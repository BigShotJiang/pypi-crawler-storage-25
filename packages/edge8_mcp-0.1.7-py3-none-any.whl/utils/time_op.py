import time
import re
from typing import Optional

def calculate_expiry_date(
    expires_in: Optional[int] = None
) -> int:
    from datetime import datetime, timedelta
    new_expires_at = datetime.now() + timedelta(seconds=expires_in)
    expires_at_str = new_expires_at.isoformat()

    return expires_at_str

def get_time_difference(timestamp: int, output_type: str = 'hours') -> int:
    current_time = time.time()
    time_difference = current_time - timestamp
    if output_type == 'hours':
        return int(time_difference / 3600)
    elif output_type == 'minutes':
        return int(time_difference / 60)
    elif output_type == 'seconds':
        return int(time_difference)
    else:
        raise ValueError(f"Invalid output type: {output_type}")


def frequency_to_cron(descriptor: str) -> Optional[str]:
    """
    Convert a time-frequency descriptor to a cron expression.
    
    Supports descriptors like:
    - "daily", "weekly", "monthly", "yearly"
    - "every N months/hours/days/weeks/minutes" (e.g., "every 2 months", "every 3 hours")
    - "daily at Xam/pm" or "daily at HH:MM am/pm" (e.g., "daily at 9am", "daily at 08:30 am")
    - "on day X of the month at HH:MM am/pm" (e.g., "on day 10 of the month at 08:00 am")
    - "on [weekday] at HH:MM am/pm" (e.g., "on monday at 9am", "on friday at 5:30 pm")
    - "at HH:MM am/pm" (e.g., "at 9am", "at 3:30 pm")
    - "every minutes", "every hour"
    
    Args:
        descriptor: Natural language frequency description
        
    Returns:
        Cron expression string, or None if descriptor is not recognized
        
    Examples:
        >>> frequency_to_cron("daily")
        "0 0 * * *"
        >>> frequency_to_cron("daily at 9am")
        "0 9 * * *"
        >>> frequency_to_cron("every 3 months")
        "0 0 1 */3 *"
        >>> frequency_to_cron("on day 10 of the month at 08:00 am")
        "0 8 10 * *"
        >>> frequency_to_cron("on monday at 9am")
        "0 9 * * 1"
    """
    descriptor = descriptor.lower().strip()
    
    # Simple mappings
    simple = {
        "daily": "0 0 * * *", "weekly": "0 0 * * 0", "monthly": "0 0 1 * *",
        "yearly": "0 0 1 1 *", "every minutes": "* * * * *", "every hour": "0 * * * *",
        "every minute": "* * * * *", "hourly": "0 * * * *"
    }
    if descriptor in simple:
        return simple[descriptor]
    
    # Weekday mapping
    weekdays = {
        "sunday": "0", "sun": "0", "monday": "1", "mon": "1",
        "tuesday": "2", "tue": "2", "tues": "2", "wednesday": "3", "wed": "3",
        "thursday": "4", "thu": "4", "thur": "4", "thurs": "4",
        "friday": "5", "fri": "5", "saturday": "6", "sat": "6"
    }
    
    # Parse time helper
    def parse_time(s: str) -> Optional[tuple]:
        m = re.match(r"(\d{1,2})(?::(\d{2}))?\s*(am|pm)", s)
        if not m:
            return None
        h, min_str, period = int(m.group(1)), m.group(2), m.group(3)
        h = h + 12 if period == "pm" and h != 12 else 0 if period == "am" and h == 12 else h
        return (h, int(min_str) if min_str else 0)
    
    # Try time-based patterns
    patterns = [
        (r"on day (\d{1,2}) of (?:the )?month at (.+)", lambda m, t: f"{t[1]} {t[0]} {m.group(1)} * *" if t and 1 <= int(m.group(1)) <= 31 else None),
        (r"on (monday|tuesday|wednesday|thursday|friday|saturday|sunday|mon|tue|wed|thu|fri|sat|sun|tues|thur|thurs) at (.+)", 
         lambda m, t: f"{t[1]} {t[0]} * * {weekdays[m.group(1)]}" if t and m.group(1) in weekdays else None),
        (r"daily at (.+)", lambda m, t: f"{t[1]} {t[0]} * * *" if t else None),
        (r"weekdays at (.+)", lambda m, t: f"{t[1]} {t[0]} * * 1-5" if t else None),
        (r"weekends at (.+)", lambda m, t: f"{t[1]} {t[0]} * * 0,6" if t else None),
        (r"first day of (?:the )?month at (.+)", lambda m, t: f"{t[1]} {t[0]} 1 * *" if t else None),
        (r"at (.+)", lambda m, t: f"{t[1]} {t[0]} * * *" if t else None),
    ]
    
    for pattern, handler in patterns:
        m = re.match(pattern, descriptor)
        if m:
            t = parse_time(m.groups()[-1].strip())
            result = handler(m, t)
            if result:
                return result
    
    # Interval patterns
    intervals = [
        (r"every (\d+) months?", "0 0 1 */{} *"),
        (r"every (\d+) hours?", "0 */{} * * *"),
        (r"every (\d+) minutes?", "*/{} * * * *"),
        (r"every (\d+) days?", "0 0 */{} * *"),
    ]
    
    for pattern, template in intervals:
        m = re.match(pattern, descriptor)
        if m:
            return template.format(m.group(1))
    
    # Weeks (special case: convert to days)
    m = re.match(r"every (\d+) weeks?", descriptor)
    if m:
        return f"0 0 */{int(m.group(1)) * 7} * *"
    
    return None



FREQUENCY_DESCRIPTOR_OPTIONS = [
    # Basic frequencies
    "daily", "weekly", "monthly", "yearly", "hourly",
    
    # Minute/hour intervals
    "every minute", "every minutes", "every hour",
    "every 5 minutes", "every 15 minutes", "every 30 minutes",
    "every 2 hours", "every 6 hours", "every 12 hours",
    
    # Day/week/month intervals
    "every 2 days", "every 7 days",
    "every 1 week", "every 2 weeks",
    "every 2 months", "every 3 months", "every 6 months", "every 12 months",
    
    # Daily at specific times (simple)
    "daily at 6am", "daily at 7am", "daily at 8am", "daily at 9am", "daily at 10am", "daily at 11am",
    "daily at 12pm", "daily at 3pm", "daily at 4pm", "daily at 5pm", "daily at 6pm", "daily at 7pm",
    "daily at 8pm", "daily at 9pm", "daily at 10pm", "daily at 11pm", "daily at 12am",
    
    # Daily at specific times (with minutes)
    "daily at 8:30 am", "daily at 2:45 pm", "daily at 11:00 pm",
    
    # Shorthand for daily at time
    "at 9am", "at 3:30 pm", "at 12:00 am",
    
    # Day of month patterns
    "on day 1 of the month at 9am", "on day 10 of the month at 08:00 am", "on day 15 of month at 3:30 pm",
    "first day of month at 9am", "first day of the month at 8:30 am",
    
    # Weekday patterns
    "on monday at 9am", "on tuesday at 2:30 pm", "on wednesday at 8:15 am",
    "on thursday at 5pm", "on friday at 6:45 pm", "on saturday at 10am", "on sunday at 11:30 am",
    "on mon at 9am", "on fri at 5pm", "on sat at 8am",
    
    # Weekdays/weekends
    "weekdays at 9am", "weekdays at 5:30 pm",
    "weekends at 10am", "weekends at 8:00 pm",
]

SIMPLE_DESCRIPTORS = ["daily", "weekly", "monthly", "yearly", "hourly"]
GAP_DESCRIPTORS = [
    "every 2 days", "every 7 days","every 2 weeks",
    "every 2 months", "every 3 months", "every 6 months", "every 12 months"
]
SPECIFIC_TIME_DESCRIPTORS = [
    "daily at 6am", "daily at 7am", "daily at 8am", "daily at 9am", "daily at 10am", "daily at 11am",
    "daily at 12pm", "daily at 3pm", "daily at 4pm", "daily at 5pm", "daily at 6pm", "daily at 7pm",
    "daily at 8pm", "daily at 9pm", "daily at 10pm", "daily at 11pm", "daily at 12am", "daily at 8:30 am", 
    "daily at 2:45 pm", "daily at 11:00 pm", "at 9am", "at 3:30 pm", "at 12:00 am", "weekdays at 9am", 
    "weekdays at 5:30 pm", "weekends at 10am", "weekends at 8:00 pm"
]
COMPLEX_DESCRIPTORS = [
    # Day of month patterns
    "on day 10 of the month at 08:00 am", "on day 1 of the month at 9am",  "on day 15 of month at 3:30 pm",
    "first day of month at 9am", "first day of the month at 8:30 am",
]

WEEKDAYS_COMPLEX_DESCRIPTORS = [
    # Weekday patterns
    "on monday at 9am", "on tuesday at 2:30 pm", "on wednesday at 8:15 am",
    "on thursday at 5pm", "on friday at 6:45 pm", "on saturday at 10am", "on sunday at 11:30 am",
    "on mon at 9am", "on fri at 5pm", "on sat at 8am",
]

SAMPLING_DESCRIPTORS = SIMPLE_DESCRIPTORS + GAP_DESCRIPTORS[:2] + SPECIFIC_TIME_DESCRIPTORS[:5] + COMPLEX_DESCRIPTORS[:5] + WEEKDAYS_COMPLEX_DESCRIPTORS[:5]

__all__ = ["get_time_difference", "frequency_to_cron", "SAMPLING_DESCRIPTORS", "calculate_expiry_date"]