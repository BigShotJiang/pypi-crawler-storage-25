"""
Mission detection utilities for Circle chat room assignments

Provides functions to detect mission patterns in text and match them
with space names based on normalized mission numbers.
"""

import re
from typing import Optional, List, Union

# Mapping of word numbers to digits
WORD_TO_NUMBER = {
    "zero": "0", "one": "1", "two": "2", "three": "3", "four": "4",
    "five": "5", "six": "6", "seven": "7", "eight": "8", "nine": "9",
    "ten": "10", "eleven": "11", "twelve": "12", "thirteen": "13",
    "fourteen": "14", "fifteen": "15", "sixteen": "16", "seventeen": "17",
    "eighteen": "18", "nineteen": "19", "twenty": "20"
}


def normalize_mission_number(mission_text: str) -> str:
    """
    Convert mission text to normalized 2-digit format.
    Handles both numeric and word formats.
    
    Args:
        mission_text: Mission text (e.g., "1", "01", "One", "one")
        
    Returns:
        Normalized 2-digit string (e.g., "01")
    """
    try:
        # Try to convert word to number
        mission_lower = mission_text.lower().strip()
        if mission_lower in WORD_TO_NUMBER:
            mission_num = int(WORD_TO_NUMBER[mission_lower])
        else:
            # Try to parse as integer
            mission_num = int(mission_text)
        
        # Return as 2-digit zero-padded string
        return str(mission_num).zfill(2)
    except (ValueError, AttributeError):
        return ""


def detect_mission_space(text: str, spaces: List[dict], with_id: Optional[bool] = False) -> Optional[Union[str, List[str]]]:
    """
    Detect mission pattern in text and match with space names.
    
    Looks for pattern "Mission [for] <Mission_Number>" where <Mission_Number> can be:
    - A number: "1", "01", "2"
    - A word: "One", "Two", "Three", etc. (case-sensitive)
    
    Handles optional "for" connector: "Mission 1" or "Mission for 1" or "Mission for One"
    
    Matches against space names where first 2 characters are the mission number.
    Example: Space "01 Enter the AI Officer" matches Mission 1 or Mission for One
    
    Args:
        text: Text to scan for mission pattern
        spaces: List of space dictionaries with 'name' field
        
    Returns:
        Space name if matched, None otherwise
    """
    if not text or not spaces:
        return None
    
    try:
        # Pattern: "Mission" (case-sensitive) followed by optional "for" and whitespace,
        # then only number or valid number word (no random words)
        # Valid number words: zero, one, two, three, ..., twenty
        valid_words = "|".join(WORD_TO_NUMBER.keys())
        # Support "Mission 1", "Mission #1", "Mission One", "Mission #one"
        mission_pattern = rf"Mission\s+#?\s*(\d+|{valid_words})"
        matches = re.findall(mission_pattern, text, re.IGNORECASE)
        
        if not matches:
            return None
        
        mission_text = matches[0]  # Get first match
        
        # Normalize mission text to 2-digit format
        normalized_mission = normalize_mission_number(mission_text)
        
        if not normalized_mission:
            return None
        
        # Check if any space name starts with the normalized mission number
        for space in spaces:
            space_name = space.get("name", "")
            if space_name and len(space_name) >= 2:
                space_prefix = space_name[:2]
                
                # Direct comparison of 2-digit prefixes
                if space_prefix == normalized_mission:
                    return space_name if not with_id else [space.get("id", None), space_name]
        
        return None
    except Exception as e:
        print(f"⚠️ Error detecting mission pattern: {str(e)}")
        return None


__all__ = ["WORD_TO_NUMBER", "normalize_mission_number", "detect_mission_space"]
