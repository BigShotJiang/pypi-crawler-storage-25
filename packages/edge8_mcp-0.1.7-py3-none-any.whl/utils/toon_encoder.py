"""
Custom TOON encoder/decoder for LLM-optimized structured data.

Focused on tool results and agent context data.
Simplified implementation for production stability.
"""

from typing import Any, List, Dict, Union, Optional
import re


class ToonEncoder:
    """Custom TOON encoder for LLM-optimized data serialization."""

    # Characters that require quoting
    QUOTE_REQUIRED = set(':,[]{}#- \t\n\r\\"\'')
    KEYWORDS = {'true', 'false', 'null', 'inf', 'nan'}

    @classmethod
    def _needs_quoting(cls, value: str) -> bool:
        """Check if a string value needs quoting."""
        if not value:
            return True
        if value.lower() in cls.KEYWORDS:
            return True
        # Check if it looks like a number
        if re.match(r'^-?\d+\.?\d*$', value):
            return True
        return any(char in cls.QUOTE_REQUIRED for char in value)

    @classmethod
    def _quote_string(cls, value: str) -> str:
        """Quote a string if necessary."""
        if cls._needs_quoting(value):
            # Use backticks for quoting (TOON convention)
            return f'`{value}`'
        return value

    @classmethod
    def _encode_value(cls, value: Any, indent: int = 0) -> str:
        """Encode a single value to TOON format."""
        if value is None:
            return 'null'
        elif isinstance(value, bool):
            return 'true' if value else 'false'
        elif isinstance(value, (int, float)):
            return str(value)
        elif isinstance(value, str):
            return cls._quote_string(value)
        elif isinstance(value, dict):
            return cls._encode_object(value, indent)
        elif isinstance(value, list):
            return cls._encode_array(value, indent)
        else:
            # Fallback to string representation
            return cls._quote_string(str(value))

    @classmethod
    def _encode_object(cls, obj: Dict[str, Any], indent: int = 0) -> str:
        """Encode object to TOON format."""
        if not obj:
            # Empty object - use special marker
            return '{}'
        
        lines = []
        prefix = '  ' * indent
        
        for key, value in obj.items():
            encoded_value = cls._encode_value(value, indent + 1)
            
            # Check if encoded value is multiline
            if '\n' in encoded_value:
                # Multiline value - put on next line with indentation
                lines.append(f'{prefix}{cls._quote_string(key)}:')
                lines.append(encoded_value)
            else:
                # Simple types on same line
                lines.append(f'{prefix}{cls._quote_string(key)}: {encoded_value}')
        
        return '\n'.join(lines)

    @classmethod
    def _is_uniform_object_array(cls, arr: List[Any]) -> bool:
        """Check if array contains uniform objects (same keys) with primitive values."""
        if not arr or not all(isinstance(item, dict) for item in arr):
            return False

        # Get keys from first object
        first_keys = set(arr[0].keys())

        # Check all objects have same keys
        for item in arr[1:]:
            if set(item.keys()) != first_keys:
                return False

        # Check if all values are primitives (no nested dicts or lists)
        for item in arr:
            for value in item.values():
                if isinstance(value, (dict, list)):
                    return False

        return True

    @classmethod
    def _encode_tabular_array(cls, arr: List[Dict[str, Any]], indent: int = 0) -> str:
        """Encode uniform object array as tabular format."""
        if not arr:
            return f'[0]:'

        # Get headers from first object
        headers = list(arr[0].keys())
        quoted_headers = [cls._quote_string(h) for h in headers]

        lines = []
        prefix = '  ' * indent

        # Header line
        lines.append(f'{prefix}[{len(arr)},{{{",".join(quoted_headers)}}}]:')

        # Data rows
        for obj in arr:
            values = []
            for key in headers:
                value = obj.get(key)
                if isinstance(value, (dict, list)):
                    # Complex values in tabular format - use JSON string
                    values.append(cls._quote_string(str(value)))
                else:
                    values.append(cls._encode_value(value))
            lines.append(f'{prefix}{",".join(values)}')

        return '\n'.join(lines)

    @classmethod
    def _encode_primitive_array(cls, arr: List[Any], indent: int = 0) -> str:
        """Encode array of primitives."""
        prefix = '  ' * indent
        values = [cls._encode_value(v) for v in arr]
        return f'{prefix}[{len(arr)}]: {",".join(values)}'

    @classmethod
    def _encode_mixed_array(cls, arr: List[Any], indent: int = 0) -> str:
        """Encode mixed array using dash prefix."""
        if not arr:
            return f'[0]:'

        lines = []
        prefix = '  ' * indent

        lines.append(f'{prefix}[{len(arr)}]:')

        for item in arr:
            encoded = cls._encode_value(item, indent + 1)
            if isinstance(item, (dict, list)):
                # Complex type: add dash, then value on next line
                lines.append(f'{prefix}-')
                lines.append(encoded)
            else:
                # Simple type: dash and value on same line
                lines.append(f'{prefix}- {encoded}')

        return '\n'.join(lines)

    @classmethod
    def _encode_array(cls, arr: List[Any], indent: int = 0) -> str:
        """Encode an array to TOON format."""
        if not arr:
            return f'[0]:'

        # Check if uniform object array (tabular format)
        if cls._is_uniform_object_array(arr):
            return cls._encode_tabular_array(arr, indent)

        # Check if all primitives
        if all(not isinstance(item, (dict, list)) for item in arr):
            return cls._encode_primitive_array(arr, indent)

        # Mixed array
        return cls._encode_mixed_array(arr, indent)

    @classmethod
    def encode(cls, data: Any) -> str:
        """
        Encode data to TOON format.

        Args:
            data: Data to encode (dict, list, or primitive)

        Returns:
            TOON-formatted string
        """
        return cls._encode_value(data, indent=0)


class ToonDecoder:
    """Custom TOON decoder for parsing TOON-formatted strings."""

    KEYWORDS = {'true', 'false', 'null', 'inf', 'nan'}

    @classmethod
    def _parse_value(cls, value: str) -> Any:
        """Parse a string value to appropriate type."""
        value = value.strip()
        
        # Handle quoted strings
        if value.startswith('`') and value.endswith('`'):
            return value[1:-1]
        
        # Handle keywords
        if value.lower() == 'true':
            return True
        elif value.lower() == 'false':
            return False
        elif value.lower() == 'null':
            return None
        elif value.lower() == 'inf':
            return float('inf')
        elif value.lower() == 'nan':
            return float('nan')
        
        # Handle numbers
        try:
            if '.' in value or 'e' in value.lower():
                return float(value)
            return int(value)
        except ValueError:
            pass
        
        # Return as string
        return value

    @classmethod
    def _parse_line_indent(cls, line: str) -> tuple[int, str]:
        """Parse indentation level and content."""
        stripped = line.lstrip(' ')
        indent = (len(line) - len(stripped)) // 2
        return indent, stripped

    @classmethod
    def _parse_array_header(cls, line: str) -> Optional[tuple[int, Optional[List[str]]]]:
        """Parse array header line like '[3]:' or '[3,{key1,key2}]:'."""
        # Match up to the colon only
        match = re.match(r'^\[(\d+)(?:,\{([^}]*)\})?\]:', line.strip())
        if not match:
            return None
        
        count = int(match.group(1))
        keys_str = match.group(2)
        
        if keys_str:
            keys = [k.strip() for k in keys_str.split(',')]
            return count, keys
        return count, None

    @classmethod
    def _parse_primitive_array(cls, line: str) -> List[Any]:
        """Parse primitive array line like '[3]: 1,2,3'."""
        match = re.match(r'^\[(\d+)\]:\s*(.*)$', line.strip())
        if not match:
            return []
        
        count = int(match.group(1))
        values_str = match.group(2).strip()
        
        # Handle empty array
        if count == 0 or not values_str:
            return []
        
        return [cls._parse_value(v) for v in values_str.split(',')]

    @classmethod
    def _parse_key_value(cls, line: str) -> Optional[tuple[str, Any]]:
        """Parse key-value line like 'key: value'."""
        if ':' not in line:
            return None
        
        key, value = line.split(':', 1)
        key = key.strip()
        value = value.strip()
        
        # Handle empty object marker
        if value == '{}':
            return key, {}
        
        # Handle empty value
        if not value:
            return key, ''
        
        # Check if value is a quoted string - preserve it
        if value.startswith('`') and value.endswith('`'):
            return key, value[1:-1]
        
        return key, cls._parse_value(value)

    @classmethod
    def _parse_tabular_array(cls, lines: List[str], headers: List[str]) -> List[Dict[str, Any]]:
        """Parse tabular array data rows."""
        result = []
        
        for line in lines:
            line = line.strip()
            if not line or line.startswith('['):
                continue
            
            values = [cls._parse_value(v) for v in line.split(',')]
            if len(values) == len(headers):
                obj = {}
                for i, key in enumerate(headers):
                    obj[key] = values[i]
                result.append(obj)
        
        return result

    @classmethod
    def _parse_object_with_nesting(cls, lines: List[str]) -> Dict[str, Any]:
        """Parse object with potential nested structures."""
        result = {}
        i = 0
        
        while i < len(lines):
            line = lines[i]
            indent, content = cls._parse_line_indent(line)
            
            # Check if this is a key-value pair with an array value
            # Pattern: "key: [n]:" or "key: [n,{headers}]:"
            if ':' in content:
                parts = content.split(':', 2)  # Split on first two colons
                if len(parts) >= 2:
                    key_part = parts[0].strip()
                    value_part = ':'.join(parts[1:]).strip()
                    
                    # Check if value_part is an array header
                    array_header = cls._parse_array_header(value_part)
                    if array_header:
                        key = cls._parse_value(key_part)
                        
                        # Check if next line is a dash (mixed array indicator)
                        if i + 1 < len(lines):
                            next_indent, next_content = cls._parse_line_indent(lines[i + 1])
                            if next_content.strip() == '-':
                                # Mixed array
                                nested_lines = []
                                j = i + 1
                                while j < len(lines):
                                    next_indent, _ = cls._parse_line_indent(lines[j])
                                    if next_indent <= indent:
                                        break
                                    nested_lines.append(lines[j])
                                    j += 1
                                result[key] = cls._parse_mixed_array(nested_lines, indent + 1)
                                i = j
                                continue
                        
                        if array_header[1] is None:
                            # Primitive array
                            values_str = value_part.split(':', 1)[1].strip() if ':' in value_part else ''
                            if values_str:
                                values = [cls._parse_value(v) for v in values_str.split(',') if v.strip()]
                            else:
                                values = []
                            result[key] = values
                        else:
                            # Tabular array - collect data lines
                            headers = array_header[1]
                            data_lines = []
                            j = i + 1
                            while j < len(lines):
                                next_indent, _ = cls._parse_line_indent(lines[j])
                                if next_indent <= indent:
                                    break
                                data_lines.append(lines[j])
                                j += 1
                            result[key] = cls._parse_tabular_array(data_lines, headers)
                            i = j
                            continue
                        i += 1
                        continue
            
            # Parse as regular key-value
            kv = cls._parse_key_value(content)
            if kv:
                key, value = kv
                # Check if next line is more indented (nested structure)
                if i + 1 < len(lines):
                    next_indent, _ = cls._parse_line_indent(lines[i + 1])
                    if next_indent > indent:
                        # Nested structure - collect nested lines
                        nested_lines = []
                        j = i + 1
                        while j < len(lines):
                            next_indent, _ = cls._parse_line_indent(lines[j])
                            if next_indent <= indent:
                                break
                            nested_lines.append(lines[j])
                            j += 1
                        
                        # Check if nested structure is an array
                        nested_first = nested_lines[0].strip() if nested_lines else ''
                        nested_array_header = cls._parse_array_header(nested_first)
                        if nested_array_header:
                            # Nested array
                            if nested_array_header[1] is None:
                                # Check if it's a mixed array (followed by dash)
                                if len(nested_lines) > 1 and nested_lines[1].strip() == '-':
                                    result[key] = cls._parse_mixed_array(nested_lines, indent + 1)
                                else:
                                    # Primitive array
                                    values_str = nested_first.split(':', 1)[1].strip()
                                    if values_str:
                                        values = [cls._parse_value(v) for v in values_str.split(',') if v.strip()]
                                    else:
                                        values = []
                                    result[key] = values
                            else:
                                # Tabular array
                                headers = nested_array_header[1]
                                data_lines = nested_lines[1:] if len(nested_lines) > 1 else []
                                result[key] = cls._parse_tabular_array(data_lines, headers)
                        elif nested_first.startswith('-'):
                            # Mixed array
                            result[key] = cls._parse_mixed_array(nested_lines, indent + 1)
                        else:
                            # Nested object
                            result[key] = cls._parse_object_with_nesting(nested_lines)
                        
                        i = j
                        continue
                
                result[key] = value
            elif kv:
                result[kv[0]] = kv[1]
            
            i += 1
        
        return result

    @classmethod
    def _parse_mixed_array(cls, lines: List[str], base_indent: int) -> List[Any]:
        """Parse mixed array using dash prefix."""
        result = []
        i = 0
        
        while i < len(lines):
            line = lines[i]
            indent, content = cls._parse_line_indent(line)
            
            if content.startswith('- '):
                # Simple item
                value = cls._parse_value(content[2:].strip())
                result.append(value)
            elif content == '-':
                # Complex item on next line
                i += 1
                if i < len(lines):
                    next_indent, next_content = cls._parse_line_indent(lines[i])
                    if next_indent > base_indent:
                        # Check if next line is an array
                        nested_array_header = cls._parse_array_header(next_content)
                        if nested_array_header:
                            if nested_array_header[1] is None:
                                # Primitive array
                                values_str = next_content.split(':', 1)[1].strip()
                                if values_str:
                                    values = [cls._parse_value(v) for v in values_str.split(',') if v.strip()]
                                else:
                                    values = []
                                result.append(values)
                            else:
                                # Tabular array
                                headers = nested_array_header[1]
                                data_lines = []
                                j = i + 1
                                while j < len(lines):
                                    next_indent, _ = cls._parse_line_indent(lines[j])
                                    if next_indent <= base_indent:
                                        break
                                    data_lines.append(lines[j])
                                    j += 1
                                result.append(cls._parse_tabular_array(data_lines, headers))
                                i = j - 1
                        else:
                            # Nested object - collect all lines until next dash at same or lower indent
                            nested_lines = []
                            j = i
                            while j < len(lines):
                                next_indent, next_content = cls._parse_line_indent(lines[j])
                                # Stop if we find another dash at base_indent or lower
                                if next_content.strip() == '-' and next_indent <= base_indent:
                                    break
                                nested_lines.append(lines[j])
                                j += 1
                            result.append(cls._parse_object_with_nesting(nested_lines))
                            i = j - 1
            i += 1
        
        return result

    @classmethod
    def decode(cls, toon_str: str) -> Any:
        """
        Decode TOON-formatted string to Python data.

        Args:
            toon_str: TOON-formatted string

        Returns:
            Decoded Python data (dict, list, or primitive)
        """
        lines = toon_str.strip().split('\n')
        
        if not lines:
            return None
        
        # Check if it's a primitive array on single line
        if len(lines) == 1:
            array_header = cls._parse_array_header(lines[0])
            if array_header and array_header[1] is None:
                return cls._parse_primitive_array(lines[0])
        
        # Check if it's a tabular array
        first_line = lines[0].strip()
        array_header = cls._parse_array_header(first_line)
        if array_header and array_header[1] is not None:
            # Tabular array
            headers = array_header[1]
            data_lines = lines[1:]
            return cls._parse_tabular_array(data_lines, headers)
        
        # Check if it's a mixed array
        if array_header and array_header[1] is None:
            # Mixed array - delegate to _parse_mixed_array
            return cls._parse_mixed_array(lines[1:], 0)
        
        # Parse as object with potential nesting
        return cls._parse_object_with_nesting(lines)


def encode_toon(data: Any) -> str:
    """
    Convenience function to encode data to TOON format.

    Args:
        data: Data to encode

    Returns:
        TOON-formatted string

    Example:
        >>> data = [{"id": 1, "name": "Alice"}, {"id": 2, "name": "Bob"}]
        >>> encode_toon(data)
        '[2,{id,name}]:\\n1,Alice\\n2,Bob'
    """
    return ToonEncoder.encode(data)


def decode_toon(toon_str: str) -> Any:
    """
    Convenience function to decode TOON format to Python data.

    Args:
        toon_str: TOON-formatted string

    Returns:
        Decoded Python data (dict, list, or primitive)

    Example:
        >>> toon_str = '[2,{id,name}]:\\n1,Alice\\n2,Bob'
        >>> decode_toon(toon_str)
        [{'id': 1, 'name': 'Alice'}, {'id': 2, 'name': 'Bob'}]
    """
    return ToonDecoder.decode(toon_str)


__all__ = ['ToonEncoder', 'ToonDecoder', 'encode_toon', 'decode_toon']
