import requests
from httpx import AsyncClient, Limits
import asyncio

# Global client instance - will be initialized in lifespan
client: AsyncClient = None

def get_client():
    """Get or create the AsyncClient instance with proper connection limits"""
    global client
    if client is None:
        # Configure limits for better connection handling in serverless environments
        limits = Limits(
            max_connections=100,  # Maximum number of connections in the pool
            max_keepalive_connections=20,  # Maximum number of idle connections
            keepalive_expiry=5.0  # Seconds to keep idle connections alive
        )
        client = AsyncClient(
            timeout=30.0,
            limits=limits,
            http2=True,  # Enable HTTP/2 for better performance
            follow_redirects=True
        )
    return client

def send_webhook(webhook_url, payload):
    response = requests.post(webhook_url, json=payload)
    
    if response.status_code != 200:
        raise Exception("Failed to send webhook")
    
    return response.json()

async def non_await_request(url, payload, headers, method="POST", max_retries=3):
    """
    Make an async HTTP request with retry logic for better reliability in serverless environments.
    
    Args:
        url: The URL to send the request to
        payload: The JSON payload to send
        headers: Request headers
        method: HTTP method (default: POST)
        max_retries: Maximum number of retry attempts (default: 3)
    """
    http_client = get_client()
    last_exception = None
    
    # for attempt in range(max_retries):
    #     try:
    #         response = await http_client.request(method, url, json=payload, headers=headers)
    #         print(f"Response status: {response.status_code} (attempt {attempt + 1})")
    #         return response
    #     except Exception as e:
    #         last_exception = e
    #         print(f"Error in non_await_request (attempt {attempt + 1}/{max_retries}): {str(e)}")
            
    #         # Don't retry on the last attempt
    #         if attempt < max_retries - 1:
    #             # Exponential backoff: 0.5s, 1s, 2s
    #             wait_time = 0.5 * (2 ** attempt)
    #             print(f"Retrying in {wait_time} seconds...")
    #             await asyncio.sleep(wait_time)
    #         else:
    #             print(f"All {max_retries} attempts failed for {url}")
    #             raise last_exception
    try:
        response = await http_client.request(method, url, json=payload, headers=headers)
        print(response.text)
        print(f"Response status: {response.status_code}")
        return response
    except Exception as e:
        print(f"Error in non_await_request: {str(e)}")
        return e
    
    
        