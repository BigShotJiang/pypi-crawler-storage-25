# Utils Module

## Purpose

The `src/utils/` package hosts shared utility functions used across routers, agents, and connectors. Utilities are small, stateless helpers that avoid platform-specific logic and keep business code lean.

## Typical Responsibilities

- HTTP/webhook helpers
- Data transformations and formatting
- Validation helpers
- Logging and tracing helpers
- Small pure functions reused across modules

## Usage Guidelines

1. **Stateless**: Utilities should not hold state; pass all required data via parameters.
2. **Pure when possible**: Favor pure functions (no side effects) to ease testing.
3. **No platform coupling**: Keep platform-specific logic inside connectors/agents, not utils.
4. **Typed**: Use strict typing for parameters and return values.
5. **Granular**: Prefer small, focused helpers over large utility classes.

## Example Patterns

### Webhook Helpers
```python
from src.utils.webhooks_interaction import get_client

# Reuse shared async HTTP client for webhook callbacks
client = get_client()
response = await client.post(url, json=payload)
```

### Validation Helpers
```python
from typing import Any

def assert_required(field: Any, name: str) -> None:
    if field is None:
        raise ValueError(f"Missing required field: {name}")
```

### Formatting Helpers
```python
def format_percentage(value: float) -> str:
    return f"{value:.2%}"
```

## Best Practices

- Keep dependencies minimal; utils should not import heavy modules unnecessarily.
- Avoid circular imports—do not import routers or agents inside utils.
- Provide docstrings and type hints for every function.
- Add unit tests for non-trivial helpers.
- If a utility grows platform-specific branches, migrate it to the relevant connector/agent.

## Testing

- Add targeted unit tests in `tests/` for any non-trivial logic.
- Mock network or file I/O when necessary.
- Ensure formatting/validation helpers have edge-case coverage.
