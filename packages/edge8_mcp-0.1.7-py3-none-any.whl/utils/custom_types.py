from typing import TypedDict, Optional, List

Metadata = TypedDict(
    "Metadata",
    {
        "experience_id": Optional[str],
        "activity_id": Optional[str],
        "id": Optional[int],
        "vector_id": Optional[int],
        "fts_id": Optional[int],
        "distance": Optional[float],
        "bm25_score": Optional[float],
        "hybrid_score": Optional[float],
        "source": Optional[str],
        "title": Optional[str],
        "type": Optional[str],
    },
)


class DocumentProps:
    def __init__(self, content: str, metadata: Optional[Metadata] = None):
        self.content = content
        self.metadata = metadata

    def __repr__(self):
        return f"""
        Document
        Content: 
        {self.content}
        Metadata: 
        {self.metadata}
        """


BraveSearchConfig = TypedDict(
    "BraveSearchConfig", {"num_results": Optional[int], "result_filter": Optional[str]}
)

ExaConfig = TypedDict(
    "ExaConfig",
    {
        "type": Optional[str],
        "num_results": Optional[int],
        "livecrawl": Optional[str],
        "summary": Optional[dict],
        "subpages": Optional[int],
        "extras": Optional[dict],
        "as_answer": Optional[bool],
    },
)

DataPrepTyping = TypedDict(
    "DataPrepTyping",
    {
        "data_source": Optional[str],
        "data_loader": Optional[str],
        "custom_metadata": Optional[dict[str, str]],
        "exa_config": Optional[ExaConfig],
    },
)

LoaderProps = TypedDict(
    "LoaderProps",
    {
        "data_preparation": Optional[List[DataPrepTyping]],
        "raw_docs": Optional[List[DocumentProps]],
        "chunk_size": Optional[int],
        "chunk_overlap": Optional[int],
        "with_analyzer": Optional[bool],
        "system_prompt": Optional[str],
    },
)

ContentHints = TypedDict(
    "ContentHints",
    {
        "indexableText": Optional[str],
        "thumbnail": Optional[TypedDict("Thumbnail", {"mimeType": str, "image": str})],
    },
)

GoogleDriveUploadMetadata = TypedDict(
    "GoogleDriveUploadMetadata", {"name": Optional[str], "parents": Optional[list[str]]}
)

StoryGenProps = TypedDict(
    "StoryGenProps",
    {
        "experience_id": str,
        "notes": str,
        "media": List[str],
        "story_length": int,
        "reporter_id": Optional[str],
        "seo_title_tag": Optional[str],
        "seo_meta_desc": Optional[str],
        "seo_excerpt": Optional[str],
        "seo_slug": Optional[str],
        "long_tail_keyword": Optional[str],
        "hashtags": Optional[List[str]],
    },
)

ToolSources = TypedDict(
    "ToolSources",
    {
        "type": str,
        "title": str,
        "url": str,
        "snippet": str,
        "relevance_score": float,
        "content_type": str,
    },
)

MediaProps = TypedDict(
    "MediaProps", {"body": str, "path": str, "mimeType": Optional[str]}
)

LocalizationObject = TypedDict("LocalizationObject", {"label": dict, "value": str})

LocalizationObjectList = List[LocalizationObject]

LocalizationRequest = TypedDict(
    "LocalizationRequest", {"objects": LocalizationObjectList, "target_language": str}
)

LarkTableFieldPropertyOptions = TypedDict(
    "LarkTableFieldPropertyOptions", {"name": Optional[str], "color": Optional[int]}
)

LarkUiProp = TypedDict(
    "UiProp",
    {
        "formatter": Optional[int],
        "date_formatter": Optional[str],
        "auto_fill": Optional[str],
        "multiple": Optional[bool],
        "table_id": Optional[str],
        "back_field_name": Optional[str],
        "min": Optional[int],
        "max": Optional[int],
        "currency_code": Optional[str],
        "rating": Optional[TypedDict("Rating", {"symbol": Optional[str]})],
    },
)

LarkFieldType = TypedDict(
    "Type",
    {
        "data_type": int,
        "ui_property": Optional[LarkUiProp],
        "ui_type": Optional[str],
    },
)

LarkTableFieldProperty = TypedDict(
    "LarkTableFieldProperty",
    {
        **LarkUiProp.__annotations__,
        "options": Optional[List[LarkTableFieldPropertyOptions]],
        "type": Optional[LarkFieldType],
        "ui_type": Optional[str],
        # Text：multiline text
        # Email：Email
        # Barcode：barcode
        # Number：number
        # Progress：progress
        # Currency：currency
        # Rating：score
        # SingleSelect：radio
        # MultiSelect：multiple choice
        # DateTime：date
        # Checkbox：checkbox
        # User：Personnel
        # GroupChat：group
        # Phone：Phone number
        # Url：Hyperlink
        # Attachment：Attachment
        # SingleLink：one-way association
        # Formula：formula
        # DuplexLink：bidirectional association
        # Location：Geographical location
        # CreatedTime：Creation time
        # ModifiedTime：Last update time
        # CreatedUser：founder
        # ModifiedUser：Modifier
        # AutoNumber：Automatic numbering
    },
)

LarkTableField = TypedDict(
    "LarkTableField",
    {"field_name": str, "type": int, "property": Optional[LarkTableFieldProperty]},
)

LarkTimeProp = TypedDict(
    "LarkTimeProp",
    {"date": Optional[str], "timestamp": Optional[str], "timezone": Optional[str]},
)

LarkEventFilter = TypedDict(
    "LarkEventFilter",
    {
        "start_time": Optional[LarkTimeProp],
        "end_time": Optional[LarkTimeProp],
        "user_ids": Optional[List[str]],
        "room_ids": Optional[List[str]],
        "chat_ids": Optional[List[str]],
    },
)

LarkEventMeetingSetting = TypedDict(
    "LarkEventMeetingSetting",
    {
        "owner_id": Optional[str],
        "join_meeting_permission": Optional[str],
        "assign_hosts": Optional[List[str]],
        "auto_record": Optional[bool],
        "open_lobby": Optional[bool],
        "allow_attendees_start": Optional[bool],
    },
)

LarkMeetingSettingProps = TypedDict(
    "LarkMeetingSettingProps",
    {
        "topic": Optional[str],
        "action_permission": Optional[
            TypedDict(
                "ActionPermission",
                {
                    "permission": Optional[int],
                    "permission_checkers": Optional[
                        List[
                            TypedDict(
                                "PermissionChecker",
                                {
                                    "check_field": Optional[int],
                                    "check_mode": Optional[int],
                                    "check_list": Optional[List[str]],
                                },
                            )
                        ]
                    ],
                },
            )
        ],
        "meeting_initial_type": Optional[int],
        "call_setting": Optional[dict],  # Complex nested structure - use dict for now
        "assign_host_list": Optional[
            List[
                TypedDict(
                    "AssignHost", {"id": Optional[str], "user_type": Optional[int]}
                )
            ]
        ],
    },
)

LarkMeetingAuthorizeObject = TypedDict(
    "LarkMeetingAuthorizeObject",
    {
        "id": Optional[str],
        "type": int,
        "permission": int,
    },
)

LarkWikiNode = TypedDict(
    "LarkWikiNode",
    {
        "obj_type": str,
        "parent_node_token": Optional[str],
        "origin_node_token": str,
        "node_type": Optional[int],
        "title": Optional[str],
        "creator": Optional[str],
        "owner": Optional[str],
    },
)

LarkFileMetadata = TypedDict(
    "LarkFileMetadata",
    {
        "doc_token": Optional[str],
        "doc_type": Optional[str],
    },
)

ThoughtFlowMeetingsFilter = TypedDict(
    "ThoughtFlowMeetingsFilter",
    {
        "key": str,
        "operator": str,
        "value": str,
    },
)

# Lark Calendar Event TypedDicts
LarkEventReminder = TypedDict(
    "LarkEventReminder",
    {
        "minutes": Optional[int],
    },
)

LarkEventSchema = TypedDict(
    "LarkEventSchema",
    {
        "ui_name": Optional[str],
        "ui_status": Optional[str],
        "app_link": Optional[str],
    },
)

LarkEventOrganizer = TypedDict(
    "LarkEventOrganizer",
    {
        "user_id": Optional[str],
        "display_name": Optional[str],
    },
)

LarkAttachmentResourceCustomization = TypedDict(
    "LarkAttachmentResourceCustomization",
    {
        "index_key": Optional[str],
        "input_content": Optional[str],
        "options": Optional[
            List[
                TypedDict(
                    "ResourceCustomizationOption",
                    {
                        "option_key": Optional[str],
                        "others_content": Optional[str],
                    },
                )
            ]
        ],
    },
)

LarkChatMember = TypedDict(
    "LarkChatMember",
    {
        "rsvp_status": Optional[str],
        "is_optional": Optional[bool],
        "display_name": Optional[str],
        "is_organizer": Optional[bool],
        "is_external": Optional[bool],
    },
)

LarkVideoChatProp = TypedDict(
    "LarkVideoChatProp",
    {
        "vc_type": Optional[str],
        "description": Optional[str],
        "icon_type": Optional[LarkTimeProp],
        "meeting_url": Optional[str],
        "meeting_settings": Optional[LarkEventMeetingSetting],
    },
)

LocationProp = TypedDict(
    "LocationProp",
    {
        "name": Optional[str],
        "address": Optional[str],
        "latitude": Optional[float],
        "longitude": Optional[float],
    },
)

LarkEventAttendee = TypedDict(
    "LarkEventAttendee",
    {
        "type": Optional[str],
        "attendee_id": Optional[str],
        "rsvp_status": Optional[str],
        "is_optional": Optional[bool],
        "is_organizer": Optional[bool],
        "is_external": Optional[bool],
        "display_name": Optional[str],
        "chat_members": Optional[List[LarkChatMember]],
        "user_id": Optional[str],
        "chat_id": Optional[str],
        "room_id": Optional[str],
        "third_party_email": Optional[str],
        "operate_id": Optional[str],
        "resource_customization": Optional[List[LarkAttachmentResourceCustomization]],
    },
)

LarkEventAttachment = TypedDict(
    "LarkEventAttachment",
    {
        "file_token": Optional[str],
        "file_size": Optional[str],
        "name": Optional[str],
    },
)

LarkCalendarEvent = TypedDict(
    "LarkCalendarEvent",
    {
        "event_id": Optional[str],
        "organizer_calendar_id": Optional[str],
        "summary": Optional[str],
        "description": Optional[str],
        "start_time": Optional[LarkTimeProp],
        "end_time": Optional[LarkTimeProp],
        "vchat": Optional[LarkVideoChatProp],
        "visibility": Optional[str],
        "attendee_ability": Optional[str],
        "free_busy_status": Optional[str],
        "location": Optional[LocationProp],
        "color": Optional[int],
        "reminders": Optional[List[LarkEventReminder]],
        "recurrence": Optional[str],
        "status": Optional[str],
        "is_exception": Optional[bool],
        "recurring_event_id": Optional[str],
        "create_time": Optional[str],
        "schemas": Optional[List[LarkEventSchema]],
        "event_organizer": Optional[LarkEventOrganizer],
        "app_link": Optional[str],
        "attendees": Optional[List[LarkEventAttendee]],
        "has_more_attendee": Optional[bool],
        "attachments": Optional[List[LarkEventAttachment]],
    },
)

LarkEventAttendeeSimple = TypedDict(
    "LarkEventAttendeeSimple",
    {
        "name": Optional[str],
        "user_id": Optional[str],
        "rsvp_status": Optional[str],
        "third_party_email": Optional[str],
        "is_external": Optional[bool],
    },
)

LarkCalendarEventSummary = TypedDict(
    "LarkCalendarEventSummary",
    {
        "event_id": Optional[str],
        "summary": Optional[str],
        "description": Optional[str],
        "start_time": Optional[str],
        "start_timestamp": Optional[str],
        "start_timezone": Optional[str],
        "end_time": Optional[str],
        "end_timestamp": Optional[str],
        "end_timezone": Optional[str],
        "organizer_id": Optional[str],
        "organizer_name": Optional[str],
        "location_name": Optional[str],
        "location_address": Optional[str],
        "latitude": Optional[float],
        "longitude": Optional[float],
        "status": Optional[str], # "confirmed", "tentative", "cancelled"
        "visibility": Optional[str], # "public", "private", "confidential"
        "free_busy_status": Optional[str], # "free", "busy", "tentative", "unknown"
        "recurrence": Optional[str],
        "meeting_url": Optional[str],
        "meeting_type": Optional[str],
        "attendees": Optional[List[LarkEventAttendeeSimple]],
        "has_more_attendee": Optional[bool],
        "attachment_count": Optional[int],
        "app_link": Optional[str],
        "vc_url": Optional[str],
        "vc_type": Optional[str],
        "vc_description": Optional[str],
        "vc_permission": Optional[str],
    },
)


# ============================================================================
# Typeform API TypedDicts
# ============================================================================

# Choice option for multiple_choice and dropdown fields
TypeformChoice = TypedDict(
    "TypeformChoice",
    {
        "id": str,
        "ref": str,
        "label": str,
    },
)

# Contact info subfield (first_name, last_name, email, phone_number, company)
TypeformContactInfoSubfield = TypedDict(
    "TypeformContactInfoSubfield",
    {
        "id": str,
        "title": str,
        "ref": str,
        "subfield_key": str,  # "first_name", "last_name", "email", "phone_number", "company"
        "type": str,  # "short_text", "email", "phone_number"
        "properties": dict,
        "validations": Optional[dict],
    },
)

# Field validation rules
TypeformFieldValidation = TypedDict(
    "TypeformFieldValidation",
    {
        "required": Optional[bool],
        "max_length": Optional[int],
        "min_length": Optional[int],
        "max_value": Optional[int],
        "min_value": Optional[int],
    },
    total=False,
)

# Typeform form field definition
TypeformField = TypedDict(
    "TypeformField",
    {
        "id": str,
        "type": str,  # "short_text", "long_text", "email", "number", "dropdown", "multiple_choice", "nps", "opinion_scale", "rating", "yes_no", "contact_info", "date", "time", "phone_number", "file_upload", "statement"
        "title": str,
        "ref": str,
        "properties": dict,
        "validations": Optional[TypeformFieldValidation],
        "choices": Optional[List[TypeformChoice]],  # For multiple_choice, dropdown, rating
        "fields": Optional[List[TypeformContactInfoSubfield]],  # For contact_info type
    },
    total=False,
)

# Typeform form structure
TypeformForm = TypedDict(
    "TypeformForm",
    {
        "id": str,
        "type": str,  # "quiz", "form", "survey"
        "title": str,
        "created_at": str,  # ISO 8601 timestamp
        "updated_at": Optional[str],  # ISO 8601 timestamp, may be None
        "last_updated_at": Optional[str],  # ISO 8601 timestamp
        "published_at": Optional[str],  # ISO 8601 timestamp
        "fields": List[TypeformField],
        "welcome_screens": Optional[list],
        "thank_you_screens": Optional[list],
    },
    total=False,
)

# Answer field reference
TypeformAnswerFieldRef = TypedDict(
    "TypeformAnswerFieldRef",
    {
        "id": str,
        "type": str,
        "ref": str,
    },
)

# Individual answer in a response
TypeformAnswer = TypedDict(
    "TypeformAnswer",
    {
        "type": str,  # "text", "email", "number", "choice", "choices", "date", "time", "boolean", "file_url", "phone_number"
        "field": TypeformAnswerFieldRef,
        "text": Optional[str],  # For text, email, long_text, phone_number
        "email": Optional[str],  # For email type
        "number": Optional[int],  # For number, nps, opinion_scale, rating
        "choice": Optional[dict],  # For single choice: {"id": str, "label": str, "ref": str}
        "choices": Optional[List[dict]],  # For multiple choices: [{"id": str, "label": str, "ref": str}, ...]
        "date": Optional[str],  # For date type: "YYYY-MM-DD"
        "time": Optional[str],  # For time type: "HH:MM"
        "boolean": Optional[bool],  # For yes_no type
        "file_url": Optional[str],  # For file_upload type
        "phone_number": Optional[str],  # For phone_number type
    },
    total=False,
)

# Form response
TypeformResponse = TypedDict(
    "TypeformResponse",
    {
        "response_id": str,
        "token": str,
        "response_type": str,  # "completed", "partial"
        "submitted_at": str,  # ISO 8601 timestamp
        "landed_at": Optional[str],  # ISO 8601 timestamp
        "answers": List[TypeformAnswer],
        "metadata": Optional[dict],  # User agent, platform, browser info
        "hidden": Optional[dict],  # Hidden fields
        "calculated": Optional[dict],  # Calculated scores
        "thankyou_screen_ref": Optional[str],
    },
    total=False,
)
