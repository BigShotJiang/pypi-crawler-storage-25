"""
Lark MCP Tools

Wraps Lark (Feishu) operations as FastMCP tools.
Authentication is handled transparently by LarkAuthManager — callers do NOT
pass an access token directly. The manager reads from the credential store,
auto-refreshes near-expiry tokens, and raises NeedsReauthError when a full
re-authentication is required.
"""

from __future__ import annotations

import asyncio
import time
from typing import Any, Dict, List, Optional

from fastmcp import FastMCP

# ── Messaging handlers ────────────────────────────────────────────────────────
from agents.tools.lark.messages_tools import (
    LarkSendMessageHandler,
    LarkChatHistoryHandler,
    LarkUpdateCardHandler,
    LarkListChatsHandler,
    LarkSearchUserAndSendMessageHandler,
    LarkReplyToMessageHandler,
    LarkReactToMessageHandler,
)

# ── User handlers ─────────────────────────────────────────────────────────────
from agents.tools.lark.user_tools import (
    LarkGetCurrentUserHandler,
    GetLarkUserHandler,
    LarkGetUserByIdHandler,
    LarkListDepartmentMembersHandler,
)

# ── Calendar / event handlers ─────────────────────────────────────────────────
from agents.tools.lark.event_tools import (
    LarkListEventsHandler,
    LarkSearchEventsHandler,
    LarkGetEventHandler,
    LarkCreateEventHandler,
    LarkUpdateEventHandler,
    LarkDeleteEventHandler,
)

# ── Document handlers ─────────────────────────────────────────────────────────
from agents.tools.lark.doc_tools import (
    LarkCreateDocHandler,
    LarkSearchDocHandler,
    LarkGetDocCommentsHandler,
    LarkAddDocCommentHandler,
    LarkGetDocumentContentHandler,
)

# ── File handlers ─────────────────────────────────────────────────────────────
from agents.tools.lark.file_tools import (
    LarkSearchFilesHandler,
    LarkGetFileMetadataHandler,
    LarkGetFolderInfoHandler,
    LarkMoveFileToFolderHandler,
    LarkListFolderHandler,
)

# ── Bitable handlers ──────────────────────────────────────────────────────────
from agents.tools.lark.base_tools import (
    LarkFetchTableData,
    LarkInsertTableData,
    LarkListBaseTablesHandler,
    LarkListBaseFieldsHandler,
    LarkUpdateBaseRecordHandler,
    LarkDeleteBaseRecordsHandler,
)

# ── Wiki handlers ─────────────────────────────────────────────────────────────
from agents.tools.lark.wiki_tools import (
    LarkWikiSearchHandler,
    LarkWikiGetNodeHandler,
    LarkWikiListSpacesHandler,
    LarkWikiListNodesHandler,
    LarkWikiGetSpaceHandler,
    LarkWikiGetSpaceByNameHandler,
    LarkWikiExtractDocxContentHandler,
    LarkWikiSearchAndExtractHandler,
)

# ── Sheet handlers ────────────────────────────────────────────────────────────
from agents.tools.lark.sheet_tools import (
    LarkReadSheetHandler,
    LarkWriteSheetHandler,
    LarkAppendSheetHandler,
)

# ── Task handlers ─────────────────────────────────────────────────────────────
from agents.tools.lark.task_tools import (
    LarkCreateTaskHandler,
    LarkListTasksHandler,
    LarkUpdateTaskHandler,
    LarkGetTaskHandler,
    LarkDeleteTaskHandler,
)

# ── Meeting handlers ──────────────────────────────────────────────────────────
from agents.tools.lark.meetings_tools import (
    LarkGetMeetingMinutesDirect,
    LarkGenerateSummaryFromMinutes,
    LarkMeetingToDocumentHandler,
    # DB-dependent — disabled until Supabase is wired:
    # LarkGetMinutesFromMeetingNumber,
    # LarkMeetingSummaryGenerator,
    # GetMeetingSummaryHandler,
)

from mcp_server.lark_auth_manager import NeedsReauthError, lark_auth_manager
from mcp_server.credential_store import _get_service, _set_service, _encrypt


def _token() -> str:
    """Return a valid Lark access token or raise a human-readable RuntimeError."""
    try:
        return lark_auth_manager.get_access_token()
    except NeedsReauthError as e:
        raise RuntimeError(
            f"Lark authentication required. Call lark_authenticate to get the OAuth URL. "
            f"Details: {e}"
        )


def register_lark_tools(mcp: FastMCP) -> None:
    """Register all Lark tools on the given FastMCP instance."""

    # ── Auth tools ────────────────────────────────────────────────────────────

    @mcp.tool
    def lark_authenticate() -> Dict[str, Any]:
        """Get the Lark OAuth URL to begin authentication, or confirm already authenticated.

        Returns:
            dict with 'authenticated' (bool). When False, includes 'oauth_url'.
            When True, includes token expiry info.
        """
        status = lark_auth_manager.auth_status()
        if status.get("authenticated"):
            return status
        return {
            "authenticated": False,
            "oauth_url": lark_auth_manager.get_oauth_url(),
            "message": "Visit the oauth_url to authenticate with Lark.",
        }

    @mcp.tool
    def lark_auth_status() -> Dict[str, Any]:
        """Return the current Lark authentication status without triggering a token refresh."""
        return lark_auth_manager.auth_status()

    @mcp.tool
    def lark_configure(app_id: str, app_secret: str) -> Dict[str, Any]:
        """Configure Lark app credentials (App ID and App Secret) for OAuth authentication.

        Args:
            app_id: Your Lark App ID (e.g., cli_xxxxxxxxxxxx).
            app_secret: Your Lark App Secret.
        """
        try:
            service_data = _get_service("lark")
            service_data["app_id"] = app_id
            service_data["app_secret"] = _encrypt(app_secret)
            _set_service("lark", service_data)
            return {"success": True, "message": "Lark credentials stored. Now call lark_authenticate."}
        except Exception as e:
            return {"success": False, "error": str(e)}

    @mcp.tool
    def lark_logout() -> Dict[str, Any]:
        """Clear stored Lark OAuth tokens, forcing re-authentication on next tool call."""
        lark_auth_manager.clear()
        return {"status": "logged_out", "message": "Tokens cleared. Call lark_authenticate to re-authenticate."}

    # ── Messaging tools ───────────────────────────────────────────────────────

    @mcp.tool
    async def lark_send_message(
        receive_id: str,
        content: str,
        receive_id_type: str = "open_id",
        is_card_message: bool = False,
        title: str = "",
        button_label: str = "",
    ) -> Dict[str, Any]:
        """Send a message to a Lark user or group chat.

        Args:
            receive_id: Recipient ID (user or group).
            content: Message text content.
            receive_id_type: 'open_id', 'user_id', 'email', or 'chat_id'. Default 'open_id'.
            is_card_message: If True, sends as interactive card message.
            title: Card title (card messages only).
            button_label: Card button label (card messages only).
        """
        try:
            return await LarkSendMessageHandler().execute(
                receive_id=receive_id, content=content,
                receive_id_type=receive_id_type, is_card_message=is_card_message,
                title=title, button_label=button_label,
            )
        except Exception as e:
            return {"error": str(e)}

    @mcp.tool
    async def lark_list_chats() -> Dict[str, Any]:
        """List all Lark chat groups the authenticated user is a member of."""
        try:
            return await LarkListChatsHandler().execute(access_token=_token())
        except Exception as e:
            return {"error": str(e)}

    @mcp.tool
    async def lark_get_chat_history(query: str = "") -> Dict[str, Any]:
        """Retrieve Lark chat group history, optionally filtered by name.

        Searches for a chat group matching the query using the authenticated user's
        token, then reads its messages as the bot. If the bot is not a member of the
        matched chat, it will be automatically added before reading — this is an
        intentional side effect required for the bot to access message history.

        Args:
            query: Optional search string to find a specific chat group by name.
        """
        try:
            return await LarkChatHistoryHandler().execute(access_token=_token(), query=query)
        except Exception as e:
            return {"error": str(e)}

    @mcp.tool
    async def lark_send_batch_messages(
        recipients: List[str],
        content: str,
        receive_id_type: str = "open_id",
        is_card_message: bool = False,
        title: str = "",
        button_label: str = "",
    ) -> Dict[str, Any]:
        """Send the same message to multiple Lark users or groups.

        Args:
            recipients: List of recipient IDs (matching receive_id_type).
            content: Message text content.
            receive_id_type: 'open_id', 'user_id', 'email', or 'chat_id'. Default 'open_id'.
            is_card_message: If True, sends as interactive card message.
            title: Card title (card messages only).
            button_label: Card button label (card messages only).
        """
        handler = LarkSendMessageHandler()
        results, sent, failed = [], 0, 0
        for receive_id in recipients:
            try:
                result = await handler.execute(
                    receive_id=receive_id, content=content,
                    receive_id_type=receive_id_type, is_card_message=is_card_message,
                    title=title, button_label=button_label,
                )
                results.append({"receive_id": receive_id, "result": result})
                failed += 1 if "error" in result else 0
                sent += 0 if "error" in result else 1
            except Exception as e:
                results.append({"receive_id": receive_id, "result": {"error": str(e)}})
                failed += 1
        return {
            "content": f"Batch send complete: {sent} sent, {failed} failed.",
            "metadata": {"sent": sent, "failed": failed, "results": results},
        }

    @mcp.tool
    async def lark_update_card(message_id: str, content: str) -> Dict[str, Any]:
        """Update an existing Lark interactive card message.

        Args:
            message_id: The ID of the card message to update.
            content: New card content (JSON string or plain text).
        """
        try:
            return await LarkUpdateCardHandler().execute(message_id=message_id, content=content)
        except Exception as e:
            return {"error": str(e)}

    @mcp.tool
    async def lark_reply_to_message(
        message_id: str,
        content: str,
        reply_in_thread: bool = False,
    ) -> Dict[str, Any]:
        """Reply to an existing Lark message (optionally threaded).

        Args:
            message_id: The message ID to reply to.
            content: The reply text content.
            reply_in_thread: If True, creates a threaded reply. Default False.
        """
        try:
            return await LarkReplyToMessageHandler().execute(
                message_id=message_id, content=content, reply_in_thread=reply_in_thread
            )
        except Exception as e:
            return {"error": str(e)}

    @mcp.tool
    async def lark_react_to_message(
        message_id: str,
        emoji_type: str = "THUMBSUP",
    ) -> Dict[str, Any]:
        """Add an emoji reaction to a Lark message.

        Args:
            message_id: The message ID to react to.
            emoji_type: Emoji type string e.g. 'THUMBSUP', 'OK', 'SMILE', 'CLAP'. Default 'THUMBSUP'.
        """
        try:
            return await LarkReactToMessageHandler().execute(
                message_id=message_id, emoji_type=emoji_type
            )
        except Exception as e:
            return {"error": str(e)}

    @mcp.tool
    async def lark_message_user_by_name(
        user_name: str,
        message_content: str,
        is_card_message: bool = False,
        title: str = "",
        button_label: str = "",
    ) -> Dict[str, Any]:
        """Search for a Lark user by name and send them a message in one call.

        Args:
            user_name: Display name (or partial name) to search for in org directory.
            message_content: Message text to send.
            is_card_message: If True, sends as interactive card message.
            title: Card title (card messages only).
            button_label: Card button label (card messages only).
        """
        try:
            return await LarkSearchUserAndSendMessageHandler().execute(
                user_name=user_name,
                message_content=message_content, is_card_message=is_card_message,
                title=title, button_label=button_label,
            )
        except Exception as e:
            return {"error": str(e)}

    # ── User tools ────────────────────────────────────────────────────────────

    @mcp.tool
    async def lark_get_current_user() -> Dict[str, Any]:
        """Get the Lark profile of the currently authenticated user."""
        try:
            return await LarkGetCurrentUserHandler().execute(access_token=_token())
        except Exception as e:
            return {"error": str(e)}

    @mcp.tool
    async def lark_search_users(query: str) -> Dict[str, Any]:
        """Search for Lark users by name or email.

        Args:
            query: Name or email fragment to search for.
        """
        try:
            return await GetLarkUserHandler().execute(query=query)
        except Exception as e:
            return {"error": str(e)}

    @mcp.tool
    async def lark_get_user_by_id(
        user_id: str,
        id_type: str = "open_id",
    ) -> Dict[str, Any]:
        """Get a full Lark user profile by open_id or user_id.

        Args:
            user_id: The user's open_id (or user_id if id_type is 'user_id').
            id_type: 'open_id' (default) or 'user_id'.
        """
        try:
            return await LarkGetUserByIdHandler().execute(user_id=user_id, id_type=id_type)
        except Exception as e:
            return {"error": str(e)}

    @mcp.tool
    async def lark_list_department_members(
        department_id: str,
        page_size: int = 50,
    ) -> Dict[str, Any]:
        """List all members of a Lark department.

        Args:
            department_id: The open_department_id of the department.
            page_size: Maximum number of members to return. Default 50.
        """
        try:
            return await LarkListDepartmentMembersHandler().execute(
                department_id=department_id, page_size=page_size
            )
        except Exception as e:
            return {"error": str(e)}

    # ── Calendar tools ────────────────────────────────────────────────────────

    @mcp.tool
    async def lark_list_events(
        anchor_time: Optional[int] = None,
        query: str = "",
    ) -> Dict[str, Any]:
        """List upcoming Lark calendar events from an anchor timestamp.

        Args:
            anchor_time: Unix timestamp to list events from. Defaults to now.
            query: Optional string to filter events by summary.
        """
        try:
            return await LarkListEventsHandler().execute(
                access_token=_token(),
                anchor_time=anchor_time if anchor_time is not None else int(time.time()),
                query=query,
            )
        except Exception as e:
            return {"error": str(e)}

    @mcp.tool
    async def lark_search_events(
        query: str,
        start_time: Optional[str] = None,
        end_time: Optional[str] = None,
    ) -> Dict[str, Any]:
        """Search for Lark calendar events by keyword and optional date range.

        Args:
            query: Keyword to search events by title/summary.
            start_time: ISO date string for range start (e.g. '2026-04-01').
            end_time: ISO date string for range end (e.g. '2026-04-30').
        """
        try:
            return await LarkSearchEventsHandler().execute(
                access_token=_token(), query=query, start_time=start_time, end_time=end_time
            )
        except Exception as e:
            return {"error": str(e)}

    @mcp.tool
    async def lark_get_event(
        event_id: str,
        extracted_keys: Optional[List[str]] = None,
    ) -> Dict[str, Any]:
        """Get details for a specific Lark calendar event.

        Args:
            event_id: The unique identifier of the event.
            extracted_keys: Optional list of keys to extract (e.g. ['vc_url', 'attendees']).
        """
        try:
            return await LarkGetEventHandler().execute(
                access_token=_token(), event_id=event_id, extracted_keys=extracted_keys or []
            )
        except Exception as e:
            return {"error": str(e)}

    @mcp.tool
    async def lark_create_event(
        summary: str,
        start_time: str,
        end_time: str,
        description: str = "",
        attendee_ids: Optional[List[str]] = None,
    ) -> Dict[str, Any]:
        """Create a new Lark calendar event.

        Args:
            summary: Event title.
            start_time: Unix timestamp string for event start (e.g. '1761338478').
            end_time: Unix timestamp string for event end.
            description: Optional event description.
            attendee_ids: Optional list of attendee open_ids to invite.
        """
        try:
            return await LarkCreateEventHandler().execute(
                access_token=_token(), summary=summary, start_time=start_time,
                end_time=end_time, description=description, attendee_ids=attendee_ids or [],
            )
        except Exception as e:
            return {"error": str(e)}

    @mcp.tool
    async def lark_update_event(
        event_id: str,
        updates: Dict[str, Any],
    ) -> Dict[str, Any]:
        """Update an existing Lark calendar event.

        Args:
            event_id: The event ID to update.
            updates: Dict of fields to update, e.g. {'summary': 'New Title'}.
        """
        try:
            return await LarkUpdateEventHandler().execute(
                access_token=_token(), event_id=event_id, updates=updates
            )
        except Exception as e:
            return {"error": str(e)}

    @mcp.tool
    async def lark_delete_event(event_id: str) -> Dict[str, Any]:
        """Delete a Lark calendar event.

        Args:
            event_id: The event ID to delete.
        """
        try:
            return await LarkDeleteEventHandler().execute(access_token=_token(), event_id=event_id)
        except Exception as e:
            return {"error": str(e)}

    # ── Document tools ────────────────────────────────────────────────────────

    @mcp.tool
    async def lark_create_document(
        title: str,
        content: str,
        folder_token: str = "",
    ) -> Dict[str, Any]:
        """Create a new Lark document with the given title and content.

        Args:
            title: Document title.
            content: Document body text (markdown-style formatting supported).
            folder_token: Token of the folder to create the document in. Defaults to root.
        """
        try:
            return await LarkCreateDocHandler().execute(
                access_token=_token(), title=title, content=content, folder_token=folder_token
            )
        except Exception as e:
            return {"error": str(e)}

    @mcp.tool
    async def lark_search_documents(
        search_key: str,
        owner_ids: Optional[List[str]] = None,
        docs_types: Optional[List[str]] = None,
    ) -> Dict[str, Any]:
        """Search for Lark documents by keyword.

        Args:
            search_key: Search keyword.
            owner_ids: Optional list of owner IDs to filter results.
            docs_types: Optional list of document types (e.g. ['file', 'docx', 'doc']). Default ['file'].
        """
        try:
            return await LarkSearchDocHandler().execute(
                access_token=_token(), search_key=search_key,
                owner_ids=owner_ids or [], docs_types=docs_types or ["file"],
            )
        except Exception as e:
            return {"error": str(e)}

    @mcp.tool
    async def lark_get_document_content(
        doc_token: str,
        format: str = "raw",
    ) -> Dict[str, Any]:
        """Read the full text content of a Lark document.

        Args:
            doc_token: The document token (ID).
            format: 'raw' for plain text (default) or 'markdown' for Markdown format.
        """
        try:
            return await LarkGetDocumentContentHandler().execute(
                access_token=_token(), doc_token=doc_token, format=format
            )
        except Exception as e:
            return {"error": str(e)}

    @mcp.tool
    async def lark_get_doc_comments(
        doc_token: str,
        doc_type: str = "docx",
    ) -> Dict[str, Any]:
        """List all comments on a Lark document.

        Args:
            doc_token: The document token (ID).
            doc_type: 'docx' or 'doc'. Default 'docx'.
        """
        try:
            return await LarkGetDocCommentsHandler().execute(
                access_token=_token(), doc_token=doc_token, doc_type=doc_type
            )
        except Exception as e:
            return {"error": str(e)}

    @mcp.tool
    async def lark_add_doc_comment(
        doc_token: str,
        content: str,
        doc_type: str = "docx",
    ) -> Dict[str, Any]:
        """Add a comment to a Lark document.

        Args:
            doc_token: The document token (ID).
            content: The comment text to add.
            doc_type: 'docx' or 'doc'. Default 'docx'.
        """
        try:
            return await LarkAddDocCommentHandler().execute(
                access_token=_token(), doc_token=doc_token, content=content, doc_type=doc_type
            )
        except Exception as e:
            return {"error": str(e)}

    # ── Files tools ───────────────────────────────────────────────────────────

    @mcp.tool
    async def lark_search_files(
        search_key: str,
        object_types: Optional[List[str]] = None,
        owner_ids: Optional[List[str]] = None,
    ) -> Dict[str, Any]:
        """Search for files in Lark Drive by keyword.

        Args:
            search_key: Keyword to search file names.
            object_types: List of file types (e.g. ['file', 'doc', 'docx']). Default all types.
            owner_ids: Optional list of owner IDs to restrict results.
        """
        try:
            return await LarkSearchFilesHandler().execute(
                access_token=_token(), search_key=search_key,
                object_types=object_types or ["file", "doc", "docx"], owner_ids=owner_ids,
            )
        except Exception as e:
            return {"error": str(e)}

    @mcp.tool
    async def lark_get_file_metadata(
        file_token: str,
        doc_type: str = "file",
    ) -> Dict[str, Any]:
        """Get metadata (URL, name, owner) for a Lark Drive file.

        Args:
            file_token: The file token (doc_token).
            doc_type: 'file', 'doc', 'docx', 'sheet', 'bitable', 'pdf'. Default 'file'.
        """
        try:
            return await LarkGetFileMetadataHandler().execute(
                access_token=_token(), file_token=file_token, doc_type=doc_type
            )
        except Exception as e:
            return {"error": str(e)}

    @mcp.tool
    async def lark_get_folder_info(folder_token: str) -> Dict[str, Any]:
        """Get metadata for a Lark Drive folder.

        Args:
            folder_token: The folder token.
        """
        try:
            return await LarkGetFolderInfoHandler().execute(
                access_token=_token(), folder_token=folder_token
            )
        except Exception as e:
            return {"error": str(e)}

    @mcp.tool
    async def lark_list_folder(
        folder_token: Optional[str] = None,
        page_size: int = 50,
    ) -> Dict[str, Any]:
        """List files in a Lark Drive folder.

        Args:
            folder_token: The folder token to list. Omit to list the root folder.
            page_size: Maximum number of files to return. Default 50.
        """
        try:
            return await LarkListFolderHandler().execute(
                access_token=_token(), folder_token=folder_token, page_size=page_size
            )
        except Exception as e:
            return {"error": str(e)}

    @mcp.tool
    async def lark_move_file(
        file_token: str,
        target_folder_token: str,
        file_type: str = "docx",
    ) -> Dict[str, Any]:
        """Move a Lark Drive file to a different folder.

        Args:
            file_token: The token of the file to move.
            target_folder_token: The destination folder token.
            file_type: 'file', 'docx', 'doc', 'sheet'. Default 'docx'.
        """
        try:
            return await LarkMoveFileToFolderHandler().execute(
                access_token=_token(), file_token=file_token,
                target_folder_token=target_folder_token, file_type=file_type,
            )
        except Exception as e:
            return {"error": str(e)}

    # ── Bitable tools ─────────────────────────────────────────────────────────

    @mcp.tool
    async def lark_fetch_base_records(
        app_name: str,
        table_name: str,
        field_names: Optional[List[str]] = None,
        sort: Optional[List[Dict[str, Any]]] = None,
        filters: Optional[List[Dict[str, Any]]] = None,
    ) -> Dict[str, Any]:
        """Fetch records from a Lark Bitable (Base) table.

        Args:
            app_name: Name of the Lark Base app to search for.
            table_name: Name of the table within the app.
            field_names: Optional list of field names to return. Returns all if omitted.
            sort: Optional sort conditions (e.g. [{'field_name': 'Name', 'desc': False}]).
            filters: Optional filter conditions (e.g. [{'field_name': 'Status', 'operator': 'is', 'value': ['Active']}]).
        """
        try:
            return await LarkFetchTableData().execute(
                access_token=_token(), app_name=app_name, table_name=table_name,
                field_names=field_names, sort=sort, filters=filters,
            )
        except Exception as e:
            return {"error": str(e)}

    @mcp.tool
    async def lark_insert_base_records(
        app_id: str,
        table_id: str,
        data: Any,
    ) -> Dict[str, Any]:
        """Insert one or more records into a Lark Bitable table.

        Args:
            app_id: The Bitable app ID.
            table_id: The table ID within the app.
            data: Record data — single dict or list of dicts of field values.
        """
        try:
            return await LarkInsertTableData().execute(
                access_token=_token(), app_id=app_id, table_id=table_id, data=data
            )
        except Exception as e:
            return {"error": str(e)}

    @mcp.tool
    async def lark_update_base_record(
        app_id: str,
        table_id: str,
        record_id: str,
        fields: Dict[str, Any],
    ) -> Dict[str, Any]:
        """Update a single record in a Lark Bitable table.

        Args:
            app_id: The Bitable app ID.
            table_id: The table ID.
            record_id: The record ID to update.
            fields: Dict of field names → new values.
        """
        try:
            return await LarkUpdateBaseRecordHandler().execute(
                access_token=_token(), app_id=app_id, table_id=table_id,
                record_id=record_id, fields=fields,
            )
        except Exception as e:
            return {"error": str(e)}

    @mcp.tool
    async def lark_delete_base_records(
        app_id: str,
        table_id: str,
        record_ids: List[str],
    ) -> Dict[str, Any]:
        """Batch delete records from a Lark Bitable table.

        Args:
            app_id: The Bitable app ID.
            table_id: The table ID.
            record_ids: List of record IDs to delete.
        """
        try:
            return await LarkDeleteBaseRecordsHandler().execute(
                access_token=_token(), app_id=app_id, table_id=table_id, record_ids=record_ids
            )
        except Exception as e:
            return {"error": str(e)}

    @mcp.tool
    async def lark_list_base_tables(app_id: str) -> Dict[str, Any]:
        """List all tables in a Lark Bitable app.

        Args:
            app_id: The Bitable app ID.
        """
        try:
            return await LarkListBaseTablesHandler().execute(access_token=_token(), app_id=app_id)
        except Exception as e:
            return {"error": str(e)}

    @mcp.tool
    async def lark_list_base_fields(
        app_id: str,
        table_id: str,
    ) -> Dict[str, Any]:
        """List all fields (schema) in a Lark Bitable table.

        Args:
            app_id: The Bitable app ID.
            table_id: The table ID to inspect.
        """
        try:
            return await LarkListBaseFieldsHandler().execute(
                access_token=_token(), app_id=app_id, table_id=table_id
            )
        except Exception as e:
            return {"error": str(e)}

    # ── Wiki tools ────────────────────────────────────────────────────────────

    @mcp.tool
    async def lark_search_wiki(
        query: str,
        space_id: str = "",
        node_id: str = "",
        page_size: int = 50,
    ) -> Dict[str, Any]:
        """Search for nodes across Lark Wiki spaces.

        Args:
            query: Search keyword.
            space_id: Optional wiki space ID to scope the search.
            node_id: Optional parent node ID to scope the search.
            page_size: Maximum number of results. Default 50.
        """
        try:
            return await LarkWikiSearchHandler().execute(
                access_token=_token(), query=query,
                space_id=space_id, node_id=node_id, page_size=page_size,
            )
        except Exception as e:
            return {"error": str(e)}

    @mcp.tool
    async def lark_get_wiki_node(node_token: str) -> Dict[str, Any]:
        """Get details of a specific Lark Wiki node.

        Args:
            node_token: The unique token of the wiki node.
        """
        try:
            return await LarkWikiGetNodeHandler().execute(access_token=_token(), node_token=node_token)
        except Exception as e:
            return {"error": str(e)}

    @mcp.tool
    async def lark_list_wiki_spaces(page_size: int = 50) -> Dict[str, Any]:
        """List all Lark Wiki spaces the authenticated user has access to.

        Args:
            page_size: Maximum number of spaces to return. Default 50.
        """
        try:
            return await LarkWikiListSpacesHandler().execute(access_token=_token(), page_size=page_size)
        except Exception as e:
            return {"error": str(e)}

    @mcp.tool
    async def lark_get_wiki_space(space_id: str) -> Dict[str, Any]:
        """Get details of a specific Lark Wiki space.

        Args:
            space_id: The space ID.
        """
        try:
            return await LarkWikiGetSpaceHandler().execute(access_token=_token(), space_id=space_id)
        except Exception as e:
            return {"error": str(e)}

    @mcp.tool
    async def lark_list_wiki_nodes(
        space_id: str,
        page_size: int = 50,
    ) -> Dict[str, Any]:
        """List all nodes in a Lark Wiki space.

        Args:
            space_id: The wiki space ID.
            page_size: Maximum number of nodes to return. Default 50.
        """
        try:
            return await LarkWikiListNodesHandler().execute(
                access_token=_token(), space_id=space_id, page_size=page_size
            )
        except Exception as e:
            return {"error": str(e)}

    @mcp.tool
    async def lark_get_wiki_space_by_name(
        space_name: str,
        node_name: str,
    ) -> Dict[str, Any]:
        """Find a wiki space by name, locate a node within it, and extract its children content.

        Args:
            space_name: The display name of the wiki space.
            node_name: The display name of the parent node to look under.
        """
        try:
            return await LarkWikiGetSpaceByNameHandler().execute(
                access_token=_token(), space_name=space_name, node_name=node_name
            )
        except Exception as e:
            return {"error": str(e)}

    @mcp.tool
    async def lark_extract_wiki_doc_content(
        space_id: str,
        query: str = "",
        extract_all_nodes: bool = False,
        page_size: int = 50,
    ) -> Dict[str, Any]:
        """Extract markdown content from docx-type wiki nodes.

        Args:
            space_id: The wiki space ID to search within.
            query: Search keyword to find specific nodes. If empty, use extract_all_nodes.
            extract_all_nodes: If True (and query is empty), extract all docx nodes in space.
            page_size: Maximum number of nodes to process. Default 50.
        """
        try:
            return await LarkWikiExtractDocxContentHandler().execute(
                access_token=_token(), space_id=space_id, query=query,
                extract_all_nodes=extract_all_nodes, page_size=page_size,
            )
        except Exception as e:
            return {"error": str(e)}

    @mcp.tool
    async def lark_wiki_search_and_extract(
        query: str,
        space_id: str = "",
        include_subnodes: bool = True,
        page_size: int = 50,
    ) -> Dict[str, Any]:
        """Search wiki nodes and extract markdown content from docx-type results.

        Args:
            query: Search keyword.
            space_id: Optional wiki space ID to scope the search.
            include_subnodes: If True, also extract content from child nodes. Default True.
            page_size: Maximum number of results. Default 50.
        """
        try:
            return await LarkWikiSearchAndExtractHandler().execute(
                access_token=_token(), query=query, space_id=space_id,
                include_subnodes=include_subnodes, page_size=page_size,
            )
        except Exception as e:
            return {"error": str(e)}

    # ── Sheet tools ───────────────────────────────────────────────────────────

    @mcp.tool
    async def lark_read_sheet(
        spreadsheet_token: str,
        range: str,
    ) -> Dict[str, Any]:
        """Read cell values from a Lark Spreadsheet range.

        Args:
            spreadsheet_token: The unique token of the spreadsheet.
            range: A1-notation range to read (e.g. 'Sheet1!A1:D10').
        """
        try:
            return await LarkReadSheetHandler().execute(
                access_token=_token(), spreadsheet_token=spreadsheet_token, range=range
            )
        except Exception as e:
            return {"error": str(e)}

    @mcp.tool
    async def lark_write_sheet(
        spreadsheet_token: str,
        range: str,
        values: List[List[Any]],
    ) -> Dict[str, Any]:
        """Write values to a Lark Spreadsheet range (overwrites existing data).

        Args:
            spreadsheet_token: The unique token of the spreadsheet.
            range: A1-notation range to write to (e.g. 'Sheet1!A1:D3').
            values: 2D list of values to write (rows × columns).
        """
        try:
            return await LarkWriteSheetHandler().execute(
                access_token=_token(), spreadsheet_token=spreadsheet_token,
                range=range, values=values,
            )
        except Exception as e:
            return {"error": str(e)}

    @mcp.tool
    async def lark_append_sheet(
        spreadsheet_token: str,
        range: str,
        values: List[List[Any]],
    ) -> Dict[str, Any]:
        """Append rows to a Lark Spreadsheet after the last row with data.

        Args:
            spreadsheet_token: The unique token of the spreadsheet.
            range: A1-notation anchor range (e.g. 'Sheet1!A1').
            values: 2D list of values to append (rows × columns).
        """
        try:
            return await LarkAppendSheetHandler().execute(
                access_token=_token(), spreadsheet_token=spreadsheet_token,
                range=range, values=values,
            )
        except Exception as e:
            return {"error": str(e)}

    # ── Task tools ────────────────────────────────────────────────────────────

    @mcp.tool
    async def lark_create_task(
        summary: str,
        description: str = "",
        due_timestamp: Optional[str] = None,
        assignee_ids: Optional[List[str]] = None,
    ) -> Dict[str, Any]:
        """Create a new task in Lark Tasks.

        Args:
            summary: Short title of the task.
            description: Detailed description. Default empty string.
            due_timestamp: Unix timestamp string for due date (e.g. '1761338478').
            assignee_ids: List of Lark user open_ids to assign the task to.
        """
        try:
            return await LarkCreateTaskHandler().execute(
                access_token=_token(), summary=summary, description=description,
                due_timestamp=due_timestamp, assignee_ids=assignee_ids or [],
            )
        except Exception as e:
            return {"error": str(e)}

    @mcp.tool
    async def lark_list_tasks(
        completed: Optional[bool] = None,
        page_size: int = 50,
    ) -> Dict[str, Any]:
        """List tasks from Lark Tasks, with optional completion filter.

        Args:
            completed: True for completed tasks, False for incomplete, None for all.
            page_size: Maximum number of tasks to return. Default 50.
        """
        try:
            return await LarkListTasksHandler().execute(
                access_token=_token(), completed=completed, page_size=page_size
            )
        except Exception as e:
            return {"error": str(e)}

    @mcp.tool
    async def lark_get_task(task_guid: str) -> Dict[str, Any]:
        """Get a single Lark task by its GUID.

        Args:
            task_guid: The unique GUID of the task.
        """
        try:
            return await LarkGetTaskHandler().execute(access_token=_token(), task_guid=task_guid)
        except Exception as e:
            return {"error": str(e)}

    @mcp.tool
    async def lark_update_task(
        task_guid: str,
        summary: Optional[str] = None,
        description: Optional[str] = None,
        completed_at: Optional[str] = None,
        due_timestamp: Optional[str] = None,
    ) -> Dict[str, Any]:
        """Update an existing Lark task.

        Args:
            task_guid: The unique GUID of the task to update.
            summary: New title (None to keep existing).
            description: New description (None to keep existing).
            completed_at: Unix timestamp string to mark complete. Pass '0' to re-open.
            due_timestamp: New due date as Unix timestamp string.
        """
        try:
            return await LarkUpdateTaskHandler().execute(
                access_token=_token(), task_guid=task_guid, summary=summary,
                description=description, completed_at=completed_at, due_timestamp=due_timestamp,
            )
        except Exception as e:
            return {"error": str(e)}

    @mcp.tool
    async def lark_delete_task(task_guid: str) -> Dict[str, Any]:
        """Delete a Lark task permanently.

        Args:
            task_guid: The unique GUID of the task to delete.
        """
        try:
            return await LarkDeleteTaskHandler().execute(access_token=_token(), task_guid=task_guid)
        except Exception as e:
            return {"error": str(e)}

    # ── Meeting tools ─────────────────────────────────────────────────────────

    @mcp.tool
    async def lark_get_meeting_minutes(
        meeting_number: str,
        start_time: float = 0,
        end_time: float = 0,
    ) -> Dict[str, Any]:
        """Fetch transcript minutes for a Lark meeting directly from the Lark API.

        Returns meeting metadata and the minutes URL for each matching meeting.
        Pass the returned minutes_url to lark_summarize_from_minutes_url to get an AI summary.
        No database required.

        Args:
            meeting_number: The Lark meeting number (last segment of the meeting URL).
            start_time: Optional Unix timestamp lower bound for the search window.
            end_time: Optional Unix timestamp upper bound (defaults to now).
        """
        try:
            kwargs: Dict[str, Any] = {"access_token": _token(), "meeting_number": meeting_number}
            if start_time:
                kwargs["start_time"] = start_time
            if end_time:
                kwargs["end_time"] = end_time
            return await LarkGetMeetingMinutesDirect().execute(**kwargs)
        except Exception as e:
            return {"error": str(e)}

    @mcp.tool
    async def lark_summarize_meeting_by_number(
        meeting_number: str,
        template: str = "",
        contexts: str = "",
    ) -> Dict[str, Any]:
        """Fetch meeting transcript and generate an AI summary in one step. No database required.

        Internally calls lark_get_meeting_minutes to get the transcript URL, then
        generates the summary with the same LLM pipeline as lark_summarize_from_minutes_url.

        Args:
            meeting_number: The Lark meeting number (last segment of the meeting URL).
            template: Optional summary template to guide the output structure.
            contexts: Optional additional context (e.g. past notes) to enrich the summary.
        """
        try:
            token = _token()
            minutes_result = await LarkGetMeetingMinutesDirect().execute(
                access_token=token, meeting_number=meeting_number
            )
            if minutes_result.get("error"):
                return minutes_result
            meetings = minutes_result.get("metadata", {}).get("meetings", [])
            if not meetings:
                return {"error": "No meetings found for that meeting number"}
            url = meetings[0].get("minutes_url", "")
            if not url:
                return {"error": "No transcript URL found for this meeting"}
            return await LarkGenerateSummaryFromMinutes().execute(
                access_token=token, url=url, template=template, contexts=contexts
            )
        except Exception as e:
            return {"error": str(e)}

    @mcp.tool
    async def lark_summarize_from_minutes_url(
        url: str,
        template: str = "",
        contexts: str = "",
    ) -> Dict[str, Any]:
        """Generate an AI meeting summary directly from a Lark minutes/transcript URL.

        Args:
            url: The Lark minutes URL (e.g. https://meetings.larksuite.com/minutes/xxx).
            template: Optional summary template to guide the output structure.
            contexts: Optional additional context (e.g. past notes) to enrich the summary.
        """
        try:
            return await LarkGenerateSummaryFromMinutes().execute(
                access_token=_token(), url=url, template=template, contexts=contexts
            )
        except Exception as e:
            return {"error": str(e)}

    @mcp.tool
    async def lark_meeting_to_document(
        content: str,
        permission_list: Optional[List[Dict[str, Any]]] = None,
    ) -> Dict[str, Any]:
        """Create a Lark document from meeting notes content and optionally share it.

        Args:
            content: Meeting notes text (markdown supported).
            permission_list: Optional list of permission dicts, each with
                'user_id', 'permission_type' ('view'|'edit'), and 'need_notification' (bool).
        """
        try:
            return await LarkMeetingToDocumentHandler().execute(
                access_token=_token(), content=content, permission_list=permission_list or []
            )
        except Exception as e:
            return {"error": str(e)}

    # lark_get_stored_meeting_summaries — DISABLED
    # Reads from the Supabase `meetings` + `meeting_types` tables and decrypts
    # 1-1 summaries with THOUGHTFLOW_PRIVATE_KEY.  No DB-free equivalent exists
    # (stored summaries have no Lark API counterpart).  Re-enable once Supabase
    # is wired to this MCP server.

    # ── Compound / workflow tools ─────────────────────────────────────────────

    @mcp.tool
    async def lark_daily_digest(send_to_self: bool = False) -> Dict[str, Any]:
        """Fetch today's events and open tasks and return a combined digest.

        Lists upcoming events from now and all incomplete tasks, then combines
        them into a structured summary. Optionally sends the digest to yourself.

        Args:
            send_to_self: If True, sends the digest as a Lark message to the authenticated user.
        """
        try:
            token = _token()
            events_result = await LarkListEventsHandler().execute(
                access_token=token, anchor_time=int(time.time()), query=""
            )
            tasks_result = await LarkListTasksHandler().execute(
                access_token=token, completed=False, page_size=20
            )
            events = events_result.get("metadata", {}).get("events", [])
            tasks = tasks_result.get("metadata", {}).get("tasks", [])

            lines = ["*Daily Digest*\n"]
            lines.append(f"*Upcoming events ({len(events)}):*")
            for e in events[:10]:
                ts = e.get("start_time", {}).get("timestamp", "?")
                lines.append(f"  - {e.get('summary', 'Untitled')} @ {ts}")
            lines.append(f"\n*Open tasks ({len(tasks)}):*")
            for t in tasks[:10]:
                lines.append(f"  - {t.get('summary', 'Untitled')}")

            digest_text = "\n".join(lines)

            if send_to_self:
                user_result = await LarkGetCurrentUserHandler().execute(access_token=token)
                user_id = user_result.get("metadata", {}).get("user", {}).get("open_id", "")
                if user_id:
                    await LarkSendMessageHandler().execute(
                        receive_id=user_id, receive_id_type="open_id", content=digest_text
                    )

            return {"content": digest_text, "metadata": {"events": events, "tasks": tasks}}
        except Exception as e:
            return {"error": str(e)}

    @mcp.tool
    async def lark_notify_department(
        department_id: str,
        message: str,
        is_card_message: bool = False,
        title: str = "",
    ) -> Dict[str, Any]:
        """Send a message to all members of a Lark department.

        Fetches all department members then batch-sends the message to each one.

        Args:
            department_id: The open_department_id of the department.
            message: The message text content to send.
            is_card_message: If True, sends as interactive card message.
            title: Card title (card messages only).
        """
        try:
            members_result = await LarkListDepartmentMembersHandler().execute(
                department_id=department_id, page_size=100
            )
            members = members_result.get("metadata", {}).get("members", [])
            if not members:
                return {"error": f"No members found in department '{department_id}'."}

            open_ids = [m.get("open_id", "") for m in members if m.get("open_id")]
            handler = LarkSendMessageHandler()
            sent, failed, results = 0, 0, []
            for oid in open_ids:
                res = await handler.execute(
                    receive_id=oid, receive_id_type="open_id",
                    content=message, is_card_message=is_card_message, title=title,
                )
                results.append({"open_id": oid, "result": res})
                if "error" in res:
                    failed += 1
                else:
                    sent += 1

            return {
                "content": f"Department notification complete: {sent} sent, {failed} failed.",
                "metadata": {"sent": sent, "failed": failed, "member_count": len(open_ids), "results": results},
            }
        except Exception as e:
            return {"error": str(e)}

    @mcp.tool
    async def lark_base_upsert_records(
        app_id: str,
        table_id: str,
        records: List[Dict[str, Any]],
        match_field: str,
    ) -> Dict[str, Any]:
        """Upsert records into a Lark Bitable table — update if match found, insert otherwise.

        Args:
            app_id: The Bitable app ID.
            table_id: The table ID.
            records: List of record dicts (field → value) to upsert.
            match_field: Field name used to identify existing records (e.g. 'Email').
        """
        try:
            from connectors.lark_interactions.base import LarkBaseTable
            token = _token()
            table = LarkBaseTable(is_auth=True, access_token=token)

            existing = await asyncio.to_thread(
                table.search_records, app_id, table_id, [match_field], None, None
            )
            existing_map = {r.get(match_field, ""): r.get("id", "") for r in existing}

            updated, inserted = 0, 0
            for rec in records:
                key = rec.get(match_field, "")
                if key and key in existing_map:
                    await asyncio.to_thread(
                        table.update_record, app_id, table_id, existing_map[key], {"fields": rec}
                    )
                    updated += 1
                else:
                    await asyncio.to_thread(table.insert, app_id, table_id, [{"fields": rec}])
                    inserted += 1

            return {
                "content": f"Upsert complete: {updated} updated, {inserted} inserted.",
                "metadata": {"updated": updated, "inserted": inserted},
            }
        except Exception as e:
            return {"error": str(e)}

    @mcp.tool
    async def lark_create_event_with_agenda(
        summary: str,
        start_time: str,
        end_time: str,
        agenda: str,
        attendee_ids: Optional[List[str]] = None,
        notify_attendees: bool = True,
    ) -> Dict[str, Any]:
        """Create a calendar event, generate an agenda document, and notify attendees.

        Steps: (1) creates the event, (2) creates an agenda doc, (3) optionally messages attendees.

        Args:
            summary: Event title.
            start_time: Unix timestamp string for event start.
            end_time: Unix timestamp string for event end.
            agenda: Markdown text for the agenda document.
            attendee_ids: List of attendee open_ids.
            notify_attendees: If True, messages each attendee with the agenda link. Default True.
        """
        try:
            token = _token()
            attendees = attendee_ids or []

            event_result = await LarkCreateEventHandler().execute(
                access_token=token, summary=summary,
                start_time=start_time, end_time=end_time, attendee_ids=attendees,
            )
            doc_result = await LarkCreateDocHandler().execute(
                access_token=token, title=f"Agenda: {summary}", content=agenda, folder_token=""
            )
            doc_url = doc_result.get("metadata", {}).get("document_url", "")

            notifications = []
            if notify_attendees and doc_url and attendees:
                msg = f"You're invited to: *{summary}*\n\nAgenda: {doc_url}"
                handler = LarkSendMessageHandler()
                for oid in attendees:
                    res = await handler.execute(
                        receive_id=oid, receive_id_type="open_id", content=msg
                    )
                    notifications.append({"open_id": oid, "result": res})

            return {
                "content": f"Event '{summary}' created with agenda and {len(notifications)} attendees notified.",
                "metadata": {
                    "event": event_result.get("metadata", {}).get("event", {}),
                    "document_url": doc_url,
                    "notifications": notifications,
                },
            }
        except Exception as e:
            return {"error": str(e)}
