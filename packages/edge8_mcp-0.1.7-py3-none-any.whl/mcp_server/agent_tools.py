"""
Agent Tools for Edge8 MCP Server

Provides daemon management and project registration tools for the Lark
agent worker system. Uses only stdlib + pyyaml — no FastAPI, Supabase,
or lark-oapi dependencies.
"""

from __future__ import annotations

import os
import subprocess
from pathlib import Path
from typing import Any, Dict, List, Optional

import yaml
from fastmcp import FastMCP


def register_agent_tools(mcp: FastMCP) -> None:
    """Register agent daemon management tools with the MCP server."""

    @mcp.tool()
    async def lark_daemon_status() -> dict:
        """Check if the Lark agent daemon is running on this machine."""
        try:
            result = subprocess.run(
                ["launchctl", "list"],
                capture_output=True,
                text=True,
            )
            label = "com.edge8.lark-agent-worker"
            for line in result.stdout.splitlines():
                if label in line:
                    parts = line.split()
                    # launchctl list columns: PID  Status  Label
                    pid_str = parts[0] if parts else "-"
                    pid = None if pid_str == "-" else int(pid_str)
                    return {
                        "running": pid is not None,
                        "pid": pid,
                        "label": label,
                    }
            return {"running": False, "pid": None, "label": label}
        except Exception as e:
            return {"running": False, "error": str(e)}

    @mcp.tool()
    async def lark_register_project(
        root: str,
        app_id: str,
        name: str,
    ) -> dict:
        """Register a project's agent workspaces with the local Lark daemon.

        Args:
            root: Absolute path to the project's lark-agents/ or .claude/agents/ directory
            app_id: Lark App ID (format: cli_xxxxxxxx)
            name: Human-readable project name
        """
        root_path = Path(root)
        if not root_path.exists():
            return {"registered": False, "error": f"Path does not exist: {root}"}

        # ── Detect format ──────────────────────────────────────────────────────
        root_str = str(root_path)
        is_format_b = root_str.endswith(".claude/agents") or root_str.endswith(
            ".claude/agents/"
        )

        # Also check contents: Format B has .md files with YAML frontmatter
        if not is_format_b:
            md_files = list(root_path.glob("*.md"))
            if md_files:
                try:
                    content = md_files[0].read_text(encoding="utf-8")
                    if content.startswith("---"):
                        is_format_b = True
                except OSError:
                    pass

        agents: List[Dict[str, Any]] = []

        if is_format_b:
            # Format B: .md files with YAML frontmatter
            for md_file in sorted(root_path.glob("*.md")):
                try:
                    content = md_file.read_text(encoding="utf-8")
                    if not content.startswith("---"):
                        continue
                    end = content.index("---", 3)
                    frontmatter = yaml.safe_load(content[3:end])
                    if isinstance(frontmatter, dict):
                        agents.append(
                            {
                                "id": md_file.stem,
                                "display_name": frontmatter.get(
                                    "name", md_file.stem
                                ),
                                "description": frontmatter.get("description", ""),
                            }
                        )
                except (OSError, ValueError, yaml.YAMLError):
                    continue
        else:
            # Format A: subdirectories (exclude _router), each with CLAUDE.md
            for subdir in sorted(root_path.iterdir()):
                if not subdir.is_dir() or subdir.name.startswith("_"):
                    continue
                claude_md = subdir / "CLAUDE.md"
                display_name = subdir.name
                description = ""
                if claude_md.exists():
                    try:
                        lines = claude_md.read_text(encoding="utf-8").splitlines()
                        for line in lines:
                            stripped = line.strip()
                            if stripped.startswith("# "):
                                display_name = stripped[2:].strip()
                                break
                        # Next non-empty line after heading = description
                        found_heading = False
                        for line in lines:
                            stripped = line.strip()
                            if stripped.startswith("# "):
                                found_heading = True
                                continue
                            if found_heading and stripped:
                                description = stripped
                                break
                    except OSError:
                        pass
                agents.append(
                    {
                        "id": subdir.name,
                        "display_name": display_name,
                        "description": description,
                    }
                )

        # ── Locate registry ────────────────────────────────────────────────────
        registry_path: Optional[Path] = None

        env_path = os.getenv("EDGE8_REGISTRY_PATH")
        if env_path:
            registry_path = Path(env_path)
        else:
            home_path = Path.home() / ".edge8" / "agent_registry.yaml"
            if home_path.exists():
                registry_path = home_path
            else:
                cwd_path = Path.cwd() / "config" / "agent_registry.yaml"
                if cwd_path.exists():
                    registry_path = cwd_path
                else:
                    # Fall back to home path (will be created)
                    registry_path = home_path

        # ── Read / create registry ─────────────────────────────────────────────
        if registry_path.exists():
            try:
                data = yaml.safe_load(registry_path.read_text(encoding="utf-8")) or {}
            except yaml.YAMLError:
                data = {}
        else:
            data = {}

        if not isinstance(data.get("projects"), list):
            data["projects"] = []

        # ── Upsert by app_id ───────────────────────────────────────────────────
        project_entry = {
            "app_id": app_id,
            "name": name,
            "root": str(root_path),
            "agents": [
                {
                    "id": a["id"],
                    "display_name": a["display_name"],
                    "description": a["description"],
                }
                for a in agents
            ],
        }

        existing_index = next(
            (i for i, p in enumerate(data["projects"]) if p.get("app_id") == app_id),
            None,
        )
        if existing_index is not None:
            data["projects"][existing_index] = project_entry
        else:
            data["projects"].append(project_entry)

        # ── Write back ─────────────────────────────────────────────────────────
        registry_path.parent.mkdir(parents=True, exist_ok=True)
        registry_path.write_text(
            yaml.dump(data, default_flow_style=False, allow_unicode=True),
            encoding="utf-8",
        )

        return {
            "registered": True,
            "agents": [a["id"] for a in agents],
            "registry_path": str(registry_path),
        }

    @mcp.tool()
    async def lark_daemon_start() -> dict:
        """Start the Lark agent daemon via launchctl."""
        label = "com.edge8.lark-agent-worker"
        plist_path = (
            Path.home() / "Library" / "LaunchAgents" / f"{label}.plist"
        )
        if not plist_path.exists():
            return {
                "started": False,
                "error": (
                    f"Plist not found at {plist_path}. "
                    "Run setup.sh first to install the daemon, "
                    "then retry lark_daemon_start."
                ),
            }
        try:
            result = subprocess.run(
                ["launchctl", "start", label],
                capture_output=True,
                text=True,
            )
            if result.returncode == 0:
                return {"started": True}
            return {
                "started": False,
                "error": result.stderr.strip() or f"exit code {result.returncode}",
            }
        except Exception as e:
            return {"started": False, "error": str(e)}
