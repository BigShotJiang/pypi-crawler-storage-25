"""
Edge8 Internal MCP Server

Exposes Lark workspace tools, Typeform data-sync tools, and Zernio social
media tools via the Model Context Protocol (FastMCP).
Mount `app` as an ASGI sub-application in main.py or run it standalone.
"""

from fastmcp import FastMCP

from mcp_server.agent_tools import register_agent_tools
from mcp_server.lark_tools import register_lark_tools
from mcp_server.typeform_tools import register_typeform_tools
from mcp_server.zernio_tools import register_zernio_tools

mcp = FastMCP(
    "Edge8 Internal MCP",
    instructions=(
        "Internal MCP server for Edge8 workspace automation. "
        "Provides tools for Lark workspace operations (messaging, calendar, "
        "documents, sheets, tasks, Bitable bases, wiki) and Typeform data access "
        "and Zernio social media publishing."
    ),
)

register_lark_tools(mcp)
register_typeform_tools(mcp)
register_zernio_tools(mcp)
register_agent_tools(mcp)

# ASGI entry-point – mount at /mcp in main.py or run standalone
app = mcp.http_app()
