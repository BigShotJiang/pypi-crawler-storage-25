"""
Typeform MCP Tools

Wraps Typeform data-sync operations as FastMCP tools.
Authentication uses TypeformAuthManager (credential store) with fallback to
TYPEFORM_ACCESS_TOKEN env var.
"""

from __future__ import annotations

from typing import Any, Dict

from fastmcp import FastMCP

from agents.tools.database.aio.typeform_daily_sync import TypeformDailySyncTool
from mcp_server.typeform_auth_manager import NeedsReauthError, typeform_auth_manager


def register_typeform_tools(mcp: FastMCP) -> None:
    """Register all Typeform tools on the given FastMCP instance."""

    @mcp.tool
    def typeform_set_api_key(api_key: str) -> Dict[str, Any]:
        """Store the Typeform API key encrypted at rest.

        Call this once during initial setup. Future calls will use the stored
        key automatically. The TYPEFORM_ACCESS_TOKEN env var is still accepted
        as a fallback if no stored key exists.

        Args:
            api_key: Your Typeform personal access token.

        Returns:
            dict with 'status': 'stored'.
        """
        typeform_auth_manager.store_api_key(api_key)
        return {"status": "stored", "message": "Typeform API key stored successfully."}

    @mcp.tool
    def typeform_auth_status() -> Dict[str, Any]:
        """Check whether a Typeform API key is configured.

        Returns:
            dict with 'authenticated' (bool) and 'source' ('store' | 'env' | 'none').
        """
        return typeform_auth_manager.auth_status()

    @mcp.tool
    def typeform_clear_api_key() -> Dict[str, Any]:
        """Remove the stored Typeform API key from the credential store.

        Use this to rotate the key or clear a mis-stored value. The
        TYPEFORM_ACCESS_TOKEN env var will still work as a fallback after clearing.

        Returns:
            dict with 'status': 'cleared'.
        """
        typeform_auth_manager.clear()
        return {"status": "cleared", "message": "Typeform API key removed. Call typeform_set_api_key to store a new one."}

    @mcp.tool
    async def typeform_sync_daily() -> Dict[str, Any]:
        """Run the incremental daily Typeform sync (new forms, updates, new responses).

        This is a lighter operation than typeform_sync_all – it only fetches
        changes since the last sync run.  Designed to be called once per day
        (e.g. by a cron job).

        Returns:
            dict with daily sync statistics:
              - new_forms: number of newly discovered forms
              - updated_forms: number of forms with metadata changes
              - new_responses: number of new form responses synced
              - new_answers: number of new answers synced
        """
        try:
            api_key = typeform_auth_manager.get_api_key()
        except NeedsReauthError as e:
            return {"error": str(e)}

        # H-3: pass the resolved key so TypeformDailySyncTool uses the credential
        # store rather than always falling back to TYPEFORM_ACCESS_TOKEN env var.
        sync_tool = TypeformDailySyncTool(api_key=api_key)
        return await sync_tool.run_daily_sync()
