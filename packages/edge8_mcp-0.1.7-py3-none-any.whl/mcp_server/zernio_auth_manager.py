"""
Zernio Auth Manager

Thin ApiKeyManager subclass for Zernio. The API key is AES-encrypted at rest
in ~/.config/mcp-credentials/credentials.json under the "zernio" service key.

Falls back to ZERNIO_API_KEY env var if no stored key exists, so existing .env
setups continue working without any migration step.
"""

from __future__ import annotations

from mcp_server.credential_store import ApiKeyManager, NeedsReauthError

__all__ = ["ZernioAuthManager", "NeedsReauthError", "zernio_auth_manager"]


class ZernioAuthManager(ApiKeyManager):
    service_id = "zernio"
    env_var = "ZERNIO_API_KEY"


# Module-level singleton
zernio_auth_manager = ZernioAuthManager()
