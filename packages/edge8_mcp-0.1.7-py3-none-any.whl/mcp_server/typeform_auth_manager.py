"""
Typeform Auth Manager

Thin ApiKeyManager subclass for Typeform. The API key is AES-encrypted at rest
in ~/.config/mcp-credentials/credentials.json under the "typeform" service key.

Falls back to TYPEFORM_ACCESS_TOKEN env var if no stored key exists, so existing
.env setups continue working without any migration step.
"""

from __future__ import annotations

from mcp_server.credential_store import ApiKeyManager, NeedsReauthError

__all__ = ["TypeformAuthManager", "NeedsReauthError", "typeform_auth_manager"]


class TypeformAuthManager(ApiKeyManager):
    service_id = "typeform"
    env_var = "TYPEFORM_ACCESS_TOKEN"


# Module-level singleton
typeform_auth_manager = TypeformAuthManager()
