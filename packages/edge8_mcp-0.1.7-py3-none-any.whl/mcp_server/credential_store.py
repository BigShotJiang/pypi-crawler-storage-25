"""
Unified Credential Store
========================

Single file that holds all third-party service credentials for this MCP server.
No database required. No per-service files.

File location: ~/.config/mcp-credentials/credentials.json (default)
              Override with MCP_CREDENTIALS_DIR env var.
Gitignored:    yes (see .gitignore)

Schema
------
{
  "version": "1",
  "services": {
    "<service_id>": { ...service-specific fields... }
  }
}

Credential types
----------------
1. OAuthManager  — for services with expiring access_token + refresh_token (e.g. Lark)
2. ApiKeyManager — for services with a permanent API key (e.g. Zernio, Typeform)

Both read/write through this module. The file is the only source of truth.

Encryption
----------
Sensitive fields (API keys) are AES-256-CBC encrypted with a key from env var
EDGE8_STORE_KEY. If that var is unset, a random key is generated at runtime —
set it permanently so keys survive process restarts.

Tokens (access_token, refresh_token) are NOT encrypted because:
  - They are short-lived and useless without the app credentials (in .env)
  - Encrypting them adds complexity without meaningful security gain
  - App credentials (LARK_APP_ID, LARK_APP_SECRET) stay in .env

Multi-service OAuth
-------------------
Each OAuthManager subclass owns a unique service_id string ("lark", "zernio", …).
All sessions live under that key in the shared credentials.json. Adding a new
OAuth service = subclass OAuthManager, set service_id, implement _do_refresh()
and _build_oauth_url(). Nothing else needs to change.
"""

from __future__ import annotations

import json
import logging
import os
import secrets
import threading
from abc import ABC, abstractmethod
from datetime import datetime, timedelta, timezone
from pathlib import Path
from typing import Any, Dict, Optional

from utils.encryption import AESCipher

logger = logging.getLogger(__name__)

# ── File location ────────────────────────────────────────────────────────────
# Default: ~/.config/mcp-credentials/credentials.json
# Override: set MCP_CREDENTIALS_DIR to any directory path.

_STORE_DIR = Path(os.getenv("MCP_CREDENTIALS_DIR", str(Path.home() / ".config" / "mcp-credentials")))
STORE_FILE = _STORE_DIR / "credentials.json"

# ── Encryption key ───────────────────────────────────────────────────────────

_ENC_KEY_ENV = "EDGE8_STORE_KEY"
_cipher_cache: Optional[AESCipher] = None
_cipher_lock = threading.Lock()  # H-2: prevents race on first initialisation


def _get_cipher() -> AESCipher:
    global _cipher_cache
    if _cipher_cache is not None:
        return _cipher_cache
    with _cipher_lock:
        if _cipher_cache is not None:  # re-check after acquiring lock
            return _cipher_cache
        key = os.getenv(_ENC_KEY_ENV)
        if not key:
            key = secrets.token_hex(32)
            logger.warning(
                "%s is not set. A random key was generated for this session — "
                "encrypted API keys will not survive a process restart. "
                "Add to your .env: %s=%s",
                _ENC_KEY_ENV, _ENC_KEY_ENV, key,
            )
        _cipher_cache = AESCipher(key)
    return _cipher_cache


# L-1: Use a prefix that cannot appear at the start of a real API key.
# Dollar signs are not valid in API key character sets from any major provider.
_ENC_PREFIX = "$MCPENC$:"


def _encrypt(value: str) -> str:
    return _ENC_PREFIX + _get_cipher().encrypt_string(value)


def _decrypt(value: str) -> str:
    if not isinstance(value, str) or not value.startswith(_ENC_PREFIX):
        return value  # plaintext (legacy / unencrypted field)
    return _get_cipher().decrypt_string(value[len(_ENC_PREFIX):])


# ── Raw file I/O ─────────────────────────────────────────────────────────────

def _load_store() -> dict:
    if STORE_FILE.exists():
        try:
            return json.loads(STORE_FILE.read_text())
        except (json.JSONDecodeError, OSError):
            return {"version": "1", "services": {}}
    return {"version": "1", "services": {}}


def _save_store(store: dict) -> None:
    # C-1: Atomic write — truncation of the final file only happens on rename,
    # so a crash mid-write leaves the old file intact.
    STORE_FILE.parent.mkdir(parents=True, exist_ok=True)
    tmp = STORE_FILE.with_suffix(".tmp")
    try:
        tmp.write_text(json.dumps(store, indent=2))
        tmp.chmod(0o600)
        tmp.replace(STORE_FILE)  # POSIX-atomic; near-atomic on Windows
    except Exception:
        tmp.unlink(missing_ok=True)
        raise


def _get_service(service_id: str) -> dict:
    return _load_store().get("services", {}).get(service_id, {})


def _set_service(service_id: str, data: dict) -> None:
    store = _load_store()
    store.setdefault("services", {})[service_id] = data
    _save_store(store)


def _clear_service(service_id: str) -> None:
    store = _load_store()
    store.get("services", {}).pop(service_id, None)
    _save_store(store)


# ── Shared utilities ─────────────────────────────────────────────────────────

def _now() -> datetime:
    return datetime.now(timezone.utc)


def _seconds_until(iso_str: str) -> float:
    dt = datetime.fromisoformat(iso_str)
    if dt.tzinfo is None:
        dt = dt.replace(tzinfo=timezone.utc)
    return (dt - _now()).total_seconds()


# ── Concurrent refresh lock ──────────────────────────────────────────────────
# One lock per service_id prevents double-refresh when two concurrent tool
# calls both see an expiring access_token before either has stored the new one.

_refresh_locks: Dict[str, threading.Lock] = {}
_locks_mutex = threading.Lock()


def _get_refresh_lock(service_id: str) -> threading.Lock:
    with _locks_mutex:
        if service_id not in _refresh_locks:
            _refresh_locks[service_id] = threading.Lock()
        return _refresh_locks[service_id]


# ── Shared exception ─────────────────────────────────────────────────────────

class NeedsReauthError(Exception):
    """
    Raised by any manager when the user must re-authenticate.

    Attributes:
        service_id:  e.g. "lark"
        oauth_url:   the URL to open (None for API-key services)
        message:     human-readable explanation
    """
    def __init__(self, service_id: str, message: str, oauth_url: Optional[str] = None):
        self.service_id = service_id
        self.oauth_url = oauth_url
        super().__init__(message)


# ═══════════════════════════════════════════════════════════════════════════════
# OAuthManager — base for services with access_token + refresh_token
# ═══════════════════════════════════════════════════════════════════════════════

class OAuthManager(ABC):
    """
    Base class for OAuth-based service credential managers.

    Subclasses must set:
        service_id              str   — unique key in credentials.json
        access_token_default_ttl  int — seconds (fallback if API doesn't return expires_in)
        refresh_token_default_ttl int — seconds

    Subclasses must implement:
        _do_refresh(refresh_token) -> (access_token, refresh_token, at_ttl, rt_ttl)
        _build_oauth_url()         -> str
    """

    service_id: str
    access_token_default_ttl: int = 7_200       # 2 hours
    refresh_token_default_ttl: int = 604_800    # 7 days
    refresh_before_expiry: int = 600            # refresh when < 10 min remain
    warn_before_rt_expiry: int = 86_400         # warn when < 1 day on refresh token

    # ── Public API ──────────────────────────────────────────────────────────

    def get_access_token(self) -> str:
        """
        Return a valid access_token, refreshing silently when near expiry.

        Raises:
            NeedsReauthError: refresh_token missing or expired.
        """
        data = _get_service(self.service_id)

        if not data or "refresh_token" not in data:
            raise NeedsReauthError(
                self.service_id,
                f"{self.service_id}: not authenticated. Call {self.service_id}_authenticate.",
                oauth_url=self._build_oauth_url(),
            )

        rt_seconds = _seconds_until(data["refresh_token_expires_at"])
        if rt_seconds <= 0:
            raise NeedsReauthError(
                self.service_id,
                f"{self.service_id}: session expired (refresh token). Re-authenticate.",
                oauth_url=self._build_oauth_url(),
            )

        at_seconds = _seconds_until(data["access_token_expires_at"])
        if at_seconds < self.refresh_before_expiry:
            with _get_refresh_lock(self.service_id):
                # Re-read after acquiring lock — another thread may have already refreshed.
                data = _get_service(self.service_id)
                at_seconds = _seconds_until(data["access_token_expires_at"])
                if at_seconds < self.refresh_before_expiry:
                    data = self._refresh_and_store(data["refresh_token"])

        return data["access_token"]

    def auth_status(self) -> Dict[str, Any]:
        """
        Return current auth status without triggering a refresh.

        Returns dict with keys:
            authenticated           bool
            access_token_expires_in int   (seconds, only if authenticated)
            refresh_token_expires_in int  (seconds, only if authenticated)
            refresh_token_warning   bool  (True if < warn_before_rt_expiry left)
            oauth_url               str   (only if not authenticated)
        """
        data = _get_service(self.service_id)

        if not data or "refresh_token" not in data:
            return {"authenticated": False, "oauth_url": self._build_oauth_url()}

        rt_seconds = _seconds_until(data["refresh_token_expires_at"])
        if rt_seconds <= 0:
            return {"authenticated": False, "oauth_url": self._build_oauth_url()}

        at_seconds = _seconds_until(data["access_token_expires_at"])
        return {
            "authenticated": True,
            "access_token_expires_in": max(0, int(at_seconds)),
            "refresh_token_expires_in": max(0, int(rt_seconds)),
            "refresh_token_warning": rt_seconds < self.warn_before_rt_expiry,
        }

    def store_tokens(
        self,
        access_token: str,
        refresh_token: str,
        expires_in: Optional[int] = None,
        refresh_token_expires_in: Optional[int] = None,
    ) -> None:
        """Persist tokens from an OAuth callback. Called by the route handler."""
        at_ttl = expires_in or self.access_token_default_ttl
        rt_ttl = refresh_token_expires_in or self.refresh_token_default_ttl
        now = _now()
        _set_service(self.service_id, {
            "access_token": access_token,
            "refresh_token": refresh_token,
            "access_token_expires_at": (now + timedelta(seconds=at_ttl)).isoformat(),
            "refresh_token_expires_at": (now + timedelta(seconds=rt_ttl)).isoformat(),
        })

    def get_oauth_url(self) -> str:
        return self._build_oauth_url()

    def clear(self) -> None:
        """Remove this service's credentials (logout)."""
        _clear_service(self.service_id)

    # ── Subclass interface ──────────────────────────────────────────────────

    @abstractmethod
    def _do_refresh(self, refresh_token: str) -> tuple[str, str, int, int]:
        """
        Call the service's token refresh endpoint.

        Returns:
            (access_token, new_refresh_token, at_expires_in, rt_expires_in)
        """

    @abstractmethod
    def _build_oauth_url(self) -> str:
        """Return the authorization URL for the initial OAuth flow."""

    # ── Internal ────────────────────────────────────────────────────────────

    def _refresh_and_store(self, refresh_token: str) -> dict:
        access_token, new_rt, at_ttl, rt_ttl = self._do_refresh(refresh_token)
        now = _now()
        data = {
            "access_token": access_token,
            "refresh_token": new_rt,
            "access_token_expires_at": (now + timedelta(seconds=at_ttl)).isoformat(),
            "refresh_token_expires_at": (now + timedelta(seconds=rt_ttl)).isoformat(),
        }
        _set_service(self.service_id, data)
        return data


# ═══════════════════════════════════════════════════════════════════════════════
# ApiKeyManager — base for services with a permanent bearer / API key
# ═══════════════════════════════════════════════════════════════════════════════

class ApiKeyManager(ABC):
    """
    Base class for API-key-based service credential managers.

    Subclasses must set:
        service_id  str — unique key in credentials.json
        env_var     str — fallback env var name (e.g. "ZERNIO_API_KEY")

    The API key is AES-encrypted at rest.
    On first use the env var is checked as a fallback if no stored key exists.
    """

    service_id: str
    env_var: str

    # ── Public API ──────────────────────────────────────────────────────────

    def get_api_key(self) -> str:
        """
        Return the stored API key.

        Falls back to the env var if nothing is stored.

        Raises:
            NeedsReauthError: no key stored and no env var set.
        """
        data = _get_service(self.service_id)
        encrypted = data.get("api_key")
        if encrypted:
            return _decrypt(encrypted)

        # Fallback: env var (unencrypted, not persisted)
        env_key = os.getenv(self.env_var)
        if env_key:
            return env_key

        raise NeedsReauthError(
            self.service_id,
            f"{self.service_id}: no API key configured. "
            f"Call {self.service_id}_set_api_key or set {self.env_var} in .env.",
        )

    def store_api_key(self, api_key: str) -> None:
        """Encrypt and persist the API key."""
        # H-1: Reject empty keys — they bypass the env-var fallback on next read.
        if not api_key or not api_key.strip():
            raise ValueError(f"{self.service_id}: API key must not be empty.")
        data = _get_service(self.service_id)
        data["api_key"] = _encrypt(api_key)
        _set_service(self.service_id, data)

    def auth_status(self) -> Dict[str, Any]:
        """Return whether an API key is configured."""
        try:
            self.get_api_key()
            source = "store" if _get_service(self.service_id).get("api_key") else "env"
            return {"authenticated": True, "source": source}
        except NeedsReauthError:
            return {
                "authenticated": False,
                "message": f"Set {self.env_var} in .env or call {self.service_id}_set_api_key.",
            }

    def clear(self) -> None:
        """Remove this service's stored key."""
        _clear_service(self.service_id)
