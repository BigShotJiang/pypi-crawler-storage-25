"""
Lark Auth Manager

Thin OAuthManager subclass for Lark. Delegates all storage, refresh scheduling,
and error handling to the shared CredentialStore / OAuthManager base.

Token lifetimes:
  access_token   — 2 hours  (7 200 s)
  refresh_token  — 7 days   (604 800 s)
"""

from __future__ import annotations

from connectors.lark_interactions.auth import LarkAuth
from mcp_server.credential_store import NeedsReauthError, OAuthManager

__all__ = ["LarkAuthManager", "NeedsReauthError", "lark_auth_manager"]


class LarkAuthManager(OAuthManager):
    service_id = "lark"
    access_token_default_ttl = 7_200      # 2 hours
    refresh_token_default_ttl = 604_800   # 7 days

    def __init__(self) -> None:
        self._auth = LarkAuth()

    def _do_refresh(self, refresh_token: str) -> tuple[str, str, int, int]:
        resp = self._auth.refresh_access_token(refresh_token)
        data = resp.get("data", resp)
        access_token = data.get("access_token")
        if not access_token:
            raise RuntimeError(f"Lark refresh returned unexpected payload: {resp}")
        return (
            access_token,
            data.get("refresh_token", refresh_token),
            data.get("expires_in", self.access_token_default_ttl),
            data.get("refresh_token_expires_in", self.refresh_token_default_ttl),
        )

    def _build_oauth_url(self) -> str:
        return self._auth.oauth_code()


# Module-level singleton — import this everywhere
lark_auth_manager = LarkAuthManager()
