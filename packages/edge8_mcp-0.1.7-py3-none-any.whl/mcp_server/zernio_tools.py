"""
Zernio MCP Tools

Wraps Zernio social media publishing operations as FastMCP tools.
Authentication is handled transparently by ZernioAuthManager — callers do NOT
pass an API key. The manager reads from ~/.config/mcp-credentials/credentials.json
or falls back to the ZERNIO_API_KEY env var.
"""

from __future__ import annotations

from typing import Any, Dict, List, Optional

from fastmcp import FastMCP

from connectors.zernio.posts import ZernioPosts
from connectors.zernio.profiles import ZernioProfiles
from connectors.zernio.accounts import ZernioAccounts
from connectors.zernio.analytics import ZernioAnalytics
from mcp_server.zernio_auth_manager import NeedsReauthError, zernio_auth_manager


def _key() -> str:
    """Return a valid Zernio API key or raise a human-readable RuntimeError."""
    try:
        return zernio_auth_manager.get_api_key()
    except NeedsReauthError:
        raise RuntimeError(
            "Zernio API key not configured. Use zernio_set_api_key to store it, "
            "or set the ZERNIO_API_KEY environment variable."
        )


def register_zernio_tools(mcp: FastMCP) -> None:
    """Register all Zernio tools on the given FastMCP instance."""

    @mcp.tool
    def zernio_set_api_key(api_key: str) -> Dict[str, Any]:
        """Store the Zernio API key encrypted at rest in ~/.config/mcp-credentials/credentials.json.

        Call this once during initial setup. The key is AES-256 encrypted and
        persists across server restarts. Future calls to Zernio tools will use
        the stored key automatically.

        Args:
            api_key: Your Zernio API key (starts with sk_...).

        Returns:
            dict with 'status': 'stored'.
        """
        zernio_auth_manager.store_api_key(api_key)
        return {"status": "stored", "message": "Zernio API key stored successfully."}

    @mcp.tool
    def zernio_auth_status() -> Dict[str, Any]:
        """Check whether a Zernio API key is configured.

        Returns:
            dict with 'authenticated' (bool) and 'source' ('stored' | 'env' | 'none').
        """
        return zernio_auth_manager.auth_status()

    @mcp.tool
    def zernio_clear_api_key() -> Dict[str, Any]:
        """Remove the stored Zernio API key from the credential store.

        Use this to rotate the key or clear a mis-stored value. The ZERNIO_API_KEY
        env var will still work as a fallback after clearing.

        Returns:
            dict with 'status': 'cleared'.
        """
        zernio_auth_manager.clear()
        return {"status": "cleared", "message": "Zernio API key removed. Call zernio_set_api_key to store a new one."}

    @mcp.tool
    async def zernio_list_profiles() -> Dict[str, Any]:
        """List all Zernio brand profiles (project containers).

        Returns:
            dict with 'content' and 'metadata.profiles' (list of profile dicts).
        """
        try:
            profiles = await ZernioProfiles(api_key=_key()).list()
            return {
                "content": f"Found {len(profiles)} profile(s).",
                "metadata": {"profiles": profiles, "count": len(profiles)},
            }
        except Exception as e:
            return {"error": str(e)}

    @mcp.tool
    async def zernio_create_post(
        content: str,
        platforms: List[str],
        publish_now: bool = False,
        scheduled_for: Optional[str] = None,
        timezone: Optional[str] = None,
    ) -> Dict[str, Any]:
        """Create a social media post on one or more platforms.

        Args:
            content: Post text content.
            platforms: List of platform identifiers (e.g. ['twitter', 'linkedin']).
            publish_now: If True, publish immediately. Otherwise schedules or saves as draft.
            scheduled_for: ISO 8601 datetime string for scheduled publishing.
            timezone: IANA timezone string (e.g. 'Asia/Ho_Chi_Minh').

        Returns:
            dict with 'content' and 'metadata.post'.
        """
        try:
            post = await ZernioPosts(api_key=_key()).create(
                content=content,
                platforms=platforms,
                publish_now=publish_now,
                scheduled_for=scheduled_for,
                timezone=timezone,
            )
            return {"content": "Post created successfully.", "metadata": {"post": post}}
        except Exception as e:
            return {"error": str(e)}

    @mcp.tool
    async def zernio_list_posts(
        status: Optional[str] = None,
        platform: Optional[str] = None,
        from_date: Optional[str] = None,
        to_date: Optional[str] = None,
        limit: int = 20,
    ) -> Dict[str, Any]:
        """List Zernio posts with optional filters.

        Args:
            status: Filter by status — 'draft', 'scheduled', 'published', 'failed'.
            platform: Filter by platform identifier.
            from_date: ISO date string range start (YYYY-MM-DD).
            to_date: ISO date string range end (YYYY-MM-DD).
            limit: Maximum results to return (default 20).

        Returns:
            dict with 'content' and 'metadata.posts' (list).
        """
        try:
            posts = await ZernioPosts(api_key=_key()).list(
                status=status,
                platform=platform,
                from_date=from_date,
                to_date=to_date,
                limit=limit,
            )
            return {
                "content": f"Found {len(posts)} post(s).",
                "metadata": {"posts": posts, "count": len(posts)},
            }
        except Exception as e:
            return {"error": str(e)}

    @mcp.tool
    async def zernio_list_accounts() -> Dict[str, Any]:
        """List all connected social media accounts in Zernio.

        Returns:
            dict with 'content' and 'metadata.accounts' (list of account dicts).
        """
        try:
            accounts = await ZernioAccounts(api_key=_key()).list()
            return {
                "content": f"Found {len(accounts)} connected account(s).",
                "metadata": {"accounts": accounts, "count": len(accounts)},
            }
        except Exception as e:
            return {"error": str(e)}

    @mcp.tool
    async def zernio_get_analytics(
        from_date: Optional[str] = None,
        to_date: Optional[str] = None,
        limit: int = 20,
    ) -> Dict[str, Any]:
        """Get post performance analytics from Zernio.

        Args:
            from_date: ISO date range start (YYYY-MM-DD).
            to_date: ISO date range end (YYYY-MM-DD).
            limit: Maximum results (default 20).

        Returns:
            dict with 'content' and 'metadata.analytics'.
        """
        try:
            data = await ZernioAnalytics(api_key=_key()).get_post_analytics(
                from_date=from_date,
                to_date=to_date,
                limit=limit,
            )
            return {"content": "Analytics fetched.", "metadata": {"analytics": data}}
        except Exception as e:
            return {"error": str(e)}

    @mcp.tool
    async def zernio_get_best_times() -> Dict[str, Any]:
        """Get the best posting times for each connected platform.

        Returns:
            dict with 'content' and 'metadata.best_times'.
        """
        try:
            data = await ZernioAnalytics(api_key=_key()).get_best_times()
            return {"content": "Best times fetched.", "metadata": {"best_times": data}}
        except Exception as e:
            return {"error": str(e)}
