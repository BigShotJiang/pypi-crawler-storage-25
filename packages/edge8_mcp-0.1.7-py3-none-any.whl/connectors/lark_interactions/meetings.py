from .auth import LarkParentInitializer

import os
import sys
import requests
import json
from typing import List, Optional
import time

sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from utils.custom_types import LarkMeetingSettingProps, LarkMeetingAuthorizeObject

class Meetings(LarkParentInitializer):
    reserve_id: Optional[str] = None
    meeting_id: Optional[str] = None
    url: Optional[str] = None
    app_link: Optional[str] = None
    live_link: Optional[str] = None
    
    def __init__(self, is_auth=False, access_token=None, bot_type: Optional[str] = "meeting"):
        super().__init__(is_auth, access_token, bot_type)
        self.headers = {
            "Authorization": f"Bearer {self.access_token if self.access_token is not None else self.tenant_access_token}",
            "Content-Type": "application/json",
        }
    
    def get_by_id(self, reserve_id, is_active=True, user_id_type="open_id", with_participants=True):
        response = requests.get(
            f"{self.base_url}/vc/v1/reserves/{reserve_id}{'/get_active_meeting' if is_active else ''}",
            headers=self.headers,
            params = {
                "user_id_type": user_id_type,
                "with_participants": with_participants,
            }
        )
        try:
            return self.process_response_contents(response, "data", {}).get("reserve" if not is_active else "meeting", None)
        except Exception as e:
            raise Exception(f"Failed to get meeting: {str(e)}")
    
    def get_by_meeting_number(self, meeting_number: str, start_time: int, end_time: int, page_size: int = 20):
        response = requests.get(
            f"{self.base_url}/vc/v1/meetings/list_by_no",
            headers=self.headers,
            params={
                "meeting_no": meeting_number,
                "start_time": start_time,
                "end_time": end_time,
                "page_size": page_size,
            }
        )
        try:
            return self.process_response_contents(response, "data", {}).get("meeting_briefs", [])
        except Exception as e:
            raise Exception(f"Failed to get meeting: {str(e)}")
    
    def create(self, owner_id, end_time, settings: LarkMeetingSettingProps):
        response = requests.post(
            f"{self.base_url}/vc/v1/meetings",
            headers=self.headers,
            json={
                "owner_id": owner_id,
                "end_time": end_time,
                "meeting_settings": settings,
            },
        )
        try:
            reservation_data = self.process_response_contents(response, "data", {}).get("reserve", {})
            self.reserve_id = reservation_data.get("id", None)
            self.meeting_id = reservation_data.get("meeting_no", None)
            self.url = reservation_data.get("url", None)
            self.app_link = reservation_data.get("app_link", None)
            self.live_link = reservation_data.get("live_link", None)
        
            return reservation_data
        except Exception as e:
            raise Exception(f"Failed to create meeting: {str(e)}")
    
    def update(self, end_time, settings: LarkMeetingSettingProps):
        response = requests.put(
            f"{self.base_url}/vc/v1/meetings",
            headers=self.headers,
            json={
                "end_time": end_time,
                "meeting_settings": settings,
            },
        )
        try:
            return self.process_response_contents(response, "data", {}).get("reserve", None)
        except Exception as e:
            raise Exception(f"Failed to update meeting: {str(e)}")
    
    def delete(self, reserve_id):
        response = requests.delete(
            f"{self.base_url}/vc/v1/reserves/{reserve_id}",
            headers=self.headers,
        )
        try:
            return self.process_response_contents(response, "data", {})
        except Exception as e:
            raise Exception(f"Failed to delete meeting: {str(e)}")
    
    def get_details(
        self,
        meeting_id: str,
        user_id_type="open_id",
    ) -> dict:
        response = requests.get(
            f"{self.base_url}/vc/v1/meetings/{meeting_id}",
            headers=self.headers,
            params={
                "user_id_type": user_id_type,
                "with_participants": True,
                "with_meeting_ability": True,
            }
        )
        try:
            return self.process_response_contents(response, "data", {}).get("meeting", {})
        except Exception as e:
            raise Exception(f"Failed to get meeting details: {str(e)}")
    
    def get_participants_details(
        self,
        start_time: str,
        end_time: str,
        meeting_no: str,
        user_id: Optional[str] = None,
        room_id: Optional[str] = None,
        page_size: Optional[int] = 100,
        page_token: Optional[str] = None,
        user_id_type="open_id",
    ):
        response = requests.get(
            f"{self.base_url}/vc/v1/meeting_list",
            headers=self.headers,
            params={
                "user_id_type": user_id_type,
                "with_participants": True,
                "start_time": start_time,
                "end_time": end_time,
                "meeting_no": meeting_no,
                "user_id": user_id,
                "room_id": room_id,
                "page_size": page_size,
                "page_token": page_token,
            }
        )
        try:
            return self.process_response_contents(response, "data", {}).get("meeting_list", [])
        except Exception as e:
            raise Exception(f"Failed to get participants details: {str(e)}")
    
class MeetingRecord(Meetings):
    def __init__(self, is_auth=False, access_token=None, bot_type: Optional[str] = "meeting"):
        super().__init__(is_auth, access_token, bot_type)
        self.headers = {
            "Authorization": f"Bearer {self.access_token if self.access_token is not None else self.tenant_access_token}",
            "Content-Type": "application/json",
        }
    
    def get_recording(self, meeting_id: Optional[str] = None):
        if meeting_id is None:
            meeting_id = self.meeting_id
        is_generating = True
        while is_generating:
            response = requests.get(
                f"{self.base_url}/vc/v1/meetings/{meeting_id}/recording",
                headers=self.headers,
            )
            response = self.response_data_and_error(response)
            error = response.get("error", {})
            code = response.get("code")
            msg = response.get("msg", error)
            if (code != 124002 and code == 0 and error == {}):
                is_generating = False
                recording = response.get("data", {}).get("recording", {})
                return recording
            elif code != 124002 and code != 0:
                print("response: ", response)
                print("error: ", error)
                raise Exception(msg)
            else:
                print("response: ", response)
                print("error: ", error)
    
    def authorize(self, meeting_id: Optional[str], permission_objects: List[LarkMeetingAuthorizeObject], action_type: int = 0):
        if meeting_id is None:
            meeting_id = self.meeting_id
        
        response = requests.patch(
            f"{self.base_url}/vc/v1/meetings/{meeting_id}/recording/set_permission",
            headers=self.headers,
            json={
                "permission_objects": permission_objects,
                "action_type": action_type,
            },
        )
        try:
            return self.process_response_contents(response, "data", {}).get("recording", {})
        except Exception as e:
            raise Exception(f"Failed to authorize meeting: {str(e)}")
    
    def start_recording(self):
        response = requests.get(
            f"{self.base_url}/vc/v1/meetings/{self.meeting_id}/recordings/start",
            headers=self.headers,
        )
        try:
            return self.process_response_contents(response, "data", {}).get("recording", {})
        except Exception as e:
            raise Exception(f"Failed to start recording: {str(e)}")
    
    def stop_recording(self):
        response = requests.get(
            f"{self.base_url}/vc/v1/meetings/{self.meeting_id}/recordings/stop",
            headers=self.headers,
        )
        try:
            return self.process_response_contents(response, "data", {}).get("recording", {})
        except Exception as e:
            raise Exception(f"Failed to stop recording: {str(e)}")
    
class Minutes(LarkParentInitializer):
    def __init__(self, is_auth=False, access_token=None, minute_token=None, bot_type: Optional[str]= "meeting"):
        super().__init__(is_auth, access_token, bot_type)
        self.minute_token = minute_token
        self.headers = {
            "Authorization": f"Bearer {self.access_token if self.access_token is not None else self.tenant_access_token}",
            "Content-Type": "application/json",
        }
    
    def get_transcript(self, need_speaker: Optional[bool] = True, need_timestamp: Optional[bool] = True, file_format: Optional[str] = "txt") -> bytes:
        try:
            is_ready = False
            attempt = 1
            
            while not is_ready:
                response = requests.get(
                    f"{self.base_url}/minutes/v1/minutes/{self.minute_token}/transcript",
                    headers=self.headers,
                    params={
                        "need_speaker": need_speaker,
                        "need_timestamp": need_timestamp,
                        "file_format": file_format,
                    }
                )
          
                if response.status_code == 200:
                    is_ready = True
                    return response.content
                else:
                    time.sleep(0.5)
                    reason = response.reason
                    error = response.json().get("msg", "")
                    print("attempt: ", attempt)
                    print("reason: ", reason)
                    print("error: ", error)
                    attempt += 1
            
            raise Exception(f"Failed to get transcript: {str(response)}")
        
        except Exception as e:
            raise Exception(f"Failed to get transcript: {str(e)}")
        
    def get_metadata(self, user_id_type="open_id") -> dict[str,str]:
        try:
            response = requests.get(
                f"{self.base_url}/minutes/v1/minutes/{self.minute_token}",
                headers=self.headers,
                params={
                    "user_id_type": user_id_type,
                }
            )
            return self.process_response_contents(response, "data", {}).get("minute", {})
        except Exception as e:
            raise Exception(f"Failed to get metadata: {str(e)}")
        
        