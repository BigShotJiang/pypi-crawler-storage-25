import requests
from typing import Union, Optional, List, Dict
import os
import sys

sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from connectors.lark_interactions.auth import LarkParentInitializer
from utils.custom_types import LarkTableField

class LarkBase(LarkParentInitializer):
    def __init__(self, is_auth=False, access_token=None, bot_type: Optional[str] = "meeting"):
        super().__init__(is_auth, access_token, bot_type)
        self.headers = {
            "Authorization": f"Bearer {self.access_token if self.access_token is not None else self.tenant_access_token}",
            "Content-Type": "application/json",
        }

    def create_app(self, name, folder_token=""):
        response = requests.post(
            f"{self.base_url}/bitable/v1/apps",
            headers=self.headers,
            json={"name": name, "folder_token": folder_token},
        )
        try:
            return self.process_response_contents(response, "data", {}).get("app", {})
        except Exception as e:
            raise Exception(f"Failed to create app: {str(e)}")

    def get_app_info(self, app_id):
        response = requests.get(
            f"{self.base_url}/bitable/v1/apps/{app_id}",
            headers=self.headers,
        )
        try:
            return self.process_response_contents(response, "data", {}).get("app", {})
        except Exception as e:
            raise Exception(f"Failed to get app info: {str(e)}")

class LarkBaseTable(LarkBase):
    def __init__(self, is_auth=False, access_token=None, bot_type: Optional[str] = "meeting"):
        super().__init__(is_auth, access_token, bot_type)
        self.type_str_int_map = {
            "multiline": 1,
            "number": 2,
            "single_option": 3,
            "multiple_option": 4,
            "date": 5,
            "checkbox": 7,
            "person": 11,
            "phone_number": 13,
            "link": 15,
            "attachment": 17,
            "one_way_link": 18,
            "formula": 20,
            "two_way_link": 21,
            "location": 22,
            "group": 23,
            "date_created": 1001,
            "last_modified_date": 1002,
            "created_by": 1003,
            "modified_by": 1004,
            "auto_serial": 1005,
        }
    
    def create_table(self, app_id, table_name, default_view_name: Optional[str] = "Grid", fields: Optional[List[LarkTableField]] = []):
        response = requests.post(
            f"{self.base_url}/bitable/v1/apps/{app_id}/tables",
            headers=self.headers,
            json={"table" :{
                "name": table_name,
                "default_view_name": default_view_name,
                "fields": fields
            }},
        )
        print("Create table response: ", response.json())
        try:
            return self.process_response_contents(response, "data", {})
        except Exception as e:
            raise Exception(f"Failed to create table: {str(e)}")
    
    def list_tables(self, app_id, page_size=20, page_token=""):
        response = requests.get(
            f"{self.base_url}/bitable/v1/apps/{app_id}/tables",
            headers=self.headers,
            params={"page_size": page_size, "page_token": page_token},
        )

        try:
            return self.process_response_contents(response, "data", {}).get("items", [])
        except Exception as e:
            raise Exception(f"Failed to list tables: {str(e)}")
    
    def update_table_name(self, app_id, table_id, table_name):
        response = requests.put(
            f"{self.base_url}/bitable/v1/apps/{app_id}/tables/{table_id}",
            headers=self.headers,
            json={"name": table_name},
        )
        try:
            return self.process_response_contents(response, "data", {})
        except Exception as e:
            raise Exception(f"Failed to update table name: {str(e)}")
      
    def delete_table(self, app_id, table_id):
        response = requests.delete(
            f"{self.base_url}/bitable/v1/apps/{app_id}/tables/{table_id}",
            headers=self.headers,
        )
        print("Delete table response: ", response.json())
        try:
            return self.process_response_contents(response, "data", {})
        except Exception as e:
            raise Exception(f"Failed to delete table: {str(e)}")
    
    def create_field(self, app_id, table_id, field: LarkTableField):
        response = requests.post(
            f"{self.base_url}/bitable/v1/apps/{app_id}/tables/{table_id}/fields",
            headers=self.headers,
            json=field,
        )
        try:
            return self.process_response_contents(response, "data", {})
        except Exception as e:
            raise Exception(f"Failed to create field: {str(e)}")
    
    def list_fields(self, app_id, table_id, page_size=20, page_token="", view_id="", text_field_as_array=False):
        response = requests.get(
            f"{self.base_url}/bitable/v1/apps/{app_id}/tables/{table_id}/fields",
            headers=self.headers,
            params={"page_size": page_size, "page_token": page_token, "view_id": view_id, "text_field_as_array": text_field_as_array},
        )
        try:
            return self.process_response_contents(response, "data", {}).get("items", [])
        except Exception as e:
            raise Exception(f"Failed to list fields: {str(e)}")
    
    def update_field(self, app_id, table_id, field_id, field: LarkTableField):
        response = requests.put(
            f"{self.base_url}/bitable/v1/apps/{app_id}/tables/{table_id}/fields/{field_id}",
            headers=self.headers,
            json=field,
        )
        try:
            return self.process_response_contents(response, "data", {})
        except Exception as e:
            raise Exception(f"Failed to update field: {str(e)}")
    
    def delete_field(self, app_id, table_id, field_id):
        response = requests.delete(
            f"{self.base_url}/bitable/v1/apps/{app_id}/tables/{table_id}/fields/{field_id}",
            headers=self.headers,
        )
        try:
            return self.process_response_contents(response, "data", {})
        except Exception as e:
            raise Exception(f"Failed to delete field: {str(e)}")
        
    def insert(self, app_id, table_id, records: list[dict]):
        response = requests.post(
            f"{self.base_url}/bitable/v1/apps/{app_id}/tables/{table_id}/records/batch_create",
            headers=self.headers,
            json={"records": records},
        )
        try:
            return self.process_response_contents(response, "data", {}).get("records", [])
        except Exception as e:
            raise Exception(f"Failed to create records: {str(e)}")
        
    def update_record(self, app_id, table_id, record_id, record: dict):
        response = requests.put(
            f"{self.base_url}/bitable/v1/apps/{app_id}/tables/{table_id}/records/{record_id}",
            headers=self.headers,
            json=record,
        )
        try:
            record = self.process_response_contents(response, "data", {}).get("record", {})
            mapped_record = {"id": record["record_id"], **record["fields"]}
            return mapped_record
        except Exception as e:
            raise Exception(f"Failed to update record: {str(e)}")
        
    def delete_records(self, app_id: str, table_id: str, record_ids: List[str]) -> dict:
        """Batch delete records by record ID list."""
        response = requests.delete(
            f"{self.base_url}/bitable/v1/apps/{app_id}/tables/{table_id}/records/batch_delete",
            headers=self.headers,
            json={"records": record_ids},
        )
        try:
            return self.process_response_contents(response, "data", {})
        except Exception as e:
            raise Exception(f"Failed to delete records: {str(e)}")

    def search_records(self, app_id, table_id, field_names: Optional[List[str]], sort: Optional[List[Dict]], filter: Optional[List[str]]):
        filter = build_lark_filter(filter) if filter is not None else None
        response = requests.post(
            f"{self.base_url}/bitable/v1/apps/{app_id}/tables/{table_id}/records/search",
            headers=self.headers,
            json={"field_names": field_names, "sort": sort, "filter": filter},
        )
        try:
            records = self.process_response_contents(response, "data", {}).get("items", [])
            mapped_records = [{"id": record["record_id"], **record["fields"]} for record in records]
            return mapped_records
        except Exception as e:
            raise Exception(f"Failed to search records: {str(e)}")
        

def build_lark_filter(filters: list):
    conditions = []
    for filter in filters:
        if "=" in filter:
            if "null" in filter:
                field_name, value = filter.split("=")
                conditions.append({"field_name": field_name, "operator": "isEmpty", "value": []})
            else:
                field_name, value = filter.split("=")
                conditions.append({"field_name": field_name, "operator": "is", "value": [value]})
        elif "!=" in filter:
            if "null" in filter:
                field_name, value = filter.split("!=")
                conditions.append({"field_name": field_name, "operator": "isNotEmpty", "value": []})
            else:
                field_name, value = filter.split("!=")
                conditions.append({"field_name": field_name, "operator": "isNot", "value": [value]})
        elif "<" in filter:
            field_name, value = filter.split("<")
            conditions.append({"field_name": field_name, "operator": "isLess", "value": [value]})
        elif ">" in filter:
            field_name, value = filter.split(">")
            conditions.append({"field_name": field_name, "operator": "isGreater", "value": [value]})
        elif "<=" in filter:
            field_name, value = filter.split("<=")
            conditions.append({"field_name": field_name, "operator": "isLessEqual", "value": [value]})
        elif ">=" in filter:
            field_name, value = filter.split(">=")
            conditions.append({"field_name": field_name, "operator": "isGreaterEqual", "value": [value]})
        elif "contains" in filter:
            field_name, value = filter.split(":contains:")
            conditions.append({"field_name": field_name, "operator": "contains", "value": [value]})
        elif "not-contains" in filter:
            field_name, value = filter.split(":not-contains:")
            conditions.append({"field_name": field_name, "operator": "doesNotContain", "value": [value]})
    
    return {"conditions": conditions}
            
            
            
            
            
            
            