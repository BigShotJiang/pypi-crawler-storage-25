from .auth import LarkParentInitializer
import requests
from typing import Any, Dict, List, Optional


class LarkTasks(LarkParentInitializer):
    def __init__(self, is_auth: bool = False, access_token: Optional[str] = None, bot_type: Optional[str] = "meeting"):
        super().__init__(is_auth, access_token, bot_type)
        self.headers = {
            "Authorization": f"Bearer {self.access_token if self.access_token is not None else self.tenant_access_token}",
            "Content-Type": "application/json",
        }

    def create(self, summary: str, description: str = "", due_timestamp: Optional[str] = None, assignee_ids: Optional[List[str]] = None) -> Dict[str, Any]:
        """Create a task. due_timestamp is a unix ms string e.g. '1712700000000'."""
        body: Dict[str, Any] = {"summary": summary, "description": description}
        if due_timestamp:
            body["due"] = {"timestamp": due_timestamp}
        if assignee_ids:
            body["members"] = [{"id": uid, "type": "user", "role": "assignee"} for uid in assignee_ids]
        response = requests.post(
            f"{self.base_url}/task/v2/tasks",
            headers=self.headers,
            json=body,
        )
        try:
            return self.process_response_contents(response, "data", {}).get("task", {})
        except Exception as e:
            raise Exception(f"Failed to create task: {str(e)}")

    def list(self, page_size: int = 50, page_token: str = "", completed: Optional[bool] = None) -> List[Dict[str, Any]]:
        """List tasks visible to the authenticated user."""
        params: Dict[str, Any] = {"page_size": page_size}
        if page_token:
            params["page_token"] = page_token
        if completed is not None:
            params["completed"] = str(completed).lower()
        response = requests.get(
            f"{self.base_url}/task/v2/tasks",
            headers=self.headers,
            params=params,
        )
        try:
            return self.process_response_contents(response, "data", {}).get("items", [])
        except Exception as e:
            raise Exception(f"Failed to list tasks: {str(e)}")

    def update(self, task_guid: str, summary: Optional[str] = None, description: Optional[str] = None, completed_at: Optional[str] = None, due_timestamp: Optional[str] = None) -> Dict[str, Any]:
        """Update an existing task by GUID."""
        task: Dict[str, Any] = {}
        update_fields: List[str] = []
        if summary is not None:
            task["summary"] = summary
            update_fields.append("summary")
        if description is not None:
            task["description"] = description
            update_fields.append("description")
        if completed_at is not None:
            task["completed_at"] = completed_at
            update_fields.append("completed_at")
        if due_timestamp is not None:
            task["due"] = {"timestamp": due_timestamp}
            update_fields.append("due")
        response = requests.patch(
            f"{self.base_url}/task/v2/tasks/{task_guid}",
            headers=self.headers,
            json={"task": task, "update_fields": update_fields},
        )
        try:
            return self.process_response_contents(response, "data", {}).get("task", {})
        except Exception as e:
            raise Exception(f"Failed to update task: {str(e)}")

    def get(self, task_guid: str) -> Dict[str, Any]:
        """Get a single task by GUID."""
        response = requests.get(
            f"{self.base_url}/task/v2/tasks/{task_guid}",
            headers=self.headers,
        )
        try:
            return self.process_response_contents(response, "data", {}).get("task", {})
        except Exception as e:
            raise Exception(f"Failed to get task: {str(e)}")

    def delete(self, task_guid: str) -> bool:
        """Delete a task by GUID. Returns True on success."""
        response = requests.delete(
            f"{self.base_url}/task/v2/tasks/{task_guid}",
            headers=self.headers,
        )
        try:
            code = self.process_response_contents(response, "code", -1)
            return code == 0
        except Exception as e:
            raise Exception(f"Failed to delete task: {str(e)}")
