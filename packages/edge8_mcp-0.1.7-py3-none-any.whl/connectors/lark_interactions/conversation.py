import json
from .auth import LarkParentInitializer

import os
from dotenv import load_dotenv
import sys
import requests
from typing import List, Dict, Any, Union, Optional
from uuid import uuid4

sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))


load_dotenv()

LARK_APP_ID = os.environ.get("LARK_APP_ID_CHAT_MGMT") or os.environ.get("LARK_APP_ID")
LARK_APP_SECRET = os.environ.get("LARK_APP_SECRET_CHAT_MGMT") or os.environ.get("LARK_APP_SECRET")

def process_rich_text(content):
    return list(map(lambda x: "\n".join(list(map(lambda a: f"{a}", x.values()))), content))

def filter_non_json(x):
    return x if  "\":" in x else '{"text":' + '"{x}"'.format(x=x) + '}'
    
class LarkChatGroups(LarkParentInitializer):
    def __init__(self, is_auth=False, access_token=None, bot_type: Optional[str] = "meeting"):
        super().__init__(is_auth, access_token, bot_type)
        self.headers = {
            "Authorization": f"Bearer {self.access_token if self.access_token is not None else self.tenant_access_token}",
            "Content-Type": "application/json",
        }
        self.chat_groups = self.get()["items"]
        self.chat_groups_ids = list(map(lambda x: x["chat_id"], self.chat_groups))
        self.chat_group_name_id = list(map(lambda x: {"chat_id": x["chat_id"], "name": x["name"]}, self.chat_groups))
        
    def get(
        self,
        user_id_type: Optional[str] = "open_id",
        sort_type: Optional[str] = "ByCreateTimeAsc",
        page_size: Optional[int] = 20,
        page_token: Optional[str] = None,
    ) -> Dict[str, Any]:
        params: Dict[str, Any] = {
            "user_id_type": user_id_type,
            "sort_type": sort_type,
            "page_size": page_size,
        }
        if page_token:
            params["page_token"] = page_token
        response = requests.get(
            f"{self.base_url}/im/v1/chats",
            headers=self.headers,
            params=params,
        )
        try:
            data = self.process_response_contents(response, "data", {})
            return {
                "items": data.get("items", []),
                "has_more": data.get("has_more", False),
                "page_token": data.get("page_token"),
            }
        except Exception as e:
            raise Exception(f"Failed to get chat groups: {str(e)}")
    
    def search(
        self,
        query: str,
        user_id_type: Optional[str] = "open_id",
        page_size: Optional[int] = 20,
    ):
        response = requests.get(
            f"{self.base_url}/im/v1/chats/search",
            headers=self.headers,
            params={
                "user_id_type": user_id_type,
                "query": query,
                "page_size": page_size,
            },
        )
        try:
            return self.process_response_contents(response, "data", {}).get("items", [])
        except Exception as e:
            raise Exception(f"Failed to search chat group: {str(e)}")
    
    def get_share_link(self, chat_id, validity_period: Optional[str] = "permanently"):
        response = requests.post(
            f"{self.base_url}/im/v1/chats/{chat_id}/link",
            headers=self.headers,
            json={ "validity_period": validity_period}
        )
        try:
            return self.process_response_contents(response, "data", {}).get("share_link", None)
        except Exception as e:
            raise Exception(f"Failed to get share link: {str(e)}")
        
    def add_user(self, chat_id, id_list: list[str], user_id_type: Optional[str] = "open_id"):
        response = requests.post(
            f"{self.base_url}/im/v1/chats/{chat_id}/members",
            headers=self.headers,
            params={
                "member_id_type": user_id_type,
                "succeed_type": 1,
            },
            json={
                "id_list": id_list,
            },
        )
        try:
            return self.process_response_contents(response, "data", {})
        except Exception as e:
            raise Exception(f"Failed to add user to chat group: {str(e)}")
    

class LarkChatMessages(LarkParentInitializer):
    def __init__(self, group_id=None, is_auth=False, access_token=None):
        super().__init__(is_auth, access_token)
        self.headers = {
            "Authorization": f"Bearer {self.tenant_access_token}",
            "Content-Type": "application/json",
        }
        self.chat_group_handler = LarkChatGroups(is_auth=True, access_token=access_token)
        self.group_id = group_id
        if group_id is not None:
            response = self.get_chat_history()
            if response.get("code") == 230002:
                bot_id = self.chat_group_handler.app_id
                self.chat_group_handler.add_user(chat_id=group_id, id_list=[bot_id], user_id_type="app_id")
                response = self.get_chat_history()
            elif response.get("code") != 0:
                print("Failed to get chat history: ", response)
                raise Exception("Failed to get chat history")
            self.messages = response.get("data", {}).get("items", [])
            self.msg_by_sender = list(map(lambda x: self.get_msg_by_type(x, ["post", "text"]), self.messages))
            self.msg_by_system = list(map(lambda x: self.get_msg_by_type(x, ["system"]), self.messages))
            self.msg_by_all = list(map(lambda x: self.get_msg_by_type(x, ["system", "post", "text"]), self.messages))
    
    def get_msg_by_type(self, x, types):
        if x["msg_type"] in types:
            return {
                "sender_id": "system" if x["msg_type"] == "system" else x["sender"]["id"],
                "content": json.loads(filter_non_json(x["body"]["content"])),
                "create_time": x["create_time"],
                "update_time": x["update_time"]
            }
    
        
    def get_chat_history(
        self,
        container_id_type: str = "chat", 
        thread_id: Optional[str] = None,
        start_time: Optional[str] = None, 
        end_time: Optional[str] = None, 
        sort_type: Optional[str] = "ByCreateTimeAsc", 
        page_size: Optional[int] = 20
    ):
        """
        Get chat history from Lark
        
        Args:
            container_id_type (str, optional): Type of container ID. Defaults to "chat".
            thread_id (Optional[str], optional): Thread ID. Defaults to None.
            start_time (Optional[str], optional): Start time. Defaults to None.
            end_time (Optional[str], optional): End time. Defaults to None.
            sort_type (Optional[str], optional): Sort type. Defaults to "ByCreateTimeAsc".
            page_size (Optional[int], optional): Page size. Defaults to 20.
        """
        
        response = requests.get(
            f"{self.base_url}/im/v1/messages",
            headers=self.headers,
            params={
                "container_id_type": container_id_type,
                "container_id": thread_id if thread_id is not None else self.group_id,
                "sort_type": sort_type,
                "page_size": page_size,
                "start_time": start_time,
                "end_time": end_time,
            },
        )
        
        try:    
            return self.response_data_and_error(response)
        except Exception as e:
            raise Exception(f"Failed to get chat history: {str(e)}")
    
    def get_reactions(self, message_id: str):
        response = requests.get(
            f"{self.base_url}/im/v1/messages/{message_id}/reactions",
            headers=self.headers,
        )
        
        return self.process_response_contents(response, "data", {})

    def send(
        self, 
        receive_id: str, 
        content: Union[str, List[Dict[str, Any]], Dict[str, Any]],
        receive_id_type: str = "user_id", 
        msg_type: str = "text", 
    ):
        """
        Send message to Lark
        
        Args:
            receive_id (str): ID of the recipient.
            content (str, optional): Content of the message. Defaults to "".
            receive_id_type (str, optional): Type of the recipient ID. Defaults to "user_id".
            msg_type (str, optional): Type of the message. Defaults to "text".
        """
        
        response = requests.post(
            f"{self.base_url}/im/v1/messages",
            headers=self.headers,
            params={
                "receive_id_type": receive_id_type,
            },
            json={
                "receive_id": receive_id,
                "msg_type": msg_type,
                "content": content,
                "uuid": str(uuid4()),
            },
        )
        try:
            return self.process_response_contents(response, "data", {})
        except Exception as e:
            raise Exception(f"Failed to send message: {str(e)}")
    
    def reply(
        self,
        message_id: str,
        content: Union[str, List[Dict[str, Union[str, List[str]]]]],
        msg_type: str = "text",
        reply_in_thread: bool = False,
    ):
        """
        Reply to a message in Lark

        Args:
            message_id (str): ID of the message to reply to.
            content (str, optional): Content of the message. Defaults to "".
            msg_type (str, optional): Type of the message. Defaults to "text".
            content (str, optional): Content of the message. Defaults to "".
        """

        response = requests.post(
            f"{self.base_url}/im/v1/messages/{message_id}/reply",
            headers=self.headers,
            json={
                "content": content,
                "msg_type": msg_type,
                "reply_in_thread": reply_in_thread,
                "uuid": str(uuid4()),
            },
        )

        try:
            return self.process_response_contents(response, "data", {})
        except Exception as e:
            raise Exception(f"Failed to reply to message: {str(e)}")

    def add_reaction(self, message_id: str, emoji_type: str) -> Dict[str, Any]:
        """Add an emoji reaction to a message.

        Args:
            message_id: The ID of the message to react to.
            emoji_type: Emoji type string (e.g. 'THUMBSUP', 'OK', 'SMILE').
        """
        response = requests.post(
            f"{self.base_url}/im/v1/messages/{message_id}/reactions",
            headers=self.headers,
            json={"reaction_type": {"emoji_type": emoji_type}},
        )
        try:
            return self.process_response_contents(response, "data", {})
        except Exception as e:
            raise Exception(f"Failed to add reaction: {str(e)}")