from .auth import LarkParentInitializer
import requests
import os
import sys

sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from typing import Optional
from utils.custom_types import LarkEventFilter, LarkCalendarEvent, LarkCalendarEventSummary, LarkEventAttendeeSimple, LarkEventAttendee

class LarkCalendars(LarkParentInitializer):
    def __init__(self, is_auth=False, access_token=None, bot_type: Optional[str] = "meeting"):
        super().__init__(is_auth, access_token, bot_type)
        self.headers = {
            "Authorization": f"Bearer {self.access_token if self.access_token is not None else self.tenant_access_token}",
            "Content-Type": "application/json",
        }
        
    def list(self, page_size: int = 100):
        response = requests.get(
            f"{self.base_url}/calendar/v4/calendars",
            headers=self.headers,
            params={"page_size": page_size},
        )
        try:
            return self.process_response_contents(response, "data", {}).get("items", [])
        except Exception as e:
            raise Exception(f"Failed to list all calendars: {str(e)}")
    
    def search(self, query: str, page_size: int = 50):
        response = requests.post(
            f"{self.base_url}/calendar/v4/calendars/search",
            headers=self.headers,
            params={"page_size": page_size},
            json={"query": query},
        )
        try:
            return self.process_response_contents(response, "data", {}).get("items", [])
        except Exception as e:
            raise Exception(f"Failed to search calendar: {str(e)}")

class LarkEvents(LarkParentInitializer):
    def __init__(self, is_auth=False, access_token=None, bot_type: Optional[str] = "meeting"):
        super().__init__(is_auth, access_token, bot_type)
        self.headers = {
            "Authorization": f"Bearer {self.access_token if self.access_token is not None else self.tenant_access_token}",
            "Content-Type": "application/json",
        }
        
    def list(self, calendar_id, start_time: Optional[int] = None, end_time: Optional[int] = None, anchor_time: Optional[int] = None,  page_size: int = 50):
        response = requests.get(
            f"{self.base_url}/calendar/v4/calendars/{calendar_id}/events",
            headers=self.headers,
            params={"page_size": page_size, "user_id_type": "open_id", "anchor_time": anchor_time, "start_time": start_time, "end_time": end_time},
        )
        try:
            return self.process_response_contents(response, "data", {}).get("items", [])
        except Exception as e:
            raise Exception(f"Failed to list all events: {str(e)}")
        
    def search(self, query, calendar_id, filter: LarkEventFilter, page_size: int = 100):
        response = requests.post(
            f"{self.base_url}/calendar/v4/calendars/{calendar_id}/events/search",
            headers=self.headers,
            params={"page_size": page_size, "user_id_type": "open_id"},
            json={"query": query, "filter": filter},
        )
        try:
            return self.process_response_contents(response, "data", {}).get("items", [])
        except Exception as e:
            raise Exception(f"Failed to search calendar event: {str(e)}")
    
    def get(self, calendar_id, event_id, user_id_type="open_id") -> LarkCalendarEvent:
        response = requests.get(
            f"{self.base_url}/calendar/v4/calendars/{calendar_id}/events/{event_id}",
            headers=self.headers,
            params={
                "user_id_type": user_id_type,
                "need_meeting_settings": True,
                "need_attendee": True,
                "max_attendee_num": 100,
            },
        )
        try:
            return self.process_response_contents(response, "data", {})
        except Exception as e:
            raise Exception(f"Failed to get event by ID: {str(e)}")
    
    def create(self, calendar_id, event_id, data: LarkCalendarEvent, user_id_type="open_id"):
        # NOTE: This method signature is incorrect — event_id in path is only for update/delete.
        # Use create_event() instead for creating new events.
        response = requests.post(
            f"{self.base_url}/calendar/v4/calendars/{calendar_id}/events/{event_id}",
            headers=self.headers,
            params={
                "user_id_type": user_id_type,
            },
            json=data,
        )
        try:
            return self.process_response_contents(response, "data", {})
        except Exception as e:
            raise Exception(f"Failed to create event: {str(e)}")

    def create_event(self, calendar_id: str, data: LarkCalendarEvent, user_id_type: str = "open_id") -> dict:
        """Create a new calendar event. Uses the correct POST endpoint without event_id in path."""
        response = requests.post(
            f"{self.base_url}/calendar/v4/calendars/{calendar_id}/events",
            headers=self.headers,
            params={"user_id_type": user_id_type},
            json=data,
        )
        try:
            return self.process_response_contents(response, "data", {}).get("event", {})
        except Exception as e:
            raise Exception(f"Failed to create event: {str(e)}")
    
    def update(self, calendar_id, event_id, data: LarkCalendarEvent, user_id_type="open_id"):
        response = requests.put(
            f"{self.base_url}/calendar/v4/calendars/{calendar_id}/events/{event_id}",
            headers=self.headers,
            params={
                "user_id_type": user_id_type,
            },
            json=data,
        )
        try:
            return self.process_response_contents(response, "data", {})
        except Exception as e:
            raise Exception(f"Failed to update event: {str(e)}")
    
    def delete(self, calendar_id, event_id, user_id_type="open_id"):
        response = requests.delete(
            f"{self.base_url}/calendar/v4/calendars/{calendar_id}/events/{event_id}",
            headers=self.headers,
            params={
                "user_id_type": user_id_type,
            },
        )
        try:
            code = self.process_response_contents(response, "code", 0)
            message = self.process_response_contents(response, "msg", '')
            if code == 0:
                return 'Event deleted successfully'
            
            return message
        except Exception as e:
            raise Exception(f"Failed to delete event: {str(e)}")
            
