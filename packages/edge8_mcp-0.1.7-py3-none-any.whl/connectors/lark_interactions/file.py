
import requests
import os
import sys

sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from typing import Optional
from utils.custom_types import LarkFileMetadata
from .auth import LarkParentInitializer
class LarkFiles(LarkParentInitializer):
    def __init__(self, is_auth=False, access_token=None, bot_type: Optional[str] = "meeting"):
        super().__init__(is_auth, access_token, bot_type)
        self.headers = {
            "Authorization": f"Bearer {self.access_token if self.access_token is not None else self.tenant_access_token}",
            "Content-Type": "application/json",
        }

    def list_files(self, page_size: Optional[int] = 50, page_token: Optional[str] = "", folder_token: Optional[str] = None):
        response = requests.get(
            f"{self.base_url}/drive/v1/files",
            headers=self.headers,
            params={
                "page_size": page_size, 
                "page_token": page_token, 
                "folder_token": folder_token
            },
        )
        print(response.json())
        try:
            return self.process_response_contents(response, "data", {}).get("files", [])
        except Exception as e:
            raise Exception(f"Failed to list files: {str(e)}")

    def create(self, folder_token, name):
        response = requests.post(
            f"{self.base_url}/drive/v1/files/create_folder",
            headers=self.headers,
            json={"folder_token": folder_token, "name": name},
        )
        try:
            return self.process_response_contents(response, "data", {})
        except Exception as e:
            raise Exception(f"Failed to create file: {str(e)}")

    def get_root_folder(self):
        response = requests.get(
            f"{self.base_url}/drive/explorer/v2/root_folder/meta",
            headers=self.headers,
        )
        try:
            return self.process_response_contents(response, "data", {})
        except Exception as e:
            raise Exception(f"Failed to get root folder: {str(e)}")
    
    def get_folder_metadata(self, folder_token):
        response = requests.get(
            f"{self.base_url}/drive/explorer/v2/folder/{folder_token}/meta",
            headers=self.headers,
        )
        try:
            return self.process_response_contents(response, "data", {})
        except Exception as e:
            raise Exception(f"Failed to get folder metadata: {str(e)}")
    
    def get_files_metadata(self, request_docs: list[LarkFileMetadata]):
        response = requests.post(
            f"{self.base_url}/drive/v1/metas/batch_query",
            headers=self.headers,
            json={
                "request_docs": request_docs,
                "with_url": True,
            }
        )
        try:
            return self.process_response_contents(response, "data", {})
        except Exception as e:
            raise Exception(f"Failed to get files metadata: {str(e)}")
        
    def search(self, query: str, object_types: list[str] = ["file"], owner_ids: Optional[list[str]] = None):
        response = requests.post(
            f"{self.base_url}/suite/docs-api/search/object",
            headers=self.headers,
            json={"search_key": query, "doc_types": object_types, "owner_ids": owner_ids},
        )
        try:
            return self.process_response_contents(response, "data", {}).get("docs_entities", [])
        except Exception as e:
            raise Exception(f"Failed to search files: {str(e)}")
        
    def delete(self, file_token: str, type: Optional[str] = "file"):
        response = requests.delete(
            f"{self.base_url}/drive/v1/files/{file_token}",
            headers=self.headers,
            params={"type": type}
        )
        try:
            return self.process_response_contents(response, "data", {})
        except Exception as e:
            raise Exception(f"Failed to delete file: {str(e)}")
        
    def download_file(self, file_token: str) -> bytes:
        response = requests.get(
            f"{self.base_url}/drive/v1/files/{file_token}/download",
            headers=self.headers,
        )
        try:
            return response.content
        except Exception as e:
            raise Exception(f"Failed to download file: {str(e)}")
        
class LarkFilesPermission(LarkFiles):
    def __init__(self, is_auth=False, access_token=None, bot_type: Optional[str] = "meeting"):
        super().__init__(is_auth, access_token, bot_type)
        self.headers = {
            "Authorization": f"Bearer {self.access_token if self.access_token is not None else self.tenant_access_token}",
            "Content-Type": "application/json",
        }
    
    def add(self, doc_token, user_id, permission_type,  user_id_type, file_type, need_notification: Optional[bool] = False):
        url = f'{self.base_url}/drive/v1/permissions/{doc_token}/members'
        params={"type":file_type, "need_notification": need_notification}
        body = {"member_id": user_id, "member_type": user_id_type, "perm": permission_type}
        response = requests.post(url, headers=self.headers, json=body, params=params)
        try:
            return self.process_response_contents(response, "data", {})
        except Exception as e:
            raise Exception(f"Failed to add permission: {str(e)}")
    
    def update(self, doc_token, user_id, permission_type, file_type, user_id_type = "open_id"):
        url = f'{self.base_url}/drive/v1/permissions/{doc_token}/members/{user_id}'
        params={"type":file_type, "need_notification": False}
        body = {"member_type": user_id_type, "perm": permission_type}
        response = requests.put(url, headers=self.headers, json=body, params=params)
        try:
            return self.process_response_contents(response, "data", {})
        except Exception as e:
            raise Exception(f"Failed to update permission: {str(e)}")
    
    def delete(self, doc_token, user_id, file_type, user_id_type = "open_id"):
        url = f'{self.base_url}/drive/v1/permissions/{doc_token}/members/{user_id}'
        params={"type":file_type, "member_type": user_id_type}
        response = requests.delete(url, headers=self.headers, params=params)
        try:
            return self.process_response_contents(response, "data", {})
        except Exception as e:
            raise Exception(f"Failed to delete permission: {str(e)}")


def main():
    user_auth_token = "eyJhbGciOiJFUzI1NiIsImZlYXR1cmVfY29kZSI6IkZlYXR1cmVPQXV0aEpXVFNpZ25fU0ciLCJraWQiOiI3NTY5Mzk1ODQwNTkzMDE4ODgxIiwidHlwIjoiSldUIn0.eyJqdGkiOiI3NTcwNjM1MTE5NjU2OTYzODAzIiwiaWF0IjoxNzYyNjc1ODQ3LCJleHAiOjE3NjI2ODMwNDcsInZlciI6InYxIiwidHlwIjoiYWNjZXNzX3Rva2VuIiwiY2xpZW50X2lkIjoiY2xpX2E4MTFiZDRjNzBmOTUwMmYiLCJzY29wZSI6ImNvbnRhY3Q6Y29udGFjdCBhdXRoOnVzZXIuaWQ6cmVhZCBtaW51dGVzOm1pbnV0ZXMgbWludXRlczptaW51dGVzLnRyYW5zY3JpcHQ6ZXhwb3J0IHZjOmV4cG9ydCB2YzptZWV0aW5nIHZjOm1lZXRpbmc6cmVhZG9ubHkgdmM6cmVjb3JkIHZjOnJlY29yZDpyZWFkb25seSBvZmZsaW5lX2FjY2VzcyBkaXJlY3Rvcnk6ZGVwYXJ0bWVudDpzZWFyY2ggZG9jczpkb2MgZG9jczpwZXJtaXNzaW9uLm1lbWJlciBkb2N4OmRvY3VtZW50IHdpa2k6bm9kZTptb3ZlIGRyaXZlOmRyaXZlIGRpcmVjdG9yeTplbXBsb3llZTpzZWFyY2ggY2FsZW5kYXI6Y2FsZW5kYXIgaW06Y2hhdCBpbTptZXNzYWdlIGJpdGFibGU6YXBwIiwiYXV0aF9pZCI6Ijc1NzA2MzUxMTU1MTcxODU3NTgiLCJhdXRoX3RpbWUiOjE3NjI2NzU4NDYsImF1dGhfZXhwIjoxNzk0MjExODQ2LCJ1bml0IjoibGFya3NnYXdzIiwidGVuYW50X3VuaXQiOiJsYXJrc2dhd3MiLCJvcGFxdWUiOnRydWUsImVuYyI6IkFpUWtBUUVDQU1ZREFBRUJBd0FDQVEwQUF3c0xBQUFBQXdBQUFBZEdaV0YwZFhKbEFBQUFFRzloZFhSb1gyOXdZWEYxWlY5cWQzUUFBQUFJVkdWdVlXNTBTV1FBQUFBQk1BQUFBQVJVYVcxbEFBQUFDakUzTmpJeE1qZ3dNREFQQUFRTUFBQUFBUW9BQVdMRklsbXZnQUFpQ3dBQ0FBQUFETUd4aWtsS1Rkb1hQSnpsdVFzQUF3QUFBRENCTnJSVmtjQXNHbmhydW9GRytyYUg5SWdiUXpmVTl0L25ldVlTSTdUbzN3R3hOUVQwV25SVmc4MTgwZDI4aWFJQUN3QUZBQUFBQ1d4aGNtdHpaMkYzY3dEZFkwZjFrdndaaFpBelNDdXk0Ymp2L0JWUEswbm9OK3IyMzV0V3hYc2RRZk5lSEFkRXNZTDhvTU44UjMrOFljaTRpbXdXTWNobEkvaGRsMUZnbkdhOW9vZy8yUG5qa0kvRjBTL2Rpd0UzZXhXNFUwaEc2SHRaMEZsWWJlY1NlTkpQQkdSOGFIaFZKUXc3ZG9iNkNXN01RUXMrVVVDWXRyc1k4UWVUUUJFL3lDbzJtY3dCbTZkMUZ3T00zSS9peDAvNGp4QT0iLCJlbmNfdmVyIjoidjEifQ.dAqyUzcxnWvv0_DXYKUGiimMfR4sKgCAWjFU_62_gxxZTXXYt6Q_AWHBKpiyaGMxCibOFxrlA4YCDXvFfJJ8Eg"
    lark_files = LarkFiles(is_auth=True, access_token=user_auth_token)
    search_result = lark_files.search("Test Base")
    print(search_result)

if __name__ == "__main__":
    main()

__all__ = ["LarkFiles"]
