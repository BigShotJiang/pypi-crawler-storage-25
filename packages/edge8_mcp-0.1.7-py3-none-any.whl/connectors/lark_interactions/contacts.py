from .auth import LarkParentInitializer
import requests
from typing import Optional

class Users(LarkParentInitializer):
    def __init__(self, is_auth=False, access_token=None, bot_type: Optional[str] = "meeting"):
        super().__init__(is_auth, access_token, bot_type)
        self.headers = {
            "Authorization": f"Bearer {self.access_token if self.access_token is not None else self.tenant_access_token}",
            "Content-Type": "application/json",
        }
    
    def get_current_user(self):
        response = requests.get(
            f"{self.base_url}/authen/v1/user_info",
            headers=self.headers,
        )
        try:
            return self.process_response_contents(response, "data", {})
        except Exception as e:
            raise Exception(f"Failed to get current user: {str(e)}")
    
    def get_single_user(self, id, id_type: Optional[str]="open_id", department_id_type: Optional[str]="open_department_id"):
        response = requests.get(
            f"{self.base_url}/contact/v3/users/{id}",
            headers=self.headers,
            params={"user_id_type": id_type, "department_id_type": department_id_type},
        )
        try:
            return self.process_response_contents(response, "data", {}).get("user", {})
        except Exception as e:
            raise Exception(f"Failed to get single user: {str(e)}")
    
    def search(self, query: str, page_size: int=200):
        response = requests.get(
            f"{self.base_url}/search/v1/user",
            headers=self.headers,
            params={"query": query, "page_size": page_size},
        )
        try:
            return self.process_response_contents(response, "data", {}).get("users", [])
        except Exception as e:
            raise Exception(f"Failed to search users: {str(e)}")
    
    def list_by_department(self, department_id, user_id_type="open_id", department_id_type="open_department_id", page_size=20, page_token=""):
        response = requests.get(
            f"{self.base_url}/contact/v3/users/find_by_department",
            headers=self.headers,
            params={
                "department_id": department_id,
                "user_id_type": user_id_type,
                "department_id_type": department_id_type,
                "page_size": page_size,
                "page_token": page_token,
            },
        )
        try:
            return self.process_response_contents(response, "data", {}).get("items", [])
        except Exception as e:
            raise Exception(f"Failed to list users by department: {str(e)}")

class Departments(LarkParentInitializer):
    def __init__(self, is_auth=False, access_token=None, bot_type: Optional[str] = "meeting"):
        super().__init__(is_auth, access_token, bot_type)
        self.headers = {
            "Authorization": f"Bearer {self.access_token if self.access_token is not None else self.tenant_access_token}",
            "Content-Type": "application/json",
        }
    
    # Use search for department API to get department ID
    def get(self, department_id):
        response = requests.get(
            f"{self.base_url}/contact/v3/departments/{department_id}",
            headers=self.headers,
        )
        try:
            return self.process_response_contents(response, "data", {}).get("department", {})
        except Exception as e:
            raise Exception(f"Failed to get department ID: {str(e)}")
    
    def list_department_members(self, department_id, user_id_type="open_id", department_id_type="open_department_id", page_size=20, page_token=""):
        response = requests.get(
            f"{self.base_url}/contact/v3/users/find_by_department",
            headers=self.headers,
            params={"department_id": department_id, "user_id_type": user_id_type, "department_id_type": department_id_type, "page_size": page_size, "page_token": page_token},
        )
        try:
            return self.process_response_contents(response, "data", {}).get("items", [])
        except Exception as e:
            raise Exception(f"Failed to get department members: {str(e)}")

    def search(self, query: str, page_size: int=200, user_id_type: str="open_id", department_id_type: str="open_department_id"):
        response = requests.post(
            f"{self.base_url}/search/v3/departments/search",
            headers=self.headers,
            params={
                "page_size": page_size,
                "user_id_type": user_id_type,
                "department_id_type": department_id_type,
            },
            json={"query": query},
        )
        try:
            return self.process_response_contents(response, "data", {}).get("items", [])
        except Exception as e:
            raise Exception(f"Failed to search users: {str(e)}")

class Organizations(LarkParentInitializer):
    def __init__(self, is_auth=False, access_token=None, bot_type: Optional[str] = "meeting"):
        super().__init__(is_auth, access_token, bot_type)
        self.headers = {
            "Authorization": f"Bearer {self.access_token if self.access_token is not None else self.tenant_access_token}",
            "Content-Type": "application/json",
        }
        
    def search_employee(
        self, 
        query: str, 
        page_size: int=50, 
        employee_id_type: str="open_id", 
        department_id_type: str="open_department_id",
        selections: Optional[str] = None,
    ):
        required_fields = [
            "base_info.employee_id",
            "base_info.name",
            "base_info.email",
            "base_info.departments.department_path_infos",
        ]
        if selections is not None:
            required_fields = ["base_info." + item for item in selections.replace(" ", "").split(",")]
        
        response = requests.post(
            f"{self.base_url}/directory/v1/employees/search",
            headers=self.headers,
            params={
                "employee_id_type": employee_id_type,
                "department_id_type": department_id_type,
            },
            json={
                "query": query,
                "page_request": {
                    "page_size": page_size,
                },
                "required_fields":required_fields,
            },
        )
        try:
            return self.process_response_contents(response, "data", {}).get("employees", [])
        except Exception as e:
            raise Exception(f"Failed to search users: {str(e)}")
    
    def search_department(
        self, 
        query: str, 
        page_size: int=200, 
        employee_id_type: str="open_id", 
        department_id_type: str="open_department_id",
        selections: Optional[str] = None,
    ):
        required_fields = ["*"]
        if selections is not None:
            required_fields = selections.replace(" ", "").split(",")
        
        response = requests.post(
            f"{self.base_url}/directory/v1/departments/search",
            headers=self.headers,
            params={
                "employee_id_type": employee_id_type,
                "department_id_type": department_id_type,
            },
            json={
                "query": query,
                "page_request": {
                    "page_size": page_size,
                },
                "required_fields":required_fields,
            },
        )
        try:
            return self.process_response_contents(response, "data", {}).get("departments", [])
        except Exception as e:
            raise Exception(f"Failed to search users: {str(e)}")
    

__all__ = ["Users", "GetDepartmentInfo"]

