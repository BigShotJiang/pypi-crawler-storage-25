from .auth import LarkParentInitializer
import requests
from typing import Optional

class LarkDocs(LarkParentInitializer):
    def __init__(self, is_auth=False, access_token=None, bot_type: Optional[str] = "meeting"):
        super().__init__(is_auth, access_token, bot_type)
        self.headers = {
            "Authorization": f"Bearer {self.access_token if self.access_token is not None else self.tenant_access_token}",
            "Content-Type": "application/json",
        }

    def create(self, folder_token: Optional[str] = None, title: Optional[str] = None):
        url = f'{self.base_url}/docx/v1/documents'
        body = {"folder_token": folder_token, "title": title}
        response = requests.post(url, headers=self.headers, json=body)
        try:
            return self.process_response_contents(response, "data", {}).get("document", {})
        except Exception as e:
            raise Exception(f"Failed to create document: {str(e)}")

    def get(self, doc_id):
        url = f'{self.base_url}/docx/v1/documents/{doc_id}'
        response = requests.get(url, headers=self.headers)
        try:
            return self.process_response_contents(response, "data", {}).get("document", {})
        except Exception as e:
            raise Exception(f"Failed to get document: {str(e)}")

    def get_raw_content(self, doc_id):
        url = f'{self.base_url}/docx/v1/documents/{doc_id}/raw_content'
        response = requests.get(url, headers=self.headers)
        try:
            return self.process_response_contents(response, "data", {}).get("content", "")
        except Exception as e:
            raise Exception(f"Failed to get plain text: {str(e)}")
    
    def get_content(self, doc_id, doc_type: str  = 'docx', content_type: str = 'markdown', lang: str = 'en'):
        url = f'{self.base_url}/docx/v1/documents/content'
        params = {"doc_token": doc_id, "doc_type": doc_type, "content_type": content_type, "lang": lang}
        response = requests.get(url, headers=self.headers, params=params)
        try:
            return self.process_response_contents(response, "data", {}).get("content", [])
        except Exception as e:
            raise Exception(f"Failed to get blocks: {str(e)}")
    
    def search(
      self, 
      search_key: str, 
      count: Optional[int] = None, 
      offset: Optional[int] = None, 
      owner_ids: Optional[list[str]] = None, 
      chat_ids: Optional[list[str]] = None, 
      docs_types: Optional[list[str]] = None
    ):
        url = f'{self.base_url}/suite/docs-api/search/object'
        body = {"search_key": search_key, "count": count, "offset": offset, "owner_ids": owner_ids, "chat_ids": chat_ids, "docs_types": docs_types}
        response = requests.post(url, headers=self.headers, json=body)
        print("Response: ", response)
        try:
            return self.process_response_contents(response, "data", {}).get('docs_entities', [])
        except Exception as e:
            raise Exception(f"Failed to search: {str(e)}")


class LarkDocsContent(LarkParentInitializer):
    def __init__(self, is_auth=False, access_token=None, bot_type: Optional[str] = "meeting"):
        super().__init__(is_auth, access_token, bot_type)
        self.headers = {
            "Authorization": f"Bearer {self.access_token if self.access_token is not None else self.tenant_access_token}",
            "Content-Type": "application/json",
        }

    def get(self, doc_id, block_id, doc_revision, id_type):
        url = f'{self.base_url}/docx/v1/documents/{doc_id}/blocks/{block_id}'
        params = {"document_revision_id": doc_revision, "user_id_type": id_type}
        response = requests.get(url, headers=self.headers, params=params)
        try:
            return self.process_response_contents(response, "data", {})
        except Exception as e:
            raise Exception(f"Failed to get: {str(e)}")

    def content_to_blocks(self, id_type, content, content_type="markdown"):
        url = f"{self.base_url}/docx/v1/documents/blocks/convert"
        params = {"user_id_type": id_type}
        body = {"content_type": content_type, "content": content}
        headers = {
            "Authorization": f"Bearer {self.tenant_access_token}",
            "Content-Type": "application/json",
        }
        response = requests.post(url, headers=headers, json=body, params=params)
        try:
            return self.process_response_contents(response, "data", {})
        except Exception as e:
            raise Exception(f"Failed to convert content to blocks: {str(e)}")

    def create_nested_blocks(self, doc_id, block_id, id_type, children_id, blocks):
        url = f"{self.base_url}/docx/v1/documents/{doc_id}/blocks/{block_id}/descendant"
        params = {"user_id_type": id_type}
        body = {"children_id": children_id, "descendants": blocks}
        response = requests.post(url, headers=self.headers, json=body, params=params)
        try:
            return self.process_response_contents(response, "data", {})
        except Exception as e:
            raise Exception(f"Failed to create nested blocks: {str(e)}")

    def text_to_blocks(self, doc_id: str, block_id: str, id_type: Optional[str] = "open_id", content: str = "", content_type: Optional[str] = "markdown"):
        try:
            conversion_reponse = self.content_to_blocks(id_type, content, content_type)
            children_id = conversion_reponse.get("first_level_block_ids", "")
            blocks = conversion_reponse.get("blocks", [])

            converted_blocks = self.create_nested_blocks(
                doc_id, block_id, id_type, children_id, blocks
            )
            
            return converted_blocks
        except Exception as e:
            raise Exception(f"Failed to convert content to blocks: {str(e)}")
    
    
class LarkDocComments(LarkParentInitializer):
    def __init__(self, is_auth: bool = False, access_token=None, bot_type=None):
        super().__init__(is_auth, access_token, bot_type or "meeting")
        self.headers = {
            "Authorization": f"Bearer {self.access_token if self.access_token is not None else self.tenant_access_token}",
            "Content-Type": "application/json",
        }

    def list(self, doc_token: str, doc_type: str = "docx") -> list:
        """List all comments on a document."""
        response = requests.get(
            f"{self.base_url}/comment/v1/comments",
            headers=self.headers,
            params={"token": doc_token, "file_type": doc_type},
        )
        try:
            return self.process_response_contents(response, "data", {}).get("items", [])
        except Exception as e:
            raise Exception(f"Failed to list comments: {str(e)}")

    def add(self, doc_token: str, content: str, doc_type: str = "docx") -> dict:
        """Add a whole-document comment."""
        body = {
            "token": doc_token,
            "file_type": doc_type,
            "comment_list": [{"content": [{"type": "text", "text": content}]}],
        }
        response = requests.post(
            f"{self.base_url}/comment/v1/comments",
            headers=self.headers,
            json=body,
        )
        try:
            return self.process_response_contents(response, "data", {}).get("comment", {})
        except Exception as e:
            raise Exception(f"Failed to add comment: {str(e)}")


__all__ = ["LarkDocs", "LarkDocComments"]
