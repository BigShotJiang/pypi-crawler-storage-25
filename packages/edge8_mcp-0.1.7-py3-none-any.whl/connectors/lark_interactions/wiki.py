from .auth import LarkParentInitializer
import requests
from typing import Optional
from utils.custom_types import LarkWikiNode

class Wiki(LarkParentInitializer):
    space_id: Optional[str] = ""
    node_token: Optional[str] = ""
    
    def __init__(self, is_auth=False, access_token=None, bot_type: Optional[str] = "meeting"):
        super().__init__(is_auth, access_token, bot_type)
        self.headers = {
            "Authorization": f"Bearer {self.access_token if self.access_token is not None else self.tenant_access_token}",
            "Content-Type": "application/json",
        }
    
    def create_space(self, name: str, description: Optional[str] = ""):
        response = requests.post(
            f"{self.base_url}/wiki/v2/spaces",
            headers=self.headers,
            json={"name": name, "description": description},
        )
        space_data = self.process_response_contents(response, "data", {}).get("space", {})
        self.space_id = space_data.get("space_id", "")
        return space_data
    
    def list_spaces(self, page_size: Optional[int] = 50, page_token: Optional[str] = ""):
        response = requests.get(
            f"{self.base_url}/wiki/v2/spaces",
            headers=self.headers,
            params={"page_size": page_size, "page_token": page_token},
        )
        try:
            return self.process_response_contents(response, "data", {}).get("items", [])
        except Exception as e:
            raise Exception(f"Failed to list spaces: {str(e)}")
      
    def get_space(self, space_id: str):
        response = requests.get(
            f"{self.base_url}/wiki/v2/spaces/{space_id}",
            headers=self.headers,
        )
        try:
            return self.process_response_contents(response, "data", {}).get("space", {})
        except Exception as e:
            raise Exception(f"Failed to get space: {str(e)}")
      
    def search(
      self, 
      query: str, 
      space_id: Optional[str] = None, 
      node_id: Optional[str] = None, 
      page_size: Optional[int] = 50, 
      page_token: Optional[str] = None
    ):
      response = requests.post(
        f"{self.base_url}/wiki/v2/nodes/search",
        headers=self.headers,
        json={"query": query, "space_id": space_id, "node_id": node_id, "page_size": page_size, "page_token": page_token},
      )
      try:
          return self.process_response_contents(response, "data", {}).get("items", [])
      except Exception as e:
          raise Exception(f"Failed to search: {str(e)}")

class Nodes(Wiki):
  def __init__(self, space_id: Optional[str] = "", is_auth=False, access_token=None, bot_type: Optional[str] = "meeting"):
    super().__init__(is_auth, access_token, bot_type)
    self.space_id = space_id
    
  def create(self, data: LarkWikiNode):
    response = requests.post(
      f"{self.base_url}/wiki/v2/nodes",
      headers=self.headers,
      json=data,
    )
    
    try:
        return self.process_response_contents(response, "data", {}).get("node", {})
    except Exception as e:
        raise Exception(f"Failed to create node: {str(e)}")
    
  
  def get(self, node_token):
    response = requests.get(
      f"{self.base_url}/wiki/v2/spaces/get_node",
      headers=self.headers,
      params={"token": node_token}
    )
    try:
        return self.process_response_contents(response, "data", {}).get("node", {})
    except Exception as e:
        raise Exception(f"Failed to get node: {str(e)}")
  
  def list(self, page_size: Optional[int] = 50, page_token: Optional[str] = ""):
    response = requests.get(
      f"{self.base_url}/wiki/v2/spaces/{self.space_id}/nodes",
      headers=self.headers,
      params={"page_size": page_size, "page_token": page_token}
    )
    try:
        return self.process_response_contents(response, "data", {}).get("items", [])
    except Exception as e:
        raise Exception(f"Failed to list nodes: {str(e)}")
  
  def move(
    self,
    node_token: str, 
    target_node_token: str, 
    space_id: Optional[str] = None, 
    target_space_id: Optional[str] = None
  ):
    body = {"target_space_id": target_space_id} if target_space_id else {"target_node_token": target_node_token}
    response = requests.post(
      f"{self.base_url}/wiki/v2/spaces/move_node",
      headers=self.headers,
      params={"space_id": space_id or self.space_id, "node_token": node_token},
      json=body
    )
    try:
        return self.process_response_contents(response, "data", {}).get("node", {})
    except Exception as e:
        raise Exception(f"Failed to move node: {str(e)}")