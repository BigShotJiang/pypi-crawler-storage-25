from .auth import LarkParentInitializer
import requests
from typing import Any, Dict, List, Optional


class LarkSheets(LarkParentInitializer):
    def __init__(self, is_auth: bool = False, access_token: Optional[str] = None, bot_type: Optional[str] = "meeting"):
        super().__init__(is_auth, access_token, bot_type)
        self.headers = {
            "Authorization": f"Bearer {self.access_token if self.access_token is not None else self.tenant_access_token}",
            "Content-Type": "application/json",
        }

    def get_spreadsheet(self, spreadsheet_token: str) -> Dict[str, Any]:
        response = requests.get(
            f"{self.base_url}/sheets/v3/spreadsheets/{spreadsheet_token}",
            headers=self.headers,
        )
        try:
            return self.process_response_contents(response, "data", {}).get("spreadsheet", {})
        except Exception as e:
            raise Exception(f"Failed to get spreadsheet: {str(e)}")

    def read_values(self, spreadsheet_token: str, range: str) -> Dict[str, Any]:
        """Read cell values from a range (e.g. 'Sheet1!A1:D10')."""
        response = requests.get(
            f"{self.base_url}/sheets/v2/spreadsheets/{spreadsheet_token}/values/{range}",
            headers=self.headers,
        )
        try:
            return self.process_response_contents(response, "data", {}).get("valueRange", {})
        except Exception as e:
            raise Exception(f"Failed to read values: {str(e)}")

    def write_values(self, spreadsheet_token: str, range: str, values: List[List[Any]]) -> Dict[str, Any]:
        """Write values to a range. values is a 2D list (rows × cols)."""
        body = {"valueRange": {"range": range, "values": values}}
        response = requests.put(
            f"{self.base_url}/sheets/v2/spreadsheets/{spreadsheet_token}/values",
            headers=self.headers,
            json=body,
        )
        try:
            return self.process_response_contents(response, "data", {})
        except Exception as e:
            raise Exception(f"Failed to write values: {str(e)}")

    def append_values(self, spreadsheet_token: str, range: str, values: List[List[Any]]) -> Dict[str, Any]:
        """Append rows after the last non-empty row in range."""
        body = {"valueRange": {"range": range, "values": values}}
        response = requests.post(
            f"{self.base_url}/sheets/v2/spreadsheets/{spreadsheet_token}/values_append",
            headers=self.headers,
            json=body,
        )
        try:
            return self.process_response_contents(response, "data", {})
        except Exception as e:
            raise Exception(f"Failed to append values: {str(e)}")
