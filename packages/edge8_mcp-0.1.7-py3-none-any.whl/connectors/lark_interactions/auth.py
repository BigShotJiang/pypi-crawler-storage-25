import requests
import json
import os
from dotenv import load_dotenv
from typing import Optional
from utils.response_parser import response_data_and_error, process_response_contents

# Load environment variables
load_dotenv()

_DEFAULT_APP_ID = os.environ.get("LARK_APP_ID")
_DEFAULT_APP_SECRET = os.environ.get("LARK_APP_SECRET")

BOT_NAME_MAPPING = {
    "chat_mgmt": {
        "app_id": os.environ.get("LARK_APP_ID_CHAT_MGMT") or _DEFAULT_APP_ID,
        "app_secret": os.environ.get("LARK_APP_SECRET_CHAT_MGMT") or _DEFAULT_APP_SECRET
    },
    "meeting": {
        "app_id": os.environ.get("LARK_APP_ID_MEETING") or _DEFAULT_APP_ID,
        "app_secret": os.environ.get("LARK_APP_SECRET_MEETING") or _DEFAULT_APP_SECRET
    },
    "story_gen": {
        "app_id": os.environ.get("LARK_APP_ID_STORYGEN") or _DEFAULT_APP_ID,
        "app_secret": os.environ.get("LARK_APP_SECRET_STORYGEN") or _DEFAULT_APP_SECRET
    },
    "learning": {
        "app_id": os.environ.get("LARK_APP_ID_LEARNING") or _DEFAULT_APP_ID,
        "app_secret": os.environ.get("LARK_APP_SECRET_LEARNING") or _DEFAULT_APP_SECRET
    }
}

DEFAULT_SCOPES = [
    # Authentication & User Identity
    'auth:user.id:read',
    'offline_access',
    
    # Contact & Directory
    'contact:contact',
    'contact:contact.base:readonly',
    'contact:user.email:readonly',
    'contact:user.employee:readonly',
    'contact:user.employee_id:readonly',
    'contact:user.id:readonly',
    'contact:user:search',
    'contact:user.department:readonly',
    'directory:department:search',
    'directory:employee:search',
    
    # Video Conferencing & Meetings
    'vc:export',
    'vc:meeting',
    'vc:meeting:readonly',
    'vc:record',
    'vc:record:readonly',
    'minutes:minutes',
    'minutes:minutes.transcript:export',
    'minutes:minutes.media:export',
    # 'vc:alert:readonly',
    # 'vc:reserve',
    
    # Documents & Drive
    'docs:doc',
    'docs:permission.member',
    'docx:document',
    'drive:drive',
    'sheets:spreadsheet',
    
    # Wiki
    'wiki:node:move',
    'wiki:wiki',
    'wiki:wiki:readonly',
    'wiki:space:retrieve',
    
    # Calendar
    'calendar:calendar',
    
    # Instant Messaging
    'im:chat',
    'im:message',
    
    # Bitable (Base)
    'bitable:app',
    
    # Email
    'mail:user_mailbox.event.mail_address:read',
    'mail:user_mailbox.folder:read',
    'mail:user_mailbox.mail_contact.mail_address:read',
    'mail:user_mailbox.message.address:read',
    'mail:user_mailbox.message.body:read',
    'mail:user_mailbox.message:readonly',
    'mail:user_mailbox.message:send',
]

BASE_REDIRECT_URL = os.getenv("LARK_REDIRECT_URL", "https://edge8-automation-mcp.vercel.app/api/v1/lark/authorize")

def _get_credential_store_creds() -> tuple[Optional[str], Optional[str]]:
    """Try to get Lark credentials from the MCP credential store."""
    try:
        # Import here to avoid circular dependency issues at module load time
        from mcp_server.credential_store import _get_service, _decrypt
        service_data = _get_service("lark")
        app_id = service_data.get("app_id")
        app_secret_enc = service_data.get("app_secret", "")
        if app_id and app_secret_enc:
            # Decrypt if encrypted, otherwise use as-is
            if app_secret_enc.startswith("$MCPENC$"):
                app_secret = _decrypt(app_secret_enc)
            else:
                app_secret = app_secret_enc
            return app_id, app_secret
    except Exception:
        pass
    return None, None


class LarkParentInitializer:
    def __init__(self, is_auth=False, access_token=None, bot_type: Optional[str] ="meeting"):
        bot_creds = BOT_NAME_MAPPING.get(bot_type) or {}
        # Priority: 1) env vars, 2) credential store, 3) defaults
        store_app_id, store_app_secret = _get_credential_store_creds()
        self.app_id = bot_creds.get("app_id") or _DEFAULT_APP_ID or store_app_id
        self.app_secret = bot_creds.get("app_secret") or _DEFAULT_APP_SECRET or store_app_secret
        self.base_url = os.getenv("LARK_BASE_URL", "https://open.larksuite.com/open-apis")
        self.app_access_token_url = f"{self.base_url}/auth/v3/app_access_token/internal/"
        self.access_token = access_token
        self.response_data_and_error = response_data_and_error
        self.process_response_contents = process_response_contents
        self.tenant_access_token = self.get_tenant_access_token()
        
    def get_tenant_access_token(self):
        url = f"{self.base_url}/auth/v3/tenant_access_token/internal/"
        response = requests.post(
            url,
            headers={"Content-Type": "application/json; charset=utf-8"},
            json={"app_id": self.app_id, "app_secret": self.app_secret},
        )
        return self.process_response_contents(response, "tenant_access_token", "")
    
    def get_bot_info(self):
        response = requests.get(
            f"{self.base_url}/bot/v3/info",
            headers={
                "Authorization": f"Bearer {self.tenant_access_token}",
                "Content-Type": "application/json",
            },
        )
        try:
            return self.process_response_contents(response, "bot", {})
        except Exception as e:
            raise Exception(f"Failed to get bot info: {str(e)}")

    def get_app_access_token(self):
        request_body = {
            "app_id": self.app_id,
            "app_secret": self.app_secret
        }
        
        response = requests.post(self.app_access_token_url, json=request_body)
        
        if response.status_code != 200:
            raise Exception("Failed to get app access token")
        
        return self.process_response_contents(response, "app_access_token", "")
    
class LarkAuth(LarkParentInitializer):
    def __init__(self, bot_type: Optional[str] = "meeting"):
        super().__init__(bot_type=bot_type)
        self.access_token = None
        self.refresh_token = None
        self.expire_time = None
        self.refresh_token_expire_time = None
        self.tenant_access_token_url = f"{self.base_url}/auth/v3/tenant_access_token/internal/"
        self.oauth_url='https://accounts.larksuite.com/open-apis/authen/v1/authorize'
        self.user_access_token_url=f'{self.base_url}/authen/v2/oauth/token'
    
    def oauth_code(self, redirect_uri: Optional[str] = None, scope: Optional[str] = None, action_type: Optional[str] = None, meeting_id: Optional[str] = None):
      redirect_query_params = f"?type={action_type}" if action_type is not None else ""
      if meeting_id is not None:
        redirect_query_params += f"&meeting_id={meeting_id}"
      if action_type is None:
        redirect_query_params = redirect_query_params.replace("&", "?", 1)
      redirect_uri = f"{BASE_REDIRECT_URL}{redirect_query_params}" if redirect_uri is None else redirect_uri
      scope = " ".join(DEFAULT_SCOPES) if scope is None else scope
      response = requests.get(f"{self.oauth_url}?client_id={self.app_id}&redirect_uri={redirect_uri}&scope={scope}")
      
      if not response.ok:
        raise Exception("Failed to get OAuth code")
      return response.url
  
    def get_user_access_token(self, code, type: Optional[str] = None, meeting_id: Optional[str] = None):
        scope = " ".join(DEFAULT_SCOPES)
        headers = {
            "Content-Type": "application/json; charset=utf-8"
        }
        params = []
        if type:
            params.append(f"type={type}")
        if meeting_id:
            params.append(f"meeting_id={meeting_id}")
        qs = ("?" + "&".join(params)) if params else ""
        redirect_uri = f"{BASE_REDIRECT_URL}{qs}"
        request_body = {
            "grant_type": "authorization_code",
            "code": code,
            "scope": scope,
            "client_id": self.app_id,
            "client_secret": self.app_secret,
            "redirect_uri": redirect_uri
        }
        
        response = requests.post(
            self.user_access_token_url, 
            json=request_body, 
            headers=headers
        )
        
        if response.status_code != 200:
            print("response: ", response.json())
            raise Exception("Failed to get user access token")
    
        return response.json()
    
    def refresh_access_token(self, refresh_token):  
        scope = " ".join(DEFAULT_SCOPES)
        
        headers = {
            "Content-Type": "application/json; charset=utf-8"
        }
        request_body = {
            "grant_type": "refresh_token",
            "refresh_token": refresh_token,
            "client_id": self.app_id,
            "client_secret": self.app_secret,
            "scope": scope
        }
        response = requests.post(
            self.user_access_token_url, 
            json=request_body, 
            headers=headers
        )
        
        if response.status_code != 200:
            print("response: ", response.json())
            raise Exception("Failed to refresh access token")
        
        return response.json()
        
    
        
__all__ = ["LarkAuth"]
