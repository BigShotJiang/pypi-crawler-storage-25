"""Web scraping utilities using httpx and BeautifulSoup4."""
from __future__ import annotations

import httpx
from typing import TYPE_CHECKING, Dict, List, Optional

if TYPE_CHECKING:
    from bs4 import BeautifulSoup
from dataclasses import dataclass, field
import logging
from urllib.parse import urlparse

logger = logging.getLogger(__name__)


@dataclass
class WebPageInfo:
    """Structured information extracted from a webpage."""
    url: str
    title: Optional[str] = None
    description: Optional[str] = None
    headings: List[str] = field(default_factory=list)
    paragraphs: List[str] = field(default_factory=list)
    links: List[Dict[str, str]] = field(default_factory=list)
    images: List[Dict[str, str]] = field(default_factory=list)
    metadata: Dict[str, str] = field(default_factory=dict)
    text_content: Optional[str] = None


class WebScraper:
    """Simple web scraper using httpx and BeautifulSoup4."""
    
    def __init__(self, timeout: int = 30, max_content_length: int = 10_000_000):
        self.timeout = timeout
        self.max_content_length = max_content_length
        self.headers = {
            'User-Agent': 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36'
        }
    
    async def fetch_html(self, url: str) -> str:
        """Fetch HTML content from a URL."""
        async with httpx.AsyncClient(timeout=self.timeout, follow_redirects=True) as client:
            response = await client.get(url, headers=self.headers)
            response.raise_for_status()
            return response.text
    
    def parse_html(self, html: str, parser: str = 'lxml') -> BeautifulSoup:
        """Parse HTML into BeautifulSoup object."""
        from bs4 import BeautifulSoup
        return BeautifulSoup(html, parser)
    
    def extract_title(self, soup: BeautifulSoup) -> Optional[str]:
        """Extract page title."""
        title_tag = soup.find('title')
        if title_tag:
            return title_tag.get_text().strip()
        h1_tag = soup.find('h1')
        if h1_tag:
            return h1_tag.get_text().strip()
        return None
    
    def extract_description(self, soup: BeautifulSoup) -> Optional[str]:
        """Extract meta description."""
        meta_desc = soup.find('meta', attrs={'name': 'description'})
        if meta_desc and meta_desc.get('content'):
            return meta_desc['content'].strip()
        og_desc = soup.find('meta', attrs={'property': 'og:description'})
        if og_desc and og_desc.get('content'):
            return og_desc['content'].strip()
        return None
    
    def extract_headings(self, soup: BeautifulSoup, max_headings: int = 50) -> List[str]:
        """Extract all headings (h1-h6)."""
        headings = []
        for tag in ['h1', 'h2', 'h3', 'h4', 'h5', 'h6']:
            for heading in soup.find_all(tag, limit=max_headings):
                text = heading.get_text().strip()
                if text:
                    headings.append(text)
        return headings[:max_headings]
    
    def extract_paragraphs(self, soup: BeautifulSoup, max_paragraphs: int = 100) -> List[str]:
        """Extract all paragraph text."""
        paragraphs = []
        for p in soup.find_all('p', limit=max_paragraphs):
            text = p.get_text().strip()
            if text and len(text) > 20:
                paragraphs.append(text)
        return paragraphs
    
    def extract_text_content(self, soup: BeautifulSoup) -> str:
        """Extract all visible text content."""
        for script in soup(['script', 'style', 'nav', 'footer', 'header']):
            script.decompose()
        text = soup.get_text(separator='\n', strip=True)
        lines = [line.strip() for line in text.splitlines() if line.strip()]
        return '\n'.join(lines)
    
    async def scrape_url(self, url: str) -> WebPageInfo:
        """Scrape a URL and extract all basic information."""
        html = await self.fetch_html(url)
        soup = self.parse_html(html)
        
        return WebPageInfo(
            url=url,
            title=self.extract_title(soup),
            description=self.extract_description(soup),
            headings=self.extract_headings(soup),
            paragraphs=self.extract_paragraphs(soup),
            text_content=self.extract_text_content(soup)
        )


async def scrape_webpage(url: str) -> WebPageInfo:
    """Convenience function to scrape a webpage."""
    scraper = WebScraper()
    return await scraper.scrape_url(url)
  
__all__ = [
    "WebScraper",
    "WebPageInfo",
    "scrape_webpage"
]