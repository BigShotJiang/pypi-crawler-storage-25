import requests
import os
import sys
from typing import Optional

sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from .auth import ThoughtFlowBase, ThoughtFlowAuth

class ThoughtFlowAccount(ThoughtFlowBase):
    def __init__(self):
        super().__init__()
        self.auth = ThoughtFlowAuth()
        self.headers["Authorization"] = f"Bearer {self.auth.access_token}"
    
    def get_account(self):
        response = requests.get(
            f"{self.base_url}/functions/v1/api/account/", 
            headers=self.headers
        )
        try:
            return self.process_response_contents(response, "data", [])
        except Exception as e:
            raise Exception(f"Failed to get account: {str(e)}")
      
    def get_targeted_account(self, targets: list[str] = ["ThoughtFlow Devs"]):
        self.accounts = self.get_account()
        for account in self.accounts:
            if account.get("name") in targets:
                return account.get("id")
        