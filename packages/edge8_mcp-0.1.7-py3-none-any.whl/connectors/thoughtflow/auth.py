import requests
import os
import sys
from typing import Optional
from dotenv import load_dotenv

sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from utils.encryption import encrypt_data
from utils.response_parser import response_data_and_error, process_response_contents

load_dotenv()

class ThoughtFlowBase:
    def __init__(self):
      self.base_url: str = os.getenv("THOUGHTFLOW_BE_PROD_URL")
      self.private_key: str = os.getenv("THOUGHTFLOW_PRIVATE_KEY")
      self.api_key: str = os.getenv("THOUGHTFLOW_SUPABASE_KEY")
      self.headers: dict = {
        "Content-Type": "application/json",
        "Authorization": f"Bearer {self.api_key}"
      }
      self.response_data_and_error = response_data_and_error
      self.process_response_contents = process_response_contents

class ThoughtFlowAuth(ThoughtFlowBase):
    def __init__(self):
      super().__init__()
      self.login_response = self.login()
      self.access_token = self.login_response.get("session", {}).get("access_token")
    
    def login(self, email: Optional[str] = None, password: Optional[str] = None):
      try:
        email = email if email is not None else os.getenv("TF_DEV_EMAIL")
        password = password if password is not None else os.getenv("TF_DEV_PASSWORD")
        encrypted_password = encrypt_data(password, self.private_key)
        response = requests.post(
          f"{self.base_url}/functions/v1/api/auth/signInWithPassword", 
          json={"email": email, "password": encrypted_password},
          headers=self.headers
        )
        login_response = self.process_response_contents(response, "data", {})
        return login_response
      except Exception as e:
        raise Exception(f"Failed to login: {str(e)}")


__all__ = ["ThoughtFlowBase", "ThoughtFlowAuth"]