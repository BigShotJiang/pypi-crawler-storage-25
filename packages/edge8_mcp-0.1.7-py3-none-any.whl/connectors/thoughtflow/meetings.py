import requests
import os
import sys

sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from connectors.thoughtflow.auth import ThoughtFlowBase, ThoughtFlowAuth
from connectors.thoughtflow.account import ThoughtFlowAccount
from utils.custom_types import ThoughtFlowMeetingsFilter

class ThoughtFlowMeetings(ThoughtFlowBase):
    def __init__(self):
      super().__init__()
      self.auth = ThoughtFlowAuth()
      self.account = ThoughtFlowAccount()
      self.account_id = self.account.get_targeted_account()
      self.headers = {
        "Content-Type": "application/json",
        "Authorization": f"Bearer {self.auth.access_token}",
        "account-id": self.account_id
      }
    
    def upload_transcript(self, data: bytes, file_name: str):
      response = requests.post(
        f"{self.base_url}/functions/v1/meetings/meeting-records/1/transcripts",
        headers={
          "Authorization": f"Bearer {self.auth.access_token}",
          "account-id": self.account_id
        },
        files={"file": (file_name, data, 'multipart/form-data')}
      )

      try:
        return self.process_response_contents(response, "data", {})
      except Exception as e:
        raise Exception(f"Failed to upload transcript: {str(e)}")
    
    def generate_summary(self, transcript_id: str):
      response = requests.post(
        f"{self.base_url}/functions/v1/meetings/meeting-records/",
        headers=self.headers,
        json={"transcript_id": transcript_id}
      )
      try:
        return self.process_response_contents(response)
      except Exception as e:
        raise Exception(f"Failed to get summary: {str(e)}")
      
    def get(self, meeting_id: str):
      response = requests.get(
        f"{self.base_url}/functions/v1/meetings/meeting-records/{meeting_id}",
        headers=self.headers
      )
      try:
        return self.process_response_contents(response, "data", {})
      except Exception as e:
        raise Exception(f"Failed to get meeting: {str(e)}")
      
    def filter(self, filters: list[ThoughtFlowMeetingsFilter]):
      filters_dict = {filter["key"]: f"{filter["operator"]}:{filter["value"]}" \
            if filter["operator"] != "eq" else filter["value"] \
            for filter in filters}
      response = requests.get(
        f"{self.base_url}/functions/v1/meetings/meeting-records/",
        headers=self.headers,
        params=filters_dict
      )
      try:
        return self.process_response_contents(response).get('data', [])
      except Exception as e:
        raise Exception(f"Failed to filter meetings: {str(e)}")
      
    def get_types(self):
      response = requests.get(
        f"{self.base_url}/functions/v1/meetings/meeting-types",
        headers=self.headers
      )
      try:
        return self.process_response_contents(response)
      except Exception as e:
        raise Exception(f"Failed to get meeting types: {str(e)}")
