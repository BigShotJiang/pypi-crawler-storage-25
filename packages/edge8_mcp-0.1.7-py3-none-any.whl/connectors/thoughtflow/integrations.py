import requests
import os
import sys
from typing import Optional

sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from connectors.supabase_client.createClient import get_custom_client
from dotenv import load_dotenv

load_dotenv()

class ThoughtFlowIntegrations:
    def __init__(self):
        self.client = get_custom_client(os.getenv("THOUGHTFLOW_BE_PROD_URL"), os.getenv("THOUGHTFLOW_SUPABASE_SERVICE_ROLE_KEY"))
    
    def get_integrations(self, email: str):
      try:
        profile = self.client.from_("profiles").select("*").eq("email", email).execute()
        if profile.data:
            user_id = profile.data[0]["id"]
            response = self.client.from_("user_social_integration").select("*").eq("user_id", user_id).execute()
            if response.data:
                return response.data[0]
        return {}
      except Exception as e:
        raise Exception(f"Failed to get integrations: {str(e)}")
      
        