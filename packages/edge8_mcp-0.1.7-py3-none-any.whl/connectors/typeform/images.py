from typing import Dict, Any, Optional, List
from .auth import TypeformParentInitializer

class TypeformImages(TypeformParentInitializer):
    """Typeform Images API implementation"""
    
    async def list_images(self) -> List[Dict[str, Any]]:
        """
        Retrieve all images in the account
        """
        return await self.request("GET", "/images")
    
    async def get_image(self, image_id: str, size: Optional[str] = None) -> Dict[str, Any]:
        """
        Retrieve a specific image
        
        Args:
            image_id: Unique image identifier
            size: Image size variant
        """
        params = {}
        if size:
            params["size"] = size
            
        return await self.request("GET", f"/images/{image_id}", params=params)
