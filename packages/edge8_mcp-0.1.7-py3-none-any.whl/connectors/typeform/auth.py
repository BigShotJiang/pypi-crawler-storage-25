import os
import httpx
from typing import Optional, Dict, Any
from dotenv import load_dotenv

load_dotenv()

class TypeformParentInitializer:
    """Base class for Typeform API interactions"""
    
    def __init__(self, access_token: Optional[str] = None):
        self.access_token = access_token or os.getenv("TYPEFORM_ACCESS_TOKEN")
        self.base_url = os.getenv("TYPEFORM_BASE_URL", "https://api.typeform.com")
        
        # Handle EU data center if configured
        if os.getenv("TYPEFORM_EU_MODE", "").lower() == "true":
            self.base_url = "https://api.eu.typeform.com"
            
        self.headers = {
            "Authorization": f"Bearer {self.access_token}",
            "Content-Type": "application/json"
        }
    
    async def request(self, method: str, endpoint: str, **kwargs) -> Dict[str, Any]:
        """Make HTTP request to Typeform API"""
        url = f"{self.base_url}{endpoint}"
        async with httpx.AsyncClient() as client:
            response = await client.request(method, url, headers=self.headers, **kwargs)
            
            # Handle common errors
            if response.status_code == 401:
                raise Exception("Unauthorized: Invalid Typeform access token")
            elif response.status_code == 403:
                raise Exception("Forbidden: Insufficient permissions")
            elif response.status_code == 429:
                raise Exception("Rate Limit Exceeded: Too many requests")
                
            response.raise_for_status()
            return response.json()
