from typing import Dict, Any, Optional
from .auth import TypeformParentInitializer

class TypeformThemes(TypeformParentInitializer):
    """Typeform Themes API implementation"""
    
    async def list_themes(self, 
                        page: int = 1, 
                        page_size: int = 10) -> Dict[str, Any]:
        """
        Retrieve list of themes
        
        Args:
            page: Page number (default: 1)
            page_size: Results per page (default: 10, max: 200)
        """
        params = {
            "page": page,
            "page_size": page_size
        }
            
        return await self.request("GET", "/themes", params=params)
    
    async def get_theme(self, theme_id: str) -> Dict[str, Any]:
        """
        Retrieve a single theme
        
        Args:
            theme_id: Unique theme identifier
        """
        return await self.request("GET", f"/themes/{theme_id}")
