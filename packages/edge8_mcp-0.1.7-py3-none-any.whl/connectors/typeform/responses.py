from typing import Dict, Any, Optional
from .auth import TypeformParentInitializer

class TypeformResponses(TypeformParentInitializer):
    """Typeform Responses API implementation"""
    
    async def get_responses(self, 
                          form_id: str,
                          page_size: int = 25,
                          since: Optional[str] = None,
                          until: Optional[str] = None,
                          after: Optional[str] = None,
                          before: Optional[str] = None,
                          included_response_ids: Optional[str] = None,
                          completed: Optional[bool] = None,
                          sort: Optional[str] = None,
                          query: Optional[str] = None,
                          fields: Optional[str] = None) -> Dict[str, Any]:
        """
        Retrieve responses for a form
        
        Args:
            form_id: Unique form identifier
            page_size: Number of results per page (default: 25, max: 1000)
            since: ISO 8601 timestamp (UTC) - retrieve responses after this date
            until: ISO 8601 timestamp (UTC) - retrieve responses before this date
            after: Pagination cursor for next page
            before: Pagination cursor for previous page
            included_response_ids: Comma-separated list of response IDs to include
            completed: Filter by completion status
            sort: Field to sort by
            query: Search term to filter responses
            fields: Comma-separated list of fields to retrieve
        """
        params = {
            "page_size": page_size
        }
        
        if since:
            params["since"] = since
        if until:
            params["until"] = until
        if after:
            params["after"] = after
        if before:
            params["before"] = before
        if included_response_ids:
            params["included_response_ids"] = included_response_ids
        if completed is not None:
            params["completed"] = str(completed).lower()
        if sort:
            params["sort"] = sort
        if query:
            params["query"] = query
        if fields:
            params["fields"] = fields
            
        return await self.request("GET", f"/forms/{form_id}/responses", params=params)
