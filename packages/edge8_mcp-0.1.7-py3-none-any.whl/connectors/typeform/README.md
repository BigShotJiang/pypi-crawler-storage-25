# Typeform API Connector

This connector provides an asynchronous interface to the Typeform API.

## Configuration

Set the following environment variables:

```bash
TYPEFORM_ACCESS_TOKEN=your_access_token_here
TYPEFORM_BASE_URL=https://api.typeform.com  # Optional
TYPEFORM_EU_MODE=false  # Set to true for EU data center
```

## Usage

### Forms

```python
from src.connectors.typeform import TypeformForms

forms_client = TypeformForms()
forms = await forms_client.list_forms()
form_details = await forms_client.get_form("form_id")
```

### Responses

```python
from src.connectors.typeform import TypeformResponses

responses_client = TypeformResponses()
responses = await responses_client.get_responses("form_id", page_size=50)
```

### Workspaces

```python
from src.connectors.typeform import TypeformWorkspaces

workspaces_client = TypeformWorkspaces()
workspaces = await workspaces_client.list_workspaces()
```

### Themes

```python
from src.connectors.typeform import TypeformThemes

themes_client = TypeformThemes()
themes = await themes_client.list_themes()
```

### Images

```python
from src.connectors.typeform import TypeformImages

images_client = TypeformImages()
images = await images_client.list_images()
```

## Features

- Asynchronous requests using `httpx`
- Automatic error handling
- Type hinting
- Support for pagination and filtering
