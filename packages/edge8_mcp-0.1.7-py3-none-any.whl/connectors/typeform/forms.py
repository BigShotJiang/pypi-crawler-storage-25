from typing import Dict, Any, Optional
from .auth import TypeformParentInitializer

class TypeformForms(TypeformParentInitializer):
    """Typeform Forms API implementation"""
    
    async def list_forms(self, 
                        page: int = 1, 
                        page_size: int = 10, 
                        search: Optional[str] = None,
                        workspace_id: Optional[str] = None,
                        sort: Optional[str] = None,
                        order: Optional[str] = None) -> Dict[str, Any]:
        """
        Retrieve list of forms
        
        Args:
            page: Page number (default: 1)
            page_size: Results per page (default: 10, max: 200)
            search: Filter forms by name/description
            workspace_id: Filter by workspace
            sort: Sort field (created_at or last_updated_at)
            order: Sort order (asc or desc)
        """
        params = {
            "page": page,
            "page_size": page_size
        }
        
        if search:
            params["search"] = search
        if workspace_id:
            params["workspace_id"] = workspace_id
        if sort:
            params["sort"] = sort
        if order:
            params["order"] = order
            
        return await self.request("GET", "/forms", params=params)
    
    async def get_form(self, form_id: str) -> Dict[str, Any]:
        """
        Retrieve a single form's structure
        
        Args:
            form_id: Unique form identifier
        """
        return await self.request("GET", f"/forms/{form_id}")
