from typing import Dict, Any, Optional
from .auth import TypeformParentInitializer

class TypeformWorkspaces(TypeformParentInitializer):
    """Typeform Workspaces API implementation"""
    
    async def list_workspaces(self, 
                            page: int = 1, 
                            page_size: int = 10, 
                            search: Optional[str] = None) -> Dict[str, Any]:
        """
        Retrieve list of workspaces
        
        Args:
            page: Page number (default: 1)
            page_size: Results per page (default: 10, max: 200)
            search: Filter workspaces by name
        """
        params = {
            "page": page,
            "page_size": page_size
        }
        
        if search:
            params["search"] = search
            
        return await self.request("GET", "/workspaces", params=params)
    
    async def get_workspace(self, workspace_id: str) -> Dict[str, Any]:
        """
        Retrieve a single workspace
        
        Args:
            workspace_id: Unique workspace identifier
        """
        return await self.request("GET", f"/workspaces/{workspace_id}")
