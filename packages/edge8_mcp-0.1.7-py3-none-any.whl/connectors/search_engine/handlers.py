from typing import Optional, List
from utils.custom_types import DocumentProps
import time
import asyncio
import os
from concurrent.futures import ThreadPoolExecutor
import requests
from .custom_sdk.serp_api import SerpApi
from .custom_sdk.exa_api import Exa

# Global thread pool executor to prevent resource exhaustion
_global_executor = None
_executor_lock = asyncio.Lock()


async def get_global_executor():
  """Get or create a global thread pool executor with limited workers"""
  global _global_executor
  async with _executor_lock:
    if _global_executor is None:
      # Limit max_workers to prevent resource exhaustion in Cloud Run
      max_workers = min(4, (os.cpu_count() or 1) + 1)
      _global_executor = ThreadPoolExecutor(max_workers=max_workers)
    return _global_executor


class DocumentLoader:
    def __init__(
        self,
        api_key: Optional[str] = None,
        custom_metadata: Optional[dict[str, str]] = {},
    ):
        self.api_key = api_key
        self.custom_metadata = custom_metadata


class ExaSearchLoader(DocumentLoader):
    def __init__(
        self,
        query,
        api_key,
        custom_metadata,
        search_kwargs: Optional[dict[str, str]] = None,
        as_answer: Optional[bool] = False,
    ):
        super().__init__(api_key, custom_metadata)
        self.search_kwargs = search_kwargs
        self.exa = Exa(
            api_key=self.api_key,
            query=query,
            search_kwargs=search_kwargs,
            as_answer=as_answer,
            custom_metadata=self.custom_metadata,
        )

    async def load(self) -> List[DocumentProps]:
        start_time = time.time()
        docs = await self.exa.search(num_results=self.search_kwargs["num_results"])

        print("Total number of documents from keyword search:", len(docs))

        print("Time to load keyword search results: ", time.time() - start_time)

        return docs


class SerpApiLoader(DocumentLoader):
    def __init__(
        self,
        api_key: Optional[str] = None,
        custom_metadata: Optional[dict[str, str]] = {},
    ):
        super().__init__(api_key, custom_metadata)
        self.serp_api = SerpApi(api_key, "google_light")

    async def load(self) -> List[DocumentProps]:
        search_results = await self.serp_api.search()
        converted_docs = [
            DocumentProps(
                content=result.get("snippet", ""),
                metadata=self.custom_metadata
                | {
                    "source": result.get("link", ""),
                    "title": result.get("title", ""),
                    "image": result.get("image", ""),
                },
            )
            for result in search_results.get("organic_results", [])
        ]
        return converted_docs
