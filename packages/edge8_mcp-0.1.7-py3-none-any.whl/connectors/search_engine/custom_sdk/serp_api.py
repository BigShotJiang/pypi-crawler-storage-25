from typing import Optional, List, Any
import time
import asyncio
import os
from concurrent.futures import ThreadPoolExecutor
import requests
from requests.adapters import HTTPAdapter, Retry
from dotenv import load_dotenv

load_dotenv()

_global_executor = None
_executor_lock = asyncio.Lock()


async def get_global_executor():
    """Get or create a global thread pool executor with limited workers"""
    global _global_executor
    async with _executor_lock:
        if _global_executor is None:
            # Limit max_workers to prevent resource exhaustion in Cloud Run
            max_workers = min(4, (os.cpu_count() or 1) + 1)
            _global_executor = ThreadPoolExecutor(max_workers=max_workers)
        return _global_executor


class SerpApi:
    def __init__(self, api_key: Optional[str] = None, engine: Optional[str] = "google_light"):
        self.api_key = api_key if api_key else os.getenv("SERP_API_KEY")
        self.engine = engine

    def _get_header(self):
        return {"x-api-key": self.api_key, "Content-Type": "application/json"}

    async def search(self, **params) -> List[dict[str, Any]]:
        start_time = time.time()

        print("Start Serp search")
        print("Params: ", params)
        try:
            executor = await get_global_executor()

            async def async_search_and_process():
                def sync_search_and_process():
                    s = requests.Session()
                    retries = Retry(total=100,
                                   backoff_factor=0.1,
                                   status_forcelist=[500, 502, 503, 504])
                    s.mount('http://', HTTPAdapter(max_retries=retries))
                    s.mount('https://', HTTPAdapter(max_retries=retries))
                    response = s.get(
                        "https://api.serpapi.com/v1/search.json",
                        headers=self._get_header(),
                        params={"engine": self.engine, "google_domain": "google.com", **params},
                    )

                    response = response.json()

                    print(
                        "Time to load Serp search results: ", time.time() - start_time
                    )

                    return response

                loop = asyncio.get_event_loop()

                return await loop.run_in_executor(
                    executor, lambda: sync_search_and_process()
                )

            response = await async_search_and_process()

            print("Time to process Serp search results: ", time.time() - start_time)

            return response
        except Exception as e:
            print("Error in Serp search: ", e)
            return []
