from typing import Optional, List
from utils.custom_types import DocumentProps
import time
import asyncio
import os
from concurrent.futures import ThreadPoolExecutor
import requests
from dotenv import load_dotenv

load_dotenv()

# Global thread pool executor to prevent resource exhaustion
_global_executor = None
_executor_lock = asyncio.Lock()

async def get_global_executor():
    """Get or create a global thread pool executor with limited workers"""
    global _global_executor
    async with _executor_lock:
        if _global_executor is None:
            # Limit max_workers to prevent resource exhaustion in Cloud Run
            max_workers = min(4, (os.cpu_count() or 1) + 1)
            _global_executor = ThreadPoolExecutor(max_workers=max_workers)
        return _global_executor
      

class Exa:
    def __init__(self, 
      api_key: Optional[str] = None, 
      query: Optional[str] = None, 
      search_kwargs: Optional[dict[str, str]] = None, 
      custom_metadata: Optional[dict[str, str]] = {}
    ):
        self.api_key = os.environ.get("EXASEARCH_API_KEY") if api_key is None else api_key
        print("Exa API Key: ", self.api_key)
        self.query = query
        self.search_kwargs = search_kwargs
        self.custom_metadata = custom_metadata
        self.header = {
            "x-api-key": self.api_key,
            "Content-Type": "application/json"
        }
        
    async def process_search_results_json(self, response, executor):
        if not response:
          return []
        
        async def process_main_doc(item):
            loop = asyncio.get_event_loop()
            return await loop.run_in_executor(
                executor,
                lambda: DocumentProps(
                    content=item.get("summary", item.get("text", "")),
                    metadata=self.custom_metadata | {
                            "source": item.get("url", ""),
                            "title": item.get("title", ""),
                            "image": item.get("image", ""),
                            "highlights": item.get("highlights", []),
                            "type": "summary"
                        }
                    )
                )
            
        
        main_docs = await process_main_doc(response)
        
        subpage_docs = []
        if response.get("subpages", []) and len(response.get("subpages", [])) > 0:
            subpage_tasks = [
                asyncio.create_task(process_main_doc(item))
                 for item in response.get("subpages", []) \
                    if item.get("url", "") != response.get("url", "")
            ]
            subpage_docs = await asyncio.gather(*subpage_tasks)
        
        return [main_docs, *subpage_docs]
    
    async def search(self, num_results: int = 5) -> List[DocumentProps]:
        start_time = time.time()
        
        print("Start Exa search")
        try:
            executor = await get_global_executor()
            async def async_search_and_process():
                def sync_search_and_process():
                    response = requests.post(
                        "https://api.exa.ai/search",
                        headers=self.header,
                        json={
                            "query": self.query,
                            "type": self.search_kwargs.get("type", "auto"),
                            "numResults": num_results,
                            "startPublishedDate": self.search_kwargs.get("start_published_date", None),
                            "endPublishedDate": self.search_kwargs.get("end_published_date", None),
                            "userLocation": "VN",
                            "includeText": self.search_kwargs.get("include_text", None),
                            "includeDomains": self.search_kwargs.get("include_domains", None),
                            "moderation": self.search_kwargs.get("moderation", True),
                            "contents": {
                                "livecrawl": self.search_kwargs.get("livecrawl", None),
                                "text": self.search_kwargs.get("text", False),
                                "summary": self.search_kwargs.get("summary", True) if self.search_kwargs.get("type") != "fast" else None,
                                "subpages": self.search_kwargs.get("subpages", None),
                                "extras": self.search_kwargs.get("extras", None),
                                "highlights": {
                                  "query": self.search_kwargs.get("highlight_query", f"Most related set of sentences to '{self.query}'."),
                                  "numSentences": self.search_kwargs.get("highlights_num_sentences", 10),
                                  "highlightsPerUrl": self.search_kwargs.get("highlights_per_url", 1)
                                }
                            }
                        }
                    )
                
                    response = response.json()
                    
                    print(response)
                    
                    print("Time to load Exa search results: ", time.time() - start_time)
                    
                    return response
                
                loop = asyncio.get_event_loop()

                return await loop.run_in_executor(
                        executor,
                        lambda: sync_search_and_process()
                    )
            
                
            response = await async_search_and_process()
            
            doc_tasks = [
                    asyncio.create_task(self.process_search_results_json(item, executor))
                    for item in response.get("results", [])
                ]
            
            docs = await asyncio.gather(*doc_tasks)
            docs = [item for sublist in docs for item in sublist]
                
            print("Time to process Exa search results: ", time.time() - start_time)
        
            return docs
            
        
        except Exception as e:
            print("Error in Exa search: ", e)
            return []    
