import os
import httpx
from typing import Optional, Dict, Any
from dotenv import load_dotenv

load_dotenv()

class NotionApiClient:
    def __init__(self, api_key: Optional[str] = None):
        self.api_key = api_key or os.getenv("NOTION_API_KEY")
        if not self.api_key:
            raise ValueError("Notion API key is required.")
        self.base_url = "https://api.notion.com/v1"
        self.headers = {
            "Authorization": f"Bearer {self.api_key}",
            "Content-Type": "application/json",
            "Notion-Version": "2022-06-28"
        }

    async def request(self, method: str, url: str, **kwargs) -> Dict[str, Any]:
        async with httpx.AsyncClient() as client:
            response = await client.request(method, f"{self.base_url}/{url}", headers=self.headers, **kwargs)
            response.raise_for_status()
            return response.json()

    async def create_page(self, data: Dict[str, Any]) -> Dict[str, Any]:
        return await self.request("POST", "pages", json=data)

    async def create_database(self, data: Dict[str, Any]) -> Dict[str, Any]:
        return await self.request("POST", "databases", json=data)
