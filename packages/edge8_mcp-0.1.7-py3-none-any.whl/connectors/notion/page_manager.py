from typing import Dict, Any
from .client import NotionApiClient

def markdown_to_notion_blocks(markdown_text: str) -> list:
    # This is a simplified converter. A more robust solution would handle more markdown features.
    blocks = []
    for line in markdown_text.split('\n'):
        if line.startswith('# '):
            blocks.append({
                "object": "block",
                "type": "heading_1",
                "heading_1": {"rich_text": [{"type": "text", "text": {"content": line[2:]}}]}
            })
        elif line.strip():
            blocks.append({
                "object": "block",
                "type": "paragraph",
                "paragraph": {"rich_text": [{"type": "text", "text": {"content": line}}]}
            })
    return blocks

async def create_page(parent_page_id: str, title: str, content: str) -> Dict[str, Any]:
    """Create a new page in Notion."""
    client = NotionApiClient()
    page_data = {
        "parent": {"page_id": parent_page_id},
        "properties": {
            "title": [
                {
                    "text": {"content": title}
                }
            ]
        },
        "children": markdown_to_notion_blocks(content)
    }
    return await client.create_page(page_data)
