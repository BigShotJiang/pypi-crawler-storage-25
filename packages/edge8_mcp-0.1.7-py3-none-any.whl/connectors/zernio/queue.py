from typing import Any, Dict, Optional

from .auth import ZernioParentInitializer


class ZernioQueue(ZernioParentInitializer):
    """Queue slot management for recurring auto-scheduling of posts."""

    async def list_slots(
        self,
        profile_id: str,
        all: bool = False,
        queue_id: Optional[str] = None,
    ) -> Dict[str, Any]:
        """List queue schedules for a profile.

        Args:
            profile_id: The profile identifier (required)
            all: Whether to list all slots including inactive
            queue_id: Optional specific queue identifier

        Returns:
            Dict containing queue slot list
        """
        params: Dict[str, Any] = {"profileId": profile_id}
        if all:
            params["all"] = True
        if queue_id is not None:
            params["queueId"] = queue_id
        return await self.request("GET", "/v1/queue/slots", params=params)

    async def create_slot(
        self,
        profile_id: str,
        **kwargs: Any,
    ) -> Dict[str, Any]:
        """Create a new queue slot.

        Args:
            profile_id: The profile identifier (required)
            **kwargs: Additional slot configuration passed as JSON body

        Returns:
            Dict containing the created queue slot data
        """
        params: Dict[str, str] = {"profileId": profile_id}
        return await self.request("POST", "/v1/queue/slots", params=params, json=kwargs)

    async def update_slot(
        self,
        profile_id: str,
        queue_id: Optional[str] = None,
        set_as_default: bool = False,
        **kwargs: Any,
    ) -> Dict[str, Any]:
        """Update an existing queue slot.

        Args:
            profile_id: The profile identifier (required)
            queue_id: Optional specific queue identifier
            set_as_default: Whether to set this slot as the default
            **kwargs: Additional fields to update

        Returns:
            Dict containing updated queue slot data
        """
        params: Dict[str, Any] = {"profileId": profile_id}
        if queue_id is not None:
            params["queueId"] = queue_id
        if set_as_default:
            params["setAsDefault"] = True
        return await self.request("PUT", "/v1/queue/slots", params=params, json=kwargs)

    async def delete_slot(
        self,
        profile_id: str,
        queue_id: str,
    ) -> Dict[str, Any]:
        """Delete a queue slot.

        Args:
            profile_id: The profile identifier (required)
            queue_id: The queue slot identifier (required)

        Returns:
            Dict containing deletion confirmation
        """
        params: Dict[str, str] = {"profileId": profile_id, "queueId": queue_id}
        return await self.request("DELETE", "/v1/queue/slots", params=params)

    async def get_next_slot(
        self,
        profile_id: str,
    ) -> Dict[str, Any]:
        """Get the next available queue slot for a profile.

        Args:
            profile_id: The profile identifier (required)

        Returns:
            Dict containing the next available slot data
        """
        params: Dict[str, str] = {"profileId": profile_id}
        return await self.request("GET", "/v1/queue/next-slot", params=params)

    async def preview_slots(
        self,
        profile_id: str,
        count: int = 5,
    ) -> Dict[str, Any]:
        """Preview upcoming queue slots.

        Args:
            profile_id: The profile identifier (required)
            count: Number of upcoming slots to preview (default 5)

        Returns:
            Dict containing preview of upcoming slots
        """
        params: Dict[str, Any] = {"profileId": profile_id, "count": count}
        return await self.request("GET", "/v1/queue/preview", params=params)
