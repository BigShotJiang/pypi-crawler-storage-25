from typing import Any, Dict, Optional

from .auth import ZernioParentInitializer


class ZernioProfiles(ZernioParentInitializer):
    """CRUD operations for Zernio profile (brand/project) containers."""

    async def create(
        self,
        name: str,
        description: Optional[str] = None,
        color: Optional[str] = None,
    ) -> Dict[str, Any]:
        """Create a new profile.

        Args:
            name: Profile name (required)
            description: Optional profile description
            color: Optional hex color string

        Returns:
            Dict containing the created profile data
        """
        body: Dict[str, Any] = {"name": name}
        if description is not None:
            body["description"] = description
        if color is not None:
            body["color"] = color
        return await self.request("POST", "/v1/profiles", json=body)

    async def list(self, include_over_limit: bool = False) -> Dict[str, Any]:
        """List all profiles.

        Args:
            include_over_limit: Whether to include profiles over their limit

        Returns:
            Dict containing list of profiles
        """
        params: Dict[str, bool] = {}
        if include_over_limit:
            params["includeOverLimit"] = True
        return await self.request("GET", "/v1/profiles", params=params)

    async def get(self, profile_id: str) -> Dict[str, Any]:
        """Get a specific profile by ID.

        Args:
            profile_id: The profile identifier

        Returns:
            Dict containing profile data
        """
        return await self.request("GET", f"/v1/profiles/{profile_id}")

    async def update(
        self,
        profile_id: str,
        name: Optional[str] = None,
        description: Optional[str] = None,
        color: Optional[str] = None,
        is_default: Optional[bool] = None,
    ) -> Dict[str, Any]:
        """Update an existing profile.

        Args:
            profile_id: The profile identifier
            name: New profile name
            description: New profile description
            color: New hex color string
            is_default: Whether this is the default profile

        Returns:
            Dict containing updated profile data
        """
        body: Dict[str, Any] = {}
        if name is not None:
            body["name"] = name
        if description is not None:
            body["description"] = description
        if color is not None:
            body["color"] = color
        if is_default is not None:
            body["isDefault"] = is_default
        return await self.request("PUT", f"/v1/profiles/{profile_id}", json=body)

    async def delete(self, profile_id: str) -> Dict[str, Any]:
        """Delete a profile.

        Args:
            profile_id: The profile identifier

        Returns:
            Dict containing deletion confirmation
        """
        return await self.request("DELETE", f"/v1/profiles/{profile_id}")
