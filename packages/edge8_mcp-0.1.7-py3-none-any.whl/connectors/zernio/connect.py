from typing import Any, Dict, Optional

import httpx

from .auth import ZernioParentInitializer


class ZernioConnect(ZernioParentInitializer):
    """OAuth flows and headless platform selection for social accounts."""

    async def request(self, method: str, endpoint: str, **kwargs) -> Dict[str, Any]:
        """Make HTTP request with optional header override via custom_headers kwarg."""
        custom_headers = kwargs.pop("custom_headers", None)
        headers = self.headers.copy()
        if custom_headers:
            headers.update(custom_headers)
        url = f"{self.base_url}{endpoint}"
        async with httpx.AsyncClient() as client:
            response = await client.request(method, url, headers=headers, **kwargs)

            if response.status_code == 401:
                raise Exception("Unauthorized: Invalid Zernio API key")
            elif response.status_code == 403:
                raise Exception(
                    "Forbidden: Insufficient permissions or feature requires upgrade"
                )
            elif response.status_code == 429:
                raise Exception("Rate Limit Exceeded: Too many requests")
            elif response.status_code == 400:
                try:
                    error_data = response.json()
                    error_msg = error_data.get(
                        "error", error_data.get("message", "Bad request")
                    )
                    raise Exception(f"Bad Request: {error_msg}")
                except Exception:
                    raise Exception("Bad Request: Invalid request parameters")

            response.raise_for_status()
            return response.json()

    async def get_connect_url(
        self,
        platform: str,
        profile_id: str,
        redirect_url: Optional[str] = None,
        headless: bool = False,
    ) -> Dict[str, Any]:
        """Get OAuth authorization URL for a platform.

        Args:
            platform: Social platform name (facebook, linkedin, pinterest,
                google-business, snapchat)
            profile_id: Profile ID to associate with
            redirect_url: Optional redirect URL after OAuth
            headless: Whether to use headless mode

        Returns:
            Dict containing authUrl
        """
        params: Dict[str, Any] = {"profileId": profile_id}
        if redirect_url is not None:
            params["redirect_url"] = redirect_url
        if headless:
            params["headless"] = True
        return await self.request("GET", f"/v1/connect/{platform}", params=params)

    async def list_facebook_pages(self, connect_token: str) -> Dict[str, Any]:
        """List Facebook pages available for selection in headless flow.

        Args:
            connect_token: Connect token from headless OAuth initiation

        Returns:
            Dict containing available Facebook pages
        """
        return await self.request(
            "GET",
            "/v1/connect/facebook/select-page",
            custom_headers={"X-Connect-Token": connect_token},
        )

    async def select_facebook_page(
        self, connect_token: str, page_id: str
    ) -> Dict[str, Any]:
        """Select a Facebook page to connect.

        Args:
            connect_token: Connect token from headless OAuth initiation
            page_id: Facebook page ID to select

        Returns:
            Dict containing selection result
        """
        return await self.request(
            "POST",
            "/v1/connect/facebook/select-page",
            json={"pageId": page_id},
            custom_headers={"X-Connect-Token": connect_token},
        )

    async def list_linkedin_orgs(self, connect_token: str) -> Dict[str, Any]:
        """List LinkedIn organizations available for selection in headless flow.

        Args:
            connect_token: Connect token from headless OAuth initiation

        Returns:
            Dict containing available LinkedIn organizations
        """
        return await self.request(
            "GET",
            "/v1/connect/linkedin/select-org",
            custom_headers={"X-Connect-Token": connect_token},
        )

    async def select_linkedin_org(
        self, connect_token: str, organization_id: str
    ) -> Dict[str, Any]:
        """Select a LinkedIn organization to connect.

        Args:
            connect_token: Connect token from headless OAuth initiation
            organization_id: LinkedIn organization ID to select

        Returns:
            Dict containing selection result
        """
        return await self.request(
            "POST",
            "/v1/connect/linkedin/select-org",
            json={"organizationId": organization_id},
            custom_headers={"X-Connect-Token": connect_token},
        )

    async def connect_bluesky(
        self, profile_id: str, identifier: str, password: str
    ) -> Dict[str, Any]:
        """Connect a Bluesky account using credentials.

        Args:
            profile_id: Profile ID to associate with
            identifier: Bluesky account identifier (handle or email)
            password: Bluesky app password

        Returns:
            Dict containing connection result
        """
        return await self.request(
            "POST",
            "/v1/connect/bluesky/credentials",
            json={
                "profileId": profile_id,
                "identifier": identifier,
                "password": password,
            },
        )
