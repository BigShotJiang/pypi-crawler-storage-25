from typing import Any, Dict, Optional

import httpx

from .auth import ZernioParentInitializer


class ZernioAnalytics(ZernioParentInitializer):
    """Zernio analytics: post metrics, best times, daily metrics, follower stats."""

    async def request(self, method: str, endpoint: str, **kwargs) -> Dict[str, Any]:
        """Override to handle 202 and 424 before parent raises on non-2xx.

        Args:
            method: HTTP method
            endpoint: API endpoint path
            **kwargs: Additional request kwargs

        Returns:
            Dict containing response data or status for 202/424
        """
        url = f"{self.base_url}{endpoint}"
        async with httpx.AsyncClient() as client:
            response = await client.request(method, url, headers=self.headers, **kwargs)

            if response.status_code == 202:
                return {"status": "pending", "message": "Analytics sync in progress"}
            if response.status_code == 424:
                return {
                    "status": "failed",
                    "message": "All platforms failed to provide data",
                }

            if response.status_code == 401:
                raise Exception("Unauthorized: Invalid Zernio API key")
            elif response.status_code == 403:
                raise Exception(
                    "Forbidden: Insufficient permissions or feature requires upgrade"
                )
            elif response.status_code == 429:
                raise Exception("Rate Limit Exceeded: Too many requests")
            elif response.status_code == 400:
                # M-4: only catch JSON parse errors, not the Exception we just raised
                try:
                    error_data = response.json()
                    error_msg = error_data.get("error", error_data.get("message", "Bad request"))
                except (ValueError, KeyError):
                    error_msg = "Invalid request parameters"
                raise Exception(f"Bad Request: {error_msg}")

            response.raise_for_status()
            return response.json()

    async def get_post_analytics(
        self,
        post_id: Optional[str] = None,
        from_date: Optional[str] = None,
        to_date: Optional[str] = None,
        sort_by: str = "date",
        limit: int = 20,
        offset: int = 0,
    ) -> Dict[str, Any]:
        """Get analytics for a single post or paginated overview.

        Args:
            post_id: Optional post ID for single post analytics
            from_date: Start date filter
            to_date: End date filter
            sort_by: Sort field (default: date)
            limit: Number of results per page
            offset: Pagination offset

        Returns:
            Dict containing analytics data
        """
        params: Dict[str, Any] = {
            "sortBy": sort_by,
            "limit": limit,
            "offset": offset,
        }
        if post_id is not None:
            params["postId"] = post_id
        if from_date is not None:
            params["fromDate"] = from_date
        if to_date is not None:
            params["toDate"] = to_date
        return await self.request("GET", "/v1/analytics", params=params)

    async def get_best_times(self) -> Dict[str, Any]:
        """Get optimal posting times (analytics add-on).

        Returns:
            Dict containing best posting time slots
        """
        return await self.request("GET", "/v1/analytics/best-time")

    async def get_daily_metrics(
        self,
        from_date: Optional[str] = None,
        to_date: Optional[str] = None,
    ) -> Dict[str, Any]:
        """Get daily aggregated metrics (analytics add-on).

        Args:
            from_date: Start date filter
            to_date: End date filter

        Returns:
            Dict containing daily metric data
        """
        params: Dict[str, Any] = {}
        if from_date is not None:
            params["fromDate"] = from_date
        if to_date is not None:
            params["toDate"] = to_date
        return await self.request("GET", "/v1/analytics/daily-metrics", params=params)

    async def get_follower_stats(self) -> Dict[str, Any]:
        """Get follower growth statistics (analytics add-on).

        Returns:
            Dict containing follower growth data
        """
        return await self.request("GET", "/v1/accounts/follower-stats")
