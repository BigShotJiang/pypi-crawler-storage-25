import os
from typing import Any, Dict

import httpx

from .auth import ZernioParentInitializer


class ZernioMedia(ZernioParentInitializer):
    """Handles presigned URL media uploads to Zernio."""

    async def get_presigned_url(self, file_name: str, file_type: str) -> Dict[str, Any]:
        """Get a presigned URL for uploading a file.

        Args:
            file_name: Name of the file to upload
            file_type: MIME type of the file

        Returns:
            Dict containing uploadUrl, publicUrl, and expires
        """
        return await self.request(
            "POST",
            "/v1/media/presign",
            json={"fileName": file_name, "fileType": file_type},
        )

    async def upload(self, file_path: str, file_type: str) -> str:
        """Upload a file via presigned URL and return its public URL.

        Args:
            file_path: Local path to the file to upload
            file_type: MIME type of the file

        Returns:
            Public URL string of the uploaded file
        """
        file_name = os.path.basename(file_path)
        result = await self.get_presigned_url(file_name, file_type)

        with open(file_path, "rb") as f:
            content = f.read()

        async with httpx.AsyncClient() as client:
            response = await client.put(
                result["uploadUrl"],
                content=content,
                headers={"Content-Type": file_type},
            )
            response.raise_for_status()

        return result["publicUrl"]
