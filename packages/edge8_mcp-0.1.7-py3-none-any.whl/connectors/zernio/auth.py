import os
from typing import Any, Dict, Optional

import httpx
from dotenv import load_dotenv

load_dotenv()

ZERNIO_API_KEY = os.getenv("ZERNIO_API_KEY")
ZERNIO_BASE_URL = os.getenv("ZERNIO_BASE_URL", "https://zernio.com/api/v1")


class ZernioParentInitializer:
    """Base class for Zernio API interactions"""

    def __init__(self, api_key: Optional[str] = None):
        self.api_key = api_key or ZERNIO_API_KEY
        self.base_url = ZERNIO_BASE_URL
        self.headers = {
            "Authorization": f"Bearer {self.api_key}",
            "Content-Type": "application/json",
        }

    async def request(self, method: str, endpoint: str, **kwargs) -> Dict[str, Any]:
        """Make HTTP request to Zernio API"""
        url = f"{self.base_url}{endpoint}"
        async with httpx.AsyncClient() as client:
            response = await client.request(method, url, headers=self.headers, **kwargs)

            if response.status_code == 401:
                raise Exception("Unauthorized: Invalid Zernio API key")
            elif response.status_code == 403:
                raise Exception(
                    "Forbidden: Insufficient permissions or feature requires upgrade"
                )
            elif response.status_code == 429:
                raise Exception("Rate Limit Exceeded: Too many requests")
            elif response.status_code == 400:
                # M-4: only catch JSON parse errors, not the Exception we just raised
                try:
                    error_data = response.json()
                    error_msg = error_data.get("error", error_data.get("message", "Bad request"))
                except (ValueError, KeyError):
                    error_msg = "Invalid request parameters"
                raise Exception(f"Bad Request: {error_msg}")

            response.raise_for_status()
            return response.json()
