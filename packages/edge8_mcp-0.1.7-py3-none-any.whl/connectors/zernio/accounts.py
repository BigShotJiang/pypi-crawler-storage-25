from typing import Any, Dict, Optional

from .auth import ZernioParentInitializer


class ZernioAccounts(ZernioParentInitializer):
    """Manage connected social media accounts via Zernio API."""

    async def list(
        self, page: Optional[int] = None, limit: Optional[int] = None
    ) -> Dict[str, Any]:
        """List connected accounts with optional pagination.

        Args:
            page: Page number for pagination
            limit: Number of results per page

        Returns:
            Dict containing account list and pagination info
        """
        params: Dict[str, Any] = {}
        if page is not None:
            params["page"] = page
        if limit is not None:
            params["limit"] = limit
        return await self.request("GET", "/v1/accounts", params=params)

    async def update(
        self, account_id: str, display_name: Optional[str] = None
    ) -> Dict[str, Any]:
        """Update a connected account's display name.

        Args:
            account_id: Unique identifier of the account
            display_name: New display name for the account

        Returns:
            Dict containing updated account info
        """
        body: Dict[str, Any] = {}
        if display_name is not None:
            body["displayName"] = display_name
        return await self.request("PUT", f"/v1/accounts/{account_id}", json=body)

    async def delete(self, account_id: str) -> Dict[str, Any]:
        """Delete a connected account.

        Args:
            account_id: Unique identifier of the account

        Returns:
            Dict containing deletion result
        """
        return await self.request("DELETE", f"/v1/accounts/{account_id}")

    async def get_health(self, account_id: str) -> Dict[str, Any]:
        """Get health status of a specific connected account.

        Args:
            account_id: Unique identifier of the account

        Returns:
            Dict containing account health status
        """
        return await self.request("GET", f"/v1/accounts/{account_id}/health")

    async def get_all_health(self) -> Dict[str, Any]:
        """Get health status of all connected accounts.

        Returns:
            Dict containing health status for all accounts
        """
        return await self.request("GET", "/v1/accounts/health")

    async def get_follower_stats(self) -> Dict[str, Any]:
        """Get follower statistics for all connected accounts.

        Returns:
            Dict containing follower stats data
        """
        return await self.request("GET", "/v1/accounts/follower-stats")
