# Zernio Marketing Connector

Python async client for the [Zernio Marketing API](https://zernio.com/api/v1).

## Classes

| Class | Purpose |
|-------|---------|
| `ZernioParentInitializer` | Base class — API key handling, HTTP requests |
| `ZernioProfiles` | CRUD for brand/project profile containers |
| `ZernioAccounts` | Connected social media account management |
| `ZernioConnect` | OAuth flows and headless platform selection |
| `ZernioPosts` | Create, schedule, publish, and manage posts |
| `ZernioMedia` | Presigned-URL media uploads |
| `ZernioAnalytics` | Post metrics, best times, daily metrics, follower stats |
| `ZernioQueue` | Queue slot management for auto-scheduling |

## Environment Setup

```bash
# Required
export ZERNIO_API_KEY="your-api-key"

# Optional (defaults to https://zernio.com/api/v1)
export ZERNIO_BASE_URL="https://zernio.com/api/v1"
```

Or in a `.env` file:

```
ZERNIO_API_KEY=your-api-key
ZERNIO_BASE_URL=https://zernio.com/api/v1
```

## Quick Start

```python
from src.connectors.zernio import (
    ZernioProfiles,
    ZernioPosts,
    ZernioMedia,
    ZernioAnalytics,
    ZernioQueue,
)
import asyncio

async def main():
    # --- Profiles ---
    profiles = ZernioProfiles()
    all_profiles = await profiles.list()
    profile = await profiles.create(name="Campaign Q2", description="Summer campaign")

    # --- Posts ---
    posts = ZernioPosts()
    new_post = await posts.create(
        content="Hello from Zernio!",
        platforms=["facebook", "linkedin"],
        publish_now=True,
    )
    scheduled = await posts.create(
        content="Scheduled post",
        platforms=["twitter"],
        scheduled_for="2026-05-01T10:00:00Z",
        timezone="America/New_York",
    )
    post_list = await posts.list(status="published", limit=10)

    # --- Media ---
    media = ZernioMedia()
    public_url = await media.upload("/path/to/image.png", "image/png")

    # --- Analytics ---
    analytics = ZernioAnalytics()
    post_stats = await analytics.get_post_analytics(post_id="post_123")
    best_times = await analytics.get_best_times()
    daily = await analytics.get_daily_metrics(from_date="2026-04-01")
    followers = await analytics.get_follower_stats()

    # --- Queue ---
    queue = ZernioQueue()
    slots = await queue.list_slots(profile_id=profile["id"])
    next_slot = await queue.get_next_slot(profile_id=profile["id"])

asyncio.run(main())
```

## OAuth Connect Example

```python
from src.connectors.zernio import ZernioConnect

async def connect_facebook():
    connect = ZernioConnect()

    # Standard OAuth
    result = await connect.get_connect_url(
        platform="facebook",
        profile_id="profile_123",
        redirect_url="https://example.com/callback",
    )
    auth_url = result["authUrl"]

    # Headless flow
    headless = await connect.get_connect_url(
        platform="facebook",
        profile_id="profile_123",
        headless=True,
    )
    token = headless["connectToken"]
    pages = await connect.list_facebook_pages(connect_token=token)
    await connect.select_facebook_page(connect_token=token, page_id="page_456")
```

## Accounts & Health

```python
from src.connectors.zernio import ZernioAccounts

async def check_accounts():
    accounts = ZernioAccounts()
    all_accounts = await accounts.list(limit=50)
    health = await accounts.get_all_health()
    stats = await accounts.get_follower_stats()
```

## Error Handling

All classes raise descriptive exceptions for API errors:

- `401` — Invalid API key
- `403` — Insufficient permissions or upgrade required
- `400` — Bad request parameters
- `429` — Rate limit exceeded

`ZernioAnalytics` additionally handles:
- `202` — Analytics sync in progress (returns `{"status": "pending"}`)
- `424` — All platforms failed (returns `{"status": "failed"}`)
