from typing import Any, Dict, List, Optional

from .auth import ZernioParentInitializer


class ZernioPosts(ZernioParentInitializer):
    """Manage marketing posts (create, publish, schedule) via Zernio API."""

    async def create(
        self,
        content: str,
        platforms: List[str],
        publish_now: bool = False,
        scheduled_for: Optional[str] = None,
        timezone: Optional[str] = None,
        media_items: Optional[List[Dict[str, Any]]] = None,
        custom_content: Optional[Dict[str, Any]] = None,
    ) -> Dict[str, Any]:
        """Create, publish, or schedule a post.

        Args:
            content: Post text content
            platforms: List of platform identifiers to target
            publish_now: Publish immediately if True
            scheduled_for: ISO datetime string for scheduling
            timezone: Timezone identifier for scheduled time
            media_items: List of media attachment objects
            custom_content: Platform-specific content overrides

        Returns:
            Dict containing created post data
        """
        body: Dict[str, Any] = {
            "content": content,
            "platforms": platforms,
        }
        if publish_now:
            body["publishNow"] = True
        if scheduled_for is not None:
            body["scheduledFor"] = scheduled_for
        if timezone is not None:
            body["timezone"] = timezone
        if media_items is not None:
            body["mediaItems"] = media_items
        if custom_content is not None:
            body["customContent"] = custom_content
        return await self.request("POST", "/v1/posts", json=body)

    async def list(
        self,
        status: Optional[str] = None,
        platform: Optional[str] = None,
        from_date: Optional[str] = None,
        to_date: Optional[str] = None,
        limit: int = 20,
        offset: int = 0,
    ) -> Dict[str, Any]:
        """List posts with optional filters and pagination.

        Args:
            status: Filter by post status
            platform: Filter by platform identifier
            from_date: Start date filter (ISO format)
            to_date: End date filter (ISO format)
            limit: Maximum number of results
            offset: Pagination offset

        Returns:
            Dict containing post list and pagination info
        """
        params: Dict[str, Any] = {
            "limit": limit,
            "offset": offset,
        }
        if status is not None:
            params["status"] = status
        if platform is not None:
            params["platform"] = platform
        if from_date is not None:
            params["fromDate"] = from_date
        if to_date is not None:
            params["toDate"] = to_date
        return await self.request("GET", "/v1/posts", params=params)

    async def get(self, post_id: str) -> Dict[str, Any]:
        """Get a single post by ID.

        Args:
            post_id: Unique identifier of the post

        Returns:
            Dict containing post data
        """
        return await self.request("GET", f"/v1/posts/{post_id}")

    async def update(
        self,
        post_id: str,
        content: Optional[str] = None,
        platforms: Optional[List[str]] = None,
        scheduled_for: Optional[str] = None,
        timezone: Optional[str] = None,
        media_items: Optional[List[Dict[str, Any]]] = None,
    ) -> Dict[str, Any]:
        """Update a draft or scheduled post.

        Args:
            post_id: Unique identifier of the post
            content: Updated post text content
            platforms: Updated list of platform identifiers
            scheduled_for: Updated scheduled datetime (ISO format)
            timezone: Updated timezone identifier
            media_items: Updated list of media attachment objects

        Returns:
            Dict containing updated post data
        """
        body: Dict[str, Any] = {}
        if content is not None:
            body["content"] = content
        if platforms is not None:
            body["platforms"] = platforms
        if scheduled_for is not None:
            body["scheduledFor"] = scheduled_for
        if timezone is not None:
            body["timezone"] = timezone
        if media_items is not None:
            body["mediaItems"] = media_items
        return await self.request("PUT", f"/v1/posts/{post_id}", json=body)

    async def delete(self, post_id: str) -> Dict[str, Any]:
        """Delete a draft or scheduled post.

        Args:
            post_id: Unique identifier of the post

        Returns:
            Dict containing deletion result
        """
        return await self.request("DELETE", f"/v1/posts/{post_id}")

    async def retry(self, post_id: str) -> Dict[str, Any]:
        """Retry publishing to failed platforms.

        Args:
            post_id: Unique identifier of the post

        Returns:
            Dict containing retry result
        """
        return await self.request("POST", f"/v1/posts/{post_id}/retry")
