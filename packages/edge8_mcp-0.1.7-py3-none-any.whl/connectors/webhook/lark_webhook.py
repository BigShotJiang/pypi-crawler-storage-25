#!/usr/bin/env python3
"""
Lark Webhook Event Handler (Python Implementation)

This is a Python conversion of the TypeScript webhook handler.
Handles incoming webhook events from Lark (Feishu) platform.
Supports event verification and processing for various event types.

Event Types:
- vc.meeting.meeting_ended_v1: Triggered when a video conference meeting ends

Reference:
https://open.feishu.cn/document/uAjLw4CM/ukTMukTMukTM/server-side-sdk/nodejs-sdk/preparation-before-development

Usage:
    from lark_webhook_handler import LarkWebhookHandler
    
    handler = LarkWebhookHandler(
        encrypt_key='your_encrypt_key',
        verification_token='your_verification_token'
    )
    
    # In your Flask/FastAPI/Django view:
    response = handler.handle_webhook(request_body, request_headers)
"""

import os
import sys
import json
import hashlib
import logging
from typing import Dict, Any, Optional
from dataclasses import dataclass
from enum import Enum
import requests
import base64
from Crypto.Cipher import AES

sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from utils.webhooks_interaction import non_await_request
from utils.encryption import AESCipher
from dotenv import load_dotenv

load_dotenv()

# Configure logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)


class HTTPStatus(Enum):
    """HTTP Status Codes"""
    OK = 200
    UNAUTHORIZED = 401
    METHOD_NOT_ALLOWED = 405
    INTERNAL_SERVER_ERROR = 500


@dataclass
class LarkEventHeader:
    """Lark event header structure"""
    event_id: str
    event_type: str
    create_time: str
    token: str
    app_id: str
    tenant_key: str


@dataclass
class LarkEventPayload:
    """Lark event payload structure"""
    schema: str
    header: LarkEventHeader
    event: Dict[str, Any]


@dataclass
class LarkEventChallenge:
    """Lark URL verification challenge structure"""
    challenge: str
    token: str
    type: str


class WebhookResponse:
    """Webhook response wrapper"""
    
    def __init__(self, data: Dict[str, Any], status_code: int = 200):
        self.data = data
        self.status_code = status_code
        self.headers = {'Content-Type': 'application/json'}
    
    def to_dict(self) -> Dict[str, Any]:
        """Convert response to dictionary"""
        return {
            'status_code': self.status_code,
            'body': json.dumps(self.data),
            'headers': self.headers
        }
    
    def to_json(self) -> str:
        """Convert response to JSON string"""
        return json.dumps(self.data)


class LarkWebhookHandler:
    """
    Lark Webhook Event Handler
    
    Processes webhook events from Lark platform with signature verification
    and event routing.
    """
    
    def __init__(
        self,
        app_id: str = "",
        encrypt_key: Optional[str] = None,
        verification_token: Optional[str] = None
    ):
        self.app_id = app_id or os.getenv("LARK_APP_ID", "")
        app_id_key = self.app_id.upper().replace("-", "_")
        self.encrypt_key = (
            encrypt_key
            or os.getenv(f"LARK_{app_id_key}_ENCRYPT_KEY")
            or os.getenv("LARK_ENCRYPT_KEY", "")
        )
        self.verification_token = (
            verification_token
            or os.getenv(f"LARK_{app_id_key}_VERIFY_TOKEN")
            or os.getenv("LARK_VERIFY_TOKEN", "")
        )
    
    def verify_signature(
        self,
        timestamp: str,
        nonce: str,
        body: str,
        signature: str
    ) -> bool:
        """
        Verify the webhook signature from Lark using SHA-256
        
        Args:
            timestamp: Request timestamp from headers
            nonce: Request nonce from headers
            body: Raw request body
            signature: Signature from request headers
            
        Returns:
            True if signature is valid, False otherwise
        """
        if not self.encrypt_key:
            logger.warning('No encrypt key configured, skipping signature verification')
            return True
        
        content = f"{timestamp}{nonce}{self.encrypt_key}{body}"
        computed_signature = hashlib.sha256(content.encode('utf-8')).hexdigest()
        
        return computed_signature == signature
    
    # def decryptPayload(self, encryptedPayload: str) -> Dict[str, Any]:
        
    
    def verify_token(self, token: str) -> bool:
        """
        Verify the verification token from Lark
        
        Args:
            token: Token from event payload
            
        Returns:
            True if token is valid, False otherwise
        """
        if not self.verification_token:
            logger.warning('No verification token configured, skipping token verification')
            return True
        
        return token == self.verification_token
    
    def handle_meeting_ended_event(self, event: Dict[str, Any]) -> WebhookResponse:
        """
        Handle meeting ended event
        
        Args:
            event: The meeting ended event data
            
        Returns:
            WebhookResponse object
        """
        logger.info(f'Meeting ended event received: {json.dumps(event, indent=2)}')
        
        # Extract meeting details
        meeting_id = event.get('meeting_id')
        meeting_topic = event.get('meeting_topic')
        start_time = event.get('start_time')
        end_time = event.get('end_time')
        duration = event.get('duration')
        
        logger.info(f'Meeting details: {{\n'
                   f'  meetingId: {meeting_id},\n'
                   f'  meetingTopic: {meeting_topic},\n'
                   f'  startTime: {start_time},\n'
                   f'  endTime: {end_time},\n'
                   f'  duration: {duration}\n'
                   f'}}')
        
        # TODO: Add your business logic here
        # Examples:
        # - Fetch meeting transcript
        # - Process meeting recording
        # - Create meeting record in database
        # - Send notifications
        
        return WebhookResponse({'message': 'success'}, HTTPStatus.OK.value)
    
    def handle_lark_webhook(
        self,
        payload: Dict[str, Any],
        headers: Dict[str, str]
    ) -> WebhookResponse:
        """
        Main webhook handler for Lark events
        
        Args:
            body: Request body as string
            headers: Request headers as dictionary
            
        Returns:
            WebhookResponse object
        """
        try:
            # Handle plain-text URL verification (no encryption configured)
            if payload.get('type') == 'url_verification':
                token = payload.get('token', '')
                if not self.verify_token(token):
                    logger.error('Token verification failed on challenge')
                    return WebhookResponse(
                        {'error': 'Invalid verification token'},
                        HTTPStatus.UNAUTHORIZED.value
                    )
                return WebhookResponse(
                    {'challenge': payload.get('challenge')},
                    HTTPStatus.OK.value
                )

            # Handle encrypted events
            cipher = AESCipher(self.encrypt_key)
            decrypted_payload = json.loads(cipher.decrypt_string(payload.get('encrypt')))
            print("Decrypted Payload:", decrypted_payload)

            # Handle encrypted URL verification challenge
            if decrypted_payload.get('type') == 'url_verification':
                token = decrypted_payload.get('token', '')
                if not self.verify_token(token):
                    logger.error('Token verification failed on challenge')
                    return WebhookResponse(
                        {'error': 'Invalid verification token'},
                        HTTPStatus.UNAUTHORIZED.value
                    )
                return WebhookResponse(
                    {'challenge': decrypted_payload.get('challenge')},
                    HTTPStatus.OK.value
                )
            
            # Verify signature if provided
            timestamp = headers.get('x-lark-request-timestamp', '')
            nonce = headers.get('x-lark-request-nonce', '')
            signature = headers.get('x-lark-signature', '')
            
            if signature and not self.verify_signature(timestamp, nonce, json.dumps(payload), signature):
                logger.error('Signature verification failed')
                return WebhookResponse(
                    {'error': 'Invalid signature'},
                    HTTPStatus.UNAUTHORIZED.value
                )
                
            payload = decrypted_payload
            event_header = payload.get('header', {})
            event_data = payload.get('event', {})
            
            # Verify token
            token = event_header.get('token', '')
            if not self.verify_token(token):
                logger.error('Token verification failed')
                return WebhookResponse(
                    {'error': 'Invalid verification token'},
                    HTTPStatus.UNAUTHORIZED.value
                )
            
            # Route to appropriate event handler based on event type
            event_type = event_header.get('event_type', '')
            logger.info(f'Processing event type: {event_type}')

            # Map Lark event types to channel paths
            EVENT_TYPE_TO_PATH = {
                'im.message.receive_v1': '/message',
                'vc.meeting.all_meeting_ended_v1': '/meeting-ended',
            }
            channel_path = EVENT_TYPE_TO_PATH.get(event_type, '/unknown')

            self._push_to_redis(channel_path, payload)
            return WebhookResponse({'message': 'ok'}, HTTPStatus.OK.value)
        
        except json.JSONDecodeError as e:
            logger.error(f'JSON decode error: {e}')
            return WebhookResponse(
                {'error': 'Invalid JSON', 'details': str(e)},
                HTTPStatus.INTERNAL_SERVER_ERROR.value
            )
        except Exception as e:
            logger.error(f'Error processing webhook: {e}')
            return WebhookResponse(
                {'error': 'Internal server error', 'details': str(e)},
                HTTPStatus.INTERNAL_SERVER_ERROR.value
            )
    
    def crud_lark_webhook(
        self,
        subpath: str,
        method: str,
        body: str,
        headers: Dict[str, str]
    ) -> WebhookResponse:
        """
        CRUD handler for webhook endpoint
        
        Args:
            subpath: The subpath after /lark/webhook/
            method: HTTP method
            body: Request body
            headers: Request headers
            
        Returns:
            WebhookResponse object
        """
        # Webhook endpoint only accepts POST requests
        if method != 'POST':
            return WebhookResponse(
                {'error': 'Method not allowed. Only POST is supported.'},
                HTTPStatus.METHOD_NOT_ALLOWED.value
            )
        
        # Handle the webhook event
        return self.handle_lark_webhook(body, headers)

    def _push_to_redis(self, path: str, payload: dict) -> None:
        """Push a full context payload to Upstash Redis for the Mac daemon to consume."""
        redis_url = os.getenv("LARK_REDIS_URL")
        redis_token = os.getenv("LARK_REDIS_TOKEN")
        redis_key = os.getenv("LARK_REDIS_KEY", f"lark:events:{self.app_id}")

        if not redis_url or not redis_token:
            return

        event = payload.get("event", {})
        message = event.get("message", {})
        sender = event.get("sender", {}).get("sender_id", {})

        try:
            content = json.loads(message.get("content", "{}"))
            text = content.get("text", "")
        except Exception:
            text = ""

        mentions = [m.get("name", "") for m in message.get("mentions", [])]
        history = self._fetch_chat_history(message.get("chat_id", ""), limit=20)

        context = {
            "app_id": self.app_id,
            "path": path,
            "chat_id": message.get("chat_id", ""),
            "chat_type": message.get("chat_type", ""),
            "message_id": message.get("message_id", ""),
            "sender_open_id": sender.get("open_id", ""),
            "sender_name": self._resolve_sender_name(sender.get("open_id", "")),
            "text": text,
            "mentions": mentions,
            "history": history,
            "ts": payload.get("header", {}).get("create_time", ""),
            "raw": payload,
        }

        event_json = json.dumps(context)
        try:
            resp = requests.post(
                redis_url,
                headers={"Authorization": f"Bearer {redis_token}", "Content-Type": "application/json"},
                data=json.dumps(["RPUSH", redis_key, event_json]),
                timeout=3,
            )
            if resp.status_code == 200:
                logger.info(f"Pushed context payload to Redis ({redis_key}): {path}")
            else:
                logger.warning(f"Redis RPUSH returned {resp.status_code}")
        except Exception as e:
            logger.error(f"Failed to push to Redis: {e}")

    def _fetch_chat_history(self, chat_id: str, limit: int = 20) -> list:
        """Fetch recent messages from Lark for conversation context."""
        if not chat_id:
            return []
        try:
            from connectors.lark.client import get_tenant_access_token
            token = get_tenant_access_token()
            resp = requests.get(
                f"{os.getenv('LARK_BASE_URL', 'https://open.larksuite.com/open-apis')}"
                f"/im/v1/messages",
                headers={"Authorization": f"Bearer {token}"},
                params={"container_id_type": "chat", "container_id": chat_id, "page_size": limit},
                timeout=5,
            )
            if resp.status_code == 200:
                items = resp.json().get("data", {}).get("items", [])
                history = []
                for item in reversed(items):
                    try:
                        content = json.loads(item.get("body", {}).get("content", "{}"))
                        history.append({
                            "sender": item.get("sender", {}).get("id", ""),
                            "text": content.get("text", ""),
                            "ts": item.get("create_time", ""),
                        })
                    except Exception:
                        pass
                return history
        except Exception as e:
            logger.warning(f"Could not fetch chat history: {e}")
        return []

    def _resolve_sender_name(self, open_id: str) -> str:
        """Best-effort name resolution — returns open_id on failure."""
        return open_id


__all__ = ["LarkWebhookHandler"]

