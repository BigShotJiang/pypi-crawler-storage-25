import os
import sys
sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
import json
import requests
import httpx
from typing import Any, Dict, List, Optional, Sequence, Generator, AsyncGenerator
import base64
from pydantic import BaseModel, Field, ConfigDict, PrivateAttr, field_validator
from agents.tools.schema import ToolSchema
from dotenv import load_dotenv

load_dotenv()

# Default OpenRouter base URL
DEFAULT_OPENROUTER_BASE_URL = "https://openrouter.ai/api/v1"

class ImageDocument(BaseModel):
    image: str
    image_mimetype: str

class ChatMessage:
    def __init__(self, role: str, content: str, additional_kwargs: dict = None, cache_control: Optional[Dict[str, str]] = None):
        self.role = role
        self.content = content
        self.additional_kwargs = additional_kwargs or {}
        self.cache_control = cache_control

class LogProb(BaseModel):
    """LogProb of a token."""

    token: str = Field(default_factory=str)
    logprob: float = Field(default_factory=float)
    bytes: List[int] = Field(default_factory=list)
        
class ChatResponse(BaseModel):
    """Chat response."""
    model_config = {"arbitrary_types_allowed": True}

    message: ChatMessage
    raw: Optional[Any] = None
    delta: Optional[str] = None
    logprobs: Optional[List[List[LogProb]]] = None
    additional_kwargs: dict = Field(default_factory=dict)

    def __str__(self) -> str:
        return str(self.message)
      
ChatResponseGen = Generator[ChatResponse, None, None]
ChatResponseAsyncGen = AsyncGenerator[ChatResponse, None]

class CompletionResponse(BaseModel):
    """
    Completion response.

    Fields:
        text: Text content of the response if not streaming, or if streaming,
            the current extent of streamed text.
        additional_kwargs: Additional information on the response(i.e. token
            counts, function calling information).
        raw: Optional raw JSON that was parsed to populate text, if relevant.
        delta: New text that just streamed in (only relevant when streaming).
    """

    text: str
    additional_kwargs: dict = Field(default_factory=dict)
    raw: Optional[Any] = None
    logprobs: Optional[List[List[LogProb]]] = None
    delta: Optional[str] = None

    def __str__(self) -> str:
        return self.text


CompletionResponseGen = Generator[CompletionResponse, None, None]
CompletionResponseAsyncGen = AsyncGenerator[CompletionResponse, None]

class LLMMetadata(BaseModel):
    model_config = ConfigDict(
        protected_namespaces=("pydantic_model_",), arbitrary_types_allowed=True
    )
    context_window: int = Field(
        default=4096,
        description=(
            "Total number of tokens the model can be input and output for one response."
        ),
    )
    num_output: int = Field(
        default=4096,
        description="Number of tokens the model can output when generating a response.",
    )
    is_chat_model: bool = Field(
        default=True,
        description=(
            "Set True if the model exposes a chat interface (i.e. can be passed a"
            " sequence of messages, rather than text), like OpenAI's"
            " /v1/chat/completions endpoint."
        ),
    )
    is_function_calling_model: bool = Field(
        default=False,
        # SEE: https://openai.com/blog/function-calling-and-other-api-updates
        description=(
            "Set True if the model supports function calling messages, similar to"
            " OpenAI's function calling API. For example, converting 'Email Anya to"
            " see if she wants to get coffee next Friday' to a function call like"
            " `send_email(to: string, body: string)`."
        ),
    )
    model_name: str = Field(
        default="unknown",
        description=(
            "The model's name used for logging, testing, and sanity checking. For some"
            " models this can be automatically discerned. For other models, like"
            " locally loaded models, this must be manually specified."
        ),
    )
    system_role: str = Field(
        default="system",
        description="The role this specific LLM provider"
        "expects for system prompt. E.g. 'SYSTEM' for OpenAI, 'CHATBOT' for Cohere",
    )
    
class ToolSelection(BaseModel):
    """Tool selection."""

    tool_id: str = Field(description="Tool ID to select.")
    tool_name: str = Field(description="Tool name to select.")
    tool_kwargs: Dict[str, Any] = Field(description="Keyword arguments for the tool.")

    @field_validator("tool_kwargs", mode="wrap")
    @classmethod
    def ignore_non_dict_arguments(cls, v: Any, handler: Any) -> Dict[str, Any]:
        try:
            return handler(v)
        except ValueError:
            return handler({})
      
def process_uri_to_llama_format(data_uri: str) -> ImageDocument:
    base64_data = data_uri.split(",")[1]
    # data_bytes=base64.b64decode(base64_data)
    image_mimetype = data_uri.split(",")[0].replace("data:", "").replace(";base64","")
    return ImageDocument(
        image=base64_data,
        image_mimetype=image_mimetype
    )

class OpenRouterMultimodalLLM():
    """
    OpenRouter LLM that uses the requests library for multimodal and function calling support.
    """

    def __init__(
        self,
        model: Optional[str] = None,
        fallback_models: Optional[list[str]] = None,
        api_key: Optional[str] = None,
        base_url: str = "https://openrouter.ai/api/v1",
        temperature: float = 0.7,
        max_tokens: int = 4096,
        reasoning_effort: Optional[str] = None,
        **kwargs: Any,
    ) -> None:
        api_key = api_key or os.getenv("OPENROUTER_API_KEY")
        if not api_key:
            raise ValueError("API key is required.")

        self.model = model
        self.fallback_models = fallback_models
        self.temperature = temperature
        self.max_tokens = max_tokens
        self.base_url = base_url
        self.api_key = api_key
        self.reasoning_effort = reasoning_effort
        
        headers = {"Authorization": f"Bearer {self.api_key}", "Content-Type": "application/json"}
        self._sync_client = requests.Session()
        self._sync_client.headers.update(headers)
        self._async_client = httpx.AsyncClient(timeout=30.0)
        self._async_client.headers.update(headers)

    @classmethod
    def class_name(cls) -> str:
        return "OpenRouterMultimodalLLM"

    @property
    def metadata(self) -> LLMMetadata:
        return LLMMetadata(is_chat_model=True, is_function_calling_model=True, model_name=self.model)

    def construct_message_list(self, system_prompt: str, user_prompt: str, **kwargs: Any) -> List[ChatMessage]:
        return [
            ChatMessage(role="system", content=system_prompt),
            ChatMessage(role="user", content=user_prompt, additional_kwargs=kwargs if kwargs else None),
        ]

    def _to_openrouter_messages(self, messages: Sequence[ChatMessage]) -> List[Dict[str, Any]]:
        results = []
        for msg in messages:
            # Safely check for additional_kwargs
            additional_kwargs = getattr(msg, 'additional_kwargs', {}) or {}
            
            has_images = (
                additional_kwargs
                and "image_urls" in additional_kwargs
                and additional_kwargs["image_urls"]
            )
            
            has_video = (
                additional_kwargs
                and "video_urls" in additional_kwargs
                and additional_kwargs["video_urls"]
            )
            
            has_files = (
                additional_kwargs
                and "files" in additional_kwargs
                and additional_kwargs["files"]
            )

            if has_images or has_files or has_video:
                content_parts = [{"type": "text", "text": msg.content or ""}]
                
                if has_images:
                    for url in additional_kwargs["image_urls"]:
                        content_parts.append(
                            {"type": "image_url", "image_url": {"url": url}}
                        )

                if has_files:
                    for file in additional_kwargs["files"]:
                        content_parts.append(
                            {"type": "file", "file": {"filename": file["name"], "file_data": file["content"]}}
                        )
                        
                if has_video:
                    for url in additional_kwargs["video_urls"]:
                        content_parts.append(
                            {"type": "video_url", "videoUrl": {"url": url}}
                        )
                        
                content = content_parts
            else:
                content = msg.content

            # Handle role properly - check if it's a string or enum
            role = msg.role if isinstance(msg.role, str) else msg.role
            message_dict = {"role": role, "content": content}

            # Handle assistant messages with tool_calls
            additional_kwargs = msg.additional_kwargs or {}
            if role == "assistant" and "tool_calls" in additional_kwargs:
                message_dict["tool_calls"] = additional_kwargs["tool_calls"]

            # Handle tool result messages
            if role == "tool":
                if "tool_call_id" in additional_kwargs:
                    message_dict["tool_call_id"] = additional_kwargs["tool_call_id"]
                if "name" in additional_kwargs:
                    message_dict["name"] = additional_kwargs["name"]

            # Add cache_control if present
            if hasattr(msg, 'cache_control') and msg.cache_control:
                message_dict["cache_control"] = msg.cache_control

            results.append(message_dict)
        return results

    def _build_payload(self, messages: Sequence[ChatMessage], **kwargs) -> Dict[str, Any]:
        payload = {
            "messages": self._to_openrouter_messages(messages),
            "temperature": self.temperature,
            "max_tokens": self.max_tokens,
            **kwargs,
        }

        # OpenRouter fallback pattern: use "models" array (no "model" key) when fallbacks configured.
        # If both are present, "model" takes precedence and "models" is ignored.
        if self.fallback_models:
            payload["models"] = self.fallback_models
        else:
            payload["model"] = self.model

        if self.reasoning_effort:
            payload["reasoning"] = {"effort": self.reasoning_effort}
        return payload

    def chat(self, messages: Sequence[ChatMessage], **kwargs: Any) -> ChatResponse:
        tools = kwargs.pop("tools", None)
        tool_choice = kwargs.pop("tool_choice", "auto")
        if tools:
            kwargs.update(self._prepare_chat_with_tools(tools, tool_choice))
        payload = self._build_payload(messages, **kwargs)
        
        response = self._sync_client.post(f"{self.base_url}/chat/completions", json=payload, headers=self._sync_client.headers)
        response.raise_for_status()
        data = response.json()
        message = data["choices"][0]["message"]
        additional_kwargs = {}
        if tool_calls := message.get("tool_calls"):
            additional_kwargs["tool_calls"] = tool_calls
        
        if annotations := message.get("annotations"):
            additional_kwargs["annotations"] = annotations
        
        if images := message.get("images"):
            additional_kwargs["images"] = [
                process_uri_to_llama_format(image.get("image_url").get("url")) \
                for image in images
            ]
        
        return ChatResponse(
            message=ChatMessage(
                role=message["role"],
                content=message.get("content", ""),
                additional_kwargs=additional_kwargs,
            )
        )

    def stream_chat(self, messages: Sequence[ChatMessage], **kwargs: Any) -> ChatResponseGen:
        tools = kwargs.pop("tools", None)
        tool_choice = kwargs.pop("tool_choice", "auto")
        if tools:
            kwargs.update(self._prepare_chat_with_tools(tools, tool_choice))
        payload = self._build_payload(messages, stream=True, **kwargs)
        response = self._sync_client.post(f"{self.base_url}/chat/completions", json=payload, stream=True, headers=self._sync_client.headers)
        response.raise_for_status()
        
        additional_kwargs = {}
        additional_kwargs["images"] = []

        def gen() -> ChatResponseGen:
            content = ""
            for line in response.iter_lines():
                if line:
                    line = line.decode('utf-8')
                    if line.startswith('data: '):
                        line = line[6:]
                    if line == '[DONE]':
                        break
                    try:
                        data = json.loads(line)
                        delta = data['choices'][0]['delta']
                        content_delta = delta.get('content', '')
                        
                        if images:= delta.get("images") :
                            additional_kwargs["images"] = [
                                process_uri_to_llama_format(image.get("image_url").get("url")) \
                                for image in images
                            ]
                        if content_delta:
                            content += content_delta
                        
                        yield ChatResponse(
                            message=ChatMessage(role='assistant', content=content),
                            delta=content_delta,
                            additional_kwargs=additional_kwargs
                        )
                        
                    except json.JSONDecodeError:
                        pass
        return gen()

    async def achat(self, messages: Sequence[ChatMessage], **kwargs: Any) -> ChatResponse:
        tools = kwargs.pop("tools", None)
        tool_choice = kwargs.pop("tool_choice", "auto")
        plugin = kwargs.pop("plugin", None)
        
        if tools:
            kwargs.update(self._prepare_chat_with_tools(tools, tool_choice))
            # print(f"DEBUG: KWARG after tools prep: {kwargs}")
        
        if plugin:
            kwargs["plugin"] = plugin
            
        payload = self._build_payload(messages, **kwargs)

        # Debug: print payload for troubleshooting
        # print(f"DEBUG: Sending payload: {json.dumps(payload, indent=2)}")

        response = await self._async_client.post(f"{self.base_url}/chat/completions", json=payload, headers=self._async_client.headers)

        # If error, print response details
        if response.status_code != 200:
            print(f"ERROR Response Status: {response.status_code}")
            print(f"ERROR Response Body: {response.text}")

        response.raise_for_status()
        data = response.json()
        # print(f"DEBUG: Full response data: {json.dumps(data, indent=2)}")

        # Log cache savings if available
        if data.get("usage"):
            usage = data["usage"]
            cache_read_tokens = usage.get("cache_read_tokens", 0)
            cache_creation_tokens = usage.get("cache_creation_tokens", 0)
            
            if cache_read_tokens > 0:
                print(f"💰 Cache READ: {cache_read_tokens} tokens (saved ~{cache_read_tokens * 0.75:.0f} tokens worth of cost)")
            
            if cache_creation_tokens > 0:
                print(f"📝 Cache WRITE: {cache_creation_tokens} tokens")

        if "choices" not in data:
            raise ValueError(f"API response missing 'choices' key. Response: {data}")

        message = data["choices"][0]["message"]
        additional_kwargs = {}

        if tool_calls := message.get("tool_calls"):
            print("Tool calls: ", tool_calls)
            additional_kwargs["tool_calls"] = tool_calls
            
        if annotations := message.get("annotations"):
            additional_kwargs["annotations"] = annotations
            
        if images := message.get("images"):
            additional_kwargs["images"] = [
                process_uri_to_llama_format(image.get("image_url").get("url")) \
                for image in images
            ]
        
        return ChatResponse(
            message=ChatMessage(
                role=message["role"],
                content=message.get("content", ""),
                additional_kwargs=additional_kwargs,
            )
        )

    def astream_chat(
        self, messages: Sequence[ChatMessage], **kwargs: Any
    ) -> ChatResponseAsyncGen:
        tools = kwargs.pop("tools", None)
        tool_choice = kwargs.pop("tool_choice", "auto")
        if tools:
            kwargs.update(self._prepare_chat_with_tools(tools, tool_choice))
        payload = self._build_payload(messages, stream=True, **kwargs)
        additional_kwargs = {}
        additional_kwargs["images"] = []

        async def gen() -> ChatResponseAsyncGen:
            async with self._async_client.stream(
                "POST",
                f"{self.base_url}/chat/completions",
                json=payload,
                headers=self._async_client.headers,
            ) as response:
                response.raise_for_status()
                content = ""
                async for line in response.aiter_lines():
                    if line:
                        if line.startswith('data: '):
                            line = line[6:]
                        if line == '[DONE]':
                            break
                        try:
                            data = json.loads(line)
                            choices = data.get('choices')
                            if not choices:
                                continue
                            delta = choices[0]['delta']
                            content_delta = delta.get('content', '')
                            
                            if images:= delta.get("images") :
                                additional_kwargs["images"].extend([
                                    process_uri_to_llama_format(image.get("image_url").get("url")) \
                                    for image in images
                                ])
                            if content_delta:
                                content += content_delta
                            
                            yield ChatResponse(
                                message=ChatMessage(role='assistant', content=content),
                                delta=content_delta,
                                additional_kwargs=additional_kwargs
                            )
                        except json.JSONDecodeError:
                            pass

        return gen()

    def _prepare_chat_with_tools(self, tools: List[ToolSchema], tool_choice: str = "auto") -> dict:
        """Prepare tools for OpenRouter API call
        
        Args:
            tools: List of tool schemas
            tool_choice: Tool choice mode - "auto", "required", "none", or specific tool name
        """
        tool_specs = []
        for t in tools:
            # Handle both ToolSchema objects and dict schemas
            if hasattr(t, 'to_openrouter_tool_schema'):
                schema = t.to_openrouter_tool_schema()
            elif isinstance(t, dict):
                schema = t
            else:
                continue
            tool_specs.append({"type": "function", "function": schema})
        return {"tools": tool_specs, "tool_choice": tool_choice}

    def get_tool_calls_from_response(self, response: ChatResponse, **kwargs) -> List[ToolSelection]:
        tool_calls = response.message.additional_kwargs.get("tool_calls")
        if not tool_calls:
            return []
        selections = []
        for tool_call in tool_calls:
            try:
                func = tool_call['function']
                selections.append(ToolSelection(tool_id=tool_call['id'], tool_name=func['name'], tool_kwargs={**json.loads(func['arguments']), **kwargs}))
            except (json.JSONDecodeError, KeyError) as e:
                raise ValueError(f"Failed to parse tool call: {tool_call}. Error: {e}")
        return selections

    # --- Not Implemented Methods ---
    def complete(self, prompt: str, **kwargs: Any) -> CompletionResponse:
        raise NotImplementedError("This model only supports chat.")

    def stream_complete(self, prompt: str, **kwargs: Any) -> CompletionResponseGen:
        raise NotImplementedError("This model only supports chat.")

    async def acomplete(self, prompt: str, **kwargs: Any) -> CompletionResponse:
        payload = {
            "model": self.model,
            "prompt": prompt,
            "temperature": self.temperature,
            "max_tokens": self.max_tokens,
            "usage": {
                "include": True,
            },
            **kwargs,
        }
        
        response = await self._async_client.post(
            f"{self.base_url}/completions",
            json=payload,
            headers=self._async_client.headers
        )
        
        response.raise_for_status()
        
        data = response.json()
        data = data["choices"][0]
        text = data.get("text", "")
        openai_completion_logprobs = data.get("logprobs")
        logprobs = None

        return CompletionResponse(
            text=text,
            raw=response,
            logprobs=logprobs,
            additional_kwargs={
                key: value
                for key, value in data.items()
                if key != "text"
            },
        )
    
    async def close(self):
        """Close the async HTTP client"""
        await self._async_client.aclose()
