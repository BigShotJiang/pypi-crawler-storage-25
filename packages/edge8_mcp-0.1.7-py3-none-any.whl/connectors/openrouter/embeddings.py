"""
OpenRouter Embeddings Client for qwen/qwen3-embedding-8b
Supports batch processing and custom dimensions
"""

import os
import httpx
from typing import List, Optional
from dotenv import load_dotenv

load_dotenv()

class OpenRouterEmbeddings:
    """
    Client for generating embeddings via OpenRouter API
    Model: qwen/qwen3-embedding-8b
    """
    
    def __init__(
        self,
        api_key: Optional[str] = None,
        model: str = "qwen/qwen3-embedding-8b",
        dimensions: int = 1536,
        base_url: str = "https://openrouter.ai/api/v1"
    ):
        self.api_key = api_key or os.getenv("OPENROUTER_API_KEY")
        if not self.api_key:
            raise ValueError("OPENROUTER_API_KEY not found in environment variables")
        
        self.model = model
        self.dimensions = dimensions
        self.base_url = base_url
        
        if not 32 <= dimensions <= 4096:
            raise ValueError(f"Dimensions must be between 32 and 4096, got {dimensions}")
        
        self.client = httpx.AsyncClient(timeout=30.0)
        self.sync_client = httpx.Client(timeout=30.0)
    
    async def aembed_text(
        self, 
        text: str,
        instruction: Optional[str] = None
    ) -> List[float]:
        """Generate embedding for single text asynchronously"""
        embeddings = await self.aembed_texts([text], instruction)
        return embeddings[0]
    
    async def aembed_texts(
        self, 
        texts: List[str],
        instruction: Optional[str] = None
    ) -> List[List[float]]:
        """Generate embeddings for multiple texts (batch)"""
        inputs = texts
        if instruction:
            inputs = [f"{instruction}\n{text}" for text in texts]
        
        payload = {
            "model": self.model,
            "input": inputs,
            "dimensions": self.dimensions
        }
        
        headers = {
            "Authorization": f"Bearer {self.api_key}",
            "Content-Type": "application/json"
        }
        
        response = await self.client.post(
            f"{self.base_url}/embeddings",
            json=payload,
            headers=headers
        )
        response.raise_for_status()
        
        data = response.json()
        embeddings = [item["embedding"] for item in data["data"]]
        
        # L2 normalize embeddings (required for qwen/qwen3-embedding-8b)
        embeddings = [self._normalize_l2(e) for e in embeddings]
        
        return embeddings
    
    def _normalize_l2(self, embedding: List[float]) -> List[float]:
        """Apply L2 normalization to embedding vector"""
        import numpy as np
        arr = np.array(embedding, dtype=np.float32)
        norm = np.linalg.norm(arr)
        if norm == 0:
            return embedding
        return (arr / norm).tolist()
    
    def embed_text(
        self, 
        text: str,
        instruction: Optional[str] = None
    ) -> List[float]:
        """Generate embedding for single text synchronously"""
        embeddings = self.embed_texts([text], instruction)
        return embeddings[0]
    
    def embed_texts(
        self, 
        texts: List[str],
        instruction: Optional[str] = None
    ) -> List[List[float]]:
        """Generate embeddings for multiple texts synchronously"""
        inputs = texts
        if instruction:
            inputs = [f"{instruction}\n{text}" for text in texts]
        
        payload = {
            "model": self.model,
            "input": inputs,
            "dimensions": self.dimensions
        }
        
        headers = {
            "Authorization": f"Bearer {self.api_key}",
            "Content-Type": "application/json"
        }
        
        response = self.sync_client.post(
            f"{self.base_url}/embeddings",
            json=payload,
            headers=headers
        )
        response.raise_for_status()
        
        data = response.json()
        embeddings = [item["embedding"] for item in data["data"]]
        
        # L2 normalize embeddings (required for qwen/qwen3-embedding-8b)
        embeddings = [self._normalize_l2(e) for e in embeddings]
        
        return embeddings
    
    async def close(self):
        """Close async HTTP client"""
        await self.client.aclose()
    
    def close_sync(self):
        """Close sync HTTP client"""
        self.sync_client.close()
