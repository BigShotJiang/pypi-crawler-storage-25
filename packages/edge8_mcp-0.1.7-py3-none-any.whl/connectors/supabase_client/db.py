from __future__ import annotations
import os
from typing import Union, List, Dict, TYPE_CHECKING
from connectors.supabase_client.createClient import get_custom_client

if TYPE_CHECKING:
    from supabase import Client

def get_supabase_client() -> Client:
    """Initializes and returns a Supabase client."""
    return get_custom_client()

def get_content(content_id: str, language: str) -> dict:
    """Retrieves content from the 'content_transcripts' table."""
    supabase = get_supabase_client()
    res = supabase\
        .table("content_transcripts")\
        .select("*,sentence_timestamps(sentence, start_time, end_time)")\
        .eq("content_id", content_id)\
        .eq("language", language)\
        .execute()
    
    # print("Transcript Supa Content: ", res.data)
        
    return res.data[0] if res.data and len(res.data) > 0 else None

def get_media_assets_info(query_items: list[str], query_type: str = "id") -> list[dict]:
    supabase = get_supabase_client()
    res = supabase\
        .table("media_assets")\
        .select("*")\
        .in_(query_type, query_items)\
        .neq("storage_path", None)\
        .execute()
    
    return res.data

def update_translation(content_id: str, language: str, translation: str, ssml: str) -> dict:
    """Uploads a translation to the 'content_transcripts' table."""
    supabase = get_supabase_client()
    res = supabase.table("content_transcripts").update({
        "content": translation,
        "ssml_content": ssml
    }).eq("content_id", content_id).eq("language", language).execute()
    return res.data[0] if res.data else None

def upload_translation(content_id: str, language: str, translation: str, ssml: str) -> dict:
    """Uploads a translation to the 'content_transcripts' table."""
    supabase = get_supabase_client()
    res = supabase.table("content_transcripts").insert({
        "content_id": content_id,
        "language": language,
        "content": translation,
        "ssml_content": ssml
    }).execute()
    return res.data[0] if res.data else None

def upload_transcript_sentence_timestamps(transcript_id: str, timestamps: list) -> list:
    """Uploads transcript sentence timestamps to the 'content_transcripts' table."""
    supabase = get_supabase_client()
    res = supabase\
        .table("sentence_timestamps")\
        .insert([
            {
                "transcript_id": transcript_id,
                "start_time": timestamp["start_time"],
                "end_time": timestamp["end_time"],
                "sentence": timestamp["sentence"]
            } for timestamp in timestamps
        ])\
        .execute()
        
    return res.data if res.data else None

def create_session(content_id: str, language: str) -> dict:
    """Creates a new TTS session in the 'tts_sessions' table."""
    supabase = get_supabase_client()
    res = supabase.table("tts_sessions").insert({
        "content_id": content_id,
        "language": language,
        "current_position": 0.0,
        "is_playing": True
    }).execute()
    return res.data[0] if res.data else None

def update_session(session_id: str, position: float, is_playing: bool) -> dict:
    """Updates a TTS session's position and playing status."""
    supabase = get_supabase_client()
    res = supabase.table("tts_sessions").update({
        "current_position": position,
        "is_playing": is_playing,
        "updated_at": "now()"
    }).eq("id", session_id).execute()
    return res.data[0] if res.data else None

def get_session(session_id: str) -> dict:
    """Retrieves a TTS session by its ID."""
    supabase = get_supabase_client()
    res = supabase.table("tts_sessions").select("*").eq("id", session_id).execute()
    return res.data[0] if res.data else None

async def basic_insertion(table_name: str, data: Union[Dict, List[Dict]], supabase_client: Union[Client, None] = None) -> List:
    if supabase_client is None:
        supabase_client = get_supabase_client()
    res = supabase_client.table(table_name).insert(data).execute()
    return res.data

def upsert_with_conflict_skip(supabase_client: Client, table_name: str, data: dict, on_conflict: str):
    """
    Performs upsert but silently skips if unique constraint conflict occurs.
    Duplicates are still blocked at the database level.
    """
    print("Data: ", data)
    try:
        response = (
            supabase_client
            .table(table_name)
            .upsert(data, on_conflict=on_conflict)
            .execute()
        )
        print("response: ", response)
        return {"success": True, "data": response.data[0], "skipped": False}
    except Exception as e:
        # Check if it's a unique constraint violation
        error_message = str(e).lower()
        print("error_message: ", error_message)
        if "unique" in error_message or "duplicate" in error_message:
            # Silently skip - duplicate was blocked at DB level
            return {"success": True, "data": None, "skipped": True}
        else:
            # Re-raise other errors
            raise


__all__ = [
    "get_supabase_client",
    "get_content",
    "get_media_assets_info",
    "update_translation",
    "upload_translation",
    "upload_transcript_sentence_timestamps",
    "create_session",
    "update_session",
    "get_session",
    "basic_insertion",
    "upsert_with_conflict_skip"
]