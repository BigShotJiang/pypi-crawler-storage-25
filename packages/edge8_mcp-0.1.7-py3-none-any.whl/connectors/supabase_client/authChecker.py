import json
import base64
import time
import os
from dotenv import load_dotenv

load_dotenv()

def auth_checker(token: str) -> bool:
    if not token:
        return False
    
    if token.startswith("sb_publishable"):
        return token == os.getenv("SERVER_AUTH_API_KEY")
    
    token_payload = token.split(".")
    if (len(token_payload) == 0 or len(token_payload) != 3):
        return False
    
    decoded_token = str(base64.b64decode(token_payload[1] + "=="), "utf-8 ")
    payload = json.loads(decoded_token)
    
    return payload.get("exp") > time.time()

__all__ = ["auth_checker"]
