from __future__ import annotations
from dotenv import load_dotenv
import os
from typing import Optional, TypedDict

load_dotenv()

SUPABASE_URL = os.environ.get("AIO_SUPABASE_URL")
SUPABASE_KEY = os.environ.get("AIO_SUPABASE_ANON_KEY")

customClientDict = TypedDict(
    "CustomClientDict",
    {
        "headers": Optional[dict[str, str]],
        "schema": Optional[str]
    }
)

def get_custom_client(
    url: Optional[str] = None,
    key: Optional[str] = None,
    options: customClientDict = {}
):
    from supabase.client import Client, ClientOptions, create_client

    if url is None:
        url = SUPABASE_URL
    if key is None:
        key = SUPABASE_KEY

    return create_client(url, key, ClientOptions(
        headers=options.get("headers", {}),
        schema=options.get("schema", "public")
    ))

__all__ = ["get_custom_client"]
