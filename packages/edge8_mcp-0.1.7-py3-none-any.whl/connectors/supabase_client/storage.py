from __future__ import annotations
import os
import sys
import time
import asyncio
from concurrent.futures import ThreadPoolExecutor

sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from uuid import uuid4
import base64
from typing import Optional, Union
from connectors.supabase_client.createClient import get_custom_client

# Global thread pool executor to prevent resource exhaustion
_global_executor = None
_executor_lock = asyncio.Lock()

async def get_global_executor():
    """Get or create a global thread pool executor with limited workers"""
    global _global_executor
    async with _executor_lock:
        if _global_executor is None:
            # Limit max_workers to prevent resource exhaustion in Cloud Run
            max_workers = min(4, (os.cpu_count() or 1) + 1)
            _global_executor = ThreadPoolExecutor(max_workers=max_workers)
        return _global_executor

def upload_to_storage(
    custom_supabase: Client, 
    mime_type: str,
    media_body: Union[str, bytes],
    bucket_name: str, 
    file_name: str, 
    url_exp: Optional[int] = 60*60*24*364*10
) -> dict:
    start_time = time.time()
    try:
        if isinstance(media_body, str):
            if "base64" in media_body:
                media_body = media_body.split("base64,")[1]
                
            file_bytes = base64.b64decode(media_body)
        else:
            file_bytes = media_body
        
        file_ext = file_name.split(".")[-1] if "." in file_name else ""
            
        print("Supabase upload - Decoded file size:",len(file_bytes)," B")
        try:
            result = (
                custom_supabase\
                    .storage\
                    .from_(bucket_name)\
                    .upload(
                        file=file_bytes,
                        path=file_name,
                        file_options={
                            "cache-control": "3600", 
                            "upsert": "false",
                            "content-type": mime_type
                        }
                    )
            )
        except Exception as e:
            error_code = getattr(e, 'status', None) or getattr(e, 'code', None)
        
            if error_code == '409':
                duplication_count = 2
                max_duplicates = 100
                while error_code == '409' and duplication_count <= max_duplicates:
                    new_file_name = file_name.replace(f".{file_ext}", f" ({duplication_count}).{file_ext}")
                    
                    try:
                        result = (
                            custom_supabase\
                                .storage\
                                .from_(bucket_name)\
                                .upload(
                                    file=file_bytes,
                                    path=new_file_name,
                                    file_options={
                                        "cache-control": "3600", 
                                        "upsert": "false", 
                                        "content-type": mime_type
                                    }
                                )
                        )
                        break
                    except Exception as e:
                        error_code = getattr(e, 'status', None) or getattr(e, 'code', None)
                        if error_code == '409':
                            duplication_count += 1
                        else:
                            raise
                
                if error_code == '409':
                    raise Exception(f"Could not find unique filename after {max_duplicates} attempts")
            else:
                raise
        
        print("Time taken for upload:", time.time()- start_time)
        
        url_response = (
            custom_supabase.storage
            .from_(bucket_name)
            .create_signed_url(
                result.path,
                60 * 60 * 24 * 364 * 10 if url_exp == 0 else url_exp
            )
        )
        
        search_key = result.path.split("/")[-1].split(".")[0]
        print("Supabase upload - Search key:", search_key)
        folder = result.path.replace(result.path.split("/")[-1], "")
        print("Supabase upload - Folder:", folder)
        
        storage_object = custom_supabase.storage.from_(bucket_name).list(
            path=folder,
            options={
                "limit": 1,
                "offset": 0,
                "sortBy": {"column": "created_at", "order": "desc"},
                "search": search_key,
            }
        )
        
        print("Time taken for list:", time.time()- start_time)
        
        # print("Supabase upload - Storage object:", storage_object)
        
        print("Time taken for signed url creation:", time.time()- start_time)
        object_id = None
        
        if storage_object and len(storage_object) > 0:
            object_id = storage_object[0]["id"]
        
        print("Supabase upload - Object ID:", object_id)
    
        return {
            "url": url_response.get("signedUrl"), 
            "path": result.path,
            "id": object_id
        }
    
    except Exception as e:
        raise
    
    

async def async_upload_to_storage(
    custom_supabase: Client, 
    mime_type: str,
    media_body: Union[str, bytes],
    bucket_name: str, 
    user_id: str, 
    url_exp: Optional[int] = 0
) -> dict:

    try:
        if isinstance(media_body, str):
            if "base64" in media_body:
                media_body = media_body.split("base64,")[1]
                
            file_bytes = base64.b64decode(media_body)
        else:
            file_bytes = media_body
            
        print("Supabase upload - Decoded file size:",len(file_bytes)," B")
        
        extension = mime_type.split("/")[1]
        
        result = (
            custom_supabase\
                .storage\
                .from_(bucket_name)\
                .upload(
                file=file_bytes,
                path=f"{user_id}/{uuid4()}.{extension}",
                file_options={"cache-control": "3600", "upsert": "false", "content-type": mime_type}
            )
        )
        
        url_response = (
            custom_supabase.storage
            .from_(bucket_name)
            .create_signed_url(
                result.path,
                60 * 60 * 24 * 364 * 10 if url_exp == 0 else url_exp
            )
        )
        
        media_asset = custom_supabase.table("media_assets")\
            .insert({
                "url": url_response.get("signedUrl"), 
                "storage_path": result.path,
                "user_id": user_id,
                "mime_type": mime_type,
                "usage": "story",
                "bucket": bucket_name
            })\
            .execute()\
            .data[0]
        
    except Exception as e:
        raise Exception(e)
    
    print("Supabase upload - Path:", result.path)
    
    return {"url": url_response.get("signedUrl"), "path": result.path, "id": media_asset["id"]}

async def concurrent_async_upload_to_storage(
    custom_supabase: Client, 
    mime_type: str,
    media_body: Union[str, bytes],
    bucket_name: str, 
    user_id: str, 
    url_exp: Optional[int] = 0
) -> dict:
    """
    Cloud Run optimized version with resource management to prevent Errno 11.
    
    Performance improvements:
    - Uses global thread pool executor to prevent resource exhaustion
    - Semaphore-controlled concurrency for Cloud Run environments
    - Enhanced error handling for resource constraints
    - Retry logic for temporary resource unavailability
    """
    start_time = time.time()
    
    # Semaphore to limit concurrent operations in Cloud Run
    semaphore = asyncio.Semaphore(2)  # Limit to 2 concurrent operations
    
    async with semaphore:
        try:
            # Get global executor to prevent resource exhaustion
            executor = await get_global_executor()
            
            # Optimize base64 decoding - do this first to fail fast if invalid
            if isinstance(media_body, str):
                if "base64," in media_body:
                    # More efficient split - only split once and take the last part
                    media_body = media_body.split("base64,", 1)[1]
                
                # Use global executor for CPU-intensive base64 decoding
                loop = asyncio.get_event_loop()
                file_bytes = await loop.run_in_executor(executor, base64.b64decode, media_body)
            else:
                file_bytes = media_body
                
            file_size = len(file_bytes)
            print(f"Supabase upload - Decoded file size: {file_size} B")
            
            # Generate unique filename once
            file_extension = mime_type.split("/")[1] if "/" in mime_type else "bin"
            file_path = f"{user_id}/{uuid4()}.{file_extension}"
            
            # Step 1: Upload file with retry logic
            upload_start = time.time()
            
            async def upload_with_retry():
                for attempt in range(3):
                    try:
                        loop = asyncio.get_event_loop()
                        return await loop.run_in_executor(
                            executor,
                            lambda: custom_supabase.storage.from_(bucket_name).upload(
                                file=file_bytes,
                                path=file_path,
                                file_options={
                                    "cache-control": "3600", 
                                    "upsert": "false", 
                                    "content-type": mime_type
                                }
                            )
                        )
                    except OSError as e:
                        if e.errno == 11 and attempt < 2:  # Resource temporarily unavailable
                            await asyncio.sleep(0.1 * (attempt + 1))  # Exponential backoff
                            continue
                        raise
                    except Exception as e:
                        if attempt < 2:
                            await asyncio.sleep(0.1 * (attempt + 1))
                            continue
                        raise
            
            result = await upload_with_retry()
            print(f"Upload completed in: {time.time() - upload_start:.3f}s")
            
            # Step 2: Sequential operations with shared executor
            concurrent_start = time.time()
            
            async def create_signed_url_async():
                """Create signed URL using global executor"""
                loop = asyncio.get_event_loop()
                return await loop.run_in_executor(
                    executor,
                    lambda: custom_supabase.storage.from_(bucket_name).create_signed_url(
                        result.path,
                        60 * 60 * 24 * 364 * 10 if url_exp == 0 else url_exp
                    )
                )
            
            async def insert_media_asset_async(signed_url):
                """Insert media asset using global executor"""
                loop = asyncio.get_event_loop()
                return await loop.run_in_executor(
                    executor,
                    lambda: custom_supabase.table("media_assets").insert({
                        "url": signed_url.get("signedUrl"), 
                        "storage_path": result.path,
                        "user_id": user_id,
                        "mime_type": mime_type,
                        "usage": "story",
                        "bucket": bucket_name
                    }).execute().data[0]
                )
            
            # Create signed URL first, then insert media asset
            url_response = await create_signed_url_async()
            media_asset = await insert_media_asset_async(url_response)
            
            print(f"Sequential operations completed in: {time.time() - concurrent_start:.3f}s")
            print(f"Total upload time: {time.time() - start_time:.3f}s")
            print(f"Supabase upload - Path: {result.path}")
            
            return {
                "url": url_response.get("signedUrl"), 
                "path": result.path,
                "id": media_asset["id"]
            }
        
        except OSError as e:
            if e.errno == 11:
                print(f"Resource temporarily unavailable after {time.time() - start_time:.3f}s - Cloud Run resource limit hit")
            else:
                print(f"OS Error {e.errno} after {time.time() - start_time:.3f}s: {str(e)}")
            return None
        except Exception as e:
            print(f"Upload failed after {time.time() - start_time:.3f}s: {str(e)}")
            return None

def get_public_url(bucket: str, path: str) -> str:
    """Gets the public URL for a file in Supabase Storage."""
    supabase = get_custom_client()
    return supabase.storage.from_(bucket).get_public_url(path)

def create_signed_url(bucket: str, path: str) -> str:
    supabase = get_custom_client()
    try:
        response_signed_url = supabase.storage\
            .from_(bucket)\
            .create_signed_url(
                path,
                60 * 60 * 24 * 364 * 10
        )
        
        return response_signed_url.get("signedUrl")
    except Exception as e:
        raise Exception(e)

def download_audio_chunk(bucket: str, path: str, byte_range: tuple) -> bytes:
    """Downloads a chunk of an audio file from Supabase Storage."""
    supabase = get_custom_client()
    response = supabase.storage.from_(bucket).download(path)
    return response[byte_range[0]:byte_range[1]]

def download_file_data(bucket: str, path: str) -> bytes:
    """Downloads an audio file from Supabase Storage."""
    supabase = get_custom_client()
    response = supabase.storage.from_(bucket).download(path)
    return response

def upload_audio(bucket: str, path: str, content: bytes) -> str:
    """Uploads an audio file to Supabase Storage."""
    print("Uploading audio to Supabase Storage")
    print("Path: ", path)
    supabase = get_custom_client()
    supabase.storage.from_(bucket).upload(
        path,
        content,
        file_options={
            "content-type": "audio/mpeg", 
            "cache-control": "public, max-age=31536000",
            "upsert": "false"
        }
    )
    return create_signed_url(bucket, path)

def check_audio_exists(bucket: str, content_id: str, language: str) -> bool:
    """Checks if an audio file exists in Supabase Storage."""
    print("Checking audio exists")
    print("Bucket: ", bucket)
    print("Content ID: ", content_id)
    print("Language: ", language)
    
    supabase = get_custom_client()
    files = (
        supabase.storage\
        .from_(bucket)\
        .list(
            content_id,
            {
                "limit": 1,
                "offset": 0,
                "search": language,
            }
        )
    )
    
    print("Files: ", files)
    
    return len(files) > 0, files

def get_audio_data(bucket: str, path: str) -> bytes:
    supabase = get_custom_client()
    return supabase.storage.from_(bucket).download(path)

def get_images_as_url(
        custom_supabase: Client,
        bucket_name: str, 
        user_id: str,
        images: dict,
        url_exp: Optional[int] = 60*15
    ) -> dict:
        
        storage_obj = []
        for img in images:
            storage_obj.append(
                upload_to_storage(
                    custom_supabase=custom_supabase,
                    media_body=img.get("body"),
                    bucket_name=bucket_name,
                    file_name=f"{user_id}/{uuid4()}.{img.get('type').split('/')[1]}",
                    mime_type=img.get("type"),
                    url_exp=url_exp
                )
            )
        
        return {
            "urls": [obj["url"] for obj in storage_obj],
            "paths": [obj["path"] for obj in storage_obj]
        }
        
def upload_chunk(
    chunk: bytes,
    upload_id: str,
    part_number: int,
    supabase: Client,
    mime_type: Optional[str] = None
):
    try:
        session = supabase\
            .table("uploads")\
            .select("*")\
            .eq("id", upload_id)\
            .execute()
    
        if len(session.data) == 0:
            raise Exception("Upload session not found")

        session_data = session.data[0]
        
        session_id = session_data.get("id")
    
        chunk_name = f"{session_id}/part-{part_number}"
    
        supabase.storage\
            .from_('experience')\
            .upload(
                path=chunk_name,
                file=chunk,
                file_options={
                    "content-type": mime_type or 'application/octet-stream',
                    "upsert": "false"
                }
            )
    
        update_session = supabase\
            .table("uploads")\
            .update({
                "received_parts": [*session_data.get("received_parts", []), part_number],
                "status": "uploading"
            })\
            .eq("id", session_id)\
            .execute()
        
        print("Update session:", update_session)
    
        return update_session.data[0]
    except Exception as e:
        raise Exception(e)

async def combine_chunks(upload_id: str, supabase: Client, user_id: str):
    try:
        chunks = supabase.storage.from_('experience').list(upload_id, {
            "limit": 100,
            "offset": 0,
            "sortBy": { "column": 'name', "order": 'asc' },
            "search": 'part-'
        })
        
        combined_file = b''
        
        for chunk in chunks:
            chunk_data = supabase.storage\
                .from_('experience')\
                .download(f"{upload_id}/{chunk.get('name')}")
            
            combined_file += chunk_data
        
        return combined_file
    except Exception as e:
        raise e

def delete_media(
    supabase: Client, 
    media_query_values: list[str], 
    bucket_name: str, 
    query_type: Optional[str] = "url"
):
    try:
        response = supabase\
            .table("media_assets")\
            .select("id,storage_path")\
            .in_(query_type, media_query_values)\
            .execute()
        
        # print("Delete media response:", response)
        
        media_ids = list(map(lambda x: x["id"], response.data))
        storage_paths = list(map(lambda x: x["storage_path"], response.data))
        
        if response.data is None:
            raise Exception("Media not found")
        
        storage_delete = None
        if any(ele is not None and ele != "" and ele != "null" for ele in storage_paths):
          storage_delete = supabase.storage.from_(bucket_name).remove(storage_paths)
        
        # if storage_delete is None or len(storage_delete) == 0:
        #     raise Exception("Media not found")
        
        delete_response = supabase\
            .table("media_assets")\
            .delete()\
            .in_("id", media_ids)\
            .execute()
        
        if delete_response.data is None:
            raise Exception("Media not found")
        
        return {
            "media_assets": delete_response.data,
            "storage_deletes": storage_delete
        }
        
    except Exception as e:
        raise e
    

__all__ = [
    "upload_to_storage", 
    "get_public_url", 
    "download_audio_chunk", 
    "upload_audio", 
    "check_audio_exists",
    "upload_chunk",
    "combine_chunks",
    "download_file_data",
    "async_upload_to_storage",
    "async_upload_to_storage_optimized"
]