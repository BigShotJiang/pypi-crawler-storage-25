# Connectors Module

## Purpose

The `src/connectors/` package hosts all external platform integrations for the Edge8 Lark Automation platform. Each connector is self-contained, exposes typed client interfaces, and focuses on reliability (auth handling, retries, clear errors).

## Folder Structure

```
src/connectors/
├── airtable/              # Airtable API client
├── lark_interactions/     # Lark (Feishu) API client (auth, meetings, docs, contacts)
├── notion/                # Notion workspace integration
├── openrouter/            # OpenRouter LLM client
├── search_engine/         # Search utilities
├── supabase_client/       # Supabase DB/auth/storage client
├── thoughtflow/           # Thoughtflow integration
├── typeform/              # Typeform integration
├── web_scrapper/          # Web scraping utilities
└── webhook/               # Shared webhook helpers
```

## Design Principles

1. **Isolation**: Each connector manages its own auth, schemas, and HTTP client.
2. **Async-first**: Prefer `httpx.AsyncClient` and async methods for I/O.
3. **Typed contracts**: Use Pydantic models or TypedDicts for request/response where practical.
4. **Error clarity**: Raise descriptive exceptions; include platform error codes/messages.
5. **Retries**: Apply limited retries/backoff on transient failures (429/5xx/network).
6. **Security**: Never log secrets; read credentials from environment or injected configs.

## Connector Summaries

### Airtable (`airtable/`)
- Syncs course/lesson/assignment data from Airtable (source of truth).
- Handles pagination and schema mapping to internal models.
- Provides upsert helpers and webhook handling for change events.

### Lark (Feishu) (`lark_interactions/`)
- OAuth/token lifecycle, meetings, transcripts, documents, contacts, messages, calendar, wiki, file.
- Base/table operations for data tables.
- Powers Lark tool-use agent and meeting automation flows.

### Supabase (`supabase_client/`)
- Primary database, storage, auth utilities.
- `authChecker` validates Bearer tokens for API middleware.
- Provides typed helpers for CRUD used by AIO LMS endpoints.

### OpenRouter (`openrouter/`)
- LLM client for multi-model access and streaming.
- Used by AgentSystem for routing, planning, execution, and answering.

### Typeform (`typeform/`)
- Fetch responses and handle webhooks for surveys/assessments feeding LMS flows.

### Notion (`notion/`), Search Engine (`search_engine/`), Web Scraper (`web_scrapper/`), Thoughtflow (`thoughtflow/`)
- Supplemental integrations for content ingestion and knowledge operations.

## Usage Patterns

```python
from src.connectors.lark_interactions.auth import LarkAuth

auth = LarkAuth(app_id, app_secret)
tokens = await auth.exchange_code_for_token(code)
```

```python
from src.connectors.supabase_client import get_supabase_client

supabase = get_supabase_client()
rows = await supabase.table("students").select("*").execute()
```

## Best Practices

- Reuse HTTP clients where possible to benefit from connection pooling.
- Centralize headers/auth creation inside each connector; do not duplicate in callers.
- Validate all inputs before outbound requests; fail fast with actionable errors.
- Respect platform rate limits; implement exponential backoff on 429/503.
- Redact tokens and PII from logs; log request IDs and endpoints for traceability.
- Keep connectors side-effect free beyond the API calls themselves; business logic stays in agents/routers.

## Testing

- Mock external HTTP calls with `respx`/`pytest` fixtures.
- Add regression tests for pagination, error handling, and auth refresh flows.
- Use recorded fixtures for stable contract tests where live API access is unavailable.
