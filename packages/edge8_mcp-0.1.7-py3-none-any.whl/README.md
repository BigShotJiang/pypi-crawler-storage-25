# Source Module (src/)

## Purpose

The `src/` directory contains the core application logic, including AI agent systems, external platform connectors, configuration, and utility functions. This is the business logic layer of the application.

## Folder Structure

```
src/
├── agents/                  # AI agent systems
│   ├── systems/             # Core agent orchestration
│   ├── subagents/           # Specialized sub-agents
│   ├── tools/               # Tool definitions and handlers
│   ├── prompts.py           # Agent system prompts
│   └── shared_types.py      # Legacy type definitions
├── connectors/              # External platform integrations
│   ├── lark_interactions/   # Lark API client
│   ├── airtable/            # Airtable integration
│   ├── supabase_client/     # Supabase client
│   ├── openrouter/          # LLM client
│   ├── typeform/            # Typeform integration
│   ├── notion/              # Notion integration
│   ├── search_engine/       # Search utilities
│   ├── web_scrapper/        # Web scraping
│   └── webhook/             # Webhook utilities
├── config/                  # Configuration files
│   └── lark/                # Lark configuration
├── iframe_ui/               # Built chatbot UI assets
└── utils/                   # Utility functions
```

## Module Overview

### 1. Agents Module

**Location:** `src/agents/`

**Purpose:** Multi-agent AI orchestration system with dynamic chameleon pattern

**Key Components:**
- **AgentSystem**: Main orchestrator (Router → Planner → Executor)
- **Grading Workflow**: AI-powered assignment grading
- **Subagents**: RouterAgent, PlannerAgent, ExecutorAgent, AnsweringAgent
- **Tools**: 30+ specialized tools for Lark, Circle, database operations

**See:** `src/agents/README.md` for detailed documentation

### 2. Connectors Module

**Location:** `src/connectors/`

**Purpose:** External platform API clients and integrations

**Key Integrations:**
- **Lark (Feishu)**: OAuth, meetings, documents, contacts, messaging
- **Circle.so**: Community management, posts, courses, analytics
- **Airtable**: Source of truth for course data
- **Supabase**: Primary database and storage
- **OpenRouter**: Multi-model LLM access
- **Typeform**: Form submissions and surveys

**See:** `src/connectors/README.md` for detailed documentation

### 3. Configuration Module

**Location:** `src/config/`

**Purpose:** Configuration files and settings

**Contents:**
- Lark app configuration
- Platform-specific settings
- Environment-based configurations

### 4. UI Assets Module

**Location:** `src/iframe_ui/`

**Purpose:** Built chatbot UI assets for embedding

**Contents:**
- Compiled React application
- Static assets (CSS, JS, images)
- HTML entry point

### 5. Utilities Module

**Location:** `src/utils/`

**Purpose:** Shared utility functions and helpers

**Common Utilities:**
- Webhook interaction helpers
- Data transformation utilities
- Validation functions
- Logging utilities

## Architecture Patterns

### 1. Agent System Architecture

```
User Input
    ↓
[Router Agent] → Detect intent & select tool group
    ↓
[Planner Agent] → Select tools & generate persona
    ↓
[Executor Agent] → Execute with custom prompt
    ↓
[Update State] → Store results
    ↓
[Loop or Finish] → Continue or generate response
```

**Key Features:**
- Dynamic executor instantiation
- Per-turn state reset
- Streaming output
- Tool-group filtering

### 2. Connector Pattern

All connectors follow a consistent pattern:

```python
class PlatformClient:
    def __init__(self, api_key: str):
        self.api_key = api_key
        self.client = httpx.AsyncClient()
    
    async def operation(self, **kwargs):
        """Perform platform operation"""
        response = await self.client.post(
            url=self.base_url,
            headers=self._get_headers(),
            json=kwargs
        )
        return self._handle_response(response)
    
    def _get_headers(self):
        return {"Authorization": f"Bearer {self.api_key}"}
    
    def _handle_response(self, response):
        if response.status_code != 200:
            raise Exception(f"API error: {response.text}")
        return response.json()
```

### 3. Tool Handler Pattern

```python
from src.agents.tools.shared import BaseToolHandler, ToolExecutionResult

class MyToolHandler(BaseToolHandler):
    async def execute(self, **kwargs) -> ToolExecutionResult:
        """Execute tool with parameters"""
        try:
            result = await self._perform_operation(**kwargs)
            return ToolExecutionResult(
                success=True,
                result=result,
                metadata={"operation": "my_tool"}
            )
        except Exception as e:
            return ToolExecutionResult(
                success=False,
                error=str(e)
            )
```

## Coding Conventions

### Type Safety

Use strict typing throughout:

```python
from typing import List, Optional, Dict, Any
from pydantic import BaseModel

class MyModel(BaseModel):
    field1: str
    field2: Optional[int] = None
    field3: List[str] = []
    
async def my_function(
    param1: str,
    param2: Optional[Dict[str, Any]] = None
) -> MyModel:
    """Function with strict typing"""
    pass
```

### Async/Await

Use async for all I/O operations:

```python
import httpx
from typing import Dict

async def fetch_data(url: str) -> Dict:
    """Fetch data asynchronously"""
    async with httpx.AsyncClient() as client:
        response = await client.get(url)
        return response.json()

async def process_multiple():
    """Process multiple operations concurrently"""
    results = await asyncio.gather(
        fetch_data(url1),
        fetch_data(url2),
        fetch_data(url3)
    )
    return results
```

### Error Handling

Implement comprehensive error handling:

```python
import logging
from typing import Optional

logger = logging.getLogger(__name__)

async def safe_operation() -> Optional[dict]:
    """Operation with error handling"""
    try:
        result = await risky_operation()
        return result
    except ValueError as e:
        logger.warning(f"Validation error: {e}")
        return None
    except httpx.HTTPError as e:
        logger.error(f"HTTP error: {e}")
        raise
    except Exception as e:
        logger.critical(f"Unexpected error: {e}")
        raise
```

### Pydantic Models

Use Pydantic for data validation:

```python
from pydantic import BaseModel, Field, validator
from datetime import datetime
from typing import Optional

class StudentModel(BaseModel):
    id: Optional[str] = None
    email: str = Field(..., description="Student email")
    name: str = Field(..., min_length=1)
    enrolled_at: datetime = Field(default_factory=datetime.now)
    
    @validator('email')
    def email_must_be_valid(cls, v):
        if '@' not in v:
            raise ValueError('Invalid email format')
        return v.lower()
    
    class Config:
        json_encoders = {
            datetime: lambda v: v.isoformat()
        }
```

## Best Practices

### 1. Separation of Concerns

- **Routers**: Handle HTTP requests/responses
- **Connectors**: Interact with external APIs
- **Agents**: Implement business logic
- **Tools**: Execute specific operations
- **Utils**: Provide shared functionality

### 2. Dependency Injection

```python
from typing import Protocol

class DatabaseClient(Protocol):
    async def query(self, sql: str) -> list:
        ...

class MyService:
    def __init__(self, db: DatabaseClient):
        self.db = db
    
    async def get_data(self):
        return await self.db.query("SELECT * FROM table")
```

### 3. Configuration Management

```python
from pydantic import BaseSettings

class Settings(BaseSettings):
    lark_app_id: str
    lark_app_secret: str
    openrouter_api_key: str
    
    class Config:
        env_file = ".env"

settings = Settings()
```

### 4. Logging

```python
import logging

logger = logging.getLogger(__name__)

# In functions
logger.debug("Detailed diagnostic information")
logger.info("General informational message")
logger.warning("Warning message")
logger.error("Error message")
logger.critical("Critical issue")
```

### 5. Testing

```python
import pytest
from unittest.mock import AsyncMock, patch

@pytest.mark.asyncio
async def test_my_function():
    """Test async function"""
    result = await my_async_function()
    assert result is not None

@patch('src.connectors.platform.PlatformClient.operation')
async def test_with_mock(mock_operation):
    """Test with mocked external call"""
    mock_operation.return_value = {"success": True}
    result = await my_function()
    assert result["success"] is True
```

## Performance Optimization

### 1. Caching

```python
from functools import lru_cache
from typing import Dict

@lru_cache(maxsize=128)
def get_config(key: str) -> str:
    """Cache configuration values"""
    return os.getenv(key)

# For async functions
from aiocache import cached

@cached(ttl=300)
async def get_user_data(user_id: str) -> Dict:
    """Cache user data for 5 minutes"""
    return await fetch_user_data(user_id)
```

### 2. Connection Pooling

```python
import httpx

# Create client once, reuse for multiple requests
client = httpx.AsyncClient(
    timeout=30.0,
    limits=httpx.Limits(max_connections=100)
)

async def make_request(url: str):
    response = await client.get(url)
    return response.json()
```

### 3. Batch Operations

```python
async def batch_create_students(students: List[StudentModel]):
    """Create multiple students in one operation"""
    values = [
        (s.email, s.name) 
        for s in students
    ]
    await db.execute_many(
        "INSERT INTO students (email, name) VALUES ($1, $2)",
        values
    )
```

## Security Best Practices

### 1. Input Validation

```python
from pydantic import BaseModel, validator

class UserInput(BaseModel):
    query: str
    
    @validator('query')
    def sanitize_query(cls, v):
        # Remove potentially dangerous characters
        return v.replace(';', '').replace('--', '')
```

### 2. Secret Management

```python
import os
from dotenv import load_dotenv

load_dotenv()

# Never hardcode secrets
API_KEY = os.getenv("API_KEY")
if not API_KEY:
    raise ValueError("API_KEY not set in environment")
```

### 3. Authentication

```python
from fastapi import HTTPException, Header

async def verify_token(authorization: str = Header(...)):
    """Verify bearer token"""
    if not authorization.startswith("Bearer "):
        raise HTTPException(status_code=401, detail="Invalid auth header")
    
    token = authorization.split(" ")[1]
    if not is_valid_token(token):
        raise HTTPException(status_code=401, detail="Invalid token")
    
    return token
```

## Troubleshooting

### Common Issues

**Import Errors:**
- Ensure all dependencies are installed: `pip install -r requirements.txt`
- Check Python version compatibility (3.9+)

**Async Issues:**
- Always use `await` with async functions
- Use `asyncio.run()` for top-level async calls
- Don't mix sync and async code without proper handling

**Type Errors:**
- Enable strict type checking: `mypy src/`
- Use proper type hints
- Avoid using `Any` type

### Debug Mode

```python
import logging

# Enable debug logging
logging.basicConfig(
    level=logging.DEBUG,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
)

# In code
logger = logging.getLogger(__name__)
logger.debug("Debug information")
```

## Testing Strategy

### Unit Tests
- Test individual functions and classes
- Mock external dependencies
- Use `pytest` and `pytest-asyncio`

### Integration Tests
- Test module interactions
- Use test database
- Verify external API integrations

### Example Test Structure

```
tests/
├── agents/
│   ├── test_agent_system.py
│   └── test_tools.py
├── connectors/
│   └── test_lark.py
└── conftest.py
```

## Additional Documentation

- **Agent Systems**: `src/agents/README.md`
- **Agent Architecture**: `src/agents/systems/AGENT_SYSTEM_OVERVIEW.md`
- **Subagents**: `src/agents/subagents/README.md`
- **Tools**: `src/agents/tools/README.md`
- **Connectors**: `src/connectors/README.md`
