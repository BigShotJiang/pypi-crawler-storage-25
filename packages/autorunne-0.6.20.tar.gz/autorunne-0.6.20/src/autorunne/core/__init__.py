# Core helpers for Autorunne
