"""Shared fixtures for asta-agent tests.

Pins the cache to a temp directory so unit tests never touch the real
``~/Library/Caches/asta-agent`` (or its Linux/Windows equivalents).
"""

from __future__ import annotations

import json
import os
from pathlib import Path

import pytest

from asta_agent.a2a import commands as cmds


# Mirror of the published Theorizer card (skills + schemas extension only),
# trimmed to what the CLI actually inspects. Fixture lives in code rather
# than a separate file so test failures land in one diff.
THEORIZER_CARD: dict = {
    "name": "Theorizer",
    "description": "Reads scientific papers and writes theories from them.",
    "version": "0.1.0",
    "url": "",
    "protocolVersion": "0.3.0",
    "preferredTransport": "JSONRPC",
    "defaultInputModes": ["application/json"],
    "defaultOutputModes": ["application/json"],
    "capabilities": {
        "streaming": True,
        "extensions": [
            {
                "uri": "https://allenai.org/asta/schemas/v1",
                "description": "Per-skill JSON Schema URLs.",
                "required": False,
                "params": {
                    "literature-theory-generation": {
                        "$ref": "/skills/literature-theory-generation/input-schema.json",
                    },
                    "find-and-extract": {
                        "$ref": "/skills/find-and-extract/input-schema.json",
                    },
                    "form-theory": {
                        "$ref": "/skills/form-theory/input-schema.json",
                    },
                },
            }
        ],
    },
    "skills": [
        {
            "id": "literature-theory-generation",
            "name": "Literature Theory Generation",
            "description": "Full pipeline: search, extract, theorize.",
            "tags": [],
        },
        {
            "id": "find-and-extract",
            "name": "Find and Extract",
            "description": "Search and extract evidence; stop short of theories.",
            "tags": [],
        },
        {
            "id": "form-theory",
            "name": "Form Theory",
            "description": "Theorize from prior evidence.",
            "tags": [],
        },
    ],
}


THEORIZER_LITGEN_SCHEMA: dict = {
    "type": "object",
    "required": ["theory_query"],
    "additionalProperties": False,
    "properties": {
        "theory_query": {"type": "string", "description": "Research question."},
        "mission_statement": {"type": "string", "default": ""},
        "paper_store": {
            "anyOf": [
                {"$ref": "#/$defs/PaperStore"},
                {"type": "null"},
            ],
            "default": None,
            "description": "Pre-collected paper store.",
        },
        "max_papers_to_retrieve": {
            "type": "integer", "minimum": 1, "default": 10,
            "description": "Max papers to find and extract from.",
        },
        "knowledge_cutoff_year": {"type": "integer", "default": 2050},
        "knowledge_cutoff_month": {
            "type": "integer", "minimum": 1, "maximum": 12, "default": 1,
        },
        "model_str_primary": {"type": "string", "default": "gpt-5.2"},
        "generation_objective": {
            "enum": ["accuracy-focused", "novelty-focused"],
            "default": "accuracy-focused",
        },
        "do_qualified_novelty_evaluation": {
            "type": "boolean", "default": True,
            "description": "Run novelty evaluation after theory generation.",
        },
        "search_additional_papers": {"type": "boolean", "default": True},
        "generation_temperature": {
            "type": "number", "minimum": 0.0, "maximum": 2.0, "default": 1.0,
        },
    },
    "$defs": {
        "PaperStore": {"type": "object", "properties": {"paperstore": {"type": "object"}}},
    },
}


THEORIZER_FIND_SCHEMA: dict = {
    "type": "object",
    "required": ["theory_query"],
    "properties": {
        "theory_query": {"type": "string"},
        "max_papers_to_retrieve": {"type": "integer", "minimum": 1, "default": 10},
    },
}


THEORIZER_FORM_SCHEMA: dict = {
    "type": "object",
    "required": ["paper_store"],
    "properties": {
        "paper_store": {"$ref": "#/$defs/PaperStore"},
        "generation_objective": {
            "enum": ["accuracy-focused", "novelty-focused"],
            "default": "accuracy-focused",
        },
    },
    "$defs": {"PaperStore": {"type": "object"}},
}


SKILL_SCHEMAS: dict[str, dict] = {
    "literature-theory-generation": THEORIZER_LITGEN_SCHEMA,
    "find-and-extract": THEORIZER_FIND_SCHEMA,
    "form-theory": THEORIZER_FORM_SCHEMA,
}


@pytest.fixture
def theorizer_card() -> dict:
    return json.loads(json.dumps(THEORIZER_CARD))  # deep copy


@pytest.fixture
def theorizer_schemas() -> dict[str, dict]:
    return json.loads(json.dumps(SKILL_SCHEMAS))


@pytest.fixture(autouse=True)
def isolated_cache(tmp_path, monkeypatch) -> Path:
    """Redirect the on-disk cache to a per-test temp directory."""
    cache = tmp_path / "asta-agent-cache"
    monkeypatch.setattr(cmds, "_cache_dir", lambda: cache)
    monkeypatch.delenv(cmds.NO_CACHE_ENV, raising=False)
    yield cache


@pytest.fixture(autouse=True)
def clean_argv(monkeypatch):
    """Default to argv that doesn't include --refresh-card."""
    monkeypatch.setattr("sys.argv", ["asta-a2a"])
