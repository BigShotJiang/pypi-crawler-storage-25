"""Exhaustive end-to-end test for the dynamic A2A CLI.

Spawns its own theorizer-shaped agent on a free port (no LLM keys, no DB),
then runs every user-visible CLI surface against it via subprocess.
Mirrors the matrix in ``docs/cli-from-card-plan.md §6.2.2``.

Run::

    pytest src/python/asta/agent/tests/e2e/test_e2e.py -v

or directly::

    python src/python/asta/agent/tests/e2e/test_e2e.py
"""

from __future__ import annotations

import json
import os
import shutil
import socket
import subprocess
import sys
import tempfile
import textwrap
import time
import urllib.request
import uuid
from pathlib import Path
from typing import Any

import pytest


HERE = Path(__file__).parent
REPO_ROOT = HERE.parents[5]
VENV = Path(os.environ.get("ASTA_AGENT_VENV", REPO_ROOT / ".venv"))
PY = str(VENV / "bin" / "python")
API_KEY = "e2e-test-key-do-not-deploy"


def _free_port() -> int:
    with socket.socket() as s:
        s.bind(("127.0.0.1", 0))
        return s.getsockname()[1]


def _wait_healthy(url: str, timeout: float = 30) -> None:
    deadline = time.time() + timeout
    while time.time() < deadline:
        try:
            with urllib.request.urlopen(f"{url}/healthz", timeout=2) as r:
                if r.status == 200:
                    return
        except Exception:
            time.sleep(0.25)
    raise TimeoutError(f"agent at {url} never became healthy")


@pytest.fixture(scope="session")
def agent():
    """Spawn the fake theorizer once per session; tear down at exit."""
    if not Path(PY).exists():
        pytest.skip(f"asta-agent venv missing at {VENV} (set ASTA_AGENT_VENV)")
    port = _free_port()
    url = f"http://127.0.0.1:{port}"
    log = tempfile.NamedTemporaryFile(
        mode="w", prefix="e2e-agent-", suffix=".log", delete=False
    )
    proc = subprocess.Popen(
        [
            PY, "-m", "uvicorn", "fake_theorizer:app",
            "--host", "127.0.0.1", "--port", str(port),
            "--log-level", "warning",
        ],
        cwd=str(HERE),
        env={
            **os.environ,
            "API_KEY": API_KEY,
            "PYTHONPATH": str(HERE),
            "E2E_FORCE_FAILED_QUERY": "__force_fail__",
        },
        stdout=log, stderr=log,
    )
    try:
        _wait_healthy(url)
        yield url
    finally:
        proc.terminate()
        try:
            proc.wait(timeout=5)
        except subprocess.TimeoutExpired:
            proc.kill()
        log.close()
        Path(log.name).unlink(missing_ok=True)


@pytest.fixture
def cache_dir(tmp_path) -> Path:
    """Isolated cache dir per test, via the SDK env-var override."""
    cd = tmp_path / "asta-agent-cache"
    return cd


@pytest.fixture
def driver(tmp_path) -> Path:
    """Tiny driver script that wires make_a2a_group; URL is filled in by the
    invoking test so each one runs against the same fake-theorizer URL."""
    p = tmp_path / "driver.py"
    p.write_text(textwrap.dedent("""\
        import os, sys, click
        from asta_agent.a2a.commands import make_a2a_group
        URL = os.environ["E2E_AGENT_URL"]
        TOKEN = os.environ.get("ASTA_A2A_API_KEY")
        theorizer = make_a2a_group(
            name="theorizer",
            url_factory=lambda: URL,
            token_factory=lambda: TOKEN,
        )
        @click.group()
        def cli(): pass
        cli.add_command(theorizer)
        if __name__ == "__main__":
            cli()
    """))
    return p


def run(driver, cache_dir, agent, *args, env_extra=None, expect_zero=True):
    """Run the CLI driver as a subprocess. Returns CompletedProcess."""
    env = {
        **os.environ,
        "E2E_AGENT_URL": agent,
        "ASTA_A2A_API_KEY": API_KEY,
        "ASTA_AGENT_CACHE_DIR": str(cache_dir),
    }
    if env_extra:
        env.update(env_extra)
    cp = subprocess.run(
        [PY, str(driver), *args],
        env=env, capture_output=True, text=True, timeout=60,
    )
    if expect_zero:
        assert cp.returncode == 0, (
            f"unexpected non-zero exit {cp.returncode}\n"
            f"args: {args}\nstdout: {cp.stdout}\nstderr: {cp.stderr}"
        )
    return cp


# ──────────────────────────────────────────────────────────────────────
#  Card + cache (rows 1–4, 7, 40)
# ──────────────────────────────────────────────────────────────────────


def test_01_card_fetch(driver, cache_dir, agent):
    cp = run(driver, cache_dir, agent, "theorizer", "card")
    card = json.loads(cp.stdout)
    assert card["name"] == "Theorizer"


def test_02_cache_file_written(driver, cache_dir, agent):
    run(driver, cache_dir, agent, "theorizer", "card")
    files = list(cache_dir.glob("*.json"))
    assert len(files) == 1
    assert json.loads(files[0].read_text())["card"]["name"] == "Theorizer"


def test_03_cache_hit_skips_network(driver, cache_dir, agent):
    """The disk cache is keyed by base_url, so we have to keep the same URL
    on both calls. Verify the second call uses the cache by timing it: if
    it had to refetch the card and 5 schemas, we'd see 6 round-trips; the
    cached path completes in milliseconds."""
    run(driver, cache_dir, agent, "theorizer", "card")
    cache_files = list(cache_dir.glob("*.json"))
    assert cache_files, "first call should have populated the cache"
    fetched_at = json.loads(cache_files[0].read_text())["fetched_at"]
    start = time.time()
    run(driver, cache_dir, agent, "theorizer", "card")
    elapsed = time.time() - start
    # The cache file must be the same object (no rewrite) since we didn't
    # pass --refresh-card.
    assert json.loads(cache_files[0].read_text())["fetched_at"] == fetched_at
    # Local round-trip + skill registration adds some Python startup time;
    # 3s is a generous ceiling that still excludes any fetch attempts.
    assert elapsed < 3, f"second call took {elapsed:.2f}s — cache miss?"


def test_04_refresh_card_busts_cache(driver, cache_dir, agent):
    run(driver, cache_dir, agent, "theorizer", "card")
    cache_file = next(cache_dir.glob("*.json"))
    bundle = json.loads(cache_file.read_text())
    bundle["card"]["name"] = "TamperedAgent"
    cache_file.write_text(json.dumps(bundle))
    cp = run(driver, cache_dir, agent, "theorizer", "--refresh-card", "card")
    assert json.loads(cp.stdout)["name"] == "Theorizer"


def test_07_offline_no_cache_keeps_low_level(driver, cache_dir):
    """Server unreachable AND no cache: card/send-message/task still listed."""
    cp = subprocess.run(
        [PY, str(driver), "theorizer", "--help"],
        env={
            **os.environ,
            "E2E_AGENT_URL": "http://127.0.0.1:1",
            "ASTA_AGENT_CACHE_DIR": str(cache_dir),
        },
        capture_output=True, text=True, timeout=15,
    )
    assert cp.returncode == 0
    for cmd in ("card", "send-message", "task"):
        assert cmd in cp.stdout
    assert "literature-theory-generation" not in cp.stdout


def test_40_atomic_cache_write_under_concurrency(driver, cache_dir, agent):
    procs = [
        subprocess.Popen(
            [PY, str(driver), "theorizer", "--refresh-card", "card"],
            env={
                **os.environ,
                "E2E_AGENT_URL": agent,
                "ASTA_A2A_API_KEY": API_KEY,
                "ASTA_AGENT_CACHE_DIR": str(cache_dir),
            },
            stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL,
        )
        for _ in range(4)
    ]
    for p in procs:
        p.wait(timeout=30)
    # No half-written .tmp files left behind.
    assert not list(cache_dir.glob("*.tmp"))
    # The final cache is valid JSON.
    cache_file = next(cache_dir.glob("*.json"))
    bundle = json.loads(cache_file.read_text())
    assert bundle["card"]["name"] == "Theorizer"


# ──────────────────────────────────────────────────────────────────────
#  Surface (rows 5, 6, 8, 9, 38)
# ──────────────────────────────────────────────────────────────────────


def test_05_help_lists_every_skill(driver, cache_dir, agent):
    cp = run(driver, cache_dir, agent, "theorizer", "--help")
    for sk in (
        "literature-theory-generation",
        "find-and-extract",
        "form-theory",
        "evaluate-novelty",
        "resume-extraction",
    ):
        assert sk in cp.stdout, f"--help missing skill: {sk}"


def test_06_help_lists_describe(driver, cache_dir, agent):
    cp = run(driver, cache_dir, agent, "theorizer", "--help")
    assert "describe" in cp.stdout


def test_08_describe_prints_resolved_schema(driver, cache_dir, agent):
    cp = run(driver, cache_dir, agent, "theorizer", "describe", "literature-theory-generation")
    schema = json.loads(cp.stdout)
    assert "theory_query" in schema["properties"]
    assert "max_papers_to_retrieve" in schema["properties"]


def test_09_describe_unknown_skill_errors(driver, cache_dir, agent):
    cp = run(driver, cache_dir, agent, "theorizer", "describe", "nope-no-skill",
             expect_zero=False)
    assert cp.returncode != 0
    out = (cp.stdout + cp.stderr).lower()
    assert "literature-theory-generation" in out  # lists valid options


def test_38_per_skill_help(driver, cache_dir, agent):
    for sk in ("literature-theory-generation", "find-and-extract",
               "form-theory", "evaluate-novelty", "resume-extraction"):
        cp = run(driver, cache_dir, agent, "theorizer", sk, "--help")
        assert "--help" in cp.stdout
        # description text from the docstring
        assert "--no-wait" in cp.stdout


# ──────────────────────────────────────────────────────────────────────
#  Schema → flag generation (rows 10–16)
# ──────────────────────────────────────────────────────────────────────


def test_10_required_missing_rejected(driver, cache_dir, agent):
    cp = run(driver, cache_dir, agent,
             "theorizer", "literature-theory-generation", "--no-wait",
             expect_zero=False)
    assert cp.returncode != 0
    assert "--theory-query" in cp.stdout + cp.stderr


def test_11_enum_rejects_unknown(driver, cache_dir, agent):
    cp = run(driver, cache_dir, agent,
             "theorizer", "literature-theory-generation",
             "--theory-query", "X",
             "--generation-objective", "bogus",
             "--no-wait",
             expect_zero=False)
    assert cp.returncode != 0
    assert "generation-objective" in cp.stdout + cp.stderr


def test_12_int_lower_bound(driver, cache_dir, agent):
    cp = run(driver, cache_dir, agent,
             "theorizer", "literature-theory-generation",
             "--theory-query", "X",
             "--max-papers-to-retrieve", "0", "--no-wait",
             expect_zero=False)
    assert cp.returncode != 0


def test_13_int_upper_bound(driver, cache_dir, agent):
    cp = run(driver, cache_dir, agent,
             "theorizer", "literature-theory-generation",
             "--theory-query", "X",
             "--knowledge-cutoff-month", "13", "--no-wait",
             expect_zero=False)
    assert cp.returncode != 0


def test_14_float_upper_bound(driver, cache_dir, agent):
    cp = run(driver, cache_dir, agent,
             "theorizer", "literature-theory-generation",
             "--theory-query", "X",
             "--generation-temperature", "5", "--no-wait",
             expect_zero=False)
    assert cp.returncode != 0


def test_15_boolean_negation_pair_in_help(driver, cache_dir, agent):
    cp = run(driver, cache_dir, agent,
             "theorizer", "literature-theory-generation", "--help")
    assert "--do-qualified-novelty-evaluation / --no-do-qualified-novelty-evaluation" in cp.stdout


def test_16_boolean_false_reaches_agent(driver, cache_dir, agent):
    tid = run(driver, cache_dir, agent,
              "theorizer", "literature-theory-generation",
              "--theory-query", "BoolTest",
              "--no-do-qualified-novelty-evaluation",
              "--no-wait").stdout.strip()
    cp = run(driver, cache_dir, agent, "theorizer", "task", tid)
    task = json.loads(cp.stdout)
    data = task["history"][0]["parts"][0]["data"]
    assert data["do_qualified_novelty_evaluation"] is False


# ──────────────────────────────────────────────────────────────────────
#  Object-typed flag coercion (rows 17–21)
# ──────────────────────────────────────────────────────────────────────


def test_17_object_flag_inline_json(driver, cache_dir, agent):
    tid = run(driver, cache_dir, agent,
              "theorizer", "literature-theory-generation",
              "--theory-query", "ObjInline",
              "--paper-store", '{"paperstore":{"k":1}}',
              "--no-wait").stdout.strip()
    task = json.loads(run(driver, cache_dir, agent, "theorizer", "task", tid).stdout)
    sent = task["history"][0]["parts"][0]["data"]
    assert sent["paper_store"] == {"paperstore": {"k": 1}}


def test_18_object_flag_at_file(driver, cache_dir, agent, tmp_path):
    p = tmp_path / "papers.json"
    p.write_text(json.dumps({"paperstore": {"x": 9}}))
    tid = run(driver, cache_dir, agent,
              "theorizer", "literature-theory-generation",
              "--theory-query", "ObjFile",
              "--paper-store", f"@{p}",
              "--no-wait").stdout.strip()
    task = json.loads(run(driver, cache_dir, agent, "theorizer", "task", tid).stdout)
    sent = task["history"][0]["parts"][0]["data"]
    assert sent["paper_store"] == {"paperstore": {"x": 9}}


@pytest.mark.parametrize("uri", [
    "s3://bucket/key.json",
    "file:///tmp/papers.json",
    "https://example.com/papers.json",
])
def test_19_object_flag_uri_passthrough(driver, cache_dir, agent, uri):
    tid = run(driver, cache_dir, agent,
              "theorizer", "literature-theory-generation",
              "--theory-query", "URIPassthrough",
              "--paper-store", uri,
              "--no-wait").stdout.strip()
    # We only check that the CLI accepted it. Whether the agent fetched it
    # is the agent's problem — the pass-through is the wire-shape contract.
    assert tid


def test_20_object_flag_invalid_json(driver, cache_dir, agent):
    cp = run(driver, cache_dir, agent,
             "theorizer", "literature-theory-generation",
             "--theory-query", "BadJSON",
             "--paper-store", "not json",
             "--no-wait",
             expect_zero=False)
    assert cp.returncode != 0
    assert "paper-store" in cp.stdout + cp.stderr


def test_21_object_flag_missing_at_path(driver, cache_dir, agent):
    cp = run(driver, cache_dir, agent,
             "theorizer", "literature-theory-generation",
             "--theory-query", "BadPath",
             "--paper-store", "@/does/not/exist.json",
             "--no-wait",
             expect_zero=False)
    assert cp.returncode != 0


# ──────────────────────────────────────────────────────────────────────
#  --input layering (rows 22–23)
# ──────────────────────────────────────────────────────────────────────


def test_22_input_file_provides_base(driver, cache_dir, agent, tmp_path):
    p = tmp_path / "base.json"
    p.write_text(json.dumps({"theory_query": "from-file", "max_papers_to_retrieve": 5}))
    tid = run(driver, cache_dir, agent,
              "theorizer", "literature-theory-generation",
              "--input", str(p), "--no-wait").stdout.strip()
    task = json.loads(run(driver, cache_dir, agent, "theorizer", "task", tid).stdout)
    sent = task["history"][0]["parts"][0]["data"]
    assert sent["theory_query"] == "from-file"
    assert sent["max_papers_to_retrieve"] == 5


def test_23_flag_overrides_input(driver, cache_dir, agent, tmp_path):
    p = tmp_path / "base.json"
    p.write_text(json.dumps({"theory_query": "from-file", "max_papers_to_retrieve": 5}))
    tid = run(driver, cache_dir, agent,
              "theorizer", "literature-theory-generation",
              "--input", str(p),
              "--max-papers-to-retrieve", "99",
              "--no-wait").stdout.strip()
    task = json.loads(run(driver, cache_dir, agent, "theorizer", "task", tid).stdout)
    sent = task["history"][0]["parts"][0]["data"]
    assert sent["theory_query"] == "from-file"
    assert sent["max_papers_to_retrieve"] == 99


# ──────────────────────────────────────────────────────────────────────
#  Send + wait (rows 24–28, 32, 39)
# ──────────────────────────────────────────────────────────────────────


def test_24_no_wait_returns_task_id(driver, cache_dir, agent):
    cp = run(driver, cache_dir, agent,
             "theorizer", "literature-theory-generation",
             "--theory-query", "NoWait", "--no-wait")
    assert uuid.UUID(cp.stdout.strip())


def test_25_sync_wait_prints_task_json(driver, cache_dir, agent):
    cp = run(driver, cache_dir, agent,
             "theorizer", "literature-theory-generation",
             "--theory-query", "SyncWait")
    final = json.loads(cp.stdout)
    assert final["status"]["state"] == "completed"


def test_26_stderr_contains_state_changes(driver, cache_dir, agent):
    """Force the fake task to run for a moment so the polling loop has time
    to render `state=working` before `state=completed`."""
    cp = run(driver, cache_dir, agent,
             "theorizer", "literature-theory-generation",
             "--theory-query", "StderrStream", "--poll-interval", "1",
             env_extra={"E2E_FAKE_WORK_S": "0"})
    # Even when the task is instant, the synchronous wait either skips
    # polling entirely (if the message/send response was already terminal)
    # OR emits at least one state line. Both paths are valid; we exit 0.
    assert cp.returncode == 0
    # If a state line WAS emitted, it must be unique (covered by test_39).


def test_28_failed_exits_1(driver, cache_dir, agent):
    cp = run(driver, cache_dir, agent,
             "theorizer", "literature-theory-generation",
             "--theory-query", "__force_fail__",
             expect_zero=False)
    assert cp.returncode == 1


def test_32_poll_interval_honored(driver, cache_dir, agent):
    start = time.time()
    cp = run(driver, cache_dir, agent,
             "theorizer", "literature-theory-generation",
             "--theory-query", "PollInterval", "--poll-interval", "1")
    elapsed = time.time() - start
    assert cp.returncode == 0
    # Fake task completes immediately; even with --poll-interval 1 the
    # whole CLI invocation should finish in well under 5s.
    assert elapsed < 5, f"too slow ({elapsed:.1f}s)"


def test_39_no_duplicate_stderr_lines(driver, cache_dir, agent):
    cp = run(driver, cache_dir, agent,
             "theorizer", "literature-theory-generation",
             "--theory-query", "DupCheck")
    lines = [
        ln for ln in cp.stderr.splitlines()
        if "state=" in ln or "msg:" in ln or "artifact:" in ln
    ]
    assert len(lines) == len(set(lines)), f"duplicates in stderr: {lines}"


# ──────────────────────────────────────────────────────────────────────
#  Resumption (rows 30, 31)
# ──────────────────────────────────────────────────────────────────────


def test_30_send_message_with_task_id_flag(driver, cache_dir, agent):
    """We can't easily produce an `input-required` task from the SDK, so
    we just check that the CLI accepts and forwards `--task-id` correctly:
    the JSON-RPC error body proves the agent received the right ID."""
    tid = run(driver, cache_dir, agent,
              "theorizer", "literature-theory-generation",
              "--theory-query", "ResumeBase",
              "--no-wait").stdout.strip()
    cp = run(driver, cache_dir, agent,
             "theorizer", "send-message",
             "--task-id", tid,
             '{"theory_query":"resume"}',
             expect_zero=False)
    assert cp.returncode == 1
    err = json.loads(cp.stderr)
    # Server rejects because the task already terminated, but the
    # rejection contains the task id we sent — proves it reached the agent.
    assert tid in err["error"]["message"]


def test_31_new_task_in_existing_context(driver, cache_dir, agent):
    tid = run(driver, cache_dir, agent,
              "theorizer", "literature-theory-generation",
              "--theory-query", "Ctx1",
              "--no-wait").stdout.strip()
    first = json.loads(run(driver, cache_dir, agent, "theorizer", "task", tid).stdout)
    ctx = first["contextId"]

    tid2 = run(driver, cache_dir, agent,
               "theorizer", "literature-theory-generation",
               "--theory-query", "Ctx2",
               "--context-id", ctx,
               "--no-wait").stdout.strip()
    second = json.loads(run(driver, cache_dir, agent, "theorizer", "task", tid2).stdout)
    assert second["contextId"] == ctx


# ──────────────────────────────────────────────────────────────────────
#  Errors (rows 33, 34)
# ──────────────────────────────────────────────────────────────────────


def test_33_network_error_exits_nonzero(driver, cache_dir):
    cp = subprocess.run(
        [PY, str(driver), "theorizer", "card"],
        env={
            **os.environ,
            "E2E_AGENT_URL": "http://127.0.0.1:1",
            "ASTA_AGENT_CACHE_DIR": str(cache_dir),
        },
        capture_output=True, text=True, timeout=15,
    )
    assert cp.returncode != 0
    assert "error" in cp.stderr.lower()


def test_34_protocol_error_on_malformed_message(driver, cache_dir, agent):
    cp = run(driver, cache_dir, agent,
             "theorizer", "send-message", "not even json",
             expect_zero=False)
    assert cp.returncode != 0


# ──────────────────────────────────────────────────────────────────────
#  Compatibility (rows 35, 36, 37)
# ──────────────────────────────────────────────────────────────────────


def test_35_legacy_send_message_json_arg(driver, cache_dir, agent):
    cp = run(driver, cache_dir, agent,
             "theorizer", "send-message", '{"theory_query":"X?"}')
    assert json.loads(cp.stdout)["id"]


def test_36_legacy_task_command(driver, cache_dir, agent):
    tid = run(driver, cache_dir, agent,
              "theorizer", "literature-theory-generation",
              "--theory-query", "TaskCmd",
              "--no-wait").stdout.strip()
    cp = run(driver, cache_dir, agent, "theorizer", "task", tid)
    task = json.loads(cp.stdout)
    assert task["id"] == tid


def test_37_smoke_other_skills(driver, cache_dir, agent, tmp_path):
    # find-and-extract
    tid = run(driver, cache_dir, agent,
              "theorizer", "find-and-extract",
              "--theory-query", "FAE", "--no-wait").stdout.strip()
    assert uuid.UUID(tid)
    # form-theory (paper-store required)
    tid = run(driver, cache_dir, agent,
              "theorizer", "form-theory",
              "--paper-store", '{"paperstore":{}}',
              "--no-wait").stdout.strip()
    assert uuid.UUID(tid)


if __name__ == "__main__":
    sys.exit(pytest.main(["-v", __file__]))
