"""A theorizer-shaped A2A agent for E2E tests.

Mirrors the *shape* of the real Theorizer card (5 skills, the same flag
names and types) but runs entirely in-process — no LLM keys, no DB. Skill
bodies are deterministic and instant so the E2E harness exercises every
CLI surface in <30s without touching a model provider.

Behavior knobs (env vars, set by run_e2e.sh):

* ``E2E_FORCE_FAILED_QUERY``  — when ``theory_query`` equals this string,
  the task ends in state ``failed`` (lets us cover exit-code paths).

The SDK doesn't yet expose an ``input-required`` primitive on the task
body, so that exit path is exercised in unit tests only.

Run with::

    API_KEY=... uvicorn fake_theorizer:app --host 127.0.0.1 --port 9099
"""

from __future__ import annotations

import os
from typing import Annotated, Any, Literal

from pydantic import BaseModel, Field

from asta_agent import Asta, AstaContext, NullContext


asta = Asta(
    name="Theorizer",
    description="In-process E2E stand-in for the real Theorizer.",
    version="0.1.0",
)


class PaperStore(BaseModel):
    paperstore: dict[str, Any] = {}


class ExtractionSchemaInput(BaseModel):
    extraction_schemas: dict[str, Any] = {}


@asta.task("Literature Theory Generation")
def literature_theory_generation(
    theory_query: Annotated[str, Field(description="Research question.")],
    mission_statement: Annotated[str, Field(description="Optional focus.")] = "",
    paper_store: PaperStore | None = None,
    extraction_schema: ExtractionSchemaInput | None = None,
    max_papers_to_retrieve: Annotated[int, Field(ge=1)] = 10,
    knowledge_cutoff_year: int = 2050,
    knowledge_cutoff_month: Annotated[int, Field(ge=1, le=12)] = 1,
    model_str_primary: str = "gpt-5.2",
    model_str_extraction: str = "gpt-5-mini",
    generation_objective: Literal["accuracy-focused", "novelty-focused"] = "accuracy-focused",
    max_data_tokens: Annotated[int, Field(ge=1)] = 100000,
    do_qualified_novelty_evaluation: bool = True,
    search_additional_papers: bool = True,
    generation_temperature: Annotated[float, Field(ge=0.0, le=2.0)] = 1.0,
    ctx: AstaContext = NullContext(),
):
    """The full pipeline: search, extract, theorize. (e2e stand-in)"""
    if theory_query == os.environ.get("E2E_FORCE_FAILED_QUERY"):
        raise RuntimeError("forced failure for e2e test")
    # Optional artificial work so the polling loop can observe the
    # working→completed transition. Set ``E2E_FAKE_WORK_S=1`` to give the
    # CLI a state-change to render to stderr.
    delay = float(os.environ.get("E2E_FAKE_WORK_S", "0") or 0)
    if delay > 0:
        import time as _t
        _t.sleep(delay)
    ctx.set_metadata("theory_query", theory_query)
    ctx.set_metadata("max_papers_to_retrieve", max_papers_to_retrieve)
    # Publish two artifacts so the artifacts-skill handoff has something to
    # chew on during E2E.
    ctx.publish_data_artifact(
        artifact_id="theories",
        name="generated-theories",
        subtype="theory-laws",
        description="Synthetic theories produced by the E2E fake theorizer.",
        data={
            "theories": [
                {"name": f"Theory of {theory_query[:32]}",
                 "laws": [
                     {"id": "L1",
                      "statement": "X causes Y when Z is large.",
                      "evidence": ["paper-1", "paper-3"]},
                     {"id": "L2",
                      "statement": "Increasing A increases B.",
                      "evidence": ["paper-2"]},
                 ]},
                {"name": "Alternative explanation",
                 "laws": [
                     {"id": "L3",
                      "statement": "P moderates the X to Y effect.",
                      "evidence": ["paper-4"]},
                 ]},
            ],
        },
    )
    ctx.publish_data_artifact(
        artifact_id="extraction",
        name="extraction-results",
        subtype="extraction",
        description="Synthetic per-paper extractions.",
        data={
            "papers": [
                {"id": f"paper-{i}",
                 "title": f"E2E synthetic paper {i} about {theory_query[:24]}"}
                for i in range(1, 5)
            ],
        },
    )


@asta.task("Find and Extract")
def find_and_extract(
    theory_query: Annotated[str, Field(description="Research question.")],
    max_papers_to_retrieve: Annotated[int, Field(ge=1)] = 10,
    ctx: AstaContext = NullContext(),
):
    """Search and extract evidence; stop short of theories."""
    ctx.set_metadata("theory_query", theory_query)


@asta.task("Form Theory")
def form_theory(
    paper_store: PaperStore,
    generation_objective: Literal["accuracy-focused", "novelty-focused"] = "accuracy-focused",
    ctx: AstaContext = NullContext(),
):
    """Theorize from prior evidence."""
    ctx.set_metadata("paper_store_size", len(paper_store.paperstore))


@asta.task("Evaluate Novelty")
def evaluate_novelty(
    theory_ids: Annotated[list[str], Field(description="Theory IDs to evaluate.")],
    ctx: AstaContext = NullContext(),
):
    """Per-statement novelty assessment."""
    ctx.set_metadata("evaluated", len(theory_ids))


@asta.task("Resume Extraction")
def resume_extraction(
    previous_run_id: Annotated[str, Field(description="Prior run ID.")],
    paper_keys: list[str] = [],
    ctx: AstaContext = NullContext(),
):
    """Add more papers to a prior run."""
    ctx.set_metadata("resumed_from", previous_run_id)


app = asta.app
