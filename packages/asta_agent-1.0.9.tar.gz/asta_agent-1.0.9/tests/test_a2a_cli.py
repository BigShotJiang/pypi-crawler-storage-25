"""Unit tests for the dynamic Click CLI generated from agent cards.

Targets ``asta_agent.a2a.commands`` end-to-end: cache, schema → flag
generation, object-flag coercion, ``--input`` layering, ``describe``,
``--no-wait``, synchronous wait + change-only stderr stream, exit codes,
and graceful degradation.
"""

from __future__ import annotations

import json
import time
import uuid

import click
import pytest
from click.testing import CliRunner

from asta_agent.a2a import client as client_mod
from asta_agent.a2a import commands as cmds
from asta_agent.a2a.client import A2AError


# ──────────────────────────────────────────────────────────────────────
#  Fakes
# ──────────────────────────────────────────────────────────────────────


class FakeA2AClient:
    """Replaces A2AClient. Tests hand it scripted responses."""

    def __init__(self, base_url: str = "http://t", api_key=None):
        self.base_url = base_url
        self.api_key = api_key
        self.send_calls: list[tuple[str, str | None, str | None]] = []
        self.get_task_calls: list[str] = []
        self.card_calls = 0
        self.url_calls: list[str] = []
        # Plug these from tests:
        self.card_payload: dict = {}
        self.schema_payloads: dict[str, dict] = {}
        self.send_response: dict = {}
        self.task_responses: list[dict] = []
        self.send_raises: Exception | None = None
        self.task_raises: Exception | None = None
        self.card_raises: Exception | None = None

    def get_agent_card(self):
        self.card_calls += 1
        if self.card_raises:
            raise self.card_raises
        return self.card_payload

    def get_url(self, url: str):
        self.url_calls.append(url)
        for skill_id, schema in self.schema_payloads.items():
            if skill_id in url:
                return schema
        raise A2AError(404, f"no fake schema for {url}")

    def send_message(self, payload, *, task_id=None, context_id=None):
        self.send_calls.append((payload, task_id, context_id))
        if self.send_raises:
            raise self.send_raises
        return self.send_response

    def get_task(self, task_id):
        self.get_task_calls.append(task_id)
        if self.task_raises:
            raise self.task_raises
        if not self.task_responses:
            raise RuntimeError("FakeA2AClient.task_responses exhausted")
        if len(self.task_responses) == 1:
            return self.task_responses[0]
        return self.task_responses.pop(0)


@pytest.fixture
def fake_client(monkeypatch, theorizer_card, theorizer_schemas):
    """A FakeA2AClient pre-loaded with the Theorizer card + schemas, and
    monkey-patched so any ``A2AClient(url, api_key=...)`` call returns it."""
    fake = FakeA2AClient()
    fake.card_payload = theorizer_card
    fake.schema_payloads = theorizer_schemas

    def _factory(url, api_key=None):
        fake.base_url = url
        fake.api_key = api_key
        return fake

    monkeypatch.setattr(cmds, "A2AClient", _factory)
    monkeypatch.setattr(client_mod, "A2AClient", _factory)
    return fake


def _make_group(fake, **kwargs):
    return cmds.make_a2a_group(
        name="theorizer",
        url_factory=lambda: "http://t",
        token_factory=lambda: "tok",
        help="Theorizer test group.",
        **kwargs,
    )


def _success_task(state="completed", artifacts=None, message_text=None, task_id="t1"):
    task: dict = {
        "id": task_id,
        "contextId": "c1",
        "kind": "task",
        "status": {"state": state},
        "artifacts": artifacts or [],
    }
    if message_text:
        task["status"]["message"] = {
            "kind": "message", "role": "agent", "messageId": "m1",
            "parts": [{"kind": "text", "text": message_text}],
        }
    return task


# ──────────────────────────────────────────────────────────────────────
#  Cache + card fetch
# ──────────────────────────────────────────────────────────────────────


def test_card_fetched_once_then_cached(fake_client, isolated_cache):
    # First make_a2a_group call: fetches.
    _make_group(fake_client)
    assert fake_client.card_calls == 1
    assert isolated_cache.exists()

    # Second invocation: reads cache, no re-fetch.
    fake_client.card_calls = 0
    _make_group(fake_client)
    assert fake_client.card_calls == 0


def test_refresh_card_flag_busts_cache(fake_client, monkeypatch, isolated_cache):
    _make_group(fake_client)
    assert fake_client.card_calls == 1

    monkeypatch.setattr("sys.argv", ["asta", "theorizer", "--refresh-card", "card"])
    fake_client.card_calls = 0
    _make_group(fake_client)
    assert fake_client.card_calls == 1


def test_refresh_card_does_not_cross_talk_to_siblings(fake_client, monkeypatch):
    """`--refresh-card` should only refresh the targeted agent's cache,
    not every agent group built in the same process."""
    _make_group(fake_client)
    fake_client.card_calls = 0
    # Caller targets `someother-agent` with --refresh-card. Our group
    # ("theorizer") must NOT refetch.
    monkeypatch.setattr("sys.argv", ["asta", "someother-agent", "--refresh-card", "card"])
    _make_group(fake_client)
    assert fake_client.card_calls == 0


def test_no_cache_env_var_busts_cache(fake_client, monkeypatch):
    _make_group(fake_client)
    fake_client.card_calls = 0
    monkeypatch.setenv(cmds.NO_CACHE_ENV, "1")
    _make_group(fake_client)
    assert fake_client.card_calls == 1


def test_24h_ttl_expiry_refetches(fake_client, monkeypatch, isolated_cache):
    _make_group(fake_client)
    cache_path = next(isolated_cache.iterdir())
    bundle = json.loads(cache_path.read_text())
    bundle["fetched_at"] = time.time() - cmds.CACHE_TTL_SECONDS - 1
    cache_path.write_text(json.dumps(bundle))

    fake_client.card_calls = 0
    _make_group(fake_client)
    assert fake_client.card_calls == 1


def test_offline_with_no_cache_keeps_low_level_subcommands(monkeypatch):
    def factory(url, api_key=None):
        raise OSError("offline")

    monkeypatch.setattr(cmds, "A2AClient", factory)
    group = cmds.make_a2a_group(
        "theorizer", url_factory=lambda: "http://t", token_factory=lambda: None
    )
    names = set(group.commands)
    assert {"card", "send-message", "task"} <= names
    # Skill subcommands omitted — only the low-level three remain.
    assert "literature-theory-generation" not in names


def test_offline_refresh_surfaces_error(monkeypatch, capsys):
    def factory(url, api_key=None):
        raise OSError("offline")

    monkeypatch.setattr(cmds, "A2AClient", factory)
    monkeypatch.setattr("sys.argv", ["asta", "theorizer", "--refresh-card"])
    cmds.make_a2a_group(
        "theorizer", url_factory=lambda: "http://t", token_factory=lambda: None
    )
    err = capsys.readouterr().err
    assert "--refresh-card failed" in err


def test_atomic_cache_write(fake_client, isolated_cache):
    _make_group(fake_client)
    cache_path = next(isolated_cache.iterdir())
    # No leftover .tmp file should remain after the rename.
    assert not list(isolated_cache.glob("*.tmp"))
    assert cache_path.suffix == ".json"


def test_cache_key_is_sha1_of_base_url(fake_client, isolated_cache):
    _make_group(fake_client)
    import hashlib
    expected = hashlib.sha1(b"http://t").hexdigest() + ".json"
    assert (isolated_cache / expected).exists()


# ──────────────────────────────────────────────────────────────────────
#  Schema → flag generation
# ──────────────────────────────────────────────────────────────────────


def test_string_flag_required(fake_client):
    runner = CliRunner()
    result = runner.invoke(_make_group(fake_client),
                           ["literature-theory-generation"])
    assert result.exit_code != 0
    assert "--theory-query" in result.output
    assert "Missing required" in result.output


def test_integer_with_min_max_range(fake_client):
    runner = CliRunner()
    result = runner.invoke(
        _make_group(fake_client),
        ["literature-theory-generation",
         "--theory-query", "X?",
         "--max-papers-to-retrieve", "0"],
    )
    assert result.exit_code != 0
    assert "Invalid value for '--max-papers-to-retrieve'" in result.output


def test_integer_upper_bound(fake_client):
    runner = CliRunner()
    result = runner.invoke(
        _make_group(fake_client),
        ["literature-theory-generation",
         "--theory-query", "X?",
         "--knowledge-cutoff-month", "13"],
    )
    assert result.exit_code != 0
    assert "Invalid value for '--knowledge-cutoff-month'" in result.output


def test_number_with_bounds(fake_client):
    runner = CliRunner()
    result = runner.invoke(
        _make_group(fake_client),
        ["literature-theory-generation",
         "--theory-query", "X?",
         "--generation-temperature", "5"],
    )
    assert result.exit_code != 0
    assert "Invalid value for '--generation-temperature'" in result.output


def test_boolean_default_true_renders_negation_pair(fake_client):
    runner = CliRunner()
    help_out = runner.invoke(
        _make_group(fake_client),
        ["literature-theory-generation", "--help"],
    ).output
    assert "--do-qualified-novelty-evaluation" in help_out
    assert "--no-do-qualified-novelty-evaluation" in help_out


def test_boolean_negation_passes_false(fake_client):
    fake_client.send_response = _success_task()
    runner = CliRunner()
    result = runner.invoke(
        _make_group(fake_client),
        ["literature-theory-generation",
         "--theory-query", "X?",
         "--no-do-qualified-novelty-evaluation",
         "--no-wait"],
    )
    assert result.exit_code == 0
    sent = json.loads(fake_client.send_calls[0][0])
    assert sent["do_qualified_novelty_evaluation"] is False


def test_enum_uses_choice(fake_client):
    runner = CliRunner()
    result = runner.invoke(
        _make_group(fake_client),
        ["literature-theory-generation",
         "--theory-query", "X?",
         "--generation-objective", "bogus"],
    )
    assert result.exit_code != 0
    assert "Invalid value for '--generation-objective'" in result.output


def test_snake_case_property_to_kebab_flag(fake_client):
    help_out = CliRunner().invoke(
        _make_group(fake_client),
        ["literature-theory-generation", "--help"],
    ).output
    assert "--max-papers-to-retrieve" in help_out
    assert "--max_papers_to_retrieve" not in help_out


def test_help_text_reflects_description(fake_client):
    help_out = CliRunner().invoke(
        _make_group(fake_client),
        ["literature-theory-generation", "--help"],
    ).output
    assert "Research question" in help_out


def test_optional_nullable_via_anyof(fake_client):
    # paper_store is anyOf [PaperStore, null] → optional, accepts JSON/file/URI.
    fake_client.send_response = _success_task()
    runner = CliRunner()
    result = runner.invoke(
        _make_group(fake_client),
        ["literature-theory-generation",
         "--theory-query", "X?",
         "--no-wait"],
    )
    assert result.exit_code == 0
    sent = json.loads(fake_client.send_calls[0][0])
    assert "paper_store" not in sent  # not provided -> not in payload


# ──────────────────────────────────────────────────────────────────────
#  Object-field coercion
# ──────────────────────────────────────────────────────────────────────


def test_object_flag_inline_json(fake_client):
    fake_client.send_response = _success_task()
    runner = CliRunner()
    result = runner.invoke(
        _make_group(fake_client),
        ["literature-theory-generation",
         "--theory-query", "X?",
         "--paper-store", '{"paperstore":{"abc":1}}',
         "--no-wait"],
    )
    assert result.exit_code == 0, result.output
    sent = json.loads(fake_client.send_calls[0][0])
    assert sent["paper_store"] == {"paperstore": {"abc": 1}}


def test_object_flag_file_at_prefix(fake_client, tmp_path):
    f = tmp_path / "papers.json"
    f.write_text(json.dumps({"paperstore": {"x": 9}}))
    fake_client.send_response = _success_task()
    runner = CliRunner()
    result = runner.invoke(
        _make_group(fake_client),
        ["literature-theory-generation",
         "--theory-query", "X?",
         "--paper-store", f"@{f}",
         "--no-wait"],
    )
    assert result.exit_code == 0, result.output
    sent = json.loads(fake_client.send_calls[0][0])
    assert sent["paper_store"] == {"paperstore": {"x": 9}}


@pytest.mark.parametrize("uri", [
    "s3://bucket/key.json",
    "file:///tmp/papers.json",
    "https://example.com/papers.json",
    "http://example.com/papers.json",
])
def test_object_flag_uri_passthrough(fake_client, uri):
    fake_client.send_response = _success_task()
    runner = CliRunner()
    result = runner.invoke(
        _make_group(fake_client),
        ["literature-theory-generation",
         "--theory-query", "X?",
         "--paper-store", uri,
         "--no-wait"],
    )
    assert result.exit_code == 0, result.output
    sent = json.loads(fake_client.send_calls[0][0])
    assert sent["paper_store"] == uri


def test_object_flag_invalid_json_errors_with_field_name(fake_client):
    runner = CliRunner()
    result = runner.invoke(
        _make_group(fake_client),
        ["literature-theory-generation",
         "--theory-query", "X?",
         "--paper-store", "not json",
         "--no-wait"],
    )
    assert result.exit_code != 0
    assert "--paper-store" in result.output


def test_object_flag_missing_at_path_errors(fake_client):
    runner = CliRunner()
    result = runner.invoke(
        _make_group(fake_client),
        ["literature-theory-generation",
         "--theory-query", "X?",
         "--paper-store", "@/does/not/exist.json",
         "--no-wait"],
    )
    assert result.exit_code != 0
    assert "--paper-store" in result.output


# ──────────────────────────────────────────────────────────────────────
#  --input layering
# ──────────────────────────────────────────────────────────────────────


def test_input_file_provides_base_payload(fake_client, tmp_path):
    base = tmp_path / "base.json"
    base.write_text(json.dumps({
        "theory_query": "from-file",
        "max_papers_to_retrieve": 3,
    }))
    fake_client.send_response = _success_task()
    result = CliRunner().invoke(
        _make_group(fake_client),
        ["literature-theory-generation", "--input", str(base), "--no-wait"],
    )
    assert result.exit_code == 0, result.output
    sent = json.loads(fake_client.send_calls[0][0])
    assert sent["theory_query"] == "from-file"
    assert sent["max_papers_to_retrieve"] == 3


def test_per_field_flags_override_input_file(fake_client, tmp_path):
    base = tmp_path / "base.json"
    base.write_text(json.dumps({
        "theory_query": "from-file",
        "max_papers_to_retrieve": 3,
    }))
    fake_client.send_response = _success_task()
    result = CliRunner().invoke(
        _make_group(fake_client),
        ["literature-theory-generation",
         "--input", str(base),
         "--max-papers-to-retrieve", "99",
         "--no-wait"],
    )
    assert result.exit_code == 0, result.output
    sent = json.loads(fake_client.send_calls[0][0])
    assert sent["theory_query"] == "from-file"
    assert sent["max_papers_to_retrieve"] == 99


def test_input_file_must_be_object(fake_client, tmp_path):
    base = tmp_path / "base.json"
    base.write_text(json.dumps([1, 2, 3]))
    result = CliRunner().invoke(
        _make_group(fake_client),
        ["literature-theory-generation", "--input", str(base), "--no-wait"],
    )
    assert result.exit_code != 0


# ──────────────────────────────────────────────────────────────────────
#  describe
# ──────────────────────────────────────────────────────────────────────


def test_describe_prints_resolved_schema(fake_client, theorizer_schemas):
    result = CliRunner().invoke(
        _make_group(fake_client), ["describe", "literature-theory-generation"]
    )
    assert result.exit_code == 0
    out = json.loads(result.output)
    assert out == theorizer_schemas["literature-theory-generation"]


def test_describe_unknown_skill_errors(fake_client):
    result = CliRunner().invoke(_make_group(fake_client), ["describe", "nope"])
    assert result.exit_code != 0
    assert "literature-theory-generation" in result.output  # lists valid


# ──────────────────────────────────────────────────────────────────────
#  send + wait
# ──────────────────────────────────────────────────────────────────────


def test_no_wait_prints_task_id_one_line(fake_client):
    fake_client.send_response = _success_task(state="submitted", task_id="abc-123")
    result = CliRunner().invoke(
        _make_group(fake_client),
        ["literature-theory-generation", "--theory-query", "X?", "--no-wait"],
    )
    assert result.exit_code == 0
    assert result.output.strip() == "abc-123"


def test_sync_wait_polls_until_completed(fake_client, monkeypatch):
    fake_client.send_response = _success_task(state="submitted", task_id="t1")
    fake_client.task_responses = [
        _success_task(state="working", message_text="step 1"),
        _success_task(state="completed", message_text="done"),
    ]
    monkeypatch.setattr(cmds.time, "sleep", lambda *_: None)
    result = CliRunner().invoke(
        _make_group(fake_client),
        ["literature-theory-generation", "--theory-query", "X?"],
    )
    assert result.exit_code == 0
    out = json.loads(result.stdout)
    assert out["status"]["state"] == "completed"


def test_sync_wait_streams_state_changes(fake_client, monkeypatch):
    fake_client.send_response = _success_task(state="submitted", task_id="t1")
    fake_client.task_responses = [
        _success_task(state="working"),
        _success_task(state="completed"),
    ]
    monkeypatch.setattr(cmds.time, "sleep", lambda *_: None)
    result = CliRunner().invoke(
        _make_group(fake_client),
        ["literature-theory-generation", "--theory-query", "X?"],
    )
    err = result.stderr
    assert "state=working" in err
    assert "state=completed" in err


def test_sync_wait_streams_status_message(fake_client, monkeypatch):
    fake_client.send_response = _success_task(state="working", task_id="t1")
    fake_client.task_responses = [
        _success_task(state="working", message_text="extracting"),
        _success_task(state="completed"),
    ]
    monkeypatch.setattr(cmds.time, "sleep", lambda *_: None)
    result = CliRunner().invoke(
        _make_group(fake_client),
        ["literature-theory-generation", "--theory-query", "X?"],
    )
    assert "msg: extracting" in result.stderr


def test_sync_wait_streams_artifact_publications(fake_client, monkeypatch):
    fake_client.send_response = _success_task(state="working", task_id="t1")
    fake_client.task_responses = [
        _success_task(state="working", artifacts=[
            {"artifactId": "a1-aaaaaaaa", "name": "extraction"},
        ]),
        _success_task(state="completed", artifacts=[
            {"artifactId": "a1-aaaaaaaa", "name": "extraction"},
            {"artifactId": "b2-bbbbbbbb", "name": "theories"},
        ]),
    ]
    monkeypatch.setattr(cmds.time, "sleep", lambda *_: None)
    result = CliRunner().invoke(
        _make_group(fake_client),
        ["literature-theory-generation", "--theory-query", "X?"],
    )
    err = result.stderr
    assert "artifact: extraction" in err
    assert "artifact: theories" in err
    # Each artifact reported exactly once.
    assert err.count("artifact: extraction") == 1


def test_sync_wait_does_not_repeat_unchanged_lines(fake_client, monkeypatch):
    fake_client.send_response = _success_task(state="working", task_id="t1")
    fake_client.task_responses = [
        _success_task(state="working", message_text="same"),
        _success_task(state="working", message_text="same"),
        _success_task(state="completed", message_text="same"),
    ]
    monkeypatch.setattr(cmds.time, "sleep", lambda *_: None)
    result = CliRunner().invoke(
        _make_group(fake_client),
        ["literature-theory-generation", "--theory-query", "X?"],
    )
    err = result.stderr
    assert err.count("msg: same") == 1
    assert err.count("state=working") == 1


def test_sync_wait_failed_exits_1(fake_client, monkeypatch):
    fake_client.send_response = _success_task(state="working", task_id="t1")
    fake_client.task_responses = [_success_task(state="failed")]
    monkeypatch.setattr(cmds.time, "sleep", lambda *_: None)
    result = CliRunner().invoke(
        _make_group(fake_client),
        ["literature-theory-generation", "--theory-query", "X?"],
    )
    assert result.exit_code == 1


@pytest.mark.parametrize("state", ["canceled", "rejected"])
def test_sync_wait_other_failures_exit_1(fake_client, monkeypatch, state):
    fake_client.send_response = _success_task(state="working", task_id="t1")
    fake_client.task_responses = [_success_task(state=state)]
    monkeypatch.setattr(cmds.time, "sleep", lambda *_: None)
    result = CliRunner().invoke(
        _make_group(fake_client),
        ["literature-theory-generation", "--theory-query", "X?"],
    )
    assert result.exit_code == 1


def test_input_required_exit_0_with_hint(fake_client, monkeypatch):
    fake_client.send_response = _success_task(state="working", task_id="t1")
    fake_client.task_responses = [_success_task(state="input-required")]
    monkeypatch.setattr(cmds.time, "sleep", lambda *_: None)
    result = CliRunner().invoke(
        _make_group(fake_client),
        ["literature-theory-generation", "--theory-query", "X?"],
    )
    assert result.exit_code == 0
    assert "Continue with" in result.stderr
    assert "send-message" in result.stderr
    assert "--task-id" in result.stderr


def test_terminal_on_submit_skips_polling(fake_client):
    fake_client.send_response = _success_task(state="completed")
    result = CliRunner().invoke(
        _make_group(fake_client),
        ["literature-theory-generation", "--theory-query", "X?"],
    )
    assert result.exit_code == 0
    assert fake_client.get_task_calls == []


def test_poll_interval_override(monkeypatch, fake_client):
    fake_client.send_response = _success_task(state="working", task_id="t1")
    fake_client.task_responses = [_success_task(state="completed")]
    sleeps: list[float] = []
    monkeypatch.setattr(cmds.time, "sleep", lambda s: sleeps.append(s))
    CliRunner().invoke(
        _make_group(fake_client),
        ["literature-theory-generation", "--theory-query", "X?",
         "--poll-interval", "7"],
    )
    # Single working→completed transition: at most one sleep, and if there
    # is one, it must use the override interval.
    if sleeps:
        assert all(s == 7 for s in sleeps)


def test_poll_cadence_default_starts_with_5s():
    # Inspect the cadence list directly — covered via _POLL_CADENCE.
    assert cmds._POLL_CADENCE[:6] == [5, 5, 5, 5, 5, 5]
    assert cmds._POLL_CADENCE[6:26] == [15] * 20


# ──────────────────────────────────────────────────────────────────────
#  Resumption
# ──────────────────────────────────────────────────────────────────────


def test_skill_command_accepts_task_and_context_id(fake_client):
    fake_client.send_response = _success_task(state="completed")
    CliRunner().invoke(
        _make_group(fake_client),
        ["literature-theory-generation", "--theory-query", "X?",
         "--task-id", "t-prev", "--context-id", "c-prev",
         "--no-wait"],
    )
    payload, task_id, context_id = fake_client.send_calls[0]
    assert task_id == "t-prev"
    assert context_id == "c-prev"


# ──────────────────────────────────────────────────────────────────────
#  Compatibility
# ──────────────────────────────────────────────────────────────────────


def test_legacy_send_message_accepts_message_argument(fake_client):
    fake_client.send_response = _success_task()
    result = CliRunner().invoke(
        _make_group(fake_client),
        ["send-message", '{"theory_query": "X?"}'],
    )
    assert result.exit_code == 0
    payload, _, _ = fake_client.send_calls[0]
    assert json.loads(payload) == {"theory_query": "X?"}


def test_card_subcommand_unchanged(fake_client):
    result = CliRunner().invoke(_make_group(fake_client), ["card"])
    assert result.exit_code == 0
    assert "Theorizer" in result.output


def test_task_subcommand_unchanged(fake_client):
    fake_client.task_responses = [_success_task(state="completed")]
    result = CliRunner().invoke(_make_group(fake_client), ["task", "abc"])
    assert result.exit_code == 0
    assert "completed" in result.output


def test_card_without_schemas_extension_falls_back_to_positional(fake_client):
    fake_client.card_payload = {
        "name": "Bare", "description": "", "version": "0",
        "url": "", "protocolVersion": "0.3.0",
        "preferredTransport": "JSONRPC",
        "defaultInputModes": ["application/json"],
        "defaultOutputModes": ["application/json"],
        "capabilities": {"streaming": True},
        "skills": [{"id": "do-thing", "name": "Do Thing", "description": "", "tags": []}],
    }
    fake_client.schema_payloads = {}
    fake_client.send_response = _success_task()
    group = _make_group(fake_client)
    assert "do-thing" in group.commands
    # The fallback command takes a positional payload, no per-field flags.
    result = CliRunner().invoke(group, ["do-thing", '{"x":1}', "--no-wait"])
    assert result.exit_code == 0, result.output
    payload, _, _ = fake_client.send_calls[0]
    assert json.loads(payload) == {"x": 1}


# ──────────────────────────────────────────────────────────────────────
#  Errors
# ──────────────────────────────────────────────────────────────────────


def test_protocol_error_exits_1(fake_client):
    fake_client.send_raises = A2AError(-32601, "Method not found")
    result = CliRunner().invoke(
        _make_group(fake_client),
        ["literature-theory-generation", "--theory-query", "X?",
         "--no-wait"],
    )
    assert result.exit_code == 1
    err = json.loads(result.stderr)
    assert err["error"]["code"] == -32601


def test_network_error_exits_1(fake_client):
    fake_client.send_raises = OSError("connection refused")
    result = CliRunner().invoke(
        _make_group(fake_client),
        ["literature-theory-generation", "--theory-query", "X?",
         "--no-wait"],
    )
    assert result.exit_code == 1
    err = json.loads(result.stderr)
    assert "connection refused" in err["error"]["message"]


# ──────────────────────────────────────────────────────────────────────
#  Helpers (white-box)
# ──────────────────────────────────────────────────────────────────────


def test_resolve_schema_ref_relative_path():
    out = cmds._resolve_schema_ref(
        "https://gw/api/theorizer", "/skills/foo/input-schema.json"
    )
    assert out == "https://gw/skills/foo/input-schema.json"


def test_resolve_schema_ref_absolute():
    out = cmds._resolve_schema_ref(
        "https://gw/api/theorizer", "https://other/schema.json"
    )
    assert out == "https://other/schema.json"


def test_kebab():
    assert cmds._kebab("max_papers_to_retrieve") == "max-papers-to-retrieve"


def test_is_object_field_for_ref():
    assert cmds._is_object_field({"$ref": "#/$defs/X"}) is True


def test_is_object_field_for_anyof_with_ref():
    assert cmds._is_object_field({"anyOf": [{"$ref": "#/$defs/X"}, {"type": "null"}]}) is True


def test_is_object_field_for_primitive():
    assert cmds._is_object_field({"type": "string"}) is False


def test_status_message_text_concatenates_text_parts():
    task = {"status": {"message": {"parts": [
        {"kind": "text", "text": "a"}, {"kind": "text", "text": "b"},
    ]}}}
    assert cmds._status_message_text(task) == "a b"


def test_short_help_first_sentence():
    desc = (
        "For each statement in a set of theories, check whether the retrieved "
        "literature already says it. Returns a per-statement assessment marking "
        "the claim as already established."
    )
    out = cmds._short_help(desc)
    assert out == "For each statement in a set of theories, check whether the retrieved literature already says it.".replace(
        "For each statement in a set of theories, check whether the retrieved literature already says it.",
        out,
    ) or out.endswith("…") or out.endswith(".")
    # Always under the limit.
    assert len(out) <= cmds.SHORT_HELP_LIMIT + 1  # +1 for the ellipsis


def test_short_help_handles_empty():
    assert cmds._short_help("") == ""


def test_short_help_truncates_word_boundary():
    desc = "x" * 200
    out = cmds._short_help(desc)
    assert len(out) <= cmds.SHORT_HELP_LIMIT
    assert out.endswith("…")


def test_short_help_prefers_paragraph_break():
    desc = "Tight one-liner.\n\nLong second paragraph that should be ignored entirely."
    assert cmds._short_help(desc) == "Tight one-liner."


def test_skill_subcommand_short_help_in_group_listing(fake_client):
    runner = CliRunner()
    out = runner.invoke(_make_group(fake_client), ["--help"]).output
    # Old behavior: full description trails off with "..." mid-sentence.
    # New: short_help fits a clean one-liner per command.
    for line in out.splitlines():
        if "literature-theory-generation" in line:
            assert "..." not in line, f"truncated mid-sentence: {line!r}"


def test_artifact_summaries():
    task = {"artifacts": [
        {"artifactId": "x", "name": "n"},
        {"artifactId": "y", "name": "m"},
    ]}
    assert cmds._artifact_summaries(task) == [("x", "n"), ("y", "m")]
