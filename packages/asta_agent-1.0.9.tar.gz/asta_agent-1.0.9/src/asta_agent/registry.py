"""Task registration and agent card generation."""

from __future__ import annotations

import inspect
import logging
import typing
from dataclasses import dataclass, field
from typing import Any, Callable

from a2a.types import AgentCapabilities, AgentCard, AgentExtension, AgentSkill

from asta_agent.context import AstaContext

logger = logging.getLogger(__name__)

_MISSING = object()

_CONTEXT_TYPES: set[type | str] = {AstaContext, "AstaContext"}


def _resolved_hints(fn: Callable) -> dict[str, Any]:
    """Resolve ``fn``'s annotations against its own globals/locals.

    When the caller's module uses ``from __future__ import annotations``,
    annotations on ``fn`` are stored as strings and ``inspect.signature``
    returns those strings. ``typing.get_type_hints`` resolves them in the
    function's globals so callers' type aliases (e.g. ``Query =
    Annotated[str, Field(description=...)]``) come back as real types.
    ``include_extras=True`` keeps ``Annotated[...]`` metadata, which is
    where Pydantic ``Field`` lives.
    """
    try:
        return typing.get_type_hints(fn, include_extras=True)
    except Exception:
        logger.warning(
            "asta_agent: failed to resolve type hints for %s; "
            "string annotations will be passed through to TypeAdapter",
            getattr(fn, "__qualname__", fn),
            exc_info=True,
        )
        return {}


@dataclass
class _Param:
    name: str
    required: bool
    default: Any = _MISSING
    annotation: Any = None


@dataclass
class TaskDef:
    """A registered task definition."""
    name: str
    fn: Callable
    params: list[_Param] = field(default_factory=list)
    context_param: str | None = None

    @property
    def skill_id(self) -> str:
        return self.name.lower().replace(" ", "-")

    def input_schema(self) -> dict:
        """JSON Schema for the task's input parameters.

        Uses pydantic's TypeAdapter when available for rich schema generation
        (supports Annotated[..., Field(description=...)], Pydantic models, etc.).
        Falls back to basic type mapping otherwise; the fallback is logged
        so silent regressions to the stub schema are visible.
        """
        try:
            return self._pydantic_schema()
        except Exception:
            logger.warning(
                "asta_agent: pydantic schema generation failed for %r; "
                "falling back to basic type-map schema",
                self.skill_id,
                exc_info=True,
            )
            return self._basic_schema()

    def _pydantic_schema(self) -> dict:
        """Generate schema via pydantic TypeAdapter (same approach as FastMCP)."""
        from pydantic import TypeAdapter

        # Build a function with only the public params (no AstaContext)
        # by creating a TypeAdapter from the function signature
        fn = self.fn
        sig = inspect.signature(fn)

        # Resolve PEP 563 string annotations against fn's own globals so
        # caller-defined type aliases (Annotated[..., Field(...)] etc.)
        # come back as live types, not unresolvable forward references.
        hints = _resolved_hints(fn)

        # Filter out context params, swap each param's annotation for the
        # resolved type so TypeAdapter sees real types (not strings).
        filtered_params = []
        for name, p in sig.parameters.items():
            if name == self.context_param or name in ("self", "cls"):
                continue
            if name in hints:
                p = p.replace(annotation=hints[name])
            filtered_params.append(p)

        new_sig = sig.replace(parameters=filtered_params)

        def _stub(**kwargs: Any) -> None: ...
        _stub.__signature__ = new_sig  # type: ignore[attr-defined]
        _stub.__annotations__ = {
            p.name: p.annotation
            for p in filtered_params
            if p.annotation is not inspect.Parameter.empty
        }

        ta = TypeAdapter(_stub)
        schema = ta.json_schema()

        schema.pop("title", None)
        if "properties" in schema:
            for prop in schema["properties"].values():
                prop.pop("title", None)
        return schema

    def _basic_schema(self) -> dict:
        """Fallback: generate schema from type annotations without pydantic."""
        _TYPE_MAP: dict[type | str | None, str] = {
            str: "string", "str": "string",
            int: "integer", "int": "integer",
            float: "number", "float": "number",
            bool: "boolean", "bool": "boolean",
            dict: "object", "dict": "object",
            list: "array", "list": "array",
        }
        properties: dict[str, Any] = {}
        required: list[str] = []
        for p in self.params:
            prop: dict[str, Any] = {"type": _TYPE_MAP.get(p.annotation, "string")}
            if not p.required and p.default is not _MISSING:
                prop["default"] = p.default
            properties[p.name] = prop
            if p.required:
                required.append(p.name)
        schema: dict[str, Any] = {"type": "object", "properties": properties}
        if required:
            schema["required"] = required
        return schema


def extract_params(fn: Callable) -> tuple[list[_Param], str | None]:
    """Extract parameter info from a function signature.

    Returns (params, context_param_name). AstaContext params are excluded
    from params so they never appear in the public JSON schema.
    """
    sig = inspect.signature(fn)
    params: list[_Param] = []
    context_param: str | None = None
    for name, p in sig.parameters.items():
        if name in ("self", "cls"):
            continue
        annotation = p.annotation if p.annotation is not inspect.Parameter.empty else None
        if annotation in _CONTEXT_TYPES:
            context_param = name
            continue
        required = p.default is inspect.Parameter.empty
        default = _MISSING if required else p.default
        params.append(_Param(name=name, required=required, default=default, annotation=annotation))
    return params, context_param


SCHEMAS_EXTENSION_URI = "https://allenai.org/asta/schemas/v1"

INPUT_SCHEMA_PATH = "/skills/{skill_id}/input-schema.json"


_SCHEMAS_EXTENSION_DESCRIPTION = (
    "Per-skill JSON Schema URLs, keyed by skill_id. Each value is a JSON "
    "Reference ($ref) to a schema document hosted by this agent. Fetch the "
    "referenced URL to validate task inputs before calling message/send. "
    "Any input typed as a Pydantic model also accepts a string URI in place "
    "of an inline dict — file://, s3://, or https:// — which the agent "
    "fetches and validates against the published schema."
)


def _strip_pydantic_titles(node: Any) -> Any:
    """Remove auto-generated ``title`` keys from a JSON Schema in place.

    Pydantic emits a ``title`` for every property derived from the field
    name (e.g. ``"title": "User Email"``), which adds bytes without
    information beyond the property name itself.
    """
    if isinstance(node, dict):
        node.pop("title", None)
        for v in node.values():
            _strip_pydantic_titles(v)
    elif isinstance(node, list):
        for v in node:
            _strip_pydantic_titles(v)
    return node


def _compact_nullable(node: Any) -> Any:
    """Rewrite Pydantic's verbose ``anyOf: [{type: X}, {type: null}]`` shape
    to JSON Schema's shorter ``type: [X, null]`` form. Operates in place.
    Only compacts when every ``anyOf`` member is a bare ``{type: ...}``
    dict (no ``enum``, ``$ref``, ``format``, etc.) — those cases need to
    keep ``anyOf`` because the alternatives carry constraints.
    """
    if isinstance(node, dict):
        members = node.get("anyOf")
        if (
            isinstance(members, list)
            and len(members) >= 2
            and all(
                isinstance(m, dict) and set(m.keys()) == {"type"} and isinstance(m["type"], str)
                for m in members
            )
        ):
            node["type"] = [m["type"] for m in members]
            del node["anyOf"]
        for v in node.values():
            _compact_nullable(v)
    elif isinstance(node, list):
        for v in node:
            _compact_nullable(v)
    return node


def task_input_schema(task: TaskDef) -> dict:
    """Compact, deliverable JSON Schema for a task's input — what
    :data:`INPUT_SCHEMA_PATH` serves at runtime."""
    return _compact_nullable(_strip_pydantic_titles(task.input_schema()))


def build_agent_card(
    name: str,
    description: str,
    version: str,
    url: str,
    tasks: list[TaskDef],
) -> AgentCard:
    """Generate an A2A AgentCard from registered tasks.

    The SDK publishes one extension at :data:`SCHEMAS_EXTENSION_URI` whose
    ``params`` is a ``{skill_id: {"$ref": <url>}}`` map. The referenced URLs
    are mounted by :func:`asta_agent.server.build_app` and serve each task's
    full input schema (Pydantic-typed inputs emit their nested shape under
    ``$defs`` automatically).
    """
    base = url.rstrip("/")
    skills = []
    schema_refs: dict[str, dict[str, str]] = {}
    for td in tasks:
        schema_refs[td.skill_id] = {
            "$ref": base + INPUT_SCHEMA_PATH.format(skill_id=td.skill_id),
        }
        skills.append(AgentSkill(
            id=td.skill_id,
            name=td.name,
            description=inspect.getdoc(td.fn) or "",
            tags=[],
        ))
    extension = AgentExtension(
        uri=SCHEMAS_EXTENSION_URI,
        description=_SCHEMAS_EXTENSION_DESCRIPTION,
        required=False,
        params=schema_refs,
    )
    return AgentCard(
        name=name,
        description=description,
        version=version,
        url=url,
        capabilities=AgentCapabilities(streaming=True, extensions=[extension]),
        default_input_modes=["application/json"],
        default_output_modes=["application/json"],
        skills=skills,
    )
