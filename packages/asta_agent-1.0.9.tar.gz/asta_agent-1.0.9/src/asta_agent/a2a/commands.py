"""A2A CLI commands.

Exposes a ``a2a`` Click group (``card``, ``send-message``, ``task``).
Host CLIs register this group inside their own command tree; a standalone
``asta-a2a`` console_script is also provided.

``make_a2a_group`` creates a named Click group with the same three
subcommands but with the agent URL baked in — useful for host commands
that always talk to the same backend. The factory also fetches the agent
card and per-skill input schemas at import time and emits one typed
Click subcommand per skill, plus a ``describe`` subcommand for
inspecting a skill's resolved schema.

Examples (for a group registered as ``my-agent``)::

    my-agent card                            # full A2A spec
    my-agent describe <skill-id>             # resolved input schema
    my-agent <skill-id> --field-a X --field-b 20
    my-agent send-message '{...}'            # raw escape hatch
    my-agent --refresh-card <subcommand>     # bust cache, refetch
"""

from __future__ import annotations

import hashlib
import json
import os
import re
import sys
import tempfile
import time
import urllib.parse
from collections.abc import Callable
from pathlib import Path
from typing import Any

import click
from a2a.types import AgentCard, Task

from asta_agent.a2a.client import A2AClient, A2AError

# ──────────────────────────────────────────────────────────────────────────
#  Config
# ──────────────────────────────────────────────────────────────────────────

CACHE_TTL_SECONDS = 24 * 60 * 60
SHORT_HELP_LIMIT = 72
SCHEMAS_EXTENSION_URI = "https://allenai.org/asta/schemas/v1"
NO_CACHE_ENV = "ASTA_AGENT_NO_CACHE"
CACHE_DIR_ENV = "ASTA_AGENT_CACHE_DIR"

# Polling cadence for synchronous wait: 5s × 6, 15s × 20, then 60s plateau.
_POLL_CADENCE = [5] * 6 + [15] * 20

_TERMINAL_STATES = {"completed", "failed", "canceled", "rejected", "input-required"}
_FAIL_STATES = {"failed", "canceled", "rejected"}

_URI_SCHEME_RE = re.compile(r"^(s3|file|https?)://", re.IGNORECASE)


# ──────────────────────────────────────────────────────────────────────────
#  Auth helper (unchanged surface)
# ──────────────────────────────────────────────────────────────────────────


def _get_api_key(api_key: str | None) -> str | None:
    """Resolve the bearer token in priority order.

    1. ``--api-key`` flag
    2. ``ASTA_A2A_API_KEY`` / ``API_KEY`` env vars
    3. ``asta auth`` token (lazy import; only present in asta-plugins envs)
    """
    if api_key:
        return api_key
    if env := (os.environ.get("ASTA_A2A_API_KEY") or os.environ.get("API_KEY")):
        return env
    try:
        from asta.utils.auth_helper import get_access_token
    except ImportError:
        return None
    try:
        return get_access_token()
    except Exception as e:
        raise click.UsageError(
            f"No API key provided and `asta auth` lookup failed: {e}\n"
            "Pass --api-key, set ASTA_A2A_API_KEY, or run `asta auth login`."
        ) from e


# ──────────────────────────────────────────────────────────────────────────
#  Generic standalone group (--url + --api-key on every subcommand)
# ──────────────────────────────────────────────────────────────────────────


@click.group()
def a2a():
    """A2A (Agent-to-Agent) protocol client commands."""
    pass


@a2a.command()
@click.option("--url", required=True, help="Base URL of the A2A agent")
@click.option(
    "--api-key",
    default=None,
    help="Bearer token (or set ASTA_A2A_API_KEY / API_KEY, or run `asta auth login`)",
)
def card(url: str, api_key: str | None):
    """Fetch an agent's Agent Card."""
    try:
        client = A2AClient(url, api_key=_get_api_key(api_key))
        result = client.get_agent_card()
        agent_card = AgentCard.model_validate(result)
        click.echo(agent_card.model_dump_json(by_alias=True, indent=2, exclude_none=True))
    except A2AError as e:
        _emit_error_json(e)
        sys.exit(1)
    except Exception as e:
        _emit_error_json(e)
        sys.exit(1)


@a2a.command("send-message")
@click.option("--url", required=True, help="Base URL of the A2A agent")
@click.option(
    "--api-key",
    default=None,
    help="Bearer token (or set ASTA_A2A_API_KEY / API_KEY, or run `asta auth login`)",
)
@click.option(
    "--task-id",
    default=None,
    help="Existing task ID to continue (use when a task is in `input-required`).",
)
@click.option(
    "--context-id",
    default=None,
    help="Existing context ID to start a new task within an existing session.",
)
@click.option(
    "--file",
    "-f",
    multiple=True,
    type=(str, click.Path(exists=True)),
    help="Merge a JSON file into the message: --file key path.json",
)
@click.argument("message")
def send_message(
    url: str,
    api_key: str | None,
    task_id: str | None,
    context_id: str | None,
    file: tuple[tuple[str, str], ...],
    message: str,
):
    """Send a message to an A2A agent.

    MESSAGE is JSON or plain text. Use --file to merge large JSON files
    into the message without inlining them.
    """
    try:
        message = _maybe_merge_files_into_message(message, file)
        client = A2AClient(url, api_key=_get_api_key(api_key))
        result = client.send_message(message, task_id=task_id, context_id=context_id)
        click.echo(json.dumps(result, indent=2))
    except A2AError as e:
        _emit_error_json(e)
        sys.exit(1)
    except Exception as e:
        _emit_error_json(e)
        sys.exit(1)


@a2a.command()
@click.option("--url", required=True, help="Base URL of the A2A agent")
@click.option(
    "--api-key",
    default=None,
    help="Bearer token (or set ASTA_A2A_API_KEY / API_KEY, or run `asta auth login`)",
)
@click.argument("task_id")
def task(url: str, api_key: str | None, task_id: str):
    """Poll a task's current status."""
    try:
        client = A2AClient(url, api_key=_get_api_key(api_key))
        result = client.get_task(task_id)
        parsed = Task.model_validate(result)
        click.echo(parsed.model_dump_json(by_alias=True, indent=2, exclude_none=True))
    except A2AError as e:
        _emit_error_json(e)
        sys.exit(1)
    except Exception as e:
        _emit_error_json(e)
        sys.exit(1)


# ──────────────────────────────────────────────────────────────────────────
#  Cache (platformdirs on the slow path, stdlib fallbacks)
# ──────────────────────────────────────────────────────────────────────────


def _cache_dir() -> Path:
    """Cache root: ``$ASTA_AGENT_CACHE_DIR`` if set, else platformdirs, else
    a sane stdlib default.

    macOS  → ``~/Library/Caches/asta-agent``
    Linux  → ``$XDG_CACHE_HOME/asta-agent`` (defaults to ``~/.cache/...``)
    Win32  → ``%LOCALAPPDATA%\\asta-agent\\Cache``
    """
    override = os.environ.get(CACHE_DIR_ENV)
    if override:
        return Path(override)
    try:
        from platformdirs import user_cache_dir
        return Path(user_cache_dir("asta-agent"))
    except ImportError:
        if sys.platform == "darwin":
            return Path.home() / "Library" / "Caches" / "asta-agent"
        if sys.platform.startswith("win"):
            base = os.environ.get("LOCALAPPDATA") or str(Path.home() / "AppData" / "Local")
            return Path(base) / "asta-agent" / "Cache"
        base = os.environ.get("XDG_CACHE_HOME") or str(Path.home() / ".cache")
        return Path(base) / "asta-agent"


def _cache_path(base_url: str) -> Path:
    digest = hashlib.sha1(base_url.encode("utf-8")).hexdigest()
    return _cache_dir() / f"{digest}.json"


def _read_cache(base_url: str) -> dict | None:
    """Return cached bundle if present and not expired, else None."""
    if os.environ.get(NO_CACHE_ENV) == "1":
        return None
    path = _cache_path(base_url)
    if not path.exists():
        return None
    try:
        bundle = json.loads(path.read_text())
    except (OSError, json.JSONDecodeError):
        return None
    fetched_at = bundle.get("fetched_at", 0)
    if time.time() - fetched_at > CACHE_TTL_SECONDS:
        return None
    return bundle


def _write_cache(base_url: str, bundle: dict) -> None:
    """Atomically write a cache bundle. Best-effort: failures are silent."""
    path = _cache_path(base_url)
    try:
        path.parent.mkdir(parents=True, exist_ok=True)
        with tempfile.NamedTemporaryFile(
            "w", dir=str(path.parent), prefix=path.name, suffix=".tmp", delete=False
        ) as tf:
            tf.write(json.dumps(bundle))
            tmp_path = tf.name
        os.replace(tmp_path, path)
    except OSError:
        pass


def _invalidate_cache(base_url: str) -> None:
    try:
        _cache_path(base_url).unlink()
    except FileNotFoundError:
        pass
    except OSError:
        pass


# ──────────────────────────────────────────────────────────────────────────
#  Card + schema fetch
# ──────────────────────────────────────────────────────────────────────────


def _resolve_schema_ref(base_url: str, ref: str) -> str:
    """Resolve a $ref URL against the agent's base URL.

    The agent server publishes refs as either absolute URLs or
    server-relative paths (``/skills/foo/input-schema.json``). Relative
    paths are resolved against ``base_url``; absolute URLs are returned
    unchanged.
    """
    if not ref:
        raise ValueError("Empty $ref")
    parsed = urllib.parse.urlparse(ref)
    if parsed.scheme:
        return ref
    base_parsed = urllib.parse.urlparse(base_url.rstrip("/") + "/")
    if ref.startswith("/"):
        return urllib.parse.urlunparse(
            (base_parsed.scheme, base_parsed.netloc, ref, "", "", "")
        )
    return urllib.parse.urljoin(base_parsed.geturl(), ref)


def _extract_schema_refs(card_dict: dict) -> dict[str, str]:
    """Return ``{skill_id: ref_url_or_path}`` from the asta schemas extension.

    Returns an empty dict if the card doesn't carry the extension.
    """
    capabilities = card_dict.get("capabilities") or {}
    extensions = capabilities.get("extensions") or []
    for ext in extensions:
        if ext.get("uri") == SCHEMAS_EXTENSION_URI:
            params = ext.get("params") or {}
            return {
                skill_id: ref["$ref"]
                for skill_id, ref in params.items()
                if isinstance(ref, dict) and "$ref" in ref
            }
    return {}


def _load_card_with_schemas(
    client: A2AClient,
    base_url: str,
    *,
    refresh: bool = False,
) -> dict:
    """Return ``{card, schemas, fetched_at, base_url}``.

    Reads the disk cache first unless ``refresh=True`` (or
    ``ASTA_AGENT_NO_CACHE=1``). On a miss, fetches the card and every
    advertised input-schema, stitches them into one bundle, writes the
    cache, and returns. Any HTTP failure during schema fetch is caught
    so a partial bundle is still useful.
    """
    if refresh:
        _invalidate_cache(base_url)
    cached = _read_cache(base_url)
    if cached is not None:
        return cached

    card = client.get_agent_card()
    schemas: dict[str, dict] = {}
    for skill_id, ref in _extract_schema_refs(card).items():
        url = _resolve_schema_ref(base_url, ref)
        try:
            schemas[skill_id] = client.get_url(url)
        except A2AError:
            # Best-effort: a missing schema means that skill degrades to the
            # bare positional-JSON form, but the rest of the CLI still works.
            continue

    bundle = {
        "fetched_at": time.time(),
        "base_url": base_url,
        "card": card,
        "schemas": schemas,
    }
    _write_cache(base_url, bundle)
    return bundle


# ──────────────────────────────────────────────────────────────────────────
#  Schema → Click flag generation
# ──────────────────────────────────────────────────────────────────────────


def _kebab(name: str) -> str:
    return name.replace("_", "-")


def _short_help(description: str, limit: int = SHORT_HELP_LIMIT) -> str:
    """Compact one-liner for the group's command listing.

    Click otherwise truncates the full multi-paragraph docstring at
    terminal width and the result reads like ``Some long opening clause
    that runs on and on and on…`` mid-sentence. Take the first sentence;
    if still too long, hard-cut on a word boundary.
    """
    if not description:
        return ""
    head = description.strip().split("\n\n", 1)[0].replace("\n", " ").strip()
    # Prefer to cut at the first sentence boundary.
    for stop in (". ", "; ", " — "):
        idx = head.find(stop)
        if 0 < idx <= limit:
            return head[:idx].rstrip(",") + "."
    if len(head) <= limit:
        return head
    cut = head[: limit - 1].rsplit(" ", 1)[0]
    return cut + "…"


def _types_in(schema: dict) -> list[str]:
    """Normalize ``type``/``anyOf``/``oneOf`` into a flat ``list[str]``.

    Returns the JSON-Schema type names present, dropping ``"null"``. An
    object with ``$ref`` and no ``type`` returns ``["object"]``.
    """
    if "type" in schema:
        t = schema["type"]
        if isinstance(t, list):
            return [x for x in t if x != "null"]
        return [t] if t != "null" else []
    for key in ("anyOf", "oneOf"):
        members = schema.get(key) or []
        out: list[str] = []
        for m in members:
            if not isinstance(m, dict):
                continue
            if m.get("type") == "null":
                continue
            if "$ref" in m or m.get("type") in ("object", "array"):
                out.append("object")
            elif "type" in m:
                if isinstance(m["type"], list):
                    out.extend(x for x in m["type"] if x != "null")
                else:
                    out.append(m["type"])
        if out:
            return out
    if "$ref" in schema:
        return ["object"]
    if "enum" in schema:
        # Pure enum without a type — sniff from the first value.
        sample = schema["enum"][0]
        if isinstance(sample, bool):
            return ["boolean"]
        if isinstance(sample, int):
            return ["integer"]
        if isinstance(sample, float):
            return ["number"]
        return ["string"]
    return []


def _is_object_field(schema: dict) -> bool:
    """True iff this property accepts JSON-object/array values (so the CLI
    must do inline-JSON / @file / URI coercion)."""
    types = _types_in(schema)
    return any(t in ("object", "array") for t in types) or "$ref" in schema or any(
        "$ref" in m
        for m in (schema.get("anyOf") or []) + (schema.get("oneOf") or [])
        if isinstance(m, dict)
    )


def _is_nullable(schema: dict) -> bool:
    if isinstance(schema.get("type"), list) and "null" in schema["type"]:
        return True
    for key in ("anyOf", "oneOf"):
        for m in schema.get(key, []) or []:
            if isinstance(m, dict) and m.get("type") == "null":
                return True
    return False


def _enum_values(schema: dict) -> list[str] | None:
    if "enum" in schema:
        return [str(v) for v in schema["enum"]]
    for key in ("anyOf", "oneOf"):
        for m in schema.get(key, []) or []:
            if isinstance(m, dict) and "enum" in m:
                return [str(v) for v in m["enum"]]
    return None


def _click_type_for(schema: dict) -> click.ParamType | None:
    """Pick a Click type for a primitive property, or None if the field is
    object-typed (caller will use STRING + runtime coercion)."""
    enum = _enum_values(schema)
    if enum is not None:
        return click.Choice(enum)
    if _is_object_field(schema):
        return None
    types = _types_in(schema)
    if "integer" in types:
        lo, hi = schema.get("minimum"), schema.get("maximum")
        if lo is not None or hi is not None:
            return click.IntRange(min=lo, max=hi)
        return click.INT
    if "number" in types:
        lo, hi = schema.get("minimum"), schema.get("maximum")
        if lo is not None or hi is not None:
            return click.FloatRange(min=lo, max=hi)
        return click.FLOAT
    if "boolean" in types:
        return click.BOOL  # placeholder; caller uses --flag/--no-flag form
    return click.STRING


def _coerce_object_value(field_name: str, raw: str, _schema_field: dict) -> Any:
    """Decode an object-typed flag value into the wire payload.

    Three accepted forms (sniffed in order):

    1. ``@path/to.json`` → read file, JSON-parse, inline.
    2. ``s3://`` / ``file://`` / ``http(s)://`` → return string unchanged
       (the agent fetches it server-side per the schemas extension).
    3. otherwise → JSON-parse as a literal.

    Raises :class:`click.UsageError` with the field name on parse failure.
    """
    if raw.startswith("@"):
        path = raw[1:]
        try:
            with open(path) as f:
                return json.load(f)
        except FileNotFoundError as e:
            raise click.UsageError(
                f"--{_kebab(field_name)}: file not found: {path}"
            ) from e
        except (OSError, json.JSONDecodeError) as e:
            raise click.UsageError(
                f"--{_kebab(field_name)}: failed to read {path}: {e}"
            ) from e
    if _URI_SCHEME_RE.match(raw):
        return raw
    try:
        return json.loads(raw)
    except (json.JSONDecodeError, ValueError) as e:
        raise click.UsageError(
            f"--{_kebab(field_name)}: value must be inline JSON, "
            f"@path/to.json, or a URI (file://, s3://, https://): {e}"
        ) from e


def _option_for_property(
    name: str,
    prop_schema: dict,
    required: bool,
) -> click.Option:
    """Build one Click option from a JSON-Schema property.

    Note: Click treats ``default=None`` as "I have a default, it's None"
    which silently overrides ``required=True``. We therefore only pass
    ``default=`` when the schema actually has one.
    """
    description = prop_schema.get("description", "")
    has_default = "default" in prop_schema
    default_kw: dict = {"default": prop_schema["default"]} if has_default else {}
    # Required-ness is enforced post-merge in the callback so --input can
    # supply required fields without the user also passing the flag. The
    # description is annotated to keep --help honest.
    is_required = False
    if required and not has_default:
        description = (description + "  [required]").strip()
    flag = f"--{_kebab(name)}"

    types = _types_in(prop_schema)

    # Boolean → --flag/--no-flag pair, default reflected in --help.
    if "boolean" in types and _enum_values(prop_schema) is None:
        return click.Option(
            [f"{flag}/--no-{_kebab(name)}", name],
            help=description,
            show_default=True,
            required=is_required,
            **default_kw,
        )

    if _is_object_field(prop_schema):
        help_text = description or ""
        suffix = "JSON, @file, or URI."
        help_text = f"{help_text}  ({suffix})" if help_text else suffix
        return click.Option(
            [flag, name],
            type=click.STRING,
            help=help_text,
            required=is_required,
            **default_kw,
        )

    click_type = _click_type_for(prop_schema)
    return click.Option(
        [flag, name],
        type=click_type,
        help=description,
        show_default=has_default,
        required=is_required,
        **default_kw,
    )


def _build_skill_options(schema: dict) -> tuple[list[click.Option], dict[str, dict]]:
    """Return (options, prop_schemas) for a skill's input schema.

    ``prop_schemas`` maps the snake_case property name to its raw schema
    dict so the runtime can decide whether to coerce the value as object.
    """
    properties: dict[str, dict] = schema.get("properties") or {}
    required: set[str] = set(schema.get("required") or [])
    options: list[click.Option] = []
    prop_schemas: dict[str, dict] = {}
    for name, prop in properties.items():
        if not isinstance(prop, dict):
            continue
        prop_schemas[name] = prop
        options.append(_option_for_property(name, prop, name in required))
    return options, prop_schemas


# ──────────────────────────────────────────────────────────────────────────
#  Polling
# ──────────────────────────────────────────────────────────────────────────


def _status_message_text(task: dict) -> str:
    """Extract human-readable text from the task's status.message, or ``""``."""
    status = task.get("status") or {}
    message = status.get("message") or {}
    parts = message.get("parts") or []
    out: list[str] = []
    for p in parts:
        if not isinstance(p, dict):
            continue
        kind = p.get("kind")
        if kind == "text":
            text = p.get("text", "")
            if text:
                out.append(text)
        elif kind == "data":
            data = p.get("data")
            if isinstance(data, dict) and "message" in data:
                out.append(str(data["message"]))
    return " ".join(out).strip()


def _artifact_summaries(task: dict) -> list[tuple[str, str]]:
    """List of ``(artifact_id, name)`` for every artifact on the task."""
    out: list[tuple[str, str]] = []
    for art in task.get("artifacts") or []:
        if not isinstance(art, dict):
            continue
        aid = art.get("artifactId") or art.get("id") or ""
        name = art.get("name") or "(unnamed)"
        out.append((aid, name))
    return out


def _now_hms() -> str:
    return time.strftime("%H:%M:%S", time.localtime())


def _poll_until_terminal(
    client: A2AClient,
    task_id: str,
    *,
    interval: int | None = None,
) -> dict:
    """Poll ``tasks/get`` until terminal state.

    Cadence: fixed at ``interval`` seconds if given, else
    ``5×6 + 15×20 + 60·∞``. Emits one stderr line per change in state,
    status-message text, or artifact set. ``time.sleep`` is looked up
    at call time so tests can monkey-patch it.
    """
    last_state: str | None = None
    last_msg: str = ""
    seen_artifacts: set[str] = set()
    cadence = iter(_POLL_CADENCE) if interval is None else None

    while True:
        result = client.get_task(task_id)
        state = (result.get("status") or {}).get("state")
        msg = _status_message_text(result)
        artifacts = _artifact_summaries(result)

        if state and state != last_state:
            click.echo(f"[{_now_hms()}] state={state}", err=True)
            last_state = state
        if msg and msg != last_msg:
            click.echo(f"[{_now_hms()}] msg: {msg}", err=True)
            last_msg = msg
        for aid, name in artifacts:
            if aid not in seen_artifacts:
                tag = f" ({aid[:8]}…)" if aid else ""
                click.echo(f"[{_now_hms()}] artifact: {name}{tag}", err=True)
                seen_artifacts.add(aid)

        if state in _TERMINAL_STATES:
            return result

        if interval is not None:
            time.sleep(interval)
        else:
            try:
                time.sleep(next(cadence))
            except StopIteration:
                time.sleep(60)


# ──────────────────────────────────────────────────────────────────────────
#  Output helpers
# ──────────────────────────────────────────────────────────────────────────


def _emit_error_json(e: Exception) -> None:
    if isinstance(e, A2AError):
        payload = {"error": {"code": e.code, "message": str(e)}}
    else:
        payload = {"error": {"message": str(e)}}
    click.echo(json.dumps(payload, indent=2), err=True)


def _emit_input_required_hint(group_name: str, task_id: str, context_id: str | None) -> None:
    parts = [f"--task-id {task_id}"]
    if context_id:
        parts.append(f"--context-id {context_id}")
    click.echo(
        f"\nTask awaiting input. Continue with:\n"
        f"  asta {group_name} send-message {' '.join(parts)} '<reply-json>'",
        err=True,
    )


def _maybe_merge_files_into_message(
    message: str, file: tuple[tuple[str, str], ...]
) -> str:
    if not file:
        return message
    try:
        data = json.loads(message)
    except (json.JSONDecodeError, ValueError) as e:
        raise click.UsageError("MESSAGE must be valid JSON when using --file") from e
    if not isinstance(data, dict):
        raise click.UsageError("MESSAGE must be a JSON object when using --file")
    for key, path in file:
        with open(path) as f:
            data[key] = json.load(f)
    return json.dumps(data)


# ──────────────────────────────────────────────────────────────────────────
#  Per-skill command + describe (used by make_a2a_group)
# ──────────────────────────────────────────────────────────────────────────


def _build_skill_command(
    group_name: str,
    skill: dict,
    schema: dict,
    url_factory: Callable[[], str],
    token_factory: Callable[[], str | None],
) -> click.Command:
    """Generate the Click command for one skill."""
    skill_id = skill["id"]
    description = skill.get("description") or ""
    required_fields: set[str] = set(schema.get("required") or [])

    options, prop_schemas = _build_skill_options(schema)
    standard = [
        click.Option(
            ["--input", "input_path"],
            type=click.Path(exists=True, dir_okay=False, readable=True),
            default=None,
            help="Base payload JSON; per-field flags layer on top as overrides.",
        ),
        click.Option(["--task-id", "task_id_"], default=None,
                     help="Continue an input-required task."),
        click.Option(["--context-id", "context_id_"], default=None,
                     help="Start a new task in an existing session."),
        click.Option(["--no-wait", "no_wait"], is_flag=True, default=False,
                     help="Submit and return the task id only (one line)."),
        click.Option(["--poll-interval", "poll_interval"], type=click.INT, default=None,
                     help="Override the default backoff cadence with a fixed interval (s)."),
    ]

    def _callback(**kwargs: Any) -> None:
        input_path: str | None = kwargs.pop("input_path", None)
        task_id_: str | None = kwargs.pop("task_id_", None)
        context_id_: str | None = kwargs.pop("context_id_", None)
        no_wait: bool = kwargs.pop("no_wait", False)
        poll_interval: int | None = kwargs.pop("poll_interval", None)

        # Build the payload in three layers, lowest to highest precedence:
        # 1. Schema defaults    — fill in for fields the user never touched.
        # 2. --input file       — overwrites schema defaults.
        # 3. Per-field flags    — but only when explicitly provided.
        ctx = click.get_current_context()

        payload: dict[str, Any] = {}
        for fname, fschema in prop_schemas.items():
            # Skip null defaults — those mean "field is optional, omit it".
            if "default" in fschema and fschema["default"] is not None:
                payload[fname] = fschema["default"]

        if input_path:
            with open(input_path) as f:
                base = json.load(f)
            if not isinstance(base, dict):
                raise click.UsageError("--input file must contain a JSON object")
            payload.update(base)

        for name, value in kwargs.items():
            source = ctx.get_parameter_source(name)
            # Skip values that came from the schema-default we already merged.
            if source == click.core.ParameterSource.DEFAULT:
                continue
            if value is None:
                continue
            if _is_object_field(prop_schemas.get(name, {})):
                payload[name] = _coerce_object_value(name, value, prop_schemas[name])
            else:
                payload[name] = value

        # Validate required fields after the merge, so --input can satisfy
        # them without forcing the user to also pass the per-field flag.
        missing = sorted(f for f in required_fields if f not in payload)
        if missing:
            raise click.UsageError(
                "Missing required fields: "
                + ", ".join(f"--{_kebab(f)}" for f in missing)
                + " (or supply via --input)"
            )

        # 2. Submit and (optionally) wait.
        try:
            client = A2AClient(url_factory(), api_key=token_factory())
            result = client.send_message(
                json.dumps(payload), task_id=task_id_, context_id=context_id_
            )
            task_id = result.get("id") or ""
            if no_wait:
                click.echo(task_id)
                return
            # Tasks may already be terminal on submit (e.g. immediate failure).
            state = (result.get("status") or {}).get("state")
            if state in _TERMINAL_STATES:
                final = result
            else:
                final = _poll_until_terminal(client, task_id, interval=poll_interval)
            click.echo(json.dumps(final, indent=2))
            terminal = (final.get("status") or {}).get("state")
            if terminal == "input-required":
                _emit_input_required_hint(group_name, task_id, final.get("contextId") or context_id_)
            elif terminal in _FAIL_STATES:
                sys.exit(1)
        except A2AError as e:
            _emit_error_json(e)
            sys.exit(1)
        except click.UsageError:
            raise
        except Exception as e:
            _emit_error_json(e)
            sys.exit(1)

    cmd = click.Command(
        name=skill_id,
        callback=_callback,
        params=options + standard,
        help=description,
        short_help=_short_help(description),
    )
    return cmd


def _build_describe_command(bundle: dict) -> click.Command:
    schemas: dict[str, dict] = bundle.get("schemas") or {}

    @click.command("describe", help="Print a skill's resolved input schema.")
    @click.argument("skill_id")
    def describe(skill_id: str) -> None:
        if skill_id not in schemas:
            valid = ", ".join(sorted(schemas)) or "(none cached)"
            raise click.UsageError(
                f"Unknown skill: {skill_id!r}. Available: {valid}"
            )
        click.echo(json.dumps(schemas[skill_id], indent=2))

    return describe


def _build_fallback_skill_command(
    group_name: str,
    skill: dict,
    url_factory: Callable[[], str],
    token_factory: Callable[[], str | None],
) -> click.Command:
    """Skill subcommand for cards without a published input schema.

    Takes a single positional JSON payload, like ``send-message`` does.
    """
    skill_id = skill["id"]
    description = skill.get("description") or ""

    @click.command(name=skill_id, help=description, short_help=_short_help(description))
    @click.option("--task-id", "task_id_", default=None)
    @click.option("--context-id", "context_id_", default=None)
    @click.option("--no-wait", "no_wait", is_flag=True, default=False)
    @click.option("--poll-interval", "poll_interval", type=click.INT, default=None)
    @click.argument("payload")
    def _fallback(
        task_id_: str | None,
        context_id_: str | None,
        no_wait: bool,
        poll_interval: int | None,
        payload: str,
    ) -> None:
        try:
            client = A2AClient(url_factory(), api_key=token_factory())
            result = client.send_message(payload, task_id=task_id_, context_id=context_id_)
            task_id = result.get("id") or ""
            if no_wait:
                click.echo(task_id)
                return
            state = (result.get("status") or {}).get("state")
            final = result if state in _TERMINAL_STATES else _poll_until_terminal(
                client, task_id, interval=poll_interval
            )
            click.echo(json.dumps(final, indent=2))
            terminal = (final.get("status") or {}).get("state")
            if terminal == "input-required":
                _emit_input_required_hint(group_name, task_id, final.get("contextId") or context_id_)
            elif terminal in _FAIL_STATES:
                sys.exit(1)
        except A2AError as e:
            _emit_error_json(e)
            sys.exit(1)
        except Exception as e:
            _emit_error_json(e)
            sys.exit(1)

    return _fallback


# ──────────────────────────────────────────────────────────────────────────
#  Per-agent factory
# ──────────────────────────────────────────────────────────────────────────


def _register_low_level(
    group: click.Group,
    url_factory: Callable[[], str],
    token_factory: Callable[[], str | None],
) -> None:
    """Add ``card``, ``send-message``, ``task`` to a group.

    These work without ever fetching the agent card, so they remain
    available even when offline / uncached.
    """

    @group.command()
    def card() -> None:
        """Print the agent's full A2A spec (skills, schemas, capabilities)."""
        try:
            result = A2AClient(url_factory(), api_key=token_factory()).get_agent_card()
            click.echo(
                AgentCard.model_validate(result).model_dump_json(
                    by_alias=True, indent=2, exclude_none=True
                )
            )
        except Exception as e:
            _emit_error_json(e)
            sys.exit(1)

    @group.command("send-message")
    @click.option(
        "--task-id",
        default=None,
        help="Existing task ID to continue (use when a task is in `input-required`).",
    )
    @click.option(
        "--context-id",
        default=None,
        help="Existing context ID to start a new task within an existing session.",
    )
    @click.option(
        "--file",
        "-f",
        multiple=True,
        type=(str, click.Path(exists=True)),
        help="Merge a JSON file into the message: --file key path.json",
    )
    @click.argument("message")
    def _send_message(
        task_id: str | None,
        context_id: str | None,
        file: tuple[tuple[str, str], ...],
        message: str,
    ) -> None:
        """Send a raw JSON-RPC message (escape hatch under the typed flags).

        MESSAGE is a JSON object with the agent's task parameters. Prefer
        the per-skill subcommands above for typed flag validation.
        """
        try:
            message = _maybe_merge_files_into_message(message, file)
            result = A2AClient(url_factory(), api_key=token_factory()).send_message(
                message, task_id=task_id, context_id=context_id
            )
            click.echo(json.dumps(result, indent=2))
        except Exception as e:
            _emit_error_json(e)
            sys.exit(1)

    @group.command("task")
    @click.argument("task_id")
    def _task(task_id: str) -> None:
        """Fetch a task by ID and print its current state and artifacts."""
        try:
            result = A2AClient(url_factory(), api_key=token_factory()).get_task(task_id)
            click.echo(
                Task.model_validate(result).model_dump_json(
                    by_alias=True, indent=2, exclude_none=True
                )
            )
        except Exception as e:
            _emit_error_json(e)
            sys.exit(1)


def make_a2a_group(
    name: str,
    url_factory: Callable[[], str],
    token_factory: Callable[[], str | None] | None = None,
    help: str | None = None,
) -> click.Group:
    """Create a Click group with baked-in A2A agent URL and auth.

    The returned group always carries ``card``, ``send-message``, and
    ``task`` (no ``--url`` / ``--api-key`` flags — both are resolved at
    call time via the supplied factories). It additionally fetches the
    agent card and per-skill input schemas (cached on disk) and emits
    one typed Click subcommand per skill plus a ``describe`` subcommand.

    A top-level ``--refresh-card`` flag busts the disk cache before
    fetching. The ``ASTA_AGENT_NO_CACHE=1`` env var has the same effect.

    Card fetch errors are non-fatal: ``card``/``send-message``/``task``
    remain available, but skill subcommands are omitted (and a single
    stderr hint is printed when a user runs ``--help`` or any subcommand).

    Usage::

        from asta.utils.auth_helper import get_access_token

        def _url() -> str:
            base = os.environ.get("ASTA_GATEWAY_URL", "https://...")
            return f"{base}/api/my-agent"

        my_agent = make_a2a_group(
            name="my-agent",
            url_factory=_url,
            token_factory=get_access_token,
            help="Talk to My Agent.",
        )
        cli.add_command(my_agent)
    """
    if token_factory is None:
        token_factory = lambda: None  # noqa: E731
    # We can't ask Click to parse "--refresh-card" before subcommand
    # registration, so sniff sys.argv directly. To avoid cross-talk
    # with sibling agent groups (each makes its own cache), only honor
    # the flag when this group's name is also present in argv.
    # ``ASTA_AGENT_NO_CACHE=1`` is the env equivalent.
    refresh = "--refresh-card" in sys.argv and name in sys.argv

    group = click.Group(name=name, help=help)
    group.params.append(
        click.Option(
            ["--refresh-card"],
            is_flag=True,
            default=False,
            help="Refresh the cached agent card before running.",
        )
    )

    _register_low_level(group, url_factory, token_factory)

    # Best-effort skill discovery. Any failure here means the group still
    # works as the legacy three-subcommand surface.
    try:
        client = A2AClient(url_factory(), api_key=token_factory())
        bundle = _load_card_with_schemas(client, url_factory(), refresh=refresh)
    except Exception as e:
        # Only surface the failure when the user explicitly targeted *this*
        # group with --refresh-card. A global ASTA_AGENT_NO_CACHE=1 forces a
        # fetch in every sibling group; their failures are noise.
        if refresh:
            click.echo(
                f"asta-agent: --refresh-card failed for {name}: {e}",
                err=True,
            )
        return group

    group.add_command(_build_describe_command(bundle))
    schemas: dict[str, dict] = bundle.get("schemas") or {}
    for skill in bundle["card"].get("skills") or []:
        skill_id = skill.get("id")
        if not skill_id:
            continue
        schema = schemas.get(skill_id)
        if schema is None:
            group.add_command(_build_fallback_skill_command(name, skill, url_factory, token_factory))
        else:
            group.add_command(_build_skill_command(name, skill, schema, url_factory, token_factory))

    return group


if __name__ == "__main__":
    a2a()
