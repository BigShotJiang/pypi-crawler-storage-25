"""Claude Code hook entrypoints."""
