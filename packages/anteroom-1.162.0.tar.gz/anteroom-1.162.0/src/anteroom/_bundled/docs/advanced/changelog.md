# Changelog

Release highlights for every Anteroom version. For full details including developer notes and upgrade instructions, see the linked GitHub Release.


---

## April 12, 2026

### v1.161.0 — The Responsive Release

Anteroom gets dramatically faster and more interactive — sub-200ms startup, sub-50ms cancel, real-time thinking indicators, and live follow-up message routing to running workflows.

#### Follow-up message routing

Type "cancel that" or "I pushed fixes" while workflows run, and the message is dispatched to the right run automatically. Multi-run disambiguation asks you to pick by number, name, or ID prefix. Delivery is at-least-once with a live mid-run drainer. (#889)

See [Workflow Monitoring](../workflows/monitoring.md) for the full routing reference.

#### Sub-200ms startup

Heavy imports deferred, MCP connections and update checks fully backgrounded. The prompt appears immediately. (#1371)

See [CLI Startup Behavior](../cli/index.md#startup-behavior) for details.

#### Instant cancel and thinking indicators

Ctrl+C acknowledged in under 50ms (#1372). Status bar shows real-time phase: "Connecting," "Executing read_file," "Streaming response" (#1366).

See [CLI Index](../cli/index.md) for the indicator reference.

#### Replay-from-step

Resume workflow runs from a specific step, pruning downstream state while preserving prior work. (#1106)

See [Workflow Commands](../workflows/commands.md) for usage.

#### SKILL.md format

Skills now use Markdown with YAML frontmatter. All 13 built-ins migrated. (#856)

See [Skills](../cli/skills.md) for the format reference.

#### Bug Fixes

- Duplicate phase text in CLI status toolbar (#1382)
- Update check blocking prompt for up to 2s (#1377)

[GitHub Release](https://github.com/troylar/anteroom/releases/tag/v1.161.0)

---

## April 10, 2026

### v1.160.0 — Provider Guardrails

Anteroom now validates every outbound provider request before it reaches the SDK, catching malformed conversations locally with actionable error messages instead of opaque SDK exceptions.

#### Pre-flight provider request validation

When using Anthropic (direct or via LiteLLM) or AWS Bedrock, provider APIs enforce strict conversation rules. Previously, violations produced cryptic SDK errors. Now two rules are enforced before every send:

- **First message must be user** — for Anthropic and Bedrock routes, the first non-system message must be `user`. Violations name the offending message and suggest remediation.
- **Bedrock tool calling guardrail** — tool calling via LiteLLM → Bedrock is blocked by default (fail-closed) with an opt-in config flag `ai.litellm_bedrock_tools_confirmed`. (#1344)

See [Config Reference](../configuration/config-file.md) for the new field and [Connect to OpenRouter / Bedrock](../tutorials/connect-to-openrouter.md) for setup.

#### Bug fix: context compaction compatibility

Context compaction summary changed from `role: system` to `role: user` to satisfy the new first-message validation for Anthropic/Bedrock routes. (#1344)

[GitHub Release](https://github.com/troylar/anteroom/releases/tag/v1.160.0)

---

## April 9, 2026

### v1.159.0 — Trustworthy Workflows

The local issue-delivery workflow gains stale-worktree recovery, observable provider errors, real-git integration test coverage, and a new real-behavior validation guardrail that prevents workflow-control and Git-integration PRs from being senior-approved on mocked unit tests alone.

#### Stale worktree recovery

The `prepare` step now fetches the current default branch and fast-forwards stale issue branches safely — including the edge case where a linked worktree directory was deleted without `git worktree prune`. The helper prunes stale worktree metadata before attempting `git branch -f`, and refuses to rewrite branches with real divergent work. (#1197)

See [Local CLI Issue Flow](../workflows/local-cli-issue-flow.md) for the prepare semantics.

#### Observable provider errors

Provider-side validation failures like `toolConfig must be defined ...` and `a conversation must start with a user message` previously collapsed to the opaque "An internal error occurred". All three provider services now surface unmapped exceptions as structured `error` events carrying `provider` and `model` context. The LiteLLM provider gains explicit typed handlers for connection, timeout, service-unavailable, internal-server, and bad-gateway failures, and the generic catch-all is tightened to fail-fast for unknown errors. (#1343)

See [Configuration Reference](../configuration/config-file.md) for provider settings.

#### Real-behavior validation guardrail

A new `SENSITIVE_PATH_PATTERNS` allowlist in the workflow helper script gates senior approval of workflow-control and Git-integration PRs on documented real-behavior validation. When a plan or PR touches any sensitive path, the review commands force `changes_requested` unless the review JSON proves a real-behavior step was run. The validation note is persisted as a `## Real-behavior validation` section on the PR body. Fail-closed: if `gh` or `git` fails to return the file list, the scope is assumed sensitive. (#1200)

See [Local CLI Issue Flow — Real-behavior validation guardrail](../workflows/local-cli-issue-flow.md#real-behavior-validation-guardrail) for the full rule and how to extend the allowlist.

#### Real-git integration test coverage

Six new integration tests exercise the `local_cli_issue_flow.py` helper against real temporary git repositories, covering `inspect_pr_state` lifecycle branches, `branch_status` fast paths, and the `ensure_worktree` diverged-branch `fail()` path. (#1199)

See [Testing](testing.md) for the integration test patterns.

[GitHub Release](https://github.com/troylar/anteroom/releases/tag/v1.159.0)

---

## April 7, 2026

### v1.158.0 — Async Work You Can Trust

Background shell tasks and detached subagents now announce their own completion, carry a structured result contract, and get routed intelligently across execution surfaces. On the context-management side, historical tool results are compacted before replay and a shared full-request token accounting path catches silent overflows.

#### Completion notifications for async tasks

Background shell tasks and detached subagents now surface completion notices in both the CLI and web UI through shared SSE events and a single dedup path. Long-running work tells you when it's done without polling. (#1315)

See [Background Tasks](../cli/background-tasks.md) for usage details.

#### Structured TaskResult contracts

Async work no longer returns a free-form text blob. The new `TaskResult` dataclass carries `summary`, `status`, `tool_calls_made`, `files_touched`, `elapsed_seconds`, and an `output_pointer`, with `to_llm_dict()` stripping trust-boundary fields before the model sees the result. Both the CLI completion path and `GET /api/agent-runs/{id}` return this shape. (#1316)

See [Async Tools](../cli/tools.md) and [Streaming](../web-ui/streaming.md) for the full contract.

#### Execution surface routing advisory

A new advisory layer suggests the right execution surface — inline tool, inline subagent, background shell task, detached subagent, or workflow — based on task shape and expected duration. Two new `CliConfig` knobs control the thresholds. (#1317)

```yaml
cli:
  background_suggest_seconds: 30   # suggest background for tasks >= 30s
  detach_suggest_seconds: 120      # suggest detached subagent for tasks >= 2min
```

See [Configuration Reference](../configuration/config-file.md) for the knobs and [Background Tasks](../cli/background-tasks.md) for when each surface fires.

#### Compact tool result replay

Resuming a chatty conversation used to blast every stored bash output and file read back into the model's context — tens of thousands of tokens of stale stdout per resume. The new shared `compact_tool_output()` helper strips internal metadata, preserves structured fields (`exit_code`, `error`, `path`), and truncates bulk content with an informative suffix. Applied on conversation replay **and** live in the agent loop so chatty tools also stop blowing the context window. (#1336)

```yaml
cli:
  tool_output_max_chars: 2000      # live agent call budget
  tool_replay_max_chars: 2000      # conversation replay budget
```

See [Configuration Reference](../configuration/config-file.md) for the full tool budget knobs.

#### Shared full-request token accounting

Anteroom's context warnings and auto-compaction gate used to count only chat messages, missing the system prompt, tool schemas, and the pending user turn. A single large pasted prompt or `@file` expansion could silently push a real request past the model's context window. The new `estimate_request_tokens()` returns a `RequestTokenBreakdown` covering messages + system prompt + tool schemas + injected context, and is wired into the CLI auto-compact gate, the web preflight path, the agent loop's proactive compaction, and the introspect budget tool. The CLI caches the fixed portion once at REPL startup so per-turn cost stays cheap. (#1339)

See [Context Management](../cli/context-management.md) for thresholds and [Configuration Reference](../configuration/config-file.md) for the full knob list.

[GitHub Release](https://github.com/troylar/anteroom/releases/tag/v1.158.0)

---

## April 5, 2026

### v1.157.0 — Detached Subagents

Subagents can now run as durable background jobs. Pass `detach: true` to `run_agent` and the agent launches independently — the turn ends immediately while the subagent works in the background.

#### Detached Subagent Mode

The `run_agent` tool gains a `detach` parameter that launches subagents as durable async jobs tracked in `agent_runs`. Completion notifications surface in CLI and web UI. Use `agent_run_status` to inspect results. (#1314)

See [Built-in Tools](../cli/tools.md) for parameter reference.

#### Lifecycle Controls

New `/agent` CLI commands and `GET/DELETE/POST /api/agent-runs/` web API endpoints for listing, inspecting, cancelling, and retrying detached runs. Retry creates a new run with `parent_run_id` linkage — the full prompt is preserved for re-execution. (#1314)

See [CLI Commands](../cli/commands.md) and [Web Streaming](../web-ui/streaming.md) for details.

[GitHub Release](https://github.com/troylar/anteroom/releases/tag/v1.157.0)

---

## April 4, 2026

### v1.156.0 — Clean Workflow Interrupts

**Fixed:**

- Ctrl-C during workflow runs no longer leaves orphaned subprocesses or produces `RuntimeError: Event loop is closed` tracebacks. `execute_opaque_runner()` now kills the process group and drains reader tasks before re-raising `CancelledError`. (#1149)

[GitHub Release](https://github.com/troylar/anteroom/releases/tag/v1.156.0)

### v1.155.0 — Responsive Background Conversations

The foreground message queue is now decoupled from background task lifecycle. Queued messages process immediately when the foreground turn ends, regardless of background tasks.

#### Foreground/Background Separation

Queue decisions gate solely on foreground state. Background tasks are purely informational — shown as `[N bg]` in the CLI prompt and "N task(s) running" in the web UI. Counter resets on conversation switch and SSE reconnect. (#1313)

[GitHub Release](https://github.com/troylar/anteroom/releases/tag/v1.155.0)

### v1.154.0 — Task Output Inspection

Background tasks now capture their full stdout/stderr to disk, with CLI commands and web API endpoints to inspect output after the fact.

#### Durable Output Storage

Stdout and stderr are captured to `{data_dir}/task_output/{conversation_id}/{task_id}.stdout|stderr`, capped at 10MB. Cleaned up on conversation deletion and by the retention worker. (#1312)

#### CLI Task Commands and Web API

New `/task list|show|output|cancel` commands in the REPL, plus `GET /api/tasks`, `GET /api/tasks/{id}`, and `GET /api/tasks/{id}/output` web endpoints. New `bash_task_output` built-in tool at READ tier. (#1312)

See [CLI Commands](../cli/commands.md) and [CLI Tools](../cli/tools.md) for reference.

[GitHub Release](https://github.com/troylar/anteroom/releases/tag/v1.154.0)

### v1.153.0 — Faster CI

CI pipeline optimizations that cut test run times by 30-45% across the Python matrix.

#### CI Pipeline Optimization

Four targeted changes to `.github/workflows/test.yml`: pip dependency caching, parallel unit tests via pytest-xdist (`-n auto --dist loadfile`), a dedicated lint job that runs once instead of 5 times, and coverage instrumentation scoped to Python 3.13 only. (#1325)

#### Test Reliability Fixes

Fixed several tests that became flaky under parallel execution: mocked project discovery for xdist isolation, increased subprocess and SSE stream timeouts, fixed a race condition in the REPL cancel recovery test, and excluded subprocess-spawning tests from parallel runs. (#1325)

[GitHub Release](https://github.com/troylar/anteroom/releases/tag/v1.153.0)

---

## April 3, 2026

### v1.152.0 — Missions Graduate

The largest mission system release since V1. Missions now handle the full lifecycle — planning through delivery, failure recovery, and external reconciliation — with minimal operator intervention.

#### Lifecycle-Aware Workflow Routing

Mission items compile to the correct lifecycle workflow based on their current state. The new `local_work_item_router` inspects live PR state and routes automatically — fresh issues get delivery, existing PRs get repair, stale branches get refresh. (#1259, #1260, #1208, #1207)

See [Workflow Shape Selection](../missions/best-practices.md) for the routing table.

#### Mission Recovery Commands

Three new commands for precise failure recovery: `retry` (re-launch after transient failure), `replace` (cancel stuck execution and re-launch), and `reconcile` (mark externally completed work as done). Item IDs accept unique prefixes. (#1262, #1256, #1297)

See [Common Failure Modes and Recovery](../missions/best-practices.md) for patterns.

#### Automatic External Reconciliation

When a workflow-backed item fails but its linked GitHub issue is closed, the scheduler auto-reconciles to `completed` instead of leaving it in a stale `failed` state. Merged closing PRs are included in the audit trail. (#1306)

See [Reconcile an Item](../missions/index.md) for the operator contract.

#### Mission Observability

New `mission why` (blocker diagnosis), `mission summary` (retrospectives), and unified `observe` command for timeline views across missions and workflows. Delta summaries via `--since`. (#1235, #1263, #1225, #1236)

See [Monitoring](../missions/best-practices.md) for the command reference.

#### Runtime Scheduler Integration

The mission scheduler starts automatically in the web/app runtime. CLI users run `aroom mission scheduler` for local use. (#1196)

#### CLI Default Entry Point

`aroom` now launches the CLI REPL by default. Web UI via `aroom web`. (#1242)

#### Live ANTEROOM.md Reload

ANTEROOM.md changes are picked up during an active REPL session without restarting. (#1302)

#### Bug Fixes

- Strip UTF-8 BOM from config YAML files (#1287)
- Close stdin on all workflow subprocess spawns (#1298)
- Narrow `review_existing_work` scope and report timeout causes (#1301)
- Fix wrong-direction spaces column rename migration (#1258)
- Normalize baseline env signatures across worktrees (#1253)
- Share local issue workflow state across worktrees (#1251)
- Cap local issue-delivery plan churn (#1239)
- Register built-in workflow gates in executor dispatch (#1219)
- Prevent issue-delivery reruns from stalling on existing PR repair (#1210)
- Fix senior-review timeout fallback stalling workflows (#1201)

[GitHub Release](https://github.com/troylar/anteroom/releases/tag/v1.152.0)

---

## March 28, 2026

### v1.151.1 — Senior Review Timeouts Fail Closed

The local Claude/Codex issue-delivery workflow no longer disappears into a long fallback stall when a Codex senior review hangs. Review attempts are now bounded, timed-out review subprocesses are terminated, and the workflow records an explicit `review_failed` outcome while keeping `needs-senior-review` in place for operator follow-up. (#1201)

See [Local Claude/Codex Issue Flow](../workflows/local-cli-issue-flow.md) for the updated timeout behavior.

[GitHub Release](https://github.com/troylar/anteroom/releases/tag/v1.151.1)

### v1.151.0 — Missions That Actually Launch

`aroom mission create --launch` now correctly activates the mission session so the scheduler picks it up. Previously, launched missions were created in `pending` state — invisible to the scheduler. The fix threads launch intent through CLI → compiler → storage, and tightened integration tests prove scheduler visibility. (#1194)

See [Mission CLI](../missions/index.md) for usage details.

[GitHub Release](https://github.com/troylar/anteroom/releases/tag/v1.151.0)

### v1.150.0 — Richer Documents, Stronger Foundation

Two long-running branches land together: the Office document tools now give the AI full formatting context, and the CLI's slash-command system is centralized into a shared engine.

#### Enriched XLSX and DOCX Read Output

The `xlsx` and `docx` tools now return formatting metadata alongside content — bold, italic, font sizes, merged cells, column widths, data validations, conditional formatting, named ranges, and more. Six new actions: `template_fill`, `manage_sheets`, `resize`, `insert_delete`, `copy_range` (XLSX) and `template_fill` (DOCX). All template operations sanitize replacement values to prevent DDE injection. (#607)

See [Tools Reference](../cli/tools.md) for action details.

#### Shared Slash-Command Engine

The 35+ CLI slash commands are now defined once in `commands.py` as centralized metadata. Skills derive their built-in name blocklist automatically — fixing 6 missing entries and 2 stale ones. This is Phase 1 infrastructure for interface parity; commands work exactly as before. (#801)

See [CLI Commands Reference](../cli/commands.md) for the full command list.

[GitHub Release](https://github.com/troylar/anteroom/releases/tag/v1.150.0)

---

## March 27, 2026

### v1.149.0 — Queue Feedback That Talks Back

When you send a message while the AI is still working, Anteroom now tells you exactly where you stand.

#### Steering-Message Queue Feedback

Both the web UI and CLI now provide real-time queue position feedback when you send messages during an active AI turn. The web UI shows a `queued (N)` badge that highlights briefly when your turn starts. The CLI shows `Message queued [N]: preview…` with the first 80 characters. The API response and SSE events include enriched `position` and `queue_depth` metadata. (#1175)

See [Web UI Streaming](../web-ui/streaming.md) for badge behavior, [CLI Index](../cli/index.md) for REPL queue feedback, and [API Conversations](../api/conversations.md) for the enriched response contract.

[GitHub Release](https://github.com/troylar/anteroom/releases/tag/v1.149.0)

### v1.148.0 — Spec-First Build Flow

Anteroom now supports LLM-assisted spec generation — describe what you want to build in natural language or point to a GitHub issue, and Anteroom generates a structured specification with requirements, design, and dependency-ordered tasks.

#### LLM-Assisted Spec Generation

The new `spec_generator` service lets you create specs from prompts or GitHub issues. Instead of manually writing YAML, describe your feature and Anteroom calls your configured LLM to produce a structured spec with requirements, design, and a task list. Tasks are automatically ordered using topological sort, so dependencies are respected and independent tasks are grouped for concurrent execution. (#1165)

```bash
aroom spec create --from-prompt "Add rate limiting to the /api/chat endpoint"
aroom spec create --from-issue 42
```

See [Spec Commands](../specs/commands.md) for full CLI usage and [API Reference](../specs/api-reference.md) for endpoint details.

#### Topological Task Ordering

Generated specs include dependency-aware task ordering. Tasks are grouped into levels: level 0 has no dependencies, level 1 depends only on level 0, and so on — making parallelization opportunities clear. (#1165)

See [Spec Concepts](../specs/concepts.md) for how specs, tasks, and dependencies fit together.

[GitHub Release](https://github.com/troylar/anteroom/releases/tag/v1.148.0)

### v1.147.1

**Fixed:**

- CLI theme, renderer, and workflow formatter tests now pass when the developer's shell has `NO_COLOR=1` set. A per-file `autouse` fixture clears the environment variable before each test, making all 472 affected tests deterministic. (#1172)

[GitHub Release](https://github.com/troylar/anteroom/releases/tag/v1.147.1)

## March 26, 2026

### v1.147.0 — Offline Development Kit

Anteroom is now fully distributable as a single `pip install` for offline or air-gapped development environments — no git clone required.

#### Kitchensink Extra and `aroom unpack`

The new `kitchensink` extra bundles everything a developer needs to contribute to Anteroom — tests, docs, evals, demo scripts, and dev dependencies — directly inside the wheel. A single `pip install anteroom[kitchensink]` gives you the full development toolchain, and `aroom unpack` extracts the bundled files into a working directory. (#1168)

```bash
pip install anteroom[kitchensink]
aroom unpack ./anteroom-dev
cd anteroom-dev && pytest tests/ -v
```

The unpack command includes symlink escape prevention and `--force` for overwriting existing directories.

See [Installation](../getting-started/installation.md) for setup details and [CLI Commands](../cli/commands.md) for the full `aroom unpack` reference.

[GitHub Release](https://github.com/troylar/anteroom/releases/tag/v1.147.0)

### v1.146.0 — Config Parity

The web UI and CLI now share the same agent loop configuration knobs. Previously, `cli.max_tool_iterations` and `cli.tool_output_max_chars` were only respected by the CLI — the web chat route silently used hardcoded defaults.

#### Agent Loop Config Threading

Setting `cli.max_tool_iterations` or `cli.tool_output_max_chars` in your `config.yaml` now applies to both the CLI REPL and the web UI chat. The same is true for `max_consecutive_text_only` and `max_line_repeats`, which were partially threaded before but now use the same safe fallback pattern. (#1145)

```yaml
cli:
  max_tool_iterations: 25       # applies to both CLI and web UI
  tool_output_max_chars: 4000   # applies to both CLI and web UI
```

See [Configuration](../configuration/index.md) for full details on CLI config knobs.

[GitHub Release](https://github.com/troylar/anteroom/releases/tag/v1.146.0)

### v1.145.0 — Preference-Driven Missions

Missions gain execution profiles — named preference bundles that tell the compiler how you want work to run, without requiring you to know about specific workflow definitions or adapter configs.

#### Execution Profiles

Instead of manually specifying adapters and workflow paths, you can now say what you *want* — "plan first", "work in parallel with review", "run hands-off" — and the compiler figures out the rest. (#1154)

```bash
aroom mission create --spec @ns/spec/auth --profile plan-then-execute
aroom mission create --prompt "Build auth module" --profile parallel-review
aroom mission create --spec @ns/spec/auth --profile hands-off
```

Four built-in profiles: `default`, `plan-then-execute`, `parallel-review`, `hands-off`. The compiler discovers available workflows, scores them against your preferences (runner match, input match, tags, structural features), and binds items to the best fit. If nothing matches, items fall back gracefully. Every item records a binding reason for provenance.

See [Execution Profiles](../missions/index.md#execution-profiles) for full details and [Planning and Execution](../planning-and-execution.md) for how profiles fit into the pipeline.

[GitHub Release](https://github.com/troylar/anteroom/releases/tag/v1.145.0)

---

## March 25, 2026

### v1.144.0 — The Mission Release

Anteroom gains a new orchestration layer. Missions sit above workflows — they take an approved spec or a free-form prompt, compile it into a versioned execution plan with dependencies, and coordinate work across adapters.

#### Mission Orchestration

Missions are versioned, steerable execution plans. Create one from an approved spec or a natural-language prompt, and the compiler produces a structured plan with items, dependencies, and adapter bindings. The deterministic scheduler evaluates eligibility and dispatches work through pluggable adapters. (#1042)

```bash
aroom mission create --spec @myteam/spec/auth --adapter workflow --workflow-path defs/build.yaml --launch
aroom mission status <session_id>
aroom mission talk <session_id>
```

See [Missions](../missions/index.md) for the full CLI reference and [Planning and Execution](../planning-and-execution.md) for how specs, missions, and workflows compose.

#### Data Model and Storage

Sessions, items, dependencies, executions, revisions, and events — all persisted to SQLite. Every plan mutation creates an immutable revision with full provenance. (#1043)

#### Adapter Protocol

Pluggable execution backends: `NoopAdapter` for tracked work, `WorkflowAdapter` for dispatching items as workflow runs. (#1044, #1046)

#### Deterministic Scheduler

The scheduler is the only launch authority. Evaluates eligibility from stored state — dependency completion, lane limits, concurrency groups, hold flags. No LLM in the scheduling loop. (#1045)

#### Plan Compiler

Spec-backed (deterministic) and prompt-backed (LLM) compilation. Patch compiler turns steering instructions into structured operations with restricted-mutation detection. (#1047)

#### Conversational Steering

Ten mission tools for real-time plan mutation: hold, resume, drop, reprioritize, add items, change dependencies, change bindings, replan. (#1048)

#### CLI Surface

Seven subcommands: `create`, `list`, `status`, `talk`, `update`, `revisions`, `cancel`. Plus `/mission` REPL commands with tab completion. (#1049)

[GitHub Release](https://github.com/troylar/anteroom/releases/tag/v1.144.0)

### v1.143.0 — The Recovery Release

Workflows now degrade into controlled, recoverable states with explicit operator guidance — never into opaque dead ends.

#### Workflow Recovery Model

Five interconnected improvements ship together as the recovery model umbrella (#1153):

**Resumable blocked runs** — Gate-blocked runs are no longer terminal. Fix the condition externally, then `aroom workflow resume` re-evaluates the gate. Blocked runs can also be cancelled directly. (#1141)

**Structured failure triage** — Failed runner steps extract normalized fields (`first_failing_test`, `first_assertion`, `failure_signature`) from pytest/ruff output. Repair steps receive structured XML via `context_from_failed_step`. (#1151)

**Loop no-progress detection** — Set `stop_after_unchanged: 3` on a loop and the engine stops early when the same failure signature repeats, instead of consuming all rounds. (#1152)

**Emit steps and final summaries** — `type: emit` steps for operator-facing milestone messages with `info`/`warning`/`success`/`error` levels. Workflow-level `summary:` block with `on_success`/`on_failure` templates. (#1150)

**Recovery action guidance** — CLI status/progress and web detail now show concrete recovery options for every non-success state. API run detail includes `recovery_actions`. (#1153)

```yaml
steps:
  - id: check
    type: emit
    message: "Starting checks for {issue_number}"
    level: info
  - id: repair_loop
    type: loop
    max_rounds: 5
    stop_after_unchanged: 3
    steps:
      - id: run_tests
        type: runner
        runner: shell
        command: pytest tests/ -x -q

summary:
  on_success: "All checks passed for issue {issue_number}"
  on_failure: "Failed at {failing_step}: {stop_reason}"
```

See [Workflow Definitions](../workflows/definitions.md), [Commands](../workflows/commands.md), and [Monitoring](../workflows/monitoring.md) for full details.

[GitHub Release](https://github.com/troylar/anteroom/releases/tag/v1.143.0)

### v1.142.1

**Documentation:**

- Added a cross-cutting [Planning and Execution](../planning-and-execution.md) page explaining how specs, workflows, and missions relate as distinct layers of planning, execution, and orchestration (#1076)

[GitHub Release](https://github.com/troylar/anteroom/releases/tag/v1.142.1)

### v1.142.0 — Smarter Loops

Repair loops that spin without progress now detect stagnation and stop early, saving rounds and making failure diagnosis clearer.

#### Loop No-Progress Detection

Workflow loops can now detect when the same failure repeats across consecutive rounds and stop early instead of consuming all remaining rounds. Add `stop_after_unchanged` to any loop step to enable detection — the engine computes a stable failure signature from each round's results and stops when the same signature repeats for the configured number of rounds. (#1152)

```yaml
steps:
  - id: repair_loop
    type: loop
    max_rounds: 10
    stop_after_unchanged: 3   # stop if same failure repeats 3x
    until:
      step: run_tests
      field: result_status
      equals: success
```

The no-progress check respects the existing termination priority — `until` and `break_when` always win. When a loop stops for no-progress, `aroom workflow diagnose` provides a distinct `loop_no_progress` diagnosis, and CLI output shows `(no progress)`.

See [Workflow Definitions](../workflows/definitions.md) for field documentation and [Workflow Commands](../workflows/commands.md) for CLI output details.

#### Bug Fixes

- Fixed `rounds_completed` and `level` artifact keys being stripped during checkpoint sanitization (#1152)

[GitHub Release](https://github.com/troylar/anteroom/releases/tag/v1.142.0)

### v1.141.0

**Fixed:**

- The `/copy` CLI command now works out of the box — `pyperclip` is a base dependency instead of requiring a separate install (#1155)

[GitHub Release](https://github.com/troylar/anteroom/releases/tag/v1.141.0)

### v1.140.0 — Spec Portfolio Dashboard

Teams managing multiple specs now have a single consolidated view of lifecycle state across all specs in scope. The portfolio dashboard surfaces phase statuses, workflow execution progress, and staleness at a glance.

#### Portfolio Dashboard

The new dashboard aggregates lifecycle data from all specs into one view. Each spec shows its overall status (draft, in progress, stale, blocked, or all approved), individual phase statuses, and a summary of linked workflow runs. (#1016)

**CLI**: `/spec dashboard` renders a Rich table with color-coded status badges. Supports `--status`, `--namespace`, `--phase`, and `--phase-status` flags.

**Web UI**: A new Specs panel with filterable card view, phase filters, namespace search, and "with runs only" toggle. Click any spec card to see phase details. Auto-refreshes every 30 seconds.

**REST API**: `GET /api/specs/dashboard` returns specs, totals, and applied filters.

See [Spec Commands](../specs/commands.md) for CLI usage and [API Reference](../specs/api-reference.md) for endpoint details.

[GitHub Release](https://github.com/troylar/anteroom/releases/tag/v1.140.0)

### v1.139.0 — Copy to Clipboard

Type `/copy` in the CLI REPL to copy the last assistant response to your clipboard. Useful for pasting Claude's output into documents, chat windows, or code editors without manually selecting terminal text. (#1092)

```
anteroom> explain the config layering system
[Claude responds]

anteroom> /copy
Copied to clipboard.
```

Graceful degradation when clipboard is unavailable (headless/SSH environments).

See [CLI Reference](../cli/index.md) for the full list of slash commands.

[GitHub Release](https://github.com/troylar/anteroom/releases/tag/v1.139.0)

---

## March 24, 2026

### v1.138.0 — Shell Escape

Type `!` followed by any shell command to execute it inline from the CLI REPL without leaving the conversation. Output streams directly to your terminal. (#1140)

```
anteroom> ! git status
anteroom> ! pytest tests/unit/ -x -q
```

Works alongside `/slash` commands — `!` is for shell, `/` is for REPL commands.

See [CLI Reference](../cli/index.md) for full command documentation.

[GitHub Release](https://github.com/troylar/anteroom/releases/tag/v1.138.0)

### v1.137.0 — Resilient Workflows

Seven workflow engine primitives that transform failure handling from "any failure = abort" to "authors declare what happens on failure."

#### Loop Conditions

Loops can declare `until` (success condition), `fail_if_not_met` (fail on exhaustion), and `break_when` (early termination). All loops now report a `loop_end_reason` artifact. (#1125, #1130)

See [Loop Success Conditions](../workflows/definitions.md#loop-success-conditions-1125) and [Early Loop Termination](../workflows/definitions.md#early-loop-termination-1130) for YAML syntax.

#### Failure Continuation and Context

`continue_on: [failed]` lets a step fail without aborting the run. `context_from_failed_step` injects failure context into repair steps. (#1126, #1128)

See [Failure Continuation](../workflows/definitions.md#failure-continuation-continue_on) for details.

#### Failure Branches and Semantic Retries

`on_failure` declares handler steps that run when a step fails. `retry_on_result` retries based on step result content, not just exceptions. (#1127, #1129)

See [Failure Branches](../workflows/definitions.md#failure-branches-1127) and [Semantic Retries](../workflows/definitions.md#semantic-retries-1129).

#### Structured Outputs

Steps can declare `outputs` — named values extracted from results — so downstream branching uses explicit fields instead of parsing summaries. (#1131)

[GitHub Release](https://github.com/troylar/anteroom/releases/tag/v1.137.0)

### v1.135.1 — Failed Runs Are Fixable

Failed workflow runs can now be repaired and resumed. Fix inputs or prior step artifacts, then resume — completed steps are skipped, the failed step re-executes with corrected context. (#1124)

```bash
aroom workflow diagnose <run_id>
aroom workflow repair <run_id> --field inputs --value '{"issue": 100}'
aroom workflow resume <run_id>
```

See [Workflow Commands — Recovering from Failures](../workflows/commands.md#recovering-from-failures) for the full workflow.

[GitHub Release](https://github.com/troylar/anteroom/releases/tag/v1.135.1)

### v1.136.0 — Stable Prompt

The CLI REPL now keeps the input prompt visually stable while the agent is thinking. The "Thinking..." indicator and tool ticker render inside the sticky footer toolbar instead of as a separate raw ANSI line, eliminating prompt flickering and type-ahead corruption during agent turns. API error retry countdowns also route through the toolbar. (#1134)

See [CLI documentation](../cli/index.md) for REPL usage details.

[GitHub Release](https://github.com/troylar/anteroom/releases/tag/v1.136.0)

---

## March 23, 2026

### v1.135.0 — The Workflow Visibility Release

Workflow runs are no longer black boxes. This release adds timeline monitoring, durable transcripts, conversation replay, live streaming, and structured diagnosis across both CLI and web UI.

#### Timeline Monitoring

Step progress now shows status icons and friendly durations instead of raw output. Running steps show live elapsed time. Loop-nested steps are indented. (#1102, #1110)

See [Workflow Monitoring](../workflows/monitoring.md) and [Workflow Commands](../workflows/commands.md).

#### Durable Transcripts

Every agent step records assistant messages, tool calls, stdout/stderr, and token usage as `transcript_*` events. Six event types capture the full conversation inside each step. (#1111)

See [Workflow Monitoring — Transcript Events](../workflows/monitoring.md#transcript-events).

#### Transcript Rendering and Replay

`aroom workflow transcript` shows the conversation inside each step. `aroom workflow replay` stitches step-level transcripts into a run-level view with step boundaries and token counters. Both render in Anteroom style. (#1112, #1113)

See [Workflow Commands](../workflows/commands.md#aroom-workflow-transcript).

#### Incremental Streaming

`workflow watch` and `workflow run` show transcript content during execution, not just after completion. The web UI transcript panel updates via SSE in real time. (#1117)

#### Workflow Diagnosis

`aroom workflow diagnose` explains why a run stopped — 12 categories from runner failures to budget exhaustion, with evidence and suggested next actions. (#1103)

See [Workflow Commands](../workflows/commands.md#aroom-workflow-diagnose).

#### CLI Lifecycle Polish

Early run ID printing, `--detach` for background execution, and clean Ctrl-C with resume guidance. (#1118)

See [Workflow Quickstart](../workflows/quickstart.md).

#### Bug Fixes

- Fixed Ctrl-C on Windows workflow runs (#1122)
- Fixed asyncio teardown tracebacks on Python 3.13+

[GitHub Release](https://github.com/troylar/anteroom/releases/tag/v1.135.0)

---

## March 22, 2026

### v1.134.2 — Smarter Workflow Loops

Nested loop steps now support `when` guards, completing a feature that already worked at the top level. The local issue-delivery workflow's plan loop uses this to skip review when the draft failed.

- Workflow loop `when` guards: nested steps inside `loop` blocks can now declare `when` conditions. Skipped steps are neutral — they don't trigger loop retries. (#1095)

See [Workflow Definitions](../workflows/definitions.md) for `when` clause usage.

[GitHub Release](https://github.com/troylar/anteroom/releases/tag/v1.134.2)

### v1.134.1

**Fixed:**

- Local issue-delivery workflow helper no longer uses the non-portable `claude -C` flag. Uses `claude -p` with subprocess `cwd` instead. (#1096)

See [Local CLI Issue Flow](../workflows/local-cli-issue-flow.md) for the updated prerequisites.

[GitHub Release](https://github.com/troylar/anteroom/releases/tag/v1.134.1)

---

## March 21, 2026

### v1.134.0 — Workflow Control Surfaces

This release graduates workflow management from CLI-only to full web API parity, adds resilience for LLM-powered automation steps, and introduces cost-saving response caching.

#### Safe Cancel and Approval Semantics

Workflow runs can now be cancelled, approved, denied, and resumed from both the CLI and the web API. Cancellation uses a cooperative DB-polling model that works across processes. If a workflow has already crossed an irreversible step, the cancel response reports exactly what already happened. The chat interface detects natural-language cancel intent and routes through the same mechanism. (#890)

See [API Reference](../workflows/api-reference.md) for the 5 new action endpoints and [Monitoring](../workflows/monitoring.md) for cancel/approval events.

#### LLM Step Fallback Chains

Workflow `llm` steps can declare fallback models. When the primary model fails, the engine tries the next model in the chain. Each attempt emits an `llm_fallback` event, and cost accounting uses the actual model that succeeded. (#986)

See [Workflow Definitions](../workflows/definitions.md#fallback-models) for configuration.

#### LLM Step Response Caching

Repeated LLM calls with identical inputs can be cached to reduce cost and latency. Caching is opt-in, keyed by SHA-256 of deterministic inputs, and scoped by space for tenant isolation. Cached responses count zero tokens toward budget. (#988)

See [Response Caching](../workflows/definitions.md#response-caching) for scope semantics.

[GitHub Release](https://github.com/troylar/anteroom/releases/tag/v1.134.0)

### v1.133.0 — Workflow Repair

When a workflow run pauses — at an approval gate, a spec-gate block, or a human-input step — operators can now edit bounded fields in the run's state and resume execution from the paused point, without restarting the entire run.

#### Edit-and-Resume for Paused Runs

Workflow runs that are paused or blocked can now be repaired in place. The `repair` command lets operators correct a specific input field (like a spec FQN, a task ID, or a structured output value), then resume the run with the corrected state. Every repair is recorded in the run's event history with before/after values, creating a full audit trail. (#995)

Only `inputs_json` fields are editable — immutable fields like `run_id`, `workflow_id`, `status`, and `created_at` are protected. Runs must be in `paused` or `blocked` status to accept repairs.

```bash
aroom workflow repair <run_id> --field spec_fqn --value "@ns/spec/new-feature"
aroom workflow resume <run_id>
```

See [Workflow Commands](../workflows/commands.md) for CLI usage and [Workflow API Reference](../workflows/api-reference.md) for the REST endpoint.

[GitHub Release](https://github.com/troylar/anteroom/releases/tag/v1.133.0)

---

## March 19, 2026

### v1.132.0 — Better Docs Navigation

The documentation site gets a complete information architecture overhaul — fewer tabs, collapsible sections, and individual pages for every artifact type.

#### Restructured Navigation

The top-level tab bar goes from 15 overcrowded tabs to 6 clean groups: **Home**, **Getting Started**, **Using Anteroom**, **Extend**, **Configure**, and **Develop**. Within each tab, sidebar sections are now collapsible sub-groups (Getting Started, Using, Reference, Tutorials) so you see 4 lines per section instead of 10-13. Sticky tabs, breadcrumbs, nav pruning, search sharing, and tooltips are now enabled. (#1072)

#### Individual Artifact Type Pages

The monolithic "Artifact Types" page is now split into 8 individual pages — one per type. Navigate directly to any type from the sidebar. All references across the documentation now correctly list 8 artifact types (adding `spec`, which was introduced in v1.129.0 but missing from several reference pages). (#1072)

See [Artifact Types](../packs/artifact-types.md) for the overview with links to each type.

#### Cleaner Sidebar Titles

Stripped redundant prefixes from 17 page titles — "Workflow Quickstart" becomes just "Quickstart" when nested under the Workflows section. Same for Spec, Pack, and Space pages. (#1072)

[GitHub Release](https://github.com/troylar/anteroom/releases/tag/v1.132.0)

### v1.131.0 — Clear Slate

A new `/clear` command for the CLI REPL gives users a fast way to wipe the screen and start fresh without exiting.

#### `/clear` Command

Type `/clear` in the REPL to clear the terminal screen and reset the conversation context. A new conversation is created in the database (the previous one is preserved for resume). Message history and conversation-scoped prompt additions (approved plans, planning prompts, space instructions, RAG context) are stripped, while session-level content (canary tokens, codebase index, skill catalog) is preserved. If plan mode is active, it stays active in the new conversation. (#1057)

See [CLI Commands](../cli/commands.md) for the full command reference.

#### Bug Fixes

- Fixed docs build failure caused by a missing `cli/themes.md` page. Added CLI themes documentation. (#1057)

[GitHub Release](https://github.com/troylar/anteroom/releases/tag/v1.131.0)

### v1.130.0 — A Calmer CLI

Four CLI presentation improvements that make everyday use feel calmer and more intentional. No shared core changes — all presentation-layer polish.

#### Softer Inline Code Styling

Inline code spans in assistant responses now render with a subtle themed foreground instead of a harsh filled-chip look. New `code_inline` theme slot with per-theme colors. (#1055)

See [CLI Themes](../cli/themes.md) for customization.

#### Calmer Thinking Line

The thinking indicator is silent for the first 2 seconds, shows just "Thinking..." from 2-3s, adds a timer after 3s, and delays the "esc to cancel" hint until 8s. Phase detail suppressed for the first 5s. Retry and stall conditions still show immediately. (#1052)

See [Configuration Reference](../configuration/config-file.md) for CLI timing knobs.

#### Quieter RAG Diagnostics

Default COMPACT verbosity now suppresses successful RAG retrievals and "no results" statuses. Failure statuses use softened wording. Switch to DETAILED verbosity (press `v`) for full diagnostics. (#1053)

See [How RAG Works](../knowledge/how-rag-works.md) for monitoring details.

#### Polished Prompts

`ask_user` and approval prompts now render with themed headers, explicit choice prompts, confirmation lines, and prefix-match shortcuts. AI-generated content is escaped to prevent Rich markup injection. (#1051)

[GitHub Release](https://github.com/troylar/anteroom/releases/tag/v1.130.0)

### v1.129.0 — Workflow Engine: Params, Parallel, Compensation

Three workflow engine capabilities that make definitions reusable, concurrent, and recoverable.

#### Overridable Workflow Params

Workflow definitions can declare `params:` with defaults, overridden at runtime via `--param key=value` or the API. Teams share one YAML without forking. (#958)

See [Workflow Definitions — Params](../workflows/definitions.md#params) for the full reference.

#### Parallel Branches

New `parallel` step type executes named branches concurrently with `join: all` and fail-fast cancellation. Branch steps use qualified IDs (`branch_id/step_id`). Scope-aware `context_from` prevents sibling branch references. (#976)

See [Workflow Definitions — Parallel Steps](../workflows/definitions.md#parallel-steps) for the full reference.

#### Compensation and Rollback

Steps with side effects can declare `compensate:` blocks. On failure, the engine rolls back completed steps in reverse chronological order (best-effort). New statuses: `compensating`, `compensated`, `compensation_failed`. (#978)

See [Workflow Definitions — Compensation Steps](../workflows/definitions.md#compensation-steps) and [Monitoring — Run Statuses](../workflows/monitoring.md#run-statuses).

[GitHub Release](https://github.com/troylar/anteroom/releases/tag/v1.129.0)

### v1.128.0 — Specs Get Smarter

Four new spec system capabilities: design-first authoring, a review inbox, git linkage, and conformance checks. Together they make the spec system a real team workflow tool.

#### Design-First Spec Flow

The `--design-first` flag on `/spec create` lets teams start from the architecture and derive requirements later. Pending phases are guarded in code — they cannot be approved until real content is filled in via `/spec edit`. (#1013)

See [Spec Commands](../specs/commands.md) for full usage.

#### Review Inbox and Approval Queue

`/spec queue` shows specs with draft or stale phases and workflow runs blocked on spec gates. The queue is attachment-aware — only specs in your space/project context appear. Available via CLI and `GET /api/specs/queue`. (#1015)

See [Spec Commands](../specs/commands.md#spec-queue) and [API Reference](../specs/api-reference.md#review-queue).

#### Spec-to-Git Linkage

`/spec link` connects specs to branches and PRs. CLI auto-detects the current branch; the API accepts explicit links. Stored in spec metadata with deduplication. (#1018)

See [Spec Commands](../specs/commands.md#spec-link) and [API Reference](../specs/api-reference.md#list-git-links).

#### Deterministic Conformance Checks

`/spec conformance` runs four bounded checks: task coverage, run health, phase status, and temporal validity. All deterministic — no AI in V1. (#1017)

See [Spec Commands](../specs/commands.md#spec-conformance) and [API Reference](../specs/api-reference.md#conformance-check).

[GitHub Release](https://github.com/troylar/anteroom/releases/tag/v1.128.0)

---

## March 18, 2026

### v1.127.0 — The Workflow Toolbox

Four workflow improvements ship together: audit trail integration, a simulation/validation harness, a browser monitoring dashboard, and expanded CLI integration test coverage.

#### Workflow Audit Integration

Every durable workflow event now emits a tamper-evident audit entry when audit logging is enabled. The audit writer hooks into the engine's central `_emit_event()` dispatch for zero missed-event drift. All production constructor sites thread the writer, with a regression test to prevent future omissions. (#953)

See [Audit Log](../security/audit-log.md) for configuration.

#### Workflow Simulation and Validation

New `aroom workflow validate` and `aroom workflow simulate` CLI commands let you test workflow definitions without real side effects. Validation catches structural errors before execution. Simulation runs the real engine with stub runners for fidelity. (#968)

```bash
aroom workflow validate path/to/workflow.yaml
aroom workflow simulate path/to/workflow.yaml --stubs stubs.yaml
```

See [Workflow Commands](../workflows/commands.md) for full usage.

#### Workflow Dashboard

A browser panel for monitoring workflow runs with filterable list, step timeline detail view, and live SSE updates. Read-only in V1. (#961)

See [Workflow Monitoring](../workflows/monitoring.md) for details.

#### REPL Integration Coverage

Seven new CLI integration tests cover slash commands, plan mode, empty input, and graceful exit using the direct `_run_repl` harness. (#660)

[GitHub Release](https://github.com/troylar/anteroom/releases/tag/v1.127.0)

### v1.126.0 — Spec System Enhancements

The spec system graduates from a planning tool into a complete governed pipeline: plan as a bugfix or feature, approve phases, launch execution, and distribute governed specs through packs.

#### Bugfix Spec Flow

Specs now support a `mode: bugfix` field that selects a bugfix-oriented template — current behavior, expected behavior, reproduction steps, root cause, fix approach, and non-regression boundaries — within the same `requirements`/`design`/`tasks` phase lifecycle. Zero changes to gates, invalidation, or diff. (#1012)

See [Spec Commands](../specs/commands.md) for usage details.

#### Launch Execution from Spec Tasks

`/spec launch` bridges approved specs to workflow execution. Launch a governed run from a spec task without manually building inputs. Defense in depth: validates approval at launch and re-checks at execution via gate conditions. New REST endpoints: `POST /api/specs/{fqn}/tasks/{task_id}/launch` and `GET /api/specs/{fqn}/traceability`. (#1014)

See [Spec API Reference](../specs/api-reference.md) for endpoint details.

#### Pack Support for Specs

Packs can now include `type: spec` artifacts. Spec YAML is validated at install, pack-owned specs are read-only (content edits and deletes blocked, approval still works), and pack refresh runs invalidation rules on content changes. Attachment-aware filtering ensures detached pack artifacts are excluded from all surfaces. Also fixes a pre-existing SQL parameter ordering bug in `list_artifacts()`. (#1010)

See [Pack Artifact Types](../packs/artifact-types.md) for documentation.

[GitHub Release](https://github.com/troylar/anteroom/releases/tag/v1.126.0)

### v1.125.0 — Durable Run Storage

Agent runs now have persistent storage. Two new tables (`agent_runs` and `agent_run_events`) track conversation-scoped background work with status, timestamps, parent-child relationships, and an open-ended event log. This is the data foundation for async workflows — deployments, reviews, and ideation sessions that need status tracking and recovery.

#### Agent Run Storage

Eight CRUD functions provide full lifecycle management: create, query, update, and delete runs; append and list events; count active runs per conversation. Status vocabulary is aligned with the workflow engine to prevent translation churn. Event types are open-ended — producers store what they need without storage-layer constraints. (#887)

See [Architecture](../advanced/architecture.md) for database schema details.

[GitHub Release](https://github.com/troylar/anteroom/releases/tag/v1.125.0)

### v1.124.1 — The Coverage Release

Unit test coverage jumped from 65% to 88% effective, adding ~500 tests across 40+ modules. No production code changes — only test infrastructure improvements.

#### Test Coverage Improvements

Nearly 500 new unit tests across five tiers bring effective coverage (excluding platform-specific and optional-dependency modules) from 79% to 88.1%. Highlights: Anthropic provider 20% to 72%, workflow gates 0% to 92%, workflow hooks 68% to 98%, workflow executor 68% to 83%. (#1021, #1022, #1023, #1024, #1025, #1026)

See [Testing documentation](../advanced/testing.md) for the full testing guide.

[GitHub Release](https://github.com/troylar/anteroom/releases/tag/v1.124.1)

### v1.124.0 — Spec Commands Go Live

The spec lifecycle now has a full CLI and API surface. Create, inspect, approve, and diff specs without leaving your terminal.

#### /spec Commands and Spec API

The new `/spec` slash commands bring the full spec lifecycle to the CLI REPL. List specs with phase status badges, show detailed phase breakdowns, create specs via `$EDITOR`, approve or unapprove individual phases, and view colorized content diffs after updates. The matching REST API at `/api/specs` provides the same capabilities for the web UI and external integrations. (#1000)

```bash
/spec list                    # see all specs with phase badges
/spec show myapp/api-design   # phase statuses + content + tasks
/spec approve myapp/api-design architecture
/spec diff myapp/api-design   # colorized content diff
```

See [Spec Commands](../specs/commands.md) for the full CLI reference and [Spec Concepts](../specs/concepts.md) for how phases, approvals, and workflow gates work.

[GitHub Release](https://github.com/troylar/anteroom/releases/tag/v1.124.0)

### v1.123.1 — Spec System Foundation

This release introduces the spec artifact system — a structured layer above workflows for defining, approving, and tracking multi-phase specifications. It also fixes token usage reporting for providers that omit streaming usage data.

#### Spec Artifacts

A new `spec` artifact type with structured YAML schema supporting phases (e.g., architecture, api, security), tasks, and full version history. Specs integrate with the existing artifact registry, storage, and health check infrastructure. Filesystem discovery excludes specs to prevent conflicts with DB-managed instances. (#996)

See [Spec Quickstart](../specs/quickstart.md) to get started and [Spec Schema Reference](../specs/schema-reference.md) for the YAML format.

#### Spec Phase Approval Gates

Spec phases can now be individually approved, with automatic staleness detection when spec content changes after approval. Gates integrate with the workflow engine — all engine creation paths register spec gate handlers. `GateResult` contract provides structured pass/fail with reasons. (#997)

See [Spec Concepts](../specs/concepts.md#invalidation-rules) for how staleness tracking works and [Workflow Gates](../specs/concepts.md#workflow-gates) for gating workflow steps on spec approval.

#### Spec Diff and Impact Analysis

Content diffs between spec versions with single-write invalidation — updating a spec automatically marks approved phases as stale when the content they approved has changed. Enables impact analysis across spec revisions. (#1002)

See [Spec API Reference](../specs/api-reference.md#get-diff) for the diff endpoint.

#### Bug Fixes

- `/usage` and `aroom usage` now report token data even when the AI backend omits streaming usage. Tiktoken (`cl100k_base`) estimates tokens from the full prompt and response. Covers OpenAI-compatible, Anthropic, and LiteLLM providers. (#1006)
- Metadata merge preserves existing fields (like RAG provenance) when adding estimation flags. (#1006)

[GitHub Release](https://github.com/troylar/anteroom/releases/tag/v1.123.1)

## March 17, 2026

### v1.123.0 — Server-Mode Automation

Workflow execution graduates from CLI-only to full server-mode automation with background dispatch and cron scheduling.

#### Background Workflow Executor

A new background worker claims pending runs via atomic CAS, dispatches them through the engine, and recovers stale runs on startup. `POST /workflow-runs` enqueues runs from the web UI. `aroom workflow watch` observes progress in real time. (#888)

```yaml
workflow:
  executor_enabled: true
  max_concurrent_runs: 3
```

See [Workflow API Reference](../workflows/api-reference.md) for the POST endpoint and [Workflow Commands](../workflows/commands.md) for CLI usage.

#### Workflow Scheduling and Triggers

Workflows can declare `triggers:` in YAML for cron-based scheduling. Pure-Python evaluator with safety bounds. `missed_policy` controls run pile-up: `skip` advances immediately, `queue` waits for the prior run. (#969)

```yaml
triggers:
  - type: schedule
    cron: "0 8 * * *"
    missed_policy: queue
```

See [Workflow Scheduling](../workflows/scheduling.md) for full details.

[GitHub Release](https://github.com/troylar/anteroom/releases/tag/v1.123.0)

### v1.122.0 — Workflows That Think

A new `llm` step type brings bounded model inference directly into workflows.

#### LLM Steps

New `type: llm` for direct model inference. Per-step model override, token/cost tracking, `context_from` support. Uses `complete_with_usage()` on all three providers for usage metadata with auth refresh. (#983)

```yaml
- id: summarize
  type: llm
  prompt: "Summarize the findings."
  model: "gpt-4o-mini"
  context_from:
    - step: code_review
      field: result_summary
```

See [Workflow Definitions](../workflows/definitions.md) for the full LLM step reference.

#### Structured Output

LLM steps support `response_format: json_object`. Native on OpenAI/LiteLLM, instruction-based on Anthropic (best-effort). Parsed JSON in `result_artifacts.structured_output`. (#984)

See [Workflow Definitions](../workflows/definitions.md) for provider differences.

[GitHub Release](https://github.com/troylar/anteroom/releases/tag/v1.122.0)

### v1.121.0 — Safe Workflows

On-wire idempotency keys and explicit checkpoints make workflows safer for side-effecting operations and more auditable for operators.

#### Idempotency Keys for Publish Steps

Publish steps now receive a stable `Idempotency-Key` HTTP header, preventing duplicate delivery on retries. Key computed from `run_id:step_id` by default, or user-defined via template. Persisted on the step record before adapter call. Visible in `aroom workflow history`. (#977)

See [Workflow Definitions](../workflows/definitions.md) for the idempotency key reference.

#### Explicit Workflow Checkpoints

Labeled checkpoint snapshots at every execution boundary: step completion, pause, failure, and run completion. Sanitized via structural allowlisting (safe artifact keys only, summary truncation). CLI shows checkpoint count in status and list in history. New API: `GET /workflow-runs/{run_id}/checkpoints`. (#979)

See [Workflow Monitoring](../workflows/monitoring.md) for checkpoint details.

[GitHub Release](https://github.com/troylar/anteroom/releases/tag/v1.121.0)

---

## March 16, 2026

### v1.120.0 — Workflows That Track and Deliver

Always-on token tracking and a new publish step type make workflows production-ready for cost governance and end-to-end automation.

#### Always-On Token and Cost Tracking

Token usage is now tracked on every run regardless of budget config. Agent runners record prompt/completion tokens and model name. Cost estimation computed from `model_costs` config. CLI status and history show tokens/cost unconditionally. (#963)

See [Workflow Monitoring](../workflows/monitoring.md) for token/cost visibility.

#### Publish/Output Steps

New `publish` step type delivers workflow outputs to real destinations. V1 ships file (local filesystem) and webhook (HTTP POST) adapters. Publish steps consume prior step data via `context_from`, support credentials and template variables, and fail as real step failures. (#966)

```yaml
- id: save_report
  type: publish
  destination:
    adapter: file
    path: "/output/reports/{target_name}_report.md"
  context_from:
    - step: generate_report
      field: result_summary
```

See [Workflow Definitions](../workflows/definitions.md) for full publish step reference.

[GitHub Release](https://github.com/troylar/anteroom/releases/tag/v1.120.0)

### v1.119.0 — Smarter Workflows

Anteroom's workflow engine gains two new step-level controls: conditional execution and automatic retry.

#### Conditional Step Execution

Steps can now include a `when` clause that evaluates against prior step results. If the condition is false, the step is marked `skipped` and the engine moves on. Five operators: `equals`, `not_equals`, `is_not_empty`, `is_empty`, `contains`. Skipped steps cascade — if step B depends on a skipped step A, B is also skipped. (#959)

```yaml
- id: fix_findings
  type: runner
  runner: cli_claude
  prompt: "Fix the findings from the review."
  when:
    step: review
    field: result_findings
    is_not_empty: true
```

See [Workflow Definitions](../workflows/definitions.md) for full details.

#### Step Retry with Configurable Backoff

Steps can retry automatically with exponential or fixed backoff before failing the run. Each attempt creates a separate DB record. Budget checked before each attempt. Not allowed on gate/human_gate steps. (#962)

```yaml
- id: run_tests
  type: runner
  runner: shell
  command: "pytest tests/ -x"
  retry:
    max_attempts: 3
    backoff: exponential
    initial_delay: 5
    max_delay: 60
```

See [Workflow Definitions](../workflows/definitions.md) for full details.

[GitHub Release](https://github.com/troylar/anteroom/releases/tag/v1.119.0)

### v1.118.0 — Workflows That Connect

Credential binding and artifact integration make the workflow engine production-ready for real integrations — safe secret access and full connection to Anteroom's knowledge layer.

#### Credential Binding

Workflow steps can reference named credentials (env vars or shell commands) declared in `config.yaml`. Values are resolved at execution time, exist only in memory, and are never logged or persisted. Credentials support `allowed_runners` to restrict which runner types can use them. (#970)

```yaml
workflow:
  credentials:
    - name: github_token
      env_var: GITHUB_TOKEN
```

See [Workflow Definitions — Credentials](../workflows/definitions.md) for YAML reference and [Security Hardening](../security/hardening.md) for the security model.

#### Artifact Integration

Agent runner steps can invoke skills by name (`skill_name`), inject sources as context via UUID refs (`source_id`/`source_group_id`), and auto-inject rules/conventions from the artifact registry. On resume, registries are rebuilt scoped to the run's stored `space_id`. (#957)

See [Workflow Concepts — Artifact Integration](../workflows/concepts.md) and [Workflow Definitions](../workflows/definitions.md) for full details.

[GitHub Release](https://github.com/troylar/anteroom/releases/tag/v1.118.0)

### v1.117.0 — Governed Workflows

Definition drift detection and execution budgets bring governance to the workflow engine — ensuring long-running agentic workflows operate against the correct plan and within bounded resource limits.

#### Definition Drift Detection

When a workflow run starts, Anteroom records a SHA-256 hash and full snapshot of the YAML definition. If the definition changes while a run is paused, resuming is blocked with a drift report showing which steps changed. Use `--force` to override when the change is safe. Pre-existing runs with no stored hash resume with a warning. (#964)

```bash
aroom workflow resume <run_id> --force   # override drift block
```

See [Workflow Concepts — Definition Drift](../workflows/concepts.md) for details and [Commands — Resume](../workflows/commands.md) for CLI usage.

#### Workflow Execution Budgets

Workflows can declare resource budgets for duration, step count, and token consumption. Budgets are checked at step boundaries and persist across resumes. Config-level ceilings (`workflow.budget`) enforce stricter-wins policy for organization-wide limits. (#967)

```yaml
policies:
  budget:
    max_steps: 50
    max_tokens: 100000
    max_duration_seconds: 3600
```

See [Workflow Definitions — Policies](../workflows/definitions.md) for YAML reference, [Configuration — workflow.budget](../configuration/config-file.md) for config options, and [Security Hardening](../security/hardening.md) for the security rationale.

#### Approval Gates and Human-in-the-Loop Steps

Workflow runs can now pause for operator approval or an explicit human decision. Tool approvals are persisted as `waiting_for_approval` pauses that operators can resolve with `aroom workflow approve` or `aroom workflow deny`. New `type: human_gate` steps pause a run in `waiting_for_input`, present labeled options, and continue only after `aroom workflow respond` records a choice. (#971)

```yaml
- id: review_release
  type: human_gate
  prompt: "Ship this release?"
  options:
    - id: approve
      label: "Ship it"
      outcome: continue
    - id: reject
      label: "Stop"
      outcome: stop
      stop_reason: "release_rejected"
```

See [Workflow Definitions](../workflows/definitions.md) for `human_gate` syntax and [Workflow Commands](../workflows/commands.md) for approval and response handling.
[GitHub Release](https://github.com/troylar/anteroom/releases/tag/v1.117.0)

---

## March 15, 2026

### v1.116.0 — The Workflow Engine

Anteroom ships a durable, domain-neutral workflow engine that orchestrates multi-step processes defined in YAML. Define steps, gates, and loops — the engine handles execution, state persistence, crash recovery, and monitoring.

#### Workflow Engine

Run multi-step automation workflows from the CLI with durable state, concurrency locks, and crash recovery. Workflows are defined in YAML with three step types: runners (shell commands, Python scripts, or AI agent sessions), gates (boolean conditions that block or continue), and loops (bounded repetition). (#947, #948)

```bash
aroom workflow run my_pipeline.yaml
aroom workflow status <run_id>
aroom workflow list
```

See [Workflow Overview](../workflows/index.md) for the full guide and [Workflow Definitions](../workflows/definitions.md) for YAML syntax.

#### Crash Recovery and Resume

Workflows survive process crashes and machine reboots. Heartbeat-based stale detection identifies interrupted runs. Resume from the last completed step — no re-running successful work. (#949)

```bash
aroom workflow resume <run_id>
```

See [Workflow Commands](../workflows/commands.md) for resume and cancel details.

#### Monitoring: API, SSE, Hooks, and CLI Progress

Real-time workflow observability through four channels: a read-only REST API, SSE streaming, notification hooks (webhook and Unix socket with egress allowlist validation), and Rich CLI progress output during execution. (#951)

See [Monitoring](../workflows/monitoring.md) for hook configuration and [API Reference](../workflows/api-reference.md) for endpoint details.

[GitHub Release](https://github.com/troylar/anteroom/releases/tag/v1.116.0)

---

## March 14, 2026

### v1.115.1

**Fixed:**

- `/new-skill` could generate YAML with invalid fields or missing required keys, silently saving a broken skill that failed at invocation time. The skill authoring pipeline now validates against the `Skill` schema at creation time with clear error messages. (#938)

[GitHub Release](https://github.com/troylar/anteroom/releases/tag/v1.115.1)

---

## March 13, 2026

### v1.115.0 — Config Gets a Cockpit

Anteroom's configuration system has always been powerful — 7 layers of precedence, team enforcement, pack overlays. But editing it meant hand-editing YAML files. This release gives config a proper cockpit.

#### Interactive Config TUI

Type `/config` in the CLI REPL and you get a full-screen, two-panel editor. The left panel shows every settable field grouped by section, color-coded by which layer currently controls it. The right panel shows the selected field's effective value, source attribution, type constraints, and a layer-by-layer breakdown. (#933)

Navigate with arrow keys or `j`/`k`. Press Enter to edit — booleans toggle inline, enums cycle through allowed values, and strings/numbers get an inline text prompt. Tab cycles through scopes (personal, space, project). Press `s` to save, `r` to reset, `/` to filter.

```
/config              # Launch the TUI
/config list         # Quick field listing
/config get ai.model # Show one field with source
/config set ai.model gpt-4o --scope personal
```

See [Configuration](../configuration/index.md) for the full config reference.

#### Scoped Config Editing (CLI + API)

The new `config_editor` service provides scoped read/write for all config layers. `/config set` and `/config reset` accept `--scope personal|space|project` to target exactly the right YAML file. The web API gets matching endpoints for programmatic access. Source attribution is fully pack-aware. (#933)

Sensitive fields (`api_key`, identity keys, `encryption_kdf`) are blocked at the CLI and API boundary.

See [Configuration](../configuration/index.md) for scope precedence details.

[GitHub Release](https://github.com/troylar/anteroom/releases/tag/v1.115.0)

### v1.114.1

**Fixed:**

- REPL no longer hangs after cancelling an agent run with Ctrl-C or Escape — `agent_busy` is now unconditionally cleared on cancel, even when queued messages exist in the input pipeline (#937)
- Ctrl-C and Escape reliably route cancel signals through a shared `_route_cancel_signal()` function, preventing stale cancel events between turns (#937)
- Queued messages typed during streaming are preserved after cancel via msg_queue backfill (#937)
- Runner task exceptions are now surfaced via logging instead of being silently swallowed by `asyncio.wait()` (#937)
- Thinking spinner no longer orphaned after cancel — `_thinking_cancelled` guard flag prevents stale ticker artifacts (#937)

[GitHub Release](https://github.com/troylar/anteroom/releases/tag/v1.114.1)

### v1.114.0 — Themes, Timeouts, and Runtime Introspection

This release brings CLI color theming, clearer timeout UX for safety gates, runtime session introspection for the AI, and a terminology cleanup for pack directory scoping.

#### CLI Color Themes

The CLI now supports configurable color themes via `cli.theme` in `config.yaml`. Four built-in themes: **midnight** (default), **dawn** (warm light), **high-contrast** (maximum readability), and **accessible** (CVD-safe blue/orange per IBM). All 22 semantic color slots flow through a `CliTheme` frozen dataclass, replacing previously hardcoded hex values. The `NO_COLOR` environment variable is respected. (#116)

```yaml
cli:
  theme: "accessible"   # midnight | dawn | high-contrast | accessible
```

See [CLI Features](../cli/index.md) for the theme list and [Configuration](../configuration/config-file.md) for the config key.

#### Approval & Ask-User Timeout UX

When an approval gate or `ask_user` prompt times out, both the web UI and CLI now show a clear expiry message instead of silently failing. The web UI renders `approval-expired` / `ask-user-expired` CSS classes with status text, and SSE events include `reason: "timed_out"`. (#870)

#### Runtime Introspection

The `introspect` tool now supports `section=runtime`, exposing bounded session metadata: `conversation_id`, `conversation_title`, `slug`, `message_count`, `token_totals`, `active_space`, and `interface`. The `/a-help` skill includes a complete reference of all 9 valid introspect sections. (#908)

#### Terminology Cleanup

Pack `project_path` renamed to `directory` scoping throughout codebase and documentation, aligning with Spaces vocabulary. Non-breaking internal rename. (#881)

[GitHub Release](https://github.com/troylar/anteroom/releases/tag/v1.114.0)

### v1.113.1

**Fixed:**

- Pack source docs no longer list `http://` as an accepted URL scheme — it is rejected to prevent MITM attacks (#914)
- `POST /api/packs/refresh` response docs updated from flat list to current envelope format `{sources, quarantined, quarantine_reason}` (#914)
- Added quarantine lifecycle documentation across pack-sources, troubleshooting, pack-commands, and automatic-updates docs (#914)
- Refresh failure docs corrected: 10 consecutive failures disable the entire background worker, not individual sources (#914)
- Config precedence in troubleshooting docs now includes the `packs`, `space`, and `project` layers (#914)
- Fixed broken changelog link to pack API reference (#914)

See [Pack Sources](../packs/pack-sources.md) for the corrected lifecycle and [Troubleshooting](../packs/troubleshooting.md) for quarantine recovery steps.

[GitHub Release](https://github.com/troylar/anteroom/releases/tag/v1.113.1)

---

## March 12, 2026

### v1.113.0 — Pack Lifecycle Hardening

This release strengthens the pack management system with better failure handling, content change detection, quarantine reporting, and attachment priority support.

#### Content Change Detection for Source Packs

Source-installed packs now detect content changes even when the manifest version hasn't been bumped. The refresh pipeline compares artifact content hashes using the same normalization and hashing as `pack install`, ensuring upstream changes always propagate. (#899)

See [Packs](../packs/how-packs-work.md) for details on pack sources and refresh behavior.

#### Config Rebuild Failure Handling

Pack attach and detach endpoints now handle config rebuild failures correctly: compliance violations roll back the mutation (409), infrastructure errors preserve the mutation and reload registries from DB (200 with warning). Previously, infrastructure errors returned 500 and left registries stale. (#898)

See [Pack API](../packs/api-reference.md) for the full endpoint reference.

#### Quarantine Reporting in Refresh API

The refresh endpoint now returns a structured envelope reporting which packs were quarantined due to compliance violations. Compliance error details are kept server-side to prevent information disclosure. CLI shows matching quarantine warnings. (#900)

See [Packs](../packs/how-packs-work.md) for quarantine behavior.

#### Attachment Priority in Web API

The pack attach endpoint now accepts an optional `priority` field (1-100, default 50), matching the CLI's `--priority` flag. Lower values win for overlapping config overlays. (#901)

See [Packs](../packs/how-packs-work.md) for priority-based conflict resolution.

[GitHub Release](https://github.com/troylar/anteroom/releases/tag/v1.113.0)

### v1.112.0 — Ask the Source

The `/a-help` skill gains source-code awareness — advanced developers can now ask implementation questions, trace call chains, and verify documentation accuracy against the actual running code.

#### Source-Aware `/a-help`

The built-in `/a-help` skill now falls back to inspecting Anteroom's installed source code when documentation doesn't fully answer a question. It uses the new `introspect section=package` capability to locate the source root, then searches and reads relevant code with file and line citations. When docs and source disagree, `/a-help` flags the discrepancy. (#902)

```
/a-help how does the agent loop handle tool call parallelism?
```

See [Skills](../cli/skills.md) for the full skill system documentation.

#### `introspect section=package`

The `introspect` tool gains a new `package` section returning the installed Anteroom source root path and version — a READ-tier building block for AI self-inspection. (#902)

See [Tools](../cli/tools.md) for the introspect tool reference.

[GitHub Release](https://github.com/troylar/anteroom/releases/tag/v1.112.0)

---

## March 11, 2026

### v1.111.0 — Packs That Actually Work

This release stabilizes the entire pack lifecycle — from source refresh through config overlay application to runtime artifact loading. Four interconnected issues, developed and tested as a single integrated unit.

#### Explicit Pack Source Activation

Pack sources now follow clear, predictable semantics: `auto_attach` controls whether newly installed packs are automatically attached, and the refresh worker correctly propagates changed pack IDs through the callback chain. Quarantine on compliance violations detaches offending packs and recovers gracefully. (#872)

See [Pack Sources](../packs/pack-sources.md) for full details.

#### Markdown Rule Metadata Preserved

Pack rules authored in Markdown now retain their YAML front-matter metadata (`enforce: hard`, custom fields) through the full install-attach-enforce pipeline. Previously, metadata was silently dropped during manifest parsing. (#873)

#### Project-Scoped Packs Load at Runtime

Packs attached with `--project` scope now correctly load their artifacts in both the CLI REPL and web UI. The artifact registry receives the resolved `space_id`, ensuring project-scoped pack artifacts appear in the active registry. (#874)

#### Config Overlay Reload and Scoping

Pack config overlays are rebuilt and re-merged on every pack attach, detach, and source refresh — not just at startup. The overlay collection respects attachment scope (global vs project). (#875)

#### Bug Fixes

- Fixed YAML boolean parsing for `auto_attach`: `bool("false")` is `True` in Python (#872)
- Fixed `_reload_after_pack_refresh()` to refresh DLP scanner and injection detector alongside rate limiting (#872)
- Fixed `collect_overlays()` docstring: raises `ComplianceError`, not `ValueError` (#875)

[GitHub Release](https://github.com/troylar/anteroom/releases/tag/v1.111.0)

### v1.110.3

**Fixed:**

- Embedding and reranker models now cache to `data_dir/models/` (default `~/.anteroom/models/`) instead of `/tmp/fastembed_cache/`, surviving reboots and container restarts. Explicit `cache_dir` config enables `local_files_only` mode. (#865)
- Disabled HuggingFace Hub's xet downloader (`HF_HUB_DISABLE_XET=1`) which failed on read-only volumes. Respects user-set values. (#865)

[GitHub Release](https://github.com/troylar/anteroom/releases/tag/v1.110.3)

---

## March 10, 2026

### v1.110.2 — The Prompt Card Fix

Fixes several rendering bugs in the web UI's approval and ask_user prompt cards, plus adds JavaScript unit testing infrastructure.

#### Prompt Card Rendering

Approval and ask_user prompt cards now render in the correct position — directly after the assistant message that triggered them, rather than at the bottom of the chat. Multiple concurrent prompts stack in FIFO order. Both the approval reason and ask_user question render as markdown. (#864)

#### Reconnect Cleanup

When the SSE connection drops and reconnects, pending prompt cards are cleaned up while resolved cards are preserved. A shared `prompt-cleanup.js` module ensures the same logic runs in production and tests. (#864)

#### Enter Key & Race Condition

The ask_user input field now correctly submits on Enter. Cards are marked as resolved immediately before the async API call, preventing a race condition where SSE reconnect could remove a card mid-submission. (#864)

#### JavaScript Unit Testing

Added Vitest + jsdom infrastructure with 13 tests and a `js-test` CI job. (#864)

#### Bug Fixes

- Prompt cards insert after the last assistant message instead of at the container bottom (#864)
- Multiple prompt cards stack in FIFO order (#864)
- Enter key in ask_user input now submits correctly (#864)
- SSE reconnect no longer removes cards being submitted (#864)

[GitHub Release](https://github.com/troylar/anteroom/releases/tag/v1.110.2)

### v1.110.1 — Better Error Messages

When an LLM provider returns a 400-class error, Anteroom now surfaces the provider's actual error message instead of the generic "AI request error", sanitized for safety.

#### Provider Error Surfacing

Previously, provider errors like "the model was unable to complete inference due to an internal error" were discarded in favor of a generic message. Now you see the actual reason — with URLs, API keys, and structured payloads stripped. All three providers (OpenAI, Anthropic, LiteLLM) share a common sanitizer that fails closed to the generic fallback. (#867)

#### Bug Fixes

- Provider 400 errors no longer escape as unhandled 500s with stack traces in the web UI (#867)
- LiteLLM provider now detects "too many tools" errors consistently with OpenAI and Anthropic (#867)

[GitHub Release](https://github.com/troylar/anteroom/releases/tag/v1.110.1)

### v1.110.0 — Sources Remember

RAG source provenance is now persisted with messages, so resuming a conversation preserves full attribution of which documents and prior chats informed each response.

#### Persistent RAG Source Provenance

Previously, RAG source badges were ephemeral — visible during streaming but lost on resume. Now, when the RAG pipeline retrieves context, that metadata is saved with the assistant's message. Resuming a conversation in either the web UI or CLI shows the same "knowledge" and "conversation" badges that appeared during the original session. The schema migration is automatic, including for databases that went through the earlier `messages_repaired` path. (#822)

See [How RAG Works](../knowledge/how-rag-works.md) for details on the retrieval pipeline and provenance display.

[GitHub Release](https://github.com/troylar/anteroom/releases/tag/v1.110.0)

---

## March 9, 2026

### v1.109.0 — Source Scope Awareness

Anteroom's knowledge pipeline becomes more transparent — you now see exactly which sources are in scope, which are excluded, and how RAG retrieval is performing.

#### Source Scope Exclusion Feedback

When a space is active and sources are referenced by tag or group, Anteroom now shows which sources were excluded because they aren't linked to the current space. The web UI dims out-of-scope sources, displays scope counts in tag pickers and group details, and shows confirmation dialogs before attaching partially-scoped groups. The chat stream emits a toast when exclusions occur. (#853)

See [Knowledge Management](../knowledge/index.md) for details on spaces and source scoping.

#### Live RAG Status Feedback

RAG retrieval status is surfaced in real-time across both interfaces. The CLI shows muted status lines (`[RAG: 5 relevant chunk(s) retrieved]`), silent for non-actionable states. Source badges now use clearer labels: "knowledge" for documents and "conversation" for message history. (#854)

See [CLI Reference](../cli/index.md) for the RAG status display.

[GitHub Release](https://github.com/troylar/anteroom/releases/tag/v1.109.0)

### v1.108.1

**Fixed:**

- CLI approval prompt options (`[y] Allow once`, `[s] Allow for session`, etc.) are now visible before the user needs to type a response. Three root causes addressed: `write_raw()` text overwritten on redraw, tool elapsed-time ticker overwriting the prompt area, and `in_terminal()` being a no-op from the agent runner task. (#849)

See [Tool Safety](../security/tool-safety.md) for the approval flow and [CLI Guide](../cli/index.md) for REPL usage.

[GitHub Release](https://github.com/troylar/anteroom/releases/tag/v1.108.1)

### v1.108.0 — Leaner Help, Smarter Matching

The built-in `/a-help` skill gets a major diet and learns to answer questions without being asked directly.

#### Slimmed Help Skill

The `a-help` skill prompt dropped from 48KB to 11KB — a 77% reduction. High-frequency quick-reference tables stay inline; detailed reference delegates to docs pages via `read_file`. A 15KB size budget test prevents future bloat. (#845)

See [Skills](../cli/skills.md) for how built-in skills work.

#### Auto-Invocation for Anteroom Questions

The skill description was broadened so the AI automatically recognizes natural Anteroom questions and invokes `a-help` without requiring the explicit `/a-help` prefix. Works through the existing `invoke_skill` auto-invocation mechanism — no shared code changes. (#845)

See [Skills](../cli/skills.md) for details on skill auto-invocation.

[GitHub Release](https://github.com/troylar/anteroom/releases/tag/v1.108.0)

### v1.107.2 — Porting Docs for Claude Code Users

Clear guidance for users bringing Claude Code command files into Anteroom skills — format differences, tool name mapping, sub-agent migration patterns, and common gotchas.

#### Claude Code Porting Guide

New documentation page explaining how to convert `.claude/commands/*.md` files (Markdown with YAML frontmatter) into Anteroom YAML skills. Covers field mapping, tool name mapping (Read to read_file, Agent to run_agent, etc.), and four documented "gotchas" that silently fail when porting without changes. (#843)

See [Porting from Claude Code](../cli/porting-from-claude-code.md) for the full migration guide.

#### Skill Examples Catalog

Five complete, ready-to-use YAML skill examples: simple bash workflows with `{args}`, parallel sub-agent orchestration, codebase exploration, sequential deploy checklists, and security audits with model overrides. (#843)

See [Skill Examples](../cli/skill-examples.md) for all examples and authoring tips.

[GitHub Release](https://github.com/troylar/anteroom/releases/tag/v1.107.2)

### v1.107.1

**Fixed:**

- Sources list endpoint now fetches embedding statuses in a single batch query instead of 2N queries per request — significant performance improvement for large source libraries. (#844)
- Embedding status now correctly filters by `status = 'embedded'`, so sources with skipped or failed embeddings are no longer falsely reported as fully embedded. (#844)
- Sources list gracefully degrades to `"unknown"` status if embedding tables are unavailable, instead of failing the entire request. (#844)

[GitHub Release](https://github.com/troylar/anteroom/releases/tag/v1.107.1)

## March 8, 2026

### v1.107.0 — Knowledge Pipeline That Tells You What Went Wrong

Anteroom's knowledge source pipeline used to fail silently. This release makes it fail loudly, surface warnings, and support recovery.

#### Source Pipeline Warning Propagation

Every text extractor now returns an `ExtractionResult` with both text and warnings. Missing dependency? The warning tells you what to install. Warnings flow through the entire pipeline to both web UI and CLI. (#832)

#### Source Recovery with `/reprocess`

Install a missing dependency after uploading? No need to re-upload. Use `/reprocess <source_id>` or `/reprocess all` in the CLI, or click "Reprocess" in the web UI source detail view. Re-extracts text, rebuilds chunks, and kicks off embedding. (#832)

#### Embedding Status Visibility

Sources API now includes `embedding_status` on every source (`embedded`, `partial`, `pending`, or `no_chunks`). Displayed in the web UI source detail view. (#832)

#### RAG Diagnostics

`retrieve_context()` returns a reason string when no results are found. CLI shows `[RAG: no results — <reason>]`, web UI includes it in prompt metadata. (#832)

#### Knowledge Dependency Health Check

`aroom --test` checks for optional knowledge pipeline dependencies and reports which are missing with correct install commands. (#832)

[GitHub Release](https://github.com/troylar/anteroom/releases/tag/v1.107.0)

### v1.106.2

**Fixed:**

- RAG vector index sync race on upload — newly uploaded sources were invisible to semantic search until restart because `embed_source()` never flushed vectors to disk. Now centralizes `save_all()` inside `embed_source()` for all callers. Mid-session repair sweeps metadata to re-queue any stale entries. (#834)
- CLI `/upload` now embeds inline, matching the web UI's behavior. Extracted `_embed_after_upload()` helper fails gracefully with background worker retry. (#834)

[GitHub Release](https://github.com/troylar/anteroom/releases/tag/v1.106.2)

### v1.106.1

**Fixed:**

- `/space link-source` and `/space unlink-source` now disambiguate when multiple sources share the same title, showing candidates with truncated IDs instead of silently failing (#833)
- Web UI sources panel uncapped from 100 to unlimited (`limit=0`) so large knowledge bases display all sources (#833)
- Fixed `UnboundLocalError` crash in `/space link-source` when matching by title — missing import of `get_direct_space_source_links` (#833)

[GitHub Release](https://github.com/troylar/anteroom/releases/tag/v1.106.1)

### v1.106.0 — Offline-Ready Embeddings

Anteroom's local embedding and reranking models are now fully usable in air-gapped environments, and keyword retrieval works correctly without an embedding service.

#### Vendored Model Cache

Both the embedding service and the reranker service now accept a `cache_dir` config field. When set, models load from that directory with `local_files_only` mode enabled — fastembed fails fast instead of attempting network requests. Pre-download models once on a connected machine, copy the directory, and configure the path. (#825)

```yaml
embeddings:
  provider: "local"
  cache_dir: "/opt/anteroom/models"
reranker:
  cache_dir: "/opt/anteroom/models"
```

See [Configuration Reference](../knowledge/config-reference.md) for all embedding and reranker config options.

#### Keyword RAG Without Embeddings

The chat entrypoints previously required an active embedding service before calling RAG, even for keyword or hybrid modes that don't need embeddings. Keyword-only search now works correctly without fastembed installed. (#825)

See [How RAG Works](../knowledge/how-rag-works.md) for retrieval mode details.

#### Documentation

Comprehensive updates to RAG and knowledge documentation covering hybrid retrieval, cross-encoder reranking, and the new `cache_dir` config. (#827)

[GitHub Release](https://github.com/troylar/anteroom/releases/tag/v1.106.0)

### v1.105.0 — Rules That Bite

Security rules that ship with Anteroom should actually stop dangerous code — not just warn about it. This release fixes the security-baseline pack so its rules block writes containing `eval()`, hardcoded secrets, and SQL injection, adds a new way to exclude tools without bypassing the approval gate, and squashes two CLI annoyances.

#### Rule Enforcement Now Covers File Writes

The built-in security-baseline pack (no-eval, parameterized-queries, no-hardcoded-secrets) previously only checked bash commands. The rule enforcer now inspects file content for `write_file` and `new_text` for `edit_file`, so rules like "no `eval()` in source files" and "no hardcoded `api_key = ...`" actually fire. The `yaml.load()` rule now distinguishes `SafeLoader` from unsafe loaders. (#819)

See [Tool Safety](../security/tool-safety.md) for details on rule enforcement.

#### `--denied-tools` Flag

The new `--denied-tools` flag hard-blocks tools without the auto-approval side effect of `--allowed-tools`. Denied takes priority over allowed. Also available in config as `safety.denied_tools`. (#820)

```bash
aroom chat --denied-tools bash,run_agent
```

See [CLI documentation](../cli/index.md) for all flags.

#### Bug Fixes

- Line repetition detection now stops mid-stream at the threshold instead of consuming the entire response first (#821)
- Thinking spinner clears before tool approval prompts in the CLI (#823)

[GitHub Release](https://github.com/troylar/anteroom/releases/tag/v1.105.0)

### v1.104.0 — Smarter Retrieval

Anteroom's RAG pipeline now includes an optional cross-encoder reranking stage that significantly improves the relevance of retrieved context.

#### Cross-Encoder Reranker

The RAG pipeline previously relied solely on embedding similarity to rank retrieved chunks. Cross-encoder reranking adds a second stage: after initial retrieval fetches a broad candidate set, a cross-encoder model scores each candidate against the query directly, producing much more accurate relevance judgments. (#811)

```yaml
reranker:
  enabled: null    # auto-detect (uses fastembed if available)
  top_k: 5         # keep top-5 after reranking
  candidate_multiplier: 3  # fetch 3x candidates for reranking
```

Runs locally via fastembed's `TextCrossEncoder` — no external API needed. Auto-detects on startup and degrades gracefully.

See [Configuration Reference](../knowledge/config-reference.md) for all reranker settings.

[GitHub Release](https://github.com/troylar/anteroom/releases/tag/v1.104.0)

### v1.103.0 — Search Gets Smarter

Anteroom's RAG pipeline gains a hybrid retrieval mode that combines keyword search (FTS5) with dense vector search, merging results via Reciprocal Rank Fusion for better context quality.

#### Hybrid Search with Reciprocal Rank Fusion

The RAG pipeline now supports three retrieval modes: `dense` (vector similarity, the default), `keyword` (FTS5 full-text search), and `hybrid` (both, merged via RRF). Hybrid mode runs both search backends in parallel, ranks each result set independently, then combines them using reciprocal rank fusion with k=60. Results that appear in both lists get a natural relevance boost. (#810)

```yaml
rag:
  retrieval_mode: hybrid  # dense | keyword | hybrid
```

The keyword mode works without any embedding service — useful when fastembed isn't available or embeddings are disabled. Hybrid mode degrades gracefully to keyword-only when embedding fails.

See [Knowledge & RAG](../knowledge/index.md) for full documentation and [How RAG Works](../knowledge/how-rag-works.md) for the pipeline walkthrough.

#### FTS5 Full-Text Search Infrastructure

SQLite FTS5 virtual tables with Porter stemming now index both messages and source chunks automatically via INSERT/UPDATE/DELETE triggers. Existing databases are migrated and backfilled transparently on startup. Space-scoped keyword search filters at the SQL level to prevent limit starvation. (#810)

[GitHub Release](https://github.com/troylar/anteroom/releases/tag/v1.103.0)

---

## March 7, 2026

### v1.102.0 — Faster, Simpler Vector Search

Anteroom's RAG pipeline now uses usearch instead of sqlite-vec for vector similarity search, eliminating a C extension that was difficult to install on many platforms.

#### Usearch Vector Engine

The vector search backend has been completely rewritten. Two persistent usearch indexes handle nearest-neighbor search with cosine similarity, while SQLite metadata tables remain the source of truth. Cross-platform installation, crash recovery with per-key verification, iterative widening for space-scoped search, and automatic rollback on failure. (#778)

```yaml
rag:
  max_chunks: 10
  similarity_threshold: 0.5
  max_tokens: 2000
```

See [Knowledge & RAG](../knowledge/index.md) for full documentation and [How RAG Works](../knowledge/how-rag-works.md) for the pipeline walkthrough.

#### Knowledge & RAG Documentation

A new top-level documentation section explains the complete RAG pipeline: embedding, retrieval, defensive wrapping, and space scoping. (#778)

See [Knowledge & RAG Overview](../knowledge/index.md), [Sources](../knowledge/sources.md), [Configuration](../knowledge/config-reference.md), and [API Reference](../knowledge/api-reference.md).

[GitHub Release](https://github.com/troylar/anteroom/releases/tag/v1.102.0)

### v1.101.1

**Fixed:**

- CSP violation silently blocking the theme initialization script. The SHA-256 hash in `script-src` didn't match the inline script content. Moved to an external file (`theme-init.js`) so `'self'` covers it without a fragile hash. (#739)

[GitHub Release](https://github.com/troylar/anteroom/releases/tag/v1.101.1)

### v1.101.0 — First Steps That Work

New users used to land on a blank chat screen with no guidance. Now both the web UI and CLI greet them with clear, actionable next steps.

#### Task-Based Web Onboarding

The web UI's empty state has been replaced with three action cards that directly do what they describe. "Start chatting" focuses the message input. "Configure your model" opens the settings modal. "Create a space" triggers the workspace creation flow. Keyboard shortcuts are shown inline so new users discover them immediately. (#795)

See [Web UI documentation](../web-ui/index.md) for the full interface guide.

#### CLI First-Run Guidance

The CLI REPL now detects first-run sessions and displays a structured getting-started block with three key commands: just type to chat, `/space init` for workspace setup, and `/help` for the full command reference. Returning users see a compact one-line hint instead. (#798)

```
Getting started:
  Just type a message to start chatting
  /space init   — set up a workspace with custom instructions
  /help         — see all commands
```

See [CLI documentation](../cli/index.md) for REPL usage details.

[GitHub Release](https://github.com/troylar/anteroom/releases/tag/v1.101.0)

### v1.100.2 — Clearer First Steps

This release overhauls Anteroom's onboarding documentation so new users understand what the tool does for them before encountering advanced concepts like packs, artifacts, and precedence layers.

#### README Restructured Around Outcomes

The README now leads with three concrete user jobs — secure chat, real work with agentic tools, and shared team conventions — before diving into enterprise governance. Packs and spaces are introduced as optional power features rather than required concepts. (#793)

#### Start Here Guide

A new top-level "Start Here" page routes first-time users into one of three guided paths: chat securely, use an AI coding assistant, or share team conventions. Each path links to no more than three follow-up pages. (#794)

See [Start Here](../start-here.md) in the docs.

#### Packs and Spaces Docs Reframed

Both packs and spaces documentation now answer "why would I use this?" before explaining YAML schemas and architecture. The packs quickstart leads with installing an existing pack before teaching how to create one. (#797, #796)

See [Packs](../packs/index.md) and [Spaces](../spaces/index.md) for the reframed docs.

#### Bug Fixes

- Fixed ASVS compliance level incorrectly stated as L1 in three doc pages (#792)
- Renamed `projects.md` to `spaces.md` in web-ui and API docs, added URL redirects (#792)

[GitHub Release](https://github.com/troylar/anteroom/releases/tag/v1.100.2)

### v1.100.1 — Spaces Get Smarter

This patch release strengthens how Anteroom manages pack artifacts and space selections — two areas where subtle bugs could cause unexpected behavior in multi-space workflows.

#### Attachment-Aware Artifact Registry

The artifact registry now filters by pack attachment state when loading from the database. Previously, unattached pack artifacts could leak into the active registry. Now only artifacts from attached packs (or standalone artifacts) are visible, and each space sees only its own scoped packs. (#788)

See [How Packs Work](../packs/how-packs-work.md) for the full artifact lifecycle and [Spaces Concepts](../spaces/concepts.md) for space-scoped registry behavior.

#### Concurrent Request Safety

The web UI now passes `rule_enforcer_override` through the tool execution path instead of mutating shared state, eliminating a race condition where concurrent requests in different spaces could see each other's rule enforcers. (#788)

#### Space Selection Persists Across Reloads

The web UI saves your selected space to `sessionStorage` and restores it on page reload. If the saved space was deleted, the UI gracefully falls back to "All Spaces." (#745)

[GitHub Release](https://github.com/troylar/anteroom/releases/tag/v1.100.1)

---

## March 6, 2026

### v1.100.0 — Packs That Enforce

This release is all about packs. The pack system graduates from "bundle of artifacts" to a real policy enforcement layer — packs can now define rules that the AI **cannot** bypass, skills resolve cleanly when multiple packs collide, and exec mode finally gets the same pack-powered experience as the interactive REPL.

#### Hard Rule Enforcement

Packs can now include rules with `enforce: hard` metadata. Hard rules are checked on every tool call — before the safety config is even consulted. If safety is disabled, hard rules still fire. This means a team pack like `ops-guardrails` can block production database writes or destructive shell commands regardless of what the user configures locally. (#773)

```yaml
# In a pack rule artifact
name: no-prod-writes
enforce: hard
match_tools: [bash]
pattern: "psql.*production"
reason: "Production database writes require a change ticket"
```

See [Artifact Types — Rules](../packs/artifact-types.md) for the full rule schema and [How Packs Work — Phase 5: Enforce](../packs/how-packs-work.md) for the enforcement lifecycle.

#### Additive Skills with Namespace Resolution

Previously, if two packs defined a skill with the same name, attach failed with an error. Now all non-config artifact types — skills, rules, instructions, context, memory, MCP servers — are **additive** across packs. When skill names collide, they're displayed with namespace-qualified names (e.g., `ops/deploy` vs `dev/deploy`) so you can tell them apart. No more conflicts, no more "first pack wins." (#770)

See [Artifact Types](../packs/artifact-types.md) for the full list of additive types and [Pack Commands — Conflict Detection](../packs/pack-commands.md) for how conflicts are surfaced at attach time.

#### Exec Mode Parity

`aroom exec` was missing pack support entirely — no artifact injection, no rule enforcement. Now exec mode loads the full artifact registry and rule enforcer, injects instruction/rule/context artifacts into the system prompt, and enforces hard rules on every tool call. Scripts and CI pipelines get the same safety guarantees as interactive sessions. (#777)

See [CLI — Exec Mode](../cli/index.md) for usage details.

#### Example Packs

Three new example packs ship with Anteroom to help you get started:

- **code-review** — skills and rules for structured code review workflows
- **writing-assistant** — instructions and context for document drafting
- **strict-safety** — hard rules that lock down destructive operations

Install with `aroom pack install --name code-review`. See the [Quickstart](../packs/quickstart.md) to get up and running, or browse the [Manifest Format](../packs/manifest-format.md) to create your own. (#770)

#### Bug Fixes

- Skills from packs now appear in `/skills` immediately after install — no restart needed (#770)
- Fixed `NameError: '_artifact_registry'` crash after running `/pack install` in the REPL (#771)
- Pack reinstall no longer creates duplicate database entries — existing packs are updated in place (#772)
- Pack attachments are preserved during pack updates (#770)
- Orphan artifact detection runs inside a DB transaction to prevent TOCTOU races (#770)
- Router regex for pack namespace/name validation aligned with manifest parser (#770)

See [Troubleshooting](../packs/troubleshooting.md) for common pack issues and [Health Check](../packs/health-check.md) to diagnose artifact conflicts.

[GitHub Release](https://github.com/troylar/anteroom/releases/tag/v1.100.0)

### v1.99.2

**Fixed:**

- API errors returning HTML pages (502 gateway errors, misconfigured base URLs) now show clean, actionable messages instead of raw HTML (#784)

[GitHub Release](https://github.com/troylar/anteroom/releases/tag/v1.99.2)

### v1.99.1

**Fixed:**

- Stall detection now catches slow-trickle streams via rolling throughput window (#774)
- Thinking ticker no longer freezes during slow API responses (#775)
- Stream timeout warnings display cleanly instead of raw log lines (#776)

[GitHub Release](https://github.com/troylar/anteroom/releases/tag/v1.99.1)

---

## March 5, 2026

### v1.99.0

**New:**

- Install packs from git URLs: `aroom pack install https://github.com/org/repo --attach` (#762)
- Zero-config onboarding: pack config overlays provide required settings, skipping the init wizard (#762)
- Priority-based conflict resolution for pack config overlays with `--priority` flag (#762)
- `aroom config view --with-sources` shows which layer set each config key (#759)

[GitHub Release](https://github.com/troylar/anteroom/releases/tag/v1.99.0)

### v1.98.2

**Improved:**

- Removed 5 unused runtime dependencies, reducing install footprint and supply chain surface (#763)

[GitHub Release](https://github.com/troylar/anteroom/releases/tag/v1.98.2)

### v1.98.1

**Fixed:**

- Paste (right-click, ctrl-v, cmd-v) now works correctly in the CLI prompt (#754)

**Improved:**

- Simplified CLI architecture: removed full-screen layout in favor of scrolling console output with anchored prompt (#754)
- Git branch refreshes in the toolbar during sessions; interactive sub-prompts have a 5-minute timeout (#754)

[GitHub Release](https://github.com/troylar/anteroom/releases/tag/v1.98.1)

---

## March 4, 2026

### v1.98.0

**New:**

- Built-in `/excalidraw` skill for creating interactive diagrams rendered live in the web UI canvas panel (#751)

**Fixed:**

- Streaming stability: hard tool timeouts, Anthropic provider cancel-aware streams, EventBus retry-with-backoff (#751)
- SSE task leak on client disconnect, postMessage wildcard origins, page lifecycle stream cleanup (#751)

[GitHub Release](https://github.com/troylar/anteroom/releases/tag/v1.98.0)

### v1.97.0

**New:**

- `aroom start` now shows real-time startup progress with a Rich spinner instead of a silent wait (#746)
- Refreshed logo branding across CLI and web UI with triangle/doorway motif (#747)

**Improved:**

- Extracted inline styles to CSS classes for cleaner HTML (#747)

[GitHub Release](https://github.com/troylar/anteroom/releases/tag/v1.97.0)

### v1.96.0

**New:**

- Spaces are now the universal workspace primitive — Projects have been completely removed and replaced by Spaces with full CRUD in both web UI and CLI (#716)
- Export any space to YAML with `aroom space export` for git-committable workspace configuration (#716)
- DB-authoritative with file sync — spaces created anywhere (UI, CLI, YAML) converge in the database (#716)

**Improved:**

- Safe automatic migration converts existing projects to spaces, preserving all conversations and folders (#716)
- Net code reduction: ~1050 lines removed while adding full space CRUD parity (#716)

[GitHub Release](https://github.com/troylar/anteroom/releases/tag/v1.96.0)

### v1.95.1

**Fixed:**

- Rate limiter/EventSource reconnection storm — SSE endpoint now exempt from rate limiting, preventing cascading 429 failures that froze the web UI (#740)
- Added `Retry-After` header to 429 responses and SSE `retry:` field for browser-controlled reconnection intervals (#740)

[GitHub Release](https://github.com/troylar/anteroom/releases/tag/v1.95.1)

---

## March 3, 2026

### v1.95.0

**New:**

- Streaming watchdog with auto-recovery — web UI no longer hangs on infinite spinner when server stops responding (#737)
- Debug diagnostic mode for both interfaces: `?debug=1` for web UI, `--debug` for CLI (#737)

**Fixed:**

- Role labels in web UI: assistant messages now show "ANTEROOM" instead of "SYSTEM" (#737)
- "New Chat" button failing silently when server is unavailable (#737)

[GitHub Release](https://github.com/troylar/anteroom/releases/tag/v1.95.0)

### v1.94.7

**New:**

- Ctrl-S toggle for mouse mode in CLI fullscreen — switch between scroll mode and native text selection (#736)

[GitHub Release](https://github.com/troylar/anteroom/releases/tag/v1.94.7)

### v1.94.6

**Fixed:**

- Database migration crash on startup for users upgrading from older versions (#734)
- Auto-repair for corrupted FK references caused by v1.94.4 migration (#734)
- Mouse scroll wheel in CLI now scrolls conversation output instead of terminal scrollback (#735)

[GitHub Release](https://github.com/troylar/anteroom/releases/tag/v1.94.6)

### v1.94.5

**Fixed:**

- AI now reads extracted content from attached files directly instead of calling file tools (#731)
- Attachment filenames sanitized against prompt injection (#731)

[GitHub Release](https://github.com/troylar/anteroom/releases/tag/v1.94.5)

### v1.94.4

**Fixed:**

- Message action buttons (edit, fork, retry, copy, delete) now appear on sent and streamed messages in the web UI (#725)
- Race condition in rapid message sending that could misattach action buttons to wrong messages (#725)
- Attachment filename sanitization and untrusted zone storage to prevent path traversal (#731)
- AI ignoring extracted attachment content and calling tools instead (#731)

[GitHub Release](https://github.com/troylar/anteroom/releases/tag/v1.94.4)

### v1.94.3

**Fixed:**

- Binary file attachments (PPTX, XLSX, PDF, DOCX) no longer silently drop from AI context (#727)
- Added PPTX and XLSX text extraction for file uploads and CLI `@file` references (#727)
- Unextractable binary files now show a fallback note instead of being silently ignored (#727)

[GitHub Release](https://github.com/troylar/anteroom/releases/tag/v1.94.3)

### v1.94.2

**Fixed:**

- File upload on Windows now shows extensions and filters correctly in the file dialog (#722)
- Page refresh on Windows no longer hangs due to SSE connection pool exhaustion (#723)

[GitHub Release](https://github.com/troylar/anteroom/releases/tag/v1.94.2)

### v1.94.1

**Fixed:**

- Console window no longer flashes on Windows during background server operation (#720)

[GitHub Release](https://github.com/troylar/anteroom/releases/tag/v1.94.1)

### v1.94.0

**New:**

- Background server management: `aroom start`, `aroom stop`, `aroom status` — run the web UI without keeping a terminal open (#718)

[GitHub Release](https://github.com/troylar/anteroom/releases/tag/v1.94.0)

---

## March 2, 2026

### v1.93.2

**Fixed:**

- RAG vector search now respects space and project boundaries — no more cross-tenant context leakage (#709)
- Embedding worker recovers from transient failures; edited messages properly re-embedded (#710)
- Source file creation is atomic with consistent content-hash dedup and orphan cleanup (#711)
- RAG status feedback in both web UI (toasts) and CLI (inline status) (#712)
- Multi-file source upload capped at 20 with user feedback (#712)

[GitHub Release](https://github.com/troylar/anteroom/releases/tag/v1.93.2)

### v1.93.1

**Fixed:**

- 18 artifact ecosystem bugs across CLI, API, and web UI — wrong DB references, missing imports, unprotected endpoints, N+1 queries (#708)
- CLI `artifact delete` now blocks built-in artifacts; invalid filters return clean errors (#708)
- Pack delete via API refreshes artifact registry; space create/init rejects duplicates (#708)

[GitHub Release](https://github.com/troylar/anteroom/releases/tag/v1.93.1)

### v1.93.0

**New:**

- Skill support in web UI — skills can now be invoked during web chat, matching CLI behavior (#698)
- Artifact & pack browser panel in web UI with type/source filtering and inline delete (#700)
- `/artifact` and `/space clone/map` REPL commands for CLI artifact management (#702)
- Skill-artifact bridge — skills stored as artifacts auto-load into the skill registry (#699)

**Fixed:**

- Pack install now sets correct artifact source (GLOBAL vs PROJECT) based on context (#703)
- Prompt injection vulnerability in skill argument expansion (#698)
- `invoke_skill` tool silently dropped when exceeding max tool count (#698)
- Pack removal wrapped in transaction for atomicity (#704)

**Improved:**

- Deduplicated pack disambiguation logic in REPL (#706)
- Added `/instructions` alias and terminology clarifications (#701)

[GitHub Release](https://github.com/troylar/anteroom/releases/tag/v1.93.0)

### v1.92.0

**New:**

- Multi-provider support via LiteLLM — connect to 100+ LLM providers including OpenRouter, Together AI, Replicate, Cohere, and AWS Bedrock (#696)
- OpenRouter preset added to setup wizard (`aroom init`) (#696)
- AWS Bedrock support with native IAM/SSO/role-based auth — no API key needed (#696)

[GitHub Release](https://github.com/troylar/anteroom/releases/tag/v1.92.0)

### v1.91.0

**New:**

- Native Anthropic/Claude API provider — connect directly without an OpenAI-compatible proxy (#694)
- Anthropic (Claude) option added to `aroom init` setup wizard (#694)

[GitHub Release](https://github.com/troylar/anteroom/releases/tag/v1.91.0)

### v1.90.3

**Fixed:**

- Token usage now correctly persisted to the database after streaming responses (#689)
- Duplicate database names properly rejected with 409 error (#689)
- `aroom usage` command fixed — was using incorrect database path (#689)
- Destructive command detection now catches separated flags like `rm -v -r -f /` (#689)

**Improved:**

- 948 new unit tests added, bringing total from ~4,900 to 5,800+ (#689)

[GitHub Release](https://github.com/troylar/anteroom/releases/tag/v1.90.3)

### v1.90.2

**Fixed:**

- LLM degenerate output (same line repeated dozens of times in one response) is now detected and stopped after 5 repeats — configurable via `cli.max_line_repeats` (#691)

[GitHub Release](https://github.com/troylar/anteroom/releases/tag/v1.90.2)

### v1.90.1

**Fixed:**

- "Session expired. Could not recover automatically" banner no longer appears incorrectly on fresh page loads when multiple API calls hit 401 simultaneously (#687)

[GitHub Release](https://github.com/troylar/anteroom/releases/tag/v1.90.1)

### v1.90.0

**New:**

- Local-first space creation: `space create` writes `.anteroom/space.yaml` in your project directory by default (#686)
- `space init` derives space name from directory name for zero-argument setup (#686)
- `space list` shows origin (local/global), conversation count, and active indicator (#686)

[GitHub Release](https://github.com/troylar/anteroom/releases/tag/v1.90.0)

---

## March 1, 2026

### v1.89.8

**Fixed:**

- Agent loop no longer gets stuck spamming text-only responses — stops after 3 consecutive text-only turns with no tool calls (#679)

[GitHub Release](https://github.com/troylar/anteroom/releases/tag/v1.89.8)

### v1.89.7

**Fixed:**

- CLI fullscreen streaming errors (timeouts, retries, connection failures) no longer corrupt the prompt area — log output is now routed through the layout's output pane (#678)

[GitHub Release](https://github.com/troylar/anteroom/releases/tag/v1.89.7)

### v1.89.6

**Fixed:**

- Complete fix for CLI spacing between tool call output and AI narration text — v1.89.5 only covered mid-turn narration; this fixes the main streaming path (#680)

[GitHub Release](https://github.com/troylar/anteroom/releases/tag/v1.89.6)

### v1.89.5

**Fixed:**

- Added visual spacing between tool call checkmarks and narration text in CLI output (#680)

[GitHub Release](https://github.com/troylar/anteroom/releases/tag/v1.89.5)

### v1.89.4

**Fixed:**

- Fixed persistent "Session expired" banner when using web UI locally on macOS — IPv4/IPv6 loopback mismatch no longer invalidates sessions (#675)

[GitHub Release](https://github.com/troylar/anteroom/releases/tag/v1.89.4)

### v1.89.3

**Fixed:**

- Multiline input now grows dynamically in CLI fullscreen mode — input area expands up to 10 rows as you type (#669)
- Removed kitty protocol activation that caused Ctrl+C to output garbage in iTerm2 (#669)

[GitHub Release](https://github.com/troylar/anteroom/releases/tag/v1.89.3)

### v1.89.2

**Fixed:**

- Fixed `aroom chat` hanging when run from non-project directories like `~` — codebase index now checks for project markers before scanning (#672)

[GitHub Release](https://github.com/troylar/anteroom/releases/tag/v1.89.2)

### v1.89.1

**Fixed:**

- Fixed CLI fullscreen markdown double-spacing on Windows Git Bash — Rich line padding caused visual wrapping in narrower panes (#670)

[GitHub Release](https://github.com/troylar/anteroom/releases/tag/v1.89.1)

### v1.89.0

**New:**

- Knowledge notebooks: conversations now support `note` and `document` types beyond chat (#83)
- Type-aware semantic and keyword search with `?type=` filter in API, CLI, and web UI (#83)
- Web UI type picker dropdown and sidebar type badges for visual distinction (#83)
- RAG context labels retrieved chunks with `[note]`/`[doc]` type badges (#83)

[GitHub Release](https://github.com/troylar/anteroom/releases/tag/v1.89.0)

### v1.88.3

**Improved:**

- Added UX testing rule and integrated coverage checks into `/new-issue`, `/start-work`, `/submit-pr`, `/code-review` (#665)
- Rewrote VISION.md with enterprise server-mode positioning and phased ROADMAP.md (#665)

[GitHub Release](https://github.com/troylar/anteroom/releases/tag/v1.88.3)

### v1.88.2

**Fixed:**

- Fixed double-spaced Markdown output on Windows Git Bash (#658)

[GitHub Release](https://github.com/troylar/anteroom/releases/tag/v1.88.2)

### v1.88.1

**Improved:**

- Fixed all 499 mypy type-check errors across 43 files for better code quality and IDE support (#610)
- Fixed Starlette compatibility issue with 204 endpoints that broke test collection on newer versions (#610)

[GitHub Release](https://github.com/troylar/anteroom/releases/tag/v1.88.1)

### v1.88.0

**New:**

- Bug Hunter agent added to `/submit-pr` and `/deploy` — deep correctness scan that fixes every issue automatically (#636)
- License changed from MIT to Apache 2.0 for stronger patent protection (#636)

**Improved:**

- README messaging refreshed to align with landing page; test count updated to 4,800+ (#636)

[GitHub Release](https://github.com/troylar/anteroom/releases/tag/v1.88.0)

### v1.87.0

**New:**

- Fullscreen streaming pipeline with checkpoint-based rendering for clean Markdown output (#608)
- Live plan checklist renders in-pane with step-by-step updates during agentic runs (#608)

**Fixed:**

- Duplicate output in fullscreen mode where raw text appeared alongside rendered Markdown (#608)
- Plan checklist corruption during concurrent streaming and plan updates (#608)
- Dead flush ticker removed — was consuming CPU without effect (#608)

[GitHub Release](https://github.com/troylar/anteroom/releases/tag/v1.87.0)

---

## February 28, 2026

### v1.86.0

**New:**

- Fullscreen visual polish: turn separators, streaming cursor, scroll indicator, approval mode prompt colors (#619)
- Tool calls render as compact single-line results, parallel-safe (#619)

**Fixed:**

- Conversation context bleed — previous turn's AI response missing from history (#619)
- Parallel tool call rendering, elapsed times, and summaries now correct (#619)

[GitHub Release](https://github.com/troylar/anteroom/releases/tag/v1.86.0)

### v1.85.2

**Fixed:**

- 15 fullscreen layout bugs: exit handling, input race conditions, Ctrl+C, stale header state, rendering (#617)

[GitHub Release](https://github.com/troylar/anteroom/releases/tag/v1.85.2)

### v1.85.1

*Maintenance release — bumped 14 direct dependency version floors to address known CVEs and stay current (#611).*

[GitHub Release](https://github.com/troylar/anteroom/releases/tag/v1.85.1)

### v1.85.0

**New:**

- PPTX read now shows paragraph structure (level, bold, size) for multi-paragraph shapes and table cells (#605)

**Fixed:**

- COM backend auto-reconnects when Office drops the RPC connection between tool calls (#603)
- `shape_edits` description warns about paragraph destruction and directs to `paragraph_edits` (#605)

[GitHub Release](https://github.com/troylar/anteroom/releases/tag/v1.85.0)

### v1.84.2

**Fixed:**

- PPTX table edit skip diagnostics now show the actual keys the AI sent, exposing key name mismatches (#599)

[GitHub Release](https://github.com/troylar/anteroom/releases/tag/v1.84.2)

### v1.84.1

**Fixed:**

- PPTX edit operations now report why entries were skipped instead of silently returning zero edits (#599)

[GitHub Release](https://github.com/troylar/anteroom/releases/tag/v1.84.1)

### v1.84.0

**New:**

- 5 new PPTX edit features: template fill (`{{key}}` replacement), table formatting, paragraph edits, placeholder edits by type name, and image replacements — all working in both lib and COM backends (#597)

**Improved:**

- Resource exhaustion prevention with `_MAX_EDIT_OPS = 500` cap on all array-based edit parameters (#597)

[GitHub Release](https://github.com/troylar/anteroom/releases/tag/v1.84.0)

### v1.83.5

**Fixed:**

- COM objects no longer disconnect between read and edit operations — fixes "object is not connected to server" error (#595)

[GitHub Release](https://github.com/troylar/anteroom/releases/tag/v1.83.5)

### v1.83.4

**Fixed:**

- COM (Windows Office) operations now report actual error messages instead of opaque "Unable to read file" messages, making corporate security policy blocks diagnosable (#593)

[GitHub Release](https://github.com/troylar/anteroom/releases/tag/v1.83.4)

## February 27, 2026

### v1.83.0

**New:**

- 47 new Office tool actions: Word (track changes, comments, headers/footers, styles, find-regex, and more), Excel (formatting, charts, named ranges, data validation, conditional formatting, and more), PowerPoint (shapes, images, tables, hyperlinks, slide management, and more) (#589)
- COM backend for Windows with native Office automation — PDF export, pivot tables, transitions, animations, and other COM-only features (#588)
- New `anteroom[office-com]` install option for full Windows COM backend support (#588)

**Fixed:**

- DDE formula injection protection on COM cell writes (#589)
- ReDoS mitigation via regex pattern length cap in find_regex (#589)
- URL scheme validation on all hyperlink actions (#589)
- Resource leak fixes across all Office COM handlers (#589)

[GitHub Release](https://github.com/troylar/anteroom/releases/tag/v1.83.0)

### v1.82.2

**Fixed:**

- Stop existing tool ticker when `ask_user` starts, preventing repeated output during input (#581)

[GitHub Release](https://github.com/troylar/anteroom/releases/tag/v1.82.2)

### v1.82.1

**Fixed:**

- Tool elapsed timer no longer clobbers the `ask_user` input prompt (#581)

[GitHub Release](https://github.com/troylar/anteroom/releases/tag/v1.82.1)

### v1.82.0

**New:**

- Built-in MS Office tools (`docx`, `xlsx`, `pptx`) for creating, reading, and editing Word, Excel, and PowerPoint files directly from the agent — install with `pip install anteroom[office]` (#585)
- Windows bash tool fix: multiline `python -c` commands are automatically written to temp files to avoid `cmd.exe` truncation; `python3` resolves to `python` when needed (#583)

[GitHub Release](https://github.com/troylar/anteroom/releases/tag/v1.82.0)

### v1.81.0

**New:**

- Live elapsed timer during tool execution — CLI and web UI now show an updating counter instead of silence during long-running tools (#581)

[GitHub Release](https://github.com/troylar/anteroom/releases/tag/v1.81.0)

### v1.80.0

**New:**

- GUID identity for spaces and packs — duplicate human-friendly names are now allowed, with interactive disambiguation picker in CLI and 409 responses in API (#579)
- New `by-id` pack API endpoints for unambiguous programmatic access (#579)
- ID prefix matching — type the first few characters of a GUID to resolve directly (#579)

[GitHub Release](https://github.com/troylar/anteroom/releases/tag/v1.80.0)

### v1.79.1

**Improved:**

- Removed duplicate `space-setup` skill; `new-space` is the canonical space creation skill (#571)

[GitHub Release](https://github.com/troylar/anteroom/releases/tag/v1.79.1)

### v1.79.0

**New:**

- Auto-discover and activate spaces from `.anteroom/space.yaml` when starting a CLI session — no manual `aroom space load` needed (#572)

[GitHub Release](https://github.com/troylar/anteroom/releases/tag/v1.79.0)

### v1.78.2

**Fixed:**

- Bash tool subprocesses no longer hang when commands read from stdin — stdin is now closed immediately (#573)

[GitHub Release](https://github.com/troylar/anteroom/releases/tag/v1.78.2)

### v1.78.1

*Maintenance release — see GitHub Release for details.*

**Improved:**

- Removed 4 thin stub skills from built-in defaults; built-in count drops from 17 to 13 with zero capability loss (#570)

[GitHub Release](https://github.com/troylar/anteroom/releases/tag/v1.78.1)

### v1.78.0

**New:**

- `aroom space create <name>` now scaffolds a YAML template instead of requiring a pre-existing file; old behavior preserved as `aroom space load <path>` (#532)

**Fixed:**

- UnicodeEncodeError in terminals with restricted locale settings — all Unicode arrows replaced with ASCII (#568)

[GitHub Release](https://github.com/troylar/anteroom/releases/tag/v1.78.0)

### v1.77.2

**New:**

- Spaces: project-scoped workspaces combining packs, sources, repos, and config overlays into reusable YAML definitions (#532)
- Space CLI commands (`aroom space clone/map/move-root`), REPL commands (`/space`), and web API integration (#551, #552, #554)

**Fixed:**

- UnicodeEncodeError from arrow character in space commands on non-UTF-8 terminals (#568)
- Latent bug where `idx_conversations_slug` was never created on fresh installs (#564)

**Improved:**

- All database index creation moved to dedicated function running after migrations, preventing schema ordering bugs by design (#564)
- Migration-path test fixtures with 3 historical schema baselines ensure upgrade safety (#565)

[GitHub Release](https://github.com/troylar/anteroom/releases/tag/v1.77.2)

### v1.77.1

**Fixed:**

- Startup crash (`no such column: space_id`) on databases created before v1.74.0 (#562)

[GitHub Release](https://github.com/troylar/anteroom/releases/tag/v1.77.1)

### v1.77.0

**New:**

- Full pack management parity between CLI and REPL: `/pack attach`, `/pack detach`, `/pack update` in REPL; `aroom pack add-source` in CLI (#559)

**Improved:**

- Hardened URL validation and Rich markup escaping for pack source management (#559)

[GitHub Release](https://github.com/troylar/anteroom/releases/tag/v1.77.0)

### v1.76.0

**New:**

- Five built-in space management skills: `/new-space`, `/space-doctor`, `/space-edit`, `/space-lint`, `/space-setup` (#558)
- Space files can now live anywhere on the filesystem, including inside git repos for team sharing (#558)

[GitHub Release](https://github.com/troylar/anteroom/releases/tag/v1.76.0)

### v1.75.0

**New:**

- Five AI-guided pack workflow skills: `/pack-lint`, `/pack-publish`, `/pack-doctor`, `/pack-update` (#555)
- `/new-pack` renamed from `/pack-create` for consistency with `/new-skill` naming (#555)

**Improved:**

- Skill tab completion now appends a trailing space, ready for arguments immediately (#555)

[GitHub Release](https://github.com/troylar/anteroom/releases/tag/v1.75.0)

### v1.74.0

**New:**

- Spaces: named YAML workspaces bundling repos, packs, sources, instructions, and config overrides (#532)
- CLI `aroom space` subcommands and `/space` REPL commands for full space lifecycle (#551, #552)
- Space config overlay merges between personal and project layers with team enforcement (#553)
- Hot-reload file watcher detects space YAML changes automatically (#553)
- Web UI REST API for spaces with chat integration (#554)

[GitHub Release](https://github.com/troylar/anteroom/releases/tag/v1.74.0)

### v1.73.2

**Fixed:**

- Pack install copies only manifest-referenced files; updates are atomic with rollback (#546)
- Health check no longer deletes pack-referenced artifacts or produces false orphan positives (#541, #545)
- CLI pack inputs validated against injection; API strips internal paths from responses (#545, #546)
- Lock file validation is now bidirectional — catches installed packs missing from lock (#546)
- Credential sanitization, `SELECT *` removal, and duplicate registry init cleaned up (#542, #543, #544)

[GitHub Release](https://github.com/troylar/anteroom/releases/tag/v1.73.2)

### v1.73.1

**Fixed:**

- ArtifactRegistry now wired into runtime — 6-layer precedence is no longer dead code (#528)
- Pack install/remove operations wrapped in atomic transactions with proper rollback (#529)
- FQN regex rejects leading hyphens/dots and enforces 63-char segment limits (#530)
- Symlink rejection in pack manifest validation prevents TOCTOU attacks (#531)
- Credential sanitization extended to ssh:// and git:// URLs in error messages (#531)

[GitHub Release](https://github.com/troylar/anteroom/releases/tag/v1.73.1)

### v1.73.0

**New:**

- `/pack` REPL commands: list, show, install, remove, sources, refresh, add-source — manage packs without leaving the REPL (#525)
- `/new-pack` skill (renamed from `/pack-create`): guided AI-driven pack authoring with manifest scaffolding and validation (#527)
- Welcome banner now shows skill/pack counts and first-run hint (#526)

[GitHub Release](https://github.com/troylar/anteroom/releases/tag/v1.73.0)

### v1.72.1

**Fixed:**

- Artifact upsert race condition: concurrent creation no longer crashes with IntegrityError (#522)
- Malformed JSON metadata and invalid YAML in pack artifacts no longer crash reads/installs (#522)
- Pack refresh worker now uses exponential backoff on failures instead of retrying at normal interval (#522)

[GitHub Release](https://github.com/troylar/anteroom/releases/tag/v1.72.1)

---

## February 26, 2026

### v1.72.0

**New:**

- Pack ecosystem: starter packs, pack attachments (global/project scope), local artifacts, and artifact import/migration (#507)
- Built-in `python-dev` and `security-baseline` starter packs auto-install at startup (#507)
- CLI commands: `pack attach`, `pack detach`, `artifact import`, `artifact create` (#507)

**Improved:**

- Path traversal prevention on artifact names and project paths (#507)

[GitHub Release](https://github.com/troylar/anteroom/releases/tag/v1.72.0)

### v1.71.1

**New:**

- Comprehensive packs & artifacts documentation: 20 new pages covering concepts, quickstart, all 7 artifact types, manifest format, CLI/API reference, pack sources, lock files, health checks, and troubleshooting (#519)
- 8 end-to-end tutorials: install packs, create from scratch, share via git, team standardization, auto-updates, conflict management, health check diagnosis, CI/CD integration (#519)

[GitHub Release](https://github.com/troylar/anteroom/releases/tag/v1.71.1)

### v1.71.0

**New:**

- Artifact health check: analyze all loaded artifacts for conflicts, shadows, duplicates, bloat, and quality issues (#508)
- Three interfaces: CLI (`aroom artifact check`), REPL (`/artifact-check`), and API (`GET /api/artifacts/check`) (#508)
- Auto-fix mode removes exact duplicate artifacts; JSON output for CI/CD integration (#508)

[GitHub Release](https://github.com/troylar/anteroom/releases/tag/v1.71.0)

### v1.70.0

**New:**

- Pack distribution: configure Git-based pack sources with auto-clone, background refresh, and per-source intervals (#506)
- CLI `aroom pack sources` and `aroom pack refresh` commands for source management (#506)
- Lock file provenance: entries include `source_url` and `source_ref` for traceability (#506)

[GitHub Release](https://github.com/troylar/anteroom/releases/tag/v1.70.0)

### v1.69.0

**New:**

- Pack management system: install, remove, update, and list artifact packs via CLI and REST API (#505)
- YAML manifests with namespaced naming, reference counting, and lock file generation for reproducible installs (#505)

[GitHub Release](https://github.com/troylar/anteroom/releases/tag/v1.69.0)

### v1.68.0

**New:**

- Universal artifact system: skills, rules, instructions, context, memories, MCP servers, and config overlays as first-class versioned entities (#504)
- 6-layer precedence resolution for artifact loading (`built_in` through `inline`) (#504)
- CLI `aroom artifact list/show` commands and read-only API endpoints (#504)

[GitHub Release](https://github.com/troylar/anteroom/releases/tag/v1.68.0)

### v1.67.0

**New:**

- Pack source git cache: clone, pull, and manage remote git repositories as pack sources (#509)
- URL scheme allowlist and credential sanitization for secure git operations (#509)

[GitHub Release](https://github.com/troylar/anteroom/releases/tag/v1.67.0)

### v1.66.2

**Fixed:**

- Custom skill files with `.yml` extension now discovered alongside `.yaml` (#510)
- `/skills` output now shows searched directories with skill counts for debugging discovery issues (#510)
- `/new-skill` explicitly requires `.yaml` extension and verifies after writing (#510)

[GitHub Release](https://github.com/troylar/anteroom/releases/tag/v1.66.2)

### v1.66.1

**Fixed:**

- Skill system hardening: reload safety, queue handling, code-fence-aware `{args}`, built-in command protection (#498)
- Default skills (`/commit`, `/review`, `/explain`, `/new-skill`) now use inline `{args}` placeholders (#498)
- Queued skill invocations no longer silently dropped while AI is responding (#498)

[GitHub Release](https://github.com/troylar/anteroom/releases/tag/v1.66.1)

### v1.66.0

**New:**

- CLI `--project` flag for loading project context into chat, exec, and REPL sessions (#391)
- `aroom projects` command lists all projects with model, instructions, and last updated (#391)
- Resuming a project-linked conversation auto-loads project context (#391)

[GitHub Release](https://github.com/troylar/anteroom/releases/tag/v1.66.0)

### v1.65.2

**New:**

- `/new-skill` built-in skill: interactive guide for creating custom skills with best practices (#489)
- `{args}` template variable support in skill prompts (#489)
- `/reload-skills` command and auto-reload on `/skills` for hot-reload without restart (#489)

**Fixed:**

- YAML parse errors when skills use `{args}` template variables (#489)
- Actionable error messages with line/column numbers for skill YAML syntax errors (#489)

[GitHub Release](https://github.com/troylar/anteroom/releases/tag/v1.65.2)

### v1.65.0

**New:**

- CLI project management: `/project create`, `select`, `edit`, `delete`, `sources` commands with active project state (#344)
- Project instructions injected into system prompts with model override support (#344)

**Improved:**

- Introspect tool now triggers on context window and token budget questions (#344)
- Project name/instructions sanitized via `sanitize_trust_tags()` before system prompt injection (#344)

[GitHub Release](https://github.com/troylar/anteroom/releases/tag/v1.65.0)

### v1.64.0

**New:**

- Working directory persistence: CLI conversations remember their project directory and restore it on resume (#274)

[GitHub Release](https://github.com/troylar/anteroom/releases/tag/v1.64.0)

### v1.63.1

**Fixed:**

- Built-in `/a-help` skill updated with all current tools, CLI flags, REPL commands, config sections, and docs index (#487)

**Improved:**

- `/submit-pr` now automatically checks a-help.yaml for staleness during documentation freshness audit (#487)

[GitHub Release](https://github.com/troylar/anteroom/releases/tag/v1.63.1)

### v1.63.0

**New:**

- Egress domain allowlist: restrict which external domains can be contacted for API calls, with team-enforceable policies (#453)
- SSRF prevention: block loopback, RFC-1918 private, link-local (cloud IMDS), multicast, and reserved addresses (#453)

[GitHub Release](https://github.com/troylar/anteroom/releases/tag/v1.63.0)

### v1.62.0

**New:**

- Compliance rules engine: declarative config policy validation with 5 operators (must_be, must_not_be, must_match, must_not_be_empty, must_contain) (#447)
- Fail-closed at startup when compliance rules are violated, preventing misconfigured deployments (#447)
- `aroom config validate` CLI command for pre-deploy policy checks (#447)

[GitHub Release](https://github.com/troylar/anteroom/releases/tag/v1.62.0)

### v1.61.0

**New:**

- Output content filter with system prompt leak detection: scans LLM responses for forbidden content and system prompt fragments via n-gram overlap analysis (OWASP LLM07 mitigation) (#449)
- Custom pattern blocking catches forbidden patterns during streaming before tokens reach the user (#449)
- Three configurable actions: warn, block, or redact — works across web UI, CLI REPL, and exec mode (#449)

[GitHub Release](https://github.com/troylar/anteroom/releases/tag/v1.61.0)

### v1.60.0

**New:**

- Prompt injection detection with canary tokens: multi-layered defense scanning tool outputs for canary leakage, encoding attacks, and instruction override attempts (#448)
- Three detection techniques: CSPRNG canary tokens, base64/zero-width/homoglyph encoding attacks, and 6 ReDoS-safe heuristic patterns (#448)
- Configurable action modes (block/warn/log) with adjustable confidence thresholds, disabled by default (#448)

[GitHub Release](https://github.com/troylar/anteroom/releases/tag/v1.60.0)

### v1.59.0

**New:**

- Data Loss Prevention (DLP) scanning pipeline: detects sensitive data patterns (SSN, credit card, email, phone, IBAN) in AI responses with configurable redact/block/warn actions (#445)
- Custom DLP regex patterns via config for domain-specific sensitive data detection (#445)
- ReDoS-safe pattern validation with static analysis rejection of pathological regex (#445)

[GitHub Release](https://github.com/troylar/anteroom/releases/tag/v1.59.0)

### v1.58.0

**New:**

- Data retention policy: auto-purge old conversations with configurable `storage.retention_days`, background worker, and `aroom db purge` CLI command (#455)
- Encryption at rest: SQLCipher-based database encryption with HKDF-SHA256 key derivation from Ed25519 identity key, `aroom db encrypt` migration (#455)

[GitHub Release](https://github.com/troylar/anteroom/releases/tag/v1.58.0)

### v1.57.1

**Improved:**

- Security documentation overhauled: 3 new pages (bash sandboxing, audit log, prompt injection defense), 4 rewritten pages, all config tables cross-verified against source (#469)
- README rewrite: fixed stale counts (ASVS L2, 2900+ tests, 12 tools, 4 approval modes), expanded security and feature sections (#469)
- SECURITY.md updated from ASVS v4.0 Level 1 to v5.0 Level 2 with 27-row threat model (#469)

[GitHub Release](https://github.com/troylar/anteroom/releases/tag/v1.57.1)

### v1.57.0

**New:**

- Context trust tagging: all LLM context classified as trusted or untrusted with defensive XML envelopes to prevent indirect prompt injection (#366)
- Per-MCP-server trust levels configurable via `trust_level` field (default: untrusted) (#366)
- Structural system prompt separation with `[SYSTEM INSTRUCTIONS - TRUSTED]` / `[EXTERNAL CONTEXT - UNTRUSTED]` markers (#366)

[GitHub Release](https://github.com/troylar/anteroom/releases/tag/v1.57.0)

### v1.56.0

**New:**

- Win32 Job Object sandbox: kernel-level memory, process count, and CPU time limits for bash commands on Windows (#297)
- Auto-detects Windows, no-op on macOS/Linux, zero new dependencies (ctypes only) (#297)
- Graceful degradation: if OS sandbox setup fails, Tier 1 config-level restrictions still apply (#297)

[GitHub Release](https://github.com/troylar/anteroom/releases/tag/v1.56.0)

### v1.55.1

**Fixed:**

- File uploads (PDF, DOCX, text) now have their contents sent to the AI in web UI chat (#464)
- Source references preserved when files are attached via the upload button (#464)
- Extracted document text truncated at 50K chars to prevent oversized token consumption (#464)

[GitHub Release](https://github.com/troylar/anteroom/releases/tag/v1.55.1)

### v1.55.0

**New:**

- Bash execution sandboxing: configurable network, package install, path, and command restrictions for the AI agent's bash tool (#450)
- Cross-platform detection covering Unix tools, PowerShell cmdlets, and Windows package managers (#450)
- Execution timeouts, output limits, and optional audit logging for all bash commands (#450)

[GitHub Release](https://github.com/troylar/anteroom/releases/tag/v1.55.0)

### v1.54.0

**New:**

- Tool call rate limiting: per-minute, per-conversation, and consecutive failure limits to prevent runaway agent loops (#451)
- Two action modes (block or warn) with limits shared across parent and child sub-agents (#451)

[GitHub Release](https://github.com/troylar/anteroom/releases/tag/v1.54.0)

### v1.53.0

**New:**

- Session hardening: pluggable session stores (memory or SQLite), configurable idle/absolute timeouts, concurrent session limits (#452)
- IP allowlisting with CIDR support — restrict access to specific networks or addresses (#452)
- Session IP binding — sessions locked to the IP that created them, invalidated on mismatch (#452)

[GitHub Release](https://github.com/troylar/anteroom/releases/tag/v1.53.0)

### v1.52.0

**New:**

- Read-only mode: lock Anteroom to read-only operations via config, env var, or `--read-only` CLI flag (#454)
- Defense-in-depth: two-layer security with tool-list filtering and execution-time hard-deny backstop (#454)

[GitHub Release](https://github.com/troylar/anteroom/releases/tag/v1.52.0)

---

## February 25, 2026

### v1.51.1

**New:**

- Structured JSONL audit log with HMAC-SHA256 chain tamper protection for enterprise security compliance (#444)
- `aroom audit verify` and `aroom audit purge` CLI commands for log integrity and retention management (#444)

[GitHub Release](https://github.com/troylar/anteroom/releases/tag/v1.51.1)

### v1.51.0

**New:**

- Token budget enforcement for denial-of-wallet prevention — configurable per-request, per-conversation, and per-day limits with block/warn modes (#446)

[GitHub Release](https://github.com/troylar/anteroom/releases/tag/v1.51.0)

### v1.50.3

**Fixed:**

- Canvas tools no longer prompt for approval — reclassified from WRITE to READ tier (#441)

[GitHub Release](https://github.com/troylar/anteroom/releases/tag/v1.50.3)

### v1.50.2

**Fixed:**

- ask_user tool in web UI no longer hangs after clicking an option — SSE keepalive pings prevent stream death during long waits (#439)

[GitHub Release](https://github.com/troylar/anteroom/releases/tag/v1.50.2)

### v1.50.1

**Fixed:**

- Hung stream no longer blocks web UI after page refresh — disconnect polling auto-cancels orphaned streams (#436)
- Stop button immediately resets client state for responsive UI during cancellation (#436)
- Page-load recovery detects active streams and shows Stop button (#436)

[GitHub Release](https://github.com/troylar/anteroom/releases/tag/v1.50.1)

### v1.50.0

**New:**

- Web UI thinking indicator now shows lifecycle phases — connecting, waiting, streaming with char count, and stall detection (#435)

[GitHub Release](https://github.com/troylar/anteroom/releases/tag/v1.50.0)

### v1.49.1

**Fixed:**

- Canvas streaming now renders with proper syntax highlighting from the start (#432)
- Canvas content no longer leaks before approval prompt (#432)
- Thinking animation dots render below the SYSTEM header, not above it (#434)

[GitHub Release](https://github.com/troylar/anteroom/releases/tag/v1.49.1)

### v1.49.0

**New:**

- `/create-eval` built-in skill — generate promptfoo evals, shell tests, and VHS demos from descriptions or conversations (#430)
- Tutorial for project-local evals with copy-paste examples for all patterns (#430)

[GitHub Release](https://github.com/troylar/anteroom/releases/tag/v1.49.0)

### v1.48.1

**New:**

- Comprehensive developer testing guide covering all 7 test layers — unit through red teaming (#428)
- Documents promptfoo eval setup, agent behavioral evals, VHS demo recordings, and deterministic output configuration (#428)

[GitHub Release](https://github.com/troylar/anteroom/releases/tag/v1.48.1)

### v1.48.0

**New:**

- Auto-detect embedding support at startup — probes endpoint once instead of failing every 30s for enterprise APIs without embeddings (#109)
- Zero-config for both paths: embedding-capable APIs work automatically, others silently skip

[GitHub Release](https://github.com/troylar/anteroom/releases/tag/v1.48.0)

## February 24, 2026

### v1.47.0

**New:**

- Parallel MCP server startup — all servers connect simultaneously with live animated status display (#383)
- Subprocess stderr suppressed for clean terminal output during MCP connection (#383)

[GitHub Release](https://github.com/troylar/anteroom/releases/tag/v1.47.0)

### v1.46.0

**New:**

- Tree-sitter codebase index — AI automatically understands your project's functions, classes, and import structure (#212)
- Supports 10 languages with token-budgeted output and graceful degradation without tree-sitter installed (#212)

[GitHub Release](https://github.com/troylar/anteroom/releases/tag/v1.46.0)

### v1.44.0

**New:**

- Interactive conversation picker — type `/resume` with no argument to browse conversations with a live preview panel (#381)

[GitHub Release](https://github.com/troylar/anteroom/releases/tag/v1.44.0)

### v1.43.3

**Fixed:**

- REPL autocomplete now includes `/slug`, `/upload`, `/usage`, and `/rename` commands (#377)
- `/help` dialog now shows `/upload` and `/usage` entries (#377)

[GitHub Release](https://github.com/troylar/anteroom/releases/tag/v1.43.3)

### v1.43.2

**Fixed:**

- Resume hint now appears on all exit paths including Ctrl+C (#376)
- Added double Ctrl+C exit: first press clears buffer, second press exits with resume hint (#376)

[GitHub Release](https://github.com/troylar/anteroom/releases/tag/v1.43.2)

### v1.43.1

*Maintenance release — bumped CodeQL CI action from v3 to v4.*

[GitHub Release](https://github.com/troylar/anteroom/releases/tag/v1.43.1)

### v1.43.0

**New:**

- AI-powered skill auto-invocation — say "commit my changes" or "review this PR" instead of typing `/commit` or `/review` (#267)
- Configurable via `cli.skills.auto_invoke` (default true); explicit `/command` still takes priority (#267)

[GitHub Release](https://github.com/troylar/anteroom/releases/tag/v1.43.0)

### v1.42.0

**New:**

- Human-readable conversation slugs — conversations get auto-generated names like `bold-azure-cliff` for easy resume and reference (#367)
- Rename slugs with `/slug my-project` in CLI, with uniqueness suggestions when names are taken (#367)
- Slug display in CLI `/list` and web UI sidebar (#367)

[GitHub Release](https://github.com/troylar/anteroom/releases/tag/v1.42.0)

### v1.41.0

**New:**

- Resume hint on CLI exit — shows `aroom chat -c` and `aroom chat -r <id>` commands when leaving a conversation with messages (#370)

[GitHub Release](https://github.com/troylar/anteroom/releases/tag/v1.41.0)

### v1.40.0

**New:**

- Automatic cleanup of empty conversations on startup — keeps your conversation list clutter-free in both web UI and CLI (#363)

[GitHub Release](https://github.com/troylar/anteroom/releases/tag/v1.40.0)

### v1.39.0

**New:**

- **Plan mode in web UI**: Toggle planning mode, review AI-generated plans in a side panel, approve to execute or reject to start over — full parity with CLI (#340)

[GitHub Release](https://github.com/troylar/anteroom/releases/tag/v1.39.0)

### v1.38.0

**New:**

- **RAG pipeline**: Conversations now automatically retrieve relevant context from past conversations and knowledge sources via semantic similarity search (#349)
- Configurable similarity threshold, token budget, and chunk limits — works zero-config with sensible defaults

[GitHub Release](https://github.com/troylar/anteroom/releases/tag/v1.38.0)

### v1.37.1

**Fixed:**

- CLI paste preview no longer shows raw ANSI escape codes — collapsed multiline input renders colors correctly via Rich (#159)

[GitHub Release](https://github.com/troylar/anteroom/releases/tag/v1.37.1)

## February 23, 2026

### v1.37.0

**New:**

- **Introspect tool**: AI can now examine its own runtime context — config, tools, MCP servers, safety gates, skills, and token budget — to answer self-awareness questions accurately (#332)

[GitHub Release](https://github.com/troylar/anteroom/releases/tag/v1.37.0)

### v1.36.1

**Fixed:**

- Init wizard now skips redundant prompts when team config provides AI settings (#333)

[GitHub Release](https://github.com/troylar/anteroom/releases/tag/v1.36.1)

### v1.36.0

**New:**

- **Named-list merge for team config**: MCP servers and shared databases merge by `name` field instead of replacing wholesale — overlay just the fields you need (#330)
- **Disable team items**: Set `enabled: false` in personal config to opt out of team-defined MCP servers or databases (#330)

[GitHub Release](https://github.com/troylar/anteroom/releases/tag/v1.36.0)

### v1.35.0

**New:**

- **Project-scoped configuration**: Per-project `config.yaml` files auto-discovered via walk-up search from cwd, with deep merge, trust verification, and team enforcement (#325)
- **Required keys**: Project/team configs can declare required values with interactive prompting and masked input for secrets (#325)
- **Shared references**: Declare instructions, rules, and skills that load automatically per project (#325)
- **Live config reload**: Config files monitored via mtime polling — changes apply without restarting (#325)
- **Team config bootstrap**: `aroom init --team-config` trusts and configures team config in one step (#325)

[GitHub Release](https://github.com/troylar/anteroom/releases/tag/v1.35.0)

### v1.34.1

**New:**

- **Renamed `/docs` to `/a-help`**: Built-in help skill renamed to avoid conflicts with project skills (#326)
- **Expanded `/a-help` config docs**: Inline reference now covers config layers, team config, enforce/required keys, onboarding, and directory equivalence (#326)

[GitHub Release](https://github.com/troylar/anteroom/releases/tag/v1.34.1)

### v1.34.0

**New:**

- **Graceful tool limit handling**: Automatically caps tools per API request (default 128) to prevent errors when many MCP servers are connected (#311)
- **Configurable tool limit**: Set `ai.max_tools` in config or `AI_CHAT_MAX_TOOLS` env var to adjust the cap (#311)

[GitHub Release](https://github.com/troylar/anteroom/releases/tag/v1.34.0)

### v1.33.0

**New:**

- **Team config with enforcement**: Shared YAML config with `enforce` list to lock settings (API endpoint, model, safety mode) across all team members (#316)
- **.claude directory support**: `.anteroom` and `.claude` directories are now interchangeable for instructions, skills, team config, and rules (#316)
- **Web UI enforcement**: Config API rejects changes to enforced fields (HTTP 403) and exposes locked fields to the UI (#316)

[GitHub Release](https://github.com/troylar/anteroom/releases/tag/v1.33.0)

### v1.32.0

**New:**

- **Structured options for ask_user**: AI can present multiple-choice options as numbered list (CLI) or buttons (web UI), with freeform fallback (#312)
- **Cancel support**: Esc in CLI or Cancel button in web UI sends unambiguous cancelled signal to the AI (#312)
- **Web UI ask_user rendering**: Fully functional styled prompt cards replace previously silent/broken SSE events (#312)

[GitHub Release](https://github.com/troylar/anteroom/releases/tag/v1.32.0)

### v1.31.0

**New:**

- **Debug logging for MCP troubleshooting**: `aroom --debug chat` or `AI_CHAT_LOG_LEVEL=DEBUG` enables debug logging to stderr for diagnosing MCP server connections and tool routing (#313)

[GitHub Release](https://github.com/troylar/anteroom/releases/tag/v1.31.0)

### v1.30.0

**New:**

- **Token usage tracking & cost estimation**: Track token consumption per model with `/usage` command in CLI, `aroom usage` subcommand, and `GET /api/usage` web endpoint (#226)
- **Configurable cost rates**: Set per-model input/output token rates for cost estimation via `cli.usage.model_costs` config (#226)

[GitHub Release](https://github.com/troylar/anteroom/releases/tag/v1.30.0)

### v1.29.0

**New:**

- **Document upload with text extraction**: Upload PDFs and DOCX files to the knowledge base with automatic text extraction, chunking, and semantic search indexing (#179)
- **CLI `/upload` command**: Upload files directly from the CLI REPL with MIME detection and size validation (#179)
- **Project-scoped source search**: Filter semantic search results to sources linked to a specific project (#179)

**Fixed:**

- Bumped `pypdf` minimum to >=6.7.1 to address 6 known vulnerabilities (#179)

[GitHub Release](https://github.com/troylar/anteroom/releases/tag/v1.29.0)

### v1.28.0

**New:**

- **Per-server MCP tool filtering**: Control which tools each MCP server exposes using `tools_include`/`tools_exclude` with fnmatch glob patterns (#306)
- **MCP tool warning threshold**: Warns when total MCP tools exceed a configurable limit (default 40) with per-server breakdown (#306)

[GitHub Release](https://github.com/troylar/anteroom/releases/tag/v1.28.0)

---

## February 22, 2026

### v1.27.0

**New:**

- **Ask User tool**: AI now pauses mid-turn to ask clarifying questions instead of guessing and continuing, saving tokens and producing better results (#299)

[GitHub Release](https://github.com/troylar/anteroom/releases/tag/v1.27.0)

### v1.26.1

**Fixed:**

- **Aggressive plan suggestions silenced**: Default `auto_mode` changed from `"suggest"` to `"off"` and threshold raised from 5 to 15 tool calls, eliminating noise on routine tasks (#302)

[GitHub Release](https://github.com/troylar/anteroom/releases/tag/v1.26.1)

### v1.26.0

**New:**

- **Live plan checklist**: `/plan approve` now renders a real-time checklist above the thinking spinner, tracking each implementation step through pending, in-progress, and complete states (#166)

[GitHub Release](https://github.com/troylar/anteroom/releases/tag/v1.26.0)

### v1.25.0

**New:**

- **Inline diff rendering in CLI**: File edits and creations now show Claude Code-style color-coded diffs with line numbers, red/green backgrounds, and context collapsing (#281)

[GitHub Release](https://github.com/troylar/anteroom/releases/tag/v1.25.0)

### v1.24.6

**Fixed:**

- **Changelog rendering on ReadTheDocs**: Section headers were rendering inline with bullet points — added blank lines for proper MkDocs Material list rendering (#295)
- Completed ~45 truncated changelog entries from initial backfill (#295)

[GitHub Release](https://github.com/troylar/anteroom/releases/tag/v1.24.6)

### v1.24.5

**Improved:**

- **Changelog readability**: Release entries now grouped by type — New, Fixed, Improved — for easier scanning (#295)
- **Changelog navigation**: Moved to top-level nav in docs instead of hidden under Advanced (#295)
- Deploy skill auto-generates future entries in the new type-segregated format (#295)

[GitHub Release](https://github.com/troylar/anteroom/releases/tag/v1.24.5)

### v1.24.4

**New:**

- **Changelog with release highlights**: Every release now has a highlights entry in `docs/advanced/changelog.md`, viewable on ReadTheDocs (#290)
- Backfilled all 80 existing releases; `/deploy` skill auto-appends new entries going forward

[GitHub Release](https://github.com/troylar/anteroom/releases/tag/v1.24.4)

### v1.24.3

**Improved:**

- **Replaced Snyk with Semgrep + CodeQL** for open-source SAST scanning — no more external tokens or Node.js required in CI (#289)

[GitHub Release](https://github.com/troylar/anteroom/releases/tag/v1.24.3)

### v1.24.2

**Fixed:**

- Fixed MCP tool argument validation that incorrectly blocked legitimate text content (newlines, parentheses, semicolons, etc.) when passed to MCP servers like filesystem or database tools (#291)
- Improved MCP tool error messages to include server name and tool context for easier debugging (#291)
- Sanitized MCP error output so raw server exceptions are logged server-side only, not exposed to the user (#291)

**Improved:**

- Updated README.md MCP safety description to reflect current behavior (#291)

[GitHub Release](https://github.com/troylar/anteroom/releases/tag/v1.24.2)

### v1.24.1

*Maintenance release — see GitHub Release for details.*

[GitHub Release](https://github.com/troylar/anteroom/releases/tag/v1.24.1)

### v1.24.0

**New:**

- **OpenAI-compatible proxy endpoint**: External tools using the OpenAI SDK can route requests through Anteroom to the upstream API (#285)
- Endpoints: `GET /v1/models` and `POST /v1/chat/completions` with full streaming support
- Opt-in via `proxy.enabled: true` — disabled by default for security

[GitHub Release](https://github.com/troylar/anteroom/releases/tag/v1.24.0)

### v1.23.0

**New:**

- **Iterative plan refinement**: `/plan edit` opens in `$EDITOR`, `/plan reject` triggers AI revision (#270, #271)
- **Inline planning**: `/plan <prompt>` enters planning mode in one command (#265)
- Auto-plan suggestions when tasks exceed tool-call threshold (#265)

[GitHub Release](https://github.com/troylar/anteroom/releases/tag/v1.23.0)

### v1.22.1

**New:**

- **Planning Mode**: AI can now generate a structured step-by-step plan before executing tasks. Start planning mode with `aroom chat --plan` or `/plan on` during a session (#264)
- **Plan Editing**: Open your plan in `$VISUAL`/`$EDITOR` with `/plan edit` to review and modify it before approving execution. (#270)

**Improved:**

- Added a feature parity development rule ensuring all new features work equivalently in both the CLI and web UI (#275)

[GitHub Release](https://github.com/troylar/anteroom/releases/tag/v1.22.1)


---

## February 21, 2026

### v1.22.0

**New:**

- **Built-in `/docs` skill**: Look up Anteroom documentation without leaving the CLI — covers config, flags, tools, skills, and architecture (#262)
- Embeds quick-reference tables for instant answers; consults 42 documentation files for deeper questions

[GitHub Release](https://github.com/troylar/anteroom/releases/tag/v1.22.0)

### v1.21.0

**New:**

- **Non-interactive exec mode**: `aroom exec "prompt"` for scripting and CI pipelines (#232)
- Supports stdin piping, `--json` output, timeout control, and conversation persistence

[GitHub Release](https://github.com/troylar/anteroom/releases/tag/v1.21.0)

### v1.20.1

**Fixed:**

- Fixed stale thinking line text persisting after stream retry — the "Stream timed out" and "retrying in Ns" text no longer flashes or leaves ghost content on the thinking line (#253)

[GitHub Release](https://github.com/troylar/anteroom/releases/tag/v1.20.1)

### v1.20.0

**New:**

- **ANTEROOM.md Project Conventions**: Anteroom now formally supports `ANTEROOM.md` as a project-level conventions file that the AI follows consistently across both CLI and web UI (#215)
- Auto-discovers conventions walking up from your working directory (#215)
- **Web UI now loads ANTEROOM.md** — previously CLI-only, conventions now apply in both interfaces (#215)

**Improved:**

- Removed legacy `PARLOR.md` instruction filename support — use `ANTEROOM.md` going forward (#215)

[GitHub Release](https://github.com/troylar/anteroom/releases/tag/v1.20.0)


---

## February 20, 2026

### v1.19.0

**New:**

- **Trust Prompts for Project Instructions**: Anteroom now prompts you before loading project-level `ANTEROOM.md` files into the AI context. This prevents prompt injection from untrusted project directories (#219)
- Trust decisions are persisted with SHA-256 content hash verification — you only need to approve once per project (#219)
- If the file changes, you'll be re-prompted to review and approve the new content (#219)

[GitHub Release](https://github.com/troylar/anteroom/releases/tag/v1.19.0)

### v1.18.4

**Fixed:**

- **Fixed CLI hang after pressing Escape** — pressing Escape to cancel a running command could leave the CLI unresponsive, requiring a force-quit. The REPL now cleanly cancels the active operation and returns to the prompt (#243)

[GitHub Release](https://github.com/troylar/anteroom/releases/tag/v1.18.4)

### v1.18.3

**Fixed:**

- **API error handling during streaming** — Previously, HTTP errors from the AI provider (like 500 Internal Server Error, 502 Bad Gateway, or 404 Not Found) could crash the stream or produce confusing output. Now handled gracefully with clear error messages (#241)

[GitHub Release](https://github.com/troylar/anteroom/releases/tag/v1.18.3)

### v1.18.2

**Fixed:**

- Fixed the CLI thinking indicator ("Thinking...") briefly flashing then dropping to a blank line on the very first message in a new REPL session. Subsequent messages were unaffected (#239)

[GitHub Release](https://github.com/troylar/anteroom/releases/tag/v1.18.2)

### v1.18.1

**Fixed:**

- **Fixed timeout enforcement on API connections** — The configured `request_timeout` (default 120s) was not enforced as a hard deadline during the initial API connection phase, allowing slow connections to hang indefinitely (#237)
- **Fixed Escape key ignored during connecting phase** — Pressing Escape while the API was connecting had no effect until the connection completed or timed out. Now cancels immediately (#237)
- **Fixed cancel-during-retry loop** — If the user pressed Escape during a retry backoff delay, the retry loop could re-enter the connection attempt instead of returning to the prompt (#237)

[GitHub Release](https://github.com/troylar/anteroom/releases/tag/v1.18.1)

### v1.18.0

**New:**

- **Configurable Timeouts and Thresholds**: Every timeout, threshold, and limit that was previously hardcoded is now a config field with a sensible default (#235)
- `write_timeout` — time to send request body (default: 30s)
- `pool_timeout` — wait for free connection from pool (default: 10s)

**Fixed:**

- **Escape during stalled stream now cancels cleanly** — Previously, pressing Escape while a stream was stalled would trigger a retry countdown instead of cancelling. Now returns to the prompt immediately (#235)
- **Stalled streams abort faster** — Added per-chunk stall timeout (default 30s) so streams that go silent mid-response are aborted sooner instead of waiting for the full request timeout (#235)

[GitHub Release](https://github.com/troylar/anteroom/releases/tag/v1.18.0)

### v1.17.1

**Fixed:**

- Fixed the CLI thinking spinner showing stale phase text ("waiting for first token", "streaming · N chars") and "esc to cancel" hint on the final line after a response completes (#231)
- Fixed the per-phase timer not always appearing during the "waiting for first token" phase. The timer now starts immediately when thinking begins, rather than waiting for the first phase transition (#231)

[GitHub Release](https://github.com/troylar/anteroom/releases/tag/v1.17.1)

### v1.17.0

**New:**

- **Real-Time Connection Health Monitor for CLI**: The CLI thinking spinner now shows live connection status so you always know what's happening during AI interactions (#221)
- **Phase tracking**: See "connecting", "connected · waiting for first token", and "streaming · N chars" as the request progresses (#221)
- **Per-phase timing**: Each phase shows how long it's been active (e.g., "waiting for first token (5s)")

**Fixed:**

- Fixed error messages leaking internal API details — now shows generic "AI request error" instead of raw provider messages (#221)
- Fixed exception class names appearing in retry event payloads (#221)

[GitHub Release](https://github.com/troylar/anteroom/releases/tag/v1.17.0)

### v1.16.3

**Fixed:**

- **Fixed confusing "HARD BLOCKED" message after approving dangerous commands.** Previously, when you approved a dangerous command like `rm -rf`, the system would still show a "HARD BLOCKED" error. Now bypasses the redundant safety check after explicit approval (#217)

[GitHub Release](https://github.com/troylar/anteroom/releases/tag/v1.16.3)

### v1.16.2

**Fixed:**

- **Smarter API timeouts**: Replaced the single 120-second timeout with three phase-aware timeouts — connect (5s), first-token (30s), and stream (120s). This prevents long waits when the API is unreachable (#213)
- **Automatic retry on transient errors**: When the API times out or drops a connection, Anteroom now automatically retries up to 3 times with exponential backoff (#213)
- **Fixed phantom thinking timer after timeout**: Previously, if the API timed out, the thinking spinner would restart and keep counting up even after the error message was shown (#213)

[GitHub Release](https://github.com/troylar/anteroom/releases/tag/v1.16.2)

### v1.16.1

**Fixed:**

- CLI no longer prints noisy tracebacks when pressing Ctrl+C with MCP servers connected. Shutdown errors are now suppressed from terminal output and logged at debug level (#208)
- Fixed a test that would fail when `AI_CHAT_API_KEY` was set in the shell environment (#208)

[GitHub Release](https://github.com/troylar/anteroom/releases/tag/v1.16.1)

### v1.16.0

**New:**

- **Granular Request Lifecycle Phases in Thinking Indicator**: The thinking spinner now shows exactly where time is being spent during AI responses, making it easy to diagnose slow connections (#203)
- **Connecting** — shown while establishing connection to the AI API (#203)
- **Waiting for first token** — shown after the request is sent, while waiting for the model to start responding (#203)

[GitHub Release](https://github.com/troylar/anteroom/releases/tag/v1.16.0)

### v1.15.0

**New:**

- **Rich Markdown in Resume Recap**: When resuming a conversation with `/last` or `/resume`, the assistant's last message is now rendered with full Rich Markdown formatting (#199)
- Long assistant messages truncate at line boundaries to preserve markdown structure
- Truncation limit increased from 300 to 500 characters for better context

[GitHub Release](https://github.com/troylar/anteroom/releases/tag/v1.15.0)

### v1.14.11

**Fixed:**

- **Thinking spinner no longer freezes during API stalls** — The CLI thinking timer previously stuck at "1s" when the API was slow to respond between tool calls. Now uses a background ticker task that updates independently (#197)

[GitHub Release](https://github.com/troylar/anteroom/releases/tag/v1.14.11)

### v1.14.10

**New:**

- **`--port` flag**: Override the configured port directly from the command line
- **`AI_CHAT_PORT` environment variable**: Set a default port via environment variable, useful for scripts and containerized setups
- **Smarter browser launch**: The browser now waits until the server is actually ready before opening, preventing "connection refused" errors on slower startups

**Fixed:**

- **Port-in-use errors now show actionable guidance** — when port 8080 (or your configured port) is already taken, Anteroom now prints a clear message with the `--port` flag and `AI_CHAT_PORT` env var as alternatives (#193)

[GitHub Release](https://github.com/troylar/anteroom/releases/tag/v1.14.10)

### v1.14.9

*Maintenance release — see GitHub Release for details.*

[GitHub Release](https://github.com/troylar/anteroom/releases/tag/v1.14.9)

### v1.14.8

**Fixed:**

- **Fixed thinking indicator hanging indefinitely** — When an API stalls mid-stream (no chunks arriving), Anteroom now detects the stall and times out gracefully instead of spinning forever (#191)

[GitHub Release](https://github.com/troylar/anteroom/releases/tag/v1.14.8)

### v1.14.7

*Maintenance release — see GitHub Release for details.*

[GitHub Release](https://github.com/troylar/anteroom/releases/tag/v1.14.7)


---

## February 19, 2026

### v1.14.6

**Fixed:**

- API connection and authentication errors now show clear, actionable messages instead of raw Python tracebacks or generic "internal error" text (#121)

[GitHub Release](https://github.com/troylar/anteroom/releases/tag/v1.14.6)

### v1.14.5

**Fixed:**

- **Fixed stacking approval prompts in CLI.** When multiple MCP tools needed approval at the same time, prompts would stack on top of each other and spam "terminal" output. Now serialized with proper queueing (#187)

[GitHub Release](https://github.com/troylar/anteroom/releases/tag/v1.14.5)

### v1.14.4

**New:**

- **ESC cancel hint on CLI thinking line**: When the AI is thinking for more than 3 seconds, a muted "esc to cancel" hint now appears on the thinking line. This makes the cancel shortcut discoverable without cluttering the UI (#185)

[GitHub Release](https://github.com/troylar/anteroom/releases/tag/v1.14.4)

### v1.14.3

**Fixed:**

- **Embedding worker no longer retries unembeddable messages forever.** Previously, short messages (< 10 characters), messages that returned no embedding, and messages that repeatedly failed to store would be retried indefinitely. Now marked as skipped after detection (#183)

[GitHub Release](https://github.com/troylar/anteroom/releases/tag/v1.14.3)

### v1.14.2

**Fixed:**

- Fixed Ctrl+C causing unhandled `ExceptionGroup` errors during MCP server shutdown (#174). The MCP SDK uses `anyio` TaskGroups internally, which raise `ExceptionGroup` on cancellation. Now caught and handled cleanly

[GitHub Release](https://github.com/troylar/anteroom/releases/tag/v1.14.2)

### v1.14.1

**Fixed:**

- **File uploads now accept common document formats** — Uploading Office documents (.docx, .xlsx, .pptx, .doc, .xls, .ppt), Markdown files, JSON, YAML, TOML, and other common formats no longer fails with a MIME type validation error (#176)
- **Markdown and text files upload correctly even when browsers send no MIME type** — When a browser sends `application/octet-stream` (no MIME type detected), the server now infers the type from the file extension (#176)

[GitHub Release](https://github.com/troylar/anteroom/releases/tag/v1.14.1)

### v1.14.0

**New:**

- **Knowledge Sources**: A global knowledge store for your projects — upload files, save text notes, and bookmark URLs that persist across conversations. Sources can be tagged, grouped, and linked to projects (#180)
- Create text, URL, and file-based knowledge sources (#180)
- Full web UI for browsing, creating, editing, and deleting sources (#181)

[GitHub Release](https://github.com/troylar/anteroom/releases/tag/v1.14.0)

### v1.13.0

**New:**

- **Local Embeddings — No API Key Required**: Anteroom now generates vector embeddings locally using [fastembed](https://github.com/qdrant/fastembed), an ONNX-based embedding library that runs entirely offline (#172)
- Default model: `BAAI/bge-small-en-v1.5` (384 dimensions, ~50MB download on first use)
- Install with: `pip install anteroom[embeddings]`

[GitHub Release](https://github.com/troylar/anteroom/releases/tag/v1.13.0)

### v1.12.3

**Fixed:**

- MCP server connection failures are now logged cleanly without a raw traceback. When an MCP server rejects a connection or fails the handshake, Anteroom presents a clear error message and continues starting up (#170)

[GitHub Release](https://github.com/troylar/anteroom/releases/tag/v1.12.3)

### v1.12.2

**Fixed:**

- **Fixed CLI crash when reviewing codebases with special tokens**: The CLI would crash with a tiktoken error when message content contained special token patterns. Now handled gracefully (#168)

[GitHub Release](https://github.com/troylar/anteroom/releases/tag/v1.12.2)

### v1.12.1

**Fixed:**

- **Narration cadence now actually works**: The narration cadence feature (introduced in v1.11.0) was not producing any output for modern models like GPT-4o that return empty content with tool calls. Fixed to inject narration prompts correctly (#169)
- Narration now fires reliably regardless of model behavior (#169)
- Default cadence unchanged: every 5 tool calls (`ai.narration_cadence: 5`)

[GitHub Release](https://github.com/troylar/anteroom/releases/tag/v1.12.1)

### v1.12.0

**New:**

- **Configurable Tool Call Dedup**: When the AI makes many consecutive tool calls of the same type (e.g., editing 10 files in a row), they're now automatically collapsed into a summary line for cleaner output (#59)
- CLI: consecutive same-type tool calls collapse with a count summary (e.g., "... edited 5 files total") (#59)
- Web UI: consecutive same-type tool calls group into a collapsible `<details>` element with count (e.g., "edit_file × 5") (#59)

[GitHub Release](https://github.com/troylar/anteroom/releases/tag/v1.12.0)


---

## February 18, 2026

### v1.11.0

**New:**

- **Progress Updates During Long Agentic Runs**: When the AI executes many tool calls in sequence (editing files, running tests, exploring code), it now gives periodic progress summaries so you know what's happening (#157)
- Configurable via `ai.narration_cadence` in config.yaml (default: every 5 tool calls) (#157)
- Set to `0` to disable and restore the previous silent behavior

[GitHub Release](https://github.com/troylar/anteroom/releases/tag/v1.11.0)

### v1.10.2

**Fixed:**

- **API timeout recovery**: After a timeout, the next request no longer hangs indefinitely. Previously, a timeout would leave the httpx connection pool in a broken state. Now properly cleaned up (#155)

[GitHub Release](https://github.com/troylar/anteroom/releases/tag/v1.10.2)

### v1.10.0

**New:**

- **Claude Code-Quality System Instructions**: The default system prompt for `aroom chat` has been completely rewritten to match the quality and structure of professional agentic coding assistants (#153)
- **Tool preference hierarchy**: The AI now strongly prefers dedicated tools (read_file, edit_file, grep, glob_files) over bash for file operations, reducing errors and improving reliability (#153)
- **Code modification guidelines**: Instructions to read before editing, match codebase conventions, avoid over-engineering, and produce working code — not prototypes (#153)

[GitHub Release](https://github.com/troylar/anteroom/releases/tag/v1.10.0)

### v1.9.4

**Fixed:**

- **Tool call notifications no longer disappear mid-session.** In multi-iteration agent loops (where the AI calls tools, thinks, then calls more tools), tool call panels in the Web UI were being cleared between iterations. Now preserved across the full response (#151)

[GitHub Release](https://github.com/troylar/anteroom/releases/tag/v1.9.4)

### v1.9.3

**Fixed:**

- **Embedding worker no longer retries forever** when the embedding API returns a permanent error (e.g., model not found, invalid credentials). Previously, the worker would retry with exponential backoff indefinitely (#149)
- **Permanent errors** (404 model not found, 422 unprocessable, failed auth) immediately disable the worker with a clear log message
- **Transient errors** (429 rate limit, 503 server error, timeouts) trigger exponential backoff: 30s → 60s → 120s → up to 300s

[GitHub Release](https://github.com/troylar/anteroom/releases/tag/v1.9.3)

### v1.9.2

**Fixed:**

- Fixed CLI completion menu using white-on-black colors that clashed with the dark terminal theme — now uses the dark palette (gold highlight, chrome text on dark background) (#147)
- Added above-cursor positioning attempt for the completion menu to reduce clipping when the prompt is near the terminal bottom (best-effort — full fix coming in a future release) (#147)

[GitHub Release](https://github.com/troylar/anteroom/releases/tag/v1.9.2)

### v1.9.1

**Improved:**

- Optimized `/code-review` and `/submit-pr` Claude Code skills to eliminate redundant agent work during deploy cycles, reducing token usage by ~170k per deploy (#145)

[GitHub Release](https://github.com/troylar/anteroom/releases/tag/v1.9.1)

### v1.9.0

**New:**

- **Sub-Agent Loading Indicator**: When a sub-agent is running in the Web UI, you now see a distinctive loading state instead of the generic tool call panel (#143)
- A pulsing accent border that animates while the sub-agent works
- A prompt preview showing what the sub-agent is doing

[GitHub Release](https://github.com/troylar/anteroom/releases/tag/v1.9.0)

### v1.8.0

**New:**

- **MCP Tools in Sub-Agents**: Sub-agents spawned via `run_agent` can now access MCP (Model Context Protocol) tools from connected servers. Previously, child agents only had access to built-in tools (#100)
- MCP tool definitions are merged into the child agent's tool list (#100)
- Child agents can call MCP tools through real MCP servers (e.g., time, filesystem, databases)

[GitHub Release](https://github.com/troylar/anteroom/releases/tag/v1.8.0)

### v1.7.0

**Fixed:**

- **CLI text readability on dark terminals**: Rich's `[dim]` style (SGR 2 faint) was nearly invisible on most dark terminal themes, making tool results, approval prompts, and metadata unreadable (#140)
- Replaced all `[dim]` and `grey62` markup with a defined color palette that meets WCAG AA contrast ratios (#140)
- Four named constants: `GOLD` (accents), `SLATE` (labels), `MUTED` (secondary text), `CHROME` (UI chrome)

[GitHub Release](https://github.com/troylar/anteroom/releases/tag/v1.7.0)

### v1.6.0

**New:**

- **Sub-Agent Orchestration**: The AI can now spawn parallel child agents using the `run_agent` tool to break complex tasks into independent subtasks. Each sub-agent runs in its own conversation context (#95)
- Sub-agents execute in parallel with concurrency control via `asyncio.Semaphore` (#95)
- Configurable limits: max concurrent (5), max total (10), max depth (3), max iterations (15), wall-clock timeout (120s)

[GitHub Release](https://github.com/troylar/anteroom/releases/tag/v1.6.0)

### v1.5.1

**Improved:**

- Remove stale test count tracking from CLAUDE.md and skill definitions — the hardcoded count went stale constantly and skills wasted cycles checking/updating it (#138)

[GitHub Release](https://github.com/troylar/anteroom/releases/tag/v1.5.1)

### v1.5.0

**New:**

- **Issue Lifecycle Management**: Three new Claude Code skills for managing the issue → branch → PR → deploy lifecycle, plus seven GitHub labels for tracking priority and status (#136)
- `/next` — Prioritized work queue sorted by priority labels and VISION.md direction areas. Shows what to work on next with rationale (#136)
- `/triage` — Set priority on individual issues or AI-reassess all open issues against VISION.md. Optionally updates ROADMAP.md (#136)

[GitHub Release](https://github.com/troylar/anteroom/releases/tag/v1.5.0)

### v1.4.11

*Maintenance release — see GitHub Release for details.*

[GitHub Release](https://github.com/troylar/anteroom/releases/tag/v1.4.11)

### v1.4.10

**Fixed:**

- **Stale Auth Cookie Recovery on Upgrade**: Users upgrading from pre-identity versions (before v1.4.5) could get stuck in an authentication loop where the browser had an outdated session cookie (#128)
- Server now attaches a fresh session cookie to 401 responses, so browsers auto-recover without a manual page refresh (#128)
- Partial identity configs (user_id present but missing private_key) are now auto-repaired on server startup (#128)

[GitHub Release](https://github.com/troylar/anteroom/releases/tag/v1.4.10)

### v1.4.9

**New:**

- **CLI Startup Progress Feedback**: The CLI no longer sits silently during bootstrap. Dim animated spinners now show activity during the three slow startup phases (#122):
- MCP server connections (#122)
- AI service validation (#122)

**Fixed:**

- Fixed compatibility with newer OpenAI models (e.g., gpt-5.2) that reject the deprecated `max_tokens` parameter in `aroom --test`. Now uses `max_completion_tokens` (#122)

[GitHub Release](https://github.com/troylar/anteroom/releases/tag/v1.4.9)

### v1.4.8

**Fixed:**

- Fixed the web UI "stuck thinking" animation that would never dismiss after a response completed. The thinking indicator was being created multiple times but only one instance was tracked for dismissal (#128)
- Fixed 401 authentication errors for users upgrading from pre-identity versions. The chat stream now properly handles expired sessions instead of showing an opaque error (#128)
- Fixed SSE EventSource reconnect loop — persistent auth failures (3+ consecutive) now trigger session recovery instead of reconnecting indefinitely. (#128)

[GitHub Release](https://github.com/troylar/anteroom/releases/tag/v1.4.8)

### v1.4.7

**Fixed:**

- **CI: Snyk security scan now passes green** — the Snyk SCA scan was crashing due to a dependency resolver bug in the Snyk Docker container (not an actual vulnerability in Anteroom). Switched to a workaround configuration (#126)

[GitHub Release](https://github.com/troylar/anteroom/releases/tag/v1.4.7)

### v1.4.6

**Fixed:**

- Fixed Windows mapped network drive paths resolving to blocked UNC paths. On Windows, accessing files on mapped drives (e.g., `X:\test` where `X:` maps to a network share) no longer triggers a false path-traversal block (#124)

[GitHub Release](https://github.com/troylar/anteroom/releases/tag/v1.4.6)

### v1.4.5

**Improved:**

- Hardened deploy workflow to handle recurring merge failures — auto-rebases, waits for CI, uses `--admin` only when non-required checks fail (#120)
- Fixed pre-push hook blocking version bump pushes with `--no-verify` (#120)
- Fixed zsh glob expansion error on `*.egg-info` cleanup (#120)

[GitHub Release](https://github.com/troylar/anteroom/releases/tag/v1.4.5)

### v1.4.4

**Fixed:**

- Fixed Rich markup injection in approval output — tool names containing brackets or colons (common with MCP tools) are now properly escaped (#111)

[GitHub Release](https://github.com/troylar/anteroom/releases/tag/v1.4.4)

### v1.4.3

**Fixed:**

- **UI hangs after MCP tool approval (#110)**: After approving MCP tool calls, the web UI could become completely unresponsive. This release fixes five interrelated issues (#110)
- **Stale stream detection** — when a browser tab disconnects or times out, the server now detects the stale SSE stream and cleans it up instead of blocking new requests (#110)
- **Thinking spinner stuck forever** — the "thinking" animation now correctly dismisses on all completion paths including errors and canvas operations (#110)

[GitHub Release](https://github.com/troylar/anteroom/releases/tag/v1.4.3)


---

## February 17, 2026

### v1.4.2

*Maintenance release — see GitHub Release for details.*

[GitHub Release](https://github.com/troylar/anteroom/releases/tag/v1.4.2)

### v1.4.1

**Fixed:**

- **MCP tool approval flow no longer stalls after clicking Allow.** Previously, after approving an MCP tool in the web UI, there was no visual feedback that the tool was executing. Now shows a progress indicator immediately (#108)
- **CLI approval prompt now accepts keyboard input.** The tool approval prompt in the CLI REPL was unresponsive — you couldn't type y/n/a/s. Fixed by integrating with prompt_toolkit's input handling (#108)

**Improved:**

- CLI banner now correctly shows **ANTEROOM** instead of the old project name, with the updated tagline "the secure AI gateway."

[GitHub Release](https://github.com/troylar/anteroom/releases/tag/v1.4.1)

### v1.4.0

**New:**

- **Tool Approval System**: A Claude Code-style safety gate for AI tool execution. Every tool is assigned a risk tier (read, write, execute, destructive), and the approval mode determines which tiers require user confirmation (#106)
- **4 risk tiers**: read (safe), write (modifies files), execute (runs code), destructive (irreversible)
- **4 approval modes**: `auto` (no prompts), `ask_for_dangerous` (destructive only), `ask_for_writes` (default — write+execute+destructive), `ask` (alias)

[GitHub Release](https://github.com/troylar/anteroom/releases/tag/v1.4.0)

### v1.3.1

**Fixed:**

- **New Chat button broken** — Clicking "New Chat" in the Web UI failed with a 415 error when no project was selected. The Content-Type header was only sent for project-scoped requests (#104)
- **CSP inline script blocked** — The Content Security Policy hash for the theme initialization script was stale, causing the browser to block it. Updated to match the current script content (#104)

[GitHub Release](https://github.com/troylar/anteroom/releases/tag/v1.3.1)

### v1.3.0

**New:**

- **Canvas Tools with Real-Time Streaming**: Anteroom now includes a canvas panel for AI-generated content alongside chat. When the AI writes code, documents, or structured content, it streams into a side panel in real time (#89)
- **Create canvas** — AI can open a canvas panel with any content (#89)
- **Update canvas** — Full content replacement for major revisions (#89)

**Improved:**

- Note and document conversation types for non-chat content (#89)
- Canvas CRUD API endpoints for programmatic access (#89)
- Product vision document (VISION.md) establishing project guardrails (#88)

[GitHub Release](https://github.com/troylar/anteroom/releases/tag/v1.3.0)


---

## February 16, 2026

### v1.2.0

**New:**

- **Semantic Search**: Anteroom now supports vector similarity search across your conversation history, powered by sqlite-vec. Search finds semantically related messages even when exact keywords don't match (#82)
- Semantic search API endpoints: `/api/search/semantic` and `/api/search/hybrid` (#82)
- Background embedding worker processes messages automatically using any OpenAI-compatible embedding API (#82)

[GitHub Release](https://github.com/troylar/anteroom/releases/tag/v1.2.0)

### v1.1.0

**New:**

- **Cryptographic Identity (#68)**: Every Anteroom user now gets a unique cryptographic identity — a UUID paired with an Ed25519 keypair. This is the foundation for future features like message signing and multi-user attribution (#68)
- UUID + Ed25519 keypair generated automatically on first run or via `aroom init` (#68)
- Private key stored securely in `config.yaml` (file permissions set to 0600) (#68)

[GitHub Release](https://github.com/troylar/anteroom/releases/tag/v1.1.0)


---

## February 15, 2026

### v0.9.1

*Maintenance release — see GitHub Release for details.*

[GitHub Release](https://github.com/troylar/anteroom/releases/tag/v0.9.1)

### v0.9.0

*Maintenance release — see GitHub Release for details.*

[GitHub Release](https://github.com/troylar/anteroom/releases/tag/v0.9.0)

### v0.8.3

*Maintenance release — see GitHub Release for details.*

[GitHub Release](https://github.com/troylar/anteroom/releases/tag/v0.8.3)

### v0.8.2

*Maintenance release — see GitHub Release for details.*

[GitHub Release](https://github.com/troylar/anteroom/releases/tag/v0.8.2)

### v0.8.1

*Maintenance release — see GitHub Release for details.*

[GitHub Release](https://github.com/troylar/anteroom/releases/tag/v0.8.1)

### v0.8.0

**New:**

- **Verbosity system**: Three display modes for tool calls — compact (default), detailed, and verbose
- **`/detail` command**: Replay last turn's tool calls with full arguments and output on demand
- **Live tool spinners**: Each tool call shows an animated spinner while executing

[GitHub Release](https://github.com/troylar/anteroom/releases/tag/v0.8.0)

### v0.7.2

**Fixed:**

- Connection failures now show descriptive error context instead of generic messages

[GitHub Release](https://github.com/troylar/anteroom/releases/tag/v0.7.2)

### v0.7.1

*Maintenance release — see GitHub Release for details.*

[GitHub Release](https://github.com/troylar/anteroom/releases/tag/v0.7.1)


---

## February 14, 2026

### v0.7.0

*Maintenance release — see GitHub Release for details.*

[GitHub Release](https://github.com/troylar/anteroom/releases/tag/v0.7.0)

### v0.6.9

*Maintenance release — see GitHub Release for details.*

[GitHub Release](https://github.com/troylar/anteroom/releases/tag/v0.6.9)

### v0.6.8

*Maintenance release — see GitHub Release for details.*

[GitHub Release](https://github.com/troylar/anteroom/releases/tag/v0.6.8)
