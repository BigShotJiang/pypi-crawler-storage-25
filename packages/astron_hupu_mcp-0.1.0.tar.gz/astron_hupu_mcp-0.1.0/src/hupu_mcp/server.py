"""Astron Hupu MCP server."""

from __future__ import annotations

import json
import os
import re
from datetime import datetime, timezone
from html import unescape
from html.parser import HTMLParser
from typing import Any
from urllib.parse import quote

import requests
from mcp.server.fastmcp import Context, FastMCP

from hupu_mcp import __version__


HOME_URL = "https://m.hupu.com/"
BBS_URL = "https://m.hupu.com/bbs/{content_id}.html"
USER_URL = "https://m.hupu.com/user/{author_id}"
SEARCH_URL = "https://m.hupu.com/search?keyword={query}"
THREAD_RE = re.compile(r"/bbs/(\d+)\.html")
USER_RE = re.compile(r"/user/([^/?#]+)")


class _NextDataParser(HTMLParser):
    """Collect __NEXT_DATA__ JSON from a Next.js page."""

    def __init__(self) -> None:
        super().__init__()
        self._in_target_script = False
        self._parts: list[str] = []

    def handle_starttag(self, tag: str, attrs: list[tuple[str, str | None]]) -> None:
        if tag != "script":
            return
        attrs_map = {key: value or "" for key, value in attrs}
        if attrs_map.get("id") == "__NEXT_DATA__":
            self._in_target_script = True
            self._parts = []

    def handle_data(self, data: str) -> None:
        if self._in_target_script:
            self._parts.append(data)

    def handle_endtag(self, tag: str) -> None:
        if tag == "script" and self._in_target_script:
            self._in_target_script = False

    def value(self) -> str:
        return "".join(self._parts).strip()


class _HTMLTextParser(HTMLParser):
    """Very small HTML-to-text helper."""

    def __init__(self) -> None:
        super().__init__()
        self._parts: list[str] = []

    def handle_data(self, data: str) -> None:
        self._parts.append(data)

    def text(self) -> str:
        return clean_text(unescape(" ".join(self._parts)))


def _current_iso() -> str:
    return datetime.now(tz=timezone.utc).astimezone().isoformat()


def get_timeout_seconds() -> float:
    raw = os.getenv("HUPU_MCP_TIMEOUT_SECONDS", "30").strip()
    try:
        value = float(raw)
    except ValueError as exc:
        raise RuntimeError("HUPU_MCP_TIMEOUT_SECONDS 必须是数字") from exc
    if value <= 0:
        raise RuntimeError("HUPU_MCP_TIMEOUT_SECONDS 必须大于 0")
    return value


def get_user_agent() -> str:
    value = os.getenv("HUPU_MCP_USER_AGENT", "").strip()
    if value:
        return value
    return (
        "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 "
        "(KHTML, like Gecko) Chrome/135.0.0.0 Safari/537.36 "
        f"Astron-Hupu-MCP/{__version__}"
    )


def create_session() -> requests.Session:
    session = requests.Session()
    session.headers.update(
        {
            "User-Agent": get_user_agent(),
            "Accept-Language": "zh-CN,zh;q=0.9",
        }
    )
    return session


def clean_text(value: Any) -> str:
    return " ".join(str(value or "").replace("\xa0", " ").split())


def strip_html(value: str) -> str:
    parser = _HTMLTextParser()
    parser.feed(value or "")
    return parser.text()


def to_int(value: Any) -> int | None:
    if value in (None, ""):
        return None
    try:
        return int(value)
    except (TypeError, ValueError):
        digits = re.sub(r"[^\d]", "", str(value))
        return int(digits) if digits else None


def unix_to_iso(value: int | str | None) -> str:
    if value in (None, ""):
        return ""
    try:
        timestamp = int(value)
    except (TypeError, ValueError):
        return ""
    return datetime.fromtimestamp(timestamp, tz=timezone.utc).astimezone().isoformat()


def extract_next_data(html: str) -> dict[str, Any]:
    parser = _NextDataParser()
    parser.feed(html)
    raw = parser.value()
    if not raw:
        return {}
    try:
        payload = json.loads(raw)
    except json.JSONDecodeError:
        return {}
    return payload if isinstance(payload, dict) else {}


def _request_text(
    session: requests.Session,
    url: str,
    *,
    referer: str = HOME_URL,
) -> str:
    try:
        response = session.get(
            url,
            headers={
                "Referer": referer,
                "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8",
            },
            timeout=get_timeout_seconds(),
        )
    except requests.RequestException as exc:
        raise RuntimeError(f"请求失败: {url}; error={exc}") from exc

    if response.status_code != 200:
        raise RuntimeError(
            f"调用失败: HTTP {response.status_code}; url={response.url}; body={response.text[:500]}"
        )
    return response.text


def _load_payload(session: requests.Session, url: str, error_message: str) -> dict[str, Any]:
    html = _request_text(session, url, referer=HOME_URL)
    payload = extract_next_data(html)
    if not payload:
        raise RuntimeError(error_message)
    return payload


def _normalize_limit(limit: int, *, maximum: int = 50) -> int:
    value = to_int(limit)
    if value is None:
        return 20
    return max(1, min(value, maximum))


def _page_props(payload: dict[str, Any]) -> dict[str, Any]:
    props = payload.get("props", {})
    if not isinstance(props, dict):
        return {}
    page_props = props.get("pageProps", {})
    return page_props if isinstance(page_props, dict) else {}


def _extract_content_id(content_id: str, url: str) -> str:
    value = clean_text(content_id)
    if value:
        return value
    match = THREAD_RE.search(url)
    return match.group(1) if match else ""


def _extract_author_id(author_id: str, url: str) -> str:
    value = clean_text(author_id)
    if value:
        return value
    match = USER_RE.search(url)
    return match.group(1) if match else ""


def _build_thread_url(content_id: str) -> str:
    return BBS_URL.format(content_id=content_id.strip())


def _build_user_url(author_id: str) -> str:
    return USER_URL.format(author_id=author_id.strip())


def _build_search_url(query: str) -> str:
    return SEARCH_URL.format(query=quote(query))


def _build_list_result(
    capability: str,
    items: list[dict[str, Any]],
    raw: dict[str, Any],
    *,
    has_more: bool = False,
    next_cursor: str = "",
) -> dict[str, Any]:
    return {
        "platform": "hupu",
        "capability": capability,
        "update_time": _current_iso(),
        "items": items,
        "paging": {
            "has_more": bool(has_more),
            "next_cursor": next_cursor if has_more else "",
        },
        "raw": raw,
    }


def _build_detail_result(item: dict[str, Any], raw: dict[str, Any]) -> dict[str, Any]:
    return {
        "platform": "hupu",
        "item": item,
        "raw": raw,
    }


def _build_author_result(author: dict[str, Any], raw: dict[str, Any]) -> dict[str, Any]:
    return {
        "platform": "hupu",
        "author": author,
        "raw": raw,
    }


def _parse_thread_item(item: dict[str, Any], rank: int) -> dict[str, Any]:
    title = clean_text(item.get("title", ""))
    label = clean_text(item.get("label", ""))
    replies = to_int(item.get("replies"))
    lights = to_int(item.get("lights"))
    visits = to_int(item.get("visits"))
    hot_value = replies if replies is not None else lights
    tid = clean_text(item.get("tid", "")) or title
    item_url = clean_text(item.get("url", ""))
    if not item_url and tid:
        item_url = _build_thread_url(tid)
    pics = item.get("pics", [])
    cover = ""
    if isinstance(pics, list) and pics:
        first_pic = pics[0]
        if isinstance(first_pic, dict):
            cover = clean_text(first_pic.get("url", ""))
        else:
            cover = clean_text(first_pic)
    publish_time = unix_to_iso(item.get("publish_time") or item.get("create_time") or item.get("lastpost_time"))
    author_name = clean_text(item.get("author_name", "")) or clean_text(item.get("nickname", ""))
    author_id = clean_text(item.get("author_id", "")) or clean_text(item.get("puid", ""))
    source_type = "news" if item.get("contentType") == 1 or str(item.get("type")) in {"mt", "news"} else "thread"
    tags = [
        tag
        for tag in [
            label,
            clean_text(item.get("topic_name", "")),
            clean_text(item.get("forum_name", "")),
        ]
        if tag
    ]
    return {
        "id": tid,
        "title": title,
        "summary": clean_text(item.get("summary", "")) or label or title,
        "content": clean_text(item.get("summary", "")) or title,
        "url": item_url,
        "cover": cover,
        "author_name": author_name,
        "author_id": author_id,
        "publish_time": publish_time,
        "rank": rank,
        "hot_value": hot_value,
        "hot_text": f"{hot_value} 回复" if hot_value is not None else "",
        "comment_count": replies,
        "like_count": lights,
        "share_count": to_int(item.get("share_num") or item.get("share")),
        "collect_count": None,
        "view_count": visits,
        "source_type": source_type,
        "tags": tags,
        "raw": item,
    }


def _rank_and_dedupe(items: list[dict[str, Any]]) -> list[dict[str, Any]]:
    result: list[dict[str, Any]] = []
    seen: set[str] = set()
    for item in items:
        item_id = clean_text(item.get("id", ""))
        if item_id and item_id in seen:
            continue
        if item_id:
            seen.add(item_id)
        result.append(item)
    for index, item in enumerate(result, start=1):
        item["rank"] = index
    return result


def _parse_thread_list_payload(payload: dict[str, Any], limit: int, *, capability: str) -> dict[str, Any]:
    safe_limit = _normalize_limit(limit)
    page_props = _page_props(payload)
    res = page_props.get("res", [])
    items: list[dict[str, Any]] = []
    if isinstance(res, list):
        for index, item in enumerate(res[:safe_limit], start=1):
            if isinstance(item, dict):
                items.append(_parse_thread_item(item, index))
    items = _rank_and_dedupe(items)
    has_more = isinstance(res, list) and len(res) > safe_limit
    return _build_list_result(capability, items, payload, has_more=has_more)


def fetch_hot_list_data(*, limit: int, refresh: bool) -> dict[str, Any]:
    del refresh
    session = create_session()
    payload = _load_payload(session, HOME_URL, "未能解析虎扑热帖首页")
    return _parse_thread_list_payload(payload, limit, capability="hot_list")


def fetch_feed_list_data(
    *,
    channel: str,
    cursor: str,
    limit: int,
    refresh: bool,
) -> dict[str, Any]:
    del channel, cursor, refresh
    session = create_session()
    payload = _load_payload(session, HOME_URL, "未能解析虎扑首页")
    return _parse_thread_list_payload(payload, limit, capability="feed_list")


def fetch_search_content_data(*, query: str, cursor: str, limit: int) -> dict[str, Any]:
    del cursor
    keyword = clean_text(query)
    if not keyword:
        raise RuntimeError("query 不能为空")
    safe_limit = _normalize_limit(limit)
    session = create_session()
    payload = _load_payload(session, _build_search_url(keyword), "未能解析虎扑搜索页")
    page_props = _page_props(payload)
    hot_info = page_props.get("hotInfo", {})
    items: list[dict[str, Any]] = []
    if isinstance(hot_info, dict):
        hot_list = hot_info.get("list", [])
        if isinstance(hot_list, list):
            for index, item in enumerate(hot_list[:safe_limit], start=1):
                if not isinstance(item, dict):
                    continue
                hot_keyword = clean_text(item.get("showName") or item.get("name") or "")
                if not hot_keyword:
                    continue
                items.append(
                    {
                        "id": hot_keyword,
                        "title": hot_keyword,
                        "summary": "虎扑搜索热词",
                        "content": keyword,
                        "url": _build_search_url(hot_keyword),
                        "cover": "",
                        "author_name": "",
                        "author_id": "",
                        "publish_time": "",
                        "rank": index,
                        "hot_value": None,
                        "hot_text": "热词",
                        "comment_count": None,
                        "like_count": None,
                        "share_count": None,
                        "collect_count": None,
                        "view_count": None,
                        "source_type": "search_keyword",
                        "tags": [],
                        "raw": item,
                    }
                )
    if not items:
        search_words = page_props.get("searchWords", [])
        if isinstance(search_words, list):
            for index, item in enumerate(search_words[:safe_limit], start=1):
                hot_keyword = clean_text(item.get("showName") if isinstance(item, dict) else item)
                if not hot_keyword and isinstance(item, dict):
                    hot_keyword = clean_text(item.get("name") or item.get("keyword") or "")
                if not hot_keyword:
                    continue
                items.append(
                    {
                        "id": hot_keyword,
                        "title": hot_keyword,
                        "summary": f"虎扑搜索词 - {keyword}",
                        "content": keyword,
                        "url": _build_search_url(hot_keyword),
                        "cover": "",
                        "author_name": "",
                        "author_id": "",
                        "publish_time": "",
                        "rank": index,
                        "hot_value": None,
                        "hot_text": "热词",
                        "comment_count": None,
                        "like_count": None,
                        "share_count": None,
                        "collect_count": None,
                        "view_count": None,
                        "source_type": "search_keyword",
                        "tags": [],
                        "raw": item if isinstance(item, dict) else {"keyword": item},
                    }
                )
    items = _rank_and_dedupe(items)
    return _build_list_result("search", items, {"query": keyword, "payload": payload})


def fetch_content_detail_data(*, content_id: str, url: str) -> dict[str, Any]:
    resolved_content_id = _extract_content_id(content_id, url)
    target_url = clean_text(url) or _build_thread_url(resolved_content_id)
    if not resolved_content_id and not target_url:
        raise RuntimeError("content_id 或 url 至少提供一个有效帖子标识")
    session = create_session()
    payload = _load_payload(session, target_url, "未能解析虎扑内容详情")
    page_props = _page_props(payload)
    thread_data = page_props.get("threadData", {})
    thread_info = page_props.get("threadInfo", {})
    thread_body = thread_info.get("t_detail", {}) if isinstance(thread_info, dict) else {}
    author_info = thread_info.get("t_author", {}) if isinstance(thread_info, dict) else {}
    basic_info = thread_data.get("data", {}).get("basicInfo", {}) if isinstance(thread_data, dict) else {}
    detail_source = thread_body if isinstance(thread_body, dict) and thread_body else {}
    content_html = strip_html(detail_source.get("content", ""))
    title = clean_text(
        detail_source.get("title")
        or basic_info.get("title")
        or resolved_content_id
    )
    author_name = clean_text(
        (detail_source.get("user", {}) or {}).get("username", "")
        or author_info.get("username", "")
        or (basic_info.get("author", {}) or {}).get("name", "")
    )
    author_id = clean_text(
        (detail_source.get("user", {}) or {}).get("puid", "")
        or author_info.get("puid", "")
        or (basic_info.get("author", {}) or {}).get("puid", "")
    )
    hot_value = to_int(detail_source.get("hits") or detail_source.get("replies") or detail_source.get("lights"))
    item = {
        "id": clean_text(detail_source.get("tid") or basic_info.get("tid") or resolved_content_id or target_url.rsplit("/", 1)[-1]),
        "title": title,
        "summary": content_html[:300] or title,
        "content": content_html or title,
        "url": target_url,
        "cover": "",
        "author_name": author_name,
        "author_id": author_id,
        "publish_time": unix_to_iso(detail_source.get("update") or basic_info.get("create_time")),
        "rank": 1,
        "hot_value": hot_value,
        "hot_text": clean_text(detail_source.get("lights", "")) or "",
        "comment_count": to_int(detail_source.get("replies")),
        "like_count": to_int(detail_source.get("lights")),
        "share_count": to_int(detail_source.get("share")),
        "collect_count": None,
        "view_count": to_int(detail_source.get("hits")),
        "source_type": "news" if detail_source.get("is_top") is not None else "thread",
        "tags": [],
        "raw": detail_source or thread_data or payload,
    }
    return _build_detail_result(item, {"url": target_url, "payload": payload})


def fetch_author_profile_data(*, author_id: str, url: str) -> dict[str, Any]:
    resolved_author_id = _extract_author_id(author_id, url)
    target_url = clean_text(url) or _build_user_url(resolved_author_id)
    if not resolved_author_id and not target_url:
        raise RuntimeError("author_id 或 url 至少提供一个")
    session = create_session()
    payload = _load_payload(session, target_url, "未能解析虎扑作者主页")
    page_props = _page_props(payload)
    user_info = page_props.get("userInfoData", {})
    if not isinstance(user_info, dict) or not user_info:
        raise RuntimeError("未能解析虎扑作者主页")
    profile_author_id = clean_text(page_props.get("puid") or user_info.get("puid") or resolved_author_id)
    bio_parts = [
        clean_text(user_info.get("bbsUserLevelDesc", "")),
        clean_text(user_info.get("reg_time_str", "")),
        clean_text(user_info.get("location_str", "") or user_info.get("location", "")),
    ]
    author = {
        "id": profile_author_id,
        "name": clean_text(user_info.get("nickname", "") or user_info.get("name", "")),
        "url": clean_text(user_info.get("shareUrl", "") or target_url),
        "avatar": clean_text(user_info.get("header", "")),
        "bio": " | ".join(part for part in bio_parts if part),
        "follower_count": to_int(user_info.get("be_follow_count")),
        "following_count": to_int(user_info.get("follow_count")),
        "content_count": to_int(user_info.get("bbs_post_count")),
        "raw": user_info,
    }
    return _build_author_result(author, {"url": target_url, "payload": payload})


def fetch_author_content_list_data(
    *,
    author_id: str,
    url: str,
    cursor: str,
    limit: int,
) -> dict[str, Any]:
    del cursor
    resolved_author_id = _extract_author_id(author_id, url)
    target_url = clean_text(url) or _build_user_url(resolved_author_id)
    if not resolved_author_id and not target_url:
        raise RuntimeError("author_id 或 url 至少提供一个")
    safe_limit = _normalize_limit(limit)
    session = create_session()
    payload = _load_payload(session, target_url, "未能解析虎扑作者帖子列表")
    page_props = _page_props(payload)
    thread_list = page_props.get("threadList", [])
    items: list[dict[str, Any]] = []
    if isinstance(thread_list, list):
        for index, item in enumerate(thread_list[:safe_limit], start=1):
            if isinstance(item, dict):
                items.append(_parse_thread_item(item, index))
    items = _rank_and_dedupe(items)
    has_more = isinstance(thread_list, list) and len(thread_list) > safe_limit
    return _build_list_result(
        "author_content_list",
        items,
        {"author_id": clean_text(page_props.get("puid") or resolved_author_id), "payload": payload},
        has_more=has_more,
    )


mcp = FastMCP(
    "HUPU_MCP",
    instructions=(
        "Astron Hupu MCP server，基于虎扑公开页面和公开 Next.js 页面数据提供公开内容工具能力，"
        "无需额外部署后端服务。"
    ),
)


@mcp.tool()
def get_hot_list(
    ctx: Context,
    limit: int = 20,
    refresh: bool = False,
) -> dict[str, Any]:
    """
    获取虎扑热帖。

    参数：
    - limit: 返回条数，范围建议 1-50。
    - refresh: 是否请求刷新数据。
    """
    del ctx
    return fetch_hot_list_data(limit=limit, refresh=refresh)


@mcp.tool()
def get_feed_list(
    ctx: Context,
    channel: str = "",
    cursor: str = "",
    limit: int = 20,
    refresh: bool = False,
) -> dict[str, Any]:
    """
    获取虎扑内容流。

    参数：
    - channel: 兼容保留参数，当前未启用。
    - cursor: 兼容保留参数，当前未启用。
    - limit: 返回条数，范围建议 1-50。
    - refresh: 是否请求刷新数据。
    """
    del ctx
    return fetch_feed_list_data(
        channel=channel,
        cursor=cursor,
        limit=limit,
        refresh=refresh,
    )


@mcp.tool()
def search_content(
    ctx: Context,
    query: str,
    cursor: str = "",
    limit: int = 20,
) -> dict[str, Any]:
    """
    搜索虎扑公开搜索热词。

    参数：
    - query: 搜索关键词。
    - cursor: 兼容保留参数，当前未启用。
    - limit: 返回条数，范围建议 1-50。
    """
    del ctx
    return fetch_search_content_data(query=query, cursor=cursor, limit=limit)


@mcp.tool()
def get_content_detail(
    ctx: Context,
    content_id: str = "",
    url: str = "",
) -> dict[str, Any]:
    """
    获取虎扑内容详情。

    参数：
    - content_id: 帖子 ID。
    - url: 内容完整 URL。
    """
    del ctx
    return fetch_content_detail_data(content_id=content_id, url=url)


@mcp.tool()
def get_author_profile(
    ctx: Context,
    author_id: str = "",
    url: str = "",
) -> dict[str, Any]:
    """
    获取虎扑作者主页。

    参数：
    - author_id: 作者 puid。
    - url: 作者主页 URL。
    """
    del ctx
    return fetch_author_profile_data(author_id=author_id, url=url)


@mcp.tool()
def get_author_content_list(
    ctx: Context,
    author_id: str = "",
    url: str = "",
    cursor: str = "",
    limit: int = 20,
) -> dict[str, Any]:
    """
    获取虎扑作者帖子列表。

    参数：
    - author_id: 作者 puid。
    - url: 作者主页 URL。
    - cursor: 兼容保留参数，当前未启用。
    - limit: 返回条数，范围建议 1-50。
    """
    del ctx
    return fetch_author_content_list_data(
        author_id=author_id,
        url=url,
        cursor=cursor,
        limit=limit,
    )


def main() -> None:
    """Run the MCP server over stdio."""
    mcp.run()


if __name__ == "__main__":
    main()
