# 虎扑公开内容 MCP Server

## 概述

`Astron-hupu-mcp` 是一个基于 MCP 协议的虎扑工具服务，直接请求虎扑公开页面，并从 Next.js 页面中的 `__NEXT_DATA__` 提取公开内容，无需额外部署后端服务。

当前工程形态：
- 使用 `MCP Python SDK`
- 使用单文件 `server.py` 承载工具定义和 HTTP 调用
- 通过独立 `pyproject` 打包
- 支持 `uvx` 一键启动
- 通过环境变量配置超时和 User-Agent

当前提供 6 个原子工具：
- `get_hot_list`
- `get_feed_list`
- `search_content`
- `get_content_detail`
- `get_author_profile`
- `get_author_content_list`


## 工具

### 1. 获取热帖 `get_hot_list`
- 描述：读取虎扑首页热帖。
- 参数：
  - `limit`：返回条数，默认 `20`
  - `refresh`：是否刷新，默认 `False`

### 2. 获取内容流 `get_feed_list`
- 描述：读取虎扑首页公开内容流。
- 参数：
  - `channel`：兼容保留参数，当前未启用
  - `cursor`：兼容保留参数，当前未启用
  - `limit`：返回条数，默认 `20`
  - `refresh`：是否刷新，默认 `False`

### 3. 搜索内容 `search_content`
- 描述：读取虎扑公开搜索页中的热词结果。
- 参数：
  - `query`：搜索词，必填
  - `cursor`：兼容保留参数，当前未启用
  - `limit`：返回条数，默认 `20`

### 4. 获取内容详情 `get_content_detail`
- 描述：读取虎扑帖子详情。
- 参数：
  - `content_id`：帖子 ID
  - `url`：内容完整 URL

### 5. 获取作者主页 `get_author_profile`
- 描述：读取虎扑用户公开主页。
- 参数：
  - `author_id`：作者 `puid`
  - `url`：用户主页 URL

### 6. 获取作者帖子列表 `get_author_content_list`
- 描述：读取虎扑作者公开帖子列表。
- 参数：
  - `author_id`：作者 `puid`
  - `url`：用户主页 URL
  - `cursor`：兼容保留参数，当前未启用
  - `limit`：返回条数，默认 `20`


## 环境变量

这个包默认不需要认证信息。

可选环境变量：

```bash
export HUPU_MCP_TIMEOUT_SECONDS="30"
export HUPU_MCP_USER_AGENT="Mozilla/5.0 ..."
```

说明：
- `HUPU_MCP_TIMEOUT_SECONDS` 控制公开页面请求超时。
- `HUPU_MCP_USER_AGENT` 用于覆盖默认请求头。


## 开始

### 推荐方式：使用 uvx 一键启动

```bash
uvx --from Astron-hupu-mcp hupu-mcp
```

如果你还没有安装 `uv` / `uvx`，可先执行：

```bash
curl -fsSL https://install.astral.sh/uv | bash
```

### 使用 pip 安装

```bash
pip install Astron-hupu-mcp
hupu-mcp
```

### 本地源码运行

```bash
cd hupu-mcp
PYTHONPATH=src python3 -m hupu_mcp.server
```


## MCP 客户端配置

### 使用 uvx

```json
{
  "mcpServers": {
    "hupu-mcp": {
      "command": "uvx",
      "args": ["--from", "Astron-hupu-mcp", "hupu-mcp"],
      "env": {
        "HUPU_MCP_TIMEOUT_SECONDS": "30"
      }
    }
  }
}
```

### 使用本地源码

```json
{
  "mcpServers": {
    "hupu-mcp": {
      "command": "python3",
      "args": ["-m", "hupu_mcp.server"],
      "env": {
        "PYTHONPATH": "/path/to/hupu-mcp/src",
        "HUPU_MCP_TIMEOUT_SECONDS": "30"
      }
    }
  }
}
```


## 说明

1. 这个 MCP 直接请求虎扑公开页面，不依赖额外的 Astron 后端服务。
2. 当前仅面向公开内容能力，不包含登录态、私有内容或用户专属数据。
3. `get_hot_list` 和 `get_feed_list` 当前都基于虎扑首页公开帖子流。
4. `search_content` 当前读取虎扑搜索页公开热词，而不是完整站内帖子搜索结果。
5. 公开页面结构如果发生变化，`__NEXT_DATA__` 解析可能需要跟着调整。


## 发布到 PyPI

```bash
cd hupu-mcp
rm -rf build dist src/*.egg-info
python3 -m build --no-isolation
python3 -m twine check dist/*
python3 -m twine upload dist/*
```


## License

Apache License 2.0. See `LICENSE`.
