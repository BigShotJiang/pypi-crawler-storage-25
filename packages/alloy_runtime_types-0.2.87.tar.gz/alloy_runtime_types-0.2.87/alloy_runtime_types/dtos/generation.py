"""DTOs for text generation endpoints."""

import ipaddress
import json
from datetime import datetime
from decimal import Decimal
from typing import Any, Literal, Self, cast
from urllib.parse import urlparse
from uuid import UUID

from pydantic import BaseModel, ConfigDict, Field, field_validator, model_validator

from alloy_runtime_types.dtos.managed_tools import (
    ManagedToolRequest,
    normalize_managed_tools,
    validate_unique_managed_tool_aliases,
)
from alloy_runtime_types.dtos.sessions import MessageResponse
from alloy_runtime_types.enums.provider import Provider
from alloy_runtime_types.enums.schema_enums import SchemaFormat
from alloy_runtime_types.model_option_allowlist import (
    PROTECTED_EXTRA_HEADERS,
    normalize_extra_headers,
    normalize_model_options,
)

type ReasoningEffort = Literal["none", "minimal", "low", "medium", "high", "xhigh"]


REASONING_EFFORT_VALUES: tuple[ReasoningEffort, ...] = (
    "none",
    "minimal",
    "low",
    "medium",
    "high",
    "xhigh",
)


# =============================================================================
# Output Schema Types (Union)
# =============================================================================


class InlineOutputSchema(BaseModel):
    """Inline output schema definition.

    Use this when you want to define a schema directly in the request
    without creating a reusable schema in the database.

    Examples:
        # JSON Schema for structured output
        InlineOutputSchema(
            schema_format=SchemaFormat.JSON_SCHEMA,
            schema_definition='{"type": "object", "properties": {"name": {"type": "string"}}}'
        )

        # Regex pattern for extraction
        InlineOutputSchema(
            schema_format=SchemaFormat.REGEX,
            schema_definition="```python\\n([\\s\\S]*?)\\n```"
        )
    """

    schema_format: SchemaFormat = Field(
        description="Type of schema: json_schema or regex"
    )
    schema_definition: str = Field(
        min_length=1,
        description="For json_schema: JSON string of the schema. For regex: the pattern string.",
    )


class SchemaReference(BaseModel):
    """Reference to an existing schema by ID or name.

    Use this when you have a pre-defined schema in the database.
    Names are resolved with priority: user-owned > org-owned > global.

    Examples:
        # Reference by UUID
        SchemaReference(schema_id="019377f5-1234-7000-8000-000000000001")

        # Reference by name
        SchemaReference(schema_id="my-response-schema")
    """

    schema_id: str | UUID = Field(
        description="Schema identifier - can be UUID or schema name. "
        "Names are resolved with priority: user-owned > org-owned > global."
    )


OutputSchemaSource = InlineOutputSchema | SchemaReference
"""Union for output schema specification.

Either define a schema inline (InlineOutputSchema) or reference an existing
schema by ID or name (SchemaReference). Pydantic automatically determines
which type based on the fields present.

JSON Examples:
    # Inline JSON Schema
    {"schema_format": "json_schema", "schema_definition": "{\\"type\\": \\"object\\"}"}

    # Inline Regex
    {"schema_format": "regex", "schema_definition": "```python\\\\n([\\\\s\\\\S]*?)\\\\n```"}

    # Reference by UUID
    {"schema_id": "019377f5-1234-7000-8000-000000000001"}

    # Reference by name
    {"schema_id": "my-response-schema"}
"""


MAX_USER_METADATA_BYTES = 16_384
BLOCKED_WEBHOOK_HOSTNAMES = frozenset({"localhost"})


def build_canonical_model(provider_key: str, provider_model_name: str) -> str:
    return f"{provider_key}/{provider_model_name}"


def parse_canonical_model(model: str) -> tuple[Provider, str]:
    provider_key, separator, provider_model_name = model.partition("/")
    if not separator or not provider_key or not provider_model_name:
        raise ValueError("model must use canonical <provider>/<model> format")
    provider = Provider.from_str(provider_key)
    if not provider_model_name.strip():
        raise ValueError("model must use canonical <provider>/<model> format")
    return provider, provider_model_name


class GenerationInputMessage(BaseModel):
    role: Literal["system", "user", "assistant"]
    content: str = Field(min_length=1)


class GenerateTextRequest(BaseModel):
    model_config = ConfigDict(extra="forbid", populate_by_name=True)

    model: str | None = Field(
        default=None,
        min_length=1,
        description="Canonical direct-model identity in <provider>/<model> format.",
    )
    agent_id: str | UUID | None = Field(
        default=None,
        description="Agent identifier - can be UUID or agent name. "
        "Names are resolved with priority: user-owned > org-owned > global.",
    )

    prompt: str | None = Field(
        default=None,
        min_length=1,
        description="Direct prompt text. If contains Jinja2 syntax ({{ }}, {% %}), "
        "will be rendered using prompt_variables.",
    )
    prompt_template_id: str | UUID | None = Field(
        default=None,
        description="Prompt template identifier - can be UUID or template name. "
        "Names are resolved with priority: user-owned > org-owned > global.",
    )
    input: str | list[GenerationInputMessage] | None = Field(
        default=None,
        description="Alternative compiled input source. Use a string for a direct prompt "
        "or a message list ending with a user message. Message-list input is a "
        "convenience alias for prompt + chat_history + optional leading system message.",
    )
    prompt_variables: dict[str, Any] | None = Field(
        default=None,
        description="Variables for prompt_template_id or inline Jinja syntax in prompt.",
    )

    system: str | None = Field(
        default=None,
        min_length=1,
        description="Direct system instruction for convenience-mode requests.",
    )
    system_template_id: str | UUID | None = Field(
        default=None,
        description="System instruction template identifier - can be UUID or template name. "
        "Names are resolved with priority: user-owned > org-owned > global.",
    )
    system_variables: dict[str, Any] | None = Field(
        default=None,
        description="Variables for system_template_id or inline Jinja syntax in system.",
    )

    # Tools (for direct model usage)
    tools: list[Any] | None = None
    managed_tools: list[ManagedToolRequest] | None = None

    output_schema: OutputSchemaSource | None = Field(
        default=None,
        description="Output schema for structured output. Can be an inline definition "
        "(InlineOutputSchema) or a reference to an existing schema (SchemaReference). "
        "JSON schema output cannot be used with streaming. "
        "Cannot be specified when using an agent (agents have their own output schema).",
    )

    # Context
    chat_session_id: UUID | None = None
    parent_execution_id: UUID | None = None
    chat_history: list[dict[str, str]] | None = None
    max_history_messages: int | None = Field(
        default=None,
        gt=0,
        le=1000,
        description="Limit chat history to N most recent messages",
    )

    regenerate: bool = Field(
        default=False,
        description="If True, regenerate response to the last user message in the session. "
        "Requires chat_session_id. Previous assistant response will be excluded from context.",
    )

    stream: bool = False

    model_options: dict[str, Any] | None = Field(
        default=None,
        description="Flat allowlisted model options passed to the selected model.",
    )
    extra_headers: dict[str, str] | None = Field(
        default=None,
        description="Additional string-valued HTTP headers for the upstream model request.",
    )

    # Tags
    tags: list[str] = Field(
        default_factory=list,
        description="Tag paths for generated content (e.g., ['marketing.email'])",
    )

    # External ID
    external_id: str | None = Field(
        default=None,
        description="Optional caller-provided identifier for idempotency and correlation. "
        "Must be unique per organization. Use to track processed items.",
    )

    # Pipeline Execution ID
    pipeline_execution_id: UUID | None = Field(
        default=None,
        description="Pipeline execution ID for lineage tracking. "
        "Set automatically by SDK for pipeline-originated calls.",
    )

    # Billing Project
    billing_project_id: str | UUID | None = Field(
        default=None,
        description="Optional billing project identifier for cost tracking and aggregation. "
        "Can be UUID or project name within the authenticated organization.",
    )

    # Execution Purpose
    execution_purpose: str | None = Field(
        default=None,
        min_length=1,
        description="Label for why this execution exists (e.g., 'pipeline_step'). "
        "Defaults to 'agent' if not specified. Auto-set to 'pipeline_step' for pipeline executions.",
    )
    artifact_policy: Literal["full", "stateless"] = Field(
        default="full",
        description="Controls whether chat/session and render artifacts are persisted. "
        "Use 'stateless' to keep only the execution record and structured output.",
    )

    # Async Generation
    run_async: bool = Field(
        default=False,
        alias="async",
        description="If True, queue generation for background processing and return immediately. "
        "Returns 202 Accepted with execution_id for polling. Cannot be used with stream=True.",
    )
    include_tool_call_details: bool = Field(
        default=False,
        description="If True, include tool call details in the response metadata. "
        "Only available for non-streaming, non-async requests.",
    )
    show_full_trace: bool = Field(
        default=False,
        description="If True, include the ordered message trace for the generated turn. "
        "Only available for non-streaming, non-async requests with persisted artifacts.",
    )
    user_metadata: dict[str, Any] | None = Field(
        default=None,
        description="Optional user-provided metadata attached to the async execution. "
        "Returned in status polling responses and webhook payloads.",
    )
    webhook_url: str | None = Field(
        default=None,
        max_length=2048,
        description="Optional webhook URL to receive completion notification. "
        "POST request with a signed webhook event envelope whose data field matches "
        "the terminal AsyncGenerationStatusResponse shape when generation completes.",
    )

    @field_validator("webhook_url")
    @classmethod
    def validate_webhook_url(cls, value: str | None) -> str | None:
        if value is None:
            return value

        parsed = urlparse(value)
        if parsed.scheme.lower() != "https":
            raise ValueError("webhook_url must use HTTPS scheme")

        hostname = parsed.hostname
        if hostname is None:
            raise ValueError("webhook_url must have a valid hostname")

        normalized_hostname = hostname.rstrip(".").lower()
        if normalized_hostname in BLOCKED_WEBHOOK_HOSTNAMES:
            raise ValueError(
                "webhook_url must not target private or reserved addresses"
            )

        try:
            ip_address = ipaddress.ip_address(normalized_hostname)
        except ValueError:
            return value

        if (
            ip_address.is_private
            or ip_address.is_reserved
            or ip_address.is_loopback
            or ip_address.is_link_local
            or ip_address.is_unspecified
        ):
            raise ValueError(
                "webhook_url must not target private or reserved addresses"
            )

        return value

    @field_validator("user_metadata")
    @classmethod
    def validate_user_metadata_size(
        cls,
        value: dict[str, Any] | None,
    ) -> dict[str, Any] | None:
        if value is None:
            return value

        serialized = json.dumps(value, separators=(",", ":"), ensure_ascii=False)
        if len(serialized.encode("utf-8")) > MAX_USER_METADATA_BYTES:
            raise ValueError(
                "user_metadata must not exceed "
                f"{MAX_USER_METADATA_BYTES} bytes when serialized"
            )
        return value

    @field_validator("model_options")
    @classmethod
    def validate_model_options(
        cls,
        value: dict[str, Any] | None,
    ) -> dict[str, Any] | None:
        if value is None:
            return value

        return normalize_model_options(value)

    @field_validator("extra_headers", mode="before")
    @classmethod
    def validate_extra_headers(cls, value: Any) -> Any:
        if value is None or not isinstance(value, dict):
            return value

        return normalize_extra_headers(
            value,
            lowercase_keys=True,
            protected_headers=PROTECTED_EXTRA_HEADERS,
        )

    @field_validator("input")
    @classmethod
    def validate_raw_input_string(
        cls, value: str | list[GenerationInputMessage] | None
    ):
        if isinstance(value, str) and not value.strip():
            raise ValueError("input string cannot be empty or whitespace-only")
        return value

    @field_validator("model")
    @classmethod
    def validate_canonical_model(cls, value: str | None) -> str | None:
        if value is None:
            return value
        provider, provider_model_name = parse_canonical_model(value)
        return build_canonical_model(provider.value, provider_model_name)

    @model_validator(mode="after")
    def validate_request_shape(self) -> Self:
        normalized_managed_tools = normalize_managed_tools(self.managed_tools)
        self.managed_tools = cast(
            list[ManagedToolRequest] | None,
            normalized_managed_tools,
        )
        selection_count = int(self.model is not None) + int(self.agent_id is not None)
        if selection_count != 1:
            raise ValueError("Exactly one of model or agent_id must be provided")

        content_count = sum(
            (
                self.prompt is not None,
                self.prompt_template_id is not None,
                self.input is not None,
                self.regenerate,
            )
        )
        if content_count != 1:
            raise ValueError(
                "Exactly one of prompt, prompt_template_id, input, or regenerate must be provided"
            )

        if self.regenerate and self.chat_session_id is None:
            raise ValueError("chat_session_id is required when regenerate=True")

        if self.input is not None and any(
            value is not None
            for value in (
                self.prompt_variables,
                self.system,
                self.system_template_id,
                self.system_variables,
            )
        ):
            raise ValueError(
                "input cannot be combined with top-level prompt/system convenience fields"
            )

        if isinstance(self.input, list):
            if not self.input:
                raise ValueError("input message lists must not be empty")
            if self.chat_history is not None:
                raise ValueError(
                    "input message lists cannot be combined with top-level chat_history"
                )
            system_indices = [
                index
                for index, message in enumerate(self.input)
                if message.role == "system"
            ]
            if system_indices and system_indices != [0]:
                raise ValueError(
                    "input message lists may include at most one system message, and it must be first"
                )
            if self.input[-1].role != "user":
                raise ValueError("input message lists must end with a user message")

        if self.stream and self.run_async:
            raise ValueError(
                "stream=True and async=True are mutually exclusive. "
                "Use streaming for real-time responses or async for background processing."
            )
        if self.stream and self.artifact_policy == "stateless":
            raise ValueError(
                "artifact_policy='stateless' is not supported with stream=True"
            )

        if self.include_tool_call_details and self.stream:
            raise ValueError(
                "include_tool_call_details=True is not supported with stream=True"
            )
        if self.include_tool_call_details and self.run_async:
            raise ValueError(
                "include_tool_call_details=True is not supported with async=True"
            )
        if self.show_full_trace and self.stream:
            raise ValueError("show_full_trace=True is not supported with stream=True")
        if self.show_full_trace and self.run_async:
            raise ValueError("show_full_trace=True is not supported with async=True")
        if self.show_full_trace and self.artifact_policy == "stateless":
            raise ValueError(
                "show_full_trace=True is not supported with artifact_policy='stateless'"
            )

        if normalized_managed_tools is None:
            return self

        if self.agent_id is not None:
            raise ValueError("managed_tools requires direct model source")

        if self.stream:
            raise ValueError("managed_tools cannot be used with stream=True")

        if self.tools is not None:
            raise ValueError("tools and managed_tools are mutually exclusive")

        validate_unique_managed_tool_aliases(
            normalized_managed_tools,
            field_name="managed_tools",
        )
        return self


class TokenUsageDTO(BaseModel):
    """Token usage information."""

    input_tokens: int
    output_tokens: int
    reasoning_tokens: int | None = None
    cache_creation_tokens: int | None = None
    cache_read_tokens: int | None = None


class CostBreakdownDTO(BaseModel):
    """Cost breakdown for execution."""

    input_cost_usd: Decimal
    output_cost_usd: Decimal
    cache_cost_usd: Decimal | None = None
    total_cost_usd: Decimal


class GenerationFullTrace(BaseModel):
    finish_reason: str
    messages: list[MessageResponse]


class GenerateTextResponse(BaseModel):
    """Response from non-streaming text generation."""

    model_config = ConfigDict(extra="forbid")

    execution_id: UUID
    chat_session_id: UUID | None = None
    assistant_message_id: UUID | None = None
    primary_content_part_id: UUID | None = None
    output_text: str
    output_incomplete: bool = False
    full_trace: GenerationFullTrace | None = None
    structured_output: dict[str, Any] | None = None
    usage: TokenUsageDTO
    cost: CostBreakdownDTO
    finish_reason: str
    model: str
    tags: list[str]
    external_id: str | None = None
    metadata: dict[str, Any] = Field(default_factory=dict)

    @field_validator("model")
    @classmethod
    def validate_model(cls, value: str) -> str:
        parse_canonical_model(value)
        return value


class GenerateTextStreamChunk(BaseModel):
    """Individual chunk from streaming generation (SSE payload)."""

    model_config = ConfigDict(extra="forbid")

    execution_id: UUID
    sequence: int
    content: str
    chunk_type: str = "text"  # text, thinking, metadata, error
    is_first: bool = False
    reasoning_content: str | None = (
        None  # Reasoning/thinking content for models that support it
    )
    metadata: dict[str, Any] = Field(default_factory=dict)


# =============================================================================
# Async Generation DTOs
# =============================================================================


# Async generation status type alias
AsyncGenerationStatus = Literal[
    "pending", "running", "completed", "failed", "cancelled", "timeout"
]

# Terminal statuses - indicates polling should stop
TERMINAL_ASYNC_STATUSES: frozenset[AsyncGenerationStatus] = frozenset(
    {"completed", "failed", "cancelled", "timeout"}
)


def is_terminal_async_status(status: AsyncGenerationStatus) -> bool:
    """Check if an async generation status is terminal (polling should stop)."""
    return status in TERMINAL_ASYNC_STATUSES


class AsyncGenerationSubmitResponse(BaseModel):
    """Response returned when async generation is submitted (HTTP 202).

    Returned when run_async=True in GenerateTextRequest. The client should
    poll GET /generate/{execution_id} for status updates.
    """

    execution_id: UUID
    status: str = "pending"
    message: str = "Generation queued"
    user_metadata: dict[str, Any] | None = None
    external_id: str | None = None
    webhook_signing_secret: str | None = None


class AsyncGenerationStatusResponse(BaseModel):
    """Response from polling async generation status.

    Returned by GET /generate/{execution_id}. Fields are populated
    as the generation progresses. Check is_terminal to know when to stop polling.
    """

    model_config = ConfigDict(extra="forbid")

    execution_id: UUID
    status: AsyncGenerationStatus
    is_terminal: bool = Field(
        description="True when generation reached terminal status (completed, failed, cancelled, timeout). "
        "Clients should stop polling when this is True."
    )
    # Populated when completed
    chat_session_id: UUID | None = None
    assistant_message_id: UUID | None = None
    primary_content_part_id: UUID | None = None
    output_text: str | None = None
    output_incomplete: bool = False
    structured_output: dict[str, Any] | None = None
    usage: TokenUsageDTO | None = None
    cost: CostBreakdownDTO | None = None
    finish_reason: str | None = None
    model: str | None = None
    # Timing
    queued_at: datetime
    pending_for_ms: int | None = None
    started_at: datetime | None = None
    completed_at: datetime | None = None
    total_duration_ms: int | None = None
    # User context
    user_metadata: dict[str, Any] | None = None
    external_id: str | None = None
    metadata: dict[str, Any] | None = None
    # Error info (when failed)
    error_message: str | None = None
    error_type: str | None = None

    @field_validator("model")
    @classmethod
    def validate_model(cls, value: str | None) -> str | None:
        if value is not None:
            parse_canonical_model(value)
        return value


class AsyncGenerationCancelResponse(BaseModel):
    """Response from cancelling an async generation.

    Returned by DELETE /generate/{execution_id}. Only pending or running
    generations can be cancelled.
    """

    execution_id: UUID
    status: str = "cancelled"
    message: str = "Generation cancelled"
    was_running: bool = Field(
        description="True if generation was actively running when cancelled. "
        "False if it was still pending in queue."
    )
