# Wrapper on `optax.GradientTransformationExtraArgs` to carry info about
# wether to use NGD gradient_step() in solve (instead of regular)

import equinox as eqx
import optax
import jinns
import jax
import jax.numpy as jnp

from jinns.optimizers._utils_ngd import Component, _reweight_pytree
from jinns.optimizers._utils_ngd import (
    assemble_ngd_gram_matrix_and_euclidean_gradient,
    params_array_to_pytree,
)


class NGDState(eqx.Module):
    """A custom state for Natural Gradient Descent.

    Useful internally: it tells `jinns` when to trigger NGD. All custom NGD optimizer state
    should inherit this.
    """

    tx_state: optax.OptState  # optimizer state


class VanillaNGDState(NGDState):
    """State for vanilla Natural Gradient Descent with ridge regularization.

    Parameters
    ----------
    sgd_learning_rate: float, default = 1.0
        The learning rate for the standard gradient descent algorithm run
        before the linesearch step
    ridge_reg: float, default = 1.0
        The ridge regularization coefficient used to improved the conditioning
        of the Gram matrix that is inverted in the NGD procedure
    with_eq_params_update: bool, default = True
        A boolean specifying if the updates for `params.eq_params` should be applied or not.
        If True, we are in inverse problem mode and euclidean gradient for eq_params are passed
        to the optimizer. If False, we are in forward problem mode and they are set to zero.
        This is useful in `solve_alternate`, as users may want to perform NGD on nn_params
        while leaving the eq_params untouched during a few steps.
    """

    sgd_learning_rate: float = 1.0
    ridge_reg: float = 1e-5  # small ridge regularization on diag(G) when inverting
    with_eq_params_update: bool = eqx.field(static=True, default=False)


def vanilla_ngd(
    *,
    sgd_learning_rate: float = 1.0,
    gram_reg: float = 1e-5,
    linesearch: optax.GradientTransformationExtraArgs = optax.scale_by_backtracking_linesearch(
        max_backtracking_steps=15, verbose=True
    ),
    eq_params_tx: dict | None = None,
) -> optax.GradientTransformationExtraArgs:
    r"""jinns implementation of vanilla Natural Gradient Descent (NGD).

    See e.g. [Johannes Müller, Marius Zeinhofer - Achieving High Accuracy with PINNs via Energy Natural Gradient Descent](https://proceedings.mlr.press/v202/muller23b/muller23b.pdf)

    This vanilla implementation uses a ridge regularization on the diagonal of $G$ before solving
    the linear system.

    $$
        \eta = (\hat{G} + \lambda I_p)^{-1} \nabla_{\nu} \mathcal{L}(\nu).
    $$


    Parameters
    ----------
    sgd_learning_rate
        the starting learning rate multiply the NGD update, by default 1.0
    gram_reg
        the ridge regularization used before inverting the Gram matrix, by default 1e-5
    linesearch
        it is recommended to use a linesearch method that computes a learning rate,
        a.k.a. stepsize, to satisfy some criterion such as a sufficient decrease of the objective
        by additional calls to the objective
        by default optax.scale_by_backtracking_linesearch(max_backtracking_steps=15, verbose=True)
    eq_params_tx
        optional dictionnary of optax optimizers for each eq_params, by default None which means eq_params are not updated (forward problem)

    Returns
    -------
    optax.GradientTransformationExtraArgs
        the vanilla ngd optimizer with a special signature for the `update(r_g_sw, ngd_state, params, loss, batch,
        loss_value)` function. Here

         * the update `r_g_sw` is a 3-tuple with the 1) residuals $r(x_i)$ *per-sample*, 2) the gradient $\partial_\nu \rho_{\nu}(x_i)$ *per-sample*, and 3) the sample weights $w_i$
         * the `loss` is a `jinns.loss.LossXDE` object
         * `batch` is the current batch of point
    """
    if linesearch is None:
        linesearch_ = optax.identity()
    else:
        linesearch_ = linesearch

    ngd_optim_ = optax.chain(
        optax.sgd(learning_rate=sgd_learning_rate),
        linesearch_,
    )
    if eq_params_tx is not None:
        # In the line below, parameters that are not updated are assigned the
        # "freeze" label. The "freeze" label is then associated to the null
        # update. We resort to the "freeze" label when a None value is found.
        # see https://github.com/google-deepmind/optax/blob/main/examples/freezing_parameters.ipynb
        param_labels = jinns.parameters.Params(
            nn_params="ngd",
            eq_params={
                key: (key if val is not None else "freeze")
                for key, val in eq_params_tx.items()
            },
        )

        ngd_optim = optax.partition(
            {
                **{
                    "ngd": ngd_optim_,
                },
                **{
                    (key if val is not None else "freeze"): (
                        val if val is not None else optax.set_to_zero()
                    )
                    for key, val in eq_params_tx.items()
                },
            },
            param_labels,
            mask_compatible_extra_args=True,  # https://github.com/google-deepmind/optax/issues/1649
        )
        with_eq_params_update = True
    else:
        ngd_optim = ngd_optim_
        with_eq_params_update = False

    def init(params: optax.Params) -> VanillaNGDState:
        return VanillaNGDState(
            tx_state=ngd_optim.init(params),
            sgd_learning_rate=sgd_learning_rate,
            ridge_reg=gram_reg,
            with_eq_params_update=with_eq_params_update,
        )

    def update(
        r_g_sw: tuple[Component, Component, Component],
        ngd_state: VanillaNGDState,
        params,
        loss,
        batch,
        loss_value,
        **_,
    ) -> tuple[optax.Updates, VanillaNGDState]:
        # -- Compute the necessary quantities from r, g
        r, g, sqrt_weights_per_sample = r_g_sw
        gram_mat, euclidean_grad_array_nn, euclidean_grad_array_eq = (
            assemble_ngd_gram_matrix_and_euclidean_gradient(
                r=r,
                g=g,
                sqrt_weights_per_sample=sqrt_weights_per_sample,
                with_eq_params_update=ngd_state.with_eq_params_update,
            )
        )

        # --
        # Solve the linear system (G + reg * I) @ natural_grad = eucl_grad to get
        # the nn_params natural gradient.
        reg: float = ngd_state.ridge_reg
        n_param = gram_mat.shape[0]
        natural_grad_array_nn = jax.scipy.linalg.solve(
            gram_mat + reg * jnp.eye(n_param), euclidean_grad_array_nn, assume_a="sym"
        )

        # --
        # Final step : restructure the natural gradient as a Params PyTree
        # NOTE: if in inverse problem mode, the leaf at eq_params is filled with standard euclidean
        # gradients, and zeros if in forward problem mode.

        ngd_pytree = params_array_to_pytree(
            natural_grad_array_nn, params, euclidean_grad_array_eq
        )

        # ---
        # In case of linesearch, we need euclidean grad + value_fn
        euclidean_grads = params_array_to_pytree(
            euclidean_grad_array_nn, params, euclidean_grad_array_eq
        )

        def ngd_value_fn(params):
            """ """
            # Not using loss.evaluate here cause of the mean(sum()) vs sum(mean)
            # remark. This fn computes the loss we are truly minimizing with NGD.
            new_r = loss.evaluate_per_sample(
                params,
                batch,
            )
            total_loss = jnp.sum(
                jnp.concatenate(
                    jax.tree.leaves(
                        jax.tree.map(
                            lambda arr: jnp.sum(arr**2, axis=-1),
                            _reweight_pytree(
                                new_r, sqrt_weights_per_sample
                            ),  # `r` changes !
                        ),
                    ),
                    axis=0,
                )
            )
            return total_loss

        if ngd_state.with_eq_params_update:
            # Following https://github.com/google-deepmind/optax/issues/1649
            # to handle the optax partition doing some masking:
            # -> We need to pass the full params (`params`) because opt_params might contain
            # None at eq_params, which would fail the last instruction
            # NOTE that this is a specific manipulation when using optax
            # partition for linesearch and this is NOT linked with jinns masking induced by
            # jinns.solve_alternate()
            def fill_eq_params_value_fn(ngd_value_fn, params):
                """Reconstructs the full parameter tree from the masked one.
                Specific case: this is always eq_params that will be masked
                """

                def wrapper(
                    masked_params_for_linesearch,
                ):  # this is what will be called by the
                    # backtracking line search callback
                    # ie., it will contain masked params that we need to fill in
                    full_params = eqx.tree_at(
                        lambda pt: pt.eq_params,
                        masked_params_for_linesearch,
                        params.eq_params,
                    )
                    return ngd_value_fn(full_params)

                return wrapper

            value_fn = fill_eq_params_value_fn(ngd_value_fn, params)
        else:
            # if we are not doing an inverse problem, there is no optax.partition
            # to handle
            value_fn = ngd_value_fn

        tx_state = ngd_state.tx_state
        ngd_pytree, new_tx_state = ngd_optim.update(
            ngd_pytree,  # type: ignore
            tx_state,
            params,
            # extra kwargs passed to backtracking line search `update()` method
            value=loss_value,
            grad=euclidean_grads,
            value_fn=value_fn,
        )

        return (
            ngd_pytree,
            eqx.tree_at(lambda pt: pt.tx_state, ngd_state, new_tx_state),
        )

    return optax.GradientTransformationExtraArgs(
        init,  # type: ignore
        update,  # type: ignore
    )
