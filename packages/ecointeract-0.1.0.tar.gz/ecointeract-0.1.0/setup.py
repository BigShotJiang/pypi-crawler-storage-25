from setuptools import setup, find_packages

setup(
    name='ecointeract',
    version='0.1.0',
    description='A Python library for ecological data collection and environmental analysis',
    long_description=open('USAGE.md').read(),
    long_description_content_type='text/markdown',
    author='Ane Simões',
    author_email='anes.2017@alunos.utfpr.edu.br',
    packages=find_packages(),
    install_requires=[
        "ee",
        "pandas",
        "requests",
        "networkx",
        "duckdb",
    ],
    license='MIT',
    python_requires='>=3.7',
)