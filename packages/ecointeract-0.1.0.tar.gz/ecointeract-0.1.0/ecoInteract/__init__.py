from .getgraph import get_interaction_data
__all__ = [
    "get_interaction_data"
]
def version():
    return "0.0.1"
def  describe ():
    description = (
        "Eco Interactions Library\n"
        "Version: {}\n"
        "Implement functions to get interactions data from species:\n"
        " - get_interaction_data\n"
     ). format (version())
    print (description)
    return description