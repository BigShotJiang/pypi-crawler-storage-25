import duckdb
import networkx as nx
import os
import sys
import requests
from pathlib import Path
path_root = Path(__file__).resolve().parent
# Define the stable URL for the GloBI interactions dataset and the local DB file name
GLOBI_TSV_GZ_URL = "https://zenodo.org/record/14640564/files/interactions.tsv.gz"
DUCKDB_FILE = f"{path_root}/interactions.duckdb"

def resolve_redirect(url: str) -> str:
    """Follows redirects and returns the final URL."""
    response = requests.head(url, allow_redirects=True)
    return response.url

def setup_globi_duckdb() -> None:
    if os.path.exists(DUCKDB_FILE):
        print(f"Database file '{DUCKDB_FILE}' already exists. Skipping setup.")
        return

    print("Resolving download URL...")
    final_url = resolve_redirect(GLOBI_TSV_GZ_URL)
    print(f"Resolved URL: {final_url}")

    try:
        with duckdb.connect(database=DUCKDB_FILE, read_only=False) as con:
            con.execute("INSTALL httpfs;")
            con.execute("LOAD httpfs;")
            con.execute("""
                SET http_keep_alive=false;
            """)
            con.execute(f"""
                CREATE TABLE interactions AS
                SELECT
                    sourceTaxonName,
                    interactionTypeName,
                    targetTaxonName
                FROM read_csv('{final_url}',
                             delim='\t',
                             header=True,
                             compression='gzip',
                             quote='',
                             escape='',
                             ignore_errors=true);
            """)
            print("Database setup complete.")

    except Exception as e:
        print(f"An error occurred during database setup: {e}", file=sys.stderr)
        if os.path.exists(DUCKDB_FILE):
            os.remove(DUCKDB_FILE)
        sys.exit(1)

def get_interactions_graph(species_name: str, depth: int, con: duckdb.DuckDBPyConnection) -> nx.DiGraph:
    """
    Builds an interaction graph for a given species up to a specified depth
    using a local GloBI DuckDB database.

    Args:
        species_name: The scientific name of the starting species.
        depth: The maximum depth of interactions to explore from the start species.
        con: An active DuckDB connection object.

    Returns:
        A NetworkX DiGraph object representing the interaction network.
    """
    if depth < 1:
        print("Depth must be 1 or greater.", file=sys.stderr)
        return nx.DiGraph()

    graph = nx.DiGraph()
    nodes_to_process = {species_name}
    all_known_nodes = {species_name}

    for i in range(depth):
        current_depth = i + 1
        if not nodes_to_process:
            print(f"No new nodes to explore at depth {current_depth}. Halting search.")
            break

        print(f"Processing depth {current_depth}/{depth}. Querying for {len(nodes_to_process)} species...")

        # Use parameterized queries to handle species names safely
        placeholders = ', '.join(['?'] * len(nodes_to_process))
        query = f"""
            SELECT DISTINCT sourceTaxonName, interactionTypeName, targetTaxonName
            FROM interactions
            WHERE sourceTaxonName IN ({placeholders})
               OR targetTaxonName IN ({placeholders})
        """
        
        # Parameters list must be duplicated for the two 'IN' clauses
        params = list(nodes_to_process) * 2
        results_df = con.execute(query, params).fetchdf()

        if results_df.empty:
            print(f"No new interactions found for species at depth {current_depth}.")
            continue

        print(f"Found {len(results_df)} new interactions.")
        newly_found_nodes = set()
        for _, row in results_df.iterrows():
            source = row['sourceTaxonName']
            target = row['targetTaxonName']
            interaction = row['interactionTypeName']

            # Add the interaction as a directed edge to the graph
            graph.add_edge(source, target, type=interaction)

            # Identify new species to explore in the next iteration
            if source not in all_known_nodes:
                newly_found_nodes.add(source)
            if target not in all_known_nodes:
                newly_found_nodes.add(target)
        
        # Update node sets for the next iteration
        all_known_nodes.update(newly_found_nodes)
        nodes_to_process = newly_found_nodes

    return graph

# --- Main execution block ---
def get_interaction_data(
    target_species: str,
    search_depth: int = 3,
    interaction_type: str | list[str] | None = None,
) -> nx.DiGraph | None:
    """
    Builds the interaction graph for a target species.

    Parameters
    ----------
    target_species : str
        The species to search interactions for.
    search_depth : int
        Depth of the interaction graph traversal.
    interaction_type : str | list[str] | None
        Filter by interaction type(s). If None, returns all interactions.

    Returns
    -------
    nx.DiGraph or None if no interactions are found.
    """
    setup_globi_duckdb()

    if search_depth > 3:
        print("The informed search depth is high, expect some delay.")

    if isinstance(interaction_type, str):
        type_filter = {interaction_type}
    elif isinstance(interaction_type, list):
        type_filter = set(interaction_type)
    else:
        type_filter = None

    try:
        with duckdb.connect(database=DUCKDB_FILE, read_only=True) as connection:
            interaction_graph = get_interactions_graph(
                species_name=target_species,
                depth=search_depth,
                con=connection,
            )

            if interaction_graph.number_of_nodes() == 0:
                return None

            depth_map = nx.single_source_shortest_path_length(
                interaction_graph, target_species
            )

            nx.set_node_attributes(interaction_graph, depth_map, name="depth")

            if type_filter is None:
                return interaction_graph

            filtered_edges = [
                (s, t)
                for s, t, data in interaction_graph.edges(data=True)
                if data.get("type") in type_filter
            ]

            if not filtered_edges:
                return None

            return interaction_graph.edge_subgraph(filtered_edges).copy()

    except Exception as e:
        print(f"An error occurred during graph construction: {e}", file=sys.stderr)
        return None