import networkx as nx
from pyvis.network import Network
import math

# --- 1. Create a more complex NetworkX graph ---
# This graph will represent a small ecosystem.
g_nx = nx.DiGraph()

# Add nodes (species)
species = ["Oak Tree", "Grass", "Rabbit", "Squirrel", "Deer", "Fox", "Wolf", "Fungi"]
g_nx.add_nodes_from(species)

# Add edges (interactions) with attributes
# The dictionary contains the 'type' which will be used as the edge label.
edges = [
    # --- Predation / Consumption ---
    # (Source) eats (Target)
    ("Rabbit", "Grass", {"type": "Eats"}),
    ("Squirrel", "Oak Tree", {"type": "Eats"}),
    ("Deer", "Grass", {"type": "Eats"}),
    ("Deer", "Oak Tree", {"type": "Eats"}),
    ("Fox", "Rabbit", {"type": "Eats"}),
    ("Fox", "Squirrel", {"type": "Eats"}),
    ("Wolf", "Deer", {"type": "Eats"}),
    ("Wolf", "Rabbit", {"type": "Eats"}),

    # --- Competition (Symmetric) ---
    # (Source) competes with (Target)
    ("Rabbit", "Deer", {"type": "Competes"}),
    ("Deer", "Rabbit", {"type": "Competes"}),
    ("Fox", "Wolf", {"type": "Competes"}),
    ("Wolf", "Fox", {"type": "Competes"}),

    # --- Decomposition ---
    # (Source) decomposes (Target)
    ("Fungi", "Oak Tree", {"type": "Decomposes"}),
    ("Fungi", "Grass", {"type": "Decomposes"}),
    ("Fungi", "Rabbit", {"type": "Decomposes"}),
    ("Fungi", "Squirrel", {"type": "Decomposes"}),
    ("Fungi", "Deer", {"type": "Decomposes"}),
    ("Fungi", "Fox", {"type": "Decomposes"}),
    ("Fungi", "Wolf", {"type": "Decomposes"}),

    # --- Other Interactions ---
    ("Squirrel", "Oak Tree", {"type": "Shelters in"})
]

for source, target, attr in edges:
    g_nx.add_edge(source, target, title=attr["type"], label=attr["type"])

# --- 2. Calculate Eigenvector Centrality ---
# This metric identifies nodes that are connected to other highly connected nodes.
# It's a measure of influence within the network.
try:
    # max_iter is increased to help with convergence in some graphs
    centrality = nx.eigenvector_centrality(g_nx, max_iter=1000)
except nx.PowerIterationFailedConvergence:
    # Fallback for graphs where eigenvector centrality doesn't converge
    print("Eigenvector centrality did not converge, falling back to degree centrality.")
    centrality = nx.degree_centrality(g_nx)


# --- 3. Create a Pyvis network for visualization ---
net = Network(height="800px", width="100%", directed=True, notebook=True, cdn_resources='remote')

# --- 4. Add nodes to Pyvis graph, with size based on centrality ---
# We'll scale the centrality score to make the size difference more visible.
scaling_factor = 100

for node, centr_score in centrality.items():
    # The 'value' attribute in pyvis scales the node size
    node_size = centr_score * scaling_factor
    
    # Ensure size is not NaN or too small to be visible
    if math.isnan(node_size) or node_size < 5:
        node_size = 5

    net.add_node(
        node,
        label=node,
        value=node_size,
        title=f"Centrality: {centr_score:.4f}" # Hover text shows the score
    )

# --- 5. Add edges to Pyvis graph with labels ---
for source, target, data in g_nx.edges(data=True):
    net.add_edge(
        source,
        target,
        label=data.get('label', ''),
        title=data.get('title', '')
    )

# --- 6. Customize physics and generate the HTML file ---
net.show_buttons(filter_=['physics'])
net.show("ecosystem_centrality_graph.html")

print("Generated 'ecosystem_centrality_graph.html'. Open this file in your browser.")