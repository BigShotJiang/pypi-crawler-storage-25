"""Rendering helpers for GNU/Tcl environment modulefiles."""

from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path


def tcl_quote(value: str) -> str:
    """Quote a string for the small Tcl subset used in modulefiles."""
    escaped = value.replace("\\", "\\\\").replace('"', '\\"').replace("$", "\\$")
    return f'"{escaped}"'


@dataclass(frozen=True)
class ModuleSpec:
    """Data required to render one versioned environment modulefile."""

    name: str
    version: str
    root: Path
    bin_dir: Path
    description: str | None = None
    family: str | None = None
    homepage: str | None = None
    install_hint: str | None = None

    @property
    def module_path(self) -> str:
        """Return the canonical module name/version path."""
        return f"{self.name}/{self.version}"


def render_modulefile(spec: ModuleSpec) -> str:
    """Render a Tcl modulefile for the given module specification."""
    description = spec.description or f"{spec.name} {spec.version}"
    lines = [
        "#%Module1.0",
        f"## {spec.module_path}",
        "",
        "proc ModulesHelp { } {",
        f"    puts stderr {tcl_quote(description)}",
    ]

    if spec.homepage:
        lines.append(f"    puts stderr {tcl_quote('Homepage: ' + spec.homepage)}")
    if spec.install_hint:
        lines.append(f"    puts stderr {tcl_quote('Install: ' + spec.install_hint)}")

    lines.extend(
        [
            "}",
            "",
            f"module-whatis {tcl_quote(description)}",
        ]
    )

    if spec.family:
        lines.append(f"family {tcl_quote(spec.family)}")

    lines.extend(
        [
            "",
            f"set root {tcl_quote(str(spec.root))}",
            f"set bindir {tcl_quote(str(spec.bin_dir))}",
            "",
            "prepend-path PATH $bindir",
            f"setenv {spec.name.upper().replace('-', '_')}_ROOT $root",
            "",
        ]
    )
    return "\n".join(lines)
