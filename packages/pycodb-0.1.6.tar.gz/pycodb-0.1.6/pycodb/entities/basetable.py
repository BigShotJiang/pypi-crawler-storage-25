import requests
import mimetypes

class BaseTable:
    def __init__(self, domain, headers, view_id, table_id):
        self.view_id = view_id
        self.headers = headers
        self.endpoint = f'http://{domain}/api/v2/tables/{table_id}/records'

    def _get(self, fields=None, **kwargs):
        url_query = f'{self.endpoint}?viewId={self.view_id}&limit=1000&shuffle=0'

        if fields:
            url_query += f'&fields={",".join(fields)}'

        if kwargs:
            expressions = '&'.join([f'{k}={v}' for k, v in kwargs.items()])
            url_query += f'&{expressions}'

        response = requests.get(url_query, headers=self.headers)
        response.raise_for_status()

        data = response.json()
        return data.get('list', []) if isinstance(data, dict) else data

    def _append(self, target: dict):
        response = requests.post(self.endpoint, headers=self.headers, json=target)
        response.raise_for_status()
        return response.json()

    def _update(self, target: dict):
        response = requests.patch(self.endpoint, headers=self.headers, json=target)
        response.raise_for_status()
        return response.json()

    def _delete(self, target: dict):
        response = requests.delete(self.endpoint, headers=self.headers, json=target)
        response.raise_for_status()
        return response.json()

    def _upload(self, file_bytes, filename):
        upload_url = self.endpoint.split('/tables/')[0] + '/storage/upload'

        mime_type, _ = mimetypes.guess_type(filename)
        mime_type = mime_type or 'application/octet-stream'

        files = {'file': (filename, file_bytes, mime_type)}

        response = requests.post(upload_url, headers=self.headers, files=files)
        response.raise_for_status()

        return response.json()