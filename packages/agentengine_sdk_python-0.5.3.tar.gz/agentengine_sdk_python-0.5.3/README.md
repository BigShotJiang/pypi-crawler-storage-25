# agentengine-sdk-python

**Kingsoft Cloud Agent Engine SDK** - 别名包

这是 [ksadk](https://pypi.org/project/ksadk/) 的别名包，安装后会自动安装对应版本的 ksadk。

当前版本：`0.5.1`

## 安装

```bash
# 任选一种方式安装
pip install agentengine-sdk-python
# 或
pip install ksadk
```

## 使用

```bash
agentengine --help
```

更多文档请参考 [ksadk](https://github.com/kingsoftcloud/ksadk-python)。
