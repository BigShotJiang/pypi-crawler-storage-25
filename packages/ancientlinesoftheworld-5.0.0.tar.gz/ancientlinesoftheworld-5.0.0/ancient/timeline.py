from datetime import datetime
from .mappings import (
    convert_to_cuneiform,
    convert_to_pahlavi,
    convert_to_manichaean,
    convert_to_hieroglyph,
    convert_to_akkadian,
    convert_to_oracle_bone,
    convert_to_avestan,
    convert_to_brahmi,
    convert_to_kharosthi,
    convert_to_runic
)


class AncientTimeline:
    """
    نمایش تایم‌لاین (زمان کنونی) با خطوط باستانی هخامنشی/اوستایی
    نویسنده: امیرحسین خزاعی
    """

    # ماه‌های هخامنشی (پارسی باستان)
    _hakhāmanišiya_months = {
        1: "Ādukanaiša",    # مارس-آوریل
        2: "Thūravāhara",   # آوریل-مه
        3: "Thāigaciš",     # مه-ژوئن
        4: "Garmapada",     # ژوئن-ژوئیه
        5: "Drnabāji",      # ژوئیه-اوت
        6: "Kārbāšiya",     # اوت-سپتامبر
        7: "Bāgayādi",      # سپتامبر-اکتبر
        8: "Vrkazana",      # اکتبر-نوامبر
        9: "Āçiyādiya",     # نوامبر-دسامبر
        10: "Anāmaka",      # دسامبر-ژانویه
        11: "Samiyama",     # ژانویه-فوریه
        12: "Viyaxana",     # فوریه-مارس
    }
    
    # اعداد هخامنشی (میخی پارسی باستان)
    _numbers_hakhāmanišiya = {
        '0': '𐏐',      # جداکننده
        '1': '𐏑',
        '2': '𐏒',
        '3': '𐏓',
        '4': '𐏔',
        '5': '𐏕',
        '6': '𐏑𐏒',
        '7': '𐏑𐏓',
        '8': '𐏑𐏔',
        '9': '𐏑𐏕',
        '10': '𐏒𐏐',
    }
    
    # روزهای هفته هخامنشی
    _hakhāmanišiya_weekdays = {
        "Saturday": "𐎠𐎼𐎶𐎫𐎡𐎹",    # Ārmaitiya
        "Sunday": "𐎠𐎢𐎼𐎶𐏀𐎭𐎠",    # Auramazdā
        "Monday": "𐎠𐎼𐎫𐎠",         # Artā
        "Tuesday": "𐎭𐎠𐎫𐎢𐏁",      # Dātauš
        "Wednesday": "𐎠𐎼𐎡𐎹𐎶𐎴",  # Ariyaman
        "Thursday": "𐎺𐎡𐎰𐎡𐎼𐎠",   # Vīthirā
        "Friday": "𐎠𐎴𐎠𐎡𐎫𐎠",     # Anāhitā
    }

    def __init__(self, script: str = 'cuneiform', ancient_format: bool = False):
        self.supported_scripts = [
            'cuneiform', 'pahlavi', 'manichaean',
            'hieroglyph', 'akkadian', 'oracle_bone', 'avestan',
            'runic','brahmi','kharosthi','runic']

        if script not in self.supported_scripts:
            raise ValueError(
                f"❌ زبان نامعتبر است.\nگزینه‌های معتبر:\n{self.supported_scripts}"
            )

        self.script = script
        self.ancient_format = ancient_format

    def _convert_number_to_hakhāmanišiya(self, num: int) -> str:
        """تبدیل عدد به فرمت میخی هخامنشی"""
        if num == 0:
            return self._numbers_hakhāmanišiya['0']
        
        result = []
        num_str = str(num)
        
        for digit in num_str:
            if digit in self._numbers_hakhāmanišiya:
                result.append(self._numbers_hakhāmanišiya[digit])
            else:
                result.append(digit)
        
        return ''.join(result)

    def _format_pure_ancient_cuneiform(self, now: datetime) -> str:
        """
        فرمت خالص و واقعی هخامنشی - بدون هیچ متن فارسی یا انگلیسی
        فقط نمادهای میخی پارسی باستان
        """
        # دریافت مقادیر
        year = now.year
        month_num = now.month
        day = now.day
        hour = now.hour
        minute = now.minute
        second = now.second
        
        # دریافت نام ماه به خط میخی (تبدیل نام به میخی)
        month_name = self._hakhāmanišiya_months[month_num]
        month_cuneiform = convert_to_cuneiform(month_name)
        
        # دریافت نام روز هفته به خط میخی
        weekday_name = now.strftime("%A")
        weekday_cuneiform = self._hakhāmanišiya_weekdays.get(weekday_name, convert_to_cuneiform(weekday_name))
        
        # تبدیل اعداد به میخی هخامنشی
        year_cuneiform = self._convert_number_to_hakhāmanišiya(year)
        day_cuneiform = self._convert_number_to_hakhāmanišiya(day)
        hour_cuneiform = self._convert_number_to_hakhāmanišiya(hour)
        minute_cuneiform = self._convert_number_to_hakhāmanišiya(minute)
        second_cuneiform = self._convert_number_to_hakhāmanišiya(second)
        
        # قالب کاملاً باستانی هخامنشی (بدون کلمه انگلیسی)
        # الگو: [روز هفته] [روز] [ماه] [سال] [ساعت:دقیقه:ثانیه]
        ancient_pattern = (
            f"{weekday_cuneiform} 𐏐 "      # روز هفته
            f"{day_cuneiform} 𐏐 "           # روز ماه
            f"{month_cuneiform} 𐏐 "         # ماه
            f"{year_cuneiform} 𐏐 "          # سال
            f"{hour_cuneiform}:{minute_cuneiform}:{second_cuneiform}"  # زمان
        )
        
        return ancient_pattern

    def _convert_text(self, text: str) -> str:
        """تبدیل متن به خط باستانی انتخاب شده"""
        if self.script == 'cuneiform':
            return convert_to_cuneiform(text)
        elif self.script == 'pahlavi':
            return convert_to_pahlavi(text)
        elif self.script == 'manichaean':
            return convert_to_manichaean(text)
        elif self.script == 'hieroglyph':
            return convert_to_hieroglyph(text)
        elif self.script == 'akkadian':
            return convert_to_akkadian(text)
        elif self.script == 'oracle_bone':
            return convert_to_oracle_bone(text)
        elif self.script == "avestan":
            return convert_to_avestan(text)
        
        elif self.script == 'kharosthi':
            return convert_to_kharosthi(text)
        elif self.script == "brahmi":
            return convert_to_brahmi(text)
        
        elif self.script == "runic":
            return convert_to_runic(text)
        
        return text

    def get_ancient_time(self) -> str:
        now = datetime.now()
        
        if self.ancient_format:
            # حالت ویژه: نمایش خالص و واقعی هخامنشی
            if self.script == 'cuneiform':
                # برای خط میخی، فرمت خالص هخامنشی را برمی‌گردانیم
                pure_ancient = self._format_pure_ancient_cuneiform(now)
                return pure_ancient
            else:
                # برای سایر خطوط باستانی
                formatted = now.strftime("%Y/%m/%d %H:%M:%S")
                return self._convert_text(formatted)
        else:
            # حالت عادی
            formatted = now.strftime("%Y-%m-%d | %H:%M:%S")
            return self._convert_text(formatted)

    def show(self):
        print("\n━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━")
        print("        📜 Ancient Timeline")
        print("━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━")
        print(f"🔹 Script      : {self.script}")
        print(f"🔹 Ancient Mode: {self.ancient_format}")
        
        ancient_time = self.get_ancient_time()
        
        if self.ancient_format and self.script == 'cuneiform':
            print("\n🔸 خالص ترین فرمت هخامنشی:")
            print(f"\n   {ancient_time}\n")
            print("\n📖 ترجمه (برای درک):")
            now = datetime.now()
            print(f"   {now.strftime('%A')} {now.day} {self._hakhāmanišiya_months[now.month]} {now.year}")
            print(f"   ساعت {now.hour}:{now.minute}:{now.second}")
        else:
            print(f"🔸 Time        :\n{ancient_time}")
        
        print("━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\n")

    def as_text(self):
        return self.get_ancient_time()