import time
import sys
from typing import Callable, Optional
from .core import AncientScripts


class AncientAnimator:
    """
    انیمیشن خطوط باستانی - بهینه شده برای همه پلتفرم‌ها
    کار می‌کند در: Terminal, Jupyter, Colab, Web, GUI
    """

    def __init__(self, delay: float = 0.14):
        """
        delay: تأخیر بین هر کاراکتر (بر حسب ثانیه)
        """
        self.delay = delay
        self.conv = AncientScripts()
        
        self.script_methods = {
            "pahlavi": self.conv.pahlavi,
            "cuneiform": self.conv.cuneiform,
            "manichaean": self.conv.manichaean,
            "hieroglyph": self.conv.hieroglyph,
            "hebrew": self.conv.hebrew,
            "linear_b": self.conv.linear_b,
            "akkadian": self.conv.akkadian,
            "oracle_bone": self.conv.oracle_bone,
            "avestan": self.conv.avestan,
            "brahmi": self.conv.brahmi,
            "runic": self.conv.runic,
            "kharosthi": self.conv.kharosthi,
            "sanskrit": self.conv.sanskrit,
        }
        
        # تشخیص محیط اجرا
        self._is_jupyter = self._check_jupyter()

    def _check_jupyter(self) -> bool:
        """تشخیص Jupyter/Colab - import داخل تابع"""
        try:
            from IPython import get_ipython  # ← اینجا import کن
            if get_ipython() and 'IPKernelApp' in get_ipython().config:
                return True
        except:
            pass
        return False

    def convert(self, text: str, script: str) -> str:
        """تبدیل متن به خط باستانی"""
        if script not in self.script_methods:
            raise ValueError(f"خط '{script}' پشتیبانی نمی‌شود.")
        return self.script_methods[script](text)

    def animate_chars(
        self,
        converted_text: str,
        output_func: Optional[Callable[[str], None]] = None
    ):
        """
        نمایش کاراکتر به کاراکتر با تاخیر
        output_func: تابع callback برای دریافت خروجی (وب/GUI)
        """
        full_text = ""
        
        for ch in converted_text:
            full_text += ch
            
            if output_func:
                # حالت وب یا GUI
                output_func(full_text)
            else:
                # حالت ترمینال / Jupyter
                if self._is_jupyter:
                    # روش مخصوص Jupyter - import داخل try
                    try:
                        from IPython.display import clear_output  # ← اینجا import کن
                        clear_output(wait=True)
                        print(full_text, end='')
                    except:
                        print(full_text, end='')
                else:
                    # ترمینال استاندارد
                    sys.stdout.write('\r' + full_text)
                    sys.stdout.flush()
            
            time.sleep(self.delay)
        
        # خط جدید در انتها (فقط برای ترمینال)
        if not output_func and not self._is_jupyter:
            print()

    def run(
        self,
        text: str,
        script: str,
        output_func: Optional[Callable[[str], None]] = None
    ):
        """
        text: متن ورودی
        script: خط باستانی
        output_func: تابع callback برای هر مرحله (اختیاری)
        """
        converted = self.convert(text, script)
        
        if output_func is None:
            print("\n--- شروع نوشتن باستانی ---\n")
        
        self.animate_chars(converted, output_func)
        
        if output_func is None:
            print("\n--- تمام شد ---\n")