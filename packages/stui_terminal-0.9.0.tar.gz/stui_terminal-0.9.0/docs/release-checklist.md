# Release Checklist

Use this checklist for public releases of `stui-terminal`, the PyPI
distribution that provides the `stui` import package and `stui` command.

`stui` is not official Streamlit, is not affiliated with Streamlit, and is not a
Streamlit compatibility layer.

## Decide Release Type

- Patch: bugs, docs, examples, tests, packaging, or project metadata.
- Minor: new public APIs, new widgets, or meaningful behavior additions.
- Breaking: do not ship before 1.0 unless a severe correctness or safety issue
  requires it.

If a change adds API surface, it is not a patch release.

## Pre-Release Triage

- Review open bug reports and recent discussions on Monday or Tuesday when
  possible.
- Confirm any release-blocking issue has a reproducible case.
- Move broad feature ideas into feedback collection instead of rushing them into
  the release.
- Check docs for honest scope: terminal-native, Streamlit-inspired, not
  Streamlit-compatible, no browser/server/runtime Streamlit dependency.

## Local Verification

Run from the repository root:

```bash
. .venv/bin/activate
python -m pip install -e ".[dev]"
ruff check .
python3.11 -m pytest
python -m build
python -m twine check dist/*
stui --version
python -m stui --version
./scripts/check.sh
git diff --check
```

For package publishing, also follow `docs/publishing.md`.

## Installed-Package Verification

Before publishing, verify the current public package still installs cleanly:

```bash
python3.11 -m venv /tmp/stui-current
/tmp/stui-current/bin/python -m pip install --upgrade pip
/tmp/stui-current/bin/python -m pip install --index-url https://pypi.org/simple --no-cache-dir stui-terminal
/tmp/stui-current/bin/python -c "import stui; print(stui.__version__)"
/tmp/stui-current/bin/stui --version
/tmp/stui-current/bin/stui doctor --json
/tmp/stui-current/bin/stui examples
/tmp/stui-current/bin/stui example list
/tmp/stui-current/bin/stui example copy basic /tmp/stui-basic.py
/tmp/stui-current/bin/stui init /tmp/stui-app.py
```

After publishing, repeat the same check with the exact released version, for
example `stui-terminal==0.9.0`.

## Tag, CI, Publish, Release

1. Commit only after local verification is green.
2. Create and push the release tag, for example `v0.9.0`.
3. Wait for CI on `main` and the tag.
4. Dispatch the `Publish` workflow from the release tag with exactly one publish
   flag enabled.
5. Approve the protected PyPI environment only after CI, build, Twine, security,
   and fresh-wheel checks are green.
6. Confirm PyPI JSON and the Simple API show the new release.
7. Verify a clean install from PyPI with the exact version.
8. Create the GitHub Release from the matching `RELEASE_NOTES_*.md` file.

## v0.9 And v1 Release Gates

Before tagging v0.9.0 or v1.0.0, confirm:

- Version metadata, README, `CHANGELOG.md`, release notes, and
  `docs/v1-readiness.md` all name the same release.
- Stable and experimental API labels agree across README,
  `docs/api-reference.md`, `docs/api-stability.md`, and public API tests.
- `stui-terminal` remains the PyPI distribution name; `stui` remains the import
  package and CLI command.
- The public docs preserve the non-affiliation and non-compatibility language:
  not official Streamlit, not affiliated with Streamlit, and not a Streamlit
  compatibility layer.
- No browser, server, websocket, port-forwarding, Streamlit runtime, GPL slider
  code, or `textual-slider` dependency has been introduced.
- Installed-package flows work without a repository checkout: `stui examples`,
  `stui example list`, `stui example copy`, and `stui init`.
- Terminal compatibility evidence or explicit test-needed labels are current in
  `docs/terminal-compatibility.md`.
- Public launch-style announcement copy is not generated for pre-v1 releases.

For v1.0.0 specifically, also confirm the final checklist in
[`docs/v1-readiness.md`](v1-readiness.md#final-v10-checklist).

## Public Copy

Before publishing release notes, confirm they do not imply:

- Official Streamlit affiliation.
- Streamlit compatibility.
- Browser, server, websocket, or port-forwarding support.
- Production maturity beyond the current tested surface.
- Widget or layout coverage that does not exist yet.

## Release Window

- Monday and Tuesday are best for triage and final release decision-making.
- Midweek is best for small bug, docs, example, and metadata fixes.
- Friday and the weekend should be patch-only, and only when a real fix needs to
  reach users.

## After Release

Pause feature churn for several days after this release.

During the pause:

- Let users try the package in real terminal environments.
- Collect terminal feedback: rendering, keyboard behavior, SSH/container quirks,
  and color/readability issues.
- Collect API feedback: whether the current widget, callback, rerun, and
  `session_state` model feels simple enough.
- Patch reproducible bugs or docs/package metadata mistakes.
- Defer large features until enough feedback shows the next API direction.
