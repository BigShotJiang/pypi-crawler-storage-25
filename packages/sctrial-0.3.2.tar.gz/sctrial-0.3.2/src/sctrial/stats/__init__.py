"""Statistical modules for trial-aware single-cell inference.

This subpackage provides the core statistical methods for analyzing
clinical trial data with single-cell resolution.

Core Methods
------------
- **did_table**: Difference-in-Differences with fixed effects
- **abundance_did**: Cell-type proportion changes
- **within_arm_comparison**: Paired longitudinal contrasts
- **between_arm_comparison**: Cross-sectional arm comparisons

Advanced Methods
----------------
- **did_table_mixed**: Mixed effects DiD models
- **trend_interaction**: Multi-timepoint trend analysis
- **event_study_did**: Generalized event study design
- **loo_cv_did**: Leave-one-out cross-validation
- **kfold_cv_did**: K-fold cross-validation

Effect Sizes & Power
--------------------
- **add_effect_sizes_to_did**: Cohen's d / Hedge's g for DiD
- **power_did** / **power_paired**: Power calculations (two-arm DiD / single-arm paired)
- **sample_size_did** / **sample_size_paired**: Sample size determination
- **sensitivity_paired**: Minimum detectable effect size for paired designs
"""

from .abundance import abundance_did
from .bayes import did_table_bayes, prior_predictive_check
from .comparisons import (
    between_arm_comparison,
    compare_gene_in_celltype,
    get_within_arm_aggregated_df,
    within_arm_comparison,
    within_arm_fit_beta,
)
from .cv import cv_summary, influence_diagnostics, kfold_cv_did, loo_cv_did
from .diagnostics import check_did_assumptions
from .did import (
    DiDConfig,
    did_fit,
    did_table,
    did_table_by_celltype,
    did_table_parallel,
    get_did_aggregated_df,
)
from .effect_size import (
    add_effect_sizes_to_did,
    bootstrap_effect_size_ci,
    cohens_d,
    cohens_d_from_did,
    cohens_d_from_did_approx,
    effect_size_ci,
    hedges_g,
)
from .gsea import (
    run_gsea_cross_sectional,
    run_gsea_did,
    run_gsea_did_by_celltype,
    run_gsea_did_multi,
    run_gsea_pseudobulk,
    run_gsea_within_arm,
)
from .heterogeneity import test_treatment_heterogeneity
from .mixed_effects import compare_fixed_vs_mixed, did_mixed, did_table_mixed
from .module_scores import (
    module_score_did_by_pool,
    module_score_pseudobulk,
    module_score_within_arm_by_pool,
)
from .power import (
    design_effect,
    effective_sample_size,
    power_curve,
    power_did,
    power_paired,
    sample_size_did,
    sample_size_paired,
    sensitivity_analysis,
    sensitivity_paired,
)
from .pseudobulk import (
    pseudobulk_did,
    pseudobulk_export,
    pseudobulk_expression,
    pseudobulk_within_arm,
)
from .sensitivity import e_value_rr
from .summary import summarize_did_results
from .survival import hazard_regression_with_features
from .timeseries import event_study_did, polynomial_trend, test_parallel_trends, trend_interaction

__all__ = [
    # Core DiD
    "did_table",
    "did_fit",
    "did_table_by_celltype",
    "did_table_parallel",
    "did_table_bayes",
    "prior_predictive_check",
    "DiDConfig",
    "abundance_did",
    "run_gsea_did",
    "run_gsea_did_multi",
    "run_gsea_did_by_celltype",
    "run_gsea_pseudobulk",
    "run_gsea_cross_sectional",
    "run_gsea_within_arm",
    "within_arm_comparison",
    "between_arm_comparison",
    "get_did_aggregated_df",
    "get_within_arm_aggregated_df",
    "within_arm_fit_beta",
    "summarize_did_results",
    "pseudobulk_expression",
    "pseudobulk_within_arm",
    "pseudobulk_did",
    "pseudobulk_export",
    "module_score_pseudobulk",
    "module_score_did_by_pool",
    "module_score_within_arm_by_pool",
    "compare_gene_in_celltype",
    # Effect sizes
    "cohens_d",
    "hedges_g",
    "cohens_d_from_did",
    "cohens_d_from_did_approx",
    "effect_size_ci",
    "add_effect_sizes_to_did",
    "bootstrap_effect_size_ci",
    # Power analysis
    "power_did",
    "power_paired",
    "sample_size_did",
    "sample_size_paired",
    "sensitivity_analysis",
    "sensitivity_paired",
    "power_curve",
    "design_effect",
    "effective_sample_size",
    # Mixed effects
    "did_mixed",
    "did_table_mixed",
    "compare_fixed_vs_mixed",
    "test_treatment_heterogeneity",
    "e_value_rr",
    # Time series
    "trend_interaction",
    "event_study_did",
    "polynomial_trend",
    "test_parallel_trends",
    # Cross-validation
    "loo_cv_did",
    "kfold_cv_did",
    "influence_diagnostics",
    "cv_summary",
    # Diagnostics
    "check_did_assumptions",
    # Survival
    "hazard_regression_with_features",
]
