# Changelog

All notable changes to this project will be documented in this file.

The format is based on [Keep a Changelog](https://keepachangelog.com/en/1.0.0/),
and this project adheres to [Semantic Versioning](https://semver.org/spec/v2.0.0.html).

## [Unreleased]

### Added
- N/A

### Changed
- N/A

### Fixed
- N/A

### Security
- N/A

## [0.2.0] - 2026-04-09

### Added
- **Embedding model validation on startup**: MCP server now validates the embedding model when connecting to Qdrant. If fastembed is not installed or model download fails, server exits with clear error message
- **Custom embedding cache directory**: New `EMBEDDING_CACHE_DIR` environment variable allows specifying where to store cached models (persists across restarts)
- **Model instance caching**: Embedding model is loaded once and reused for all operations (search, upsert)
- **Vector validation in diagnostics**: `qdrant_diagnose_collection` now detects and warns about zero-dimension vectors
- **Troubleshooting documentation**: Added `docs/TROUBLESHOOTING.md` with detailed solutions for common issues
- Russian README translation (`README.ru.md`)
- Structured metadata documentation (`docs/STRUCTURED_METADATA.md`, `docs/STRUCTURED_METADATA.ru.md`)
- OpenCode skill with diagnostic workflows

### Changed
- **Improved search performance**: Now uses pre-generated embeddings instead of `models.Document` which created new model instances on each call
- **Better error messages**: Network errors during model download are clearly reported
- Enhanced `ParsedChunk` dataclass with extended metadata fields
- Improved MarkdownParser with code block language extraction
- Updated MultiLanguageParser with import extraction fallback

### Fixed
- **Zero-dimension vectors**: Fixed issue where vectors were created with dimensionality 0 when fastembed failed silently
- Fixed diagnostics mock in tests for `validate_collection_vectors` method
- Fixed import ordering in server.py

### Security
- N/A

## [0.1.5] - 2026-03-27

### Added
- Gitignore support: indexer now respects `.gitignore` files
- Automatically excludes `node_modules/`, `__pycache__/`, `.venv/`, build artifacts, etc.
- Added `pathspec` dependency for gitignore pattern matching
- Added tests for gitignore functionality

### Changed
- Updated README with gitignore documentation and indexing notes
- Updated skill documentation with gitignore support info

### Fixed
- N/A

### Security
- N/A

## [0.1.4] - 2026-03-27

### Added
- N/A

### Changed
- N/A

### Fixed
- Use correct CollectionInfo attributes (indexed_vectors_count instead of vectors_count)
- Update server version to 0.1.4

### Security
- N/A

## [0.1.3] - 2026-03-27

### Added
- N/A

### Changed
- Rename package to qmcp-qdrant (due to name conflict on PyPI)
- Add entry point for command-line execution

### Fixed
- N/A

### Security
- N/A

## [0.1.1] - 2026-03-27

### Added
- N/A

### Changed
- Remove Docker references from documentation

### Fixed
- Change license from MIT to Apache 2.0

### Security
- N/A

## [0.1.0] - 2026-03-27

### Added
- Make collection parameter required for data isolation

### Changed
- Simplify documentation - focus on local development
- Use opencode mcp add for integration
- Change license to Apache 2.0

### Fixed
- Migrate from deprecated tool.uv to dependency-groups

### Security
- N/A
