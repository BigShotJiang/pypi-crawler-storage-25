from __future__ import annotations

import logging
from typing import TYPE_CHECKING, Any

from privacy_filter import (
    PiiStore,
    extract_text_from_content,
    get_classifier,
    is_redactable_role,
    redact_text,
    unredact_text,
)

if TYPE_CHECKING:
    from privacy_filter.types import ClassifierPipeline, Entity

logger: logging.Logger = logging.getLogger(__name__)


class PrivacyFilterHook:
    """NanoBot AgentHook that redacts PII before each LLM call and restores it in responses.

    Usage with NanoBot:

        from nanobot_hook import PrivacyFilterHook

        hook = PrivacyFilterHook(min_score=0.9)
        # Register with your NanoBot agent's CompositeHook
    """

    def __init__(
        self,
        min_score: float = 0.8,
        entity_types: list[str] | None = None,
        cache_dir: str | None = None,
    ) -> None:
        self.min_score = min_score
        self.entity_types = entity_types
        self.cache_dir = cache_dir
        self.store = PiiStore()

    async def before_iteration(self, context: Any) -> None:
        """Redact PII from user/system messages before LLM call.

        Creates a fresh PiiStore for each iteration and replaces detected
        PII with placeholders in the message content.
        """
        self.store = PiiStore()
        classifier: ClassifierPipeline = get_classifier(self.cache_dir)

        for msg in context.messages:
            role = msg.get("role")
            if not is_redactable_role(role):
                continue

            content = msg.get("content")
            if not content:
                continue

            # Handle both string content and list content (OpenAI vision format)
            if isinstance(content, list):
                for part in content:
                    if isinstance(part, dict) and part.get("type") == "text":
                        text = part.get("text", "")
                        entities: list[Entity] = classifier(text)
                        part["text"] = redact_text(
                            text,
                            entities,
                            self.store,
                            self.min_score,
                            self.entity_types,
                        )
            elif isinstance(content, str):
                entities: list[Entity] = classifier(content)
                msg["content"] = redact_text(
                    content,
                    entities,
                    self.store,
                    self.min_score,
                    self.entity_types,
                )

    def finalize_content(self, context: Any, content: str | None) -> str | None:
        """Restore original PII values from placeholders in LLM response.

        Uses the PiiStore populated during before_iteration to reverse
        the redaction process.
        """
        if content and self.store.forward:
            logger.debug("Restoring PII from placeholders in response")
            return unredact_text(content, self.store)
        return content
