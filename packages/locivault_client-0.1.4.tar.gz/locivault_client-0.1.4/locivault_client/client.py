"""
LocIVaultClient — main client class.

Usage (simple):
    from locivault_client import LocIVaultClient
    from eth_account import Account

    account = Account.from_key("0x...")
    client = LocIVaultClient(account)

    # Write encrypted memory (encrypt it yourself or use the auto_encrypt option)
    import os
    blob = os.urandom(64)  # your encrypted bytes
    result = client.write(blob)
    print(result)  # {"ok": True, "sha256": "...", "ops_used": 1, ...}

    # Read it back
    data = client.read()

    # Check account status
    print(client.status())

Usage (with built-in encryption):
    from locivault_client import LocIVaultClient
    from eth_account import Account

    account = Account.from_key("0x...")
    client = LocIVaultClient(account, auto_encrypt=True)

    client.write_plaintext(b"my secret memory")
    text = client.read_plaintext()

Payment behaviour:
    - Reads are always free, unlimited
    - First 500 writes per month are free
    - Beyond that, pay per write in USDC on Base
    - Payment is automatic when an account is provided — the client
      detects the 402, signs a payment, and retries transparently
    - Set auto_pay=False to disable (you'll get PaymentRequired exceptions instead)
"""

import base64
import hashlib
import json
import logging
import time
from typing import Optional

import requests

from .crypto import encrypt_with_account, decrypt_with_account
from .signing import sign_request

log = logging.getLogger("locivault.client")

# Public server
DEFAULT_BASE_URL = "https://locivault.fly.dev"
DEFAULT_NETWORK  = "eip155:8453"    # Base mainnet

# Throttle between payment attempts to avoid settlement failures.
PAY_THROTTLE_SEC = 3.5


class PaymentRequired(Exception):
    """
    Raised when the server returns 402 and auto_pay=False (or no account provided).

    Attributes:
        accepts (list): the "accepts" list from the 402 body — pass to PaymentSigner.sign()
        body    (dict): full 402 response body
    """
    def __init__(self, accepts: list, body: dict):
        self.accepts = accepts
        self.body    = body
        super().__init__(f"Payment required. Use auto_pay=True or sign manually. Accepts: {accepts}")


class LocIVaultError(Exception):
    """Raised for non-payment API errors (4xx/5xx)."""
    def __init__(self, status_code: int, detail: str):
        self.status_code = status_code
        self.detail = detail
        super().__init__(f"LocIVault error {status_code}: {detail}")


class LocIVaultClient:
    """
    Python client for the LocIVault API.

    Args:
        account:      eth_account LocalAccount (your wallet). Used for:
                        - Wallet address (sent as X-Wallet-Address header)
                        - Payment signing (when auto_pay=True)
                        - Encryption key derivation (when auto_encrypt=True)
        base_url:     LocIVault server URL. Default: https://locivault.fly.dev
        network:      EIP-155 chain ID string. Default: "eip155:8453" (Base mainnet)
        auto_pay:     If True (default), automatically sign and send x402 payments
                      when the free tier is exhausted. Requires x402[evm] to be installed.
        auto_encrypt: If True, write_plaintext/read_plaintext will encrypt/decrypt
                      using the account's private key (AES-256-GCM). Default: False.
        timeout:      HTTP request timeout in seconds. Default: 30.
        session:      Optional requests.Session to reuse. If None, a fresh one is created.
    """

    def __init__(
        self,
        account,
        base_url:      str  = DEFAULT_BASE_URL,
        network:       str  = DEFAULT_NETWORK,
        auto_pay:      bool = True,
        auto_encrypt:  bool = False,
        timeout:       int  = 30,
        session:       Optional[requests.Session] = None,
    ):
        self.account      = account
        self.base_url     = base_url.rstrip("/")
        self.network      = network
        self.auto_pay     = auto_pay
        self.auto_encrypt = auto_encrypt
        self.timeout      = timeout
        self._session     = session or requests.Session()
        self._signer      = None          # lazy — only built if payment needed
        self._last_pay_ts = 0.0           # for payment throttling

    # ── Public API ─────────────────────────────────────────────────────────────

    def write(self, data: bytes) -> dict:
        """
        Store an encrypted blob for this wallet.

        Args:
            data: arbitrary bytes (client-side encrypted — LocIVault never sees plaintext)

        Returns:
            dict with keys: ok, sha256, size, ops_used, free_ops_remaining

        Raises:
            PaymentRequired: if auto_pay=False and free tier is exhausted
            LocIVaultError:  on 4xx/5xx errors
        """
        return self._request_with_payment(
            method="POST",
            path="/write",
            json_body={"data": base64.b64encode(data).decode()},
            resource_path="/write",
        )

    def read(self) -> bytes:
        """
        Retrieve the stored encrypted blob for this wallet.

        Returns:
            bytes: the blob previously stored with write()

        Raises:
            PaymentRequired: if auto_pay=False and free tier is exhausted
            LocIVaultError:  on 4xx/5xx errors (404 if nothing stored yet)
        """
        result = self._request_with_payment(
            method="GET",
            path="/read",
            resource_path="/read",
        )
        return base64.b64decode(result["data"])

    def write_plaintext(self, plaintext: bytes) -> dict:
        """
        Encrypt plaintext with this wallet's key and store it.

        Requires auto_encrypt=True (or just call this directly — it will work
        regardless of the auto_encrypt flag, using the account's private key).

        Args:
            plaintext: bytes to encrypt and store

        Returns:
            dict: same as write()
        """
        blob = encrypt_with_account(plaintext, self.account)
        return self.write(blob)

    def read_plaintext(self) -> bytes:
        """
        Read and decrypt stored memory using this wallet's key.

        Returns:
            bytes: original plaintext

        Raises:
            ValueError: if decryption fails (wrong key or tampered blob)
        """
        blob = self.read()
        return decrypt_with_account(blob, self.account)

    def status(self, wallet: Optional[str] = None) -> dict:
        """
        Check ops usage and tier for a wallet address.

        Args:
            wallet: wallet address to check. Defaults to this client's account address.

        Returns:
            dict with keys: wallet, ops_used, free_ops_remaining, tier, price_per_op, ...
        """
        addr = wallet or self.account.address
        resp = self._session.get(
            f"{self.base_url}/status",
            headers={"X-Wallet-Address": addr},
            timeout=self.timeout,
        )
        return resp.json()

    def health(self) -> dict:
        """Liveness check. Returns {"status": "ok", "ts": "..."}."""
        resp = self._session.get(f"{self.base_url}/health", timeout=self.timeout)
        resp.raise_for_status()
        return resp.json()

    # ── Internal helpers ───────────────────────────────────────────────────────

    def _request_with_payment(
        self,
        method:        str,
        path:          str,
        resource_path: str,
        json_body:     Optional[dict] = None,
    ) -> dict:
        """
        Make an API request. If the server returns 402 and auto_pay=True,
        sign a payment and retry exactly once.
        Every request is signed with the wallet key for authentication.
        """
        sig_headers = sign_request(self.account, method, path)
        headers = {"X-Wallet-Address": self.account.address, **sig_headers}

        # First attempt — no payment header
        resp = self._do_request(method, path, headers, json_body)

        if resp.status_code == 200:
            return resp.json()

        if resp.status_code == 402:
            body_402 = resp.json()
            accepts  = body_402.get("accepts", [])

            if not self.auto_pay:
                raise PaymentRequired(accepts=accepts, body=body_402)

            if not accepts:
                raise LocIVaultError(402, "Server returned 402 with no payment requirements")

            # Re-sign with fresh timestamp + add payment header
            sig_headers = sign_request(self.account, method, path)
            payment_header = self._sign_payment(
                resource_url=f"{self.base_url}{resource_path}",
                accepts=accepts,
            )
            headers = {
                "X-Wallet-Address": self.account.address,
                **sig_headers,
                "X-Payment": payment_header,
            }
            resp = self._do_request(method, path, headers, json_body)

            if resp.status_code == 200:
                return resp.json()
            elif resp.status_code == 402:
                # Payment was rejected — surface the error
                detail = resp.json().get("error_detail", resp.text[:200])
                raise LocIVaultError(402, f"Payment rejected by server: {detail}")
            else:
                self._raise_for_status(resp)

        else:
            self._raise_for_status(resp)

    def _do_request(
        self,
        method:    str,
        path:      str,
        headers:   dict,
        json_body: Optional[dict],
    ) -> requests.Response:
        url = f"{self.base_url}{path}"
        if method == "POST":
            return self._session.post(url, json=json_body, headers=headers, timeout=self.timeout)
        elif method == "GET":
            return self._session.get(url, headers=headers, timeout=self.timeout)
        else:
            raise ValueError(f"Unsupported method: {method}")

    def _sign_payment(self, resource_url: str, accepts: list) -> str:
        """Build signer lazily, throttle, sign, return X-Payment header value."""
        if self._signer is None:
            from .payment import PaymentSigner
            self._signer = PaymentSigner(self.account, network=self.network)

        # Throttle: ensure >= PAY_THROTTLE_SEC between payments
        elapsed = time.time() - self._last_pay_ts
        if elapsed < PAY_THROTTLE_SEC:
            wait = PAY_THROTTLE_SEC - elapsed
            log.debug(f"Throttling payment: sleeping {wait:.1f}s")
            time.sleep(wait)

        header = self._signer.sign(resource_url, accepts)
        self._last_pay_ts = time.time()
        return header

    @staticmethod
    def _raise_for_status(resp: requests.Response):
        try:
            detail = resp.json().get("detail", resp.text[:300])
        except Exception:
            detail = resp.text[:300]
        raise LocIVaultError(resp.status_code, detail)
