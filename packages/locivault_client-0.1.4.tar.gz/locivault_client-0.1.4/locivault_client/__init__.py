"""
LocIVault Python Client SDK
===========================

Encrypted, agent-owned memory storage with x402 micropayments.

Quickstart
----------
    from locivault_client import LocIVaultClient
    from eth_account import Account

    account = Account.from_key("0x...")
    client = LocIVaultClient(account)

    client.write(b"\\x00\\x01\\x02...")        # your encrypted blob
    blob = client.read()                       # get it back
    print(client.status())                     # ops used, tier, etc.

Key custody
-----------
LocIVault stores encrypted blobs — it never sees plaintext.
Encrypt/decrypt your data before passing it to this client.
Use locivault_client.crypto for a bundled AES-256-GCM helper.
"""

from .client import LocIVaultClient
from .crypto import encrypt, decrypt

__all__ = ["LocIVaultClient", "encrypt", "decrypt"]
__version__ = "0.1.4"
