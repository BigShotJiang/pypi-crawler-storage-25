print("the-critic")
