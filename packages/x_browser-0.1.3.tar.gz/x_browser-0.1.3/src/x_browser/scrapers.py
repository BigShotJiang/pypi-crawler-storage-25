"""Read/scrape operations for X: get tweets, search, user profiles, timelines, etc.

These are read-only, so they do NOT call politeness_wait() — only write
actions need the delay.  (The plan says "any action" which means writes.)
If you want delays on reads too, the config is available.
"""

from __future__ import annotations

import re
from typing import Any

from playwright.async_api import Page

from .config import Config


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def _normalize_tweet_url(id_or_url: str) -> str:
    id_or_url = id_or_url.strip()
    if id_or_url.startswith("http"):
        return id_or_url.split("?")[0]
    if id_or_url.isdigit():
        return f"https://x.com/i/status/{id_or_url}"
    return id_or_url


def _clean_username(username: str) -> str:
    return username.lstrip("@").strip()


def _parse_metric(text: str) -> int:
    """Parse metric text like '1.2K', '3M', '500' into an integer."""
    if not text:
        return 0
    text = text.strip().replace(",", "")
    multipliers = {"K": 1_000, "M": 1_000_000, "B": 1_000_000_000}
    for suffix, mult in multipliers.items():
        if text.upper().endswith(suffix):
            try:
                return int(float(text[:-1]) * mult)
            except ValueError:
                return 0
    try:
        return int(text)
    except ValueError:
        return 0


async def _extract_tweet_from_article(article, page: Page) -> dict:
    """Extract tweet data from a single <article> element."""
    data: dict[str, Any] = {}

    # Author info
    user_link = await article.query_selector('div[data-testid="User-Name"] a')
    if user_link:
        href = await user_link.get_attribute("href") or ""
        data["author_username"] = href.strip("/").split("/")[0] if href else ""

    user_name_el = await article.query_selector('div[data-testid="User-Name"] span')
    if user_name_el:
        data["author_name"] = (await user_name_el.inner_text()).strip()

    # Tweet text
    text_el = await article.query_selector('div[data-testid="tweetText"]')
    if text_el:
        data["text"] = (await text_el.inner_text()).strip()
    else:
        data["text"] = ""

    # Timestamp
    time_el = await article.query_selector("time")
    if time_el:
        data["created_at"] = await time_el.get_attribute("datetime") or ""

    # Tweet URL / ID
    time_link = await article.query_selector('a[href*="/status/"] time')
    if time_link:
        parent_a = await time_link.evaluate_handle("el => el.closest('a')")
        if parent_a:
            href = await parent_a.get_attribute("href")
            if href:
                data["url"] = f"https://x.com{href}"
                match = re.search(r"/status/(\d+)", href)
                if match:
                    data["id"] = match.group(1)

    # Metrics (reply, retweet, like, view counts)
    # These are in the button group at the bottom of the tweet
    reply_btn = await article.query_selector('button[data-testid="reply"]')
    if reply_btn:
        reply_text = await reply_btn.inner_text()
        data["reply_count"] = _parse_metric(reply_text)

    retweet_btn = await article.query_selector('button[data-testid="retweet"]')
    if retweet_btn:
        retweet_text = await retweet_btn.inner_text()
        data["retweet_count"] = _parse_metric(retweet_text)

    like_btn = await article.query_selector(
        'button[data-testid="like"], button[data-testid="unlike"]'
    )
    if like_btn:
        like_text = await like_btn.inner_text()
        data["like_count"] = _parse_metric(like_text)

    # View count (analytics icon area)
    view_el = await article.query_selector('a[href*="/analytics"] span')
    if view_el:
        view_text = await view_el.inner_text()
        data["view_count"] = _parse_metric(view_text)

    return data


# ---------------------------------------------------------------------------
# Get a single tweet
# ---------------------------------------------------------------------------

async def tweet_get(page: Page, id_or_url: str) -> dict:
    """Fetch a single tweet's data by navigating to it."""
    url = _normalize_tweet_url(id_or_url)
    await page.goto(url, wait_until="domcontentloaded")
    article = await page.wait_for_selector(
        'article[data-testid="tweet"]', timeout=15_000
    )
    return await _extract_tweet_from_article(article, page)


# ---------------------------------------------------------------------------
# Tweet metrics (same as get but focused on numbers)
# ---------------------------------------------------------------------------

async def tweet_metrics(page: Page, id_or_url: str) -> dict:
    """Get detailed metrics for a tweet."""
    data = await tweet_get(page, id_or_url)
    # Keep only metric fields + identifiers
    return {
        "id": data.get("id", ""),
        "text": data.get("text", ""),
        "reply_count": data.get("reply_count", 0),
        "retweet_count": data.get("retweet_count", 0),
        "like_count": data.get("like_count", 0),
        "view_count": data.get("view_count", 0),
    }


# ---------------------------------------------------------------------------
# Search tweets
# ---------------------------------------------------------------------------

async def tweet_search(
    page: Page, query: str, *, max_results: int = 10
) -> list[dict]:
    """Search for recent tweets matching a query."""
    encoded = query.replace(" ", "%20")
    await page.goto(
        f"https://x.com/search?q={encoded}&src=typed_query&f=live",
        wait_until="domcontentloaded",
    )
    await page.wait_for_timeout(3000)

    results: list[dict] = []
    articles = await page.query_selector_all('article[data-testid="tweet"]')
    for article in articles[:max_results]:
        try:
            data = await _extract_tweet_from_article(article, page)
            if data.get("text"):
                results.append(data)
        except Exception:
            continue

    # If we need more, scroll and collect
    retries = 0
    while len(results) < max_results and retries < 5:
        await page.evaluate("window.scrollBy(0, 1000)")
        await page.wait_for_timeout(2000)
        articles = await page.query_selector_all('article[data-testid="tweet"]')
        for article in articles[len(results):]:
            try:
                data = await _extract_tweet_from_article(article, page)
                if data.get("text") and data.get("id") not in {
                    r.get("id") for r in results
                }:
                    results.append(data)
                    if len(results) >= max_results:
                        break
            except Exception:
                continue
        retries += 1

    return results[:max_results]


# ---------------------------------------------------------------------------
# User profile
# ---------------------------------------------------------------------------

async def user_get(page: Page, username: str) -> dict:
    """Get a user's profile data."""
    username = _clean_username(username)
    await page.goto(
        f"https://x.com/{username}", wait_until="domcontentloaded"
    )
    await page.wait_for_timeout(3000)

    data: dict[str, Any] = {"username": username}

    # Display name
    name_el = await page.query_selector(
        'div[data-testid="UserName"] span'
    )
    if name_el:
        data["name"] = (await name_el.inner_text()).strip()

    # Bio/description
    bio_el = await page.query_selector(
        'div[data-testid="UserDescription"]'
    )
    if bio_el:
        data["description"] = (await bio_el.inner_text()).strip()

    # Following / followers counts
    following_link = await page.query_selector(f'a[href="/{username}/following"]')
    if following_link:
        text = (await following_link.inner_text()).strip()
        match = re.search(r"([\d,.]+[KMB]?)", text)
        if match:
            data["following_count"] = _parse_metric(match.group(1))

    followers_link = await page.query_selector(
        f'a[href="/{username}/verified_followers"], a[href="/{username}/followers"]'
    )
    if followers_link:
        text = (await followers_link.inner_text()).strip()
        match = re.search(r"([\d,.]+[KMB]?)", text)
        if match:
            data["followers_count"] = _parse_metric(match.group(1))

    # Join date
    join_el = await page.query_selector('span[data-testid="UserJoinDate"]')
    if join_el:
        data["joined"] = (await join_el.inner_text()).strip()

    # Location
    loc_el = await page.query_selector('span[data-testid="UserLocation"]')
    if loc_el:
        data["location"] = (await loc_el.inner_text()).strip()

    # Website/URL
    url_el = await page.query_selector('a[data-testid="UserUrl"]')
    if url_el:
        data["url"] = await url_el.get_attribute("href") or ""

    return data


# ---------------------------------------------------------------------------
# User timeline
# ---------------------------------------------------------------------------

async def user_timeline(
    page: Page, username: str, *, max_results: int = 10
) -> list[dict]:
    """Get a user's recent tweets."""
    username = _clean_username(username)
    await page.goto(
        f"https://x.com/{username}", wait_until="domcontentloaded"
    )
    await page.wait_for_timeout(3000)

    results: list[dict] = []
    retries = 0
    while len(results) < max_results and retries < 10:
        articles = await page.query_selector_all('article[data-testid="tweet"]')
        for article in articles:
            try:
                data = await _extract_tweet_from_article(article, page)
                if data.get("text") and data.get("id") not in {
                    r.get("id") for r in results
                }:
                    results.append(data)
                    if len(results) >= max_results:
                        break
            except Exception:
                continue
        if len(results) >= max_results:
            break
        await page.evaluate("window.scrollBy(0, 1000)")
        await page.wait_for_timeout(2000)
        retries += 1

    return results[:max_results]


# ---------------------------------------------------------------------------
# Followers / Following
# ---------------------------------------------------------------------------

async def _scrape_user_list(
    page: Page, url: str, *, max_results: int = 100
) -> list[dict]:
    """Scrape a list of users from a followers/following page."""
    await page.goto(url, wait_until="domcontentloaded")
    await page.wait_for_timeout(3000)

    results: list[dict] = []
    seen_usernames: set[str] = set()
    retries = 0

    while len(results) < max_results and retries < 15:
        cells = await page.query_selector_all(
            'div[data-testid="cellInnerDiv"] button[data-testid*="UserCell"], '
            'div[data-testid="cellInnerDiv"] div[data-testid="UserCell"]'
        )
        # Fallback: try link-based extraction
        if not cells:
            cells = await page.query_selector_all(
                'div[data-testid="cellInnerDiv"]'
            )

        for cell in cells:
            try:
                user_data: dict[str, Any] = {}
                # Find username link
                links = await cell.query_selector_all("a")
                for link in links:
                    href = await link.get_attribute("href") or ""
                    if href.startswith("/") and "/" not in href[1:] and href != "/":
                        uname = href.strip("/")
                        if uname and uname not in seen_usernames:
                            user_data["username"] = uname
                            break

                if not user_data.get("username"):
                    continue

                # Display name
                spans = await cell.query_selector_all("span")
                for span in spans:
                    text = (await span.inner_text()).strip()
                    if text and not text.startswith("@") and text != "Follow":
                        user_data["name"] = text
                        break

                if user_data["username"] not in seen_usernames:
                    seen_usernames.add(user_data["username"])
                    results.append(user_data)
                    if len(results) >= max_results:
                        break
            except Exception:
                continue

        if len(results) >= max_results:
            break
        await page.evaluate("window.scrollBy(0, 1000)")
        await page.wait_for_timeout(2000)
        retries += 1

    return results[:max_results]


async def user_followers(
    page: Page, username: str, *, max_results: int = 100
) -> list[dict]:
    """List followers of a user."""
    username = _clean_username(username)
    return await _scrape_user_list(
        page,
        f"https://x.com/{username}/verified_followers",
        max_results=max_results,
    )


async def user_following(
    page: Page, username: str, *, max_results: int = 100
) -> list[dict]:
    """List users that a user follows."""
    username = _clean_username(username)
    return await _scrape_user_list(
        page,
        f"https://x.com/{username}/following",
        max_results=max_results,
    )


# ---------------------------------------------------------------------------
# Mentions
# ---------------------------------------------------------------------------

async def me_mentions(page: Page, *, max_results: int = 10) -> list[dict]:
    """Fetch tweets that mention the logged-in user."""
    await page.goto(
        "https://x.com/notifications/mentions",
        wait_until="domcontentloaded",
    )
    await page.wait_for_timeout(3000)

    results: list[dict] = []
    retries = 0
    while len(results) < max_results and retries < 5:
        articles = await page.query_selector_all('article[data-testid="tweet"]')
        for article in articles:
            try:
                data = await _extract_tweet_from_article(article, page)
                if data.get("text") and data.get("id") not in {
                    r.get("id") for r in results
                }:
                    results.append(data)
                    if len(results) >= max_results:
                        break
            except Exception:
                continue
        if len(results) >= max_results:
            break
        await page.evaluate("window.scrollBy(0, 1000)")
        await page.wait_for_timeout(2000)
        retries += 1

    return results[:max_results]


# ---------------------------------------------------------------------------
# Bookmarks
# ---------------------------------------------------------------------------

async def me_bookmarks(page: Page, *, max_results: int = 10) -> list[dict]:
    """Fetch the logged-in user's bookmarks."""
    await page.goto(
        "https://x.com/i/bookmarks", wait_until="domcontentloaded"
    )
    await page.wait_for_timeout(3000)

    results: list[dict] = []
    retries = 0
    while len(results) < max_results and retries < 5:
        articles = await page.query_selector_all('article[data-testid="tweet"]')
        for article in articles:
            try:
                data = await _extract_tweet_from_article(article, page)
                if data.get("text") and data.get("id") not in {
                    r.get("id") for r in results
                }:
                    results.append(data)
                    if len(results) >= max_results:
                        break
            except Exception:
                continue
        if len(results) >= max_results:
            break
        await page.evaluate("window.scrollBy(0, 1000)")
        await page.wait_for_timeout(2000)
        retries += 1

    return results[:max_results]
