"""Output formatters for x-browser.

Supports four modes: human (Rich panels), JSON, plain (TSV), and markdown.
Mirrors the x-cli output interface.
"""

from __future__ import annotations

import json
import sys
from typing import Any

from rich.console import Console
from rich.panel import Panel
from rich.table import Table

console = Console(stderr=True)
out_console = Console()  # stdout


# ---------------------------------------------------------------------------
# Router
# ---------------------------------------------------------------------------

def output(data: Any, *, mode: str = "human", verbose: bool = False) -> None:
    """Route output to the correct formatter."""
    if mode == "json":
        output_json(data, verbose=verbose)
    elif mode == "plain":
        output_plain(data, verbose=verbose)
    elif mode == "markdown":
        output_markdown(data, verbose=verbose)
    else:
        output_human(data, verbose=verbose)


# ---------------------------------------------------------------------------
# JSON
# ---------------------------------------------------------------------------

def output_json(data: Any, *, verbose: bool = False) -> None:
    print(json.dumps(data, indent=2, default=str, ensure_ascii=False))


# ---------------------------------------------------------------------------
# Plain / TSV
# ---------------------------------------------------------------------------

def output_plain(data: Any, *, verbose: bool = False) -> None:
    if isinstance(data, dict):
        _plain_dict(data, verbose=verbose)
    elif isinstance(data, list):
        _plain_list(data, verbose=verbose)
    else:
        print(data)


def _plain_dict(d: dict, *, verbose: bool = False) -> None:
    skip = set() if verbose else {"entities", "edit_history_tweet_ids", "attachments"}
    for k, v in d.items():
        if k in skip:
            continue
        print(f"{k}\t{v}")


def _plain_list(items: list, *, verbose: bool = False) -> None:
    if not items:
        return
    # Use keys from first item as header
    keys = list(items[0].keys())
    if not verbose:
        skip = {"entities", "edit_history_tweet_ids", "attachments", "referenced_tweets"}
        keys = [k for k in keys if k not in skip]
    print("\t".join(keys))
    for item in items:
        print("\t".join(str(item.get(k, "")) for k in keys))


# ---------------------------------------------------------------------------
# Markdown
# ---------------------------------------------------------------------------

def output_markdown(data: Any, *, verbose: bool = False) -> None:
    if isinstance(data, dict):
        if "text" in data and ("author_username" in data or "author_name" in data):
            _md_tweet(data, verbose=verbose)
        elif "username" in data and "name" in data:
            _md_user(data, verbose=verbose)
        else:
            _md_dict(data)
    elif isinstance(data, list):
        _md_list(data, verbose=verbose)
    else:
        print(data)


def _md_tweet(t: dict, *, verbose: bool = False) -> None:
    author = t.get("author_name", t.get("author_username", ""))
    username = t.get("author_username", "")
    print(f"### {author} (@{username})")
    if verbose and t.get("created_at"):
        print(f"*{t['created_at']}*")
    print()
    print(t.get("text", ""))
    print()
    if verbose or any(t.get(k) for k in ("like_count", "retweet_count", "reply_count")):
        metrics = []
        for k in ("reply_count", "retweet_count", "like_count", "view_count"):
            if t.get(k) is not None:
                label = k.replace("_count", "").replace("_", " ").title()
                metrics.append(f"**{label}:** {t[k]}")
        if metrics:
            print(" | ".join(metrics))
            print()
    if t.get("id"):
        print(f"ID: `{t['id']}`")
    print()


def _md_user(u: dict, *, verbose: bool = False) -> None:
    name = u.get("name", u.get("username", ""))
    username = u.get("username", "")
    print(f"## {name} (@{username})")
    print()
    if u.get("description"):
        print(u["description"])
        print()
    parts = []
    if u.get("followers_count") is not None:
        parts.append(f"**Followers:** {u['followers_count']}")
    if u.get("following_count") is not None:
        parts.append(f"**Following:** {u['following_count']}")
    if parts:
        print(" | ".join(parts))
        print()
    if verbose:
        if u.get("joined"):
            print(f"**Joined:** {u['joined']}")
        if u.get("location"):
            print(f"**Location:** {u['location']}")
        if u.get("url"):
            print(f"**URL:** {u['url']}")
        print()


def _md_dict(d: dict) -> None:
    for k, v in d.items():
        print(f"- **{k}:** {v}")
    print()


def _md_list(items: list, *, verbose: bool = False) -> None:
    if not items:
        print("*No results*")
        return
    # Detect type from first item
    first = items[0]
    for i, item in enumerate(items):
        if "text" in item and ("author_username" in item or "author_name" in item):
            _md_tweet(item, verbose=verbose)
        elif "username" in item:
            _md_user(item, verbose=verbose)
        else:
            _md_dict(item)
        if i < len(items) - 1:
            print("---")
            print()


# ---------------------------------------------------------------------------
# Human (Rich)
# ---------------------------------------------------------------------------

def output_human(data: Any, *, verbose: bool = False) -> None:
    if isinstance(data, dict):
        if "text" in data and ("author_username" in data or "author_name" in data):
            _human_tweet(data, verbose=verbose)
        elif "username" in data and "name" in data:
            _human_user(data, verbose=verbose)
        elif "ok" in data:
            _human_action_result(data)
        else:
            _human_dict(data)
    elif isinstance(data, list):
        _human_list(data, verbose=verbose)
    else:
        out_console.print(data)


def _human_tweet(t: dict, *, verbose: bool = False) -> None:
    author = t.get("author_name", t.get("author_username", ""))
    username = t.get("author_username", "")
    title = f"@{username}" if username else author
    if verbose and t.get("created_at"):
        title += f"  {t['created_at']}"

    body = t.get("text", "")

    metrics_parts = []
    for k, icon in [
        ("reply_count", "\U0001f4ac"),
        ("retweet_count", "\U0001f501"),
        ("like_count", "\u2764\ufe0f"),
        ("view_count", "\U0001f441"),
    ]:
        if t.get(k) is not None:
            metrics_parts.append(f"{icon} {t[k]}")
    if metrics_parts:
        body += f"\n\n{'  '.join(metrics_parts)}"

    out_console.print(
        Panel(body, title=title, border_style="blue", expand=False)
    )


def _human_user(u: dict, *, verbose: bool = False) -> None:
    name = u.get("name", "")
    username = u.get("username", "")
    title = f"{name} (@{username})"

    parts = []
    if u.get("description"):
        parts.append(u["description"])
    metrics = []
    if u.get("followers_count") is not None:
        metrics.append(f"Followers: {u['followers_count']}")
    if u.get("following_count") is not None:
        metrics.append(f"Following: {u['following_count']}")
    if metrics:
        parts.append("  |  ".join(metrics))
    if verbose:
        if u.get("joined"):
            parts.append(f"Joined: {u['joined']}")
        if u.get("location"):
            parts.append(f"Location: {u['location']}")
        if u.get("url"):
            parts.append(f"URL: {u['url']}")

    out_console.print(
        Panel("\n".join(parts), title=title, border_style="green", expand=False)
    )


def _human_action_result(d: dict) -> None:
    msg_parts = []
    for k, v in d.items():
        if k == "ok":
            continue
        msg_parts.append(f"{k}: {v}")
    status = "[green]OK[/green]" if d.get("ok") else "[red]FAILED[/red]"
    out_console.print(f"{status}  {'  |  '.join(msg_parts)}")


def _human_dict(d: dict) -> None:
    for k, v in d.items():
        out_console.print(f"[bold]{k}:[/bold] {v}")


def _human_list(items: list, *, verbose: bool = False) -> None:
    if not items:
        out_console.print("[dim]No results[/dim]")
        return
    first = items[0]
    # If it's a list of tweets, show panels
    if "text" in first:
        for item in items:
            _human_tweet(item, verbose=verbose)
    # If it's a list of users, show a table
    elif "username" in first:
        table = Table(show_header=True, header_style="bold cyan")
        table.add_column("Username")
        table.add_column("Name")
        if verbose:
            table.add_column("Followers")
            table.add_column("Following")
        for u in items:
            row = [f"@{u.get('username', '')}", u.get("name", "")]
            if verbose:
                row.append(str(u.get("followers_count", "")))
                row.append(str(u.get("following_count", "")))
            table.add_row(*row)
        out_console.print(table)
    else:
        for item in items:
            _human_dict(item)
