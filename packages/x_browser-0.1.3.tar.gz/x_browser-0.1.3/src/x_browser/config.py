"""Configuration management for x-browser.

Handles politeness delays and other settings.
Loads from ~/.config/x-browser/config.json, can be overridden via CLI flags
or function parameters.
"""

from __future__ import annotations

import asyncio
import json
import random
import sys
from dataclasses import dataclass, field
from pathlib import Path

CONFIG_DIR = Path.home() / ".config" / "x-browser"
CONFIG_FILE = CONFIG_DIR / "config.json"

DEFAULTS = {
    "minPolitenessDelay": 3,
    "maxPolitenessDelay": 30,
}


@dataclass
class Config:
    """Runtime configuration."""

    min_politeness_delay: float = DEFAULTS["minPolitenessDelay"]
    max_politeness_delay: float = DEFAULTS["maxPolitenessDelay"]

    # ---- persistence ----

    @classmethod
    def load(cls) -> "Config":
        """Load config from disk, falling back to defaults."""
        cfg = cls()
        if CONFIG_FILE.exists():
            try:
                raw = json.loads(CONFIG_FILE.read_text())
                cfg.min_politeness_delay = float(
                    raw.get("minPolitenessDelay", cfg.min_politeness_delay)
                )
                cfg.max_politeness_delay = float(
                    raw.get("maxPolitenessDelay", cfg.max_politeness_delay)
                )
            except (json.JSONDecodeError, ValueError):
                pass  # corrupt file → use defaults
        return cfg

    def save(self) -> None:
        """Persist current config to disk."""
        CONFIG_DIR.mkdir(parents=True, exist_ok=True)
        CONFIG_FILE.write_text(
            json.dumps(
                {
                    "minPolitenessDelay": self.min_politeness_delay,
                    "maxPolitenessDelay": self.max_politeness_delay,
                },
                indent=2,
            )
            + "\n"
        )

    # ---- delay helper ----

    async def politeness_wait(
        self,
        *,
        min_delay: float | None = None,
        max_delay: float | None = None,
    ) -> float:
        """Sleep for a random duration between min and max delay.

        Parameters override the config values for this single call.
        Returns the actual seconds waited.
        """
        lo = min_delay if min_delay is not None else self.min_politeness_delay
        hi = max_delay if max_delay is not None else self.max_politeness_delay
        if lo > hi:
            lo, hi = hi, lo
        wait_secs = random.uniform(lo, hi)
        print(
            f"\u23f3 Waiting {wait_secs:.1f}s (politeness delay)...",
            file=sys.stderr,
        )
        await asyncio.sleep(wait_secs)
        return wait_secs
