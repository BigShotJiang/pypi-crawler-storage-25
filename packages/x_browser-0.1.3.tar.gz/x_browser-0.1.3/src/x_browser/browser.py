"""Browser session management for x-browser.

Launches Chrome as a normal subprocess (zero automation flags) with
--remote-debugging-port, then connects via CDP.  X cannot distinguish
this from a human-opened Chrome window.

Supports multiple concurrent sessions via a port-lock file and separate
profile directories.
"""

from __future__ import annotations

import asyncio
import fcntl
import json
import os
import socket
import subprocess
import sys
import time
from pathlib import Path

import httpx
from playwright.async_api import Browser, BrowserContext, Page, async_playwright

from .config import CONFIG_DIR

USER_DATA_DIR = CONFIG_DIR / "chrome-data"
LOCK_FILE = CONFIG_DIR / "chrome.lock"
PORT_FILE = CONFIG_DIR / "chrome.port"

# Where Chrome lives on macOS
CHROME_PATHS = [
    "/Applications/Google Chrome.app/Contents/MacOS/Google Chrome",
    "/Applications/Google Chrome Canary.app/Contents/MacOS/Google Chrome Canary",
    "/Applications/Chromium.app/Contents/MacOS/Chromium",
]


def _find_chrome() -> str:
    for p in CHROME_PATHS:
        if Path(p).exists():
            return p
    raise FileNotFoundError(
        "Google Chrome not found. Install it or set CHROME_PATH env var."
    )


def _free_port() -> int:
    """Find a free TCP port."""
    with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
        s.bind(("127.0.0.1", 0))
        return s.getsockname()[1]


async def _check_devtools(port: int) -> str | None:
    """Check if DevTools is already running on a port. Returns WS URL or None."""
    url = f"http://127.0.0.1:{port}/json/version"
    async with httpx.AsyncClient() as client:
        try:
            resp = await client.get(url, timeout=2)
            data = resp.json()
            return data.get("webSocketDebuggerUrl")
        except Exception:
            return None


async def _wait_for_devtools(port: int, timeout: float = 15) -> str:
    """Poll the DevTools JSON endpoint until Chrome is ready."""
    url = f"http://127.0.0.1:{port}/json/version"
    deadline = time.monotonic() + timeout
    async with httpx.AsyncClient() as client:
        while time.monotonic() < deadline:
            try:
                resp = await client.get(url, timeout=2)
                data = resp.json()
                return data["webSocketDebuggerUrl"]
            except Exception:
                await asyncio.sleep(0.3)
    raise TimeoutError(f"Chrome DevTools did not start on port {port}")


def _read_existing_port() -> int | None:
    """Read the port of an already-running Chrome instance."""
    try:
        if PORT_FILE.exists():
            return int(PORT_FILE.read_text().strip())
    except (ValueError, OSError):
        pass
    return None


def _write_port(port: int) -> None:
    """Record the debugging port so other sessions can connect."""
    CONFIG_DIR.mkdir(parents=True, exist_ok=True)
    PORT_FILE.write_text(str(port))


def _clear_port() -> None:
    """Remove the port file."""
    try:
        PORT_FILE.unlink(missing_ok=True)
    except OSError:
        pass


class XBrowser:
    """Launches real Chrome and connects via CDP — fully undetectable.

    If Chrome is already running on the same profile (from another terminal),
    connects to the existing instance instead of launching a new one.
    Each connection gets its own tab.
    """

    def __init__(self, *, headless: bool = True) -> None:
        self._headless = headless
        self._chrome_proc: subprocess.Popen | None = None
        self._pw = None
        self._browser: Browser | None = None
        self._ctx: BrowserContext | None = None
        self.page: Page | None = None
        self._owns_chrome = False  # True if this instance launched Chrome

    async def launch(self) -> Page:
        USER_DATA_DIR.mkdir(parents=True, exist_ok=True)

        # Try to connect to an already-running Chrome instance
        existing_port = _read_existing_port()
        if existing_port:
            ws_url = await _check_devtools(existing_port)
            if ws_url:
                print(
                    f"Connecting to existing Chrome (port {existing_port})...",
                    file=sys.stderr,
                )
                self._pw = await async_playwright().start()
                self._browser = await self._pw.chromium.connect_over_cdp(
                    f"http://127.0.0.1:{existing_port}"
                )
                self._ctx = self._browser.contexts[0]
                # Always open a new tab for this session
                self.page = await self._ctx.new_page()
                self._owns_chrome = False
                return self.page

        # No existing Chrome — launch a new one
        chrome = _find_chrome()
        port = _free_port()

        cmd = [
            chrome,
            f"--user-data-dir={USER_DATA_DIR}",
            f"--remote-debugging-port={port}",
            "--no-first-run",
            "--no-default-browser-check",
            "--disable-default-apps",
            "--window-size=1280,900",
        ]
        if self._headless:
            cmd.append("--headless=new")

        self._chrome_proc = subprocess.Popen(
            cmd,
            stdout=subprocess.DEVNULL,
            stderr=subprocess.DEVNULL,
        )

        ws_url = await _wait_for_devtools(port)
        _write_port(port)

        self._pw = await async_playwright().start()
        self._browser = await self._pw.chromium.connect_over_cdp(ws_url)
        self._ctx = self._browser.contexts[0]
        self._owns_chrome = True

        # Reuse the first tab or open a new one
        if self._ctx.pages:
            self.page = self._ctx.pages[0]
        else:
            self.page = await self._ctx.new_page()

        return self.page

    async def close(self) -> None:
        # Close just our tab if we don't own Chrome
        if not self._owns_chrome and self.page:
            try:
                await self.page.close()
            except Exception:
                pass

        if self._browser:
            try:
                await self._browser.close()
            except Exception:
                pass
        if self._pw:
            await self._pw.stop()

        # Only kill Chrome if we launched it
        if self._owns_chrome:
            _clear_port()
            if self._chrome_proc:
                self._chrome_proc.terminate()
                try:
                    self._chrome_proc.wait(timeout=5)
                except subprocess.TimeoutExpired:
                    self._chrome_proc.kill()

    async def __aenter__(self) -> "XBrowser":
        await self.launch()
        return self

    async def __aexit__(self, *exc) -> None:
        await self.close()


async def ensure_logged_in(page: Page) -> bool:
    """Navigate to X and check if we're logged in."""
    await page.goto("https://x.com/home", wait_until="domcontentloaded")
    await page.wait_for_timeout(3000)
    url = page.url
    if "/login" in url or "/i/flow/login" in url:
        return False
    try:
        await page.wait_for_selector('a[href="/compose/post"]', timeout=5000)
        return True
    except Exception:
        return False


async def login_interactive() -> None:
    """Open a headed Chrome window for the user to log in manually."""
    print("Opening Chrome for manual login...", file=sys.stderr)
    print(
        "Log in to X, then wait — session saves automatically.",
        file=sys.stderr,
    )

    async with XBrowser(headless=False) as xb:
        page = xb.page
        await page.goto("https://x.com/login", wait_until="domcontentloaded")
        print(
            "Waiting for login... (navigate to your home timeline)",
            file=sys.stderr,
        )
        try:
            await page.wait_for_url("**/home**", timeout=300_000)
            await page.wait_for_timeout(3000)
            print("Login successful! Session saved.", file=sys.stderr)
        except Exception:
            print(
                "Login timed out. Run `x-browser login` again.",
                file=sys.stderr,
            )
