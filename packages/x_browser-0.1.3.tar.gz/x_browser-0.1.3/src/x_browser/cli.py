"""CLI entry point for x-browser.

Mirrors the x-cli command interface but uses Playwright browser automation
instead of the X API.
"""

from __future__ import annotations

import asyncio
import functools
import sys
from dataclasses import dataclass
from typing import Any, Callable

import click

from . import actions, scrapers
from .browser import XBrowser, login_interactive
from .config import Config
from .formatters import output


# ---------------------------------------------------------------------------
# State object shared across commands
# ---------------------------------------------------------------------------

@dataclass
class State:
    mode: str  # human | json | plain | markdown
    verbose: bool
    config: Config
    headless: bool = True

    _browser: XBrowser | None = None

    async def get_browser(self) -> XBrowser:
        if self._browser is None:
            self._browser = XBrowser(headless=self.headless)
            await self._browser.launch()
        return self._browser

    async def get_page(self):
        xb = await self.get_browser()
        return xb.page

    async def cleanup(self):
        if self._browser:
            await self._browser.close()


pass_state = click.make_pass_decorator(State)


def async_command(fn: Callable) -> Callable:
    """Decorator to run an async Click command in asyncio."""

    @functools.wraps(fn)
    def wrapper(*args, **kwargs):
        return asyncio.run(fn(*args, **kwargs))

    return wrapper


# ---------------------------------------------------------------------------
# Root CLI group
# ---------------------------------------------------------------------------

@click.group()
@click.option("--json", "-j", "fmt", flag_value="json", help="Output raw JSON")
@click.option("--plain", "-p", "fmt", flag_value="plain", help="Output TSV")
@click.option(
    "--markdown", "-md", "fmt", flag_value="markdown", help="Output markdown"
)
@click.option("--verbose", "-v", is_flag=True, help="Show full details")
@click.option(
    "--min-delay",
    type=float,
    default=None,
    help="Min politeness delay in seconds (overrides config)",
)
@click.option(
    "--max-delay",
    type=float,
    default=None,
    help="Max politeness delay in seconds (overrides config)",
)
@click.option(
    "--headed",
    is_flag=True,
    help="Run browser in headed mode (visible window)",
)
@click.pass_context
def cli(ctx, fmt, verbose, min_delay, max_delay, headed):
    """x-browser: Browser-based X/Twitter CLI using Playwright."""
    config = Config.load()
    if min_delay is not None:
        config.min_politeness_delay = min_delay
    if max_delay is not None:
        config.max_politeness_delay = max_delay

    ctx.ensure_object(dict)
    ctx.obj = State(
        mode=fmt or "human",
        verbose=verbose,
        config=config,
        headless=not headed,
    )


# ---------------------------------------------------------------------------
# login
# ---------------------------------------------------------------------------

@cli.command("login")
@pass_state
@async_command
async def cmd_login(state: State):
    """Open browser for manual X login (one-time setup)."""
    await login_interactive()


# ---------------------------------------------------------------------------
# tweet group
# ---------------------------------------------------------------------------

@cli.group("tweet")
def tweet_group():
    """Tweet operations: post, get, delete, reply, quote, search, metrics."""
    pass


@tweet_group.command("post")
@click.argument("text")
@click.option("--poll", default=None, help="Comma-separated poll options")
@click.option("--poll-duration", default=1440, type=int, help="Poll duration in minutes")
@pass_state
@async_command
async def cmd_tweet_post(state: State, text: str, poll: str | None, poll_duration: int):
    """Post a new tweet."""
    page = await state.get_page()
    poll_options = [o.strip() for o in poll.split(",")] if poll else None
    try:
        result = await actions.tweet_post(
            page, text, config=state.config, poll_options=poll_options, poll_duration=poll_duration
        )
        output(result, mode=state.mode, verbose=state.verbose)
    finally:
        await state.cleanup()


@tweet_group.command("get")
@click.argument("id_or_url")
@pass_state
@async_command
async def cmd_tweet_get(state: State, id_or_url: str):
    """Fetch a single tweet."""
    page = await state.get_page()
    try:
        result = await scrapers.tweet_get(page, id_or_url)
        output(result, mode=state.mode, verbose=state.verbose)
    finally:
        await state.cleanup()


@tweet_group.command("delete")
@click.argument("id_or_url")
@pass_state
@async_command
async def cmd_tweet_delete(state: State, id_or_url: str):
    """Delete a tweet you own."""
    page = await state.get_page()
    try:
        result = await actions.tweet_delete(page, id_or_url, config=state.config)
        output(result, mode=state.mode, verbose=state.verbose)
    finally:
        await state.cleanup()


@tweet_group.command("reply")
@click.argument("id_or_url")
@click.argument("text")
@pass_state
@async_command
async def cmd_tweet_reply(state: State, id_or_url: str, text: str):
    """Reply to a tweet."""
    page = await state.get_page()
    try:
        result = await actions.tweet_reply(page, id_or_url, text, config=state.config)
        output(result, mode=state.mode, verbose=state.verbose)
    finally:
        await state.cleanup()


@tweet_group.command("quote")
@click.argument("id_or_url")
@click.argument("text")
@pass_state
@async_command
async def cmd_tweet_quote(state: State, id_or_url: str, text: str):
    """Quote a tweet."""
    page = await state.get_page()
    try:
        result = await actions.tweet_quote(page, id_or_url, text, config=state.config)
        output(result, mode=state.mode, verbose=state.verbose)
    finally:
        await state.cleanup()


@tweet_group.command("search")
@click.argument("query")
@click.option("--max", "max_results", default=10, type=int, help="Max results (default 10)")
@pass_state
@async_command
async def cmd_tweet_search(state: State, query: str, max_results: int):
    """Search for recent tweets."""
    page = await state.get_page()
    try:
        results = await scrapers.tweet_search(page, query, max_results=max_results)
        output(results, mode=state.mode, verbose=state.verbose)
    finally:
        await state.cleanup()


@tweet_group.command("metrics")
@click.argument("id_or_url")
@pass_state
@async_command
async def cmd_tweet_metrics(state: State, id_or_url: str):
    """Get engagement metrics for a tweet."""
    page = await state.get_page()
    try:
        result = await scrapers.tweet_metrics(page, id_or_url)
        output(result, mode=state.mode, verbose=state.verbose)
    finally:
        await state.cleanup()


# ---------------------------------------------------------------------------
# user group
# ---------------------------------------------------------------------------

@cli.group("user")
def user_group():
    """User operations: get, timeline, followers, following."""
    pass


@user_group.command("get")
@click.argument("username")
@pass_state
@async_command
async def cmd_user_get(state: State, username: str):
    """Lookup a user's profile."""
    page = await state.get_page()
    try:
        result = await scrapers.user_get(page, username)
        output(result, mode=state.mode, verbose=state.verbose)
    finally:
        await state.cleanup()


@user_group.command("timeline")
@click.argument("username")
@click.option("--max", "max_results", default=10, type=int, help="Max tweets (default 10)")
@pass_state
@async_command
async def cmd_user_timeline(state: State, username: str, max_results: int):
    """Fetch a user's recent tweets."""
    page = await state.get_page()
    try:
        results = await scrapers.user_timeline(page, username, max_results=max_results)
        output(results, mode=state.mode, verbose=state.verbose)
    finally:
        await state.cleanup()


@user_group.command("followers")
@click.argument("username")
@click.option("--max", "max_results", default=100, type=int, help="Max results (default 100)")
@pass_state
@async_command
async def cmd_user_followers(state: State, username: str, max_results: int):
    """List followers of a user."""
    page = await state.get_page()
    try:
        results = await scrapers.user_followers(page, username, max_results=max_results)
        output(results, mode=state.mode, verbose=state.verbose)
    finally:
        await state.cleanup()


@user_group.command("following")
@click.argument("username")
@click.option("--max", "max_results", default=100, type=int, help="Max results (default 100)")
@pass_state
@async_command
async def cmd_user_following(state: State, username: str, max_results: int):
    """List users that a user follows."""
    page = await state.get_page()
    try:
        results = await scrapers.user_following(page, username, max_results=max_results)
        output(results, mode=state.mode, verbose=state.verbose)
    finally:
        await state.cleanup()


# ---------------------------------------------------------------------------
# me group
# ---------------------------------------------------------------------------

@cli.group("me")
def me_group():
    """Authenticated user: mentions, bookmarks."""
    pass


@me_group.command("mentions")
@click.option("--max", "max_results", default=10, type=int, help="Max mentions (default 10)")
@pass_state
@async_command
async def cmd_me_mentions(state: State, max_results: int):
    """Fetch tweets that mention you."""
    page = await state.get_page()
    try:
        results = await scrapers.me_mentions(page, max_results=max_results)
        output(results, mode=state.mode, verbose=state.verbose)
    finally:
        await state.cleanup()


@me_group.command("bookmarks")
@click.option("--max", "max_results", default=10, type=int, help="Max bookmarks (default 10)")
@pass_state
@async_command
async def cmd_me_bookmarks(state: State, max_results: int):
    """Fetch your bookmarked tweets."""
    page = await state.get_page()
    try:
        results = await scrapers.me_bookmarks(page, max_results=max_results)
        output(results, mode=state.mode, verbose=state.verbose)
    finally:
        await state.cleanup()


@me_group.command("bookmark")
@click.argument("id_or_url")
@pass_state
@async_command
async def cmd_me_bookmark(state: State, id_or_url: str):
    """Bookmark a tweet."""
    page = await state.get_page()
    try:
        result = await actions.bookmark(page, id_or_url, config=state.config)
        output(result, mode=state.mode, verbose=state.verbose)
    finally:
        await state.cleanup()


@me_group.command("unbookmark")
@click.argument("id_or_url")
@pass_state
@async_command
async def cmd_me_unbookmark(state: State, id_or_url: str):
    """Remove a bookmark from a tweet."""
    page = await state.get_page()
    try:
        result = await actions.unbookmark(page, id_or_url, config=state.config)
        output(result, mode=state.mode, verbose=state.verbose)
    finally:
        await state.cleanup()


# ---------------------------------------------------------------------------
# Top-level quick actions
# ---------------------------------------------------------------------------

@cli.command("like")
@click.argument("id_or_url")
@pass_state
@async_command
async def cmd_like(state: State, id_or_url: str):
    """Like a tweet."""
    page = await state.get_page()
    try:
        result = await actions.like(page, id_or_url, config=state.config)
        output(result, mode=state.mode, verbose=state.verbose)
    finally:
        await state.cleanup()


@cli.command("retweet")
@click.argument("id_or_url")
@pass_state
@async_command
async def cmd_retweet(state: State, id_or_url: str):
    """Retweet (repost) a tweet."""
    page = await state.get_page()
    try:
        result = await actions.retweet(page, id_or_url, config=state.config)
        output(result, mode=state.mode, verbose=state.verbose)
    finally:
        await state.cleanup()


# ---------------------------------------------------------------------------
# Config management
# ---------------------------------------------------------------------------

@cli.command("config")
@click.option("--min-delay", type=float, help="Set min politeness delay (seconds)")
@click.option("--max-delay", type=float, help="Set max politeness delay (seconds)")
@click.option("--show", is_flag=True, help="Show current config")
@pass_state
def cmd_config(state: State, min_delay: float | None, max_delay: float | None, show: bool):
    """View or update persistent configuration."""
    config = Config.load()
    if show or (min_delay is None and max_delay is None):
        output(
            {
                "minPolitenessDelay": config.min_politeness_delay,
                "maxPolitenessDelay": config.max_politeness_delay,
            },
            mode=state.mode,
            verbose=state.verbose,
        )
        return

    if min_delay is not None:
        config.min_politeness_delay = min_delay
    if max_delay is not None:
        config.max_politeness_delay = max_delay
    config.save()
    print(
        f"Config saved: minPolitenessDelay={config.min_politeness_delay}s, "
        f"maxPolitenessDelay={config.max_politeness_delay}s",
        file=sys.stderr,
    )


# ---------------------------------------------------------------------------
# Entry point
# ---------------------------------------------------------------------------

def main():
    cli()


if __name__ == "__main__":
    main()
