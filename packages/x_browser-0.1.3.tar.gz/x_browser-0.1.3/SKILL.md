---
name: x-browser
description: Control X/Twitter through browser automation — post, like, retweet, reply, search, follow, and more. No API keys needed.
version: 0.1.0
---

# Skill: x-browser

You have access to **x-browser**, a tool that controls X/Twitter through a real browser. It can post tweets, like, retweet, reply, quote, delete, search, read profiles, follow users, and more — all without API keys.

## Setup (if not already installed)

```bash
pip install x-browser
# or
git clone https://github.com/shivamtiwari93/x-browser.git && cd x-browser && uv tool install .

# First-time login
x-browser login
```

Ensure `~/.local/bin` is in PATH.

---

## Capabilities

### Write Actions
| Action | Command |
|--------|---------|
| Post tweet | `x-browser tweet post 'text'` |
| Reply | `x-browser tweet reply <url> 'text'` |
| Quote tweet | `x-browser tweet quote <url> 'text'` |
| Delete tweet | `x-browser tweet delete <url>` |
| Like | `x-browser like <url>` |
| Retweet | `x-browser retweet <url>` |
| Bookmark | `x-browser me bookmark <url>` |
| Unbookmark | `x-browser me unbookmark <url>` |

### Read Actions
| Action | Command |
|--------|---------|
| Get tweet | `x-browser tweet get <url>` |
| Tweet metrics | `x-browser tweet metrics <url>` |
| Search tweets | `x-browser tweet search 'query' --max 20` |
| User profile | `x-browser user get <username>` |
| User timeline | `x-browser user timeline <username> --max 10` |
| User followers | `x-browser user followers <username> --max 50` |
| User following | `x-browser user following <username> --max 50` |
| Your mentions | `x-browser me mentions --max 20` |
| Your bookmarks | `x-browser me bookmarks --max 20` |

---

## Output Formats

| Flag | Format | Use case |
|------|--------|----------|
| (none) | Human-readable | Display to user |
| `-j` | JSON | Parsing programmatically |
| `-p` | TSV | Piping to other tools |
| `-md` | Markdown | Documentation |
| `-v` | Verbose | Full details + timestamps |

**Always use `-j` when processing output programmatically.**

Example: `x-browser -j tweet search 'AI' --max 5`

---

## Politeness Delay

Every write action waits a random 3–30 seconds before executing (default). Override:

```bash
x-browser --min-delay 1 --max-delay 5 like <url>      # faster
x-browser --min-delay 0 --max-delay 0 tweet post 'hi'  # no delay
```

---

## Automation Scripts

For long-running tasks, use the pre-built scripts:

```bash
cd /path/to/x-browser

# Search & like for 5 hours
uv run python scripts/search-and-like.py 'query' --hours 5

# Search & retweet
uv run python scripts/search-and-retweet.py 'query' --hours 3

# Full engagement (like + retweet + follow)
uv run python scripts/engagement-bot.py 'query' --hours 5

# Auto follow-back
uv run python scripts/auto-follow-back.py

# Auto reply to mentions
uv run python scripts/auto-reply-mentions.py --hours 8

# Post tweets from a file on schedule
uv run python scripts/scheduled-poster.py tweets.txt --interval 3600
```

---

## Python Module Usage

For complex multi-step tasks, write Python:

```python
import asyncio
from x_browser.browser import XBrowser
from x_browser.actions import tweet_post, like, retweet, follow
from x_browser.scrapers import tweet_search, user_get, user_timeline
from x_browser.config import Config

async def main():
    config = Config.load()
    async with XBrowser(headless=True) as xb:
        page = xb.page
        # your logic here

asyncio.run(main())
```

Run with: `uv run python your_script.py`

---

## Common Workflows

### Search and engage
```bash
x-browser -j tweet search 'topic' --max 10
x-browser like https://x.com/user/status/123456
x-browser tweet reply https://x.com/user/status/123456 'Great insight!'
```

### Research a user
```bash
x-browser -j user get username
x-browser -j user timeline username --max 20
x-browser -j user following username --max 50
```

### Post and verify
```bash
x-browser tweet post 'My tweet text'
x-browser -j user timeline myusername --max 1
```

---

## Important Notes

- **Single quotes** for text containing `!` or special characters
- **`--headed`** shows the browser window (useful for debugging)
- **Tweet URLs and numeric IDs** are interchangeable
- **Usernames** work with or without `@` prefix
- **One process at a time** — don't run multiple x-browser instances simultaneously
- **Session persists** in `~/.config/x-browser/chrome-data/` — run `x-browser login` if it expires
