# x-browser

A CLI and Python module for X/Twitter that works through browser automation — no API keys, no tier restrictions, no rate limits.

Uses [Playwright](https://playwright.dev/) to control your real Chrome installation via CDP. X cannot distinguish this from a human using Chrome.

---

## Quick Start

```bash
# 1. Install
git clone https://github.com/shivamtiwari93/x-browser.git
cd x-browser
uv tool install .

# 2. Login (one-time — opens Chrome, you log in normally)
x-browser login

# 3. Use it
x-browser tweet post 'Hello from x-browser!'
x-browser tweet search 'AI agents' --max 10
x-browser like https://x.com/user/status/123
```

### Install from PyPI

```bash
pip install x-browser
# or
uv tool install x-browser
```

### Install from Homebrew (macOS)

```bash
brew tap shivamtiwari93/tap
brew install x-browser
```

---

## Why not the API?

| | X API (x-cli) | Browser (x-browser) |
|---|---|---|
| **Setup** | 5 API keys from Developer Portal | Log into X once |
| **Likes** | Removed from Free tier | Works |
| **Replies** | Restricted on self-serve tiers | Works |
| **Bookmarks** | Requires Basic+ ($200/mo) | Works |
| **Post limits** | 500/mo on Free | Normal user limits |
| **Rate limits** | API rate limiting (429) | None |

---

## CLI Reference

### Tweets

```bash
x-browser tweet post 'Hello world'
x-browser tweet post --poll 'Yes,No' 'Do you like polls?'
x-browser tweet get <id-or-url>
x-browser tweet delete <id-or-url>
x-browser tweet reply <id-or-url> 'nice post'
x-browser tweet quote <id-or-url> 'this is important'
x-browser tweet search 'machine learning' --max 20
x-browser tweet metrics <id-or-url>
```

### Users

```bash
x-browser user get elonmusk
x-browser user timeline elonmusk --max 10
x-browser user followers elonmusk --max 50
x-browser user following elonmusk
```

### Self (authenticated user)

```bash
x-browser me mentions --max 20
x-browser me bookmarks
x-browser me bookmark <id-or-url>
x-browser me unbookmark <id-or-url>
```

### Quick actions

```bash
x-browser like <id-or-url>
x-browser retweet <id-or-url>
```

### Output formats

```bash
x-browser -j tweet get <id>        # JSON output
x-browser -p user get elonmusk     # TSV (pipe to awk/cut)
x-browser -md tweet get <id>       # Markdown
x-browser -v tweet get <id>        # Verbose (timestamps, full metrics)
x-browser --headed tweet post 'hi' # Show browser window
```

---

## Automation Scripts

Ready-to-run scripts in `scripts/` for long-running tasks:

### Search & Like

Search for tweets and like them continuously:

```bash
uv run python scripts/search-and-like.py 'YC W26' --hours 5 --headed
uv run python scripts/search-and-like.py 'AI agents' --hours 8 --min-delay 10 --max-delay 60
```

### Search & Retweet

Search and retweet matching posts:

```bash
uv run python scripts/search-and-retweet.py 'AI startups' --hours 3 --headed
```

### Engagement Bot

Full engagement: search, then like + retweet + follow the author:

```bash
uv run python scripts/engagement-bot.py 'YC W26' --hours 5 --headed
uv run python scripts/engagement-bot.py 'AI agents' --skip-follow --hours 3   # like + retweet only
uv run python scripts/engagement-bot.py 'web3' --skip-retweet --hours 2        # like + follow only
```

### Auto Follow-Back

Check your followers and follow back anyone you're not already following:

```bash
uv run python scripts/auto-follow-back.py --headed
uv run python scripts/auto-follow-back.py --max-check 200 --dry-run   # preview without acting
```

### Auto Reply Mentions

Monitor your mentions and auto-reply with templates:

```bash
uv run python scripts/auto-reply-mentions.py --hours 8 --headed
uv run python scripts/auto-reply-mentions.py --reply 'Thanks for the mention!' --hours 2
uv run python scripts/auto-reply-mentions.py --replies-file my-replies.txt --hours 12
```

### Scheduled Poster

Post tweets from a text file on a schedule:

```bash
# Create a tweets file (one per line, # comments ignored)
echo 'Hello world!
Check out x-browser
# this line is skipped
Another scheduled tweet' > tweets.txt

uv run python scripts/scheduled-poster.py tweets.txt --interval 3600 --headed     # every hour
uv run python scripts/scheduled-poster.py tweets.txt --interval 1800 --random-order  # every 30min, shuffled
uv run python scripts/scheduled-poster.py tweets.txt --interval 600 --loop          # every 10min, loop forever
```

---

## Use as a Python Module

```python
import asyncio
from x_browser.browser import XBrowser
from x_browser.actions import tweet_post, like, retweet, follow
from x_browser.scrapers import tweet_search, user_get, user_timeline
from x_browser.config import Config

async def main():
    config = Config.load()
    async with XBrowser(headless=True) as xb:
        page = xb.page

        # Post a tweet
        await tweet_post(page, "Hello from Python!", config=config)

        # Search and like
        tweets = await tweet_search(page, "YC W26", max_results=10)
        for tweet in tweets:
            await like(page, tweet["url"], config=config)

        # Follow a user
        await follow(page, "elonmusk", config=config)

        # Get user profile
        profile = await user_get(page, "elonmusk")
        print(profile)

asyncio.run(main())
```

### Custom delays per call

```python
await like(page, url, min_delay=5, max_delay=15)
await tweet_post(page, text, min_delay=0, max_delay=0)  # no delay
```

### Install as a dependency

```bash
# In your project
pip install x-browser
# or add to pyproject.toml
# dependencies = ["x-browser"]
```

```python
# Then import directly
from x_browser.browser import XBrowser
from x_browser.actions import tweet_post
```

---

## AI Agent Integration

### Claude Code

Add x-browser as a slash command so Claude can use it:

```bash
# Copy SKILL.md to your Claude commands
mkdir -p ~/.claude/commands
cp SKILL.md ~/.claude/commands/x-browser.md
```

Now Claude Code can use `/x-browser` to see all available commands.

Or add it to a specific project:

```bash
mkdir -p .claude/commands
cp /path/to/x-browser/SKILL.md .claude/commands/x-browser.md
```

### OpenClaw / Other AI Agents

Add the contents of `SKILL.md` to your agent's system prompt or tool configuration. The file is structured so any LLM can parse and use the commands.

### Building with x-browser

If you're building an AI agent that needs X/Twitter capabilities:

```python
# In your agent's tool implementation
from x_browser.browser import XBrowser
from x_browser.actions import tweet_post, like
from x_browser.scrapers import tweet_search

async def x_post_tool(text: str):
    async with XBrowser() as xb:
        return await tweet_post(xb.page, text)
```

---

## Politeness Delay

Every write action (post, like, retweet, reply, quote, delete, bookmark, follow) waits a random delay before executing. This makes behavior look human.

**Defaults:** 3 – 30 seconds

### Configure

```bash
# Per-run override
x-browser --min-delay 5 --max-delay 30 like <url>

# Persistent config
x-browser config --min-delay 5 --max-delay 30

# View current config
x-browser config --show
```

Config is stored in `~/.config/x-browser/config.json`.

---

## How It Works

1. **Chrome launches as a normal process** — no automation flags, no bundled Chromium
2. **Playwright connects via CDP** (Chrome DevTools Protocol) — passive observer
3. **Session persists** in `~/.config/x-browser/chrome-data/` — login once, use forever
4. X sees a real Chrome browser with real cookies — indistinguishable from a human

---

## Troubleshooting

### "Google Chrome not found"
Install Chrome or set the path. x-browser looks in `/Applications/Google Chrome.app/`.

### Login fails / "Could not log you in"
Clear the session and try again:
```bash
rm -rf ~/.config/x-browser/chrome-data
x-browser login
```

### Shell interprets `!` in tweet text
Use single quotes: `x-browser tweet post 'Hello, World!'`

### `command not found: x-browser`
Add `~/.local/bin` to your PATH:
```bash
echo 'export PATH="$HOME/.local/bin:$PATH"' >> ~/.zshrc
source ~/.zshrc
```

---

## Acknowledgements

Inspired by [x-cli](https://github.com/Infatoshi/x-cli) by Infatoshi — the API-based counterpart to this project.

## License

MIT
