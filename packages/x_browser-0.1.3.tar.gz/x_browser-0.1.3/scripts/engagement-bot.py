"""Full engagement bot: search a query, then like + retweet + follow the author.

Usage:
    python scripts/engagement-bot.py "AI startups" --hours 5
    python scripts/engagement-bot.py "YC W26" --hours 8 --skip-follow --min-delay 10 --max-delay 60
"""

from __future__ import annotations

import argparse
import asyncio
import re
import sys
import time

sys.path.insert(0, str(__import__("pathlib").Path(__file__).resolve().parent.parent / "src"))

from x_browser.browser import XBrowser
from x_browser.config import Config
from x_browser.actions import like, retweet, follow


async def _extract_tweet_ids_from_page(page) -> list[dict]:
    tweets = []
    articles = await page.query_selector_all('article[data-testid="tweet"]')
    for article in articles:
        try:
            time_el = await article.query_selector("time")
            if not time_el:
                continue
            parent_a = await time_el.evaluate_handle("el => el.closest('a')")
            if not parent_a:
                continue
            href = await parent_a.get_attribute("href")
            if not href or "/status/" not in href:
                continue
            match = re.search(r"/status/(\d+)", href)
            if not match:
                continue

            tweet_id = match.group(1)
            url = f"https://x.com{href}"

            author = ""
            user_link = await article.query_selector('div[data-testid="User-Name"] a')
            if user_link:
                user_href = await user_link.get_attribute("href") or ""
                author = user_href.strip("/").split("/")[0]

            text = ""
            text_el = await article.query_selector('div[data-testid="tweetText"]')
            if text_el:
                text = (await text_el.inner_text()).strip()

            tweets.append({"id": tweet_id, "url": url, "author": author, "text": text})
        except Exception:
            continue
    return tweets


async def main():
    parser = argparse.ArgumentParser(description="Engagement bot: like + retweet + follow")
    parser.add_argument("query", help="Search query")
    parser.add_argument("--hours", type=float, default=5, help="How long to run (default: 5)")
    parser.add_argument("--skip-like", action="store_true", help="Skip liking")
    parser.add_argument("--skip-retweet", action="store_true", help="Skip retweeting")
    parser.add_argument("--skip-follow", action="store_true", help="Skip following authors")
    parser.add_argument("--min-delay", type=float, default=None, help="Min delay between actions")
    parser.add_argument("--max-delay", type=float, default=None, help="Max delay between actions")
    parser.add_argument("--headed", action="store_true", help="Show browser window")
    args = parser.parse_args()

    config = Config.load()
    if args.min_delay is not None:
        config.min_politeness_delay = args.min_delay
    if args.max_delay is not None:
        config.max_politeness_delay = args.max_delay

    actions_per_tweet = []
    if not args.skip_like:
        actions_per_tweet.append("like")
    if not args.skip_retweet:
        actions_per_tweet.append("retweet")
    if not args.skip_follow:
        actions_per_tweet.append("follow")

    if not actions_per_tweet:
        print("\u274c All actions skipped. Nothing to do.", file=sys.stderr)
        return

    deadline = time.monotonic() + (args.hours * 3600)
    processed_ids: set[str] = set()
    followed_authors: set[str] = set()
    stats = {"liked": 0, "retweeted": 0, "followed": 0}
    dry_streak = 0

    print(f"\U0001f916 Engagement bot for: {args.query}", file=sys.stderr)
    print(f"\u23f1\ufe0f  Running for {args.hours} hours", file=sys.stderr)
    print(f"\U0001f3af Actions per tweet: {', '.join(actions_per_tweet)}", file=sys.stderr)
    print("\u2500" * 50, file=sys.stderr)

    async with XBrowser(headless=not args.headed) as xb:
        page = xb.page
        encoded = args.query.replace(" ", "%20")
        await page.goto(
            f"https://x.com/search?q={encoded}&src=typed_query&f=live",
            wait_until="domcontentloaded",
        )
        await page.wait_for_timeout(4000)

        while time.monotonic() < deadline:
            tweets = await _extract_tweet_ids_from_page(page)
            new_tweets = [t for t in tweets if t["id"] not in processed_ids]

            if not new_tweets:
                dry_streak += 1
                if dry_streak >= 15:
                    print(f"\n\U0001f504 Reloading search...", file=sys.stderr)
                    await page.goto(
                        f"https://x.com/search?q={encoded}&src=typed_query&f=live",
                        wait_until="domcontentloaded",
                    )
                    await page.wait_for_timeout(4000)
                    dry_streak = 0
                    continue
                await page.evaluate("window.scrollBy(0, 800)")
                await page.wait_for_timeout(2000)
                continue

            dry_streak = 0
            for tweet in new_tweets:
                if time.monotonic() >= deadline:
                    break

                text_preview = (tweet["text"][:50] + "...") if len(tweet["text"]) > 50 else tweet["text"]
                total = stats["liked"] + stats["retweeted"] + stats["followed"]
                print(f"\n\U0001f4cc [{total}] @{tweet['author']}: {text_preview}", file=sys.stderr)

                # Like
                if "like" in actions_per_tweet:
                    try:
                        await like(page, tweet["url"], config=config)
                        stats["liked"] += 1
                        print(f"   \u2764\ufe0f  Liked", file=sys.stderr)
                    except Exception as e:
                        print(f"   \u274c Like failed: {e}", file=sys.stderr)

                # Retweet
                if "retweet" in actions_per_tweet:
                    try:
                        await retweet(page, tweet["url"], config=config)
                        stats["retweeted"] += 1
                        print(f"   \U0001f501 Retweeted", file=sys.stderr)
                    except Exception as e:
                        print(f"   \u274c Retweet failed: {e}", file=sys.stderr)

                # Follow author
                if "follow" in actions_per_tweet and tweet["author"] and tweet["author"] not in followed_authors:
                    try:
                        result = await follow(page, tweet["author"], config=config)
                        followed_authors.add(tweet["author"])
                        if result.get("followed"):
                            stats["followed"] += 1
                            print(f"   \U0001f464 Followed @{tweet['author']}", file=sys.stderr)
                        else:
                            print(f"   \u2714\ufe0f  Already following @{tweet['author']}", file=sys.stderr)
                    except Exception as e:
                        print(f"   \u274c Follow failed: {e}", file=sys.stderr)
                        followed_authors.add(tweet["author"])

                processed_ids.add(tweet["id"])

            # Navigate back to search if needed
            if "/search" not in page.url:
                await page.goto(
                    f"https://x.com/search?q={encoded}&src=typed_query&f=live",
                    wait_until="domcontentloaded",
                )
                await page.wait_for_timeout(3000)
                for _ in range(min(len(processed_ids) // 3, 20)):
                    await page.evaluate("window.scrollBy(0, 800)")
                    await page.wait_for_timeout(500)

            await page.evaluate("window.scrollBy(0, 800)")
            await page.wait_for_timeout(2000)

    print(f"\n\u2500" * 50, file=sys.stderr)
    print(f"\u2705 Done!", file=sys.stderr)
    print(f"   \u2764\ufe0f  Liked: {stats['liked']}", file=sys.stderr)
    print(f"   \U0001f501 Retweeted: {stats['retweeted']}", file=sys.stderr)
    print(f"   \U0001f464 Followed: {stats['followed']}", file=sys.stderr)


if __name__ == "__main__":
    asyncio.run(main())
