"""Post tweets from a text file on a schedule.

Create a file with one tweet per line, and this script will post them
at regular intervals.

Usage:
    python scripts/scheduled-poster.py tweets.txt --interval 60
    python scripts/scheduled-poster.py tweets.txt --interval 3600 --headed
    python scripts/scheduled-poster.py tweets.txt --random-order --interval 1800

tweets.txt format (one tweet per line, blank lines and # comments ignored):
    Hello world!
    Check out our new project
    # this is a comment, skipped
    Another tweet here
"""

from __future__ import annotations

import argparse
import asyncio
import random
import sys
import time
from pathlib import Path

sys.path.insert(0, str(__import__("pathlib").Path(__file__).resolve().parent.parent / "src"))

from x_browser.browser import XBrowser
from x_browser.config import Config
from x_browser.actions import tweet_post


def load_tweets(filepath: str) -> list[str]:
    """Load tweets from a text file. Skips blank lines and # comments."""
    path = Path(filepath)
    if not path.exists():
        print(f"\u274c File not found: {filepath}", file=sys.stderr)
        sys.exit(1)
    tweets = []
    for line in path.read_text().splitlines():
        line = line.strip()
        if line and not line.startswith("#"):
            tweets.append(line)
    return tweets


async def main():
    parser = argparse.ArgumentParser(description="Post tweets from a file on a schedule")
    parser.add_argument("file", help="Text file with one tweet per line")
    parser.add_argument("--interval", type=float, default=3600, help="Seconds between posts (default: 3600 = 1 hour)")
    parser.add_argument("--random-order", action="store_true", help="Shuffle tweet order")
    parser.add_argument("--loop", action="store_true", help="Loop back to start after all tweets are posted")
    parser.add_argument("--min-delay", type=float, default=None, help="Min politeness delay")
    parser.add_argument("--max-delay", type=float, default=None, help="Max politeness delay")
    parser.add_argument("--headed", action="store_true", help="Show browser window")
    parser.add_argument("--dry-run", action="store_true", help="Show what would be posted without doing it")
    args = parser.parse_args()

    config = Config.load()
    if args.min_delay is not None:
        config.min_politeness_delay = args.min_delay
    if args.max_delay is not None:
        config.max_politeness_delay = args.max_delay

    tweets = load_tweets(args.file)
    if not tweets:
        print("\u274c No tweets found in file.", file=sys.stderr)
        return

    if args.random_order:
        random.shuffle(tweets)

    print(f"\U0001f4dd Loaded {len(tweets)} tweets from {args.file}", file=sys.stderr)
    print(f"\u23f0 Posting every {args.interval}s ({args.interval/60:.1f} min)", file=sys.stderr)
    if args.loop:
        print(f"\U0001f501 Looping enabled — will restart from beginning after all tweets", file=sys.stderr)
    print("\u2500" * 50, file=sys.stderr)

    total_posted = 0
    tweet_index = 0

    async with XBrowser(headless=not args.headed) as xb:
        page = xb.page

        while True:
            if tweet_index >= len(tweets):
                if args.loop:
                    print(f"\n\U0001f501 All tweets posted. Looping back to start...", file=sys.stderr)
                    tweet_index = 0
                    if args.random_order:
                        random.shuffle(tweets)
                else:
                    break

            text = tweets[tweet_index]
            tweet_index += 1

            text_preview = (text[:60] + "...") if len(text) > 60 else text

            if args.dry_run:
                print(f"\U0001f4e4 [DRY RUN] [{total_posted + 1}/{len(tweets)}] Would post: {text_preview}", file=sys.stderr)
                total_posted += 1
            else:
                try:
                    await tweet_post(page, text, config=config)
                    total_posted += 1
                    print(f"\U0001f4e4 [{total_posted}/{len(tweets)}] Posted: {text_preview}", file=sys.stderr)
                except Exception as e:
                    print(f"\u274c Failed to post: {e}", file=sys.stderr)

            # Wait for next scheduled post
            if tweet_index < len(tweets) or args.loop:
                next_time = time.strftime("%H:%M:%S", time.localtime(time.time() + args.interval))
                print(f"   \u23f3 Next post at {next_time}", file=sys.stderr)
                await asyncio.sleep(args.interval)

    print(f"\n\u2705 Done! Posted {total_posted} tweets.", file=sys.stderr)


if __name__ == "__main__":
    asyncio.run(main())
