"""Check your followers and follow back anyone you're not already following.

Usage:
    python scripts/auto-follow-back.py --headed
    python scripts/auto-follow-back.py --max-check 200 --min-delay 5 --max-delay 30
"""

from __future__ import annotations

import argparse
import asyncio
import sys

sys.path.insert(0, str(__import__("pathlib").Path(__file__).resolve().parent.parent / "src"))

from x_browser.browser import XBrowser
from x_browser.config import Config
from x_browser.actions import follow
from x_browser.scrapers import user_followers, user_following


async def main():
    parser = argparse.ArgumentParser(description="Auto follow-back on X")
    parser.add_argument("--username", default=None, help="Your username (auto-detected if logged in)")
    parser.add_argument("--max-check", type=int, default=100, help="Max followers to check (default: 100)")
    parser.add_argument("--min-delay", type=float, default=None, help="Min delay between follows")
    parser.add_argument("--max-delay", type=float, default=None, help="Max delay between follows")
    parser.add_argument("--headed", action="store_true", help="Show browser window")
    parser.add_argument("--dry-run", action="store_true", help="Show who would be followed without doing it")
    args = parser.parse_args()

    config = Config.load()
    if args.min_delay is not None:
        config.min_politeness_delay = args.min_delay
    if args.max_delay is not None:
        config.max_politeness_delay = args.max_delay

    async with XBrowser(headless=not args.headed) as xb:
        page = xb.page

        # Detect username if not provided
        username = args.username
        if not username:
            await page.goto("https://x.com/home", wait_until="domcontentloaded")
            await page.wait_for_timeout(3000)
            profile_link = await page.query_selector('a[data-testid="AppTabBar_Profile_Link"]')
            if profile_link:
                href = await profile_link.get_attribute("href") or ""
                username = href.strip("/")
            if not username:
                print("\u274c Could not detect username. Pass --username.", file=sys.stderr)
                return

        print(f"\U0001f464 Checking followers for @{username}...", file=sys.stderr)

        # Get followers and following lists
        print(f"   Fetching followers (max {args.max_check})...", file=sys.stderr)
        followers = await user_followers(page, username, max_results=args.max_check)
        follower_names = {f["username"] for f in followers if f.get("username")}
        print(f"   Found {len(follower_names)} followers", file=sys.stderr)

        print(f"   Fetching who you follow...", file=sys.stderr)
        following = await user_following(page, username, max_results=1000)
        following_names = {f["username"] for f in following if f.get("username")}
        print(f"   You follow {len(following_names)} accounts", file=sys.stderr)

        # Find who follows you but you don't follow back
        not_following_back = follower_names - following_names
        print(f"\n\U0001f4cb {len(not_following_back)} followers you're not following back", file=sys.stderr)
        print("\u2500" * 50, file=sys.stderr)

        if not not_following_back:
            print("\u2705 You're following everyone back!", file=sys.stderr)
            return

        total_followed = 0
        for uname in sorted(not_following_back):
            if args.dry_run:
                print(f"   [DRY RUN] Would follow @{uname}", file=sys.stderr)
                total_followed += 1
                continue

            try:
                result = await follow(page, uname, config=config)
                if result.get("ok"):
                    total_followed += 1
                    if result.get("followed"):
                        print(f"\u2705 [{total_followed}] Followed @{uname}", file=sys.stderr)
                    else:
                        print(f"\u2714\ufe0f  [{total_followed}] Already following @{uname}", file=sys.stderr)
            except Exception as e:
                print(f"\u274c Failed to follow @{uname}: {e}", file=sys.stderr)

        print(f"\n\U0001f389 Done! Followed {total_followed} accounts.", file=sys.stderr)


if __name__ == "__main__":
    asyncio.run(main())
