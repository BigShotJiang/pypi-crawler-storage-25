"""Monitor your mentions and auto-reply with configurable templates.

Usage:
    python scripts/auto-reply-mentions.py --headed
    python scripts/auto-reply-mentions.py --reply "Thanks for the mention!" --hours 2
    python scripts/auto-reply-mentions.py --replies-file replies.txt --hours 8
"""

from __future__ import annotations

import argparse
import asyncio
import random
import sys
import time

sys.path.insert(0, str(__import__("pathlib").Path(__file__).resolve().parent.parent / "src"))

from x_browser.browser import XBrowser
from x_browser.config import Config
from x_browser.actions import tweet_reply
from x_browser.scrapers import me_mentions


DEFAULT_REPLIES = [
    "Thanks for the mention! \U0001f64f",
    "Appreciate the shoutout! \U0001f525",
    "Thanks! Glad you found this useful.",
    "Hey, thanks for tagging us! \U0001f680",
    "Much appreciated! \U0001f4aa",
]


async def main():
    parser = argparse.ArgumentParser(description="Auto-reply to mentions on X")
    parser.add_argument("--reply", default=None, help="Fixed reply text (used for all replies)")
    parser.add_argument(
        "--replies-file", default=None,
        help="Text file with one reply per line (random selection per mention)",
    )
    parser.add_argument("--hours", type=float, default=1, help="How long to monitor (default: 1)")
    parser.add_argument("--check-interval", type=float, default=120, help="Seconds between mention checks (default: 120)")
    parser.add_argument("--max-per-check", type=int, default=10, help="Max mentions to fetch per check")
    parser.add_argument("--min-delay", type=float, default=None, help="Min delay between replies")
    parser.add_argument("--max-delay", type=float, default=None, help="Max delay between replies")
    parser.add_argument("--headed", action="store_true", help="Show browser window")
    parser.add_argument("--dry-run", action="store_true", help="Show what would be replied without doing it")
    args = parser.parse_args()

    config = Config.load()
    if args.min_delay is not None:
        config.min_politeness_delay = args.min_delay
    if args.max_delay is not None:
        config.max_politeness_delay = args.max_delay

    # Build reply templates
    if args.reply:
        replies = [args.reply]
    elif args.replies_file:
        with open(args.replies_file) as f:
            replies = [line.strip() for line in f if line.strip()]
        if not replies:
            print("\u274c Replies file is empty.", file=sys.stderr)
            return
    else:
        replies = DEFAULT_REPLIES

    deadline = time.monotonic() + (args.hours * 3600)
    replied_ids: set[str] = set()
    total_replied = 0

    print(f"\U0001f514 Monitoring mentions for {args.hours} hours", file=sys.stderr)
    print(f"\U0001f4ac Using {len(replies)} reply template(s)", file=sys.stderr)
    print(f"\U0001f504 Checking every {args.check_interval}s", file=sys.stderr)
    print("\u2500" * 50, file=sys.stderr)

    async with XBrowser(headless=not args.headed) as xb:
        page = xb.page

        while time.monotonic() < deadline:
            print(f"\n\U0001f50d Checking mentions...", file=sys.stderr)

            try:
                mentions = await me_mentions(page, max_results=args.max_per_check)
            except Exception as e:
                print(f"\u274c Failed to fetch mentions: {e}", file=sys.stderr)
                await asyncio.sleep(60)
                continue

            new_mentions = [m for m in mentions if m.get("id") and m["id"] not in replied_ids]

            if not new_mentions:
                print(f"   No new mentions. Next check in {args.check_interval}s...", file=sys.stderr)
            else:
                print(f"   Found {len(new_mentions)} new mention(s)", file=sys.stderr)

            for mention in new_mentions:
                if time.monotonic() >= deadline:
                    break

                tweet_id = mention["id"]
                url = mention.get("url", f"https://x.com/i/status/{tweet_id}")
                author = mention.get("author_username", "someone")
                text_preview = (mention.get("text", "")[:50] + "...") if len(mention.get("text", "")) > 50 else mention.get("text", "")
                reply_text = random.choice(replies)

                if args.dry_run:
                    print(f"   [DRY RUN] Would reply to @{author}: \"{reply_text}\"", file=sys.stderr)
                    replied_ids.add(tweet_id)
                    total_replied += 1
                    continue

                try:
                    await tweet_reply(page, url, reply_text, config=config)
                    replied_ids.add(tweet_id)
                    total_replied += 1
                    print(
                        f"\U0001f4ac [{total_replied}] Replied to @{author} ({text_preview})",
                        file=sys.stderr,
                    )
                except Exception as e:
                    print(f"\u274c Failed to reply to {url}: {e}", file=sys.stderr)
                    replied_ids.add(tweet_id)  # skip it

            # Wait before next check
            if time.monotonic() < deadline:
                wait = min(args.check_interval, deadline - time.monotonic())
                if wait > 0:
                    await asyncio.sleep(wait)

    print(f"\n\u2705 Done! Replied to {total_replied} mentions.", file=sys.stderr)


if __name__ == "__main__":
    asyncio.run(main())
