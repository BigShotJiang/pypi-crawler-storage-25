"""Search for a query on X and like every result, scrolling continuously for hours.

Usage:
    python scripts/search-and-like.py "YC W26" --hours 5
    python scripts/search-and-like.py "YC W26" --hours 5 --min-delay 30 --max-delay 120
"""

from __future__ import annotations

import argparse
import asyncio
import re
import sys
import time

sys.path.insert(0, str(__import__("pathlib").Path(__file__).resolve().parent.parent / "src"))

from x_browser.browser import XBrowser
from x_browser.config import Config
from x_browser.actions import like, _normalize_tweet_url


async def _extract_tweet_ids_from_page(page) -> list[dict]:
    """Extract tweet IDs and URLs from currently visible articles."""
    tweets = []
    articles = await page.query_selector_all('article[data-testid="tweet"]')
    for article in articles:
        try:
            # Get tweet URL/ID from the timestamp link
            time_el = await article.query_selector("time")
            if not time_el:
                continue
            parent_a = await time_el.evaluate_handle("el => el.closest('a')")
            if not parent_a:
                continue
            href = await parent_a.get_attribute("href")
            if not href or "/status/" not in href:
                continue
            match = re.search(r"/status/(\d+)", href)
            if not match:
                continue

            tweet_id = match.group(1)
            url = f"https://x.com{href}"

            # Get author
            author = ""
            user_link = await article.query_selector('div[data-testid="User-Name"] a')
            if user_link:
                user_href = await user_link.get_attribute("href") or ""
                author = user_href.strip("/").split("/")[0]

            # Get text preview
            text = ""
            text_el = await article.query_selector('div[data-testid="tweetText"]')
            if text_el:
                text = (await text_el.inner_text()).strip()

            tweets.append({
                "id": tweet_id,
                "url": url,
                "author": author,
                "text": text,
            })
        except Exception:
            continue
    return tweets


async def main():
    parser = argparse.ArgumentParser(description="Search & like posts on X")
    parser.add_argument("query", help="Search query (e.g. 'YC W26')")
    parser.add_argument("--hours", type=float, default=5, help="How long to run (default: 5)")
    parser.add_argument("--min-delay", type=float, default=None, help="Min delay between likes (seconds)")
    parser.add_argument("--max-delay", type=float, default=None, help="Max delay between likes (seconds)")
    parser.add_argument("--headed", action="store_true", help="Show browser window")
    args = parser.parse_args()

    config = Config.load()
    if args.min_delay is not None:
        config.min_politeness_delay = args.min_delay
    if args.max_delay is not None:
        config.max_politeness_delay = args.max_delay

    deadline = time.monotonic() + (args.hours * 3600)
    liked_ids: set[str] = set()
    total_liked = 0
    dry_streak = 0  # consecutive scrolls with 0 new tweets

    print(f"\U0001f50d Searching for: {args.query}", file=sys.stderr)
    print(f"\u23f1\ufe0f  Running for {args.hours} hours", file=sys.stderr)
    print(
        f"\u23f3 Politeness delay: {config.min_politeness_delay}s \u2013 {config.max_politeness_delay}s",
        file=sys.stderr,
    )
    print("\u2500" * 50, file=sys.stderr)

    async with XBrowser(headless=not args.headed) as xb:
        page = xb.page

        # Load search page once
        encoded = args.query.replace(" ", "%20")
        await page.goto(
            f"https://x.com/search?q={encoded}&src=typed_query&f=live",
            wait_until="domcontentloaded",
        )
        await page.wait_for_timeout(4000)

        while time.monotonic() < deadline:
            # Extract tweets currently visible on page
            tweets = await _extract_tweet_ids_from_page(page)

            # Filter to only unseen tweets
            new_tweets = [t for t in tweets if t["id"] not in liked_ids]

            if not new_tweets:
                dry_streak += 1
                if dry_streak >= 15:
                    # Searched deep enough, reload with fresh results
                    print(
                        f"\n\U0001f504 No new tweets after {dry_streak} scrolls. "
                        "Reloading search...",
                        file=sys.stderr,
                    )
                    await page.goto(
                        f"https://x.com/search?q={encoded}&src=typed_query&f=live",
                        wait_until="domcontentloaded",
                    )
                    await page.wait_for_timeout(4000)
                    dry_streak = 0
                    continue

                # Scroll down to load more
                await page.evaluate("window.scrollBy(0, 800)")
                await page.wait_for_timeout(2000)
                continue

            dry_streak = 0

            # Like each new tweet
            for tweet in new_tweets:
                if time.monotonic() >= deadline:
                    print("\n\u23f0 Time's up!", file=sys.stderr)
                    break

                text_preview = (
                    (tweet["text"][:60] + "...") if len(tweet["text"]) > 60
                    else tweet["text"]
                )

                try:
                    result = await like(page, tweet["url"], config=config)
                    liked_ids.add(tweet["id"])
                    if result.get("already_liked"):
                        print(
                            f"\u2705 Already liked @{tweet['author']}: {text_preview}",
                            file=sys.stderr,
                        )
                    else:
                        total_liked += 1
                        print(
                            f"\u2764\ufe0f  [{total_liked}] Liked @{tweet['author']}: {text_preview}",
                            file=sys.stderr,
                        )
                except Exception as e:
                    print(f"\u274c Failed to like {tweet['url']}: {e}", file=sys.stderr)
                    liked_ids.add(tweet["id"])  # skip it either way

            # After liking visible tweets, navigate back to search and scroll further
            if "/search" not in page.url:
                await page.goto(
                    f"https://x.com/search?q={encoded}&src=typed_query&f=live",
                    wait_until="domcontentloaded",
                )
                await page.wait_for_timeout(3000)
                # Scroll past already-seen tweets
                for _ in range(min(len(liked_ids) // 3, 20)):
                    await page.evaluate("window.scrollBy(0, 800)")
                    await page.wait_for_timeout(500)

            # Scroll down for more
            await page.evaluate("window.scrollBy(0, 800)")
            await page.wait_for_timeout(2000)

    print(f"\n\u2705 Done! Liked {total_liked} tweets total.", file=sys.stderr)


if __name__ == "__main__":
    asyncio.run(main())
