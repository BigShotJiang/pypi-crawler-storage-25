"""Search for a query on X and retweet matching posts continuously.

Usage:
    python scripts/search-and-retweet.py "AI agents" --hours 3
    python scripts/search-and-retweet.py "YC W26" --hours 5 --min-delay 30 --max-delay 120
"""

from __future__ import annotations

import argparse
import asyncio
import re
import sys
import time

sys.path.insert(0, str(__import__("pathlib").Path(__file__).resolve().parent.parent / "src"))

from x_browser.browser import XBrowser
from x_browser.config import Config
from x_browser.actions import retweet


async def _extract_tweet_ids_from_page(page) -> list[dict]:
    """Extract tweet IDs and metadata from currently visible articles."""
    tweets = []
    articles = await page.query_selector_all('article[data-testid="tweet"]')
    for article in articles:
        try:
            time_el = await article.query_selector("time")
            if not time_el:
                continue
            parent_a = await time_el.evaluate_handle("el => el.closest('a')")
            if not parent_a:
                continue
            href = await parent_a.get_attribute("href")
            if not href or "/status/" not in href:
                continue
            match = re.search(r"/status/(\d+)", href)
            if not match:
                continue

            tweet_id = match.group(1)
            url = f"https://x.com{href}"

            author = ""
            user_link = await article.query_selector('div[data-testid="User-Name"] a')
            if user_link:
                user_href = await user_link.get_attribute("href") or ""
                author = user_href.strip("/").split("/")[0]

            text = ""
            text_el = await article.query_selector('div[data-testid="tweetText"]')
            if text_el:
                text = (await text_el.inner_text()).strip()

            tweets.append({"id": tweet_id, "url": url, "author": author, "text": text})
        except Exception:
            continue
    return tweets


async def main():
    parser = argparse.ArgumentParser(description="Search & retweet posts on X")
    parser.add_argument("query", help="Search query")
    parser.add_argument("--hours", type=float, default=3, help="How long to run (default: 3)")
    parser.add_argument("--min-delay", type=float, default=None, help="Min delay between retweets")
    parser.add_argument("--max-delay", type=float, default=None, help="Max delay between retweets")
    parser.add_argument("--headed", action="store_true", help="Show browser window")
    args = parser.parse_args()

    config = Config.load()
    if args.min_delay is not None:
        config.min_politeness_delay = args.min_delay
    if args.max_delay is not None:
        config.max_politeness_delay = args.max_delay

    deadline = time.monotonic() + (args.hours * 3600)
    retweeted_ids: set[str] = set()
    total = 0
    dry_streak = 0

    print(f"\U0001f50d Searching for: {args.query}", file=sys.stderr)
    print(f"\u23f1\ufe0f  Running for {args.hours} hours", file=sys.stderr)
    print("\u2500" * 50, file=sys.stderr)

    async with XBrowser(headless=not args.headed) as xb:
        page = xb.page
        encoded = args.query.replace(" ", "%20")
        await page.goto(
            f"https://x.com/search?q={encoded}&src=typed_query&f=live",
            wait_until="domcontentloaded",
        )
        await page.wait_for_timeout(4000)

        while time.monotonic() < deadline:
            tweets = await _extract_tweet_ids_from_page(page)
            new_tweets = [t for t in tweets if t["id"] not in retweeted_ids]

            if not new_tweets:
                dry_streak += 1
                if dry_streak >= 15:
                    print(f"\n\U0001f504 Reloading search...", file=sys.stderr)
                    await page.goto(
                        f"https://x.com/search?q={encoded}&src=typed_query&f=live",
                        wait_until="domcontentloaded",
                    )
                    await page.wait_for_timeout(4000)
                    dry_streak = 0
                    continue
                await page.evaluate("window.scrollBy(0, 800)")
                await page.wait_for_timeout(2000)
                continue

            dry_streak = 0
            for tweet in new_tweets:
                if time.monotonic() >= deadline:
                    break
                text_preview = (tweet["text"][:60] + "...") if len(tweet["text"]) > 60 else tweet["text"]
                try:
                    await retweet(page, tweet["url"], config=config)
                    retweeted_ids.add(tweet["id"])
                    total += 1
                    print(f"\U0001f501 [{total}] Retweeted @{tweet['author']}: {text_preview}", file=sys.stderr)
                except Exception as e:
                    print(f"\u274c Failed: {e}", file=sys.stderr)
                    retweeted_ids.add(tweet["id"])

            if "/search" not in page.url:
                await page.goto(
                    f"https://x.com/search?q={encoded}&src=typed_query&f=live",
                    wait_until="domcontentloaded",
                )
                await page.wait_for_timeout(3000)
                for _ in range(min(len(retweeted_ids) // 3, 20)):
                    await page.evaluate("window.scrollBy(0, 800)")
                    await page.wait_for_timeout(500)

            await page.evaluate("window.scrollBy(0, 800)")
            await page.wait_for_timeout(2000)

    print(f"\n\u2705 Done! Retweeted {total} tweets.", file=sys.stderr)


if __name__ == "__main__":
    asyncio.run(main())
