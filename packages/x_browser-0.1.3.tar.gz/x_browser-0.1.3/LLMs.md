# x-browser — LLM Codebase Guide

You are working on **x-browser**, a browser-based X/Twitter automation tool. It uses Playwright to control real Chrome via CDP, avoiding all API restrictions.

---

## Architecture

```
src/x_browser/
├── __init__.py       # Package marker
├── cli.py            # Click CLI — all commands, entry point
├── browser.py        # Chrome launch + CDP connection
├── config.py         # Politeness delays, config load/save
├── actions.py        # Write operations (post, like, retweet, reply, quote, delete, bookmark)
├── scrapers.py       # Read operations (get tweet, search, user profile, timeline, followers, mentions, bookmarks)
└── formatters.py     # Output modes: human (Rich), JSON, TSV, markdown
```

```
scripts/
└── search-and-like.py   # Example long-running automation script
```

---

## Module details

### `browser.py` — Browser session management

**Key insight:** Chrome is launched as a normal subprocess with `--remote-debugging-port`, then Playwright connects over CDP. This means zero automation flags — X cannot detect it.

- `XBrowser` class: async context manager, holds Chrome process + Playwright connection
- `XBrowser(headless=True/False)` — headless uses `--headless=new` flag
- Session data persists in `~/.config/x-browser/chrome-data/`
- `login_interactive()` — opens headed Chrome, waits for user to log in, saves session
- `ensure_logged_in(page)` — checks if session is still valid

### `config.py` — Configuration

- `Config` dataclass with `min_politeness_delay` and `max_politeness_delay`
- Defaults: 3s min, 30s max
- Loads from `~/.config/x-browser/config.json`, falls back to defaults
- `Config.save()` persists to disk
- `config.politeness_wait()` — async sleep for random(min, max) seconds, logs to stderr

### `actions.py` — Write operations

Every function signature follows this pattern:
```python
async def action_name(
    page: Page,
    ...,                          # action-specific args
    *,
    config: Config | None = None, # uses Config.load() if None
    min_delay: float | None = None,
    max_delay: float | None = None,
) -> dict:
```

Every function calls `politeness_wait()` as its first line, then performs browser interactions.

Functions and what they do:
- `tweet_post(page, text, poll_options=None)` — navigates to `/compose/post`, types, clicks Post
- `tweet_delete(page, id_or_url)` — navigates to tweet, clicks ⋯ → Delete → Confirm
- `tweet_reply(page, id_or_url, text)` — navigates to tweet, clicks reply, types, posts
- `tweet_quote(page, id_or_url, text)` — navigates to tweet, clicks repost → Quote, types, posts
- `like(page, id_or_url)` — navigates to tweet, clicks heart (`data-testid="like"`)
- `retweet(page, id_or_url)` — navigates to tweet, clicks repost → Repost
- `follow(page, username)` — navigates to user profile, clicks Follow button
- `bookmark(page, id_or_url)` — navigates to tweet, clicks bookmark icon
- `unbookmark(page, id_or_url)` — navigates to tweet, clicks removeBookmark icon

All return `{"ok": True, ...}` dicts.

### `scrapers.py` — Read operations

Functions return Python dicts or lists of dicts. No politeness delay on reads.

- `tweet_get(page, id_or_url)` → dict with: text, author_username, author_name, created_at, id, url, reply_count, retweet_count, like_count, view_count
- `tweet_metrics(page, id_or_url)` → subset of tweet_get focused on counts
- `tweet_search(page, query, max_results=10)` → list of tweet dicts
- `user_get(page, username)` → dict with: username, name, description, followers_count, following_count, joined, location, url
- `user_timeline(page, username, max_results=10)` → list of tweet dicts
- `user_followers(page, username, max_results=100)` → list of user dicts
- `user_following(page, username, max_results=100)` → list of user dicts
- `me_mentions(page, max_results=10)` → list of tweet dicts
- `me_bookmarks(page, max_results=10)` → list of tweet dicts

Key helper: `_extract_tweet_from_article(article, page)` — extracts data from a single `<article data-testid="tweet">` element.

### `formatters.py` — Output formatting

- `output(data, mode="human", verbose=False)` — router to the correct formatter
- Modes: `human` (Rich panels/tables), `json`, `plain` (TSV), `markdown`
- Auto-detects data type (tweet, user, action result, list) and formats accordingly

### `cli.py` — Click CLI

- Root group `cli()` with global options: `-j`, `-p`, `-md`, `-v`, `--min-delay`, `--max-delay`, `--headed`
- Sub-groups: `tweet`, `user`, `me`
- Top-level commands: `like`, `retweet`, `login`, `config`
- `State` dataclass holds mode, verbose, config, and lazy-loaded browser
- `async_command` decorator bridges async functions into Click's sync world via `asyncio.run()`

---

## X DOM selectors used

These are the key `data-testid` selectors x-browser relies on:

| Selector | Used for |
|----------|----------|
| `article[data-testid="tweet"]` | Tweet containers |
| `div[data-testid="tweetTextarea_0"]` | Compose text box |
| `button[data-testid="tweetButton"]` | Post/Reply button |
| `button[data-testid="reply"]` | Reply button on a tweet |
| `button[data-testid="retweet"]` | Repost button |
| `button[data-testid="like"]` | Like button (unliked state) |
| `button[data-testid="unlike"]` | Like button (liked state) |
| `button[data-testid="bookmark"]` | Bookmark button |
| `button[data-testid="removeBookmark"]` | Unbookmark button |
| `button[data-testid="caret"]` | ⋯ more menu on tweet |
| `div[data-testid="tweetText"]` | Tweet text content |
| `div[data-testid="User-Name"]` | User display name |
| `div[data-testid="UserDescription"]` | User bio |
| `span[data-testid="UserJoinDate"]` | User join date |
| `a[data-testid="UserUrl"]` | User website link |

If X changes these selectors, update the corresponding functions in `actions.py` and `scrapers.py`.

---

## Adding a new action

1. Add the async function in `actions.py` following the existing pattern
2. Call `politeness_wait()` as the first line
3. Add a Click command in `cli.py` under the appropriate group
4. Return a dict — formatters handle it automatically

## Adding a new scraper

1. Add the async function in `scrapers.py`
2. Use `_extract_tweet_from_article()` for tweet lists, or write custom extraction
3. Add a Click command in `cli.py`
4. Return a dict or list of dicts — formatters handle it automatically

---

## Automation scripts

Located in `scripts/`. Each uses argparse and imports from `x_browser.*`:

| Script | Purpose |
|--------|---------|
| `search-and-like.py` | Search & like tweets, scrolling continuously |
| `search-and-retweet.py` | Search & retweet tweets |
| `engagement-bot.py` | Search → like + retweet + follow author (each toggleable via `--skip-*`) |
| `auto-follow-back.py` | Compare followers vs following, follow back the difference |
| `auto-reply-mentions.py` | Monitor mentions, reply with templates (fixed, file, or defaults) |
| `scheduled-poster.py` | Post tweets from a text file at intervals |

All scripts support `--headed`, `--min-delay`, `--max-delay`, `--dry-run` (where applicable).

---

## File paths

- Config: `~/.config/x-browser/config.json`
- Browser session: `~/.config/x-browser/chrome-data/`
- Source: `src/x_browser/`
- Scripts: `scripts/`
