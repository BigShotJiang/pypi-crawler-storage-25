import numpy as np
import pytest

import BlendPATH
import BlendPATH.network.pipeline_components as bp_plc


@pytest.fixture(scope="module")
def setup_flow_supply_network():
    composition = bp_plc.Composition(
        pure_x={"CH4": 1},
        composition_tracking=True,
        thermo_curvefit=True,
        eos_type="rk",
    )

    nodes = {}
    for i in range(4):
        nodes[f"n{i}"] = bp_plc.Node(
            name=f"n{i}",
            composition=composition,
            p_max_mpa_g=10,
        )

    pipes = {}
    diam_mm = 882.65
    l_km = 20
    ro_mm = 0.006350
    th_mm = 15.875
    grade = "X70"
    pipes["p0"] = bp_plc.Pipe(
        from_node=nodes["n0"],
        to_node=nodes["n2"],
        name="p0",
        diameter_mm=diam_mm,
        length_km=l_km,
        roughness_mm=ro_mm,
        thickness_mm=th_mm,
        rating_code=grade,
    )
    pipes["p1"] = bp_plc.Pipe(
        from_node=nodes["n1"],
        to_node=nodes["n2"],
        name="p1",
        diameter_mm=diam_mm,
        length_km=l_km,
        roughness_mm=ro_mm,
        thickness_mm=th_mm,
        rating_code=grade,
    )
    pipes["p2"] = bp_plc.Pipe(
        from_node=nodes["n2"],
        to_node=nodes["n3"],
        name="p2",
        diameter_mm=diam_mm,
        length_km=l_km,
        roughness_mm=ro_mm,
        thickness_mm=th_mm,
        rating_code=grade,
    )

    demand_nodes = {
        "d1": bp_plc.Demand_node(
            name="d1", node=nodes["n3"], flowrate_MW=21743.1429436407
        )
    }

    supply_nodes = {
        "s1": bp_plc.Supply_node(
            name="s1", node=nodes["n0"], flowrate_MW=5000, blend=0.25
        ),
        "s2": bp_plc.Supply_node(
            name="s2", node=nodes["n1"], pressure_mpa=11, blend=0.25
        ),
    }

    compressors = {}

    regulators = {}

    return BlendPATH.BlendPATH_network(
        name="comptracking",
        pipes=pipes,
        nodes=nodes,
        demand_nodes=demand_nodes,
        supply_nodes=supply_nodes,
        compressors=compressors,
        regulators=regulators,
        composition=composition,
        composition_tracking=True,
        thermo_curvefit=True,
        scenario_type="transmission",
        eos="rk",
    )


def test_pressures(setup_flow_supply_network):
    setup_flow_supply_network.solve()
    assert setup_flow_supply_network.nodes["n0"].pressure == pytest.approx(
        np.float64(10710333.652658472)
    ), "Pressue at source node is incorrect"

    assert setup_flow_supply_network.nodes["n3"].pressure == pytest.approx(
        10120267.497707633
    ), "Pressue at demand node is incorrect"
