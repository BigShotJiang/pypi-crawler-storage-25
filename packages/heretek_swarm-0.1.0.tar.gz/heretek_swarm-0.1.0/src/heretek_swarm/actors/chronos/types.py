"""
Chronos types - Enums and dataclasses for temporal & scheduling management.

Extracted from chronos.py (INTG-04).
"""

from dataclasses import dataclass, field
from datetime import UTC, datetime, timedelta
from enum import Enum
from typing import Any


class ScheduleStatus(Enum):
    """Status of a scheduled item."""

    PENDING = "pending"
    ACTIVE = "active"
    PAUSED = "paused"
    COMPLETED = "completed"
    CANCELLED = "cancelled"
    MISSED = "missed"
    FAILED = "failed"


class RecurrenceType(Enum):
    """Type of recurrence pattern."""

    ONCE = "once"
    HOURLY = "hourly"
    DAILY = "daily"
    WEEKLY = "weekly"
    MONTHLY = "monthly"
    YEARLY = "yearly"
    CRON = "cron"
    INTERVAL = "interval"


class Priority(Enum):
    """Task priority levels."""

    LOW = 1
    NORMAL = 2
    HIGH = 3
    URGENT = 4
    CRITICAL = 5


@dataclass
class ScheduledTask:
    """A scheduled task."""

    task_id: str
    name: str
    description: str
    scheduled_at: datetime
    status: ScheduleStatus = ScheduleStatus.PENDING
    priority: Priority = Priority.NORMAL
    recurrence: RecurrenceType | None = None
    recurrence_config: dict[str, Any] = field(default_factory=dict)
    target_agents: list[str] = field(default_factory=list)
    action: str = ""
    payload: dict[str, Any] = field(default_factory=dict)
    deadline: datetime | None = None
    completed_at: datetime | None = None
    next_run: datetime | None = None
    run_count: int = 0
    max_runs: int | None = None
    metadata: dict[str, Any] = field(default_factory=dict)
    created_at: datetime = field(default_factory=lambda: datetime.now(UTC))

    def to_dict(self) -> dict[str, Any]:
        """Convert to dictionary for serialization."""
        return {
            "task_id": self.task_id,
            "name": self.name,
            "description": self.description,
            "scheduled_at": self.scheduled_at.isoformat(),
            "status": self.status.value,
            "priority": self.priority.value,
            "recurrence": self.recurrence.value if self.recurrence else None,
            "recurrence_config": self.recurrence_config,
            "target_agents": self.target_agents,
            "action": self.action,
            "payload": self.payload,
            "deadline": self.deadline.isoformat() if self.deadline else None,
            "completed_at": self.completed_at.isoformat() if self.completed_at else None,
            "next_run": self.next_run.isoformat() if self.next_run else None,
            "run_count": self.run_count,
            "max_runs": self.max_runs,
            "metadata": self.metadata,
            "created_at": self.created_at.isoformat(),
        }


@dataclass
class Deadline:
    """A deadline tracking entry."""

    deadline_id: str
    name: str
    due_at: datetime
    assigned_to: list[str] = field(default_factory=list)
    status: str = "pending"  # pending, met, missed
    warning_thresholds: list[timedelta] = field(default_factory=list)
    warnings_sent: set[str] = field(default_factory=set)
    metadata: dict[str, Any] = field(default_factory=dict)

    def to_dict(self) -> dict[str, Any]:
        """Convert to dictionary for serialization."""
        return {
            "deadline_id": self.deadline_id,
            "name": self.name,
            "due_at": self.due_at.isoformat(),
            "assigned_to": self.assigned_to,
            "status": self.status,
            "warning_thresholds": [str(t) for t in self.warning_thresholds],
            "warnings_sent": list(self.warnings_sent),
            "metadata": self.metadata,
            "time_remaining": str(self.due_at - datetime.now(UTC)),
        }
