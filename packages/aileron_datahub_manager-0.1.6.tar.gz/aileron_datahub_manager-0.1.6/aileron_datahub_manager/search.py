from __future__ import annotations

import logging
from typing import TYPE_CHECKING, Iterator, List, Optional

from datahub.metadata.urns import Urn
from datahub.sdk.search_filters import FilterDsl as F

if TYPE_CHECKING:
    from aileron_datahub_manager.client import DataHubManager

logger = logging.getLogger(__name__)


class SearchManager:
    """DataHub 엔티티 검색 기능 제공.

    Example::

        # 키워드 검색
        urns = manager.search.find(query="orders", entity_type="dataset")

        # 플랫폼 필터 검색
        urns = manager.search.find_datasets(platform="hive")

        # 태그로 검색
        urns = manager.search.find(entity_type="dataset", tag="pii")
    """

    def __init__(self, manager: "DataHubManager") -> None:
        self._manager = manager

    def find(
        self,
        *,
        query: Optional[str] = None,
        entity_type: Optional[str] = None,
        platform: Optional[str] = None,
        tag: Optional[str] = None,
        limit: Optional[int] = None,
    ) -> List[str]:
        """조건에 맞는 엔티티의 URN 목록을 반환합니다.

        Args:
            query:       검색 키워드 (이름·설명 full-text 검색)
            entity_type: 엔티티 타입 필터 (dataset, dataflow, datajob, container, tag)
            platform:    플랫폼 필터 (hive, snowflake 등) — dataset 검색 시 유용
            tag:         태그 이름 필터
            limit:       최대 반환 수 (None이면 전체)

        Returns:
            URN 문자열 목록
        """
        filters = []

        if entity_type:
            filters.append(F.entity_type(entity_type))
        if platform:
            filters.append(F.platform(platform))
        if tag:
            filters.append(F.tag(f"urn:li:tag:{tag}" if not tag.startswith("urn:") else tag))

        if len(filters) == 0:
            filter_expr = None
        elif len(filters) == 1:
            filter_expr = filters[0]
        else:
            filter_expr = F.and_(*filters)

        urns: Iterator[Urn] = self._manager._sdk_client.search.get_urns(
            query=query,
            filter=filter_expr,
        )

        results = [str(urn) for urn in urns]
        if limit is not None:
            results = results[:limit]

        logger.debug("검색 결과 %d건 (query=%s, entity_type=%s)", len(results), query, entity_type)
        return results

    def find_datasets(
        self,
        *,
        query: Optional[str] = None,
        platform: Optional[str] = None,
        tag: Optional[str] = None,
        limit: Optional[int] = None,
    ) -> List[str]:
        """Dataset URN 목록을 검색합니다."""
        return self.find(
            query=query,
            entity_type="dataset",
            platform=platform,
            tag=tag,
            limit=limit,
        )

    def find_pipelines(
        self,
        *,
        query: Optional[str] = None,
        limit: Optional[int] = None,
    ) -> List[str]:
        """DataFlow(파이프라인) URN 목록을 검색합니다."""
        return self.find(query=query, entity_type="dataFlow", limit=limit)
