from __future__ import annotations

import logging
from typing import TYPE_CHECKING, Optional

from datahub.ingestion.graph.client import DataHubGraph
from datahub.ingestion.graph.config import DatahubClientConfig
from datahub.sdk.main_client import DataHubClient

from aileron_datahub_manager.config import DataHubConfig
from aileron_datahub_manager.exceptions import ConnectionError

if TYPE_CHECKING:
    from aileron_datahub_manager.entities.dataset import DatasetManager
    from aileron_datahub_manager.entities.pipeline import PipelineManager
    from aileron_datahub_manager.entities.container import ContainerManager
    from aileron_datahub_manager.entities.tag import TagManager
    from aileron_datahub_manager.lineage import LineageManager
    from aileron_datahub_manager.search import SearchManager

logger = logging.getLogger(__name__)


class DataHubManager:
    """여러 마이크로서비스에서 공통으로 사용하는 DataHub 클라이언트.

    Entity 생성·수정, 리니지(관계) 등록 등의 기능을 제공합니다.

    사용 예::

        manager = DataHubManager.from_env()

        # Dataset 등록
        manager.datasets.upsert(
            platform="hive",
            name="my_db.my_table",
            description="...",
        )

        # 리니지 등록
        manager.lineage.add_dataset_lineage(
            upstream="urn:li:dataset:(urn:li:dataPlatform:hive,source_db.source_table,PROD)",
            downstream="urn:li:dataset:(urn:li:dataPlatform:hive,target_db.target_table,PROD)",
        )

    URN의 env 값은 각 MS에서 직접 지정합니다::

        manager.datasets.make_urn("hive", "my_db.my_table", env="PROD")
        manager.datasets.upsert(platform="hive", name="my_db.my_table", env="PROD")
    """

    def __init__(self, config: DataHubConfig) -> None:
        self._config = config
        self._client = self._build_client(config)
        self._graph = self._client._graph

        # lazy-loaded sub-managers
        self._datasets: Optional["DatasetManager"] = None
        self._pipelines: Optional["PipelineManager"] = None
        self._containers: Optional["ContainerManager"] = None
        self._tags: Optional["TagManager"] = None
        self._lineage: Optional["LineageManager"] = None
        self._search: Optional["SearchManager"] = None

    # ------------------------------------------------------------------
    # Factory methods
    # ------------------------------------------------------------------

    @classmethod
    def from_env(cls) -> "DataHubManager":
        """환경변수(DATAHUB_SERVER, DATAHUB_TOKEN)에서 설정을 읽어 인스턴스를 생성합니다."""
        return cls(config=DataHubConfig.from_env())

    @classmethod
    def from_config(cls, config: DataHubConfig) -> "DataHubManager":
        """DataHubConfig 객체로 인스턴스를 생성합니다."""
        return cls(config=config)

    # ------------------------------------------------------------------
    # Sub-managers (lazy)
    # ------------------------------------------------------------------

    @property
    def datasets(self) -> "DatasetManager":
        if self._datasets is None:
            from aileron_datahub_manager.entities.dataset import DatasetManager

            self._datasets = DatasetManager(self)
        return self._datasets

    @property
    def pipelines(self) -> "PipelineManager":
        if self._pipelines is None:
            from aileron_datahub_manager.entities.pipeline import PipelineManager

            self._pipelines = PipelineManager(self)
        return self._pipelines

    @property
    def containers(self) -> "ContainerManager":
        if self._containers is None:
            from aileron_datahub_manager.entities.container import ContainerManager

            self._containers = ContainerManager(self)
        return self._containers

    @property
    def tags(self) -> "TagManager":
        if self._tags is None:
            from aileron_datahub_manager.entities.tag import TagManager

            self._tags = TagManager(self)
        return self._tags

    @property
    def lineage(self) -> "LineageManager":
        if self._lineage is None:
            from aileron_datahub_manager.lineage import LineageManager

            self._lineage = LineageManager(self)
        return self._lineage

    @property
    def search(self) -> "SearchManager":
        if self._search is None:
            from aileron_datahub_manager.search import SearchManager

            self._search = SearchManager(self)
        return self._search

    # ------------------------------------------------------------------
    # Connection helpers
    # ------------------------------------------------------------------

    def test_connection(self) -> bool:
        """DataHub 서버 연결을 테스트합니다.

        Returns:
            연결 성공 여부

        Raises:
            ConnectionError: 연결에 실패한 경우
        """
        try:
            self._client.test_connection()
            logger.info("DataHub 연결 성공: %s", self._config.server)
            return True
        except Exception as exc:
            raise ConnectionError(
                f"DataHub 서버({self._config.server})에 연결할 수 없습니다: {exc}"
            ) from exc

    # ------------------------------------------------------------------
    # Internal helpers (sub-managers에서 사용)
    # ------------------------------------------------------------------

    @property
    def _sdk_client(self) -> DataHubClient:
        return self._client

    @property
    def _datahub_graph(self) -> DataHubGraph:
        return self._graph

    # ------------------------------------------------------------------

    @staticmethod
    def _build_client(config: DataHubConfig) -> DataHubClient:
        dh_config = DatahubClientConfig(
            server=config.server,
            token=config.token,
        )
        return DataHubClient(config=dh_config)
