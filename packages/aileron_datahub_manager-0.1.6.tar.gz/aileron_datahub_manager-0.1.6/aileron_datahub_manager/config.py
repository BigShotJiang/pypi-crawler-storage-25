from __future__ import annotations

import os
from typing import Optional

from pydantic import BaseModel, Field, model_validator


class DataHubConfig(BaseModel):
    """DataHub 연결 설정.

    환경변수 또는 코드에서 직접 값을 전달할 수 있습니다.

    환경변수:
        DATAHUB_SERVER: DataHub GMS 서버 URL (예: http://datahub-gms:8080)
        DATAHUB_TOKEN:  인증 토큰 (선택)
    """

    server: str = Field(default_factory=lambda: os.environ.get("DATAHUB_SERVER", ""))
    token: Optional[str] = Field(
        default_factory=lambda: os.environ.get("DATAHUB_TOKEN")
    )

    @model_validator(mode="after")
    def _require_server(self) -> "DataHubConfig":
        if not self.server:
            raise ValueError(
                "DataHub server URL이 필요합니다. "
                "DataHubConfig(server=...) 또는 환경변수 DATAHUB_SERVER를 설정하세요."
            )
        return self

    @classmethod
    def from_env(cls) -> "DataHubConfig":
        """환경변수에서 설정을 읽어 인스턴스를 반환합니다."""
        return cls()
