from __future__ import annotations

import logging
from typing import TYPE_CHECKING, Dict, List, Optional

from datahub.emitter.mcp_builder import DatabaseKey, ContainerKey
from datahub.metadata.urns import ContainerUrn
from datahub.sdk.container import Container

from aileron_datahub_manager.exceptions import EntityNotFoundError, InvalidEntityError

if TYPE_CHECKING:
    from aileron_datahub_manager.client import DataHubManager

logger = logging.getLogger(__name__)


class ContainerManager:
    """Container 엔티티(데이터베이스, 스키마, 버킷 등) 관리."""

    def __init__(self, manager: "DataHubManager") -> None:
        self._manager = manager

    # ------------------------------------------------------------------
    # URN 헬퍼
    # ------------------------------------------------------------------

    def make_database_urn(
        self, platform: str, database: str, instance: Optional[str] = None
    ) -> str:
        """Database Container URN을 생성합니다.

        Args:
            platform: 플랫폼 이름 (hive, snowflake 등)
            database: 데이터베이스 이름
            instance: 플랫폼 인스턴스 (선택)
        """
        key = DatabaseKey(platform=platform, database=database, instance=instance)
        return key.as_urn()

    # ------------------------------------------------------------------
    # CRUD
    # ------------------------------------------------------------------

    def upsert(
        self,
        container_key: ContainerKey,
        *,
        display_name: str,
        description: Optional[str] = None,
        subtype: Optional[str] = None,
        owners: Optional[List[str]] = None,
        tags: Optional[List[str]] = None,
        extra_properties: Optional[Dict[str, str]] = None,
        parent_container: Optional[str] = None,
    ) -> str:
        """Container를 생성하거나 업데이트합니다.

        Args:
            container_key:    ContainerKey 인스턴스 (DatabaseKey, SchemaKey 등)
            display_name:     UI 표시 이름 (필수)
            description:      설명
            subtype:          서브타입 (Database, Schema, Bucket 등)
            owners:           소유자 URN 목록
            tags:             태그 목록
            extra_properties: 커스텀 속성
            parent_container: 부모 Container URN

        Returns:
            생성된 Container URN 문자열
        """
        if not display_name:
            raise InvalidEntityError("display_name은 필수입니다.")

        container = Container(
            container_key=container_key,
            display_name=display_name,
            description=description,
            extra_properties=extra_properties,
            subtype=subtype,
            owners=owners,
            tags=tags,
            parent_container=parent_container,
        )

        self._manager._sdk_client.entities.upsert(container)
        urn = container_key.as_urn()
        logger.info("Container upsert 완료: %s", urn)
        return urn

    def upsert_database(
        self,
        platform: str,
        database: str,
        *,
        instance: Optional[str] = None,
        description: Optional[str] = None,
        owners: Optional[List[str]] = None,
        tags: Optional[List[str]] = None,
        extra_properties: Optional[Dict[str, str]] = None,
    ) -> str:
        """Database 타입 Container를 생성하거나 업데이트합니다.

        Args:
            platform:  플랫폼 이름
            database:  데이터베이스 이름
            instance:  플랫폼 인스턴스 (선택)

        Returns:
            Container URN 문자열
        """
        key = DatabaseKey(platform=platform, database=database, instance=instance)
        return self.upsert(
            key,
            display_name=database,
            description=description,
            subtype="Database",
            owners=owners,
            tags=tags,
            extra_properties=extra_properties,
        )

    def get(self, urn: str) -> Container:
        """URN으로 Container를 조회합니다.

        Raises:
            EntityNotFoundError: 엔티티가 없을 때
        """
        try:
            entity = self._manager._sdk_client.entities.get(ContainerUrn.from_string(urn))
        except Exception as exc:
            raise EntityNotFoundError(urn) from exc
        if entity is None:
            raise EntityNotFoundError(urn)
        return entity  # type: ignore[return-value]

    def delete(self, urn: str, *, hard: bool = False) -> None:
        """Container를 삭제합니다."""
        self._manager._sdk_client.entities.delete(urn, hard=hard)
        logger.info("Container 삭제 완료 (hard=%s): %s", hard, urn)
