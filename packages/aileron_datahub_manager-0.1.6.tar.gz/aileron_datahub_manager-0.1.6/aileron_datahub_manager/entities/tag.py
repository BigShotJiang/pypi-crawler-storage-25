from __future__ import annotations

import logging
from typing import TYPE_CHECKING, List, Optional

from datahub.metadata.urns import TagUrn
from datahub.sdk.tag import Tag

from aileron_datahub_manager.exceptions import EntityNotFoundError, InvalidEntityError

if TYPE_CHECKING:
    from aileron_datahub_manager.client import DataHubManager

logger = logging.getLogger(__name__)


class TagManager:
    """Tag 엔티티 생성·수정·삭제 관리.

    주의: upsert(tags=[...]) 에서 넘기는 태그 이름은 DataHub가 자동으로
    Tag 엔티티를 생성하지만, 설명·색상·소유자가 없는 빈 Tag입니다.
    이 매니저를 통해 Tag를 사전에 등록하면 메타데이터를 풍부하게 관리할 수 있습니다.
    """

    def __init__(self, manager: "DataHubManager") -> None:
        self._manager = manager

    # ------------------------------------------------------------------
    # URN 헬퍼
    # ------------------------------------------------------------------

    @staticmethod
    def make_urn(name: str) -> str:
        """Tag URN을 생성합니다.

        Args:
            name: 태그 이름 (예: pii, finance)

        Returns:
            urn:li:tag:{name} 형식의 문자열
        """
        return str(TagUrn(name=name))

    # ------------------------------------------------------------------
    # CRUD
    # ------------------------------------------------------------------

    def upsert(
        self,
        name: str,
        *,
        display_name: Optional[str] = None,
        description: Optional[str] = None,
        color: Optional[str] = None,
        owners: Optional[List[str]] = None,
    ) -> str:
        """Tag를 생성하거나 업데이트합니다.

        Args:
            name:         태그 이름 (URN의 key가 됨)
            display_name: UI 표시 이름 (기본값: name)
            description:  태그 설명
            color:        색상 hex 코드 (예: "#FF5733")
            owners:       소유자 URN 목록

        Returns:
            Tag URN 문자열
        """
        if not name:
            raise InvalidEntityError("name은 필수입니다.")

        tag = Tag(
            name=name,
            display_name=display_name,
            description=description,
            color=color,
            owners=owners,
        )

        self._manager._sdk_client.entities.upsert(tag)
        urn = self.make_urn(name)
        logger.info("Tag upsert 완료: %s", urn)
        return urn

    def get(self, name_or_urn: str) -> Tag:
        """Tag를 이름 또는 URN으로 조회합니다.

        Raises:
            EntityNotFoundError: 태그가 없을 때
        """
        urn_str = (
            name_or_urn
            if name_or_urn.startswith("urn:li:tag:")
            else self.make_urn(name_or_urn)
        )
        try:
            entity = self._manager._sdk_client.entities.get(TagUrn.from_string(urn_str))
        except Exception as exc:
            raise EntityNotFoundError(urn_str) from exc
        if entity is None:
            raise EntityNotFoundError(urn_str)
        return entity  # type: ignore[return-value]

    def delete(self, name_or_urn: str, *, hard: bool = False) -> None:
        """Tag를 삭제합니다.

        Args:
            name_or_urn: 태그 이름 또는 URN
            hard:        True이면 하드 삭제 (기본값: 소프트 삭제)
        """
        urn_str = (
            name_or_urn
            if name_or_urn.startswith("urn:li:tag:")
            else self.make_urn(name_or_urn)
        )
        self._manager._sdk_client.entities.delete(urn_str, hard=hard)
        logger.info("Tag 삭제 완료 (hard=%s): %s", hard, urn_str)
