from __future__ import annotations

import logging
from typing import TYPE_CHECKING, List, Optional

from datahub.metadata.urns import DataFlowUrn, DataJobUrn, TagUrn
from datahub.sdk.dataflow import DataFlow
from datahub.sdk.datajob import DataJob

from aileron_datahub_manager.exceptions import EntityNotFoundError, InvalidEntityError

if TYPE_CHECKING:
    from aileron_datahub_manager.client import DataHubManager

logger = logging.getLogger(__name__)


class PipelineManager:
    """DataFlow(파이프라인)와 DataJob(태스크) 엔티티 관리.

    DataHub의 파이프라인 계층 구조::

        DataFlow (파이프라인/DAG)
            └── DataJob (태스크/Step)
    """

    def __init__(self, manager: "DataHubManager") -> None:
        self._manager = manager

    # ------------------------------------------------------------------
    # URN 헬퍼
    # ------------------------------------------------------------------

    def make_flow_urn(self, orchestrator: str, flow_id: str, cluster: str) -> str:
        """DataFlow URN을 생성합니다.

        Args:
            orchestrator: 오케스트레이터 (airflow, prefect, spark 등)
            flow_id:      파이프라인 ID / DAG ID
            cluster:      클러스터 이름 (예: PROD, DEV)
        """
        return str(DataFlowUrn(orchestrator=orchestrator, flow_id=flow_id, cluster=cluster))

    def make_job_urn(self, orchestrator: str, flow_id: str, job_id: str, cluster: str) -> str:
        """DataJob URN을 생성합니다."""
        flow_urn = DataFlowUrn(orchestrator=orchestrator, flow_id=flow_id, cluster=cluster)
        return str(DataJobUrn(flow=str(flow_urn), job_id=job_id))

    # ------------------------------------------------------------------
    # DataFlow CRUD
    # ------------------------------------------------------------------

    def upsert_flow(
        self,
        orchestrator: str,
        flow_id: str,
        cluster: str,
        *,
        display_name: Optional[str] = None,
        description: Optional[str] = None,
        owners: Optional[List[str]] = None,
        tags: Optional[List[str]] = None,
    ) -> str:
        """DataFlow(파이프라인)를 생성하거나 업데이트합니다.

        Args:
            orchestrator: 오케스트레이터 이름 (airflow, spark 등)
            flow_id:      파이프라인 고유 ID (예: my_dag)
            cluster:      클러스터 이름 (예: PROD, DEV)
            display_name: UI 표시 이름
            description:  설명
            owners:       소유자 URN 목록
            tags:         태그 목록

        Returns:
            DataFlow URN 문자열
        """
        if not orchestrator or not flow_id:
            raise InvalidEntityError("orchestrator와 flow_id는 필수입니다.")

        urn = self.make_flow_urn(orchestrator, flow_id, cluster)

        flow = DataFlow(name=flow_id, platform=orchestrator, env=cluster)

        if display_name:
            flow.set_display_name(display_name)
        if description:
            flow.set_description(description)
        if owners:
            flow.set_owners(owners)
        if tags:
            flow.set_tags([t if t.startswith("urn:li:") else str(TagUrn(name=t)) for t in tags])

        self._manager._sdk_client.entities.upsert(flow)
        logger.info("DataFlow upsert 완료: %s", urn)
        return urn

    def get_flow(self, urn: str) -> DataFlow:
        """DataFlow를 URN으로 조회합니다.

        Raises:
            EntityNotFoundError: 엔티티가 없을 때
        """
        try:
            entity = self._manager._sdk_client.entities.get(DataFlowUrn.from_string(urn))
        except Exception as exc:
            raise EntityNotFoundError(urn) from exc
        if entity is None:
            raise EntityNotFoundError(urn)
        return entity  # type: ignore[return-value]

    # ------------------------------------------------------------------
    # DataJob CRUD
    # ------------------------------------------------------------------

    def upsert_job(
        self,
        orchestrator: str,
        flow_id: str,
        job_id: str,
        cluster: str,
        *,
        display_name: Optional[str] = None,
        description: Optional[str] = None,
        owners: Optional[List[str]] = None,
        tags: Optional[List[str]] = None,
        upstream_jobs: Optional[List[str]] = None,
        input_datasets: Optional[List[str]] = None,
        output_datasets: Optional[List[str]] = None,
    ) -> str:
        """DataJob(태스크)을 생성하거나 업데이트합니다.

        Args:
            orchestrator:    오케스트레이터 이름
            flow_id:         소속 DataFlow ID
            job_id:          태스크 고유 ID
            cluster:         클러스터 이름 (예: PROD, DEV)
            display_name:    UI 표시 이름
            description:     설명
            owners:          소유자 URN 목록
            tags:            태그 목록
            upstream_jobs:   선행 DataJob URN 목록
            input_datasets:  입력 Dataset URN 목록
            output_datasets: 출력 Dataset URN 목록

        Returns:
            DataJob URN 문자열
        """
        if not orchestrator or not flow_id or not job_id:
            raise InvalidEntityError("orchestrator, flow_id, job_id는 필수입니다.")

        flow_urn = self.make_flow_urn(orchestrator, flow_id, cluster)
        urn = self.make_job_urn(orchestrator, flow_id, job_id, cluster)

        job = DataJob(name=job_id, flow_urn=flow_urn)

        if display_name:
            job.set_display_name(display_name)
        if description:
            job.set_description(description)
        if owners:
            job.set_owners(owners)
        if tags:
            job.set_tags([t if t.startswith("urn:li:") else str(TagUrn(name=t)) for t in tags])
        if upstream_jobs:
            props = job._ensure_datajob_inputoutput_props()  # type: ignore[attr-defined]
            if props.inputDatajobs is None:
                props.inputDatajobs = []
            props.inputDatajobs.extend(upstream_jobs)
        if input_datasets:
            job.set_inlets(input_datasets)
        if output_datasets:
            job.set_outlets(output_datasets)

        self._manager._sdk_client.entities.upsert(job)
        logger.info("DataJob upsert 완료: %s", urn)
        return urn

    def get_job(self, urn: str) -> DataJob:
        """DataJob을 URN으로 조회합니다.

        Raises:
            EntityNotFoundError: 엔티티가 없을 때
        """
        try:
            entity = self._manager._sdk_client.entities.get(DataJobUrn.from_string(urn))
        except Exception as exc:
            raise EntityNotFoundError(urn) from exc
        if entity is None:
            raise EntityNotFoundError(urn)
        return entity  # type: ignore[return-value]

    def delete_flow(self, urn: str, *, hard: bool = False) -> None:
        """DataFlow를 삭제합니다.

        Args:
            urn:  삭제할 DataFlow URN
            hard: True이면 하드 삭제 (기본값: 소프트 삭제)
        """
        self._manager._sdk_client.entities.delete(urn, hard=hard)
        logger.info("DataFlow 삭제 완료 (hard=%s): %s", hard, urn)

    def delete_job(self, urn: str, *, hard: bool = False) -> None:
        """DataJob을 삭제합니다.

        Args:
            urn:  삭제할 DataJob URN
            hard: True이면 하드 삭제 (기본값: 소프트 삭제)
        """
        self._manager._sdk_client.entities.delete(urn, hard=hard)
        logger.info("DataJob 삭제 완료 (hard=%s): %s", hard, urn)
