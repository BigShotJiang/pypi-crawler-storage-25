from __future__ import annotations

from unittest.mock import MagicMock, patch

import pytest

from aileron_datahub_manager.client import DataHubManager
from aileron_datahub_manager.config import DataHubConfig
from aileron_datahub_manager.exceptions import InvalidEntityError

DS_IN = "urn:li:dataset:(urn:li:dataPlatform:hive,db.input,PROD)"
DS_OUT = "urn:li:dataset:(urn:li:dataPlatform:hive,db.output,PROD)"


@pytest.fixture
def manager():
    config = DataHubConfig(server="http://localhost:8080")
    with patch("aileron_datahub_manager.client.DataHubClient") as mock_cls:
        mock_client = MagicMock()
        mock_client._graph = MagicMock()
        mock_cls.return_value = mock_client
        m = DataHubManager(config=config)
    return m


# ------------------------------------------------------------------
# upsert_flow
# ------------------------------------------------------------------

def test_upsert_flow_returns_urn(manager):
    urn = manager.pipelines.upsert_flow(
        orchestrator="airflow", flow_id="my_dag", cluster="PROD"
    )
    assert "airflow" in urn
    assert "my_dag" in urn
    manager._client.entities.upsert.assert_called_once()


def test_upsert_flow_missing_required_raises(manager):
    with pytest.raises(InvalidEntityError):
        manager.pipelines.upsert_flow(orchestrator="", flow_id="my_dag", cluster="PROD")


# ------------------------------------------------------------------
# upsert_job — 기본
# ------------------------------------------------------------------

def test_upsert_job_returns_urn(manager):
    urn = manager.pipelines.upsert_job(
        orchestrator="airflow", flow_id="my_dag", job_id="my_task", cluster="PROD"
    )
    assert "my_task" in urn
    manager._client.entities.upsert.assert_called_once()


def test_upsert_job_missing_required_raises(manager):
    with pytest.raises(InvalidEntityError):
        manager.pipelines.upsert_job(
            orchestrator="airflow", flow_id="my_dag", job_id="", cluster="PROD"
        )


# ------------------------------------------------------------------
# upsert_job — 수정된 메서드 검증
# ------------------------------------------------------------------

def test_upsert_job_input_datasets_calls_set_inlets(manager):
    """input_datasets → DataJob.set_inlets 호출 검증 (set_input_datasets → AttributeError 수정)."""
    with patch("datahub.sdk.datajob.DataJob.set_inlets") as mock_inlets:
        manager.pipelines.upsert_job(
            orchestrator="airflow",
            flow_id="my_dag",
            job_id="my_task",
            cluster="PROD",
            input_datasets=[DS_IN],
        )
    mock_inlets.assert_called_once_with([DS_IN])


def test_upsert_job_output_datasets_calls_set_outlets(manager):
    """output_datasets → DataJob.set_outlets 호출 검증 (set_output_datasets → AttributeError 수정)."""
    with patch("datahub.sdk.datajob.DataJob.set_outlets") as mock_outlets:
        manager.pipelines.upsert_job(
            orchestrator="airflow",
            flow_id="my_dag",
            job_id="my_task",
            cluster="PROD",
            output_datasets=[DS_OUT],
        )
    mock_outlets.assert_called_once_with([DS_OUT])


def test_upsert_job_upstream_jobs_sets_input_datajobs(manager):
    """upstream_jobs → DataJobInputOutputClass.inputDatajobs 설정 검증 (set_upstream_jobs → AttributeError 수정)."""
    upstream_urn = manager.pipelines.make_job_urn("airflow", "my_dag", "upstream_task", "PROD")

    captured = {}

    def capture(entity):
        captured["job"] = entity

    manager._client.entities.upsert.side_effect = capture

    manager.pipelines.upsert_job(
        orchestrator="airflow",
        flow_id="my_dag",
        job_id="my_task",
        cluster="PROD",
        upstream_jobs=[upstream_urn],
    )

    job = captured["job"]
    props = job._get_datajob_inputoutput_props()
    assert props is not None
    assert upstream_urn in props.inputDatajobs


def test_upsert_job_no_datasets_does_not_call_inlets_outlets(manager):
    """datasets 미전달 시 set_inlets / set_outlets 가 호출되지 않아야 한다."""
    with patch("datahub.sdk.datajob.DataJob.set_inlets") as mock_inlets, \
         patch("datahub.sdk.datajob.DataJob.set_outlets") as mock_outlets:
        manager.pipelines.upsert_job(
            orchestrator="airflow", flow_id="my_dag", job_id="my_task", cluster="PROD"
        )
    mock_inlets.assert_not_called()
    mock_outlets.assert_not_called()
