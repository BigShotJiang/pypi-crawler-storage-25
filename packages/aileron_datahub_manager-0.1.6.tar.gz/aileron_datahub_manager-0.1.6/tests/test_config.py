from __future__ import annotations

import pytest

from aileron_datahub_manager.config import DataHubConfig


def test_config_direct():
    config = DataHubConfig(server="http://datahub:8080", token="tok")
    assert config.server == "http://datahub:8080"
    assert config.token == "tok"


def test_config_from_env_vars(monkeypatch):
    monkeypatch.setenv("DATAHUB_SERVER", "http://env-host:8080")
    monkeypatch.setenv("DATAHUB_TOKEN", "env-token")

    config = DataHubConfig.from_env()
    assert config.server == "http://env-host:8080"
    assert config.token == "env-token"


def test_config_missing_server_raises():
    with pytest.raises(ValueError, match="server"):
        DataHubConfig(server="")
