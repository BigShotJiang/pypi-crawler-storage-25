from __future__ import annotations

from unittest.mock import MagicMock, patch

import pytest

from datahub.sdk.search_client import SearchClient

from aileron_datahub_manager.client import DataHubManager
from aileron_datahub_manager.config import DataHubConfig


@pytest.fixture
def manager():
    config = DataHubConfig(server="http://localhost:8080")
    with patch("aileron_datahub_manager.client.DataHubClient") as mock_cls:
        mock_client = MagicMock()
        mock_client._graph = MagicMock()
        # spec=SearchClient → 존재하지 않는 메서드 호출 시 AttributeError
        mock_client.search = MagicMock(spec=SearchClient)
        mock_client.search.get_urns.return_value = iter([])
        mock_cls.return_value = mock_client
        m = DataHubManager(config=config)
    return m


def test_find_calls_get_urns(manager):
    """find → SearchClient.get_urns 호출 검증."""
    manager.search.find(query="orders", entity_type="dataset")
    manager._client.search.get_urns.assert_called_once()


def test_find_returns_urn_list(manager):
    """find 결과가 문자열 목록이어야 한다."""
    from datahub.metadata.urns import DatasetUrn
    manager._client.search.get_urns.return_value = iter([
        DatasetUrn(platform="hive", name="db.table", env="PROD")
    ])
    results = manager.search.find(query="orders")
    assert isinstance(results, list)
    assert len(results) == 1
    assert "hive" in results[0]


def test_find_with_limit(manager):
    """limit 파라미터가 결과 수를 제한해야 한다."""
    from datahub.metadata.urns import DatasetUrn
    manager._client.search.get_urns.return_value = iter([
        DatasetUrn(platform="hive", name=f"db.table{i}", env="PROD") for i in range(5)
    ])
    results = manager.search.find(query="orders", limit=2)
    assert len(results) == 2


def test_find_datasets_filters_by_entity_type(manager):
    """find_datasets은 entity_type=dataset 으로 검색해야 한다."""
    manager.search.find_datasets(platform="hive")
    call_kwargs = manager._client.search.get_urns.call_args.kwargs
    # filter 에 entity_type 조건이 포함되어 있어야 함
    assert call_kwargs.get("filter") is not None


def test_wrong_search_method_raises(manager):
    """존재하지 않는 메서드 호출 시 AttributeError (spec 검증)."""
    with pytest.raises(AttributeError):
        manager._client.search.nonexistent_method()
