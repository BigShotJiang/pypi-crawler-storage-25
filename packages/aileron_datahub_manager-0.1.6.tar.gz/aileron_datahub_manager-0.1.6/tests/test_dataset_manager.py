from __future__ import annotations

from unittest.mock import MagicMock, patch

import pytest

from aileron_datahub_manager.client import DataHubManager
from aileron_datahub_manager.config import DataHubConfig
from aileron_datahub_manager.exceptions import EntityNotFoundError, InvalidEntityError

SCHEMA_FIELDS = [("id", "bigint", "ID"), ("name", "string", "이름")]


@pytest.fixture
def manager():
    config = DataHubConfig(server="http://localhost:8080")
    with patch("aileron_datahub_manager.client.DataHubClient") as mock_cls:
        mock_client = MagicMock()
        mock_client._graph = MagicMock()
        mock_cls.return_value = mock_client
        m = DataHubManager(config=config)
    return m


def test_make_urn(manager):
    urn = manager.datasets.make_urn("hive", "my_db.my_table", "PROD")
    assert "hive" in urn
    assert "my_db.my_table" in urn
    assert "PROD" in urn


def test_upsert_calls_sdk(manager):
    urn = manager.datasets.upsert(
        platform="hive",
        name="my_db.my_table",
        env="PROD",
        description="테스트 테이블",
    )
    assert "hive" in urn
    manager._client.entities.upsert.assert_called_once()


def test_upsert_missing_platform_raises(manager):
    with pytest.raises(InvalidEntityError):
        manager.datasets.upsert(platform="", name="my_db.my_table", env="PROD")


def test_upsert_missing_name_raises(manager):
    with pytest.raises(InvalidEntityError):
        manager.datasets.upsert(platform="hive", name="", env="PROD")


def test_get_not_found_raises(manager):
    manager._client.entities.get.return_value = None
    urn = "urn:li:dataset:(urn:li:dataPlatform:hive,db.table,PROD)"
    with pytest.raises(EntityNotFoundError):
        manager.datasets.get(urn)


def test_exists_false_when_not_found(manager):
    manager._client.entities.get.return_value = None
    urn = "urn:li:dataset:(urn:li:dataPlatform:hive,db.table,PROD)"
    assert manager.datasets.exists(urn) is False


def test_delete_calls_sdk(manager):
    urn = "urn:li:dataset:(urn:li:dataPlatform:hive,db.table,PROD)"
    manager.datasets.delete(urn)
    manager._client.entities.delete.assert_called_once_with(urn, hard=False)


def test_upsert_with_schema_fields_calls_set_schema(manager):
    """schema_fields 전달 시 Dataset._set_schema 가 호출되어야 한다 (set_schema → AttributeError 수정 검증)."""
    with patch("datahub.sdk.dataset.Dataset._set_schema") as mock_set_schema:
        manager.datasets.upsert(
            platform="hive",
            name="my_db.my_table",
            env="PROD",
            schema_fields=SCHEMA_FIELDS,
        )
    mock_set_schema.assert_called_once_with(SCHEMA_FIELDS)


def test_upsert_without_schema_fields_does_not_call_set_schema(manager):
    """schema_fields 미전달 시 _set_schema 가 호출되지 않아야 한다."""
    with patch("datahub.sdk.dataset.Dataset._set_schema") as mock_set_schema:
        manager.datasets.upsert(platform="hive", name="my_db.my_table", env="PROD")
    mock_set_schema.assert_not_called()
