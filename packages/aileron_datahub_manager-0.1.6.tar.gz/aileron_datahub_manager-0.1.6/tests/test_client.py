from __future__ import annotations

from unittest.mock import MagicMock, patch

import pytest

from aileron_datahub_manager.client import DataHubManager
from aileron_datahub_manager.config import DataHubConfig
from aileron_datahub_manager.exceptions import ConnectionError


@pytest.fixture
def config():
    return DataHubConfig(server="http://localhost:8080", token="tok")


def _make_manager(config: DataHubConfig) -> DataHubManager:
    with patch("aileron_datahub_manager.client.DataHubClient") as mock_cls:
        mock_client = MagicMock()
        mock_client._graph = MagicMock()
        mock_cls.return_value = mock_client
        manager = DataHubManager(config=config)
    return manager


def test_manager_lazy_sub_managers(config):
    manager = _make_manager(config)
    assert manager._datasets is None
    assert manager._pipelines is None
    assert manager._containers is None
    assert manager._lineage is None

    # 접근 시 초기화
    _ = manager.datasets
    assert manager._datasets is not None

    _ = manager.lineage
    assert manager._lineage is not None


def test_test_connection_success(config):
    manager = _make_manager(config)
    manager._client.test_connection.return_value = None
    assert manager.test_connection() is True


def test_test_connection_failure(config):
    manager = _make_manager(config)
    manager._client.test_connection.side_effect = Exception("refused")
    with pytest.raises(ConnectionError):
        manager.test_connection()
