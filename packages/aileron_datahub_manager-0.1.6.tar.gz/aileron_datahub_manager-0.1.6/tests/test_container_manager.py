from __future__ import annotations

from unittest.mock import MagicMock, patch

import pytest

from datahub.emitter.mcp_builder import DatabaseKey
from datahub.sdk.container import Container

from aileron_datahub_manager.client import DataHubManager
from aileron_datahub_manager.config import DataHubConfig
from aileron_datahub_manager.exceptions import InvalidEntityError


@pytest.fixture
def manager():
    config = DataHubConfig(server="http://localhost:8080")
    with patch("aileron_datahub_manager.client.DataHubClient") as mock_cls:
        mock_client = MagicMock()
        mock_client._graph = MagicMock()
        mock_cls.return_value = mock_client
        m = DataHubManager(config=config)
    return m


def test_upsert_database_returns_urn(manager):
    """upsert_database가 Container URN을 반환하고 entities.upsert를 호출해야 한다."""
    urn = manager.containers.upsert_database(
        platform="hive",
        database="analytics",
        description="분석용 데이터베이스",
    )
    assert urn.startswith("urn:li:container:")
    manager._client.entities.upsert.assert_called_once()


def test_upsert_database_passes_real_container(manager):
    """entities.upsert에 실제 Container 객체가 전달되어야 한다."""
    manager.containers.upsert_database(platform="hive", database="analytics")

    call_args = manager._client.entities.upsert.call_args
    container = call_args[0][0]
    assert isinstance(container, Container)


def test_upsert_missing_display_name_raises(manager):
    """display_name 없으면 InvalidEntityError."""
    key = DatabaseKey(platform="hive", database="analytics", instance=None)
    with pytest.raises(InvalidEntityError):
        manager.containers.upsert(key, display_name="")


def test_make_database_urn(manager):
    """make_database_urn이 Container URN 형식을 반환해야 한다."""
    urn = manager.containers.make_database_urn(platform="hive", database="analytics")
    assert urn.startswith("urn:li:container:")
