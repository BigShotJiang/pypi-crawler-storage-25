from pathlib import Path

import pandas as pd


def _get_suffix(file_path: str) -> str:
    return Path(file_path).suffix.lower()


def save_jsonl(df: pd.DataFrame, output_file: str) -> None:
    """Save DataFrame to JSONL format (one JSON object per line)."""
    Path(output_file).parent.mkdir(parents=True, exist_ok=True)
    df.to_json(output_file, orient="records", lines=True, force_ascii=False)


def save_json(df: pd.DataFrame, output_file: str) -> None:
    """Save DataFrame to a single JSON array."""
    Path(output_file).parent.mkdir(parents=True, exist_ok=True)
    df.to_json(output_file, orient="records", force_ascii=False)


def save_dataframe(df: pd.DataFrame, output_file: str) -> None:
    """Save DataFrame to file based on extension.

    Supported formats: csv, tsv, jsonl, json, xlsx.
    """
    Path(output_file).parent.mkdir(parents=True, exist_ok=True)
    suffix = _get_suffix(output_file)
    handlers = {
        ".csv": lambda: df.to_csv(output_file, index=False),
        ".tsv": lambda: df.to_csv(output_file, sep="\t", index=False),
        ".jsonl": lambda: save_jsonl(df, output_file),
        ".json": lambda: save_json(df, output_file),
        ".xlsx": lambda: df.to_excel(output_file, index=False),
    }

    handler = handlers.get(suffix)
    if handler is None:
        raise ValueError(
            f"Unsupported file extension '{suffix}' in '{output_file}'. "
            f"Supported: {', '.join(handlers.keys())}"
        )
    handler()
