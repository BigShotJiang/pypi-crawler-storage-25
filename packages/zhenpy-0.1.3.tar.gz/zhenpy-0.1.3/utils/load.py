import pandas as pd
from pathlib import Path
from pandas import DataFrame


def load_jsonl(input_file, names=None) -> DataFrame:
    suffix = Path(input_file).suffix.lower()
    if suffix == '.csv':
        return pd.read_csv(input_file, names=names)
    if suffix == '.tsv':
        return pd.read_csv(input_file, sep='\t', names=names)
    return pd.read_json(input_file, lines=True)


def load_jsonl_dataframe(input_file):
    return pd.read_json(input_file, lines=True)


def load_json_dataframe(input_file):
    return pd.read_json(input_file)


def load_file_dataframe(input_file, names=None) -> DataFrame:
    suffix = Path(input_file).suffix.lower()
    loaders = {
        '.csv': lambda: pd.read_csv(input_file, names=names),
        '.tsv': lambda: pd.read_csv(input_file, sep='\t', names=names),
        '.xlsx': lambda: pd.read_excel(input_file),
        '.jsonl': lambda: load_jsonl_dataframe(input_file),
        '.json': lambda: load_json_dataframe(input_file),
    }
    loader = loaders.get(suffix)
    if loader:
        return loader()
    print(f"File: {input_file}, doesn't contain a supported suffix [csv, tsv, jsonl, json, xlsx]")
    return None
