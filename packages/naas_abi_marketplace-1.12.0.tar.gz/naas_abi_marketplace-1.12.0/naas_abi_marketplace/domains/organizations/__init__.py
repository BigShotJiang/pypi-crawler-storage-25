from fastapi import FastAPI
from naas_abi_core.module.Module import (
    BaseModule,
    ModuleConfiguration,
    ModuleDependencies,
)
from naas_abi_core.services.object_storage.ObjectStorageService import (
    ObjectStorageService,
)

# from naas_abi_core.services.secret.Secret import Secret
from naas_abi_core.services.triple_store.TripleStoreService import TripleStoreService

# from naas_abi_core.services.vector_store.VectorStoreService import VectorStoreService
# from naas_abi_core.services.bus.BusService import BusService
# from naas_abi_core.services.keyvalue.KeyValueService import KeyValueService


class ABIModule(BaseModule):
    dependencies: ModuleDependencies = ModuleDependencies(
        modules=[
            "naas_abi_marketplace.applications.sec_gov#soft",
            "naas_abi_core.modules.templatablesparqlquery",
        ],
        services=[
            # Secret,
            TripleStoreService,
            ObjectStorageService,
            # VectorStoreService,
            # BusService,
            # KeyValueService,
        ],
    )

    class Configuration(ModuleConfiguration):
        pass

    # on_initialized is called by the engine after all modules and services have been fully loaded.
    # At this point, you can safely access other modules and services through the engine's interfaces.
    # Override this method to implement any post-initialization logic your module requires.
    def on_initialized(self) -> None:
        super().on_initialized()

        import glob
        import os

        # Convert ontologies to Python classes.
        from naas_abi_core import logger
        from naas_abi_core.utils.onto2py import onto2py

        ontologies_dir = os.path.join(os.path.dirname(__file__), "ontologies")
        ttl_files = glob.glob(
            os.path.join(ontologies_dir, "modules", "*.ttl"), recursive=True
        )

        if not ttl_files:
            logger.warning(f"No TTL files found in {ontologies_dir}")
            return

        for ttl_file in ttl_files:
            try:
                logger.debug(f"Converting {ttl_file} to Python")
                onto2py(ttl_file)
            except Exception as e:
                logger.error(
                    f"Failed to convert {ttl_file} to Python: {e}", exc_info=True
                )

        # if not self.configuration.sync_sec_org_graph_on_startup:
        #     return
        # from naas_abi_marketplace.applications.sec_gov import ABIModule as SecGovModule
        # from naas_abi_marketplace.domains.organizations.pipelines.SecGovCompanyTickersPipeline import (
        #     SecGovCompanyTickersPipeline,
        #     SecGovCompanyTickersPipelineConfiguration,
        #     SecGovCompanyTickersPipelineParameters,
        # )

        # sec = SecGovModule.get_instance()
        # pipeline = SecGovCompanyTickersPipeline(
        #     SecGovCompanyTickersPipelineConfiguration(
        #         triple_store=self.engine.services.triple_store,
        #         object_storage=self.engine.services.object_storage,
        #         user_agent=sec.configuration.user_agent,
        #         datastore_path=sec.configuration.datastore_path,
        #     )
        # )
        # try:
        #     pipeline.run(SecGovCompanyTickersPipelineParameters())
        # except Exception as e:
        #     logger.warning(
        #         "SEC organization graph sync skipped or failed: %s",
        #         e,
        #         exc_info=True,
        #     )

    # The on_load method is invoked during initial module loading by the engine.
    # At this point, avoid accessing services or other modules, as they have not been loaded yet.
    # Place any logic here that must occur right as the module is loaded, before initialization.
    # You can see it as the constructor of the module.
    def on_load(self):
        super().on_load()

    # Optional FastAPI integration hook.
    # This mirrors how `naas_abi` wires API settings and services into app.state.
    # Override and adapt to your module if you expose HTTP routes.
    def api(self, app: FastAPI) -> None:
        # Example: expose services to your API layer.
        # app.state.object_storage = self.engine.services.object_storage
        # app.state.secret_service = self.engine.services.secret
        # app.state.triple_store = self.engine.services.triple_store
        # app.state.vector_store = self.engine.services.vector_store
        # app.state.bus_service = self.engine.services.bus
        # app.state.key_value_service = self.engine.services.kv

        # Example: mount your FastAPI routes/app factory.
        # from your_module.apps.api.app.main import create_app
        # create_app(app)
        pass
