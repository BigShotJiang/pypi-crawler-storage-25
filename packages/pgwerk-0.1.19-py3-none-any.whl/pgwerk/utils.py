"""Utility functions shared across app, workers, and scheduler."""

from __future__ import annotations

import sys
import asyncio
import hashlib
import inspect
import logging
import importlib

from typing import Any
from typing import Callable
from datetime import datetime
from datetime import timezone
from datetime import timedelta

from pgwerk.schemas import Job
from pgwerk.schemas import Retry
from pgwerk.schemas import Context
from pgwerk.schemas import Callback
from pgwerk.schemas import Dependency
from pgwerk.schemas import Schedule

logger = logging.getLogger(__name__)


def tty_supports_color(stream: Any = None) -> bool:
    """Return True if *stream* is a TTY that likely supports ANSI colour codes.

    Args:
        stream: File-like object to test; defaults to ``sys.stderr``.

    Returns:
        ``True`` if the stream has ``isatty()`` and it returns a truthy value.
    """
    stream = stream or sys.stderr
    return hasattr(stream, "isatty") and stream.isatty()


def schedule_tick_key(schedule: Schedule) -> str:
    """Return a dedup key for a single schedule tick.

    Stable within the current scheduling bucket so that concurrent enqueues
    (from multiple schedulers or a retry) collapse via the ``_jobs.key`` UNIQUE
    constraint.
    """
    if schedule.interval_secs:
        bucket = int(datetime.now(timezone.utc).timestamp() // schedule.interval_secs)
        return f"_pgwerk_sched:{schedule.name}:interval:{bucket}"

    if schedule.next_run_at is not None:
        nxt = schedule.next_run_at
        if nxt.tzinfo is None:
            nxt = nxt.replace(tzinfo=timezone.utc)
        return f"_pgwerk_sched:{schedule.name}:cron:{nxt.isoformat()}"

    return f"_pgwerk_sched:{schedule.name}:fallback:{int(datetime.now(timezone.utc).timestamp())}"


def compute_next_run(
    interval_secs: int | None,
    cron: str | None,
    base: datetime | None = None,
) -> datetime:
    """Return the next run time given a schedule's policy.

    Args:
        interval_secs: Uniform interval between runs. Mutually exclusive with ``cron``.
        cron: Cron expression. Mutually exclusive with ``interval_secs``.
        base: Anchor time to compute from. Defaults to ``NOW()`` UTC. For an
            interval schedule this is typically the last (or current) run time.

    Raises:
        ValueError: If neither (or both) of ``interval_secs`` / ``cron`` is set.
        ImportError: If ``cron`` is set but ``croniter`` is not installed.
    """
    if (interval_secs is None) == (cron is None):
        raise ValueError("Specify either interval_secs or cron, not both")

    anchor = base or datetime.now(timezone.utc)
    if anchor.tzinfo is None:
        anchor = anchor.replace(tzinfo=timezone.utc)

    if interval_secs is not None:
        return anchor + timedelta(seconds=interval_secs)

    try:
        from croniter import croniter
    except ImportError:
        raise ImportError("croniter is required for cron expressions: pip install croniter")
    assert cron is not None
    return croniter(cron, anchor).get_next(datetime)


def advisory_key(s: str) -> int:
    """Derive a stable PostgreSQL advisory lock key from a string.

    Uses blake2b so the result is identical across processes regardless of
    PYTHONHASHSEED. Returns a non-negative int64 (fits pg's bigint).
    """
    digest = hashlib.blake2b(s.encode(), digest_size=8).digest()
    return int.from_bytes(digest, "big", signed=False) & 0x7FFFFFFFFFFFFFFF


# ---------------------------------------------------------------------------
# Worker helpers
# ---------------------------------------------------------------------------


def wants_context(fn: Callable) -> bool:
    """Return True if *fn*'s first positional parameter is named ``ctx`` or annotated as Context."""
    try:
        params = [
            p
            for p in inspect.signature(fn).parameters.values()
            if p.kind in (p.POSITIONAL_ONLY, p.POSITIONAL_OR_KEYWORD)
        ]
        if not params:
            return False
        first = params[0]
        if first.name == "ctx":
            return True
        ann = first.annotation
        if ann is inspect.Parameter.empty:
            return False
        return ann is Context or (isinstance(ann, str) and ann == "Context")
    except (ValueError, TypeError):
        return False


async def call_hook(hook: Callable, ctx: "Context") -> None:
    """Call *hook* with *ctx*, awaiting it if it returns a coroutine.

    Args:
        hook: A sync or async callable that accepts a single Context argument.
        ctx: The execution context to pass to the hook.
    """
    result = hook(ctx)
    if asyncio.iscoroutine(result):
        await result


async def invoke_callback(dotted: str, job: "Job", timeout: int | None = None) -> None:
    """Import and call a callback by dotted path. Never raises."""
    try:
        fn = import_fn(dotted)
        coro = fn(job)
        if asyncio.iscoroutine(coro):
            if timeout:
                await asyncio.wait_for(coro, timeout=timeout)
            else:
                await coro
    except asyncio.TimeoutError:
        logger.warning("Callback %s timed out for job %s", dotted, job.id)
    except Exception as exc:
        logger.exception("Callback %s failed for job %s: %s", dotted, job.id, exc)


# ---------------------------------------------------------------------------
# Enqueue helpers
# ---------------------------------------------------------------------------


def import_fn(dotted: str) -> Callable:
    """Import a callable from its dotted module path.

    Supports module-level functions and class methods/staticmethods. For class
    members the path includes the class name as a qualname component
    (e.g. ``module.ClassName.method``), so this walks from right to left until
    a valid module is found, then resolves the remaining attributes.

    If the target module exists but one of its imports is missing, the real
    ``ModuleNotFoundError`` is re-raised immediately rather than being swallowed
    and replaced with the generic "Couldn't import" message.
    """
    parts = dotted.split(".")
    for i in range(len(parts) - 1, 0, -1):
        module_path = ".".join(parts[:i])
        try:
            obj: Any = importlib.import_module(module_path)
            for attr in parts[i:]:
                obj = getattr(obj, attr)
            return obj
        except ModuleNotFoundError as exc:
            is_own_module = exc.name and (
                exc.name == module_path or module_path.startswith(exc.name + ".")
            )
            if not is_own_module:
                raise
            continue
        except AttributeError:
            continue
    raise ImportError(
        f"Couldn't import {dotted!r}. Make sure the dotted path points to a "
        "module-level function, class, or class method that is importable at runtime."
    )


def fn_path(func: Callable) -> str:
    """Return the dotted module path for *func*.

    Args:
        func: A module-level callable.

    Returns:
        ``module.qualname`` string suitable for dynamic import.

    Raises:
        ValueError: If *func* is a local function or lambda that cannot be
            imported by dotted path.
    """
    qualname = func.__qualname__
    if "<locals>" in qualname or "<lambda>" in qualname:
        raise ValueError(
            f"Cannot enqueue {func!r}: only module-level functions are supported (got qualname={qualname!r})."
        )
    return f"{func.__module__}.{qualname}"


_DEFAULT_BACKOFF_BASE = 2
_DEFAULT_BACKOFF_CAP = 300


def default_backoff_intervals(max_attempts: int) -> list[int] | None:
    """Generate an exponential backoff schedule for ``max_attempts`` total attempts.

    Produces ``max_attempts - 1`` delays of ``base * 2**i`` seconds, capped at
    :data:`_DEFAULT_BACKOFF_CAP`. Returns ``None`` when no retries are possible.
    """
    n = max_attempts - 1
    if n <= 0:
        return None
    return [min(_DEFAULT_BACKOFF_BASE * (2**i), _DEFAULT_BACKOFF_CAP) for i in range(n)]


def normalize_retry(
    retry: "Retry | int | None",
    default_backoff: bool = True,
) -> tuple[int, list[int] | None]:
    """Normalise a ``retry`` argument to ``(max_attempts, intervals_or_None)``.

    Args:
        retry: A :class:`~wrk.schemas.Retry` object, a plain integer (max
            attempts), or ``None`` (use library defaults).
        default_backoff: When ``True`` and ``retry`` is ``None`` or a plain
            integer, synthesize an exponential backoff schedule. Set to
            ``False`` to preserve the legacy immediate-retry behavior. An
            explicit :class:`Retry` always wins — its intervals are used
            verbatim.

    Returns:
        A tuple of ``(max_attempts, retry_intervals)`` where ``retry_intervals``
        is a list of per-attempt delays in seconds, or ``None`` for immediate retry.
    """
    if retry is None:
        return 3, default_backoff_intervals(3) if default_backoff else None
    if retry == 0:
        return 1, None
    if isinstance(retry, int):
        return retry, default_backoff_intervals(retry) if default_backoff else None
    if isinstance(retry.intervals, list):
        return retry.max, retry.intervals if retry.intervals else None
    if retry.intervals:  # uniform int > 0
        return retry.max, [retry.intervals]
    return retry.max, None


def normalize_callback(
    cb: "Callback | Callable | str | None",
) -> tuple[str | None, int | None]:
    """Normalise a callback argument to ``(dotted_path, timeout_or_None)``.

    Args:
        cb: A :class:`~wrk.schemas.Callback` object, a callable, a dotted
            import path string, or ``None``.

    Returns:
        A tuple of ``(dotted_path, timeout_secs)`` or ``(None, None)`` if *cb*
        is ``None``.
    """
    if cb is None:
        return None, None
    if isinstance(cb, Callback):
        return cb.path(), cb.timeout
    if callable(cb):
        return fn_path(cb), None
    return cb, None


def normalize_depends_on(
    depends_on: "list[Dependency | str | Job] | Dependency | str | Job | None",
) -> list[tuple[str, bool]]:
    """Normalise a ``depends_on`` argument to a list of ``(job_id, allow_failure)`` tuples.

    Args:
        depends_on: A single dependency or a list of dependencies expressed as
            :class:`~wrk.schemas.Dependency` objects, :class:`~wrk.schemas.Job`
            objects, or raw UUID strings.

    Returns:
        A list of ``(job_id_str, allow_failure)`` tuples ready for DB insertion.
    """
    if depends_on is None:
        return []
    if not isinstance(depends_on, list):
        depends_on = [depends_on]
    result = []
    for d in depends_on:
        if isinstance(d, Dependency):
            result.append((d.job_id, d.allow_failure))
        elif isinstance(d, Job):
            result.append((d.id, False))
        else:
            result.append((str(d), False))
    return result
