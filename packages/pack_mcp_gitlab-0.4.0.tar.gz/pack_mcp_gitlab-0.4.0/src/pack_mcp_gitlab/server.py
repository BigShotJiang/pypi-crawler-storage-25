import json
import os
import logging
from mcp.server.fastmcp import FastMCP

mcp = FastMCP("pack-mcp-gitlab")

_client = None


def get_gitlab_client():
    """Inicializa e retorna o cliente GitLab com validação de config (singleton)."""
    global _client
    if _client is not None:
        return _client

    from pack_mcp_gitlab.client import GitLabClient

    log_level = os.environ.get("LOG_LEVEL", "WARNING").upper()
    logging.basicConfig(level=getattr(logging, log_level, logging.WARNING))

    gitlab_url = os.environ.get("GITLAB_URL", "")
    gitlab_token = os.environ.get("GITLAB_TOKEN", "")

    _client = GitLabClient(gitlab_url, gitlab_token)
    return _client


@mcp.tool()
async def list_merge_requests(project_path: str, state: str = "opened") -> str:
    """Lista Merge Requests de um projeto no GitLab.

    Args:
        project_path: Caminho completo do projeto (ex: "grupo/subgrupo/projeto").
        state: Filtro por estado do MR. Valores: "opened", "closed", "merged", "all". Padrão: "opened".

    Returns:
        JSON array com MRs contendo: iid, title, author (username), source_branch, target_branch, state, web_url, created_at, updated_at.
    """
    client = get_gitlab_client()
    result = client.list_merge_requests(project_path, state)
    return json.dumps(result)


@mcp.tool()
async def get_merge_request(project_path: str, mr_iid: int) -> str:
    """Obtém detalhes completos de um Merge Request específico.

    Args:
        project_path: Caminho completo do projeto (ex: "grupo/subgrupo/projeto").
        mr_iid: Número (IID) do Merge Request dentro do projeto.

    Returns:
        JSON com: iid, title, description, state, author (name, username), source_branch, target_branch, web_url, created_at, updated_at.
    """
    client = get_gitlab_client()
    result = client.get_merge_request(project_path, mr_iid)
    return json.dumps(result)


@mcp.tool()
async def get_merge_request_changes(project_path: str, mr_iid: int) -> str:
    """Obtém as alterações (diffs) de um Merge Request, arquivo por arquivo.

    Args:
        project_path: Caminho completo do projeto (ex: "grupo/subgrupo/projeto").
        mr_iid: Número (IID) do Merge Request dentro do projeto.

    Returns:
        JSON array com um objeto por arquivo alterado contendo: new_path, old_path, new_file, renamed_file, deleted_file, diff (texto do diff unificado).
    """
    client = get_gitlab_client()
    result = client.get_merge_request_changes(project_path, mr_iid)
    return json.dumps(result)


@mcp.tool()
async def get_file_content(project_path: str, file_path: str, ref: str = "HEAD") -> str:
    """Lê o conteúdo de um arquivo do repositório GitLab.

    Args:
        project_path: Caminho completo do projeto (ex: "grupo/subgrupo/projeto").
        file_path: Caminho do arquivo dentro do repositório (ex: "src/main/App.java").
        ref: Branch, tag ou commit SHA de onde ler o arquivo. Padrão: "HEAD".

    Returns:
        JSON com: file_path, ref, content (conteúdo UTF-8 do arquivo).
    """
    client = get_gitlab_client()
    result = client.get_file_content(project_path, file_path, ref)
    return json.dumps(result)


@mcp.tool()
async def create_merge_request_note(project_path: str, mr_iid: int, body: str) -> str:
    """Posta um comentário (note) em um Merge Request no GitLab.

    Args:
        project_path: Caminho completo do projeto (ex: "grupo/subgrupo/projeto").
        mr_iid: Número (IID) do Merge Request dentro do projeto.
        body: Texto do comentário a ser postado. Suporta Markdown do GitLab. Não pode ser vazio.

    Returns:
        JSON com: id (ID do comentário criado), success (true).
    """
    client = get_gitlab_client()
    result = client.create_merge_request_note(project_path, mr_iid, body)
    return json.dumps(result)


@mcp.tool()
async def list_merge_request_notes(project_path: str, mr_iid: int) -> str:
    """Lista todos os comentários (notes) de um Merge Request.

    Args:
        project_path: Caminho completo do projeto (ex: "grupo/subgrupo/projeto").
        mr_iid: Número (IID) do Merge Request dentro do projeto.

    Returns:
        JSON array com notes contendo: id, body, author (name, username), created_at, system (true se é nota automática do GitLab).
    """
    client = get_gitlab_client()
    result = client.list_merge_request_notes(project_path, mr_iid)
    return json.dumps(result)


@mcp.tool()
async def get_project(project_path: str) -> str:
    """Obtém informações de um projeto no GitLab.

    Args:
        project_path: Caminho completo do projeto (ex: "grupo/subgrupo/projeto").

    Returns:
        JSON com: id, name, path_with_namespace, description, default_branch, web_url, visibility.
    """
    client = get_gitlab_client()
    result = client.get_project(project_path)
    return json.dumps(result)


@mcp.tool()
async def search_projects(search: str) -> str:
    """Busca projetos no GitLab por nome. Use quando não souber o caminho exato do projeto.

    Args:
        search: Termo de busca (nome ou parte do nome do projeto).

    Returns:
        JSON array com projetos encontrados contendo: id, name, path_with_namespace, description, web_url. Retorna lista vazia se nenhum projeto corresponder.
    """
    client = get_gitlab_client()
    result = client.search_projects(search)
    return json.dumps(result)


@mcp.tool()
async def create_merge_request(
    project_path: str,
    source_branch: str,
    target_branch: str,
    title: str,
    description: str = "",
    remove_source_branch: bool = False,
    squash: bool = False,
    labels: str = "",
    assignee_ids: list[int] | None = None,
    reviewer_ids: list[int] | None = None,
) -> str:
    """Cria um novo Merge Request no GitLab. A source_branch já deve existir no repositório remoto.

    Args:
        project_path: Caminho completo do projeto (ex: "grupo/subgrupo/projeto").
        source_branch: Branch de origem com as alterações (deve existir no repositório). Ex: "feature/minha-feature".
        target_branch: Branch de destino onde as alterações serão mescladas. Ex: "main", "develop".
        title: Título do Merge Request. Deve ser descritivo e conciso.
        description: Descrição detalhada do MR. Suporta Markdown do GitLab. Padrão: vazio.
        remove_source_branch: Se true, remove a source_branch após o merge. Padrão: false.
        squash: Se true, faz squash dos commits ao mesclar. Padrão: false.
        labels: Labels separadas por vírgula (ex: "bug,urgente"). Padrão: vazio.
        assignee_ids: Lista de IDs numéricos dos usuários responsáveis pelo MR. Opcional.
        reviewer_ids: Lista de IDs numéricos dos revisores do MR. Opcional.

    Returns:
        JSON com: iid, title, state, web_url, source_branch, target_branch, created_at.
    """
    client = get_gitlab_client()
    result = client.create_merge_request(
        project_path, source_branch, target_branch, title,
        description, remove_source_branch, squash, labels,
        assignee_ids, reviewer_ids,
    )
    return json.dumps(result)


@mcp.tool()
async def get_merge_request_diff_versions(project_path: str, mr_iid: int) -> str:
    """Obtém as versões de diff de um Merge Request.

    Retorna os SHAs necessários para criar comentários inline no diff.

    Args:
        project_path: Caminho completo do projeto (ex: "grupo/subgrupo/projeto").
        mr_iid: Número (IID) do Merge Request dentro do projeto.

    Returns:
        JSON array com versões de diff contendo: id, head_commit_sha, base_commit_sha, start_commit_sha, created_at, state, real_size.
    """
    client = get_gitlab_client()
    result = client.get_merge_request_diff_versions(project_path, mr_iid)
    return json.dumps(result)


@mcp.tool()
async def create_merge_request_discussion(
    project_path: str,
    mr_iid: int,
    body: str,
    position: dict | None = None,
) -> str:
    """Cria uma thread de discussão (discussion) em um Merge Request no GitLab.

    Permite criar comentários gerais ou comentários inline posicionados em linhas
    específicas do diff. Para comentários inline, forneça o parâmetro position com
    os SHAs obtidos via get_merge_request_diff_versions.

    Args:
        project_path: Caminho completo do projeto (ex: "grupo/subgrupo/projeto").
        mr_iid: Número (IID) do Merge Request dentro do projeto.
        body: Texto da discussão. Suporta Markdown do GitLab. Não pode ser vazio.
        position: Objeto opcional para posicionar o comentário no diff. Campos obrigatórios:
            base_sha (str) — SHA do commit base,
            head_sha (str) — SHA do HEAD,
            start_sha (str) — SHA do commit start,
            position_type (str) — tipo de posição (ex: "text"),
            new_path (str) — caminho do arquivo novo,
            old_path (str) — caminho do arquivo antigo.
            Campos opcionais:
            new_line (int) — linha no arquivo novo (para linhas adicionadas ou inalteradas),
            old_line (int) — linha no arquivo antigo (para linhas removidas ou inalteradas).

    Returns:
        JSON com: id (ID da discussion criada), success (true).
    """
    client = get_gitlab_client()
    result = client.create_merge_request_discussion(project_path, mr_iid, body, position)
    return json.dumps(result)


@mcp.tool()
async def resolve_merge_request_discussion(
    project_path: str,
    mr_iid: int,
    discussion_id: str,
    resolved: bool,
) -> str:
    """Resolve ou reabre uma thread de discussão (discussion) em um Merge Request no GitLab.

    Args:
        project_path: Caminho completo do projeto (ex: "grupo/subgrupo/projeto").
        mr_iid: Número (IID) do Merge Request dentro do projeto.
        discussion_id: ID da discussion a ser resolvida ou reaberta.
        resolved: Se true, resolve a discussion. Se false, reabre a discussion.

    Returns:
        JSON com: id (ID da discussion), resolved (estado atualizado), success (true).
    """
    client = get_gitlab_client()
    result = client.resolve_merge_request_discussion(project_path, mr_iid, discussion_id, resolved)
    return json.dumps(result)


@mcp.tool()
async def list_merge_request_discussions(project_path: str, mr_iid: int) -> str:
    """Lista todas as threads de discussão (discussions) de um Merge Request.

    Retorna as discussions com suas notas, incluindo informações de autor,
    estado de resolução e posição no diff quando aplicável.

    Args:
        project_path: Caminho completo do projeto (ex: "grupo/subgrupo/projeto").
        mr_iid: Número (IID) do Merge Request dentro do projeto.

    Returns:
        JSON array com discussions contendo: id, notes (array com id, body, author, created_at, resolved, position).
    """
    client = get_gitlab_client()
    result = client.list_merge_request_discussions(project_path, mr_iid)
    return json.dumps(result)


def main():
    mcp.run(transport="stdio")


if __name__ == "__main__":
    main()
