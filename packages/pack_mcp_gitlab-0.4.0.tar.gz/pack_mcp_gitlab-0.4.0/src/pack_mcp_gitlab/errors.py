import functools
import logging
import re

import requests
from gitlab.exceptions import (
    GitlabAuthenticationError,
    GitlabCreateError,
    GitlabGetError,
    GitlabHttpError,
)
from mcp.shared.exceptions import McpError
from mcp.types import INTERNAL_ERROR, ErrorData

logger = logging.getLogger(__name__)

_TOKEN_PATTERN = re.compile(
    r"(glpat-[A-Za-z0-9_\-]{20,}|private.token=[^\s&]+)", re.IGNORECASE
)


def _sanitize(message: str) -> str:
    """Remove tokens de acesso de mensagens de log."""
    return _TOKEN_PATTERN.sub("[REDACTED]", message)


def handle_gitlab_error(func):
    """Decorator que converte exceções GitLab em respostas de erro MCP.

    Mapeia exceções específicas do python-gitlab e requests para
    mensagens de erro descritivas via McpError, garantindo que
    logs nunca exponham tokens de acesso.
    """

    @functools.wraps(func)
    def wrapper(*args, **kwargs):
        try:
            return func(*args, **kwargs)
        except GitlabAuthenticationError:
            msg = "Falha de autenticação: token inválido ou expirado"
            logger.error(_sanitize(msg))
            raise McpError(ErrorData(code=INTERNAL_ERROR, message=msg))
        except GitlabGetError as e:
            if getattr(e, "response_code", None) == 404:
                msg = f"Recurso não encontrado: {_sanitize(str(e))}"
            else:
                msg = f"Erro GitLab: {_sanitize(str(e))}"
            logger.error(_sanitize(msg))
            raise McpError(ErrorData(code=INTERNAL_ERROR, message=msg))
        except GitlabCreateError as e:
            msg = f"Erro ao criar recurso no GitLab: {_sanitize(str(e))}"
            logger.error(_sanitize(msg))
            raise McpError(ErrorData(code=INTERNAL_ERROR, message=msg))
        except GitlabHttpError as e:
            if getattr(e, "response_code", None) == 403:
                msg = "Permissão negada: token sem acesso para esta operação"
            else:
                msg = f"Erro HTTP GitLab: {_sanitize(str(e))}"
            logger.error(_sanitize(msg))
            raise McpError(ErrorData(code=INTERNAL_ERROR, message=msg))
        except requests.ConnectionError as e:
            msg = f"Erro de conexão: {_sanitize(str(e))}"
            logger.error(_sanitize(msg))
            raise McpError(ErrorData(code=INTERNAL_ERROR, message=msg))
        except requests.Timeout as e:
            msg = f"Timeout na conexão com GitLab: {_sanitize(str(e))}"
            logger.error(_sanitize(msg))
            raise McpError(ErrorData(code=INTERNAL_ERROR, message=msg))
        except McpError:
            raise
        except Exception as e:
            msg = f"Erro inesperado: {type(e).__name__}: {_sanitize(str(e))}"
            logger.error(_sanitize(msg))
            raise McpError(ErrorData(code=INTERNAL_ERROR, message=msg))

    return wrapper
