import pytest
from unittest.mock import MagicMock, patch
from hypothesis import settings

from pack_mcp_gitlab.client import GitLabClient

# Configure Hypothesis: minimum 100 examples per test
settings.register_profile("default", max_examples=100)
settings.load_profile("default")


@pytest.fixture
def mock_gitlab():
    """Mock do gitlab.Gitlab."""
    return MagicMock()


@pytest.fixture
def gitlab_client(mock_gitlab):
    """GitLabClient com gitlab.Gitlab mockado."""
    with patch("pack_mcp_gitlab.client.gitlab.Gitlab", return_value=mock_gitlab):
        client = GitLabClient("https://gitlab.example.com", "glpat-test-token-12345678901234")
    return client
