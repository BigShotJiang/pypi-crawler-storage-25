"""Property-based tests for create_merge_request_discussion and list_merge_request_discussions.

Properties:
  P3 — General creation: discussion without position returns {id, success: true}.
  P4 — Empty body: empty or whitespace body raises ValueError (converted to McpError).
  P5 — Inline position: discussion with position sends required fields to GitLab.
  P6 — Resolve/reopen: resolved=true/false returns correct state.
  P7 — Discussion not found: inexistent discussion_id raises McpError.
  P8 — Discussion mapping: each discussion preserves id and notes with correct fields.
  P9 — Empty list: MR without discussions returns empty array.
"""

from unittest.mock import MagicMock

import pytest
import hypothesis.strategies as st
from hypothesis import given, settings, HealthCheck
from gitlab.exceptions import GitlabGetError
from mcp.shared.exceptions import McpError

from tests.strategies import (
    discussion_id_strings,
    discussions_list,
    gitlab_get_errors,
    position_data,
    project_paths,
    whitespace_strings,
)


class TestCreateDiscussionGeneral:
    """**Validates: Requirements 2.1**"""

    @settings(suppress_health_check=[HealthCheck.function_scoped_fixture])
    @given(
        project_path=project_paths(),
        disc_id=discussion_id_strings(),
    )
    def test_p3_creation_returns_id_and_success(
        self, gitlab_client, project_path, disc_id
    ):
        """P3: Discussion without position returns {id, success: true}."""
        mock_project = MagicMock()
        mock_mr = MagicMock()
        mock_discussion = MagicMock()
        mock_discussion.id = disc_id

        gitlab_client.gl.projects.get.return_value = mock_project
        mock_project.mergerequests.get.return_value = mock_mr
        mock_mr.discussions.create.return_value = mock_discussion

        result = gitlab_client.create_merge_request_discussion(
            project_path, 1, "Some review comment"
        )

        assert result == {"id": disc_id, "success": True}
        mock_mr.discussions.create.assert_called_once_with({"body": "Some review comment"})


class TestCreateDiscussionEmptyBody:
    """**Validates: Requirements 2.7**"""

    @settings(suppress_health_check=[HealthCheck.function_scoped_fixture])
    @given(
        project_path=project_paths(),
        body=whitespace_strings(),
    )
    def test_p4_empty_body_raises_error(self, gitlab_client, project_path, body):
        """P4: Empty or whitespace body raises McpError."""
        with pytest.raises(McpError):
            gitlab_client.create_merge_request_discussion(project_path, 1, body)


class TestCreateDiscussionInlinePosition:
    """**Validates: Requirements 2.2, 2.3, 2.4, 2.5, 2.6**"""

    @settings(suppress_health_check=[HealthCheck.function_scoped_fixture])
    @given(
        project_path=project_paths(),
        disc_id=discussion_id_strings(),
        position=position_data(),
    )
    def test_p5_position_inline_sends_required_fields(
        self, gitlab_client, project_path, disc_id, position
    ):
        """P5: Discussion with position includes required fields in data sent to GitLab."""
        mock_project = MagicMock()
        mock_mr = MagicMock()
        mock_discussion = MagicMock()
        mock_discussion.id = disc_id

        gitlab_client.gl.projects.get.return_value = mock_project
        mock_project.mergerequests.get.return_value = mock_mr
        mock_mr.discussions.create.return_value = mock_discussion

        result = gitlab_client.create_merge_request_discussion(
            project_path, 1, "Inline comment", position=position
        )

        assert result == {"id": disc_id, "success": True}

        call_args = mock_mr.discussions.create.call_args[0][0]
        assert call_args["body"] == "Inline comment"
        assert "position" in call_args

        sent_position = call_args["position"]
        required_fields = {
            "base_sha",
            "head_sha",
            "start_sha",
            "position_type",
            "new_path",
            "old_path",
        }
        for field in required_fields:
            assert field in sent_position, f"Missing required field: {field}"
            assert sent_position[field] == position[field]

        # Verify line fields match the position variant
        if "new_line" in position and "old_line" not in position:
            # Added line: only new_line
            assert "new_line" in sent_position
        elif "old_line" in position and "new_line" not in position:
            # Removed line: only old_line
            assert "old_line" in sent_position
        else:
            # Unchanged line: both
            assert "new_line" in sent_position
            assert "old_line" in sent_position



class TestResolveDiscussion:
    """**Validates: Requirements 3.1, 3.2**"""

    @settings(suppress_health_check=[HealthCheck.function_scoped_fixture])
    @given(
        project_path=project_paths(),
        disc_id=discussion_id_strings(),
        resolved=st.booleans(),
    )
    def test_p6_resolve_reopen_returns_correct_state(
        self, gitlab_client, project_path, disc_id, resolved
    ):
        """P6: resolved=true returns {id, resolved: true, success: true} and resolved=false returns {id, resolved: false, success: true}."""
        mock_project = MagicMock()
        mock_mr = MagicMock()
        mock_discussion = MagicMock()
        mock_note = MagicMock()

        # Setup discussion with a resolvable note
        mock_discussion.attributes = {
            "notes": [{"id": 1, "resolvable": True}]
        }

        gitlab_client.gl.projects.get.return_value = mock_project
        mock_project.mergerequests.get.return_value = mock_mr
        mock_mr.discussions.get.return_value = mock_discussion
        mock_mr.notes.get.return_value = mock_note

        result = gitlab_client.resolve_merge_request_discussion(
            project_path, 1, disc_id, resolved
        )

        assert result == {"id": disc_id, "resolved": resolved, "success": True}
        mock_mr.discussions.get.assert_called_once_with(disc_id)
        mock_mr.notes.get.assert_called_once_with(1)
        assert mock_note.resolved == resolved
        mock_note.save.assert_called_once()


class TestResolveDiscussionNotFound:
    """**Validates: Requirements 3.3**"""

    @settings(suppress_health_check=[HealthCheck.function_scoped_fixture])
    @given(
        project_path=project_paths(),
        disc_id=discussion_id_strings(),
        error=gitlab_get_errors(response_code=404),
    )
    def test_p7_discussion_not_found_raises_mcp_error(
        self, gitlab_client, project_path, disc_id, error
    ):
        """P7: discussion_id inexistente gera McpError com 'Recurso não encontrado'."""
        mock_project = MagicMock()
        mock_mr = MagicMock()

        gitlab_client.gl.projects.get.return_value = mock_project
        mock_project.mergerequests.get.return_value = mock_mr
        mock_mr.discussions.get.side_effect = error

        with pytest.raises(McpError, match="Recurso não encontrado"):
            gitlab_client.resolve_merge_request_discussion(
                project_path, 1, disc_id, True
            )


class TestListDiscussionsMapping:
    """**Validates: Requirements 4.1**"""

    @settings(suppress_health_check=[HealthCheck.function_scoped_fixture])
    @given(
        project_path=project_paths(),
        raw_discussions=discussions_list(),
    )
    def test_p8_discussions_preserve_id_and_notes(
        self, gitlab_client, project_path, raw_discussions
    ):
        """P8: Mapeamento de discussions — cada discussion retornada preserva id e notes com campos corretos."""
        mock_project = MagicMock()
        mock_mr = MagicMock()

        # Build MagicMock objects mimicking python-gitlab discussion objects
        mock_discussion_objects = []
        for disc in raw_discussions:
            mock_disc = MagicMock()
            mock_disc.id = disc["id"]
            mock_disc.attributes = {"notes": disc["notes"]}
            mock_discussion_objects.append(mock_disc)

        gitlab_client.gl.projects.get.return_value = mock_project
        mock_project.mergerequests.get.return_value = mock_mr
        mock_mr.discussions.list.return_value = mock_discussion_objects

        result = gitlab_client.list_merge_request_discussions(project_path, 1)

        assert len(result) == len(raw_discussions)

        for returned, original in zip(result, raw_discussions):
            assert returned["id"] == original["id"]
            assert len(returned["notes"]) == len(original["notes"])

            for ret_note, orig_note in zip(returned["notes"], original["notes"]):
                assert ret_note["id"] == orig_note["id"]
                assert ret_note["body"] == orig_note["body"]
                assert ret_note["author"]["name"] == orig_note["author"]["name"]
                assert ret_note["author"]["username"] == orig_note["author"]["username"]
                assert ret_note["created_at"] == orig_note["created_at"]
                assert ret_note["resolved"] == orig_note["resolved"]
                assert ret_note["position"] == orig_note.get("position", None)


class TestListDiscussionsEmpty:
    """**Validates: Requirements 4.2**"""

    @settings(suppress_health_check=[HealthCheck.function_scoped_fixture])
    @given(
        project_path=project_paths(),
    )
    def test_p9_empty_discussions_returns_empty_list(
        self, gitlab_client, project_path
    ):
        """P9: Lista vazia — MR sem discussions retorna array vazio."""
        mock_project = MagicMock()
        mock_mr = MagicMock()

        gitlab_client.gl.projects.get.return_value = mock_project
        mock_project.mergerequests.get.return_value = mock_mr
        mock_mr.discussions.list.return_value = []

        result = gitlab_client.list_merge_request_discussions(project_path, 1)

        assert result == []
