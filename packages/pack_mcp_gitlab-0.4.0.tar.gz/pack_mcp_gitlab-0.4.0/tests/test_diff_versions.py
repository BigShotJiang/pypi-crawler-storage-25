"""Property-based tests for get_merge_request_diff_versions.

Properties:
  P1 — Field mapping: each diff version contains exactly the 7 expected fields with correct types.
  P2 — 404 errors: nonexistent project or MR raises McpError with "Recurso não encontrado".
"""

from unittest.mock import MagicMock

import pytest
from hypothesis import given, settings, HealthCheck
from mcp.shared.exceptions import McpError

from tests.strategies import (
    diff_versions_list,
    gitlab_get_errors,
    project_paths,
)

EXPECTED_FIELDS = {
    "id",
    "head_commit_sha",
    "base_commit_sha",
    "start_commit_sha",
    "created_at",
    "state",
    "real_size",
}


class TestDiffVersionsFieldMapping:
    """**Validates: Requirements 1.1**"""

    @settings(suppress_health_check=[HealthCheck.function_scoped_fixture])
    @given(versions=diff_versions_list(), project_path=project_paths())
    def test_p1_field_mapping(self, gitlab_client, versions, project_path):
        """P1: Each diff version returned contains exactly the 7 expected fields."""
        mock_project = MagicMock()
        mock_mr = MagicMock()

        # Build mock diff objects from strategy data
        mock_diffs = []
        for v in versions:
            d = MagicMock()
            d.id = v["id"]
            d.head_commit_sha = v["head_commit_sha"]
            d.base_commit_sha = v["base_commit_sha"]
            d.start_commit_sha = v["start_commit_sha"]
            d.created_at = v["created_at"]
            d.state = v["state"]
            d.real_size = v["real_size"]
            mock_diffs.append(d)

        gitlab_client.gl.projects.get.return_value = mock_project
        mock_project.mergerequests.get.return_value = mock_mr
        mock_mr.diffs.list.return_value = mock_diffs

        result = gitlab_client.get_merge_request_diff_versions(project_path, 1)

        assert len(result) == len(versions)
        for item, original in zip(result, versions):
            assert set(item.keys()) == EXPECTED_FIELDS
            assert item["id"] == original["id"]
            assert item["head_commit_sha"] == original["head_commit_sha"]
            assert item["base_commit_sha"] == original["base_commit_sha"]
            assert item["start_commit_sha"] == original["start_commit_sha"]
            assert item["created_at"] == original["created_at"]
            assert item["state"] == original["state"]
            assert item["real_size"] == original["real_size"]


class TestDiffVersions404Errors:
    """**Validates: Requirements 1.2, 1.3**"""

    @settings(suppress_health_check=[HealthCheck.function_scoped_fixture])
    @given(error=gitlab_get_errors(response_code=404), project_path=project_paths())
    def test_p2_project_not_found(self, gitlab_client, error, project_path):
        """P2: Nonexistent project raises McpError with 'Recurso não encontrado'."""
        gitlab_client.gl.projects.get.side_effect = error

        with pytest.raises(McpError) as exc_info:
            gitlab_client.get_merge_request_diff_versions(project_path, 1)

        assert "Recurso não encontrado" in exc_info.value.error.message

    @settings(suppress_health_check=[HealthCheck.function_scoped_fixture])
    @given(error=gitlab_get_errors(response_code=404), project_path=project_paths())
    def test_p2_mr_not_found(self, gitlab_client, error, project_path):
        """P2: Nonexistent MR raises McpError with 'Recurso não encontrado'."""
        mock_project = MagicMock()
        gitlab_client.gl.projects.get.return_value = mock_project
        mock_project.mergerequests.get.side_effect = error

        with pytest.raises(McpError) as exc_info:
            gitlab_client.get_merge_request_diff_versions(project_path, 999)

        assert "Recurso não encontrado" in exc_info.value.error.message
