"""Property-based tests for authentication errors on the 4 new GitLab tools.

Properties:
  P10 — Authentication errors: GitlabAuthenticationError raises McpError
        with "token inválido ou expirado" for all new methods.

**Validates: Requirements 5.1**
"""

import pytest
from hypothesis import given, settings, HealthCheck
from mcp.shared.exceptions import McpError

from tests.strategies import gitlab_auth_errors, project_paths, discussion_id_strings

AUTH_MSG = "token inválido ou expirado"


class TestAuthErrorGetDiffVersions:
    """**Validates: Requirements 5.1**"""

    @settings(suppress_health_check=[HealthCheck.function_scoped_fixture])
    @given(
        project_path=project_paths(),
        error=gitlab_auth_errors(),
    )
    def test_p10_get_diff_versions_auth_error(self, gitlab_client, project_path, error):
        """P10: GitlabAuthenticationError in get_merge_request_diff_versions raises McpError."""
        gitlab_client.gl.projects.get.side_effect = error

        with pytest.raises(McpError, match=AUTH_MSG):
            gitlab_client.get_merge_request_diff_versions(project_path, 1)


class TestAuthErrorCreateDiscussion:
    """**Validates: Requirements 5.1**"""

    @settings(suppress_health_check=[HealthCheck.function_scoped_fixture])
    @given(
        project_path=project_paths(),
        error=gitlab_auth_errors(),
    )
    def test_p10_create_discussion_auth_error(self, gitlab_client, project_path, error):
        """P10: GitlabAuthenticationError in create_merge_request_discussion raises McpError."""
        gitlab_client.gl.projects.get.side_effect = error

        with pytest.raises(McpError, match=AUTH_MSG):
            gitlab_client.create_merge_request_discussion(project_path, 1, "comment body")


class TestAuthErrorResolveDiscussion:
    """**Validates: Requirements 5.1**"""

    @settings(suppress_health_check=[HealthCheck.function_scoped_fixture])
    @given(
        project_path=project_paths(),
        disc_id=discussion_id_strings(),
        error=gitlab_auth_errors(),
    )
    def test_p10_resolve_discussion_auth_error(self, gitlab_client, project_path, disc_id, error):
        """P10: GitlabAuthenticationError in resolve_merge_request_discussion raises McpError."""
        gitlab_client.gl.projects.get.side_effect = error

        with pytest.raises(McpError, match=AUTH_MSG):
            gitlab_client.resolve_merge_request_discussion(project_path, 1, disc_id, True)


class TestAuthErrorListDiscussions:
    """**Validates: Requirements 5.1**"""

    @settings(suppress_health_check=[HealthCheck.function_scoped_fixture])
    @given(
        project_path=project_paths(),
        error=gitlab_auth_errors(),
    )
    def test_p10_list_discussions_auth_error(self, gitlab_client, project_path, error):
        """P10: GitlabAuthenticationError in list_merge_request_discussions raises McpError."""
        gitlab_client.gl.projects.get.side_effect = error

        with pytest.raises(McpError, match=AUTH_MSG):
            gitlab_client.list_merge_request_discussions(project_path, 1)
