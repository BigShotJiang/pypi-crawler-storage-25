﻿#!/usr/bin/env python3
"""
data_corruptor.py - Backward-compatibility shim.

All functionality lives in data_validation_gini.utils.data_corruptor.
This module re-exports everything so existing imports continue to work.
"""
import sys
from pathlib import Path

if __package__:
    from .utils.data_corruptor import *  # noqa: F401,F403
    from .utils.data_corruptor import inject_variation, main, parse_arguments  # noqa: F401
else:  # pragma: no cover - script/run_path fallback
    src_dir = Path(__file__).resolve().parents[1]
    if str(src_dir) not in sys.path:
        sys.path.insert(0, str(src_dir))
    from data_validation_gini.utils.data_corruptor import *  # noqa: F401,F403
    from data_validation_gini.utils.data_corruptor import (  # noqa: F401
        inject_variation,
        main,
        parse_arguments,
    )

if __name__ == "__main__":  # pragma: no cover
    main()
