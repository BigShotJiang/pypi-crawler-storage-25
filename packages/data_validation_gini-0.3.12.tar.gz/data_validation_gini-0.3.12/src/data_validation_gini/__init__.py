"""Data Validation Gini package."""

from .dvg import main as dvg_main

__all__ = ["dvg_main"]
