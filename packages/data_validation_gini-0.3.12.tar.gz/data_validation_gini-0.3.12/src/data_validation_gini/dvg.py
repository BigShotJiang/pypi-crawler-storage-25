﻿#!/usr/bin/env python3
"""
dvg.py - Backward-compatibility shim.

All functionality lives in data_validation_gini.core.cli.
This module re-exports everything so existing imports continue to work.
"""
from .core.cli import *  # noqa: F401,F403
from .core.cli import (  # noqa: F401
    DEFAULT_DB_CONFIG,
    PROJECT_ROOT,
    _build_validation_service,
    _compute_total_chunks,
    _count_csv_data_rows,
    _values_are_equal,
    _print_chunk_complete,
    _print_chunk_progress,
    _print_chunk_start,
    _run_db_validation,
    is_excel_path,
    iter_chunks,
    load_csv,
    load_excel,
    load_table,
    main,
    normalize_cell,
    parse_args,
    parse_sheet_mapping,
    resolve_output_path,
    trim_trailing_empty,
)
from .core.comparators import compare_row_col, compare_rowcount  # noqa: F401
