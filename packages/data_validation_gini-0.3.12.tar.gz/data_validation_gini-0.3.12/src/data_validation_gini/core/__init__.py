# Domain objects
from .loaders import DbTableLoader, FileTableLoader
from .models import Dataset, ValidationBundleResult, ValidationResult
from .service import ValidationService
from .strategies import RowColumnStrategy, RowCountStrategy

# Comparison logic
from .comparators import compare_row_col, compare_rowcount

# Infrastructure
from .db import get_db_connection, list_db_tables, load_db_table
from .file_stores import IniConfigStore, JsonFileStore
from .report import build_report_metrics, generate_html_report, write_html_report

# CLI / entry point
from .cli import (
    iter_chunks,
    is_excel_path,
    load_csv,
    load_excel,
    load_table,
    main,
    normalize_cell,
    parse_args,
    parse_sheet_mapping,
    resolve_output_path,
    trim_trailing_empty,
)

__all__ = [
    # Domain
    "Dataset",
    "ValidationResult",
    "ValidationBundleResult",
    "FileTableLoader",
    "DbTableLoader",
    "RowCountStrategy",
    "RowColumnStrategy",
    "ValidationService",
    # Comparators
    "compare_rowcount",
    "compare_row_col",
    # DB
    "get_db_connection",
    "list_db_tables",
    "load_db_table",
    # File stores
    "IniConfigStore",
    "JsonFileStore",
    # Report
    "build_report_metrics",
    "generate_html_report",
    "write_html_report",
    # CLI helpers
    "iter_chunks",
    "is_excel_path",
    "load_csv",
    "load_excel",
    "load_table",
    "main",
    "normalize_cell",
    "parse_args",
    "parse_sheet_mapping",
    "resolve_output_path",
    "trim_trailing_empty",
]
