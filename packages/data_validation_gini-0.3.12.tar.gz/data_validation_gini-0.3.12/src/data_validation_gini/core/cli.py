#!/usr/bin/env python3
"""
cli.py – DVG command-line interface and file-loading utilities.

Moved to core/ as the canonical CLI module.  This module owns:
  - Argument parsing (parse_args)
  - File loading helpers (load_csv, load_excel, load_table)
  - The main() entry point
  - resolve_output_path helper
"""
from __future__ import annotations

import argparse
import csv
import os
import sys
from datetime import datetime
from itertools import islice
from pathlib import Path

from .comparators import _values_are_equal, compare_row_col, compare_rowcount
from .loaders import DbTableLoader, FileTableLoader
from .report import write_html_report
from .service import ValidationService
from .strategies import RowColumnStrategy, RowCountStrategy

PROJECT_ROOT = Path(__file__).resolve().parents[3]
DEFAULT_DB_CONFIG = str(PROJECT_ROOT / "database_config.ini")
FILE_KINDS = {"csv", "excel"}
DB_KINDS = {"sqlite", "postgresql", "mysql", "sqlserver", "oracle"}
SUPPORTED_DB_KINDS_FOR_CLI = {"sqlite", "postgresql", "mysql"}
ENVIRONMENTS = {"ACC", "NP1", "PRE_PROD", "PROD", "STAGE"}
VALIDATION_TYPE_ALIASES = {
    "ROWCOUNT": "ROWCOUNT_VALIDATION",
    "ROWCOUNT_VALIDATION": "ROWCOUNT_VALIDATION",
    "ROW_COL_VALIDATION": "ROW_COL_VALIDATION",
    "SCHEMA_VALIDATION": "SCHEMA_VALIDATION",
}


# ---------------------------------------------------------------------------
# Validation service factory
# ---------------------------------------------------------------------------

def _build_validation_service() -> ValidationService:
    return ValidationService(
        rowcount_strategy=RowCountStrategy(comparator=compare_rowcount),
        rowcol_strategy=RowColumnStrategy(comparator=compare_row_col),
    )


# ---------------------------------------------------------------------------
# Argument parsing
# ---------------------------------------------------------------------------

def parse_args():
    parser = argparse.ArgumentParser(
        description="Data Validation Gini CLI (dvg): compare source and target files."
    )
    parser.add_argument(
        "--file-type",
        required=False,
        choices=["EXCEL", "DB"],
        help="Input file type. Use EXCEL for .csv/.xlsx/.xlsm/.xltx files, DB for database tables.",
    )
    parser.add_argument(
        "--src-kind",
        required=False,
        choices=sorted(FILE_KINDS | DB_KINDS),
        help="Source kind: csv, excel, sqlite, postgresql, mysql, sqlserver, oracle.",
    )
    parser.add_argument(
        "--tgt-kind",
        required=False,
        choices=sorted(FILE_KINDS | DB_KINDS),
        help="Target kind: csv, excel, sqlite, postgresql, mysql, sqlserver, oracle.",
    )
    parser.add_argument("--src-path", required=False, help="Path to source file (EXCEL mode).")
    parser.add_argument("--tgt-path", required=False, help="Path to target file (EXCEL mode).")
    parser.add_argument(
        "--validation-type",
        required=True,
        help="Validation mode: ROWCOUNT, ROW_COL_VALIDATION, or both (e.g., 'ROWCOUNT,ROW_COL_VALIDATION')",
    )
    parser.add_argument(
        "--html-output",
        required=False,
        help="Optional HTML report path. Supports <datetime> token.",
    )
    parser.add_argument("--src-sheet", required=False, help="Optional source sheet name for Excel input.")
    parser.add_argument("--tgt-sheet", required=False, help="Optional target sheet name for Excel input.")
    parser.add_argument(
        "--sheet-mapping",
        required=False,
        help="Optional Excel sheet mapping, e.g. 'SRC1:TGT1,SRC2:TGT2'.",
    )
    parser.add_argument(
        "--chunk-size",
        required=False,
        type=int,
        default=1000,
        help="Number of data rows to process per chunk while loading files (default: 1000).",
    )
    parser.add_argument("--src-db", required=False, help="Source database alias (DB mode).")
    parser.add_argument("--tgt-db", required=False, help="Target database alias (DB mode).")
    parser.add_argument(
        "--src-db-alias",
        required=False,
        help="Source database alias (preferred flag; compatibility with --src-db).",
    )
    parser.add_argument(
        "--tgt-db-alias",
        required=False,
        help="Target database alias (preferred flag; compatibility with --tgt-db).",
    )
    parser.add_argument("--src-table", required=False, help="Source table name (DB mode).")
    parser.add_argument("--tgt-table", required=False, help="Target table name (DB mode, defaults to --src-table).")
    parser.add_argument("--src-query", required=False, help="Optional source SQL query (reserved for future use).")
    parser.add_argument("--tgt-query", required=False, help="Optional target SQL query (reserved for future use).")
    parser.add_argument("--src-schema", required=False, help="Optional source schema override (DB mode).")
    parser.add_argument("--tgt-schema", required=False, help="Optional target schema override (DB mode).")
    parser.add_argument(
        "--src-env",
        required=False,
        choices=sorted(ENVIRONMENTS),
        help="Source environment label.",
    )
    parser.add_argument(
        "--tgt-env",
        required=False,
        choices=sorted(ENVIRONMENTS),
        help="Target environment label.",
    )
    parser.add_argument("--env-map-config", required=False, help="Optional environment map configuration file.")
    parser.add_argument(
        "--allow-cross-env",
        action="store_true",
        help="Explicitly allow cross-environment comparisons when --src-env != --tgt-env.",
    )
    parser.add_argument(
        "--db-config",
        required=False,
        default=DEFAULT_DB_CONFIG,
        help="Path to database_config.ini (default: project root).",
    )
    parser.add_argument("--max-mismatches", required=False, type=int, default=None)
    parser.add_argument("--fail-fast", action="store_true")
    parser.add_argument("--strict-header-order", action="store_true")
    parser.add_argument("--key-columns", required=False)
    parser.add_argument(
        "--key-mode",
        required=False,
        choices=["AUTO", "PRIMARY_KEY", "COLUMNS", "GROUP_CANONICAL", "HASH"],
        default="AUTO",
    )
    parser.add_argument("--strict-key-uniqueness", action="store_true")
    parser.add_argument("--group-columns", required=False)
    parser.add_argument("--canonical-columns", required=False)
    parser.add_argument(
        "--canonical-agg",
        required=False,
        choices=["SUM", "COUNT", "MIN", "MAX", "AVG", "LISTAGG"],
    )
    parser.add_argument("--transform-config", required=False)
    parser.add_argument("--allow-transformations", action="store_true")
    parser.add_argument(
        "--report-format",
        required=False,
        choices=["html", "json", "both"],
        default="html",
    )
    parser.add_argument(
        "--log-level",
        required=False,
        choices=["DEBUG", "INFO", "WARN", "ERROR"],
        default="INFO",
    )

    args = parser.parse_args()

    if args.src_db_alias and not args.src_db:
        args.src_db = args.src_db_alias
    if args.tgt_db_alias and not args.tgt_db:
        args.tgt_db = args.tgt_db_alias

    if bool(args.src_kind) != bool(args.tgt_kind):
        parser.error("Both --src-kind and --tgt-kind must be provided together.")

    if not args.file_type and not args.src_kind:
        parser.error("Provide either --file-type or both --src-kind/--tgt-kind.")

    if args.file_type and args.src_kind and args.tgt_kind:
        if args.file_type == "EXCEL" and (
            args.src_kind not in FILE_KINDS or args.tgt_kind not in FILE_KINDS
        ):
            parser.error("--file-type EXCEL requires file kinds (csv/excel).")
        if args.file_type == "DB" and (
            args.src_kind not in DB_KINDS or args.tgt_kind not in DB_KINDS
        ):
            parser.error("--file-type DB requires database kinds.")

    if args.max_mismatches is not None and args.max_mismatches < 0:
        parser.error("--max-mismatches must be >= 0.")

    if args.src_env and args.tgt_env and args.src_env != args.tgt_env and not args.allow_cross_env:
        parser.error(
            "Cross-environment comparison requires --allow-cross-env when --src-env != --tgt-env."
        )

    return args


def _resolve_mode(args) -> str:
    src_kind = (getattr(args, "src_kind", None) or "").lower().strip()
    tgt_kind = (getattr(args, "tgt_kind", None) or "").lower().strip()

    if src_kind and tgt_kind:
        if src_kind in FILE_KINDS and tgt_kind in FILE_KINDS:
            return "FILE"
        if src_kind in DB_KINDS and tgt_kind in DB_KINDS:
            return "DB"
        if (src_kind in FILE_KINDS and tgt_kind in DB_KINDS) or (
            src_kind in DB_KINDS and tgt_kind in FILE_KINDS
        ):
            return "MIXED"
        return "UNKNOWN"

    file_type = (getattr(args, "file_type", None) or "").upper().strip()
    if file_type == "EXCEL":
        return "FILE"
    if file_type == "DB":
        return "DB"

    # Backward-compatibility fallback for tests and callers that monkeypatch
    # parse_args() and provide only selector flags.
    if getattr(args, "src_path", None) or getattr(args, "tgt_path", None):
        return "FILE"
    if (
        getattr(args, "src_db", None)
        or getattr(args, "tgt_db", None)
        or getattr(args, "src_db_alias", None)
        or getattr(args, "tgt_db_alias", None)
    ):
        return "DB"

    return "UNKNOWN"


def _normalized_validation_types(validation_type_text: str) -> list[str]:
    normalized: list[str] = []
    seen = set()
    for raw in (validation_type_text or "").split(","):
        token = raw.strip().upper()
        if not token:
            continue
        canonical = VALIDATION_TYPE_ALIASES.get(token)
        if canonical is None:
            print("FAILED")
            print(
                f"Reason: Unsupported validation type '{token}'. "
                "Supported: ROWCOUNT_VALIDATION, ROW_COL_VALIDATION, SCHEMA_VALIDATION"
            )
            sys.exit(1)
        if canonical not in seen:
            seen.add(canonical)
            normalized.append(canonical)

    if not normalized:
        print("FAILED")
        print("Reason: --validation-type is empty.")
        sys.exit(1)

    return normalized


def _to_internal_validation_types(validation_types: list[str]) -> list[str]:
    internal = []
    for vt in validation_types:
        if vt == "ROWCOUNT_VALIDATION":
            internal.append("ROWCOUNT")
        elif vt == "ROW_COL_VALIDATION":
            internal.append("ROW_COL_VALIDATION")
        elif vt == "SCHEMA_VALIDATION":
            print("FAILED")
            print(
                "Reason: SCHEMA_VALIDATION is part of the enterprise target contract "
                "but is not implemented in this CLI yet."
            )
            sys.exit(1)
    return internal


def _apply_mismatch_cap(mismatches, max_mismatches):
    if max_mismatches is None:
        return mismatches, None
    if len(mismatches) <= max_mismatches:
        return mismatches, None
    note = (
        f"Mismatch list truncated to {max_mismatches} item(s) "
        f"from {len(mismatches)} total due to --max-mismatches."
    )
    return mismatches[:max_mismatches], note


# ---------------------------------------------------------------------------
# Cell / row helpers
# ---------------------------------------------------------------------------

def normalize_cell(value):
    if value is None:
        return ""
    return str(value)


def trim_trailing_empty(values):
    result = list(values)
    while result and result[-1] == "":
        result.pop()
    return result


def iter_chunks(iterator, chunk_size):
    while True:
        chunk = list(islice(iterator, chunk_size))
        if not chunk:
            break
        yield chunk


def _compute_total_chunks(total_rows, chunk_size):
    if total_rows <= 0:
        return 0
    return (total_rows + chunk_size - 1) // chunk_size


def _count_csv_data_rows(path):
    with open(path, mode="r", encoding="utf-8-sig", newline="") as f:
        reader = csv.reader(f)
        return max(sum(1 for _ in reader) - 1, 0)


def _print_chunk_start(progress_label, total_chunks, chunk_size):
    print(
        f"[LOAD][{progress_label}] chunk-size={chunk_size}, "
        f"total-chunks={total_chunks}"
    )


def _print_chunk_progress(progress_label, chunk_num, total_chunks, chunk_len):
    print(
        f"[LOAD][{progress_label}] processing chunk "
        f"{chunk_num}/{total_chunks} ({chunk_len} row(s))"
    )


def _print_chunk_complete(progress_label, total_rows, total_chunks):
    print(
        f"[LOAD][{progress_label}] completed "
        f"{total_rows} row(s) across {total_chunks} chunk(s)"
    )


# ---------------------------------------------------------------------------
# File loaders
# ---------------------------------------------------------------------------

def load_csv(path, chunk_size=1000, progress_label="CSV"):
    total_rows = _count_csv_data_rows(path)
    total_chunks = _compute_total_chunks(total_rows, chunk_size)
    _print_chunk_start(progress_label, total_chunks, chunk_size)

    with open(path, mode="r", encoding="utf-8-sig", newline="") as f:
        reader = csv.reader(f)
        header_row = next(reader, None)
        if header_row is None:
            _print_chunk_complete(progress_label, 0, 0)
            return [], []

        header = trim_trailing_empty([normalize_cell(v) for v in header_row])
        rows = []
        for chunk_idx, chunk in enumerate(iter_chunks(reader, chunk_size), start=1):
            _print_chunk_progress(progress_label, chunk_idx, total_chunks, len(chunk))
            rows.extend(
                trim_trailing_empty([normalize_cell(v) for v in row]) for row in chunk
            )

    _print_chunk_complete(progress_label, len(rows), total_chunks)
    return header, rows


def load_excel(path, sheet_name=None, chunk_size=1000, progress_label="EXCEL"):
    try:
        from openpyxl import load_workbook
    except ImportError:
        print("FAILED")
        print(
            "Reason: openpyxl is required for .xlsx/.xlsm/.xltx files. "
            "Install it with: pip install openpyxl"
        )
        sys.exit(1)

    wb = load_workbook(path, read_only=True, data_only=True)
    try:
        ws = wb.active
        if sheet_name:
            if sheet_name not in wb.sheetnames:
                print("FAILED")
                print(f"Reason: Sheet '{sheet_name}' not found in file: {path}")
                sys.exit(1)
            ws = wb[sheet_name]

        max_row = getattr(ws, "max_row", 0) or 0
        total_rows = max(max_row - 1, 0)
        total_chunks = _compute_total_chunks(total_rows, chunk_size)
        _print_chunk_start(progress_label, total_chunks, chunk_size)

        row_iter = iter(ws.iter_rows(values_only=True))
        header_row = next(row_iter, None)
        if header_row is None:
            _print_chunk_complete(progress_label, 0, 0)
            return [], []

        header = trim_trailing_empty([normalize_cell(v) for v in header_row])
        rows = []
        for chunk_idx, chunk in enumerate(iter_chunks(row_iter, chunk_size), start=1):
            _print_chunk_progress(progress_label, chunk_idx, total_chunks, len(chunk))
            rows.extend(
                trim_trailing_empty([normalize_cell(v) for v in row]) for row in chunk
            )

        _print_chunk_complete(progress_label, len(rows), total_chunks)
        return header, rows
    finally:
        wb.close()


def load_table(path, sheet_name=None, chunk_size=1000, progress_label=None):
    ext = os.path.splitext(path)[1].lower()
    if ext == ".csv":
        if sheet_name:
            print("FAILED")
            print(
                f"Reason: --src-sheet/--tgt-sheet requires Excel input, got CSV: {path}"
            )
            sys.exit(1)
        label = progress_label or f"CSV:{os.path.basename(path)}"
        return load_csv(path, chunk_size=chunk_size, progress_label=label)
    if ext in {".xlsx", ".xlsm", ".xltx"}:
        label = progress_label or f"XLSX:{sheet_name or '<active>'}"
        try:
            return load_excel(
                path,
                sheet_name=sheet_name,
                chunk_size=chunk_size,
                progress_label=label,
            )
        except TypeError:
            return load_excel(path, sheet_name=sheet_name)
    print("FAILED")
    print(
        f"Reason: Unsupported file extension '{ext}'. "
        "Supported: .csv, .xlsx, .xlsm, .xltx"
    )
    sys.exit(1)


def is_excel_path(path):
    return os.path.splitext(path)[1].lower() in {".xlsx", ".xlsm", ".xltx"}


def parse_sheet_mapping(mapping_text):
    pairs = []
    for token in (mapping_text or "").split(","):
        item = token.strip()
        if not item:
            continue
        if ":" not in item:
            print("FAILED")
            print("Reason: Invalid --sheet-mapping format. Use 'SRC1:TGT1,SRC2:TGT2'.")
            sys.exit(1)
        src_sheet, tgt_sheet = item.split(":", 1)
        src_sheet = src_sheet.strip()
        tgt_sheet = tgt_sheet.strip()
        if not src_sheet or not tgt_sheet:
            print("FAILED")
            print(
                "Reason: Invalid --sheet-mapping pair. "
                "Both source and target sheet names are required."
            )
            sys.exit(1)
        pairs.append((src_sheet, tgt_sheet))

    if not pairs:
        print("FAILED")
        print("Reason: --sheet-mapping is empty. Use format 'SRC1:TGT1,SRC2:TGT2'.")
        sys.exit(1)

    return pairs


# ---------------------------------------------------------------------------
# Output path resolution
# ---------------------------------------------------------------------------

def resolve_output_path(path):
    if not path:
        return None
    ts = datetime.now().strftime("%Y%m%d_%H%M%S")
    resolved = path.replace("<datetime>", ts).replace("<datetime<", ts)
    resolved = os.path.normpath(resolved)
    out_dir = os.path.dirname(resolved)
    if out_dir:
        os.makedirs(out_dir, exist_ok=True)
    return resolved


# ---------------------------------------------------------------------------
# DB-mode validation
# ---------------------------------------------------------------------------

def _run_db_validation(args) -> None:
    """Handle the DB file-type branch of main()."""
    # Backward-compatible import order:
    # 1) legacy top-level module (tests monkeypatch this path)
    # 2) package shim fallback
    try:
        import dvg_db as _dvg_db
    except ImportError:
        from data_validation_gini import dvg_db as _dvg_db

    chunk_size = getattr(args, "chunk_size", 1000)
    src_kind = (getattr(args, "src_kind", None) or "").lower().strip()
    tgt_kind = (getattr(args, "tgt_kind", None) or "").lower().strip()

    if src_kind and src_kind not in SUPPORTED_DB_KINDS_FOR_CLI:
        print("FAILED")
        print(
            f"Reason: --src-kind {src_kind} is declared in the CLI contract but is "
            "not implemented yet. Implemented DB kinds: sqlite, postgresql, mysql."
        )
        sys.exit(1)

    if tgt_kind and tgt_kind not in SUPPORTED_DB_KINDS_FOR_CLI:
        print("FAILED")
        print(
            f"Reason: --tgt-kind {tgt_kind} is declared in the CLI contract but is "
            "not implemented yet. Implemented DB kinds: sqlite, postgresql, mysql."
        )
        sys.exit(1)

    for flag, name in (
        ("--src-db", args.src_db),
        ("--tgt-db", args.tgt_db),
        ("--src-table", args.src_table),
    ):
        if not name:
            print("FAILED")
            print(f"Reason: {flag} is required when --file-type DB is used.")
            sys.exit(1)

    tgt_table = args.tgt_table or args.src_table
    db_config = args.db_config

    validation_types = _to_internal_validation_types(
        _normalized_validation_types(args.validation_type)
    )

    db_loader = DbTableLoader(load_db_table_func=_dvg_db.load_db_table)
    try:
        src_dataset = db_loader.load(
            db_alias=args.src_db,
            table_name=args.src_table,
            config_path=db_config,
            chunk_size=chunk_size,
            progress_label=f"SRC:{args.src_db}:{args.src_table}",
        )
        tgt_dataset = db_loader.load(
            db_alias=args.tgt_db,
            table_name=tgt_table,
            config_path=db_config,
            chunk_size=chunk_size,
            progress_label=f"TGT:{args.tgt_db}:{tgt_table}",
        )
    except Exception as exc:
        print("FAILED")
        print(f"Reason: Database load error – {exc}")
        sys.exit(1)

    label = f"{args.src_db}.{args.src_table}->{args.tgt_db}.{tgt_table}"
    service = _build_validation_service()
    bundle = service.validate_many(
        pairs=[(label, src_dataset, tgt_dataset)],
        validation_types=validation_types,
        tag_mismatch_reasons=False,
    )

    all_passed = bundle.passed
    all_mismatches, truncation_note = _apply_mismatch_cap(
        bundle.mismatches,
        getattr(args, "max_mismatches", None),
    )
    reason = bundle.reason
    if truncation_note:
        reason = f"{reason} | {truncation_note}"
    print("PASSED" if all_passed else "FAILED")
    print(f"Reason: {reason}")

    if not all_passed and all_mismatches:
        preview = all_mismatches[:10]
        print("Mismatch preview (first 10):")
        for item in preview:
            print(
                f"  - type={item['type']} row={item['row']} column={item['column']} "
                f"src='{item['src']}' tgt='{item['tgt']}' reason='{item['reason']}'"
            )

    if args.html_output:
        out_path = resolve_output_path(args.html_output)
        src_label = f"{args.src_db}:{args.src_table}"
        tgt_label = f"{args.tgt_db}:{tgt_table}"
        write_html_report(
            path=out_path,
            passed=all_passed,
            summary=reason,
            src_path=src_label,
            tgt_path=tgt_label,
            validation_type=args.validation_type,
            mismatches=all_mismatches,
            src_rows_count=bundle.src_rows_count,
            tgt_rows_count=bundle.tgt_rows_count,
        )
        print(f"HTML report: {out_path}")

    sys.exit(0 if all_passed else 1)


# ---------------------------------------------------------------------------
# Entry point
# ---------------------------------------------------------------------------

def main():
    args = parse_args()
    chunk_size = getattr(args, "chunk_size", 1000)
    mode = _resolve_mode(args)

    if chunk_size <= 0:
        print("FAILED")
        print("Reason: --chunk-size must be a positive integer.")
        sys.exit(1)

    if mode == "MIXED":
        print("FAILED")
        print(
            "Reason: Mixed source/target kind validation in one CLI run is not implemented yet. "
            "Use separate import/export and validation workflows for file-to-db or db-to-file flows today."
        )
        sys.exit(1)

    if mode == "UNKNOWN":
        print("FAILED")
        print("Reason: Unable to determine run mode from --file-type or --src-kind/--tgt-kind.")
        sys.exit(1)

    if mode == "DB":
        _run_db_validation(args)

    if not os.path.exists(args.src_path or ""):
        if not args.src_path:
            print("FAILED")
            print("Reason: --src-path is required when --file-type EXCEL is used.")
            sys.exit(1)
        print("FAILED")
        print(f"Reason: Source file not found: {args.src_path}")
        sys.exit(1)
    if not os.path.exists(args.tgt_path or ""):
        if not args.tgt_path:
            print("FAILED")
            print("Reason: --tgt-path is required when --file-type EXCEL is used.")
            sys.exit(1)
        print("FAILED")
        print(f"Reason: Target file not found: {args.tgt_path}")
        sys.exit(1)

    if args.sheet_mapping and (
        not is_excel_path(args.src_path) or not is_excel_path(args.tgt_path)
    ):
        print("FAILED")
        print(
            "Reason: --sheet-mapping is supported only for Excel files "
            "(.xlsx/.xlsm/.xltx)."
        )
        sys.exit(1)

    if args.sheet_mapping:
        sheet_pairs = parse_sheet_mapping(args.sheet_mapping)
    else:
        sheet_pairs = [(args.src_sheet, args.tgt_sheet)]

    validation_types = _to_internal_validation_types(
        _normalized_validation_types(args.validation_type)
    )

    file_loader = FileTableLoader(load_table_func=load_table)
    service = _build_validation_service()
    pairs = []

    for src_sheet_name, tgt_sheet_name in sheet_pairs:
        src_dataset = file_loader.load(
            args.src_path,
            sheet_name=src_sheet_name,
            chunk_size=chunk_size,
            progress_label=f"SRC:{src_sheet_name or '<active>'}",
        )
        tgt_dataset = file_loader.load(
            args.tgt_path,
            sheet_name=tgt_sheet_name,
            chunk_size=chunk_size,
            progress_label=f"TGT:{tgt_sheet_name or '<active>'}",
        )

        if src_sheet_name or tgt_sheet_name:
            sheet_label = (
                f"{src_sheet_name or '<active>'}->{tgt_sheet_name or '<active>'}"
            )
        else:
            sheet_label = "<active_sheet>"

        pairs.append((sheet_label, src_dataset, tgt_dataset))

    bundle = service.validate_many(
        pairs=pairs,
        validation_types=validation_types,
        tag_mismatch_reasons=True,
    )

    passed = bundle.passed
    reason = bundle.reason
    all_mismatches, truncation_note = _apply_mismatch_cap(
        bundle.mismatches,
        getattr(args, "max_mismatches", None),
    )
    if truncation_note:
        reason = f"{reason} | {truncation_note}"

    print("PASSED" if passed else "FAILED")
    print(f"Reason: {reason}")

    if not passed and all_mismatches:
        preview = all_mismatches[:10]
        print("Mismatch preview (first 10):")
        for item in preview:
            print(
                f"  - type={item['type']} row={item['row']} column={item['column']} "
                f"src='{item['src']}' tgt='{item['tgt']}' reason='{item['reason']}'"
            )

    if args.html_output:
        out_path = resolve_output_path(args.html_output)
        write_html_report(
            path=out_path,
            passed=passed,
            summary=reason,
            src_path=args.src_path,
            tgt_path=args.tgt_path,
            validation_type=args.validation_type,
            mismatches=all_mismatches,
            src_rows_count=bundle.src_rows_count,
            tgt_rows_count=bundle.tgt_rows_count,
        )
        print(f"HTML report: {out_path}")

    sys.exit(0 if passed else 1)


if __name__ == "__main__":  # pragma: no cover
    main()
