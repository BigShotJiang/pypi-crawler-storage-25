from __future__ import annotations

from dataclasses import dataclass
from typing import Callable

from .models import Dataset, ValidationResult


@dataclass
class RowCountStrategy:
    comparator: Callable[[list[list[str]], list[list[str]]], tuple[bool, str, list[dict]]]

    def validate(self, src: Dataset, tgt: Dataset) -> ValidationResult:
        passed, reason, mismatches = self.comparator(src.rows, tgt.rows)
        return ValidationResult(passed=passed, reason=reason, mismatches=mismatches)


@dataclass
class RowColumnStrategy:
    comparator: Callable[[list[str], list[list[str]], list[str], list[list[str]]], tuple[bool, str, list[dict]]]

    def validate(self, src: Dataset, tgt: Dataset) -> ValidationResult:
        passed, reason, mismatches = self.comparator(
            src.header,
            src.rows,
            tgt.header,
            tgt.rows,
        )
        return ValidationResult(passed=passed, reason=reason, mismatches=mismatches)
