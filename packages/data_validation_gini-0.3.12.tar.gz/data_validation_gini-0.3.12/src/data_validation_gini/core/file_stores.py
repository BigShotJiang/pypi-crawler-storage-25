"""
file_stores.py – Shared file reader/writer classes for INI and JSON files.

Moved to core/ as a shared infrastructure component used by the CLI,
database layer, and reporting helpers.
"""
from __future__ import annotations

import configparser
import json
from pathlib import Path
from typing import Any


class IniConfigStore:
    """Read and write INI configuration files using ConfigParser."""

    def __init__(self, path: str | Path):
        self.path = Path(path)

    def read(self) -> configparser.ConfigParser:
        if not self.path.exists():
            raise FileNotFoundError(f"INI file not found: {self.path}")

        config = configparser.ConfigParser()
        config.read(str(self.path))
        return config

    def write(self, config: configparser.ConfigParser) -> None:
        self.path.parent.mkdir(parents=True, exist_ok=True)
        with self.path.open("w", encoding="utf-8") as handle:
            config.write(handle)

    def read_section(self, section: str) -> dict[str, str]:
        config = self.read()
        if not config.has_section(section):
            raise ValueError(
                f"Section '{section}' not found in INI file: {self.path}"
            )
        return dict(config[section])


class JsonFileStore:
    """Read and write JSON files with UTF-8 encoding."""

    def __init__(self, path: str | Path):
        self.path = Path(path)

    def read(self, default: Any | None = None) -> Any:
        if not self.path.exists():
            if default is not None:
                return default
            raise FileNotFoundError(f"JSON file not found: {self.path}")

        with self.path.open("r", encoding="utf-8") as handle:
            return json.load(handle)

    def write(self, data: Any, indent: int = 2) -> None:
        self.path.parent.mkdir(parents=True, exist_ok=True)
        with self.path.open("w", encoding="utf-8") as handle:
            json.dump(data, handle, ensure_ascii=False, indent=indent)
            handle.write("\n")
