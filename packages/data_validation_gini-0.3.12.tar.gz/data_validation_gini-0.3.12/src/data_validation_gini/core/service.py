from __future__ import annotations

from dataclasses import dataclass

from .models import Dataset, ValidationBundleResult


@dataclass
class ValidationService:
    rowcount_strategy: object
    rowcol_strategy: object

    def _validate_pair(
        self,
        src: Dataset,
        tgt: Dataset,
        label: str,
        validation_types: list[str],
        tag_mismatch_reasons: bool,
    ) -> tuple[bool, list[str], list[dict]]:
        all_passed = True
        reasons: list[str] = []
        mismatches: list[dict] = []

        if "ROWCOUNT" in validation_types:
            result = self.rowcount_strategy.validate(src, tgt)
            all_passed = all_passed and result.passed
            reasons.append(f"[{label}][ROWCOUNT] {result.reason}")
            if tag_mismatch_reasons:
                for item in result.mismatches:
                    tagged = dict(item)
                    tagged["reason"] = f"[{label}] {item.get('reason', '')}"
                    mismatches.append(tagged)
            else:
                mismatches.extend(result.mismatches)

        if "ROW_COL_VALIDATION" in validation_types:
            result = self.rowcol_strategy.validate(src, tgt)
            all_passed = all_passed and result.passed
            reasons.append(f"[{label}][ROW_COL_VALIDATION] {result.reason}")
            if tag_mismatch_reasons:
                for item in result.mismatches:
                    tagged = dict(item)
                    tagged["reason"] = f"[{label}] {item.get('reason', '')}"
                    mismatches.append(tagged)
            else:
                mismatches.extend(result.mismatches)

        return all_passed, reasons, mismatches

    def validate_many(
        self,
        pairs: list[tuple[str, Dataset, Dataset]],
        validation_types: list[str],
        tag_mismatch_reasons: bool,
    ) -> ValidationBundleResult:
        all_passed = True
        all_reasons: list[str] = []
        all_mismatches: list[dict] = []
        total_src_rows = 0
        total_tgt_rows = 0

        for label, src, tgt in pairs:
            total_src_rows += len(src.rows)
            total_tgt_rows += len(tgt.rows)
            pair_passed, pair_reasons, pair_mismatches = self._validate_pair(
                src=src,
                tgt=tgt,
                label=label,
                validation_types=validation_types,
                tag_mismatch_reasons=tag_mismatch_reasons,
            )
            all_passed = all_passed and pair_passed
            all_reasons.extend(pair_reasons)
            all_mismatches.extend(pair_mismatches)

        return ValidationBundleResult(
            passed=all_passed,
            reason=" | ".join(all_reasons),
            mismatches=all_mismatches,
            src_rows_count=total_src_rows,
            tgt_rows_count=total_tgt_rows,
        )
