"""
report.py – HTML report generation for Data Validation Gini.

Moved to core/ as the canonical report module.
"""
import html
from datetime import datetime


DEFAULT_LINKEDIN_URL = "https://www.linkedin.com/in/shankonduru"
DEFAULT_REPO_URL = "https://github.com/ShanKonduru/data-validation-gini"


def _safe_int(value):
    try:
        return int(value)
    except (TypeError, ValueError):
        return 0


def _normalize_column_name(value, fallback="unknown"):
    text = str(value or "").strip()
    if not text:
        text = fallback
    return text.replace(" ", "_")


def _column_pair_for_mismatch(item):
    mismatch_type = str(item.get("type", ""))
    column_value = _normalize_column_name(item.get("column", ""))

    if mismatch_type == "HEADER_NAME":
        src_name = _normalize_column_name(item.get("src", ""), fallback=column_value)
        tgt_name = _normalize_column_name(item.get("tgt", ""), fallback=column_value)
    else:
        src_name = column_value
        tgt_name = column_value

    return f"src_{src_name}", f"tgt_{tgt_name}"


def _group_mismatches(mismatches):
    grouped = {}
    for item in mismatches:
        row_type_raw = str(item.get("type", ""))
        row_num_raw = str(item.get("row", ""))
        reason_raw = str(item.get("reason", ""))
        group_key = (row_type_raw, row_num_raw, reason_raw)

        if group_key not in grouped:
            grouped[group_key] = {
                "columns": [],
                "src_values": [],
                "tgt_values": [],
            }

        src_col, tgt_col = _column_pair_for_mismatch(item)
        column_pair = f"{src_col},{tgt_col}"
        if column_pair not in grouped[group_key]["columns"]:
            grouped[group_key]["columns"].append(column_pair)

        src_val_raw = str(item.get("src", ""))
        tgt_val_raw = str(item.get("tgt", ""))
        src_pair = f"{src_col}={src_val_raw}"
        tgt_pair = f"{tgt_col}={tgt_val_raw}"
        if src_pair not in grouped[group_key]["src_values"]:
            grouped[group_key]["src_values"].append(src_pair)
        if tgt_pair not in grouped[group_key]["tgt_values"]:
            grouped[group_key]["tgt_values"].append(tgt_pair)

    return grouped


def build_report_metrics(src_rows_count, tgt_rows_count, mismatches):
    grouped = _group_mismatches(mismatches)
    failed_rows = set()
    src_only_rows = set()
    tgt_only_rows = set()

    for row_type_raw, row_num_raw, _reason_raw in grouped.keys():
        row_num = _safe_int(row_num_raw)
        if row_num <= 1:
            continue

        if row_type_raw in {"CELL", "SRC_ONLY", "TGT_ONLY"}:
            failed_rows.add(row_num)
        if row_type_raw == "SRC_ONLY":
            src_only_rows.add(row_num)
        if row_type_raw == "TGT_ONLY":
            tgt_only_rows.add(row_num)

    comparison_rows = max(src_rows_count, tgt_rows_count)
    failed_count = len(failed_rows)
    passed_count = max(comparison_rows - failed_count, 0)

    if comparison_rows > 0:
        pass_rate = (passed_count / comparison_rows) * 100.0
        failed_rate = (failed_count / comparison_rows) * 100.0
    else:
        pass_rate = 100.0
        failed_rate = 0.0

    return {
        "src_count": src_rows_count,
        "tgt_count": tgt_rows_count,
        "passed": passed_count,
        "failed": failed_count,
        "pass_rate": pass_rate,
        "failed_rate": failed_rate,
        "src_only": len(src_only_rows),
        "tgt_only": len(tgt_only_rows),
    }


def _render_mismatch_rows(mismatches):
    if not mismatches:
        return "<tr><td colspan='6'>No mismatches</td></tr>"

    grouped = _group_mismatches(mismatches)
    rows = []
    ordered_keys = sorted(grouped.keys(), key=lambda x: (_safe_int(x[1]), x[0], x[2]))

    for row_type_raw, row_num_raw, reason_raw in ordered_keys:
        grouped_item = grouped[(row_type_raw, row_num_raw, reason_raw)]
        row_type = html.escape(row_type_raw)
        row_num = html.escape(row_num_raw)

        if row_type_raw in ("SRC_ONLY", "TGT_ONLY"):
            column_pair = "—"
        else:
            unique_cols = set()
            for pair in grouped_item["columns"]:
                for col in pair.split(","):
                    col_clean = col.strip()
                    if col_clean.startswith("src_"):
                        col_clean = col_clean[4:]
                    elif col_clean.startswith("tgt_"):
                        col_clean = col_clean[4:]
                    if col_clean:
                        unique_cols.add(col_clean)
            column_pair = html.escape(",".join(sorted(unique_cols)))

        src_val = html.escape(" | ".join(grouped_item["src_values"]))
        tgt_val = html.escape(" | ".join(grouped_item["tgt_values"]))
        reason = html.escape(reason_raw)
        rows.append(
            "<tr>"
            f"<td>{row_type}</td>"
            f"<td>{row_num}</td>"
            f"<td>{column_pair}</td>"
            f"<td>{src_val}</td>"
            f"<td>{tgt_val}</td>"
            f"<td>{reason}</td>"
            "</tr>"
        )

    return "".join(rows)


def generate_html_report(
    passed,
    summary,
    src_path,
    tgt_path,
    validation_type,
    mismatches,
    metrics,
    linkedin_url=DEFAULT_LINKEDIN_URL,
    repo_url=DEFAULT_REPO_URL,
):
    status_text = "PASSED" if passed else "FAILED"
    status_color = "#0f5132" if passed else "#7f1d1d"
    status_bg = "#dcfce7" if passed else "#fee2e2"
    status_border = "#14532d" if passed else "#991b1b"

    mismatch_rows = _render_mismatch_rows(mismatches)

    return f"""<!doctype html>
<html lang=\"en\">
<head>
  <meta charset=\"utf-8\" />
  <meta name=\"viewport\" content=\"width=device-width,initial-scale=1\" />
  <title>DVG Validation Report</title>
  <style>
    :root {{
      --bg: #f4f7fb;
      --surface: #ffffff;
      --line: #d9e2ec;
      --text: #0f172a;
      --muted: #475569;
      --brand: #0b3b66;
    }}

    * {{ box-sizing: border-box; }}

    body {{
      margin: 0;
      font-family: "Segoe UI", Tahoma, sans-serif;
      color: var(--text);
      background: radial-gradient(circle at top right, #d9ebff, var(--bg) 35%);
      min-height: 100vh;
      display: flex;
      flex-direction: column;
    }}

    .page {{
      max-width: 1180px;
      width: 100%;
      margin: 0 auto;
      padding: 24px;
      flex: 1;
    }}

    .brand-header {{
      background: linear-gradient(130deg, var(--brand), #155a96);
      color: #fff;
      border-radius: 14px;
      padding: 20px;
      box-shadow: 0 8px 24px rgba(17, 24, 39, 0.12);
      margin-bottom: 18px;
    }}

    .brand-title {{ margin: 0; font-size: 30px; letter-spacing: 0.4px; }}
    .brand-sub {{ margin: 6px 0 0 0; opacity: 0.92; }}

    .status-pill {{
      display: inline-block;
      margin-top: 14px;
      padding: 8px 14px;
      border-radius: 999px;
      font-weight: 700;
      color: {status_color};
      background: {status_bg};
      border: 1px solid {status_border};
    }}

    .kpi-grid {{
      display: grid;
      grid-template-columns: repeat(auto-fit, minmax(180px, 1fr));
      gap: 12px;
      margin-bottom: 16px;
    }}

    .kpi-card {{
      background: var(--surface);
      border: 1px solid var(--line);
      border-radius: 12px;
      padding: 12px 14px;
      box-shadow: 0 4px 14px rgba(15, 23, 42, 0.05);
    }}

    .kpi-card.success {{
      background: #f0fdf4;
      border-color: #86efac;
      box-shadow: 0 4px 14px rgba(34, 197, 94, 0.15);
    }}

    .kpi-card.danger {{
      background: #fef2f2;
      border-color: #fca5a5;
      box-shadow: 0 4px 14px rgba(239, 68, 68, 0.15);
    }}

    .kpi-label {{
      color: var(--muted);
      font-size: 12px;
      text-transform: uppercase;
      letter-spacing: 0.4px;
      margin-bottom: 6px;
    }}

    .kpi-card.success .kpi-label {{
      color: #15803d;
    }}

    .kpi-card.danger .kpi-label {{
      color: #991b1b;
    }}

    .kpi-value {{ font-size: 24px; font-weight: 700; line-height: 1; }}

    .kpi-card.success .kpi-value {{
      color: #15803d;
    }}

    .kpi-card.danger .kpi-value {{
      color: #dc2626;
    }}

    .card {{
      background: var(--surface);
      border: 1px solid var(--line);
      border-radius: 12px;
      padding: 16px;
      margin-bottom: 16px;
    }}

    .meta-grid {{
      display: grid;
      grid-template-columns: repeat(auto-fit, minmax(280px, 1fr));
      gap: 8px 16px;
      color: var(--muted);
    }}

    .table-wrap {{
      width: 100%;
      overflow-x: auto;
      overflow-y: auto;
      max-height: 60vh;
      border: 1px solid var(--line);
      border-radius: 10px;
    }}

    table {{ width: max-content; min-width: 1400px; border-collapse: collapse; font-size: 13px; }}
    th, td {{ border: 1px solid #cfd8e3; padding: 8px; text-align: left; vertical-align: top; }}
    th {{ background: #eef4fb; position: sticky; top: 0; z-index: 1; }}
    .filters th {{ background: #f8fafc; padding: 6px; position: sticky; top: 38px; z-index: 1; }}
    .filters input {{ width: 100%; border: 1px solid #cbd5e1; border-radius: 6px; padding: 6px 8px; font-size: 12px; }}

    .footer {{
      background: #0b3b66;
      color: #e2ecf7;
      padding: 16px 24px;
      text-align: center;
      font-size: 14px;
    }}

    .footer a {{ color: #f8bf3b; text-decoration: none; font-weight: 600; }}
    .footer a:hover {{ text-decoration: underline; }}

    @media (max-width: 720px) {{
      .brand-title {{ font-size: 24px; }}
      .filters th {{ top: 74px; }}
    }}
  </style>
</head>
<body>
  <main class=\"page\">
    <header class=\"brand-header\">
      <h1 class=\"brand-title\">DVG Data Validation Report</h1>
      <p class=\"brand-sub\">Data Validation Gini | Reconciliation and mismatch diagnostics</p>
      <span class=\"status-pill\">{status_text}</span>
    </header>

    <section class=\"kpi-grid\">
      <article class=\"kpi-card\"><div class=\"kpi-label\">SRC Count</div><div class=\"kpi-value\">{metrics['src_count']}</div></article>
      <article class=\"kpi-card\"><div class=\"kpi-label\">TGT Count</div><div class=\"kpi-value\">{metrics['tgt_count']}</div></article>
      <article class=\"kpi-card success\"><div class=\"kpi-label\">PASSED</div><div class=\"kpi-value\">{metrics['passed']}</div></article>
      <article class=\"kpi-card danger\"><div class=\"kpi-label\">FAILED</div><div class=\"kpi-value\">{metrics['failed']}</div></article>
      <article class=\"kpi-card success\"><div class=\"kpi-label\">Pass Rate</div><div class=\"kpi-value\">{metrics['pass_rate']:.2f}%</div></article>
      <article class=\"kpi-card danger\"><div class=\"kpi-label\">Failed Rate</div><div class=\"kpi-value\">{metrics['failed_rate']:.2f}%</div></article>
      <article class=\"kpi-card\"><div class=\"kpi-label\">SRC Only</div><div class=\"kpi-value\">{metrics['src_only']}</div></article>
      <article class=\"kpi-card\"><div class=\"kpi-label\">TGT Only</div><div class=\"kpi-value\">{metrics['tgt_only']}</div></article>
    </section>

    <section class=\"card\">
      <div class=\"meta-grid\">
        <div><strong>Validation Type:</strong> {html.escape(validation_type)}</div>
        <div><strong>Generated:</strong> {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}</div>
        <div><strong>Source:</strong> {html.escape(src_path)}</div>
        <div><strong>Target:</strong> {html.escape(tgt_path)}</div>
      </div>
      <p><strong>Summary:</strong> {html.escape(summary)}</p>
    </section>

    <section class=\"card\">
      <h2 style=\"margin-top:0;\">Mismatch Details</h2>
      <p style=\"color: var(--muted); margin-top: -4px;\">Use the filter boxes in each column to narrow results.</p>
      <div class=\"table-wrap\">
        <table id=\"mismatchTable\">
          <thead>
            <tr>
              <th>Type</th>
              <th>Row</th>
              <th>Mismatching Columns</th>
              <th>Source</th>
              <th>Target</th>
              <th>Reason</th>
            </tr>
            <tr class=\"filters\">
              <th><input type=\"text\" oninput=\"filterTable(0, this.value)\" placeholder=\"Filter type\" /></th>
              <th><input type=\"text\" oninput=\"filterTable(1, this.value)\" placeholder=\"Filter row\" /></th>
              <th><input type=\"text\" oninput=\"filterTable(2, this.value)\" placeholder=\"Filter mismatching columns\" /></th>
              <th><input type=\"text\" oninput=\"filterTable(3, this.value)\" placeholder=\"Filter source\" /></th>
              <th><input type=\"text\" oninput=\"filterTable(4, this.value)\" placeholder=\"Filter target\" /></th>
              <th><input type=\"text\" oninput=\"filterTable(5, this.value)\" placeholder=\"Filter reason\" /></th>
            </tr>
          </thead>
          <tbody>
            {mismatch_rows}
          </tbody>
        </table>
      </div>
    </section>
  </main>

  <footer class=\"footer\">
    <div>Designed and developed by <a href=\"{html.escape(linkedin_url)}\" target=\"_blank\" rel=\"noopener noreferrer\">ShanKonduru</a></div>
    <div>This project is available at <a href=\"{html.escape(repo_url)}\" target=\"_blank\" rel=\"noopener noreferrer\">GitHub</a></div>
  </footer>

  <script>
    const activeFilters = ["", "", "", "", "", ""];

    function filterTable(columnIndex, searchValue) {{
      activeFilters[columnIndex] = (searchValue || "").toLowerCase();
      const table = document.getElementById("mismatchTable");
      const rows = table.tBodies[0].rows;

      for (let i = 0; i < rows.length; i += 1) {{
        let showRow = true;

        for (let col = 0; col < activeFilters.length; col += 1) {{
          const term = activeFilters[col];
          if (!term) {{
            continue;
          }}

          const cell = rows[i].cells[col];
          const text = (cell ? cell.textContent : "").toLowerCase();
          if (text.indexOf(term) == -1) {{
            showRow = false;
            break;
          }}
        }}

        rows[i].style.display = showRow ? "" : "none";
      }}
    }}
  </script>
</body>
</html>
"""


def write_html_report(
    path,
    passed,
    summary,
    src_path,
    tgt_path,
    validation_type,
    mismatches,
    src_rows_count,
    tgt_rows_count,
    linkedin_url=DEFAULT_LINKEDIN_URL,
    repo_url=DEFAULT_REPO_URL,
):
    metrics = build_report_metrics(src_rows_count, tgt_rows_count, mismatches)
    report_html = generate_html_report(
        passed=passed,
        summary=summary,
        src_path=src_path,
        tgt_path=tgt_path,
        validation_type=validation_type,
        mismatches=mismatches,
        metrics=metrics,
        linkedin_url=linkedin_url,
        repo_url=repo_url,
    )

    with open(path, mode="w", encoding="utf-8") as report_file:
        report_file.write(report_html)
