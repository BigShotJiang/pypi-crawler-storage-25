"""
comparators.py – Pure comparison functions for row-count and row/column validation.

These functions implement the comparison logic that drives RowCountStrategy
and RowColumnStrategy.  They are intentionally free of I/O and CLI concerns
so they can be unit-tested in isolation.
"""
from __future__ import annotations


# ---------------------------------------------------------------------------
# Row-count comparator
# ---------------------------------------------------------------------------

def compare_rowcount(
    src_rows: list[list[str]],
    tgt_rows: list[list[str]],
) -> tuple[bool, str, list[dict]]:
    """Return (passed, reason, mismatches) comparing two row-count totals."""
    src_count = len(src_rows)
    tgt_count = len(tgt_rows)
    passed = src_count == tgt_count
    if passed:
        reason = f"Row counts match: src={src_count}, tgt={tgt_count}."
    else:
        reason = f"Row count mismatch: src={src_count}, tgt={tgt_count}."
    return passed, reason, []


# ---------------------------------------------------------------------------
# Cell-equality helper
# ---------------------------------------------------------------------------

def _values_are_equal(src_val: str, tgt_val: str) -> bool:
    """
    Compare two cell values for equality.

    If both values parse as floats compare numerically (handles decimal
    precision differences such as 130522.40 == 130522.4).  Otherwise fall
    back to string comparison.
    """
    src_str = str(src_val).strip()
    tgt_str = str(tgt_val).strip()

    try:
        return float(src_str) == float(tgt_str)
    except (ValueError, TypeError):
        return src_str == tgt_str


# ---------------------------------------------------------------------------
# Row/column comparator
# ---------------------------------------------------------------------------

def _classify_mismatch(src_val: str, tgt_val: str) -> tuple[str, str]:
    src_blank = str(src_val).strip() == ""
    tgt_blank = str(tgt_val).strip() == ""
    if (not src_blank) and tgt_blank:
        return "SRC_ONLY", "Source-only value (target missing or blank)"
    if src_blank and (not tgt_blank):
        return "TGT_ONLY", "Target-only value (source missing or blank)"
    return "CELL", "Cell value mismatch"


def _build_row_map(
    header: list[str],
    rows: list[list[str]],
) -> tuple[dict[str, tuple[int, list[str]]], int | None]:
    preferred_keys = ["employee_id", "id", "emp_id", "record_id", "pk"]
    lowered = [str(h).strip().lower() for h in header]

    key_idx: int | None = None
    for candidate in preferred_keys:
        if candidate in lowered:
            key_idx = lowered.index(candidate)
            break

    if key_idx is None and header:
        key_idx = 0

    row_map: dict[str, tuple[int, list[str]]] = {}
    if key_idx is None:
        return row_map, key_idx

    for row_idx, row in enumerate(rows):
        key_val = row[key_idx] if key_idx < len(row) else ""
        key_text = str(key_val).strip()
        if key_text == "":
            key_text = f"__row_{row_idx + 2}"
        row_map[key_text] = (row_idx, row)

    return row_map, key_idx


def compare_row_col(
    src_header: list[str],
    src_rows: list[list[str]],
    tgt_header: list[str],
    tgt_rows: list[list[str]],
) -> tuple[bool, str, list[dict]]:
    """Return (passed, reason, mismatches) for a full row/column comparison."""
    mismatches: list[dict] = []

    if len(src_header) != len(tgt_header):
        mismatches.append(
            {
                "type": "HEADER_LENGTH",
                "row": 1,
                "column": "<HEADER>",
                "src": str(len(src_header)),
                "tgt": str(len(tgt_header)),
                "reason": "Header column count mismatch",
            }
        )

    header_limit = max(len(src_header), len(tgt_header))
    for col_idx in range(header_limit):
        src_col = src_header[col_idx] if col_idx < len(src_header) else ""
        tgt_col = tgt_header[col_idx] if col_idx < len(tgt_header) else ""
        if src_col != tgt_col:
            mismatches.append(
                {
                    "type": "HEADER_NAME",
                    "row": 1,
                    "column": f"col_{col_idx + 1}",
                    "src": src_col,
                    "tgt": tgt_col,
                    "reason": "Header name mismatch",
                }
            )

    if len(src_rows) != len(tgt_rows):
        mismatches.append(
            {
                "type": "ROWCOUNT",
                "row": 0,
                "column": "<ROWCOUNT>",
                "src": str(len(src_rows)),
                "tgt": str(len(tgt_rows)),
                "reason": "Data row count mismatch",
            }
        )

    src_map, _ = _build_row_map(src_header, src_rows)
    tgt_map, _ = _build_row_map(tgt_header, tgt_rows)
    all_keys = sorted(set(src_map.keys()) | set(tgt_map.keys()))

    for key in all_keys:
        src_entry = src_map.get(key)
        tgt_entry = tgt_map.get(key)

        src_row_idx = src_entry[0] if src_entry else None
        tgt_row_idx = tgt_entry[0] if tgt_entry else None
        src_row = src_entry[1] if src_entry else []
        tgt_row = tgt_entry[1] if tgt_entry else []

        display_row = (src_row_idx if src_row_idx is not None else tgt_row_idx) + 2
        col_limit = max(
            len(src_header), len(tgt_header), len(src_row), len(tgt_row)
        )

        for col_idx in range(col_limit):
            src_val = src_row[col_idx] if col_idx < len(src_row) else ""
            tgt_val = tgt_row[col_idx] if col_idx < len(tgt_row) else ""
            if _values_are_equal(src_val, tgt_val):
                continue

            if col_idx < len(src_header):
                col_name = src_header[col_idx]
            elif col_idx < len(tgt_header):
                col_name = tgt_header[col_idx]
            else:
                col_name = f"col_{col_idx + 1}"

            mismatch_type, mismatch_reason = _classify_mismatch(src_val, tgt_val)
            mismatches.append(
                {
                    "type": mismatch_type,
                    "row": display_row,
                    "column": col_name,
                    "src": src_val,
                    "tgt": tgt_val,
                    "reason": mismatch_reason,
                }
            )

    passed = len(mismatches) == 0
    reason = (
        "All rows and columns match."
        if passed
        else f"Found {len(mismatches)} mismatch(es) across headers/rows/columns."
    )
    return passed, reason, mismatches
