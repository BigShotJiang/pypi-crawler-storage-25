#!/usr/bin/env python3
"""
db.py – Database connectivity and table loading for Data Validation Gini.

Moved to core/ as the canonical database layer.

Supported engines: postgresql, mysql, sqlite.
Connection parameters are read from database_config.ini (or a custom path).

Public API
----------
load_db_table(db_alias, table_name, config_path, chunk_size, progress_label)
    -> (header: list[str], rows: list[list[str]])

get_db_connection(db_alias, config_path)
    -> a DB-API 2.0 connection

list_db_tables(db_alias, config_path)
    -> list[str]
"""
from __future__ import annotations

import configparser
import re
import sqlite3
from pathlib import Path
from typing import Any

from .file_stores import IniConfigStore

# ---------------------------------------------------------------------------
# Config helpers
# ---------------------------------------------------------------------------

DEFAULT_CONFIG_PATH = Path(__file__).resolve().parents[3] / "database_config.ini"

SUPPORTED_ENGINES = {"postgresql", "mysql", "sqlite"}


def _load_config(config_path: str | Path | None = None) -> configparser.ConfigParser:
    path = Path(config_path) if config_path else DEFAULT_CONFIG_PATH
    store = IniConfigStore(path)
    try:
        return store.read()
    except FileNotFoundError as exc:
        raise FileNotFoundError(
            f"Database config file not found: {path}. "
            "Create database_config.ini or pass --db-config <path>."
        ) from exc


def _section(cfg: configparser.ConfigParser, db_alias: str) -> dict[str, str]:
    if not cfg.has_section(db_alias):
        available = ", ".join(cfg.sections()) or "<none>"
        raise ValueError(
            f"Database alias '{db_alias}' not found in config. "
            f"Available aliases: {available}"
        )
    return dict(cfg[db_alias])


# ---------------------------------------------------------------------------
# Connection factory
# ---------------------------------------------------------------------------

def get_db_connection(
    db_alias: str,
    config_path: str | Path | None = None,
) -> Any:
    """Return a DB-API 2.0 connection for the given alias."""
    cfg = _load_config(config_path)
    params = _section(cfg, db_alias)
    engine = params.get("engine", "").lower()

    if engine not in SUPPORTED_ENGINES:
        raise ValueError(
            f"Unsupported engine '{engine}' for alias '{db_alias}'. "
            f"Supported engines: {', '.join(sorted(SUPPORTED_ENGINES))}"
        )

    if engine == "sqlite":
        db_file = params.get("database", "./data/dvg.db")
        config_dir = (
            Path(config_path) if config_path else DEFAULT_CONFIG_PATH
        ).parent
        db_path = (config_dir / db_file).resolve()
        db_path.parent.mkdir(parents=True, exist_ok=True)
        conn = sqlite3.connect(str(db_path))
        conn.row_factory = None
        return conn

    if engine == "postgresql":
        try:
            import psycopg2  # type: ignore
        except ImportError as exc:
            raise ImportError(
                "psycopg2-binary is required for PostgreSQL. "
                "Run: pip install psycopg2-binary"
            ) from exc
        return psycopg2.connect(
            host=params.get("host", "localhost"),
            port=int(params.get("port", 5432)),
            dbname=params.get("database", "dvg_db"),
            user=params.get("user", "dvg_user"),
            password=params.get("password", ""),
        )

    if engine == "mysql":
        try:
            import pymysql  # type: ignore
        except ImportError as exc:
            raise ImportError(
                "pymysql is required for MySQL. Run: pip install pymysql"
            ) from exc
        return pymysql.connect(
            host=params.get("host", "localhost"),
            port=int(params.get("port", 3306)),
            database=params.get("database", "dvg_db"),
            user=params.get("user", "dvg_user"),
            password=params.get("password", ""),
            cursorclass=pymysql.cursors.Cursor,
        )

    raise ValueError(f"Unknown engine: {engine}")


# ---------------------------------------------------------------------------
# Table listing
# ---------------------------------------------------------------------------

def list_db_tables(
    db_alias: str,
    config_path: str | Path | None = None,
) -> list[str]:
    """Return the list of user tables in the target database."""
    cfg = _load_config(config_path)
    params = _section(cfg, db_alias)
    engine = params.get("engine", "").lower()

    conn = get_db_connection(db_alias, config_path)
    try:
        cur = conn.cursor()
        if engine == "sqlite":
            cur.execute(
                "SELECT name FROM sqlite_master WHERE type='table' ORDER BY name"
            )
        elif engine == "postgresql":
            schema = params.get("schema", "public")
            cur.execute(
                "SELECT table_name FROM information_schema.tables "
                "WHERE table_schema = %s ORDER BY table_name",
                (schema,),
            )
        elif engine == "mysql":
            cur.execute("SHOW TABLES")
        else:
            return []
        return [row[0] for row in cur.fetchall()]
    finally:
        conn.close()


# ---------------------------------------------------------------------------
# Table loading
# ---------------------------------------------------------------------------

def _normalize_cell(value: Any) -> str:
    if value is None:
        return ""
    return str(value)


def _is_safe_identifier(name: str) -> bool:
    """Return True only if *name* contains safe SQL identifier characters."""
    return bool(re.fullmatch(r"[A-Za-z_][A-Za-z0-9_.]*", name))


def load_db_table(
    db_alias: str,
    table_name: str,
    config_path: str | Path | None = None,
    chunk_size: int = 1000,
    progress_label: str | None = None,
) -> tuple[list[str], list[list[str]]]:
    """
    Load all rows from *table_name* in the database identified by *db_alias*.

    Returns ``(header, rows)`` where every cell is a normalised string,
    matching the contract of the file loaders in ``core.cli``.
    """
    label = progress_label or f"DB:{db_alias}:{table_name}"

    cfg = _load_config(config_path)
    params = _section(cfg, db_alias)
    engine = params.get("engine", "").lower()

    conn = get_db_connection(db_alias, config_path)
    try:
        cur = conn.cursor()
        if not _is_safe_identifier(table_name):
            raise ValueError(
                f"Unsafe table name '{table_name}'. "
                "Only letters, digits, underscores, and dots are allowed."
            )
        if engine == "postgresql":
            schema = params.get("schema", "public")
            if not _is_safe_identifier(schema):
                raise ValueError(
                    f"Unsafe schema name '{schema}'. "
                    "Only letters, digits, underscores, and dots are allowed."
                )
            qualified = f"{schema}.{table_name}"
        else:
            qualified = table_name
        cur.execute(f"SELECT * FROM {qualified}")  # nosec B608

        header: list[str] = [desc[0] for desc in cur.description]
        rows: list[list[str]] = []
        chunk_num = 0
        while True:
            chunk = cur.fetchmany(chunk_size)
            if not chunk:
                break
            chunk_num += 1
            print(
                f"[LOAD][{label}] processing chunk {chunk_num} "
                f"({len(chunk)} row(s))"
            )
            for db_row in chunk:
                rows.append([_normalize_cell(v) for v in db_row])

        print(
            f"[LOAD][{label}] completed {len(rows)} row(s) across "
            f"{chunk_num} chunk(s)"
        )
        return header, rows
    finally:
        conn.close()
