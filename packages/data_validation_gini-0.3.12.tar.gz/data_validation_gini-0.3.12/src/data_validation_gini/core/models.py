from __future__ import annotations

from dataclasses import dataclass, field


@dataclass
class Dataset:
    header: list[str]
    rows: list[list[str]]


@dataclass
class ValidationResult:
    passed: bool
    reason: str
    mismatches: list[dict] = field(default_factory=list)


@dataclass
class ValidationBundleResult:
    passed: bool
    reason: str
    mismatches: list[dict] = field(default_factory=list)
    src_rows_count: int = 0
    tgt_rows_count: int = 0
