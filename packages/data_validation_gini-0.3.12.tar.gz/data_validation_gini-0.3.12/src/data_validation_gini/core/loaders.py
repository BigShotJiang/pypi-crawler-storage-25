from __future__ import annotations

from dataclasses import dataclass
from typing import Callable

from .models import Dataset


@dataclass
class FileTableLoader:
    load_table_func: Callable

    def load(
        self,
        path: str,
        sheet_name: str | None = None,
        chunk_size: int = 1000,
        progress_label: str | None = None,
    ) -> Dataset:
        try:
            header, rows = self.load_table_func(
                path,
                sheet_name=sheet_name,
                chunk_size=chunk_size,
                progress_label=progress_label,
            )
        except TypeError:
            # Backward-compatible path for monkeypatched callables in tests.
            header, rows = self.load_table_func(path, sheet_name=sheet_name)
        return Dataset(header=header, rows=rows)


@dataclass
class DbTableLoader:
    load_db_table_func: Callable

    def load(
        self,
        db_alias: str,
        table_name: str,
        config_path: str,
        chunk_size: int,
        progress_label: str,
    ) -> Dataset:
        header, rows = self.load_db_table_func(
            db_alias,
            table_name,
            config_path=config_path,
            chunk_size=chunk_size,
            progress_label=progress_label,
        )
        return Dataset(header=header, rows=rows)
