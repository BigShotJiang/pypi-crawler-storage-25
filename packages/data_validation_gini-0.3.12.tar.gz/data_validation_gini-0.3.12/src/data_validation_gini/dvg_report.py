﻿"""
dvg_report.py - Backward-compatibility shim.

All functionality lives in data_validation_gini.core.report.
This module re-exports everything so existing imports continue to work.
"""
from .core.report import *  # noqa: F401,F403
from .core.report import (
    DEFAULT_LINKEDIN_URL,
    DEFAULT_REPO_URL,
    _column_pair_for_mismatch,
    _group_mismatches,
    _normalize_column_name,
    _render_mismatch_rows,
    _safe_int,
    build_report_metrics,
    generate_html_report,
    write_html_report,
)  # noqa: F401
