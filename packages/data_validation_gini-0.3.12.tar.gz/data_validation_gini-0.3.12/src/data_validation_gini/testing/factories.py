"""
factories.py – Lightweight factory functions for building test objects.

These helpers keep test setup concise and consistent across the test suite.
They have no pytest dependency so they can be called from unit tests and
from pytest fixtures alike.
"""
from __future__ import annotations

import csv
from pathlib import Path

from ..core.models import Dataset, ValidationBundleResult, ValidationResult


# ---------------------------------------------------------------------------
# Dataset factories
# ---------------------------------------------------------------------------

def make_dataset(
    header: list[str],
    rows: list[list[str]],
) -> Dataset:
    """Return a ``Dataset`` with the given header and rows."""
    return Dataset(header=list(header), rows=[list(r) for r in rows])


def make_empty_dataset(header: list[str] | None = None) -> Dataset:
    """Return an empty ``Dataset`` (no data rows)."""
    return Dataset(header=list(header or []), rows=[])


def make_identical_dataset_pair(
    header: list[str],
    rows: list[list[str]],
) -> tuple[Dataset, Dataset]:
    """Return two independent but identical ``Dataset`` objects."""
    return make_dataset(header, rows), make_dataset(header, rows)


def make_mismatched_dataset_pair(
    header: list[str],
    src_rows: list[list[str]],
    tgt_rows: list[list[str]],
) -> tuple[Dataset, Dataset]:
    """Return a (src, tgt) ``Dataset`` pair that differs in data."""
    return make_dataset(header, src_rows), make_dataset(header, tgt_rows)


# ---------------------------------------------------------------------------
# ValidationResult factories
# ---------------------------------------------------------------------------

def make_validation_result(
    passed: bool = True,
    reason: str = "ok",
    mismatches: list[dict] | None = None,
) -> ValidationResult:
    """Return a ``ValidationResult`` for use in tests."""
    return ValidationResult(
        passed=passed,
        reason=reason,
        mismatches=list(mismatches or []),
    )


def make_bundle_result(
    passed: bool = True,
    reason: str = "ok",
    mismatches: list[dict] | None = None,
    src_rows_count: int = 0,
    tgt_rows_count: int = 0,
) -> ValidationBundleResult:
    """Return a ``ValidationBundleResult`` for use in tests."""
    return ValidationBundleResult(
        passed=passed,
        reason=reason,
        mismatches=list(mismatches or []),
        src_rows_count=src_rows_count,
        tgt_rows_count=tgt_rows_count,
    )


# ---------------------------------------------------------------------------
# File factories
# ---------------------------------------------------------------------------

def make_csv_file(
    path: Path,
    header: list[str],
    rows: list[list[str]],
) -> Path:
    """Write a CSV file at *path* and return the path."""
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", encoding="utf-8", newline="") as fh:
        writer = csv.writer(fh)
        writer.writerow(header)
        writer.writerows(rows)
    return path
