"""
fixtures.py – Re-usable pytest fixtures for Data Validation Gini tests.

Usage
-----
Import individual fixtures into your conftest.py::

    from data_validation_gini.testing.fixtures import (
        sample_employees_dataset,
        matching_dataset_pair,
        mismatched_dataset_pair,
        sample_csv_file,
    )

Or import all at once (pytest will discover them automatically)::

    from data_validation_gini.testing.fixtures import *  # noqa: F401,F403
"""
from __future__ import annotations

import pytest

from ..core.models import Dataset
from .factories import make_csv_file, make_dataset


# ---------------------------------------------------------------------------
# Dataset fixtures
# ---------------------------------------------------------------------------

@pytest.fixture
def sample_employees_dataset() -> Dataset:
    """A small employees dataset with realistic column names."""
    return make_dataset(
        header=["employee_id", "first_name", "last_name", "email", "department_id", "salary"],
        rows=[
            ["1", "Alice", "Smith", "alice@example.com", "10", "70000"],
            ["2", "Bob", "Jones", "bob@example.com", "20", "80000"],
            ["3", "Carol", "White", "carol@example.com", "10", "75000"],
        ],
    )


@pytest.fixture
def sample_departments_dataset() -> Dataset:
    """A small departments dataset."""
    return make_dataset(
        header=["department_id", "department_name", "location"],
        rows=[
            ["10", "Engineering", "New York"],
            ["20", "Marketing", "London"],
        ],
    )


@pytest.fixture
def matching_dataset_pair() -> tuple[Dataset, Dataset]:
    """A (src, tgt) pair whose contents are identical — validation should PASS."""
    header = ["id", "name", "value"]
    rows = [["1", "Alpha", "100"], ["2", "Beta", "200"], ["3", "Gamma", "300"]]
    return make_dataset(header, rows), make_dataset(header, rows)


@pytest.fixture
def mismatched_dataset_pair() -> tuple[Dataset, Dataset]:
    """A (src, tgt) pair with a deliberate cell mismatch — validation should FAIL."""
    header = ["id", "name"]
    src = make_dataset(header, [["1", "Alice"], ["2", "Bob"]])
    tgt = make_dataset(header, [["1", "Alice"], ["2", "Charlie"]])  # row 2 differs
    return src, tgt


@pytest.fixture
def rowcount_mismatch_pair() -> tuple[Dataset, Dataset]:
    """A (src, tgt) pair where src has more rows than tgt."""
    header = ["id", "name"]
    src = make_dataset(header, [["1", "Alice"], ["2", "Bob"], ["3", "Carol"]])
    tgt = make_dataset(header, [["1", "Alice"], ["2", "Bob"]])
    return src, tgt


# ---------------------------------------------------------------------------
# File fixtures
# ---------------------------------------------------------------------------

@pytest.fixture
def sample_csv_file(tmp_path):
    """A temporary CSV file with a small employees dataset."""
    return make_csv_file(
        tmp_path / "sample.csv",
        header=["id", "name", "email"],
        rows=[
            ["1", "Alice", "alice@example.com"],
            ["2", "Bob", "bob@example.com"],
        ],
    )


@pytest.fixture
def matching_csv_pair(tmp_path):
    """Two temporary CSV files with identical content."""
    header = ["id", "name", "salary"]
    rows = [["1", "Alice", "70000"], ["2", "Bob", "80000"]]
    src = make_csv_file(tmp_path / "src.csv", header, rows)
    tgt = make_csv_file(tmp_path / "tgt.csv", header, rows)
    return src, tgt


@pytest.fixture
def mismatched_csv_pair(tmp_path):
    """Two temporary CSV files with a cell-level mismatch."""
    header = ["id", "name", "salary"]
    src = make_csv_file(
        tmp_path / "src.csv", header,
        [["1", "Alice", "70000"], ["2", "Bob", "80000"]],
    )
    tgt = make_csv_file(
        tmp_path / "tgt.csv", header,
        [["1", "Alice", "70000"], ["2", "Bob", "90000"]],  # salary differs
    )
    return src, tgt
