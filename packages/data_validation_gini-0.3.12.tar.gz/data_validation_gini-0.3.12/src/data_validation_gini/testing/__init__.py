"""
data_validation_gini.testing
============================
Shared test-support helpers for the Data Validation Gini test suite.

Sub-modules
-----------
factories   – Lightweight factory functions for building test objects
              (Dataset, ValidationResult, ValidationBundleResult) and
              creating temporary CSV files.

fixtures    – Re-usable pytest fixtures built on top of the factories.
              Import them into your conftest.py with::

                  from data_validation_gini.testing.fixtures import *  # noqa: F401,F403

              or selectively::

                  from data_validation_gini.testing.fixtures import (
                      sample_employees_dataset,
                      matching_dataset_pair,
                  )
"""
from .factories import (
    make_bundle_result,
    make_csv_file,
    make_dataset,
    make_validation_result,
)

__all__ = [
    "make_bundle_result",
    "make_csv_file",
    "make_dataset",
    "make_validation_result",
]
