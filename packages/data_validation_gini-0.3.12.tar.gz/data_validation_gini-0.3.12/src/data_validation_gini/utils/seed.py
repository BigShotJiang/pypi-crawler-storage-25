"""
seed.py – Database seeding utilities for Data Validation Gini.

Moved to utils/ as the canonical seeding module.  Provides functions to
create tables and load sample employees/departments CSV data into
PostgreSQL, MySQL, and SQLite databases defined in database_config.ini.

Public API
----------
seed_target(db_alias, config_path)
    Seed a single database alias.

main()
    CLI entry point; seeds one or more aliases.

CLI usage
---------
    python -m data_validation_gini.utils.seed \\
        --db-config database_config.ini \\
        --targets postgresql,mysql,sqlite
"""
from __future__ import annotations

import argparse
import csv
from pathlib import Path

from ..core.db import _load_config, _section, get_db_connection

PROJECT_ROOT = Path(__file__).resolve().parents[3]
EMPLOYEES_CSV = PROJECT_ROOT / "inputs" / "employees.csv"
DEPARTMENTS_CSV = PROJECT_ROOT / "inputs" / "departments.csv"

# ---------------------------------------------------------------------------
# DDL templates
# ---------------------------------------------------------------------------

DDL_POSTGRESQL = {
    "departments": """
        CREATE TABLE IF NOT EXISTS departments (
            department_id   INTEGER PRIMARY KEY,
            department_name VARCHAR(120) NOT NULL,
            location        VARCHAR(120),
            cost_center_code VARCHAR(30)
        )
    """,
    "employees": """
        CREATE TABLE IF NOT EXISTS employees (
            employee_id   INTEGER PRIMARY KEY,
            first_name    VARCHAR(60),
            last_name     VARCHAR(60),
            email         VARCHAR(150),
            department_id INTEGER REFERENCES departments(department_id),
            salary        NUMERIC(12,2),
            hire_date     DATE,
            status        VARCHAR(30),
            manager_id    INTEGER
        )
    """,
}

DDL_MYSQL = {
    "departments": """
        CREATE TABLE IF NOT EXISTS departments (
            department_id   INT PRIMARY KEY,
            department_name VARCHAR(120) NOT NULL,
            location        VARCHAR(120),
            cost_center_code VARCHAR(30)
        )
    """,
    "employees": """
        CREATE TABLE IF NOT EXISTS employees (
            employee_id   INT PRIMARY KEY,
            first_name    VARCHAR(60),
            last_name     VARCHAR(60),
            email         VARCHAR(150),
            department_id INT,
            salary        DECIMAL(12,2),
            hire_date     DATE,
            status        VARCHAR(30),
            manager_id    INT
        )
    """,
}

DDL_SQLITE = {
    "departments": """
        CREATE TABLE IF NOT EXISTS departments (
            department_id   INTEGER PRIMARY KEY,
            department_name TEXT NOT NULL,
            location        TEXT,
            cost_center_code TEXT
        )
    """,
    "employees": """
        CREATE TABLE IF NOT EXISTS employees (
            employee_id   INTEGER PRIMARY KEY,
            first_name    TEXT,
            last_name     TEXT,
            email         TEXT,
            department_id INTEGER,
            salary        REAL,
            hire_date     TEXT,
            status        TEXT,
            manager_id    INTEGER
        )
    """,
}

ENGINE_DDL: dict[str, dict[str, str]] = {
    "postgresql": DDL_POSTGRESQL,
    "mysql": DDL_MYSQL,
    "sqlite": DDL_SQLITE,
}


# ---------------------------------------------------------------------------
# Internal helpers
# ---------------------------------------------------------------------------

def _read_csv(path: Path) -> tuple[list[str], list[list[str]]]:
    with path.open(newline="", encoding="utf-8-sig") as fh:
        reader = csv.reader(fh)
        header = next(reader)
        rows = list(reader)
    return header, rows


def _coerce(value: str) -> object:
    """Convert empty strings and NULL literals to None."""
    stripped = value.strip()
    if stripped == "" or stripped.upper() == "NULL":
        return None
    return stripped


def _seed_table(
    conn,
    engine: str,
    table: str,
    header: list[str],
    rows: list[list[str]],
) -> None:
    cur = conn.cursor()
    placeholders = (
        ", ".join(["%s"] * len(header))
        if engine != "sqlite"
        else ", ".join(["?"] * len(header))
    )
    cols = ", ".join(header)
    insert_sql = f"INSERT INTO {table} ({cols}) VALUES ({placeholders})"  # nosec B608

    coerced_rows = [[_coerce(cell) for cell in row] for row in rows]
    cur.executemany(insert_sql, coerced_rows)
    conn.commit()
    print(f"  Inserted {len(coerced_rows)} rows into {table}.")


def _clear_tables(conn) -> None:
    """Delete rows in FK-safe order (children first, then parents)."""
    cur = conn.cursor()
    for table in ["employees", "departments"]:
        cur.execute(f"DELETE FROM {table}")  # nosec B608
    conn.commit()


def _create_tables(conn, engine: str, ddl_map: dict[str, str]) -> None:
    cur = conn.cursor()
    for table in ["departments", "employees"]:
        cur.execute(ddl_map[table])
    conn.commit()


# ---------------------------------------------------------------------------
# Public API
# ---------------------------------------------------------------------------

def seed_target(
    db_alias: str,
    config_path: str | Path,
    employees_csv: Path | None = None,
    departments_csv: Path | None = None,
) -> None:
    """Seed *db_alias* with employees and departments data.

    Parameters
    ----------
    db_alias:           Alias defined in database_config.ini.
    config_path:        Path to database_config.ini.
    employees_csv:      Override path to employees CSV (default: inputs/employees.csv).
    departments_csv:    Override path to departments CSV (default: inputs/departments.csv).
    """
    emp_csv = Path(employees_csv) if employees_csv else EMPLOYEES_CSV
    dept_csv = Path(departments_csv) if departments_csv else DEPARTMENTS_CSV

    cfg = _load_config(config_path)
    params = _section(cfg, db_alias)
    engine = params.get("engine", "").lower()

    ddl_map = ENGINE_DDL.get(engine)
    if ddl_map is None:
        print(f"  [SKIP] Unknown engine '{engine}' for alias '{db_alias}'.")
        return

    print(f"\n[{db_alias.upper()}] Connecting (engine={engine})…")
    try:
        conn = get_db_connection(db_alias, config_path)
    except Exception as exc:
        print(f"  [ERROR] Could not connect to '{db_alias}': {exc}")
        return

    try:
        print("  Creating tables…")
        _create_tables(conn, engine, ddl_map)

        dept_header, dept_rows = _read_csv(dept_csv)
        emp_header, emp_rows = _read_csv(emp_csv)

        print("  Clearing existing rows…")
        _clear_tables(conn)

        print("  Seeding departments…")
        _seed_table(conn, engine, "departments", dept_header, dept_rows)

        print("  Seeding employees…")
        _seed_table(conn, engine, "employees", emp_header, emp_rows)

        print(f"  [{db_alias.upper()}] Done.")
    except Exception as exc:
        print(f"  [ERROR] Seed failed for '{db_alias}': {exc}")
        conn.rollback()
    finally:
        conn.close()


# ---------------------------------------------------------------------------
# CLI entry point
# ---------------------------------------------------------------------------

def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(
        description="Seed employee and department data into configured databases."
    )
    parser.add_argument(
        "--db-config",
        default=str(PROJECT_ROOT / "database_config.ini"),
        help="Path to database_config.ini (default: project root).",
    )
    parser.add_argument(
        "--targets",
        default="postgresql,mysql,sqlite",
        help="Comma-separated list of DB aliases to seed (default: all three).",
    )
    return parser.parse_args()


def main() -> None:
    args = parse_args()
    config_path = Path(args.db_config)
    targets = [t.strip() for t in args.targets.split(",") if t.strip()]

    print(f"Seeding databases: {', '.join(targets)}")
    print(f"Config: {config_path}")

    for alias in targets:
        seed_target(alias, config_path)

    print("\nSeeding complete.")


if __name__ == "__main__":
    main()
