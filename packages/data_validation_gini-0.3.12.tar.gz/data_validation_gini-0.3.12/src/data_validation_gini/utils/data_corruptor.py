#!/usr/bin/env python3
"""
data_corruptor.py – Inject controlled data variations into CSV files.

Moved to utils/ as the canonical utility module.

Supported mutation types
------------------------
nullify         – Replace the target cell with a blank value.
case_swap       – Swap the case of every character in the value.
numeric_shift   – Add or subtract a numeric amount from a numeric cell.
date_shift      – Shift a date value by a given number of days.
typo            – Randomly replace one character with a different character.

CLI usage
---------
    python -m data_validation_gini.utils.data_corruptor \\
        -i inputs/employees.csv \\
        -o outputs/employees_corrupted.csv \\
        -c salary -t numeric_shift -p 10 -v 500
"""
import csv
import argparse
import random
import sys
from datetime import datetime, timedelta


def parse_arguments():
    parser = argparse.ArgumentParser(
        description=(
            "Inject controlled data variations/corruptions into CSV files "
            "for validation testing."
        )
    )
    parser.add_argument("-i", "--input", required=True, help="Path to the input baseline CSV file")
    parser.add_argument("-o", "--output", required=True, help="Path to save the mutated output CSV file")
    parser.add_argument("-c", "--column", required=True, help="Column name to apply variations to")
    parser.add_argument(
        "-p", "--percentage",
        type=float,
        default=5.0,
        help="Percentage of rows to alter in the specified column (0.0 to 100.0)",
    )
    parser.add_argument(
        "-t", "--type",
        required=True,
        choices=["nullify", "case_swap", "numeric_shift", "date_shift", "typo"],
        help="Type of variation/corruption to inject",
    )
    parser.add_argument(
        "-v", "--value",
        type=float,
        default=1.0,
        help="Adjustment value: numeric shift amount, days to shift a date, or typo count",
    )
    return parser.parse_args()


def inject_variation(val: str, mutation_type: str, intensity_val: float) -> str:
    """Apply a single transformation to *val* and return the mutated string.

    Parameters
    ----------
    val:            The original cell value.
    mutation_type:  One of nullify | case_swap | numeric_shift | date_shift | typo.
    intensity_val:  Numeric intensity (shift amount, number of days, etc.).
    """
    if not val or val.strip().upper() == "NULL":
        return val  # Leave existing nulls as-is to preserve base structure

    if mutation_type == "nullify":
        return ""  # Creates a blank/null discrepancy

    if mutation_type == "case_swap":
        return val.swapcase()  # Verifies case-sensitivity checks

    if mutation_type == "numeric_shift":
        try:
            if "." in val:
                return str(round(float(val) + intensity_val, 2))
            return str(int(val) + int(intensity_val))
        except ValueError:
            return val + "_SHIFT_ERR"

    if mutation_type == "date_shift":
        for fmt in ("%Y-%m-%d", "%Y-%m-%d %H:%M:%S"):
            try:
                dt = datetime.strptime(val, fmt)
                mutated_dt = dt + timedelta(days=intensity_val)
                return mutated_dt.strftime(fmt)
            except ValueError:
                continue
        return val + "_DATE_ERR"

    if mutation_type == "typo":
        if len(val) <= 1:
            return val + "X"
        idx = random.randint(0, len(val) - 1)
        char_pool = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789"
        new_char = random.choice(char_pool.replace(val[idx], ""))
        val_list = list(val)
        val_list[idx] = new_char
        return "".join(val_list)

    return val


def main():
    args = parse_arguments()

    if not 0 <= args.percentage <= 100:
        print("Error: Percentage must be between 0 and 100.")
        sys.exit(1)

    try:
        with open(args.input, mode="r", newline="", encoding="utf-8") as f:
            reader = list(csv.reader(f))
    except FileNotFoundError:
        print(f"Error: Input file '{args.input}' not found.")
        sys.exit(1)

    if not reader:
        print("Error: The input CSV file is empty.")
        sys.exit(1)

    header = reader[0]
    rows = reader[1:]

    if args.column not in header:
        print(f"Error: Column '{args.column}' not found in the CSV header.")
        print(f"Available columns: {', '.join(header)}")
        sys.exit(1)

    col_idx = header.index(args.column)
    total_rows = len(rows)

    mutation_count = int(round((args.percentage / 100.0) * total_rows))
    if mutation_count == 0 and args.percentage > 0:
        mutation_count = 1  # Guarantee at least one alteration if percentage > 0

    target_row_indices = set(random.sample(range(total_rows), mutation_count))

    print("--- Data Variation Injection Active ---")
    print(f"Targeting Column : '{args.column}' (Index {col_idx})")
    print(f"Mutation Strategy: {args.type}")
    print(
        f"Execution Volume : Modifying {mutation_count} out of {total_rows} "
        f"rows ({args.percentage}%)"
    )

    for idx in range(total_rows):
        if idx in target_row_indices:
            rows[idx][col_idx] = inject_variation(rows[idx][col_idx], args.type, args.value)

    with open(args.output, mode="w", newline="", encoding="utf-8") as f:
        writer = csv.writer(f)
        writer.writerow(header)
        writer.writerows(rows)

    print(f"Success: Saved modified file to '{args.output}'. Verification runs ready.")


if __name__ == "__main__":
    main()
