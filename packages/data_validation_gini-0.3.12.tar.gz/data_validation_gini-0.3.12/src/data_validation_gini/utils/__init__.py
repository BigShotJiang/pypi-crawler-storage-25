"""
data_validation_gini.utils
===========================
Utility sub-package for data preparation, mutation, and seeding helpers.

Sub-modules
-----------
data_corruptor   – Inject controlled data variations into CSV files for
                   validation testing (nullify, case_swap, numeric_shift,
                   date_shift, typo).

seed             – Functions for seeding PostgreSQL, MySQL, and SQLite
                   databases with sample employees/departments data.
"""
from .data_corruptor import inject_variation
from .seed import seed_target

__all__ = ["inject_variation", "seed_target"]
