﻿#!/usr/bin/env python3
"""
dvg_db.py - Backward-compatibility shim.

All functionality lives in data_validation_gini.core.db.
This module re-exports everything so existing imports continue to work.
"""
from .core.db import *  # noqa: F401,F403
from .core.db import (
    DEFAULT_CONFIG_PATH,
    SUPPORTED_ENGINES,
    _is_safe_identifier,
    _load_config,
    _normalize_cell,
    _section,
    get_db_connection,
    list_db_tables,
    load_db_table,
)  # noqa: F401
