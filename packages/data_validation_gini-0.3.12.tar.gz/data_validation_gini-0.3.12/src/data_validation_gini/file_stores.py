﻿#!/usr/bin/env python3
"""
file_stores.py - Backward-compatibility shim.

All functionality lives in data_validation_gini.core.file_stores.
This module re-exports everything so existing imports continue to work.
"""
from .core.file_stores import IniConfigStore, JsonFileStore  # noqa: F401
