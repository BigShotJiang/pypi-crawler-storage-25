from __future__ import annotations

import shutil
import subprocess
import sys
import time
from pathlib import Path

import pytest

from data_validation_gini.core.cli import _build_validation_service
from data_validation_gini.core.db import get_db_connection, load_db_table
from data_validation_gini.core.models import Dataset


ROOT = Path(__file__).resolve().parents[1]
DB_CONFIG = ROOT / "database_config.ini"


pytestmark = pytest.mark.integration


def _run(cmd: list[str], cwd: Path | None = None) -> subprocess.CompletedProcess[str]:
    return subprocess.run(
        cmd,
        cwd=str(cwd or ROOT),
        capture_output=True,
        text=True,
        check=False,
    )


def _docker_ready() -> bool:
    if shutil.which("docker") is None:
        return False
    probe = _run(["docker", "compose", "version"])
    return probe.returncode == 0


def _wait_for_db(alias: str, timeout_seconds: int = 90) -> None:
    deadline = time.time() + timeout_seconds
    while time.time() < deadline:
        try:
            conn = get_db_connection(alias, DB_CONFIG)
            conn.close()
            return True
        except Exception:
            time.sleep(2)
    return False


@pytest.fixture(scope="session")
def docker_seeded_databases() -> set[str]:
    if not _docker_ready():
        pytest.skip("Docker Compose is not available; skipping DB integration tests.")

    up = _run(["docker", "compose", "up", "-d"], cwd=ROOT)
    if up.returncode != 0:
        pytest.skip(
            "Could not start docker compose services for integration tests. "
            f"stderr={up.stderr.strip()}"
        )

    available_aliases: set[str] = {"sqlite"}
    if _wait_for_db("postgresql"):
        available_aliases.add("postgresql")
    if _wait_for_db("mysql"):
        available_aliases.add("mysql")

    if "postgresql" not in available_aliases and "mysql" not in available_aliases:
        pytest.skip(
            "Neither PostgreSQL nor MySQL became ready in docker compose; "
            "skipping cross-platform DB integration tests."
        )

    seed = _run(
        [
            sys.executable,
            str(ROOT / "scripts" / "seed_databases.py"),
            "--db-config",
            str(DB_CONFIG),
            "--targets",
            "postgresql,mysql,sqlite",
        ],
        cwd=ROOT,
    )
    if seed.returncode != 0:
        pytest.fail(
            "Seeding databases failed for integration tests.\n"
            f"stdout:\n{seed.stdout}\n"
            f"stderr:\n{seed.stderr}"
        )

    yield available_aliases

    # Best-effort cleanup; do not fail test session if teardown is unavailable.
    _run(["docker", "compose", "down"], cwd=ROOT)


def _load_dataset(alias: str, table: str) -> Dataset:
    header, rows = load_db_table(
        db_alias=alias,
        table_name=table,
        config_path=DB_CONFIG,
        chunk_size=500,
        progress_label=f"IT:{alias}:{table}",
    )
    return Dataset(header=header, rows=rows)


def _require_aliases(available_aliases: set[str], required: tuple[str, ...]) -> None:
    missing = [alias for alias in required if alias not in available_aliases]
    if missing:
        pytest.skip(
            "Skipping integration case because required database aliases are unavailable: "
            + ", ".join(missing)
        )


@pytest.mark.parametrize(
    "src_db,tgt_db,table",
    [
        ("postgresql", "mysql", "employees"),
        ("postgresql", "mysql", "departments"),
        ("postgresql", "sqlite", "employees"),
        ("postgresql", "sqlite", "departments"),
        ("mysql", "sqlite", "employees"),
        ("mysql", "sqlite", "departments"),
    ],
)
def test_cross_platform_validation_service_passes(
    docker_seeded_databases: set[str],
    src_db: str,
    tgt_db: str,
    table: str,
) -> None:
    _require_aliases(docker_seeded_databases, (src_db, tgt_db))

    src = _load_dataset(src_db, table)
    tgt = _load_dataset(tgt_db, table)

    service = _build_validation_service()
    result = service.validate_many(
        pairs=[(f"{src_db}.{table}->{tgt_db}.{table}", src, tgt)],
        validation_types=["ROWCOUNT", "ROW_COL_VALIDATION"],
        tag_mismatch_reasons=False,
    )

    assert result.passed is True, result.reason
    assert result.src_rows_count == result.tgt_rows_count
    assert result.mismatches == []


@pytest.mark.parametrize(
    "src_db,tgt_db,table",
    [
        ("postgresql", "mysql", "employees"),
        ("postgresql", "sqlite", "departments"),
        ("mysql", "sqlite", "employees"),
    ],
)
def test_cross_platform_cli_db_mode_passes(
    docker_seeded_databases: set[str],
    tmp_path: Path,
    src_db: str,
    tgt_db: str,
    table: str,
) -> None:
    _require_aliases(docker_seeded_databases, (src_db, tgt_db))

    out_path = tmp_path / f"it_{src_db}_vs_{tgt_db}_{table}.html"
    cmd = [
        sys.executable,
        str(ROOT / "dvg.py"),
        "--file-type",
        "DB",
        "--src-db",
        src_db,
        "--tgt-db",
        tgt_db,
        "--src-table",
        table,
        "--validation-type",
        "ROWCOUNT,ROW_COL_VALIDATION",
        "--db-config",
        str(DB_CONFIG),
        "--html-output",
        str(out_path),
    ]

    completed = _run(cmd, cwd=ROOT)

    assert completed.returncode == 0, (
        f"CLI validation failed for {src_db}->{tgt_db} {table}.\n"
        f"stdout:\n{completed.stdout}\n"
        f"stderr:\n{completed.stderr}"
    )
    assert "PASSED" in completed.stdout
    assert out_path.exists()
