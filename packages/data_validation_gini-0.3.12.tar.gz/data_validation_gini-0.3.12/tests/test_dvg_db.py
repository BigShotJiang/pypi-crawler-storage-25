import configparser
import sqlite3
import sys
import types

import pytest

import data_validation_gini.core.db as dvg_db


pytestmark = pytest.mark.core


def _write_config(path, section_name, values):
    cfg = configparser.ConfigParser()
    cfg[section_name] = values
    with open(path, "w", encoding="utf-8") as fh:
        cfg.write(fh)


def test_load_config_missing_file(tmp_path):
    with pytest.raises(FileNotFoundError):
        dvg_db._load_config(tmp_path / "missing.ini")


def test_section_missing_alias(tmp_path):
    cfg_path = tmp_path / "db.ini"
    _write_config(cfg_path, "sqlite_local", {"engine": "sqlite", "database": "local.db"})

    cfg = dvg_db._load_config(cfg_path)
    with pytest.raises(ValueError):
        dvg_db._section(cfg, "unknown")


def test_get_db_connection_unsupported_engine(tmp_path):
    cfg_path = tmp_path / "db.ini"
    _write_config(cfg_path, "bad", {"engine": "oracle"})

    with pytest.raises(ValueError):
        dvg_db.get_db_connection("bad", cfg_path)


def test_get_db_connection_sqlite(tmp_path):
    cfg_path = tmp_path / "db.ini"
    _write_config(cfg_path, "sqlite_local", {"engine": "sqlite", "database": "nested/local.db"})

    conn = dvg_db.get_db_connection("sqlite_local", cfg_path)
    try:
        assert isinstance(conn, sqlite3.Connection)
    finally:
        conn.close()

    assert (tmp_path / "nested" / "local.db").exists()


def test_get_db_connection_postgresql_import_error(tmp_path, monkeypatch):
    cfg_path = tmp_path / "db.ini"
    _write_config(cfg_path, "pg", {"engine": "postgresql"})

    monkeypatch.setitem(sys.modules, "psycopg2", None)

    real_import = __import__

    def fake_import(name, *args, **kwargs):
        if name == "psycopg2":
            raise ImportError("missing")
        return real_import(name, *args, **kwargs)

    monkeypatch.setattr("builtins.__import__", fake_import)

    with pytest.raises(ImportError):
        dvg_db.get_db_connection("pg", cfg_path)


def test_get_db_connection_postgresql_success(tmp_path, monkeypatch):
    cfg_path = tmp_path / "db.ini"
    _write_config(
        cfg_path,
        "pg",
        {
            "engine": "postgresql",
            "host": "h",
            "port": "5555",
            "database": "db",
            "user": "u",
            "password": "p",
        },
    )

    captured = {}

    fake_module = types.SimpleNamespace(
        connect=lambda **kwargs: captured.setdefault("kwargs", kwargs) or object()
    )
    monkeypatch.setitem(sys.modules, "psycopg2", fake_module)

    conn = dvg_db.get_db_connection("pg", cfg_path)
    assert conn is not None
    assert captured["kwargs"]["host"] == "h"
    assert captured["kwargs"]["port"] == 5555


def test_get_db_connection_mysql_import_error(tmp_path, monkeypatch):
    cfg_path = tmp_path / "db.ini"
    _write_config(cfg_path, "my", {"engine": "mysql"})

    real_import = __import__

    def fake_import(name, *args, **kwargs):
        if name == "pymysql":
            raise ImportError("missing")
        return real_import(name, *args, **kwargs)

    monkeypatch.setattr("builtins.__import__", fake_import)

    with pytest.raises(ImportError):
        dvg_db.get_db_connection("my", cfg_path)


def test_get_db_connection_mysql_success(tmp_path, monkeypatch):
    cfg_path = tmp_path / "db.ini"
    _write_config(
        cfg_path,
        "my",
        {
            "engine": "mysql",
            "host": "h",
            "port": "3307",
            "database": "db",
            "user": "u",
            "password": "p",
        },
    )

    captured = {}

    class FakeCursorClass:
        pass

    fake_module = types.SimpleNamespace(
        cursors=types.SimpleNamespace(Cursor=FakeCursorClass),
        connect=lambda **kwargs: captured.setdefault("kwargs", kwargs) or object(),
    )
    monkeypatch.setitem(sys.modules, "pymysql", fake_module)

    conn = dvg_db.get_db_connection("my", cfg_path)
    assert conn is not None
    assert captured["kwargs"]["port"] == 3307
    assert captured["kwargs"]["cursorclass"] is FakeCursorClass


class _FakeCursor:
    def __init__(self, rows):
        self.rows = rows
        self.executed = []

    def execute(self, sql, params=None):
        self.executed.append((sql, params))

    def fetchall(self):
        return self.rows


class _FakeConn:
    def __init__(self, cursor):
        self._cursor = cursor
        self.closed = False

    def cursor(self):
        return self._cursor

    def close(self):
        self.closed = True


def test_list_db_tables_sqlite(tmp_path, monkeypatch):
    cfg_path = tmp_path / "db.ini"
    _write_config(cfg_path, "sqlite_local", {"engine": "sqlite", "database": "local.db"})

    cur = _FakeCursor([("a",), ("b",)])
    conn = _FakeConn(cur)
    monkeypatch.setattr(dvg_db, "get_db_connection", lambda *args, **kwargs: conn)

    tables = dvg_db.list_db_tables("sqlite_local", cfg_path)
    assert tables == ["a", "b"]
    assert "sqlite_master" in cur.executed[0][0]
    assert conn.closed is True


def test_list_db_tables_postgresql(tmp_path, monkeypatch):
    cfg_path = tmp_path / "db.ini"
    _write_config(cfg_path, "pg", {"engine": "postgresql", "schema": "public"})

    cur = _FakeCursor([("x",)])
    conn = _FakeConn(cur)
    monkeypatch.setattr(dvg_db, "get_db_connection", lambda *args, **kwargs: conn)

    tables = dvg_db.list_db_tables("pg", cfg_path)
    assert tables == ["x"]
    assert "information_schema.tables" in cur.executed[0][0]


def test_list_db_tables_mysql(tmp_path, monkeypatch):
    cfg_path = tmp_path / "db.ini"
    _write_config(cfg_path, "my", {"engine": "mysql"})

    cur = _FakeCursor([("m",)])
    conn = _FakeConn(cur)
    monkeypatch.setattr(dvg_db, "get_db_connection", lambda *args, **kwargs: conn)

    tables = dvg_db.list_db_tables("my", cfg_path)
    assert tables == ["m"]
    assert cur.executed[0][0] == "SHOW TABLES"


def test_list_db_tables_unknown_engine_path(tmp_path, monkeypatch):
    cfg_path = tmp_path / "db.ini"
    _write_config(cfg_path, "x", {"engine": "mystery"})

    cur = _FakeCursor([])
    conn = _FakeConn(cur)
    monkeypatch.setattr(dvg_db, "get_db_connection", lambda *args, **kwargs: conn)

    tables = dvg_db.list_db_tables("x", cfg_path)
    assert tables == []


class _FakeDataCursor:
    def __init__(self, chunks, description):
        self._chunks = list(chunks)
        self.description = description
        self.executed = []

    def execute(self, sql):
        self.executed.append(sql)

    def fetchmany(self, size):
        if not self._chunks:
            return []
        return self._chunks.pop(0)


class _FakeDataConn:
    def __init__(self, cursor):
        self._cursor = cursor
        self.closed = False

    def cursor(self):
        return self._cursor

    def close(self):
        self.closed = True


def test_load_db_table_success_and_prints(tmp_path, monkeypatch, capsys):
    cfg_path = tmp_path / "db.ini"
    _write_config(cfg_path, "my", {"engine": "mysql"})

    cursor = _FakeDataCursor(
        chunks=[[(1, "Alice")], [(2, "Bob")]],
        description=[("id",), ("name",)],
    )
    conn = _FakeDataConn(cursor)
    monkeypatch.setattr(dvg_db, "get_db_connection", lambda *args, **kwargs: conn)

    header, rows = dvg_db.load_db_table("my", "employees", cfg_path, chunk_size=1, progress_label="LBL")
    assert header == ["id", "name"]
    assert rows == [["1", "Alice"], ["2", "Bob"]]
    assert "SELECT * FROM employees" in cursor.executed[0]
    out = capsys.readouterr().out
    assert "[LOAD][LBL] processing chunk 1" in out
    assert "completed 2 row(s)" in out
    assert conn.closed is True


def test_load_db_table_postgresql_schema_qualification(tmp_path, monkeypatch):
    cfg_path = tmp_path / "db.ini"
    _write_config(cfg_path, "pg", {"engine": "postgresql", "schema": "public"})

    cursor = _FakeDataCursor(chunks=[[(1,)]], description=[("id",)])
    conn = _FakeDataConn(cursor)
    monkeypatch.setattr(dvg_db, "get_db_connection", lambda *args, **kwargs: conn)

    dvg_db.load_db_table("pg", "employees", cfg_path)
    assert "SELECT * FROM public.employees" in cursor.executed[0]


def test_load_db_table_unsafe_identifiers(tmp_path, monkeypatch):
    cfg_path = tmp_path / "db.ini"
    _write_config(cfg_path, "pg", {"engine": "postgresql", "schema": "public"})

    cursor = _FakeDataCursor(chunks=[], description=[("id",)])
    conn = _FakeDataConn(cursor)
    monkeypatch.setattr(dvg_db, "get_db_connection", lambda *args, **kwargs: conn)

    with pytest.raises(ValueError):
        dvg_db.load_db_table("pg", "bad-name", cfg_path)

    _write_config(cfg_path, "pg", {"engine": "postgresql", "schema": "bad-name"})
    with pytest.raises(ValueError):
        dvg_db.load_db_table("pg", "employees", cfg_path)


def test_normalize_and_identifier_helper():
    assert dvg_db._normalize_cell(None) == ""
    assert dvg_db._normalize_cell(12) == "12"
    assert dvg_db._is_safe_identifier("abc_1.x") is True
    assert dvg_db._is_safe_identifier("bad-name") is False


def test_get_db_connection_unknown_engine_final_guard(tmp_path, monkeypatch):
    cfg_path = tmp_path / "db.ini"
    _write_config(cfg_path, "x", {"engine": "mystery"})

    monkeypatch.setattr(dvg_db, "SUPPORTED_ENGINES", {"postgresql", "mysql", "sqlite", "mystery"})
    with pytest.raises(ValueError, match="Unknown engine"):
        dvg_db.get_db_connection("x", cfg_path)
