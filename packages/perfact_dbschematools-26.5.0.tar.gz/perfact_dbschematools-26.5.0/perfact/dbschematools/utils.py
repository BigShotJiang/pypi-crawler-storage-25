#!/usr/bin/python3
import os
import string

import oyaml


def cleanup(ident, add_allow=""):
    """
    Return a valid table identifier (as per our rules).
    Only consisting of lower ascii, digits and possibly underscores (if so,
    add_allow is set to '_'), but the first character needs to be an ascii
    letter. The identifier may become empty by this!
    """
    allowed = string.ascii_lowercase + string.digits + add_allow
    result = "".join(c for c in ident if c in allowed)
    while result and result[0] not in string.ascii_lowercase:
        result = result[1:]
    return result


def yaml_dump(data, filename=None):
    """
    Wrapper to avoid always passing the Dumper
    """
    result = oyaml.dump(data, Dumper=oyaml.Dumper)
    if filename:
        with open(filename, "w") as f:
            f.write(result)
    return result


def yaml_load(filename):
    """
    Wrapper to open and load a YAML file.
    """
    with open(filename) as f:
        return oyaml.load(f, Loader=oyaml.Loader)


def add_subcmds(parser, commands, key="command"):
    """
    Add a subparser that derives its commands from the given list of classes.
    Each class must have an "add_args" static method. Once the arguments are
    parsed, the matching class is added under the key <key>.
    """
    subs = parser.add_subparsers()
    for cls in commands:
        subparser = subs.add_parser(
            getattr(cls, "subcommand", cls.__name__.lower()),
            help=cls.__doc__,
        )
        cls.add_args(subparser)
        # Add the instance as command parameter
        subparser.set_defaults(**{key: cls})


def scandir(path: str):
    """
    Iterate through contents of dir, but simply ignore if this is not a folder.
    """
    if not os.path.isdir(path):
        return
    yield from os.scandir(path)
