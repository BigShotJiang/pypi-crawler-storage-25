#!/usr/bin/python3
from typing import Any

import psycopg2
import pytest
from perfact.dbutils.conn import Connection
from pytest_postgresql.janitor import DatabaseJanitor

from ..assets import assets


@pytest.fixture(scope="function")
def dbconn(postgresql_proc: Any) -> Any:
    """A PostgreSQL database, connected using psycopg2."""
    with DatabaseJanitor(
        user=postgresql_proc.user,
        host=postgresql_proc.host,
        port=postgresql_proc.port,
        dbname=postgresql_proc.dbname,
        version=postgresql_proc.version,
        password=postgresql_proc.password,
    ):
        with psycopg2.connect(
            dbname=postgresql_proc.dbname,
            user=postgresql_proc.user,
            password=postgresql_proc.password,
            host=postgresql_proc.host,
            port=postgresql_proc.port,
        ) as db_connection:
            db_connection.autocommit = True
            conn = Connection(db_connection)
            conn.execute(assets["testinit.db_username"])
            yield conn
