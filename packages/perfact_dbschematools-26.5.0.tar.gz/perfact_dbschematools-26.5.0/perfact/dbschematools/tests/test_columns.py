import pytest

from ..plugins.columns import Columns
from ..plugins.tables import Tables
from ..utils import yaml_dump
from .testenv import TestEnv


class TestColumns(TestEnv):
    def _write_col_yaml(self, tmp_path, table, column, coltype, default):
        """Write a column YAML definition file directly, bypassing add_col."""
        fname = tmp_path / f"tables/{table}/columns/{column}.yml"
        yaml_dump({"type": coltype, "default": default}, filename=str(fname))

    def _assert_no_patch(self, dbconn, tmp_path):
        cols = Columns()
        cols.read(tmp_path)
        assert cols.mkpatch(dbconn) == []

    def test_add_column(self, dbconn, tmp_path):
        """
        Add a column with a default
        """
        Tables.add_table(tmp_path, "test")
        Columns.add_col(
            path=tmp_path,
            table="test",
            column="test_title",
            coltype="text",
            default="'blubb'",
        )
        self.flush(dbconn, tmp_path)

        dbconn.execute("insert into test default values")
        res = dbconn.execute("select * from test")
        assert res.names[-1] == "test_title"
        assert res.tuples[0][-1] == "blubb"

    def test_column_aliases(self, dbconn, tmp_path):
        """
        Add a column using a non-default type. Check that executing a second
        time does not yield anything to do.
        """
        Tables.add_table(tmp_path, "test")
        Columns.add_col(
            path=tmp_path,
            table="test",
            column="test_something",
            coltype="bigint",
        )
        self.flush(dbconn, tmp_path)
        cols = Columns()
        cols.read(tmp_path)
        res = cols.mkpatch(dbconn)
        assert res == []

    def test_no_remove_default(self, dbconn, tmp_path):
        """
        If a schema definition does not say anything about a default,
        a possibly existing default should be kept.
        Otherwise, the default should be overwritten.
        """
        Tables.add_table(tmp_path, "test")
        Columns.add_col(
            path=tmp_path,
            table="test",
            column="test_pos",
            coltype="integer",
            default="7",
        )
        self.flush(dbconn, tmp_path)

        defs = Columns.read_defs_from_db(dbconn)
        assert "default" in defs[("test", "test_pos")]

        Columns.add_col(
            path=tmp_path,
            table="test",
            column="test_pos",
            coltype="integer",
        )
        self.flush(dbconn, tmp_path)
        defs = Columns.read_defs_from_db(dbconn)
        assert "default" in defs[("test", "test_pos")]

        Columns.add_col(
            path=tmp_path,
            table="test",
            column="test_pos",
            coltype="integer",
            default="null",
        )
        self.flush(dbconn, tmp_path)
        defs = Columns.read_defs_from_db(dbconn)
        assert "default" not in defs[("test", "test_pos")]

    def test_boolean_default(self, dbconn, tmp_path):
        """
        Boolean defaults (true/false) should work both as strings ('true') and
        as YAML-loaded Python booleans (True/False from `default: true`).
        Neither should cause errors or trigger spurious re-application.
        """
        Tables.add_table(tmp_path, "test")

        # Case 1: string 'true' — normal programmatic/CLI usage
        Columns.add_col(
            path=tmp_path,
            table="test",
            column="test_flag",
            coltype="boolean",
            default="true",
        )
        self.flush(dbconn, tmp_path)

        dbconn.execute("insert into test default values")
        res = dbconn.execute("select test_flag from test")
        assert res.tuples[0][0] is True

        # No spurious re-application after second read
        self._assert_no_patch(dbconn, tmp_path)

        # Case 2: YAML with unquoted boolean
        # (oyaml loads `default: true` as Python True)
        self._write_col_yaml(tmp_path, "test", "test_flag", "bool", True)
        # Should not crash and should not produce patches
        self._assert_no_patch(dbconn, tmp_path)

    def test_numerical_default(self, dbconn, tmp_path):
        """
        Numerical defaults should work both as strings ('42') and as
        YAML-loaded Python ints (42 from `default: 42`).
        Neither should cause errors or trigger spurious re-application.
        """
        Tables.add_table(tmp_path, "test")

        # Case 1: string '42' — normal programmatic/CLI usage
        Columns.add_col(
            path=tmp_path,
            table="test",
            column="test_num",
            coltype="integer",
            default="42",
        )
        self.flush(dbconn, tmp_path)

        dbconn.execute("insert into test default values")
        res = dbconn.execute("select test_num from test")
        assert res.tuples[0][0] == 42

        # No spurious re-application after second read
        self._assert_no_patch(dbconn, tmp_path)

        # Case 2: YAML with unquoted integer
        # (oyaml loads `default: 42` as Python int)
        self._write_col_yaml(tmp_path, "test", "test_num", "integer", 42)
        self._assert_no_patch(dbconn, tmp_path)

    def test_float_default(self, dbconn, tmp_path):
        """
        Float defaults should work both as strings ('3.14') and as
        YAML-loaded Python floats (3.14 from `default: 3.14`).
        Neither should cause errors or trigger spurious re-application.
        """
        Tables.add_table(tmp_path, "test")

        # Case 1: string '3.14' — normal programmatic/CLI usage
        Columns.add_col(
            path=tmp_path,
            table="test",
            column="test_val",
            coltype="numeric",
            default="3.14",
        )
        self.flush(dbconn, tmp_path)

        dbconn.execute("insert into test default values")
        res = dbconn.execute("select test_val from test")
        assert float(res.tuples[0][0]) == pytest.approx(3.14)

        # No spurious re-application after second read
        self._assert_no_patch(dbconn, tmp_path)

        # Case 2: YAML with unquoted float
        # (oyaml loads `default: 3.14` as Python float)
        self._write_col_yaml(tmp_path, "test", "test_val", "numeric", 3.14)
        self._assert_no_patch(dbconn, tmp_path)

    def test_null_default(self, dbconn, tmp_path):
        """
        A null default should work both as the string 'null' and as
        YAML-loaded Python None (from `default: null`).
        Neither should cause errors or trigger spurious re-application.
        """
        Tables.add_table(tmp_path, "test")

        # Case 1: string 'null' — normal programmatic/CLI usage
        Columns.add_col(
            path=tmp_path,
            table="test",
            column="test_val",
            coltype="integer",
            default="null",
        )
        self.flush(dbconn, tmp_path)

        defs = Columns.read_defs_from_db(dbconn)
        assert "default" not in defs[("test", "test_val")]

        # No spurious re-application after second read
        self._assert_no_patch(dbconn, tmp_path)

        # Case 2: YAML with null
        # (oyaml loads `default: null` as Python None)
        self._write_col_yaml(tmp_path, "test", "test_val", "integer", None)
        self._assert_no_patch(dbconn, tmp_path)
