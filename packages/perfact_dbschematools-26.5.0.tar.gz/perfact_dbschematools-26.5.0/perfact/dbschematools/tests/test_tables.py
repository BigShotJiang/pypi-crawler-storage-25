from ..plugins.tables import Tables
from .testenv import TestEnv


class TestTables(TestEnv):
    def test_create_table(self, dbconn, tmp_path):
        """
        Add a table, execute patch, check that it has the expected columns
        """
        Tables.add_table(tmp_path, "test")
        self.flush(dbconn, tmp_path)
        res = dbconn.execute("select * from test")
        assert res.names == (
            "test_id",
            "test_createtime",
            "test_creator",
            "test_modtime",
            "test_author",
        )
