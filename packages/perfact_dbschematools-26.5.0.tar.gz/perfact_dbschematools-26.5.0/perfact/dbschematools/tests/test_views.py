import argparse
import os

import pytest

from ..plugins.columns import Columns
from ..plugins.tables import Tables
from ..plugins.views import Views, views_equivalent
from .testenv import TestEnv


class TestViews(TestEnv):
    def test_parser(self, tmp_path):
        "Check that the arguments work as expected"
        parser = argparse.ArgumentParser()
        Views.add_args(parser)
        args = parser.parse_args(
            [
                "test_sel",
                "--reltable",
                "test",
                "select test_id as id, test_name as name from test",
            ]
        )
        args.path = tmp_path
        Views.add(args)
        assert os.path.exists(f"{tmp_path}/tables/test/views/test_sel.sql")

    def test_invalid_viewname(self, tmp_path):
        "Check that views must obey our naming rules"
        with pytest.raises(ValueError):
            Views.add_view(tmp_path, "viewtest %sel", "select 1")
        assert not os.path.exists(f"{tmp_path}/views")

    def test_invalid_paths(self, tmp_path):
        "Check that applying invalid viewnames skips them"
        os.makedirs(f"{tmp_path}/views")
        os.makedirs(f"{tmp_path}/tables/test/views")
        for fname in [
            "views/wrong.txt",
            "views/correct.sql",
            "tables/test/views/correct.sql",
            "views/this is invalid.sql",
        ]:
            with open(f"{tmp_path}/{fname}", "w") as f:
                print("select 1", file=f)
        views = Views()
        views.read(tmp_path)
        # Even though there are two definitions with correct filename, they
        # refer to the same viewname
        assert len(views.views) == 1

    def test_create_and_replace_view(self, dbconn, tmp_path):
        """
        Create a table, column and view definition. Check that the view
        definition is only updated if it actually changes.
        """
        Tables.add_table(tmp_path, "viewtest")
        Columns.add_col(tmp_path, "viewtest", "viewtest_name", "text")

        def add(viewdef: str):
            Views.add_view(tmp_path, "viewtest_sel", viewdef, "viewtest")

        add("select 1 as id, viewtest_name as name from viewtest")
        res = self.flush(dbconn, tmp_path)
        assert "view.create viewtest_sel" in res

        # Now change view definition, but only in a non-relevant way
        add("""
            select
              1 as id,
              Viewtest_Name as name
            from viewtest
        """)
        res = self.flush(dbconn, tmp_path)
        assert len(res) == 0

        # Now change it in a relevant way
        add("""
            select
              2 as id,
              Viewtest_Name as name
            from viewtest
        """)
        res = self.flush(dbconn, tmp_path)[0].split("\n")
        assert "view.del viewtest_sel" in res
        assert "view.create viewtest_sel" in res

        # We can even handle a complete signature change
        add("select 'test' as name, 5 as id")
        res = self.flush(dbconn, tmp_path)[0].split("\n")
        assert "view.del viewtest_sel" in res
        assert "view.create viewtest_sel" in res
        res = dbconn.execute("select * from viewtest_sel")
        assert res.names == ("name", "id")

    def test_create_in_order(self, dbconn, tmp_path):
        """
        Add three views, where va and vc depend on vb. Check that all three are
        created, so the order actually respects dependencies.
        """
        Views.add_view(tmp_path, "va", "select * from vb")
        Views.add_view(tmp_path, "vb", "select 1 as id")
        Views.add_view(tmp_path, "vc", "select * from vb")
        self.flush(dbconn, tmp_path)
        assert dbconn.execute("select * from va").names == ("id",)
        assert dbconn.execute("select * from vc").names == ("id",)

    def test_dependency_order(self, dbconn, tmp_path):
        """
        Create two views, where A depends on B.
        Change the signature of B so the columns are provided in a different
        order. Make sure that A is correctly recreated after B is teared down
        and recreated.
        """
        Views.add_view(tmp_path, "vb", "select 1 as id, 'test' as name")
        Views.add_view(tmp_path, "va", "select id, name from vb")
        self.flush(dbconn, tmp_path)
        Views.add_view(tmp_path, "vb", "select 'test' as name, 1 as id")
        self.flush(dbconn, tmp_path)
        assert dbconn.execute("select * from va").names == ("id", "name")
        assert dbconn.execute("select * from vb").names == ("name", "id")

    def test_hist_views(self, dbconn, tmp_path):
        """
        Create a view and two views, one in schema public and one in history,
        that depend on it. Change the view definition and chech that both are
        recreated.
        """
        Views.add_view(tmp_path, "va", "select 1 as id, 'test' as name")
        Views.add_view(tmp_path, "vb", "select id, name from va")
        self.flush(dbconn, tmp_path)
        dbconn.execute("create schema hist")
        dbconn.execute("create view hist.vb as select id, name from va")
        Views.add_view(tmp_path, "va", "select 'test' as name, 1 as id")
        self.flush(dbconn, tmp_path)
        assert (
            dbconn.execute(
                "select count(*) from pg_views where viewname = 'vb'"
            ).tuples[0][0]
            == 2
        )

    def test_vieweq(self):
        """
        Check equivalency
        """
        assert views_equivalent(
            """select 1 from test""",
            """
              select
                1
              from test
            """,
        )
        # Can not be recognized to be equivalent from just the AST parsing
        assert not views_equivalent(
            """select * from test_sel""",
            """select id, name, deleted from test_sel""",
        )
        assert not views_equivalent(
            """
              select
                pdord_id,
                pdordhd_id
              from pdord
              join pdordhd
                on pdordhd_id = pdord_pdordhd_id
            """,
            """
              select
                pdord.pdord_id,
                pdordhd.pdordhd_id
              from pdord
              join pdordhd
                on pdordhd_id = pdord_pdordhd_id
            """,
        )
