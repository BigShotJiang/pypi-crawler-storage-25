from argparse import Namespace

from ..commands.patch import Patch


class TestEnv:
    def flush(self, dbconn, tmp_path):
        """
        After preparing some definitions, execute the patch
        """
        return Patch().run(
            config={},
            args=Namespace(
                path=[tmp_path],
                execute=True,
            ),
            dbconn=dbconn,
        )
