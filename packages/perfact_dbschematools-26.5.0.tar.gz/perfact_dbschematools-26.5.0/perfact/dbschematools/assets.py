#!/usr/bin/python3
import os

from perfact.fileassets import FileAssets

assets = FileAssets(basepath=os.path.dirname(__file__) + "/assets/")
