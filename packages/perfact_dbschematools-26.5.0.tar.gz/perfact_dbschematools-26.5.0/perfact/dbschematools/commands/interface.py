from abc import ABC, abstractmethod
from argparse import ArgumentParser, Namespace

from perfact.dbutils.conn import Connection


class Command(ABC):
    """
    Each command describes one subcommand of the main
    "perfact-dbschema" command, with its own further arguments
    and what to do when called with these
    """

    @staticmethod
    @abstractmethod
    def add_args(parser: ArgumentParser):
        """
        Define arguments for subparser of the given command.
        """

    @abstractmethod
    def run(self, config: dict, args: Namespace, dbconn: Connection):
        """
        Execute the given command with the given configuration, provided
        arguments and the given database connection.
        """
