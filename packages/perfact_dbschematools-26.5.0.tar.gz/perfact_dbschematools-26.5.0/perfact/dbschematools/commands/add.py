#!/usr/bin/python3

from ..plugins import plugins
from ..utils import add_subcmds
from .interface import Command


class Add(Command):
    """
    Add a definition to the file system structure.
    """

    # Returns a list of statements to execute for applying the corresponding
    # changes. Note that these don't check the current schema and don't try to
    # create a list of statements in the correct order, they simply are meant
    # for application by the table manager as long as not everything is handled
    # here.
    @staticmethod
    def add_args(parser):
        parser.add_argument("path", help="Path with schema definition files")
        parser.add_argument(
            "--return-patch",
            action="store_true",
            help="""Return queries to execute to pre-apply the changes on a
            best-guess basis. Note that this does not check which changes
            actually are needed and does not check dependencies.""",
        )
        add_subcmds(parser, plugins, key="type")

    def run(self, config, args, dbconn):
        result = args.type.add(args)
        if args.return_patch:
            return result
