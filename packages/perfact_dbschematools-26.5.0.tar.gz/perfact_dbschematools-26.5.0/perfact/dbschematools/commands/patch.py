#!/usr/bin/python3
import os

import psycopg2.errors

from ..plugins import plugins
from .interface import Command


class Patch(Command):
    """
    Execute patch statements to extend the current DB to fulfill the schema
    definition.
    """

    @staticmethod
    def add_args(parser):
        parser.add_argument(
            "path", nargs="+", help="Paths with schema definition files"
        )
        parser.add_argument(
            "--execute",
            action="store_true",
            help="Execute generated statements (deprecated, always executes)",
        )

    def run(self, config, args, dbconn):
        instances = [plugin() for plugin in plugins]
        for path in args.path:
            if not os.path.isdir(path):
                continue
            for instance in instances:
                instance.read(path)

        result = []
        for instance in instances:
            result.extend(instance.mkpatch(dbconn))

        for patch in result:
            try:
                dbconn.execute(patch["query"])
            except psycopg2.errors.Error as err:
                print("ERROR:", err)
            finally:
                dbconn.execute("commit; begin")
        # Return a shorter output for stdout during execution
        return [patch["title"] for patch in result]
