#!/usr/bin/python3

from ..plugins import plugins
from .interface import Command


class Dump(Command):
    """
    Dump everything found in the DB
    """

    @staticmethod
    def add_args(parser):
        parser.add_argument("path", help="Path with schema definition files")

    def run(self, config, args, dbconn):
        for cmd in plugins:
            cmd.dump(args.path, dbconn)
