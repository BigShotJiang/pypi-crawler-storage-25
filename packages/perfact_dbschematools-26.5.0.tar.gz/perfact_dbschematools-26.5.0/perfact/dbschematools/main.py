#!/usr/bin/python3
import os
from argparse import ArgumentParser, Namespace

import psycopg2
from perfact.dbutils.conn import Connection, ZRDBConnectionWrapper

from .commands.add import Add
from .commands.dump import Dump
from .commands.patch import Patch
from .utils import add_subcmds, yaml_dump, yaml_load

default_connstr = "dbname=perfactema user=zope application_name=dbschematools"


def main(args=None):
    """
    Main entrypoint. Handles different actions using subparsers of argparse.
    If the action returns something other than None, the result is printed as
    yaml.
    """
    parser = ArgumentParser("Handle necessary schema changes of a perfactema database")
    parser.add_argument(
        "--config",
        help="Configuration file",
        default="/etc/perfact/dbschematools/config.yaml",
    )
    add_subcmds(parser, [Patch, Add, Dump])
    args = parser.parse_args(args)

    config = {
        "connstr": default_connstr,
    }
    if os.path.exists(args.config):
        config.update(yaml_load(args.config))
    conn = psycopg2.connect(config["connstr"])
    conn.autocommit = True
    result = args.command().run(config, args, Connection(conn))
    if result is not None:
        print(yaml_dump(result))


def patch(path: str, connstr: str = default_connstr, dbconn=None):
    """
    Entrypoint for usage from other packages or from Zope
    I.e.:
    from perfact.dbschematools import patch
    patch(myinitpath, connstr)

    If dbconn is given, it is for usage from within Zope, providing a ZRDB
    Connection.
    """
    if dbconn is not None:
        dbconn = ZRDBConnectionWrapper(dbconn)
    else:
        conn = psycopg2.connect(connstr)
        conn.autocommit = True
        dbconn = Connection(conn)
    return Patch().run({}, Namespace(path=[path]), dbconn)
