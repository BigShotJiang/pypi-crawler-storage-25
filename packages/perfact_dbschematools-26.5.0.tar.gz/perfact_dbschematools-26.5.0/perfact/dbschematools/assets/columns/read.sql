select
  table_name collate "POSIX" as tablename,
  column_name collate "POSIX" as name,
  udt_name || coalesce('(' || character_maximum_length || ')', '') as type,
  column_default as default

from information_schema.columns

where table_schema not in ('pg_catalog', 'information_schema', 'hist')
  -- only valid table names
  and table_name ~ '^[a-z0-9]+$'
  -- no hist tables
  and table_name !~ 'hist$'
  -- only columns from base tables, not views
  and table_name in (
    select table_name
    from information_schema.tables
    where table_type = 'BASE TABLE'
    and table_schema not in ('pg_catalog', 'information_schema', 'hist')
  )
order by tablename, ordinal_position
