alter table {tablename}
  alter column {colname} type {coltype};
