alter table {tablename} add column if not exists
  {colname} {coltype}
;
