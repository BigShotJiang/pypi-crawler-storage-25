do $$
  declare
    cur_default text;
  begin
    select
      column_default
    into
      cur_default
    from information_schema.columns
    where table_schema not in ('pg_catalog', 'information_schema', 'hist')
      and table_name = '{tablename}'
      and column_name = '{colname}'
    ;

    if cur_default is distinct from {coldefault_esc} then
      alter table {tablename}
        alter column {colname} set default {coldefault};
    end if;
  end
$$;
