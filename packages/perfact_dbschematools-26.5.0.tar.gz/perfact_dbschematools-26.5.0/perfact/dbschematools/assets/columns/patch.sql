do $$
  declare
    cur_type text;
  begin
    select
      udt_name || coalesce('(' || character_maximum_length || ')', '')
    into
      cur_type
    from information_schema.columns
    where table_schema not in ('pg_catalog', 'information_schema', 'hist')
      and table_name = '{tablename}'
      and column_name = '{colname}'
    ;

    if cur_type is null then
      -- Column does not exist yet
      alter table {tablename} add column if not exists
        {colname} {coltype}
      ;
    end if;

    if cur_type::regtype != '{coltype}'::regtype then
      alter table {tablename}
        alter column {colname} type {coltype};
    end if;
  end
$$;
