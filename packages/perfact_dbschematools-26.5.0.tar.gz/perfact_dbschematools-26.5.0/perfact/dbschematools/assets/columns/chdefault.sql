alter table {tablename}
  alter column {colname} set default {coldefault};
