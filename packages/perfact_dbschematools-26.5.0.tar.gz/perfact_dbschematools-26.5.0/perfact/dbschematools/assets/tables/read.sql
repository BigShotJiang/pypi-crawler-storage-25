select
  table_name collate "POSIX" as name
from information_schema.tables
where table_schema not in ('pg_catalog', 'information_schema', 'hist')
  and table_type = 'BASE TABLE'
  and not (table_name ~ '.*hist$')
order by 1
