create sequence if not exists {table}_s minvalue 1001;
create table if not exists {table} (
  {table}_id bigint not null default nextval('{table}_s'),
  {table}_createtime timestamp with time zone not null default now(),
  {table}_creator varchar(80) default db_username(),
  {table}_modtime timestamp with time zone not null default now(),
  {table}_author varchar(80) default db_username(),
  primary key({table}_id)
);
alter sequence {table}_s owned by {table}.{table}_id;
