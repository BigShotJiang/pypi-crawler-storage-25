create or replace function public.db_username()
 returns text
 language plpgsql
 strict
as $function$
begin
  return 'testrunner';
end;
$function$
