select
  case when cascade_ns.nspname = 'hist' then 'hist.' else '' end || cascade_table.relname as target,
  array_agg(
    distinct
      case when origin_ns.nspname = 'hist' then 'hist.' else '' end
      || origin_table.relname
      order by case when origin_ns.nspname = 'hist' then 'hist.' else '' end || origin_table.relname
  ) as source
from pg_depend
join pg_rewrite
  on pg_rewrite.oid = pg_depend.objid
join pg_class as cascade_table
  on cascade_table.oid = pg_rewrite.ev_class
join pg_class as origin_table
  on origin_table.oid = pg_depend.refobjid
 and origin_table.oid <> cascade_table.oid
join pg_namespace as cascade_ns
  on cascade_ns.oid = cascade_table.relnamespace
join pg_namespace as origin_ns
  on origin_ns.oid = origin_table.relnamespace
where origin_ns.nspname not in ('pg_catalog', 'information_schema', 'repack')
  and cascade_ns.nspname not in ('pg_catalog', 'information_schema', 'repack')
  and origin_table.relkind = 'v'
group by 1
order by 1
