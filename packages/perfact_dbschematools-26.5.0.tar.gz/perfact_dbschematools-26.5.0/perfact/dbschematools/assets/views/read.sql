select
  -- We do not allow multiple views with the same name in different schemas -
  -- except for the hist schema
  case when nspname = 'hist' then 'hist.' else '' end || cls.relname as viewname,
  pg_get_viewdef(cls.oid) as viewdef

from pg_class as cls
join pg_namespace as nsp
  on nsp.oid = cls.relnamespace
where relkind = 'v'
  and nspname NOT IN ('pg_catalog', 'information_schema', 'repack')
