#!/usr/bin/python3

from .columns import Columns
from .tables import Tables
from .views import Views

plugins = [Tables, Columns, Views]
