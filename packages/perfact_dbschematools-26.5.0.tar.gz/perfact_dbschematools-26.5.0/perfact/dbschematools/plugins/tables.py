#!/usr/bin/python3

import logging
import os
from argparse import ArgumentParser, Namespace
from typing import List

from perfact.dbutils.conn import Executor

from ..assets import assets
from ..utils import cleanup, scandir
from .interface import Plugin

logger = logging.getLogger("perfact.dbschematools")


class Tables(Plugin):
    subcommand = "table"

    @staticmethod
    def add_table(path: str, table: str) -> List[str]:
        """
        Add the (minimal) definition of a given table to the path
        """
        folder = f"{path}/tables/{table}"
        fname = f"{folder}/main.yml"
        if os.path.exists(fname):
            return []
        os.makedirs(folder, exist_ok=True)
        with open(fname, "w") as f:
            print("---", file=f)
        return [assets["tables.create"].format(table=table)]

    @staticmethod
    def add_args(parser: ArgumentParser):
        """
        Add necessary arguments for "add" command
        """
        parser.add_argument("table")

    @staticmethod
    def add(args: Namespace):
        """
        Add the (minimal) definition of a given table to the path
        """
        # Wrapper for call as subcommand
        return Tables.add_table(args.path, args.table)

    def __init__(self):
        self.tables = []

    def read(self, path: str):
        """
        Read table definitions from the schema path
        """
        for entry in scandir(f"{path}/tables"):
            table = entry.name
            if table != cleanup(table):
                logger.warning(f"Invalid table identifier: {table}")
                continue
            if table in self.tables:
                continue
            self.tables.append(table)

    def mkpatch(self, dbconn: Executor):
        """
        Generate statements for creating missing tables
        """
        existing = [row[0] for row in dbconn.execute(assets["tables.read"]).tuples]
        return [
            {
                "title": f"table {table}",
                "query": assets["tables.create"].format(table=table),
            }
            for table in self.tables
            if table not in existing
        ]

    @staticmethod
    def dump(path: str, dbconn: Executor):
        """
        Dump all tables found in the DB
        """
        existing = [row[0] for row in dbconn.execute(assets["tables.read"]).tuples]
        for table in existing:
            if cleanup(table) != table:
                logger.warning(f"Invalid table identifier: {table}")
                continue
            Tables.add_table(path, table)
