#!/usr/bin/python3

import logging
import os
from argparse import ArgumentParser, Namespace
from functools import lru_cache
from typing import Any, List, Optional

from perfact.dbutils.conn import Executor

from ..assets import assets
from ..utils import cleanup, scandir, yaml_dump, yaml_load
from .interface import Plugin

logger = logging.getLogger("perfact.dbschematools")


# See https://www.postgresql.org/docs/current/datatype.html
# The mapped-to value is what udt_type returns
aliases = {
    "bigint": "int8",
    "boolean": "bool",
    "character": "char",
    "character varying": "varchar",
    "double precision": "float8",
    "integer": "int4",
    "int": "int4",
    "float": "float8",
    "timestamp with time zone": "timestamptz",
    "timestamp without time zone": "timestamp",
}


@lru_cache
def table_basecols(table: str) -> dict:
    """
    Default columns to be included with every table.
    """
    return {
        f"{table}_id": {
            "type": "int8",
            "default": f"nextval('{table}_s'::regclass)",
        },
        f"{table}_creator": {
            "type": "varchar(80)",
            "default": "db_username()",
        },
        f"{table}_author": {
            "type": "varchar(80)",
            "default": "db_username()",
        },
        f"{table}_createtime": {
            "type": "timestamptz",
            "default": "now()",
        },
        f"{table}_modtime": {
            "type": "timestamptz",
            "default": "now()",
        },
    }


def normalize_default(value):
    "Map Python booleans, numbers, and None to their SQL string equivalents"
    if isinstance(value, bool):
        return str(value).lower()
    if isinstance(value, (int, float)):
        return str(value)
    if value is None:
        return "null"
    return value


def map_none(value: Any) -> Any:
    "Map None to null, otherwise return as-is"
    return normalize_default(value)


def coldefault_esc(default: Optional[str]) -> str:
    """
    Simple escaping for stuff that can be in the string that represents a
    column default in information_schema.columns for comparison in the query.
    """
    default = normalize_default(default)
    return "null" if default == "null" else "'{}'".format(default.replace("'", "''"))


class Columns(Plugin):
    subcommand = "column"

    @staticmethod
    def add_args(parser: ArgumentParser):
        parser.add_argument("table", help="Name of table")
        parser.add_argument("column", help="Name of column")
        parser.add_argument("coltype", help="Type of column")
        parser.add_argument("default", nargs="?", help="Default value")

    @staticmethod
    def add_col(
        path: str, table: str, column: str, coltype: str, default: Optional[str] = None
    ) -> List[str]:
        """
        Add the definition of a given table column to the path
        """
        folder = f"{path}/tables/{table}/columns"
        fname = f"{folder}/{column}.yml"
        if not os.path.isdir(folder):
            os.makedirs(folder, exist_ok=True)
        current: dict[str, str] = {}
        if os.path.exists(fname):
            current = yaml_load(fname) or {}
        coldef = {
            "type": coltype,
        }
        if default is not None:
            coldef["default"] = default
        if current != coldef:
            yaml_dump(coldef, filename=fname)
        result = [
            assets["columns.patch"].format(
                tablename=table,
                colname=column,
                coltype=coltype,
                coldefault=map_none(default),
                coldefault_esc=coldefault_esc(default),
            )
        ]
        if default is not None:
            result.append(
                assets["columns.patch_default"].format(
                    tablename=table,
                    colname=column,
                    coldefault=default,
                    coldefault_esc=coldefault_esc(default),
                )
            )
        return result

    @staticmethod
    def add(args: Namespace) -> List[str]:
        """
        Add the definition of a given table column to the path
        """
        # Wrapper for call as subcommand
        return Columns.add_col(
            path=args.path,
            table=args.table,
            column=args.column,
            coltype=args.coltype,
            default=args.default,
        )

    def __init__(self):
        self.cols = {}

    def read(self, path: str):
        """
        Read column definitions from
        {path}/tables/{table}/columns/{column}.yml
        """
        for entry in scandir(f"{path}/tables"):
            table = entry.name
            basecols = table_basecols(table)
            if not entry.is_dir():
                logger.warning(f"Path is not a dir: {entry.path}")
                continue
            if cleanup(table) != table:
                logger.warning(f"Invalid tablename: {table}")
                continue
            self.cols.update({(table, col): values for col, values in basecols.items()})
            for col in scandir(f"{entry.path}/columns"):
                if not col.is_file():
                    logger.warning(f"Path is not a file: {col.path}")
                    continue
                colname = col.name.split(".")[0]
                if colname != cleanup(colname, add_allow="_"):
                    logger.warning(f"Invalid column name: {colname}")
                    continue
                ident = (table, colname)
                if ident in self.cols and colname not in basecols:
                    logger.warning(f"Duplicate definition for col: {ident}")
                    continue
                coldef = yaml_load(col.path)
                if "default" in coldef:
                    coldef["default"] = normalize_default(coldef["default"])

                # Map part until ( using aliases before comparing
                parts = coldef["type"].split("(")
                if parts[0] in aliases:
                    parts[0] = aliases[parts[0]]
                coldef["type"] = "(".join(parts)
                self.cols[ident] = coldef

    @staticmethod
    def read_defs_from_db(dbconn: Executor) -> dict:
        existing = {}
        for row in dbconn.execute(assets["columns.read"]).rows():
            item = {"type": row.type}
            if row.default is not None:
                item["default"] = row.default
            existing[(row.tablename, row.name)] = item
        return existing

    def mkpatch(self, dbconn: Executor) -> List[dict[str, str]]:
        """
        Generate patch statements for missing or mismatched columns
        """
        existing = self.read_defs_from_db(dbconn)

        query = assets["columns.create"]
        result = [
            {
                "title": f"col.create {':'.join(ident)}",
                "query": query.format(
                    tablename=ident[0],
                    colname=ident[1],
                    coltype=coldef["type"],
                ),
            }
            for ident, coldef in self.cols.items()
            if ident not in existing
        ]
        query = assets["columns.chtype"]
        result.extend(
            [
                {
                    "title": f"col.settype {':'.join(ident)}",
                    "query": query.format(
                        tablename=ident[0],
                        colname=ident[1],
                        coltype=coldef["type"],
                    ),
                }
                for ident, coldef in self.cols.items()
                if ident in existing and existing[ident]["type"] != coldef["type"]
            ]
        )
        query = assets["columns.chdefault"]
        result.extend(
            [
                {
                    "title": f"col.setdefault {':'.join(ident)}",
                    "query": query.format(
                        tablename=ident[0],
                        colname=ident[1],
                        coldefault=map_none(coldef.get("default")),
                    ),
                }
                for ident, coldef in self.cols.items()
                if "default" in coldef
                and existing.get(ident, {}).get("default", "null") != coldef["default"]
            ]
        )
        return result

    @staticmethod
    def dump(path: str, dbconn: Executor):
        for col in dbconn.execute(assets["columns.read"]).rows():
            if cleanup(col.tablename) != col.tablename:
                logger.warning(f"Invalid tablename: {col.tablename}")
                continue
            if cleanup(col.name, add_allow="_") != col.name:
                logger.warning(f"Invalid colname: {col.name}")
                continue

            basecols = table_basecols(col.tablename)
            if col.name in basecols:
                # Only skip if the type actually also deviates, to i.e. keep
                # text vs. varchar(80). But if only the default deviates, we
                # want to have the standard default.
                default_def = basecols[col.name]
                if col.type == default_def["type"]:
                    continue
                col.default = default_def["default"]

            Columns.add_col(
                path=path,
                table=col.tablename,
                column=col.name,
                coltype=col.type,
                default=col.default,
            )
