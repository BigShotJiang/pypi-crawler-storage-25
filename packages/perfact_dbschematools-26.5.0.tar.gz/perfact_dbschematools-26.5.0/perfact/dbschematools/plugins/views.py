#!/usr/bin/python3
# import logging
import logging
import os
from argparse import ArgumentParser, Namespace
from typing import Optional

import pglast.parser
from perfact.dbutils.conn import Executor
from perfact.generic import topological_sort

from ..assets import assets
from ..utils import cleanup, scandir
from .interface import Plugin

logger = logging.getLogger("perfact.dbschematools")


class Views(Plugin):
    """
    Handle view definitions and their dependencies
    """

    subcommand = "view"

    @staticmethod
    def add_args(parser: ArgumentParser):
        """
        Add arguments for the "add" command for adding an entity to the schema
        definition.
        """
        parser.add_argument("viewname", type=str, help="Name of the view")
        parser.add_argument(
            "--reltable", type=str, help="Table the view relates to primarily"
        )
        parser.add_argument("viewdef", type=str, help="View definition")

    @staticmethod
    def add(args: Namespace) -> list[str]:
        """
        Call the "add" command for this entity with the arguments provided by
        the argument parser.
        Returns a list of statements that can be executed to directly
        create/update the given entity.
        """
        return Views.add_view(
            path=args.path,
            name=args.viewname,
            viewdef=args.viewdef,
            table=args.reltable,
        )

    @staticmethod
    def add_view(
        path: str, name: str, viewdef: str, table: Optional[str] = None
    ) -> list[str]:
        if name != cleanup(name, add_allow="_"):
            raise ValueError(f"Invalid name: {name}")
        pglast.parse_sql(viewdef)  # Check syntax
        parent = f"{path}/views"
        if table:
            parent = f"{path}/tables/{table}/views"
        os.makedirs(parent, exist_ok=True)
        with open(f"{parent}/{name}.sql", "w") as f:
            f.write(viewdef)
        return [f"create or replace view {name} as {viewdef}"]

    def __init__(self):
        # viewname -> dict with definition, dependencies and ast
        self.views = {}

    def read(self, path: str):
        """
        Read entity definitions from the given path and add/update internal
        structures that can later be used in "mkpatch".
        """

        def add(view):
            parts = view.name.split(".")
            if len(parts) != 2 or parts[1] != "sql" or not view.is_file():
                logger.warning(f"Invalid view definition path: {view.path}")
                return
            viewname = parts[0]
            if viewname != cleanup(viewname, add_allow="_"):
                logger.warning(f"Invalid view identifier: {view.path}")
                return
            if viewname in self.views:
                logger.warning(f"Duplicate definition for view: {view.path}")
                return
            with open(view.path) as f:
                definition = f.read()
            ast = pglast.parse_sql(definition)
            self.views[viewname] = {
                "def": definition,
                "ast": ast,
                "deps": Views.dependencies(ast),
            }

        for view in scandir(f"{path}/views"):
            add(view)
        for table in scandir(f"{path}/tables"):
            for view in scandir(f"{table.path}/views"):
                add(view)

    def mkpatch(self, dbconn: Executor) -> list[dict[str, str]]:
        """
        Generate statement for extending the database found through dbconn to
        fulfil the definitions collected by previous read calls.
        We want to make sure that all the drop and recreate statements are
        executed in the same transaction, so we only return one item.
        """
        # viewname -> definition
        current = dict(dbconn.execute(assets["views.read"]).tuples)
        todelete = set()
        tocreate = set()
        for viewname, view in self.views.items():
            if viewname in current:
                curdef = current[viewname]
                ast = pglast.parse_sql(curdef)
                if ast == view["ast"]:
                    continue
                todelete.add(viewname)
            tocreate.add(viewname)
        if not tocreate:
            return []

        curtree = dict(dbconn.execute(assets["views.dependencies"]).tuples)
        tgtviews = sorted(set(tocreate) | set(current.keys()))
        tgttree = {}
        for view in tgtviews:
            if view in tocreate:
                deps = Views.dependencies(self.views[view]["ast"])
            else:
                deps = curtree.get(view, [])
            # Filter out tables, which parsing the AST can not distinguish
            deps = [dep for dep in deps if dep in tgtviews]
            if deps:
                tgttree[view] = deps
        # Add more views to todelete according to dependencies
        # First create a reverse-lookup depedency tree (for each view list
        # which views depend on it)
        revdeps: dict[str, list[str]] = {}
        for view, deps in curtree.items():
            for dep in deps:
                if dep in revdeps:
                    revdeps[dep].append(view)
                else:
                    revdeps[dep] = [view]
        # Now add views that depend on those to be deleted
        while True:
            todelete_addition = (
                set(
                    sum(
                        [revdeps[view] for view in todelete if view in revdeps],
                        start=[],
                    )
                )
                - todelete
            )
            if not todelete_addition:
                break
            todelete |= todelete_addition

        tocreate |= todelete

        # Earlier elements depend on later ones
        cur = topological_sort(curtree)
        tgt = topological_sort(tgttree)
        # Append/Prepend those without any dependencies
        cur.extend(view for view in todelete if view not in cur)
        tgt = [view for view in tocreate if view not in tgt] + tgt
        titles = []
        queries = []
        for view in cur:
            if view not in todelete:
                continue
            titles.append(f"view.del {view}")
            queries.append(f"drop view {view}")
        for view in reversed(tgt):
            if view not in tocreate:
                continue
            if view in self.views:
                viewdef = self.views[view]["def"]
            else:
                viewdef = current[view]
            titles.append(f"view.create {view}")
            queries.append(f"create view {view} as {viewdef}")

        return [
            {
                "title": "\n".join(titles),
                "query": ";\n".join(queries),
            }
        ]

    @staticmethod
    def dump(path: str, dbconn: Executor):
        """
        Dump all schema information found in the database to schema definition
        folder.
        A heuristic is used for the "associated table" - matching the parts
        separated by _ from last to first.
        """
        views = dbconn.execute(assets["views.read"])
        tables = [entry.name for entry in scandir(f"{path}/tables") if entry.is_dir()]
        for view in views.rows():
            parts = view.viewname.split("_")
            table = None
            for part in reversed(parts):
                if part in tables:
                    table = part
                    break
            parent = path + (f"/tables/{table}" if table else "") + "/views"
            os.makedirs(parent, exist_ok=True)
            with open(f"{parent}/{view.viewname}.sql", "w") as f:
                print(view.viewdef, file=f)

    @staticmethod
    def dependencies(ast: tuple):
        """
        Extract the direct dependencies of the view definition - can be tables
        or other views.
        """

        def walk(node, result):
            if isinstance(node, dict):
                if "relname" in node:
                    if node["relname"] not in result:
                        result.append(node["relname"])
                for child in node.values():
                    walk(child, result)
            if isinstance(node, (list, tuple)):
                for child in node:
                    walk(child, result)

        result: list[str] = []
        walk(ast[0](), result)
        return result


def views_equivalent(viewa: str, viewb: str) -> bool:
    """
    Check for equivalency of view definitions.
    This is meant to be used as follows by the table manager:
    - Create a view on the database with the given view definition
    - Read the parsed view definition back
    - Compare the two for stability, i.e.: Will dbschematools recognize the
      view to be unchanged or will it always try to recreate this?
    - Only then will the view definition be added
    """
    return pglast.parse_sql(viewa) == pglast.parse_sql(viewb)
