from abc import ABC, abstractmethod
from argparse import ArgumentParser, Namespace

from perfact.dbutils.conn import Executor


class Plugin(ABC):
    """
    A plugin handles specific database entities like tables, columns, views
    etc.
    """

    @staticmethod
    @abstractmethod
    def add_args(parser: ArgumentParser):
        """
        Add arguments for the "add" command for adding an entity to the schema
        definition.
        """

    @staticmethod
    @abstractmethod
    def add(args: Namespace) -> list[str]:
        """
        Call the "add" command for this entity with the arguments provided by
        the argument parser.
        Returns a list of statements that can be executed to directly
        create/update the given entity.
        """

    @abstractmethod
    def read(self, path: str):
        """
        Read entity definitions from the given path and add/update internal
        structures that can later be used in "mkpatch".
        """

    @abstractmethod
    def mkpatch(self, dbconn: Executor) -> list[dict[str, str]]:
        """
        Generate statements for extending the database found through dbconn to
        fulfill the definitions collected by previous read calls.
        """

    @staticmethod
    @abstractmethod
    def dump(path: str, dbconn: Executor):
        """
        Dump all schema information found in the database to schema definition
        folder.
        """
