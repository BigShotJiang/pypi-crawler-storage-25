from .main import FakerRussia

__version__ = "1.0.0"
__all__ = ["FakerRussia"]