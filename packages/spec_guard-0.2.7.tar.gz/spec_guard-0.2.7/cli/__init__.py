"""SpecGuard CLI package."""
