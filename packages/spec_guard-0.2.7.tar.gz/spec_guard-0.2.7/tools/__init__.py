"""SpecGuard tool package."""
