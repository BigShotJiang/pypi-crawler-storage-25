# Audio Spectrogram

[![PyPI - Version](https://img.shields.io/pypi/v/audio-spectrogram.svg)](https://pypi.org/project/audio-spectrogram)
[![PyPI - Python Version](https://img.shields.io/pypi/pyversions/audio-spectrogram.svg)](https://pypi.org/project/audio-spectrogram)

## Introduction

*Audio Spectrogram* is a small python GUI application to analyze the frequency content of your microphone input.

<img src="https://raw.githubusercontent.com/zariiii9003/audio_spectrogram/refs/heads/master/doc/GUI.png" width="683" alt="GUI Screenshot" />

## Usage

You can run it directly from your command line:
```bash
uvx audio-spectrogram
```
or
```bash
pipx audio-spectrogram
```
