# Copyright 2026 - 2026, Artur Drogunow and the Audio-Spectrogram contributors
# SPDX-License-Identifier: GPL-3.0-or-later

import logging
from importlib.metadata import version
from typing import Final

APP_TITLE: Final = "Audio Spectrogram"
PACKAGE_NAME: Final = "audio-spectrogram"
LOGGER: Final = logging.getLogger(PACKAGE_NAME)

__version__ = version(PACKAGE_NAME)
