# Copyright 2026 - 2026, Artur Drogunow and the Audio-Spectrogram contributors
# SPDX-License-Identifier: GPL-3.0-or-later

import argparse
import sys

from audio_spectrogram import LOGGER, __version__
from audio_spectrogram.app.application import Application
from audio_spectrogram.util import setup_logging


def main() -> None:
    # parse arguments
    parser = argparse.ArgumentParser()
    parser.add_argument(
        "-v",
        "--verbose",
        action="count",
        default=0,
        help="Increase verbosity (-v, -vv, -vvv)",
    )
    args = parser.parse_args()

    # setup logging
    setup_logging(verbosity=args.verbose)
    LOGGER.info("Executable: %s %s", sys.executable, " ".join(sys.argv))
    LOGGER.info("Version: %s", __version__)

    while True:
        restart = Application.run_application()
        if not restart:
            break


if __name__ == "__main__":
    main()
