# Copyright 2026 - 2026, Artur Drogunow and the Audio-Spectrogram contributors
# SPDX-License-Identifier: GPL-3.0-or-later

import datetime
import logging
from typing import Final

from platformdirs import user_log_path

from audio_spectrogram import APP_TITLE, LOGGER, PACKAGE_NAME

VERBOSITY_LEVEL_APP_DEBUG: Final = 1
VERBOSITY_LEVEL_ROOT_WARNING: Final = 1
VERBOSITY_LEVEL_ROOT_INFO: Final = 2
VERBOSITY_LEVEL_ROOT_DEBUG: Final = 3


def setup_logging(verbosity: int) -> None:
    iso_date = datetime.datetime.now(tz=datetime.UTC).strftime("%Y-%m-%d")
    logfile_path = user_log_path(PACKAGE_NAME, ensure_exists=True) / f"{iso_date}.log"

    with logfile_path.open(mode="at") as file:
        if file.tell() > 0:
            file.write("\n\n")
        file.writelines(
            [
                "*" * 80 + "\n",
                f"Start {APP_TITLE}".center(80) + "\n",
                "*" * 80 + "\n",
            ]
        )

    # instantiate logging handlers
    file_handler = logging.FileHandler(logfile_path)
    stream_handler = logging.StreamHandler()

    # configure formatting
    formatter = logging.Formatter("%(asctime)s - %(name)s - %(levelname)s - %(message)s")
    file_handler.setFormatter(formatter)
    stream_handler.setFormatter(formatter)

    # determine log levels for app (package_level) and dependencies (root_level)
    package_level = logging.DEBUG if verbosity >= VERBOSITY_LEVEL_APP_DEBUG else logging.INFO
    if verbosity >= VERBOSITY_LEVEL_ROOT_DEBUG:
        root_level = logging.DEBUG
    elif verbosity >= VERBOSITY_LEVEL_ROOT_INFO:
        root_level = logging.INFO
    elif verbosity >= VERBOSITY_LEVEL_ROOT_WARNING:
        root_level = logging.WARNING
    else:
        root_level = logging.ERROR

    # configure root logger
    root_logger = logging.getLogger()
    root_logger.handlers.clear()
    root_logger.setLevel(root_level)
    root_logger.addHandler(file_handler)
    root_logger.addHandler(stream_handler)

    # configure package logger
    LOGGER.setLevel(package_level)
    LOGGER.info("Root log level: %s", logging.getLevelName(root_level))
    LOGGER.info("Package log level: %s", logging.getLevelName(package_level))
