# Copyright 2026 - 2026, Artur Drogunow and the Audio-Spectrogram contributors
# SPDX-License-Identifier: GPL-3.0-or-later

import numpy as np
import numpy.typing as npt
from PySide6.QtCore import QObject

from audio_spectrogram import LOGGER

from .spectrogram import SpectrogramData
from .widgets.plot_widget import PlotWidget


class PlotHandler(QObject):
    def __init__(self, plot_widget: PlotWidget) -> None:
        super().__init__()

        # variables
        self.configured = False
        self.recording_duration: float = 20.0  # seconds
        self.time_plot_length: int = 1
        self.time_plot_x: npt.NDArray[np.float32] = np.zeros(self.time_plot_length).astype(np.float32)
        self.time_plot_y: npt.NDArray[np.float32] = np.zeros(self.time_plot_length).astype(np.float32)
        self.spec_plot_data: SpectrogramData | None = None

        # widgets
        self.plot_widget = plot_widget

        # setup
        self._setup_widgets()
        self._setup_layout()
        self._connect_signals()

    def _setup_widgets(self) -> None:
        pass

    def _setup_layout(self) -> None:
        pass

    def _connect_signals(self) -> None:
        pass

    def start(self, sample_rate: int, window_size: int, hop_size: int) -> None:
        LOGGER.info(
            "%s.%s(sample_rate=%d, window_size=%d, hop_size=%d)",
            self.__class__.__name__,
            self.start.__name__,
            sample_rate,
            window_size,
            hop_size,
        )
        # configure timeseries
        self.time_plot_length = round(self.recording_duration * sample_rate)
        self.time_plot_x = np.linspace(-self.recording_duration, 0, self.time_plot_length).astype(
            np.float32
        )
        self.time_plot_y = np.zeros(self.time_plot_length).astype(np.float32)
        self.plot_widget.time_plot_item.setData(x=self.time_plot_x, y=self.time_plot_y)
        self.plot_widget.time_plot.setXRange(-0.1, 0)

        # configure spectrogram
        self.spec_plot_data = SpectrogramData(
            window_size=window_size,
            hop_size=hop_size,
            frame_count=round(self.recording_duration * sample_rate / hop_size),
        )
        self.plot_widget.spec_plot_item.setImage(self.spec_plot_data.image, autoLevels=False)
        self.plot_widget.spec_plot_item.setRect(
            -self.recording_duration,
            0,
            self.recording_duration,
            sample_rate / 2,
        )
        self.plot_widget.spec_plot.setYRange(0, sample_rate / 2)

        self.configured = True

    def stop(self) -> None:
        LOGGER.info("%s.%s()", self.__class__.__name__, self.stop.__name__)
        self.configured = False

    def on_new_data(self, data: npt.NDArray[np.float32]) -> None:
        LOGGER.debug("%s.%s(%d bytes)", self.__class__.__name__, self.on_new_data.__name__, data.size)
        if not self.configured or self.spec_plot_data is None:
            return

        # plot timeseries
        self.time_plot_y = np.hstack((self.time_plot_y, data))[-self.time_plot_length :]
        self.plot_widget.time_plot_item.setData(x=self.time_plot_x, y=self.time_plot_y)

        # plot spectrogram
        self.spec_plot_data.push(data)
        self.plot_widget.spec_plot_item.setImage(self.spec_plot_data.image, autoLevels=False)

    def post_visible_setup(self) -> None:
        LOGGER.info("%s.%s()", self.__class__.__name__, self.post_visible_setup.__name__)
        # warmup jit compilation
        spec_plot_data = SpectrogramData(
            window_size=1024,
            hop_size=256,
            frame_count=128,
        )
        spec_plot_data.push(np.zeros(10_000).astype(np.float32))
        self.plot_widget.spec_plot_item.setImage(spec_plot_data.image, autoLevels=False)

    def cleanup(self) -> None:
        pass
