# Copyright 2026 - 2026, Artur Drogunow and the Audio-Spectrogram contributors
# SPDX-License-Identifier: GPL-3.0-or-later

from PySide6.QtCore import QEventLoop, QObject

from audio_spectrogram import LOGGER

from .control_panel_handler import ControlPanelHandler, Settings
from .plot_handler import PlotHandler
from .qapplication import get_qapplication
from .widgets.main_window import MainWindow


class Application(QObject):
    def __init__(self) -> None:
        super().__init__()

        self.qapp = get_qapplication()
        self.restart = False
        self.main_window = MainWindow()
        self.control_panel_handler = ControlPanelHandler(self.main_window.control_panel_widget)
        self.plot_handler = PlotHandler(self.main_window.plot_widget)

        self._setup_widgets()
        self._connect_signals()

    def _setup_widgets(self) -> None:
        pass

    def _connect_signals(self) -> None:
        self.control_panel_handler.start.connect(self.on_capture_start)
        self.control_panel_handler.stop.connect(self.on_capture_stop)
        self.control_panel_handler.data.connect(self.plot_handler.on_new_data)

    def on_capture_start(self, settings: Settings) -> None:
        LOGGER.info("%s.%s(%s)", self.__class__.__name__, self.on_capture_start.__name__, settings)
        self.plot_handler.start(
            sample_rate=settings.sample_rate,
            window_size=settings.window_size,
            hop_size=settings.hop_size,
        )

    def on_capture_stop(self) -> None:
        LOGGER.info("%s.%s()", self.__class__.__name__, self.on_capture_stop.__name__)
        self.plot_handler.stop()

    def start_gui(self) -> None:
        LOGGER.info("%s.%s()", self.__class__.__name__, self.start_gui.__name__)
        self.main_window.setEnabled(False)
        self.main_window.show()

        # process events twice to avoid all white main window
        self.qapp.processEvents(QEventLoop.ProcessEventsFlag.AllEvents)
        self.qapp.processEvents(QEventLoop.ProcessEventsFlag.AllEvents)

        # post-visible setup
        self.control_panel_handler.post_visible_setup()
        self.plot_handler.post_visible_setup()

        # re-enable window
        self.main_window.setEnabled(True)

    def cleanup(self) -> None:
        LOGGER.info("%s.%s()", self.__class__.__name__, self.cleanup.__name__)
        self.control_panel_handler.cleanup()
        self.plot_handler.cleanup()

    @staticmethod
    def run_application() -> bool:
        """Return True to restart application."""
        LOGGER.info("Instantiate GUI")
        app = Application()
        app.start_gui()

        LOGGER.info("Register cleanup callback")
        app.qapp.aboutToQuit.connect(app.cleanup)

        LOGGER.info("Run Qt event loop")
        app.qapp.exec()

        return app.restart
