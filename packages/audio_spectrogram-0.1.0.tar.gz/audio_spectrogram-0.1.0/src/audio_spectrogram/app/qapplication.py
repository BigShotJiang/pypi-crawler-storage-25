# Copyright 2026 - 2026, Artur Drogunow and the Audio-Spectrogram contributors
# SPDX-License-Identifier: GPL-3.0-or-later

from typing import cast

from PySide6.QtWidgets import QApplication

from audio_spectrogram import APP_TITLE


def get_qapplication() -> QApplication:
    instance = cast("QApplication | None", QApplication.instance())
    if instance is not None:
        return instance

    return create_qapplication()


def create_qapplication() -> QApplication:
    # create instance
    qt_app = QApplication()

    # set app title
    qt_app.setApplicationName(APP_TITLE)

    return qt_app
