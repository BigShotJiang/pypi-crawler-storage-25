# Copyright 2026 - 2026, Artur Drogunow and the Audio-Spectrogram contributors
# SPDX-License-Identifier: GPL-3.0-or-later

from collections.abc import Iterable
from typing import Final

from PySide6.QtCore import QSignalBlocker
from PySide6.QtWidgets import (
    QComboBox,
    QGroupBox,
    QHBoxLayout,
    QLabel,
    QPushButton,
    QVBoxLayout,
)

from .combobox import ComboBoxWithSignal
from .power_of_two_spinbox import PowerOfTwoSpinBox

OVERLAP_PRESETS: Final = [(f"{2**exponent - 1}/{2**exponent}", 2**exponent) for exponent in range(1, 8)]


class ControlPanelWidget(QGroupBox):
    def __init__(self) -> None:
        super().__init__()

        # widgets
        self.device_cb = ComboBoxWithSignal()
        self.sample_rate_cb = ComboBoxWithSignal()
        self.window_size_sb = PowerOfTwoSpinBox()
        self.overlap_cb = QComboBox()
        self.start_btn = QPushButton("Start")
        self.stop_btn = QPushButton("Stop")

        # setup
        self._setup_widgets()
        self._setup_layout()
        self._connect_signals()

    def _setup_widgets(self) -> None:
        self.setTitle("Control Panel")

        self.sample_rate_cb.setToolTip(
            "Reduce sample rate for better performance,<br>"
            "increase sample rate to resolve higher frequencies."
        )
        self.window_size_sb.setToolTip(
            "Reduce window size for better temporal resolution,<br>"
            "increase window size for better frequency resolution."
        )
        self.overlap_cb.setToolTip(
            "Higher overlap improves temporal smoothness,<br>but increases CPU usage."
        )
        for label, exponent in OVERLAP_PRESETS:
            self.overlap_cb.addItem(label, exponent)
        self.overlap_cb.setCurrentText("3/4")

    def _setup_layout(self) -> None:
        vbox = QVBoxLayout(self)

        hbox1 = QHBoxLayout()
        hbox1.addWidget(QLabel("Capture device"), 0)
        hbox1.addWidget(self.device_cb, 1)
        hbox1.addWidget(QLabel("Sample rate"), 0)
        hbox1.addWidget(self.sample_rate_cb, 0)
        vbox.addLayout(hbox1)

        hbox2 = QHBoxLayout()
        hbox2.addWidget(QLabel("FFT window size"), 0)
        hbox2.addWidget(self.window_size_sb, 0)
        hbox2.addWidget(QLabel("Overlap"), 0)
        hbox2.addWidget(self.overlap_cb, 0)
        hbox2.addStretch(1)
        hbox2.addWidget(self.start_btn, 0)
        hbox2.addWidget(self.stop_btn, 0)
        vbox.addLayout(hbox2)

    def _connect_signals(self) -> None:
        pass

    def set_device_list(self, device_list: list[str]) -> None:
        old_text = self.device_cb.currentText()

        with QSignalBlocker(self.device_cb):
            self.device_cb.clear()
            self.device_cb.addItems(device_list)

            if old_text in device_list:
                self.device_cb.setCurrentText(old_text)

        new_text = self.device_cb.currentText()

        if new_text != old_text:
            self.device_cb.currentTextChanged.emit(new_text)

    def set_sample_rate_list(self, sample_rates: Iterable[int], preferred: int) -> None:
        old_text = self.sample_rate_cb.currentText()

        with QSignalBlocker(self.sample_rate_cb):
            sample_rate_list = [str(x) for x in sorted(sample_rates)]
            self.sample_rate_cb.clear()
            self.sample_rate_cb.addItems(sample_rate_list)

            if old_text in sample_rate_list:
                self.sample_rate_cb.setCurrentText(old_text)
            else:
                self.sample_rate_cb.setCurrentText(str(preferred))

        new_text = self.sample_rate_cb.currentText()

        if new_text != old_text:
            self.sample_rate_cb.currentTextChanged.emit(new_text)

    def set_state(self, *, connected: bool) -> None:
        self.device_cb.setEnabled(not connected)
        self.sample_rate_cb.setEnabled(not connected)
        self.window_size_sb.setEnabled(not connected)
        self.overlap_cb.setEnabled(not connected)
        self.start_btn.setEnabled(not connected)
        self.stop_btn.setEnabled(connected)

    def sample_rate(self) -> int:
        return int(self.sample_rate_cb.currentText())

    def window_size(self) -> int:
        return self.window_size_sb.value()

    def hop_size(self) -> int:
        window_size = self.window_size()
        divisor = self.overlap_cb.currentData()
        return max(1, int(window_size // divisor))
