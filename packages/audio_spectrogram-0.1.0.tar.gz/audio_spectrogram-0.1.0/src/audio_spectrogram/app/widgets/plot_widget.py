# Copyright 2026 - 2026, Artur Drogunow and the Audio-Spectrogram contributors
# SPDX-License-Identifier: GPL-3.0-or-later

import pyqtgraph as pg
from PySide6.QtWidgets import QGroupBox, QVBoxLayout

pg.setConfigOption(opt="useNumba", value=True)


class PlotWidget(QGroupBox):
    def __init__(self) -> None:
        super().__init__("Signal Viewer")

        # variables

        # widgets
        self.glw = pg.GraphicsLayoutWidget()
        self.time_plot = self.glw.addPlot(row=0, col=0)
        self.time_plot_item = pg.PlotCurveItem()
        self.spec_plot = self.glw.addPlot(row=1, col=0)
        self.spec_plot_item = pg.ImageItem(axisOrder="row-major", levels=[-90, 0])

        # setup
        self._setup_widgets()
        self._setup_layout()
        self._connect_signals()

    def _setup_widgets(self) -> None:
        # set line properties
        self.time_plot_item.setClickable(False)
        self.time_plot_item.setPen(pg.mkPen("coral", width=0.5))
        self.time_plot_item.setSkipFiniteCheck(True)
        self.time_plot_item.setSegmentedLineMode("on")

        # horizontally align left axis
        self.time_plot.getAxis("left").setWidth(40)
        self.spec_plot.getAxis("left").setWidth(40)

        # setup time plot
        self.time_plot.setLabel("left", "Amplitude")
        self.time_plot.setLabel("bottom", "Time", units="s")
        self.time_plot.showGrid(x=True, y=True)
        self.time_plot.addItem(self.time_plot_item)

        # setup spectrum plot
        self.spec_plot.setYRange(-100, 7100)
        self.spec_plot.setLabel("left", "Frequency", units="Hz")
        self.spec_plot.setLabel("bottom", "Time", units="s")
        self.spec_plot.showGrid(x=False, y=False)
        self.spec_plot_item.setColorMap(pg.colormap.get("magma"))
        self.spec_plot.addItem(self.spec_plot_item)

    def _setup_layout(self) -> None:
        layout = QVBoxLayout(self)
        layout.addWidget(self.glw)

    def _connect_signals(self) -> None:
        pass
