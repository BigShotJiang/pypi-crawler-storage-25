# Copyright 2026 - 2026, Artur Drogunow and the Audio-Spectrogram contributors
# SPDX-License-Identifier: GPL-3.0-or-later

import typing

from PySide6.QtWidgets import (
    QSpinBox,
    QWidget,
)

DEFAULT_VALUE: typing.Final = 1024
MIN_VALUE: typing.Final = 64


class PowerOfTwoSpinBox(QSpinBox):
    def __init__(self, parent: QWidget | None = None) -> None:
        super().__init__(parent)

        self.setReadOnly(True)
        self.setRange(MIN_VALUE, 2**30)
        self.setValue(1024)  # default value

    @typing.override
    def stepBy(self, steps: int, /) -> None:
        value: int = self.value()

        for _ in range(abs(steps)):
            if steps > 0:
                value *= 2
            else:
                value = max(MIN_VALUE, value // 2)

        self.setValue(value)

    @typing.override
    def stepEnabled(self, /) -> QSpinBox.StepEnabledFlag:
        flags = QSpinBox.StepEnabledFlag.StepUpEnabled

        if self.value() > MIN_VALUE:
            flags |= QSpinBox.StepEnabledFlag.StepDownEnabled

        return flags
