# Copyright 2026 - 2026, Artur Drogunow and the Audio-Spectrogram contributors
# SPDX-License-Identifier: GPL-3.0-or-later

import sys

from PySide6.QtWidgets import QMainWindow, QVBoxLayout, QWidget

from audio_spectrogram import APP_TITLE, __version__

from .control_panel_widget import ControlPanelWidget
from .plot_widget import PlotWidget


class MainWindow(QMainWindow):
    def __init__(self) -> None:
        super().__init__()

        # variables

        # widgets
        self.control_panel_widget = ControlPanelWidget()
        self.plot_widget = PlotWidget()

        # setup
        self._setup_widgets()
        self._setup_layout()
        self._connect_signals()

    def _setup_widgets(self) -> None:
        title = (
            f"{APP_TITLE} {__version__} "
            f"(Python {sys.version_info[0]}.{sys.version_info[1]}.{sys.version_info[2]})"
        )
        self.setWindowTitle(title)

    def _setup_layout(self) -> None:
        central_widget = QWidget()
        self.setCentralWidget(central_widget)
        vbox = QVBoxLayout(central_widget)
        vbox.addWidget(self.control_panel_widget, 0)
        vbox.addWidget(self.plot_widget, 1)

    def _connect_signals(self) -> None:
        pass
