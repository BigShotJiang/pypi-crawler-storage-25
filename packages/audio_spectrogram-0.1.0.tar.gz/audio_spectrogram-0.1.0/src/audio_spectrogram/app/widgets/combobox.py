# Copyright 2026 - 2026, Artur Drogunow and the Audio-Spectrogram contributors
# SPDX-License-Identifier: GPL-3.0-or-later

import typing

from PySide6.QtCore import Qt, Signal
from PySide6.QtGui import QWheelEvent
from PySide6.QtWidgets import QComboBox, QWidget


class ComboBoxWithSignal(QComboBox):
    popoutAboutToBeShown = Signal()  # noqa: N815

    def __init__(self, parent: QWidget | None = None) -> None:
        super().__init__(parent)
        self.setFocusPolicy(Qt.FocusPolicy.StrongFocus)

    @typing.override
    def showPopup(self) -> None:
        self.popoutAboutToBeShown.emit()
        self._update_dropdown_width()
        return super().showPopup()

    @typing.override
    def wheelEvent(self, event: QWheelEvent) -> None:
        if not self.hasFocus():
            event.ignore()
        else:
            super().wheelEvent(event)

    def _update_dropdown_width(self) -> None:
        view = self.view()
        if self.count() == 0:
            width = self.width()
        else:
            font_metrics = view.fontMetrics()
            width = max(font_metrics.horizontalAdvance(self.itemText(i)) for i in range(self.count()))
            width = max(self.width(), width + 20)
        view.setFixedWidth(width)
