# Copyright 2026 - 2026, Artur Drogunow and the Audio-Spectrogram contributors
# SPDX-License-Identifier: GPL-3.0-or-later

import numpy as np
import numpy.typing as npt
from numba import float32, int64  # import the types
from numba.experimental import jitclass


@jitclass(
    [
        ("window_size", int64),
        ("hop_size", int64),
        ("frame_count", int64),
        ("freq_bins", int64),
        ("hanning", float32[:]),
        ("scaling", float32[:]),
        ("signal_buffer", float32[:]),
        ("image", float32[:, :]),
    ]
)  # pyright: ignore[reportCallIssue]
class SpectrogramData:
    def __init__(self, window_size: int, hop_size: int, frame_count: int) -> None:
        self.window_size = window_size
        self.hop_size = hop_size
        self.frame_count = frame_count
        self.freq_bins = window_size // 2 + 1
        self.hanning = np.hanning(window_size).astype(np.float32)

        # calculate normalization scaling array
        self.scaling = np.ones(self.freq_bins, dtype=np.float32) / np.sum(self.hanning)
        self.scaling[1:-1] *= 2

        self.signal_buffer: npt.NDArray[np.float32] = np.zeros((0,), dtype=np.float32)
        self.image: npt.NDArray[np.float32] = np.zeros((self.freq_bins, frame_count), dtype=np.float32)
        self.image -= 120.0

    def push(self, data: npt.NDArray[np.float32]) -> None:
        self.signal_buffer = np.hstack((self.signal_buffer, data))
        self._calc_stft()

    def _calc_stft(self) -> None:
        buffer_length = len(self.signal_buffer)
        if buffer_length < self.window_size:
            return
        new_frames = (buffer_length - self.window_size) // self.hop_size + 1
        frame_buffer = np.empty((self.freq_bins, new_frames), dtype=np.float32)

        for frame_idx in range(new_frames):
            # get window data
            x = self.signal_buffer[
                frame_idx * self.hop_size : frame_idx * self.hop_size + self.window_size
            ]

            # calculate spectrogram
            mag = np.abs(np.fft.rfft(x * self.hanning))
            mag[:] = np.multiply(mag, self.scaling)
            mag[:] = 20.0 * np.log10(mag + 1e-12)
            frame_buffer[:, frame_idx] = mag

        self.signal_buffer = self.signal_buffer[new_frames * self.hop_size :]
        self.image = np.hstack((self.image, frame_buffer))[::, -self.frame_count :].copy()
