# Copyright 2026 - 2026, Artur Drogunow and the Audio-Spectrogram contributors
# SPDX-License-Identifier: GPL-3.0-or-later

from dataclasses import dataclass

import numpy as np
from PySide6.QtCore import QEventLoop, QIODevice, QObject, Signal
from PySide6.QtMultimedia import QAudio, QAudioFormat, QAudioSource, QMediaDevices

from audio_spectrogram import LOGGER

from .qapplication import get_qapplication
from .widgets.control_panel_widget import ControlPanelWidget


@dataclass
class Settings:
    sample_rate: int
    window_size: int
    hop_size: int


class ControlPanelHandler(QObject):
    start = Signal(Settings)
    stop = Signal()
    data = Signal(object)  # signal data, sample rate

    def __init__(self, control_panel_widget: ControlPanelWidget) -> None:
        super().__init__()

        # variables
        self.qapp = get_qapplication()
        self.audio_source: QAudioSource | None = None
        self.io_device: QIODevice | None = None

        # widgets
        self.control_panel_widget = control_panel_widget

        # setup
        self._setup_widgets()
        self._setup_layout()
        self._connect_signals()

        # call after signals are connected
        self.update_device_list()

    def _setup_widgets(self) -> None:
        self.control_panel_widget.set_state(connected=False)

    def _setup_layout(self) -> None:
        pass

    def _connect_signals(self) -> None:
        self.control_panel_widget.device_cb.popoutAboutToBeShown.connect(self.update_device_list)
        self.control_panel_widget.device_cb.currentTextChanged.connect(self.on_device_changed)
        self.control_panel_widget.start_btn.clicked.connect(self.start_capture)
        self.control_panel_widget.stop_btn.clicked.connect(self.stop_capture)

    def update_device_list(self) -> None:
        LOGGER.info("%s.%s()", self.__class__.__name__, self.update_device_list.__name__)
        device_list = [x.description() for x in QMediaDevices.audioInputs()]
        self.control_panel_widget.set_device_list(device_list)

    def on_device_changed(self, selected_device: str) -> None:
        LOGGER.info(
            "%s.%s(%s)",
            self.__class__.__name__,
            self.on_device_changed.__name__,
            selected_device,
        )
        supported_sample_rates: set[int] = set()
        for audio_device in QMediaDevices.audioInputs():
            if audio_device.description() != selected_device:
                continue
            fmt = audio_device.preferredFormat()
            preferred_sample_rate = fmt.sampleRate()
            supported_sample_rates.add(preferred_sample_rate)
            for sample_rate in [
                8_000,
                11_025,
                16_000,
                22_050,
                44_100,
                48_000,
                88_200,
                96_000,
                176_400,
                192_000,
                352_800,
                384_000,
            ]:
                fmt.setSampleRate(sample_rate)
                if audio_device.isFormatSupported(fmt):
                    supported_sample_rates.add(sample_rate)
            self.control_panel_widget.set_sample_rate_list(
                sample_rates=supported_sample_rates, preferred=preferred_sample_rate
            )

    def start_capture(self) -> None:
        LOGGER.info("%s.%s()", self.__class__.__name__, self.start_capture.__name__)
        selected_device = self.control_panel_widget.device_cb.currentText()
        for audio_device in QMediaDevices.audioInputs():
            if audio_device.description() != selected_device:
                continue
            fmt = audio_device.preferredFormat()
            fmt.setChannelCount(1)
            fmt.setSampleRate(self.control_panel_widget.sample_rate())
            fmt.setSampleFormat(QAudioFormat.SampleFormat.Float)
            sample_rate = fmt.sampleRate()
            self.audio_source = QAudioSource(audio_device, fmt)
            self.audio_source.stateChanged.connect(self.on_state_changed)

            # notify
            self.control_panel_widget.set_state(connected=True)
            self.start.emit(
                Settings(
                    sample_rate=sample_rate,
                    window_size=self.control_panel_widget.window_size(),
                    hop_size=self.control_panel_widget.hop_size(),
                )
            )
            self.qapp.processEvents(QEventLoop.ProcessEventsFlag.AllEvents)

            # start capturing
            LOGGER.info(
                'Starting stream from device "%s" (%.0fHz)',
                bytes(audio_device.id().data()).decode(),
                self.audio_source.format().sampleRate(),
            )
            self.io_device = self.audio_source.start()
            self.io_device.readyRead.connect(self.on_ready_read)
            self.on_ready_read()

    def stop_capture(self) -> None:
        LOGGER.info("%s.%s()", self.__class__.__name__, self.stop_capture.__name__)
        if self.io_device is not None:
            self.io_device.readyRead.disconnect(self.on_ready_read)
            self.io_device = None

        if self.audio_source is not None:
            self.audio_source.stateChanged.disconnect(self.on_state_changed)
            self.audio_source.stop()
            self.audio_source.deleteLater()
            self.audio_source = None

        self.control_panel_widget.set_state(connected=False)
        self.stop.emit()

    def on_state_changed(self, state: QAudio.State) -> None:
        LOGGER.info("%s.%s(%s)", self.__class__.__name__, self.on_state_changed.__name__, state)
        if state is QAudio.State.StoppedState:
            self.stop_capture()

    def on_ready_read(self) -> None:
        LOGGER.debug("%s.%s()", self.__class__.__name__, self.on_ready_read.__name__)
        if self.io_device is not None:
            data = self.io_device.readAll().data()
            array = np.frombuffer(data, dtype=np.float32)
            self.data.emit(array)

    def post_visible_setup(self) -> None:
        LOGGER.info("%s.%s()", self.__class__.__name__, self.post_visible_setup.__name__)

    def cleanup(self) -> None:
        LOGGER.info("%s.%s()", self.__class__.__name__, self.cleanup.__name__)
        self.stop_capture()
