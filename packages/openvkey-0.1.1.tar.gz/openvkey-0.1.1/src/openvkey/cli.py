""" openvkey """


def main() -> None:
    print("  openvkey  ")
