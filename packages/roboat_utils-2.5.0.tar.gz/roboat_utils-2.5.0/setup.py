from setuptools import setup, find_packages

with open("README.md", "r", encoding="utf-8") as f:
    long_description = f.read()

setup(
    name="roboat-utils",
    version="2.5.0",
    author="roboat contributors",
    description=(
        "The best Python wrapper for the Roblox ecosystem — "
        "OAuth, async, typed models, datastores, events, marketplace tools"
    ),
    long_description=long_description,
    long_description_content_type="text/markdown",
    url="https://roboat.pro",
    project_urls={
        "Bug Tracker": "https://github.com/Addi9000/roboat/issues",
        "Documentation": "https://www.roboat.pro/docs",
        "Source": "https://github.com/Addi9000/roboat",
    },
    packages=find_packages(exclude=["tests*", "examples*"]),
    python_requires=">=3.9",
    install_requires=[
        "requests>=2.28.0",
        "databaserotacos",
    ],
    extras_require={
        "async": ["aiohttp>=3.8.0"],
        "test":  ["pytest>=7.0", "pytest-mock>=3.0"],
        "all":   ["aiohttp>=3.8.0", "pytest>=7.0"],
    },
    entry_points={
        "console_scripts": [
            "roboat-utils=roboat_utils.session:_cli_entry",
        ],
    },
    classifiers=[
        "Development Status :: 5 - Production/Stable",
        "Intended Audience :: Developers",
        "License :: OSI Approved :: MIT License",
        "Programming Language :: Python :: 3",
        "Programming Language :: Python :: 3.9",
        "Programming Language :: Python :: 3.10",
        "Programming Language :: Python :: 3.11",
        "Programming Language :: Python :: 3.12",
        "Operating System :: OS Independent",
        "Topic :: Software Development :: Libraries :: Python Modules",
        "Topic :: Games/Entertainment",
        "Environment :: Console",
        "Typing :: Typed",
    ],
    keywords=[
        "roblox", "api", "wrapper", "roblox-api", "roboat-utils",
        "games", "catalog", "trading", "opencloud", "datastore",
        "automation", "economy",
    ],
    license="MIT",
)