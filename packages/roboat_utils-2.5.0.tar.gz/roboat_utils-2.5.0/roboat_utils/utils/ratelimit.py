"""
roboat_utils.utils.ratelimit
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
Token-bucket rate limiter + exponential-backoff retry decorator.
"""

from __future__ import annotations
import time
import threading
import functools
from typing import Callable, Optional, Type, Tuple


class TokenBucket:
    """
    Thread-safe token bucket for synchronous rate limiting.

    Args:
        rate:     Tokens replenished per second.
        capacity: Maximum burst size (bucket capacity).

    Example::

        bucket = TokenBucket(rate=10, capacity=20)
        bucket.consume()   # blocks until a token is available
    """

    def __init__(self, rate: float = 10.0, capacity: float = 20.0) -> None:
        if rate <= 0:
            raise ValueError("rate must be positive")
        if capacity <= 0:
            raise ValueError("capacity must be positive")
        self.rate = rate
        self.capacity = capacity
        self._tokens = capacity
        self._last = time.monotonic()
        self._lock = threading.Lock()

    def consume(self, tokens: float = 1.0) -> float:
        """
        Consume *tokens* from the bucket, blocking until they are available.

        Returns:
            Seconds waited.
        """
        waited = 0.0
        while True:
            with self._lock:
                now = time.monotonic()
                elapsed = now - self._last
                self._tokens = min(self.capacity, self._tokens + elapsed * self.rate)
                self._last = now
                if self._tokens >= tokens:
                    self._tokens -= tokens
                    return waited
                sleep_for = (tokens - self._tokens) / self.rate
            time.sleep(sleep_for)
            waited += sleep_for

    def drain(self) -> None:
        """Empty the bucket (used after receiving a 429)."""
        with self._lock:
            self._tokens = 0.0

    @property
    def available(self) -> float:
        """Current number of available tokens (approximate)."""
        with self._lock:
            now = time.monotonic()
            return min(self.capacity, self._tokens + (now - self._last) * self.rate)

    def __repr__(self) -> str:
        return (
            f"TokenBucket(rate={self.rate}, capacity={self.capacity}, "
            f"available={self.available:.1f})"
        )


def retry(
    max_attempts: int = 3,
    backoff: float = 1.0,
    backoff_factor: float = 2.0,
    max_backoff: float = 60.0,
    exceptions: Tuple[Type[BaseException], ...] = (),
) -> Callable:
    """
    Decorator: retry a function with exponential backoff on specific exceptions.

    Args:
        max_attempts:   Maximum number of attempts (including the first).
        backoff:        Initial wait in seconds before the first retry.
        backoff_factor: Multiplier applied each retry.
        max_backoff:    Cap on the sleep time between retries.
        exceptions:     Exception types to retry on.
                        Defaults to ``RateLimitedError``.

    Example::

        @retry(max_attempts=3, backoff=1.0)
        def fetch_user():
            return client.users.get_user(123)
    """
    def decorator(fn: Callable) -> Callable:
        @functools.wraps(fn)
        def wrapper(*args, **kwargs):
            from roboat_utils.exceptions import RateLimitedError
            catch = exceptions or (RateLimitedError,)
            delay = backoff
            last_exc: BaseException | None = None

            for attempt in range(max_attempts):
                try:
                    return fn(*args, **kwargs)
                except catch as exc:
                    last_exc = exc
                    if attempt < max_attempts - 1:
                        # Honour Retry-After if the exception carries it
                        sleep_for = getattr(exc, "retry_after", None) or delay
                        sleep_for = min(sleep_for, max_backoff)
                        time.sleep(sleep_for)
                        delay = min(delay * backoff_factor, max_backoff)

            raise last_exc  # type: ignore[misc]
        return wrapper
    return decorator


__all__ = ["TokenBucket", "retry"]
