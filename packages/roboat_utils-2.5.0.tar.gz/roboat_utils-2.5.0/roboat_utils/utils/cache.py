"""
roboat_utils.utils.cache
~~~~~~~~~~~~~~~~~~~~~~~~~
Thread-safe in-memory TTL + LRU cache.
"""

from __future__ import annotations
import time
import threading
import functools
from collections import OrderedDict
from typing import Any, Callable, Optional


class TTLCache:
    """
    Thread-safe in-memory cache with per-entry TTL and LRU eviction.

    Args:
        default_ttl: Default time-to-live in seconds.
        max_size:    Max entries before LRU eviction kicks in.

    Example::

        cache = TTLCache(default_ttl=30, max_size=512)
        cache.set("user:156", user_data)
        value = cache.get("user:156")   # None if expired or missing
    """

    def __init__(self, default_ttl: float = 30.0, max_size: int = 512) -> None:
        self.default_ttl = default_ttl
        self.max_size = max_size
        # OrderedDict preserves insertion order for LRU
        self._store: OrderedDict[str, tuple[Any, float]] = OrderedDict()
        self._lock = threading.Lock()

    # ── Public API ────────────────────────────────────────────────────

    def get(self, key: str) -> Optional[Any]:
        """Return the cached value, or ``None`` if missing / expired."""
        with self._lock:
            entry = self._store.get(key)
            if entry is None:
                return None
            value, expires_at = entry
            if time.monotonic() > expires_at:
                del self._store[key]
                return None
            # Move to end (most-recently-used)
            self._store.move_to_end(key)
            return value

    def set(self, key: str, value: Any, ttl: Optional[float] = None) -> None:
        """Cache *value* under *key* for *ttl* seconds (default: ``default_ttl``)."""
        with self._lock:
            if key in self._store:
                self._store.move_to_end(key)
            elif len(self._store) >= self.max_size:
                # Evict LRU entry (first item)
                self._store.popitem(last=False)
            expires_at = time.monotonic() + (ttl if ttl is not None else self.default_ttl)
            self._store[key] = (value, expires_at)

    def delete(self, key: str) -> None:
        """Remove a specific key."""
        with self._lock:
            self._store.pop(key, None)

    def clear(self) -> None:
        """Remove all entries."""
        with self._lock:
            self._store.clear()

    def invalidate_prefix(self, prefix: str) -> int:
        """Remove all keys that start with *prefix*. Returns the count removed."""
        with self._lock:
            to_delete = [k for k in self._store if k.startswith(prefix)]
            for k in to_delete:
                del self._store[k]
            return len(to_delete)

    # ── Stats ─────────────────────────────────────────────────────────

    def stats(self) -> dict:
        """Return cache utilisation info."""
        with self._lock:
            now = time.monotonic()
            alive = sum(1 for _, (_, exp) in self._store.items() if exp > now)
            return {
                "total":    len(self._store),
                "alive":    alive,
                "max_size": self.max_size,
                "ttl":      self.default_ttl,
            }

    def __len__(self) -> int:
        with self._lock:
            return len(self._store)

    def __repr__(self) -> str:
        s = self.stats()
        return f"TTLCache(alive={s['alive']}/{s['max_size']}, ttl={self.default_ttl}s)"


def cached(ttl: float = 30.0, key_fn: Optional[Callable] = None) -> Callable:
    """
    Decorator: cache the result of a method for *ttl* seconds.

    Looks for a ``_cache`` attribute on ``self`` or ``self._c``.
    Falls through (no caching) if neither exists.

    Args:
        ttl:    Cache lifetime in seconds.
        key_fn: Optional ``(args, kwargs) → str`` for a custom cache key.

    Example::

        class UsersAPI:
            @cached(ttl=60)
            def get_user(self, user_id: int) -> User:
                ...
    """
    def decorator(fn: Callable) -> Callable:
        @functools.wraps(fn)
        def wrapper(self_or_cls, *args, **kwargs):
            # Resolve the cache object
            cache: Optional[TTLCache] = (
                getattr(self_or_cls, "_cache", None)
                or getattr(getattr(self_or_cls, "_c", None), "_cache", None)
            )
            if cache is None:
                return fn(self_or_cls, *args, **kwargs)

            cache_key = (
                key_fn(args, kwargs)
                if key_fn
                else f"{fn.__qualname__}:{args}:{tuple(sorted(kwargs.items()))}"
            )
            hit = cache.get(cache_key)
            if hit is not None:
                return hit

            result = fn(self_or_cls, *args, **kwargs)
            if result is not None:
                cache.set(cache_key, result, ttl=ttl)
            return result

        return wrapper
    return decorator


__all__ = ["TTLCache", "cached"]
