"""
roboat_utils.utils.paginator
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
Lazy iterator for Roblox cursor-based endpoints.
"""

from __future__ import annotations
from typing import Callable, Generic, Iterator, List, Optional, TypeVar

T = TypeVar("T")


class Paginator(Generic[T]):
    """
    Lazy iterator that auto-fetches all pages of a cursor-based endpoint.

    Args:
        fetch_fn:  Callable ``(cursor: str | None) -> Page``.
        max_items: Stop after this many items. ``None`` = fetch all.

    Example::

        # Stream ALL followers, one page at a time
        for follower in Paginator(lambda c: client.friends.get_followers(uid, cursor=c)):
            print(follower)

        # First 500 only
        top = list(Paginator(
            lambda c: client.friends.get_followers(uid, limit=100, cursor=c),
            max_items=500,
        ))
    """

    def __init__(
        self,
        fetch_fn: Callable[[Optional[str]], object],
        max_items: Optional[int] = None,
    ) -> None:
        self._fetch = fetch_fn
        self._max_items = max_items

    def __iter__(self) -> Iterator[T]:
        cursor: Optional[str] = None
        count = 0
        while True:
            page = self._fetch(cursor)
            for item in page.data:  # type: ignore[attr-defined]
                yield item
                count += 1
                if self._max_items is not None and count >= self._max_items:
                    return
            cursor = page.next_cursor  # type: ignore[attr-defined]
            if not cursor:
                break

    def collect(self) -> List[T]:
        """Eagerly collect all items into a list."""
        return list(self)

    def first(self, n: int = 1) -> List[T]:
        """Collect the first *n* items."""
        result: List[T] = []
        for item in self:
            result.append(item)
            if len(result) >= n:
                break
        return result


__all__ = ["Paginator"]
