"""Allow running as: python -m roboat_utils"""
from roboat_utils.session import _cli_entry

if __name__ == "__main__":
    _cli_entry()
