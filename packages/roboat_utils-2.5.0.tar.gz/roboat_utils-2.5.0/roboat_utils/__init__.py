"""
roboat-utils v3.0.0
~~~~~~~~~~~~~~~~~~~~
Python interface for the Roblox ecosystem.
Install: pip install roboat-utils

Quick start::

    from roboat_utils import RoboatClient

    client = RoboatClient(cookie="_|WARNING:...")
    user   = client.users.get_user(156)
    print(user)

Async::

    from roboat_utils import AsyncRoboatClient
    import asyncio

    async def main():
        async with AsyncRoboatClient(cookie="...") as client:
            user = await client.users.get_user(156)

    asyncio.run(main())

Open Cloud::

    from roboat_utils import RoboatCloudClient

    cloud = RoboatCloudClient(api_key="roblox-KEY-xxxx")
    cloud.datastores.set(123456, "PlayerData", "player_1", {"coins": 500})
"""

from .client       import RoboatClient, ClientBuilder
from .async_client import AsyncRoboatClient
from .opencloud    import RoboatCloudClient
from .session      import RoboatSession
from .database     import SessionDatabase
from .events       import EventPoller
from .analytics    import Analytics
from .oauth        import OAuthManager, get_oauth_url, OAUTH_URL
from .utils        import TokenBucket, TTLCache, Paginator, retry, cached

from .models import (
    User, UserPresence,
    Game, GameVotes, GameServer,
    CatalogItem, ResaleData,
    Group, GroupRole,
    Friend,
    Badge,
    Avatar, AvatarAsset, AvatarColors,
    RobuxBalance, Transaction,
    Page,
)
from .trades       import Trade, TradeOffer, TradeAsset
from .messages     import Message, ChatConversation
from .inventory    import InventoryAsset
from .develop      import Universe, Place, DataStore, PlaceVersion, TeamCreateMember, PluginInfo
from .groups       import GroupShout, GroupPayout, GroupJoinRequest, GroupRelationship
from .marketplace  import MarketplaceAPI, LimitedData, ResaleProfit, RAPTracker
from .social       import SocialGraph, UserNode, PresenceSnapshot
from .notifications import NotificationsAPI, NotificationResult
from .publish      import PublishAPI, UploadedAsset
from .moderation   import ModerationAPI, AccountStanding, AbuseReport

from .exceptions import (
    RoboatAPIError,
    HTTPError,
    RateLimitedError,
    InvalidCookieError,
    ForbiddenError,
    NotFoundError,
    UserNotFoundError,
    GameNotFoundError,
    ItemNotFoundError,
    GroupNotFoundError,
    BadgeNotFoundError,
    ServerError,
    NotAuthenticatedError,
    InsufficientFundsError,
    DatabaseError,
)

__version__ = "3.0.0"
__author__  = "roboat contributors"
__license__ = "MIT"

__all__ = [
    # Clients
    "RoboatClient", "ClientBuilder",
    "AsyncRoboatClient",
    "RoboatCloudClient",
    "RoboatSession",
    "SessionDatabase",
    # High-level
    "EventPoller", "Analytics", "OAuthManager",
    "get_oauth_url", "OAUTH_URL",
    # Utils
    "TokenBucket", "TTLCache", "Paginator", "retry", "cached",
    # Models
    "User", "UserPresence",
    "Game", "GameVotes", "GameServer",
    "CatalogItem", "ResaleData",
    "Group", "GroupRole",
    "Friend", "Badge",
    "Avatar", "AvatarAsset", "AvatarColors",
    "RobuxBalance", "Transaction",
    "Page",
    "Trade", "TradeOffer", "TradeAsset",
    "Message", "ChatConversation",
    "InventoryAsset",
    "Universe", "Place", "DataStore", "PlaceVersion",
    "TeamCreateMember", "PluginInfo",
    "GroupShout", "GroupPayout", "GroupJoinRequest", "GroupRelationship",
    "LimitedData", "ResaleProfit", "RAPTracker",
    "UserNode", "PresenceSnapshot",
    "NotificationResult", "UploadedAsset",
    "AccountStanding", "AbuseReport",
    # APIs
    "MarketplaceAPI", "SocialGraph", "NotificationsAPI", "PublishAPI", "ModerationAPI",
    # Exceptions
    "RoboatAPIError", "HTTPError",
    "RateLimitedError", "InvalidCookieError", "ForbiddenError",
    "NotFoundError", "UserNotFoundError", "GameNotFoundError",
    "ItemNotFoundError", "GroupNotFoundError", "BadgeNotFoundError",
    "ServerError", "NotAuthenticatedError", "InsufficientFundsError",
    "DatabaseError",
]
