"""
roboat_utils.exceptions
~~~~~~~~~~~~~~~~~~~~~~~
Exception hierarchy for roboat-utils.

Hierarchy
---------
RoboatAPIError
├── HTTPError
│   ├── RateLimitedError      (429)  — has .retry_after
│   ├── InvalidCookieError    (401)
│   ├── ForbiddenError        (403)
│   ├── NotFoundError         (404)
│   │   ├── UserNotFoundError
│   │   ├── GameNotFoundError
│   │   ├── ItemNotFoundError
│   │   ├── GroupNotFoundError
│   │   └── BadgeNotFoundError
│   └── ServerError           (5xx)
├── NotAuthenticatedError
├── InsufficientFundsError
└── DatabaseError
"""

from __future__ import annotations
from typing import Optional


class RoboatAPIError(Exception):
    """Base class for all roboat-utils exceptions."""

    def __init__(self, message: str = "", *, errors: list | None = None) -> None:
        self.errors: list = errors or []
        super().__init__(message)

    def __repr__(self) -> str:
        return f"{self.__class__.__name__}({self.args[0]!r})"


# ── HTTP layer ──────────────────────────────────────────────────────── #

class HTTPError(RoboatAPIError):
    """Raised for non-2xx HTTP responses from the Roblox API."""

    def __init__(self, status_code: int, message: str = "",
                 *, errors: list | None = None) -> None:
        self.status_code = status_code
        super().__init__(f"HTTP {status_code}: {message}", errors=errors)

    @property
    def is_retryable(self) -> bool:
        return self.status_code in (429, 500, 502, 503, 504)


class RateLimitedError(HTTPError):
    """HTTP 429 — rate limit exceeded."""

    def __init__(self, retry_after: Optional[float] = None) -> None:
        self.retry_after = retry_after
        msg = "Rate limited by Roblox API."
        if retry_after:
            msg += f" Retry after {retry_after:.1f}s."
        super().__init__(429, msg)


class InvalidCookieError(HTTPError):
    """HTTP 401 — the .ROBLOSECURITY cookie is invalid or expired."""

    def __init__(self) -> None:
        super().__init__(401, "Invalid or expired .ROBLOSECURITY cookie.")


class ForbiddenError(HTTPError):
    """HTTP 403 — insufficient permissions."""

    def __init__(self, message: str = "Forbidden.") -> None:
        super().__init__(403, message)


class NotFoundError(HTTPError):
    """HTTP 404 — resource not found."""

    def __init__(self, message: str = "Resource not found.") -> None:
        super().__init__(404, message)


class ServerError(HTTPError):
    """HTTP 5xx — Roblox-side server error."""

    def __init__(self, status_code: int, message: str = "") -> None:
        super().__init__(status_code, message or f"Server error ({status_code}).")


# ── Not-found specialisations ────────────────────────────────────────── #

class UserNotFoundError(NotFoundError):
    """Raised when a user cannot be found by ID or username."""

    def __init__(self, identifier: int | str = "") -> None:
        super().__init__(f"User not found: {identifier!r}")
        self.identifier = identifier


class GameNotFoundError(NotFoundError):
    """Raised when a universe/place cannot be found."""

    def __init__(self, universe_id: int | str = "") -> None:
        super().__init__(f"Game not found: universe {universe_id!r}")
        self.universe_id = universe_id


class ItemNotFoundError(NotFoundError):
    """Raised when a catalog item cannot be found."""

    def __init__(self, asset_id: int | str = "") -> None:
        super().__init__(f"Catalog item not found: {asset_id!r}")
        self.asset_id = asset_id


class GroupNotFoundError(NotFoundError):
    """Raised when a group cannot be found."""

    def __init__(self, group_id: int | str = "") -> None:
        super().__init__(f"Group not found: {group_id!r}")
        self.group_id = group_id


class BadgeNotFoundError(NotFoundError):
    """Raised when a badge cannot be found."""

    def __init__(self, badge_id: int | str = "") -> None:
        super().__init__(f"Badge not found: {badge_id!r}")
        self.badge_id = badge_id


# ── Logic exceptions ─────────────────────────────────────────────────── #

class NotAuthenticatedError(RoboatAPIError):
    """Raised when a method requires authentication but none is set."""

    def __init__(self, method: str = "") -> None:
        where = f" ({method})" if method else ""
        super().__init__(
            f"Authentication required{where}. "
            "Pass a .ROBLOSECURITY cookie to RoboatClient."
        )


class InsufficientFundsError(RoboatAPIError):
    """Raised when a purchase cannot be completed due to insufficient Robux."""

    def __init__(self, required: int = 0, available: int = 0) -> None:
        msg = "Insufficient Robux."
        if required and available:
            msg = f"Need {required:,}R$ but only have {available:,}R$."
        super().__init__(msg)
        self.required = required
        self.available = available


class DatabaseError(RoboatAPIError):
    """Raised for errors relating to the local session database."""


# ── Helper ────────────────────────────────────────────────────────────── #

def raise_for_response(status_code: int, body: dict, url: str = "") -> None:
    """
    Parse a Roblox API response and raise the appropriate exception.

    Args:
        status_code: HTTP status code.
        body: Parsed JSON response body.
        url: Request URL (used to pick a more specific Not-Found subclass).
    """
    if 200 <= status_code < 300:
        return

    # Extract Roblox error message
    errs = body.get("errors", [])
    msg = "; ".join(e.get("message", "") for e in errs if e.get("message"))
    if not msg:
        msg = body.get("message", "")

    if status_code == 401:
        raise InvalidCookieError()
    if status_code == 429:
        raise RateLimitedError()
    if status_code == 403:
        raise ForbiddenError(msg or "Forbidden.")
    if status_code == 404:
        url_lower = url.lower()
        if "users"   in url_lower: raise UserNotFoundError(msg or url)
        if "games"   in url_lower: raise GameNotFoundError(msg or url)
        if "catalog" in url_lower: raise ItemNotFoundError(msg or url)
        if "groups"  in url_lower: raise GroupNotFoundError(msg or url)
        if "badges"  in url_lower: raise BadgeNotFoundError(msg or url)
        raise NotFoundError(msg or f"Not found: {url}")
    if status_code >= 500:
        raise ServerError(status_code, msg)
    raise HTTPError(status_code, msg, errors=errs)


__all__ = [
    "RoboatAPIError",
    "HTTPError",
    "RateLimitedError",
    "InvalidCookieError",
    "ForbiddenError",
    "NotFoundError",
    "UserNotFoundError",
    "GameNotFoundError",
    "ItemNotFoundError",
    "GroupNotFoundError",
    "BadgeNotFoundError",
    "ServerError",
    "NotAuthenticatedError",
    "InsufficientFundsError",
    "DatabaseError",
    "raise_for_response",
]
