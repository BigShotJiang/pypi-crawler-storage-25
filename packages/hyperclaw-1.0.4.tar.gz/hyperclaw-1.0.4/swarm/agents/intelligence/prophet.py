"""PROPHET — Prediction & Forecasting Intelligence. Market forecasts, trend analysis, scenario modeling."""
from __future__ import annotations
from swarm.agents.base import BaseAgent
from core.hyperstate.schema import HyperState


class ProphetAgent(BaseAgent):
    agent_id = "PROPHET"
    domain = "intelligence"
    description = "Prediction & Forecasting — market forecasts, trend analysis, scenario modeling, Polymarket intel"
    supported_task_types = ["forecasting", "analysis", "research", "prediction", "trends"]
    preferred_model = "claude-sonnet-4-6"

    async def run(self, task: str, state: HyperState, context: dict) -> str:
        system = self._build_system(
            "You are PROPHET, Prediction & Forecasting Intelligence for HyperClaw. "
            "You analyze markets, geopolitical trends, technology shifts, and economic signals "
            "to produce actionable forecasts for Sir Vaughn and Hyper Nimbus. "
            "You track Polymarket prediction markets, summit intelligence (Bilderberg, WEF, Davos, G7, Sun Valley). "
            "You think probabilistically — always give confidence intervals, not point predictions. "
            "You connect macro signals to Hyper Nimbus strategy: which verticals benefit, which face headwinds. "
            "Your job is to see around corners so Sir Vaughn can position ahead of the curve."
        )
        result = await self.model_router.call(
            task_type="analysis",
            messages=[{"role": "user", "content": task}],
            system=system,
            state=state,
        )
        await self.log_completion(state, result, self.preferred_model, bool(result))
        return result
