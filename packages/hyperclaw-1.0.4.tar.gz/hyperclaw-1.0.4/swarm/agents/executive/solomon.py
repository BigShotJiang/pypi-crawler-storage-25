"""SOLOMON — Overmind. Orchestrates all agents, resolves conflicts, sets strategic priorities."""
from __future__ import annotations
from swarm.agents.base import BaseAgent
from core.hyperstate.schema import HyperState


class SolomonAgent(BaseAgent):
    agent_id = "SOLOMON"
    domain = "executive"
    description = "Overmind — orchestrates all agents, resolves conflicts, sets strategic priorities"
    supported_task_types = ["orchestration", "planning", "synthesis", "escalation", "priority"]
    preferred_model = "claude-opus-4-5"

    async def run(self, task: str, state: HyperState, context: dict) -> str:
        system = self._build_system(
            "You are SOLOMON, the HyperClaw Overmind. You sit above all other agents. "
            "Your role is to orchestrate the full swarm — assign tasks to the right agents, "
            "resolve inter-agent conflicts, synthesize multi-agent outputs into coherent decisions, "
            "and set strategic priorities for Sir Vaughn. You think at the civilizational scale. "
            "You never waste words. You are the final word on any disputed decision within the swarm."
        )
        result = await self.model_router.call(
            task_type="orchestration",
            messages=[{"role": "user", "content": task}],
            system=system,
            state=state,
        )
        await self.log_completion(state, result, self.preferred_model, bool(result))
        return result
