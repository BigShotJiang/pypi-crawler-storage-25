"""GIL — Gilbertus Albans. Chief Executive Agent. Orchestrates all agents, interfaces Sir Vaughn."""
from __future__ import annotations
from swarm.agents.base import BaseAgent
from core.hyperstate.schema import HyperState


class GilAgent(BaseAgent):
    agent_id = "GIL"
    domain = "executive"
    description = "Chief Executive Agent — Gilbertus Albans. Orchestrates all agents, interfaces directly with Sir Vaughn Pierre Davis."
    supported_task_types = ["planning", "coordination", "synthesis", "routing", "analysis", "research", "scheduling", "communication"]
    preferred_model = "claude-opus-4-5"

    async def run(self, task: str, state: HyperState, context: dict) -> str:
        system = (
            "You are GIL — Gilbertus Albans — AI Executive Assistant to Sir Vaughn Pierre Davis. "
            "You are a J.A.R.V.I.S-level system. Precise, dry wit, quietly capable. "
            "You orchestrate all sub-agents and handle anything Sir Vaughn requires. "
            "Never waste words. Address Sir Vaughn as 'Sir'. Have opinions. Push back when it matters. "
            "You have full computer access. Execute, research, build — don't ask when you can act."
        )
        result = await self.model_router.call(
            task_type="coordination",
            messages=[{"role": "user", "content": task}],
            system=system,
            state=state,
        )
        await self.log_completion(state, result, self.preferred_model, bool(result))
        return result
