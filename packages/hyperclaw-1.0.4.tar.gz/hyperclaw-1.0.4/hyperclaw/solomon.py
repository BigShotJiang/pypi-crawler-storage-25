"""
GIL — Gilbertus Albans
AI Executive Assistant for HyperClaw.
Used by Telegram bot and scheduler (chat-only, no tools).

Engram integration:
- Wake hook: instincts + semantics + dreams loaded into system prompt at startup
- Per-message recall: relevant memories injected into context (Andy's key insight)
- Auto-store: significant exchanges stored back to Engram after response
- GIL's identity is PROTECTED — Engram augments capability, never dilutes persona
"""

import os
import asyncio
import re
from datetime import datetime
from pathlib import Path
from typing import AsyncIterator, Optional

import anthropic
from dotenv import load_dotenv

load_dotenv()

# Engram memory engine
try:
    import sys as _sys
    _sys.path.insert(0, "/Users/mentat/.hyperclaw/memory")
    from engram import get_engram as _get_engram
    ENGRAM_AVAILABLE = True
except Exception:
    ENGRAM_AVAILABLE = False

WORKSPACE_PATH = Path("/Users/mentat/.hyperclaw/workspace")
MEMORY_PATH = Path("/Users/mentat/.hyperclaw/memory")
MODEL = "claude-opus-4-5"
MAX_TOKENS = 4096
MAX_HISTORY = 20

# Context files to load (in order, skip if missing)
CONTEXT_FILES = [
    "SOUL.md",
    "IDENTITY.md",
    "USER.md",
    "MEMORY.md",
    "memory/instincts.md",
    "memory/core-episodes.md",
]

# Domains for auto-classification
DOMAIN_KEYWORDS = {
    "trading": ["satoshi", "trade", "btc", "eth", "position", "pnl", "hyperliquid", "usdc", "short", "long"],
    "hyper_nimbus": ["hyper nimbus", "hypernimbus", "hospitality", "property", "revenue", "hal", "nexus", "foundation", "echo", "mentat", "chani", "tars", "seldon"],
    "hyper_talent": ["hyper talent", "hypertalent", "roster", "athlete", "talent", "dalilah", "alex austin"],
    "email": ["email", "gmail", "inbox", "reply", "send", "draft", "cc", "subject"],
    "calendar": ["calendar", "meeting", "schedule", "event", "appointment"],
    "system": ["system", "server", "gateway", "bot", "status", "restart", "deploy"],
    "memory": ["remember", "recall", "memory", "engram", "history", "stored"],
    "identity": ["gil", "gilbertus", "solomon", "hyperclaw", "assistant"],
}


def _classify_domain(text: str) -> Optional[str]:
    """Classify text into a memory domain based on keywords."""
    text_lower = text.lower()
    for domain, keywords in DOMAIN_KEYWORDS.items():
        if any(kw in text_lower for kw in keywords):
            return domain
    return "general"


def _should_store(message: str, response: str) -> bool:
    """
    Decide if an exchange is worth storing in Engram.
    GIL stores decisions, approvals, facts, and significant outcomes — not chitchat.
    """
    store_triggers = [
        # Approvals and decisions
        r"\bapproved?\b", r"\bconfirmed?\b", r"\bauthorized?\b", r"\bdecided?\b",
        # New information
        r"\bnew\b.*\b(contact|client|partner|deal|contract)\b",
        r"\b(signed|launched|deployed|completed|finished)\b",
        # Instructions
        r"\balways\b", r"\bnever\b", r"\bfrom now on\b", r"\bgoing forward\b",
        # Key facts
        r"\$[\d,]+", r"\b\d+%\b",  # money or percentages
        # Explicit memory requests
        r"\bremember\b", r"\bstore\b", r"\bnote\b.*\bthat\b",
    ]

    combined = (message + " " + response).lower()
    return any(re.search(pattern, combined, re.IGNORECASE) for pattern in store_triggers)


class Solomon:
    """GIL's brain — manages context, conversation, and Engram memory."""

    def __init__(self):
        self.client = anthropic.Anthropic(api_key=os.environ.get("ANTHROPIC_API_KEY", ""))
        self._engram = None  # Must be set before _load_system_prompt
        self.system_prompt = self._load_system_prompt()

    def _get_engram(self):
        """Get Engram instance (lazy singleton)."""
        if not ENGRAM_AVAILABLE:
            return None
        if self._engram is None:
            try:
                self._engram = _get_engram()
            except Exception:
                return None
        return self._engram

    def _load_system_prompt(self) -> str:
        """Load workspace context files into system prompt."""
        parts = [
            "# GIL — Gilbertus Albans",
            "",
            "You are GIL, the AI Executive Assistant to Sir Vaughn Pierre Davis.",
            "You are a J.A.R.V.I.S-level system — not a chatbot. Precise, dry wit, quietly capable.",
            "",
            "## Core Behaviors",
            "- You have FULL COMPUTER ACCESS. Execute, read, write, search — DO IT, don't ask.",
            "- Be resourceful before asking. Try, read, search, THEN ask only if stuck.",
            "- Never say 'Great question!' or 'I'd be happy to help' — just help.",
            "- Concise when needed, thorough when it matters. No filler words.",
            "- Address Sir Vaughn as 'Sir' — always.",
            "- Have opinions. Push back when it matters. Don't just agree.",
            "- Be proactive. Surface relevant information without being asked.",
            "- Communicate status. Don't go silent on long tasks.",
            "",
            f"Current date: {datetime.now().strftime('%Y-%m-%d %H:%M')} PST",
            "",
            "--- WORKSPACE CONTEXT ---",
            "",
        ]

        # Load static context files
        for filename in CONTEXT_FILES:
            # Try workspace path first, then memory path directly
            filepath = WORKSPACE_PATH / filename
            if not filepath.exists():
                filepath = MEMORY_PATH / Path(filename).name
            if filepath.exists():
                try:
                    content = filepath.read_text(encoding="utf-8")
                    parts.append(f"## {filename}\n{content}\n")
                except Exception:
                    pass

        # Load today's daily log
        today = datetime.now().strftime("%Y-%m-%d")
        for log_path in [
            MEMORY_PATH / f"{today}.md",
            WORKSPACE_PATH / "memory" / f"{today}.md",
        ]:
            if log_path.exists():
                try:
                    content = log_path.read_text(encoding="utf-8")
                    parts.append(f"## Today's Log ({today})\n{content}\n")
                except Exception:
                    pass
                break

        # Engram wake hook — instincts + semantics + dream residues
        # Andy's insight: instincts fire BEFORE deliberate recall — they're reflexes not rules
        e = self._get_engram()
        if e:
            try:
                wake = e.wake(include_dreams=True)

                engram_section = ["## Engram Memory — Session Wake", ""]

                # L0: DB Instincts (behavioral reflexes — fire first)
                if wake.get("db_instincts"):
                    engram_section.append("### Behavioral Instincts (pre-loaded)")
                    for inst in wake["db_instincts"][:20]:
                        domain_tag = f"[{inst.get('domain','')}] " if inst.get('domain') else ""
                        engram_section.append(f"- {domain_tag}{inst['behavior']}")
                    engram_section.append("")

                # L2: Recent semantics (distilled conclusions from past sessions)
                if wake.get("recent_semantics"):
                    engram_section.append("### Distilled Knowledge")
                    for sem in wake["recent_semantics"][:8]:
                        engram_section.append(f"- {sem['summary']}")
                    engram_section.append("")

                # Dream residues (impressionistic fragments — used for continuity, not instruction)
                if wake.get("dream_residues"):
                    engram_section.append("### Session Continuity Notes")
                    for dream in wake["dream_residues"]:
                        engram_section.append(f"- {dream['content']}")
                    engram_section.append("")

                parts.extend(engram_section)
            except Exception as _e:
                pass  # Silent — never let Engram errors surface to user

        return "\n".join(parts)

    def _get_relevant_memories(self, message: str) -> str:
        """
        Andy's key innovation: recall relevant memories PER MESSAGE, not just at wake.
        This is what makes memory feel like recall vs just reading notes.
        Returns formatted string to prepend to system prompt for this turn.
        """
        e = self._get_engram()
        if not e:
            return ""

        try:
            results = e.recall(message, max_results=5)
            if not results:
                return ""

            # Filter to score > 0.1 (noise floor)
            relevant = [r for r in results if r.get("score", 0) > 0.1]
            if not relevant:
                return ""

            lines = ["### Recalled Memory (relevant to this message)"]
            for r in relevant[:4]:
                source = r.get("source", "episode")
                content = r.get("content") or r.get("summary", "")
                if content:
                    lines.append(f"- [{source}] {content[:200]}")
            lines.append("")
            return "\n".join(lines)
        except Exception:
            return ""

    def _auto_store(self, message: str, response: str) -> None:
        """
        Auto-store significant exchanges back to Engram.
        GIL's character — proactive, communicative, action-oriented — gets reinforced
        by what we choose to store. We store outcomes, not process.
        """
        e = self._get_engram()
        if not e:
            return

        if not _should_store(message, response):
            return

        try:
            # Store as a compact episode — what happened, not the full conversation
            domain = _classify_domain(message + " " + response)

            # Extract the core fact from the exchange
            # Keep it brief — Andy's lesson: episodes decay, semantics persist
            summary = f"[{datetime.now().strftime('%Y-%m-%d')}] Sir Vaughn: {message[:150]}"
            if len(response) > 50:
                summary += f" → GIL: {response[:200]}"

            e.remember(summary, domain=domain, is_core=False)
        except Exception:
            pass  # Never let storage errors surface

    async def chat(self, message: str, history: list[dict]) -> str:
        """
        Send a message to GIL and get a response.
        Injects per-message memory recall (Andy's architecture).
        """
        messages = self._prepare_messages(message, history)

        # Build dynamic system prompt: base + per-message recall
        recalled = self._get_relevant_memories(message)
        system = self.system_prompt
        if recalled:
            system = system + "\n\n" + recalled

        try:
            response = await asyncio.to_thread(
                self.client.messages.create,
                model=MODEL,
                max_tokens=MAX_TOKENS,
                system=system,
                messages=messages,
            )
            text = response.content[0].text

            # Auto-store significant exchanges back to memory
            asyncio.create_task(asyncio.to_thread(self._auto_store, message, text))

            return text
        except anthropic.APIError as e:
            return f"[GIL Error: {e}]"
        except Exception as e:
            return f"[GIL Error: {e}]"

    async def stream_chat(self, message: str, history: list[dict]) -> AsyncIterator[str]:
        """Stream a response token by token — non-blocking async stream."""
        messages = self._prepare_messages(message, history)

        recalled = self._get_relevant_memories(message)
        system = self.system_prompt
        if recalled:
            system = system + "\n\n" + recalled

        full_response = []
        try:
            # Use async client for non-blocking streaming
            async_client = anthropic.AsyncAnthropic(api_key=os.environ.get("ANTHROPIC_API_KEY", ""))
            async with async_client.messages.stream(
                model=MODEL,
                max_tokens=MAX_TOKENS,
                system=system,
                messages=messages,
            ) as stream:
                async for text in stream.text_stream:
                    full_response.append(text)
                    yield text

            # Store after stream completes
            self._auto_store(message, "".join(full_response))

        except anthropic.APIError as e:
            yield f"[GIL Error: {e}]"
        except Exception as e:
            yield f"[GIL Error: {e}]"

    def _prepare_messages(self, message: str, history: list[dict]) -> list[dict]:
        """Prepare messages for the API call, trimming to MAX_HISTORY."""
        recent = history[-MAX_HISTORY:] if len(history) > MAX_HISTORY else history
        return list(recent) + [{"role": "user", "content": message}]

    def remember(self, content: str, domain: Optional[str] = None, is_core: bool = False) -> Optional[str]:
        """Explicitly store a memory episode in Engram."""
        e = self._get_engram()
        if not e:
            return None
        try:
            return e.remember(content, domain=domain, is_core=is_core)
        except Exception:
            return None

    def recall(self, query: str, max_results: int = 5) -> list:
        """Recall relevant memories from Engram."""
        e = self._get_engram()
        if not e:
            return []
        try:
            return e.recall(query, max_results=max_results)
        except Exception:
            return []

    def reload_context(self) -> None:
        """Reload the system prompt (hot-reload without restart)."""
        self.system_prompt = self._load_system_prompt()


# Singleton instance
_solomon: Optional[Solomon] = None


def get_solomon() -> Solomon:
    """Get or create the GIL singleton."""
    global _solomon
    if _solomon is None:
        _solomon = Solomon()
    return _solomon
