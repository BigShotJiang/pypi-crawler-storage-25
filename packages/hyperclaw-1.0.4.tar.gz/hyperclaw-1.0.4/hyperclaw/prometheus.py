"""
PROMETHEUS — Memory Consolidation Daemon
GIL's overnight memory processor.

Functions:
- Process daily logs into semantic knowledge
- Extract patterns into instincts
- Consolidate episodic memories
- Prune stale/redundant memories
- Generate session continuity notes ("dreams")

Runs nightly at 3am or on-demand via /api/memory/consolidate.
"""

import asyncio
import json
import logging
import os
import re
from datetime import datetime, timedelta
from pathlib import Path
from typing import Optional

import anthropic
from dotenv import load_dotenv

load_dotenv()

logger = logging.getLogger("hyperclaw.prometheus")

# Paths
HYPERCLAW_ROOT = Path("/Users/mentat/.hyperclaw")
MEMORY_PATH = HYPERCLAW_ROOT / "memory"
WORKSPACE_PATH = HYPERCLAW_ROOT / "workspace"
INSTINCTS_FILE = MEMORY_PATH / "instincts.md"
CORE_EPISODES_FILE = MEMORY_PATH / "core-episodes.md"
KNOWLEDGE_FILE = MEMORY_PATH / "KNOWLEDGE.md"
DREAMS_FILE = MEMORY_PATH / "dreams.md"

MODEL = "claude-sonnet-4-20250514"  # Use Sonnet for consolidation (cost-efficient)
MAX_TOKENS = 4096


class Prometheus:
    """Memory consolidation engine."""

    def __init__(self):
        self.client = anthropic.Anthropic(api_key=os.environ.get("ANTHROPIC_API_KEY", ""))
        self._last_run: Optional[datetime] = None

    async def consolidate(self, days_back: int = 1) -> dict:
        """
        Main consolidation routine.

        1. Read recent daily logs
        2. Extract decisions, approvals, key facts → CORE episodes
        3. Identify behavioral patterns → instincts
        4. Generate session continuity notes → dreams
        5. Prune redundant entries
        """
        logger.info(f"PROMETHEUS starting consolidation (days_back={days_back})")

        results = {
            "logs_processed": 0,
            "episodes_extracted": 0,
            "instincts_added": 0,
            "dreams_generated": 0,
            "errors": [],
        }

        try:
            # 1. Gather daily logs
            logs = self._gather_logs(days_back)
            results["logs_processed"] = len(logs)

            if not logs:
                logger.info("No logs to process")
                return results

            # 2. Extract core episodes
            episodes = await self._extract_episodes(logs)
            if episodes:
                self._append_episodes(episodes)
                results["episodes_extracted"] = len(episodes)

            # 3. Extract behavioral patterns
            instincts = await self._extract_instincts(logs)
            if instincts:
                self._append_instincts(instincts)
                results["instincts_added"] = len(instincts)

            # 4. Generate dreams (session continuity notes)
            dreams = await self._generate_dreams(logs)
            if dreams:
                self._save_dreams(dreams)
                results["dreams_generated"] = len(dreams)

            # 5. Deduplicate
            self._deduplicate_instincts()

            self._last_run = datetime.now()
            logger.info(f"PROMETHEUS complete: {results}")

        except Exception as e:
            logger.error(f"PROMETHEUS error: {e}", exc_info=True)
            results["errors"].append(str(e))

        return results

    def _gather_logs(self, days_back: int) -> list[dict]:
        """Read recent daily logs."""
        logs = []
        today = datetime.now()

        for i in range(days_back):
            date = today - timedelta(days=i)
            date_str = date.strftime("%Y-%m-%d")

            # Check both memory and workspace paths
            for base in [MEMORY_PATH, WORKSPACE_PATH / "memory"]:
                log_path = base / f"{date_str}.md"
                if log_path.exists():
                    try:
                        content = log_path.read_text(encoding="utf-8")
                        if content.strip():
                            logs.append({
                                "date": date_str,
                                "path": str(log_path),
                                "content": content[:50000],  # Limit size
                            })
                    except Exception as e:
                        logger.warning(f"Failed to read {log_path}: {e}")

        return logs

    async def _extract_episodes(self, logs: list[dict]) -> list[str]:
        """Use Claude to extract key decisions and facts from logs."""
        combined = "\n\n---\n\n".join(
            f"## {log['date']}\n{log['content']}" for log in logs
        )

        prompt = f"""Analyze these daily logs from GIL (an AI Executive Assistant) and extract CORE EPISODES that should be permanently remembered.

Extract ONLY:
- Explicit approvals or decisions from Sir Vaughn
- New key facts about people, projects, or systems
- Completed significant actions
- Policy changes or new instructions

Format each as a single line starting with the date:
[YYYY-MM-DD] Brief description of the key fact/decision

Do NOT include:
- Routine tasks
- In-progress work
- Technical debugging
- Conversations without decisions

Return ONLY the extracted episodes, one per line. If none found, return "NONE".

LOGS:
{combined}"""

        try:
            response = await asyncio.to_thread(
                self.client.messages.create,
                model=MODEL,
                max_tokens=MAX_TOKENS,
                messages=[{"role": "user", "content": prompt}],
            )
            text = response.content[0].text.strip()

            if text == "NONE":
                return []

            # Parse episodes
            episodes = [
                line.strip() for line in text.split("\n")
                if line.strip() and line.strip().startswith("[")
            ]
            return episodes
        except Exception as e:
            logger.error(f"Episode extraction failed: {e}")
            return []

    async def _extract_instincts(self, logs: list[dict]) -> list[str]:
        """Extract behavioral patterns that should become instincts."""
        combined = "\n\n---\n\n".join(
            f"## {log['date']}\n{log['content']}" for log in logs
        )

        prompt = f"""Analyze these daily logs and identify NEW behavioral instincts GIL should adopt.

An instinct is a pre-loaded behavioral reflex that fires before deliberation.

Extract patterns like:
- "When X happens, always do Y"
- "Never do X without checking Y"
- "If Sir Vaughn mentions X, immediately check Y"

Format each instinct as:
[DOMAIN] Brief behavioral rule

Domains: trading, email, communication, system, memory, calendar, general

Return ONLY new instincts that emerge from these logs. If none, return "NONE".
Do not repeat obvious or already-established behaviors.

LOGS:
{combined}"""

        try:
            response = await asyncio.to_thread(
                self.client.messages.create,
                model=MODEL,
                max_tokens=1024,
                messages=[{"role": "user", "content": prompt}],
            )
            text = response.content[0].text.strip()

            if text == "NONE":
                return []

            instincts = [
                line.strip() for line in text.split("\n")
                if line.strip() and line.strip().startswith("[")
            ]
            return instincts
        except Exception as e:
            logger.error(f"Instinct extraction failed: {e}")
            return []

    async def _generate_dreams(self, logs: list[dict]) -> list[str]:
        """Generate session continuity notes (impressionistic fragments)."""
        combined = "\n\n---\n\n".join(
            f"## {log['date']}\n{log['content']}" for log in logs
        )

        prompt = f"""Generate 2-4 brief "dream residues" from these daily logs.

Dreams are impressionistic session continuity notes — not facts, but emotional/relational threads GIL should carry forward.

Examples:
- "Sir Vaughn seemed energized about the space vertical"
- "Email tone today was formal — maintain that register"
- "Trading volatility required extra caution"

Be brief (one sentence each). Focus on tone, energy, and relationship dynamics.

LOGS:
{combined}

Return dreams as bullet points. If nothing stands out, return "NONE"."""

        try:
            response = await asyncio.to_thread(
                self.client.messages.create,
                model=MODEL,
                max_tokens=512,
                messages=[{"role": "user", "content": prompt}],
            )
            text = response.content[0].text.strip()

            if text == "NONE":
                return []

            dreams = [
                line.strip().lstrip("-").strip()
                for line in text.split("\n")
                if line.strip() and line.strip().startswith("-")
            ]
            return dreams
        except Exception as e:
            logger.error(f"Dream generation failed: {e}")
            return []

    def _append_episodes(self, episodes: list[str]) -> None:
        """Append new episodes to core-episodes.md."""
        if not episodes:
            return

        CORE_EPISODES_FILE.parent.mkdir(parents=True, exist_ok=True)

        existing = ""
        if CORE_EPISODES_FILE.exists():
            existing = CORE_EPISODES_FILE.read_text(encoding="utf-8")

        # Avoid duplicates
        new_episodes = []
        for ep in episodes:
            # Extract date and content for matching
            match = re.match(r"\[(\d{4}-\d{2}-\d{2})\]\s*(.+)", ep)
            if match:
                content = match.group(2).lower()
                if content not in existing.lower():
                    new_episodes.append(ep)

        if new_episodes:
            with open(CORE_EPISODES_FILE, "a", encoding="utf-8") as f:
                f.write("\n")
                for ep in new_episodes:
                    f.write(f"- {ep}\n")
            logger.info(f"Added {len(new_episodes)} episodes to core-episodes.md")

    def _append_instincts(self, instincts: list[str]) -> None:
        """Append new instincts to instincts.md."""
        if not instincts:
            return

        INSTINCTS_FILE.parent.mkdir(parents=True, exist_ok=True)

        existing = ""
        if INSTINCTS_FILE.exists():
            existing = INSTINCTS_FILE.read_text(encoding="utf-8")

        # Avoid duplicates (fuzzy match)
        new_instincts = []
        for inst in instincts:
            # Simple dedup: check if core phrase exists
            core = re.sub(r"\[[^\]]+\]\s*", "", inst).lower()[:50]
            if core not in existing.lower():
                new_instincts.append(inst)

        if new_instincts:
            with open(INSTINCTS_FILE, "a", encoding="utf-8") as f:
                f.write("\n")
                for inst in new_instincts:
                    f.write(f"- {inst}\n")
            logger.info(f"Added {len(new_instincts)} instincts")

    def _save_dreams(self, dreams: list[str]) -> None:
        """Save dream residues (replace daily)."""
        if not dreams:
            return

        DREAMS_FILE.parent.mkdir(parents=True, exist_ok=True)

        today = datetime.now().strftime("%Y-%m-%d")
        content = f"# Dream Residues — {today}\n\n"
        for dream in dreams:
            content += f"- {dream}\n"

        DREAMS_FILE.write_text(content, encoding="utf-8")
        logger.info(f"Saved {len(dreams)} dreams")

    def _deduplicate_instincts(self) -> None:
        """Remove duplicate instincts."""
        if not INSTINCTS_FILE.exists():
            return

        try:
            content = INSTINCTS_FILE.read_text(encoding="utf-8")
            lines = content.split("\n")

            seen = set()
            unique_lines = []

            for line in lines:
                # Normalize for comparison
                if line.strip().startswith("-"):
                    core = line.lower().strip()[:80]
                    if core not in seen:
                        seen.add(core)
                        unique_lines.append(line)
                else:
                    unique_lines.append(line)

            INSTINCTS_FILE.write_text("\n".join(unique_lines), encoding="utf-8")
        except Exception as e:
            logger.warning(f"Dedup failed: {e}")

    def status(self) -> dict:
        """Get Prometheus status."""
        return {
            "name": "PROMETHEUS",
            "status": "active",
            "last_run": self._last_run.isoformat() if self._last_run else None,
            "instincts_file": str(INSTINCTS_FILE),
            "core_episodes_file": str(CORE_EPISODES_FILE),
            "dreams_file": str(DREAMS_FILE),
        }


# Singleton
_prometheus: Optional[Prometheus] = None


def get_prometheus() -> Prometheus:
    """Get or create Prometheus singleton."""
    global _prometheus
    if _prometheus is None:
        _prometheus = Prometheus()
    return _prometheus


async def run_consolidation(days_back: int = 1) -> dict:
    """Run memory consolidation."""
    prometheus = get_prometheus()
    return await prometheus.consolidate(days_back)


if __name__ == "__main__":
    import sys

    logging.basicConfig(level=logging.INFO)

    days = int(sys.argv[1]) if len(sys.argv) > 1 else 1
    result = asyncio.run(run_consolidation(days))
    print(json.dumps(result, indent=2))
