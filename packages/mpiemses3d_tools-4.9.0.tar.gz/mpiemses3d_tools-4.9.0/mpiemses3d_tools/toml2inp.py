"""Convert plasma.toml to legacy plasma.inp (Fortran namelist) format."""

from __future__ import annotations

import argparse
import copy
import sys
from pathlib import Path
from typing import Any

try:
    import tomllib  # Python 3.11+
except ImportError:
    try:
        import tomli as tomllib  # type: ignore[no-redef]
    except ImportError:
        tomllib = None  # type: ignore[assignment]


ALL_NAMELIST_GROUPS = [
    "real",
    "realcv",
    "esorem",
    "jobcon",
    "digcon",
    "plasma",
    "tmgrid",
    "system",
    "intp",
    "others",
    "inp",
    "ptcond",
    "jsrc",
    "wave",
    "scrnt",
    "emissn",
    "testch",
    "dipole",
    "mpi",
    "verbose",
    "gradema",
]

DEFAULT_NAMELIST_GROUPS = [group for group in ALL_NAMELIST_GROUPS if group != "real"]

SPECIES_FALLBACK_GROUPS = ["plasma", "intp", "inp", "emissn", "digcon", "system", "ptcond"]

_SPECIES_PARAM_GROUP: dict[str, str] = {}
for _group_name, _keys in [
    ("plasma", ["wp", "denmod", "denk", "omegalw"]),
    (
        "intp",
        [
            "np",
            "npin",
            "qm",
            "path",
            "peth",
            "spa",
            "spe",
            "speth",
            "f",
            "vdx",
            "vdy",
            "vdz",
            "vdri",
            "vdthz",
            "vdthxy",
            "vpa",
            "vpb",
            "vpe",
            "nphi",
            "ndst",
            "ioptd",
            "lcgamma",
            "lcbeta",
            "dnsf",
        ],
    ),
    ("inp", ["inpf", "inpb", "injct", "npr"]),
    (
        "emissn",
        [
            "nflag_emit",
            "nepl",
            "flpf",
            "flpb",
            "curf",
            "curb",
            "qp",
            "qpr",
            "abvdem",
            "dnsb",
            "ray_zenith_angle_deg",
            "ray_azimuth_angle_deg",
            "emission_time_mode",
            "emission_start_step",
            "emission_end_step",
            "emission_time_sigma",
            "emission_leave_anti_particle",
        ],
    ),
    ("digcon", ["ipadig", "ipahdf", "ipaxyz", "ildig", "imdig", "isort", "irhsp"]),
    ("system", ["npbnd", "mfpath"]),
    ("ptcond", ["pemax", "deltaemax"]),
]:
    for _key in _keys:
        _SPECIES_PARAM_GROUP[_key] = _group_name

_GENERIC_AOT = {
    "emissn": {
        "aot_key": "planes",
        "count_var": "nepl",
        "col_params": set(),
        "groups_key": "plane_groups",
    },
    "dipole": {
        "aot_key": "sources",
        "count_var": "nmd",
        "col_params": set(),
        "groups_key": "source_groups",
    },
    "testch": {
        "aot_key": "charges",
        "count_var": "ntch",
        "col_params": {"rtch", "dimclst", "rclst"},
        "groups_key": "charge_groups",
    },
    "jsrc": {
        "aot_key": "sources",
        "count_var": "njs",
        "col_params": {"rjs", "ajs"},
        "groups_key": "source_groups",
    },
}

_OBJECT_COLUMN_PARAMS = {"bdycoord", "bdyedge", "oradius", "wireorigin"}

_BOUNDARY_COLUMN_PARAMS = {
    "rectangle_shape",
    "cuboid_shape",
    "sphere_origin",
    "circle_origin",
    "cylinder_origin",
    "disk_origin",
    "plane_with_circle_origin",
    "wireorigin",
    "oradius",
    "bdyedge",
    "bdycoord",
}


def _warn(message: str) -> None:
    print(f"WARNING: {message}", file=sys.stderr)


def _read_toml(path: Path) -> dict[str, Any]:
    if tomllib is None:
        raise ImportError(
            "Python 3.11+ or the 'tomli' package is required to read TOML files."
        )
    with open(path, "rb") as handle:
        data = tomllib.load(handle)
    if not isinstance(data, dict):
        raise ValueError("top-level TOML value must be a table")
    return data


def _format_scalar(value: Any) -> str:
    if isinstance(value, bool):
        return ".true." if value else ".false."
    if isinstance(value, int):
        return str(value)
    if isinstance(value, float):
        text = repr(value)
        if "." not in text and "e" not in text.lower():
            text += ".0"
        return text
    if isinstance(value, str):
        return "'" + value.replace("'", "''") + "'"
    raise TypeError(f"unsupported scalar value: {value!r}")


def _serialize_vector(values: list[Any]) -> str:
    if not values:
        raise ValueError("empty arrays cannot be serialized to plasma.inp")
    return ", ".join(_format_scalar(value) for value in values)


def _is_table_array(value: Any) -> bool:
    return isinstance(value, list) and bool(value) and isinstance(value[0], dict)


def _emit_flat_value(lines: list[str], key: str, value: Any) -> None:
    if isinstance(value, dict) or _is_table_array(value):
        raise ValueError(f"{key} is a table-like value and cannot be written flat")

    if isinstance(value, list):
        if not value:
            raise ValueError(f"{key} is an empty array and cannot be written")
        if isinstance(value[0], list):
            for row_index, row in enumerate(value, start=1):
                if not isinstance(row, list) or not row:
                    raise ValueError(f"{key} has an invalid matrix row")
                lines.append(
                    f"    {key}({row_index},1:{len(row)}) = {_serialize_vector(row)}"
                )
        else:
            lines.append(f"    {key}(1:{len(value)}) = {_serialize_vector(value)}")
        return

    lines.append(f"    {key} = {_format_scalar(value)}")


def _emit_indexed_value(
    lines: list[str],
    key: str,
    value: Any,
    index: int,
    *,
    array_mode: str,
) -> None:
    if isinstance(value, dict) or _is_table_array(value):
        raise ValueError(f"{key} is a nested table-like value")

    if isinstance(value, list):
        if not value:
            raise ValueError(f"{key} is an empty array and cannot be written")
        if isinstance(value[0], list):
            raise ValueError(f"{key} has unsupported nested array shape")
        if array_mode == "column":
            lines.append(f"    {key}(:,{index}) = {_serialize_vector(value)}")
        else:
            lines.append(f"    {key}({index},:) = {_serialize_vector(value)}")
        return

    lines.append(f"    {key}({index}) = {_format_scalar(value)}")


def _emit_key_header(lines: list[str], data: dict[str, Any]) -> None:
    meta = data.get("meta")
    if not isinstance(meta, dict):
        return
    unit_conversion = meta.get("unit_conversion")
    if not isinstance(unit_conversion, dict) or not unit_conversion:
        return

    parts: list[str] = []
    for key, value in unit_conversion.items():
        if isinstance(value, list):
            if len(value) != 1:
                raise ValueError(
                    f"meta.unit_conversion.{key} must be scalar-compatible for !!key"
                )
            value = value[0]
        parts.append(f"{key}=[{_format_scalar(value)}]")
    lines.append("!!key " + ",".join(parts))
    lines.append("")


def _resolve_named_group(
    groups: Any,
    group_id: Any,
    *,
    groups_key: str,
    context: str,
) -> dict[str, Any] | None:
    if not isinstance(group_id, str):
        return None
    if not isinstance(groups, dict):
        return None
    group = groups.get(group_id)
    if group is None:
        _warn(f'unknown {groups_key} "{group_id}" referenced from {context}')
        return None
    if not isinstance(group, dict):
        raise ValueError(f"{groups_key}.{group_id} must be a table")
    return group


def _emit_species(lines: list[str], data: dict[str, Any], group_name: str) -> bool:
    species = data.get("species")
    if not isinstance(species, list) or not species:
        return False

    species_groups = data.get("species_groups")
    if group_name == "system":
        lines.append(f"    nspec = {len(species)}")

    for index, entry in enumerate(species, start=1):
        if not isinstance(entry, dict):
            raise ValueError("each [[species]] entry must be a table")

        defaults = _resolve_named_group(
            species_groups,
            entry.get("group_id"),
            groups_key="species_groups",
            context="[[species]]",
        )
        for source in (defaults, entry):
            if not source:
                continue
            for key, value in source.items():
                if key == "group_id":
                    continue
                if _SPECIES_PARAM_GROUP.get(key) != group_name:
                    continue
                _emit_indexed_value(lines, key, value, index, array_mode="column")

    return True


def _resolve_boundary_type(
    entry: dict[str, Any],
    boundary_groups: Any,
) -> str | None:
    value = entry.get("type")
    if isinstance(value, str):
        return value

    defaults = _resolve_named_group(
        boundary_groups,
        entry.get("group_id"),
        groups_key="boundary_groups",
        context="[[ptcond.boundaries]]",
    )
    if not defaults:
        return None
    value = defaults.get("type")
    return value if isinstance(value, str) else None


def _emit_boundaries(lines: list[str], ptcond_group: dict[str, Any]) -> bool:
    boundaries = ptcond_group.get("boundaries")
    if not isinstance(boundaries, list) or not boundaries:
        return False

    boundary_groups = ptcond_group.get("boundary_groups")
    lines.append("    boundary_type = 'complex'")

    for index, entry in enumerate(boundaries, start=1):
        if not isinstance(entry, dict):
            raise ValueError("each [[ptcond.boundaries]] entry must be a table")

        boundary_type = _resolve_boundary_type(entry, boundary_groups)
        if boundary_type is not None:
            lines.append(
                f"    boundary_types({index}) = {_format_scalar(boundary_type)}"
            )
        else:
            _warn(f'[[ptcond.boundaries]] entry {index} has no "type" key')

        defaults = _resolve_named_group(
            boundary_groups,
            entry.get("group_id"),
            groups_key="boundary_groups",
            context="[[ptcond.boundaries]]",
        )
        for source in (defaults, entry):
            if not source:
                continue
            for key, value in source.items():
                if key in {"type", "group_id"}:
                    continue
                array_mode = "column" if key in _BOUNDARY_COLUMN_PARAMS else "row"
                _emit_indexed_value(lines, key, value, index, array_mode=array_mode)

    return True


def _resolve_object_conductor(
    entry: dict[str, Any],
    object_groups: Any,
) -> str:
    conductor = entry.get("conductor")
    if isinstance(conductor, str):
        return conductor

    defaults = _resolve_named_group(
        object_groups,
        entry.get("group_id"),
        groups_key="object_groups",
        context="[[ptcond.objects]]",
    )
    if defaults:
        conductor = defaults.get("conductor")
        if isinstance(conductor, str):
            return conductor

    raise ValueError(
        '[[ptcond.objects]] entry must define "conductor" directly or via group_id'
    )


def _emit_objects(lines: list[str], ptcond_group: dict[str, Any]) -> bool:
    conductor_groups = ptcond_group.get("conductor_groups")
    objects = ptcond_group.get("objects")
    if not isinstance(conductor_groups, dict):
        return False
    if not isinstance(objects, list) or not objects:
        return False

    conductor_names = list(conductor_groups.keys())
    if not conductor_names:
        return False

    object_groups = ptcond_group.get("object_groups")
    group_count = {name: 0 for name in conductor_names}
    resolved_conductors: list[str] = []

    for entry in objects:
        if not isinstance(entry, dict):
            raise ValueError("each [[ptcond.objects]] entry must be a table")
        conductor = _resolve_object_conductor(entry, object_groups)
        if conductor not in group_count:
            raise ValueError(
                f'unknown conductor group in [[ptcond.objects]]: "{conductor}"'
            )
        group_count[conductor] += 1
        resolved_conductors.append(conductor)

    lines.append(f"    npc = {len(objects)}")
    lines.append(f"    npcg = {len(conductor_names)}")
    counts = [group_count[name] for name in conductor_names]
    lines.append(f"    pcgs(1:{len(conductor_names)}) = {_serialize_vector(counts)}")
    lines.append(f"    ccgs(1:{len(conductor_names)}) = {_serialize_vector(counts)}")

    for index, conductor_name in enumerate(conductor_names, start=1):
        group = conductor_groups[conductor_name]
        if not isinstance(group, dict):
            raise ValueError(f"ptcond.conductor_groups.{conductor_name} must be a table")
        for key, value in group.items():
            if isinstance(value, (dict, list)):
                raise ValueError(
                    f"ptcond.conductor_groups.{conductor_name}.{key} must be scalar"
                )
            _emit_indexed_value(lines, key, value, index, array_mode="row")

    object_index = 0
    for conductor_name in conductor_names:
        for entry, resolved_conductor in zip(objects, resolved_conductors):
            if resolved_conductor != conductor_name:
                continue
            object_index += 1
            defaults = _resolve_named_group(
                object_groups,
                entry.get("group_id"),
                groups_key="object_groups",
                context="[[ptcond.objects]]",
            )
            for source in (defaults, entry):
                if not source:
                    continue
                for key, value in source.items():
                    if key in {"conductor", "group_id"}:
                        continue
                    array_mode = "column" if key in _OBJECT_COLUMN_PARAMS else "row"
                    _emit_indexed_value(
                        lines,
                        key,
                        value,
                        object_index,
                        array_mode=array_mode,
                    )

    return True


def _emit_generic_aot(
    lines: list[str],
    group_name: str,
    group: dict[str, Any],
) -> bool:
    spec = _GENERIC_AOT.get(group_name)
    if spec is None:
        return False

    entries = group.get(spec["aot_key"])
    if not isinstance(entries, list) or not entries:
        return False

    group_defaults = group.get(spec["groups_key"])
    lines.append(f"    {spec['count_var']} = {len(entries)}")

    for index, entry in enumerate(entries, start=1):
        if not isinstance(entry, dict):
            raise ValueError(f"each [[{group_name}.{spec['aot_key']}]] entry must be a table")

        defaults = _resolve_named_group(
            group_defaults,
            entry.get("group_id"),
            groups_key=spec["groups_key"],
            context=f"[[{group_name}.{spec['aot_key']}]]",
        )
        for source in (defaults, entry):
            if not source:
                continue
            for key, value in source.items():
                if key == "group_id":
                    continue
                array_mode = "column" if key in spec["col_params"] else "row"
                _emit_indexed_value(lines, key, value, index, array_mode=array_mode)

    return True


def _skip_group_key(
    group_name: str,
    key: str,
    *,
    boundaries_expanded: bool,
    objects_expanded: bool,
    species_expanded: bool,
) -> bool:
    if group_name == "ptcond":
        if key in {"boundaries", "conductor_groups", "boundary_groups", "objects", "object_groups"}:
            return True
        if boundaries_expanded and key == "boundary_type":
            return True
        if objects_expanded and key in {"npc", "npcg", "pcgs", "ccgs"}:
            return True

    spec = _GENERIC_AOT.get(group_name)
    if spec is not None and key in {spec["aot_key"], spec["groups_key"]}:
        return True

    if group_name == "system" and species_expanded and key == "nspec":
        return True

    return False


def _apply_meta_physical(data: dict[str, Any]) -> dict[str, Any]:
    from .plasma_toml import PlasmaToml

    toml = PlasmaToml.from_dict(copy.deepcopy(data))
    toml.apply_physical()
    return toml.data


def to_inp(
    data: dict[str, Any],
    *,
    apply_physical: bool = False,
    include_real: bool = False,
) -> str:
    if apply_physical:
        data = _apply_meta_physical(data)

    lines: list[str] = []
    _emit_key_header(lines, data)

    species_present = isinstance(data.get("species"), list) and bool(data.get("species"))
    group_names = ALL_NAMELIST_GROUPS if include_real else DEFAULT_NAMELIST_GROUPS

    for group_name in group_names:
        raw_group = data.get(group_name)
        needs_species_fallback = species_present and group_name in SPECIES_FALLBACK_GROUPS
        if raw_group is None and not needs_species_fallback:
            continue
        if raw_group is not None and not isinstance(raw_group, dict):
            raise ValueError(f"top-level TOML entry {group_name!r} must be a table")

        group = raw_group if isinstance(raw_group, dict) else {}
        lines.append(f"&{group_name}")

        boundaries_expanded = False
        objects_expanded = False
        if group_name == "ptcond":
            boundaries_expanded = _emit_boundaries(lines, group)
            objects_expanded = _emit_objects(lines, group)

        _emit_generic_aot(lines, group_name, group)
        species_expanded = _emit_species(lines, data, group_name)

        for key, value in group.items():
            if _skip_group_key(
                group_name,
                key,
                boundaries_expanded=boundaries_expanded,
                objects_expanded=objects_expanded,
                species_expanded=species_expanded,
            ):
                continue
            _emit_flat_value(lines, key, value)

        lines.append("/")
        lines.append("")

    return "\n".join(lines).rstrip() + "\n"


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(
        prog="toml2inp",
        description="Convert plasma.toml to legacy plasma.inp.",
    )
    parser.add_argument("input", help="Path to plasma.toml")
    parser.add_argument(
        "-o",
        "--output",
        default=None,
        help="Output path (default: <input>.inp). Use '-' for stdout.",
    )
    parser.add_argument(
        "--apply-physical",
        action=argparse.BooleanOptionalAction,
        default=False,
        help="Apply [meta.physical] in-memory before emitting legacy namelists.",
    )
    parser.add_argument(
        "--include-real",
        action=argparse.BooleanOptionalAction,
        default=False,
        help="Include raw [real] as-is. Off by default because preinp-specific conversion is not performed.",
    )
    args = parser.parse_args(argv)

    input_path = Path(args.input)
    if not input_path.exists():
        print(f"ERROR: {input_path} not found.", file=sys.stderr)
        return 1

    try:
        data = _read_toml(input_path)
        inp_text = to_inp(
            data,
            apply_physical=args.apply_physical,
            include_real=args.include_real,
        )
    except (ImportError, OSError, TypeError, ValueError) as exc:
        print(f"ERROR: {exc}", file=sys.stderr)
        return 1

    if args.output == "-":
        sys.stdout.write(inp_text)
        return 0

    output_path = Path(args.output) if args.output else input_path.with_suffix(".inp")
    output_path.write_text(inp_text, encoding="utf-8")
    print(f"Written: {output_path}", file=sys.stderr)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
