"""Unit conversion between EMSES input (TOML) units and physical SI units.

The EMSES S-unit system fixes four base quantities:
    permittivity = 1, |q/m(electron)| = 1, dr = 1, dt = 2

Given dx [m] (grid spacing) and cv (= to_c, simulation light speed),
all conversion scale factors are uniquely determined.

Usage::

    from mpiemses3d_tools.unit_system import UnitSystem

    unit = UnitSystem(dx=0.005, cv=10000)
    unit.v.trans(1.23e5)       # physical m/s -> sim units
    unit.f.reverse(2.975)      # sim units -> physical rad/s
"""

from __future__ import annotations

import math
from typing import TYPE_CHECKING

import scipy.constants as cn

if TYPE_CHECKING:
    pass

# ---------------------------------------------------------------------------
# Physical constants (from scipy.constants, cached for clarity)
# ---------------------------------------------------------------------------
CLIGHT = cn.c  # speed of light [m/s]
ELEMCHG = cn.e  # elementary charge [C]
MASSELE = cn.m_e  # electron mass [kg]
EPS0 = cn.epsilon_0  # vacuum permittivity [F/m]
KBOLTZ = cn.k  # Boltzmann constant [J/K]
QM_E = ELEMCHG / MASSELE  # |q/m| for electron [C/kg]


# ---------------------------------------------------------------------------
# Parameter -> unit-type mapping (derived from rescale.F90)
# ---------------------------------------------------------------------------
PARAM_UNIT_MAP: dict[str, str] = {
    # velocity
    "path": "v",
    "peth": "v",
    "spa": "v",
    "spe": "v",
    "vdx": "v",
    "vdy": "v",
    "vdz": "v",
    "vdri": "v",
    "vpa": "v",
    "vpb": "v",
    "vpe": "v",
    "cv": "v",
    # velocity squared (special)
    "cs": "v_squared",
    "tcs": "v_squared",
    "pemax": "v_squared",
    # frequency
    "wp": "f",
    "wc": "f",
    "wjs": "f",
    # electric field
    "e0x": "e",
    "e0y": "e",
    "e0z": "e",
    "gap_amp": "e",
    "e1tch": "e",
    # magnetic field
    "b0": "b",
    "b0x": "b",
    "b0y": "b",
    "b0z": "b",
    # potential
    "biasp": "phi",
    "pswspn": "phi",
    "pfixed": "phi",
    "p1tch": "phi",
    # charge
    "qtch": "q",
    # current density
    "ajs": "j",
    "ajs_amp": "j",
    "curf": "j",
    "curb": "j",
    "curfs": "j",
    "curbs": "j",
    "flpf": "j",
    "flpb": "j",
    "flpfs": "j",
    "flpbs": "j",
    # charge density
    "rhopeak": "rho",
    # conductivity
    "conductivity": "ec",
    # energy (eV)
    "boundary_se_energy_max": "energy_ev",
    # distance (emission walls etc.)
    "xwdte": "r",
    "ywdte": "r",
    "zwdte": "r",
}


# ---------------------------------------------------------------------------
# _QuantityConverter
# ---------------------------------------------------------------------------
class _QuantityConverter:
    """Converter for a single physical quantity.

    The *scale* is the physical value of one input (simulation) unit.
    For example if ``scale = 29979.2`` for velocity, then 1 input velocity
    unit equals 29979.2 m/s.
    """

    __slots__ = ("_scale", "name", "unit")

    def __init__(self, scale: float, name: str, unit_label: str) -> None:
        self._scale = scale
        self.name = name
        self.unit = unit_label

    @property
    def scale(self) -> float:
        """Physical value per one input unit."""
        return self._scale

    def trans(self, physical_value: float) -> float:
        """Convert physical SI value to input (simulation) units.

        Same convention as the legacy ``preinp`` tool:
        ``unit.v.trans(c_phys)`` returns ``cv``.
        """
        return physical_value / self._scale

    def reverse(self, sim_value: float) -> float:
        """Convert input (simulation) value to physical SI units."""
        return sim_value * self._scale

    def __repr__(self) -> str:
        return f"_QuantityConverter({self.name!r}, scale={self._scale:.6e}, unit={self.unit!r})"


# ---------------------------------------------------------------------------
# UnitSystem
# ---------------------------------------------------------------------------
class UnitSystem:
    """Unit converter between EMSES input units and physical SI units.

    Parameters
    ----------
    dx : float
        Grid spacing in metres.
    cv : float
        Simulation light speed (= ``to_c = c_phys / cv``).
    """

    def __init__(self, dx: float, cv: float) -> None:
        self.dx = dx
        self.cv = cv

        # Base scale factors
        Sv = CLIGHT / cv  # velocity: m/s per input unit
        Sr = dx  # distance: m per input unit
        St = Sr / Sv  # time:     s per input unit

        # Mass & charge from ε₀=1 and |qm_e|=1 constraints
        Sm = EPS0 * Sr**3 / (QM_E**2 * St**2)
        Sq = Sm * QM_E

        # Derived EM quantities
        Se = Sv**2 / (QM_E * Sr)  # E-field [V/m]
        Sb = Sv / (QM_E * Sr)  # B-field [T]
        Sphi = Se * Sr  # potential [V]
        Srho = Sq / Sr**3  # charge density [C/m³]
        Sj = Sq * Sv / Sr**3  # current density [A/m²]
        Sed = Sm * Sv**2 / Sr**3  # energy density [J/m³]

        # Energy
        Senergy = Sm * Sv**2  # [J]
        Senergy_ev = Senergy / ELEMCHG  # [eV]

        # Electrical circuit quantities
        Si = Sj * Sr**2  # current [A]
        Sreg = Sphi / Si if Si != 0 else 0.0  # resistance [Ω]
        Sg = 1.0 / Sreg if Sreg != 0 else 0.0  # conductance [S]
        Sec = Sg / Sr if Sr != 0 else 0.0  # conductivity [S/m]

        # Build converters
        self.r = _QuantityConverter(Sr, "distance", "m")
        self.t = _QuantityConverter(St, "time", "s")
        self.v = _QuantityConverter(Sv, "velocity", "m/s")
        self.f = _QuantityConverter(1.0 / St, "frequency", "rad/s")
        self.a = _QuantityConverter(Sv / St, "acceleration", "m/s^2")
        self.m = _QuantityConverter(Sm, "mass", "kg")
        self.q = _QuantityConverter(Sq, "charge", "C")
        self.e = _QuantityConverter(Se, "electric_field", "V/m")
        self.E = self.e  # alias
        self.b = _QuantityConverter(Sb, "magnetic_field", "T")
        self.B = self.b  # alias
        self.phi = _QuantityConverter(Sphi, "potential", "V")
        self.rho = _QuantityConverter(Srho, "charge_density", "C/m^3")
        self.j = _QuantityConverter(Sj, "current_density", "A/m^2")
        self.J = self.j  # alias
        self.ed = _QuantityConverter(Sed, "energy_density", "J/m^3")
        self.energy = _QuantityConverter(Senergy, "energy", "J")
        self.energy_ev = _QuantityConverter(Senergy_ev, "energy", "eV")
        self.i = _QuantityConverter(Si, "current", "A")
        self.reg = _QuantityConverter(Sreg, "resistance", "Ohm")
        self.g = _QuantityConverter(Sg, "conductance", "S")
        self.ec = _QuantityConverter(Sec, "conductivity", "S/m")

        # Lookup table for string-based access
        self._converters: dict[str, _QuantityConverter] = {
            "r": self.r,
            "t": self.t,
            "v": self.v,
            "f": self.f,
            "a": self.a,
            "m": self.m,
            "q": self.q,
            "e": self.e,
            "E": self.e,
            "b": self.b,
            "B": self.b,
            "phi": self.phi,
            "rho": self.rho,
            "j": self.j,
            "J": self.j,
            "ed": self.ed,
            "energy": self.energy,
            "energy_ev": self.energy_ev,
            "i": self.i,
            "reg": self.reg,
            "g": self.g,
            "ec": self.ec,
        }

    # -- String-based access ------------------------------------------------

    def converter(self, quantity: str) -> _QuantityConverter:
        """Get the converter for *quantity* (e.g. ``"v"``, ``"E"``)."""
        try:
            return self._converters[quantity]
        except KeyError:
            raise ValueError(
                f"Unknown quantity {quantity!r}. "
                f"Available: {', '.join(sorted(self._converters))}"
            ) from None

    def trans(self, quantity: str, value: float) -> float:
        """Physical -> simulation by quantity name."""
        return self.converter(quantity).trans(value)

    def reverse(self, quantity: str, value: float) -> float:
        """Simulation -> physical by quantity name."""
        return self.converter(quantity).reverse(value)

    # -- Construction helpers -----------------------------------------------

    @classmethod
    def from_toml(cls, data: dict) -> UnitSystem:
        """Construct from a parsed plasma.toml dict.

        Reads ``meta.unit_conversion.dx`` and ``meta.unit_conversion.to_c``.
        """
        meta = data.get("meta", {}).get("unit_conversion", {})
        dx = meta.get("dx")
        cv = meta.get("to_c")
        if dx is None or cv is None:
            raise ValueError(
                "plasma.toml must have [meta.unit_conversion] with dx and to_c"
            )
        # dx and to_c may be stored as single-element lists
        if isinstance(dx, list):
            dx = dx[0]
        if isinstance(cv, list):
            cv = cv[0]
        return cls(float(dx), float(cv))

    # -- Physics helper functions -------------------------------------------

    @staticmethod
    def plasma_frequency(density_m3: float, mass_kg: float = MASSELE) -> float:
        """Compute plasma frequency [rad/s] from number density [m^-3]."""
        return math.sqrt(density_m3 * ELEMCHG**2 / (EPS0 * mass_kg))

    @staticmethod
    def thermal_speed(temperature_eV: float, mass_kg: float = MASSELE) -> float:
        """Compute thermal speed [m/s] from temperature [eV]."""
        return math.sqrt(ELEMCHG * temperature_eV / mass_kg)

    @staticmethod
    def debye_length(temperature_eV: float, density_m3: float) -> float:
        """Compute Debye length [m]."""
        return math.sqrt(EPS0 * temperature_eV * ELEMCHG / (density_m3 * ELEMCHG**2))

    @staticmethod
    def cyclotron_frequency(B_tesla: float, mass_kg: float = MASSELE) -> float:
        """Compute cyclotron frequency [rad/s] from B-field [T]."""
        return abs(ELEMCHG * B_tesla / mass_kg)

    @staticmethod
    def larmor_radius(
        v_perp_ms: float, B_tesla: float, mass_kg: float = MASSELE
    ) -> float:
        """Compute Larmor radius [m]."""
        wc = abs(ELEMCHG * B_tesla / mass_kg)
        return v_perp_ms / wc if wc > 0 else float("inf")

    # -- Summary ------------------------------------------------------------

    def summary(self) -> str:
        """Human-readable summary of all conversion factors."""
        lines = [f"UnitSystem(dx={self.dx}, cv={self.cv})", ""]
        lines.append(f"  {'Quantity':<20} {'Scale (1 sim unit =)':<24} {'Unit'}")
        lines.append(f"  {'-' * 20} {'-' * 24} {'-' * 10}")
        for name, conv in self._converters.items():
            if conv is self._converters.get(name.lower(), None) or name == name.lower():
                lines.append(f"  {name:<20} {conv.scale:<24.6e} {conv.unit}")
        return "\n".join(lines)

    def __repr__(self) -> str:
        return f"UnitSystem(dx={self.dx}, cv={self.cv})"
