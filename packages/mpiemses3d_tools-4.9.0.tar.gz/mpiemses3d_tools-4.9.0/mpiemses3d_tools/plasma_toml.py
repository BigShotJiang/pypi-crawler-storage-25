"""Ergonomic interface for reading, modifying, and writing plasma.toml files.

Supports format_version 2 with ``[[species]]``, ``[[ptcond.objects]]``, etc.

Usage::

    from mpiemses3d_tools.plasma_toml import PlasmaToml

    toml = PlasmaToml.load("plasma.toml")

    # Attribute-style access
    toml.tmgrid.nx = 256
    toml.species[0].wp = 2.975
    toml.species.append({"wp": 0.1, "qm": 0.001})

    # SI-unit access
    toml.species[0].si.path = 1.5e5       # m/s -> sim units
    print(toml.species[0].si.path)         # sim units -> m/s

    # Bulk overrides
    toml.apply({"tmgrid": {"nx": 256, "ny": 256}})

    toml.write("output.toml")
"""

from __future__ import annotations

import copy
import re
from pathlib import Path
from typing import Any

from ._serialize import serialize_v2
from .unit_system import (
    ELEMCHG,
    EPS0,
    KBOLTZ,
    MASSELE,
    PARAM_UNIT_MAP,
    UnitSystem,
)

# ---------------------------------------------------------------------------
# TOML reading (tomllib / tomli fallback)
# ---------------------------------------------------------------------------
try:
    import tomllib  # Python 3.11+
except ImportError:
    try:
        import tomli as tomllib  # type: ignore[no-redef]
    except ImportError:
        tomllib = None  # type: ignore[assignment]


def _read_toml(path: Path) -> dict:
    """Read a TOML file and return a dict."""
    if tomllib is None:
        raise ImportError(
            "Python 3.11+ or the 'tomli' package is required to read TOML files."
        )
    with open(path, "rb") as fh:
        return tomllib.load(fh)


# ---------------------------------------------------------------------------
# Schema directive handling
# ---------------------------------------------------------------------------
_SCHEMA_RE = re.compile(r"^#:schema\s+(.+)$")

SCHEMA_URL = (
    "https://raw.githubusercontent.com/CS12-Laboratory/"
    "mpiemses3d-schema/refs/heads/main/plasma.schema.json"
)


def _read_schema_directive(path: Path) -> str | None:
    """Read the ``#:schema <url>`` directive from the first lines of a file."""
    try:
        with open(path, encoding="utf-8") as fh:
            for line in fh:
                line = line.strip()
                if not line or line.startswith("#"):
                    m = _SCHEMA_RE.match(line)
                    if m:
                        return m.group(1).strip()
                    continue
                break
    except OSError:
        pass
    return None


# ---------------------------------------------------------------------------
# Deep merge
# ---------------------------------------------------------------------------
def _deep_merge(base: dict, overrides: dict) -> dict:
    """Recursively merge *overrides* into *base* (mutates *base*)."""
    for key, value in overrides.items():
        if key in base and isinstance(base[key], dict) and isinstance(value, dict):
            _deep_merge(base[key], value)
        else:
            base[key] = value
    return base


# ---------------------------------------------------------------------------
# Group defaults resolution
# ---------------------------------------------------------------------------
def _resolve_aot_groups(entries: list[dict], groups: dict) -> list[dict]:
    """Return a copy of *entries* with group defaults merged in.

    For each entry that has a ``group_id`` key referencing a group in
    *groups*, the group's parameters are used as defaults.  Entry-level
    values override group-level values.  The ``group_id`` key is removed
    from the resolved entry.
    """
    resolved: list[dict] = []
    for entry in entries:
        merged: dict = {}
        gid = entry.get("group_id")
        if gid and gid in groups:
            merged.update(groups[gid])
        merged.update(entry)
        merged.pop("group_id", None)
        resolved.append(merged)
    return resolved


# ---------------------------------------------------------------------------
# Physical parameter conversion helper
# ---------------------------------------------------------------------------
def _reverse_physical_species(
    sp: dict,
    unit: UnitSystem,
    grid_cells: int | None,
) -> dict:
    """Reverse-convert one ``[[species]]`` entry to ``[[meta.physical.species]]``.

    Returns a dict of physical-unit parameters (e.g. ``mass_ratio``,
    ``qm_sign``, ``temperature_eV``, ``density_m3``, etc.).
    """
    qm = sp.get("qm", 0)
    if qm == 0:
        return {}

    abs_qm = abs(qm)
    mass_ratio = 1.0 / abs_qm
    qm_sign = 1 if qm > 0 else -1
    mass_kg = MASSELE * mass_ratio

    result: dict = {}
    result["mass_ratio"] = mass_ratio
    result["qm_sign"] = qm_sign

    # Density from plasma frequency
    wp_sim = sp.get("wp", 0)
    if wp_sim != 0:
        wp_phys = abs(wp_sim) * unit.f.scale  # [rad/s]
        # n = wp^2 * eps0 * m / e^2
        density = wp_phys**2 * EPS0 * mass_kg / ELEMCHG**2
        result["density_m3"] = density

    # Temperature from thermal speed
    path_sim = sp.get("path", 0)
    peth_sim = sp.get("peth", 0)
    if path_sim != 0:
        vth_par = abs(path_sim) * unit.v.scale  # [m/s]
        T_par_eV = mass_kg * vth_par**2 / ELEMCHG
        result["temperature_eV"] = T_par_eV
    if peth_sim != 0:
        vth_perp = abs(peth_sim) * unit.v.scale
        T_perp_eV = mass_kg * vth_perp**2 / ELEMCHG

        if path_sim != 0:
            T_par_eV = result["temperature_eV"]
            # If anisotropic, store separately
            if abs(T_par_eV - T_perp_eV) / max(T_par_eV, 1e-30) > 0.01:
                result["path_temperature_eV"] = T_par_eV
                result["peth_temperature_eV"] = T_perp_eV
                del result["temperature_eV"]
        else:
            result["temperature_eV"] = T_perp_eV

    # Drift velocity
    vdri_sim = sp.get("vdri", 0)
    if vdri_sim != 0:
        result["drift_velocity_m_s"] = vdri_sim * unit.v.scale

    # Emission current density
    nflag_emit = sp.get("nflag_emit", 0)
    curf_sim = sp.get("curf", 0)
    if nflag_emit == 2 and curf_sim != 0:
        result["emission_current_density_A_m2"] = curf_sim * unit.j.scale
    else:
        # Particles per cell
        npin = sp.get("npin", 0)
        if npin and grid_cells and grid_cells > 0:
            result["particles_per_cell"] = int(round(npin / grid_cells))

    return result


def _convert_physical_species(
    phys: dict,
    density_m3: float | None,
    unit: UnitSystem,
    grid_cells: int | None,
    global_ppc: int | None,
) -> dict:
    """Convert one ``[[meta.physical.species]]`` entry to simulation values.

    Returns a dict of simulation-unit parameters (e.g. ``wp``, ``qm``,
    ``path``, ``peth``, ``vdri``, ``npin``, ``curf``, ``nflag_emit``).
    Only keys that can be derived from the physical entry are included.
    """
    mass_ratio = phys["mass_ratio"]
    qm_sign = phys["qm_sign"]
    temperature = phys["temperature_eV"]

    # Per-species density_m3 overrides global default
    species_density = phys.get("density_m3", density_m3)
    if species_density is None:
        raise ValueError(
            "density_m3 must be specified either in [meta.physical] or "
            "in [[meta.physical.species]]."
        )

    mass_kg = MASSELE * mass_ratio
    result: dict = {}

    result["qm"] = qm_sign / mass_ratio
    result["wp"] = unit.f.trans(UnitSystem.plasma_frequency(species_density, mass_kg))

    path_temp = phys.get("path_temperature_eV", temperature)
    peth_temp = phys.get("peth_temperature_eV", temperature)
    result["path"] = unit.v.trans(UnitSystem.thermal_speed(path_temp, mass_kg))
    result["peth"] = unit.v.trans(UnitSystem.thermal_speed(peth_temp, mass_kg))

    drift = phys.get("drift_velocity_m_s", 0.0)
    result["vdri"] = unit.v.trans(drift)

    # Emission species (photoelectrons etc.)
    if "emission_current_density_A_m2" in phys:
        result["curf"] = unit.j.trans(phys["emission_current_density_A_m2"])
        result["nflag_emit"] = 2
        result["npin"] = 0
    else:
        ppc = phys.get("particles_per_cell", global_ppc)
        if ppc is not None and grid_cells is not None:
            result["npin"] = int(grid_cells * ppc)

    return result


# ---------------------------------------------------------------------------
# Proxy classes for attribute access
# ---------------------------------------------------------------------------
class _SIProxy:
    """Proxy that converts values to/from physical SI units on get/set.

    Accessed via ``group_proxy.si``.  Uses :data:`PARAM_UNIT_MAP` to
    determine the unit type for each parameter name.
    """

    __slots__ = ("_data", "_unit")

    def __init__(self, data: dict, unit: UnitSystem) -> None:
        object.__setattr__(self, "_data", data)
        object.__setattr__(self, "_unit", unit)

    def __getattr__(self, name: str) -> Any:
        val = self._data[name]
        quantity = PARAM_UNIT_MAP.get(name)
        if quantity is None or not isinstance(val, (int, float)):
            return val
        if quantity == "v_squared":
            return val * self._unit.v.scale**2
        return self._unit.reverse(quantity, val)

    def __setattr__(self, name: str, value: Any) -> None:
        quantity = PARAM_UNIT_MAP.get(name)
        if quantity is None:
            self._data[name] = value
        elif quantity == "v_squared":
            self._data[name] = value / (self._unit.v.scale**2)
        else:
            self._data[name] = self._unit.trans(quantity, value)


class _GroupProxy:
    """Proxy for a TOML table (dict) that allows attribute-style access."""

    __slots__ = ("_data", "_root")

    def __init__(self, data: dict, root: PlasmaToml) -> None:
        object.__setattr__(self, "_data", data)
        object.__setattr__(self, "_root", root)

    def __getattr__(self, name: str) -> Any:
        try:
            val = self._data[name]
        except KeyError:
            raise AttributeError(f"No key {name!r} in this TOML group") from None
        if isinstance(val, dict):
            return _GroupProxy(val, self._root)
        if isinstance(val, list) and val and isinstance(val[0], dict):
            return _ListProxy(val, self._root)
        return val

    def __setattr__(self, name: str, value: Any) -> None:
        self._data[name] = value

    @property
    def si(self) -> _SIProxy:
        """Return an SI-unit proxy for this group.

        ``proxy.si.path = 1.5e5``  sets *path* from a physical value [m/s].
        ``proxy.si.path``          returns the physical value [m/s].
        """
        return _SIProxy(self._data, self._root.unit)

    def __repr__(self) -> str:
        return f"_GroupProxy({self._data!r})"


class _ListProxy:
    """Proxy for a TOML array of tables (list[dict])."""

    __slots__ = ("_data", "_root")

    def __init__(self, data: list, root: PlasmaToml) -> None:
        object.__setattr__(self, "_data", data)
        object.__setattr__(self, "_root", root)

    def __getitem__(self, index: int) -> _GroupProxy:
        return _GroupProxy(self._data[index], self._root)

    def __len__(self) -> int:
        return len(self._data)

    def __iter__(self):
        for item in self._data:
            yield _GroupProxy(item, self._root)

    def append(self, item: dict) -> PlasmaToml:
        """Append a new entry and return the root :class:`PlasmaToml` for chaining."""
        self._data.append(item)
        return self._root

    def __repr__(self) -> str:
        return f"_ListProxy(len={len(self._data)})"


# ---------------------------------------------------------------------------
# Dotted-key helper
# ---------------------------------------------------------------------------
def _resolve_dotted(data: dict, dotted_key: str) -> tuple[dict, str]:
    """Walk *data* along a dotted key path and return ``(parent, leaf_key)``.

    Numeric segments index into lists (0-based).
    """
    parts = dotted_key.split(".")
    obj = data
    for part in parts[:-1]:
        if isinstance(obj, list):
            obj = obj[int(part)]
        elif isinstance(obj, dict):
            obj = obj[part]
        else:
            raise KeyError(dotted_key)
    return obj, parts[-1]


# ---------------------------------------------------------------------------
# PlasmaToml
# ---------------------------------------------------------------------------
class PlasmaToml:
    """Ergonomic interface for reading, modifying, and writing plasma.toml.

    Supports both attribute-style access (via proxies) and dict-style access.
    """

    def __init__(
        self,
        path: str | Path | None = None,
        data: dict | None = None,
    ) -> None:
        self._path: Path | None = Path(path) if path else None
        self._schema: str | None = None

        if path is not None:
            p = Path(path)
            self._data = _read_toml(p)
            self._schema = _read_schema_directive(p)
        elif data is not None:
            self._data = data
        else:
            self._data = {}

    @classmethod
    def load(cls, path: str | Path) -> PlasmaToml:
        """Load from a plasma.toml file."""
        return cls(path=path)

    @classmethod
    def from_dict(cls, data: dict) -> PlasmaToml:
        """Create from a plain dict."""
        return cls(data=data)

    # -- Data access --------------------------------------------------------

    @property
    def data(self) -> dict:
        """The underlying TOML dict (mutable)."""
        return self._data

    def __getitem__(self, key: str) -> Any:
        return self._data[key]

    def __contains__(self, key: str) -> bool:
        return key in self._data

    def __getattr__(self, name: str) -> Any:
        # Avoid infinite recursion for internal attrs
        if name.startswith("_"):
            raise AttributeError(name)
        try:
            val = self._data[name]
        except KeyError:
            raise AttributeError(f"No group {name!r} in this PlasmaToml") from None
        if isinstance(val, dict):
            return _GroupProxy(val, self)
        if isinstance(val, list) and val and isinstance(val[0], dict):
            return _ListProxy(val, self)
        return val

    def get(self, dotted_key: str, default: Any = None) -> Any:
        """Get a value using dotted key notation.

        ``toml.get("tmgrid.dt")`` returns the dt value.
        ``toml.get("species.0.wp")`` returns the first species' wp.
        """
        try:
            parent, leaf = _resolve_dotted(self._data, dotted_key)
            if isinstance(parent, list):
                return parent[int(leaf)]
            return parent[leaf]
        except (KeyError, IndexError, ValueError):
            return default

    def set(self, dotted_key: str, value: Any) -> PlasmaToml:
        """Set a value using dotted key notation."""
        parent, leaf = _resolve_dotted(self._data, dotted_key)
        if isinstance(parent, list):
            parent[int(leaf)] = value
        else:
            parent[leaf] = value
        return self

    # -- Group resolution ----------------------------------------------------

    @property
    def resolved_species(self) -> list[dict]:
        """Return ``[[species]]`` entries with ``species_groups`` defaults merged in."""
        return _resolve_aot_groups(
            self._data.get("species", []),
            self._data.get("species_groups", {}),
        )

    @property
    def resolved_meta_physical_species(self) -> list[dict]:
        """Return ``[[meta.physical.species]]`` with group defaults merged in."""
        phys = self._data.get("meta", {}).get("physical", {})
        return _resolve_aot_groups(
            phys.get("species", []),
            phys.get("species_groups", {}),
        )

    @property
    def resolved_meta_physical_conductors(self) -> list[dict]:
        """Return ``[[meta.physical.conductors]]`` with group defaults merged in."""
        phys = self._data.get("meta", {}).get("physical", {})
        return _resolve_aot_groups(
            phys.get("conductors", []),
            phys.get("conductor_groups", {}),
        )

    # -- Mutation -----------------------------------------------------------

    def apply(self, overrides: dict) -> PlasmaToml:
        """Deep-merge *overrides* into the current data.

        For dict values: recursively merge.
        For other values (scalars, lists): overwrite.

        Returns *self* for chaining.
        """
        _deep_merge(self._data, overrides)
        return self

    # -- Physical parameter application ---------------------------------------

    def apply_physical(self, *, dry_run: bool = False) -> str | None:
        """Convert ``[meta.physical]`` to simulation units and update parameters.

        Reads ``meta.physical``, computes simulation-unit values via
        :class:`UnitSystem`, and updates ``[[species]]``, ``[plasma]``,
        and ``[ptcond.conductor_groups]`` accordingly.

        Parameters
        ----------
        dry_run : bool
            If ``True``, return a human-readable summary string without
            modifying any data.

        Returns
        -------
        str or None
            Summary string when *dry_run* is ``True``, otherwise ``None``.
        """
        phys = self._data.get("meta", {}).get("physical")
        if phys is None:
            raise ValueError("No [meta.physical] section found in this TOML.")

        unit = self.unit
        density = phys.get("density_m3")  # global default (optional)

        global_ppc = phys.get("particles_per_cell")

        # Grid size for npin calculation
        tmgrid = self._data.get("tmgrid", {})
        nx = tmgrid.get("nx")
        ny = tmgrid.get("ny")
        nz = tmgrid.get("nz")
        grid_cells = nx * ny * nz if (nx and ny and nz) else None

        lines: list[str] = []
        if dry_run:
            lines.append("[meta.physical] -> simulation parameters:")

        # --- Species ---
        phys_species = _resolve_aot_groups(
            phys.get("species", []),
            phys.get("species_groups", {}),
        )
        sim_species = self._data.setdefault("species", [])

        for i, ps in enumerate(phys_species):
            converted = _convert_physical_species(
                ps,
                density,
                unit,
                grid_cells,
                global_ppc,
            )
            if dry_run:
                label = ps.get("label", f"species_{i}")
                lines.append(f"  species[{i}] ({label}):")
                for k, v in converted.items():
                    lines.append(f"    {k:<24} = {v}")
            else:
                # Ensure species[i] exists
                while len(sim_species) <= i:
                    sim_species.append({})
                sim_species[i].update(converted)

        # --- Conductors ---
        phys_conductors = self.resolved_meta_physical_conductors
        if phys_conductors:
            ptcond = self._data.setdefault("ptcond", {})
            cg = ptcond.setdefault("conductor_groups", {})
            if dry_run and phys_conductors:
                lines.append("  conductors:")
            for pc in phys_conductors:
                group_name = pc.get("group", "")
                group_data = cg.setdefault(group_name, {})
                converted_cond: dict[str, Any] = {}
                if "potential_V" in pc:
                    converted_cond["pfixed"] = unit.phi.trans(pc["potential_V"])
                if "bias_potential_V" in pc:
                    converted_cond["biasp"] = unit.phi.trans(pc["bias_potential_V"])
                if dry_run:
                    for k, v in converted_cond.items():
                        lines.append(f"    {group_name}.{k:<16} = {v}")
                else:
                    group_data.update(converted_cond)

        # --- Global plasma parameters ---
        plasma = self._data.setdefault("plasma", {})
        global_converted: dict[str, Any] = {}

        mag = phys.get("magnetic_field_T")
        if mag is not None:
            sign = 1 if mag >= 0 else -1
            wc = unit.f.trans(UnitSystem.cyclotron_frequency(abs(mag)))
            global_converted["wc"] = sign * wc

        if "magnetic_field_phiz_deg" in phys:
            global_converted["phiz"] = phys["magnetic_field_phiz_deg"]
        if "magnetic_field_phixy_deg" in phys:
            global_converted["phixy"] = phys["magnetic_field_phixy_deg"]

        for phys_key, sim_key in (
            ("e0x_V_m", "e0x"),
            ("e0y_V_m", "e0y"),
            ("e0z_V_m", "e0z"),
        ):
            if phys_key in phys:
                global_converted[sim_key] = unit.e.trans(phys[phys_key])

        if global_converted:
            if dry_run:
                lines.append("  plasma:")
                for k, v in global_converted.items():
                    lines.append(f"    {k:<24} = {v}")
            else:
                plasma.update(global_converted)

        if dry_run:
            return "\n".join(lines)
        return None

    # -- Physical parameter generation (reverse of apply_physical) ----------

    def generate_physical(self, *, update: bool = False) -> None:
        """Generate ``[meta.physical]`` from simulation parameters.

        Reverse of :meth:`apply_physical`: reads ``[[species]]``,
        ``[plasma]``, and ``[ptcond.conductor_groups]`` and populates
        ``[meta.physical]`` with the corresponding SI-unit values.

        Parameters
        ----------
        update : bool
            If ``True`` and ``[meta.physical]`` already exists, update it
            while preserving existing ``label`` fields and any extra keys
            not derivable from simulation parameters.  If ``False``
            (default), overwrite ``[meta.physical]`` entirely.
        """
        unit = self.unit
        meta = self._data.setdefault("meta", {})
        # Auto-detect: if [meta.physical] already exists, behave as update
        if not update and meta.get("physical"):
            update = True
        existing_phys = meta.get("physical", {}) if update else {}

        # Grid size for particles_per_cell calculation
        tmgrid = self._data.get("tmgrid", {})
        nx = tmgrid.get("nx")
        ny = tmgrid.get("ny")
        nz = tmgrid.get("nz")
        grid_cells = nx * ny * nz if (nx and ny and nz) else None

        phys: dict = {}

        # --- Species ---
        sim_species = self.resolved_species
        existing_species = existing_phys.get("species", [])
        phys_species: list[dict] = []

        # Collect densities and ppc values to detect common global values
        densities: list[float] = []
        ppcs: list[int] = []

        for i, sp in enumerate(sim_species):
            converted = _reverse_physical_species(sp, unit, grid_cells)
            if not converted:
                phys_species.append({})
                continue

            # Preserve label from existing meta.physical
            if i < len(existing_species):
                old = existing_species[i]
                if "label" in old:
                    converted["label"] = old["label"]
                if update:
                    # Preserve extra user keys not generated by reverse
                    for k, v in old.items():
                        if k not in converted:
                            converted[k] = v

            if "density_m3" in converted:
                densities.append(converted["density_m3"])
            if "particles_per_cell" in converted:
                ppcs.append(converted["particles_per_cell"])

            phys_species.append(converted)

        # Factor out common density_m3 and particles_per_cell as globals
        if densities and all(
            abs(d - densities[0]) / max(abs(densities[0]), 1e-30) < 0.01
            for d in densities
        ):
            phys["density_m3"] = densities[0]
            for ps in phys_species:
                ps.pop("density_m3", None)

        if ppcs and all(p == ppcs[0] for p in ppcs):
            phys["particles_per_cell"] = ppcs[0]
            for ps in phys_species:
                ps.pop("particles_per_cell", None)

        # Ensure label ordering: label first in each species dict
        ordered_species: list[dict] = []
        for ps in phys_species:
            if "label" in ps:
                ordered: dict = {"label": ps.pop("label")}
                ordered.update(ps)
                ordered_species.append(ordered)
            else:
                ordered_species.append(ps)

        if ordered_species:
            phys["species"] = ordered_species

        # --- Global plasma parameters ---
        plasma = self._data.get("plasma", {})

        wc_sim = plasma.get("wc", 0)
        if isinstance(wc_sim, list):
            wc_sim = wc_sim[0] if wc_sim else 0
        if wc_sim != 0:
            sign = 1 if wc_sim >= 0 else -1
            wc_phys = abs(wc_sim) * unit.f.scale
            B_tesla = wc_phys * MASSELE / ELEMCHG
            phys["magnetic_field_T"] = sign * B_tesla
        else:
            phys["magnetic_field_T"] = 0.0

        phiz = plasma.get("phiz")
        if phiz is not None and phiz != 0:
            phys["magnetic_field_phiz_deg"] = phiz
        phixy = plasma.get("phixy")
        if phixy is not None and phixy != 0:
            phys["magnetic_field_phixy_deg"] = phixy

        for sim_key, phys_key in (
            ("e0x", "e0x_V_m"),
            ("e0y", "e0y_V_m"),
            ("e0z", "e0z_V_m"),
        ):
            val = plasma.get(sim_key)
            if val is not None and val != 0:
                phys[phys_key] = unit.e.reverse(val)

        # --- Conductors ---
        ptcond = self._data.get("ptcond", {})
        cg = ptcond.get("conductor_groups", {})
        if cg:
            phys_conductors: list[dict] = []
            for group_name, group_data in cg.items():
                cond: dict = {"group": group_name}
                pfixed = group_data.get("pfixed")
                if pfixed is not None and pfixed != 0:
                    cond["potential_V"] = unit.phi.reverse(pfixed)
                biasp = group_data.get("biasp")
                if biasp is not None and biasp != 0:
                    cond["bias_potential_V"] = unit.phi.reverse(biasp)
                if len(cond) > 1:  # has more than just "group"
                    phys_conductors.append(cond)
            if phys_conductors:
                phys["conductors"] = phys_conductors

        # Preserve extra keys from existing physical section on update
        if update:
            for k, v in existing_phys.items():
                if k not in phys:
                    phys[k] = v

        meta["physical"] = phys

    # -- Unit system --------------------------------------------------------

    @property
    def unit(self) -> UnitSystem:
        """Get a :class:`UnitSystem` from this TOML's metadata."""
        return UnitSystem.from_toml(self._data)

    # -- Physical-value interface -------------------------------------------

    def set_physical(
        self,
        dotted_key: str,
        physical_value: float,
        quantity: str | None = None,
    ) -> PlasmaToml:
        """Set a parameter using physical SI units.

        The unit type is auto-detected from :data:`PARAM_UNIT_MAP`,
        or can be specified explicitly via *quantity*.
        """
        parent, leaf = _resolve_dotted(self._data, dotted_key)
        if quantity is None:
            quantity = PARAM_UNIT_MAP.get(leaf)
        if quantity is None:
            raise ValueError(
                f"Unknown unit type for {leaf!r}. Specify quantity= explicitly."
            )
        unit = self.unit
        if quantity == "v_squared":
            sim_value = physical_value / (unit.v.scale**2)
        else:
            sim_value = unit.trans(quantity, physical_value)
        if isinstance(parent, list):
            parent[int(leaf)] = sim_value
        else:
            parent[leaf] = sim_value
        return self

    def get_physical(
        self,
        dotted_key: str,
        quantity: str | None = None,
    ) -> float:
        """Get a parameter value in physical SI units."""
        parent, leaf = _resolve_dotted(self._data, dotted_key)
        if isinstance(parent, list):
            sim_value = parent[int(leaf)]
        else:
            sim_value = parent[leaf]
        if quantity is None:
            quantity = PARAM_UNIT_MAP.get(leaf)
        if quantity is None:
            raise ValueError(
                f"Unknown unit type for {leaf!r}. Specify quantity= explicitly."
            )
        unit = self.unit
        if quantity == "v_squared":
            return sim_value * unit.v.scale**2
        return unit.reverse(quantity, sim_value)

    # -- Inspection ---------------------------------------------------------

    def inspect(self, keys: list[str] | None = None) -> str:
        """Show simulation values and their physical equivalents.

        If *keys* is ``None``, inspects all parameters with known unit types
        and appends a plasma summary section.
        """
        unit = self.unit
        lines: list[str] = []

        def _inspect_dict(d: dict, prefix: str) -> None:
            for k, v in d.items():
                if keys is not None and k not in keys:
                    continue
                if isinstance(v, (int, float)) and k in PARAM_UNIT_MAP:
                    q = PARAM_UNIT_MAP[k]
                    conv = unit.converter(q) if q != "v_squared" else None
                    if q == "v_squared":
                        phys = v * unit.v.scale**2
                        unit_label = "(m/s)^2"
                    else:
                        phys = conv.reverse(v)  # type: ignore[union-attr]
                        unit_label = conv.unit  # type: ignore[union-attr]
                    lines.append(f"  {k:<24} = {v:<16} -> {phys:.6e} [{unit_label}]")

        # species (resolved with group defaults)
        species_list = self.resolved_species
        for idx, sp in enumerate(species_list):
            lines.append(f"species[{idx}]:")
            _inspect_dict(sp, f"species.{idx}")

        # other groups
        for group, gdata in self._data.items():
            if group in ("meta", "species", "real", "realcv"):
                continue
            if isinstance(gdata, dict):
                _old_len = len(lines)
                _inspect_dict(gdata, group)
                if len(lines) > _old_len:
                    lines.insert(_old_len, f"{group}:")

        # Plasma summary (only when showing all parameters)
        if keys is None:
            summary = self._plasma_summary()
            if summary:
                lines.append("")
                lines.append(summary)

        return "\n".join(lines)

    def _plasma_summary(self) -> str:
        """Compute derived plasma quantities per species."""
        unit = self.unit

        # --- Gather per-species sim values ---
        species_data: list[dict] = []
        species_list = self.resolved_species
        if species_list:
            for sp in species_list:
                species_data.append(
                    {
                        "qm": sp.get("qm", 0),
                        "wp": sp.get("wp", 0),
                        "path": sp.get("path", 0),
                        "peth": sp.get("peth", 0),
                    }
                )
        else:
            # v1 fallback: per-species arrays in plasma / intp groups
            plasma_g = self._data.get("plasma", {})
            intp_g = self._data.get("intp", {})

            def _as_list(v: object) -> list:
                return v if isinstance(v, list) else ([v] if v else [])

            wp_a = _as_list(plasma_g.get("wp", []))
            qm_a = _as_list(intp_g.get("qm", []))
            path_a = _as_list(intp_g.get("path", []))
            peth_a = _as_list(intp_g.get("peth", []))
            nspec = max(len(wp_a), len(qm_a), len(path_a), len(peth_a), 0)
            for i in range(nspec):
                species_data.append(
                    {
                        "qm": qm_a[i] if i < len(qm_a) else 0,
                        "wp": wp_a[i] if i < len(wp_a) else 0,
                        "path": path_a[i] if i < len(path_a) else 0,
                        "peth": peth_a[i] if i < len(peth_a) else 0,
                    }
                )

        if not species_data:
            return ""

        # Global wc (electron cyclotron frequency, sim units)
        plasma_g = self._data.get("plasma", {})
        wc_sim = plasma_g.get("wc", 0)
        if isinstance(wc_sim, list):
            wc_sim = wc_sim[0] if wc_sim else 0
        wc_phys = abs(wc_sim) * unit.f.scale  # [rad/s]
        B_tesla = wc_phys * MASSELE / ELEMCHG if wc_phys > 0 else 0.0

        lines: list[str] = ["Plasma Summary", "=" * 60]

        if B_tesla > 0:
            lines.append(f"  B                       = {B_tesla:.6e} [T]")
            lines.append(f"  Electron wce            = {wc_phys:.6e} [rad/s]")
            lines.append("")

        for idx, sp in enumerate(species_data):
            qm_sim = sp["qm"]
            wp_sim = sp["wp"]
            path_sim = sp["path"]
            peth_sim = sp["peth"]
            abs_qm = abs(qm_sim)

            lines.append(f"  species[{idx}]  (qm = {qm_sim})")
            lines.append(f"  {'-' * 56}")

            if abs_qm == 0 or wp_sim == 0:
                lines.append("    (wp = 0 or qm = 0: skipped)")
                lines.append("")
                continue

            # Mass (assuming |q| = e): m = m_e / |qm|
            mass = MASSELE / abs_qm
            mass_ratio = 1.0 / abs_qm  # m / m_e

            # Plasma frequency [rad/s]
            wp_phys = wp_sim * unit.f.scale

            # Density: n = wp^2 * eps0 * m / e^2
            density = wp_phys**2 * EPS0 * mass / ELEMCHG**2

            # Thermal speeds [m/s]
            vth_par = path_sim * unit.v.scale
            vth_perp = peth_sim * unit.v.scale

            # Temperature: T = m * vth^2 / e [eV], m * vth^2 / kB [K]
            T_par_eV = mass * vth_par**2 / ELEMCHG
            T_par_K = mass * vth_par**2 / KBOLTZ
            T_perp_eV = mass * vth_perp**2 / ELEMCHG
            T_perp_K = mass * vth_perp**2 / KBOLTZ

            isotropic = abs(T_par_eV - T_perp_eV) / max(T_par_eV, 1e-30) < 0.01

            # Debye length (parallel temperature)
            debye = UnitSystem.debye_length(T_par_eV, density)
            debye_dx = debye / unit.dx

            lines.append(
                f"    Mass                  = {mass:.6e} [kg]  ({mass_ratio:.1f} m_e)"
            )
            lines.append(f"    Density               = {density:.6e} [m^-3]")
            if isotropic:
                lines.append(
                    f"    Temperature           = {T_par_eV:.6e} [eV]  ({T_par_K:.6e} [K])"
                )
                lines.append(f"    v_th                  = {vth_par:.6e} [m/s]")
            else:
                lines.append(
                    f"    T_par                 = {T_par_eV:.6e} [eV]  ({T_par_K:.6e} [K])"
                )
                lines.append(
                    f"    T_perp                = {T_perp_eV:.6e} [eV]  ({T_perp_K:.6e} [K])"
                )
                lines.append(f"    v_th (par)            = {vth_par:.6e} [m/s]")
                lines.append(f"    v_th (perp)           = {vth_perp:.6e} [m/s]")
            lines.append(f"    omega_p               = {wp_phys:.6e} [rad/s]")
            lines.append(
                f"    Debye length          = {debye:.6e} [m]  ({debye_dx:.2f} dx)"
            )

            if B_tesla > 0:
                wc_s = abs_qm * wc_phys  # species cyclotron frequency
                r_L = vth_perp / wc_s if wc_s > 0 else float("inf")
                r_L_dx = r_L / unit.dx
                lines.append(f"    omega_c               = {wc_s:.6e} [rad/s]")
                lines.append(
                    f"    Larmor radius         = {r_L:.6e} [m]  ({r_L_dx:.2f} dx)"
                )

            lines.append("")

        return "\n".join(lines)

    # -- Serialisation ------------------------------------------------------

    def to_toml_string(self) -> str:
        """Serialize to a format_version 2 TOML string."""
        schema = self._schema or SCHEMA_URL
        return serialize_v2(self._data, schema=schema)

    def write(self, path: str | Path | None = None) -> None:
        """Write to a file.  If *path* is ``None``, writes to the original file."""
        p = Path(path) if path else self._path
        if p is None:
            raise ValueError("No path specified and no original path available.")
        p.write_text(self.to_toml_string(), encoding="utf-8")

    def update(self) -> None:
        """Write back to the original file (alias for :meth:`write`)."""
        self.write()

    # -- Copy ---------------------------------------------------------------

    def copy(self) -> PlasmaToml:
        """Return a deep copy."""
        new = PlasmaToml(data=copy.deepcopy(self._data))
        new._path = self._path
        new._schema = self._schema
        return new

    def __repr__(self) -> str:
        src = str(self._path) if self._path else "dict"
        return f"PlasmaToml({src})"
