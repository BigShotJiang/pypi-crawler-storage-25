"""TOML format_version 2 serialization for plasma.toml."""

from __future__ import annotations

from collections import OrderedDict

from ._fmt import emit_kv, fmt

# Canonical output order for top-level groups.
GROUP_ORDER = [
    "meta",
    "memo",
    "real",
    "realcv",
    "species_groups",
    "species",
    "esorem",
    "jobcon",
    "digcon",
    "plasma",
    "tmgrid",
    "system",
    "intp",
    "others",
    "inp",
    "ptcond",
    "wave",
    "scrnt",
    "emissn",
    "dipole",
    "testch",
    "jsrc",
    "mpi",
    "verbose",
    "gradema",
]

# AOT sub-keys inside their parent groups.
AOT_KEYS: dict[str, list[str]] = {
    "ptcond": ["objects", "boundaries"],
    "emissn": ["planes"],
    "dipole": ["sources"],
    "testch": ["charges"],
    "jsrc": ["sources"],
}


def serialize_v2(data: dict, schema: str | None = None) -> str:
    """Serialize a plasma.toml dict to format_version 2 TOML string."""
    parts: list[str] = []

    if schema:
        parts.append(f"#:schema {schema}")
        parts.append("")

    emitted: set[str] = set()

    for group in GROUP_ORDER:
        if group not in data:
            continue
        emitted.add(group)

        if group == "meta":
            _emit_meta(parts, data["meta"])
        elif group == "species_groups":
            _emit_named_groups(parts, "species_groups", data["species_groups"])
        elif group == "species":
            _emit_species(parts, data["species"])
        elif group in AOT_KEYS:
            _emit_group_with_aot(parts, group, data[group])
        else:
            emit_kv(parts, data[group], f"[{group}]")

    # Any remaining groups not in the canonical order
    for group in data:
        if group not in emitted:
            val = data[group]
            if isinstance(val, dict):
                emit_kv(parts, val, f"[{group}]")

    return "\n".join(parts)


def _emit_meta(parts: list[str], meta: dict) -> None:
    """Emit [meta], [meta.unit_conversion], and [meta.physical]."""
    _META_SUB = {"unit_conversion", "physical"}
    parts.append("[meta]")
    for k, v in meta.items():
        if k in _META_SUB:
            continue
        parts.append(f"{k} = {fmt(v)}")
    parts.append("")

    uc = meta.get("unit_conversion")
    if uc:
        parts.append("[meta.unit_conversion]")
        for k, v in uc.items():
            parts.append(f"{k} = {fmt(v)}")
        parts.append("")

    phys = meta.get("physical")
    if phys:
        _PHYS_SUB = {"species", "conductors", "species_groups", "conductor_groups"}
        parts.append("[meta.physical]")
        for k, v in phys.items():
            if k in _PHYS_SUB:
                continue
            parts.append(f"{k} = {fmt(v)}")
        parts.append("")
        for gk in ("species_groups", "conductor_groups"):
            gdata = phys.get(gk, {})
            if isinstance(gdata, dict) and gdata:
                _emit_named_groups(parts, f"meta.physical.{gk}", gdata)
        for sp in phys.get("species", []):
            parts.append("[[meta.physical.species]]")
            for k, v in sp.items():
                parts.append(f"{k} = {fmt(v)}")
            parts.append("")
        for cond in phys.get("conductors", []):
            parts.append("[[meta.physical.conductors]]")
            for k, v in cond.items():
                parts.append(f"{k} = {fmt(v)}")
            parts.append("")


# Groups sub-keys inside their parent groups (parallel to AOT_KEYS).
GROUPS_KEYS: dict[str, list[str]] = {
    "ptcond": ["object_groups", "boundary_groups"],
    "emissn": ["plane_groups"],
    "dipole": ["source_groups"],
    "testch": ["charge_groups"],
    "jsrc": ["source_groups"],
}


# Canonical key order for [[species]] — groups related parameters together.
_SPECIES_KEY_ORDER = [
    # Group reference
    "group_id",
    # Core physics
    "wp",
    "qm",
    # Thermal velocity
    "path",
    "peth",
    # Drift
    "vdri",
    "vdthz",
    "vdthxy",
    "vdx",
    "vdy",
    "vdz",
    # Distribution
    "spa",
    "spe",
    "speth",
    "f",
    # Particles
    "npin",
    "np",
    "dnsf",
    # Boundary
    "npbnd",
    # Injection
    "inpf",
    "inpb",
    "injct",
    "npr",
    # Emission
    "nflag_emit",
    "curf",
    "curb",
    "nepl",
    "emission_leave_anti_particle",
    "emission_time_mode",
    "emission_start_step",
    "emission_end_step",
    "emission_time_sigma",
    "ray_zenith_angle_deg",
    "ray_azimuth_angle_deg",
    # Flux / charge
    "flpf",
    "flpb",
    "qp",
    "qpr",
    "abvdem",
    "dnsb",
    # Diagnostics
    "ipahdf",
    "ipadig",
    "ipaxyz",
    "ildig",
    "imdig",
    "isort",
    "irhsp",
    # Velocity range
    "vpa",
    "vpb",
    "vpe",
    # Other
    "mfpath",
    "pemax",
    "deltaemax",
    "denmod",
    "denk",
    "omegalw",
    "lcgamma",
    "lcbeta",
    "nphi",
    "ndst",
    "ioptd",
]
_SPECIES_KEY_SET = set(_SPECIES_KEY_ORDER)


def _sorted_species_keys(sp: dict) -> list[str]:
    """Return species keys in canonical order, unknown keys appended at end."""
    ordered = [k for k in _SPECIES_KEY_ORDER if k in sp]
    ordered.extend(k for k in sp if k not in _SPECIES_KEY_SET)
    return ordered


def _emit_species(parts: list[str], species_list: list[dict]) -> None:
    """Emit [[species]] entries."""
    for sp in species_list:
        parts.append("[[species]]")
        for k in _sorted_species_keys(sp):
            parts.append(f"{k} = {fmt(sp[k])}")
        parts.append("")


def _emit_named_groups(parts: list[str], prefix: str, groups: dict) -> None:
    """Emit named group tables like ``[species_groups.background]``."""
    for name, params in groups.items():
        if isinstance(params, dict):
            emit_kv(parts, params, f"[{prefix}.{name}]")


def _emit_group_with_aot(parts: list[str], group: str, data: dict) -> None:
    """Emit a group that may contain array-of-tables sub-keys."""
    aot_keys = AOT_KEYS.get(group, [])
    groups_keys = GROUPS_KEYS.get(group, [])
    skip_keys = set(aot_keys) | set(groups_keys)
    # Emit non-AOT, non-groups keys first
    simple = OrderedDict()
    for k, v in data.items():
        if k in skip_keys:
            continue
        if isinstance(v, dict):
            # Nested table (e.g. ptcond.conductor_groups.group_1)
            for subk, subv in v.items():
                if isinstance(subv, dict):
                    emit_kv(parts, subv, f"[{group}.{k}.{subk}]")
                else:
                    simple[f"{k}.{subk}"] = subv
        else:
            simple[k] = v
    if simple:
        emit_kv(parts, simple, f"[{group}]")
    # Emit *_groups tables (e.g. ptcond.boundary_groups.reflective)
    for gk in groups_keys:
        gdata = data.get(gk, {})
        if isinstance(gdata, dict) and gdata:
            _emit_named_groups(parts, f"{group}.{gk}", gdata)
    # Emit AOTs
    for aot_key in aot_keys:
        entries = data.get(aot_key, [])
        if isinstance(entries, list):
            for entry in entries:
                emit_kv(parts, entry, f"[[{group}.{aot_key}]]")
