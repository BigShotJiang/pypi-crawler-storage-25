# mpiemses3d_tools/copy_emses.py
from __future__ import annotations
import argparse
import os
import shutil
import sys
from pathlib import Path

BIN_CANDIDATES = ["mpiemses3D", "mpiemses3D.exe"]


def find_binary() -> Path | None:
    for name in BIN_CANDIDATES:
        p = shutil.which(name)
        if p:
            return Path(p)

    return None


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(
        prog="copy-emses", description="Copy mpiemses3D binary to a target directory."
    )
    parser.add_argument("dest", help="Destination directory")
    parser.add_argument(
        "--name",
        default=None,
        help="Rename the binary on copy (default: keep original name)",
    )
    parser.add_argument(
        "--overwrite", action="store_true", help="Overwrite if the file already exists"
    )
    parser.add_argument(
        "--dry-run", action="store_true", help="Show what would be done without copying"
    )
    args = parser.parse_args(argv)

    binpath = find_binary()
    if not binpath or not binpath.exists():
        print("ERROR: mpiemses3D binary not found in PATH or package.", file=sys.stderr)
        return 1

    dest_dir = Path(args.dest).expanduser().resolve()
    dest_dir.mkdir(parents=True, exist_ok=True)

    out_name = args.name or binpath.name
    dest = dest_dir / out_name

    if dest.exists() and not args.overwrite:
        print(f"ERROR: {dest} already exists (use --overwrite).", file=sys.stderr)
        return 2

    print(f"Source : {binpath}")
    print(f"Target : {dest}")
    if args.dry_run:
        return 0

    shutil.copy2(binpath, dest)
    try:
        os.chmod(dest, os.stat(dest).st_mode | 0o111)
    except Exception:
        pass

    print("Done.")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
