"""Upgrade plasma.toml from format_version 1 to 2.

Reads a v1 plasma.toml (flat arrays), extracts per-species parameters
into [[species]] entries, and writes format_version = 2.
"""

from __future__ import annotations

import argparse
import sys
from pathlib import Path

from ..inp2toml import (
    SCHEMA_URL,
)
from collections import OrderedDict


def _read_toml_as_groups(
    text: str,
) -> tuple[dict | None, list[tuple[str, OrderedDict]]]:
    """Minimal TOML parser that reads plasma.toml into the same
    (meta, groups) structure as parse_inp, leveraging tomllib if available."""
    try:
        import tomllib
    except ImportError:
        try:
            import tomli as tomllib  # type: ignore[no-redef]
        except ImportError:
            print(
                "ERROR: Python 3.11+ or 'tomli' package required for toml-upgrade.",
                file=sys.stderr,
            )
            sys.exit(1)

    data = tomllib.loads(text)

    meta = None
    meta_raw = data.pop("meta", None)
    if isinstance(meta_raw, dict):
        uc = meta_raw.get("unit_conversion", {})
        if uc:
            meta = dict(uc)

    # Schema key is not a group
    data.pop("$schema", None)

    groups: list[tuple[str, OrderedDict]] = []
    for gname, gval in data.items():
        if isinstance(gval, dict):
            groups.append((gname, OrderedDict(gval)))

    return meta, groups


def main(argv: list[str] | None = None) -> int:
    ap = argparse.ArgumentParser(
        prog="toml-upgrade",
        description="Upgrade plasma.toml from format_version 1 to 2 (new-style [[species]] etc.).",
    )
    ap.add_argument("input", help="Path to plasma.toml (format_version 1)")
    ap.add_argument(
        "-o",
        "--output",
        default=None,
        help="Output path (default: overwrite input). Use '-' for stdout.",
    )
    ap.add_argument(
        "--schema",
        default=SCHEMA_URL,
        help=f"$schema URI to embed (default: {SCHEMA_URL}).",
    )
    args = ap.parse_args(argv)

    inp_path = Path(args.input)
    if not inp_path.exists():
        print(f"ERROR: {inp_path} not found.", file=sys.stderr)
        return 1

    text = inp_path.read_text(encoding="utf-8", errors="replace")
    meta, groups = _read_toml_as_groups(text)

    # Import v2 emitter
    from ..inp2toml import _to_toml_v2

    toml_text = _to_toml_v2(meta, groups, schema=args.schema or None)

    if args.output == "-":
        sys.stdout.write(toml_text)
    else:
        out_path = Path(args.output) if args.output else inp_path
        out_path.write_text(toml_text, encoding="utf-8")
        print(f"Upgraded to format_version 2: {out_path}", file=sys.stderr)

    return 0


if __name__ == "__main__":
    raise SystemExit(main())
