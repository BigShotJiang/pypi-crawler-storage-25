"""Convert plasma.inp (Fortran namelist) to plasma.toml format.

Handles:
- !!key header → [meta.unit_conversion]
- Fortran namelist groups → TOML tables
- Array slice syntax: var(1:3) = a, b, c
- Single-element indexing: var(2) = x
- 2D indexing: var(1,4) = x → matrix
- Fortran literals: .true./.false., 1.0d0, "string"
- Inline comments (!)
"""

from __future__ import annotations

import argparse
import sys
from collections import OrderedDict
from pathlib import Path

from ._fmt import fmt as _fmt, emit_kv as _emit_kv
from ._inp_parser import parse_inp

try:
    import tomllib  # Python 3.11+
except ImportError:
    try:
        import tomli as tomllib  # type: ignore[no-redef]
    except ImportError:
        tomllib = None  # type: ignore[assignment]


def _parse_toml_text(text: str) -> dict:
    """Parse a TOML string into a dict."""
    if tomllib is None:
        raise ImportError(
            "Python 3.11+ or the 'tomli' package is required for --generate-physical."
        )
    return tomllib.loads(text)


SCHEMA_URL = "https://raw.githubusercontent.com/CS12-Laboratory/mpiemses3d-schema/refs/heads/main/plasma.schema.json"


# ── TOML emitter ──────────────────────────────────────────────────


def to_toml(
    meta: dict | None,
    groups: list[tuple[str, OrderedDict]],
    schema: str | None = None,
    format_version: int = 1,
) -> str:
    """Generate a TOML string from parsed data."""
    if format_version >= 2:
        return _to_toml_v2(meta, groups, schema)
    return _to_toml_v1(meta, groups, schema)


def _to_toml_v1(
    meta: dict | None,
    groups: list[tuple[str, OrderedDict]],
    schema: str | None = None,
) -> str:
    parts: list[str] = []

    if schema:
        parts.append(f"#:schema {schema}")
        parts.append("")

    if meta:
        parts.append("[meta]")
        parts.append("format_version = 1")
        parts.append("")
        parts.append("[meta.unit_conversion]")
        for k, v in meta.items():
            parts.append(f"{k} = {_fmt(v)}")
        parts.append("")

    for gname, params in groups:
        parts.append(f"[{gname}]")
        for key, value in params.items():
            parts.append(f"{key} = {_fmt(value)}")
        parts.append("")

    return "\n".join(parts)


# ── Format version 2 ─────────────────────────────────────────────

# Species parameter → owning group mapping
_SPECIES_PARAMS: dict[str, str] = {}
for _g, _keys in [
    ("plasma", ["wp", "denmod", "denk", "omegalw"]),
    (
        "intp",
        [
            "np",
            "npin",
            "qm",
            "path",
            "peth",
            "spa",
            "spe",
            "speth",
            "f",
            "vdx",
            "vdy",
            "vdz",
            "vdri",
            "vdthz",
            "vdthxy",
            "vpa",
            "vpb",
            "vpe",
            "nphi",
            "ndst",
            "ioptd",
            "lcgamma",
            "lcbeta",
            "dnsf",
        ],
    ),
    ("inp", ["inpf", "inpb", "injct", "npr"]),
    (
        "emissn",
        [
            "nflag_emit",
            "nepl",
            "flpf",
            "flpb",
            "curf",
            "curb",
            "qp",
            "qpr",
            "abvdem",
            "dnsb",
            "ray_zenith_angle_deg",
            "ray_azimuth_angle_deg",
            "emission_time_mode",
            "emission_start_step",
            "emission_end_step",
            "emission_time_sigma",
            "emission_leave_anti_particle",
        ],
    ),
    ("digcon", ["ipadig", "ipahdf", "ipaxyz", "ildig", "imdig", "isort", "irhsp"]),
    ("system", ["npbnd", "mfpath"]),
    ("ptcond", ["pemax", "deltaemax"]),
]:
    for _k in _keys:
        _SPECIES_PARAMS[_k] = _g


def _detect_nspec(groups: list[tuple[str, OrderedDict]]) -> int:
    """Detect nspec from system group or array lengths."""
    for gname, params in groups:
        if gname == "system" and "nspec" in params:
            return int(params["nspec"])
    # Fallback: infer from wp array length
    for gname, params in groups:
        if gname == "plasma" and "wp" in params:
            v = params["wp"]
            return len(v) if isinstance(v, list) else 1
    return 0


# Parameters where species index is the SECOND dimension (2D arrays)
# key → size of first dimension
_SPECIES_2D_PARAMS: dict[str, int] = {
    "ipaxyz": 7,
    "npbnd": 3,
}


def _extract_species(
    groups: list[tuple[str, OrderedDict]], nspec: int
) -> tuple[list[dict], list[tuple[str, OrderedDict]]]:
    """Extract per-species params from groups, return (species_list, remaining_groups)."""
    species: list[dict] = [{} for _ in range(nspec)]
    remaining: list[tuple[str, OrderedDict]] = []

    for gname, params in groups:
        leftover = OrderedDict()
        for key, value in params.items():
            if key in _SPECIES_PARAMS and _SPECIES_PARAMS[key] == gname:
                if key in _SPECIES_2D_PARAMS and isinstance(value, list):
                    # 2D param stored flat: split into chunks of first-dim size
                    chunk = _SPECIES_2D_PARAMS[key]
                    for i in range(nspec):
                        start = i * chunk
                        end = start + chunk
                        if end <= len(value):
                            species[i][key] = value[start:end]
                elif isinstance(value, list) and len(value) >= nspec:
                    for i in range(nspec):
                        species[i][key] = value[i]
                elif isinstance(value, list) and len(value) < nspec:
                    for i in range(len(value)):
                        if value[i] != 0 and value[i] is not False:
                            species[i][key] = value[i]
                elif not isinstance(value, list):
                    leftover[key] = value
                    continue
            elif key == "nspec" and gname == "system":
                continue  # Skip nspec, auto-computed
            else:
                leftover[key] = value
        if leftover:
            remaining.append((gname, leftover))

    return species, remaining


# ── v2 extraction helpers ─────────────────────────────────────────


def _get_val(arr, idx):
    """Get value at 0-based index from list, or return scalar."""
    if isinstance(arr, list):
        return arr[idx] if idx < len(arr) else 0
    return arr


def _get_col(matrix, col_idx, pad_to: int = 0):
    """Extract column (0-based) from row-major 2D list, padded to min length."""
    result = [row[col_idx] if col_idx < len(row) else 0 for row in matrix]
    while len(result) < pad_to:
        result.append(0)
    return result


def _is_matrix(val):
    """True if val is a 2D list (list of lists)."""
    return isinstance(val, list) and val and isinstance(val[0], list)


# ── ptcond.objects + conductor_groups ─────────────────────────────

_OBJECT_SCALAR_PARAMS = [
    "geotype",
    "xlpc",
    "xupc",
    "ylpc",
    "yupc",
    "zlpc",
    "zupc",
    "bdyradius",
    "bdyalign",
    "biasp",
    "dscaled",
    "nflag_subcell",
    "wirealign",
    "wirerradius",
    "wireeradius",
    "wirehlength",
]
_OBJECT_MATRIX_PARAMS: dict[str, int] = {
    "bdycoord": 3,
    "bdyedge": 2,
    "wireorigin": 3,
}
_CONDUCTOR_GROUP_PARAMS = ["mtd_vchg", "pfixed"]


def _extract_objects(params: OrderedDict):
    """Extract [[ptcond.objects]] + [ptcond.conductor_groups]."""
    npc = params.get("npc", 0)
    if isinstance(npc, list):
        npc = npc[0] if npc else 0
    npc = int(npc)
    if npc <= 0:
        return [], {}, params

    npcg = params.get("npcg", 1)
    if isinstance(npcg, list):
        npcg = npcg[0] if npcg else 1
    npcg = int(npcg)
    pcgs = params.get("pcgs", [1] * npc)

    # Conductor groups
    groups: OrderedDict = OrderedDict()
    for g in range(npcg):
        gd: OrderedDict = OrderedDict()
        for key in _CONDUCTOR_GROUP_PARAMS:
            val = params.get(key)
            if val is not None:
                gd[key] = _get_val(val, g)
        groups[f"group_{g + 1}"] = gd

    # Objects
    objects: list[OrderedDict] = []
    for i in range(npc):
        obj: OrderedDict = OrderedDict()
        g_idx = int(_get_val(pcgs, i))
        obj["conductor"] = f"group_{g_idx}"
        try:
            gt = int(_get_val(params.get("geotype", [0]), i))
        except (ValueError, TypeError):
            gt = 0
        obj["geotype"] = gt

        # Shape params by geotype
        if gt in (0, 1):
            for key in ["xlpc", "xupc", "ylpc", "yupc", "zlpc", "zupc"]:
                val = params.get(key)
                if val is not None:
                    obj[key] = _get_val(val, i)
        elif gt == 2:
            for key in ["bdyradius", "bdyalign"]:
                val = params.get(key)
                if val is not None:
                    obj[key] = _get_val(val, i)
            for key, dim in [("bdycoord", 3), ("bdyedge", 2)]:
                val = params.get(key)
                if val is not None and _is_matrix(val):
                    obj[key] = _get_col(val, i, pad_to=dim)[:dim]
        elif gt == 3:
            val = params.get("bdyradius")
            if val is not None:
                obj["bdyradius"] = _get_val(val, i)
            val = params.get("bdycoord")
            if val is not None and _is_matrix(val):
                obj["bdycoord"] = _get_col(val, i, pad_to=3)[:3]

        # Wire (only if enabled)
        wa = int(_get_val(params.get("wirealign", [0]), i))
        if wa != 0:
            obj["wirealign"] = wa
            for key in ["wirerradius", "wireeradius", "wirehlength"]:
                val = params.get(key)
                if val is not None:
                    obj[key] = _get_val(val, i)
            val = params.get("wireorigin")
            if val is not None and _is_matrix(val):
                obj["wireorigin"] = _get_col(val, i, pad_to=3)[:3]

        # Optional (non-default only)
        for key, default in [("biasp", 0.0), ("dscaled", 1.0), ("nflag_subcell", 0)]:
            val = params.get(key)
            if val is not None:
                v = _get_val(val, i)
                if v != default:
                    obj[key] = v

        objects.append(obj)

    extracted = {"npc", "npcg", "pcgs", "ccgs"}
    extracted.update(_OBJECT_SCALAR_PARAMS)
    extracted.update(_OBJECT_MATRIX_PARAMS)
    extracted.update(_CONDUCTOR_GROUP_PARAMS)
    remaining = OrderedDict((k, v) for k, v in params.items() if k not in extracted)
    return objects, groups, remaining


# ── ptcond.boundaries ─────────────────────────────────────────────

_BOUNDARY_SCALAR_PARAMS = [
    "sphere_radius",
    "circle_radius",
    "cylinder_radius",
    "cylinder_height",
    "disk_radius",
    "disk_inner_radius",
    "disk_height",
    "plane_with_circle_radius",
    "boundary_conductor_id",
    "conductivity",
]
_BOUNDARY_MATRIX_PARAMS: dict[str, int] = {
    "rectangle_shape": 6,
    "cuboid_shape": 6,
    "sphere_origin": 3,
    "circle_origin": 3,
    "cylinder_origin": 3,
    "disk_origin": 3,
    "plane_with_circle_origin": 3,
}
_BOUNDARY_SPECIES_PARAMS = [
    "boundary_mirror_reflection_rate",
    "boundary_reversal_reflection_rate",
    "boundary_mirror_reflect_alpha",
    "boundary_reversal_reflect_alpha",
    "boundary_mirror_reflect_energy_loss_frac",
    "boundary_reversal_reflect_energy_loss_frac",
    "enable_secondary_electron_emission",
    "boundary_se_yield_max",
    "boundary_se_energy_max",
    "boundary_se_species_id",
    "boundary_se_model_type",
    "boundary_se_const_yield",
]


def _extract_boundaries(params: OrderedDict):
    """Extract [[ptcond.boundaries]] from ptcond params."""
    bt = params.get("boundary_types")
    if not bt or not isinstance(bt, list):
        return [], params

    entries: list[OrderedDict] = []
    for i, btype in enumerate(bt):
        if isinstance(btype, str) and btype.lower() == "none":
            continue
        entry: OrderedDict = OrderedDict()
        entry["type"] = btype

        for key in _BOUNDARY_SCALAR_PARAMS:
            val = params.get(key)
            if val is not None and isinstance(val, list) and i < len(val):
                v = val[i]
                if v != 0 and v != 0.0:
                    entry[key] = v

        for key, dim in _BOUNDARY_MATRIX_PARAMS.items():
            val = params.get(key)
            if val is not None and _is_matrix(val):
                col = _get_col(val, i, pad_to=dim)[:dim]
                if any(v != 0 for v in col):
                    entry[key] = col

        for key in _BOUNDARY_SPECIES_PARAMS:
            val = params.get(key)
            if val is not None and _is_matrix(val) and i < len(val):
                row = val[i]
                if any(v != 0 and v is not False for v in row):
                    entry[key] = row

        entries.append(entry)

    extracted = {"boundary_type", "boundary_types"}
    extracted.update(_BOUNDARY_SCALAR_PARAMS)
    extracted.update(_BOUNDARY_MATRIX_PARAMS)
    extracted.update(_BOUNDARY_SPECIES_PARAMS)
    remaining = OrderedDict((k, v) for k, v in params.items() if k not in extracted)
    return entries, remaining


# ── Generic array-of-tables (dipole, testch, jsrc) ───────────────


def _extract_aot(
    params: OrderedDict,
    count_key: str,
    scalar_keys: list[str],
    matrix_keys: dict[str, int],
):
    """Extract entries for simple array-of-tables."""
    n = params.get(count_key, 0)
    if isinstance(n, list):
        n = n[0] if n else 0
    n = int(n)
    if n <= 0:
        return [], params

    entries: list[OrderedDict] = []
    for i in range(n):
        entry: OrderedDict = OrderedDict()
        for key in scalar_keys:
            val = params.get(key)
            if val is not None:
                entry[key] = _get_val(val, i)
        for key, dim in matrix_keys.items():
            val = params.get(key)
            if val is not None and _is_matrix(val):
                entry[key] = _get_col(val, i, pad_to=dim)[:dim]
            elif val is not None and isinstance(val, list):
                entry[key] = _get_val(val, i)
        entries.append(entry)

    extracted = {count_key}
    extracted.update(scalar_keys)
    extracted.update(matrix_keys)
    remaining = OrderedDict((k, v) for k, v in params.items() if k not in extracted)
    return entries, remaining


# ── emissn.planes ─────────────────────────────────────────────────

_EMISSION_PLANE_PARAMS = [
    "nemd",
    "ipcpl",
    "xmine",
    "xmaxe",
    "ymine",
    "ymaxe",
    "zmine",
    "zmaxe",
    "curfs",
    "curbs",
    "dnsfs",
    "dnsbs",
    "flpfs",
    "flpbs",
    "remf",
    "remb",
]


def _extract_emission_planes(params: OrderedDict):
    """Extract [[emissn.planes]] from emissn params."""
    # Infer plane count from nemd array length
    nemd = params.get("nemd")
    if not nemd or not isinstance(nemd, list):
        return [], params
    n = len(nemd)

    entries: list[OrderedDict] = []
    for i in range(n):
        v = _get_val(nemd, i)
        if v == 0:
            continue
        entry: OrderedDict = OrderedDict()
        for key in _EMISSION_PLANE_PARAMS:
            val = params.get(key)
            if val is not None and isinstance(val, list) and i < len(val):
                entry[key] = val[i]
            elif val is not None and not isinstance(val, list):
                entry[key] = val
        entries.append(entry)

    remaining = OrderedDict(
        (k, v) for k, v in params.items() if k not in set(_EMISSION_PLANE_PARAMS)
    )
    return entries, remaining


# ── v2 group emitters ─────────────────────────────────────────────

## _emit_kv is now imported from ._toml_fmt above


def _emit_ptcond_v2(parts: list[str], params: OrderedDict):
    objects, cgroups, params = _extract_objects(params)
    boundaries, params = _extract_boundaries(params)

    for gname, gparams in cgroups.items():
        _emit_kv(parts, gparams, f"[ptcond.conductor_groups.{gname}]")
    for obj in objects:
        _emit_kv(parts, obj, "[[ptcond.objects]]")
    for entry in boundaries:
        _emit_kv(parts, entry, "[[ptcond.boundaries]]")
    _emit_kv(parts, params, "[ptcond]" if params else None)


def _emit_dipole_v2(parts: list[str], params: OrderedDict):
    entries, params = _extract_aot(
        params,
        "nmd",
        ["md", "mdx", "mdy", "mdz", "mddir"],
        {},
    )
    for e in entries:
        _emit_kv(parts, e, "[[dipole.sources]]")
    _emit_kv(parts, params, "[dipole]" if params else None)


def _emit_testch_v2(parts: list[str], params: OrderedDict):
    entries, params = _extract_aot(
        params,
        "ntch",
        ["qtch", "e1tch", "p1tch", "rcutoff"],
        {"rtch": 3},
    )
    for e in entries:
        _emit_kv(parts, e, "[[testch.charges]]")
    _emit_kv(parts, params, "[testch]" if params else None)


def _emit_jsrc_v2(parts: list[str], params: OrderedDict):
    entries, params = _extract_aot(
        params,
        "njs",
        ["wjs", "th0js"],
        {"rjs": 3, "ajs": 3},
    )
    for e in entries:
        _emit_kv(parts, e, "[[jsrc.sources]]")
    _emit_kv(parts, params, "[jsrc]" if params else None)


def _emit_emissn_v2(parts: list[str], params: OrderedDict):
    entries, params = _extract_emission_planes(params)
    for e in entries:
        _emit_kv(parts, e, "[[emissn.planes]]")
    _emit_kv(parts, params, "[emissn]" if params else None)


# ── v2 main emitter ──────────────────────────────────────────────

_V2_GROUP_EMITTERS: dict[str, object] = {
    "ptcond": _emit_ptcond_v2,
    "dipole": _emit_dipole_v2,
    "testch": _emit_testch_v2,
    "jsrc": _emit_jsrc_v2,
    "emissn": _emit_emissn_v2,
}


def _to_toml_v2(
    meta: dict | None,
    groups: list[tuple[str, OrderedDict]],
    schema: str | None = None,
) -> str:
    parts: list[str] = []

    if schema:
        parts.append(f"#:schema {schema}")
        parts.append("")

    if meta:
        parts.append("[meta]")
        parts.append("format_version = 2")
        parts.append("")
        parts.append("[meta.unit_conversion]")
        for k, v in meta.items():
            parts.append(f"{k} = {_fmt(v)}")
        parts.append("")

    # Extract species
    nspec = _detect_nspec(groups)
    if nspec > 0:
        species_list, groups = _extract_species(groups, nspec)
        for sp in species_list:
            parts.append("[[species]]")
            for key, value in sp.items():
                parts.append(f"{key} = {_fmt(value)}")
            parts.append("")

    # Remaining groups (with v2 extraction for supported groups)
    for gname, params in groups:
        if not params:
            continue
        emitter = _V2_GROUP_EMITTERS.get(gname)
        if emitter:
            emitter(parts, params)
        else:
            parts.append(f"[{gname}]")
            for key, value in params.items():
                parts.append(f"{key} = {_fmt(value)}")
            parts.append("")

    return "\n".join(parts)


# ── CLI ───────────────────────────────────────────────────────────


def main(argv: list[str] | None = None) -> int:
    ap = argparse.ArgumentParser(
        prog="inp2toml",
        description="Convert plasma.inp (Fortran namelist) to plasma.toml.",
    )
    ap.add_argument("input", help="Path to plasma.inp")
    ap.add_argument(
        "-o",
        "--output",
        default=None,
        help="Output path (default: <input>.toml). Use '-' for stdout.",
    )
    ap.add_argument(
        "--schema",
        default=SCHEMA_URL,
        help=f"$schema URI to embed (default: {SCHEMA_URL}). "
        "Pass empty string to omit.",
    )
    ap.add_argument(
        "--format-version",
        type=int,
        default=2,
        choices=[1, 2],
        help="Output format version. 1=flat arrays, 2=new-style [[species]] etc. (default).",
    )
    ap.add_argument(
        "--generate-physical",
        action=argparse.BooleanOptionalAction,
        default=True,
        help="Generate [meta.physical] section with SI-unit values (requires format version 2). "
        "Enabled by default. Use --no-generate-physical to disable.",
    )
    args = ap.parse_args(argv)

    inp_path = Path(args.input)
    if not inp_path.exists():
        print(f"ERROR: {inp_path} not found.", file=sys.stderr)
        return 1

    text = inp_path.read_text(encoding="utf-8", errors="replace")
    meta, groups = parse_inp(text)
    schema = args.schema or None
    format_version = args.format_version

    if args.generate_physical and format_version < 2:
        format_version = 2
        print(
            "NOTE: --generate-physical requires format version 2; auto-upgrading.",
            file=sys.stderr,
        )

    toml_text = to_toml(meta, groups, schema=schema, format_version=format_version)

    if args.generate_physical:
        from .plasma_toml import PlasmaToml

        pt = PlasmaToml.from_dict(_parse_toml_text(toml_text))
        pt._schema = schema
        pt.generate_physical()
        toml_text = pt.to_toml_string()

    if args.output == "-":
        sys.stdout.write(toml_text)
    else:
        out_path = Path(args.output) if args.output else inp_path.with_suffix(".toml")
        out_path.write_text(toml_text, encoding="utf-8")
        print(f"Written: {out_path}", file=sys.stderr)

    return 0


if __name__ == "__main__":
    raise SystemExit(main())
