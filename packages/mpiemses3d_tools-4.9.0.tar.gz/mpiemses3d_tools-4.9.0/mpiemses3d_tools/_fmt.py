"""Shared TOML formatting utilities for plasma.toml serialization."""

from __future__ import annotations


def fmt(value) -> str:
    """Format a Python value as a TOML literal."""
    if isinstance(value, bool):
        return "true" if value else "false"
    if isinstance(value, int):
        return str(value)
    if isinstance(value, float):
        r = repr(value)
        if "." not in r and "e" not in r.lower():
            r += ".0"
        return r
    if isinstance(value, str):
        return f'"{value}"'
    if isinstance(value, list):
        if value and isinstance(value[0], list):
            inner = ", ".join(
                "[" + ", ".join(fmt(v) for v in row) + "]" for row in value
            )
            return f"[{inner}]"
        return "[" + ", ".join(fmt(v) for v in value) + "]"
    return str(value)


def emit_kv(parts: list[str], params: dict, header: str | None = None):
    """Emit [header] + key = value lines to *parts*."""
    if not params:
        return
    if header:
        parts.append(header)
    for k, v in params.items():
        parts.append(f"{k} = {fmt(v)}")
    parts.append("")
