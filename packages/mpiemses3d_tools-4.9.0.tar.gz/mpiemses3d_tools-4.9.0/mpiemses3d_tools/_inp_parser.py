"""Fortran namelist parser for plasma.inp files.

Parses ``!!key`` headers, ``&group … /`` namelist blocks,
array slice syntax, 2D indexing, and Fortran literals.
"""

from __future__ import annotations

import re
from collections import OrderedDict

# ── LHS patterns (checked in order) ──────────────────────────────
_RE_2D = re.compile(r"(\w+)\s*\(\s*(\d+)\s*,\s*(\d+)\s*\)")
_RE_2D_COL_SLICE = re.compile(r"(\w+)\s*\(\s*(\d+)\s*,\s*(\d+)\s*:\s*(\d+)\s*\)")
_RE_2D_ROW_SLICE = re.compile(r"(\w+)\s*\(\s*(\d+)\s*:\s*(\d+)\s*,\s*(\d+)\s*\)")
_RE_2D_FULL_ROW = re.compile(r"(\w+)\s*\(\s*:\s*,\s*(\d+)\s*\)")  # var(:, col)
_RE_2D_FULL_COL = re.compile(r"(\w+)\s*\(\s*(\d+)\s*,\s*:\s*\)")  # var(row, :)
_RE_SLICE = re.compile(r"(\w+)\s*\(\s*(\d+)\s*:\s*(\d+)\s*\)")
_RE_SINGLE = re.compile(r"(\w+)\s*\(\s*(\d+)\s*\)")
_RE_PLAIN = re.compile(r"(\w+)")


def _remove_inline_comment(line: str) -> str:
    """Strip trailing ``!`` comment while preserving quoted strings."""
    in_str = False
    qchar = ""
    for i, ch in enumerate(line):
        if in_str:
            if ch == qchar:
                in_str = False
        else:
            if ch in ('"', "'"):
                in_str = True
                qchar = ch
            elif ch == "!":
                return line[:i].rstrip()
    return line.rstrip()


def _parse_scalar(s: str):
    """Parse a single Fortran literal into a Python value."""
    s = s.strip().rstrip(",")
    if not s:
        return None
    low = s.lower()
    if low in (".true.", "true"):
        return True
    if low in (".false.", "false"):
        return False
    if (s.startswith('"') and s.endswith('"')) or (
        s.startswith("'") and s.endswith("'")
    ):
        return s[1:-1]
    # Fortran double-precision exponent d/D -> e
    s_num = re.sub(r"[dD]", "e", s)
    try:
        if "." in s_num or "e" in s_num.lower():
            return float(s_num)
        return int(s_num)
    except ValueError:
        return s


def _split_values(text: str) -> list:
    """Split comma-separated Fortran values respecting quoted strings."""
    values: list = []
    current = ""
    in_str = False
    qchar = ""
    for ch in text:
        if in_str:
            current += ch
            if ch == qchar:
                in_str = False
        elif ch in ('"', "'"):
            in_str = True
            qchar = ch
            current += ch
        elif ch == ",":
            if current.strip():
                values.append(_parse_scalar(current))
            current = ""
        else:
            current += ch
    if current.strip():
        values.append(_parse_scalar(current))
    return [v for v in values if v is not None]


def _parse_key_header(line: str) -> dict | None:
    """``!!key dx=[0.5],to_c=[10000.0]`` -> ``{'dx': 0.5, 'to_c': 10000.0}``."""
    m = re.match(r"^!!key\s+(.*)", line.strip())
    if not m:
        return None
    result: dict = {}
    for kv in re.finditer(r"(\w+)\s*=\s*\[([^\]]*)\]", m.group(1)):
        result[kv.group(1)] = _parse_scalar(kv.group(2))
    return result


def _parse_group_lines(lines: list[str]) -> OrderedDict:
    """Parse raw lines inside ``&group ... /`` into an ordered parameter dict."""

    # 1) Collect logical assignment strings (join continuation lines)
    assignments: list[str] = []
    current: str | None = None
    for line in lines:
        stripped = line.strip()
        if not stripped or stripped.startswith("!"):
            continue
        stripped = _remove_inline_comment(stripped)
        if not stripped:
            continue
        if re.match(r"\w+\s*(\(|=)", stripped):
            if current is not None:
                assignments.append(current)
            current = stripped
        elif current is not None:
            current += " " + stripped
    if current is not None:
        assignments.append(current)

    # 2) Interpret each assignment
    storage: OrderedDict = OrderedDict()

    for text in assignments:
        eq_pos = text.index("=")
        lhs = text[:eq_pos].strip()
        rhs = text[eq_pos + 1 :].strip()
        values = _split_values(rhs)
        if not values:
            continue

        m2d_cs = _RE_2D_COL_SLICE.match(lhs)
        m2d_rs = _RE_2D_ROW_SLICE.match(lhs)
        m2d_fr = _RE_2D_FULL_ROW.match(lhs)
        m2d_fc = _RE_2D_FULL_COL.match(lhs)
        m2d = _RE_2D.match(lhs)
        mslice = _RE_SLICE.match(lhs)
        msingle = _RE_SINGLE.match(lhs)

        if m2d_cs:
            var = m2d_cs.group(1)
            ri = int(m2d_cs.group(2))
            cs, _ce = int(m2d_cs.group(3)), int(m2d_cs.group(4))
            entry = storage.setdefault(var, {"kind": "matrix", "data": {}})
            if entry["kind"] != "matrix":
                entry["kind"] = "matrix"
                entry["data"] = {}
            for k, v in enumerate(values):
                entry["data"][(ri, cs + k)] = v

        elif m2d_rs:
            var = m2d_rs.group(1)
            rs, _re = int(m2d_rs.group(2)), int(m2d_rs.group(3))
            ci = int(m2d_rs.group(4))
            entry = storage.setdefault(var, {"kind": "matrix", "data": {}})
            if entry["kind"] != "matrix":
                entry["kind"] = "matrix"
                entry["data"] = {}
            for k, v in enumerate(values):
                entry["data"][(rs + k, ci)] = v

        elif m2d_fr:
            # var(:, col) — full row-slice: values fill rows 1..N at fixed column
            var = m2d_fr.group(1)
            ci = int(m2d_fr.group(2))
            entry = storage.setdefault(var, {"kind": "matrix", "data": {}})
            if entry["kind"] != "matrix":
                entry["kind"] = "matrix"
                entry["data"] = {}
            for k, v in enumerate(values):
                entry["data"][(1 + k, ci)] = v

        elif m2d_fc:
            # var(row, :) — full col-slice: values fill cols 1..N at fixed row
            var = m2d_fc.group(1)
            ri = int(m2d_fc.group(2))
            entry = storage.setdefault(var, {"kind": "matrix", "data": {}})
            if entry["kind"] != "matrix":
                entry["kind"] = "matrix"
                entry["data"] = {}
            for k, v in enumerate(values):
                entry["data"][(ri, 1 + k)] = v

        elif m2d:
            var = m2d.group(1)
            ri, ci = int(m2d.group(2)), int(m2d.group(3))
            entry = storage.setdefault(var, {"kind": "matrix", "data": {}})
            if entry["kind"] != "matrix":
                entry["kind"] = "matrix"
                entry["data"] = {}
            for k, v in enumerate(values):
                entry["data"][(ri + k, ci)] = v

        elif mslice:
            var = mslice.group(1)
            start, _end = int(mslice.group(2)), int(mslice.group(3))
            entry = storage.setdefault(var, {"kind": "array", "data": {}})
            if entry["kind"] == "scalar":
                entry.update(kind="array", data={})
            if entry["kind"] == "flat":
                entry.update(
                    kind="array", data={i + 1: v for i, v in enumerate(entry["data"])}
                )
            for k, v in enumerate(values):
                entry["data"][start + k] = v

        elif msingle:
            var = msingle.group(1)
            idx = int(msingle.group(2))
            entry = storage.setdefault(var, {"kind": "array", "data": {}})
            if entry["kind"] == "scalar":
                entry.update(kind="array", data={})
            if entry["kind"] == "flat":
                entry.update(
                    kind="array", data={i + 1: v for i, v in enumerate(entry["data"])}
                )
            for k, v in enumerate(values):
                entry["data"][idx + k] = v

        else:
            var = _RE_PLAIN.match(lhs).group(1)  # type: ignore[union-attr]
            if len(values) == 1:
                if var in storage and storage[var]["kind"] == "array":
                    d = storage[var]["data"]
                    d[max(d) + 1] = values[0]
                else:
                    storage[var] = {"kind": "scalar", "data": values[0]}
            else:
                storage[var] = {"kind": "flat", "data": values}

    # 3) Finalize into plain Python values
    result: OrderedDict = OrderedDict()
    for var, entry in storage.items():
        kind = entry["kind"]
        data = entry["data"]

        if kind == "scalar":
            result[var] = data
        elif kind == "flat":
            result[var] = list(data)
        elif kind == "array":
            hi = max(data)
            result[var] = [data.get(i, 0) for i in range(1, hi + 1)]
        elif kind == "matrix":
            rhi = max(k[0] for k in data)
            chi = max(k[1] for k in data)
            result[var] = [
                [data.get((r, c), 0) for c in range(1, chi + 1)]
                for r in range(1, rhi + 1)
            ]

    return result


def parse_inp(text: str) -> tuple[dict | None, list[tuple[str, OrderedDict]]]:
    """Parse full ``plasma.inp`` text.

    Returns ``(meta, [(group_name, params), ...])``.
    """
    lines = text.splitlines()

    # !!key header
    meta = None
    for line in lines:
        s = line.strip()
        if s.startswith("!!key"):
            meta = _parse_key_header(s)
            break
        if s and not s.startswith("!"):
            break

    # Namelist groups
    groups: list[tuple[str, OrderedDict]] = []
    i = 0
    while i < len(lines):
        s = lines[i].strip()
        m = re.match(r"&(\w+)", s)
        if m:
            gname = m.group(1)
            glines: list[str] = []
            i += 1
            while i < len(lines):
                if lines[i].strip() == "/":
                    break
                glines.append(lines[i])
                i += 1
            groups.append((gname, _parse_group_lines(glines)))
        i += 1

    return meta, groups
