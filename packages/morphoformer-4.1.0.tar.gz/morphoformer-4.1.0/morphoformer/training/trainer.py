from __future__ import annotations

import math
import time
from pathlib import Path
from typing import TypedDict, cast

import torch

from morphoformer import __version__ as MORPHOFORMER_VERSION
from chartoken import CharVocab, FeatureVocab, PAD
from chartoken.feature_vocab import FeatureVocabState
from chartoken.vocab import CharVocabState
from morphoformer.config.schema import DataConfig, MorphoformerConfig, OptimizerConfig, TrainConfig
from morphoformer.model.model import Morphoformer
from sigmorphon import MorphDataset, load_tsv_pattern
from sigmorphon.dataset import MorphRow
from trainkit import MultiLevelSequenceLoss, create_cosine_schedule, freeze_stages, load_checkpoint, save_checkpoint


class MorphoformerCheckpointMetadata(TypedDict):
    package_version: str
    model_family: str
    model_series: str
    train_stage: str
    device: str
    d_model: int
    dim_ff: int
    num_heads: int
    num_kv_heads: int
    universal_layers: int
    family_layers: int
    language_layers: int
    num_languages: int


class MorphoformerCheckpointBase(TypedDict):
    model_state: dict[str, torch.Tensor]
    optimizer_state: dict[str, object]
    char_vocab: CharVocabState
    feature_vocab: FeatureVocabState
    language_to_id: dict[str, int]
    epoch: int


class MorphoformerCheckpointOptional(TypedDict, total=False):
    global_step: int
    best_dev_loss: float
    metadata: MorphoformerCheckpointMetadata


class MorphoformerCheckpoint(MorphoformerCheckpointBase, MorphoformerCheckpointOptional):
    pass


def _create_grad_scaler(device_type: str, enabled: bool) -> torch.GradScaler:
    return torch.GradScaler(device_type, enabled=enabled)


def _optimizer_step_completed(scaler: torch.GradScaler, previous_scale: float) -> bool:
    if not scaler.is_enabled():
        return True
    return scaler.get_scale() >= previous_scale


def _format_duration(total_seconds: float) -> str:
    rounded_seconds = max(0, int(total_seconds))
    hours, remainder = divmod(rounded_seconds, 3600)
    minutes, seconds = divmod(remainder, 60)
    return f"{hours:02d}:{minutes:02d}:{seconds:02d}"


def _estimate_batch_count(num_samples: int, batch_size: int) -> int:
    return max(1, math.ceil(num_samples / batch_size))


def _parameter_counts(model: torch.nn.Module) -> tuple[int, int]:
    total_params = sum(parameter.numel() for parameter in model.parameters())
    trainable_params = sum(parameter.numel() for parameter in model.parameters() if parameter.requires_grad)
    return total_params, trainable_params


class MorphoformerTrainer:
    def __init__(self, config: MorphoformerConfig) -> None:
        self.config: MorphoformerConfig = config
        self.data_config: DataConfig = config.data
        self.train_config: TrainConfig = config.train
        self.optimizer_config: OptimizerConfig = config.optimizer
        self.device = torch.device(
            self.train_config.device if self.train_config.device != "cuda" or torch.cuda.is_available() else "cpu"
        )

    def _build_vocabs(self, rows: list[MorphRow]) -> tuple[CharVocab, FeatureVocab]:
        texts = [lemma for lemma, _, _, _ in rows] + [surface for _, _, surface, _ in rows]
        tags = [features for _, features, _, _ in rows]
        return CharVocab.from_texts(texts), FeatureVocab.from_tags(tags)

    def _build_language_map(self) -> dict[str, int]:
        return {language: idx for idx, language in enumerate(sorted(self.config.languages))}

    def _create_dataset(
        self,
        rows: list[MorphRow],
        char_vocab: CharVocab,
        feature_vocab: FeatureVocab,
        language_to_id: dict[str, int],
    ) -> MorphDataset:
        return MorphDataset(
            rows,
            char_vocab,
            feature_vocab,
            language_to_id,
            max_len=self.data_config.max_len,
            max_features=self.data_config.max_features,
        )

    def _checkpoint_metadata(self, model: Morphoformer) -> MorphoformerCheckpointMetadata:
        model_config = self.config.model
        return {
            "package_version": MORPHOFORMER_VERSION,
            "model_family": model.model_family,
            "model_series": model.model_series,
            "train_stage": self.train_config.stage,
            "device": self.device.type,
            "d_model": model_config.d_model,
            "dim_ff": model_config.dim_ff,
            "num_heads": model_config.num_heads,
            "num_kv_heads": model_config.num_kv_heads,
            "universal_layers": model_config.universal_layers,
            "family_layers": model_config.family_layers,
            "language_layers": model_config.language_layers,
            "num_languages": len(self.config.languages),
        }

    def _checkpoint_payload(
        self,
        model: Morphoformer,
        char_vocab: CharVocab,
        feature_vocab: FeatureVocab,
        optimizer: torch.optim.Optimizer,
        epoch: int,
        global_step: int,
        best_dev_loss: float,
    ) -> MorphoformerCheckpoint:
        return {
            "model_state": model.state_dict(),
            "optimizer_state": optimizer.state_dict(),
            "char_vocab": char_vocab.to_dict(),
            "feature_vocab": feature_vocab.to_dict(),
            "language_to_id": model.language_to_id,
            "epoch": epoch,
            "global_step": global_step,
            "best_dev_loss": best_dev_loss,
            "metadata": self._checkpoint_metadata(model),
        }

    def _print_training_header(
        self,
        model: Morphoformer,
        train_data: MorphDataset,
        dev_data: MorphDataset,
        train_batches_per_epoch: int,
        dev_batches_per_epoch: int,
    ) -> None:
        total_params, trainable_params = _parameter_counts(model)
        families = sorted({payload.family for payload in self.config.languages.values()})
        model_config = self.config.model
        optimizer_config = self.optimizer_config
        train_config = self.train_config
        print(
            f"run=morphoformer version={MORPHOFORMER_VERSION} "
            f"family={model.model_family} series={model.model_series} "
            f"stage={train_config.stage} device={self.device.type} amp={train_config.mixed_precision}",
            flush=True,
        )
        print(
            f"data train_rows={train_data.num_samples} dev_rows={dev_data.num_samples} "
            f"languages={len(self.config.languages)} families={len(families)} "
            f"max_len={self.data_config.max_len} max_features={self.data_config.max_features}",
            flush=True,
        )
        print(
            f"model d_model={model_config.d_model} dim_ff={model_config.dim_ff} "
            f"heads={model_config.num_heads} kv_heads={model_config.num_kv_heads} "
            f"layers={model_config.universal_layers}/{model_config.family_layers}/{model_config.language_layers} "
            f"params={total_params} trainable={trainable_params}",
            flush=True,
        )
        print(
            f"train epochs={train_config.epochs} batch_size={train_config.batch_size} "
            f"train_batches={train_batches_per_epoch} dev_batches={dev_batches_per_epoch} "
            f"planned_batches={train_batches_per_epoch * train_config.epochs} "
            f"scheduler_steps={train_config.total_steps} warmup_steps={train_config.warmup_steps}",
            flush=True,
        )
        print(
            f"optimizer lr={optimizer_config.lr:.6f} weight_decay={optimizer_config.weight_decay:.6f} "
            f"betas={optimizer_config.betas} output_dir={train_config.output_dir}",
            flush=True,
        )

    def train(self) -> Path:
        train_config = self.train_config
        optimizer_config = self.optimizer_config
        train_rows = load_tsv_pattern(self.data_config.train_path)
        dev_rows = load_tsv_pattern(self.data_config.dev_path)
        char_vocab, feature_vocab = self._build_vocabs(train_rows + dev_rows)
        language_to_id = self._build_language_map()
        train_data = self._create_dataset(train_rows, char_vocab, feature_vocab, language_to_id)
        dev_data = self._create_dataset(dev_rows, char_vocab, feature_vocab, language_to_id)

        model = Morphoformer(
            self.config,
            vocab_size=char_vocab.size,
            feature_vocab_size=feature_vocab.size,
            language_to_id=language_to_id,
        ).to(self.device)
        freeze_stages(model, train_config.stage)
        batch_size: int = train_config.batch_size
        train_batches_per_epoch = _estimate_batch_count(train_data.num_samples, batch_size)
        dev_batches_per_epoch = _estimate_batch_count(dev_data.num_samples, batch_size)
        total_train_batches = train_batches_per_epoch * train_config.epochs
        self._print_training_header(model, train_data, dev_data, train_batches_per_epoch, dev_batches_per_epoch)

        optimizer = torch.optim.AdamW(
            model.parameters(),
            lr=optimizer_config.lr,
            betas=optimizer_config.betas,
            weight_decay=optimizer_config.weight_decay,
        )
        scheduler = create_cosine_schedule(
            optimizer,
            warmup_steps=train_config.warmup_steps,
            total_steps=train_config.total_steps,
        )
        criterion = MultiLevelSequenceLoss(
            pad_id=PAD,
            final_weight=train_config.final_loss_weight,
            universal_weight=train_config.universal_loss_weight,
            family_weight=train_config.family_loss_weight,
            language_weight=train_config.language_loss_weight,
        )

        scaler = _create_grad_scaler(
            self.device.type,
            self.device.type == "cuda" and train_config.mixed_precision,
        )
        output_dir = Path(train_config.output_dir)
        output_dir.mkdir(parents=True, exist_ok=True)
        best_path = output_dir / "best.pt"
        interrupted_path = output_dir / "interrupted.pt"
        best_dev_loss = float("inf")
        global_step = 0
        train_start_time = time.perf_counter()
        current_epoch = 0
        current_batch = 0

        try:
            for epoch in range(1, train_config.epochs + 1):
                current_epoch = epoch
                current_batch = 0
                epoch_start_time = time.perf_counter()
                model.train()
                print(
                    f"epoch_start epoch={epoch}/{train_config.epochs} "
                    f"train_batches={train_batches_per_epoch} dev_batches={dev_batches_per_epoch}",
                    flush=True,
                )
                for batch_index, batch in enumerate(train_data.epoch_batches(batch_size, self.device), start=1):
                    current_batch = batch_index
                    source, target, language_ids, feature_ids, feature_mask = batch
                    optimizer.zero_grad(set_to_none=True)
                    with torch.autocast(device_type=self.device.type, enabled=scaler.is_enabled()):
                        output = model(source, language_ids, feature_ids, feature_mask)
                        losses = criterion(output, target)
                    scaler.scale(losses.total).backward()
                    scaler.unscale_(optimizer)
                    torch.nn.utils.clip_grad_norm_(model.parameters(), train_config.clip_grad_norm)
                    previous_scale = scaler.get_scale()
                    scaler.step(optimizer)
                    scaler.update()
                    if _optimizer_step_completed(scaler, previous_scale):
                        scheduler.step()
                        global_step += 1
                    if global_step > 0 and global_step % train_config.log_interval == 0:
                        stats = losses.as_scalars()
                        elapsed = time.perf_counter() - train_start_time
                        completed_train_batches = (epoch - 1) * train_batches_per_epoch + batch_index
                        remaining_train_batches = max(0, total_train_batches - completed_train_batches)
                        seconds_per_batch = elapsed / max(1, completed_train_batches)
                        eta = seconds_per_batch * remaining_train_batches
                        current_lr = optimizer.param_groups[0]["lr"]
                        best_display = "n/a" if math.isinf(best_dev_loss) else f"{best_dev_loss:.4f}"
                        print(
                            f"epoch={epoch}/{train_config.epochs} batch={batch_index}/{train_batches_per_epoch} "
                            f"step={global_step}/{train_config.total_steps} lr={current_lr:.6f} "
                            f"loss={stats['loss']:.4f} final={stats['loss_final']:.4f} "
                            f"universal={stats['loss_universal']:.4f} family={stats['loss_family']:.4f} "
                            f"language={stats['loss_language']:.4f} "
                            f"elapsed={_format_duration(elapsed)} eta={_format_duration(eta)} "
                            f"best_dev={best_display}",
                            flush=True,
                        )

                dev_loss = self.evaluate(model, dev_data, criterion)
                epoch_elapsed = time.perf_counter() - epoch_start_time
                elapsed = time.perf_counter() - train_start_time
                remaining_epochs = max(0, train_config.epochs - epoch)
                eta = (elapsed / max(1, epoch)) * remaining_epochs
                improved = dev_loss < best_dev_loss
                if improved:
                    best_dev_loss = dev_loss
                    save_checkpoint(
                        best_path,
                        self._checkpoint_payload(
                            model,
                            char_vocab,
                            feature_vocab,
                            optimizer,
                            epoch,
                            global_step,
                            best_dev_loss,
                        ),
                    )
                checkpoint_status = str(best_path) if improved else "unchanged"
                print(
                    f"epoch_end epoch={epoch}/{train_config.epochs} dev_loss={dev_loss:.4f} "
                    f"best_dev={best_dev_loss:.4f} improved={improved} "
                    f"epoch_time={_format_duration(epoch_elapsed)} "
                    f"elapsed={_format_duration(elapsed)} eta={_format_duration(eta)} "
                    f"checkpoint={checkpoint_status}",
                    flush=True,
                )
        except KeyboardInterrupt:
            optimizer.zero_grad(set_to_none=True)
            interrupted_elapsed = time.perf_counter() - train_start_time
            save_checkpoint(
                interrupted_path,
                self._checkpoint_payload(
                    model,
                    char_vocab,
                    feature_vocab,
                    optimizer,
                    current_epoch,
                    global_step,
                    best_dev_loss,
                ),
            )
            print(
                f"training_interrupted epoch={current_epoch}/{train_config.epochs} "
                f"batch={current_batch}/{train_batches_per_epoch} step={global_step}/{train_config.total_steps} "
                f"elapsed={_format_duration(interrupted_elapsed)} checkpoint={interrupted_path}",
                flush=True,
            )
            return interrupted_path

        return best_path

    def evaluate(self, model: Morphoformer, dataset: MorphDataset, criterion: MultiLevelSequenceLoss) -> float:
        model.eval()
        losses: list[float] = []
        with torch.no_grad():
            batch_size: int = self.train_config.batch_size
            for source, target, language_ids, feature_ids, feature_mask in dataset.epoch_batches(
                batch_size,
                self.device,
            ):
                output = model(source, language_ids, feature_ids, feature_mask)
                losses.append(float(criterion(output, target).total.detach().cpu()))
        return sum(losses) / max(1, len(losses))

    def load_model(self, checkpoint_path: str | Path) -> tuple[Morphoformer, CharVocab, FeatureVocab]:
        checkpoint = cast(MorphoformerCheckpoint, load_checkpoint(checkpoint_path, map_location=self.device))
        char_vocab = CharVocab.from_dict(checkpoint["char_vocab"])
        feature_vocab = FeatureVocab.from_dict(checkpoint["feature_vocab"])
        language_to_id = checkpoint["language_to_id"]
        model = Morphoformer(
            self.config,
            vocab_size=char_vocab.size,
            feature_vocab_size=feature_vocab.size,
            language_to_id=language_to_id,
        ).to(self.device)
        model.load_state_dict(checkpoint["model_state"])
        model.eval()
        return model, char_vocab, feature_vocab
