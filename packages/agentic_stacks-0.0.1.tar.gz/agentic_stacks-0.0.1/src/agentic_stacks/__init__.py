"""Agentic Stacks — composed domain expertise for AI agents and humans."""

__version__ = "0.0.1"
