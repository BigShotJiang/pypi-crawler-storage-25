"""
Tests for promptsmith.
Run with: pytest tests/ -v
"""

import pytest
from pathlib import Path

from promptsmith import Prompt, PromptRegistry, PromptRenderError, diff_prompts
from promptsmith.prompt import PromptVariable, _bump_version


# ── Prompt ────────────────────────────────────────────────────────────────────

class TestPrompt:
    def test_basic_render(self):
        p = Prompt("t", "Hello {name}!", variables={"name": str})
        assert p.render(name="Alice") == "Hello Alice!"

    def test_infers_variables(self):
        p = Prompt("t", "Hello {name}, you are {age} years old.")
        assert "name" in p.variables
        assert "age" in p.variables

    def test_type_casting(self):
        p = Prompt("t", "Port: {port}", variables={"port": int})
        result = p.render(port="8080")
        assert result == "Port: 8080"
        assert isinstance(p.variables["port"].cast("8080"), int)

    def test_missing_required_raises(self):
        p = Prompt("t", "Hello {name} {surname}", variables={"name": str, "surname": str})
        with pytest.raises(PromptRenderError):
            p.render(name="Alice")

    def test_unknown_variable_raises(self):
        p = Prompt("t", "Hello {name}", variables={"name": str})
        with pytest.raises(PromptRenderError):
            p.render(name="Alice", extra="oops")

    def test_default_value(self):
        p = Prompt("t", "Lang: {lang}", variables={
            "lang": PromptVariable("lang", str, required=False, default="English")
        })
        assert p.render() == "Lang: English"

    def test_render_messages_with_system(self):
        p = Prompt("t", "Answer: {q}", system="You are helpful.", variables={"q": str})
        msgs = p.render_messages(q="What is 2+2?")
        assert msgs[0]["role"] == "system"
        assert msgs[1]["role"] == "user"
        assert "2+2" in msgs[1]["content"]

    def test_render_messages_without_system(self):
        p = Prompt("t", "Hello {name}", variables={"name": str})
        msgs = p.render_messages(name="Bob")
        assert len(msgs) == 1
        assert msgs[0]["role"] == "user"

    def test_update_bumps_version(self):
        p = Prompt("t", "Hello {name}", variables={"name": str}, version="1.0.0")
        p2 = p.update(template="Hi {name}")
        assert p2.version == "1.0.1"
        assert p2.template == "Hi {name}"

    def test_update_preserves_name(self):
        p = Prompt("my_prompt", "Hello {name}", variables={"name": str})
        p2 = p.update(template="Hi {name}")
        assert p2.name == "my_prompt"

    def test_to_dict_and_from_dict(self):
        p = Prompt("t", "Hello {name}", variables={"name": str}, version="2.0.0",
                   tags=["test"], description="A test prompt")
        d = p.to_dict()
        p2 = Prompt.from_dict(d)
        assert p2.name == p.name
        assert p2.version == p.version
        assert p2.template == p.template
        assert p2.tags == p.tags

    def test_to_json_and_from_json(self):
        p = Prompt("t", "Hi {x}", variables={"x": int})
        j = p.to_json()
        p2 = Prompt.from_json(j)
        assert p2.render(x=42) == "Hi 42"

    def test_validate_returns_errors(self):
        p = Prompt("t", "{a} {b}", variables={"a": str, "b": int})
        errors = p.validate(a="hello")
        assert any("b" in e for e in errors)

    def test_validate_passes(self):
        p = Prompt("t", "{x}", variables={"x": str})
        assert p.validate(x="ok") == []

    def test_repr(self):
        p = Prompt("my_p", "{x}", variables={"x": str})
        assert "my_p" in repr(p)


# ── Version bumping ───────────────────────────────────────────────────────────

class TestVersionBump:
    def test_bump_patch(self):
        assert _bump_version("1.0.0") == "1.0.1"
        assert _bump_version("1.0.9") == "1.0.10"
        assert _bump_version("2.3.5") == "2.3.6"


# ── PromptRegistry ────────────────────────────────────────────────────────────

class TestPromptRegistry:
    def test_save_and_load(self, tmp_path):
        reg = PromptRegistry(str(tmp_path / "prompts"))
        p = Prompt("greeter", "Hello {name}", variables={"name": str})
        reg.save(p)
        loaded = reg.load("greeter")
        assert loaded.template == p.template
        assert loaded.version == p.version

    def test_load_latest(self, tmp_path):
        reg = PromptRegistry(str(tmp_path / "prompts"))
        p1 = Prompt("p", "v1 {x}", variables={"x": str}, version="1.0.0")
        p2 = Prompt("p", "v2 {x}", variables={"x": str}, version="1.0.1")
        reg.save(p1)
        reg.save(p2)
        loaded = reg.load("p")
        assert loaded.version == "1.0.1"

    def test_load_specific_version(self, tmp_path):
        reg = PromptRegistry(str(tmp_path / "prompts"))
        p1 = Prompt("p", "v1 {x}", variables={"x": str}, version="1.0.0")
        p2 = Prompt("p", "v2 {x}", variables={"x": str}, version="1.0.1")
        reg.save(p1); reg.save(p2)
        loaded = reg.load("p", version="1.0.0")
        assert loaded.template == "v1 {x}"

    def test_load_missing_raises(self, tmp_path):
        reg = PromptRegistry(str(tmp_path / "prompts"))
        with pytest.raises(FileNotFoundError):
            reg.load("nonexistent")

    def test_history(self, tmp_path):
        reg = PromptRegistry(str(tmp_path / "prompts"))
        p1 = Prompt("p", "v1 {x}", variables={"x": str}, version="1.0.0",
                    changelog="Initial")
        p2 = p1.update(template="v2 {x}", changelog="Updated template")
        reg.save(p1); reg.save(p2)
        hist = reg.history("p")
        assert len(hist) == 2
        assert hist[0]["version"] == "1.0.0"

    def test_names(self, tmp_path):
        reg = PromptRegistry(str(tmp_path / "prompts"))
        reg.save(Prompt("a", "A {x}", variables={"x": str}))
        reg.save(Prompt("b", "B {x}", variables={"x": str}))
        assert set(reg.names()) == {"a", "b"}

    def test_list(self, tmp_path):
        reg = PromptRegistry(str(tmp_path / "prompts"))
        reg.save(Prompt("a", "A {x}", variables={"x": str}, tags=["llm"]))
        entries = reg.list()
        assert len(entries) == 1
        assert entries[0]["name"] == "a"

    def test_list_filter_by_tag(self, tmp_path):
        reg = PromptRegistry(str(tmp_path / "prompts"))
        reg.save(Prompt("a", "A {x}", variables={"x": str}, tags=["llm"]))
        reg.save(Prompt("b", "B {x}", variables={"x": str}, tags=["chat"]))
        entries = reg.list(tag="llm")
        assert all("llm" in e["tags"] for e in entries)

    def test_delete_version(self, tmp_path):
        reg = PromptRegistry(str(tmp_path / "prompts"))
        p = Prompt("p", "{x}", variables={"x": str}, version="1.0.0")
        reg.save(p)
        count = reg.delete("p", "1.0.0")
        assert count == 1
        with pytest.raises(FileNotFoundError):
            reg.load("p", "1.0.0")

    def test_diff(self, tmp_path):
        reg = PromptRegistry(str(tmp_path / "prompts"))
        p1 = Prompt("p", "Summarize {text}", variables={"text": str}, version="1.0.0")
        p2 = Prompt("p", "Briefly summarize {text}", variables={"text": str}, version="1.0.1")
        reg.save(p1); reg.save(p2)
        d = reg.diff("p", "1.0.0", "1.0.1")
        assert "Summarize" in d or "summarize" in d.lower()

    def test_ab_test(self, tmp_path):
        reg = PromptRegistry(str(tmp_path / "prompts"))
        p1 = Prompt("p", "Answer: {q}", variables={"q": str}, version="1.0.0")
        p2 = Prompt("p", "Briefly answer: {q}", variables={"q": str}, version="1.0.1")
        reg.save(p1); reg.save(p2)

        runner = lambda prompt: f"Response to: {prompt[:20]}"
        scorer = lambda a, b: 1.0  # A always wins

        result = reg.ab_test("p", "1.0.0", "1.0.1",
                             inputs={"q": "What is 2+2?"},
                             runner=runner, scorer=scorer)
        assert result.winner == "1.0.0"
        assert result.output_a is not None
        assert result.output_b is not None

    def test_export_all(self, tmp_path):
        reg = PromptRegistry(str(tmp_path / "prompts"))
        reg.save(Prompt("a", "A {x}", variables={"x": str}))
        export_file = str(tmp_path / "export.json")
        reg.export_all(export_file)
        import json
        with open(export_file) as f:
            data = json.load(f)
        assert len(data) == 1
        assert data[0]["name"] == "a"


# ── Diff ──────────────────────────────────────────────────────────────────────

class TestDiff:
    def test_diff_template_change(self):
        a = Prompt("p", "Hello {name}", variables={"name": str}, version="1.0.0")
        b = Prompt("p", "Hi {name}", variables={"name": str}, version="1.0.1")
        d = diff_prompts(a, b)
        assert "-Hello" in d or "+Hi" in d

    def test_diff_no_change(self):
        a = Prompt("p", "Hello {name}", variables={"name": str}, version="1.0.0")
        b = Prompt("p", "Hello {name}", variables={"name": str}, version="1.0.1")
        d = diff_prompts(a, b)
        assert "no changes" in d.lower() or d

    def test_diff_variable_added(self):
        a = Prompt("p", "Hello {name}", variables={"name": str}, version="1.0.0")
        b = Prompt("p", "Hello {name} {surname}",
                   variables={"name": str, "surname": str}, version="1.0.1")
        d = diff_prompts(a, b)
        assert "surname" in d
