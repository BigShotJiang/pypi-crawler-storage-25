"""
promptsmith.prompt
------------------
Prompt class — typed variables, rendering, versioning, and serialization.
"""

import json
import re
from dataclasses import dataclass, field, asdict
from datetime import datetime
from typing import Any, Dict, List, Optional, Type


TYPE_MAP: Dict[str, type] = {
    "str": str, "int": int, "float": float,
    "bool": bool, "list": list, "dict": dict,
}
REVERSE_TYPE_MAP = {v: k for k, v in TYPE_MAP.items()}


class PromptRenderError(Exception):
    """Raised when a prompt cannot be rendered due to missing or invalid variables."""
    pass


@dataclass
class PromptVariable:
    """Describes a single variable in a prompt template."""
    name: str
    type_: type = str
    required: bool = True
    default: Any = None
    description: str = ""

    def cast(self, value: Any) -> Any:
        if isinstance(value, self.type_):
            return value
        try:
            return self.type_(value)
        except (ValueError, TypeError) as e:
            raise PromptRenderError(
                f"Variable '{self.name}' expected {self.type_.__name__}, "
                f"got {type(value).__name__}: {e}"
            )

    def to_dict(self) -> dict:
        return {
            "name": self.name,
            "type": REVERSE_TYPE_MAP.get(self.type_, "str"),
            "required": self.required,
            "default": self.default,
            "description": self.description,
        }

    @classmethod
    def from_dict(cls, d: dict) -> "PromptVariable":
        return cls(
            name=d["name"],
            type_=TYPE_MAP.get(d.get("type", "str"), str),
            required=d.get("required", True),
            default=d.get("default"),
            description=d.get("description", ""),
        )


class Prompt:
    """
    A versioned, typed prompt template.

    Parameters
    ----------
    name : str
        Unique prompt identifier.
    template : str
        Prompt text with {variable} placeholders.
    variables : dict, optional
        Mapping of variable name → type or PromptVariable.
        If None, inferred from template placeholders (all str).
    version : str
        Semantic version string. Default: "1.0.0".
    description : str
        Human-readable description.
    changelog : str
        What changed in this version.
    tags : list[str]
        Tags for grouping/filtering.
    system : str, optional
        Separate system prompt (for chat models).

    Example
    -------
    >>> p = Prompt(
    ...     name="summarizer",
    ...     template="Summarize this {content_type} in {max_words} words:\\n\\n{content}",
    ...     variables={"content_type": str, "max_words": int, "content": str},
    ...     version="1.0.0",
    ... )
    >>> text = p.render(content_type="article", max_words=100, content="...")
    """

    def __init__(
        self,
        name: str,
        template: str,
        variables: Optional[Dict[str, Any]] = None,
        version: str = "1.0.0",
        description: str = "",
        changelog: str = "Initial version",
        tags: Optional[List[str]] = None,
        system: Optional[str] = None,
        metadata: Optional[dict] = None,
    ):
        self.name = name
        self.template = template
        self.version = version
        self.description = description
        self.changelog = changelog
        self.tags = tags or []
        self.system = system
        self.metadata = metadata or {}
        self.created_at = datetime.now().isoformat()

        # Parse variables
        self.variables: Dict[str, PromptVariable] = {}
        inferred = self._infer_variables()

        if variables is None:
            for vname in inferred:
                self.variables[vname] = PromptVariable(name=vname)
        else:
            for vname, vtype in variables.items():
                if isinstance(vtype, PromptVariable):
                    self.variables[vname] = vtype
                else:
                    self.variables[vname] = PromptVariable(name=vname, type_=vtype)
            # Add any inferred but not declared (default to str)
            for vname in inferred:
                if vname not in self.variables:
                    self.variables[vname] = PromptVariable(name=vname)

    def _infer_variables(self) -> List[str]:
        """Extract {variable} names from the template."""
        return list(dict.fromkeys(re.findall(r"\{(\w+)\}", self.template)))

    def render(self, **kwargs) -> str:
        """
        Render the prompt by substituting variables.

        Raises PromptRenderError if required variables are missing or wrong type.

        Returns
        -------
        str — the rendered prompt text.
        """
        resolved = {}

        for vname, var in self.variables.items():
            if vname in kwargs:
                resolved[vname] = var.cast(kwargs[vname])
            elif not var.required and var.default is not None:
                resolved[vname] = var.default
            elif var.required:
                raise PromptRenderError(
                    f"Required variable '{vname}' not provided for prompt '{self.name}'"
                )

        # Check for extra kwargs not in template
        extra = set(kwargs) - set(self.variables)
        if extra:
            raise PromptRenderError(
                f"Unknown variables for prompt '{self.name}': {extra}"
            )

        try:
            return self.template.format(**resolved)
        except KeyError as e:
            raise PromptRenderError(f"Template variable {e} not found in variables")

    def render_messages(self, **kwargs) -> List[dict]:
        """
        Render as OpenAI-style messages list.

        Returns [{"role": "system", "content": ...}, {"role": "user", "content": ...}]
        """
        messages = []
        if self.system:
            messages.append({"role": "system", "content": self.system})
        messages.append({"role": "user", "content": self.render(**kwargs)})
        return messages

    def update(
        self,
        template: Optional[str] = None,
        variables: Optional[Dict[str, Any]] = None,
        description: Optional[str] = None,
        changelog: str = "",
        system: Optional[str] = None,
        tags: Optional[List[str]] = None,
        metadata: Optional[dict] = None,
    ) -> "Prompt":
        """
        Create a new version of this prompt with changes applied.

        Returns a new Prompt with auto-incremented patch version.
        """
        new_version = _bump_version(self.version)
        new = Prompt(
            name=self.name,
            template=template or self.template,
            variables=variables or {k: v.type_ for k, v in self.variables.items()},
            version=new_version,
            description=description or self.description,
            changelog=changelog or f"Updated from {self.version}",
            tags=tags if tags is not None else self.tags,
            system=system if system is not None else self.system,
            metadata=metadata if metadata is not None else self.metadata,
        )
        return new

    def validate(self, **kwargs) -> List[str]:
        """
        Validate kwargs against this prompt's variables without rendering.

        Returns list of error strings (empty = valid).
        """
        errors = []
        for vname, var in self.variables.items():
            if vname not in kwargs:
                if var.required:
                    errors.append(f"Missing required variable: '{vname}'")
            else:
                try:
                    var.cast(kwargs[vname])
                except PromptRenderError as e:
                    errors.append(str(e))
        return errors

    def to_dict(self) -> dict:
        return {
            "name": self.name,
            "version": self.version,
            "template": self.template,
            "system": self.system,
            "description": self.description,
            "changelog": self.changelog,
            "tags": self.tags,
            "metadata": self.metadata,
            "created_at": self.created_at,
            "variables": {k: v.to_dict() for k, v in self.variables.items()},
        }

    def to_json(self, indent: int = 2) -> str:
        return json.dumps(self.to_dict(), indent=indent)

    @classmethod
    def from_dict(cls, d: dict) -> "Prompt":
        variables = {
            k: PromptVariable.from_dict(v)
            for k, v in d.get("variables", {}).items()
        }
        p = cls(
            name=d["name"],
            template=d["template"],
            variables=variables,
            version=d.get("version", "1.0.0"),
            description=d.get("description", ""),
            changelog=d.get("changelog", ""),
            tags=d.get("tags", []),
            system=d.get("system"),
            metadata=d.get("metadata", {}),
        )
        p.created_at = d.get("created_at", p.created_at)
        return p

    @classmethod
    def from_json(cls, text: str) -> "Prompt":
        return cls.from_dict(json.loads(text))

    def __repr__(self):
        return f"<Prompt name={self.name!r} version={self.version!r} vars={list(self.variables)}>"


def _bump_version(version: str) -> str:
    """Bump the patch component of a semver string."""
    parts = version.split(".")
    if len(parts) == 3:
        try:
            parts[2] = str(int(parts[2]) + 1)
            return ".".join(parts)
        except ValueError:
            pass
    return version + ".1"
