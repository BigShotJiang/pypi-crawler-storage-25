"""
promptsmith.registry
--------------------
PromptRegistry — stores, versions, and retrieves prompts.
Backed by both file-based JSON (Git-friendly) and SQLite index.
"""

import json
import os
import sqlite3
import threading
from datetime import datetime
from pathlib import Path
from typing import Any, Callable, Dict, List, Optional, Tuple

from .prompt import Prompt
from .diff import diff_prompts


class PromptRegistry:
    """
    Central store for all prompts.

    Prompts are stored as JSON files (one per version, Git-friendly)
    and indexed in a SQLite database for fast querying.

    Parameters
    ----------
    path : str
        Directory to store prompts. Created if it doesn't exist.
    db_path : str, optional
        Path to SQLite index file. Defaults to <path>/promptsmith.db

    Example
    -------
    >>> registry = PromptRegistry("./prompts")
    >>> registry.save(my_prompt)
    >>> p = registry.load("summarizer")
    >>> p = registry.load("summarizer", version="1.0.0")
    """

    def __init__(self, path: str = "./prompts", db_path: Optional[str] = None):
        self.path = Path(path)
        self.path.mkdir(parents=True, exist_ok=True)
        db = db_path or str(self.path / "promptsmith.db")
        self._db = sqlite3.connect(db, check_same_thread=False)
        self._lock = threading.Lock()
        self._init_db()

    # ── DB ────────────────────────────────────────────────────────────────────

    def _init_db(self):
        with self._lock:
            self._db.executescript("""
                CREATE TABLE IF NOT EXISTS prompts (
                    name        TEXT NOT NULL,
                    version     TEXT NOT NULL,
                    description TEXT,
                    changelog   TEXT,
                    tags        TEXT,
                    file_path   TEXT NOT NULL,
                    created_at  TEXT NOT NULL,
                    PRIMARY KEY (name, version)
                );

                CREATE TABLE IF NOT EXISTS ab_results (
                    id          INTEGER PRIMARY KEY AUTOINCREMENT,
                    name        TEXT NOT NULL,
                    version_a   TEXT NOT NULL,
                    version_b   TEXT NOT NULL,
                    input_hash  TEXT,
                    score_a     REAL,
                    score_b     REAL,
                    winner      TEXT,
                    ran_at      TEXT NOT NULL
                );

                CREATE INDEX IF NOT EXISTS idx_prompts_name ON prompts(name);
            """)
            self._db.commit()

    def _index_prompt(self, prompt: Prompt, file_path: str):
        with self._lock:
            self._db.execute("""
                INSERT OR REPLACE INTO prompts
                (name, version, description, changelog, tags, file_path, created_at)
                VALUES (?, ?, ?, ?, ?, ?, ?)
            """, (
                prompt.name, prompt.version, prompt.description,
                prompt.changelog, ",".join(prompt.tags),
                file_path, prompt.created_at,
            ))
            self._db.commit()

    # ── File storage ──────────────────────────────────────────────────────────

    def _prompt_dir(self, name: str) -> Path:
        d = self.path / name
        d.mkdir(exist_ok=True)
        return d

    def _prompt_file(self, name: str, version: str) -> Path:
        return self._prompt_dir(name) / f"{version}.json"

    # ── Save / Load ───────────────────────────────────────────────────────────

    def save(self, prompt: Prompt) -> str:
        """
        Save a prompt to disk and index it in SQLite.

        Returns the file path where it was saved.
        """
        file_path = self._prompt_file(prompt.name, prompt.version)
        file_path.write_text(prompt.to_json(), encoding="utf-8")
        self._index_prompt(prompt, str(file_path))
        return str(file_path)

    def load(self, name: str, version: Optional[str] = None) -> Prompt:
        """
        Load a prompt by name and optional version.

        If version is None, loads the latest version.

        Raises FileNotFoundError if prompt not found.
        """
        if version is None:
            version = self._latest_version(name)
            if version is None:
                raise FileNotFoundError(f"No prompt found with name '{name}'")

        file_path = self._prompt_file(name, version)
        if not file_path.exists():
            raise FileNotFoundError(
                f"Prompt '{name}' version '{version}' not found at {file_path}"
            )
        return Prompt.from_json(file_path.read_text(encoding="utf-8"))

    def _latest_version(self, name: str) -> Optional[str]:
        """Return the latest version string for a prompt name."""
        with self._lock:
            row = self._db.execute(
                "SELECT version FROM prompts WHERE name = ? ORDER BY created_at DESC LIMIT 1",
                (name,)
            ).fetchone()
        return row[0] if row else None

    def delete(self, name: str, version: Optional[str] = None) -> int:
        """
        Delete a prompt version (or all versions if version=None).
        Returns number of versions deleted.
        """
        if version:
            versions = [version]
        else:
            versions = [r[0] for r in self._db.execute(
                "SELECT version FROM prompts WHERE name = ?", (name,)
            ).fetchall()]

        count = 0
        for v in versions:
            fp = self._prompt_file(name, v)
            if fp.exists():
                fp.unlink()
                count += 1
            with self._lock:
                self._db.execute(
                    "DELETE FROM prompts WHERE name = ? AND version = ?", (name, v)
                )
                self._db.commit()

        # Remove directory if empty
        prompt_dir = self._prompt_dir(name)
        if not any(prompt_dir.iterdir()):
            prompt_dir.rmdir()

        return count

    # ── Listing & search ──────────────────────────────────────────────────────

    def list(self, tag: Optional[str] = None) -> List[dict]:
        """List all prompts (optionally filtered by tag)."""
        query = "SELECT name, version, description, tags, created_at FROM prompts"
        params = []
        if tag:
            query += " WHERE tags LIKE ?"
            params.append(f"%{tag}%")
        query += " ORDER BY name, created_at"
        with self._lock:
            rows = self._db.execute(query, params).fetchall()
        return [
            {"name": r[0], "version": r[1], "description": r[2],
             "tags": r[3].split(",") if r[3] else [], "created_at": r[4]}
            for r in rows
        ]

    def history(self, name: str) -> List[dict]:
        """Return all versions of a prompt in chronological order."""
        with self._lock:
            rows = self._db.execute(
                "SELECT version, changelog, created_at FROM prompts "
                "WHERE name = ? ORDER BY created_at ASC",
                (name,)
            ).fetchall()
        return [{"version": r[0], "changelog": r[1], "created_at": r[2]} for r in rows]

    def names(self) -> List[str]:
        """Return all unique prompt names."""
        with self._lock:
            rows = self._db.execute(
                "SELECT DISTINCT name FROM prompts ORDER BY name"
            ).fetchall()
        return [r[0] for r in rows]

    # ── Diff ─────────────────────────────────────────────────────────────────

    def diff(
        self,
        name: str,
        version_a: str,
        version_b: str,
        context: int = 3,
    ) -> str:
        """
        Return a human-readable diff between two versions of a prompt.

        Example
        -------
        >>> print(registry.diff("summarizer", "1.0.0", "1.1.0"))
        """
        a = self.load(name, version_a)
        b = self.load(name, version_b)
        return diff_prompts(a, b, context=context)

    # ── A/B Testing ───────────────────────────────────────────────────────────

    def ab_test(
        self,
        name: str,
        version_a: str,
        version_b: str,
        inputs: Dict[str, Any],
        runner: Callable[[str], str],
        scorer: Optional[Callable[[str, str], float]] = None,
    ) -> "ABResult":
        """
        Run A/B test between two prompt versions.

        Parameters
        ----------
        name : str
            Prompt name.
        version_a, version_b : str
            Versions to compare.
        inputs : dict
            Variable values to render both prompts with.
        runner : callable
            Function that takes a rendered prompt string and returns LLM output.
        scorer : callable, optional
            Function(output_a, output_b) → float where positive = A wins.
            If None, returns both outputs for manual comparison.

        Returns
        -------
        ABResult with output_a, output_b, score, winner.
        """
        a = self.load(name, version_a)
        b = self.load(name, version_b)

        prompt_a = a.render(**inputs)
        prompt_b = b.render(**inputs)

        output_a = runner(prompt_a)
        output_b = runner(prompt_b)

        score = None
        winner = None
        if scorer:
            score = scorer(output_a, output_b)
            winner = version_a if score > 0 else version_b if score < 0 else "tie"

        result = ABResult(
            name=name,
            version_a=version_a,
            version_b=version_b,
            prompt_a=prompt_a,
            prompt_b=prompt_b,
            output_a=output_a,
            output_b=output_b,
            score=score,
            winner=winner,
        )

        # Persist result
        input_hash = str(hash(str(sorted(inputs.items()))))
        with self._lock:
            self._db.execute("""
                INSERT INTO ab_results
                (name, version_a, version_b, input_hash, score_a, score_b, winner, ran_at)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?)
            """, (
                name, version_a, version_b, input_hash,
                score if score and score > 0 else None,
                score if score and score < 0 else None,
                winner, datetime.now().isoformat(),
            ))
            self._db.commit()

        return result

    def ab_history(self, name: str) -> List[dict]:
        """Return past A/B test results for a prompt."""
        with self._lock:
            rows = self._db.execute(
                "SELECT version_a, version_b, score_a, score_b, winner, ran_at "
                "FROM ab_results WHERE name = ? ORDER BY ran_at DESC",
                (name,)
            ).fetchall()
        return [
            {"version_a": r[0], "version_b": r[1], "score_a": r[2],
             "score_b": r[3], "winner": r[4], "ran_at": r[5]}
            for r in rows
        ]

    # ── Export ────────────────────────────────────────────────────────────────

    def export_all(self, output_path: str):
        """Export all prompts to a single JSON file."""
        all_prompts = []
        for name in self.names():
            for entry in self.history(name):
                p = self.load(name, entry["version"])
                all_prompts.append(p.to_dict())
        with open(output_path, "w") as f:
            json.dump(all_prompts, f, indent=2)

    def print_summary(self):
        """Print a formatted table of all prompts."""
        entries = self.list()
        if not entries:
            print("  No prompts registered.")
            return
        print(f"\n{'Name':<25} {'Version':<10} {'Tags':<20} Created")
        print("─" * 75)
        seen = set()
        for e in entries:
            key = f"{e['name']}:{e['version']}"
            if key in seen:
                continue
            seen.add(key)
            tags = ", ".join(e["tags"]) if e["tags"] else "—"
            created = e["created_at"][:10]
            print(f"  {e['name']:<23} {e['version']:<10} {tags:<20} {created}")
        print()


class ABResult:
    """Result of an A/B prompt test."""

    def __init__(self, name, version_a, version_b, prompt_a, prompt_b,
                 output_a, output_b, score, winner):
        self.name = name
        self.version_a = version_a
        self.version_b = version_b
        self.prompt_a = prompt_a
        self.prompt_b = prompt_b
        self.output_a = output_a
        self.output_b = output_b
        self.score = score
        self.winner = winner

    def print_comparison(self):
        print(f"\n{'='*60}")
        print(f"  A/B Test: {self.name}  ({self.version_a} vs {self.version_b})")
        print(f"{'='*60}")
        print(f"\n── Prompt A ({self.version_a}) ──────────────────────────")
        print(self.prompt_a[:500])
        print(f"\n── Output A ────────────────────────────────────────────")
        print(self.output_a[:500])
        print(f"\n── Prompt B ({self.version_b}) ──────────────────────────")
        print(self.prompt_b[:500])
        print(f"\n── Output B ────────────────────────────────────────────")
        print(self.output_b[:500])
        if self.winner:
            print(f"\n  🏆 Winner: {self.winner}")
        print()

    def __repr__(self):
        return (
            f"<ABResult {self.name} {self.version_a} vs {self.version_b} "
            f"winner={self.winner!r}>"
        )
