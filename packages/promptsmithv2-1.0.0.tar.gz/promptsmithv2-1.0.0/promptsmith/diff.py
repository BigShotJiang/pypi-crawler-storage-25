"""
promptsmith.diff
----------------
Human-readable diffing between prompt versions.
"""

import difflib
from typing import List, TYPE_CHECKING

if TYPE_CHECKING:
    from .prompt import Prompt


def diff_prompts(a: "Prompt", b: "Prompt", context: int = 3) -> str:
    """
    Return a unified diff between two prompt versions.

    Parameters
    ----------
    a : Prompt
        The older / baseline prompt.
    b : Prompt
        The newer prompt.
    context : int
        Lines of context to show around changes.

    Returns
    -------
    str — unified diff string, empty if identical.
    """
    lines = []

    # Template diff
    template_diff = _text_diff(
        a.template, b.template,
        fromfile=f"template ({a.version})",
        tofile=f"template ({b.version})",
        context=context,
    )
    if template_diff:
        lines.append("── Template ─────────────────────────────────────────")
        lines.append(template_diff)

    # System prompt diff
    if a.system or b.system:
        system_diff = _text_diff(
            a.system or "", b.system or "",
            fromfile=f"system ({a.version})",
            tofile=f"system ({b.version})",
            context=context,
        )
        if system_diff:
            lines.append("── System ───────────────────────────────────────────")
            lines.append(system_diff)

    # Variable diff
    var_changes = _diff_variables(a, b)
    if var_changes:
        lines.append("── Variables ────────────────────────────────────────")
        lines.extend(var_changes)

    # Metadata
    lines.append("── Metadata ─────────────────────────────────────────")
    lines.append(f"  {a.version} → {b.version}")
    lines.append(f"  changelog: {b.changelog}")

    return "\n".join(lines) if lines else "(no changes)"


def _text_diff(old: str, new: str, fromfile: str, tofile: str, context: int) -> str:
    if old == new:
        return ""
    old_lines = old.splitlines(keepends=True)
    new_lines = new.splitlines(keepends=True)
    return "".join(difflib.unified_diff(
        old_lines, new_lines,
        fromfile=fromfile, tofile=tofile,
        n=context,
    ))


def _diff_variables(a: "Prompt", b: "Prompt") -> List[str]:
    lines = []
    all_keys = set(a.variables) | set(b.variables)
    for key in sorted(all_keys):
        if key not in a.variables:
            lines.append(f"  + added:   {key} ({b.variables[key].type_.__name__})")
        elif key not in b.variables:
            lines.append(f"  - removed: {key}")
        else:
            va, vb = a.variables[key], b.variables[key]
            if va.type_ != vb.type_:
                lines.append(
                    f"  ~ changed: {key} "
                    f"{va.type_.__name__} → {vb.type_.__name__}"
                )
    return lines
