"""
promptsmith — Structured prompt builder and version manager for LLM engineers.
Version control, typed variables, diffing, A/B testing, and audit trails.
"""

from .prompt import Prompt, PromptVariable, PromptRenderError
from .registry import PromptRegistry
from .diff import diff_prompts

__all__ = [
    "Prompt", "PromptVariable", "PromptRenderError",
    "PromptRegistry", "diff_prompts",
]
__version__ = "1.0.0"
__author__ = "prabhay759"
