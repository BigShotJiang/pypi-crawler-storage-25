from __future__ import annotations

import builtins

from anusara._contracts.agent import Agent
from anusara._contracts.agent_schema_descriptor import AgentSchemaDescriptor
from anusara._registry.errors import AgentNotFoundError
from anusara._registry.factory_builders import InstanceAgentFactory
from anusara._registry.loaders.resolution import resolve_registration_spec
from anusara._registry.registration_spec import AgentRegistrationSpec
from anusara._registry.resolved_definition import ResolvedAgentDefinition
from anusara._registry.sources.python_import_source import PythonImportAgentSource
from anusara._registry.validation import (
    validate_agent_id,
    validate_agent_instance,
    validate_agent_schema_descriptor,
)


class AgentRegistry:
    """
    Registry for managing resolved agent definitions.

    Provides deterministic mapping between stable agent identifiers and
    validated factory-backed runtime definitions used during execution.

    Behavior:
    - Strict mode (default): duplicate registrations raise KeyError
    - Non-strict mode: later registrations overwrite earlier ones

    Design principles:
    - Explicit registration only (no implicit discovery)
    - Deterministic lookup
    - Stable identifier-based resolution
    - Factory-backed runtime creation
    - Lightweight and side-effect free registry access
    """

    def __init__(self, strict: bool = True) -> None:
        """
        Args:
            strict:
                If True, duplicate registrations raise KeyError.
                If False, later registrations overwrite earlier ones.
        """
        self._agents: dict[str, ResolvedAgentDefinition] = {}
        self._strict = strict
        self._schema_cache: dict[str, AgentSchemaDescriptor | None] = {}

    # ---------------------------------------------------------
    # REGISTRATION
    # ---------------------------------------------------------

    def register(
        self,
        name: str,
        agent: Agent,
        *,
        replace: bool = False,
    ) -> None:
        """
        Backward-compatible registration API.

        Registers a concrete agent instance under an identifier by wrapping
        it in an InstanceAgentFactory and normalizing it into a
        ResolvedAgentDefinition.

        Args:
            name: Unique identifier for the agent
            agent: Agent implementation
            replace:
                If True, overwrite an existing registration for the same name.
                If False, preserve strict duplicate protection.

        Raises:
            ValueError: If identifier is invalid
            TypeError: If agent does not satisfy the Agent contract
            KeyError: If strict mode is enabled, identifier already exists,
                and replace is False
        """
        validate_agent_id(name)
        validate_agent_instance(agent, agent_id=name)

        definition = ResolvedAgentDefinition(
            agent_id=name,
            namespace=self._infer_namespace(name),
            version=None,
            is_builtin=False,
            source_kind="instance",
            source_ref=type(agent).__name__,
            factory=InstanceAgentFactory(agent=agent),
        )

        if replace and name in self._agents:
            self._store_definition(definition)
            return

        self.register_resolved_definition(definition)

    def register_external(
        self,
        name: str,
        module: str,
        symbol: str,
        *,
        namespace: str | None = None,
        version: str | None = None,
        is_builtin: bool = False,
        replace: bool = False,
    ) -> None:
        """
        Resolve and register an external Python agent class.

        Args:
            name: Registry identifier to store the agent under
            module: Python module path
            symbol: Agent class symbol within the module
            replace: If True, overwrite an existing registration

        Raises:
            ValueError: If inputs are invalid
            ImportError: If module import fails
            AttributeError: If symbol is missing
            TypeError: If symbol is not a supported Agent class
            KeyError: If strict mode is enabled and replace is False
        """
        spec = AgentRegistrationSpec(
            agent_id=name,
            namespace=(
                namespace if namespace is not None else self._infer_namespace(name)
            ),
            version=version,
            is_builtin=is_builtin,
            source=PythonImportAgentSource(
                module=module,
                symbol=symbol,
            ),
        )

        definition = resolve_registration_spec(spec)

        if definition.agent_id in self._agents:
            existing = self._agents[definition.agent_id]

            if self._definitions_match(definition, existing):
                return

            if replace:
                self._store_definition(definition)
                return

        self.register_resolved_definition(definition)

    def register_resolved_definition(self, definition: ResolvedAgentDefinition) -> None:
        if self._strict and definition.agent_id in self._agents:
            raise KeyError(f"Agent '{definition.agent_id}' is already registered.")

        self._store_definition(definition)

    # ---------------------------------------------------------
    # LOOKUP / RESOLUTION
    # ---------------------------------------------------------

    def get(self, name: str) -> Agent:
        """
        Resolve and create an agent instance for the given identifier.

        Args:
            name: Agent identifier

        Returns:
            Agent instance created through the registered factory

        Raises:
            AgentNotFoundError: If agent is not registered
            TypeError: If the created object does not satisfy the Agent contract
        """
        definition = self.get_definition(name)
        agent = definition.factory.create()
        validate_agent_instance(agent, agent_id=name)
        return agent

    def get_definition(self, agent_id: str) -> ResolvedAgentDefinition:
        """
        Retrieve a full resolved agent definition.

        Args:
            agent_id: Agent identifier

        Returns:
            ResolvedAgentDefinition

        Raises:
            AgentNotFoundError: If agent is not registered
        """
        try:
            return self._agents[agent_id]
        except KeyError as exc:
            raise AgentNotFoundError(agent_id) from exc

    # ---------------------------------------------------------
    # LIFECYCLE
    # ---------------------------------------------------------

    def unregister(self, name: str) -> None:
        if name not in self._agents:
            raise AgentNotFoundError(name)

        del self._agents[name]
        self._schema_cache.pop(name, None)

    def exists(self, name: str) -> bool:
        """Check if an agent is registered."""
        return name in self._agents

    def clear(self) -> None:
        self._agents.clear()
        self._schema_cache.clear()

    def reset(self) -> None:
        """Reset the registry to an empty state."""
        self.clear()

    # ---------------------------------------------------------
    # COLLECTION HELPERS
    # ---------------------------------------------------------

    def __contains__(self, name: str) -> bool:
        return name in self._agents

    def __len__(self) -> int:
        return len(self._agents)

    def list(self) -> list[str]:
        """List registered agent identifiers."""
        return list(self._agents.keys())

    def list_definitions(self) -> builtins.list[ResolvedAgentDefinition]:
        """List full resolved agent definitions."""
        return list(self._agents.values())

    # ---------------------------------------------------------
    # METADATA
    # ---------------------------------------------------------

    def metadata(self, name: str) -> dict[str, str]:
        """
        Return metadata for a registered agent.

        Raises:
            AgentNotFoundError: If agent is not registered
        """
        definition = self.get_definition(name)

        return {
            "agent_id": definition.agent_id,
            "namespace": definition.namespace or "",
            "version": definition.version or "",
            "is_builtin": str(definition.is_builtin),
            "source_kind": definition.source_kind,
            "source_ref": definition.source_ref,
            "factory_type": type(definition.factory).__name__,
        }

    # ---------------------------------------------------------
    # INTERNALS
    # ---------------------------------------------------------

    def _infer_namespace(self, agent_id: str) -> str | None:
        if "." not in agent_id:
            return None

        namespace, _ = agent_id.split(".", 1)
        return namespace or None

    def register_spec(self, spec: AgentRegistrationSpec) -> None:
        """
        Resolve and register an agent from an explicit registration spec.

        Args:
            spec: Durable registration input describing how to resolve the agent

        Raises:
            ValueError: If spec fields are invalid
            ImportError: If module import fails
            AttributeError: If symbol is missing
            TypeError: If resolved symbol is not a supported Agent class
            KeyError: If strict mode is enabled and agent_id already exists
        """
        definition = resolve_registration_spec(spec)
        self.register_resolved_definition(definition)

    def _definitions_match(
        self,
        left: ResolvedAgentDefinition,
        right: ResolvedAgentDefinition,
    ) -> bool:
        return (
            left.agent_id == right.agent_id
            and left.namespace == right.namespace
            and left.version == right.version
            and left.is_builtin == right.is_builtin
            and left.source_kind == right.source_kind
            and left.source_ref == right.source_ref
            and type(left.factory).__name__ == type(right.factory).__name__
        )

    def _build_schema_cache_entry(
        self,
        definition: ResolvedAgentDefinition,
    ) -> AgentSchemaDescriptor | None:
        agent = definition.factory.create()
        validate_agent_instance(agent, agent_id=definition.agent_id)
        return validate_agent_schema_descriptor(agent, agent_id=definition.agent_id)

    def _store_definition(
        self,
        definition: ResolvedAgentDefinition,
    ) -> None:
        descriptor = self._validate_and_build_schema_cache_entry(definition)
        self._agents[definition.agent_id] = definition
        self._schema_cache[definition.agent_id] = descriptor

    def get_schema_descriptor(
        self,
        agent_id: str,
    ) -> AgentSchemaDescriptor | None:
        self.get_definition(agent_id)  # preserves not-found behavior
        return self._schema_cache.get(agent_id)

    def get_cached_capabilities(
        self,
        agent_id: str,
    ) -> builtins.list[str]:
        descriptor = self.get_schema_descriptor(agent_id)
        return list(descriptor.capabilities) if descriptor is not None else []

    def get_cached_description(
        self,
        agent_id: str,
    ) -> str | None:
        descriptor = self.get_schema_descriptor(agent_id)
        return descriptor.description if descriptor is not None else None

    def _validate_and_build_schema_cache_entry(
        self,
        definition: ResolvedAgentDefinition,
    ) -> AgentSchemaDescriptor | None:
        validate_agent_id(definition.agent_id)

        if definition.namespace is not None:
            if not isinstance(definition.namespace, str) or not definition.namespace:
                raise ValueError("namespace must be a non-empty string when provided.")

        if definition.version is not None:
            if not isinstance(definition.version, str) or not definition.version:
                raise ValueError("version must be a non-empty string when provided.")

        if not isinstance(definition.source_kind, str) or not definition.source_kind:
            raise ValueError("source_kind must be a non-empty string.")

        if not isinstance(definition.source_ref, str):
            raise ValueError("source_ref must be a string.")

        agent = definition.factory.create()
        validate_agent_instance(agent, agent_id=definition.agent_id)
        return validate_agent_schema_descriptor(agent, agent_id=definition.agent_id)
