from __future__ import annotations

from typing import cast

from anusara._contracts.agent_schema_descriptor import AgentSchemaDescriptor
from anusara._registry.resolved_definition import ResolvedAgentDefinition
from anusara.adapters.http.schemas import (
    AgentSchemaDescriptorSchema,
    RegisteredAgentSchema,
    RegisteredAgentsData,
)


def _descriptor_fields(
    descriptor: AgentSchemaDescriptor | None,
) -> tuple[str | None, dict[str, object] | None, dict[str, object] | None, list[str]]:
    if descriptor is None:
        return None, None, None, []

    return (
        descriptor.description,
        cast(dict[str, object] | None, descriptor.input_schema),
        cast(dict[str, object] | None, descriptor.output_schema),
        list(descriptor.capabilities),
    )


def to_agent_schema_descriptor_schema(
    definition: ResolvedAgentDefinition,
    descriptor: AgentSchemaDescriptor | None,
) -> AgentSchemaDescriptorSchema:
    description, input_schema, output_schema, capabilities = _descriptor_fields(
        descriptor
    )

    return AgentSchemaDescriptorSchema(
        agent_id=definition.agent_id,
        version=definition.version,
        description=description,
        input_schema=input_schema,
        output_schema=output_schema,
        capabilities=capabilities,
    )


def to_registered_agent_schema(
    definition: ResolvedAgentDefinition,
    descriptor: AgentSchemaDescriptor | None,
) -> RegisteredAgentSchema:
    description, _, _, capabilities = _descriptor_fields(descriptor)

    return RegisteredAgentSchema(
        agent_id=definition.agent_id,
        namespace=definition.namespace,
        version=definition.version,
        is_builtin=definition.is_builtin,
        source_kind=definition.source_kind,
        source_ref=definition.source_ref,
        factory_type=type(definition.factory).__name__,
        description=description,
        capabilities=capabilities,
    )


def to_registered_agents_data(
    definitions: list[ResolvedAgentDefinition],
    descriptors: dict[str, AgentSchemaDescriptor | None],
) -> RegisteredAgentsData:
    return RegisteredAgentsData(
        registered=[
            to_registered_agent_schema(d, descriptors.get(d.agent_id))
            for d in definitions
        ]
    )
