from __future__ import annotations

from anusara._builtin.agents.echo_agent import EchoAgent
from anusara._builtin.agents.hello_agent import HelloAgent
from anusara._registry.factory_builders import ClassAgentFactory
from anusara._registry.resolved_definition import ResolvedAgentDefinition


def _definition_sort_key(definition: ResolvedAgentDefinition) -> str:
    return definition.agent_id


def builtin_agent_definitions() -> list[ResolvedAgentDefinition]:
    definitions = [
        ResolvedAgentDefinition(
            agent_id="core.hello",
            factory=ClassAgentFactory(agent_cls=HelloAgent),
            namespace="core",
            version=None,
            is_builtin=True,
            source_kind="class",
            source_ref="anusara._builtin.agents.hello_agent:HelloAgent",
        ),
        ResolvedAgentDefinition(
            agent_id="core.echo",
            factory=ClassAgentFactory(agent_cls=EchoAgent),
            namespace="core",
            version=None,
            is_builtin=True,
            source_kind="class",
            source_ref="anusara._builtin.agents.echo_agent:EchoAgent",
        ),
    ]

    definitions.sort(key=_definition_sort_key)
    return definitions
