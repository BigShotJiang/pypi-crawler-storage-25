"""cagecore config — tek doğruluk kaynağı.

Öncelik sırası (yüksekten düşüğe):
  1. Env var:  CAGECORE_ENDPOINT, CAGECORE_MODEL_NEEDLE, CAGECORE_WHITELIST
  2. Dosya:    ~/.config/cagecore/config.toml (veya $XDG_CONFIG_HOME/cagecore/config.toml)
  3. Autodetect: recon'daki LM Studio/Ollama adayları probe edilir, alive olanlar
     endpoint + whitelist'e eklenir
  4. Hardcoded default: whitelist = ["127.0.0.0/8"], endpoint = None, needle = ""

Modüller bu sıradan Config alıp karar verir. Hardcoded IP/port yok.
"""
from __future__ import annotations

import os
import re
from dataclasses import dataclass, field, asdict
from pathlib import Path
from typing import Any, Dict, List, Optional


CONFIG_ENV_ENDPOINT = "CAGECORE_ENDPOINT"            # "host:port" veya "http://host:port"
CONFIG_ENV_NEEDLE = "CAGECORE_MODEL_NEEDLE"          # substring, ","-ayrılmış çoklu
CONFIG_ENV_WHITELIST = "CAGECORE_WHITELIST"          # "host:port,host:port,..." veya CIDR[:port]
CONFIG_FILE_ENV = "CAGECORE_CONFIG"                  # özel config yol override

DEFAULT_WHITELIST_ENTRIES: List[str] = ["127.0.0.0/8"]

# Autodetect probe portları — sadece candidate listesi için, whitelist DEĞİL
STANDARD_LMSTUDIO_PORT = 1234
STANDARD_OLLAMA_PORT = 11434


def config_dir() -> Path:
    """XDG_CONFIG_HOME/cagecore veya ~/.config/cagecore."""
    base = os.environ.get("XDG_CONFIG_HOME")
    if base:
        return Path(base) / "cagecore"
    return Path.home() / ".config" / "cagecore"


def config_path() -> Path:
    override = os.environ.get(CONFIG_FILE_ENV)
    if override:
        return Path(override)
    return config_dir() / "config.toml"


@dataclass
class Config:
    endpoint_url: Optional[str] = None            # e.g. "http://127.0.0.1:11434"
    model_needle: str = ""                         # substring (case-insensitive)
    whitelist_entries: List[str] = field(default_factory=list)
    tools_enabled: bool = False                    # opencode provider tools: true/false
    source: str = "default"                        # "default"|"file"|"env"|"autodetect" (son yazan)
    source_chain: List[str] = field(default_factory=list)

    def hostport(self) -> Optional[str]:
        if not self.endpoint_url:
            return None
        m = re.match(r"^https?://([^/]+)(/|$)", self.endpoint_url)
        return m.group(1) if m else None


# ---------- File loader (minimal TOML) ----------

def _parse_minimal_toml(text: str) -> Dict[str, Any]:
    """3.10 uyumlu minimal TOML parser.

    Desteklenen: [section], key = "string", key = true|false, key = [list of strings].
    Yorumlar '#' ile. tomllib varsa (3.11+) o kullanılır.
    """
    try:
        import tomllib  # type: ignore[import-not-found]
        return tomllib.loads(text)
    except ImportError:
        pass
    # elle parse
    out: Dict[str, Any] = {}
    section_name = ""
    current: Dict[str, Any] = out
    for raw in text.splitlines():
        line = raw.strip()
        if not line or line.startswith("#"):
            continue
        if line.startswith("[") and line.endswith("]"):
            section_name = line[1:-1].strip()
            out.setdefault(section_name, {})
            current = out[section_name]
            continue
        if "=" not in line:
            continue
        k, v = line.split("=", 1)
        k = k.strip()
        v = v.strip()
        # string
        if v.startswith('"') and v.endswith('"'):
            current[k] = v[1:-1]
        # bool
        elif v in ("true", "True"):
            current[k] = True
        elif v in ("false", "False"):
            current[k] = False
        # list of strings: [ "a", "b" ]
        elif v.startswith("[") and v.endswith("]"):
            inner = v[1:-1].strip()
            items: List[str] = []
            for tok in re.findall(r'"([^"]*)"', inner):
                items.append(tok)
            current[k] = items
        else:
            # naked number / unknown — int denemesi
            try:
                current[k] = int(v)
            except ValueError:
                current[k] = v
    return out


def _from_file(path: Path) -> Optional[Dict[str, Any]]:
    if not path.is_file():
        return None
    try:
        text = path.read_text(encoding="utf-8")
        return _parse_minimal_toml(text)
    except (OSError, ValueError):
        return None


def _apply_file_data(cfg: Config, data: Dict[str, Any]) -> None:
    ep = data.get("endpoint", {}) or {}
    wl = data.get("whitelist", {}) or {}
    if isinstance(ep, dict):
        url = ep.get("url")
        if isinstance(url, str) and url:
            cfg.endpoint_url = url
        needle = ep.get("model_needle")
        if isinstance(needle, str) and needle:
            cfg.model_needle = needle
        tools = ep.get("tools_enabled")
        if isinstance(tools, bool):
            cfg.tools_enabled = tools
    if isinstance(wl, dict):
        allow = wl.get("allow")
        if isinstance(allow, list):
            cfg.whitelist_entries = [str(x) for x in allow if x]


# ---------- Env loader ----------

def _apply_env(cfg: Config) -> bool:
    """Returns True if any env var was applied."""
    applied = False
    ep = os.environ.get(CONFIG_ENV_ENDPOINT, "").strip()
    if ep:
        if not ep.startswith("http"):
            ep = "http://" + ep
        cfg.endpoint_url = ep
        applied = True
    needle = os.environ.get(CONFIG_ENV_NEEDLE, "").strip()
    if needle:
        cfg.model_needle = needle
        applied = True
    wl = os.environ.get(CONFIG_ENV_WHITELIST, "").strip()
    if wl:
        cfg.whitelist_entries = [t.strip() for t in wl.split(",") if t.strip()]
        applied = True
    tools_env = os.environ.get("CAGECORE_TOOLS_ENABLED", "").strip().lower()
    if tools_env in ("1", "true", "yes"):
        cfg.tools_enabled = True
        applied = True
    elif tools_env in ("0", "false", "no"):
        cfg.tools_enabled = False
        applied = True
    return applied


# ---------- Autodetect ----------

def _autodetect(cfg: Config) -> bool:
    """LM Studio + Ollama adayları probe et, alive olanları ekle.

    Returns True if any endpoint was discovered.
    """
    # Import geç (circular import önlemi)
    from . import lmstudio as _lm

    cands = _lm.candidate_endpoints()
    alive_probes = []
    for u in cands:
        r = _lm.probe_endpoint(u, timeout=2.0)
        if r.alive:
            alive_probes.append(r)
    if not alive_probes:
        return False

    # İlk alive'ı endpoint olarak seç
    if not cfg.endpoint_url:
        first = alive_probes[0]
        # URL'den /v1/models'i kırp, base URL olarak kaydet
        base = first.url
        if base.endswith("/v1/models"):
            base = base[: -len("/v1/models")]
        cfg.endpoint_url = base

    # Whitelist'e tüm alive host:port'ları ekle
    for p in alive_probes:
        m = re.match(r"^https?://([^:/]+)(?::(\d+))?", p.url)
        if not m:
            continue
        host, port = m.group(1), m.group(2) or "80"
        entry = f"{host}:{port}"
        if entry not in cfg.whitelist_entries:
            cfg.whitelist_entries.append(entry)
    return True


# ---------- Merge + resolve ----------

def resolve(autodetect: bool = True) -> Config:
    """Config'i sırasıyla yükle ve döndür. Hiçbir exception caller'a sızmaz."""
    cfg = Config()
    cfg.whitelist_entries = list(DEFAULT_WHITELIST_ENTRIES)
    cfg.source_chain.append("default")

    # 2. File
    try:
        data = _from_file(config_path())
        if data:
            _apply_file_data(cfg, data)
            cfg.source = "file"
            cfg.source_chain.append("file")
    except Exception:
        pass

    # 1. Env (overrides file)
    if _apply_env(cfg):
        cfg.source = "env"
        cfg.source_chain.append("env")

    # 3. Autodetect — yalnızca env ve file yoksa (explicit kaynaklar baskın)
    explicit = "env" in cfg.source_chain or "file" in cfg.source_chain
    if autodetect and not explicit:
        try:
            if _autodetect(cfg):
                cfg.source = "autodetect"
                cfg.source_chain.append("autodetect")
        except Exception:
            pass

    return cfg


# ---------- Save (for --save-config) ----------

def save(cfg: Config, path: Optional[Path] = None) -> Path:
    """Config'i TOML olarak diske yaz. Kullanıcının home'una."""
    if path is None:
        path = config_path()
    path.parent.mkdir(parents=True, exist_ok=True)
    lines = [
        "# cagecore config — written by `cagecore recon --save-config`",
        "# Priority: env vars > this file > autodetect > default",
        "",
        "[endpoint]",
    ]
    if cfg.endpoint_url:
        lines.append(f'url = "{cfg.endpoint_url}"')
    if cfg.model_needle:
        lines.append(f'model_needle = "{cfg.model_needle}"')
    # tools_enabled her zaman yaz (default false)
    lines.append(f'tools_enabled = {"true" if cfg.tools_enabled else "false"}')
    lines.append("")
    lines.append("[whitelist]")
    if cfg.whitelist_entries:
        allow_str = ", ".join(f'"{e}"' for e in cfg.whitelist_entries)
        lines.append(f"allow = [{allow_str}]")
    else:
        lines.append("allow = []")
    lines.append("")
    path.write_text("\n".join(lines), encoding="utf-8")
    return path


def as_dict(cfg: Config) -> Dict[str, Any]:
    return {
        "endpoint_url": cfg.endpoint_url,
        "model_needle": cfg.model_needle,
        "whitelist_entries": cfg.whitelist_entries,
        "tools_enabled": cfg.tools_enabled,
        "source": cfg.source,
        "source_chain": cfg.source_chain,
    }
