#!/usr/bin/env python3
"""Whitelist HTTP/HTTPS proxy for opencode offline mode.

Only CONNECT requests to whitelisted host:port pairs are tunneled.
Plain HTTP requests matching the whitelist are forwarded; everything
else returns 403 Forbidden and is logged to deny.log.

Stdlib only. Run as: python3 deny_proxy.py [--host 127.0.0.1] [--port 9876]
"""
from __future__ import annotations

import argparse
import logging
import os
import select
import socket
import socketserver
import sys
import threading
import time
from http.server import BaseHTTPRequestHandler
from pathlib import Path
from urllib.parse import urlsplit

WHITELIST_ENV = "CAGECORE_WHITELIST"
DEFAULT_WHITELIST = [
    ("127.0.0.1", 0),
    ("localhost", 0),
    ("::1", 0),
]


def parse_whitelist(raw: str | None) -> list[tuple[str, int]]:
    if not raw:
        return list(DEFAULT_WHITELIST)
    out: list[tuple[str, int]] = []
    for entry in raw.split(","):
        entry = entry.strip()
        if not entry:
            continue
        if ":" in entry:
            host, port_s = entry.rsplit(":", 1)
            port = int(port_s) if port_s and port_s != "*" else 0
        else:
            host, port = entry, 0
        out.append((host, port))
    return out


def is_allowed(host: str, port: int, whitelist: list[tuple[str, int]]) -> bool:
    host_lc = host.lower()
    for whost, wport in whitelist:
        if whost.lower() != host_lc:
            continue
        if wport == 0 or wport == port:
            return True
    return False


class DenyProxyHandler(BaseHTTPRequestHandler):
    whitelist: list[tuple[str, int]] = []
    deny_log: Path | None = None
    timeout = 30

    def log_message(self, fmt, *args):
        logging.info("%s - %s", self.address_string(), fmt % args)

    def _log_deny(self, verb: str, target: str, reason: str):
        line = f"{time.strftime('%Y-%m-%dT%H:%M:%S')} DENY {verb} {target} ({reason})\n"
        logging.warning(line.rstrip())
        if self.deny_log:
            try:
                with self.deny_log.open("a", encoding="utf-8") as f:
                    f.write(line)
            except OSError:
                pass

    def _send_forbidden(self, body: str):
        data = body.encode("utf-8")
        self.send_response(403)
        self.send_header("Content-Type", "text/plain; charset=utf-8")
        self.send_header("Content-Length", str(len(data)))
        self.send_header("Connection", "close")
        self.end_headers()
        try:
            self.wfile.write(data)
        except OSError:
            pass

    def do_CONNECT(self):  # noqa: N802 — stdlib name
        try:
            host, port_s = self.path.rsplit(":", 1)
            port = int(port_s)
        except ValueError:
            self._log_deny("CONNECT", self.path, "malformed")
            self._send_forbidden("offline mode: malformed CONNECT target\n")
            return

        if not is_allowed(host, port, self.whitelist):
            self._log_deny("CONNECT", f"{host}:{port}", "not whitelisted")
            self._send_forbidden(
                f"offline mode: {host}:{port} is not in whitelist\n"
            )
            return

        try:
            upstream = socket.create_connection((host, port), timeout=self.timeout)
        except OSError as e:
            self._log_deny("CONNECT", f"{host}:{port}", f"upstream error: {e}")
            self._send_forbidden(f"offline mode: cannot reach {host}:{port}: {e}\n")
            return

        self.send_response(200, "Connection Established")
        self.end_headers()
        self._tunnel(self.connection, upstream)

    def _handle_plain(self, method: str):
        target = self.path
        path_only = target
        if target.startswith("http://") or target.startswith("https://"):
            parts = urlsplit(target)
            host = parts.hostname or ""
            port = parts.port or (443 if parts.scheme == "https" else 80)
            path_only = parts.path or "/"
            if parts.query:
                path_only += "?" + parts.query
        else:
            host_hdr = self.headers.get("Host", "")
            if ":" in host_hdr:
                host, port_s = host_hdr.rsplit(":", 1)
                try:
                    port = int(port_s)
                except ValueError:
                    port = 80
            else:
                host, port = host_hdr, 80

        if not host or not is_allowed(host, port, self.whitelist):
            self._log_deny(method, f"{host}:{port}{self.path}", "not whitelisted")
            self._send_forbidden(
                f"offline mode: {method} {host}:{port} blocked\n"
            )
            return

        self._log_deny(method, f"{host}:{port}{self.path}", "allowed passthrough")
        try:
            upstream = socket.create_connection((host, port), timeout=self.timeout)
        except OSError as e:
            self._send_forbidden(f"offline mode: upstream error: {e}\n")
            return

        # HTTP/1.1 CRLF zorunlu — self.headers bytes LF veriyor, elle inşa et
        header_lines = [f"{method} {path_only} {self.request_version}"]
        for key, value in self.headers.items():
            if key.lower() in {"proxy-connection", "proxy-authorization"}:
                continue
            header_lines.append(f"{key}: {value}")
        header_blob = ("\r\n".join(header_lines) + "\r\n\r\n").encode("iso-8859-1")
        upstream.sendall(header_blob)
        content_length = int(self.headers.get("Content-Length", "0") or 0)
        if content_length:
            upstream.sendall(self.rfile.read(content_length))
        self._tunnel(self.connection, upstream, half_close=True)

    def do_GET(self):  # noqa: N802
        self._handle_plain("GET")

    def do_POST(self):  # noqa: N802
        self._handle_plain("POST")

    def do_PUT(self):  # noqa: N802
        self._handle_plain("PUT")

    def do_DELETE(self):  # noqa: N802
        self._handle_plain("DELETE")

    def do_HEAD(self):  # noqa: N802
        self._handle_plain("HEAD")

    def do_PATCH(self):  # noqa: N802
        self._handle_plain("PATCH")

    @staticmethod
    def _tunnel(client: socket.socket, upstream: socket.socket, half_close: bool = False):
        client.setblocking(False)
        upstream.setblocking(False)
        socks = [client, upstream]
        try:
            while True:
                readable, _, errored = select.select(socks, [], socks, 10)
                if errored:
                    break
                if not readable:
                    break
                for s in readable:
                    try:
                        data = s.recv(65536)
                    except BlockingIOError:
                        continue
                    except OSError:
                        return
                    if not data:
                        return
                    out = upstream if s is client else client
                    try:
                        out.sendall(data)
                    except OSError:
                        return
        finally:
            try:
                upstream.shutdown(socket.SHUT_RDWR)
            except OSError:
                pass
            upstream.close()


class ThreadingHTTPServer(socketserver.ThreadingMixIn, socketserver.TCPServer):
    daemon_threads = True
    allow_reuse_address = True


def build_server(host: str, port: int, whitelist: list[tuple[str, int]], deny_log: Path | None) -> ThreadingHTTPServer:
    handler = type(
        "Handler",
        (DenyProxyHandler,),
        {"whitelist": whitelist, "deny_log": deny_log},
    )
    return ThreadingHTTPServer((host, port), handler)


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--host", default="127.0.0.1")
    ap.add_argument("--port", type=int, default=9876)
    ap.add_argument("--log", default=None, help="deny log path")
    ap.add_argument("--whitelist", default=os.environ.get(WHITELIST_ENV))
    ap.add_argument("--quiet", action="store_true")
    args = ap.parse_args()

    level = logging.WARNING if args.quiet else logging.INFO
    logging.basicConfig(level=level, format="%(asctime)s %(levelname)s %(message)s")

    whitelist = parse_whitelist(args.whitelist)
    deny_log = Path(args.log) if args.log else None
    if deny_log:
        deny_log.parent.mkdir(parents=True, exist_ok=True)

    server = build_server(args.host, args.port, whitelist, deny_log)
    host, port = server.server_address[:2]
    logging.info("deny-proxy listening on %s:%s", host, port)
    logging.info("whitelist: %s", whitelist)

    def shutdown(*_):
        logging.info("shutting down")
        t = threading.Thread(target=server.shutdown, daemon=True)
        t.start()

    import signal
    signal.signal(signal.SIGINT, shutdown)
    signal.signal(signal.SIGTERM, shutdown)

    try:
        server.serve_forever()
    finally:
        server.server_close()
    return 0


if __name__ == "__main__":
    sys.exit(main())
