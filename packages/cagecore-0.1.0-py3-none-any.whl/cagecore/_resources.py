"""Pakete gömülü data/ ve shell/ dosyalarına erişim.

Çalışma modları:
  1. pip install (dosya sistemine açılmış) — Path(__file__).parent kullanılır
  2. zipapp (.pyz) — dosyalar zip içinde, first-access'te tempdir'e extract edilir
     ve sonraki çağrılarda cache'den okunur.

Python 3.8+ uyumlu. Yalnızca stdlib.
"""
from __future__ import annotations

import atexit
import shutil
import tempfile
import zipfile
from pathlib import Path
from typing import Optional


_EXTRACTED_ROOT: Optional[Path] = None


def _pkg_dir_on_fs() -> Path:
    return Path(__file__).resolve().parent


def _in_zipapp() -> bool:
    p = _pkg_dir_on_fs()
    # zipapp içindeyse __file__ /path/to/archive.pyz/cagecore/_resources.py gibi
    return not p.is_dir()


def _zip_archive_path() -> Path:
    """zipapp mode'da ana arşivi bul."""
    p = _pkg_dir_on_fs()
    # p = .../archive.pyz/cagecore
    for parent in [p, *p.parents]:
        if parent.name.endswith(".pyz") or (
            parent.is_file() and zipfile.is_zipfile(parent)
        ):
            return parent
        if parent == parent.parent:
            break
    # Son çare: parent'ın parent'ı
    raise RuntimeError(f"zipapp arşivi bulunamadı: {_pkg_dir_on_fs()}")


def _ensure_extracted() -> Path:
    """Zipapp içindeyse data/ ve shell/'i bir kez temp'e extract et; Path döndür."""
    global _EXTRACTED_ROOT
    if _EXTRACTED_ROOT is not None:
        return _EXTRACTED_ROOT
    if not _in_zipapp():
        _EXTRACTED_ROOT = _pkg_dir_on_fs()
        return _EXTRACTED_ROOT

    archive = _zip_archive_path()
    tmpdir = Path(tempfile.mkdtemp(prefix="cagecore_"))
    with zipfile.ZipFile(archive, "r") as zf:
        for name in zf.namelist():
            if name.startswith("cagecore/data/") or name.startswith("cagecore/shell/"):
                zf.extract(name, tmpdir)
    # executable bit for shell
    for sh in (tmpdir / "cagecore" / "shell").glob("*.sh"):
        sh.chmod(0o755)
    _EXTRACTED_ROOT = tmpdir / "cagecore"
    atexit.register(lambda: shutil.rmtree(tmpdir, ignore_errors=True))
    return _EXTRACTED_ROOT


def data_path(name: str) -> Path:
    root = _ensure_extracted()
    p = root / "data" / name
    if not p.exists():
        raise FileNotFoundError(f"data resource yok: {p}")
    return p


def shell_path(name: str) -> Path:
    root = _ensure_extracted()
    p = root / "shell" / name
    if not p.exists():
        raise FileNotFoundError(f"shell resource yok: {p}")
    return p


def read_data(name: str) -> str:
    return data_path(name).read_text(encoding="utf-8")


def whitelist_default() -> str:
    lines = []
    for line in read_data("whitelist.default.txt").splitlines():
        line = line.strip()
        if not line or line.startswith("#"):
            continue
        lines.append(line)
    return ",".join(lines)
