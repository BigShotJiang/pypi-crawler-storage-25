"""Paket smoke testi — kurulumdan sonra çalışır."""
from __future__ import annotations

import json
import os
import tempfile
import unittest
from pathlib import Path
from unittest import mock

from cagecore import _resources, config as cfg_mod, env_flags, lmstudio, pcap, deny_proxy


class SmokeTests(unittest.TestCase):
    def test_whitelist_resource(self):
        wl = _resources.whitelist_default()
        # Default içinde sadece loopback olmalı; kullanıcı kendi IP'sini config ile ekler
        self.assertIn("127.0.0.0/8", wl)

    def test_models_json_resource(self):
        text = _resources.read_data("models.json")
        data = json.loads(text)
        # Jenerik placeholder yapısını doğrula
        self.assertIn("local", data)
        self.assertIn("models", data["local"])

    def test_env_flags_complete(self):
        flags = env_flags.offline_flags()
        for req in env_flags.REQUIRED_FLAGS:
            self.assertIn(req, flags)

    def test_pcap_parse_whitelist(self):
        # Test-only RFC5737 TEST-NET-2 IP
        any_p, spec = pcap.parse_whitelist("127.0.0.0/8,198.51.100.10:1234")
        self.assertTrue(pcap.is_allowed("127.0.0.1", 9, any_p, spec))
        self.assertTrue(pcap.is_allowed("198.51.100.10", 1234, any_p, spec))
        self.assertFalse(pcap.is_allowed("8.8.8.8", 443, any_p, spec))

    def test_deny_proxy_parse_whitelist(self):
        wl = deny_proxy.parse_whitelist("a.com:443,10.0.0.1")
        self.assertIn(("a.com", 443), wl)
        self.assertIn(("10.0.0.1", 0), wl)

    def test_lmstudio_candidates(self):
        cands = lmstudio.candidate_endpoints(windows_host="198.51.100.10")
        self.assertTrue(any("198.51.100.10:1234" in u for u in cands))
        self.assertTrue(any("127.0.0.1:11434" in u for u in cands),
                        "Ollama port 11434 must be in candidates")


class ConfigTests(unittest.TestCase):
    def test_default_whitelist_is_loopback(self):
        with mock.patch.dict(os.environ, {}, clear=False):
            # CAGECORE_* env vars'ı temizle
            for k in list(os.environ):
                if k.startswith("CAGECORE_"):
                    os.environ.pop(k, None)
            with tempfile.TemporaryDirectory() as d:
                os.environ["CAGECORE_CONFIG"] = str(Path(d) / "nope.toml")
                try:
                    cfg = cfg_mod.resolve(autodetect=False)
                    self.assertEqual(cfg.whitelist_entries, ["127.0.0.0/8"])
                    self.assertEqual(cfg.source, "default")
                finally:
                    os.environ.pop("CAGECORE_CONFIG", None)

    def test_env_override(self):
        with mock.patch.dict(os.environ, {
            "CAGECORE_ENDPOINT": "127.0.0.1:11434",
            "CAGECORE_MODEL_NEEDLE": "qwen3-coder",
            "CAGECORE_WHITELIST": "127.0.0.1:11434,192.168.1.5:8080",
            "CAGECORE_CONFIG": "/nonexistent/path.toml",
        }, clear=False):
            cfg = cfg_mod.resolve(autodetect=False)
            self.assertEqual(cfg.endpoint_url, "http://127.0.0.1:11434")
            self.assertEqual(cfg.model_needle, "qwen3-coder")
            self.assertIn("127.0.0.1:11434", cfg.whitelist_entries)
            self.assertIn("192.168.1.5:8080", cfg.whitelist_entries)
            self.assertEqual(cfg.source, "env")

    def test_file_config(self):
        with tempfile.TemporaryDirectory() as d:
            cfg_path = Path(d) / "config.toml"
            cfg_path.write_text(
                '[endpoint]\n'
                'url = "http://127.0.0.1:11434"\n'
                'model_needle = "cont-local"\n'
                '\n'
                '[whitelist]\n'
                'allow = ["127.0.0.1:11434"]\n'
            )
            with mock.patch.dict(os.environ, {}, clear=False):
                for k in list(os.environ):
                    if k.startswith("CAGECORE_"):
                        os.environ.pop(k, None)
                os.environ["CAGECORE_CONFIG"] = str(cfg_path)
                try:
                    cfg = cfg_mod.resolve(autodetect=False)
                    self.assertEqual(cfg.endpoint_url, "http://127.0.0.1:11434")
                    self.assertEqual(cfg.model_needle, "cont-local")
                    self.assertEqual(cfg.whitelist_entries, ["127.0.0.1:11434"])
                    self.assertEqual(cfg.source, "file")
                finally:
                    os.environ.pop("CAGECORE_CONFIG", None)

    def test_save_roundtrip(self):
        with tempfile.TemporaryDirectory() as d:
            cfg_path = Path(d) / "config.toml"
            cfg = cfg_mod.Config(
                endpoint_url="http://127.0.0.1:11434",
                model_needle="qwen3-coder",
                whitelist_entries=["127.0.0.1:11434"],
            )
            cfg_mod.save(cfg, cfg_path)
            self.assertTrue(cfg_path.is_file())
            text = cfg_path.read_text()
            self.assertIn("url = \"http://127.0.0.1:11434\"", text)
            self.assertIn("model_needle = \"qwen3-coder\"", text)
            self.assertIn("127.0.0.1:11434", text)

            # read back
            with mock.patch.dict(os.environ, {}, clear=False):
                for k in list(os.environ):
                    if k.startswith("CAGECORE_"):
                        os.environ.pop(k, None)
                os.environ["CAGECORE_CONFIG"] = str(cfg_path)
                try:
                    got = cfg_mod.resolve(autodetect=False)
                    self.assertEqual(got.endpoint_url, "http://127.0.0.1:11434")
                    self.assertEqual(got.model_needle, "qwen3-coder")
                    self.assertEqual(got.whitelist_entries, ["127.0.0.1:11434"])
                finally:
                    os.environ.pop("CAGECORE_CONFIG", None)


if __name__ == "__main__":
    unittest.main(verbosity=2)
