"""cagecore CLI — generic kafes + uygulama-agnostik launcher."""
from __future__ import annotations

import argparse
import json
import shutil
import subprocess
import sys
import time
from pathlib import Path
from typing import List, Optional

from . import __version__
from . import _resources
from . import config as cfg_mod
from . import kernel_guard
from . import launcher
from . import lmstudio
from . import pcap as pcap_mod
from . import recon
from . import reporting
from . import verify


def _cmd_launch(args: argparse.Namespace) -> int:
    tb = args.target_binary
    if not tb:
        print("--target-binary gerekli", file=sys.stderr)
        return 2
    extra = list(args.target_args or [])
    return launcher.launch(
        target_binary=tb,
        target_args=extra,
        soft=args.soft,
        skip_endpoint_check=args.skip_endpoint_check,
    )


def _cmd_panic(_args: argparse.Namespace) -> int:
    return launcher.panic()


def _cmd_install_cleanup_service(_args: argparse.Namespace) -> int:
    unit_dir = Path.home() / ".config" / "systemd" / "user"
    unit_dir.mkdir(parents=True, exist_ok=True)
    unit_path = unit_dir / "cagecore-cleanup.service"
    bin_path = shutil.which("cagecore") or str(Path.home() / ".local" / "bin" / "cagecore")
    content = f"""[Unit]
Description=cagecore zombie kernel_guard cleanup on login/boot
After=default.target

[Service]
Type=oneshot
ExecStart={bin_path} panic
SuccessExitStatus=0 1 2

[Install]
WantedBy=default.target
"""
    unit_path.write_text(content)
    print(f"unit → {unit_path}")
    print(f"  systemctl --user enable --now cagecore-cleanup")
    return 0


def _cmd_recon(args: argparse.Namespace) -> int:
    recon.main(write_report=True, save_config=args.save_config)
    return 0


def _cmd_verify(args: argparse.Namespace) -> int:
    return verify.main(hardened=args.hardened, soft_only=args.soft_only, write_report=True)


def _cmd_pcap(args: argparse.Namespace) -> int:
    tcpdump = shutil.which("tcpdump")
    if not tcpdump:
        print("tcpdump yok", file=sys.stderr)
        return 4
    sudo_ok = kernel_guard.sudo_nopasswd_available()
    guard_installed = False
    try:
        if args.guard and sudo_ok:
            rc, *_ = kernel_guard.install(scope="global")
            guard_installed = rc == 0
        cap_dir = reporting.report_dir() / "captures"
        cap_dir.mkdir(parents=True, exist_ok=True)
        ts = time.strftime("%Y%m%d_%H%M%S")
        pcap_path = cap_dir / f"session_{ts}.pcap"
        td_cmd = (["sudo", "-n"] if sudo_ok else []) + [
            tcpdump, "-i", args.iface, "-U", "-s", "0", "-w", str(pcap_path), "tcp or udp",
        ]
        print(f"[pcap] capture {args.duration}s → {pcap_path}")
        import os
        td = subprocess.Popen(td_cmd, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
        try:
            time.sleep(args.duration)
        finally:
            try: td.send_signal(2)
            except Exception: pass
            try: td.wait(timeout=5)
            except subprocess.TimeoutExpired: td.kill()
        if sudo_ok:
            subprocess.run(["sudo", "-n", "chown", f"{os.getuid()}:{os.getgid()}",
                           str(pcap_path)], capture_output=True, timeout=5)
        if not pcap_path.exists():
            return 4
        cfg = cfg_mod.resolve(autodetect=True)
        wl_spec = ",".join(cfg.whitelist_entries) if cfg.whitelist_entries else "127.0.0.0/8"
        report, violations = pcap_mod.build_report(pcap_path, wl_spec, local_nets_spec=None)
        pcap_mod.print_table(report)
        json_path = reporting.save_json(pcap_mod.report_to_dict(report), "pcap")
        print(f"JSON: {json_path}")
        return 0 if violations == 0 else 1
    finally:
        if guard_installed:
            kernel_guard.uninstall()


def _cmd_report(args: argparse.Namespace) -> int:
    items = reporting.list_recent(limit=20)
    if not items:
        print("(rapor yok)")
        return 0
    print(f"{'file':<60} {'size':>8}  mtime")
    for p in items:
        st = p.stat()
        mt = time.strftime("%Y-%m-%dT%H:%M:%S", time.localtime(st.st_mtime))
        print(f"{p.name:<60} {st.st_size:>8}  {mt}")
    return 0


def _cmd_selftest(_args: argparse.Namespace) -> int:
    fails: List[str] = []
    print(f"version: {__version__}")
    try:
        wl = _resources.whitelist_default()
        print(f"whitelist default: {wl[:60]}")
    except Exception as e:
        fails.append(f"whitelist: {e}")
    for sh in ("kernel_guard.sh", "dns_sinkhole.sh", "ensure_lmstudio.sh"):
        try:
            _resources.shell_path(sh)
            print(f"shell/{sh}: OK")
        except Exception as e:
            fails.append(f"shell/{sh}: {e}")
    for mod in ("recon", "verify", "pcap", "deny_proxy", "kernel_guard",
                "dns_sinkhole", "lmstudio", "env_flags", "reporting",
                "config", "launcher", "_watchdog"):
        try:
            __import__(f"cagecore.{mod}")
            print(f"import cagecore.{mod}: ok")
        except Exception as e:
            fails.append(f"import {mod}: {e}")
    if fails:
        print("\n❌ selftest FAIL:")
        for f in fails: print(f"  - {f}")
        return 1
    print("\n✅ selftest OK")
    return 0


def _cmd_config(args: argparse.Namespace) -> int:
    if args.action == "path":
        print(cfg_mod.config_path())
        return 0
    cfg = cfg_mod.resolve(autodetect=False)
    print(f"config file:  {cfg_mod.config_path()}  (exists={cfg_mod.config_path().is_file()})")
    print(f"source:       {cfg.source}")
    print(f"endpoint:     {cfg.endpoint_url or '(none)'}")
    print(f"model_needle: {cfg.model_needle or '(none)'}")
    print(f"tools_enabled: {cfg.tools_enabled}")
    print(f"whitelist:    {cfg.whitelist_entries}")
    return 0


def build_parser() -> argparse.ArgumentParser:
    p = argparse.ArgumentParser(prog="cagecore")
    p.add_argument("--version", action="version", version=f"cagecore {__version__}")
    sub = p.add_subparsers(dest="cmd", required=True)

    sp = sub.add_parser("launch",
                        help="Generic: target_binary'yi kafes içinde çalıştır")
    sp.add_argument("--target-binary", required=True,
                    help="Çalıştırılacak binary'nin tam yolu")
    sp.add_argument("--soft", action="store_true",
                    help="L1 atlanır (sudo istemez)")
    sp.add_argument("--skip-endpoint-check", action="store_true",
                    help="LM endpoint probe atlanır")
    sp.add_argument("target_args", nargs=argparse.REMAINDER,
                    help="Target binary argümanları")
    sp.set_defaults(func=_cmd_launch)

    sp = sub.add_parser("panic", help="Kalıntı kuralları zorla temizle")
    sp.set_defaults(func=_cmd_panic)

    sp = sub.add_parser("install-cleanup-service",
                        help="systemd --user unit (boot'ta cagecore panic)")
    sp.set_defaults(func=_cmd_install_cleanup_service)

    sp = sub.add_parser("recon", help="Ortam keşfi (read-only)")
    sp.add_argument("--save-config", action="store_true")
    sp.set_defaults(func=_cmd_recon)

    sp = sub.add_parser("verify", help="Test suite")
    sp.add_argument("--hardened", action="store_true")
    sp.add_argument("--soft-only", action="store_true")
    sp.set_defaults(func=_cmd_verify)

    sp = sub.add_parser("pcap", help="tcpdump + whitelist denetim")
    sp.add_argument("--duration", type=int, default=15)
    sp.add_argument("--iface", default="any")
    sp.add_argument("--no-guard", dest="guard", action="store_false", default=True)
    sp.set_defaults(func=_cmd_pcap)

    sp = sub.add_parser("report", help="Geçmiş raporlar")
    sp.add_argument("--export")
    sp.set_defaults(func=_cmd_report)

    sp = sub.add_parser("selftest", help="Paket bütünlüğü")
    sp.set_defaults(func=_cmd_selftest)

    sp = sub.add_parser("config", help="Config göster / path")
    sp.add_argument("action", nargs="?", default="show", choices=["show", "path"])
    sp.set_defaults(func=_cmd_config)

    return p


def main(argv: Optional[List[str]] = None) -> int:
    parser = build_parser()
    args = parser.parse_args(argv)
    try:
        return args.func(args)
    except KeyboardInterrupt:
        return 130
    except Exception as e:
        print(f"cagecore hata: {e}", file=sys.stderr)
        return 1


if __name__ == "__main__":
    sys.exit(main())
