"""Local OpenAI-compatible endpoint liveness + discovery.

Lightweight probe + default-gateway detection for local LLM endpoints.
Stdlib-only (urllib + subprocess).

Endpoint + model needle artık cagecore.config üzerinden yönetilir.
Bu modül hardcoded default port tutmaz — candidate_endpoints standard
LM Studio (1234) ve Ollama (11434) portlarını yalnızca **autodetect**
ihtiyacı için probe eder.
"""
from __future__ import annotations

import json
import os
import re
import subprocess
import urllib.error
import urllib.request
from dataclasses import dataclass, field
from typing import List, Optional, Tuple

from . import config as _cfg


def _lm_port() -> int:
    return _cfg.STANDARD_LMSTUDIO_PORT


def _ol_port() -> int:
    return _cfg.STANDARD_OLLAMA_PORT


@dataclass
class ProbeResult:
    url: str
    http_code: str = "000"
    alive: bool = False
    model_count: int = 0
    has_model_match: bool = False
    model_ids: List[str] = field(default_factory=list)
    error: str = ""


def detect_windows_host() -> Optional[str]:
    """`ip route show default` gateway IP'si (WSL2'de Windows host)."""
    try:
        out = subprocess.check_output(
            ["ip", "route", "show", "default"], text=True, timeout=3,
            stderr=subprocess.DEVNULL,
        )
        for line in out.splitlines():
            parts = line.split()
            if len(parts) >= 3 and parts[0] == "default":
                return parts[2]
    except (subprocess.SubprocessError, FileNotFoundError, OSError):
        pass
    return None


def _split_needle(spec: str) -> List[str]:
    return [s.strip().lower() for s in spec.split(",") if s.strip()]


def probe_endpoint(
    url: str,
    timeout: float = 3.0,
    model_needle: Optional[Tuple[str, ...]] = None,
) -> ProbeResult:
    """OpenAI-compat `/v1/models` endpoint probe. HTTP_PROXY onurlanır.

    model_needle verilmezse:
      1. cagecore.config.resolve().model_needle varsa o kullanılır
      2. yoksa CAGECORE_MODEL_NEEDLE env var okunur
      3. ikisi de yoksa sadece alive=True yeterli sayılır (has_model_match=False)

    Match: substring, case-insensitive.
    """
    # needle kaynağı
    needles: Tuple[str, ...]
    if model_needle is not None:
        needles = tuple(n.lower() for n in model_needle if n)
    else:
        env_needle = os.environ.get("CAGECORE_MODEL_NEEDLE", "").strip()
        needles = tuple(_split_needle(env_needle))

    result = ProbeResult(url=url)
    try:
        req = urllib.request.Request(url, headers={"User-Agent": "cagecore/0.1.1"})
        with urllib.request.urlopen(req, timeout=timeout) as resp:
            result.http_code = str(resp.status)
            if resp.status == 200:
                body = resp.read().decode("utf-8", errors="replace")
                try:
                    data = json.loads(body)
                    models = data.get("data", [])
                    result.model_count = len(models)
                    ids = [str(m.get("id", "")) for m in models]
                    result.model_ids = ids
                    lc_ids = [i.lower() for i in ids]
                    for needle in needles:
                        if any(needle in mid for mid in lc_ids):
                            result.has_model_match = True
                            break
                    result.alive = True
                except json.JSONDecodeError as e:
                    result.error = f"json decode: {e}"
    except urllib.error.HTTPError as e:
        result.http_code = str(e.code)
        result.error = f"http {e.code}"
    except (urllib.error.URLError, TimeoutError, OSError) as e:
        result.error = str(e)
    return result


def candidate_endpoints(
    windows_host: Optional[str] = None,
    lmstudio_port: Optional[int] = None,
    ollama_port: Optional[int] = None,
) -> List[str]:
    """Autodetect için denenecek URL'ler — öncelik sırayla."""
    wh = windows_host or detect_windows_host()
    lp = lmstudio_port if lmstudio_port is not None else _lm_port()
    op = ollama_port if ollama_port is not None else _ol_port()
    cands: List[str] = [
        f"http://127.0.0.1:{lp}/v1/models",
        f"http://localhost:{lp}/v1/models",
    ]
    if wh:
        cands.append(f"http://{wh}:{lp}/v1/models")
    cands.append(f"http://127.0.0.1:{op}/v1/models")
    if wh:
        cands.append(f"http://{wh}:{op}/v1/models")
    return cands


def ensure_alive(
    windows_host: Optional[str] = None,
    lmstudio_port: Optional[int] = None,
) -> Tuple[bool, List[ProbeResult]]:
    """En az bir aday endpoint canlı mı?

    Returns (any_alive, all_results). model_needle env varsa ayrıca
    has_model_match'e bakılır.
    """
    cands = candidate_endpoints(windows_host, lmstudio_port)
    results = [probe_endpoint(url) for url in cands]
    needle_set = bool(os.environ.get("CAGECORE_MODEL_NEEDLE", "").strip())
    if needle_set:
        ok = any(r.alive and r.has_model_match for r in results)
    else:
        ok = any(r.alive for r in results)
    return ok, results
