"""cagecore launch — verilen target_binary'yi kernel_guard kafesi içinde çalıştır.

Generic: hiçbir uygulamaya özgü değil. Contcode gibi sarmalayıcılar
cagecore.launcher.launch() çağrısını yapar ve kendi binary'lerini verir.

Akış:
  0) Zombie cleanup (önceki kalıntı iptables/nft kurallarını sessizce sil)
  1) Config resolve (env > file > autodetect > default)
  2) Endpoint alive kontrol (--skip-endpoint-check ile atlanır)
  3) sudo -n / hardened → kernel_guard install
  4) Env flags apply (caller tarafından override edilebilir)
  5) Watchdog spawn (detached, opencode ölürse 30s sonra uninstall)
  6) target_binary exec
  7) Normal çıkış → watchdog SIGTERM + kernel_guard uninstall
"""
from __future__ import annotations

import json
import os
import signal
import subprocess
import sys
from pathlib import Path
from typing import Any, Dict, List, Optional

from . import _resources
from . import config as cfg_mod
from . import env_flags
from . import kernel_guard
from . import lmstudio


RUNTIME_DIR = Path(os.environ.get("CAGECORE_RUNTIME_DIR", "/tmp/cagecore"))


# ============= ZOMBIE CLEANUP =============

def _cleanup_silently() -> Dict[str, Any]:
    result = {"nft_removed": False, "ipt_removed": False, "sudo_n": False}
    try:
        sudo_n = subprocess.run(
            ["sudo", "-n", "true"],
            capture_output=True, timeout=2,
        ).returncode == 0
        result["sudo_n"] = sudo_n
        if not sudo_n:
            return result
    except Exception:
        return result

    # nft: inet cagecore tablosu (yeni ad)
    for tname in ("cagecore", "opencode-offline"):  # eski kurulumları da temizle
        try:
            chk = subprocess.run(
                ["sudo", "-n", "nft", "list", "tables"],
                capture_output=True, text=True, timeout=3,
            )
            if f"inet {tname}" in (chk.stdout or ""):
                subprocess.run(
                    ["sudo", "-n", "nft", "delete", "table", "inet", tname],
                    capture_output=True, timeout=3,
                )
                result["nft_removed"] = True
        except Exception:
            pass

    # iptables: cagecore ve eski opencode_offline chain'leri
    for cname in ("cagecore", "opencode_offline"):
        try:
            chk = subprocess.run(
                ["sudo", "-n", "iptables", "-L", cname, "-n"],
                capture_output=True, timeout=3,
            )
            if chk.returncode == 0:
                for _ in range(5):
                    r = subprocess.run(
                        ["sudo", "-n", "iptables", "-D", "OUTPUT", "-j", cname],
                        capture_output=True, timeout=3,
                    )
                    if r.returncode != 0:
                        break
                subprocess.run(
                    ["sudo", "-n", "iptables", "-F", cname],
                    capture_output=True, timeout=3,
                )
                subprocess.run(
                    ["sudo", "-n", "iptables", "-X", cname],
                    capture_output=True, timeout=3,
                )
                result["ipt_removed"] = True
        except Exception:
            pass

    return result


# ============= PANIC =============

def panic() -> int:
    print("[panic] cagecore kernel_guard temizliği...", file=sys.stderr)
    script = _resources.shell_path("kernel_guard.sh")
    sudo_n_ok = False
    try:
        sudo_n_ok = subprocess.run(
            ["sudo", "-n", "true"], capture_output=True, timeout=2,
        ).returncode == 0
    except Exception:
        pass

    if sudo_n_ok:
        print("[panic] sudo -n OK → sessiz uninstall", file=sys.stderr)
        cmd = ["sudo", "-n", "bash", str(script), "uninstall"]
    else:
        print("[panic] sudo -n yok → interaktif parola istenecek", file=sys.stderr)
        cmd = ["sudo", "bash", str(script), "uninstall"]

    try:
        subprocess.run(cmd, timeout=60)
    except Exception as e:
        print(f"[panic] uninstall error: {e}", file=sys.stderr)

    extra = _cleanup_silently()
    print(f"[panic] direct teardown: {extra}", file=sys.stderr)

    # Doğrulama
    try:
        r = subprocess.run(
            ["sudo", "-n", "iptables", "-L", "cagecore", "-n"],
            capture_output=True, timeout=3,
        )
        if r.returncode == 0:
            print("[panic] ⚠  iptables chain HALA var", file=sys.stderr)
            return 2
    except Exception:
        pass

    print("[panic] ✓ temizlik tamam", file=sys.stderr)
    return 0


# ============= WATCHDOG SPAWN =============

def _spawn_watchdog(target_pid: int, grace_s: int = 30) -> Optional[int]:
    try:
        proc = subprocess.Popen(
            [sys.executable, "-m", "cagecore._watchdog",
             str(target_pid), str(grace_s)],
            stdin=subprocess.DEVNULL,
            stdout=subprocess.DEVNULL,
            stderr=subprocess.DEVNULL,
            start_new_session=True,
            close_fds=True,
        )
        return proc.pid
    except Exception as e:
        print(f"[launcher] watchdog spawn fail: {e}", file=sys.stderr)
        return None


# ============= LAUNCH =============

def _stop_guard(installed_flag: Dict[str, bool]) -> None:
    if installed_flag.get("v"):
        print("\n[launcher] kernel_guard uninstall...", file=sys.stderr)
        rc, out, err = kernel_guard.uninstall()
        if rc == 0:
            installed_flag["v"] = False
        else:
            print(f"[launcher] uninstall rc={rc} — elle: "
                  f"sudo bash {kernel_guard.script_path()} uninstall",
                  file=sys.stderr)


def build_launch_env(cfg: cfg_mod.Config, extra_env: Optional[Dict[str, str]] = None,
                     proxy_host: str = "127.0.0.1",
                     proxy_port: int = 9876) -> Dict[str, str]:
    """Caller override'a izin veren env kurulumu."""
    env = os.environ.copy()
    win_host = lmstudio.detect_windows_host()
    flags = env_flags.offline_flags(
        proxy_host=proxy_host, proxy_port=proxy_port,
        windows_host=win_host,
    )
    env.update(flags)
    env.setdefault("OPENAI_API_KEY", "cagecore-local")
    if extra_env:
        env.update(extra_env)
    return env


def launch(
    target_binary: str,
    target_args: Optional[List[str]] = None,
    soft: bool = False,
    skip_endpoint_check: bool = False,
    extra_env: Optional[Dict[str, str]] = None,
) -> int:
    """Generic cage launcher. Tüm kafes katmanlarını kurar, target_binary'i exec eder."""
    target_args = target_args or []

    # 0. Zombie cleanup
    zc = _cleanup_silently()
    if zc["nft_removed"] or zc["ipt_removed"]:
        print(f"[launcher] zombie guard cleanup: {zc}")

    # 1. Config resolve
    cfg = cfg_mod.resolve(autodetect=True)
    print(f"[launcher] config source: {cfg.source}  chain: {cfg.source_chain}")
    print(f"[launcher] endpoint:      {cfg.endpoint_url or '(none)'}")
    print(f"[launcher] model_needle:  {cfg.model_needle or '(none)'}")
    print(f"[launcher] tools_enabled: {cfg.tools_enabled}")
    print(f"[launcher] whitelist:     {cfg.whitelist_entries}")

    cfg_path_on_disk = cfg_mod.config_path()
    if not cfg_path_on_disk.is_file() and cfg.endpoint_url:
        try:
            cfg_mod.save(cfg)
            print(f"[launcher] config kaydedildi → {cfg_path_on_disk}")
        except Exception as e:
            print(f"[launcher] config kaydedilemedi: {e}", file=sys.stderr)

    # 2. Endpoint ping (opsiyonel)
    if not skip_endpoint_check and cfg.endpoint_url:
        test_url = cfg.endpoint_url.rstrip("/") + "/v1/models"
        probe = lmstudio.probe_endpoint(test_url, timeout=3)
        if not probe.alive:
            print(f"[launcher] ⚠  endpoint DEAD: {test_url} ({probe.error})",
                  file=sys.stderr)
            return 4
        print(f"[launcher] endpoint alive: {probe.model_count} model, "
              f"match={probe.has_model_match}")
    elif not cfg.endpoint_url and not skip_endpoint_check:
        print("[launcher] ⚠  endpoint tespit edilemedi", file=sys.stderr)
        return 4

    # 3. Target binary kontrolü
    tbin = Path(target_binary)
    if not tbin.is_file() or not os.access(tbin, os.X_OK):
        print(f"[launcher] target binary yok/exec değil: {tbin}", file=sys.stderr)
        return 5
    print(f"[launcher] target: {tbin}")

    # 4. Kernel guard
    guard_installed = {"v": False}
    if not soft:
        if not kernel_guard.sudo_nopasswd_available():
            print("[launcher] sudo -n yok. sudo -v veya --soft geç.",
                  file=sys.stderr)
            return 6
        pre = kernel_guard.preflight()
        print(f"[launcher] preflight: backend={pre.get('backend')} "
              f"xt_owner={pre.get('xt_owner')} xt_limit={pre.get('xt_limit')}")
        if pre.get("xt_owner") == "missing":
            print("[launcher] xt_owner missing — L1 kurulamaz", file=sys.stderr)
            return 6
        rc, out, err = kernel_guard.install(scope="uid")
        if rc != 0:
            print(f"[launcher] kernel_guard install rc={rc}\n{err}", file=sys.stderr)
            return 6
        guard_installed["v"] = True
        print("[launcher] ✓ kernel_guard aktif")
    else:
        print("[launcher] --soft: L1 kernel_guard ATLANDI")

    # 5. Env + exec
    env = build_launch_env(cfg, extra_env=extra_env)

    cmd = [str(tbin)] + list(target_args)
    print(f"[launcher] exec: {' '.join(cmd)}\n")

    watchdog_pid: Optional[int] = None
    try:
        proc = subprocess.Popen(cmd, env=env)

        if guard_installed["v"]:
            watchdog_pid = _spawn_watchdog(proc.pid, grace_s=30)
            if watchdog_pid:
                print(f"[launcher] watchdog pid={watchdog_pid}", file=sys.stderr)

        def _forward(sig, _frame):
            try:
                proc.send_signal(sig)
            except Exception:
                pass
        signal.signal(signal.SIGINT, _forward)
        signal.signal(signal.SIGTERM, _forward)

        rc = proc.wait()

        if watchdog_pid:
            try:
                os.kill(watchdog_pid, signal.SIGTERM)
            except ProcessLookupError:
                pass
            except Exception:
                pass

        _stop_guard(guard_installed)
        return rc
    except FileNotFoundError as e:
        print(f"[launcher] exec fail: {e}", file=sys.stderr)
        _stop_guard(guard_installed)
        return 127
    except KeyboardInterrupt:
        _stop_guard(guard_installed)
        return 130
    except Exception as e:
        print(f"[launcher] abnormal: {e}", file=sys.stderr)
        _stop_guard(guard_installed)
        return 1
