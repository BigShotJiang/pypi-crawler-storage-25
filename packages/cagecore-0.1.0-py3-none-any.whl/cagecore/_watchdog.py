"""cagecore watchdog — opencode PID ölürse kernel_guard uninstall eder.

Parent'tan bağımsız çalışır (setsid ile ayrı session). Opencode çıkarken
ana launcher SIGTERM gönderir → watchdog temiz çıkar. Launcher kendisi
SIGKILL edilse bile (terminal kapanma, WSL shutdown, OOM), watchdog
opencode'un ölümünü görür ve 30s sonra guard'ı söker.

Kullanım:
  python -m cagecore._watchdog <opencode_pid> [grace_seconds]
"""
from __future__ import annotations

import os
import signal
import subprocess
import sys
import time
from pathlib import Path

from . import _resources


_STOP = False


def _sigterm_handler(_signo, _frame):
    """Ana launcher normal çıkışta SIGTERM gönderir — temiz çık (cleanup yapmadan)."""
    global _STOP
    _STOP = True


def pid_alive(pid: int) -> bool:
    try:
        os.kill(pid, 0)
        return True
    except ProcessLookupError:
        return False
    except PermissionError:
        # Process var ama yetki yok — yine de canlı sayılır
        return True


def cleanup_guard() -> int:
    script = _resources.shell_path("kernel_guard.sh")
    # sudo -n dene
    try:
        p = subprocess.run(
            ["sudo", "-n", "bash", str(script), "uninstall"],
            capture_output=True, text=True, timeout=15,
        )
        return p.returncode
    except Exception:
        return 1


def main() -> int:
    signal.signal(signal.SIGTERM, _sigterm_handler)
    signal.signal(signal.SIGINT, _sigterm_handler)

    if len(sys.argv) < 2:
        print("usage: python -m cagecore._watchdog <pid> [grace_seconds]", file=sys.stderr)
        return 2
    try:
        target_pid = int(sys.argv[1])
    except ValueError:
        return 2
    grace_s = 30
    if len(sys.argv) >= 3:
        try:
            grace_s = int(sys.argv[2])
        except ValueError:
            pass

    log_dir = Path(os.environ.get("CAGECORE_RUNTIME_DIR", "/tmp/cagecore"))
    log_dir.mkdir(parents=True, exist_ok=True)
    log = log_dir / "watchdog.log"

    def _log(msg: str):
        try:
            with log.open("a", encoding="utf-8") as f:
                f.write(f"{time.strftime('%Y-%m-%dT%H:%M:%S')} pid={os.getpid()} target={target_pid} {msg}\n")
        except OSError:
            pass

    _log("watchdog started")

    # Phase 1: opencode canlı olduğu sürece bekle
    while not _STOP and pid_alive(target_pid):
        time.sleep(1)

    if _STOP:
        _log("sigterm received — exit without cleanup")
        return 0

    _log(f"target pid died — grace {grace_s}s before cleanup")

    # Phase 2: grace period — SIGTERM gelirse vazgeç
    end = time.time() + grace_s
    while not _STOP and time.time() < end:
        time.sleep(1)

    if _STOP:
        _log("sigterm during grace — exit without cleanup")
        return 0

    # Phase 3: guard uninstall
    rc = cleanup_guard()
    _log(f"cleanup_guard rc={rc}")
    return 0


if __name__ == "__main__":
    sys.exit(main())
