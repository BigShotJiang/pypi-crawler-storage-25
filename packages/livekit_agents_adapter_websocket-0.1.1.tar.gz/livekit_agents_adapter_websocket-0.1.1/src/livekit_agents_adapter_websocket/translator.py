"""WebSocket Translator — bridges LiveKit to any external agent service via WebSockets."""

from __future__ import annotations

import json
import logging
from typing import Any, AsyncIterable

import aiohttp

from livekit_agents_adapter import ExternalLLMResponse
from livekit_agents_adapter.translators.base import Translator

logger = logging.getLogger("livekit_agents_adapter.websocket")


class WebSocketTranslator(Translator):
    """Translator that connects to an external agent via a persistent WebSocket.

    Sends LiveKit ``ChatContext`` and tool definitions as JSON on each
    :meth:`invoke` call and yields :class:`~livekit_agents_adapter.TextChunk`,
    :class:`~livekit_agents_adapter.ToolCall`, and
    :class:`~livekit_agents_adapter.Done` responses streamed back from the
    remote server.

    The connection is opened in :meth:`on_enter` and closed in :meth:`on_exit`,
    keeping it alive across turns for minimal latency.

    JSON protocol (adapter -> server)::

        {
            "type": "invoke",
            "chat_ctx": [{"role": "user", "content": "..."}],
            "tools": [{"name": "...", "description": "...", "parameters": {...}}]
        }

    JSON protocol (server -> adapter)::

        {"type": "text_chunk", "content": "...", "is_final": false}
        {"type": "tool_call", "name": "...", "arguments": "{...}", "call_id": "..."}
        {"type": "done", "metadata": {}}
        {"type": "error", "message": "..."}
    """

    def __init__(
        self,
        url: str,
        *,
        headers: dict[str, str] | None = None,
        timeout: float = 30.0,
        ping_interval: float = 20.0,
    ) -> None:
        """Initialize the WebSocket translator.

        Args:
            url: WebSocket server URL (e.g., ``ws://localhost:8000/ws``).
            headers: Optional HTTP headers for the upgrade request.
            timeout: Timeout in seconds for receiving each streamed message.
            ping_interval: Interval (seconds) for WebSocket keep-alive pings.
        """
        super().__init__()
        self._url = url
        self._headers = headers or {}
        self._timeout = timeout
        self._ping_interval = ping_interval

        self._session: aiohttp.ClientSession | None = None
        self._ws: aiohttp.ClientWebSocketResponse | None = None

        self._collected_tool_calls: list[dict[str, Any]] = []
        self._collected_text: str = ""
        self._last_synced_offset: int = 0

    def reset(self) -> None:
        """Reset per-turn state for a new session.

        Clears accumulated text, tool calls, and the sync offset so that
        conversation history does not bleed between sessions. The WebSocket
        connection is intentionally preserved — it is reused across turns
        within a session and is only closed in :meth:`on_exit`.
        """
        self._collected_tool_calls = []
        self._collected_text = ""
        self._last_synced_offset = 0

    async def on_enter(self) -> None:
        if self._ws is not None and not self._ws.closed:
            return

        self._session = aiohttp.ClientSession()
        try:
            self._ws = await self._session.ws_connect(
                self._url,
                headers=self._headers,
                heartbeat=self._ping_interval,
            )
        except Exception:
            await self._session.close()
            self._session = None
            raise

    async def on_exit(self) -> None:
        if self._ws is not None and not self._ws.closed:
            await self._ws.close()
            self._ws = None
        if self._session is not None:
            await self._session.close()
            self._session = None

    async def to_external_chat_ctx(self, chat_ctx: Any) -> Any:
        from livekit.agents.llm.chat_context import ChatMessage, FunctionCall, FunctionCallOutput

        items: list[dict[str, Any]] = []
        for item in chat_ctx.items:
            if isinstance(item, ChatMessage):
                role = getattr(item, "role", "user")
                text = _extract_text(item)
                if text:
                    items.append({"role": role, "content": text})
            elif isinstance(item, FunctionCall):
                args_str = getattr(item, "arguments", "{}")
                items.append(
                    {
                        "type": "function_call",
                        "role": "assistant",
                        "call_id": getattr(item, "call_id", ""),
                        "name": getattr(item, "name", ""),
                        "arguments": args_str,
                    }
                )
            elif isinstance(item, FunctionCallOutput):
                items.append(
                    {
                        "type": "function_call_output",
                        "role": "tool",
                        "call_id": getattr(item, "call_id", ""),
                        "output": getattr(item, "output", ""),
                    }
                )
        return items

    async def to_external_tools(self, tools: Any) -> Any:
        from livekit_agents_adapter.translators.chat_context import build_tools_dict

        return build_tools_dict(tools)

    async def invoke(self, chat_ctx: Any, tools: Any) -> AsyncIterable[ExternalLLMResponse]:
        from livekit_agents_adapter import Done, TextChunk, ToolCall

        if self._ws is None or self._ws.closed:
            yield Done(
                metadata={
                    "error": "NOT_CONNECTED",
                    "error_message": "WebSocket not connected",
                }
            )
            return

        self._collected_tool_calls = []
        self._collected_text = ""

        payload = json.dumps(
            {
                "type": "invoke",
                "chat_ctx": chat_ctx,
                "tools": tools,
            }
        )
        await self._ws.send_str(payload)

        try:
            async for msg in self._ws:
                if msg.type == aiohttp.WSMsgType.TEXT:
                    data = json.loads(msg.data)
                    msg_type = data.get("type", "")

                    if msg_type == "text_chunk":
                        content = data.get("content", "")
                        self._collected_text += content
                        yield TextChunk(
                            content=content,
                            is_final=data.get("is_final", False),
                        )

                    elif msg_type == "tool_call":
                        args: dict[str, Any] = {}
                        raw_args = data.get("arguments", "{}")
                        if isinstance(raw_args, str):
                            try:
                                args = json.loads(raw_args)
                            except json.JSONDecodeError:
                                args = {"_raw": raw_args}
                        elif isinstance(raw_args, dict):
                            args = raw_args

                        self._collected_tool_calls.append(
                            {
                                "name": data.get("name", ""),
                                "arguments": args,
                                "call_id": data.get("call_id", ""),
                            }
                        )
                        yield ToolCall(
                            name=data.get("name", ""),
                            arguments=args,
                            call_id=data.get("call_id") or None,
                        )

                    elif msg_type == "done":
                        yield Done(metadata=data.get("metadata", {}))
                        return

                    elif msg_type == "error":
                        message = data.get("message", "Unknown server error")
                        logger.error("WebSocket agent error: %s", message)
                        yield Done(metadata={"error": "AGENT_ERROR", "error_message": message})
                        return

                elif msg.type == aiohttp.WSMsgType.ERROR:
                    logger.error(
                        "WebSocket error: %s",
                        self._ws.exception(),
                        exc_info=True,
                    )
                    yield Done(
                        metadata={
                            "error": "WS_ERROR",
                            "error_message": str(self._ws.exception()),
                        }
                    )
                    return

                elif msg.type in (
                    aiohttp.WSMsgType.CLOSE,
                    aiohttp.WSMsgType.CLOSED,
                    aiohttp.WSMsgType.CLOSING,
                ):
                    logger.warning("WebSocket closed unexpectedly during invoke")
                    yield Done(
                        metadata={
                            "error": "WS_CLOSED",
                            "error_message": "Connection closed",
                        }
                    )
                    return

        except TimeoutError:
            logger.error("WebSocket invoke timed out after %.1fs", self._timeout)
            yield Done(
                metadata={
                    "error": "TIMEOUT",
                    "error_message": f"Timed out after {self._timeout}s",
                }
            )

        except Exception as e:
            logger.error("WebSocket invoke failed: %s", e, exc_info=True)
            yield Done(metadata={"error": "EXCEPTION", "error_message": str(e)})

    async def sync_back_messages(self, chat_ctx: Any) -> list[Any]:
        from livekit.agents.llm.chat_context import ChatMessage, FunctionCall

        new_items: list[Any] = []

        if self._collected_text:
            new_items.append(ChatMessage(role="assistant", content=[self._collected_text]))

        for tc in self._collected_tool_calls[self._last_synced_offset :]:
            args = tc.get("arguments", {})
            args_str = json.dumps(args) if isinstance(args, dict) else str(args)
            new_items.append(
                FunctionCall(
                    call_id=tc.get("call_id", ""),
                    name=tc.get("name", ""),
                    arguments=args_str,
                )
            )

        self._last_synced_offset = len(self._collected_tool_calls)
        return new_items


def _extract_text(item: Any) -> str:
    content = getattr(item, "content", "")
    if isinstance(content, str):
        return content
    if isinstance(content, list):
        return " ".join(str(p) for p in content)
    return str(content)
