"""LiveKit Agents Adapter WebSocket — connect any remote agent service to LiveKit via WebSockets.

This package provides :class:`WebSocketTranslator`, a
:class:`~livekit_agents_adapter.Translator` implementation that bridges
LiveKit's agent pipeline to an external agent running on a separate process
or machine over a persistent WebSocket connection.

Example usage::

    from livekit_agents_adapter import AgentAdapter, AgentAdapterConfig
    from livekit_agents_adapter_websocket import WebSocketTranslator

    translator = WebSocketTranslator("ws://localhost:8000/ws")

    config = AgentAdapterConfig(
        translator=translator,
    )

    agent = AgentAdapter(
        config=config,
        instructions="You are a helpful assistant.",
    )
"""

from __future__ import annotations

from .translator import WebSocketTranslator

__all__ = [
    "WebSocketTranslator",
]
