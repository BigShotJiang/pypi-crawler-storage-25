# livekit-agents-adapter-websocket

WebSocket translator for [livekit-agents-adapter](../livekit-agents-adapter/).
Connect any remote agent service to LiveKit via a persistent WebSocket connection.

## Installation

```bash
pip install livekit-agents-adapter-websocket
```

## Usage

```python
from livekit_agents_adapter import AgentAdapter, AgentAdapterConfig
from livekit_agents_adapter_websocket import WebSocketTranslator

translator = WebSocketTranslator("ws://localhost:8000/ws")

config = AgentAdapterConfig(
    translator=translator,
)

agent = AgentAdapter(
    config=config,
    instructions="You are a helpful assistant.",
)
```

See `examples/websocket_reference_server.py` for a reference WebSocket server implementation.
