import io
import json
from pathlib import Path

import pandas as pd
import pytest
from pymultirole_plugins.v1.schema import Document
from starlette.responses import Response

from pyformatters_tabular.tabular import OutputFormat, TabularFormatter, TabularParameters


def test_xlsx():
    testdir = Path(__file__).parent
    source = Path(testdir, "data/response_1621334812115.json")
    with source.open("r") as fin:
        docs = json.load(fin)
        doc = Document(**docs[0])
        formatter = TabularFormatter()
        options = TabularParameters(format=OutputFormat.xlsx)
        resp: Response = formatter.format(doc, options)
        assert resp.status_code == 200
        assert resp.media_type == "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"
        result = Path(testdir, "data/response_1621334812115.xlsx")
        with result.open("wb") as fout:
            fout.write(resp.body)


def test_csv():
    testdir = Path(__file__).parent
    source = Path(testdir, "data/response_1621334812115.json")
    with source.open("r") as fin:
        docs = json.load(fin)
        doc = Document(**docs[0])
        formatter = TabularFormatter()
        options = TabularParameters(format=OutputFormat.csv)
        resp: Response = formatter.format(doc, options)
        assert resp.status_code == 200
        assert resp.media_type == "text/csv"
        result = Path(testdir, "data/response_1621334812115.csv")
        with result.open("wb") as fout:
            fout.write(resp.body)


def test_slots():
    testdir = Path(__file__).parent
    source = Path(testdir, "data/slots.json")
    output_file = Path(testdir, "data/slots.xlsx")
    formatter = TabularFormatter()
    options = TabularParameters(format=OutputFormat.csv, as_slots=True)
    with source.open("r") as fin:
        docs = json.load(fin)
        dfs = []
        for doc in docs:
            doc = Document(**doc)
            resp: Response = formatter.format(doc, options)
            assert resp.status_code == 200
            content = io.TextIOWrapper(io.BytesIO(resp.body), encoding=resp.charset)
            df = pd.read_csv(content)
            dfs.append(df)
        concatenated = pd.concat(dfs, ignore_index=True)
        concatenated.to_excel(str(output_file), index=False)


def _make_doc(**kwargs):
    defaults = {"identifier": "doc-001", "title": "Test Document", "text": "Hello world foo"}
    return Document(**{**defaults, **kwargs})


def _read_csv_response(resp: Response) -> pd.DataFrame:
    content = io.TextIOWrapper(io.BytesIO(resp.body), encoding=resp.charset)
    return pd.read_csv(content)


def test_get_model():
    assert TabularFormatter.get_model() is TabularParameters


def test_document_fields_identifier_and_title():
    doc = _make_doc(annotations=[{"start": 0, "end": 5, "label": "greeting", "labelName": "greeting"}])
    formatter = TabularFormatter()
    options = TabularParameters(format=OutputFormat.csv, document_fields="identifier,title")
    resp = formatter.format(doc, options)
    assert resp.status_code == 200
    df = _read_csv_response(resp)
    assert "document.identifier" in df.columns
    assert "document.title" in df.columns
    assert df["document.identifier"].iloc[0] == "doc-001"
    assert df["document.title"].iloc[0] == "Test Document"


def test_document_fields_empty():
    doc = _make_doc(annotations=[{"start": 0, "end": 5, "label": "greeting", "labelName": "greeting"}])
    formatter = TabularFormatter()
    options = TabularParameters(format=OutputFormat.csv, document_fields="")
    resp = formatter.format(doc, options)
    df = _read_csv_response(resp)
    assert "document.identifier" not in df.columns
    assert "document.title" not in df.columns


def test_empty_annotations():
    doc = _make_doc(annotations=[])
    formatter = TabularFormatter()
    options = TabularParameters(format=OutputFormat.csv, document_fields="")
    resp = formatter.format(doc, options)
    assert resp.status_code == 200
    assert resp.body.strip() == b""


def test_annotation_properties():
    testdir = Path(__file__).parent
    source = Path(testdir, "data/response_1621334812115.json")
    with source.open("r") as fin:
        docs = json.load(fin)
        doc = Document(**docs[0])
    # inject properties into first annotation
    doc.annotations[0].properties = {"confidence": "0.9", "source": "model"}
    formatter = TabularFormatter()
    options = TabularParameters(format=OutputFormat.csv, document_fields="")
    resp = formatter.format(doc, options)
    df = _read_csv_response(resp)
    assert "properties.confidence" in df.columns
    assert "properties.source" in df.columns
    assert float(df["properties.confidence"].iloc[0]) == pytest.approx(0.9)


def test_annotation_terms():
    testdir = Path(__file__).parent
    source = Path(testdir, "data/test.json")
    with source.open("r") as fin:
        doc = Document(**json.load(fin))
    formatter = TabularFormatter()
    options = TabularParameters(format=OutputFormat.csv, document_fields="")
    resp = formatter.format(doc, options)
    assert resp.status_code == 200
    df = _read_csv_response(resp)
    assert "terms.0.identifier" in df.columns
    assert "terms.0.lexicon" in df.columns
    assert "terms.0.preferredForm" in df.columns


def test_filename_from_document_properties():
    doc = _make_doc(
        annotations=[{"start": 0, "end": 5, "label": "greeting", "labelName": "greeting"}],
        properties={"fileName": "/path/to/myreport.txt"},
    )
    formatter = TabularFormatter()
    options = TabularParameters(format=OutputFormat.xlsx, document_fields="")
    resp = formatter.format(doc, options)
    assert "myreport.xlsx" in resp.headers["Content-Disposition"]


def test_slots_multivalue_separator():
    doc = _make_doc(
        annotations=[
            {"start": 0, "end": 5, "label": "word", "labelName": "word"},
            {"start": 6, "end": 11, "label": "word", "labelName": "word"},
        ]
    )
    formatter = TabularFormatter()
    options = TabularParameters(format=OutputFormat.csv, as_slots=True, multivalue_separator="|", document_fields="")
    resp = formatter.format(doc, options)
    df = _read_csv_response(resp)
    assert "word" in df.columns
    assert df["word"].iloc[0] == "Hello|world"
