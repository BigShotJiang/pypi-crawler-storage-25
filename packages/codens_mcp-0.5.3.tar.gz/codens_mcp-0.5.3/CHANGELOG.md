# Changelog

All notable changes to `codens-mcp` are documented here.

## [0.5.3] - 2026-05-15

### Fixed

- **MCP server crash on startup** — `from __future__ import annotations` in
  `cross_tools.py` turned `list[str]` / `str | None` into string annotations,
  causing `mcp>=1.12.0` to raise `TypeError: issubclass() arg 1 must be a class`
  during tool registration. Replaced with `typing.List` / `typing.Optional`.
- `purple-codens-mcp` dependency relaxed to `>=0.2.0` (was `>=0.3.0` which does
  not exist on PyPI).

## [0.4.0] - 2026-05-07

### Added

- **CLI subcommands**: `codens-mcp login`, `codens-mcp whoami`, `codens-mcp serve`.
  - `login` performs Device Code Flow auth via Auth Codens by delegating to
    `purple_codens_mcp.auth.device_code_login` — no logic is duplicated.
  - `whoami` prints `email` / `user_id` / `organization` / `credits_remaining_jpy`
    using the stored token.
  - `serve` (default when no subcommand is given) starts the unified MCP
    server, preserving the previous `codens-mcp` invocation as backward
    compatible.
- README Quick Start updated to document the `codens-mcp login` flow with a
  Device Code Flow example.
- `tests/test_cli.py` added — covers `--help` output, no-arg → `serve`
  routing, and `_cmd_login` delegation.

### Changed

- `server.py` refactored to an `argparse` subparsers structure with
  `_cmd_login` / `_cmd_whoami` / `_cmd_serve` handlers and a `build_server()`
  helper for MCP construction.

## [0.3.0] - 2026-05-06

### Added

- **Cross-product tool (1)**: `codens_register_project_unified` — register a project across Purple/Red/Blue/Green in one call. Best-effort: a failure in one product does not block others. Returns per-product IDs and an `errors` list.

## [0.1.0] - 2026-05-06

### Added

- Initial release of `codens-mcp` — the unified MCP server for the Codens family.
- **Purple tools (16)**: All tools re-exported from `purple-codens-mcp>=0.2.0`.
  - Auth: `purple_login`, `purple_whoami`
  - Project: `purple_analyze_repo`, `purple_list_projects`, `purple_init_project`
  - Repository: `purple_add_repository`, `purple_list_repositories`
  - Instructions: `purple_import_instructions`, `purple_list_instructions`, `purple_sync_instructions`
  - Workflow: `purple_create_workflow`, `purple_get_run_status`, `purple_list_runs`, `purple_cancel_run`, `purple_inject_message`
  - SSE: `purple_subscribe_run_events`
- **Red tools (4)**: Red Codens bug-report and auto-fix integration.
  - `red_create_bug_report` — POST `/api/v1/agent/create-bug-report`
  - `red_get_bug_report` — GET `/api/v1/organizations/{org}/bug-reports/{id}`
  - `red_analyze_bug_report` — POST `/api/v1/organizations/{org}/bug-reports/{id}/analyze`
  - `red_submit_bug_fix_plan_to_purple` — POST `/api/v1/organizations/{org}/bug-fix-plans/{id}/submit`
- **Blue tools (4)**: Blue Codens QA/E2E automation.
  - `blue_list_e2e_tests`
  - `blue_generate_e2e_test`
  - `blue_run_e2e_test`
  - `blue_get_e2e_test_results`
- **Green tools (4)**: Green Codens PRD consultation and kickoff.
  - `green_create_consultation_with_message`
  - `green_send_consultation_message`
  - `green_convert_consultation_to_prd`
  - `green_create_kickoff`
- **Auth tools (2)**: Auth Codens agent signup and public pricing.
  - `auth_agent_signup`
  - `auth_get_pricing`
