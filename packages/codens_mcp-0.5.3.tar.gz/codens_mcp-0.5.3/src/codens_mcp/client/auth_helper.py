"""Shared credential helper for Codens family clients.

Reuses the credential store written by purple_login (~/.purple-codens/credentials.json).
Auth Codens is the single OIDC issuer for the family, so the same JWT is accepted
by Red, Blue, and Green backends.
"""

from dataclasses import dataclass

from purple_codens_mcp.auth import get_credentials


class AuthenticationError(Exception):
    """Raised when credentials are missing or invalid."""


@dataclass
class Credentials:
    token: str


def load_codens_credentials(api_url: str, service: str) -> Credentials:
    """Load JWT from the purple-codens-mcp credential store.

    For v0.1.0 all Codens backends share the JWT issued by Auth Codens via
    purple_login. Future versions may use per-service capability_tokens.
    """
    creds = get_credentials(api_url)
    if creds is None:
        raise AuthenticationError(
            f"Not logged in for {api_url}. Run purple_login first."
        )
    return Credentials(token=creds["token"])
