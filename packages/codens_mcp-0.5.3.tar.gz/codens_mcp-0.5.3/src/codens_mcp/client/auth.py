"""HTTP client for Auth Codens (agent-signup and public endpoints)."""

from typing import Optional

import httpx


class AuthClient:
    def __init__(self, api_url: str, token: Optional[str] = None) -> None:
        self.api_url = api_url.rstrip("/")
        self.token = token

    def get_no_auth(self, path: str) -> dict:
        with httpx.Client(timeout=10.0) as c:
            r = c.get(f"{self.api_url}{path}")
            r.raise_for_status()
            return r.json()

    def post(self, path: str, json: dict) -> dict:
        with httpx.Client(timeout=10.0) as c:
            r = c.post(f"{self.api_url}{path}", json=json)
            r.raise_for_status()
            return r.json()
