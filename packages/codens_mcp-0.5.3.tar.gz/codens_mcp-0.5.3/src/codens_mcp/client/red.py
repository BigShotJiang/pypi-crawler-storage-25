"""HTTP client for Red Codens (auto-fix service)."""

from typing import Optional

import httpx

from .auth_helper import AuthenticationError


class RedClient:
    def __init__(self, api_url: str, token: str) -> None:
        self.api_url = api_url.rstrip("/")
        self.token = token

    def _headers(self) -> dict:
        return {"Authorization": f"Bearer {self.token}", "Content-Type": "application/json"}

    def get(self, path: str, params: Optional[dict] = None) -> dict:
        with httpx.Client(timeout=30.0) as c:
            r = c.get(f"{self.api_url}{path}", headers=self._headers(), params=params)
            if r.status_code == 401:
                raise AuthenticationError("401 from Red Codens — token may be expired")
            r.raise_for_status()
            return r.json()

    def post(self, path: str, json: Optional[dict] = None) -> dict:
        with httpx.Client(timeout=30.0) as c:
            r = c.post(f"{self.api_url}{path}", headers=self._headers(), json=json or {})
            if r.status_code == 401:
                raise AuthenticationError("401 from Red Codens — token may be expired")
            r.raise_for_status()
            return r.json()

    def patch(self, path: str, json: Optional[dict] = None) -> dict:
        with httpx.Client(timeout=30.0) as c:
            r = c.patch(f"{self.api_url}{path}", headers=self._headers(), json=json or {})
            if r.status_code == 401:
                raise AuthenticationError("401 from Red Codens — token may be expired")
            r.raise_for_status()
            return r.json()
