"""Unified MCP server entry point for the Codens family."""

import argparse
import sys
from typing import Optional

from mcp.server.fastmcp import FastMCP

from .tools.auth_tools import register_auth_tools
from .tools.blue_tools import register_blue_tools
from .tools.cross_tools import register_cross_tools
from .tools.green_tools import register_green_tools
from .tools.purple_tools import register_purple_tools
from .tools.red_tools import register_red_tools


def build_server() -> FastMCP:
    """Build the unified Codens MCP server with all tools registered."""
    mcp = FastMCP(
        "codens",
        instructions=(
            "Codens unified MCP server. "
            "Use purple_login first, then use Red/Blue/Green/Auth tools as needed. "
            "All tools that call Codens APIs require the api_url parameter."
        ),
    )
    register_purple_tools(mcp)
    register_cross_tools(mcp)
    register_red_tools(mcp)
    register_blue_tools(mcp)
    register_green_tools(mcp)
    register_auth_tools(mcp)
    return mcp


def _cmd_login(args: argparse.Namespace) -> None:
    """Handle `codens-mcp login` — Device Code Flow auth via Auth Codens.

    Delegates token issuance to ``purple_codens_mcp.auth.device_code_login``
    and persists credentials via ``PurpleCodensClient.login_with_device_token``
    so the unified ``codens-mcp`` and ``purple-codens-mcp`` CLIs share a
    credential store at ``~/.purple-codens/credentials.json`` (mode 0600).
    """
    from purple_codens_mcp.auth import device_code_login
    from purple_codens_mcp.client import PurpleCodensClient

    auth_url: str = args.auth_url
    api_url: str = args.api_url

    print(f"Logging in to {api_url} via {auth_url} ...\n")
    token_resp = device_code_login(auth_url)

    client = PurpleCodensClient(api_url)
    result = client.login_with_device_token(
        access_token=token_resp["access_token"],
        refresh_token=token_resp.get("refresh_token"),
        auth_service_url=auth_url,
    )
    user = result.get("user", {})
    email = user.get("email", "unknown")
    print(f"\nLogged in as {email}")


def _cmd_whoami(args: argparse.Namespace) -> None:
    """Handle `codens-mcp whoami` — print current authenticated user info."""
    from purple_codens_mcp.client import PurpleCodensClient

    client = PurpleCodensClient(args.api_url)
    if not client._token:
        print("Not logged in. Run: codens-mcp login")
        sys.exit(1)
    try:
        me = client._request("GET", "/api/v1/auth/me")
    except Exception as exc:
        print(f"Error: {exc}")
        sys.exit(1)

    print(f"Email: {me.get('email')}")
    print(f"User ID: {me.get('id') or me.get('user_id')}")
    orgs = me.get("organizations") or []
    org = me.get("organization")
    if org:
        org_id = org.get("id")
        org_name = org.get("name") or org.get("organization_name")
        print(f"Organization: {org_name} ({org_id})")
    elif orgs:
        first = orgs[0]
        org_name = first.get("organization_name") or first.get("name")
        org_id = first.get("organization_id") or first.get("id")
        role = first.get("role")
        suffix = f" ({role})" if role else ""
        print(f"Organization: {org_name} [{org_id}]{suffix}")
    credits = me.get("credits_remaining_jpy")
    if credits is not None:
        print(f"Credits remaining (JPY): {credits}")


def _cmd_serve(args: Optional[argparse.Namespace] = None) -> None:
    """Handle `codens-mcp serve` (default) — start the unified MCP server."""
    mcp = build_server()
    mcp.run()


def _build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        prog="codens-mcp",
        description=(
            "Codens unified MCP server. "
            "Run without a subcommand to start the MCP server (default)."
        ),
    )
    subparsers = parser.add_subparsers(dest="command")

    # codens-mcp login
    login_p = subparsers.add_parser(
        "login",
        help="Authenticate via Device Code Flow (works on headless/SSH).",
        description=(
            "Log in to Codens via the Device Code Flow. Prints a verification "
            "URL and user code to enter on any browser-equipped device."
        ),
    )
    login_p.add_argument(
        "--auth-url",
        default="https://api.auth.codens.ai",
        help="Auth Codens base URL (default: https://api.auth.codens.ai)",
    )
    login_p.add_argument(
        "--api-url",
        default="https://api.purple.codens.ai",
        help="Codens API base URL used to fetch /me (default: https://api.purple.codens.ai)",
    )

    # codens-mcp whoami
    whoami_p = subparsers.add_parser(
        "whoami",
        help="Show the currently authenticated user.",
        description="Print user_id / email / organization / credits using the stored token.",
    )
    whoami_p.add_argument(
        "--api-url",
        default="https://api.purple.codens.ai",
        help="Codens API base URL (default: https://api.purple.codens.ai)",
    )

    # codens-mcp serve (default when no subcommand is given)
    subparsers.add_parser(
        "serve",
        help="Start the MCP server over stdio (default).",
        description="Start the unified Codens MCP server (stdio transport).",
    )

    return parser


def main() -> None:
    parser = _build_parser()
    args = parser.parse_args()

    if args.command == "login":
        _cmd_login(args)
    elif args.command == "whoami":
        _cmd_whoami(args)
    else:
        # No subcommand or "serve" → start the MCP server (backward compatible).
        _cmd_serve(args)


if __name__ == "__main__":
    main()
