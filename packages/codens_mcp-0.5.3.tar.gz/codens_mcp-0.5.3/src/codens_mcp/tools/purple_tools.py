"""Re-export all 18 Purple tools from purple-codens-mcp dependency."""

from mcp.server.fastmcp import FastMCP
from purple_codens_mcp.client import PurpleCodensClient
from purple_codens_mcp.tools.auth_tools import register_auth_tools as _register_purple_auth
from purple_codens_mcp.tools.instruction_tools import register_instruction_tools as _register_instructions
from purple_codens_mcp.tools.log_tools import register_log_tools as _register_logs
from purple_codens_mcp.tools.project_tools import register_project_tools as _register_projects
from purple_codens_mcp.tools.repo_tools import register_repo_tools as _register_repos
from purple_codens_mcp.tools.sse_tools import register_sse_tools as _register_sse
from purple_codens_mcp.tools.workflow_tools import register_workflow_tools as _register_workflows

_purple_clients: dict[str, PurpleCodensClient] = {}


def _purple_get_client(api_url: str, force_reload: bool = False) -> PurpleCodensClient:
    if force_reload or api_url not in _purple_clients:
        _purple_clients[api_url] = PurpleCodensClient(api_url)
    return _purple_clients[api_url]


def register_purple_tools(mcp: FastMCP) -> None:
    """Register all 18 Purple tools (auth/project/repo/instruction/workflow/sse/log)."""
    _register_purple_auth(mcp, _purple_get_client)
    _register_projects(mcp, _purple_get_client)
    _register_repos(mcp, _purple_get_client)
    _register_instructions(mcp, _purple_get_client)
    _register_workflows(mcp, _purple_get_client)
    _register_sse(mcp, _purple_get_client)
    _register_logs(mcp, _purple_get_client)
