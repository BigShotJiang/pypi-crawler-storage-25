"""Red Codens MCP tools: bug reports, fix plans, fix proposals, and Purple submission."""

from typing import Any, Optional

from mcp.server.fastmcp import FastMCP

from ..client.auth_helper import load_codens_credentials
from ..client.red import RedClient


def _client(api_url: str) -> RedClient:
    creds = load_codens_credentials(api_url, service="red")
    return RedClient(api_url, creds.token)


def register_red_tools(mcp: FastMCP) -> None:

    # ─── Bug Reports ────────────────────────────────────────────────────────

    @mcp.tool()
    async def red_create_bug_report(
        api_url: str,
        organization_id: str,
        project_id: str,
        title: str,
        description: str,
        severity: str = "medium",
        steps_to_reproduce: Optional[str] = None,
        expected_behavior: Optional[str] = None,
        actual_behavior: Optional[str] = None,
        affected_files: Optional[list[str]] = None,
        auto_analyze: bool = True,
        attachment_urls: Optional[list[str]] = None,
    ) -> dict:
        """
        Create a bug report via the agent endpoint.

        Path: POST /api/v1/agent/create-bug-report

        Args:
            api_url: Red Codens API base URL
            organization_id: Organization ID
            project_id: Project ID
            title: Bug report title
            description: Bug description
            severity: Bug severity (critical, high, medium, low, info)
            steps_to_reproduce: Optional steps to reproduce
            expected_behavior: Optional expected behavior
            actual_behavior: Optional actual behavior observed
            affected_files: Optional list of affected file paths
            auto_analyze: Whether to auto-trigger Claude analysis (default: true)
            attachment_urls: Optional list of attachment URLs (screenshots, logs)
        """
        body: dict[str, Any] = {
            "organization_id": organization_id,
            "project_id": project_id,
            "title": title,
            "description": description,
            "severity": severity,
            "auto_analyze": auto_analyze,
        }
        if steps_to_reproduce is not None:
            body["steps_to_reproduce"] = steps_to_reproduce
        if expected_behavior is not None:
            body["expected_behavior"] = expected_behavior
        if actual_behavior is not None:
            body["actual_behavior"] = actual_behavior
        if affected_files is not None:
            body["affected_files"] = affected_files
        if attachment_urls:
            body["attachment_urls"] = attachment_urls
        return _client(api_url).post("/api/v1/agent/create-bug-report", json=body)

    @mcp.tool()
    async def red_create_bug_report_full(
        api_url: str,
        organization_id: str,
        project_id: str,
        title: str,
        description: str,
        severity: str = "medium",
        steps_to_reproduce: Optional[str] = None,
        expected_behavior: Optional[str] = None,
        actual_behavior: Optional[str] = None,
        affected_files: Optional[list[str]] = None,
        auto_analyze: bool = True,
    ) -> dict:
        """
        Create a bug report via the standard API (full schema).

        Path: POST /api/v1/organizations/{organization_id}/projects/{project_id}/bug-reports

        Args:
            api_url: Red Codens API base URL
            organization_id: Organization ID
            project_id: Project ID
            title: Bug report title
            description: Bug description
            severity: Bug severity (critical, high, medium, low, info)
            steps_to_reproduce: Optional steps to reproduce
            expected_behavior: Optional expected behavior
            actual_behavior: Optional actual behavior observed
            affected_files: Optional list of affected file paths
            auto_analyze: Whether to auto-trigger Claude analysis (default: true)
        """
        body: dict[str, Any] = {
            "title": title,
            "description": description,
            "severity": severity,
            "auto_analyze": auto_analyze,
        }
        if steps_to_reproduce is not None:
            body["steps_to_reproduce"] = steps_to_reproduce
        if expected_behavior is not None:
            body["expected_behavior"] = expected_behavior
        if actual_behavior is not None:
            body["actual_behavior"] = actual_behavior
        if affected_files is not None:
            body["affected_files"] = affected_files
        return _client(api_url).post(
            f"/api/v1/organizations/{organization_id}/projects/{project_id}/bug-reports",
            json=body,
        )

    @mcp.tool()
    async def red_list_bug_reports(
        api_url: str,
        organization_id: str,
        project_id: str,
        status: Optional[str] = None,
        severity: Optional[str] = None,
        limit: int = 50,
        offset: int = 0,
    ) -> dict:
        """
        List bug reports for a project.

        Path: GET /api/v1/organizations/{organization_id}/projects/{project_id}/bug-reports

        Args:
            api_url: Red Codens API base URL
            organization_id: Organization ID
            project_id: Project ID
            status: Optional status filter (pending, analyzing, proposal_generated, fixed, closed, failed)
            severity: Optional severity filter (critical, high, medium, low, info)
            limit: Max results per page (default: 50)
            offset: Pagination offset (default: 0)
        """
        params: dict[str, Any] = {"limit": limit, "offset": offset}
        if status is not None:
            params["status"] = status
        if severity is not None:
            params["severity"] = severity
        return _client(api_url).get(
            f"/api/v1/organizations/{organization_id}/projects/{project_id}/bug-reports",
            params=params,
        )

    @mcp.tool()
    async def red_get_bug_report(
        api_url: str,
        organization_id: str,
        bug_id: str,
    ) -> dict:
        """
        Get a bug report by ID.

        Path: GET /api/v1/organizations/{organization_id}/bug-reports/{bug_id}

        Args:
            api_url: Red Codens API base URL
            organization_id: Organization ID
            bug_id: Bug report ID
        """
        return _client(api_url).get(
            f"/api/v1/organizations/{organization_id}/bug-reports/{bug_id}"
        )

    @mcp.tool()
    async def red_update_bug_report(
        api_url: str,
        organization_id: str,
        bug_id: str,
        title: Optional[str] = None,
        description: Optional[str] = None,
        severity: Optional[str] = None,
        steps_to_reproduce: Optional[str] = None,
        expected_behavior: Optional[str] = None,
        actual_behavior: Optional[str] = None,
        status: Optional[str] = None,
        affected_files: Optional[list[str]] = None,
    ) -> dict:
        """
        Update a bug report.

        Path: PATCH /api/v1/organizations/{organization_id}/bug-reports/{bug_id}

        Args:
            api_url: Red Codens API base URL
            organization_id: Organization ID
            bug_id: Bug report ID
            title: Optional new title
            description: Optional new description
            severity: Optional new severity
            steps_to_reproduce: Optional new steps to reproduce
            expected_behavior: Optional new expected behavior
            actual_behavior: Optional new actual behavior
            status: Optional new status (pending, analyzing, proposal_generated, fixed, closed, failed)
            affected_files: Optional list of affected file paths
        """
        body: dict[str, Any] = {}
        if title is not None:
            body["title"] = title
        if description is not None:
            body["description"] = description
        if severity is not None:
            body["severity"] = severity
        if steps_to_reproduce is not None:
            body["steps_to_reproduce"] = steps_to_reproduce
        if expected_behavior is not None:
            body["expected_behavior"] = expected_behavior
        if actual_behavior is not None:
            body["actual_behavior"] = actual_behavior
        if status is not None:
            body["status"] = status
        if affected_files is not None:
            body["affected_files"] = affected_files
        return _client(api_url).patch(
            f"/api/v1/organizations/{organization_id}/bug-reports/{bug_id}",
            json=body,
        )

    @mcp.tool()
    async def red_analyze_bug_report(
        api_url: str,
        organization_id: str,
        bug_id: str,
    ) -> dict:
        """
        Trigger AI analysis for a bug report.

        Path: POST /api/v1/organizations/{organization_id}/bug-reports/{bug_id}/analyze

        Args:
            api_url: Red Codens API base URL
            organization_id: Organization ID
            bug_id: Bug report ID
        """
        return _client(api_url).post(
            f"/api/v1/organizations/{organization_id}/bug-reports/{bug_id}/analyze",
            json={},
        )

    @mcp.tool()
    async def red_retry_bug_analysis(
        api_url: str,
        organization_id: str,
        bug_id: str,
    ) -> dict:
        """
        Retry AI analysis for a bug report (e.g., after updating the description).

        Path: POST /api/v1/organizations/{organization_id}/bug-reports/{bug_id}/retry-analyze

        Args:
            api_url: Red Codens API base URL
            organization_id: Organization ID
            bug_id: Bug report ID
        """
        return _client(api_url).post(
            f"/api/v1/organizations/{organization_id}/bug-reports/{bug_id}/retry-analyze",
            json={},
        )

    # ─── Bug Fix Plans (→ Purple) ────────────────────────────────────────────

    @mcp.tool()
    async def red_generate_bug_fix_plan(
        api_url: str,
        organization_id: str,
        project_id: str,
        bug_id: str,
        mode: str = "append",
    ) -> dict:
        """
        Generate a bug fix plan from a bug report using Purple Codens analyze-with-repo (async).

        This is the key step between bug analysis and Purple execution — it creates
        a BugFixPlan, dispatches Purple's analyze-with-repo, and materializes BugFixTasks.

        Path: POST /api/v1/organizations/{org}/projects/{proj}/bug-reports/{bug_id}/generate-plan

        Args:
            api_url: Red Codens API base URL
            organization_id: Organization ID
            project_id: Project ID
            bug_id: Bug report ID
            mode: "append" (keep existing tasks) or "full_replace" (delete all, regenerate)
        """
        return _client(api_url).post(
            f"/api/v1/organizations/{organization_id}/projects/{project_id}/bug-reports/{bug_id}/generate-plan",
            json={"mode": mode},
        )

    @mcp.tool()
    async def red_get_bug_fix_plan(
        api_url: str,
        organization_id: str,
        plan_id: str,
    ) -> dict:
        """
        Get bug fix plan details including tasks and generation status.

        Path: GET /api/v1/organizations/{organization_id}/bug-fix-plans/{plan_id}

        Args:
            api_url: Red Codens API base URL
            organization_id: Organization ID
            plan_id: Bug fix plan ID
        """
        return _client(api_url).get(
            f"/api/v1/organizations/{organization_id}/bug-fix-plans/{plan_id}"
        )

    @mcp.tool()
    async def red_get_bug_fix_plan_by_bug(
        api_url: str,
        organization_id: str,
        project_id: str,
        bug_id: str,
    ) -> dict:
        """
        Get the bug fix plan associated with a bug report.

        Path: GET /api/v1/organizations/{org}/projects/{proj}/bug-reports/{bug_id}/bug-fix-plan

        Args:
            api_url: Red Codens API base URL
            organization_id: Organization ID
            project_id: Project ID
            bug_id: Bug report ID
        """
        return _client(api_url).get(
            f"/api/v1/organizations/{organization_id}/projects/{project_id}/bug-reports/{bug_id}/bug-fix-plan"
        )

    @mcp.tool()
    async def red_submit_bug_fix_plan_to_purple(
        api_url: str,
        organization_id: str,
        plan_id: str,
        task_ids: Optional[list[str]] = None,
    ) -> dict:
        """
        Submit DRAFT BugFixTasks of a plan to Purple Codens for execution.

        Path: POST /api/v1/organizations/{organization_id}/bug-fix-plans/{plan_id}/submit

        Args:
            api_url: Red Codens API base URL
            organization_id: Organization ID
            plan_id: Bug fix plan ID
            task_ids: Optional list of task IDs to submit (if omitted, submits all DRAFT tasks)
        """
        body: dict[str, Any] = {}
        if task_ids is not None:
            body["task_ids"] = task_ids
        return _client(api_url).post(
            f"/api/v1/organizations/{organization_id}/bug-fix-plans/{plan_id}/submit",
            json=body,
        )

    @mcp.tool()
    async def red_resubmit_bug_fix_plan(
        api_url: str,
        organization_id: str,
        plan_id: str,
        task_ids: Optional[list[str]] = None,
    ) -> dict:
        """
        Resubmit previously-submitted BugFixTasks to Purple (e.g., after retries or fixes).

        Path: POST /api/v1/organizations/{organization_id}/bug-fix-plans/{plan_id}/resubmit

        Args:
            api_url: Red Codens API base URL
            organization_id: Organization ID
            plan_id: Bug fix plan ID
            task_ids: Optional list of task IDs to resubmit
        """
        body: dict[str, Any] = {}
        if task_ids is not None:
            body["task_ids"] = task_ids
        return _client(api_url).post(
            f"/api/v1/organizations/{organization_id}/bug-fix-plans/{plan_id}/resubmit",
            json=body,
        )

    # ─── Fix Proposals ───────────────────────────────────────────────────────

    @mcp.tool()
    async def red_create_fix_proposal(
        api_url: str,
        error_id: str,
        fix_description: str,
        fix_diff: str,
        confidence_score: float = 0.5,
        root_cause: Optional[str] = None,
    ) -> dict:
        """
        Create a fix proposal for an error.

        Path: POST /api/v1/proposals

        Args:
            api_url: Red Codens API base URL
            error_id: Error log ID this proposal addresses
            fix_description: Description of the proposed fix
            fix_diff: Diff patch for the fix
            confidence_score: Confidence score (0.0-1.0)
            root_cause: Optional root cause analysis
        """
        body: dict[str, Any] = {
            "error_id": error_id,
            "fix_description": fix_description,
            "fix_diff": fix_diff,
            "confidence_score": confidence_score,
        }
        if root_cause is not None:
            body["root_cause"] = root_cause
        return _client(api_url).post("/api/v1/proposals", json=body)

    @mcp.tool()
    async def red_list_fix_proposals(
        api_url: str,
        error_id: Optional[str] = None,
        status: Optional[str] = None,
    ) -> dict:
        """
        List fix proposals, optionally filtered by error ID or status.

        Path: GET /api/v1/proposals

        Args:
            api_url: Red Codens API base URL
            error_id: Optional error ID to filter by
            status: Optional status filter
        """
        params: dict[str, Any] = {}
        if error_id is not None:
            params["error_id"] = error_id
        if status is not None:
            params["status"] = status
        return _client(api_url).get("/api/v1/proposals", params=params if params else None)

    @mcp.tool()
    async def red_get_fix_proposal(
        api_url: str,
        proposal_id: str,
    ) -> dict:
        """
        Get a fix proposal by ID.

        Path: GET /api/v1/proposals/{proposal_id}

        Args:
            api_url: Red Codens API base URL
            proposal_id: Fix proposal ID
        """
        return _client(api_url).get(f"/api/v1/proposals/{proposal_id}")

    @mcp.tool()
    async def red_get_fix_proposals_by_error(
        api_url: str,
        error_id: str,
    ) -> dict:
        """
        Get all fix proposals for a specific error.

        Path: GET /api/v1/proposals/error/{error_id}

        Args:
            api_url: Red Codens API base URL
            error_id: Error log ID
        """
        return _client(api_url).get(f"/api/v1/proposals/error/{error_id}")

    # ─── External Tasks ──────────────────────────────────────────────────────

    @mcp.tool()
    async def red_list_external_tasks(
        api_url: str,
        project_id: str,
        status: Optional[str] = None,
    ) -> dict:
        """
        List external tasks for a project.

        Path: GET /api/v1/external/{project_id}

        Args:
            api_url: Red Codens API base URL
            project_id: Project ID
            status: Optional status filter
        """
        params: dict[str, Any] = {}
        if status is not None:
            params["status"] = status
        return _client(api_url).get(
            f"/api/v1/external/{project_id}",
            params=params if params else None,
        )

    @mcp.tool()
    async def red_get_external_task(
        api_url: str,
        task_id: str,
    ) -> dict:
        """
        Get an external task by ID.

        Path: GET /api/v1/external/task/{task_id}

        Args:
            api_url: Red Codens API base URL
            task_id: External task ID
        """
        return _client(api_url).get(f"/api/v1/external/task/{task_id}")

    @mcp.tool()
    async def red_execute_external_task(
        api_url: str,
        task_id: str,
    ) -> dict:
        """
        Execute an external task.

        Path: POST /api/v1/external/task/{task_id}/execute

        Args:
            api_url: Red Codens API base URL
            task_id: External task ID
        """
        return _client(api_url).post(
            f"/api/v1/external/task/{task_id}/execute",
            json={},
        )
