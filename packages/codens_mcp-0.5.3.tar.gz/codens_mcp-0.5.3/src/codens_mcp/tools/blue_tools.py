"""Blue Codens MCP tools: E2E test generation and execution."""

from mcp.server.fastmcp import FastMCP

from ..client.auth_helper import load_codens_credentials
from ..client.blue import BlueClient


def _client(api_url: str) -> BlueClient:
    creds = load_codens_credentials(api_url, service="blue")
    return BlueClient(api_url, creds.token)


def register_blue_tools(mcp: FastMCP) -> None:

    @mcp.tool()
    async def blue_list_e2e_tests(
        api_url: str,
        page: int = 1,
        page_size: int = 20,
    ) -> dict:
        """
        List E2E tests.

        Path: GET /api/v1/e2e-tests

        Args:
            api_url: Blue Codens API base URL
            page: Page number (default: 1)
            page_size: Results per page (default: 20)
        """
        return _client(api_url).get(
            "/api/v1/e2e-tests",
            params={"page": page, "page_size": page_size},
        )

    @mcp.tool()
    async def blue_generate_e2e_test(
        api_url: str,
        project_id: str,
        requirement: str,
        language: str = "playwright",
    ) -> dict:
        """
        Generate an E2E test from a natural-language requirement.

        Path: POST /api/v1/ai/generate/e2e-test

        Args:
            api_url: Blue Codens API base URL
            project_id: Project ID
            requirement: Natural-language description of the test scenario
            language: Test framework (default: playwright)
        """
        return _client(api_url).post(
            "/api/v1/ai/generate/e2e-test",
            json={
                "project_id": project_id,
                "requirement": requirement,
                "language": language,
            },
        )

    @mcp.tool()
    async def blue_run_e2e_test(
        api_url: str,
        e2e_test_id: str,
    ) -> dict:
        """
        Trigger a run for an existing E2E test.

        Path: POST /api/v1/e2e-tests/{e2e_test_id}/run

        Args:
            api_url: Blue Codens API base URL
            e2e_test_id: E2E test ID
        """
        return _client(api_url).post(f"/api/v1/e2e-tests/{e2e_test_id}/run", json={})

    @mcp.tool()
    async def blue_get_e2e_test_results(
        api_url: str,
        e2e_test_id: str,
    ) -> dict:
        """
        Get results for an E2E test (latest run).

        Path: GET /api/v1/e2e-tests/{e2e_test_id}/results

        Args:
            api_url: Blue Codens API base URL
            e2e_test_id: E2E test ID
        """
        return _client(api_url).get(f"/api/v1/e2e-tests/{e2e_test_id}/results")
