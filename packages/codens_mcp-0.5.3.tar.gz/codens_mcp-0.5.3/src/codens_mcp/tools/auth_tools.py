"""Auth Codens MCP tools: agent signup and public pricing."""

from mcp.server.fastmcp import FastMCP

from ..client.auth import AuthClient


def register_auth_tools(mcp: FastMCP) -> None:

    @mcp.tool()
    async def auth_agent_signup(
        api_url: str,
        existing_api_key: str,
        agent_identity_token: str,
        agent_identity_provider: str = "anthropic",
    ) -> dict:
        """
        Issue a capability_token and register an agent member via the existing user's API key.

        Path: POST /api/v1/auth/agent-signup

        Args:
            api_url: Auth Codens API base URL
            existing_api_key: The user's existing API key (used to authorize agent registration)
            agent_identity_token: Identity token issued by the agent provider
            agent_identity_provider: Provider name (default: anthropic)
        """
        return AuthClient(api_url).post(
            "/api/v1/auth/agent-signup",
            json={
                "existing_api_key": existing_api_key,
                "agent_identity_token": agent_identity_token,
                "agent_identity_provider": agent_identity_provider,
            },
        )

    @mcp.tool()
    async def auth_get_pricing(api_url: str) -> dict:
        """
        Return the public pricing.json (proxied from BCP, 5-min cache + fallback). No auth required.

        Path: GET /.well-known/pricing.json

        Args:
            api_url: Auth Codens API base URL
        """
        return AuthClient(api_url).get_no_auth("/.well-known/pricing.json")
