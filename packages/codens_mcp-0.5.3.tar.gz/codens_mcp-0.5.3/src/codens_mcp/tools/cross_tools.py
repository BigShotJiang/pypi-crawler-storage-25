"""Cross-product Codens MCP tools."""

from typing import Any, List, Optional

from mcp.server.fastmcp import FastMCP

from ..client.auth_helper import load_codens_credentials
from ..client.blue import BlueClient
from ..client.green import GreenClient
from ..client.red import RedClient

try:
    from purple_codens_mcp.client import PurpleCodensClient
except ImportError:  # pragma: no cover
    PurpleCodensClient = None  # type: ignore[assignment,misc]


def _red_client(api_url: str) -> RedClient:
    creds = load_codens_credentials(api_url, service="red")
    return RedClient(api_url, creds.token)


def _blue_client(api_url: str) -> BlueClient:
    creds = load_codens_credentials(api_url, service="blue")
    return BlueClient(api_url, creds.token)


def _green_client(api_url: str) -> GreenClient:
    creds = load_codens_credentials(api_url, service="green")
    return GreenClient(api_url, creds.token)


def register_cross_tools(mcp: FastMCP) -> None:

    @mcp.tool()
    async def codens_register_project_unified(
        api_url: str,
        name: str,
        github_owner: str,
        github_repo: str,
        products: List[str] = ["purple", "red", "blue", "green"],
        description: Optional[str] = None,
    ) -> dict:
        """Register the same project across the requested Codens products.

        Calls each product's project-create endpoint in sequence (best-effort: a failure
        in one product does not prevent registration in the others).

        Args:
            api_url: Codens API base URL (shared across all products via Auth Codens SSO)
            name: Project name
            github_owner: GitHub repository owner (org or user)
            github_repo: GitHub repository name
            products: Subset of products to register in (default: all four)
            description: Optional project description

        Returns:
            {
              "purple_project_id": "...",
              "red_project_id":    "...",
              "blue_project_id":   "...",
              "green_project_id":  "...",
              "errors": [],
            }
        """
        result: dict[str, Any] = {
            "purple_project_id": None,
            "red_project_id": None,
            "blue_project_id": None,
            "green_project_id": None,
            "errors": [],
        }

        payload: dict[str, Any] = {
            "name": name,
            "github_owner": github_owner,
            "github_repo": github_repo,
        }
        if description is not None:
            payload["description"] = description

        for product in products:
            try:
                if product == "purple":
                    if PurpleCodensClient is None:
                        raise RuntimeError("purple-codens-mcp is not installed")
                    client = PurpleCodensClient(api_url)
                    resp = client.post("/api/v1/projects", json=payload)
                    result["purple_project_id"] = resp.get("id")
                elif product == "red":
                    resp = _red_client(api_url).post("/api/v1/projects", json=payload)
                    result["red_project_id"] = resp.get("id")
                elif product == "blue":
                    resp = _blue_client(api_url).post("/api/v1/projects", json=payload)
                    result["blue_project_id"] = resp.get("id")
                elif product == "green":
                    resp = _green_client(api_url).post("/api/v1/projects", json=payload)
                    result["green_project_id"] = resp.get("id")
                else:
                    result["errors"].append(
                        {"product": product, "error_message": f"Unknown product: {product}"}
                    )
            except Exception as exc:
                result["errors"].append({"product": product, "error_message": str(exc)})

        return result
