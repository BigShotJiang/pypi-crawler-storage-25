"""Green Codens MCP tools: PRD consultations, kickoffs, PRD CRUD, plan generation, and Notion integration."""

from typing import Any, Optional

from mcp.server.fastmcp import FastMCP

from ..client.auth_helper import load_codens_credentials
from ..client.green import GreenClient


def _client(api_url: str) -> GreenClient:
    creds = load_codens_credentials(api_url, service="green")
    return GreenClient(api_url, creds.token)


def register_green_tools(mcp: FastMCP) -> None:

    @mcp.tool()
    async def green_create_consultation_with_message(
        api_url: str,
        organization_id: str,
        project_id: str,
        message: str,
    ) -> dict:
        """
        Create a new consultation session and send the first message in one call (lazy creation).

        Path: POST /api/v1/organizations/{organization_id}/consultations/with-message

        Args:
            api_url: Green Codens API base URL
            organization_id: Organization ID
            project_id: Project ID
            message: First message to send in the consultation
        """
        return _client(api_url).post(
            f"/api/v1/organizations/{organization_id}/consultations/with-message",
            json={"project_id": project_id, "message": message},
        )

    @mcp.tool()
    async def green_send_consultation_message(
        api_url: str,
        organization_id: str,
        consultation_id: str,
        message: str,
    ) -> dict:
        """
        Send a message in an existing consultation and get the AI reply.

        Path: POST /api/v1/organizations/{organization_id}/consultations/{consultation_id}/messages

        Args:
            api_url: Green Codens API base URL
            organization_id: Organization ID
            consultation_id: Consultation session ID
            message: Message to send
        """
        return _client(api_url).post(
            f"/api/v1/organizations/{organization_id}/consultations/{consultation_id}/messages",
            json={"message": message},
        )

    @mcp.tool()
    async def green_convert_consultation_to_prd(
        api_url: str,
        organization_id: str,
        consultation_id: str,
        title: Optional[str] = None,
    ) -> dict:
        """
        Convert a consultation session into a PRD.

        Path: POST /api/v1/organizations/{organization_id}/consultations/{consultation_id}/convert-to-prd

        Args:
            api_url: Green Codens API base URL
            organization_id: Organization ID
            consultation_id: Consultation session ID
            title: Optional PRD title (auto-generated if omitted)
        """
        body = {"title": title} if title else {}
        return _client(api_url).post(
            f"/api/v1/organizations/{organization_id}/consultations/{consultation_id}/convert-to-prd",
            json=body,
        )

    @mcp.tool()
    async def green_create_kickoff(
        api_url: str,
        organization_id: str,
        project_id: str,
        title: str,
        description: str,
    ) -> dict:
        """
        Create a Kickoff in Green Codens.

        Path: POST /api/v1/organizations/{organization_id}/kickoffs

        Args:
            api_url: Green Codens API base URL
            organization_id: Organization ID
            project_id: Project ID
            title: Kickoff title
            description: Kickoff description
        """
        return _client(api_url).post(
            f"/api/v1/organizations/{organization_id}/kickoffs",
            json={
                "project_id": project_id,
                "title": title,
                "description": description,
            },
        )

    @mcp.tool()
    async def green_notion_link(
        api_url: str,
        organization_id: str,
        notion_api_key: str,
        notion_database_id: str,
        sync_direction: str = "both",
    ) -> dict:
        """
        Register a Notion Internal Integration Token for an organization.

        Tests the API key against the Notion databases.retrieve endpoint before
        saving. On success returns { "ok": true, "integration_id": "...", "status": "active" }.
        On invalid credentials returns { "ok": false, "error_code": "INVALID_NOTION_CREDENTIALS" }.

        Path: POST /api/v1/organizations/{organization_id}/notion-integration

        Args:
            api_url: Green Codens API base URL
            organization_id: Organization ID
            notion_api_key: Notion Internal Integration Token (secret_...)
            notion_database_id: Notion database ID to link
            sync_direction: "both" | "to_notion" | "from_notion" (default: "both")
        """
        return _client(api_url).post(
            f"/api/v1/organizations/{organization_id}/notion-integration",
            json={
                "notion_api_key": notion_api_key,
                "notion_database_id": notion_database_id,
                "sync_direction": sync_direction,
            },
        )

    @mcp.tool()
    async def green_notion_unlink(
        api_url: str,
        organization_id: str,
    ) -> dict:
        """
        Remove the Notion API key integration for an organization.

        Path: DELETE /api/v1/organizations/{organization_id}/notion-integration

        Args:
            api_url: Green Codens API base URL
            organization_id: Organization ID
        """
        return _client(api_url).delete(
            f"/api/v1/organizations/{organization_id}/notion-integration"
        )

    @mcp.tool()
    async def green_notion_status(
        api_url: str,
        organization_id: str,
    ) -> dict:
        """
        Get the Notion API key integration status for an organization.

        Returns { "linked": bool, "database_id": str|null, "sync_direction": str|null,
                  "last_sync_at": str|null, "synced_prd_count": int }.

        Path: GET /api/v1/organizations/{organization_id}/notion-integration

        Args:
            api_url: Green Codens API base URL
            organization_id: Organization ID
        """
        return _client(api_url).get(
            f"/api/v1/organizations/{organization_id}/notion-integration"
        )

    # ─── PRD CRUD ───────────────────────────────────────────────────────────

    @mcp.tool()
    async def green_create_prd(
        api_url: str,
        organization_id: str,
        project_id: str,
        title: str,
        template_id: str,
        original_input: Optional[str] = None,
        content: Optional[Any] = None,
    ) -> dict:
        """
        Create a new PRD directly (without consultation).

        Path: POST /api/v1/organizations/{organization_id}/projects/{project_id}/prds

        Args:
            api_url: Green Codens API base URL
            organization_id: Organization ID
            project_id: Project ID
            title: PRD title
            template_id: PRD template ID
            original_input: Optional free-text input that prompted this PRD
            content: Optional structured PRD content (dict)
        """
        body: dict[str, Any] = {"title": title, "template_id": template_id}
        if original_input is not None:
            body["original_input"] = original_input
        if content is not None:
            body["content"] = content
        return _client(api_url).post(
            f"/api/v1/organizations/{organization_id}/projects/{project_id}/prds",
            json=body,
        )

    @mcp.tool()
    async def green_list_prds(
        api_url: str,
        organization_id: str,
        project_id: str,
        status: Optional[str] = None,
        limit: int = 50,
        offset: int = 0,
    ) -> dict:
        """
        List PRDs for a project.

        Path: GET /api/v1/organizations/{organization_id}/projects/{project_id}/prds

        Args:
            api_url: Green Codens API base URL
            organization_id: Organization ID
            project_id: Project ID
            status: Optional status filter (e.g., "draft", "review", "approved")
            limit: Max results per page (default: 50)
            offset: Pagination offset (default: 0)
        """
        params: dict[str, Any] = {"limit": limit, "offset": offset}
        if status is not None:
            params["status"] = status
        return _client(api_url).get(
            f"/api/v1/organizations/{organization_id}/projects/{project_id}/prds",
            params=params,
        )

    @mcp.tool()
    async def green_get_prd(
        api_url: str,
        organization_id: str,
        project_id: str,
        prd_id: str,
    ) -> dict:
        """
        Get details of a specific PRD.

        Path: GET /api/v1/organizations/{organization_id}/projects/{project_id}/prds/{prd_id}

        Args:
            api_url: Green Codens API base URL
            organization_id: Organization ID
            project_id: Project ID
            prd_id: PRD ID
        """
        return _client(api_url).get(
            f"/api/v1/organizations/{organization_id}/projects/{project_id}/prds/{prd_id}"
        )

    @mcp.tool()
    async def green_update_prd(
        api_url: str,
        organization_id: str,
        project_id: str,
        prd_id: str,
        title: Optional[str] = None,
        content: Optional[Any] = None,
        original_input: Optional[str] = None,
    ) -> dict:
        """
        Update a PRD's title, content, or original input.

        Path: PATCH /api/v1/organizations/{organization_id}/projects/{project_id}/prds/{prd_id}

        Args:
            api_url: Green Codens API base URL
            organization_id: Organization ID
            project_id: Project ID
            prd_id: PRD ID
            title: Optional new title
            content: Optional new structured content (dict)
            original_input: Optional new original input text
        """
        body: dict[str, Any] = {}
        if title is not None:
            body["title"] = title
        if content is not None:
            body["content"] = content
        if original_input is not None:
            body["original_input"] = original_input
        return _client(api_url).patch(
            f"/api/v1/organizations/{organization_id}/projects/{project_id}/prds/{prd_id}",
            json=body,
        )

    # ─── AI PRD Generation ──────────────────────────────────────────────────

    @mcp.tool()
    async def green_generate_prd_with_ai(
        api_url: str,
        organization_id: str,
        project_id: str,
        template_id: str,
        free_text: str,
        title: Optional[str] = None,
        use_codebase: bool = False,
    ) -> dict:
        """
        Generate a PRD using AI (async). Returns a task_id immediately;
        poll the result using the task_id from the response.

        Path: POST /api/v1/organizations/{organization_id}/projects/{project_id}/prds/generate-with-ai

        Args:
            api_url: Green Codens API base URL
            organization_id: Organization ID
            project_id: Project ID
            template_id: PRD template ID
            free_text: Free-text description of the product (min 5 chars)
            title: Optional PRD title (auto-generated if omitted)
            use_codebase: Whether to incorporate codebase context (default: false)
        """
        body: dict[str, Any] = {
            "template_id": template_id,
            "free_text": free_text,
            "use_codebase": use_codebase,
        }
        if title is not None:
            body["title"] = title
        return _client(api_url).post(
            f"/api/v1/organizations/{organization_id}/projects/{project_id}/prds/generate-with-ai",
            json=body,
        )

    # ─── PRD Workflow ────────────────────────────────────────────────────────

    @mcp.tool()
    async def green_approve_prd(
        api_url: str,
        organization_id: str,
        project_id: str,
        prd_id: str,
        comment: Optional[str] = None,
    ) -> dict:
        """
        Approve a PRD, transitioning it to the approved status.

        Path: POST /api/v1/organizations/{organization_id}/projects/{project_id}/prds/{prd_id}/approve

        Args:
            api_url: Green Codens API base URL
            organization_id: Organization ID
            project_id: Project ID
            prd_id: PRD ID
            comment: Optional approval comment
        """
        body: dict[str, Any] = {}
        if comment is not None:
            body["comment"] = comment
        return _client(api_url).post(
            f"/api/v1/organizations/{organization_id}/projects/{project_id}/prds/{prd_id}/approve",
            json=body,
        )

    @mcp.tool()
    async def green_submit_prd_for_review(
        api_url: str,
        organization_id: str,
        project_id: str,
        prd_id: str,
        reviewer_id: str,
    ) -> dict:
        """
        Submit a PRD for review by a specific user.

        Path: POST /api/v1/organizations/{organization_id}/projects/{project_id}/prds/{prd_id}/submit-for-review

        Args:
            api_url: Green Codens API base URL
            organization_id: Organization ID
            project_id: Project ID
            prd_id: PRD ID
            reviewer_id: User ID of the reviewer
        """
        return _client(api_url).post(
            f"/api/v1/organizations/{organization_id}/projects/{project_id}/prds/{prd_id}/submit-for-review",
            json={"reviewer_id": reviewer_id},
        )

    # ─── Implementation Plan ─────────────────────────────────────────────────

    @mcp.tool()
    async def green_generate_plan_from_prd(
        api_url: str,
        organization_id: str,
        project_id: str,
        prd_id: str,
        mode: str = "append",
    ) -> dict:
        """
        Generate an implementation plan from a PRD using AI (async).

        Path: POST /api/v1/organizations/{organization_id}/projects/{project_id}/prds/{prd_id}/generate-plan

        Args:
            api_url: Green Codens API base URL
            organization_id: Organization ID
            project_id: Project ID
            prd_id: PRD ID
            mode: "append" (keep existing tasks, add new ones) or "full_replace" (delete all, regenerate)
        """
        return _client(api_url).post(
            f"/api/v1/organizations/{organization_id}/projects/{project_id}/prds/{prd_id}/generate-plan",
            json={"mode": mode},
        )

    @mcp.tool()
    async def green_get_plan(
        api_url: str,
        organization_id: str,
        plan_id: str,
    ) -> dict:
        """
        Get plan details including tasks and generation status.

        Path: GET /api/v1/organizations/{organization_id}/plans/{plan_id}

        Args:
            api_url: Green Codens API base URL
            organization_id: Organization ID
            plan_id: Plan ID
        """
        return _client(api_url).get(
            f"/api/v1/organizations/{organization_id}/plans/{plan_id}"
        )

    # ─── Submit Plan to Purple Codens ────────────────────────────────────────

    @mcp.tool()
    async def green_submit_plan_to_purple(
        api_url: str,
        organization_id: str,
        plan_id: str,
        task_ids: Optional[list[str]] = None,
    ) -> dict:
        """
        Submit a plan (or specific tasks) to Purple Codens for execution.

        Path: POST /api/v1/organizations/{organization_id}/plans/{plan_id}/submit

        Args:
            api_url: Green Codens API base URL
            organization_id: Organization ID
            plan_id: Plan ID
            task_ids: Optional list of task IDs to submit (if omitted, submits all unsubmitted tasks)
        """
        body: dict[str, Any] = {}
        if task_ids is not None:
            body["task_ids"] = task_ids
        return _client(api_url).post(
            f"/api/v1/organizations/{organization_id}/plans/{plan_id}/submit",
            json=body,
        )

    # ─── Plan CRUD (additional) ──────────────────────────────────────────────

    @mcp.tool()
    async def green_list_plans(
        api_url: str,
        organization_id: str,
    ) -> dict:
        """
        List all plans for an organization.

        Path: GET /api/v1/organizations/{organization_id}/plans

        Args:
            api_url: Green Codens API base URL
            organization_id: Organization ID
        """
        return _client(api_url).get(
            f"/api/v1/organizations/{organization_id}/plans"
        )

    @mcp.tool()
    async def green_list_plans_by_project(
        api_url: str,
        project_id: str,
    ) -> dict:
        """
        List plans scoped to a specific project.

        Path: GET /api/v1/projects/{project_id}/plans

        Args:
            api_url: Green Codens API base URL
            project_id: Project ID
        """
        return _client(api_url).get(f"/api/v1/projects/{project_id}/plans")

    @mcp.tool()
    async def green_create_plan(
        api_url: str,
        organization_id: str,
        title: str,
        project_id: str,
        description: Optional[str] = None,
        notion_database_id: Optional[str] = None,
        prd_id: Optional[str] = None,
        kickoff_id: Optional[str] = None,
    ) -> dict:
        """
        Create a new implementation plan.

        Path: POST /api/v1/organizations/{organization_id}/plans

        Args:
            api_url: Green Codens API base URL
            organization_id: Organization ID
            title: Plan title
            project_id: Project ID
            description: Optional plan description
            notion_database_id: Optional Notion database ID
            prd_id: Optional associated PRD ID
            kickoff_id: Optional associated Kickoff ID
        """
        body: dict[str, Any] = {
            "title": title,
            "project_id": project_id,
        }
        if description is not None:
            body["description"] = description
        if notion_database_id is not None:
            body["notion_database_id"] = notion_database_id
        if prd_id is not None:
            body["prd_id"] = prd_id
        if kickoff_id is not None:
            body["kickoff_id"] = kickoff_id
        return _client(api_url).post(
            f"/api/v1/organizations/{organization_id}/plans",
            json=body,
        )

    @mcp.tool()
    async def green_update_plan(
        api_url: str,
        organization_id: str,
        plan_id: str,
        title: Optional[str] = None,
        description: Optional[str] = None,
        project_id: Optional[str] = None,
    ) -> dict:
        """
        Update a plan's title, description, or project_id.

        Path: PUT /api/v1/organizations/{organization_id}/plans/{plan_id}

        Args:
            api_url: Green Codens API base URL
            organization_id: Organization ID
            plan_id: Plan ID
            title: Optional new title
            description: Optional new description
            project_id: Optional new project ID
        """
        body: dict[str, Any] = {}
        if title is not None:
            body["title"] = title
        if description is not None:
            body["description"] = description
        if project_id is not None:
            body["project_id"] = project_id
        return _client(api_url).put(
            f"/api/v1/organizations/{organization_id}/plans/{plan_id}",
            json=body,
        )

    @mcp.tool()
    async def green_create_plan_version(
        api_url: str,
        organization_id: str,
        plan_id: str,
        body_markdown: str,
        tasks: list[dict[str, Any]],
        changelog_text: Optional[str] = None,
    ) -> dict:
        """
        Create a new PlanVersion and upsert tasks.

        Path: POST /api/v1/organizations/{organization_id}/plans/{plan_id}/versions

        Args:
            api_url: Green Codens API base URL
            organization_id: Organization ID
            plan_id: Plan ID
            body_markdown: Markdown body for the plan version
            tasks: List of task dicts (title, sequence, goal_body_markdown, verify_commands, etc.)
            changelog_text: Optional changelog description
        """
        body: dict[str, Any] = {
            "body_markdown": body_markdown,
            "tasks": tasks,
        }
        if changelog_text is not None:
            body["changelog_text"] = changelog_text
        return _client(api_url).post(
            f"/api/v1/organizations/{organization_id}/plans/{plan_id}/versions",
            json=body,
        )

    # ─── PlanTask Operations ─────────────────────────────────────────────────

    @mcp.tool()
    async def green_create_plan_task(
        api_url: str,
        organization_id: str,
        plan_id: str,
        title: str,
        description: Optional[str] = None,
        notion_page_id: Optional[str] = None,
        notion_database_id: Optional[str] = None,
    ) -> dict:
        """
        Create a new PlanTask within a plan.

        Path: POST /api/v1/organizations/{organization_id}/plans/{plan_id}/tasks

        Args:
            api_url: Green Codens API base URL
            organization_id: Organization ID
            plan_id: Plan ID
            title: Task title
            description: Optional task description
            notion_page_id: Optional Notion page ID
            notion_database_id: Optional Notion database ID
        """
        body: dict[str, Any] = {"title": title}
        if description is not None:
            body["description"] = description
        if notion_page_id is not None:
            body["notion_page_id"] = notion_page_id
        if notion_database_id is not None:
            body["notion_database_id"] = notion_database_id
        return _client(api_url).post(
            f"/api/v1/organizations/{organization_id}/plans/{plan_id}/tasks",
            json=body,
        )

    @mcp.tool()
    async def green_repush_plan_task(
        api_url: str,
        organization_id: str,
        plan_id: str,
        plan_task_id: str,
    ) -> dict:
        """
        Repush a single PlanTask to Notion.

        Path: POST /api/v1/organizations/{organization_id}/plans/{plan_id}/tasks/{plan_task_id}/repush

        Args:
            api_url: Green Codens API base URL
            organization_id: Organization ID
            plan_id: Plan ID
            plan_task_id: PlanTask ID
        """
        return _client(api_url).post(
            f"/api/v1/organizations/{organization_id}/plans/{plan_id}/tasks/{plan_task_id}/repush",
        )

    @mcp.tool()
    async def green_refresh_plan_task(
        api_url: str,
        organization_id: str,
        plan_id: str,
        plan_task_id: str,
    ) -> dict:
        """
        Immediately sync a PlanTask's notion_status from Notion API.

        Path: POST /api/v1/organizations/{organization_id}/plans/{plan_id}/tasks/{plan_task_id}/refresh

        Args:
            api_url: Green Codens API base URL
            organization_id: Organization ID
            plan_id: Plan ID
            plan_task_id: PlanTask ID
        """
        return _client(api_url).post(
            f"/api/v1/organizations/{organization_id}/plans/{plan_id}/tasks/{plan_task_id}/refresh",
        )

    @mcp.tool()
    async def green_diagnose_plan_task(
        api_url: str,
        organization_id: str,
        plan_id: str,
        plan_task_id: str,
    ) -> dict:
        """
        Start AI diagnosis for a 'Needs Human' PlanTask (async, returns 202).

        Path: POST /api/v1/organizations/{organization_id}/plans/{plan_id}/tasks/{plan_task_id}/diagnose

        Args:
            api_url: Green Codens API base URL
            organization_id: Organization ID
            plan_id: Plan ID
            plan_task_id: PlanTask ID
        """
        return _client(api_url).post(
            f"/api/v1/organizations/{organization_id}/plans/{plan_id}/tasks/{plan_task_id}/diagnose",
        )

    @mcp.tool()
    async def green_get_plan_diagnosis(
        api_url: str,
        organization_id: str,
        plan_id: str,
        diagnosis_id: str,
    ) -> dict:
        """
        Get AI diagnosis result for a PlanTask.

        Path: GET /api/v1/organizations/{organization_id}/plans/{plan_id}/diagnoses/{diagnosis_id}

        Args:
            api_url: Green Codens API base URL
            organization_id: Organization ID
            plan_id: Plan ID
            diagnosis_id: Diagnosis ID
        """
        return _client(api_url).get(
            f"/api/v1/organizations/{organization_id}/plans/{plan_id}/diagnoses/{diagnosis_id}"
        )

    # ─── Celery Task Management ──────────────────────────────────────────────

    @mcp.tool()
    async def green_get_task_status(api_url: str, task_id: str) -> dict:
        """
        Get the status of a Celery task (for polling async operations).

        Path: GET /api/v1/tasks/{task_id}

        Args:
            api_url: Green Codens API base URL
            task_id: Celery task ID
        """
        return _client(api_url).get(f"/api/v1/tasks/{task_id}")

    @mcp.tool()
    async def green_revoke_task(
        api_url: str,
        task_id: str,
        terminate: bool = False,
    ) -> dict:
        """
        Revoke (cancel) a Celery task.

        Path: POST /api/v1/tasks/{task_id}/revoke

        Args:
            api_url: Green Codens API base URL
            task_id: Celery task ID
            terminate: If True, send SIGTERM to the worker process
        """
        params: dict[str, Any] = {"terminate": terminate}
        return _client(api_url).post(
            f"/api/v1/tasks/{task_id}/revoke?terminate={str(terminate).lower()}",
        )

    # ─── Plan Monitoring ─────────────────────────────────────────────────────

    @mcp.tool()
    async def green_trigger_plan_monitoring(
        api_url: str,
        organization_id: str,
        plan_id: str,
    ) -> dict:
        """
        Manually trigger one MonitorPlanProgress tick (async, returns 202).

        Path: POST /api/v1/organizations/{organization_id}/plans/{plan_id}/monitor

        Args:
            api_url: Green Codens API base URL
            organization_id: Organization ID
            plan_id: Plan ID
        """
        return _client(api_url).post(
            f"/api/v1/organizations/{organization_id}/plans/{plan_id}/monitor",
        )

    @mcp.tool()
    async def green_stop_plan_monitoring(
        api_url: str,
        organization_id: str,
        plan_id: str,
    ) -> dict:
        """
        Emergency stop: set monitoring_enabled=False immediately.

        Path: POST /api/v1/organizations/{organization_id}/plans/{plan_id}/monitoring/stop

        Args:
            api_url: Green Codens API base URL
            organization_id: Organization ID
            plan_id: Plan ID
        """
        return _client(api_url).post(
            f"/api/v1/organizations/{organization_id}/plans/{plan_id}/monitoring/stop",
        )

    @mcp.tool()
    async def green_update_plan_monitoring_settings(
        api_url: str,
        organization_id: str,
        plan_id: str,
        monitoring_enabled: Optional[bool] = None,
        monitoring_interval_min: Optional[int] = None,
        auto_apply_diff: Optional[bool] = None,
    ) -> dict:
        """
        Update plan monitoring settings (enable/interval/auto-apply).

        Path: PUT /api/v1/organizations/{organization_id}/plans/{plan_id}/monitoring/settings

        Args:
            api_url: Green Codens API base URL
            organization_id: Organization ID
            plan_id: Plan ID
            monitoring_enabled: Enable/disable monitoring
            monitoring_interval_min: Interval in minutes (5-1440)
            auto_apply_diff: Auto-apply AI-generated diffs
        """
        body: dict[str, Any] = {}
        if monitoring_enabled is not None:
            body["monitoring_enabled"] = monitoring_enabled
        if monitoring_interval_min is not None:
            body["monitoring_interval_min"] = monitoring_interval_min
        if auto_apply_diff is not None:
            body["auto_apply_diff"] = auto_apply_diff
        return _client(api_url).put(
            f"/api/v1/organizations/{organization_id}/plans/{plan_id}/monitoring/settings",
            json=body,
        )

    @mcp.tool()
    async def green_list_plan_snapshots(
        api_url: str,
        organization_id: str,
        plan_id: str,
        limit: int = 20,
    ) -> dict:
        """
        List recent PlanProgressSnapshots for a plan (audit log).

        Path: GET /api/v1/organizations/{organization_id}/plans/{plan_id}/snapshots

        Args:
            api_url: Green Codens API base URL
            organization_id: Organization ID
            plan_id: Plan ID
            limit: Number of snapshots to return (default: 20, max: 100)
        """
        params: dict[str, Any] = {"limit": limit}
        return _client(api_url).get(
            f"/api/v1/organizations/{organization_id}/plans/{plan_id}/snapshots",
            params=params,
        )

    # ─── PRD Review Requests ─────────────────────────────────────────────────

    @mcp.tool()
    async def green_create_review_request(
        api_url: str,
        organization_id: str,
        project_id: str,
        prd_id: str,
        reviewer_id: str,
        request_comment: Optional[str] = None,
    ) -> dict:
        """
        Create a review request for a PRD.

        Path: POST /api/v1/organizations/{organization_id}/projects/{project_id}/prds/{prd_id}/review-requests

        Args:
            api_url: Green Codens API base URL
            organization_id: Organization ID
            project_id: Project ID
            prd_id: PRD ID
            reviewer_id: User ID of the reviewer
            request_comment: Optional comment
        """
        body: dict[str, Any] = {"reviewer_id": reviewer_id}
        if request_comment is not None:
            body["request_comment"] = request_comment
        return _client(api_url).post(
            f"/api/v1/organizations/{organization_id}/projects/{project_id}/prds/{prd_id}/review-requests",
            json=body,
        )

    @mcp.tool()
    async def green_list_review_requests(
        api_url: str,
        organization_id: str,
        project_id: str,
        prd_id: str,
        status: Optional[str] = None,
        limit: int = 50,
        offset: int = 0,
    ) -> dict:
        """
        List review requests for a PRD.

        Path: GET /api/v1/organizations/{organization_id}/projects/{project_id}/prds/{prd_id}/review-requests

        Args:
            api_url: Green Codens API base URL
            organization_id: Organization ID
            project_id: Project ID
            prd_id: PRD ID
            status: Optional status filter
            limit: Max results (default: 50)
            offset: Pagination offset (default: 0)
        """
        params: dict[str, Any] = {"limit": limit, "offset": offset}
        if status is not None:
            params["status"] = status
        return _client(api_url).get(
            f"/api/v1/organizations/{organization_id}/projects/{project_id}/prds/{prd_id}/review-requests",
            params=params,
        )

    @mcp.tool()
    async def green_get_review_request(
        api_url: str,
        organization_id: str,
        project_id: str,
        prd_id: str,
        request_id: str,
    ) -> dict:
        """
        Get a review request by ID.

        Path: GET /api/v1/organizations/{organization_id}/projects/{project_id}/prds/{prd_id}/review-requests/{request_id}

        Args:
            api_url: Green Codens API base URL
            organization_id: Organization ID
            project_id: Project ID
            prd_id: PRD ID
            request_id: Review request ID
        """
        return _client(api_url).get(
            f"/api/v1/organizations/{organization_id}/projects/{project_id}/prds/{prd_id}/review-requests/{request_id}"
        )

    @mcp.tool()
    async def green_respond_to_review_request(
        api_url: str,
        organization_id: str,
        project_id: str,
        prd_id: str,
        request_id: str,
        approve: bool,
        comment: Optional[str] = None,
    ) -> dict:
        """
        Respond to a review request (approve or request changes).

        Path: POST /api/v1/organizations/{organization_id}/projects/{project_id}/prds/{prd_id}/review-requests/{request_id}/respond

        Args:
            api_url: Green Codens API base URL
            organization_id: Organization ID
            project_id: Project ID
            prd_id: PRD ID
            request_id: Review request ID
            approve: True to approve, False to request changes
            comment: Optional response comment
        """
        body: dict[str, Any] = {"approve": approve}
        if comment is not None:
            body["comment"] = comment
        return _client(api_url).post(
            f"/api/v1/organizations/{organization_id}/projects/{project_id}/prds/{prd_id}/review-requests/{request_id}/respond",
            json=body,
        )

    @mcp.tool()
    async def green_cancel_review_request(
        api_url: str,
        organization_id: str,
        project_id: str,
        prd_id: str,
        request_id: str,
    ) -> dict:
        """
        Cancel a review request.

        Path: POST /api/v1/organizations/{organization_id}/projects/{project_id}/prds/{prd_id}/review-requests/{request_id}/cancel

        Args:
            api_url: Green Codens API base URL
            organization_id: Organization ID
            project_id: Project ID
            prd_id: PRD ID
            request_id: Review request ID
        """
        return _client(api_url).post(
            f"/api/v1/organizations/{organization_id}/projects/{project_id}/prds/{prd_id}/review-requests/{request_id}/cancel",
        )

    @mcp.tool()
    async def green_list_my_review_requests(
        api_url: str,
        organization_id: str,
        status: Optional[str] = None,
        limit: int = 50,
        offset: int = 0,
    ) -> dict:
        """
        List review requests assigned to the authenticated user.

        Path: GET /api/v1/organizations/{organization_id}/my-review-requests

        Args:
            api_url: Green Codens API base URL
            organization_id: Organization ID
            status: Optional status filter
            limit: Max results (default: 50)
            offset: Pagination offset (default: 0)
        """
        params: dict[str, Any] = {"limit": limit, "offset": offset}
        if status is not None:
            params["status"] = status
        return _client(api_url).get(
            f"/api/v1/organizations/{organization_id}/my-review-requests",
            params=params,
        )

    @mcp.tool()
    async def green_list_my_requested_reviews(
        api_url: str,
        organization_id: str,
        status: Optional[str] = None,
        limit: int = 50,
        offset: int = 0,
    ) -> dict:
        """
        List review requests created by the authenticated user.

        Path: GET /api/v1/organizations/{organization_id}/my-requested-reviews

        Args:
            api_url: Green Codens API base URL
            organization_id: Organization ID
            status: Optional status filter
            limit: Max results (default: 50)
            offset: Pagination offset (default: 0)
        """
        params: dict[str, Any] = {"limit": limit, "offset": offset}
        if status is not None:
            params["status"] = status
        return _client(api_url).get(
            f"/api/v1/organizations/{organization_id}/my-requested-reviews",
            params=params,
        )

    # ─── PRD Templates ───────────────────────────────────────────────────────

    @mcp.tool()
    async def green_list_org_prd_templates(
        api_url: str,
        organization_id: str,
    ) -> dict:
        """
        List all PRD templates for an organization (across all projects).

        Path: GET /api/v1/organizations/{organization_id}/prd-templates

        Args:
            api_url: Green Codens API base URL
            organization_id: Organization ID
        """
        return _client(api_url).get(
            f"/api/v1/organizations/{organization_id}/prd-templates"
        )

    @mcp.tool()
    async def green_create_prd_template(
        api_url: str,
        organization_id: str,
        project_id: str,
        name: str,
        sections: list[dict[str, Any]],
        description: Optional[str] = None,
        is_default: bool = False,
    ) -> dict:
        """
        Create a new PRD template for a project.

        Path: POST /api/v1/organizations/{organization_id}/projects/{project_id}/prd-templates

        Args:
            api_url: Green Codens API base URL
            organization_id: Organization ID
            project_id: Project ID
            name: Template name
            sections: List of section dicts (key, label, type, description, required, etc.)
            description: Optional template description
            is_default: Whether to set as default template
        """
        body: dict[str, Any] = {
            "name": name,
            "sections": sections,
            "is_default": is_default,
        }
        if description is not None:
            body["description"] = description
        return _client(api_url).post(
            f"/api/v1/organizations/{organization_id}/projects/{project_id}/prd-templates",
            json=body,
        )

    @mcp.tool()
    async def green_create_default_prd_template(
        api_url: str,
        organization_id: str,
        project_id: str,
        language: str = "en",
    ) -> dict:
        """
        Create a default PRD template with predefined sections.

        Path: POST /api/v1/organizations/{organization_id}/projects/{project_id}/prd-templates/default

        Args:
            api_url: Green Codens API base URL
            organization_id: Organization ID
            project_id: Project ID
            language: Language for default template ('en' or 'ja')
        """
        return _client(api_url).post(
            f"/api/v1/organizations/{organization_id}/projects/{project_id}/prd-templates/default",
            json={"language": language},
        )

    @mcp.tool()
    async def green_list_prd_templates(
        api_url: str,
        organization_id: str,
        project_id: str,
    ) -> dict:
        """
        List all PRD templates in a project.

        Path: GET /api/v1/organizations/{organization_id}/projects/{project_id}/prd-templates

        Args:
            api_url: Green Codens API base URL
            organization_id: Organization ID
            project_id: Project ID
        """
        return _client(api_url).get(
            f"/api/v1/organizations/{organization_id}/projects/{project_id}/prd-templates"
        )

    @mcp.tool()
    async def green_get_prd_template(
        api_url: str,
        organization_id: str,
        project_id: str,
        template_id: str,
    ) -> dict:
        """
        Get PRD template by ID.

        Path: GET /api/v1/organizations/{organization_id}/projects/{project_id}/prd-templates/{template_id}

        Args:
            api_url: Green Codens API base URL
            organization_id: Organization ID
            project_id: Project ID
            template_id: Template ID
        """
        return _client(api_url).get(
            f"/api/v1/organizations/{organization_id}/projects/{project_id}/prd-templates/{template_id}"
        )

    @mcp.tool()
    async def green_update_prd_template(
        api_url: str,
        organization_id: str,
        project_id: str,
        template_id: str,
        name: Optional[str] = None,
        description: Optional[str] = None,
        sections: Optional[list[dict[str, Any]]] = None,
        is_default: Optional[bool] = None,
    ) -> dict:
        """
        Update PRD template.

        Path: PATCH /api/v1/organizations/{organization_id}/projects/{project_id}/prd-templates/{template_id}

        Args:
            api_url: Green Codens API base URL
            organization_id: Organization ID
            project_id: Project ID
            template_id: Template ID
            name: Optional new name
            description: Optional new description
            sections: Optional new sections list
            is_default: Optional default flag
        """
        body: dict[str, Any] = {}
        if name is not None:
            body["name"] = name
        if description is not None:
            body["description"] = description
        if sections is not None:
            body["sections"] = sections
        if is_default is not None:
            body["is_default"] = is_default
        return _client(api_url).patch(
            f"/api/v1/organizations/{organization_id}/projects/{project_id}/prd-templates/{template_id}",
            json=body,
        )

    @mcp.tool()
    async def green_set_template_as_default(
        api_url: str,
        organization_id: str,
        project_id: str,
        template_id: str,
    ) -> dict:
        """
        Set a template as the default for the project.

        Path: POST /api/v1/organizations/{organization_id}/projects/{project_id}/prd-templates/{template_id}/set-default

        Args:
            api_url: Green Codens API base URL
            organization_id: Organization ID
            project_id: Project ID
            template_id: Template ID
        """
        return _client(api_url).post(
            f"/api/v1/organizations/{organization_id}/projects/{project_id}/prd-templates/{template_id}/set-default",
        )

    @mcp.tool()
    async def green_reorder_template_sections(
        api_url: str,
        organization_id: str,
        project_id: str,
        template_id: str,
        section_keys: list[str],
    ) -> dict:
        """
        Reorder sections in a template.

        Path: POST /api/v1/organizations/{organization_id}/projects/{project_id}/prd-templates/{template_id}/reorder-sections

        Args:
            api_url: Green Codens API base URL
            organization_id: Organization ID
            project_id: Project ID
            template_id: Template ID
            section_keys: Ordered list of section keys
        """
        return _client(api_url).post(
            f"/api/v1/organizations/{organization_id}/projects/{project_id}/prd-templates/{template_id}/reorder-sections",
            json={"section_keys": section_keys},
        )

    @mcp.tool()
    async def green_delete_prd_template(
        api_url: str,
        organization_id: str,
        project_id: str,
        template_id: str,
    ) -> dict:
        """
        Delete PRD template.

        Path: DELETE /api/v1/organizations/{organization_id}/projects/{project_id}/prd-templates/{template_id}

        Args:
            api_url: Green Codens API base URL
            organization_id: Organization ID
            project_id: Project ID
            template_id: Template ID
        """
        return _client(api_url).delete(
            f"/api/v1/organizations/{organization_id}/projects/{project_id}/prd-templates/{template_id}"
        )

    # ─── PRD Attachments ─────────────────────────────────────────────────────

    @mcp.tool()
    async def green_get_upload_url(
        api_url: str,
        organization_id: str,
        prd_id: str,
        filename: str,
        content_type: str,
        section_key: Optional[str] = None,
        alt_text: Optional[str] = None,
        caption: Optional[str] = None,
    ) -> dict:
        """
        Get a presigned URL for uploading an image to S3.

        Path: POST /api/v1/organizations/{organization_id}/prds/{prd_id}/attachments/upload-url

        Args:
            api_url: Green Codens API base URL
            organization_id: Organization ID
            prd_id: PRD ID
            filename: Name of the file
            content_type: MIME type (e.g., image/png)
            section_key: Optional PRD section key
            alt_text: Optional alt text
            caption: Optional caption
        """
        body: dict[str, Any] = {
            "filename": filename,
            "content_type": content_type,
        }
        if section_key is not None:
            body["section_key"] = section_key
        if alt_text is not None:
            body["alt_text"] = alt_text
        if caption is not None:
            body["caption"] = caption
        return _client(api_url).post(
            f"/api/v1/organizations/{organization_id}/prds/{prd_id}/attachments/upload-url",
            json=body,
        )

    @mcp.tool()
    async def green_confirm_upload(
        api_url: str,
        organization_id: str,
        prd_id: str,
        attachment_id: str,
        file_size: int,
    ) -> dict:
        """
        Confirm that an image upload to S3 has completed.

        Path: POST /api/v1/organizations/{organization_id}/prds/{prd_id}/attachments/{attachment_id}/confirm-upload

        Args:
            api_url: Green Codens API base URL
            organization_id: Organization ID
            prd_id: PRD ID
            attachment_id: Attachment ID
            file_size: Size of uploaded file in bytes
        """
        return _client(api_url).post(
            f"/api/v1/organizations/{organization_id}/prds/{prd_id}/attachments/{attachment_id}/confirm-upload",
            json={"file_size": file_size},
        )

    @mcp.tool()
    async def green_direct_upload(
        api_url: str,
        organization_id: str,
        prd_id: str,
        filename: str,
        content_type: str,
        content_base64: str,
        section_key: Optional[str] = None,
        alt_text: Optional[str] = None,
        caption: Optional[str] = None,
    ) -> dict:
        """
        Directly upload an image as Base64-encoded data.

        Path: POST /api/v1/organizations/{organization_id}/prds/{prd_id}/attachments/upload

        Args:
            api_url: Green Codens API base URL
            organization_id: Organization ID
            prd_id: PRD ID
            filename: Name of the file
            content_type: MIME type
            content_base64: Base64-encoded file content
            section_key: Optional PRD section key
            alt_text: Optional alt text
            caption: Optional caption
        """
        body: dict[str, Any] = {
            "filename": filename,
            "content_type": content_type,
            "content_base64": content_base64,
        }
        if section_key is not None:
            body["section_key"] = section_key
        if alt_text is not None:
            body["alt_text"] = alt_text
        if caption is not None:
            body["caption"] = caption
        return _client(api_url).post(
            f"/api/v1/organizations/{organization_id}/prds/{prd_id}/attachments/upload",
            json=body,
        )

    @mcp.tool()
    async def green_list_attachments(
        api_url: str,
        organization_id: str,
        prd_id: str,
        section_key: Optional[str] = None,
    ) -> dict:
        """
        List all attachments for a PRD.

        Path: GET /api/v1/organizations/{organization_id}/prds/{prd_id}/attachments

        Args:
            api_url: Green Codens API base URL
            organization_id: Organization ID
            prd_id: PRD ID
            section_key: Optional section filter
        """
        params: dict[str, Any] = {}
        if section_key is not None:
            params["section_key"] = section_key
        return _client(api_url).get(
            f"/api/v1/organizations/{organization_id}/prds/{prd_id}/attachments",
            params=params if params else None,
        )

    @mcp.tool()
    async def green_get_attachment(
        api_url: str,
        organization_id: str,
        prd_id: str,
        attachment_id: str,
    ) -> dict:
        """
        Get attachment details.

        Path: GET /api/v1/organizations/{organization_id}/prds/{prd_id}/attachments/{attachment_id}

        Args:
            api_url: Green Codens API base URL
            organization_id: Organization ID
            prd_id: PRD ID
            attachment_id: Attachment ID
        """
        return _client(api_url).get(
            f"/api/v1/organizations/{organization_id}/prds/{prd_id}/attachments/{attachment_id}"
        )

    @mcp.tool()
    async def green_update_attachment(
        api_url: str,
        organization_id: str,
        prd_id: str,
        attachment_id: str,
        section_key: Optional[str] = None,
        position: Optional[int] = None,
        alt_text: Optional[str] = None,
        caption: Optional[str] = None,
    ) -> dict:
        """
        Update attachment metadata.

        Path: PATCH /api/v1/organizations/{organization_id}/prds/{prd_id}/attachments/{attachment_id}

        Args:
            api_url: Green Codens API base URL
            organization_id: Organization ID
            prd_id: PRD ID
            attachment_id: Attachment ID
            section_key: Optional section key
            position: Optional position
            alt_text: Optional alt text
            caption: Optional caption
        """
        body: dict[str, Any] = {}
        if section_key is not None:
            body["section_key"] = section_key
        if position is not None:
            body["position"] = position
        if alt_text is not None:
            body["alt_text"] = alt_text
        if caption is not None:
            body["caption"] = caption
        return _client(api_url).patch(
            f"/api/v1/organizations/{organization_id}/prds/{prd_id}/attachments/{attachment_id}",
            json=body,
        )

    @mcp.tool()
    async def green_delete_attachment(
        api_url: str,
        organization_id: str,
        prd_id: str,
        attachment_id: str,
    ) -> dict:
        """
        Delete an attachment and its S3 object.

        Path: DELETE /api/v1/organizations/{organization_id}/prds/{prd_id}/attachments/{attachment_id}

        Args:
            api_url: Green Codens API base URL
            organization_id: Organization ID
            prd_id: PRD ID
            attachment_id: Attachment ID
        """
        return _client(api_url).delete(
            f"/api/v1/organizations/{organization_id}/prds/{prd_id}/attachments/{attachment_id}"
        )
