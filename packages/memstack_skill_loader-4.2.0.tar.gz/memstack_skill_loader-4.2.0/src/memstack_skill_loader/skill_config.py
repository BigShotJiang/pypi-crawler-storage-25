# MemStack Skill Config - Toggle and filter system
"""Skill configuration system — manages .memstack/skills-enabled.json."""

import json
import os
from dataclasses import dataclass, field
from pathlib import Path
from typing import Literal

_CONFIG_DIR = ".memstack"
_CONFIG_FILE = "skills-enabled.json"
_LEGACY_IGNORE = ".memstack-ignore"
_VERSION = 1

Mode = Literal["all", "allowlist", "blocklist"]


@dataclass
class SkillConfig:
    version: int = _VERSION
    mode: Mode = "all"
    enabled: list[str] = field(default_factory=list)
    disabled: list[str] = field(default_factory=list)

    def to_dict(self) -> dict:
        return {
            "version": self.version,
            "mode": self.mode,
            "enabled": sorted(self.enabled),
            "disabled": sorted(self.disabled),
        }


# In-memory cache: keyed by resolved config path
_cache: dict[str, tuple[float, SkillConfig]] = {}


def _config_path(project_dir: Path) -> Path:
    return project_dir / _CONFIG_DIR / _CONFIG_FILE


def _legacy_ignore_path(project_dir: Path) -> Path:
    return project_dir / _LEGACY_IGNORE


def _migrate_from_ignore(project_dir: Path) -> SkillConfig | None:
    """Read .memstack-ignore and convert to a blocklist config. Returns None if no legacy file."""
    ignore_path = _legacy_ignore_path(project_dir)
    if not ignore_path.exists():
        return None
    try:
        lines = ignore_path.read_text(encoding="utf-8").splitlines()
        disabled = [
            line.strip().lower()
            for line in lines
            if line.strip() and not line.strip().startswith("#")
        ]
    except Exception:
        return None
    if not disabled:
        return None
    return SkillConfig(mode="blocklist", disabled=disabled)


def load_skill_config(project_dir: Path | None = None) -> SkillConfig:
    """Load the skill config, using mtime cache to avoid unnecessary disk reads."""
    if project_dir is None:
        project_dir = Path.cwd()
    project_dir = project_dir.resolve()

    path = _config_path(project_dir)
    cache_key = str(path)

    if path.exists():
        try:
            mtime = path.stat().st_mtime
        except OSError:
            mtime = 0.0
        cached = _cache.get(cache_key)
        if cached and cached[0] == mtime:
            return cached[1]
        try:
            raw = json.loads(path.read_text(encoding="utf-8"))
            config = SkillConfig(
                version=raw.get("version", _VERSION),
                mode=raw.get("mode", "all"),
                enabled=raw.get("enabled", []),
                disabled=raw.get("disabled", []),
            )
            if config.mode not in ("all", "allowlist", "blocklist"):
                config.mode = "all"
            _cache[cache_key] = (mtime, config)
            return config
        except Exception:
            _cache.pop(cache_key, None)
            return SkillConfig()

    # No config file — check for legacy .memstack-ignore migration
    migrated = _migrate_from_ignore(project_dir)
    if migrated is not None:
        save_skill_config(project_dir, migrated)
        return migrated

    return SkillConfig()


def save_skill_config(project_dir: Path | None = None, config: SkillConfig | None = None) -> None:
    """Write the config atomically (tmp + rename). Creates .memstack/ if needed."""
    if project_dir is None:
        project_dir = Path.cwd()
    project_dir = project_dir.resolve()
    if config is None:
        config = SkillConfig()

    dir_path = project_dir / _CONFIG_DIR
    dir_path.mkdir(parents=True, exist_ok=True)

    path = _config_path(project_dir)
    tmp = path.with_suffix(".tmp")
    tmp.write_text(json.dumps(config.to_dict(), indent=2) + "\n", encoding="utf-8")
    tmp.replace(path)

    # Update cache
    try:
        mtime = path.stat().st_mtime
    except OSError:
        mtime = 0.0
    _cache[str(path)] = (mtime, config)


def is_skill_enabled(config: SkillConfig, skill_name: str) -> bool:
    """Check if a skill is enabled under the current mode."""
    name = skill_name.strip().lower()
    if config.mode == "all":
        return True
    if config.mode == "allowlist":
        return name in {s.lower() for s in config.enabled}
    if config.mode == "blocklist":
        return name not in {s.lower() for s in config.disabled}
    return True


def toggle_skill(project_dir: Path | None, skill_name: str, enabled: bool) -> SkillConfig:
    """Toggle a single skill. Auto-adjusts the enabled/disabled lists based on current mode."""
    if project_dir is None:
        project_dir = Path.cwd()
    config = load_skill_config(project_dir)
    name_lower = skill_name.strip().lower()

    if config.mode == "all":
        if not enabled:
            config.mode = "blocklist"
            config.disabled = [name_lower]
        # enabling in "all" mode is a no-op
    elif config.mode == "allowlist":
        names = {s.lower() for s in config.enabled}
        if enabled:
            names.add(name_lower)
        else:
            names.discard(name_lower)
        config.enabled = sorted(names)
    elif config.mode == "blocklist":
        names = {s.lower() for s in config.disabled}
        if enabled:
            names.discard(name_lower)
        else:
            names.add(name_lower)
        config.disabled = sorted(names)

    save_skill_config(project_dir, config)
    return config


def set_mode(project_dir: Path | None, mode: Mode) -> SkillConfig:
    """Change the filtering mode. Preserves existing lists."""
    if project_dir is None:
        project_dir = Path.cwd()
    config = load_skill_config(project_dir)
    config.mode = mode
    save_skill_config(project_dir, config)
    return config


def clear_cache() -> None:
    """Clear the in-memory config cache (for testing)."""
    _cache.clear()
