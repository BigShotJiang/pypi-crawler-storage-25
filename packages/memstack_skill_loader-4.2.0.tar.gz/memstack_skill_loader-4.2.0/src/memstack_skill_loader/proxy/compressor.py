"""Free-tier compression engine for tool result content."""

import re

_ANSI_RE = re.compile(r"\x1b\[[0-9;]*[a-zA-Z]")
_PREAMBLE_RE = re.compile(
    r"^\s*(?:Here (?:is|are) the contents? of (?:file )?|"
    r"The file .+ contains?:|"
    r"Contents? of .+:)\s*$",
    re.IGNORECASE,
)
_FENCED_CODE_START = re.compile(r"^```")


def estimate_tokens(text: str) -> int:
    return len(text) // 4


def compress(text: str, tier: str = "free") -> tuple[str, int, int]:
    original_tokens = estimate_tokens(text)

    # 1. Strip ANSI escape sequences
    text = _ANSI_RE.sub("", text)

    lines = text.split("\n")

    # 2. Strip trailing whitespace on every line
    lines = [line.rstrip() for line in lines]

    # 3. Collapse consecutive blank lines to a single blank line
    collapsed: list[str] = []
    prev_blank = False
    for line in lines:
        is_blank = line == ""
        if is_blank and prev_blank:
            continue
        collapsed.append(line)
        prev_blank = is_blank
    lines = collapsed

    # 4. Deduplicate identical consecutive lines
    deduped: list[str] = []
    i = 0
    while i < len(lines):
        line = lines[i]
        count = 1
        while i + count < len(lines) and lines[i + count] == line:
            count += 1
        deduped.append(line)
        if count > 1:
            deduped.append(f"[repeated {count}x]")
        i += count
    lines = deduped

    # 5. Strip verbose tool preambles
    lines = [line for line in lines if not _PREAMBLE_RE.match(line)]

    # 6. Collapse repeated whitespace in non-code text
    in_code_block = False
    result: list[str] = []
    for line in lines:
        if _FENCED_CODE_START.match(line):
            in_code_block = not in_code_block
        if not in_code_block:
            line = re.sub(r"[ \t]{2,}", " ", line)
        result.append(line)

    compressed_text = "\n".join(result)
    compressed_tokens = estimate_tokens(compressed_text)
    return (compressed_text, original_tokens, compressed_tokens)
