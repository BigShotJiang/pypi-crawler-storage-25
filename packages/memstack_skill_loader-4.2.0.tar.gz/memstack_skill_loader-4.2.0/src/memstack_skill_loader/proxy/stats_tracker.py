"""Record proxy request stats to ~/.memstack/stats.db."""

import sqlite3
from datetime import datetime, timedelta
from pathlib import Path

DB_PATH = Path.home() / ".memstack" / "stats.db"


def _get_conn() -> sqlite3.Connection:
    DB_PATH.parent.mkdir(parents=True, exist_ok=True)
    conn = sqlite3.connect(str(DB_PATH), timeout=5)
    conn.execute("PRAGMA journal_mode=WAL")
    conn.execute(
        """
        CREATE TABLE IF NOT EXISTS proxy_requests (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            timestamp TEXT,
            original_tokens INTEGER,
            compressed_tokens INTEGER,
            savings_pct REAL,
            tool_result_count INTEGER,
            compression_tier TEXT,
            latency_ms REAL
        )
        """
    )
    conn.commit()
    return conn


def log_proxy_request(
    original_tokens: int,
    compressed_tokens: int,
    savings_pct: float,
    tool_result_count: int,
    compression_tier: str,
    latency_ms: float,
) -> None:
    conn = _get_conn()
    try:
        conn.execute(
            """
            INSERT INTO proxy_requests
                (timestamp, original_tokens, compressed_tokens, savings_pct,
                 tool_result_count, compression_tier, latency_ms)
            VALUES (?, ?, ?, ?, ?, ?, ?)
            """,
            (
                datetime.utcnow().isoformat(),
                original_tokens,
                compressed_tokens,
                savings_pct,
                tool_result_count,
                compression_tier,
                latency_ms,
            ),
        )
        conn.commit()
    finally:
        conn.close()


def get_proxy_stats(time_range: str = "all") -> dict:
    conn = _get_conn()
    try:
        if time_range == "today":
            since = datetime.utcnow().replace(hour=0, minute=0, second=0, microsecond=0).isoformat()
        elif time_range == "week":
            since = (datetime.utcnow() - timedelta(days=7)).isoformat()
        else:
            since = None

        if since:
            rows = conn.execute(
                """
                SELECT COUNT(*), SUM(original_tokens - compressed_tokens), AVG(savings_pct), SUM(original_tokens)
                FROM proxy_requests
                WHERE timestamp >= ?
                """,
                (since,),
            ).fetchone()
        else:
            rows = conn.execute(
                """
                SELECT COUNT(*), SUM(original_tokens - compressed_tokens), AVG(savings_pct), SUM(original_tokens)
                FROM proxy_requests
                """,
            ).fetchone()

        total_requests = rows[0] or 0
        total_tokens_saved = int(rows[1] or 0)
        avg_savings_pct = round(rows[2] or 0.0, 1)
        total_original_tokens = int(rows[3] or 0)
        return {
            "total_requests": total_requests,
            "total_tokens_saved": total_tokens_saved,
            "avg_savings_pct": avg_savings_pct,
            "total_original_tokens": total_original_tokens,
            "time_range": time_range,
        }
    finally:
        conn.close()
