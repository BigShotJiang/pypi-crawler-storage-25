"""Parse Anthropic request bodies and compress large content blocks."""

import copy
import os
from typing import Any

_VERBOSE = os.environ.get("TOKENSTACK_VERBOSE", "").lower() in ("1", "true", "yes")

from .compressor import compress

_COMPRESS_THRESHOLD = 8000


def _block_text_size(block: dict) -> int:
    """Return the character length of a block's compressible text, or 0."""
    btype = block.get("type", "")
    if btype == "tool_result":
        inner = block.get("content")
        if isinstance(inner, str):
            return len(inner)
        if isinstance(inner, list):
            return max((len(i.get("text", "")) for i in inner if isinstance(i, dict) and i.get("type") == "text"), default=0)
    if btype == "text":
        return len(block.get("text", ""))
    return 0


def parse_and_compress(body_dict: dict, tier: str = "free") -> tuple[dict, dict]:
    modified = copy.deepcopy(body_dict)
    total_original = 0
    total_compressed = 0
    compressed_count = 0

    messages = modified.get("messages", [])

    total_blocks = 0
    total_tool_results = 0
    largest_block = 0
    for msg in messages:
        content = msg.get("content")
        if not isinstance(content, list):
            continue
        for block in content:
            if not isinstance(block, dict):
                continue
            total_blocks += 1
            btype = block.get("type", "")
            if btype == "tool_result":
                total_tool_results += 1
            size = _block_text_size(block)
            if size > largest_block:
                largest_block = size

    if _VERBOSE:
        print(f"[parser] messages={len(messages)} blocks={total_blocks} tool_results={total_tool_results} largest_block={largest_block} chars")

    for message in messages:
        content = message.get("content")
        if not isinstance(content, list):
            continue
        for block in content:
            if not isinstance(block, dict):
                continue
            btype = block.get("type", "")

            if btype == "tool_result":
                inner = block.get("content")
                if isinstance(inner, str):
                    if len(inner) > _COMPRESS_THRESHOLD:
                        compressed, orig_tok, comp_tok = compress(inner, tier)
                        block["content"] = compressed
                        total_original += orig_tok
                        total_compressed += comp_tok
                        compressed_count += 1
                elif isinstance(inner, list):
                    for item in inner:
                        if not isinstance(item, dict) or item.get("type") != "text":
                            continue
                        text = item.get("text", "")
                        if len(text) > _COMPRESS_THRESHOLD:
                            compressed, orig_tok, comp_tok = compress(text, tier)
                            item["text"] = compressed
                            total_original += orig_tok
                            total_compressed += comp_tok
                            compressed_count += 1

            elif btype == "text":
                text = block.get("text", "")
                if len(text) > _COMPRESS_THRESHOLD:
                    compressed, orig_tok, comp_tok = compress(text, tier)
                    block["text"] = compressed
                    total_original += orig_tok
                    total_compressed += comp_tok
                    compressed_count += 1

    if total_original > 0:
        savings_pct = round((1 - total_compressed / total_original) * 100, 1)
    else:
        savings_pct = 0.0

    stats: dict[str, Any] = {
        "original_tokens": total_original,
        "compressed_tokens": total_compressed,
        "compressed_count": compressed_count,
        "savings_pct": savings_pct,
    }
    return (modified, stats)
