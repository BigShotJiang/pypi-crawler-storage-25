"""aiohttp proxy server — intercepts /v1/messages, compresses tool results, forwards."""

import json
import signal
import time

GREEN = "\033[32m"
YELLOW = "\033[33m"
RED = "\033[31m"
CYAN = "\033[36m"
DIM = "\033[2m"
BOLD = "\033[1m"
RESET = "\033[0m"

from aiohttp import web

from .body_parser import parse_and_compress
from .forwarder import forward_request
from .stats_tracker import get_proxy_stats, log_proxy_request

_HOP_BY_HOP = frozenset({
    "host", "connection", "keep-alive", "transfer-encoding",
    "te", "trailer", "upgrade", "proxy-authorization", "proxy-authenticate",
    "accept-encoding",
})

_start_time: float = 0.0
_total_requests: int = 0
_total_savings_sum: float = 0.0
_target_url: str = "https://api.anthropic.com"
_session_tokens_saved: int = 0
_session_requests_compressed: int = 0
_verbose: bool = False


def _human_size(n: int) -> str:
    if n >= 1_048_576:
        return f"{n / 1_048_576:.1f}MB"
    if n >= 1024:
        return f"{n // 1024}KB"
    return f"{n}B"


def _ts() -> str:
    return time.strftime("%H:%M:%S")


async def _handle_messages(request: web.Request) -> web.StreamResponse:
    global _total_requests, _total_savings_sum, _session_tokens_saved, _session_requests_compressed

    t0 = time.monotonic()
    raw_body = await request.read()

    try:
        body_dict = json.loads(raw_body)
        modified_body, stats = parse_and_compress(body_dict)
        forward_body = json.dumps(modified_body).encode()
    except Exception:
        forward_body = raw_body
        stats = {"original_tokens": 0, "compressed_tokens": 0, "compressed_count": 0, "savings_pct": 0.0}

    print(f"{DIM}[{_ts()}]{RESET} {CYAN}{request.method} {request.path}{RESET} {DIM}({_human_size(len(raw_body))}){RESET}")

    if stats["compressed_count"] > 0:
        print(
            f"         {GREEN}✓ {stats['compressed_count']} blocks compressed: "
            f"{stats['original_tokens']} → {stats['compressed_tokens']} tokens "
            f"({stats['savings_pct']:.1f}% saved){RESET}"
        )

    fwd_headers = {
        k: v for k, v in request.headers.items()
        if k.lower() not in _HOP_BY_HOP
    }
    fwd_headers["Content-Length"] = str(len(forward_body))

    response: web.StreamResponse | None = None
    first = True

    async for chunk, status, resp_headers in forward_request(
        method=request.method,
        path=request.path,
        headers=fwd_headers,
        body=forward_body,
        target_url=_target_url,
    ):
        if first:
            content_type = resp_headers.get("Content-Type", "application/json")
            if status == 200:
                suffix = " streaming" if "text/event-stream" in content_type else ""
                print(f"         {DIM}← 200{suffix}{RESET}")
            elif status == 429:
                print(f"         {YELLOW}← 429 rate limited{RESET}")
            else:
                print(f"         {RED}← {status} error{RESET}")
            if "text/event-stream" in content_type:
                response = web.StreamResponse(status=status)
                for key, val in resp_headers.items():
                    if key.lower() not in ("transfer-encoding", "content-length"):
                        response.headers[key] = val
                await response.prepare(request)
            else:
                response = web.Response(status=status, body=chunk)
                for key, val in resp_headers.items():
                    if key.lower() not in ("transfer-encoding", "content-length"):
                        response.headers[key] = val
                latency_ms = (time.monotonic() - t0) * 1000
                _total_requests += 1
                _total_savings_sum += stats["savings_pct"]
                tokens_saved = stats["original_tokens"] - stats["compressed_tokens"]
                if tokens_saved > 0:
                    _session_tokens_saved += tokens_saved
                    _session_requests_compressed += 1
                if _total_requests % 10 == 0:
                    avg = _total_savings_sum / _total_requests if _total_requests > 0 else 0
                    print(f"\n{DIM}─── Session: {_total_requests} requests │ {_session_tokens_saved:,} tokens saved │ {avg:.1f}% avg savings ───{RESET}\n")
                log_proxy_request(
                    original_tokens=stats["original_tokens"],
                    compressed_tokens=stats["compressed_tokens"],
                    savings_pct=stats["savings_pct"],
                    tool_result_count=stats["compressed_count"],
                    compression_tier="free",
                    latency_ms=latency_ms,
                )
                return response
            first = False
        if chunk and isinstance(response, web.StreamResponse):
            try:
                await response.write(chunk)
            except (ConnectionResetError, ConnectionAbortedError):
                print(f"         {DIM}← client disconnected{RESET}")
                break

    if response is None:
        response = web.Response(status=500, text="Upstream returned no data")
        return response

    if isinstance(response, web.StreamResponse):
        try:
            await response.write_eof()
        except (ConnectionResetError, ConnectionAbortedError):
            print(f"         {DIM}← client disconnected{RESET}")
        latency_ms = (time.monotonic() - t0) * 1000
        _total_requests += 1
        _total_savings_sum += stats["savings_pct"]
        tokens_saved = stats["original_tokens"] - stats["compressed_tokens"]
        if tokens_saved > 0:
            _session_tokens_saved += tokens_saved
            _session_requests_compressed += 1
        if _total_requests % 10 == 0:
            avg = _total_savings_sum / _total_requests if _total_requests > 0 else 0
            print(f"\n{DIM}─── Session: {_total_requests} requests │ {_session_tokens_saved:,} tokens saved │ {avg:.1f}% avg savings ───{RESET}\n")
        log_proxy_request(
            original_tokens=stats["original_tokens"],
            compressed_tokens=stats["compressed_tokens"],
            savings_pct=stats["savings_pct"],
            tool_result_count=stats["compressed_count"],
            compression_tier="free",
            latency_ms=latency_ms,
        )

    return response


async def _handle_health(request: web.Request) -> web.Response:
    uptime = time.monotonic() - _start_time
    avg_savings = (_total_savings_sum / _total_requests) if _total_requests > 0 else 0.0
    db_stats = get_proxy_stats()
    return web.json_response({
        "status": "ok",
        "uptime_seconds": round(uptime, 1),
        "total_requests": _total_requests,
        "total_savings_pct": round(avg_savings, 1),
        "total_tokens_saved": db_stats["total_tokens_saved"],
        "total_original_tokens": db_stats["total_original_tokens"],
        "average_savings_pct": db_stats["avg_savings_pct"],
        "requests_compressed": db_stats["total_requests"],
    })


def start_proxy(host: str = "127.0.0.1", port: int = 8787, target: str = "https://api.anthropic.com", verbose: bool = False) -> None:
    global _start_time, _target_url, _verbose
    _start_time = time.monotonic()
    _target_url = target
    _verbose = verbose

    app = web.Application()
    app.router.add_post("/v1/messages", _handle_messages)
    app.router.add_get("/health", _handle_health)

    url = f"http://{host}:{port}"
    W = 50
    line1 = f"  TokenStack™ - Token Compression Proxy"
    line2 = f"  Part of the MemStack™ ecosystem"
    line3 = f"  URL:  {url}"
    line4 = f"  Mode: Free tier (basic compression)"
    print(f"""\
{BOLD}╔{'═' * W}╗
║{line1:<{W}}║
║{line2:<{W}}║
╠{'═' * W}╣{RESET}
{CYAN}║{line3:<{W}}║{RESET}
║{line4:<{W}}║
╚{'═' * W}╝

Set ANTHROPIC_BASE_URL={url}
""")

    def _shutdown_handler(sig, frame):
        avg = (_total_savings_sum / _total_requests) if _total_requests > 0 else 0.0
        w = 50
        req_line = f"  Requests:      {_total_requests:,}"
        tok_line = f"  Tokens saved:  {_session_tokens_saved:,}"
        avg_line = f"  Avg savings:   {avg:.1f}%"
        print(f"""
{BOLD}╔{'═' * w}╗
║{'  TokenStack™ Session Summary':<{w}}║
╠{'═' * w}╣{RESET}
║{req_line:<{w}}║
║{tok_line:<{w}}║
║{avg_line:<{w}}║
╚{'═' * w}╝""")
        raise KeyboardInterrupt

    signal.signal(signal.SIGINT, _shutdown_handler)

    web.run_app(app, host=host, port=port, print=None)
