"""Forward modified requests to Anthropic and stream responses back."""

from typing import AsyncGenerator

import aiohttp


async def forward_request(
    method: str,
    path: str,
    headers: dict,
    body: bytes | None,
    target_url: str,
) -> AsyncGenerator[tuple[bytes, int, dict], None]:
    """Yield (chunk, status, response_headers). Headers yielded once on first chunk."""
    url = target_url.rstrip("/") + path
    # Never modify auth headers — pass everything through as-is
    async with aiohttp.ClientSession() as session:
        async with session.request(
            method=method,
            url=url,
            headers=headers,
            data=body,
            allow_redirects=False,
        ) as resp:
            status = resp.status
            # aiohttp auto-decompresses the body, so strip encoding headers
            # to prevent the client from trying to decompress again
            resp_headers = {
                k: v for k, v in resp.headers.items()
                if k.lower() not in ("content-encoding", "transfer-encoding")
            }
            content_type = resp_headers.get("Content-Type", "")
            if "text/event-stream" in content_type:
                first = True
                async for chunk in resp.content.iter_any():
                    if first:
                        yield (chunk, status, resp_headers)
                        first = False
                    else:
                        yield (chunk, status, {})
                if first:
                    # Empty streaming response
                    yield (b"", status, resp_headers)
            else:
                data = await resp.read()
                yield (data, status, resp_headers)
