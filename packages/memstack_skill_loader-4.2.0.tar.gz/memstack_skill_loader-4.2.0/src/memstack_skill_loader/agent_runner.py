# Agent Runner v4.0 - MemStack autonomous agent orchestration
"""Agent Runner — orchestrates Claude Code agents via interactive streaming."""

import json
import os
import shutil
import subprocess
import sys
import threading
import time
import uuid
from pathlib import Path
from typing import Optional

import httpx

from .stats import log_agent_invocation, log_api_cost


# ---------------------------------------------------------------------------
# Anthropic model pricing (per million tokens, May 2026)
# ---------------------------------------------------------------------------

MODEL_PRICING = {
    "claude-sonnet-4-6": {"input": 3.0, "output": 15.0},
    "claude-opus-4-6": {"input": 5.0, "output": 25.0},
    "claude-opus-4-7": {"input": 5.0, "output": 25.0},
    "claude-haiku-4-5": {"input": 1.0, "output": 5.0},
}
# Cache read: 90% discount on input rate
# Cache creation: 25% premium on input rate


def _calculate_api_cost(
    model: str,
    input_tokens: int,
    output_tokens: int,
    cache_read_tokens: int = 0,
    cache_creation_tokens: int = 0,
) -> float:
    """Calculate USD cost from token counts and model pricing."""
    pricing = MODEL_PRICING.get(model, MODEL_PRICING["claude-sonnet-4-6"])
    input_rate = pricing["input"]
    output_rate = pricing["output"]

    cost = (input_tokens / 1_000_000 * input_rate
            + output_tokens / 1_000_000 * output_rate)
    if cache_read_tokens > 0:
        cost += cache_read_tokens / 1_000_000 * input_rate * 0.1
    if cache_creation_tokens > 0:
        cost += cache_creation_tokens / 1_000_000 * input_rate * 1.25
    return round(cost, 6)


# ---------------------------------------------------------------------------
# Configuration
# ---------------------------------------------------------------------------

STATE_DIR = Path.home() / ".memstack" / "agent-runner"
STATE_FILE = STATE_DIR / "state.json"

AGENT_TIMEOUT = 3600  # seconds per agent invocation (default 60 minutes)
MAX_ITERATIONS = 2

ANTHROPIC_BASE_URL = os.environ.get("ANTHROPIC_BASE_URL", "")
API_KEY_FILE = Path.home() / ".memstack" / "api_key"
OAUTH_TOKEN_FILE = Path.home() / ".memstack" / "oauth_token"
API_DEFAULT_MODEL = "claude-sonnet-4-20250514"
API_MAX_TOKENS = 16000

# API key loading moved to _load_api_key() — called on-demand per agent invocation.
# Do NOT set os.environ["ANTHROPIC_API_KEY"] at module load. It defeats subscription mode.


def _load_api_key() -> str | None:
    """Get the Anthropic API key from environment or stored config file."""
    key = os.environ.get("ANTHROPIC_API_KEY", "").strip()
    if key:
        return key
    try:
        if API_KEY_FILE.is_file():
            stored = API_KEY_FILE.read_text(encoding="utf-8").strip()
            if stored:
                return stored
    except Exception:
        pass
    return None

def _load_oauth_token() -> str | None:
    """Get the OAuth token from environment or stored config file."""
    token = os.environ.get("CLAUDE_CODE_OAUTH_TOKEN", "").strip()
    if token:
        return token
    try:
        if OAUTH_TOKEN_FILE.is_file():
            stored = OAUTH_TOKEN_FILE.read_text(encoding="utf-8").strip()
            if stored:
                return stored
    except Exception:
        pass
    return None


SYSTEM_PROMPTS = {
    "manager": (
        "You are a Manager agent. You receive a task and project context (directory listing "
        "and CLAUDE.md if available). Your job is to write a clear, specific delegation spec "
        "for the Builder agent.\n\n"
        "Rules:\n"
        "- Do NOT use tools to read files or explore the codebase. The project context "
        "provided is sufficient.\n"
        "- Do NOT write code yourself.\n"
        "- Be specific: name exact files to create or modify, describe the changes precisely.\n"
        "- For simple tasks (single file edits, adding comments, small features), keep the "
        "spec under 500 words.\n"
        "- End your response with '## Builder Delegation:' followed by the full specification.\n"
        "- When delegating tasks that involve styling, instruct the Builder to use CSS classes, "
        "not inline styles.\n"
        "- When delegating tasks that involve API keys or secrets, instruct the Builder to use "
        "environment variables from .env files, never hardcoded values."
    ),
    "builder": (
        "You are a Builder agent working in {working_dir}. You receive build specifications "
        "from the Manager.\n\n"
        "Rules:\n"
        "- Read existing files before modifying them.\n"
        "- ONLY change what is specified in the delegation. Do not add, refactor, rename, or "
        "fix anything not explicitly requested.\n"
        "- Do not reorganize imports, fix style issues, or make 'improvements' beyond the spec.\n"
        "- Do not verify your changes by reading files after editing them. The Reviewer will verify.\n"
        "- Do not run tests, linters, or build commands unless the spec explicitly asks for it.\n"
        "- Finish as quickly as possible. One read of the target file, make the edit, output your summary.\n"
        "- After completing changes, output a summary listing each file changed and what was done.\n"
        "- Always end with written text summarizing your changes.\n"
        "- Never use inline styles. Always use CSS classes defined in a <style> block or "
        "external stylesheet.\n"
        "- Never hardcode secrets, API keys, tokens, passwords, or credentials in source code. "
        "Always use environment variables loaded from .env files. If a secret is needed, create "
        "or update a .env.example file with the variable name and a placeholder value.\n"
        "- Do NOT run git add, git commit, or any git commands. Only make file changes."
    ),
    "reviewer": (
        "You are a Reviewer agent. You review the Builder's changes against the original "
        "specification.\n\n"
        "Compare the Builder's changes against the original user task to judge completeness.\n"
        "For simple tasks (single file, minor changes), a brief 2-3 sentence approval is sufficient.\n"
        "Do not re-read files that the Builder already summarized unless you suspect the summary "
        "is inaccurate.\n\n"
        "Approve (output 'APPROVED: [summary]') if:\n"
        "- The specified changes were implemented correctly\n"
        "- No security vulnerabilities were introduced (XSS, injection, path traversal)\n"
        "- No obvious bugs or runtime errors\n\n"
        "Do NOT reject for:\n"
        "- Code style, formatting, PEP 8, or naming conventions\n"
        "- Import ordering\n"
        "- Missing docstrings or comments\n"
        "- Suggestions for improvements beyond the original spec\n\n"
        "Only output 'CHANGES REQUESTED: [list]' for actual correctness or security issues."
    ),
}

BUILDER_TOOLS_CONFIG_FILE = Path.home() / ".memstack" / "builder-tools-config.json"


# ---------------------------------------------------------------------------
# MCP server discovery & Builder tools config
# ---------------------------------------------------------------------------

def discover_mcp_servers(workdir: str) -> list[str]:
    """Read .mcp.json from workdir and return the list of MCP server name keys."""
    try:
        mcp_file = Path(workdir) / ".mcp.json"
        if not mcp_file.is_file():
            return []
        data = json.loads(mcp_file.read_text(encoding="utf-8"))
        servers = data.get("mcpServers", {})
        return sorted(servers.keys()) if isinstance(servers, dict) else []
    except Exception:
        return []


_VALID_GIT_WORKFLOWS = ("auto", "single_branch", "dev_to_default", "feature_branch")


def _migrate_config(cfg: dict) -> dict:
    """Migrate per-project values from plain arrays to objects with blocked_mcp key."""
    changed = False
    for key, val in list(cfg.items()):
        if key.startswith("_"):
            continue
        if isinstance(val, list):
            cfg[key] = {"blocked_mcp": val}
            changed = True
    if changed:
        save_builder_tools_config(cfg)
    return cfg


def load_builder_tools_config() -> dict:
    """Load per-project config from ~/.memstack/builder-tools-config.json, migrating if needed."""
    try:
        if BUILDER_TOOLS_CONFIG_FILE.is_file():
            cfg = json.loads(BUILDER_TOOLS_CONFIG_FILE.read_text(encoding="utf-8"))
            return _migrate_config(cfg)
    except Exception:
        pass
    return {}


def save_builder_tools_config(config: dict) -> None:
    """Save per-project config."""
    BUILDER_TOOLS_CONFIG_FILE.parent.mkdir(parents=True, exist_ok=True)
    BUILDER_TOOLS_CONFIG_FILE.write_text(json.dumps(config, indent=2), encoding="utf-8")


def _get_project_config(cfg: dict, workdir: str) -> dict:
    """Return the project config dict for workdir, or empty dict."""
    val = cfg.get(workdir)
    if isinstance(val, dict):
        return val
    return {}


def get_blocked_servers_for_project(workdir: str) -> list[str]:
    """Return blocked MCP servers for a project, falling back to global defaults."""
    cfg = load_builder_tools_config()
    proj = _get_project_config(cfg, workdir)
    if proj:
        return proj.get("blocked_mcp", [])
    return cfg.get("_global_defaults", [])


def get_git_workflow_for_project(workdir: str) -> tuple[str, bool]:
    """Return (workflow, is_project_config) for a working directory."""
    cfg = load_builder_tools_config()
    proj = _get_project_config(cfg, workdir)
    if proj and "git_workflow" in proj:
        wf = proj["git_workflow"]
        if wf in _VALID_GIT_WORKFLOWS:
            return wf, True
    global_wf = cfg.get("_git_workflow", "auto")
    if global_wf not in _VALID_GIT_WORKFLOWS:
        global_wf = "auto"
    return global_wf, False


_VALID_AGENT_MODES = ("api", "subscription")


def _default_agent_modes() -> dict:
    """Return default execution modes — always subscription.

    The API key enables the *option* to switch to API mode in the dashboard,
    but never pre-selects it.
    """
    return {"manager": "subscription", "builder": "subscription", "reviewer": "subscription"}


def load_agent_modes() -> dict:
    """Load agent execution modes from config, falling back to defaults.

    On first run (no ``_agent_modes`` key in config), the computed defaults
    are persisted immediately so subsequent loads read an explicit saved state.
    """
    cfg = load_builder_tools_config()
    stored = cfg.get("_agent_modes", {})
    first_run = "_agent_modes" not in cfg
    defaults = _default_agent_modes()
    modes = {}
    for agent in ("manager", "builder", "reviewer"):
        val = stored.get(agent, "")
        modes[agent] = val if val in _VALID_AGENT_MODES else defaults[agent]
    if first_run:
        save_agent_modes(modes)
    return modes


def _load_agent_display_names() -> dict[str, str]:
    """Load custom agent display names from user profile, falling back to role names."""
    profile_path = Path.home() / ".memstack" / "user_profile.json"
    names = {"manager": "manager", "builder": "builder", "reviewer": "reviewer"}
    try:
        if profile_path.exists():
            data = json.loads(profile_path.read_text(encoding="utf-8"))
            stored = data.get("agent_names", {})
            for role in names:
                custom = stored.get(role, "").strip()
                if custom:
                    names[role] = custom.lower()
    except Exception:
        pass
    return names


def save_agent_modes(modes: dict) -> None:
    """Save agent execution modes to config."""
    cfg = load_builder_tools_config()
    clean = {}
    for agent in ("manager", "builder", "reviewer"):
        val = modes.get(agent, "")
        clean[agent] = val if val in _VALID_AGENT_MODES else "subscription"
    cfg["_agent_modes"] = clean
    save_builder_tools_config(cfg)


# ---------------------------------------------------------------------------
# Project context gathering
# ---------------------------------------------------------------------------

def _gather_project_context(working_dir: str) -> str:
    """Collect directory listing and CLAUDE.md for the Manager prompt."""
    lines = [f"Project directory: {working_dir}"]

    try:
        entries = sorted(os.listdir(working_dir))[:50]
        lines.append("Files: " + ", ".join(entries))
    except OSError:
        lines.append("Files: (could not list directory)")

    claude_md = Path(working_dir) / "CLAUDE.md"
    if claude_md.is_file():
        try:
            content = claude_md.read_text(encoding="utf-8")[:3000]
            lines.append(f"\nProject rules (CLAUDE.md):\n{content}")
        except OSError:
            lines.append("\nProject rules (CLAUDE.md): (could not read)")
    else:
        lines.append("\nProject rules (CLAUDE.md): No CLAUDE.md found")

    return "\n".join(lines)


def _extract_task_text(raw: str) -> str:
    """Strip boilerplate from task text, returning a short commit summary."""
    import re
    text = raw.strip()
    text = re.sub(r'(?m)^Working directory:.*$\n?', '', text)
    text = re.sub(r'(?m)^Branch:.*$\n?', '', text)
    text = re.sub(r'(?m)^Read (?:existing files|the following files).*$\n?', '', text)
    text = re.sub(r'(?m)^- [\w/\\.*]+\s*$\n?', '', text)
    text = re.sub(r'(?m)^Task:\s*', '', text)
    text = re.sub(r'(?ms)^---.*', '', text, count=1)
    text = re.sub(r'(?m)^FIX\s+\d+[:\s].*$\n?', '', text)
    text = re.sub(r'(?m)^[A-Z][A-Z _\-:#]{5,}$\n?', '', text)
    text = re.sub(r'(?m)^.*(?:Do NOT|Do not).*$\n?', '', text)
    text = re.sub(r'(?m)^.*Run npm run build.*$\n?', '', text)
    text = re.sub(r'(?m)^Audit\s.*$\n?', '', text)
    text = re.sub(r'(?m)^STEP\s.*$\n?', '', text)
    text = re.sub(r'(?m)^.*(?:Report findings|Report back).*$\n?', '', text)
    text = text.strip()
    text = re.sub(r'\n{2,}', ' ', text)
    text = re.sub(r'\s+', ' ', text)
    result = "".join(ch for ch in text if ch.isprintable()).strip()
    # If the remaining text still looks like a prompt, replace with generic
    prompt_words = {"endpoint", "implement", "read", "fix", "investigate", "check"}
    if result and sum(1 for w in prompt_words if w in result.lower()) >= 3:
        return "complete task"
    if not result:
        return "dashboard updates"
    return result[:72]


def _clean_task_description(task: str) -> str:
    """Strip Working directory/Branch boilerplate, returning the user's task description."""
    import re
    _BOILERPLATE_LINE = re.compile(
        r'^(working\s+directory:|branch:|read\s+all\s+files\s+before\s+modifying\.?)',
        re.IGNORECASE
    )
    lines = task.splitlines()
    start = 0
    for i, line in enumerate(lines):
        stripped = line.strip()
        if not stripped or _BOILERPLATE_LINE.match(stripped):
            start = i + 1
        else:
            break
    return "\n".join(lines[start:]).strip()


def _extract_commit_from_reviewer(reviewer_output: str) -> str:
    """Extract a commit-friendly summary from the reviewer's APPROVED message."""
    import re
    if not reviewer_output:
        return ""

    _FILLER = re.compile(
        r'\b(?:is correctly implemented|is complete and correct'
        r'|are present and correct|correctly|implementation)\b',
        re.IGNORECASE,
    )

    def _clean(text: str) -> str:
        text = re.split(r'[.\n]', text)[0].strip()
        text = _FILLER.sub('', text)
        text = re.sub(r'\s+', ' ', text).strip()
        text = re.sub(r'^[,\s]+|[,\s]+$', '', text)
        return "".join(ch for ch in text if ch.isprintable()).strip()

    # Try APPROVED: summary on same line
    m = re.search(r'APPROVED[:\s]+(.+)', reviewer_output, re.IGNORECASE)
    if m:
        summary = m.group(1).strip()
        if summary and not summary.startswith('---'):
            result = _clean(summary)
            if len(result) >= 10:
                return result[:50]
    # Fallback: take first meaningful line after APPROVED
    idx = reviewer_output.upper().find('APPROVED')
    if idx >= 0:
        after = reviewer_output[idx + 8:].strip().lstrip(':').strip()
        lines = [l.strip() for l in after.split('\n') if l.strip() and not l.strip().startswith('---')]
        if lines:
            result = _clean(lines[0])
            if len(result) >= 10:
                return result[:50]
    return ""


# ---------------------------------------------------------------------------
# Agent invocation via interactive streaming
# ---------------------------------------------------------------------------

def _build_env(strip_api_key: bool = False, inject_api_key: str | None = None) -> dict:
    """Build environment for subprocess, ensuring Anthropic vars are passed."""
    env = os.environ.copy()
    env.pop("MEMSTACK_ENABLE_TTS", None)
    # Strip API key for subscription mode so CC uses subscription instead of API.
    # Set strip_api_key=False to revert.
    if strip_api_key:
        env.pop("ANTHROPIC_API_KEY", None)
        oauth_token = _load_oauth_token()
        if oauth_token:
            env["ANTHROPIC_AUTH_TOKEN"] = oauth_token
    elif inject_api_key:
        env["ANTHROPIC_API_KEY"] = inject_api_key
    if ANTHROPIC_BASE_URL:
        env["ANTHROPIC_BASE_URL"] = ANTHROPIC_BASE_URL
    return env


def _parse_stream_json(raw: str) -> tuple[str, int, int, float, int, str]:
    """Extract text and token usage from claude --output-format stream-json.

    Returns (text, input_tokens, output_tokens, cost_usd, context_tokens, model).
    context_tokens is the last iteration's total tokens (accurate context window fill).
    """
    text_parts: list[str] = []
    tool_parts: list[str] = []
    result_text = ""
    input_tokens = 0
    output_tokens = 0
    cost_usd = 0.0
    context_tokens = 0
    stream_model = ""
    last_assistant_usage: dict = {}
    for line in raw.splitlines():
        line = line.strip()
        if not line:
            continue
        try:
            obj = json.loads(line)
        except json.JSONDecodeError:
            continue
        msg_type = obj.get("type")
        if msg_type == "assistant":
            msg_model = obj.get("message", {}).get("model", "")
            if msg_model:
                stream_model = msg_model
            usage = obj.get("message", {}).get("usage", {})
            if usage:
                last_assistant_usage = usage
            for block in obj.get("message", {}).get("content", []):
                btype = block.get("type")
                if btype == "text":
                    text_parts.append(block.get("text", ""))
                elif btype == "tool_use":
                    name = block.get("name", "unknown_tool")
                    inp = block.get("input", {})
                    summary = json.dumps(inp, indent=2)[:500]
                    tool_parts.append(f"[Tool call: {name}]\n{summary}")
        elif msg_type == "result":
            result_text = obj.get("result", "") or ""
            usage = obj.get("usage", {})
            input_tokens = usage.get("input_tokens", 0)
            output_tokens = usage.get("output_tokens", 0)
            cost_usd = obj.get("total_cost_usd", 0.0) or 0.0
    if last_assistant_usage:
        context_tokens = (
            last_assistant_usage.get("input_tokens", 0)
            + last_assistant_usage.get("cache_read_input_tokens", 0)
            + last_assistant_usage.get("cache_creation_input_tokens", 0)
        )

    collected = "\n\n".join(text_parts)
    if result_text and len(result_text) >= len(collected):
        text = result_text
    elif collected:
        text = collected
    elif tool_parts:
        text = "[Agent completed with tool calls but no text summary]\n\n" + "\n\n".join(tool_parts)
    else:
        text = ""
    return text, input_tokens, output_tokens, cost_usd, context_tokens, stream_model


def _extract_text_from_stream_line(line: str) -> Optional[str]:
    """Extract user-visible text from a single stream-json line.

    Returns the text if the line contains assistant text or a result, else None.
    """
    try:
        obj = json.loads(line.strip())
    except (json.JSONDecodeError, ValueError):
        return None
    msg_type = obj.get("type")
    if msg_type == "assistant":
        parts = []
        for block in obj.get("message", {}).get("content", []):
            if block.get("type") == "text":
                t = block.get("text", "")
                if t:
                    parts.append(t)
        return "\n".join(parts) if parts else None
    if msg_type == "result":
        t = obj.get("result", "")
        return t if t else None
    return None


# ---------------------------------------------------------------------------
# Direct API invocation (Manager / Reviewer — no file tools needed)
# ---------------------------------------------------------------------------

def _invoke_api_agent(name: str, prompt: str, system_prompt: str,
                      log_path: Optional[Path] = None, timeout: int = 600,
                      model: str = "", session_id: Optional[str] = None,
                      working_dir: str = "",
                      display_name: str = "",
                      ) -> tuple[str, int, int]:
    """Call the Anthropic Messages API directly via httpx.

    Returns (text, input_tokens, output_tokens).
    """
    api_key = _load_api_key() or ""
    base_url = ANTHROPIC_BASE_URL or "https://api.anthropic.com"

    if not api_key and not ANTHROPIC_BASE_URL:
        raise RuntimeError(
            f"{name}: No API key found (env or ~/.memstack/api_key) and no ANTHROPIC_BASE_URL proxy configured"
        )

    url = f"{base_url.rstrip('/')}/v1/messages"
    headers = {
        "content-type": "application/json",
        "anthropic-version": "2023-06-01",
    }
    if api_key:
        headers["x-api-key"] = api_key

    body = {
        "model": model or API_DEFAULT_MODEL,
        "max_tokens": API_MAX_TOKENS,
        "system": system_prompt,
        "messages": [{"role": "user", "content": prompt}],
    }

    if log_path:
        log_path.parent.mkdir(parents=True, exist_ok=True)
        ts = time.strftime("%H:%M:%S")
        with open(log_path, "a", encoding="utf-8") as f:
            f.write(f"[{ts}] === API call: {name} ===\n")
            f.write(f"[{ts}] Model: {body['model']}\n")
            f.write(f"[{ts}] Prompt length: {len(prompt)} chars\n")

    try:
        resp = httpx.post(url, json=body, headers=headers, timeout=timeout)
        resp.raise_for_status()
    except httpx.TimeoutException:
        if log_path:
            ts = time.strftime("%H:%M:%S")
            with open(log_path, "a", encoding="utf-8") as f:
                f.write(f"[{ts}] API timeout after {timeout}s\n")
        raise subprocess.TimeoutExpired(f"api:{name}", timeout)
    except httpx.HTTPStatusError as exc:
        if log_path:
            ts = time.strftime("%H:%M:%S")
            with open(log_path, "a", encoding="utf-8") as f:
                f.write(f"[{ts}] API error {exc.response.status_code}: {exc.response.text[:500]}\n")
        raise RuntimeError(f"{name} API error {exc.response.status_code}: {exc.response.text[:200]}") from exc
    except httpx.HTTPError as exc:
        if log_path:
            ts = time.strftime("%H:%M:%S")
            with open(log_path, "a", encoding="utf-8") as f:
                f.write(f"[{ts}] HTTP error: {exc}\n")
        raise RuntimeError(f"{name} HTTP error: {exc}") from exc

    data = resp.json()
    text_parts = []
    for block in data.get("content", []):
        if block.get("type") == "text":
            text_parts.append(block["text"])
    output = "\n".join(text_parts).strip()

    usage = data.get("usage", {})
    input_tokens = usage.get("input_tokens", 0)
    output_tokens = usage.get("output_tokens", 0)
    cache_read_tokens = usage.get("cache_read_input_tokens", 0)
    cache_creation_tokens = usage.get("cache_creation_input_tokens", 0)
    total_input_tokens = input_tokens + cache_read_tokens

    resp_model = data.get("model", model or "claude-sonnet-4-6")
    actual_cost = _calculate_api_cost(
        resp_model, input_tokens, output_tokens,
        cache_read_tokens, cache_creation_tokens,
    )

    if log_path:
        ts = time.strftime("%H:%M:%S")
        with open(log_path, "a", encoding="utf-8") as f:
            f.write(f"[{ts}] Response: {len(output)} chars, "
                    f"in={total_input_tokens} out={output_tokens}\n")

    stats_name = display_name or name
    try:
        log_agent_invocation(
            stats_name, len(prompt), len(output), session_id, working_dir,
            input_tokens=total_input_tokens, output_tokens=output_tokens, cost_usd=actual_cost,
        )
    except Exception:
        pass

    try:
        _project = os.path.basename(working_dir) if working_dir else None
        log_api_cost(
            session_id=session_id, agent_name=stats_name, model=resp_model,
            input_tokens=total_input_tokens, output_tokens=output_tokens,
            actual_cost_usd=actual_cost, execution_mode="api",
            project=_project,
            cache_read_tokens=cache_read_tokens,
            cache_creation_tokens=cache_creation_tokens,
        )
    except Exception:
        pass

    return output, total_input_tokens, output_tokens


# ---------------------------------------------------------------------------
# CC subprocess invocation (Builder — needs file tools)
# ---------------------------------------------------------------------------

def _invoke_agent(name: str, prompt: str, working_dir: str, log_path: Optional[Path] = None,
                   skip_permissions: bool = False,
                   session_id: Optional[str] = None, timeout: int = AGENT_TIMEOUT,
                   model: str = "", disallowed_tools: Optional[list[str]] = None,
                   session: Optional["Session"] = None,
                   display_name: str = "",
                   execution_mode: str = "subscription") -> tuple[str, int, int, int]:
    """Run a single claude interactive streaming invocation and return the output."""
    claude_bin = shutil.which("claude")
    if not claude_bin:
        raise FileNotFoundError("'claude' CLI not found on PATH")

    cmd = [claude_bin, "--verbose", "--output-format", "stream-json", "--input-format", "stream-json"]
    if skip_permissions:
        cmd.append("--dangerously-skip-permissions")
    if model:
        cmd.extend(["--model", model])
    if disallowed_tools:
        patterns = ",".join(f"mcp__{srv}__*" for srv in disallowed_tools)
        cmd.extend(["--disallowedTools", patterns])

    if log_path:
        log_path.parent.mkdir(parents=True, exist_ok=True)

    ts = time.strftime("%H:%M:%S")
    if log_path:
        with open(log_path, "a", encoding="utf-8") as f:
            f.write(f"[{ts}] === Invoking {name} ===\n")
            f.write(f"[{ts}] Prompt length: {len(prompt)} chars\n")

    global _current_process
    proc = subprocess.Popen(
        cmd,
        stdin=subprocess.PIPE,
        stdout=subprocess.PIPE,
        stderr=subprocess.PIPE,
        cwd=working_dir,
        env=_build_env(
            strip_api_key=(execution_mode == "subscription"),
            inject_api_key=_load_api_key() if execution_mode == "api" else None,
        ),
        creationflags=0,
    )
    with _lock:
        _current_process = proc

    if log_path:
        with open(log_path, "a", encoding="utf-8") as f:
            f.write(f"[{ts}] PID: {proc.pid}\n")

    killed_by_watchdog = threading.Event()

    def _watchdog_kill() -> None:
        killed_by_watchdog.set()
        proc.kill()

    stdout_chunks: list[str] = []
    stderr_chunks: list[str] = []
    partial_text: list[str] = []

    def _read_stdout() -> None:
        for raw_line in proc.stdout:
            line = raw_line.decode("utf-8", errors="replace")
            stdout_chunks.append(line)
            extracted = _extract_text_from_stream_line(line)
            if extracted and session is not None:
                partial_text.append(extracted)
                try:
                    session.agents[name]["last_output"] = "".join(partial_text)[-500:]
                    session._save_state()
                except Exception:
                    pass

    def _read_stderr() -> None:
        for raw_line in proc.stderr:
            stderr_chunks.append(raw_line.decode("utf-8", errors="replace"))

    def _write_stdin() -> None:
        try:
            msg = json.dumps({"type": "user", "message": {"role": "user", "content": prompt}})
            proc.stdin.write((msg + "\n").encode("utf-8"))
            proc.stdin.flush()
        finally:
            proc.stdin.close()

    # Start reader threads BEFORE writing stdin to prevent pipe deadlock.
    # On Windows, anonymous pipes have a ~4KB buffer. Large prompts exceed
    # this, blocking the write until the subprocess reads. If the subprocess
    # writes init events to stdout first, nobody drains them — deadlock.
    t_out = threading.Thread(target=_read_stdout, daemon=True)
    t_err = threading.Thread(target=_read_stderr, daemon=True)
    t_in = threading.Thread(target=_write_stdin, daemon=True)
    t_out.start()
    t_err.start()
    t_in.start()

    watchdog = threading.Timer(timeout, _watchdog_kill)
    watchdog.daemon = True
    watchdog.start()

    try:
        proc.wait()
    except Exception as e:
        watchdog.cancel()
        with _lock:
            if _current_process is proc:
                _current_process = None
        if log_path:
            with open(log_path, "a", encoding="utf-8") as f:
                f.write(f"[{ts}] wait() error: {e}\n")
        raise RuntimeError(f"{name} wait() failed: {e}") from e
    finally:
        watchdog.cancel()
        with _lock:
            if _current_process is proc:
                _current_process = None

    t_in.join(timeout=10)
    t_out.join(timeout=10)
    t_err.join(timeout=10)

    if killed_by_watchdog.is_set():
        raise subprocess.TimeoutExpired(cmd, timeout)

    stdout_data = "".join(stdout_chunks)
    stderr_data = "".join(stderr_chunks)

    if log_path:
        with open(log_path, "a", encoding="utf-8") as f:
            f.write(f"[{ts}] Process exited: stdout={len(stdout_data)} stderr={len(stderr_data)}\n")

    raw_stdout = stdout_data or ""
    stderr = stderr_data or ""
    output, input_tokens, output_tokens, cost_usd, context_tokens, stream_model = _parse_stream_json(raw_stdout)
    output = output.strip()
    ts = time.strftime("%H:%M:%S")

    if log_path:
        raw_log_path = log_path.with_suffix(".stream.jsonl")
        try:
            raw_log_path.write_text(raw_stdout, encoding="utf-8")
        except OSError:
            pass
        with open(log_path, "a", encoding="utf-8") as f:
            f.write(f"[{ts}] Exit code: {proc.returncode}\n")
            f.write(f"[{ts}] Raw stream: {len(raw_stdout)} chars -> {raw_log_path.name}\n")
            if stderr:
                f.write(f"[{ts}] Stderr: {stderr[:500]}\n")
            f.write(f"[{ts}] Parsed output ({len(output)} chars):\n{output}\n")
            f.write(f"[{ts}] === End {name} ===\n\n")

    if proc.returncode != 0 and not output:
        raise RuntimeError(
            f"{name} exited with code {proc.returncode}: {stderr[:300]}"
        )

    stats_name = display_name or name
    try:
        log_agent_invocation(
            stats_name, len(prompt), len(output), session_id, working_dir,
            input_tokens=input_tokens, output_tokens=output_tokens, cost_usd=cost_usd,
        )
    except Exception:
        pass

    try:
        resolved_model = stream_model or model or "claude-sonnet-4-6"
        exec_mode = "api" if cost_usd and cost_usd > 0 else "subscription"
        _project = os.path.basename(working_dir) if working_dir else None
        log_api_cost(
            session_id=session_id, agent_name=stats_name, model=resolved_model,
            input_tokens=input_tokens, output_tokens=output_tokens,
            actual_cost_usd=cost_usd, execution_mode=exec_mode,
            project=_project,
        )
    except Exception:
        pass

    return output, input_tokens, output_tokens, context_tokens


# ---------------------------------------------------------------------------
# Session state
# ---------------------------------------------------------------------------

class Session:
    """Tracks the full state of an agent run session."""

    def __init__(self, task: str, working_dir: str, context: Optional[str] = None, auto_commit: bool = False, timeout_minutes: int = 60,
                 manager_model: str = "", builder_model: str = "", reviewer_model: str = "", user_name: str = "",
                 blocked_mcp_servers: Optional[list[str]] = None):
        self.session_id = uuid.uuid4().hex[:12]
        self.task = task
        self.working_dir = working_dir
        self.models = {"manager": manager_model, "builder": builder_model, "reviewer": reviewer_model}
        self.user_name = user_name
        self.context = context
        self.auto_commit = auto_commit
        self.blocked_mcp_servers = blocked_mcp_servers or []
        self.auto_committed = False
        self.total_duration_seconds: int = 0
        self._start_monotonic: float = 0.0
        self.timeout = max(5, min(120, timeout_minutes)) * 60
        self.status = "running"
        self.result: Optional[str] = None
        self.iteration = 0
        self.max_iterations = MAX_ITERATIONS
        self.started_at = time.strftime("%Y-%m-%d %H:%M:%S")
        self.messages: list[dict] = []
        self.agents: dict[str, dict] = {
            "manager": {"status": "idle", "input_tokens": 0, "output_tokens": 0, "context_tokens": 0, "last_output": "", "started_at": None},
            "builder": {"status": "idle", "input_tokens": 0, "output_tokens": 0, "context_tokens": 0, "last_output": "", "started_at": None},
            "reviewer": {"status": "idle", "input_tokens": 0, "output_tokens": 0, "context_tokens": 0, "last_output": "", "started_at": None},
        }

    def add_message(self, from_agent: str, to_agent: str, content: str) -> None:
        msg = {
            "from": from_agent,
            "to": to_agent,
            "content": content[:10000],
            "timestamp": time.strftime("%Y-%m-%d %H:%M:%S"),
        }
        self.messages.append(msg)
        self._save_state()
        self._persist_message(msg)

    def _save_state(self) -> None:
        STATE_DIR.mkdir(parents=True, exist_ok=True)
        if self.status in ("completed", "error", "stopped") and self.total_duration_seconds == 0 and self._start_monotonic > 0:
            self.total_duration_seconds = round(time.monotonic() - self._start_monotonic)
        data = {
            "session_id": self.session_id,
            "status": self.status,
            "task": self.task,
            "working_dir": self.working_dir,
            "started_at": self.started_at,
            "agents": self.agents,
            "messages": self.messages[-50:],
            "iteration": self.iteration,
            "max_iterations": self.max_iterations,
            "result": self.result,
            "auto_committed": self.auto_committed,
            "total_duration_seconds": self.total_duration_seconds,
        }
        try:
            STATE_FILE.write_text(json.dumps(data, indent=2), encoding="utf-8")
        except OSError:
            pass
        try:
            meta_dir = STATE_DIR / "sessions" / self.session_id
            meta_dir.mkdir(parents=True, exist_ok=True)
            meta = {
                "session_id": self.session_id,
                "task": self.task,
                "task_description": _clean_task_description(self.task),
                "status": self.status,
                "started_at": self.started_at,
                "iteration": self.iteration,
                "result": (self.result or "")[:200],
            }
            (meta_dir / "session_meta.json").write_text(
                json.dumps(meta), encoding="utf-8"
            )
        except OSError:
            pass

    def _persist_message(self, msg: dict) -> None:
        msg_dir = STATE_DIR / "sessions" / self.session_id
        msg_dir.mkdir(parents=True, exist_ok=True)
        msg_file = msg_dir / "messages.jsonl"
        try:
            with open(msg_file, "a", encoding="utf-8") as f:
                f.write(json.dumps(msg) + "\n")
        except OSError:
            pass

    def to_dict(self) -> dict:
        reviewer_text = self.agents.get("reviewer", {}).get("last_output", "")
        commit_summary = _extract_commit_from_reviewer(reviewer_text) if reviewer_text else ""
        if not commit_summary:
            commit_summary = _extract_task_text(self.task) if self.task else ""
        return {
            "session_id": self.session_id,
            "status": self.status,
            "task": self.task,
            "working_dir": self.working_dir,
            "started_at": self.started_at,
            "agents": self.agents,
            "messages": self.messages[-50:],
            "iteration": self.iteration,
            "max_iterations": self.max_iterations,
            "result": self.result,
            "auto_committed": self.auto_committed,
            "commit_summary": commit_summary,
            "total_duration_seconds": self.total_duration_seconds,
        }


# ---------------------------------------------------------------------------
# Module state
# ---------------------------------------------------------------------------

_current_session: Optional[Session] = None
_orchestration_thread: Optional[threading.Thread] = None
_lock = threading.Lock()
_current_process = None


# ---------------------------------------------------------------------------
# Orchestration logic
# ---------------------------------------------------------------------------

def _orchestrate(session: Session) -> None:
    """Run the Manager → Builder → Reviewer loop."""
    session._start_monotonic = time.monotonic()
    session_log_dir = STATE_DIR / "sessions" / session.session_id

    try:
        # Load execution modes and custom display names for this run
        agent_modes = load_agent_modes()
        display_names = _load_agent_display_names()
        has_api_key = bool(_load_api_key() or ANTHROPIC_BASE_URL)
        for _ag in ("manager", "builder", "reviewer"):
            if agent_modes[_ag] == "api" and not has_api_key:
                agent_modes[_ag] = "subscription"
                print(f"[agent-runner] {_ag}: mode=api but no API key found, falling back to subscription", file=sys.stderr)

        # Step 1: Manager analyzes the task
        session.agents["manager"]["status"] = "busy"
        session.agents["manager"]["started_at"] = time.strftime("%Y-%m-%dT%H:%M:%S")
        session.agents["manager"]["last_output"] = ""
        session._save_state()

        context = _gather_project_context(session.working_dir)
        # SECURITY: task text is user-supplied and injected into prompts. Agents run with --dangerously-skip-permissions. This tool must only be exposed to trusted local users, never to untrusted MCP clients.
        manager_prompt = SYSTEM_PROMPTS["manager"] + "\n\n" + context + "\n\nTask:\n" + session.task
        if session.context:
            manager_prompt += "\n\nAdditional context from user:\n" + session.context
        if session.user_name:
            manager_prompt = f"The user's name is {session.user_name}.\n\n" + manager_prompt
        try:
            if agent_modes["manager"] == "api":
                manager_output, m_in, m_out = _invoke_api_agent(
                    "manager", manager_prompt,
                    system_prompt=SYSTEM_PROMPTS["manager"],
                    log_path=session_log_dir / "manager.log",
                    timeout=min(600, session.timeout),
                    model=session.models.get("manager", ""),
                    session_id=session.session_id,
                    working_dir=session.working_dir,
                    display_name=display_names["manager"],
                )
                m_ctx = m_in
            else:
                manager_output, m_in, m_out, m_ctx = _invoke_agent(
                    "manager", manager_prompt, session.working_dir,
                    log_path=session_log_dir / "manager.log",
                    skip_permissions=True, session_id=session.session_id,
                    timeout=min(600, session.timeout),
                    model=session.models.get("manager", ""),
                    display_name=display_names["manager"],
                    execution_mode=agent_modes["manager"],
                )
        except subprocess.TimeoutExpired:
            session.agents["manager"]["status"] = "timeout"
            session.status = "error"
            session.result = "Manager timed out after 10 minutes. Try a simpler task description or break the task into smaller pieces."
            session._save_state()
            return
        except RuntimeError:
            session.agents["manager"]["status"] = "crashed"
            session.status = "error"
            session.result = "Manager agent stopped unexpectedly."
            session._save_state()
            return
        session.agents["manager"]["input_tokens"] += m_in
        session.agents["manager"]["output_tokens"] += m_out
        session.agents["manager"]["context_tokens"] = m_ctx
        session.agents["manager"]["last_output"] = (manager_output or "")[:500]

        session.agents["manager"]["status"] = "done"
        if session.status == "stopped":
            session._save_state()
            return

        if not (manager_output or "").strip():
            session.status = "error"
            session.result = "Manager produced no output"
            session._save_state()
            return

        session.add_message("manager", "builder", manager_output)

        # Step 2-3: Builder/Reviewer loop
        builder_input = manager_output

        for iteration in range(1, MAX_ITERATIONS + 1):
            if session.status == "stopped":
                break
            session.iteration = iteration

            # Builder
            session.agents["builder"]["status"] = "busy"
            session.agents["builder"]["started_at"] = time.strftime("%Y-%m-%dT%H:%M:%S")
            session.agents["builder"]["last_output"] = ""
            session._save_state()

            builder_prompt = (
                SYSTEM_PROMPTS["builder"].format(working_dir=session.working_dir)
                + "\n\n" + context
                + f"\n\nOriginal task:\n{session.task}"
                + (f"\n\nAdditional context from user:\n{session.context}" if session.context else "")
                + f"\n\nBuild specification:\n{builder_input}"
            )
            if session.user_name:
                builder_prompt = f"The user's name is {session.user_name}.\n\n" + builder_prompt
            try:
                if agent_modes["builder"] == "subscription":
                    builder_output, b_in, b_out, b_ctx = _invoke_agent(
                        "builder", builder_prompt, session.working_dir,
                        log_path=session_log_dir / "builder.log",
                        skip_permissions=True, session_id=session.session_id,
                        timeout=session.timeout,
                        model=session.models.get("builder", ""),
                        disallowed_tools=session.blocked_mcp_servers,
                        session=session,
                        display_name=display_names["builder"],
                        execution_mode=agent_modes["builder"],
                    )
                else:
                    builder_output, b_in, b_out = _invoke_api_agent(
                        "builder", builder_prompt,
                        system_prompt=SYSTEM_PROMPTS["builder"].format(working_dir=session.working_dir),
                        log_path=session_log_dir / "builder.log",
                        timeout=session.timeout,
                        model=session.models.get("builder", ""),
                        session_id=session.session_id,
                        working_dir=session.working_dir,
                        display_name=display_names["builder"],
                    )
                    b_ctx = b_in
            except subprocess.TimeoutExpired:
                session.agents["builder"]["status"] = "timeout"
                session.status = "error"
                session.result = "Builder timed out. The task may be too large for a single agent pass."
                session._save_state()
                return
            except RuntimeError:
                session.agents["builder"]["status"] = "crashed"
                session.status = "error"
                session.result = "Builder agent stopped unexpectedly."
                session._save_state()
                return
            session.agents["builder"]["input_tokens"] += b_in
            session.agents["builder"]["output_tokens"] += b_out
            session.agents["builder"]["context_tokens"] = b_ctx
            session.agents["builder"]["last_output"] = (builder_output or "")[:500]

            session.agents["builder"]["status"] = "done"
            if session.status == "stopped":
                session._save_state()
                return

            if not builder_output or len(builder_output.strip()) < 20:
                try:
                    diff_result = subprocess.run(
                        ["git", "diff", "--stat"],
                        cwd=session.working_dir,
                        capture_output=True, text=True, timeout=30,
                    )
                    if diff_result.stdout.strip():
                        builder_output = (
                            f"Builder made the following file changes:\n{diff_result.stdout}\n\n"
                            "Please review the actual file diffs with 'git diff' to verify correctness."
                        )
                except Exception:
                    pass

            if not (builder_output or "").strip():
                session.status = "error"
                session.result = f"Builder produced no output (iteration {iteration})"
                session._save_state()
                return

            session.add_message("builder", "reviewer", builder_output)

            # Reviewer
            session.agents["reviewer"]["status"] = "busy"
            session.agents["reviewer"]["started_at"] = time.strftime("%Y-%m-%dT%H:%M:%S")
            session.agents["reviewer"]["last_output"] = ""
            session._save_state()

            reviewer_prompt = (
                SYSTEM_PROMPTS["reviewer"]
                + f"\n\nOriginal task from user:\n{session.task}"
                + f"\n\nBuilder output (iteration {iteration}):\n{builder_output}"
            )
            try:
                if agent_modes["reviewer"] == "api":
                    reviewer_output, r_in, r_out = _invoke_api_agent(
                        "reviewer", reviewer_prompt,
                        system_prompt=SYSTEM_PROMPTS["reviewer"],
                        log_path=session_log_dir / "reviewer.log",
                        timeout=session.timeout,
                        model=session.models.get("reviewer", ""),
                        session_id=session.session_id,
                        working_dir=session.working_dir,
                        display_name=display_names["reviewer"],
                    )
                    r_ctx = r_in
                else:
                    reviewer_output, r_in, r_out, r_ctx = _invoke_agent(
                        "reviewer", reviewer_prompt, session.working_dir,
                        log_path=session_log_dir / "reviewer.log",
                        skip_permissions=True, session_id=session.session_id,
                        timeout=session.timeout,
                        model=session.models.get("reviewer", ""),
                        display_name=display_names["reviewer"],
                        execution_mode=agent_modes["reviewer"],
                    )
            except subprocess.TimeoutExpired:
                session.agents["reviewer"]["status"] = "timeout"
                session.status = "error"
                session.result = "Reviewer timed out."
                session._save_state()
                return
            except RuntimeError:
                session.agents["reviewer"]["status"] = "crashed"
                session.status = "error"
                session.result = "Reviewer agent stopped unexpectedly."
                session._save_state()
                return
            session.agents["reviewer"]["input_tokens"] += r_in
            session.agents["reviewer"]["output_tokens"] += r_out
            session.agents["reviewer"]["context_tokens"] = r_ctx
            session.agents["reviewer"]["last_output"] = (reviewer_output or "")[:500]

            session.agents["reviewer"]["status"] = "done"
            if session.status == "stopped":
                session._save_state()
                return

            if not (reviewer_output or "").strip():
                session.status = "error"
                session.result = f"Reviewer produced no output (iteration {iteration})"
                session._save_state()
                return

            session.add_message("reviewer", "builder", reviewer_output)

            if "APPROVED" in reviewer_output.upper():
                result_text = f"Approved after {iteration} iteration(s): {reviewer_output[:500]}"
                if session.auto_commit:
                    try:
                        import re as _re
                        git_kw = dict(capture_output=True, text=True, encoding="utf-8", errors="replace", cwd=session.working_dir, timeout=30)
                        _EXCLUDED_PATTERNS = [
                            _re.compile(r'\.json$'),
                            _re.compile(r'^\.claude[\\/]'),
                            _re.compile(r'^AGENTS\.md$'),
                            _re.compile(r'\.log$'),
                            _re.compile(r'\.pyc$'),
                            _re.compile(r'__pycache__[\\/]'),
                            _re.compile(r'node_modules[\\/]'),
                            _re.compile(r'^\.env'),
                            _re.compile(r'secret', _re.IGNORECASE),
                            _re.compile(r'credential', _re.IGNORECASE),
                        ]
                        _ALLOWED_JSON = {'package.json', 'tsconfig.json'}
                        diff_r = subprocess.run(["git", "diff", "--name-only"], **git_kw)
                        status_r = subprocess.run(["git", "status", "--porcelain"], **git_kw)
                        changed_files: set[str] = set()
                        for line in diff_r.stdout.splitlines():
                            f = line.strip()
                            if f:
                                changed_files.add(f)
                        for line in status_r.stdout.splitlines():
                            f = line[3:].strip()
                            if f:
                                changed_files.add(f)
                        safe_files = []
                        for f in changed_files:
                            basename = f.replace('\\', '/').split('/')[-1]
                            excluded = False
                            for pat in _EXCLUDED_PATTERNS:
                                if pat.search(f.replace('\\', '/')):
                                    if pat.pattern == r'\.json$' and basename in _ALLOWED_JSON:
                                        continue
                                    excluded = True
                                    break
                            if not excluded:
                                safe_files.append(f)
                        if not safe_files:
                            result_text += "\n\n--- Auto-commit skipped: no files passed safety filter ---"
                            session.status = "completed"
                            session.result = result_text
                            session._save_state()
                            return
                        subprocess.run(["git", "add", "--"] + safe_files, **git_kw)
                        reviewer_summary = _extract_commit_from_reviewer(reviewer_output)
                        safe_task = reviewer_summary or _extract_task_text(session.task) or "dashboard updates"
                        commit_msg = f"agent: {safe_task[:72]}"
                        cr = subprocess.run(["git", "commit", "-m", commit_msg], **git_kw)
                        if cr.returncode == 0:
                            session.auto_committed = True
                            result_text += f"\n\n--- Auto-committed ---\n{cr.stdout.strip()}"
                        else:
                            result_text += f"\n\n--- Auto-commit skipped: {(cr.stdout + cr.stderr).strip()} ---"
                    except Exception as exc:
                        result_text += f"\n\n--- Auto-commit skipped: {exc} ---"
                session.status = "completed"
                session.result = result_text
                session._save_state()
                return

            # Changes requested — feed back to builder
            builder_input = (
                f"The reviewer requested changes:\n{reviewer_output}\n\n"
                f"Original manager specification:\n{manager_output}\n\n"
                "Please address the reviewer's feedback."
            )

        # Max iterations reached
        session.status = "completed"
        session.result = f"Completed after {MAX_ITERATIONS} iterations (max reached)"
        session._save_state()

    except subprocess.TimeoutExpired:
        session.status = "error"
        minutes = session.timeout // 60
        session.result = f"Task timed out after {minutes} minutes. Try breaking the task into smaller steps or increasing the timeout."
        session._save_state()
    except Exception as exc:
        session.status = "error"
        session.result = f"Orchestration error: {exc}"
        session._save_state()


# ---------------------------------------------------------------------------
# Public API
# ---------------------------------------------------------------------------

_BLOCKED_WIN = {"windows", "system32", "syswow64", "program files", "program files (x86)", "programdata", "$recycle.bin", "recovery"}
_BLOCKED_NIX = {"/etc", "/var", "/proc", "/sys", "/boot"}


def start_run(task: str, working_dir: Optional[str] = None, context: Optional[str] = None, auto_commit: bool = True, timeout_minutes: int = 60,
              manager_model: str = "", builder_model: str = "", reviewer_model: str = "", user_name: str = "",
              blocked_mcp_servers: Optional[list[str]] = None) -> dict:
    """Start a new agent run. Returns session info."""
    global _current_session, _orchestration_thread

    if working_dir is None:
        working_dir = os.getcwd()

    wd = Path(working_dir).resolve()
    if not wd.exists() or not wd.is_dir():
        return {"error": f"Working directory does not exist or is not a directory: {wd}"}
    parts_lower = [part.lower() for part in wd.parts]
    if sys.platform == "win32":
        if any(part in _BLOCKED_WIN for part in parts_lower):
            return {"error": f"Working directory not allowed: {wd}"}
    else:
        str_wd = str(wd)
        if any(str_wd == bp or str_wd.startswith(bp + "/") for bp in _BLOCKED_NIX):
            return {"error": f"Working directory not allowed: {wd}"}

    if blocked_mcp_servers is None:
        blocked_mcp_servers = get_blocked_servers_for_project(str(wd))

    with _lock:
        if _current_session and _current_session.status == "running":
            return {"error": "A session is already running", "session_id": _current_session.session_id}

        session = Session(task=task, working_dir=working_dir, context=context, auto_commit=auto_commit, timeout_minutes=timeout_minutes,
                          manager_model=manager_model, builder_model=builder_model, reviewer_model=reviewer_model, user_name=user_name,
                          blocked_mcp_servers=blocked_mcp_servers)
        _current_session = session

    session._save_state()

    _orchestration_thread = threading.Thread(
        target=_orchestrate, args=(session,), daemon=False, name="orchestrator"
    )
    _orchestration_thread.start()

    return {"session_id": session.session_id, "status": "starting"}


def get_status() -> dict:
    """Return current session status for dashboard."""
    with _lock:
        if _current_session:
            return _current_session.to_dict()

    if STATE_FILE.exists():
        try:
            return json.loads(STATE_FILE.read_text(encoding="utf-8"))
        except (OSError, json.JSONDecodeError):
            pass

    return {"session_id": None, "status": "idle", "agents": {}, "messages": []}


def send_manual_message(to_agent: str, content: str) -> dict:
    """Send a manual message to a specific agent (no-op in --print mode)."""
    return {"error": "Manual messages not supported in --print mode. Agents run one-shot."}


def stop_all() -> None:
    """Stop the current session."""
    global _current_session
    proc_to_kill = None
    with _lock:
        if _current_session:
            _current_session.status = "stopped"
            for role in ("manager", "builder", "reviewer"):
                if _current_session.agents.get(role, {}).get("status") in ("busy", "idle"):
                    _current_session.agents[role]["status"] = "stopped"
            _current_session._save_state()
        proc_to_kill = _current_process
    if proc_to_kill:
        try:
            proc_to_kill.terminate()
            try:
                proc_to_kill.wait(timeout=5)
            except subprocess.TimeoutExpired:
                proc_to_kill.kill()
        except Exception:
            pass


def reset_session() -> dict:
    """Clear completed/stopped session so a new task can start fresh."""
    global _current_session
    with _lock:
        if _current_session and _current_session.status == "running":
            return {"error": "Cannot reset while a session is running"}
        _current_session = None
    try:
        if STATE_FILE.exists():
            STATE_FILE.unlink()
    except OSError:
        pass
    return {"success": True}


def get_messages(limit: int = 50) -> list[dict]:
    """Return recent messages from current session."""
    with _lock:
        if _current_session:
            return _current_session.messages[-limit:]

    if STATE_FILE.exists():
        try:
            data = json.loads(STATE_FILE.read_text(encoding="utf-8"))
            return data.get("messages", [])[-limit:]
        except (OSError, json.JSONDecodeError):
            pass

    return []
