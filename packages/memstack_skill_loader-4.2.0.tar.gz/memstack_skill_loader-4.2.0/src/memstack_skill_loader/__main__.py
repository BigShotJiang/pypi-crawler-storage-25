"""Entry point for python -m memstack_skill_loader."""

import asyncio
import sys
import time

from .server import run


def _run_agents(task: str) -> None:
    """Start agent runner and print live message log until done."""
    from . import agent_runner

    print(f"\033[1;36m{'='*60}\033[0m")
    print(f"\033[1;36m  Agent Runner — Task Orchestration\033[0m")
    print(f"\033[1;36m{'='*60}\033[0m")
    print(f"\n  Task: {task}")
    print(f"  Working dir: {sys.argv[3] if len(sys.argv) > 3 else '.'}")
    print(f"\n  Press Ctrl+C to stop all agents.\n")

    working_dir = sys.argv[3] if len(sys.argv) > 3 else None
    result = agent_runner.start_run(task=task, working_dir=working_dir)

    if "error" in result:
        print(f"\033[31mError: {result['error']}\033[0m", file=sys.stderr)
        sys.exit(1)

    print(f"  Session: {result['session_id']}\n")
    print(f"\033[90m{'─'*60}\033[0m")

    seen_messages = 0
    try:
        while True:
            time.sleep(2)
            status = agent_runner.get_status()

            # Print new messages
            messages = status.get("messages", [])
            for msg in messages[seen_messages:]:
                from_name = msg.get("from", "?")
                to_name = msg.get("to", "?")
                content = msg.get("content", "")[:200]
                ts = msg.get("timestamp", "")

                color = "\033[35m" if from_name == "manager" else \
                        "\033[36m" if from_name == "builder" else \
                        "\033[32m" if from_name == "reviewer" else "\033[90m"

                print(f"  {color}{from_name}\033[0m → \033[37m{to_name}\033[0m")
                for line in content.split("\n")[:5]:
                    print(f"    {line}")
                print()

            seen_messages = len(messages)

            # Check if done
            session_status = status.get("status", "")
            if session_status in ("completed", "error", "stopped"):
                print(f"\033[90m{'─'*60}\033[0m")
                color = "\033[32m" if session_status == "completed" else "\033[31m"
                print(f"\n  {color}Status: {session_status}\033[0m")
                result_text = status.get("result", "")
                if result_text:
                    print(f"  {result_text[:300]}")
                print()
                break

    except KeyboardInterrupt:
        print("\n\n  Stopping agents...")
        agent_runner.stop_all()
        print("  All agents stopped.")


def main():
    if len(sys.argv) > 1 and sys.argv[1] == "dashboard":
        from .dashboard import start_dashboard
        start_dashboard()
    elif len(sys.argv) > 2 and sys.argv[1] == "run":
        task = " ".join(sys.argv[2:])
        _run_agents(task)
    elif len(sys.argv) > 1 and sys.argv[1] == "proxy":
        import argparse
        parser = argparse.ArgumentParser(prog="memstack proxy")
        parser.add_argument("--port", type=int, default=8787)
        parser.add_argument("--host", default="127.0.0.1")
        parser.add_argument("--verbose", action="store_true", help="Show parser diagnostics")
        args = parser.parse_args(sys.argv[2:])
        from .proxy.server import start_proxy
        start_proxy(host=args.host, port=args.port, verbose=args.verbose)
    elif len(sys.argv) > 1 and sys.argv[1] == "run":
        print("Usage: python -m memstack_skill_loader run \"Your task description\"",
              file=sys.stderr)
        sys.exit(1)
    else:
        asyncio.run(run())


if __name__ == "__main__":
    main()
