# MemStack Search - Semantic and keyword skill matching
"""Semantic search against the LanceDB skill index."""

import os
import sys
from pathlib import Path

import lancedb

from .config import Config, load_config

_model = None
_db = None
_table = None


def _get_model(config: Config):
    """Lazy-load the sentence-transformers model."""
    global _model
    if _model is None:
        from sentence_transformers import SentenceTransformer
        _model = SentenceTransformer(config.embedding_model)
    return _model


def warmup_model(config: Config):
    """Pre-load the embedding model into memory. Call from a background thread at startup."""
    cache_dir = os.environ.get("HF_HOME") or os.environ.get(
        "TRANSFORMERS_CACHE", os.path.join(Path.home(), ".cache", "huggingface")
    )
    print(f"HuggingFace cache directory: {cache_dir}", file=sys.stderr)
    print(f"Loading embedding model '{config.embedding_model}' in background...", file=sys.stderr)
    try:
        _get_model(config)
        print("Embedding model loaded and ready.", file=sys.stderr)
    except Exception as e:
        print(f"Background model warmup failed: {e}", file=sys.stderr)


def _get_table(config: Config):
    """Get the LanceDB skills table, return None if not indexed yet."""
    global _db, _table
    if _table is None:
        db_path = str(config.resolved_vector_db_path)
        if not Path(db_path).exists():
            return None
        _db = lancedb.connect(db_path)
        try:
            _table = _db.open_table("skills")
        except Exception:
            return None
    return _table


def reset_cache():
    """Reset cached db/table/model. Call after reindexing."""
    global _db, _table, _model
    _db = None
    _table = None
    _model = None


def search_skills(query: str, config: Config | None = None, top_k: int | None = None) -> list[dict]:
    """Semantic search for skills matching the query.

    Returns list of dicts with: name, description, source_label, content, score
    """
    if config is None:
        config = load_config()
    if top_k is None:
        top_k = config.default_top_k

    table = _get_table(config)
    if table is None:
        return []

    model = _get_model(config)
    query_vector = model.encode(query).tolist()

    results = (
        table.search(query_vector)
        .metric("cosine")
        .limit(top_k)
        .to_pandas()
    )

    skills = []
    for _, row in results.iterrows():
        # Cosine distance is 0-2; convert to similarity 0-1
        distance = row.get("_distance", 0)
        similarity = round(max(0, 1 - distance), 4)
        skills.append({
            "name": row["name"],
            "description": row["description"],
            "source_label": row["source_label"],
            "content": row["content"],
            "filepath": row["filepath"],
            "score": similarity,
        })

    return skills


def list_all_skills(config: Config | None = None) -> list[dict]:
    """Return all indexed skills (name + description only, no content)."""
    if config is None:
        config = load_config()

    table = _get_table(config)
    if table is None:
        return []

    df = table.to_pandas()
    skills = []
    for _, row in df.iterrows():
        skills.append({
            "name": row["name"],
            "description": row["description"],
            "source_label": row["source_label"],
        })

    return sorted(skills, key=lambda s: s["name"])


def get_skill_by_name(name: str, config: Config | None = None) -> dict | None:
    """Get a skill by exact or fuzzy name match."""
    if config is None:
        config = load_config()

    table = _get_table(config)
    if table is None:
        return None

    df = table.to_pandas()
    name_lower = name.lower().replace("-", " ").replace("_", " ")

    # Exact match first
    for _, row in df.iterrows():
        if row["name"].lower() == name_lower:
            return {
                "name": row["name"],
                "description": row["description"],
                "source_label": row["source_label"],
                "content": row["content"],
                "filepath": row["filepath"],
            }

    # Fuzzy: check if query is substring of name or name is substring of query
    for _, row in df.iterrows():
        row_name_lower = row["name"].lower()
        if name_lower in row_name_lower or row_name_lower in name_lower:
            return {
                "name": row["name"],
                "description": row["description"],
                "source_label": row["source_label"],
                "content": row["content"],
                "filepath": row["filepath"],
            }

    # Last resort: semantic search with top_k=1
    results = search_skills(name, config, top_k=1)
    if results and results[0]["score"] > 0.5:
        return results[0]

    return None
