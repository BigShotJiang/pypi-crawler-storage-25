# MemStack Categories - Skill classification and routing
"""Shared category mapping for skill slugs."""

CATEGORY_MAP = {
    # Internal
    "__list__": "Core",
    # Automation
    "cron-scheduler": "Automation", "n8n-workflow-builder": "Automation",
    "api-integration": "Automation", "webhook-designer": "Automation",
    "content-pipeline": "Automation", "hosted-mcp-catalog": "Automation",
    # Business
    "quill": "Business", "scan": "Business", "governor": "Business",
    "client-onboarding": "Business", "contract-template": "Business", "financial-model": "Business",
    "freelancer-toolkit": "Business", "invoice-generator": "Business", "scope-of-work": "Business",
    "sop-builder": "Business", "proposal-writer": "Business",
    # Content
    "humanize": "Content", "blog-post": "Content", "email-sequence": "Content",
    "landing-page-copy": "Content", "newsletter": "Content", "product-description": "Content",
    "tiktok-script": "Content", "twitter-thread": "Content", "youtube-script": "Content",
    "kdp-format": "Content",
    # Deployment
    "railway-deploy": "Deployment", "docker-setup": "Deployment", "netlify-deploy": "Deployment",
    "domain-ssl": "Deployment", "hetzner-setup": "Deployment", "ci-cd-pipeline": "Deployment",
    "marketplace-submit": "Deployment",
    # Development
    "forge": "Development", "shard": "Development",
    "state": "Development", "work": "Development", "verify": "Development",
    "project": "Development", "familiar": "Development", "api-designer": "Development",
    "code-reviewer": "Development", "database-architect": "Development", "migration-planner": "Development",
    "performance-audit": "Development", "refactor-planner": "Development", "test-writer": "Development",
    "changelog-generator": "Development", "mentor": "Development", "webapp-testing": "Development",
    # Core
    "compress": "Core", "diary": "Core", "echo": "Core", "grimoire": "Core",
    "sight": "Core", "token-optimization": "Core",
    # Marketing
    "facebook-ad": "Marketing", "google-ad": "Marketing",
    "launch-plan": "Marketing", "competitor-analysis": "Marketing", "pricing-strategy": "Marketing",
    "lead-magnet": "Marketing", "webinar-script": "Marketing", "sales-funnel": "Marketing",
    # SEO & GEO
    "site-audit": "SEO & GEO", "keyword-research": "SEO & GEO",
    "meta-tag-optimizer": "SEO & GEO", "schema-markup": "SEO & GEO",
    "ai-search-visibility": "SEO & GEO", "local-seo": "SEO & GEO",
    # Product
    "prd-writer": "Product", "feature-spec": "Product",
    "user-story-generator": "Product", "mvp-scoper": "Product", "roadmap-builder": "Product",
    "feedback-analyzer": "Product",
    # Security
    "advanced-security": "Security", "env-manager-pro": "Security",
    "api-audit": "Security", "csp-headers": "Security", "dependency-audit": "Security",
    "owasp-top10": "Security", "owasp-top-10": "Security",
    "rls-checker": "Security", "rls-guardian": "Security",
    "secrets-scanner": "Security",
    # Pro skills (for backfill matching)
    "api-docs": "Core", "branching": "Core", "consolidate": "Core", "context-db": "Core",
    "multi-agent": "Development", "codebase-index": "Development", "doc-index": "Development",
    "diagram-generator": "Development", "browser-use": "Development", "session-restore": "Core",
    "drift-detection": "Security", "mcp-builder": "Development", "claude-api-helper": "Development",
    "test-generator": "Development", "log-analyzer": "Development",
    "performance-profiler": "Development", "dependency-auditor": "Security",
    "git-worktrees": "Development", "error-handler": "Development", "web-scraper": "Automation",
    "hooks-integration": "Development",
}


def derive_category(slug: str) -> str:
    """Derive a display category from a skill slug."""
    return CATEGORY_MAP.get(slug, "Other")
