# MemStack Version Check - PyPI update detection
"""Check for MemStack updates via the PyPI JSON API."""

import json
import sys
import time
from pathlib import Path

PYPI_URL = "https://pypi.org/pypi/memstack-skill-loader/json"
CACHE_FILE = Path.home() / ".memstack" / "version-check.json"
CACHE_TTL = 86400  # 24 hours


def _get_local_version() -> str | None:
    """Get the installed package version via importlib.metadata."""
    try:
        from importlib.metadata import version
        return version("memstack-skill-loader")
    except Exception:
        return None


def _read_cache() -> dict | None:
    """Read cached version check result if still valid."""
    try:
        if not CACHE_FILE.exists():
            return None
        data = json.loads(CACHE_FILE.read_text(encoding="utf-8"))
        if time.time() - data.get("checked_at", 0) < CACHE_TTL:
            return data
    except (json.JSONDecodeError, OSError, KeyError):
        pass
    return None


def _write_cache(remote_version: str) -> None:
    """Cache the remote version check result."""
    try:
        CACHE_FILE.parent.mkdir(parents=True, exist_ok=True)
        CACHE_FILE.write_text(
            json.dumps({"remote_version": remote_version, "checked_at": time.time()}, indent=2),
            encoding="utf-8",
        )
    except OSError:
        pass


def check_for_updates() -> None:
    """Check PyPI for a newer MemStack version. Prints to stderr if update available."""
    try:
        local_version = _get_local_version()
        if not local_version:
            return

        cached = _read_cache()
        if cached:
            remote_version = cached.get("remote_version", "")
            if remote_version and remote_version != local_version:
                print(
                    f"[memstack] Update available: {remote_version} (you have {local_version}). "
                    f"Run: pip install memstack-skill-loader --upgrade",
                    file=sys.stderr,
                )
            return

        import httpx
        response = httpx.get(PYPI_URL, timeout=5.0, follow_redirects=True)
        if response.status_code != 200:
            return

        data = response.json()
        remote_version = data.get("info", {}).get("version", "")
        if not remote_version:
            return

        _write_cache(remote_version)

        if remote_version != local_version:
            print(
                f"[memstack] Update available: {remote_version} (you have {local_version}). "
                f"Run: pip install memstack-skill-loader --upgrade",
                file=sys.stderr,
            )
    except Exception:
        pass
