# MemStack Config - Path resolution and skill discovery
"""Config loading and validation for MemStack Skill Loader."""

import json
import os
import sys
from dataclasses import dataclass, field
from pathlib import Path


@dataclass
class SkillSource:
    type: str
    path: str
    pattern: str = "**/SKILL.md"
    label: str = "Unknown"


@dataclass
class Config:
    skill_sources: list[SkillSource] = field(default_factory=list)
    embedding_model: str = "all-MiniLM-L6-v2"
    default_top_k: int = 3
    vector_db_path: str = "./vectors"
    auto_reindex_on_start: bool = False
    _config_dir: Path = field(default_factory=lambda: Path.cwd(), repr=False)

    @property
    def resolved_vector_db_path(self) -> Path:
        p = Path(self.vector_db_path).expanduser()
        if not p.is_absolute():
            p = self._config_dir / p
        return p.resolve()

    @property
    def pro_skills_dir(self) -> Path:
        """Return the pro-skills directory — customer download first, bundled fallback."""
        customer_dir = Path.home() / ".memstack" / "pro-skills"
        if customer_dir.exists() and (customer_dir / ".complete").exists():
            return customer_dir
        return Path(__file__).resolve().parent.parent.parent / "pro-skills"

    def with_pro_skills(self) -> "Config":
        """Return a copy of this config with the bundled pro-skills source added."""
        pro_dir = self.pro_skills_dir
        if not pro_dir.exists():
            return self
        if any(Path(s.path).resolve() == pro_dir.resolve() for s in self.skill_sources):
            return self
        pro_source = SkillSource(
            type="local",
            path=str(pro_dir),
            pattern="**/SKILL.md",
            label="MemStack Pro",
        )
        return Config(
            skill_sources=self.skill_sources + [pro_source],
            embedding_model=self.embedding_model,
            default_top_k=self.default_top_k,
            vector_db_path=self.vector_db_path,
            auto_reindex_on_start=self.auto_reindex_on_start,
            _config_dir=self._config_dir,
        )


def _auto_discover_skills() -> SkillSource | None:
    """Scan common locations for MemStack skills when no config.json exists (PyPI installs)."""
    env_dir = os.environ.get("MEMSTACK_SKILLS_DIR")
    if env_dir:
        p = Path(env_dir).expanduser()
        if p.exists():
            skill_files = list(p.glob("**/SKILL.md"))
            if skill_files:
                print(f"Using MEMSTACK_SKILLS_DIR: {p} ({len(skill_files)} skills found)", file=sys.stderr)
                return SkillSource(type="local", path=str(p), pattern="**/SKILL.md", label="MemStack")

    home = Path.home()
    candidates = [
        home / ".claude" / "plugins" / "marketplaces" / "cwinvestments-memstack" / "skills",
        home / ".claude" / "plugins" / "cache" / "cwinvestments-memstack" / "memstack",
        home / "memstack" / "skills",
        Path.cwd().parent / "memstack" / "skills",
    ]

    for candidate in candidates:
        if candidate.name == "memstack":
            version_dirs = sorted(candidate.glob("*/skills"), reverse=True)
            for vdir in version_dirs:
                skill_files = list(vdir.glob("**/SKILL.md"))
                if skill_files:
                    print(f"Auto-detected skills at: {vdir} ({len(skill_files)} skills found)", file=sys.stderr)
                    return SkillSource(type="local", path=str(vdir), pattern="**/SKILL.md", label="MemStack")
        else:
            if candidate.exists():
                skill_files = list(candidate.glob("**/SKILL.md"))
                if skill_files:
                    print(f"Auto-detected skills at: {candidate} ({len(skill_files)} skills found)", file=sys.stderr)
                    return SkillSource(type="local", path=str(candidate), pattern="**/SKILL.md", label="MemStack")

    print(
        "No skills found. Install the MemStack plugin first: "
        "/plugin marketplace add cwinvestments/memstack",
        file=sys.stderr,
    )
    return None


def load_config(config_path: Path | None = None) -> Config:
    """Load config from JSON file. Falls back to auto-discovery if not found."""
    if config_path is None:
        config_path = Path(__file__).resolve().parent.parent.parent / "config.json"

    if not config_path.exists():
        source = _auto_discover_skills()
        config = Config(
            skill_sources=[source] if source else [],
            auto_reindex_on_start=True,
        )
        if os.environ.get("MEMSTACK_PRO_LICENSE_KEY"):
            config = config.with_pro_skills()
        return config

    try:
        with open(config_path, encoding="utf-8") as f:
            data = json.load(f)
    except json.JSONDecodeError as e:
        print(f"Invalid JSON in {config_path}: {e}", file=sys.stderr)
        return Config()

    sources = []
    env_skills_dir = os.environ.get("MEMSTACK_SKILLS_DIR")
    for s in data.get("skill_sources", []):
        if "path" not in s:
            print(f"Warning: skill source missing 'path', skipping: {s}", file=sys.stderr)
            continue
        skill_path = env_skills_dir if env_skills_dir else str(Path(s["path"]).expanduser())
        sources.append(SkillSource(
            type=s.get("type", "local"),
            path=skill_path,
            pattern=s.get("pattern", "**/SKILL.md"),
            label=s.get("label", "Unknown"),
        ))

    for source in sources:
        p = Path(source.path).expanduser()
        if not p.exists():
            sibling = config_path.parent.resolve().parent / "memstack" / "skills"
            if sibling.exists():
                source.path = str(sibling)
                print(f"Auto-detected skills at {sibling}", file=sys.stderr)

    config = Config(
        skill_sources=sources,
        embedding_model=data.get("embedding_model", "all-MiniLM-L6-v2"),
        default_top_k=data.get("default_top_k", 3),
        vector_db_path=data.get("vector_db_path", "./vectors"),
        auto_reindex_on_start=data.get("auto_reindex_on_start", False),
        _config_dir=config_path.parent.resolve(),
    )

    # Auto-detect pro-skills if license key is set (env var or license.json)
    if os.environ.get("MEMSTACK_PRO_LICENSE_KEY") or (Path.home() / ".memstack" / "license.json").exists():
        config = config.with_pro_skills()

    return config
