"""MCP server entry point — exposes skill search tools via stdio transport."""

import asyncio
import json
import os
import sys
import tempfile
import time
import uuid
import zipfile
from pathlib import Path

from mcp.server import Server
from mcp.server.stdio import stdio_server
from mcp.types import TextContent, Tool

from .config import load_config
from .license import (
    MAX_KEY_LEN,
    clear_cache,
    get_license_key,
    is_pro_exclusive,
    save_license_key,
    validate_license,
)
from .compression import clear_cache as clear_compression_cache, get_or_compress
from .skill_config import load_skill_config, is_skill_enabled, toggle_skill as _toggle_skill_config, set_mode as _set_mode_config, SkillConfig
from .stats import get_compression_stats, get_dashboard_data, log_compression, log_skill_fire, log_tool_call
from .categories import CATEGORY_MAP as _CATEGORY_MAP, derive_category as _derive_category
from .tfidf_search import get_skill_by_name, list_all_skills, reset_cache, search_skills
from . import memory_db
from . import agent_runner

app = Server("memstack-skill-loader")
_config = None
_session_id: str | None = None
_last_tool_call_time: float = 0.0
_session_start_time: float = 0.0
_SESSION_TIMEOUT = 300  # 5 minutes


def _get_session_id() -> str:
    global _session_id, _session_start_time
    if _session_id is None:
        _session_id = str(uuid.uuid4())
        _session_start_time = time.time()
    return _session_id


def _maybe_close_session() -> None:
    """If 5+ minutes since last tool call, auto-summarize and start new session."""
    global _session_id, _last_tool_call_time, _session_start_time
    if _last_tool_call_time == 0.0 or _session_id is None:
        return
    if time.time() - _last_tool_call_time < _SESSION_TIMEOUT:
        return
    try:
        project_dir = os.getcwd()
        old_session = _session_id
        events = memory_db.get_recent_events(project_dir, limit=50)
        session_events = [e for e in events if e.get("session_id") == old_session]
        if not session_events:
            return
        skills_fired = set()
        files_mentioned = set()
        decisions = []
        for ev in session_events:
            details = ev.get("details") or {}
            if isinstance(details, dict):
                if details.get("skill_name"):
                    skills_fired.add(details["skill_name"])
                if details.get("files"):
                    files_mentioned.update(details["files"])
            if ev.get("event_type") == "decision":
                decisions.append(ev["summary"])
        summary_parts = []
        if skills_fired:
            summary_parts.append(f"Skills used: {', '.join(sorted(skills_fired))}")
        if decisions:
            summary_parts.append(f"Decisions: {'; '.join(decisions)}")
        summary_parts.append(f"Total events: {len(session_events)}")
        summary_text = ". ".join(summary_parts)
        started = session_events[-1].get("timestamp", "")
        ended = session_events[0].get("timestamp", "")
        memory_db.insert_summary(
            project_dir=project_dir,
            session_id=old_session,
            started_at=started,
            ended_at=ended,
            summary=summary_text,
            decisions=decisions if decisions else None,
            files_changed=list(files_mentioned) if files_mentioned else None,
        )
        print(f"[memstack-memory] Auto-summarized session {old_session[:8]}...", file=sys.stderr)
    except Exception as exc:
        print(f"[memstack-memory] Auto-summary failed: {exc}", file=sys.stderr)
    finally:
        _session_id = None
        _session_start_time = 0.0


USAGE_FILE = Path.home() / ".memstack" / "skill-usage.json"

PRO_BUNDLE_URL = "https://admin.cwaffiliateinvestments.com/api/skills/pro-bundle"
PRO_SKILLS_HOME = Path.home() / ".memstack" / "pro-skills"
_MAX_BUNDLE_SIZE = 10 * 1024 * 1024  # 10 MB


async def _download_pro_skills(license_key: str, force: bool = False) -> str:
    """Download and extract Pro skills bundle to ~/.memstack/pro-skills/."""
    sentinel = PRO_SKILLS_HOME / ".complete"
    if sentinel.exists() and not force:
        return f"Pro skills already present at {PRO_SKILLS_HOME}"

    import httpx

    print("[memstack] Downloading Pro skills...", file=sys.stderr)
    async with httpx.AsyncClient(timeout=60) as client:
        resp = await client.get(
            PRO_BUNDLE_URL,
            headers={"Authorization": f"Bearer {license_key}"},
        )
        resp.raise_for_status()

    content = resp.content
    if len(content) > _MAX_BUNDLE_SIZE:
        raise ValueError(f"Bundle too large ({len(content)} bytes, limit {_MAX_BUNDLE_SIZE})")

    tmp_path = None
    tmp_dir = None
    try:
        with tempfile.NamedTemporaryFile(suffix=".zip", delete=False) as tmp:
            tmp.write(content)
            tmp_path = tmp.name

        with zipfile.ZipFile(tmp_path) as zf:
            # Zip-slip protection
            for member in zf.namelist():
                member_path = Path(member)
                if member_path.is_absolute() or ".." in member_path.parts:
                    raise ValueError(f"Unsafe zip member: {member}")

            tmp_dir = tempfile.mkdtemp(
                prefix="pro-skills-tmp-",
                dir=PRO_SKILLS_HOME.parent,
            )
            zf.extractall(tmp_dir)

        # Atomic swap
        if PRO_SKILLS_HOME.exists():
            import shutil
            shutil.rmtree(PRO_SKILLS_HOME)
        os.rename(tmp_dir, str(PRO_SKILLS_HOME))
        tmp_dir = None  # rename succeeded, don't clean up

        # Count installed skills
        skill_count = sum(1 for _ in PRO_SKILLS_HOME.rglob("SKILL.md"))

        # Write sentinel
        (PRO_SKILLS_HOME / ".complete").write_text("ok", encoding="utf-8")

        msg = f"{skill_count} Pro skills installed to {PRO_SKILLS_HOME}"
        print(f"[memstack] {msg}", file=sys.stderr)
        return msg
    finally:
        if tmp_path and os.path.exists(tmp_path):
            os.unlink(tmp_path)
        if tmp_dir and os.path.exists(tmp_dir):
            import shutil
            shutil.rmtree(tmp_dir, ignore_errors=True)


def _skill_enabled(skill_name: str) -> bool:
    """Check if a skill is enabled under the current project config."""
    config = load_skill_config()
    return is_skill_enabled(config, skill_name)


# Category derivation — imported from shared categories.py

def _record_skill_usage(skill_name: str) -> None:
    """Increment the usage counter for a skill."""
    try:
        USAGE_FILE.parent.mkdir(parents=True, exist_ok=True)
        data: dict[str, int] = {}
        if USAGE_FILE.exists():
            data = json.loads(USAGE_FILE.read_text(encoding="utf-8"))
        data[skill_name] = data.get(skill_name, 0) + 1
        tmp = USAGE_FILE.with_suffix(".tmp")
        tmp.write_text(json.dumps(data, indent=2), encoding="utf-8")
        tmp.replace(USAGE_FILE)
    except (OSError, json.JSONDecodeError) as exc:
        print(f"[memstack] failed to record skill usage: {exc}", file=sys.stderr)

_BLOCKED_MSG = (
    "MemStack\u2122 grace period expired.\n\n"
    "Run `activate_license` with your **email** to unlock 85 free skills.\n\n"
    "Example: `activate_license(key=\"free\", email=\"you@example.com\")`\n\n"
    "Already have a Pro key? Run `activate_license(key=\"your-key\", email=\"you@example.com\")`."
)
def _pro_skill_notice(skill_name: str) -> str:
    return f"{skill_name} is a Pro skill. Details at memstack.pro"
_GRACE_EXPIRED_MSG = (
    "\U0001f512 MemStack\u2122 grace period expired. "
    "Run `activate_license` with your email to unlock 85 free skills."
)
_TAMPERED_MSG = (
    "\U0001f512 MemStack\u2122 Pro: License file integrity check failed. "
    "Get your key at https://memstack.pro"
)


def _grace_banner(status) -> str:
    """Return a warning banner if the user is on a grace period, else empty."""
    if status.grace_period and status.grace_days_remaining > 0:
        return (
            f"> \u26a0\ufe0f **MemStack\u2122 free trial:** "
            f"**{status.grace_days_remaining} days** remaining. "
            f"Run `activate_license` with your email to keep access permanently.\n\n"
        )
    return ""


def _get_config():
    global _config
    if _config is None:
        _config = load_config()
    return _config


def _check_index() -> bool:
    """Return True if TF-IDF index exists on disk."""
    config = _get_config()
    pkl_path = config.resolved_vector_db_path / "tfidf_index.pkl"
    return pkl_path.exists()


@app.list_tools()
async def list_tools() -> list[Tool]:
    return [
        Tool(
            name="find_skill",
            description=(
                "Search MemStack\u2122 skills by describing what you need. Returns the most "
                "relevant skill(s) with full instructions. Call this BEFORE starting any "
                "task to check if a skill exists for it.\n"
                "Workflow: 1) find_skill (preview) to identify the right skill, "
                "2) get_skill to load full content for the one you need."
            ),
            inputSchema={
                "type": "object",
                "properties": {
                    "query": {
                        "type": "string",
                        "description": (
                            "Natural language description of what you need "
                            "(e.g., 'deploy to Railway', 'set up Supabase RLS')"
                        ),
                    },
                    "top_k": {
                        "type": "integer",
                        "description": "Number of results to return (1-10, default 3)",
                        "minimum": 1,
                        "maximum": 10,
                        "default": 3,
                    },
                    "full": {
                        "type": "boolean",
                        "description": (
                            "Return full skill content (default false). "
                            "When false, returns name + short description + score only. "
                            "Use get_skill to fetch full content for a specific skill."
                        ),
                        "default": False,
                    },
                },
                "required": ["query"],
            },
        ),
        Tool(
            name="list_skills",
            description=(
                "List all available MemStack\u2122 skills with names and descriptions. "
                "Use this to browse the full skill catalog."
            ),
            inputSchema={
                "type": "object",
                "properties": {
                    "compact": {
                        "type": "boolean",
                        "description": (
                            "Return skill names only, grouped by category (default false). "
                            "When false, includes descriptions."
                        ),
                        "default": False,
                    },
                },
            },
        ),
        Tool(
            name="get_skill",
            description=(
                "Get the full content of a specific skill by exact name. "
                "Use after find_skill to load a specific skill."
            ),
            inputSchema={
                "type": "object",
                "properties": {
                    "name": {
                        "type": "string",
                        "description": "Skill name (case-insensitive, fuzzy match supported)",
                    },
                    "full": {
                        "type": "boolean",
                        "description": "Return uncompressed skill content. Default false (compressed).",
                        "default": False,
                    },
                },
                "required": ["name"],
            },
        ),
        Tool(
            name="reindex_skills",
            description="Rebuild the skill vector index. Run after adding or modifying skills.",
            inputSchema={
                "type": "object",
                "properties": {},
            },
        ),
        Tool(
            name="skill_stats",
            description=(
                "View MemStack\u2122 skill usage statistics. Shows most used skills, "
                "least used skills, and total activations."
            ),
            inputSchema={
                "type": "object",
                "properties": {},
            },
        ),
        Tool(
            name="manage_skills",
            description=(
                "Enable, disable, or list disabled skills for this project. "
                "Disabled skills are hidden from find_skill, list_skills, and get_skill."
            ),
            inputSchema={
                "type": "object",
                "properties": {
                    "action": {
                        "type": "string",
                        "description": "Action to perform: disable, enable, or list_disabled",
                        "enum": ["disable", "enable", "list_disabled"],
                    },
                    "skill": {
                        "type": "string",
                        "description": "Skill name to enable or disable (not required for list_disabled)",
                    },
                },
                "required": ["action"],
            },
        ),
        Tool(
            name="activate_license",
            description=(
                "Activate a MemStack license key to unlock skills. "
                "Requires your email. Use key=\"free\" for a free license. "
                "Get a Pro key at memstack.pro"
            ),
            inputSchema={
                "type": "object",
                "properties": {
                    "key": {
                        "type": "string",
                        "description": "Your MemStack license key (use \"free\" for free tier)",
                    },
                    "email": {
                        "type": "string",
                        "description": "Your email (required for activation)",
                    },
                },
                "required": ["key", "email"],
            },
        ),
        Tool(
            name="dashboard_stats",
            description=(
                "View MemStack\u2122 usage dashboard data \u2014 skill fires, trends, "
                "category breakdown, and context savings estimates."
            ),
            inputSchema={
                "type": "object",
                "properties": {},
            },
        ),
        Tool(
            name="memory_capture",
            description=(
                "Manually capture a memory event. Use to record decisions, "
                "errors, failed approaches, or any notable session event."
            ),
            inputSchema={
                "type": "object",
                "properties": {
                    "event_type": {
                        "type": "string",
                        "description": "Event type: file_edit, tool_call, error, decision, failed_approach",
                    },
                    "summary": {
                        "type": "string",
                        "description": "Brief summary of the event",
                    },
                    "details": {
                        "type": "string",
                        "description": "Optional JSON details blob",
                    },
                },
                "required": ["event_type", "summary"],
            },
        ),
        Tool(
            name="memory_search",
            description=(
                "Search across all memory (events, sessions, lessons, facts) "
                "using full-text search. Returns ranked results."
            ),
            inputSchema={
                "type": "object",
                "properties": {
                    "query": {
                        "type": "string",
                        "description": "Search query",
                    },
                    "project_only": {
                        "type": "boolean",
                        "description": "Only search current project (default true)",
                        "default": True,
                    },
                    "limit": {
                        "type": "integer",
                        "description": "Max results (default 10)",
                        "default": 10,
                    },
                },
                "required": ["query"],
            },
        ),
        Tool(
            name="memory_recall",
            description=(
                "Recall context for the current project: last session summary, "
                "recent decisions, active lessons, and key facts."
            ),
            inputSchema={
                "type": "object",
                "properties": {},
            },
        ),
        Tool(
            name="memory_lesson",
            description=(
                "Save a reusable lesson learned. Categories: gotcha, pattern, "
                "lesson, failed_approach. Can be project-scoped or global."
            ),
            inputSchema={
                "type": "object",
                "properties": {
                    "title": {
                        "type": "string",
                        "description": "Short title for the lesson",
                    },
                    "content": {
                        "type": "string",
                        "description": "Detailed lesson content",
                    },
                    "category": {
                        "type": "string",
                        "description": "Category: gotcha, pattern, lesson, or failed_approach",
                        "enum": ["gotcha", "pattern", "lesson", "failed_approach"],
                    },
                    "global": {
                        "type": "boolean",
                        "description": "Make this lesson global across all projects (default false)",
                        "default": False,
                    },
                    "stack_tags": {
                        "type": "array",
                        "items": {"type": "string"},
                        "description": "Optional tags (e.g. ['python', 'sqlite'])",
                    },
                },
                "required": ["title", "content", "category"],
            },
        ),
        Tool(
            name="memory_stats",
            description=(
                "Get memory layer statistics: event count, session count, "
                "lesson count, fact count, and database size."
            ),
            inputSchema={
                "type": "object",
                "properties": {
                    "project_dir": {
                        "type": "string",
                        "description": "Project directory (defaults to current working directory)",
                    },
                },
            },
        ),
        Tool(
            name="agent_run",
            description=(
                "Start a multi-agent task with Manager, Builder, and Reviewer. "
                "Spawns Claude Code sub-processes that collaborate autonomously. "
                "Returns a session_id to track and manage the agents."
            ),
            inputSchema={
                "type": "object",
                "properties": {
                    "task": {
                        "type": "string",
                        "description": "The task description for the agents to work on",
                    },
                    "working_dir": {
                        "type": "string",
                        "description": "Working directory for agents (defaults to cwd)",
                    },
                    "agents": {
                        "type": "object",
                        "description": (
                            "Optional agent configuration JSON. "
                            "Keys are agent names, values have 'role' and optional 'prompt'. "
                            "Defaults to manager+builder+reviewer."
                        ),
                    },
                },
                "required": ["task"],
            },
        ),
        Tool(
            name="agent_status",
            description=(
                "Get status of running agents. Shows agent names, roles, "
                "statuses, message counts, and current tasks."
            ),
            inputSchema={
                "type": "object",
                "properties": {
                    "session_id": {
                        "type": "string",
                        "description": "Session ID to check (omit to show all agents)",
                    },
                },
            },
        ),
        Tool(
            name="agent_message",
            description="Send a message to a specific agent for manual intervention.",
            inputSchema={
                "type": "object",
                "properties": {
                    "to_agent": {
                        "type": "string",
                        "description": "Name of the agent to message",
                    },
                    "content": {
                        "type": "string",
                        "description": "Message content to send",
                    },
                },
                "required": ["to_agent", "content"],
            },
        ),
        Tool(
            name="agent_stop",
            description="Stop all running agents.",
            inputSchema={
                "type": "object",
                "properties": {},
            },
        ),
    ]


@app.call_tool()
async def call_tool(name: str, arguments: dict) -> list[TextContent]:
    log_tool_call(name)
    try:
        return await _handle_tool(name, arguments)
    except Exception as e:
        print(f"Error in tool {name}: {e}", file=sys.stderr)
        return [TextContent(type="text", text=f"Error executing {name}: {e}")]


async def _handle_tool(name: str, arguments: dict) -> list[TextContent]:
    global _last_tool_call_time
    _maybe_close_session()
    _last_tool_call_time = time.time()
    config = _get_config()

    if name == "find_skill":
        t0 = time.perf_counter()
        print(f"[find_skill] start query={arguments.get('query', '')!r}", file=sys.stderr)
        if not _check_index():
            return [TextContent(
                type="text",
                text="No TF-IDF index found. Call reindex_skills first to build the index.",
            )]

        license_status = await validate_license()

        # No valid license and no grace period
        if not license_status.valid:
            if license_status.grace_tampered:
                return [TextContent(type="text", text=_TAMPERED_MSG)]
            if license_status.grace_expired:
                return [TextContent(type="text", text=_GRACE_EXPIRED_MSG)]
            return [TextContent(type="text", text=_BLOCKED_MSG)]

        query = arguments["query"]
        top_k = arguments.get("top_k", config.default_top_k)
        results = await asyncio.to_thread(search_skills, query, config, top_k)
        # Filter ignored skills
        results = [r for r in results if _skill_enabled(r["name"])]
        t1 = time.perf_counter()
        print(f"[find_skill] search done in {t1 - t0:.3f}s", file=sys.stderr)

        if not results:
            return [TextContent(type="text", text="No matching skills found.")]

        # Track usage
        project_name = os.path.basename(os.getcwd())
        for r in results:
            _record_skill_usage(r["name"])
            try:
                log_skill_fire(r["name"], category=_derive_category(r.get("slug", "")), project=project_name, tool="find_skill")
            except Exception:
                pass

        full_mode = arguments.get("full", False)
        banner = _grace_banner(license_status)
        parts = []
        for i, r in enumerate(results, 1):
            if full_mode:
                if license_status.tier == "pro" or not is_pro_exclusive(r["slug"]):
                    tier = license_status.tier or "free"
                    content, t_before, t_after = get_or_compress(r, tier=tier)
                    try:
                        log_compression(r["name"], t_before, t_after, tier)
                    except Exception:
                        pass
                    parts.append(
                        f"## {i}. {r['name']} (score: {r['score']})\n"
                        f"**Source:** {r['source_label']}\n\n"
                        f"{content}"
                    )
                else:
                    parts.append(
                        f"## {i}. {r['name']} (score: {r['score']})\n"
                        f"**Source:** {r['source_label']}\n\n"
                        + _pro_skill_notice(r["name"])
                    )
            else:
                # Preview mode: name + short description + score only
                desc = r.get("description", "")
                desc_short = desc[:120] + "..." if len(desc) > 120 else desc
                lock = ""
                if license_status.tier != "pro" and is_pro_exclusive(r["slug"]):
                    lock = " \U0001f512 Pro"
                parts.append(
                    f"{i}. **{r['name']}** (score: {r['score']}){lock}\n"
                    f"   {desc_short}"
                )
        t2 = time.perf_counter()
        print(f"[find_skill] response ready in {t2 - t0:.3f}s", file=sys.stderr)
        separator = "\n\n---\n\n" if full_mode else "\n"
        hint = "" if full_mode else "\n\n_Use `get_skill` with the skill name to load full content._"
        try:
            memory_db.insert_event(
                os.getcwd(), _get_session_id(), "skill_fire",
                f"find_skill: {arguments.get('query', '')}",
                {"query": arguments.get("query", ""), "result_count": len(parts)},
            )
        except Exception:
            pass
        return [TextContent(type="text", text=banner + separator.join(parts) + hint)]

    elif name == "list_skills":
        license_status = await validate_license()

        if not license_status.valid:
            if license_status.grace_tampered:
                return [TextContent(type="text", text=_TAMPERED_MSG)]
            if license_status.grace_expired:
                return [TextContent(type="text", text=_GRACE_EXPIRED_MSG)]
            return [TextContent(type="text", text=_BLOCKED_MSG)]

        skills = await asyncio.to_thread(list_all_skills, config)
        # Filter ignored skills
        skills = [s for s in skills if _skill_enabled(s["name"])]
        if not skills:
            return [TextContent(
                type="text",
                text="No skills indexed yet. Call reindex_skills to build the index.",
            )]

        try:
            log_skill_fire("__list__", tool="list_skills", project=os.path.basename(os.getcwd()))
        except Exception:
            pass

        compact = arguments.get("compact", False)
        banner = _grace_banner(license_status)

        if compact:
            # Group by source_label, names only
            groups: dict[str, list[str]] = {}
            for s in skills:
                label = s["source_label"]
                lock = ""
                if license_status.tier != "pro" and is_pro_exclusive(s["slug"]):
                    lock = " \U0001f512"
                groups.setdefault(label, []).append(f"{s['name']}{lock}")
            lines = [f"# MemStack\u2122 Skills ({len(skills)})\n"]
            for label, names in groups.items():
                lines.append(f"**{label}** ({len(names)}):")
                lines.append(", ".join(names))
                lines.append("")
            lines.append("_Use `get_skill` with a name to load full content._")
            return [TextContent(type="text", text=banner + "\n".join(lines))]

        lines = [f"# MemStack\u2122 Skill Catalog ({len(skills)} skills)\n"]
        for i, s in enumerate(skills, 1):
            desc = s["description"][:120] + "..." if len(s["description"]) > 120 else s["description"]
            if license_status.tier != "pro" and is_pro_exclusive(s["slug"]):
                lock = " \U0001f512 Pro"
            else:
                lock = ""
            lines.append(f"{i}. **{s['name']}** [{s['source_label']}]{lock}\n   {desc}")
        return [TextContent(type="text", text=banner + "\n".join(lines))]

    elif name == "get_skill":
        if not _check_index():
            return [TextContent(
                type="text",
                text="No TF-IDF index found. Call reindex_skills first to build the index.",
            )]

        license_status = await validate_license()

        # Check license before reading from disk
        if not license_status.valid:
            if license_status.grace_tampered:
                return [TextContent(type="text", text=_TAMPERED_MSG)]
            if license_status.grace_expired:
                return [TextContent(type="text", text=_GRACE_EXPIRED_MSG)]
            return [TextContent(type="text", text=_BLOCKED_MSG)]

        skill = await asyncio.to_thread(get_skill_by_name, arguments["name"], config)
        if skill is None:
            return [TextContent(
                type="text",
                text=f"Skill '{arguments['name']}' not found. Use list_skills to see available skills.",
            )]
        if not _skill_enabled(skill["name"]):
            return [TextContent(
                type="text",
                text=f"Skill '{skill['name']}' is disabled for this project. Enable it in the dashboard at localhost:3333 or edit .memstack/skills-enabled.json",
            )]

        # Track usage
        _record_skill_usage(skill["name"])
        try:
            log_skill_fire(skill["name"], category=_derive_category(skill.get("slug", "")), project=os.path.basename(os.getcwd()), tool="get_skill")
        except Exception:
            pass
        try:
            memory_db.insert_event(
                os.getcwd(), _get_session_id(), "skill_load",
                f"get_skill: {skill['name']}",
                {"skill_name": skill["name"]},
            )
        except Exception:
            pass

        banner = _grace_banner(license_status)
        full_mode = arguments.get("full", False)
        if license_status.tier == "pro" or not is_pro_exclusive(skill["slug"]):
            if full_mode:
                content = skill["content"]
            else:
                tier = license_status.tier or "free"
                content, tokens_before, tokens_after = get_or_compress(skill, tier=tier)
                try:
                    log_compression(skill["name"], tokens_before, tokens_after, tier)
                except Exception:
                    pass
            return [TextContent(
                type="text",
                text=banner + f"# {skill['name']}\n**Source:** {skill['source_label']}\n\n{content}",
            )]
        # Free tier + Pro-exclusive skill
        return [TextContent(
            type="text",
            text=(
                f"# {skill['name']}\n**Source:** {skill['source_label']}\n\n"
                + _pro_skill_notice(skill["name"])
            ),
        )]

    elif name == "activate_license":
        key = arguments.get("key", "").strip()
        email = arguments.get("email", "").strip() or None
        if not email:
            return [TextContent(
                type="text",
                text=(
                    "\u274c Email is required to activate MemStack\u2122.\n\n"
                    "Run: `activate_license(key=\"your-key\", email=\"you@example.com\")`\n\n"
                    "Don't have a key? Use `key=\"free\"` to get a free license."
                ),
            )]
        if not key or len(key) > MAX_KEY_LEN:
            return [TextContent(
                type="text",
                text="\u274c No valid license key provided. Get one at https://memstack.pro",
            )]

        # Clear any stale cache for this key so the fresh API call runs.
        clear_cache(key)

        status = await validate_license(license_key=key, email=email)
        if status.valid:
            save_license_key(key)
            if status.tier == "pro":
                try:
                    dl_msg = await _download_pro_skills(key)
                    print(f"[memstack] {dl_msg}", file=sys.stderr)
                except Exception as exc:
                    print(
                        f"[memstack] Pro skills download failed: {exc}. "
                        "Please try again or contact support@memstack.pro",
                        file=sys.stderr,
                    )
                from .indexer import build_index
                await asyncio.to_thread(build_index, config)
                reset_cache()
                clear_compression_cache()
                skills = await asyncio.to_thread(list_all_skills, config)
                total = len(skills) if skills else 0
                msg = (
                    f"\u2705 License activated! Tier: **Pro**. "
                    f"All {total} skills unlocked."
                )
            else:
                skills = await asyncio.to_thread(list_all_skills, config)
                total = len(skills) if skills else 0
                free_count = sum(
                    1 for s in (skills or []) if not is_pro_exclusive(s.get("slug", s["name"]))
                )
                msg = (
                    f"\u2705 License activated! Tier: **Free**. "
                    f"{free_count} skills unlocked. "
                    f"Upgrade to Pro at https://memstack.pro to unlock all {total}."
                )
            return [TextContent(type="text", text=msg)]
        return [TextContent(
            type="text",
            text="\u274c Invalid license key. Get one at https://memstack.pro",
        )]

    elif name == "skill_stats":
        try:
            if USAGE_FILE.exists():
                data: dict[str, int] = json.loads(
                    USAGE_FILE.read_text(encoding="utf-8")
                )
            else:
                data = {}
        except (OSError, json.JSONDecodeError):
            data = {}

        if not data:
            return [TextContent(
                type="text",
                text="No skill usage data yet. Use find_skill or get_skill to start tracking.",
            )]

        total = sum(data.values())
        sorted_skills = sorted(data.items(), key=lambda x: x[1], reverse=True)
        most_used = sorted_skills[:10]
        least_used = sorted_skills[-5:] if len(sorted_skills) > 5 else sorted_skills

        lines = [f"# MemStack\u2122 Skill Usage Stats\n"]
        lines.append(f"**Total activations:** {total}")
        lines.append(f"**Unique skills used:** {len(data)}\n")
        lines.append("## Most Used")
        for name_, count in most_used:
            lines.append(f"- **{name_}**: {count} activations")
        lines.append("\n## Least Used")
        for name_, count in reversed(least_used):
            lines.append(f"- **{name_}**: {count} activations")

        return [TextContent(type="text", text="\n".join(lines))]

    elif name == "dashboard_stats":
        data = get_dashboard_data()
        try:
            data["compression"] = get_compression_stats()
        except Exception:
            pass
        return [TextContent(type="text", text=json.dumps(data, indent=2))]

    elif name == "manage_skills":
        action = arguments.get("action", "")
        skill_name = arguments.get("skill", "").strip()
        sc = load_skill_config()

        if action == "list_disabled":
            if sc.mode == "all":
                return [TextContent(
                    type="text",
                    text="No skills are currently disabled for this project (mode: all).",
                )]
            disabled = sc.disabled if sc.mode == "blocklist" else []
            if sc.mode == "allowlist":
                lines_ = [f"# Skills Config (mode: allowlist)\n"]
                lines_.append(f"**{len(sc.enabled)}** skills enabled (all others blocked)")
                for s in sorted(sc.enabled):
                    lines_.append(f"- ✅ {s}")
            else:
                lines_ = [f"# Disabled Skills (mode: blocklist)\n"]
                for s in sorted(disabled):
                    lines_.append(f"- {s}")
                lines_.append(f"\n**{len(disabled)}** skills disabled")
            return [TextContent(type="text", text="\n".join(lines_))]

        if not skill_name:
            return [TextContent(
                type="text",
                text="Skill name is required for enable/disable actions.",
            )]

        if action == "disable":
            if not _skill_enabled(skill_name):
                return [TextContent(
                    type="text",
                    text=f"'{skill_name}' is already disabled.",
                )]
            _toggle_skill_config(None, skill_name, False)
            sc = load_skill_config()
            count = len(sc.disabled) if sc.mode == "blocklist" else 0
            return [TextContent(
                type="text",
                text=f"Disabled {skill_name}. {count} skills now filtered.",
            )]

        if action == "enable":
            if _skill_enabled(skill_name):
                return [TextContent(
                    type="text",
                    text=f"'{skill_name}' is not currently disabled.",
                )]
            _toggle_skill_config(None, skill_name, True)
            sc = load_skill_config()
            count = len(sc.disabled) if sc.mode == "blocklist" else 0
            return [TextContent(
                type="text",
                text=f"Enabled {skill_name}. {count} skills now filtered.",
            )]

        return [TextContent(
            type="text",
            text=f"Unknown action: {action}. Use disable, enable, or list_disabled.",
        )]

    elif name == "reindex_skills":
        from .indexer import build_index
        count = await asyncio.to_thread(build_index, config)
        reset_cache()
        clear_compression_cache()
        if count == 0:
            return [TextContent(
                type="text",
                text="Warning: No skills found to index. Check config.json skill_sources paths.",
            )]
        return [TextContent(
            type="text",
            text=f"Reindexed {count} skills successfully.",
        )]

    elif name == "memory_capture":
        project_dir = os.getcwd()
        session_id = _get_session_id()
        event_type = arguments.get("event_type", "")
        summary = arguments.get("summary", "")
        details = None
        if arguments.get("details"):
            try:
                details = json.loads(arguments["details"])
            except (json.JSONDecodeError, TypeError):
                details = {"raw": arguments["details"]}
        row_id = memory_db.insert_event(
            project_dir, session_id, event_type, summary, details
        )
        if row_id:
            return [TextContent(type="text", text=f"Memory event captured (id={row_id}, type={event_type}).")]
        return [TextContent(type="text", text="Failed to capture memory event.")]

    elif name == "memory_search":
        query = arguments.get("query", "")
        project_only = arguments.get("project_only", True)
        limit = arguments.get("limit", 10)
        project_dir = os.getcwd() if project_only else None
        results = memory_db.search_memory(query, project_dir=project_dir, limit=limit)
        if not results:
            return [TextContent(type="text", text="No memory results found.")]
        lines = [f"# Memory Search: {len(results)} results\n"]
        for r in results:
            lines.append(f"- **[{r['source_table']}#{r['source_id']}]** {r['content'][:200]}")
        return [TextContent(type="text", text="\n".join(lines))]

    elif name == "memory_recall":
        project_dir = os.getcwd()
        lines = ["# Memory Recall\n"]

        facts = memory_db.get_facts(project_dir)
        if facts:
            lines.append("## Key Facts")
            for f in facts:
                lines.append(f"- **{f['fact_type']}/{f['key']}**: {f['value']}")
            lines.append("")

        lessons = memory_db.get_lessons(project_dir)
        if lessons:
            lines.append("## Active Lessons")
            for l in lessons:
                lines.append(f"- **[{l['category']}]** {l['title']}: {l['content'][:200]}")
            lines.append("")

        events = memory_db.get_recent_events(project_dir, limit=10)
        if events:
            lines.append("## Recent Events (last 10)")
            for e in events:
                lines.append(f"- [{e['event_type']}] {e['summary']} ({e['timestamp']})")
            lines.append("")

        stats = memory_db.get_memory_stats(project_dir)
        lines.append("## Stats")
        lines.append(f"- Events: {stats['events']}, Sessions: {stats['sessions']}, "
                      f"Lessons: {stats['lessons']}, Facts: {stats['facts']}, "
                      f"DB size: {stats['db_size_human']}")

        return [TextContent(type="text", text="\n".join(lines))]

    elif name == "memory_lesson":
        title = arguments.get("title", "")
        content = arguments.get("content", "")
        category = arguments.get("category", "lesson")
        is_global = arguments.get("global", False)
        stack_tags = arguments.get("stack_tags")
        project_dir = os.getcwd()
        row_id = memory_db.insert_lesson(
            title, content, category,
            project_dir=project_dir,
            global_=is_global,
            stack_tags=stack_tags,
        )
        scope = "global" if is_global else "project"
        if row_id:
            return [TextContent(type="text", text=f"Lesson saved (id={row_id}, category={category}, scope={scope}).")]
        return [TextContent(type="text", text="Failed to save lesson.")]

    elif name == "memory_stats":
        project_dir = arguments.get("project_dir", os.getcwd())
        stats = memory_db.get_memory_stats(project_dir)
        lines = [
            "# Memory Stats\n",
            f"- **Events**: {stats['events']}",
            f"- **Sessions**: {stats['sessions']}",
            f"- **Lessons**: {stats['lessons']}",
            f"- **Facts**: {stats['facts']}",
            f"- **DB size**: {stats['db_size_human']}",
        ]
        return [TextContent(type="text", text="\n".join(lines))]

    elif name == "agent_run":
        task = arguments.get("task", "")
        if not task:
            return [TextContent(type="text", text="Error: 'task' parameter is required.")]
        working_dir = arguments.get("working_dir", os.getcwd())
        try:
            result = agent_runner.start_run(
                task=task,
                working_dir=working_dir,
            )
            return [TextContent(
                type="text",
                text=json.dumps(result, indent=2),
            )]
        except Exception as exc:
            return [TextContent(type="text", text=f"Error starting agents: {exc}")]

    elif name == "agent_status":
        try:
            status = agent_runner.get_status()
            if not status:
                return [TextContent(type="text", text="No agents running.")]
            return [TextContent(
                type="text",
                text=json.dumps(status, indent=2),
            )]
        except Exception as exc:
            return [TextContent(type="text", text=f"Error getting agent status: {exc}")]

    elif name == "agent_message":
        to_agent = arguments.get("to_agent", "")
        content = arguments.get("content", "")
        if not to_agent or not content:
            return [TextContent(
                type="text",
                text="Error: 'to_agent' and 'content' are required.",
            )]
        try:
            agent_runner.send_message(
                from_agent="user",
                to_agent=to_agent,
                content=content,
                message_type="task",
            )
            return [TextContent(type="text", text=f"Message sent to '{to_agent}'.")]
        except (ValueError, RuntimeError) as exc:
            return [TextContent(type="text", text=f"Error sending message: {exc}")]

    elif name == "agent_stop":
        try:
            agent_runner.stop_all()
            return [TextContent(type="text", text="All agents stopped.")]
        except Exception as exc:
            return [TextContent(type="text", text=f"Error stopping agents: {exc}")]

    return [TextContent(type="text", text=f"Unknown tool: {name}")]


async def run():
    config = _get_config()

    # Load skill config (triggers migration from .memstack-ignore if needed)
    sc = load_skill_config()
    if sc.mode != "all":
        print(f"MemStack™: skill config mode={sc.mode}", file=sys.stderr)

    # Print grace period status on startup if no license key is set
    if not get_license_key():
        from .license import _get_grace_period_status
        active, remaining, _tampered = _get_grace_period_status()
        if active:
            print(
                f"[memstack] No license key. Grace period: {remaining} days remaining. "
                f"Get your free key at memstack.pro",
                file=sys.stderr,
            )
        else:
            print(
                "[memstack] No license key. Grace period expired. "
                "Get your free key at memstack.pro",
                file=sys.stderr,
            )

    # Check for updates (cached, non-blocking)
    from .version_check import check_for_updates
    check_for_updates()

    # Backfill NULL categories in stats.db from category map
    from .stats import backfill_categories
    backfill_categories(_CATEGORY_MAP)

    # Auto-build index on first run (PyPI installs have no pre-built index).
    if config.auto_reindex_on_start:
        from .tfidf_search import _get_index as _peek_index
        if _peek_index(config) is None:
            from .indexer import build_index
            print("[memstack] Building skill index for first time...", file=sys.stderr)
            count = build_index(config)
            print(f"[memstack] Indexed {count} skills.", file=sys.stderr)

    # Pre-load TF-IDF index before stdio_server starts its stdin reader thread.
    # On Windows, a blocking readline() in the stdin thread causes GIL contention
    # that slows down CPU-intensive operations (like sklearn import) by ~20x.
    from .tfidf_search import _get_index
    _get_index(config)

    # Auto-start dashboard HTTP server in a daemon thread
    try:
        import socket
        import threading
        dashboard_port = 3333
        sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        port_free = sock.connect_ex(("127.0.0.1", dashboard_port)) != 0
        sock.close()
        if port_free:
            from .dashboard import start_dashboard
            t = threading.Thread(
                target=start_dashboard,
                kwargs={"port": dashboard_port, "open_browser": False},
                daemon=True,
            )
            t.start()
            pid_dir = Path.home() / ".memstack"
            pid_dir.mkdir(parents=True, exist_ok=True)
            (pid_dir / "dashboard.pid").write_text(str(os.getpid()))
            print(f"[memstack] Dashboard started at http://localhost:{dashboard_port}", file=sys.stderr)
        else:
            print(f"[memstack] Dashboard already running on port {dashboard_port}", file=sys.stderr)
    except Exception as exc:
        print(f"[memstack] Dashboard auto-start failed: {exc}", file=sys.stderr)

    async with stdio_server() as (read_stream, write_stream):
        await app.run(read_stream, write_stream, app.create_initialization_options())
