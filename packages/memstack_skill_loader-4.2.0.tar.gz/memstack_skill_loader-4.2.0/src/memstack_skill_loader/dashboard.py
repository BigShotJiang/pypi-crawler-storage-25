"""Local HTTP dashboard server for MemStack usage analytics."""

import json
import os
import pickle
import re
import secrets
import shutil
import sys
import threading
import time
import urllib.request
import webbrowser
from datetime import datetime, timezone
try:
    from importlib.metadata import version as _pkg_version, PackageNotFoundError
    _VERSION = _pkg_version("memstack-skill-loader")
except PackageNotFoundError:
    _VERSION = "dev"
from http.server import BaseHTTPRequestHandler, HTTPServer
from pathlib import Path

from .config import load_config
from .license import is_pro_exclusive
import sqlite3
from urllib.parse import urlparse, parse_qs
from .categories import derive_category as _derive_category
from . import memory_db
from . import agent_runner
import subprocess
from .skill_config import load_skill_config, save_skill_config, toggle_skill, set_mode, SkillConfig
from .stats import DB_PATH, get_dashboard_data, get_project_details, get_skill_fire_counts, get_burn_report_data, get_api_costs

_HTML_PATH = Path(__file__).parent / "dashboard.html"
_LAST_WORKDIR_FILE = Path.home() / ".memstack" / "agent-runner" / "last-workdir.txt"

_BLOCKED_WIN = {"windows", "system32", "syswow64", "program files", "program files (x86)", "programdata", "$recycle.bin", "recovery"}
_BLOCKED_NIX = {"/etc", "/var", "/proc", "/sys", "/boot"}

_diary_process = None
_diary_md_snapshot: set[str] = set()
_diary_md_file: str | None = None


def _validate_working_dir(path_str: str) -> str | None:
    """Return an error message if *path_str* is not a safe working directory, else None."""
    p = Path(path_str).resolve()
    if not p.exists() or not p.is_dir():
        return f"Working directory does not exist or is not a directory: {p}"
    parts_lower = [part.lower() for part in p.parts]
    if sys.platform == "win32":
        if any(part in _BLOCKED_WIN for part in parts_lower):
            return f"Working directory not allowed: {p}"
    else:
        str_p = str(p)
        if any(str_p == bp or str_p.startswith(bp + "/") for bp in _BLOCKED_NIX):
            return f"Working directory not allowed: {p}"
    return None


def _load_ignore_set() -> frozenset[str]:
    """Load disabled skill names from .memstack-ignore in CWD."""
    ignore_path = Path.cwd() / ".memstack-ignore"
    if not ignore_path.exists():
        return frozenset()
    try:
        lines = ignore_path.read_text(encoding="utf-8").splitlines()
        return frozenset(
            line.strip().lower()
            for line in lines
            if line.strip() and not line.strip().startswith("#")
        )
    except Exception:
        return frozenset()



def _strip_non_ascii(text: str) -> str:
    """Strip non-ASCII characters (emoji, unicode) from text."""
    return re.sub(r'[^\x00-\x7F]+', '', text).strip()


def _get_skills_data() -> dict:
    """Build the full skill catalog with fire counts and status."""
    config = load_config()
    pkl_path = config.resolved_vector_db_path / "tfidf_index.pkl"

    if not pkl_path.exists():
        return {
            "project": os.path.basename(os.getcwd()),
            "skills": [],
            "total": 0,
            "free_count": 0,
            "pro_count": 0,
            "disabled_count": 0,
            "error": "No skill index found. Run reindex_skills first.",
        }

    try:
        with open(pkl_path, "rb") as f:
            # SECURITY: pickle.load can execute arbitrary code. This file is local-only and built by our own indexer. Do not load pickles from untrusted sources.
            index = pickle.load(f)
    except Exception:
        return {
            "project": os.path.basename(os.getcwd()),
            "skills": [],
            "total": 0,
            "free_count": 0,
            "pro_count": 0,
            "disabled_count": 0,
            "error": "Failed to load skill index.",
        }

    skills_raw = index.get("skills", [])
    fire_counts = get_skill_fire_counts()
    ignored = _load_ignore_set()

    skills = []
    free_count = 0
    pro_count = 0
    disabled_count = 0

    for s in skills_raw:
        slug = s.get("slug", s.get("name", ""))
        is_pro = is_pro_exclusive(slug)
        name_raw = s.get("name", "")
        name_ascii = _strip_non_ascii(name_raw).lower()
        enabled = (slug.lower() not in ignored
                   and name_raw.lower() not in ignored
                   and name_ascii not in ignored)
        fires = fire_counts.get(s.get("name", ""), 0)

        if is_pro:
            pro_count += 1
        else:
            free_count += 1
        if not enabled:
            disabled_count += 1

        skills.append({
            "name": s.get("name", ""),
            "slug": slug,
            "description": s.get("description", ""),
            "source_label": s.get("source_label", ""),
            "category": _derive_category(slug),
            "is_pro": is_pro,
            "enabled": enabled,
            "fire_count": fires,
        })

    return {
        "project": os.path.basename(os.getcwd()),
        "skills": skills,
        "total": len(skills),
        "free_count": free_count,
        "pro_count": pro_count,
        "disabled_count": disabled_count,
        "display_free_count": free_count,
        "display_pro_count": pro_count,
        "display_total": free_count + pro_count,
    }


def _toggle_skill(skill_name: str, action: str) -> dict:
    """Enable or disable a skill by updating .memstack-ignore."""
    ignore_path = Path.cwd() / ".memstack-ignore"

    # Validate action
    if action not in ("enable", "disable"):
        return {"success": False, "error": "Invalid action. Use 'enable' or 'disable'."}

    # Validate skill exists in index
    config = load_config()
    pkl_path = config.resolved_vector_db_path / "tfidf_index.pkl"
    if pkl_path.exists():
        try:
            with open(pkl_path, "rb") as f:
                # SECURITY: pickle.load can execute arbitrary code. This file is local-only and built by our own indexer. Do not load pickles from untrusted sources.
                index = pickle.load(f)
            known = {s.get("name", "").lower() for s in index.get("skills", [])}
            known |= {s.get("slug", "").lower() for s in index.get("skills", [])}
            if skill_name.lower() not in known:
                return {"success": False, "error": f"Skill '{skill_name}' not found in index."}
        except Exception:
            pass

    # Read existing ignore file
    existing_lines: list[str] = []
    if ignore_path.exists():
        try:
            existing_lines = ignore_path.read_text(encoding="utf-8").splitlines()
        except Exception:
            pass

    name_lower = skill_name.lower()
    name_lower_ascii = _strip_non_ascii(skill_name).lower()

    if action == "disable":
        # Check if already disabled
        active = [
            line.strip().lower()
            for line in existing_lines
            if line.strip() and not line.strip().startswith("#")
        ]
        if name_lower in active or name_lower_ascii in active:
            return {"success": True, "skill": skill_name, "enabled": False,
                    "disabled_count": len(active)}
        # Strip emoji/unicode — write only ASCII to .memstack-ignore
        existing_lines.append(_strip_non_ascii(skill_name))
        ignore_path.parent.mkdir(parents=True, exist_ok=True)
        tmp = ignore_path.with_suffix(".tmp")
        tmp.write_text("\n".join(existing_lines) + "\n", encoding="utf-8")
        tmp.replace(ignore_path)
        ignored = _load_ignore_set()
        return {"success": True, "skill": skill_name, "enabled": False,
                "disabled_count": len(ignored)}

    else:  # enable
        if not ignore_path.exists():
            return {"success": True, "skill": skill_name, "enabled": True,
                    "disabled_count": 0}
        new_lines = [
            line for line in existing_lines
            if line.strip().lower() != name_lower and line.strip().lower() != name_lower_ascii
        ]
        if len(new_lines) == len(existing_lines):
            return {"success": True, "skill": skill_name, "enabled": True,
                    "disabled_count": len(_load_ignore_set())}
        if not any(l.strip() and not l.strip().startswith("#") for l in new_lines):
            try:
                ignore_path.unlink()
            except Exception:
                pass
            return {"success": True, "skill": skill_name, "enabled": True,
                    "disabled_count": 0}
        tmp = ignore_path.with_suffix(".tmp")
        tmp.write_text("\n".join(new_lines) + "\n", encoding="utf-8")
        tmp.replace(ignore_path)
        ignored = _load_ignore_set()
        return {"success": True, "skill": skill_name, "enabled": True,
                "disabled_count": len(ignored)}


def _get_category_skills() -> dict:
    """Return skill fire counts grouped by category."""
    if not DB_PATH.exists():
        return {}
    try:
        conn = sqlite3.connect(str(DB_PATH), timeout=5)
        rows = conn.execute(
            """
            SELECT COALESCE(category, 'uncategorized') as cat, skill_name, COUNT(*) as fires
            FROM skill_fires
            GROUP BY cat, skill_name
            ORDER BY cat, fires DESC
            """,
        ).fetchall()
        conn.close()
    except Exception:
        return {}

    result: dict[str, list[dict]] = {}
    for cat, name, fires in rows:
        result.setdefault(cat, []).append({"name": name, "fires": fires})
    return result


def _parse_plugin_list() -> list[dict]:
    """Run `claude plugin list` and parse the output into structured plugin data."""
    try:
        r = subprocess.run(
            ["claude", "plugin", "list"],
            capture_output=True, text=True, timeout=30, encoding="utf-8", errors="replace",
        )
        text = (r.stdout or "") + (r.stderr or "")
    except FileNotFoundError:
        return []
    except subprocess.TimeoutExpired:
        return []
    except Exception:
        return []

    plugins: list[dict] = []
    current: dict | None = None
    for line in text.splitlines():
        stripped = line.strip()
        header = re.match(r'^[❯>]\s+(.+?)@(.+)$', stripped)
        if header:
            if current:
                plugins.append(current)
            current = {
                "name": header.group(1).strip(),
                "marketplace": header.group(2).strip(),
                "version": "",
                "scope": "",
                "status": "unknown",
                "error": None,
            }
            continue
        if current is None:
            continue
        if stripped.lower().startswith("version:"):
            current["version"] = stripped.split(":", 1)[1].strip()
        elif stripped.lower().startswith("scope:"):
            current["scope"] = stripped.split(":", 1)[1].strip()
        elif stripped.lower().startswith("status:"):
            status_val = stripped.split(":", 1)[1].strip().lower()
            if "enabled" in status_val:
                current["status"] = "enabled"
            elif "disabled" in status_val:
                current["status"] = "disabled"
            elif "failed" in status_val:
                current["status"] = "failed"
            else:
                current["status"] = status_val
        elif stripped.lower().startswith("error:"):
            current["error"] = stripped.split(":", 1)[1].strip() or None
    if current:
        plugins.append(current)
    return plugins


def _git_push_with_workflow(run_git, work_dir: str, current_branch: str,
                            output_parts: list, workflow: str) -> tuple:
    """Push using the specified workflow strategy.

    Returns (success: bool, error: str | None).
    run_git must have signature (args, cwd, timeout=30) -> (ok, out).
    """
    if workflow in ("single_branch", "feature_branch"):
        ok, out = run_git(["push", "origin", current_branch], work_dir, timeout=60)
        output_parts.append(out)
        if not ok:
            return False, "git push failed"
        return True, None

    if workflow == "dev_to_default":
        default_branch = None
        for candidate in ("main", "master"):
            chk, _ = run_git(["rev-parse", "--verify", candidate], work_dir)
            if chk:
                default_branch = candidate
                break
        if not default_branch:
            ok, out = run_git(["push", "origin", current_branch], work_dir, timeout=60)
            output_parts.append(out)
            if not ok:
                return False, "git push failed"
            return True, None
        if current_branch == default_branch:
            ok, out = run_git(["push", "origin", current_branch], work_dir, timeout=60)
            output_parts.append(out)
            if not ok:
                return False, "git push failed"
            return True, None
        steps = [
            (["checkout", default_branch], 30),
            (["merge", current_branch, "--ff-only"], 30),
            (["push", "origin", default_branch], 60),
            (["checkout", current_branch], 30),
            (["reset", "--hard", default_branch], 30),
        ]
        for args, t in steps:
            ok, out = run_git(args, work_dir, timeout=t)
            output_parts.append(out)
            if not ok:
                return False, f"git {args[0]} failed"
        return True, None

    # "auto" (default): detect and merge to default if on non-default branch
    default_branch = None
    for candidate in ("main", "master"):
        chk, _ = run_git(["rev-parse", "--verify", candidate], work_dir)
        if chk:
            default_branch = candidate
            break

    if default_branch and current_branch != default_branch:
        steps = [
            (["checkout", default_branch], 30),
            (["merge", current_branch, "--ff-only"], 30),
            (["push", "origin", default_branch], 60),
            (["checkout", current_branch], 30),
            (["reset", "--hard", default_branch], 30),
        ]
        for args, t in steps:
            ok, out = run_git(args, work_dir, timeout=t)
            output_parts.append(out)
            if not ok:
                return False, f"git {args[0]} failed"
    else:
        ok, out = run_git(["push", "origin", current_branch], work_dir, timeout=60)
        output_parts.append(out)
        if not ok:
            return False, "git push failed"
    return True, None


def _get_diary_entries() -> list[dict]:
    """Read diary entries from known locations."""
    entries = []
    diary_dirs = [
        Path.home() / ".memstack" / "diary",
        Path.cwd() / "memory" / "sessions",
    ]
    for diary_dir in diary_dirs:
        if not diary_dir.exists():
            continue
        for f in diary_dir.glob("*.md"):
            try:
                content = f.read_text(encoding="utf-8", errors="replace")
                name = f.stem
                date_part = name[:10] if len(name) >= 10 else name
                first_line = content.split("\n", 1)[0].strip("#").strip()
                entries.append({
                    "date": date_part,
                    "filename": f.name,
                    "title": first_line or name,
                    "content": content,
                    "source": str(diary_dir),
                    "mtime": f.stat().st_mtime,
                })
            except Exception:
                continue
    entries.sort(key=lambda e: e["mtime"], reverse=True)
    return entries


class _DashboardServer(HTTPServer):
    allow_reuse_address = False

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.start_time = time.time()
        self.auth_token = secrets.token_hex(16)
        port = self.server_address[1]
        self.allowed_origins = {
            f"http://localhost:{port}",
            f"http://127.0.0.1:{port}",
        }

    def server_bind(self):
        import socket as _socket
        if hasattr(_socket, "SO_EXCLUSIVEADDRUSE"):
            self.socket.setsockopt(_socket.SOL_SOCKET, _socket.SO_EXCLUSIVEADDRUSE, 1)
        super().server_bind()


class _Handler(BaseHTTPRequestHandler):
    def log_message(self, format, *args):
        pass  # suppress default logging

    def _check_auth(self) -> bool:
        token = self.headers.get("X-Auth-Token", "")
        if token != self.server.auth_token:
            body = json.dumps({"success": False, "error": "Forbidden"}).encode()
            self._respond(403, "application/json", body)
            return False
        return True

    def do_GET(self):
        if self.path == "/":
            html = _HTML_PATH.read_text(encoding="utf-8")
            html = html.replace("__AUTH_TOKEN__", self.server.auth_token)
            body = html.encode("utf-8")
            self._respond(200, "text/html", body)
        elif self.path.startswith("/api/"):
            if not self._check_auth():
                return
            self._handle_api_get()
        else:
            body = json.dumps({"success": False, "error": "Not found"}).encode()
            self._respond(404, "application/json", body)

    def _handle_api_get(self):
        if self.path == "/api/stats":
            data = get_dashboard_data()
            data["project_path"] = os.getcwd()
            data["agent_display_names"] = agent_runner._load_agent_display_names()
            body = json.dumps(data).encode()
            self._respond(200, "application/json", body)
        elif self.path == "/api/skills":
            body = json.dumps(_get_skills_data()).encode()
            self._respond(200, "application/json", body)
        elif self.path == "/api/diary":
            body = json.dumps(_get_diary_entries()).encode()
            self._respond(200, "application/json", body)
        elif self.path == "/api/projects":
            body = json.dumps(get_project_details()).encode()
            self._respond(200, "application/json", body)
        elif self.path == "/api/category-skills":
            body = json.dumps(_get_category_skills()).encode()
            self._respond(200, "application/json", body)
        elif self.path == "/api/skill-config":
            config = load_skill_config()
            body = json.dumps(config.to_dict()).encode()
            self._respond(200, "application/json", body)
        elif self.path.startswith("/api/memory/"):
            self._handle_memory_get()
        elif self.path == "/api/agent-status":
            data = agent_runner.get_status()
            body = json.dumps(data).encode()
            self._respond(200, "application/json", body)
        elif self.path == "/api/diary-status":
            global _diary_md_file
            dp = _diary_process
            if dp is None:
                status_str = "completed"
            else:
                rc = dp.poll()
                if rc is None:
                    status_str = "running"
                elif rc == 0:
                    status_str = "completed"
                    if not _diary_md_file:
                        diary_dir = Path.home() / ".memstack" / "diary"
                        if diary_dir.exists():
                            current = {f.name for f in diary_dir.glob("*.md")}
                            new_files = current - _diary_md_snapshot
                            if new_files:
                                _diary_md_file = str(diary_dir / sorted(new_files)[-1])
                else:
                    status_str = "failed"
            resp: dict = {"status": status_str}
            if _diary_md_file:
                resp["md_file"] = _diary_md_file
            body = json.dumps(resp).encode()
            self._respond(200, "application/json", body)
        elif self.path.startswith("/api/burn-report"):
            parsed = urlparse(self.path)
            params = parse_qs(parsed.query)
            period = params.get("period", ["daily"])[0]
            if period not in ("daily", "weekly", "monthly"):
                period = "daily"
            range_filter = params.get("range", ["all"])[0]
            if range_filter not in ("daily", "weekly", "monthly", "all"):
                range_filter = "all"
            data = get_burn_report_data(period, range_filter=range_filter)
            data["api_costs"] = get_api_costs(time_range=range_filter)
            data["agent_display_names"] = agent_runner._load_agent_display_names()
            body = json.dumps(data).encode()
            self._respond(200, "application/json", body)
        elif self.path == "/api/recent-projects":
            dirs = memory_db.get_recent_project_dirs(limit=10)
            body = json.dumps(dirs).encode()
            self._respond(200, "application/json", body)
        elif self.path.startswith("/api/browse-dirs"):
            parsed = urlparse(self.path)
            params = parse_qs(parsed.query)
            req_path = params.get("path", [os.path.expanduser("~")])[0]
            try:
                p = Path(req_path).resolve()
                if ".." in p.parts:
                    body = json.dumps({"error": "Path not allowed", "path": str(p), "dirs": []}).encode()
                    self._respond(403, "application/json", body)
                    return
                blocked_win = {"windows", "system32", "syswow64", "program files", "program files (x86)", "programdata", "$recycle.bin", "recovery"}
                blocked_nix = {"/etc", "/var", "/proc", "/sys", "/boot"}
                parts_lower = [part.lower() for part in p.parts]
                if sys.platform == "win32":
                    if any(part in blocked_win for part in parts_lower):
                        body = json.dumps({"error": "Path not allowed", "path": str(p), "dirs": []}).encode()
                        self._respond(403, "application/json", body)
                        return
                else:
                    str_p = str(p)
                    if any(str_p == bp or str_p.startswith(bp + "/") for bp in blocked_nix):
                        body = json.dumps({"error": "Path not allowed", "path": str(p), "dirs": []}).encode()
                        self._respond(403, "application/json", body)
                        return
                if not p.is_dir():
                    body = json.dumps({"error": "Not a directory", "path": str(p), "dirs": []}).encode()
                    self._respond(400, "application/json", body)
                    return
                dirs = sorted(
                    [d.name for d in p.iterdir() if d.is_dir() and not d.name.startswith(".")],
                    key=str.lower,
                )
                body = json.dumps({"path": str(p), "dirs": dirs}).encode()
                self._respond(200, "application/json", body)
            except PermissionError:
                body = json.dumps({"error": "Permission denied", "path": req_path, "dirs": []}).encode()
                self._respond(403, "application/json", body)
            except Exception as e:
                body = json.dumps({"error": str(e), "path": req_path, "dirs": []}).encode()
                self._respond(500, "application/json", body)
        elif self.path == "/api/last-workdir":
            path = ""
            try:
                if _LAST_WORKDIR_FILE.exists():
                    path = _LAST_WORKDIR_FILE.read_text(encoding="utf-8").strip()
            except OSError:
                pass
            body = json.dumps({"path": path}).encode()
            self._respond(200, "application/json", body)
        elif self.path.startswith("/api/mcp-servers"):
            parsed = urlparse(self.path)
            qs = parse_qs(parsed.query)
            workdir = qs.get("workdir", [""])[0]
            servers = agent_runner.discover_mcp_servers(workdir) if workdir else []
            cfg = agent_runner.load_builder_tools_config()
            blocked: list[str] = []
            has_project_config = False
            git_workflow = None
            if workdir:
                proj = agent_runner._get_project_config(cfg, workdir)
                if proj:
                    blocked = proj.get("blocked_mcp", [])
                    has_project_config = True
                    git_workflow = proj.get("git_workflow")
                else:
                    blocked = cfg.get("_global_defaults", [])
            global_blocked = cfg.get("_global_defaults", [])
            resp_data: dict = {"servers": servers, "blocked": blocked, "global_blocked": global_blocked, "has_project_config": has_project_config}
            if git_workflow:
                resp_data["git_workflow"] = git_workflow
            body = json.dumps(resp_data).encode()
            self._respond(200, "application/json", body)
        elif self.path == "/api/global-mcp-defaults":
            cfg = agent_runner.load_builder_tools_config()
            body = json.dumps({"blocked": cfg.get("_global_defaults", [])}).encode()
            self._respond(200, "application/json", body)
        elif self.path == "/api/headroom-stats":
            try:
                req = urllib.request.Request("http://127.0.0.1:8787/stats")
                with urllib.request.urlopen(req, timeout=2) as resp:
                    data = json.loads(resp.read().decode())
                body = json.dumps(data).encode()
            except Exception:
                body = json.dumps({"error": "Headroom not running"}).encode()
            self._respond(200, "application/json", body)
        elif self.path.startswith("/api/agent-session-log"):
            parsed = urlparse(self.path)
            qs = parse_qs(parsed.query)
            session_id = qs.get("session_id", [""])[0]
            agent_name = qs.get("agent", ["builder"])[0]
            if not session_id or not re.fullmatch(r"[a-f0-9]+", session_id):
                body = json.dumps({"error": "Invalid session_id"}).encode()
                self._respond(400, "application/json", body)
                return
            if agent_name not in ("manager", "builder", "reviewer"):
                body = json.dumps({"error": "Invalid agent name"}).encode()
                self._respond(400, "application/json", body)
                return
            log_path = Path.home() / ".memstack" / "agent-runner" / "sessions" / session_id / f"{agent_name}.log"
            if not log_path.exists():
                body = json.dumps({"error": "Log file not found"}).encode()
                self._respond(404, "application/json", body)
                return
            try:
                log_text = log_path.read_text(encoding="utf-8", errors="replace")
                body = json.dumps({"session_id": session_id, "agent": agent_name, "log": log_text}).encode()
                self._respond(200, "application/json", body)
            except OSError as e:
                body = json.dumps({"error": str(e)}).encode()
                self._respond(500, "application/json", body)
        elif self.path == "/api/health":
            data = {
                "status": "ok",
                "version": _VERSION,
                "uptime": round(time.time() - self.server.start_time, 2),
                "timestamp": datetime.now(timezone.utc).isoformat().replace("+00:00", "Z"),
            }
            body = json.dumps(data).encode()
            self._respond(200, "application/json", body)
        elif self.path == "/api/settings-info":
            home = Path.home()
            data = {
                "version": _VERSION,
                "python_version": f"{sys.version_info.major}.{sys.version_info.minor}.{sys.version_info.micro}",
                "platform": f"{sys.platform} ({os.name})",
                "skills_dir": str(home / ".memstack" / "skills"),
                "pro_skills_dir": str(home / ".memstack" / "pro-skills"),
                "stats_db": str(DB_PATH),
                "sessions_dir": str(home / ".memstack" / "agent-runner" / "sessions"),
                "api_key_set": bool(os.environ.get("ANTHROPIC_API_KEY")),
                "api_key_hint": ("sk-ant-..."+os.environ["ANTHROPIC_API_KEY"][-4:]) if os.environ.get("ANTHROPIC_API_KEY") and len(os.environ.get("ANTHROPIC_API_KEY","")) >= 8 else "",
                "oauth_token_set": bool(agent_runner._load_oauth_token()),
                "oauth_token_hint": ("..."+agent_runner._load_oauth_token()[-4:]) if agent_runner._load_oauth_token() and len(agent_runner._load_oauth_token() or "") >= 8 else "",
                "base_url": os.environ.get("ANTHROPIC_BASE_URL", ""),
            }
            body = json.dumps(data).encode()
            self._respond(200, "application/json", body)
        elif self.path == "/api/skill-descriptions":
            desc_file = Path(__file__).parent / "skill_descriptions.json"
            if desc_file.exists():
                try:
                    body = desc_file.read_bytes()
                except OSError:
                    body = b"{}"
            else:
                body = b"{}"
            self._respond(200, "application/json", body)
        elif self.path == "/api/cc-usage":
            result = {"available": False}
            for fname in ("statsig_cache.json", "stats-cache.json"):
                stats_file = Path.home() / ".claude" / fname
                if stats_file.exists():
                    try:
                        raw = json.loads(stats_file.read_text(encoding="utf-8"))
                        result = {"available": True, "source": fname, "data": raw}
                        break
                    except Exception:
                        continue
            body = json.dumps(result).encode()
            self._respond(200, "application/json", body)
        elif self.path == "/api/user-profile":
            profile_path = Path.home() / ".memstack" / "user_profile.json"
            default_profile = {
                "user_name": "",
                "agent_names": {"manager": "Manager", "builder": "Builder", "reviewer": "Reviewer"},
                "sound_notifications": True,
            }
            if not profile_path.exists():
                try:
                    profile_path.parent.mkdir(parents=True, exist_ok=True)
                    profile_path.write_text(json.dumps(default_profile, indent=2), encoding="utf-8")
                except OSError:
                    pass
                body = json.dumps(default_profile).encode()
            else:
                try:
                    profile = json.loads(profile_path.read_text(encoding="utf-8"))
                    body = json.dumps(profile).encode()
                except Exception:
                    body = json.dumps(default_profile).encode()
            self._respond(200, "application/json", body)
        elif self.path == "/api/version":
            body = json.dumps({"version": _VERSION}).encode()
            self._respond(200, "application/json", body)
        elif self.path.startswith("/api/git-workflow"):
            parsed = urlparse(self.path)
            qs = parse_qs(parsed.query)
            workdir = qs.get("workdir", [""])[0]
            if workdir:
                wf, is_proj = agent_runner.get_git_workflow_for_project(workdir)
            else:
                cfg = agent_runner.load_builder_tools_config()
                wf = cfg.get("_git_workflow", "auto")
                if wf not in agent_runner._VALID_GIT_WORKFLOWS:
                    wf = "auto"
                is_proj = False
            body = json.dumps({"workflow": wf, "is_project_config": is_proj}).encode()
            self._respond(200, "application/json", body)
        elif self.path == "/api/agent-modes":
            modes = agent_runner.load_agent_modes()
            body = json.dumps({
                "modes": modes,
                "api_key_set": bool(os.environ.get("ANTHROPIC_API_KEY")),
            }).encode()
            self._respond(200, "application/json", body)
        elif self.path.startswith("/api/git-branches"):
            parsed = urlparse(self.path)
            qs = parse_qs(parsed.query)
            workdir = qs.get("workdir", [""])[0]
            if not workdir or not Path(workdir).is_dir():
                body = json.dumps({"branches": [], "current": ""}).encode()
                self._respond(400, "application/json", body)
                return
            wd_err = _validate_working_dir(workdir)
            if wd_err:
                body = json.dumps({"branches": [], "current": "", "error": wd_err}).encode()
                self._respond(400, "application/json", body)
                return
            try:
                br_r = subprocess.run(["git", "branch", "--list"], capture_output=True, text=True, cwd=workdir, timeout=10)
                branches = []
                for line in br_r.stdout.splitlines():
                    name = line.lstrip("* ").strip()
                    if name:
                        branches.append(name)
                cur_r = subprocess.run(["git", "branch", "--show-current"], capture_output=True, text=True, cwd=workdir, timeout=10)
                current = cur_r.stdout.strip()
                body = json.dumps({"branches": sorted(branches), "current": current}).encode()
                self._respond(200, "application/json", body)
            except subprocess.TimeoutExpired:
                body = json.dumps({"branches": [], "current": "", "error": "Git command timed out."}).encode()
                self._respond(500, "application/json", body)
            except Exception as e:
                body = json.dumps({"branches": [], "current": "", "error": str(e)}).encode()
                self._respond(500, "application/json", body)
        elif self.path == "/api/plugins":
            plugins = _parse_plugin_list()
            body = json.dumps({"plugins": plugins}).encode()
            self._respond(200, "application/json", body)
        else:
            body = json.dumps({"success": False, "error": "Not found"}).encode()
            self._respond(404, "application/json", body)

    def do_POST(self):
        if not self._check_auth():
            return
        content_length = int(self.headers.get("Content-Length", 0))
        if content_length > 1_048_576:
            body = json.dumps({"success": False, "error": "Request body too large (max 1 MB)."}).encode()
            self._respond(413, "application/json", body)
            return
        if self.path == "/api/user-profile":
            content_len = int(self.headers.get("Content-Length", 0))
            raw = self.rfile.read(content_len).decode("utf-8") if content_len else ""
            try:
                incoming = json.loads(raw) if raw else {}
            except (json.JSONDecodeError, ValueError):
                body = json.dumps({"success": False, "error": "Invalid JSON body."}).encode()
                self._respond(400, "application/json", body)
                return
            profile_path = Path.home() / ".memstack" / "user_profile.json"
            default_profile = {
                "user_name": "",
                "agent_names": {"manager": "Manager", "builder": "Builder", "reviewer": "Reviewer"},
                "sound_notifications": True,
            }
            try:
                if profile_path.exists():
                    existing = json.loads(profile_path.read_text(encoding="utf-8"))
                else:
                    existing = dict(default_profile)
                if "user_name" in incoming:
                    existing["user_name"] = str(incoming["user_name"])
                if "agent_names" in incoming and isinstance(incoming["agent_names"], dict):
                    if "agent_names" not in existing or not isinstance(existing["agent_names"], dict):
                        existing["agent_names"] = {}
                    for k in ("manager", "builder", "reviewer"):
                        if k in incoming["agent_names"]:
                            existing["agent_names"][k] = str(incoming["agent_names"][k])
                if "sound_notifications" in incoming:
                    existing["sound_notifications"] = bool(incoming["sound_notifications"])
                profile_path.parent.mkdir(parents=True, exist_ok=True)
                profile_path.write_text(json.dumps(existing, indent=2), encoding="utf-8")
                body = json.dumps({"success": True}).encode()
                self._respond(200, "application/json", body)
            except Exception as exc:
                body = json.dumps({"success": False, "error": str(exc)}).encode()
                self._respond(500, "application/json", body)
            return
        elif self.path == "/api/skills/toggle":
            content_length = int(self.headers.get("Content-Length", 0))
            if content_length == 0:
                body = json.dumps({"success": False, "error": "Request body required."}).encode()
                self._respond(400, "application/json", body)
                return
            raw = self.rfile.read(content_length)
            try:
                data = json.loads(raw)
            except (json.JSONDecodeError, ValueError):
                body = json.dumps({"success": False, "error": "Invalid JSON body."}).encode()
                self._respond(400, "application/json", body)
                return

            skill = data.get("skill", "").strip()
            action = data.get("action", "").strip()

            if not skill:
                body = json.dumps({"success": False, "error": "Missing 'skill' field."}).encode()
                self._respond(400, "application/json", body)
                return

            if action not in ("enable", "disable"):
                body = json.dumps({"success": False, "error": "Invalid action. Use 'enable' or 'disable'."}).encode()
                self._respond(400, "application/json", body)
                return

            result = _toggle_skill(skill, action)
            status = 200 if result.get("success") else 400
            body = json.dumps(result).encode()
            self._respond(status, "application/json", body)
        elif self.path == "/api/skill-config":
            content_length = int(self.headers.get("Content-Length", 0))
            if content_length == 0:
                body = json.dumps({"success": False, "error": "Request body required."}).encode()
                self._respond(400, "application/json", body)
                return
            raw = self.rfile.read(content_length)
            try:
                data = json.loads(raw)
            except (json.JSONDecodeError, ValueError):
                body = json.dumps({"success": False, "error": "Invalid JSON body."}).encode()
                self._respond(400, "application/json", body)
                return

            action = data.get("action", "").strip()

            if action == "set_mode":
                mode = data.get("mode", "").strip()
                if mode not in ("all", "allowlist", "blocklist"):
                    body = json.dumps({"success": False, "error": "Invalid mode. Use 'all', 'allowlist', or 'blocklist'."}).encode()
                    self._respond(400, "application/json", body)
                    return
                config = set_mode(None, mode)
                body = json.dumps({"success": True, "config": config.to_dict()}).encode()
                self._respond(200, "application/json", body)

            elif action == "toggle":
                skill = data.get("skill", "").strip()
                enabled = data.get("enabled", True)
                if not skill:
                    body = json.dumps({"success": False, "error": "Missing 'skill' field."}).encode()
                    self._respond(400, "application/json", body)
                    return
                config = toggle_skill(None, skill, enabled)
                body = json.dumps({"success": True, "config": config.to_dict()}).encode()
                self._respond(200, "application/json", body)

            elif action == "save":
                mode = data.get("mode", "all")
                enabled_list = data.get("enabled", [])
                disabled_list = data.get("disabled", [])
                config = SkillConfig(mode=mode, enabled=enabled_list, disabled=disabled_list)
                save_skill_config(None, config)
                body = json.dumps({"success": True, "config": config.to_dict()}).encode()
                self._respond(200, "application/json", body)

            else:
                body = json.dumps({"success": False, "error": "Invalid action. Use 'set_mode', 'toggle', or 'save'."}).encode()
                self._respond(400, "application/json", body)
        elif self.path == "/api/agent-run":
            try:
                content_len = int(self.headers.get("Content-Length", 0))
                raw = self.rfile.read(content_len).decode("utf-8") if content_len else ""
                if not raw:
                    body = json.dumps({"success": False, "error": "Request body required."}).encode()
                    self._respond(400, "application/json", body)
                    return
                data = json.loads(raw)
                task = data.get("task", "").strip()
                if not task:
                    body = json.dumps({"success": False, "error": "Missing 'task' field."}).encode()
                    self._respond(400, "application/json", body)
                    return
                working_dir = data.get("working_dir", os.getcwd())
                wd_err = _validate_working_dir(working_dir)
                if wd_err:
                    body = json.dumps({"success": False, "error": wd_err}).encode()
                    self._respond(400, "application/json", body)
                    return
                context = data.get("context", "").strip() or None
                try:
                    _LAST_WORKDIR_FILE.parent.mkdir(parents=True, exist_ok=True)
                    _LAST_WORKDIR_FILE.write_text(working_dir, encoding="utf-8")
                except OSError:
                    pass
                auto_commit = data.get("auto_commit", False)
                timeout_minutes = int(data.get("timeout_minutes", 60))
                manager_model = data.get("manager_model", "")
                builder_model = data.get("builder_model", "")
                reviewer_model = data.get("reviewer_model", "")
                user_name = str(data.get("user_name", "")).strip()
                blocked_mcp = data.get("blocked_mcp_servers", [])
                result = agent_runner.start_run(task=task, working_dir=working_dir, context=context, auto_commit=auto_commit, timeout_minutes=timeout_minutes,
                                                manager_model=manager_model, builder_model=builder_model, reviewer_model=reviewer_model, user_name=user_name,
                                                blocked_mcp_servers=blocked_mcp)
                body = json.dumps(result).encode()
                status_code = 200 if "session_id" in result else 400
                self._respond(status_code, "application/json", body)
            except (json.JSONDecodeError, ValueError):
                body = json.dumps({"success": False, "error": "Invalid JSON body."}).encode()
                self._respond(400, "application/json", body)
            except Exception as exc:
                body = json.dumps({"success": False, "error": str(exc)}).encode()
                self._respond(500, "application/json", body)
        elif self.path == "/api/agent-message":
            try:
                content_len = int(self.headers.get("Content-Length", 0))
                raw = self.rfile.read(content_len).decode("utf-8") if content_len else ""
                if not raw:
                    body = json.dumps({"success": False, "error": "Request body required."}).encode()
                    self._respond(400, "application/json", body)
                    return
                data = json.loads(raw)
                to_agent = data.get("to", "").strip()
                content = data.get("content", "").strip()
                if not to_agent or not content:
                    body = json.dumps({"success": False, "error": "Missing 'to' or 'content' field."}).encode()
                    self._respond(400, "application/json", body)
                    return
                result = agent_runner.send_manual_message(to_agent, content)
                body = json.dumps(result).encode()
                self._respond(200, "application/json", body)
            except (json.JSONDecodeError, ValueError):
                body = json.dumps({"success": False, "error": "Invalid JSON body."}).encode()
                self._respond(400, "application/json", body)
            except Exception as exc:
                body = json.dumps({"success": False, "error": str(exc)}).encode()
                self._respond(500, "application/json", body)
        elif self.path == "/api/agent-stop":
            try:
                agent_runner.stop_all()
                body = json.dumps({"success": True}).encode()
                self._respond(200, "application/json", body)
            except Exception as exc:
                body = json.dumps({"success": False, "error": str(exc)}).encode()
                self._respond(500, "application/json", body)
        elif self.path == "/api/builder-tools-config":
            try:
                content_len = int(self.headers.get("Content-Length", 0))
                raw = self.rfile.read(content_len).decode("utf-8") if content_len else ""
                data = json.loads(raw)
                workdir = data.get("workdir", "").strip()
                blocked = data.get("blocked", [])
                if not workdir:
                    body = json.dumps({"success": False, "error": "Missing 'workdir' field."}).encode()
                    self._respond(400, "application/json", body)
                    return
                cfg = agent_runner.load_builder_tools_config()
                proj = agent_runner._get_project_config(cfg, workdir)
                proj["blocked_mcp"] = blocked
                cfg[workdir] = proj
                agent_runner.save_builder_tools_config(cfg)
                body = json.dumps({"success": True}).encode()
                self._respond(200, "application/json", body)
            except (json.JSONDecodeError, ValueError):
                body = json.dumps({"success": False, "error": "Invalid JSON body."}).encode()
                self._respond(400, "application/json", body)
            except Exception as exc:
                body = json.dumps({"success": False, "error": str(exc)}).encode()
                self._respond(500, "application/json", body)
        elif self.path == "/api/global-mcp-defaults":
            try:
                content_len = int(self.headers.get("Content-Length", 0))
                raw = self.rfile.read(content_len).decode("utf-8") if content_len else ""
                data = json.loads(raw)
                blocked = data.get("blocked", [])
                cfg = agent_runner.load_builder_tools_config()
                cfg["_global_defaults"] = blocked
                if data.get("apply_all"):
                    for key in list(cfg.keys()):
                        if key != "_global_defaults":
                            cfg[key] = list(blocked)
                agent_runner.save_builder_tools_config(cfg)
                body = json.dumps({"success": True}).encode()
                self._respond(200, "application/json", body)
            except (json.JSONDecodeError, ValueError):
                body = json.dumps({"success": False, "error": "Invalid JSON body."}).encode()
                self._respond(400, "application/json", body)
            except Exception as exc:
                body = json.dumps({"success": False, "error": str(exc)}).encode()
                self._respond(500, "application/json", body)
        elif self.path == "/api/burn-report/reset":
            try:
                from .stats import reset_burn_stats
                result = reset_burn_stats()
                body = json.dumps(result).encode()
                self._respond(200, "application/json", body)
            except Exception as exc:
                body = json.dumps({"success": False, "error": str(exc)}).encode()
                self._respond(500, "application/json", body)
        elif self.path == "/api/agent-reset":
            try:
                result = agent_runner.reset_session()
                body = json.dumps(result).encode()
                self._respond(200, "application/json", body)
            except Exception as exc:
                body = json.dumps({"success": False, "error": str(exc)}).encode()
                self._respond(500, "application/json", body)
        elif self.path in ("/api/agent-commit", "/api/agent-commit-push"):
            try:
                content_len = int(self.headers.get("Content-Length", 0))
                raw = self.rfile.read(content_len).decode("utf-8") if content_len else ""
                data = json.loads(raw) if raw else {}
                message = data.get("message", "").strip()
                if not message:
                    body = json.dumps({"success": False, "error": "Missing 'message' field."}).encode()
                    self._respond(400, "application/json", body)
                    return
                status = agent_runner.get_status()
                work_dir = status.get("working_dir", "")
                if not work_dir or not Path(work_dir).is_dir():
                    body = json.dumps({"success": False, "error": "No valid working directory from last session."}).encode()
                    self._respond(400, "application/json", body)
                    return

                def _run_git(args: list, cwd: str, timeout: int = 30) -> tuple:
                    r = subprocess.run(["git"] + args, capture_output=True, text=True, cwd=cwd, timeout=timeout)
                    out = f"$ git {' '.join(args)}\n{r.stdout}{r.stderr}".strip()
                    return (r.returncode == 0, out)

                output_parts = []

                import fnmatch as _fnmatch

                _ALLOWED_EXTENSIONS = {
                    '.py', '.ts', '.tsx', '.js', '.jsx', '.css', '.scss',
                    '.md', '.yml', '.yaml', '.toml', '.cfg', '.ini', '.sql',
                    '.sh', '.bat', '.cmd', '.rs', '.go', '.java', '.rb',
                    '.php', '.vue', '.svelte', '.astro',
                }
                _ALLOWED_JSON_FILES = {
                    'package.json', 'package-lock.json', 'tsconfig.json',
                    'pyproject.toml', 'composer.json', 'Cargo.toml',
                    '.eslintrc.json', '.prettierrc.json',
                }
                _TSCONFIG_GLOB = 'tsconfig.*.json'

                def _is_safe_file(fpath: str) -> str | None:
                    """Return None if file is safe to stage, or a reason string if it should be skipped."""
                    fp = fpath.replace('\\', '/')
                    basename = fp.split('/')[-1]
                    parts = fp.split('/')

                    if fp.startswith('.claude/') or '/.claude/' in fp:
                        return "in .claude/ directory"
                    if 'node_modules/' in fp or fp.startswith('node_modules/'):
                        return "in node_modules/"
                    if '__pycache__/' in fp or fp.startswith('__pycache__/'):
                        return "in __pycache__/"
                    if basename == 'AGENTS.md':
                        return "AGENTS.md excluded"
                    if basename.startswith('.env'):
                        return ".env file excluded"
                    if basename.endswith('.log'):
                        return "log file excluded"
                    if basename.endswith('.pyc'):
                        return "compiled Python file"
                    if basename.startswith('console.') or basename.startswith('process.'):
                        return "CC junk file"
                    if basename.endswith('_signal.txt') or basename.endswith('_profit_margin.txt') or basename.endswith('_onoff.txt'):
                        return "trading signal file"
                    if basename == 'alerts_version.txt':
                        return "alerts version file"
                    if basename == 'indicators_data.json':
                        return "indicators data file"
                    if fp == 'scripts/inspect_stats_db.py' or fp.endswith('/scripts/inspect_stats_db.py'):
                        return "test script excluded"
                    for part in parts[:-1]:
                        if part.isupper() and 2 <= len(part) <= 5 and part.isalpha():
                            return f"crypto ticker directory ({part}/)"

                    _, ext = os.path.splitext(basename)
                    ext = ext.lower()

                    if ext == '.html':
                        if any(p in ('src', 'public') for p in parts[:-1]):
                            return None
                        return ".html only allowed in src/ or public/"

                    if ext == '.json':
                        if basename in _ALLOWED_JSON_FILES:
                            return None
                        if _fnmatch.fnmatch(basename, _TSCONFIG_GLOB):
                            return None
                        return f".json file not in allowlist ({basename})"

                    if ext in _ALLOWED_EXTENSIONS:
                        return None

                    return f"extension '{ext or '(none)'}' not in whitelist"

                diff_r = subprocess.run(["git", "diff", "--name-only"], capture_output=True, text=True, cwd=work_dir, timeout=30)
                status_r = subprocess.run(["git", "status", "--porcelain"], capture_output=True, text=True, cwd=work_dir, timeout=30)
                changed_files: set[str] = set()
                for line in diff_r.stdout.splitlines():
                    f = line.strip()
                    if f:
                        changed_files.add(f)
                for line in status_r.stdout.splitlines():
                    f = line[3:].strip()
                    if f:
                        changed_files.add(f)
                safe_files = []
                skipped_files = []
                for f in changed_files:
                    reason = _is_safe_file(f)
                    if reason is None:
                        safe_files.append(f)
                    else:
                        skipped_files.append(f"{f} ({reason})")
                if skipped_files:
                    output_parts.append("Skipped files:\n" + "\n".join(f"  - {s}" for s in sorted(skipped_files)))
                if not safe_files:
                    body = json.dumps({"success": False, "error": "No files to commit after safety filter"}).encode()
                    self._respond(400, "application/json", body)
                    return
                ok, out = _run_git(["add", "--"] + safe_files, work_dir)
                output_parts.append(out)
                if not ok:
                    body = json.dumps({"success": False, "error": "git add failed", "output": "\n".join(output_parts)}).encode()
                    self._respond(500, "application/json", body)
                    return

                ok, out = _run_git(["commit", "-m", message], work_dir)
                output_parts.append(out)
                if not ok:
                    if "nothing to commit" not in out.lower():
                        body = json.dumps({"success": False, "error": "git commit failed", "output": "\n".join(output_parts)}).encode()
                        self._respond(500, "application/json", body)
                        return

                if self.path == "/api/agent-commit-push":
                    ok, out = _run_git(["branch", "--show-current"], work_dir)
                    current_branch = out.split("\n", 1)[-1].strip() if ok else ""
                    output_parts.append(out)
                    if not ok or not current_branch:
                        body = json.dumps({"success": False, "error": "Could not detect current branch", "output": "\n".join(output_parts)}).encode()
                        self._respond(500, "application/json", body)
                        return

                    wf, _ = agent_runner.get_git_workflow_for_project(work_dir)
                    push_ok, push_err = _git_push_with_workflow(
                        _run_git, work_dir, current_branch, output_parts, wf)
                    if not push_ok:
                        body = json.dumps({"success": False, "error": push_err, "output": "\n".join(output_parts)}).encode()
                        self._respond(500, "application/json", body)
                        return

                body = json.dumps({"success": True, "output": "\n\n".join(output_parts)}).encode()
                self._respond(200, "application/json", body)
            except (json.JSONDecodeError, ValueError):
                body = json.dumps({"success": False, "error": "Invalid JSON body."}).encode()
                self._respond(400, "application/json", body)
            except subprocess.TimeoutExpired:
                body = json.dumps({"success": False, "error": "Git command timed out."}).encode()
                self._respond(500, "application/json", body)
            except Exception as exc:
                body = json.dumps({"success": False, "error": str(exc)}).encode()
                self._respond(500, "application/json", body)
        elif self.path == "/api/agent/push":
            try:
                status = agent_runner.get_status()
                work_dir = status.get("working_dir", "")
                if not work_dir or not Path(work_dir).is_dir():
                    body = json.dumps({"success": False, "error": "No valid working directory from last session."}).encode()
                    self._respond(400, "application/json", body)
                    return

                def _run_git_p(args: list, cwd: str, timeout: int = 30) -> tuple:
                    r = subprocess.run(["git"] + args, capture_output=True, text=True, cwd=cwd, timeout=timeout)
                    out = f"$ git {' '.join(args)}\n{r.stdout}{r.stderr}".strip()
                    return (r.returncode == 0, out)

                status_r = subprocess.run(["git", "status", "--porcelain"], capture_output=True, text=True, cwd=work_dir, timeout=30)
                if status_r.stdout.strip():
                    body = json.dumps({"success": False, "error": "Uncommitted changes. Commit first."}).encode()
                    self._respond(200, "application/json", body)
                    return

                output_parts = []
                ok, out = _run_git_p(["branch", "--show-current"], work_dir)
                current_branch = out.split("\n", 1)[-1].strip() if ok else ""
                output_parts.append(out)
                if not ok or not current_branch:
                    body = json.dumps({"success": False, "error": "Could not detect current branch", "output": "\n".join(output_parts)}).encode()
                    self._respond(500, "application/json", body)
                    return

                wf, _ = agent_runner.get_git_workflow_for_project(work_dir)
                try:
                    push_ok, push_err = _git_push_with_workflow(
                        _run_git_p, work_dir, current_branch, output_parts, wf)
                    if not push_ok:
                        body = json.dumps({"success": False, "error": push_err, "output": "\n".join(output_parts)}).encode()
                        self._respond(500, "application/json", body)
                        return
                finally:
                    if current_branch:
                        _run_git_p(["checkout", current_branch], work_dir, timeout=30)

                body = json.dumps({"success": True, "output": "\n\n".join(output_parts)}).encode()
                self._respond(200, "application/json", body)
            except subprocess.TimeoutExpired:
                body = json.dumps({"success": False, "error": "Git command timed out."}).encode()
                self._respond(500, "application/json", body)
            except Exception as exc:
                body = json.dumps({"success": False, "error": str(exc)}).encode()
                self._respond(500, "application/json", body)
        elif self.path == "/api/agent-save-diary":
            try:
                status = agent_runner.get_status()
                if not status or status.get("status") == "idle":
                    body = json.dumps({"success": False, "error": "No active session"}).encode()
                    self._respond(400, "application/json", body)
                    return

                task_text = (status.get("task", "") or "")[:200]
                agents_info = status.get("agents", {})
                role_labels = {"manager": "Architect", "builder": "Enforcer", "reviewer": "Auditor"}

                agent_outputs = {}
                for role in ("manager", "builder", "reviewer"):
                    ag = agents_info.get(role, {})
                    agent_outputs[role] = (ag.get("last_output", "") or "")[:500] or "No output"

                total_tokens = sum(
                    (agents_info.get(r, {}).get("input_tokens", 0) or 0) +
                    (agents_info.get(r, {}).get("output_tokens", 0) or 0)
                    for r in ("manager", "builder", "reviewer")
                )

                duration_str = "Unknown"
                started_at = status.get("started_at")
                if started_at:
                    try:
                        if isinstance(started_at, str):
                            started_ts = time.mktime(time.strptime(started_at, "%Y-%m-%d %H:%M:%S"))
                        else:
                            started_ts = float(started_at)
                        elapsed = time.time() - started_ts
                        duration_str = f"{int(elapsed // 60)}m {int(elapsed % 60)}s"
                    except Exception:
                        pass

                input_cost_rate = {"manager": 5.0, "builder": 3.0, "reviewer": 3.0}
                output_cost_rate = {"manager": 25.0, "builder": 15.0, "reviewer": 15.0}
                cost = sum(
                    (agents_info.get(r, {}).get("input_tokens", 0) or 0) / 1_000_000 * input_cost_rate.get(r, 3.0) +
                    (agents_info.get(r, {}).get("output_tokens", 0) or 0) / 1_000_000 * output_cost_rate.get(r, 15.0)
                    for r in ("manager", "builder", "reviewer")
                )

                date_slug = time.strftime("%Y-%m-%d")
                slug_source = task_text
                if "Task:" in slug_source:
                    slug_source = slug_source.split("Task:", 1)[1]
                slug_words = re.sub(r"[^a-z0-9 ]", "", slug_source.lower()).split()[:5]
                slug = "-".join(slug_words) if slug_words else "session"

                md_lines = [
                    f"# {date_slug} - {task_text[:80]}",
                    "",
                    "## Summary",
                    "",
                    f"Task: {task_text}",
                    "",
                    "## Agent Outputs",
                    "",
                    f"**{role_labels['manager']}:** {agent_outputs['manager']}",
                    "",
                    f"**{role_labels['builder']}:** {agent_outputs['builder']}",
                    "",
                    f"**{role_labels['reviewer']}:** {agent_outputs['reviewer']}",
                    "",
                    "## Stats",
                    "",
                    f"- Tokens: {total_tokens:,}",
                    f"- Duration: {duration_str}",
                    f"- Estimated cost: ${cost:.4f}",
                    "",
                ]
                md_content = "\n".join(md_lines)

                primary_dir = Path.home() / ".memstack" / "diary"
                md_filename = f"{date_slug}-{slug}.md"
                saved_file = None
                try:
                    primary_dir.mkdir(parents=True, exist_ok=True)
                    md_file = primary_dir / md_filename
                    md_file.write_text(md_content, encoding="utf-8")
                    saved_file = str(md_file)
                except Exception as e:
                    print(f"[diary] write error: {e}")

                ts = time.strftime("%Y-%m-%d_%H-%M-%S")
                messages = status.get("messages", [])
                diary_json_data = {
                    "timestamp": time.strftime("%Y-%m-%dT%H:%M:%S"),
                    "task": status.get("task", ""),
                    "source": "dashboard",
                    "messages_count": len(messages) if isinstance(messages, list) else 0,
                    "agents": {},
                    "messages": messages,
                    "tokens_used": {},
                }
                for role in ("manager", "builder", "reviewer"):
                    agent_data = agents_info.get(role, {})
                    diary_json_data["agents"][role] = {
                        "status": agent_data.get("status", "unknown"),
                        "output_summary": (agent_data.get("last_output", "") or "")[:500],
                    }
                    diary_json_data["tokens_used"][role] = {
                        "input_tokens": agent_data.get("input_tokens", 0),
                        "output_tokens": agent_data.get("output_tokens", 0),
                        "context_tokens": agent_data.get("context_tokens", 0),
                    }
                try:
                    json_file = primary_dir / f"{ts}.json"
                    json_file.write_text(json.dumps(diary_json_data, indent=2), encoding="utf-8")
                    if not saved_file:
                        saved_file = str(json_file)
                except Exception as e:
                    print(f"[diary] json write error: {e}")

                if saved_file:
                    working_dir = status.get("working_dir", "") or ""
                    files_changed = 0
                    try:
                        git_result = subprocess.run(
                            ["git", "diff", "--name-only"],
                            capture_output=True, text=True, timeout=5, cwd=working_dir or None,
                        )
                        if git_result.returncode == 0:
                            files_changed = len([l for l in git_result.stdout.splitlines() if l.strip()])
                    except Exception:
                        pass
                    summary = {
                        "file": saved_file,
                        "project": os.path.basename(working_dir),
                        "started_at": status.get("started_at", ""),
                        "iteration": status.get("iteration", 0),
                        "max_iterations": status.get("max_iterations", 0),
                        "messages_count": diary_json_data["messages_count"],
                        "reviewer_summary": (agents_info.get("reviewer", {}).get("last_output", "") or "")[:200],
                        "task": task_text[:100],
                        "files_changed": files_changed,
                        "insights_saved": 0,
                    }
                    print(f"[diary] saved {md_filename} ({total_tokens:,} tokens, {duration_str})")
                    body = json.dumps({"success": True, "file": saved_file, "summary": summary}).encode()
                    self._respond(200, "application/json", body)
                else:
                    body = json.dumps({"success": False, "error": "Could not write diary to any location"}).encode()
                    self._respond(500, "application/json", body)
            except Exception as exc:
                print(f"[diary] error: {exc}")
                body = json.dumps({"success": False, "error": str(exc)}).encode()
                self._respond(500, "application/json", body)
        elif self.path == "/api/git-workflow":
            try:
                content_len = int(self.headers.get("Content-Length", 0))
                raw = self.rfile.read(content_len).decode("utf-8") if content_len else ""
                if not raw:
                    body = json.dumps({"success": False, "error": "Request body required."}).encode()
                    self._respond(400, "application/json", body)
                    return
                data = json.loads(raw)
                workflow = data.get("workflow", "").strip()
                if workflow not in agent_runner._VALID_GIT_WORKFLOWS:
                    body = json.dumps({"success": False, "error": f"Invalid workflow. Use one of: {', '.join(agent_runner._VALID_GIT_WORKFLOWS)}"}).encode()
                    self._respond(400, "application/json", body)
                    return
                workdir = data.get("workdir", "").strip()
                cfg = agent_runner.load_builder_tools_config()
                if workdir:
                    proj = agent_runner._get_project_config(cfg, workdir)
                    proj["git_workflow"] = workflow
                    cfg[workdir] = proj
                else:
                    cfg["_git_workflow"] = workflow
                agent_runner.save_builder_tools_config(cfg)
                body = json.dumps({"success": True, "workflow": workflow, "scope": "project" if workdir else "global"}).encode()
                self._respond(200, "application/json", body)
            except (json.JSONDecodeError, ValueError):
                body = json.dumps({"success": False, "error": "Invalid JSON body."}).encode()
                self._respond(400, "application/json", body)
            except Exception as exc:
                body = json.dumps({"success": False, "error": str(exc)}).encode()
                self._respond(500, "application/json", body)
        elif self.path == "/api/agent-modes":
            try:
                content_len = int(self.headers.get("Content-Length", 0))
                raw = self.rfile.read(content_len).decode("utf-8") if content_len else ""
                if not raw:
                    body = json.dumps({"success": False, "error": "Request body required."}).encode()
                    self._respond(400, "application/json", body)
                    return
                data = json.loads(raw)
                modes = {}
                for ag in ("manager", "builder", "reviewer"):
                    val = data.get(ag, "")
                    if val not in ("api", "subscription"):
                        body = json.dumps({"success": False, "error": f"Invalid mode for {ag}: {val}"}).encode()
                        self._respond(400, "application/json", body)
                        return
                    modes[ag] = val
                agent_runner.save_agent_modes(modes)
                body = json.dumps({"success": True}).encode()
                self._respond(200, "application/json", body)
            except (json.JSONDecodeError, ValueError):
                body = json.dumps({"success": False, "error": "Invalid JSON body."}).encode()
                self._respond(400, "application/json", body)
            except Exception as exc:
                body = json.dumps({"success": False, "error": str(exc)}).encode()
                self._respond(500, "application/json", body)
        elif self.path == "/api/set-api-key":
            try:
                content_len = int(self.headers.get("Content-Length", 0))
                raw = self.rfile.read(content_len).decode("utf-8") if content_len else ""
                if not raw:
                    body = json.dumps({"success": False, "error": "Request body required."}).encode()
                    self._respond(400, "application/json", body)
                    return
                data = json.loads(raw)
                key = data.get("key", "").strip()
                if not key:
                    api_key_file = Path.home() / ".memstack" / "api_key"
                    if api_key_file.is_file():
                        api_key_file.unlink()
                    os.environ.pop("ANTHROPIC_API_KEY", None)
                    body = json.dumps({"success": True, "api_key_set": False, "api_key_hint": ""}).encode()
                    self._respond(200, "application/json", body)
                    return
                if not key.startswith("sk-ant-"):
                    body = json.dumps({"success": False, "error": "Key must start with sk-ant-"}).encode()
                    self._respond(400, "application/json", body)
                    return
                os.environ["ANTHROPIC_API_KEY"] = key
                api_key_file = Path.home() / ".memstack" / "api_key"
                api_key_file.parent.mkdir(parents=True, exist_ok=True)
                api_key_file.write_text(key, encoding="utf-8")
                hint = "sk-ant-..." + key[-4:] if len(key) >= 8 else ""
                body = json.dumps({"success": True, "api_key_set": True, "api_key_hint": hint}).encode()
                self._respond(200, "application/json", body)
            except (json.JSONDecodeError, ValueError):
                body = json.dumps({"success": False, "error": "Invalid JSON body."}).encode()
                self._respond(400, "application/json", body)
            except Exception as exc:
                body = json.dumps({"success": False, "error": str(exc)}).encode()
                self._respond(500, "application/json", body)
        elif self.path == "/api/oauth-token":
            try:
                content_len = int(self.headers.get("Content-Length", 0))
                raw = self.rfile.read(content_len).decode("utf-8") if content_len else ""
                if not raw:
                    body = json.dumps({"success": False, "error": "Request body required."}).encode()
                    self._respond(400, "application/json", body)
                    return
                data = json.loads(raw)
                token = data.get("token", "").strip()
                if not token:
                    if agent_runner.OAUTH_TOKEN_FILE.is_file():
                        agent_runner.OAUTH_TOKEN_FILE.unlink()
                    body = json.dumps({"success": True, "oauth_token_set": False, "oauth_token_hint": ""}).encode()
                    self._respond(200, "application/json", body)
                    return
                agent_runner.OAUTH_TOKEN_FILE.parent.mkdir(parents=True, exist_ok=True)
                agent_runner.OAUTH_TOKEN_FILE.write_text(token, encoding="utf-8")
                hint = "..." + token[-4:] if len(token) >= 8 else ""
                body = json.dumps({"success": True, "oauth_token_set": True, "oauth_token_hint": hint}).encode()
                self._respond(200, "application/json", body)
            except (json.JSONDecodeError, ValueError):
                body = json.dumps({"success": False, "error": "Invalid JSON body."}).encode()
                self._respond(400, "application/json", body)
            except Exception as exc:
                body = json.dumps({"success": False, "error": str(exc)}).encode()
                self._respond(500, "application/json", body)
        elif self.path == "/api/git-checkout":
            try:
                content_len = int(self.headers.get("Content-Length", 0))
                raw = self.rfile.read(content_len).decode("utf-8") if content_len else ""
                if not raw:
                    body = json.dumps({"success": False, "error": "Request body required."}).encode()
                    self._respond(400, "application/json", body)
                    return
                data = json.loads(raw)
                workdir = data.get("workdir", "").strip()
                branch = data.get("branch", "").strip()
                if not workdir or not branch:
                    body = json.dumps({"success": False, "error": "Missing 'workdir' or 'branch' field."}).encode()
                    self._respond(400, "application/json", body)
                    return
                wd_err = _validate_working_dir(workdir)
                if wd_err:
                    body = json.dumps({"success": False, "error": wd_err}).encode()
                    self._respond(400, "application/json", body)
                    return
                status = agent_runner.get_status()
                if status and status.get("status") not in (None, "idle", "completed", "stopped", "failed"):
                    body = json.dumps({"success": False, "error": "Cannot switch branches while an agent task is running."}).encode()
                    self._respond(409, "application/json", body)
                    return
                if not re.fullmatch(r'[a-zA-Z0-9_./-]+', branch):
                    body = json.dumps({"success": False, "error": "Invalid branch name."}).encode()
                    self._respond(400, "application/json", body)
                    return
                r = subprocess.run(["git", "checkout", branch], capture_output=True, text=True, cwd=workdir, timeout=30)
                output = ((r.stdout or "") + (r.stderr or "")).strip()
                if r.returncode == 0:
                    body = json.dumps({"success": True, "message": output or f"Switched to branch '{branch}'."}).encode()
                    self._respond(200, "application/json", body)
                else:
                    body = json.dumps({"success": False, "error": output or f"Failed to checkout '{branch}'."}).encode()
                    self._respond(500, "application/json", body)
            except (json.JSONDecodeError, ValueError):
                body = json.dumps({"success": False, "error": "Invalid JSON body."}).encode()
                self._respond(400, "application/json", body)
            except subprocess.TimeoutExpired:
                body = json.dumps({"success": False, "error": "Git command timed out."}).encode()
                self._respond(500, "application/json", body)
            except Exception as exc:
                body = json.dumps({"success": False, "error": str(exc)}).encode()
                self._respond(500, "application/json", body)
        elif self.path == "/api/plugins/toggle":
            try:
                content_len = int(self.headers.get("Content-Length", 0))
                raw = self.rfile.read(content_len).decode("utf-8") if content_len else ""
                if not raw:
                    body = json.dumps({"success": False, "error": "Request body required."}).encode()
                    self._respond(400, "application/json", body)
                    return
                data = json.loads(raw)
                action = data.get("action", "").strip()
                plugin_name = data.get("name", "").strip()
                if action not in ("enable", "disable"):
                    body = json.dumps({"success": False, "error": "Invalid action. Use 'enable' or 'disable'."}).encode()
                    self._respond(400, "application/json", body)
                    return
                if not plugin_name:
                    body = json.dumps({"success": False, "error": "Missing 'name' field."}).encode()
                    self._respond(400, "application/json", body)
                    return
                status = agent_runner.get_status()
                if status and status.get("status") not in (None, "idle", "completed", "stopped", "failed"):
                    body = json.dumps({"success": False, "error": "Cannot modify plugins while an agent task is running."}).encode()
                    self._respond(409, "application/json", body)
                    return
                r = subprocess.run(
                    ["claude", "plugin", action, plugin_name],
                    capture_output=True, text=True, timeout=30,
                )
                output = ((r.stdout or "") + (r.stderr or "")).strip()
                if r.returncode == 0:
                    body = json.dumps({"success": True, "message": output or f"Plugin '{plugin_name}' {action}d."}).encode()
                    self._respond(200, "application/json", body)
                else:
                    body = json.dumps({"success": False, "error": output or f"Failed to {action} plugin."}).encode()
                    self._respond(500, "application/json", body)
            except (json.JSONDecodeError, ValueError):
                body = json.dumps({"success": False, "error": "Invalid JSON body."}).encode()
                self._respond(400, "application/json", body)
            except subprocess.TimeoutExpired:
                body = json.dumps({"success": False, "error": "Plugin command timed out."}).encode()
                self._respond(500, "application/json", body)
            except Exception as exc:
                body = json.dumps({"success": False, "error": str(exc)}).encode()
                self._respond(500, "application/json", body)
        else:
            body = json.dumps({"success": False, "error": "Not found"}).encode()
            self._respond(404, "application/json", body)

    def do_OPTIONS(self):
        self.send_response(204)
        allowed = self._cors_origin()
        if allowed:
            self.send_header("Access-Control-Allow-Origin", allowed)
        self.send_header("Access-Control-Allow-Methods", "GET, POST, OPTIONS")
        self.send_header("Access-Control-Allow-Headers", "Content-Type, X-Auth-Token")
        self.end_headers()

    def _handle_memory_get(self):
        parsed = urlparse(self.path)
        qs = parse_qs(parsed.query)
        route = parsed.path
        project = qs.get("project", [os.getcwd()])[0]

        if route == "/api/memory/stats":
            data = memory_db.get_memory_stats(project)
            body = json.dumps(data).encode()
            self._respond(200, "application/json", body)

        elif route == "/api/memory/events":
            limit = min(int(qs.get("limit", ["50"])[0]), 500)
            data = memory_db.get_recent_events(project, limit=limit)
            body = json.dumps(data).encode()
            self._respond(200, "application/json", body)

        elif route == "/api/memory/lessons":
            category = qs.get("category", [None])[0]
            data = memory_db.get_lessons(project_dir=project, category=category)
            body = json.dumps(data).encode()
            self._respond(200, "application/json", body)

        elif route == "/api/memory/search":
            q = qs.get("q", [""])[0]
            limit = min(int(qs.get("limit", ["20"])[0]), 500)
            if not q:
                body = json.dumps([]).encode()
            else:
                data = memory_db.search_memory(q, project_dir=project, limit=limit)
                body = json.dumps(data).encode()
            self._respond(200, "application/json", body)

        elif route == "/api/memory/sessions":
            sessions = memory_db.get_session_summaries(project, limit=min(500, 100))
            body = json.dumps(sessions).encode()
            self._respond(200, "application/json", body)

        else:
            self.send_error(404)

    def _cors_origin(self) -> str | None:
        origin = self.headers.get("Origin", "")
        if origin in self.server.allowed_origins:
            return origin
        return None

    def _respond(self, status: int, content_type: str, body: bytes):
        self.send_response(status)
        self.send_header("Content-Type", content_type)
        self.send_header("Content-Length", str(len(body)))
        allowed = self._cors_origin()
        if allowed:
            self.send_header("Access-Control-Allow-Origin", allowed)
        self.end_headers()
        self.wfile.write(body)


def start_dashboard(port: int = 3333, open_browser: bool = True):
    """Start the dashboard HTTP server (blocking)."""
    api_key_file = Path.home() / ".memstack" / "api_key"
    if not os.environ.get("ANTHROPIC_API_KEY") and api_key_file.is_file():
        try:
            stored = api_key_file.read_text(encoding="utf-8").strip()
            if stored:
                os.environ["ANTHROPIC_API_KEY"] = stored
        except OSError:
            pass
    httpd = _DashboardServer(("127.0.0.1", port), _Handler)
    url = f"http://localhost:{port}"
    print(f"MemStack\u2122 Dashboard running at {url}", file=sys.stderr)
    if open_browser:
        webbrowser.open(url)
    try:
        httpd.serve_forever()
    except KeyboardInterrupt:
        print("\nDashboard stopped.", file=sys.stderr)
    finally:
        httpd.server_close()
