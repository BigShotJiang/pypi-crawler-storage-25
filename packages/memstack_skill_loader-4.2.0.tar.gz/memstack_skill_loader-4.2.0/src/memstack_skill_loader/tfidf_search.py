"""Lightweight TF-IDF search against pre-built skill index.

This module replaces the heavy sentence-transformers/PyTorch search
with scikit-learn TF-IDF, cutting cold start from ~10s to ~2s.
The TF-IDF index is built at index time by indexer.py and loaded
from a pickle file at search time.
"""

import pickle
import sys
from pathlib import Path

from sklearn.metrics.pairwise import cosine_similarity

from .config import Config, load_config

# Lazy-loaded singletons
_index = None  # dict with 'vectorizer', 'matrix', 'skills'


def _get_index(config: Config) -> dict | None:
    """Load the pre-built TF-IDF index from pickle."""
    global _index
    if _index is not None:
        return _index

    pkl_path = config.resolved_vector_db_path / "tfidf_index.pkl"
    if not pkl_path.exists():
        print(f"TF-IDF index not found at {pkl_path}. Run index_skills.py first.", file=sys.stderr)
        return None

    try:
        with open(pkl_path, "rb") as f:
            # SECURITY: pickle.load can execute arbitrary code. This file is local-only and built by our own indexer. Do not load pickles from untrusted sources.
            _index = pickle.load(f)
        print(f"Loaded TF-IDF index: {len(_index['skills'])} skills", file=sys.stderr)
        return _index
    except Exception as e:
        print(f"Error loading TF-IDF index: {e}", file=sys.stderr)
        return None


def search_skills(query: str, config: Config, top_k: int = 3) -> list[dict]:
    """Search skills using TF-IDF cosine similarity."""
    index = _get_index(config)
    if index is None:
        return []

    vectorizer = index["vectorizer"]
    matrix = index["matrix"]
    skills = index["skills"]

    query_vec = vectorizer.transform([query])
    similarities = cosine_similarity(query_vec, matrix)[0]

    # Get top-k indices sorted by score descending
    ranked = sorted(range(len(similarities)), key=lambda i: similarities[i], reverse=True)[:top_k]

    results = []
    for idx in ranked:
        score = round(float(similarities[idx]), 4)
        if score <= 0:
            continue
        skill = skills[idx]
        results.append({
            "name": skill["name"],
            "slug": skill["slug"],
            "description": skill["description"],
            "source_label": skill["source_label"],
            "content": skill["content"],
            "filepath": skill["filepath"],
            "score": score,
        })

    return results


def list_all_skills(config: Config) -> list[dict]:
    """Return all indexed skills (name, description, source_label)."""
    index = _get_index(config)
    if index is None:
        return []

    return sorted(
        [
            {
                "name": s["name"],
                "slug": s["slug"],
                "description": s["description"],
                "source_label": s["source_label"],
            }
            for s in index["skills"]
        ],
        key=lambda s: s["name"],
    )


def get_skill_by_name(name: str, config: Config) -> dict | None:
    """Find a skill by name: exact match -> substring -> TF-IDF fallback."""
    index = _get_index(config)
    if index is None:
        return None

    skills = index["skills"]
    name_lower = name.strip().lower()

    # Stage 1: exact match (by name or slug)
    for skill in skills:
        if skill["name"].lower() == name_lower or skill["slug"] == name_lower:
            return {
                "name": skill["name"],
                "slug": skill["slug"],
                "description": skill["description"],
                "source_label": skill["source_label"],
                "content": skill["content"],
                "filepath": skill["filepath"],
            }

    # Stage 2: substring fuzzy match
    for skill in skills:
        skill_lower = skill["name"].lower()
        if name_lower in skill_lower or skill_lower in name_lower:
            return {
                "name": skill["name"],
                "slug": skill["slug"],
                "description": skill["description"],
                "source_label": skill["source_label"],
                "content": skill["content"],
                "filepath": skill["filepath"],
            }

    # Stage 3: TF-IDF search fallback
    results = search_skills(name, config, top_k=1)
    if results and results[0]["score"] > 0.3:
        return results[0]

    return None


def reset_cache():
    """Clear cached index so next query reloads from disk."""
    global _index
    _index = None
