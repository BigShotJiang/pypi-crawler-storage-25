"""Skill indexer — reads SKILL.md files and builds LanceDB vector index."""

import sys
from pathlib import Path

import lancedb

from .config import Config, load_config


def _parse_frontmatter(content: str) -> tuple[dict, str]:
    """Extract YAML frontmatter and body from markdown content."""
    if not content.startswith("---"):
        return {}, content

    end = content.find("---", 3)
    if end == -1:
        return {}, content

    frontmatter_text = content[3:end].strip()
    body = content[end + 3:].strip()

    metadata = {}
    for line in frontmatter_text.split("\n"):
        line = line.strip()
        if ":" in line:
            key, _, value = line.partition(":")
            value = value.strip().strip('"').strip("'")
            metadata[key.strip()] = value

    return metadata, body


def _display_name_from_filename(dirname: str) -> str:
    """Convert 'railway-deploy' to 'Railway Deploy'."""
    return dirname.replace("-", " ").replace("_", " ").title()


def _display_name_from_meta_name(meta_name: str) -> str:
    """Convert 'memstack-codebase-index' to 'Codebase Index'."""
    parts = meta_name.split("-")
    if parts[0] == "memstack":
        parts = parts[1:]
    return " ".join(parts).title()


def _display_name_from_h1(body: str) -> str:
    """Extract display name from the first H1 heading, before any em-dash."""
    for line in body.split("\n"):
        line = line.strip()
        if line.startswith("# "):
            heading = line[2:].strip()
            # Strip subtitle after em-dash (e.g., "Codebase Index — Scanning...")
            if " — " in heading:
                heading = heading.split(" — ")[0].strip()
            elif " - " in heading:
                heading = heading.split(" - ")[0].strip()
            return heading
    return ""


def discover_skills(config: Config) -> list[dict]:
    """Walk skill sources and parse all SKILL.md files."""
    skills = []

    for source in config.skill_sources:
        source_path = Path(source.path).expanduser()
        if not source_path.exists():
            print(f"Warning: skill source not found: {source_path}", file=sys.stderr)
            continue

        pattern = source.pattern
        for skill_file in sorted(source_path.glob(pattern)):
            content = skill_file.read_text(encoding="utf-8", errors="replace")
            metadata, body = _parse_frontmatter(content)

            # Primary: H1 heading (human-readable)
            display_name = _display_name_from_h1(body)
            # Fallback: frontmatter name (machine ID → title case)
            if not display_name:
                meta_name = metadata.get("name", "")
                if meta_name:
                    display_name = _display_name_from_meta_name(meta_name)
            # Last resort: directory name
            if not display_name:
                display_name = _display_name_from_filename(skill_file.parent.name)

            description = metadata.get("description", "")
            if not description:
                for line in body.split("\n"):
                    line = line.strip().lstrip("#").strip()
                    if line and not line.startswith("*"):
                        description = line
                        break

            skills.append({
                "name": display_name,
                "slug": skill_file.parent.name,
                "description": description,
                "filename": skill_file.name,
                "filepath": str(skill_file.resolve()),
                "source_label": source.label,
                "content": content,
            })

    return skills


def _build_tfidf_index(skills: list[dict], texts: list[str], config: Config) -> None:
    """Build a TF-IDF index and save as pickle for fast search.

    Pickle is used here because sklearn's TfidfVectorizer and sparse matrices
    cannot be serialized with JSON. The pickle is generated and consumed by
    this same codebase (indexer writes, tfidf_search reads).
    """
    import pickle
    from sklearn.feature_extraction.text import TfidfVectorizer

    vectorizer = TfidfVectorizer(
        stop_words="english",
        ngram_range=(1, 2),
        max_features=5000,
        sublinear_tf=True,
    )
    matrix = vectorizer.fit_transform(texts)

    # Store skill metadata (without vectors) alongside the TF-IDF index
    skill_meta = [
        {
            "name": s["name"],
            "slug": s["slug"],
            "description": s["description"],
            "filename": s["filename"],
            "filepath": s["filepath"],
            "source_label": s["source_label"],
            "content": s["content"],
        }
        for s in skills
    ]

    pkl_path = config.resolved_vector_db_path / "tfidf_index.pkl"
    with open(pkl_path, "wb") as f:
        pickle.dump({"vectorizer": vectorizer, "matrix": matrix, "skills": skill_meta}, f)

    # TF-IDF index saved silently


def build_index(config: Config | None = None) -> int:
    """Build/rebuild the LanceDB vector index. Returns number of skills indexed."""
    if config is None:
        config = load_config()

    skills = discover_skills(config)
    if not skills:
        print("No skills found to index.", file=sys.stderr)
        return 0

    import os
    import time
    import logging
    import warnings

    # Suppress all noisy output before importing ML libraries
    os.environ["HF_HUB_DISABLE_TELEMETRY"] = "1"
    os.environ["HF_HUB_DISABLE_IMPLICIT_TOKEN"] = "1"
    os.environ["TOKENIZERS_PARALLELISM"] = "false"
    os.environ["SAFETENSORS_FAST_GPU"] = "0"
    os.environ["TQDM_DISABLE"] = "1"
    warnings.filterwarnings("ignore")
    logging.getLogger("transformers").setLevel(logging.ERROR)
    logging.getLogger("sentence_transformers").setLevel(logging.ERROR)
    logging.getLogger("huggingface_hub").setLevel(logging.ERROR)
    logging.getLogger("safetensors").setLevel(logging.ERROR)

    print("Loading embedding model (first run may take 30-60 seconds)...", file=sys.stderr)

    # Suppress safetensors LOAD REPORT, tqdm progress bars, and HF Hub warnings
    # by redirecting at the OS file-descriptor level (C extensions bypass Python
    # sys.stdout/stderr). Import is inside the block because it also emits warnings.
    _null_fd = os.open(os.devnull, os.O_WRONLY)
    _saved_stdout_fd = os.dup(1)
    _saved_stderr_fd = os.dup(2)
    os.dup2(_null_fd, 1)
    os.dup2(_null_fd, 2)
    try:
        from sentence_transformers import SentenceTransformer
        model = SentenceTransformer(config.embedding_model)
    finally:
        os.dup2(_saved_stdout_fd, 1)
        os.dup2(_saved_stderr_fd, 2)
        os.close(_saved_stdout_fd)
        os.close(_saved_stderr_fd)
        os.close(_null_fd)

    print(f"Indexing {len(skills)} skills...", file=sys.stderr)
    t0 = time.time()

    texts = [f"{s['name']} {s['description']}" for s in skills]
    vectors = model.encode(texts, show_progress_bar=False)

    records = []
    for i, skill in enumerate(skills):
        records.append({
            "name": skill["name"],
            "description": skill["description"],
            "filename": skill["filename"],
            "filepath": skill["filepath"],
            "source_label": skill["source_label"],
            "content": skill["content"],
            "vector": vectors[i].tolist(),
        })

    db_path = str(config.resolved_vector_db_path)
    db = lancedb.connect(db_path)

    try:
        db.drop_table("skills")
    except Exception:
        pass

    db.create_table("skills", data=records)
    elapsed = time.time() - t0
    print(f"Done! {len(records)} skills indexed in {elapsed:.1f}s", file=sys.stderr)

    # Also build TF-IDF index for fast search (no PyTorch needed at search time)
    _build_tfidf_index(skills, texts, config)

    return len(records)


def main():
    """CLI entry point for rebuilding the index."""
    config = load_config()
    count = build_index(config)
    if count == 0:
        sys.exit(1)


if __name__ == "__main__":
    main()
