# MemStack Stats - Token usage and skill fire analytics
"""Local usage analytics — SQLite-backed skill fire tracking and dashboard data."""

import re
import sqlite3
import sys
from datetime import datetime, timedelta
from pathlib import Path

DB_PATH = Path.home() / ".memstack" / "stats.db"


def _get_conn() -> sqlite3.Connection:
    """Open (and initialize) the stats database."""
    DB_PATH.parent.mkdir(parents=True, exist_ok=True)
    conn = sqlite3.connect(str(DB_PATH), timeout=5)
    conn.execute("PRAGMA journal_mode=WAL")
    conn.execute(
        """
        CREATE TABLE IF NOT EXISTS skill_fires (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            skill_name TEXT NOT NULL,
            category TEXT,
            project TEXT,
            tool TEXT,
            timestamp DATETIME DEFAULT CURRENT_TIMESTAMP
        )
        """
    )
    conn.execute(
        """
        CREATE TABLE IF NOT EXISTS daily_summary (
            date TEXT PRIMARY KEY,
            total_fires INTEGER DEFAULT 0,
            unique_skills INTEGER DEFAULT 0,
            unique_projects INTEGER DEFAULT 0
        )
        """
    )
    conn.execute(
        """
        CREATE TABLE IF NOT EXISTS compression_stats (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            skill_name TEXT NOT NULL,
            tokens_before INTEGER NOT NULL,
            tokens_after INTEGER NOT NULL,
            tier TEXT,
            timestamp DATETIME DEFAULT CURRENT_TIMESTAMP
        )
        """
    )
    conn.execute(
        """
        CREATE TABLE IF NOT EXISTS api_costs (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            session_id TEXT,
            agent_name TEXT NOT NULL,
            model TEXT,
            input_tokens INTEGER DEFAULT 0,
            output_tokens INTEGER DEFAULT 0,
            cache_read_tokens INTEGER DEFAULT 0,
            cache_creation_tokens INTEGER DEFAULT 0,
            actual_cost_usd REAL DEFAULT 0.0,
            execution_mode TEXT NOT NULL DEFAULT 'unknown',
            project TEXT,
            timestamp DATETIME DEFAULT CURRENT_TIMESTAMP
        )
        """
    )
    conn.commit()
    # Column names are hardcoded but validated as defense-in-depth since ALTER TABLE cannot use parameterized queries.
    for col, typedef in [
        ("input_tokens", "INTEGER DEFAULT 0"),
        ("output_tokens", "INTEGER DEFAULT 0"),
        ("cost_usd", "REAL DEFAULT 0"),
        ("session_id", "TEXT"),
    ]:
        if not re.fullmatch(r"^[a-z_]+$", col):
            raise ValueError(f"Invalid column name: {col}")
        try:
            conn.execute(f"ALTER TABLE skill_fires ADD COLUMN {col} {typedef}")
            conn.commit()
        except sqlite3.OperationalError:
            pass
    for col, typedef in [
        ("total_tokens", "INTEGER DEFAULT 0"),
    ]:
        if not re.fullmatch(r"^[a-z_]+$", col):
            raise ValueError(f"Invalid column name: {col}")
        try:
            conn.execute(f"ALTER TABLE daily_summary ADD COLUMN {col} {typedef}")
            conn.commit()
        except sqlite3.OperationalError:
            pass
    return conn


def log_skill_fire(
    skill_name: str,
    category: str | None = None,
    project: str | None = None,
    tool: str | None = None,
    input_tokens: int = 0,
    output_tokens: int = 0,
    cost_usd: float = 0.0,
    session_id: str | None = None,
) -> None:
    """Record a skill activation. Silently swallows all errors."""
    try:
        conn = _get_conn()
        try:
            today = datetime.now().strftime("%Y-%m-%d")

            conn.execute(
                "INSERT INTO skill_fires (skill_name, category, project, tool, input_tokens, output_tokens, cost_usd, session_id) "
                "VALUES (?, ?, ?, ?, ?, ?, ?, ?)",
                (skill_name, category, project, tool, input_tokens, output_tokens, cost_usd, session_id),
            )

            row = conn.execute(
                """
                SELECT COUNT(*), COUNT(DISTINCT skill_name), COUNT(DISTINCT project),
                       SUM(input_tokens + output_tokens)
                FROM skill_fires WHERE date(timestamp) = ?
                """,
                (today,),
            ).fetchone()

            conn.execute(
                """
                INSERT INTO daily_summary (date, total_fires, unique_skills, unique_projects, total_tokens)
                VALUES (?, ?, ?, ?, ?)
                ON CONFLICT(date) DO UPDATE SET
                    total_fires = excluded.total_fires,
                    unique_skills = excluded.unique_skills,
                    unique_projects = excluded.unique_projects,
                    total_tokens = excluded.total_tokens
                """,
                (today, row[0], row[1], row[2], row[3] or 0),
            )
            conn.commit()
        finally:
            conn.close()
    except Exception as exc:
        print(f"[memstack-stats] log_skill_fire failed: {exc}", file=sys.stderr)


def log_agent_invocation(
    agent_name: str,
    prompt_chars: int,
    output_chars: int,
    session_id: str | None = None,
    working_dir: str | None = None,
    input_tokens: int = 0,
    output_tokens: int = 0,
    cost_usd: float = 0.0,
) -> None:
    """Record an Agent Runner invocation as a skill fire with real or estimated tokens."""
    import os
    try:
        project = os.path.basename(working_dir) if working_dir else None
        if input_tokens <= 0 and output_tokens <= 0:
            input_tokens = prompt_chars // 4
            output_tokens = output_chars // 4
        log_skill_fire(
            skill_name=f"agent:{agent_name}",
            category="agent-runner",
            project=project,
            tool="agent_runner",
            input_tokens=input_tokens,
            output_tokens=output_tokens,
            cost_usd=cost_usd,
            session_id=session_id,
        )
    except Exception:
        pass


def log_api_cost(
    session_id: str | None,
    agent_name: str,
    model: str | None,
    input_tokens: int,
    output_tokens: int,
    actual_cost_usd: float,
    execution_mode: str,
    project: str | None = None,
    cache_read_tokens: int = 0,
    cache_creation_tokens: int = 0,
) -> None:
    """Record a real API cost entry for an agent invocation."""
    try:
        conn = _get_conn()
        try:
            conn.execute(
                "INSERT INTO api_costs "
                "(session_id, agent_name, model, input_tokens, output_tokens, "
                "cache_read_tokens, cache_creation_tokens, actual_cost_usd, "
                "execution_mode, project) "
                "VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)",
                (session_id, agent_name, model, input_tokens, output_tokens,
                 cache_read_tokens, cache_creation_tokens, actual_cost_usd,
                 execution_mode, project),
            )
            conn.commit()
        finally:
            conn.close()
    except Exception:
        pass


def get_api_costs(time_range: str = "all") -> dict:
    """Query aggregated API cost data with time filtering.

    *time_range*: "all", "daily", "weekly", "monthly" — same semantics as
    the existing burn report range filter.
    """
    result: dict = {
        "total_actual_cost": 0.0,
        "total_input_tokens": 0,
        "total_output_tokens": 0,
        "by_model": [],
        "by_agent": [],
        "trend": [],
    }

    today = datetime.now().replace(hour=0, minute=0, second=0, microsecond=0)
    if time_range == "daily":
        since = today.strftime("%Y-%m-%d 00:00:00")
    elif time_range == "weekly":
        since_dt = today - timedelta(days=today.weekday())
        since = since_dt.strftime("%Y-%m-%d 00:00:00")
    elif time_range == "monthly":
        since = today.strftime("%Y-%m-01 00:00:00")
    else:
        since = "2000-01-01 00:00:00"

    try:
        conn = _get_conn()
        try:
            where = "WHERE timestamp >= ?"
            params: tuple = (since,)

            row = conn.execute(
                f"SELECT COALESCE(SUM(actual_cost_usd), 0), "
                f"COALESCE(SUM(input_tokens), 0), "
                f"COALESCE(SUM(output_tokens), 0) "
                f"FROM api_costs {where}",
                params,
            ).fetchone()
            if row:
                result["total_actual_cost"] = round(row[0], 4)
                result["total_input_tokens"] = int(row[1])
                result["total_output_tokens"] = int(row[2])

            for r in conn.execute(
                f"SELECT model, SUM(input_tokens), SUM(output_tokens), "
                f"SUM(actual_cost_usd), COUNT(*) "
                f"FROM api_costs {where} GROUP BY model ORDER BY SUM(actual_cost_usd) DESC",
                params,
            ).fetchall():
                result["by_model"].append({
                    "model": r[0] or "unknown",
                    "input_tokens": int(r[1]),
                    "output_tokens": int(r[2]),
                    "actual_cost": round(r[3], 4),
                    "call_count": int(r[4]),
                })

            for r in conn.execute(
                f"SELECT agent_name, SUM(input_tokens), SUM(output_tokens), "
                f"SUM(actual_cost_usd), COUNT(*) "
                f"FROM api_costs {where} GROUP BY agent_name ORDER BY SUM(actual_cost_usd) DESC",
                params,
            ).fetchall():
                result["by_agent"].append({
                    "agent_name": r[0],
                    "input_tokens": int(r[1]),
                    "output_tokens": int(r[2]),
                    "actual_cost": round(r[3], 4),
                    "call_count": int(r[4]),
                })

            for r in conn.execute(
                f"SELECT date(timestamp) as day, SUM(actual_cost_usd), "
                f"SUM(input_tokens) + SUM(output_tokens) "
                f"FROM api_costs {where} GROUP BY date(timestamp) ORDER BY day",
                params,
            ).fetchall():
                result["trend"].append({
                    "date": r[0],
                    "actual_cost": round(r[1], 4),
                    "tokens": int(r[2]),
                })
        finally:
            conn.close()
    except Exception:
        pass

    return result


def log_tool_call(tool_name: str) -> None:
    try:
        conn = _get_conn()
        try:
            conn.execute(
                "INSERT INTO daily_summary (date, total_fires, unique_skills, unique_projects) "
                "VALUES (date('now'), 0, 1, 1) "
                "ON CONFLICT(date) DO UPDATE SET total_fires = total_fires + 1",
            )
            conn.commit()
        finally:
            conn.close()
    except Exception:
        pass


def log_compression(
    skill_name: str,
    tokens_before: int,
    tokens_after: int,
    tier: str = "free",
) -> None:
    """Record a compression event."""
    try:
        conn = _get_conn()
        try:
            conn.execute(
                "INSERT INTO compression_stats (skill_name, tokens_before, tokens_after, tier) "
                "VALUES (?, ?, ?, ?)",
                (skill_name, tokens_before, tokens_after, tier),
            )
            conn.commit()
        finally:
            conn.close()
    except Exception as exc:
        print(f"[memstack-stats] log_compression failed: {exc}", file=sys.stderr)


def get_compression_stats() -> dict:
    """Return aggregate compression stats for dashboard."""
    try:
        conn = _get_conn()
        try:
            row = conn.execute(
                "SELECT COUNT(*), COALESCE(SUM(tokens_before), 0), "
                "COALESCE(SUM(tokens_after), 0) FROM compression_stats"
            ).fetchone()
            total_events = row[0]
            total_before = row[1]
            total_after = row[2]
            total_saved = total_before - total_after
            ratio = round(total_saved / total_before * 100, 1) if total_before > 0 else 0.0

            # Per-skill breakdown (top 10)
            per_skill = conn.execute(
                "SELECT skill_name, COUNT(*), SUM(tokens_before), SUM(tokens_after) "
                "FROM compression_stats GROUP BY skill_name "
                "ORDER BY SUM(tokens_before) - SUM(tokens_after) DESC LIMIT 10"
            ).fetchall()

            return {
                "total_compressions": total_events,
                "total_tokens_before": total_before,
                "total_tokens_after": total_after,
                "total_tokens_saved": total_saved,
                "avg_compression_pct": ratio,
                "top_skills": [
                    {
                        "name": r[0],
                        "compressions": r[1],
                        "tokens_saved": r[2] - r[3],
                        "avg_pct": round((r[2] - r[3]) / r[2] * 100, 1) if r[2] > 0 else 0,
                    }
                    for r in per_skill
                ],
            }
        finally:
            conn.close()
    except Exception as exc:
        print(f"[memstack-stats] get_compression_stats failed: {exc}", file=sys.stderr)
        return {"total_compressions": 0, "total_tokens_saved": 0}


def get_dashboard_data() -> dict:
    """Return a dict of dashboard metrics. Returns sensible defaults if no data exists."""
    defaults = {
        "total_fires": 0,
        "unique_skills_used": 0,
        "total_sessions": 0,
        "fires_today": 0,
        "top_skills": [],
        "category_breakdown": [],
        "daily_trend": [],
        "project_breakdown": [],
        "top_projects": [],
        "recent_projects": [],
        "context_saved_estimate": 0,
        "dollar_savings": 0.0,
        "most_active_project": None,
    }
    try:
        if not DB_PATH.exists():
            return defaults

        conn = _get_conn()
        try:
            today = datetime.now().strftime("%Y-%m-%d")

            # All-time totals
            total_fires = conn.execute("SELECT COUNT(*) FROM skill_fires").fetchone()[0]
            unique_skills = conn.execute(
                "SELECT COUNT(DISTINCT skill_name) FROM skill_fires"
            ).fetchone()[0]
            total_sessions = conn.execute(
                "SELECT COUNT(DISTINCT date(timestamp)) FROM skill_fires"
            ).fetchone()[0]

            # Today
            fires_today = conn.execute(
                "SELECT COUNT(*) FROM skill_fires WHERE date(timestamp) = ?",
                (today,),
            ).fetchone()[0]

            # Top skills — last 7 days
            seven_days_ago = (datetime.now() - timedelta(days=7)).strftime("%Y-%m-%d")
            top_skills = conn.execute(
                """
                SELECT skill_name, COUNT(*) as cnt
                FROM skill_fires WHERE date(timestamp) >= ?
                GROUP BY skill_name ORDER BY cnt DESC LIMIT 10
                """,
                (seven_days_ago,),
            ).fetchall()

            # Category breakdown — last 7 days
            category_breakdown = conn.execute(
                """
                SELECT COALESCE(category, 'uncategorized') as cat, COUNT(*) as cnt
                FROM skill_fires WHERE date(timestamp) >= ?
                GROUP BY cat ORDER BY cnt DESC
                """,
                (seven_days_ago,),
            ).fetchall()

            # Daily trend — last 14 days (include zero-count days)
            fourteen_days_ago = datetime.now() - timedelta(days=13)
            daily_counts = dict(
                conn.execute(
                    """
                    SELECT date(timestamp), COUNT(*)
                    FROM skill_fires WHERE date(timestamp) >= ?
                    GROUP BY date(timestamp)
                    """,
                    (fourteen_days_ago.strftime("%Y-%m-%d"),),
                ).fetchall()
            )
            daily_trend = []
            for i in range(14):
                d = (fourteen_days_ago + timedelta(days=i)).strftime("%Y-%m-%d")
                daily_trend.append({"date": d, "count": daily_counts.get(d, 0)})

            # Project breakdown — all time, top 10
            project_breakdown = conn.execute(
                """
                SELECT COALESCE(project, 'unknown') as proj, COUNT(*) as cnt
                FROM skill_fires
                GROUP BY proj ORDER BY cnt DESC LIMIT 10
                """
            ).fetchall()

            # Most active project this week
            most_active_project = conn.execute(
                """
                SELECT COALESCE(project, 'unknown') as proj, COUNT(*) as cnt
                FROM skill_fires WHERE date(timestamp) >= ?
                GROUP BY proj ORDER BY cnt DESC LIMIT 1
                """,
                (seven_days_ago,),
            ).fetchone()

            # Top projects (last 7 days) — used by overview "Most Active Project"
            top_projects_rows = conn.execute(
                """
                SELECT COALESCE(project, 'unknown') as proj, COUNT(*) as cnt
                FROM skill_fires WHERE date(timestamp) >= ?
                GROUP BY proj ORDER BY cnt DESC LIMIT 10
                """,
                (seven_days_ago,),
            ).fetchall()

            # Recent projects — last 5 distinct projects ordered by most recent fire
            recent_projects_rows = conn.execute(
                """
                SELECT COALESCE(project, 'unknown') as proj, COUNT(*) as cnt,
                       MAX(timestamp) as last_active
                FROM skill_fires
                GROUP BY proj ORDER BY last_active DESC LIMIT 5
                """
            ).fetchall()

            tokens_saved = total_fires * 1700
            dollar_savings = round((tokens_saved / 1_000_000) * 15, 2)

            return {
                "total_fires": total_fires,
                "unique_skills_used": unique_skills,
                "total_sessions": total_sessions,
                "fires_today": fires_today,
                "top_skills": [{"name": r[0], "count": r[1]} for r in top_skills],
                "category_breakdown": [
                    {"category": r[0], "count": r[1]} for r in category_breakdown
                ],
                "daily_trend": daily_trend,
                "project_breakdown": [
                    {"project": r[0], "count": r[1]} for r in project_breakdown
                ],
                "top_projects": [
                    {"project": r[0], "count": r[1]} for r in top_projects_rows
                ],
                "recent_projects": [
                    {"project": r[0], "count": r[1], "last_active": r[2]} for r in recent_projects_rows
                ],
                "context_saved_estimate": tokens_saved,
                "dollar_savings": dollar_savings,
                "most_active_project": {
                    "name": most_active_project[0],
                    "fires": most_active_project[1],
                } if most_active_project else None,
            }
        finally:
            conn.close()
    except Exception as exc:
        print(f"[memstack-stats] get_dashboard_data failed: {exc}", file=sys.stderr)
        return defaults


def get_project_details() -> list[dict]:
    """Return per-project stats: total fires, last active, top 3 skills."""
    try:
        if not DB_PATH.exists():
            return []
        conn = _get_conn()
        try:
            rows = conn.execute(
                """
                SELECT COALESCE(project, 'unknown') as proj,
                       COUNT(*) as cnt,
                       MAX(timestamp) as last_active
                FROM skill_fires
                GROUP BY proj ORDER BY cnt DESC
                """
            ).fetchall()
            projects = []
            for proj_name, cnt, last_active in rows:
                top_skills = conn.execute(
                    """
                    SELECT skill_name, COUNT(*) as c
                    FROM skill_fires WHERE COALESCE(project, 'unknown') = ?
                    AND skill_name NOT LIKE '@_%' ESCAPE '@'
                    GROUP BY skill_name ORDER BY c DESC LIMIT 3
                    """,
                    (proj_name,),
                ).fetchall()
                projects.append({
                    "name": proj_name,
                    "total_fires": cnt,
                    "last_active": last_active,
                    "top_skills": [{"name": s[0], "count": s[1]} for s in top_skills],
                })
            return projects
        finally:
            conn.close()
    except Exception as exc:
        print(f"[memstack-stats] get_project_details failed: {exc}", file=sys.stderr)
        return []


def backfill_categories(category_map: dict[str, str]) -> int:
    """Backfill NULL categories in existing skill_fires using a slug->category map.

    Handles emoji-prefixed display names (e.g. "🛡️ OWASP Top 10") by stripping
    non-ASCII chars before converting to slug form for matching.

    Returns the number of rows updated.
    """
    import re

    def _to_slug(name: str) -> str:
        """Convert a display name to a slug for category map lookup."""
        # Strip emoji and non-ASCII characters
        clean = re.sub(r'[^\x00-\x7F]+', '', name).strip()
        # Convert to lowercase slug
        return clean.lower().replace(" ", "-").replace("_", "-")

    updated = 0
    try:
        conn = _get_conn()
        try:
            rows = conn.execute(
                "SELECT DISTINCT skill_name FROM skill_fires WHERE category IS NULL"
            ).fetchall()

            for (skill_name,) in rows:
                slug = _to_slug(skill_name)
                # For internal names like __list__, use the raw name as slug
                if skill_name.startswith("__"):
                    slug = skill_name
                category = category_map.get(slug)

                if not category:
                    # Try substring matching against map keys
                    for map_slug, map_cat in category_map.items():
                        if map_slug in slug or slug in map_slug:
                            category = map_cat
                            break

                if category:
                    conn.execute(
                        "UPDATE skill_fires SET category = ? WHERE skill_name = ? AND category IS NULL",
                        (category, skill_name),
                    )
                    updated += 1

            conn.commit()
        finally:
            conn.close()
    except Exception as exc:
        print(f"[memstack-stats] backfill_categories failed: {exc}", file=sys.stderr)
    return updated


def get_recent_activity(limit: int = 10) -> list[dict]:
    """Return the most recent skill fires for the activity feed."""
    try:
        conn = _get_conn()
        try:
            rows = conn.execute(
                "SELECT timestamp, skill_name, category, project "
                "FROM skill_fires "
                "WHERE skill_name NOT LIKE '@_%' ESCAPE '@' "
                "ORDER BY timestamp DESC LIMIT ?",
                (limit,),
            ).fetchall()
            return [
                {
                    "timestamp": row[0],
                    "skill_name": row[1],
                    "category": row[2],
                    "project": row[3],
                }
                for row in rows
            ]
        finally:
            conn.close()
    except Exception as exc:
        print(f"[memstack-stats] get_recent_activity failed: {exc}", file=sys.stderr)
        return []


def get_skill_fire_counts() -> dict[str, int]:
    """Return {skill_name: fire_count} for all skills (excluding internal names)."""
    try:
        conn = _get_conn()
        try:
            rows = conn.execute(
                "SELECT skill_name, COUNT(*) FROM skill_fires "
                "WHERE skill_name NOT LIKE '@_%' ESCAPE '@' "
                "GROUP BY skill_name"
            ).fetchall()
            return {row[0]: row[1] for row in rows}
        finally:
            conn.close()
    except Exception as exc:
        print(f"[memstack-stats] get_skill_fire_counts failed: {exc}", file=sys.stderr)
        return {}


OPUS_INPUT_COST = 5.0    # $/M tokens (Opus 4.x pricing)
OPUS_OUTPUT_COST = 25.0  # $/M tokens (Opus 4.x pricing)
SONNET_INPUT_COST = 3.0  # $/M tokens
SONNET_OUTPUT_COST = 15.0  # $/M tokens
AVG_OUTPUT_RATIO = 0.3   # assume ~30% of tokens are output

_SESSIONS_DIR = Path.home() / ".memstack" / "agent-runner" / "sessions"

_TASK_BOILERPLATE = re.compile(
    r'^(working\s+directory:|branch:|read\s+all\s+files\s+before\s+modifying\.?)',
    re.IGNORECASE
)


def _clean_task_description(task: str) -> str:
    """Strip Working directory/Branch boilerplate, returning the user's task description."""
    lines = task.splitlines()
    start = 0
    for i, line in enumerate(lines):
        stripped = line.strip()
        if not stripped or _TASK_BOILERPLATE.match(stripped):
            start = i + 1
        else:
            break
    return "\n".join(lines[start:]).strip()


def get_recent_agent_sessions(limit: int = 10) -> list[dict]:
    """Scan agent-runner session directories for recent sessions."""
    import json as _json

    if not _SESSIONS_DIR.is_dir():
        return []

    entries: list[tuple[float, dict]] = []
    for d in _SESSIONS_DIR.iterdir():
        if not d.is_dir():
            continue
        meta_file = d / "session_meta.json"
        if meta_file.exists():
            try:
                meta = _json.loads(meta_file.read_text(encoding="utf-8"))
                mtime = meta_file.stat().st_mtime
                entries.append((mtime, {
                    "session_id": meta.get("session_id", d.name),
                    "task": (_clean_task_description(meta.get("task_description") or meta.get("task") or ""))[:60],
                    "status": meta.get("status", "unknown"),
                    "started_at": meta.get("started_at", ""),
                    "iteration": meta.get("iteration", 0),
                }))
                continue
            except (OSError, ValueError):
                pass
        msg_file = d / "messages.jsonl"
        if msg_file.exists():
            try:
                mtime = msg_file.stat().st_mtime
                lines = msg_file.read_text(encoding="utf-8").strip().splitlines()
                first = _json.loads(lines[0]) if lines else {}
                started = first.get("timestamp", "")
                task_content = first.get("content", "")
                task_marker = "Task:\n"
                idx = task_content.find(task_marker)
                task_snippet = task_content[idx + len(task_marker):][:60].strip() if idx >= 0 else d.name
                last = _json.loads(lines[-1]) if lines else {}
                last_content = last.get("content", "")
                if "APPROVED" in last_content.upper():
                    status = "completed"
                elif "REJECTED" in last_content.upper() or "error" in last_content.lower():
                    status = "error"
                else:
                    status = "completed"
                entries.append((mtime, {
                    "session_id": d.name,
                    "task": task_snippet,
                    "status": status,
                    "started_at": started,
                    "iteration": max(1, len([l for l in lines if '"to": "builder"' in l or '"to":"builder"' in l])),
                }))
            except (OSError, ValueError):
                pass

    entries.sort(key=lambda x: x[0], reverse=True)
    return [e[1] for e in entries[:limit]]


def get_burn_report_data(period: str = "daily", range_filter: str = "all") -> dict:
    """Return token burn analytics for the dashboard.

    Pulls from stats.db (compression_stats, skill_fires) and memory.db (temporal_events).

    *range_filter* controls the time window for both summary cards and chart:
      daily   = today since midnight
      weekly  = since Monday of this week
      monthly = since the 1st of this month
      all     = all time (365-day lookback for chart)
    """
    from . import memory_db

    defaults = {
        "period": period,
        "range": range_filter,
        "total_tokens": 0,
        "total_cost": 0.0,
        "sessions": [],
        "trend": [],
        "per_skill": [],
    }

    # ── Determine date range based on range_filter ──
    now = datetime.now()
    today = now.replace(hour=0, minute=0, second=0, microsecond=0)
    if range_filter == "daily":
        since_dt = today
        group_fmt = "%Y-%m-%d %H:00"
    elif range_filter == "weekly":
        since_dt = today - timedelta(days=today.weekday())  # Monday
        group_fmt = "%Y-%m-%d"
    elif range_filter == "monthly":
        since_dt = today.replace(day=1)
        group_fmt = "%Y-%m-%d"
    else:
        since_dt = now - timedelta(days=365)
        group_fmt = "%Y-%m-%d"

    since = since_dt.strftime("%Y-%m-%d %H:%M:%S")

    # ── 1. Session-level token usage from memory.db ──
    sessions: list[dict] = []
    try:
        mem_conn = sqlite3.connect(str(memory_db.DB_PATH), timeout=5)
        mem_conn.row_factory = sqlite3.Row
        try:
            rows = mem_conn.execute(
                "SELECT session_id, "
                "SUM(tokens_used) as total_tokens, "
                "MIN(timestamp) as first_ts, "
                "MAX(timestamp) as last_ts, "
                "COUNT(*) as event_count "
                "FROM temporal_events "
                "WHERE timestamp >= ? AND tokens_used > 0 "
                "GROUP BY session_id ORDER BY first_ts DESC",
                (since,),
            ).fetchall()
            for r in rows:
                tokens = r["total_tokens"] or 0
                input_tokens = int(tokens * (1 - AVG_OUTPUT_RATIO))
                output_tokens = int(tokens * AVG_OUTPUT_RATIO)
                cost = (input_tokens / 1_000_000 * OPUS_INPUT_COST
                        + output_tokens / 1_000_000 * OPUS_OUTPUT_COST)
                sessions.append({
                    "session_id": r["session_id"][:12],
                    "tokens": tokens,
                    "cost": round(cost, 4),
                    "started": r["first_ts"],
                    "ended": r["last_ts"],
                    "events": r["event_count"],
                })
        finally:
            mem_conn.close()
    except Exception:
        pass

    # ── 2. Time-series trend from both DBs ──
    trend_buckets: dict[str, int] = {}
    # From compression_stats
    try:
        conn = _get_conn()
        try:
            rows = conn.execute(
                "SELECT timestamp, tokens_before FROM compression_stats "
                "WHERE timestamp >= ?",
                (since,),
            ).fetchall()
            for ts, tokens in rows:
                try:
                    dt = datetime.strptime(ts[:19], "%Y-%m-%d %H:%M:%S")
                    key = dt.strftime(group_fmt)
                    trend_buckets[key] = trend_buckets.get(key, 0) + tokens
                except (ValueError, TypeError):
                    pass
        finally:
            conn.close()
    except Exception:
        pass

    # From temporal_events
    try:
        mem_conn = sqlite3.connect(str(memory_db.DB_PATH), timeout=5)
        try:
            rows = mem_conn.execute(
                "SELECT timestamp, tokens_used FROM temporal_events "
                "WHERE timestamp >= ? AND tokens_used > 0",
                (since,),
            ).fetchall()
            for ts, tokens in rows:
                try:
                    dt = datetime.strptime(ts[:19], "%Y-%m-%d %H:%M:%S")
                    key = dt.strftime(group_fmt)
                    trend_buckets[key] = trend_buckets.get(key, 0) + tokens
                except (ValueError, TypeError):
                    pass
        finally:
            mem_conn.close()
    except Exception:
        pass

    # From skill_fires (input_tokens + output_tokens per day)
    try:
        conn = _get_conn()
        try:
            rows = conn.execute(
                "SELECT date(timestamp) as day, SUM(input_tokens) + SUM(output_tokens) as tokens "
                "FROM skill_fires WHERE input_tokens > 0 AND timestamp >= ? "
                "GROUP BY date(timestamp) ORDER BY day",
                (since,),
            ).fetchall()
            for day, tokens in rows:
                if day and tokens:
                    trend_buckets[day] = trend_buckets.get(day, 0) + tokens
        finally:
            conn.close()
    except Exception:
        pass

    trend = [{"label": k, "tokens": v} for k, v in sorted(trend_buckets.items())]

    # ── 3. Per-skill token breakdown from compression_stats ──
    per_skill: list[dict] = []
    try:
        conn = _get_conn()
        try:
            rows = conn.execute(
                "SELECT skill_name, COUNT(*) as fires, "
                "SUM(tokens_before) as total_in, "
                "SUM(tokens_after) as total_out, "
                "SUM(tokens_before) - SUM(tokens_after) as saved "
                "FROM compression_stats WHERE timestamp >= ? "
                "GROUP BY skill_name ORDER BY total_in DESC LIMIT 20",
                (since,),
            ).fetchall()
            for r in rows:
                total_in = r[2] or 0
                input_t = int(total_in * (1 - AVG_OUTPUT_RATIO))
                output_t = int(total_in * AVG_OUTPUT_RATIO)
                cost = (input_t / 1_000_000 * OPUS_INPUT_COST
                        + output_t / 1_000_000 * OPUS_OUTPUT_COST)
                per_skill.append({
                    "name": r[0],
                    "fires": r[1],
                    "tokens": total_in,
                    "saved": r[4] or 0,
                    "cost": round(cost, 4),
                })
        finally:
            conn.close()
    except Exception:
        pass

    # Also add skill_fires tokens for skills not in compression_stats
    try:
        conn = _get_conn()
        try:
            existing_skills = {s["name"] for s in per_skill}
            rows = conn.execute(
                "SELECT skill_name, COUNT(*) as fires, "
                "SUM(input_tokens) as sum_in, SUM(output_tokens) as sum_out, "
                "SUM(cost_usd) as sum_cost "
                "FROM skill_fires WHERE timestamp >= ? "
                "GROUP BY skill_name ORDER BY fires DESC LIMIT 20",
                (since,),
            ).fetchall()
            for r in rows:
                name, fires, sum_in, sum_out, sum_cost = r[0], r[1], r[2] or 0, r[3] or 0, r[4] or 0.0
                if name not in existing_skills:
                    if sum_in > 0 or sum_out > 0:
                        total_t = sum_in + sum_out
                        cost = sum_cost if sum_cost > 0 else (
                            sum_in / 1_000_000 * OPUS_INPUT_COST
                            + sum_out / 1_000_000 * OPUS_OUTPUT_COST
                        )
                    else:
                        total_t = fires * 1700
                        input_t = int(total_t * (1 - AVG_OUTPUT_RATIO))
                        output_t = int(total_t * AVG_OUTPUT_RATIO)
                        cost = (input_t / 1_000_000 * OPUS_INPUT_COST
                                + output_t / 1_000_000 * OPUS_OUTPUT_COST)
                    per_skill.append({
                        "name": name,
                        "fires": fires,
                        "tokens": total_t,
                        "saved": 0,
                        "cost": round(cost, 4),
                    })
        finally:
            conn.close()
    except Exception:
        pass

    per_skill.sort(key=lambda x: x["tokens"], reverse=True)

    # ── Summary cards: derive from skill_fires (real data) ──
    total_tokens = 0
    total_cost = 0.0
    session_count = 0
    try:
        conn = _get_conn()
        try:
            row = conn.execute(
                "SELECT SUM(input_tokens), SUM(output_tokens), SUM(cost_usd), "
                "COUNT(DISTINCT session_id) "
                "FROM skill_fires WHERE timestamp >= ?",
                (since,),
            ).fetchone()
            sf_in, sf_out, sf_cost = row[0] or 0, row[1] or 0, row[2] or 0.0
            session_count = row[3] or 0

            if sf_in > 0 or sf_out > 0:
                total_tokens = sf_in + sf_out
                total_cost = round(sf_cost, 4) if sf_cost > 0 else round(
                    sf_in / 1_000_000 * OPUS_INPUT_COST
                    + sf_out / 1_000_000 * OPUS_OUTPUT_COST, 4
                )
            else:
                total_tokens = sum(s["tokens"] for s in sessions)
                input_t = int(total_tokens * (1 - AVG_OUTPUT_RATIO))
                output_t = int(total_tokens * AVG_OUTPUT_RATIO)
                total_cost = round(
                    input_t / 1_000_000 * OPUS_INPUT_COST
                    + output_t / 1_000_000 * OPUS_OUTPUT_COST, 4
                )
        finally:
            conn.close()
    except Exception:
        total_tokens = sum(s["tokens"] for s in sessions)
        input_t = int(total_tokens * (1 - AVG_OUTPUT_RATIO))
        output_t = int(total_tokens * AVG_OUTPUT_RATIO)
        total_cost = round(
            input_t / 1_000_000 * OPUS_INPUT_COST
            + output_t / 1_000_000 * OPUS_OUTPUT_COST, 4
        )

    if session_count == 0:
        session_count = len(sessions)

    recent_sessions = get_recent_agent_sessions(10)
    if range_filter != "all":
        filtered = []
        for s in recent_sessions:
            started = s.get("started_at", "")
            if started and started >= since:
                filtered.append(s)
        recent_sessions = filtered

    # ── Compression savings (for headroom-style cards) ──
    tokens_saved = 0
    savings_pct = 0.0
    cost_saved = 0.0
    compress_count = 0
    try:
        conn = _get_conn()
        try:
            row = conn.execute(
                "SELECT SUM(tokens_before), SUM(tokens_after), COUNT(*) "
                "FROM compression_stats WHERE timestamp >= ?",
                (since,),
            ).fetchone()
            t_before, t_after = row[0] or 0, row[1] or 0
            compress_count = row[2] or 0
            tokens_saved = t_before - t_after
            if t_before > 0:
                savings_pct = round(tokens_saved / t_before * 100, 2)
            cost_saved = round(tokens_saved / 1_000_000 * OPUS_INPUT_COST, 4)
        finally:
            conn.close()
    except Exception:
        pass

    # ── Model-level breakdown (Opus = manager+reviewer, Sonnet = builder) ──
    opus_input = 0
    opus_output = 0
    sonnet_input = 0
    sonnet_output = 0
    try:
        conn = _get_conn()
        try:
            row = conn.execute(
                "SELECT SUM(input_tokens), SUM(output_tokens) FROM skill_fires "
                "WHERE skill_name IN ('agent:manager', 'agent:reviewer') AND timestamp >= ?",
                (since,),
            ).fetchone()
            opus_input = int(row[0] or 0)
            opus_output = int(row[1] or 0)
            row2 = conn.execute(
                "SELECT SUM(input_tokens), SUM(output_tokens) FROM skill_fires "
                "WHERE skill_name = 'agent:builder' AND timestamp >= ?",
                (since,),
            ).fetchone()
            sonnet_input = int(row2[0] or 0)
            sonnet_output = int(row2[1] or 0)
        finally:
            conn.close()
    except Exception:
        pass

    opus_tokens = opus_input + opus_output
    sonnet_tokens = sonnet_input + sonnet_output
    opus_cost = round(opus_input / 1_000_000 * OPUS_INPUT_COST + opus_output / 1_000_000 * OPUS_OUTPUT_COST, 4)
    sonnet_cost = round(sonnet_input / 1_000_000 * SONNET_INPUT_COST + sonnet_output / 1_000_000 * SONNET_OUTPUT_COST, 4)

    return {
        "period": period,
        "range": range_filter,
        "total_tokens": total_tokens,
        "total_cost": total_cost,
        "session_count": session_count,
        "tokens_saved": tokens_saved,
        "savings_pct": savings_pct,
        "cost_saved": cost_saved,
        "compress_count": compress_count,
        "sessions": sessions[:50],
        "trend": trend,
        "per_skill": per_skill[:20],
        "recent_sessions": recent_sessions,
        "opus_tokens": opus_tokens,
        "opus_cost": opus_cost,
        "sonnet_tokens": sonnet_tokens,
        "sonnet_cost": sonnet_cost,
    }


def reset_burn_stats() -> dict:
    """Delete all rows from burn-report-related tables in stats.db."""
    try:
        conn = _get_conn()
        try:
            for table in ("skill_fires", "compression_stats", "daily_summary"):
                conn.execute(f"DELETE FROM {table}")
            conn.commit()
        finally:
            conn.close()
        return {"success": True}
    except Exception as exc:
        return {"success": False, "error": str(exc)}
