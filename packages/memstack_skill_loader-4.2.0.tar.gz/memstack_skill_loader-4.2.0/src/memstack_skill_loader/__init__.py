"""MemStack Skill Loader — MCP server for semantic skill search."""

__version__ = "4.2.0"
