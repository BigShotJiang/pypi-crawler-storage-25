# MemStack Memory - 5-layer persistent memory system
"""Persistent memory layer — SQLite-backed 5-table memory system for MemStack."""

import json
import os
import sqlite3
import sys
from pathlib import Path

DB_PATH = Path.home() / ".memstack" / "memory.db"
SCHEMA_VERSION = 1


def _get_conn() -> sqlite3.Connection:
    DB_PATH.parent.mkdir(parents=True, exist_ok=True)
    conn = sqlite3.connect(str(DB_PATH), timeout=5)
    conn.row_factory = sqlite3.Row
    conn.execute("PRAGMA journal_mode=WAL")
    _init_tables(conn)
    return conn


def _init_tables(conn: sqlite3.Connection) -> None:
    cur = conn.cursor()

    cur.execute(
        "CREATE TABLE IF NOT EXISTS schema_version (version INTEGER PRIMARY KEY)"
    )
    cur.execute("INSERT OR IGNORE INTO schema_version VALUES (?)", (SCHEMA_VERSION,))

    cur.execute(
        """
        CREATE TABLE IF NOT EXISTS temporal_events (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            project_dir TEXT NOT NULL,
            session_id TEXT NOT NULL,
            event_type TEXT NOT NULL,
            timestamp TEXT NOT NULL DEFAULT (datetime('now')),
            summary TEXT NOT NULL,
            details TEXT,
            tokens_used INTEGER DEFAULT 0
        )
        """
    )
    cur.execute(
        "CREATE INDEX IF NOT EXISTS idx_temporal_project ON temporal_events(project_dir)"
    )
    cur.execute(
        "CREATE INDEX IF NOT EXISTS idx_temporal_session ON temporal_events(session_id)"
    )
    cur.execute(
        "CREATE INDEX IF NOT EXISTS idx_temporal_type ON temporal_events(event_type)"
    )

    cur.execute(
        """
        CREATE TABLE IF NOT EXISTS session_summaries (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            project_dir TEXT NOT NULL,
            session_id TEXT NOT NULL UNIQUE,
            started_at TEXT NOT NULL,
            ended_at TEXT,
            summary TEXT,
            decisions TEXT,
            files_changed TEXT,
            next_actions TEXT,
            tokens_total INTEGER DEFAULT 0
        )
        """
    )
    cur.execute(
        "CREATE INDEX IF NOT EXISTS idx_summaries_project ON session_summaries(project_dir)"
    )

    cur.execute(
        """
        CREATE TABLE IF NOT EXISTS procedural_memory (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            project_dir TEXT,
            category TEXT NOT NULL,
            title TEXT NOT NULL,
            content TEXT NOT NULL,
            stack_tags TEXT,
            confidence REAL DEFAULT 1.0,
            times_reinforced INTEGER DEFAULT 0,
            created_at TEXT NOT NULL DEFAULT (datetime('now')),
            last_used TEXT
        )
        """
    )
    cur.execute(
        "CREATE INDEX IF NOT EXISTS idx_procedural_project ON procedural_memory(project_dir)"
    )
    cur.execute(
        "CREATE INDEX IF NOT EXISTS idx_procedural_category ON procedural_memory(category)"
    )

    cur.execute(
        """
        CREATE TABLE IF NOT EXISTS context_facts (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            project_dir TEXT NOT NULL,
            fact_type TEXT NOT NULL,
            key TEXT NOT NULL,
            value TEXT NOT NULL,
            source TEXT,
            updated_at TEXT NOT NULL DEFAULT (datetime('now'))
        )
        """
    )
    cur.execute(
        "CREATE UNIQUE INDEX IF NOT EXISTS idx_facts_unique "
        "ON context_facts(project_dir, fact_type, key)"
    )

    cur.execute(
        """
        CREATE VIRTUAL TABLE IF NOT EXISTS memory_fts USING fts5(
            content,
            source_table,
            source_id,
            project_dir
        )
        """
    )

    conn.commit()


def init_memory_db() -> None:
    """Create the database and all tables. Safe to call repeatedly."""
    conn = _get_conn()
    conn.close()


def _index_fts(conn: sqlite3.Connection, source_table: str, source_id: int,
               content: str, project_dir: str) -> None:
    try:
        conn.execute(
            "INSERT INTO memory_fts (content, source_table, source_id, project_dir) "
            "VALUES (?, ?, ?, ?)",
            (content, source_table, str(source_id), project_dir),
        )
    except Exception:
        pass


# ---------------------------------------------------------------------------
# Insert functions
# ---------------------------------------------------------------------------

def insert_event(
    project_dir: str,
    session_id: str,
    event_type: str,
    summary: str,
    details: dict | list | None = None,
    tokens_used: int = 0,
) -> int | None:
    try:
        conn = _get_conn()
        try:
            details_json = json.dumps(details) if details is not None else None
            cur = conn.execute(
                "INSERT INTO temporal_events "
                "(project_dir, session_id, event_type, summary, details, tokens_used) "
                "VALUES (?, ?, ?, ?, ?, ?)",
                (project_dir, session_id, event_type, summary, details_json, tokens_used),
            )
            row_id = cur.lastrowid
            _index_fts(conn, "temporal_events", row_id, summary, project_dir)
            conn.commit()
            return row_id
        finally:
            conn.close()
    except Exception as exc:
        print(f"[memstack-memory] insert_event failed: {exc}", file=sys.stderr)
        return None


def insert_summary(
    project_dir: str,
    session_id: str,
    started_at: str,
    ended_at: str | None = None,
    summary: str | None = None,
    decisions: list | None = None,
    files_changed: list | None = None,
    next_actions: list | None = None,
    tokens_total: int = 0,
) -> int | None:
    try:
        conn = _get_conn()
        try:
            cur = conn.execute(
                "INSERT OR REPLACE INTO session_summaries "
                "(project_dir, session_id, started_at, ended_at, summary, "
                "decisions, files_changed, next_actions, tokens_total) "
                "VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)",
                (
                    project_dir,
                    session_id,
                    started_at,
                    ended_at,
                    summary,
                    json.dumps(decisions) if decisions else None,
                    json.dumps(files_changed) if files_changed else None,
                    json.dumps(next_actions) if next_actions else None,
                    tokens_total,
                ),
            )
            row_id = cur.lastrowid
            if summary:
                _index_fts(conn, "session_summaries", row_id, summary, project_dir)
            conn.commit()
            return row_id
        finally:
            conn.close()
    except Exception as exc:
        print(f"[memstack-memory] insert_summary failed: {exc}", file=sys.stderr)
        return None


def insert_lesson(
    title: str,
    content: str,
    category: str,
    project_dir: str | None = None,
    global_: bool = False,
    stack_tags: list[str] | None = None,
) -> int | None:
    try:
        conn = _get_conn()
        try:
            pdir = None if global_ else project_dir
            cur = conn.execute(
                "INSERT INTO procedural_memory "
                "(project_dir, category, title, content, stack_tags) "
                "VALUES (?, ?, ?, ?, ?)",
                (
                    pdir,
                    category,
                    title,
                    content,
                    json.dumps(stack_tags) if stack_tags else None,
                ),
            )
            row_id = cur.lastrowid
            _index_fts(conn, "procedural_memory", row_id,
                        f"{title} {content}", pdir or "")
            conn.commit()
            return row_id
        finally:
            conn.close()
    except Exception as exc:
        print(f"[memstack-memory] insert_lesson failed: {exc}", file=sys.stderr)
        return None


def insert_fact(
    project_dir: str,
    fact_type: str,
    key: str,
    value: str,
    source: str | None = None,
) -> int | None:
    try:
        conn = _get_conn()
        try:
            # Delete old FTS entry if updating
            old = conn.execute(
                "SELECT id FROM context_facts "
                "WHERE project_dir=? AND fact_type=? AND key=?",
                (project_dir, fact_type, key),
            ).fetchone()
            if old:
                conn.execute(
                    "DELETE FROM memory_fts "
                    "WHERE source_table='context_facts' AND source_id=?",
                    (str(old["id"]),),
                )

            cur = conn.execute(
                "INSERT OR REPLACE INTO context_facts "
                "(project_dir, fact_type, key, value, source, updated_at) "
                "VALUES (?, ?, ?, ?, ?, datetime('now'))",
                (project_dir, fact_type, key, value, source),
            )
            row_id = cur.lastrowid
            _index_fts(conn, "context_facts", row_id,
                        f"{key} {value}", project_dir)
            conn.commit()
            return row_id
        finally:
            conn.close()
    except Exception as exc:
        print(f"[memstack-memory] insert_fact failed: {exc}", file=sys.stderr)
        return None


# ---------------------------------------------------------------------------
# Query functions
# ---------------------------------------------------------------------------

def search_memory(
    query: str, project_dir: str | None = None, limit: int = 10
) -> list[dict]:
    if limit > 500:
        limit = 500
    query = f'"{query}"'
    try:
        conn = _get_conn()
        try:
            sql = (
                "SELECT content, source_table, source_id, project_dir, "
                "rank FROM memory_fts WHERE memory_fts MATCH ?"
            )
            params: list = [query]
            if project_dir:
                sql += " AND project_dir = ?"
                params.append(project_dir)
            sql += " ORDER BY rank LIMIT ?"
            params.append(limit)
            rows = conn.execute(sql, params).fetchall()
            return [
                {
                    "content": r["content"],
                    "source_table": r["source_table"],
                    "source_id": r["source_id"],
                    "project_dir": r["project_dir"],
                    "rank": r["rank"],
                }
                for r in rows
            ]
        finally:
            conn.close()
    except Exception as exc:
        print(f"[memstack-memory] search_memory failed: {exc}", file=sys.stderr)
        return []


def get_recent_events(project_dir: str, limit: int = 20) -> list[dict]:
    if limit > 500:
        limit = 500
    try:
        conn = _get_conn()
        try:
            rows = conn.execute(
                "SELECT * FROM temporal_events "
                "WHERE project_dir=? ORDER BY timestamp DESC LIMIT ?",
                (project_dir, limit),
            ).fetchall()
            results = []
            for r in rows:
                d = dict(r)
                if d.get("details"):
                    try:
                        d["details"] = json.loads(d["details"])
                    except (json.JSONDecodeError, TypeError):
                        pass
                results.append(d)
            return results
        finally:
            conn.close()
    except Exception as exc:
        print(f"[memstack-memory] get_recent_events failed: {exc}", file=sys.stderr)
        return []


def get_session_summaries(project_dir: str, limit: int = 50) -> list[dict]:
    if limit > 500:
        limit = 500
    try:
        conn = _get_conn()
        try:
            rows = conn.execute(
                "SELECT * FROM session_summaries "
                "WHERE project_dir=? ORDER BY ended_at DESC LIMIT ?",
                (project_dir, limit),
            ).fetchall()
            return [dict(r) for r in rows]
        finally:
            conn.close()
    except Exception as exc:
        print(f"[memstack-memory] get_session_summaries failed: {exc}", file=sys.stderr)
        return []


def get_session_summary(session_id: str) -> dict | None:
    try:
        conn = _get_conn()
        try:
            row = conn.execute(
                "SELECT * FROM session_summaries WHERE session_id=?",
                (session_id,),
            ).fetchone()
            if not row:
                return None
            d = dict(row)
            for field in ("decisions", "files_changed", "next_actions"):
                if d.get(field):
                    try:
                        d[field] = json.loads(d[field])
                    except (json.JSONDecodeError, TypeError):
                        pass
            return d
        finally:
            conn.close()
    except Exception as exc:
        print(f"[memstack-memory] get_session_summary failed: {exc}", file=sys.stderr)
        return None


def get_lessons(
    project_dir: str | None = None, category: str | None = None
) -> list[dict]:
    try:
        conn = _get_conn()
        try:
            sql = "SELECT * FROM procedural_memory WHERE 1=1"
            params: list = []
            if project_dir:
                sql += " AND (project_dir=? OR project_dir IS NULL)"
                params.append(project_dir)
            if category:
                sql += " AND category=?"
                params.append(category)
            sql += " ORDER BY times_reinforced DESC, created_at DESC"
            rows = conn.execute(sql, params).fetchall()
            results = []
            for r in rows:
                d = dict(r)
                if d.get("stack_tags"):
                    try:
                        d["stack_tags"] = json.loads(d["stack_tags"])
                    except (json.JSONDecodeError, TypeError):
                        pass
                results.append(d)
            return results
        finally:
            conn.close()
    except Exception as exc:
        print(f"[memstack-memory] get_lessons failed: {exc}", file=sys.stderr)
        return []


def get_facts(project_dir: str) -> list[dict]:
    try:
        conn = _get_conn()
        try:
            rows = conn.execute(
                "SELECT * FROM context_facts WHERE project_dir=? ORDER BY fact_type, key",
                (project_dir,),
            ).fetchall()
            return [dict(r) for r in rows]
        finally:
            conn.close()
    except Exception as exc:
        print(f"[memstack-memory] get_facts failed: {exc}", file=sys.stderr)
        return []


def get_memory_stats(project_dir: str | None = None) -> dict:
    try:
        conn = _get_conn()
        try:
            result: dict = {}
            if project_dir:
                result["events"] = conn.execute(
                    "SELECT COUNT(*) FROM temporal_events WHERE project_dir=?",
                    (project_dir,),
                ).fetchone()[0]
                result["sessions"] = conn.execute(
                    "SELECT COUNT(*) FROM session_summaries WHERE project_dir=?",
                    (project_dir,),
                ).fetchone()[0]
                result["lessons"] = conn.execute(
                    "SELECT COUNT(*) FROM procedural_memory "
                    "WHERE project_dir=? OR project_dir IS NULL",
                    (project_dir,),
                ).fetchone()[0]
                result["facts"] = conn.execute(
                    "SELECT COUNT(*) FROM context_facts WHERE project_dir=?",
                    (project_dir,),
                ).fetchone()[0]
            else:
                result["events"] = conn.execute(
                    "SELECT COUNT(*) FROM temporal_events"
                ).fetchone()[0]
                result["sessions"] = conn.execute(
                    "SELECT COUNT(*) FROM session_summaries"
                ).fetchone()[0]
                result["lessons"] = conn.execute(
                    "SELECT COUNT(*) FROM procedural_memory"
                ).fetchone()[0]
                result["facts"] = conn.execute(
                    "SELECT COUNT(*) FROM context_facts"
                ).fetchone()[0]

            db_size = 0
            if DB_PATH.exists():
                db_size = DB_PATH.stat().st_size
            result["db_size_bytes"] = db_size
            result["db_size_human"] = _human_size(db_size)
            return result
        finally:
            conn.close()
    except Exception as exc:
        print(f"[memstack-memory] get_memory_stats failed: {exc}", file=sys.stderr)
        return {"events": 0, "sessions": 0, "lessons": 0, "facts": 0,
                "db_size_bytes": 0, "db_size_human": "0 B"}


def get_recent_project_dirs(limit: int = 10) -> list[str]:
    try:
        conn = _get_conn()
        try:
            rows = conn.execute(
                "SELECT project_dir, MAX(timestamp) as last_used "
                "FROM temporal_events GROUP BY project_dir "
                "ORDER BY last_used DESC LIMIT ?",
                (limit,),
            ).fetchall()
            return [row[0] for row in rows]
        finally:
            conn.close()
    except Exception:
        return []


def _human_size(nbytes: int) -> str:
    for unit in ("B", "KB", "MB", "GB"):
        if nbytes < 1024:
            return f"{nbytes:.1f} {unit}" if unit != "B" else f"{nbytes} {unit}"
        nbytes /= 1024
    return f"{nbytes:.1f} TB"
