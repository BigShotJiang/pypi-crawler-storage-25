# MemStack™ Skill Loader

**127 skills for Claude Code** — 85 free + 42 Pro exclusive. Vector-indexed so CC loads only the skill it needs, saving your context window.

## Quick Start (5 minutes)

1. **Install from PyPI:**
   ```bash
   pip install memstack-skill-loader
   ```

2. **Register with Claude Code:**
   ```bash
   claude mcp add --scope user memstack-skills -- python -m memstack_skill_loader
   ```

3. **Restart Claude Code**, then type `list skills` to verify.

4. **Activate Pro** (if purchased at [memstack.pro](https://memstack.pro)):
   ```
   activate_license(key="your-key-here", email="you@example.com")
   ```

> To override the skills path, set `MEMSTACK_SKILLS_DIR=/path/to/your/memstack/skills`.

> See [QUICKSTART.md](QUICKSTART.md) for detailed setup, [QUICK-REFERENCE.md](QUICK-REFERENCE.md) for the full skill catalog, and [TROUBLESHOOTING.md](TROUBLESHOOTING.md) if you hit issues.

## How It Works

MCP server that vector-indexes all 127 MemStack™ skills so Claude Code can call `find_skill("deploy to Railway")` and load **only** the relevant skill on demand — instead of all skills consuming context window.

- **No API keys required** — everything runs locally
- **Pro skills auto-detected** — set your license key and they appear automatically
- **Auto-reindex on start** — skills stay current without manual rebuilds

### Environment Variable Override

Set `MEMSTACK_SKILLS_DIR` to override the skills path in `config.json`:

```bash
export MEMSTACK_SKILLS_DIR=/path/to/your/memstack/skills
```

## Stack

- Python 3.12+
- [MCP SDK](https://pypi.org/project/mcp/) (stdio transport)
- [LanceDB](https://lancedb.com/) (vector storage, zero external dependencies)
- [sentence-transformers](https://www.sbert.net/) with `all-MiniLM-L6-v2` (384-dim local embeddings)

## Available Tools

### `find_skill`
Search skills by describing what you need. Returns the most relevant skill(s) with full instructions.

```
find_skill(query="deploy to Railway", top_k=3)
```

### `list_skills`
Browse the full skill catalog with names and descriptions.

```
list_skills()
```

### `get_skill`
Load a specific skill by exact name.

```
get_skill(name="railway deploy")
```

### `reindex_skills`
Rebuild the vector index after adding or modifying skills.

```
reindex_skills()
```

## Configuration

The `config.json` file controls where skills are loaded from:

```json
{
  "skill_sources": [
    {
      "type": "local",
      "path": "C:\\Projects\\memstack\\skills",
      "pattern": "**/SKILL.md",
      "label": "MemStack"
    }
  ],
  "embedding_model": "all-MiniLM-L6-v2",
  "default_top_k": 3,
  "vector_db_path": "./vectors",
  "auto_reindex_on_start": true
}
```

Pro skills are **auto-detected** when `MEMSTACK_PRO_LICENSE_KEY` is set — no need to add them to `config.json`.

Add entries to `skill_sources` to index skills from multiple directories:

```json
{
  "skill_sources": [
    {
      "type": "local",
      "path": "C:\\Projects\\memstack\\skills",
      "pattern": "**/SKILL.md",
      "label": "MemStack"
    },
    {
      "type": "local",
      "path": "/home/user/custom-skills",
      "pattern": "*.md",
      "label": "My Custom Skills"
    }
  ]
}
```

The `pattern` field controls how skills are discovered:
- `**/SKILL.md` — Subdirectory structure (e.g., `category/skill-name/SKILL.md`)
- `*.md` — Flat directory (each `.md` file is a skill)

## Release Notes

### v4.0.0 (May 2026)

- Dashboard: 6-page localhost dashboard (Overview, Skills Manager, Burn Report, Memory Browser, Agent Monitor, Settings)
- Agent Runner: 3-agent orchestration (Manager/Builder/Reviewer) with per-agent model selection
- 17 MCP tools
- 127 skills (85 free + 42 Pro)
- Real-time context window monitoring per agent
- Session diary with AI-authored markdown narratives
- Safe git staging (prevents accidental commits of secrets/runtime data)
- Task completion notifications (browser, tab flash, audio)
- Token usage tracking with estimated costs
- Headroom proxy integration (~35-40% token savings)

**[v3.4.0](https://github.com/cwinvestments/memstack-skill-loader/releases/tag/v3.4.0)** — 100 Skills Milestone (18 new Pro skills, auto-detection, display name fixes)

## License

Proprietary — Part of MemStack™ Pro by CW Affiliate Investments LLC.
