"""Entry point for running the MCP server as a module."""

import logging
import sys

from summary_stack_obsidian_mcp_server.server import mcp


def _configure_logging() -> None:
    """Configure logging to write to stderr instead of stdout.

    MCP uses stdout for JSONRPC communication, so all logs must go to stderr.
    """
    logging.basicConfig(
        level=logging.WARNING,
        format="%(levelname)s - %(name)s - %(message)s",
        stream=sys.stderr,
        force=True,
    )


def main() -> None:
    """Run the MCP server."""
    _configure_logging()
    mcp.run()


if __name__ == "__main__":
    main()
