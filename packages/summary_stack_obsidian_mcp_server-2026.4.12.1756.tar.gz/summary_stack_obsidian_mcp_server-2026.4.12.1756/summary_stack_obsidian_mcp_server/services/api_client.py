"""API client for Summary Stack API with HTTP polling pattern."""

import asyncio
import logging
from typing import Any

import httpx

from summary_stack_obsidian_mcp_server.models import ObsidianManifestResult


logger = logging.getLogger(__name__)

# Polling configuration
POLL_INTERVAL_SECONDS = 2.0
MAX_POLL_TIMEOUT_SECONDS = 300.0  # 5 minutes
MAX_RETRIES = 3
RETRY_BACKOFF_BASE = 1.0  # 1s, 2s, 4s


class SummaryStackAPIError(Exception):
    """Error from Summary Stack API."""

    def __init__(self, message: str, event_type: str | None = None, metadata: dict[str, Any] | None = None):
        super().__init__(message)
        self.event_type = event_type
        self.metadata = metadata or {}


class SummaryStackAPIClient:
    """Client for Summary Stack API using HTTP polling pattern."""

    def __init__(self, api_url: str, api_key: str):
        """Initialize the API client.

        Args:
            api_url: Base URL of the Summary Stack API
            api_key: API key for authentication
        """
        self.api_url = api_url.rstrip("/")
        self.api_key = api_key

    def _get_headers(self) -> dict[str, str]:
        """Get common headers for API requests."""
        return {
            "X-API-Key": self.api_key,
            "Content-Type": "application/x-www-form-urlencoded",
        }

    async def _request_with_retry(
        self,
        client: httpx.AsyncClient,
        method: str,
        url: str,
        **kwargs: Any,
    ) -> httpx.Response:
        """Make HTTP request with retry logic for transient errors.

        Args:
            client: httpx AsyncClient instance
            method: HTTP method (GET, POST, etc.)
            url: Request URL
            **kwargs: Additional arguments for httpx request

        Returns:
            HTTP response

        Raises:
            httpx.HTTPError: If all retries fail
        """
        last_error: Exception | None = None

        for attempt in range(MAX_RETRIES):
            try:
                response = await client.request(method, url, **kwargs)
                # Don't retry on 4xx errors
                if 400 <= response.status_code < 500:
                    response.raise_for_status()
                return response
            except httpx.HTTPError as e:
                last_error = e
                if attempt < MAX_RETRIES - 1:
                    wait_time = RETRY_BACKOFF_BASE * (2**attempt)
                    logger.warning(f"Request failed (attempt {attempt + 1}/{MAX_RETRIES}), retrying in {wait_time}s: {e}")
                    await asyncio.sleep(wait_time)

        raise last_error or httpx.HTTPError("Request failed after all retries")

    async def create_stack(self, url: str) -> str:
        """Initiate stack creation and return session_id.

        Args:
            url: URL to process into a summary stack

        Returns:
            session_id for polling status

        Raises:
            SummaryStackAPIError: If API returns an error
            httpx.HTTPError: If request fails
        """
        async with httpx.AsyncClient(timeout=30.0) as client:
            response = await self._request_with_retry(
                client,
                "POST",
                f"{self.api_url}/api/v1/stacks",
                data={"uri": url},
                headers=self._get_headers(),
            )

            if response.status_code == 202:
                data: dict[str, Any] = response.json()
                session_id = data.get("session_id")
                if not session_id:
                    raise SummaryStackAPIError("API response missing session_id")
                logger.info(f"Stack creation initiated, session_id: {session_id}")
                return str(session_id)

            # Handle error responses
            response.raise_for_status()
            raise SummaryStackAPIError(f"Unexpected response status: {response.status_code}")

    async def poll_session_status(self, session_id: str) -> dict[str, Any]:
        """Poll session status endpoint.

        Args:
            session_id: Session ID from create_stack response

        Returns:
            Status response dict with 'status' and additional fields

        Raises:
            httpx.HTTPError: If request fails
        """
        async with httpx.AsyncClient(timeout=30.0) as client:
            response = await self._request_with_retry(
                client,
                "GET",
                f"{self.api_url}/api/v1/sessions/{session_id}/status",
                headers=self._get_headers(),
            )
            response.raise_for_status()
            result: dict[str, Any] = response.json()
            return result

    async def get_obsidian_manifest(self, summary_stack_id: str) -> ObsidianManifestResult:
        """Retrieve Obsidian manifest for a completed stack.

        Args:
            summary_stack_id: ID of the completed summary stack

        Returns:
            ObsidianManifestResult with all data for vault writing

        Raises:
            SummaryStackAPIError: If API returns an error
            httpx.HTTPError: If request fails
        """
        async with httpx.AsyncClient(timeout=60.0) as client:
            response = await self._request_with_retry(
                client,
                "GET",
                f"{self.api_url}/api/v1/stacks/{summary_stack_id}/obsidian-manifest",
                headers=self._get_headers(),
            )
            response.raise_for_status()
            return ObsidianManifestResult.model_validate(response.json())

    async def create_obsidian_manifest(self, url: str) -> ObsidianManifestResult:
        """Create a summary stack and wait for completion via polling.

        This is the main entry point that replaces the SSE-based flow.
        Initiates stack creation, polls for completion, then fetches manifest.

        Args:
            url: URL to process into a summary stack

        Returns:
            ObsidianManifestResult with all data needed for vault writing

        Raises:
            SummaryStackAPIError: If processing fails or times out
            httpx.HTTPError: If requests fail
        """
        # Step 1: Initiate stack creation
        session_id = await self.create_stack(url)

        # Step 2: Poll for completion
        elapsed = 0.0
        while elapsed < MAX_POLL_TIMEOUT_SECONDS:
            status_response = await self.poll_session_status(session_id)
            status = status_response.get("status")

            if status == "complete":
                summary_stack_id = status_response.get("summary_stack_id")
                if not summary_stack_id:
                    raise SummaryStackAPIError("Complete status missing summary_stack_id")

                logger.info(f"Processing complete, fetching manifest for: {summary_stack_id}")

                # Step 3: Fetch manifest
                return await self.get_obsidian_manifest(summary_stack_id)

            if status == "error":
                error_msg = status_response.get("error", "Unknown processing error")
                raise SummaryStackAPIError(
                    message=error_msg,
                    event_type="processing_error",
                    metadata=status_response,
                )

            if status == "not_found":
                raise SummaryStackAPIError(
                    message=f"Session not found: {session_id}",
                    event_type="session_not_found",
                )

            # Status is "processing" - continue polling
            current_step = status_response.get("current_step", "unknown")
            logger.debug(f"Processing in progress: {current_step} (elapsed: {elapsed:.1f}s)")

            await asyncio.sleep(POLL_INTERVAL_SECONDS)
            elapsed += POLL_INTERVAL_SECONDS

        # Timeout reached
        raise SummaryStackAPIError(
            message=f"Processing timeout after {MAX_POLL_TIMEOUT_SECONDS}s. Processing may still be running.",
            event_type="timeout",
            metadata={"session_id": session_id, "elapsed_seconds": elapsed},
        )
