"""SQLite-based API response cache for yuragi.

Caches CompletionResult by hash(model + prompt + temperature + num_samples +
system_prompt + max_tokens + version).
Default TTL: 24 hours.
Cache DB: ~/.yuragi/cache.db
"""

from __future__ import annotations

import hashlib
import json
import logging
import os
import sqlite3
import time
from pathlib import Path

import yuragi
from yuragi.providers.adapter import CompletionResult

logger = logging.getLogger(__name__)

_DEFAULT_TTL = 60 * 60 * 24  # 24 hours
_DB_PATH = Path.home() / ".yuragi" / "cache.db"

_CREATE_TABLE = """
CREATE TABLE IF NOT EXISTS responses_v2 (
    key TEXT PRIMARY KEY,
    value TEXT NOT NULL,
    created_at REAL NOT NULL
)
"""


def _cache_key(
    model: str,
    prompt: str,
    temperature: float,
    num_samples: int,
    system_prompt: str | None = None,
    max_tokens: int | None = None,
) -> str:
    raw = json.dumps(
        {
            "model": model,
            "prompt": prompt,
            "temperature": temperature,
            "num_samples": num_samples,
            "system_prompt": system_prompt,
            "max_tokens": max_tokens,
            "version": yuragi.__version__,
        },
        sort_keys=True,
        ensure_ascii=False,
    )
    return hashlib.sha256(raw.encode()).hexdigest()


class ResponseCache:
    """SQLite-backed cache for CompletionResult objects."""

    def __init__(self, db_path: Path = _DB_PATH, ttl: int = _DEFAULT_TTL) -> None:
        self.db_path = db_path
        self.ttl = ttl
        self._hits = 0
        self._misses = 0
        db_path.parent.mkdir(parents=True, exist_ok=True)
        os.chmod(str(db_path.parent), 0o700)
        try:
            self._conn = sqlite3.connect(str(db_path), check_same_thread=False)
            self._conn.execute("PRAGMA journal_mode=WAL")
            self._conn.execute(_CREATE_TABLE)
            self._conn.commit()
            os.chmod(str(db_path), 0o600)
        except sqlite3.Error as e:
            from yuragi.exceptions import CacheError

            raise CacheError(f"Failed to initialize cache at {db_path}: {e}") from e

    def get(
        self,
        model: str,
        prompt: str,
        temperature: float,
        num_samples: int,
        system_prompt: str | None = None,
        max_tokens: int | None = None,
    ) -> CompletionResult | None:
        key = _cache_key(model, prompt, temperature, num_samples, system_prompt, max_tokens)
        row = self._conn.execute(
            "SELECT value, created_at FROM responses_v2 WHERE key = ?", (key,)
        ).fetchone()
        if row is None:
            self._misses += 1
            logger.debug("cache miss key=%s", key[:16])
            return None
        value, created_at = row
        if time.time() - created_at > self.ttl:
            self._conn.execute("DELETE FROM responses_v2 WHERE key = ?", (key,))
            self._conn.commit()
            self._misses += 1
            logger.debug("cache expired key=%s", key[:16])
            return None
        self._hits += 1
        logger.debug("cache hit key=%s", key[:16])
        data = json.loads(value)
        return CompletionResult.from_json(data)

    def set(
        self,
        model: str,
        prompt: str,
        temperature: float,
        num_samples: int,
        result: CompletionResult,
        system_prompt: str | None = None,
        max_tokens: int | None = None,
    ) -> None:
        key = _cache_key(model, prompt, temperature, num_samples, system_prompt, max_tokens)
        value = json.dumps(result.to_json(), ensure_ascii=False)
        self._conn.execute(
            "INSERT OR REPLACE INTO responses_v2 (key, value, created_at) VALUES (?, ?, ?)",
            (key, value, time.time()),
        )
        self._conn.commit()

    def clear(self) -> int:
        cur = self._conn.execute("SELECT COUNT(*) FROM responses_v2")
        count = cur.fetchone()[0]
        self._conn.execute("DELETE FROM responses_v2")
        self._conn.commit()
        return count

    def stats(self) -> dict:
        cur = self._conn.execute("SELECT COUNT(*) FROM responses_v2")
        total = cur.fetchone()[0]
        requests = self._hits + self._misses
        hit_rate = self._hits / requests if requests > 0 else 0.0
        return {
            "total_entries": total,
            "hits": self._hits,
            "misses": self._misses,
            "hit_rate": hit_rate,
            "db_path": str(self.db_path),
        }

    def close(self) -> None:
        self._conn.close()
