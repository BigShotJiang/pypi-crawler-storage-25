"""Adapter that converts a yuragi :class:`ScanResult` into a guardrail
:class:`ConfidenceReport`.

The two data shapes were defined for different purposes — yuragi's
``ScanResult`` measures *fragility under perturbation*, while the
guardrail ``ConfidenceReport`` records *the four signals the policy
needs to route on*. This adapter does the mapping in one place so user
code never has to know the field names.

Mapping
-------
* ``confidence``       ← ``baseline.confidence``  (logprob-derived)
* ``semantic_entropy`` ← ``-log(1 - dissociation_rate)``  if the
  optional ``yuragi.metrics.semantic_entropy`` extra is wired in,
  otherwise ``0`` and ``"semantic_entropy"`` is omitted from sources.
* ``vix``              ← ``vulnerability * 100`` (mapped to the [0, 100]
  VIX-style scale the fuser expects)
* ``sharpe``           ← ``(1 - fragility_score) * 4 - 2``  rescales the
  yuragi fragility score (0 = stable, 1 = collapse) into the Sharpe
  range ``[-2, 2]`` the fuser uses; a ``fragility_score`` of 0 maps to
  the maximum Sharpe of 2.
* ``dissociation``     ← ``dissociation_rate`` (passed through)

The mapping is documented at length so future contributors can adjust
weights without re-reading the fuser.
"""

from __future__ import annotations

from typing import TYPE_CHECKING

from .._types import ConfidenceReport

if TYPE_CHECKING:
    from yuragi.core import ScanResult


def yuragi_to_report(scan: ScanResult) -> ConfidenceReport:
    """Convert a :class:`yuragi.core.ScanResult` to a :class:`ConfidenceReport`.

    The conversion is lossless for the four fields the guardrails fuser
    consumes (``confidence``, ``semantic_entropy``, ``vix``, ``sharpe``,
    ``dissociation``). ``sources`` is populated with the names of the
    metrics that were actually present.
    """
    sources: list[str] = []

    confidence = float(getattr(scan.baseline, "confidence", 0.0))
    if confidence:
        sources.append("yuragi.baseline_confidence")

    fragility = float(getattr(scan, "fragility_score", 0.0))
    sharpe = max(-2.0, min(2.0, (1.0 - fragility) * 4.0 - 2.0))
    # Only mark fragility as a populated source when the metric was
    # explicitly measured (> 0). The rescaled sharpe is always defined,
    # so we cannot use it to decide whether the underlying signal exists.
    if fragility > 0:
        sources.append("yuragi.fragility_score")

    vulnerability = float(getattr(scan, "vulnerability", 0.0))
    vix = max(0.0, min(100.0, vulnerability * 100.0))
    if vulnerability:
        sources.append("yuragi.vulnerability")

    dissociation = float(getattr(scan, "dissociation_rate", 0.0))
    if dissociation:
        sources.append("yuragi.dissociation_rate")

    return ConfidenceReport(
        confidence=confidence,
        semantic_entropy=0.0,  # not exposed by ScanResult; left at 0
        vix=vix,
        sharpe=sharpe,
        dissociation=dissociation,
        sources=tuple(sources),
    )
