"""Adapters from third-party data shapes into the guardrail
:class:`yuragi.guardrails.ConfidenceReport`.

Currently shipped:

* :func:`yuragi_to_report` — maps a :class:`yuragi.core.ScanResult`
  into a :class:`ConfidenceReport`.
"""

from __future__ import annotations

from .yuragi_metrics import yuragi_to_report

__all__ = ["yuragi_to_report"]
