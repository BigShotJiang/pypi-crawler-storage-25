"""Multi-signal confidence fusion.

Fuses semantic entropy, volatility (VIX), risk-adjusted certainty
(Sharpe), and the verbalized-logit dissociation gap into a single
scalar confidence in ``[0, 1]``.

The fusion formula (yuragi v0.5.0)::

    C = w_semantic · (1 - H_norm)
      + w_vix      · (1 - VIX/100)
      + w_sharpe   ·  Sharpe_norm
      - λ_diss     ·  Dissociation

where ``H_norm = clip01(H / H_ref)`` with the reference entropy
``H_ref`` defaulting to 4 nats (treated as "very uncertain" given the
yuragi sampling defaults).

Origin: ported from ``dacm.confidence.engine`` (2026-04-11). The single
behavioural change is that the fusion engine emits a logger message at
``DEBUG`` level for every call so production observability hooks can
watch confidence drift without re-implementing the fusion logic.
"""

from __future__ import annotations

import logging
from dataclasses import dataclass

from ._types import ConfidenceReport

logger = logging.getLogger(__name__)

_EPS = 1e-9
_SHARPE_LO = -2.0
_SHARPE_HI = 2.0
_VIX_HI = 100.0


@dataclass(frozen=True, slots=True)
class FusionWeights:
    """Tunable weights for :class:`ConfidenceFuser`.

    All weights are positive by convention. ``lam_dissociation`` is
    *subtracted* in the fusion formula, so a higher value penalises
    verbalized-logit gap more aggressively.
    """

    w_semantic: float = 0.45
    w_vix: float = 0.20
    w_sharpe: float = 0.20
    lam_dissociation: float = 0.40
    semantic_entropy_norm: float = 4.0


def _clip01(x: float) -> float:
    """Clip ``x`` into ``[0.0, 1.0]`` (NaN-safe via comparisons)."""
    if x != x:  # NaN check without importing math
        return 0.0
    if x < 0.0:
        return 0.0
    if x > 1.0:
        return 1.0
    return x


class ConfidenceFuser:
    """Stateless fusion of (semantic_entropy, vix, sharpe, dissociation).

    Instances are cheap to allocate; the only state is a
    :class:`FusionWeights` value object. Subclass and override
    :meth:`fuse` to plug in domain-specific calibration without touching
    the public API.
    """

    __slots__ = ("weights",)

    def __init__(self, weights: FusionWeights | None = None) -> None:
        self.weights = weights or FusionWeights()

    def fuse(
        self,
        *,
        semantic_entropy: float = 0.0,
        vix: float = 0.0,
        sharpe: float = 0.0,
        dissociation: float = 0.0,
        sources: tuple[str, ...] = (),
    ) -> ConfidenceReport:
        """Fuse four uncertainty signals into a :class:`ConfidenceReport`.

        Parameters
        ----------
        semantic_entropy
            Semantic entropy in nats. Must be ``>= 0``.
        vix
            Confidence volatility in ``[0, 100]``.
        sharpe
            Confidence Sharpe ratio. Values outside ``[-2, 2]`` are
            clipped during normalisation.
        dissociation
            Verbalized–logit gap in ``[0, 1]``.
        sources
            Names of the signals actually populated. Empty tuple is
            permitted but logged at ``DEBUG``.
        """
        w = self.weights

        h_norm = _clip01(semantic_entropy / max(w.semantic_entropy_norm, _EPS))
        vix_norm = _clip01(vix / _VIX_HI)
        sharpe_norm = _clip01((sharpe - _SHARPE_LO) / (_SHARPE_HI - _SHARPE_LO))
        diss = _clip01(dissociation)

        confidence = (
            w.w_semantic * (1.0 - h_norm)
            + w.w_vix * (1.0 - vix_norm)
            + w.w_sharpe * sharpe_norm
            - w.lam_dissociation * diss
        )
        confidence = _clip01(confidence)

        logger.debug(
            "fused confidence=%.4f h=%.3f vix=%.1f sharpe=%.2f diss=%.3f sources=%s",
            confidence, semantic_entropy, vix, sharpe, dissociation, sources,
        )

        return ConfidenceReport(
            confidence=confidence,
            semantic_entropy=semantic_entropy,
            vix=vix,
            sharpe=sharpe,
            dissociation=dissociation,
            sources=sources,
        )
