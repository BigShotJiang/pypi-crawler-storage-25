"""yuragi.guardrails — confidence-aware LLM guardrails.

Public API
----------

Confidence layer
~~~~~~~~~~~~~~~~
* :class:`ConfidenceReport` — multi-signal confidence record.
* :class:`PolicyDecision` — closed enum of routing outcomes.
* :class:`ConfidenceFuser` / :class:`FusionWeights` — fuse the four
  yuragi confidence signals into one score.
* :class:`ConfidencePolicy` — threshold-based routing policy.
* :func:`route_on_confidence` / :func:`route_on_confidence_async` —
  one-liner dispatch helpers for any framework.

Audit layer
~~~~~~~~~~~
* :class:`AuditLog` / :class:`AuditSink` — append-only audit log with
  SHA-256 hash chain.
* :mod:`yuragi.guardrails.audit.events` — guardrail-level event
  vocabulary (decisions).
* :mod:`yuragi.guardrails.protocols.events` — kernel-level event
  vocabulary (mechanics).

Multi-agent runtime
~~~~~~~~~~~~~~~~~~~
* :class:`Runtime` — actor mesh orchestrator.
* :class:`Actor` / :class:`Envelope` — kernel base class + message type.
* :class:`InMemoryTransport` — default pub/sub bus.
* :class:`SnapshotEngine` — Git-like checkpoint/restore on a Merkle DAG.
* :class:`ContractNetScheduler` / :class:`AgentSpawner` — decentralised
  task allocation and dynamic worker scaling.

Reference agents
~~~~~~~~~~~~~~~~
* :class:`PlannerAgent` / :class:`ExecutorAgent` / :class:`CriticAgent`
  / :class:`ResearcherAgent` / :class:`VerifierAgent` /
  :class:`MetaAgent` — thin reference implementations to subclass.

Adapters & integrations
~~~~~~~~~~~~~~~~~~~~~~~
* :mod:`yuragi.guardrails.adapters` — adapt third-party data shapes
  into :class:`ConfidenceReport`.
* :mod:`yuragi.guardrails.integrations` — AutoGen / LangGraph wrappers.

Notes
-----
This subsystem ships as part of the ``yuragi`` package but is
*opt-in*: the symbols below are not exported from ``yuragi.__init__``,
so importing ``yuragi`` itself never pulls in the guardrails code.

The default install (``pip install yuragi``) is enough to use the
guardrails — the only dependencies are the standard library. Optional
framework integrations and distributed transports require extras
(``yuragi[guardrails-autogen]``, ``yuragi[guardrails-nats]``).
"""

from __future__ import annotations

from ._types import ConfidenceReport, PolicyDecision
from .agents import (
    CriticAgent,
    ExecutorAgent,
    GuardrailAgent,
    MetaAgent,
    PlannerAgent,
    ResearcherAgent,
    VerifierAgent,
)
from .audit import AuditLog, AuditSink
from .bus import InMemoryTransport, Transport
from .fuse import ConfidenceFuser, FusionWeights
from .kernel import Actor, Envelope, LifecycleError, Runtime
from .policy import ConfidencePolicy
from .route import route_on_confidence, route_on_confidence_async
from .scheduler import AgentSpawner, ContractNetScheduler, ReputationTable
from .snapshot import MerkleDag, MerkleNode, SnapshotEngine, SnapshotResult

__all__ = [
    "Actor",
    "AgentSpawner",
    "AuditLog",
    "AuditSink",
    "ConfidenceFuser",
    "ConfidencePolicy",
    "ConfidenceReport",
    "ContractNetScheduler",
    "CriticAgent",
    "Envelope",
    "ExecutorAgent",
    "FusionWeights",
    "GuardrailAgent",
    "InMemoryTransport",
    "LifecycleError",
    "MerkleDag",
    "MerkleNode",
    "MetaAgent",
    "PlannerAgent",
    "PolicyDecision",
    "ReputationTable",
    "ResearcherAgent",
    "Runtime",
    "SnapshotEngine",
    "SnapshotResult",
    "Transport",
    "VerifierAgent",
    "route_on_confidence",
    "route_on_confidence_async",
]
