"""Content-addressed blob storage used by the snapshot engine."""

from __future__ import annotations

from .cas_blob import CasBlobStore

__all__ = ["CasBlobStore"]
