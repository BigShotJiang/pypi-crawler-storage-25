"""Content-addressed blob store.

Used by the snapshot engine and any agent that wants to deduplicate
large state blobs across snapshots. The address of a blob *is* its
SHA-256 — equal blobs share storage automatically, mutation is
impossible because that would change the address.

Origin: ported from ``dacm.memory.cas_blob`` (2026-04-11).
"""

from __future__ import annotations

import asyncio
import hashlib
import re
from pathlib import Path

_SHA256_HEX = re.compile(r"\A[0-9a-f]{64}\Z")


class CasBlobStore:
    """A tiny content-addressed blob store on the local filesystem.

    Layout: ``root/<aa>/<bb>/<full_sha256>``. The two-level fan-out
    keeps any single directory below 65 k entries even when the store
    grows large.
    """

    def __init__(self, root: str | Path) -> None:
        self.root = Path(root)
        self.root.mkdir(parents=True, exist_ok=True)
        self._lock = asyncio.Lock()

    async def put(self, blob: bytes) -> str:
        sha = hashlib.sha256(blob).hexdigest()
        path = self._path_for(sha)
        async with self._lock:
            if not path.exists():
                path.parent.mkdir(parents=True, exist_ok=True)
                tmp = path.with_suffix(".tmp")
                tmp.write_bytes(blob)
                tmp.replace(path)
        return sha

    async def get(self, sha: str) -> bytes:
        return self._path_for(sha).read_bytes()

    async def has(self, sha: str) -> bool:
        return self._path_for(sha).exists()

    def _path_for(self, sha: str) -> Path:
        # Reject anything that isn't a 64-char lowercase hex SHA-256 so a
        # caller can never escape ``self.root`` (e.g. via ``../`` segments)
        # when an untrusted address is passed in.
        if not _SHA256_HEX.match(sha):
            raise ValueError(f"not a SHA-256 hex digest: {sha!r}")
        return self.root / sha[:2] / sha[2:4] / sha
