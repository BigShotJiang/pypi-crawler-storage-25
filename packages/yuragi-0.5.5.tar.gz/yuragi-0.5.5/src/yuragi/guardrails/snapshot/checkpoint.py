"""SnapshotEngine — Git-like checkpoint and ≤ 1 s lazy restore.

The engine takes a snapshot of the runtime by:

1. Asking every actor for its serialisable state via ``on_checkpoint()``.
2. Hashing each agent's state into a leaf :class:`MerkleNode`.
3. Building a single root node whose ``children`` map is
   ``{agent_id: agent_state_address}``.
4. Returning the root address. ``commit`` is one dict insert; the
   actual writing happens in :meth:`MerkleDag.put`, which deduplicates
   any unchanged subtree.

Restore is the symmetric operation: given a root address, walk the
children map, fetch each agent's state, and call ``on_restore`` on
the matching live actor.

Performance target: for 10 000 agents × ~4 KB state each, ``commit``
and ``restore`` should each complete in under one second on commodity
NVMe. The unit tests exercise 1 000 agents to keep CI fast.

Origin: ported from ``dacm.snapshot.checkpoint`` (2026-04-11).
"""

from __future__ import annotations

import time
from dataclasses import dataclass
from typing import TYPE_CHECKING

from ..protocols.events import CheckpointCreated, CheckpointRestored
from .merkle_dag import MerkleDag, MerkleNode

if TYPE_CHECKING:
    from ..kernel.lifecycle import Runtime


@dataclass(frozen=True, slots=True)
class SnapshotResult:
    """Return value of :meth:`SnapshotEngine.commit`."""

    root: str
    n_agents: int
    bytes_total: int
    duration_ms: float


class SnapshotEngine:
    """Snapshot / restore engine on top of a :class:`MerkleDag`."""

    def __init__(self, dag: MerkleDag | None = None) -> None:
        self.dag = dag or MerkleDag()

    async def commit(self, runtime: Runtime, *, reason: str = "") -> SnapshotResult:
        """Capture the state of every live actor in ``runtime``."""
        t0 = time.perf_counter()
        children: dict[str, str] = {}
        n_agents = 0
        for agent_id in runtime.list_agents():
            actor = runtime._actors[agent_id].actor
            state = await actor.on_checkpoint()
            leaf = MerkleNode(payload=state)
            children[agent_id] = self.dag.put(leaf)
            n_agents += 1
        root_node = MerkleNode(payload={"reason": reason}, children=children)
        root_addr = self.dag.put(root_node)
        duration = (time.perf_counter() - t0) * 1000.0
        await runtime.record_event(
            CheckpointCreated(
                root_hash=root_addr,
                n_agents=n_agents,
                bytes_total=self.dag.total_bytes,
            )
        )
        return SnapshotResult(
            root=root_addr,
            n_agents=n_agents,
            bytes_total=self.dag.total_bytes,
            duration_ms=duration,
        )

    async def restore(self, runtime: Runtime, root: str) -> dict[str, str]:
        """Restore as many live actors as match the snapshot's children map.

        Returns a dict ``{agent_id: 'restored' | 'missing'}`` so the
        caller can report which agents were repopulated and which the
        snapshot contained but the runtime no longer has.
        """
        t0 = time.perf_counter()
        node = self.dag.get(root)
        report: dict[str, str] = {}
        for agent_id, addr in node.children.items():
            child = self.dag.get(addr)
            if agent_id in runtime._actors:
                await runtime._actors[agent_id].actor.on_restore(child.payload)
                report[agent_id] = "restored"
            else:
                report[agent_id] = "missing"
        duration = (time.perf_counter() - t0) * 1000.0
        await runtime.record_event(
            CheckpointRestored(root_hash=root, duration_ms=duration)
        )
        return report
