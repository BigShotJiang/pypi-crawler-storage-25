"""Merkle DAG — content-addressed copy-on-write tree of agent state.

The snapshot engine stores agent state as a Merkle DAG: every node is
a serialised dict of children + payload, and a node's address is the
SHA-256 of its serialised form. Two nodes with identical content share
the same address automatically; modifying any field produces a new
address all the way up to the root, *but* the unmodified subtrees
remain reachable through the old root. That is what makes snapshots
copy-on-write.

This module is intentionally tiny: about 80 lines of plain Python with
no third-party dependency. The whole point of the architecture is that
the snapshot machinery is simple enough to audit and trust.

Origin: ported from ``dacm.snapshot.merkle_dag`` (2026-04-11).
"""

from __future__ import annotations

import hashlib
import json
from dataclasses import dataclass, field
from typing import Any


def _node_hash(payload: Any, children: dict[str, str]) -> str:
    blob = json.dumps(
        {"payload": payload, "children": children},
        sort_keys=True,
        ensure_ascii=False,
        default=repr,
    ).encode("utf-8")
    return hashlib.sha256(blob).hexdigest()


@dataclass(frozen=True, slots=True)
class MerkleNode:
    """One immutable node in the Merkle DAG."""

    payload: Any
    children: dict[str, str] = field(default_factory=dict)

    @property
    def address(self) -> str:
        return _node_hash(self.payload, self.children)

    def serialise(self) -> bytes:
        return json.dumps(
            {"payload": self.payload, "children": self.children},
            sort_keys=True,
            ensure_ascii=False,
            default=repr,
        ).encode("utf-8")

    @classmethod
    def deserialise(cls, blob: bytes) -> MerkleNode:
        data = json.loads(blob.decode("utf-8"))
        return cls(payload=data["payload"], children=data["children"])


class MerkleDag:
    """In-memory Merkle DAG store with put / get / root operations.

    Backed by a plain ``dict[str, bytes]`` so it can be swapped with
    :class:`~yuragi.guardrails.storage.cas_blob.CasBlobStore` for
    on-disk persistence by re-implementing the same two methods.
    """

    def __init__(self) -> None:
        self._store: dict[str, bytes] = {}

    def put(self, node: MerkleNode) -> str:
        addr = node.address
        if addr not in self._store:
            self._store[addr] = node.serialise()
        return addr

    def get(self, addr: str) -> MerkleNode:
        blob = self._store.get(addr)
        if blob is None:
            raise KeyError(f"Unknown Merkle address: {addr}")
        return MerkleNode.deserialise(blob)

    def has(self, addr: str) -> bool:
        return addr in self._store

    def __len__(self) -> int:
        return len(self._store)

    @property
    def total_bytes(self) -> int:
        return sum(len(b) for b in self._store.values())
