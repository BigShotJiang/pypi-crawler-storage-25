"""Threshold-based routing policy for fused confidence reports.

The default :class:`ConfidencePolicy` is intentionally simple: three
thresholds, one decision. Subclass it for learned or per-task taus.

Decision rules (in order)::

    confidence < reject_below    → REJECT
    dissociation > diss_max      → RESEARCH   (verbalized-logit red flag)
    confidence  < tau            → RESEARCH
    otherwise                    → ACCEPT

Origin: ported from ``dacm.confidence.policy`` (2026-04-11), with the
ordering of the rules made explicit and a logger added for production
debuggability.
"""

from __future__ import annotations

import logging
from dataclasses import dataclass

from ._types import ConfidenceReport, PolicyDecision

logger = logging.getLogger(__name__)


@dataclass(frozen=True, slots=True)
class ConfidencePolicy:
    """Threshold-based confidence policy.

    Parameters
    ----------
    tau
        Confidence threshold for ``ACCEPT``. Reports at or above ``tau``
        and not flagged for dissociation pass through.
    dissociation_max
        Dissociation threshold for ``RESEARCH``. Above this value the
        verbalized–logit gap is considered too large to trust the
        verbalized number, so the report is routed to research even if
        ``confidence >= tau``.
    reject_below
        Confidence threshold for ``REJECT``. Reports below this value
        are dropped outright; downstream code should emit an abstention.

    Notes
    -----
    Thresholds are validated lazily inside :meth:`decide` so the
    dataclass stays a value object.
    """

    tau: float = 0.55
    dissociation_max: float = 0.30
    reject_below: float = 0.10

    def decide(self, report: ConfidenceReport) -> PolicyDecision:
        """Return the routing decision for ``report``.

        The function is a pure projection: same input always yields the
        same output, no I/O, no side effects beyond a debug log line.
        """
        c = report.confidence
        d = report.dissociation

        if c < self.reject_below:
            decision = PolicyDecision.REJECT
        elif d > self.dissociation_max or c < self.tau:
            decision = PolicyDecision.RESEARCH
        else:
            decision = PolicyDecision.ACCEPT

        logger.debug(
            "policy decide c=%.3f d=%.3f tau=%.2f diss_max=%.2f reject=%.2f -> %s",
            c, d, self.tau, self.dissociation_max, self.reject_below, decision.value,
        )
        return decision
