"""Append-only audit log for guardrail decisions.

See :mod:`yuragi.guardrails.audit.log` for the SQLite-backed default
implementation and :mod:`yuragi.guardrails.audit.events` for the
closed event vocabulary every guardrail emits.
"""

from __future__ import annotations

from .events import (
    AbstentionEmitted,
    AuditEvent,
    ConfidenceComputed,
    ErrorRaised,
    GuardrailAttached,
    GuardrailDetached,
    MessageBlocked,
    MessageInspected,
    PolicyDecided,
    ResearchRequested,
    ToolFailed,
    ToolInvoked,
    ToolResulted,
)
from .log import AuditLog, AuditSink

__all__ = [
    "AbstentionEmitted",
    "AuditEvent",
    "AuditLog",
    "AuditSink",
    "ConfidenceComputed",
    "ErrorRaised",
    "GuardrailAttached",
    "GuardrailDetached",
    "MessageBlocked",
    "MessageInspected",
    "PolicyDecided",
    "ResearchRequested",
    "ToolFailed",
    "ToolInvoked",
    "ToolResulted",
]
