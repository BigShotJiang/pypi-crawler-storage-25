"""SQLite-WAL append-only audit log with SHA-256 hash chain.

Every guardrail decision can be appended to an :class:`AuditLog` so an
auditor (or the user themselves) can later prove that the log has not
been tampered with after the fact.

Design notes
------------
* **Append-only enforced by SQL trigger.** ``BEFORE UPDATE`` and
  ``BEFORE DELETE`` triggers raise ``ABORT``. Convention is not enough;
  the database itself refuses mutation.
* **Hash chain.** Every row stores ``prev_hash = SHA256(prev_row_blob)``.
  A tampered row breaks the chain on the next call to
  :meth:`AuditLog.verify_chain`.
* **WAL mode.** ``PRAGMA journal_mode=WAL`` + ``synchronous=NORMAL``
  yields ~10 k events / s on commodity NVMe with concurrent reads.
* **Single-writer.** SQLite WAL allows many readers but only one
  writer. Writes are serialised through one ``asyncio.Lock``.
* **JSON payloads.** Events are persisted as canonical JSON
  (``sort_keys=True``) so the hash chain is reproducible across
  Python runs and platforms.

Origin: ported from ``dacm.memory.event_store`` (2026-04-11). Behaviour
is byte-identical; the rename to :class:`AuditLog` reflects that the
yuragi guardrails view it as an audit primitive rather than a generic
event store.
"""

from __future__ import annotations

import asyncio
import dataclasses
import hashlib
import json
import logging
import sqlite3
from collections.abc import Iterable
from pathlib import Path
from typing import Any, Protocol, runtime_checkable

# AuditLog also accepts :class:`yuragi.guardrails.protocols.events.RuntimeEvent`
# instances — both share the same ``event_id`` / ``ts_ns`` / ``lamport`` /
# ``trace_id`` shape and are frozen dataclasses, which is all the storage
# layer needs.

logger = logging.getLogger(__name__)


SCHEMA_SQL = """
CREATE TABLE IF NOT EXISTS audit_events (
    seq        INTEGER PRIMARY KEY AUTOINCREMENT,
    event_id   TEXT    NOT NULL UNIQUE,
    event_type TEXT    NOT NULL,
    ts_ns      INTEGER NOT NULL,
    lamport    INTEGER NOT NULL,
    trace_id   TEXT    NOT NULL,
    payload    TEXT    NOT NULL,
    prev_hash  TEXT    NOT NULL,
    self_hash  TEXT    NOT NULL UNIQUE
);

CREATE INDEX IF NOT EXISTS ix_audit_events_type  ON audit_events(event_type);
CREATE INDEX IF NOT EXISTS ix_audit_events_trace ON audit_events(trace_id);

DROP TRIGGER IF EXISTS audit_events_no_update;
CREATE TRIGGER audit_events_no_update BEFORE UPDATE ON audit_events
BEGIN
    SELECT RAISE(ABORT, 'audit log is append-only');
END;

DROP TRIGGER IF EXISTS audit_events_no_delete;
CREATE TRIGGER audit_events_no_delete BEFORE DELETE ON audit_events
BEGIN
    SELECT RAISE(ABORT, 'audit log is append-only');
END;
"""


@runtime_checkable
class AuditSink(Protocol):
    """Append-only audit sink surface — useful for testing.

    Anything implementing these four async methods can be substituted
    for an :class:`AuditLog` in user code (e.g. an in-memory mock or a
    pluggable Kafka backend).
    """

    async def append(self, event: Any) -> None: ...
    async def replay(self) -> Iterable[dict[str, Any]]: ...
    async def verify_chain(self) -> bool: ...
    async def close(self) -> None: ...


def _event_to_payload(event: Any) -> dict[str, Any]:
    """Serialise a frozen-dataclass event to a JSON-safe dict."""
    fields = {f.name: getattr(event, f.name) for f in dataclasses.fields(event)}
    fields["__type__"] = type(event).__name__
    return _sanitize(fields)


def _sanitize(obj: Any) -> Any:
    if isinstance(obj, tuple):
        return [_sanitize(x) for x in obj]
    if isinstance(obj, list):
        return [_sanitize(x) for x in obj]
    if isinstance(obj, dict):
        return {k: _sanitize(v) for k, v in obj.items()}
    return obj


def _payload_blob(payload: dict[str, Any]) -> bytes:
    """Canonical JSON encoding used for hashing and storage."""
    return json.dumps(payload, sort_keys=True, ensure_ascii=False).encode("utf-8")


def _row_hash(prev_hash: str, payload_blob: bytes) -> str:
    h = hashlib.sha256()
    h.update(prev_hash.encode("ascii"))
    h.update(b"\x00")
    h.update(payload_blob)
    return h.hexdigest()


class AuditLog:
    """Default :class:`AuditSink` implementation backed by SQLite-WAL.

    Use as an async-friendly handle: every public method is ``async``
    so the runtime can ``await`` it directly. Internally writes
    serialise through an :class:`asyncio.Lock` and run in the calling
    thread because ``sqlite3`` is fast enough at audit-log scale that
    an executor pool would only add overhead.

    Concurrency note
    ----------------
    A single :class:`asyncio.Lock` serialises every append across all
    agents in the runtime. This is **by design** — the SHA-256 chain
    requires that ``self_hash`` be computed against the exact previous
    row, which means writes have to be ordered. Throughput on commodity
    NVMe is ~10 k events / s, which is comfortably above the rate the
    runtime can produce them in practice. If your workload exceeds that
    ceiling, swap in a custom :class:`AuditSink` that batches writes or
    pushes them to a background queue.
    """

    __slots__ = ("_closed", "_conn", "_lock", "_tail_hash", "_tail_loaded", "path")

    def __init__(self, path: str | Path = ":memory:") -> None:
        self.path = str(path)
        if self.path != ":memory:":
            Path(self.path).parent.mkdir(parents=True, exist_ok=True)
        self._conn = sqlite3.connect(
            self.path,
            isolation_level=None,        # autocommit
            check_same_thread=False,
        )
        self._conn.execute("PRAGMA journal_mode=WAL")
        self._conn.execute("PRAGMA synchronous=NORMAL")
        self._conn.execute("PRAGMA foreign_keys=ON")
        self._conn.executescript(SCHEMA_SQL)
        self._lock = asyncio.Lock()
        # Lazy: read the actual tail under the write lock on the first
        # append so a second writer that opened the same DB file in the
        # interim cannot poison our prev_hash with a stale value.
        self._tail_hash: str = ""
        self._tail_loaded: bool = False
        self._closed = False
        logger.debug("AuditLog opened at %s (tail_hash will be loaded lazily)", self.path)

    async def append(self, event: Any) -> None:
        """Append ``event`` to the chain.

        ``event`` must be an instance of either :class:`AuditEvent` (a
        guardrail-level decision) or
        :class:`yuragi.guardrails.protocols.events.RuntimeEvent` (a
        kernel-level mechanic). Both share the field shape the chain
        needs (``event_id``, ``ts_ns``, ``lamport``, ``trace_id``).

        Raises
        ------
        RuntimeError
            If the log has been closed.
        sqlite3.IntegrityError
            If the row's ``event_id`` or computed ``self_hash`` collides
            with an existing row (should never happen in practice).
        """
        if self._closed:
            raise RuntimeError("AuditLog is closed")

        async with self._lock:
            if not self._tail_loaded:
                # Re-read tail under the lock so a concurrent writer
                # that has appended to the same DB file since __init__
                # cannot leave us with a stale prev_hash.
                self._tail_hash = self._load_tail_hash()
                self._tail_loaded = True
            payload = _event_to_payload(event)
            blob = _payload_blob(payload)
            self_hash = _row_hash(self._tail_hash, blob)
            self._conn.execute(
                "INSERT INTO audit_events "
                "(event_id, event_type, ts_ns, lamport, trace_id, payload, prev_hash, self_hash) "
                "VALUES (?, ?, ?, ?, ?, ?, ?, ?)",
                (
                    event.event_id,
                    type(event).__name__,
                    event.ts_ns,
                    event.lamport,
                    event.trace_id,
                    blob.decode("utf-8"),
                    self._tail_hash,
                    self_hash,
                ),
            )
            self._tail_hash = self_hash

    async def replay(self) -> list[dict[str, Any]]:
        """Return every stored row as a list of dicts (oldest first)."""
        if self._closed:
            raise RuntimeError("AuditLog is closed")

        async with self._lock:
            rows = self._conn.execute(
                "SELECT seq, event_id, event_type, ts_ns, lamport, trace_id, "
                "payload, prev_hash, self_hash FROM audit_events ORDER BY seq ASC"
            ).fetchall()
        return [
            {
                "seq": r[0],
                "event_id": r[1],
                "event_type": r[2],
                "ts_ns": r[3],
                "lamport": r[4],
                "trace_id": r[5],
                "payload": json.loads(r[6]),
                "prev_hash": r[7],
                "self_hash": r[8],
            }
            for r in rows
        ]

    async def verify_chain(
        self,
        *,
        start_seq: int = 1,
        batch_size: int = 1000,
    ) -> bool:
        """Walk the chain and confirm every row's ``self_hash`` matches.

        The walk is **incremental and bounded**. Pass ``start_seq`` to
        resume from a previously-verified point (callers can persist
        the highest verified ``seq`` between runs to avoid re-hashing
        the entire log) and ``batch_size`` to control how many rows
        are loaded into memory at once. Returns ``True`` when the
        chain segment is intact, ``False`` when any row has been
        mutated, deleted, or inserted out of order.
        """
        if self._closed:
            raise RuntimeError("AuditLog is closed")
        if start_seq < 1:
            raise ValueError("start_seq must be >= 1")

        # Bootstrap prev_hash for the requested start point.
        async with self._lock:
            if start_seq == 1:
                prev = ""
            else:
                row = self._conn.execute(
                    "SELECT self_hash FROM audit_events WHERE seq = ?",
                    (start_seq - 1,),
                ).fetchone()
                if row is None:
                    return False
                prev = row[0]

        seq = start_seq
        while True:
            async with self._lock:
                rows = self._conn.execute(
                    "SELECT seq, payload, prev_hash, self_hash "
                    "FROM audit_events WHERE seq >= ? ORDER BY seq ASC LIMIT ?",
                    (seq, batch_size),
                ).fetchall()
            if not rows:
                return True
            for r_seq, payload_text, prev_hash_db, self_hash_db in rows:
                payload = json.loads(payload_text)
                blob = _payload_blob(payload)
                expected = _row_hash(prev, blob)
                if self_hash_db != expected:
                    logger.warning("audit chain corrupt at seq=%s", r_seq)
                    return False
                if prev_hash_db != prev:
                    logger.warning(
                        "audit chain corrupt: prev_hash mismatch at seq=%s", r_seq,
                    )
                    return False
                prev = expected
            seq = rows[-1][0] + 1

    async def close(self) -> None:
        """Close the underlying SQLite connection. Idempotent."""
        if self._closed:
            return
        async with self._lock:
            self._conn.close()
            self._closed = True
            logger.debug("AuditLog closed at %s", self.path)

    def _load_tail_hash(self) -> str:
        row = self._conn.execute(
            "SELECT self_hash FROM audit_events ORDER BY seq DESC LIMIT 1"
        ).fetchone()
        return row[0] if row else ""

    @property
    def tail_hash(self) -> str:
        """The hash of the most recently appended row (or '' for empty log)."""
        return self._tail_hash
