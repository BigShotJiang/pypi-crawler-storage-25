"""Audit event vocabulary for the guardrails subsystem.

A closed vocabulary of frozen dataclasses every guardrail emits when
something interesting happens. The set is deliberately small (twelve
events split across five categories) so it stays understandable by a
human reading a SQL dump of the audit log.

Each event inherits from :class:`AuditEvent`, which carries the
runtime fields every event has — a unique ``event_id``, a
nanosecond-precision timestamp, a Lamport clock for partial ordering,
and a free-form ``trace_id`` so a single LLM request can be followed
end-to-end across multiple guardrails.

Origin: ported from ``dacm.protocols.events`` (2026-04-11). The CNP
(Contract Net Protocol) and snapshot families are intentionally omitted
from v0.5.0 — they belong to a multi-agent runtime, not a guardrail
audit log, and will be reintroduced in v0.7.0 when snapshots land.
"""

from __future__ import annotations

import time
import uuid
from dataclasses import dataclass, field

EventId = str


def _new_id() -> str:
    return uuid.uuid4().hex


def _now_ns() -> int:
    return time.time_ns()


@dataclass(frozen=True, slots=True)
class AuditEvent:
    """Base class for every event in the guardrails audit log.

    Subclasses are frozen dataclasses with ``slots=True`` so they
    behave as value objects: hashable, comparable, and cheap to
    allocate. The base carries the runtime fields every event has.
    """

    event_id: EventId = field(default_factory=_new_id)
    ts_ns: int = field(default_factory=_now_ns)
    lamport: int = 0
    trace_id: str = ""


# ---------------------------------------------------------------------------
# Lifecycle
# ---------------------------------------------------------------------------
@dataclass(frozen=True, slots=True)
class GuardrailAttached(AuditEvent):
    """A guardrail was attached to an agent or chain."""

    guardrail_id: str = ""
    target_id: str = ""
    config_hash: str = ""


@dataclass(frozen=True, slots=True)
class GuardrailDetached(AuditEvent):
    """A guardrail was removed from an agent or chain."""

    guardrail_id: str = ""
    reason: str = ""


# ---------------------------------------------------------------------------
# Messaging
# ---------------------------------------------------------------------------
@dataclass(frozen=True, slots=True)
class MessageInspected(AuditEvent):
    """A message passed through a guardrail for inspection."""

    sender_id: str = ""
    subject: str = ""
    payload_hash: str = ""
    confidence: float | None = None


@dataclass(frozen=True, slots=True)
class MessageBlocked(AuditEvent):
    """A guardrail blocked a message from being delivered."""

    sender_id: str = ""
    subject: str = ""
    payload_hash: str = ""
    reason: str = ""


# ---------------------------------------------------------------------------
# Cognition
# ---------------------------------------------------------------------------
@dataclass(frozen=True, slots=True)
class ConfidenceComputed(AuditEvent):
    """A :class:`ConfidenceReport` was produced for an LLM action."""

    agent_id: str = ""
    target_id: str = ""
    confidence: float = 0.0
    semantic_entropy: float = 0.0
    vix: float = 0.0
    sharpe: float = 0.0
    dissociation: float = 0.0
    sources: tuple[str, ...] = ()


@dataclass(frozen=True, slots=True)
class PolicyDecided(AuditEvent):
    """A :class:`ConfidencePolicy` returned a decision for a report."""

    agent_id: str = ""
    target_id: str = ""
    decision: str = ""  # PolicyDecision.value
    confidence: float = 0.0
    threshold_tau: float = 0.0


@dataclass(frozen=True, slots=True)
class ResearchRequested(AuditEvent):
    """Confidence dropped below the policy threshold; research dispatched."""

    requesting_agent: str = ""
    confidence: float = 0.0
    threshold: float = 0.0
    query: str = ""


@dataclass(frozen=True, slots=True)
class AbstentionEmitted(AuditEvent):
    """A guardrail returned a refusal in place of an LLM answer."""

    agent_id: str = ""
    reason: str = ""
    domain: str = ""


# ---------------------------------------------------------------------------
# Tools
# ---------------------------------------------------------------------------
@dataclass(frozen=True, slots=True)
class ToolInvoked(AuditEvent):
    agent_id: str = ""
    tool_name: str = ""
    args_hash: str = ""


@dataclass(frozen=True, slots=True)
class ToolResulted(AuditEvent):
    agent_id: str = ""
    tool_name: str = ""
    result_hash: str = ""
    duration_ms: float = 0.0


@dataclass(frozen=True, slots=True)
class ToolFailed(AuditEvent):
    agent_id: str = ""
    tool_name: str = ""
    error: str = ""


# ---------------------------------------------------------------------------
# Errors
# ---------------------------------------------------------------------------
@dataclass(frozen=True, slots=True)
class ErrorRaised(AuditEvent):
    """An unhandled exception escaped a guardrail or wrapped agent."""

    agent_id: str = ""
    error_class: str = ""
    message: str = ""
    stack_hash: str = ""


__all__ = [
    "AbstentionEmitted",
    "AuditEvent",
    "ConfidenceComputed",
    "ErrorRaised",
    "EventId",
    "GuardrailAttached",
    "GuardrailDetached",
    "MessageBlocked",
    "MessageInspected",
    "PolicyDecided",
    "ResearchRequested",
    "ToolFailed",
    "ToolInvoked",
    "ToolResulted",
]
