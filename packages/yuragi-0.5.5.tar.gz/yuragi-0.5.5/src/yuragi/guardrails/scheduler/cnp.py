"""Contract Net Protocol scheduler with reputation fallback.

The Contract Net Protocol is a classic decentralised task-allocation
pattern from Smith (1980): a manager *announces* a task on a public
channel, candidate workers *bid* with their cost estimate, the manager
*awards* the task to the lowest bidder. The guardrails runtime uses
CNP because it has no single scheduling authority, which lines up with
the "no central orchestrator" goal.

The wrinkle: pure CNP can deadlock when all candidates are too busy
to bid, so we wrap it with a 2-second timeout that falls back to a
reputation-based assignment from :class:`ReputationTable`.

Origin: ported from ``dacm.scheduler.cnp`` (2026-04-11).
"""

from __future__ import annotations

import asyncio
import uuid
from dataclasses import dataclass

from .reputation import ReputationTable


@dataclass(frozen=True, slots=True)
class Bid:
    bidder: str
    cost_estimate: float
    confidence: float = 0.0


@dataclass(frozen=True, slots=True)
class Award:
    task_id: str
    awardee: str
    via: str  # "cnp" or "reputation_fallback"


class ContractNetScheduler:
    """Decentralised task awarding with bid timeout + reputation fallback."""

    def __init__(
        self,
        *,
        bid_timeout_s: float = 2.0,
        reputation: ReputationTable | None = None,
    ) -> None:
        self.bid_timeout_s = bid_timeout_s
        self.reputation = reputation or ReputationTable()
        self._open_auctions: dict[str, asyncio.Queue[Bid]] = {}

    def open_auction(self) -> str:
        task_id = uuid.uuid4().hex
        self._open_auctions[task_id] = asyncio.Queue()
        return task_id

    async def submit_bid(self, task_id: str, bid: Bid) -> None:
        queue = self._open_auctions.get(task_id)
        if queue is None:
            return
        await queue.put(bid)

    async def collect_bids(self, task_id: str) -> list[Bid]:
        queue = self._open_auctions.get(task_id)
        if queue is None:
            return []
        bids: list[Bid] = []
        end = asyncio.get_event_loop().time() + self.bid_timeout_s
        while True:
            remaining = end - asyncio.get_event_loop().time()
            if remaining <= 0:
                break
            try:
                bid = await asyncio.wait_for(queue.get(), timeout=remaining)
                bids.append(bid)
            except TimeoutError:
                break
        return bids

    def award(
        self,
        task_id: str,
        bids: list[Bid],
        candidates: list[str] | None = None,
    ) -> Award:
        if bids:
            winner = min(bids, key=lambda b: (b.cost_estimate, -b.confidence))
            return Award(task_id=task_id, awardee=winner.bidder, via="cnp")
        # Fallback: highest reputation among the announced candidates.
        fallback = self.reputation.best(candidates or [])
        return Award(
            task_id=task_id,
            awardee=fallback or "",
            via="reputation_fallback",
        )

    def close_auction(self, task_id: str) -> None:
        self._open_auctions.pop(task_id, None)
