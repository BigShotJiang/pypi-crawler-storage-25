"""Reputation table — fallback assignment when CNP bidding times out.

Origin: ported from ``dacm.scheduler.reputation`` (2026-04-11).
"""

from __future__ import annotations

from collections import defaultdict
from dataclasses import dataclass, field


@dataclass
class ReputationTable:
    """Per-agent rolling success / failure counts.

    Used as the fallback target when the Contract Net auction times
    out without enough bids: the scheduler picks the agent with the
    highest success ratio for the requested capability.
    """

    successes: dict[str, int] = field(
        default_factory=lambda: defaultdict(int)
    )
    failures: dict[str, int] = field(
        default_factory=lambda: defaultdict(int)
    )

    def record_success(self, agent_id: str) -> None:
        self.successes[agent_id] += 1

    def record_failure(self, agent_id: str) -> None:
        self.failures[agent_id] += 1

    def score(self, agent_id: str) -> float:
        s = self.successes[agent_id]
        f = self.failures[agent_id]
        if s + f == 0:
            return 0.5  # neutral prior
        return s / (s + f)

    def best(self, candidates: list[str]) -> str | None:
        if not candidates:
            return None
        return max(candidates, key=self.score)
