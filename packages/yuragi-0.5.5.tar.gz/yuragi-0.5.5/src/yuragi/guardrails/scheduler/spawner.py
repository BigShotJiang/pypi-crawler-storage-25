"""Dynamic agent spawning — the "agent metabolism" the README promises.

When the :class:`MetaAgent` observes that incoming task complexity
exceeds a threshold, it asks the spawner to bring up additional
workers. The default heuristic is ``ceil(log2(complexity_score))``: a
complexity-1 task gets one worker, complexity-32 gets five,
complexity-1024 gets ten. The exact curve is meant to be overridden
in subclasses or via the ``policy`` callable.

Origin: ported from ``dacm.scheduler.spawner`` (2026-04-11).
"""

from __future__ import annotations

import math
from collections.abc import Callable
from dataclasses import dataclass, field
from typing import TYPE_CHECKING

from ..kernel.actor import Actor

if TYPE_CHECKING:
    from ..kernel.lifecycle import Runtime


def _log2_policy(complexity: float) -> int:
    if complexity <= 1.0:
        return 1
    return max(1, math.ceil(math.log2(complexity)))


@dataclass
class AgentSpawner:
    """Brings up *N* workers in response to observed task complexity."""

    runtime: Runtime
    worker_class: type[Actor]
    name_prefix: str = "worker"
    policy: Callable[[float], int] = field(default=_log2_policy)

    async def scale_for(
        self,
        complexity: float,
        *,
        spawn_reason: str = "complexity",
    ) -> list[str]:
        n = self.policy(complexity)
        names: list[str] = []
        for _ in range(n):
            actor = await self.runtime.spawn(
                self.worker_class,
                name=f"{self.name_prefix}-{self.runtime.agent_count + 1}",
                spawn_reason=spawn_reason,
            )
            names.append(actor.id)
        return names
