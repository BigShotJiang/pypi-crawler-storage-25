"""Runtime event vocabulary for the guardrails kernel.

Distinct from :mod:`yuragi.guardrails.audit.events` (which records
*guardrail-level* decisions). This module defines the *runtime-level*
events the actor mesh emits: lifecycle, messaging, cognition, tools,
contract-net tasks, snapshots, and errors.
"""

from __future__ import annotations

from .events import (
    AgentHalted,
    AgentSpawned,
    CheckpointCreated,
    CheckpointRestored,
    DeadLetter,
    ErrorRaised,
    EventVisitor,
    MessageDelivered,
    MessageReceived,
    MessageSent,
    RuntimeConfidenceComputed,
    RuntimeEvent,
    RuntimeResearchRequested,
    RuntimeToolFailed,
    RuntimeToolInvoked,
    RuntimeToolResulted,
    SnapshotForked,
    StateMutated,
    TaskAnnounced,
    TaskAwarded,
    TaskBidPlaced,
    TaskCompleted,
    TaskFailed,
    ThoughtRecorded,
)

__all__ = [
    "AgentHalted",
    "AgentSpawned",
    "CheckpointCreated",
    "CheckpointRestored",
    "DeadLetter",
    "ErrorRaised",
    "EventVisitor",
    "MessageDelivered",
    "MessageReceived",
    "MessageSent",
    "RuntimeConfidenceComputed",
    "RuntimeEvent",
    "RuntimeResearchRequested",
    "RuntimeToolFailed",
    "RuntimeToolInvoked",
    "RuntimeToolResulted",
    "SnapshotForked",
    "StateMutated",
    "TaskAnnounced",
    "TaskAwarded",
    "TaskBidPlaced",
    "TaskCompleted",
    "TaskFailed",
    "ThoughtRecorded",
]
