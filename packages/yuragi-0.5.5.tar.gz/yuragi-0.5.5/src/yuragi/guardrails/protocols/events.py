"""Runtime event vocabulary — what the kernel emits.

The guardrails kernel is event-sourced: every meaningful action (an
agent spawned, a message sent, a thought recorded, a tool invoked, a
snapshot forked, a checkpoint created) is appended to an audit log as
one of the :class:`RuntimeEvent` subclasses defined here. Replay =
applying these events to a fresh projection in order; the audit log's
hash chain detects tampering.

All events are immutable frozen dataclasses.

Origin: ported from ``dacm.protocols.events`` (2026-04-11). Renamed
``DACMEvent`` → :class:`RuntimeEvent` to distinguish it from the
guardrail-level :class:`yuragi.guardrails.audit.events.AuditEvent`
vocabulary (which records *decisions*, not *runtime mechanics*).
"""

from __future__ import annotations

import time
import uuid
from dataclasses import dataclass, field
from typing import Any, Protocol, runtime_checkable

EventId = str


def _new_id() -> str:
    return uuid.uuid4().hex


def _now_ns() -> int:
    return time.time_ns()


@dataclass(frozen=True, slots=True)
class RuntimeEvent:
    """Base class for every event in the guardrails runtime.

    Subclasses are frozen dataclasses with ``slots=True`` so they
    behave as value objects. The base carries the runtime fields every
    event has: a UUID hex ``event_id``, a nanosecond-precision
    timestamp, a Lamport clock for partial ordering, and a free-form
    ``trace_id`` for end-to-end request tracing.
    """

    event_id: EventId = field(default_factory=_new_id)
    ts_ns: int = field(default_factory=_now_ns)
    lamport: int = 0
    trace_id: str = ""


# ---------------------------------------------------------------------------
# Lifecycle
# ---------------------------------------------------------------------------
@dataclass(frozen=True, slots=True)
class AgentSpawned(RuntimeEvent):
    """A new actor has been admitted to the runtime."""

    agent_id: str = ""
    agent_class: str = ""
    parent_id: str | None = None
    spawn_reason: str = ""


@dataclass(frozen=True, slots=True)
class AgentHalted(RuntimeEvent):
    """An actor has been removed from the runtime."""

    agent_id: str = ""
    reason: str = ""


# ---------------------------------------------------------------------------
# Messaging
# ---------------------------------------------------------------------------
@dataclass(frozen=True, slots=True)
class MessageSent(RuntimeEvent):
    """A message left an actor's mailbox toward the bus."""

    sender_id: str = ""
    subject: str = ""
    payload_hash: str = ""
    confidence: float | None = None


@dataclass(frozen=True, slots=True)
class MessageDelivered(RuntimeEvent):
    """The bus delivered a message to one or more subscribers."""

    subject: str = ""
    payload_hash: str = ""
    receiver_count: int = 0


@dataclass(frozen=True, slots=True)
class MessageReceived(RuntimeEvent):
    """An actor accepted a message off its mailbox."""

    receiver_id: str = ""
    subject: str = ""
    payload_hash: str = ""


@dataclass(frozen=True, slots=True)
class DeadLetter(RuntimeEvent):
    """A message could not be delivered (no subscriber, or all errored)."""

    subject: str = ""
    payload_hash: str = ""
    reason: str = ""


# ---------------------------------------------------------------------------
# Cognition
# ---------------------------------------------------------------------------
@dataclass(frozen=True, slots=True)
class ThoughtRecorded(RuntimeEvent):
    """An actor wrote an internal reasoning step (chain-of-thought log)."""

    agent_id: str = ""
    thought_hash: str = ""
    summary: str = ""


@dataclass(frozen=True, slots=True)
class RuntimeConfidenceComputed(RuntimeEvent):
    """A :class:`ConfidenceReport` was produced for a particular agent action."""

    agent_id: str = ""
    target_id: str = ""
    confidence: float = 0.0
    semantic_entropy: float = 0.0
    vix: float = 0.0
    sharpe: float = 0.0
    dissociation: float = 0.0
    sources: tuple[str, ...] = ()


@dataclass(frozen=True, slots=True)
class RuntimeResearchRequested(RuntimeEvent):
    """Confidence dropped below the policy threshold; researcher dispatched."""

    requesting_agent: str = ""
    confidence: float = 0.0
    threshold: float = 0.0
    query: str = ""


# ---------------------------------------------------------------------------
# Tools
# ---------------------------------------------------------------------------
@dataclass(frozen=True, slots=True)
class RuntimeToolInvoked(RuntimeEvent):
    agent_id: str = ""
    tool_name: str = ""
    args_hash: str = ""


@dataclass(frozen=True, slots=True)
class RuntimeToolResulted(RuntimeEvent):
    agent_id: str = ""
    tool_name: str = ""
    result_hash: str = ""
    duration_ms: float = 0.0


@dataclass(frozen=True, slots=True)
class RuntimeToolFailed(RuntimeEvent):
    agent_id: str = ""
    tool_name: str = ""
    error: str = ""


# ---------------------------------------------------------------------------
# Tasks (Contract Net Protocol)
# ---------------------------------------------------------------------------
@dataclass(frozen=True, slots=True)
class TaskAnnounced(RuntimeEvent):
    task_id: str = ""
    requester: str = ""
    description: str = ""
    deadline_ns: int = 0


@dataclass(frozen=True, slots=True)
class TaskBidPlaced(RuntimeEvent):
    task_id: str = ""
    bidder: str = ""
    cost_estimate: float = 0.0
    confidence: float = 0.0


@dataclass(frozen=True, slots=True)
class TaskAwarded(RuntimeEvent):
    task_id: str = ""
    awardee: str = ""
    via: str = "cnp"   # "cnp" or "reputation_fallback"


@dataclass(frozen=True, slots=True)
class TaskCompleted(RuntimeEvent):
    task_id: str = ""
    awardee: str = ""
    result_hash: str = ""


@dataclass(frozen=True, slots=True)
class TaskFailed(RuntimeEvent):
    task_id: str = ""
    awardee: str = ""
    error: str = ""


# ---------------------------------------------------------------------------
# State, snapshots, errors
# ---------------------------------------------------------------------------
@dataclass(frozen=True, slots=True)
class StateMutated(RuntimeEvent):
    agent_id: str = ""
    state_hash: str = ""
    keys_changed: tuple[str, ...] = ()


@dataclass(frozen=True, slots=True)
class SnapshotForked(RuntimeEvent):
    parent_root: str = ""
    new_root: str = ""
    reason: str = ""


@dataclass(frozen=True, slots=True)
class CheckpointCreated(RuntimeEvent):
    root_hash: str = ""
    n_agents: int = 0
    bytes_total: int = 0


@dataclass(frozen=True, slots=True)
class CheckpointRestored(RuntimeEvent):
    root_hash: str = ""
    duration_ms: float = 0.0


@dataclass(frozen=True, slots=True)
class ErrorRaised(RuntimeEvent):
    agent_id: str = ""
    error_class: str = ""
    message: str = ""
    stack_hash: str = ""


# ---------------------------------------------------------------------------
# Visitor
# ---------------------------------------------------------------------------
@runtime_checkable
class EventVisitor(Protocol):
    """Optional visitor interface for projection / replay code."""

    def visit(self, event: RuntimeEvent) -> Any:  # pragma: no cover - protocol
        ...
