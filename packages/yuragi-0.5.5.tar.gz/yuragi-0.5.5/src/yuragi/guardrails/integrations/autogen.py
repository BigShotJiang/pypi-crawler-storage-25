"""AutoGen integration — wrap a confidence-aware guardrail around any AutoGen agent.

This module is import-light: it defines the wrapper at module load
time but ``pyautogen`` itself is only imported inside
:class:`AutoGenGuardrail` so the rest of the guardrails subsystem
remains usable without the optional ``guardrails-autogen`` extra.

Usage
-----
.. code-block:: python

    from yuragi.guardrails import ConfidencePolicy, ConfidenceReport
    from yuragi.guardrails.integrations.autogen import AutoGenGuardrail

    guard = AutoGenGuardrail(
        agent=my_autogen_agent,
        policy=ConfidencePolicy(tau=0.6),
        measure=lambda msg: ConfidenceReport(confidence=0.8),
        on_research=lambda msg, report: my_research_agent.handle(msg),
    )
    response = guard.generate_reply(messages=[...])
"""

from __future__ import annotations

import logging
from collections.abc import Callable
from typing import TYPE_CHECKING, Any

from .._types import ConfidenceReport, PolicyDecision
from ..policy import ConfidencePolicy

if TYPE_CHECKING:  # pragma: no cover
    from autogen import ConversableAgent

logger = logging.getLogger(__name__)

MeasureFn = Callable[[str | dict[str, Any]], ConfidenceReport]
EscalationFn = Callable[[Any, ConfidenceReport], Any]


class AutoGenGuardrail:
    """Confidence-aware wrapper around an AutoGen :class:`ConversableAgent`.

    The wrapper intercepts every reply the inner agent produces, runs
    the user-supplied ``measure`` callback to obtain a
    :class:`ConfidenceReport`, then dispatches on the policy decision:

    * ``ACCEPT``   — return the reply unchanged.
    * ``RESEARCH`` — call ``on_research`` (if provided) and return its
      result, otherwise return the reply with a low-confidence warning
      prefix.
    * ``REJECT``   — return ``abstention_message`` (defaults to a polite
      refusal).

    Parameters
    ----------
    agent
        The wrapped AutoGen agent. Any object exposing a
        ``generate_reply(messages, sender=None, **kwargs)`` method is
        accepted; AutoGen's own ``ConversableAgent`` satisfies this.
    measure
        Callback that takes the message about to be returned and
        produces a :class:`ConfidenceReport`. The user supplies this
        because the *right* way to measure confidence depends on the
        provider (logprobs, ensemble, perturbation, …).
    policy
        :class:`ConfidencePolicy` used to route on the report. Defaults
        to a fresh policy with library defaults.
    on_research
        Optional escalation callback invoked when the policy returns
        ``RESEARCH``. Signature ``(reply, report) -> reply``. When
        ``None``, the original reply is returned with a
        low-confidence prefix.
    abstention_message
        Returned when the policy returns ``REJECT``.
    """

    __slots__ = (
        "abstention_message",
        "agent",
        "measure",
        "on_research",
        "policy",
    )

    def __init__(
        self,
        *,
        agent: ConversableAgent,
        measure: MeasureFn,
        policy: ConfidencePolicy | None = None,
        on_research: EscalationFn | None = None,
        abstention_message: str = (
            "I am not confident enough to answer this reliably. "
            "Please rephrase the question or consult a domain expert."
        ),
    ) -> None:
        self.agent = agent
        self.measure = measure
        self.policy = policy or ConfidencePolicy()
        self.on_research = on_research
        self.abstention_message = abstention_message

    def generate_reply(
        self,
        messages: list[dict[str, Any]] | None = None,
        sender: Any = None,
        **kwargs: Any,
    ) -> str | dict[str, Any]:
        """Drop-in replacement for :meth:`ConversableAgent.generate_reply`."""
        reply = self.agent.generate_reply(messages=messages, sender=sender, **kwargs)
        if reply is None:
            return reply  # type: ignore[return-value]

        report = self.measure(reply)
        decision = self.policy.decide(report)

        if decision == PolicyDecision.ACCEPT:
            return reply
        if decision == PolicyDecision.REJECT:
            logger.info(
                "AutoGenGuardrail rejected reply: c=%.3f d=%.3f",
                report.confidence, report.dissociation,
            )
            return self.abstention_message
        # RESEARCH
        logger.info(
            "AutoGenGuardrail escalating to research: c=%.3f d=%.3f",
            report.confidence, report.dissociation,
        )
        if self.on_research is not None:
            return self.on_research(reply, report)
        prefix = f"[low-confidence={report.confidence:.2f}] "
        if isinstance(reply, str):
            return prefix + reply
        return reply
