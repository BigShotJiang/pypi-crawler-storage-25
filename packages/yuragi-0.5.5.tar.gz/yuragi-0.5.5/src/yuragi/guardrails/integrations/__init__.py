"""Optional integrations with third-party agent frameworks.

Each submodule is import-light: the third-party dependency is only
loaded inside the integration class so the rest of the guardrails
subsystem remains usable without the optional extras.

Available integrations:

* :mod:`yuragi.guardrails.integrations.autogen` —
  :class:`AutoGenGuardrail` (requires ``yuragi[guardrails-autogen]``).
* :mod:`yuragi.guardrails.integrations.langgraph` —
  :func:`guardrail_node` (no third-party dependency required; uses
  LangGraph's function-of-state convention only).
"""

from __future__ import annotations
