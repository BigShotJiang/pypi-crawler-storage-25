"""LangGraph integration — drop a confidence-aware guardrail node into any
LangGraph state graph.

This module exposes a single helper, :func:`guardrail_node`, that
returns a callable suitable for use as a LangGraph node. The node
reads a configurable key out of the graph state, runs the user
``measure`` callback to obtain a :class:`ConfidenceReport`, then sets
the policy decision into another configurable key so downstream edges
can route on it via LangGraph's standard conditional-edge mechanism.

The integration imports nothing from ``langgraph`` itself; it only
depends on the function-of-state convention LangGraph uses, so it can
be wired into any graph without a runtime dependency.

Usage
-----
.. code-block:: python

    from langgraph.graph import StateGraph, END
    from yuragi.guardrails import ConfidencePolicy, ConfidenceReport
    from yuragi.guardrails.integrations.langgraph import guardrail_node

    def measure(state: dict) -> ConfidenceReport:
        return ConfidenceReport(confidence=0.8)

    graph = StateGraph(dict)
    graph.add_node("agent", my_agent)
    graph.add_node("guardrail", guardrail_node(measure=measure))
    graph.add_node("research", my_research_agent)

    graph.add_edge("agent", "guardrail")
    graph.add_conditional_edges(
        "guardrail",
        lambda s: s["guardrail_decision"],
        {"accept": END, "research": "research", "reject": END},
    )
"""

from __future__ import annotations

import logging
from collections.abc import Callable
from typing import Any

from .._types import ConfidenceReport
from ..policy import ConfidencePolicy

logger = logging.getLogger(__name__)

StateMeasureFn = Callable[[dict[str, Any]], ConfidenceReport]
NodeFn = Callable[[dict[str, Any]], dict[str, Any]]


def guardrail_node(
    *,
    measure: StateMeasureFn,
    policy: ConfidencePolicy | None = None,
    decision_key: str = "guardrail_decision",
    report_key: str = "guardrail_report",
) -> NodeFn:
    """Build a LangGraph-compatible guardrail node.

    Parameters
    ----------
    measure
        Callback that takes the current LangGraph state and produces a
        :class:`ConfidenceReport`.
    policy
        :class:`ConfidencePolicy` used to route on the report. Defaults
        to a fresh policy with library defaults.
    decision_key
        Key in the returned state-update dict that holds the
        :class:`PolicyDecision` value (``"accept"`` / ``"research"`` /
        ``"reject"``). Use this key in your conditional edges.
    report_key
        Key in the returned state-update dict that holds the full
        :class:`ConfidenceReport` for downstream nodes that want to
        inspect raw signals.

    Returns
    -------
    NodeFn
        A function ``(state) -> {decision_key, report_key}`` suitable
        for ``StateGraph.add_node``.
    """
    pol = policy or ConfidencePolicy()

    def _node(state: dict[str, Any]) -> dict[str, Any]:
        report = measure(state)
        decision = pol.decide(report)
        logger.debug(
            "langgraph guardrail node: decision=%s c=%.3f d=%.3f",
            decision.value, report.confidence, report.dissociation,
        )
        return {decision_key: decision.value, report_key: report}

    return _node
