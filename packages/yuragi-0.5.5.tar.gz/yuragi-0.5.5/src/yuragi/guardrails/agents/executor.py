"""ExecutorAgent — performs the work and emits a :class:`ConfidenceReport`.

In the smoke demo the executor produces a deterministic stub answer
plus a synthetic :class:`ConfidenceReport` so the rest of the routing
logic (critic / researcher dispatch) can be exercised without an LLM.
Real executors will subclass and replace ``compute()``.

Origin: ported from ``dacm.agents.executor`` (2026-04-11).
"""

from __future__ import annotations

from typing import Any

from ..kernel.envelope import Envelope
from .base import GuardrailAgent


class ExecutorAgent(GuardrailAgent):
    """Default executor — synthetic compute + fused confidence report.

    Parameters
    ----------
    max_iterations
        Hard cap on the number of times the executor will respond to
        ``executor.in`` messages. Default ``8`` is enough for the smoke
        pipeline + a couple of research escalations; production
        subclasses should raise it explicitly.
    """

    def __init__(
        self,
        *,
        max_iterations: int = 8,
        **kwargs: Any,
    ) -> None:
        super().__init__(**kwargs)
        self.max_iterations = max_iterations
        self._iterations = 0

    async def compute(self, task: str) -> tuple[str, dict[str, float]]:
        """Return ``(answer, signals)``. Override to call an LLM.

        The default stub returns a fixed synthetic answer plus a
        mid-range signal vector so the smoke pipeline runs offline.
        """
        return (
            f"answer-for({task})",
            {
                "semantic_entropy": 1.6,
                "vix": 22.0,
                "sharpe": 0.6,
                "dissociation": 0.15,
            },
        )

    async def handle(self, envelope: Envelope) -> None:
        if not isinstance(envelope.payload, dict):
            return
        if self._iterations >= self.max_iterations:
            # Prevents the synthetic-stub Executor → Critic → Researcher
            # loop from spinning forever in demos.
            return
        self._iterations += 1
        task: Any = envelope.payload.get("task", "")
        answer, signals = await self.compute(str(task))
        report = self.confidence_fuser.fuse(
            semantic_entropy=signals["semantic_entropy"],
            vix=signals["vix"],
            sharpe=signals["sharpe"],
            dissociation=signals["dissociation"],
            sources=("executor.stub",),
        )
        await self.publish_with_confidence(
            "critic.in",
            answer,
            report=report,
        )
