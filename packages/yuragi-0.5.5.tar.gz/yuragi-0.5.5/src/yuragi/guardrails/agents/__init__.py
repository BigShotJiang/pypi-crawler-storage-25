"""Specialised actors that ship with the guardrails runtime.

These are deliberately thin reference implementations — they exist so
the smoke pipeline runs without an LLM and so users have a starting
template to subclass. Every method is a stub that returns a synthetic
value; production deployments swap them for LLM-backed subclasses.
"""

from __future__ import annotations

from .base import GuardrailAgent
from .critic import CriticAgent
from .executor import ExecutorAgent
from .meta import MetaAgent
from .planner import PlannerAgent
from .researcher import ResearcherAgent
from .verifier import VerifierAgent

__all__ = [
    "CriticAgent",
    "ExecutorAgent",
    "GuardrailAgent",
    "MetaAgent",
    "PlannerAgent",
    "ResearcherAgent",
    "VerifierAgent",
]
