"""PlannerAgent — turns a task description into an Executor work item.

The default implementation is intentionally trivial: it tags the task
with a synthetic complexity score so the smoke pipeline has something
to feed the spawner with. Real planners will subclass and call into
an LLM.

Origin: ported from ``dacm.agents.planner`` (2026-04-11).
"""

from __future__ import annotations

from ..kernel.envelope import Envelope
from .base import GuardrailAgent


class PlannerAgent(GuardrailAgent):
    """Default planner — extract task + complexity, forward to ``executor.in``."""

    async def handle(self, envelope: Envelope) -> None:
        payload = envelope.payload
        if isinstance(payload, dict):
            task = payload.get("task")
            complexity = float(payload.get("complexity", 4.0))
        else:
            task = str(payload)
            complexity = 4.0
        await self.publish(
            "executor.in",
            {"task": task, "complexity": complexity},
        )
