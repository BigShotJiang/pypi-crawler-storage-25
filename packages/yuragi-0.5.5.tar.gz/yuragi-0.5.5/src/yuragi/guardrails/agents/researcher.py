"""ResearcherAgent — fired when confidence is too low to accept a result.

The default implementation echoes the query into the audit log as a
:class:`RuntimeResearchRequested` event and publishes a placeholder
"researched" payload back into the executor's input subject. Real
implementations will swap ``research()`` for a RAG / web-search call.

Origin: ported from ``dacm.agents.researcher`` (2026-04-11).
"""

from __future__ import annotations

from typing import Any

from ..kernel.envelope import Envelope
from ..protocols.events import RuntimeResearchRequested
from .base import GuardrailAgent


class ResearcherAgent(GuardrailAgent):
    """Default researcher — echo + grounded-fact stub."""

    async def research(self, query: Any) -> str:
        return f"grounded-fact-for({query})"

    async def handle(self, envelope: Envelope) -> None:
        if not isinstance(envelope.payload, dict):
            return
        query = envelope.payload.get("query")
        confidence = float(envelope.payload.get("confidence", 0.0))
        await self.runtime.record_event(
            RuntimeResearchRequested(
                requesting_agent=self.id,
                confidence=confidence,
                threshold=0.55,
                query=str(query),
            )
        )
        result = await self.research(query)
        await self.publish(
            "executor.in",
            {"task": result, "complexity": 1.0},
        )
