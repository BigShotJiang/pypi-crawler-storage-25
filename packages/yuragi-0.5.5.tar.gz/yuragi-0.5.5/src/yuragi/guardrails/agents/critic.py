"""CriticAgent — routes on confidence.

* ``ACCEPT``  → publishes the value to ``verifier.in``.
* ``RESEARCH`` → publishes the original query to ``researcher.in``.
* ``REJECT``  → publishes a dead-letter to ``critic.dead``.

Origin: ported from ``dacm.agents.critic`` (2026-04-11).
"""

from __future__ import annotations

from .._types import ConfidenceReport, PolicyDecision
from ..kernel.envelope import Envelope
from ..policy import ConfidencePolicy
from .base import GuardrailAgent


class CriticAgent(GuardrailAgent):
    """Threshold-based confidence critic."""

    def __init__(self, policy: ConfidencePolicy | None = None) -> None:
        super().__init__()
        self.policy = policy or ConfidencePolicy()

    async def handle(self, envelope: Envelope) -> None:
        if not isinstance(envelope.payload, dict):
            return
        report_dict = envelope.payload.get("report") or {}
        report = ConfidenceReport(
            confidence=float(report_dict.get("confidence", 0.0)),
            semantic_entropy=float(report_dict.get("semantic_entropy", 0.0)),
            vix=float(report_dict.get("vix", 0.0)),
            sharpe=float(report_dict.get("sharpe", 0.0)),
            dissociation=float(report_dict.get("dissociation", 0.0)),
            sources=tuple(report_dict.get("sources", ())),
        )
        decision = self.policy.decide(report)
        if decision == PolicyDecision.ACCEPT:
            await self.publish("verifier.in", envelope.payload)
        elif decision == PolicyDecision.RESEARCH:
            await self.publish(
                "researcher.in",
                {
                    "query": envelope.payload.get("value"),
                    "confidence": report.confidence,
                    "reason": "low_confidence",
                },
            )
        else:
            await self.publish("critic.dead", envelope.payload)
