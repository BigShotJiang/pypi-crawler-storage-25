"""MetaAgent — observes complexity and asks the spawner to scale.

Origin: ported from ``dacm.agents.meta`` (2026-04-11).
"""

from __future__ import annotations

from typing import TYPE_CHECKING

from ..kernel.envelope import Envelope
from .base import GuardrailAgent

if TYPE_CHECKING:
    from ..scheduler.spawner import AgentSpawner


class MetaAgent(GuardrailAgent):
    """Default meta-agent — drives :class:`AgentSpawner` from incoming load."""

    def __init__(self, spawner: AgentSpawner | None = None) -> None:
        super().__init__()
        self.spawner = spawner

    async def handle(self, envelope: Envelope) -> None:
        if self.spawner is None:
            return
        if isinstance(envelope.payload, dict):
            complexity = float(envelope.payload.get("complexity", 1.0))
            spawned = await self.spawner.scale_for(complexity)
            await self.publish("meta.scaled", {"workers": spawned})
