"""VerifierAgent — final acceptance check before a result is published.

Origin: ported from ``dacm.agents.verifier`` (2026-04-11).
"""

from __future__ import annotations

from ..kernel.envelope import Envelope
from .base import GuardrailAgent


class VerifierAgent(GuardrailAgent):
    """Default verifier — emit the value on ``verifier.out``."""

    async def handle(self, envelope: Envelope) -> None:
        if isinstance(envelope.payload, dict):
            value = envelope.payload.get("value")
            await self.publish("verifier.out", {"verified": value})
