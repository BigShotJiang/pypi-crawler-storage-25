"""GuardrailAgent — base class for the bundled actors.

Adds two pieces of optional plumbing on top of the kernel
:class:`Actor`: a :class:`ConfidenceFuser` handle and a small helper
to publish a payload *with* its :class:`ConfidenceReport` attached.
Subclasses are free to ignore both and behave as raw actors.

Origin: ported from ``dacm.agents.base`` (2026-04-11). Renamed
``DACMAgent`` → :class:`GuardrailAgent`; the ``confidence_engine``
slot is now ``confidence_fuser`` to align with the yuragi naming.
"""

from __future__ import annotations

from typing import Any

from .._types import ConfidenceReport
from ..fuse import ConfidenceFuser
from ..kernel.actor import Actor
from ..kernel.envelope import Envelope


class GuardrailAgent(Actor):
    """Base for the specialised guardrails agents."""

    def __init__(self, *, confidence_fuser: ConfidenceFuser | None = None) -> None:
        super().__init__()
        self.confidence_fuser = confidence_fuser or ConfidenceFuser()

    async def publish_with_confidence(
        self,
        subject: str,
        payload: Any,
        *,
        report: ConfidenceReport,
    ) -> Envelope:
        """Publish ``payload`` together with its :class:`ConfidenceReport`.

        Convenience for agents so downstream subscribers (typically a
        :class:`CriticAgent`) can route on confidence without re-running
        the fuser.
        """
        return await self.publish(
            subject,
            {
                "value": payload,
                "confidence": report.confidence,
                "report": {
                    "confidence": report.confidence,
                    "semantic_entropy": report.semantic_entropy,
                    "vix": report.vix,
                    "sharpe": report.sharpe,
                    "dissociation": report.dissociation,
                    "sources": list(report.sources),
                },
            },
            confidence=report.confidence,
        )
