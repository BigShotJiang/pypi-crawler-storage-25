"""Functional routing helper around :class:`ConfidencePolicy`.

Provides a one-liner ``route_on_confidence`` that the AutoGen and
LangGraph integrations call directly. Keeping the routing logic in a
module-level function — rather than buried inside a class hierarchy —
lets users wire it into any framework without subclassing yuragi
abstractions.
"""

from __future__ import annotations

import logging
from collections.abc import Awaitable, Callable
from typing import TypeVar

from ._types import ConfidenceReport, PolicyDecision
from .policy import ConfidencePolicy

logger = logging.getLogger(__name__)

T = TypeVar("T")


def route_on_confidence(
    report: ConfidenceReport,
    *,
    policy: ConfidencePolicy | None = None,
    on_accept: Callable[[], T] | None = None,
    on_research: Callable[[], T] | None = None,
    on_reject: Callable[[], T] | None = None,
) -> T | PolicyDecision:
    """Dispatch on the policy decision for ``report``.

    When the matching ``on_*`` callback is supplied it is invoked and
    its return value is propagated. When it is ``None`` the
    :class:`PolicyDecision` enum is returned instead, so callers can
    branch on it themselves.

    The function is intentionally synchronous so it composes with both
    sync code paths (LangChain ``RunnableLambda`` etc.) and async
    callers via :func:`route_on_confidence_async` below.
    """
    pol = policy or ConfidencePolicy()
    decision = pol.decide(report)

    if decision == PolicyDecision.ACCEPT and on_accept is not None:
        return on_accept()
    if decision == PolicyDecision.RESEARCH and on_research is not None:
        return on_research()
    if decision == PolicyDecision.REJECT and on_reject is not None:
        return on_reject()
    return decision


async def route_on_confidence_async(
    report: ConfidenceReport,
    *,
    policy: ConfidencePolicy | None = None,
    on_accept: Callable[[], Awaitable[T]] | None = None,
    on_research: Callable[[], Awaitable[T]] | None = None,
    on_reject: Callable[[], Awaitable[T]] | None = None,
) -> T | PolicyDecision:
    """Async variant of :func:`route_on_confidence`."""
    pol = policy or ConfidencePolicy()
    decision = pol.decide(report)

    if decision == PolicyDecision.ACCEPT and on_accept is not None:
        return await on_accept()
    if decision == PolicyDecision.RESEARCH and on_research is not None:
        return await on_research()
    if decision == PolicyDecision.REJECT and on_reject is not None:
        return await on_reject()
    return decision
