"""Actor base class — every guardrails agent inherits from here.

The actor model is borrowed from Akka / Erlang OTP: each actor has a
private mailbox, a private state dict, and a single ``handle()``
coroutine the runtime invokes for every delivered envelope. Actors
never share state directly — they communicate by publishing envelopes
to subjects via the runtime's bus.

The kernel is intentionally tiny — about a hundred lines of public
surface — because every concrete capability (a NATS-backed transport,
a SQLite audit log, a yuragi confidence fuser) plugs in through a
:class:`typing.Protocol` defined in its own subpackage.

Origin: ported from ``dacm.kernel.actor`` (2026-04-11).
"""

from __future__ import annotations

import abc
import asyncio
from typing import TYPE_CHECKING, Any

from .envelope import Envelope

if TYPE_CHECKING:
    from .lifecycle import Runtime


class Actor(abc.ABC):
    """Base class for every actor on the guardrails mesh.

    Subclasses must implement :meth:`handle`. They may override
    :meth:`on_start`, :meth:`on_stop`, :meth:`on_checkpoint`, and
    :meth:`on_restore` to participate in lifecycle events. The runtime
    sets ``self.runtime`` and ``self.id`` immediately after construction.
    """

    id: str = ""
    state: dict[str, Any]
    runtime: Runtime  # set by Runtime.spawn

    def __init__(self) -> None:
        self.state = {}
        self._mailbox: asyncio.Queue[Envelope] = asyncio.Queue()
        self._lamport: int = 0
        self._task: asyncio.Task[None] | None = None

    # ------------------------------------------------------------------ #
    # Public surface for subclasses
    # ------------------------------------------------------------------ #
    @abc.abstractmethod
    async def handle(self, envelope: Envelope) -> None:
        """Process a single delivered envelope. Subclasses must implement."""

    async def on_start(self) -> None:
        """Called once after the actor is admitted to the runtime."""

    async def on_stop(self) -> None:
        """Called once before the actor is removed from the runtime."""

    async def on_checkpoint(self) -> dict[str, Any]:
        """Return the actor's serialisable state for a snapshot.

        The default returns ``self.state`` as-is. Override to drop
        transient fields or to dump rich types into plain primitives.
        """
        return dict(self.state)

    async def on_restore(self, state: dict[str, Any]) -> None:
        """Reload state from a snapshot. Default replaces ``self.state``."""
        self.state = dict(state)

    async def publish(self, subject: str, payload: Any, **kwargs: Any) -> Envelope:
        """Publish a payload to a subject via the runtime's bus.

        Convenience for actors so they don't have to construct an
        :class:`Envelope` themselves. Returns the envelope that was
        sent so callers can correlate causality.
        """
        self._lamport += 1
        envelope = Envelope(
            subject=subject,
            payload=payload,
            sender_id=self.id,
            lamport=self._lamport,
            **kwargs,
        )
        await self.runtime.publish_envelope(envelope)
        return envelope

    # ------------------------------------------------------------------ #
    # Runtime interaction (called by Runtime, not by subclasses)
    # ------------------------------------------------------------------ #
    async def deliver(self, envelope: Envelope) -> None:
        """The runtime hands envelopes here. Subclasses should not call.

        Performs the standard Lamport merge: the local clock advances
        to ``max(local, incoming) + 1``.
        """
        self._lamport = max(self._lamport, envelope.lamport) + 1
        await self._mailbox.put(envelope)

    async def _run(self) -> None:
        """Internal run loop — strictly sequential by design.

        This loop awaits each :meth:`handle` call before consuming the
        next envelope from the mailbox. That serialisation matches the
        classic Akka / Erlang actor semantics — a single actor's state
        mutations are linearisable — and is intentional. If you have a
        gateway-style actor that needs to process unrelated requests in
        parallel, dispatch the heavy work into ``asyncio.create_task``
        from inside :meth:`handle`, or split the role across multiple
        actors (the spawner is happy to do this for you).
        """
        await self.on_start()
        try:
            while True:
                envelope = await self._mailbox.get()
                if envelope.subject == "__stop__":
                    break
                try:
                    await self.handle(envelope)
                except asyncio.CancelledError:
                    raise
                except Exception as exc:
                    await self.runtime.report_actor_error(self, exc, envelope)
        finally:
            await self.on_stop()

    async def stop(self) -> None:
        """Politely halt the actor by enqueueing a stop sentinel."""
        await self._mailbox.put(
            Envelope(subject="__stop__", payload=None, sender_id=self.id)
        )
