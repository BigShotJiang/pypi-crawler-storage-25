"""Message envelope — the unit of inter-actor communication.

Every message that crosses a transport is wrapped in an
:class:`Envelope`. The envelope carries the payload plus the metadata
the runtime needs for causality, tracing, and confidence-aware routing.

Origin: ported from ``dacm.kernel.envelope`` (2026-04-11). Behaviour
identical; only the docstring origin note has changed.
"""

from __future__ import annotations

import time
import uuid
from dataclasses import dataclass, field
from typing import Any


def _new_id() -> str:
    return uuid.uuid4().hex


def _now_ns() -> int:
    return time.time_ns()


@dataclass(frozen=True, slots=True)
class Envelope:
    """A message in flight on the guardrails actor mesh.

    Parameters
    ----------
    subject
        Pub/sub subject the message will be delivered on.
    payload
        Arbitrary payload — frequently a JSON-serialisable dict.
    sender_id
        ID of the actor that originated the message; ``""`` when
        published by the runtime itself.
    envelope_id
        Unique identifier (hex UUID) generated automatically.
    ts_ns
        Nanosecond-precision timestamp at construction time.
    lamport
        Lamport clock value, monotonic per-actor, merged on receipt.
    causality
        Tuple of envelope IDs that caused this envelope. Used by
        the cycle detector to spot circular bid dependencies.
    confidence
        Optional ``[0, 1]`` confidence score carried alongside the
        payload so receivers can route on confidence without
        re-running the computation.
    trace_id
        Free-form trace identifier so a single request can be followed
        end-to-end across the mesh.
    headers
        Free-form string-to-string metadata for application use.
    """

    subject: str
    payload: Any
    sender_id: str = ""
    envelope_id: str = field(default_factory=_new_id)
    ts_ns: int = field(default_factory=_now_ns)
    lamport: int = 0
    causality: tuple[str, ...] = ()
    confidence: float | None = None
    trace_id: str = ""
    headers: dict[str, str] = field(default_factory=dict)

    def with_lamport(self, lamport: int) -> Envelope:
        """Return a copy with an advanced Lamport clock."""
        return Envelope(
            subject=self.subject,
            payload=self.payload,
            sender_id=self.sender_id,
            envelope_id=self.envelope_id,
            ts_ns=self.ts_ns,
            lamport=lamport,
            causality=self.causality,
            confidence=self.confidence,
            trace_id=self.trace_id,
            headers=dict(self.headers),
        )
