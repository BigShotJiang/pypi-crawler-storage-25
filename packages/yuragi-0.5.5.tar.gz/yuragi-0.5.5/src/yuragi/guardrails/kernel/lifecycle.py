"""Runtime — the orchestrator that spawns actors and pipes events through.

The :class:`Runtime` is the only concrete component the kernel exports.
It owns:

* the bus (any :class:`~yuragi.guardrails.bus.transport.Transport`
  Protocol implementation),
* the registry of admitted actors,
* the asyncio task running each actor's ``_run`` loop,
* the optional audit log (anything implementing
  :class:`~yuragi.guardrails.audit.log.AuditSink`).

Everything else is plug-in: bring your own transport, your own audit
log, your own confidence fuser. The runtime never imports them
directly — only through Protocol surfaces.

Origin: ported from ``dacm.kernel.lifecycle`` (2026-04-11). The
``EventStore`` / ``DACMEvent`` references were renamed to
``AuditSink`` / :class:`RuntimeEvent` to align with the yuragi audit
log naming.
"""

from __future__ import annotations

import asyncio
import contextlib
import hashlib
import json
from collections.abc import AsyncIterator
from dataclasses import dataclass, field
from typing import TYPE_CHECKING, Any

from ..protocols.events import (
    AgentHalted,
    AgentSpawned,
    DeadLetter,
    ErrorRaised,
    MessageDelivered,
    MessageSent,
    RuntimeEvent,
)
from .actor import Actor
from .envelope import Envelope

if TYPE_CHECKING:
    from ..audit.log import AuditSink
    from ..bus.transport import Transport


class LifecycleError(RuntimeError):
    """Raised when the runtime is asked to do something it cannot."""


@dataclass
class _ActorRecord:
    actor: Actor
    task: asyncio.Task[None]
    name: str


@dataclass
class Runtime:
    """The guardrails event loop. Use as an async context manager.

    Parameters
    ----------
    transport
        Any object implementing the :class:`Transport` Protocol. When
        ``None``, an in-memory transport is allocated automatically on
        ``__aenter__``.
    audit_log
        Optional :class:`AuditSink`. When provided, every kernel event
        is appended to it.
    """

    transport: Transport | None = None
    audit_log: AuditSink | None = None
    _actors: dict[str, _ActorRecord] = field(default_factory=dict)
    _stack: contextlib.AsyncExitStack | None = field(default=None, init=False, repr=False)
    _lamport: int = field(default=0, init=False, repr=False)
    _started: bool = field(default=False, init=False, repr=False)

    # ------------------------------------------------------------------ #
    # Async context manager
    # ------------------------------------------------------------------ #
    async def __aenter__(self) -> Runtime:
        if self.transport is None:
            from ..bus.memory_transport import InMemoryTransport
            self.transport = InMemoryTransport()
        await self.transport.start()
        self._stack = contextlib.AsyncExitStack()
        await self._stack.__aenter__()
        self._started = True
        return self

    async def __aexit__(self, exc_type: Any, exc: Any, tb: Any) -> None:
        for record in list(self._actors.values()):
            await record.actor.stop()
        for record in list(self._actors.values()):
            with contextlib.suppress(asyncio.CancelledError):
                await record.task
        if self.transport is not None:
            await self.transport.stop()
        if self._stack is not None:
            await self._stack.__aexit__(exc_type, exc, tb)
        self._started = False

    # ------------------------------------------------------------------ #
    # Spawn / halt
    # ------------------------------------------------------------------ #
    async def spawn(
        self,
        actor_cls: type[Actor],
        *,
        name: str | None = None,
        parent_id: str | None = None,
        spawn_reason: str = "explicit",
        **init_kwargs: Any,
    ) -> Actor:
        """Construct an actor, register it, and start its run loop."""
        if not self._started:
            raise LifecycleError("Runtime not started — use `async with Runtime()`")
        actor = actor_cls(**init_kwargs)
        actor.id = name or f"{actor_cls.__name__}-{len(self._actors) + 1}"
        actor.runtime = self
        if actor.id in self._actors:
            raise LifecycleError(f"Actor name already in use: {actor.id}")

        assert self.transport is not None
        await self.transport.subscribe(actor.id, actor.deliver)

        loop = asyncio.get_running_loop()
        task = loop.create_task(actor._run(), name=f"actor:{actor.id}")
        self._actors[actor.id] = _ActorRecord(actor=actor, task=task, name=actor.id)

        await self.record_event(
            AgentSpawned(
                agent_id=actor.id,
                agent_class=actor_cls.__name__,
                parent_id=parent_id,
                spawn_reason=spawn_reason,
            )
        )
        return actor

    async def halt(self, actor_id: str, *, reason: str = "explicit") -> None:
        record = self._actors.pop(actor_id, None)
        if record is None:
            return
        await record.actor.stop()
        with contextlib.suppress(asyncio.CancelledError):
            await record.task
        await self.record_event(AgentHalted(agent_id=actor_id, reason=reason))

    # ------------------------------------------------------------------ #
    # Bus surface (called by actors)
    # ------------------------------------------------------------------ #
    async def publish_envelope(self, envelope: Envelope) -> None:
        """Forward an :class:`Envelope` onto the configured transport."""
        assert self.transport is not None
        self._lamport = max(self._lamport, envelope.lamport) + 1
        envelope = envelope.with_lamport(self._lamport)
        await self.record_event(
            MessageSent(
                sender_id=envelope.sender_id,
                subject=envelope.subject,
                payload_hash=_payload_hash(envelope.payload),
                confidence=envelope.confidence,
                lamport=envelope.lamport,
                trace_id=envelope.trace_id,
            )
        )
        n = await self.transport.publish(envelope)
        if n == 0:
            await self.record_event(
                DeadLetter(
                    subject=envelope.subject,
                    payload_hash=_payload_hash(envelope.payload),
                    reason="no subscribers",
                )
            )
        else:
            await self.record_event(
                MessageDelivered(
                    subject=envelope.subject,
                    payload_hash=_payload_hash(envelope.payload),
                    receiver_count=n,
                )
            )

    async def publish(self, subject: str, payload: Any, **kw: Any) -> Envelope:
        """Convenience for tests / orchestrators to publish without an actor."""
        envelope = Envelope(
            subject=subject,
            payload=payload,
            sender_id=kw.pop("sender_id", "runtime"),
            lamport=self._lamport + 1,
            **kw,
        )
        await self.publish_envelope(envelope)
        return envelope

    async def subscribe(self, subject: str) -> AsyncIterator[Envelope]:
        """Async iterator yielding envelopes published on ``subject``."""
        if self.transport is None:
            raise LifecycleError("Transport not configured")
        queue: asyncio.Queue[Envelope] = asyncio.Queue()

        async def _push(env: Envelope) -> None:
            await queue.put(env)

        await self.transport.subscribe(subject, _push)
        while True:
            env = await queue.get()
            yield env

    # ------------------------------------------------------------------ #
    # Event sourcing
    # ------------------------------------------------------------------ #
    async def record_event(self, event: RuntimeEvent) -> None:
        """Append a runtime event to the configured audit log (if any)."""
        if self.audit_log is not None:
            await self.audit_log.append(event)  # type: ignore[arg-type]

    async def report_actor_error(
        self, actor: Actor, exc: BaseException, envelope: Envelope,
    ) -> None:
        await self.record_event(
            ErrorRaised(
                agent_id=actor.id,
                error_class=type(exc).__name__,
                message=str(exc),
                stack_hash="",
            )
        )

    # ------------------------------------------------------------------ #
    # Introspection
    # ------------------------------------------------------------------ #
    @property
    def agent_count(self) -> int:
        return len(self._actors)

    def list_agents(self) -> list[str]:
        return sorted(self._actors)


def _payload_hash(payload: Any) -> str:
    """Stable, cheap hash of an arbitrary payload (used in event records)."""
    try:
        blob = json.dumps(payload, sort_keys=True, default=repr).encode("utf-8")
    except (TypeError, ValueError):
        blob = repr(payload).encode("utf-8")
    return hashlib.sha256(blob).hexdigest()[:32]
