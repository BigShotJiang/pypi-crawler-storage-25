"""NATS JetStream transport — distributed bus implementation.

Activated by ``pip install yuragi[guardrails-nats]``. Implements the
same :class:`~yuragi.guardrails.bus.transport.Transport` Protocol as
:class:`~yuragi.guardrails.bus.memory_transport.InMemoryTransport`, so
the runtime swap is a one-constructor-argument change.

Lazy-imports ``nats`` so a missing extra never breaks core guardrails.

Origin: ported from ``dacm.bus.nats_transport`` (2026-04-11).
"""

from __future__ import annotations

import asyncio
import json
import logging
from collections.abc import Awaitable, Callable
from typing import Any

from ..kernel.envelope import Envelope
from .transport import DeliverFn

logger = logging.getLogger(__name__)


class NatsTransport:
    """Pluggable JetStream-backed transport. **Experimental in v0.5.0**.

    The implementation is intentionally minimal — publish, subscribe,
    unsubscribe — because the heavy lifting (durable consumers,
    exactly-once delivery, KV store, object store) lives in JetStream
    itself.

    Known limitations (tracked in ``KNOWN_LIMITATIONS.md``):

    * ``publish`` returns a hardcoded ``1``; the runtime's DeadLetter
      detection is therefore inactive over NATS.
    * Malformed messages are acked after invoking ``on_malformed``;
      callers that want NAK / TERM semantics must implement them
      inside the callback before raising.
    * No explicit concurrency / prefetch limit on the consumer.
    * No durable consumer support yet.

    Production NATS deployments should pin ``yuragi >= 0.6.0`` once
    these limitations are addressed.
    """

    def __init__(
        self,
        servers: list[str] | None = None,
        *,
        on_malformed: Callable[[bytes, Exception], Awaitable[None]] | None = None,
    ) -> None:
        """Construct the transport.

        Parameters
        ----------
        servers
            JetStream URLs. Defaults to ``["nats://127.0.0.1:4222"]``.
        on_malformed
            Optional async callback that receives the raw bytes of any
            message that fails decoding plus the exception. Use this to
            forward the payload to a dead-letter subject or store it for
            later inspection. When ``None``, malformed messages are
            logged and dropped.
        """
        self.servers = servers or ["nats://127.0.0.1:4222"]
        self._warn_on_plaintext()
        self.on_malformed = on_malformed
        self._nc: Any | None = None
        self._js: Any | None = None
        self._subs: dict[tuple[str, int], Any] = {}
        self._handlers_by_id: dict[int, DeliverFn] = {}
        self._lock = asyncio.Lock()

    def _warn_on_plaintext(self) -> None:
        """Emit a warning when a non-loopback ``nats://`` server is configured.

        ``nats://`` is unencrypted; remote deployments should use
        ``tls://`` or wrap the broker behind a TLS-terminating proxy.
        Loopback (``127.0.0.1`` / ``localhost``) is treated as safe.
        """
        for url in self.servers:
            if not url.startswith("nats://"):
                continue
            host_segment = url[len("nats://") :].split(":", 1)[0]
            if host_segment in ("127.0.0.1", "localhost", "::1"):
                continue
            logger.warning(
                "NatsTransport configured with plaintext nats:// to %s — "
                "use tls:// for non-loopback deployments to protect "
                "envelope payloads in transit.",
                url,
            )

    async def start(self) -> None:
        try:
            import nats  # type: ignore[import-not-found]
        except ImportError as exc:  # pragma: no cover
            raise ImportError(
                "NatsTransport requires the optional 'guardrails-nats' extra: "
                "pip install 'yuragi[guardrails-nats]'"
            ) from exc
        self._nc = await nats.connect(servers=self.servers)
        self._js = self._nc.jetstream()

    async def stop(self) -> None:
        if self._nc is not None:
            await self._nc.close()
            self._nc = None
            self._js = None

    async def publish(self, envelope: Envelope) -> int:
        """Publish to JetStream.

        Important caveat: JetStream gives no synchronous subscriber
        count, so this method always returns ``1`` to indicate "delivered
        to the broker". As a result the runtime's
        :class:`~yuragi.guardrails.protocols.events.DeadLetter` detection
        does **not** fire for NATS-backed deployments — undelivered
        messages must be tracked at the consumer side via JetStream's
        ack / redelivery machinery instead. This is a known limitation
        and will be addressed in a future release by polling the
        consumer info before publish.
        """
        if self._js is None:
            raise RuntimeError("NatsTransport not started")
        blob = json.dumps(
            {
                "subject": envelope.subject,
                "payload": envelope.payload,
                "sender_id": envelope.sender_id,
                "envelope_id": envelope.envelope_id,
                "ts_ns": envelope.ts_ns,
                "lamport": envelope.lamport,
                "causality": list(envelope.causality),
                "confidence": envelope.confidence,
                "trace_id": envelope.trace_id,
                "headers": envelope.headers,
            },
        ).encode("utf-8")
        await self._js.publish(envelope.subject, blob)
        # JetStream gives no synchronous subscriber count.
        return 1

    async def subscribe(self, subject: str, handler: DeliverFn) -> None:
        if self._js is None:
            raise RuntimeError("NatsTransport not started")

        async def _on_msg(msg: Any) -> None:
            try:
                data = json.loads(msg.data.decode("utf-8"))
                env = Envelope(
                    subject=data["subject"],
                    payload=data["payload"],
                    sender_id=data.get("sender_id", ""),
                    envelope_id=data.get("envelope_id", ""),
                    ts_ns=data.get("ts_ns", 0),
                    lamport=data.get("lamport", 0),
                    causality=tuple(data.get("causality", [])),
                    confidence=data.get("confidence"),
                    trace_id=data.get("trace_id", ""),
                    headers=data.get("headers", {}),
                )
            except (json.JSONDecodeError, UnicodeDecodeError, KeyError) as exc:
                # Malformed message — give the user a chance to forward
                # it to a dead-letter subject, then ack so JetStream does
                # not redeliver forever. The subscription stays alive.
                logger.warning(
                    "NatsTransport: dropping malformed message on %s: %s",
                    subject, exc,
                )
                if self.on_malformed is not None:
                    try:
                        await self.on_malformed(msg.data, exc)
                    except Exception:
                        logger.exception(
                            "NatsTransport: on_malformed callback failed on %s",
                            subject,
                        )
                try:
                    await msg.ack()
                except Exception:
                    logger.exception(
                        "NatsTransport: msg.ack() failed for malformed message on %s",
                        subject,
                    )
                return
            try:
                await handler(env)
            except Exception:
                logger.exception(
                    "NatsTransport: handler raised on %s envelope_id=%s",
                    subject, env.envelope_id,
                )
            await msg.ack()

        sub = await self._js.subscribe(subject, cb=_on_msg)
        async with self._lock:
            handler_id = id(handler)
            self._subs[(subject, handler_id)] = sub
            self._handlers_by_id[handler_id] = handler

    async def unsubscribe(self, subject: str, handler: DeliverFn) -> None:
        async with self._lock:
            handler_id = id(handler)
            sub = self._subs.pop((subject, handler_id), None)
            self._handlers_by_id.pop(handler_id, None)
        if sub is not None:
            await sub.unsubscribe()
