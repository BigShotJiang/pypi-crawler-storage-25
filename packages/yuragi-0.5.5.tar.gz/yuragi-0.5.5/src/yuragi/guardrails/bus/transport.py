"""Transport Protocol — every concrete bus implements this surface.

The :class:`~yuragi.guardrails.kernel.lifecycle.Runtime` never imports
a concrete transport; it accepts anything that matches this Protocol.
That means swapping the in-process asyncio bus for NATS JetStream,
ZeroMQ, Ray actors, or libp2p is a one-line change in client code
without touching the kernel.

Origin: ported from ``dacm.bus.transport`` (2026-04-11).
"""

from __future__ import annotations

from collections.abc import Awaitable, Callable
from typing import Protocol, runtime_checkable

from ..kernel.envelope import Envelope

DeliverFn = Callable[[Envelope], Awaitable[None]]


@runtime_checkable
class Transport(Protocol):
    """Pluggable bus surface used by the :class:`Runtime`."""

    async def start(self) -> None: ...
    async def stop(self) -> None: ...
    async def publish(self, envelope: Envelope) -> int:
        """Send an envelope. Return the number of subscribers it reached."""
        ...
    async def subscribe(self, subject: str, handler: DeliverFn) -> None: ...
    async def unsubscribe(self, subject: str, handler: DeliverFn) -> None: ...
