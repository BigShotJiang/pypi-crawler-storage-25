"""In-process asyncio transport — the default bus.

Every guardrails test and the smoke demo run on this transport. It is
also the right choice for single-process production deployments where
"distributed" means "many actors in one process". For real
multi-machine deployments install ``yuragi[guardrails-nats]`` and use
:class:`yuragi.guardrails.bus.nats_transport.NatsTransport` instead —
both implement the same :class:`Transport` Protocol so client code
does not change.

Origin: ported from ``dacm.bus.memory_transport`` (2026-04-11).
"""

from __future__ import annotations

import asyncio
import logging
from collections import defaultdict

from ..kernel.envelope import Envelope
from .transport import DeliverFn, Transport

logger = logging.getLogger(__name__)


class InMemoryTransport(Transport):
    """A single-process pub/sub bus backed by per-subject handler lists."""

    def __init__(self) -> None:
        self._subscribers: dict[str, list[DeliverFn]] = defaultdict(list)
        self._lock = asyncio.Lock()
        self._running = False

    async def start(self) -> None:
        self._running = True

    async def stop(self) -> None:
        self._running = False
        async with self._lock:
            self._subscribers.clear()

    async def publish(self, envelope: Envelope) -> int:
        if not self._running:
            return 0
        async with self._lock:
            handlers = list(self._subscribers.get(envelope.subject, ()))
        if not handlers:
            return 0
        for handler in handlers:
            try:
                await handler(envelope)
            except Exception:
                logger.exception("subscriber raised on %s", envelope.subject)
        return len(handlers)

    async def subscribe(self, subject: str, handler: DeliverFn) -> None:
        async with self._lock:
            self._subscribers[subject].append(handler)

    async def unsubscribe(self, subject: str, handler: DeliverFn) -> None:
        async with self._lock:
            if handler in self._subscribers.get(subject, ()):
                self._subscribers[subject].remove(handler)
