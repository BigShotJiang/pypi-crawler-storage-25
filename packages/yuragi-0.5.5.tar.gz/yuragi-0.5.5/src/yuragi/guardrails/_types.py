"""Core data types for the yuragi guardrails subsystem.

This module deliberately depends only on the standard library so the
``guardrails`` extra can be installed without pulling any extra wheels.

Design notes
------------
* All types are :class:`~dataclasses.dataclass` instances with
  ``frozen=True`` and ``slots=True``. They behave as immutable value
  objects: hashable, comparable, and cheap to allocate.
* ``ConfidenceReport`` is the canonical record every guardrail decision
  attaches to its inputs and outputs. It carries the four signals the
  yuragi confidence model knows how to fuse, plus a free-form
  ``sources`` tuple so a downstream policy can decide whether a missing
  signal should down-weight the verdict.
* ``PolicyDecision`` is a closed enum on purpose: the runtime should
  never see an unknown decision string. New decisions belong in a
  separate enum (e.g. ``EscalationDecision``) so the type checker
  catches missed cases.

Origin: ported from ``dacm.confidence.report`` and
``dacm.confidence.policy`` (2026-04-11), refactored for yuragi.
"""

from __future__ import annotations

import enum
from dataclasses import dataclass, field


@dataclass(frozen=True, slots=True)
class ConfidenceReport:
    """Multi-signal confidence record for a single LLM action.

    Every field is bounded and dimensionless so policies can treat them
    uniformly. When a metric is unavailable, leave it at zero and add
    its name to ``sources`` so the policy can apply a discount.

    Parameters
    ----------
    confidence
        Aggregated score in ``[0.0, 1.0]``. Higher means the model is
        considered more reliable for this output.
    semantic_entropy
        Semantic entropy across resampled outputs, in nats. Lower means
        higher cross-sample agreement. ``0`` when not measured.
    vix
        Confidence VIX (volatility index) in ``[0, 100]``. Lower means
        the signal is stabler across small input perturbations. ``0``
        when not measured.
    sharpe
        Confidence Sharpe ratio in ``[-2, 2]`` after rescaling. Higher
        means better risk-adjusted certainty. ``0`` when not measured.
    dissociation
        Verbalized–logit gap in ``[0, 1]``. ``> 0.3`` is treated as a
        red flag by the default policy. ``0`` when not measured.
    sources
        Names of the signals that were actually populated. Empty tuple
        is allowed for backward-compat but discouraged in production.
    """

    confidence: float = 0.0
    semantic_entropy: float = 0.0
    vix: float = 0.0
    sharpe: float = 0.0
    dissociation: float = 0.0
    sources: tuple[str, ...] = field(default_factory=tuple)


class PolicyDecision(enum.Enum):
    """Enumerated outcomes of a :class:`ConfidencePolicy.decide` call."""

    ACCEPT = "accept"
    """The output passes — forward it downstream unchanged."""

    RESEARCH = "research"
    """The output is uncertain — escalate to a research agent or human."""

    REJECT = "reject"
    """The output is unsafe — drop it and emit an abstention."""
