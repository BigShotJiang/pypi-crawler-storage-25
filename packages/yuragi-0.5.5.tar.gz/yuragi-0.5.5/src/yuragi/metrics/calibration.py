"""Calibration metrics for LLM confidence quality measurement.

Provides research-grade calibration indicators beyond simple fragility scoring:
ECE, Mutual Information, Confidence Surface Curvature, Overconfidence Score, Brier Score.
"""

from __future__ import annotations

import logging
import math
from dataclasses import dataclass

from yuragi.config import DEFAULT_CONFIG, YuragiConfig
from yuragi.core import PerturbationResult, ScanResult

logger = logging.getLogger(__name__)


@dataclass
class CalibrationReport:
    """Aggregated calibration metrics for a scan."""

    ece: float
    """Expected Calibration Error — lower is better calibrated."""

    mutual_information: float | None
    """Mutual information between original/perturbed confidence distributions.
    None when raw_logprobs are unavailable."""

    surface_curvature: float
    """Second-order curvature of confidence over omit-perturbation space."""

    overconfidence_score: float
    """Mean gap where verbalized confidence > sampling agreement."""

    brier_score: float
    """Brier score treating confidence as P(answer_unchanged)."""


# ---------------------------------------------------------------------------
# 1. Expected Calibration Error
# ---------------------------------------------------------------------------

def expected_calibration_error(
    results: list[PerturbationResult],
    n_bins: int | None = None,
    config: YuragiConfig | None = None,
) -> float:
    """Compute ECE over perturbation results.

    Each PerturbationResult provides:
    - confidence  : perturbed_response.confidence  (predicted probability)
    - accuracy    : 1 - answer_changed             (binary outcome)

    The ECE is the weighted mean absolute difference between bin-level
    average confidence and bin-level accuracy.

    Returns 0.0 for empty input.
    """
    if not results:
        return 0.0

    cfg = config or DEFAULT_CONFIG
    if n_bins is None:
        n_bins = cfg.calibration_n_bins

    bin_size = 1.0 / n_bins
    bin_confidence_sum = [0.0] * n_bins
    bin_accuracy_sum = [0.0] * n_bins
    bin_counts = [0] * n_bins

    for r in results:
        conf = max(0.0, min(1.0, r.perturbed_response.confidence))
        acc = 0.0 if r.answer_changed else 1.0
        idx = min(int(conf / bin_size), n_bins - 1)
        bin_confidence_sum[idx] += conf
        bin_accuracy_sum[idx] += acc
        bin_counts[idx] += 1

    n = len(results)
    ece = 0.0
    for i in range(n_bins):
        count = bin_counts[i]
        if count == 0:
            continue
        avg_conf = bin_confidence_sum[i] / count
        avg_acc = bin_accuracy_sum[i] / count
        ece += (count / n) * abs(avg_conf - avg_acc)

    return ece


# ---------------------------------------------------------------------------
# 2. Mutual Information Score
# ---------------------------------------------------------------------------

def _entropy_from_probs(probs: list[float]) -> float:
    """Shannon entropy (nats) from a probability list (not required to sum to 1)."""
    total = sum(probs)
    if total <= 0:
        return 0.0
    return -sum((p / total) * math.log(p / total) for p in probs if p > 0)


def _kl_divergence(p: list[float], q: list[float]) -> float:
    """KL(P || Q) in nats, with smoothing to avoid log(0)."""
    if not p or not q:
        return 0.0
    eps = 1e-12
    p_sum = sum(p) + eps * len(p)
    q_sum = sum(q) + eps * len(q)
    kl = 0.0
    for pi, qi in zip(p, q, strict=False):
        pi_n = (pi + eps) / p_sum
        qi_n = (qi + eps) / q_sum
        kl += pi_n * math.log(pi_n / qi_n)
    return max(0.0, kl)


def mutual_information_score(results: list[PerturbationResult]) -> float | None:
    """Symmetric mutual information between original and perturbed logprob distributions.

    Uses the identity:  MI(P, Q) = H(P) + H(Q) - H(P, Q)
    approximated as:   MI ≈ (KL(P||M) + KL(Q||M)) / 2  where M = (P+Q)/2
    (Jensen-Shannon divergence, which is a symmetric MI bound).

    Returns None when no raw_logprobs are available in the results.
    """
    pairs: list[tuple[list[float], list[float]]] = []

    for r in results:
        orig_lp = r.original_response.raw_logprobs
        pert_lp = r.perturbed_response.raw_logprobs
        if not orig_lp or not pert_lp:
            continue

        # Aggregate top-logprob probability mass across all token positions.
        # Each entry in raw_logprobs is a list of (token, logprob) tuples
        # representing the top-k alternatives at that position.
        # We sum exp(logprob) across all (position, alternative) to build
        # a single marginal probability vector per response.
        orig_probs: list[float] = []
        for entry in orig_lp:
            if entry:
                orig_probs.extend(math.exp(lp) for _, lp in entry)

        pert_probs: list[float] = []
        for entry in pert_lp:
            if entry:
                pert_probs.extend(math.exp(lp) for _, lp in entry)

        if not orig_probs or not pert_probs:
            continue

        pairs.append((orig_probs, pert_probs))

    if not pairs:
        return None

    jsd_values = []
    total_truncated = 0
    n_truncated_pairs = 0
    for p, q in pairs:
        # Align lengths
        orig_len, pert_len = len(p), len(q)
        min_len = min(orig_len, pert_len)
        if orig_len != pert_len:
            truncated = max(orig_len, pert_len) - min_len
            total_truncated += truncated
            n_truncated_pairs += 1
        p = p[:min_len]
        q = q[:min_len]
        if min_len == 0:
            continue

        p_sum = sum(p) or 1.0
        q_sum = sum(q) or 1.0
        p_n = [v / p_sum for v in p]
        q_n = [v / q_sum for v in q]
        m = [(pi + qi) / 2 for pi, qi in zip(p_n, q_n, strict=False)]

        kl_pm = _kl_divergence(p_n, m)
        kl_qm = _kl_divergence(q_n, m)
        jsd = (kl_pm + kl_qm) / 2
        jsd_values.append(jsd)

    if n_truncated_pairs > 0:
        logger.warning(
            "mutual_information_score: %d/%d pairs had mismatched logprob lengths; "
            "%d total tokens truncated",
            n_truncated_pairs, len(pairs), total_truncated,
        )

    if not jsd_values:
        return None

    return sum(jsd_values) / len(jsd_values)


# ---------------------------------------------------------------------------
# 3. Confidence Surface Curvature
# ---------------------------------------------------------------------------

def confidence_surface_curvature(results: list[PerturbationResult]) -> float:
    """Estimate local curvature of the confidence function over omit-perturbations.

    Uses the sequence of perturbed confidences from omit-type perturbations,
    approximating curvature via second-order finite differences.

    Higher curvature means confidence is more non-linear / unstable.
    Returns 0.0 when fewer than 3 omit-type results exist.
    """
    omit_results = [r for r in results if r.perturbation_type == "omit"]
    confidences = [r.perturbed_response.confidence for r in omit_results]

    n = len(confidences)
    if n < 3:
        return 0.0

    second_diffs = []
    for i in range(1, n - 1):
        d2 = confidences[i + 1] - 2 * confidences[i] + confidences[i - 1]
        second_diffs.append(abs(d2))

    return sum(second_diffs) / len(second_diffs)


# ---------------------------------------------------------------------------
# 4. Overconfidence Score
# ---------------------------------------------------------------------------

def overconfidence_score(results: list[PerturbationResult]) -> float:
    """Mean excess of verbalized confidence over sampling agreement.

    For each result where original_response uses verbalized confidence,
    we compare it against perturbed_response sampling confidence.
    A positive score indicates systematic overconfidence.

    Returns 0.0 for empty input or when methods don't apply.
    """
    if not results:
        return 0.0

    gaps = []
    for r in results:
        verbalized = None
        sampling = None

        # Check original response for verbalized confidence
        if r.original_response.confidence_method == "verbalized":
            verbalized = r.original_response.confidence
        # Check perturbed response for sampling confidence
        if r.perturbed_response.confidence_method == "sampling":
            sampling = r.perturbed_response.confidence

        if verbalized is not None and sampling is not None:
            gap = verbalized - sampling
            if gap > 0:
                gaps.append(gap)

    if not gaps:
        # Fall back: mean positive (conf - accuracy) across all results
        fallback_gaps = []
        for r in results:
            conf = r.perturbed_response.confidence
            acc = 0.0 if r.answer_changed else 1.0
            gap = conf - acc
            if gap > 0:
                fallback_gaps.append(gap)
        return sum(fallback_gaps) / len(fallback_gaps) if fallback_gaps else 0.0

    return sum(gaps) / len(gaps)


# ---------------------------------------------------------------------------
# 5. Brier Score
# ---------------------------------------------------------------------------

def brier_score(results: list[PerturbationResult]) -> float:
    """Brier score treating perturbed confidence as P(answer_unchanged).

    BS = (1/N) * sum((confidence - outcome)^2)
    where outcome = 1 if answer_unchanged else 0.

    Lower is better. Returns 0.0 for empty input.
    """
    if not results:
        return 0.0

    total = 0.0
    for r in results:
        conf = max(0.0, min(1.0, r.perturbed_response.confidence))
        outcome = 0.0 if r.answer_changed else 1.0
        total += (conf - outcome) ** 2

    return total / len(results)


# ---------------------------------------------------------------------------
# Aggregate
# ---------------------------------------------------------------------------

def compute_calibration(
    scan: ScanResult, config: YuragiConfig | None = None
) -> CalibrationReport:
    """Compute all calibration metrics from a ScanResult.

    Args:
        scan: A completed ScanResult.
        config: Optional YuragiConfig for threshold overrides.

    Returns:
        CalibrationReport with all five calibration metrics.
    """
    cfg = config or getattr(scan, "config", None) or DEFAULT_CONFIG
    results = scan.perturbation_results

    return CalibrationReport(
        ece=expected_calibration_error(results, config=cfg),
        mutual_information=mutual_information_score(results),
        surface_curvature=confidence_surface_curvature(results),
        overconfidence_score=overconfidence_score(results),
        brier_score=brier_score(results),
    )
