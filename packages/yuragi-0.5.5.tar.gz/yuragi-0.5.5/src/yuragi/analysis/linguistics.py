"""Linguistic confidence analysis — text-based confidence indicators.

Extracts hedge words, assertion words, and structural features from LLM
response text to compute a linguistic confidence score. Compare against
numerical confidence to detect over/under-expression.
"""

from __future__ import annotations

import re
from dataclasses import dataclass

from yuragi.config import DEFAULT_CONFIG, YuragiConfig

# ---------------------------------------------------------------------------
# Hedge word dictionaries
# ---------------------------------------------------------------------------

_HEDGE_WEAK_EN: list[str] = [
    "maybe",
    "perhaps",
    "possibly",
    "might",
    "could",
    "i think",
    "i believe",
    "it seems",
    "it appears",
    "seemingly",
    "apparently",
    "presumably",
    "likely",
    "probably",
    "i suppose",
    "i guess",
    "sort of",
    "kind of",
    "somewhat",
]

_HEDGE_STRONG_EN: list[str] = [
    "i'm not sure",
    "i am not sure",
    "it's hard to say",
    "it is hard to say",
    "this is debatable",
    "there's no consensus",
    "there is no consensus",
    "difficult to say",
    "hard to determine",
    "unclear",
    "uncertain",
    "no definitive",
    "not entirely clear",
]

_HEDGE_WEAK_JA: list[str] = [
    "かもしれない",
    "かもしれません",
    "おそらく",
    "たぶん",
    "と思います",
    "と思われます",
    "でしょう",
    "らしい",
    "らしく",
    "ようです",
    "ようで",
    "みたいです",
]

_HEDGE_STRONG_JA: list[str] = [
    "断言はできません",
    "断言できません",
    "諸説あります",
    "一概には言えません",
    "一概に言えません",
    "はっきりしません",
    "確かではありません",
    "わかりません",
    "不明です",
]

# ---------------------------------------------------------------------------
# Assertion word dictionaries
# ---------------------------------------------------------------------------

_ASSERTION_EN: list[str] = [
    "definitely",
    "certainly",
    "clearly",
    "obviously",
    "undoubtedly",
    "absolutely",
    "without question",
    "without doubt",
    "unquestionably",
    "indisputably",
    "of course",
    "it is clear",
    "it's clear",
    "in fact",
    "the fact is",
    "it is certain",
    "it's certain",
]

_ASSERTION_JA: list[str] = [
    "確実に",
    "間違いなく",
    "明らかに",
    "当然",
    "必ず",
    "確かに",
    "疑いなく",
    "明白に",
    "断言できます",
    "断言します",
    "絶対に",
]

# All hedges combined (weak weight=1, strong weight=2)
_ALL_HEDGES_EN = {w: 1 for w in _HEDGE_WEAK_EN} | {w: 2 for w in _HEDGE_STRONG_EN}
_ALL_HEDGES_JA = {w: 1 for w in _HEDGE_WEAK_JA} | {w: 2 for w in _HEDGE_STRONG_JA}

_ALL_ASSERTIONS_EN = {w: 1 for w in _ASSERTION_EN}
_ALL_ASSERTIONS_JA = {w: 1 for w in _ASSERTION_JA}


@dataclass
class LinguisticConfidenceReport:
    """Text-based confidence indicators extracted from LLM response."""

    # Hedge word analysis
    hedge_count: int  # total hedge occurrences (weighted: strong=2)
    hedge_density: float  # hedge_count / total_words
    hedge_words_found: list[str]

    # Assertiveness
    assertion_count: int  # total assertion occurrences
    assertion_density: float

    # Response structure
    word_count: int
    sentence_count: int
    avg_sentence_length: float

    # Linguistic confidence score (0-1)
    linguistic_confidence: float  # derived from above metrics

    # Comparison with numerical confidence
    numerical_confidence: float
    confidence_gap: float  # linguistic - numerical
    is_overexpressing: bool  # linguistic > numerical (says confident but score is low)
    is_underexpressing: bool  # linguistic < numerical (hedges despite high score)


def analyze_text(
    text: str,
    numerical_confidence: float,
    config: YuragiConfig | None = None,
) -> LinguisticConfidenceReport:
    """Analyze linguistic confidence indicators in an LLM response.

    Args:
        text: The LLM response text to analyze.
        numerical_confidence: The numerical confidence score (0-1) from the model.
        config: Optional YuragiConfig for threshold overrides.

    Returns:
        A LinguisticConfidenceReport with all linguistic metrics.
    """
    cfg = config or DEFAULT_CONFIG
    lower = text.lower()

    # ---- Word count --------------------------------------------------------
    # Simple whitespace split; works for English. For Japanese, count characters.
    words = text.split()
    word_count = len(words) if words else 1  # avoid div-by-zero

    # ---- Sentence count ----------------------------------------------------
    # fmt: off
    sentence_count = max(1, len(re.findall(r"[.!?。！？]+", text)))
    avg_sentence_length = word_count / sentence_count

    # ---- Hedge detection ---------------------------------------------------
    hedge_words_found: list[str] = []
    weighted_hedge_total = 0

    for phrase, weight in (_ALL_HEDGES_EN | _ALL_HEDGES_JA).items():
        count = _count_phrase(lower, phrase)
        if count > 0:
            hedge_words_found.extend([phrase] * count)
            weighted_hedge_total += count * weight

    hedge_density = weighted_hedge_total / word_count

    # ---- Assertion detection -----------------------------------------------
    assertion_total = 0
    for phrase in (_ALL_ASSERTIONS_EN | _ALL_ASSERTIONS_JA):
        assertion_total += _count_phrase(lower, phrase)

    assertion_density = assertion_total / word_count

    # ---- Linguistic confidence score ---------------------------------------
    linguistic_confidence = _compute_linguistic_confidence(
        hedge_density=hedge_density,
        assertion_density=assertion_density,
        avg_sentence_length=avg_sentence_length,
        config=cfg,
    )

    # ---- Gap analysis ------------------------------------------------------
    gap = linguistic_confidence - numerical_confidence
    gap_threshold = cfg.linguistic_gap_threshold

    return LinguisticConfidenceReport(
        hedge_count=weighted_hedge_total,
        hedge_density=hedge_density,
        hedge_words_found=hedge_words_found,
        assertion_count=assertion_total,
        assertion_density=assertion_density,
        word_count=word_count,
        sentence_count=sentence_count,
        avg_sentence_length=avg_sentence_length,
        linguistic_confidence=linguistic_confidence,
        numerical_confidence=numerical_confidence,
        confidence_gap=gap,
        is_overexpressing=gap > gap_threshold,
        is_underexpressing=gap < -gap_threshold,
    )


# ---------------------------------------------------------------------------
# Internal helpers
# ---------------------------------------------------------------------------


def _count_phrase(text_lower: str, phrase: str) -> int:
    """Count non-overlapping occurrences of phrase in lowercased text."""
    if not phrase:
        return 0
    count = 0
    start = 0
    while True:
        idx = text_lower.find(phrase, start)
        if idx == -1:
            break
        count += 1
        start = idx + len(phrase)
    return count


def _compute_linguistic_confidence(
    hedge_density: float,
    assertion_density: float,
    avg_sentence_length: float,
    config: YuragiConfig | None = None,
) -> float:
    """Derive a 0-1 linguistic confidence score from textual features.

    Formula intuition:
    - High hedges  -> lower confidence
    - High assertions -> higher confidence
    - Very short sentences can indicate uncertainty (terse deflection)
    - Very long sentences may dilute assertiveness
    """
    cfg = config or DEFAULT_CONFIG

    # Base: neutral 0.5
    score = 0.5

    hedge_penalty = min(hedge_density * cfg.hedge_penalty_multiplier, cfg.hedge_penalty_cap)
    score -= hedge_penalty

    assertion_boost = min(assertion_density * cfg.assertion_boost_multiplier, cfg.assertion_boost_cap)
    score += assertion_boost

    # Sentence length adjustment: normalize around 15 words/sentence
    # Very short (<5) or very long (>40) penalize slightly
    if avg_sentence_length < 5:
        score -= cfg.linguistic_sentence_penalty_long
    elif avg_sentence_length > 40:
        score -= cfg.linguistic_sentence_penalty_short

    return max(0.0, min(1.0, score))
