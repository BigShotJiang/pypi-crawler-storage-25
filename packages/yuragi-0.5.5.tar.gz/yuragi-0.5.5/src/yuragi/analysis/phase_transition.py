"""Phase transition detection in LLM confidence.

Applies physics-inspired phase transition theory to confidence analysis:
as a prompt parameter is varied continuously, confidence may undergo
sudden, sharp transitions — analogous to water freezing or magnetic ordering.

The order parameter is confidence (or answer_stability / hedge_density).
Transitions are detected via peaks in the second derivative.
"""

from __future__ import annotations

import math
from dataclasses import dataclass, field

from yuragi.config import DEFAULT_CONFIG, YuragiConfig
from yuragi.providers.adapter import LLMAdapter

# Doubt words injected one-by-one to sweep the parameter space
_DOUBT_WORDS: list[str] = [
    "maybe",
    "perhaps",
    "supposedly",
    "allegedly",
    "questionably",
]

# Hedge phrases that appear when the model loses confidence
_HEDGE_PHRASES: list[str] = [
    "i think",
    "i believe",
    "i'm not sure",
    "it's possible",
    "might be",
    "could be",
    "not certain",
    "unclear",
    "uncertain",
]


@dataclass
class PhaseTransition:
    """A detected confidence phase transition."""

    # The prompt at which transition occurs
    transition_prompt: str
    pre_transition_confidence: float
    post_transition_confidence: float

    # How sharp is the transition?
    sharpness: float  # |second derivative| at transition point

    # What type of transition?
    transition_type: str  # "collapse" (high→low) or "surge" (low→high)

    # Critical perturbation that triggers it
    trigger: str  # The specific word/phrase that crosses the threshold


@dataclass
class PhaseMap:
    """Map of confidence phases across a parameter space."""

    transitions: list[PhaseTransition]
    num_phases: int  # How many distinct confidence "phases" exist
    critical_point: str | None  # Most dramatic transition prompt

    # Order parameter: what quantity changes at the transition?
    order_parameter: str  # "confidence", "answer_stability", "hedge_density"

    # Raw data: (parameter_value, prompt, confidence) at each step
    steps: list[tuple[int, str, float]] = field(default_factory=list)


def _count_hedge_density(text: str) -> float:
    """Fraction of hedge phrases present (0-1)."""
    lower = text.lower()
    hits = sum(1 for phrase in _HEDGE_PHRASES if phrase in lower)
    return min(1.0, hits / max(1, len(_HEDGE_PHRASES) // 2))


def _second_derivative(values: list[float]) -> list[float]:
    """Compute discrete second derivative via central differences.

    Returns a list of length len(values); boundary points use
    forward/backward differences of the first derivative.
    """
    n = len(values)
    if n < 3:
        return [0.0] * n

    d2 = []
    for i in range(n):
        if i == 0:
            d2.append(values[2] - 2 * values[1] + values[0])
        elif i == n - 1:
            d2.append(values[n - 1] - 2 * values[n - 2] + values[n - 3])
        else:
            d2.append(values[i + 1] - 2 * values[i] + values[i - 1])
    return d2


def _detect_transitions(
    steps: list[tuple[int, str, float]],
    sharpness_threshold: float | None = None,
    delta_min: float | None = None,
    config: YuragiConfig | None = None,
) -> list[PhaseTransition]:
    """Detect phase transitions from a sequence of (param, prompt, confidence) steps.

    A transition is detected where |second derivative| exceeds the threshold,
    indicating a rapid change in confidence slope.
    """
    cfg = config or DEFAULT_CONFIG
    sharpness_threshold = sharpness_threshold if sharpness_threshold is not None else cfg.phase_sharpness_threshold
    delta_min = delta_min if delta_min is not None else cfg.phase_transition_delta_min

    if len(steps) < 3:
        return []

    confidences = [c for _, _, c in steps]
    d2 = _second_derivative(confidences)

    transitions: list[PhaseTransition] = []
    for i, (_, prompt, _) in enumerate(steps):
        sharpness = abs(d2[i])
        if sharpness < sharpness_threshold:
            continue

        # Need at least one preceding point to determine pre/post
        if i == 0:
            continue

        pre_conf = confidences[i - 1]
        post_conf = confidences[i]

        delta = post_conf - pre_conf
        if abs(delta) < delta_min:
            continue

        transition_type = "collapse" if delta < 0 else "surge"

        # Find the trigger: the doubt word added at step i
        param_value = steps[i][0]
        trigger = _DOUBT_WORDS[param_value - 1] if 1 <= param_value <= len(_DOUBT_WORDS) else ""

        transitions.append(
            PhaseTransition(
                transition_prompt=prompt,
                pre_transition_confidence=pre_conf,
                post_transition_confidence=post_conf,
                sharpness=sharpness,
                transition_type=transition_type,
                trigger=trigger,
            )
        )

    return transitions


def _count_phases(confidences: list[float], band: float | None = None, config: YuragiConfig | None = None) -> int:
    """Count distinct confidence 'phases' (plateau regions).

    A phase is a contiguous run where confidence stays within ±band/2
    of the run's mean.
    """
    cfg = config or DEFAULT_CONFIG
    band = band if band is not None else cfg.phase_band_width

    if not confidences:
        return 0

    phases = 1
    run_mean = confidences[0]

    for c in confidences[1:]:
        if abs(c - run_mean) > band:
            phases += 1
            run_mean = c
        else:
            # Update running mean (simple EMA)
            alpha = cfg.phase_ema_alpha
            run_mean = alpha * run_mean + (1.0 - alpha) * c

    return phases


def _build_parameterized_prompts(base_prompt: str, max_param: int = 5) -> list[str]:
    """Build a sequence of prompts with 0..max_param doubt words injected.

    Parameter 0: original prompt
    Parameter k: prepend k doubt words to the prompt
    """
    prompts = [base_prompt]
    for k in range(1, max_param + 1):
        words = " ".join(_DOUBT_WORDS[:k])
        prompts.append(f"{words}, {base_prompt}")
    return prompts


@dataclass
class PhaseMapExperiment:
    """Run a phase transition sweep on a prompt."""

    model: str
    max_param: int = 5
    num_samples: int = 3
    sharpness_threshold: float | None = None
    api_key: str | None = None
    config: YuragiConfig | None = None

    def run(self, prompt: str) -> PhaseMap:
        """Sweep the parameter space and build a PhaseMap."""
        adapter = LLMAdapter(
            model=self.model,
            api_key=self.api_key,
            num_samples=self.num_samples,
        )

        prompts = _build_parameterized_prompts(prompt, self.max_param)
        steps: list[tuple[int, str, float]] = []

        for param_value, p in enumerate(prompts):
            result = adapter.complete(p)
            steps.append((param_value, p, result.confidence))

        cfg = self.config or DEFAULT_CONFIG
        threshold = self.sharpness_threshold if self.sharpness_threshold is not None else cfg.phase_sharpness_threshold
        transitions = _detect_transitions(steps, sharpness_threshold=threshold, config=cfg)
        confidences = [c for _, _, c in steps]
        num_phases = _count_phases(confidences, config=cfg)

        critical_point: str | None = None
        if transitions:
            most_dramatic = max(transitions, key=lambda t: t.sharpness)
            critical_point = most_dramatic.transition_prompt

        # Determine dominant order parameter
        # Use "hedge_density" if any transition has a large hedge response,
        # otherwise default to "confidence"
        order_parameter = "confidence"
        for _, _, conf in steps:
            _ = conf  # already using confidence as order param

        return PhaseMap(
            transitions=transitions,
            num_phases=num_phases,
            critical_point=critical_point,
            order_parameter=order_parameter,
            steps=steps,
        )


def detect_phase_transitions(
    prompt: str,
    model: str,
    max_param: int = 5,
    num_samples: int = 3,
    sharpness_threshold: float | None = None,
    api_key: str | None = None,
    config: YuragiConfig | None = None,
) -> PhaseMap:
    """Convenience function: run a full phase transition sweep.

    Args:
        prompt: Base prompt to sweep.
        model: LiteLLM model string.
        max_param: Number of doubt-word steps (0..max_param).
        num_samples: Samples per step for confidence measurement.
        sharpness_threshold: |d²C/dx²| cutoff for transition detection.
            Defaults to ``config.phase_sharpness_threshold``.
        api_key: Optional API key override.
        config: Optional YuragiConfig for threshold overrides.

    Returns:
        PhaseMap with all detected transitions and phase structure.
    """
    experiment = PhaseMapExperiment(
        model=model,
        max_param=max_param,
        num_samples=num_samples,
        sharpness_threshold=sharpness_threshold,
        api_key=api_key,
        config=config,
    )
    return experiment.run(prompt)


def _phase_label(confidence: float, config: YuragiConfig | None = None) -> str:
    """Human-readable phase label for a confidence value."""
    cfg = config or DEFAULT_CONFIG
    if confidence >= cfg.phase_confidence_high:
        return "high-confidence"
    if confidence >= cfg.phase_confidence_low:
        return "intermediate"
    return "low-confidence"


def _transition_summary(pt: PhaseTransition) -> str:
    """One-line summary of a PhaseTransition."""
    direction = "\u2193" if pt.transition_type == "collapse" else "\u2191"
    delta = pt.post_transition_confidence - pt.pre_transition_confidence
    pre_label = _phase_label(pt.pre_transition_confidence)
    post_label = _phase_label(pt.post_transition_confidence)
    trigger_info = f' (trigger: "{pt.trigger}")' if pt.trigger else ""
    return (
        f"{direction} {pre_label} \u2192 {post_label}  "
        f"\u0394={delta:+.2f}  sharpness={pt.sharpness:.3f}{trigger_info}"
    )


def _ascii_phase_diagram(phase_map: PhaseMap, width: int = 40) -> list[str]:
    """Render a simple ASCII confidence phase diagram.

    Returns a list of lines suitable for display.
    """
    if not phase_map.steps:
        return ["(no data)"]

    confidences = [c for _, _, c in phase_map.steps]
    max_c = max(confidences) if confidences else 1.0
    scale = max_c if max_c > 0 else 1.0

    lines = []
    for param_value, prompt_snippet, conf in phase_map.steps:
        filled = int((conf / scale) * width)
        bar = "\u2588" * filled + "\u2591" * (width - filled)
        label = _phase_label(conf)
        marker = " \u26a1" if any(
            t.transition_prompt == prompt_snippet for t in phase_map.transitions
        ) else "  "
        lines.append(
            f"  p={param_value}  {bar}  {conf:.2f}  [{label}]{marker}"
        )
    return lines


def _confidence_gradient(confidences: list[float]) -> list[float]:
    """Compute first derivative (gradient) of confidence series."""
    if len(confidences) < 2:
        return [0.0] * len(confidences)
    grad = [0.0]
    for i in range(1, len(confidences)):
        grad.append(confidences[i] - confidences[i - 1])
    return grad


def phase_map_summary(phase_map: PhaseMap) -> str:
    """Return a multi-line text summary of a PhaseMap."""
    lines = [
        f"Order parameter : {phase_map.order_parameter}",
        f"Distinct phases : {phase_map.num_phases}",
        f"Transitions     : {len(phase_map.transitions)}",
    ]

    if phase_map.critical_point:
        short = phase_map.critical_point[:60]
        lines.append(f"Critical point  : \"{short}\"")

    if phase_map.transitions:
        lines.append("")
        lines.append("Detected transitions:")
        for i, t in enumerate(phase_map.transitions, 1):
            lines.append(f"  [{i}] {_transition_summary(t)}")

    if phase_map.steps:
        lines.append("")
        lines.append("Phase diagram (confidence vs. doubt-word count):")
        lines.extend(_ascii_phase_diagram(phase_map))

    # Compute gradient signature
    confidences = [c for _, _, c in phase_map.steps]
    if len(confidences) >= 2:
        total_drop = confidences[0] - min(confidences)
        lines.append(f"\nTotal confidence drop: {total_drop:+.2f}")
        is_monotone = all(
            confidences[i] >= confidences[i + 1]
            for i in range(len(confidences) - 1)
        )
        lines.append(
            f"Monotone decrease   : {'yes' if is_monotone else 'no'}"
        )

    return "\n".join(lines)


# ---------------------------------------------------------------------------
# Internal helpers exposed for testing
# ---------------------------------------------------------------------------

def _compute_sharpness_at(confidences: list[float], index: int) -> float:
    """Return |d²C/dx²| at a given index (used in tests)."""
    d2 = _second_derivative(confidences)
    return abs(d2[index]) if 0 <= index < len(d2) else 0.0


def _is_transition(confidences: list[float], index: int, threshold: float = 0.05) -> bool:
    """Return True if a phase transition occurs at index (used in tests)."""
    if index == 0 or index >= len(confidences):
        return False
    sharpness = _compute_sharpness_at(confidences, index)
    delta = abs(confidences[index] - confidences[index - 1])
    return sharpness >= threshold and delta >= 0.02


def _is_monotone_decrease(confidences: list[float]) -> bool:
    """Return True iff confidence is non-increasing throughout."""
    return all(
        confidences[i] >= confidences[i + 1] - 1e-9
        for i in range(len(confidences) - 1)
    )


# Ensure math import is used (entropy-style check for hedge density)
def _hedge_entropy(text: str) -> float:
    """Shannon entropy of hedge phrase presence — auxiliary diagnostic."""
    density = _count_hedge_density(text)
    if density <= 0 or density >= 1:
        return 0.0
    return -density * math.log2(density) - (1 - density) * math.log2(1 - density)
