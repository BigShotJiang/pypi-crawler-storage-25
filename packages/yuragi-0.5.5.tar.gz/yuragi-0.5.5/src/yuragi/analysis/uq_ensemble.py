"""UQ Ensemble — bc + LSC + STC + fragility の ensemble が single-feature を超えるか検証。

arxiv 2504.19254 "Uncertainty Quantification Suite" に合わせた
blackbox / whitebox / LLM-judge / ensemble の 4 カテゴリ統一フレームワーク。

使用例
------
>>> from yuragi.analysis.uq_ensemble import kfold_ensemble_auc, ablation_leave_one_out
>>> X, y = build_feature_matrix(records, ["baseline_confidence", "fragility_score"])
>>> result = kfold_ensemble_auc(X, y, ["baseline_confidence", "fragility_score"])
>>> print(result["auc"], result["ci_lower"], result["ci_upper"])
"""

from __future__ import annotations

import warnings
from typing import Literal

import numpy as np
from sklearn.linear_model import LogisticRegression, RidgeClassifier
from sklearn.metrics import roc_auc_score
from sklearn.model_selection import StratifiedKFold
from sklearn.preprocessing import StandardScaler

__all__ = [
    "ablation_leave_one_out",
    "build_feature_matrix",
    "kfold_ensemble_auc",
    "uq_ensemble_fit",
    "uq_ensemble_predict_auc",
]

SEED = 42
N_BOOTSTRAP = 1000


# ---------------------------------------------------------------------------
# 1. Feature matrix builder
# ---------------------------------------------------------------------------


def build_feature_matrix(
    records: list[dict],
    features: list[str],
) -> np.ndarray:
    """JSON records から指定 features を numeric matrix に変換する。

    欠損値 (None / NaN) は列の中央値で補完する。
    LSC スコアは負値で「小さいほど不確か」なので、
    符号を反転して「大きいほど不確か」に統一する。

    Parameters
    ----------
    records:
        list of dict。各 dict は 1 サンプルを表す。
    features:
        抽出する特徴量名のリスト。

    Returns
    -------
    X: np.ndarray, shape (n_samples, n_features)
    """
    n = len(records)
    n_feat = len(features)
    X = np.full((n, n_feat), np.nan)

    for i, rec in enumerate(records):
        for j, feat in enumerate(features):
            val = rec.get(feat)
            if val is not None:
                try:
                    X[i, j] = float(val)
                except (TypeError, ValueError):
                    pass  # leave as NaN

    # Impute missing values with column median
    for j in range(n_feat):
        col = X[:, j]
        missing = np.isnan(col)
        if missing.any():
            med = float(np.nanmedian(col))
            col[missing] = 0.0 if np.isnan(med) else med
            X[:, j] = col

    return X


# ---------------------------------------------------------------------------
# 2. Ensemble fit
# ---------------------------------------------------------------------------


def uq_ensemble_fit(
    X_train: np.ndarray,
    y_train: np.ndarray,
    model: Literal["logreg", "ridge"] = "logreg",
    C: float = 1.0,
) -> tuple[object, StandardScaler]:
    """LogisticRegression または RidgeClassifier で ensemble を学習する。

    Parameters
    ----------
    X_train: np.ndarray, shape (n, k)
    y_train: np.ndarray, shape (n,), binary 0/1
    model: "logreg" (デフォルト) | "ridge"
    C: L2 正則化の逆数 (LogisticRegression のみ)

    Returns
    -------
    (fitted_model, scaler)
        scaler は StandardScaler; テスト時に同じ scaler で変換すること。
    """
    scaler = StandardScaler()
    X_scaled = scaler.fit_transform(X_train)

    if model == "logreg":
        clf = LogisticRegression(C=C, solver="lbfgs", max_iter=1000, random_state=SEED)
    else:
        clf = RidgeClassifier(alpha=1.0 / C, max_iter=1000)

    with warnings.catch_warnings():
        warnings.simplefilter("ignore")
        clf.fit(X_scaled, y_train)

    return clf, scaler


# ---------------------------------------------------------------------------
# 3. AUC + bootstrap CI
# ---------------------------------------------------------------------------


def uq_ensemble_predict_auc(
    model: object,
    X_test: np.ndarray,
    y_test: np.ndarray,
    scaler: StandardScaler | None = None,
    n_bootstrap: int = N_BOOTSTRAP,
    seed: int = SEED,
) -> dict[str, float]:
    """AUC + bootstrap 95% CI を計算する。

    Parameters
    ----------
    model: fitted classifier (LogisticRegression / RidgeClassifier)
    X_test: shape (n, k)
    y_test: shape (n,) binary
    scaler: StandardScaler を渡せば内部で変換。None なら変換なし。
    n_bootstrap: bootstrap 反復数
    seed: random seed

    Returns
    -------
    dict with keys: auc, ci_lower, ci_upper, p_value_vs_05
        p_value_vs_05: AUC=0.5 に対する片側 p 値 (bootstrap)
    """
    if scaler is not None:
        X_test = scaler.transform(X_test)

    if hasattr(model, "predict_proba"):
        scores = model.predict_proba(X_test)[:, 1]
    else:
        # RidgeClassifier: decision_function
        scores = model.decision_function(X_test)

    y_arr = np.asarray(y_test, dtype=int)
    auc = float(roc_auc_score(y_arr, scores))

    rng = np.random.default_rng(seed)
    n = len(y_arr)
    boot_aucs: list[float] = []
    for _ in range(n_bootstrap):
        idx = rng.integers(0, n, size=n)
        ys = y_arr[idx]
        ss = scores[idx]
        if len(np.unique(ys)) < 2:
            continue
        boot_aucs.append(float(roc_auc_score(ys, ss)))

    boot_arr = np.array(boot_aucs)
    ci_lower = float(np.percentile(boot_arr, 2.5))
    ci_upper = float(np.percentile(boot_arr, 97.5))
    # one-sided p-value: P(AUC_boot >= 0.5 under null)
    # approximate: fraction of bootstrap samples <= 0.5
    p_value = float(np.mean(boot_arr <= 0.5))

    return {
        "auc": auc,
        "ci_lower": ci_lower,
        "ci_upper": ci_upper,
        "p_value_vs_05": p_value,
        "n_boot_valid": len(boot_aucs),
    }


# ---------------------------------------------------------------------------
# 4. 5-fold CV OOF ensemble AUC
# ---------------------------------------------------------------------------


def kfold_ensemble_auc(
    X: np.ndarray,
    y: np.ndarray,
    features: list[str],
    k: int = 5,
    seed: int = SEED,
    model: Literal["logreg", "ridge"] = "logreg",
    C: float = 1.0,
    n_bootstrap: int = N_BOOTSTRAP,
) -> dict[str, object]:
    """5-fold CV out-of-fold predictions → global AUC + bootstrap CI。

    CV で学習した各 fold のモデルを使い、OOF スコアを結合してから
    global AUC を計算する (fold-leakage なし)。

    また train AUC (各 fold の平均) も返して overfitting 検知に使う。

    Parameters
    ----------
    X: shape (n, k)
    y: shape (n,) binary
    features: feature names (for reporting)
    k: CV folds
    seed, model, C, n_bootstrap: 上記と同様

    Returns
    -------
    dict with keys:
        auc_oof: float — OOF global AUC
        ci_lower, ci_upper: bootstrap 95% CI on OOF AUC
        p_value_vs_05: AUC=0.5 に対する片側 p (bootstrap)
        auc_train_mean: float — 平均 train fold AUC (overfitting 指標)
        overfitting_gap: auc_train_mean - auc_oof
        oof_scores: np.ndarray — OOF predicted probabilities
        features: list[str]
        n_samples: int
        n_features: int
    """
    y_arr = np.asarray(y, dtype=int)
    n = len(y_arr)
    oof_scores = np.zeros(n, dtype=float)
    train_aucs: list[float] = []

    skf = StratifiedKFold(n_splits=k, shuffle=True, random_state=seed)

    for train_idx, val_idx in skf.split(X, y_arr):
        X_tr, X_val = X[train_idx], X[val_idx]
        y_tr, y_val = y_arr[train_idx], y_arr[val_idx]

        clf, scaler = uq_ensemble_fit(X_tr, y_tr, model=model, C=C)
        X_tr_sc = scaler.transform(X_tr)
        X_val_sc = scaler.transform(X_val)

        if hasattr(clf, "predict_proba"):
            oof_scores[val_idx] = clf.predict_proba(X_val_sc)[:, 1]
            train_scores = clf.predict_proba(X_tr_sc)[:, 1]
        else:
            oof_scores[val_idx] = clf.decision_function(X_val_sc)
            train_scores = clf.decision_function(X_tr_sc)

        if len(np.unique(y_tr)) >= 2:
            train_aucs.append(float(roc_auc_score(y_tr, train_scores)))

    auc_oof = float(roc_auc_score(y_arr, oof_scores))
    auc_train_mean = float(np.mean(train_aucs)) if train_aucs else float("nan")

    # bootstrap CI on OOF
    rng = np.random.default_rng(seed)
    boot_aucs: list[float] = []
    for _ in range(n_bootstrap):
        idx = rng.integers(0, n, size=n)
        ys = y_arr[idx]
        ss = oof_scores[idx]
        if len(np.unique(ys)) < 2:
            continue
        boot_aucs.append(float(roc_auc_score(ys, ss)))

    boot_arr = np.array(boot_aucs)
    ci_lower = float(np.percentile(boot_arr, 2.5))
    ci_upper = float(np.percentile(boot_arr, 97.5))
    p_value = float(np.mean(boot_arr <= 0.5))

    return {
        "auc_oof": auc_oof,
        "ci_lower": ci_lower,
        "ci_upper": ci_upper,
        "p_value_vs_05": p_value,
        "auc_train_mean": auc_train_mean,
        "overfitting_gap": auc_train_mean - auc_oof,
        "oof_scores": oof_scores,
        "features": features,
        "n_samples": n,
        "n_features": len(features),
    }


# ---------------------------------------------------------------------------
# 5. Leave-one-out ablation
# ---------------------------------------------------------------------------


def ablation_leave_one_out(
    X: np.ndarray,
    y: np.ndarray,
    features: list[str],
    k: int = 5,
    seed: int = SEED,
    model: Literal["logreg", "ridge"] = "logreg",
    C: float = 1.0,
    n_bootstrap: int = N_BOOTSTRAP,
) -> list[dict[str, object]]:
    """各 feature を 1 つずつ除外した時の CV-AUC の変化量を計算する。

    Parameters
    ----------
    X: shape (n, n_features)
    y: shape (n,) binary
    features: feature names
    k, seed, model, C, n_bootstrap: kfold_ensemble_auc と同様

    Returns
    -------
    list of dict, sorted by delta_auc descending (貢献度順)
        各 dict: {
            "feature": str,
            "auc_without": float,
            "ci_lower_without": float,
            "ci_upper_without": float,
            "delta_auc": float,  # full_auc - auc_without (正 = この feature が有益)
        }
    """
    full_result = kfold_ensemble_auc(
        X, y, features, k=k, seed=seed, model=model, C=C, n_bootstrap=n_bootstrap
    )
    full_auc = full_result["auc_oof"]

    results: list[dict[str, object]] = []
    for j, feat in enumerate(features):
        mask = [i for i in range(len(features)) if i != j]
        X_sub = X[:, mask]
        sub_features = [features[i] for i in mask]

        if len(mask) == 0:
            # single feature: compare single-feature AUC vs full ensemble
            auc_without = float("nan")
            ci_lo = ci_hi = float("nan")
        else:
            sub_result = kfold_ensemble_auc(
                X_sub, y, sub_features, k=k, seed=seed, model=model, C=C,
                n_bootstrap=n_bootstrap,
            )
            auc_without = sub_result["auc_oof"]
            ci_lo = sub_result["ci_lower"]
            ci_hi = sub_result["ci_upper"]

        results.append({
            "feature": feat,
            "auc_without": auc_without,
            "ci_lower_without": ci_lo,
            "ci_upper_without": ci_hi,
            "delta_auc": full_auc - auc_without,
        })

    results.sort(key=lambda d: d["delta_auc"], reverse=True)
    return results
