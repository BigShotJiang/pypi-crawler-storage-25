"""Distribution shift metrics for logprob-based intent-alignment detection.

Round 6-A: bc-shift under context stripping (Hellinger on top-5 logprobs).

Functions:
  hellinger_distance(p, q) — Hellinger distance between two probability vectors
  js_divergence(p, q)      — Jensen-Shannon divergence between two probability vectors
  logprobs_to_dist(logprob_pairs, k) — top-K logprob list → normalised probability vector
"""

from __future__ import annotations

import math
from collections.abc import Sequence


def hellinger_distance(p: Sequence[float], q: Sequence[float]) -> float:
    """Hellinger distance between two probability distributions.

    H(p, q) = (1 / sqrt(2)) * ||sqrt(p) - sqrt(q)||_2

    Both inputs must be non-negative and of equal length.  They do NOT need to
    sum to 1 — the function normalises internally.

    Returns a value in [0, 1].  H=0 iff p==q (after normalisation); H=1 iff
    the distributions have disjoint support.

    Args:
        p: First distribution (unnormalised probabilities / logprob-derived values).
        q: Second distribution (same length as p).

    Returns:
        Hellinger distance in [0, 1].

    Raises:
        ValueError: If the inputs have different lengths or are empty.
    """
    if len(p) != len(q):
        raise ValueError(f"Distributions must have equal length: {len(p)} != {len(q)}")
    if len(p) == 0:
        raise ValueError("Distributions must be non-empty")

    p_sum = sum(p)
    q_sum = sum(q)
    if p_sum <= 0 or q_sum <= 0:
        raise ValueError("Distribution sums must be positive")

    sq_sum = sum(
        (math.sqrt(pi / p_sum) - math.sqrt(qi / q_sum)) ** 2
        for pi, qi in zip(p, q, strict=True)
    )
    return math.sqrt(sq_sum) / math.sqrt(2)


def js_divergence(p: Sequence[float], q: Sequence[float]) -> float:
    """Jensen-Shannon divergence between two probability distributions.

    JSD(p || q) = (KL(p || m) + KL(q || m)) / 2  where m = (p + q) / 2

    Both inputs must be non-negative and of equal length.  They do NOT need to
    sum to 1 — the function normalises internally.

    Returns a value in [0, log(2)].  JSD=0 iff p==q; JSD=log(2) iff the
    distributions have disjoint support.

    Args:
        p: First distribution.
        q: Second distribution (same length as p).

    Returns:
        Jensen-Shannon divergence in [0, log(2)] ≈ [0, 0.693].

    Raises:
        ValueError: If the inputs have different lengths or are empty.
    """
    if len(p) != len(q):
        raise ValueError(f"Distributions must have equal length: {len(p)} != {len(q)}")
    if len(p) == 0:
        raise ValueError("Distributions must be non-empty")

    p_sum = sum(p)
    q_sum = sum(q)
    if p_sum <= 0 or q_sum <= 0:
        raise ValueError("Distribution sums must be positive")

    pn = [pi / p_sum for pi in p]
    qn = [qi / q_sum for qi in q]

    def _kl(a: list[float], b: list[float]) -> float:
        total = 0.0
        for ai, bi in zip(a, b, strict=True):
            if ai > 0 and bi > 0:
                total += ai * math.log(ai / bi)
            elif ai > 0:
                # b_i == 0 → KL → +inf, clamp to large finite value
                total += ai * 700.0
        return total

    m = [(pi + qi) / 2 for pi, qi in zip(pn, qn, strict=True)]
    return (_kl(pn, m) + _kl(qn, m)) / 2


def logprobs_to_dist(
    logprob_pairs: Sequence[tuple[str, float]],
    k: int = 5,
) -> tuple[list[str], list[float]]:
    """Convert top-K (token, logprob) pairs to a normalised probability vector.

    The NIM API returns `top_logprobs` as a list of {token: str, logprob: float}
    dicts.  This helper converts them to (tokens, probs) suitable for
    hellinger_distance / js_divergence.

    Args:
        logprob_pairs: Sequence of (token, logprob) tuples, already top-K sorted.
        k: Number of top entries to keep (default 5).

    Returns:
        Tuple of (token_list, probability_list) where probabilities sum to 1.

    Raises:
        ValueError: If logprob_pairs is empty.
    """
    if not logprob_pairs:
        raise ValueError("logprob_pairs must be non-empty")

    top = list(logprob_pairs)[:k]
    tokens = [t for t, _ in top]
    # logprob → probability via exp; values are negative (log-probabilities)
    probs_raw = [math.exp(lp) for _, lp in top]
    total = sum(probs_raw)
    if total <= 0:
        raise ValueError("All logprobs produced zero probability — check input")
    probs = [p / total for p in probs_raw]
    return tokens, probs
