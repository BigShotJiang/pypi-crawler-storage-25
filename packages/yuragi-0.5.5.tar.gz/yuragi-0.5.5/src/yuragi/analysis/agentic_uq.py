"""Agentic Uncertainty Quantification.

Tracks confidence trajectory during multi-step tool-use sessions.
Reference: arxiv 2601.15703, 2602.05073.
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from yuragi.providers.adapter import LLMAdapter


@dataclass(frozen=True)
class AgenticStep:
    step_index: int
    tool_called: str | None  # None for non-tool steps
    confidence_before: float
    confidence_after: float
    confidence_delta: float


@dataclass(frozen=True)
class AgenticTrajectory:
    steps: list[AgenticStep]
    total_steps: int
    monotone_decline: bool  # whether confidence decreases monotonically
    max_drop: float
    final_confidence: float
    fragility_score: float


def _build_tool_call_prompt(initial_prompt: str, tools: list[dict], step: int) -> str:
    """Build a prompt that requests a tool call or final answer at a given step."""
    tool_names = [t.get("name", f"tool_{i}") for i, t in enumerate(tools)]
    if step == 0:
        return (
            f"{initial_prompt}\n\n"
            f"Available tools: {', '.join(tool_names)}. "
            "If you need to use a tool, respond with: TOOL: <tool_name>. "
            "Otherwise respond with your answer."
        )
    return (
        f"Continuing from step {step}. Based on tool results so far, "
        "do you need another tool or can you answer? "
        "TOOL: <tool_name> or give final answer."
    )


def _extract_tool_name(response_text: str, tools: list[dict]) -> str | None:
    """Extract tool name from response if the model requested a tool call."""
    text_lower = response_text.lower()
    for tool in tools:
        name = tool.get("name", "")
        if name and (f"tool: {name.lower()}" in text_lower or name.lower() in text_lower[:50]):
            return name
    if "tool:" in text_lower:
        after = response_text.lower().split("tool:", 1)[1].strip().split()[0]
        return after if after else None
    return None


def track_agentic_session(
    adapter: LLMAdapter,
    initial_prompt: str,
    tools: list[dict],
    *,
    max_steps: int = 5,
) -> AgenticTrajectory:
    """Run a multi-step tool-use session and track confidence at each step.

    Calls adapter.complete(...) at each step. Records confidence (verbalized
    or sampled) before and after each tool call.
    """
    steps: list[AgenticStep] = []
    prev_confidence: float | None = None

    for step_index in range(max_steps):
        prompt = _build_tool_call_prompt(initial_prompt, tools, step=step_index)
        result = adapter.complete(prompt)

        # Step 0 has no prior call; use the first observed confidence as
        # the baseline so the delta is zero instead of being attributed to
        # a discarded duplicate call.
        confidence_before = prev_confidence if prev_confidence is not None else result.confidence
        confidence_after = result.confidence
        delta = confidence_after - confidence_before

        tool_called = _extract_tool_name(result.text, tools)

        steps.append(
            AgenticStep(
                step_index=step_index,
                tool_called=tool_called,
                confidence_before=confidence_before,
                confidence_after=confidence_after,
                confidence_delta=delta,
            )
        )

        prev_confidence = confidence_after

        # Stop if no tool called (final answer reached)
        if tool_called is None:
            break

    if not steps:
        return AgenticTrajectory(
            steps=[],
            total_steps=0,
            monotone_decline=False,
            max_drop=0.0,
            final_confidence=prev_confidence,
            fragility_score=0.0,
        )

    confidences_after = [s.confidence_after for s in steps]
    monotone_decline = all(
        confidences_after[i] >= confidences_after[i + 1]
        for i in range(len(confidences_after) - 1)
    )
    drops = [s.confidence_before - s.confidence_after for s in steps]
    max_drop = max(drops) if drops else 0.0

    final_confidence = steps[-1].confidence_after
    first_confidence = steps[0].confidence_before
    total_drop = max(first_confidence - final_confidence, 0.0)
    fragility_score = min(total_drop + (max_drop * 0.5), 1.0)

    return AgenticTrajectory(
        steps=steps,
        total_steps=len(steps),
        monotone_decline=monotone_decline,
        max_drop=max_drop,
        final_confidence=final_confidence,
        fragility_score=fragility_score,
    )
