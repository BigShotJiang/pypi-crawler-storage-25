"""Semantic Entropy Probes (SEP) for hallucination detection.

Implements lightweight linear probes that predict semantic entropy from
hidden states of a language model, enabling single-forward-pass uncertainty
estimation without the multi-sample overhead of full semantic entropy.

Reference:
    Kossen et al. 2024, "Semantic Entropy Probes: Robust and Cheap
    Hallucination Detection in LLMs", arXiv:2406.15927
    GitHub: https://github.com/OATML/semantic-entropy-probes

Core idea:
    Full SE (Farquhar et al., Nature 2024) requires n forward passes + NLI
    clustering. SEP trains a linear probe on hidden states so that at
    inference time a single forward pass suffices:

        probe = LogisticRegression(
            X = hidden_state[layer L, last_token],   # shape (n_samples, d_model)
            y = binarised_semantic_entropy            # 0 = low SE, 1 = high SE
        )

    The median SE across the training set is used as the binarisation
    threshold. At inference:

        p_high_se = probe.predict_proba(h)[..., 1]

    This value serves as a cheap proxy for semantic uncertainty.
"""
from __future__ import annotations

import math
import pickle
from pathlib import Path
from typing import TYPE_CHECKING

import numpy as np

try:
    from sklearn.linear_model import LogisticRegression
    from sklearn.preprocessing import StandardScaler
    _SKLEARN_AVAILABLE = True
except ImportError:  # pragma: no cover
    _SKLEARN_AVAILABLE = False

if TYPE_CHECKING:
    from transformers import PreTrainedModel, PreTrainedTokenizerBase


# ---------------------------------------------------------------------------
# Semantic entropy helpers
# ---------------------------------------------------------------------------

def _jaccard_3gram(a: str, b: str) -> float:
    """Character 3-gram Jaccard similarity between two strings."""
    def ngrams(s: str, n: int = 3) -> set[str]:
        s = s.lower().strip()
        return {s[i : i + n] for i in range(len(s) - n + 1)} if len(s) >= n else {s}

    sa, sb = ngrams(a), ngrams(b)
    union = sa | sb
    if not union:
        return 1.0
    return len(sa & sb) / len(union)


def compute_semantic_entropy(
    answers: list[str],
    threshold: float = 0.7,
) -> float:
    """Compute semantic entropy via Jaccard-similarity greedy clustering.

    This is a simplified NLI-free approximation of Farquhar et al.
    (Nature 2024). Character 3-gram Jaccard similarity is used instead
    of NLI entailment — appropriate for short factoid answers but not
    equivalent to the published NLI clustering approach.

    Formula (Farquhar 2024):
        SE = -Σ_{c in clusters} p(c) * log p(c)
        where p(c) = |c| / n_total

    Args:
        answers: List of model-generated answers for the same prompt.
        threshold: Jaccard similarity threshold for merging into one cluster.
            Higher = stricter (more clusters = higher entropy).

    Returns:
        Semantic entropy in nats (≥ 0.0). Returns 0.0 for empty or
        single-element lists (no diversity possible).
    """
    if len(answers) <= 1:
        return 0.0

    # Greedy single-linkage clustering (sorted for reproducibility)
    sorted_answers = sorted(answers)
    clusters: list[list[str]] = []
    for ans in sorted_answers:
        placed = False
        for cluster in clusters:
            if _jaccard_3gram(ans, cluster[0]) >= threshold:
                cluster.append(ans)
                placed = True
                break
        if not placed:
            clusters.append([ans])

    n = len(answers)
    return -sum((len(c) / n) * math.log(len(c) / n) for c in clusters)


def extract_hidden_state(
    model: PreTrainedModel,
    tokenizer: PreTrainedTokenizerBase,
    prompt: str,
    layer: int = -1,
    aggregation: str = "last_token",
) -> np.ndarray:
    """Extract a hidden-state vector from a single forward pass.

    Args:
        model: HuggingFace causal LM (must support output_hidden_states).
        tokenizer: Matching tokenizer.
        prompt: Input text.
        layer: Which transformer layer to extract. -1 = final layer (before
            unembedding). 0 = embedding layer. Negative indices count from
            the end (Python convention).
        aggregation: How to reduce the token dimension.
            "last_token"  — hidden state of the last input token (default,
                            matches SEP paper for completion prompts).
            "mean"        — mean-pool over all token positions.

    Returns:
        1-D numpy array of shape (d_model,).
    """
    import torch

    enc = tokenizer(prompt, return_tensors="pt")
    with torch.no_grad():
        out = model(**enc, output_hidden_states=True, use_cache=False)

    # out.hidden_states: tuple of (n_layers+1) tensors, each (1, seq_len, d_model)
    hidden = out.hidden_states[layer]  # (1, seq_len, d_model)

    if aggregation == "last_token":
        vec = hidden[0, -1, :]  # last token, all hidden dims
    elif aggregation == "mean":
        vec = hidden[0].mean(dim=0)
    else:
        raise ValueError(f"Unknown aggregation '{aggregation}'. Use 'last_token' or 'mean'.")

    return vec.cpu().float().numpy()


# ---------------------------------------------------------------------------
# SemanticEntropyProbe
# ---------------------------------------------------------------------------

class SemanticEntropyProbe:
    """Linear probe that predicts semantic entropy from hidden states.

    Training (fit):
        1. For each prompt, generate n samples and compute SE.
        2. Binarise SE at the median → label y ∈ {0, 1}.
        3. Fit LogisticRegression on (hidden_states, y).

    Inference (predict / predict_proba):
        Single forward pass → hidden state → probe → p(high SE).

    Reference: arXiv:2406.15927, https://github.com/OATML/semantic-entropy-probes
    """

    def __init__(self, C: float = 1.0, max_iter: int = 1000, random_state: int = 42) -> None:
        if not _SKLEARN_AVAILABLE:
            raise ImportError(
                "scikit-learn is required for SemanticEntropyProbe. "
                "Install with: pip install scikit-learn"
            )
        self._scaler = StandardScaler()
        self._clf = LogisticRegression(
            C=C,
            max_iter=max_iter,
            random_state=random_state,
            solver="lbfgs",
        )
        self._se_threshold: float | None = None
        self._fitted = False

    # ------------------------------------------------------------------
    # Fitting
    # ------------------------------------------------------------------

    def fit(
        self,
        hidden_states: np.ndarray,
        semantic_entropies: np.ndarray,
    ) -> SemanticEntropyProbe:
        """Fit the probe from pre-computed hidden states and SE values.

        Args:
            hidden_states: Float array of shape (n_samples, d_model).
            semantic_entropies: Float array of shape (n_samples,) with
                semantic entropy in nats for each training prompt.

        Returns:
            self (for chaining).
        """
        hidden_states = np.asarray(hidden_states, dtype=np.float32)
        semantic_entropies = np.asarray(semantic_entropies, dtype=np.float32)

        if hidden_states.ndim != 2:
            raise ValueError(
                f"hidden_states must be 2-D (n_samples, d_model), got shape {hidden_states.shape}"
            )
        if semantic_entropies.ndim != 1 or len(semantic_entropies) != len(hidden_states):
            raise ValueError(
                "semantic_entropies must be 1-D with the same length as hidden_states"
            )

        # Binarise at median SE
        self._se_threshold = float(np.median(semantic_entropies))
        y = (semantic_entropies > self._se_threshold).astype(int)

        X_scaled = self._scaler.fit_transform(hidden_states)
        self._clf.fit(X_scaled, y)
        self._fitted = True
        return self

    # ------------------------------------------------------------------
    # Inference
    # ------------------------------------------------------------------

    def _check_fitted(self) -> None:
        if not self._fitted:
            raise RuntimeError("Call fit() before predict().")

    def predict(self, hidden_states: np.ndarray) -> np.ndarray:
        """Predict binary label (0 = low SE, 1 = high SE).

        Args:
            hidden_states: Float array of shape (n_samples, d_model) or (d_model,).

        Returns:
            Integer array of shape (n_samples,).
        """
        self._check_fitted()
        hidden_states = np.atleast_2d(np.asarray(hidden_states, dtype=np.float32))
        X_scaled = self._scaler.transform(hidden_states)
        return self._clf.predict(X_scaled)

    def predict_proba(self, hidden_states: np.ndarray) -> np.ndarray:
        """Predict probability of high semantic entropy.

        Args:
            hidden_states: Float array of shape (n_samples, d_model) or (d_model,).

        Returns:
            Float array of shape (n_samples, 2) — columns: [p_low_SE, p_high_SE].
        """
        self._check_fitted()
        hidden_states = np.atleast_2d(np.asarray(hidden_states, dtype=np.float32))
        X_scaled = self._scaler.transform(hidden_states)
        return self._clf.predict_proba(X_scaled)

    # ------------------------------------------------------------------
    # Persistence
    # ------------------------------------------------------------------

    def save(self, path: str | Path) -> None:
        """Pickle the probe to disk.

        Args:
            path: File path (will be created/overwritten).
        """
        self._check_fitted()
        Path(path).parent.mkdir(parents=True, exist_ok=True)
        payload = {
            "scaler": self._scaler,
            "clf": self._clf,
            "se_threshold": self._se_threshold,
        }
        with open(path, "wb") as fh:
            pickle.dump(payload, fh, protocol=pickle.HIGHEST_PROTOCOL)

    @classmethod
    def load(cls, path: str | Path) -> SemanticEntropyProbe:
        """Load a probe previously saved with save().

        SECURITY (CWE-502): This method uses ``pickle.load``, which is RCE-equivalent
        when the input is attacker-controlled. **ONLY load files you produced
        yourself, or that you have cryptographically verified** (e.g. detached
        signature with a key you trust). Never load probes downloaded from
        untrusted sources, shared in chat, or hosted on public model registries
        without explicit signature verification. For a hardened serialiser, see
        ``skops.io`` or ``joblib`` + HMAC.

        Args:
            path: File path written by save().

        Returns:
            Fitted SemanticEntropyProbe instance.
        """
        import warnings

        warnings.warn(
            "SemanticEntropyProbe.load uses pickle and will execute arbitrary "
            "code from the file. Only load probes you produced or have "
            "cryptographically verified.",
            category=UserWarning,
            stacklevel=2,
        )
        with open(path, "rb") as fh:
            payload = pickle.load(fh)  # nosec B301 - runtime UserWarning + docstring above
        obj = cls.__new__(cls)
        obj._scaler = payload["scaler"]
        obj._clf = payload["clf"]
        obj._se_threshold = payload["se_threshold"]
        obj._fitted = True
        return obj
