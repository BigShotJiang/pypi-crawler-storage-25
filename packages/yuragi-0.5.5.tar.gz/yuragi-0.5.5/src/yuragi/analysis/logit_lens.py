"""Logit Lens analysis for layer-wise token probability evolution.

Implements logit lens (nostalgebraist 2020) for GPTNeoX (Pythia) models.

Critical: Pythia-410m uses GPTNeoX architecture. HuggingFace hidden_states[i]
for i < n_layers are BEFORE final_layer_norm (ln_f).  The last hidden state
(hidden_states[-1]) is AFTER ln_f.  Intermediate states MUST have ln_f applied
before unembedding — otherwise early-layer distributions are near-uniform due
to basis mismatch (entropy 78-235x inflated; see sach_wort_probe bug 2026-04).
"""
from __future__ import annotations

import numpy as np
import torch
import torch.nn.functional as F
from transformers import PreTrainedModel, PreTrainedTokenizerBase


def _get_ln_f(model: PreTrainedModel) -> torch.nn.Module | None:
    """Return the final layer norm for GPTNeoX / GPT-2 style models."""
    if hasattr(model, "gpt_neox") and hasattr(model.gpt_neox, "final_layer_norm"):
        return model.gpt_neox.final_layer_norm
    if hasattr(model, "transformer") and hasattr(model.transformer, "ln_f"):
        return model.transformer.ln_f
    return None


def logit_lens(
    model: PreTrainedModel,
    tokenizer: PreTrainedTokenizerBase,
    prompts: list[str],
    layers: list[int] | None = None,
    top_k: int = 10,
) -> np.ndarray:
    """Compute layer-wise top-k token probabilities via the logit lens.

    Parameters
    ----------
    model:
        A HuggingFace causal LM (must support output_hidden_states).
    tokenizer:
        Corresponding tokenizer.
    prompts:
        List of n_prompts text strings.
    layers:
        Layer indices to include.  None = all layers (0..n_layers-1 plus
        the embedding layer at index 0 from hidden_states[0]).
    top_k:
        Number of top tokens to track per layer.

    Returns
    -------
    np.ndarray of shape [n_prompts, n_selected_layers, top_k]
        Each entry is the probability of the k-th ranked token at that layer
        for the *last* token position.
    """
    model.eval()
    ln_f = _get_ln_f(model)
    unembed = model.get_output_embeddings().weight.detach()  # [vocab, hidden]

    # Determine number of layers from a single forward pass
    enc0 = tokenizer(prompts[0], return_tensors="pt")
    with torch.no_grad():
        out0 = model(**enc0, output_hidden_states=True, use_cache=False)
    n_hidden = len(out0.hidden_states)  # embedding layer + n_transformer_layers

    if layers is None:
        layers = list(range(n_hidden))

    results: list[np.ndarray] = []

    for prompt in prompts:
        enc = tokenizer(prompt, return_tensors="pt")
        with torch.no_grad():
            out = model(**enc, output_hidden_states=True, use_cache=False)

        prompt_probs: list[np.ndarray] = []
        for layer_idx in layers:
            h = out.hidden_states[layer_idx][0, -1, :]  # [hidden]

            # Apply ln_f to all layers except the last hidden state,
            # which HuggingFace already normalises.
            if ln_f is not None and layer_idx < n_hidden - 1:
                h = ln_f(h.unsqueeze(0)).squeeze(0)

            logits = h @ unembed.T  # [vocab]
            probs = F.softmax(logits, dim=-1)
            topk_probs = torch.topk(probs, k=top_k).values.cpu().numpy()
            prompt_probs.append(topk_probs)

        results.append(np.stack(prompt_probs))  # [n_selected_layers, top_k]

    return np.stack(results)  # [n_prompts, n_selected_layers, top_k]


def answer_emergence_layer(
    lens_output: np.ndarray,
    target_token_id: int,
    model: PreTrainedModel,
    tokenizer: PreTrainedTokenizerBase,
    prompts: list[str],
    layers: list[int] | None = None,
) -> list[int]:
    """Find the first layer where target_token is top-1 for each prompt.

    Parameters
    ----------
    lens_output:
        Ignored; kept for API consistency.  Full token-id tracking is done
        internally via _logit_lens_with_ids.
    target_token_id:
        Vocabulary index of the answer token to track.
    model, tokenizer, prompts, layers:
        Same as logit_lens().

    Returns
    -------
    list of int, one per prompt.
        The smallest layer index at which target_token_id is argmax.
        Returns -1 if the token never reaches top-1.
    """
    model.eval()
    ln_f = _get_ln_f(model)
    unembed = model.get_output_embeddings().weight.detach()

    enc0 = tokenizer(prompts[0], return_tensors="pt")
    with torch.no_grad():
        out0 = model(**enc0, output_hidden_states=True, use_cache=False)
    n_hidden = len(out0.hidden_states)

    if layers is None:
        layers = list(range(n_hidden))

    emergence_layers: list[int] = []

    for prompt in prompts:
        enc = tokenizer(prompt, return_tensors="pt")
        with torch.no_grad():
            out = model(**enc, output_hidden_states=True, use_cache=False)

        first_layer = -1
        for layer_idx in layers:
            h = out.hidden_states[layer_idx][0, -1, :]
            if ln_f is not None and layer_idx < n_hidden - 1:
                h = ln_f(h.unsqueeze(0)).squeeze(0)
            logits = h @ unembed.T
            top1 = int(torch.argmax(logits).item())
            if top1 == target_token_id:
                first_layer = layer_idx
                break
        emergence_layers.append(first_layer)

    return emergence_layers


def confidence_progression(
    model: PreTrainedModel,
    tokenizer: PreTrainedTokenizerBase,
    prompts: list[str],
    target_token_id: int,
    layers: list[int] | None = None,
) -> list[list[float]]:
    """Return target token probability at each layer for each prompt.

    Parameters
    ----------
    model, tokenizer, prompts, target_token_id, layers:
        As above.

    Returns
    -------
    list of list of float, shape [n_prompts][n_layers].
        Probability of target_token_id at each selected layer.
    """
    model.eval()
    ln_f = _get_ln_f(model)
    unembed = model.get_output_embeddings().weight.detach()

    enc0 = tokenizer(prompts[0], return_tensors="pt")
    with torch.no_grad():
        out0 = model(**enc0, output_hidden_states=True, use_cache=False)
    n_hidden = len(out0.hidden_states)

    if layers is None:
        layers = list(range(n_hidden))

    all_progressions: list[list[float]] = []

    for prompt in prompts:
        enc = tokenizer(prompt, return_tensors="pt")
        with torch.no_grad():
            out = model(**enc, output_hidden_states=True, use_cache=False)

        prog: list[float] = []
        for layer_idx in layers:
            h = out.hidden_states[layer_idx][0, -1, :]
            if ln_f is not None and layer_idx < n_hidden - 1:
                h = ln_f(h.unsqueeze(0)).squeeze(0)
            logits = h @ unembed.T
            probs = F.softmax(logits, dim=-1)
            prog.append(float(probs[target_token_id].item()))

        all_progressions.append(prog)

    return all_progressions
