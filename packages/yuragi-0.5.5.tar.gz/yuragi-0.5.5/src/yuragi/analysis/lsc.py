"""Lowest Span Confidence (LSC) — zero-shot hallucination detection metric.

Reference
---------
"Lowest Span Confidence: A Zero-Shot Metric for Efficient and
Black-Box Hallucination Detection in LLMs"
arXiv:2601.19918

Algorithm
---------
Given a sequence of per-token log-probabilities p_1, …, p_T:

    1. Slide a window of width w over the sequence, computing the mean
       log-prob for each window position i:

           span_score(i) = mean(p_i, …, p_{i+w-1})

    2. LSC = min over all window positions.

Intuition: the *weakest* span of the response (lowest average log-prob)
is a reliable proxy for the model's uncertainty in that factual claim.
A very low LSC value indicates at least one span where the model assigned
low probability to its own tokens → hallucination signal.

Usage as hallucination predictor
---------------------------------
Higher score = more confident = less likely to hallucinate.
To convert to a "hallucination probability" that is high when the model
is uncertain, use ``-lsc_score(logprobs)`` as the predictor.

Window width w=4
----------------
The original paper evaluates w ∈ {2, 4, 8} and reports w=4 as the sweet
spot: small enough to capture a single short entity or clause, large
enough to suppress single-token noise (punctuation, articles).
"""

from __future__ import annotations

import math


def lsc_score(token_logprobs: list[float], window: int = 4) -> float:
    """Compute Lowest Span Confidence for a single response.

    Args:
        token_logprobs: Per-token log-probabilities (negative floats).
            An empty list or a list shorter than *window* falls back to
            the mean of available log-probs, or 0.0 if empty.
        window: Sliding window width in tokens (default 4, per paper).

    Returns:
        LSC score (negative float, higher = more confident).
        Returns 0.0 for an empty input.

    Examples:
        >>> lsc_score([-0.1, -0.2, -0.3, -0.4, -0.5])
        -0.35
        >>> lsc_score([-0.5, -0.5, -0.5], window=4)  # shorter than window
        -0.5
    """
    if not token_logprobs:
        return 0.0
    n = len(token_logprobs)
    if n < window:
        return sum(token_logprobs) / n
    spans = [
        sum(token_logprobs[i : i + window]) / window
        for i in range(n - window + 1)
    ]
    return min(spans)


def lsc_batch(
    batch_logprobs: list[list[float]],
    window: int = 4,
) -> list[float]:
    """Compute LSC for a batch of responses.

    Args:
        batch_logprobs: List of per-token log-prob sequences.
        window: Sliding window width (default 4).

    Returns:
        List of LSC scores, one per input sequence.
    """
    return [lsc_score(lp, window=window) for lp in batch_logprobs]


def extract_token_logprobs(raw_logprobs: list | None) -> list[float]:
    """Extract the top-1 log-prob for each token from adapter raw_logprobs.

    ``raw_logprobs`` in :class:`~yuragi.providers.adapter.CompletionResult`
    is a list-of-lists: each inner list contains ``(token, logprob)`` pairs
    for one output token, ordered by descending probability.  The first pair
    is therefore the chosen token's log-prob.

    Args:
        raw_logprobs: Value of ``CompletionResult.raw_logprobs``, or *None*.

    Returns:
        List of chosen-token log-probs (negative floats).
        Returns an empty list if *raw_logprobs* is None or empty.
    """
    if not raw_logprobs:
        return []
    result: list[float] = []
    for token_candidates in raw_logprobs:
        if token_candidates:
            _token, lp = token_candidates[0]
            if lp is not None and not math.isnan(lp) and not math.isinf(lp):
                result.append(float(lp))
    return result
