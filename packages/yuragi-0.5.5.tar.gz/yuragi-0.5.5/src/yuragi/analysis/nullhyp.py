"""Null hypothesis tests for yuragi hallucination detection experiments.

Provides permutation-based AUC null tests, cross-template binomial test,
and Wilson score interval. Designed to be called on pre-computed score
arrays without any model inference.

All functions are deterministic via seed=42 default.
"""

from __future__ import annotations

import math
from collections.abc import Sequence


def _require_numpy():
    try:
        import numpy as np

        return np
    except ImportError as err:
        raise ImportError(
            "numpy is required for null hypothesis tests. "
            "Install with: pip install numpy"
        ) from err


def _require_sklearn_auc():
    try:
        from sklearn.metrics import roc_auc_score

        return roc_auc_score
    except ImportError as err:
        raise ImportError(
            "scikit-learn is required for AUC computation. "
            "Install with: pip install scikit-learn"
        ) from err


def permutation_auc_p(
    y_true: Sequence[int | bool],
    y_score: Sequence[float],
    n_iter: int = 10000,
    seed: int = 42,
) -> float:
    """One-sided permutation p-value for AUC > chance.

    Shuffles y_score n_iter times and computes the fraction of permutations
    that achieve AUC >= observed AUC. A small p-value (< 0.05) indicates the
    observed AUC is unlikely under the null hypothesis of no association.

    Args:
        y_true: Binary ground-truth labels (0/1 or bool).
        y_score: Continuous score values to rank.
        n_iter: Number of permutation iterations.
        seed: Random seed for reproducibility.

    Returns:
        One-sided p-value: fraction of permutations with AUC >= observed.
    """
    np = _require_numpy()
    roc_auc_score = _require_sklearn_auc()

    y_true_arr = np.asarray(y_true, dtype=int)
    y_score_arr = np.asarray(y_score, dtype=float)

    if len(y_true_arr) != len(y_score_arr):
        raise ValueError("y_true and y_score must have the same length")
    if len(np.unique(y_true_arr)) < 2:
        raise ValueError("y_true must contain at least two classes")

    observed_auc = float(roc_auc_score(y_true_arr, y_score_arr))

    rng = np.random.default_rng(seed)
    count_gte = 0
    for _ in range(n_iter):
        shuffled = rng.permutation(y_score_arr)
        perm_auc = float(roc_auc_score(y_true_arr, shuffled))
        if perm_auc >= observed_auc:
            count_gte += 1

    return count_gte / n_iter


def permutation_delta_p(
    y_score_a: Sequence[float],
    y_score_b: Sequence[float],
    y_true: Sequence[int | bool],
    n_iter: int = 10000,
    seed: int = 42,
) -> float:
    """Two-sided permutation p-value for difference in AUC between two scorers.

    Computes the observed delta = AUC(y_score_a) - AUC(y_score_b), then
    estimates a null distribution by randomly swapping (per-sample) which
    score belongs to scorer A vs scorer B. Returns the fraction of permutations
    where |delta_perm| >= |observed delta|.

    Args:
        y_score_a: Score array for model/config A.
        y_score_b: Score array for model/config B (same samples as A).
        y_true: Binary ground-truth labels.
        n_iter: Number of permutation iterations.
        seed: Random seed for reproducibility.

    Returns:
        Two-sided p-value for H0: AUC(A) == AUC(B).
    """
    np = _require_numpy()
    roc_auc_score = _require_sklearn_auc()

    a = np.asarray(y_score_a, dtype=float)
    b = np.asarray(y_score_b, dtype=float)
    yt = np.asarray(y_true, dtype=int)

    if len(a) != len(b) or len(a) != len(yt):
        raise ValueError("y_score_a, y_score_b, and y_true must have equal length")
    if len(np.unique(yt)) < 2:
        raise ValueError("y_true must contain at least two classes")

    observed_delta = float(roc_auc_score(yt, a)) - float(roc_auc_score(yt, b))

    rng = np.random.default_rng(seed)
    count_gte = 0
    stacked = np.stack([a, b], axis=1)  # (n, 2)
    for _ in range(n_iter):
        swap_mask = rng.integers(0, 2, size=len(a)).astype(bool)
        perm_a = np.where(swap_mask, stacked[:, 1], stacked[:, 0])
        perm_b = np.where(swap_mask, stacked[:, 0], stacked[:, 1])
        perm_delta = float(roc_auc_score(yt, perm_a)) - float(roc_auc_score(yt, perm_b))
        if abs(perm_delta) >= abs(observed_delta):
            count_gte += 1

    return count_gte / n_iter


def binomial_cross_template_p(k: int, n: int, chance: float = 0.5) -> float:
    """Exact two-sided binomial p-value for cross-template win rate.

    Tests H0: win_rate == chance against H1: win_rate != chance.
    Uses the exact binomial CDF via scipy.stats if available, otherwise
    falls back to a pure-Python implementation.

    Args:
        k: Number of successes (wins).
        n: Total number of trials.
        chance: Null hypothesis probability of success (default 0.5).

    Returns:
        Two-sided p-value.
    """
    if not (0 < chance < 1):
        raise ValueError("chance must be strictly between 0 and 1")
    if k < 0 or k > n:
        raise ValueError("k must satisfy 0 <= k <= n")
    if n == 0:
        return 1.0

    try:
        from scipy.stats import binom

        return float(binom.cdf(min(k, n - k), n, chance) * 2)
    except ImportError:
        pass

    # Pure-Python fallback: exact binomial CDF
    def _binom_pmf(kk: int, nn: int, pp: float) -> float:
        log_c = (
            math.lgamma(nn + 1) - math.lgamma(kk + 1) - math.lgamma(nn - kk + 1)
        )
        return math.exp(log_c + kk * math.log(pp) + (nn - kk) * math.log(1 - pp))

    tail_k = min(k, n - k)
    p_two_sided = sum(_binom_pmf(j, n, chance) for j in range(tail_k + 1)) * 2
    return min(p_two_sided, 1.0)


def wilson_ci(k: int, n: int, alpha: float = 0.05) -> tuple[float, float]:
    """Wilson score confidence interval for a proportion.

    Args:
        k: Number of successes.
        n: Total number of trials.
        alpha: Significance level; 0.05 gives a 95% CI.

    Returns:
        (lower, upper) Wilson score interval.

    Raises:
        ValueError: If k > n or n == 0.
    """
    if n == 0:
        raise ValueError("n must be > 0")
    if k < 0 or k > n:
        raise ValueError("k must satisfy 0 <= k <= n")

    try:
        from scipy.stats import norm

        z = float(norm.ppf(1 - alpha / 2))
    except ImportError:
        # Hardcoded z for common alpha values
        _z_table = {0.05: 1.95996, 0.01: 2.57583, 0.10: 1.64485}
        if alpha not in _z_table:
            raise ImportError(
                "scipy is required for non-standard alpha values in wilson_ci. "
                "Install with: pip install scipy"
            )
        z = _z_table[alpha]

    p_hat = k / n
    z2 = z * z
    denom = 1 + z2 / n
    center = (p_hat + z2 / (2 * n)) / denom
    margin = (z / denom) * math.sqrt(p_hat * (1 - p_hat) / n + z2 / (4 * n * n))
    lower = max(0.0, center - margin)
    upper = min(1.0, center + margin)
    return lower, upper
