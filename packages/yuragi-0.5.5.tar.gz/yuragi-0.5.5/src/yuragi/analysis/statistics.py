"""Statistical analysis for confidence fragility.

Provides rigorous statistical tests beyond simple mean/variance,
including effect size (Cohen's d), bootstrap confidence intervals,
and significance testing.
"""

from __future__ import annotations

from dataclasses import dataclass

from yuragi.config import DEFAULT_CONFIG, YuragiConfig
from yuragi.core import ScanResult
from yuragi.metrics.statistical_tests import bootstrap_ci as _bootstrap_ci_fast


@dataclass
class StatisticalReport:
    """Comprehensive statistical analysis of a scan."""

    n_perturbations: int
    baseline_confidence: float

    # Central tendency
    mean_confidence: float
    median_confidence: float
    std_confidence: float

    # Effect size
    cohens_d: float  # Standardized effect size
    effect_size_label: str  # "negligible", "small", "medium", "large"

    # Bootstrap CI
    ci_lower: float  # 95% CI lower bound
    ci_upper: float  # 95% CI upper bound

    # Fragility metrics
    fragility_score: float
    max_drop: float
    max_boost: float
    dissociation_rate: float

    # Non-linearity
    coefficient_of_variation: float  # std/mean — higher = more non-linear
    interquartile_range: float


def analyze(
    result: ScanResult,
    bootstrap_iterations: int | None = None,
    config: YuragiConfig | None = None,
) -> StatisticalReport:
    """Run comprehensive statistical analysis on scan results.

    Args:
        result: A completed ScanResult
        bootstrap_iterations: Number of bootstrap samples for CI estimation.
            Defaults to config.bootstrap_iterations (1000).
        config: Optional YuragiConfig for threshold overrides.
    """
    cfg = config or getattr(result, "config", None) or DEFAULT_CONFIG
    if bootstrap_iterations is None:
        bootstrap_iterations = cfg.bootstrap_iterations

    if not result.perturbation_results:
        return _empty_report(result.baseline.confidence)

    confidences = [r.perturbed_response.confidence for r in result.perturbation_results]
    deltas = [r.confidence_delta for r in result.perturbation_results]
    n = len(confidences)

    # Central tendency
    mean_conf = sum(confidences) / n
    sorted_conf = sorted(confidences)
    median_conf = sorted_conf[n // 2] if n % 2 else (sorted_conf[n // 2 - 1] + sorted_conf[n // 2]) / 2

    # Standard deviation (unbiased, ddof=1)
    if n < 2:
        std_conf = 0.0
    else:
        variance = sum((c - mean_conf) ** 2 for c in confidences) / (n - 1)
        std_conf = variance ** 0.5

    # Cohen's d: baseline is a single measurement, using one-sample effect size.
    # d = (mean_perturbed - baseline) / std_perturbed
    baseline = result.baseline.confidence
    cohens_d = abs((mean_conf - baseline) / std_conf) if std_conf > 0 else 0.0

    if cohens_d < cfg.cohens_d_small:
        effect_label = "negligible"
    elif cohens_d < cfg.cohens_d_medium:
        effect_label = "small"
    elif cohens_d < cfg.cohens_d_large:
        effect_label = "medium"
    else:
        effect_label = "large"

    # Bootstrap 95% CI for mean delta — delegate to fast numpy vectorised path
    _ci = _bootstrap_ci_fast(deltas, n_iterations=bootstrap_iterations, seed=cfg.seed)
    ci_lower, ci_upper = _ci.lower, _ci.upper

    # Coefficient of variation
    cv = std_conf / mean_conf if mean_conf > 0 else 0.0

    # IQR
    q1_idx = n // 4
    q3_idx = (3 * n) // 4
    iqr = sorted_conf[q3_idx] - sorted_conf[q1_idx] if n >= 4 else 0.0

    return StatisticalReport(
        n_perturbations=n,
        baseline_confidence=result.baseline.confidence,
        mean_confidence=mean_conf,
        median_confidence=median_conf,
        std_confidence=std_conf,
        cohens_d=cohens_d,
        effect_size_label=effect_label,
        ci_lower=ci_lower,
        ci_upper=ci_upper,
        fragility_score=result.fragility_score,
        max_drop=result.max_confidence_drop,
        max_boost=max(r.confidence_delta for r in result.perturbation_results),
        dissociation_rate=result.dissociation_rate,
        coefficient_of_variation=cv,
        interquartile_range=iqr,
    )



def _empty_report(baseline: float) -> StatisticalReport:
    return StatisticalReport(
        n_perturbations=0,
        baseline_confidence=baseline,
        mean_confidence=baseline,
        median_confidence=baseline,
        std_confidence=0.0,
        cohens_d=0.0,
        effect_size_label="negligible",
        ci_lower=0.0,
        ci_upper=0.0,
        fragility_score=0.0,
        max_drop=0.0,
        max_boost=0.0,
        dissociation_rate=0.0,
        coefficient_of_variation=0.0,
        interquartile_range=0.0,
    )
