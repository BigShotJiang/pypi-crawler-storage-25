"""Semantic Token Clustering (STC) for hallucination detection.

Single-forward-pass uncertainty estimation via token-level embedding clustering.
Avoids the multi-sample overhead of full semantic entropy (Farquhar et al., Nature 2024).

Reference:
    arXiv:2603.20161 (2026-03) — Semantic Token Clustering

Core idea:
    1. Generate tokens greedily (single pass, T=0).
    2. Embed each generated token via the model's embedding matrix.
    3. Detect semantic spans via cosine similarity prefix matching.
    4. Cluster spans (KMeans / agglomerative, k auto-selected via silhouette).
    5. Aggregate token log-probabilities per cluster.
    6. Shannon entropy over cluster probabilities = STC_entropy (hallucination proxy).
"""
from __future__ import annotations

import math
from typing import TYPE_CHECKING

import numpy as np

try:
    from sklearn.cluster import AgglomerativeClustering, KMeans
    from sklearn.metrics import silhouette_score
    _SKLEARN_AVAILABLE = True
except ImportError:  # pragma: no cover
    _SKLEARN_AVAILABLE = False

if TYPE_CHECKING:
    from transformers import PreTrainedModel, PreTrainedTokenizerBase


# ---------------------------------------------------------------------------
# Step 1 — token embeddings from a generated sequence
# ---------------------------------------------------------------------------

def compute_token_embeddings(
    model: PreTrainedModel,
    tokenizer: PreTrainedTokenizerBase,
    text: str,
    layer: int | None = None,
) -> np.ndarray:
    """Extract per-token embeddings for a text string.

    When *layer* is None the static token embedding matrix (input embeddings)
    is used — shape (vocab, d_model).  When *layer* is an integer the hidden
    states of that layer are used instead, which gives contextualised
    representations.

    Args:
        model: HuggingFace causal LM supporting output_hidden_states.
        tokenizer: Matching tokenizer.
        text: Input text whose tokens are embedded.
        layer: Transformer layer index for contextualised embeddings.
            None = static input embeddings (fast, no forward pass required).
            0 = embedding layer output, -1 = final layer, etc.

    Returns:
        Float32 array of shape (T, d_model) where T = number of tokens.
    """
    import torch

    enc = tokenizer(text, return_tensors="pt")
    token_ids = enc["input_ids"][0]  # (T,)

    if layer is None:
        # Static lookup: no forward pass needed
        embed_matrix = model.get_input_embeddings().weight  # (vocab, d)
        with torch.no_grad():
            vecs = embed_matrix[token_ids]  # (T, d)
        return vecs.cpu().float().numpy()

    with torch.no_grad():
        out = model(**enc, output_hidden_states=True, use_cache=False)
    # hidden_states: tuple of (n_layers+1) tensors, each (1, T, d)
    hidden = out.hidden_states[layer]  # (1, T, d)
    return hidden[0].cpu().float().numpy()  # (T, d)


# ---------------------------------------------------------------------------
# Step 2 — prefix-matching span detection
# ---------------------------------------------------------------------------

def _cosine_sim(a: np.ndarray, b: np.ndarray) -> float:
    """Cosine similarity between two 1-D vectors."""
    norm_a = np.linalg.norm(a)
    norm_b = np.linalg.norm(b)
    if norm_a < 1e-10 or norm_b < 1e-10:
        return 0.0
    return float(np.dot(a, b) / (norm_a * norm_b))


def detect_semantic_spans(
    token_embeddings: np.ndarray,
    sim_threshold: float = 0.85,
) -> list[tuple[int, int]]:
    """Group adjacent tokens into spans via cosine similarity prefix matching.

    Adjacent tokens with cosine similarity >= *sim_threshold* are merged into
    the same span.  The algorithm scans left-to-right, comparing each token to
    the *span anchor* (first token of the current span).

    Args:
        token_embeddings: Float array of shape (T, d_model).
        sim_threshold: Cosine similarity threshold for span merging.
            Higher = stricter (more, shorter spans).

    Returns:
        List of (start, end) index pairs (end exclusive) representing spans.
        Always covers [0, T) with no gaps.
    """
    T = len(token_embeddings)
    if T == 0:
        return []
    if T == 1:
        return [(0, 1)]

    spans: list[tuple[int, int]] = []
    span_start = 0

    for i in range(1, T):
        sim = _cosine_sim(token_embeddings[span_start], token_embeddings[i])
        if sim < sim_threshold:
            spans.append((span_start, i))
            span_start = i

    spans.append((span_start, T))
    return spans


# ---------------------------------------------------------------------------
# Step 3 — span clustering
# ---------------------------------------------------------------------------

def cluster_spans(
    span_embeddings: np.ndarray,
    k: int | None = None,
    max_k: int = 8,
    random_state: int = 42,
) -> np.ndarray:
    """Cluster span embeddings, auto-selecting k via silhouette score.

    Args:
        span_embeddings: Float array of shape (S, d_model) — one row per span
            (e.g. mean of token embeddings in that span).
        k: Fixed number of clusters.  When None, k is chosen in [2, max_k]
            by maximising the silhouette score.  Falls back to k=1 when S <= 1.
        max_k: Upper bound for auto k search.
        random_state: Seed for KMeans reproducibility.

    Returns:
        Integer array of shape (S,) with cluster labels in [0, k-1].
    """
    if not _SKLEARN_AVAILABLE:
        raise ImportError("scikit-learn is required for cluster_spans.")

    S = len(span_embeddings)
    if S <= 1:
        return np.zeros(S, dtype=int)

    if k is not None:
        k = min(k, S)
        if k == 1:
            return np.zeros(S, dtype=int)
        km = KMeans(n_clusters=k, random_state=random_state, n_init="auto")
        return km.fit_predict(span_embeddings).astype(int)

    # Auto-select k via silhouette score
    best_k = 2
    best_score = -1.0
    best_labels = None

    k_max = min(max_k, S - 1)
    if k_max < 2:
        return np.zeros(S, dtype=int)

    for candidate_k in range(2, k_max + 1):
        km = KMeans(n_clusters=candidate_k, random_state=random_state, n_init="auto")
        labels = km.fit_predict(span_embeddings)
        # silhouette_score needs at least 2 distinct labels
        if len(np.unique(labels)) < 2:
            continue
        score = silhouette_score(span_embeddings, labels)
        if score > best_score:
            best_score = score
            best_k = candidate_k
            best_labels = labels.copy()

    if best_labels is None:
        return np.zeros(S, dtype=int)

    return best_labels.astype(int)


# ---------------------------------------------------------------------------
# Step 4-5 — STC entropy
# ---------------------------------------------------------------------------

def stc_entropy(
    tokens: list[int],
    logprobs: list[float],
    spans: list[tuple[int, int]],
    labels: np.ndarray,
) -> float:
    """Compute STC entropy from cluster-aggregated token log-probabilities.

    Formula:
        p_c = sum of exp(logprob_i) for tokens i in cluster c
        (then renormalized so sum(p_c) = 1)
        STC_entropy = -sum_c p_c * log(p_c)   [Shannon, nats]

    Args:
        tokens: List of T token ids (not used in computation, kept for API
            clarity and future extensions).
        logprobs: List of T log-probabilities (log P(token_i | prefix)).
        spans: List of (start, end) span index pairs as returned by
            detect_semantic_spans.
        labels: Integer array of shape (S,) cluster labels for each span.

    Returns:
        STC entropy in nats (>= 0.0).  Returns 0.0 for empty or single-token
        inputs (no diversity possible).
    """
    T = len(logprobs)
    if T == 0:
        return 0.0
    if T == 1:
        return 0.0

    S = len(spans)
    if S == 0:
        return 0.0

    # Map each token to its span index, then to its cluster label
    token_cluster = np.empty(T, dtype=int)
    for span_idx, (start, end) in enumerate(spans):
        token_cluster[start:end] = labels[span_idx] if span_idx < len(labels) else 0

    # Aggregate probabilities per cluster
    n_clusters = int(labels.max()) + 1 if len(labels) > 0 else 1
    cluster_probs = np.zeros(n_clusters, dtype=np.float64)
    for i, lp in enumerate(logprobs):
        c = int(token_cluster[i])
        cluster_probs[c] += math.exp(lp)

    total = cluster_probs.sum()
    if total < 1e-30:
        return 0.0

    cluster_probs /= total  # normalise

    # Shannon entropy
    entropy = 0.0
    for p in cluster_probs:
        if p > 1e-30:
            entropy -= p * math.log(p)

    return float(entropy)


# ---------------------------------------------------------------------------
# High-level helper: single text -> STC entropy
# ---------------------------------------------------------------------------

def compute_stc_entropy(
    model: PreTrainedModel,
    tokenizer: PreTrainedTokenizerBase,
    prompt: str,
    max_new_tokens: int = 20,
    sim_threshold: float = 0.85,
    layer: int | None = None,
    k: int | None = None,
) -> dict:
    """Full STC pipeline: generate -> embed -> span -> cluster -> entropy.

    Args:
        model: HuggingFace causal LM.
        tokenizer: Matching tokenizer.
        prompt: Input prompt string.
        max_new_tokens: Number of new tokens to generate (greedy, T=0).
        sim_threshold: Cosine similarity threshold for span detection.
        layer: Embedding layer (None = static input embeddings).
        k: Fixed cluster count (None = auto via silhouette).

    Returns:
        Dict with keys:
            stc_entropy (float): STC entropy in nats.
            n_tokens (int): Number of generated tokens.
            n_spans (int): Number of detected spans.
            n_clusters (int): Number of clusters used.
            generated_text (str): Decoded generated tokens.
    """
    import torch

    enc = tokenizer(prompt, return_tensors="pt")
    prompt_len = enc["input_ids"].shape[1]

    with torch.no_grad():
        out = model.generate(
            **enc,
            max_new_tokens=max_new_tokens,
            do_sample=False,
            temperature=1.0,
            output_scores=True,
            return_dict_in_generate=True,
        )

    # Generated token ids (excluding prompt)
    gen_ids = out.sequences[0, prompt_len:]  # (T_gen,)
    T = len(gen_ids)

    if T == 0:
        return {
            "stc_entropy": 0.0,
            "n_tokens": 0,
            "n_spans": 0,
            "n_clusters": 0,
            "generated_text": "",
        }

    # Log-probabilities for each generated token
    # out.scores: tuple of T tensors, each (1, vocab)
    import torch.nn.functional as F
    logprobs = []
    for step, score_tensor in enumerate(out.scores):
        log_prob_dist = F.log_softmax(score_tensor[0], dim=-1)
        token_id = int(gen_ids[step])
        logprobs.append(float(log_prob_dist[token_id]))

    # Token embeddings for generated tokens
    gen_ids_np = gen_ids.cpu().numpy()
    gen_text = tokenizer.decode(gen_ids_np, skip_special_tokens=True)

    # Embed generated tokens (static lookup is fastest and sufficient)
    embed_matrix = model.get_input_embeddings().weight  # (vocab, d)
    with torch.no_grad():
        token_embs = embed_matrix[gen_ids].cpu().float().numpy()  # (T, d)

    spans = detect_semantic_spans(token_embs, sim_threshold=sim_threshold)

    # Span embeddings: mean of token embeddings per span
    span_embs = np.stack([
        token_embs[s:e].mean(axis=0) for s, e in spans
    ])  # (S, d)

    labels = cluster_spans(span_embs, k=k)
    n_clusters = int(labels.max()) + 1 if len(labels) > 0 else 1

    entropy = stc_entropy(
        tokens=gen_ids_np.tolist(),
        logprobs=logprobs,
        spans=spans,
        labels=labels,
    )

    return {
        "stc_entropy": entropy,
        "n_tokens": T,
        "n_spans": len(spans),
        "n_clusters": n_clusters,
        "generated_text": gen_text,
    }
