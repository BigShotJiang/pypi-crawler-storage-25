"""Conformal prediction for yuragi hallucination detection metrics.

Provides finite-sample coverage guarantees (split conformal) and
selective prediction (abstain on high-uncertainty samples) for AUC estimation.

Inspired by SCOPE (arxiv:2602.13110) but uses the two core functions:
  1. split_conformal_interval — marginal coverage guarantee
  2. selective_prediction    — abstain on low-confidence samples

All functions are API-free, offline-only, using existing JSON data.

References
----------
Venn-ABERS / split conformal: Angelopoulos & Bates (2021), arXiv:2107.07511
SCOPE: arxiv:2602.13110 (2026-02)
"""

from __future__ import annotations

import math
from collections.abc import Sequence

import numpy as np
from sklearn.metrics import roc_auc_score

# ---------------------------------------------------------------------------
# 1. Split Conformal Interval
# ---------------------------------------------------------------------------

def split_conformal_interval(
    calib_scores: Sequence[float],
    calib_labels: Sequence[bool],
    test_scores: Sequence[float],
    alpha: float = 0.05,
) -> tuple[np.ndarray, np.ndarray, float]:
    """Compute split conformal predictive intervals for binary classification.

    Uses the non-conformity score |y - score| evaluated on the calibration
    set to derive a coverage-adjusted threshold. For binary labels (0/1)
    this gives a marginal coverage guarantee: the true label lies in the
    predicted interval with probability >= 1 - alpha.

    Parameters
    ----------
    calib_scores : sequence of float
        Model scores (e.g. baseline_confidence) on calibration samples.
    calib_labels : sequence of bool
        Ground-truth correctness on calibration samples (True = correct).
    test_scores  : sequence of float
        Model scores on test samples to predict.
    alpha        : float
        Miscoverage rate (default 0.05 → 95% coverage).

    Returns
    -------
    lower : np.ndarray, shape (n_test,)
        Lower bound of predictive interval for each test sample.
    upper : np.ndarray, shape (n_test,)
        Upper bound of predictive interval for each test sample.
    q_hat : float
        Conformal quantile used (the (1-alpha)(1+1/n)-th quantile of
        non-conformity scores on the calibration set).
    """
    calib_scores = np.asarray(calib_scores, dtype=float)
    calib_labels = np.asarray(calib_labels, dtype=float)
    test_scores = np.asarray(test_scores, dtype=float)

    n = len(calib_scores)
    if n < 2:
        raise ValueError("split_conformal_interval requires >= 2 calibration samples.")

    # Non-conformity score: absolute residual from label
    nonconf = np.abs(calib_labels - calib_scores)

    # Conformal quantile: ceil((n+1)(1-alpha))/n percentile
    level = math.ceil((n + 1) * (1.0 - alpha)) / n
    level = min(level, 1.0)
    q_hat = float(np.quantile(nonconf, level))

    lower = np.clip(test_scores - q_hat, 0.0, 1.0)
    upper = np.clip(test_scores + q_hat, 0.0, 1.0)

    return lower, upper, q_hat


# ---------------------------------------------------------------------------
# 2. Selective Prediction
# ---------------------------------------------------------------------------

def selective_prediction(
    scores: Sequence[float],
    labels: Sequence[bool],
    coverage_target: float = 0.8,
    alpha: float = 0.05,
) -> dict[str, object]:
    """Selective prediction: abstain on high-uncertainty samples.

    Retains only the ``coverage_target`` fraction of samples where the
    model is most confident (highest score). For a good UQ metric, AUC
    should increase as coverage decreases (more abstaining = better subset).

    Parameters
    ----------
    scores         : sequence of float
        Model scores (higher = more confident).
    labels         : sequence of bool
        Ground-truth correctness.
    coverage_target: float
        Fraction of samples to keep (0 < coverage_target <= 1).
    alpha          : float
        Significance level for bootstrap CI on selective AUC.

    Returns
    -------
    dict with keys:
        coverage      : actual achieved coverage
        n_selected    : number of samples retained
        n_abstained   : number of samples abstained
        auc           : AUC on selected subset (NaN if not computable)
        ci_lower      : 95% bootstrap CI lower
        ci_upper      : 95% bootstrap CI upper
        selected_mask : boolean array of which samples were kept
    """
    scores = np.asarray(scores, dtype=float)
    labels = np.asarray(labels, dtype=bool)

    n = len(scores)
    k = max(1, int(math.ceil(n * coverage_target)))
    k = min(k, n)

    # Select top-k by descending score
    order = np.argsort(scores)[::-1]
    selected = order[:k]
    selected_mask = np.zeros(n, dtype=bool)
    selected_mask[selected] = True

    sel_scores = scores[selected_mask]
    sel_labels = labels[selected_mask]

    # AUC requires at least one positive and one negative
    n_pos = int(sel_labels.sum())
    n_neg = k - n_pos

    if n_pos < 1 or n_neg < 1:
        auc = float("nan")
        ci_lower = float("nan")
        ci_upper = float("nan")
    else:
        auc = float(roc_auc_score(sel_labels.astype(int), sel_scores))
        rng = np.random.default_rng(42)
        boot_aucs = []
        for _ in range(500):
            idx = rng.integers(0, k, size=k)
            bl = sel_labels[idx]
            bs = sel_scores[idx]
            if bl.sum() < 1 or (k - int(bl.sum())) < 1:
                continue
            boot_aucs.append(roc_auc_score(bl.astype(int), bs))
        if len(boot_aucs) >= 10:
            ci_lower = float(np.percentile(boot_aucs, 100 * alpha / 2))
            ci_upper = float(np.percentile(boot_aucs, 100 * (1 - alpha / 2)))
        else:
            ci_lower = float("nan")
            ci_upper = float("nan")

    return {
        "coverage": k / n,
        "n_selected": k,
        "n_abstained": n - k,
        "auc": auc,
        "ci_lower": ci_lower,
        "ci_upper": ci_upper,
        "selected_mask": selected_mask,
    }


# ---------------------------------------------------------------------------
# 3. Conformal AUC with multiple random splits
# ---------------------------------------------------------------------------

def conformal_auc(
    scores: Sequence[float],
    labels: Sequence[bool],
    n_calib_frac: float = 0.5,
    alpha: float = 0.05,
    n_iter: int = 100,
    seed: int = 42,
) -> dict[str, float]:
    """Estimate AUC with finite-sample conformal guarantee via random splits.

    Splits the dataset into calibration (size = n_calib_frac * n) and test
    sets repeatedly. On each split, computes:
      - AUC on test set
      - Conformal q_hat (width of predictive interval) on calibration set
      - Empirical coverage on test set (fraction of labels inside interval)

    Returns mean ± CI of AUC and coverage across splits.

    Parameters
    ----------
    scores       : sequence of float
        Model scores.
    labels       : sequence of bool
        Ground-truth correctness.
    n_calib_frac : float
        Fraction used as calibration (default 0.5).
    alpha        : float
        Target miscoverage level (default 0.05 → 95%).
    n_iter       : int
        Number of random splits (default 100).
    seed         : int
        RNG seed (default 42).

    Returns
    -------
    dict with keys:
        auc_mean, auc_ci_lower, auc_ci_upper,
        coverage_mean, coverage_ci_lower, coverage_ci_upper,
        q_hat_mean,
        n, n_calib, n_test
    """
    scores = np.asarray(scores, dtype=float)
    labels = np.asarray(labels, dtype=bool)
    n = len(scores)

    n_calib = max(2, int(round(n * n_calib_frac)))
    n_test = n - n_calib

    if n_test < 2:
        raise ValueError(
            f"Too few test samples ({n_test}). Reduce n_calib_frac or increase n."
        )

    rng = np.random.default_rng(seed)
    auc_list: list[float] = []
    cov_list: list[float] = []
    qhat_list: list[float] = []

    for _ in range(n_iter):
        perm = rng.permutation(n)
        calib_idx = perm[:n_calib]
        test_idx = perm[n_calib:]

        c_scores = scores[calib_idx]
        c_labels = labels[calib_idx]
        t_scores = scores[test_idx]
        t_labels = labels[test_idx]

        # Skip iteration if test set has only one class
        if t_labels.sum() < 1 or (n_test - int(t_labels.sum())) < 1:
            continue

        auc_list.append(float(roc_auc_score(t_labels.astype(int), t_scores)))

        # Conformal interval and empirical coverage
        try:
            lower, upper, q_hat = split_conformal_interval(
                c_scores, c_labels, t_scores, alpha=alpha
            )
            in_interval = (t_labels.astype(float) >= lower) & (
                t_labels.astype(float) <= upper
            )
            cov_list.append(float(in_interval.mean()))
            qhat_list.append(q_hat)
        except ValueError:
            pass

    if len(auc_list) < 5:
        raise ValueError("Too few valid splits to estimate AUC. Check label balance.")

    auc_arr = np.array(auc_list)
    cov_arr = np.array(cov_list) if cov_list else np.array([float("nan")])

    return {
        "auc_mean": float(auc_arr.mean()),
        "auc_ci_lower": float(np.percentile(auc_arr, 100 * alpha / 2)),
        "auc_ci_upper": float(np.percentile(auc_arr, 100 * (1 - alpha / 2))),
        "coverage_mean": float(cov_arr.mean()),
        "coverage_ci_lower": float(np.percentile(cov_arr, 100 * alpha / 2)),
        "coverage_ci_upper": float(np.percentile(cov_arr, 100 * (1 - alpha / 2))),
        "q_hat_mean": float(np.mean(qhat_list)) if qhat_list else float("nan"),
        "n": n,
        "n_calib": n_calib,
        "n_test": n_test,
    }


# ---------------------------------------------------------------------------
# 4. Selective AUC at multiple coverage levels
# ---------------------------------------------------------------------------

def selective_auc_at_coverage(
    scores: Sequence[float],
    labels: Sequence[bool],
    coverages: Sequence[float] = (0.5, 0.7, 0.9),
    alpha: float = 0.05,
) -> list[dict[str, object]]:
    """Compute selective AUC at each requested coverage level.

    A valid UQ metric should show AUC increasing (or staying high) as
    coverage decreases (more selective = higher-quality subset).

    Parameters
    ----------
    scores    : sequence of float
        Model scores (higher = more confident).
    labels    : sequence of bool
        Ground-truth correctness.
    coverages : sequence of float
        Coverage fractions to evaluate (default [0.5, 0.7, 0.9]).
    alpha     : float
        CI level (default 0.05).

    Returns
    -------
    list of dicts, one per coverage level, each containing:
        coverage_target, coverage, n_selected, n_abstained,
        auc, ci_lower, ci_upper
    """
    results = []
    for cov in sorted(coverages, reverse=True):
        row = selective_prediction(scores, labels, coverage_target=cov, alpha=alpha)
        row["coverage_target"] = cov
        results.append(row)
    return results
