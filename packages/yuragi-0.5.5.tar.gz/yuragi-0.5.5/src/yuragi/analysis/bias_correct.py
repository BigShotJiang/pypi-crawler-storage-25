"""
bias_correct.py — length-residualized and family-balanced AUC correction.

Round 2-1 判明バイアス:
  - Length bias: Spearman ρ=+0.35 (flex), +0.387 (majority) — 長い回答が CORRECT 判定されやすい
  - Self-preference bias: llama-family judge +12.2pp vs gpt-oss
"""

from __future__ import annotations

import warnings

import numpy as np
from scipy import stats
from sklearn.metrics import roc_auc_score
from statsmodels.regression.linear_model import OLS
from statsmodels.tools import add_constant

__all__ = [
    "auc_bias_corrected",
    "family_balanced_majority",
    "length_residualize",
]

SEED = 42
N_BOOT = 2000


def length_residualize(
    scores: np.ndarray,
    answer_lengths: np.ndarray,
    poly_order: int = 1,
) -> np.ndarray:
    """OLS で score から answer_length との線形(または多項式)相関を除去する。

    Parameters
    ----------
    scores:
        連続値スコア (baseline_confidence, fragility_score など)。shape (n,)
    answer_lengths:
        文字数またはトークン数。shape (n,)
    poly_order:
        1=線形, 2=二次多項式。デフォルト1。

    Returns
    -------
    residuals: np.ndarray
        OLS 残差。Spearman ρ(residuals, length) ≈ 0 を確認すること。
    """
    scores = np.asarray(scores, dtype=float)
    lengths = np.asarray(answer_lengths, dtype=float)

    if poly_order == 1:
        X = add_constant(lengths)
    else:
        X = np.column_stack(
            [lengths ** k for k in range(1, poly_order + 1)]
        )
        X = add_constant(X)

    with warnings.catch_warnings():
        warnings.simplefilter("ignore")
        model = OLS(scores, X).fit()

    residuals = model.resid

    rho_before, _ = stats.spearmanr(scores, lengths)
    rho_after, _ = stats.spearmanr(residuals, lengths)

    # sanity: residual ρ should be near zero
    if abs(rho_after) > 0.05:
        warnings.warn(
            f"length_residualize: residual Spearman ρ={rho_after:.3f} (>0.05). "
            "Non-linear length dependence may remain.",
            UserWarning,
        )

    return residuals


def family_balanced_majority(
    judge_labels_by_family: dict[str, list[str]],
    strategy: str = "majority_of_families",
) -> np.ndarray:
    """llama-family self-preference を中和するファミリー均等多数決。

    Parameters
    ----------
    judge_labels_by_family:
        {"llama": ["CORRECT", "INCORRECT", ...], "gpt": [...], ...}
        各ファミリーのラベルリスト。すべて同じ長さ (n,)。
        値は "CORRECT" / "INCORRECT" 文字列または 1/0 整数。
    strategy:
        "majority_of_families" — 各ファミリー内で多数決→ファミリー間で多数決。

    Returns
    -------
    balanced_labels: np.ndarray, shape (n,)
        0/1 整数。CORRECT=1, INCORRECT=0。
    """
    families = list(judge_labels_by_family.keys())
    n_families = len(families)
    if n_families < 2:
        raise ValueError(
            "family_balanced_majority requires >=2 families. "
            f"Got: {families}"
        )

    # 各ファミリーの per-item 多数決スコア (0 or 1)
    family_votes = []
    for fam, labels in judge_labels_by_family.items():
        arr = np.array(
            [1 if str(l).upper() in ("CORRECT", "1", "TRUE") else 0 for l in labels],
            dtype=int,
        )
        family_votes.append(arr)

    family_votes_arr = np.stack(family_votes, axis=1)  # (n, n_families)

    # majority_of_families: ファミリー列の合計 > n_families/2
    balanced = (family_votes_arr.sum(axis=1) > n_families / 2).astype(int)
    return balanced


def _bootstrap_auc_ci(
    scores: np.ndarray,
    labels: np.ndarray,
    n_boot: int = N_BOOT,
    alpha: float = 0.05,
    seed: int = SEED,
) -> tuple[float, float, float]:
    """Bootstrap AUC + 95% CI。

    Returns
    -------
    (auc, ci_lower, ci_upper)
    """
    rng = np.random.default_rng(seed)
    n = len(scores)
    boot_aucs = []
    for _ in range(n_boot):
        idx = rng.integers(0, n, size=n)
        s_b, l_b = scores[idx], labels[idx]
        if len(np.unique(l_b)) < 2:
            continue
        try:
            boot_aucs.append(roc_auc_score(l_b, s_b))
        except Exception:
            pass

    if not boot_aucs:
        return float("nan"), float("nan"), float("nan")

    auc = roc_auc_score(labels, scores)
    ci_lo = float(np.percentile(boot_aucs, 100 * alpha / 2))
    ci_hi = float(np.percentile(boot_aucs, 100 * (1 - alpha / 2)))
    return auc, ci_lo, ci_hi


def auc_bias_corrected(
    scores: np.ndarray,
    labels: np.ndarray,
    lengths: np.ndarray | None = None,
    family_labels: dict[str, list[str]] | None = None,
    alpha: float = 0.05,
    poly_order: int = 1,
    seed: int = SEED,
) -> dict:
    """length-residualized + family-balanced 両方適用後の AUC + bootstrap CI。

    Parameters
    ----------
    scores:
        UQ スコア (baseline_confidence, fragility_score, lsc_score, stc_score 等)。
    labels:
        正解ラベル 0/1。
    lengths:
        回答文字数またはトークン数。None なら length 補正をスキップ。
    family_labels:
        {"llama": [...], "gpt": [...]} 形式のジャッジラベル辞書。
        None または ファミリー数 < 2 なら family balanced をスキップ。
    alpha:
        CI 有意水準 (デフォルト 0.05 → 95% CI)。
    poly_order:
        length_residualize の多項式次数。
    seed:
        乱数シード。

    Returns
    -------
    dict with keys:
        raw_auc, raw_ci_lo, raw_ci_hi,
        len_residualized_auc, len_ci_lo, len_ci_hi,
        family_balanced_auc, fb_ci_lo, fb_ci_hi,  (if family_labels provided)
        both_corrected_auc, bc_ci_lo, bc_ci_hi,   (if both corrections applied)
        spearman_rho_before, spearman_rho_after,
        length_bias_detected, self_pref_detected,
    """
    scores = np.asarray(scores, dtype=float)
    labels = np.asarray(labels, dtype=int)

    if len(np.unique(labels)) < 2:
        raise ValueError("labels must contain both classes (0 and 1).")

    result: dict = {}

    # --- raw AUC ---
    raw_auc, raw_lo, raw_hi = _bootstrap_auc_ci(scores, labels, seed=seed)
    result["raw_auc"] = raw_auc
    result["raw_ci_lo"] = raw_lo
    result["raw_ci_hi"] = raw_hi

    # --- length residualization ---
    if lengths is not None:
        lengths = np.asarray(lengths, dtype=float)
        rho_before, _ = stats.spearmanr(scores, lengths)
        result["spearman_rho_before"] = float(rho_before)
        result["length_bias_detected"] = abs(rho_before) > 0.1

        residuals = length_residualize(scores, lengths, poly_order=poly_order)
        rho_after, _ = stats.spearmanr(residuals, lengths)
        result["spearman_rho_after"] = float(rho_after)

        # poly_order=2 sanity
        if poly_order == 1:
            res2 = length_residualize(scores, lengths, poly_order=2)
            rho2, _ = stats.spearmanr(res2, lengths)
            result["spearman_rho_after_poly2"] = float(rho2)

        len_auc, len_lo, len_hi = _bootstrap_auc_ci(residuals, labels, seed=seed)
        result["len_residualized_auc"] = len_auc
        result["len_ci_lo"] = len_lo
        result["len_ci_hi"] = len_hi
    else:
        residuals = scores
        result["length_bias_detected"] = False
        result["spearman_rho_before"] = None
        result["spearman_rho_after"] = None

    # --- family-balanced majority ---
    fb_labels = None
    if family_labels is not None and len(family_labels) >= 2:
        # ファミリー間 CORRECT rate 差を計算
        rates = {}
        for fam, lbls in family_labels.items():
            arr = np.array(
                [1 if str(l).upper() in ("CORRECT", "1", "TRUE") else 0 for l in lbls]
            )
            rates[fam] = arr.mean()
        result["family_correct_rates"] = rates

        all_rates = list(rates.values())
        result["self_pref_delta"] = float(max(all_rates) - min(all_rates))
        result["self_pref_detected"] = result["self_pref_delta"] > 0.05

        fb_labels = family_balanced_majority(family_labels)
        fb_auc, fb_lo, fb_hi = _bootstrap_auc_ci(scores, fb_labels, seed=seed)
        result["family_balanced_auc"] = fb_auc
        result["fb_ci_lo"] = fb_lo
        result["fb_ci_hi"] = fb_hi
    else:
        result["self_pref_detected"] = False

    # --- both corrections ---
    if lengths is not None and fb_labels is not None:
        bc_auc, bc_lo, bc_hi = _bootstrap_auc_ci(residuals, fb_labels, seed=seed)
        result["both_corrected_auc"] = bc_auc
        result["bc_ci_lo"] = bc_lo
        result["bc_ci_hi"] = bc_hi

    return result
