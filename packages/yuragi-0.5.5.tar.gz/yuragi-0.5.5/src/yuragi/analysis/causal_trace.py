"""Causal tracing for Pythia-410m (GPTNeoX architecture).

Implements a simplified version of Meng et al. 2022 (ROME) causal tracing:
for each layer, restore the hidden state at the last token position from the
clean (original) run while running under the corrupted input.  The resulting
increase in target-token probability measures that layer's causal contribution.

Critical: ln_f must be applied before unembedding (same constraint as logit_lens).
"""
from __future__ import annotations

import numpy as np
import torch
import torch.nn.functional as F
from transformers import PreTrainedModel, PreTrainedTokenizerBase


def _get_ln_f(model: PreTrainedModel) -> torch.nn.Module | None:
    if hasattr(model, "gpt_neox") and hasattr(model.gpt_neox, "final_layer_norm"):
        return model.gpt_neox.final_layer_norm
    if hasattr(model, "transformer") and hasattr(model.transformer, "ln_f"):
        return model.transformer.ln_f
    return None


def _collect_hidden_states(
    model: PreTrainedModel,
    input_ids: torch.Tensor,
) -> dict[int, torch.Tensor]:
    """Run a forward pass, return last-token hidden state per transformer layer."""
    hiddens: dict[int, torch.Tensor] = {}

    def _make_hook(idx: int):
        def hook(module, input, output):
            t = output[0] if isinstance(output, tuple) else output
            hiddens[idx] = t[0, -1, :].detach().clone()
        return hook

    handles = []
    layers = model.gpt_neox.layers
    for i, layer in enumerate(layers):
        handles.append(layer.register_forward_hook(_make_hook(i)))
    with torch.no_grad():
        model(input_ids=input_ids, use_cache=False)
    for h in handles:
        h.remove()
    return hiddens


def _prob_of_token(
    model: PreTrainedModel,
    ln_f: torch.nn.Module | None,
    unembed: torch.Tensor,
    input_ids: torch.Tensor,
    target_token_id: int,
    patch_layer: int | None = None,
    patch_hidden: torch.Tensor | None = None,
) -> float:
    """Forward pass with optional single-layer patching; return target token prob."""

    handles = []
    if patch_layer is not None and patch_hidden is not None:
        def patch_hook(module, input, output):
            if isinstance(output, tuple):
                patched = output[0].clone()
                patched[0, -1, :] = patch_hidden
                return (patched,) + output[1:]
            patched = output.clone()
            patched[0, -1, :] = patch_hidden
            return patched

        handles.append(
            model.gpt_neox.layers[patch_layer].register_forward_hook(patch_hook)
        )

    try:
        with torch.no_grad():
            out = model(input_ids=input_ids, use_cache=False)
    finally:
        for h in handles:
            h.remove()

    logits = out.logits[0, -1, :]  # [vocab]
    probs = F.softmax(logits, dim=-1)
    return float(probs[target_token_id].item())


def causal_trace(
    model: PreTrainedModel,
    tokenizer: PreTrainedTokenizerBase,
    prompt_original: str,
    prompt_corrupted: str,
    target_token: str,
    layers: list[int] | None = None,
) -> np.ndarray:
    """Compute causal tracing scores for each layer.

    For each layer l, measures: P(target | corrupted + patch@l) - P(target | corrupted).
    Positive delta = restoring layer l recovers the target token probability.

    Parameters
    ----------
    model, tokenizer:
        Pythia-410m loaded in eval mode.
    prompt_original:
        The clean prompt (e.g. "The language of France is").
    prompt_corrupted:
        The corrupted prompt (e.g. "The Language of France is").
    target_token:
        String token to track (e.g. " French").
    layers:
        Layer indices to probe.  None = all transformer layers.

    Returns
    -------
    np.ndarray of shape [n_layers]
        Causal restoration score per layer (delta probability).
    """
    model.eval()
    unembed = model.get_output_embeddings().weight.detach()
    ln_f = _get_ln_f(model)

    # Encode target token
    target_ids = tokenizer.encode(target_token, add_special_tokens=False)
    if not target_ids:
        raise ValueError(f"target_token {target_token!r} encodes to empty sequence")
    target_token_id = target_ids[0]

    ids_orig = torch.tensor(
        [tokenizer.encode(prompt_original, add_special_tokens=False)]
    )
    ids_corr = torch.tensor(
        [tokenizer.encode(prompt_corrupted, add_special_tokens=False)]
    )

    n_layers = len(model.gpt_neox.layers)
    if layers is None:
        layers = list(range(n_layers))

    # Clean run — collect hidden states
    clean_hiddens = _collect_hidden_states(model, ids_orig)

    # Corrupted baseline probability
    p_corrupt = _prob_of_token(model, ln_f, unembed, ids_corr, target_token_id)

    scores = np.zeros(len(layers))
    for i, layer_idx in enumerate(layers):
        if layer_idx not in clean_hiddens:
            continue
        p_restored = _prob_of_token(
            model, ln_f, unembed, ids_corr, target_token_id,
            patch_layer=layer_idx,
            patch_hidden=clean_hiddens[layer_idx],
        )
        scores[i] = p_restored - p_corrupt

    return scores


def identify_causal_layer(trace_output: np.ndarray) -> int:
    """Return the layer index with maximum causal restoration score."""
    return int(np.argmax(trace_output))
