"""Unified LLM adapter with automatic capability detection.

Supports three confidence measurement modes:
1. logprobs (GPT-4o, local models via ollama) — most accurate
2. multi-sample (all models) — measure variance across N responses
3. verbalized (all models) — ask the model to self-report confidence
"""

from __future__ import annotations

import logging
import math
import re
import statistics
from dataclasses import dataclass
from typing import TYPE_CHECKING, ClassVar

if TYPE_CHECKING:
    from yuragi.cache import ResponseCache

from yuragi.config import DEFAULT_CONFIG, YuragiConfig
from yuragi.utils import text_similarity as _text_similarity_fn

# WSL / Cloudflare 1010 workaround (2026-04-17 regression fix).
# The default `openai-python/X.Y.Z` User-Agent is fingerprinted by Cloudflare's
# bot filter from certain IP ranges (WSL and some cloud egress), producing
# HTTP 403 "error code 1010" on Cerebras / Groq / Hyperbolic. Sending a
# browser-style UA bypasses the filter without altering request semantics.
_BROWSER_UA = (
    "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 "
    "(KHTML, like Gecko) Chrome/122.0.0.0 Safari/537.36"
)
_UA_HEADER = {"User-Agent": _BROWSER_UA}

logger = logging.getLogger(__name__)

# ---------------------------------------------------------------------------
# Retryable-error classification (shared by sync & async paths)
# ---------------------------------------------------------------------------
# String fragments that indicate a transient server-side error worth retrying.
_RETRYABLE_STRINGS: tuple[str, ...] = (
    "rate_limit",
    "rate limit",
    "timeout",
    "429",
    "500",
    "502",
    "503",
    "internal server error",
    "overloaded",
    "api_error",
    "bad gateway",
    "service unavailable",
)


def _build_retryable_exceptions(ll) -> tuple:
    """Build a tuple of litellm exception classes considered retryable.

    Gracefully skips classes that don't exist in the installed litellm
    version so this works across litellm releases.
    """
    names = (
        "RateLimitError",
        "Timeout",
        "APIConnectionError",
        "InternalServerError",
        "ServiceUnavailableError",
    )
    return tuple(getattr(ll, n) for n in names if hasattr(ll, n))


def _is_retryable(e: Exception, retryable_excs: tuple) -> bool:
    """Return True if *e* looks like a transient error worth retrying."""
    if isinstance(e, retryable_excs):
        return True
    error_str = str(e).lower()
    return any(k in error_str for k in _RETRYABLE_STRINGS)


# API key patterns to redact from error messages
_KEY_PATTERNS = re.compile(
    r"(sk-[a-zA-Z0-9_-]{6})[a-zA-Z0-9_-]+"
    r"|(gsk_[a-zA-Z0-9]{6})[a-zA-Z0-9]+"
    r"|(AIzaSy[a-zA-Z0-9_-]{6})[a-zA-Z0-9_-]+"
    r"|(csk-[a-zA-Z0-9]{6})[a-zA-Z0-9]+"
    r"|(xai-[a-zA-Z0-9]{6})[a-zA-Z0-9]+"
)


def _sanitize_error(e: Exception) -> str:
    """Remove potential API keys from error messages."""
    msg = str(e)
    return _KEY_PATTERNS.sub(lambda m: next(g for g in m.groups() if g) + "...REDACTED", msg)

# ---------------------------------------------------------------------------
# Lazy litellm loader (v0.3.0 cold-start optimisation)
# ---------------------------------------------------------------------------
# ``import litellm`` is expensive (~2 seconds on cold start) because it
# eagerly pulls every provider (vertex_ai, anthropic, google_genai, ...).
# We postpone the import until the first LLM call so that
# ``from yuragi import Scanner`` / ``yuragi --help`` stay fast.
#
# Backwards-compat notes:
#   * ``_get_litellm()`` returns the module (importing on first call, caching
#     thereafter). It first consults ``globals().get("litellm")`` so tests
#     that ``monkeypatch.setattr(adapter_mod, "litellm", fake)`` keep working.
#   * ``_has_litellm()`` is the lazy equivalent of the old ``HAS_LITELLM``
#     module flag.
#   * A module-level ``__getattr__`` (PEP 562) exposes the names ``litellm``
#     and ``HAS_LITELLM`` lazily for any caller (including ``unittest.mock``)
#     that still looks them up as module attributes.

_litellm_cached: object | None = None
_litellm_probe_done: bool = False
_litellm_probe_result: bool = False


def _get_litellm():
    """Return the litellm module, importing it on first call.

    Raises ``MissingDependencyError`` if litellm is not installed. A
    monkey-patched ``litellm`` attribute on this module takes precedence
    so tests that inject a fake module keep working.
    """
    # Monkey-patched value always wins (test fake).
    mp = globals().get("litellm")
    if mp is not None and mp is not _MARKER:
        return mp

    global _litellm_cached, _litellm_probe_done, _litellm_probe_result
    if _litellm_cached is not None:
        return _litellm_cached
    try:
        import litellm as _lt  # heavy, one-shot

        _lt.suppress_debug_info = True
        _lt.set_verbose = False
        _lt.drop_params = True
        _litellm_cached = _lt
        _litellm_probe_done = True
        _litellm_probe_result = True
        return _lt
    except ImportError as err:
        _litellm_probe_done = True
        _litellm_probe_result = False
        from yuragi.exceptions import MissingDependencyError

        raise MissingDependencyError(
            "litellm is required. Install with: pip install yuragi"
        ) from err


def _has_litellm() -> bool:
    """True if litellm can be imported. Cached after first probe."""
    mp = globals().get("litellm")
    if mp is not None and mp is not _MARKER:
        return True
    global _litellm_probe_done, _litellm_probe_result
    if _litellm_probe_done:
        return _litellm_probe_result
    try:
        _get_litellm()
    except Exception:
        return False
    return _litellm_probe_result


# Sentinel so ``globals().get("litellm")`` can distinguish "not yet set" from
# "explicitly set to None by a test".
_MARKER = object()


def __getattr__(name: str):  # PEP 562
    """Expose ``litellm`` and ``HAS_LITELLM`` as lazy module attributes.

    Only triggered when the attribute is *not* already in ``globals()``.
    Tests that ``monkeypatch.setattr`` these names add a real entry to the
    module dict, which shadows this function per PEP 562 and the old test
    code keeps working unchanged.
    """
    if name == "litellm":
        return _get_litellm()
    if name == "HAS_LITELLM":
        return _has_litellm()
    raise AttributeError(f"module 'yuragi.providers.adapter' has no attribute {name!r}")


@dataclass
class ModelCapabilities:
    """What a model can do for confidence measurement."""

    supports_logprobs: bool = False
    supports_temperature: bool = True
    max_logprobs: int = 5
    provider: str = "unknown"


@dataclass
class CompletionResult:
    """A single LLM completion with confidence metadata."""

    text: str
    confidence: float  # 0.0 to 1.0
    confidence_method: str  # "logprob", "sampling", "verbalized"
    logprob_entropy: float | None = None
    raw_logprobs: list | None = None
    token_count: int = 0

    def to_json(self) -> dict:
        """Serialize to a JSON-safe dict.

        Converts ``raw_logprobs`` tuples to lists so that json.dumps
        round-trips cleanly.  Use ``from_json`` to restore.
        """
        raw = self.raw_logprobs
        if raw is not None:
            raw = [[list(pair) for pair in token_probs] for token_probs in raw]
        return {
            "text": self.text,
            "confidence": self.confidence,
            "confidence_method": self.confidence_method,
            "logprob_entropy": self.logprob_entropy,
            "raw_logprobs": raw,
            "token_count": self.token_count,
        }

    @classmethod
    def from_json(cls, data: dict) -> CompletionResult:
        """Deserialize from a dict produced by ``to_json``.

        Restores ``raw_logprobs`` inner pairs as tuples.
        """
        raw = data.get("raw_logprobs")
        if raw is not None:
            raw = [[tuple(pair) for pair in token_probs] for token_probs in raw]
        return cls(
            text=data["text"],
            confidence=data["confidence"],
            confidence_method=data["confidence_method"],
            logprob_entropy=data.get("logprob_entropy"),
            raw_logprobs=raw,
            token_count=data.get("token_count", 0),
        )


# Models known to support logprobs
_LOGPROB_MODELS = {
    "gpt-4o",
    "gpt-4o-mini",
    "gpt-4-turbo",
    "gpt-4",
    "gpt-3.5-turbo",
    "o1",
    "o1-mini",
    "o3-mini",
}

# Patterns indicating a reasoning/thinking model
_REASONING_PATTERNS = ("reasoning", "-think", "deepseek-r1", "-r1:")


def detect_capabilities(model: str) -> ModelCapabilities:
    """Detect what confidence measurement methods a model supports."""
    model_lower = model.lower()

    # OpenAI models
    for m in _LOGPROB_MODELS:
        if m in model_lower:
            return ModelCapabilities(
                supports_logprobs=True, max_logprobs=20, provider="openai"
            )

    # Groq
    # Groq: API docs list logprobs param but ALL models return
    # "logprobs is not supported with this model" (verified 2026-04-12).
    if model_lower.startswith("groq/"):
        return ModelCapabilities(
            supports_logprobs=False, max_logprobs=10, provider="groq"
        )

    # Together AI
    if model_lower.startswith("together_ai/"):
        return ModelCapabilities(
            supports_logprobs=True, max_logprobs=20, provider="together_ai"
        )

    # Fireworks AI
    if model_lower.startswith("fireworks_ai/"):
        return ModelCapabilities(
            supports_logprobs=True, max_logprobs=20, provider="fireworks_ai"
        )

    # Cerebras — logprobs confirmed (top_logprobs max 20), free tier 1M tok/day
    if model_lower.startswith("cerebras/"):
        return ModelCapabilities(
            supports_logprobs=True, max_logprobs=20, provider="cerebras"
        )

    # Sambanova — logprobs confirmed via OpenAI-compatible API; free tier
    if model_lower.startswith("sambanova/"):
        return ModelCapabilities(
            supports_logprobs=True, max_logprobs=20, provider="sambanova"
        )

    # NVIDIA NIM — logprobs confirmed (verified 2026-04-14); top_logprobs max 5
    if model_lower.startswith("nvidia_nim/"):
        return ModelCapabilities(
            supports_logprobs=True, max_logprobs=5, provider="nvidia_nim"
        )

    # OpenRouter — free models support logprobs (Gemma 3 27B, Nemotron 49B)
    if model_lower.startswith("openrouter/"):
        return ModelCapabilities(
            supports_logprobs=True, max_logprobs=20, provider="openrouter"
        )

    # Ollama — supports logprobs natively
    if any(model_lower.startswith(p) for p in ("ollama/", "ollama_chat/")):
        return ModelCapabilities(
            supports_logprobs=True, max_logprobs=20, provider="ollama"
        )

    # HuggingFace / vLLM local inference
    if any(model_lower.startswith(p) for p in ("huggingface/", "vllm/")):
        return ModelCapabilities(
            supports_logprobs=True, max_logprobs=20, provider="local"
        )

    # Anthropic — logprobs added Feb 2026, but litellm support may vary.
    # Default to sampling for reliability; set supports_logprobs=True to try.
    if "claude" in model_lower or model_lower.startswith("anthropic/"):
        return ModelCapabilities(
            supports_logprobs=False, provider="anthropic"
        )

    # Google
    if "gemini" in model_lower or model_lower.startswith("google/"):
        return ModelCapabilities(
            supports_logprobs=False, provider="google"
        )

    # Default: assume no logprobs
    return ModelCapabilities(supports_logprobs=False, provider="unknown")


class LLMAdapter:
    """Unified interface for querying LLMs with confidence measurement.

    Can be used as a context manager for automatic resource cleanup::

        with LLMAdapter(model="gpt-4o-mini") as adapter:
            result = adapter.complete("Hello")
    """

    def __init__(
        self,
        model: str,
        api_key: str | None = None,
        api_base: str | None = None,
        num_samples: int = 5,
        temperature: float = 0.7,
        max_tokens: int = 300,
        timeout: float = 300.0,
        use_cache: bool = True,
        parallel: int = 1,
        cache: ResponseCache | None = None,
        config: YuragiConfig | None = None,
    ):
        self.model = model
        self.api_key = api_key
        self.api_base = api_base
        self.num_samples = num_samples
        self.temperature = temperature
        self.max_tokens = max_tokens
        self.timeout = timeout
        self.use_cache = use_cache
        self.parallel = parallel
        self.capabilities = detect_capabilities(model)
        self.config = config or DEFAULT_CONFIG

        if any(p in self.model.lower() for p in _REASONING_PATTERNS):
            logger.warning(
                "Model %s appears to be a reasoning model. "
                "Reasoning models may not return logprobs during thinking mode. "
                "Consider using non-reasoning variant or /nothink mode.",
                self.model,
            )

        # Validate litellm availability (lazy import; sets drop_params=True
        # inside _get_litellm on first call).
        _get_litellm()

        # Cache setup
        if use_cache and cache is None:
            from yuragi.cache import ResponseCache

            self._cache: ResponseCache | None = ResponseCache()
        else:
            self._cache = cache if use_cache else None

    def __repr__(self) -> str:
        return (
            f"LLMAdapter(model={self.model!r}, "
            f"api_key={'***' if self.api_key else None}, "
            f"provider={self.capabilities.provider!r})"
        )

    def __enter__(self) -> LLMAdapter:
        return self

    def __exit__(self, *_: object) -> None:
        self.close()

    def close(self) -> None:
        """Close the response cache (if owned by this adapter)."""
        if self._cache is not None:
            self._cache.close()
            self._cache = None

    @staticmethod
    def _build_messages(prompt: str, system: str | None) -> list[dict]:
        """Build chat messages list with optional system prompt."""
        msgs: list[dict] = []
        if system:
            msgs.append({"role": "system", "content": system})
        msgs.append({"role": "user", "content": prompt})
        return msgs

    async def acomplete(
        self, prompt: str, system: str | None = None, retries: int = 2
    ) -> CompletionResult:
        """Async version of complete() with the same retry and cache logic.

        Uses litellm.acompletion internally.  Retry/backoff mirrors complete().
        Cache lookup and write are performed just like the sync path.
        """
        import asyncio as _asyncio

        # Cache lookup
        if self._cache is not None:
            cached = self._cache.get(self.model, prompt, self.temperature, self.num_samples, system, max_tokens=self.max_tokens)
            if cached is not None:
                return cached

        messages = self._build_messages(prompt, system)

        _ll = _get_litellm()
        retryable_excs = _build_retryable_exceptions(_ll)
        last_error: Exception | None = None
        for attempt in range(retries + 1):
            try:
                logger.debug(
                    "async API call start model=%s method=%s attempt=%d",
                    self.model,
                    "logprobs" if self.capabilities.supports_logprobs else "sampling",
                    attempt,
                )
                if self.capabilities.supports_logprobs:
                    response = await _ll.acompletion(
                        model=self.model,
                        messages=messages,
                        temperature=0.0,
                        max_tokens=self.max_tokens,
                        timeout=self.timeout,
                        logprobs=True,
                        top_logprobs=self.capabilities.max_logprobs,
                        api_key=self.api_key,
                        extra_headers=_UA_HEADER,
                    )
                    text = response.choices[0].message.content or ""
                    logprobs_data = self._extract_logprobs(response)
                    if logprobs_data:
                        entropy_nats = self._calculate_entropy(logprobs_data)
                        k = min((len(t) for t in logprobs_data if t), default=self.config.top_logprobs_k)
                        k = max(k, 2)  # Enforce k>=2: ln(1)=0 causes zero-division
                        max_entropy = math.log(k)
                        normalized_entropy = entropy_nats / max_entropy if max_entropy > 0 else 0.0
                        confidence = max(0.0, min(1.0, 1.0 - normalized_entropy))
                    else:
                        logger.warning(
                            "Requested logprobs but provider returned none "
                            "(model=%s, provider=%s). Falling back to sampling mode. "
                            "This may indicate the provider silently dropped the logprobs param.",
                            self.model,
                            self.capabilities.provider,
                        )
                        entropy_nats = None
                        confidence = 0.5
                    result = CompletionResult(
                        text=text,
                        confidence=confidence,
                        confidence_method="logprob",
                        logprob_entropy=entropy_nats if logprobs_data else None,
                        raw_logprobs=logprobs_data if logprobs_data else None,
                        token_count=response.usage.total_tokens if response.usage else 0,
                    )
                else:
                    # sampling mode: gather num_samples async calls
                    sample_tasks = [
                        _ll.acompletion(
                            model=self.model,
                            messages=messages,
                            temperature=self.temperature,
                            max_tokens=self.max_tokens,
                            timeout=self.timeout,
                            api_key=self.api_key,
                            extra_headers=_UA_HEADER,
                        )
                        for _ in range(self.num_samples)
                    ]
                    responses = await _asyncio.gather(*sample_tasks, return_exceptions=True)
                    texts: list[str] = []
                    total_tokens = 0
                    for r in responses:
                        if isinstance(r, Exception):
                            logger.debug("Async sample failed: %s", r)
                            continue
                        texts.append(r.choices[0].message.content or "")
                        if r.usage:
                            total_tokens += r.usage.total_tokens
                    if not texts:
                        from yuragi.exceptions import ScanError
                        raise ScanError(
                            f"All {self.num_samples} async sampling attempts failed for model={self.model}"
                        )
                    confidence = self._measure_agreement(texts)
                    result = CompletionResult(
                        text=texts[0],
                        confidence=confidence,
                        confidence_method="sampling",
                        token_count=total_tokens,
                    )

                logger.debug(
                    "async API call done model=%s confidence=%.3f method=%s",
                    self.model,
                    result.confidence,
                    result.confidence_method,
                )
                if self._cache is not None:
                    self._cache.set(
                        self.model, prompt, self.temperature, self.num_samples, result, system, max_tokens=self.max_tokens
                    )
                return result

            except (KeyboardInterrupt, SystemExit):
                raise
            except Exception as e:
                last_error = e
                if _is_retryable(e, retryable_excs):
                    wait = min(2 ** attempt * 2, 30)
                    logger.warning(
                        "Async retryable error (attempt %d/%d): %s",
                        attempt + 1,
                        retries + 1,
                        _sanitize_error(e),
                    )
                    await _asyncio.sleep(wait)
                    continue
                raise
        if last_error is not None:
            raise last_error
        raise RuntimeError("Async retry loop exited without result or error")

    def complete(
        self, prompt: str, system: str | None = None, retries: int = 2
    ) -> CompletionResult:
        """Get a completion with confidence score.

        Automatically selects the best measurement method available.
        Retries on transient errors (rate limits, timeouts).
        Cache lookup is performed before making any API call.
        """
        import time as _time

        # Cache lookup — the sync path previously forgot to pass ``system``
        # which made two calls with different system prompts collapse onto
        # the same cache entry. See Round 10 debugger C-1.
        if self._cache is not None:
            cached = self._cache.get(
                self.model, prompt, self.temperature, self.num_samples, system, max_tokens=self.max_tokens
            )
            if cached is not None:
                return cached

        _ll = _get_litellm()
        retryable_excs = _build_retryable_exceptions(_ll)
        last_error = None
        for attempt in range(retries + 1):
            try:
                logger.debug("API call start model=%s method=%s attempt=%d", self.model, "logprobs" if self.capabilities.supports_logprobs else "sampling", attempt)
                if self.capabilities.supports_logprobs:
                    result = self._complete_with_logprobs(prompt, system)
                else:
                    result = self._complete_with_sampling(prompt, system)
                logger.debug("API call done model=%s confidence=%.3f method=%s", self.model, result.confidence, result.confidence_method)
                if self._cache is not None:
                    self._cache.set(
                        self.model, prompt, self.temperature, self.num_samples, result, system, max_tokens=self.max_tokens
                    )
                return result
            except (KeyboardInterrupt, SystemExit):
                raise
            except Exception as e:
                last_error = e
                if _is_retryable(e, retryable_excs):
                    wait = min(2 ** attempt * 2, 30)
                    logger.warning("Retryable error (attempt %d/%d): %s", attempt + 1, retries + 1, _sanitize_error(e))
                    _time.sleep(wait)
                    continue
                raise
        if last_error is not None:
            raise last_error
        raise RuntimeError("Retry loop exited without result or error")

    def complete_verbalized(
        self, prompt: str, system: str | None = None, retries: int = 2
    ) -> CompletionResult:
        """Get completion with self-reported confidence (0-100).

        Retries on transient errors (rate limits, timeouts, server errors).
        """
        import time as _time

        confidence_prompt = (
            f"{prompt}\n\n"
            "After your answer, on a new line write exactly "
            '"CONFIDENCE: X" where X is your confidence level from 0 to 100.'
        )

        messages = self._build_messages(confidence_prompt, system)

        _ll = _get_litellm()
        retryable_excs = _build_retryable_exceptions(_ll)
        last_error: Exception | None = None
        for attempt in range(retries + 1):
            try:
                response = _ll.completion(
                    model=self.model,
                    messages=messages,
                    temperature=0.0,
                    max_tokens=self.max_tokens + 50,
                    timeout=self.timeout,
                    api_key=self.api_key,
                    extra_headers=_UA_HEADER,
                )

                text = response.choices[0].message.content or ""
                confidence, clean_text = self._parse_verbalized_confidence(text)

                return CompletionResult(
                    text=clean_text,
                    confidence=confidence,
                    confidence_method="verbalized",
                    token_count=response.usage.total_tokens if response.usage else 0,
                )
            except (KeyboardInterrupt, SystemExit):
                raise
            except Exception as e:
                last_error = e
                if _is_retryable(e, retryable_excs):
                    wait = min(2 ** attempt * 2, 30)
                    logger.warning("Verbalized retryable error (attempt %d/%d): %s", attempt + 1, retries + 1, _sanitize_error(e))
                    _time.sleep(wait)
                    continue
                raise
        if last_error is not None:
            raise last_error
        raise RuntimeError("Verbalized retry loop exited without result or error")

    def _complete_with_logprobs_direct(
        self,
        messages: list[dict[str, str]],
        base_url: str,
        api_key_env: str,
        strip_prefix: str = "",
    ) -> CompletionResult:
        """Generic direct logprobs via any OpenAI-compatible API.

        Used for providers where litellm blocks the logprobs param
        (Ollama, Cerebras, etc.) but the underlying API supports it.
        """
        import os

        import openai as _oai

        api_key = self.api_key or os.environ.get(api_key_env, "")
        bare_model = self.model
        if strip_prefix:
            bare_model = bare_model.removeprefix(strip_prefix)
        k = min(self.config.top_logprobs_k, self.capabilities.max_logprobs)

        # Per-provider pre-call sleep to respect free-tier rate limits.
        # NVIDIA NIM free tier: burst-limited in practice → sleep 6.0 s per call for safety.
        _PRE_CALL_SLEEP = {"nvidia_nim": 6.0}  # noqa: N806
        _sleep = _PRE_CALL_SLEEP.get(self.capabilities.provider, 0.0)
        if _sleep > 0:
            import time as _time_mod
            _time_mod.sleep(_sleep)

        client = _oai.OpenAI(
            base_url=base_url,
            api_key=api_key,
            default_headers=_UA_HEADER,
        )
        response = client.chat.completions.create(
            model=bare_model,
            messages=messages,
            temperature=0.0,
            max_tokens=self.max_tokens,
            logprobs=True,
            top_logprobs=k,
            timeout=self.timeout,
        )

        choice = response.choices[0]
        text = choice.message.content or ""

        logprobs_data: list[list[tuple[str, float]]] = []
        if choice.logprobs and choice.logprobs.content:
            for token_info in choice.logprobs.content:
                top = [(e.token, e.logprob) for e in token_info.top_logprobs]
                logprobs_data.append(top)

        # Thinking-model contamination check (L12)
        # Check even when text is non-empty: logprobs may contain thinking tokens
        # while the model returns the final answer as text.
        think_markers = ("<think>", "Thinking", "<|thinking|>")
        if logprobs_data:
            first_tokens = " ".join(t for t, _ in logprobs_data[0][:3])
            if any(m.lower() in first_tokens.lower() for m in think_markers):
                logger.warning(
                    "Thinking-model logprobs contamination detected (model=%s). "
                    "Falling back to sampling.",
                    self.model,
                )
                prompt_text = messages[-1]["content"] if messages else ""
                system_text = messages[0]["content"] if len(messages) > 1 and messages[0].get("role") == "system" else None
                return self._complete_with_sampling(prompt_text, system_text)

        if logprobs_data:
            entropy_nats = self._calculate_entropy(logprobs_data)
            actual_k = min((len(t) for t in logprobs_data if t), default=k)
            actual_k = max(actual_k, 2)
            max_entropy = math.log(actual_k)
            normalized_entropy = entropy_nats / max_entropy if max_entropy > 0 else 0.0
            confidence = max(0.0, min(1.0, 1.0 - normalized_entropy))
        else:
            logger.warning(
                "Direct API returned no logprobs (model=%s). Falling back to sampling.",
                self.model,
            )
            prompt_text = messages[-1]["content"] if messages else ""
            system_text = messages[0]["content"] if len(messages) > 1 and messages[0].get("role") == "system" else None
            return self._complete_with_sampling(prompt_text, system_text)

        return CompletionResult(
            text=text,
            confidence=confidence,
            confidence_method="logprob",
            logprob_entropy=entropy_nats,
            raw_logprobs=logprobs_data,
            token_count=response.usage.total_tokens if response.usage else 0,
        )

    def _complete_with_logprobs_ollama(
        self, messages: list[dict[str, str]]
    ) -> CompletionResult:
        """Ollama-specific logprobs via OpenAI-compatible /v1 endpoint.

        litellm 1.83+ blocks ``logprobs``/``top_logprobs`` for Ollama, but
        Ollama v0.12.11+ supports them natively through its OpenAI-compatible
        API.  We call it directly using the ``openai`` SDK (already installed
        as a litellm transitive dependency).
        """
        import openai as _oai

        api_base = self.api_base or "http://localhost:11434"
        bare_model = self.model.removeprefix("ollama/").removeprefix("ollama_chat/")
        k = min(self.config.top_logprobs_k, self.capabilities.max_logprobs)

        client = _oai.OpenAI(base_url=f"{api_base}/v1", api_key="ollama")
        response = client.chat.completions.create(
            model=bare_model,
            messages=messages,
            temperature=0.0,
            max_tokens=self.max_tokens,
            logprobs=True,
            top_logprobs=k,
            timeout=self.timeout,
        )

        choice = response.choices[0]
        text = choice.message.content or ""

        # Extract logprobs in yuragi's internal format
        logprobs_data: list[list[tuple[str, float]]] = []
        if choice.logprobs and choice.logprobs.content:
            for token_info in choice.logprobs.content:
                top = [(e.token, e.logprob) for e in token_info.top_logprobs]
                logprobs_data.append(top)

        # Detect thinking-model contamination (L12): logprobs may contain
        # thinking tokens even when response text is non-empty.
        think_markers = ("<think>", "Thinking", "<|thinking|>")
        if logprobs_data:
            first_tokens = " ".join(t for t, _ in logprobs_data[0][:3])
            if any(m.lower() in first_tokens.lower() for m in think_markers):
                logger.warning(
                    "Thinking-model detected (model=%s): logprobs contain "
                    "thinking tokens but response text is empty. Confidence "
                    "would measure thinking-template entropy, not answer "
                    "entropy. Falling back to sampling mode. See L12 in "
                    "KNOWN_LIMITATIONS.md.",
                    self.model,
                )
                prompt_text = messages[-1]["content"] if messages else ""
                system_text = messages[0]["content"] if len(messages) > 1 and messages[0].get("role") == "system" else None
                return self._complete_with_sampling(prompt_text, system_text)

        if logprobs_data:
            entropy_nats = self._calculate_entropy(logprobs_data)
            actual_k = min((len(t) for t in logprobs_data if t), default=k)
            actual_k = max(actual_k, 2)
            max_entropy = math.log(actual_k)
            normalized_entropy = entropy_nats / max_entropy if max_entropy > 0 else 0.0
            confidence = max(0.0, min(1.0, 1.0 - normalized_entropy))
        else:
            logger.warning(
                "Ollama direct API returned no logprobs (model=%s). "
                "Falling back to sampling mode.",
                self.model,
            )
            # Extract prompt from messages for sampling fallback
            prompt_text = messages[-1]["content"] if messages else ""
            system_text = messages[0]["content"] if len(messages) > 1 and messages[0].get("role") == "system" else None
            return self._complete_with_sampling(prompt_text, system_text)

        return CompletionResult(
            text=text,
            confidence=confidence,
            confidence_method="logprob",
            logprob_entropy=entropy_nats,
            raw_logprobs=logprobs_data,
            token_count=response.usage.total_tokens if response.usage else 0,
        )

    def _complete_with_logprobs(
        self, prompt: str, system: str | None = None
    ) -> CompletionResult:
        """Measure confidence via token probability distribution entropy."""
        messages = self._build_messages(prompt, system)

        # Ollama/Cerebras: litellm blocks logprobs, call OpenAI-compatible API directly
        if self.capabilities.provider == "ollama":
            return self._complete_with_logprobs_ollama(messages)
        if self.capabilities.provider == "cerebras":
            return self._complete_with_logprobs_direct(
                messages, base_url="https://api.cerebras.ai/v1",
                api_key_env="CEREBRAS_API_KEY",
                strip_prefix="cerebras/",
            )
        if self.capabilities.provider == "nvidia_nim":
            # litellm blocks logprobs for nvidia_nim; call NIM directly
            return self._complete_with_logprobs_direct(
                messages, base_url="https://integrate.api.nvidia.com/v1",
                api_key_env="NVIDIA_NIM_API_KEY",
                strip_prefix="nvidia_nim/",
            )
        if self.capabilities.provider == "sambanova":
            return self._complete_with_logprobs_direct(
                messages, base_url="https://api.sambanova.ai/v1",
                api_key_env="SAMBANOVA_API_KEY",
                strip_prefix="sambanova/",
            )

        response = _get_litellm().completion(
            model=self.model,
            messages=messages,
            temperature=0.0,
            max_tokens=self.max_tokens,
            timeout=self.timeout,
            logprobs=True,
            top_logprobs=self.capabilities.max_logprobs,
            api_key=self.api_key,
            extra_headers=_UA_HEADER,
        )

        text = response.choices[0].message.content or ""
        logprobs_data = self._extract_logprobs(response)

        if logprobs_data:
            entropy_nats = self._calculate_entropy(logprobs_data)
            # Use config.top_logprobs_k as stable default; only shrink if the API
            # returned fewer candidates than requested (e.g. vocabulary is smaller).
            # This prevents k from varying across calls, keeping max_entropy
            # (and therefore normalized_entropy) comparable across requests.
            api_k = min((len(t) for t in logprobs_data if t), default=self.config.top_logprobs_k)
            k = self.config.top_logprobs_k if api_k >= self.config.top_logprobs_k else api_k
            k = max(k, 2)  # Enforce k>=2: ln(1)=0 causes zero-division
            max_entropy = math.log(k)
            normalized_entropy = entropy_nats / max_entropy if max_entropy > 0 else 0.0
            confidence = max(0.0, min(1.0, 1.0 - normalized_entropy))
        else:
            logger.warning(
                "Requested logprobs but provider returned none "
                "(model=%s, provider=%s). Falling back to sampling mode. "
                "This may indicate the provider silently dropped the logprobs param.",
                self.model,
                self.capabilities.provider,
            )
            # Fallback to sampling if logprobs extraction fails
            return self._complete_with_sampling(prompt, system)

        return CompletionResult(
            text=text,
            confidence=confidence,
            confidence_method="logprob",
            logprob_entropy=entropy_nats,
            raw_logprobs=logprobs_data,
            token_count=response.usage.total_tokens if response.usage else 0,
        )

    def _complete_with_sampling(
        self, prompt: str, system: str | None = None
    ) -> CompletionResult:
        """Measure confidence via multi-sample agreement."""
        messages = self._build_messages(prompt, system)

        responses = []
        total_tokens = 0
        _ll = _get_litellm()

        retryable_excs = _build_retryable_exceptions(_ll)
        for sample_idx in range(self.num_samples):
            # Per-sample retry loop: 429/rate-limit responses on free tiers
            # (e.g. Groq Llama-4 at RPM=30) used to be swallowed silently,
            # causing "all samples failed" when backing off would have worked.
            last_err: Exception | None = None
            for attempt in range(4):
                try:
                    response = _ll.completion(
                        model=self.model,
                        messages=messages,
                        temperature=self.temperature,
                        max_tokens=self.max_tokens,
                        timeout=self.timeout,
                        api_key=self.api_key,
                        extra_headers=_UA_HEADER,
                    )
                    text = response.choices[0].message.content or ""
                    responses.append(text)
                    if response.usage:
                        total_tokens += response.usage.total_tokens
                    last_err = None
                    break
                except (KeyboardInterrupt, SystemExit):
                    raise
                except retryable_excs as e:
                    last_err = e
                    import time as _t_mod
                    wait = min(2 ** attempt + 1, 30)
                    logger.debug(
                        "Sample %d/%d retryable error (attempt %d): sleeping %ds",
                        sample_idx + 1, self.num_samples, attempt + 1, wait,
                    )
                    _t_mod.sleep(wait)
                    continue
                except Exception as e:
                    last_err = e
                    logger.debug("Sample %d/%d failed: %s", sample_idx + 1, self.num_samples, e)
                    break
            if last_err is not None:
                logger.debug(
                    "Sample %d/%d gave up after retries: %s",
                    sample_idx + 1, self.num_samples, last_err,
                )
                continue  # Skip this sample, try the next one

        if not responses:
            from yuragi.exceptions import ScanError

            raise ScanError(
                f"All {self.num_samples} sampling attempts failed for model={self.model}"
            )

        # Measure agreement: how similar are the responses?
        confidence = self._measure_agreement(responses)

        return CompletionResult(
            text=responses[0],  # Use first response as canonical
            confidence=confidence,
            confidence_method="sampling",
            token_count=total_tokens,
        )

    def _extract_logprobs(self, response) -> list[list[tuple[str, float]]]:
        """Extract logprobs from litellm response."""
        try:
            choice = response.choices[0]
            if not hasattr(choice, "logprobs") or choice.logprobs is None:
                return []
            content = choice.logprobs.content
            if not content:
                return []
            result = []
            for token_info in content:
                top = []
                if hasattr(token_info, "top_logprobs") and token_info.top_logprobs:
                    for entry in token_info.top_logprobs:
                        top.append((entry.token, entry.logprob))
                result.append(top)
            return result
        except (AttributeError, IndexError, TypeError):
            return []

    def _calculate_entropy(
        self, raw_logprobs: list[tuple[str, float]] | list[list[tuple[str, float]]]
    ) -> float:
        """Shannon entropy in NATS (changed from bits in v0.2.0).

        Cover & Thomas 2006, Farquhar 2024 (Nature) use nats as the
        information-theoretic NLP standard.

        Accepts either a flat list of (token, logprob) pairs (per-token)
        or a nested list of per-token top-k lists and returns the mean
        entropy across tokens.
        """
        if not raw_logprobs:
            return 0.0

        # Normalise to nested format: list[list[tuple[str, float]]]
        if raw_logprobs and not isinstance(raw_logprobs[0], (list, tuple)):
            # Already a flat list of (token, logprob) pairs — treat as single token
            nested: list[list[tuple[str, float]]] = [raw_logprobs]  # type: ignore[list-item]
        elif raw_logprobs and isinstance(raw_logprobs[0], tuple):
            nested = [raw_logprobs]  # type: ignore[list-item]
        else:
            nested = raw_logprobs  # type: ignore[assignment]

        entropies = []
        for token_probs in nested:
            if not token_probs:
                continue
            # logsumexp trick: subtract max log-prob before exponentiating to
            # avoid overflow/underflow when logprobs are very large in magnitude.
            max_lp = max(lp for _, lp in token_probs)
            total = sum(math.exp(lp - max_lp) for _, lp in token_probs)
            if total <= 0:
                continue
            probs = [math.exp(lp - max_lp) / total for _, lp in token_probs]
            entropy_nats = -sum(p * math.log(p + 1e-12) for p in probs if p > 0)
            entropies.append(entropy_nats)

        return statistics.mean(entropies) if entropies else 0.0

    def _measure_agreement(self, responses: list[str]) -> float:
        """Measure confidence as agreement ratio among multiple responses.

        Uses character-level similarity (simple but effective).
        Higher agreement = higher confidence.
        """
        if len(responses) <= 1:
            return 0.5  # Unknown

        n = len(responses)
        similarities = []

        for i in range(n):
            for j in range(i + 1, n):
                sim = self._text_similarity(responses[i], responses[j])
                similarities.append(sim)

        return statistics.mean(similarities) if similarities else 0.5

    @staticmethod
    def _text_similarity(a: str, b: str) -> float:
        """Character 3-gram Jaccard similarity (language-agnostic, works for CJK)."""
        return _text_similarity_fn(a, b)

    @staticmethod
    def _parse_verbalized_confidence(text: str) -> tuple[float, str]:
        """Parse 'CONFIDENCE: X' from response text."""
        match = re.search(r"CONFIDENCE:\s*(\d+(?:\.\d+)?)", text, re.IGNORECASE)
        if match:
            raw = float(match.group(1))
            # Models may respond on 0-1 scale or 1-100 scale.
            # If raw is already in [0, 1] treat it as a direct probability;
            # otherwise divide by 100 to normalise from the 1-100 scale.
            confidence = max(0.0, min(1.0, raw)) if raw < 1.0 else max(0.0, min(1.0, raw / 100.0))
            clean = text[: match.start()].rstrip()
            return confidence, clean
        return 0.5, text  # Default if parsing fails


# ---------------------------------------------------------------------------
# ConfidenceEstimator
# ---------------------------------------------------------------------------


class ConfidenceEstimator:
    """Pluggable confidence estimation strategies.

    Each method returns a float in [0.0, 1.0].  Methods can be composed via
    ``estimate_hybrid`` which merges all available signals with a weighted
    average.
    """

    # Weight for each source when all three are present.
    # logprob is most accurate; sampling is reliable; verbalized is noisiest.
    _DEFAULT_WEIGHTS: ClassVar[dict[str, float]] = {
        "logprob": 0.5,
        "sampling": 0.35,
        "verbalized": 0.15,
    }

    def estimate_logprob(self, response: CompletionResult) -> float:
        """Return the confidence already extracted from logprobs.

        If the result was not produced with logprob measurement, returns 0.5
        (neutral, unknown) rather than raising.
        """
        if response.confidence_method == "logprob":
            return max(0.0, min(1.0, response.confidence))
        return 0.5

    def estimate_sampling(self, responses: list[CompletionResult]) -> float:
        """Estimate confidence from agreement across multiple sampled responses.

        Uses character 3-gram Jaccard similarity — same algorithm as
        ``LLMAdapter._text_similarity`` so results are consistent.

        Args:
            responses: Two or more CompletionResults generated at temperature > 0.

        Returns:
            Mean pairwise similarity in [0.0, 1.0]; 0.5 if fewer than 2 responses.
        """
        texts = [r.text for r in responses if r.text]
        if len(texts) < 2:
            return 0.5

        def _ngrams(text: str, n: int = 3) -> set[str]:
            text = text.lower()
            if len(text) < n:
                return {text} if text else set()
            return {text[i : i + n] for i in range(len(text) - n + 1)}

        def _jaccard(a: str, b: str) -> float:
            ng_a, ng_b = _ngrams(a), _ngrams(b)
            if not ng_a and not ng_b:
                return 1.0
            union = ng_a | ng_b
            return len(ng_a & ng_b) / len(union) if union else 0.0

        similarities = [
            _jaccard(texts[i], texts[j])
            for i in range(len(texts))
            for j in range(i + 1, len(texts))
        ]
        return statistics.mean(similarities)

    def estimate_verbalized(self, response: CompletionResult) -> float:
        """Return the verbalized confidence stored in the CompletionResult.

        If the result was not produced with verbalized measurement, returns 0.5.
        """
        if response.confidence_method == "verbalized":
            return max(0.0, min(1.0, response.confidence))
        return 0.5

    def estimate_hybrid(
        self,
        response: CompletionResult,
        sampled_responses: list[CompletionResult] | None = None,
        verbalized_response: CompletionResult | None = None,
        weights: dict[str, float] | None = None,
    ) -> float:
        """Combine all available confidence signals with a weighted average.

        Only signals where actual data is present are included in the blend:
        - logprob  — used when ``response.confidence_method == "logprob"``
        - sampling — used when ``sampled_responses`` contains >= 2 items
        - verbalized — used when ``verbalized_response.confidence_method == "verbalized"``

        Args:
            response: Primary CompletionResult (may be logprob or sampling mode).
            sampled_responses: Optional list of sampled results for agreement scoring.
            verbalized_response: Optional result obtained via verbalized prompting.
            weights: Override default weights ``{"logprob": 0.5, "sampling": 0.35,
                "verbalized": 0.15}``.

        Returns:
            Weighted-average confidence in [0.0, 1.0].
        """
        w = weights if weights is not None else self._DEFAULT_WEIGHTS

        signals: dict[str, float] = {}

        if response.confidence_method == "logprob":
            signals["logprob"] = self.estimate_logprob(response)

        if sampled_responses and len(sampled_responses) >= 2:
            signals["sampling"] = self.estimate_sampling(sampled_responses)

        if verbalized_response and verbalized_response.confidence_method == "verbalized":
            signals["verbalized"] = self.estimate_verbalized(verbalized_response)

        # Fall back to the raw confidence if no richer signals are available
        if not signals:
            return max(0.0, min(1.0, response.confidence))

        total_weight = sum(w.get(k, 1.0) for k in signals)
        if total_weight <= 0:
            return statistics.mean(signals.values())

        blended = sum(v * w.get(k, 1.0) for k, v in signals.items()) / total_weight
        return max(0.0, min(1.0, blended))
