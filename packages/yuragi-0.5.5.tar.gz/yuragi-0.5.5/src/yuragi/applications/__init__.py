"""Practical applications of yuragi fragility analysis.

Five production-ready modules:
- check: CI/CD fragility regression detection
- route: Fragility-aware multi-model routing
- guard: Abstention system for high-stakes domains
- recommend: Model selection based on fragility profiles
- red_team: Automated vulnerability discovery
"""

from __future__ import annotations

from yuragi.applications import check, guard, recommend, red_team, route

__all__ = [
    "check",
    "guard",
    "recommend",
    "red_team",
    "route",
]
