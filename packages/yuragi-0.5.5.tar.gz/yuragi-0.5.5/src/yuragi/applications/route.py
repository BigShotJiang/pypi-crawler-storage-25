"""Fragility-aware multi-model routing.

Routes a prompt to the model with the lowest fragility, ensuring the
most reliable answer is selected.

Usage (Python)::

    from yuragi.applications.route import FragilityRouter, RouteResult

    router = FragilityRouter(
        models=["gpt-4o-mini", "ollama/llama3.2", "cerebras/llama-3.1-8b"],
    )
    result = router.route("What causes inflation?")
    print(result.selected_model)     # "gpt-4o-mini"
    print(result.selected_answer)    # "Inflation is caused by..."
    print(result.fragility_scores)   # {"gpt-4o-mini": 0.02, ...}

Usage (CLI)::

    yuragi route "What causes inflation?" \\
        --models gpt-4o-mini,ollama/llama3.2,cerebras/llama-3.1-8b

Strategies:
- lowest_fragility (default): pick the model with lowest fragility_score
- lowest_vulnerability: pick the model with lowest vulnerability (downward only)
- ensemble_weighted: weighted answer by inverse fragility

.. deprecated:: 0.5.3
    This module relies on yuragi's baseline_confidence (bc), which is mathematically
    identical to the Kadavath 2022 / Farquhar 2024 K-normalized mean-token entropy
    baseline (see KNOWN_LIMITATIONS.md L16). Additionally, paired-bootstrap analysis
    (experiments/ablation_46_paired_bootstrap_verdict.md) shows that 13-perturbation
    fragility features HURT classification AUC decisively (Δ=-0.029 LogReg, p=0.016).
    Cross-provider comparison is non-commutative due to differing top-K logprob
    support (NIM K=5 vs Cerebras K=20); bc scores from different providers are not
    directly comparable.

    Use as a thin wrapper around logprob entropy, not as a novel UQ signal.
"""

from __future__ import annotations

import logging
import warnings
from dataclasses import dataclass
from typing import Any, Literal

from yuragi.config import DEFAULT_CONFIG, YuragiConfig
from yuragi.core import Scanner, ScanResult

logger = logging.getLogger(__name__)

RoutingStrategy = Literal["lowest_fragility", "lowest_vulnerability", "ensemble_weighted"]


@dataclass(frozen=True)
class ModelCandidate:
    """Result from a single model candidate."""

    model: str
    answer: str
    confidence: float
    fragility_score: float
    vulnerability: float
    dissociation_rate: float
    scan_result: ScanResult


@dataclass(frozen=True)
class RouteResult:
    """Result of fragility-aware routing."""

    prompt: str
    strategy: RoutingStrategy
    selected_model: str
    selected_answer: str
    selected_fragility: float
    selected_confidence: float
    candidates: list[ModelCandidate]
    fragility_scores: dict[str, float]
    ensemble_weights: dict[str, float] | None = None

    @property
    def routing_confidence(self) -> float:
        """How confident are we in the routing decision.

        High when the gap between best and second-best is large.
        Range: [0, 1].
        """
        scores = sorted(self.fragility_scores.values())
        if len(scores) < 2:
            return 1.0
        gap = scores[1] - scores[0]
        # Normalize: gap of 0.1 -> high confidence, gap of 0 -> low
        return min(gap / 0.1, 1.0)

    @property
    def consensus(self) -> bool:
        """True if all models gave similar answers (fragility spread < 0.02)."""
        scores = list(self.fragility_scores.values())
        return (max(scores) - min(scores)) < 0.02 if scores else True

    def to_dict(self) -> dict[str, Any]:
        """Serialize for JSON output."""
        d: dict[str, Any] = {
            "prompt": self.prompt,
            "strategy": self.strategy,
            "selected_model": self.selected_model,
            "selected_answer": self.selected_answer[:200],
            "selected_fragility": self.selected_fragility,
            "selected_confidence": self.selected_confidence,
            "routing_confidence": self.routing_confidence,
            "consensus": self.consensus,
            "fragility_scores": self.fragility_scores,
            "candidates": [
                {
                    "model": c.model,
                    "fragility": c.fragility_score,
                    "confidence": c.confidence,
                    "vulnerability": c.vulnerability,
                    "dissociation_rate": c.dissociation_rate,
                }
                for c in self.candidates
            ],
        }
        if self.ensemble_weights is not None:
            d["ensemble_weights"] = self.ensemble_weights
        return d


class FragilityRouter:
    """Route prompts to the most stable model.

    Parameters
    ----------
    models : list[str]
        Model identifiers (litellm format).
    strategy : RoutingStrategy
        Routing strategy. Default "lowest_fragility".
    config : YuragiConfig, optional
        Yuragi configuration.
    """

    def __init__(
        self,
        models: list[str],
        strategy: RoutingStrategy = "lowest_fragility",
        config: YuragiConfig | None = None,
    ) -> None:
        if len(models) < 2:
            msg = "FragilityRouter requires at least 2 models"
            raise ValueError(msg)
        self.models = models
        self.strategy = strategy
        self.config = config or DEFAULT_CONFIG

    def route(self, prompt: str) -> RouteResult:
        """Route a prompt to the most stable model.

        Scans the prompt with each model, then selects based on strategy.
        """
        warnings.warn(
            "FragilityRouter.route() uses bc which is Kadavath 2022 logprob-entropy baseline; "
            "perturbation features HURT AUC (ablation_46 CI [-0.052,-0.006]). "
            "Cross-provider bc comparison is non-commutative (NIM K=5 vs Cerebras K=20). "
            "Treat as measurement harness, not novel UQ. See KNOWN_LIMITATIONS.md L16.",
            DeprecationWarning, stacklevel=2,
        )
        candidates: list[ModelCandidate] = []

        for model in self.models:
            with Scanner(model=model, config=self.config) as scanner:
                result = scanner.scan(prompt)
            candidates.append(
                ModelCandidate(
                    model=model,
                    answer=result.baseline.text,
                    confidence=result.baseline.confidence,
                    fragility_score=result.fragility_score,
                    vulnerability=result.vulnerability,
                    dissociation_rate=result.dissociation_rate,
                    scan_result=result,
                )
            )

        selected, ensemble_weights = self._select(candidates)
        fragility_scores = {c.model: c.fragility_score for c in candidates}

        return RouteResult(
            prompt=prompt,
            strategy=self.strategy,
            selected_model=selected.model,
            selected_answer=selected.answer,
            selected_fragility=selected.fragility_score,
            selected_confidence=selected.confidence,
            candidates=candidates,
            fragility_scores=fragility_scores,
            ensemble_weights=ensemble_weights,
        )

    def _select(
        self, candidates: list[ModelCandidate]
    ) -> tuple[ModelCandidate, dict[str, float] | None]:
        """Select the best candidate based on strategy.

        Returns
        -------
        tuple[ModelCandidate, dict[str, float] | None]
            The selected candidate and, for ensemble_weighted, the normalized
            inverse-fragility weights keyed by model name.
        """
        if self.strategy == "lowest_fragility":
            return min(candidates, key=lambda c: c.fragility_score), None
        elif self.strategy == "lowest_vulnerability":
            return min(candidates, key=lambda c: c.vulnerability), None
        elif self.strategy == "ensemble_weighted":
            # Compute inverse-fragility weights w_i = 1 / F_i.
            # Guard against zero fragility with a small epsilon.
            eps = 1e-9
            raw = {c.model: 1.0 / (c.fragility_score + eps) for c in candidates}
            total = sum(raw.values())
            weights = {model: w / total for model, w in raw.items()}
            # Primary model is the one with highest weight (= lowest fragility).
            selected = max(candidates, key=lambda c: weights[c.model])
            return selected, weights
        else:
            return min(candidates, key=lambda c: c.fragility_score), None
