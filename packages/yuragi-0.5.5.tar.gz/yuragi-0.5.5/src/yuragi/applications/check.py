"""CI/CD fragility regression detection.

Run ``yuragi check`` in your CI pipeline to catch fragility regressions
before they reach production.

Usage (CLI)::

    yuragi check --baseline baseline.json --model gpt-4o-mini prompts.txt

Usage (Python)::

    from yuragi.applications.check import FragilityChecker, CheckResult

    checker = FragilityChecker(model="gpt-4o-mini")
    result = checker.run(
        prompts=["Is quantum computing practical?", ...],
        baseline_path="baseline.json",
    )
    if result.failed:
        print(result.summary)
        sys.exit(1)

Usage (GitHub Actions)::

    - name: Fragility check
      run: |
        pip install yuragi
        yuragi check --baseline baseline.json --model ${{ env.MODEL }} prompts.txt

.. deprecated:: 0.5.3
    This module relies on yuragi's baseline_confidence (bc), which is mathematically
    identical to the Kadavath 2022 / Farquhar 2024 K-normalized mean-token entropy
    baseline (see KNOWN_LIMITATIONS.md L16). Additionally, paired-bootstrap analysis
    (experiments/ablation_46_paired_bootstrap_verdict.md) shows that 13-perturbation
    fragility features HURT classification AUC decisively (Δ=-0.029 LogReg, p=0.016).
    CI/CD thresholds are calibrated against fragility scores that are bc-delta
    tautologies; threshold breaches may reflect logprob variance, not genuine
    model regression.

    Use as a thin wrapper around logprob entropy, not as a novel UQ signal.
"""

from __future__ import annotations

import json
import logging
import warnings
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any

from yuragi.config import DEFAULT_CONFIG, YuragiConfig
from yuragi.core import Scanner

logger = logging.getLogger(__name__)


@dataclass(frozen=True)
class PromptRegression:
    """A single prompt that regressed beyond the threshold."""

    prompt: str
    baseline_fragility: float
    current_fragility: float
    delta: float
    category: str | None = None

    @property
    def regression_pct(self) -> float:
        """Regression as percentage increase."""
        if self.baseline_fragility == 0:
            return float("inf") if self.delta > 0 else 0.0
        return (self.delta / self.baseline_fragility) * 100


@dataclass
class CheckResult:
    """Result of a fragility regression check."""

    prompts_checked: int = 0
    regressions: list[PromptRegression] = field(default_factory=list)
    improvements: list[PromptRegression] = field(default_factory=list)
    current_results: dict[str, float] = field(default_factory=dict)
    baseline_results: dict[str, float] = field(default_factory=dict)
    threshold_abs: float = 0.05
    threshold_pct: float = 10.0

    @property
    def failed(self) -> bool:
        """True if any prompt regressed beyond thresholds."""
        return len(self.regressions) > 0

    @property
    def exit_code(self) -> int:
        """0 = pass, 1 = regressions detected."""
        return 1 if self.failed else 0

    @property
    def mean_delta(self) -> float:
        """Mean fragility change across all prompts."""
        if not self.current_results:
            return 0.0
        deltas = []
        for prompt, current in self.current_results.items():
            baseline = self.baseline_results.get(prompt, current)
            deltas.append(current - baseline)
        return sum(deltas) / len(deltas) if deltas else 0.0

    @property
    def summary(self) -> str:
        """Human-readable summary for CI output."""
        lines = [f"yuragi check: {self.prompts_checked} prompts"]
        if self.regressions:
            lines.append(
                f"FAIL: {len(self.regressions)} regression(s) detected "
                f"(threshold: +{self.threshold_abs:.3f} abs / +{self.threshold_pct:.0f}%)"
            )
            for r in self.regressions:
                lines.append(
                    f"  - {r.prompt[:60]}... "
                    f"baseline={r.baseline_fragility:.4f} -> "
                    f"current={r.current_fragility:.4f} "
                    f"(+{r.delta:.4f}, +{r.regression_pct:.1f}%)"
                )
        else:
            lines.append("PASS: no fragility regressions")
        if self.improvements:
            lines.append(f"  {len(self.improvements)} improvement(s)")
        lines.append(f"  mean delta: {self.mean_delta:+.4f}")
        return "\n".join(lines)

    def to_dict(self) -> dict[str, Any]:
        """Serialize for JSON output."""
        return {
            "status": "fail" if self.failed else "pass",
            "prompts_checked": self.prompts_checked,
            "regressions_count": len(self.regressions),
            "improvements_count": len(self.improvements),
            "mean_delta": self.mean_delta,
            "threshold_abs": self.threshold_abs,
            "threshold_pct": self.threshold_pct,
            "regressions": [
                {
                    "prompt": r.prompt,
                    "baseline": r.baseline_fragility,
                    "current": r.current_fragility,
                    "delta": r.delta,
                    "regression_pct": r.regression_pct,
                }
                for r in self.regressions
            ],
        }


class FragilityChecker:
    """CI/CD fragility regression checker.

    Scans a set of prompts, compares against a baseline, and reports
    regressions that exceed configurable thresholds.

    Parameters
    ----------
    model : str
        LLM model identifier (litellm format).
    config : YuragiConfig, optional
        Yuragi configuration.
    threshold_abs : float
        Absolute fragility increase to flag as regression. Default 0.05.
    threshold_pct : float
        Percentage fragility increase to flag as regression. Default 10.0.
        A prompt is flagged if EITHER threshold is exceeded.
    """

    def __init__(
        self,
        model: str = "ollama/llama3.2",
        config: YuragiConfig | None = None,
        threshold_abs: float = 0.05,
        threshold_pct: float = 10.0,
    ) -> None:
        self.model = model
        self.config = config or DEFAULT_CONFIG
        self.threshold_abs = threshold_abs
        self.threshold_pct = threshold_pct

    def run(
        self,
        prompts: list[str],
        baseline_path: str | Path | None = None,
        baseline_data: dict[str, float] | None = None,
        save_baseline: str | Path | None = None,
    ) -> CheckResult:
        """Run fragility check against a baseline.

        Parameters
        ----------
        prompts : list[str]
            Prompts to check.
        baseline_path : str | Path, optional
            Path to JSON baseline file (prompt -> fragility_score).
        baseline_data : dict[str, float], optional
            Inline baseline data. Takes precedence over baseline_path.
        save_baseline : str | Path, optional
            If set, save current results as new baseline.

        Returns
        -------
        CheckResult
        """
        warnings.warn(
            "FragilityChecker.run() uses bc which is Kadavath 2022 logprob-entropy baseline; "
            "perturbation features HURT AUC (ablation_46 CI [-0.052,-0.006]). "
            "CI/CD thresholds calibrated on bc-delta tautologies may flag logprob variance as regression. "
            "Treat as measurement harness, not novel UQ. See KNOWN_LIMITATIONS.md L16.",
            DeprecationWarning, stacklevel=2,
        )
        baseline = self._load_baseline(baseline_path, baseline_data)

        current: dict[str, float] = {}
        regressions: list[PromptRegression] = []
        improvements: list[PromptRegression] = []

        with Scanner(model=self.model, config=self.config) as scanner:
            for prompt in prompts:
                result = scanner.scan(prompt)
                score = result.fragility_score
                current[prompt] = score

                if prompt in baseline:
                    bl = baseline[prompt]
                    delta = score - bl
                    reg = PromptRegression(
                        prompt=prompt,
                        baseline_fragility=bl,
                        current_fragility=score,
                        delta=delta,
                    )
                    if delta > self.threshold_abs or (bl > 0 and reg.regression_pct > self.threshold_pct):
                        regressions.append(reg)
                    elif delta < -self.threshold_abs:
                        improvements.append(reg)

        if save_baseline:
            Path(save_baseline).write_text(
                json.dumps(current, indent=2, ensure_ascii=False)
            )
            logger.info("Saved baseline to %s", save_baseline)

        return CheckResult(
            prompts_checked=len(prompts),
            regressions=regressions,
            improvements=improvements,
            current_results=current,
            baseline_results=baseline,
            threshold_abs=self.threshold_abs,
            threshold_pct=self.threshold_pct,
        )

    def _load_baseline(
        self,
        path: str | Path | None,
        data: dict[str, float] | None,
    ) -> dict[str, float]:
        """Load baseline from file or inline data."""
        if data is not None:
            return data
        if path is not None:
            p = Path(path)
            if p.exists():
                raw = json.loads(p.read_text())
                # Support both flat {prompt: score} and nested format
                if isinstance(raw, dict):
                    if all(isinstance(v, (int, float)) for v in raw.values()):
                        return raw
                    # Nested: extract fragility_score from each entry
                    return {
                        k: v["fragility_score"]
                        for k, v in raw.items()
                        if isinstance(v, dict) and "fragility_score" in v
                    }
            logger.warning("Baseline file not found: %s (treating as first run)", path)
        return {}
