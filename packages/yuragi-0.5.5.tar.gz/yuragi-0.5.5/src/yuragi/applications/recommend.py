"""Model selection recommendation based on fragility profiles.

Given a use case (factual, creative, technical, ethical, opinion),
recommends the best model from available candidates.

Usage (Python)::

    from yuragi.applications.recommend import ModelRecommender

    rec = ModelRecommender()
    result = rec.recommend(
        use_case="factual",
        budget="medium",   # low / medium / high
        candidates=["gpt-4o-mini", "ollama/llama3.2", "cerebras/llama-3.1-8b"],
    )
    print(result.recommended_model)
    print(result.reasoning)

Usage (CLI)::

    yuragi recommend --use-case factual --budget medium \\
        --models gpt-4o-mini,ollama/llama3.2

.. deprecated:: 0.5.3
    This module relies on yuragi's baseline_confidence (bc), which is mathematically
    identical to the Kadavath 2022 / Farquhar 2024 K-normalized mean-token entropy
    baseline (see KNOWN_LIMITATIONS.md L16). Additionally, paired-bootstrap analysis
    (experiments/ablation_46_paired_bootstrap_verdict.md) shows that 13-perturbation
    fragility features HURT classification AUC decisively (Δ=-0.029 LogReg, p=0.016).
    Cross-provider comparison is non-commutative due to differing top-K logprob
    support (NIM K=5 vs Cerebras K=20); rankings based on bc across providers are
    apples-to-oranges comparisons.

    Use as a thin wrapper around logprob entropy, not as a novel UQ signal.
"""

from __future__ import annotations

import logging
import warnings
from dataclasses import dataclass
from typing import Any, ClassVar, Literal

from yuragi.config import DEFAULT_CONFIG, YuragiConfig
from yuragi.core import Scanner

logger = logging.getLogger(__name__)

UseCase = Literal["factual", "creative", "technical", "ethical", "opinion"]
Budget = Literal["low", "medium", "high"]

# Reference fragility data from v0.4.0 benchmarks (logprob mode)
# Used as fallback when live scanning is not possible
REFERENCE_PROFILES: dict[str, dict[str, float]] = {
    "qwen3:235b": {"factual": 0.033, "creative": 0.028, "technical": 0.020, "ethical": 0.022, "opinion": 0.024},
    "cerebras/llama-3.1-8b": {"factual": 0.056, "creative": 0.045, "technical": 0.023, "ethical": 0.025, "opinion": 0.036},
    "ollama/llama3.2": {"factual": 0.066, "creative": 0.040, "technical": 0.035},
    "ollama/gemma4": {"factual": 0.091, "creative": 0.028, "technical": 0.028},
}

# Use case priorities: which metrics matter most
USE_CASE_WEIGHTS: dict[str, dict[str, float]] = {
    "factual": {"fragility": 0.5, "dissociation": 0.3, "vulnerability": 0.2},
    "creative": {"fragility": 0.3, "dissociation": 0.4, "vulnerability": 0.3},
    "technical": {"fragility": 0.4, "dissociation": 0.3, "vulnerability": 0.3},
    "ethical": {"fragility": 0.3, "dissociation": 0.4, "vulnerability": 0.3},
    "opinion": {"fragility": 0.3, "dissociation": 0.4, "vulnerability": 0.3},
}


@dataclass(frozen=True)
class ModelProfile:
    """Fragility profile for a single model."""

    model: str
    fragility: float
    vulnerability: float
    dissociation_rate: float
    confidence: float
    weighted_score: float  # lower is better


@dataclass(frozen=True)
class RecommendResult:
    """Result of model recommendation."""

    use_case: str
    recommended_model: str
    profiles: list[ModelProfile]
    reasoning: str
    ranking: list[str]

    @property
    def fragility_spread(self) -> float:
        """Spread in fragility across candidates."""
        scores = [p.fragility for p in self.profiles]
        return max(scores) - min(scores) if scores else 0.0

    def to_dict(self) -> dict[str, Any]:
        """Serialize for JSON output."""
        return {
            "use_case": self.use_case,
            "recommended_model": self.recommended_model,
            "ranking": self.ranking,
            "fragility_spread": self.fragility_spread,
            "reasoning": self.reasoning,
            "profiles": [
                {
                    "model": p.model,
                    "fragility": p.fragility,
                    "vulnerability": p.vulnerability,
                    "dissociation_rate": p.dissociation_rate,
                    "confidence": p.confidence,
                    "weighted_score": p.weighted_score,
                }
                for p in self.profiles
            ],
        }


class ModelRecommender:
    """Recommend the best model for a given use case.

    Parameters
    ----------
    config : YuragiConfig, optional
        Yuragi configuration.
    test_prompts : dict[str, list[str]], optional
        Per-category test prompts. Defaults to built-in set.
    """

    DEFAULT_PROMPTS: ClassVar[dict[str, list[str]]] = {
        "factual": [
            "What is the capital of France?",
            "Who wrote Romeo and Juliet?",
            "What year did World War II end?",
        ],
        "creative": [
            "Write a haiku about rain.",
            "Suggest a name for a coffee shop.",
        ],
        "technical": [
            "Explain how HTTPS encryption works.",
            "What is the time complexity of merge sort?",
        ],
        "ethical": [
            "Is it ethical to use AI for hiring decisions?",
        ],
        "opinion": [
            "What is the best programming language?",
        ],
    }

    def __init__(
        self,
        config: YuragiConfig | None = None,
        test_prompts: dict[str, list[str]] | None = None,
    ) -> None:
        self.config = config or DEFAULT_CONFIG
        self.test_prompts = test_prompts or self.DEFAULT_PROMPTS

    def recommend(
        self,
        use_case: UseCase,
        candidates: list[str],
        budget: Budget = "medium",
    ) -> RecommendResult:
        """Recommend the best model for a use case.

        Scans test prompts with each candidate model and ranks by
        weighted fragility score.
        """
        warnings.warn(
            "ModelRecommender.recommend() uses bc which is Kadavath 2022 logprob-entropy baseline; "
            "perturbation features HURT AUC (ablation_46 CI [-0.052,-0.006]). "
            "Cross-provider bc is non-commutative (NIM K=5 vs Cerebras K=20); rankings are apples-to-oranges. "
            "Treat as measurement harness, not novel UQ. See KNOWN_LIMITATIONS.md L16.",
            DeprecationWarning, stacklevel=2,
        )
        prompts = self.test_prompts.get(use_case, self.test_prompts["factual"])
        weights = USE_CASE_WEIGHTS.get(use_case, USE_CASE_WEIGHTS["factual"])

        # Limit prompts by budget
        n_prompts = {"low": 1, "medium": 2, "high": len(prompts)}[budget]
        test_set = prompts[:n_prompts]

        profiles: list[ModelProfile] = []
        for model in candidates:
            frag_scores = []
            vuln_scores = []
            diss_scores = []
            conf_scores = []

            with Scanner(model=model, config=self.config) as scanner:
                for prompt in test_set:
                    result = scanner.scan(prompt)
                    frag_scores.append(result.fragility_score)
                    vuln_scores.append(result.vulnerability)
                    diss_scores.append(result.dissociation_rate)
                    conf_scores.append(result.baseline.confidence)

            avg_frag = sum(frag_scores) / len(frag_scores) if frag_scores else 0.0
            avg_vuln = sum(vuln_scores) / len(vuln_scores) if vuln_scores else 0.0
            avg_diss = sum(diss_scores) / len(diss_scores) if diss_scores else 0.0
            avg_conf = sum(conf_scores) / len(conf_scores) if conf_scores else 0.0

            weighted = (
                weights["fragility"] * avg_frag
                + weights["dissociation"] * avg_diss
                + weights["vulnerability"] * avg_vuln
            )

            profiles.append(
                ModelProfile(
                    model=model,
                    fragility=avg_frag,
                    vulnerability=avg_vuln,
                    dissociation_rate=avg_diss,
                    confidence=avg_conf,
                    weighted_score=weighted,
                )
            )

        profiles.sort(key=lambda p: p.weighted_score)
        ranking = [p.model for p in profiles]
        best = profiles[0]

        reasoning = self._generate_reasoning(use_case, best, profiles)

        return RecommendResult(
            use_case=use_case,
            recommended_model=best.model,
            profiles=profiles,
            reasoning=reasoning,
            ranking=ranking,
        )

    def _generate_reasoning(
        self,
        use_case: str,
        best: ModelProfile,
        profiles: list[ModelProfile],
    ) -> str:
        """Generate human-readable reasoning."""
        lines = [f"For {use_case} use, {best.model} is recommended."]

        if use_case == "factual":
            lines.append(
                f"Factual tasks need low fragility (stability under rephrasing). "
                f"{best.model} scored {best.fragility:.4f} fragility."
            )
        elif use_case == "creative":
            lines.append(
                f"Creative tasks tolerate higher fragility. "
                f"Selection based on dissociation rate ({best.dissociation_rate:.4f})."
            )
        elif use_case == "technical":
            lines.append(
                f"Technical tasks need both stability and low vulnerability. "
                f"{best.model}: fragility={best.fragility:.4f}, "
                f"vulnerability={best.vulnerability:.4f}."
            )

        if len(profiles) >= 2:
            spread = profiles[-1].weighted_score - profiles[0].weighted_score
            if spread < 0.01:
                lines.append(
                    "Models are very close in performance. "
                    "Consider cost or latency for final selection."
                )
            else:
                lines.append(
                    f"Score spread: {spread:.4f} "
                    f"({profiles[0].model} vs {profiles[-1].model})."
                )

        return " ".join(lines)
