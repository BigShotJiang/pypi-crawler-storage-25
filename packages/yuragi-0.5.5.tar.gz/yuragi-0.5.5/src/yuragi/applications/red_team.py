"""Automated red teaming via fragility perturbation.

Discovers a model's weaknesses by systematically probing with yuragi's
perturbation types and identifying which perturbations cause the largest
confidence shifts.

Usage (Python)::

    from yuragi.applications.red_team import FragilityRedTeam

    red = FragilityRedTeam(model="gpt-4o-mini")
    report = red.probe(prompts=["What is 2+2?", "Explain gravity."])
    print(report.summary)
    for v in report.vulnerabilities:
        print(f"  {v.perturbation_type}: severity={v.severity:.3f}")

Usage (CLI)::

    yuragi red-team --model gpt-4o-mini prompts.txt --output report.json

.. deprecated:: 0.5.3
    This module relies on yuragi's baseline_confidence (bc), which is mathematically
    identical to the Kadavath 2022 / Farquhar 2024 K-normalized mean-token entropy
    baseline (see KNOWN_LIMITATIONS.md L16). Additionally, paired-bootstrap analysis
    (experiments/ablation_46_paired_bootstrap_verdict.md) shows that 13-perturbation
    fragility features HURT classification AUC decisively (Δ=-0.029 LogReg, p=0.016).
    Severity scores here are bc-delta tautologies; NLI-based semantic shift validation
    is absent, so reported "vulnerabilities" may not correspond to genuine answer changes.

    Use as a thin wrapper around logprob entropy, not as a novel UQ signal.
"""

from __future__ import annotations

import logging
import warnings
from collections import defaultdict
from dataclasses import dataclass, field
from typing import Any

from yuragi.config import DEFAULT_CONFIG, YuragiConfig
from yuragi.core import Scanner, ScanResult

logger = logging.getLogger(__name__)


@dataclass(frozen=True)
class Vulnerability:
    """A discovered vulnerability."""

    perturbation_type: str
    severity: float  # mean |delta_C| for this perturbation across all prompts
    max_delta: float  # worst-case delta
    affected_prompts: int  # number of prompts affected
    total_prompts: int
    example_prompt: str  # worst-case prompt
    example_delta: float
    causes_answer_change: bool  # any answer changed?

    @property
    def risk_level(self) -> str:
        """Risk classification based on severity."""
        if self.severity > 0.10:
            return "critical"
        if self.severity > 0.05:
            return "high"
        if self.severity > 0.02:
            return "medium"
        return "low"


@dataclass(frozen=True)
class ModelWeakness:
    """Summary of a model's overall weakness profile."""

    model: str
    overall_fragility: float
    weakest_perturbation: str
    weakest_perturbation_severity: float
    strongest_perturbation: str  # least vulnerable
    strongest_perturbation_severity: float
    answer_instability_rate: float  # fraction of perturbations that changed answers


@dataclass
class RedTeamReport:
    """Complete red team report."""

    model: str
    prompts_tested: int
    vulnerabilities: list[Vulnerability] = field(default_factory=list)
    weakness: ModelWeakness | None = None
    scan_results: list[ScanResult] = field(default_factory=list)

    @property
    def critical_count(self) -> int:
        return sum(1 for v in self.vulnerabilities if v.risk_level == "critical")

    @property
    def high_count(self) -> int:
        return sum(1 for v in self.vulnerabilities if v.risk_level == "high")

    @property
    def summary(self) -> str:
        """Human-readable report summary."""
        lines = [f"Red Team Report: {self.model} ({self.prompts_tested} prompts)"]
        lines.append("=" * 60)

        if self.weakness:
            lines.append(
                f"Overall fragility: {self.weakness.overall_fragility:.4f}"
            )
            lines.append(
                f"Weakest to: {self.weakness.weakest_perturbation} "
                f"(severity {self.weakness.weakest_perturbation_severity:.4f})"
            )
            lines.append(
                f"Strongest against: {self.weakness.strongest_perturbation} "
                f"(severity {self.weakness.strongest_perturbation_severity:.4f})"
            )
            lines.append(
                f"Answer instability: {self.weakness.answer_instability_rate:.1%}"
            )

        lines.append("")
        lines.append("Vulnerabilities by perturbation type:")
        for v in sorted(self.vulnerabilities, key=lambda x: -x.severity):
            lines.append(
                f"  [{v.risk_level.upper():8s}] {v.perturbation_type:20s} "
                f"severity={v.severity:.4f}  "
                f"affected={v.affected_prompts}/{v.total_prompts}"
            )
            if v.risk_level in ("critical", "high"):
                lines.append(f"           worst prompt: {v.example_prompt[:60]}...")

        return "\n".join(lines)

    def to_dict(self) -> dict[str, Any]:
        """Serialize for JSON output."""
        return {
            "model": self.model,
            "prompts_tested": self.prompts_tested,
            "critical_vulnerabilities": self.critical_count,
            "high_vulnerabilities": self.high_count,
            "weakness": {
                "overall_fragility": self.weakness.overall_fragility,
                "weakest_perturbation": self.weakness.weakest_perturbation,
                "strongest_perturbation": self.weakness.strongest_perturbation,
                "answer_instability_rate": self.weakness.answer_instability_rate,
            }
            if self.weakness
            else None,
            "vulnerabilities": [
                {
                    "perturbation_type": v.perturbation_type,
                    "risk_level": v.risk_level,
                    "severity": v.severity,
                    "max_delta": v.max_delta,
                    "affected_prompts": v.affected_prompts,
                    "total_prompts": v.total_prompts,
                    "causes_answer_change": v.causes_answer_change,
                    "example_prompt": v.example_prompt[:100],
                }
                for v in sorted(self.vulnerabilities, key=lambda x: -x.severity)
            ],
        }


class FragilityRedTeam:
    """Automated red teaming through fragility probing.

    Parameters
    ----------
    model : str
        Target model to probe.
    config : YuragiConfig, optional
        Yuragi configuration.
    """

    def __init__(
        self,
        model: str = "ollama/llama3.2",
        config: YuragiConfig | None = None,
    ) -> None:
        self.model = model
        self.config = config or DEFAULT_CONFIG

    def probe(self, prompts: list[str]) -> RedTeamReport:
        """Probe a model with a set of prompts.

        Scans each prompt and aggregates vulnerabilities by perturbation type.
        """
        warnings.warn(
            "FragilityRedTeam.probe() uses bc which is Kadavath 2022 logprob-entropy baseline; "
            "perturbation features HURT AUC (ablation_46 CI [-0.052,-0.006]). "
            "Severity scores are bc-delta tautologies; NLI semantic validation absent. "
            "Treat as measurement harness, not novel UQ. See KNOWN_LIMITATIONS.md L16.",
            DeprecationWarning, stacklevel=2,
        )
        scan_results: list[ScanResult] = []

        # Collect per-perturbation-type data
        type_deltas: dict[str, list[float]] = defaultdict(list)
        type_max: dict[str, tuple[float, str]] = {}
        type_answer_changed: dict[str, bool] = defaultdict(lambda: False)

        with Scanner(model=self.model, config=self.config) as scanner:
            for prompt in prompts:
                result = scanner.scan(prompt)
                scan_results.append(result)

                for pr in result.perturbation_results:
                    ptype = pr.perturbation_type
                    delta = abs(pr.confidence_delta)
                    type_deltas[ptype].append(delta)

                    if ptype not in type_max or delta > type_max[ptype][0]:
                        type_max[ptype] = (delta, prompt)

                    if pr.answer_changed:
                        type_answer_changed[ptype] = True

        # Build vulnerabilities
        vulnerabilities: list[Vulnerability] = []
        for ptype, deltas in type_deltas.items():
            n_affected = sum(1 for d in deltas if d > self.config.dissociation_noise_floor)
            max_info = type_max.get(ptype, (0.0, ""))
            vulnerabilities.append(
                Vulnerability(
                    perturbation_type=ptype,
                    severity=sum(deltas) / len(deltas) if deltas else 0.0,
                    max_delta=max_info[0],
                    affected_prompts=n_affected,
                    total_prompts=len(prompts),
                    example_prompt=max_info[1],
                    example_delta=max_info[0],
                    causes_answer_change=type_answer_changed[ptype],
                )
            )

        # Build overall weakness profile
        weakness = None
        if vulnerabilities:
            sorted_v = sorted(vulnerabilities, key=lambda v: -v.severity)
            overall_frag = sum(r.fragility_score for r in scan_results) / len(scan_results)

            total_answer_changes = 0
            total_perturbations = 0
            for r in scan_results:
                for pr in r.perturbation_results:
                    total_perturbations += 1
                    if pr.answer_changed:
                        total_answer_changes += 1

            weakness = ModelWeakness(
                model=self.model,
                overall_fragility=overall_frag,
                weakest_perturbation=sorted_v[0].perturbation_type,
                weakest_perturbation_severity=sorted_v[0].severity,
                strongest_perturbation=sorted_v[-1].perturbation_type,
                strongest_perturbation_severity=sorted_v[-1].severity,
                answer_instability_rate=(
                    total_answer_changes / total_perturbations
                    if total_perturbations > 0
                    else 0.0
                ),
            )

        return RedTeamReport(
            model=self.model,
            prompts_tested=len(prompts),
            vulnerabilities=vulnerabilities,
            weakness=weakness,
            scan_results=scan_results,
        )
