"""Fragility-aware abstention system.

For high-stakes domains (medical, legal, financial), refuse to answer
when confidence fragility exceeds safety thresholds.

Usage (Python)::

    from yuragi.applications.guard import FragilityGuard, GuardDecision

    guard = FragilityGuard(
        model="gpt-4o-mini",
        domain="medical",
    )
    decision = guard.evaluate("What medication should I take for headaches?")
    if decision.should_abstain:
        print(decision.abstention_reason)
    else:
        print(decision.answer)

Usage (CLI)::

    yuragi guard "What medication should I take?" --model gpt-4o-mini --domain medical

Domain presets adjust thresholds automatically:
- medical:   fragility < 0.03, dissociation < 0.05
- legal:     fragility < 0.04, dissociation < 0.08
- financial: fragility < 0.04, dissociation < 0.08
- safety:    fragility < 0.02, dissociation < 0.03
- general:   fragility < 0.10, dissociation < 0.15

.. deprecated:: 0.5.3
    This module relies on yuragi's baseline_confidence (bc), which is mathematically
    identical to the Kadavath 2022 / Farquhar 2024 K-normalized mean-token entropy
    baseline (see KNOWN_LIMITATIONS.md L16). Additionally, paired-bootstrap analysis
    (experiments/ablation_46_paired_bootstrap_verdict.md) shows that 13-perturbation
    fragility features HURT classification AUC decisively (Δ=-0.029 LogReg, p=0.016).
    Abstention decisions are bc-only; Kadavath identity must be disclosed to downstream
    users who rely on this guard for safety-critical applications.

    Use as a thin wrapper around logprob entropy, not as a novel UQ signal.
"""

from __future__ import annotations

import logging
import warnings
from dataclasses import dataclass
from typing import Any, Literal

from yuragi.config import DEFAULT_CONFIG, YuragiConfig
from yuragi.core import Scanner, ScanResult

logger = logging.getLogger(__name__)

Domain = Literal["medical", "legal", "financial", "safety", "general"]

# Domain-specific thresholds calibrated from v0.4.0 benchmarks:
# factual fragility 0.033-0.091 (logprob mode)
DOMAIN_THRESHOLDS: dict[str, dict[str, float]] = {
    "medical": {
        "max_fragility": 0.03,
        "max_dissociation": 0.05,
        "max_vulnerability": 0.03,
        "min_confidence": 0.70,
    },
    "legal": {
        "max_fragility": 0.04,
        "max_dissociation": 0.08,
        "max_vulnerability": 0.04,
        "min_confidence": 0.60,
    },
    "financial": {
        "max_fragility": 0.04,
        "max_dissociation": 0.08,
        "max_vulnerability": 0.04,
        "min_confidence": 0.60,
    },
    "safety": {
        "max_fragility": 0.02,
        "max_dissociation": 0.03,
        "max_vulnerability": 0.02,
        "min_confidence": 0.80,
    },
    "general": {
        "max_fragility": 0.10,
        "max_dissociation": 0.15,
        "max_vulnerability": 0.10,
        "min_confidence": 0.40,
    },
}


@dataclass(frozen=True)
class GuardDecision:
    """Result of a fragility guard evaluation."""

    prompt: str
    model: str
    domain: str
    answer: str
    confidence: float
    fragility_score: float
    vulnerability: float
    dissociation_rate: float
    should_abstain: bool
    abstention_reasons: list[str]
    thresholds: dict[str, float]
    scan_result: ScanResult

    @property
    def abstention_reason(self) -> str:
        """Single-line abstention reason."""
        if not self.abstention_reasons:
            return ""
        return "; ".join(self.abstention_reasons)

    @property
    def risk_level(self) -> str:
        """Risk level: safe / caution / danger."""
        if not self.should_abstain:
            return "safe"
        return "danger" if len(self.abstention_reasons) >= 2 else "caution"

    @property
    def safe_response(self) -> str:
        """The response to return to users.

        Returns the answer if safe, or an abstention message if not.
        """
        if not self.should_abstain:
            return self.answer
        return (
            f"I'm not confident enough to answer this reliably "
            f"for {self.domain} use. {self.abstention_reason}. "
            f"Please consult a qualified professional."
        )

    def to_dict(self) -> dict[str, Any]:
        """Serialize for JSON output."""
        return {
            "prompt": self.prompt,
            "model": self.model,
            "domain": self.domain,
            "should_abstain": self.should_abstain,
            "risk_level": self.risk_level,
            "abstention_reasons": self.abstention_reasons,
            "answer": self.answer[:200] if not self.should_abstain else "[ABSTAINED]",
            "confidence": self.confidence,
            "fragility_score": self.fragility_score,
            "vulnerability": self.vulnerability,
            "dissociation_rate": self.dissociation_rate,
            "thresholds": self.thresholds,
        }


class FragilityGuard:
    """Fragility-aware abstention system.

    Parameters
    ----------
    model : str
        LLM model identifier.
    domain : Domain
        Domain preset (medical, legal, financial, safety, general).
    config : YuragiConfig, optional
        Yuragi configuration.
    custom_thresholds : dict[str, float], optional
        Override domain thresholds. Keys: max_fragility, max_dissociation,
        max_vulnerability, min_confidence.
    """

    def __init__(
        self,
        model: str = "ollama/llama3.2",
        domain: Domain = "general",
        config: YuragiConfig | None = None,
        custom_thresholds: dict[str, float] | None = None,
    ) -> None:
        self.model = model
        self.domain = domain
        self.config = config or DEFAULT_CONFIG
        self.thresholds = {**DOMAIN_THRESHOLDS.get(domain, DOMAIN_THRESHOLDS["general"])}
        if custom_thresholds:
            self.thresholds.update(custom_thresholds)

    def evaluate(self, prompt: str) -> GuardDecision:
        """Evaluate a prompt for safe answering.

        Scans the prompt for fragility and checks against domain thresholds.
        """
        warnings.warn(
            "FragilityGuard.evaluate() uses bc which is Kadavath 2022 logprob-entropy baseline; "
            "perturbation features HURT AUC (ablation_46 CI [-0.052,-0.006]). "
            "Abstention is bc-only; disclose Kadavath identity to safety-critical downstream users. "
            "Treat as measurement harness, not novel UQ. See KNOWN_LIMITATIONS.md L16.",
            DeprecationWarning, stacklevel=2,
        )
        with Scanner(model=self.model, config=self.config) as scanner:
            result = scanner.scan(prompt)

        reasons: list[str] = []

        if result.fragility_score > self.thresholds["max_fragility"]:
            reasons.append(
                f"fragility {result.fragility_score:.4f} > "
                f"{self.thresholds['max_fragility']:.4f}"
            )

        if result.dissociation_rate > self.thresholds["max_dissociation"]:
            reasons.append(
                f"dissociation {result.dissociation_rate:.4f} > "
                f"{self.thresholds['max_dissociation']:.4f}"
            )

        if result.vulnerability > self.thresholds["max_vulnerability"]:
            reasons.append(
                f"vulnerability {result.vulnerability:.4f} > "
                f"{self.thresholds['max_vulnerability']:.4f}"
            )

        if result.baseline.confidence < self.thresholds["min_confidence"]:
            reasons.append(
                f"confidence {result.baseline.confidence:.4f} < "
                f"{self.thresholds['min_confidence']:.4f}"
            )

        return GuardDecision(
            prompt=prompt,
            model=self.model,
            domain=self.domain,
            answer=result.baseline.text,
            confidence=result.baseline.confidence,
            fragility_score=result.fragility_score,
            vulnerability=result.vulnerability,
            dissociation_rate=result.dissociation_rate,
            should_abstain=len(reasons) > 0,
            abstention_reasons=reasons,
            thresholds=self.thresholds,
            scan_result=result,
        )

    def batch_evaluate(self, prompts: list[str]) -> list[GuardDecision]:
        """Evaluate multiple prompts."""
        return [self.evaluate(p) for p in prompts]
