"""Centralized configuration for all yuragi thresholds and tuning parameters.

Every magic number in the codebase lives here.  Users can override any value
by constructing a custom ``YuragiConfig`` and passing it to the relevant API.

    from yuragi.config import YuragiConfig

    cfg = YuragiConfig(answer_similarity_threshold=0.8)
    result = Scanner(model="ollama/llama3.2", config=cfg).scan("...")

When no config is supplied, ``DEFAULT_CONFIG`` (all defaults) is used.
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import Literal


@dataclass(frozen=True)
class YuragiConfig:
    """All tunable thresholds and coefficients used across yuragi.

    Frozen so instances are hashable and safe to share across threads.
    """

    # ---- Dissociation (core.py) ----
    # Confidence delta below this is treated as noise
    dissociation_noise_floor: float = 0.06
    # Unified similarity threshold for answer_changed judgment.
    # Lowered from 0.75 to 0.5 in v0.4.0: empirical analysis showed 0.75
    # too strict for factual answers with varying verbosity (L15).
    answer_similarity_threshold: float = 0.5

    # ---- Confidence normalization (providers/adapter.py) ----
    # Number of top logprobs (k) used for entropy normalization: max_entropy = ln(k)
    top_logprobs_k: int = 5
    # Similarity backend for answer comparison
    similarity_backend: Literal["jaccard", "sbert"] = "jaccard"

    # ---- Fragility profile (fragility_profile.py) ----
    # Confidence-per-character at which CCI = 1.0
    cci_normalization: float = 0.05
    # Minimum |delta| to count as a meaningful drop/boost
    recovery_threshold: float = 0.05
    # Std-dev-of-efficiency at which NLS = 1.0
    nls_normalization: float = 0.03

    # ---- Volatility (metrics/volatility.py) ----
    vix_baseline_mean: float = 0.15
    vix_baseline_std: float = 0.10
    regime_stable: float = 0.10
    regime_transitional: float = 0.30
    regime_volatile: float = 0.50

    # ---- Statistics (analysis/statistics.py) ----
    cohens_d_small: float = 0.2
    cohens_d_medium: float = 0.5
    cohens_d_large: float = 0.8

    # ---- Linguistics (analysis/linguistics.py) ----
    hedge_penalty_multiplier: float = 80.0
    hedge_penalty_cap: float = 0.45
    assertion_boost_multiplier: float = 60.0
    assertion_boost_cap: float = 0.35
    linguistic_gap_threshold: float = 0.15
    # Sentence length penalty values in _compute_linguistic_confidence
    linguistic_sentence_penalty_long: float = 0.05
    linguistic_sentence_penalty_short: float = 0.02

    # ---- Phase transition (analysis/phase_transition.py) ----
    phase_sharpness_threshold: float = 0.05
    phase_transition_delta_min: float = 0.02
    phase_band_width: float = 0.15
    # EMA smoothing factor in _count_phases
    phase_ema_alpha: float = 0.7
    # Confidence boundaries for human-readable phase labels
    phase_confidence_high: float = 0.7
    phase_confidence_low: float = 0.4

    # ---- CLI defaults ----
    default_model: str = "ollama/llama3.2"

    # ---- Rate limiting ----
    rate_limit_rpm: int = 0  # 0 = no limit; requests per minute

    # ---- Reproducibility ----
    seed: int | None = None

    # ---- Trilayer thresholds ----
    trilayer_internal_conflict_threshold: float = 0.2

    # ---- Trajectory thresholds ----
    trajectory_decline_threshold: float = -0.1
    trajectory_recovery_threshold: float = 0.05
    trajectory_volatility_threshold: float = 0.1
    # Variance below this value is treated as stable in trend detection
    trajectory_stable_variance_threshold: float = 0.01

    # ---- Decay grid ----
    decay_grid_min: float = 0.01
    decay_grid_max: float = 5.0
    decay_grid_steps: int = 200

    # ---- Recovery ----
    recovery_baseline_ratio: float = 0.9

    # ---- Adversarial ----
    adversarial_sycophancy_threshold: float = 0.2
    adversarial_severe_threshold: float = 0.0

    # ---- Experiments (experiments/registry.py) ----
    # min max_delta to confirm an experiment's hypothesized effect
    experiment_effect_threshold: float = 0.15

    # ---- Verbalized logit gap (metrics/verbalized_logit_gap.py) ----
    # gap threshold for counting a sample as overconfident
    verbalized_logit_gap_overconf_threshold: float = 0.1

    # ---- Minimal edit ----
    minimal_edit_significance_threshold: float = -0.05

    # ---- Calibration ----
    calibration_n_bins: int = 10

    # ---- Fragility labels (4 boundaries → 5 labels) ----
    fragility_label_boundaries: tuple[float, ...] = (0.15, 0.35, 0.55, 0.80)

    # ---- Bootstrap ----
    bootstrap_iterations: int = 1000


DEFAULT_CONFIG = YuragiConfig()
