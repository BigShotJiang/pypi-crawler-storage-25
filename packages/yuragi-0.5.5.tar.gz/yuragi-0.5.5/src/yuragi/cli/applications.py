"""CLI commands for yuragi practical applications.

Commands: check, route, guard, recommend, red-team
"""

from __future__ import annotations

import json
import sys
from pathlib import Path

import click
from rich.console import Console
from rich.panel import Panel
from rich.table import Table

console = Console()


@click.command()
@click.argument("prompts_file", type=click.Path(exists=True))
@click.option("--baseline", "-b", type=click.Path(), default=None, help="Baseline JSON file")
@click.option("--model", "-m", default="ollama/llama3.2", help="Model to test")
@click.option("--threshold", "-t", default=0.05, type=float, help="Absolute fragility threshold")
@click.option("--threshold-pct", default=10.0, type=float, help="Percentage threshold")
@click.option("--save-baseline", type=click.Path(), default=None, help="Save results as new baseline")
@click.option("--json-output", "-j", is_flag=True, help="JSON output")
@click.pass_context
def check(
    ctx: click.Context,
    prompts_file: str,
    baseline: str | None,
    model: str,
    threshold: float,
    threshold_pct: float,
    save_baseline: str | None,
    json_output: bool,
) -> None:
    """Check for fragility regressions (CI/CD integration).

    Reads prompts from PROMPTS_FILE (one per line) and compares against
    a baseline. Exit code 1 if regressions detected.

    \b
    Example:
        yuragi check prompts.txt --baseline baseline.json --model gpt-4o-mini
        yuragi check prompts.txt --save-baseline baseline.json  # first run
    """
    from yuragi.applications.check import FragilityChecker

    prompts = [
        line.strip()
        for line in Path(prompts_file).read_text().splitlines()
        if line.strip() and not line.strip().startswith("#")
    ]

    if not prompts:
        console.print("[red]No prompts found in file[/red]")
        sys.exit(1)

    checker = FragilityChecker(
        model=model,
        threshold_abs=threshold,
        threshold_pct=threshold_pct,
    )

    with console.status("Running fragility check..."):
        result = checker.run(
            prompts=prompts,
            baseline_path=baseline,
            save_baseline=save_baseline,
        )

    if json_output:
        click.echo(json.dumps(result.to_dict(), indent=2))
    else:
        if result.failed:
            console.print(Panel(result.summary, title="FAIL", border_style="red"))
        else:
            console.print(Panel(result.summary, title="PASS", border_style="green"))

    sys.exit(result.exit_code)


@click.command()
@click.argument("prompt")
@click.option("--models", "-m", required=True, help="Comma-separated model list")
@click.option(
    "--strategy",
    "-s",
    type=click.Choice(["lowest_fragility", "lowest_vulnerability", "ensemble_weighted"]),
    default="lowest_fragility",
    help="Routing strategy",
)
@click.option("--json-output", "-j", is_flag=True, help="JSON output")
@click.pass_context
def route(
    ctx: click.Context,
    prompt: str,
    models: str,
    strategy: str,
    json_output: bool,
) -> None:
    """Route a prompt to the most stable model.

    \b
    Example:
        yuragi route "What causes inflation?" \\
            --models gpt-4o-mini,ollama/llama3.2,cerebras/llama-3.1-8b
    """
    from yuragi.applications.route import FragilityRouter

    model_list = [m.strip() for m in models.split(",") if m.strip()]

    router = FragilityRouter(models=model_list, strategy=strategy)

    with console.status("Scanning models for fragility..."):
        result = router.route(prompt)

    if json_output:
        click.echo(json.dumps(result.to_dict(), indent=2))
    else:
        table = Table(title="Fragility-Aware Routing")
        table.add_column("Model", style="cyan")
        table.add_column("Fragility", justify="right")
        table.add_column("Confidence", justify="right")
        table.add_column("Selected", justify="center")

        for c in result.candidates:
            selected = "[bold green]>>>[/bold green]" if c.model == result.selected_model else ""
            table.add_row(
                c.model,
                f"{c.fragility_score:.4f}",
                f"{c.confidence:.4f}",
                selected,
            )

        console.print(table)
        console.print(f"\nSelected: [bold]{result.selected_model}[/bold] (strategy: {result.strategy})")
        console.print(f"Routing confidence: {result.routing_confidence:.2f}")


@click.command()
@click.argument("prompt")
@click.option("--model", "-m", default="ollama/llama3.2", help="Model to evaluate")
@click.option(
    "--domain",
    "-d",
    type=click.Choice(["medical", "legal", "financial", "safety", "general"]),
    default="general",
    help="Domain preset",
)
@click.option("--json-output", "-j", is_flag=True, help="JSON output")
@click.pass_context
def guard(
    ctx: click.Context,
    prompt: str,
    model: str,
    domain: str,
    json_output: bool,
) -> None:
    """Evaluate if a prompt is safe to answer (abstention system).

    \b
    Example:
        yuragi guard "What medication should I take?" --model gpt-4o-mini --domain medical
    """
    from yuragi.applications.guard import FragilityGuard

    g = FragilityGuard(model=model, domain=domain)

    with console.status("Evaluating fragility for safe answering..."):
        decision = g.evaluate(prompt)

    if json_output:
        click.echo(json.dumps(decision.to_dict(), indent=2))
    else:
        if decision.should_abstain:
            console.print(
                Panel(
                    f"[bold red]ABSTAIN[/bold red] ({decision.risk_level})\n\n"
                    f"{decision.safe_response}\n\n"
                    f"[dim]Reasons: {decision.abstention_reason}[/dim]",
                    title=f"Guard: {domain}",
                    border_style="red",
                )
            )
        else:
            console.print(
                Panel(
                    f"[bold green]SAFE[/bold green]\n\n"
                    f"Fragility: {decision.fragility_score:.4f}  "
                    f"Confidence: {decision.confidence:.4f}  "
                    f"Dissociation: {decision.dissociation_rate:.4f}",
                    title=f"Guard: {domain}",
                    border_style="green",
                )
            )


@click.command()
@click.option("--models", "-m", required=True, help="Comma-separated model list")
@click.option(
    "--use-case",
    "-u",
    type=click.Choice(["factual", "creative", "technical", "ethical", "opinion"]),
    default="factual",
    help="Target use case",
)
@click.option(
    "--budget",
    type=click.Choice(["low", "medium", "high"]),
    default="medium",
    help="Test budget (number of prompts)",
)
@click.option("--json-output", "-j", is_flag=True, help="JSON output")
@click.pass_context
def recommend(
    ctx: click.Context,
    models: str,
    use_case: str,
    budget: str,
    json_output: bool,
) -> None:
    """Recommend the best model for your use case.

    \b
    Example:
        yuragi recommend --use-case factual --models gpt-4o-mini,ollama/llama3.2
    """
    from yuragi.applications.recommend import ModelRecommender

    model_list = [m.strip() for m in models.split(",") if m.strip()]

    rec = ModelRecommender()

    with console.status("Profiling models..."):
        result = rec.recommend(use_case=use_case, candidates=model_list, budget=budget)

    if json_output:
        click.echo(json.dumps(result.to_dict(), indent=2))
    else:
        table = Table(title=f"Model Recommendation: {use_case}")
        table.add_column("Rank", justify="right")
        table.add_column("Model", style="cyan")
        table.add_column("Fragility", justify="right")
        table.add_column("Vulnerability", justify="right")
        table.add_column("Dissociation", justify="right")
        table.add_column("Score", justify="right")

        for i, p in enumerate(result.profiles, 1):
            style = "bold green" if i == 1 else ""
            table.add_row(
                str(i),
                p.model,
                f"{p.fragility:.4f}",
                f"{p.vulnerability:.4f}",
                f"{p.dissociation_rate:.4f}",
                f"{p.weighted_score:.4f}",
                style=style,
            )

        console.print(table)
        console.print(f"\n{result.reasoning}")


@click.command("red-team")
@click.argument("prompts_file", type=click.Path(exists=True))
@click.option("--model", "-m", default="ollama/llama3.2", help="Model to probe")
@click.option("--output", "-o", type=click.Path(), default=None, help="Save report to JSON")
@click.option("--json-output", "-j", is_flag=True, help="JSON output to stdout")
@click.pass_context
def red_team(
    ctx: click.Context,
    prompts_file: str,
    model: str,
    output: str | None,
    json_output: bool,
) -> None:
    """Automated red teaming via fragility probing.

    Discovers which perturbation types cause the largest confidence shifts.

    \b
    Example:
        yuragi red-team prompts.txt --model gpt-4o-mini --output report.json
    """
    from yuragi.applications.red_team import FragilityRedTeam

    prompts = [
        line.strip()
        for line in Path(prompts_file).read_text().splitlines()
        if line.strip() and not line.strip().startswith("#")
    ]

    if not prompts:
        console.print("[red]No prompts found in file[/red]")
        sys.exit(1)

    red = FragilityRedTeam(model=model)

    with console.status(f"Probing {model} with {len(prompts)} prompts..."):
        report = red.probe(prompts)

    if output:
        Path(output).write_text(json.dumps(report.to_dict(), indent=2))
        console.print(f"Report saved to {output}")

    if json_output:
        click.echo(json.dumps(report.to_dict(), indent=2))
    else:
        console.print(Panel(report.summary, title="Red Team Report", border_style="red"))
