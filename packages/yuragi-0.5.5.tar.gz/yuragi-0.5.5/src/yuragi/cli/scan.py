"""scan and find-weakness CLI commands."""

from __future__ import annotations

import csv
import sys

import click
from rich import box
from rich.console import Console
from rich.panel import Panel
from rich.progress import Progress, SpinnerColumn, TextColumn
from rich.rule import Rule
from rich.table import Table
from rich.text import Text

from yuragi.config import DEFAULT_CONFIG
from yuragi.core import DEFAULT_PERTURBATIONS, Scanner, ScanResult
from yuragi.perturbations import Perturbation

from .helpers import (
    ERR_API_KEY,
    ERR_MODEL,
    ERR_OLLAMA_NOT_FOUND,
    _confidence_bar,
    _delta_text,
    _find_removed_word,
    _fragility_color,
    _key_insight,
    _severity_color,
)

console = Console()


def _print_logo(quiet: bool = False) -> None:
    from yuragi import __version__

    logo = "[bold cyan]yuragi[/bold cyan] [dim]v{version}[/dim]"
    if quiet:
        return
    console.print(logo.format(version=__version__))
    console.print()


def _highlight_diff(original: str, perturbed: str) -> Text:
    """Highlight the difference between original and perturbed text."""
    text = Text()
    if len(perturbed) > 50:
        text.append(perturbed[:50] + "...", style="white")
    else:
        text.append(perturbed, style="white")
    return text


def _display_prompt_with_weakness(prompt: str, weak_word: str) -> None:
    """Display prompt with the weakest word highlighted in red/bold, others dimmed."""
    words = prompt.split()
    text = Text()
    for i, word in enumerate(words):
        if i > 0:
            text.append(" ")
        stripped = word.strip(".,!?;:\"'")
        if stripped.lower() == weak_word.lower() or word.lower() == weak_word.lower():
            text.append(word, style="bold red")
        else:
            text.append(word, style="dim")
    console.print(text)


def _display_scan_result(result: ScanResult, quiet: bool = False) -> None:
    """Display scan results with Rich formatting."""
    console.print()
    console.print(
        Panel(
            f"[bold]yuragi[/bold] confidence fragility scan\n"
            f"[dim]Model: {result.model} | "
            f"Method: {result.baseline.confidence_method} | "
            f"Duration: {result.scan_duration_seconds:.1f}s | "
            f"API calls: {result.total_api_calls}[/dim]",
            title="[bold cyan]\u63fa\u3089\u304e[/bold cyan]",
            border_style="cyan",
        )
    )

    console.print(f"\n[bold]Original:[/bold] {result.prompt}")
    console.print(
        f"[dim]Answer:[/dim] {result.baseline.text[:100]}{'...' if len(result.baseline.text) > 100 else ''}"
    )
    console.print(Text.assemble("Confidence: ", _confidence_bar(result.baseline.confidence)))
    console.print()

    table = Table(
        title="Perturbation Results",
        box=box.ROUNDED,
        show_lines=True,
        title_style="bold",
    )
    table.add_column("Type", style="cyan", width=12)
    table.add_column("Mutation", max_width=50)
    table.add_column("Confidence", width=35)
    table.add_column("\u0394", width=12)
    table.add_column("Severity", width=10)
    table.add_column("Answer", width=8)

    for r in sorted(result.perturbation_results, key=lambda x: x.confidence_delta):
        mutation_display = _highlight_diff(result.prompt, r.perturbed_prompt)

        answer_status = (
            Text("same", style="green") if not r.answer_changed
            else Text("CHANGED", style="bold red")
        )

        delta = _delta_text(r.confidence_delta)
        if r.is_dissociated:
            delta.append(" [!]", style="bold magenta")

        sev = r.dissociation_severity
        sev_style = _severity_color(sev)
        severity_cell = Text(f"{sev:.2f}", style=sev_style) if sev > 0 else Text("\u2014", style="dim")

        table.add_row(
            r.perturbation_type,
            mutation_display,
            _confidence_bar(r.perturbed_response.confidence),
            delta,
            severity_cell,
            answer_status,
        )

    console.print(table)

    fragility = result.fragility_score
    frag_style = _fragility_color(fragility)

    summary_lines = []
    summary_lines.append(
        f"Fragility Score: [{frag_style}]{fragility:.2f} ({result.fragility_label()})[/{frag_style}]"
    )
    summary_lines.append(
        f"Worst perturbation: {result.fragility_max:.3f}"
    )
    tau = result.config.dissociation_noise_floor
    summary_lines.append(
        f"Exceedance rate (\u03c4={tau:.2f}): {result.fragility_exceed:.1%}"
    )
    ci = result.fragility_ci_95()
    if ci is not None:
        summary_lines.append(f"95% CI: [{ci[0]:.3f}, {ci[1]:.3f}]")
    else:
        summary_lines.append("CI: n/a (need n\u22655)")
    summary_lines.append(f"Confidence Range: {result.confidence_range:.2f}")
    summary_lines.append(
        f"Dissociation Rate: {result.dissociation_rate:.0%} "
        f"(answer same, confidence shifted)"
    )

    try:
        from yuragi.analysis.fragility_profile import build_profile

        fp = build_profile(result)
        cci_c = "red" if fp.catastrophic_collapse_index > 0.5 else "yellow" if fp.catastrophic_collapse_index > 0.2 else "green"
        re_c = "red" if fp.recovery_elasticity < 0.3 else "yellow" if fp.recovery_elasticity < 0.6 else "green"
        nl_c = "red" if fp.non_linearity_score > 0.6 else "yellow" if fp.non_linearity_score > 0.3 else "green"
        summary_lines.append(
            f"\n[bold]Fragility Profile[/bold]  [{cci_c}]CCI {fp.catastrophic_collapse_index:.2f}[/{cci_c}]"
            f"  [{re_c}]RE {fp.recovery_elasticity:.2f}[/{re_c}]"
            f"  [{nl_c}]NLS {fp.non_linearity_score:.2f}[/{nl_c}]"
            f"  [dim]({fp.profile_label})[/dim]"
        )
    except Exception:
        pass

    weakest = result.weakest_perturbation
    if weakest and weakest.confidence_delta < -0.05:
        summary_lines.append(
            f"\n[bold red]Weakest point:[/bold red] "
            f'"{weakest.perturbed_prompt[:60]}..."'
            f"\n  \u0394 = {weakest.confidence_delta:+.2f} ({weakest.perturbation_type})"
        )

    strongest = result.strongest_perturbation
    if strongest and strongest.confidence_delta > 0.05:
        summary_lines.append(
            f"\n[bold green]Strongest boost:[/bold green] "
            f'"{strongest.perturbed_prompt[:60]}..."'
            f"\n  \u0394 = {strongest.confidence_delta:+.2f} ({strongest.perturbation_type})"
        )

    console.print(
        Panel(
            "\n".join(summary_lines),
            title="[bold]Summary[/bold]",
            border_style="cyan",
        )
    )

    console.print(
        Panel(
            _key_insight(result),
            title="[bold yellow]\u2728 Key Insight[/bold yellow]",
            border_style="yellow",
        )
    )
    console.print()


def _export_scan_csv(result: ScanResult, path: str) -> None:
    """Export scan results to CSV."""
    with open(path, "w", newline="", encoding="utf-8") as f:
        writer = csv.writer(f)
        writer.writerow([
            "prompt", "model", "perturbation_type", "perturbed_prompt",
            "baseline_confidence", "perturbed_confidence", "delta",
            "answer_changed", "dissociated", "dissociation_severity",
        ])
        for r in result.perturbation_results:
            writer.writerow([
                result.prompt,
                result.model,
                r.perturbation_type,
                r.perturbed_prompt,
                f"{result.baseline.confidence:.4f}",
                f"{r.perturbed_response.confidence:.4f}",
                f"{r.confidence_delta:+.4f}",
                r.answer_changed,
                r.is_dissociated,
                f"{r.dissociation_severity:.4f}",
            ])


@click.command()
@click.argument("prompt")
@click.option(
    "--model", "-m",
    default=DEFAULT_CONFIG.default_model,
    help="Model to test (any litellm-supported model)",
)
@click.option(
    "--samples", "-n",
    default=5,
    type=int,
    help="Number of samples for confidence measurement (non-logprob models)",
)
@click.option(
    "--variants", "-v",
    default=3,
    type=int,
    help="Number of variants per perturbation type",
)
@click.option(
    "--perturbations", "-p",
    default="all",
    help="Comma-separated perturbation types (typo,synonym,omit,reorder,tone,paraphrase,conformity,impostor,anchoring,semantic,negation,counterfactual,code_switching) or 'all'",
)
@click.option("--json-output", "-j", is_flag=True, help="Output as JSON")
@click.option("--html", type=str, default=None, help="Save HTML report to file")
@click.option("--dashboard", type=str, default=None, help="Save interactive Plotly dashboard to file")
@click.option("--plot", type=str, default=None, help="Save heatmap plot to file")
@click.option("--csv-output", type=str, default=None, help="Export results to CSV file")
@click.option(
    "--benchmark",
    default=None,
    type=click.Choice(["truthfulqa", "simpleqa", "halueval"]),
    help="Load questions from a public benchmark instead of PROMPT argument",
)
@click.option("--benchmark-limit", default=10, type=int, help="Max questions to load from benchmark")
@click.pass_context
def scan(ctx: click.Context, prompt: str, model: str, samples: int, variants: int, perturbations: list[str], json_output: bool, html: str | None, dashboard: bool, plot: str | None, csv_output: str | None, benchmark: str | None, benchmark_limit: int) -> None:
    """Scan a prompt for confidence fragility.

    Example:
        yuragi scan "Is quantum computing practical?" -m gpt-4o
        yuragi scan "" --benchmark truthfulqa --benchmark-limit 5
    """
    quiet = ctx.obj.get("quiet", False) if ctx.obj else False
    if not json_output and not quiet:
        _print_logo(quiet)

    if perturbations == "all":
        pert_types = DEFAULT_PERTURBATIONS
    else:
        pert_types = []
        for name in perturbations.split(","):
            name = name.strip()
            try:
                pert_types.append(Perturbation(name))
            except ValueError:
                console.print(f"[red]Unknown perturbation: {name}[/red]")
                console.print(
                    f"Available: {', '.join(p.value for p in Perturbation)}"
                )
                sys.exit(1)

    # Benchmark mode: iterate questions from the benchmark dataset
    if benchmark is not None:
        from yuragi.benchmarks_loader import yield_questions

        questions = list(yield_questions(benchmark, limit=benchmark_limit))
        if not questions:
            console.print(f"[red]No questions loaded from benchmark: {benchmark}[/red]")
            sys.exit(1)
        if not json_output and not quiet:
            console.print(f"[cyan]Benchmark:[/cyan] {benchmark} ({len(questions)} questions)")
            console.print(f"[dim]Model: {model} | Samples: {samples} | Variants: {variants}[/dim]")

        all_results = []
        for i, q in enumerate(questions, 1):
            qtext = q["question"]
            if not json_output and not quiet:
                console.print(f"[dim]({i}/{len(questions)}) {qtext[:60]}...[/dim]")
            scanner = Scanner(
                model=model,
                num_samples=samples,
                perturbations=pert_types,
                num_variants=variants,
            )
            try:
                res = scanner.scan(qtext)
                all_results.append(res)
            except Exception as e:
                console.print(f"[yellow]Skipped ({qtext[:40]}): {e}[/yellow]")

        if not all_results:
            console.print("[red]All benchmark questions failed.[/red]")
            sys.exit(1)

        if json_output:
            import json as _json
            output = [_json.loads(r.to_json()) for r in all_results]
            print(_json.dumps(output, indent=2, ensure_ascii=False))
        else:
            avg_fragility = sum(r.fragility_score for r in all_results) / len(all_results)
            console.print(
                f"\n[bold]Benchmark scan complete:[/bold] {len(all_results)} questions"
            )
            console.print(f"Average fragility score: [cyan]{avg_fragility:.3f}[/cyan]")
        return

    if not prompt:
        console.print("[red]PROMPT is required when not using --benchmark[/red]")
        sys.exit(1)

    if not json_output and not quiet:
        console.print(f"[cyan]Scanning:[/cyan] {prompt}")
        console.print(f"[dim]Model: {model} | Samples: {samples} | Variants: {variants}[/dim]")

    progress_console = Console(stderr=True) if not json_output else None

    with Progress(
        SpinnerColumn(),
        TextColumn("[progress.description]{task.description}"),
        console=progress_console or Console(stderr=True),
        disable=json_output or quiet,
    ) as progress:
        task = progress.add_task("Scanning...", total=None)

        def on_progress(stage: str, detail: str) -> None:
            progress.update(task, description=f"{stage}: {detail[:40]}")

        scanner = Scanner(
            model=model,
            num_samples=samples,
            perturbations=pert_types,
            num_variants=variants,
            on_progress=on_progress,
        )

        try:
            result = scanner.scan(prompt)
        except Exception as e:
            console.print(f"\n[red]Error: {e}[/red]")
            err_lower = str(e).lower()
            if "api_key" in err_lower or "auth" in err_lower:
                console.print(ERR_API_KEY)
            elif "ollama" in err_lower or "connection refused" in err_lower:
                console.print(ERR_OLLAMA_NOT_FOUND)
            elif "model" in err_lower or "not found" in err_lower:
                console.print(ERR_MODEL)
            sys.exit(1)

    if json_output:
        print(result.to_json())
    else:
        _display_scan_result(result, quiet=quiet)
        if not quiet:
            from yuragi.badges import process_badges

            process_badges(result)

    if html:
        from yuragi.visualize.html_report import generate_html_report

        generate_html_report(result, html)
        console.print(f"[green]HTML report saved to {html}[/green]")

    if dashboard:
        from yuragi.visualize.dashboard import generate_dashboard

        generate_dashboard(result, dashboard)
        console.print(f"[green]Dashboard saved to {dashboard}[/green]")

    if plot:
        from yuragi.visualize.heatmap import plot_sensitivity_heatmap

        plot_sensitivity_heatmap(result, save_path=plot)
        console.print(f"[green]Heatmap saved to {plot}[/green]")

    if csv_output:
        _export_scan_csv(result, csv_output)
        console.print(f"[green]CSV exported to {csv_output}[/green]")


@click.command("find-weakness")
@click.argument("prompt")
@click.option("--model", "-m", default=DEFAULT_CONFIG.default_model)
@click.option("--samples", "-n", default=5, type=int)
@click.pass_context
def find_weakness(ctx: click.Context, prompt: str, model: str, samples: int) -> None:
    """Find the single word that, when removed, causes maximum confidence collapse.

    This is yuragi's killer feature: minimal perturbation search.

    Example:
        yuragi find-weakness "Explain quantum computing in simple terms" -m gpt-4o
    """
    quiet = ctx.obj.get("quiet", False) if ctx.obj else False
    _print_logo(quiet)

    console.print(f"[cyan]Finding weakest word in:[/cyan] {prompt}")
    console.print(f"[dim]Model: {model}[/dim]\n")

    scanner = Scanner(
        model=model,
        num_samples=samples,
        perturbations=[Perturbation.OMIT],
        num_variants=0,
    )

    with Progress(
        SpinnerColumn(),
        TextColumn("[progress.description]{task.description}"),
        console=Console(stderr=True),
        disable=quiet,
    ) as progress:
        task = progress.add_task("Scanning all words...", total=None)

        def on_progress(stage: str, detail: str) -> None:
            progress.update(task, description=f"{stage}: {detail[:40]}")

        scanner.on_progress = on_progress
        result = scanner.scan(prompt)

    if not result.perturbation_results:
        console.print("[yellow]No words to test.[/yellow]")
        return

    sorted_results = sorted(
        result.perturbation_results, key=lambda r: r.confidence_delta
    )

    console.print(f"[bold]Baseline confidence:[/bold] {result.baseline.confidence:.2f}\n")

    table = Table(
        title="Word-by-Word Fragility Map",
        box=box.ROUNDED,
        show_lines=False,
    )
    table.add_column("Removed Word", style="bold")
    table.add_column("Confidence", width=35)
    table.add_column("\u0394", width=12)
    table.add_column("Impact")

    for r in sorted_results:
        removed = _find_removed_word(prompt, r.perturbed_prompt)

        delta = r.confidence_delta
        if delta < -0.2:
            impact = Text("CRITICAL", style="bold red")
        elif delta < -0.1:
            impact = Text("fragile", style="red")
        elif abs(delta) < 0.05:
            impact = Text("stable", style="green")
        else:
            impact = Text("boost", style="cyan")

        table.add_row(
            f'"{removed}"' if removed else "?",
            _confidence_bar(r.perturbed_response.confidence),
            _delta_text(delta),
            impact,
        )

    console.print(table)

    weakest = sorted_results[0]
    removed_word = _find_removed_word(prompt, weakest.perturbed_prompt)
    if removed_word and weakest.confidence_delta < -0.1:
        console.print()
        console.print(Rule("[bold red]Weakest Word[/bold red]", style="red"))
        console.print()
        _display_prompt_with_weakness(prompt, removed_word)
        console.print()
        dissoc_note = (
            "[bold magenta]pure dissociation.[/bold magenta]"
            if not weakest.answer_changed
            else "answer drift."
        )
        console.print(
            Panel(
                f'[bold red]"{removed_word}"[/bold red] is this prompt\'s weakest point.\n'
                f"Removing it drops confidence by [bold red]{abs(weakest.confidence_delta):.0%}[/bold red].\n"
                f"Answer {'changed' if weakest.answer_changed else '[green]stayed the same[/green]'} — {dissoc_note}",
                title="[bold]Weakest Word Found[/bold]",
                border_style="red",
            )
        )
    console.print()
