"""demo and export CLI commands."""

from __future__ import annotations

import csv
import json
import sys
from pathlib import Path

import click
from rich import box
from rich.console import Console
from rich.panel import Panel
from rich.rule import Rule
from rich.table import Table
from rich.text import Text

from .helpers import _confidence_bar, _delta_text, _fragility_color, _severity_color

console = Console()


def _print_logo(quiet: bool = False) -> None:
    from yuragi import __version__

    logo = "[bold cyan]yuragi[/bold cyan] [dim]v{version}[/dim]"
    if quiet:
        return
    console.print(logo.format(version=__version__))
    console.print()


def _display_prompt_with_weakness(prompt: str, weak_word: str) -> None:
    """Display prompt with the weakest word highlighted in red/bold, others dimmed."""
    words = prompt.split()
    text = Text()
    for i, word in enumerate(words):
        if i > 0:
            text.append(" ")
        stripped = word.strip(".,!?;:\"'")
        if stripped.lower() == weak_word.lower() or word.lower() == weak_word.lower():
            text.append(word, style="bold red")
        else:
            text.append(word, style="dim")
    console.print(text)


def _export_scan_json_to_csv(data: dict, path: str) -> None:
    with open(path, "w", newline="", encoding="utf-8") as f:
        writer = csv.writer(f)
        writer.writerow([
            "prompt", "model", "perturbation_type", "perturbed_prompt",
            "baseline_confidence", "perturbed_confidence", "delta",
            "answer_changed", "dissociated", "dissociation_severity",
        ])
        baseline = data["baseline_confidence"]
        for p in data["perturbations"]:
            writer.writerow([
                data["prompt"],
                data["model"],
                p["type"],
                p["prompt"],
                f"{baseline:.4f}",
                f"{p['confidence']:.4f}",
                f"{p['delta']:+.4f}",
                p["answer_changed"],
                p["dissociated"],
                f"{p.get('dissociation_severity', 0.0):.4f}",
            ])


def _export_scan_json_to_markdown(data: dict, path: str) -> None:
    lines = [
        f"# Scan: {data['prompt']}",
        "",
        f"**Model:** {data['model']}  ",
        f"**Fragility Score:** {data['fragility_score']:.2f} ({data['fragility_label']})  ",
        f"**Dissociation Rate:** {data['dissociation_rate']:.0%}  ",
        f"**Confidence Range:** {data['confidence_range']:.2f}",
        "",
        "| Type | Perturbed Prompt | Confidence | \u0394 | Dissociated |",
        "|------|-----------------|------------|---|-------------|",
    ]
    for p in sorted(data["perturbations"], key=lambda x: x["delta"]):
        lines.append(
            f"| {p['type']} | {p['prompt'][:60]} | {p['confidence']:.2f} | "
            f"{p['delta']:+.2f} | {'Yes' if p['dissociated'] else 'No'} |"
        )
    Path(path).write_text("\n".join(lines) + "\n", encoding="utf-8")


def _export_experiment_json_to_csv(data: dict, path: str) -> None:
    with open(path, "w", newline="", encoding="utf-8") as f:
        writer = csv.writer(f)
        writer.writerow([
            "experiment", "model", "control", "treatment",
            "control_confidence", "treatment_confidence", "delta",
            "answer_changed", "dissociated",
        ])
        for r in data["results"]:
            writer.writerow([
                data["experiment"],
                data["model"],
                r["control"],
                r["treatment"],
                f"{r['control_confidence']:.4f}",
                f"{r['treatment_confidence']:.4f}",
                f"{r['delta']:+.4f}",
                r["answer_changed"],
                r["dissociated"],
            ])


def _export_experiment_json_to_markdown(data: dict, path: str) -> None:
    lines = [
        f"# Experiment: {data['experiment']}",
        "",
        f"**Model:** {data['model']}  ",
        f"**Avg \u0394:** {data['avg_delta']:+.2f} | **Max |\u0394|:** {data['max_delta']:.2f} | "
        f"**Confidence Dissociation:** {data['dissociation_rate']:.0%} | "
        f"**Effect:** {'CONFIRMED' if data['effect_confirmed'] else 'NOT CONFIRMED'}",
        "",
        "| Control | Treatment | Ctrl Conf | Treat Conf | \u0394 | Dissociated |",
        "|---------|-----------|-----------|------------|---|-------------|",
    ]
    for r in data["results"]:
        lines.append(
            f"| {r['control'][:50]} | {r['treatment'][:50]} | "
            f"{r['control_confidence']:.2f} | {r['treatment_confidence']:.2f} | "
            f"{r['delta']:+.2f} | {'Yes' if r['dissociated'] else 'No'} |"
        )
    Path(path).write_text("\n".join(lines) + "\n", encoding="utf-8")


@click.command()
@click.pass_context
def demo(ctx: click.Context) -> None:
    """Run a pre-computed demo (no API key needed).

    Shows what yuragi output looks like using cached results from docs/demo_data.json.

    Example:
        yuragi demo
    """
    quiet = ctx.obj.get("quiet", False) if ctx.obj else False
    _print_logo(quiet)

    demo_path = Path(__file__).parent.parent.parent.parent.parent / "docs" / "demo_data.json"
    if not demo_path.exists():
        demo_path = Path("docs/demo_data.json")
    if not demo_path.exists():
        console.print(
            "[red]demo_data.json not found.[/red]\n"
            "[dim]Expected at docs/demo_data.json relative to project root.[/dim]"
        )
        sys.exit(1)

    data = json.loads(demo_path.read_text(encoding="utf-8"))
    scan_data = data["scan"]
    exp_data = data["experiment"]
    fw_data = data["find_weakness"]

    # ── SCAN DEMO ──────────────────────────────────────────────────────────
    console.print(Rule("[bold cyan]Demo: scan[/bold cyan]", style="cyan"))
    console.print()
    console.print(
        Panel(
            f"[bold]yuragi[/bold] confidence fragility scan  [dim](pre-computed)[/dim]\n"
            f"[dim]Model: {scan_data['model']} | "
            f"Method: {scan_data['confidence_method']} | "
            f"Duration: {scan_data['scan_duration_seconds']:.1f}s | "
            f"API calls: {scan_data['total_api_calls']}[/dim]",
            title="[bold cyan]\u63fa\u3089\u304e[/bold cyan]",
            border_style="cyan",
        )
    )
    console.print(f"\n[bold]Original:[/bold] {scan_data['prompt']}")
    console.print(
        Text.assemble("Confidence: ", _confidence_bar(scan_data["baseline_confidence"]))
    )
    console.print()

    table = Table(
        title="Perturbation Results",
        box=box.ROUNDED,
        show_lines=True,
        title_style="bold",
    )
    table.add_column("Type", style="cyan", width=12)
    table.add_column("Mutation", max_width=55)
    table.add_column("Confidence", width=35)
    table.add_column("\u0394", width=12)
    table.add_column("Severity", width=10)
    table.add_column("Answer", width=8)

    for p in sorted(scan_data["perturbations"], key=lambda x: x["delta"]):
        sev = p.get("dissociation_severity", 0.0)
        sev_style = _severity_color(sev)
        severity_cell = Text(f"{sev:.2f}", style=sev_style) if sev > 0 else Text("\u2014", style="dim")
        answer_cell = (
            Text("same", style="green") if not p["answer_changed"]
            else Text("CHANGED", style="bold red")
        )
        delta = _delta_text(p["delta"])
        if p.get("dissociated"):
            delta.append(" [!]", style="bold magenta")
        table.add_row(
            p["type"],
            p["prompt"][:55],
            _confidence_bar(p["confidence"]),
            delta,
            severity_cell,
            answer_cell,
        )
    console.print(table)

    fp = scan_data["fragility_profile"]
    fragility = scan_data["fragility_score"]
    frag_style = _fragility_color(fragility)
    cci_c = "red" if fp["catastrophic_collapse_index"] > 0.5 else "yellow"
    re_c = "red" if fp["recovery_elasticity"] < 0.3 else "yellow"
    nl_c = "red" if fp["non_linearity_score"] > 0.6 else "yellow"
    console.print(
        Panel(
            f"Fragility Score: [{frag_style}]{fragility:.2f} ({scan_data['fragility_label']})[/{frag_style}]\n"
            f"Confidence Range: {scan_data['confidence_range']:.2f}\n"
            f"Dissociation Rate: {scan_data['dissociation_rate']:.0%}\n"
            f"\n[bold]Fragility Profile[/bold]  [{cci_c}]CCI {fp['catastrophic_collapse_index']:.2f}[/{cci_c}]"
            f"  [{re_c}]RE {fp['recovery_elasticity']:.2f}[/{re_c}]"
            f"  [{nl_c}]NLS {fp['non_linearity_score']:.2f}[/{nl_c}]"
            f"  [dim]({fp['profile_label']})[/dim]",
            title="[bold]Summary[/bold]",
            border_style="cyan",
        )
    )
    console.print(
        Panel(
            f"{scan_data['dissociation_rate']:.0%} of perturbations shifted confidence "
            "without changing the answer. "
            "The model's stated confidence responds more to [italic]phrasing[/italic] than to factual accuracy \u2014 "
            "a textbook case of [bold magenta]dissociation[/bold magenta].",
            title="[bold yellow]\u2728 Key Insight[/bold yellow]",
            border_style="yellow",
        )
    )

    # ── FIND-WEAKNESS DEMO ─────────────────────────────────────────────────
    console.print()
    console.print(Rule("[bold cyan]Demo: find-weakness[/bold cyan]", style="cyan"))
    console.print()
    console.print(f"[bold]Prompt:[/bold] {fw_data['prompt']}")
    console.print(f"[bold]Baseline confidence:[/bold] {fw_data['baseline_confidence']:.2f}\n")

    fw_table = Table(box=box.ROUNDED, show_lines=False, title="Word-by-Word Fragility")
    fw_table.add_column("Removed Word", style="bold")
    fw_table.add_column("Confidence", width=35)
    fw_table.add_column("\u0394", width=12)
    fw_table.add_column("Impact")
    for w in fw_data["words"]:
        delta = w["delta"]
        if delta < -0.2:
            impact = Text("CRITICAL", style="bold red")
        elif delta < -0.1:
            impact = Text("fragile", style="red")
        elif abs(delta) < 0.05:
            impact = Text("stable", style="green")
        else:
            impact = Text("boost", style="cyan")
        fw_table.add_row(
            f'"{w["word"]}"',
            _confidence_bar(w["confidence"]),
            _delta_text(delta),
            impact,
        )
    console.print(fw_table)
    console.print()
    _display_prompt_with_weakness(fw_data["prompt"], fw_data["weakest_word"])
    console.print()
    console.print(
        Panel(
            f'[bold red]"{fw_data["weakest_word"]}"[/bold red] is this prompt\'s weakest point.\n'
            f"Removing it drops confidence by [bold red]{abs(fw_data['weakest_delta']):.0%}[/bold red] "
            f"\u2014 [bold magenta]pure dissociation.[/bold magenta]",
            title="[bold]Weakest Word Found[/bold]",
            border_style="red",
        )
    )

    # ── EXPERIMENT DEMO ────────────────────────────────────────────────────
    console.print()
    console.print(Rule("[bold cyan]Demo: experiment[/bold cyan]", style="cyan"))
    console.print()
    for i, r in enumerate(exp_data["results"], 1):
        ctrl_bar = _confidence_bar(r["control_confidence"], width=10)
        treat_bar = _confidence_bar(r["treatment_confidence"], width=10)
        delta = r["delta"]

        console.print(
            Text.assemble(
                f"  [{i}] Control:   ",
                Text(f'"{r["control"]}"', style="white"),
                " \u2192 Confidence ",
                ctrl_bar,
            )
        )
        console.print(
            Text.assemble(
                "      Treatment: ",
                Text(f'"{r["treatment"]}"', style="white"),
                " \u2192 Confidence ",
                treat_bar,
            )
        )
        if abs(delta) >= 0.15:
            direction = "collapsed" if delta < 0 else "boosted"
            prefix = "\u26a1" if delta < 0 else "\u2b06"
            effect_style = "bold red" if delta < 0 else "bold green"
            console.print(
                f"      [{effect_style}]{prefix} Social pressure {direction} confidence by {abs(delta):.0%}[/{effect_style}]"
            )
        else:
            console.print(f"      [dim]\u2192 No significant effect ({delta:+.2f})[/dim]")
        console.print()

    confirmed_style = "green" if exp_data["effect_confirmed"] else "yellow"
    console.print(
        Panel(
            f"Avg \u0394: {exp_data['avg_delta']:+.2f}\n"
            f"Confidence Dissociation: {exp_data['dissociation_rate']:.0%}\n"
            f"\n[bold {confirmed_style}]Effect {'CONFIRMED' if exp_data['effect_confirmed'] else 'NOT CONFIRMED'}[/bold {confirmed_style}]",
            title="[bold]Experiment Summary[/bold]",
            border_style=confirmed_style,
        )
    )

    console.print()
    console.print(
        Panel(
            "[bold cyan]Run yuragi with your own API key to test real models.[/bold cyan]\n"
            "[dim]  yuragi scan 'your question' -m gpt-4o[/dim]\n"
            "[dim]  yuragi experiment asch -m ollama/llama3.2[/dim]\n"
            "[dim]  yuragi find-weakness 'your prompt' -m gpt-4o-mini[/dim]",
            title="[bold]Try It Yourself[/bold]",
            border_style="bright_cyan",
        )
    )
    console.print()


@click.command()
@click.argument("source", type=click.Choice(["scan", "experiment"]))
@click.option("--input", "-i", "input_file", required=True, help="Input JSON file (from --json-output)")
@click.option("--output", "-o", required=True, help="Output file path (.csv or .md)")
@click.option("--format", "-f", "fmt", type=click.Choice(["csv", "markdown"]), default="csv")
@click.pass_context
def export(ctx: click.Context, source, input_file, output, fmt):
    """Export scan or experiment results to CSV or Markdown.

    Examples:
        yuragi scan "..." --json-output > result.json
        yuragi export scan -i result.json -o result.csv
        yuragi export experiment -i exp.json -o report.md -f markdown
    """
    quiet = ctx.obj.get("quiet", False) if ctx.obj else False
    _print_logo(quiet)

    try:
        data = json.loads(Path(input_file).read_text(encoding="utf-8"))
    except FileNotFoundError:
        console.print(f"[red]File not found: {input_file}[/red]")
        sys.exit(1)
    except json.JSONDecodeError as e:
        console.print(f"[red]Invalid JSON: {e}[/red]")
        sys.exit(1)

    if source == "scan":
        if fmt == "csv":
            _export_scan_json_to_csv(data, output)
            console.print(f"[green]CSV exported to {output}[/green]")
        else:
            _export_scan_json_to_markdown(data, output)
            console.print(f"[green]Markdown exported to {output}[/green]")
    else:
        if fmt == "markdown":
            _export_experiment_json_to_markdown(data, output)
            console.print(f"[green]Markdown exported to {output}[/green]")
        else:
            _export_experiment_json_to_csv(data, output)
            console.print(f"[green]CSV exported to {output}[/green]")
