"""compare CLI command."""

from __future__ import annotations

import json
import sys

import click
from rich import box
from rich.console import Console
from rich.table import Table
from rich.text import Text

from yuragi.core import Scanner

from .helpers import _confidence_bar, _fragility_color

console = Console()


def _print_logo(quiet: bool = False) -> None:
    from yuragi import __version__

    logo = "[bold cyan]yuragi[/bold cyan] [dim]v{version}[/dim]"
    if quiet:
        return
    console.print(logo.format(version=__version__))
    console.print()


@click.command()
@click.argument("prompt")
@click.option(
    "--models", "-m",
    required=True,
    help="Comma-separated model list (e.g., ollama/llama3.2,groq/llama-3.1-8b-instant)",
)
@click.option("--samples", "-n", default=3, type=int)
@click.option("--json-output", "-j", is_flag=True)
@click.pass_context
def compare(ctx: click.Context, prompt: str, models: list[str], samples: int, json_output: bool) -> None:
    """Compare confidence fragility across multiple models.

    Example:
        yuragi compare "Is AI dangerous?" -m ollama/llama3.2,groq/llama-3.1-8b-instant
    """
    quiet = ctx.obj.get("quiet", False) if ctx.obj else False
    if not json_output and not quiet:
        _print_logo(quiet)

    model_list = [m.strip() for m in models.split(",")]

    if not json_output and not quiet:
        console.print(f"[cyan]Comparing {len(model_list)} models on:[/cyan] {prompt}")

    results = {}
    for model_name in model_list:
        if not json_output and not quiet:
            console.print(f"\n[dim]Scanning {model_name}...[/dim]")

        scanner = Scanner(
            model=model_name,
            num_samples=samples,
            num_variants=2,
        )
        try:
            result = scanner.scan(prompt)
            results[model_name] = result
        except Exception as e:
            console.print(f"[red]{model_name}: {e}[/red]")
            continue

    if not results:
        console.print("[red]No models succeeded.[/red]")
        sys.exit(1)

    if json_output:
        output = {
            "prompt": prompt,
            "models": {
                name: {
                    "fragility_score": r.fragility_score,
                    "fragility_label": r.fragility_label(),
                    "confidence_range": r.confidence_range,
                    "dissociation_rate": r.dissociation_rate,
                    "baseline_confidence": r.baseline.confidence,
                    "max_drop": r.max_confidence_drop,
                }
                for name, r in results.items()
            },
        }
        print(json.dumps(output, indent=2, ensure_ascii=False))
        return

    table = Table(
        title=f'Model Comparison: "{prompt[:50]}..."',
        box=box.ROUNDED,
    )
    table.add_column("Model", style="cyan")
    table.add_column("Fragility", width=20)
    table.add_column("Baseline Conf", width=15)
    table.add_column("Conf Range", width=12)
    table.add_column("Dissociation", width=14)
    table.add_column("Max Drop", width=10)

    for name, r in sorted(results.items(), key=lambda x: x[1].fragility_score, reverse=True):
        frag_style = _fragility_color(r.fragility_score)
        table.add_row(
            name,
            Text(f"{r.fragility_score:.2f} ({r.fragility_label()})", style=frag_style),
            _confidence_bar(r.baseline.confidence, width=10),
            f"{r.confidence_range:.2f}",
            f"{r.dissociation_rate:.0%}",
            f"{r.max_confidence_drop:+.2f}",
        )

    console.print(table)

    most_fragile = max(results.items(), key=lambda x: x[1].fragility_score)
    most_stable = min(results.items(), key=lambda x: x[1].fragility_score)

    console.print(
        f"\n[red]Most fragile:[/red] {most_fragile[0]} "
        f"(fragility: {most_fragile[1].fragility_score:.2f})"
    )
    console.print(
        f"[green]Most stable:[/green] {most_stable[0]} "
        f"(fragility: {most_stable[1].fragility_score:.2f})"
    )
    console.print()
