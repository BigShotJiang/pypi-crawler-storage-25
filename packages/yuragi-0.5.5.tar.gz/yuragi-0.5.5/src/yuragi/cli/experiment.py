"""experiment CLI command."""

from __future__ import annotations

import json
import sys
from pathlib import Path

import click
from rich import box
from rich.console import Console
from rich.panel import Panel
from rich.progress import Progress, SpinnerColumn, TextColumn
from rich.rule import Rule
from rich.table import Table
from rich.text import Text

from yuragi.config import DEFAULT_CONFIG

from .helpers import ERR_API_KEY, ERR_MODEL, _confidence_bar, _delta_text

console = Console()


def _print_logo(quiet: bool = False) -> None:
    from yuragi import __version__

    logo = "[bold cyan]yuragi[/bold cyan] [dim]v{version}[/dim]"
    if quiet:
        return
    console.print(logo.format(version=__version__))
    console.print()


def _export_experiment_markdown(result, spec, path: str) -> None:
    """Export experiment results as a Markdown table."""
    lines = [
        f"# Experiment: {spec.name}",
        "",
        f"**Description:** {spec.description}  ",
        f"**Hypothesis:** {spec.hypothesis}  ",
        f"**Model:** {result.model}  ",
        "",
        f"**Avg \u0394:** {result.avg_delta:+.2f} | **Max |\u0394|:** {result.max_delta:.2f} | "
        f"**Confidence Dissociation:** {result.dissociation_rate:.0%} | "
        f"**Effect:** {'CONFIRMED' if result.effect_confirmed else 'NOT CONFIRMED'}",
        "",
        "| Control | Treatment | Ctrl Conf | Treat Conf | \u0394 | Dissociated |",
        "|---------|-----------|-----------|------------|---|-------------|",
    ]
    for r in result.results:
        lines.append(
            f"| {r.control_prompt[:50]} | {r.treatment_prompt[:50]} | "
            f"{r.control_confidence:.2f} | {r.treatment_confidence:.2f} | "
            f"{r.confidence_delta:+.2f} | {'Yes' if r.is_dissociated else 'No'} |"
        )
    Path(path).write_text("\n".join(lines) + "\n", encoding="utf-8")


@click.command()
@click.argument("experiment_name")
@click.option("--model", "-m", default=DEFAULT_CONFIG.default_model)
@click.option("--samples", "-n", default=5, type=int)
@click.option("--json-output", "-j", is_flag=True)
@click.option("--markdown", type=str, default=None, help="Export results as Markdown table to file")
@click.pass_context
def experiment(ctx: click.Context, experiment_name: str, model: str, samples: int, json_output: bool, markdown: str | None) -> None:
    """Run a psychology experiment on a model.

    Available experiments: asch, impostor, authority, anchoring, gaslighting,
    framing, dissonance, halo, primacy, dunning_kruger, test_time_compute

    Example:
        yuragi experiment asch -m ollama/llama3.2
        yuragi experiment dunning_kruger -m ollama/llama3.2
        yuragi experiment test_time_compute -m ollama/llama3.2
    """
    from yuragi.experiments.registry import get_experiment, list_experiments
    from yuragi.experiments.runner import run_experiment

    quiet = ctx.obj.get("quiet", False) if ctx.obj else False
    if not json_output and not quiet:
        _print_logo(quiet)

    if experiment_name == "list":
        from yuragi.experiments.registry import _EXPERIMENTS

        table = Table(title="Available Experiments", box=box.ROUNDED)
        table.add_column("Name", style="cyan")
        table.add_column("Description")
        table.add_column("Human Parallel", style="dim")
        for name, spec in _EXPERIMENTS.items():
            table.add_row(name, spec.description, spec.human_parallel[:60] + "...")
        console.print(table)
        return

    try:
        spec = get_experiment(experiment_name)
    except ValueError as e:
        console.print(f"[red]{e}[/red]")
        console.print(f"[dim]Available: {', '.join(list_experiments())}[/dim]")
        console.print("[dim]Use 'yuragi experiment list' to see all experiments[/dim]")
        sys.exit(1)

    if not json_output and not quiet:
        console.print(
            Panel(
                f"[bold]{spec.description}[/bold]\n"
                f"[dim]Hypothesis: {spec.hypothesis}[/dim]\n"
                f"[dim]Human parallel: {spec.human_parallel}[/dim]",
                title=f"[bold cyan]Experiment: {spec.name}[/bold cyan]",
                border_style="cyan",
            )
        )

    with Progress(
        SpinnerColumn(),
        TextColumn("[progress.description]{task.description}"),
        console=Console(stderr=True),
        disable=json_output or quiet,
    ) as progress:
        task = progress.add_task("Running experiment...", total=None)

        def on_progress(idx: int, total: int, phase: str) -> None:
            progress.update(
                task,
                description=f"Pair {idx + 1}/{total} ({phase})",
            )

        try:
            result = run_experiment(
                spec, model, num_samples=samples, on_progress=on_progress
            )
        except Exception as e:
            console.print(f"\n[red]Error: {e}[/red]")
            if "api_key" in str(e).lower() or "auth" in str(e).lower():
                console.print(ERR_API_KEY)
            elif "model" in str(e).lower() or "not found" in str(e).lower():
                console.print(ERR_MODEL)
            sys.exit(1)

    if json_output:
        output = {
            "experiment": spec.name,
            "model": model,
            "hypothesis": spec.hypothesis,
            "avg_delta": result.avg_delta,
            "max_delta": result.max_delta,
            "dissociation_rate": result.dissociation_rate,
            "effect_confirmed": result.effect_confirmed,
            "results": [
                {
                    "control": r.control_prompt,
                    "treatment": r.treatment_prompt,
                    "control_confidence": r.control_confidence,
                    "treatment_confidence": r.treatment_confidence,
                    "delta": r.confidence_delta,
                    "answer_changed": r.answer_changed,
                    "dissociated": r.is_dissociated,
                }
                for r in result.results
            ],
        }
        print(json.dumps(output, indent=2, ensure_ascii=False))
        return

    console.print(Rule("[bold cyan]Experiment Story[/bold cyan]", style="cyan"))
    console.print()
    for i, r in enumerate(result.results, 1):
        ctrl_bar = _confidence_bar(r.control_confidence, width=10)
        treat_bar = _confidence_bar(r.treatment_confidence, width=10)
        delta = r.confidence_delta

        console.print(
            Text.assemble(
                f"  [{i}] Control:   ",
                Text(f'"{r.control_prompt[:60]}"', style="white"),
                " \u2192 Confidence ",
                ctrl_bar,
            )
        )
        console.print(
            Text.assemble(
                "      Treatment: ",
                Text(f'"{r.treatment_prompt[:60]}"', style="white"),
                " \u2192 Confidence ",
                treat_bar,
            )
        )

        if abs(delta) >= 0.15:
            direction = "collapsed" if delta < 0 else "boosted"
            pct = abs(delta)
            effect_style = "bold red" if delta < 0 else "bold green"
            prefix = "\u26a1" if delta < 0 else "\u2b06"
            console.print(
                f"      [{effect_style}]{prefix} Social pressure {direction} confidence by {pct:.0%}[/{effect_style}]"
            )
        else:
            console.print(f"      [dim]\u2192 No significant effect ({delta:+.2f})[/dim]")
        console.print()

    table = Table(box=box.ROUNDED, show_lines=True, title="Results Summary")
    table.add_column("Control", max_width=35)
    table.add_column("Treatment", max_width=35)
    table.add_column("Ctrl Conf", width=12)
    table.add_column("Treat Conf", width=12)
    table.add_column("\u0394", width=10)
    table.add_column("Answer", width=8)

    for r in result.results:
        delta = _delta_text(r.confidence_delta)
        if r.is_dissociated:
            delta.append(" [!]", style="bold magenta")

        answer_status = (
            Text("same", style="green")
            if not r.answer_changed
            else Text("CHANGED", style="bold red")
        )

        table.add_row(
            r.control_prompt[:35],
            r.treatment_prompt[:35],
            _confidence_bar(r.control_confidence, width=8),
            _confidence_bar(r.treatment_confidence, width=8),
            delta,
            answer_status,
        )

    console.print(table)

    verdict_style = "green" if result.effect_confirmed else "yellow"
    console.print(
        Panel(
            f"Avg \u0394: {result.avg_delta:+.2f}\n"
            f"Max |\u0394|: {result.max_delta:.2f}\n"
            f"Confidence Dissociation: {result.dissociation_rate:.0%}\n"
            f"\n[bold {verdict_style}]Effect {'CONFIRMED' if result.effect_confirmed else 'NOT CONFIRMED'}[/bold {verdict_style}]",
            title="[bold]Experiment Results[/bold]",
            border_style=verdict_style,
        )
    )

    if markdown:
        _export_experiment_markdown(result, spec, markdown)
        console.print(f"[green]Markdown exported to {markdown}[/green]")
