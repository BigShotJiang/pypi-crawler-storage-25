"""yuragi — LLM Confidence Fragility Analyzer.

Measure how fragile your AI's confidence really is.
One word can change AI confidence by 75%, without changing the answer.

Quick start (fluent API)::

    import yuragi

    result = (
        yuragi.scan("Is AI dangerous?")
        .model("ollama/llama3.2")
        .samples(5)
        .perturbations("tone", "omit")
        .run()
    )
    print(result.fragility_score)

One-liner convenience functions::

    result    = yuragi.scan("Is AI dangerous?", model="ollama/llama3.2")
    score     = yuragi.fragility_score("Is AI dangerous?", model="ollama/llama3.2")
    weakness  = yuragi.find_weakness("Is AI dangerous?", model="ollama/llama3.2")

Session (shared cache)::

    with yuragi.session(model="ollama/llama3.2") as s:
        r1 = s.scan("prompt 1")
        r2 = s.scan("prompt 2")

Classic API (still supported)::

    from yuragi import Scanner
    scanner = Scanner(model="ollama/llama3.2")
    result = scanner.scan("Is quantum computing practical?")
    print(result.fragility_score)  # 0.0 (steel) to 1.0 (glass)

CLI::

    pip install yuragi
    yuragi scan "Your prompt" --model ollama/llama3.2

See https://github.com/hinanohart/yuragi for full documentation.
"""

from __future__ import annotations

import logging
from typing import TYPE_CHECKING

__version__ = "0.5.2"

logging.getLogger("yuragi").addHandler(logging.NullHandler())

from yuragi.config import DEFAULT_CONFIG, YuragiConfig
from yuragi.core import PerturbationResult, Scanner, ScannerBuilder, ScanResult, Session
from yuragi.exceptions import (
    APIKeyMissingError,
    CacheError,
    ExperimentError,
    ModelNotFoundError,
    ScanError,
    YuragiError,
)
from yuragi.perturbations import Perturbation
from yuragi.providers.adapter import CompletionResult, LLMAdapter, ModelCapabilities

if TYPE_CHECKING:
    pass


def scan(prompt: str, model: str = DEFAULT_CONFIG.default_model, **kwargs) -> ScanResult | ScannerBuilder:
    """Scan a prompt for confidence fragility.

    When called with only ``prompt`` (and optionally ``model``), returns a
    :class:`ScannerBuilder` so you can chain further options before calling
    ``.run()``.  When additional scanner kwargs are provided (e.g.
    ``num_samples``) the scan is executed immediately and the
    :class:`ScanResult` is returned.

    Examples::

        # Fluent — configure then run
        result = yuragi.scan("Is AI safe?").model("ollama/llama3.2").samples(3).run()

        # One-liner — run immediately
        result = yuragi.scan("Is AI safe?", model="ollama/llama3.2")
    """
    if kwargs:
        with Scanner(model=model, **kwargs) as scanner:
            return scanner.scan(prompt)
    return ScannerBuilder(prompt).model(model)


def fragility_score(prompt: str, model: str = DEFAULT_CONFIG.default_model, **kwargs) -> float:
    """Return the fragility score (0.0-1.0) for a prompt.

    Convenience wrapper around :func:`scan`.  Higher = more fragile.
    """
    with Scanner(model=model, **kwargs) as s:
        return s.scan(prompt).fragility_score


def find_weakness(prompt: str, model: str = DEFAULT_CONFIG.default_model, **kwargs) -> PerturbationResult | None:
    """Return the perturbation that caused the biggest confidence drop.

    Returns ``None`` when no perturbations were run.
    """
    with Scanner(model=model, **kwargs) as s:
        return s.scan(prompt).weakest_perturbation


def session(**kwargs) -> Session:
    """Create a :class:`Session` context manager with shared cache.

    Example::

        with yuragi.session(model="ollama/llama3.2") as s:
            r1 = s.scan("prompt 1")
            r2 = s.scan("prompt 2")
    """
    return Session(**kwargs)


__all__ = [
    "DEFAULT_CONFIG",
    "APIKeyMissingError",
    "CacheError",
    "CompletionResult",
    "ExperimentError",
    "LLMAdapter",
    "ModelCapabilities",
    "ModelNotFoundError",
    "Perturbation",
    "PerturbationResult",
    "ScanError",
    "ScanResult",
    "Scanner",
    "ScannerBuilder",
    "Session",
    "YuragiConfig",
    "YuragiError",
    "__version__",
    "find_weakness",
    "fragility_score",
    "scan",
    "session",
]
