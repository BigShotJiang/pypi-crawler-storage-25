"""Public benchmark dataset loaders.

Loads TruthfulQA, SimpleQA, HaluEval as standardized question dicts
for use with yuragi's fragility scanner.

Datasets are NOT bundled. Loaders fetch from Hugging Face datasets
on first use, with optional caching to ~/.cache/yuragi/benchmarks/.
"""

from __future__ import annotations

from collections.abc import Iterator

_BENCHMARKS = ("truthfulqa", "simpleqa", "halueval", "triviaqa", "nq_open")

# Default Hugging Face dataset revision SHAs (2026-05-09 audit pin).
#
# Pinning supply-chain origins to immutable commit SHAs blocks the case
# where the upstream dataset author silently rewrites the dataset to
# include malicious labels, prompt-injection payloads, or contaminated
# splits between two of our experimental runs. ``trust_remote_code=False``
# already prevents arbitrary code from the dataset card running locally,
# but content drift is a separate axis.
#
# Override per-call by passing ``revision="..."`` (or ``None`` to track
# the dataset's default branch — discouraged for reproducible benchmarks).
_HF_DATASET_REVISIONS: dict[str, str] = {
    "truthful_qa": "741b8276f2d1982aa3d5b832d3ee81ed3b896490",
    "basicv8vc/SimpleQA": "e319282ab125c3dbd0c7fd00be2e4dd54e7e8f94",
    "pminervini/HaluEval": "12a856119f03975a94509091e8cada3e6be6ead7",
    "trivia_qa": "0f7faf33a3908546c6fd5b73a660e0f8ff173c2f",
    "nq_open": "5dd9790a83002ad084ddeb7c420dc716852c6f28",
}


def _require_datasets():
    try:
        from datasets import load_dataset

        return load_dataset
    except ImportError as err:
        raise ImportError(
            "benchmarks extras required: pip install yuragi[benchmarks]"
        ) from err


# Sentinel: caller did not pass an explicit revision -> use the audit default.
# Distinct from ``None`` (caller wants to track the upstream default branch).
_USE_DEFAULT_REVISION = object()


def load_truthfulqa(
    *,
    split: str = "validation",
    limit: int | None = None,
    revision: str | None = _USE_DEFAULT_REVISION,  # type: ignore[assignment]
) -> list[dict]:
    """Load TruthfulQA. Returns [{"question": str, "answers": list[str]}, ...].

    ``revision`` defaults to a pinned dataset commit SHA captured during the
    2026-05-09 supply-chain audit (see ``_HF_DATASET_REVISIONS``). Pass an
    explicit SHA / ref name to override, or ``None`` to disable pinning and
    track the dataset's default branch.
    """
    load_dataset = _require_datasets()
    if revision is _USE_DEFAULT_REVISION:
        revision = _HF_DATASET_REVISIONS["truthful_qa"]
    ds = load_dataset(
        "truthful_qa",
        "generation",
        split=split,
        trust_remote_code=False,
        revision=revision,
    )
    rows = []
    for i, item in enumerate(ds):
        if limit is not None and i >= limit:
            break
        rows.append(
            {
                "question": item["question"],
                "answers": item.get("correct_answers", []) or [],
                "source": "truthfulqa",
            }
        )
    return rows


def load_simpleqa(
    *,
    limit: int | None = None,
    dataset_id: str = "basicv8vc/SimpleQA",
    revision: str | None = _USE_DEFAULT_REVISION,  # type: ignore[assignment]
) -> list[dict]:
    """Load SimpleQA. Returns [{"question": str, "answers": list[str]}, ...].

    The ``dataset_id`` parameter is exposed because the canonical SimpleQA
    repository has moved between mirrors on Hugging Face. The default points
    at ``basicv8vc/SimpleQA`` (community mirror of the OpenAI release); pass
    an alternative repo id if you prefer a different host.

    ``revision`` defaults to a pinned commit SHA for the default
    ``basicv8vc/SimpleQA`` mirror; passing a non-default ``dataset_id``
    automatically falls back to ``revision=None`` (track upstream default
    branch) unless you also pass a matching SHA.
    """
    load_dataset = _require_datasets()
    if revision is _USE_DEFAULT_REVISION:
        revision = _HF_DATASET_REVISIONS.get(dataset_id)  # may be None
    ds = load_dataset(
        dataset_id, split="test", trust_remote_code=False, revision=revision
    )
    rows = []
    for i, item in enumerate(ds):
        if limit is not None and i >= limit:
            break
        answer = item.get("answer", "") or item.get("correct_answer", "")
        question = item.get("problem") or item.get("question") or ""
        rows.append(
            {
                "question": question,
                "answers": [answer] if answer else [],
                "source": "simpleqa",
            }
        )
    return rows


def load_halueval(
    *,
    task: str = "qa",
    limit: int | None = None,
    revision: str | None = _USE_DEFAULT_REVISION,  # type: ignore[assignment]
) -> list[dict]:
    """Load HaluEval. Returns [{"question": str, "answers": list[str]}, ...].

    ``revision`` defaults to a pinned dataset commit SHA captured during the
    2026-05-09 supply-chain audit. Pass an explicit SHA / ref to override or
    ``None`` to track the dataset's default branch.
    """
    load_dataset = _require_datasets()
    if revision is _USE_DEFAULT_REVISION:
        revision = _HF_DATASET_REVISIONS["pminervini/HaluEval"]
    ds = load_dataset(
        "pminervini/HaluEval",
        task,
        split="data",
        trust_remote_code=False,
        revision=revision,
    )
    rows = []
    for i, item in enumerate(ds):
        if limit is not None and i >= limit:
            break
        question = item.get("question") or item.get("input") or ""
        answer = item.get("right_answer") or item.get("answer") or ""
        rows.append(
            {
                "question": question,
                "answers": [answer] if answer else [],
                "source": "halueval",
                "task": task,
            }
        )
    return rows


def load_triviaqa(
    *,
    split: str = "validation",
    subset: str = "rc.nocontext",
    limit: int | None = None,
    revision: str | None = _USE_DEFAULT_REVISION,  # type: ignore[assignment]
) -> list[dict]:
    """Load TriviaQA (reading-comprehension, no context).

    Returns [{"question": str, "answers": list[str]}, ...] where ``answers``
    contains the canonical value plus any aliases recognised by the dataset.
    The ``rc.nocontext`` subset is the lightest: just questions and answers,
    no evidence passages. Use ``subset='rc'`` to include Wikipedia/Web context.

    ``revision`` defaults to a pinned dataset commit SHA captured during the
    2026-05-09 supply-chain audit. Pass an explicit SHA / ref to override or
    ``None`` to track the dataset's default branch.
    """
    load_dataset = _require_datasets()
    if revision is _USE_DEFAULT_REVISION:
        revision = _HF_DATASET_REVISIONS["trivia_qa"]
    ds = load_dataset(
        "trivia_qa",
        subset,
        split=split,
        trust_remote_code=False,
        revision=revision,
    )
    rows = []
    for i, item in enumerate(ds):
        if limit is not None and i >= limit:
            break
        ans = item.get("answer") or {}
        value = ans.get("value", "") or ""
        aliases = list(ans.get("aliases") or [])
        answers = [value] + [a for a in aliases if a and a != value]
        rows.append(
            {
                "question": item.get("question", ""),
                "answers": answers,
                "source": "triviaqa",
            }
        )
    return rows


def load_nq_open(
    *,
    split: str = "validation",
    limit: int | None = None,
    revision: str | None = _USE_DEFAULT_REVISION,  # type: ignore[assignment]
) -> list[dict]:
    """Load Natural Questions (open). Short factoid questions with list of
    acceptable answer strings.

    Returns [{"question": str, "answers": list[str]}, ...].

    ``revision`` defaults to a pinned dataset commit SHA captured during the
    2026-05-09 supply-chain audit. Pass an explicit SHA / ref to override or
    ``None`` to track the dataset's default branch.
    """
    load_dataset = _require_datasets()
    if revision is _USE_DEFAULT_REVISION:
        revision = _HF_DATASET_REVISIONS["nq_open"]
    ds = load_dataset(
        "nq_open", split=split, trust_remote_code=False, revision=revision
    )
    rows = []
    for i, item in enumerate(ds):
        if limit is not None and i >= limit:
            break
        answers = list(item.get("answer") or [])
        rows.append(
            {
                "question": item.get("question", ""),
                "answers": answers,
                "source": "nq_open",
            }
        )
    return rows


def yield_questions(benchmark: str, **kwargs) -> Iterator[dict]:
    """Generic dispatcher.

    benchmark in {'truthfulqa', 'simpleqa', 'halueval', 'triviaqa', 'nq_open'}.
    """
    if benchmark == "truthfulqa":
        yield from load_truthfulqa(**kwargs)
    elif benchmark == "simpleqa":
        yield from load_simpleqa(**kwargs)
    elif benchmark == "halueval":
        yield from load_halueval(**kwargs)
    elif benchmark == "triviaqa":
        yield from load_triviaqa(**kwargs)
    elif benchmark == "nq_open":
        yield from load_nq_open(**kwargs)
    else:
        raise ValueError(
            f"Unknown benchmark: {benchmark!r}. Available: {', '.join(_BENCHMARKS)}"
        )
