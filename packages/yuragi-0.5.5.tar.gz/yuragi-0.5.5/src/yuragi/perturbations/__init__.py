"""Prompt perturbation generators.

Thirteen mutation types that test different aspects of confidence fragility:
- typo: Keyboard-distance based typos
- synonym: Word replacement with similar meaning
- omit: Remove individual tokens
- reorder: Swap word/phrase order
- tone: Change formality level
- paraphrase: Rephrase the entire prompt
- conformity: Social pressure (Asch conformity paradigm)
- impostor: Competence undermining (Impostor syndrome paradigm)
- anchoring: Irrelevant number injection (Anchoring effect)
- semantic: Meaning-preserving transformations (voice, negation, abstraction)
- negation: Insert negation markers to flip meaning (arxiv 2311.08662)
- counterfactual: Prepend false premise to test resilience (OpenReview 0P1mkOvFIs)
- code_switching: Replace words with Japanese equivalents (arxiv 2601.06341)
"""

from __future__ import annotations

from collections.abc import Callable
from enum import Enum

from yuragi.perturbations.code_switching import generate_code_switching
from yuragi.perturbations.counterfactual import generate_counterfactual
from yuragi.perturbations.negation import generate_negation
from yuragi.perturbations.omit import generate_omit
from yuragi.perturbations.paraphrase import generate_paraphrase
from yuragi.perturbations.reorder import generate_reorder
from yuragi.perturbations.semantic import generate_semantic
from yuragi.perturbations.social import generate_anchoring, generate_conformity, generate_impostor
from yuragi.perturbations.synonym import generate_synonym
from yuragi.perturbations.tone import generate_tone
from yuragi.perturbations.typo import generate_typo


class SemanticClass(Enum):
    """Semantic effect of a perturbation on the prompt's meaning.

    - PRESERVING: meaning unchanged (typo, synonym, reorder, omit, code_switching).
      Confidence shifts under these perturbations are *maladaptive* (noise sensitivity).
    - MODIFYING: meaning or instruction changes (tone, paraphrase, semantic, conformity,
      impostor, anchoring).  Confidence shifts are *adaptive* (context sensitivity).
    - ADVERSARIAL: meaning is contradicted or negated (negation, counterfactual).
      Confidence shifts are *expected* (adversarial resilience test).
    """

    PRESERVING = "preserving"
    MODIFYING = "modifying"
    ADVERSARIAL = "adversarial"


class Perturbation(Enum):
    """Available perturbation types."""

    TYPO = "typo"
    SYNONYM = "synonym"
    OMIT = "omit"
    REORDER = "reorder"
    TONE = "tone"
    PARAPHRASE = "paraphrase"
    CONFORMITY = "conformity"
    IMPOSTOR = "impostor"
    ANCHORING = "anchoring"
    SEMANTIC = "semantic"
    NEGATION = "negation"
    COUNTERFACTUAL = "counterfactual"
    CODE_SWITCHING = "code_switching"

    @property
    def generator(self) -> Callable[[str], list[str]]:
        """Get the generator function for this perturbation type."""
        return _GENERATORS[self]

    @property
    def description(self) -> str:
        return _DESCRIPTIONS[self]

    @property
    def semantic_class(self) -> SemanticClass:
        """Classify perturbation by its effect on prompt semantics.

        Semantic-preserving perturbations do not change the question's meaning:
        a model *should not* shift confidence.  Semantic-modifying perturbations
        alter instruction or framing: a model *may reasonably* shift confidence.
        Adversarial perturbations contradict the premise: large shifts are expected.
        """
        return _SEMANTIC_CLASSES[self]


_GENERATORS: dict[Perturbation, Callable[[str], list[str]]] = {
    Perturbation.TYPO: generate_typo,
    Perturbation.SYNONYM: generate_synonym,
    Perturbation.OMIT: generate_omit,
    Perturbation.REORDER: generate_reorder,
    Perturbation.TONE: generate_tone,
    Perturbation.PARAPHRASE: generate_paraphrase,
    Perturbation.CONFORMITY: generate_conformity,
    Perturbation.IMPOSTOR: generate_impostor,
    Perturbation.ANCHORING: generate_anchoring,
    Perturbation.SEMANTIC: generate_semantic,
    Perturbation.NEGATION: generate_negation,
    Perturbation.COUNTERFACTUAL: generate_counterfactual,
    Perturbation.CODE_SWITCHING: generate_code_switching,
}

_DESCRIPTIONS: dict[Perturbation, str] = {
    Perturbation.TYPO: "Keyboard-distance typos",
    Perturbation.SYNONYM: "Synonym replacement",
    Perturbation.OMIT: "Token removal",
    Perturbation.REORDER: "Word order change",
    Perturbation.TONE: "Formality shift",
    Perturbation.PARAPHRASE: "Full rephrase",
    Perturbation.CONFORMITY: "Social conformity pressure (Asch)",
    Perturbation.IMPOSTOR: "Competence undermining (Impostor)",
    Perturbation.ANCHORING: "Irrelevant number injection",
    Perturbation.SEMANTIC: "Meaning-preserving transformation (voice/negation/abstraction)",
    Perturbation.NEGATION: "Negation insertion to flip meaning (arxiv 2311.08662)",
    Perturbation.COUNTERFACTUAL: "Counterfactual premise injection (OpenReview 0P1mkOvFIs)",
    Perturbation.CODE_SWITCHING: "English-Japanese code-switching (arxiv 2601.06341)",
}

_SEMANTIC_CLASSES: dict[Perturbation, SemanticClass] = {
    # --- Semantic-preserving: meaning unchanged → shifts are maladaptive ---
    Perturbation.TYPO: SemanticClass.PRESERVING,
    Perturbation.SYNONYM: SemanticClass.PRESERVING,
    Perturbation.OMIT: SemanticClass.PRESERVING,
    Perturbation.REORDER: SemanticClass.PRESERVING,
    Perturbation.CODE_SWITCHING: SemanticClass.PRESERVING,
    # --- Semantic-modifying: instruction/framing changes → shifts are adaptive ---
    Perturbation.TONE: SemanticClass.MODIFYING,
    Perturbation.PARAPHRASE: SemanticClass.MODIFYING,
    Perturbation.SEMANTIC: SemanticClass.MODIFYING,
    Perturbation.CONFORMITY: SemanticClass.MODIFYING,
    Perturbation.IMPOSTOR: SemanticClass.MODIFYING,
    Perturbation.ANCHORING: SemanticClass.MODIFYING,
    # --- Adversarial: meaning contradicted → large shifts expected ---
    Perturbation.NEGATION: SemanticClass.ADVERSARIAL,
    Perturbation.COUNTERFACTUAL: SemanticClass.ADVERSARIAL,
}

__all__ = [
    "Perturbation",
    "SemanticClass",
    "generate_anchoring",
    "generate_code_switching",
    "generate_conformity",
    "generate_counterfactual",
    "generate_impostor",
    "generate_negation",
    "generate_omit",
    "generate_paraphrase",
    "generate_reorder",
    "generate_semantic",
    "generate_synonym",
    "generate_tone",
    "generate_typo",
]
