"""Code-switching perturbation (English <-> Japanese).

Measures robustness to bilingual input where parts of the question
are translated to another language.
Reference: arxiv 2601.06341 "Code-switching robustness".
"""

from __future__ import annotations

import random
import re

# Small built-in EN->JA dictionary (deterministic, no external API)
_EN_JA: dict[str, str] = {
    "what": "何",
    "how": "どう",
    "why": "なぜ",
    "when": "いつ",
    "where": "どこ",
    "who": "誰",
    "is": "は",
    "are": "は",
    "the": "その",
    "a": "ある",
    "an": "ある",
    "this": "これ",
    "that": "あれ",
    "good": "良い",
    "bad": "悪い",
    "big": "大きい",
    "small": "小さい",
    "true": "真実",
    "false": "偽",
}


def _replace_word(word: str, mapping: dict[str, str]) -> str:
    """Replace a word using mapping, preserving surrounding punctuation."""
    stripped = word.strip(".,?!;:")
    punct = word[len(stripped):]
    replacement = mapping.get(stripped.lower())
    if replacement is None:
        return word
    return replacement + punct


def generate_code_switching(
    text: str,
    num_variants: int = 3,
    *,
    rng: random.Random | None = None,
    target_lang: str = "ja",
) -> list[str]:
    """Replace some English words with Japanese equivalents.

    Uses a small built-in dictionary for safety. Avoids machine translation
    APIs to keep the perturbation deterministic and reproducible.

    Each variant replaces a different subset of words from the dictionary
    that appear in the text.
    """
    if target_lang != "ja":
        raise ValueError(f"Unsupported target_lang: {target_lang!r}. Only 'ja' is supported.")

    _rng = rng or random.Random()
    mapping = _EN_JA

    # Find which dictionary words appear in text
    tokens = re.split(r"(\s+)", text)
    word_tokens = [t for t in tokens if t.strip() and t.strip() not in (" ", "\t")]
    matchable = [t for t in word_tokens if t.strip(".,?!;:").lower() in mapping]

    if not matchable:
        # No replaceable words: return empty list to avoid diluting fragility score
        return []

    variants: list[str] = []
    for _ in range(num_variants):
        # Randomly choose how many words to switch (1 to len(matchable))
        n = _rng.randint(1, max(1, len(matchable)))
        targets = set(_rng.sample(matchable, min(n, len(matchable))))
        new_tokens = []
        seen: dict[str, int] = {}
        for tok in tokens:
            stripped = tok.strip(".,?!;:")
            key = stripped.lower()
            if tok in targets and key in mapping:
                idx = seen.get(tok, 0)
                seen[tok] = idx + 1
                if idx == 0:
                    new_tokens.append(_replace_word(tok, mapping))
                else:
                    new_tokens.append(tok)
            else:
                new_tokens.append(tok)
        variants.append("".join(new_tokens))

    return variants
