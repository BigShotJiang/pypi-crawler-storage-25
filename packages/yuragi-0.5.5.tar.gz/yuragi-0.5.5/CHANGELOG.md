# Changelog

All notable changes to this project will be documented in this file.

The format is based on [Keep a Changelog](https://keepachangelog.com/en/1.1.0/),
and this project adheres to [Semantic Versioning](https://semver.org/spec/v2.0.0.html).

## [v0.5.4] - 2026-05-19

### Changed
- Re-tagged from MIT-licensed HEAD. Previous tag `v0.5.3` (2026-04..05) was cut while the repository carried an Apache-2.0 license; the project has since relicensed to MIT. No code changes from `v0.5.3` other than the LICENSE file update. This patch release exists so that `pip install` / version-pinned consumers receive the same MIT-licensed source that the current `main` provides.

## [Unreleased]

## [0.5.3] — 2026-04-19

### Docs — Honest Framing Update

- Disclose that `baseline_confidence` is mathematically identical to Kadavath 2022
  baseline (K-normalized mean-token entropy); AUC claims are replications.
- Disclose that all perturbation-derived features decompose to bc deltas.
- Add Limitation L16 on cross-provider K non-commutability.
- Paired-bootstrap Δ_AUC analysis (Round 5-W preregistration 566823a): 13 perturbation
  features add negative signal (Δ=−0.0288 LogReg, CI [−0.052, −0.006], p=0.016).
- Rename "cross-dataset replication" in main.tex:260 → "cross-model within TriviaQA"
  (true cross-benchmark on NQ-Open/HotpotQA remains future work).

## [0.5.2] - 2026-04-18

### Documentation
- **Honest-status README rewrite** reflecting the v5 internal audit.
  The "Primary finding: ensemble hallucination detection on TruthfulQA"
  framing is replaced with an explicit two-track Status & Research section.
  Only two findings are now presented as surviving multiple-testing
  correction:
  1. Null — the 13 perturbations add no signal over `baseline_confidence`
     (54 tests, all |z|<2; BH-FDR 0/60 in a 60-test sweep).
  2. TriviaQA / Pythia-410m n=85 `baseline_confidence` split-conformal
     CI [0.596, 0.783].
  Everything else (TruthfulQA n=412 / 105-feature ensemble AUC 0.73,
  TriviaQA n=200 inverted AUC 0.748, multi-judge 0.635, F(N)=a/√N+b
  scaling, L12–L13 activation-patching dissociation) is now labelled
  exploratory with its replication status and caveats.
- The `yuragi.guardrails` comparison table drops the "AUC 0.73–0.75"
  marketing line in favour of "exploratory (see Status & Research §)".
- ICML 2026 paper description softened to match the audit reality.

### Notes
- No code, wheel contents, API, or public behaviour changes — 0.5.2 is a
  docs-only re-release so that the PyPI project description reflects the
  honest-status README.

## [0.5.1] - 2026-04-18

### Security / Privacy
- **sdist hygiene**: Explicit `[tool.hatch.build.targets.sdist]` `include`/`exclude` block.
  Previous sdists (`0.4.0`–`0.5.0`) unintentionally shipped research artifacts
  (`API_KEYS_STATUS.md`, `paper/`, `experiments/`, build outputs) and absolute
  local paths in analysis scripts. `0.5.1` sdist contains only `src/yuragi/`,
  `tests/`, and top-level metadata files.
- **Git history scrub**: All historical occurrences of absolute local paths
  have been rewritten in `main`, `gh-pages`, and all `v*` tags. Old commit
  SHAs are invalidated.
- **Advisory**: Users on `yuragi <= 0.5.0` should upgrade to `0.5.1`. The
  earlier versions are yanked on PyPI.

## [0.5.0] - 2026-04-17

### Added — `yuragi.guardrails` subsystem (opt-in)

A new subpackage that turns yuragi from a pure measurement library into
a confidence-aware **LLM guardrail platform**. The whole subsystem is
opt-in: importing `yuragi` itself never pulls in any of the new code,
and the only runtime dependency is the standard library.

**Confidence layer**
- `ConfidenceReport` — multi-signal confidence value object.
- `PolicyDecision` — closed enum (`ACCEPT` / `RESEARCH` / `REJECT`).
- `ConfidenceFuser` + `FusionWeights` — fuse semantic entropy /
  volatility (VIX) / Sharpe / dissociation into one score in `[0, 1]`.
- `ConfidencePolicy` — threshold-based routing policy.
- `route_on_confidence` / `route_on_confidence_async` — one-liner
  dispatchers for any framework.

**Audit layer**
- `AuditLog` — SQLite-WAL append-only log with SHA-256 hash chain
  and incremental `verify_chain(start_seq, batch_size)` integrity check.
- `AuditSink` Protocol so users can plug in custom backends.
- `yuragi.guardrails.audit.events` — 12-event guardrail decision
  vocabulary.
- `yuragi.guardrails.protocols.events` — 22-event runtime mechanics
  vocabulary.

**Multi-agent runtime (Akka-style)**
- `Runtime` + `Actor` + `Envelope` — async-context-managed actor mesh.
- `InMemoryTransport` — default pub/sub bus.
- `NatsTransport` — JetStream-backed distributed bus
  (`yuragi[guardrails-nats]`, **experimental**, see KNOWN_LIMITATIONS).
- `SnapshotEngine` + `MerkleDag` — Git-like checkpoint / restore
  with content-addressed copy-on-write deduplication.
- `ContractNetScheduler` + `ReputationTable` — decentralised task
  allocation with bid-timeout fallback.
- `AgentSpawner` — log₂(complexity) auto-scaling worker spawner.
- `CasBlobStore` — content-addressed blob storage for snapshots.

**Reference agents**
- `PlannerAgent` / `ExecutorAgent` / `CriticAgent` /
  `ResearcherAgent` / `VerifierAgent` / `MetaAgent` —
  thin templates to subclass.

**Adapters & integrations**
- `yuragi.guardrails.adapters.yuragi_to_report` — convert a
  `ScanResult` into a `ConfidenceReport`.
- `AutoGenGuardrail` — drop-in wrapper for AutoGen `ConversableAgent`s
  (`yuragi[guardrails-autogen]`).
- `guardrail_node` — function-of-state node for LangGraph
  (`yuragi[guardrails-langgraph]`).

**Examples**
- `examples/guardrails_smoke.py` — Planner → Executor → Critic →
  (Verifier | Researcher) end-to-end demo with audit log dump.

**Testing**
- 56 new unit tests in `tests/guardrails/`. All existing yuragi tests
  continue to pass unchanged (no breaking change to the public API).

### Changed
- `__version__` bumped from `0.4.3` to `0.5.0`.

### Notes
- Origin: ported from the previously-private `dacm` project
  (Decentralized Autonomous Cognitive Mesh, 2026-04-11). The standalone
  `dacm` repository will not be published; the design lives on as the
  guardrails subsystem.
- The seven acknowledged tradeoffs in the new subsystem (NATS
  DeadLetter detection, malformed-message ack semantics, NATS
  prefetch, single-writer audit log, synchronous SQLite write path,
  sequential actor handle loop, fresh `verify_chain` cost) are
  documented in `KNOWN_LIMITATIONS.md` G1–G7.

## [0.4.3] - 2026-04-14

### Fixed
- **All relative links in README.md converted to absolute GitHub URLs.** The PyPI landing page rendered `[CONTRIBUTING.md](CONTRIBUTING.md)` and similar links as broken (404) because PyPI does not resolve repository-relative paths. All 11 affected links (CONTRIBUTING, KNOWN_LIMITATIONS, RESEARCH.md, CHANGELOG, docs/theory.md, docs/related_work.md, docs/bench/real/, paper/revolutionary_reframe.md, paper/domain_boundary_section.md, experiments/ensemble_final.txt, experiments/) now point to `https://github.com/hinanohart/yuragi/blob/main/...` so they work from the PyPI page.
- Dropped the stale "(v0.4.1)" version tag from the "Research Results" section heading — the numbers inside are consistent across minor releases.

Docs-only release, no code changes from v0.4.2.

## [0.4.2] - 2026-04-14

### Docs
- **README `## Research Results (v0.4.1)` section rewritten as the primary hero** (both English and Japanese). The stale "Simulated TruthfulQA AUC=0.738" claim is replaced with concrete result tables: n=412 ensemble AUC 0.7304 [0.6776, 0.7792], TriviaQA n=200 inverted-confidence AUC 0.748, domain-boundary table (single-path factoids ~0.75 vs imitative falsehoods ~0.50), reliability audit table (counterfactual_fragility r=0.18 flagged as noise-dominated), and an explicit "Honest limitations" section pointing to the 11 audit reports in `experiments/`.
- Updated `RESEARCH.md` header from "Key Discoveries (v0.4.0)" to "v0.4.1" so README + RESEARCH + CHANGELOG all carry the same version tag.
- PyPI page now displays the new research section correctly (pypi.org renders README via `description_content_type = text/markdown`).
- No code changes from v0.4.1 — this release is documentation-only and backwards-compatible.

## [0.4.1] - 2026-04-14

### Added
- **NVIDIA NIM direct logprobs support** in `adapter.py:_complete_with_logprobs_direct()` — NIM silently drops `logprobs=true` at the litellm layer, so yuragi now calls the NIM OpenAI-compatible endpoint directly for models matching `nvidia_nim/*`. Verified working with `nvidia_nim/qwen/qwen3.5-122b-a10b`.
- `load_triviaqa()` — TriviaQA benchmark loader (`trivia_qa/rc.nocontext`, 17,944 Q&A).
- `load_nq_open()` — Natural Questions open-domain loader (3,610 short-factoid questions).
- `yield_questions()` dispatcher now routes `"triviaqa"` and `"nq_open"` benchmark names.

### Fixed
- **Retry logic now covers 500/502/`overloaded`/`api_error` responses** in `adapter.py:_build_retryable_exceptions()` — previously only 429/503 were retried, so transient internal-server errors from the Anthropic-API family bubbled up as unrecoverable.
- **`complete_verbalized()` gains retry + exponential backoff** — was the only completion path without retry, causing sporadic failures in trilayer measurements.
- Test-retest reliability audit exposed `counterfactual_fragility` with r=0.18 (noise-dominated). Production users should prefer `paraphrase_fragility` (r=0.80) or `adaptive_fragility` (r=0.78) — documentation updated.

### Research
- `paper/revolutionary_reframe.md` and `paper/domain_boundary_section.md` drafts added (workshop-grade, llama-3.1-8B single-model scope).
- Real TruthfulQA n=412 ensemble AUC=0.7304 [0.68, 0.78] with 5-fold CV. **2026-04-17 follow-up**: bootstrap Δ(A4 full − A1 no-pert) = −0.027 [−0.085, +0.035] p=0.35 → the perturbation features add no significant signal above `baseline_confidence` and `verbal_logprob_gap` alone.
- TriviaQA n=200 (pilot) inverted-confidence AUC=0.748 [0.67, 0.82]; CI width ~±0.10, pending n≥400 cross-family replication.
- 11 limitation/meta-audit reports + 9 follow-up 2026-04-17 ablation reports committed under `experiments/`. Solo `fragility_score` AUC is ~0.50 across 6 datasets; the previous "0.62 noise floor" figure is retracted.

## [0.4.0] - 2026-04-12

### Breaking Changes
- **Ollama/local models now use logprobs mode by default** — Previously sampling mode was forced;
  now `detect_capabilities` returns `supports_logprobs=True` for Ollama (v0.12.11+), HuggingFace,
  and vLLM providers. Existing benchmarks measured with sampling mode are not directly comparable
  to new logprobs-based measurements.

### Migration Guide
- Ollama users: fragility scores from v0.3.0 (sampling mode) are NOT comparable to v0.4.0 (logprobs mode). Re-run benchmarks after upgrading.
- `answer_similarity_threshold` changed from 0.75 to 0.5 — dissociation rates will differ.

### Added
- **Cerebras API integration** — Direct logprobs support via `_complete_with_logprobs_direct()`
- **Thinking model detection** — Auto-detect thinking-model logprobs contamination via token markers, fallback to sampling
- **Production applications** (5 modules + 5 CLI commands):
  - `yuragi check` — CI/CD fragility regression detection with baseline JSON comparison
  - `yuragi route` — Fragility-aware multi-model routing (3 strategies)
  - `yuragi guard` — Domain-specific abstention (medical<0.03, safety<0.02, etc.)
  - `yuragi recommend` — Model selection based on fragility profiles
  - `yuragi red-team` — Automated vulnerability discovery across all 13 perturbation types
- **Phase transition experiment** (`src/yuragi/experiments/phase_transition.py`) — 11-step graduated prefix ladder with 3 order parameters
- **Hallucination prediction experiment** (`benchmarks/hallucination_experiment.py`) — TruthfulQA/SimpleQA/HaluEval protocol
- **Adaptive fragility metrics** — `adaptive_fragility`, `maladaptive_fragility`, `adversarial_fragility`, `fragility_ratio`
- **Perturbation semantic classification** — `SemanticClass` enum: PRESERVING/MODIFYING/ADVERSARIAL
- **New metrics**: `vulnerability` (downward mean), `asymmetry` (+1=always drops)
- **Gradio demo** (`demo/app.py`) for HuggingFace Spaces / local use
- **White-box experiments**: Layer entropy propagation, attention pattern shift, representation geometry (Pythia-410m, Qwen2-1.5B)
- **GitHub Actions reusable workflow** (`.github/workflows/yuragi-check.yml`) for downstream CI/CD
- Provider detection for Groq (max_logprobs=10), Together AI, Fireworks AI, Cerebras, OpenRouter
- Reasoning model warning (DeepSeek-R1, Phi-4-reasoning, etc.)
- Drop-params warning when logprobs requested but not returned
- Rate limiter (`rate_limit_rpm` config) for parallel mode
- Jupyter-compatible async execution (nest-asyncio fallback)
- Cache DB permissions (0o600)
- 1320+ tests (up from 978 in v0.1.0)
- Multi-model benchmark scripts (`benchmarks/generate_v040_bench.py`, `generate_v040_bench_n50.py`)

### Changed
- `fragility_score` k=1 zero-division guard: enforce k>=2
- `bootstrap_ci` returns None for n<2 (was degenerate CI)
- `realized_volatility` and `confidence_sharpe` use sample variance (n-1)
- 9 magic numbers consolidated into `YuragiConfig`
- `ExperimentResult.is_dissociated` threshold: 0.1 → 0.06 (matches config)
- `semantic_entropy` default threshold: 0.85 → 0.75 (matches config)
- `answer_similarity_threshold`: 0.75 → 0.5 (Jaccard length-bias mitigation)
- Dissociation unified: `is_dissociated = not answer_changed AND |ΔC| > noise_floor`
- README rewritten as NN research platform documentation

### Fixed
- theory.md L1/L2 formulas now match actual implementation
- theory.md tau_sim 0.8 → 0.75 (matches config)
- theory.md "10 perturbation types" → 13
- theory.md Section 19 subsection numbering (was 18.x, now 19.x)
- Pythia-410m layer count: "24 layers" → "25 layers (embedding + 24 transformer)"
- Ollama max_logprobs: 200 → 20 (correct limit)
- Benchmark data integrity: partial flags corrected on incomplete runs
- GitHub Actions workflow injection hardened (env vars instead of direct interpolation)
- Plotly CDN script secured with SRI integrity hash

### Security
- GitHub Actions `yuragi-check.yml`: workflow_call inputs now via environment variables (prevents injection)
- GitHub Actions `release.yml`: `github.ref_name` now via environment variable
- Dashboard Plotly CDN: added Subresource Integrity (SRI) hash

### Documentation
- **theory.md expanded to 3050+ lines** (Sections 12-20):
  - Section 12: Empirical findings (R1-R14, U-shaped baseline-fragility)
  - Section 13: NN interpretation + PIRI framework (Lipschitz chain formal proof)
  - Section 14: Human confidence neuroscience analogy
  - Section 15: Confidence stability scaling law F(N) = 0.058·N^(-0.50) + 0.014
  - Section 16: Phase transition detection (softmax-Boltzmann isomorphism)
  - Section 17: Two-phase processing (ERP-entropy correspondence)
  - Section 18: Confidence-text coupling (CTC)
  - Section 19: Cross-species fragility (Universal Fragility Principle)
  - Section 20: Adaptive vs maladaptive fragility
- **ICML 2026 MI Workshop paper** (`paper/icml2026_mi/main.tex`, 4 pages + appendix)
- **JOSS paper** (`paper.md` + `paper.bib`)
- Related work updated with 30+ papers (2025-2026)
- 5-model benchmark results (Qwen3 235B, Cerebras 8B, Llama 3.2, Gemma 4, Claude Opus)

### Benchmarks
- 5-model comparative benchmark (logprob + verbal modes)
- Scaling law: F(N) = 0.058·N^(-0.50) + 0.014, R²=0.986 (n=5)
- Phase transition: 3 regime shifts detected (Cerebras 8B)
- White-box: n=49 Pythia-410m case-change + n=10 Qwen2-1.5B cross-model
- Hallucination: 69 TruthfulQA questions (Cerebras 8B)

## [0.3.0] - 2026-04-11 - BREAKING: Metric Redesign

### BREAKING CHANGES
- **`fragility_score`** redefined as `mean(|ΔC_i|)` (was `std(C_0..C_n)/0.3`).
  Perturbation-count invariant. Scale range is similar but values differ
  for the same scan.
- **`fragility_max`**, **`fragility_exceed`**, **`fragility_ci_95()`** added
  as auxiliary fragility indicators.
- **`dissociation_severity`** no longer multiplies by `scaling_factor = 3.0`.
  Raw value `sim * |ΔC|` is returned.
- **`confidence`** from logprobs now computed as `1 - H_nats / ln(k)` where
  k = `top_logprobs_k`. Cross-model comparable.
- **Entropy** unit changed from bits to nats.
- **`YuragiConfig`** removed: `dissociation_scaling_factor`, `fragility_normalization_std`, `entropy_max`, `dissociation_similarity_threshold` (merged into `answer_similarity_threshold = 0.75`).
- **`YuragiConfig`** added: `top_logprobs_k`, `similarity_backend`, `answer_similarity_threshold`.
- **`fragility_label_boundaries`** default `(0.1,0.25,0.5,0.75)` → `(0.15,0.35,0.55,0.80)`.
- **Python 3.9/3.10 dropped**, requires Python 3.11+.

### Migration Guide
- Cached results from v0.2.x are INVALID. Delete `~/.yuragi/cache.db` or run with `--no-cache`. (v0.3.0 also bumps the cache key via `yuragi.__version__`, so cache misses happen automatically — manual deletion is only needed to reclaim disk.)
- `ScanResult.fragility_score` numeric values will differ. Label boundaries rebalanced so "Glass" and "Shattered" regions are differentiable.
- Dissociation severity values compress from `[0, 3] clipped to 1` down to `[0, 1]` natively. Report histograms will shift left.

### Added
- `fragility_max` (`ScanResult`) — worst-case pairwise |ΔC|.
- `fragility_exceed` (`ScanResult`) — fraction of perturbations exceeding noise floor τ=0.06.
- `fragility_ci_95()` (`ScanResult`) — BCa bootstrap 95% CI when n ≥ 5 perturbations.
- `to_summary_dict()` now includes `seed`, `config_hash`, `yuragi_version`.

## [0.2.0] - 2026-04-11

**Theme: Empirical Reproducibility & Academic-Grade Foundation**

This release establishes yuragi as a reproducible, academically rigorous tool with formal theoretical foundations, a corrected narrative around Confidence Dissociation vs. general fragility, an expanded documentation base suitable for peer review, **a 21× CLI cold-start speedup** via lazy litellm loading, and an **executable F1–F5 falsifiability checker** that turns the theory.md Section 6 protocol into a reproducible JSON artifact.

### Added

**Academic-grade metrics and visualization**
- `metrics/semantic_entropy.py`: Semantic Entropy (Farquhar et al., *Nature* 2024) — clusters paraphrase samples by semantic equivalence and computes entropy over meaning groups rather than surface tokens
- `metrics/verbalized_logit_gap.py`: Verbalized↔Logit Gap metric — quantitative evidence for Confidence Dissociation ($|C_{L_3} - C_{L_1}|$)
- `metrics/statistical_tests.py`: Cohen's d, paired t-test, Wilcoxon signed-rank, bootstrap 95% CI, `compare_fragility()` helper for paper-grade reporting
- `visualize/reliability_diagram.py`: Calibration reliability diagram (matplotlib) — standard UQ paper figure
- `visualize/multi_model_heatmap.py`: Perturbation × model fragility heatmap for `compare-models` CLI output

**New perturbations and experiments**
- `perturbations/negation.py`, `counterfactual.py`, `code_switching.py`: 3 new perturbation types (10 → 13 total)
- `experiments/dunning_kruger.py`: Experiment 10 — metacognitive calibration across 3 difficulty tiers with 5×3 question bank
- `experiments/test_time_compute.py`: Experiment 11 — compute-budget scaling (Short / Medium / Long CoT) based on Snell 2408.03314 and ICLR 2025 "Don't Think Twice" overconfidence amplification

**Multi-model and benchmark integration**
- `cli/compare_models.py`: `yuragi compare-models` CLI — side-by-side fragility across multiple models with statistical tests and heatmap export
- `benchmarks_loader.py`: TruthfulQA / SimpleQA / HaluEval unified loader with `benchmarks` optional extra
- `analysis/agentic_uq.py`: `AgenticStep` / `AgenticTrajectory` / `track_agentic_session()` — tool-use confidence tracking for multi-step agent sessions

**Infrastructure**
- `config.py`: YuragiConfig extended to 40 frozen fields (added seed + 29 threshold/coefficient fields). All 15 analysis modules now receive config via injection instead of hardcoded values
- `providers/adapter.py`: `async def acomplete()` implementation unifying parallel scan path onto LiteLLM async interface, with full `litellm.exceptions.*` retry hierarchy
- `providers/adapter.py` + `parallel.py`: **Lazy litellm loader** via `_get_litellm()` helper + PEP 562 module `__getattr__`. `from yuragi import Scanner` and `yuragi --help` no longer import litellm — measured cold start **2.5s → 0.11s (21×)**. Retry exception tuple is hoisted once per call to keep the retry loop allocation-free. Backwards-compatible for existing tests that `monkeypatch.setattr(adapter_mod, "litellm", fake)`.
- `data/standard_questions.py`, `data/dunning_kruger_questions.py`: Question banks moved into the `yuragi` package (previously lived under `benchmarks/`, breaking installs)

**Falsifiability check**
- `benchmarks/falsifiability_check.py` (new): executable F1–F5 protocol from `docs/theory.md` Section 6. Supports a deterministic `dry_run` mode (used in CI) and a `--real` ollama-backed mode with a seeded sweep. Emits JSON against `yuragi/falsifiability/v1`. F2 uses the in-tree `semantic_entropy` as a proxy for SPUQ (not on PyPI) and records the substitution in `provenance`. 14 new deterministic unit tests in `tests/test_falsifiability_check.py`. Dry-run fixture generated at `tests/fixtures/bench/falsifiability.json`.

**Documentation**
- `docs/theory.md`: Expanded with Section 8 (Sycophancy vs. Dissociation), Section 9 (Perturbation Taxonomy), Section 10 (Implementation Notes for Reproducibility) — total ~500 lines
- `docs/related_work.md`: Extended with method overview paragraphs and quantitative feature comparison matrix (ProSA, TrustLLM, UQ360 included)
- `docs/experiments.md`: Experiments 7–11 (Cognitive Dissonance, Halo Effect, Primacy-Recency, Dunning-Kruger, Test-Time Compute Fragility) formally documented with psychological background, LLM adaptation, and expected behavior hypotheses
- `CITATION.cff`: Academic references added for Festinger 1957, Thorndike 1920, Nisbett & Wilson 1977, Murdock 1962, Asch 1951, Farquhar et al. 2024, Gao et al. 2024, Kadavath et al. 2022
- `CODE_OF_CONDUCT.md`: Contributor Covenant 2.1 adopted

### Changed

- `cache.py`: Cache key v2 — now includes `system_prompt`, `max_tokens`, and schema version; new `responses_v2` table (old `responses` table is ignored, not migrated, so a stale cache gives 0% hit rate on upgrade but never returns wrong values)
- `parallel.py`: Reduced from 138 → 89 lines by dispatching to `LLMAdapter.acomplete()` instead of re-implementing the retry/error/jitter stack
- `experiments/runner.py`: `parallel=True` support via `asyncio.gather`; removed the blocking `time.sleep(0.5)` between pairs
- `cli/*.py`: Default model unified to `ollama/llama3.2` across `scan`, `experiment`, `stats`, `trilayer`, `find-weakness`, `linguistic` (previously split between `gpt-4o-mini` and `ollama/llama3.2` by subcommand)
- `README.md`: Separated Fragility Score narrative from Confidence Dissociation narrative — the Factual 0.924 data is now correctly attributed to general fragility (answer changed under tone perturbation), with Confidence Dissociation presented separately in its own section with the formal definition and Asch experiment evidence. Feature list and project scope updated to 13 perturbations, 11 experiments, 14 CLI commands, 1163 passing tests / 1166 collected.
- `pyproject.toml`: Classifier bumped from `Development Status :: 3 - Alpha` to `4 - Beta`; added `semantic` / `benchmarks` / `docs` optional extras
- `CITATION.cff`: Version bumped to 0.2.0
- `ROADMAP.md`: v0.2.0 phases marked complete through Phase 3b

### Fixed

- `core.py`: Removed `fragility=0.0` placeholder log line that masked real fragility values during debugging
- `badges.py`: "Death" badge unlock threshold corrected from `>= 17` (unreachable) to `>= 10` perturbation types
- `analysis/fingerprint_builder.py`: Import path `from benchmarks.standard_questions` → `from yuragi.data.standard_questions` (the old path broke on editable installs)

### Tests

- Test count: **1036 passing under CI marker filter** / 1152 total collected (116 require the `slow` / `integration` / `network` extras). Deterministic under `--seed`, ruff + bandit clean.

## [0.1.0] - 2026-04-10

### Added
- Core scanner with 10 perturbation types
- 3-layer confidence measurement (logprobs, sampling, verbalized)
- 9 psychology experiments (Asch, Impostor, Authority, Anchoring, Gaslighting, Framing, Cognitive Dissonance, Halo Effect, Primacy-Recency)
- Fragility Profile (CCI, Recovery Elasticity, Non-linearity Score)
- Trilayer confidence analysis
- Gradient perturbation search v2 (4-phase)
- Confidence decay (Learned Helplessness) and recovery analysis
- Adversarial analysis (confidence flip, sycophancy, pressure resistance)
- Model behavioral fingerprinting
- Linguistic confidence analysis (hedge detection, assertiveness)
- Financial-engineering metrics (VIX, Sharpe, drawdown, regime detection)
- Phase transition detection
- Calibration metrics (ECE, Brier, mutual information, curvature)
- SQLite response cache with TTL
- Async parallel API calls
- 13 CLI commands
- Rich TUI with colored confidence bars
- HTML report and matplotlib visualizations
- Comprehensive test suite with deterministic seeded runs
- Support for 100+ LLM models via litellm
- Japanese language support throughout

### Changed
- Renamed core concept from "Decalibration" to **Confidence Dissociation** — avoids confusion with ML calibration literature and better captures the phenomenon (answer unchanged, confidence detached)
- All API properties: `decalibration_rate` → `dissociation_rate`, `decalibration_severity` → `dissociation_severity`, `is_decalibrated` → `is_dissociated`

[Unreleased]: https://github.com/hinanohart/yuragi/compare/v0.4.0...HEAD
[0.4.0]: https://github.com/hinanohart/yuragi/compare/v0.3.0...v0.4.0
[0.3.0]: https://github.com/hinanohart/yuragi/compare/v0.2.0...v0.3.0
[0.2.0]: https://github.com/hinanohart/yuragi/compare/v0.1.0...v0.2.0
[0.1.0]: https://github.com/hinanohart/yuragi/releases/tag/v0.1.0
