# Security Policy

## Reporting a Vulnerability

If you discover a security vulnerability, please report it via [GitHub Private Vulnerability Reporting](https://github.com/hinanohart/yuragi/security/advisories/new).

Do not open a public issue for security vulnerabilities.

## API Key Safety

yuragi uses LLM API keys. Please:

- Never commit API keys to version control
- Use environment variables or `.env` files (`.env` is in `.gitignore`)
- Be aware that prompts are sent to external API providers when using cloud models
- Use `ollama` for fully local, offline operation

## Local Cache Privacy

yuragi caches LLM prompts and responses in plaintext at `~/.yuragi/cache.db`
(SQLite). Cache keys are hashed, but the stored values are not encrypted. When
processing confidential prompts, clear or disable the cache:

```python
from yuragi.cache import ResponseCache
ResponseCache().clear()
```

Or simply `rm -rf ~/.yuragi/` between sessions.

## Supported Versions

Only the latest 0.5.x release line is supported. All earlier releases
(0.1.x through 0.4.x and 0.5.0–0.5.2) have been **yanked from PyPI**
because they shipped `litellm>=1.40.0` without an upper bound, which
allowed pip to resolve to litellm 1.40.0 — a version carrying 10
GHSA advisories (SSTI, SQL injection in proxy API key verification,
authenticated RCE via MCP stdio test endpoints, etc.).

| Version | Supported | Status |
|---------|-----------|--------|
| 0.5.x   | Yes       | Active; install via `pip install -U yuragi` |
| < 0.5.3 | No        | Yanked on PyPI; do not install |

If you have an older release in a lockfile, regenerate the lock against
`yuragi>=0.5.3` to pull in the patched `litellm>=1.83.7,<2` constraint.

## Acceptable Use Policy

`yuragi` is designed as a **measurement and diagnostics tool for LLM
confidence fragility**. The `fragility_score` reflects prompt–context
interaction with the model; it is not a measure of truthfulness, integrity,
deception, or trustworthiness of any human or organisation.

You **must not** use this tool to:

- Build human deception detectors, lie detectors, or interrogation aids
- Assess the trustworthiness, honesty, or character of identifiable
  individuals (e.g. job candidates, witnesses, subjects of investigation)
- Build surveillance pipelines that score people by their phrasing
- Make consequential personnel, lending, criminal-justice, or
  disciplinary decisions based on confidence-fragility signals
- Circumvent content-safety filters or jailbreak defences of upstream
  LLM providers

`yuragi` interacts with third-party LLM providers (Anthropic, OpenAI,
Google, Cohere, Mistral, NVIDIA NIM, Cerebras, local Ollama, and others
via litellm). Users remain fully responsible for complying with each
provider's terms of service and Acceptable Use Policy:

- Anthropic: <https://www.anthropic.com/legal/aup>
- OpenAI: <https://openai.com/policies/usage-policies/>
- Google AI: <https://ai.google/responsibility/use-policies/>

This project is an **independent third-party tool** and is **not
affiliated with, endorsed by, or sponsored by** any of those providers.
