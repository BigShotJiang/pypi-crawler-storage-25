"""Unit tests for yuragi.analysis.nullhyp."""

from __future__ import annotations

import pytest


class TestPermutationAucP:
    def test_null_p_roughly_uniform(self):
        """Under the null (shuffled labels), p-value should not be consistently small."""
        import numpy as np

        from yuragi.analysis.nullhyp import permutation_auc_p

        rng = np.random.default_rng(0)
        n = 80
        y_true = rng.integers(0, 2, size=n)
        y_score = rng.uniform(0, 1, size=n)
        # Run 20 independent p-values; at least half should be > 0.05
        p_values = [
            permutation_auc_p(y_true, rng.permutation(y_score), n_iter=500, seed=i)
            for i in range(20)
        ]
        assert sum(p > 0.05 for p in p_values) >= 10

    def test_clear_signal_gives_small_p(self):
        """A perfect classifier should yield p < 0.01."""
        from yuragi.analysis.nullhyp import permutation_auc_p

        y_true = [0] * 50 + [1] * 50
        y_score = [0.1] * 50 + [0.9] * 50
        p = permutation_auc_p(y_true, y_score, n_iter=2000, seed=42)
        assert p < 0.01

    def test_mismatched_lengths_raises(self):
        from yuragi.analysis.nullhyp import permutation_auc_p

        with pytest.raises(ValueError, match="same length"):
            permutation_auc_p([0, 1], [0.5, 0.6, 0.7], n_iter=100)

    def test_single_class_raises(self):
        from yuragi.analysis.nullhyp import permutation_auc_p

        with pytest.raises(ValueError, match="two classes"):
            permutation_auc_p([1, 1, 1], [0.3, 0.5, 0.7], n_iter=100)

    def test_seed_reproducibility(self):
        from yuragi.analysis.nullhyp import permutation_auc_p

        y_true = [0, 1, 0, 1, 0, 1, 0, 1, 0, 1]
        y_score = [0.3, 0.7, 0.2, 0.8, 0.4, 0.6, 0.35, 0.65, 0.25, 0.75]
        p1 = permutation_auc_p(y_true, y_score, n_iter=500, seed=42)
        p2 = permutation_auc_p(y_true, y_score, n_iter=500, seed=42)
        assert p1 == p2


class TestPermutationDeltaP:
    def test_identical_scores_large_p(self):
        """Same scores for A and B should give a large p-value."""
        from yuragi.analysis.nullhyp import permutation_delta_p

        y_true = [0] * 40 + [1] * 40
        y_score = [0.3 + 0.01 * i for i in range(80)]
        p = permutation_delta_p(y_score, y_score, y_true, n_iter=1000, seed=42)
        assert p > 0.1

    def test_large_delta_gives_small_p(self):
        """A clearly better scorer A should yield small two-sided p."""
        from yuragi.analysis.nullhyp import permutation_delta_p

        y_true = [0] * 50 + [1] * 50
        y_score_a = [0.1] * 50 + [0.9] * 50  # perfect
        y_score_b = [0.5] * 100  # chance
        p = permutation_delta_p(y_score_a, y_score_b, y_true, n_iter=2000, seed=42)
        assert p < 0.01

    def test_mismatched_lengths_raises(self):
        from yuragi.analysis.nullhyp import permutation_delta_p

        with pytest.raises(ValueError, match="equal length"):
            permutation_delta_p([0.5, 0.6], [0.5], [0, 1], n_iter=100)


class TestBinomialCrossTemplateP:
    def test_null_hypothesis_not_rejected_balanced(self):
        """k=5, n=10 at chance=0.5 should not be significant."""
        from yuragi.analysis.nullhyp import binomial_cross_template_p

        p = binomial_cross_template_p(5, 10, chance=0.5)
        assert p > 0.05

    def test_extreme_wins_significant(self):
        """k=18, n=20 should clearly reject H0 at chance=0.5."""
        from yuragi.analysis.nullhyp import binomial_cross_template_p

        p = binomial_cross_template_p(18, 20, chance=0.5)
        assert p < 0.01

    def test_zero_wins(self):
        """k=0 should give same p as k=n by symmetry."""
        from yuragi.analysis.nullhyp import binomial_cross_template_p

        p_zero = binomial_cross_template_p(0, 10, chance=0.5)
        p_all = binomial_cross_template_p(10, 10, chance=0.5)
        assert abs(p_zero - p_all) < 1e-10

    def test_invalid_chance_raises(self):
        from yuragi.analysis.nullhyp import binomial_cross_template_p

        with pytest.raises(ValueError, match="chance"):
            binomial_cross_template_p(5, 10, chance=1.0)

    def test_n_zero_returns_one(self):
        from yuragi.analysis.nullhyp import binomial_cross_template_p

        p = binomial_cross_template_p(0, 0, chance=0.5)
        assert p == 1.0


class TestWilsonCI:
    def test_bounds_valid_range(self):
        """Wilson CI must be within [0, 1] and lower < upper."""
        from yuragi.analysis.nullhyp import wilson_ci

        lo, hi = wilson_ci(30, 100)
        assert 0.0 <= lo <= hi <= 1.0

    def test_proportion_within_ci(self):
        """Observed proportion should lie within its own Wilson CI."""
        from yuragi.analysis.nullhyp import wilson_ci

        k, n = 37, 100
        lo, hi = wilson_ci(k, n)
        assert lo <= k / n <= hi

    def test_extreme_k_zero(self):
        """k=0 should give lower=0."""
        from yuragi.analysis.nullhyp import wilson_ci

        lo, hi = wilson_ci(0, 50)
        assert lo == 0.0
        assert hi > 0.0

    def test_extreme_k_n(self):
        """k=n should give upper=1."""
        from yuragi.analysis.nullhyp import wilson_ci

        lo, hi = wilson_ci(50, 50)
        assert hi == 1.0
        assert lo < 1.0

    def test_wider_with_smaller_n(self):
        """Smaller n should give wider interval for same proportion."""
        from yuragi.analysis.nullhyp import wilson_ci

        lo1, hi1 = wilson_ci(5, 10)
        lo2, hi2 = wilson_ci(50, 100)
        width_small = hi1 - lo1
        width_large = hi2 - lo2
        assert width_small > width_large

    def test_n_zero_raises(self):
        from yuragi.analysis.nullhyp import wilson_ci

        with pytest.raises(ValueError, match="n must be > 0"):
            wilson_ci(0, 0)
