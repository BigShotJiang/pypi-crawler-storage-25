"""Unit tests for yuragi.analysis.lsc (Lowest Span Confidence)."""

from __future__ import annotations

import math

from yuragi.analysis.lsc import extract_token_logprobs, lsc_batch, lsc_score


class TestLscScore:
    def test_empty_returns_zero(self):
        assert lsc_score([]) == 0.0

    def test_shorter_than_window_returns_mean(self):
        # 3 tokens, window=4 → fallback to mean
        logprobs = [-0.5, -0.5, -0.5]
        result = lsc_score(logprobs, window=4)
        assert math.isclose(result, -0.5, rel_tol=1e-9)

    def test_monotonic_increasing_magnitude(self):
        # Worst span is at the end: [-0.4, -0.5] mean = -0.45
        logprobs = [-0.1, -0.2, -0.4, -0.5]
        result = lsc_score(logprobs, window=2)
        assert math.isclose(result, -0.45, rel_tol=1e-9)

    def test_realistic_sequence(self):
        # window=4, spans: mean(0:4)=-0.2, mean(1:5)=-0.325, mean(2:6)=-0.4
        logprobs = [-0.1, -0.1, -0.2, -0.4, -0.5, -0.5]
        result = lsc_score(logprobs, window=4)
        expected = min(
            sum(logprobs[0:4]) / 4,
            sum(logprobs[1:5]) / 4,
            sum(logprobs[2:6]) / 4,
        )
        assert math.isclose(result, expected, rel_tol=1e-9)

    def test_single_token_shorter_than_window(self):
        result = lsc_score([-0.3], window=4)
        assert math.isclose(result, -0.3, rel_tol=1e-9)

    def test_exactly_window_length(self):
        logprobs = [-0.1, -0.2, -0.3, -0.4]
        result = lsc_score(logprobs, window=4)
        expected = sum(logprobs) / 4
        assert math.isclose(result, expected, rel_tol=1e-9)

    def test_high_confidence_sequence_near_zero(self):
        logprobs = [-0.01] * 10
        result = lsc_score(logprobs, window=4)
        assert math.isclose(result, -0.01, rel_tol=1e-6)

    def test_low_confidence_captures_weak_span(self):
        # One very uncertain token buried in the middle
        logprobs = [-0.05, -0.05, -5.0, -0.05, -0.05, -0.05, -0.05]
        result = lsc_score(logprobs, window=4)
        # Span containing index 2 will be the minimum
        assert result < -1.0


class TestLscBatch:
    def test_empty_batch(self):
        assert lsc_batch([]) == []

    def test_single_item_batch(self):
        result = lsc_batch([[-0.3, -0.3, -0.3, -0.3]])
        assert len(result) == 1
        assert math.isclose(result[0], -0.3, rel_tol=1e-9)

    def test_multiple_items(self):
        batch = [[-0.1, -0.2, -0.3, -0.4], [-0.5, -0.5, -0.5, -0.5]]
        results = lsc_batch(batch, window=4)
        assert len(results) == 2
        assert results[0] > results[1]  # first sequence is more confident


class TestExtractTokenLogprobs:
    def test_none_returns_empty(self):
        assert extract_token_logprobs(None) == []

    def test_empty_list_returns_empty(self):
        assert extract_token_logprobs([]) == []

    def test_extracts_first_logprob_per_token(self):
        # raw_logprobs format: list of [(token, logprob), ...] per token
        raw = [
            [("hello", -0.1), ("world", -1.0)],
            [("there", -0.3), ("again", -2.0)],
        ]
        result = extract_token_logprobs(raw)
        assert result == [-0.1, -0.3]

    def test_skips_nan_and_inf(self):
        raw = [
            [("ok", -0.2)],
            [("bad", float("nan"))],
            [("inf", float("-inf"))],
            [("fine", -0.4)],
        ]
        result = extract_token_logprobs(raw)
        assert result == [-0.2, -0.4]

    def test_empty_token_entry_skipped(self):
        raw = [[], [("token", -0.5)]]
        result = extract_token_logprobs(raw)
        assert result == [-0.5]
