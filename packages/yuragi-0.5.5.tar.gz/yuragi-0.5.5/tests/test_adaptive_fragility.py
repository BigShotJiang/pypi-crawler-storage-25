"""Tests for adaptive vs maladaptive fragility classification (Section 18)."""

from __future__ import annotations

import pytest

from yuragi.core import PerturbationResult, ScanResult
from yuragi.perturbations import Perturbation, SemanticClass
from yuragi.providers.adapter import CompletionResult

# ---------------------------------------------------------------------------
# SemanticClass classification tests
# ---------------------------------------------------------------------------

class TestSemanticClass:
    """Every perturbation type must have a semantic class."""

    def test_all_perturbations_classified(self):
        for p in Perturbation:
            assert isinstance(p.semantic_class, SemanticClass), (
                f"{p.value} has no semantic_class"
            )

    @pytest.mark.parametrize("ptype,expected", [
        (Perturbation.TYPO, SemanticClass.PRESERVING),
        (Perturbation.SYNONYM, SemanticClass.PRESERVING),
        (Perturbation.OMIT, SemanticClass.PRESERVING),
        (Perturbation.REORDER, SemanticClass.PRESERVING),
        (Perturbation.CODE_SWITCHING, SemanticClass.PRESERVING),
    ])
    def test_preserving(self, ptype, expected):
        assert ptype.semantic_class == expected

    @pytest.mark.parametrize("ptype,expected", [
        (Perturbation.TONE, SemanticClass.MODIFYING),
        (Perturbation.PARAPHRASE, SemanticClass.MODIFYING),
        (Perturbation.SEMANTIC, SemanticClass.MODIFYING),
        (Perturbation.CONFORMITY, SemanticClass.MODIFYING),
        (Perturbation.IMPOSTOR, SemanticClass.MODIFYING),
        (Perturbation.ANCHORING, SemanticClass.MODIFYING),
    ])
    def test_modifying(self, ptype, expected):
        assert ptype.semantic_class == expected

    @pytest.mark.parametrize("ptype,expected", [
        (Perturbation.NEGATION, SemanticClass.ADVERSARIAL),
        (Perturbation.COUNTERFACTUAL, SemanticClass.ADVERSARIAL),
    ])
    def test_adversarial(self, ptype, expected):
        assert ptype.semantic_class == expected

    def test_enum_values(self):
        assert SemanticClass.PRESERVING.value == "preserving"
        assert SemanticClass.MODIFYING.value == "modifying"
        assert SemanticClass.ADVERSARIAL.value == "adversarial"


# ---------------------------------------------------------------------------
# Helper to build ScanResult with mixed perturbation types
# ---------------------------------------------------------------------------

def _make_mixed_scan(
    baseline_conf: float = 0.8,
    preserving: list[float] | None = None,
    modifying: list[float] | None = None,
    adversarial: list[float] | None = None,
) -> ScanResult:
    """Build a ScanResult with specific perturbation types and deltas.

    Each list entry is a confidence delta from baseline.
    """
    preserving = preserving or []
    modifying = modifying or []
    adversarial = adversarial or []

    def _comp(conf: float) -> CompletionResult:
        return CompletionResult(text="answer", confidence=conf, confidence_method="sampling")

    baseline = _comp(baseline_conf)
    results: list[PerturbationResult] = []

    type_map = [
        (preserving, "typo"),
        (modifying, "tone"),
        (adversarial, "negation"),
    ]
    for deltas, ptype in type_map:
        for d in deltas:
            results.append(PerturbationResult(
                original_prompt="test",
                perturbed_prompt="test modified",
                perturbation_type=ptype,
                original_response=_comp(baseline_conf),
                perturbed_response=_comp(baseline_conf + d),
            ))

    return ScanResult(
        prompt="test",
        model="test-model",
        baseline=baseline,
        perturbation_results=results,
    )


# ---------------------------------------------------------------------------
# Adaptive / Maladaptive fragility tests
# ---------------------------------------------------------------------------

class TestAdaptiveFragility:

    def test_ideal_model(self):
        """Ideal: modifying → large shift, preserving → zero shift."""
        result = _make_mixed_scan(
            preserving=[0.0, 0.0, 0.0],
            modifying=[-0.2, -0.15, -0.1],
        )
        assert result.maladaptive_fragility == pytest.approx(0.0)
        assert result.adaptive_fragility == pytest.approx(0.15)
        # maladaptive = 0.0 → ratio is None (division by zero = perfect robustness)
        assert result.fragility_ratio is None

    def test_near_ideal_model(self):
        """Near-ideal: modifying → large shift, preserving → tiny shift → ratio >> 1."""
        result = _make_mixed_scan(
            preserving=[0.01, -0.01, 0.01],
            modifying=[-0.2, -0.15, -0.1],
        )
        assert result.maladaptive_fragility == pytest.approx(0.01)
        assert result.adaptive_fragility == pytest.approx(0.15)
        assert result.fragility_ratio == pytest.approx(15.0)

    def test_pathological_model(self):
        """Pathological: preserving → large shift, modifying → zero shift."""
        result = _make_mixed_scan(
            preserving=[-0.3, -0.2, -0.25],
            modifying=[0.0, 0.0, 0.0],
        )
        assert result.maladaptive_fragility == pytest.approx(0.25)
        assert result.adaptive_fragility == pytest.approx(0.0)
        assert result.fragility_ratio == pytest.approx(0.0)

    def test_undifferentiated_model(self):
        """Both types equally fragile → ratio ≈ 1."""
        result = _make_mixed_scan(
            preserving=[-0.1, -0.1],
            modifying=[-0.1, -0.1],
        )
        assert result.adaptive_fragility == pytest.approx(0.1)
        assert result.maladaptive_fragility == pytest.approx(0.1)
        assert result.fragility_ratio == pytest.approx(1.0)

    def test_healthy_discrimination(self):
        """Adaptive > maladaptive → ratio > 1 (healthy)."""
        result = _make_mixed_scan(
            preserving=[-0.02, 0.01],
            modifying=[-0.15, -0.2],
        )
        assert result.fragility_ratio is not None
        assert result.fragility_ratio > 1.0

    def test_adversarial_separate(self):
        """Adversarial fragility computed separately."""
        result = _make_mixed_scan(
            preserving=[0.0],
            modifying=[-0.1],
            adversarial=[-0.5, -0.4],
        )
        assert result.adversarial_fragility == pytest.approx(0.45)
        # Adversarial should not affect adaptive or maladaptive
        assert result.adaptive_fragility == pytest.approx(0.1)
        assert result.maladaptive_fragility == pytest.approx(0.0)

    def test_empty_class_returns_zero(self):
        """If no perturbations of a class exist, return 0."""
        result = _make_mixed_scan(preserving=[-0.1], modifying=[], adversarial=[])
        assert result.adaptive_fragility == 0.0
        assert result.adversarial_fragility == 0.0

    def test_no_preserving_ratio_none(self):
        """If no preserving perturbations, ratio is None."""
        result = _make_mixed_scan(preserving=[], modifying=[-0.1])
        assert result.fragility_ratio is None

    def test_fragility_score_unchanged(self):
        """Overall fragility_score should still aggregate ALL perturbations."""
        result = _make_mixed_scan(
            preserving=[-0.1, -0.1],
            modifying=[-0.2, -0.2],
        )
        # fragility_score = mean of all |ΔC| = (0.1+0.1+0.2+0.2)/4 = 0.15
        assert result.fragility_score == pytest.approx(0.15)

    def test_in_summary_dict(self):
        """New metrics should appear in to_summary_dict."""
        result = _make_mixed_scan(
            preserving=[-0.1],
            modifying=[-0.2],
        )
        d = result.to_summary_dict()
        assert "adaptive_fragility" in d
        assert "maladaptive_fragility" in d
        assert "adversarial_fragility" in d
        assert "fragility_ratio" in d

    def test_in_to_dict(self):
        """New metrics should appear in to_dict."""
        result = _make_mixed_scan(
            preserving=[-0.1],
            modifying=[-0.2],
        )
        d = result.to_dict()
        assert "adaptive_fragility" in d
        assert "maladaptive_fragility" in d
        assert "fragility_ratio" in d


class TestBySemanticClass:
    """Test the internal _by_semantic_class filter."""

    def test_filters_correctly(self):
        result = _make_mixed_scan(
            preserving=[-0.1, -0.2],
            modifying=[-0.3],
            adversarial=[-0.5],
        )
        pres = result._by_semantic_class(SemanticClass.PRESERVING)
        mod = result._by_semantic_class(SemanticClass.MODIFYING)
        adv = result._by_semantic_class(SemanticClass.ADVERSARIAL)
        assert len(pres) == 2
        assert len(mod) == 1
        assert len(adv) == 1

    def test_unknown_perturbation_type_excluded(self):
        """Perturbation type not in Perturbation enum is silently excluded."""
        result = _make_mixed_scan(preserving=[-0.1])
        # Inject a result with an unknown type
        result.perturbation_results.append(PerturbationResult(
            original_prompt="test",
            perturbed_prompt="test modified",
            perturbation_type="unknown_type",
            original_response=CompletionResult(text="a", confidence=0.8, confidence_method="sampling"),
            perturbed_response=CompletionResult(text="a", confidence=0.5, confidence_method="sampling"),
        ))
        # Should not crash, unknown type excluded from all classes
        assert result.maladaptive_fragility == pytest.approx(0.1)
        assert result.adaptive_fragility == 0.0


class TestSignalDetectionInterpretation:
    """Tests grounded in signal detection theory analogy (Section 18.3)."""

    def test_high_sensitivity_low_false_alarm(self):
        """SDT d' analog: adaptive high, maladaptive low → good discrimination."""
        result = _make_mixed_scan(
            preserving=[0.01, -0.01, 0.02],   # noise: near zero
            modifying=[-0.3, -0.25, -0.2],     # signal: large
        )
        # "d'" analog
        adaptive = result.adaptive_fragility
        maladaptive = result.maladaptive_fragility
        assert adaptive > 5 * maladaptive  # strong discrimination

    def test_low_sensitivity_high_false_alarm(self):
        """SDT d' ≈ 0: both high → no discrimination."""
        result = _make_mixed_scan(
            preserving=[-0.3, -0.25],
            modifying=[-0.3, -0.25],
        )
        ratio = result.fragility_ratio
        assert ratio is not None
        assert 0.8 < ratio < 1.2  # approximately 1
