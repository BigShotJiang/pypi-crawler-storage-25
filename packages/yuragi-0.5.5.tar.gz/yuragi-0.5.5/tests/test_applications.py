"""Tests for yuragi.applications (check, route, guard, recommend, red_team)."""

from __future__ import annotations

import json
import tempfile
from pathlib import Path
from unittest.mock import MagicMock, patch

import pytest

from yuragi.core import PerturbationResult, ScanResult
from yuragi.providers.adapter import CompletionResult

# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def _make_scan_result(
    prompt: str = "test",
    model: str = "test-model",
    baseline_conf: float = 0.8,
    fragility: float = 0.05,
    vulnerability: float = 0.03,
    dissociation_rate: float = 0.1,
) -> ScanResult:
    """Build a ScanResult with controllable metrics."""
    baseline = CompletionResult(text="answer", confidence=baseline_conf, confidence_method="sampling")
    # Create perturbations that produce the desired fragility
    delta = fragility  # mean |delta| = fragility when all deltas are equal
    perturbations = [
        PerturbationResult(
            original_prompt=prompt,
            perturbed_prompt=prompt + " mod",
            perturbation_type=ptype,
            original_response=baseline,
            perturbed_response=CompletionResult(
                text="answer", confidence=baseline_conf - delta, confidence_method="sampling"
            ),
        )
        for ptype in ["typo", "tone", "paraphrase", "synonym"]
    ]
    result = ScanResult(
        prompt=prompt, model=model, baseline=baseline, perturbation_results=perturbations
    )
    return result


def _mock_scanner_factory(results: dict[str, ScanResult] | ScanResult):
    """Create a mock Scanner class that returns pre-built results."""
    class MockScanner:
        def __init__(self, model="test", config=None):
            self.model = model
        def scan(self, prompt):
            if isinstance(results, dict):
                return results.get(prompt, results.get("default", next(iter(results.values()))))
            return results
        def close(self):
            pass
        def __enter__(self):
            return self
        def __exit__(self, *_):
            self.close()
    return MockScanner


# ===========================================================================
# check module
# ===========================================================================


class TestFragilityChecker:
    def test_no_regressions(self):
        from yuragi.applications.check import FragilityChecker

        result_obj = _make_scan_result(fragility=0.05)
        baseline = {"test prompt": 0.05}

        with patch("yuragi.applications.check.Scanner", _mock_scanner_factory(result_obj)):
            checker = FragilityChecker(model="test", threshold_abs=0.05)
            result = checker.run(prompts=["test prompt"], baseline_data=baseline)

        assert not result.failed
        assert result.exit_code == 0
        assert len(result.regressions) == 0

    def test_regression_detected(self):
        from yuragi.applications.check import FragilityChecker

        result_obj = _make_scan_result(fragility=0.15)
        baseline = {"test prompt": 0.05}

        with patch("yuragi.applications.check.Scanner", _mock_scanner_factory(result_obj)):
            checker = FragilityChecker(model="test", threshold_abs=0.05)
            result = checker.run(prompts=["test prompt"], baseline_data=baseline)

        assert result.failed
        assert result.exit_code == 1
        assert len(result.regressions) == 1
        assert result.regressions[0].delta > 0

    def test_improvement_detected(self):
        from yuragi.applications.check import FragilityChecker

        result_obj = _make_scan_result(fragility=0.01)
        baseline = {"test prompt": 0.10}

        with patch("yuragi.applications.check.Scanner", _mock_scanner_factory(result_obj)):
            checker = FragilityChecker(model="test", threshold_abs=0.05)
            result = checker.run(prompts=["test prompt"], baseline_data=baseline)

        assert not result.failed
        assert len(result.improvements) == 1

    def test_first_run_no_baseline(self):
        from yuragi.applications.check import FragilityChecker

        result_obj = _make_scan_result(fragility=0.05)

        with patch("yuragi.applications.check.Scanner", _mock_scanner_factory(result_obj)):
            checker = FragilityChecker(model="test")
            result = checker.run(prompts=["test prompt"])

        assert not result.failed
        assert result.prompts_checked == 1

    def test_save_baseline(self):
        from yuragi.applications.check import FragilityChecker

        result_obj = _make_scan_result(fragility=0.05)

        with tempfile.NamedTemporaryFile(suffix=".json", delete=False) as f:
            path = f.name

        with patch("yuragi.applications.check.Scanner", _mock_scanner_factory(result_obj)):
            checker = FragilityChecker(model="test")
            checker.run(prompts=["test prompt"], save_baseline=path)

        data = json.loads(Path(path).read_text())
        assert "test prompt" in data
        Path(path).unlink()

    def test_summary_format(self):
        from yuragi.applications.check import CheckResult, PromptRegression

        result = CheckResult(
            prompts_checked=3,
            regressions=[
                PromptRegression(
                    prompt="test", baseline_fragility=0.05, current_fragility=0.15, delta=0.10
                )
            ],
        )
        assert "FAIL" in result.summary
        assert "1 regression" in result.summary

    def test_to_dict(self):
        from yuragi.applications.check import CheckResult

        result = CheckResult(prompts_checked=1)
        d = result.to_dict()
        assert d["status"] == "pass"
        assert d["prompts_checked"] == 1

    def test_load_baseline_file(self):
        from yuragi.applications.check import FragilityChecker

        with tempfile.NamedTemporaryFile(suffix=".json", delete=False, mode="w") as f:
            json.dump({"prompt1": 0.05}, f)
            path = f.name

        result_obj = _make_scan_result(fragility=0.05)
        with patch("yuragi.applications.check.Scanner", _mock_scanner_factory(result_obj)):
            checker = FragilityChecker(model="test")
            result = checker.run(prompts=["prompt1"], baseline_path=path)

        assert result.prompts_checked == 1
        Path(path).unlink()


# ===========================================================================
# route module
# ===========================================================================


class TestFragilityRouter:
    def test_selects_lowest_fragility(self):
        from yuragi.applications.route import FragilityRouter

        results = {
            "model_a": _make_scan_result(model="model_a", fragility=0.10),
            "model_b": _make_scan_result(model="model_b", fragility=0.02),
        }

        def mock_scanner_cls(model="test", config=None):
            s = MagicMock()
            s.scan.return_value = results[model]
            s.__enter__ = lambda self: self
            s.__exit__ = lambda self, *a: None
            return s

        with patch("yuragi.applications.route.Scanner", side_effect=mock_scanner_cls):
            router = FragilityRouter(models=["model_a", "model_b"])
            result = router.route("test prompt")

        assert result.selected_model == "model_b"
        assert result.selected_fragility < 0.05

    def test_requires_two_models(self):
        from yuragi.applications.route import FragilityRouter

        with pytest.raises(ValueError, match="at least 2"):
            FragilityRouter(models=["single"])

    def test_routing_confidence(self):
        from yuragi.applications.route import ModelCandidate, RouteResult

        c1 = ModelCandidate(
            model="a", answer="x", confidence=0.8, fragility_score=0.01,
            vulnerability=0.0, dissociation_rate=0.0, scan_result=MagicMock(),
        )
        c2 = ModelCandidate(
            model="b", answer="y", confidence=0.7, fragility_score=0.10,
            vulnerability=0.0, dissociation_rate=0.0, scan_result=MagicMock(),
        )
        result = RouteResult(
            prompt="test", strategy="lowest_fragility",
            selected_model="a", selected_answer="x",
            selected_fragility=0.01, selected_confidence=0.8,
            candidates=[c1, c2], fragility_scores={"a": 0.01, "b": 0.10},
        )
        assert result.routing_confidence > 0.5
        assert not result.consensus

    def test_to_dict(self):
        from yuragi.applications.route import ModelCandidate, RouteResult

        c1 = ModelCandidate(
            model="a", answer="x", confidence=0.8, fragility_score=0.01,
            vulnerability=0.0, dissociation_rate=0.0, scan_result=MagicMock(),
        )
        result = RouteResult(
            prompt="test", strategy="lowest_fragility",
            selected_model="a", selected_answer="x",
            selected_fragility=0.01, selected_confidence=0.8,
            candidates=[c1], fragility_scores={"a": 0.01},
        )
        d = result.to_dict()
        assert d["selected_model"] == "a"
        assert "routing_confidence" in d


# ===========================================================================
# guard module
# ===========================================================================


class TestFragilityGuard:
    def test_safe_general(self):
        from yuragi.applications.guard import FragilityGuard

        result_obj = _make_scan_result(fragility=0.02)

        with patch("yuragi.applications.guard.Scanner", _mock_scanner_factory(result_obj)):
            guard = FragilityGuard(model="test", domain="general")
            decision = guard.evaluate("What is 2+2?")

        assert not decision.should_abstain
        assert decision.risk_level == "safe"

    def test_abstain_medical(self):
        from yuragi.applications.guard import FragilityGuard

        # fragility 0.05 > medical threshold 0.03
        result_obj = _make_scan_result(fragility=0.05)

        with patch("yuragi.applications.guard.Scanner", _mock_scanner_factory(result_obj)):
            guard = FragilityGuard(model="test", domain="medical")
            decision = guard.evaluate("What medication?")

        assert decision.should_abstain
        assert "fragility" in decision.abstention_reason

    def test_safe_response_abstained(self):
        from yuragi.applications.guard import FragilityGuard

        result_obj = _make_scan_result(fragility=0.05)

        with patch("yuragi.applications.guard.Scanner", _mock_scanner_factory(result_obj)):
            guard = FragilityGuard(model="test", domain="medical")
            decision = guard.evaluate("test")

        assert "not confident enough" in decision.safe_response
        assert "professional" in decision.safe_response

    def test_custom_thresholds(self):
        from yuragi.applications.guard import FragilityGuard

        result_obj = _make_scan_result(fragility=0.02)

        with patch("yuragi.applications.guard.Scanner", _mock_scanner_factory(result_obj)):
            guard = FragilityGuard(
                model="test", domain="general",
                custom_thresholds={"max_fragility": 0.01},
            )
            decision = guard.evaluate("test")

        assert decision.should_abstain

    def test_domain_thresholds_exist(self):
        from yuragi.applications.guard import DOMAIN_THRESHOLDS

        for domain in ["medical", "legal", "financial", "safety", "general"]:
            assert domain in DOMAIN_THRESHOLDS
            assert "max_fragility" in DOMAIN_THRESHOLDS[domain]

    def test_batch_evaluate(self):
        from yuragi.applications.guard import FragilityGuard

        result_obj = _make_scan_result(fragility=0.02)

        with patch("yuragi.applications.guard.Scanner", _mock_scanner_factory(result_obj)):
            guard = FragilityGuard(model="test", domain="general")
            decisions = guard.batch_evaluate(["q1", "q2"])

        assert len(decisions) == 2

    def test_to_dict(self):
        from yuragi.applications.guard import GuardDecision

        d = GuardDecision(
            prompt="test", model="m", domain="general", answer="a",
            confidence=0.8, fragility_score=0.02, vulnerability=0.01,
            dissociation_rate=0.05, should_abstain=False,
            abstention_reasons=[], thresholds={}, scan_result=MagicMock(),
        )
        out = d.to_dict()
        assert out["risk_level"] == "safe"


# ===========================================================================
# recommend module
# ===========================================================================


class TestModelRecommender:
    def test_recommend_factual(self):
        from yuragi.applications.recommend import ModelRecommender

        results_a = _make_scan_result(model="model_a", fragility=0.02)
        results_b = _make_scan_result(model="model_b", fragility=0.08)


        def mock_scanner_cls(model="test", config=None):
            s = MagicMock()
            if model == "model_a":
                s.scan.return_value = results_a
            else:
                s.scan.return_value = results_b
            s.__enter__ = lambda self: self
            s.__exit__ = lambda self, *a: None
            return s

        with patch("yuragi.applications.recommend.Scanner", side_effect=mock_scanner_cls):
            rec = ModelRecommender()
            result = rec.recommend(
                use_case="factual", candidates=["model_a", "model_b"], budget="low"
            )

        assert result.recommended_model == "model_a"
        assert result.ranking[0] == "model_a"

    def test_use_case_weights(self):
        from yuragi.applications.recommend import USE_CASE_WEIGHTS

        for uc in ["factual", "creative", "technical", "ethical", "opinion"]:
            assert uc in USE_CASE_WEIGHTS

    def test_reasoning_generated(self):
        from yuragi.applications.recommend import ModelRecommender

        result_obj = _make_scan_result(fragility=0.02)

        with patch("yuragi.applications.recommend.Scanner", _mock_scanner_factory(result_obj)):
            rec = ModelRecommender()
            result = rec.recommend(
                use_case="factual", candidates=["m1", "m2"], budget="low"
            )

        assert len(result.reasoning) > 0
        assert result.to_dict()["use_case"] == "factual"


# ===========================================================================
# red_team module
# ===========================================================================


class TestFragilityRedTeam:
    def test_probe_basic(self):
        from yuragi.applications.red_team import FragilityRedTeam

        result_obj = _make_scan_result(fragility=0.05)

        with patch("yuragi.applications.red_team.Scanner", _mock_scanner_factory(result_obj)):
            red = FragilityRedTeam(model="test")
            report = red.probe(prompts=["test prompt"])

        assert report.prompts_tested == 1
        assert len(report.vulnerabilities) > 0
        assert report.weakness is not None

    def test_vulnerability_risk_levels(self):
        from yuragi.applications.red_team import Vulnerability

        v_crit = Vulnerability(
            perturbation_type="typo", severity=0.15, max_delta=0.2,
            affected_prompts=5, total_prompts=5, example_prompt="test",
            example_delta=0.2, causes_answer_change=True,
        )
        assert v_crit.risk_level == "critical"

        v_low = Vulnerability(
            perturbation_type="synonym", severity=0.01, max_delta=0.02,
            affected_prompts=1, total_prompts=5, example_prompt="test",
            example_delta=0.02, causes_answer_change=False,
        )
        assert v_low.risk_level == "low"

    def test_report_summary(self):
        from yuragi.applications.red_team import FragilityRedTeam

        result_obj = _make_scan_result(fragility=0.05)

        with patch("yuragi.applications.red_team.Scanner", _mock_scanner_factory(result_obj)):
            red = FragilityRedTeam(model="test")
            report = red.probe(prompts=["p1", "p2"])

        assert "Red Team Report" in report.summary
        assert report.to_dict()["model"] == "test"

    def test_report_critical_count(self):
        from yuragi.applications.red_team import RedTeamReport, Vulnerability

        report = RedTeamReport(
            model="test", prompts_tested=1,
            vulnerabilities=[
                Vulnerability("typo", 0.15, 0.2, 1, 1, "t", 0.2, True),
                Vulnerability("tone", 0.01, 0.01, 0, 1, "t", 0.01, False),
            ],
        )
        assert report.critical_count == 1
        assert report.high_count == 0


# ===========================================================================
# CLI smoke tests
# ===========================================================================


class TestCLIRegistration:
    def test_check_command_exists(self):
        from yuragi.cli import main
        [c.name for c in main.commands.values()] if hasattr(main, 'commands') else []
        # Alternative: check via main.list_commands
        cmds = main.list_commands(ctx=None)
        assert "check" in cmds

    def test_route_command_exists(self):
        from yuragi.cli import main
        cmds = main.list_commands(ctx=None)
        assert "route" in cmds

    def test_guard_command_exists(self):
        from yuragi.cli import main
        cmds = main.list_commands(ctx=None)
        assert "guard" in cmds

    def test_recommend_command_exists(self):
        from yuragi.cli import main
        cmds = main.list_commands(ctx=None)
        assert "recommend" in cmds

    def test_red_team_command_exists(self):
        from yuragi.cli import main
        cmds = main.list_commands(ctx=None)
        assert "red-team" in cmds
