# Test Fixtures

These files are **synthetic test data**, NOT real benchmark measurements.
They are used by the test suite to verify yuragi's internal logic without
requiring API access or real model inference.

Do NOT cite these values as experimental evidence. Real benchmark data
is stored in `docs/bench/real/`.
