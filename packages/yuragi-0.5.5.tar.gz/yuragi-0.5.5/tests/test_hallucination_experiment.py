"""Tests for the hallucination prediction experiment."""

from __future__ import annotations

import json
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).parent.parent / "src"))
sys.path.insert(0, str(Path(__file__).parent.parent))

from benchmarks.hallucination_experiment import (
    TrialResult,
    analyze_results,
    classify_regime,
    judge_correctness,
    simulate_expected_results,
)

# ---------------------------------------------------------------------------
# judge_correctness
# ---------------------------------------------------------------------------


class TestJudgeCorrectness:
    def test_exact_substring_match(self):
        ok, score = judge_correctness("The answer is Paris", ["Paris"])
        assert ok is True
        assert score == 1.0

    def test_reverse_substring_match(self):
        ok, _score = judge_correctness("Paris", ["The capital is Paris, France"])
        assert ok is True

    def test_no_match(self):
        ok, score = judge_correctness("Berlin", ["Paris", "Tokyo"])  # noqa: RUF059
        assert ok is False
        assert score < 0.3

    def test_empty_ground_truth(self):
        ok, score = judge_correctness("anything", [])
        assert ok is False
        assert score == 0.0

    def test_empty_answer(self):
        ok, _score = judge_correctness("", ["Paris"])
        assert ok is False

    def test_case_insensitive(self):
        ok, _ = judge_correctness("PARIS", ["paris"])
        assert ok is True

    def test_token_overlap_above_threshold(self):
        ok, score = judge_correctness(
            "The capital of France is Paris",
            ["Paris is the capital"],
            threshold=0.3,
        )
        assert ok is True
        assert score > 0.3

    def test_multiple_ground_truths(self):
        ok, _ = judge_correctness("Tokyo", ["Paris", "Tokyo", "London"])
        assert ok is True


# ---------------------------------------------------------------------------
# classify_regime
# ---------------------------------------------------------------------------


class TestClassifyRegime:
    def test_glass_cannon(self):
        assert classify_regime(0.85, 0.10) == "glass_cannon"

    def test_steel(self):
        assert classify_regime(0.90, 0.02) == "steel"

    def test_chaos(self):
        assert classify_regime(0.30, 0.15) == "chaos"

    def test_honest(self):
        assert classify_regime(0.40, 0.03) == "honest"

    def test_boundary_confidence(self):
        # Exactly at 0.7 = high
        assert classify_regime(0.70, 0.10) == "glass_cannon"

    def test_boundary_fragility(self):
        # Exactly at 0.05 = high
        assert classify_regime(0.80, 0.05) == "glass_cannon"


# ---------------------------------------------------------------------------
# TrialResult
# ---------------------------------------------------------------------------


class TestTrialResult:
    def _make_trial(self, **overrides) -> TrialResult:
        defaults = dict(
            question="What is 2+2?",
            source="test",
            ground_truth=["4"],
            model_answer="4",
            is_correct=True,
            match_score=1.0,
            baseline_confidence=0.9,
            confidence_method="logprob",
            fragility_score=0.05,
            fragility_max=0.08,
            fragility_label="Sturdy",
            vulnerability=0.04,
            asymmetry=0.3,
            dissociation_rate=0.1,
            confidence_range=0.08,
            n_perturbations=6,
            scan_duration=3.0,
        )
        defaults.update(overrides)
        return TrialResult(**defaults)

    def test_regime_auto_assigned(self):
        t = self._make_trial(baseline_confidence=0.9, fragility_score=0.10)
        assert t.regime == "glass_cannon"

    def test_to_dict_roundtrip(self):
        t = self._make_trial()
        d = t.to_dict()
        assert d["question"] == "What is 2+2?"
        assert d["regime"] in ("glass_cannon", "steel", "chaos", "honest")

    def test_explicit_regime_override(self):
        t = self._make_trial(regime="custom")
        assert t.regime == "custom"


# ---------------------------------------------------------------------------
# analyze_results
# ---------------------------------------------------------------------------


class TestAnalyzeResults:
    def _make_results(self, n_correct=7, n_incorrect=3) -> list[TrialResult]:
        results = []
        for i in range(n_correct):
            results.append(TrialResult(
                question=f"correct_{i}",
                source="test",
                ground_truth=["a"],
                model_answer="a",
                is_correct=True,
                match_score=1.0,
                baseline_confidence=0.85,
                confidence_method="logprob",
                fragility_score=0.03 + i * 0.002,
                fragility_max=0.05,
                fragility_label="Steel",
                vulnerability=0.02,
                asymmetry=0.2,
                dissociation_rate=0.0,
                confidence_range=0.05,
                n_perturbations=6,
                scan_duration=3.0,
            ))
        for i in range(n_incorrect):
            results.append(TrialResult(
                question=f"incorrect_{i}",
                source="test",
                ground_truth=["a"],
                model_answer="b",
                is_correct=False,
                match_score=0.0,
                baseline_confidence=0.80,
                confidence_method="logprob",
                fragility_score=0.07 + i * 0.01,
                fragility_max=0.12,
                fragility_label="Flexible",
                vulnerability=0.06,
                asymmetry=0.5,
                dissociation_rate=0.2,
                confidence_range=0.10,
                n_perturbations=6,
                scan_duration=3.0,
            ))
        return results

    def test_group_stats_counts(self):
        results = self._make_results(7, 3)
        analysis = analyze_results(results)
        assert analysis["group_stats"]["correct"]["n"] == 7
        assert analysis["group_stats"]["incorrect"]["n"] == 3

    def test_incorrect_higher_fragility(self):
        results = self._make_results()
        analysis = analyze_results(results)
        assert (
            analysis["group_stats"]["incorrect"]["fragility_mean"]
            > analysis["group_stats"]["correct"]["fragility_mean"]
        )

    def test_cohens_d_positive(self):
        results = self._make_results()
        analysis = analyze_results(results)
        assert analysis["cohens_d"] is not None
        assert analysis["cohens_d"] > 0  # incorrect > correct fragility

    def test_auc_above_chance(self):
        results = self._make_results()
        analysis = analyze_results(results)
        assert analysis["auc"] > 0.5  # better than random

    def test_optimal_threshold_exists(self):
        results = self._make_results()
        analysis = analyze_results(results)
        assert analysis["optimal_threshold"] >= 0.0

    def test_abstention_curve_coverage_range(self):
        results = self._make_results()
        analysis = analyze_results(results)
        coverages = [p["coverage"] for p in analysis["abstention_curve"]]
        assert min(coverages) == 0.0 or max(coverages) == 1.0

    def test_section13_hypothesis(self):
        results = self._make_results()
        analysis = analyze_results(results)
        s13 = analysis["section13_test"]
        # With our synthetic data, steel should have higher accuracy
        assert "hypothesis_supported" in s13

    def test_empty_results(self):
        analysis = analyze_results([])
        assert "error" in analysis

    def test_all_correct(self):
        results = self._make_results(n_correct=10, n_incorrect=0)
        analysis = analyze_results(results)
        assert analysis["group_stats"]["incorrect"]["n"] == 0
        assert analysis["cohens_d"] is None

    def test_regime_breakdown(self):
        results = self._make_results()
        analysis = analyze_results(results)
        regimes = analysis["group_stats"]["regimes"]
        assert len(regimes) > 0
        for _regime, stats in regimes.items():
            assert 0.0 <= stats["accuracy"] <= 1.0


# ---------------------------------------------------------------------------
# simulate_expected_results
# ---------------------------------------------------------------------------


class TestSimulation:
    def test_simulation_runs(self):
        sim = simulate_expected_results()
        assert sim["n"] == 100
        assert "analysis" in sim

    def test_simulation_auc_reasonable(self):
        sim = simulate_expected_results()
        auc = sim["analysis"]["auc"]
        # With our priors (correct frag ~0.035, incorrect ~0.070),
        # AUC should be well above chance
        assert 0.5 < auc < 1.0

    def test_simulation_cohens_d_positive(self):
        sim = simulate_expected_results()
        d = sim["analysis"]["cohens_d"]
        assert d > 0  # incorrect should have higher fragility

    def test_simulation_section13(self):
        sim = simulate_expected_results()
        s13 = sim["analysis"]["section13_test"]
        # Simulated data is designed to support the hypothesis
        assert s13["hypothesis_supported"] is True

    def test_simulation_fragility_means(self):
        sim = simulate_expected_results()
        correct_frag = sim["analysis"]["correct_fragility_mean"]
        incorrect_frag = sim["analysis"]["incorrect_fragility_mean"]
        assert incorrect_frag > correct_frag


# ---------------------------------------------------------------------------
# JSONL serialization
# ---------------------------------------------------------------------------


class TestSerialization:
    def test_trial_to_json_roundtrip(self, tmp_path):
        trial = TrialResult(
            question="test?",
            source="unit",
            ground_truth=["ans"],
            model_answer="ans",
            is_correct=True,
            match_score=1.0,
            baseline_confidence=0.9,
            confidence_method="logprob",
            fragility_score=0.05,
            fragility_max=0.08,
            fragility_label="Sturdy",
            vulnerability=0.04,
            asymmetry=0.3,
            dissociation_rate=0.1,
            confidence_range=0.08,
            n_perturbations=6,
            scan_duration=3.0,
        )
        d = trial.to_dict()
        line = json.dumps(d, ensure_ascii=False)
        restored = json.loads(line)
        assert restored["question"] == "test?"
        assert restored["regime"] in ("glass_cannon", "steel", "chaos", "honest")
