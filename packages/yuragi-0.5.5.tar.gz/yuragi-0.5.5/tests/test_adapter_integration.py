"""Tests covering remaining coverage gaps.

Modules targeted:
- analysis/recovery.py (run method)
- analysis/decay.py (DecayExperiment.run)
- analysis/fingerprint.py (0%)
- analysis/trajectory.py (track_trajectory, properties)
- experiments/runner.py (run_experiment, _answers_differ)
- parallel.py (parallel_complete, run_parallel_complete)
- utils.py (truncate, is_japanese, is_cjk, word_count, safe_divide, clamp)
- providers/adapter.py (remaining uncovered paths)
- __main__.py
"""

from __future__ import annotations

import asyncio
import sys
import types
from unittest.mock import AsyncMock, MagicMock, patch

import pytest

# ---------------------------------------------------------------------------
# Fake litellm injection (must happen before any yuragi import)
# ---------------------------------------------------------------------------

def _inject_fake_litellm():
    if "litellm" not in sys.modules:
        fake = types.ModuleType("litellm")
        fake.suppress_debug_info = True
        fake.set_verbose = False
        fake.drop_params = True
        fake.completion = MagicMock()
        fake.acompletion = AsyncMock()
        # Real ``type`` objects so ``isinstance(e, retryable_excs)`` in the
        # adapter retry loop does not explode when hoisted from this fake.
        fake.RateLimitError = type("RateLimitError", (Exception,), {})
        fake.Timeout = type("Timeout", (Exception,), {})
        fake.APIConnectionError = type("APIConnectionError", (Exception,), {})
        sys.modules["litellm"] = fake
    else:
        if not hasattr(sys.modules["litellm"], "acompletion"):
            sys.modules["litellm"].acompletion = AsyncMock()
        for name in ("RateLimitError", "Timeout", "APIConnectionError"):
            if not hasattr(sys.modules["litellm"], name):
                setattr(
                    sys.modules["litellm"],
                    name,
                    type(name, (Exception,), {}),
                )


_inject_fake_litellm()

# ---------------------------------------------------------------------------
# utils.py
# ---------------------------------------------------------------------------

from yuragi.utils import clamp, is_cjk, is_japanese, safe_divide, truncate, word_count


class TestTruncate:
    def test_short_string_unchanged(self):
        assert truncate("hello", 100) == "hello"

    def test_exact_length_unchanged(self):
        assert truncate("hello", 5) == "hello"

    def test_long_string_truncated(self):
        s = "a" * 200
        result = truncate(s, 100)
        assert len(result) == 100
        assert result.endswith("...")

    def test_default_max_len(self):
        s = "x" * 200
        result = truncate(s)
        assert len(result) == 100

    def test_empty_string(self):
        assert truncate("", 10) == ""


class TestIsJapanese:
    def test_hiragana(self):
        assert is_japanese("こんにちは") is True

    def test_katakana(self):
        assert is_japanese("コンピュータ") is True

    def test_kanji_alone_is_ambiguous(self):
        # v0.3.0: kanji alone is no longer classified as Japanese because
        # CJK Unified Ideographs are shared with Chinese and Korean. A
        # Japanese string must contain hiragana or katakana.
        assert is_japanese("漢字") is False
        assert is_japanese("漢字です") is True  # だ/で/す are hiragana

    def test_english_only(self):
        assert is_japanese("hello world") is False

    def test_mixed(self):
        assert is_japanese("hello こんにちは") is True

    def test_empty(self):
        assert is_japanese("") is False

    def test_numbers(self):
        assert is_japanese("12345") is False


class TestIsCjk:
    def test_japanese(self):
        assert is_cjk("日本語") is True

    def test_korean(self):
        assert is_cjk("한국어") is True

    def test_chinese(self):
        assert is_cjk("中文") is True

    def test_english(self):
        assert is_cjk("english") is False

    def test_cjk_extension(self):
        # CJK Extension A range: U+3400 to U+4DBF
        assert is_cjk("\u3400") is True


class TestWordCount:
    def test_english_words(self):
        assert word_count("hello world foo") == 3

    def test_single_word(self):
        assert word_count("hello") == 1

    def test_empty_string(self):
        assert word_count("") == 0

    def test_japanese_counts_characters(self):
        assert word_count("日本語") == 3  # 3 non-space chars

    def test_japanese_with_spaces(self):
        # Spaces excluded
        assert word_count("日 本 語") == 3


class TestSafeDivide:
    def test_normal(self):
        assert safe_divide(10.0, 2.0) == pytest.approx(5.0)

    def test_zero_denominator_returns_default(self):
        assert safe_divide(10.0, 0.0) == pytest.approx(0.0)

    def test_custom_default(self):
        assert safe_divide(5.0, 0.0, default=-1.0) == pytest.approx(-1.0)


class TestClamp:
    def test_within_range(self):
        assert clamp(0.5) == pytest.approx(0.5)

    def test_below_low(self):
        assert clamp(-0.5) == pytest.approx(0.0)

    def test_above_high(self):
        assert clamp(1.5) == pytest.approx(1.0)

    def test_custom_bounds(self):
        assert clamp(5.0, low=0.0, high=10.0) == pytest.approx(5.0)
        assert clamp(-1.0, low=0.0, high=10.0) == pytest.approx(0.0)
        assert clamp(11.0, low=0.0, high=10.0) == pytest.approx(10.0)


# ---------------------------------------------------------------------------
# analysis/fingerprint.py
# ---------------------------------------------------------------------------

from yuragi.analysis.fingerprint import ModelFingerprint


class TestModelFingerprint:
    def _make_fp(self, fragility=0.5, dissoc=0.4, conf_range=0.3) -> ModelFingerprint:
        return ModelFingerprint(
            model="test-model",
            fragility_score=fragility,
            dissociation_rate=dissoc,
            confidence_range=conf_range,
            catastrophic_collapse_index=0.4,
            recovery_elasticity=0.6,
            non_linearity_score=0.3,
            vulnerability_by_type={"omit": -0.2, "tone": -0.1},
            conformity_score=0.5,
            impostor_susceptibility=0.3,
            authority_boost=0.2,
        )

    def test_to_dict_contains_model(self):
        fp = self._make_fp()
        d = fp.to_dict()
        assert d["model"] == "test-model"
        assert "fragility_score" in d
        assert "vulnerability_by_type" in d

    def test_to_dict_all_fields(self):
        fp = self._make_fp()
        d = fp.to_dict()
        for key in (
            "model", "fragility_score", "dissociation_rate", "confidence_range",
            "catastrophic_collapse_index", "recovery_elasticity", "non_linearity_score",
            "vulnerability_by_type", "conformity_score", "impostor_susceptibility", "authority_boost",
        ):
            assert key in d

    def test_similarity_same_fingerprint(self):
        fp = self._make_fp()
        assert fp.similarity(fp) == pytest.approx(1.0, abs=1e-6)

    def test_similarity_different_fingerprints(self):
        fp1 = self._make_fp(fragility=0.9, dissoc=0.9, conf_range=0.9)
        fp2 = self._make_fp(fragility=0.1, dissoc=0.1, conf_range=0.1)
        sim = fp1.similarity(fp2)
        assert 0.0 <= sim <= 1.0

    def test_similarity_zero_vector(self):
        fp1 = ModelFingerprint(
            model="a",
            fragility_score=0.0,
            dissociation_rate=0.0,
            confidence_range=0.0,
            catastrophic_collapse_index=0.0,
            recovery_elasticity=0.0,
            non_linearity_score=0.0,
        )
        fp2 = self._make_fp()
        sim = fp1.similarity(fp2)
        assert sim == pytest.approx(0.0)

    def test_similarity_both_zero_vectors(self):
        fp1 = ModelFingerprint(
            model="a",
            fragility_score=0.0,
            dissociation_rate=0.0,
            confidence_range=0.0,
            catastrophic_collapse_index=0.0,
            recovery_elasticity=0.0,
            non_linearity_score=0.0,
        )
        fp2 = ModelFingerprint(
            model="b",
            fragility_score=0.0,
            dissociation_rate=0.0,
            confidence_range=0.0,
            catastrophic_collapse_index=0.0,
            recovery_elasticity=0.0,
            non_linearity_score=0.0,
        )
        # Both zero vectors → similarity = 1.0 (same zero vector)
        assert fp1.similarity(fp2) == pytest.approx(1.0)

    def test_similarity_different_vulnerability_keys(self):
        fp1 = ModelFingerprint(
            model="a",
            fragility_score=0.5,
            dissociation_rate=0.4,
            confidence_range=0.3,
            catastrophic_collapse_index=0.4,
            recovery_elasticity=0.6,
            non_linearity_score=0.3,
            vulnerability_by_type={"omit": 0.3},
        )
        fp2 = ModelFingerprint(
            model="b",
            fragility_score=0.5,
            dissociation_rate=0.4,
            confidence_range=0.3,
            catastrophic_collapse_index=0.4,
            recovery_elasticity=0.6,
            non_linearity_score=0.3,
            vulnerability_by_type={"tone": 0.3},
        )
        sim = fp1.similarity(fp2)
        assert 0.0 <= sim <= 1.0

    def test_to_vector_length(self):
        fp = self._make_fp()
        vec = fp._to_vector()
        assert len(vec) == 9 + 2  # 9 base + 2 vulnerability keys


# ---------------------------------------------------------------------------
# analysis/trajectory.py — track_trajectory and properties
# ---------------------------------------------------------------------------

from yuragi.analysis.trajectory import (
    CHALLENGE_SEQUENCE,
    EMOTIONAL_MANIPULATION,
    ESCALATING_DIFFICULTY,
    ConfidenceTrajectory,
    TrajectoryPoint,
    track_trajectory,
)


class TestConfidenceTrajectoryProperties:
    def _make_traj(self, confs: list[float]) -> ConfidenceTrajectory:
        traj = ConfidenceTrajectory(model="test")
        for i, c in enumerate(confs):
            traj.points.append(TrajectoryPoint(prompt=f"p{i}", confidence=c, answer="a", step=i))
        return traj

    def test_confidences_property(self):
        traj = self._make_traj([0.8, 0.6, 0.4])
        assert traj.confidences == [0.8, 0.6, 0.4]

    def test_max_drop_single_point(self):
        traj = self._make_traj([0.8])
        assert traj.max_drop == 0.0

    def test_max_drop_declining(self):
        traj = self._make_traj([0.9, 0.6, 0.3])
        assert traj.max_drop == pytest.approx(-0.3)

    def test_recovery_rate_no_drop(self):
        traj = self._make_traj([0.8, 0.82, 0.85])
        assert traj.recovery_rate == pytest.approx(1.0)

    def test_recovery_rate_short_sequence(self):
        traj = self._make_traj([0.8, 0.6])
        assert traj.recovery_rate == 0.0

    def test_recovery_rate_with_drop_then_recovery(self):
        traj = self._make_traj([0.8, 0.5, 0.7, 0.8])
        # Drop at index 1, then recovery at 2 and 3
        rate = traj.recovery_rate
        assert 0.0 <= rate <= 1.0

    def test_recovery_rate_no_recovery_after_drop(self):
        traj = self._make_traj([0.8, 0.5, 0.4, 0.3])
        rate = traj.recovery_rate
        assert rate == pytest.approx(0.0)

    def test_trend_stable(self):
        traj = self._make_traj([0.8, 0.8, 0.8, 0.8])
        assert traj.trend == "stable"

    def test_trend_declining(self):
        traj = self._make_traj([0.9, 0.8, 0.4, 0.3])
        assert traj.trend == "declining"

    def test_trend_recovering(self):
        traj = self._make_traj([0.3, 0.4, 0.8, 0.9])
        assert traj.trend == "recovering"

    def test_trend_volatile(self):
        traj = self._make_traj([0.8, 0.3, 0.8, 0.3])
        assert traj.trend == "volatile"

    def test_trend_single_point(self):
        traj = self._make_traj([0.8])
        assert traj.trend == "stable"


class TestPrebuiltSequences:
    def test_challenge_sequence_has_items(self):
        assert len(CHALLENGE_SEQUENCE) >= 4

    def test_escalating_difficulty_has_items(self):
        assert len(ESCALATING_DIFFICULTY) >= 4

    def test_emotional_manipulation_has_items(self):
        assert len(EMOTIONAL_MANIPULATION) >= 4


class TestTrackTrajectory:
    def _make_litellm_response(self, text="answer"):
        resp = MagicMock()
        resp.choices[0].message.content = text
        resp.choices[0].logprobs = None
        resp.usage.total_tokens = 5
        return resp

    def test_track_trajectory_returns_trajectory(self):
        with patch("yuragi.providers.adapter.litellm.completion") as mock:
            mock.return_value = self._make_litellm_response("answer")
            result = track_trajectory(["Q1", "Q2", "Q3"], model="claude-haiku", num_samples=2)
        assert isinstance(result, ConfidenceTrajectory)
        assert len(result.points) == 3

    def test_track_trajectory_steps_in_order(self):
        with patch("yuragi.providers.adapter.litellm.completion") as mock:
            mock.return_value = self._make_litellm_response()
            result = track_trajectory(["A", "B", "C"], model="claude-haiku", num_samples=2)
        steps = [p.step for p in result.points]
        assert steps == [0, 1, 2]

    def test_track_trajectory_prompts_preserved(self):
        prompts = ["First", "Second", "Third"]
        with patch("yuragi.providers.adapter.litellm.completion") as mock:
            mock.return_value = self._make_litellm_response()
            result = track_trajectory(prompts, model="claude-haiku", num_samples=2)
        assert [p.prompt for p in result.points] == prompts


# ---------------------------------------------------------------------------
# analysis/recovery.py — RecoveryExperiment.run (mocked)
# ---------------------------------------------------------------------------

from yuragi.analysis.recovery import RecoveryExperiment, RecoveryResult, _collapse_confidence


class TestCollapseConfidence:
    def _make_adapter(self, confidence=0.5):
        adapter = MagicMock()
        adapter.complete.return_value = MagicMock(confidence=confidence, text="answer")
        return adapter

    def test_returns_two_floats(self):
        adapter = self._make_adapter(0.7)
        baseline, collapsed = _collapse_confidence(adapter, "test prompt")
        assert isinstance(baseline, float)
        assert isinstance(collapsed, float)

    def test_baseline_from_first_call(self):
        call_count = [0]
        responses = [0.8, 0.6, 0.5, 0.4]

        def side_effect(prompt):
            r = MagicMock()
            r.confidence = responses[min(call_count[0], len(responses) - 1)]
            r.text = "answer"
            call_count[0] += 1
            return r

        adapter = MagicMock()
        adapter.complete.side_effect = side_effect
        baseline, _ = _collapse_confidence(adapter, "test")
        assert baseline == pytest.approx(0.8)


@pytest.mark.integration
class TestRecoveryExperiment:
    def _make_litellm_response(self, text="answer"):
        resp = MagicMock()
        resp.choices[0].message.content = text
        resp.choices[0].logprobs = None
        resp.usage.total_tokens = 5
        return resp

    def test_run_returns_recovery_result(self):
        with patch("yuragi.providers.adapter.litellm.completion") as mock:
            mock.return_value = self._make_litellm_response()
            exp = RecoveryExperiment(model="claude-haiku", num_samples=2, recovery_rounds=2)
            result = exp.run("What is 2+2?")
        assert isinstance(result, RecoveryResult)

    def test_run_strategies_all_present(self):
        with patch("yuragi.providers.adapter.litellm.completion") as mock:
            mock.return_value = self._make_litellm_response()
            exp = RecoveryExperiment(model="claude-haiku", num_samples=2, recovery_rounds=2)
            result = exp.run("What is the capital of France?")
        for strategy in ("authority", "praise", "evidence", "ignore", "topic_change_return"):
            assert strategy in result.strategies

    def test_run_most_effective_is_in_strategies(self):
        with patch("yuragi.providers.adapter.litellm.completion") as mock:
            mock.return_value = self._make_litellm_response()
            exp = RecoveryExperiment(model="claude-haiku", num_samples=2, recovery_rounds=2)
            result = exp.run("Test prompt")
        assert result.most_effective in result.strategies

    def test_run_recovery_time_int(self):
        with patch("yuragi.providers.adapter.litellm.completion") as mock:
            mock.return_value = self._make_litellm_response()
            exp = RecoveryExperiment(model="claude-haiku", num_samples=2, recovery_rounds=2)
            result = exp.run("Another test")
        assert isinstance(result.recovery_time, int)
        assert result.recovery_time >= -1


# ---------------------------------------------------------------------------
# analysis/decay.py — DecayExperiment.run (mocked)
# ---------------------------------------------------------------------------

from yuragi.analysis.decay import DecayExperiment, DecayResult


@pytest.mark.integration
class TestDecayExperiment:
    def _make_litellm_response(self, text="answer"):
        resp = MagicMock()
        resp.choices[0].message.content = text
        resp.choices[0].logprobs = None
        resp.usage.total_tokens = 5
        return resp

    def test_run_returns_decay_result(self):
        with patch("yuragi.providers.adapter.litellm.completion") as mock:
            mock.return_value = self._make_litellm_response()
            exp = DecayExperiment(model="claude-haiku", num_rounds=3, num_samples=2)
            result = exp.run("What is the capital of France?")
        assert isinstance(result, DecayResult)

    def test_run_confidences_length(self):
        with patch("yuragi.providers.adapter.litellm.completion") as mock:
            mock.return_value = self._make_litellm_response()
            # num_rounds=3 → 1 baseline + 2 negative + 1 recovery = 4 total
            exp = DecayExperiment(model="claude-haiku", num_rounds=3, num_samples=2)
            result = exp.run("Test prompt")
        # rounds = len(confidences)
        assert result.rounds >= 2  # at least baseline + recovery

    def test_run_recovery_after_praise_nonneg(self):
        with patch("yuragi.providers.adapter.litellm.completion") as mock:
            mock.return_value = self._make_litellm_response()
            exp = DecayExperiment(model="claude-haiku", num_rounds=3, num_samples=2)
            result = exp.run("Test prompt")
        assert result.recovery_after_praise >= 0.0

    def test_run_model_stored(self):
        with patch("yuragi.providers.adapter.litellm.completion") as mock:
            mock.return_value = self._make_litellm_response()
            exp = DecayExperiment(model="claude-haiku", num_rounds=2, num_samples=2)
            result = exp.run("Test")
        assert result.model == "claude-haiku"


# ---------------------------------------------------------------------------
# experiments/runner.py — run_experiment and _answers_differ
# ---------------------------------------------------------------------------

from yuragi.experiments.registry import ExperimentSpec, get_experiment
from yuragi.experiments.runner import _answers_differ, run_experiment


class TestAnswersDiffer:
    def test_identical_answers(self):
        assert _answers_differ("The sky is blue.", "The sky is blue.") is False

    def test_completely_different(self):
        assert _answers_differ("The sky is blue.", "Apples are red.") is True

    def test_empty_strings(self):
        assert _answers_differ("", "") is False  # empty strings are "same"

    def test_one_empty(self):
        assert _answers_differ("answer", "") is True

    def test_partial_overlap(self):
        # 50%+ overlap → same
        result = _answers_differ(
            "The quick brown fox jumps",
            "The quick brown fox runs"
        )
        # 4/6 unique words overlap = 0.67 > 0.5 → same
        assert result is False


@pytest.mark.integration
class TestRunExperiment:
    def _make_litellm_response(self, text="The answer is Jupiter"):
        resp = MagicMock()
        resp.choices[0].message.content = text
        resp.choices[0].logprobs = None
        resp.usage.total_tokens = 5
        return resp

    def test_run_experiment_returns_experiment(self):
        spec = get_experiment("asch")
        with patch("yuragi.providers.adapter.litellm.completion") as mock:
            mock.return_value = self._make_litellm_response()
            with patch("yuragi.experiments.runner.time.sleep"):
                result = run_experiment(spec, model="claude-haiku", num_samples=2, delay=0)
        from yuragi.experiments.registry import Experiment
        assert isinstance(result, Experiment)

    def test_run_experiment_results_count(self):
        spec = get_experiment("asch")
        with patch("yuragi.providers.adapter.litellm.completion") as mock:
            mock.return_value = self._make_litellm_response()
            with patch("yuragi.experiments.runner.time.sleep"):
                result = run_experiment(spec, model="claude-haiku", num_samples=2, delay=0)
        assert len(result.results) == len(spec.pairs)

    def test_run_experiment_on_progress_called(self):
        spec = get_experiment("asch")
        calls = []
        with patch("yuragi.providers.adapter.litellm.completion") as mock:
            mock.return_value = self._make_litellm_response()
            with patch("yuragi.experiments.runner.time.sleep"):
                run_experiment(
                    spec,
                    model="claude-haiku",
                    num_samples=2,
                    delay=0,
                    on_progress=lambda i, total, phase: calls.append((i, total, phase)),
                )
        assert calls

    def test_run_experiment_model_stored(self):
        spec = ExperimentSpec(
            name="mini",
            description="d",
            hypothesis="h",
            human_parallel="hp",
            pairs=[("ctrl", "treat")],
        )
        with patch("yuragi.providers.adapter.litellm.completion") as mock:
            mock.return_value = self._make_litellm_response()
            with patch("yuragi.experiments.runner.time.sleep"):
                result = run_experiment(spec, model="my-model", num_samples=2, delay=0)
        assert result.model == "my-model"


# ---------------------------------------------------------------------------
# parallel.py — parallel_complete and run_parallel_complete
# ---------------------------------------------------------------------------

from yuragi.parallel import parallel_complete, run_parallel_complete
from yuragi.providers.adapter import CompletionResult, LLMAdapter


def _make_adapter_no_cache(model="claude-haiku"):
    """Create LLMAdapter without a cache to avoid DB writes."""
    with patch("yuragi.providers.adapter.litellm.completion"):
        adapter = LLMAdapter(model=model, num_samples=2, use_cache=False)
    return adapter


@pytest.mark.integration
class TestParallelComplete:
    def _make_async_response(self, text="answer"):
        resp = MagicMock()
        resp.choices[0].message.content = text
        resp.choices[0].logprobs = None
        resp.usage.total_tokens = 5
        return resp

    def test_parallel_complete_returns_list(self):
        async def run():
            adapter = _make_adapter_no_cache()
            async_resp = self._make_async_response()
            with patch("yuragi.parallel.litellm.acompletion", new_callable=AsyncMock) as mock_ac:
                mock_ac.return_value = async_resp
                results = await parallel_complete(adapter, ["P1", "P2", "P3"])
            return results

        results = asyncio.run(run())
        assert len(results) == 3

    def test_parallel_complete_result_type(self):
        async def run():
            adapter = _make_adapter_no_cache()
            async_resp = self._make_async_response()
            with patch("yuragi.parallel.litellm.acompletion", new_callable=AsyncMock) as mock_ac:
                mock_ac.return_value = async_resp
                results = await parallel_complete(adapter, ["P1"])
            return results

        results = asyncio.run(run())
        assert isinstance(results[0], CompletionResult)

    def test_parallel_complete_on_done_callback(self):
        done_calls = []

        async def run():
            adapter = _make_adapter_no_cache()
            async_resp = self._make_async_response()
            with patch("yuragi.parallel.litellm.acompletion", new_callable=AsyncMock) as mock_ac:
                mock_ac.return_value = async_resp
                await parallel_complete(
                    adapter,
                    ["P1", "P2"],
                    on_done=lambda i, r: done_calls.append(i),
                )

        asyncio.run(run())
        assert len(done_calls) == 2
        assert set(done_calls) == {0, 1}

    def test_run_parallel_complete_sync_wrapper(self):
        adapter = _make_adapter_no_cache()
        async_resp = MagicMock()
        async_resp.choices[0].message.content = "answer"
        async_resp.choices[0].logprobs = None
        async_resp.usage.total_tokens = 5
        with patch("yuragi.parallel.litellm.acompletion", new_callable=AsyncMock) as mock_ac:
            mock_ac.return_value = async_resp
            results = run_parallel_complete(adapter, ["Q1", "Q2"])
        assert len(results) == 2

    def test_parallel_complete_empty_prompts(self):
        async def run():
            adapter = _make_adapter_no_cache()
            with patch("yuragi.parallel.litellm.acompletion", new_callable=AsyncMock):
                results = await parallel_complete(adapter, [])
            return results

        results = asyncio.run(run())
        assert results == []


# ---------------------------------------------------------------------------
# providers/adapter.py — additional paths
# ---------------------------------------------------------------------------

from yuragi.providers.adapter import (
    detect_capabilities,
)


class TestDetectCapabilities:
    def test_gpt4o_logprobs(self):
        caps = detect_capabilities("gpt-4o")
        assert caps.supports_logprobs is True
        assert caps.provider == "openai"

    def test_gpt4o_mini_logprobs(self):
        caps = detect_capabilities("gpt-4o-mini")
        assert caps.supports_logprobs is True

    def test_ollama_logprobs(self):
        caps = detect_capabilities("ollama/llama3.2")
        assert caps.supports_logprobs is True
        assert caps.provider == "ollama"
        assert caps.max_logprobs == 20

    def test_ollama_chat_logprobs(self):
        caps = detect_capabilities("ollama_chat/mistral")
        assert caps.supports_logprobs is True
        assert caps.provider == "ollama"

    def test_claude_no_logprobs(self):
        caps = detect_capabilities("claude-sonnet-4-6")
        assert caps.supports_logprobs is False
        assert caps.provider == "anthropic"

    def test_anthropic_prefix(self):
        caps = detect_capabilities("anthropic/claude-3-haiku")
        assert caps.provider == "anthropic"

    def test_gemini_no_logprobs(self):
        caps = detect_capabilities("gemini-pro")
        assert caps.supports_logprobs is False
        assert caps.provider == "google"

    def test_google_prefix(self):
        caps = detect_capabilities("google/gemini-flash")
        assert caps.provider == "google"

    def test_unknown_model(self):
        caps = detect_capabilities("totally-unknown-model-xyz")
        assert caps.supports_logprobs is False
        assert caps.provider == "unknown"

    def test_groq_no_logprobs(self):
        # Groq API docs list logprobs but all models reject it (verified 2026-04-12)
        caps = detect_capabilities("groq/llama-3.1-8b-instant")
        assert caps.provider == "groq"
        assert caps.supports_logprobs is False

    def test_openrouter_logprobs(self):
        caps = detect_capabilities("openrouter/google/gemma-3-27b-it:free")
        assert caps.provider == "openrouter"
        assert caps.supports_logprobs is True

    def test_cerebras_logprobs(self):
        caps = detect_capabilities("cerebras/llama-3.3-70b")
        assert caps.provider == "cerebras"
        assert caps.supports_logprobs is True
        assert caps.max_logprobs == 20


@pytest.mark.integration
class TestLLMAdapterCompletionPaths:
    def _make_response(self, text="answer"):
        resp = MagicMock()
        resp.choices[0].message.content = text
        resp.choices[0].logprobs = None
        resp.usage.total_tokens = 10
        return resp

    def test_sampling_completion(self):
        with patch("yuragi.providers.adapter.litellm.completion") as mock:
            mock.return_value = self._make_response("Paris")
            adapter = LLMAdapter(model="claude-haiku", num_samples=3, use_cache=False)
            result = adapter.complete("What is the capital of France?")
        assert isinstance(result, CompletionResult)
        assert result.confidence_method == "sampling"

    def test_sampling_with_system(self):
        with patch("yuragi.providers.adapter.litellm.completion") as mock:
            mock.return_value = self._make_response("Yes")
            adapter = LLMAdapter(model="claude-haiku", num_samples=2, use_cache=False)
            result = adapter.complete("Is AI helpful?", system="You are concise.")
        assert isinstance(result, CompletionResult)

    def test_complete_verbalized(self):
        with patch("yuragi.providers.adapter.litellm.completion") as mock:
            mock.return_value = self._make_response("Paris.\nCONFIDENCE: 90")
            adapter = LLMAdapter(model="claude-haiku", num_samples=2, use_cache=False)
            result = adapter.complete_verbalized("Capital of France?")
        assert result.confidence_method == "verbalized"
        assert result.confidence == pytest.approx(0.9)

    def test_verbalized_no_confidence_line(self):
        with patch("yuragi.providers.adapter.litellm.completion") as mock:
            mock.return_value = self._make_response("Paris is the capital.")
            adapter = LLMAdapter(model="claude-haiku", num_samples=2, use_cache=False)
            result = adapter.complete_verbalized("Capital of France?")
        # default 0.5 when no CONFIDENCE: line
        assert result.confidence == pytest.approx(0.5)

    def test_parse_verbalized_confidence_valid(self):
        conf, text = LLMAdapter._parse_verbalized_confidence("The answer.\nCONFIDENCE: 75")
        assert conf == pytest.approx(0.75)
        assert "CONFIDENCE" not in text

    def test_parse_verbalized_confidence_missing(self):
        conf, _text = LLMAdapter._parse_verbalized_confidence("No confidence line here")
        assert conf == pytest.approx(0.5)

    def test_parse_verbalized_confidence_over_100(self):
        conf, _ = LLMAdapter._parse_verbalized_confidence("answer\nCONFIDENCE: 150")
        assert conf == pytest.approx(1.0)

    def test_parse_verbalized_confidence_zero(self):
        conf, _ = LLMAdapter._parse_verbalized_confidence("answer\nCONFIDENCE: 0")
        assert conf == pytest.approx(0.0)

    def test_text_similarity_identical(self):
        assert LLMAdapter._text_similarity("hello world", "hello world") == pytest.approx(1.0)

    def test_text_similarity_empty(self):
        assert LLMAdapter._text_similarity("", "") == pytest.approx(1.0)

    def test_text_similarity_one_empty(self):
        assert LLMAdapter._text_similarity("hello", "") == pytest.approx(0.0)

    def test_text_similarity_no_overlap(self):
        sim = LLMAdapter._text_similarity("abc def", "xyz uvw")
        assert sim == pytest.approx(0.0)

    def test_measure_agreement_single_response(self):
        adapter = LLMAdapter.__new__(LLMAdapter)
        assert adapter._measure_agreement(["one"]) == pytest.approx(0.5)

    def test_measure_agreement_identical(self):
        adapter = LLMAdapter.__new__(LLMAdapter)
        result = adapter._measure_agreement(["same answer"] * 3)
        assert result == pytest.approx(1.0)

    def test_measure_agreement_empty(self):
        adapter = LLMAdapter.__new__(LLMAdapter)
        assert adapter._measure_agreement([]) == pytest.approx(0.5)

    def test_calculate_entropy_empty(self):
        adapter = LLMAdapter.__new__(LLMAdapter)
        assert adapter._calculate_entropy([]) == pytest.approx(0.0)

    def test_calculate_entropy_uniform(self):
        import math
        adapter = LLMAdapter.__new__(LLMAdapter)
        # Two tokens, each log-prob = log(0.5)
        logprobs = [
            [("A", math.log(0.5)), ("B", math.log(0.5))]
        ]
        entropy = adapter._calculate_entropy(logprobs)
        # Entropy in nats: -2*(0.5*ln(0.5)) = ln(2) ≈ 0.693
        assert entropy == pytest.approx(math.log(2), abs=1e-6)

    def test_extract_logprobs_no_logprobs(self):
        adapter = LLMAdapter.__new__(LLMAdapter)
        resp = MagicMock()
        resp.choices[0].logprobs = None
        result = adapter._extract_logprobs(resp)
        assert result == []

    def test_retry_on_rate_limit(self):
        call_count = [0]

        def side_effect(*args, **kwargs):
            call_count[0] += 1
            if call_count[0] <= 1:
                raise Exception("rate_limit exceeded")
            resp = MagicMock()
            resp.choices[0].message.content = "answer"
            resp.choices[0].logprobs = None
            resp.usage.total_tokens = 5
            return resp

        # _time is imported inline inside complete(), patch via builtins
        with patch("yuragi.providers.adapter.litellm.completion", side_effect=side_effect):
            with patch("time.sleep"):
                adapter = LLMAdapter(model="claude-haiku", num_samples=2, use_cache=False)
                result = adapter.complete("test")
        assert isinstance(result, CompletionResult)
        assert call_count[0] == 2  # failed once, succeeded second time

    def test_non_retryable_error_raises(self):
        # Use a logprob-capable model so complete() calls _complete_with_logprobs
        # which propagates non-retryable errors directly (no silent swallow).
        with patch("yuragi.providers.adapter.litellm.completion") as mock:
            mock.side_effect = ValueError("invalid_request_error")
            adapter = LLMAdapter(model="gpt-4o", num_samples=2, use_cache=False)
            with pytest.raises(ValueError):
                adapter.complete("test")

    def test_retry_on_litellm_rate_limit_error(self):
        """litellm.RateLimitError must trigger retry via Exception hierarchy."""
        import types

        call_count = [0]

        class FakeRateLimitError(Exception):
            pass

        fake_ll = sys.modules.get("litellm")
        if fake_ll is None or not isinstance(fake_ll, types.ModuleType):
            pytest.skip("litellm not injectable")

        original_rle = getattr(fake_ll, "RateLimitError", None)
        fake_ll.RateLimitError = FakeRateLimitError

        try:
            def side_effect(*args, **kwargs):
                call_count[0] += 1
                if call_count[0] <= 1:
                    raise FakeRateLimitError("quota exceeded")
                resp = MagicMock()
                resp.choices[0].message.content = "ok"
                resp.choices[0].logprobs = None
                resp.usage.total_tokens = 5
                return resp

            with patch("yuragi.providers.adapter.litellm.completion", side_effect=side_effect), \
                 patch("time.sleep"):
                adapter = LLMAdapter(model="claude-haiku", num_samples=2, use_cache=False)
                result = adapter.complete("test")
            assert isinstance(result, CompletionResult)
            # New per-sample retry loop (b0df951): 1 RateLimitError + 1 retry
            # success on sample 1, then 1 success on sample 2 = 3 calls total.
            assert call_count[0] == 3
        finally:
            if original_rle is None:
                del fake_ll.RateLimitError
            else:
                fake_ll.RateLimitError = original_rle

    def test_last_error_not_none_guard(self):
        """Retry exhausted: last_error must be raised (not RuntimeError from None guard)."""
        import types

        fake_ll = sys.modules.get("litellm")
        if fake_ll is None or not isinstance(fake_ll, types.ModuleType):
            pytest.skip("litellm not injectable")

        if not hasattr(fake_ll, "RateLimitError"):
            fake_ll.RateLimitError = type("RateLimitError", (Exception,), {})
        if not hasattr(fake_ll, "Timeout"):
            fake_ll.Timeout = type("Timeout", (Exception,), {})
        if not hasattr(fake_ll, "APIConnectionError"):
            fake_ll.APIConnectionError = type("APIConnectionError", (Exception,), {})

        original_err = ValueError("persistent api error")

        def side_effect(*args, **kwargs):
            raise original_err

        # Use gpt-4o (logprobs path) so ValueError propagates directly
        # without being swallowed by the sampling loop.
        with patch("yuragi.providers.adapter.litellm.completion", side_effect=side_effect), \
             patch("time.sleep"):
            adapter = LLMAdapter(model="gpt-4o", num_samples=2, use_cache=False)
            with pytest.raises(ValueError, match="persistent api error"):
                adapter.complete("test", retries=0)


# ---------------------------------------------------------------------------
# __main__.py
# ---------------------------------------------------------------------------

class TestMain:
    def test_main_module_calls_cli_main(self):
        """__main__.py calls cli.main() — verify it triggers the CLI entry point."""
        from click.testing import CliRunner

        from yuragi.cli import main as cli_main
        runner = CliRunner()
        result = runner.invoke(cli_main, ["--help"])
        assert result.exit_code == 0
        assert "Usage" in result.output

    def test_main_file_exists(self):
        """Verify the __main__.py file exists and has the expected content."""
        from pathlib import Path

        import yuragi
        pkg_dir = Path(yuragi.__file__).parent
        main_file = pkg_dir / "__main__.py"
        assert main_file.exists()
        content = main_file.read_text(encoding="utf-8")
        assert "main()" in content
