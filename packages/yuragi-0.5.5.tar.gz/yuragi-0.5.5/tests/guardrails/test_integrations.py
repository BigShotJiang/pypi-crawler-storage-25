"""Tests for the AutoGen + LangGraph integration shims.

The integrations are tested with stand-in objects so the test suite
does not require ``pyautogen`` or ``langgraph`` to be installed.
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import Any

from yuragi.guardrails import ConfidencePolicy, ConfidenceReport
from yuragi.guardrails.integrations.autogen import AutoGenGuardrail
from yuragi.guardrails.integrations.langgraph import guardrail_node


@dataclass
class _FakeAutoGenAgent:
    """Minimal stand-in for ``autogen.ConversableAgent``."""

    reply: str = "fake reply"

    def generate_reply(
        self,
        messages: list[dict[str, Any]] | None = None,
        sender: Any = None,
        **kwargs: Any,
    ) -> str:
        return self.reply


def test_autogen_guardrail_accept_passes_through() -> None:
    agent = _FakeAutoGenAgent(reply="The capital of France is Paris.")
    guard = AutoGenGuardrail(
        agent=agent,
        measure=lambda _: ConfidenceReport(confidence=0.9, dissociation=0.05),
        policy=ConfidencePolicy(tau=0.55),
    )
    assert guard.generate_reply(messages=[]) == "The capital of France is Paris."


def test_autogen_guardrail_reject_emits_abstention() -> None:
    agent = _FakeAutoGenAgent(reply="dubious answer")
    guard = AutoGenGuardrail(
        agent=agent,
        measure=lambda _: ConfidenceReport(confidence=0.05, dissociation=0.0),
        policy=ConfidencePolicy(reject_below=0.10),
        abstention_message="REFUSED",
    )
    assert guard.generate_reply(messages=[]) == "REFUSED"


def test_autogen_guardrail_research_invokes_callback() -> None:
    agent = _FakeAutoGenAgent(reply="not sure")
    calls: list[ConfidenceReport] = []

    def on_research(reply: Any, report: ConfidenceReport) -> str:
        calls.append(report)
        return "RESEARCHED"

    guard = AutoGenGuardrail(
        agent=agent,
        measure=lambda _: ConfidenceReport(confidence=0.4, dissociation=0.0),
        policy=ConfidencePolicy(tau=0.55),
        on_research=on_research,
    )
    assert guard.generate_reply(messages=[]) == "RESEARCHED"
    assert len(calls) == 1


def test_autogen_guardrail_research_without_callback_prefixes_warning() -> None:
    agent = _FakeAutoGenAgent(reply="hmm")
    guard = AutoGenGuardrail(
        agent=agent,
        measure=lambda _: ConfidenceReport(confidence=0.4, dissociation=0.0),
        policy=ConfidencePolicy(tau=0.55),
    )
    out = guard.generate_reply(messages=[])
    assert isinstance(out, str)
    assert out.startswith("[low-confidence=")


def test_langgraph_node_returns_decision_and_report() -> None:
    node = guardrail_node(
        measure=lambda _: ConfidenceReport(confidence=0.9, dissociation=0.05),
        policy=ConfidencePolicy(tau=0.55),
    )
    out = node({"input": "x"})
    assert out["guardrail_decision"] == "accept"
    assert isinstance(out["guardrail_report"], ConfidenceReport)


def test_langgraph_node_custom_keys() -> None:
    node = guardrail_node(
        measure=lambda _: ConfidenceReport(confidence=0.05, dissociation=0.0),
        policy=ConfidencePolicy(reject_below=0.10),
        decision_key="next",
        report_key="cf",
    )
    out = node({})
    assert out["next"] == "reject"
    assert "cf" in out
