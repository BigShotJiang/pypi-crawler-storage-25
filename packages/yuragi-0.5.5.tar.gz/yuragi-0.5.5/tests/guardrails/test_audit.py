"""Tests for :mod:`yuragi.guardrails.audit`."""

from __future__ import annotations

import asyncio

import pytest

from yuragi.guardrails.audit import (
    AuditLog,
    ConfidenceComputed,
    GuardrailAttached,
    PolicyDecided,
)


def _run(coro):  # type: ignore[no-untyped-def]
    return asyncio.new_event_loop().run_until_complete(coro)


def test_audit_log_appends_and_replays() -> None:
    async def go() -> None:
        log = AuditLog()
        await log.append(GuardrailAttached(guardrail_id="g1", target_id="agent_a"))
        await log.append(
            ConfidenceComputed(agent_id="agent_a", target_id="t1", confidence=0.8)
        )
        rows = await log.replay()
        assert len(rows) == 2
        assert rows[0]["event_type"] == "GuardrailAttached"
        assert rows[1]["payload"]["confidence"] == 0.8
        await log.close()

    _run(go())


def test_audit_log_chain_verifies_clean() -> None:
    async def go() -> None:
        log = AuditLog()
        for i in range(5):
            await log.append(
                PolicyDecided(
                    agent_id="agent_a",
                    target_id=f"t{i}",
                    decision="accept",
                    confidence=0.9,
                )
            )
        assert await log.verify_chain() is True
        await log.close()

    _run(go())


def test_audit_log_detects_tampered_payload(tmp_path) -> None:  # type: ignore[no-untyped-def]
    """Mutate a row's payload behind the API and verify_chain returns False."""
    import sqlite3

    db_path = tmp_path / "audit.db"

    async def write() -> None:
        log = AuditLog(path=db_path)
        await log.append(GuardrailAttached(guardrail_id="g1", target_id="agent_a"))
        await log.append(
            ConfidenceComputed(agent_id="agent_a", target_id="t1", confidence=0.8)
        )
        await log.close()

    _run(write())

    # Tamper: rewrite the second row's payload directly with a fresh
    # connection so the SQL trigger applies. Disable the trigger for
    # the demonstration so the tampering succeeds and is then caught
    # by verify_chain.
    raw = sqlite3.connect(str(db_path))
    raw.execute("DROP TRIGGER IF EXISTS audit_events_no_update")
    raw.execute("UPDATE audit_events SET payload = ? WHERE seq = 2", ('{"tampered": true}',))
    raw.commit()
    raw.close()

    async def verify() -> bool:
        log = AuditLog(path=db_path)
        ok = await log.verify_chain()
        await log.close()
        return ok

    assert _run(verify()) is False


def test_audit_log_refuses_update_via_trigger(tmp_path) -> None:  # type: ignore[no-untyped-def]
    import sqlite3

    db_path = tmp_path / "audit.db"

    async def write() -> None:
        log = AuditLog(path=db_path)
        await log.append(GuardrailAttached(guardrail_id="g1", target_id="agent_a"))
        await log.close()

    _run(write())

    raw = sqlite3.connect(str(db_path))
    with pytest.raises(sqlite3.IntegrityError):
        raw.execute("UPDATE audit_events SET payload = '{}' WHERE seq = 1")
    raw.close()


def test_audit_log_tail_hash_advances() -> None:
    async def go() -> None:
        log = AuditLog()
        first = log.tail_hash
        assert first == ""
        await log.append(GuardrailAttached(guardrail_id="g1", target_id="agent_a"))
        second = log.tail_hash
        assert second != first
        await log.append(GuardrailAttached(guardrail_id="g2", target_id="agent_b"))
        third = log.tail_hash
        assert third != second
        await log.close()

    _run(go())


def test_audit_log_close_is_idempotent() -> None:
    async def go() -> None:
        log = AuditLog()
        await log.close()
        await log.close()  # second close must not raise

    _run(go())


def test_audit_log_raises_after_close() -> None:
    async def go() -> None:
        log = AuditLog()
        await log.close()
        with pytest.raises(RuntimeError):
            await log.append(GuardrailAttached(guardrail_id="g1"))

    _run(go())
