"""Tests for :mod:`yuragi.guardrails.fuse`."""

from __future__ import annotations

import math

import pytest

from yuragi.guardrails import ConfidenceFuser, ConfidenceReport, FusionWeights


def test_fuser_returns_confidence_report() -> None:
    fuser = ConfidenceFuser()
    report = fuser.fuse(semantic_entropy=1.0, vix=10.0, sharpe=1.0, dissociation=0.05)
    assert isinstance(report, ConfidenceReport)
    assert 0.0 <= report.confidence <= 1.0


def test_fuser_clips_into_unit_interval() -> None:
    fuser = ConfidenceFuser()
    very_bad = fuser.fuse(semantic_entropy=10.0, vix=200.0, sharpe=-10.0, dissociation=10.0)
    assert very_bad.confidence == 0.0

    very_good = fuser.fuse(semantic_entropy=0.0, vix=0.0, sharpe=2.0, dissociation=0.0)
    assert 0.0 < very_good.confidence <= 1.0


def test_fuser_handles_nan_dissociation_safely() -> None:
    fuser = ConfidenceFuser()
    report = fuser.fuse(dissociation=float("nan"))
    assert math.isfinite(report.confidence)
    assert 0.0 <= report.confidence <= 1.0


def test_fuser_uses_custom_weights() -> None:
    """A higher dissociation penalty should always lower confidence."""
    base = ConfidenceFuser(weights=FusionWeights(lam_dissociation=0.1))
    strict = ConfidenceFuser(weights=FusionWeights(lam_dissociation=0.9))
    same_inputs = {"semantic_entropy": 1.0, "vix": 10.0, "sharpe": 1.0, "dissociation": 0.5}
    assert base.fuse(**same_inputs).confidence > strict.fuse(**same_inputs).confidence


def test_fuser_records_sources() -> None:
    fuser = ConfidenceFuser()
    report = fuser.fuse(semantic_entropy=1.0, sources=("ensemble", "logprob"))
    assert report.sources == ("ensemble", "logprob")


@pytest.mark.parametrize(
    ("entropy", "vix", "sharpe", "diss"),
    [
        (0.0, 0.0, 2.0, 0.0),     # best case
        (4.0, 100.0, -2.0, 1.0),  # worst case
        (2.0, 50.0, 0.0, 0.5),    # midpoint
    ],
)
def test_fuser_monotonicity(
    entropy: float, vix: float, sharpe: float, diss: float
) -> None:
    """Output is finite and bounded for representative input combinations."""
    fuser = ConfidenceFuser()
    report = fuser.fuse(
        semantic_entropy=entropy, vix=vix, sharpe=sharpe, dissociation=diss
    )
    assert 0.0 <= report.confidence <= 1.0
    assert math.isfinite(report.confidence)
