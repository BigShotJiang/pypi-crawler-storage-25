"""Tests for the Contract Net scheduler + reputation + spawner."""

from __future__ import annotations

import asyncio

from yuragi.guardrails import (
    Actor,
    AgentSpawner,
    ContractNetScheduler,
    Envelope,
    ReputationTable,
    Runtime,
)
from yuragi.guardrails.scheduler import Bid


class _Worker(Actor):
    async def handle(self, envelope: Envelope) -> None:
        return


def test_reputation_table_records_and_scores() -> None:
    rt = ReputationTable()
    rt.record_success("a")
    rt.record_success("a")
    rt.record_failure("a")
    rt.record_success("b")
    assert rt.score("a") == 2 / 3
    assert rt.score("b") == 1.0
    assert rt.best(["a", "b"]) == "b"


def test_reputation_table_neutral_prior_for_unknown() -> None:
    rt = ReputationTable()
    assert rt.score("unknown") == 0.5


def test_cnp_award_lowest_cost_bid() -> None:
    sched = ContractNetScheduler()
    task = sched.open_auction()
    award = sched.award(
        task,
        bids=[
            Bid(bidder="a", cost_estimate=3.0, confidence=0.7),
            Bid(bidder="b", cost_estimate=1.0, confidence=0.5),
            Bid(bidder="c", cost_estimate=2.0, confidence=0.9),
        ],
    )
    assert award.awardee == "b"
    assert award.via == "cnp"


def test_cnp_award_falls_back_to_reputation() -> None:
    rep = ReputationTable()
    rep.record_success("workhorse")
    sched = ContractNetScheduler(reputation=rep)
    task = sched.open_auction()
    award = sched.award(task, bids=[], candidates=["workhorse", "newbie"])
    assert award.awardee == "workhorse"
    assert award.via == "reputation_fallback"


def test_cnp_collect_bids_respects_timeout() -> None:
    sched = ContractNetScheduler(bid_timeout_s=0.05)

    async def go() -> None:
        task = sched.open_auction()
        await sched.submit_bid(task, Bid(bidder="a", cost_estimate=1.0))
        bids = await sched.collect_bids(task)
        assert any(b.bidder == "a" for b in bids)

    asyncio.run(go())


def test_spawner_log2_policy_scales_with_complexity() -> None:
    async def go() -> None:
        async with Runtime() as rt:
            spawner = AgentSpawner(runtime=rt, worker_class=_Worker, name_prefix="w")
            spawned = await spawner.scale_for(complexity=8.0)
            assert len(spawned) == 3  # ceil(log2(8)) == 3

    asyncio.run(go())


def test_spawner_minimum_one_worker() -> None:
    async def go() -> None:
        async with Runtime() as rt:
            spawner = AgentSpawner(runtime=rt, worker_class=_Worker, name_prefix="w")
            spawned = await spawner.scale_for(complexity=0.5)
            assert len(spawned) == 1

    asyncio.run(go())
