"""Tests for the bundled reference agents."""

from __future__ import annotations

import asyncio

from yuragi.guardrails import (
    AuditLog,
    ConfidencePolicy,
    CriticAgent,
    Envelope,
    ExecutorAgent,
    PlannerAgent,
    ResearcherAgent,
    Runtime,
    VerifierAgent,
)


def test_smoke_pipeline_routes_through_critic_research_or_verify() -> None:
    """Planner → Executor → Critic → (Verifier | Researcher) end-to-end."""

    async def go() -> None:
        log = AuditLog()
        async with Runtime(audit_log=log) as rt:
            await rt.spawn(PlannerAgent, name="planner")
            await rt.spawn(ExecutorAgent, name="executor")
            # Tau set high so the synthetic confidence (~0.5) escalates.
            await rt.spawn(CriticAgent, name="critic", policy=ConfidencePolicy(tau=0.85))
            await rt.spawn(ResearcherAgent, name="researcher")
            await rt.spawn(VerifierAgent, name="verifier")

            assert rt.transport is not None
            for subj, owner in [
                ("executor.in", "executor"),
                ("critic.in", "critic"),
                ("researcher.in", "researcher"),
                ("verifier.in", "verifier"),
            ]:
                await rt.transport.subscribe(subj, rt._actors[owner].actor.deliver)

            await rt.publish("planner", {"task": "summarise quantum tunneling", "complexity": 6})
            await asyncio.sleep(0.4)

        rows = await log.replay()
        types = {r["event_type"] for r in rows}
        # Either branch must have fired — research escalation or verifier accept.
        assert {"AgentSpawned", "MessageSent"}.issubset(types)
        assert {"RuntimeResearchRequested", "AgentSpawned"} & types
        await log.close()

    asyncio.run(go())


def test_critic_accepts_high_confidence() -> None:
    """A critic with low ``tau`` accepts a synthetic-stub confidence report."""

    async def go() -> None:
        async with Runtime() as rt:
            await rt.spawn(ExecutorAgent, name="executor")
            await rt.spawn(CriticAgent, name="critic", policy=ConfidencePolicy(tau=0.05))
            await rt.spawn(VerifierAgent, name="verifier")
            assert rt.transport is not None
            received: list[Envelope] = []

            async def collect(env: Envelope) -> None:
                received.append(env)

            await rt.transport.subscribe("executor.in", rt._actors["executor"].actor.deliver)
            await rt.transport.subscribe("critic.in", rt._actors["critic"].actor.deliver)
            await rt.transport.subscribe("verifier.in", rt._actors["verifier"].actor.deliver)
            await rt.transport.subscribe("verifier.out", collect)

            await rt.publish("executor.in", {"task": "trivial"})
            await asyncio.sleep(0.2)

            assert any("verified" in (env.payload or {}) for env in received)

    asyncio.run(go())
