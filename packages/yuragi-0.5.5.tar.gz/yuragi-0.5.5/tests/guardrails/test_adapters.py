"""Tests for :mod:`yuragi.guardrails.adapters`."""

from __future__ import annotations

from dataclasses import dataclass

from yuragi.guardrails.adapters import yuragi_to_report


@dataclass
class _FakeBaseline:
    confidence: float = 0.0
    text: str = ""


@dataclass
class _FakeScanResult:
    """Minimal stand-in for :class:`yuragi.core.ScanResult`."""

    baseline: _FakeBaseline
    fragility_score: float = 0.0
    vulnerability: float = 0.0
    dissociation_rate: float = 0.0


def test_yuragi_to_report_full() -> None:
    scan = _FakeScanResult(
        baseline=_FakeBaseline(confidence=0.8),
        fragility_score=0.2,
        vulnerability=0.3,
        dissociation_rate=0.05,
    )
    report = yuragi_to_report(scan)  # type: ignore[arg-type]
    assert report.confidence == 0.8
    assert report.dissociation == 0.05
    assert report.vix == 30.0
    assert -2.0 <= report.sharpe <= 2.0
    assert "yuragi.baseline_confidence" in report.sources


def test_yuragi_to_report_zero_metrics_omits_sources() -> None:
    scan = _FakeScanResult(baseline=_FakeBaseline(confidence=0.0))
    report = yuragi_to_report(scan)  # type: ignore[arg-type]
    assert report.confidence == 0.0
    assert report.sources == () or "yuragi.baseline_confidence" not in report.sources


def test_yuragi_to_report_clips_vix_to_100() -> None:
    scan = _FakeScanResult(
        baseline=_FakeBaseline(confidence=0.5),
        vulnerability=10.0,  # absurdly high — must clip
    )
    report = yuragi_to_report(scan)  # type: ignore[arg-type]
    assert report.vix == 100.0
