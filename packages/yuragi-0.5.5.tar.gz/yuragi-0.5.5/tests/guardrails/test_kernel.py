"""Tests for the kernel: :class:`Actor`, :class:`Envelope`, :class:`Runtime`."""

from __future__ import annotations

import asyncio

import pytest

from yuragi.guardrails import (
    Actor,
    AuditLog,
    Envelope,
    InMemoryTransport,
    LifecycleError,
    Runtime,
)


class _Echo(Actor):
    async def handle(self, envelope: Envelope) -> None:
        await self.publish("echo.out", {"echoed": envelope.payload})


def test_envelope_with_lamport_returns_copy() -> None:
    env = Envelope(subject="x", payload=1, lamport=3)
    new = env.with_lamport(7)
    assert new.lamport == 7
    assert env.lamport == 3
    assert new.envelope_id == env.envelope_id


def test_runtime_requires_started_before_spawn() -> None:
    rt = Runtime()

    async def go() -> None:
        with pytest.raises(LifecycleError):
            await rt.spawn(_Echo)

    asyncio.run(go())


def test_runtime_spawn_and_publish() -> None:
    async def go() -> None:
        log = AuditLog()
        async with Runtime(audit_log=log) as rt:
            await rt.spawn(_Echo, name="echo")
            assert rt.transport is not None
            received: list[Envelope] = []

            async def collect(env: Envelope) -> None:
                received.append(env)

            await rt.transport.subscribe("echo.out", collect)
            await rt.publish("echo", {"hello": True})
            await asyncio.sleep(0.05)
            assert any(env.payload == {"echoed": {"hello": True}} for env in received)

        rows = await log.replay()
        types = [r["event_type"] for r in rows]
        assert "AgentSpawned" in types
        assert "MessageSent" in types
        await log.close()

    asyncio.run(go())


def test_runtime_dead_letter_on_no_subscriber() -> None:
    async def go() -> None:
        log = AuditLog()
        async with Runtime(audit_log=log) as rt:
            await rt.publish("nobody.listens", {"ping": 1})
            await asyncio.sleep(0.01)

        rows = await log.replay()
        assert any(r["event_type"] == "DeadLetter" for r in rows)
        await log.close()

    asyncio.run(go())


def test_runtime_halt_records_event() -> None:
    async def go() -> None:
        log = AuditLog()
        async with Runtime(audit_log=log) as rt:
            await rt.spawn(_Echo, name="echo")
            await rt.halt("echo", reason="shutdown")
            assert "echo" not in rt.list_agents()

        rows = await log.replay()
        assert any(r["event_type"] == "AgentHalted" for r in rows)
        await log.close()

    asyncio.run(go())


def test_runtime_default_transport_is_in_memory() -> None:
    async def go() -> None:
        async with Runtime() as rt:
            assert isinstance(rt.transport, InMemoryTransport)

    asyncio.run(go())


def test_runtime_duplicate_actor_name_raises() -> None:
    async def go() -> None:
        async with Runtime() as rt:
            await rt.spawn(_Echo, name="dup")
            with pytest.raises(LifecycleError):
                await rt.spawn(_Echo, name="dup")

    asyncio.run(go())
