"""Tests for :mod:`yuragi.guardrails.policy` and the routing helpers."""

from __future__ import annotations

import asyncio

from yuragi.guardrails import (
    ConfidencePolicy,
    ConfidenceReport,
    PolicyDecision,
    route_on_confidence,
    route_on_confidence_async,
)


def test_policy_accepts_high_confidence_low_dissociation() -> None:
    pol = ConfidencePolicy(tau=0.55, dissociation_max=0.30, reject_below=0.10)
    report = ConfidenceReport(confidence=0.9, dissociation=0.05)
    assert pol.decide(report) == PolicyDecision.ACCEPT


def test_policy_research_below_tau() -> None:
    pol = ConfidencePolicy(tau=0.55)
    report = ConfidenceReport(confidence=0.4, dissociation=0.0)
    assert pol.decide(report) == PolicyDecision.RESEARCH


def test_policy_research_on_high_dissociation() -> None:
    pol = ConfidencePolicy(tau=0.55, dissociation_max=0.30)
    report = ConfidenceReport(confidence=0.95, dissociation=0.5)
    assert pol.decide(report) == PolicyDecision.RESEARCH


def test_policy_rejects_below_floor() -> None:
    pol = ConfidencePolicy(reject_below=0.10)
    report = ConfidenceReport(confidence=0.05, dissociation=0.0)
    assert pol.decide(report) == PolicyDecision.REJECT


def test_route_on_confidence_returns_decision_when_callbacks_omitted() -> None:
    report = ConfidenceReport(confidence=0.9, dissociation=0.05)
    assert route_on_confidence(report) == PolicyDecision.ACCEPT


def test_route_on_confidence_dispatches_to_callback() -> None:
    report = ConfidenceReport(confidence=0.05, dissociation=0.0)
    result = route_on_confidence(report, on_reject=lambda: "abstained")
    assert result == "abstained"


def test_route_on_confidence_async_dispatches() -> None:
    report = ConfidenceReport(confidence=0.4, dissociation=0.0)

    async def go() -> str:
        async def on_research() -> str:
            return "researching"

        return await route_on_confidence_async(report, on_research=on_research)

    assert asyncio.run(go()) == "researching"


def test_policy_threshold_ordering_is_explicit() -> None:
    """A report below ``reject_below`` is rejected even if dissociation is OK."""
    pol = ConfidencePolicy(tau=0.55, dissociation_max=0.30, reject_below=0.10)
    bad = ConfidenceReport(confidence=0.05, dissociation=0.05)
    assert pol.decide(bad) == PolicyDecision.REJECT
