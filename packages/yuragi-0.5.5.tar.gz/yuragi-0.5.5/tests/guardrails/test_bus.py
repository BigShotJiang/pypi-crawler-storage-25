"""Tests for the in-memory transport."""

from __future__ import annotations

import asyncio

from yuragi.guardrails import Envelope, InMemoryTransport


def test_in_memory_transport_publishes_to_all_subscribers() -> None:
    async def go() -> None:
        bus = InMemoryTransport()
        await bus.start()
        received: list[Envelope] = []

        async def h1(env: Envelope) -> None:
            received.append(env)

        async def h2(env: Envelope) -> None:
            received.append(env)

        await bus.subscribe("topic", h1)
        await bus.subscribe("topic", h2)

        env = Envelope(subject="topic", payload="x")
        n = await bus.publish(env)
        assert n == 2
        assert len(received) == 2

        await bus.stop()

    asyncio.run(go())


def test_in_memory_transport_publish_returns_zero_when_no_subscribers() -> None:
    async def go() -> None:
        bus = InMemoryTransport()
        await bus.start()
        env = Envelope(subject="nobody", payload="x")
        assert await bus.publish(env) == 0
        await bus.stop()

    asyncio.run(go())


def test_in_memory_transport_unsubscribe() -> None:
    async def go() -> None:
        bus = InMemoryTransport()
        await bus.start()
        received: list[Envelope] = []

        async def h(env: Envelope) -> None:
            received.append(env)

        await bus.subscribe("topic", h)
        await bus.unsubscribe("topic", h)
        await bus.publish(Envelope(subject="topic", payload="x"))
        assert received == []
        await bus.stop()

    asyncio.run(go())


def test_in_memory_transport_publish_after_stop_returns_zero() -> None:
    async def go() -> None:
        bus = InMemoryTransport()
        await bus.start()
        await bus.stop()
        n = await bus.publish(Envelope(subject="t", payload=1))
        assert n == 0

    asyncio.run(go())
