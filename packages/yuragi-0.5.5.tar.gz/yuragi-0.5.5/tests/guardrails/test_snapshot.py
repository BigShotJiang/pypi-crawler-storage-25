"""Tests for the snapshot engine + Merkle DAG."""

from __future__ import annotations

import asyncio

from yuragi.guardrails import (
    Actor,
    AuditLog,
    Envelope,
    MerkleDag,
    MerkleNode,
    Runtime,
    SnapshotEngine,
)


class _Stateful(Actor):
    async def handle(self, envelope: Envelope) -> None:
        if isinstance(envelope.payload, dict):
            self.state.update(envelope.payload)


def test_merkle_node_address_is_deterministic() -> None:
    a = MerkleNode(payload={"x": 1, "y": 2})
    b = MerkleNode(payload={"y": 2, "x": 1})
    assert a.address == b.address


def test_merkle_dag_dedupes_identical_nodes() -> None:
    dag = MerkleDag()
    addr1 = dag.put(MerkleNode(payload={"x": 1}))
    addr2 = dag.put(MerkleNode(payload={"x": 1}))
    assert addr1 == addr2
    assert len(dag) == 1


def test_snapshot_commit_and_restore_roundtrips_state() -> None:
    async def go() -> None:
        log = AuditLog()
        async with Runtime(audit_log=log) as rt:
            await rt.spawn(_Stateful, name="alpha")
            await rt.spawn(_Stateful, name="beta")
            assert rt.transport is not None

            await rt.transport.subscribe("alpha", rt._actors["alpha"].actor.deliver)
            await rt.transport.subscribe("beta", rt._actors["beta"].actor.deliver)

            await rt.publish("alpha", {"counter": 5})
            await rt.publish("beta", {"counter": 9})
            await asyncio.sleep(0.05)

            engine = SnapshotEngine()
            snap = await engine.commit(rt, reason="unit-test")
            assert snap.n_agents == 2
            assert snap.bytes_total > 0

            # Mutate state, then restore.
            rt._actors["alpha"].actor.state["counter"] = 999
            report = await engine.restore(rt, snap.root)
            assert report["alpha"] == "restored"
            assert rt._actors["alpha"].actor.state["counter"] == 5

        await log.close()

    asyncio.run(go())


def test_merkle_node_serialise_deserialise_roundtrip() -> None:
    node = MerkleNode(payload={"a": 1}, children={"child": "deadbeef"})
    blob = node.serialise()
    out = MerkleNode.deserialise(blob)
    assert out.payload == {"a": 1}
    assert out.children == {"child": "deadbeef"}
