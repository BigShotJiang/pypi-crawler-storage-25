"""Unit tests for yuragi.analysis.stc (Semantic Token Clustering).

Reference: arXiv:2603.20161 (2026-03)

Covers 6+ cases: synthetic uniform/skewed/singleton, cluster count validation,
empty/single-token boundary conditions.
"""
from __future__ import annotations

import math

import numpy as np
import pytest

from yuragi.analysis.stc import (
    _cosine_sim,
    cluster_spans,
    detect_semantic_spans,
    stc_entropy,
)

# ---------------------------------------------------------------------------
# _cosine_sim helpers
# ---------------------------------------------------------------------------

class TestCosineSim:
    def test_identical_vectors_returns_one(self):
        a = np.array([1.0, 0.0, 0.0])
        assert _cosine_sim(a, a) == pytest.approx(1.0)

    def test_orthogonal_vectors_returns_zero(self):
        a = np.array([1.0, 0.0])
        b = np.array([0.0, 1.0])
        assert _cosine_sim(a, b) == pytest.approx(0.0)

    def test_zero_vector_returns_zero(self):
        a = np.zeros(4)
        b = np.array([1.0, 2.0, 3.0, 4.0])
        assert _cosine_sim(a, b) == 0.0


# ---------------------------------------------------------------------------
# detect_semantic_spans
# ---------------------------------------------------------------------------

class TestDetectSemanticSpans:
    def test_empty_input_returns_empty(self):
        result = detect_semantic_spans(np.empty((0, 4)))
        assert result == []

    def test_single_token_returns_one_span(self):
        emb = np.random.default_rng(0).normal(size=(1, 8)).astype(np.float32)
        result = detect_semantic_spans(emb, sim_threshold=0.85)
        assert result == [(0, 1)]

    def test_identical_tokens_form_one_span(self):
        # All identical embeddings -> all cos sim = 1.0 -> single span
        emb = np.ones((5, 4), dtype=np.float32)
        result = detect_semantic_spans(emb, sim_threshold=0.85)
        assert result == [(0, 5)]

    def test_orthogonal_tokens_form_many_spans(self):
        # Each token is a different basis vector -> cos sim = 0 -> 4 spans
        emb = np.eye(4, dtype=np.float32)
        result = detect_semantic_spans(emb, sim_threshold=0.5)
        assert result == [(0, 1), (1, 2), (2, 3), (3, 4)]

    def test_spans_cover_full_range_no_gaps(self):
        rng = np.random.default_rng(7)
        emb = rng.normal(size=(10, 16)).astype(np.float32)
        spans = detect_semantic_spans(emb, sim_threshold=0.85)
        # Covers [0, T) without gaps
        assert spans[0][0] == 0
        assert spans[-1][1] == 10
        for i in range(len(spans) - 1):
            assert spans[i][1] == spans[i + 1][0]

    def test_higher_threshold_produces_more_spans(self):
        rng = np.random.default_rng(3)
        emb = rng.normal(size=(8, 16)).astype(np.float32)
        spans_strict = detect_semantic_spans(emb, sim_threshold=0.99)
        spans_lenient = detect_semantic_spans(emb, sim_threshold=0.0)
        assert len(spans_strict) >= len(spans_lenient)


# ---------------------------------------------------------------------------
# cluster_spans
# ---------------------------------------------------------------------------

class TestClusterSpans:
    def test_single_span_returns_label_zero(self):
        emb = np.ones((1, 4), dtype=np.float32)
        labels = cluster_spans(emb)
        assert list(labels) == [0]

    def test_empty_spans_returns_empty(self):
        labels = cluster_spans(np.empty((0, 4), dtype=np.float32))
        assert len(labels) == 0

    def test_fixed_k_produces_correct_cluster_count(self):
        rng = np.random.default_rng(42)
        emb = rng.normal(size=(10, 8)).astype(np.float32)
        labels = cluster_spans(emb, k=3)
        assert len(np.unique(labels)) <= 3
        assert labels.shape == (10,)

    def test_auto_k_returns_valid_labels(self):
        # 2 well-separated clusters -> auto k should pick >=2
        rng = np.random.default_rng(0)
        emb_a = rng.normal(loc=5.0, scale=0.1, size=(5, 8)).astype(np.float32)
        emb_b = rng.normal(loc=-5.0, scale=0.1, size=(5, 8)).astype(np.float32)
        emb = np.vstack([emb_a, emb_b])
        labels = cluster_spans(emb, k=None)
        assert labels.shape == (10,)
        assert labels.min() >= 0

    def test_k_capped_at_span_count(self):
        emb = np.random.default_rng(1).normal(size=(3, 4)).astype(np.float32)
        labels = cluster_spans(emb, k=100)
        assert len(labels) == 3


# ---------------------------------------------------------------------------
# stc_entropy
# ---------------------------------------------------------------------------

class TestStcEntropy:
    """6 core cases: uniform, skewed, singleton, cluster count, empty, single-token."""

    def _make_uniform_spans_labels(self, n: int) -> tuple:
        """n tokens, each its own span, each its own cluster."""
        tokens = list(range(n))
        logprobs = [math.log(1.0 / n)] * n  # uniform
        spans = [(i, i + 1) for i in range(n)]
        labels = np.arange(n, dtype=int)
        return tokens, logprobs, spans, labels

    # Case 1: empty input -> 0
    def test_empty_tokens_returns_zero(self):
        assert stc_entropy([], [], [], np.array([], dtype=int)) == 0.0

    # Case 2: single token -> 0
    def test_single_token_returns_zero(self):
        result = stc_entropy([42], [0.0], [(0, 1)], np.array([0]))
        assert result == 0.0

    # Case 3: uniform distribution over n clusters -> ln(n)
    def test_uniform_entropy_equals_log_n(self):
        n = 4
        tokens, logprobs, spans, labels = self._make_uniform_spans_labels(n)
        entropy = stc_entropy(tokens, logprobs, spans, labels)
        assert entropy == pytest.approx(math.log(n), abs=1e-5)

    # Case 4: skewed distribution -> lower entropy than uniform
    def test_skewed_entropy_less_than_uniform(self):
        # One cluster gets 90% probability, rest share 10%
        n = 4
        tokens = list(range(n))
        # High prob on token 0, low on rest
        logprobs = [math.log(0.91)] + [math.log(0.03)] * 3
        spans = [(i, i + 1) for i in range(n)]
        labels = np.arange(n, dtype=int)
        skewed = stc_entropy(tokens, logprobs, spans, labels)
        uniform = math.log(n)
        assert skewed < uniform

    # Case 5: all tokens in one cluster -> 0
    def test_singleton_cluster_entropy_zero(self):
        n = 5
        tokens = list(range(n))
        logprobs = [math.log(1.0 / n)] * n
        spans = [(0, n)]  # one span
        labels = np.array([0])  # one cluster
        entropy = stc_entropy(tokens, logprobs, spans, labels)
        assert entropy == pytest.approx(0.0, abs=1e-10)

    # Case 6: cluster count validation - 2 clusters, equal prob -> ln(2)
    def test_two_equal_clusters_entropy_equals_log2(self):
        tokens = [0, 1, 2, 3]
        logprobs = [math.log(0.25)] * 4
        spans = [(0, 2), (2, 4)]  # 2 spans
        labels = np.array([0, 1])  # 2 clusters
        entropy = stc_entropy(tokens, logprobs, spans, labels)
        assert entropy == pytest.approx(math.log(2), abs=1e-5)

    # Bonus: multiple tokens per span merged into cluster
    def test_multi_token_spans_aggregate_probs(self):
        # 4 tokens, 2 spans of 2, both same cluster -> 0 entropy
        tokens = [0, 1, 2, 3]
        logprobs = [math.log(0.25)] * 4
        spans = [(0, 2), (2, 4)]
        labels = np.array([0, 0])  # same cluster
        entropy = stc_entropy(tokens, logprobs, spans, labels)
        assert entropy == pytest.approx(0.0, abs=1e-10)
