"""Unit tests for logit_lens and causal_trace modules.

5 test cases:
1. logit_lens output shape
2. layer ordering (later layers have higher target token prob for factual prompt)
3. unembedding correctness (final layer matches model.logits)
4. ln_f application confirmed (early layer without ln_f has near-uniform distribution)
5. causal_trace shape and identify_causal_layer
"""
from __future__ import annotations

import pytest

torch = pytest.importorskip("torch")
F = pytest.importorskip("torch.nn.functional")
pytest.importorskip("transformers")

import numpy as np  # noqa: E402

# ---------------------------------------------------------------------------
# Shared fixture: tiny stub model that mimics Pythia GPTNeoX structure
# ---------------------------------------------------------------------------

class _FakeFinalLayerNorm(torch.nn.Module):
    """Identity layer norm (preserves tensor, simulates ln_f)."""
    def forward(self, x):
        return x


class _FakeLayer(torch.nn.Module):
    """Single transformer-like layer that scales hidden state by a constant."""
    def __init__(self, scale: float):
        super().__init__()
        self.scale = scale

    def forward(self, x):
        return (x * self.scale,)


class _FakeGptNeoX(torch.nn.Module):
    def __init__(self, n_layers: int, hidden: int):
        super().__init__()
        self.layers = torch.nn.ModuleList(
            [_FakeLayer(1.0 + 0.1 * i) for i in range(n_layers)]
        )
        self.final_layer_norm = _FakeFinalLayerNorm()


class _FakeConfig:
    num_hidden_layers = 4
    hidden_size = 8
    vocab_size = 16


class _FakeOutput:
    def __init__(self, hidden_states, logits):
        self.hidden_states = hidden_states
        self.logits = logits


class _FakeModel(torch.nn.Module):
    """Minimal stub model with GPTNeoX attribute structure."""

    def __init__(self):
        super().__init__()
        self.config = _FakeConfig()
        hidden = self.config.hidden_size
        vocab = self.config.vocab_size
        n = self.config.num_hidden_layers

        self.gpt_neox = _FakeGptNeoX(n, hidden)
        # unembed: vocab x hidden
        self._embed_out = torch.nn.Linear(hidden, vocab, bias=False)
        torch.nn.init.eye_(self._embed_out.weight[:hidden, :hidden])

    def get_output_embeddings(self):
        return self._embed_out

    def eval(self):
        return super().eval()

    def forward(self, input_ids=None, output_hidden_states=False, use_cache=False, **kwargs):
        # input_ids: [1, seq]
        batch, seq = input_ids.shape
        hidden = self.config.hidden_size

        # embedding layer output
        h = torch.zeros(batch, seq, hidden)
        h[0, -1, 0] = 1.0  # put signal in dim 0

        all_hidden = [h]
        for layer in self.gpt_neox.layers:
            out = layer(h)
            h = out[0]
            all_hidden.append(h)

        # Apply final layer norm to last hidden state (simulate HF convention)
        h_final = self.gpt_neox.final_layer_norm(h)
        # Replace last entry with ln_f applied version
        all_hidden[-1] = h_final

        logits = self._embed_out(h_final)  # [batch, seq, vocab]
        return _FakeOutput(hidden_states=all_hidden, logits=logits)


class _FakeTokenizer:
    """Minimal tokenizer stub."""
    def __call__(self, text, return_tensors="pt"):
        # Always return a 3-token sequence
        return {"input_ids": torch.tensor([[1, 2, 3]])}

    def encode(self, text, add_special_tokens=False):
        # Map characters to ids deterministically
        return [ord(c) % 16 for c in text[:3]]


# ---------------------------------------------------------------------------
# Test 1: logit_lens output shape
# ---------------------------------------------------------------------------

def test_logit_lens_shape():
    """logit_lens returns [n_prompts, n_layers, top_k] shaped array."""
    from yuragi.analysis.logit_lens import logit_lens

    model = _FakeModel()
    tokenizer = _FakeTokenizer()
    prompts = ["abc", "def"]
    top_k = 3

    result = logit_lens(model, tokenizer, prompts, top_k=top_k)

    # hidden_states has embedding + 4 transformer layers = 5
    n_hidden = 1 + _FakeConfig.num_hidden_layers  # 5
    assert result.shape == (len(prompts), n_hidden, top_k), (
        f"Expected ({len(prompts)}, {n_hidden}, {top_k}), got {result.shape}"
    )


# ---------------------------------------------------------------------------
# Test 2: layer ordering — top-1 prob at last layer >= first layer
# ---------------------------------------------------------------------------

def test_logit_lens_layer_ordering():
    """Probabilities at last layer are at least as concentrated as early layers."""
    from yuragi.analysis.logit_lens import logit_lens

    model = _FakeModel()
    tokenizer = _FakeTokenizer()
    result = logit_lens(model, tokenizer, ["abc"], top_k=1)

    # result shape [1, n_layers, 1] — top-1 prob
    first_layer_prob = result[0, 0, 0]
    last_layer_prob = result[0, -1, 0]
    # The stub scales hidden states up in later layers, concentrating mass
    assert last_layer_prob >= first_layer_prob, (
        f"Expected last layer top-1 prob >= first: {last_layer_prob} < {first_layer_prob}"
    )


# ---------------------------------------------------------------------------
# Test 3: unembedding correctness — final layer matches model logits
# ---------------------------------------------------------------------------

def test_logit_lens_unembedding_correctness():
    """Final layer logit_lens probs must match model's own output logits."""
    from yuragi.analysis.logit_lens import logit_lens

    model = _FakeModel()
    tokenizer = _FakeTokenizer()

    # Get reference probs from model directly
    enc = tokenizer("abc", return_tensors="pt")
    with torch.no_grad():
        out = model(**enc, output_hidden_states=True, use_cache=False)
    ref_probs = F.softmax(out.logits[0, -1, :], dim=-1).numpy()
    ref_top1 = float(np.sort(ref_probs)[::-1][0])

    # logit_lens last layer top-1 prob
    result = logit_lens(model, tokenizer, ["abc"], top_k=1)
    lens_top1 = float(result[0, -1, 0])

    assert abs(lens_top1 - ref_top1) < 1e-5, (
        f"Final layer mismatch: logit_lens={lens_top1:.6f} model={ref_top1:.6f}"
    )


# ---------------------------------------------------------------------------
# Test 4: ln_f application — intermediate layers must go through ln_f
# ---------------------------------------------------------------------------

def test_logit_lens_ln_f_applied():
    """Intermediate layers must go through ln_f in logit_lens.

    Strategy: run a forward-only pass (no logit_lens) to measure the baseline
    number of ln_f calls triggered by the model itself.  Then run logit_lens
    and confirm that *more* ln_f calls occur (the excess equals the number of
    intermediate layers that logit_lens explicitly normalises).
    """
    from yuragi.analysis.logit_lens import logit_lens

    model = _FakeModel()
    tokenizer = _FakeTokenizer()

    call_count = {"n": 0}
    original_forward = model.gpt_neox.final_layer_norm.forward

    def tracking_forward(x):
        call_count["n"] += 1
        return original_forward(x)

    model.gpt_neox.final_layer_norm.forward = tracking_forward

    # Baseline: how many times does a plain forward pass call ln_f?
    enc = tokenizer("abc", return_tensors="pt")
    with torch.no_grad():
        model(**enc, output_hidden_states=True, use_cache=False)
    baseline = call_count["n"]

    # Reset and run logit_lens (also does one internal forward pass, but PLUS
    # n_hidden-1 explicit ln_f applications for intermediate layers)
    call_count["n"] = 0
    logit_lens(model, tokenizer, ["abc"], top_k=2)
    lens_calls = call_count["n"]

    n_hidden = 1 + _FakeConfig.num_hidden_layers  # 5
    # logit_lens internally does:
    #   1 probe forward pass (enc0) to detect n_layers  -> baseline calls
    #   1 actual forward pass for the prompt             -> baseline calls
    #   (n_hidden-1) explicit ln_f calls for intermediate layers
    extra_ln_f = n_hidden - 1  # 4
    expected_total = 2 * baseline + extra_ln_f
    assert lens_calls == expected_total, (
        f"Expected {expected_total} ln_f calls "
        f"(2x{baseline} forward + {extra_ln_f} intermediate), got {lens_calls}"
    )
    assert lens_calls > baseline, (
        "logit_lens must call ln_f more than a bare forward pass"
    )


# ---------------------------------------------------------------------------
# Test 5: causal_trace shape and identify_causal_layer
# ---------------------------------------------------------------------------

def test_causal_trace_shape_and_identify():
    """causal_trace returns [n_layers] array; identify_causal_layer returns valid index."""
    from yuragi.analysis.causal_trace import causal_trace, identify_causal_layer

    model = _FakeModel()
    tokenizer = _FakeTokenizer()

    n_layers = _FakeConfig.num_hidden_layers
    target_token = "a"

    scores = causal_trace(
        model, tokenizer,
        prompt_original="abc",
        prompt_corrupted="Abc",
        target_token=target_token,
    )

    assert scores.shape == (n_layers,), (
        f"Expected ({n_layers},), got {scores.shape}"
    )

    peak = identify_causal_layer(scores)
    assert 0 <= peak < n_layers, f"Peak layer {peak} out of range [0, {n_layers})"
