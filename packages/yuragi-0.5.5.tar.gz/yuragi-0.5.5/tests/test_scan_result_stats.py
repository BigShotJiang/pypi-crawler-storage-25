"""ScanResult statistics boundary tests and Provider/Adapter unit tests."""

import math

import pytest

from yuragi.core import ScanResult
from yuragi.providers.adapter import (
    CompletionResult,
    LLMAdapter,
    ModelCapabilities,
    detect_capabilities,
)

# ---------------------------------------------------------------------------
# fragility_score: bounded 0.0 - 1.0
# ---------------------------------------------------------------------------

class TestFragilityScoreBounds:
    def test_fragility_score_never_below_zero(self, make_scan_result):
        result = make_scan_result(deltas=[0.0, 0.01, -0.01])
        assert result.fragility_score >= 0.0

    def test_fragility_score_never_above_one(self, make_scan_result):
        # Maximum possible std with confidences between 0 and 1
        result = make_scan_result(deltas=[-0.8, 0.0, -0.8, 0.0, -0.8])
        assert result.fragility_score <= 1.0

    def test_fragility_score_with_extreme_variance(self, make_completion, make_perturbation):
        baseline = make_completion("answer", 1.0)
        results = [
            make_perturbation(orig_conf=1.0, pert_conf=0.0)
            for _ in range(50)
        ]
        scan = ScanResult(
            prompt="test", model="m", baseline=baseline, perturbation_results=results
        )
        assert 0.0 <= scan.fragility_score <= 1.0

    def test_fragility_score_with_zero_variance(self, make_scan_result):
        # All identical confidences → std = 0 → score = 0
        result = make_scan_result(deltas=[0.0, 0.0, 0.0, 0.0])
        assert result.fragility_score == pytest.approx(0.0)

    @pytest.mark.parametrize("n_results", [1, 10, 50, 100])
    def test_fragility_score_bounded_for_various_sizes(self, n_results, make_scan_result):
        deltas = [(-1) ** i * 0.3 for i in range(n_results)]
        result = make_scan_result(deltas=deltas)
        assert 0.0 <= result.fragility_score <= 1.0


# ---------------------------------------------------------------------------
# Empty perturbation_results: all properties must be safe
# ---------------------------------------------------------------------------

class TestEmptyScanResult:
    def setup_method(self):
        self.empty = ScanResult(
            prompt="test",
            model="test-model",
            baseline=CompletionResult(text="answer", confidence=0.7, confidence_method="sampling"),
        )

    def test_fragility_score_is_zero(self):
        assert self.empty.fragility_score == 0.0

    def test_confidence_range_is_zero(self):
        assert self.empty.confidence_range == 0.0

    def test_dissociation_rate_is_zero(self):
        assert self.empty.dissociation_rate == 0.0

    def test_max_confidence_drop_is_zero(self):
        assert self.empty.max_confidence_drop == 0.0

    def test_weakest_perturbation_is_none(self):
        assert self.empty.weakest_perturbation is None

    def test_strongest_perturbation_is_none(self):
        assert self.empty.strongest_perturbation is None

    def test_fragility_label_is_steel(self):
        assert self.empty.fragility_label() == "Steel"

    def test_by_type_returns_empty(self):
        assert self.empty.by_type("omit") == []


# ---------------------------------------------------------------------------
# 100 perturbation results: performance (must complete quickly)
# ---------------------------------------------------------------------------

class TestLargeScanResult:
    @pytest.mark.slow
    def test_100_perturbations_fragility_score(self, make_scan_result):
        import time

        deltas = [(-1) ** i * 0.05 for i in range(100)]
        result = make_scan_result(deltas=deltas)
        start = time.monotonic()
        score = result.fragility_score
        elapsed = time.monotonic() - start
        assert 0.0 <= score <= 1.0
        # Must compute in under 50ms
        assert elapsed < 0.05

    def test_100_perturbations_all_properties(self, make_scan_result):
        deltas = [(-1) ** i * 0.1 for i in range(100)]
        result = make_scan_result(deltas=deltas)
        # All properties must return without error
        assert isinstance(result.fragility_score, float)
        assert isinstance(result.confidence_range, float)
        assert isinstance(result.dissociation_rate, float)
        assert isinstance(result.max_confidence_drop, float)
        assert result.weakest_perturbation is not None
        assert result.strongest_perturbation is not None
        assert isinstance(result.fragility_label(), str)

    def test_100_perturbations_dissociation_rate_bounded(self, make_scan_result):
        deltas = [-0.2 for _ in range(100)]  # All answer same, conf drops
        result = make_scan_result(deltas=deltas)
        rate = result.dissociation_rate
        assert 0.0 <= rate <= 1.0


# ---------------------------------------------------------------------------
# dissociation_rate boundary values
# ---------------------------------------------------------------------------

class TestDissociationRateBoundary:
    def test_zero_when_below_noise_floor(self, make_scan_result):
        # v0.4.0: dissociation_rate uses noise_floor (0.06).
        # Deltas below noise floor → dissociation_rate = 0.
        result = make_scan_result(deltas=[0.03, -0.03, 0.04])
        assert result.dissociation_rate == pytest.approx(0.0)

    def test_one_when_all_dissociated(self, make_scan_result):
        # All deltas > noise_floor (0.06) with same answer text
        result = make_scan_result(deltas=[-0.5, -0.5, -0.5])
        assert result.dissociation_rate == pytest.approx(1.0)

    def test_partial_dissociation(self, make_completion, make_perturbation):
        # v0.4.0: only deltas > noise_floor (0.06) with same answer count
        baseline = make_completion("same answer here", 0.8)
        results = [
            make_perturbation("same answer here", "same answer here", 0.8, 0.3),  # delta=0.5 > 0.06 ✓
            make_perturbation("same answer here", "same answer here", 0.8, 0.3),  # delta=0.5 > 0.06 ✓
            make_perturbation("same answer here", "same answer here", 0.8, 0.78),  # delta=0.02 < 0.06 ✗
            make_perturbation("same answer here", "same answer here", 0.8, 0.79),  # delta=0.01 < 0.06 ✗
        ]
        scan = ScanResult(
            prompt="test", model="m", baseline=baseline, perturbation_results=results
        )
        assert scan.dissociation_rate == pytest.approx(0.5)  # 2/4

    def test_answer_changed_does_not_count_as_dissociated(self, make_completion, make_perturbation):
        baseline = make_completion("yes", 0.9)
        results = [
            make_perturbation("yes", "no completely different", 0.9, 0.1),
        ]
        scan = ScanResult(
            prompt="test", model="m", baseline=baseline, perturbation_results=results
        )
        # answer changed → is_dissociated is False even though delta is large
        assert scan.dissociation_rate == pytest.approx(0.0)


# ---------------------------------------------------------------------------
# detect_capabilities: all provider branches
# ---------------------------------------------------------------------------

class TestDetectCapabilities:
    @pytest.mark.parametrize("model,expected_provider,expected_logprobs", [
        ("gpt-4o", "openai", True),
        ("gpt-4o-mini", "openai", True),
        ("gpt-4-turbo", "openai", True),
        ("gpt-4", "openai", True),
        ("gpt-3.5-turbo", "openai", True),
        ("o1", "openai", True),
        ("o1-mini", "openai", True),
        ("o3-mini", "openai", True),
    ])
    def test_openai_models_have_logprobs(self, model, expected_provider, expected_logprobs):
        caps = detect_capabilities(model)
        assert caps.provider == expected_provider
        assert caps.supports_logprobs == expected_logprobs

    @pytest.mark.parametrize("model", [
        "claude-3-opus",
        "claude-sonnet-4-6",
        "claude-haiku",
        "anthropic/claude-3",
    ])
    def test_anthropic_models_no_logprobs(self, model):
        caps = detect_capabilities(model)
        assert caps.provider == "anthropic"
        assert not caps.supports_logprobs

    @pytest.mark.parametrize("model", [
        "gemini-pro",
        "gemini-1.5-flash",
        "google/gemini-ultra",
    ])
    def test_google_models_no_logprobs(self, model):
        caps = detect_capabilities(model)
        assert caps.provider == "google"
        assert not caps.supports_logprobs

    @pytest.mark.parametrize("model,expected_provider", [
        ("ollama/llama3", "ollama"),
        ("ollama/mistral", "ollama"),
        ("ollama_chat/llama2", "ollama"),
        ("huggingface/bert-base", "local"),
        ("vllm/mistral-7b", "local"),
    ])
    def test_local_models_logprobs(self, model, expected_provider):
        caps = detect_capabilities(model)
        assert caps.provider == expected_provider
        assert caps.supports_logprobs  # All local providers now support logprobs

    def test_unknown_model_defaults(self):
        caps = detect_capabilities("some-completely-unknown-model-xyz")
        assert caps.provider == "unknown"
        assert not caps.supports_logprobs

    def test_capabilities_is_model_capabilities_dataclass(self):
        caps = detect_capabilities("gpt-4o")
        assert isinstance(caps, ModelCapabilities)
        assert hasattr(caps, "supports_logprobs")
        assert hasattr(caps, "provider")
        assert hasattr(caps, "max_logprobs")


# ---------------------------------------------------------------------------
# LLMAdapter._text_similarity: boundary values
# ---------------------------------------------------------------------------

class TestTextSimilarity:
    def test_identical_strings_return_one(self):
        assert LLMAdapter._text_similarity("hello world", "hello world") == pytest.approx(1.0)

    def test_empty_both_return_one(self):
        assert LLMAdapter._text_similarity("", "") == pytest.approx(1.0)

    def test_empty_one_side_return_zero(self):
        assert LLMAdapter._text_similarity("hello", "") == pytest.approx(0.0)
        assert LLMAdapter._text_similarity("", "world") == pytest.approx(0.0)

    def test_no_overlap_return_zero(self):
        sim = LLMAdapter._text_similarity("cat sat mat", "dog ran ran")
        assert sim == pytest.approx(0.0)

    def test_partial_overlap(self):
        # Char n-gram overlap (implementation may use word or char ngrams)
        sim = LLMAdapter._text_similarity("cat dog", "cat fish")
        assert 0.0 < sim < 1.0  # Partial overlap, not zero or full

    def test_similarity_is_symmetric(self):
        a = "the quick brown fox"
        b = "the slow brown dog"
        assert LLMAdapter._text_similarity(a, b) == pytest.approx(
            LLMAdapter._text_similarity(b, a)
        )

    def test_similarity_between_zero_and_one(self):
        a = "machine learning is fascinating"
        b = "deep learning is challenging"
        sim = LLMAdapter._text_similarity(a, b)
        assert 0.0 <= sim <= 1.0

    def test_case_insensitive(self):
        assert LLMAdapter._text_similarity("Hello World", "hello world") == pytest.approx(1.0)


# ---------------------------------------------------------------------------
# LLMAdapter._parse_verbalized_confidence: edge cases
# ---------------------------------------------------------------------------

class TestParseVerbalizedConfidence:
    def test_standard_format(self):
        conf, text = LLMAdapter._parse_verbalized_confidence(
            "The answer is 42.\nCONFIDENCE: 80"
        )
        assert conf == pytest.approx(0.8)
        assert "42" in text

    def test_zero_confidence(self):
        conf, _ = LLMAdapter._parse_verbalized_confidence("I don't know.\nCONFIDENCE: 0")
        assert conf == pytest.approx(0.0)

    def test_hundred_confidence(self):
        conf, _ = LLMAdapter._parse_verbalized_confidence("Yes.\nCONFIDENCE: 100")
        assert conf == pytest.approx(1.0)

    def test_over_hundred_clamped_to_one(self):
        conf, _ = LLMAdapter._parse_verbalized_confidence("Yes.\nCONFIDENCE: 150")
        assert conf == pytest.approx(1.0)

    def test_negative_value_not_parsed_returns_default(self):
        # The regex only matches \d+ (no minus sign), so -10 is not captured.
        # The implementation falls back to the default 0.5.
        conf, _ = LLMAdapter._parse_verbalized_confidence("No.\nCONFIDENCE: -10")
        assert conf == pytest.approx(0.5)

    def test_no_confidence_marker_returns_default(self):
        conf, text = LLMAdapter._parse_verbalized_confidence("Just an answer here.")
        assert conf == pytest.approx(0.5)
        assert text == "Just an answer here."

    def test_case_insensitive_marker(self):
        conf, _ = LLMAdapter._parse_verbalized_confidence("Answer.\nconfidence: 75")
        assert conf == pytest.approx(0.75)

    def test_decimal_confidence(self):
        conf, _ = LLMAdapter._parse_verbalized_confidence("Answer.\nCONFIDENCE: 87.5")
        assert conf == pytest.approx(0.875)

    def test_clean_text_strips_marker(self):
        _, text = LLMAdapter._parse_verbalized_confidence(
            "The result is X.\nCONFIDENCE: 90"
        )
        assert "CONFIDENCE" not in text
        assert "90" not in text


# ---------------------------------------------------------------------------
# LLMAdapter._calculate_entropy: mathematical correctness
# ---------------------------------------------------------------------------

class TestCalculateEntropy:
    def _make_adapter(self):
        """Build a minimal adapter without calling litellm."""
        caps = ModelCapabilities(supports_logprobs=True, provider="openai")
        adapter = object.__new__(LLMAdapter)
        adapter.capabilities = caps
        return adapter

    def test_empty_input_returns_zero(self):
        adapter = self._make_adapter()
        assert adapter._calculate_entropy([]) == pytest.approx(0.0)

    def test_empty_token_list_skipped(self):
        adapter = self._make_adapter()
        # Only empty token lists → no entropies computed → returns 0.0
        assert adapter._calculate_entropy([[], []]) == pytest.approx(0.0)

    def test_uniform_distribution_max_entropy(self):
        """4 equally probable tokens → H = ln(4) nats ≈ 1.386."""
        adapter = self._make_adapter()
        # log(0.25) = log(1/4) → four equal logprobs
        lp = math.log(0.25)
        token_probs = [("a", lp), ("b", lp), ("c", lp), ("d", lp)]
        entropy = adapter._calculate_entropy([token_probs])
        assert entropy == pytest.approx(math.log(4), abs=1e-6)

    def test_certain_token_zero_entropy(self):
        """One token with p=1.0 → H = 0."""
        adapter = self._make_adapter()
        token_probs = [("a", 0.0)]  # logprob=0 → prob=1.0
        entropy = adapter._calculate_entropy([token_probs])
        assert entropy == pytest.approx(0.0, abs=1e-6)

    def test_entropy_non_negative(self):
        adapter = self._make_adapter()
        token_probs = [("a", math.log(0.7)), ("b", math.log(0.3))]
        entropy = adapter._calculate_entropy([token_probs])
        assert entropy >= 0.0

    def test_entropy_averages_across_tokens(self):
        """Average of H=0 and H=ln(2) in nats should be ~ln(2)/2."""
        adapter = self._make_adapter()
        certain = [("a", 0.0)]  # H=0
        # Two equal tokens: H = ln(2) nats
        lp = math.log(0.5)
        binary = [("x", lp), ("y", lp)]
        entropy = adapter._calculate_entropy([certain, binary])
        assert entropy == pytest.approx(math.log(2) / 2, abs=1e-6)
