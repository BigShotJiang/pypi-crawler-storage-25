"""Unit tests for yuragi.analysis.sep (Semantic Entropy Probes).

Reference: Kossen et al. 2024, arXiv:2406.15927
"""
from __future__ import annotations

import math

import numpy as np
import pytest

from yuragi.analysis.sep import (
    SemanticEntropyProbe,
    compute_semantic_entropy,
)

# ---------------------------------------------------------------------------
# compute_semantic_entropy
# ---------------------------------------------------------------------------

class TestComputeSemanticEntropy:
    def test_empty_list_returns_zero(self):
        assert compute_semantic_entropy([]) == 0.0

    def test_single_answer_returns_zero(self):
        assert compute_semantic_entropy(["Paris"]) == 0.0

    def test_identical_answers_low_entropy(self):
        # All identical -> 1 cluster -> entropy = 0
        answers = ["Paris is the capital of France."] * 5
        se = compute_semantic_entropy(answers, threshold=0.5)
        assert se == pytest.approx(0.0)

    def test_all_different_answers_high_entropy(self):
        # 4 completely different answers -> 4 clusters -> SE = ln(4)
        answers = [
            "Paris is the capital.",
            "Quantum mechanics involves particles.",
            "The Amazon river flows through Brazil.",
            "Jazz originated in New Orleans.",
        ]
        se = compute_semantic_entropy(answers, threshold=0.85)
        expected = math.log(4)  # ≈ 1.386
        assert se == pytest.approx(expected, abs=0.05)

    def test_two_equal_clusters_entropy(self):
        # 2 samples in cluster A, 2 in cluster B -> SE = ln(2) ≈ 0.693
        answers = [
            "The capital of France is Paris.",
            "The capital of France is Paris.",
            "completely different xyz text abc",
            "completely different xyz text abc",
        ]
        se = compute_semantic_entropy(answers, threshold=0.85)
        assert se == pytest.approx(math.log(2), abs=0.05)

    def test_entropy_increases_with_diversity(self):
        all_same = ["Paris."] * 4
        two_groups = ["Paris.", "Paris.", "London.", "London."]
        all_diff = ["Paris.", "London.", "Berlin.", "Rome."]

        se_same = compute_semantic_entropy(all_same, threshold=0.3)
        se_two = compute_semantic_entropy(two_groups, threshold=0.3)
        se_diff = compute_semantic_entropy(all_diff, threshold=0.8)
        assert se_same <= se_two <= se_diff

    def test_threshold_affects_clustering(self):
        # Moderately similar answers - high threshold -> more clusters -> higher entropy
        answers = ["Paris is the capital", "Paris is the capital of France",
                   "The capital is Paris", "Paris"]
        se_strict = compute_semantic_entropy(answers, threshold=0.9)
        se_lenient = compute_semantic_entropy(answers, threshold=0.1)
        assert se_strict >= se_lenient


# ---------------------------------------------------------------------------
# SemanticEntropyProbe — synthetic fit/predict
# ---------------------------------------------------------------------------

def _make_synthetic_data(
    n_samples: int = 60,
    d_model: int = 32,
    seed: int = 0,
) -> tuple[np.ndarray, np.ndarray]:
    """Generate linearly separable hidden states + SE values."""
    rng = np.random.default_rng(seed)
    # Low-SE cluster: mean vector near +1
    X_low = rng.normal(loc=1.0, scale=0.2, size=(n_samples // 2, d_model))
    # High-SE cluster: mean vector near -1
    X_high = rng.normal(loc=-1.0, scale=0.2, size=(n_samples // 2, d_model))
    X = np.concatenate([X_low, X_high], axis=0).astype(np.float32)
    # Corresponding SE: low = 0.1, high = 1.5
    se_low = np.full(n_samples // 2, 0.1, dtype=np.float32)
    se_high = np.full(n_samples // 2, 1.5, dtype=np.float32)
    se = np.concatenate([se_low, se_high])
    return X, se


class TestSemanticEntropyProbe:
    def test_fit_predict_binary_labels(self):
        X, se = _make_synthetic_data()
        probe = SemanticEntropyProbe(C=1.0, random_state=42)
        probe.fit(X, se)
        preds = probe.predict(X)
        assert preds.shape == (len(X),)
        assert set(preds).issubset({0, 1})

    def test_fit_predict_high_accuracy_linearly_separable(self):
        X, se = _make_synthetic_data(n_samples=100, d_model=32, seed=7)
        probe = SemanticEntropyProbe(C=1.0, random_state=42)
        probe.fit(X, se)
        preds = probe.predict(X)
        # Linearly separable data: expect >= 90% accuracy on training set
        labels = (se > float(np.median(se))).astype(int)
        acc = float((preds == labels).mean())
        assert acc >= 0.90, f"Expected >= 90% accuracy, got {acc:.2%}"

    def test_predict_proba_shape_and_range(self):
        X, se = _make_synthetic_data()
        probe = SemanticEntropyProbe(random_state=42)
        probe.fit(X, se)
        proba = probe.predict_proba(X[:10])
        assert proba.shape == (10, 2)
        assert np.all(proba >= 0.0) and np.all(proba <= 1.0)
        assert np.allclose(proba.sum(axis=1), 1.0, atol=1e-5)

    def test_predict_single_sample_1d(self):
        X, se = _make_synthetic_data()
        probe = SemanticEntropyProbe(random_state=42)
        probe.fit(X, se)
        # 1-D input should work via atleast_2d
        single = X[0]
        pred = probe.predict(single)
        assert pred.shape == (1,)

    def test_predict_before_fit_raises(self):
        probe = SemanticEntropyProbe()
        with pytest.raises(RuntimeError, match="fit"):
            probe.predict(np.zeros((1, 32), dtype=np.float32))

    def test_fit_wrong_ndim_raises(self):
        probe = SemanticEntropyProbe()
        with pytest.raises(ValueError, match="2-D"):
            probe.fit(np.zeros((10,), dtype=np.float32), np.zeros(10))

    def test_fit_mismatched_length_raises(self):
        probe = SemanticEntropyProbe()
        with pytest.raises(ValueError):
            probe.fit(np.zeros((10, 32), dtype=np.float32), np.zeros(9))

    # ------------------------------------------------------------------
    # Save / load
    # ------------------------------------------------------------------

    def test_save_load_roundtrip(self, tmp_path):
        X, se = _make_synthetic_data()
        probe = SemanticEntropyProbe(random_state=42)
        probe.fit(X, se)
        save_path = tmp_path / "probe.pkl"
        probe.save(save_path)
        assert save_path.exists()
        loaded = SemanticEntropyProbe.load(save_path)
        np.testing.assert_array_equal(probe.predict(X), loaded.predict(X))

    def test_save_load_preserves_threshold(self, tmp_path):
        X, se = _make_synthetic_data()
        probe = SemanticEntropyProbe(random_state=42)
        probe.fit(X, se)
        save_path = tmp_path / "probe.pkl"
        probe.save(save_path)
        loaded = SemanticEntropyProbe.load(save_path)
        assert loaded._se_threshold == pytest.approx(probe._se_threshold)

    def test_save_before_fit_raises(self, tmp_path):
        probe = SemanticEntropyProbe()
        with pytest.raises(RuntimeError, match="fit"):
            probe.save(tmp_path / "probe.pkl")

    def test_load_creates_parent_dirs(self, tmp_path):
        X, se = _make_synthetic_data()
        probe = SemanticEntropyProbe(random_state=42)
        probe.fit(X, se)
        deep_path = tmp_path / "a" / "b" / "probe.pkl"
        probe.save(deep_path)
        assert deep_path.exists()

    # ------------------------------------------------------------------
    # Shape checks
    # ------------------------------------------------------------------

    def test_output_shape_matches_input_batch(self):
        X, se = _make_synthetic_data(n_samples=40)
        probe = SemanticEntropyProbe(random_state=42)
        probe.fit(X, se)
        batch = X[:15]
        preds = probe.predict(batch)
        probas = probe.predict_proba(batch)
        assert preds.shape == (15,)
        assert probas.shape == (15, 2)
