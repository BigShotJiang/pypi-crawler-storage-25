"""Unit tests for yuragi.analysis.conformal (SCOPE-inspired conformal prediction).

6 test cases:
  1. split_conformal_interval: coverage rate >= 1 - alpha on held-out set
  2. split_conformal_interval: interval width is symmetric around score
  3. selective_prediction: random labels → AUC near 0.5
  4. selective_prediction: strong signal → AUC improvement at low coverage
  5. conformal_auc: returns coverage_mean >= 1 - alpha for calibrated interval
  6. selective_auc_at_coverage: list length matches requested coverages
"""

from __future__ import annotations

import math

import numpy as np
import pytest

from yuragi.analysis.conformal import (
    conformal_auc,
    selective_auc_at_coverage,
    selective_prediction,
    split_conformal_interval,
)

RNG = np.random.default_rng(42)


# ---------------------------------------------------------------------------
# Case 1: split_conformal_interval — coverage rate >= 1 - alpha
# ---------------------------------------------------------------------------
class TestSplitConformalInterval:
    def test_coverage_rate_above_target(self):
        """Empirical coverage on a held-out set should be >= 1 - alpha."""
        rng = np.random.default_rng(0)
        n = 400
        scores = rng.uniform(0, 1, n)
        labels = (scores + rng.normal(0, 0.15, n) > 0.5).astype(float)

        calib_idx = rng.choice(n, size=200, replace=False)
        test_idx = np.setdiff1d(np.arange(n), calib_idx)

        c_scores = scores[calib_idx]
        c_labels = labels[calib_idx]
        t_scores = scores[test_idx]
        t_labels = labels[test_idx]

        alpha = 0.1
        lower, upper, _q_hat = split_conformal_interval(c_scores, c_labels, t_scores, alpha=alpha)

        covered = ((t_labels >= lower) & (t_labels <= upper)).mean()
        # Marginal coverage guarantee: empirical coverage >= 1 - alpha.
        # Binary labels mapped to 0/1; q_hat inflates interval generously.
        # Allow tolerance of 0.15 to account for discrete label structure.
        assert covered >= (1.0 - alpha) - 0.15, (
            f"Coverage {covered:.3f} is too low (target >= {1-alpha:.2f})"
        )

    def test_interval_width_symmetric_around_score(self):
        """lower = score - q_hat, upper = score + q_hat (before clipping)."""
        calib_scores = np.array([0.3, 0.5, 0.7, 0.8])
        calib_labels = np.array([0.0, 1.0, 1.0, 1.0])
        test_scores = np.array([0.4, 0.6])

        lower, upper, q_hat = split_conformal_interval(
            calib_scores, calib_labels, test_scores, alpha=0.05
        )
        # Width should equal 2 * q_hat (subject to boundary clipping)
        for i in range(len(test_scores)):
            expected_width = min(test_scores[i] + q_hat, 1.0) - max(
                test_scores[i] - q_hat, 0.0
            )
            actual_width = upper[i] - lower[i]
            assert math.isclose(actual_width, expected_width, abs_tol=1e-9), (
                f"Width mismatch at i={i}: {actual_width} vs {expected_width}"
            )

    def test_requires_at_least_two_calibration_samples(self):
        with pytest.raises(ValueError, match=">="):
            split_conformal_interval([0.5], [True], [0.4])


# ---------------------------------------------------------------------------
# Case 3: selective_prediction — random labels → AUC near 0.5
# ---------------------------------------------------------------------------
class TestSelectivePredictionRandom:
    def test_random_labels_auc_near_half(self):
        """With random labels, AUC on selected subset should be near 0.5."""
        rng = np.random.default_rng(7)
        n = 200
        scores = rng.uniform(0, 1, n)
        labels = rng.choice([True, False], size=n, p=[0.5, 0.5])

        result = selective_prediction(scores, labels, coverage_target=0.6, alpha=0.05)
        auc = result["auc"]
        assert not math.isnan(auc), "AUC should be computable for balanced random labels"
        # Allow generous range: 0.3 <= AUC <= 0.7 for random
        assert 0.3 <= auc <= 0.7, f"Random AUC should be near 0.5, got {auc:.3f}"


# ---------------------------------------------------------------------------
# Case 4: selective_prediction — strong signal improves AUC at low coverage
# ---------------------------------------------------------------------------
class TestSelectivePredictionStrongSignal:
    def test_strong_signal_auc_improves_at_low_coverage(self):
        """With clear signal, AUC at 70% coverage should be >= AUC at 90% coverage."""
        rng = np.random.default_rng(13)
        n = 300
        # True labels strongly correlated with scores
        scores = rng.uniform(0, 1, n)
        labels = scores + rng.normal(0, 0.1, n) > 0.5

        result_90 = selective_prediction(scores, labels, coverage_target=0.9)
        result_70 = selective_prediction(scores, labels, coverage_target=0.7)

        auc_90 = result_90["auc"]
        auc_70 = result_70["auc"]

        assert not math.isnan(auc_90)
        assert not math.isnan(auc_70)
        # Lower coverage retains higher-confidence samples → AUC should not drop
        assert auc_70 >= auc_90 - 0.05, (
            f"Selective AUC at 70% ({auc_70:.3f}) should be >= 90% ({auc_90:.3f})"
        )


# ---------------------------------------------------------------------------
# Case 5: conformal_auc — coverage_mean >= 1 - alpha
# ---------------------------------------------------------------------------
class TestConformalAuc:
    def test_coverage_mean_above_target(self):
        """conformal_auc should report empirical coverage >= 1 - alpha."""
        rng = np.random.default_rng(99)
        n = 200
        scores = rng.uniform(0.2, 0.8, n)
        labels = (scores + rng.normal(0, 0.15, n) > 0.5).astype(bool)

        alpha = 0.1
        result = conformal_auc(scores, labels, n_calib_frac=0.5, alpha=alpha, n_iter=50)

        assert result["coverage_mean"] >= (1.0 - alpha) - 0.1, (
            f"Coverage mean {result['coverage_mean']:.3f} too low"
        )
        # AUC should be in valid range
        assert 0.0 <= result["auc_mean"] <= 1.0

    def test_returns_required_keys(self):
        rng = np.random.default_rng(5)
        scores = rng.uniform(0, 1, 80)
        labels = scores > 0.5
        result = conformal_auc(scores, labels, n_iter=20)

        required_keys = {
            "auc_mean", "auc_ci_lower", "auc_ci_upper",
            "coverage_mean", "coverage_ci_lower", "coverage_ci_upper",
            "q_hat_mean", "n", "n_calib", "n_test",
        }
        assert required_keys.issubset(result.keys())


# ---------------------------------------------------------------------------
# Case 6: selective_auc_at_coverage — list length matches coverages
# ---------------------------------------------------------------------------
class TestSelectiveAucAtCoverage:
    def test_list_length_matches_coverages(self):
        rng = np.random.default_rng(3)
        scores = rng.uniform(0, 1, 100)
        labels = scores + rng.normal(0, 0.2, 100) > 0.5

        coverages = [0.5, 0.7, 0.9]
        results = selective_auc_at_coverage(scores, labels, coverages=coverages)

        assert len(results) == len(coverages), (
            f"Expected {len(coverages)} results, got {len(results)}"
        )
        # Results should be sorted descending by coverage_target
        targets = [r["coverage_target"] for r in results]
        assert targets == sorted(targets, reverse=True)

    def test_each_result_has_required_fields(self):
        rng = np.random.default_rng(17)
        scores = rng.uniform(0, 1, 80)
        labels = scores > 0.5

        results = selective_auc_at_coverage(scores, labels, coverages=[0.6, 0.9])
        for r in results:
            assert "auc" in r
            assert "coverage_target" in r
            assert "n_selected" in r
            assert "n_abstained" in r
