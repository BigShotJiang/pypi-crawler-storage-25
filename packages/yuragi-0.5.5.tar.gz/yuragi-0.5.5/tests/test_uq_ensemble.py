"""Unit tests for yuragi.analysis.uq_ensemble."""

from __future__ import annotations

import math

import numpy as np

from yuragi.analysis.uq_ensemble import (
    ablation_leave_one_out,
    build_feature_matrix,
    kfold_ensemble_auc,
)

# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

_RNG = np.random.default_rng(42)
_N = 80


def _make_records(n: int = _N) -> tuple[list[dict], np.ndarray]:
    """確定的な synthetic records + binary labels を生成する。"""
    rng = np.random.default_rng(0)
    bc = rng.uniform(0.1, 0.9, n)
    frag = rng.uniform(0.0, 0.5, n)
    lsc = -rng.uniform(0.5, 3.0, n)  # 負値
    stc = rng.uniform(0.0, 1.0, n)
    # label: bc > 0.5 かつ frag < 0.25 で correct (線形分離可能なシグナル)
    y = ((bc > 0.5) & (frag < 0.25)).astype(int)
    records = [
        {
            "baseline_confidence": float(bc[i]),
            "fragility_score": float(frag[i]),
            "lsc_score": float(lsc[i]),
            "stc_entropy": float(stc[i]),
        }
        for i in range(n)
    ]
    return records, y


_FEATURES = ["baseline_confidence", "fragility_score", "lsc_score", "stc_entropy"]


# ---------------------------------------------------------------------------
# Test 1: build_feature_matrix — shape と欠損補完
# ---------------------------------------------------------------------------


class TestBuildFeatureMatrix:
    def test_shape(self):
        records, _ = _make_records(20)
        X = build_feature_matrix(records, _FEATURES[:2])
        assert X.shape == (20, 2)

    def test_no_nan_after_impute(self):
        records, _ = _make_records(10)
        # 一部を None にする
        records[0]["baseline_confidence"] = None
        records[3]["fragility_score"] = None
        X = build_feature_matrix(records, ["baseline_confidence", "fragility_score"])
        assert not np.isnan(X).any()

    def test_missing_key_imputed(self):
        records = [{"baseline_confidence": 0.5}] * 10
        X = build_feature_matrix(records, ["baseline_confidence", "fragility_score"])
        # fragility_score は全欠損 → 中央値 = nan → 0 で補完されること
        assert X.shape == (10, 2)
        assert not np.isnan(X).any()

    def test_values_match(self):
        records = [{"bc": float(i)} for i in range(5)]
        X = build_feature_matrix(records, ["bc"])
        np.testing.assert_array_almost_equal(X.flatten(), [0, 1, 2, 3, 4])


# ---------------------------------------------------------------------------
# Test 2: CV AUC が 0.5 を超える (シグナルあり synthetic data)
# ---------------------------------------------------------------------------


class TestKfoldEnsembleAuc:
    def test_auc_above_chance(self):
        records, y = _make_records()
        X = build_feature_matrix(records, _FEATURES)
        result = kfold_ensemble_auc(X, y, _FEATURES, k=5, seed=42)
        assert result["auc_oof"] > 0.5, f"AUC={result['auc_oof']:.3f} not above 0.5"

    def test_ci_brackets_auc(self):
        records, y = _make_records()
        X = build_feature_matrix(records, _FEATURES)
        result = kfold_ensemble_auc(X, y, _FEATURES, k=5, seed=42, n_bootstrap=200)
        assert result["ci_lower"] <= result["auc_oof"] <= result["ci_upper"]

    def test_output_keys(self):
        records, y = _make_records(40)
        X = build_feature_matrix(records, _FEATURES[:2])
        result = kfold_ensemble_auc(X, y, _FEATURES[:2], k=5, seed=42, n_bootstrap=50)
        for key in ["auc_oof", "ci_lower", "ci_upper", "p_value_vs_05",
                    "auc_train_mean", "overfitting_gap", "oof_scores",
                    "n_samples", "n_features"]:
            assert key in result, f"Missing key: {key}"

    def test_n_samples_n_features(self):
        records, y = _make_records(60)
        X = build_feature_matrix(records, _FEATURES[:3])
        result = kfold_ensemble_auc(X, y, _FEATURES[:3], k=5, seed=42, n_bootstrap=50)
        assert result["n_samples"] == 60
        assert result["n_features"] == 3


# ---------------------------------------------------------------------------
# Test 3: ablation_leave_one_out — 構造と delta_auc
# ---------------------------------------------------------------------------


class TestAblationLeaveOneOut:
    def test_length_equals_n_features(self):
        records, y = _make_records()
        X = build_feature_matrix(records, _FEATURES)
        ablations = ablation_leave_one_out(X, y, _FEATURES, k=5, seed=42, n_bootstrap=100)
        assert len(ablations) == len(_FEATURES)

    def test_sorted_by_delta_desc(self):
        records, y = _make_records()
        X = build_feature_matrix(records, _FEATURES)
        ablations = ablation_leave_one_out(X, y, _FEATURES, k=5, seed=42, n_bootstrap=100)
        deltas = [a["delta_auc"] for a in ablations]
        assert deltas == sorted(deltas, reverse=True)

    def test_all_features_present(self):
        records, y = _make_records()
        X = build_feature_matrix(records, _FEATURES)
        ablations = ablation_leave_one_out(X, y, _FEATURES, k=5, seed=42, n_bootstrap=100)
        returned_feats = {a["feature"] for a in ablations}
        assert returned_feats == set(_FEATURES)


# ---------------------------------------------------------------------------
# Test 4: 正則化の効果 — C が小さいと AUC が変化する
# ---------------------------------------------------------------------------


class TestRegularization:
    def test_high_vs_low_regularization(self):
        records, y = _make_records()
        X = build_feature_matrix(records, _FEATURES)
        res_high_C = kfold_ensemble_auc(X, y, _FEATURES, k=5, seed=42, C=100.0, n_bootstrap=100)
        res_low_C = kfold_ensemble_auc(X, y, _FEATURES, k=5, seed=42, C=0.001, n_bootstrap=100)
        # 結果が変わることを確認 (overfitting_gap が異なるはず)
        assert res_high_C["auc_oof"] != res_low_C["auc_oof"] or \
               res_high_C["overfitting_gap"] != res_low_C["overfitting_gap"]


# ---------------------------------------------------------------------------
# Test 5: length-residualized 前後での AUC 変化
# ---------------------------------------------------------------------------


class TestLengthResidualizedAuc:
    def test_length_resid_does_not_break_auc(self):
        """length_residualize を適用した後もモジュールが壊れないことを確認。"""
        from yuragi.analysis.bias_correct import length_residualize

        records, y = _make_records()
        n_tokens = np.array([len(str(r)) for r in records], dtype=float)
        X = build_feature_matrix(records, ["baseline_confidence", "fragility_score"])

        # length-residualize each column
        X_resid = X.copy()
        for j in range(X.shape[1]):
            X_resid[:, j] = length_residualize(X[:, j], n_tokens)

        result = kfold_ensemble_auc(X_resid, y, ["bc_resid", "frag_resid"],
                                    k=5, seed=42, n_bootstrap=100)
        assert not math.isnan(result["auc_oof"])
        assert 0.0 <= result["auc_oof"] <= 1.0
