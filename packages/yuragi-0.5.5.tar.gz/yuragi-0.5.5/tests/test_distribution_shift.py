"""Unit tests for distribution_shift.py (Round 6-A utility)."""

from __future__ import annotations

import math

import pytest

from yuragi.analysis.distribution_shift import (
    hellinger_distance,
    js_divergence,
    logprobs_to_dist,
)

# ---------------------------------------------------------------------------
# hellinger_distance
# ---------------------------------------------------------------------------

class TestHellingerDistance:
    def test_identical_distributions_zero(self):
        """H(p, p) == 0."""
        p = [0.25, 0.25, 0.25, 0.25]
        assert hellinger_distance(p, p) == pytest.approx(0.0, abs=1e-12)

    def test_uniform_uniform_zero(self):
        """Two identical uniforms → 0."""
        p = [1.0, 1.0, 1.0, 1.0, 1.0]
        q = [1.0, 1.0, 1.0, 1.0, 1.0]
        assert hellinger_distance(p, q) == pytest.approx(0.0, abs=1e-12)

    def test_delta_vs_uniform_near_one(self):
        """Delta mass vs uniform → Hellinger near 1 for large n."""
        # H(δ₀, U_n) = sqrt(1 - 1/sqrt(n)) — for n=5: sqrt(1 - 1/sqrt(5)) ≈ 0.795
        n = 5
        delta = [1.0] + [0.0] * (n - 1)
        uniform = [1.0] * n
        h = hellinger_distance(delta, uniform)
        expected = math.sqrt(1.0 - 1.0 / math.sqrt(n))
        assert h == pytest.approx(expected, rel=1e-6)
        assert h > 0.7

    def test_symmetry(self):
        """H(p, q) == H(q, p)."""
        p = [0.5, 0.3, 0.2]
        q = [0.1, 0.6, 0.3]
        assert hellinger_distance(p, q) == pytest.approx(hellinger_distance(q, p), abs=1e-12)

    def test_range_zero_to_one(self):
        """Result is always in [0, 1]."""
        p = [0.9, 0.05, 0.03, 0.01, 0.01]
        q = [0.01, 0.01, 0.03, 0.05, 0.9]
        h = hellinger_distance(p, q)
        assert 0.0 <= h <= 1.0

    def test_unnormalised_inputs_same_result(self):
        """Unnormalised inputs should give the same result as normalised."""
        p = [2.0, 2.0]
        q = [1.0, 1.0]
        h_unnorm = hellinger_distance(p, q)
        h_norm = hellinger_distance([0.5, 0.5], [0.5, 0.5])
        assert h_unnorm == pytest.approx(h_norm, abs=1e-12)

    def test_length_mismatch_raises(self):
        with pytest.raises(ValueError, match="equal length"):
            hellinger_distance([0.5, 0.5], [0.3, 0.3, 0.4])

    def test_empty_raises(self):
        with pytest.raises(ValueError):
            hellinger_distance([], [])


# ---------------------------------------------------------------------------
# js_divergence
# ---------------------------------------------------------------------------

class TestJSDivergence:
    def test_identical_distributions_zero(self):
        """JSD(p, p) == 0."""
        p = [0.2, 0.3, 0.5]
        assert js_divergence(p, p) == pytest.approx(0.0, abs=1e-9)

    def test_disjoint_support_max(self):
        """Disjoint supports → JSD = log(2)."""
        p = [1.0, 0.0]
        q = [0.0, 1.0]
        jsd = js_divergence(p, q)
        assert jsd == pytest.approx(math.log(2), rel=1e-3)

    def test_symmetry(self):
        """JSD(p, q) == JSD(q, p)."""
        p = [0.6, 0.3, 0.1]
        q = [0.1, 0.5, 0.4]
        assert js_divergence(p, q) == pytest.approx(js_divergence(q, p), abs=1e-12)

    def test_non_negative(self):
        """JSD >= 0 always."""
        p = [0.4, 0.4, 0.2]
        q = [0.1, 0.8, 0.1]
        assert js_divergence(p, q) >= 0.0

    def test_length_mismatch_raises(self):
        with pytest.raises(ValueError, match="equal length"):
            js_divergence([0.5, 0.5], [0.3, 0.3, 0.4])


# ---------------------------------------------------------------------------
# logprobs_to_dist
# ---------------------------------------------------------------------------

class TestLogprobsToDist:
    def test_basic_conversion(self):
        """logprob → probability via exp, then normalised."""
        pairs = [("the", -0.1), ("a", -1.2), ("an", -2.3), ("this", -3.4), ("that", -4.5)]
        tokens, probs = logprobs_to_dist(pairs, k=5)
        assert tokens == ["the", "a", "an", "this", "that"]
        assert len(probs) == 5
        assert sum(probs) == pytest.approx(1.0, abs=1e-9)
        # "the" has highest logprob → highest prob
        assert probs[0] == max(probs)

    def test_k_truncation(self):
        """k=3 returns only top 3 tokens."""
        pairs = [("a", -0.5), ("b", -1.0), ("c", -1.5), ("d", -2.0), ("e", -2.5)]
        tokens, probs = logprobs_to_dist(pairs, k=3)
        assert len(tokens) == 3
        assert len(probs) == 3
        assert sum(probs) == pytest.approx(1.0, abs=1e-9)

    def test_empty_raises(self):
        with pytest.raises(ValueError):
            logprobs_to_dist([], k=5)

    def test_negative_logprobs_normalised(self):
        """Negative logprobs (log-probabilities) are handled correctly via exp."""
        pairs = [("yes", -0.5), ("no", -1.5), ("maybe", -3.0)]
        _tokens, probs = logprobs_to_dist(pairs, k=3)
        assert sum(probs) == pytest.approx(1.0, abs=1e-9)
        assert all(p >= 0.0 for p in probs)
        # highest logprob → highest prob
        assert probs[0] > probs[1] > probs[2]

    def test_very_negative_logprobs_no_nan(self):
        """Extreme negative logprobs (near -700) must not produce NaN/Inf."""
        pairs = [("tok_a", -0.1), ("tok_b", -600.0), ("tok_c", -699.0)]
        _tokens, probs = logprobs_to_dist(pairs, k=3)
        assert sum(probs) == pytest.approx(1.0, abs=1e-9)
        assert all(math.isfinite(p) for p in probs)
        # tok_b and tok_c flush to ~0 but tok_a dominates
        assert probs[0] > 0.999


# ---------------------------------------------------------------------------
# Hellinger additional edge cases
# ---------------------------------------------------------------------------

class TestHellingerEdgeCases:
    def test_disjoint_one_hot_max(self):
        """Disjoint one-hot distributions → H == 1.0."""
        p = [1.0, 0.0]
        q = [0.0, 1.0]
        assert hellinger_distance(p, q) == pytest.approx(1.0, abs=1e-12)

    def test_empty_raises(self):
        with pytest.raises(ValueError):
            hellinger_distance([], [])

    def test_zero_sum_raises(self):
        with pytest.raises(ValueError, match="positive"):
            hellinger_distance([0.0, 0.0], [0.5, 0.5])

    def test_result_finite_for_near_zero_mass(self):
        """Near-zero mass entries must not produce NaN."""
        p = [1e-300, 1.0]
        q = [1.0, 1e-300]
        h = hellinger_distance(p, q)
        assert math.isfinite(h)
        assert 0.0 <= h <= 1.0


# ---------------------------------------------------------------------------
# JS divergence additional edge cases
# ---------------------------------------------------------------------------

class TestJSDivergenceEdgeCases:
    def test_empty_raises(self):
        with pytest.raises(ValueError):
            js_divergence([], [])

    def test_zero_sum_raises(self):
        with pytest.raises(ValueError, match="positive"):
            js_divergence([0.0, 0.0], [0.5, 0.5])

    def test_disjoint_one_hot_log2(self):
        """Disjoint one-hot → JSD == log(2) (maximum)."""
        p = [1.0, 0.0]
        q = [0.0, 1.0]
        assert js_divergence(p, q) == pytest.approx(math.log(2), rel=1e-6)

    def test_range_zero_to_log2(self):
        p = [0.9, 0.05, 0.03, 0.01, 0.01]
        q = [0.01, 0.01, 0.03, 0.05, 0.9]
        jsd = js_divergence(p, q)
        assert 0.0 <= jsd <= math.log(2) + 1e-9
