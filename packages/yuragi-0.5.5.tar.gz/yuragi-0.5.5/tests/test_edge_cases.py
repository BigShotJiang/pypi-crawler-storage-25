"""Edge case tests for v0.4.0 robustness."""

from __future__ import annotations

import math

import pytest

from yuragi.core import PerturbationResult, ScanResult
from yuragi.metrics.statistical_tests import bootstrap_ci, compare_fragility
from yuragi.metrics.volatility import confidence_sharpe, realized_volatility
from yuragi.providers.adapter import CompletionResult, LLMAdapter

# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def _cr(
    text: str = "answer",
    confidence: float = 0.8,
    method: str = "sampling",
) -> CompletionResult:
    return CompletionResult(
        text=text,
        confidence=confidence,
        confidence_method=method,
        raw_logprobs=None,
    )


def _pr(
    orig_conf: float = 0.8,
    pert_conf: float = 0.8,
    ptype: str = "omit",
) -> PerturbationResult:
    return PerturbationResult(
        original_prompt="prompt",
        perturbed_prompt="prompt modified",
        perturbation_type=ptype,
        original_response=_cr("orig", orig_conf),
        perturbed_response=_cr("pert", pert_conf),
    )


def _scan(deltas: list[float], model: str = "test-model") -> ScanResult:
    baseline_conf = 0.8
    return ScanResult(
        prompt="test",
        model=model,
        baseline=_cr("baseline", baseline_conf),
        perturbation_results=[_pr(baseline_conf, baseline_conf + d) for d in deltas],
    )


def _adapter() -> LLMAdapter:
    return LLMAdapter.__new__(LLMAdapter)


# ---------------------------------------------------------------------------
# _calculate_entropy: k=1 and empty
# ---------------------------------------------------------------------------


class TestCalculateEntropyEdgeCases:
    def test_calculate_entropy_k1(self):
        """k=1 logprobs should not cause zero-division."""
        adapter = _adapter()
        # Single token with full mass: logprob=0 (prob=1)
        logprobs = [("token", 0.0)]
        entropy = adapter._calculate_entropy(logprobs)
        # H = -(1 * log(1)) = 0
        assert entropy == pytest.approx(0.0, abs=1e-6)

    def test_calculate_entropy_empty(self):
        """Empty logprobs should return 0.0."""
        adapter = _adapter()
        assert adapter._calculate_entropy([]) == pytest.approx(0.0)

    def test_confidence_k1_fallback(self):
        """When k=1, k=max(k,2) guard ensures no zero-division in adapter."""
        adapter = _adapter()
        logprobs_k1 = [[("token", 0.0)]]
        entropy = adapter._calculate_entropy(logprobs_k1)
        k = len(logprobs_k1[0])  # k=1
        k = max(k, 2)  # guard applied in adapter
        max_entropy = math.log(k)
        assert max_entropy > 0
        normalized = entropy / max_entropy
        confidence = max(0.0, min(1.0, 1.0 - normalized))
        assert 0.0 <= confidence <= 1.0


# ---------------------------------------------------------------------------
# bootstrap_ci: n<2
# ---------------------------------------------------------------------------


class TestBootstrapCIEdgeCases:
    def test_bootstrap_ci_n0(self):
        """bootstrap_ci([]) should raise ValueError (empty)."""
        with pytest.raises(ValueError, match="empty"):
            bootstrap_ci([])

    def test_bootstrap_ci_n1(self):
        """bootstrap_ci with single value should return None."""
        result = bootstrap_ci([0.5])
        assert result is None

    def test_compare_fragility_small_n(self):
        """compare_fragility with n<2 should not crash."""
        scan_a = _scan([])
        scan_b = _scan([])
        result = compare_fragility(scan_a, scan_b)
        assert result["bootstrap_ci_a"] is None
        assert result["bootstrap_ci_b"] is None

    def test_compare_fragility_one_delta(self):
        """compare_fragility with exactly 1 delta should return None CI."""
        scan_a = _scan([-0.1])
        scan_b = _scan([-0.2])
        result = compare_fragility(scan_a, scan_b)
        assert result["bootstrap_ci_a"] is None
        assert result["bootstrap_ci_b"] is None

    def test_compare_fragility_two_deltas(self):
        """compare_fragility with n>=2 should return CIResult, not None."""
        scan_a = _scan([-0.1, -0.2])
        scan_b = _scan([-0.1, -0.2])
        result = compare_fragility(scan_a, scan_b)
        assert result["bootstrap_ci_a"] is not None
        assert result["bootstrap_ci_b"] is not None


# ---------------------------------------------------------------------------
# _measure_agreement: edge cases
# ---------------------------------------------------------------------------


class TestMeasureAgreementEdgeCases:
    def test_measure_agreement_empty(self):
        """Agreement with 0 responses = 0.5."""
        adapter = _adapter()
        assert adapter._measure_agreement([]) == pytest.approx(0.5)

    def test_measure_agreement_single(self):
        """Agreement with 1 response = 0.5."""
        adapter = _adapter()
        assert adapter._measure_agreement(["one response"]) == pytest.approx(0.5)

    def test_measure_agreement_identical(self):
        """Identical responses = 1.0."""
        adapter = _adapter()
        result = adapter._measure_agreement(["same answer", "same answer", "same answer"])
        assert result == pytest.approx(1.0)

    def test_measure_agreement_different(self):
        """Completely different responses should have low similarity."""
        adapter = _adapter()
        responses = [
            "aaa bbb ccc ddd eee fff",
            "zzz yyy xxx www vvv uuu",
        ]
        result = adapter._measure_agreement(responses)
        assert result < 0.5


# ---------------------------------------------------------------------------
# realized_volatility: sample variance
# ---------------------------------------------------------------------------


class TestRealizedVolatilitySampleVariance:
    def test_realized_volatility_n1(self):
        """Single confidence should return 0.0, not crash."""
        assert realized_volatility([_pr(pert_conf=0.8)]) == 0.0

    def test_realized_volatility_two_results_returns_zero(self):
        """Two results → 1 log-return → n<2 guard → 0.0."""
        results = [_pr(pert_conf=0.8), _pr(pert_conf=0.4)]
        assert realized_volatility(results) == pytest.approx(0.0, abs=1e-9)

    def test_realized_volatility_sample_vs_population(self):
        """Verify sample variance (n-1 denominator) is used.

        With 3 results we get 2 log-returns, so both sample and population
        variance are non-zero. Sample variance > population variance (n-1 < n).
        """
        import math as _math

        results = [_pr(pert_conf=c) for c in [0.9, 0.5, 0.8]]
        rv = realized_volatility(results)

        eps = 1e-9
        confs = [0.9, 0.5, 0.8]
        log_returns = [
            _math.log(max(confs[i], eps) / max(confs[i - 1], eps))
            for i in range(1, len(confs))
        ]
        n = len(log_returns)
        mean = sum(log_returns) / n
        # sample variance
        sample_var = sum((r - mean) ** 2 for r in log_returns) / (n - 1)
        expected_rv = _math.sqrt(sample_var) * _math.sqrt(n)

        assert rv == pytest.approx(expected_rv, rel=1e-6)

    def test_confidence_sharpe_sample_variance(self):
        """confidence_sharpe uses sample variance (n-1)."""
        import math as _math

        results = [_pr(pert_conf=c) for c in [0.6, 0.8, 0.7]]
        sharpe = confidence_sharpe(results)
        confs = [0.6, 0.8, 0.7]
        n = len(confs)
        mean = sum(confs) / n
        sample_var = sum((c - mean) ** 2 for c in confs) / (n - 1)
        std = _math.sqrt(sample_var)
        expected = mean / std if std > 1e-9 else 0.0
        assert sharpe == pytest.approx(expected, rel=1e-6)
