"""Tests for the Section 16 phase transition experiment module.

Tests the graduated prefix ladder protocol for detecting first-order
regime shifts in LLM generation strategy. Uses mocked LLM responses
to validate order parameter computation, susceptibility estimation,
and regime shift detection without requiring live API access.
"""

from __future__ import annotations

import math

import pytest

from yuragi.experiments.phase_transition import (
    DEFAULT_PREFIX_LADDER,
    LevelMeasurement,
    LevelResult,
    PhaseTransitionResult,
    _compute_token_entropy,
    _max_entropy_diff,
    compute_susceptibility,
    detect_regime_shift,
    run_phase_transition,
)
from yuragi.providers.adapter import CompletionResult

# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def _make_measurement(
    *,
    lambda_val: float = 0.0,
    prefix: str = "",
    response_text: str = "The capital of France is Paris.",
    confidence: float = 0.95,
    logprob_entropy: float | None = 0.05,
    raw_logprobs: list | None = None,
    token_count: int = 8,
) -> LevelMeasurement:
    return LevelMeasurement(
        lambda_val=lambda_val,
        prefix=prefix,
        prompt=prefix + "What is the capital of France?",
        response_text=response_text,
        confidence=confidence,
        confidence_method="logprob",
        logprob_entropy=logprob_entropy,
        raw_logprobs=raw_logprobs,
        token_count=token_count,
    )


def _make_level(
    *,
    lambda_val: float,
    phi1: float = 0.9,
    phi2: float = 0.01,
    phi3: float = 0.02,
    susceptibility: float = 0.001,
) -> LevelResult:
    return LevelResult(
        lambda_val=lambda_val,
        prefix=f"prefix_{lambda_val}",
        rationale="test",
        phi1_text_similarity=phi1,
        phi2_entropy_jump=phi2,
        phi3_confidence_delta=phi3,
        mean_confidence=0.9 - phi3,
        mean_entropy=0.1,
        mean_response_length=10.0,
        susceptibility=susceptibility,
    )


# ---------------------------------------------------------------------------
# DEFAULT_PREFIX_LADDER
# ---------------------------------------------------------------------------


class TestDefaultPrefixLadder:
    def test_has_eleven_levels(self):
        assert len(DEFAULT_PREFIX_LADDER) == 11

    def test_starts_at_zero(self):
        assert DEFAULT_PREFIX_LADDER[0][0] == 0.0
        assert DEFAULT_PREFIX_LADDER[0][1] == ""

    def test_ends_at_one(self):
        assert DEFAULT_PREFIX_LADDER[-1][0] == 1.0

    def test_monotonically_increasing(self):
        lambdas = [lam for lam, _, _ in DEFAULT_PREFIX_LADDER]
        for i in range(1, len(lambdas)):
            assert lambdas[i] > lambdas[i - 1]

    def test_each_entry_has_three_elements(self):
        for entry in DEFAULT_PREFIX_LADDER:
            assert len(entry) == 3
            assert isinstance(entry[0], float)
            assert isinstance(entry[1], str)
            assert isinstance(entry[2], str)

    def test_scholarly_prefix_present(self):
        prefixes = [prefix for _, prefix, _ in DEFAULT_PREFIX_LADDER]
        assert any("scholarly" in p.lower() for p in prefixes)


# ---------------------------------------------------------------------------
# _compute_token_entropy
# ---------------------------------------------------------------------------


class TestComputeTokenEntropy:
    def test_none_input(self):
        assert _compute_token_entropy(None) == []

    def test_empty_input(self):
        assert _compute_token_entropy([]) == []

    def test_single_token_deterministic(self):
        # Single token with probability ~1.0
        logprobs = [[("the", 0.0)]]  # log(1.0) = 0.0
        entropies = _compute_token_entropy(logprobs)
        assert len(entropies) == 1
        assert entropies[0] == pytest.approx(0.0, abs=1e-6)

    def test_uniform_distribution_max_entropy(self):
        # 4 tokens with equal probability -> entropy = ln(4)
        lp = math.log(0.25)
        logprobs = [[("a", lp), ("b", lp), ("c", lp), ("d", lp)]]
        entropies = _compute_token_entropy(logprobs)
        assert len(entropies) == 1
        assert entropies[0] == pytest.approx(math.log(4), abs=0.01)

    def test_two_position_sequence(self):
        # Position 0: deterministic, Position 1: uniform(2)
        lp_half = math.log(0.5)
        logprobs = [
            [("the", 0.0)],
            [("cat", lp_half), ("dog", lp_half)],
        ]
        entropies = _compute_token_entropy(logprobs)
        assert len(entropies) == 2
        assert entropies[0] == pytest.approx(0.0, abs=1e-6)
        assert entropies[1] == pytest.approx(math.log(2), abs=0.01)

    def test_empty_token_probs_gives_zero(self):
        logprobs = [[]]
        entropies = _compute_token_entropy(logprobs)
        assert entropies == [0.0]


# ---------------------------------------------------------------------------
# _max_entropy_diff
# ---------------------------------------------------------------------------


class TestMaxEntropyDiff:
    def test_both_none(self):
        assert _max_entropy_diff(None, None) == 0.0

    def test_baseline_none(self):
        assert _max_entropy_diff(None, [[("a", 0.0)]]) == 0.0

    def test_target_none(self):
        assert _max_entropy_diff([[("a", 0.0)]], None) == 0.0

    def test_identical_sequences(self):
        lp = [[("the", 0.0)], [("cat", math.log(0.5)), ("dog", math.log(0.5))]]
        assert _max_entropy_diff(lp, lp) == pytest.approx(0.0, abs=1e-6)

    def test_one_position_differs(self):
        baseline = [[("the", 0.0)]]  # H = 0
        lp_half = math.log(0.5)
        target = [[("the", lp_half), ("a", lp_half)]]  # H = ln(2)
        diff = _max_entropy_diff(baseline, target)
        assert diff == pytest.approx(math.log(2), abs=0.01)

    def test_different_lengths_uses_shorter(self):
        baseline = [[("a", 0.0)], [("b", 0.0)]]
        target = [[("a", 0.0)]]
        # Only position 0 compared, both deterministic
        assert _max_entropy_diff(baseline, target) == pytest.approx(0.0, abs=1e-6)


# ---------------------------------------------------------------------------
# LevelResult.is_regime_shift
# ---------------------------------------------------------------------------


class TestLevelResultRegimeShift:
    def test_all_criteria_met(self):
        lv = _make_level(lambda_val=0.8, phi1=0.1, phi2=0.8, phi3=0.3)
        assert lv.is_regime_shift is True

    def test_phi1_too_high(self):
        lv = _make_level(lambda_val=0.8, phi1=0.5, phi2=0.8, phi3=0.3)
        assert lv.is_regime_shift is False

    def test_phi2_too_low(self):
        lv = _make_level(lambda_val=0.8, phi1=0.1, phi2=0.3, phi3=0.3)
        assert lv.is_regime_shift is False

    def test_phi3_too_low(self):
        lv = _make_level(lambda_val=0.8, phi1=0.1, phi2=0.8, phi3=0.1)
        assert lv.is_regime_shift is False

    def test_baseline_not_regime_shift(self):
        lv = _make_level(lambda_val=0.0, phi1=1.0, phi2=0.0, phi3=0.0)
        assert lv.is_regime_shift is False


# ---------------------------------------------------------------------------
# PhaseTransitionResult
# ---------------------------------------------------------------------------


class TestPhaseTransitionResult:
    def _make_result_with_peak(self) -> PhaseTransitionResult:
        """Simulate a phase transition at lambda=0.8."""
        levels = [
            _make_level(lambda_val=0.0, susceptibility=0.001),
            _make_level(lambda_val=0.2, susceptibility=0.002),
            _make_level(lambda_val=0.4, susceptibility=0.003),
            _make_level(lambda_val=0.6, susceptibility=0.005),
            _make_level(
                lambda_val=0.8,
                phi1=0.1,
                phi2=0.8,
                phi3=0.3,
                susceptibility=0.050,  # 10x median
            ),
            _make_level(lambda_val=1.0, susceptibility=0.008),
        ]
        return PhaseTransitionResult(
            base_prompt="What is the capital of France?",
            model="ollama/llama3.2",
            repeats=5,
            levels=levels,
        )

    def _make_flat_result(self) -> PhaseTransitionResult:
        """No peak: all susceptibilities are similar."""
        levels = [
            _make_level(lambda_val=i * 0.2, susceptibility=0.005)
            for i in range(6)
        ]
        return PhaseTransitionResult(
            base_prompt="test",
            model="test",
            repeats=5,
            levels=levels,
        )

    def test_critical_lambda_at_peak(self):
        result = self._make_result_with_peak()
        assert result.critical_lambda == 0.8

    def test_critical_lambda_none_when_flat(self):
        result = self._make_flat_result()
        assert result.critical_lambda is None

    def test_regime_shift_detected(self):
        result = self._make_result_with_peak()
        assert result.regime_shift_detected is True

    def test_regime_shift_lambda(self):
        result = self._make_result_with_peak()
        assert result.regime_shift_lambda == 0.8

    def test_no_regime_shift_in_flat(self):
        result = self._make_flat_result()
        assert result.regime_shift_detected is False
        assert result.regime_shift_lambda is None

    def test_summary_keys(self):
        result = self._make_result_with_peak()
        s = result.summary()
        assert "base_prompt" in s
        assert "model" in s
        assert "critical_lambda" in s
        assert "regime_shift_detected" in s
        assert "levels" in s
        assert len(s["levels"]) == 6

    def test_summary_level_keys(self):
        result = self._make_result_with_peak()
        s = result.summary()
        level = s["levels"][0]
        assert "lambda" in level
        assert "phi1_sim" in level
        assert "phi2_entropy" in level
        assert "phi3_conf" in level
        assert "susceptibility" in level
        assert "is_regime_shift" in level

    def test_empty_result(self):
        result = PhaseTransitionResult(
            base_prompt="test", model="test", repeats=0
        )
        assert result.critical_lambda is None
        assert result.regime_shift_detected is False


# ---------------------------------------------------------------------------
# detect_regime_shift
# ---------------------------------------------------------------------------


class TestDetectRegimeShift:
    def test_detects_shift(self):
        levels = [
            _make_level(lambda_val=0.0),
            _make_level(lambda_val=0.5),
            _make_level(lambda_val=0.8, phi1=0.1, phi2=0.8, phi3=0.3),
        ]
        result = PhaseTransitionResult(
            base_prompt="test", model="test", repeats=5, levels=levels
        )
        shifts = detect_regime_shift(result)
        assert len(shifts) == 1
        assert shifts[0][0] == 0.8  # lambda

    def test_no_shift_with_smooth_decrease(self):
        levels = [
            _make_level(lambda_val=0.0, phi1=1.0, phi2=0.0, phi3=0.0),
            _make_level(lambda_val=0.5, phi1=0.7, phi2=0.2, phi3=0.05),
            _make_level(lambda_val=1.0, phi1=0.5, phi2=0.3, phi3=0.1),
        ]
        result = PhaseTransitionResult(
            base_prompt="test", model="test", repeats=5, levels=levels
        )
        shifts = detect_regime_shift(result)
        assert len(shifts) == 0

    def test_custom_thresholds(self):
        levels = [
            _make_level(lambda_val=0.8, phi1=0.25, phi2=0.6, phi3=0.2),
        ]
        result = PhaseTransitionResult(
            base_prompt="test", model="test", repeats=5, levels=levels
        )
        # With default thresholds: phi1 < 0.3 and phi2 > 0.5 and phi3 > 0.15
        shifts = detect_regime_shift(result)
        assert len(shifts) == 1

        # Tighten phi1 threshold
        shifts_tight = detect_regime_shift(result, tau_sim=0.2)
        assert len(shifts_tight) == 0


# ---------------------------------------------------------------------------
# compute_susceptibility
# ---------------------------------------------------------------------------


class TestComputeSusceptibility:
    def test_sorted_by_lambda(self):
        levels = [
            _make_level(lambda_val=0.5, susceptibility=0.01),
            _make_level(lambda_val=0.0, susceptibility=0.001),
            _make_level(lambda_val=1.0, susceptibility=0.02),
        ]
        result = PhaseTransitionResult(
            base_prompt="test", model="test", repeats=5, levels=levels
        )
        chi = compute_susceptibility(result)
        assert chi == [(0.0, 0.001), (0.5, 0.01), (1.0, 0.02)]

    def test_empty_result(self):
        result = PhaseTransitionResult(
            base_prompt="test", model="test", repeats=5
        )
        assert compute_susceptibility(result) == []


# ---------------------------------------------------------------------------
# run_phase_transition (with mocked adapter)
# ---------------------------------------------------------------------------


class TestRunPhaseTransition:
    def test_integration_with_mock(self, monkeypatch):
        """Verify the full pipeline runs with a mocked LLMAdapter."""
        call_count = 0

        class MockAdapter:
            def __init__(self, **kwargs):
                pass

            def complete(self, prompt: str) -> CompletionResult:
                nonlocal call_count
                call_count += 1

                # Simulate regime shift for scholarly prefix
                if "scholarly" in prompt.lower() or "academic essay" in prompt.lower():
                    return CompletionResult(
                        text="A question that may seem straightforward...",
                        confidence=0.45,
                        confidence_method="logprob",
                        logprob_entropy=0.8,
                        raw_logprobs=[
                            [("A", math.log(0.3)), ("The", math.log(0.7))],
                            [("question", math.log(0.5)), ("topic", math.log(0.5))],
                        ],
                        token_count=15,
                    )
                else:
                    return CompletionResult(
                        text="The capital of France is Paris.",
                        confidence=0.95,
                        confidence_method="logprob",
                        logprob_entropy=0.05,
                        raw_logprobs=[
                            [("The", math.log(0.99)), ("A", math.log(0.01))],
                            [("capital", math.log(0.98)), ("city", math.log(0.02))],
                        ],
                        token_count=8,
                    )

        monkeypatch.setattr(
            "yuragi.experiments.phase_transition.LLMAdapter", MockAdapter
        )

        # Use a short ladder for speed
        short_ladder = [
            (0.0, "", "baseline"),
            (0.5, "Please ", "polite"),
            (0.8, "From a scholarly perspective, ", "scholarly"),
            (1.0, "Write a detailed academic essay analyzing the historical and philosophical dimensions of ", "max"),
        ]

        result = run_phase_transition(
            base_prompt="What is the capital of France?",
            model="test/mock",
            repeats=3,
            prefix_ladder=short_ladder,
        )

        assert result.model == "test/mock"
        assert result.repeats == 3
        assert len(result.levels) == 4

        # Baseline level should have high similarity to itself
        baseline = result.levels[0]
        assert baseline.lambda_val == 0.0
        assert baseline.phi1_text_similarity == pytest.approx(1.0, abs=0.01)
        assert baseline.phi3_confidence_delta == pytest.approx(0.0, abs=0.01)

        # Scholarly level should show regime shift
        scholarly = result.levels[2]
        assert scholarly.lambda_val == 0.8
        assert scholarly.phi1_text_similarity < 0.5  # different text

        # Result should detect regime shift
        assert result.regime_shift_detected is True

        # Total API calls = 4 levels * 3 repeats = 12
        assert call_count == 12

    def test_progress_callback(self, monkeypatch):
        """Verify progress callback is called correctly."""
        progress_calls = []

        class MockAdapter:
            def __init__(self, **kwargs):
                pass

            def complete(self, prompt: str) -> CompletionResult:
                return CompletionResult(
                    text="Paris.",
                    confidence=0.9,
                    confidence_method="logprob",
                    logprob_entropy=0.1,
                    raw_logprobs=None,
                    token_count=2,
                )

        monkeypatch.setattr(
            "yuragi.experiments.phase_transition.LLMAdapter", MockAdapter
        )

        short_ladder = [(0.0, "", "baseline"), (1.0, "Test ", "test")]

        def on_progress(idx, total, msg):
            progress_calls.append((idx, total, msg))

        run_phase_transition(
            base_prompt="test",
            model="test/mock",
            repeats=2,
            prefix_ladder=short_ladder,
            on_progress=on_progress,
        )

        # 2 levels * 2 repeats = 4 calls
        assert len(progress_calls) == 4
        # First call should be (1, 4, ...)
        assert progress_calls[0][0] == 1
        assert progress_calls[0][1] == 4
