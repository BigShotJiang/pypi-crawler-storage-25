"""Unit tests for yuragi.metrics.volatility."""

from __future__ import annotations

import pytest

from yuragi.core import PerturbationResult, ScanResult
from yuragi.metrics.volatility import (
    VolatilityReport,
    autocorrelation,
    compute_volatility,
    confidence_sharpe,
    confidence_vix,
    detect_regime,
    max_drawdown_and_duration,
    realized_volatility,
)
from yuragi.providers.adapter import CompletionResult

# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def _cr(
    text: str = "answer",
    confidence: float = 0.8,
    method: str = "sampling",
) -> CompletionResult:
    return CompletionResult(
        text=text,
        confidence=confidence,
        confidence_method=method,
        raw_logprobs=None,
    )


def _pr(
    orig_conf: float = 0.8,
    pert_conf: float = 0.8,
    orig_text: str = "same answer",
    pert_text: str = "same answer",
    ptype: str = "omit",
) -> PerturbationResult:
    return PerturbationResult(
        original_prompt="prompt",
        perturbed_prompt="prompt modified",
        perturbation_type=ptype,
        original_response=_cr(orig_text, orig_conf),
        perturbed_response=_cr(pert_text, pert_conf),
    )


def _scan(perturbation_results: list[PerturbationResult]) -> ScanResult:
    return ScanResult(
        prompt="test",
        model="test-model",
        baseline=_cr("baseline", 0.8),
        perturbation_results=perturbation_results,
    )


# ---------------------------------------------------------------------------
# realized_volatility
# ---------------------------------------------------------------------------


class TestRealizedVolatility:
    def test_empty_returns_zero(self):
        assert realized_volatility([]) == 0.0

    def test_single_result_returns_zero(self):
        assert realized_volatility([_pr(pert_conf=0.8)]) == 0.0

    def test_constant_confidence_returns_zero(self):
        results = [_pr(pert_conf=0.7) for _ in range(5)]
        rv = realized_volatility(results)
        assert rv == pytest.approx(0.0, abs=1e-9)

    def test_positive_for_varying_confidence(self):
        results = [_pr(pert_conf=c) for c in [0.9, 0.4, 0.8, 0.3, 0.7]]
        rv = realized_volatility(results)
        assert rv > 0.0

    def test_higher_variance_higher_volatility(self):
        low_var = [_pr(pert_conf=c) for c in [0.79, 0.80, 0.81, 0.80, 0.79]]
        high_var = [_pr(pert_conf=c) for c in [0.9, 0.2, 0.8, 0.3, 0.7]]
        assert realized_volatility(high_var) > realized_volatility(low_var)

    def test_mathematical_correctness(self):
        # Manual: confidences = [0.8, 0.4], log_return = log(0.4/0.8) = log(0.5)
        results = [_pr(pert_conf=0.8), _pr(pert_conf=0.4)]
        # std of single value = 0, but we use population std
        # mean = log(0.5), variance = 0, std = 0
        # realized_vol = 0 * sqrt(1) = 0
        rv = realized_volatility(results)
        assert rv == pytest.approx(0.0, abs=1e-9)

    def test_two_different_returns(self):
        # 3 confidences -> 2 log_returns -> non-zero std possible
        results = [_pr(pert_conf=c) for c in [0.9, 0.5, 0.8]]
        rv = realized_volatility(results)
        assert rv >= 0.0

    def test_scales_with_sqrt_n(self):
        # Verify scaling: doubling N with same returns roughly scales by sqrt(2)
        confs_base = [0.9, 0.5, 0.8]
        confs_doubled = confs_base * 2
        results_base = [_pr(pert_conf=c) for c in confs_base]
        results_doubled = [_pr(pert_conf=c) for c in confs_doubled]
        rv_base = realized_volatility(results_base)
        rv_doubled = realized_volatility(results_doubled)
        # Not exact due to std computation, but both should be positive
        assert rv_base >= 0.0
        assert rv_doubled >= 0.0


# ---------------------------------------------------------------------------
# confidence_vix
# ---------------------------------------------------------------------------


class TestConfidenceVix:
    def test_empty_returns_fifty(self):
        assert confidence_vix([]) == pytest.approx(50.0)

    def test_single_returns_fifty(self):
        assert confidence_vix([_pr(pert_conf=0.8)]) == pytest.approx(50.0)

    def test_range_zero_to_hundred(self):
        # Extreme volatility should not exceed 100
        results = [_pr(pert_conf=c) for c in [0.99, 0.01, 0.99, 0.01, 0.99, 0.01]]
        vix = confidence_vix(results)
        assert 0.0 <= vix <= 100.0

    def test_stable_below_fifty(self):
        results = [_pr(pert_conf=c) for c in [0.79, 0.80, 0.81, 0.80, 0.79]]
        vix = confidence_vix(results)
        assert vix < 50.0

    def test_volatile_above_fifty(self):
        results = [_pr(pert_conf=c) for c in [0.9, 0.1, 0.9, 0.1, 0.9]]
        vix = confidence_vix(results)
        assert vix > 50.0


# ---------------------------------------------------------------------------
# max_drawdown_and_duration
# ---------------------------------------------------------------------------


class TestMaxDrawdown:
    def test_empty_returns_zeros(self):
        dd, dur = max_drawdown_and_duration([])
        assert dd == 0.0
        assert dur == 0

    def test_monotone_increasing_no_drawdown(self):
        results = [_pr(pert_conf=c) for c in [0.5, 0.6, 0.7, 0.8, 0.9]]
        dd, _ = max_drawdown_and_duration(results)
        assert dd == pytest.approx(0.0)

    def test_single_drop_recovered(self):
        # peak=0.9, trough=0.3, drawdown=0.6, recovers at step 3 (0.9)
        results = [_pr(pert_conf=c) for c in [0.9, 0.3, 0.9]]
        dd, dur = max_drawdown_and_duration(results)
        assert dd == pytest.approx(0.6, rel=1e-6)
        assert dur == 1

    def test_drawdown_not_recovered(self):
        results = [_pr(pert_conf=c) for c in [0.9, 0.3, 0.4]]
        dd, _dur = max_drawdown_and_duration(results)
        assert dd == pytest.approx(0.6, rel=1e-6)

    def test_multiple_drawdowns_picks_max(self):
        # Two drawdowns: 0.8->0.5 (0.3) and 0.9->0.2 (0.7)
        results = [_pr(pert_conf=c) for c in [0.8, 0.5, 0.9, 0.2]]
        dd, _ = max_drawdown_and_duration(results)
        assert dd == pytest.approx(0.7, rel=1e-6)

    def test_constant_confidence_zero_drawdown(self):
        results = [_pr(pert_conf=0.7) for _ in range(5)]
        dd, dur = max_drawdown_and_duration(results)
        assert dd == pytest.approx(0.0)
        assert dur == 0


# ---------------------------------------------------------------------------
# confidence_sharpe
# ---------------------------------------------------------------------------


class TestConfidenceSharpe:
    def test_empty_returns_zero(self):
        assert confidence_sharpe([]) == 0.0

    def test_single_returns_zero(self):
        assert confidence_sharpe([_pr(pert_conf=0.8)]) == 0.0

    def test_constant_confidence_returns_zero(self):
        # std = 0 -> sharpe = 0
        results = [_pr(pert_conf=0.7) for _ in range(5)]
        assert confidence_sharpe(results) == 0.0

    def test_positive_for_varying_confidence(self):
        results = [_pr(pert_conf=c) for c in [0.8, 0.7, 0.9, 0.75, 0.85]]
        sharpe = confidence_sharpe(results)
        assert sharpe > 0.0

    def test_higher_mean_higher_sharpe(self):
        # Same std, higher mean -> higher Sharpe
        low_mean = [_pr(pert_conf=c) for c in [0.1, 0.2, 0.3, 0.4, 0.5]]
        high_mean = [_pr(pert_conf=c) for c in [0.5, 0.6, 0.7, 0.8, 0.9]]
        assert confidence_sharpe(high_mean) > confidence_sharpe(low_mean)

    def test_mathematical_correctness(self):
        # confidences = [0.6, 0.8], mean = 0.7
        # sample variance (n-1=1): ((0.6-0.7)² + (0.8-0.7)²) / 1 = 0.02
        # std = sqrt(0.02), sharpe = 0.7 / sqrt(0.02)
        import math

        results = [_pr(pert_conf=0.6), _pr(pert_conf=0.8)]
        sharpe = confidence_sharpe(results)
        expected = 0.7 / math.sqrt(0.02)
        assert sharpe == pytest.approx(expected, rel=1e-6)


# ---------------------------------------------------------------------------
# detect_regime
# ---------------------------------------------------------------------------


class TestDetectRegime:
    def test_stable(self):
        assert detect_regime(0.0) == "stable"
        assert detect_regime(0.05) == "stable"
        assert detect_regime(0.099) == "stable"

    def test_transitional(self):
        assert detect_regime(0.10) == "transitional"
        assert detect_regime(0.20) == "transitional"
        assert detect_regime(0.299) == "transitional"

    def test_volatile(self):
        assert detect_regime(0.30) == "volatile"
        assert detect_regime(0.40) == "volatile"
        assert detect_regime(0.499) == "volatile"

    def test_chaotic(self):
        assert detect_regime(0.50) == "chaotic"
        assert detect_regime(1.0) == "chaotic"
        assert detect_regime(5.0) == "chaotic"


# ---------------------------------------------------------------------------
# autocorrelation
# ---------------------------------------------------------------------------


class TestAutocorrelation:
    def test_empty_returns_zero(self):
        assert autocorrelation([]) == 0.0

    def test_two_returns_zero(self):
        # Need at least 3 for lag-1 autocorrelation
        assert autocorrelation([_pr(pert_conf=0.8), _pr(pert_conf=0.5)]) == 0.0

    def test_range_minus_one_to_one(self):
        results = [_pr(pert_conf=c) for c in [0.9, 0.4, 0.8, 0.3, 0.7, 0.2]]
        ac = autocorrelation(results)
        assert -1.0 <= ac <= 1.0

    def test_momentum_positive(self):
        # Accelerating decrease: deltas grow in magnitude -> positive autocorrelation
        # deltas: -0.1, -0.2, -0.3, -0.4 -> pairs (x,y): (-0.1,-0.2), (-0.2,-0.3), (-0.3,-0.4)
        # all negative and growing, so cov > 0 -> positive ac
        results = [_pr(pert_conf=c) for c in [0.9, 0.8, 0.6, 0.3, -0.1]]
        # Use clipped confidences to avoid negatives
        results = [_pr(pert_conf=c) for c in [1.0, 0.9, 0.7, 0.4, 0.0]]
        ac = autocorrelation(results)
        assert ac > 0.0

    def test_mean_reverting_negative(self):
        # Alternating up-down: delta alternates sign -> negative autocorrelation
        results = [_pr(pert_conf=c) for c in [0.5, 0.9, 0.4, 0.8, 0.3, 0.7]]
        ac = autocorrelation(results)
        assert ac < 0.0

    def test_constant_confidence_returns_zero(self):
        results = [_pr(pert_conf=0.7) for _ in range(6)]
        assert autocorrelation(results) == pytest.approx(0.0, abs=1e-9)

    def test_mathematical_correctness_perfect_momentum(self):
        # Perfectly decreasing: [1.0, 0.8, 0.6, 0.4, 0.2]
        # deltas: [-0.2, -0.2, -0.2, -0.2] -> all same -> autocorrelation = 1.0... wait
        # x = [-0.2, -0.2, -0.2], y = [-0.2, -0.2, -0.2]
        # cov = 0, std_x = 0, std_y = 0 -> returns 0.0 (zero std branch)
        results = [_pr(pert_conf=c) for c in [1.0, 0.8, 0.6, 0.4, 0.2]]
        ac = autocorrelation(results)
        assert ac == pytest.approx(0.0, abs=1e-9)


# ---------------------------------------------------------------------------
# compute_volatility (integration)
# ---------------------------------------------------------------------------


class TestComputeVolatility:
    def test_returns_volatility_report(self):
        scan = _scan([_pr(pert_conf=c) for c in [0.8, 0.6, 0.7, 0.5, 0.9]])
        report = compute_volatility(scan)
        assert isinstance(report, VolatilityReport)

    def test_all_fields_present(self):
        scan = _scan([_pr(pert_conf=c) for c in [0.8, 0.6, 0.7, 0.5, 0.9]])
        report = compute_volatility(scan)
        assert isinstance(report.realized_volatility, float)
        assert isinstance(report.confidence_vix, float)
        assert isinstance(report.max_drawdown, float)
        assert isinstance(report.drawdown_duration, int)
        assert isinstance(report.confidence_sharpe, float)
        assert report.regime in {"stable", "transitional", "volatile", "chaotic"}
        assert isinstance(report.autocorrelation, float)

    def test_empty_scan(self):
        scan = _scan([])
        report = compute_volatility(scan)
        assert report.realized_volatility == 0.0
        assert report.confidence_vix == pytest.approx(50.0)
        assert report.max_drawdown == 0.0
        assert report.drawdown_duration == 0
        assert report.confidence_sharpe == 0.0
        assert report.regime == "stable"
        assert report.autocorrelation == 0.0

    def test_regime_consistent_with_realized_volatility(self):
        # Chaotic regime: extreme oscillation
        scan = _scan([_pr(pert_conf=c) for c in [0.95, 0.05, 0.95, 0.05, 0.95, 0.05]])
        report = compute_volatility(scan)
        # chaotic requires rv >= 0.50
        if report.realized_volatility >= 0.50:
            assert report.regime == "chaotic"
        elif report.realized_volatility >= 0.30:
            assert report.regime == "volatile"

    def test_vix_within_bounds(self):
        for confs in [
            [0.8] * 5,
            [0.9, 0.1, 0.9, 0.1, 0.9],
            [0.5, 0.5, 0.5, 0.5, 0.5],
        ]:
            scan = _scan([_pr(pert_conf=c) for c in confs])
            report = compute_volatility(scan)
            assert 0.0 <= report.confidence_vix <= 100.0
