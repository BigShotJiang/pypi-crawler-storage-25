from ch00_py.file_toolbox import create_path, set_dir
from ch17_idea.idea_db_tool import get_sheet_names, save_sheet
from ch18_etl_config._ref.ch18_path import (
    create_belief0001_path,
    create_beliefs_dir_path,
)
from ch26_world.world import create_beliefs, idea_sheets_to_lynx_mstr, worlddir_shop
from os.path import exists as os_path_exists
from pandas import DataFrame, read_excel as pandas_read_excel
from pandas.testing import assert_frame_equal
from ref.keywords import Ch26Keywords as kw, ExampleStrs as exx
from shutil import copy2 as shutil_copy2


def test_create_beliefs_CreatesFile_Senario0_EmptyWorld(temp3_fs):
    # ESTABLISH
    fay_str = "Fay"
    output_dir = create_path(str(temp3_fs), "output")
    fay_wdir = worlddir_shop(fay_str, str(temp3_fs), output_dir)
    idea_sheets_to_lynx_mstr(fay_wdir)
    fay_belief0001_path = create_belief0001_path(fay_wdir.output_dir)
    assert os_path_exists(fay_belief0001_path) is False

    # WHEN
    create_beliefs(
        fay_wdir.world_dir,
        fay_wdir.output_dir,
        fay_wdir.world_name,
        fay_wdir.moment_mstr_dir,
        prettify_excel_bool=False,
    )

    # THEN
    assert os_path_exists(fay_belief0001_path)


def test_create_beliefs_CreatesFile_Senario1_SingleSmallSpark(temp3_fs):
    # ESTABLISH
    fay_str = "Fay"
    output_dir = create_path(str(temp3_fs), "output")
    fay_wdir = worlddir_shop(fay_str, str(temp3_fs), output_dir)
    spark2 = 2
    ex_filename = "Faybob.xlsx"
    i_src_dir_file_path = create_path(fay_wdir.ideas_src_dir, ex_filename)
    ii00001_columns = [
        kw.spark_num,
        kw.spark_face,
        kw.moment_rope,
        kw.person_name,
        kw.contact_name,
    ]
    ii00001_rows = [[spark2, exx.sue, exx.a23, exx.sue, exx.sue]]
    ii00001_df = DataFrame(ii00001_rows, columns=ii00001_columns)
    save_sheet(i_src_dir_file_path, "ii00001_ex3", ii00001_df)
    idea_sheets_to_lynx_mstr(fay_wdir)
    fay_belief0001_path = create_belief0001_path(fay_wdir.output_dir)
    assert os_path_exists(fay_belief0001_path) is False

    # WHEN
    create_beliefs(
        fay_wdir.world_dir,
        fay_wdir.output_dir,
        fay_wdir.world_name,
        fay_wdir.moment_mstr_dir,
        prettify_excel_bool=False,
    )

    # THEN
    assert os_path_exists(fay_belief0001_path)
    print(get_sheet_names(fay_belief0001_path))
    ii00121_sheet_df = pandas_read_excel(fay_belief0001_path, "ii00121")
    print(f"{ii00121_sheet_df=}")
    assert ii00121_sheet_df.iloc[0][kw.spark_face] == "Fay"


def test_create_beliefs_CreatesFile_Senario2_CreatedBeliefCanBeIdeasForOtherWorldDir(
    temp3_fs,
):
    # sourcery skip: no-loop-in-tests
    # ESTABLISH
    fay_str = "Fay"
    fay_output_dir = create_path(str(temp3_fs), "Fay_output")
    fay_wdir = worlddir_shop(fay_str, str(temp3_fs), fay_output_dir)
    spark2 = 2
    ex_filename = "Faybob.xlsx"
    i_src_dir_file_path = create_path(fay_wdir.ideas_src_dir, ex_filename)
    ii00001_columns = [
        kw.spark_num,
        kw.spark_face,
        kw.moment_rope,
        kw.person_name,
        kw.contact_name,
    ]
    ii00001_rows = [[spark2, exx.sue, exx.a23, exx.sue, exx.sue]]
    ii00001_df = DataFrame(ii00001_rows, columns=ii00001_columns)
    save_sheet(i_src_dir_file_path, "ii00001_ex3", ii00001_df)
    idea_sheets_to_lynx_mstr(fay_wdir)
    fay_belief0001_path = create_belief0001_path(fay_wdir.output_dir)
    create_beliefs(
        world_dir=fay_wdir.world_dir,
        output_dir=fay_wdir.output_dir,
        world_name=fay_wdir.world_name,
        moment_mstr_dir=fay_wdir.moment_mstr_dir,
        prettify_excel_bool=False,
    )
    bob_output_dir = create_path(str(temp3_fs), "Bob_output")
    bob_wdir = worlddir_shop("Bob", str(temp3_fs), bob_output_dir)
    bob_i_src_dir_st0001_path = create_path(
        bob_wdir.moment_mstr_dir, "Bob_i_src_dir.xlsx"
    )
    set_dir(create_beliefs_dir_path(bob_wdir.moment_mstr_dir))
    shutil_copy2(fay_belief0001_path, dst=bob_i_src_dir_st0001_path)
    # print(f" {pandas_read_excel(fay_belief0001_path)=}")
    # print(f"{pandas_read_excel(bob_i_src_dir_st0001_path)=}")
    print(f"{bob_i_src_dir_st0001_path=}")
    print(f"{get_sheet_names(bob_i_src_dir_st0001_path)=}")
    idea_sheets_to_lynx_mstr(fay_wdir)
    bob_belief0001_path = create_belief0001_path(bob_wdir.output_dir)
    assert os_path_exists(bob_belief0001_path) is False

    # WHEN
    create_beliefs(
        bob_wdir.world_dir,
        bob_wdir.output_dir,
        bob_wdir.world_name,
        bob_wdir.moment_mstr_dir,
        prettify_excel_bool=False,
    )

    # THEN
    assert os_path_exists(bob_belief0001_path)
    print(f"{get_sheet_names(bob_belief0001_path)=}")
    for sheetname in get_sheet_names(bob_belief0001_path):
        print(f"comparing {sheetname=}...")
        fay_sheet_df = pandas_read_excel(fay_belief0001_path, sheetname)
        bob_sheet_df = pandas_read_excel(fay_belief0001_path, sheetname)
        # if sheetname == "ii00121":
        #     print(f"{fay_sheet_df=}")
        #     print(f"{bob_sheet_df=}")
        assert_frame_equal(fay_sheet_df, bob_sheet_df)


def test_create_beliefs_CreatesFile_Senario3_Create_calendar_markdown(
    temp3_fs,
):
    # ESTABLISH
    fay_str = "Fay"
    output_dir = create_path(str(temp3_fs), "output")
    fay_wdir = worlddir_shop(fay_str, str(temp3_fs), output_dir)
    spark2 = 2
    ex_filename = "Faybob.xlsx"
    i_src_dir_file_path = create_path(fay_wdir.ideas_src_dir, ex_filename)
    ii00001_columns = [
        kw.spark_num,
        kw.spark_face,
        kw.moment_rope,
        kw.person_name,
        kw.contact_name,
    ]
    ii00001_rows = [[spark2, exx.sue, exx.a23, exx.sue, exx.sue]]
    ii00001_df = DataFrame(ii00001_rows, columns=ii00001_columns)
    save_sheet(i_src_dir_file_path, "ii00001_ex3", ii00001_df)
    idea_sheets_to_lynx_mstr(fay_wdir)
    a23_calendar_md_path = create_path(output_dir, "Amy23_calendar.md")
    print(f"      {a23_calendar_md_path=}")
    assert not os_path_exists(a23_calendar_md_path)

    # WHEN
    create_beliefs(
        fay_wdir.world_dir,
        fay_wdir.output_dir,
        fay_wdir.world_name,
        fay_wdir.moment_mstr_dir,
        prettify_excel_bool=False,
    )

    # THEN
    assert os_path_exists(a23_calendar_md_path)


# def test_WorldDir_sheets_i_src_dir_to_lynx_CreatesFiles(temp3_fs):
#     # ESTABLISH
#     fay_str = "Fay"
#     fay_wdir = worlddir_shop(fay_str, str(temp3_fs))
#     # delete_dir(fay_wdir.worlds_dir)
#     spark1 = 1
#     spark2 = 2
#     minute_360 = 360
#     minute_420 = 420
#     hour6am = "6am"
#     hour7am = "7am"
#     ex_filename = "Faybob.xlsx"
#     i_src_dir_file_path = create_path(fay_wdir.ideas_src_dir, ex_filename)
#     ii00103_columns = [
#         kw.spark_face,
#         kw.spark_num,
#         kw.cumulative_minute,
#         kw.moment_rope,
#         kw.hour_label,
#     ]
#     ii00101_columns = [
#         kw.spark_face,
#         kw.spark_num,
#         kw.moment_rope,
#         kw.person_name,
#         bud_time(),
#         kw.quota,
#         kw.celldepth,
#     ]
#     exx.a23 = exx.a23
#     tp37 = 37
#     sue_quota = 235
#     sue_celldepth = 3
#     ii1row0 = [spark2, exx.sue, exx.a23, exx.sue, tp37, sue_quota, sue_celldepth]
#     ii00101_1df = DataFrame([ii1row0], columns=ii00101_columns)
#     ii00101_ex0_str = "example0_ii00101"
#     save_sheet(i_src_dir_file_path, ii00101_ex0_str, ii00101_1df)

#     ii3row0 = [spark1, exx.sue,  minute_360, exx.a23, hour6am]
#     ii3row1 = [spark1, exx.sue,  minute_420, exx.a23, hour7am]
#     ii3row2 = [spark2, exx.sue, minute_420, exx.a23, hour7am]
#     ii00103_1df = DataFrame([ii3row0, ii3row1], columns=ii00103_columns)
#     ii00103_3df = DataFrame([ii3row1, ii3row0, ii3row2], columns=ii00103_columns)
#     ii00103_ex1_str = "example1_ii00103"
#     ii00103_ex3_str = "example3_ii00103"
#     save_sheet(i_src_dir_file_path, ii00103_ex1_str, ii00103_1df)
#     save_sheet(i_src_dir_file_path, ii00103_ex3_str, ii00103_3df)
#     ii00001_columns = [
#         kw.spark_face,
#         kw.spark_num,
#         kw.moment_rope,
#         kw.person_name,
#         kw.contact_name,
#     ]
#     ii00001_rows = [[spark2, exx.sue, exx.a23, exx.sue, exx.sue]]
#     ii00001_df = DataFrame(ii00001_rows, columns=ii00001_columns)
#     save_sheet(i_src_dir_file_path, "ii00001_ex3", ii00001_df)
#     mstr_dir = fay_wdir.moment_mstr_dir
#     wrong_a23_moment_dir = create_path(mstr_dir, exx.a23)
#     assert os_path_exists(wrong_a23_moment_dir) is False
#     a23_json_path = create_moment_json_path(mstr_dir, a23_lasso)
#     a23_sue_gut_path = create_gut_path(mstr_dir, a23_lasso, exx.sue)
#     a23_sue_job_path = create_job_path(mstr_dir, a23_lasso, exx.sue)
#     sue37_mandate_path = bud_mandate(mstr_dir, a23_lasso, exx.sue, tp37)
#     assert os_path_exists(i_src_dir_file_path)
#     assert os_path_exists(a23_json_path) is False
#     assert os_path_exists(a23_sue_gut_path) is False
#     assert os_path_exists(a23_sue_job_path) is False
#     assert os_path_exists(sue37_mandate_path) is False
#     assert count_dirs_files(fay_wdir.worlds_dir) == 7

#     # WHEN
# idea_sheets_to_lynx_mstr(
#     world_db_path=fay_wdir.get_world_db_path(),
#     i_src_dir=fay_wdir.ideas_src_dir,
#     moment_mstr_dir=fay_wdir.moment_mstr_dir,
# )

#     # THEN
#     assert os_path_exists(wrong_a23_moment_dir) is False
#     i_src_file_path = create_path(fay_wdir.ideas_src_dir, "ii00103.xlsx")
#     assert os_path_exists(i_src_dir_file_path)
#     assert os_path_exists(idea_file_path)
#     assert os_path_exists(a23_json_path)
#     assert os_path_exists(a23_sue_gut_path)
#     assert os_path_exists(a23_sue_job_path)
#     assert os_path_exists(sue37_mandate_path)
#     assert count_dirs_files(fay_wdir.worlds_dir) == 91
