from ch00_py.file_toolbox import create_path
from inspect import getdoc as inspect_getdoc
from ref.keywords import Ch28Keywords as kw

# finance tooling
# financial modeling?
