"""Write text summary report."""

import sys
from pathlib import Path
from typing import IO

from dark.aligners import align as _align
from dark.dna import compareDNAReads, matchToString
from dark.reads import DNARead, Reads

from .persite import read_fasta_sequence
from .stats import ReferenceStats, RunSummary


def _write_consensus_comparison(
    fh: IO[str],
    ref_name: str,
    reference_fasta: Path,
    consensus_fasta: Path | None,
    align: bool = False,
    aligner: str = "mafft",
    aligner_options: str | None = None,
) -> None:
    """Append a consensus-vs-reference comparison block to an open report file."""
    if consensus_fasta is None or not consensus_fasta.exists():
        return
    ref_seq = read_fasta_sequence(reference_fasta, ref_name)
    cons_seq = read_fasta_sequence(consensus_fasta)
    if not ref_seq or not cons_seq:
        return

    ref_read = DNARead(ref_name, ref_seq)
    cons_read = DNARead(f"{ref_name}-consensus", cons_seq)

    len_ref  = len(ref_read)
    len_cons = len(cons_read)
    lengths_differ = len_ref != len_cons

    fh.write(
        f"\n  Comparing reference ({ref_read.id}) vs "
        f"consensus ({cons_read.id}):\n"
    )

    if align:
        # Report pre-alignment lengths.
        if lengths_differ:
            fh.write(
                f"    Pre-alignment lengths: reference {len_ref:,}, "
                f"consensus {len_cons:,} (difference {abs(len_ref - len_cons):,})\n"
            )
        else:
            fh.write(f"    Pre-alignment lengths identical: {len_ref:,}\n")

        ref_read, cons_read = _align(Reads([ref_read, cons_read]), aligner, aligner_options)

        len_ref  = len(ref_read)
        len_cons = len(cons_read)
        fh.write(f"    Post-alignment lengths: {len_ref:,}\n")
    else:
        if lengths_differ:
            warning = (
                f"WARNING: reference length {len_ref:,} and consensus length "
                f"{len_cons:,} differ by {abs(len_ref - len_cons):,} bp — "
                "comparison may be unreliable; consider using --align"
            )
            fh.write(f"    *** {warning} ***\n")
            print(f"  {ref_name}: {warning}", file=sys.stderr)
        else:
            fh.write(f"    Sequence lengths identical: {len_ref:,}\n")

    match = compareDNAReads(ref_read, cons_read)
    comparison = matchToString(
        match,
        ref_read,
        cons_read,
        includeGapLocations=True,
        includeNoCoverageLocations=False,
        includeNLocations=True,
    )
    for line in comparison.splitlines():
        fh.write(f"    {line}\n")


def write_text_report(
    stats: dict[str, ReferenceStats],
    output_path: Path,
    run_summary: RunSummary,
    reference_fasta: Path | None = None,
    consensus_fastas: dict[str, Path] | None = None,
    align: bool = False,
    aligner: str = "mafft",
    aligner_options: str | None = None,
) -> None:
    """Write a plain-text summary of all reference statistics."""
    with open(output_path, "w") as fh:
        fh.write("midsplit summary\n")
        fh.write("=" * 60 + "\n\n")
        fh.write(f"Primary alignment records: {run_summary.total_alignments:,}\n")
        fh.write(f"Unique read IDs:           {run_summary.total_reads:,}\n")
        fh.write("References matched per read ID:\n")
        for n_refs, count in sorted(run_summary.refs_per_read.items()):
            label = "reference" if n_refs == 1 else "references"
            fh.write(f"  {n_refs} {label}:  {count:,}\n")
        fh.write("\n")
        for ref_name, s in sorted(stats.items()):
            fh.write(f"Reference:               {ref_name}\n")
            fh.write(f"  Reference length:      {s.reference_length:,} bp\n")
            total_assigned = s.reads_sole + s.reads_multi
            fh.write(f"  Read IDs assigned:     {total_assigned:,}\n")
            fh.write(f"    Sole (this ref only):  {s.reads_sole:,}\n")
            fh.write(f"    Multi (also elsewhere): {s.reads_multi:,}\n")
            fh.write(f"  Depth (mean):          {s.mean_depth:.2f}x\n")
            fh.write(f"  Depth (median):        {s.median_depth:.2f}x\n")
            fh.write(f"  Depth (std dev):       {s.depth_std:.2f}\n")
            fh.write(f"  Depth (min / max):     {s.min_depth} / {s.max_depth}\n")
            fh.write(f"  Breadth of coverage:   {s.breadth * 100:.2f}%\n")
            fh.write(f"  Soft-clip % (before):  {s.soft_clip_pct_before:.2f}%\n")
            fh.write(f"  Soft-clip % (after):   {s.soft_clip_pct_after:.2f}%\n")
            if reference_fasta and consensus_fastas:
                _write_consensus_comparison(
                    fh, ref_name,
                    reference_fasta, consensus_fastas.get(ref_name),
                    align=align, aligner=aligner,
                    aligner_options=aligner_options,
                )
            fh.write("\n")


