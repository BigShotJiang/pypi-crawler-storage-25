"""Core read classification logic.

This module is pure Python with no pysam dependency so it can be tested
independently of BAM I/O.
"""

from collections import defaultdict
from dataclasses import dataclass


@dataclass
class PairAlignmentSummary:
    """Combined evidence for a read pair (or single read) against one reference.

    For paired-end data this is computed via compute_combined_pid, which
    correctly handles overlapping read pairs.  For single-end data (or a
    pair where one mate is unmapped / does not align to this reference) it
    degrades to the per-read percent identity.
    """

    query_name: str
    reference_name: str
    combined_pid: float
    soft_clipped_bases: int
    total_query_bases: int


def calculate_percent_identity(query_length: int, nm: int) -> float:
    """Return (query_length - edit_distance) / query_length.

    Kept as a standalone utility; use compute_combined_pid for the main
    classification pipeline.
    """
    if query_length == 0:
        return 0.0
    return (query_length - nm) / query_length


def get_soft_clip_info(cigar_tuples: list[tuple[int, int]]) -> tuple[int, int]:
    """Return (soft_clipped_bases, total_query_consuming_bases) from CIGAR tuples.

    CIGAR operations that consume the query: M(0), I(1), S(4), =(7), X(8).
    Soft-clip operation: S(4).
    """
    query_consuming = {0, 1, 4, 7, 8}
    soft_clipped = 0
    total = 0
    for op, length in cigar_tuples:
        if op in query_consuming:
            total += length
        if op == 4:
            soft_clipped += length
    return soft_clipped, total


def compute_combined_pid(
    pos1: list[int],
    nm1: int,
    pos2: list[int] | None = None,
    nm2: int | None = None,
) -> float:
    """Compute the overlap-aware combined percent identity for a read pair.

    For single reads (pos2 is None), returns the per-read PID using the
    number of aligned reference positions as the denominator (NM counts
    edit distance at aligned positions, so this is more correct than using
    the raw query length).

    For read pairs, the union of reference positions is used as the
    denominator so that overlapping regions are not double-counted.
    Edit distances are prorated by region:

      * Positions unique to read 1 : use read 1's per-position edit rate
      * Positions unique to read 2 : use read 2's per-position edit rate
      * Overlap positions           : use the average of both edit rates
                                      (both reads sampled the same bases, so
                                      averaging is the neutral assumption)

    Args:
        pos1: Reference positions covered by read 1 (from get_reference_positions()).
        nm1:  NM edit distance for read 1.
        pos2: Reference positions covered by read 2, or None for single-end.
        nm2:  NM edit distance for read 2, or None for single-end.

    Returns:
        Combined percent identity in [0.0, 1.0].
    """
    set1 = set(pos1)
    n1 = len(set1)

    if n1 == 0:
        return 0.0

    if pos2 is None or nm2 is None or len(pos2) == 0:
        # Single-end or mate has no aligned positions.
        return (n1 - nm1) / n1

    set2 = set(pos2)
    n2 = len(set2)

    if n2 == 0:
        return (n1 - nm1) / n1

    union = set1 | set2
    overlap = set1 & set2
    unique1 = set1 - overlap
    unique2 = set2 - overlap

    n_union = len(union)
    mm_rate1 = nm1 / n1
    mm_rate2 = nm2 / n2

    expected_mismatches = (
        mm_rate1 * len(unique1)
        + mm_rate2 * len(unique2)
        + (mm_rate1 + mm_rate2) / 2 * len(overlap)
    )

    return 1.0 - expected_mismatches / n_union


def compute_assignment_stats(
    assignments: dict[str, set[str]],
) -> dict[str, tuple[int, int]]:
    """Return per-reference (sole_count, multi_count) from a completed assignment dict.

    sole_count  — query names assigned to this reference and no other.
    multi_count — query names assigned to this reference and at least one other.

    The unit is query_name (i.e. read pairs count as one), which is the same
    granularity at which classification decisions are made.

    Args:
        assignments: mapping reference_name -> set of assigned query_names,
                     as returned by classify_reads.

    Returns:
        Dict mapping reference_name -> (sole_count, multi_count).
    """
    # Count how many references each query_name was assigned to.
    query_ref_count: dict[str, int] = {}
    for names in assignments.values():
        for name in names:
            query_ref_count[name] = query_ref_count.get(name, 0) + 1

    result: dict[str, tuple[int, int]] = {}
    for ref, names in assignments.items():
        sole = sum(1 for n in names if query_ref_count[n] == 1)
        multi = sum(1 for n in names if query_ref_count[n] > 1)
        result[ref] = (sole, multi)
    return result


def classify_reads(
    pair_summaries: list[PairAlignmentSummary],
    threshold: float,
) -> dict[str, set[str]]:
    """Assign read pairs to per-reference buckets based on combined PID.

    A pair is assigned to a reference if its combined_pid is >= threshold
    times the best combined_pid for that pair across all references.

    Special case: if a pair aligns to only one reference it is always
    assigned to that reference regardless of score.

    Args:
        pair_summaries: One entry per (query_name, reference_name) combination.
        threshold:      Fraction of best PID required for assignment (0–1).

    Returns:
        Dict mapping reference_name -> set of assigned query_names.
    """
    by_pair: dict[str, list[PairAlignmentSummary]] = defaultdict(list)
    for ps in pair_summaries:
        by_pair[ps.query_name].append(ps)

    assignments: dict[str, set[str]] = defaultdict(set)

    for query_name, pair_alns in by_pair.items():
        if len(pair_alns) == 1:
            assignments[pair_alns[0].reference_name].add(query_name)
        else:
            best_pid = max(p.combined_pid for p in pair_alns)
            for pa in pair_alns:
                if pa.combined_pid >= threshold * best_pid:
                    assignments[pa.reference_name].add(query_name)

    return dict(assignments)
