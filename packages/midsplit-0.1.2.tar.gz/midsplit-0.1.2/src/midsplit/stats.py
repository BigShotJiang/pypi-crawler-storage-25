"""Coverage and soft-clip statistics accumulation."""

from dataclasses import dataclass, field

import numpy as np


@dataclass
class ReferenceAccumulator:
    """Accumulates coverage depth and soft-clip data for one reference.

    Populated in two stages:
      - add_alignment_before: called for every primary alignment to this
        reference, regardless of bucket assignment.
      - add_alignment_after: called only for reads actually assigned to
        this reference's bucket.

    reads_sole / reads_multi are set directly from classify.compute_assignment_stats
    after classification is complete.
    """

    reference_name: str
    reference_length: int

    # Per-position depth array (one entry per reference base).
    depth: np.ndarray = field(init=False)

    # Soft-clip totals before assignment filtering.
    sc_bases_before: int = 0
    total_bases_before: int = 0

    # Soft-clip totals after assignment filtering.
    sc_bases_after: int = 0
    total_bases_after: int = 0

    # Alignment records written to the output BAM.
    read_count: int = 0

    # Assignment breakdown (query_name granularity, set after classification).
    reads_sole: int = 0   # assigned to this reference only
    reads_multi: int = 0  # also assigned to at least one other reference

    def __post_init__(self) -> None:
        self.depth = np.zeros(self.reference_length, dtype=np.int64)

    def add_alignment_before(self, soft_clipped: int, total: int) -> None:
        """Record soft-clip info for an alignment prior to bucket filtering."""
        self.sc_bases_before += soft_clipped
        self.total_bases_before += total

    def add_alignment_after(
        self,
        soft_clipped: int,
        total: int,
        reference_positions: list[int],
    ) -> None:
        """Record soft-clip info and update depth for an assigned alignment."""
        self.sc_bases_after += soft_clipped
        self.total_bases_after += total
        self.read_count += 1
        for pos in reference_positions:
            if 0 <= pos < self.reference_length:
                self.depth[pos] += 1


@dataclass
class ReferenceStats:
    """Summary statistics for one reference after processing."""

    reference_name: str
    reference_length: int

    # Assignment counts (query_name / pair granularity).
    reads_sole: int
    reads_multi: int

    # Alignment records written (individual segments, not pairs).
    read_count: int

    # Coverage depth across all reference positions (zeros included).
    mean_depth: float
    median_depth: float
    depth_std: float
    min_depth: int
    max_depth: int
    breadth: float

    # Soft-clip percentages.
    soft_clip_pct_before: float
    soft_clip_pct_after: float


@dataclass
class RunSummary:
    """Run-level summary of the input BAM (computed before thresholding)."""

    total_alignments: int             # primary alignment records in the input
    total_reads: int                  # unique unique read IDs in the input
    refs_per_read: dict[int, int]     # n_refs_aligned_to -> count of reads (by query name)


def compute_stats(acc: ReferenceAccumulator) -> ReferenceStats:
    """Derive final statistics from a fully-populated ReferenceAccumulator."""
    if acc.reference_length > 0:
        mean_depth   = float(np.mean(acc.depth))
        median_depth = float(np.median(acc.depth))
        depth_std    = float(np.std(acc.depth))
        min_depth    = int(np.min(acc.depth))
        max_depth    = int(np.max(acc.depth))
        breadth      = float(np.sum(acc.depth > 0)) / acc.reference_length
    else:
        mean_depth = median_depth = depth_std = 0.0
        min_depth = max_depth = 0
        breadth = 0.0

    sc_before = (
        acc.sc_bases_before / acc.total_bases_before * 100
        if acc.total_bases_before > 0
        else 0.0
    )
    sc_after = (
        acc.sc_bases_after / acc.total_bases_after * 100
        if acc.total_bases_after > 0
        else 0.0
    )
    return ReferenceStats(
        reference_name=acc.reference_name,
        reference_length=acc.reference_length,
        reads_sole=acc.reads_sole,
        reads_multi=acc.reads_multi,
        read_count=acc.read_count,
        mean_depth=mean_depth,
        median_depth=median_depth,
        depth_std=depth_std,
        min_depth=min_depth,
        max_depth=max_depth,
        breadth=breadth,
        soft_clip_pct_before=sc_before,
        soft_clip_pct_after=sc_after,
    )
