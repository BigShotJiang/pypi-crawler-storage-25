"""midsplit: demultiplex multi-reference BAM files into per-reference buckets."""

__version__ = "0.1.0"
