"""Command-line entry point for midsplit."""

import argparse
import sys
from pathlib import Path

from dark.aligners import MAFFT_DEFAULT_ARGS, NEEDLE_DEFAULT_ARGS

from ..consensus import run_ivar_consensus
from ..persite import compute_per_site, write_per_site_tsv
from ..report import write_text_report
from ..writer import process_bam


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        prog="midsplit",
        description=(
            "Demultiplex a multi-reference BAM file into per-reference buckets "
            "and call consensus for each non-empty bucket."
        ),
    )
    parser.add_argument(
        "input_bam",
        type=Path,
        metavar="INPUT_BAM",
        help="Input BAM file (multi-reference, primary alignments)",
    )
    parser.add_argument(
        "--output-dir",
        type=Path,
        default=Path("."),
        metavar="DIR",
        help="Directory for all output files (created if absent, default: .)",
    )
    parser.add_argument(
        "--threshold",
        type=float,
        default=0.95,
        metavar="FLOAT",
        help=(
            "Assign a read to a reference if its percent identity is >= FLOAT "
            "times the best percent identity for that read. (default: 0.95)"
        ),
    )
    parser.add_argument(
        "--consensus-caller",
        choices=("ivar",),
        default="ivar",
        help="Consensus caller (default: ivar)",
    )
    parser.add_argument(
        "--consensus-quality",
        type=int,
        default=20,
        metavar="INT",
        help="Minimum base quality for consensus (ivar -q, default: 20)",
    )
    parser.add_argument(
        "--consensus-frequency-threshold",
        type=float,
        default=0.0,
        metavar="FLOAT",
        help="Minimum frequency for a base to be called (ivar -t, default: 0.0)",
    )
    parser.add_argument(
        "--consensus-low-coverage",
        type=int,
        default=0,
        metavar="INT",
        help="Positions with depth below this are masked with N (ivar -m, default: 0)",
    )
    parser.add_argument(
        "--reference",
        type=Path,
        default=None,
        metavar="FASTA",
        help=(
            "Multi-reference FASTA used as the assembly input (optional).  "
            "When provided, the ref_base column in per-site TSV files will "
            "contain the actual reference base instead of 'N'."
        ),
    )
    parser.add_argument(
        "--align",
        action="store_true",
        help=(
            "Align each consensus to its reference before comparing them "
            "in the summary report. Recommended when consensus and reference "
            "lengths differ."
        ),
    )
    parser.add_argument(
        "--aligner",
        default="mafft",
        choices=("edlib", "mafft", "needle"),
        help="Alignment algorithm used when --align is given (default: mafft)",
    )
    parser.add_argument(
        "--aligner-options",
        default=None,
        metavar="OPTIONS",
        help=(
            "Options to pass to the alignment algorithm (implies --align). "
            f"For mafft the default is {MAFFT_DEFAULT_ARGS!r}. "
            f"For needle the default is {NEEDLE_DEFAULT_ARGS!r}. "
            "Not used by edlib."
        ),
    )
    parser.add_argument(
        "--consensus-id",
        help="The ID for the consensus sequence. Use {ID} to embed the reference ID.",
    )
    return parser


def main() -> None:
    parser = build_parser()
    args = parser.parse_args()

    if args.aligner_options:
        args.align = True

    if not args.input_bam.exists():
        print(f"Error: input BAM not found: {args.input_bam}", file=sys.stderr)
        sys.exit(1)

    if not (0.0 < args.threshold <= 1.0):
        print(
            f"Error: --threshold must be in (0, 1], got {args.threshold}",
            file=sys.stderr,
        )
        sys.exit(1)

    print(f"midsplit: processing {args.input_bam}")
    print(f"  threshold:  {args.threshold}")
    print(f"  output dir: {args.output_dir}")

    stats, ref_bam_paths, run_summary = process_bam(
        args.input_bam, args.output_dir, args.threshold
    )

    if not stats:
        print("No reads assigned. Exiting.", file=sys.stderr)
        sys.exit(1)

    print(f"\nReads assigned to {len(stats)} reference(s):")
    for ref_name, s in sorted(stats.items()):
        print(f"  {ref_name}: {s.read_count} reads")

    print("\nCalling consensus ...")
    consensus_fastas: dict[str, Path] = {}
    for ref_name, bam_path in sorted(ref_bam_paths.items()):
        print(f"  {ref_name} ...", end=" ", flush=True)
        consensus_id = (
            args.consensus_id.replace("{ID}", ref_name)
            if args.consensus_id
            else f"{ref_name}-consensus"
        )
        try:
            fasta = run_ivar_consensus(
                bam_path=bam_path,
                output_dir=args.output_dir,
                accession=ref_name,
                quality=args.consensus_quality,
                frequency_threshold=args.consensus_frequency_threshold,
                low_coverage=args.consensus_low_coverage,
                consensus_id=consensus_id,
            )
            consensus_fastas[ref_name] = fasta
            print(f"-> {fasta.name}")
        except RuntimeError as exc:
            print(f"FAILED: {exc}", file=sys.stderr)

    print("\nWriting per-site TSV files ...")
    import pysam

    for ref_name, bam_path in sorted(ref_bam_paths.items()):
        with pysam.AlignmentFile(str(bam_path), "rb") as bam:
            ref_length = bam.header.to_dict()["SQ"][0]["LN"]
        per_site = compute_per_site(
            bam_path=bam_path,
            ref_length=ref_length,
            consensus_fasta=consensus_fastas.get(ref_name),
            reference_fasta=args.reference,
            accession=ref_name,
            align=args.align,
            aligner=args.aligner,
            aligner_options=args.aligner_options,
        )
        tsv_path = args.output_dir / f"{ref_name}-per-site.tsv"
        write_per_site_tsv(per_site, tsv_path)
        print(f"  {ref_name} -> {tsv_path.name}")

    summary_txt = args.output_dir / "summary.txt"
    write_text_report(
        stats,
        summary_txt,
        run_summary,
        args.reference,
        consensus_fastas,
        align=args.align,
        aligner=args.aligner,
        aligner_options=args.aligner_options,
    )
    print(f"\nReport written to {summary_txt}")


if __name__ == "__main__":
    main()
