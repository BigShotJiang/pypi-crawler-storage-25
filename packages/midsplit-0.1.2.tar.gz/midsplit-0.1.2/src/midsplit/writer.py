"""BAM processing pipeline: classification, per-reference output, and stats."""

import os
import sys
from collections import Counter, defaultdict
from dataclasses import dataclass, field
from pathlib import Path

import pysam

from .classify import (
    PairAlignmentSummary,
    classify_reads,
    compute_assignment_stats,
    compute_combined_pid,
    get_soft_clip_info,
)
from .stats import ReferenceAccumulator, ReferenceStats, RunSummary, compute_stats


@dataclass
class _AlignmentRecord:
    """Per-alignment data collected in Pass 1, before pair combination."""

    query_name: str
    reference_name: str
    nm: int
    reference_positions: list[int]
    soft_clipped_bases: int
    total_query_bases: int
    is_read1: bool
    is_paired: bool


def _build_pair_summaries(
    raw: list[_AlignmentRecord],
) -> list[PairAlignmentSummary]:
    """Group raw alignment records by (query_name, reference_name) and compute
    overlap-aware combined PIDs.

    For paired reads both mates' positions are combined via compute_combined_pid.
    For single-end reads (or a pair where only one mate aligns to a reference)
    the single-read formula is used.

    If more than two records exist for a (query_name, reference_name) group
    (which should not happen with primary-only alignments) only the first two
    are used and a warning is emitted.
    """
    # Group: (query_name, ref_name) -> [records]
    groups: dict[tuple[str, str], list[_AlignmentRecord]] = defaultdict(list)
    for rec in raw:
        groups[(rec.query_name, rec.reference_name)].append(rec)

    summaries: list[PairAlignmentSummary] = []

    for (query_name, ref_name), records in groups.items():
        # A read (or pair) can align to multiple positions within the same
        # reference (multi-mapping within one reference).  For each mate
        # position (r1 / r2) keep only the alignment with the lowest NM so
        # that we use the best available evidence for this reference.
        by_mate: dict[bool, list[_AlignmentRecord]] = defaultdict(list)
        for rec in records:
            by_mate[rec.is_read1].append(rec)
        records = [
            min(group, key=lambda r: r.nm)
            for group in by_mate.values()
        ]

        if len(records) == 2:
            # Ensure r1 is read1 (order matters for consistency, not correctness,
            # since compute_combined_pid is symmetric).
            r1, r2 = (records[0], records[1]) if records[0].is_read1 else (records[1], records[0])
            pid = compute_combined_pid(
                r1.reference_positions, r1.nm,
                r2.reference_positions, r2.nm,
            )
            sc = r1.soft_clipped_bases + r2.soft_clipped_bases
            total = r1.total_query_bases + r2.total_query_bases
        else:
            rec = records[0]
            pid = compute_combined_pid(rec.reference_positions, rec.nm)
            sc = rec.soft_clipped_bases
            total = rec.total_query_bases

        summaries.append(PairAlignmentSummary(
            query_name=query_name,
            reference_name=ref_name,
            combined_pid=pid,
            soft_clipped_bases=sc,
            total_query_bases=total,
        ))

    return summaries


def process_bam(
    input_bam: Path,
    output_dir: Path,
    threshold: float,
) -> tuple[dict[str, ReferenceStats], dict[str, Path], RunSummary]:
    """Classify reads, write per-reference BAMs, and collect statistics.

    Two-pass approach:
      Pass 1 — collect per-alignment records (including reference positions for
               overlap-aware pair PID computation); classify pairs.
      Pass 2 — write assigned alignments to per-reference BAMs; update
               coverage depth and soft-clip stats.

    Returns:
        stats:         mapping reference_name -> ReferenceStats
        ref_bam_paths: mapping reference_name -> Path of the output BAM
        run_summary:   run-level counts (total reads, refs-per-read distribution)
    """
    output_dir.mkdir(parents=True, exist_ok=True)

    # ------------------------------------------------------------------
    # Pass 1: collect alignment records
    # ------------------------------------------------------------------
    raw_alignments: list[_AlignmentRecord] = []

    with pysam.AlignmentFile(str(input_bam), "rb") as bam:
        header_dict = bam.header.to_dict()
        ref_lengths: dict[str, int] = {
            sq["SN"]: sq["LN"] for sq in header_dict.get("SQ", [])
        }

        for segment in bam:
            if segment.is_unmapped:
                continue
            if segment.is_supplementary:
                continue

            if not segment.has_tag("NM"):
                print(
                    f"Error: alignment for read '{segment.query_name}' against "
                    f"'{segment.reference_name}' has no NM tag. "
                    "Please use an aligner that produces NM tags (e.g. Bowtie2, BWA).",
                    file=sys.stderr,
                )
                sys.exit(1)

            nm: int = segment.get_tag("NM")
            sc, total = get_soft_clip_info(segment.cigartuples or [])

            raw_alignments.append(_AlignmentRecord(
                query_name=segment.query_name,
                reference_name=segment.reference_name,
                nm=nm,
                reference_positions=segment.get_reference_positions(),
                soft_clipped_bases=sc,
                total_query_bases=total,
                is_read1=segment.is_read1,
                is_paired=segment.is_paired,
            ))

    # ------------------------------------------------------------------
    # Run-level summary (based on raw alignments, before thresholding)
    # ------------------------------------------------------------------
    reads_to_refs: dict[str, set[str]] = defaultdict(set)
    for rec in raw_alignments:
        reads_to_refs[rec.query_name].add(rec.reference_name)  # group by read ID

    refs_per_read = dict(
        sorted(Counter(len(refs) for refs in reads_to_refs.values()).items())
    )
    run_summary = RunSummary(
        total_alignments=len(raw_alignments),
        total_reads=len(reads_to_refs),
        refs_per_read=refs_per_read,
    )

    # ------------------------------------------------------------------
    # Build pair summaries and classify
    # ------------------------------------------------------------------
    pair_summaries = _build_pair_summaries(raw_alignments)
    assignments: dict[str, set[str]] = classify_reads(pair_summaries, threshold)

    if not assignments:
        print("Warning: no reads were assigned to any reference.", file=sys.stderr)
        return {}, {}, run_summary

    assignment_stats = compute_assignment_stats(assignments)

    # ------------------------------------------------------------------
    # Build per-reference accumulators; populate "before" soft-clip stats
    # (uses individual alignment records, not pair summaries, so every
    # alignment to a reference is counted regardless of assignment)
    # ------------------------------------------------------------------
    accumulators: dict[str, ReferenceAccumulator] = {}
    for rec in raw_alignments:
        ref = rec.reference_name
        if ref not in accumulators:
            sole, multi = assignment_stats.get(ref, (0, 0))
            accumulators[ref] = ReferenceAccumulator(
                reference_name=ref,
                reference_length=ref_lengths[ref],
                reads_sole=sole,
                reads_multi=multi,
            )
        accumulators[ref].add_alignment_before(rec.soft_clipped_bases, rec.total_query_bases)

    # ------------------------------------------------------------------
    # Pass 2: write per-reference BAMs; update "after" stats
    # ------------------------------------------------------------------
    ref_bam_paths: dict[str, Path] = {}
    output_bams: dict[str, pysam.AlignmentFile] = {}

    with pysam.AlignmentFile(str(input_bam), "rb") as bam:
        original_header = bam.header.to_dict()

        for ref_name in assignments:
            sq_entries = [
                sq for sq in original_header.get("SQ", []) if sq["SN"] == ref_name
            ]
            out_header_dict = {**original_header, "SQ": sq_entries}
            out_path = output_dir / f"{ref_name}.bam"
            ref_bam_paths[ref_name] = out_path
            output_bams[ref_name] = pysam.AlignmentFile(
                str(out_path),
                "wb",
                header=pysam.AlignmentHeader.from_dict(out_header_dict),
            )

        try:
            for segment in bam:
                if segment.is_unmapped:
                    continue
                if segment.is_supplementary:
                    continue

                ref = segment.reference_name
                if ref not in assignments:
                    continue
                if segment.query_name not in assignments[ref]:
                    continue

                # The output BAM has exactly one @SQ entry (index 0).
                # We must remap both reference_id and next_reference_id;
                # htslib validates both against the header on read and
                # returns an error for any ID >= n_targets.
                original_ref_id = segment.reference_id
                original_next_ref_id = segment.next_reference_id
                segment.reference_id = 0
                if segment.next_reference_id == original_ref_id:
                    segment.next_reference_id = 0   # mate on same ref → index 0
                elif segment.next_reference_id >= 0:
                    segment.next_reference_id = -1  # mate on different ref → unknown
                output_bams[ref].write(segment)
                segment.reference_id = original_ref_id
                segment.next_reference_id = original_next_ref_id

                sc, total = get_soft_clip_info(segment.cigartuples or [])
                positions = segment.get_reference_positions()
                accumulators[ref].add_alignment_after(sc, total, positions)
        finally:
            for f in output_bams.values():
                f.close()

    # ------------------------------------------------------------------
    # Sort and index output BAMs (required for ivar / samtools mpileup)
    # ------------------------------------------------------------------
    for ref_name, bam_path in ref_bam_paths.items():
        sorted_path = str(bam_path) + ".sorted.bam"
        pysam.sort("-o", sorted_path, str(bam_path))  # type: ignore[attr-defined]
        os.replace(sorted_path, str(bam_path))
        pysam.index(str(bam_path))  # type: ignore[attr-defined]

    # ------------------------------------------------------------------
    # Compute final statistics for assigned references
    # ------------------------------------------------------------------
    stats = {
        ref: compute_stats(accumulators[ref])
        for ref in assignments
        if ref in accumulators
    }

    return stats, ref_bam_paths, run_summary
