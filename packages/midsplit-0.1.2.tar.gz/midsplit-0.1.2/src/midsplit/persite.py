"""Per-site nucleotide composition and consensus output."""

from dataclasses import dataclass
from pathlib import Path

import pysam


@dataclass
class SiteInfo:
    """Per-position data for one reference site."""

    position: int        # 1-based
    ref_base: str        # from reference FASTA, or 'N' if unavailable
    consensus_base: str  # from ivar consensus FASTA, or 'N' if unavailable
    depth: int           # reads spanning this position (including deletions)
    count_a: int
    count_c: int
    count_g: int
    count_t: int


def read_fasta_sequence(path: Path, accession: str | None = None) -> str | None:
    """Return a sequence from a FASTA file (uppercase).

    If *accession* is given, returns the sequence whose header starts with that
    word.  If *accession* is None or the name is not found, returns the first
    sequence in the file.  Returns None if the file contains no sequences.
    """
    target = accession
    in_target = target is None  # if no name given, take the first sequence
    seq_lines: list[str] = []

    with open(path) as fh:
        for raw in fh:
            line = raw.strip()
            if not line:
                continue
            if line.startswith(">"):
                if seq_lines and in_target:
                    return "".join(seq_lines).upper()
                header_name = line[1:].split()[0]
                in_target = target is None or header_name == target
                seq_lines = []
            elif in_target:
                seq_lines.append(line)

    return "".join(seq_lines).upper() if seq_lines and in_target else None


def _consensus_bases_via_alignment(
    ref_seq: str,
    cons_seq: str,
    aligner: str,
    aligner_options: str | None,
) -> list[str]:
    """Align consensus to reference; return one consensus base per reference position.

    Insertions in the consensus (gaps in the aligned reference) are skipped so
    the returned list has exactly len(ref_seq) entries.  A deletion in the
    consensus at a reference position is represented as '-'.
    """
    from dark.aligners import align as _align
    from dark.reads import DNARead, Reads

    aligned_ref, aligned_cons = _align(
        Reads([DNARead("ref", ref_seq), DNARead("cons", cons_seq)]),
        aligner,
        aligner_options,
    )
    result: list[str] = []
    for ref_char, cons_char in zip(aligned_ref.sequence, aligned_cons.sequence):
        if ref_char != "-":
            result.append(cons_char)
    return result


def compute_per_site(
    bam_path: Path,
    ref_length: int,
    consensus_fasta: Path | None = None,
    reference_fasta: Path | None = None,
    accession: str = "",
    align: bool = False,
    aligner: str = "mafft",
    aligner_options: str | None = None,
) -> list[SiteInfo]:
    """Compute per-site statistics for a per-reference BAM.

    Depth counts all reads spanning a position (including those with a
    deletion at that position, matching samtools mpileup behaviour).
    A/C/G/T counts cover only non-deletion bases.

    Args:
        bam_path:         Sorted, indexed per-reference output BAM.
        ref_length:       Length of the reference sequence in bases.
        consensus_fasta:  Path to ivar consensus FASTA; used for the
                          consensus_base column.  Pass None if unavailable.
        reference_fasta:  Optional multi-reference FASTA; used for the
                          ref_base column.  Pass None to output 'N'.
        accession:        Accession name used to look up the sequence in
                          reference_fasta (the first word of the header).
        align:            When True (and both reference_fasta and
                          consensus_fasta are provided), align the consensus
                          to the reference before mapping consensus bases to
                          reference positions.  Required when the consensus
                          length differs from the reference (e.g. ivar
                          insertions).
        aligner:          Alignment algorithm passed to dark.aligners.align
                          when align=True (default: "mafft").
        aligner_options:  Extra options forwarded to the aligner.

    Returns:
        List of SiteInfo objects, one per reference position (1-based).
    """
    # Initialise all positions with zeros / unknown bases.
    sites: list[SiteInfo] = [
        SiteInfo(
            position=i + 1,
            ref_base="N",
            consensus_base="N",
            depth=0,
            count_a=0, count_c=0, count_g=0, count_t=0,
        )
        for i in range(ref_length)
    ]

    # --- Nucleotide counts from pysam pileup ---
    with pysam.AlignmentFile(str(bam_path), "rb") as bam:
        for col in bam.pileup(
            max_depth=1_000_000,
            min_base_quality=0,
            ignore_overlaps=False,
        ):
            pos = col.reference_pos  # 0-based
            if pos < 0 or pos >= ref_length:
                continue
            site = sites[pos]
            for pr in col.pileups:
                if pr.is_refskip:
                    continue
                site.depth += 1
                if pr.is_del or pr.query_position is None:
                    continue
                base = pr.alignment.query_sequence[pr.query_position].upper()
                if base == "A":
                    site.count_a += 1
                elif base == "C":
                    site.count_c += 1
                elif base == "G":
                    site.count_g += 1
                elif base == "T":
                    site.count_t += 1

    # --- Reference bases ---
    ref_seq: str | None = None
    if reference_fasta is not None:
        ref_seq = read_fasta_sequence(reference_fasta, accession or None)
        if ref_seq:
            for i, base in enumerate(ref_seq[:ref_length]):
                sites[i].ref_base = base

    # --- Consensus bases ---
    if consensus_fasta is not None and consensus_fasta.exists():
        cons_seq = read_fasta_sequence(consensus_fasta)
        if cons_seq:
            if align and ref_seq:
                aligned_bases = _consensus_bases_via_alignment(
                    ref_seq, cons_seq, aligner, aligner_options
                )
                for i, base in enumerate(aligned_bases[:ref_length]):
                    sites[i].consensus_base = base
            else:
                for i, base in enumerate(cons_seq[:ref_length]):
                    sites[i].consensus_base = base

    return sites


def write_per_site_tsv(sites: list[SiteInfo], output_path: Path) -> None:
    """Write per-site data as a tab-separated file."""
    with open(output_path, "w") as fh:
        fh.write("site\tref_base\tconsensus_base\tdepth\tA\tC\tG\tT\n")
        for s in sites:
            fh.write(
                f"{s.position}\t{s.ref_base}\t{s.consensus_base}\t"
                f"{s.depth}\t{s.count_a}\t{s.count_c}\t{s.count_g}\t{s.count_t}\n"
            )
