"""Consensus calling wrappers."""

import shutil
import subprocess
from pathlib import Path


def run_ivar_consensus(
    bam_path: Path,
    output_dir: Path,
    accession: str,
    quality: int,
    frequency_threshold: float,
    low_coverage: int,
    consensus_id: str,
) -> Path:
    """Run samtools mpileup | ivar consensus and return path to output FASTA.

    ivar names its output {prefix}.fa; we rename it to .fasta and place it
    in output_dir as {accession}-consensus.fasta.
    """
    prefix = output_dir / f"{accession}-consensus"

    mpileup_cmd = [
        "samtools", "mpileup",
        "-d", "0",
        "-aa",
        "-A",
        "-Q", "0",
        str(bam_path),
    ]
    ivar_cmd = [
        "ivar", "consensus",
        "-p", str(prefix),
        "-q", str(quality),
        "-t", str(frequency_threshold),
        "-m", str(low_coverage),
        "-i", consensus_id,
    ]

    mpileup = subprocess.Popen(mpileup_cmd, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
    ivar = subprocess.run(ivar_cmd, stdin=mpileup.stdout, capture_output=True, text=True)
    mpileup.stdout.close()  # type: ignore[union-attr]
    mpileup.wait()

    if mpileup.returncode != 0:
        _, mpileup_err = mpileup.communicate()
        raise RuntimeError(
            f"samtools mpileup failed for {accession} (exit {mpileup.returncode})"
        )
    if ivar.returncode != 0:
        raise RuntimeError(
            f"ivar consensus failed for {accession} (exit {ivar.returncode}):\n{ivar.stderr}"
        )

    fa_path = Path(str(prefix) + ".fa")
    fasta_path = Path(str(prefix) + ".fasta")
    if fa_path.exists():
        shutil.move(str(fa_path), str(fasta_path))

    return fasta_path
