"""Tests for midsplit.classify."""

import pytest

from midsplit.classify import (
    PairAlignmentSummary,
    calculate_percent_identity,
    classify_reads,
    compute_assignment_stats,
    compute_combined_pid,
    get_soft_clip_info,
)


# ---------------------------------------------------------------------------
# calculate_percent_identity
# ---------------------------------------------------------------------------

class TestCalculatePercentIdentity:
    def test_perfect_match(self):
        assert calculate_percent_identity(100, 0) == 1.0

    def test_all_mismatches(self):
        assert calculate_percent_identity(100, 100) == 0.0

    def test_partial_mismatches(self):
        assert calculate_percent_identity(100, 5) == pytest.approx(0.95)

    def test_zero_length_returns_zero(self):
        assert calculate_percent_identity(0, 0) == 0.0


# ---------------------------------------------------------------------------
# get_soft_clip_info
# ---------------------------------------------------------------------------

class TestGetSoftClipInfo:
    def test_no_soft_clip(self):
        sc, total = get_soft_clip_info([(0, 50)])
        assert sc == 0
        assert total == 50

    def test_leading_soft_clip(self):
        sc, total = get_soft_clip_info([(4, 10), (0, 40)])
        assert sc == 10
        assert total == 50

    def test_trailing_soft_clip(self):
        sc, total = get_soft_clip_info([(0, 40), (4, 10)])
        assert sc == 10
        assert total == 50

    def test_both_ends_soft_clipped(self):
        sc, total = get_soft_clip_info([(4, 5), (0, 40), (4, 5)])
        assert sc == 10
        assert total == 50

    def test_insertion_counts_toward_total(self):
        sc, total = get_soft_clip_info([(0, 20), (1, 5), (0, 25)])
        assert sc == 0
        assert total == 50

    def test_deletion_does_not_count_toward_total(self):
        sc, total = get_soft_clip_info([(0, 25), (2, 10), (0, 25)])
        assert sc == 0
        assert total == 50

    def test_empty_cigar(self):
        sc, total = get_soft_clip_info([])
        assert sc == 0
        assert total == 0


# ---------------------------------------------------------------------------
# compute_combined_pid
# ---------------------------------------------------------------------------

class TestComputeCombinedPid:
    # --- single-read (no mate) ---

    def test_single_read_perfect(self):
        pos = list(range(30))
        assert compute_combined_pid(pos, 0) == pytest.approx(1.0)

    def test_single_read_partial_mismatches(self):
        pos = list(range(30))
        # 3 mismatches out of 30 aligned positions
        assert compute_combined_pid(pos, 3) == pytest.approx(27 / 30)

    def test_single_read_empty_positions_returns_zero(self):
        assert compute_combined_pid([], 0) == 0.0

    def test_single_read_explicit_none_mate(self):
        pos = list(range(30))
        assert compute_combined_pid(pos, 0, None, None) == pytest.approx(1.0)

    def test_single_read_empty_mate_positions(self):
        pos = list(range(30))
        # pos2 provided but empty → same as single-read
        assert compute_combined_pid(pos, 0, [], 0) == pytest.approx(1.0)

    # --- non-overlapping pair ---

    def test_non_overlapping_pair_both_perfect(self):
        # r1 covers 0-29, r2 covers 50-79 — no overlap
        pos1 = list(range(30))
        pos2 = list(range(50, 80))
        assert compute_combined_pid(pos1, 0, pos2, 0) == pytest.approx(1.0)

    def test_non_overlapping_pair_partial_mismatches(self):
        # r1: 3 mm / 30 positions; r2: 3 mm / 30 positions
        # union = 60 positions, expected mismatches = 3+3 = 6
        # combined_pid = 1 - 6/60 = 0.9
        pos1 = list(range(30))
        pos2 = list(range(50, 80))
        assert compute_combined_pid(pos1, 3, pos2, 3) == pytest.approx(0.9)

    def test_non_overlapping_pair_one_worse(self):
        # r1 perfect, r2 has 5 mm / 30 → combined = 1 - 5/60
        pos1 = list(range(30))
        pos2 = list(range(50, 80))
        assert compute_combined_pid(pos1, 0, pos2, 5) == pytest.approx(55 / 60)

    # --- overlapping pair ---

    def test_overlapping_pair_both_perfect(self):
        # r1: 0-29, r2: 20-49 → overlap 20-29 (10 bp)
        # All mm rates = 0, combined_pid = 1.0
        pos1 = list(range(30))
        pos2 = list(range(20, 50))
        assert compute_combined_pid(pos1, 0, pos2, 0) == pytest.approx(1.0)

    def test_overlapping_pair_with_mismatches(self):
        # r1: 0-29 (30 pos), nm=3; r2: 20-49 (30 pos), nm=3
        # union: 0-49 (50 pos), overlap: 20-29 (10 pos)
        # mm_rate1 = mm_rate2 = 3/30 = 0.1
        # expected_mm = 0.1*20 + 0.1*20 + 0.1*10 = 2 + 2 + 1 = 5
        # combined_pid = 1 - 5/50 = 0.9
        pos1 = list(range(30))
        pos2 = list(range(20, 50))
        assert compute_combined_pid(pos1, 3, pos2, 3) == pytest.approx(0.9)

    def test_overlapping_pair_asymmetric_mismatches(self):
        # r1: 0-29 (30 pos), nm=0; r2: 20-49 (30 pos), nm=6
        # mm_rate1=0, mm_rate2=6/30=0.2
        # unique_r1=20, unique_r2=20, overlap=10
        # expected_mm = 0*20 + 0.2*20 + (0+0.2)/2*10 = 0 + 4 + 1 = 5
        # combined_pid = 1 - 5/50 = 0.9
        pos1 = list(range(30))
        pos2 = list(range(20, 50))
        assert compute_combined_pid(pos1, 0, pos2, 6) == pytest.approx(0.9)

    def test_full_overlap_uses_average_mismatch_rate(self):
        # r1 and r2 cover identical positions (0-29), xm1=0, xm2=6
        # mm_rate1=0, mm_rate2=6/30=0.2
        # union=overlap=30, unique_r1=unique_r2=0
        # expected_mm = 0 + 0 + (0+0.2)/2 * 30 = 3
        # combined_pid = 1 - 3/30 = 0.9
        pos = list(range(30))
        assert compute_combined_pid(pos, 0, pos, 6) == pytest.approx(0.9)

    def test_symmetry(self):
        # Swapping reads should give the same result.
        pos1 = list(range(30))
        pos2 = list(range(20, 50))
        pid_12 = compute_combined_pid(pos1, 3, pos2, 1)
        pid_21 = compute_combined_pid(pos2, 1, pos1, 3)
        assert pid_12 == pytest.approx(pid_21)


# ---------------------------------------------------------------------------
# classify_reads  (uses PairAlignmentSummary)
# ---------------------------------------------------------------------------

def _ps(query_name: str, reference_name: str, pid: float) -> PairAlignmentSummary:
    return PairAlignmentSummary(
        query_name=query_name,
        reference_name=reference_name,
        combined_pid=pid,
        soft_clipped_bases=0,
        total_query_bases=100,
    )


class TestClassifyReads:
    def test_single_reference_always_assigned(self):
        result = classify_reads([_ps("r1", "ref_A", 0.5)], threshold=0.95)
        assert "r1" in result["ref_A"]

    def test_best_goes_to_winning_reference(self):
        result = classify_reads([
            _ps("r1", "ref_A", 1.0),
            _ps("r1", "ref_B", 0.5),
        ], threshold=0.95)
        assert "r1" in result["ref_A"]
        assert "r1" not in result.get("ref_B", set())

    def test_close_scores_assigned_to_both(self):
        result = classify_reads([
            _ps("r1", "ref_A", 1.0),
            _ps("r1", "ref_B", 0.97),
        ], threshold=0.95)
        assert "r1" in result["ref_A"]
        assert "r1" in result["ref_B"]

    def test_threshold_boundary(self):
        result = classify_reads([
            _ps("r1", "ref_A", 1.0),
            _ps("r1", "ref_B", 0.95),
        ], threshold=0.95)
        assert "r1" in result["ref_A"]
        assert "r1" in result["ref_B"]

    def test_just_below_threshold_excluded(self):
        result = classify_reads([
            _ps("r1", "ref_A", 1.0),
            _ps("r1", "ref_B", 0.94),
        ], threshold=0.95)
        assert "r1" in result["ref_A"]
        assert "r1" not in result.get("ref_B", set())

    def test_multiple_reads(self):
        result = classify_reads([
            _ps("r1", "ref_A", 1.0),
            _ps("r1", "ref_B", 0.50),
            _ps("r2", "ref_A", 0.60),
            _ps("r2", "ref_B", 1.0),
        ], threshold=0.95)
        assert result["ref_A"] == {"r1"}
        assert result["ref_B"] == {"r2"}

    def test_empty_input(self):
        assert classify_reads([], threshold=0.95) == {}

    def test_threshold_one_requires_perfect_tie(self):
        result = classify_reads([
            _ps("r1", "ref_A", 1.0),
            _ps("r1", "ref_B", 0.999),
        ], threshold=1.0)
        assert "r1" in result["ref_A"]
        assert "r1" not in result.get("ref_B", set())


# ---------------------------------------------------------------------------
# compute_assignment_stats
# ---------------------------------------------------------------------------

class TestComputeAssignmentStats:
    def test_all_sole(self):
        # r1 only in ref_A, r2 only in ref_B → both sole
        assignments = {"ref_A": {"r1"}, "ref_B": {"r2"}}
        result = compute_assignment_stats(assignments)
        assert result["ref_A"] == (1, 0)
        assert result["ref_B"] == (1, 0)

    def test_all_multi(self):
        # r1 in both refs → multi for both
        assignments = {"ref_A": {"r1"}, "ref_B": {"r1"}}
        result = compute_assignment_stats(assignments)
        assert result["ref_A"] == (0, 1)
        assert result["ref_B"] == (0, 1)

    def test_mixed(self):
        # r1 → both refs (multi); r2 → ref_A only (sole); r3 → ref_B only (sole)
        assignments = {"ref_A": {"r1", "r2"}, "ref_B": {"r1", "r3"}}
        result = compute_assignment_stats(assignments)
        assert result["ref_A"] == (1, 1)   # r2 sole, r1 multi
        assert result["ref_B"] == (1, 1)   # r3 sole, r1 multi

    def test_empty_assignments(self):
        assert compute_assignment_stats({}) == {}

    def test_single_reference(self):
        assignments = {"ref_A": {"r1", "r2", "r3"}}
        result = compute_assignment_stats(assignments)
        assert result["ref_A"] == (3, 0)
