"""Tests for midsplit.persite."""

import pytest
from unittest.mock import patch

from midsplit.persite import (
    SiteInfo,
    _consensus_bases_via_alignment,
    compute_per_site,
    read_fasta_sequence,
    write_per_site_tsv,
)
from tests.conftest import make_bam


# ---------------------------------------------------------------------------
# read_fasta_sequence
# ---------------------------------------------------------------------------

class TestReadFastaSequence:
    def test_single_record_no_name(self, tmp_path):
        fasta = tmp_path / "seq.fasta"
        fasta.write_text(">record1\nACGT\nACGT\n")
        assert read_fasta_sequence(fasta) == "ACGTACGT"

    def test_lowercased_to_upper(self, tmp_path):
        fasta = tmp_path / "seq.fasta"
        fasta.write_text(">rec\nacgt\n")
        assert read_fasta_sequence(fasta) == "ACGT"

    def test_named_record_found(self, tmp_path):
        fasta = tmp_path / "multi.fasta"
        fasta.write_text(">ref_A\nAAAA\n>ref_B\nCCCC\n")
        assert read_fasta_sequence(fasta, "ref_B") == "CCCC"

    def test_named_record_first(self, tmp_path):
        fasta = tmp_path / "multi.fasta"
        fasta.write_text(">ref_A\nAAAA\n>ref_B\nCCCC\n")
        assert read_fasta_sequence(fasta, "ref_A") == "AAAA"

    def test_name_not_found_returns_none(self, tmp_path):
        fasta = tmp_path / "seq.fasta"
        fasta.write_text(">ref_A\nACGT\n")
        assert read_fasta_sequence(fasta, "ref_Z") is None

    def test_empty_file_returns_none(self, tmp_path):
        fasta = tmp_path / "empty.fasta"
        fasta.write_text("")
        assert read_fasta_sequence(fasta) is None

    def test_multiline_sequence_joined(self, tmp_path):
        fasta = tmp_path / "ml.fasta"
        fasta.write_text(">seq\nACGT\nACGT\nACGT\n")
        assert read_fasta_sequence(fasta) == "ACGTACGTACGT"

    def test_header_name_matched_by_first_word(self, tmp_path):
        fasta = tmp_path / "desc.fasta"
        fasta.write_text(">ref_A some description here\nGGGG\n")
        assert read_fasta_sequence(fasta, "ref_A") == "GGGG"

    def test_no_name_returns_first_sequence(self, tmp_path):
        fasta = tmp_path / "multi.fasta"
        fasta.write_text(">first\nAAAA\n>second\nCCCC\n")
        assert read_fasta_sequence(fasta, None) == "AAAA"


# ---------------------------------------------------------------------------
# compute_per_site
# ---------------------------------------------------------------------------

class TestComputePerSite:
    def test_returns_correct_number_of_sites(self, two_ref_bam, tmp_path):
        # two_ref_bam fixture: process_bam writes per-ref BAMs; use it directly
        # to get a BAM for one reference.  Instead, build a small single-ref BAM.
        bam = make_bam(tmp_path, [("ref_A", 50)], [
            {"name": "r1", "ref": "ref_A", "pos": 1, "cigar": "10M",
             "seq": "A" * 10, "nm": 0},
        ], "single.bam")
        sites = compute_per_site(bam, 50)
        assert len(sites) == 50

    def test_positions_are_one_based(self, tmp_path):
        bam = make_bam(tmp_path, [("ref_A", 10)], [
            {"name": "r1", "ref": "ref_A", "pos": 1, "cigar": "10M",
             "seq": "A" * 10, "nm": 0},
        ], "single.bam")
        sites = compute_per_site(bam, 10)
        assert sites[0].position == 1
        assert sites[9].position == 10

    def test_covered_positions_have_nonzero_depth(self, tmp_path):
        bam = make_bam(tmp_path, [("ref_A", 20)], [
            {"name": "r1", "ref": "ref_A", "pos": 6, "cigar": "10M",
             "seq": "A" * 10, "nm": 0},
        ], "single.bam")
        sites = compute_per_site(bam, 20)
        # Positions 6-15 (1-based) should have depth 1; the rest 0.
        for i in range(5):          # positions 1-5
            assert sites[i].depth == 0
        for i in range(5, 15):      # positions 6-15
            assert sites[i].depth == 1
        for i in range(15, 20):     # positions 16-20
            assert sites[i].depth == 0

    def test_nucleotide_counts_correct(self, tmp_path):
        seq = "AACGT" * 2  # 10 bases: AACGTAACGT
        bam = make_bam(tmp_path, [("ref_A", 10)], [
            {"name": "r1", "ref": "ref_A", "pos": 1, "cigar": "10M",
             "seq": seq, "nm": 0},
        ], "single.bam")
        sites = compute_per_site(bam, 10)
        total_a = sum(s.count_a for s in sites)
        total_c = sum(s.count_c for s in sites)
        total_g = sum(s.count_g for s in sites)
        total_t = sum(s.count_t for s in sites)
        assert total_a == 4  # 2 per repeat × 2 repeats
        assert total_c == 2
        assert total_g == 2
        assert total_t == 2

    def test_two_reads_depth_two(self, tmp_path):
        bam = make_bam(tmp_path, [("ref_A", 20)], [
            {"name": "r1", "ref": "ref_A", "pos": 1, "cigar": "10M",
             "seq": "A" * 10, "nm": 0},
            {"name": "r2", "ref": "ref_A", "pos": 1, "cigar": "10M",
             "seq": "A" * 10, "nm": 0},
        ], "two.bam")
        sites = compute_per_site(bam, 20)
        for i in range(10):
            assert sites[i].depth == 2

    def test_uncovered_positions_all_zero(self, tmp_path):
        bam = make_bam(tmp_path, [("ref_A", 50)], [
            {"name": "r1", "ref": "ref_A", "pos": 1, "cigar": "5M",
             "seq": "A" * 5, "nm": 0},
        ], "short.bam")
        sites = compute_per_site(bam, 50)
        for i in range(5, 50):
            s = sites[i]
            assert s.depth == 0
            assert s.count_a == 0
            assert s.count_c == 0
            assert s.count_g == 0
            assert s.count_t == 0

    def test_ref_bases_from_fasta(self, tmp_path):
        bam = make_bam(tmp_path, [("ref_A", 5)], [
            {"name": "r1", "ref": "ref_A", "pos": 1, "cigar": "5M",
             "seq": "A" * 5, "nm": 0},
        ], "ref.bam")
        ref_fasta = tmp_path / "ref.fasta"
        ref_fasta.write_text(">ref_A\nACGTA\n")
        sites = compute_per_site(bam, 5, reference_fasta=ref_fasta, accession="ref_A")
        assert [s.ref_base for s in sites] == ["A", "C", "G", "T", "A"]

    def test_ref_base_defaults_to_n_without_fasta(self, tmp_path):
        bam = make_bam(tmp_path, [("ref_A", 5)], [
            {"name": "r1", "ref": "ref_A", "pos": 1, "cigar": "5M",
             "seq": "A" * 5, "nm": 0},
        ], "ref.bam")
        sites = compute_per_site(bam, 5)
        assert all(s.ref_base == "N" for s in sites)

    def test_consensus_bases_from_fasta(self, tmp_path):
        bam = make_bam(tmp_path, [("ref_A", 5)], [
            {"name": "r1", "ref": "ref_A", "pos": 1, "cigar": "5M",
             "seq": "A" * 5, "nm": 0},
        ], "cons.bam")
        cons_fasta = tmp_path / "cons.fasta"
        cons_fasta.write_text(">consensus\nTGCAT\n")
        sites = compute_per_site(bam, 5, consensus_fasta=cons_fasta)
        assert [s.consensus_base for s in sites] == ["T", "G", "C", "A", "T"]

    def test_consensus_bases_via_alignment_corrects_insertion_offset(self, tmp_path):
        # Consensus has an insertion (length 6 vs reference length 5).
        # Without alignment, position 5 would get the wrong base (the inserted
        # base at index 4 rather than the true consensus base at index 5).
        # With alignment the insertion is skipped and positions map correctly.
        bam = make_bam(tmp_path, [("ref_A", 5)], [
            {"name": "r1", "ref": "ref_A", "pos": 1, "cigar": "5M",
             "seq": "A" * 5, "nm": 0},
        ], "align.bam")
        ref_fasta = tmp_path / "ref.fasta"
        ref_fasta.write_text(">ref_A\nACGTA\n")
        cons_fasta = tmp_path / "cons.fasta"
        # Consensus has an insertion after position 2: ACXGTA (X = inserted base)
        cons_fasta.write_text(">consensus\nACXGTA\n")

        # _consensus_bases_via_alignment strips the inserted base (X at index 2)
        # so position i in the result maps 1:1 to reference position i+1.
        with patch(
            "midsplit.persite._consensus_bases_via_alignment",
            return_value=list("ACGTA"),
        ) as mock_align:
            sites = compute_per_site(
                bam, 5,
                consensus_fasta=cons_fasta,
                reference_fasta=ref_fasta,
                accession="ref_A",
                align=True,
            )
            mock_align.assert_called_once()

        assert [s.consensus_base for s in sites] == ["A", "C", "G", "T", "A"]

    def test_consensus_base_defaults_to_n_without_fasta(self, tmp_path):
        bam = make_bam(tmp_path, [("ref_A", 5)], [
            {"name": "r1", "ref": "ref_A", "pos": 1, "cigar": "5M",
             "seq": "A" * 5, "nm": 0},
        ], "cons.bam")
        sites = compute_per_site(bam, 5)
        assert all(s.consensus_base == "N" for s in sites)

    def test_empty_bam_all_zeros(self, tmp_path):
        bam = make_bam(tmp_path, [("ref_A", 10)], [], "empty.bam")
        sites = compute_per_site(bam, 10)
        assert len(sites) == 10
        assert all(s.depth == 0 for s in sites)

    def test_ref_length_limits_sites(self, tmp_path):
        bam = make_bam(tmp_path, [("ref_A", 100)], [
            {"name": "r1", "ref": "ref_A", "pos": 1, "cigar": "20M",
             "seq": "A" * 20, "nm": 0},
        ], "lim.bam")
        sites = compute_per_site(bam, 10)  # ask for only 10 sites
        assert len(sites) == 10


# ---------------------------------------------------------------------------
# write_per_site_tsv
# ---------------------------------------------------------------------------

class TestWritePerSiteTsv:
    def _make_sites(self) -> list[SiteInfo]:
        return [
            SiteInfo(position=1, ref_base="A", consensus_base="A",
                     depth=5, count_a=3, count_c=1, count_g=0, count_t=1),
            SiteInfo(position=2, ref_base="C", consensus_base="N",
                     depth=0, count_a=0, count_c=0, count_g=0, count_t=0),
        ]

    def test_creates_file(self, tmp_path):
        path = tmp_path / "out.tsv"
        write_per_site_tsv(self._make_sites(), path)
        assert path.exists()

    def test_header_line(self, tmp_path):
        path = tmp_path / "out.tsv"
        write_per_site_tsv(self._make_sites(), path)
        header = path.read_text().splitlines()[0]
        assert header == "site\tref_base\tconsensus_base\tdepth\tA\tC\tG\tT"

    def test_correct_number_of_rows(self, tmp_path):
        path = tmp_path / "out.tsv"
        write_per_site_tsv(self._make_sites(), path)
        lines = path.read_text().splitlines()
        assert len(lines) == 3  # header + 2 data rows

    def test_data_values(self, tmp_path):
        path = tmp_path / "out.tsv"
        write_per_site_tsv(self._make_sites(), path)
        rows = path.read_text().splitlines()
        assert rows[1] == "1\tA\tA\t5\t3\t1\t0\t1"
        assert rows[2] == "2\tC\tN\t0\t0\t0\t0\t0"

    def test_empty_sites_writes_header_only(self, tmp_path):
        path = tmp_path / "out.tsv"
        write_per_site_tsv([], path)
        lines = path.read_text().splitlines()
        assert len(lines) == 1
        assert lines[0].startswith("site\t")
