"""Tests for midsplit.stats."""

import pytest

from midsplit.stats import ReferenceAccumulator, compute_stats


class TestReferenceAccumulator:
    def test_initial_state(self):
        acc = ReferenceAccumulator("ref_A", 100)
        assert acc.sc_bases_before == 0
        assert acc.total_bases_before == 0
        assert acc.sc_bases_after == 0
        assert acc.total_bases_after == 0
        assert acc.read_count == 0
        assert acc.reads_sole == 0
        assert acc.reads_multi == 0
        assert len(acc.depth) == 100
        assert acc.depth.sum() == 0

    def test_add_alignment_before(self):
        acc = ReferenceAccumulator("ref_A", 100)
        acc.add_alignment_before(10, 100)
        acc.add_alignment_before(5, 50)
        assert acc.sc_bases_before == 15
        assert acc.total_bases_before == 150

    def test_add_alignment_after_updates_depth(self):
        acc = ReferenceAccumulator("ref_A", 100)
        acc.add_alignment_after(0, 10, list(range(10)))
        assert acc.read_count == 1
        assert acc.depth[:10].sum() == 10
        assert acc.depth[10:].sum() == 0

    def test_add_alignment_after_overlapping_reads(self):
        acc = ReferenceAccumulator("ref_A", 100)
        acc.add_alignment_after(0, 10, list(range(10)))
        acc.add_alignment_after(0, 10, list(range(5, 15)))
        assert acc.depth[0:5].sum() == 5    # depth 1
        assert acc.depth[5:10].sum() == 10  # depth 2 (5 positions * 2)
        assert acc.depth[10:15].sum() == 5  # depth 1

    def test_positions_out_of_range_ignored(self):
        acc = ReferenceAccumulator("ref_A", 10)
        acc.add_alignment_after(0, 5, [0, 5, 9, 10, 100])
        assert acc.depth[0] == 1
        assert acc.depth[5] == 1
        assert acc.depth[9] == 1
        assert acc.depth.sum() == 3  # position 10 and 100 ignored

    def test_reads_sole_and_multi_set_directly(self):
        acc = ReferenceAccumulator("ref_A", 100, reads_sole=10, reads_multi=3)
        assert acc.reads_sole == 10
        assert acc.reads_multi == 3


class TestComputeStats:
    def test_full_coverage(self):
        acc = ReferenceAccumulator("ref_A", 10)
        acc.add_alignment_after(0, 10, list(range(10)))
        stats = compute_stats(acc)
        assert stats.breadth == pytest.approx(1.0)
        assert stats.mean_depth == pytest.approx(1.0)

    def test_partial_coverage(self):
        acc = ReferenceAccumulator("ref_A", 10)
        acc.add_alignment_after(0, 5, list(range(5)))
        stats = compute_stats(acc)
        assert stats.breadth == pytest.approx(0.5)
        assert stats.mean_depth == pytest.approx(0.5)

    def test_median_depth(self):
        # depth array: [2, 2, 2, 2, 2, 0, 0, 0, 0, 0] → median = 1.0
        acc = ReferenceAccumulator("ref_A", 10)
        acc.add_alignment_after(0, 5, list(range(5)))
        acc.add_alignment_after(0, 5, list(range(5)))
        stats = compute_stats(acc)
        assert stats.median_depth == pytest.approx(1.0)  # median of [2,2,2,2,2,0,0,0,0,0]

    def test_min_max_depth(self):
        acc = ReferenceAccumulator("ref_A", 10)
        acc.add_alignment_after(0, 5, list(range(5)))
        stats = compute_stats(acc)
        assert stats.min_depth == 0   # uncovered positions
        assert stats.max_depth == 1

    def test_depth_std(self):
        # Uniform depth 1 across all 10 positions → std = 0
        acc = ReferenceAccumulator("ref_A", 10)
        acc.add_alignment_after(0, 10, list(range(10)))
        stats = compute_stats(acc)
        assert stats.depth_std == pytest.approx(0.0)

    def test_depth_std_nonzero(self):
        # Half positions at depth 2, half at 0 → non-zero std
        acc = ReferenceAccumulator("ref_A", 10)
        acc.add_alignment_after(0, 5, list(range(5)))
        acc.add_alignment_after(0, 5, list(range(5)))
        stats = compute_stats(acc)
        assert stats.depth_std > 0

    def test_reads_sole_and_multi_propagated(self):
        acc = ReferenceAccumulator("ref_A", 100, reads_sole=7, reads_multi=2)
        stats = compute_stats(acc)
        assert stats.reads_sole == 7
        assert stats.reads_multi == 2

    def test_soft_clip_pct_before(self):
        acc = ReferenceAccumulator("ref_A", 100)
        acc.add_alignment_before(10, 100)
        stats = compute_stats(acc)
        assert stats.soft_clip_pct_before == pytest.approx(10.0)

    def test_soft_clip_pct_after(self):
        acc = ReferenceAccumulator("ref_A", 100)
        acc.add_alignment_after(20, 100, [])
        stats = compute_stats(acc)
        assert stats.soft_clip_pct_after == pytest.approx(20.0)

    def test_zero_bases_returns_zero_pct(self):
        acc = ReferenceAccumulator("ref_A", 100)
        stats = compute_stats(acc)
        assert stats.soft_clip_pct_before == 0.0
        assert stats.soft_clip_pct_after == 0.0

    def test_read_count(self):
        acc = ReferenceAccumulator("ref_A", 100)
        acc.add_alignment_after(0, 30, list(range(30)))
        acc.add_alignment_after(0, 30, list(range(30, 60)))
        stats = compute_stats(acc)
        assert stats.read_count == 2

    def test_zero_length_reference(self):
        acc = ReferenceAccumulator("ref_A", 0)
        stats = compute_stats(acc)
        assert stats.breadth == 0.0
        assert stats.mean_depth == 0.0
        assert stats.median_depth == 0.0
        assert stats.min_depth == 0
        assert stats.max_depth == 0
        assert stats.depth_std == 0.0
