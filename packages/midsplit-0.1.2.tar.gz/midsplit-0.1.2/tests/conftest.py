"""Shared pytest fixtures for midsplit tests."""

import os
from pathlib import Path

import pysam
import pytest

# SAM flags for paired-end reads.
_FLAG_PAIRED_R1 = 0x41  # 65:  paired + first-in-pair
_FLAG_PAIRED_R2 = 0x81  # 129: paired + last-in-pair


def make_bam(
    tmp_path: Path,
    references: list[tuple[str, int]],
    reads: list[dict],
    filename: str = "test.bam",
) -> Path:
    """Create a sorted, indexed BAM file from synthetic read data.

    Args:
        tmp_path:   Temporary directory to write into.
        references: List of (name, length) tuples for @SQ header entries.
        reads:      List of dicts, each describing one alignment:
                      name   (str)  query name
                      ref    (str)  reference name (must be in references)
                      pos    (int)  1-based reference start
                      cigar  (str)  CIGAR string
                      seq    (str)  query sequence
                      nm     (int)  NM edit-distance tag value
                      flag   (int, optional) SAM flag (default 0)
                      mapq   (int, optional) mapping quality (default 60)
        filename:   Output filename within tmp_path.

    Returns:
        Path to the sorted, indexed BAM file.
    """
    ref_index = {name: i for i, (name, _) in enumerate(references)}

    header = pysam.AlignmentHeader.from_dict({
        "HD": {"VN": "1.6", "SO": "coordinate"},
        "SQ": [{"SN": name, "LN": length} for name, length in references],
    })

    unsorted_path = tmp_path / (filename + ".unsorted.bam")
    bam_path = tmp_path / filename

    with pysam.AlignmentFile(str(unsorted_path), "wb", header=header) as bam:
        for read in reads:
            seg = pysam.AlignedSegment(header)
            seg.query_name = read["name"]
            seg.query_sequence = read["seq"]
            seg.flag = read.get("flag", 0)
            seg.reference_id = ref_index[read["ref"]]
            seg.reference_start = read["pos"] - 1  # convert to 0-based
            seg.mapping_quality = read.get("mapq", 60)
            seg.cigarstring = read["cigar"]
            seg.query_qualities = pysam.qualitystring_to_array("I" * len(read["seq"]))
            seg.set_tag("NM", read["nm"])
            bam.write(seg)

    pysam.sort("-o", str(bam_path), str(unsorted_path))  # type: ignore[attr-defined]
    os.remove(str(unsorted_path))
    pysam.index(str(bam_path))  # type: ignore[attr-defined]
    return bam_path


@pytest.fixture
def two_ref_bam(tmp_path: Path) -> Path:
    """BAM with two references and single-end reads preferring different references.

    ref_A length 100, ref_B length 100.

    read1: ref_A nm=0 (pid=1.00), ref_B nm=5 (pid=0.833)  → ref_A only
    read2: ref_A nm=5 (pid=0.833), ref_B nm=0 (pid=1.00)  → ref_B only
    read3: ref_A nm=0 (pid=1.00),  ref_B nm=0 (pid=1.00)  → both
    """
    references = [("ref_A", 100), ("ref_B", 100)]
    seq = "A" * 30
    reads = [
        {"name": "read1", "ref": "ref_A", "pos": 1, "cigar": "30M", "seq": seq, "nm": 0},
        {"name": "read1", "ref": "ref_B", "pos": 1, "cigar": "30M", "seq": seq, "nm": 5},
        {"name": "read2", "ref": "ref_A", "pos": 1, "cigar": "30M", "seq": seq, "nm": 5},
        {"name": "read2", "ref": "ref_B", "pos": 1, "cigar": "30M", "seq": seq, "nm": 0},
        {"name": "read3", "ref": "ref_A", "pos": 1, "cigar": "30M", "seq": seq, "nm": 0},
        {"name": "read3", "ref": "ref_B", "pos": 1, "cigar": "30M", "seq": seq, "nm": 0},
    ]
    return make_bam(tmp_path, references, reads)


@pytest.fixture
def paired_two_ref_bam(tmp_path: Path) -> Path:
    """BAM with two references and non-overlapping paired-end reads.

    ref_A length 100, ref_B length 100.  Reads are 30 bp.

    pair1: r1 pos 1 (0-29), r2 pos 71 (70-99) — no overlap (insert ~100 bp)
      ref_A: r1 nm=0, r2 nm=0 → combined_pid = 1.00
      ref_B: r1 nm=5, r2 nm=5 → combined_pid = 1 - 10/60 ≈ 0.833
      → pair1 assigned to ref_A only (0.833 < 0.95)

    pair2: r1 pos 1 (0-29), r2 pos 71 (70-99)
      ref_A: r1 nm=5, r2 nm=5 → combined_pid ≈ 0.833
      ref_B: r1 nm=0, r2 nm=0 → combined_pid = 1.00
      → pair2 assigned to ref_B only
    """
    references = [("ref_A", 100), ("ref_B", 100)]
    seq = "A" * 30
    reads = [
        # pair1 r1
        {"name": "pair1", "ref": "ref_A", "pos":  1, "cigar": "30M", "seq": seq, "nm": 0, "flag": _FLAG_PAIRED_R1},
        {"name": "pair1", "ref": "ref_B", "pos":  1, "cigar": "30M", "seq": seq, "nm": 5, "flag": _FLAG_PAIRED_R1},
        # pair1 r2
        {"name": "pair1", "ref": "ref_A", "pos": 71, "cigar": "30M", "seq": seq, "nm": 0, "flag": _FLAG_PAIRED_R2},
        {"name": "pair1", "ref": "ref_B", "pos": 71, "cigar": "30M", "seq": seq, "nm": 5, "flag": _FLAG_PAIRED_R2},
        # pair2 r1
        {"name": "pair2", "ref": "ref_A", "pos":  1, "cigar": "30M", "seq": seq, "nm": 5, "flag": _FLAG_PAIRED_R1},
        {"name": "pair2", "ref": "ref_B", "pos":  1, "cigar": "30M", "seq": seq, "nm": 0, "flag": _FLAG_PAIRED_R1},
        # pair2 r2
        {"name": "pair2", "ref": "ref_A", "pos": 71, "cigar": "30M", "seq": seq, "nm": 5, "flag": _FLAG_PAIRED_R2},
        {"name": "pair2", "ref": "ref_B", "pos": 71, "cigar": "30M", "seq": seq, "nm": 0, "flag": _FLAG_PAIRED_R2},
    ]
    return make_bam(tmp_path, references, reads)


@pytest.fixture
def overlapping_pairs_bam(tmp_path: Path) -> Path:
    """BAM with two references and overlapping paired-end reads.

    ref_A length 100, ref_B length 100.  Reads are 30 bp.

    pair1: r1 pos 1 (0-29), r2 pos 21 (20-49) — 10 bp overlap (20-29)
      ref_A: r1 nm=0, r2 nm=0 → combined_pid = 1.00
      ref_B: r1 nm=3, r2 nm=3
        mm_rate = 3/30 = 0.1
        union=50, unique_r1=20, unique_r2=20, overlap=10
        expected_mm = 0.1*20 + 0.1*20 + 0.1*10 = 5
        combined_pid = 1 - 5/50 = 0.90
      → pair1 assigned to ref_A only (0.90 < 0.95 * 1.00)

    pair2: mirror — combined_pid ref_A=0.90, ref_B=1.00
      → pair2 assigned to ref_B only
    """
    references = [("ref_A", 100), ("ref_B", 100)]
    seq = "A" * 30
    reads = [
        # pair1 r1 (positions 0-29)
        {"name": "pair1", "ref": "ref_A", "pos":  1, "cigar": "30M", "seq": seq, "nm": 0, "flag": _FLAG_PAIRED_R1},
        {"name": "pair1", "ref": "ref_B", "pos":  1, "cigar": "30M", "seq": seq, "nm": 3, "flag": _FLAG_PAIRED_R1},
        # pair1 r2 (positions 20-49 — overlaps r1 at 20-29)
        {"name": "pair1", "ref": "ref_A", "pos": 21, "cigar": "30M", "seq": seq, "nm": 0, "flag": _FLAG_PAIRED_R2},
        {"name": "pair1", "ref": "ref_B", "pos": 21, "cigar": "30M", "seq": seq, "nm": 3, "flag": _FLAG_PAIRED_R2},
        # pair2 r1
        {"name": "pair2", "ref": "ref_A", "pos":  1, "cigar": "30M", "seq": seq, "nm": 3, "flag": _FLAG_PAIRED_R1},
        {"name": "pair2", "ref": "ref_B", "pos":  1, "cigar": "30M", "seq": seq, "nm": 0, "flag": _FLAG_PAIRED_R1},
        # pair2 r2
        {"name": "pair2", "ref": "ref_A", "pos": 21, "cigar": "30M", "seq": seq, "nm": 3, "flag": _FLAG_PAIRED_R2},
        {"name": "pair2", "ref": "ref_B", "pos": 21, "cigar": "30M", "seq": seq, "nm": 0, "flag": _FLAG_PAIRED_R2},
    ]
    return make_bam(tmp_path, references, reads)
