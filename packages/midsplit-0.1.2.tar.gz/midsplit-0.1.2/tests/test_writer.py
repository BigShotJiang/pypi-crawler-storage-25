"""Integration tests for midsplit.writer.process_bam."""

import pytest
import pysam

from midsplit.writer import process_bam


class TestProcessBam:
    """Single-end reads, two references (two_ref_bam fixture).

    read1 → ref_A (nm=0, pid=1.00), ref_B (nm=5, pid=0.833) → ref_A only
    read2 → ref_A (nm=5, pid=0.833), ref_B (nm=0, pid=1.00) → ref_B only
    read3 → ref_A (nm=0, pid=1.00),  ref_B (nm=0, pid=1.00) → both
    """

    def test_returns_both_references(self, two_ref_bam, tmp_path):
        stats, bam_paths, _ = process_bam(two_ref_bam, tmp_path / "out", threshold=0.95)
        assert set(stats.keys()) == {"ref_A", "ref_B"}
        assert set(bam_paths.keys()) == {"ref_A", "ref_B"}

    def test_output_bam_files_exist(self, two_ref_bam, tmp_path):
        _, bam_paths, _ = process_bam(two_ref_bam, tmp_path / "out", threshold=0.95)
        for path in bam_paths.values():
            assert path.exists(), f"Expected BAM not found: {path}"
            assert path.with_suffix(".bam.bai").exists() or \
                   (path.parent / (path.name + ".bai")).exists(), \
                   f"Expected index not found for: {path}"

    def test_ref_a_contains_correct_reads(self, two_ref_bam, tmp_path):
        _, bam_paths, _ = process_bam(two_ref_bam, tmp_path / "out", threshold=0.95)
        with pysam.AlignmentFile(str(bam_paths["ref_A"]), "rb") as bam:
            names = {seg.query_name for seg in bam}
        assert names == {"read1", "read3"}

    def test_ref_b_contains_correct_reads(self, two_ref_bam, tmp_path):
        _, bam_paths, _ = process_bam(two_ref_bam, tmp_path / "out", threshold=0.95)
        with pysam.AlignmentFile(str(bam_paths["ref_B"]), "rb") as bam:
            names = {seg.query_name for seg in bam}
        assert names == {"read2", "read3"}

    def test_output_bam_has_single_sq_header(self, two_ref_bam, tmp_path):
        _, bam_paths, _ = process_bam(two_ref_bam, tmp_path / "out", threshold=0.95)
        for ref_name, path in bam_paths.items():
            with pysam.AlignmentFile(str(path), "rb") as bam:
                sq = bam.header.to_dict().get("SQ", [])
            assert len(sq) == 1, f"{ref_name} BAM should have exactly one @SQ entry"
            assert sq[0]["SN"] == ref_name

    def test_read_counts(self, two_ref_bam, tmp_path):
        stats, _, _ = process_bam(two_ref_bam, tmp_path / "out", threshold=0.95)
        assert stats["ref_A"].read_count == 2
        assert stats["ref_B"].read_count == 2

    def test_assignment_breakdown(self, two_ref_bam, tmp_path):
        # read1 → ref_A sole; read2 → ref_B sole; read3 → both (multi)
        stats, _, _ = process_bam(two_ref_bam, tmp_path / "out", threshold=0.95)
        assert stats["ref_A"].reads_sole == 1   # read1
        assert stats["ref_A"].reads_multi == 1  # read3
        assert stats["ref_B"].reads_sole == 1   # read2
        assert stats["ref_B"].reads_multi == 1  # read3

    def test_coverage_breadth(self, two_ref_bam, tmp_path):
        # Both reads cover positions 0-29 (30M at pos 1). ref length = 100.
        stats, _, _ = process_bam(two_ref_bam, tmp_path / "out", threshold=0.95)
        assert stats["ref_A"].breadth == pytest.approx(0.30)
        assert stats["ref_B"].breadth == pytest.approx(0.30)

    def test_mean_depth(self, two_ref_bam, tmp_path):
        # Positions 0-29 depth 2, rest 0 → mean = 60/100 = 0.60
        stats, _, _ = process_bam(two_ref_bam, tmp_path / "out", threshold=0.95)
        assert stats["ref_A"].mean_depth == pytest.approx(0.60)
        assert stats["ref_B"].mean_depth == pytest.approx(0.60)

    def test_no_soft_clipping(self, two_ref_bam, tmp_path):
        stats, _, _ = process_bam(two_ref_bam, tmp_path / "out", threshold=0.95)
        for ref_name in ("ref_A", "ref_B"):
            assert stats[ref_name].soft_clip_pct_before == pytest.approx(0.0)
            assert stats[ref_name].soft_clip_pct_after == pytest.approx(0.0)

    def test_soft_clip_before_includes_unassigned_reads(self, tmp_path):
        """'before' for ref_A must include read2's alignment even though read2
        ends up in ref_B's bucket."""
        from tests.conftest import make_bam

        references = [("ref_A", 100), ("ref_B", 100)]
        reads = [
            {"name": "read1", "ref": "ref_A", "pos": 11, "cigar": "10S20M",
             "seq": "A" * 30, "nm": 0},
            {"name": "read2", "ref": "ref_A", "pos":  1, "cigar": "30M",
             "seq": "A" * 30, "nm": 10},
            {"name": "read2", "ref": "ref_B", "pos":  1, "cigar": "30M",
             "seq": "A" * 30, "nm": 0},
        ]
        bam = make_bam(tmp_path, references, reads, "sc_test.bam")
        stats, _, _ = process_bam(bam, tmp_path / "out", threshold=0.95)

        # ref_A before: read1 (10 SC / 30 total) + read2 (0 SC / 30 total) → 10/60
        assert stats["ref_A"].soft_clip_pct_before == pytest.approx(10 / 60 * 100)
        # ref_A after: only read1 assigned → 10/30
        assert stats["ref_A"].soft_clip_pct_after == pytest.approx(10 / 30 * 100)

    def test_threshold_zero_assigns_all_reads_to_all_refs(self, two_ref_bam, tmp_path):
        stats, bam_paths, _ = process_bam(two_ref_bam, tmp_path / "out", threshold=0.0)
        for ref_name in ("ref_A", "ref_B"):
            with pysam.AlignmentFile(str(bam_paths[ref_name]), "rb") as bam:
                names = {seg.query_name for seg in bam}
            assert names == {"read1", "read2", "read3"}

    def test_output_directory_created(self, two_ref_bam, tmp_path):
        out_dir = tmp_path / "new" / "nested" / "dir"
        assert not out_dir.exists()
        process_bam(two_ref_bam, out_dir, threshold=0.95)
        assert out_dir.exists()


class TestProcessBamPaired:
    """Non-overlapping paired-end reads (paired_two_ref_bam fixture).

    pair1: r1+r2 on ref_A (combined_pid=1.00), ref_B (combined_pid≈0.833) → ref_A
    pair2: r1+r2 on ref_A (combined_pid≈0.833), ref_B (combined_pid=1.00) → ref_B
    """

    def test_correct_assignment(self, paired_two_ref_bam, tmp_path):
        _, bam_paths, _ = process_bam(paired_two_ref_bam, tmp_path / "out", threshold=0.95)
        with pysam.AlignmentFile(str(bam_paths["ref_A"]), "rb") as bam:
            names_a = {seg.query_name for seg in bam}
        with pysam.AlignmentFile(str(bam_paths["ref_B"]), "rb") as bam:
            names_b = {seg.query_name for seg in bam}
        assert names_a == {"pair1"}
        assert names_b == {"pair2"}

    def test_both_mates_written(self, paired_two_ref_bam, tmp_path):
        """Both r1 and r2 of the assigned pair must appear in the output BAM."""
        _, bam_paths, _ = process_bam(paired_two_ref_bam, tmp_path / "out", threshold=0.95)
        with pysam.AlignmentFile(str(bam_paths["ref_A"]), "rb") as bam:
            segments = list(bam)
        assert len(segments) == 2, "Expected r1 and r2 for pair1 in ref_A BAM"
        flags = {seg.flag for seg in segments}
        assert 0x40 in {f & 0xC0 for f in flags}, "Expected read-1 flag"
        assert 0x80 in {f & 0xC0 for f in flags}, "Expected read-2 flag"

    def test_read_count_counts_individual_alignments(self, paired_two_ref_bam, tmp_path):
        # 2 mates per pair × 1 pair per reference = 2 alignment records each.
        stats, _, _ = process_bam(paired_two_ref_bam, tmp_path / "out", threshold=0.95)
        assert stats["ref_A"].read_count == 2
        assert stats["ref_B"].read_count == 2

    def test_coverage_breadth_non_overlapping(self, paired_two_ref_bam, tmp_path):
        # pair1 r1: positions 0-29; r2: positions 70-99 → 60/100 = 0.60
        stats, _, _ = process_bam(paired_two_ref_bam, tmp_path / "out", threshold=0.95)
        assert stats["ref_A"].breadth == pytest.approx(0.60)

    def test_mean_depth_non_overlapping(self, paired_two_ref_bam, tmp_path):
        # 60 positions at depth 1, 40 at depth 0 → mean = 60/100 = 0.60
        stats, _, _ = process_bam(paired_two_ref_bam, tmp_path / "out", threshold=0.95)
        assert stats["ref_A"].mean_depth == pytest.approx(0.60)


class TestProcessBamOverlapping:
    """Overlapping paired-end reads (overlapping_pairs_bam fixture).

    pair1: r1 pos 0-29, r2 pos 20-49, 10 bp overlap (20-29)
      ref_A combined_pid=1.00, ref_B combined_pid=0.90 → ref_A only
    pair2: mirror → ref_B only
    """

    def test_correct_assignment(self, overlapping_pairs_bam, tmp_path):
        _, bam_paths, _ = process_bam(overlapping_pairs_bam, tmp_path / "out", threshold=0.95)
        with pysam.AlignmentFile(str(bam_paths["ref_A"]), "rb") as bam:
            names_a = {seg.query_name for seg in bam}
        with pysam.AlignmentFile(str(bam_paths["ref_B"]), "rb") as bam:
            names_b = {seg.query_name for seg in bam}
        assert names_a == {"pair1"}
        assert names_b == {"pair2"}

    def test_both_mates_written(self, overlapping_pairs_bam, tmp_path):
        """Both r1 and r2 of the pair must be written even though they overlap."""
        _, bam_paths, _ = process_bam(overlapping_pairs_bam, tmp_path / "out", threshold=0.95)
        with pysam.AlignmentFile(str(bam_paths["ref_A"]), "rb") as bam:
            segments = list(bam)
        assert len(segments) == 2

    def test_overlap_aware_pid_excludes_bad_ref(self, overlapping_pairs_bam, tmp_path):
        """pair1's combined_pid for ref_B is 0.90, which is < 0.95*1.00=0.95,
        so ref_B should have no entry for pair1."""
        _, bam_paths, _ = process_bam(overlapping_pairs_bam, tmp_path / "out", threshold=0.95)
        with pysam.AlignmentFile(str(bam_paths["ref_B"]), "rb") as bam:
            names = {seg.query_name for seg in bam}
        assert "pair1" not in names

    def test_coverage_accounts_for_overlap(self, overlapping_pairs_bam, tmp_path):
        # pair1 assigned to ref_A: r1 covers 0-29, r2 covers 20-49.
        # Union of positions = 0-49 (50 positions) — overlap counted once.
        # Depth: positions 0-19 depth 1, positions 20-29 depth 2, 30-49 depth 1.
        # breadth = 50/100 = 0.50
        # mean_depth = (20*1 + 10*2 + 20*1) / 100 = 60/100 = 0.60
        stats, _, _ = process_bam(overlapping_pairs_bam, tmp_path / "out", threshold=0.95)
        assert stats["ref_A"].breadth == pytest.approx(0.50)
        assert stats["ref_A"].mean_depth == pytest.approx(0.60)

    def test_threshold_that_admits_both_refs(self, overlapping_pairs_bam, tmp_path):
        # With threshold=0.89 (< 0.90), pair1's ref_B pid=0.90 >= 0.89*1.00
        # so pair1 should appear in both ref_A and ref_B.
        _, bam_paths, _ = process_bam(overlapping_pairs_bam, tmp_path / "out", threshold=0.89)
        with pysam.AlignmentFile(str(bam_paths["ref_A"]), "rb") as bam:
            names_a = {seg.query_name for seg in bam}
        with pysam.AlignmentFile(str(bam_paths["ref_B"]), "rb") as bam:
            names_b = {seg.query_name for seg in bam}
        assert "pair1" in names_a
        assert "pair1" in names_b


class TestRunSummary:
    """run_summary returned as third value from process_bam."""

    def test_total_reads_single_end(self, two_ref_bam, tmp_path):
        # read1, read2, read3 — 3 unique query names
        _, _, summary = process_bam(two_ref_bam, tmp_path / "out", threshold=0.95)
        assert summary.total_reads == 3

    def test_total_alignments_single_end(self, two_ref_bam, tmp_path):
        # 3 reads × 2 references = 6 primary alignment records
        _, _, summary = process_bam(two_ref_bam, tmp_path / "out", threshold=0.95)
        assert summary.total_alignments == 6

    def test_refs_per_read_all_match_two(self, two_ref_bam, tmp_path):
        # All three reads align to both ref_A and ref_B → {2: 3}
        _, _, summary = process_bam(two_ref_bam, tmp_path / "out", threshold=0.95)
        assert summary.refs_per_read == {2: 3}

    def test_total_reads_paired(self, paired_two_ref_bam, tmp_path):
        # pair1 and pair2 — 2 unique query names
        _, _, summary = process_bam(paired_two_ref_bam, tmp_path / "out", threshold=0.95)
        assert summary.total_reads == 2

    def test_total_alignments_paired(self, paired_two_ref_bam, tmp_path):
        # 2 pairs × 2 mates × 2 references = 8 primary alignment records
        _, _, summary = process_bam(paired_two_ref_bam, tmp_path / "out", threshold=0.95)
        assert summary.total_alignments == 8

    def test_refs_per_read_paired_all_match_two(self, paired_two_ref_bam, tmp_path):
        # Both pairs align to both references → {2: 2}
        _, _, summary = process_bam(paired_two_ref_bam, tmp_path / "out", threshold=0.95)
        assert summary.refs_per_read == {2: 2}

    def test_total_alignments_always_gte_total_reads(self, two_ref_bam, tmp_path):
        _, _, summary = process_bam(two_ref_bam, tmp_path / "out", threshold=0.95)
        assert summary.total_alignments >= summary.total_reads


class TestSecondaryAlignments:
    """Secondary alignments (flag 0x100) must be processed, not skipped.

    Bowtie2 -k/-a marks all alignments beyond the best-scoring one as
    secondary.  In a multi-reference BAM the alignment to every reference
    other than the top hit carries this flag, so skipping secondary
    alignments would silently discard all but the primary reference match.
    Supplementary alignments (0x800, chimeric/split reads) are still skipped.
    """

    def test_secondary_alignments_are_classified(self, tmp_path):
        """A read whose ref_B alignment is flagged secondary must still be
        assigned to ref_B when its pid there is the best."""
        from tests.conftest import make_bam

        references = [("ref_A", 100), ("ref_B", 100)]
        seq = "A" * 30
        # read1: primary alignment to ref_A (nm=5, pid=0.833),
        #        secondary alignment to ref_B (nm=0, pid=1.00).
        # Expected: assigned to ref_B only (0.833 < 0.95 * 1.00).
        reads = [
            {"name": "read1", "ref": "ref_A", "pos": 1, "cigar": "30M",
             "seq": seq, "nm": 5, "flag": 0},
            {"name": "read1", "ref": "ref_B", "pos": 1, "cigar": "30M",
             "seq": seq, "nm": 0, "flag": 0x100},  # secondary
        ]
        bam = make_bam(tmp_path, references, reads, "sec.bam")
        _, bam_paths, _ = process_bam(bam, tmp_path / "out", threshold=0.95)
        with pysam.AlignmentFile(str(bam_paths["ref_B"]), "rb") as b:
            names = {seg.query_name for seg in b}
        assert "read1" in names
        assert "ref_A" not in bam_paths  # no reads assigned to ref_A

    def test_supplementary_alignments_are_still_skipped(self, tmp_path):
        """Supplementary alignments (chimeric) must not be processed."""
        from tests.conftest import make_bam

        references = [("ref_A", 100)]
        seq = "A" * 30
        reads = [
            {"name": "read1", "ref": "ref_A", "pos":  1, "cigar": "30M",
             "seq": seq, "nm": 0, "flag": 0},
            {"name": "read1", "ref": "ref_A", "pos": 50, "cigar": "30M",
             "seq": seq, "nm": 0, "flag": 0x800},  # supplementary
        ]
        bam = make_bam(tmp_path, references, reads, "supp.bam")
        _, _, summary = process_bam(bam, tmp_path / "out", threshold=0.95)
        # Only the primary alignment should be counted.
        assert summary.total_alignments == 1

    def test_multi_mapping_within_reference_uses_best_alignment(self, tmp_path):
        """When a read has multiple secondary alignments to the same reference
        (multi-mapping within one reference), the one with the lowest NM is
        used for classification."""
        from tests.conftest import make_bam

        references = [("ref_A", 200), ("ref_B", 200)]
        seq = "A" * 30
        # read1 has two secondary alignments to ref_A at different positions.
        # The second one (nm=1) is better than the first (nm=5).
        # ref_B has a primary alignment with nm=3.
        # Best pid for ref_A = (30-1)/30 ≈ 0.967, which beats ref_B's (30-3)/30 = 0.9.
        # So read1 should be assigned to ref_A only.
        reads = [
            {"name": "read1", "ref": "ref_B", "pos":   1, "cigar": "30M",
             "seq": seq, "nm": 3, "flag": 0},           # primary → ref_B
            {"name": "read1", "ref": "ref_A", "pos":   1, "cigar": "30M",
             "seq": seq, "nm": 5, "flag": 0x100},       # secondary → ref_A (worse)
            {"name": "read1", "ref": "ref_A", "pos": 100, "cigar": "30M",
             "seq": seq, "nm": 1, "flag": 0x100},       # secondary → ref_A (better)
        ]
        bam = make_bam(tmp_path, references, reads, "multimap.bam")
        _, bam_paths, _ = process_bam(bam, tmp_path / "out", threshold=0.95)
        with pysam.AlignmentFile(str(bam_paths["ref_A"]), "rb") as b:
            names_a = {seg.query_name for seg in b}
        assert "read1" in names_a
        assert "ref_B" not in bam_paths
