"""Picolayer MCP Server.

A Model Context Protocol server that exposes the Picolayer embedded testing
platform to AI agents. Tools cover the existing job flow (P0) and the new
session flow (P1). Resources expose the board catalog, config schema, examples,
peripheral types, CPU types, and Robot Framework keyword reference so agents
can generate ``picolayer.yml`` and ``.robot`` test files without guessing.
"""

from __future__ import annotations

__version__ = "0.1.9"
