"""``picolayer://robot-keywords`` — Robot Framework keyword reference for Renode tests.

These are the keywords most commonly used in Picolayer test suites. The
agent uses this when generating ``.robot`` files. Renode ships a much
larger keyword library — see
https://renode.readthedocs.io/en/latest/basic/testing.html for the full set.
"""

from __future__ import annotations

import json

KEYWORDS: list[dict[str, object]] = [
    {
        "keyword": "Execute Script",
        "args": ["script_path"],
        "description": "Run a .resc setup script. Picolayer auto-generates one at ${CURDIR}/setup.resc.",
        "example": "Execute Script  ${CURDIR}/setup.resc",
    },
    {
        "keyword": "Create LED Tester",
        "args": ["led_path", "defaultTimeout=<seconds>"],
        "description": "Create a tester observing an LED GPIO output.",
        "example": "Create LED Tester  sysbus.gpioPortD.UserLED  defaultTimeout=5",
    },
    {
        "keyword": "Assert LED State",
        "args": ["state", "timeout=<seconds>"],
        "description": "Wait for the LED to reach the given state (true|false).",
        "example": "Assert LED State  true",
    },
    {
        "keyword": "Create Terminal Tester",
        "args": ["uart_path", "defaultTimeout=<seconds>"],
        "description": "Attach a terminal tester to a UART so subsequent Wait For Line keywords work.",
        "example": "Create Terminal Tester  sysbus.usart2  defaultTimeout=10",
    },
    {
        "keyword": "Wait For Line On Uart",
        "args": ["expected_text", "timeout=<seconds>", "treatAsRegex=<bool>"],
        "description": "Block until the given line appears on the most recent terminal tester.",
        "example": "Wait For Line On Uart  Boot OK  timeout=5",
    },
    {
        "keyword": "Write Line To Uart",
        "args": ["text"],
        "description": "Inject a line on the most recent terminal tester.",
        "example": "Write Line To Uart  status",
    },
    {
        "keyword": "Start Emulation",
        "args": [],
        "description": "Start the Renode emulation. Required after machine setup before any assertions.",
        "example": "Start Emulation",
    },
    {
        "keyword": "Pause Emulation",
        "args": [],
        "description": "Pause the running emulation.",
    },
    {
        "keyword": "Reset Emulation",
        "args": [],
        "description": "Reset the current machine.",
    },
    {
        "keyword": "Execute Command",
        "args": ["renode_monitor_command"],
        "description": "Run an arbitrary Renode Monitor command.",
        "example": "Execute Command  cpu PerformanceInMips 125",
    },
]

GUIDANCE = """\
## Setup script

**Single-device tests** (board: or hardware: configs): use `Execute Script  ${RESC}`.
The executor auto-generates a setup.resc and passes it via the RESC variable.
Do NOT reference custom .resc files — only the test script and firmware are
uploaded to the remote executor.

**Multi-device tests** (renode.machines configs): use `Execute Script  ${CURDIR}/setup.resc`.
The executor generates setup.resc from the picolayer.yml machines list and
places it adjacent to the test script. The generated script creates all
machines, loads platform descriptions, loads firmware, and runs init_resc
commands (e.g. BLE medium setup).

## Robot Framework syntax

Arguments to keywords MUST be separated by 2+ spaces. Single space is treated
as part of the argument text. Example:

    CORRECT:   Wait For Line On Uart    Boot OK    testerId=${uart}    timeout=5
    WRONG:     Wait For Line On Uart    Boot OK testerId=${uart} timeout=5

## Multi-machine UART

For multi-machine tests, pass `machine=<name>` when creating terminal testers:

    ${hrm}=    Create Terminal Tester    sysbus.uart0    machine=hrm-sensor
    ${dsp}=    Create Terminal Tester    sysbus.uart0    machine=wrist-display
    Wait For Line On Uart    Boot OK    testerId=${hrm}    timeout=5

## Test case scoping

Renode resets emulation between test cases. Terminal testers from one test case
do NOT survive into the next. Put all assertions in a single test case, or use
Suite Setup for shared setup.

## Emulation limits

BLE: Renode emulates the radio layer (advertising, scanning, connecting) but
GATT attribute operations (service discovery, subscribe, notify) may not work
for all firmware. Test up to the connection layer and verify GATT via UART
output strings if the firmware supports it.
"""


def robot_keywords_resource() -> str:
    return json.dumps(
        {
            "version": 1,
            "guidance": GUIDANCE.strip(),
            "keywords": KEYWORDS,
        },
        indent=2,
    )
