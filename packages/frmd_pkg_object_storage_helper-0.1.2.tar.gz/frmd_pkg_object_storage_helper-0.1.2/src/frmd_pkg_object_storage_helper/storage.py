from __future__ import annotations

import os
from dataclasses import dataclass
from typing import Final
from urllib.parse import unquote, urlsplit

from minio import Minio
from minio.error import S3Error
from s3fs import S3FileSystem

_URL_ENV_VARS: Final[tuple[str, ...]] = ("OBJECT_STORAGE_URL", "S3_URL")
_ENDPOINT_ENV_VARS: Final[tuple[str, ...]] = ("S3_ENDPOINT", "AWS_ENDPOINT_URL")
_ACCESS_KEY_ENV_VARS: Final[tuple[str, ...]] = (
    "S3_ACCESS_KEY",
    "AWS_ACCESS_KEY_ID",
    "MINIO_ROOT_USER",
)
_SECRET_KEY_ENV_VARS: Final[tuple[str, ...]] = (
    "S3_SECRET_KEY",
    "AWS_SECRET_ACCESS_KEY",
    "MINIO_ROOT_PASSWORD",
)
_REGION_ENV_VARS: Final[tuple[str, ...]] = (
    "S3_REGION",
    "AWS_REGION",
    "AWS_DEFAULT_REGION",
)


@dataclass(frozen=True, slots=True)
class ObjectStorageSettings:
    endpoint: str
    access_key: str
    secret_key: str
    secure: bool = True
    region: str | None = None

    @property
    def endpoint_url(self) -> str:
        scheme = "https" if self.secure else "http"
        return f"{scheme}://{self.endpoint}"

    @classmethod
    def from_env(cls) -> ObjectStorageSettings:
        parsed_from_url = _parse_endpoint(_first_env(_URL_ENV_VARS))
        parsed_from_endpoint = _parse_endpoint(_first_env(_ENDPOINT_ENV_VARS))
        parsed = parsed_from_url or parsed_from_endpoint

        if parsed is None:
            raise ValueError(
                "Missing object storage configuration. Set OBJECT_STORAGE_URL, "
                "S3_URL, S3_ENDPOINT, or AWS_ENDPOINT_URL."
            )

        secure_override = _parse_optional_bool(os.getenv("S3_SECURE"))
        secure = parsed.secure if secure_override is None else secure_override

        access_key = parsed.access_key or _first_env(_ACCESS_KEY_ENV_VARS)
        secret_key = parsed.secret_key or _first_env(_SECRET_KEY_ENV_VARS)

        if not access_key or not secret_key:
            raise ValueError(
                "Missing object storage credentials. Provide them in OBJECT_STORAGE_URL/"
                "S3_URL or via S3_ACCESS_KEY and S3_SECRET_KEY."
            )

        return cls(
            endpoint=parsed.endpoint,
            access_key=access_key,
            secret_key=secret_key,
            secure=secure,
            region=_first_env(_REGION_ENV_VARS),
        )


@dataclass(frozen=True, slots=True)
class _ParsedEndpoint:
    endpoint: str
    secure: bool
    access_key: str | None = None
    secret_key: str | None = None


def get_client(settings: ObjectStorageSettings | None = None) -> Minio:
    resolved_settings = settings or ObjectStorageSettings.from_env()
    client_kwargs: dict[str, str | bool] = {
        "endpoint": resolved_settings.endpoint,
        "access_key": resolved_settings.access_key,
        "secret_key": resolved_settings.secret_key,
        "secure": resolved_settings.secure,
    }

    if resolved_settings.region:
        client_kwargs["region"] = resolved_settings.region

    return Minio(**client_kwargs)


def get_filesystem(settings: ObjectStorageSettings | None = None) -> S3FileSystem:
    resolved_settings = settings or ObjectStorageSettings.from_env()
    filesystem_kwargs: dict[str, object] = {
        "anon": False,
        "key": resolved_settings.access_key,
        "secret": resolved_settings.secret_key,
        "endpoint_url": resolved_settings.endpoint_url,
    }

    if resolved_settings.region:
        filesystem_kwargs["client_kwargs"] = {"region_name": resolved_settings.region}

    return S3FileSystem(**filesystem_kwargs)


def object_exists(client: Minio, bucket_name: str, object_name: str) -> bool:
    try:
        client.stat_object(bucket_name=bucket_name, object_name=object_name)
    except S3Error as error:
        if error.code in {
            "NoSuchBucket",
            "NoSuchKey",
            "NoSuchObject",
            "ResourceNotFound",
        }:
            return False
        raise

    return True


def to_object_storage_path(bucket_name: str, object_name: str) -> str:
    return f"{bucket_name}/{object_name}"


def from_object_storage_path(path: str) -> tuple[str, str]:
    bucket_name, separator, object_name = path.partition("/")

    if separator == "":
        raise ValueError(f"Invalid object storage path: {path}")

    return bucket_name, object_name


def _first_env(names: tuple[str, ...]) -> str | None:
    for name in names:
        value = os.getenv(name)
        if value:
            return value
    return None


def _parse_endpoint(value: str | None) -> _ParsedEndpoint | None:
    if not value:
        return None

    if "://" not in value:
        return _ParsedEndpoint(endpoint=value.rstrip("/"), secure=True)

    parsed = urlsplit(value)

    if parsed.scheme not in {"http", "https"}:
        raise ValueError(f"Unsupported object storage URL scheme: {parsed.scheme}")

    if not parsed.hostname:
        raise ValueError(f"Invalid object storage URL: {value}")

    if parsed.path not in {"", "/"}:
        raise ValueError(
            f"Object storage endpoint URLs must not include a path. Received: {value}"
        )

    endpoint = parsed.hostname
    if parsed.port is not None:
        endpoint = f"{endpoint}:{parsed.port}"

    return _ParsedEndpoint(
        endpoint=endpoint,
        secure=parsed.scheme == "https",
        access_key=unquote(parsed.username) if parsed.username else None,
        secret_key=unquote(parsed.password) if parsed.password else None,
    )


def _parse_optional_bool(value: str | None) -> bool | None:
    if value is None:
        return None

    normalized = value.strip().lower()
    if normalized in {"1", "true", "yes", "on"}:
        return True
    if normalized in {"0", "false", "no", "off"}:
        return False

    raise ValueError(f"Invalid boolean value for S3_SECURE: {value}")
