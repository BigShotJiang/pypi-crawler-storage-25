from __future__ import annotations
from pathlib import Path
from typing import AsyncGenerator, Awaitable, Callable

from autopilot.agent.events import AgentEvent, AgentEventType
from autopilot.client.response import StreamEventType, TokenUsage, ToolCall, ToolResultMessage
from autopilot.config.config import Config
import json
from autopilot.agent.session import Session
from autopilot.prompts.system import create_loop_breaker_prompt
from autopilot.tools.base import ToolConfirmation


class Agent:
    def __init__(self, config: Config, confirmation_callback: Callable[[ToolConfirmation], Awaitable[bool]] | None = None):
        # all variables are specific to a session, to avoid memory leaks, context pollution and maintain isolation while focusing concurrency
        self.session: Session | None = Session(
            config=config, confirmation_callback=confirmation_callback)
        self.config = config

    async def run(self, message: str):
        assert self.session is not None
        assert self.session.context_manager is not None
        final_response = None
        await self.session.hook_system.trigger_before_agent(message)
        yield AgentEvent.agent_start(message)
        if not self.session:
            raise RuntimeError("Session missing")

        if self.session.context_manager is None:
            raise RuntimeError("Context manager not initialized")

        self.session.context_manager.add_user_message(message)

        try:
            async for event in self._agentic_loop():
                yield event

                if event.type == AgentEventType.TEXT_COMPLETE:
                    final_response = event.data.get("content")

        except Exception as e:
            print("AGENT LOOP CRASHED:", e)
            raise
        await self.session.hook_system.trigger_after_agent(message, str(final_response))
        yield AgentEvent.agent_end(final_response)

    async def _agentic_loop(self) -> AsyncGenerator[AgentEvent, None]:

        max_turns = self.config.max_turns

        for turn_num in range(max_turns):
            if not self.session:
                raise RuntimeError("Session missing")
            self.session.increment_turn()

            response_text = ""
            # print(self.context_manager.get_messages())

            # check for context overflow

            if not self.session.client:
                raise RuntimeError("agent must be used in a 'async with' block")

            assert self.session.context_manager is not None

            if self.session.context_manager.needs_compression():
                summary, usage = await self.session.chat_compactor.compress(
                    self.session.context_manager
                )
                assert usage is not None
                # compression also uses tokens, usme bhi llm ko kol rahe to summarize this
                if summary:
                    self.session.context_manager.replace_context_with_summary(summary)
                    self.session.context_manager.set_latest_usage(usage)
                    self.session.context_manager.add_usage(usage)

            tool_schemas = self.session.tool_registry.get_schemas()

            tool_calls: list[ToolCall] = []
            usage: TokenUsage | None = None

            assert self.session is not None
            assert self.session.context_manager is not None

            async for event in self.session.client.chat_completion(
                    messages=self.session.context_manager.get_messages(),
                    tools=tool_schemas if tool_schemas else None,
                    stream=True
            ):
                # print(event)
                if event.type == StreamEventType.TEXT_DELTA:
                    if event.text_delta:
                        content = event.text_delta.content
                        # print("hello")
                        response_text += content
                        yield AgentEvent.text_delta(content)

                elif event.type == StreamEventType.TOOL_CALL_COMPLETE:
                    if event.tool_call:
                        tool_calls.append(event.tool_call)

                elif event.type == StreamEventType.ERROR:
                    yield AgentEvent.agent_end(event.error or "Unknown error occured.")

                elif event.type == StreamEventType.MESSAGE_COMPLETE:
                    usage = event.usage

            # print("response_text is this", response_text)
            self.session.context_manager.add_assistant_message(
                response_text,
                (
                    [
                        {
                            "id": tc.call_id,
                            "type": "function",
                            "function": {
                                "name": tc.name,
                                # loads to convert into python object like dict or list
                                # dumps to convert string to json object
                                "arguments": json.dumps(tc.arguments)
                            }
                        }
                        for tc in tool_calls
                    ]
                ) if tool_calls else None
            )

            if response_text:
                yield AgentEvent.text_complete(response_text)
                self.session.loop_detector.record_action(
                    "response",
                    text=response_text
                )

            if not tool_calls:
                if usage:
                    self.session.context_manager.set_latest_usage(usage)
                    self.session.context_manager.add_usage(usage)
                    # early calcuation and then return (more efficient)
                    pruned_tokens = self.session.context_manager.prune_tool_outputs()
                return

            tool_call_results: list[ToolResultMessage] = []
            for tool_call in tool_calls:
                yield AgentEvent.tool_call_start(
                    tool_call.call_id,
                    tool_call.name,
                    tool_call.arguments
                )

                self.session.loop_detector.record_action(
                    "tool_call",
                    tool_name=tool_call.name,
                    args=tool_call.arguments
                )

                loop_detection_error = self.session.loop_detector.check_for_loop()
                if loop_detection_error:
                    loop_prompt = create_loop_breaker_prompt(loop_detection_error)
                    self.session.context_manager.add_user_message(loop_prompt)
                    yield AgentEvent.loop_detected(
                        reason=loop_detection_error,
                        history=[h[1] for h in self.session.loop_detector._history]
                    )
                    continue

                result = await self.session.tool_registry.invoke(
                    name=tool_call.name,
                    params=tool_call.arguments,
                    cwd=Path.cwd(),
                    hook_system=self.session.hook_system,
                    approval_manager=self.session.approval_manager,
                )

                self.session.loop_detector.record_action(
                    "tool_result",
                    result=result.output
                )

                loop_detection_error = self.session.loop_detector.check_for_loop()

                if loop_detection_error:
                    loop_prompt = create_loop_breaker_prompt(loop_detection_error)

                    self.session.context_manager.add_user_message(loop_prompt)

                    yield AgentEvent.loop_detected(
                        reason=loop_detection_error,
                        history=[h[1] for h in self.session.loop_detector._history]
                    )

                    break

                yield AgentEvent.tool_call_complete(
                    tool_call.call_id,
                    tool_call.name,
                    result
                )
                # just formatting everything before adding to the global context to suit LLM formats
                tool_call_results.append(
                    ToolResultMessage(
                        tool_call_id=tool_call.call_id,
                        content=result.to_model_output(),
                        is_error=not result.success
                    )
                )

            for tool_result in tool_call_results:
                self.session.context_manager.add_tool_result(
                    tool_result.tool_call_id,
                    tool_result.content
                )

            if usage:
                # updating token usage after tool call results
                self.session.context_manager.set_latest_usage(usage)
                self.session.context_manager.add_usage(usage)

            pruned_tokens = self.session.context_manager.prune_tool_outputs()

        yield AgentEvent.agent_error(f"Maximum turns ({max_turns})")

    # __ is used for reserved keywords and methods in python, aenter is for async enter

    async def __aenter__(self) -> Agent:
        if self.session is None:
            raise RuntimeError("Session not initialized")
        await self.session.initialize()
        return self

    async def __aexit__(self,
                        exc_type,
                        exc_val,
                        exc_tb) -> None:
        if self.session and self.session.client and self.session.mcp_manager:
            await self.session.client.close()
            await self.session.mcp_manager.shutdown()
            self.session = None
