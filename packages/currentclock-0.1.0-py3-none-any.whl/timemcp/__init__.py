from clock.core import now

__all__ = ["now"]
