"""AIVibe MCP server — read-only tools for querying platform data."""

from __future__ import annotations

from mcp.server.fastmcp import FastMCP

from aivibe_mcp.client import api_get

mcp = FastMCP("aivibe")


# ── Organizations ────────────────────────────────────────────────────────────

@mcp.tool()
def list_organizations() -> str:
    """List all accessible organizations. Names are anonymized (shown as org codes)."""
    return api_get("/api/platform/orgs")


@mcp.tool()
def get_organization(org_id: int) -> str:
    """Get organization details by ID."""
    return api_get(f"/api/platform/orgs/{org_id}")


# ── Surveys (Diagnose module) ───────────────────────────────────────────────

@mcp.tool()
def list_surveys(org_id: int | None = None) -> str:
    """List surveys, optionally filtered by organization ID."""
    params = {"organization_id": org_id} if org_id is not None else None
    return api_get("/api/diagnose/surveys", params=params)


@mcp.tool()
def get_survey(survey_id: str) -> str:
    """Get survey details by ID."""
    return api_get(f"/api/diagnose/surveys/{survey_id}")


@mcp.tool()
def get_survey_results(survey_id: str) -> str:
    """Get survey analytics and results summary."""
    return api_get(f"/api/diagnose/reporting/analytics/{survey_id}")


# ── Teams (Map module) ──────────────────────────────────────────────────────

@mcp.tool()
def list_teams(org_id: int | None = None) -> str:
    """List teams, optionally filtered by organization ID. Returns team IDs (UUIDs), names, and org info."""
    params = {"organization_id": org_id} if org_id is not None else None
    return api_get("/api/map/teams", params=params)


@mcp.tool()
def get_team(team_id: str) -> str:
    """Get team details by ID. team_id is a UUID string."""
    return api_get(f"/api/map/teams/{team_id}")


@mcp.tool()
def get_team_members(team_id: str) -> str:
    """List members of a team. team_id is a UUID string."""
    return api_get(f"/api/map/teams/{team_id}/members")


@mcp.tool()
def get_team_roles(team_id: str) -> str:
    """List roles defined for a team. team_id is a UUID string."""
    return api_get(f"/api/map/teams/{team_id}/roles")


@mcp.tool()
def get_team_work_areas(team_id: str) -> str:
    """List work areas for a team. team_id is a UUID string."""
    return api_get(f"/api/map/teams/{team_id}/work-areas")


@mcp.tool()
def get_team_task_entries(team_id: str) -> str:
    """List all task entries (task map data) for a team. Each entry represents a task performed by a team member. Key fields: label (task name), frequency (how often), enjoyment (how much they like it), automation_type (how much this task IS CURRENTLY automated — values: '0%', '25%', '50%', '75%', '100%', or 'Not assessed' — this is NOT automation potential, it is CURRENT automation level), app_ids (UUIDs of tools used — resolve via search_catalog_apps), work_area_id, member_id. team_id is a UUID string."""
    return api_get(f"/api/map/teams/{team_id}/task-entries")


@mcp.tool()
def get_team_summary(team_id: str) -> str:
    """Get team reporting summary with aggregated metrics. team_id is a UUID string."""
    return api_get(f"/api/map/reports/teams/{team_id}/summary")


@mcp.tool()
def get_org_map_summary(org_id: int) -> str:
    """Get organization-level map reporting summary."""
    return api_get(f"/api/map/reports/organizations/{org_id}/summary")


@mcp.tool()
def get_top_tasks(org_id: int | None = None) -> str:
    """Get top tasks ranked by TAP (Technology Absorption Potential) score — a composite metric indicating how much a task COULD BENEFIT from automation/AI, based on time spent, frequency, and current automation level. Higher TAP = higher opportunity. Optionally filtered by org."""
    params = {"org_ids": str(org_id)} if org_id is not None else None
    return api_get("/api/map/reports/top-tasks", params=params)


# ── Catalog (tool/app name resolution) ───────────────────────────────────────

@mcp.tool()
def search_catalog_apps(query: str) -> str:
    """Search for tools/apps by name. Use this to resolve app UUIDs from task entries to human-readable tool names."""
    return api_get("/api/map/catalog-apps/search", params={"q": query})


# ── Recos module ─────────────────────────────────────────────────────────────

@mcp.tool()
def check_recos_freshness() -> str:
    """Check data freshness for recommendations."""
    return api_get("/api/recos/freshness")


def main() -> None:
    """Entry point for the MCP server (stdio transport)."""
    mcp.run(transport="stdio")


if __name__ == "__main__":
    main()
