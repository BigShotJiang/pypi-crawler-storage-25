Benchmarks for the LCORE
