"""Unit tests for UserDataCollection model."""

import pytest

from models.config import UserDataCollection
from utils.checks import InvalidConfigurationError


def test_user_data_collection_feedback_enabled() -> None:
    """Test the UserDataCollection constructor for feedback."""
    # correct configuration
    cfg = UserDataCollection(
        feedback_enabled=False, feedback_storage=None
    )  # pyright: ignore[reportCallIssue]
    assert cfg is not None
    assert cfg.feedback_enabled is False
    assert cfg.feedback_storage is None


def test_user_data_collection_feedback_disabled() -> None:
    """Test the UserDataCollection constructor for feedback."""
    # incorrect configuration
    with pytest.raises(
        ValueError,
        match="feedback_storage is required when feedback is enabled",
    ):
        UserDataCollection(
            feedback_enabled=True, feedback_storage=None
        )  # pyright: ignore[reportCallIssue]


def test_user_data_collection_transcripts_enabled() -> None:
    """Test the UserDataCollection constructor for transcripts."""
    # correct configuration
    cfg = UserDataCollection(
        transcripts_enabled=False, transcripts_storage=None
    )  # pyright: ignore[reportCallIssue]
    assert cfg is not None
    assert cfg.transcripts_enabled is False
    assert cfg.transcripts_storage is None


def test_user_data_collection_transcripts_disabled() -> None:
    """Test the UserDataCollection constructor for transcripts.

    Verify the UserDataCollection constructor raises when transcripts are
    enabled but no storage is provided.

    Asserts that constructing with transcripts_enabled=True and
    transcripts_storage=None raises a ValueError with the message
    "transcripts_storage is required when transcripts is enabled".
    """
    # incorrect configuration
    with pytest.raises(
        ValueError,
        match="transcripts_storage is required when transcripts is enabled",
    ):
        UserDataCollection(
            transcripts_enabled=True, transcripts_storage=None
        )  # pyright: ignore[reportCallIssue]


def test_user_data_collection_wrong_directory_path() -> None:
    """Test the UserDataCollection constructor for wrong directory path.

    Verify UserDataCollection raises InvalidConfigurationError when provided
    storage paths point to non-writable directories.

    Ensures that enabling feedback with feedback_storage='/root' raises
    InvalidConfigurationError with message "Check directory to store feedback
    '/root' is not writable", and enabling transcripts with
    transcripts_storage='/root' raises InvalidConfigurationError with message
    "Check directory to store transcripts '/root' is not writable".
    """
    with pytest.raises(
        InvalidConfigurationError,
        match="Check directory to store feedback '/root' is not writable",
    ):
        _ = UserDataCollection(
            feedback_enabled=True, feedback_storage="/root"
        )  # pyright: ignore[reportCallIssue]

    with pytest.raises(
        InvalidConfigurationError,
        match="Check directory to store transcripts '/root' is not writable",
    ):
        _ = UserDataCollection(
            transcripts_enabled=True, transcripts_storage="/root"
        )  # pyright: ignore[reportCallIssue]
