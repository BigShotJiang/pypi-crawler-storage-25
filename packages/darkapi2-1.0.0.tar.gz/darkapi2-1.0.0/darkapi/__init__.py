"""
Dark API SDK — Compatible con SignalWire y Twilio REST API.

CREDENCIALES (las obtienes del dashboard en https://apivoice.co):
  space_url  = "apivoice.co"
  project_id = "tu-project-id"
  api_token  = "tu-api-token"

USO:

  ANTES (SignalWire original):
    from signalwire.rest import Client
    client = Client(project_id, api_token, signalwire_space_url=space_url)

  DESPUÉS (Dark API — solo cambia el import):
    from darkapi import Client
    client = Client(project_id, api_token, signalwire_space_url=space_url)

  El resto del código NO cambia.
"""
from darkapi.rest import Client

__all__ = ["Client"]
