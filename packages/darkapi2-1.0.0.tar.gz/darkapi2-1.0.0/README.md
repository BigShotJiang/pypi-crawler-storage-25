# Dark API SDK

Python SDK for [Dark API](https://apivoice.co) — a self-hosted CPaaS voice platform fully compatible with SignalWire and Twilio REST API.

## Installation

```bash
pip install darkapi
```

## Quick Start

```python
from darkapi import Client

client = Client(
    project_id="your-project-id",
    api_token="your-api-token",
    signalwire_space_url="apivoice.co"
)

call = client.calls.create(
    to="+573001234567",
    from_="+18005550100",
    url="https://your-backend.com/xml",
    method="POST",
    timeout=28,
    record=True,
    status_callback="https://your-backend.com/status",
    status_callback_event=["initiated", "ringing", "completed"],
)

print(f"Call SID: {call.sid}")
print(f"Status:   {call.status}")
```

## Migration from SignalWire

Only change the import — everything else stays the same:

```python
# Before
from signalwire.rest import Client

# After
from darkapi import Client
```

## Migration from Twilio

```python
# Before
from twilio.rest import Client

# After
from darkapi import Client
```

## Features

- Full SignalWire / Twilio REST API compatibility
- Outbound call creation
- Call status, fetch and update
- Answering Machine Detection (AMD) — sync and async
- Call recording with callbacks
- Status callbacks (initiated, ringing, answered, completed)
- LAML/XML verb support (Say, Play, Gather, Record, Hangup, Redirect…)

## Documentation

Full API reference: [https://apivoice.co/documentation](https://apivoice.co/documentation)

## License

MIT
