"""Utility functions."""
