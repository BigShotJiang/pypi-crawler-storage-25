import os
import sys
sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), "..")))

import femmreader



def test_FEM():

    femmfile = os.path.join(os.path.dirname(__file__), "..", "examples", "EI-core.FEM")
    data = femmreader.read(femmfile)
    assert data['Depth'] == 20

