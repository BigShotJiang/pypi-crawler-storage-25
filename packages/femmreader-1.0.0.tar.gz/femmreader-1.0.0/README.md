# femmreader

Femmreader is a parser to read files from the Finite Element Software [femm](http://www.femm.info).

Following files are supported.
Model files:
- *.fem (Magnetics problem)
- *.fee (Electrostatics problem)
- *.fec (Current flow problem)
- *.feh (Heat flow problem)

Result files:
- *.ans (Result file of magnetics problem)
- *.anc (Result file of current flow problem)
- *.res (Result file of electrostatics problem)
- *.anh (Result file of heat flow problem)


## Installation
femmreader is a pure python package with no dependencies. Install via
```
pip install femmreader
```

## Usage
Let's have a look on a very basic [example](https://gitlab.com/martinbaun/femmreader/-/blob/c4c0b2afe7ece7ffa4444c58263745f66beacf60/examples/EI-core.FEM).

<img src="https://gitlab.com/martinbaun/femmreader/-/raw/main/examples/EI-core_geometry.png" width="600">

Read the file with
```python 
imoprt femmreader
data = femmreader.read("EI-core.FEM")

print(data.keys())
>>> dict_keys(['Format', 'Frequency', 'Precision', 'MinAngle', 'DoSmartMesh', 'Depth', 'LengthUnits', 'ProblemType', 'Coordinates', 'ACSolver', 'PrevType', 'PrevSoln', 'Comment', 'BdryProps', 'BlockProps', 'CircuitProps', 'NumPoints', 'NumSegments', 'NumArcSegments', 'NumHoles', 'NumBlockLabels'])

print(data['Depth'])
>>> 20
```

The same for [result files](https://gitlab.com/martinbaun/femmreader/-/blob/c4c0b2afe7ece7ffa4444c58263745f66beacf60/examples/EI-core.ans):

<img src="https://gitlab.com/martinbaun/femmreader/-/raw/main/examples/EI-core_solution.png" width="600">

```python 
data = femmreader.read("EI-core.ans")

print(data.keys())
>>> dict_keys(['Format', 'Frequency', 'Precision', 'MinAngle', 'DoSmartMesh', 'Depth', 'LengthUnits', 'ProblemType', 'Coordinates', 'ACSolver', 'PrevType', 'PrevSoln', 'Comment', 'BdryProps', 'BlockProps', 'CircuitProps', 'NumPoints', 'NumSegments', 'NumArcSegments', 'NumHoles', 'NumBlockLabels', 'Solution'])

print(data['Solution'].keys())
>>> dict_keys(['xpos', 'ypos', 'sol_real', 'sol_imag', 'solution', 'elements', 'block_labels'])

```