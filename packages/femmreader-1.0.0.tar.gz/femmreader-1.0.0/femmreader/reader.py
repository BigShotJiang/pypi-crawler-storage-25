# -*- coding: utf-8 -*-


def read(femmfile):
    """
    Reads a FEMM file and returns a structured dictionary containing the data.
    
    Parameters:
    femmfile (str): Path to the femm file to be read. Following files are supported:
    - *.fem (Magnetics problem)
    - *.fee (Electrostatics problem)
    - *.fec (Current flow problem)
    - *.feh (Heat flow problem)

    - *.ans (Result file of magnetics problem)
    - *.anc (Result file of current flow problem)
    - *.res (Result file of electrostatics problem)
    - *.anh (Result file of heat flow problem)

    Returns:
    dict: A dictionary containing the structured data from the .fem file.

    Example usage:
    data = reader('path/to/your/file.fem')
    """
    with open(femmfile, 'r') as f:
        content = f.readlines()

    def dtype_value(val):
        """Helper function to convert string values to appropriate data types."""
        if '"' in val or "'" in val:
            return val.strip('"\'')
        try:
            return int(val)
        except ValueError:
            try:
                return float(val)
            except ValueError:
                return val

    data = {}
    current_section = None
    i = 0
    while i < len(content):
        line = content[i].strip()

        # Skip empty lines and comments
        if not line or line.startswith(';'):
            i += 1
            continue
        
        # Check for section headers
        if line.startswith('['):
            idx = line.find(']')
            current_section = line[1:idx]

        if current_section is not None:
            if current_section == 'BdryProps':
                if line.startswith('<BeginBdry>'):
                    bdry = {}
                    while i < len(content):
                        line = content[i].strip()
                        i += 1
                        if line.startswith('<EndBdry>'):
                            data.setdefault('BdryProps', []).append(bdry)
                            i -= 1  # Step back to reprocess the line in the main loop
                            break
                        if line.startswith('<') and '>' in line and '=' in line:
                            key, sep, val = line.partition('=')
                            if sep:  # '=' found
                                key = key.strip('<> ')
                                val = val.strip()
                                bdry[key] = dtype_value(val)
            
            elif current_section == 'BlockProps':
                if line.startswith('<BeginBlock>'):                
                    block = {}
                    while i < len(content):
                        line = content[i].strip()
                        i += 1
                        if line.startswith('<EndBlock>'):
                            data.setdefault('BlockProps', []).append(block)
                            i -= 1  # Step back to reprocess the line in the main loop
                            break
                        if line.startswith('<') and '>' in line and '=' in line:
                            key, sep, val = line.partition('=')
                            if sep:  # '=' found
                                key = key.strip('<> ')
                                val = val.strip()
                                if 'BHPoints' in key:
                                    block['BHPoints'] = {'B': [], 'H': []}
                                    for k in range(int(val)):
                                        line = content[i].strip()
                                        i += 1
                                        if not line or line.startswith(';'):
                                            continue
                                        value = line.split()
                                        block['BHPoints']['B'].append(float(value[0]))
                                        block['BHPoints']['H'].append(float(value[1]))
                                
                                else:
                                    block[key] = dtype_value(val)
            
            elif current_section == 'PointProps':
                if line.startswith('<BeginPoint>'):
                    point = {}
                    while i < len(content):
                        line = content[i].strip()
                        i += 1
                        if line.startswith('<EndPoint>'):
                            data.setdefault('PointProps', []).append(point)
                            i -= 1  # Step back to reprocess the line in the main loop
                            break
                        if line.startswith('<') and '>' in line and '=' in line:
                            key, sep, val = line.partition('=')
                            if sep:  # '=' found
                                key = key.strip('<> ')
                                val = val.strip()
                                point[key] = dtype_value(val)
            
            elif current_section == 'CircuitProps':
                if line.startswith('<BeginCircuit>'):
                    circuit = {}
                    while i < len(content):
                        line = content[i].strip()
                        i += 1
                        if line.startswith('<EndCircuit>'):
                            data.setdefault('CircuitProps', []).append(circuit)
                            i -= 1  # Step back to reprocess the line in the main loop
                            break
                        if line.startswith('<') and '>' in line and '=' in line:
                            key, sep, val = line.partition('=')
                            if sep:  # '=' found
                                key = key.strip('<> ')
                                val = val.strip()
                                circuit[key] = dtype_value(val)
            
            elif current_section == 'ConductorProps':
                if line.startswith('<BeginConductor>'):
                    conductor = {}
                    while i < len(content):
                        line = content[i].strip()
                        i += 1
                        if line.startswith('<EndConductor>'):
                            data.setdefault('ConductorProps', []).append(conductor)
                            i -= 1  # Step back to reprocess the line in the main loop
                            break
                        if line.startswith('<') and '>' in line and '=' in line:
                            key, sep, val = line.partition('=')
                            if sep:  # '=' found
                                key = key.strip('<> ')
                                val = val.strip()
                                conductor[key] = dtype_value(val)

            elif current_section == 'NumPoints':
                data[current_section] = []
                i += 1
                while i < len(content):
                    line = content[i].strip()
                    # i += 1
                    if not line or line.startswith(';'):
                        continue
                    if line.startswith('['):
                        i -= 1  # Step back to reprocess the section header in the main loop
                        
                        break
                    value = line.split()
                    data[current_section].append({})
                    data[current_section][-1]['x'] = float(value[0])
                    data[current_section][-1]['y'] = float(value[1])
                    data[current_section][-1]['node_prop'] = int(value[2])
                    data[current_section][-1]['group'] = int(value[3])
                    i += 1
                
            elif current_section == 'NumSegments':
                data[current_section] = []
                i += 1
                while i < len(content):
                    line = content[i].strip()
                    # i += 1
                    if not line or line.startswith(';'):
                        continue
                    if line.startswith('['):
                        i -= 1  # Step back to reprocess the section header in the main loop
                        
                        break
                    value = line.split()
                    data[current_section].append({})
                    data[current_section][-1]['p1'] = int(value[0])
                    data[current_section][-1]['p2'] = int(value[1])
                    data[current_section][-1]['mesh_size'] = float(value[2])
                    data[current_section][-1]['bdry_prop'] = int(value[3])
                    data[current_section][-1]['hide_in_post'] = int(value[4])
                    data[current_section][-1]['group'] = int(value[5])
                    i += 1
            
            elif current_section == 'NumArcSegments':
                data[current_section] = []
                i += 1
                while i < len(content):
                    line = content[i].strip()
                    # i += 1
                    if not line or line.startswith(';'):
                        continue
                    if line.startswith('['):
                        i -= 1  # Step back to reprocess the section header in the main loop
                        break
                    value = line.split()
                    data[current_section].append({})
                    data[current_section][-1]['p1'] = int(value[0])
                    data[current_section][-1]['p2'] = int(value[1])
                    data[current_section][-1]['angle'] = float(value[2])
                    data[current_section][-1]['mesh_angle'] = float(value[3])
                    data[current_section][-1]['bdry_prop'] = int(value[4])
                    data[current_section][-1]['hide_in_post'] = int(value[5])
                    data[current_section][-1]['group'] = int(value[6])
                    i += 1
                
            elif current_section == 'NumHoles':
                data[current_section] = []
                i += 1
                while i < len(content):
                    line = content[i].strip()
                    # i += 1
                    if not line or line.startswith(';'):
                        continue
                    if line.startswith('['):
                        i -= 1  # Step back to reprocess the section header in the main loop
                        break
                    value = line.split()
                    data[current_section].append({})
                    data[current_section][-1]['x'] = float(value[0])
                    data[current_section][-1]['y'] = float(value[1])
                    data[current_section][-1]['group'] = int(value[2])
                    i += 1
            
            elif current_section == 'NumBlockLabels':
                data[current_section] = []
                i += 1
                while i < len(content):
                    line = content[i].strip()
                    # i += 1
                    if not line or line.startswith(';'):
                        continue
                    if line.startswith('['):
                        i -= 1  # Step back to reprocess the section header in the main loop
                        break
                    value = line.split()
                    data[current_section].append({})
                    data[current_section][-1]['x'] = float(value[0])
                    data[current_section][-1]['y'] = float(value[1])
                    data[current_section][-1]['region'] = int(value[2])
                    data[current_section][-1]['mesh_size'] = float(value[3])
                    data[current_section][-1]['circuit'] = int(value[4])
                    data[current_section][-1]['mag_direction'] = float(value[5])
                    if len(value) > 6:
                        data[current_section][-1]['group'] = int(value[6])
                    if len(value) > 7:
                        data[current_section][-1]['num_turns'] = int(value[7])
                        data[current_section][-1]['external_region'] = int(value[8])
                    i += 1
            
            elif current_section == 'Solution':
                
                data[current_section] = {}
                data[current_section]['xpos'] = []
                data[current_section]['ypos'] = []
                data[current_section]['sol_real'] = []
                data[current_section]['sol_imag'] = []
                value = content[i+1].strip()
                i += 1

                for k in range(int(value)):
                    i += 1
                    value = content[i].strip().split()
                    # block.append([dtype_value(v) for v in value])
                    data[current_section]['xpos'].append(float(value[0]))
                    data[current_section]['ypos'].append(float(value[1]))
                    data[current_section]['sol_real'].append(float(value[2]))
                    data[current_section]['sol_imag'].append(float(value[3]))
                    
                data[current_section]['solution'] = block

                i += 1
                value = content[i].strip()
                block = []
                for k in range(int(value)):
                    i += 1
                    value = content[i].strip().split()
                    block.append([dtype_value(v) for v in value ])
                    
                    
                data[current_section]['elements'] = [b[:3] for b in block]
                data[current_section]['block_labels'] = [b[3] for b in block]
                # skipt the last lines, content is unclear here
                i = len(content)  # End of file

            else:
                value = line.split('=')[1].strip()
                data[current_section] = dtype_value(value)

            i += 1
            continue
    return data




