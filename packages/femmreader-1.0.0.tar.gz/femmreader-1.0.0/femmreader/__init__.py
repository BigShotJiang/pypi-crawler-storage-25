# -*- coding: utf-8 -*-

__title__ = "femmreader"    
__version__ = "1.0.0"
__author__ = "Martin Baun"
__license__ = "MIT License"
__copyright__ = "Copyright 2026 Martin Baun"

from .reader import read


