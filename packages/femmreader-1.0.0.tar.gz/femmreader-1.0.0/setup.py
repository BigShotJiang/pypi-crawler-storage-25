import setuptools
import femmreader

with open("README.md", "r") as fh:
    long_description = fh.read()

setuptools.setup(
    name="femmreader",
    version=femmreader.__version__,
    author=femmreader.__author__,
    author_email="mar.baun@googlemail.com",
    description="FEMM file reader for Python",
    long_description=long_description,
    long_description_content_type="text/markdown",
    url="https://gitlab.com/martinbaun/femmreader",
    packages=setuptools.find_packages(),

    platforms="any",
    install_requires=[],
    classifiers=[
        "Programming Language :: Python :: 3",
        "License :: OSI Approved :: MIT License",
        "Operating System :: OS Independent",
    ],

)
