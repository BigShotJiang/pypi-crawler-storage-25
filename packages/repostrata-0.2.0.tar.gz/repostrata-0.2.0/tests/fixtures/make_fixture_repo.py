import os
import subprocess
from pathlib import Path


def run(repo: Path, *args: str) -> str:
    env = os.environ.copy()
    env["GIT_AUTHOR_DATE"] = "2026-05-13T12:00:00+00:00"
    env["GIT_COMMITTER_DATE"] = "2026-05-13T12:00:00+00:00"
    result = subprocess.run(
        ["git", *args],
        cwd=repo,
        check=True,
        text=True,
        stdout=subprocess.PIPE,
        stderr=subprocess.PIPE,
        env=env,
    )
    return result.stdout.strip()


def make_fixture_repo(repo: Path) -> list[str]:
    repo.mkdir()
    run(repo, "init")
    run(repo, "config", "user.name", "Fixture Dev")
    run(repo, "config", "user.email", "fixture@example.com")

    (repo / "app.py").write_text(
        "def greet(name):\n"
        "    return f'hello {name}'\n",
        encoding="utf-8",
    )
    run(repo, "add", "app.py")
    run(repo, "commit", "-m", "add python greeting")
    first = run(repo, "rev-parse", "HEAD")

    (repo / "app.py").write_text(
        "def greet(name):\n"
        "    return f'hello {name}'\n"
        "\n"
        "class Greeter:\n"
        "    def greet(self, name):\n"
        "        return greet(name)\n",
        encoding="utf-8",
    )
    (repo / "ui.ts").write_text(
        "export function render(name: string): string {\n"
        "  return `hello ${name}`;\n"
        "}\n",
        encoding="utf-8",
    )
    run(repo, "add", "app.py", "ui.ts")
    run(repo, "commit", "-m", "add greeter and ui")
    second = run(repo, "rev-parse", "HEAD")

    return [first, second]
