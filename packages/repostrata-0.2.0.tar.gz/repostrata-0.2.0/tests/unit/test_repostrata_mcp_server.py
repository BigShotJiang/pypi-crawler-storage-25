import io
import sys
import urllib.error
from pathlib import Path


REPO_ROOT = Path(__file__).resolve().parents[2]
PLUGIN_SCRIPT = REPO_ROOT / "plugins/repostrata/scripts/repostrata_mcp_server.py"
sys.path.insert(0, str(PLUGIN_SCRIPT.parent.resolve()))

import repostrata_mcp_server as bridge  # noqa: E402


def test_tool_definitions_include_expected_tools():
    names = {tool["name"] for tool in bridge.tool_definitions()}

    assert names == {
        "repostrata_status",
        "repostrata_search_symbols",
        "repostrata_get_symbol",
        "repostrata_get_symbol_neighborhood",
        "repostrata_get_symbol_history",
    }


def test_endpoint_mapping_for_search_symbols(monkeypatch):
    calls = []

    def fake_post(base_url, path, payload):
        calls.append((base_url, path, payload))
        return {
            "summary": "ok",
            "items": [],
            "evidence": [],
            "truncated": False,
            "next_queries": [],
        }

    monkeypatch.setattr(bridge, "post_json", fake_post)

    result = bridge.call_tool(
        "repostrata_search_symbols",
        {"query": "Greeter", "limit": 5},
        base_url="http://127.0.0.1:8765",
    )

    assert calls == [
        (
            "http://127.0.0.1:8765",
            "/api/agent/symbols/search",
            {"query": "Greeter", "limit": 5},
        )
    ]
    assert result["content"][0]["type"] == "text"
    assert '"summary": "ok"' in result["content"][0]["text"]


def test_status_uses_get(monkeypatch):
    calls = []

    def fake_get(base_url, path):
        calls.append((base_url, path))
        return {
            "summary": "ok",
            "items": [],
            "evidence": [],
            "truncated": False,
            "next_queries": [],
        }

    monkeypatch.setattr(bridge, "get_json", fake_get)

    bridge.call_tool("repostrata_status", {}, base_url="http://127.0.0.1:8765")

    assert calls == [("http://127.0.0.1:8765", "/api/agent/status")]


def test_server_unavailable_error_is_actionable(monkeypatch):
    def failing_get(base_url, path):
        raise OSError("connection refused")

    monkeypatch.setattr(bridge, "get_json", failing_get)

    result = bridge.call_tool("repostrata_status", {}, base_url="http://127.0.0.1:8765")

    assert result["isError"] is True
    assert (
        "repostrata dashboard --repo /path/to/repo --port 8765"
        in result["content"][0]["text"]
    )


def test_http_error_reports_status_without_startup_instruction(monkeypatch):
    def failing_post(base_url, path, payload):
        raise bridge.HttpStatusError(422, '{"detail":"query is required"}')

    monkeypatch.setattr(bridge, "post_json", failing_post)

    result = bridge.call_tool(
        "repostrata_search_symbols",
        {"query": ""},
        base_url="http://127.0.0.1:8765",
    )

    assert result["isError"] is True
    assert "RepoStrata API returned HTTP 422" in result["content"][0]["text"]
    assert "query is required" in result["content"][0]["text"]
    assert "repostrata dashboard --repo /path/to/repo --port 8765" not in result[
        "content"
    ][0]["text"]


def test_lower_helper_http_error_reports_status_without_startup_instruction(monkeypatch):
    def failing_urlopen(request, timeout):
        raise urllib.error.HTTPError(
            request.full_url,
            400,
            "Bad Request",
            {},
            io.BytesIO(b'{"detail":"bad payload"}'),
        )

    monkeypatch.setattr(bridge.urllib.request, "urlopen", failing_urlopen)

    result = bridge.call_tool(
        "repostrata_search_symbols",
        {"query": ""},
        base_url="http://127.0.0.1:8765",
    )

    assert result["isError"] is True
    assert "RepoStrata API returned HTTP 400" in result["content"][0]["text"]
    assert "bad payload" in result["content"][0]["text"]
    assert "Start it with" not in result["content"][0]["text"]


def test_handle_request_lists_tools():
    response = bridge.handle_request({"jsonrpc": "2.0", "id": 1, "method": "tools/list"})

    assert response is not None
    assert response["jsonrpc"] == "2.0"
    assert response["id"] == 1
    assert {tool["name"] for tool in response["result"]["tools"]} == {
        "repostrata_status",
        "repostrata_search_symbols",
        "repostrata_get_symbol",
        "repostrata_get_symbol_neighborhood",
        "repostrata_get_symbol_history",
    }


def test_handle_request_rejects_malformed_tools_call_params():
    response = bridge.handle_request(
        {"jsonrpc": "2.0", "id": 2, "method": "tools/call", "params": []}
    )

    assert response is not None
    assert response["error"]["code"] == -32602


def test_handle_request_rejects_unknown_tool():
    response = bridge.handle_request(
        {
            "jsonrpc": "2.0",
            "id": 3,
            "method": "tools/call",
            "params": {"name": "unknown", "arguments": {}},
        }
    )

    assert response is not None
    assert response["error"]["code"] == -32602
    assert "Unknown tool" in response["error"]["message"]


class _FakeStdin:
    def __init__(self, data):
        self.buffer = io.BytesIO(data)


def test_read_message_returns_error_for_malformed_header(monkeypatch):
    monkeypatch.setattr(sys, "stdin", _FakeStdin(b"Content-Length 10\r\n\r\n{}"))

    message = bridge.read_message()

    assert message == {
        "jsonrpc": "2.0",
        "id": None,
        "error": {"code": -32600, "message": "Invalid request: malformed header"},
    }


def test_read_message_returns_parse_error_for_invalid_json(monkeypatch):
    monkeypatch.setattr(sys, "stdin", _FakeStdin(b"Content-Length: 1\r\n\r\n{"))

    message = bridge.read_message()

    assert message == {
        "jsonrpc": "2.0",
        "id": None,
        "error": {"code": -32700, "message": "Parse error: invalid JSON"},
    }
