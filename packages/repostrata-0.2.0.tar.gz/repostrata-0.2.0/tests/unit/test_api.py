import pytest
from fastapi.testclient import TestClient

from repostrata import cli
from repostrata.api.app import create_app
from repostrata.config import init_project
from repostrata.db.repository import GraphRepository
from repostrata.index.coordinator import index_repository
from tests.fixtures.make_fixture_repo import make_fixture_repo


@pytest.fixture
def indexed_repo(tmp_path):
    repo = tmp_path / "fixture_repo"
    make_fixture_repo(repo)
    init_project(repo)
    index_repository(repo)
    return repo


def test_timeline_endpoint_returns_commits(indexed_repo):
    client = TestClient(create_app(indexed_repo))

    response = client.get("/api/timeline")

    assert response.status_code == 200
    body = response.json()
    assert len(body["commits"]) == 2
    assert all("hash" in commit for commit in body["commits"])
    assert [commit["message"] for commit in body["commits"]] == [
        "add python greeting",
        "add greeter and ui",
    ]


def test_search_symbols_endpoint_returns_matches(indexed_repo):
    client = TestClient(create_app(indexed_repo))

    response = client.get("/api/symbols/search", params={"q": "Greeter"})

    assert response.status_code == 200
    body = response.json()
    qualified_names = {symbol["qualified_name"] for symbol in body["symbols"]}
    assert "Greeter" in qualified_names


def test_search_symbols_rejects_empty_query(indexed_repo):
    client = TestClient(create_app(indexed_repo))

    response = client.get("/api/symbols/search", params={"q": "   "})

    assert response.status_code == 400
    assert response.json()["detail"] == "Search query is required"


def test_search_symbols_treats_like_wildcards_literally(indexed_repo):
    client = TestClient(create_app(indexed_repo))

    response = client.get("/api/symbols/search", params={"q": "%"})

    assert response.status_code == 200
    assert response.json()["symbols"] == []


def test_snapshot_endpoint_returns_nodes_and_edges(indexed_repo):
    client = TestClient(create_app(indexed_repo))
    timeline = client.get("/api/timeline").json()
    commit_hash = timeline["commits"][-1]["hash"]

    response = client.get(f"/api/snapshots/{commit_hash}")

    assert response.status_code == 200
    body = response.json()
    assert "nodes" in body
    assert "edges" in body
    assert len(body["nodes"]) > 0


def test_snapshot_endpoint_returns_404_for_unknown_commit(indexed_repo):
    client = TestClient(create_app(indexed_repo))

    response = client.get("/api/snapshots/not-a-commit")

    assert response.status_code == 404
    assert response.json()["detail"] == "Snapshot not found"


def test_api_does_not_create_graph_database_for_unindexed_repo(tmp_path):
    repo = tmp_path / "repo"
    repo.mkdir()
    init_project(repo)
    graph_db = repo / ".repostrata" / "graph.db"
    client = TestClient(create_app(repo))

    response = client.get("/api/timeline")

    assert response.status_code == 503
    assert response.json()["detail"] == "RepoStrata graph database has not been indexed"
    assert not graph_db.exists()


def test_agent_status_returns_indexed_tool_result(indexed_repo):
    client = TestClient(create_app(indexed_repo))

    response = client.get("/api/agent/status")

    assert response.status_code == 200
    body = response.json()
    assert body["items"][0]["indexed"] is True
    assert body["truncated"] is False
    assert body["summary"]


def test_agent_status_returns_unindexed_tool_result(tmp_path):
    repo = tmp_path / "repo"
    repo.mkdir()
    init_project(repo)
    client = TestClient(create_app(repo))

    response = client.get("/api/agent/status")

    assert response.status_code == 200
    body = response.json()
    assert body["items"][0]["indexed"] is False
    assert body["truncated"] is False
    assert body["summary"]


def test_agent_status_returns_unindexed_tool_result_without_manifest(tmp_path):
    repo = tmp_path / "repo"
    repo.mkdir()
    graph_db = repo / ".repostrata" / "graph.db"
    client = TestClient(create_app(repo))

    response = client.get("/api/agent/status")

    assert response.status_code == 200
    body = response.json()
    assert body["items"] == [
        {
            "repo_root": str(repo.resolve()),
            "indexed": False,
            "indexed_head": None,
            "indexed_commits": 0,
            "commit_count": 0,
            "symbol_count": 0,
            "relation_count": 0,
            "event_count": 0,
        }
    ]
    assert body["truncated"] is False
    assert not graph_db.exists()


def test_agent_search_symbols_returns_matches(indexed_repo):
    client = TestClient(create_app(indexed_repo))

    response = client.post(
        "/api/agent/symbols/search",
        json={"query": "Greeter", "kind": "class", "limit": 5},
    )

    assert response.status_code == 200
    body = response.json()
    assert [item["qualified_name"] for item in body["items"]] == ["Greeter"]


def test_agent_search_symbols_allows_large_limit_and_service_caps(
    indexed_repo,
    monkeypatch,
):
    observed_limits = []

    def fake_search_symbols_filtered(self, query, **kwargs):
        observed_limits.append(kwargs["limit"])
        return [
            {
                "id": f"symbol-{index}",
                "kind": "function",
                "language": "python",
                "file_path": "app.py",
                "qualified_name": f"Greeter.match_{index}",
                "name": f"match_{index}",
                "start_line": 1,
                "end_line": 1,
            }
            for index in range(101)
        ]

    monkeypatch.setattr(
        GraphRepository,
        "search_symbols_filtered",
        fake_search_symbols_filtered,
    )
    client = TestClient(create_app(indexed_repo))

    response = client.post(
        "/api/agent/symbols/search",
        json={"query": "Greeter", "limit": 500},
    )

    assert response.status_code == 200
    body = response.json()
    assert observed_limits == [101]
    assert len(body["items"]) == 100
    assert body["truncated"] is True


def test_agent_get_symbol_returns_present_at_commit(indexed_repo):
    client = TestClient(create_app(indexed_repo))
    search = client.post(
        "/api/agent/symbols/search",
        json={"query": "Greeter", "kind": "class", "limit": 5},
    ).json()
    symbol_id = search["items"][0]["symbol_id"]

    response = client.post(
        "/api/agent/symbols/get",
        json={"symbol_id": symbol_id},
    )

    assert response.status_code == 200
    body = response.json()
    assert body["items"][0]["symbol_id"] == symbol_id
    assert body["items"][0]["present_at_commit"] is True


def test_agent_symbol_neighborhood_returns_contains_edges(indexed_repo):
    client = TestClient(create_app(indexed_repo))
    search = client.post(
        "/api/agent/symbols/search",
        json={"query": "Greeter", "kind": "class", "limit": 5},
    ).json()
    symbol_id = search["items"][0]["symbol_id"]

    response = client.post(
        "/api/agent/symbols/neighborhood",
        json={"symbol_id": symbol_id},
    )

    assert response.status_code == 200
    body = response.json()
    assert any(edge["kind"] == "contains" for edge in body["items"][0]["edges"])


def test_agent_symbol_neighborhood_allows_large_limit(indexed_repo):
    client = TestClient(create_app(indexed_repo))
    search = client.post(
        "/api/agent/symbols/search",
        json={"query": "Greeter", "kind": "class", "limit": 5},
    ).json()
    symbol_id = search["items"][0]["symbol_id"]

    response = client.post(
        "/api/agent/symbols/neighborhood",
        json={"symbol_id": symbol_id, "limit": 500},
    )

    assert response.status_code == 200
    assert response.json()["items"][0]["center_symbol_id"] == symbol_id


def test_agent_symbol_history_returns_symbol_added(indexed_repo):
    client = TestClient(create_app(indexed_repo))
    search = client.post(
        "/api/agent/symbols/search",
        json={"query": "Greeter", "kind": "class", "limit": 5},
    ).json()
    symbol_id = search["items"][0]["symbol_id"]

    response = client.post(
        "/api/agent/symbols/history",
        json={"symbol_id": symbol_id},
    )

    assert response.status_code == 200
    body = response.json()
    assert any(item["event_type"] == "symbol_added" for item in body["items"])


def test_agent_symbol_history_allows_large_limit(indexed_repo):
    client = TestClient(create_app(indexed_repo))
    search = client.post(
        "/api/agent/symbols/search",
        json={"query": "Greeter", "kind": "class", "limit": 5},
    ).json()
    symbol_id = search["items"][0]["symbol_id"]

    response = client.post(
        "/api/agent/symbols/history",
        json={"symbol_id": symbol_id, "limit": 500},
    )

    assert response.status_code == 200
    assert any(item["event_type"] == "symbol_added" for item in response.json()["items"])


def test_agent_search_symbols_rejects_blank_query(indexed_repo):
    client = TestClient(create_app(indexed_repo))

    response = client.post(
        "/api/agent/symbols/search",
        json={"query": "   "},
    )

    assert response.status_code == 400
    assert response.json()["detail"] == "query is required"


def test_agent_non_status_query_rejects_unindexed_repo_without_creating_database(tmp_path):
    repo = tmp_path / "repo"
    repo.mkdir()
    init_project(repo)
    graph_db = repo / ".repostrata" / "graph.db"
    client = TestClient(create_app(repo))

    response = client.post(
        "/api/agent/symbols/search",
        json={"query": "Greeter"},
    )

    assert response.status_code == 503
    assert response.json()["detail"] == "RepoStrata graph database has not been indexed"
    assert not graph_db.exists()


def test_dashboard_index_is_served_when_static_dir_exists(indexed_repo, tmp_path):
    static_dir = tmp_path / "dist"
    static_dir.mkdir()
    (static_dir / "index.html").write_text("<main>RepoStrata</main>", encoding="utf-8")
    client = TestClient(create_app(indexed_repo, static_dir=static_dir))

    response = client.get("/")

    assert response.status_code == 200
    assert "RepoStrata" in response.text


def test_dashboard_root_returns_404_when_no_static_dir(indexed_repo):
    client = TestClient(create_app(indexed_repo, static_dir=None))

    response = client.get("/")

    assert response.status_code == 404


def test_dashboard_static_dir_prefers_packaged_assets(monkeypatch, tmp_path):
    packaged = tmp_path / "package" / "web_dist"
    source = tmp_path / "source" / "web" / "dist"
    packaged.mkdir(parents=True)
    source.mkdir(parents=True)
    (packaged / "index.html").write_text("packaged", encoding="utf-8")
    (source / "index.html").write_text("source", encoding="utf-8")

    class FakeTraversable:
        def __init__(self, path):
            self.path = path

        def joinpath(self, name):
            return FakeTraversable(self.path / name)

        def is_file(self):
            return self.path.is_file()

        def __str__(self):
            return str(self.path)

    monkeypatch.setattr(cli.resources, "files", lambda package: FakeTraversable(tmp_path / "package"))
    monkeypatch.setattr(cli, "__file__", str(tmp_path / "source" / "src" / "repostrata" / "cli.py"))

    assert cli._dashboard_static_dir() == packaged


def test_dashboard_static_dir_falls_back_to_source_assets(monkeypatch, tmp_path):
    source = tmp_path / "source" / "web" / "dist"
    source.mkdir(parents=True)
    (source / "index.html").write_text("source", encoding="utf-8")

    class MissingTraversable:
        def joinpath(self, name):
            return self

        def is_file(self):
            return False

    monkeypatch.setattr(cli.resources, "files", lambda package: MissingTraversable())
    monkeypatch.setattr(cli, "__file__", str(tmp_path / "source" / "src" / "repostrata" / "cli.py"))

    assert cli._dashboard_static_dir() == source
