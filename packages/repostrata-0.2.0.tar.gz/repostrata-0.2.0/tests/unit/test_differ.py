import json

from repostrata.index.differ import diff_facts
from repostrata.models import RelationFact, SymbolFact


def symbol(symbol_id: str, source_hash: str) -> SymbolFact:
    return SymbolFact(
        id=symbol_id,
        kind="function",
        language="python",
        file_path="app.py",
        qualified_name=symbol_id,
        name=symbol_id,
        start_line=1,
        end_line=1,
        source_hash=source_hash,
    )


def relation(relation_id: str, confidence: float = 1.0) -> RelationFact:
    return RelationFact(
        id=relation_id,
        kind="calls",
        source_id="a",
        target_id="b",
        file_path="app.py",
        confidence=confidence,
        provenance="test",
    )


def test_diff_generates_added_removed_and_changed_symbol_events():
    events = diff_facts(
        commit_hash="commit-1",
        previous_symbols=[symbol("old", "a"), symbol("changed", "a")],
        current_symbols=[symbol("new", "b"), symbol("changed", "b")],
        previous_relations=[],
        current_relations=[],
    )

    assert {event.event_type for event in events} == {
        "symbol_added",
        "symbol_changed",
        "symbol_removed",
    }

    changed_event = next(
        event for event in events if event.event_type == "symbol_changed"
    )
    payload = json.loads(changed_event.payload_json)
    assert payload["current"]["source_hash"] == "b"


def test_diff_generates_edge_events():
    added_relation = relation("rel-1")

    events = diff_facts(
        commit_hash="commit-1",
        previous_symbols=[],
        current_symbols=[],
        previous_relations=[],
        current_relations=[added_relation],
    )

    assert [event.event_type for event in events] == ["edge_added"]


def test_diff_generates_edge_removed_event():
    removed_relation = relation("rel-1")

    events = diff_facts(
        commit_hash="commit-1",
        previous_symbols=[],
        current_symbols=[],
        previous_relations=[removed_relation],
        current_relations=[],
    )

    assert [event.event_type for event in events] == ["edge_removed"]
    payload = json.loads(events[0].payload_json)
    assert payload["id"] == "rel-1"


def test_diff_generates_changed_edge_event_for_relation_metadata_changes():
    events = diff_facts(
        commit_hash="commit-1",
        previous_symbols=[],
        current_symbols=[],
        previous_relations=[relation("rel-1", confidence=0.6)],
        current_relations=[relation("rel-1", confidence=0.9)],
    )

    assert [event.event_type for event in events] == ["edge_changed"]
    payload = json.loads(events[0].payload_json)
    assert payload["current"]["confidence"] == 0.9


def test_diff_event_order_is_deterministic_by_category_and_sorted_subject_id():
    events = diff_facts(
        commit_hash="commit-1",
        previous_symbols=[
            symbol("removed-b", "a"),
            symbol("changed-b", "a"),
            symbol("removed-a", "a"),
            symbol("changed-a", "a"),
        ],
        current_symbols=[
            symbol("added-b", "b"),
            symbol("changed-b", "b"),
            symbol("added-a", "b"),
            symbol("changed-a", "b"),
        ],
        previous_relations=[
            relation("removed-edge-b"),
            relation("changed-edge-b", confidence=0.6),
            relation("removed-edge-a"),
            relation("changed-edge-a", confidence=0.6),
        ],
        current_relations=[
            relation("added-edge-b"),
            relation("changed-edge-b", confidence=0.9),
            relation("added-edge-a"),
            relation("changed-edge-a", confidence=0.9),
        ],
    )

    assert [(event.event_type, event.subject_id) for event in events] == [
        ("symbol_added", "added-a"),
        ("symbol_added", "added-b"),
        ("symbol_changed", "changed-a"),
        ("symbol_changed", "changed-b"),
        ("symbol_removed", "removed-a"),
        ("symbol_removed", "removed-b"),
        ("edge_added", "added-edge-a"),
        ("edge_added", "added-edge-b"),
        ("edge_changed", "changed-edge-a"),
        ("edge_changed", "changed-edge-b"),
        ("edge_removed", "removed-edge-a"),
        ("edge_removed", "removed-edge-b"),
    ]


def test_diff_output_is_identical_for_shuffled_inputs():
    ordered_events = diff_facts(
        commit_hash="commit-1",
        previous_symbols=[
            symbol("removed-a", "a"),
            symbol("changed-a", "a"),
            symbol("changed-b", "a"),
        ],
        current_symbols=[
            symbol("added-a", "b"),
            symbol("changed-a", "b"),
            symbol("changed-b", "b"),
        ],
        previous_relations=[
            relation("removed-edge-a"),
            relation("changed-edge-a", confidence=0.6),
            relation("changed-edge-b", confidence=0.6),
        ],
        current_relations=[
            relation("added-edge-a"),
            relation("changed-edge-a", confidence=0.9),
            relation("changed-edge-b", confidence=0.9),
        ],
    )
    shuffled_events = diff_facts(
        commit_hash="commit-1",
        previous_symbols=[
            symbol("changed-b", "a"),
            symbol("removed-a", "a"),
            symbol("changed-a", "a"),
        ],
        current_symbols=[
            symbol("changed-b", "b"),
            symbol("added-a", "b"),
            symbol("changed-a", "b"),
        ],
        previous_relations=[
            relation("changed-edge-b", confidence=0.6),
            relation("removed-edge-a"),
            relation("changed-edge-a", confidence=0.6),
        ],
        current_relations=[
            relation("changed-edge-b", confidence=0.9),
            relation("added-edge-a"),
            relation("changed-edge-a", confidence=0.9),
        ],
    )

    assert [(event.id, event.event_type) for event in shuffled_events] == [
        (event.id, event.event_type) for event in ordered_events
    ]


def test_changed_symbol_payload_is_valid_canonical_json():
    events = diff_facts(
        commit_hash="commit-1",
        previous_symbols=[symbol("changed", "a")],
        current_symbols=[symbol("changed", "b")],
        previous_relations=[],
        current_relations=[],
    )

    payload_json = events[0].payload_json
    payload = json.loads(payload_json)

    assert payload["current"]["source_hash"] == "b"
    assert payload_json == json.dumps(payload, sort_keys=True, separators=(",", ":"))
