from pathlib import Path

from typer.testing import CliRunner

from repostrata import __version__
from repostrata.cli import app
from repostrata.config import load_manifest, write_manifest
from repostrata.paths import paths_for


def test_cli_version_outputs_exact_package_version():
    result = CliRunner().invoke(app, ["--version"])

    assert result.exit_code == 0
    assert result.stdout.strip() == f"repostrata {__version__}"


def test_cli_without_args_shows_help():
    result = CliRunner().invoke(app, [])

    assert result.exit_code == 0
    assert "Usage" in result.stdout
    assert "Build and explore a time-aware code knowledge graph." in result.stdout


def test_init_creates_project_data_directory(tmp_path):
    result = CliRunner().invoke(app, ["init", "--repo", str(tmp_path)])

    assert result.exit_code == 0
    data_dir = tmp_path / ".repostrata"
    assert (data_dir / "config.toml").exists()
    assert (data_dir / "manifest.json").exists()
    assert (data_dir / "cache").is_dir()
    assert (data_dir / "runs").is_dir()
    assert (data_dir / "locks").is_dir()


def test_manifest_records_schema_version(tmp_path):
    CliRunner().invoke(app, ["init", "--repo", str(tmp_path)])

    manifest = load_manifest(tmp_path)

    assert manifest["schema_version"] == 1
    assert manifest["indexed_head"] is None
    assert manifest["indexed_commits"] == 0
    assert manifest["database_path"] == ".repostrata/graph.db"


def test_write_manifest_preserves_provided_updates(tmp_path):
    CliRunner().invoke(app, ["init", "--repo", str(tmp_path)])
    manifest = load_manifest(tmp_path)
    manifest["indexed_head"] = "abc123"
    manifest["indexed_commits"] = 42

    write_manifest(tmp_path, manifest)

    updated_manifest = load_manifest(tmp_path)
    assert updated_manifest["indexed_head"] == "abc123"
    assert updated_manifest["indexed_commits"] == 42


def test_init_writes_default_project_config(tmp_path):
    result = CliRunner().invoke(app, ["init", "--repo", str(tmp_path)])

    assert result.exit_code == 0
    config_text = (tmp_path / ".repostrata" / "config.toml").read_text(
        encoding="utf-8"
    )
    assert "[index]" in config_text
    assert 'languages = ["python", "typescript", "javascript"]' in config_text
    assert 'snapshot_strategy = "mixed"' in config_text
    assert "[dashboard]" in config_text
    assert 'host = "127.0.0.1"' in config_text
    assert "port = 8765" in config_text


def test_paths_for_resolves_relative_project_root(tmp_path, monkeypatch):
    monkeypatch.chdir(tmp_path)

    paths = paths_for(Path("."))

    assert paths.root.is_absolute()
    assert paths.data_dir == paths.root / ".repostrata"
