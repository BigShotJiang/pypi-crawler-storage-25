import json
from pathlib import Path

from typer.testing import CliRunner

from repostrata.cli import app


def test_codex_install_writes_marketplace_plugin_and_config(tmp_path):
    install_root = tmp_path / "codex-install"
    codex_config = tmp_path / ".codex" / "config.toml"

    result = CliRunner().invoke(
        app,
        [
            "codex",
            "install",
            "--install-root",
            str(install_root),
            "--config",
            str(codex_config),
        ],
    )

    assert result.exit_code == 0, result.output
    marketplace_path = install_root / ".agents" / "plugins" / "marketplace.json"
    plugin_manifest = install_root / "plugins" / "repostrata" / ".codex-plugin" / "plugin.json"
    mcp_config = install_root / "plugins" / "repostrata" / ".mcp.json"
    assert marketplace_path.exists()
    assert plugin_manifest.exists()
    assert mcp_config.exists()

    marketplace = json.loads(marketplace_path.read_text(encoding="utf-8"))
    assert marketplace["plugins"][0]["name"] == "repostrata"
    assert marketplace["plugins"][0]["source"]["path"] == "./plugins/repostrata"

    config_text = codex_config.read_text(encoding="utf-8")
    assert "[marketplaces.repostrata-local]" in config_text
    assert f'source = "{install_root}"' in config_text
    assert '[plugins."repostrata@repostrata-local"]' in config_text
    assert "enabled = true" in config_text


def test_codex_install_is_idempotent_and_preserves_other_config(tmp_path):
    install_root = tmp_path / "codex-install"
    codex_config = tmp_path / ".codex" / "config.toml"
    codex_config.parent.mkdir()
    codex_config.write_text(
        'model = "gpt-5.5"\n\n[plugins."github@openai-curated"]\nenabled = true\n',
        encoding="utf-8",
    )

    for _ in range(2):
        result = CliRunner().invoke(
            app,
            [
                "codex",
                "install",
                "--install-root",
                str(install_root),
                "--config",
                str(codex_config),
            ],
        )
        assert result.exit_code == 0, result.output

    config_text = codex_config.read_text(encoding="utf-8")
    assert 'model = "gpt-5.5"' in config_text
    assert '[plugins."github@openai-curated"]' in config_text
    assert config_text.count("[marketplaces.repostrata-local]") == 1
    assert config_text.count('[plugins."repostrata@repostrata-local"]') == 1


def test_codex_doctor_reports_missing_install(tmp_path):
    result = CliRunner().invoke(
        app,
        [
            "codex",
            "doctor",
            "--install-root",
            str(tmp_path / "missing"),
            "--config",
            str(tmp_path / ".codex" / "config.toml"),
        ],
    )

    assert result.exit_code == 1
    assert "marketplace: missing" in result.output
    assert "codex_config: missing" in result.output


def test_codex_uninstall_removes_config_sections_and_install_root(tmp_path):
    install_root = tmp_path / "codex-install"
    codex_config = tmp_path / ".codex" / "config.toml"
    install_result = CliRunner().invoke(
        app,
        [
            "codex",
            "install",
            "--install-root",
            str(install_root),
            "--config",
            str(codex_config),
        ],
    )
    assert install_result.exit_code == 0, install_result.output

    uninstall_result = CliRunner().invoke(
        app,
        [
            "codex",
            "uninstall",
            "--install-root",
            str(install_root),
            "--config",
            str(codex_config),
        ],
    )

    assert uninstall_result.exit_code == 0, uninstall_result.output
    assert not install_root.exists()
    config_text = codex_config.read_text(encoding="utf-8")
    assert "[marketplaces.repostrata-local]" not in config_text
    assert '[plugins."repostrata@repostrata-local"]' not in config_text
