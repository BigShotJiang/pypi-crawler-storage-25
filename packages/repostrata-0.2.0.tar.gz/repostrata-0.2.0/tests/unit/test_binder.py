from repostrata.index.binder import bind_relations
from repostrata.parsing.extractors import extract_facts


def _facts(file_path: str, language: str, source: bytes):
    return extract_facts(file_path, language, source)


def test_bind_relations_resolves_python_imported_call_across_files():
    util_facts = _facts(
        "util.py",
        "python",
        b"def helper():\n    return 1\n",
    )
    app_facts = _facts(
        "app.py",
        "python",
        b"from util import helper\n\n"
        b"def run():\n"
        b"    return helper()\n",
    )
    symbols = [*util_facts.symbols, *app_facts.symbols]
    relations = bind_relations(
        symbols,
        [*util_facts.relations, *app_facts.relations],
    )
    symbols_by_file_name = {
        (symbol.file_path, symbol.qualified_name): symbol for symbol in symbols
    }

    run = symbols_by_file_name[("app.py", "run")]
    helper = symbols_by_file_name[("util.py", "helper")]

    assert any(
        relation.kind == "calls"
        and relation.source_id == run.id
        and relation.target_id == helper.id
        for relation in relations
    )


def test_bind_relations_resolves_typescript_named_import_alias_call():
    lib_facts = _facts(
        "lib.ts",
        "typescript",
        b"export function load() { return 1; }\n",
    )
    view_facts = _facts(
        "view.ts",
        "typescript",
        b"import { load as fetchValue } from './lib';\n"
        b"export function render() { return fetchValue(); }\n",
    )
    symbols = [*lib_facts.symbols, *view_facts.symbols]
    relations = bind_relations(
        symbols,
        [*lib_facts.relations, *view_facts.relations],
    )
    symbols_by_file_name = {
        (symbol.file_path, symbol.qualified_name): symbol for symbol in symbols
    }

    render = symbols_by_file_name[("view.ts", "render")]
    load = symbols_by_file_name[("lib.ts", "load")]

    assert any(
        relation.kind == "calls"
        and relation.source_id == render.id
        and relation.target_id == load.id
        for relation in relations
    )


def test_bind_relations_resolves_python_module_import_attribute_call():
    util_facts = _facts("util.py", "python", b"def helper():\n    return 1\n")
    app_facts = _facts(
        "app.py",
        "python",
        b"import util\n\n"
        b"def run():\n"
        b"    return util.helper()\n",
    )
    symbols = [*util_facts.symbols, *app_facts.symbols]
    relations = bind_relations(
        symbols,
        [*util_facts.relations, *app_facts.relations],
    )
    symbols_by_file_name = {
        (symbol.file_path, symbol.qualified_name): symbol for symbol in symbols
    }

    run = symbols_by_file_name[("app.py", "run")]
    helper = symbols_by_file_name[("util.py", "helper")]

    assert any(
        relation.kind == "calls"
        and relation.source_id == run.id
        and relation.target_id == helper.id
        for relation in relations
    )


def test_bind_relations_resolves_typescript_namespace_import_call():
    lib_facts = _facts(
        "lib.ts",
        "typescript",
        b"export function load() { return 1; }\n",
    )
    view_facts = _facts(
        "view.ts",
        "typescript",
        b"import * as lib from './lib';\n"
        b"export function render() { return lib.load(); }\n",
    )
    symbols = [*lib_facts.symbols, *view_facts.symbols]
    relations = bind_relations(
        symbols,
        [*lib_facts.relations, *view_facts.relations],
    )
    symbols_by_file_name = {
        (symbol.file_path, symbol.qualified_name): symbol for symbol in symbols
    }

    render = symbols_by_file_name[("view.ts", "render")]
    load = symbols_by_file_name[("lib.ts", "load")]

    assert any(
        relation.kind == "calls"
        and relation.source_id == render.id
        and relation.target_id == load.id
        for relation in relations
    )


def test_bind_relations_binds_import_edges_to_module_symbols():
    lib_facts = _facts("lib.ts", "typescript", b"export function load() { return 1; }\n")
    view_facts = _facts(
        "view.ts",
        "typescript",
        b"import { load } from './lib';\n",
    )
    symbols = [*lib_facts.symbols, *view_facts.symbols]
    relations = bind_relations(
        symbols,
        [*lib_facts.relations, *view_facts.relations],
    )
    lib_module = next(
        symbol
        for symbol in symbols
        if symbol.kind == "module" and symbol.file_path == "lib.ts"
    )

    assert any(
        relation.kind == "imports" and relation.target_id == lib_module.id
        for relation in relations
    )


def test_bind_relations_keeps_ambiguous_unimported_call_unresolved():
    first_facts = _facts("first.py", "python", b"def duplicate():\n    return 1\n")
    second_facts = _facts("second.py", "python", b"def duplicate():\n    return 2\n")
    app_facts = _facts("app.py", "python", b"def run():\n    return duplicate()\n")

    relations = bind_relations(
        [*first_facts.symbols, *second_facts.symbols, *app_facts.symbols],
        [*first_facts.relations, *second_facts.relations, *app_facts.relations],
    )

    assert any(relation.target_id == "unresolved:duplicate" for relation in relations)


def test_bind_relations_uses_python_import_to_resolve_ambiguous_call():
    first_facts = _facts("first.py", "python", b"def duplicate():\n    return 1\n")
    second_facts = _facts("second.py", "python", b"def duplicate():\n    return 2\n")
    app_facts = _facts(
        "app.py",
        "python",
        b"from second import duplicate\n\n"
        b"def run():\n"
        b"    return duplicate()\n",
    )
    symbols = [*first_facts.symbols, *second_facts.symbols, *app_facts.symbols]
    relations = bind_relations(
        symbols,
        [*first_facts.relations, *second_facts.relations, *app_facts.relations],
    )
    symbols_by_file_name = {
        (symbol.file_path, symbol.qualified_name): symbol for symbol in symbols
    }
    run = symbols_by_file_name[("app.py", "run")]
    imported_duplicate = symbols_by_file_name[("second.py", "duplicate")]

    assert any(
        relation.kind == "calls"
        and relation.source_id == run.id
        and relation.target_id == imported_duplicate.id
        for relation in relations
    )


def test_bind_relations_resolves_unique_cross_file_short_name_call_to_symbol_id():
    util_facts = _facts("util.py", "python", b"def helper():\n    return 1\n")
    app_facts = _facts(
        "app.py",
        "python",
        b"def run():\n"
        b"    return util.helper()\n",
    )
    symbols = [*util_facts.symbols, *app_facts.symbols]
    relations = bind_relations(
        symbols,
        [*util_facts.relations, *app_facts.relations],
    )
    symbols_by_file_name = {
        (symbol.file_path, symbol.qualified_name): symbol for symbol in symbols
    }
    run = symbols_by_file_name[("app.py", "run")]
    helper = symbols_by_file_name[("util.py", "helper")]

    bound_call = next(
        relation
        for relation in relations
        if relation.kind == "calls" and relation.source_id == run.id
    )

    assert bound_call.target_id == helper.id
    assert isinstance(bound_call.target_id, str)
