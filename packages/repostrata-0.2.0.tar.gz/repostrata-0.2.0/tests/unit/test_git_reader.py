import subprocess

import pytest

from repostrata.git_reader import GitReader
from tests.fixtures.make_fixture_repo import make_fixture_repo, run


def test_git_reader_returns_empty_list_for_repo_without_head(tmp_path):
    repo = tmp_path / "empty_repo"
    repo.mkdir()
    run(repo, "init")

    assert GitReader(repo).iter_commits() == []


def test_git_reader_lists_commits_oldest_first(tmp_path):
    repo = tmp_path / "fixture_repo"
    hashes = make_fixture_repo(repo)

    commits = GitReader(repo).iter_commits()

    assert [commit.hash for commit in commits] == hashes
    assert set(commits[0].changed_files) == {"app.py"}
    assert set(commits[1].changed_files) == {"app.py", "ui.ts"}


def test_git_reader_reads_file_at_commit(tmp_path):
    repo = tmp_path / "fixture_repo"
    first, _second = make_fixture_repo(repo)

    source = GitReader(repo).read_file_at_commit(first, "app.py")

    assert source == "def greet(name):\n    return f'hello {name}'\n"


def test_git_reader_reads_second_revision_app_content(tmp_path):
    repo = tmp_path / "fixture_repo"
    _first, second = make_fixture_repo(repo)

    source = GitReader(repo).read_file_at_commit(second, "app.py")

    assert "def greet(name):" in source
    assert "return greet(name)" in source


def test_git_reader_reports_merge_commit_changed_files(tmp_path):
    repo = tmp_path / "merge_repo"
    repo.mkdir()
    run(repo, "init")
    run(repo, "config", "user.name", "Fixture Dev")
    run(repo, "config", "user.email", "fixture@example.com")

    (repo / "main.txt").write_text("main\n", encoding="utf-8")
    run(repo, "add", "main.txt")
    run(repo, "commit", "-m", "add main")
    main_branch = run(repo, "rev-parse", "--abbrev-ref", "HEAD")

    run(repo, "checkout", "-b", "feature")
    (repo / "branch.txt").write_text("branch\n", encoding="utf-8")
    run(repo, "add", "branch.txt")
    run(repo, "commit", "-m", "add branch file")

    run(repo, "checkout", main_branch)
    run(repo, "merge", "--no-ff", "feature", "-m", "merge feature")
    merge_hash = run(repo, "rev-parse", "HEAD")

    merge_commit = next(
        commit for commit in GitReader(repo).iter_commits() if commit.hash == merge_hash
    )

    assert "branch.txt" in merge_commit.changed_files


def test_fixture_repo_forces_commit_dates(tmp_path, monkeypatch):
    monkeypatch.setenv("GIT_AUTHOR_DATE", "1999-01-01T00:00:00+00:00")
    monkeypatch.setenv("GIT_COMMITTER_DATE", "1999-01-01T00:00:00+00:00")
    repo = tmp_path / "fixture_repo"
    make_fixture_repo(repo)

    commits = GitReader(repo).iter_commits()

    assert [commit.authored_at for commit in commits] == [
        "2026-05-13T12:00:00Z",
        "2026-05-13T12:00:00Z",
    ]


def test_git_reader_raises_for_nonexistent_file_at_commit(tmp_path):
    repo = tmp_path / "fixture_repo"
    first, _ = make_fixture_repo(repo)

    with pytest.raises(subprocess.CalledProcessError):
        GitReader(repo).read_file_at_commit(first, "nonexistent.py")
