from repostrata.parsing.extractors import extract_facts
from repostrata.parsing.registry import language_for_path


def test_extract_facts_finds_python_symbols_and_relations():
    source = (
        b"def greet(name):\n"
        b"    return name\n"
        b"\n"
        b"class Greeter:\n"
        b"    def run(self):\n"
        b"        return greet('Ada')\n"
    )

    facts = extract_facts("app.py", "python", source)

    assert {symbol.qualified_name for symbol in facts.symbols} == {
        "app.py",
        "greet",
        "Greeter",
        "Greeter.run",
    }
    assert {"contains", "calls"}.issubset(
        {relation.kind for relation in facts.relations}
    )


def test_extract_facts_finds_typescript_symbols_and_relations():
    source = (
        b"import { x } from './lib';\n"
        b"export function render() { return x(); }\n"
        b"class View { paint() { return render(); } }\n"
    )

    facts = extract_facts("view.ts", "typescript", source)

    assert {symbol.qualified_name for symbol in facts.symbols} == {
        "view.ts",
        "render",
        "View",
        "View.paint",
    }
    assert {"imports", "calls"}.issubset(
        {relation.kind for relation in facts.relations}
    )
    symbol_ids = {symbol.id for symbol in facts.symbols}
    import_relations = [
        relation for relation in facts.relations if relation.kind == "imports"
    ]
    assert import_relations
    assert import_relations[0].source_id in symbol_ids


def test_extract_facts_unwraps_decorated_python_function():
    source = (
        b"def decorator(fn):\n"
        b"    return fn\n"
        b"\n"
        b"@decorator\n"
        b"def wrapped():\n"
        b"    return None\n"
    )

    facts = extract_facts("app.py", "python", source)

    assert "wrapped" in {symbol.qualified_name for symbol in facts.symbols}


def test_decorated_python_function_hash_includes_decorator():
    source = b"@decorator_a\ndef wrapped():\n    return value\n"
    changed_source = b"@decorator_b\ndef wrapped():\n    return value\n"

    facts = extract_facts("app.py", "python", source)
    changed_facts = extract_facts("app.py", "python", changed_source)
    symbol = next(
        symbol for symbol in facts.symbols if symbol.qualified_name == "wrapped"
    )
    changed_symbol = next(
        symbol
        for symbol in changed_facts.symbols
        if symbol.qualified_name == "wrapped"
    )

    assert changed_symbol.id == symbol.id
    assert changed_symbol.qualified_name == symbol.qualified_name
    assert symbol.start_line == 1
    assert changed_symbol.source_hash != symbol.source_hash


def test_extract_facts_unwraps_decorated_python_class_and_method():
    source = (
        b"def decorator(value):\n"
        b"    return value\n"
        b"\n"
        b"@decorator\n"
        b"class Wrapped:\n"
        b"    @decorator\n"
        b"    def run(self):\n"
        b"        return None\n"
    )

    facts = extract_facts("app.py", "python", source)

    assert {"Wrapped", "Wrapped.run"}.issubset(
        {symbol.qualified_name for symbol in facts.symbols}
    )


def test_decorated_python_method_hash_includes_decorator():
    source = (
        b"class Wrapped:\n"
        b"    @decorator_a\n"
        b"    def run(self):\n"
        b"        return value\n"
    )
    changed_source = (
        b"class Wrapped:\n"
        b"    @decorator_b\n"
        b"    def run(self):\n"
        b"        return value\n"
    )

    facts = extract_facts("app.py", "python", source)
    changed_facts = extract_facts("app.py", "python", changed_source)
    hashes = {symbol.qualified_name: symbol.source_hash for symbol in facts.symbols}
    changed_hashes = {
        symbol.qualified_name: symbol.source_hash for symbol in changed_facts.symbols
    }
    symbols = {symbol.qualified_name: symbol for symbol in facts.symbols}

    assert symbols["Wrapped.run"].start_line == 2
    assert changed_hashes["Wrapped.run"] != hashes["Wrapped.run"]


def test_registry_maps_all_known_extensions():
    assert language_for_path("app.py") == "python"
    assert language_for_path("app.ts") == "typescript"
    assert language_for_path("app.js") == "javascript"
    assert language_for_path("app.jsx") == "javascript"
    assert language_for_path("view.tsx") == "tsx"


def test_registry_returns_none_for_unknown_extension():
    assert language_for_path("README.md") is None
    assert language_for_path("Makefile") is None
    assert language_for_path("data.json") is None


def test_extract_facts_finds_tsx_function_symbols():
    source = b"export function View() { return <div />; }\n"

    facts = extract_facts("view.tsx", "tsx", source)

    assert {symbol.qualified_name for symbol in facts.symbols} == {"view.tsx", "View"}


def test_python_call_extraction_skips_nested_scopes():
    source = (
        b"def outer():\n"
        b"    def inner():\n"
        b"        leaf()\n"
        b"    inner()\n"
    )

    facts = extract_facts("app.py", "python", source)
    symbols_by_name = {symbol.qualified_name: symbol for symbol in facts.symbols}

    outer_targets = {
        relation.target_id
        for relation in facts.relations
        if relation.source_id == symbols_by_name["outer"].id
    }
    assert "unresolved:inner" in outer_targets
    assert "unresolved:leaf" not in outer_targets


def test_typescript_call_extraction_skips_nested_scopes():
    source = (
        b"function outer() {\n"
        b"  function inner() {\n"
        b"    leaf();\n"
        b"  }\n"
        b"  inner();\n"
        b"}\n"
    )

    facts = extract_facts("app.ts", "typescript", source)
    symbols_by_name = {symbol.qualified_name: symbol for symbol in facts.symbols}

    outer_targets = {
        relation.target_id
        for relation in facts.relations
        if relation.source_id == symbols_by_name["outer"].id
    }
    assert "unresolved:inner" in outer_targets
    assert "unresolved:leaf" not in outer_targets

    assert "inner" in symbols_by_name
    inner_targets = {
        relation.target_id
        for relation in facts.relations
        if relation.source_id == symbols_by_name["inner"].id
    }
    assert "unresolved:leaf" in inner_targets


def test_duplicate_same_name_symbols_get_unique_ids():
    source = (
        b"def duplicate():\n"
        b"    return 1\n"
        b"\n"
        b"def duplicate():\n"
        b"    return 2\n"
    )

    facts = extract_facts("app.py", "python", source)

    assert len({symbol.id for symbol in facts.symbols}) == len(facts.symbols)
    assert [symbol.qualified_name for symbol in facts.symbols] == [
        "app.py",
        "duplicate",
        "duplicate",
    ]


def test_symbol_source_hash_tracks_symbol_source_only():
    source = (
        b"def stable():\n"
        b"    return 1\n"
        b"\n"
        b"def changed():\n"
        b"    return 2\n"
    )
    changed_source = (
        b"def stable():\n"
        b"    return 1\n"
        b"\n"
        b"def changed():\n"
        b"    return 3\n"
    )

    facts = extract_facts("app.py", "python", source)
    changed_facts = extract_facts("app.py", "python", changed_source)
    hashes = {symbol.qualified_name: symbol.source_hash for symbol in facts.symbols}
    changed_hashes = {
        symbol.qualified_name: symbol.source_hash for symbol in changed_facts.symbols
    }

    assert changed_hashes["stable"] == hashes["stable"]
    assert changed_hashes["changed"] != hashes["changed"]


def test_extract_facts_returns_empty_for_unsupported_language():
    facts = extract_facts("foo.rb", "ruby", b"def hello; end\n")

    assert facts.symbols == []
    assert facts.relations == []
