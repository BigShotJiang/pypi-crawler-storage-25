import sqlite3

import pytest

from repostrata.db.connection import connect
from repostrata.db.migrations import migrate
from repostrata.db.repository import GraphRepository
from repostrata.models import CommitRecord, SymbolFact


def make_commit(hash: str = "abc123") -> CommitRecord:
    return CommitRecord(
        hash=hash,
        parents=[],
        author_name="Dev",
        author_email="dev@example.com",
        authored_at="2026-05-13T12:00:00+00:00",
        message="initial",
        changed_files=["app.py"],
    )


def test_migrate_creates_core_tables(tmp_path):
    db_path = tmp_path / "graph.db"

    with connect(db_path) as conn:
        migrate(conn)
        tables = {
            row[0]
            for row in conn.execute(
                "select name from sqlite_master where type = 'table'"
            )
        }

    assert {
        "schema_version",
        "commits",
        "files",
        "symbols",
        "relations",
        "events",
        "snapshots",
        "snapshot_nodes",
        "snapshot_edges",
        "cochange_edges",
        "index_runs",
    }.issubset(tables)


def test_connect_context_manager_closes_connection(tmp_path):
    db_path = tmp_path / "graph.db"

    with connect(db_path) as conn:
        conn.execute("select 1")

    with pytest.raises(sqlite3.ProgrammingError, match="closed database"):
        conn.execute("select 1")


def test_repository_upserts_commit(tmp_path):
    db_path = tmp_path / "graph.db"
    with connect(db_path) as conn:
        migrate(conn)
        repo = GraphRepository(conn)
        repo.upsert_commit(make_commit())
        repo.commit()

        rows = conn.execute("select hash, message from commits").fetchall()

    assert [tuple(row) for row in rows] == [("abc123", "initial")]


def test_repository_upsert_can_be_rolled_back_before_commit(tmp_path):
    db_path = tmp_path / "graph.db"
    with connect(db_path) as conn:
        migrate(conn)
        repo = GraphRepository(conn)
        repo.upsert_commit(make_commit())
        conn.rollback()

    with connect(db_path) as conn:
        rows = conn.execute("select hash from commits").fetchall()

    assert rows == []


def test_events_require_existing_commit(tmp_path):
    db_path = tmp_path / "graph.db"
    with connect(db_path) as conn:
        migrate(conn)

        with pytest.raises(sqlite3.IntegrityError):
            conn.execute(
                """
                insert into events(
                  id, commit_hash, event_type, subject_id, payload_json
                )
                values (?, ?, ?, ?, ?)
                """,
                ("evt1", "missing", "symbol.added", "sym1", "{}"),
            )


def test_snapshot_nodes_require_existing_snapshot_and_symbol(tmp_path):
    db_path = tmp_path / "graph.db"
    with connect(db_path) as conn:
        migrate(conn)

        with pytest.raises(sqlite3.IntegrityError):
            conn.execute(
                "insert into snapshot_nodes(snapshot_id, symbol_id) values (?, ?)",
                ("missing-snapshot", "missing-symbol"),
            )


def test_migrate_is_idempotent_for_schema_version(tmp_path):
    db_path = tmp_path / "graph.db"
    with connect(db_path) as conn:
        migrate(conn)
        migrate(conn)

        rows = conn.execute("select version from schema_version").fetchall()

    assert [row[0] for row in rows] == [1]


def make_symbol(symbol_id: str) -> SymbolFact:
    return SymbolFact(
        id=symbol_id,
        kind="function",
        language="python",
        file_path=f"{symbol_id}.py",
        qualified_name=symbol_id,
        name=symbol_id,
        start_line=1,
        end_line=1,
        source_hash="hash",
    )


def test_repository_search_symbols_escapes_underscore_wildcard(tmp_path):
    db_path = tmp_path / "graph.db"
    with connect(db_path) as conn:
        migrate(conn)
        repo = GraphRepository(conn)
        repo.upsert_symbol(make_symbol("getXuser"))
        repo.upsert_symbol(make_symbol("get_user"))
        repo.commit()

        results = repo.search_symbols("get_user")

    qualified_names = {r["qualified_name"] for r in results}
    assert "get_user" in qualified_names
    assert "getXuser" not in qualified_names


def test_repository_upsert_cochange_accumulates_weight(tmp_path):
    db_path = tmp_path / "graph.db"
    with connect(db_path) as conn:
        migrate(conn)
        repo = GraphRepository(conn)
        repo.upsert_symbol(make_symbol("sym-a"))
        repo.upsert_symbol(make_symbol("sym-b"))
        repo.upsert_cochange("sym-a", "sym-b", "commit-1")
        repo.upsert_cochange("sym-a", "sym-b", "commit-2")
        repo.commit()

        row = conn.execute(
            "select weight, last_commit_hash from cochange_edges"
            " where source_id = 'sym-a' and target_id = 'sym-b'"
        ).fetchone()

    assert row["weight"] == 2.0
    assert row["last_commit_hash"] == "commit-2"


def test_migrate_rejects_newer_schema_version(tmp_path):
    db_path = tmp_path / "graph.db"
    with connect(db_path) as conn:
        conn.execute("create table schema_version(version integer primary key)")
        conn.execute("insert into schema_version(version) values (99)")
        conn.commit()

        with pytest.raises(RuntimeError, match="newer schema version"):
            migrate(conn)
