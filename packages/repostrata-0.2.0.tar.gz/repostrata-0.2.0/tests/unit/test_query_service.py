import pytest

from repostrata.config import init_project, load_manifest
from repostrata.db.connection import connect
from repostrata.db.repository import GraphRepository
from repostrata.index.coordinator import index_repository
from repostrata.paths import paths_for
from repostrata.query.service import QueryService
from tests.fixtures.make_fixture_repo import make_fixture_repo


@pytest.fixture
def indexed_repo(tmp_path):
    repo = tmp_path / "fixture_repo"
    make_fixture_repo(repo)
    init_project(repo)
    index_repository(repo)
    return repo


def test_status_reports_indexed_repo_counts(indexed_repo):
    result = QueryService(indexed_repo).status()

    item = result.items[0]
    manifest = load_manifest(indexed_repo)
    assert result.truncated is False
    assert item["indexed"] is True
    assert item["indexed_head"] == manifest["indexed_head"]
    assert item["indexed_commits"] == 2
    assert item["commit_count"] == 2
    assert item["symbol_count"] >= 4
    assert item["relation_count"] >= 1
    assert item["event_count"] >= 1
    assert "indexed" in result.summary


def test_status_reports_unindexed_repo_without_creating_database(tmp_path):
    repo = tmp_path / "repo"
    repo.mkdir()
    init_project(repo)
    graph_db = repo / ".repostrata" / "graph.db"

    result = QueryService(repo).status()

    assert result.items == [
        {
            "repo_root": str(repo.resolve()),
            "indexed": False,
            "indexed_head": None,
            "indexed_commits": 0,
            "commit_count": 0,
            "symbol_count": 0,
            "relation_count": 0,
            "event_count": 0,
        }
    ]
    assert graph_db.exists() is False


def test_status_reports_uninitialized_repo_without_creating_database(tmp_path):
    repo = tmp_path / "repo"
    repo.mkdir()
    graph_db = repo / ".repostrata" / "graph.db"

    result = QueryService(repo).status()

    assert result.items == [
        {
            "repo_root": str(repo.resolve()),
            "indexed": False,
            "indexed_head": None,
            "indexed_commits": 0,
            "commit_count": 0,
            "symbol_count": 0,
            "relation_count": 0,
            "event_count": 0,
        }
    ]
    assert graph_db.exists() is False


def test_search_symbols_filters_by_kind_language_and_path(indexed_repo):
    result = QueryService(indexed_repo).search_symbols(
        query="Greeter",
        kind="class",
        language="python",
        path_prefix="app",
        limit=10,
    )

    assert result.truncated is False
    assert [item["qualified_name"] for item in result.items] == ["Greeter"]
    assert "symbol_id" in result.items[0]
    assert "id" not in result.items[0]
    assert result.items[0]["kind"] == "class"
    assert result.items[0]["file_path"] == "app.py"
    assert result.evidence[0]["kind"] == "symbol"


def test_search_symbols_rejects_empty_query(indexed_repo):
    with pytest.raises(ValueError, match="query is required"):
        QueryService(indexed_repo).search_symbols(query="   ")


def test_search_symbols_rejects_unindexed_repo_without_creating_database(tmp_path):
    repo = tmp_path / "repo"
    repo.mkdir()
    init_project(repo)
    graph_db = repo / ".repostrata" / "graph.db"

    with pytest.raises(
        LookupError,
        match="RepoStrata graph database has not been indexed",
    ):
        QueryService(repo).search_symbols(query="x")

    assert graph_db.exists() is False


def test_search_symbols_truncates_and_suggests_next_query(indexed_repo):
    result = QueryService(indexed_repo).search_symbols(query="g", limit=1)

    assert len(result.items) == 1
    assert result.truncated is True
    assert result.next_queries[0]["tool"] == "repostrata_search_symbols"


def test_search_symbols_caps_large_limit(indexed_repo, monkeypatch):
    observed_limits = []

    def fake_search_symbols_filtered(self, query, **kwargs):
        observed_limits.append(kwargs["limit"])
        return [
            {
                "id": f"symbol-{index}",
                "kind": "function",
                "language": "python",
                "file_path": "app.py",
                "qualified_name": f"greet_{index}",
                "name": f"greet_{index}",
                "start_line": 1,
                "end_line": 1,
            }
            for index in range(101)
        ]

    monkeypatch.setattr(
        GraphRepository,
        "search_symbols_filtered",
        fake_search_symbols_filtered,
    )

    result = QueryService(indexed_repo).search_symbols(query="greet", limit=500)

    assert observed_limits == [101]
    assert len(result.items) == 100
    assert result.truncated is True
    assert result.next_queries[0]["limit"] == 100


def _symbol_id(repo, qualified_name):
    result = QueryService(repo).search_symbols(query=qualified_name, limit=10)
    return next(
        item["symbol_id"]
        for item in result.items
        if item["qualified_name"] == qualified_name
    )


def _commits(repo):
    with connect(paths_for(repo).database_path) as conn:
        return GraphRepository(conn).list_commits()


def test_get_symbol_defaults_to_indexed_head(indexed_repo):
    symbol_id = _symbol_id(indexed_repo, "Greeter")

    result = QueryService(indexed_repo).get_symbol(symbol_id=symbol_id)

    assert result.items == [
        {
            **result.items[0],
            "symbol_id": symbol_id,
            "qualified_name": "Greeter",
            "present_at_commit": True,
        }
    ]
    assert result.evidence[0]["commit_hash"] == load_manifest(indexed_repo)["indexed_head"]


def test_get_symbol_returns_ambiguous_qualified_name_matches(indexed_repo):
    result = QueryService(indexed_repo).get_symbol(qualified_name="greet")

    assert len(result.items) >= 2
    assert "multiple" in result.summary.lower()
    assert all(query["tool"] == "repostrata_get_symbol" for query in result.next_queries)
    assert all(query["arguments"]["symbol_id"] for query in result.next_queries)


def test_get_symbol_requires_exactly_one_identifier(indexed_repo):
    with pytest.raises(ValueError, match="exactly one"):
        QueryService(indexed_repo).get_symbol()


def test_symbol_neighborhood_returns_edges_for_class(indexed_repo):
    symbol_id = _symbol_id(indexed_repo, "Greeter")

    result = QueryService(indexed_repo).get_symbol_neighborhood(
        symbol_id=symbol_id,
        depth=1,
    )

    assert result.items[0]["center_symbol_id"] == symbol_id
    assert any(edge["kind"] == "contains" for edge in result.items[0]["edges"])
    assert any(node["qualified_name"] == "Greeter.greet" for node in result.items[0]["nodes"])


def test_symbol_neighborhood_filters_direction_and_relation_kind(indexed_repo):
    symbol_id = _symbol_id(indexed_repo, "Greeter")

    result = QueryService(indexed_repo).get_symbol_neighborhood(
        symbol_id=symbol_id,
        direction="outgoing",
        relation_kinds=["contains"],
    )

    assert all(edge["source_id"] == symbol_id for edge in result.items[0]["edges"])
    assert all(edge["kind"] == "contains" for edge in result.items[0]["edges"])


def test_symbol_neighborhood_returns_empty_when_center_absent_at_commit(indexed_repo):
    symbol_id = _symbol_id(indexed_repo, "Greeter")
    first_commit = _commits(indexed_repo)[0]["hash"]

    result = QueryService(indexed_repo).get_symbol_neighborhood(
        symbol_id=symbol_id,
        commit=first_commit,
    )

    assert "not present" in result.summary
    assert result.items == [
        {
            "center_symbol_id": symbol_id,
            "nodes": [],
            "edges": [],
        }
    ]
    assert result.evidence == []


def test_symbol_neighborhood_depth_two_expands_beyond_direct_edges(indexed_repo):
    symbol_id = _symbol_id(indexed_repo, "Greeter")

    depth_one = QueryService(indexed_repo).get_symbol_neighborhood(
        symbol_id=symbol_id,
        depth=1,
        direction="outgoing",
    )
    depth_two = QueryService(indexed_repo).get_symbol_neighborhood(
        symbol_id=symbol_id,
        depth=2,
        direction="outgoing",
    )

    depth_one_edge_ids = {
        edge["relation_id"]
        for edge in depth_one.items[0]["edges"]
    }
    depth_two_edge_ids = {
        edge["relation_id"]
        for edge in depth_two.items[0]["edges"]
    }

    assert depth_one_edge_ids <= depth_two_edge_ids
    assert len(depth_two_edge_ids) > len(depth_one_edge_ids)
    assert any(
        edge["source_id"] != symbol_id
        for edge in depth_two.items[0]["edges"]
    )


def test_symbol_history_returns_latest_events(indexed_repo):
    symbol_id = _symbol_id(indexed_repo, "Greeter")

    result = QueryService(indexed_repo).get_symbol_history(symbol_id=symbol_id)

    assert result.items
    assert result.items[0]["subject_id"] == symbol_id
    assert result.items[0]["event_type"] == "symbol_added"
    assert result.evidence[0]["kind"] == "event"


def test_symbol_history_supports_commit_bounds(indexed_repo):
    symbol_id = _symbol_id(indexed_repo, "Greeter")
    head = load_manifest(indexed_repo)["indexed_head"]

    result = QueryService(indexed_repo).get_symbol_history(
        symbol_id=symbol_id,
        since=head,
        until=head,
    )

    assert [item["commit_hash"] for item in result.items] == [head]


def test_symbol_history_supports_iso_date_bounds(indexed_repo):
    symbol_id = _symbol_id(indexed_repo, "Greeter")

    result = QueryService(indexed_repo).get_symbol_history(
        symbol_id=symbol_id,
        since="2026-05-13T00:00:00+00:00",
        until="2026-05-14T00:00:00+00:00",
    )

    assert result.items
    assert all(item["event_type"] == "symbol_added" for item in result.items)


def test_symbol_history_truncation_suggests_next_query(indexed_repo, monkeypatch):
    symbol_id = _symbol_id(indexed_repo, "greet")
    first_event = {
        "id": "event-1",
        "commit_hash": "commit-1",
        "authored_at": "2026-05-13T12:00:00Z",
        "author_name": "Fixture Dev",
        "message": "first",
        "event_type": "symbol_added",
        "subject_id": symbol_id,
        "payload_json": "{}",
    }
    second_event = {
        **first_event,
        "id": "event-2",
        "commit_hash": "commit-2",
        "message": "second",
    }

    def fake_events_for_symbol(self, **kwargs):
        assert kwargs["limit"] == 2
        return [first_event, second_event]

    monkeypatch.setattr(
        GraphRepository,
        "events_for_symbol",
        fake_events_for_symbol,
    )

    result = QueryService(indexed_repo).get_symbol_history(
        symbol_id=symbol_id,
        limit=1,
    )

    assert result.truncated is True
    assert result.next_queries[0]["tool"] == "repostrata_get_symbol_history"
    assert result.next_queries[0]["arguments"]["symbol_id"] == symbol_id
