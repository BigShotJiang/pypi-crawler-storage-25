from repostrata.index.cochange import cochange_pairs
from repostrata.index.materializer import make_commit_snapshot, snapshot_id, snapshot_payload
from repostrata.models import RelationFact, SymbolFact


def symbol(symbol_id: str) -> SymbolFact:
    return SymbolFact(
        id=symbol_id,
        kind="function",
        language="python",
        file_path=f"{symbol_id}.py",
        qualified_name=symbol_id,
        name=symbol_id,
        start_line=1,
        end_line=1,
        source_hash="hash",
    )


def test_cochange_pairs_are_stable_and_sorted():
    a = symbol("a")
    b = symbol("b")
    c = symbol("c")

    assert cochange_pairs([c, a, b]) == [("a", "b"), ("a", "c"), ("b", "c")]
    assert cochange_pairs([a, b, c]) == cochange_pairs([c, a, b])


def test_cochange_pairs_returns_empty_for_zero_or_one_symbol():
    assert cochange_pairs([]) == []
    assert cochange_pairs([symbol("a")]) == []


def test_cochange_pairs_deduplicates_repeated_symbol_ids():
    a = symbol("a")
    b = symbol("b")
    assert cochange_pairs([a, a, b]) == [("a", "b")]


def test_snapshot_id_is_stable():
    assert snapshot_id("commit", "abc123") == snapshot_id("commit", "abc123")
    assert snapshot_id("commit", "abc123") != snapshot_id("commit", "def456")
    assert snapshot_id("commit", "abc123") != snapshot_id("date", "abc123")


def test_make_commit_snapshot_records_commit_metadata():
    snapshot = make_commit_snapshot("abc123", "message")

    assert snapshot.id == snapshot_id("commit", "abc123")
    assert snapshot.time_ref == "abc123"
    assert snapshot.commit_hash == "abc123"
    assert snapshot.label == "message"


def test_snapshot_payload_returns_symbol_and_relation_ids():
    relation = RelationFact(
        id="rel-1",
        kind="calls",
        source_id="a",
        target_id="b",
        file_path="a.py",
        confidence=1.0,
        provenance="test",
    )

    assert snapshot_payload([symbol("a"), symbol("b")], [relation]) == (
        ["a", "b"],
        ["rel-1"],
    )
