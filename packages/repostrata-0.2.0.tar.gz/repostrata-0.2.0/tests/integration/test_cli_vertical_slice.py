from contextlib import closing
import json
import sqlite3

from typer.testing import CliRunner

from repostrata.config import load_manifest
from repostrata.cli import app
from tests.fixtures.make_fixture_repo import make_fixture_repo, run


def test_init_and_index_create_graph_db_with_commits_and_symbols(tmp_path):
    repo = tmp_path / "fixture_repo"
    _, second_commit = make_fixture_repo(repo)
    runner = CliRunner()

    init_result = runner.invoke(app, ["init", "--repo", str(repo)])
    index_result = runner.invoke(app, ["index", "--repo", str(repo)])

    graph_db = repo / ".repostrata" / "graph.db"
    assert init_result.exit_code == 0
    assert index_result.exit_code == 0
    assert graph_db.exists()

    with closing(sqlite3.connect(graph_db)) as conn:
        commit_count = conn.execute("select count(*) from commits").fetchone()[0]
        symbol_names = {
            row[0] for row in conn.execute("select name from symbols order by name")
        }
        event_count = conn.execute("select count(*) from events").fetchone()[0]
        snapshot_count = conn.execute("select count(*) from snapshots").fetchone()[0]
        snapshot_node_count = conn.execute(
            "select count(*) from snapshot_nodes"
        ).fetchone()[0]

    assert commit_count == 2
    assert {"greet", "Greeter", "render"}.issubset(symbol_names)
    assert event_count > 0
    assert snapshot_count == 2
    assert snapshot_node_count > 0

    manifest = load_manifest(repo)
    assert manifest["indexed_head"] == second_commit
    assert manifest["indexed_commits"] == 2


def test_index_skips_unreadable_file_and_continues_history(tmp_path):
    repo = tmp_path / "recoverable_repo"
    repo.mkdir()
    run(repo, "init")
    run(repo, "config", "user.name", "Fixture Dev")
    run(repo, "config", "user.email", "fixture@example.com")

    (repo / "ok.py").write_text("def ok():\n    return True\n", encoding="utf-8")
    run(repo, "add", "ok.py")
    run(repo, "commit", "-m", "add ok")

    (repo / "bad.py").write_bytes(b"def bad():\n    return '\xff'\n")
    run(repo, "add", "bad.py")
    run(repo, "commit", "-m", "add bad bytes")

    runner = CliRunner()
    init_result = runner.invoke(app, ["init", "--repo", str(repo)])
    index_result = runner.invoke(app, ["index", "--repo", str(repo)])

    graph_db = repo / ".repostrata" / "graph.db"
    assert init_result.exit_code == 0
    assert index_result.exit_code == 0

    with closing(sqlite3.connect(graph_db)) as conn:
        commit_count = conn.execute("select count(*) from commits").fetchone()[0]
        symbol_names = {
            row[0] for row in conn.execute("select name from symbols order by name")
        }
        run_rows = conn.execute(
            "select status, message from index_runs order by started_at"
        ).fetchall()

    manifest = load_manifest(repo)
    assert commit_count == 2
    assert manifest["indexed_commits"] == 2
    assert "ok" in symbol_names
    assert run_rows
    assert run_rows[-1][0] == "completed_with_diagnostics"
    diagnostics = json.loads(run_rows[-1][1])["diagnostics"]
    assert diagnostics[0]["file"] == "bad.py"
    assert diagnostics[0]["language"] == "python"


def test_index_binds_cross_file_imported_symbol_calls(tmp_path):
    repo = tmp_path / "binding_repo"
    repo.mkdir()
    run(repo, "init")
    run(repo, "config", "user.name", "Fixture Dev")
    run(repo, "config", "user.email", "fixture@example.com")

    (repo / "first.py").write_text(
        "def duplicate():\n"
        "    return 1\n",
        encoding="utf-8",
    )
    (repo / "second.py").write_text(
        "def duplicate():\n"
        "    return 2\n",
        encoding="utf-8",
    )
    (repo / "app.py").write_text(
        "from second import duplicate\n"
        "\n"
        "def run():\n"
        "    return duplicate()\n",
        encoding="utf-8",
    )
    run(repo, "add", "first.py", "second.py", "app.py")
    run(repo, "commit", "-m", "add cross file binding case")

    runner = CliRunner()
    assert runner.invoke(app, ["init", "--repo", str(repo)]).exit_code == 0
    assert runner.invoke(app, ["index", "--repo", str(repo)]).exit_code == 0

    graph_db = repo / ".repostrata" / "graph.db"
    with closing(sqlite3.connect(graph_db)) as conn:
        row = conn.execute(
            """
            select target.file_path, target.qualified_name, relations.provenance
            from relations
            join symbols source on source.id = relations.source_id
            join symbols target on target.id = relations.target_id
            where relations.kind = 'calls'
              and source.file_path = 'app.py'
              and source.qualified_name = 'run'
            """
        ).fetchone()

    assert row == ("second.py", "duplicate", "binder:cross-file")


def test_invalid_changed_file_does_not_retain_stale_snapshot_symbols(tmp_path):
    repo = tmp_path / "invalid_update_repo"
    repo.mkdir()
    run(repo, "init")
    run(repo, "config", "user.name", "Fixture Dev")
    run(repo, "config", "user.email", "fixture@example.com")

    (repo / "broken.py").write_text(
        "def stale():\n    return True\n",
        encoding="utf-8",
    )
    run(repo, "add", "broken.py")
    run(repo, "commit", "-m", "add valid file")

    (repo / "broken.py").write_bytes(b"def stale():\n    return '\xff'\n")
    run(repo, "add", "broken.py")
    run(repo, "commit", "-m", "make file invalid")
    latest_commit = run(repo, "rev-parse", "HEAD")

    runner = CliRunner()
    assert runner.invoke(app, ["init", "--repo", str(repo)]).exit_code == 0
    assert runner.invoke(app, ["index", "--repo", str(repo)]).exit_code == 0

    graph_db = repo / ".repostrata" / "graph.db"
    with closing(sqlite3.connect(graph_db)) as conn:
        latest_snapshot_symbols = {
            row[0]
            for row in conn.execute(
                """
                select symbols.name
                from snapshots
                join snapshot_nodes on snapshot_nodes.snapshot_id = snapshots.id
                join symbols on symbols.id = snapshot_nodes.symbol_id
                where snapshots.commit_hash = ?
                """,
                (latest_commit,),
            )
        }

    manifest = load_manifest(repo)
    assert manifest["indexed_head"] == latest_commit
    assert manifest["indexed_commits"] == 2
    assert "stale" not in latest_snapshot_symbols


def test_deleted_file_emits_symbol_removed_event(tmp_path):
    repo = tmp_path / "deletion_repo"
    repo.mkdir()
    run(repo, "init")
    run(repo, "config", "user.name", "Fixture Dev")
    run(repo, "config", "user.email", "fixture@example.com")

    (repo / "gone.py").write_text("def gone():\n    return None\n", encoding="utf-8")
    run(repo, "add", "gone.py")
    run(repo, "commit", "-m", "add gone")

    (repo / "gone.py").unlink()
    run(repo, "add", "gone.py")
    run(repo, "commit", "-m", "delete gone")

    runner = CliRunner()
    assert runner.invoke(app, ["init", "--repo", str(repo)]).exit_code == 0
    assert runner.invoke(app, ["index", "--repo", str(repo)]).exit_code == 0

    graph_db = repo / ".repostrata" / "graph.db"
    with closing(sqlite3.connect(graph_db)) as conn:
        rows = conn.execute(
            """
            select event_type, subject_id, payload_json
            from events
            join symbols on symbols.id = events.subject_id
            where event_type in ('symbol_added', 'symbol_removed')
              and symbols.kind = 'function'
            order by event_type
            """
        ).fetchall()

    events = [
        (event_type, subject_id, json.loads(payload_json))
        for event_type, subject_id, payload_json in rows
    ]
    assert {event_type for event_type, _, _ in events} == {"symbol_added", "symbol_removed"}
    for _, subject_id, payload in events:
        assert subject_id == payload["id"]
        assert payload["file_path"] == "gone.py"
        assert payload["qualified_name"] == "gone"


def test_index_is_idempotent_for_fixture_repo(tmp_path):
    repo = tmp_path / "fixture_repo"
    make_fixture_repo(repo)
    runner = CliRunner()

    assert runner.invoke(app, ["init", "--repo", str(repo)]).exit_code == 0
    assert runner.invoke(app, ["index", "--repo", str(repo)]).exit_code == 0
    first_index_state = _index_state(repo)

    assert runner.invoke(app, ["index", "--repo", str(repo)]).exit_code == 0
    second_index_state = _index_state(repo)

    assert second_index_state == first_index_state


def test_cochange_weights_only_use_symbols_changed_in_commit(tmp_path):
    repo = tmp_path / "cochange_repo"
    repo.mkdir()
    run(repo, "init")
    run(repo, "config", "user.name", "Fixture Dev")
    run(repo, "config", "user.email", "fixture@example.com")

    (repo / "one.py").write_text("def one():\n    return 1\n", encoding="utf-8")
    (repo / "two.py").write_text("def two():\n    return 2\n", encoding="utf-8")
    run(repo, "add", "one.py", "two.py")
    run(repo, "commit", "-m", "add two files")

    (repo / "one.py").write_text("def one():\n    return 10\n", encoding="utf-8")
    run(repo, "add", "one.py")
    run(repo, "commit", "-m", "change one file")

    runner = CliRunner()
    assert runner.invoke(app, ["init", "--repo", str(repo)]).exit_code == 0
    assert runner.invoke(app, ["index", "--repo", str(repo)]).exit_code == 0

    graph_db = repo / ".repostrata" / "graph.db"
    with closing(sqlite3.connect(graph_db)) as conn:
        weights = [
            row[0]
            for row in conn.execute(
                "select weight from cochange_edges order by source_id, target_id"
            )
        ]

    assert weights == [1.0]


def test_index_empty_git_repo_records_empty_manifest(tmp_path):
    repo = tmp_path / "empty_repo"
    repo.mkdir()
    run(repo, "init")
    runner = CliRunner()

    init_result = runner.invoke(app, ["init", "--repo", str(repo)])
    index_result = runner.invoke(app, ["index", "--repo", str(repo)])

    assert init_result.exit_code == 0
    assert index_result.exit_code == 0
    manifest = load_manifest(repo)
    assert manifest["indexed_head"] is None
    assert manifest["indexed_commits"] == 0


def test_doctor_reports_initialized_repository(tmp_path):
    repo = tmp_path / "repo"
    make_fixture_repo(repo)
    runner = CliRunner()
    runner.invoke(app, ["init", "--repo", str(repo)])

    result = runner.invoke(app, ["doctor", "--repo", str(repo)])

    assert result.exit_code == 0
    assert "config: ok" in result.stdout
    assert "manifest: ok" in result.stdout


def test_doctor_exits_nonzero_for_uninitialized_repository(tmp_path):
    repo = tmp_path / "repo"
    repo.mkdir()
    runner = CliRunner()

    result = runner.invoke(app, ["doctor", "--repo", str(repo)])

    assert result.exit_code != 0
    assert "config: missing" in result.stdout
    assert "manifest: missing" in result.stdout


def _table_counts(repo):
    graph_db = repo / ".repostrata" / "graph.db"
    with closing(sqlite3.connect(graph_db)) as conn:
        return {
            table: conn.execute(f"select count(*) from {table}").fetchone()[0]
            for table in (
                "commits",
                "symbols",
                "relations",
                "events",
                "snapshots",
                "snapshot_nodes",
                "snapshot_edges",
                "cochange_edges",
            )
        }


def _index_state(repo):
    graph_db = repo / ".repostrata" / "graph.db"
    with closing(sqlite3.connect(graph_db)) as conn:
        return {
            "counts": _table_counts(repo),
            "cochange_edges": conn.execute(
                """
                select source_id, target_id, weight, last_commit_hash
                from cochange_edges
                order by source_id, target_id
                """
            ).fetchall(),
            "snapshot_nodes": conn.execute(
                """
                select snapshots.commit_hash, snapshot_nodes.symbol_id
                from snapshot_nodes
                join snapshots on snapshots.id = snapshot_nodes.snapshot_id
                order by snapshots.commit_hash, snapshot_nodes.symbol_id
                """
            ).fetchall(),
            "snapshot_edges": conn.execute(
                """
                select snapshots.commit_hash, snapshot_edges.relation_id
                from snapshot_edges
                join snapshots on snapshots.id = snapshot_edges.snapshot_id
                order by snapshots.commit_hash, snapshot_edges.relation_id
                """
            ).fetchall(),
        }
