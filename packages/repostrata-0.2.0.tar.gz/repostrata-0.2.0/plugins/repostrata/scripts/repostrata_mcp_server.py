#!/usr/bin/env python3
from __future__ import annotations

import json
import os
import sys
import urllib.error
import urllib.request
from typing import Any


DEFAULT_BASE_URL = "http://127.0.0.1:8765"
STARTUP_INSTRUCTION = "repostrata dashboard --repo /path/to/repo --port 8765"


TOOL_ENDPOINTS = {
    "repostrata_status": ("GET", "/api/agent/status"),
    "repostrata_search_symbols": ("POST", "/api/agent/symbols/search"),
    "repostrata_get_symbol": ("POST", "/api/agent/symbols/get"),
    "repostrata_get_symbol_neighborhood": ("POST", "/api/agent/symbols/neighborhood"),
    "repostrata_get_symbol_history": ("POST", "/api/agent/symbols/history"),
}


class HttpStatusError(Exception):
    def __init__(self, status: int, detail: str) -> None:
        self.status = status
        self.detail = detail
        super().__init__(f"HTTP {status}: {detail}")


def tool_definitions() -> list[dict[str, Any]]:
    return [
        {
            "name": "repostrata_status",
            "description": "Check whether the local RepoStrata API is available and indexed.",
            "inputSchema": {
                "type": "object",
                "properties": {},
                "additionalProperties": False,
            },
        },
        {
            "name": "repostrata_search_symbols",
            "description": "Search indexed symbols by name and optional filters.",
            "inputSchema": {
                "type": "object",
                "required": ["query"],
                "properties": {
                    "query": {"type": "string"},
                    "kind": {
                        "type": "string",
                        "enum": ["module", "class", "function", "method"],
                    },
                    "language": {
                        "type": "string",
                        "enum": ["python", "javascript", "typescript", "tsx"],
                    },
                    "path_prefix": {"type": "string"},
                    "limit": {"type": "integer", "minimum": 1, "maximum": 100},
                },
                "additionalProperties": False,
            },
        },
        {
            "name": "repostrata_get_symbol",
            "description": "Get symbol metadata by symbol_id or qualified_name.",
            "inputSchema": {
                "type": "object",
                "properties": {
                    "symbol_id": {"type": "string"},
                    "qualified_name": {"type": "string"},
                    "commit": {"type": "string"},
                },
                "oneOf": [
                    {"required": ["symbol_id"]},
                    {"required": ["qualified_name"]},
                ],
                "additionalProperties": False,
            },
        },
        {
            "name": "repostrata_get_symbol_neighborhood",
            "description": "Get a bounded graph neighborhood around one symbol.",
            "inputSchema": {
                "type": "object",
                "required": ["symbol_id"],
                "properties": {
                    "symbol_id": {"type": "string"},
                    "commit": {"type": "string"},
                    "depth": {"type": "integer", "enum": [1, 2]},
                    "relation_kinds": {
                        "type": "array",
                        "items": {"type": "string"},
                    },
                    "direction": {
                        "type": "string",
                        "enum": ["incoming", "outgoing", "both"],
                    },
                    "limit": {"type": "integer", "minimum": 1, "maximum": 200},
                },
                "additionalProperties": False,
            },
        },
        {
            "name": "repostrata_get_symbol_history",
            "description": "Get graph events and commit context for one symbol.",
            "inputSchema": {
                "type": "object",
                "required": ["symbol_id"],
                "properties": {
                    "symbol_id": {"type": "string"},
                    "since": {"type": "string"},
                    "until": {"type": "string"},
                    "event_types": {
                        "type": "array",
                        "items": {"type": "string"},
                    },
                    "limit": {"type": "integer", "minimum": 1, "maximum": 200},
                },
                "additionalProperties": False,
            },
        },
    ]


def call_tool(
    name: str,
    arguments: dict[str, Any],
    *,
    base_url: str | None = None,
) -> dict[str, Any]:
    base_url = base_url or os.environ.get("REPOSTRATA_BASE_URL", DEFAULT_BASE_URL)
    if name not in TOOL_ENDPOINTS:
        return error_result(f"Unknown RepoStrata tool: {name}")

    method, path = TOOL_ENDPOINTS[name]
    try:
        if method == "GET":
            payload = get_json(base_url, path)
        else:
            payload = post_json(base_url, path, arguments)
    except HttpStatusError as exc:
        return error_result(
            f"RepoStrata API returned HTTP {exc.status}: {exc.detail}"
        )
    except urllib.error.HTTPError as exc:
        http_error = _http_status_error(exc)
        return error_result(
            f"RepoStrata API returned HTTP {http_error.status}: {http_error.detail}"
        )
    except (OSError, urllib.error.URLError) as exc:
        return error_result(
            f"Could not reach RepoStrata at {base_url}: {exc}. "
            f"Start it with: {STARTUP_INSTRUCTION}"
        )
    return success_result(payload)


def get_json(base_url: str, path: str) -> dict[str, Any]:
    url = f"{base_url.rstrip('/')}{path}"
    request = urllib.request.Request(url, method="GET")
    try:
        with urllib.request.urlopen(request, timeout=10) as response:
            return json.loads(response.read().decode("utf-8"))
    except urllib.error.HTTPError as exc:
        raise _http_status_error(exc) from exc


def post_json(base_url: str, path: str, payload: dict[str, Any]) -> dict[str, Any]:
    url = f"{base_url.rstrip('/')}{path}"
    request = urllib.request.Request(
        url,
        data=json.dumps(payload).encode("utf-8"),
        headers={"Content-Type": "application/json"},
        method="POST",
    )
    try:
        with urllib.request.urlopen(request, timeout=10) as response:
            return json.loads(response.read().decode("utf-8"))
    except urllib.error.HTTPError as exc:
        raise _http_status_error(exc) from exc


def _http_status_error(exc: urllib.error.HTTPError) -> HttpStatusError:
    detail = exc.read().decode("utf-8", errors="replace")
    return HttpStatusError(exc.code, detail or exc.reason)


def success_result(payload: dict[str, Any]) -> dict[str, Any]:
    return {
        "content": [
            {
                "type": "text",
                "text": json.dumps(payload, ensure_ascii=False, indent=2),
            }
        ]
    }


def error_result(message: str) -> dict[str, Any]:
    return {
        "isError": True,
        "content": [{"type": "text", "text": message}],
    }


def read_message() -> dict[str, Any] | None:
    headers = {}
    while True:
        line = sys.stdin.buffer.readline()
        if not line:
            return None
        try:
            line_text = line.decode("ascii").strip()
        except UnicodeDecodeError:
            return json_rpc_error(None, -32600, "Invalid request: malformed header")
        if not line_text:
            break
        if ":" not in line_text:
            return json_rpc_error(None, -32600, "Invalid request: malformed header")
        key, value = line_text.split(":", 1)
        headers[key.lower()] = value.strip()

    if "content-length" not in headers:
        return json_rpc_error(None, -32600, "Invalid request: missing Content-Length")
    try:
        length = int(headers["content-length"])
    except ValueError:
        return json_rpc_error(None, -32600, "Invalid request: invalid Content-Length")

    body = sys.stdin.buffer.read(length)
    try:
        return json.loads(body.decode("utf-8"))
    except (UnicodeDecodeError, json.JSONDecodeError):
        return json_rpc_error(None, -32700, "Parse error: invalid JSON")


def write_message(message: dict[str, Any]) -> None:
    body = json.dumps(message, separators=(",", ":")).encode("utf-8")
    sys.stdout.buffer.write(f"Content-Length: {len(body)}\r\n\r\n".encode("ascii"))
    sys.stdout.buffer.write(body)
    sys.stdout.buffer.flush()


def json_rpc_error(
    request_id: Any,
    code: int,
    message: str,
) -> dict[str, Any]:
    return {
        "jsonrpc": "2.0",
        "id": request_id,
        "error": {"code": code, "message": message},
    }


def handle_request(message: dict[str, Any]) -> dict[str, Any] | None:
    if "error" in message and "method" not in message:
        return message
    if "id" not in message:
        return None

    request_id = message["id"]
    method = message.get("method")
    if method == "initialize":
        result = {
            "protocolVersion": "2024-11-05",
            "capabilities": {"tools": {}},
            "serverInfo": {"name": "repostrata", "version": "0.2.0"},
        }
    elif method == "tools/list":
        result = {"tools": tool_definitions()}
    elif method == "tools/call":
        params = message.get("params")
        if not isinstance(params, dict):
            return json_rpc_error(request_id, -32602, "Invalid params")
        name = params.get("name")
        arguments = params.get("arguments") or {}
        if not isinstance(name, str) or not isinstance(arguments, dict):
            return json_rpc_error(request_id, -32602, "Invalid params")
        if name not in TOOL_ENDPOINTS:
            return json_rpc_error(request_id, -32602, f"Unknown tool: {name}")
        result = call_tool(name, arguments)
    else:
        return json_rpc_error(request_id, -32601, f"Unknown method: {method}")

    return {"jsonrpc": "2.0", "id": request_id, "result": result}


def main() -> None:
    while True:
        message = read_message()
        if message is None:
            return
        response = handle_request(message)
        if response is not None:
            write_message(response)


if __name__ == "__main__":
    main()
