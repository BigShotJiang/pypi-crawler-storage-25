import json
from pathlib import Path
from typing import Any

from repostrata.paths import paths_for


DEFAULT_CONFIG = {
    "index": {
        "languages": ["python", "typescript", "javascript"],
        "snapshot_strategy": "mixed",
    },
    "dashboard": {
        "host": "127.0.0.1",
        "port": 8765,
    },
}


def init_project(repo_root: Path) -> None:
    paths = paths_for(repo_root)

    paths.data_dir.mkdir(exist_ok=True)
    paths.cache_dir.mkdir(exist_ok=True)
    paths.runs_dir.mkdir(exist_ok=True)
    paths.locks_dir.mkdir(exist_ok=True)

    if not paths.config_path.exists():
        paths.config_path.write_text(_default_config_toml(), encoding="utf-8")

    if not paths.manifest_path.exists():
        write_manifest(repo_root, _default_manifest())


def load_manifest(repo_root: Path) -> dict[str, Any]:
    paths = paths_for(repo_root)

    return json.loads(paths.manifest_path.read_text(encoding="utf-8"))


def write_manifest(repo_root: Path, manifest: dict[str, Any]) -> None:
    paths = paths_for(repo_root)

    paths.manifest_path.write_text(
        json.dumps(manifest, indent=2) + "\n",
        encoding="utf-8",
    )


def _default_manifest() -> dict[str, Any]:
    return {
        "schema_version": 1,
        "indexed_head": None,
        "indexed_commits": 0,
        "database_path": ".repostrata/graph.db",
        "feature_flags": {
            "tree_sitter": True,
            "agent_api": True,
        },
    }


def _default_config_toml() -> str:
    return (
        "[index]\n"
        'languages = ["python", "typescript", "javascript"]\n'
        'snapshot_strategy = "mixed"\n'
        "\n"
        "[dashboard]\n"
        'host = "127.0.0.1"\n'
        "port = 8765\n"
    )
