from __future__ import annotations

import json
import shutil
from dataclasses import dataclass
from importlib import resources
from pathlib import Path


MARKETPLACE_NAME = "repostrata-local"
PLUGIN_NAME = "repostrata"
PLUGIN_KEY = f'{PLUGIN_NAME}@{MARKETPLACE_NAME}'
DEFAULT_BASE_URL = "http://127.0.0.1:8765"


@dataclass(frozen=True)
class CodexInstallPaths:
    install_root: Path
    config_path: Path

    @property
    def marketplace_path(self) -> Path:
        return self.install_root / ".agents" / "plugins" / "marketplace.json"

    @property
    def plugin_dir(self) -> Path:
        return self.install_root / "plugins" / PLUGIN_NAME

    @property
    def plugin_manifest_path(self) -> Path:
        return self.plugin_dir / ".codex-plugin" / "plugin.json"

    @property
    def mcp_config_path(self) -> Path:
        return self.plugin_dir / ".mcp.json"


def default_install_root() -> Path:
    return Path.home() / ".repostrata" / "codex"


def default_codex_config_path() -> Path:
    return Path.home() / ".codex" / "config.toml"


def install_codex_plugin(
    *,
    install_root: Path | None = None,
    config_path: Path | None = None,
    base_url: str = DEFAULT_BASE_URL,
) -> CodexInstallPaths:
    paths = CodexInstallPaths(
        install_root=(install_root or default_install_root()).expanduser().resolve(),
        config_path=(config_path or default_codex_config_path()).expanduser().resolve(),
    )
    source_plugin = _source_plugin_dir()

    paths.plugin_dir.parent.mkdir(parents=True, exist_ok=True)
    if paths.plugin_dir.exists():
        shutil.rmtree(paths.plugin_dir)
    shutil.copytree(
        source_plugin,
        paths.plugin_dir,
        ignore=shutil.ignore_patterns("__pycache__", "*.pyc"),
    )
    _write_mcp_base_url(paths.mcp_config_path, base_url)
    _write_marketplace(paths.marketplace_path)
    _enable_codex_config(paths.config_path, paths.install_root)
    return paths


def uninstall_codex_plugin(
    *,
    install_root: Path | None = None,
    config_path: Path | None = None,
) -> CodexInstallPaths:
    paths = CodexInstallPaths(
        install_root=(install_root or default_install_root()).expanduser().resolve(),
        config_path=(config_path or default_codex_config_path()).expanduser().resolve(),
    )
    if paths.install_root.exists():
        shutil.rmtree(paths.install_root)
    if paths.config_path.exists():
        paths.config_path.write_text(
            _remove_codex_config_sections(paths.config_path.read_text(encoding="utf-8")),
            encoding="utf-8",
        )
    return paths


def codex_doctor(
    *,
    install_root: Path | None = None,
    config_path: Path | None = None,
) -> list[tuple[str, bool]]:
    paths = CodexInstallPaths(
        install_root=(install_root or default_install_root()).expanduser().resolve(),
        config_path=(config_path or default_codex_config_path()).expanduser().resolve(),
    )
    config_text = (
        paths.config_path.read_text(encoding="utf-8")
        if paths.config_path.exists()
        else ""
    )
    return [
        ("marketplace", paths.marketplace_path.exists()),
        ("plugin_manifest", paths.plugin_manifest_path.exists()),
        ("mcp_config", paths.mcp_config_path.exists()),
        ("codex_config", paths.config_path.exists()),
        ("marketplace_config", "[marketplaces.repostrata-local]" in config_text),
        ("plugin_enabled", '[plugins."repostrata@repostrata-local"]' in config_text),
    ]


def _source_plugin_dir() -> Path:
    packaged = resources.files("repostrata").joinpath(
        "codex_plugin",
        "plugins",
        PLUGIN_NAME,
    )
    if packaged.joinpath(".codex-plugin", "plugin.json").is_file():
        return Path(str(packaged))

    source = Path(__file__).resolve().parents[2] / "plugins" / PLUGIN_NAME
    if source.joinpath(".codex-plugin", "plugin.json").exists():
        return source

    raise FileNotFoundError("RepoStrata Codex plugin files were not found")


def _write_marketplace(path: Path) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(
        json.dumps(
            {
                "name": MARKETPLACE_NAME,
                "interface": {"displayName": "RepoStrata Local"},
                "plugins": [
                    {
                        "name": PLUGIN_NAME,
                        "source": {
                            "source": "local",
                            "path": f"./plugins/{PLUGIN_NAME}",
                        },
                        "policy": {
                            "installation": "AVAILABLE",
                            "authentication": "ON_INSTALL",
                        },
                        "category": "Coding",
                    }
                ],
            },
            indent=2,
        )
        + "\n",
        encoding="utf-8",
    )


def _write_mcp_base_url(path: Path, base_url: str) -> None:
    payload = json.loads(path.read_text(encoding="utf-8"))
    payload["mcpServers"][PLUGIN_NAME]["env"]["REPOSTRATA_BASE_URL"] = base_url
    path.write_text(json.dumps(payload, indent=2) + "\n", encoding="utf-8")


def _enable_codex_config(path: Path, install_root: Path) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    existing = path.read_text(encoding="utf-8") if path.exists() else ""
    cleaned = _remove_codex_config_sections(existing).rstrip()
    block = (
        f"[marketplaces.{MARKETPLACE_NAME}]\n"
        'source_type = "local"\n'
        f'source = "{install_root}"\n'
        "\n"
        f'[plugins."{PLUGIN_KEY}"]\n'
        "enabled = true\n"
    )
    text = f"{cleaned}\n\n{block}" if cleaned else block
    path.write_text(text, encoding="utf-8")


def _remove_codex_config_sections(text: str) -> str:
    section_headers = {
        f"[marketplaces.{MARKETPLACE_NAME}]",
        f'[plugins."{PLUGIN_KEY}"]',
    }
    kept: list[str] = []
    skipping = False
    for line in text.splitlines():
        stripped = line.strip()
        if stripped in section_headers:
            skipping = True
            continue
        if skipping and stripped.startswith("[") and stripped.endswith("]"):
            skipping = False
        if not skipping:
            kept.append(line)
    return "\n".join(kept).rstrip() + ("\n" if kept else "")
