from dataclasses import dataclass
from hashlib import sha1
from typing import Iterable

from tree_sitter import Node
from tree_sitter_language_pack import get_parser

from repostrata.models import RelationFact, SymbolFact


PROVENANCE = "extractor:tree-sitter"
_PYTHON_SCOPE_NODE_TYPES = {
    "class_definition",
    "decorated_definition",
    "function_definition",
}
_JS_SCOPE_NODE_TYPES = {
    "arrow_function",
    "class_declaration",
    "function_declaration",
    "function_expression",
    "generator_function",
    "generator_function_declaration",
    "method_definition",
    "method_signature",
}


@dataclass
class ExtractedFacts:
    symbols: list[SymbolFact]
    relations: list[RelationFact]


@dataclass
class _ExtractionState:
    symbols: list[SymbolFact]
    relations: list[RelationFact]
    symbol_counts: dict[tuple[str, str], int]
    seen_relation_ids: set[str]


def extract_facts(file_path: str, language: str, source: bytes) -> ExtractedFacts:
    parser = get_parser(language)
    tree = parser.parse(source)

    if language == "python":
        return _extract_python(file_path, language, source, tree.root_node)
    if language in {"javascript", "typescript", "tsx"}:
        return _extract_js_like(file_path, language, source, tree.root_node)

    return ExtractedFacts(symbols=[], relations=[])


def _extract_python(
    file_path: str, language: str, source: bytes, root: Node
) -> ExtractedFacts:
    state = _new_extraction_state()
    module_symbol = _make_symbol(
        state=state,
        node=root,
        kind="module",
        language=language,
        file_path=file_path,
        qualified_name=file_path,
        source=source,
    )

    for raw_node in _named_children(root):
        node = _definition_node(raw_node)
        if node.type in {"import_statement", "import_from_statement"}:
            import_text = _node_text(node, source).strip()
            if import_text and module_symbol is not None:
                _add_relation(
                    state,
                    kind="imports",
                    source_id=module_symbol.id,
                    target_id=f"unresolved:{import_text}",
                    file_path=file_path,
                    confidence=0.8,
                )
        elif node.type == "function_definition":
            symbol = _make_symbol(
                state=state,
                node=node,
                source_node=raw_node,
                kind="function",
                language=language,
                file_path=file_path,
                qualified_name=_name(node, source),
                source=source,
            )
            if symbol is not None:
                _add_call_relations(
                    state,
                    node,
                    symbol.id,
                    file_path,
                    source,
                    "call",
                    _PYTHON_SCOPE_NODE_TYPES,
                )
        elif node.type == "class_definition":
            class_name = _name(node, source)
            class_symbol = _make_symbol(
                state=state,
                node=node,
                source_node=raw_node,
                kind="class",
                language=language,
                file_path=file_path,
                qualified_name=class_name,
                source=source,
            )
            if class_symbol is None:
                continue

            body = node.child_by_field_name("body")
            for raw_child in _named_children(body):
                child = _definition_node(raw_child)
                if child.type != "function_definition":
                    continue
                method_name = _name(child, source)
                method_symbol = _make_symbol(
                    state=state,
                    node=child,
                    source_node=raw_child,
                    kind="method",
                    language=language,
                    file_path=file_path,
                    qualified_name=f"{class_name}.{method_name}",
                    source=source,
                )
                if method_symbol is None:
                    continue

                _add_relation(
                    state,
                    kind="contains",
                    source_id=class_symbol.id,
                    target_id=method_symbol.id,
                    file_path=file_path,
                    confidence=1.0,
                )
                _add_call_relations(
                    state,
                    child,
                    method_symbol.id,
                    file_path,
                    source,
                    "call",
                    _PYTHON_SCOPE_NODE_TYPES,
                )

    return ExtractedFacts(symbols=state.symbols, relations=state.relations)


def _extract_js_like(
    file_path: str, language: str, source: bytes, root: Node
) -> ExtractedFacts:
    state = _new_extraction_state()
    module_symbol = _make_symbol(
        state=state,
        node=root,
        kind="module",
        language=language,
        file_path=file_path,
        qualified_name=file_path,
        source=source,
    )

    for node in _walk(root):
        if node.type == "import_statement":
            import_text = _node_text(node, source).strip()
            if import_text and module_symbol is not None:
                _add_relation(
                    state,
                    kind="imports",
                    source_id=module_symbol.id,
                    target_id=f"unresolved:{import_text}",
                    file_path=file_path,
                    confidence=0.8,
                )
        elif node.type == "function_declaration":
            name = _name(node, source)
            symbol = _make_symbol(
                state=state,
                node=node,
                kind="function",
                language=language,
                file_path=file_path,
                qualified_name=name,
                source=source,
            )
            if symbol is not None:
                _add_call_relations(
                    state,
                    node,
                    symbol.id,
                    file_path,
                    source,
                    "call_expression",
                    _JS_SCOPE_NODE_TYPES,
                )
        elif node.type == "class_declaration":
            class_name = _name(node, source)
            class_symbol = _make_symbol(
                state=state,
                node=node,
                kind="class",
                language=language,
                file_path=file_path,
                qualified_name=class_name,
                source=source,
            )
            if class_symbol is None:
                continue

            body = node.child_by_field_name("body")
            for child in _named_children(body):
                if child.type not in {"method_definition", "method_signature"}:
                    continue
                method_name = _name(child, source)
                method_symbol = _make_symbol(
                    state=state,
                    node=child,
                    kind="method",
                    language=language,
                    file_path=file_path,
                    qualified_name=f"{class_name}.{method_name}",
                    source=source,
                )
                if method_symbol is None:
                    continue

                _add_relation(
                    state,
                    kind="contains",
                    source_id=class_symbol.id,
                    target_id=method_symbol.id,
                    file_path=file_path,
                    confidence=1.0,
                )
                _add_call_relations(
                    state,
                    child,
                    method_symbol.id,
                    file_path,
                    source,
                    "call_expression",
                    _JS_SCOPE_NODE_TYPES,
                )

    return ExtractedFacts(symbols=state.symbols, relations=state.relations)


def _make_symbol(
    *,
    state: _ExtractionState,
    node: Node,
    source_node: Node | None = None,
    kind: str,
    language: str,
    file_path: str,
    qualified_name: str,
    source: bytes,
) -> SymbolFact | None:
    if not qualified_name:
        return None

    source_node = source_node or node
    id_qualified_name = _id_qualified_name(state, kind, qualified_name)
    symbol = SymbolFact(
        id=_symbol_id(language, file_path, kind, id_qualified_name),
        kind=kind,
        language=language,
        file_path=file_path,
        qualified_name=qualified_name,
        name=qualified_name if kind == "module" else qualified_name.rsplit(".", 1)[-1],
        start_line=_line(source_node.start_point),
        end_line=_line(source_node.end_point),
        source_hash=_sha1_bytes(source[source_node.start_byte : source_node.end_byte]),
    )
    state.symbols.append(symbol)
    return symbol


def _add_call_relations(
    state: _ExtractionState,
    node: Node,
    source_id: str,
    file_path: str,
    source: bytes,
    call_node_type: str,
    scope_node_types: set[str],
) -> None:
    for call_node in _walk_scope(node, scope_node_types):
        if call_node.type != call_node_type:
            continue
        call_name = _call_name(call_node, source)
        if not call_name:
            continue
        _add_relation(
            state,
            kind="calls",
            source_id=source_id,
            target_id=f"unresolved:{call_name}",
            file_path=file_path,
            confidence=0.6,
        )


def _add_relation(
    state: _ExtractionState,
    *,
    kind: str,
    source_id: str,
    target_id: str,
    file_path: str,
    confidence: float,
) -> None:
    relation_id = _relation_id(kind, source_id, target_id, file_path)
    if relation_id in state.seen_relation_ids:
        return

    state.seen_relation_ids.add(relation_id)
    relation = RelationFact(
        id=relation_id,
        kind=kind,
        source_id=source_id,
        target_id=target_id,
        file_path=file_path,
        confidence=confidence,
        provenance=PROVENANCE,
    )
    state.relations.append(relation)


def _new_extraction_state() -> _ExtractionState:
    return _ExtractionState(
        symbols=[],
        relations=[],
        symbol_counts={},
        seen_relation_ids=set(),
    )


def _id_qualified_name(
    state: _ExtractionState, kind: str, qualified_name: str
) -> str:
    key = (kind, qualified_name)
    count = state.symbol_counts.get(key, 0) + 1
    state.symbol_counts[key] = count
    if count == 1:
        return qualified_name
    return f"{qualified_name}#{count}"


def _name(node: Node, source: bytes) -> str:
    name_node = node.child_by_field_name("name")
    if name_node is None:
        return ""
    return _node_text(name_node, source)


def _call_name(node: Node, source: bytes) -> str:
    function_node = node.child_by_field_name("function")
    if function_node is None:
        return ""
    return _reference_name(function_node, source)


def _reference_name(node: Node, source: bytes) -> str:
    if node.type in {"identifier", "property_identifier"}:
        return _node_text(node, source)

    attribute_node = node.child_by_field_name("attribute")
    if attribute_node is not None:
        object_node = node.child_by_field_name("object")
        if object_node is not None:
            object_name = _reference_name(object_node, source)
            attribute_name = _node_text(attribute_node, source)
            if object_name:
                return f"{object_name}.{attribute_name}"
            return attribute_name

    property_node = node.child_by_field_name("property")
    if property_node is not None:
        object_node = node.child_by_field_name("object")
        object_name = _reference_name(object_node, source) if object_node else ""
        property_name = _node_text(property_node, source)
        if object_name:
            return f"{object_name}.{property_name}"
        return property_name

    return _node_text(node, source)


def _definition_node(node: Node) -> Node:
    if node.type != "decorated_definition":
        return node
    return node.child_by_field_name("definition") or node


def _named_children(node: Node | None) -> Iterable[Node]:
    if node is None:
        return ()
    return node.named_children


def _walk(node: Node) -> Iterable[Node]:
    stack = [node]
    while stack:
        current = stack.pop()
        yield current
        stack.extend(reversed(current.named_children))


def _walk_scope(node: Node, scope_node_types: set[str]) -> Iterable[Node]:
    stack = list(reversed(node.named_children))
    while stack:
        current = stack.pop()
        if current.type in scope_node_types:
            continue
        yield current
        stack.extend(reversed(current.named_children))


def _node_text(node: Node, source: bytes) -> str:
    return source[node.start_byte : node.end_byte].decode("utf-8")


def _line(point: object) -> int:
    row = getattr(point, "row", None)
    if row is None:
        row = point[0]  # type: ignore[index]
    return int(row) + 1


def _symbol_id(language: str, file_path: str, kind: str, qualified_name: str) -> str:
    return _sha1_text(f"{language}:{file_path}:{kind}:{qualified_name}")


def _relation_id(kind: str, source_id: str, target_id: str, file_path: str) -> str:
    return _sha1_text(f"{kind}:{source_id}:{target_id}:{file_path}")


def _sha1_text(value: str) -> str:
    return sha1(value.encode("utf-8")).hexdigest()


def _sha1_bytes(value: bytes) -> str:
    return sha1(value).hexdigest()
