from pathlib import Path


EXTENSION_TO_LANGUAGE = {
    ".py": "python",
    ".js": "javascript",
    ".jsx": "javascript",
    ".ts": "typescript",
    ".tsx": "tsx",
}


def language_for_path(file_path: str) -> str | None:
    return EXTENSION_TO_LANGUAGE.get(Path(file_path).suffix)
