from contextlib import closing
from dataclasses import dataclass, field
import json
from pathlib import Path
from typing import Any

from repostrata.config import load_manifest
from repostrata.db.connection import connect
from repostrata.db.repository import GraphRepository
from repostrata.paths import paths_for


MAX_SEARCH_LIMIT = 100
MAX_GRAPH_LIMIT = 200
VALID_DIRECTIONS = {"incoming", "outgoing", "both"}


@dataclass(frozen=True)
class AgentToolResult:
    summary: str
    items: list[dict[str, Any]]
    evidence: list[dict[str, Any]] = field(default_factory=list)
    truncated: bool = False
    next_queries: list[dict[str, Any]] = field(default_factory=list)


class QueryService:
    def __init__(self, repo_root: Path) -> None:
        self.paths = paths_for(repo_root)

    def _load_manifest_or_default(self) -> dict[str, Any]:
        try:
            return load_manifest(self.paths.repo_root)
        except FileNotFoundError:
            return {
                "indexed_head": None,
                "indexed_commits": 0,
            }

    def _is_indexed(self, manifest: dict[str, Any]) -> bool:
        return self.paths.database_path.exists() and manifest["indexed_head"] is not None

    def _ensure_indexed(self) -> None:
        manifest = self._load_manifest_or_default()
        if not self._is_indexed(manifest):
            raise LookupError("RepoStrata graph database has not been indexed")

    def status(self) -> AgentToolResult:
        manifest = self._load_manifest_or_default()
        indexed = self._is_indexed(manifest)
        item: dict[str, Any] = {
            "repo_root": str(self.paths.repo_root),
            "indexed": indexed,
            "indexed_head": manifest["indexed_head"],
            "indexed_commits": manifest["indexed_commits"],
            "commit_count": 0,
            "symbol_count": 0,
            "relation_count": 0,
            "event_count": 0,
        }

        if indexed:
            with closing(connect(self.paths.database_path)) as conn:
                item.update(GraphRepository(conn).counts())

        state = "indexed" if indexed else "not indexed"
        return AgentToolResult(
            summary=f"RepoStrata repository is {state}.",
            items=[item],
        )

    def search_symbols(
        self,
        *,
        query: str,
        kind: str | None = None,
        language: str | None = None,
        path_prefix: str | None = None,
        limit: int = 20,
    ) -> AgentToolResult:
        cleaned_query = query.strip()
        if not cleaned_query:
            raise ValueError("query is required")
        if limit < 1:
            raise ValueError("limit must be at least 1")
        effective_limit = min(limit, MAX_SEARCH_LIMIT)
        self._ensure_indexed()

        with closing(connect(self.paths.database_path)) as conn:
            rows = GraphRepository(conn).search_symbols_filtered(
                cleaned_query,
                kind=kind,
                language=language,
                path_prefix=path_prefix,
                limit=effective_limit + 1,
            )

        items = [_symbol_item(row) for row in rows[:effective_limit]]
        truncated = len(rows) > effective_limit
        next_queries = []
        if truncated:
            next_queries.append(
                {
                    "tool": "repostrata_search_symbols",
                    "query": cleaned_query,
                    "kind": kind,
                    "language": language,
                    "path_prefix": path_prefix,
                    "limit": effective_limit,
                }
            )

        return AgentToolResult(
            summary=f"Found {len(items)} symbol match(es).",
            items=items,
            evidence=[
                _symbol_evidence(item)
                for item in items
            ],
            truncated=truncated,
            next_queries=next_queries,
        )

    def get_symbol(
        self,
        *,
        symbol_id: str | None = None,
        qualified_name: str | None = None,
        commit: str | None = None,
    ) -> AgentToolResult:
        if (symbol_id is None) == (qualified_name is None):
            raise ValueError("exactly one of symbol_id or qualified_name is required")
        self._ensure_indexed()
        commit_hash = self._resolve_commit(commit)

        with closing(connect(self.paths.database_path)) as conn:
            repository = GraphRepository(conn)
            rows = repository.find_symbols(
                symbol_id=symbol_id,
                qualified_name=qualified_name,
            )
            if not rows:
                raise LookupError("symbol not found")
            items = []
            for row in rows:
                item = _symbol_item(row)
                item["present_at_commit"] = repository.symbol_present_at_commit(
                    item["symbol_id"],
                    commit_hash,
                )
                items.append(item)

        ambiguous = qualified_name is not None and len(items) > 1
        summary = (
            f"Found multiple symbols named {qualified_name!r}; use symbol_id to disambiguate."
            if ambiguous
            else f"Found symbol {items[0]['qualified_name']}."
        )
        return AgentToolResult(
            summary=summary,
            items=items,
            evidence=[
                {**_symbol_evidence(item), "commit_hash": commit_hash}
                for item in items
            ],
            next_queries=[
                {
                    "tool": "repostrata_get_symbol",
                    "arguments": {
                        "symbol_id": item["symbol_id"],
                        "commit": commit_hash,
                    },
                    "reason": f"Disambiguate {item['qualified_name']} in {item['file_path']}.",
                }
                for item in items
            ]
            if ambiguous
            else [],
        )

    def get_symbol_neighborhood(
        self,
        *,
        symbol_id: str,
        commit: str | None = None,
        depth: int = 1,
        relation_kinds: list[str] | None = None,
        direction: str = "both",
        limit: int = 50,
    ) -> AgentToolResult:
        if depth not in {1, 2}:
            raise ValueError("depth must be 1 or 2")
        if direction not in VALID_DIRECTIONS:
            raise ValueError("direction must be incoming, outgoing, or both")
        effective_limit = self._bounded_limit(limit, MAX_GRAPH_LIMIT)
        self._ensure_indexed()
        commit_hash = self._resolve_commit(commit)

        with closing(connect(self.paths.database_path)) as conn:
            repository = GraphRepository(conn)
            if not repository.find_symbols(symbol_id=symbol_id):
                raise LookupError("symbol not found")
            if not repository.symbol_present_at_commit(symbol_id, commit_hash):
                item = {
                    "center_symbol_id": symbol_id,
                    "nodes": [],
                    "edges": [],
                }
                return AgentToolResult(
                    summary=f"Symbol is not present at commit {commit_hash}.",
                    items=[item],
                )

            rows, truncated = _collect_neighborhood_relations(
                repository=repository,
                center_symbol_id=symbol_id,
                commit_hash=commit_hash,
                relation_kinds=relation_kinds,
                direction=direction,
                depth=depth,
                limit=effective_limit,
            )
            edges = [_edge_item(row) for row in rows]
            node_ids = sorted(
                {
                    symbol_id,
                    *(edge["source_id"] for edge in edges),
                    *(edge["target_id"] for edge in edges),
                }
            )
            nodes = [
                _neighborhood_node(row)
                for row in repository.symbols_by_ids(node_ids)
            ]

        item = {
            "center_symbol_id": symbol_id,
            "nodes": nodes,
            "edges": edges,
        }
        return AgentToolResult(
            summary=f"Found {len(nodes)} nodes and {len(edges)} edges near the symbol.",
            items=[item],
            evidence=[
                {
                    "kind": "relation",
                    "id": edge["relation_id"],
                    "label": edge["kind"],
                    "commit_hash": commit_hash,
                }
                for edge in edges
            ],
            truncated=truncated,
            next_queries=[
                {
                    "tool": "repostrata_get_symbol_neighborhood",
                    "arguments": {
                        "symbol_id": symbol_id,
                        "commit": commit_hash,
                        "depth": depth,
                        "direction": direction,
                        "relation_kinds": relation_kinds,
                        "limit": effective_limit,
                    },
                    "reason": "The neighborhood was truncated; narrow direction or relation_kinds.",
                }
            ]
            if truncated
            else [],
        )

    def get_symbol_history(
        self,
        *,
        symbol_id: str,
        since: str | None = None,
        until: str | None = None,
        event_types: list[str] | None = None,
        limit: int = 50,
    ) -> AgentToolResult:
        effective_limit = self._bounded_limit(limit, MAX_GRAPH_LIMIT)
        self._ensure_indexed()

        with closing(connect(self.paths.database_path)) as conn:
            repository = GraphRepository(conn)
            if not repository.find_symbols(symbol_id=symbol_id):
                raise LookupError("symbol not found")
            rows = repository.events_for_symbol(
                symbol_id=symbol_id,
                since=since,
                until=until,
                event_types=event_types,
                limit=effective_limit + 1,
            )

        truncated = len(rows) > effective_limit
        items = [_event_item(row) for row in rows[:effective_limit]]
        return AgentToolResult(
            summary=f"Found {len(items)} events for the symbol.",
            items=items,
            evidence=[
                {
                    "kind": "event",
                    "id": item["event_id"],
                    "label": item["event_type"],
                    "commit_hash": item["commit_hash"],
                }
                for item in items
            ],
            truncated=truncated,
            next_queries=[
                {
                    "tool": "repostrata_get_symbol_history",
                    "arguments": {
                        "symbol_id": symbol_id,
                        "since": since,
                        "until": until,
                        "event_types": event_types,
                        "limit": effective_limit,
                    },
                    "reason": "The history was truncated; narrow since, until, or event_types.",
                }
            ]
            if truncated
            else [],
        )

    def _resolve_commit(self, commit: str | None) -> str:
        manifest = load_manifest(self.paths.repo_root)
        commit_hash = commit or manifest.get("indexed_head")
        if not commit_hash:
            raise LookupError("RepoStrata has no indexed_head; run repostrata index")

        with closing(connect(self.paths.database_path)) as conn:
            if not GraphRepository(conn).commit_exists(commit_hash):
                raise LookupError(f"commit is not indexed: {commit_hash}")
        return str(commit_hash)

    @staticmethod
    def _bounded_limit(limit: int, maximum: int) -> int:
        if limit < 1:
            raise ValueError("limit must be at least 1")
        return min(limit, maximum)


def _symbol_item(row: dict[str, Any]) -> dict[str, Any]:
    return {
        "symbol_id": row["id"],
        "kind": row["kind"],
        "language": row["language"],
        "file_path": row["file_path"],
        "qualified_name": row["qualified_name"],
        "name": row["name"],
        "start_line": row["start_line"],
        "end_line": row["end_line"],
    }


def _symbol_evidence(item: dict[str, Any]) -> dict[str, Any]:
    return {
        "kind": "symbol",
        "id": item["symbol_id"],
        "label": item["qualified_name"],
        "file_path": item["file_path"],
        "start_line": item["start_line"],
        "end_line": item["end_line"],
    }


def _collect_neighborhood_relations(
    *,
    repository: GraphRepository,
    center_symbol_id: str,
    commit_hash: str,
    relation_kinds: list[str] | None,
    direction: str,
    depth: int,
    limit: int,
) -> tuple[list[dict[str, Any]], bool]:
    edge_rows_by_id: dict[str, dict[str, Any]] = {}
    expanded: set[str] = set()
    frontier = {center_symbol_id}
    truncated = False

    for _ in range(depth):
        next_frontier: set[str] = set()
        for current_symbol_id in sorted(frontier):
            expanded.add(current_symbol_id)
            remaining = limit + 1 - len(edge_rows_by_id)
            if remaining <= 0:
                truncated = True
                break

            rows = repository.snapshot_relations_for_symbol(
                symbol_id=current_symbol_id,
                commit_hash=commit_hash,
                relation_kinds=relation_kinds,
                direction=direction,
                limit=remaining,
            )
            for row in rows:
                edge_rows_by_id.setdefault(row["id"], row)
                next_frontier.update(
                    _neighbor_symbol_ids(current_symbol_id, row, direction)
                )

            if len(edge_rows_by_id) > limit:
                truncated = True
                break

        if truncated:
            break
        frontier = next_frontier - expanded
        if not frontier:
            break

    return list(edge_rows_by_id.values())[:limit], truncated


def _neighbor_symbol_ids(
    current_symbol_id: str,
    edge: dict[str, Any],
    direction: str,
) -> set[str]:
    if direction == "incoming":
        return {edge["source_id"]}
    if direction == "outgoing":
        return {edge["target_id"]}
    return {
        symbol_id
        for symbol_id in (edge["source_id"], edge["target_id"])
        if symbol_id != current_symbol_id
    }


def _neighborhood_node(row: dict[str, Any]) -> dict[str, Any]:
    return {
        "symbol_id": row["id"],
        "kind": row["kind"],
        "qualified_name": row["qualified_name"],
        "file_path": row["file_path"],
    }


def _edge_item(row: dict[str, Any]) -> dict[str, Any]:
    return {
        "relation_id": row["id"],
        "kind": row["kind"],
        "source_id": row["source_id"],
        "target_id": row["target_id"],
        "confidence": row["confidence"],
    }


def _event_item(row: dict[str, Any]) -> dict[str, Any]:
    return {
        "event_id": row["id"],
        "commit_hash": row["commit_hash"],
        "authored_at": row["authored_at"],
        "author_name": row["author_name"],
        "message": row["message"],
        "event_type": row["event_type"],
        "subject_id": row["subject_id"],
        "payload": json.loads(row["payload_json"]),
    }
