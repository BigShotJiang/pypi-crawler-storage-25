from dataclasses import dataclass
from pathlib import Path


@dataclass(frozen=True)
class RepoStrataPaths:
    root: Path
    data_dir: Path
    config_path: Path
    manifest_path: Path
    database_path: Path
    cache_dir: Path
    runs_dir: Path
    locks_dir: Path

    @property
    def repo_root(self) -> Path:
        return self.root


def paths_for(repo_root: Path) -> RepoStrataPaths:
    root = repo_root.resolve()
    data_dir = root / ".repostrata"

    return RepoStrataPaths(
        root=root,
        data_dir=data_dir,
        config_path=data_dir / "config.toml",
        manifest_path=data_dir / "manifest.json",
        database_path=data_dir / "graph.db",
        cache_dir=data_dir / "cache",
        runs_dir=data_dir / "runs",
        locks_dir=data_dir / "locks",
    )
