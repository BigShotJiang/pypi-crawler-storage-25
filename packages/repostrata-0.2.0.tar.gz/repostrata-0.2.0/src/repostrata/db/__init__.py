"""SQLite persistence for RepoStrata."""
