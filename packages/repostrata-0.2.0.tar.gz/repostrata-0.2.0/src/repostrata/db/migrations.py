import sqlite3
from importlib.resources import files


CURRENT_SCHEMA_VERSION = 1


def _schema_version_table_exists(conn: sqlite3.Connection) -> bool:
    row = conn.execute(
        """
        select 1
        from sqlite_master
        where type = 'table' and name = 'schema_version'
        """
    ).fetchone()
    return row is not None


def _existing_schema_version(conn: sqlite3.Connection) -> int | None:
    if not _schema_version_table_exists(conn):
        return None
    row = conn.execute("select max(version) from schema_version").fetchone()
    return row[0] if row is not None else None


def migrate(conn: sqlite3.Connection) -> None:
    existing_version = _existing_schema_version(conn)
    if existing_version is not None and existing_version > CURRENT_SCHEMA_VERSION:
        raise RuntimeError(
            f"Database has newer schema version {existing_version}; "
            f"current code supports {CURRENT_SCHEMA_VERSION}."
        )

    schema = files("repostrata.db").joinpath("schema.sql").read_text(encoding="utf-8")
    conn.executescript(schema)
    conn.execute(
        "insert or ignore into schema_version(version) values (?)",
        (CURRENT_SCHEMA_VERSION,),
    )
    conn.commit()
