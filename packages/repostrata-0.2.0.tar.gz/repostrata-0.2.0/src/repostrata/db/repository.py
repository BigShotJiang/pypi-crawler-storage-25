import json
import sqlite3

from repostrata.models import (
    CommitRecord,
    GraphEvent,
    RelationFact,
    SnapshotRecord,
    SymbolFact,
)


def _escape_like(value: str) -> str:
    return (
        value.replace("\\", "\\\\")
        .replace("%", "\\%")
        .replace("_", "\\_")
    )


class GraphRepository:
    def __init__(self, conn: sqlite3.Connection) -> None:
        self.conn = conn

    def commit(self) -> None:
        self.conn.commit()

    def clear_indexed_graph(self) -> None:
        for table in (
            "snapshot_edges",
            "snapshot_nodes",
            "snapshots",
            "cochange_edges",
            "events",
            "relations",
            "symbols",
            "commits",
        ):
            self.conn.execute(f"delete from {table}")

    def insert_index_run(
        self,
        run_id: str,
        started_at: str,
        completed_at: str,
        status: str,
        message: str,
    ) -> None:
        self.conn.execute(
            """
            insert into index_runs(id, started_at, completed_at, status, message)
            values (?, ?, ?, ?, ?)
            """,
            (run_id, started_at, completed_at, status, message),
        )

    def list_commits(self) -> list[dict]:
        rows = self.conn.execute(
            """
            select hash, authored_at, author_name, message
            from commits
            order by rowid asc
            """
        ).fetchall()
        return [dict(row) for row in rows]

    def search_symbols(self, query: str) -> list[dict]:
        escaped_query = _escape_like(query)
        rows = self.conn.execute(
            """
            select id, kind, language, file_path, qualified_name, name,
                   start_line, end_line
            from symbols
            where qualified_name like ? escape '\\'
            order by qualified_name asc
            limit 50
            """,
            (f"%{escaped_query}%",),
        ).fetchall()
        return [dict(row) for row in rows]

    def counts(self) -> dict[str, int]:
        return {
            "commit_count": self.conn.execute("select count(*) from commits").fetchone()[0],
            "symbol_count": self.conn.execute("select count(*) from symbols").fetchone()[0],
            "relation_count": self.conn.execute("select count(*) from relations").fetchone()[0],
            "event_count": self.conn.execute("select count(*) from events").fetchone()[0],
        }

    def search_symbols_filtered(
        self,
        query: str,
        *,
        kind: str | None = None,
        language: str | None = None,
        path_prefix: str | None = None,
        limit: int = 20,
    ) -> list[dict]:
        escaped_query = _escape_like(query)
        where = ["qualified_name like ? escape '\\'"]
        params: list[object] = [f"%{escaped_query}%"]
        if kind is not None:
            where.append("kind = ?")
            params.append(kind)
        if language is not None:
            where.append("language = ?")
            params.append(language)
        if path_prefix is not None:
            where.append("file_path like ? escape '\\'")
            params.append(f"{_escape_like(path_prefix)}%")
        params.append(limit)
        rows = self.conn.execute(
            f"""
            select id, kind, language, file_path, qualified_name, name,
                   start_line, end_line
            from symbols
            where {" and ".join(where)}
            order by qualified_name asc, id asc
            limit ?
            """,
            params,
        ).fetchall()
        return [dict(row) for row in rows]

    def find_symbols(
        self,
        *,
        symbol_id: str | None = None,
        qualified_name: str | None = None,
    ) -> list[dict]:
        where = []
        params: list[object] = []
        if symbol_id is not None:
            where.append("id = ?")
            params.append(symbol_id)
        if qualified_name is not None:
            where.append("(qualified_name = ? or name = ?)")
            params.extend([qualified_name, qualified_name])
        if not where:
            return []

        rows = self.conn.execute(
            f"""
            select id, kind, language, file_path, qualified_name, name,
                   start_line, end_line
            from symbols
            where {" and ".join(where)}
            order by qualified_name asc, file_path asc, id asc
            """,
            params,
        ).fetchall()
        return [dict(row) for row in rows]

    def symbol_present_at_commit(self, symbol_id: str, commit_hash: str) -> bool:
        row = self.conn.execute(
            """
            select 1
            from snapshots
            join snapshot_nodes on snapshot_nodes.snapshot_id = snapshots.id
            where snapshots.commit_hash = ?
              and snapshot_nodes.symbol_id = ?
            limit 1
            """,
            (commit_hash, symbol_id),
        ).fetchone()
        return row is not None

    def commit_exists(self, commit_hash: str) -> bool:
        row = self.conn.execute(
            "select 1 from commits where hash = ? limit 1",
            (commit_hash,),
        ).fetchone()
        return row is not None

    def snapshot_relations_for_symbol(
        self,
        *,
        symbol_id: str,
        commit_hash: str,
        relation_kinds: list[str] | None,
        direction: str,
        limit: int,
    ) -> list[dict]:
        conditions = ["snapshots.commit_hash = ?"]
        params: list[object] = [commit_hash]
        if direction == "incoming":
            conditions.append("relations.target_id = ?")
            params.append(symbol_id)
        elif direction == "outgoing":
            conditions.append("relations.source_id = ?")
            params.append(symbol_id)
        else:
            conditions.append("(relations.source_id = ? or relations.target_id = ?)")
            params.extend([symbol_id, symbol_id])
        if relation_kinds:
            placeholders = ", ".join("?" for _ in relation_kinds)
            conditions.append(f"relations.kind in ({placeholders})")
            params.extend(relation_kinds)
        params.append(limit)

        rows = self.conn.execute(
            f"""
            select relations.id, relations.kind, relations.source_id,
                   relations.target_id, relations.confidence
            from snapshots
            join snapshot_edges on snapshot_edges.snapshot_id = snapshots.id
            join relations on relations.id = snapshot_edges.relation_id
            where {" and ".join(conditions)}
            order by relations.kind asc, relations.id asc
            limit ?
            """,
            params,
        ).fetchall()
        return [dict(row) for row in rows]

    def symbols_by_ids(self, symbol_ids: list[str]) -> list[dict]:
        if not symbol_ids:
            return []
        placeholders = ", ".join("?" for _ in symbol_ids)
        rows = self.conn.execute(
            f"""
            select id, kind, language, file_path, qualified_name, name,
                   start_line, end_line
            from symbols
            where id in ({placeholders})
            order by qualified_name asc, id asc
            """,
            symbol_ids,
        ).fetchall()
        return [dict(row) for row in rows]

    def events_for_symbol(
        self,
        *,
        symbol_id: str,
        since: str | None,
        until: str | None,
        event_types: list[str] | None,
        limit: int,
    ) -> list[dict]:
        conditions = ["events.subject_id = ?"]
        params: list[object] = [symbol_id]
        if since is not None:
            if self.commit_exists(since):
                conditions.append(
                    "commits.rowid >= (select rowid from commits where hash = ?)"
                )
                params.append(since)
            else:
                conditions.append("commits.authored_at >= ?")
                params.append(since)
        if until is not None:
            if self.commit_exists(until):
                conditions.append(
                    "commits.rowid <= (select rowid from commits where hash = ?)"
                )
                params.append(until)
            else:
                conditions.append("commits.authored_at <= ?")
                params.append(until)
        if event_types:
            placeholders = ", ".join("?" for _ in event_types)
            conditions.append(f"events.event_type in ({placeholders})")
            params.extend(event_types)
        params.append(limit)

        rows = self.conn.execute(
            f"""
            select events.id, events.commit_hash, commits.authored_at,
                   commits.author_name, commits.message, events.event_type,
                   events.subject_id, events.payload_json
            from events
            join commits on commits.hash = events.commit_hash
            where {" and ".join(conditions)}
            order by commits.rowid desc, events.id asc
            limit ?
            """,
            params,
        ).fetchall()
        return [dict(row) for row in rows]

    def snapshot_for_commit(self, commit_hash: str) -> dict[str, list[dict]] | None:
        snapshot = self.conn.execute(
            """
            select id from snapshots
            where commit_hash = ?
            order by time_ref asc, id asc
            limit 1
            """,
            (commit_hash,),
        ).fetchone()
        if snapshot is None:
            return None

        nodes = self.conn.execute(
            """
            select symbols.id, symbols.kind, symbols.language, symbols.file_path,
                   symbols.qualified_name, symbols.name
            from snapshot_nodes
            join symbols on symbols.id = snapshot_nodes.symbol_id
            where snapshot_nodes.snapshot_id = ?
            order by symbols.qualified_name asc, symbols.id asc
            """,
            (snapshot["id"],),
        ).fetchall()
        edges = self.conn.execute(
            """
            select relations.id, relations.kind, relations.source_id,
                   relations.target_id, relations.confidence
            from snapshot_edges
            join relations on relations.id = snapshot_edges.relation_id
            where snapshot_edges.snapshot_id = ?
            order by relations.kind asc, relations.id asc
            """,
            (snapshot["id"],),
        ).fetchall()

        return {
            "nodes": [dict(row) for row in nodes],
            "edges": [dict(row) for row in edges],
        }

    def upsert_commit(self, commit: CommitRecord) -> None:
        self.conn.execute(
            """
            insert into commits(
              hash, parents_json, author_name, author_email,
              authored_at, message, changed_files_json
            )
            values (?, ?, ?, ?, ?, ?, ?)
            on conflict(hash) do update set
              parents_json = excluded.parents_json,
              author_name = excluded.author_name,
              author_email = excluded.author_email,
              authored_at = excluded.authored_at,
              message = excluded.message,
              changed_files_json = excluded.changed_files_json
            """,
            (
                commit.hash,
                json.dumps(commit.parents),
                commit.author_name,
                commit.author_email,
                commit.authored_at,
                commit.message,
                json.dumps(commit.changed_files),
            ),
        )

    def upsert_symbol(self, symbol: SymbolFact) -> None:
        self.conn.execute(
            """
            insert into symbols(
              id, kind, language, file_path, qualified_name, name,
              start_line, end_line, source_hash
            )
            values (?, ?, ?, ?, ?, ?, ?, ?, ?)
            on conflict(id) do update set
              kind = excluded.kind,
              language = excluded.language,
              file_path = excluded.file_path,
              qualified_name = excluded.qualified_name,
              name = excluded.name,
              start_line = excluded.start_line,
              end_line = excluded.end_line,
              source_hash = excluded.source_hash
            """,
            (
                symbol.id,
                symbol.kind,
                symbol.language,
                symbol.file_path,
                symbol.qualified_name,
                symbol.name,
                symbol.start_line,
                symbol.end_line,
                symbol.source_hash,
            ),
        )

    def upsert_relation(self, relation: RelationFact) -> None:
        self.conn.execute(
            """
            insert into relations(
              id, kind, source_id, target_id, file_path, confidence, provenance
            )
            values (?, ?, ?, ?, ?, ?, ?)
            on conflict(id) do update set
              kind = excluded.kind,
              source_id = excluded.source_id,
              target_id = excluded.target_id,
              file_path = excluded.file_path,
              confidence = excluded.confidence,
              provenance = excluded.provenance
            """,
            (
                relation.id,
                relation.kind,
                relation.source_id,
                relation.target_id,
                relation.file_path,
                relation.confidence,
                relation.provenance,
            ),
        )

    def insert_event(self, event: GraphEvent) -> None:
        self.conn.execute(
            """
            insert or ignore into events(
              id, commit_hash, event_type, subject_id, payload_json
            )
            values (?, ?, ?, ?, ?)
            """,
            (
                event.id,
                event.commit_hash,
                event.event_type,
                event.subject_id,
                event.payload_json,
            ),
        )

    def upsert_cochange(
        self,
        source_id: str,
        target_id: str,
        commit_hash: str,
    ) -> None:
        self.conn.execute(
            """
            insert into cochange_edges(
              source_id, target_id, weight, last_commit_hash
            )
            values (?, ?, 1.0, ?)
            on conflict(source_id, target_id) do update set
              weight = cochange_edges.weight + 1.0,
              last_commit_hash = excluded.last_commit_hash
            """,
            (source_id, target_id, commit_hash),
        )

    def upsert_snapshot(
        self,
        snapshot: SnapshotRecord,
        symbol_ids: list[str],
        relation_ids: list[str],
    ) -> None:
        self.conn.execute(
            """
            insert into snapshots(id, time_ref, commit_hash, label)
            values (?, ?, ?, ?)
            on conflict(id) do update set
              time_ref = excluded.time_ref,
              commit_hash = excluded.commit_hash,
              label = excluded.label
            """,
            (
                snapshot.id,
                snapshot.time_ref,
                snapshot.commit_hash,
                snapshot.label,
            ),
        )
        self.conn.execute(
            "delete from snapshot_nodes where snapshot_id = ?",
            (snapshot.id,),
        )
        self.conn.execute(
            "delete from snapshot_edges where snapshot_id = ?",
            (snapshot.id,),
        )
        self.conn.executemany(
            "insert into snapshot_nodes(snapshot_id, symbol_id) values (?, ?)",
            [(snapshot.id, symbol_id) for symbol_id in symbol_ids],
        )
        self.conn.executemany(
            "insert into snapshot_edges(snapshot_id, relation_id) values (?, ?)",
            [(snapshot.id, relation_id) for relation_id in relation_ids],
        )
