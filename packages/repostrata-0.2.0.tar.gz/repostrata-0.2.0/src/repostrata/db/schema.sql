create table if not exists schema_version (
  version integer primary key
);

create table if not exists commits (
  hash text primary key,
  parents_json text not null,
  author_name text not null,
  author_email text not null,
  authored_at text not null,
  message text not null,
  changed_files_json text not null
);

create table if not exists files (
  path text primary key,
  language text not null
);

create table if not exists symbols (
  id text primary key,
  kind text not null,
  language text not null,
  file_path text not null,
  qualified_name text not null,
  name text not null,
  start_line integer not null,
  end_line integer not null,
  source_hash text not null
);

create table if not exists relations (
  id text primary key,
  kind text not null,
  source_id text not null,
  target_id text not null,
  file_path text not null,
  confidence real not null,
  provenance text not null
);

create table if not exists events (
  id text primary key,
  commit_hash text not null,
  event_type text not null,
  subject_id text not null,
  payload_json text not null,
  foreign key (commit_hash) references commits(hash) on delete cascade
);

create table if not exists snapshots (
  id text primary key,
  time_ref text not null,
  commit_hash text not null,
  label text not null,
  foreign key (commit_hash) references commits(hash) on delete cascade
);

create table if not exists snapshot_nodes (
  snapshot_id text not null,
  symbol_id text not null,
  primary key (snapshot_id, symbol_id),
  foreign key (snapshot_id) references snapshots(id) on delete cascade,
  foreign key (symbol_id) references symbols(id) on delete cascade
);

create table if not exists snapshot_edges (
  snapshot_id text not null,
  relation_id text not null,
  primary key (snapshot_id, relation_id),
  foreign key (snapshot_id) references snapshots(id) on delete cascade,
  foreign key (relation_id) references relations(id) on delete cascade
);

create table if not exists cochange_edges (
  source_id text not null,
  target_id text not null,
  weight real not null,
  last_commit_hash text not null,
  primary key (source_id, target_id),
  foreign key (source_id) references symbols(id) on delete cascade,
  foreign key (target_id) references symbols(id) on delete cascade
);

create table if not exists index_runs (
  id text primary key,
  started_at text not null,
  completed_at text,
  status text not null,
  message text not null
);

create index if not exists idx_symbols_file_path on symbols(file_path);
create index if not exists idx_symbols_qualified_name on symbols(qualified_name);
create index if not exists idx_relations_source on relations(source_id);
create index if not exists idx_relations_target on relations(target_id);
create index if not exists idx_events_commit on events(commit_hash);
