from pydantic import BaseModel, Field


class CommitRecord(BaseModel):
    hash: str
    parents: list[str]
    author_name: str
    author_email: str
    authored_at: str
    message: str
    changed_files: list[str]


class SymbolFact(BaseModel):
    id: str
    kind: str
    language: str
    file_path: str
    qualified_name: str
    name: str
    start_line: int
    end_line: int
    source_hash: str


class RelationFact(BaseModel):
    id: str
    kind: str
    source_id: str
    target_id: str
    file_path: str
    confidence: float = Field(ge=0.0, le=1.0)
    provenance: str


class GraphEvent(BaseModel):
    id: str
    commit_hash: str
    event_type: str
    subject_id: str
    payload_json: str


class SnapshotRecord(BaseModel):
    id: str
    time_ref: str
    commit_hash: str
    label: str
