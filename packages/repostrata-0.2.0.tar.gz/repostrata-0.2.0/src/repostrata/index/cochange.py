from itertools import combinations

from repostrata.models import SymbolFact


def cochange_pairs(symbols: list[SymbolFact]) -> list[tuple[str, str]]:
    symbol_ids = sorted({symbol.id for symbol in symbols})
    return list(combinations(symbol_ids, 2))
