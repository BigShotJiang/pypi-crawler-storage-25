"""Fact indexing and temporal graph event generation."""
