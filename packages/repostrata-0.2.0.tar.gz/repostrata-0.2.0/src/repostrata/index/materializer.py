from hashlib import sha1

from repostrata.models import RelationFact, SnapshotRecord, SymbolFact


def snapshot_id(kind: str, time_ref: str) -> str:
    return sha1(f"{kind}:{time_ref}".encode("utf-8")).hexdigest()


def make_commit_snapshot(commit_hash: str, label: str) -> SnapshotRecord:
    return SnapshotRecord(
        id=snapshot_id("commit", commit_hash),
        time_ref=commit_hash,
        commit_hash=commit_hash,
        label=label,
    )


def snapshot_payload(
    symbols: list[SymbolFact],
    relations: list[RelationFact],
) -> tuple[list[str], list[str]]:
    return (
        [symbol.id for symbol in symbols],
        [relation.id for relation in relations],
    )
