from __future__ import annotations

from collections import defaultdict
from collections.abc import Iterable
from dataclasses import dataclass
from hashlib import sha1
import re
from pathlib import PurePosixPath

from repostrata.models import RelationFact, SymbolFact


BINDER_PROVENANCE = "binder:cross-file"
_UNRESOLVED_PREFIX = "unresolved:"
_SOURCE_EXTENSIONS = (".py", ".ts", ".tsx", ".js", ".jsx")


@dataclass(frozen=True)
class _ImportBinding:
    alias: str
    target_name: str | None
    module_specifier: str


@dataclass
class _SymbolIndex:
    by_id: dict[str, SymbolFact]
    by_file_name: dict[tuple[str, str], list[SymbolFact]]
    by_name: dict[str, list[SymbolFact]]
    module_by_file: dict[str, SymbolFact]
    file_paths: set[str]


def bind_relations(
    symbols: Iterable[SymbolFact],
    relations: Iterable[RelationFact],
) -> list[RelationFact]:
    symbol_list = list(symbols)
    relation_list = list(relations)
    index = _build_symbol_index(symbol_list)
    imported_symbols = _imported_symbol_aliases(relation_list, index)

    bound_relations: list[RelationFact] = []
    seen_ids: set[str] = set()
    for relation in relation_list:
        bound_relation = _bind_relation(relation, index, imported_symbols)
        if bound_relation.id in seen_ids:
            continue
        seen_ids.add(bound_relation.id)
        bound_relations.append(bound_relation)

    return bound_relations


def _build_symbol_index(symbols: list[SymbolFact]) -> _SymbolIndex:
    by_file_name: dict[tuple[str, str], list[SymbolFact]] = defaultdict(list)
    by_name: dict[str, list[SymbolFact]] = defaultdict(list)
    module_by_file: dict[str, SymbolFact] = {}

    for symbol in symbols:
        by_file_name[(symbol.file_path, symbol.name)].append(symbol)
        by_file_name[(symbol.file_path, symbol.qualified_name)].append(symbol)
        by_name[symbol.name].append(symbol)
        by_name[symbol.qualified_name].append(symbol)
        if symbol.kind == "module":
            module_by_file[symbol.file_path] = symbol

    return _SymbolIndex(
        by_id={symbol.id: symbol for symbol in symbols},
        by_file_name=dict(by_file_name),
        by_name=dict(by_name),
        module_by_file=module_by_file,
        file_paths={symbol.file_path for symbol in symbols},
    )


def _imported_symbol_aliases(
    relations: list[RelationFact],
    index: _SymbolIndex,
) -> dict[str, dict[str, str]]:
    aliases_by_file: dict[str, dict[str, str]] = defaultdict(dict)

    for relation in relations:
        if relation.kind != "imports":
            continue
        import_text = _unresolved_value(relation.target_id)
        if import_text is None:
            continue

        for binding in _parse_import_bindings(import_text):
            module_file = _resolve_module_file(
                binding.module_specifier,
                relation.file_path,
                index.file_paths,
            )
            if module_file is None:
                continue

            target_id = _resolve_import_target(module_file, binding, index)
            if target_id is not None:
                aliases_by_file[relation.file_path][binding.alias] = target_id

    return {file_path: dict(aliases) for file_path, aliases in aliases_by_file.items()}


def _bind_relation(
    relation: RelationFact,
    index: _SymbolIndex,
    imported_symbols: dict[str, dict[str, str]],
) -> RelationFact:
    unresolved_value = _unresolved_value(relation.target_id)
    if unresolved_value is None:
        return relation

    if relation.kind == "imports":
        target_id = _resolve_import_relation_target(relation, unresolved_value, index)
        if target_id is None:
            return relation
        return _with_target(relation, target_id, confidence=0.95)

    if relation.kind != "calls":
        return relation

    source_symbol = index.by_id.get(relation.source_id)
    if source_symbol is None:
        return relation

    target_id = _resolve_call_target(
        source_symbol,
        unresolved_value,
        index,
        imported_symbols,
    )
    if target_id is None:
        return relation

    return _with_target(relation, target_id, confidence=0.9)


def _resolve_call_target(
    source_symbol: SymbolFact,
    reference: str,
    index: _SymbolIndex,
    imported_symbols: dict[str, dict[str, str]],
) -> str | None:
    aliases = imported_symbols.get(source_symbol.file_path, {})
    if reference in aliases:
        return aliases[reference]

    if "." in reference:
        head, tail = reference.split(".", 1)
        imported_module_id = aliases.get(head)
        imported_module = index.by_id.get(imported_module_id) if imported_module_id else None
        if imported_module is not None and imported_module.kind == "module":
            symbol = _single(index.by_file_name.get((imported_module.file_path, tail), []))
            if symbol is not None:
                return symbol.id

    local_symbol = _single(index.by_file_name.get((source_symbol.file_path, reference), []))
    if local_symbol is not None:
        return local_symbol.id

    short_name = reference.rsplit(".", 1)[-1]
    local_symbol = _single(index.by_file_name.get((source_symbol.file_path, short_name), []))
    if local_symbol is not None:
        return local_symbol.id

    global_symbol = _single(index.by_name.get(reference, []))
    if global_symbol is not None:
        return global_symbol.id

    fallback_symbol = _single(
        index.by_name.get(short_name, []),
        excluded_file=source_symbol.file_path,
    )
    return fallback_symbol.id if fallback_symbol is not None else None


def _resolve_import_relation_target(
    relation: RelationFact,
    import_text: str,
    index: _SymbolIndex,
) -> str | None:
    bindings = _parse_import_bindings(import_text)
    for binding in bindings:
        module_file = _resolve_module_file(
            binding.module_specifier,
            relation.file_path,
            index.file_paths,
        )
        if module_file is None:
            continue
        module_symbol = index.module_by_file.get(module_file)
        if module_symbol is not None:
            return module_symbol.id
    return None


def _resolve_import_target(
    module_file: str,
    binding: _ImportBinding,
    index: _SymbolIndex,
) -> str | None:
    if binding.target_name is None:
        module_symbol = index.module_by_file.get(module_file)
        return module_symbol.id if module_symbol is not None else None

    symbol = _single(index.by_file_name.get((module_file, binding.target_name), []))
    return symbol.id if symbol is not None else None


def _parse_import_bindings(import_text: str) -> list[_ImportBinding]:
    return [
        *_parse_python_imports(import_text),
        *_parse_js_imports(import_text),
    ]


def _parse_python_imports(import_text: str) -> list[_ImportBinding]:
    from_match = re.match(r"^from\s+([.\w]+)\s+import\s+(.+)$", import_text)
    if from_match is not None:
        module_specifier = from_match.group(1)
        imported = _strip_import_clause(from_match.group(2))
        bindings = []
        for part in _split_import_parts(imported):
            target_name, alias = _imported_name_and_alias(part)
            if target_name == "*":
                continue
            bindings.append(
                _ImportBinding(
                    alias=alias,
                    target_name=target_name,
                    module_specifier=module_specifier,
                )
            )
        return bindings

    import_match = re.match(r"^import\s+(.+)$", import_text)
    if import_match is None:
        return []

    bindings = []
    for part in _split_import_parts(import_match.group(1)):
        module_specifier, alias = _imported_name_and_alias(part)
        bindings.append(
            _ImportBinding(
                alias=alias,
                target_name=None,
                module_specifier=module_specifier,
            )
        )
    return bindings


def _parse_js_imports(import_text: str) -> list[_ImportBinding]:
    module_match = re.search(r"\bfrom\s+['\"]([^'\"]+)['\"]", import_text)
    if module_match is None:
        module_match = re.search(r"^import\s+['\"]([^'\"]+)['\"]", import_text)
    if module_match is None:
        return []

    module_specifier = module_match.group(1)
    bindings: list[_ImportBinding] = []

    namespace_match = re.search(r"\*\s+as\s+([A-Za-z_$][\w$]*)", import_text)
    if namespace_match is not None:
        bindings.append(
            _ImportBinding(
                alias=namespace_match.group(1),
                target_name=None,
                module_specifier=module_specifier,
            )
        )

    named_match = re.search(r"\{([^}]*)\}", import_text)
    if named_match is not None:
        for part in _split_import_parts(named_match.group(1)):
            target_name, alias = _imported_name_and_alias(part)
            bindings.append(
                _ImportBinding(
                    alias=alias,
                    target_name=target_name,
                    module_specifier=module_specifier,
                )
            )

    default_match = re.match(r"^import\s+([A-Za-z_$][\w$]*)\s*(?:,|\bfrom\b)", import_text)
    if default_match is not None:
        alias = default_match.group(1)
        bindings.append(
            _ImportBinding(
                alias=alias,
                target_name=alias,
                module_specifier=module_specifier,
            )
        )

    return bindings


def _strip_import_clause(value: str) -> str:
    return value.split("#", 1)[0].strip()


def _split_import_parts(value: str) -> list[str]:
    return [part.strip() for part in value.split(",") if part.strip()]


def _imported_name_and_alias(value: str) -> tuple[str, str]:
    parts = re.split(r"\s+as\s+", value.strip(), maxsplit=1)
    name = parts[0].strip()
    alias = parts[1].strip() if len(parts) == 2 else name
    return name, alias


def _resolve_module_file(
    module_specifier: str,
    importer_file: str,
    file_paths: set[str],
) -> str | None:
    candidates = _module_candidates(module_specifier, importer_file)
    for candidate in candidates:
        if candidate in file_paths:
            return candidate
    return None


def _module_candidates(module_specifier: str, importer_file: str) -> list[str]:
    importer_parent = PurePosixPath(importer_file).parent
    if str(importer_parent) == ".":
        importer_parent = PurePosixPath("")

    if module_specifier.startswith("."):
        stripped = module_specifier
        parent = importer_parent
        while stripped.startswith("."):
            stripped = stripped[1:]
            if stripped.startswith("."):
                parent = parent.parent
            else:
                break
        module_path = parent / stripped.lstrip("/").replace(".", "/")
    else:
        module_path = PurePosixPath(module_specifier.replace(".", "/"))

    base = str(module_path).strip("/")
    candidates = []
    if any(base.endswith(extension) for extension in _SOURCE_EXTENSIONS):
        candidates.append(base)
    else:
        candidates.extend(f"{base}{extension}" for extension in _SOURCE_EXTENSIONS)
        candidates.append(f"{base}/__init__.py")
        candidates.extend(f"{base}/index{extension}" for extension in _SOURCE_EXTENSIONS[1:])
    return candidates


def _unresolved_value(target_id: str) -> str | None:
    if not target_id.startswith(_UNRESOLVED_PREFIX):
        return None
    return target_id[len(_UNRESOLVED_PREFIX) :]


def _single(
    symbols: Iterable[SymbolFact],
    *,
    excluded_file: str | None = None,
) -> SymbolFact | None:
    candidates_by_id = {
        symbol.id: symbol
        for symbol in symbols
        if symbol.kind != "module" and symbol.file_path != excluded_file
    }
    candidates = list(candidates_by_id.values())
    if len(candidates) != 1:
        return None
    return candidates[0]


def _with_target(
    relation: RelationFact,
    target_id: str,
    *,
    confidence: float,
) -> RelationFact:
    return relation.model_copy(
        update={
            "id": _relation_id(
                relation.kind,
                relation.source_id,
                target_id,
                relation.file_path,
            ),
            "target_id": target_id,
            "confidence": confidence,
            "provenance": BINDER_PROVENANCE,
        }
    )


def _relation_id(kind: str, source_id: str, target_id: str, file_path: str) -> str:
    return sha1(
        f"{kind}:{source_id}:{target_id}:{file_path}".encode("utf-8")
    ).hexdigest()
