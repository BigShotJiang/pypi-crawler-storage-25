import subprocess
from dataclasses import dataclass
from datetime import UTC, datetime
import json
from pathlib import Path
from uuid import uuid4

from repostrata.config import init_project, load_manifest, write_manifest
from repostrata.db.connection import connect
from repostrata.db.migrations import migrate
from repostrata.db.repository import GraphRepository
from repostrata.git_reader import GitReader
from repostrata.index.binder import bind_relations
from repostrata.index.cochange import cochange_pairs
from repostrata.index.differ import diff_facts
from repostrata.index.materializer import make_commit_snapshot, snapshot_payload
from repostrata.models import RelationFact, SymbolFact
from repostrata.parsing.extractors import extract_facts
from repostrata.parsing.registry import language_for_path
from repostrata.paths import paths_for


@dataclass
class _FileFacts:
    symbols: list[SymbolFact]
    relations: list[RelationFact]


def index_repository(repo_root: Path) -> int:
    init_project(repo_root)
    paths = paths_for(repo_root)
    reader = GitReader(paths.repo_root)
    file_facts: dict[str, _FileFacts] = {}
    previous_symbols: list[SymbolFact] = []
    previous_relations: list[RelationFact] = []
    indexed_commits = 0
    indexed_head: str | None = None
    diagnostics: list[dict[str, str]] = []
    started_at = _utc_now()

    with connect(paths.database_path) as conn:
        migrate(conn)
        repository = GraphRepository(conn)
        repository.clear_indexed_graph()

        for commit in reader.iter_commits():
            repository.upsert_commit(commit)
            changed_symbols: list[SymbolFact] = []

            for file_path in commit.changed_files:
                language = language_for_path(file_path)
                if language is None:
                    continue

                try:
                    raw_source = reader.read_file_at_commit(commit.hash, file_path)
                    facts = extract_facts(
                        file_path,
                        language,
                        raw_source.encode("utf-8"),
                    )
                except subprocess.CalledProcessError:
                    file_facts.pop(file_path, None)
                    diagnostics.append(
                        _diagnostic(commit.hash, file_path, language, "file unavailable")
                    )
                    continue
                except Exception as exc:
                    file_facts.pop(file_path, None)
                    diagnostics.append(
                        _diagnostic(commit.hash, file_path, language, repr(exc))
                    )
                    continue

                file_facts[file_path] = _FileFacts(
                    symbols=facts.symbols,
                    relations=facts.relations,
                )
                changed_symbols.extend(
                    symbol for symbol in facts.symbols if symbol.kind != "module"
                )

            current_symbols = _all_symbols(file_facts)
            current_relations = bind_relations(
                current_symbols,
                _all_relations(file_facts),
            )
            events = diff_facts(
                commit.hash,
                previous_symbols,
                current_symbols,
                previous_relations,
                current_relations,
            )

            for symbol in current_symbols:
                repository.upsert_symbol(symbol)
            for relation in current_relations:
                repository.upsert_relation(relation)
            for event in events:
                repository.insert_event(event)
            for source_id, target_id in cochange_pairs(changed_symbols):
                repository.upsert_cochange(source_id, target_id, commit.hash)

            snapshot = make_commit_snapshot(commit.hash, commit.message)
            symbol_ids, relation_ids = snapshot_payload(
                current_symbols,
                current_relations,
            )
            repository.upsert_snapshot(snapshot, symbol_ids, relation_ids)

            repository.commit()
            previous_symbols = current_symbols
            previous_relations = current_relations
            indexed_commits += 1
            indexed_head = commit.hash

        status = "completed_with_diagnostics" if diagnostics else "completed"
        repository.insert_index_run(
            run_id=str(uuid4()),
            started_at=started_at,
            completed_at=_utc_now(),
            status=status,
            message=json.dumps({"diagnostics": diagnostics}, sort_keys=True),
        )
        repository.commit()

    manifest = load_manifest(repo_root)
    manifest["indexed_head"] = indexed_head
    manifest["indexed_commits"] = indexed_commits
    write_manifest(repo_root, manifest)

    return indexed_commits


def _all_symbols(file_facts: dict[str, _FileFacts]) -> list[SymbolFact]:
    return [
        symbol
        for facts in file_facts.values()
        for symbol in facts.symbols
    ]


def _all_relations(file_facts: dict[str, _FileFacts]) -> list[RelationFact]:
    return [
        relation
        for facts in file_facts.values()
        for relation in facts.relations
    ]


def _diagnostic(
    commit_hash: str,
    file_path: str,
    language: str,
    error: str,
) -> dict[str, str]:
    return {
        "commit": commit_hash,
        "file": file_path,
        "language": language,
        "extractor": "tree-sitter",
        "error": error,
    }


def _utc_now() -> str:
    return datetime.now(UTC).isoformat()
