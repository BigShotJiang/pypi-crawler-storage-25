import hashlib
import json
from collections.abc import Iterable
from typing import Any

from pydantic import BaseModel

from repostrata.models import GraphEvent, RelationFact, SymbolFact


def _event_id(commit_hash: str, event_type: str, subject_id: str) -> str:
    raw_id = f"{commit_hash}:{event_type}:{subject_id}".encode()
    return hashlib.sha1(raw_id).hexdigest()


def _payload(model_or_dict: BaseModel | dict[str, Any]) -> str:
    if isinstance(model_or_dict, BaseModel):
        model_or_dict = model_or_dict.model_dump()
    return json.dumps(model_or_dict, sort_keys=True, separators=(",", ":"))


def _event(
    commit_hash: str,
    event_type: str,
    subject_id: str,
    payload: BaseModel | dict[str, Any],
) -> GraphEvent:
    return GraphEvent(
        id=_event_id(commit_hash, event_type, subject_id),
        commit_hash=commit_hash,
        event_type=event_type,
        subject_id=subject_id,
        payload_json=_payload(payload),
    )


def diff_facts(
    commit_hash: str,
    previous_symbols: Iterable[SymbolFact],
    current_symbols: Iterable[SymbolFact],
    previous_relations: Iterable[RelationFact],
    current_relations: Iterable[RelationFact],
) -> list[GraphEvent]:
    previous_symbols_by_id = {symbol.id: symbol for symbol in previous_symbols}
    current_symbols_by_id = {symbol.id: symbol for symbol in current_symbols}
    previous_relations_by_id = {
        relation.id: relation for relation in previous_relations
    }
    current_relations_by_id = {relation.id: relation for relation in current_relations}

    events: list[GraphEvent] = []

    for symbol_id in sorted(current_symbols_by_id):
        symbol = current_symbols_by_id[symbol_id]
        if symbol_id not in previous_symbols_by_id:
            events.append(_event(commit_hash, "symbol_added", symbol_id, symbol))

    for symbol_id in sorted(current_symbols_by_id):
        current_symbol = current_symbols_by_id[symbol_id]
        previous_symbol = previous_symbols_by_id.get(symbol_id)
        if (
            previous_symbol is not None
            and previous_symbol.source_hash != current_symbol.source_hash
        ):
            events.append(
                _event(
                    commit_hash,
                    "symbol_changed",
                    symbol_id,
                    {
                        "previous": previous_symbol.model_dump(),
                        "current": current_symbol.model_dump(),
                    },
                )
            )

    for symbol_id in sorted(previous_symbols_by_id):
        symbol = previous_symbols_by_id[symbol_id]
        if symbol_id not in current_symbols_by_id:
            events.append(_event(commit_hash, "symbol_removed", symbol_id, symbol))

    for relation_id in sorted(current_relations_by_id):
        relation = current_relations_by_id[relation_id]
        if relation_id not in previous_relations_by_id:
            events.append(_event(commit_hash, "edge_added", relation_id, relation))

    for relation_id in sorted(current_relations_by_id):
        current_relation = current_relations_by_id[relation_id]
        previous_relation = previous_relations_by_id.get(relation_id)
        if (
            previous_relation is not None
            and previous_relation.model_dump() != current_relation.model_dump()
        ):
            events.append(
                _event(
                    commit_hash,
                    "edge_changed",
                    relation_id,
                    {
                        "previous": previous_relation.model_dump(),
                        "current": current_relation.model_dump(),
                    },
                )
            )

    for relation_id in sorted(previous_relations_by_id):
        relation = previous_relations_by_id[relation_id]
        if relation_id not in current_relations_by_id:
            events.append(_event(commit_hash, "edge_removed", relation_id, relation))

    return events
