from importlib import resources
from pathlib import Path

import typer
import uvicorn
from typer.core import TyperGroup

from repostrata import __version__
from repostrata.api.app import create_app
from repostrata.codex import (
    DEFAULT_BASE_URL,
    codex_doctor,
    default_codex_config_path,
    default_install_root,
    install_codex_plugin,
    uninstall_codex_plugin,
)
from repostrata.config import init_project
from repostrata.index.coordinator import index_repository
from repostrata.paths import paths_for


class HelpOnNoArgsGroup(TyperGroup):
    def parse_args(self, ctx: typer.Context, args: list[str]) -> list[str]:
        if not args and self.no_args_is_help and not ctx.resilient_parsing:
            typer.echo(ctx.get_help())
            raise typer.Exit()

        return super().parse_args(ctx, args)


app = typer.Typer(
    cls=HelpOnNoArgsGroup,
    name="repostrata",
    help="Build and explore a time-aware code knowledge graph.",
    no_args_is_help=True,
)
codex_app = typer.Typer(help="Install and diagnose the Codex plugin.")
app.add_typer(codex_app, name="codex")


def version_callback(value: bool) -> None:
    if value:
        typer.echo(f"repostrata {__version__}")
        raise typer.Exit()


@app.callback()
def root(
    version: bool = typer.Option(
        False,
        "--version",
        callback=version_callback,
        is_eager=True,
        help="Show the version and exit.",
    ),
) -> None:
    pass


@app.command()
def init(repo: Path = typer.Option(Path.cwd(), "--repo", help="Repository root.")) -> None:
    init_project(repo)
    typer.echo(f"Initialized RepoStrata in {repo / '.repostrata'}")


@app.command()
def index(
    repo: Path = typer.Option(Path.cwd(), "--repo", help="Repository root."),
    since: str | None = typer.Option(None, "--since", help="Start commit or ref."),
    until: str | None = typer.Option(None, "--until", help="End commit or ref."),
    full: bool = typer.Option(False, "--full", help="Force a full index rebuild."),
    languages: str | None = typer.Option(
        None,
        "--languages",
        help="Comma-separated languages to index.",
    ),
) -> None:
    _ = (since, until, full, languages)
    count = index_repository(repo)
    typer.echo(f"Indexed {count} commits into {repo / '.repostrata' / 'graph.db'}")


@app.command()
def dashboard(
    repo: Path = typer.Option(Path.cwd(), "--repo", help="Repository root."),
    host: str = typer.Option("127.0.0.1", "--host", help="API host."),
    port: int = typer.Option(8765, "--port", help="API port."),
) -> None:
    typer.echo(f"Starting RepoStrata API at http://{host}:{port}")
    uvicorn.run(create_app(repo, static_dir=_dashboard_static_dir()), host=host, port=port)


@app.command()
def doctor(repo: Path = typer.Option(Path.cwd(), "--repo", help="Repository root.")) -> None:
    paths = paths_for(repo)
    checks = [
        ("data_dir", paths.data_dir.exists()),
        ("config", paths.config_path.exists()),
        ("manifest", paths.manifest_path.exists()),
        ("graph_db", paths.database_path.exists()),
    ]
    for name, ok in checks:
        typer.echo(f"{name}: {'ok' if ok else 'missing'}")
    if not paths.config_path.exists() or not paths.manifest_path.exists():
        raise typer.Exit(code=1)


@codex_app.command("install")
def codex_install(
    install_root: Path = typer.Option(
        default_install_root(),
        "--install-root",
        help="Directory where RepoStrata writes the Codex marketplace and plugin.",
    ),
    config: Path = typer.Option(
        default_codex_config_path(),
        "--config",
        help="Codex config.toml path.",
    ),
    base_url: str = typer.Option(
        DEFAULT_BASE_URL,
        "--base-url",
        help="RepoStrata API base URL used by the plugin.",
    ),
) -> None:
    paths = install_codex_plugin(
        install_root=install_root,
        config_path=config,
        base_url=base_url,
    )
    typer.echo(f"Installed RepoStrata Codex plugin into {paths.install_root}")
    typer.echo(f"Updated Codex config at {paths.config_path}")
    typer.echo("Restart Codex, then start RepoStrata with:")
    typer.echo("repostrata dashboard --repo /path/to/repo --port 8765")


@codex_app.command("doctor")
def codex_doctor_command(
    install_root: Path = typer.Option(
        default_install_root(),
        "--install-root",
        help="Directory where RepoStrata writes the Codex marketplace and plugin.",
    ),
    config: Path = typer.Option(
        default_codex_config_path(),
        "--config",
        help="Codex config.toml path.",
    ),
) -> None:
    checks = codex_doctor(install_root=install_root, config_path=config)
    for name, ok in checks:
        typer.echo(f"{name}: {'ok' if ok else 'missing'}")
    if not all(ok for _, ok in checks):
        raise typer.Exit(code=1)


@codex_app.command("uninstall")
def codex_uninstall(
    install_root: Path = typer.Option(
        default_install_root(),
        "--install-root",
        help="Directory where RepoStrata writes the Codex marketplace and plugin.",
    ),
    config: Path = typer.Option(
        default_codex_config_path(),
        "--config",
        help="Codex config.toml path.",
    ),
) -> None:
    paths = uninstall_codex_plugin(install_root=install_root, config_path=config)
    typer.echo(f"Removed RepoStrata Codex plugin from {paths.install_root}")
    typer.echo(f"Updated Codex config at {paths.config_path}")


def main() -> None:
    app()


def _dashboard_static_dir() -> Path | None:
    packaged_static_dir = resources.files("repostrata").joinpath("web_dist")
    if packaged_static_dir.joinpath("index.html").is_file():
        return Path(str(packaged_static_dir))

    source_static_dir = Path(__file__).resolve().parents[2] / "web" / "dist"
    return source_static_dir if source_static_dir.exists() else None
