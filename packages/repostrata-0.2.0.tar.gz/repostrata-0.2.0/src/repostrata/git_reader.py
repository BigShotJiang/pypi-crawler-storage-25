import subprocess
from pathlib import Path

from repostrata.models import CommitRecord


class GitReader:
    def __init__(self, repo_root: Path):
        self.repo_root = repo_root

    def _git(self, *args: str) -> str:
        return self._git_raw(*args).strip()

    def _git_raw(self, *args: str) -> str:
        result = subprocess.run(
            ["git", *args],
            cwd=self.repo_root,
            check=True,
            text=True,
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
        )
        return result.stdout

    def iter_commits(self) -> list[CommitRecord]:
        try:
            self._git("rev-parse", "--verify", "HEAD")
        except subprocess.CalledProcessError:
            return []

        output = self._git("rev-list", "--reverse", "HEAD")
        if not output:
            return []

        return [self._read_commit(commit_hash) for commit_hash in output.splitlines()]

    def read_file_at_commit(self, commit_hash: str, file_path: str) -> str:
        return self._git_raw("show", f"{commit_hash}:{file_path}")

    def _read_commit(self, commit_hash: str) -> CommitRecord:
        raw_commit = self._git(
            "show",
            "-s",
            "--format=%H%x1f%P%x1f%an%x1f%ae%x1f%aI%x1f%s",
            commit_hash,
        )
        full_hash, parents, author_name, author_email, authored_at, message = (
            raw_commit.split("\x1f")
        )
        parent_hashes = parents.split() if parents else []
        if parent_hashes:
            changed_files = self._git("diff", "--name-only", parent_hashes[0], commit_hash)
        else:
            changed_files = self._git(
                "diff-tree",
                "--no-commit-id",
                "--name-only",
                "-r",
                "--root",
                commit_hash,
            )

        return CommitRecord(
            hash=full_hash,
            parents=parent_hashes,
            author_name=author_name,
            author_email=author_email,
            authored_at=authored_at,
            message=message,
            changed_files=changed_files.splitlines() if changed_files else [],
        )
