"""Local HTTP API for RepoStrata dashboard and agent clients."""
