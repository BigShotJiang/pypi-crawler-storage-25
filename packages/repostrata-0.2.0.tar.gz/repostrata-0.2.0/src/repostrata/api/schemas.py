from typing import Any, Literal

from pydantic import BaseModel, Field


class TimelineResponse(BaseModel):
    commits: list[dict[str, object]]


class SymbolSearchResponse(BaseModel):
    symbols: list[dict[str, object]]


class SnapshotResponse(BaseModel):
    nodes: list[dict[str, object]]
    edges: list[dict[str, object]]


class AgentToolResponse(BaseModel):
    summary: str
    items: list[dict[str, Any]]
    evidence: list[dict[str, Any]]
    truncated: bool
    next_queries: list[dict[str, Any]]


class AgentSearchSymbolsRequest(BaseModel):
    query: str
    kind: Literal["module", "class", "function", "method"] | None = None
    language: Literal["python", "javascript", "typescript", "tsx"] | None = None
    path_prefix: str | None = None
    limit: int = Field(default=20, ge=1)


class AgentGetSymbolRequest(BaseModel):
    symbol_id: str | None = None
    qualified_name: str | None = None
    commit: str | None = None


class AgentNeighborhoodRequest(BaseModel):
    symbol_id: str
    commit: str | None = None
    depth: Literal[1, 2] = 1
    relation_kinds: list[str] | None = None
    direction: Literal["incoming", "outgoing", "both"] = "both"
    limit: int = Field(default=50, ge=1)


class AgentHistoryRequest(BaseModel):
    symbol_id: str
    since: str | None = None
    until: str | None = None
    event_types: list[str] | None = None
    limit: int = Field(default=50, ge=1)
