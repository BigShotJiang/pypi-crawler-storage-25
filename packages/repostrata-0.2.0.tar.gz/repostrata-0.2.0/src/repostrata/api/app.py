from contextlib import closing
from pathlib import Path

from fastapi import FastAPI, HTTPException
from fastapi.responses import FileResponse
from fastapi.middleware.cors import CORSMiddleware
from fastapi.staticfiles import StaticFiles

from repostrata.api.schemas import (
    AgentGetSymbolRequest,
    AgentHistoryRequest,
    AgentNeighborhoodRequest,
    AgentSearchSymbolsRequest,
    AgentToolResponse,
    SnapshotResponse,
    SymbolSearchResponse,
    TimelineResponse,
)
from repostrata.db.connection import connect
from repostrata.db.repository import GraphRepository
from repostrata.paths import paths_for
from repostrata.query.service import AgentToolResult, QueryService


def create_app(repo_root: Path, static_dir: Path | None = None) -> FastAPI:
    paths = paths_for(repo_root)
    query_service = QueryService(repo_root)
    app = FastAPI(title="RepoStrata Local API")

    app.add_middleware(
        CORSMiddleware,
        allow_origins=[
            "http://localhost:5173",
            "http://127.0.0.1:5173",
        ],
        allow_credentials=True,
        allow_methods=["*"],
        allow_headers=["*"],
    )

    def open_repository():
        if not paths.database_path.exists():
            raise HTTPException(
                status_code=503,
                detail="RepoStrata graph database has not been indexed",
            )
        return closing(connect(paths.database_path))

    def agent_response(result: AgentToolResult) -> AgentToolResponse:
        return AgentToolResponse(
            summary=result.summary,
            items=result.items,
            evidence=result.evidence,
            truncated=result.truncated,
            next_queries=result.next_queries,
        )

    def agent_error(error: LookupError) -> HTTPException:
        detail = str(error)
        if (
            "has not been indexed" in detail
            or "no indexed_head" in detail
        ):
            return HTTPException(status_code=503, detail=detail)
        return HTTPException(status_code=404, detail=detail)

    def run_agent_tool(call) -> AgentToolResponse:
        try:
            return agent_response(call())
        except ValueError as error:
            raise HTTPException(status_code=400, detail=str(error)) from error
        except LookupError as error:
            raise agent_error(error) from error

    @app.get("/api/timeline", response_model=TimelineResponse)
    def timeline() -> TimelineResponse:
        with open_repository() as conn:
            repository = GraphRepository(conn)
            return TimelineResponse(commits=repository.list_commits())

    @app.get("/api/symbols/search", response_model=SymbolSearchResponse)
    def search_symbols(q: str) -> SymbolSearchResponse:
        query = q.strip()
        if not query:
            raise HTTPException(status_code=400, detail="Search query is required")
        with open_repository() as conn:
            repository = GraphRepository(conn)
            return SymbolSearchResponse(symbols=repository.search_symbols(query))

    @app.get("/api/snapshots/{commit_hash}", response_model=SnapshotResponse)
    def snapshot(commit_hash: str) -> SnapshotResponse:
        with open_repository() as conn:
            repository = GraphRepository(conn)
            payload = repository.snapshot_for_commit(commit_hash)
            if payload is None:
                raise HTTPException(status_code=404, detail="Snapshot not found")
            return SnapshotResponse(**payload)

    @app.get("/api/agent/status", response_model=AgentToolResponse)
    def agent_status() -> AgentToolResponse:
        return agent_response(query_service.status())

    @app.post("/api/agent/symbols/search", response_model=AgentToolResponse)
    def agent_search_symbols(
        request: AgentSearchSymbolsRequest,
    ) -> AgentToolResponse:
        return run_agent_tool(
            lambda: query_service.search_symbols(
                query=request.query,
                kind=request.kind,
                language=request.language,
                path_prefix=request.path_prefix,
                limit=request.limit,
            )
        )

    @app.post("/api/agent/symbols/get", response_model=AgentToolResponse)
    def agent_get_symbol(request: AgentGetSymbolRequest) -> AgentToolResponse:
        return run_agent_tool(
            lambda: query_service.get_symbol(
                symbol_id=request.symbol_id,
                qualified_name=request.qualified_name,
                commit=request.commit,
            )
        )

    @app.post("/api/agent/symbols/neighborhood", response_model=AgentToolResponse)
    def agent_symbol_neighborhood(
        request: AgentNeighborhoodRequest,
    ) -> AgentToolResponse:
        return run_agent_tool(
            lambda: query_service.get_symbol_neighborhood(
                symbol_id=request.symbol_id,
                commit=request.commit,
                depth=request.depth,
                relation_kinds=request.relation_kinds,
                direction=request.direction,
                limit=request.limit,
            )
        )

    @app.post("/api/agent/symbols/history", response_model=AgentToolResponse)
    def agent_symbol_history(request: AgentHistoryRequest) -> AgentToolResponse:
        return run_agent_tool(
            lambda: query_service.get_symbol_history(
                symbol_id=request.symbol_id,
                since=request.since,
                until=request.until,
                event_types=request.event_types,
                limit=request.limit,
            )
        )

    if static_dir is not None and (static_dir / "index.html").exists():
        assets_dir = static_dir / "assets"
        if assets_dir.exists():
            app.mount("/assets", StaticFiles(directory=assets_dir), name="assets")

        @app.get("/", include_in_schema=False)
        def dashboard_index() -> FileResponse:
            return FileResponse(static_dir / "index.html")

    return app
