import { describe, expect, it } from "vitest";

import type { Snapshot } from "./api";
import {
  getRenderableEdges,
  getVisibleEdgeCount,
  getVisibleNodeCount,
  type EdgeKind,
  type NodeKind,
} from "./graphModel";

const snapshot: Snapshot = {
  nodes: [
    {
      id: "module:api",
      kind: "module",
      language: "typescript",
      file_path: "src/api.ts",
      qualified_name: "src/api",
      name: "api",
    },
    {
      id: "function:getTimeline",
      kind: "function",
      language: "typescript",
      file_path: "src/api.ts",
      qualified_name: "getTimeline",
      name: "getTimeline",
    },
    {
      id: "class:Timeline",
      kind: "class",
      language: "typescript",
      file_path: "src/components/Timeline.tsx",
      qualified_name: "Timeline",
      name: "Timeline",
    },
  ],
  edges: [
    {
      id: "contains:api:getTimeline",
      kind: "contains",
      source_id: "module:api",
      target_id: "function:getTimeline",
      confidence: 1,
    },
    {
      id: "imports:Timeline:api",
      kind: "imports",
      source_id: "class:Timeline",
      target_id: "module:api",
      confidence: 0.9,
    },
    {
      id: "dangling:missing",
      kind: "calls",
      source_id: "function:getTimeline",
      target_id: "missing",
      confidence: 0.5,
    },
  ],
};

describe("graph model", () => {
  it("returns zero counts for a missing snapshot", () => {
    expect(getVisibleNodeCount(null, new Set<NodeKind>(["module"]))).toBe(0);
    expect(
      getVisibleEdgeCount(null, new Set<NodeKind>(["module"]), new Set<EdgeKind>(["contains"])),
    ).toBe(0);
    expect(getRenderableEdges(null)).toEqual([]);
  });

  it("counts only nodes with enabled kinds", () => {
    expect(getVisibleNodeCount(snapshot, new Set<NodeKind>(["module", "class"]))).toBe(2);
  });

  it("omits edges that reference nodes outside the snapshot", () => {
    expect(getRenderableEdges(snapshot).map((edge) => edge.id)).toEqual([
      "contains:api:getTimeline",
      "imports:Timeline:api",
    ]);
  });

  it("counts only visible edges whose kind and endpoint node kinds are enabled", () => {
    expect(
      getVisibleEdgeCount(
        snapshot,
        new Set<NodeKind>(["module", "function"]),
        new Set<EdgeKind>(["contains", "imports"]),
      ),
    ).toBe(1);

    expect(
      getVisibleEdgeCount(
        snapshot,
        new Set<NodeKind>(["module", "function", "class"]),
        new Set<EdgeKind>(["contains", "imports"]),
      ),
    ).toBe(2);

    expect(
      getVisibleEdgeCount(
        snapshot,
        new Set<NodeKind>(["module", "function", "class"]),
        new Set<EdgeKind>(["calls"]),
      ),
    ).toBe(0);
  });
});
