import type { GraphNode } from "../api";

type Props = {
  node: GraphNode | null;
};

export function DetailsPanel({ node }: Props) {
  return (
    <aside className="panel details-panel">
      <div className="panel-heading">
        <span className="eyebrow">Inspector</span>
        <h2>符号详情</h2>
      </div>
      {node ? (
        <dl className="details-list">
          <div>
            <dt>名称</dt>
            <dd>{node.qualified_name}</dd>
          </div>
          <div>
            <dt>类型</dt>
            <dd>{node.kind}</dd>
          </div>
          <div>
            <dt>语言</dt>
            <dd>{node.language}</dd>
          </div>
          <div>
            <dt>文件</dt>
            <dd>{node.file_path}</dd>
          </div>
        </dl>
      ) : (
        <div className="empty-state">
          <div className="empty-icon" aria-hidden="true">⌁</div>
          <p>选择图谱中的节点查看符号、语言和文件路径。</p>
        </div>
      )}
    </aside>
  );
}
