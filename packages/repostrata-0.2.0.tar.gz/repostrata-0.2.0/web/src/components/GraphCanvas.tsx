import cytoscape from "cytoscape";
import { useEffect, useRef } from "react";
import type { GraphNode, Snapshot } from "../api";
import {
  ALL_EDGE_KINDS,
  ALL_NODE_KINDS,
  EDGE_COLORS,
  NODE_COLORS,
  getRenderableEdges,
  type EdgeKind,
  type NodeKind,
} from "../graphModel";

type Props = {
  snapshot: Snapshot | null;
  selectedNode: GraphNode | null;
  onSelectNode: (node: GraphNode | null) => void;
  enabledEdgeKinds: Set<EdgeKind>;
  enabledNodeKinds: Set<NodeKind>;
};

export function GraphCanvas({
  snapshot,
  selectedNode,
  onSelectNode,
  enabledEdgeKinds,
  enabledNodeKinds,
}: Props) {
  const containerRef = useRef<HTMLDivElement | null>(null);
  const cyRef = useRef<cytoscape.Core | null>(null);

  useEffect(() => {
    if (!containerRef.current || !snapshot) return;

    if (cyRef.current) cyRef.current.destroy();

    const nodesById = new Map(snapshot.nodes.map((node) => [node.id, node]));
    const visibleEdges = getRenderableEdges(snapshot);

    const cy = cytoscape({
      container: containerRef.current,
      elements: [
        ...snapshot.nodes.map((node) => ({
          data: { id: node.id, label: node.name, kind: node.kind }
        })),
        ...visibleEdges.map((edge) => ({
          data: {
            id: edge.id,
            source: edge.source_id,
            target: edge.target_id,
            kind: edge.kind
          }
        }))
      ],
      style: [
        {
          selector: "node",
          style: {
            label: "data(label)",
            "background-color": "#8b98a7",
            "border-color": "#ffffff",
            "border-width": 2,
            color: "#25313d",
            "font-size": 11,
            "font-weight": 600,
            height: "30px",
            width: "30px",
            "text-valign": "bottom",
            "text-halign": "center",
            "text-margin-y": 7,
            "text-background-color": "#ffffff",
            "text-background-opacity": 0.86,
            "text-background-padding": "3px",
            "text-border-color": "#e2e8f0",
            "text-border-opacity": 0.8,
            "text-border-width": 1,
          }
        },
        ...ALL_NODE_KINDS.map((kind) => ({
          selector: `node[kind = '${kind}']`,
          style: { "background-color": NODE_COLORS[kind] }
        })),
        {
          selector: "edge",
          style: {
            width: 1.6,
            "line-color": "#a9b4c0",
            opacity: 0.78,
            "target-arrow-color": "#a9b4c0",
            "target-arrow-shape": "triangle",
            "arrow-scale": 0.78,
            "curve-style": "bezier"
          }
        },
        ...ALL_EDGE_KINDS.map((kind) => ({
          selector: `edge[kind = '${kind}']`,
          style: {
            "line-color": EDGE_COLORS[kind],
            "target-arrow-color": EDGE_COLORS[kind],
          }
        })),
        {
          selector: "node:selected",
          style: {
            "background-color": "#d1495b",
            "border-color": "#7f1d2b",
            "border-width": 3,
            height: "38px",
            width: "38px"
          }
        },
        {
          selector: "edge:selected",
          style: {
            width: 3,
            opacity: 1
          }
        }
      ],
      layout: {
        name: "cose",
        animate: false,
        padding: 48,
        nodeRepulsion: 7200,
        idealEdgeLength: 96,
      }
    });

    cyRef.current = cy;

    cy.on("tap", "node", (event) => {
      const node = nodesById.get(event.target.id()) ?? null;
      onSelectNode(node);
    });
    cy.on("tap", (event) => {
      if (event.target === cy) onSelectNode(null);
    });

    return () => {
      cy.destroy();
      cyRef.current = null;
    };
  }, [snapshot, onSelectNode]);

  useEffect(() => {
    const cy = cyRef.current;
    if (!cy) return;
    cy.elements().unselect();
    if (selectedNode) cy.$id(selectedNode.id).select();
  }, [selectedNode]);

  useEffect(() => {
    const cy = cyRef.current;
    if (!cy) return;

    cy.batch(() => {
      cy.nodes().forEach((node) => {
        const kind = node.data("kind") as NodeKind;
        node.style("display", enabledNodeKinds.has(kind) ? "element" : "none");
      });

      cy.edges().forEach((edge) => {
        const kind = edge.data("kind") as EdgeKind;
        const sourceKind = edge.source().data("kind") as NodeKind;
        const targetKind = edge.target().data("kind") as NodeKind;
        const visible =
          enabledEdgeKinds.has(kind) &&
          enabledNodeKinds.has(sourceKind) &&
          enabledNodeKinds.has(targetKind);

        edge.style("display", visible ? "element" : "none");
      });
    });
  }, [enabledEdgeKinds, enabledNodeKinds]);

  if (!snapshot) {
    return (
      <div className="graph-canvas graph-empty">
        <div>
          <span className="eyebrow">Waiting</span>
          <p>正在等待快照数据。</p>
        </div>
      </div>
    );
  }

  if (snapshot.nodes.length === 0) {
    return (
      <div className="graph-canvas graph-empty">
        <div>
          <span className="eyebrow">Empty snapshot</span>
          <p>当前提交没有可展示的符号节点。</p>
        </div>
      </div>
    );
  }

  return <div ref={containerRef} className="graph-canvas" />;
}
