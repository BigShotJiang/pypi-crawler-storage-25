import {
  ALL_EDGE_KINDS, ALL_NODE_KINDS,
  EDGE_COLORS, NODE_COLORS,
  type EdgeKind, type NodeKind,
} from "../graphModel";

const EDGE_KIND_LABELS: Record<EdgeKind, string> = {
  contains:   "包含",
  imports:    "导入",
  calls:      "调用",
  inherits:   "继承",
  co_changes: "共变",
};

const NODE_KIND_LABELS: Record<NodeKind, string> = {
  function: "函数",
  class:    "类",
  method:   "方法",
  module:   "模块",
};

type Props = {
  nodeCount: number;
  edgeCount: number;
  enabledEdgeKinds: Set<EdgeKind>;
  onToggleEdgeKind: (kind: EdgeKind) => void;
  enabledNodeKinds: Set<NodeKind>;
  onToggleNodeKind: (kind: NodeKind) => void;
};

export function FiltersPanel({
  nodeCount,
  edgeCount,
  enabledEdgeKinds,
  onToggleEdgeKind,
  enabledNodeKinds,
  onToggleNodeKind,
}: Props) {
  return (
    <aside className="panel filters-panel">
      <div className="panel-heading">
        <span className="eyebrow">Controls</span>
        <h2>图谱筛选</h2>
      </div>
      <div className="summary-grid">
        <div className="summary-card">
          <span>节点</span>
          <strong>{nodeCount}</strong>
        </div>
        <div className="summary-card">
          <span>关系</span>
          <strong>{edgeCount}</strong>
        </div>
      </div>
      <fieldset className="filter-group">
        <legend>节点类型</legend>
        {ALL_NODE_KINDS.map((kind) => (
          <label key={kind} className="filter-option">
            <input
              type="checkbox"
              checked={enabledNodeKinds.has(kind)}
              onChange={() => onToggleNodeKind(kind)}
            />
            <span className="kind-dot" style={{ background: NODE_COLORS[kind] }} />
            <span>{NODE_KIND_LABELS[kind]}</span>
          </label>
        ))}
      </fieldset>
      <fieldset className="filter-group">
        <legend>边类型</legend>
        {ALL_EDGE_KINDS.map((kind) => (
          <label key={kind} className="filter-option">
            <input
              type="checkbox"
              checked={enabledEdgeKinds.has(kind)}
              onChange={() => onToggleEdgeKind(kind)}
            />
            <span className="kind-dot" style={{ background: EDGE_COLORS[kind] }} />
            <span>{EDGE_KIND_LABELS[kind]}</span>
          </label>
        ))}
      </fieldset>
    </aside>
  );
}
