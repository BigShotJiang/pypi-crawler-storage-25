import type { Commit } from "../api";

type Props = {
  commits: Commit[];
  selectedIndex: number;
  onSelect: (index: number) => void;
};

export function Timeline({ commits, selectedIndex, onSelect }: Props) {
  const selected = commits[selectedIndex];
  const total = commits.length;
  const sliderMax = Math.max(total - 1, 0);
  const canGoPrevious = selectedIndex > 0;
  const canGoNext = selectedIndex < total - 1;
  const authoredAt = selected
    ? new Intl.DateTimeFormat("zh-CN", {
        month: "2-digit",
        day: "2-digit",
        hour: "2-digit",
        minute: "2-digit",
      }).format(new Date(selected.authored_at))
    : null;

  return (
    <div className="timeline">
      <div className="timeline-header">
        <span className="timeline-label">时间线</span>
        <span className="timeline-counter">
          {total > 0 ? `${selectedIndex + 1} / ${total}` : "0 / 0"}
        </span>
      </div>

      <div className="timeline-control">
        <button
          type="button"
          className="nav-btn"
          disabled={!canGoPrevious}
          onClick={() => onSelect(selectedIndex - 1)}
          aria-label="上一个提交"
        >
          ‹
        </button>
        <input
          className="timeline-slider"
          aria-label="选择提交"
          type="range"
          min={0}
          max={sliderMax}
          value={Math.min(selectedIndex, sliderMax)}
          disabled={total <= 1}
          onChange={(event) => onSelect(Number(event.target.value))}
        />
        <button
          type="button"
          className="nav-btn"
          disabled={!canGoNext}
          onClick={() => onSelect(selectedIndex + 1)}
          aria-label="下一个提交"
        >
          ›
        </button>
      </div>

      <div className="commit-meta">
        {selected ? (
          <>
            <strong>{selected.hash.slice(0, 8)}</strong>
            {authoredAt ? <span>{authoredAt}</span> : null}
            <span>{selected.author_name}</span>
            <span>{selected.message}</span>
          </>
        ) : (
          <span>暂无已索引的提交</span>
        )}
      </div>
    </div>
  );
}
