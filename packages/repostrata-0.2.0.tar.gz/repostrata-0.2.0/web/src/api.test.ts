import { afterEach, describe, expect, it, vi } from "vitest";

import { getSnapshot, getTimeline } from "./api";

afterEach(() => {
  vi.restoreAllMocks();
});

describe("api client", () => {
  it("returns commits from the timeline response", async () => {
    vi.stubGlobal(
      "fetch",
      vi.fn(async () => ({
        ok: true,
        json: async () => ({
          commits: [
            {
              hash: "abc123",
              authored_at: "2026-05-15T00:00:00Z",
              author_name: "RepoStrata",
              message: "index repository",
            },
          ],
        }),
      })),
    );

    await expect(getTimeline()).resolves.toEqual([
      {
        hash: "abc123",
        authored_at: "2026-05-15T00:00:00Z",
        author_name: "RepoStrata",
        message: "index repository",
      },
    ]);
    expect(fetch).toHaveBeenCalledWith("/api/timeline");
  });

  it("loads snapshots for the selected commit", async () => {
    vi.stubGlobal(
      "fetch",
      vi.fn(async () => ({
        ok: true,
        json: async () => ({
          nodes: [],
          edges: [],
        }),
      })),
    );

    await expect(getSnapshot("abc123")).resolves.toEqual({ nodes: [], edges: [] });
    expect(fetch).toHaveBeenCalledWith("/api/snapshots/abc123");
  });

  it("rejects when the timeline request fails", async () => {
    vi.stubGlobal(
      "fetch",
      vi.fn(async () => ({
        ok: false,
        json: async () => ({ message: "unavailable" }),
      })),
    );

    await expect(getTimeline()).rejects.toThrow("Failed to load timeline");
    expect(fetch).toHaveBeenCalledWith("/api/timeline");
  });

  it("rejects when the snapshot request fails", async () => {
    vi.stubGlobal(
      "fetch",
      vi.fn(async () => ({
        ok: false,
        json: async () => ({ message: "missing" }),
      })),
    );

    await expect(getSnapshot("missing")).rejects.toThrow("Failed to load snapshot");
    expect(fetch).toHaveBeenCalledWith("/api/snapshots/missing");
  });
});
