export type Commit = {
  hash: string;
  authored_at: string;
  author_name: string;
  message: string;
};

export type GraphNode = {
  id: string;
  kind: string;
  language: string;
  file_path: string;
  qualified_name: string;
  name: string;
};

export type GraphEdge = {
  id: string;
  kind: string;
  source_id: string;
  target_id: string;
  confidence: number;
};

export type Snapshot = {
  nodes: GraphNode[];
  edges: GraphEdge[];
};

export async function getTimeline(): Promise<Commit[]> {
  const response = await fetch("/api/timeline");
  if (!response.ok) throw new Error("Failed to load timeline");
  const body = await response.json();
  return body.commits;
}

export async function getSnapshot(commitHash: string): Promise<Snapshot> {
  const response = await fetch(`/api/snapshots/${commitHash}`);
  if (!response.ok) throw new Error("Failed to load snapshot");
  return response.json();
}
