import type { Snapshot } from "./api";

export const ALL_EDGE_KINDS = ["contains", "imports", "calls", "inherits", "co_changes"] as const;
export type EdgeKind = typeof ALL_EDGE_KINDS[number];

export const ALL_NODE_KINDS = ["function", "class", "method", "module"] as const;
export type NodeKind = typeof ALL_NODE_KINDS[number];

export const NODE_COLORS: Record<NodeKind, string> = {
  function: "#4e9af1",
  class: "#e8703a",
  method: "#7bc67e",
  module: "#b57bee",
};

export const EDGE_COLORS: Record<EdgeKind, string> = {
  contains: "#7bc67e",
  imports: "#b57bee",
  calls: "#f4c842",
  inherits: "#e8703a",
  co_changes: "#f06292",
};

export function getVisibleNodeCount(
  snapshot: Snapshot | null,
  enabledNodeKinds: Set<NodeKind>,
) {
  if (!snapshot) return 0;
  return snapshot.nodes.filter((node) => enabledNodeKinds.has(node.kind as NodeKind)).length;
}

export function getRenderableEdges(snapshot: Snapshot | null) {
  if (!snapshot) return [];

  const nodesById = new Set(snapshot.nodes.map((node) => node.id));
  return snapshot.edges.filter(
    (edge) => nodesById.has(edge.source_id) && nodesById.has(edge.target_id),
  );
}

export function getVisibleEdgeCount(
  snapshot: Snapshot | null,
  enabledNodeKinds: Set<NodeKind>,
  enabledEdgeKinds: Set<EdgeKind>,
) {
  if (!snapshot) return 0;

  const nodesById = new Map(snapshot.nodes.map((node) => [node.id, node]));
  return snapshot.edges.filter((edge) => {
    const source = nodesById.get(edge.source_id);
    const target = nodesById.get(edge.target_id);
    if (!source || !target) return false;

    return (
      enabledEdgeKinds.has(edge.kind as EdgeKind) &&
      enabledNodeKinds.has(source.kind as NodeKind) &&
      enabledNodeKinds.has(target.kind as NodeKind)
    );
  }).length;
}
