import { useCallback, useEffect, useMemo, useState } from "react";
import { getSnapshot, getTimeline, type Commit, type GraphNode, type Snapshot } from "./api";
import { DetailsPanel } from "./components/DetailsPanel";
import { FiltersPanel } from "./components/FiltersPanel";
import { GraphCanvas } from "./components/GraphCanvas";
import { Timeline } from "./components/Timeline";
import {
  ALL_EDGE_KINDS,
  ALL_NODE_KINDS,
  getVisibleEdgeCount,
  getVisibleNodeCount,
  type EdgeKind,
  type NodeKind,
} from "./graphModel";

export function App() {
  const [commits, setCommits] = useState<Commit[]>([]);
  const [selectedIndex, setSelectedIndex] = useState(0);
  const [snapshot, setSnapshot] = useState<Snapshot | null>(null);
  const [selectedNode, setSelectedNode] = useState<GraphNode | null>(null);
  const [enabledEdgeKinds, setEnabledEdgeKinds] = useState<Set<EdgeKind>>(new Set(ALL_EDGE_KINDS));
  const [enabledNodeKinds, setEnabledNodeKinds] = useState<Set<NodeKind>>(new Set(ALL_NODE_KINDS));

  useEffect(() => {
    getTimeline().then(setCommits).catch(console.error);
  }, []);

  useEffect(() => {
    const commit = commits[selectedIndex];
    if (!commit) return;
    getSnapshot(commit.hash).then(setSnapshot).catch(console.error);
  }, [commits, selectedIndex]);

  const selectNode = useCallback((node: GraphNode | null) => {
    setSelectedNode(node);
  }, []);

  const toggleEdgeKind = useCallback((kind: EdgeKind) => {
    setEnabledEdgeKinds((prev) => {
      const next = new Set(prev);
      if (next.has(kind)) next.delete(kind); else next.add(kind);
      return next;
    });
  }, []);

  const toggleNodeKind = useCallback((kind: NodeKind) => {
    setEnabledNodeKinds((prev) => {
      const next = new Set(prev);
      if (next.has(kind)) next.delete(kind); else next.add(kind);
      return next;
    });
  }, []);

  const selectedCommit = commits[selectedIndex];
  const activeNodeKindCount = enabledNodeKinds.size;
  const activeEdgeKindCount = enabledEdgeKinds.size;
  const visibleNodeCount = useMemo(
    () => getVisibleNodeCount(snapshot, enabledNodeKinds),
    [enabledNodeKinds, snapshot],
  );
  const visibleEdgeCount = useMemo(
    () => getVisibleEdgeCount(snapshot, enabledNodeKinds, enabledEdgeKinds),
    [enabledEdgeKinds, enabledNodeKinds, snapshot],
  );

  return (
    <main className="app-shell">
      <header className="topbar">
        <div className="brand-block">
          <span className="product-mark" aria-hidden="true">RS</span>
          <div>
            <h1>RepoStrata</h1>
            <p>Time-aware code knowledge graph</p>
          </div>
        </div>
        <div className="topbar-metrics" aria-label="当前图谱摘要">
          <div className="metric">
            <span>提交</span>
            <strong>{commits.length}</strong>
          </div>
          <div className="metric">
            <span>节点</span>
            <strong>{visibleNodeCount}</strong>
          </div>
          <div className="metric">
            <span>关系</span>
            <strong>{visibleEdgeCount}</strong>
          </div>
        </div>
        <Timeline
          commits={commits}
          selectedIndex={selectedIndex}
          onSelect={(index) => {
            setSelectedIndex(index);
            setSelectedNode(null);
          }}
        />
      </header>
      <section className="workspace">
        <FiltersPanel
          nodeCount={visibleNodeCount}
          edgeCount={visibleEdgeCount}
          enabledEdgeKinds={enabledEdgeKinds}
          onToggleEdgeKind={toggleEdgeKind}
          enabledNodeKinds={enabledNodeKinds}
          onToggleNodeKind={toggleNodeKind}
        />
        <section className="canvas">
          <div className="canvas-toolbar">
            <div>
              <span className="eyebrow">Snapshot</span>
              <h2>{selectedCommit ? selectedCommit.message : "暂无快照"}</h2>
            </div>
            <div className="canvas-meta">
              <span>{selectedCommit ? selectedCommit.hash.slice(0, 8) : "no commit"}</span>
              <span>{activeNodeKindCount}/{ALL_NODE_KINDS.length} 节点类型</span>
              <span>{activeEdgeKindCount}/{ALL_EDGE_KINDS.length} 边类型</span>
            </div>
          </div>
          <GraphCanvas
            snapshot={snapshot}
            selectedNode={selectedNode}
            onSelectNode={selectNode}
            enabledEdgeKinds={enabledEdgeKinds}
            enabledNodeKinds={enabledNodeKinds}
          />
        </section>
        <DetailsPanel node={selectedNode} />
      </section>
    </main>
  );
}
