# RepoStrata

RepoStrata 从 Git 仓库构建时序代码知识图谱，并通过本地 Dashboard 进行可视化探索。

它遍历提交历史，使用 tree-sitter 提取符号与关系，将结果存入 SQLite 图数据库，并通过 FastAPI 后端和 React + Cytoscape.js 前端提供服务。

## 环境要求

- Python 3.11+
- Node.js 22.12+（仅前端）
- [uv](https://github.com/astral-sh/uv)

## 安装

```bash
# 后端（含 tree-sitter 解析支持）
uv pip install -e ".[dev,parsing]"
```

## 使用方法

在目标仓库目录下依次执行三条命令：

```bash
# 1. 初始化 .repostrata/ 目录
repostrata init --repo /path/to/repo

# 2. 索引提交历史
repostrata index --repo /path/to/repo

# 3. 启动 Dashboard（默认：http://127.0.0.1:8765）
repostrata dashboard --repo /path/to/repo
```

若 `web/dist/` 目录存在，Dashboard 会直接提供构建好的前端页面。如需在开发模式下运行前端：

```bash
cd web
npm install
npm run dev   # http://127.0.0.1:5173
```

检查仓库是否已正确索引：

```bash
repostrata doctor --repo /path/to/repo
```

## 工作原理

对于仓库历史中的每一个提交，RepoStrata 执行以下步骤：

1. 读取变更文件，使用 tree-sitter 解析（支持 Python、TypeScript、JavaScript、TSX）
2. 提取**符号**（函数、类、方法）和**关系**（调用、包含、导入）
3. 与上一个提交的符号图做差分，生成**事件**（新增、变更、删除）
4. 记录同一提交中同时变更的符号之间的**共变边**
5. 保存该提交时刻完整图状态的**快照**

所有数据写入 `.repostrata/graph.db`（SQLite）。

## API 接口

| 方法 | 路径 | 说明 |
|------|------|------|
| GET | `/api/timeline` | 列出所有已索引的提交 |
| GET | `/api/symbols/search?q=` | 按名称搜索符号 |
| GET | `/api/snapshots/{commit_hash}` | 获取某个提交的图快照 |

## Agent tools

RepoStrata 可以通过本地 Codex plugin 将已索引仓库暴露给 agent 查询。

安装 Codex 插件：

```bash
repostrata codex install
```

检查安装状态：

```bash
repostrata codex doctor
```

然后启动本地 API：

```bash
repostrata dashboard --repo /path/to/repo --port 8765
```

Codex plugin 默认连接 `http://127.0.0.1:8765`，重启 Codex 后会暴露以下只读工具：

- `repostrata_status`
- `repostrata_search_symbols`
- `repostrata_get_symbol`
- `repostrata_get_symbol_neighborhood`
- `repostrata_get_symbol_history`

这些工具返回结构化结果、证据、截断状态和建议的后续查询。plugin 不会自动启动 RepoStrata；如果服务不可用，请先运行上面的 `repostrata dashboard` 命令。

卸载插件：

```bash
repostrata codex uninstall
```

## 开发

```bash
# 运行所有测试
uv run --extra dev --extra parsing pytest

# 运行单个测试文件
uv run --extra dev --extra parsing pytest tests/unit/test_extractors.py

# 构建前端
cd web && npm run build

# 前端类型检查
cd web && npm run typecheck

# 运行前端测试
cd web && npm test
```

## CI 与发布

项目包含 GitHub Actions 流水线：

- Pull request / `main` 推送：运行后端测试、前端类型检查、前端测试、前端构建，并构建 Python `sdist` / `wheel`
- `v*` tag 推送：复用 CI 验证与构建产物，校验版本号，上传 GitHub Release，并可通过 PyPI Trusted Publishing 发布

详细说明见 [docs/ci-release.md](docs/ci-release.md)。

## 配置

`repostrata init` 会在目标仓库中创建 `.repostrata/config.toml`：

```toml
[index]
languages = ["python", "typescript", "javascript"]
snapshot_strategy = "mixed"

[dashboard]
host = "127.0.0.1"
port = 8765
```
