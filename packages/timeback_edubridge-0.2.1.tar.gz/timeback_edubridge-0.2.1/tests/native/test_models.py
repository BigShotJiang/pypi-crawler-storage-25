"""Native tests for EduBridge models."""

from __future__ import annotations

import pytest
from pydantic import ValidationError

from timeback_edubridge import (
    Application,
    DefaultClass,
    Enrollment,
    HighestGradeMastered,
    MapProfile,
    SubjectTrack,
    SubjectTrackUpsertInput,
    TimeSaved,
    User,
)


def test_enrollment_parsing() -> None:
    enrollment = Enrollment.model_validate(
        {
            "id": "enroll-123",
            "role": "student",
            "beginDate": "2025-01-01",
            "endDate": "2025-06-30",
            "course": {"id": "course-456", "title": "Algebra 1", "metadata": {}},
            "school": {"id": "school-789", "name": "Test School"},
        }
    )
    assert enrollment.course.id == "course-456"
    assert enrollment.school.name == "Test School"


def test_default_class_parsing() -> None:
    default_class = DefaultClass.model_validate(
        {
            "id": "class-123",
            "title": "Default Class",
            "subjectCodes": ["MATH"],
            "subjects": ["Mathematics"],
            "periods": ["term-456"],
            "course": {"id": "course-789", "title": "Algebra 1", "metadata": {}},
        }
    )
    assert default_class.subject_codes == ["MATH"]


def test_user_parsing() -> None:
    user = User.model_validate(
        {
            "sourcedId": "user-123",
            "status": "active",
            "dateLastModified": "2025-01-01T00:00:00Z",
            "userIds": [{"type": "email", "identifier": "test@example.com"}],
            "enabledUser": "true",
            "givenName": "John",
            "familyName": "Doe",
            "roles": [],
            "agents": [],
            "userProfiles": [],
        }
    )
    assert user.sourced_id == "user-123"
    assert user.enabled_user == "true"


def test_highest_grade_mastered_parsing() -> None:
    result = HighestGradeMastered.model_validate(
        {
            "studentId": "student-123",
            "subject": "Math",
            "grades": {"ritGrade": 220, "highestGradeOverall": "8"},
        }
    )
    assert result.grades.rit_grade == 220


def test_misc_models_parsing() -> None:
    app = Application.model_validate(
        {"sourcedId": "app-123", "name": "Math", "domain": ["math.io"]}
    )
    track = SubjectTrack.model_validate(
        {
            "id": "track-123",
            "subject": "Math",
            "grade": "9",
            "course": {"sourcedId": "course-456", "title": "Algebra 1"},
        }
    )
    profile = MapProfile.model_validate({"userId": "user-123", "ritScore": 220})
    time_saved = TimeSaved.model_validate({"totalHoursSaved": 5})
    assert app.sourced_id == "app-123"
    assert track.course.sourced_id == "course-456"
    assert profile.rit_score == 220
    assert time_saved.total_hours_saved == 5


def test_subject_track_upsert_input_trims_non_empty_string_fields() -> None:
    model = SubjectTrackUpsertInput.model_validate(
        {
            "subject": "  Math  ",
            "grade": "  9  ",
            "courseId": "  course-123  ",
        }
    )

    assert model.subject == "Math"
    assert model.grade == "9"
    assert model.course_id == "course-123"


def test_subject_track_upsert_input_rejects_whitespace_only_course_id() -> None:
    with pytest.raises(ValidationError):
        SubjectTrackUpsertInput.model_validate(
            {
                "subject": "Math",
                "grade": "9",
                "courseId": "   ",
            }
        )
