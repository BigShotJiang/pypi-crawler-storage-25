from __future__ import annotations

import torch


def resolve_auto_model_device(device: str | None, *, model_kind: str = "ASR") -> str:
    """Resolve the backend device for FunASR AutoModel.

    When the caller does not provide an explicit device, prefer GPU 0 if CUDA
    is available, otherwise fall back to CPU and warn the user.
    """
    if device is not None:
        return device
    if torch.cuda.is_available():
        selected_device = "cuda:0"
        return selected_device
    from loguru import logger

    logger.warning(
        "{} did not detect a GPU, falling back to CPU.",
        model_kind,
    )
    return "cpu"
