from pathlib import Path
from typing import List

from funasr import AutoModel
from pydantic import ConfigDict, Field
from typing_extensions import Self

from fasr.config import Config, registry
from fasr.data import AudioSpan, AudioToken, AudioTokenList
from fasr.model import ASRModel

from .device import resolve_auto_model_device


def _apply_paraformer_result(span: AudioSpan, result: dict) -> None:
    """Populate ``span.raw_text`` and ``span.tokens`` from one funasr result.

    The paraformer family returns space-joined recognized tokens together with
    a parallel list of ``[start_ms, end_ms]`` pairs, relative to the span
    waveform. We materialise both:

    * ``raw_text`` mirrors the full-utterance string (space-joined in the mixed
      language case, single Chinese string in the zh case) so that callers who
      just want text can read ``span.text`` directly;
    * ``tokens`` carries per-token timestamps shifted by ``span.start_ms`` so
      the recognizer component no longer needs to offset them itself.
    """
    raw_text = result.get("text") or ""
    span.raw_text = raw_text
    timestamps = result.get("timestamp") or []
    if not raw_text or not timestamps:
        span.tokens = None
        return
    texts = raw_text.split(" ")
    assert len(texts) == len(timestamps), (
        f"Texts and timestamps have different lengths: {len(texts)} != {len(timestamps)}"
    )
    offset_ms = int(span.start_ms or 0)
    tokens = AudioTokenList()
    for token_text, timestamp in zip(texts, timestamps):
        start_ms = int(timestamp[0]) + offset_ms
        end_ms = int(timestamp[1]) + offset_ms
        token = AudioToken(text=token_text, start_ms=start_ms, end_ms=end_ms)
        assert token.end_ms - token.start_ms > 0, f"{token}"
        tokens.append(token)
    span.tokens = tokens


class _ParaformerBase(ASRModel):
    """Shared runtime settings for the paraformer family."""

    device: str | None = Field(
        default=None,
        description=(
            "AutoModel device, e.g. `cuda:0` or `cpu`. "
            "When omitted, the model auto-selects GPU 0 if available."
        ),
    )
    disable_update: bool = Field(
        default=True,
        description="Forwarded to `funasr.AutoModel`; skip the built-in checkpoint update check.",
    )
    disable_log: bool = Field(
        default=True,
        description="Forwarded to `funasr.AutoModel`; silence backend logs.",
    )
    disable_pbar: bool = Field(
        default=True,
        description="Forwarded to `funasr.AutoModel`; disable tqdm progress bars.",
    )
    batch_size: int = Field(
        default=10000, ge=1, description="Inference batch size forwarded to funasr."
    )

    model_config = ConfigDict(arbitrary_types_allowed=True, validate_assignment=True)

    def _resolve_checkpoint(self, checkpoint_dir: str | Path | None) -> Path:
        if checkpoint_dir is None:
            if self.checkpoint is None:
                raise ValueError(
                    "Either `checkpoint_dir` or `self.checkpoint` must be set."
                )
            self.download_checkpoint()
            checkpoint_dir = self.checkpoint_dir
        path = Path(checkpoint_dir)
        if not path.exists():
            raise FileNotFoundError(f"Checkpoint not found: {path}")
        return path

    def _resolve_device(self) -> str:
        return resolve_auto_model_device(self.device)


class Paraformer(_ParaformerBase):
    checkpoint: str = "iic/speech_paraformer-large-vad-punc_asr_nat-zh-cn-16k-common-vocab8404-pytorch"
    endpoint: str = "modelscope"

    paraformer: AutoModel | None = Field(
        default=None,
        exclude=True,
        description="Underlying funasr AutoModel handle populated by `load_checkpoint`.",
    )

    def transcribe(self, batch: List[AudioSpan], **kwargs) -> List[AudioSpan]:
        if self.paraformer is None:
            raise RuntimeError(
                "Model is not initialized, call load_checkpoint() first."
            )
        if not batch:
            return batch
        fs = int(batch[0].waveform.sample_rate)
        inputs = [span.waveform.data for span in batch]
        results = self.paraformer.generate(input=inputs, fs=fs)
        for span, result in zip(batch, results):
            _apply_paraformer_result(span, result)
        return batch

    def load_checkpoint(self, checkpoint_dir: str | Path | None = None) -> Self:
        """Load the paraformer model from a local checkpoint directory."""
        path = self._resolve_checkpoint(checkpoint_dir)
        device = self._resolve_device()
        self.paraformer = AutoModel(
            model=str(path),
            device=device,
            disable_update=self.disable_update,
            disable_log=self.disable_log,
            disable_pbar=self.disable_pbar,
        )
        self.paraformer.kwargs["batch_size"] = self.batch_size
        return self

    def get_config(self) -> Config:
        return Config(
            data={
                "asr_model": {
                    "@asr_models": "paraformer",
                    "checkpoint": self.checkpoint,
                    "endpoint": self.endpoint,
                    "device": self.device,
                    "batch_size": self.batch_size,
                }
            }
        )


@registry.asr_models.register("paraformer")
def paraformer_entrypoint(
    device: str | None = None,
    disable_update: bool = True,
    disable_log: bool = True,
    disable_pbar: bool = True,
    batch_size: int = 10000,
    **kwargs,
) -> Paraformer:
    return Paraformer(
        device=device,
        disable_update=disable_update,
        disable_log=disable_log,
        disable_pbar=disable_pbar,
        batch_size=batch_size,
        **kwargs,
    )


@registry.asr_models.register("seaco_paraformer")
class SeacoParaformer(_ParaformerBase):
    checkpoint: str = (
        "iic/speech_seaco_paraformer_large_asr_nat-zh-cn-16k-common-vocab8404-pytorch"
    )
    endpoint: str = "modelscope"

    seaco_paraformer: AutoModel | None = Field(
        default=None,
        exclude=True,
        description="Underlying funasr AutoModel (Seaco paraformer) handle populated by `load_checkpoint`.",
    )

    def transcribe(self, batch: List[AudioSpan], **kwargs) -> List[AudioSpan]:
        if self.seaco_paraformer is None:
            raise RuntimeError(
                "Model is not initialized, call load_checkpoint() first."
            )
        if not batch:
            return batch
        fs = int(batch[0].waveform.sample_rate)
        inputs = [span.waveform.data for span in batch]
        hotwords = kwargs.get("hotwords", None)
        hotword = " ".join(hotwords) if hotwords else None
        results = self.seaco_paraformer.generate(input=inputs, fs=fs, hotword=hotword)
        for span, result in zip(batch, results):
            _apply_paraformer_result(span, result)
        return batch

    def load_checkpoint(self, checkpoint_dir: str | Path | None = None) -> Self:
        """Load the Seaco paraformer model (with hotword support) from a checkpoint."""
        path = self._resolve_checkpoint(checkpoint_dir)
        device = self._resolve_device()
        self.seaco_paraformer = AutoModel(
            model=str(path),
            device=device,
            disable_update=self.disable_update,
            disable_log=self.disable_log,
            disable_pbar=self.disable_pbar,
        )
        self.seaco_paraformer.model.generate_hotwords_list = self.generate_hotwords
        self.seaco_paraformer.kwargs["batch_size"] = self.batch_size
        return self

    def generate_hotwords(
        self, hotword_list_or_file: str | None = None, **kwargs
    ) -> List[List[int]] | None:
        """Generate hotwords list.

        Args:
            hotword_list_or_file (str): Hotword string, e.g. "hello world".
        """
        if not hotword_list_or_file:
            return None
        hotwords = hotword_list_or_file.strip().split(" ")
        if len(hotwords) == 0:
            return None
        all_ids = []
        for hotword in hotwords:
            tokens = [
                s for s in hotword
            ]  # todo: better tokenization. now it's just char-level.
            all_ids.append(self.tokens2ids(tokens))
        all_ids.append(self.tokens2ids(["<s>"]))
        return all_ids

    def tokens2ids(self, tokens: List[AudioToken], **kwargs) -> List[int]:
        return self.tokenizer.tokens2ids(tokens)

    @property
    def tokenizer(self):
        return self.seaco_paraformer.kwargs["tokenizer"]

    def get_config(self) -> Config:
        return Config(
            data={
                "asr_model": {
                    "@asr_models": "seaco_paraformer",
                    "checkpoint": self.checkpoint,
                    "endpoint": self.endpoint,
                    "device": self.device,
                    "batch_size": self.batch_size,
                }
            }
        )


@registry.asr_models.register("seaco_paraformer")
def seaco_paraformer_entrypoint(
    device: str | None = None,
    disable_update: bool = True,
    disable_log: bool = True,
    disable_pbar: bool = True,
    batch_size: int = 10000,
    **kwargs,
) -> SeacoParaformer:
    return SeacoParaformer(
        device=device,
        disable_update=disable_update,
        disable_log=disable_log,
        disable_pbar=disable_pbar,
        batch_size=batch_size,
        **kwargs,
    )
