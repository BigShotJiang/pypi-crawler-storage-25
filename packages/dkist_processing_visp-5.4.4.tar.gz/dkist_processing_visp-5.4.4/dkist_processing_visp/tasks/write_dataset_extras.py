"""Transform data written in other pipeline tasks into dataset extras for delivery alongside L1 science data."""

from functools import cached_property

from dkist_processing_common.codecs.fits import fits_array_decoder
from dkist_processing_common.codecs.json import json_decoder
from dkist_processing_common.models.extras import DatasetExtraHeaderSection
from dkist_processing_common.models.extras import DatasetExtraType
from dkist_processing_common.models.tags import EXP_TIME_ROUND_DIGITS
from dkist_processing_common.models.task_name import TaskName
from dkist_processing_common.tasks.write_extra import WriteL1DatasetExtras
from dkist_service_configuration.logging import logger

from dkist_processing_visp.models.constants import VispConstants
from dkist_processing_visp.models.dataset_extras import VispDatasetExtraHeaderData
from dkist_processing_visp.models.parameters import VispParameters
from dkist_processing_visp.models.tags import VispTag
from dkist_processing_visp.parsers.spectrograph_configuration import (
    convert_incident_light_angle_to_grating_angle,
)
from dkist_processing_visp.parsers.spectrograph_configuration import (
    convert_light_angles_to_arm_position_angle,
)


class VispWriteL1DatasetExtras(WriteL1DatasetExtras):
    """Write the dataset extra files."""

    @property
    def constants_model_class(self):
        """Get the task constants."""
        return VispConstants

    def __init__(self, recipe_run_id, workflow_name, workflow_version):
        super().__init__(
            recipe_run_id=recipe_run_id,
            workflow_name=workflow_name,
            workflow_version=workflow_version,
        )
        self.parameters = VispParameters(
            scratch=self.scratch,
            obs_ip_start_time=self.constants.obs_ip_start_time,
            wavelength=self.constants.wavelength,
            arm_id=self.constants.arm_id,
        )

    def run(self):
        """
        Write the dataset extras.

        * Gather the source data
        * Build the dataset extra filename and header
        * Write the dataset extra
        """
        visp_dataset_extras = self.create_dataset_extra_object_list()

        for extra in visp_dataset_extras:
            with self.telemetry_span(
                f"Writing {extra.extra_name} dataset extra for {'_'.join(extra.filename_detail)}"
                if extra.filename_detail
                else f"Writing {extra.extra_name} dataset extra"
            ):

                # 1. Get intermediate frame to turn into a dataset extra
                data_count = self.count(tags=extra.data_tags)
                if data_count == 0:
                    logger.info(
                        f"WARNING: No data found for {extra.extra_name} dataset extra "
                        f"with tags={extra.data_tags}. Skipping and moving on."
                    )
                    continue
                if data_count > 1:
                    logger.info(
                        f"WARNING: {data_count} files found for {extra.extra_name} dataset extra "
                        f"with tags={extra.data_tags}. Using the first one."
                    )
                data = next(
                    self.read(tags=extra.data_tags, decoder=fits_array_decoder, memmap=True)
                )

                # 2. Build the dataset extra filename and header
                extra.filename = self.format_extra_filename(
                    extra_name=extra.extra_name,
                    detail="_".join(extra.filename_detail),
                )
                header = self.build_dataset_extra_header(
                    sections=extra.header_sections, header_data=extra
                )

                # 3. Write the dataset extra
                self.assemble_and_write_dataset_extra(
                    data=data, header=header, filename=extra.filename
                )

    @cached_property
    def wavecal_solution(self):
        """Return the wavelength calibration solution."""
        solution = next(
            self.read(
                tags=[VispTag.task_wavelength_calibration(), VispTag.intermediate()],
                decoder=json_decoder,
            )
        )
        return solution

    def dataset_extra_headers(self, header_data: VispDatasetExtraHeaderData) -> dict:
        """Override the method from WriteL1DatasetExtras to include additional header sections."""
        headers = super().dataset_extra_headers(header_data=header_data)

        # Add wavecal, atlas, and visp sections:
        headers.update(
            {
                DatasetExtraHeaderSection.wavecal: {
                    "CTYPE1": self.wavecal_solution.get("CTYPE1")
                    or self.wavecal_solution.get("CTYPE2"),
                    "CUNIT1": self.wavecal_solution.get("CUNIT1")
                    or self.wavecal_solution.get("CUNIT2"),
                    "CRPIX1": self.wavecal_solution.get("CRPIX1")
                    or self.wavecal_solution.get("CRPIX2"),
                    "CDELT1": self.wavecal_solution.get("CDELT1")
                    or self.wavecal_solution.get("CDELT2"),
                    "PV1_0": self.wavecal_solution.get("PV1_0")
                    or self.wavecal_solution.get("PV2_0"),
                    "PV1_1": self.wavecal_solution.get("PV1_1")
                    or self.wavecal_solution.get("PV2_1"),
                    "PV1_2": self.wavecal_solution.get("PV1_2")
                    or self.wavecal_solution.get("PV2_2"),
                },
                DatasetExtraHeaderSection.atlas: {
                    "ATLASURL": self.parameters.wavecal_atlas_download_config.base_url,
                },
                DatasetExtraHeaderSection.visp: {
                    "VSPARMID": int(self.constants.arm_id),
                    "VSPPOLMD": self.constants.polarimeter_mode,
                    "VSPNUMST": self.constants.num_modstates,
                    "VSPGRTAN": convert_incident_light_angle_to_grating_angle(
                        incident_light_angle=self.constants.incident_light_angle_deg.value,
                    ),
                    "VSPARMPS": convert_light_angles_to_arm_position_angle(
                        reflected_light_angle=self.constants.reflected_light_angle_deg.value,
                        incident_light_angle=self.constants.incident_light_angle_deg.value,
                    ),
                    "VSPGRTCN": self.constants.grating_constant_inverse_mm.value,
                    "VSPSTNUM": header_data.modstate,
                    "VSPBEAM": header_data.beam,
                },
            }
        )
        return headers

    def create_dataset_extra_object_list(self):
        """Create a list of VispDatasetExtraHeaderData objects."""
        visp_dataset_extras = []
        visp_dataset_extras += [
            self.build_wavelength_calibration_input_spectrum_dataset_extra_data(),
            self.build_wavelength_calibration_reference_spectrum_dataset_extra_data(),
            self.build_reference_wavelength_vector_dataset_extra_data(),
        ]
        for beam in range(1, self.constants.num_beams + 1):
            visp_dataset_extras += [
                self.build_solar_gain_dataset_extra_data(beam=beam),
                self.build_characteristic_spectra_dataset_extra_data(beam=beam),
                self.build_beam_angles_dataset_extra_data(beam=beam),
                self.build_spectral_curvature_shifts_dataset_extra_data(beam=beam),
            ]
            for readout_exp_time in self.constants.dark_readout_exp_times:
                visp_dataset_extras += [
                    self.build_dark_dataset_extra_data(beam=beam, readout_exp_time=readout_exp_time)
                ]
            for modstate in range(1, self.constants.num_modstates + 1):
                visp_dataset_extras += [
                    self.build_modulation_state_offsets_dataset_extra_data(
                        beam=beam, modstate=modstate
                    )
                ]
            if self.constants.correct_for_polarization:
                visp_dataset_extras += [
                    self.build_demodulation_matrices_dataset_extra_data(beam=beam)
                ]
                if self.parameters.background_on:
                    visp_dataset_extras += [
                        self.build_background_light_dataset_extra_data(beam=beam)
                    ]
        if self.constants.correct_for_polarization:
            for cs_step in range(self.constants.num_cs_steps):
                for cs_step_frame in range(self.constants.num_frames_per_cs_step):
                    for stokes in self.constants.stokes_params:
                        visp_dataset_extras += [
                            self.build_polcal_as_science_dataset_extra_data(
                                cs_step=cs_step, cs_step_frame=cs_step_frame, stokes=stokes
                            )
                        ]

        return visp_dataset_extras

    def build_dark_dataset_extra_data(
        self, beam: int, readout_exp_time: float
    ) -> VispDatasetExtraHeaderData:
        """Return VispDatasetExtraHeaderData for dark frames."""
        return VispDatasetExtraHeaderData(
            beam=beam,
            readout_exposure=readout_exp_time,
            extra_name=DatasetExtraType.dark,
            task_type=TaskName.dark,
            total_exposure=self.constants.dark_readout_to_total_exp_times_lookup[
                round(readout_exp_time, EXP_TIME_ROUND_DIGITS)
            ],
            end_time=self.constants.dark_date_end,
            data_tags=VispTag.intermediate_frame_dark(beam=beam, readout_exp_time=readout_exp_time),
            filename_detail=[
                VispTag.beam(beam),
                VispTag.readout_exp_time(readout_exp_time),
            ],
        )

    def build_modulation_state_offsets_dataset_extra_data(
        self, beam: int, modstate: int
    ) -> VispDatasetExtraHeaderData:
        """Return VispDatasetExtraHeaderData for modulation state offsets."""
        return VispDatasetExtraHeaderData(
            beam=beam,
            modstate=modstate,
            extra_name=DatasetExtraType.modulation_state_offsets,
            task_type=TaskName.solar_gain,
            readout_exposure=self.constants.solar_readout_exp_times,
            total_exposure=self.constants.solar_exposure_times,
            end_time=self.constants.solar_gain_date_end,
            data_tags=[
                VispTag.intermediate_frame(beam=beam, modstate=modstate),
                VispTag.task_geometric_offset(),
            ],
            filename_detail=[VispTag.beam(beam), VispTag.modstate(modstate)],
        )

    def build_solar_gain_dataset_extra_data(self, beam: int) -> VispDatasetExtraHeaderData:
        """Return VispDatasetExtraHeaderData for solar gains."""
        return VispDatasetExtraHeaderData(
            beam=beam,
            extra_name=DatasetExtraType.solar_gain,
            task_type=TaskName.solar_gain,
            readout_exposure=self.constants.solar_readout_exp_times,
            total_exposure=self.constants.solar_exposure_times,
            end_time=self.constants.solar_gain_date_end,
            data_tags=[VispTag.intermediate_frame(beam=beam), VispTag.task_solar_gain()],
            filename_detail=[VispTag.beam(beam)],
        )

    def build_characteristic_spectra_dataset_extra_data(
        self, beam: int
    ) -> VispDatasetExtraHeaderData:
        """Return VispDatasetExtraHeaderData for characteristic spectra."""
        return VispDatasetExtraHeaderData(
            beam=beam,
            extra_name=DatasetExtraType.characteristic_spectra,
            task_type=TaskName.solar_gain,
            readout_exposure=self.constants.solar_readout_exp_times,
            total_exposure=self.constants.solar_exposure_times,
            end_time=self.constants.solar_gain_date_end,
            data_tags=[
                VispTag.intermediate_frame(beam=beam),
                VispTag.task_characteristic_spectra(),
            ],
            filename_detail=[VispTag.beam(beam)],
        )

    def build_beam_angles_dataset_extra_data(self, beam: int) -> VispDatasetExtraHeaderData:
        """Return VispDatasetExtraHeaderData for beam angles."""
        return VispDatasetExtraHeaderData(
            beam=beam,
            extra_name=DatasetExtraType.beam_angles,
            task_type=TaskName.solar_gain,
            readout_exposure=self.constants.solar_readout_exp_times,
            total_exposure=self.constants.solar_exposure_times,
            end_time=self.constants.solar_gain_date_end,
            data_tags=[
                VispTag.intermediate_frame(beam=beam),
                VispTag.task_geometric_angle(),
            ],
            filename_detail=[VispTag.beam(beam)],
        )

    def build_spectral_curvature_shifts_dataset_extra_data(
        self, beam: int
    ) -> VispDatasetExtraHeaderData:
        """Return VispDatasetExtraHeaderData for spectral curvature shifts."""
        return VispDatasetExtraHeaderData(
            beam=beam,
            extra_name=DatasetExtraType.spectral_curvature_shifts,
            task_type=TaskName.solar_gain,
            readout_exposure=self.constants.solar_readout_exp_times,
            total_exposure=self.constants.solar_exposure_times,
            end_time=self.constants.solar_gain_date_end,
            data_tags=[
                VispTag.intermediate_frame(beam=beam),
                VispTag.task_geometric_spectral_shifts(),
            ],
            filename_detail=[VispTag.beam(beam)],
        )

    def build_background_light_dataset_extra_data(self, beam: int) -> VispDatasetExtraHeaderData:
        """Return VispDatasetExtraHeaderData for background light."""
        return VispDatasetExtraHeaderData(
            beam=beam,
            extra_name=DatasetExtraType.background_light,
            task_type=TaskName.polcal,
            readout_exposure=self.constants.polcal_readout_exp_times,
            total_exposure=self.constants.polcal_exposure_times,
            end_time=self.constants.polcal_date_end,
            data_tags=[
                VispTag.intermediate_frame(beam=beam),
                VispTag.task_background(),
            ],
            filename_detail=[VispTag.beam(beam)],
        )

    def build_demodulation_matrices_dataset_extra_data(
        self, beam: int
    ) -> VispDatasetExtraHeaderData:
        """Return VispDatasetExtraHeaderData for demodulation matrices."""
        return VispDatasetExtraHeaderData(
            beam=beam,
            extra_name=DatasetExtraType.demodulation_matrices,
            task_type=TaskName.polcal,
            readout_exposure=self.constants.polcal_readout_exp_times,
            total_exposure=self.constants.polcal_exposure_times,
            end_time=self.constants.polcal_date_end,
            data_tags=[
                VispTag.intermediate_frame(beam=beam),
                VispTag.task_demodulation_matrices(),
            ],
            header_sections=[
                DatasetExtraHeaderSection.common,
                DatasetExtraHeaderSection.iptask,
                DatasetExtraHeaderSection.aggregate,
                DatasetExtraHeaderSection.visp,
            ],
            filename_detail=[VispTag.beam(beam)],
        )

    def build_wavelength_calibration_input_spectrum_dataset_extra_data(self):
        """Return VispDatasetExtraHeaderData for wavelength calibration input spectrum."""
        return VispDatasetExtraHeaderData(
            extra_name=DatasetExtraType.wavelength_calibration_input_spectrum,
            task_type=TaskName.solar_gain,
            readout_exposure=self.constants.solar_readout_exp_times,
            total_exposure=self.constants.solar_exposure_times,
            end_time=self.constants.solar_gain_date_end,
            data_tags=[
                VispTag.intermediate(),
                VispTag.task_wavelength_calibration_input_spectrum(),
            ],
        )

    def build_wavelength_calibration_reference_spectrum_dataset_extra_data(self):
        """Return VispDatasetExtraHeaderData for wavelength calibration reference spectrum."""
        return VispDatasetExtraHeaderData(
            extra_name=DatasetExtraType.wavelength_calibration_reference_spectrum,
            task_type=TaskName.solar_gain,
            readout_exposure=self.constants.solar_readout_exp_times,
            total_exposure=self.constants.solar_exposure_times,
            end_time=self.constants.solar_gain_date_end,
            data_tags=[
                VispTag.intermediate(),
                VispTag.task_wavelength_calibration_reference_spectrum(),
            ],
            header_sections=[
                DatasetExtraHeaderSection.common,
                DatasetExtraHeaderSection.atlas,
                DatasetExtraHeaderSection.visp,
            ],
        )

    def build_reference_wavelength_vector_dataset_extra_data(self):
        """Return VispDatasetExtraHeaderData for reference wavelength vector."""
        return VispDatasetExtraHeaderData(
            extra_name=DatasetExtraType.reference_wavelength_vector,
            task_type=TaskName.solar_gain,
            readout_exposure=self.constants.solar_readout_exp_times,
            total_exposure=self.constants.solar_exposure_times,
            end_time=self.constants.solar_gain_date_end,
            data_tags=[
                VispTag.intermediate(),
                VispTag.task_wavelength_calibration_reference_wavelength_vector(),
            ],
            header_sections=[
                DatasetExtraHeaderSection.common,
                DatasetExtraHeaderSection.wavecal,
                DatasetExtraHeaderSection.visp,
            ],
        )

    def build_polcal_as_science_dataset_extra_data(
        self, cs_step: int, cs_step_frame: int, stokes: str
    ) -> VispDatasetExtraHeaderData:
        """Return VispDatasetExtraHeaderData for polcal as science."""
        return VispDatasetExtraHeaderData(
            extra_name=DatasetExtraType.polcal_as_science,
            task_type=TaskName.polcal,
            readout_exposure=self.constants.polcal_readout_exp_times,
            total_exposure=self.constants.polcal_exposure_times,
            end_time=self.constants.polcal_date_end,
            data_tags=[
                VispTag.task(TaskName.polcal_as_science),
                VispTag.cs_step(cs_step),
                VispTag.cs_step_frame(cs_step_frame),
                VispTag.stokes(stokes),
            ],
            header_sections=[
                DatasetExtraHeaderSection.common,
                DatasetExtraHeaderSection.iptask,
                DatasetExtraHeaderSection.gos,
                DatasetExtraHeaderSection.pcas,
                DatasetExtraHeaderSection.visp,
            ],
            filename_detail=[
                VispTag.cs_step(cs_step),
                VispTag.cs_step_frame(cs_step_frame),
                VispTag.stokes(stokes),
            ],
            num_cs_steps=self.constants.num_cs_steps,
            cs_step=cs_step,
            num_frames_per_cs_step=self.constants.num_frames_per_cs_step,
            frame_in_cs_step=cs_step_frame,
            stokes=stokes,
        )
