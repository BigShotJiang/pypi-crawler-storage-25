"""Perform calibration of the polcal frames as though they were observe frames."""

from dkist_processing_common.models.constants import BudName
from dkist_processing_common.models.task_name import TaskName
from dkist_service_configuration.logging import logger

from dkist_processing_visp.models.constants import VispConstants
from dkist_processing_visp.models.tags import VispTag
from dkist_processing_visp.tasks import ScienceCalibration


class VispPCASConstants(VispConstants):
    """
    Constants subclass to hold override constant values for use in the PCAS task.

    To run polcal frames as science frames, we co-opt existing loops in the ScienceCalibration
    task: the map scan loops are used for CS steps, and the raster step loops are used for the
    frames in CS steps.

    Because loops run until the constants for number of values, we override the existing loop
    constants with the corresponding constants for the polcal frame loops.
    """

    @property
    def num_map_scans(self) -> int:
        """Return the number of CS steps."""
        return self._db_dict[BudName.num_cs_steps.value]

    @property
    def num_raster_steps(self) -> int:
        """Return the number of frames per CS steps."""
        return self._db_dict[BudName.num_frames_per_cs_step.value]


class PolcalAsScienceCalibration(ScienceCalibration):
    """
    Task class for ViSP science-like calibration of polcal input frames.

    Parameters
    ----------
    recipe_run_id : int
        id of the recipe run used to identify the workflow run this task is part of
    workflow_name : str
        name of the workflow to which this instance of the task belongs
    workflow_version : str
        version of the workflow to which this instance of the task belongs
    """

    record_provenance = False

    @property
    def constants_model_class(self):
        """Get ViSP pipeline constants."""
        return VispPCASConstants

    def run(self):
        """Only run the task if the instrument is running in polarization mode."""
        if self.constants.correct_for_polarization:
            with self.telemetry_span("Loading calibration objects for PCAS"):
                calibrations = self.collect_calibration_objects()

            with self.telemetry_span(
                f"Processing PCAS frames for "
                f"{self.constants.num_map_scans} CS steps and "
                f"{self.constants.num_raster_steps} frames per CS step"
            ):
                self.process_frames(calibrations=calibrations)
        else:
            logger.info(
                "Instrument running in intensity mode - no polcal as science calibration to perform."
            )

    def build_input_frame_tags(
        self,
        modstate: int,
        map_scan: int,
        raster_step: int,
        readout_exp_time: float,
    ) -> list[str]:
        """
        Return list of tags to mark polcal as observe frame.

        ScienceCalibration loops over map_scan and raster_step, which we co-opt for CS step and
        frame in CS step, respectively.  CS step and CS step frame are zero indexed.
        """
        tags = [
            VispTag.task_polcal(),
            VispTag.modstate(modstate),
            VispTag.cs_step(map_scan - 1),
            VispTag.cs_step_frame(raster_step),
            VispTag.readout_exp_time(readout_exp_time),
        ]
        return tags

    def build_calibrated_frame_tags(
        self,
        stokes: str,
        raster_step: int,
        map_scan: int,
    ) -> list[str]:
        """
        Output tags to prepare output data for later use in the dataset extras.

        ScienceCalibration loops over map_scan and raster_step, which we co-opt for CS step and
        frame in CS step, respectively.  Use a different set of tags for the final outputs to
        prevent collisions with observe outputs.  CS step and CS step frame are zero indexed.
        """
        tags = [
            VispTag.task(TaskName.polcal_as_science),
            VispTag.stokes(stokes),
            VispTag.cs_step(map_scan - 1),
            VispTag.cs_step_frame(raster_step),
        ]
        return tags
