"""NTRU-style experiments over finite group algebras.

This package generalizes the classical NTRU ring ``Z[x]/(x^N - 1)`` to
group algebras ``Z[G]`` with an explicit left-sided convention for
noncommutative groups.
"""

from .core import (
    EXPERIMENT_PROFILES,
    AutoBackend,
    FiniteGroup,
    GroupAlgebraNTRU,
    NaiveBackend,
    make_group,
    run_experiment,
    verify_cyclic_group_algebra_model,
)

__all__ = [
    "EXPERIMENT_PROFILES",
    "AutoBackend",
    "FiniteGroup",
    "GroupAlgebraNTRU",
    "NaiveBackend",
    "make_group",
    "run_experiment",
    "verify_cyclic_group_algebra_model",
]
