"""Command-line entry point for NTRU group algebra experiments."""

from .core import main


if __name__ == "__main__":
    main()
