"""Pure-Python NTRU-style experiments over finite group algebras.

Classical NTRU works in ``Z[x]/(x^N - 1)``, which is the group algebra
``Z[C_N]``.  This module replaces the cyclic group by a finite group ``G`` and
works with coefficient vectors in ``Z[G]``.

For noncommutative groups we use a fixed left-sided convention:

    h = f^{-1} g mod q,     e = p h r + m mod q,

then decrypt by multiplying by ``f`` on the left:

    f e = p g r + f m mod q.

After center lifting, multiplication by ``f^{-1}`` modulo ``p`` recovers the
message, provided coefficients have not wrapped modulo ``q``.
"""

from __future__ import annotations

import argparse
import itertools
import math
import random
import sys
import time
from dataclasses import dataclass
from functools import lru_cache
from typing import Sequence


DEFAULT_SINGLE_PARAMS = {
    "cyclic": (7, 3, 41, 2),
    "symmetric": (3, 5, 67, 2),
    "dihedral": (4, 5, 127, 2),
}


DEFAULT_EXPERIMENTS = [
    {
        "name": "classical cyclic C7",
        "group": "cyclic",
        "n": 7,
        "p": 3,
        "q": 41,
        "d": 2,
        "trials": 8,
    },
    {
        "name": "wider cyclic C11",
        "group": "cyclic",
        "n": 11,
        "p": 3,
        "q": 127,
        "d": 2,
        "trials": 8,
    },
    {
        "name": "symmetric S3",
        "group": "symmetric",
        "n": 3,
        "p": 5,
        "q": 67,
        "d": 2,
        "trials": 8,
    },
    {
        "name": "dihedral D4",
        "group": "dihedral",
        "n": 4,
        "p": 5,
        "q": 127,
        "d": 2,
        "trials": 8,
    },
    {
        "name": "symmetric S4",
        "group": "symmetric",
        "n": 4,
        "p": 5,
        "q": 257,
        "d": 3,
        "trials": 3,
    },
]


EXPERIMENT_PROFILES = {
    "quick": DEFAULT_EXPERIMENTS,
    "larger": [
        {
            "name": "cyclic C31",
            "group": "cyclic",
            "n": 31,
            "p": 3,
            "q": 2048,
            "d": 5,
            "trials": 10,
        },
        {
            "name": "cyclic C61",
            "group": "cyclic",
            "n": 61,
            "p": 3,
            "q": 2048,
            "d": 10,
            "trials": 10,
        },
        {
            "name": "cyclic C101",
            "group": "cyclic",
            "n": 101,
            "p": 3,
            "q": 2048,
            "d": 16,
            "trials": 6,
        },
        {
            "name": "dihedral D16",
            "group": "dihedral",
            "n": 16,
            "p": 3,
            "q": 2048,
            "d": 5,
            "trials": 8,
        },
        {
            "name": "dihedral D32",
            "group": "dihedral",
            "n": 32,
            "p": 3,
            "q": 2048,
            "d": 10,
            "trials": 6,
        },
        {
            "name": "dihedral D64",
            "group": "dihedral",
            "n": 64,
            "p": 3,
            "q": 4096,
            "d": 16,
            "trials": 4,
        },
        {
            "name": "symmetric S4",
            "group": "symmetric",
            "n": 4,
            "p": 5,
            "q": 2048,
            "d": 4,
            "trials": 6,
        },
        {
            "name": "symmetric S5",
            "group": "symmetric",
            "n": 5,
            "p": 7,
            "q": 4099,
            "d": 15,
            "trials": 2,
        },
    ],
    "fft": [
        {
            "name": "dihedral D64 over FFT prime",
            "group": "dihedral",
            "n": 64,
            "p": 3,
            "q": 2_013_265_921,
            "d": 16,
            "trials": 4,
        },
        {
            "name": "dihedral D256 over FFT prime",
            "group": "dihedral",
            "n": 256,
            "p": 3,
            "q": 2_013_265_921,
            "d": 64,
            "trials": 2,
        },
        {
            "name": "symmetric S5 over prime fields",
            "group": "symmetric",
            "n": 5,
            "p": 7,
            "q": 4099,
            "d": 15,
            "trials": 5,
        },
    ],
    "stress": [
        {
            "name": "cyclic C509",
            "group": "cyclic",
            "n": 509,
            "p": 3,
            "q": 2048,
            "d": 85,
            "trials": 2,
        },
        {
            "name": "dihedral D128",
            "group": "dihedral",
            "n": 128,
            "p": 3,
            "q": 4096,
            "d": 32,
            "trials": 2,
        },
        {
            "name": "dihedral D256",
            "group": "dihedral",
            "n": 256,
            "p": 3,
            "q": 8192,
            "d": 64,
            "trials": 1,
        },
        {
            "name": "symmetric S5",
            "group": "symmetric",
            "n": 5,
            "p": 7,
            "q": 4099,
            "d": 15,
            "trials": 5,
        },
    ],
}


def is_prime(value: int) -> bool:
    """Return whether ``value`` is prime using deterministic Miller-Rabin."""

    value = int(value)
    if value < 2:
        return False
    small_primes = (2, 3, 5, 7, 11, 13, 17, 19, 23, 29, 31, 37)
    for prime in small_primes:
        if value == prime:
            return True
        if value % prime == 0:
            return False

    d = value - 1
    s = 0
    while d % 2 == 0:
        s += 1
        d //= 2

    # Deterministic for values below 2^64; plenty for these experiments.
    for base in (2, 3, 5, 7, 11, 13, 17, 19, 23, 29, 31, 37):
        if base >= value:
            continue
        x = pow(base, d, value)
        if x == 1 or x == value - 1:
            continue
        for _ in range(s - 1):
            x = (x * x) % value
            if x == value - 1:
                break
        else:
            return False
    return True


def is_power_of_two(value: int) -> bool:
    return value > 0 and (value & (value - 1)) == 0


def center_lift_residue(value: int, modulus: int) -> int:
    residue = value % modulus
    if residue > modulus // 2:
        return residue - modulus
    return residue


def normalize_vector(coeffs: Sequence[int], modulus: int) -> tuple[int, ...]:
    return tuple(int(coeff) % modulus for coeff in coeffs)


def add_vectors(lhs: Sequence[int], rhs: Sequence[int]) -> tuple[int, ...]:
    return tuple(a + b for a, b in zip(lhs, rhs, strict=True))


def scalar_mul_vector(scalar: int, values: Sequence[int]) -> tuple[int, ...]:
    return tuple(scalar * value for value in values)


def add_mod(lhs: Sequence[int], rhs: Sequence[int], modulus: int) -> tuple[int, ...]:
    return tuple((a + b) % modulus for a, b in zip(lhs, rhs, strict=True))


def scalar_mul_mod(
    scalar: int,
    values: Sequence[int],
    modulus: int,
) -> tuple[int, ...]:
    return tuple((scalar * value) % modulus for value in values)


def solve_modular_linear_system(
    matrix: Sequence[Sequence[int]],
    rhs: Sequence[int],
    modulus: int,
) -> tuple[int, ...]:
    """Solve ``matrix * x = rhs`` over ``Z/modulus Z``.

    This Gauss-Jordan routine works for prime moduli and for composite moduli
    when the elimination can find unit pivots. That is exactly the case we need
    when the left-multiplication matrix is invertible over ``Z/qZ``.
    """

    size = len(rhs)
    rows = [
        [int(entry) % modulus for entry in matrix_row]
        + [int(rhs_entry) % modulus]
        for matrix_row, rhs_entry in zip(matrix, rhs, strict=True)
    ]

    for col in range(size):
        pivot_row = None
        for candidate in range(col, size):
            if math.gcd(rows[candidate][col], modulus) == 1:
                pivot_row = candidate
                break
        if pivot_row is None:
            raise ValueError("matrix is not invertible over this modulus")

        if pivot_row != col:
            rows[col], rows[pivot_row] = rows[pivot_row], rows[col]

        pivot_inv = pow(rows[col][col], -1, modulus)
        rows[col] = [(entry * pivot_inv) % modulus for entry in rows[col]]

        for row in range(size):
            if row == col:
                continue
            factor = rows[row][col]
            if factor == 0:
                continue
            rows[row] = [
                (entry - factor * pivot_entry) % modulus
                for entry, pivot_entry in zip(rows[row], rows[col], strict=True)
            ]

    return tuple(row[-1] % modulus for row in rows)


def cyclic_convolution_mod(
    lhs: Sequence[int],
    rhs: Sequence[int],
    modulus: int,
) -> tuple[int, ...]:
    """Multiply in ``(Z/modulus Z)[x] / (x^n - 1)``."""

    n = len(lhs)
    if n != len(rhs):
        raise ValueError("cyclic factors must have the same length")
    out = [0] * n
    lhs_mod = normalize_vector(lhs, modulus)
    rhs_mod = normalize_vector(rhs, modulus)
    for lhs_index, lhs_value in enumerate(lhs_mod):
        if lhs_value == 0:
            continue
        for rhs_index, rhs_value in enumerate(rhs_mod):
            if rhs_value == 0:
                continue
            out[(lhs_index + rhs_index) % n] = (
                out[(lhs_index + rhs_index) % n] + lhs_value * rhs_value
            ) % modulus
    return tuple(out)


def cyclic_involution(coeffs: Sequence[int], modulus: int) -> tuple[int, ...]:
    """Apply ``x -> x^-1`` in ``(Z/modulus Z)[x] / (x^n - 1)``."""

    n = len(coeffs)
    out = [0] * n
    for index, coeff in enumerate(coeffs):
        out[-index % n] = int(coeff) % modulus
    return tuple(out)


def cyclic_inverse_mod(coeffs: Sequence[int], modulus: int) -> tuple[int, ...]:
    """Invert a cyclic-ring element, falling back to a circulant solve."""

    coeffs_mod = normalize_vector(coeffs, modulus)
    if is_prime(modulus):
        return _cyclic_inverse_prime_field(coeffs_mod, modulus)
    return _cyclic_inverse_linear_solve(coeffs_mod, modulus)


def _cyclic_inverse_linear_solve(
    coeffs: Sequence[int],
    modulus: int,
) -> tuple[int, ...]:
    n = len(coeffs)
    matrix = [
        [coeffs[(row - column) % n] % modulus for column in range(n)]
        for row in range(n)
    ]
    rhs = [0] * n
    rhs[0] = 1
    return solve_modular_linear_system(matrix, rhs, modulus)


def _cyclic_inverse_prime_field(
    coeffs: Sequence[int],
    modulus: int,
) -> tuple[int, ...]:
    n = len(coeffs)
    modulus_poly = [(-1) % modulus] + [0] * (n - 1) + [1]
    inverse = _polynomial_inverse_mod(coeffs, modulus_poly, modulus)
    return _polynomial_mod_xn_minus_1(inverse, n, modulus)


def _polynomial_inverse_mod(
    coeffs: Sequence[int],
    modulus_poly: Sequence[int],
    modulus: int,
) -> list[int]:
    old_r = _trim_polynomial(modulus_poly, modulus)
    r = _trim_polynomial(coeffs, modulus)
    old_t = [0]
    t = [1]

    while r:
        quotient, remainder = _polynomial_divmod(old_r, r, modulus)
        old_r, r = r, remainder
        old_t, t = t, _polynomial_sub(
            old_t,
            _polynomial_mul(quotient, t, modulus),
            modulus,
        )

    if len(old_r) != 1 or old_r[0] % modulus == 0:
        raise ValueError("cyclic element is not invertible over this modulus")

    scale = pow(old_r[0], -1, modulus)
    return [(scale * coeff) % modulus for coeff in old_t]


def _polynomial_divmod(
    numerator: Sequence[int],
    denominator: Sequence[int],
    modulus: int,
) -> tuple[list[int], list[int]]:
    remainder = _trim_polynomial(numerator, modulus)
    denominator = _trim_polynomial(denominator, modulus)
    if not denominator:
        raise ZeroDivisionError("polynomial division by zero")
    if len(remainder) < len(denominator):
        return [], remainder

    quotient = [0] * (len(remainder) - len(denominator) + 1)
    denominator_lead_inv = pow(denominator[-1], -1, modulus)

    while len(remainder) >= len(denominator) and remainder:
        shift = len(remainder) - len(denominator)
        coeff = remainder[-1] * denominator_lead_inv % modulus
        quotient[shift] = coeff
        for index, denominator_coeff in enumerate(denominator):
            remainder[shift + index] = (
                remainder[shift + index] - coeff * denominator_coeff
            ) % modulus
        remainder = _trim_polynomial(remainder, modulus)

    return _trim_polynomial(quotient, modulus), remainder


def _polynomial_mul(
    lhs: Sequence[int],
    rhs: Sequence[int],
    modulus: int,
) -> list[int]:
    if not lhs or not rhs:
        return []
    out = [0] * (len(lhs) + len(rhs) - 1)
    for lhs_index, lhs_value in enumerate(lhs):
        lhs_value %= modulus
        if lhs_value == 0:
            continue
        for rhs_index, rhs_value in enumerate(rhs):
            rhs_value %= modulus
            if rhs_value == 0:
                continue
            out[lhs_index + rhs_index] = (
                out[lhs_index + rhs_index] + lhs_value * rhs_value
            ) % modulus
    return _trim_polynomial(out, modulus)


def _polynomial_sub(
    lhs: Sequence[int],
    rhs: Sequence[int],
    modulus: int,
) -> list[int]:
    size = max(len(lhs), len(rhs))
    out = [0] * size
    for index in range(size):
        lhs_value = lhs[index] if index < len(lhs) else 0
        rhs_value = rhs[index] if index < len(rhs) else 0
        out[index] = (lhs_value - rhs_value) % modulus
    return _trim_polynomial(out, modulus)


def _polynomial_mod_xn_minus_1(
    coeffs: Sequence[int],
    n: int,
    modulus: int,
) -> tuple[int, ...]:
    out = [0] * n
    for index, coeff in enumerate(coeffs):
        out[index % n] = (out[index % n] + coeff) % modulus
    return tuple(out)


def _trim_polynomial(coeffs: Sequence[int], modulus: int) -> list[int]:
    trimmed = [int(coeff) % modulus for coeff in coeffs]
    while trimmed and trimmed[-1] == 0:
        trimmed.pop()
    return trimmed


def dihedral_inverse_via_cyclic(
    element: Sequence[int],
    n: int,
    modulus: int,
) -> tuple[int, ...]:
    """Invert in a dihedral group algebra via a cyclic-ring inverse.

    With the coefficient convention ``a(r) + s b(r)``, we have

    ``(a + s b) * (a_bar - s b) = a a_bar - b_bar b``.

    When the cyclic factor on the right is invertible, this gives a dihedral
    inverse without forming the full ``2n`` by ``2n`` multiplication matrix.
    """

    if len(element) != 2 * n:
        raise ValueError(f"expected {2 * n} coefficients, got {len(element)}")
    if modulus <= 1:
        raise ValueError("modulus must be greater than 1")

    rotations = normalize_vector(element[:n], modulus)
    reflections = normalize_vector(element[n:], modulus)
    rotation_bar = cyclic_involution(rotations, modulus)
    reflection_bar = cyclic_involution(reflections, modulus)

    rotation_norm = cyclic_convolution_mod(rotations, rotation_bar, modulus)
    reflection_norm = cyclic_convolution_mod(reflection_bar, reflections, modulus)
    determinant = tuple(
        (left - right) % modulus
        for left, right in zip(rotation_norm, reflection_norm, strict=True)
    )
    determinant_inverse = cyclic_inverse_mod(determinant, modulus)

    inverse_rotations = cyclic_convolution_mod(
        rotation_bar,
        determinant_inverse,
        modulus,
    )
    inverse_reflections = cyclic_convolution_mod(
        tuple((-coeff) % modulus for coeff in reflections),
        determinant_inverse,
        modulus,
    )
    return inverse_rotations + inverse_reflections


@dataclass(frozen=True)
class FiniteGroup:
    """A finite group with an explicit coefficient ordering."""

    kind: str
    n: int
    name: str
    elements: tuple[object, ...]
    identity_index: int = 0

    @property
    def order(self) -> int:
        return len(self.elements)

    def multiply_index(self, lhs: int, rhs: int) -> int:
        if self.kind == "cyclic":
            return (lhs + rhs) % self.n
        if self.kind == "dihedral":
            return self._multiply_dihedral(lhs, rhs)
        if self.kind == "symmetric":
            return self._multiply_symmetric(lhs, rhs)
        raise ValueError(f"unknown group kind: {self.kind}")

    def _multiply_dihedral(self, lhs: int, rhs: int) -> int:
        n = self.n
        lhs_reflection = lhs >= n
        rhs_reflection = rhs >= n
        lhs_k = lhs - n if lhs_reflection else lhs
        rhs_k = rhs - n if rhs_reflection else rhs

        if not lhs_reflection and not rhs_reflection:
            return (lhs_k + rhs_k) % n
        if not lhs_reflection and rhs_reflection:
            return n + ((rhs_k - lhs_k) % n)
        if lhs_reflection and not rhs_reflection:
            return n + ((lhs_k + rhs_k) % n)
        return (rhs_k - lhs_k) % n

    def _multiply_symmetric(self, lhs: int, rhs: int) -> int:
        lhs_images = self.elements[lhs]
        rhs_images = self.elements[rhs]
        product = tuple(lhs_images[image] for image in rhs_images)
        return self.elements.index(product)


def make_group(group_kind: str, n: int) -> FiniteGroup:
    n = int(n)
    if group_kind == "cyclic":
        return FiniteGroup(
            kind="cyclic",
            n=n,
            name=f"C{n}",
            elements=tuple(range(n)),
        )
    if group_kind == "dihedral":
        rotations = tuple(("r", k) for k in range(n))
        reflections = tuple(("s", k) for k in range(n))
        return FiniteGroup(
            kind="dihedral",
            n=n,
            name=f"D{n} (order {2 * n})",
            elements=rotations + reflections,
        )
    if group_kind == "symmetric":
        elements = tuple(itertools.permutations(range(n)))
        return FiniteGroup(
            kind="symmetric",
            n=n,
            name=f"S{n}",
            elements=elements,
        )
    raise ValueError(f"unknown group kind: {group_kind}")


class MultiplicationBackend:
    """Backend interface for group-algebra multiplication and inversion."""

    name = "base"

    def multiply(
        self,
        group: FiniteGroup,
        lhs: Sequence[int],
        rhs: Sequence[int],
        modulus: int,
    ) -> tuple[int, ...]:
        raise NotImplementedError

    def invert(
        self,
        group: FiniteGroup,
        element: Sequence[int],
        modulus: int,
    ) -> tuple[int, ...] | None:
        """Return a fast inverse when this backend has one, otherwise ``None``."""

        return None


class NaiveBackend(MultiplicationBackend):
    name = "naive"

    def multiply(
        self,
        group: FiniteGroup,
        lhs: Sequence[int],
        rhs: Sequence[int],
        modulus: int,
    ) -> tuple[int, ...]:
        out = [0] * group.order
        lhs_mod = normalize_vector(lhs, modulus)
        rhs_mod = normalize_vector(rhs, modulus)
        for lhs_index, lhs_value in enumerate(lhs_mod):
            if lhs_value == 0:
                continue
            for rhs_index, rhs_value in enumerate(rhs_mod):
                if rhs_value == 0:
                    continue
                product_index = group.multiply_index(lhs_index, rhs_index)
                out[product_index] = (
                    out[product_index] + lhs_value * rhs_value
                ) % modulus
        return tuple(out)


@lru_cache(maxsize=None)
def _symmetric_fft_plan(n: int, modulus: int):
    from fft_symmetric import SymmetricFFT

    return SymmetricFFT(n, modulus)


@lru_cache(maxsize=None)
def _dihedral_root_of_unity(n: int, modulus: int) -> int:
    from fft_dihedral import root_of_unity

    return root_of_unity(n, modulus)


class AutoBackend(MultiplicationBackend):
    """Use optional FFT packages when compatible, otherwise use direct products."""

    name = "auto"

    def __init__(self) -> None:
        self.naive = NaiveBackend()
        self.used_backends: dict[str, int] = {}

    def multiply(
        self,
        group: FiniteGroup,
        lhs: Sequence[int],
        rhs: Sequence[int],
        modulus: int,
    ) -> tuple[int, ...]:
        if group.kind == "dihedral" and self._can_use_dihedral_fft(group, modulus):
            try:
                from fft_dihedral import dihedral_multiply_fft

                omega = _dihedral_root_of_unity(group.n, modulus)
                result = dihedral_multiply_fft(
                    lhs[: group.n],
                    lhs[group.n :],
                    rhs[: group.n],
                    rhs[group.n :],
                    modulus,
                    omega,
                )
                self._record("fft-dihedral:multiply")
                return tuple(result[0] + result[1])
            except (ImportError, ValueError):
                pass

        if group.kind == "symmetric" and self._can_use_symmetric_fft(group, modulus):
            try:
                plan = _symmetric_fft_plan(group.n, modulus)
                self._record("fft-symmetric:multiply")
                return tuple(plan.multiply(lhs, rhs))
            except (ImportError, ValueError):
                pass

        self._record("naive:multiply")
        return self.naive.multiply(group, lhs, rhs, modulus)

    def invert(
        self,
        group: FiniteGroup,
        element: Sequence[int],
        modulus: int,
    ) -> tuple[int, ...] | None:
        if group.kind == "dihedral" and self._can_use_dihedral_fft(group, modulus):
            try:
                from fft_dihedral import dihedral_invert_fft

                omega = _dihedral_root_of_unity(group.n, modulus)
                rotations, reflections = dihedral_invert_fft(
                    element[: group.n],
                    element[group.n :],
                    modulus,
                    omega,
                )
                self._record("fft-dihedral:invert")
                return tuple(rotations + reflections)
            except (AttributeError, ImportError):
                pass
            except ValueError:
                raise

        if group.kind == "dihedral" and group.n >= 3:
            try:
                inverse = dihedral_inverse_via_cyclic(element, group.n, modulus)
                self._record("dihedral-cyclic:invert")
                return inverse
            except ValueError:
                if is_prime(modulus) and math.gcd(2 * group.n, modulus) == 1:
                    raise
                pass

        if group.kind == "symmetric" and self._can_use_symmetric_fft(group, modulus):
            try:
                plan = _symmetric_fft_plan(group.n, modulus)
                self._record("fft-symmetric:invert")
                return tuple(plan.invert(element))
            except (AttributeError, ImportError):
                pass
            except ValueError:
                raise

        return None

    def _can_use_dihedral_fft(self, group: FiniteGroup, modulus: int) -> bool:
        return (
            group.n >= 3
            and is_prime(modulus)
            and is_power_of_two(group.n)
            and (modulus - 1) % group.n == 0
            and math.gcd(2 * group.n, modulus) == 1
        )

    def _can_use_symmetric_fft(self, group: FiniteGroup, modulus: int) -> bool:
        return is_prime(modulus) and modulus > group.n

    def _record(self, backend: str) -> None:
        self.used_backends[backend] = self.used_backends.get(backend, 0) + 1

    def record_linear_solve_inverse(self) -> None:
        self._record("linear-solve:invert")


class GroupAlgebraNTRU:
    def __init__(
        self,
        G: FiniteGroup,
        p: int,
        q: int,
        d: int,
        name: str | None = None,
        backend: MultiplicationBackend | None = None,
    ):
        self.G = G
        self.name = name or G.name
        self.p = int(p)
        self.q = int(q)
        self.d = int(d)
        self.group_elements = G.elements
        self.group_order = G.order
        self.backend = backend or AutoBackend()

        self._validate_parameters()

    def _validate_parameters(self) -> None:
        if not is_prime(self.p):
            raise ValueError(f"p must be prime, got p={self.p}")
        if self.q <= 1:
            raise ValueError(f"q must be greater than 1, got q={self.q}")
        if math.gcd(self.p, self.q) != 1:
            raise ValueError(f"p and q must be coprime, got p={self.p}, q={self.q}")
        if self.d < 0:
            raise ValueError(f"d must be nonnegative, got d={self.d}")
        if self.group_order < 2 * self.d + 1:
            raise ValueError(
                f"|G|={self.group_order} is too small for T(d+1,d) with d={self.d}"
            )

    def parameter_notes(self) -> list[str]:
        notes = []
        if not is_prime(self.q):
            notes.append(
                "q is not prime; FFT acceleration and field inverses are unavailable"
            )
        if math.gcd(self.group_order, self.p) != 1:
            notes.append("p divides |G|, so F_p[G] is not semisimple")
        if math.gcd(self.group_order, self.q) != 1:
            notes.append("q is not coprime to |G|")

        ntru_size_bound = (6 * self.d + 1) * self.p
        if self.q <= ntru_size_bound:
            notes.append(f"q <= (6d+1)p = {ntru_size_bound}; wraparound is likelier")
        return notes

    def element_from_coefficients(self, coeffs: Sequence[int]) -> tuple[int, ...]:
        if len(coeffs) != self.group_order:
            raise ValueError(
                f"expected {self.group_order} coefficients, got {len(coeffs)}"
            )
        return tuple(int(coeff) for coeff in coeffs)

    def center_lift(self, element: Sequence[int], modulus: int) -> tuple[int, ...]:
        return tuple(center_lift_residue(coeff, modulus) for coeff in element)

    def is_ternary(self, element: Sequence[int], d1: int, d2: int) -> bool:
        coeffs = list(element)
        return coeffs.count(1) == d1 and coeffs.count(-1) == d2

    def random_ternary(self, d1: int, d2: int) -> tuple[int, ...]:
        support_size = d1 + d2
        if self.group_order < support_size:
            raise ValueError(f"|G|={self.group_order} is too small for T({d1},{d2})")

        coeffs = [0] * self.group_order
        positions = random.sample(range(self.group_order), support_size)
        for position in positions[:d1]:
            coeffs[position] = 1
        for position in positions[d1:]:
            coeffs[position] = -1

        element = tuple(coeffs)
        assert self.is_ternary(element, d1, d2)
        return element

    def random_plaintext(self) -> tuple[int, ...]:
        half_width = (self.p - 1) // 2
        return self.plaintext(
            [random.randint(-half_width, half_width) for _ in self.group_elements]
        )

    def plaintext(self, coeffs: Sequence[int]) -> tuple[int, ...]:
        half_width = (self.p - 1) // 2
        for coeff in coeffs:
            if coeff < -half_width or coeff > half_width:
                raise ValueError(
                    f"plaintext coefficient {coeff} is not centered modulo p={self.p}"
                )
        return self.element_from_coefficients(coeffs)

    def one(self) -> tuple[int, ...]:
        coeffs = [0] * self.group_order
        coeffs[self.G.identity_index] = 1
        return tuple(coeffs)

    def multiply_mod(
        self,
        lhs: Sequence[int],
        rhs: Sequence[int],
        modulus: int,
    ) -> tuple[int, ...]:
        return self.backend.multiply(self.G, lhs, rhs, modulus)

    def multiply_integer(
        self,
        lhs: Sequence[int],
        rhs: Sequence[int],
    ) -> tuple[int, ...]:
        out = [0] * self.group_order
        for lhs_index, lhs_value in enumerate(lhs):
            if lhs_value == 0:
                continue
            for rhs_index, rhs_value in enumerate(rhs):
                if rhs_value == 0:
                    continue
                product_index = self.G.multiply_index(lhs_index, rhs_index)
                out[product_index] += lhs_value * rhs_value
        return tuple(out)

    def inverse_mod(self, element: Sequence[int], modulus: int) -> tuple[int, ...]:
        inverse = self.backend.invert(self.G, element, modulus)
        if inverse is None:
            matrix = self._left_multiplication_matrix(element, modulus)
            inverse = solve_modular_linear_system(matrix, self.one(), modulus)
            if isinstance(self.backend, AutoBackend):
                self.backend.record_linear_solve_inverse()

        identity = normalize_vector(self.one(), modulus)
        if self.multiply_mod(element, inverse, modulus) != identity:
            raise ValueError("computed inverse failed right-unit verification")
        if self.multiply_mod(inverse, element, modulus) != identity:
            raise ValueError("computed inverse failed left-unit verification")
        return inverse

    def try_inverse_mod(
        self,
        element: Sequence[int],
        modulus: int,
    ) -> tuple[int, ...] | None:
        try:
            return self.inverse_mod(element, modulus)
        except ValueError:
            return None

    def _left_multiplication_matrix(
        self,
        element: Sequence[int],
        modulus: int,
    ) -> list[list[int]]:
        matrix = [[0] * self.group_order for _ in range(self.group_order)]
        element_mod = normalize_vector(element, modulus)
        for column in range(self.group_order):
            for index, coeff in enumerate(element_mod):
                if coeff == 0:
                    continue
                row = self.G.multiply_index(index, column)
                matrix[row][column] = (matrix[row][column] + coeff) % modulus
        return matrix

    def random_private_key(self, max_tries: int = 1000) -> dict[str, object]:
        for attempt in range(1, max_tries + 1):
            f = self.random_ternary(self.d + 1, self.d)
            F_p = self.try_inverse_mod(f, self.p)
            if F_p is None:
                continue
            F_q = self.try_inverse_mod(f, self.q)
            if F_q is None:
                continue
            return {"f": f, "F_p": F_p, "F_q": F_q, "attempts": attempt}

        raise RuntimeError(
            f"could not find f in T(d+1,d) invertible modulo p and q after {max_tries} tries"
        )

    def public_key(
        self,
        f: Sequence[int],
        g: Sequence[int],
        F_q: Sequence[int] | None = None,
    ) -> tuple[int, ...]:
        if F_q is None:
            F_q = self.inverse_mod(f, self.q)
        return self.multiply_mod(F_q, g, self.q)

    def encrypt(
        self,
        m: Sequence[int],
        h: Sequence[int],
        r: Sequence[int],
    ) -> tuple[int, ...]:
        phr = scalar_mul_mod(self.p, self.multiply_mod(h, r, self.q), self.q)
        return add_mod(phr, m, self.q)

    def decrypt(
        self,
        e: Sequence[int],
        f: Sequence[int],
        F_p: Sequence[int] | None = None,
    ) -> tuple[int, ...]:
        if F_p is None:
            F_p = self.inverse_mod(f, self.p)
        a_q = self.multiply_mod(f, e, self.q)
        a_lift = self.center_lift(a_q, self.q)
        b_p = self.multiply_mod(F_p, a_lift, self.p)
        return self.center_lift(b_p, self.p)

    def trial(self, max_key_tries: int = 1000) -> dict[str, object]:
        private = self.random_private_key(max_key_tries)
        f = private["f"]
        F_p = private["F_p"]
        F_q = private["F_q"]

        g = self.random_ternary(self.d, self.d)
        r = self.random_ternary(self.d, self.d)
        m = self.random_plaintext()

        h = self.public_key(f, g, F_q)
        e = self.encrypt(m, h, r)
        decrypted = self.decrypt(e, f, F_p)

        a_q = self.multiply_mod(f, e, self.q)
        a_lift = self.center_lift(a_q, self.q)
        expected_a_lift = add_vectors(
            scalar_mul_vector(self.p, self.multiply_integer(g, r)),
            self.multiply_integer(f, m),
        )

        return {
            "success": decrypted == m,
            "no_wrap": a_lift == expected_a_lift,
            "key_attempts": private["attempts"],
            "f": f,
            "g": g,
            "r": r,
            "m": m,
            "h": h,
            "e": e,
            "a_lift": a_lift,
            "expected_a_lift": expected_a_lift,
            "decrypted": decrypted,
        }

    def run_trials(
        self,
        trials: int = 10,
        max_key_tries: int = 1000,
    ) -> dict[str, object]:
        start_time = time.time()
        results = []
        keygen_failures = 0

        for _ in range(trials):
            try:
                results.append(self.trial(max_key_tries=max_key_tries))
            except RuntimeError:
                keygen_failures += 1

        successes = sum(1 for result in results if result["success"])
        no_wraps = sum(1 for result in results if result["no_wrap"])
        attempts = [result["key_attempts"] for result in results]

        backend_counts = {}
        if isinstance(self.backend, AutoBackend):
            backend_counts = dict(self.backend.used_backends)

        return {
            "scheme": self,
            "requested_trials": trials,
            "completed_trials": len(results),
            "successes": successes,
            "no_wraps": no_wraps,
            "keygen_failures": keygen_failures,
            "max_key_attempts": max(attempts) if attempts else None,
            "avg_key_attempts": sum(attempts) / len(attempts) if attempts else None,
            "elapsed_seconds": time.time() - start_time,
            "backend_counts": backend_counts,
            "results": results,
        }


def verify_cyclic_group_algebra_model(N: int = 7) -> bool:
    """Check that ``Z[C_N]`` respects multiplication modulo ``x^N - 1``."""

    group = make_group("cyclic", N)
    scheme = GroupAlgebraNTRU(group, p=3, q=41, d=2, name=f"C{N}")

    for i in range(N):
        for j in range(N):
            if group.multiply_index(i, j) != (i + j) % N:
                return False

    for _ in range(10):
        a = scheme.random_ternary(2, 2)
        b = scheme.random_ternary(2, 2)
        product = scheme.multiply_integer(a, b)
        expected = [0] * N
        for i, lhs in enumerate(a):
            for j, rhs in enumerate(b):
                expected[(i + j) % N] += lhs * rhs
        if product != tuple(expected):
            return False

    return True


def format_element(element: Sequence[int]) -> str:
    return "[" + ", ".join(str(coeff) for coeff in element) + "]"


def print_trial_details(result: dict[str, object]) -> None:
    print(f"  key attempts: {result['key_attempts']}")
    print(f"  f: {format_element(result['f'])}")
    print(f"  g: {format_element(result['g'])}")
    print(f"  r: {format_element(result['r'])}")
    print(f"  m: {format_element(result['m'])}")
    print(f"  h: {format_element(result['h'])}")
    print(f"  e: {format_element(result['e'])}")
    print(f"  center lift of f*e: {format_element(result['a_lift'])}")
    print(f"  expected p*g*r + f*m: {format_element(result['expected_a_lift'])}")
    print(f"  decrypted: {format_element(result['decrypted'])}")
    print(f"  success: {result['success']}")
    print(f"  no coefficient wraparound: {result['no_wrap']}")


def print_summary(summary: dict[str, object], verbose: bool = False) -> None:
    scheme = summary["scheme"]
    print(f"\n{scheme.name}")
    print(f"  |G|={scheme.group_order}, p={scheme.p}, q={scheme.q}, d={scheme.d}")

    for note in scheme.parameter_notes():
        print(f"  note: {note}")

    print(
        "  decryptions: "
        f"{summary['successes']}/{summary['completed_trials']} successful "
        f"({summary['keygen_failures']} keygen failures)"
    )
    print(
        "  no-wrap checks: "
        f"{summary['no_wraps']}/{summary['completed_trials']} matched p*g*r + f*m"
    )
    print(f"  elapsed: {summary['elapsed_seconds']:.2f}s")

    if summary["avg_key_attempts"] is not None:
        print(
            "  key search attempts: "
            f"avg {summary['avg_key_attempts']:.2f}, max {summary['max_key_attempts']}"
        )

    backend_counts = summary.get("backend_counts") or {}
    if backend_counts:
        details = ", ".join(
            f"{backend}={count}" for backend, count in sorted(backend_counts.items())
        )
        print(f"  backend calls: {details}")

    if verbose:
        for index, result in enumerate(summary["results"], start=1):
            print(f"\n  trial {index}")
            print_trial_details(result)


def run_experiment(
    config: dict[str, object],
    max_key_tries: int = 1000,
    verbose: bool = False,
) -> dict[str, object]:
    G = make_group(config["group"], config["n"])
    scheme = GroupAlgebraNTRU(
        G,
        p=config["p"],
        q=config["q"],
        d=config["d"],
        name=config.get("name"),
    )
    summary = scheme.run_trials(
        trials=config.get("trials", 10), max_key_tries=max_key_tries
    )
    print_summary(summary, verbose=verbose)
    sys.stdout.flush()
    return summary


def parse_args(argv: Sequence[str] | None = None) -> argparse.Namespace:
    parser = argparse.ArgumentParser(
        description="Run NTRU-style experiments over finite group algebras."
    )
    parser.add_argument(
        "--group",
        choices=["all", "cyclic", "symmetric", "dihedral"],
        default="all",
        help="which family of groups to test",
    )
    parser.add_argument(
        "--profile",
        choices=sorted(EXPERIMENT_PROFILES),
        default="quick",
        help="named experiment profile to run when --group=all",
    )
    parser.add_argument("--n", type=int, help="group parameter")
    parser.add_argument("--p", type=int, help="plaintext prime")
    parser.add_argument("--q", type=int, help="ciphertext modulus")
    parser.add_argument("--d", type=int, help="ternary density parameter")
    parser.add_argument("--trials", type=int, default=None, help="number of trials")
    parser.add_argument(
        "--max-key-tries",
        type=int,
        default=1000,
        help="maximum ternary f samples per trial",
    )
    parser.add_argument("--seed", type=int, help="seed Python's RNG")
    parser.add_argument(
        "--verbose",
        action="store_true",
        help="print the coefficient vectors for each trial",
    )
    parser.add_argument(
        "--skip-cyclic-check",
        action="store_true",
        help="skip the C_N versus Z[x]/(x^N-1) algebra check",
    )
    return parser.parse_args(argv)


def single_config_from_args(args: argparse.Namespace) -> dict[str, object]:
    default_n, default_p, default_q, default_d = DEFAULT_SINGLE_PARAMS[args.group]
    return {
        "name": f"{args.group} n={args.n or default_n}",
        "group": args.group,
        "n": args.n or default_n,
        "p": args.p or default_p,
        "q": args.q or default_q,
        "d": args.d or default_d,
        "trials": args.trials or 10,
    }


def main(argv: Sequence[str] | None = None) -> None:
    args = parse_args(argv)

    if args.seed is not None:
        random.seed(args.seed)

    if not args.skip_cyclic_check:
        check = verify_cyclic_group_algebra_model()
        print(f"C_N algebra check against Z[x]/(x^N - 1): {check}")

    if args.group == "all":
        configs = []
        for config in EXPERIMENT_PROFILES[args.profile]:
            config = dict(config)
            if args.trials is not None:
                config["trials"] = args.trials
            configs.append(config)
    else:
        configs = [single_config_from_args(args)]

    summaries = [
        run_experiment(config, max_key_tries=args.max_key_tries, verbose=args.verbose)
        for config in configs
    ]

    total_trials = sum(summary["completed_trials"] for summary in summaries)
    total_successes = sum(summary["successes"] for summary in summaries)
    print(f"\nTotal successful decryptions: {total_successes}/{total_trials}")


if __name__ == "__main__":
    main()
