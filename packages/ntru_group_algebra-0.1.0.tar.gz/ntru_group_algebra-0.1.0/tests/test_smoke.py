import random
import unittest

from ntru_group_algebra import (
    GroupAlgebraNTRU,
    NaiveBackend,
    make_group,
    verify_cyclic_group_algebra_model,
)


class SmokeTests(unittest.TestCase):
    def setUp(self):
        random.seed(20260506)

    def test_cyclic_group_algebra_matches_quotient_ring(self):
        self.assertTrue(verify_cyclic_group_algebra_model())

    def test_symmetric_s3_round_trips_in_pure_python(self):
        scheme = GroupAlgebraNTRU(make_group("symmetric", 3), p=5, q=67, d=2)
        summary = scheme.run_trials(trials=3, max_key_tries=50)
        self.assertEqual(summary["completed_trials"], 3)
        self.assertEqual(summary["successes"], 3)
        self.assertEqual(summary["no_wraps"], 3)

    def test_dihedral_fft_backend_is_optional(self):
        scheme = GroupAlgebraNTRU(make_group("dihedral", 8), p=3, q=97, d=2)
        summary = scheme.run_trials(trials=2, max_key_tries=100)
        self.assertEqual(summary["completed_trials"], 2)
        self.assertEqual(summary["successes"], 2)

    def test_dihedral_fast_inverse_backend_is_used_when_available(self):
        try:
            from fft_dihedral import dihedral_invert_fft
        except ImportError:
            self.skipTest("fft-dihedral is not installed")

        self.assertTrue(callable(dihedral_invert_fft))
        scheme = GroupAlgebraNTRU(make_group("dihedral", 8), p=3, q=97, d=2)
        rotation_generator = [0] * scheme.group_order
        rotation_generator[1] = 1
        expected_inverse = [0] * scheme.group_order
        expected_inverse[scheme.G.n - 1] = 1

        inverse = scheme.inverse_mod(rotation_generator, 97)

        self.assertEqual(inverse, tuple(expected_inverse))
        self.assertIn("fft-dihedral:invert", scheme.backend.used_backends)

    def test_dihedral_cyclic_inverse_backend_handles_small_fields(self):
        group = make_group("dihedral", 16)
        fast_scheme = GroupAlgebraNTRU(group, p=3, q=97, d=3)
        linear_scheme = GroupAlgebraNTRU(group, p=3, q=97, d=3, backend=NaiveBackend())

        for _ in range(100):
            element = fast_scheme.random_ternary(4, 3)
            expected = linear_scheme.try_inverse_mod(element, 3)
            if expected is None:
                continue

            inverse = fast_scheme.inverse_mod(element, 3)

            self.assertEqual(inverse, expected)
            self.assertIn("dihedral-cyclic:invert", fast_scheme.backend.used_backends)
            break
        else:
            self.fail("could not find an invertible dihedral sample modulo 3")

    def test_symmetric_fast_inverse_backend_is_used_when_available(self):
        try:
            from fft_symmetric import SymmetricFFT
        except ImportError:
            self.skipTest("fft-symmetric is not installed")

        if not hasattr(SymmetricFFT(3, 67), "invert"):
            self.skipTest("fft-symmetric<0.2.0 is installed")

        scheme = GroupAlgebraNTRU(make_group("symmetric", 3), p=5, q=67, d=2)
        permutation_index = scheme.group_order - 1
        permutation = scheme.G.elements[permutation_index]
        inverse_images = [0] * scheme.G.n
        for point, image in enumerate(permutation):
            inverse_images[image] = point
        inverse_index = scheme.G.elements.index(tuple(inverse_images))

        basis_element = [0] * scheme.group_order
        basis_element[permutation_index] = 1
        expected_inverse = [0] * scheme.group_order
        expected_inverse[inverse_index] = 1

        inverse = scheme.inverse_mod(basis_element, 67)

        self.assertEqual(inverse, tuple(expected_inverse))
        self.assertIn("fft-symmetric:invert", scheme.backend.used_backends)


if __name__ == "__main__":
    unittest.main()
