class ProjectMakerError(Exception):
    pass
