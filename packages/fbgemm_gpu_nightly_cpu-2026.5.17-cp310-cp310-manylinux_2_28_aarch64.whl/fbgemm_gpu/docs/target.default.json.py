
{
    "version": "2026.5.17",
    "target": "default",
    "variant": "cpu"
}
