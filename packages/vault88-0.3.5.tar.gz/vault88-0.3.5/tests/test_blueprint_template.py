"""Tests for BlueprintTemplate.render_test_summary version parameter."""

from vault88.constructs.result import Result, ResultOutcome
from vault88.constructs.stage import Stage
from vault88.templates.blueprint import BlueprintTemplate
from vault88.utils.console import strip_ansi

_WIDTH = 80
_NO_CONFIG = {}


def _stage(results=None):
    s = Stage("Stage 1")
    for r in results or []:
        s.addResult(r)
    return s


def _result(outcome=ResultOutcome.PASSED):
    return Result("action", "expected", "actual", outcome)


def _render(test_name="My Test", stages=None, width=_WIDTH, version=""):
    return BlueprintTemplate(_NO_CONFIG).render_test_summary(
        test_name, stages or [], width, version
    )


def _plain(lines):
    return [strip_ansi(line) for line in lines]


class TestRenderTestSummaryVersion:
    def test_version_appears_in_header_when_set(self):
        lines = _plain(_render(test_name="My Test", version="1.2.3"))
        assert any("v1.2.3" in line for line in lines)

    def test_version_omitted_from_header_when_empty(self):
        lines = _plain(_render(test_name="My Test", version=""))
        assert not any(" v" in line for line in lines)

    def test_version_default_omits_version(self):
        lines = _plain(
            BlueprintTemplate(_NO_CONFIG).render_test_summary("My Test", [], _WIDTH)
        )
        assert not any(" v" in line for line in lines)

    def test_test_name_still_appears_with_version(self):
        lines = _plain(_render(test_name="My Test", version="2.0"))
        assert any("My Test" in line for line in lines)

    def test_test_name_still_appears_without_version(self):
        lines = _plain(_render(test_name="My Test", version=""))
        assert any("My Test" in line for line in lines)


class TestRenderTestSummaryOutcomes:
    def test_all_passed_shows_passed(self):
        stages = [_stage([_result(ResultOutcome.PASSED)])]
        lines = _plain(_render(stages=stages))
        assert any("PASSED" in line for line in lines)

    def test_any_failed_shows_failed(self):
        stages = [_stage([_result(ResultOutcome.FAILED)])]
        lines = _plain(_render(stages=stages))
        assert any("FAILED" in line for line in lines)

    def test_empty_stages_shows_not_run(self):
        lines = _plain(_render(stages=[]))
        assert any("NOT RUN" in line for line in lines)

    def test_pass_step_shows_pass_badge(self):
        stages = [_stage([_result(ResultOutcome.PASSED)])]
        lines = _plain(_render(stages=stages))
        assert any("PASS" in line for line in lines)

    def test_fail_step_shows_fail_badge(self):
        stages = [_stage([_result(ResultOutcome.FAILED)])]
        lines = _plain(_render(stages=stages))
        assert any("FAIL" in line for line in lines)
