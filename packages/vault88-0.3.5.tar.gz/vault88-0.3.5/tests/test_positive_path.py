"""Positive path integration test — exercises the full Runner → Test lifecycle"""

import os

import pytest

from vault88.constructs.result import ResultOutcome
from vault88.constructs.test import Test
from vault88.core.logger import Logger
from vault88.core.runner import Runner

# ---------------------------------------------------------------------------
# Concrete Test implementation used by all cases below
# ---------------------------------------------------------------------------


class SampleTest(Test):
    name = "Sample Test"
    version = ""
    tags = ["sample", "positive"]

    def selfCheck(self) -> bool:
        return True

    def setup(self) -> bool:
        return True

    def run(self) -> None:
        self.newStage("Arithmetic checks")
        self.assertEqual("Verify 1 + 1 equals 2", 2, 1 + 1)
        self.assertEqual("Verify 10 - 3 equals 7", 7, 10 - 3)
        self.assertTrue("Verify non-empty string is truthy", "hello")
        self.assertGreaterThan("Verify 5 is greater than 3", 5, 3)

        self.newStage("Requirement-linked checks")
        self.assertEqual(
            "Verify 2 * 3 equals 6",
            6,
            2 * 3,
            requirements=["SSS_001"],
        )
        self.assertIn(
            "Verify 'b' is in ['a', 'b', 'c']",
            "b",
            ["a", "b", "c"],
            requirements=["SSS_001", "SSS_002"],
        )

    def teardown(self) -> None:
        pass


# ---------------------------------------------------------------------------
# Fixtures
# ---------------------------------------------------------------------------


@pytest.fixture
def logger(tmp_path):
    log = Logger()
    log.setupLogger(str(tmp_path / "vault88.log"), verbose=False)
    yield log
    log.detachFileHandler()
    log.detachStreamHandler()


# ---------------------------------------------------------------------------
# Tests
# ---------------------------------------------------------------------------


class TestPositivePath:
    def test_runner_returns_test_instance(self, logger):
        runner = Runner(logger, SampleTest)
        test = runner.runTest()

        assert test is not None

    def test_runner_raises_no_exception(self, logger):
        runner = Runner(logger, SampleTest)
        runner.runTest()

        assert runner.exception is False

    def test_correct_number_of_stages(self, logger):
        runner = Runner(logger, SampleTest)
        test = runner.runTest()

        assert len(test.stages) == 2

    def test_stage_names(self, logger):
        runner = Runner(logger, SampleTest)
        test = runner.runTest()

        assert test.stages[0].name == "Arithmetic checks"
        assert test.stages[1].name == "Requirement-linked checks"

    def test_stage_one_result_count(self, logger):
        runner = Runner(logger, SampleTest)
        test = runner.runTest()

        assert len(test.stages[0].results) == 4

    def test_stage_two_result_count(self, logger):
        runner = Runner(logger, SampleTest)
        test = runner.runTest()

        assert len(test.stages[1].results) == 2

    def test_all_results_passed(self, logger):
        runner = Runner(logger, SampleTest)
        test = runner.runTest()

        all_results = [r for stage in test.stages for r in stage.results]
        assert all(r.outcome == ResultOutcome.PASSED for r in all_results)

    def test_results_are_ordered(self, logger):
        runner = Runner(logger, SampleTest)
        test = runner.runTest()

        actions = [r.action for r in test.stages[0].results]
        assert actions == [
            "Verify 1 + 1 equals 2",
            "Verify 10 - 3 equals 7",
            "Verify non-empty string is truthy",
            "Verify 5 is greater than 3",
        ]

    def test_results_have_timestamps(self, logger):
        runner = Runner(logger, SampleTest)
        test = runner.runTest()

        all_results = [r for stage in test.stages for r in stage.results]
        assert all(r.timestamp is not None for r in all_results)

    def test_requirements_attached_to_results(self, logger):
        runner = Runner(logger, SampleTest)
        test = runner.runTest()

        req_results = test.stages[1].results
        assert req_results[0].requirements == ["SSS_001"]
        assert req_results[1].requirements == ["SSS_001", "SSS_002"]

    def test_results_without_requirements_have_empty_list(self, logger):
        runner = Runner(logger, SampleTest)
        test = runner.runTest()

        for r in test.stages[0].results:
            assert r.requirements == []

    def test_log_dir_exists_and_contains_test_log(self, logger):
        runner = Runner(logger, SampleTest)
        test = runner.runTest()

        assert os.path.isdir(test.log_dir)
        assert os.path.isfile(os.path.join(test.log_dir, "test.log"))
