"""Tests for the built-in reporter static registry."""

from vault88.core.reporters import BUILTIN_REPORTERS
from vault88.core.reporters.junit_reporter import JUnitReporter
from vault88.core.reporters.log_archive_reporter import LogArchiveReporter
from vault88.core.reporters.pdf_reporter import PdfReporter


class TestBuiltinReportersRegistry:
    def test_registry_contains_all_three_reporters(self):
        assert JUnitReporter in BUILTIN_REPORTERS
        assert LogArchiveReporter in BUILTIN_REPORTERS
        assert PdfReporter in BUILTIN_REPORTERS

    def test_registry_has_exactly_three_entries(self):
        assert len(BUILTIN_REPORTERS) == 3

    def test_all_reporters_have_name(self):
        for cls in BUILTIN_REPORTERS:
            assert isinstance(cls.name, str) and cls.name

    def test_all_reporters_have_version(self):
        for cls in BUILTIN_REPORTERS:
            assert isinstance(cls.version, str) and cls.version

    def test_all_reporters_have_config_options_dict(self):
        for cls in BUILTIN_REPORTERS:
            assert isinstance(cls.config_options, dict)

    def test_junit_reporter_config_options(self):
        assert "suite_name" in JUnitReporter.config_options

    def test_pdf_reporter_config_options(self):
        assert "output_dir" in PdfReporter.config_options

    def test_log_archive_reporter_config_options(self):
        assert "output_dir" in LogArchiveReporter.config_options
