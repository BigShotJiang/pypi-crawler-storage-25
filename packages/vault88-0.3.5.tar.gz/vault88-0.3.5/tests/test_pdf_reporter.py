"""Unit tests for PdfReporter"""

from unittest.mock import MagicMock

import pytest

from vault88.constructs.result import Result, ResultOutcome
from vault88.constructs.stage import Stage
from vault88.constructs.test import Test
from vault88.core.reporters.pdf_reporter import PdfReporter

# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


class MinimalTest(Test):
    name = "My Sample Test"
    tags = []

    def selfCheck(self):
        return True

    def setup(self):
        return True

    def run(self):
        pass

    def teardown(self):
        pass


def make_test(stages_data, name="My Sample Test"):
    test = MinimalTest(MagicMock(), "/tmp")
    test.name = name
    for stage_name, results in stages_data:
        stage = Stage(stage_name)
        for r in results:
            stage.addResult(r)
        test.stages.append(stage)
    return test


def passed(action="step", expected="x", actual="x"):
    return Result(action, expected, actual, ResultOutcome.PASSED)


def failed(action="step", expected="x", actual="y"):
    return Result(action, expected, actual, ResultOutcome.FAILED)


def not_run(action="step", expected="x", actual="N/A"):
    return Result(action, expected, actual, ResultOutcome.NOT_RUN)


def make_reporter(config=None):
    return PdfReporter(MagicMock(), config or {})


def _find_pdf(directory):
    pdfs = list(directory.glob("*.pdf"))
    assert len(pdfs) == 1, f"Expected 1 PDF, found {[p.name for p in pdfs]}"
    return pdfs[0]


# ---------------------------------------------------------------------------
# check()
# ---------------------------------------------------------------------------


class TestCheck:
    def test_returns_false_when_no_stages(self):
        assert make_reporter().check(make_test([])) is False

    def test_returns_false_when_stages_have_no_results(self):
        assert make_reporter().check(make_test([("Stage A", []), ("Stage B", [])])) is False

    def test_returns_true_when_stage_has_results(self):
        assert make_reporter().check(make_test([("Stage A", [passed()])])) is True

    def test_returns_true_when_only_later_stage_has_results(self):
        assert make_reporter().check(make_test([("Stage A", []), ("Stage B", [passed()])])) is True


# ---------------------------------------------------------------------------
# publish()
# ---------------------------------------------------------------------------


class TestPublish:
    @pytest.fixture(autouse=True)
    def chdir(self, tmp_path, monkeypatch):
        monkeypatch.chdir(tmp_path)
        self.tmp_path = tmp_path

    # --- file creation ---

    def test_creates_pdf_file(self):
        make_reporter().publish(make_test([("Stage A", [passed()])]))
        assert len(list(self.tmp_path.glob("*.pdf"))) == 1

    def test_pdf_is_a_valid_pdf(self):
        make_reporter().publish(make_test([("Stage A", [passed()])]))
        pdf = _find_pdf(self.tmp_path)
        assert pdf.read_bytes()[:4] == b"%PDF"

    # --- filename format ---

    def test_filename_starts_with_test_name(self):
        make_reporter().publish(make_test([("Stage A", [passed()])]))
        assert _find_pdf(self.tmp_path).name.startswith("My_Sample_Test-")

    def test_filename_replaces_spaces_with_underscores(self):
        make_reporter().publish(make_test([("Stage A", [passed()])], name="A Test With Spaces"))
        assert _find_pdf(self.tmp_path).name.startswith("A_Test_With_Spaces-")

    def test_filename_for_single_word_test(self):
        make_reporter().publish(make_test([("Stage A", [passed()])], name="Login"))
        assert _find_pdf(self.tmp_path).name.startswith("Login-")

    def test_filename_ends_with_pdf(self):
        make_reporter().publish(make_test([("Stage A", [passed()])]))
        assert _find_pdf(self.tmp_path).name.endswith(".pdf")

    def test_filename_contains_timestamp(self):
        make_reporter().publish(make_test([("Stage A", [passed()])]))
        name = _find_pdf(self.tmp_path).name
        # Format: Name-YYYYMMDD_HHMMSS_ffffff.pdf
        stem = name.removesuffix(".pdf")
        timestamp_part = stem.split("-")[-1]
        assert len(timestamp_part) == 22  # YYYYMMDD_HHMMSS_ffffff
        assert timestamp_part[8] == "_"
        assert timestamp_part[15] == "_"

    def test_duplicate_publishes_create_separate_files(self):
        reporter = make_reporter()
        reporter.publish(make_test([("Stage A", [passed()])]))
        reporter.publish(make_test([("Stage A", [passed()])]))
        assert len(list(self.tmp_path.glob("*.pdf"))) == 2

    # --- output_dir config ---

    def test_default_output_dir_is_cwd(self):
        make_reporter().publish(make_test([("Stage A", [passed()])]))
        assert _find_pdf(self.tmp_path).parent == self.tmp_path

    def test_custom_output_dir_from_config(self, tmp_path):
        out_dir = tmp_path / "reports"
        out_dir.mkdir()
        make_reporter(config={"output_dir": str(out_dir)}).publish(
            make_test([("Stage A", [passed()])])
        )
        assert len(list(out_dir.glob("My_Sample_Test-*.pdf"))) == 1

    def test_custom_output_dir_is_created_if_missing(self, tmp_path):
        out_dir = tmp_path / "new_reports"
        make_reporter(config={"output_dir": str(out_dir)}).publish(
            make_test([("Stage A", [passed()])])
        )
        assert out_dir.is_dir()
        assert len(list(out_dir.glob("*.pdf"))) == 1

    # --- logger ---

    def test_logger_info_called_once(self):
        mock_logger = MagicMock()
        PdfReporter(mock_logger, {}).publish(make_test([("Stage A", [passed()])]))
        mock_logger.info.assert_called_once()

    def test_logger_info_contains_pdf_path(self):
        mock_logger = MagicMock()
        PdfReporter(mock_logger, {}).publish(make_test([("Stage A", [passed()])]))
        assert ".pdf" in mock_logger.info.call_args[0][0]

    def test_logger_info_contains_test_name(self):
        mock_logger = MagicMock()
        PdfReporter(mock_logger, {}).publish(make_test([("Stage A", [passed()])]))
        assert "My_Sample_Test" in mock_logger.info.call_args[0][0]

    # --- non-empty output ---

    def test_pdf_file_is_not_empty(self):
        make_reporter().publish(make_test([("Stage A", [passed()])]))
        assert _find_pdf(self.tmp_path).stat().st_size > 0

    def test_all_result_outcomes_are_accepted(self):
        make_reporter().publish(
            make_test([("Stage A", [passed(), failed(), not_run()])])
        )
        assert len(list(self.tmp_path.glob("*.pdf"))) == 1

    def test_multiple_stages_produce_single_pdf(self):
        make_reporter().publish(
            make_test([
                ("Stage A", [passed()]),
                ("Stage B", [failed()]),
                ("Stage C", [not_run()]),
            ])
        )
        assert len(list(self.tmp_path.glob("*.pdf"))) == 1

    def test_stages_with_no_results_are_skipped_without_error(self):
        make_reporter().publish(
            make_test([("Empty Stage", []), ("Real Stage", [passed()])])
        )
        assert len(list(self.tmp_path.glob("*.pdf"))) == 1
