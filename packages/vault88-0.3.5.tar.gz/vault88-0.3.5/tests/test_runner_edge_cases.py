"""Runner error-path tests"""

import pytest

from vault88.constructs.test import Test
from vault88.core.logger import Logger
from vault88.core.runner import Runner


@pytest.fixture
def logger(tmp_path):
    log = Logger()
    log.setupLogger(str(tmp_path / "vault88.log"))
    yield log
    log.detachFileHandler()
    log.detachStreamHandler()


class _Base(Test):
    name = "Base"
    version = ""
    tags = []

    def selfCheck(self):
        return True

    def setup(self):
        return True

    def run(self):
        pass

    def teardown(self):
        pass


class TestRunnerEdgeCases:
    def test_selfcheck_returns_false_aborts_run(self, logger):
        class T(_Base):
            setup_called = False

            def selfCheck(self):
                return False

            def setup(self):
                T.setup_called = True
                return True

        test = Runner(logger, T).runTest()
        assert test is not None
        assert T.setup_called is False
        assert test.stages == []

    def test_selfcheck_exception_sets_flag(self, logger):
        class T(_Base):
            def selfCheck(self):
                raise RuntimeError("selfcheck boom")

        runner = Runner(logger, T)
        runner.runTest()
        assert runner.exception is True

    def test_setup_returns_false_calls_teardown(self, logger):
        class T(_Base):
            torn = False

            def setup(self):
                return False

            def teardown(self):
                T.torn = True

        Runner(logger, T).runTest()
        assert T.torn is True

    def test_setup_exception_calls_teardown(self, logger):
        class T(_Base):
            torn = False

            def setup(self):
                raise RuntimeError("setup boom")

            def teardown(self):
                T.torn = True

        runner = Runner(logger, T)
        runner.runTest()
        assert T.torn is True
        assert runner.exception is True

    def test_run_exception_still_calls_teardown(self, logger):
        class T(_Base):
            torn = False

            def run(self):
                raise RuntimeError("run boom")

            def teardown(self):
                T.torn = True

        runner = Runner(logger, T)
        runner.runTest()
        assert T.torn is True
        assert runner.exception is True

    def test_teardown_exception_sets_flag(self, logger):
        class T(_Base):
            def teardown(self):
                raise RuntimeError("teardown boom")

        runner = Runner(logger, T)
        runner.runTest()
        assert runner.exception is True

    def test_init_exception_returns_none(self, logger):
        class T(_Base):
            def __init__(self, *a, **kw):
                raise RuntimeError("init boom")

        runner = Runner(logger, T)
        result = runner.runTest()
        assert result is None
        assert runner.exception is True

    def test_with_environment_passed_to_test(self, logger):
        class T(_Base):
            received_env = None

            def __init__(self, log, log_dir, environment=None):
                super().__init__(log, log_dir, environment)
                T.received_env = environment

        env = object()
        Runner(logger, T, environment=env).runTest()
        assert T.received_env is env


class TestRunnerValidation:
    """Runner skips and returns None when the test class is malformed."""

    @pytest.fixture(autouse=True)
    def _logger(self, tmp_path):
        from vault88.core.logger import Logger
        log = Logger()
        log.setupLogger(str(tmp_path / "vault88.log"))
        self.logger = log
        yield
        log.detachFileHandler()
        log.detachStreamHandler()

    def _run(self, cls):
        return Runner(self.logger, cls).runTest()

    # ------------------------------------------------------------------ attrs
    # Classes that inherit from _Base already satisfy name/version/tags via MRO.
    # To test "missing", we subclass Test directly and omit the attribute.

    def test_missing_name_returns_none(self):
        class T(Test):
            # name not declared — only inherited empty default from Test
            version = "1.0"
            tags = []

            def selfCheck(self): return True
            def setup(self): return True
            def run(self): pass
            def teardown(self): pass

        assert self._run(T) is None

    def test_empty_name_returns_none(self):
        class T(Test):
            name = ""
            version = "1.0"
            tags = []

            def selfCheck(self): return True
            def setup(self): return True
            def run(self): pass
            def teardown(self): pass

        assert self._run(T) is None

    def test_missing_version_returns_none(self):
        class T(Test):
            name = "T"
            # version not declared — only inherited empty default from Test
            tags = []

            def selfCheck(self): return True
            def setup(self): return True
            def run(self): pass
            def teardown(self): pass

        assert self._run(T) is None

    def test_missing_tags_returns_none(self):
        class T(Test):
            name = "T"
            version = "1.0"
            # tags not declared — only inherited empty default from Test

            def selfCheck(self): return True
            def setup(self): return True
            def run(self): pass
            def teardown(self): pass

        assert self._run(T) is None

    def test_tags_not_list_returns_none(self):
        class T(Test):
            name = "T"
            version = "1.0"
            tags = "not-a-list"

            def selfCheck(self): return True
            def setup(self): return True
            def run(self): pass
            def teardown(self): pass

        assert self._run(T) is None

    # ----------------------------------------------------------------- methods

    def test_all_methods_missing_returns_none(self):
        class T(Test):
            name = "T"
            version = "1.0"
            tags = []
            # selfCheck / setup / run / teardown intentionally not implemented

        assert self._run(T) is None

    def test_partially_missing_methods_returns_none(self):
        class T(Test):
            name = "T"
            version = "1.0"
            tags = []

            def selfCheck(self): return True
            def setup(self): return True
            # run and teardown still abstract

        assert self._run(T) is None

    # ------------------------------------------------------ valid class passes

    def test_valid_class_inheriting_attrs_runs_normally(self):
        # Inner T does not redeclare name/version/tags — inherits them from _Base
        class T(_Base):
            pass

        assert self._run(T) is not None

    def test_valid_class_with_explicit_attrs_runs_normally(self):
        class T(Test):
            name = "T"
            version = "1.0"
            tags = []

            def selfCheck(self): return True
            def setup(self): return True
            def run(self): pass
            def teardown(self): pass

        assert self._run(T) is not None
