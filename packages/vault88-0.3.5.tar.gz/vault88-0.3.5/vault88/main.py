"""CLI Main execution loop"""

import configparser
import os
import sys

from vault88.__about__ import __version__
from vault88.args import parseArgs
from vault88.core.environment_loaders import ApiLoader, JsonFileLoader
from vault88.core.loader import Loader
from vault88.core.logger import Logger
from vault88.core.reporter_loader import load_reporters
from vault88.core.reporters.junit_reporter import JUnitReporter
from vault88.core.runner import Runner
from vault88.core.template_loader import load_template


def shutdown(exit_code: int, logger: Logger):
    logger.detachFileHandler()
    logger.detachStreamHandler()
    sys.exit(exit_code)


def _generate_default_config(output_path: str) -> None:
    """Write a default vault88 config file to the given path.

    Sets console width to 100 and template to blueprint, and includes a
    disabled entry for every built-in reporter with its available options
    listed as comments.
    """
    from vault88.core.reporters import BUILTIN_REPORTERS

    lines = [
        "[CONSOLE]",
        "width = 100",
        "template = blueprint",
        "",
    ]

    for i, reporter_cls in enumerate(BUILTIN_REPORTERS, start=1):
        lines.append(f"[REPORTER{i}]")
        lines.append(f"; {reporter_cls.name} v{reporter_cls.version}")
        lines.append("enabled = false")
        lines.append(f"module = {reporter_cls.__module__}")
        lines.append(f"class = {reporter_cls.__name__}")
        for key, description in reporter_cls.config_options.items():
            lines.append(f"; {key}: {description}")
        lines.append("")

    with open(output_path, "w") as f:
        f.write("\n".join(lines))

    print(f"Default config written to: {output_path}")


def _print_builtin_reporters():
    """Print all built-in reporters with their module paths and config options."""
    from vault88.core.reporters import BUILTIN_REPORTERS

    print("Built-in Reporters:\n")
    for reporter_cls in BUILTIN_REPORTERS:
        module = reporter_cls.__module__
        print(f"  {reporter_cls.name} (v{reporter_cls.version})")
        print(f"    module = {module}")
        print(f"    class  = {reporter_cls.__name__}")
        if reporter_cls.config_options:
            print("    options:")
            for key, description in reporter_cls.config_options.items():
                print(f"      {key}  — {description}")
        print()


def _printStartupBanner(logger: Logger, reporters):
    logger.logBanner(f"Vault88 TEST RUNNER v{__version__}")
    logger.info(f"  Loader    : {Loader.name} v{Loader.version}")
    logger.info(f"  Runner    : {Runner.name} v{Runner.version}")
    if reporters:
        reporter_str = ", ".join(f"{r.name} v{r.version}" for r in reporters)
        logger.info(f"  Reporters : {reporter_str}")
    else:
        logger.info("  Reporters : none  (run 'vault88 --list-reporters' to see available)")
    logger.logHr()


def _resolveConfigFile(override=None):
    if override:
        return override
    user_config = os.path.expanduser("~/.vault88.conf")
    if os.path.isfile(user_config):
        return user_config
    if os.path.isfile("/etc/vault88.conf"):
        return "/etc/vault88.conf"
    return None


def main():
    args = parseArgs()

    if args.list_reporters:
        _print_builtin_reporters()
        sys.exit(0)

    if args.init_config:
        output_path = os.path.join(os.getcwd(), "vault88.conf")
        _generate_default_config(output_path)
        sys.exit(0)

    if args.testpath is None:
        print("error: the following arguments are required: testpath")
        sys.exit(1)

    # Stage 1 - setup logging
    logger = Logger()
    logger.setupLogger(args.log, args.verbose)

    if os.geteuid() == 0:
        logger.warning("Running vault88 as root is unsafe")

    # Stage 2 - load environment (optional)
    environment = None
    if args.env:
        try:
            if args.env.startswith("http://") or args.env.startswith("https://"):
                environment = ApiLoader(args.env).load()
            else:
                environment = JsonFileLoader(args.env).load()
            logger.info(f"Loaded environment: {environment.name}")
        except Exception:
            logger.error(f"Failed to load environment from: {args.env}")
            shutdown(1, logger)

    # Stage 3 - load config and reporters
    config = configparser.ConfigParser()
    config_path = _resolveConfigFile(args.config)
    if config_path:
        config.read(config_path)

    config_width = config.getint("CONSOLE", "width", fallback=None)
    logger.configure_console(config_width)

    template = load_template(logger, config)
    logger.configure_template(template)

    reporters = load_reporters(logger, config)
    if args.junit:
        reporters.append(JUnitReporter(logger, {}))

    _printStartupBanner(logger, reporters)

    # Stage 4 - discover tests
    loader = Loader(logger)
    selected_tests = loader.loadTests(
        args.testpath,
        args.tags or [],
        args.nottags or [],
        args.recursive or False,
    )

    if not selected_tests:
        logger.logBanner("TEST RUN COMPLETE - NO TESTS SELECTED")
        shutdown(1, logger)

    # Stage 5 - run tests and report
    had_exception = False
    had_failure = False
    summary_rows = []

    for test_class in selected_tests:
        test_name = test_class.name or test_class.__name__
        runner = Runner(logger, test_class, environment)
        test = runner.runTest()

        if test is None:
            logger.error(f"Runner failed to initialise {test_class.__name__}, skipping reporters")
            had_exception = True
            summary_rows.append((test_name, "not_run"))
            continue

        if runner.exception:
            logger.error(f"{test_class.__name__} encountered an exception during execution")
            had_exception = True
            summary_rows.append((test_name, "not_run"))
        elif test.has_failures():
            had_failure = True
            summary_rows.append((test_name, "failed"))
        else:
            summary_rows.append((test_name, "passed"))

        for reporter in reporters:
            if reporter.check(test):
                reporter.publish(test)

    logger.logSummary(summary_rows)

    if had_exception:
        logger.logBanner("TEST RUN COMPLETE - EXCEPTIONS ENCOUNTERED")
        shutdown(2, logger)
    elif had_failure:
        logger.logBanner("TEST RUN COMPLETE - FAILURES DETECTED")
        shutdown(1, logger)
    else:
        logger.logBanner("TEST RUN COMPLETE - ALL TESTS PASSED")
        shutdown(0, logger)
