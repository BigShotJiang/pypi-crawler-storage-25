"""Test Executor"""

import traceback

from vault88.constructs.test import Test

_REQUIRED_ATTRS = ("name", "version", "tags")
_REQUIRED_METHODS = ("selfCheck", "setup", "run", "teardown")


class Runner:
    name = "Runner"
    version = "1.0.0"

    def __init__(self, logger, test_class, environment=None):
        self.logger = logger
        self.test_class = test_class
        self.environment = environment
        self.exception = False

    def _validate_test_class(self):
        """Return a list of problems with the test class declaration.

        Attributes must be explicitly declared somewhere in the MRO, not merely
        inherited from the Test base class (which provides empty defaults).
        """
        cls = self.test_class
        problems = []

        def declared(attr):
            return any(attr in klass.__dict__ for klass in cls.__mro__ if klass is not Test)

        for attr in _REQUIRED_ATTRS:
            if not declared(attr):
                problems.append(f"class attribute '{attr}' not declared")

        if declared("name") and not cls.name:
            problems.append("'name' must be a non-empty string")

        if declared("tags") and not isinstance(cls.tags, list):
            problems.append("'tags' must be a list")

        abstract = getattr(cls, "__abstractmethods__", frozenset())
        for method in _REQUIRED_METHODS:
            if method in abstract or not callable(getattr(cls, method, None)):
                problems.append(f"required method '{method}' is not implemented")

        return problems

    def _call(self, method, label):
        """Call a test method, catching any exception.

        Returns (no_exception: bool, return_value).
        Sets self.exception and logs on failure.
        """
        try:
            return True, method()
        except Exception:
            self.exception = True
            self.logger.logTraceback(f"Exception in {label}\n{traceback.format_exc()}")
            return False, None

    def runTest(self):
        problems = self._validate_test_class()
        if problems:
            for p in problems:
                self.logger.error(f"{self.test_class.__name__}: {p}")
            self.logger.warning(
                f"{self.test_class.__name__} is not a valid test class — skipping"
            )
            return None

        # Create the test log dir before instantiation so it can be passed to the test
        ok, log_dir = self._call(
            self.logger.addTestFileHandler,
            "Logger.addTestFileHandler",
        )
        if not ok:
            return None

        # Pre-test banner
        test_name = self.test_class.name or self.test_class.__name__
        version = getattr(self.test_class, "version", "")
        title = f"Running: {test_name}" + (f" v{version}" if version else "")
        self.logger.logBanner(title)

        # Instantiate the test
        ok, test = self._call(
            lambda: self.test_class(self.logger, log_dir, self.environment),
            f"{self.test_class.__name__}.__init__",
        )
        if not ok:
            self.logger.removeTestFileHandler()
            return test

        # selfCheck — if False or exception, abort without teardown
        ok, result = self._call(test.selfCheck, f"{test.__class__.__name__}.selfCheck")
        if not ok or not result:
            if ok:
                self.logger.error(
                    f"{test.__class__.__name__}: selfCheck() returned False, test cannot run"
                )
            self.logger.logTestSummary(test)
            self.logger.removeTestFileHandler()
            return test
        self.logger.debug(f"{test.__class__.__name__}.selfCheck() returned {result!r}")

        # setup — if False or exception, run teardown then return
        ok, result = self._call(test.setup, f"{test.__class__.__name__}.setup")
        if not ok or not result:
            if ok:
                self.logger.error(f"{test.__class__.__name__}: setup() returned False")
            self._call(test.teardown, f"{test.__class__.__name__}.teardown")
            self.logger.logTestSummary(test)
            self.logger.removeTestFileHandler()
            return test
        self.logger.debug(f"{test.__class__.__name__}.setup() returned {result!r}")

        # run
        ok, _ = self._call(test.run, f"{test.__class__.__name__}.run")
        if ok:
            self.logger.debug(f"{test.__class__.__name__}.run() completed")

        # teardown always runs if we got past selfCheck and setup
        ok, _ = self._call(test.teardown, f"{test.__class__.__name__}.teardown")
        if ok:
            self.logger.debug(f"{test.__class__.__name__}.teardown() completed")

        self.logger.logTestSummary(test)

        self.logger.removeTestFileHandler()
        return test
