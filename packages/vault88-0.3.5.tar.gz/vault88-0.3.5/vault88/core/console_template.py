"""Abstract base class for console display templates."""

from abc import ABC, abstractmethod
from typing import List


class ConsoleTemplate(ABC):
    def __init__(self, config: dict = None):
        pass

    @abstractmethod
    def render_banner(self, title: str, width: int) -> List[str]: ...

    @abstractmethod
    def render_stage(self, name: str, stage_num: int, width: int) -> List[str]: ...

    @abstractmethod
    def render_result(self, result, stage_num: int, step_num: int, width: int) -> List[str]: ...

    @abstractmethod
    def render_test_summary(
        self, test_name: str, stages, width: int, version: str = ""
    ) -> List[str]: ...

    @abstractmethod
    def render_summary_table(self, rows: List[tuple], width: int) -> List[str]: ...

    @abstractmethod
    def render_traceback(self, tb: str, width: int) -> List[str]: ...

    @abstractmethod
    def render_hr(self, width: int) -> str: ...
