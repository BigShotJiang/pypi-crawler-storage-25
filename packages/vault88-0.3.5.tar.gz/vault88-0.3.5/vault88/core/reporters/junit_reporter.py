"""JUnit XML Reporter"""

import os
from typing import List

from junit_xml import TestCase, TestSuite

from vault88.constructs.result import ResultOutcome
from vault88.core.reporter import Reporter


class JUnitReporter(Reporter):
    name = "JUnit XML Reporter"
    version = "1.0.0"
    config_options = {
        "suite_name": 'Test suite name (default: "vault88")',
    }

    def __init__(self, logger, config):
        super().__init__(logger, config)
        self._test_cases: List[TestCase] = []

    def check(self, test) -> bool:
        return any(stage.results for stage in test.stages)

    def publish(self, test) -> None:
        all_results = [result for stage in test.stages for result in stage.results]

        failures = [r for r in all_results if r.outcome == ResultOutcome.FAILED]
        not_run = [r for r in all_results if r.outcome == ResultOutcome.NOT_RUN]

        tc = TestCase(name=test.name, classname=test.__class__.__name__)

        # Include all steps in order as stdout so CI tools can display the full trace
        step_lines = []
        for stage in test.stages:
            step_lines.append(f"[{stage.name}]")
            for r in stage.results:
                step_lines.append(
                    f"  {r.outcome.value.upper()} |"
                    + f"{r.action} |"
                    + f"Expected: {r.expected} |"
                    + f"Actual: {r.actual}"
                )
        tc.stdout = "\n".join(step_lines)

        if failures:
            failure_lines = [
                f"Action: {r.action}\nExpected: {r.expected}\nActual: {r.actual}" for r in failures
            ]
            tc.add_failure_info(
                message=f"{len(failures)} step(s) failed",
                output="\n\n".join(failure_lines),
            )
        elif not_run:
            tc.add_skipped_info(
                message="Test not fully executed",
                output=f"{len(not_run)} step(s) marked as not run",
            )

        self._test_cases.append(tc)

        suite = TestSuite(
            name=self.config.get("suite_name", "vault88"), test_cases=self._test_cases
        )
        output_path = os.path.join(os.getcwd(), "testresults.xml")
        with open(output_path, "w") as f:
            TestSuite.to_file(f, [suite])

        self.logger.info(f"JUnit report written to {output_path}")
