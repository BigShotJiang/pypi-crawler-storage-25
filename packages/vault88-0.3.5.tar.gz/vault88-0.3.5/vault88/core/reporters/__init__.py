"""Built-in reporter registry."""

from .junit_reporter import JUnitReporter
from .log_archive_reporter import LogArchiveReporter
from .pdf_reporter import PdfReporter

BUILTIN_REPORTERS = [JUnitReporter, LogArchiveReporter, PdfReporter]
