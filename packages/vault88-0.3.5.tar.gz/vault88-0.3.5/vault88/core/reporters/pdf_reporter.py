"""PDF Reporter"""

import os
from datetime import datetime, timezone

from reportlab.lib import colors
from reportlab.lib.pagesizes import A4
from reportlab.lib.styles import ParagraphStyle, getSampleStyleSheet
from reportlab.lib.units import cm
from reportlab.platypus import (
    Paragraph,
    SimpleDocTemplate,
    Spacer,
    Table,
    TableStyle,
)

from vault88.constructs.result import ResultOutcome
from vault88.core.reporter import Reporter

_OUTCOME_COLORS = {
    ResultOutcome.PASSED: colors.HexColor("#1e7e34"),
    ResultOutcome.FAILED: colors.HexColor("#c82333"),
    ResultOutcome.NOT_RUN: colors.HexColor("#6c757d"),
}

_OUTCOME_BG = {
    ResultOutcome.PASSED: colors.HexColor("#d4edda"),
    ResultOutcome.FAILED: colors.HexColor("#f8d7da"),
    ResultOutcome.NOT_RUN: colors.HexColor("#e2e3e5"),
}

_HEADER_BG = colors.HexColor("#343a40")
_HEADER_FG = colors.white
_ALT_ROW_BG = colors.HexColor("#f8f9fa")
_BORDER = colors.HexColor("#dee2e6")
_STAGE_BG = colors.HexColor("#495057")


def _build_styles():
    base = getSampleStyleSheet()
    return {
        "title": ParagraphStyle(
            "title",
            parent=base["Title"],
            fontSize=22,
            textColor=colors.HexColor("#212529"),
            spaceAfter=4,
        ),
        "subtitle": ParagraphStyle(
            "subtitle",
            parent=base["Normal"],
            fontSize=10,
            textColor=colors.HexColor("#6c757d"),
            spaceAfter=2,
        ),
        "status_pass": ParagraphStyle(
            "status_pass",
            parent=base["Normal"],
            fontSize=13,
            textColor=_OUTCOME_COLORS[ResultOutcome.PASSED],
            spaceBefore=6,
            spaceAfter=12,
        ),
        "status_fail": ParagraphStyle(
            "status_fail",
            parent=base["Normal"],
            fontSize=13,
            textColor=_OUTCOME_COLORS[ResultOutcome.FAILED],
            spaceBefore=6,
            spaceAfter=12,
        ),
        "stage": ParagraphStyle(
            "stage",
            parent=base["Normal"],
            fontSize=11,
            textColor=colors.white,
            spaceBefore=10,
        ),
        "cell": ParagraphStyle(
            "cell",
            parent=base["Normal"],
            fontSize=8,
            leading=11,
            wordWrap="CJK",
        ),
        "cell_header": ParagraphStyle(
            "cell_header",
            parent=base["Normal"],
            fontSize=8,
            leading=11,
            wordWrap="CJK",
            textColor=colors.white,
        ),
    }


def _result_table(results, styles):
    col_widths = [5.5 * cm, 4 * cm, 4 * cm, 2.2 * cm]
    header = [
        Paragraph("<b>Action</b>", styles["cell_header"]),
        Paragraph("<b>Expected</b>", styles["cell_header"]),
        Paragraph("<b>Actual</b>", styles["cell_header"]),
        Paragraph("<b>Outcome</b>", styles["cell_header"]),
    ]
    rows = [header]
    for r in results:
        outcome_color = _OUTCOME_COLORS[r.outcome]
        rows.append([
            Paragraph(r.action, styles["cell"]),
            Paragraph(str(r.expected), styles["cell"]),
            Paragraph(str(r.actual), styles["cell"]),
            Paragraph(
                f'<font color="{outcome_color.hexval()}"><b>{r.outcome.value.upper()}</b></font>',
                styles["cell"],
            ),
        ])

    tbl = Table(rows, colWidths=col_widths, repeatRows=1)
    row_commands = []
    for i in range(1, len(rows)):
        bg = _OUTCOME_BG[results[i - 1].outcome] if i % 2 == 0 else _ALT_ROW_BG
        row_commands.append(("BACKGROUND", (0, i), (-1, i), bg))

    tbl.setStyle(
        TableStyle(
            [
                ("BACKGROUND", (0, 0), (-1, 0), _HEADER_BG),
                ("TEXTCOLOR", (0, 0), (-1, 0), _HEADER_FG),
                ("GRID", (0, 0), (-1, -1), 0.5, _BORDER),
                ("VALIGN", (0, 0), (-1, -1), "TOP"),
                ("ROWBACKGROUND", (0, 1), (-1, -1), [_ALT_ROW_BG, colors.white]),
                *row_commands,
            ]
        )
    )
    return tbl


def _summary_table(all_results, styles):
    passed = sum(1 for r in all_results if r.outcome == ResultOutcome.PASSED)
    failed = sum(1 for r in all_results if r.outcome == ResultOutcome.FAILED)
    not_run = sum(1 for r in all_results if r.outcome == ResultOutcome.NOT_RUN)
    total = len(all_results)

    rows = [[
        Paragraph(f"<b>Total: {total}</b>", styles["cell"]),
        Paragraph(
            f'<font color="{_OUTCOME_COLORS[ResultOutcome.PASSED].hexval()}">'
            f"<b>Passed: {passed}</b></font>",
            styles["cell"],
        ),
        Paragraph(
            f'<font color="{_OUTCOME_COLORS[ResultOutcome.FAILED].hexval()}">'
            f"<b>Failed: {failed}</b></font>",
            styles["cell"],
        ),
        Paragraph(
            f'<font color="{_OUTCOME_COLORS[ResultOutcome.NOT_RUN].hexval()}">'
            f"<b>Not Run: {not_run}</b></font>",
            styles["cell"],
        ),
    ]]
    tbl = Table(rows, colWidths=[3.925 * cm] * 4)
    tbl.setStyle(
        TableStyle(
            [
                ("BOX", (0, 0), (-1, -1), 0.5, _BORDER),
                ("INNERGRID", (0, 0), (-1, -1), 0.5, _BORDER),
                ("BACKGROUND", (0, 0), (-1, -1), _ALT_ROW_BG),
                ("VALIGN", (0, 0), (-1, -1), "MIDDLE"),
                ("TOPPADDING", (0, 0), (-1, -1), 6),
                ("BOTTOMPADDING", (0, 0), (-1, -1), 6),
            ]
        )
    )
    return tbl


class PdfReporter(Reporter):
    name = "PDF Reporter"
    version = "1.0.0"
    config_options = {
        "output_dir": "Directory to write PDF files (default: current directory)",
    }

    def check(self, test) -> bool:
        return any(stage.results for stage in test.stages)

    def publish(self, test) -> None:
        timestamp = datetime.now(timezone.utc).strftime("%Y%m%d_%H%M%S_%f")
        safe_name = test.name.replace(" ", "_")
        filename = f"{safe_name}-{timestamp}.pdf"
        output_dir = self.config.get("output_dir", os.getcwd())
        os.makedirs(output_dir, exist_ok=True)
        output_path = os.path.join(output_dir, filename)

        styles = _build_styles()
        all_results = [r for stage in test.stages for r in stage.results]
        overall_passed = all(r.outcome == ResultOutcome.PASSED for r in all_results)
        status_style = styles["status_pass"] if overall_passed else styles["status_fail"]
        status_label = "PASSED" if overall_passed else "FAILED"

        doc = SimpleDocTemplate(
            output_path,
            pagesize=A4,
            leftMargin=2 * cm,
            rightMargin=2 * cm,
            topMargin=2 * cm,
            bottomMargin=2 * cm,
        )

        version = getattr(test.__class__, "version", "")
        story = [
            Paragraph(test.name, styles["title"]),
            *(
                [Paragraph(f"Version: {version}", styles["subtitle"])]
                if version else []
            ),
            Paragraph(
                f"Generated: {datetime.now(timezone.utc).strftime('%Y-%m-%d %H:%M:%S UTC')}",
                styles["subtitle"],
            ),
            Paragraph(f"Overall Result: <b>{status_label}</b>", status_style),
            _summary_table(all_results, styles),
            Spacer(1, 0.4 * cm),
        ]

        page_width = A4[0] - 4 * cm
        for stage in test.stages:
            if not stage.results:
                continue
            stage_header = Table(
                [[Paragraph(stage.name, styles["stage"])]],
                colWidths=[page_width],
            )
            stage_header.setStyle(
                TableStyle([
                    ("BACKGROUND", (0, 0), (-1, -1), _STAGE_BG),
                    ("TOPPADDING", (0, 0), (-1, -1), 5),
                    ("BOTTOMPADDING", (0, 0), (-1, -1), 5),
                    ("LEFTPADDING", (0, 0), (-1, -1), 8),
                ])
            )
            story.append(stage_header)
            story.append(_result_table(stage.results, styles))
            story.append(Spacer(1, 0.3 * cm))

        doc.build(story)
        self.logger.info(f"PDF report written to {output_path}")
