"""Blueprint console template — box-framed stage headers, symbol-prefixed steps."""

import textwrap
from typing import List

from vault88.core.console_template import ConsoleTemplate
from vault88.utils.console import _RESET, _visible_truncate, hr, strip_ansi

_BRIGHT_CYAN    = "\033[96m"
_BRIGHT_BLUE    = "\033[94m"
_BRIGHT_YELLOW  = "\033[93m"
_BRIGHT_WHITE   = "\033[97m"
_BRIGHT_BLACK   = "\033[90m"
_WHITE          = "\033[37m"
_BRIGHT_GREEN   = "\033[92m"
_BRIGHT_RED     = "\033[91m"
_BRIGHT_MAGENTA = "\033[95m"
_YELLOW         = "\033[33m"

_DEFAULT_TS_FORMAT = "%H:%M:%S"


def _badge(outcome_val: str):
    if outcome_val == "passed":
        return f"{_BRIGHT_GREEN}[PASS]{_RESET}", "[PASS]"
    elif outcome_val == "failed":
        return f"{_BRIGHT_RED}[FAIL]{_RESET}", "[FAIL]"
    return f"{_YELLOW}[----]{_RESET}", "[----]"


def _field(label: str, value: str, val_color: str, indent: str, width: int) -> List[str]:
    lw = len(label)
    val_w = max(1, width - len(indent) - lw)
    lines = []
    for i, chunk in enumerate(textwrap.wrap(value, width=val_w) or [value]):
        lbl = label if i == 0 else " " * lw
        lines.append(indent + f"{_BRIGHT_BLACK}{lbl}{_RESET}{val_color}{chunk}{_RESET}")
    return lines


class BlueprintTemplate(ConsoleTemplate):
    name = "BlueprintTemplate"
    version = "1.0.0"

    def __init__(self, config: dict = None):
        config = config or {}
        self._ts_format = config.get("timestamp_format", _DEFAULT_TS_FORMAT)

    def render_hr(self, width: int) -> str:
        return hr(width)

    def render_banner(self, title: str, width: int) -> List[str]:
        return [title, hr(width)]

    def render_stage(self, name: str, stage_num: int, width: int) -> List[str]:
        label = f"╔══ STAGE {stage_num}: {name} "
        fill_w = max(0, width - len(label) - 1)
        line = label + "═" * fill_w + "╗"
        return ["", f"{_BRIGHT_CYAN}{line}{_RESET}"]

    def render_result(self, result, stage_num: int, step_num: int, width: int) -> List[str]:
        colored_badge, plain_badge = _badge(result.outcome.value)
        ts = result.timestamp.strftime(self._ts_format)
        step_id = f"{stage_num}-{step_num}"

        prefix_plain = f"  ▶ {step_id}  {ts}  "
        field_indent = " " * len(f"  ▶ {step_id}  ")
        action_w = max(1, width - len(prefix_plain))
        action_chunks = textwrap.wrap(result.action, width=action_w) or [result.action]

        colored_prefix = (
            f"  {_BRIGHT_BLUE}▶ {step_id}{_RESET}"
            f"  {_BRIGHT_YELLOW}{ts}{_RESET}  "
        )
        lines = ["", colored_prefix + f"{_BRIGHT_WHITE}{action_chunks[0]}{_RESET}"]
        for chunk in action_chunks[1:]:
            lines.append(f"{prefix_plain}{_BRIGHT_WHITE}{chunk}{_RESET}")

        fields: List[str] = []
        fields.extend(_field("Expected:  ", result.expected, _WHITE, field_indent, width))
        fields.extend(_field("Actual:    ", result.actual, _WHITE, field_indent, width))
        if result.requirements:
            fields.extend(
                _field(
                    "Reqs:      ",
                    ", ".join(result.requirements),
                    _BRIGHT_MAGENTA,
                    field_indent,
                    width,
                )
            )

        for fl in fields[:-1]:
            lines.append(fl)
        if fields:
            last = fields[-1]
            last_w = len(strip_ansi(last))
            overhead = len(plain_badge) + 3
            if last_w + overhead > width:
                last = _visible_truncate(last, max(0, width - overhead))
                last_w = len(strip_ansi(last))
            dots = max(1, width - last_w - 2 - len(plain_badge))
            lines.append(last + " " + "." * dots + " " + colored_badge)

        lines.append("")
        return lines

    def render_test_summary(
        self, test_name: str, stages, width: int, version: str = ""
    ) -> List[str]:
        display_name = test_name + (f" v{version}" if version else "")
        label = f"╔══ Test Summary: {display_name} "
        fill_w = max(0, width - len(label) - 1)
        header = label + "═" * fill_w + "╗"
        lines = ["", f"{_BRIGHT_CYAN}{header}{_RESET}"]

        had_failure = False
        had_any = False
        for stage_num, stage in enumerate(stages, start=1):
            for step_num, result in enumerate(stage.results, start=1):
                had_any = True
                row_label = f"  Step {stage_num}-{step_num}: "
                action_plain = strip_ansi(result.action)
                if result.outcome.value == "passed":
                    s_plain, s_color = "PASS", _BRIGHT_GREEN
                elif result.outcome.value == "failed":
                    s_plain, s_color = "FAIL", _BRIGHT_RED
                    had_failure = True
                else:
                    s_plain, s_color = "----", _YELLOW
                max_action = width - len(row_label) - 2 - len(s_plain) - 3
                if len(action_plain) > max_action:
                    action_plain = action_plain[:max(0, max_action - 1)] + "…"
                content = row_label + action_plain
                dots = "." * max(3, width - len(content) - 2 - len(s_plain))
                lines.append(f"{content} {dots} {s_color}{s_plain}{_RESET}")

        if had_failure:
            o_plain, o_color = "FAILED", _BRIGHT_RED
        elif had_any:
            o_plain, o_color = "PASSED", _BRIGHT_GREEN
        else:
            o_plain, o_color = "NOT RUN", _YELLOW
        lines.append(f"  Overall: {o_color}{o_plain}{_RESET}")
        return lines

    def render_summary_table(self, rows: List[tuple], width: int) -> List[str]:
        section = "TEST EXECUTION SUMMARY "
        lines = ["", f"{_BRIGHT_CYAN}{section + '═' * (width - len(section))}{_RESET}"]
        for name, outcome in rows:
            if outcome == "passed":
                s_plain, s_color = "PASSED", _BRIGHT_GREEN
            elif outcome == "failed":
                s_plain, s_color = "FAILED", _BRIGHT_RED
            else:
                s_plain, s_color = "NOT RUN", _YELLOW
            max_name = width - 2 - 2 - len(s_plain) - 3
            name_str = name[:max_name] if len(name) > max_name else name
            dots = "." * max(3, width - 2 - len(name_str) - 2 - len(s_plain))
            lines.append(f"  {name_str} {dots} {s_color}{s_plain}{_RESET}")
        return lines

    def render_traceback(self, tb: str, width: int) -> List[str]:
        lines = [""]
        for raw in tb.rstrip().splitlines():
            if len(raw) <= width:
                lines.append(raw)
            else:
                for chunk in textwrap.wrap(raw, width=width) or [raw]:
                    lines.append(chunk)
        lines.append("")
        return lines
