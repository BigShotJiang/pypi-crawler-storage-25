"""Default console output template — preserves the original vault88 look and feel."""

import textwrap
from typing import List

from vault88.core.console_template import ConsoleTemplate
from vault88.utils.console import (
    _GREEN,
    _ORANGE,
    _RED,
    _RESET,
    _badge,
    _field_lines,
    _visible_truncate,
    hr,
    resolve_color,
    strip_ansi,
)

_DEFAULT_TIMESTAMP_FORMAT = "%H:%M:%S"
_DEFAULT_TIMESTAMP_POSITION = "field"


class DefaultTemplate(ConsoleTemplate):
    name = "DefaultTemplate"
    version = "1.0.0"

    def __init__(self, config: dict = None):
        config = config or {}
        self._stage_color = resolve_color(config.get("stage_color", ""))
        self._step_color = resolve_color(config.get("step_color", ""))
        self._timestamp_format = config.get("timestamp_format", _DEFAULT_TIMESTAMP_FORMAT)
        self._timestamp_position = config.get("timestamp_position", _DEFAULT_TIMESTAMP_POSITION)

    def render_hr(self, width: int) -> str:
        return hr(width)

    def render_banner(self, title: str, width: int) -> List[str]:
        return [title, hr(width)]

    def render_stage(self, name: str, stage_num: int, width: int) -> List[str]:
        header = f"### Stage {stage_num}: {name} "
        fill = "─" * max(0, width - len(header))
        full_line = header + fill
        if self._stage_color:
            full_line = f"{self._stage_color}{full_line}{_RESET}"
        return ["", full_line]

    def render_result(self, result, stage_num: int, step_num: int, width: int) -> List[str]:
        inner = width
        colored_badge, plain_badge = _badge(result.outcome.value)
        lines = [""]

        prefix = f"Step {stage_num}-{step_num}: "
        if self._timestamp_position == "inline":
            ts_str = result.timestamp.strftime(self._timestamp_format)
            prefix = f"Step {stage_num}-{step_num}: [{ts_str}] "

        indent = " " * len(prefix)
        action_wrap_w = max(1, inner - len(prefix))
        action_chunks = textwrap.wrap(result.action, width=action_wrap_w) or [result.action]

        if self._step_color:
            lines.append(f"{self._step_color}{prefix}{_RESET}" + action_chunks[0])
        else:
            lines.append(prefix + action_chunks[0])
        for chunk in action_chunks[1:]:
            lines.append(indent + chunk)

        field_lines: List[str] = []
        field_lines.extend(_field_lines("Expected: ", result.expected, inner))
        field_lines.extend(_field_lines("Actual: ", result.actual, inner))

        reqs_str = ", ".join(result.requirements) if result.requirements else ""
        if reqs_str:
            field_lines.extend(_field_lines("Reqs: ", reqs_str, inner))

        if self._timestamp_position == "field":
            ts_str = result.timestamp.strftime(self._timestamp_format)
            field_lines.extend(_field_lines("Timestamp: ", ts_str, inner))

        for field_line in field_lines[:-1]:
            lines.append(field_line)

        if field_lines:
            last = field_lines[-1]
            last_display = len(strip_ansi(last))
            badge_overhead = len(plain_badge) + 3
            if last_display + badge_overhead > inner:
                last = _visible_truncate(last, max(0, inner - badge_overhead))
                last_display = len(strip_ansi(last))
            dots_count = max(1, inner - last_display - 2 - len(plain_badge))
            badged = last + " " + "." * dots_count + " " + colored_badge
            lines.append(badged)

        lines.append("")
        return lines

    def render_test_summary(
        self, test_name: str, stages, width: int, version: str = ""
    ) -> List[str]:
        header_prefix = "─── Test Summary: "
        display_name = test_name + (f" v{version}" if version else "")
        header_suffix = " "
        header_base = header_prefix + display_name + header_suffix
        fill = max(0, width - len(header_base))
        lines = ["", header_prefix + display_name + header_suffix + "─" * fill]

        had_failure = False
        had_any = False

        for stage_num, stage in enumerate(stages, start=1):
            for step_num, result in enumerate(stage.results, start=1):
                had_any = True
                step_label = f"Step {stage_num}-{step_num}: "
                action_plain = strip_ansi(result.action)

                if result.outcome.value == "passed":
                    status_plain, color = "PASS", _GREEN
                elif result.outcome.value == "failed":
                    status_plain, color = "FAIL", _RED
                    had_failure = True
                else:
                    status_plain, color = "----", _ORANGE

                colored_status = f"{color}{status_plain}{_RESET}"
                row_prefix = "  " + step_label
                max_action = width - len(row_prefix) - 2 - len(status_plain) - 3
                if len(action_plain) > max_action:
                    action_plain = action_plain[:max(0, max_action - 1)] + "…"
                content = row_prefix + action_plain
                dots = "." * max(3, width - len(content) - 2 - len(status_plain))
                lines.append(f"{content} {dots} {colored_status}")

        if had_failure:
            overall_plain, overall_color = "FAILED", _RED
        elif had_any:
            overall_plain, overall_color = "PASSED", _GREEN
        else:
            overall_plain, overall_color = "NOT RUN", _ORANGE

        lines.append(f"  Overall: {overall_color}{overall_plain}{_RESET}")
        return lines

    def render_summary_table(self, rows: List[tuple], width: int) -> List[str]:
        section = "TEST EXECUTION SUMMARY "
        lines = ["", section + "─" * (width - len(section))]

        for name, outcome in rows:
            if outcome == "passed":
                status_plain, color = "PASSED", _GREEN
            elif outcome == "failed":
                status_plain, color = "FAILED", _RED
            else:
                status_plain, color = "NOT RUN", _ORANGE

            colored = f"{color}{status_plain}{_RESET}"
            max_name = width - 2 - 2 - len(status_plain) - 3
            name_str = name[:max_name] if len(name) > max_name else name
            dots = "." * max(3, width - 2 - len(name_str) - 2 - len(status_plain))
            lines.append(f"  {name_str} {dots} {colored}")

        return lines

    def render_traceback(self, tb: str, width: int) -> List[str]:
        lines = [""]
        for raw_line in tb.rstrip().splitlines():
            if len(raw_line) <= width:
                lines.append(raw_line)
            else:
                for chunk in textwrap.wrap(raw_line, width=width) or [raw_line]:
                    lines.append(chunk)
        lines.append("")
        return lines
