"""
Model Registry for DataFlow - Persistent Model Storage

This module integrates with DataFlow's existing migration system to provide
persistent model storage, enabling multi-application access to shared model definitions.
"""

import asyncio
import concurrent.futures
import hashlib
import json
import logging
import threading
import uuid
import warnings
from contextlib import contextmanager
from datetime import UTC, datetime
from typing import Any, Dict, List, Optional, Tuple

try:
    from kailash.nodes.data.sql import SQLDatabaseNode
except ImportError:
    SQLDatabaseNode = None  # type: ignore[assignment,misc]
from kailash.runtime import AsyncLocalRuntime, LocalRuntime
from kailash.workflow.builder import WorkflowBuilder

logger = logging.getLogger(__name__)


def _normalize_runtime_result(
    result: Any,
) -> Tuple[Dict[str, Any], Optional[str]]:
    """Normalise the several shapes AsyncLocalRuntime can return.

    ``execute_workflow_async`` returns ``Tuple[Dict, str]`` in current
    builds but older branches return a plain ``Dict`` or a
    ``{"results": ..., "run_id": ...}`` envelope. The model registry
    has historically unpacked the tuple form; this helper coerces any
    of the known shapes into the tuple that callers expect so a single
    unpack line (``results, _ = self._execute_workflow_sync_safe(wf)``)
    keeps working.
    """
    if isinstance(result, tuple):
        results = result[0] if len(result) >= 1 else {}
        run_id = result[1] if len(result) >= 2 else None
        return results, run_id
    if isinstance(result, dict):
        if "results" in result and ("run_id" in result or len(result) <= 2):
            return result.get("results", {}), result.get("run_id")
        return result, None
    return {}, None


class ModelRegistry:
    """Persistent model registry integrated with DataFlow's migration system."""

    # Extend existing migration tables rather than creating new ones
    # This prevents conflicts and leverages proven infrastructure

    def __init__(self, dataflow_instance, runtime=None, migration_system=None):
        """
        Initialize model registry with DataFlow instance.

        Args:
            dataflow_instance: The DataFlow instance this registry belongs to.
            runtime: Optional explicit runtime override. When supplied, the
                registry pins this runtime for its lifetime (legacy escape
                hatch). When omitted (the post-S5 default), every
                ``self.runtime`` access reads ``dataflow_instance.runtime``
                lazily so the registry follows the parent's runtime swap
                (issue #713 — manual ``db.runtime = AsyncLocalRuntime()``
                or first-async-access via S4's per-event-loop cache).
            migration_system: Optional migration system for transactional operations.
        """
        self.dataflow = dataflow_instance
        # S5: hold a back-reference to the parent so ``self.runtime``
        # (now a @property below) can resolve lazily on each access.
        # Pre-S5 the registry snapshotted ``dataflow.runtime`` once at
        # construction; post-S5 it follows the parent's lazy property
        # (S4) which detects async context per access.
        self._dataflow = dataflow_instance

        if runtime is not None:
            # Legacy explicit-runtime escape hatch. Acquire a reference so
            # the caller's close() won't tear down the loop while we
            # still need it. The pinned runtime overrides the parent's
            # lazy resolution for this registry only.
            if hasattr(runtime, "acquire"):
                self._explicit_runtime = runtime.acquire()
                logger.debug(
                    "ModelRegistry: Using injected runtime (ref_count=%d)",
                    getattr(runtime, "ref_count", 0),
                )
            else:
                self._explicit_runtime = runtime
            self._owns_runtime = False
        else:
            # No explicit runtime — defer to parent's lazy property.
            # ``self.runtime`` (the property) will route every read to
            # ``self._dataflow.runtime`` so swaps on the parent (manual
            # ``db.runtime = X`` or first-async-access cache fill) are
            # visible to this registry without snapshot drift.
            self._explicit_runtime = None
            self._owns_runtime = False

        self.migration_system = migration_system
        self._initialized = False

        # Track model definitions as part of migration metadata
        self._model_migration_type = "model_definition"

        # ✅ LAZY REGISTRATION FIX: Queue models during import time
        # This prevents race conditions when models are imported before
        # dataflow_model_registry table is created (e.g., pytest collection phase)
        self._pending_models: List[Tuple[str, type, Optional[str]]] = []
        self._pending_models_lock = threading.Lock()
        logger.debug(
            "ModelRegistry: Lazy registration enabled - models will be queued until initialization completes"
        )

        # Transaction safety
        self._registry_lock = threading.Lock()
        self._transaction_manager = None

        # Initialize transaction manager if available
        try:
            from ..features.transactions import TransactionManager

            self._transaction_manager = TransactionManager(dataflow_instance)
        except ImportError:
            logger.warning(
                "TransactionManager not available, operations will not be transactional"
            )

    # ------------------------------------------------------------------
    # S5 (issue #713): lazy runtime / _is_async via parent DataFlow.
    #
    # Pre-S5 the registry stored ``self.runtime`` and ``self._is_async``
    # as plain attributes set once in ``__init__``. Once the parent
    # DataFlow's runtime swapped (manual ``db.runtime = X`` setter or
    # first-async-access via S4's per-event-loop cache fill), the
    # registry kept the stale snapshot and either crashed (sync runtime
    # used inside an event loop) or routed through the wrong loop.
    #
    # Post-S5 ``self.runtime`` is a @property that resolves on each
    # access:
    #
    # 1. If a legacy explicit-runtime override was supplied to
    #    ``__init__`` (``self._explicit_runtime`` is not None), return
    #    that pinned runtime — the caller is in charge of its lifecycle.
    # 2. Otherwise return ``self._dataflow.runtime`` — the parent's
    #    own lazy property (issue #713 S4 implementation), which
    #    handles per-event-loop caching, sync singleton fallback, and
    #    setter override.
    #
    # ``self._is_async`` is derived from the resolved runtime so it
    # never drifts from ``self.runtime``.
    # ------------------------------------------------------------------

    @property
    def runtime(self) -> Any:
        """The runtime used by this registry (lazy parent lookup)."""
        if self._explicit_runtime is not None:
            return self._explicit_runtime
        return self._dataflow.runtime

    @runtime.setter
    def runtime(self, value: Any) -> None:
        """Assignment-compat setter.

        Two legitimate writes reach this setter:

        * ``self.runtime = None`` from ``close()`` — clears the explicit
          override so subsequent reads (if any) return ``None``-like
          state from the parent's closed runtime.
        * Direct test-time assignment for backwards compatibility with
          callers that monkey-patched the registry's runtime directly.
        """
        self._explicit_runtime = value

    @property
    def _is_async(self) -> bool:
        """Whether the active runtime is an :class:`AsyncLocalRuntime`.

        Derived from ``self.runtime`` so it always agrees with the
        currently-resolved runtime — including after a parent runtime
        swap.
        """
        return isinstance(self.runtime, AsyncLocalRuntime)

    @_is_async.setter
    def _is_async(self, value: bool) -> None:
        """No-op setter for backwards compatibility.

        Pre-S5 callers wrote ``self._is_async = True`` alongside
        ``self.runtime = AsyncLocalRuntime()``. The flag is now derived,
        so this write is ignored — the next read recomputes from
        ``self.runtime``.
        """
        # Intentional no-op: derived property.
        pass

    def _execute_workflow_sync_safe(
        self, workflow: Any
    ) -> Tuple[Dict[str, Any], Optional[str]]:
        """Execute a workflow safely from both sync and async contexts.

        Fixes gh#352: the ModelRegistry's DDL workflows are called from
        ``DataFlow.start()`` which may run under an async context
        (FastAPI startup, uvicorn, pytest-asyncio). When the registry's
        runtime is :class:`AsyncLocalRuntime`, calling ``runtime.execute``
        from inside an event loop raises a ``RuntimeError`` that the
        registry previously swallowed, leaving the
        ``dataflow_model_registry`` table uncreated.

        This helper dispatches on ``self._is_async``:

        * ``False`` → use the sync :class:`LocalRuntime` path directly.
        * ``True`` + no running event loop → ``asyncio.run`` the async
          variant once (safe, no nested loops).
        * ``True`` + running event loop → offload the async execution to
          a dedicated worker thread with its own fresh event loop. The
          worker thread blocks until the DDL workflow completes and
          returns the result; the calling event loop is unaffected.
          Bounded to the 13 model-registry DDL call sites — not a
          general substitute for async-native code.

        Returns:
            The ``(results, run_id)`` tuple that callers already expect
            from ``runtime.execute``.
        """
        built = workflow.build() if hasattr(workflow, "build") else workflow

        if not self._is_async:
            # Sync runtime — direct path, nothing to bridge.
            return self.runtime.execute(built)

        # Async runtime. Check if there's a running event loop.
        try:
            asyncio.get_running_loop()
            in_event_loop = True
        except RuntimeError:
            in_event_loop = False

        if not in_event_loop:
            # Safe to run the async variant directly.
            result = asyncio.run(self.runtime.execute_workflow_async(built, inputs={}))
            return _normalize_runtime_result(result)

        # We're inside an event loop; can't call asyncio.run.
        # Offload to a worker thread that owns a fresh event loop.
        def _run_in_thread() -> Any:
            new_loop = asyncio.new_event_loop()
            try:
                asyncio.set_event_loop(new_loop)
                return new_loop.run_until_complete(
                    self.runtime.execute_workflow_async(built, inputs={})
                )
            finally:
                try:
                    new_loop.close()
                except Exception:  # pragma: no cover — shutdown hygiene
                    logger.debug(
                        "model_registry.workflow_bridge.loop_close_failed",
                        exc_info=True,
                    )
                asyncio.set_event_loop(None)

        with concurrent.futures.ThreadPoolExecutor(
            max_workers=1,
            thread_name_prefix="dataflow-model-registry-bridge",
        ) as executor:
            future = executor.submit(_run_in_thread)
            result = future.result()
        return _normalize_runtime_result(result)

    @contextmanager
    def _transaction_context(self, operation_name: str):
        """Context manager for transaction-safe operations with logging."""
        with self._registry_lock:
            logger.debug(
                "model_registry.starting_registry_operation",
                extra={"operation_name": operation_name},
            )

            if self._transaction_manager:
                # Use existing transaction manager
                with self._transaction_manager.transaction(
                    isolation_level="READ_COMMITTED"
                ) as tx:
                    try:
                        yield tx
                        logger.info(
                            f"Registry operation {operation_name} completed successfully"
                        )
                    except Exception as e:
                        logger.error(
                            "model_registry.registry_operation_failed",
                            extra={"operation_name": operation_name, "error": str(e)},
                        )
                        raise
            else:
                # No transaction support, just use lock
                try:
                    yield None
                    logger.info(
                        f"Registry operation {operation_name} completed (non-transactional)"
                    )
                except Exception as e:
                    logger.error(
                        "model_registry.registry_operation_failed",
                        extra={"operation_name": operation_name, "error": str(e)},
                    )
                    raise

    def initialize(self) -> bool:
        """Initialize model registry with dedicated table and process pending models."""
        try:
            # Create dedicated model registry table instead of extending migration tables
            success = self._create_model_registry_table()
            if success:
                self._initialized = True
                logger.info(
                    "Model registry initialized with dedicated dataflow_model_registry table"
                )

                # ✅ LAZY REGISTRATION FIX: Process all pending models after initialization
                self._finalize_initialization()
            else:
                logger.error("Failed to create model registry table")

            return success

        except Exception as e:
            logger.error(
                "model_registry.error_initializing_model_registry",
                extra={"error": str(e)},
            )
            return False

    def _finalize_initialization(self) -> None:
        """
        Process all pending models after initialization completes.

        This method is called after dataflow_model_registry table is created.
        It registers all models that were queued during import time (before
        the table existed).

        Thread-safe: Uses lock to prevent race conditions during registration.
        """
        with self._pending_models_lock:
            if not self._pending_models:
                logger.debug("No pending models to register")
                return

            pending_count = len(self._pending_models)
            logger.info(
                f"Processing {pending_count} pending model(s) after initialization"
            )

            # Register all pending models
            registered_count = 0
            failed_count = 0

            for model_name, model_class, application_id in self._pending_models:
                try:
                    # Call the actual registration logic (without queueing)
                    success = self._do_register_model(
                        model_name, model_class, application_id
                    )
                    if success:
                        registered_count += 1
                        logger.debug(
                            "model_registry.registered_pending_model",
                            extra={"model_name": model_name},
                        )
                    else:
                        failed_count += 1
                        logger.warning(
                            f"Failed to register pending model: {model_name}"
                        )
                except Exception as e:
                    failed_count += 1
                    logger.error(
                        "model_registry.error_registering_pending_model",
                        extra={"model_name": model_name, "error": str(e)},
                    )

            # Clear the pending queue
            self._pending_models.clear()

            logger.info(
                f"Finalized model registration: {registered_count} succeeded, "
                f"{failed_count} failed out of {pending_count} total"
            )

    def _create_model_registry_table(self) -> bool:
        """Create dedicated dataflow_model_registry table inside a single
        SQLAlchemy transaction so partial failure rolls back atomically.

        Phase 6.2: every model-registry mutation MUST be wrapped in a
        real transaction. The DataFlow ``TransactionManager`` is async
        and bound to the async adapter pool — but the model registry
        runs during ``DataFlow.start()`` which may be sync or async.

        Resolution: acquire a connection from SQLDatabaseNode's shared
        SQLAlchemy engine (the same engine the rest of the registry's
        sync workflows use) and run all DDL inside a single
        ``engine.begin()`` block. SQLAlchemy issues an explicit BEGIN
        on engine.begin() and COMMITs on clean exit / ROLLBACKs on
        exception, giving the same atomicity guarantee
        ``TransactionManager.begin()`` provides for async paths.

        MySQL caveat: every DDL statement implicitly commits regardless
        of the outer transaction (MySQL has no transactional DDL). The
        DDL is idempotent (CREATE TABLE IF NOT EXISTS + each CREATE
        INDEX wrapped in a duplicate-key check below) so a partial
        failure leaves the registry in a state that retries clean. The
        BEGIN/COMMIT wrapper is still emitted because SQLAlchemy
        normalises the contract — it just becomes a no-op transaction
        on MySQL.
        """
        try:
            db_url = self.dataflow.config.database.get_connection_url(
                self.dataflow.config.environment
            )

            from ..adapters.connection_parser import ConnectionParser

            database_type = ConnectionParser.detect_database_type(db_url)

            if database_type == "sqlite":
                statements = self._get_sqlite_registry_table_statements()
            elif database_type == "mysql":
                statements = self._get_mysql_registry_table_statements()
            else:
                statements = self._get_postgresql_registry_table_statements()

            engine = self._acquire_sync_engine(db_url)
            if engine is None:
                # Fallback: legacy per-statement workflow execution.
                # This path runs when SQLDatabaseNode is unavailable
                # (e.g. import-time stub during unit tests).
                return self._create_model_registry_table_legacy(
                    database_type, statements
                )

            from sqlalchemy import text

            with engine.begin() as conn:
                for i, statement in enumerate(statements):
                    try:
                        conn.execute(text(statement))
                    except Exception as exec_error:
                        # MySQL has no transactional DDL — duplicate
                        # index errors mean a previous run created
                        # them and we should continue rather than
                        # rollback the entire bundle. The IF NOT
                        # EXISTS guard on CREATE TABLE protects against
                        # the same race for the table itself.
                        error_lower = str(exec_error).lower()
                        if database_type == "mysql" and (
                            "duplicate key name" in error_lower
                            or "1061" in error_lower
                            or "already exists" in error_lower
                        ):
                            logger.debug(
                                "model_registry.ddl.idempotent_skip",
                                extra={
                                    "statement_index": i,
                                    "error": str(exec_error),
                                },
                            )
                            continue
                        logger.error(
                            "model_registry.ddl.failed",
                            extra={
                                "statement_index": i,
                                "error": str(exec_error),
                            },
                        )
                        # Re-raise so engine.begin() rolls back the
                        # whole bundle on PostgreSQL/SQLite (the
                        # platforms that actually support
                        # transactional DDL).
                        raise

            logger.info(
                "model_registry.table_created",
                extra={"database_type": database_type, "statements": len(statements)},
            )
            return True

        except Exception as e:
            logger.error(
                "model_registry.create_table_failed",
                extra={"error": str(e)},
            )
            return False

    def _acquire_sync_engine(self, db_url: str) -> Any:
        """Return the SQLAlchemy engine SQLDatabaseNode uses for ``db_url``.

        Reuses SQLDatabaseNode's process-wide ``_shared_pools`` so the
        registry's transactional DDL runs against the same connection
        pool the rest of its sync workflow path uses. Returns ``None``
        when SQLDatabaseNode is unavailable so callers can fall back
        to the legacy per-statement path.
        """
        if SQLDatabaseNode is None:
            return None
        try:
            # Instantiate a node solely to materialise the shared
            # engine for this connection string. The node itself isn't
            # executed; we only need its _get_shared_engine() method.
            node = SQLDatabaseNode(connection_string=db_url, query="SELECT 1")
            return node._get_shared_engine()
        except Exception:
            logger.debug(
                "model_registry.sync_engine_unavailable",
                exc_info=True,
            )
            return None

    def _create_model_registry_table_legacy(
        self, database_type: str, statements: List[str]
    ) -> bool:
        """Legacy per-statement workflow path used when SQLDatabaseNode
        is not importable. Each statement runs in its own SQLDatabaseNode
        transaction; partial failure relies on idempotent DDL guards.
        """
        db_url = self.dataflow.config.database.get_connection_url(
            self.dataflow.config.environment
        )
        for i, statement in enumerate(statements):
            workflow = WorkflowBuilder()
            workflow.add_node(
                "SQLDatabaseNode",
                f"create_registry_table_{i}",
                {
                    "connection_string": db_url,
                    "database_type": database_type,
                    "query": statement,
                    "validate_queries": False,
                },
            )
            try:
                results, _ = self._execute_workflow_sync_safe(workflow)
                if f"create_registry_table_{i}" not in results or results[
                    f"create_registry_table_{i}"
                ].get("error"):
                    error_msg = results.get(f"create_registry_table_{i}", {}).get(
                        "error", "Unknown error"
                    )
                    error_lower = str(error_msg).lower()
                    if database_type == "mysql" and (
                        "duplicate key name" in error_lower
                        or "already exists" in error_lower
                    ):
                        continue
                    logger.error(
                        f"Failed to execute registry table statement {i}: {error_msg}"
                    )
                    return False
            except Exception as exec_error:
                error_lower = str(exec_error).lower()
                if database_type == "mysql" and (
                    "duplicate key name" in error_lower
                    or "1061" in error_lower
                    or "already exists" in error_lower
                ):
                    continue
                raise
        return True

    def _get_sqlite_registry_table_statements(self) -> List[str]:
        """Get SQLite model registry table creation statements."""
        return [
            """
            CREATE TABLE IF NOT EXISTS dataflow_model_registry (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                model_name TEXT NOT NULL,
                model_checksum TEXT NOT NULL,
                model_definitions TEXT NOT NULL,
                application_id TEXT,
                registered_at TEXT DEFAULT CURRENT_TIMESTAMP,
                updated_at TEXT DEFAULT CURRENT_TIMESTAMP,
                status TEXT DEFAULT 'active',
                version INTEGER DEFAULT 1,
                metadata TEXT,
                UNIQUE(model_name, application_id)
            )
            """,
            "CREATE INDEX IF NOT EXISTS idx_model_registry_application ON dataflow_model_registry(application_id)",
            "CREATE INDEX IF NOT EXISTS idx_model_registry_checksum ON dataflow_model_registry(model_checksum)",
            "CREATE INDEX IF NOT EXISTS idx_model_registry_name ON dataflow_model_registry(model_name)",
            "CREATE INDEX IF NOT EXISTS idx_model_registry_status ON dataflow_model_registry(status)",
        ]

    def _get_postgresql_registry_table_statements(self) -> List[str]:
        """Get PostgreSQL model registry table creation statements."""
        return [
            """
            CREATE TABLE IF NOT EXISTS dataflow_model_registry (
                id SERIAL PRIMARY KEY,
                model_name VARCHAR(255) NOT NULL,
                model_checksum VARCHAR(64) NOT NULL,
                model_definitions JSONB NOT NULL,
                application_id VARCHAR(255),
                registered_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
                updated_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
                status VARCHAR(50) DEFAULT 'active',
                version INTEGER DEFAULT 1,
                metadata JSONB,
                CONSTRAINT unique_model_per_app UNIQUE (model_name, application_id)
            )
            """,
            "CREATE INDEX IF NOT EXISTS idx_model_registry_application ON dataflow_model_registry(application_id)",
            "CREATE INDEX IF NOT EXISTS idx_model_registry_checksum ON dataflow_model_registry(model_checksum)",
            "CREATE INDEX IF NOT EXISTS idx_model_registry_name ON dataflow_model_registry(model_name)",
            "CREATE INDEX IF NOT EXISTS idx_model_registry_status ON dataflow_model_registry(status)",
        ]

    def _get_mysql_registry_table_statements(self) -> List[str]:
        """Get MySQL model registry table creation statements."""
        return [
            """
            CREATE TABLE IF NOT EXISTS dataflow_model_registry (
                id INT AUTO_INCREMENT PRIMARY KEY,
                model_name VARCHAR(255) NOT NULL,
                model_checksum VARCHAR(64) NOT NULL,
                model_definitions JSON NOT NULL,
                application_id VARCHAR(255),
                registered_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
                status VARCHAR(50) DEFAULT 'active',
                version INT DEFAULT 1,
                metadata JSON,
                UNIQUE KEY unique_model_per_app (model_name, application_id)
            )
            """,
            "CREATE INDEX idx_model_registry_application ON dataflow_model_registry(application_id)",
            "CREATE INDEX idx_model_registry_checksum ON dataflow_model_registry(model_checksum)",
            "CREATE INDEX idx_model_registry_name ON dataflow_model_registry(model_name)",
            "CREATE INDEX idx_model_registry_status ON dataflow_model_registry(status)",
        ]

    def _extract_query_data(
        self, results: Dict[str, Any], node_id: str
    ) -> Optional[List[Dict[str, Any]]]:
        """Extract data from query results, handling different result structures."""
        node_result = results.get(node_id, {})

        # Check for result.data structure (newer format)
        if "result" in node_result and "data" in node_result["result"]:
            return node_result["result"]["data"]

        # Check for direct data structure (older format)
        if "data" in node_result:
            return node_result["data"]

        # Check for result as list
        if "result" in node_result and isinstance(node_result["result"], list):
            return node_result["result"]

        return None

    def _make_json_serializable(self, obj: Any) -> Any:
        """Convert Python objects to JSON-serializable format.

        This handles Python type objects that can't be directly serialized to JSON.
        """
        from datetime import date, datetime, time
        from decimal import Decimal

        if isinstance(obj, dict):
            return {
                key: self._make_json_serializable(value) for key, value in obj.items()
            }
        elif isinstance(obj, list):
            return [self._make_json_serializable(item) for item in obj]
        elif isinstance(obj, datetime):
            # Convert datetime to ISO format string
            return obj.isoformat()
        elif isinstance(obj, date):
            # Convert date to ISO format string
            return obj.isoformat()
        elif isinstance(obj, time):
            # Convert time to ISO format string
            return obj.isoformat()
        elif isinstance(obj, Decimal):
            # Convert Decimal to string to preserve precision
            return str(obj)
        elif isinstance(obj, type):
            # Convert Python type objects to string representation
            return obj.__name__
        elif hasattr(obj, "__name__") and hasattr(obj, "__module__"):
            # Handle other callable objects that might have names
            return (
                f"{obj.__module__}.{obj.__name__}"
                if obj.__module__ != "builtins"
                else obj.__name__
            )
        elif callable(obj):
            return (
                f"<callable:{obj.__name__ if hasattr(obj, '__name__') else str(obj)}>"
            )
        else:
            # Handle SQLAlchemy MetaData and other non-serializable objects
            try:
                json.dumps(obj)
                return obj
            except (TypeError, ValueError):
                return f"<{type(obj).__name__}>"

    def _generate_unified_checksum(self, content: Dict[str, Any]) -> str:
        """Generate checksum for model definition."""
        # Make content JSON serializable before calculating checksum
        serializable_content = self._make_json_serializable(content)
        sorted_content = json.dumps(serializable_content, sort_keys=True)
        return hashlib.sha256(sorted_content.encode()).hexdigest()

    def register_model(
        self, model_name: str, model_class: type, application_id: str = None
    ) -> bool:
        """
        Register a model definition in the registry (with lazy registration support).

        If the registry is not yet initialized (e.g., during pytest collection phase),
        the model is queued for later registration. Otherwise, it's registered immediately.

        Args:
            model_name: Name of the model class
            model_class: The model class to register
            application_id: Optional application identifier

        Returns:
            bool: True if model was queued or registered successfully

        Note:
            This method implements lazy registration to prevent race conditions
            when models are imported before dataflow_model_registry table exists.
        """
        # ✅ LAZY REGISTRATION FIX: Queue models if not initialized
        if not self._initialized:
            with self._pending_models_lock:
                # Check if model is already in pending queue
                for pending_name, _, _ in self._pending_models:
                    if pending_name == model_name:
                        logger.debug(
                            f"Model {model_name} already in pending queue, skipping"
                        )
                        return True

                # Add to pending queue
                self._pending_models.append((model_name, model_class, application_id))
                logger.info(
                    f"Model {model_name} queued for registration "
                    f"(registry not initialized yet, {len(self._pending_models)} pending)"
                )
                return True

        # Registry is initialized, register immediately
        return self._do_register_model(model_name, model_class, application_id)

    def _do_register_model(
        self, model_name: str, model_class: type, application_id: str = None
    ) -> bool:
        """
        Actual model registration logic (internal method).

        This method performs the database operations to register a model.
        It should only be called when the registry is initialized.

        Args:
            model_name: Name of the model class
            model_class: The model class to register
            application_id: Optional application identifier

        Returns:
            bool: True if registration succeeded
        """
        try:
            # Extract model metadata
            model_definitions = self._extract_model_metadata(model_class)
            model_definitions["model_name"] = model_name

            # Generate checksum
            model_checksum = self._generate_unified_checksum(model_definitions)

            # Check if already registered with same checksum
            if self._model_exists_with_checksum(model_checksum):
                logger.debug(
                    f"Model {model_name} already registered with checksum {model_checksum}"
                )
                return True

            # Register the model with database-specific query
            db_url = self.dataflow.config.database.get_connection_url(
                self.dataflow.config.environment
            )

            # Import connection parser and detect database type
            from ..adapters.connection_parser import ConnectionParser

            database_type = ConnectionParser.detect_database_type(db_url)

            workflow = WorkflowBuilder()

            if database_type == "sqlite":
                # SQLite uses INSERT OR REPLACE and ? parameters
                workflow.add_node(
                    "SQLDatabaseNode",
                    "register_model",
                    {
                        "connection_string": db_url,
                        "database_type": database_type,
                        "query": """
                        INSERT OR REPLACE INTO dataflow_model_registry
                        (model_name, model_checksum, model_definitions, application_id,
                         status, version, metadata, updated_at)
                        VALUES (?, ?, ?, ?, ?,
                                COALESCE((SELECT version + 1 FROM dataflow_model_registry
                                         WHERE model_name = ? AND application_id = ?), 1),
                                ?, datetime('now'))
                    """,
                        "parameters": [
                            model_name,
                            model_checksum,
                            json.dumps(model_definitions),
                            application_id or self._get_application_id(),
                            "active",
                            model_name,  # For version calculation
                            application_id
                            or self._get_application_id(),  # For version calculation
                            json.dumps(
                                {
                                    "source": "model_registry",
                                    "timestamp": datetime.now(UTC).isoformat(),
                                }
                            ),
                        ],
                    },
                )
            elif database_type == "mysql":
                # MySQL uses ON DUPLICATE KEY UPDATE and %s parameters
                workflow.add_node(
                    "SQLDatabaseNode",
                    "register_model",
                    {
                        "connection_string": db_url,
                        "database_type": database_type,
                        "query": """
                        INSERT INTO dataflow_model_registry
                        (model_name, model_checksum, model_definitions, application_id,
                         status, version, metadata)
                        VALUES (%s, %s, %s, %s, %s, %s, %s)
                        ON DUPLICATE KEY UPDATE
                            model_checksum = VALUES(model_checksum),
                            model_definitions = VALUES(model_definitions),
                            updated_at = CURRENT_TIMESTAMP,
                            version = version + 1
                    """,
                        "parameters": [
                            model_name,
                            model_checksum,
                            json.dumps(model_definitions),
                            application_id or self._get_application_id(),
                            "active",
                            1,
                            json.dumps(
                                {
                                    "source": "model_registry",
                                    "timestamp": datetime.now(UTC).isoformat(),
                                }
                            ),
                        ],
                    },
                )
            else:
                # PostgreSQL uses ON CONFLICT and $1 parameters
                workflow.add_node(
                    "SQLDatabaseNode",
                    "register_model",
                    {
                        "connection_string": db_url,
                        "database_type": database_type,
                        "query": """
                        INSERT INTO dataflow_model_registry
                        (model_name, model_checksum, model_definitions, application_id,
                         status, version, metadata)
                        VALUES ($1, $2, $3, $4, $5, $6, $7)
                        ON CONFLICT (model_name, application_id)
                        DO UPDATE SET
                            model_checksum = EXCLUDED.model_checksum,
                            model_definitions = EXCLUDED.model_definitions,
                            updated_at = CURRENT_TIMESTAMP,
                            version = dataflow_model_registry.version + 1
                    """,
                        "parameters": [
                            model_name,
                            model_checksum,
                            json.dumps(model_definitions),
                            application_id or self._get_application_id(),
                            "active",
                            1,
                            json.dumps(
                                {
                                    "source": "model_registry",
                                    "timestamp": datetime.now(UTC).isoformat(),
                                }
                            ),
                        ],
                    },
                )

            results, _ = self._execute_workflow_sync_safe(workflow)

            if results.get("register_model", {}).get("error"):
                logger.error(
                    f"Failed to register model {model_name}: {results['register_model']['error']}"
                )
                return False

            logger.info(
                f"Successfully registered model {model_name} with checksum {model_checksum}"
            )
            return True

        except Exception as e:
            logger.error(
                "model_registry.error_registering_model",
                extra={"model_name": model_name, "error": str(e)},
            )
            return False

    def discover_models(self) -> Dict[str, Dict[str, Any]]:
        """Discover models from model registry."""
        if not self._initialized:
            if not self.initialize():
                return {}

        workflow = WorkflowBuilder()

        # Get database-specific query
        db_url = self.dataflow.config.database.get_connection_url(
            self.dataflow.config.environment
        )

        # Import connection parser and detect database type
        from ..adapters.connection_parser import ConnectionParser

        database_type = ConnectionParser.detect_database_type(db_url)

        if database_type == "sqlite":
            # SQLite doesn't support DISTINCT ON, use window functions
            query = """
                SELECT model_name, model_definitions, model_checksum, registered_at, application_id
                FROM (
                    SELECT model_name, model_definitions, model_checksum, registered_at, application_id,
                           ROW_NUMBER() OVER (PARTITION BY model_name ORDER BY version DESC) as rn
                    FROM dataflow_model_registry
                    WHERE status = 'active'
                ) ranked
                WHERE rn = 1
                ORDER BY model_name
            """
        else:
            # PostgreSQL supports DISTINCT ON
            query = """
                WITH latest_models AS (
                    SELECT DISTINCT ON (model_name)
                        model_name,
                        model_definitions,
                        model_checksum,
                        registered_at,
                        application_id
                    FROM dataflow_model_registry
                    WHERE status = 'active'
                    ORDER BY model_name, version DESC
                )
                SELECT * FROM latest_models
                ORDER BY model_name
            """

        workflow.add_node(
            "SQLDatabaseNode",
            "discover",
            {
                "connection_string": db_url,
                "database_type": database_type,
                "query": query,
            },
        )

        results, _ = self._execute_workflow_sync_safe(workflow)

        models = {}
        data = self._extract_query_data(results, "discover")

        if data:
            for row in data:
                model_name = row["model_name"]
                # Handle both string and dict formats for model_definitions
                model_def = row["model_definitions"]
                if isinstance(model_def, str):
                    model_def = json.loads(model_def)

                # Normalize field types in discovered models
                if "fields" in model_def:
                    for field_name, field_info in model_def["fields"].items():
                        if "type" in field_info:
                            field_info["type"] = self._normalize_stored_field_type(
                                field_info["type"]
                            )

                models[model_name] = {
                    "definition": model_def,
                    "checksum": row["model_checksum"],
                    "registered_at": row["registered_at"],
                    "application_id": row["application_id"],
                }

        return models

    def sync_models(self, force: bool = False) -> Tuple[int, int]:
        """Sync models from migration history to DataFlow instance.

        Returns:
            Tuple of (models_added, models_updated)
        """
        discovered = self.discover_models()
        added = 0
        updated = 0

        for model_name, model_info in discovered.items():
            if model_name not in self.dataflow._models or force:
                # Reconstruct model class dynamically
                success = self._reconstruct_model(model_name, model_info)
                if success:
                    if model_name in self.dataflow._models:
                        updated += 1
                    else:
                        added += 1

        logger.info(
            "model_registry.model_sync_complete_added_updated",
            extra={"added": added, "updated": updated},
        )
        return added, updated

    def get_model_version(self, model_name: str) -> int:
        """Get latest version number for a model from registry."""
        workflow = WorkflowBuilder()

        workflow.add_node(
            "SQLDatabaseNode",
            "get_version",
            {
                "connection_string": connection_url,
                "database_type": database_type,
                "query": """
                SELECT MAX(version) as max_version
                FROM dataflow_model_registry
                WHERE model_name = $1
                  AND status = 'active'
            """,
                "parameters": [model_name],
            },
        )

        results, _ = self._execute_workflow_sync_safe(workflow)

        data = self._extract_query_data(results, "get_version")
        if data and len(data) > 0:
            return data[0].get("max_version", 0) or 0

        return 0

    def get_model_history(self, model_name: str) -> List[Dict[str, Any]]:
        """Get version history for a model from registry."""
        workflow = WorkflowBuilder()

        # Get connection URL and detect database type
        from ..adapters.connection_parser import ConnectionParser

        connection_url = self.dataflow.config.database.get_connection_url(
            self.dataflow.config.environment
        )
        database_type = ConnectionParser.detect_database_type(connection_url)

        workflow.add_node(
            "SQLDatabaseNode",
            "get_history",
            {
                "connection_string": connection_url,
                "database_type": database_type,
                "query": """
                SELECT
                    version,
                    model_checksum,
                    model_definitions,
                    application_id,
                    registered_at,
                    updated_at,
                    status,
                    metadata
                FROM dataflow_model_registry
                WHERE model_name = $1
                ORDER BY version DESC
            """,
                "parameters": [model_name],
            },
        )

        results, _ = self._execute_workflow_sync_safe(workflow)

        history = []
        data = self._extract_query_data(results, "get_history")

        if data:
            for row in data:
                history.append(
                    {
                        "version": row["version"],
                        "checksum": row["model_checksum"],
                        "definitions": (
                            json.loads(row["model_definitions"])
                            if isinstance(row["model_definitions"], str)
                            else row["model_definitions"]
                        ),
                        "application_id": row["application_id"],
                        "registered_at": row["registered_at"],
                        "updated_at": row["updated_at"],
                        "status": row["status"],
                        "metadata": (
                            json.loads(row["metadata"])
                            if isinstance(row["metadata"], str)
                            else row["metadata"]
                        ),
                    }
                )

        return history

    def _model_exists_with_checksum(self, checksum: str) -> bool:
        """
        Check if model with this checksum already exists.

        Returns False if registry is not initialized (lazy registration mode).
        """
        # ✅ LAZY REGISTRATION FIX: Return False if not initialized
        # This prevents querying dataflow_model_registry before table exists
        if not self._initialized:
            logger.debug(
                "Registry not initialized, skipping checksum check "
                "(lazy registration mode)"
            )
            return False

        workflow = WorkflowBuilder()

        db_url = self.dataflow.config.database.get_connection_url(
            self.dataflow.config.environment
        )

        # Import connection parser and detect database type
        from ..adapters.connection_parser import ConnectionParser

        database_type = ConnectionParser.detect_database_type(db_url)

        if database_type == "sqlite":
            # SQLite doesn't have EXISTS as a direct return, use COUNT instead
            query = """
                SELECT (COUNT(*) > 0) as exists_result FROM dataflow_model_registry
                WHERE model_checksum = ? AND status = 'active'
            """
        else:
            query = """
                SELECT EXISTS (
                    SELECT 1 FROM dataflow_model_registry
                    WHERE model_checksum = $1
                      AND status = 'active'
                )
            """

        workflow.add_node(
            "SQLDatabaseNode",
            "check_checksum",
            {
                "connection_string": db_url,
                "database_type": database_type,
                "query": query,
                "parameters": [checksum],
            },
        )

        results, _ = self._execute_workflow_sync_safe(workflow)

        data = self._extract_query_data(results, "check_checksum")
        if data and len(data) > 0:
            # Handle different column names for different database types
            result = data[0]
            return result.get("exists", result.get("exists_result", False))

        return False

    def _normalize_field_type(self, field_type: Any) -> str:
        """Normalize Python type objects to simple string representations.

        This prevents 'Unknown field type <class str>' warnings by converting
        Python type objects to their simple names.
        """
        if isinstance(field_type, type):
            # Handle built-in types
            if field_type.__module__ == "builtins":
                return field_type.__name__
            else:
                # For non-builtin types, use module.name format
                return f"{field_type.__module__}.{field_type.__name__}"
        elif hasattr(field_type, "__name__"):
            # Handle other objects with __name__ attribute
            return field_type.__name__
        elif hasattr(field_type, "__origin__"):
            # Handle typing generics like List[str], Optional[int], etc.
            origin = field_type.__origin__
            if origin.__module__ == "builtins":
                return origin.__name__
            else:
                return f"{origin.__module__}.{origin.__name__}"
        else:
            # Fallback to string representation
            return str(field_type)

    def _normalize_stored_field_type(self, field_type_str: str) -> str:
        """Normalize stored field types from old format to new format.

        Converts "<class 'str'>" format to "str" format.
        """
        if not isinstance(field_type_str, str):
            return str(field_type_str)

        # Handle old <class 'name'> format
        if field_type_str.startswith("<class '") and field_type_str.endswith("'>"):
            # Extract the class name from <class 'name'>
            class_name = field_type_str[8:-2]  # Remove "<class '" and "'>"
            return class_name
        elif field_type_str.startswith('<class "') and field_type_str.endswith('">'):
            # Handle double quotes variant
            class_name = field_type_str[8:-2]  # Remove '<class "' and '">'
            return class_name
        else:
            # Already normalized or different format
            return field_type_str

    def _extract_model_metadata(self, model_class: type) -> Dict[str, Any]:
        """Extract metadata from a model class."""
        metadata = {
            "class_name": model_class.__name__,
            "module": (
                model_class.__module__ if hasattr(model_class, "__module__") else None
            ),
            "fields": {},
            "options": {},
        }

        # Extract field annotations.  Routes through the shared helper so
        # PEP 649/749 lazy annotations on Python 3.14+ resolve safely.
        from kailash.utils.annotations import get_resolved_type_hints

        model_annotations = get_resolved_type_hints(model_class)
        if model_annotations:
            for field_name, field_type in model_annotations.items():
                metadata["fields"][field_name] = {
                    "type": self._normalize_field_type(field_type),
                    "required": not hasattr(
                        model_class, field_name
                    ),  # Has default = not required
                }

                # Get default value if exists
                if hasattr(model_class, field_name):
                    default_value = getattr(model_class, field_name)
                    metadata["fields"][field_name]["default"] = (
                        self._make_json_serializable(default_value)
                    )
                    metadata["fields"][field_name]["required"] = False

        # Extract any additional metadata
        if hasattr(model_class, "__dataflow_meta__"):
            metadata["options"] = model_class.__dataflow_meta__

        return metadata

    def _get_application_id(self) -> str:
        """Get or generate an application ID."""
        if hasattr(self.dataflow.config, "application_id"):
            return self.dataflow.config.application_id

        # Generate a stable ID based on the DataFlow instance
        return f"dataflow_{id(self.dataflow) % 1000000}"

    def _reconstruct_model(self, model_name: str, model_info: Dict[str, Any]) -> bool:
        """Reconstruct model class from stored definition with rollback on failure."""
        # Store original state for rollback
        original_models = self.dataflow._models.copy()
        original_registered = self.dataflow._registered_models.copy()
        original_fields = self.dataflow._model_fields.copy()

        try:
            # Extract definition from model_info structure
            definition = model_info.get(
                "definition", model_info
            )  # Handle both structures

            # Create dynamic class with stored fields
            fields = definition.get("fields", {})
            options = definition.get("options", {})

            # Validate that we have fields
            if not fields:
                logger.warning(
                    f"Model {model_name} has no fields in definition, skipping reconstruction"
                )
                return False

            # Build class attributes
            attrs = {"__dataflow__": options}

            # Add field annotations
            annotations = {}
            type_map = {
                "str": str,
                "int": int,
                "float": float,
                "bool": bool,
                "datetime": datetime,
                "date": datetime,
                "time": datetime,
                "json": dict,
                "jsonb": dict,
                "list": list,
                "dict": dict,
                "uuid": str,
                "decimal": float,
                "text": str,
                "varchar": str,
                "char": str,
                "integer": int,
                "bigint": int,
                "smallint": int,
                "numeric": float,
                "real": float,
                "double": float,
                "boolean": bool,
                "timestamp": datetime,
                "timestamptz": datetime,
                "array": list,
            }

            for field_name, field_info in fields.items():
                field_type = field_info.get("type", "str")

                # Normalize field type if it's in old <class 'name'> format
                field_type = self._normalize_stored_field_type(field_type)

                # Validate and warn for unknown types
                if field_type not in type_map:
                    logger.warning(
                        f"Unknown field type '{field_type}' for {model_name}.{field_name}, "
                        f"defaulting to string. Known types: {list(type_map.keys())}"
                    )

                python_type = type_map.get(field_type, str)
                annotations[field_name] = python_type

                # Set default value if provided
                if "default" in field_info:
                    try:
                        # Handle callable defaults
                        default_value = field_info["default"]
                        if (
                            isinstance(default_value, str)
                            and default_value == "<function>"
                        ):
                            # Skip function defaults in reconstruction
                            continue
                        attrs[field_name] = default_value
                    except Exception as e:
                        logger.warning(
                            f"Could not set default for {model_name}.{field_name}: {e}"
                        )

            attrs["__annotations__"] = annotations

            # Create the class dynamically
            model_class = type(model_name, (), attrs)

            # Test instantiation before registering
            try:
                test_instance = model_class()
                del test_instance  # Clean up
            except Exception as e:
                raise ValueError(
                    f"Reconstructed model {model_name} failed instantiation test: {e}"
                )

            # Register with DataFlow
            self.dataflow.model(model_class)

            logger.info(
                f"Successfully reconstructed model {model_name} with "
                f"{len(fields)} fields from {model_info.get('application_id', 'unknown')} "
                f"application"
            )

            return True

        except Exception as e:
            # Rollback on failure
            logger.error(
                f"Failed to reconstruct model {model_name}: {e}. "
                f"Rolling back DataFlow state."
            )

            self.dataflow._models = original_models
            self.dataflow._registered_models = original_registered
            self.dataflow._model_fields = original_fields

            return False

    def validate_consistency(self) -> Dict[str, List[str]]:
        """Validate model consistency across applications."""
        issues = {}

        # Get all unique model names
        workflow = WorkflowBuilder()

        # Get connection URL and detect database type
        from ..adapters.connection_parser import ConnectionParser

        connection_url = self.dataflow.config.database.get_connection_url(
            self.dataflow.config.environment
        )
        database_type = ConnectionParser.detect_database_type(connection_url)

        workflow.add_node(
            "SQLDatabaseNode",
            "get_models",
            {
                "connection_string": connection_url,
                "database_type": database_type,
                "query": """
                SELECT DISTINCT model_name
                FROM dataflow_model_registry
                WHERE status = 'active'
            """,
            },
        )

        results, _ = self._execute_workflow_sync_safe(workflow)

        data = self._extract_query_data(results, "get_models")
        if data:
            for row in data:
                model_name = row["model_name"]
                checksums = self._get_model_checksums_by_app(model_name)

                # Check for inconsistencies
                unique_checksums = set(checksums.values())
                if len(unique_checksums) > 1:
                    issues[model_name] = [
                        f"Model definition mismatch between applications: {checksums}"
                    ]

        return issues

    def _get_model_checksums_by_app(self, model_name: str) -> Dict[str, str]:
        """Get model checksums grouped by application."""
        workflow = WorkflowBuilder()

        # Get connection URL and detect database type
        from ..adapters.connection_parser import ConnectionParser

        connection_url = self.dataflow.config.database.get_connection_url(
            self.dataflow.config.environment
        )
        database_type = ConnectionParser.detect_database_type(connection_url)

        workflow.add_node(
            "SQLDatabaseNode",
            "get_checksums",
            {
                "connection_string": connection_url,
                "database_type": database_type,
                "query": """
                WITH latest_by_app AS (
                    SELECT DISTINCT ON (application_id)
                        application_id,
                        model_checksum
                    FROM dataflow_model_registry
                    WHERE model_name = $1
                      AND status = 'active'
                    ORDER BY application_id, version DESC
                )
                SELECT application_id, model_checksum as checksum
                FROM latest_by_app
            """,
                "parameters": [model_name],
            },
        )

        results, _ = self._execute_workflow_sync_safe(workflow)

        checksums = {}
        data = self._extract_query_data(results, "get_checksums")
        if data:
            for row in data:
                checksums[row["application_id"]] = row["checksum"]

        return checksums

    def get_latest_model_for_app(
        self, model_name: str, application_id: str
    ) -> Optional[Dict[str, Any]]:
        """Get latest model definition for a specific application."""
        workflow = WorkflowBuilder()

        # Get connection URL and detect database type
        from ..adapters.connection_parser import ConnectionParser

        connection_url = self.dataflow.config.database.get_connection_url(
            self.dataflow.config.environment
        )
        database_type = ConnectionParser.detect_database_type(connection_url)

        workflow.add_node(
            "SQLDatabaseNode",
            "get_model",
            {
                "connection_string": connection_url,
                "database_type": database_type,
                "query": """
                SELECT model_definitions
                FROM dataflow_model_registry
                WHERE model_name = $1
                  AND application_id = $2
                  AND status = 'active'
                ORDER BY version DESC
                LIMIT 1
            """,
                "parameters": [model_name, application_id],
            },
        )

        results, _ = self._execute_workflow_sync_safe(workflow)

        data = self._extract_query_data(results, "get_model")
        if data and len(data) > 0:
            model_def = data[0]["model_definitions"]
            if isinstance(model_def, str):
                return json.loads(model_def)
            return model_def

        return None

    def list_applications(self) -> List[str]:
        """List all applications that have registered models."""
        workflow = WorkflowBuilder()

        # Get connection URL and detect database type
        from ..adapters.connection_parser import ConnectionParser

        connection_url = self.dataflow.config.database.get_connection_url(
            self.dataflow.config.environment
        )
        database_type = ConnectionParser.detect_database_type(connection_url)

        workflow.add_node(
            "SQLDatabaseNode",
            "list_apps",
            {
                "connection_string": connection_url,
                "database_type": database_type,
                "query": """
                SELECT DISTINCT application_id
                FROM dataflow_model_registry
                WHERE application_id IS NOT NULL
                  AND status = 'active'
                ORDER BY application_id
            """,
            },
        )

        results, _ = self._execute_workflow_sync_safe(workflow)
        data = self._extract_query_data(results, "list_apps")

        if data:
            return [row["application_id"] for row in data]

        return []

    def get_models_by_application(self, application_id: str) -> List[Dict[str, Any]]:
        """Get all models registered by a specific application."""
        workflow = WorkflowBuilder()

        # Get connection URL and detect database type
        from ..adapters.connection_parser import ConnectionParser

        connection_url = self.dataflow.config.database.get_connection_url(
            self.dataflow.config.environment
        )
        database_type = ConnectionParser.detect_database_type(connection_url)

        workflow.add_node(
            "SQLDatabaseNode",
            "get_by_app",
            {
                "connection_string": connection_url,
                "database_type": database_type,
                "query": """
                WITH latest_models AS (
                    SELECT DISTINCT ON (model_name)
                        model_name,
                        model_checksum,
                        model_definitions,
                        version,
                        registered_at,
                        updated_at
                    FROM dataflow_model_registry
                    WHERE application_id = $1
                      AND status = 'active'
                    ORDER BY model_name, version DESC
                )
                SELECT * FROM latest_models
                ORDER BY model_name
            """,
                "parameters": [application_id],
            },
        )

        results, _ = self._execute_workflow_sync_safe(workflow)
        data = self._extract_query_data(results, "get_by_app")

        models = []
        if data:
            for row in data:
                models.append(
                    {
                        "model_name": row["model_name"],
                        "checksum": row["model_checksum"],
                        "definitions": (
                            json.loads(row["model_definitions"])
                            if isinstance(row["model_definitions"], str)
                            else row["model_definitions"]
                        ),
                        "version": row["version"],
                        "registered_at": row["registered_at"],
                        "updated_at": row["updated_at"],
                    }
                )

        return models

    def get_model_by_checksum(self, checksum: str) -> Optional[Dict[str, Any]]:
        """Get a specific model by its checksum."""
        workflow = WorkflowBuilder()

        # Get connection URL and detect database type
        from ..adapters.connection_parser import ConnectionParser

        connection_url = self.dataflow.config.database.get_connection_url(
            self.dataflow.config.environment
        )
        database_type = ConnectionParser.detect_database_type(connection_url)

        workflow.add_node(
            "SQLDatabaseNode",
            "get_by_checksum",
            {
                "connection_string": connection_url,
                "database_type": database_type,
                "query": """
                SELECT
                    model_name,
                    model_definitions,
                    application_id,
                    registered_at,
                    version,
                    status
                FROM dataflow_model_registry
                WHERE model_checksum = $1
                  AND status = 'active'
                ORDER BY version DESC
                LIMIT 1
            """,
                "parameters": [checksum],
            },
        )

        results, _ = self._execute_workflow_sync_safe(workflow)
        data = self._extract_query_data(results, "get_by_checksum")

        if data and len(data) > 0:
            row = data[0]
            return {
                "model_name": row["model_name"],
                "definitions": (
                    json.loads(row["model_definitions"])
                    if isinstance(row["model_definitions"], str)
                    else row["model_definitions"]
                ),
                "application_id": row["application_id"],
                "registered_at": row["registered_at"],
                "version": row["version"],
                "status": row["status"],
            }

        return None

    def cleanup_old_versions(self, model_name: str, keep_versions: int = 5):
        """Clean up old versions of a model, keeping only the most recent ones."""
        workflow = WorkflowBuilder()

        # Get connection URL and detect database type
        from ..adapters.connection_parser import ConnectionParser

        connection_url = self.dataflow.config.database.get_connection_url(
            self.dataflow.config.environment
        )
        database_type = ConnectionParser.detect_database_type(connection_url)

        workflow.add_node(
            "SQLDatabaseNode",
            "cleanup",
            {
                "connection_string": connection_url,
                "database_type": database_type,
                "query": """
                UPDATE dataflow_model_registry
                SET status = 'archived'
                WHERE model_name = $1
                  AND version < (
                      SELECT MAX(version) - $2 + 1
                      FROM dataflow_model_registry
                      WHERE model_name = $1
                  )
                  AND status = 'active'
            """,
                "parameters": [model_name, keep_versions],
            },
        )

        results, _ = self._execute_workflow_sync_safe(workflow)

        if results.get("cleanup", {}).get("error"):
            logger.error(
                f"Failed to cleanup old versions for {model_name}: {results['cleanup']['error']}"
            )
            return False

        logger.info(
            f"Cleaned up old versions for model {model_name}, keeping {keep_versions} most recent"
        )
        return True

    @contextmanager
    def transaction(self):
        """Sync context manager for transactional registry operations.

        Phase 6.2: this method previously tried to enter
        :meth:`TransactionManager.begin` (an ``@asynccontextmanager``)
        from a sync ``with`` block, which would have raised
        ``TypeError: '_GeneratorContextManager' object is not a context
        manager`` if any caller invoked it. The fix uses the same
        sync engine + ``engine.begin()`` primitive as
        :meth:`_create_model_registry_table` so callers get a real
        BEGIN/COMMIT around grouped statements without crossing the
        sync/async boundary.

        Yields the SQLAlchemy connection inside the active transaction
        so callers can issue ``conn.execute(text(sql))``. When no
        sync engine is available (e.g. SQLDatabaseNode unavailable in a
        unit-test stub), yields ``None`` and the caller falls back to
        running mutations without a wrapping transaction.
        """
        with self._registry_lock:
            db_url = self.dataflow.config.database.get_connection_url(
                self.dataflow.config.environment
            )
            engine = self._acquire_sync_engine(db_url)
            if engine is None:
                logger.debug("model_registry.transaction.no_engine — yielding None")
                yield None
                return

            with engine.begin() as conn:
                try:
                    yield conn
                except Exception as exc:
                    logger.error(
                        "model_registry.transaction.rollback",
                        extra={"error": str(exc)},
                    )
                    raise

    def close(self):
        """Release the explicit runtime reference if one was provided.

        Safe to call multiple times — subsequent calls are no-ops.
        Post-S5 the registry no longer owns the runtime in the
        common case (it delegates to ``self._dataflow.runtime`` which is
        managed by the parent DataFlow). Only the legacy explicit
        ``runtime=`` constructor argument creates a reference this
        registry must release here.
        """
        explicit = getattr(self, "_explicit_runtime", None)
        if explicit is not None and hasattr(explicit, "release"):
            explicit.release()
        # Clear the override either way so subsequent reads fall back
        # to the parent (which itself returns None when closed).
        self._explicit_runtime = None

    def __del__(self, _warnings=warnings):
        """Emit ResourceWarning if close() was not called explicitly.

        Only fires when this registry held an explicit runtime override
        (legacy path). The lazy-parent path holds no resource of its
        own — the parent DataFlow's own ``__del__`` / ``close()`` is
        responsible for cleaning up the per-event-loop cache.
        """
        if getattr(self, "_explicit_runtime", None) is not None:
            _warnings.warn(
                f"Unclosed {self.__class__.__name__}. Call close() explicitly.",
                ResourceWarning,
                source=self,
            )
            try:
                self.close()
            except Exception:
                pass
