# ======================================== IMPORTS ========================================
from __future__ import annotations

from abc import ABC

# ======================================== ABSTRACT CLASS ========================================
class RenderObject(ABC):
    """Classe abstraite des formes de rendu"""
    __slots__ = tuple()

# ======================================== EXPORTS ========================================
__all__ = [
    "RenderObject",
]