from __future__ import annotations

from typing import TYPE_CHECKING

from app.users.models import User

from plain.signing import BadSignature, SignatureExpired
from plain.urls import reverse

from .signing import ExpiringSigner

if TYPE_CHECKING:
    from plain.http import Request


class LoginLinkExpired(Exception):
    pass


class LoginLinkInvalid(Exception):
    pass


class LoginLinkChanged(Exception):
    pass


def generate_link_url(
    *, request: Request, user: User, email: str, expires_in: int
) -> str:
    """
    Generate a login link using both the user's ID
    and email address, so links break if the user email changes or is assigned to another user.
    """
    token = ExpiringSigner(salt="plain.loginlink").sign_object(
        {"user_id": user.id, "email": email}, expires_in=expires_in
    )

    return request.build_absolute_uri(reverse("loginlink:login", token=token))


def get_link_token_user(token: str) -> User:
    """
    Validate a link token and get the user from it.
    """
    try:
        signed_data = ExpiringSigner(salt="plain.loginlink").unsign_object(token)
    except SignatureExpired:
        raise LoginLinkExpired()
    except BadSignature:
        raise LoginLinkInvalid()

    user_id = signed_data["user_id"]
    email = signed_data["email"]

    try:
        return User.query.get(id=user_id, email__iexact=email)
    except User.DoesNotExist:
        raise LoginLinkChanged()
