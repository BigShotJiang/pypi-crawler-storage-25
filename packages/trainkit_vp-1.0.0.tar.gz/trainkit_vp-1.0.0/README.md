# trainkit

Training utilities: LR scheduling, VRAM profiling, and automatic batch planning.

## Installation

```bash
pip install trainkit
```

Requires Python >= 3.14 and PyTorch >= 2.0.

## Features

- **Cosine LR scheduler** with linear warmup
- **Memory profiling** — detect system RAM and GPU VRAM (CUDA, ROCm, XPU, MPS)
- **Automatic training plan** — selects batch size, gradient checkpointing, and AMP based on available VRAM
- **VRAM estimation** heuristics for Transformer models

## Quick Start

```python
from trainkit import detect_memory, plan_training, create_cosine_schedule, estimate_model_memory

# Profile system memory
profile = detect_memory()
profile.print_info()

# Auto-plan training
model_bytes = estimate_model_memory(model)
plan = plan_training(profile, model_bytes, batch_size=64, max_len=96, d_model=512, total_layers=14)
print(plan.reason)

# Create LR schedule
scheduler = create_cosine_schedule(optimizer, warmup_steps=4000, total_steps=100000)
```

## License

See LICENSE file in the repository root.
