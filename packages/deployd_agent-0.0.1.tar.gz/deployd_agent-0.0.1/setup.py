from setuptools import setup; setup(name='deployd-agent', version='0.0.1', description='test')
