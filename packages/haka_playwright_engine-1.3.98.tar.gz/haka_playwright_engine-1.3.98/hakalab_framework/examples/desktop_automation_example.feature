# language: es
# ==============================================================================
# Ejemplo Completo de Automatización de Escritorio
# Cubre: lanzar apps, clicks por imagen y coordenadas, teclado, scroll,
#        esperas, verificaciones, OCR, portapapeles, screenshots para reporte
#        y pruebas mixtas (web + escritorio).
#
# Requisitos:
#   pip install pyautogui pillow pyperclip pytesseract
#   Carpeta desktop_images/ con las imagenes de referencia
#   Variables de entorno en .env (ver seccion Background)
# ==============================================================================

# ==============================================================================
# FEATURE 1 — PRUEBA PURA DE ESCRITORIO (sin navegador web)
# ==============================================================================

@desktop
Característica: Automatización de Aplicaciones de Escritorio

  # ============================================================================
  # ESCENARIO 1: Abrir aplicacion y verificar que cargo correctamente
  # ============================================================================

  @desktop @no_browser
  Escenario: Abrir la Calculadora de Windows y verificar que esta lista
    # Lanzar la aplicacion
    Dado que abro la aplicacion "calc.exe" y espero "2" segundos
    Y tomo una captura de pantalla del escritorio con nombre "calculadora_abierta"

    # Verificar que la pantalla principal cargo
    Entonces deberia ver la imagen "calculadora_pantalla" en pantalla
    Y deberia ver la imagen "boton_0" en pantalla
    Y deberia ver la imagen "boton_igual" en pantalla

    # Limpiar
    Y cierro la aplicacion "CalculatorApp.exe"


  # ============================================================================
  # ESCENARIO 2: Operacion matematica completa con clicks por imagen
  # ============================================================================

  @desktop @no_browser
  Escenario: Realizar una suma en la Calculadora usando imagenes de referencia
    Dado que abro la aplicacion "calc.exe" y espero "2" segundos

    # Tomar screenshot del estado inicial
    Y tomo una captura de pantalla del escritorio antes de la accion "suma"

    # Ingresar la operacion: 125 + 75 =
    Cuando hago click en la imagen "boton_1"
    Y hago click en la imagen "boton_2"
    Y hago click en la imagen "boton_5"
    Y hago click en la imagen "boton_mas"
    Y hago click en la imagen "boton_7"
    Y hago click en la imagen "boton_5"
    Y hago click en la imagen "boton_igual"

    # Tomar screenshot del resultado
    Y tomo una captura de pantalla del escritorio despues de la accion "suma"

    # Verificar resultado via OCR
    Entonces deberia ver el texto "200" en la pantalla del escritorio usando OCR
    Y tomo una captura de pantalla del escritorio con nombre "resultado_suma_200"

    Y cierro la aplicacion "CalculatorApp.exe"


  # ============================================================================
  # ESCENARIO 3: Operacion con coordenadas absolutas
  # ============================================================================

  @desktop @no_browser
  Escenario: Realizar una multiplicacion usando coordenadas de pantalla
    # Util cuando no se tienen imagenes de referencia o la app es muy simple
    Dado que abro la aplicacion "calc.exe" y espero "2" segundos

    # Establecer configuracion de pausa entre acciones
    Y establezco la pausa entre acciones de escritorio en "0.2" segundos

    # Ingresar 12 * 8 usando coordenadas (ajustar segun resolucion)
    Cuando hago click en las coordenadas "320" "450"
    Y hago click en las coordenadas "320" "450"
    Y hago click en las coordenadas "270" "400"
    Y hago click en las coordenadas "370" "450"
    Y hago click en las coordenadas "320" "500"
    Y hago click en las coordenadas "420" "550"

    # Verificar resultado
    Entonces tomo captura de escritorio y extraigo texto con OCR en la variable "resultado_calc"
    Y deberia ver el texto "96" en la pantalla del escritorio usando OCR

    Y cierro la aplicacion "CalculatorApp.exe"


  # ============================================================================
  # ESCENARIO 4: Formulario completo en Notepad (texto, atajos, portapapeles)
  # ============================================================================

  @desktop @no_browser
  Escenario: Llenar y guardar un documento en el Bloc de Notas
    Dado que abro la aplicacion "notepad.exe" y espero "1" segundos
    Y tomo una captura de pantalla del escritorio con nombre "notepad_abierto"

    # Escribir contenido usando portapapeles (soporta tildes y caracteres especiales)
    Cuando escribo el texto "Informe de Pruebas Automatizadas" usando el portapapeles
    Y presiono la tecla "enter"
    Y presiono la tecla "enter"
    Y escribo el texto "Fecha: 2024-01-15" usando el portapapeles
    Y presiono la tecla "enter"
    Y escribo el texto "Estado: Completado" usando el portapapeles
    Y presiono la tecla "enter"
    Y escribo el texto "Resultado: EXITOSO" usando el portapapeles
    Y presiono la tecla "enter"
    Y presiono la tecla "enter"
    Y escribo el texto "Observaciones: Todos los pasos ejecutados correctamente." usando el portapapeles

    # Tomar screenshot del contenido escrito
    Y tomo una captura de pantalla del escritorio con nombre "notepad_contenido"

    # Verificar contenido via OCR
    Entonces deberia ver el texto "Informe de Pruebas" en la pantalla del escritorio usando OCR
    Y deberia ver el texto "EXITOSO" en la pantalla del escritorio usando OCR

    # Guardar con Ctrl+S
    Cuando presiono el atajo de teclado guardar
    Y espero "1" segundos en escritorio

    # Si aparece dialogo de guardar, escribir nombre y confirmar
    Y espero a que aparezca la imagen "dialogo_guardar" con timeout de "3" segundos
    Y hago click en la imagen "campo_nombre_archivo" y escribo "reporte_prueba"
    Y presiono la tecla "enter"

    Y tomo una captura de pantalla del escritorio con nombre "notepad_guardado"
    Y cierro la aplicacion "notepad.exe"


  # ============================================================================
  # ESCENARIO 5: Navegacion con teclado y combinaciones de teclas
  # ============================================================================

  @desktop @no_browser
  Escenario: Navegar por una aplicacion usando solo el teclado
    Dado que abro la aplicacion "notepad.exe" y espero "1" segundos

    # Escribir texto de prueba
    Cuando escribo el texto "Primera linea de texto para prueba de teclado" usando el portapapeles
    Y presiono la tecla "enter"
    Y escribo el texto "Segunda linea con mas contenido de ejemplo" usando el portapapeles
    Y presiono la tecla "enter"
    Y escribo el texto "Tercera linea final del documento de prueba" usando el portapapeles

    # Seleccionar todo y copiar
    Y presiono el atajo de teclado seleccionar todo
    Y presiono el atajo de teclado copiar

    # Verificar que el portapapeles tiene contenido
    Entonces deberia ver que el portapapeles contiene "Primera linea"
    Y deberia ver que el portapapeles contiene "Segunda linea"

    # Guardar contenido del portapapeles en variable
    Cuando obtengo el contenido del portapapeles y lo guardo en la variable "contenido_documento"

    # Deshacer cambios
    Y presiono el atajo de teclado deshacer
    Y presiono el atajo de teclado deshacer

    Y tomo una captura de pantalla del escritorio con nombre "navegacion_teclado"
    Y cierro la aplicacion "notepad.exe"


  # ============================================================================
  # ESCENARIO 6: Scroll y navegacion en una ventana
  # ============================================================================

  @desktop @no_browser
  Escenario: Hacer scroll en una aplicacion de escritorio
    Dado que abro la aplicacion "notepad.exe" y espero "1" segundos

    # Generar contenido largo para poder hacer scroll
    Cuando escribo el texto "Linea 1 - Contenido de prueba para scroll" usando el portapapeles
    Y presiono la tecla "enter"
    Y escribo el texto "Linea 2 - Mas contenido para generar scroll" usando el portapapeles
    Y presiono la tecla "enter"
    Y escribo el texto "Linea 3 - Continuando con el contenido" usando el portapapeles
    Y presiono la tecla "enter"
    Y escribo el texto "Linea 4 - Penultima linea del documento" usando el portapapeles
    Y presiono la tecla "enter"
    Y escribo el texto "Linea 5 - Ultima linea visible del documento" usando el portapapeles

    # Scroll hacia arriba para volver al inicio
    Y hago scroll hacia arriba "5" veces
    Y tomo una captura de pantalla del escritorio con nombre "scroll_arriba"

    # Scroll hacia abajo
    Y hago scroll hacia abajo "5" veces
    Y tomo una captura de pantalla del escritorio con nombre "scroll_abajo"

    # Scroll sobre un elemento especifico encontrado por imagen
    Y hago scroll hacia arriba "3" veces sobre la imagen "area_texto_notepad"

    Y cierro la aplicacion "notepad.exe"


  # ============================================================================
  # ESCENARIO 7: Drag and Drop entre elementos
  # ============================================================================

  @desktop @no_browser
  Escenario: Arrastrar y soltar elementos en una aplicacion
    Dado que abro la aplicacion "${ENV.APP_CON_DRAG_DROP}" y espero "3" segundos
    Y tomo una captura de pantalla del escritorio antes de la accion "drag_drop"

    # Drag and drop usando imagenes de referencia
    Cuando arrastro la imagen "elemento_origen" hacia la imagen "zona_destino"
    Y espero "1" segundos en escritorio
    Y tomo una captura de pantalla del escritorio despues de la accion "drag_drop"

    # Verificar que el elemento llego al destino
    Entonces deberia ver la imagen "elemento_en_destino" en pantalla
    Y no deberia ver la imagen "elemento_origen" en pantalla

    # Drag and drop usando coordenadas
    Cuando arrastro desde las coordenadas "200" "300" hasta las coordenadas "600" "300"
    Y tomo una captura de pantalla del escritorio con nombre "drag_coordenadas"

    Y cierro la aplicacion "${ENV.APP_CON_DRAG_DROP}"


  # ============================================================================
  # ESCENARIO 8: Esperas inteligentes por imagen
  # ============================================================================

  @desktop @no_browser
  Escenario: Esperar que cargue una aplicacion pesada y verificar elementos
    # Lanzar aplicacion que tarda en cargar
    Dado que abro la aplicacion "${ENV.APP_PESADA}" y espero "1" segundos

    # Esperar a que aparezca la pantalla de carga
    Y espero a que aparezca la imagen "splash_screen" con timeout de "5" segundos

    # Esperar a que desaparezca el splash screen (carga completada)
    Y espero a que desaparezca la imagen "splash_screen" con timeout de "30" segundos

    # Esperar a que aparezca la pantalla principal
    Y espero a que aparezca la imagen "pantalla_principal_app" con timeout de "10" segundos
    Y tomo una captura de pantalla del escritorio con nombre "app_cargada"

    # Verificar elementos de la pantalla principal
    Entonces deberia ver la imagen "menu_archivo" en pantalla
    Y deberia ver la imagen "menu_editar" en pantalla
    Y deberia ver la imagen "barra_herramientas" en pantalla

    Y cierro la aplicacion "${ENV.APP_PESADA}"


  # ============================================================================
  # ESCENARIO 9: OCR avanzado - leer campos especificos por region
  # ============================================================================

  @desktop @no_browser
  Escenario: Leer datos de campos especificos usando OCR por region
    Dado que abro la aplicacion "${ENV.APP_LEGACY}" y espero "3" segundos
    Y tomo una captura de pantalla del escritorio con nombre "app_legacy_inicial"

    # Navegar al formulario de consulta
    Cuando hago click en la imagen "menu_consultas"
    Y espero a que aparezca la imagen "formulario_consulta"
    Y hago click en la imagen "campo_codigo" y escribo "CLI-001"
    Y presiono la tecla "enter"
    Y espero "2" segundos en escritorio

    # Leer campos especificos por region de pantalla
    # Region: x=100, y=200, width=300, height=30 (ajustar segun app)
    Y tomo captura de la region "100" "200" "300" "30" del escritorio y extraigo texto en la variable "nombre_cliente"
    Y tomo captura de la region "100" "240" "300" "30" del escritorio y extraigo texto en la variable "rut_cliente"
    Y tomo captura de la region "100" "280" "400" "30" del escritorio y extraigo texto en la variable "direccion_cliente"

    # Verificar datos leidos
    Entonces deberia ver el texto "CLI-001" en la pantalla del escritorio usando OCR
    Y no deberia ver el texto "ERROR" en la pantalla del escritorio usando OCR

    Y tomo una captura de pantalla del escritorio con nombre "datos_cliente_leidos"
    Y cierro la aplicacion "${ENV.APP_LEGACY}"


  # ============================================================================
  # ESCENARIO 10: Verificaciones con confianza personalizada
  # ============================================================================

  @desktop @no_browser
  Escenario: Verificar elementos con diferentes niveles de confianza
    Dado que abro la aplicacion "calc.exe" y espero "2" segundos

    # Verificacion con confianza alta (imagen muy similar a la referencia)
    Entonces deberia ver la imagen "boton_igual" en pantalla con confianza "0.95"

    # Verificacion con confianza media (imagen puede tener variaciones de color/escala)
    Y deberia ver la imagen "display_calculadora" en pantalla con confianza "0.75"

    # Contar cuantos botones numericos hay visibles
    Cuando cuento las ocurrencias de la imagen "boton_numerico" y las guardo en la variable "total_botones"

    # Guardar posicion de un elemento para uso posterior
    Y guardo la ubicacion de la imagen "boton_igual" en la variable "pos_boton_igual"

    Y tomo una captura de pantalla del escritorio con nombre "verificaciones_confianza"
    Y cierro la aplicacion "CalculatorApp.exe"


  # ============================================================================
  # ESCENARIO 11: Configuracion dinamica del motor de busqueda
  # ============================================================================

  @desktop @no_browser
  Escenario: Ajustar configuracion de busqueda segun condiciones del entorno
    # Reducir confianza para entornos con diferente escala de pantalla
    Dado que establezco la confianza de busqueda de imagenes en "0.80"
    Y establezco el timeout de busqueda de imagenes en "15" segundos
    Y establezco la pausa entre acciones de escritorio en "0.5" segundos

    # Guardar informacion del entorno
    Y guardo el tamano de pantalla en la variable "resolucion_pantalla"
    Y guardo la posicion del mouse en la variable "posicion_inicial_mouse"

    Cuando abro la aplicacion "calc.exe" y espero "2" segundos

    # Verificar con la confianza ajustada
    Entonces deberia ver la imagen "calculadora_pantalla" en pantalla
    Y tomo una captura de pantalla del escritorio con nombre "entorno_configurado"

    Y cierro la aplicacion "CalculatorApp.exe"


# ==============================================================================
# FEATURE 2 — PRUEBA MIXTA (navegador web + aplicacion de escritorio)
# ==============================================================================

Característica: Prueba Mixta Web y Escritorio

  # ============================================================================
  # ESCENARIO 12: Descargar desde web y procesar en app de escritorio
  # ============================================================================

  Escenario: Descargar reporte desde web y abrirlo en Excel
    # --- PARTE WEB ---
    Dado que navego a "${ENV.BASE_URL}/reportes"
    Y espero que el elemento con css ".reports-table" sea visible
    Y tomo una captura de pantalla con nombre "web_lista_reportes"

    Cuando hago click en el elemento "descargar_reporte" con identificador "#btn-download-excel"
    Y espero "3" segundos

    # Verificar que la descarga inicio
    Entonces verifico que el elemento con css ".download-success" es visible
    Y tomo una captura de pantalla con nombre "web_descarga_iniciada"

    # --- CAMBIO A ESCRITORIO ---
    Cuando cambio a la aplicacion de escritorio "C:\Program Files\Microsoft Office\root\Office16\EXCEL.EXE" desde la prueba web
    Y espero a que aparezca la imagen "excel_listo" con timeout de "15" segundos
    Y tomo una captura de pantalla del escritorio con nombre "excel_abierto"

    # Verificar que el archivo se abrio con datos
    Entonces deberia ver el texto "Reporte" en la pantalla del escritorio usando OCR
    Y deberia ver la imagen "celda_encabezado" en pantalla

    # Leer el total del reporte via OCR
    Y tomo captura de la region "500" "300" "200" "30" del escritorio y extraigo texto en la variable "total_reporte"

    # Cerrar Excel
    Y presiono la combinacion de teclas "alt" y "f4"
    Y espero "1" segundos en escritorio

    # --- VOLVER A WEB ---
    Y vuelvo al navegador web despues de la interaccion con escritorio
    Entonces verifico que el elemento con css "h1" es visible
    Y tomo una captura de pantalla con nombre "web_restaurada"


  # ============================================================================
  # ESCENARIO 13: Login en web, copiar token y usarlo en app de escritorio
  # ============================================================================

  Escenario: Autenticar en web y transferir credenciales a app de escritorio
    # --- LOGIN WEB ---
    Dado que navego a "${ENV.BASE_URL}/login"
    Cuando ingreso "${ENV.TEST_USER}" en el campo con id "username"
    Y ingreso "${ENV.TEST_PASSWORD}" en el campo con id "password"
    Y hago click en el botón con css "button[type='submit']"
    Entonces espero que el elemento con css ".dashboard" sea visible

    # Obtener token de la sesion
    Cuando extraigo el texto del elemento con css "[data-testid='api-token']" y lo guardo en "api_token"
    Y tomo una captura de pantalla con nombre "web_token_obtenido"

    # --- CAMBIO A ESCRITORIO ---
    Y cambio a modo escritorio
    Y abro la aplicacion "${ENV.APP_CLIENTE_API}" y espero "3" segundos
    Y espero a que aparezca la imagen "campo_token_app"

    # Pegar el token en la app de escritorio
    Cuando copio el texto "${api_token}" al portapapeles
    Y hago click en la imagen "campo_token_app"
    Y presiono el atajo de teclado pegar
    Y hago click en la imagen "boton_conectar_app"

    # Verificar conexion exitosa
    Y espero a que aparezca la imagen "estado_conectado" con timeout de "10" segundos
    Entonces deberia ver la imagen "estado_conectado" en pantalla
    Y tomo una captura de pantalla del escritorio con nombre "app_conectada_con_token"

    # --- VOLVER A WEB ---
    Y cambio a modo web
    Entonces verifico que el elemento con css ".dashboard" es visible


  # ============================================================================
  # ESCENARIO 14: Verificar datos entre web y app de escritorio (end-to-end)
  # ============================================================================

  Escenario: Crear registro en web y verificar en sistema de escritorio legacy
    # --- CREAR EN WEB ---
    Dado que navego a "${ENV.BASE_URL}/clientes/nuevo"
    Y genero un texto aleatorio de 6 caracteres y lo guardo en la variable "codigo_cliente"

    Cuando ingreso "${codigo_cliente}" en el campo con id "codigo"
    Y ingreso "Cliente de Prueba Automatizada" en el campo con id "nombre"
    Y ingreso "contacto@prueba.com" en el campo con id "email"
    Y hago click en el botón con css "#btn-guardar"
    Entonces espero que el elemento con css ".alert-success" sea visible
    Y verifico que el texto del elemento con css ".alert-success" contiene "Cliente creado"
    Y tomo una captura de pantalla con nombre "web_cliente_creado"

    # --- VERIFICAR EN SISTEMA LEGACY ---
    Cuando cambio a la aplicacion de escritorio "${ENV.APP_LEGACY}" desde la prueba web
    Y espero a que aparezca la imagen "pantalla_principal_legacy" con timeout de "10" segundos

    # Buscar el cliente recien creado
    Y hago click en la imagen "menu_clientes_legacy"
    Y espero a que aparezca la imagen "formulario_busqueda_legacy"
    Y hago click en la imagen "campo_busqueda_legacy" y escribo "${codigo_cliente}"
    Y presiono la tecla "enter"
    Y espero "2" segundos en escritorio

    # Verificar que el cliente aparece en el sistema legacy
    Entonces deberia ver el texto "${codigo_cliente}" en la pantalla del escritorio usando OCR
    Y deberia ver el texto "Cliente de Prueba" en la pantalla del escritorio usando OCR
    Y tomo una captura de pantalla del escritorio con nombre "legacy_cliente_verificado"

    # Volver a web
    Y vuelvo al navegador web despues de la interaccion con escritorio
    Y tomo captura de escritorio y continuo la prueba web con nombre "transicion_web_legacy"


  # ============================================================================
  # ESCENARIO 15: Flujo completo con screenshots en cada paso critico
  # ============================================================================

  Escenario: Flujo de aprobacion con evidencia fotografica completa
    # --- INICIO EN WEB ---
    Dado que navego a "${ENV.BASE_URL}/solicitudes"
    Y tomo una captura de pantalla con nombre "01_lista_solicitudes"

    Cuando hago click en el elemento "nueva_solicitud" con identificador "#btn-nueva"
    Y espero que el elemento con css "#form-solicitud" sea visible
    Y tomo una captura de pantalla con nombre "02_formulario_solicitud"

    Y ingreso "Solicitud de Prueba Automatizada" en el campo con id "titulo"
    Y ingreso "Descripcion generada por prueba automatizada" en el campo con id "descripcion"
    Y hago click en el botón con css "#btn-enviar"
    Entonces espero que el elemento con css ".solicitud-enviada" sea visible
    Y tomo una captura de pantalla con nombre "03_solicitud_enviada"

    # Obtener numero de solicitud
    Cuando extraigo el texto del elemento con css ".numero-solicitud" y lo guardo en "numero_sol"

    # --- APROBAR EN APP DE ESCRITORIO (sistema de aprobacion interno) ---
    Y cambio a la aplicacion de escritorio "${ENV.APP_APROBACIONES}" desde la prueba web
    Y espero a que aparezca la imagen "pantalla_aprobaciones" con timeout de "10" segundos
    Y tomo una captura de pantalla del escritorio con nombre "04_app_aprobaciones"

    Cuando hago click en la imagen "campo_buscar_solicitud" y escribo "${numero_sol}"
    Y presiono la tecla "enter"
    Y espero a que aparezca la imagen "resultado_solicitud"
    Y tomo una captura de pantalla del escritorio con nombre "05_solicitud_encontrada"

    Y hago click en la imagen "boton_aprobar"
    Y espero a que aparezca la imagen "dialogo_confirmacion_aprobacion"
    Y tomo una captura de pantalla del escritorio con nombre "06_dialogo_confirmacion"

    Y hago click en la imagen "boton_confirmar_aprobacion"
    Y espero a que aparezca la imagen "aprobacion_exitosa" con timeout de "5" segundos
    Entonces deberia ver la imagen "aprobacion_exitosa" en pantalla
    Y deberia ver el texto "Aprobado" en la pantalla del escritorio usando OCR
    Y tomo una captura de pantalla del escritorio con nombre "07_aprobacion_confirmada"

    # --- VERIFICAR ESTADO EN WEB ---
    Y vuelvo al navegador web despues de la interaccion con escritorio
    Cuando navego a "${ENV.BASE_URL}/solicitudes/${numero_sol}"
    Y espero que el elemento con css ".estado-solicitud" sea visible
    Entonces verifico que el texto del elemento con css ".estado-solicitud" contiene "Aprobada"
    Y tomo una captura de pantalla con nombre "08_estado_aprobado_en_web"
