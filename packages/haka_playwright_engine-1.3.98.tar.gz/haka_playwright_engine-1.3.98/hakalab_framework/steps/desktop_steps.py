#!/usr/bin/env python3
"""
Steps para automatizacion de aplicaciones de escritorio con PyAutoGUI.
Soporta busqueda por coordenadas y por imagen de referencia.
Compatible con pruebas puras de escritorio y pruebas mixtas (web + escritorio).

Tag recomendado para escenarios de escritorio: @desktop
Tag para deshabilitar el navegador:            @no_browser
"""

import os
import time
from behave import step


# ---------------------------------------------------------------------------
# Helpers internos
# ---------------------------------------------------------------------------

def _dm(context):
    """Obtiene o crea el DesktopManager en el contexto."""
    if not hasattr(context, 'desktop_manager') or context.desktop_manager is None:
        from hakalab_framework.core.desktop_manager import DesktopManager
        context.desktop_manager = DesktopManager()
    return context.desktop_manager


def _r(context, value):
    """Resuelve variables del framework en un valor de texto."""
    if hasattr(context, 'variable_manager'):
        return context.variable_manager.resolve_variables(str(value))
    return str(value)


def _log(context, msg):
    """Escribe en el logger del framework si existe."""
    if hasattr(context, 'logger'):
        context.logger.info(msg)
    else:
        print(msg)


# ===========================================================================
# SECCION 1 - GESTION DE APLICACIONES
# ===========================================================================

@step('I launch application "{app_path}"')
@step('abro la aplicacion "{app_path}"')
@step('que abro la aplicacion "{app_path}"')
def step_launch_application(context, app_path):
    """Lanza una aplicacion de escritorio."""
    dm = _dm(context)
    resolved_path = _r(context, app_path)
    dm.launch_application(resolved_path, wait_seconds=2.0)
    _log(context, f"Aplicacion lanzada: {resolved_path}")


@step('I launch application "{app_path}" and wait "{seconds}" seconds')
@step('abro la aplicacion "{app_path}" y espero "{seconds}" segundos')
@step('que abro la aplicacion "{app_path}" y espero "{seconds}" segundos')
def step_launch_application_wait(context, app_path, seconds):
    """Lanza una aplicacion y espera el tiempo indicado."""
    dm = _dm(context)
    resolved_path = _r(context, app_path)
    dm.launch_application(resolved_path, wait_seconds=float(seconds))
    _log(context, f"Aplicacion lanzada: {resolved_path} (espera: {seconds}s)")


@step('I launch application "{app_path}" with arguments "{args}"')
@step('abro la aplicacion "{app_path}" con argumentos "{args}"')
@step('que abro la aplicacion "{app_path}" con argumentos "{args}"')
def step_launch_application_with_args(context, app_path, args):
    """Lanza una aplicacion con argumentos de linea de comandos."""
    dm = _dm(context)
    resolved_path = _r(context, app_path)
    resolved_args = _r(context, args).split()
    dm.launch_application(resolved_path, args=resolved_args, wait_seconds=2.0)
    _log(context, f"Aplicacion lanzada: {resolved_path} {args}")


@step('I close application "{process_name}"')
@step('cierro la aplicacion "{process_name}"')
@step('que cierro la aplicacion "{process_name}"')
def step_close_application(context, process_name):
    """Cierra una aplicacion por nombre de proceso."""
    dm = _dm(context)
    dm.close_application_by_name(_r(context, process_name))
    _log(context, f"Aplicacion cerrada: {process_name}")


@step('I bring window "{window_title}" to front')
@step('traigo la ventana "{window_title}" al frente')
@step('que traigo la ventana "{window_title}" al frente')
def step_bring_window_to_front(context, window_title):
    """Trae una ventana al frente por su titulo."""
    dm = _dm(context)
    result = dm.bring_window_to_front(_r(context, window_title))
    if not result:
        _log(context, f"Advertencia: no se pudo traer la ventana '{window_title}' al frente")
    else:
        _log(context, f"Ventana '{window_title}' traida al frente")


# ===========================================================================
# SECCION 2 - CLICKS POR COORDENADAS
# ===========================================================================

@step('I click at coordinates "{x}" "{y}"')
@step('hago click en las coordenadas "{x}" "{y}"')
@step('que hago click en las coordenadas "{x}" "{y}"')
def step_click_at_coordinates(context, x, y):
    """Click izquierdo en coordenadas absolutas de pantalla."""
    dm = _dm(context)
    dm.click_at_coordinates(int(_r(context, x)), int(_r(context, y)))
    _log(context, f"Click en ({x}, {y})")


@step('I double click at coordinates "{x}" "{y}"')
@step('hago doble click en las coordenadas "{x}" "{y}"')
@step('que hago doble click en las coordenadas "{x}" "{y}"')
def step_double_click_at_coordinates(context, x, y):
    """Doble click en coordenadas absolutas."""
    dm = _dm(context)
    dm.double_click_at_coordinates(int(_r(context, x)), int(_r(context, y)))
    _log(context, f"Doble click en ({x}, {y})")


@step('I right click at coordinates "{x}" "{y}"')
@step('hago click derecho en las coordenadas "{x}" "{y}"')
@step('que hago click derecho en las coordenadas "{x}" "{y}"')
def step_right_click_at_coordinates(context, x, y):
    """Click derecho en coordenadas absolutas."""
    dm = _dm(context)
    dm.right_click_at_coordinates(int(_r(context, x)), int(_r(context, y)))
    _log(context, f"Click derecho en ({x}, {y})")


@step('I move mouse to coordinates "{x}" "{y}"')
@step('muevo el mouse a las coordenadas "{x}" "{y}"')
@step('que muevo el mouse a las coordenadas "{x}" "{y}"')
def step_move_mouse_to_coordinates(context, x, y):
    """Mueve el mouse a coordenadas absolutas sin hacer click."""
    dm = _dm(context)
    dm.move_to_coordinates(int(_r(context, x)), int(_r(context, y)))
    _log(context, f"Mouse movido a ({x}, {y})")


@step('I drag from coordinates "{x1}" "{y1}" to coordinates "{x2}" "{y2}"')
@step('arrastro desde las coordenadas "{x1}" "{y1}" hasta las coordenadas "{x2}" "{y2}"')
@step('que arrastro desde las coordenadas "{x1}" "{y1}" hasta las coordenadas "{x2}" "{y2}"')
def step_drag_coordinates_to_coordinates(context, x1, y1, x2, y2):
    """Arrastra el mouse desde unas coordenadas a otras."""
    dm = _dm(context)
    dm.drag_from_coordinates_to_coordinates(
        int(_r(context, x1)), int(_r(context, y1)),
        int(_r(context, x2)), int(_r(context, y2))
    )
    _log(context, f"Drag de ({x1},{y1}) a ({x2},{y2})")


@step('I click at coordinates "{x}" "{y}" with right button')
@step('hago click en las coordenadas "{x}" "{y}" con boton derecho')
@step('que hago click en las coordenadas "{x}" "{y}" con boton derecho')
def step_click_coordinates_right(context, x, y):
    """Click derecho en coordenadas (alias explicito)."""
    dm = _dm(context)
    dm.right_click_at_coordinates(int(_r(context, x)), int(_r(context, y)))
    _log(context, f"Click derecho en ({x}, {y})")


# ===========================================================================
# SECCION 3 - CLICKS POR IMAGEN DE REFERENCIA
# ===========================================================================

@step('I click on image "{image_name}"')
@step('hago click en la imagen "{image_name}"')
@step('que hago click en la imagen "{image_name}"')
def step_click_on_image(context, image_name):
    """Click izquierdo en un elemento encontrado por imagen de referencia."""
    dm = _dm(context)
    dm.click_on_image(_r(context, image_name))
    _log(context, f"Click en imagen '{image_name}'")


@step('I double click on image "{image_name}"')
@step('hago doble click en la imagen "{image_name}"')
@step('que hago doble click en la imagen "{image_name}"')
def step_double_click_on_image(context, image_name):
    """Doble click en un elemento encontrado por imagen de referencia."""
    dm = _dm(context)
    dm.double_click_on_image(_r(context, image_name))
    _log(context, f"Doble click en imagen '{image_name}'")


@step('I right click on image "{image_name}"')
@step('hago click derecho en la imagen "{image_name}"')
@step('que hago click derecho en la imagen "{image_name}"')
def step_right_click_on_image(context, image_name):
    """Click derecho en un elemento encontrado por imagen de referencia."""
    dm = _dm(context)
    dm.right_click_on_image(_r(context, image_name))
    _log(context, f"Click derecho en imagen '{image_name}'")


@step('I hover over image "{image_name}"')
@step('paso el mouse sobre la imagen "{image_name}"')
@step('que paso el mouse sobre la imagen "{image_name}"')
def step_hover_on_image(context, image_name):
    """Mueve el mouse sobre un elemento encontrado por imagen (hover)."""
    dm = _dm(context)
    dm.hover_on_image(_r(context, image_name))
    _log(context, f"Hover sobre imagen '{image_name}'")


@step('I click on image "{image_name}" with confidence "{confidence}"')
@step('hago click en la imagen "{image_name}" con confianza "{confidence}"')
@step('que hago click en la imagen "{image_name}" con confianza "{confidence}"')
def step_click_on_image_with_confidence(context, image_name, confidence):
    """Click en imagen con nivel de confianza personalizado (0.0 a 1.0)."""
    dm = _dm(context)
    dm.click_on_image(_r(context, image_name), confidence=float(confidence))
    _log(context, f"Click en imagen '{image_name}' (confianza: {confidence})")


@step('I click on image "{image_name}" with offset "{offset_x}" "{offset_y}"')
@step('hago click en la imagen "{image_name}" con desplazamiento "{offset_x}" "{offset_y}"')
@step('que hago click en la imagen "{image_name}" con desplazamiento "{offset_x}" "{offset_y}"')
def step_click_on_image_with_offset(context, image_name, offset_x, offset_y):
    """Click en imagen con desplazamiento en pixeles desde el centro."""
    dm = _dm(context)
    dm.click_on_image(
        _r(context, image_name),
        offset_x=int(_r(context, offset_x)),
        offset_y=int(_r(context, offset_y))
    )
    _log(context, f"Click en imagen '{image_name}' con offset ({offset_x},{offset_y})")


@step('I drag image "{source_image}" to image "{target_image}"')
@step('arrastro la imagen "{source_image}" hacia la imagen "{target_image}"')
@step('que arrastro la imagen "{source_image}" hacia la imagen "{target_image}"')
def step_drag_image_to_image(context, source_image, target_image):
    """Arrastra desde un elemento imagen a otro elemento imagen."""
    dm = _dm(context)
    dm.drag_image_to_image(_r(context, source_image), _r(context, target_image))
    _log(context, f"Drag de imagen '{source_image}' a imagen '{target_image}'")


@step('I drag image "{source_image}" to coordinates "{x}" "{y}"')
@step('arrastro la imagen "{source_image}" hacia las coordenadas "{x}" "{y}"')
@step('que arrastro la imagen "{source_image}" hacia las coordenadas "{x}" "{y}"')
def step_drag_image_to_coordinates(context, source_image, x, y):
    """Arrastra desde un elemento imagen a coordenadas especificas."""
    dm = _dm(context)
    dm.drag_image_to_coordinates(
        _r(context, source_image),
        int(_r(context, x)),
        int(_r(context, y))
    )
    _log(context, f"Drag de imagen '{source_image}' a ({x},{y})")


# ===========================================================================
# SECCION 4 - ESCRITURA DE TEXTO Y TECLADO
# ===========================================================================

@step('I type text "{text}"')
@step('escribo el texto "{text}"')
@step('que escribo el texto "{text}"')
def step_type_text(context, text):
    """Escribe texto en el elemento activo (campo con foco)."""
    dm = _dm(context)
    dm.type_text(_r(context, text))
    _log(context, f"Texto escrito: '{text}'")


@step('I type text "{text}" using clipboard')
@step('escribo el texto "{text}" usando el portapapeles')
@step('que escribo el texto "{text}" usando el portapapeles')
def step_type_text_clipboard(context, text):
    """Escribe texto usando el portapapeles (soporta tildes, enie, caracteres especiales)."""
    dm = _dm(context)
    dm.type_text_with_clipboard(_r(context, text))
    _log(context, f"Texto pegado desde portapapeles: '{text}'")


@step('I clear field and type "{text}"')
@step('limpio el campo y escribo "{text}"')
@step('que limpio el campo y escribo "{text}"')
def step_clear_and_type(context, text):
    """Selecciona todo, borra y escribe texto nuevo en el campo activo."""
    dm = _dm(context)
    dm.clear_field_and_type(_r(context, text))
    _log(context, f"Campo limpiado y texto escrito: '{text}'")


@step('I press key "{key}"')
@step('presiono la tecla "{key}"')
@step('que presiono la tecla "{key}"')
def step_press_key(context, key):
    """Presiona una tecla especial (enter, tab, escape, f5, delete, etc.)."""
    dm = _dm(context)
    dm.press_key(_r(context, key))
    _log(context, f"Tecla presionada: {key}")


@step('I press hotkey "{key1}" and "{key2}"')
@step('presiono la combinacion de teclas "{key1}" y "{key2}"')
@step('que presiono la combinacion de teclas "{key1}" y "{key2}"')
def step_press_hotkey_two(context, key1, key2):
    """Presiona una combinacion de dos teclas (ej: ctrl+c, alt+f4)."""
    dm = _dm(context)
    dm.press_hotkey(_r(context, key1), _r(context, key2))
    _log(context, f"Combinacion de teclas: {key1}+{key2}")


@step('I press hotkey "{key1}" and "{key2}" and "{key3}"')
@step('presiono la combinacion de teclas "{key1}" y "{key2}" y "{key3}"')
@step('que presiono la combinacion de teclas "{key1}" y "{key2}" y "{key3}"')
def step_press_hotkey_three(context, key1, key2, key3):
    """Presiona una combinacion de tres teclas (ej: ctrl+shift+s)."""
    dm = _dm(context)
    dm.press_hotkey(_r(context, key1), _r(context, key2), _r(context, key3))
    _log(context, f"Combinacion de teclas: {key1}+{key2}+{key3}")


@step('I click on image "{image_name}" and type "{text}"')
@step('hago click en la imagen "{image_name}" y escribo "{text}"')
@step('que hago click en la imagen "{image_name}" y escribo "{text}"')
def step_click_image_and_type(context, image_name, text):
    """Click en un campo (por imagen) y escribe texto, limpiando el campo antes."""
    dm = _dm(context)
    dm.click_on_image_and_type(_r(context, image_name), _r(context, text), clear_first=True)
    _log(context, f"Click en '{image_name}' y texto escrito: '{text}'")


@step('I click on image "{image_name}" and append text "{text}"')
@step('hago click en la imagen "{image_name}" y agrego el texto "{text}"')
@step('que hago click en la imagen "{image_name}" y agrego el texto "{text}"')
def step_click_image_and_append(context, image_name, text):
    """Click en un campo (por imagen) y agrega texto sin borrar el contenido existente."""
    dm = _dm(context)
    dm.click_on_image_and_type(_r(context, image_name), _r(context, text), clear_first=False)
    _log(context, f"Click en '{image_name}' y texto agregado: '{text}'")


@step('I click at coordinates "{x}" "{y}" and type "{text}"')
@step('hago click en las coordenadas "{x}" "{y}" y escribo "{text}"')
@step('que hago click en las coordenadas "{x}" "{y}" y escribo "{text}"')
def step_click_coordinates_and_type(context, x, y, text):
    """Click en coordenadas y escribe texto, limpiando el campo antes."""
    dm = _dm(context)
    dm.click_at_coordinates_and_type(
        int(_r(context, x)), int(_r(context, y)),
        _r(context, text), clear_first=True
    )
    _log(context, f"Click en ({x},{y}) y texto escrito: '{text}'")


@step('I hold key "{key}" down')
@step('mantengo presionada la tecla "{key}"')
@step('que mantengo presionada la tecla "{key}"')
def step_key_down(context, key):
    """Mantiene presionada una tecla (usar con step de soltar tecla)."""
    dm = _dm(context)
    dm.key_down(_r(context, key))
    _log(context, f"Tecla mantenida: {key}")


@step('I release key "{key}"')
@step('suelto la tecla "{key}"')
@step('que suelto la tecla "{key}"')
def step_key_up(context, key):
    """Suelta una tecla que estaba presionada."""
    dm = _dm(context)
    dm.key_up(_r(context, key))
    _log(context, f"Tecla soltada: {key}")


# ===========================================================================
# SECCION 5 - SCROLL
# ===========================================================================

@step('I scroll up "{clicks}" times')
@step('hago scroll hacia arriba "{clicks}" veces')
@step('que hago scroll hacia arriba "{clicks}" veces')
def step_scroll_up(context, clicks):
    """Scroll hacia arriba en la posicion actual del mouse."""
    dm = _dm(context)
    dm.scroll_up(int(_r(context, clicks)))
    _log(context, f"Scroll arriba {clicks} veces")


@step('I scroll down "{clicks}" times')
@step('hago scroll hacia abajo "{clicks}" veces')
@step('que hago scroll hacia abajo "{clicks}" veces')
def step_scroll_down(context, clicks):
    """Scroll hacia abajo en la posicion actual del mouse."""
    dm = _dm(context)
    dm.scroll_down(int(_r(context, clicks)))
    _log(context, f"Scroll abajo {clicks} veces")


@step('I scroll up "{clicks}" times at coordinates "{x}" "{y}"')
@step('hago scroll hacia arriba "{clicks}" veces en las coordenadas "{x}" "{y}"')
@step('que hago scroll hacia arriba "{clicks}" veces en las coordenadas "{x}" "{y}"')
def step_scroll_up_at_coordinates(context, clicks, x, y):
    """Scroll hacia arriba en coordenadas especificas."""
    dm = _dm(context)
    dm.scroll_up(int(_r(context, clicks)), x=int(_r(context, x)), y=int(_r(context, y)))
    _log(context, f"Scroll arriba {clicks} veces en ({x},{y})")


@step('I scroll down "{clicks}" times at coordinates "{x}" "{y}"')
@step('hago scroll hacia abajo "{clicks}" veces en las coordenadas "{x}" "{y}"')
@step('que hago scroll hacia abajo "{clicks}" veces en las coordenadas "{x}" "{y}"')
def step_scroll_down_at_coordinates(context, clicks, x, y):
    """Scroll hacia abajo en coordenadas especificas."""
    dm = _dm(context)
    dm.scroll_down(int(_r(context, clicks)), x=int(_r(context, x)), y=int(_r(context, y)))
    _log(context, f"Scroll abajo {clicks} veces en ({x},{y})")


@step('I scroll down "{clicks}" times on image "{image_name}"')
@step('hago scroll hacia abajo "{clicks}" veces sobre la imagen "{image_name}"')
@step('que hago scroll hacia abajo "{clicks}" veces sobre la imagen "{image_name}"')
def step_scroll_down_on_image(context, clicks, image_name):
    """Scroll hacia abajo sobre un elemento encontrado por imagen."""
    dm = _dm(context)
    dm.scroll_on_image(_r(context, image_name), direction='down', clicks=int(_r(context, clicks)))
    _log(context, f"Scroll abajo {clicks} veces sobre imagen '{image_name}'")


@step('I scroll up "{clicks}" times on image "{image_name}"')
@step('hago scroll hacia arriba "{clicks}" veces sobre la imagen "{image_name}"')
@step('que hago scroll hacia arriba "{clicks}" veces sobre la imagen "{image_name}"')
def step_scroll_up_on_image(context, clicks, image_name):
    """Scroll hacia arriba sobre un elemento encontrado por imagen."""
    dm = _dm(context)
    dm.scroll_on_image(_r(context, image_name), direction='up', clicks=int(_r(context, clicks)))
    _log(context, f"Scroll arriba {clicks} veces sobre imagen '{image_name}'")


# ===========================================================================
# SECCION 6 - ESPERAS
# ===========================================================================

@step('I wait "{seconds}" seconds on desktop')
@step('espero "{seconds}" segundos en escritorio')
@step('que espero "{seconds}" segundos en escritorio')
def step_wait_seconds_desktop(context, seconds):
    """Pausa la ejecucion el numero de segundos indicado."""
    dm = _dm(context)
    dm.wait_seconds(float(_r(context, seconds)))
    _log(context, f"Espera de {seconds} segundos")


@step('I wait for image "{image_name}" to appear')
@step('espero a que aparezca la imagen "{image_name}"')
@step('que espero a que aparezca la imagen "{image_name}"')
def step_wait_for_image(context, image_name):
    """Espera hasta que una imagen aparezca en pantalla (timeout por defecto)."""
    dm = _dm(context)
    found = dm.wait_for_image(_r(context, image_name))
    assert found, f"La imagen '{image_name}' no aparecio en pantalla dentro del tiempo de espera"
    _log(context, f"Imagen '{image_name}' encontrada en pantalla")


@step('I wait for image "{image_name}" to appear with timeout "{timeout}" seconds')
@step('espero a que aparezca la imagen "{image_name}" con timeout de "{timeout}" segundos')
@step('que espero a que aparezca la imagen "{image_name}" con timeout de "{timeout}" segundos')
def step_wait_for_image_timeout(context, image_name, timeout):
    """Espera hasta que una imagen aparezca en pantalla con timeout personalizado."""
    dm = _dm(context)
    found = dm.wait_for_image(_r(context, image_name), timeout=float(_r(context, timeout)))
    assert found, (
        f"La imagen '{image_name}' no aparecio en pantalla "
        f"despues de {timeout} segundos"
    )
    _log(context, f"Imagen '{image_name}' encontrada (timeout: {timeout}s)")


@step('I wait for image "{image_name}" to disappear')
@step('espero a que desaparezca la imagen "{image_name}"')
@step('que espero a que desaparezca la imagen "{image_name}"')
def step_wait_for_image_disappear(context, image_name):
    """Espera hasta que una imagen desaparezca de pantalla."""
    dm = _dm(context)
    gone = dm.wait_for_image_to_disappear(_r(context, image_name))
    assert gone, f"La imagen '{image_name}' no desaparecio dentro del tiempo de espera"
    _log(context, f"Imagen '{image_name}' desaparecio de pantalla")


@step('I wait for image "{image_name}" to disappear with timeout "{timeout}" seconds')
@step('espero a que desaparezca la imagen "{image_name}" con timeout de "{timeout}" segundos')
@step('que espero a que desaparezca la imagen "{image_name}" con timeout de "{timeout}" segundos')
def step_wait_for_image_disappear_timeout(context, image_name, timeout):
    """Espera hasta que una imagen desaparezca con timeout personalizado."""
    dm = _dm(context)
    gone = dm.wait_for_image_to_disappear(
        _r(context, image_name), timeout=float(_r(context, timeout))
    )
    assert gone, (
        f"La imagen '{image_name}' no desaparecio "
        f"despues de {timeout} segundos"
    )
    _log(context, f"Imagen '{image_name}' desaparecio (timeout: {timeout}s)")


# ===========================================================================
# SECCION 7 - VERIFICACIONES VISUALES
# ===========================================================================

@step('I should see image "{image_name}" on screen')
@step('deberia ver la imagen "{image_name}" en pantalla')
@step('que deberia ver la imagen "{image_name}" en pantalla')
def step_should_see_image(context, image_name):
    """Verifica que una imagen este visible en pantalla."""
    dm = _dm(context)
    visible = dm.is_image_visible(_r(context, image_name))
    assert visible, f"La imagen '{image_name}' no esta visible en pantalla"
    _log(context, f"Imagen '{image_name}' verificada como visible")


@step('I should not see image "{image_name}" on screen')
@step('no deberia ver la imagen "{image_name}" en pantalla')
@step('que no deberia ver la imagen "{image_name}" en pantalla')
def step_should_not_see_image(context, image_name):
    """Verifica que una imagen NO este visible en pantalla."""
    dm = _dm(context)
    visible = dm.is_image_visible(_r(context, image_name))
    assert not visible, f"La imagen '{image_name}' esta visible en pantalla cuando no deberia"
    _log(context, f"Imagen '{image_name}' verificada como no visible")


@step('I should see image "{image_name}" on screen with confidence "{confidence}"')
@step('deberia ver la imagen "{image_name}" en pantalla con confianza "{confidence}"')
@step('que deberia ver la imagen "{image_name}" en pantalla con confianza "{confidence}"')
def step_should_see_image_confidence(context, image_name, confidence):
    """Verifica que una imagen este visible con nivel de confianza personalizado."""
    dm = _dm(context)
    visible = dm.is_image_visible(_r(context, image_name), confidence=float(confidence))
    assert visible, (
        f"La imagen '{image_name}' no esta visible en pantalla "
        f"(confianza requerida: {confidence})"
    )
    _log(context, f"Imagen '{image_name}' visible (confianza: {confidence})")


@step('I store image "{image_name}" location in variable "{variable_name}"')
@step('guardo la ubicacion de la imagen "{image_name}" en la variable "{variable_name}"')
@step('que guardo la ubicacion de la imagen "{image_name}" en la variable "{variable_name}"')
def step_store_image_location(context, image_name, variable_name):
    """Busca una imagen y guarda sus coordenadas (x,y) en una variable."""
    dm = _dm(context)
    location = dm.find_element_by_image(_r(context, image_name))
    assert location is not None, f"Imagen '{image_name}' no encontrada en pantalla"
    context.variable_manager.set_variable(variable_name, location)
    _log(context, f"Ubicacion de '{image_name}' guardada en '{variable_name}': {location}")


@step('I count occurrences of image "{image_name}" and store in variable "{variable_name}"')
@step('cuento las ocurrencias de la imagen "{image_name}" y las guardo en la variable "{variable_name}"')
@step('que cuento las ocurrencias de la imagen "{image_name}" y las guardo en la variable "{variable_name}"')
def step_count_image_occurrences(context, image_name, variable_name):
    """Cuenta cuantas veces aparece una imagen en pantalla y guarda el resultado."""
    dm = _dm(context)
    locations = dm.find_all_elements_by_image(_r(context, image_name))
    count = len(locations)
    context.variable_manager.set_variable(variable_name, count)
    _log(context, f"Ocurrencias de '{image_name}': {count} (guardado en '{variable_name}')")


@step('I verify screen size is "{width}" by "{height}"')
@step('verifico que el tamano de pantalla es "{width}" por "{height}"')
@step('que verifico que el tamano de pantalla es "{width}" por "{height}"')
def step_verify_screen_size(context, width, height):
    """Verifica que la resolucion de pantalla sea la esperada."""
    dm = _dm(context)
    actual_w, actual_h = dm.get_screen_size()
    assert actual_w == int(width) and actual_h == int(height), (
        f"Tamano de pantalla incorrecto. "
        f"Esperado: {width}x{height}, Actual: {actual_w}x{actual_h}"
    )
    _log(context, f"Tamano de pantalla verificado: {width}x{height}")


# ===========================================================================
# SECCION 8 - SCREENSHOTS PARA REPORTES
# ===========================================================================

@step('I take a desktop screenshot')
@step('tomo una captura de pantalla del escritorio')
@step('que tomo una captura de pantalla del escritorio')
def step_take_desktop_screenshot(context, name=None):
    """Toma screenshot de toda la pantalla y lo guarda para el reporte."""
    dm = _dm(context)
    scenario_name = "desktop"
    if hasattr(context, 'scenario') and context.scenario:
        scenario_name = context.scenario.name.replace(' ', '_')[:40]
    path = dm.take_desktop_screenshot(name or scenario_name)
    if not hasattr(context, 'desktop_screenshots'):
        context.desktop_screenshots = []
    context.desktop_screenshots.append(path)
    _log(context, f"Screenshot de escritorio guardado: {path}")


@step('I take a desktop screenshot with name "{name}"')
@step('tomo una captura de pantalla del escritorio con nombre "{name}"')
@step('que tomo una captura de pantalla del escritorio con nombre "{name}"')
def step_take_desktop_screenshot_named(context, name):
    """Toma screenshot de toda la pantalla con nombre personalizado."""
    dm = _dm(context)
    path = dm.take_desktop_screenshot(_r(context, name))
    if not hasattr(context, 'desktop_screenshots'):
        context.desktop_screenshots = []
    context.desktop_screenshots.append(path)
    _log(context, f"Screenshot guardado: {path}")


@step('I take a screenshot of region "{x}" "{y}" "{width}" "{height}" with name "{name}"')
@step('tomo una captura de la region "{x}" "{y}" "{width}" "{height}" con nombre "{name}"')
@step('que tomo una captura de la region "{x}" "{y}" "{width}" "{height}" con nombre "{name}"')
def step_take_region_screenshot(context, x, y, width, height, name):
    """Toma screenshot de una region especifica de la pantalla."""
    dm = _dm(context)
    path = dm.take_region_screenshot(
        int(_r(context, x)), int(_r(context, y)),
        int(_r(context, width)), int(_r(context, height)),
        _r(context, name)
    )
    if not hasattr(context, 'desktop_screenshots'):
        context.desktop_screenshots = []
    context.desktop_screenshots.append(path)
    _log(context, f"Screenshot de region guardado: {path}")


@step('I take a desktop screenshot before action "{action_name}"')
@step('tomo una captura de pantalla del escritorio antes de la accion "{action_name}"')
@step('que tomo una captura de pantalla del escritorio antes de la accion "{action_name}"')
def step_take_screenshot_before_action(context, action_name):
    """Toma screenshot antes de una accion importante (documentacion del flujo)."""
    dm = _dm(context)
    path = dm.take_desktop_screenshot(f"antes_{_r(context, action_name)}")
    if not hasattr(context, 'desktop_screenshots'):
        context.desktop_screenshots = []
    context.desktop_screenshots.append(path)
    _log(context, f"Screenshot previo a '{action_name}': {path}")


@step('I take a desktop screenshot after action "{action_name}"')
@step('tomo una captura de pantalla del escritorio despues de la accion "{action_name}"')
@step('que tomo una captura de pantalla del escritorio despues de la accion "{action_name}"')
def step_take_screenshot_after_action(context, action_name):
    """Toma screenshot despues de una accion importante (documentacion del flujo)."""
    dm = _dm(context)
    path = dm.take_desktop_screenshot(f"despues_{_r(context, action_name)}")
    if not hasattr(context, 'desktop_screenshots'):
        context.desktop_screenshots = []
    context.desktop_screenshots.append(path)
    _log(context, f"Screenshot posterior a '{action_name}': {path}")


# ===========================================================================
# SECCION 9 - PORTAPAPELES
# ===========================================================================

@step('I copy text "{text}" to clipboard')
@step('copio el texto "{text}" al portapapeles')
@step('que copio el texto "{text}" al portapapeles')
def step_copy_to_clipboard(context, text):
    """Copia texto al portapapeles del sistema."""
    dm = _dm(context)
    dm.copy_to_clipboard(_r(context, text))
    _log(context, f"Texto copiado al portapapeles: '{text}'")


@step('I get clipboard content and store in variable "{variable_name}"')
@step('obtengo el contenido del portapapeles y lo guardo en la variable "{variable_name}"')
@step('que obtengo el contenido del portapapeles y lo guardo en la variable "{variable_name}"')
def step_get_clipboard(context, variable_name):
    """Obtiene el contenido actual del portapapeles y lo guarda en una variable."""
    dm = _dm(context)
    content = dm.get_clipboard_content()
    context.variable_manager.set_variable(variable_name, content)
    _log(context, f"Portapapeles guardado en '{variable_name}': '{content[:50]}'")


@step('I copy selected text and store in variable "{variable_name}"')
@step('copio el texto seleccionado y lo guardo en la variable "{variable_name}"')
@step('que copio el texto seleccionado y lo guardo en la variable "{variable_name}"')
def step_copy_selected_text(context, variable_name):
    """Copia el texto actualmente seleccionado (Ctrl+C) y lo guarda en variable."""
    dm = _dm(context)
    content = dm.copy_selected_text()
    context.variable_manager.set_variable(variable_name, content)
    _log(context, f"Texto seleccionado copiado en '{variable_name}': '{content[:50]}'")


@step('I should see clipboard contains "{expected_text}"')
@step('deberia ver que el portapapeles contiene "{expected_text}"')
@step('que deberia ver que el portapapeles contiene "{expected_text}"')
def step_verify_clipboard_contains(context, expected_text):
    """Verifica que el portapapeles contiene el texto esperado."""
    dm = _dm(context)
    content = dm.get_clipboard_content()
    resolved = _r(context, expected_text)
    assert resolved.lower() in content.lower(), (
        f"El portapapeles no contiene '{resolved}'. "
        f"Contenido actual: '{content}'"
    )
    _log(context, f"Portapapeles verificado: contiene '{expected_text}'")


# ===========================================================================
# SECCION 10 - MODO MIXTO (WEB + ESCRITORIO)
# ===========================================================================

@step('I switch to desktop mode')
@step('cambio a modo escritorio')
@step('que cambio a modo escritorio')
def step_switch_to_desktop_mode(context):
    """
    Activa el modo escritorio.
    Si hay un navegador web abierto, guarda su estado para poder volver.
    Usar con el tag @no_browser si la prueba es 100% escritorio.
    """
    dm = _dm(context)
    dm.switch_to_desktop_mode(context)
    _log(context, "Modo escritorio activado")


@step('I switch to web mode')
@step('cambio a modo web')
@step('que cambio a modo web')
def step_switch_to_web_mode(context):
    """
    Vuelve al modo web.
    Restaura la pagina del navegador guardada al cambiar a modo escritorio.
    """
    dm = _dm(context)
    dm.switch_to_web_mode(context)
    _log(context, "Modo web restaurado")


@step('I switch to desktop application "{app_path}" from web test')
@step('cambio a la aplicacion de escritorio "{app_path}" desde la prueba web')
@step('que cambio a la aplicacion de escritorio "{app_path}" desde la prueba web')
def step_switch_to_desktop_app_from_web(context, app_path):
    """
    Lanza una aplicacion de escritorio y activa el modo escritorio
    sin cerrar el navegador web (prueba mixta).
    """
    dm = _dm(context)
    dm.switch_to_desktop_mode(context)
    dm.launch_application(_r(context, app_path), wait_seconds=2.0)
    _log(context, f"Cambiado a aplicacion de escritorio: {app_path}")


@step('I return to web browser after desktop interaction')
@step('vuelvo al navegador web despues de la interaccion con escritorio')
@step('que vuelvo al navegador web despues de la interaccion con escritorio')
def step_return_to_web_browser(context):
    """
    Vuelve al navegador web despues de interactuar con una aplicacion de escritorio.
    Trae el navegador al frente y restaura el contexto web.
    """
    dm = _dm(context)
    dm.switch_to_web_mode(context)
    # Intentar traer el navegador al frente
    for browser_title in ['Chrome', 'Firefox', 'Edge', 'Chromium']:
        if dm.bring_window_to_front(browser_title):
            break
    _log(context, "Regresado al navegador web")


@step('I take desktop screenshot and continue web test with name "{name}"')
@step('tomo captura de escritorio y continuo la prueba web con nombre "{name}"')
@step('que tomo captura de escritorio y continuo la prueba web con nombre "{name}"')
def step_screenshot_and_continue_web(context, name):
    """
    Toma un screenshot del escritorio (para el reporte) y luego
    vuelve al foco del navegador web. Util en pruebas mixtas.
    """
    dm = _dm(context)
    path = dm.take_desktop_screenshot(_r(context, name))
    if not hasattr(context, 'desktop_screenshots'):
        context.desktop_screenshots = []
    context.desktop_screenshots.append(path)
    # Restaurar foco al navegador
    for browser_title in ['Chrome', 'Firefox', 'Edge', 'Chromium']:
        if dm.bring_window_to_front(browser_title):
            break
    _log(context, f"Screenshot de escritorio tomado y foco restaurado al navegador: {path}")


# ===========================================================================
# SECCION 11 - OCR EN ESCRITORIO (combina DesktopManager + OCRManager)
# ===========================================================================

@step('I take desktop screenshot and extract text with OCR into variable "{variable_name}"')
@step('tomo captura de escritorio y extraigo texto con OCR en la variable "{variable_name}"')
@step('que tomo captura de escritorio y extraigo texto con OCR en la variable "{variable_name}"')
def step_desktop_screenshot_ocr_to_variable(context, variable_name):
    """
    Toma screenshot del escritorio, aplica OCR y guarda el texto en una variable.
    Util para leer texto de aplicaciones que no exponen su contenido via accesibilidad.
    """
    dm = _dm(context)
    path = dm.take_desktop_screenshot("ocr_desktop")

    from hakalab_framework.core.ocr_manager_simple import OCRManagerSimple
    ocr = OCRManagerSimple()
    text = ocr.get_all_text(path)
    context.variable_manager.set_variable(variable_name, text)
    context.ocr_text = text
    _log(context, f"OCR de escritorio completado. Texto guardado en '{variable_name}'")


@step('I should see text "{expected_text}" on desktop screen using OCR')
@step('deberia ver el texto "{expected_text}" en la pantalla del escritorio usando OCR')
@step('que deberia ver el texto "{expected_text}" en la pantalla del escritorio usando OCR')
def step_should_see_text_on_desktop_ocr(context, expected_text):
    """
    Toma screenshot del escritorio y verifica que el texto esperado
    este presente usando OCR.
    """
    dm = _dm(context)
    path = dm.take_desktop_screenshot("ocr_verify")

    from hakalab_framework.core.ocr_manager_simple import OCRManagerSimple
    ocr = OCRManagerSimple()
    text = ocr.get_all_text(path)
    resolved = _r(context, expected_text)
    assert resolved.lower() in text.lower(), (
        f"Texto '{resolved}' no encontrado en pantalla via OCR. "
        f"Texto detectado: '{text[:200]}'"
    )
    _log(context, f"Texto '{expected_text}' verificado en pantalla via OCR")


@step('I should not see text "{unexpected_text}" on desktop screen using OCR')
@step('no deberia ver el texto "{unexpected_text}" en la pantalla del escritorio usando OCR')
@step('que no deberia ver el texto "{unexpected_text}" en la pantalla del escritorio usando OCR')
def step_should_not_see_text_on_desktop_ocr(context, unexpected_text):
    """
    Toma screenshot del escritorio y verifica que el texto NO este presente via OCR.
    """
    dm = _dm(context)
    path = dm.take_desktop_screenshot("ocr_verify_not")

    from hakalab_framework.core.ocr_manager_simple import OCRManagerSimple
    ocr = OCRManagerSimple()
    text = ocr.get_all_text(path)
    resolved = _r(context, unexpected_text)
    assert resolved.lower() not in text.lower(), (
        f"Texto '{resolved}' encontrado en pantalla cuando no deberia estar"
    )
    _log(context, f"Texto '{unexpected_text}' correctamente ausente en pantalla")


@step('I take desktop screenshot of region "{x}" "{y}" "{width}" "{height}" and extract text into variable "{variable_name}"')
@step('tomo captura de la region "{x}" "{y}" "{width}" "{height}" del escritorio y extraigo texto en la variable "{variable_name}"')
@step('que tomo captura de la region "{x}" "{y}" "{width}" "{height}" del escritorio y extraigo texto en la variable "{variable_name}"')
def step_region_screenshot_ocr(context, x, y, width, height, variable_name):
    """
    Toma screenshot de una region especifica del escritorio y aplica OCR.
    Util para leer campos concretos de una aplicacion.
    """
    dm = _dm(context)
    path = dm.take_region_screenshot(
        int(_r(context, x)), int(_r(context, y)),
        int(_r(context, width)), int(_r(context, height)),
        "ocr_region"
    )

    from hakalab_framework.core.ocr_manager_simple import OCRManagerSimple
    ocr = OCRManagerSimple()
    text = ocr.get_all_text(path)
    context.variable_manager.set_variable(variable_name, text)
    context.ocr_text = text
    _log(context, f"OCR de region completado. Texto guardado en '{variable_name}': '{text[:80]}'")


# ===========================================================================
# SECCION 12 - VARIABLES Y UTILIDADES
# ===========================================================================

@step('I store mouse position in variable "{variable_name}"')
@step('guardo la posicion del mouse en la variable "{variable_name}"')
@step('que guardo la posicion del mouse en la variable "{variable_name}"')
def step_store_mouse_position(context, variable_name):
    """Guarda la posicion actual del mouse (x, y) en una variable."""
    dm = _dm(context)
    pos = dm.get_mouse_position()
    context.variable_manager.set_variable(variable_name, pos)
    _log(context, f"Posicion del mouse guardada en '{variable_name}': {pos}")


@step('I store screen size in variable "{variable_name}"')
@step('guardo el tamano de pantalla en la variable "{variable_name}"')
@step('que guardo el tamano de pantalla en la variable "{variable_name}"')
def step_store_screen_size(context, variable_name):
    """Guarda el tamano de pantalla (width, height) en una variable."""
    dm = _dm(context)
    size = dm.get_screen_size()
    context.variable_manager.set_variable(variable_name, size)
    _log(context, f"Tamano de pantalla guardado en '{variable_name}': {size}")


@step('I set desktop action pause to "{seconds}" seconds')
@step('establezco la pausa entre acciones de escritorio en "{seconds}" segundos')
@step('que establezco la pausa entre acciones de escritorio en "{seconds}" segundos')
def step_set_action_pause(context, seconds):
    """Cambia la pausa automatica entre acciones de escritorio."""
    import pyautogui
    pyautogui.PAUSE = float(_r(context, seconds))
    _log(context, f"Pausa entre acciones establecida en {seconds}s")


@step('I set desktop image search confidence to "{confidence}"')
@step('establezco la confianza de busqueda de imagenes en "{confidence}"')
@step('que establezco la confianza de busqueda de imagenes en "{confidence}"')
def step_set_image_confidence(context, confidence):
    """Cambia el nivel de confianza para la busqueda de imagenes (0.0 a 1.0)."""
    dm = _dm(context)
    dm.search_confidence = float(_r(context, confidence))
    _log(context, f"Confianza de busqueda de imagenes establecida en {confidence}")


@step('I set desktop image search timeout to "{seconds}" seconds')
@step('establezco el timeout de busqueda de imagenes en "{seconds}" segundos')
@step('que establezco el timeout de busqueda de imagenes en "{seconds}" segundos')
def step_set_image_timeout(context, seconds):
    """Cambia el timeout para la busqueda de imagenes en pantalla."""
    dm = _dm(context)
    dm.search_timeout = float(_r(context, seconds))
    _log(context, f"Timeout de busqueda de imagenes establecido en {seconds}s")


@step('I press Enter key')
@step('presiono la tecla Enter')
@step('que presiono la tecla Enter')
def step_press_enter(context):
    """Presiona la tecla Enter (atajo comun)."""
    dm = _dm(context)
    dm.press_key('enter')
    _log(context, "Tecla Enter presionada")


@step('I press Tab key')
@step('presiono la tecla Tab')
@step('que presiono la tecla Tab')
def step_press_tab(context):
    """Presiona la tecla Tab (atajo comun para navegar entre campos)."""
    dm = _dm(context)
    dm.press_key('tab')
    _log(context, "Tecla Tab presionada")


@step('I press Escape key')
@step('presiono la tecla Escape')
@step('que presiono la tecla Escape')
def step_press_escape(context):
    """Presiona la tecla Escape (atajo comun para cancelar/cerrar)."""
    dm = _dm(context)
    dm.press_key('escape')
    _log(context, "Tecla Escape presionada")


@step('I press keyboard shortcut copy')
@step('presiono el atajo de teclado copiar')
@step('que presiono el atajo de teclado copiar')
def step_press_copy(context):
    """Presiona Ctrl+C (copiar)."""
    dm = _dm(context)
    dm.press_hotkey('ctrl', 'c')
    _log(context, "Ctrl+C presionado")


@step('I press keyboard shortcut paste')
@step('presiono el atajo de teclado pegar')
@step('que presiono el atajo de teclado pegar')
def step_press_paste(context):
    """Presiona Ctrl+V (pegar)."""
    dm = _dm(context)
    dm.press_hotkey('ctrl', 'v')
    _log(context, "Ctrl+V presionado")


@step('I press keyboard shortcut select all')
@step('presiono el atajo de teclado seleccionar todo')
@step('que presiono el atajo de teclado seleccionar todo')
def step_press_select_all(context):
    """Presiona Ctrl+A (seleccionar todo)."""
    dm = _dm(context)
    dm.press_hotkey('ctrl', 'a')
    _log(context, "Ctrl+A presionado")


@step('I press keyboard shortcut save')
@step('presiono el atajo de teclado guardar')
@step('que presiono el atajo de teclado guardar')
def step_press_save(context):
    """Presiona Ctrl+S (guardar)."""
    dm = _dm(context)
    dm.press_hotkey('ctrl', 's')
    _log(context, "Ctrl+S presionado")


@step('I press keyboard shortcut undo')
@step('presiono el atajo de teclado deshacer')
@step('que presiono el atajo de teclado deshacer')
def step_press_undo(context):
    """Presiona Ctrl+Z (deshacer)."""
    dm = _dm(context)
    dm.press_hotkey('ctrl', 'z')
    _log(context, "Ctrl+Z presionado")

