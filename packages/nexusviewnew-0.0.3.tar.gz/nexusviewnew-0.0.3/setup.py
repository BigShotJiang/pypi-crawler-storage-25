import setuptools

with open("README.md", "r", encoding="utf-8") as fh:
    long_description = fh.read()

__version__ = "0.0.3"
REPO_NAME = "NexusViewNew"
AUTHOR_USER_NAME = "AK_SHIHAB"
AUTHOR_EMAIL = "shihabkaiyumhossen@gmail.com"
SRC_REPO = "NexusViewNew"

setuptools.setup(
    name=SRC_REPO,
    version=__version__,
    author=AUTHOR_USER_NAME,
    author_email=AUTHOR_EMAIL,
    description="A small python package",

    # ✅ IMPORTANT (fixes PyPI error)
    long_description=long_description,
    long_description_content_type="text/markdown",

    url=f"https://github.com/{AUTHOR_USER_NAME}/{REPO_NAME}",
    project_urls={
        "Bug Tracker": f"https://github.com/{AUTHOR_USER_NAME}/{REPO_NAME}/issues",
    },

    package_dir={"": "src"},
    packages=setuptools.find_packages(where="src"),

    python_requires=">=3.8",
)
