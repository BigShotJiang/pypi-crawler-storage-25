# Synqly Python SDK (Typeless)

The `synqly-typeless` package provides a Python client for the [Synqly](https://synqly.com) platform where engine connector responses return plain dictionaries instead of typed Pydantic models. This gives you full flexibility to work with response data without schema constraints — ideal for custom mappings, dynamic integrations, and rapid prototyping.

The management API (accounts, integrations, mappings, tokens) remains fully typed.

This package is a drop-in replacement for the [typed `synqly` SDK](https://github.com/Synqly/python-sdk) — usage is identical with the caveat that engine request and response payloads are generic (`Dict[str, Any]`) rather than Pydantic models.

If you aren't yet a Synqly customer, please [schedule a demo](https://synqly.com/demo/).

## Installation

```bash
pip install synqly-typeless
```

## Quick Start

```python
from synqly_typeless.management.client import SynqlyManagement
from synqly_typeless.engine.client import SynqlyEngine

# Management client — create accounts, integrations, mappings
mgmt = SynqlyManagement(token="<org-token>", base_url="https://api.synqly.com")

# Engine client — query data (responses are plain dicts)
engine = SynqlyEngine(token="<integration-token>", base_url="https://api.synqly.com")

# Query EDR endpoints — result is List[dict]
response = engine.edr.query_endpoints(limit=10)
for endpoint in response.result:
    print(endpoint["device"]["hostname"])

# Query tickets
tickets = engine.ticketing.query_tickets(limit=5)

# Create a ticket
engine.ticketing.create_ticket(
    name="my-ticket",
    summary="Something needs attention",
    priority="HIGH",
)
```

## How It Differs from `synqly`

| | `synqly` (typed) | `synqly-typeless` |
|---|---|---|
| Engine responses | Pydantic models | `Dict[str, Any]` |
| Management API | Typed | Typed |
| Response envelope | Typed (`result`, `cursor`, `messages`) | Typed |
| Install side-by-side | ✓ | ✓ |

Both packages can be installed in the same environment without conflicts.

## Documentation

- [Synqly Documentation](https://docs.synqly.com)
- [API Reference](https://docs.synqly.com/api-reference/overview)
- [Adaptive Mapping](https://docs.synqly.com/api-reference/adaptive-mapping)
- [Getting Started Guide](https://docs.synqly.com/guides/getting-started/overview)
- [Typed SDK Examples](https://github.com/Synqly/python-sdk/tree/main/examples) — usage patterns apply directly to this package
