from pathlib import Path
from typing import Protocol, runtime_checkable

from takk.models import Project, SecretClass, SettingsValue, settings_for
from takk.secrets import ResourceTags, ServiceUrl


@runtime_checkable
class _WithSettings(Protocol):
    settings: list[SecretClass] | SecretClass | None


def is_commented(secret: SettingsValue) -> bool:
    has_resource_tag = any(
        ResourceTags.is_tag(tag.split(":")[0]) or ServiceUrl.from_string(tag)
        for tag in secret.tags
    ) or ResourceTags.is_tag(secret.data_type)
    return has_resource_tag or secret.default_value is not None or secret.is_optional


def _component_secrets(component: object) -> list[SecretClass]:
    """Extract per-component secrets list from any component type."""
    if isinstance(component, _WithSettings) and component.settings is not None:
        s = component.settings
        return s if isinstance(s, list) else [s]
    return []


def generate_dotenv(project: Project, output: Path = Path(".env")) -> tuple[int, int]:
    """Generate a .env file for the given project.

    Returns a tuple of (required_count, commented_count).
    """
    from dotenv import dotenv_values

    # Map: secret_name -> list of config class names (in order of first encounter)
    secret_classes: dict[str, list[str]] = {}
    # Map: secret_name -> SettingsValue (first encounter)
    secret_values: dict[str, SettingsValue] = {}

    def collect(secret: SettingsValue, cls_name: str) -> None:
        display_name = cls_name.removeprefix("Partial")
        if secret.name not in secret_classes:
            secret_classes[secret.name] = []
            secret_values[secret.name] = secret
        if display_name not in secret_classes[secret.name]:
            secret_classes[secret.name].append(display_name)

    for settings_cls in project.shared_settings or []:
        for secret in settings_for(settings_cls):
            collect(secret, settings_cls.__name__)

    for component in project.components.values():
        for settings_cls in _component_secrets(component):
            for secret in settings_for(settings_cls):
                collect(secret, settings_cls.__name__)

    for worker in project.workers or []:
        for settings_cls in _component_secrets(worker):
            for secret in settings_for(settings_cls):
                collect(secret, settings_cls.__name__)

    # Group secrets by their (ordered) tuple of class names
    section_order: list[tuple[str, ...]] = []
    sections: dict[tuple[str, ...], list[SettingsValue]] = {}
    for name, cls_names in secret_classes.items():
        key = tuple(cls_names)
        if key not in sections:
            section_order.append(key)
            sections[key] = []
        sections[key].append(secret_values[name])

    # Sort sections so those with the most required fields appear first
    section_order.sort(
        key=lambda k: sum(1 for s in sections[k] if not is_commented(s)),
        reverse=True,
    )

    existing = dotenv_values(output)

    lines: list[str] = []
    total_required = 0
    total_commented = 0

    for key in section_order:
        section_secrets = sections[key]
        header = " + ".join(key)
        lines.append(f"# {'=' * 11}{'=' * len(header)}{'=' * 11}")
        lines.append(f"# {'=' * 10} {header} {'=' * 10}")
        lines.append(f"# {'=' * 11}{'=' * len(header)}{'=' * 11}")
        lines.append("")

        required = [s for s in section_secrets if not is_commented(s)]
        commented = [s for s in section_secrets if is_commented(s)]

        if required:
            for secret in required:
                if secret.description:
                    lines.append(f"# {secret.description}")
                value = (existing.get(secret.name, "") or "").replace("\n", "\\n")
                lines.append(f'{secret.name.upper()}="{value}"')
            total_required += len(required)

        if commented:
            if required:
                lines.append("")
            for secret in commented:
                if secret.description:
                    lines.append(f"# {secret.description}")
                value = (existing.get(secret.name, secret.default_value or "") or "").replace("\n", "\\n")
                lines.append(f"# {secret.name.upper()}=\"{value}\"")
            total_commented += len(commented)

        lines.append("")

    output.write_text("\n".join(lines))

    return total_required, total_commented
