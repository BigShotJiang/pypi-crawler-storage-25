from pydantic import BaseModel, Field
from typing import Literal, Sequence


class Resource:
    def resource(self, name: str) -> "CompiledResource":
        raise NotImplementedError(type(self))


PostgresExtensions = Literal[
    "cube", 
    "bloom",
    "address_standardizer",
    "address_standardizer_data_us",
    "bloom",
    "btree_gin",
    "btree_gist",
    "citext",
    "cube",
    "dict_int",
    "dict_xsyn",
    "earthdistance",
    "fuzzystrmatch",
    "hstore",
    "intagg",
    "intarray",
    "isn",
    "ltree",
    "pg_cron",
    "pg_prewarm",
    "pg_stat_statements",
    "pg_trgm",
    "pgcrypto",
    "pgrouting",
    "pgrowlocks",
    "pgvector",
    "plpgsql",
    "postgis",
    "postgis_raster",
    "postgis_sfcgal",
    "postgis_tiger_geocoder",
    "postgis_topology",
    "tablefunc",
    "timescaledb",
    "tsm_system_rows",
    "tsm_system_time",
    "unaccent",
    "uuid-ossp"
]


class PostgresInstance(BaseModel, Resource):
    version: Literal[14, 15, 16, 17] = Field(default=17)

    settings: dict[str, str] = Field(default_factory=dict)
    tags: list[str] = Field(default_factory=list)

    min_vcpus: int = Field(default=0)
    min_gb_ram: int = Field(default=0)

    k_iops: Literal[5, 15] = Field(default=5)
    number_of_nodes: Literal[1, 2] = Field(default=1)

    is_backup_disabled: bool = Field(default=False)

    is_default: bool | None = Field(default=None)

    extensions: Sequence[PostgresExtensions | str] = Field(default_factory=list)

    def resource(self, name: str) -> "CompiledResource":
        return CompiledResource(name=name, psql=self)


class ServerlessPostgresInstance(BaseModel, Resource):
    version: Literal[16] = Field(default=16)

    min_cpus: int = Field(default=0)
    max_cpus: int = Field(default=4)

    is_default: bool | None = Field(default=None)

    extensions: Sequence[PostgresExtensions | str] = Field(default_factory=list)

    def resource(self, name: str) -> "CompiledResource":
        return CompiledResource(name=name, serverless_psql=self)


class RedisInstance(BaseModel, Resource):
    version: Literal["7.2.11"] = Field(default="7.2.11")
    
    number_of_nodes: int = Field(default=1)

    min_vcpus: int = Field(default=0)
    min_gb_ram: int = Field(default=1)

    tags: list[str] = Field(default_factory=list)

    is_default: bool | None = Field(default=None)

    def resource(self, name: str) -> "CompiledResource":
        return CompiledResource(name=name, redis=self)

class MongoDBInstance(BaseModel, Resource):
    version: Literal["7.0"] = Field(default="7.0")

    number_of_nodes: Literal[1, 3] = Field(default=1)

    min_vcpus: int = Field(default=0)
    min_gb_ram: int = Field(default=16)

    tags: list[str] = Field(default_factory=list)

    is_default: bool | None = Field(default=None)

    def resource(self, name: str) -> "CompiledResource":
        return CompiledResource(name=name, mongo_db=self)

class ClickhouseInstance(BaseModel, Resource):
    version: Literal["25"] = Field(default="25")
    
    min_vcpus: int = 4
    max_vcpus: int = 8

    nodes: int = 1

    tags: list[str] = Field(default_factory=list)

    is_default: bool | None = Field(default=None)

    def resource(self, name: str) -> "CompiledResource":
        return CompiledResource(name=name, clickhouse=self)

class KafkaInstance(BaseModel, Resource):
    version: Literal["4.0.0"] = Field(default="4.0.0")
    
    nodes: Literal[1, 3] = 3

    min_gb: int = 1
    min_vcpus: int = 1

    tags: list[str] = Field(default_factory=list)

    is_default: bool | None = Field(default=None)

    def resource(self, name: str) -> "CompiledResource":
        return CompiledResource(name=name, kafka=self)

class OpenSearchInstance(BaseModel, Resource):
    version: Literal["2.0"] = Field(default="2.0")
    
    nodes: Literal[1, 3] = 3

    min_gb: int = 1
    min_vcpus: int = 1

    tags: list[str] = Field(default_factory=list)

    is_default: bool | None = Field(default=None)

    def resource(self, name: str) -> "CompiledResource":
        return CompiledResource(name=name, opensearch=self)

class SparkInstance(BaseModel, Resource):
    version: Literal["4.0.0"] = Field(default="4.0.0")

    main_node_min_gb: int = 1
    main_node_min_vcpus: int = 1
    
    worker_nodes: int = 1
    worker_min_gb: int = 1
    worker_min_vcpus: int = 1
    worker_min_gpu_gb: int | None = None

    tags: list[str] = Field(default_factory=list)

    is_default: bool | None = Field(default=None)

    def resource(self, name: str) -> "CompiledResource":
        return CompiledResource(name=name)


class CompiledResource(BaseModel):
    name: str
    serverless_psql: ServerlessPostgresInstance | None = Field(default=None)
    psql: PostgresInstance | None = Field(default=None)
    redis: RedisInstance | None = Field(default=None)
    mongo_db: MongoDBInstance | None = Field(default=None)
    clickhouse: ClickhouseInstance | None = Field(default=None)
    kafka: KafkaInstance | None = Field(default=None)
    opensearch: OpenSearchInstance | None = Field(default=None)
