from __future__ import annotations

import json
from datetime import UTC, datetime

from fastapi.testclient import TestClient

from panoptes.utils.telemetry import TelemetryClient
from panoptes.utils.telemetry.server import TelemetryService, create_app


def test_telemetry_client_ready_and_health(tmp_path):
    fixed_now = datetime(2026, 3, 17, 14, 30, tzinfo=UTC)
    app = create_app(TelemetryService(tmp_path / "site", now_provider=lambda: fixed_now))

    with TestClient(app) as test_client:
        client = TelemetryClient(base_url="http://testserver", session=test_client)

        assert client.health() == {"ok": True}
        assert client.ready()["ready"] is True
        assert client.ready()["run_active"] is False


def test_telemetry_client_posts_and_reads_current(tmp_path):
    fixed_now = datetime(2026, 3, 17, 14, 35, tzinfo=UTC)
    app = create_app(TelemetryService(tmp_path / "site", now_provider=lambda: fixed_now))

    with TestClient(app) as test_client:
        client = TelemetryClient(base_url="http://testserver", session=test_client)
        event = client.post_event("weather", {"sky": "clear"}, meta={"source": "client"})
        current = client.current()
        current_weather = client.current_event("weather")

        assert current["weather"] == event
        assert current_weather == event


def test_telemetry_client_manages_runs(tmp_path):
    fixed_now = datetime(2026, 3, 17, 14, 40, tzinfo=UTC)
    run_dir = tmp_path / "run-002"
    app = create_app(TelemetryService(tmp_path / "site", now_provider=lambda: fixed_now))

    with TestClient(app) as test_client:
        client = TelemetryClient(base_url="http://testserver", session=test_client)

        started = client.start_run(str(run_dir), run_id="002")
        event = client.post_event("status", {"state": "running"})
        stopped = client.stop_run()

        assert started["run_dir"] == str(run_dir)
        assert started["run_id"] == "002"
        assert event["meta"]["run_id"] == "002"
        assert stopped["run_dir"] == str(run_dir)


def test_telemetry_client_can_start_run_without_arguments(tmp_path):
    fixed_now = datetime(2026, 3, 17, 14, 42, tzinfo=UTC)
    site_dir = tmp_path / "site"
    (site_dir / "001").mkdir(parents=True)
    app = create_app(TelemetryService(site_dir, now_provider=lambda: fixed_now))

    with TestClient(app) as test_client:
        client = TelemetryClient(base_url="http://testserver", session=test_client)

        started = client.start_run()

        assert started["run_id"] == "002"
        assert started["run_dir"] == str(site_dir / "002")


def test_telemetry_client_current_merges_site_and_run_context(tmp_path):
    fixed_now = datetime(2026, 3, 17, 14, 45, tzinfo=UTC)
    app = create_app(TelemetryService(tmp_path / "site", now_provider=lambda: fixed_now))

    with TestClient(app) as test_client:
        client = TelemetryClient(base_url="http://testserver", session=test_client)

        site_weather = client.post_event("weather", {"sky": "clear"})
        client.start_run(run_id="001")
        run_status = client.post_event("status", {"state": "idle"})

        assert client.current() == {
            "weather": site_weather,
            "status": run_status,
        }


# ---------------------------------------------------------------------------
# PanDB-compatible interface
# ---------------------------------------------------------------------------


def test_pandb_compat_insert_current_returns_seq(tmp_path):
    site_dir = tmp_path / "site"
    app = create_app(TelemetryService(site_dir))

    with TestClient(app) as test_client:
        client = TelemetryClient(base_url="http://testserver", session=test_client)

        obj_id = client.insert_current("weather", {"sky": "clear"})
        assert obj_id == "1"

        obj_id2 = client.insert_current("weather", {"sky": "cloudy"}, store_permanently=False)
        assert obj_id2 == "2"

        ndjson_files = list(site_dir.glob("*.ndjson"))
        assert len(ndjson_files) == 1
        lines = ndjson_files[0].read_text(encoding="utf-8").splitlines()
        assert len(lines) == 1
        assert json.loads(lines[0])["seq"] == 1


def test_post_event_store_permanently_false_skips_file_write(tmp_path):
    site_dir = tmp_path / "site"
    app = create_app(TelemetryService(site_dir))

    with TestClient(app) as test_client:
        client = TelemetryClient(base_url="http://testserver", session=test_client)

        event = client.post_event("weather", {"sky": "clear"}, store_permanently=False)
        assert event.seq == 1

        current = client.current()
        assert "weather" in current

        ndjson_files = list(site_dir.glob("*.ndjson"))
        assert ndjson_files == []


def test_pandb_compat_insert_returns_seq_and_does_not_update_current(tmp_path):
    app = create_app(TelemetryService(tmp_path / "site"))

    with TestClient(app) as test_client:
        client = TelemetryClient(base_url="http://testserver", session=test_client)

        obj_id = client.insert("weather", {"sky": "overcast"})
        assert obj_id == "1"
        # make_current=False means no current snapshot exists yet.
        assert client.get_current("weather") is None


def test_pandb_compat_get_current_returns_pandb_shape(tmp_path):
    app = create_app(TelemetryService(tmp_path / "site"))

    with TestClient(app) as test_client:
        client = TelemetryClient(base_url="http://testserver", session=test_client)

        client.insert_current("environment", {"temp_c": 15.2})
        record = client.get_current("environment")

        assert record is not None
        assert record["data"] == {"temp_c": 15.2}
        assert record["type"] == "environment"
        # PanDB-compatible aliases
        assert "_id" in record
        assert "date" in record
        assert record["_id"] == str(record.seq)
        assert record["date"] == record.ts
        # Native fields also accessible
        assert record.seq == 1
        assert record.meta is not None


def test_pandb_compat_get_current_returns_none_when_missing(tmp_path):
    app = create_app(TelemetryService(tmp_path / "site"))

    with TestClient(app) as test_client:
        client = TelemetryClient(base_url="http://testserver", session=test_client)

        assert client.get_current("nonexistent") is None


def test_pandb_compat_find_returns_none(tmp_path):
    app = create_app(TelemetryService(tmp_path / "site"))

    with TestClient(app) as test_client:
        client = TelemetryClient(base_url="http://testserver", session=test_client)

        obj_id = client.insert_current("weather", {"sky": "clear"})
        assert client.find("weather", obj_id) is None


def test_pandb_compat_clear_current_is_noop(tmp_path):
    app = create_app(TelemetryService(tmp_path / "site"))

    with TestClient(app) as test_client:
        client = TelemetryClient(base_url="http://testserver", session=test_client)

        client.insert_current("weather", {"sky": "clear"})
        client.clear_current("weather")
        # Current snapshot is unchanged — clear_current is a no-op.
        assert client.get_current("weather") is not None


def test_post_event_serializes_astropy_quantities(tmp_path):
    """Quantities round-trip: stored as strings, returned as Quantity objects."""
    from astropy import units as u

    app = create_app(TelemetryService(tmp_path / "site"))

    with TestClient(app) as test_client:
        client = TelemetryClient(base_url="http://testserver", session=test_client)

        data = {
            "temperature": 22.5 * u.deg_C,
            "wind_speed": 5.0 * u.m / u.s,
            "humidity": 0.65,
        }
        result = client.post_event("environment", data)
        assert result["type"] == "environment"

        current = client.get_current("environment")
        assert current is not None
        # Quantities are deserialized back on retrieval where units are recognised.
        assert current["data"]["wind_speed"] == 5.0 * u.m / u.s
        # Plain floats pass through unchanged.
        assert current["data"]["humidity"] == 0.65


def test_insert_current_serializes_astropy_quantities(tmp_path):
    """PanDB-compat insert_current must also handle Quantities (most common POCS path)."""
    from astropy import units as u

    app = create_app(TelemetryService(tmp_path / "site"))

    with TestClient(app) as test_client:
        client = TelemetryClient(base_url="http://testserver", session=test_client)

        data = {
            "alt": 45.0 * u.degree,
            "az": 180.0 * u.degree,
            "ra": 10.5 * u.hourangle,
        }
        seq = client.insert_current("mount", data)
        assert seq  # truthy sequence number string

        record = client.get_current("mount")
        assert record is not None
        assert record["data"]["alt"] == 45.0 * u.degree
        assert record["data"]["az"] == 180.0 * u.degree


def test_post_event_serializes_numpy_arrays(tmp_path):
    """numpy arrays inside data dicts must be serialized without error."""
    import numpy as np

    app = create_app(TelemetryService(tmp_path / "site"))

    with TestClient(app) as test_client:
        client = TelemetryClient(base_url="http://testserver", session=test_client)

        data = {"values": np.array([1.0, 2.0, 3.0]), "count": 3}
        result = client.post_event("stats", data)
        assert result["type"] == "stats"

        current = client.get_current("stats")
        assert current["data"]["values"] == [1.0, 2.0, 3.0]
        assert current["data"]["count"] == 3


def test_post_event_serializes_nested_quantities(tmp_path):
    """Quantities nested inside sub-dicts must be serialized and deserialized correctly."""
    from astropy import units as u

    app = create_app(TelemetryService(tmp_path / "site"))

    with TestClient(app) as test_client:
        client = TelemetryClient(base_url="http://testserver", session=test_client)

        data = {
            "location": {
                "latitude": 20.7 * u.degree,
                "longitude": -156.3 * u.degree,
                "elevation": 3055.0 * u.meter,
            }
        }
        client.post_event("site", data)
        current = client.get_current("site")
        loc = current["data"]["location"]
        assert loc["latitude"] == 20.7 * u.degree
        assert loc["elevation"] == 3055.0 * u.meter


def test_current_deserializes_all_event_data(tmp_path):
    """current() must deserialize Quantities in every event in the snapshot."""
    from astropy import units as u

    app = create_app(TelemetryService(tmp_path / "site"))

    with TestClient(app) as test_client:
        client = TelemetryClient(base_url="http://testserver", session=test_client)

        client.post_event("mount", {"alt": 45.0 * u.degree, "az": 90.0 * u.degree})
        client.post_event("weather", {"wind_speed": 3.0 * u.m / u.s})

        snapshot = client.current()
        assert snapshot["mount"]["data"]["alt"] == 45.0 * u.degree
        assert snapshot["weather"]["data"]["wind_speed"] == 3.0 * u.m / u.s
