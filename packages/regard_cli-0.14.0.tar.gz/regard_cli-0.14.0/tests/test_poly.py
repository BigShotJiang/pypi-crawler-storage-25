"""Polymarket venue tests — contract + error paths.

Mocks the CLOB client, Gamma client, and web3 to test all 14 poly commands
without requiring py_clob_client to be installed.
"""

import json
from unittest.mock import MagicMock, patch

import pytest
from typer.testing import CliRunner

from regard.main import app

runner = CliRunner()


# ---------------------------------------------------------------------------
# Mock data
# ---------------------------------------------------------------------------

MOCK_BALANCE = {"balance": "500.00", "allowances": {"USDC": "1000000"}}

MOCK_ORDERS = [
    {
        "id": "order-001",
        "market": "0xmarket1",
        "asset_id": "token-yes-001",
        "side": "BUY",
        "price": "0.55",
        "original_size": "100",
        "size_matched": "50",
        "status": "LIVE",
        "created_at": "2026-03-30T10:00:00Z",
    },
]

MOCK_POSITIONS = [
    {
        "asset_id": "token-yes-001",
        "market": "0xmarket1",
        "side": "BUY",
        "size": "100",
        "avg_price": "0.55",
        "cur_price": "0.60",
        "pnl": "5.00",
    },
]

MOCK_TRADES = [
    {
        "id": "trade-001",
        "market": "0xmarket1",
        "asset_id": "token-yes-001",
        "side": "BUY",
        "price": "0.55",
        "size": "100",
        "fee": "0.50",
        "created_at": "2026-03-30T10:00:00Z",
    },
]

MOCK_GAMMA_MARKET = {
    "id": "12345",
    "conditionId": "0xcondition",
    "question": "Will BTC hit $100k by 2027?",
    "slug": "btc-100k-2027",
    "clobTokenIds": '["token-yes-001", "token-no-001"]',
    "outcomePrices": '["0.55", "0.45"]',
    "active": True,
    "closed": False,
    "acceptingOrders": "true",
    "negRisk": "false",
    "volume24hr": "50000",
    "volumeNum": "1000000",
    "liquidityNum": "200000",
    "endDateIso": "2027-01-01T00:00:00Z",
    "bestBid": "0.54",
    "bestAsk": "0.56",
    "orderMinSize": "5",
    "orderPriceMinTickSize": "0.01",
}

MOCK_GAMMA_MARKETS = [MOCK_GAMMA_MARKET]

MOCK_ORDER_BOOK = MagicMock()
MOCK_ORDER_BOOK.bids = [MagicMock(price="0.54", size="200"), MagicMock(price="0.53", size="150")]
MOCK_ORDER_BOOK.asks = [MagicMock(price="0.56", size="180"), MagicMock(price="0.57", size="120")]

MOCK_EVENT = {
    "id": "event-001",
    "title": "US Presidential Election 2028",
    "slug": "us-presidential-election-2028",
    "markets": [
        {
            "id": "m1",
            "question": "Will Democrat win?",
            "clobTokenIds": ["t1", "t2"],
            "outcomePrices": ["0.45", "0.55"],
            "volume24hr": "10000",
            "active": True,
            "acceptingOrders": True,
        },
    ],
}

MOCK_WALLET = {"usdc_e": "0.00", "usdc": "5.00", "pol": "2.94", "rpc_ok": True}
MOCK_COLLATERAL = {"name": "USDC.e", "address": "0x2791Bca1f2de4661ED88A30C99A7a9449Aa84174", "source": "on-chain"}


# ---------------------------------------------------------------------------
# Fixtures
# ---------------------------------------------------------------------------

@pytest.fixture
def mock_clob():
    clob = MagicMock()
    clob.get_balance_allowance.return_value = MOCK_BALANCE
    clob.get_open_orders.return_value = list(MOCK_ORDERS)
    # get_positions moved to Data API (client.get_positions), not on clob
    clob.get_trades.return_value = list(MOCK_TRADES)
    clob.get_order_book.return_value = MOCK_ORDER_BOOK
    clob.cancel_order.return_value = {"status": "ok"}
    clob.cancel_all.return_value = {"status": "ok"}
    return clob


@pytest.fixture
def mock_gamma():
    gamma = MagicMock()

    def _mock_get(path, params=None):
        resp = MagicMock()
        resp.status_code = 200
        if "/markets" in path:
            resp.json.return_value = list(MOCK_GAMMA_MARKETS)
        elif "/events" in path:
            resp.json.return_value = [MOCK_EVENT]
        else:
            resp.json.return_value = {}
        resp.raise_for_status = MagicMock()
        return resp

    gamma.get.side_effect = _mock_get
    return gamma


@pytest.fixture
def poly_patched(mock_clob, mock_gamma):
    patches = [
        patch("regard.venues.polymarket.commands.orient.get_clob_client", return_value=mock_clob),
        patch("regard.venues.polymarket.commands.orient.get_positions", return_value=list(MOCK_POSITIONS)),
        patch("regard.venues.polymarket.commands.orient._get_balance", return_value=dict(MOCK_BALANCE)),
        patch("regard.venues.polymarket.commands.orient.get_wallet_balances", return_value=dict(MOCK_WALLET)),
        patch("regard.venues.polymarket.commands.orient.get_collateral_token", return_value=dict(MOCK_COLLATERAL)),
        patch("regard.venues.polymarket.commands.research.get_clob_client", return_value=mock_clob),
        patch("regard.venues.polymarket.commands.research.get_gamma_client", return_value=mock_gamma),
        patch("regard.venues.polymarket.commands.review.get_clob_client", return_value=mock_clob),
        patch("regard.venues.polymarket.commands.act.get_clob_client", return_value=mock_clob),
        patch("regard.venues.polymarket.commands.act.get_gamma_client", return_value=mock_gamma),
        patch("regard.venues.polymarket.commands.act.get_web3", return_value=MagicMock()),
        patch("regard.venues.polymarket.commands.act.check_geo_block"),
    ]
    for p in patches:
        p.start()
    yield {"clob": mock_clob, "gamma": mock_gamma}
    for p in patches:
        p.stop()


def parse(result) -> dict:
    stdout = result.stdout.strip()
    assert "Traceback" not in stdout, f"Traceback leaked: {stdout[:300]}"
    return json.loads(stdout)


# ---------------------------------------------------------------------------
# Orient commands
# ---------------------------------------------------------------------------

class TestPolyStatus:
    def test_basic(self, poly_patched):
        result = runner.invoke(app, ["poly", "status"])
        d = parse(result)
        assert d["ok"] is True
        assert d["data"]["collateral_token"] == "USDC.e"
        assert d["data"]["open_order_count"] == 1

    def test_clob_failure_produces_json(self, poly_patched):
        poly_patched["clob"].get_open_orders.side_effect = Exception("CLOB down")
        result = runner.invoke(app, ["poly", "status"])
        d = parse(result)
        # Should still succeed — orders gracefully degrade to []
        assert d["ok"] is True
        assert d["data"]["open_order_count"] == 0


class TestPolyBalance:
    def test_basic(self, poly_patched):
        result = runner.invoke(app, ["poly", "balance"])
        d = parse(result)
        assert d["ok"] is True
        assert d["data"]["clob_balance"] == "500.00"


class TestPolyPositions:
    def test_basic(self, poly_patched):
        result = runner.invoke(app, ["poly", "positions"])
        d = parse(result)
        assert d["ok"] is True
        assert len(d["data"]) == 1
        assert d["data"][0]["pnl"] == "5.00"

    def test_empty(self, poly_patched):
        with patch("regard.venues.polymarket.commands.orient.get_positions", return_value=[]):
            result = runner.invoke(app, ["poly", "positions"])
        d = parse(result)
        assert d["ok"] is True
        assert d["data"] == []


class TestPolyOrders:
    def test_basic(self, poly_patched):
        result = runner.invoke(app, ["poly", "orders"])
        d = parse(result)
        assert d["ok"] is True
        assert len(d["data"]) == 1
        assert d["data"][0]["order_id"] == "order-001"


# ---------------------------------------------------------------------------
# Research commands
# ---------------------------------------------------------------------------

class TestPolyMarkets:
    def test_basic(self, poly_patched):
        result = runner.invoke(app, ["poly", "markets"])
        d = parse(result)
        assert d["ok"] is True
        assert len(d["data"]) >= 1
        assert "question" in d["data"][0]


class TestPolyMarket:
    def test_by_slug(self, poly_patched):
        result = runner.invoke(app, ["poly", "market", "btc-100k-2027"])
        d = parse(result)
        assert d["ok"] is True
        assert "question" in d["data"]

    def test_not_found(self, poly_patched):
        poly_patched["gamma"].get.side_effect = lambda *a, **kw: MagicMock(
            json=MagicMock(return_value=[]), status_code=200
        )
        result = runner.invoke(app, ["poly", "market", "nonexistent-market"])
        d = parse(result)
        assert d["ok"] is False
        assert d["error"]["code"] == "UNKNOWN_MARKET"


class TestPolyEvent:
    def test_by_slug(self, poly_patched):
        result = runner.invoke(app, ["poly", "event", "us-presidential-election-2028"])
        d = parse(result)
        assert d["ok"] is True
        assert "markets" in d["data"]
        assert d["data"]["market_count"] >= 1


class TestPolyPrices:
    def test_basic(self, poly_patched):
        result = runner.invoke(app, ["poly", "prices", "btc-100k-2027"])
        d = parse(result)
        assert d["ok"] is True
        assert "yes_price" in d["data"]


class TestPolyBook:
    def test_basic(self, poly_patched):
        result = runner.invoke(app, ["poly", "book", "btc-100k-2027"])
        d = parse(result)
        assert d["ok"] is True
        assert "bids" in d["data"]
        assert "asks" in d["data"]


# ---------------------------------------------------------------------------
# Review commands
# ---------------------------------------------------------------------------

class TestPolyTrades:
    def test_basic(self, poly_patched):
        result = runner.invoke(app, ["poly", "trades"])
        d = parse(result)
        assert d["ok"] is True
        assert len(d["data"]) == 1


# ---------------------------------------------------------------------------
# Act commands
# ---------------------------------------------------------------------------

class TestPolyOrder:
    """Poly order now creates proposals."""

    def test_limit_order_creates_proposal(self, poly_patched):
        """Limit buy on yes outcome creates a proposal with resolved params."""
        result = runner.invoke(app, ["poly", "order", "btc-100k-2027", "yes", "buy", "100", "0.55"])
        d = parse(result)
        assert d["ok"] is True
        assert d["data"]["status"] == "pending"
        assert d["data"]["venue"] == "poly"
        assert d["data"]["command"] == "order"
        assert d["data"]["params"]["outcome"] == "yes"
        assert d["data"]["params"]["side"] == "BUY"
        assert d["data"]["params"]["size"] == "100.0"
        assert d["data"]["params"]["price"] == "0.55"
        assert d["data"]["params"]["market_order"] is False
        assert d["data"]["params"]["token_id"] == "token-yes-001"
        assert d["data"]["params"]["market_slug"] == "btc-100k-2027"
        # mark_price is the market's current yes price (0.55), not the user's limit price
        assert d["data"]["checks"]["mark_price"] == "0.55"
        # CLOB should NOT be called (propose only)
        poly_patched["clob"].create_order.assert_not_called()
        poly_patched["clob"].post_order.assert_not_called()

    def test_market_order_creates_proposal(self, poly_patched):
        """Market buy creates proposal with market_order=True."""
        result = runner.invoke(app, ["poly", "order", "btc-100k-2027", "no", "buy", "50", "--market"])
        d = parse(result)
        assert d["ok"] is True
        assert d["data"]["status"] == "pending"
        assert d["data"]["params"]["outcome"] == "no"
        assert d["data"]["params"]["market_order"] is True

    def test_invalid_outcome(self, poly_patched):
        result = runner.invoke(app, ["poly", "order", "btc-100k-2027", "maybe", "buy", "100", "0.55"])
        d = parse(result)
        assert d["ok"] is False
        assert d["error"]["code"] == "INVALID_OUTCOME"

    def test_invalid_side(self, poly_patched):
        result = runner.invoke(app, ["poly", "order", "btc-100k-2027", "yes", "hold", "100", "0.55"])
        d = parse(result)
        assert d["ok"] is False
        assert d["error"]["code"] == "INVALID_SIDE"

    def test_missing_price_no_market(self, poly_patched):
        result = runner.invoke(app, ["poly", "order", "btc-100k-2027", "yes", "buy", "100"])
        d = parse(result)
        assert d["ok"] is False
        assert d["error"]["code"] == "MISSING_PRICE"

    def test_price_out_of_range(self, poly_patched):
        result = runner.invoke(app, ["poly", "order", "btc-100k-2027", "yes", "buy", "100", "1.5"])
        d = parse(result)
        assert d["ok"] is False
        assert d["error"]["code"] == "INVALID_PRICE"


class TestPolyMinOrderSize:
    """Minimum order size validation (per-market, from Gamma API)."""

    def test_below_min_rejected(self, poly_patched):
        """Order below market's orderMinSize → BELOW_MIN_SIZE."""
        result = runner.invoke(app, ["poly", "order", "btc-100k-2027", "yes", "buy", "1", "0.55"])
        d = parse(result)
        assert d["ok"] is False
        assert d["error"]["code"] == "BELOW_MIN_SIZE"
        assert "5" in d["error"]["message"]

    def test_at_min_accepted(self, poly_patched):
        """Order at exactly min size → proposal created."""
        result = runner.invoke(app, ["poly", "order", "btc-100k-2027", "yes", "buy", "5", "0.55"])
        d = parse(result)
        assert d["ok"] is True
        assert d["data"]["status"] == "pending"


class TestPolyPrecision:
    """Numeric precision validation — Article II compliance."""

    def test_fractional_shares_rejected(self, poly_patched):
        """Size must be a whole number of shares."""
        result = runner.invoke(app, ["poly", "order", "btc-100k-2027", "yes", "buy", "10.5", "0.55"])
        d = parse(result)
        assert d["ok"] is False
        assert d["error"]["code"] == "PRECISION_EXCEEDED"
        assert "whole number" in d["error"]["message"]

    def test_price_not_on_tick_rejected(self, poly_patched):
        """Price must be a multiple of tick_size (0.01 in mock)."""
        result = runner.invoke(app, ["poly", "order", "btc-100k-2027", "yes", "buy", "100", "0.555"])
        d = parse(result)
        assert d["ok"] is False
        assert d["error"]["code"] == "PRECISION_EXCEEDED"
        assert "tick size" in d["error"]["message"]

    def test_valid_precision_passes(self, poly_patched):
        """Correct precision passes through to proposal."""
        result = runner.invoke(app, ["poly", "order", "btc-100k-2027", "yes", "buy", "100", "0.55"])
        d = parse(result)
        assert d["ok"] is True
        assert d["data"]["status"] == "pending"


class TestPolyApprove:
    """Poly approve (on-chain token approvals) creates proposal."""

    def test_creates_proposal(self, poly_patched):
        """poly approve creates a proposal, does not call web3 or sign txs."""
        result = runner.invoke(app, ["poly", "approve"])
        d = parse(result)
        assert d["ok"] is True
        assert d["data"]["status"] == "pending"
        assert d["data"]["command"] == "approve"
        assert d["data"]["venue"] == "poly"
        # Exchange/web3 should NOT be called at propose time
        poly_patched["clob"].post_order.assert_not_called()


class TestPolyCancel:
    """Poly cancel/cancel-all now create proposals."""

    def test_cancel(self, poly_patched):
        result = runner.invoke(app, ["poly", "cancel", "order-001"])
        d = parse(result)
        assert d["ok"] is True
        assert d["data"]["status"] == "pending"
        assert d["data"]["command"] == "cancel"
        assert d["data"]["params"]["order_id"] == "order-001"
        # CLOB should NOT be called
        poly_patched["clob"].cancel_order.assert_not_called()

    def test_cancel_all(self, poly_patched):
        result = runner.invoke(app, ["poly", "cancel-all"])
        d = parse(result)
        assert d["ok"] is True
        assert d["data"]["status"] == "pending"
        assert d["data"]["command"] == "cancel-all"
        poly_patched["clob"].cancel_all.assert_not_called()


# ---------------------------------------------------------------------------
# Executor integration: approve → execute → CLOB called correctly
# ---------------------------------------------------------------------------


class TestPolyOrderExecutor:
    """Approve a poly order proposal → real executor fires → CLOB called."""

    def _approve_with_price_bypass(self, proposal_id, mark_price="0.55"):
        """Run approve with _fetch_current_price returning the same mark_price (delta=0)."""
        with patch("regard.main._fetch_current_price", return_value=mark_price):
            return runner.invoke(app, ["approve", proposal_id])

    def test_limit_order_executor(self, poly_patched):
        """Limit order: executor calls create_order + post_order(GTC)."""
        clob = poly_patched["clob"]
        clob.post_order.return_value = {"orderID": "oid-limit-1"}
        clob.create_order.return_value = {"signed": True}
        clob.get_balance_allowance.return_value = {"balance": "10000.00"}

        # 1. Propose
        result = runner.invoke(app, ["poly", "order", "btc-100k-2027", "yes", "buy", "100", "0.55"])
        d = parse(result)
        assert d["ok"] is True
        proposal_id = d["data"]["id"]

        # 2. Approve → executor fires
        result = self._approve_with_price_bypass(proposal_id)
        d = parse(result)
        assert d["ok"] is True
        assert d["data"]["order_id"] == "oid-limit-1"
        assert d["data"]["type"] == "GTC"
        assert d["data"]["side"] == "BUY"
        assert d["data"]["outcome"] == "yes"

        # 3. Verify CLOB was called
        clob.create_order.assert_called_once()
        args = clob.create_order.call_args[0][0]
        assert args.token_id == "token-yes-001"
        assert args.price == 0.55
        assert args.size == 100.0
        assert args.side == "BUY"
        clob.post_order.assert_called_once()

    def test_market_order_executor(self, poly_patched):
        """Market order: executor calls create_market_order + post_order(FOK)."""
        clob = poly_patched["clob"]
        clob.post_order.return_value = {"orderID": "oid-market-1"}
        clob.create_market_order.return_value = {"signed": True}
        clob.get_balance_allowance.return_value = {"balance": "10000.00"}

        result = runner.invoke(app, ["poly", "order", "btc-100k-2027", "yes", "buy", "100", "--market"])
        d = parse(result)
        proposal_id = d["data"]["id"]

        result = self._approve_with_price_bypass(proposal_id)
        d = parse(result)
        assert d["ok"] is True
        assert d["data"]["type"] == "FOK"
        assert d["data"]["order_id"] == "oid-market-1"

        clob.create_market_order.assert_called_once()
        args = clob.create_market_order.call_args[0][0]
        assert args.token_id == "token-yes-001"
        assert args.amount == 100.0
        assert args.side == "BUY"
        clob.create_order.assert_not_called()

    def test_insufficient_balance_rejects(self, poly_patched):
        """BUY order with insufficient balance → INSUFFICIENT_BALANCE before CLOB call."""
        clob = poly_patched["clob"]
        clob.get_balance_allowance.return_value = {"balance": "10.00"}

        result = runner.invoke(app, ["poly", "order", "btc-100k-2027", "yes", "buy", "100", "0.55"])
        d = parse(result)
        proposal_id = d["data"]["id"]

        result = self._approve_with_price_bypass(proposal_id)
        d = parse(result)
        assert d["ok"] is False
        assert d["error"]["code"] == "INSUFFICIENT_BALANCE"
        clob.get_balance_allowance.assert_called()  # verify balance path was reached
        clob.create_order.assert_not_called()
        clob.post_order.assert_not_called()

    def test_precision_rejected_at_approve_time(self, poly_patched):
        """Tampered proposal with fractional shares → rejected at executor."""
        # Create a valid proposal, then tamper with the params
        result = runner.invoke(app, ["poly", "order", "btc-100k-2027", "yes", "buy", "100", "0.55"])
        d = parse(result)
        proposal_id = d["data"]["id"]

        # Read, tamper size to fractional, write back
        import json as _json
        import os

        from regard.core.proposal import get_workspace_dir
        ws = get_workspace_dir()
        pending_dir = os.path.join(ws, "pending")
        pf = os.path.join(pending_dir, f"{proposal_id}.json")
        with open(pf) as f:
            prop = _json.load(f)
        prop["params"]["size"] = 10.5
        with open(pf, "w") as f:
            _json.dump(prop, f)

        result = self._approve_with_price_bypass(proposal_id)
        d = parse(result)
        assert d["ok"] is False
        assert d["error"]["code"] == "PRECISION_EXCEEDED"


class TestPolyCancelExecutor:
    """Approve a poly cancel proposal → executor calls clob.cancel_order."""

    def test_cancel_executor(self, poly_patched):
        clob = poly_patched["clob"]
        clob.cancel_order.return_value = {"status": "ok", "order_id": "order-001"}

        result = runner.invoke(app, ["poly", "cancel", "order-001"])
        d = parse(result)
        proposal_id = d["data"]["id"]

        result = runner.invoke(app, ["approve", proposal_id])
        d = parse(result)
        assert d["ok"] is True
        assert d["data"]["order_id"] == "order-001"

        from py_clob_client_v2.clob_types import OrderPayload
        clob.cancel_order.assert_called_once_with(OrderPayload(orderID="order-001"))

    def test_cancel_failure(self, poly_patched):
        """CLOB cancel raises → CANCEL_FAILED error."""
        clob = poly_patched["clob"]
        clob.cancel_order.side_effect = Exception("order not found")

        result = runner.invoke(app, ["poly", "cancel", "order-001"])
        d = parse(result)
        proposal_id = d["data"]["id"]

        result = runner.invoke(app, ["approve", proposal_id])
        d = parse(result)
        assert d["ok"] is False
        assert d["error"]["code"] == "CANCEL_FAILED"


class TestPolyCancelAllExecutor:
    """Approve a poly cancel-all proposal → executor calls clob.cancel_all."""

    def test_cancel_all_executor(self, poly_patched):
        clob = poly_patched["clob"]
        clob.cancel_all.return_value = {"status": "ok", "cancelled": 3}

        result = runner.invoke(app, ["poly", "cancel-all"])
        d = parse(result)
        proposal_id = d["data"]["id"]

        result = runner.invoke(app, ["approve", proposal_id])
        d = parse(result)
        assert d["ok"] is True
        assert d["data"]["response"]["cancelled"] == 3

        clob.cancel_all.assert_called_once()

    def test_cancel_all_failure(self, poly_patched):
        """CLOB cancel_all raises → CANCEL_FAILED error."""
        clob = poly_patched["clob"]
        clob.cancel_all.side_effect = Exception("service unavailable")

        result = runner.invoke(app, ["poly", "cancel-all"])
        d = parse(result)
        proposal_id = d["data"]["id"]

        result = runner.invoke(app, ["approve", proposal_id])
        d = parse(result)
        assert d["ok"] is False
        assert d["error"]["code"] == "CANCEL_FAILED"


# ---------------------------------------------------------------------------
# Contract: all poly commands produce valid JSON
# ---------------------------------------------------------------------------

POLY_COMMANDS = [
    ["poly", "status"],
    ["poly", "balance"],
    ["poly", "positions"],
    ["poly", "orders"],
    ["poly", "markets"],
    ["poly", "market", "btc-100k-2027"],
    ["poly", "event", "us-presidential-election-2028"],
    ["poly", "prices", "btc-100k-2027"],
    ["poly", "book", "btc-100k-2027"],
    ["poly", "trades"],
    ["poly", "cancel", "order-001"],
    ["poly", "cancel-all"],
]


@pytest.mark.parametrize("args", POLY_COMMANDS, ids=lambda a: " ".join(a))
def test_poly_contract(poly_patched, args):
    """Every poly command must produce valid JSON."""
    result = runner.invoke(app, args)
    d = parse(result)
    assert "ok" in d
