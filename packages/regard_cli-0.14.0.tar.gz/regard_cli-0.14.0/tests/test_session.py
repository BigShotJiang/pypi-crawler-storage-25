"""Session command tests — transcript parsing, trade extraction, tilt.

Creates mock JSONL transcripts and tests that session commands
correctly parse trades, research chains, and session context.
"""

import json
import os
from datetime import datetime, timezone
from unittest.mock import patch

import pytest
from typer.testing import CliRunner

from regard.commands.session import (
    _extract_entries,
    _extract_research,
    _extract_trades,
    _find_gg_handoffs,
    _parse_hl_order,
    _parse_time_modifier,
)
from regard.main import app

runner = CliRunner()


# ---------------------------------------------------------------------------
# Mock transcript data
# ---------------------------------------------------------------------------

def _ts(hour=10, minute=0):
    return datetime(2026, 3, 31, hour, minute, 0, tzinfo=timezone.utc).isoformat()


def _user_entry(text, hour=10, minute=0):
    return json.dumps({
        "type": "user",
        "timestamp": _ts(hour, minute),
        "message": {"content": text},
    })


def _assistant_entry(text, hour=10, minute=1):
    return json.dumps({
        "type": "assistant",
        "timestamp": _ts(hour, minute),
        "message": {"content": [{"type": "text", "text": text}]},
    })


def _tool_use_entry(name, inp, hour=10, minute=2):
    return json.dumps({
        "type": "assistant",
        "timestamp": _ts(hour, minute),
        "message": {"content": [{"type": "tool_use", "name": name, "input": inp}]},
    })


def _tool_result_entry(content, hour=10, minute=3):
    return json.dumps({
        "type": "user",
        "timestamp": _ts(hour, minute),
        "message": {"content": [{"type": "tool_result", "content": content}]},
    })


MOCK_TRANSCRIPT = "\n".join([
    _user_entry("let's look at BTC", 10, 0),
    _assistant_entry("Looking at BTC. Let me check the market.", 10, 1),
    _tool_use_entry("Bash", {"command": "regard hl order BTC buy 0.1 65000"}, 10, 5),
    _tool_result_entry(json.dumps({"ok": True, "data": {"status": "filled", "oid": 12345, "avg_price": "65000.0"}}), 10, 6),
    _assistant_entry("Order filled at 65000.", 10, 7),
    _user_entry("now check ETH funding", 10, 10),
    _tool_use_entry("Skill", {"skill": "chans-research"}, 10, 15),
    _tool_result_entry("Some 4chan research results", 10, 16),
    _tool_use_entry("WebSearch", {"query": "ETH funding rate"}, 10, 20),
    _tool_result_entry("Search results", 10, 21),
    _tool_use_entry("Bash", {"command": "regard hl order ETH sell 1.0 --market --reduce-only"}, 11, 0),
    _tool_result_entry(json.dumps({"ok": True, "data": {"status": "filled", "oid": 12346, "avg_price": "3250.0"}}), 11, 1),
]) + "\n"


@pytest.fixture
def mock_session_dir(tmp_path):
    """Create a mock session directory with a transcript file."""
    session_dir = tmp_path / ".claude" / "projects" / "-test-cwd"
    session_dir.mkdir(parents=True)
    transcript = session_dir / "a1b2c3d4-e5f6-7890-abcd-ef1234567890.jsonl"
    transcript.write_text(MOCK_TRANSCRIPT)
    return session_dir


# ---------------------------------------------------------------------------
# Unit tests — parsing functions
# ---------------------------------------------------------------------------

class TestExtractEntries:
    def test_basic(self, mock_session_dir):
        files = list(mock_session_dir.glob("*.jsonl"))
        entries = _extract_entries(str(files[0]))
        assert len(entries) > 0
        # Should have user, assistant, tool_use, and tool_result entries
        roles = {r for _, r, _ in entries}
        assert "U" in roles
        assert "A" in roles
        assert "T" in roles
        assert "R" in roles

    def test_malformed_lines_skipped(self, tmp_path):
        f = tmp_path / "test.jsonl"
        f.write_text("not json\n{}\n" + _user_entry("hello") + "\n")
        entries = _extract_entries(str(f))
        assert len(entries) == 1
        assert entries[0][2] == "hello"

    def test_empty_file(self, tmp_path):
        f = tmp_path / "empty.jsonl"
        f.write_text("")
        entries = _extract_entries(str(f))
        assert entries == []


class TestExtractTrades:
    def test_finds_trades(self, mock_session_dir):
        files = list(mock_session_dir.glob("*.jsonl"))
        entries = _extract_entries(str(files[0]))
        trades = _extract_trades(entries)
        assert len(trades) == 2
        assert trades[0]["asset"] == "BTC"
        assert trades[0]["side"] == "buy"
        assert trades[0]["size"] == "0.1"
        assert trades[1]["asset"] == "ETH"
        assert trades[1]["side"] == "sell"
        assert trades[1]["reduce_only"] is True

    def test_trade_result_parsed(self, mock_session_dir):
        files = list(mock_session_dir.glob("*.jsonl"))
        entries = _extract_entries(str(files[0]))
        trades = _extract_trades(entries)
        assert trades[0].get("result", {}).get("status") == "filled"
        assert trades[0]["result"]["avg_price"] == "65000.0"


class TestExtractResearch:
    def test_finds_research_skills(self, mock_session_dir):
        files = list(mock_session_dir.glob("*.jsonl"))
        entries = _extract_entries(str(files[0]))
        research = _extract_research(entries)
        assert len(research) >= 2
        skills = [r["skill"] for r in research]
        assert "chans-research" in skills
        assert "WebSearch" in skills


class TestParseHlOrder:
    def test_limit_order(self):
        result = _parse_hl_order("regard hl order BTC buy 0.1 65000")
        assert result["asset"] == "BTC"
        assert result["side"] == "buy"
        assert result["size"] == "0.1"
        assert result["price"] == "65000"
        assert result["market"] is False

    def test_market_order(self):
        result = _parse_hl_order("regard hl order ETH sell 1.0 --market")
        assert result["asset"] == "ETH"
        assert result["side"] == "sell"
        assert result["market"] is True
        assert result["price"] is None

    def test_reduce_only(self):
        result = _parse_hl_order("regard hl order ETH sell 1.0 --market --reduce-only")
        assert result["reduce_only"] is True

    def test_too_short(self):
        result = _parse_hl_order("regard hl order BTC")
        assert result is None

    def test_hip3_asset(self):
        result = _parse_hl_order("regard hl order xyz:NATGAS sell 12 2.85")
        assert result["asset"] == "xyz:NATGAS"
        assert result["price"] == "2.85"


class TestParseTimeModifier:
    def test_default(self):
        start, end = _parse_time_modifier(None)
        assert start.hour == 0
        assert end > start

    def test_days(self):
        start, end = _parse_time_modifier("5d")
        assert (end - start).days >= 4

    def test_weeks(self):
        start, end = _parse_time_modifier("2w")
        assert (end - start).days >= 13

    def test_max(self):
        start, end = _parse_time_modifier("max")
        assert start.year == 1  # datetime.min

    def test_ytd(self):
        start, end = _parse_time_modifier("ytd")
        assert start.month == 1
        assert start.day == 1

    def test_date_range(self):
        start, end = _parse_time_modifier("03/10-03/17")
        assert start.month == 3
        assert start.day == 10
        assert end.day == 17


# ---------------------------------------------------------------------------
# Integration tests — CLI invocation with mocked session dir
# ---------------------------------------------------------------------------

@pytest.fixture
def session_env(mock_session_dir):
    """Patch session discovery to use mock dir."""
    cwd = "/test-cwd"
    with patch("regard.commands.session._get_session_base_path", return_value=str(mock_session_dir)):
        yield


class TestSessionCLI:
    def test_ctx_produces_json(self, session_env):
        result = runner.invoke(app, ["session", "ctx"])
        stdout = result.stdout.strip()
        assert "Traceback" not in stdout
        # ctx outputs JSON
        assert result.exit_code == 0

    def test_no_session_produces_json_error(self):
        with patch("regard.commands.session._get_session_base_path", return_value=None):
            result = runner.invoke(app, ["session", "ctx"])
            stdout = result.stdout.strip()
            data = json.loads(stdout)
            assert data["ok"] is False
            assert data["error"]["code"] == "NO_SESSION_DIR"

    def test_gm_no_session_produces_json(self):
        with patch("regard.commands.session._get_session_base_path", return_value=None):
            result = runner.invoke(app, ["session", "gm"])
            stdout = result.stdout.strip()
            data = json.loads(stdout)
            assert data["ok"] is True
            assert data["data"]["source"] == "none"

    def test_gg_no_session_produces_json(self):
        with patch("regard.commands.session._get_session_base_path", return_value=None):
            result = runner.invoke(app, ["session", "gg"])
            stdout = result.stdout.strip()
            data = json.loads(stdout)
            assert data["ok"] is False

    def test_gg_produces_structured_json(self, session_env):
        """gg should output structured JSON with trades, research, messages."""
        result = runner.invoke(app, ["session", "gg"])
        stdout = result.stdout.strip()
        data = json.loads(stdout)
        assert data["ok"] is True
        d = data["data"]
        assert "trades" in d
        assert "trade_count" in d
        assert "research" in d
        assert "user_messages" in d
        assert "assistant_messages" in d
        assert "time_range" in d
        assert d["trade_count"] == len(d["trades"])
        # Our mock transcript has 2 trades
        assert d["trade_count"] == 2
        # Each trade should have context
        for trade in d["trades"]:
            assert "asset" in trade
            assert "side" in trade
            assert "context" in trade

    def test_gm_with_transcript_fallback(self, session_env):
        """gm with no handoff should fall back to transcript reconstruction."""
        with patch("regard.commands.session._find_gg_handoffs", return_value=[]):
            result = runner.invoke(app, ["session", "gm"])
            stdout = result.stdout.strip()
            data = json.loads(stdout)
            assert data["ok"] is True
            d = data["data"]
            assert d["source"] == "transcript"
            assert len(d["transcript_trades"]) == 2
            assert d["handoff"] is None

    def test_cope_no_args_produces_json_error(self, session_env):
        """cope without assets should produce a structured error."""
        result = runner.invoke(app, ["session", "cope"])
        stdout = result.stdout.strip()
        data = json.loads(stdout)
        assert data["ok"] is False
        assert data["error"]["code"] == "MISSING_ARGUMENT"

    def test_cope_finds_trade_in_transcript(self, session_env):
        """cope should find BTC trade context from transcript."""
        with patch("regard.commands.session._find_gg_handoffs", return_value=[]):
            result = runner.invoke(app, ["session", "cope", "BTC"])
            stdout = result.stdout.strip()
            data = json.loads(stdout)
            assert data["ok"] is True
            results = data["data"]
            assert len(results) == 1
            assert results[0]["asset"] == "BTC"
            assert results[0]["source"] == "transcript"
            assert results[0]["trade"] is not None
            assert results[0]["trade"]["side"] == "buy"


# ---------------------------------------------------------------------------
# Handoff doc tests — gg/handoffs/ and gg/research/ workflow
# ---------------------------------------------------------------------------

class TestHandoffDocs:
    def test_find_gg_handoffs_empty(self, tmp_path):
        """No gg dir → empty list."""
        with patch("regard.commands.session.Path.cwd", return_value=tmp_path):
            assert _find_gg_handoffs() == []

    def test_find_gg_handoffs_returns_newest_first(self, tmp_path):
        """Handoff files should be sorted newest first."""
        hdir = tmp_path / "gg" / "handoffs"
        hdir.mkdir(parents=True)
        # Create two handoffs with different mtimes
        old = hdir / "2026-03-30-old.md"
        old.write_text("# Old session")
        new = hdir / "2026-03-31-new.md"
        new.write_text("# New session")
        # Force mtime ordering
        os.utime(old, (1000000, 1000000))
        os.utime(new, (2000000, 2000000))
        with patch("regard.commands.session.Path.cwd", return_value=tmp_path):
            handoffs = _find_gg_handoffs()
            assert len(handoffs) == 2
            assert "new" in handoffs[0]
            assert "old" in handoffs[1]

    def test_gm_reads_handoff_doc(self, tmp_path, mock_session_dir):
        """gm with a handoff doc should return source=handoff and full content."""
        hdir = tmp_path / "gg" / "handoffs"
        hdir.mkdir(parents=True)
        handoff = hdir / "2026-03-31-test.md"
        handoff_content = "# Test Handoff\n\n## Positions\nShort NATGAS @ 2.88"
        handoff.write_text(handoff_content)

        with patch("regard.commands.session._get_session_base_path", return_value=str(mock_session_dir)), \
             patch("regard.commands.session.Path.cwd", return_value=tmp_path):
            result = runner.invoke(app, ["session", "gm"])
            stdout = result.stdout.strip()
            data = json.loads(stdout)
            assert data["ok"] is True
            d = data["data"]
            assert d["source"] == "handoff"
            assert d["handoff"] == handoff_content
            assert d["handoff_path"] == str(handoff)
            assert len(d["all_handoffs"]) == 1

    def test_cope_finds_asset_in_handoff(self, tmp_path, mock_session_dir):
        """cope should find an asset mentioned in a handoff doc."""
        hdir = tmp_path / "gg" / "handoffs"
        hdir.mkdir(parents=True)
        handoff = hdir / "2026-03-31-natgas.md"
        handoff.write_text("# Handoff\n\n## xyz:NATGAS short\nThesis: lower highs")

        with patch("regard.commands.session._get_session_base_path", return_value=str(mock_session_dir)), \
             patch("regard.commands.session.Path.cwd", return_value=tmp_path):
            result = runner.invoke(app, ["session", "cope", "NATGAS"])
            stdout = result.stdout.strip()
            data = json.loads(stdout)
            assert data["ok"] is True
            results = data["data"]
            assert len(results) == 1
            assert results[0]["asset"] == "NATGAS"
            assert results[0]["source"] in ("handoff", "transcript")
            if results[0]["source"] == "handoff":
                assert results[0]["handoff"] is not None
                assert "lower highs" in results[0]["handoff"]["content"]

    def test_cope_asset_not_in_handoff_falls_back(self, tmp_path, mock_session_dir):
        """cope for an asset NOT in the handoff should fall back to transcript or none."""
        hdir = tmp_path / "gg" / "handoffs"
        hdir.mkdir(parents=True)
        handoff = hdir / "2026-03-31-test.md"
        handoff.write_text("# Handoff\n\nOnly mentions NATGAS")

        with patch("regard.commands.session._get_session_base_path", return_value=str(mock_session_dir)), \
             patch("regard.commands.session.Path.cwd", return_value=tmp_path):
            result = runner.invoke(app, ["session", "cope", "SOL"])
            stdout = result.stdout.strip()
            data = json.loads(stdout)
            assert data["ok"] is True
            results = data["data"]
            assert results[0]["asset"] == "SOL"
            # SOL not in handoff and not in mock trades → none or transcript
            assert results[0]["handoff"] is None


# ---------------------------------------------------------------------------
# pnl / tilt / what — structured JSON output tests
# ---------------------------------------------------------------------------

class TestPnlTiltWhat:
    def test_pnl_produces_json(self, session_env):
        """pnl should output structured JSON with trades and range."""
        result = runner.invoke(app, ["session", "pnl"])
        stdout = result.stdout.strip()
        data = json.loads(stdout)
        assert data["ok"] is True
        d = data["data"]
        assert "range" in d
        assert "trade_count" in d
        assert "trades" in d
        assert "balance_checks" in d
        assert "time_range" in d
        assert d["range"] == "1d"

    def test_pnl_with_modifier(self, session_env):
        """pnl 5d should use the correct range."""
        result = runner.invoke(app, ["session", "pnl", "5d"])
        stdout = result.stdout.strip()
        data = json.loads(stdout)
        assert data["ok"] is True
        assert data["data"]["range"] == "5d"

    def test_tilt_produces_json(self, session_env):
        """tilt should output structured JSON with level and health."""
        result = runner.invoke(app, ["session", "tilt"])
        stdout = result.stdout.strip()
        data = json.loads(stdout)
        assert data["ok"] is True
        d = data["data"]
        assert "level" in d
        assert "session_health" in d
        assert "trades_today" in d
        assert "indicators" in d
        assert d["level"] in ("GREEN", "YELLOW", "ORANGE", "RED")
        assert isinstance(d["session_health"], int)

    def test_what_produces_json(self, session_env):
        """what should output structured JSON with timeline."""
        result = runner.invoke(app, ["session", "what"])
        stdout = result.stdout.strip()
        data = json.loads(stdout)
        assert data["ok"] is True
        d = data["data"]
        assert "total_entries" in d
        assert "trade_count" in d
        assert "research_count" in d
        assert "timeline" in d
        assert isinstance(d["timeline"], list)
        # Timeline entries should have role and text
        for entry in d["timeline"]:
            assert "role" in entry
            assert "text" in entry

    def test_ctx_produces_json(self, session_env):
        """ctx should output structured JSON with estimated_tokens."""
        result = runner.invoke(app, ["session", "ctx"])
        stdout = result.stdout.strip()
        data = json.loads(stdout)
        assert data["ok"] is True
        assert "estimated_tokens" in data["data"]
        assert isinstance(data["data"]["estimated_tokens"], int)
