"""Golden fixture validation — validates recorded API responses against Pydantic models.

Uses extra="forbid" so any new or renamed field from the exchange causes a test
failure, forcing the model to be updated. This is the ratchet: schema drift is
caught here, not in production.

Run `python tests/record_fixtures.py` to refresh fixtures from the real API.
"""

import json
from pathlib import Path

import pytest
from pydantic import BaseModel, ConfigDict

from regard.venues.hyperliquid.models import (
    ActiveAssetData,
    AssetCtx,
    AssetInfo,
    Candle,
    Fill,
    FrontendOrder,
    FundingEntry,
    L2Snapshot,
    PerpDexInfo,
    PerpMetaEntry,
    SpotBalance,
    SpotMeta,
    UserState,
)

FIXTURES_DIR = Path(__file__).parent / "fixtures"


def _load(venue: str, name: str):
    return json.loads((FIXTURES_DIR / venue / f"{name}.json").read_text())


def _strict(model_cls, _cache=None):
    """Create a strict subclass that rejects unknown fields — recursively.

    All nested BaseModel fields also get extra="forbid" so unknown fields at
    any depth cause a validation error, not just top-level.
    """
    if _cache is None:
        _cache = {}
    if model_cls in _cache:
        return _cache[model_cls]

    # Build strict versions of all nested model fields first
    strict_annotations = {}
    for field_name, field_info in model_cls.model_fields.items():
        annotation = field_info.annotation
        # Handle direct BaseModel subclass references
        if isinstance(annotation, type) and issubclass(annotation, BaseModel):
            strict_annotations[field_name] = _strict(annotation, _cache)

    # Create strict subclass
    namespace = {"model_config": ConfigDict(extra="forbid"), "__annotations__": strict_annotations}
    StrictModel = type(f"Strict{model_cls.__name__}", (model_cls,), namespace)
    _cache[model_cls] = StrictModel
    return StrictModel


# Skip all tests if fixtures haven't been recorded yet
pytestmark = pytest.mark.skipif(
    not (FIXTURES_DIR / "hyperliquid" / "all_mids.json").exists(),
    reason="Golden fixtures not recorded — run: python tests/record_fixtures.py",
)


# --- Hyperliquid ---


class TestUserState:
    def test_validates(self):
        data = _load("hyperliquid", "user_state")
        _strict(UserState).model_validate(data)

    def test_has_asset_positions(self):
        data = _load("hyperliquid", "user_state")
        state = UserState.model_validate(data)
        # Real accounts have positions — fixture should capture this
        assert isinstance(state.assetPositions, list)

    def test_margin_summary_present(self):
        data = _load("hyperliquid", "user_state")
        state = UserState.model_validate(data)
        assert state.crossMarginSummary is not None or state.marginSummary is not None


class TestFrontendOrders:
    def test_validates(self):
        data = _load("hyperliquid", "frontend_open_orders")
        Strict = _strict(FrontendOrder)
        for order in data:
            Strict.model_validate(order)

    def test_trigger_fields_always_present(self):
        """Regression: real API returns triggerPx and isTrigger on ALL orders,
        including non-trigger orders where triggerPx is '0.0'."""
        data = _load("hyperliquid", "frontend_open_orders")
        for order in data:
            assert "triggerPx" in order, "triggerPx missing — real API always includes it"
            assert "isTrigger" in order, "isTrigger missing — real API always includes it"

    def test_non_trigger_order_has_triggerPx_zero(self):
        """Regression: non-trigger orders have triggerPx='0.0' (truthy string)."""
        data = _load("hyperliquid", "frontend_open_orders")
        non_triggers = [o for o in data if not o.get("isTrigger")]
        if non_triggers:
            for o in non_triggers:
                assert o["triggerPx"] == "0.0"


class TestMetaAndAssetCtxs:
    def test_meta_validates(self):
        data = _load("hyperliquid", "meta_and_asset_ctxs")
        meta = data[0] if isinstance(data, list) else data
        Strict = _strict(AssetInfo)
        for asset in meta.get("universe", [])[:5]:
            Strict.model_validate(asset)

    def test_asset_ctxs_validate(self):
        data = _load("hyperliquid", "meta_and_asset_ctxs")
        ctxs = data[1] if isinstance(data, list) and len(data) > 1 else []
        Strict = _strict(AssetCtx)
        for ctx in ctxs[:5]:
            Strict.model_validate(ctx)


class TestSpotMeta:
    def test_validates(self):
        data = _load("hyperliquid", "spot_meta")
        _strict(SpotMeta).model_validate(data)


class TestPerpDexs:
    def test_first_is_none(self):
        """perpDexs[0] is None on mainnet (the default dex)."""
        data = _load("hyperliquid", "perp_dexs")
        assert data[0] is None

    def test_non_null_validate(self):
        data = _load("hyperliquid", "perp_dexs")
        Strict = _strict(PerpDexInfo)
        for dex in data:
            if dex is not None:
                Strict.model_validate(dex)


class TestAllPerpMetas:
    def test_validates(self):
        data = _load("hyperliquid", "all_perp_metas")
        Strict = _strict(PerpMetaEntry)
        for meta in data[:3]:
            Strict.model_validate(meta)


class TestL2Snapshot:
    def test_validates(self):
        data = _load("hyperliquid", "l2_snapshot")
        _strict(L2Snapshot).model_validate(data)


class TestFundingHistory:
    def test_validates(self):
        data = _load("hyperliquid", "funding_history")
        Strict = _strict(FundingEntry)
        for entry in data[:5]:
            Strict.model_validate(entry)


class TestCandles:
    def test_validates(self):
        data = _load("hyperliquid", "candles")
        Strict = _strict(Candle)
        for candle in data[:5]:
            Strict.model_validate(candle)


class TestFills:
    def test_validates(self):
        data = _load("hyperliquid", "user_fills")
        Strict = _strict(Fill)
        for fill in data[:5]:
            Strict.model_validate(fill)


class TestSpotBalance:
    def test_validates(self):
        data = _load("hyperliquid", "spot_user_state")
        Strict = _strict(SpotBalance)
        for bal in data.get("balances", [])[:5]:
            Strict.model_validate(bal)


class TestActiveAssetData:
    def test_validates(self):
        data = _load("hyperliquid", "active_asset_data")
        _strict(ActiveAssetData).model_validate(data)


class TestXyzMeta:
    """HIP-3 dex-scoped metaAndAssetCtxs — may have extra fields like growthMode."""

    @pytest.mark.skipif(
        not (FIXTURES_DIR / "hyperliquid" / "meta_and_asset_ctxs_xyz.json").exists(),
        reason="xyz dex fixture not recorded",
    )
    def test_validates(self):
        data = _load("hyperliquid", "meta_and_asset_ctxs_xyz")
        meta = data[0] if isinstance(data, list) else data
        Strict = _strict(AssetInfo)
        for asset in meta.get("universe", [])[:5]:
            Strict.model_validate(asset)


class TestPerpAnnotations:
    """perpConciseAnnotations returns [[asset_name, {category: str}], ...]."""

    def test_is_list_of_pairs(self):
        data = _load("hyperliquid", "perp_annotations")
        assert isinstance(data, list)
        assert len(data) > 0, "annotations fixture is empty"
        # Each entry is [asset_name, annotation_dict]
        for entry in data[:5]:
            assert isinstance(entry, list) and len(entry) == 2
            assert isinstance(entry[0], str)
            assert isinstance(entry[1], dict)


class TestAllMids:
    def test_is_dict_of_string_prices(self):
        data = _load("hyperliquid", "all_mids")
        assert isinstance(data, dict)
        assert len(data) > 0
        for coin, price in list(data.items())[:5]:
            assert isinstance(coin, str)
            assert isinstance(price, str)
            float(price)  # must be parseable as float
