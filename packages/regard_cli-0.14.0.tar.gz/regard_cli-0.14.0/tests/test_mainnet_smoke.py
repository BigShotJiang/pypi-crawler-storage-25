"""Mainnet smoke tests — real API, dust amounts, no mocks.

These tests hit the real Hyperliquid mainnet API to verify integration
boundaries that mocked tests cannot cover. They use read-only calls
(zero cost) and dust-amount writes (~$0.01).

Run manually: pytest tests/test_mainnet_smoke.py -v
NOT part of pre-commit or CI — requires HYPERLIQUID_AGENT_KEY or
HYPERLIQUID_PRIVATE_KEY set in env or ~/.claude/settings.local.json.

Marker: @pytest.mark.mainnet — skipped unless --mainnet flag is passed.
"""

import json
import os

import pytest

from regard.venues.hyperliquid.client import (
    get_account_mode,
    get_address,
    get_all_mids,
    get_all_perp_metas,
    get_collateral_map,
    get_dex_balances,
    get_info,
    get_spot_balances,
)
from regard.venues.hyperliquid.resolver import Resolver

# ---------------------------------------------------------------------------
# Skip unless --mainnet flag and credentials present
# ---------------------------------------------------------------------------

def _has_credentials() -> bool:
    """Check if trading credentials are available (env or settings file)."""
    if os.environ.get("HYPERLIQUID_AGENT_KEY") or os.environ.get("HYPERLIQUID_PRIVATE_KEY"):
        return True
    try:
        from pathlib import Path
        settings = Path.home() / ".claude" / "settings.local.json"
        if settings.exists():
            env = json.loads(settings.read_text()).get("env", {})
            return bool(env.get("HYPERLIQUID_AGENT_KEY") or env.get("HYPERLIQUID_PRIVATE_KEY"))
    except Exception:
        pass
    return False


# ---------------------------------------------------------------------------
# Fixtures
# ---------------------------------------------------------------------------

@pytest.fixture(scope="module")
def info():
    """Real Info client — shared across module to avoid repeated metadata fetches."""
    if not _has_credentials():
        pytest.skip("No Hyperliquid credentials available")
    return get_info()


@pytest.fixture(scope="module")
def address():
    if not _has_credentials():
        pytest.skip("No Hyperliquid credentials available")
    return get_address()


# ---------------------------------------------------------------------------
# Read-only tests (zero cost, no state changes)
# ---------------------------------------------------------------------------

@pytest.mark.mainnet
class TestAssetResolution:
    """Verify the Resolver works with real SDK state (the cold-start path)."""

    def test_default_perp_resolves(self, info):
        r = Resolver(info)
        assert r.resolve("BTC") == "BTC"
        assert r.resolve("ETH") == "ETH"

    def test_hip3_full_name_resolves(self, info):
        """xyz:TSLA must resolve after lazy-loading HIP-3 metadata."""
        r = Resolver(info)
        result = r.resolve("xyz:TSLA")
        assert result == "xyz:TSLA"
        assert "xyz:TSLA" in info.coin_to_asset

    def test_hip3_ambiguous_short_name_errors(self, info):
        """Bare 'TSLA' exists on multiple dexes — must error, not silently pick one."""
        r = Resolver(info)
        with pytest.raises(SystemExit):
            r.resolve("TSLA")  # xyz:TSLA, flx:TSLA, km:TSLA, cash:TSLA

    def test_hip3_unique_short_name_resolves(self, info):
        """A short name that exists on only one dex should resolve."""
        r = Resolver(info)
        # BTCD only exists on para
        result = r.resolve("BTCD")
        assert result == "para:BTCD"

    def test_case_insensitive(self, info):
        r = Resolver(info)
        assert r.resolve("btc") == "BTC"
        assert r.resolve("xyz:tsla") == "xyz:TSLA"


@pytest.mark.mainnet
class TestSpotBalances:
    """Verify spot balance parsing against real API response shapes."""

    def test_spot_balances_parse(self, info, address):
        """Real spot_user_state response has 'token' key, not 'coin'."""
        balances = get_spot_balances(info, address)
        # Should return a list (possibly empty if no spot holdings)
        assert isinstance(balances, list)
        for bal in balances:
            assert "token" in bal
            assert "balance" in bal
            assert "token_index" in bal
            # Balance should be a parseable number string
            float(bal["balance"])

    def test_spot_balance_token_names_are_strings(self, info, address):
        """Token names should be readable strings, not indices."""
        balances = get_spot_balances(info, address)
        for bal in balances:
            assert isinstance(bal["token"], str)
            assert len(bal["token"]) > 0


@pytest.mark.mainnet
class TestAccountMode:
    """Verify account mode detection works with real API."""

    def test_account_mode_is_valid(self, info, address):
        mode = get_account_mode(info, address)
        assert mode in ("default", "unifiedAccount", "portfolioMargin")


@pytest.mark.mainnet
class TestCollateralMap:
    """Verify collateral map resolves correctly from real API data."""

    def test_default_dex_is_usdc(self, info):
        coll_map = get_collateral_map(info)
        # Default dex key is "" (empty string), not "default"
        assert coll_map[""][0] == "USDC"
        assert coll_map[""][1] == 0

    def test_non_usdc_dexes_resolve(self, info):
        """Known non-USDC dexes should resolve to their actual collateral."""
        coll_map = get_collateral_map(info)
        # These are known from the HL protocol
        known_collateral = {
            "flx": "USDH",
            "vntl": "USDH",
            "km": "USDH",
            "hyna": "USDE",
            "cash": "USDT0",
        }
        matched = 0
        for dex, expected_token in known_collateral.items():
            if dex in coll_map:
                matched += 1
                actual_token = coll_map[dex][0]
                assert actual_token == expected_token, \
                    f"{dex} collateral: expected {expected_token}, got {actual_token}"
        assert matched >= 3, \
            f"Only {matched} known non-USDC dexes found in collateral map (expected ≥3). Map keys: {list(coll_map.keys())}"

    def test_all_dexes_have_valid_tokens(self, info):
        """Every dex in the map should have a non-empty token name."""
        coll_map = get_collateral_map(info)
        for dex, (token_name, token_idx) in coll_map.items():
            assert isinstance(token_name, str) and len(token_name) > 0, \
                f"dex '{dex}' has empty token name"
            assert isinstance(token_idx, int), \
                f"dex '{dex}' token index is not int: {token_idx}"


@pytest.mark.mainnet
class TestMidPrices:
    """Verify mid price fetching across all dexes."""

    def test_default_perps_have_prices(self, info):
        mids = get_all_mids(info)
        assert "BTC" in mids
        assert "ETH" in mids
        # Prices should be parseable float strings
        assert float(mids["BTC"]) > 0

    def test_hip3_assets_have_prices(self, info):
        mids = get_all_mids(info)
        # At least some HIP-3 assets should be present
        hip3_assets = [k for k in mids if ":" in k]
        assert len(hip3_assets) > 0, "No HIP-3 assets found in mids"


@pytest.mark.mainnet
class TestDexDiscovery:
    """Verify dex/deployer discovery from real API."""

    def test_all_perp_metas_returns_multiple_dexes(self, info):
        metas = get_all_perp_metas(info)
        assert len(metas) > 1, "Expected at least default + 1 HIP-3 dex"

    def test_dex_balances_returns_list(self, info, address):
        balances = get_dex_balances(info, address)
        assert isinstance(balances, list)
        # Should at least have the default dex
        dex_names = [b["dex"] for b in balances]
        assert "default" in dex_names


@pytest.mark.mainnet
class TestTokenFormat:
    """Verify non-canonical token format matches what SDK expects."""

    def test_non_canonical_tokens_have_token_id(self, info):
        """Tokens like USDH, USDE, USDT0 must have tokenId for send_asset."""
        spot_meta = info.spot_meta()
        non_canonical = [t for t in spot_meta["tokens"] if not t.get("isCanonical", True)]

        assert len(non_canonical) > 0, "No non-canonical tokens found"
        for t in non_canonical:
            assert "tokenId" in t, f"{t['name']} missing tokenId"
            assert t["tokenId"], f"{t['name']} has empty tokenId"
            # The format for send_asset should be NAME:tokenId
            sdk_name = f"{t['name']}:{t['tokenId']}"
            assert ":" in sdk_name

    def test_usdc_is_canonical(self, info):
        """USDC should be canonical (no tokenId suffix needed)."""
        spot_meta = info.spot_meta()
        usdc = next(t for t in spot_meta["tokens"] if t["name"] == "USDC")
        assert usdc.get("isCanonical", False), "USDC should be canonical"
