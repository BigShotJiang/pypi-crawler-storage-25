"""regard — AI trading partner for the unified speculator."""

import json
import sys
from importlib.metadata import version as pkg_version
from typing import Annotated

import click
import typer


def _version_callback(value: bool):
    if value:
        print(pkg_version("regard-cli"))
        raise typer.Exit()


app = typer.Typer(
    name="regard",
    add_completion=False,
    no_args_is_help=True,
    help="AI trading partner for the unified speculator.",
    pretty_exceptions_enable=False,
    pretty_exceptions_show_locals=False,
    rich_markup_mode=None,
)

hl_app = typer.Typer(
    name="hl",
    no_args_is_help=True,
    help="Hyperliquid perp trading. JSON output by default.",
    pretty_exceptions_enable=False,
)


# ---------------------------------------------------------------------------
# Global safety net — every exit path must produce valid JSON on stdout.
# Monkey-patch Click exception classes so even Typer parse errors (missing
# args, unknown flags, bad types) produce JSON instead of Rich formatting.
# ---------------------------------------------------------------------------

def _json_show(self, file=None):
    err = {
        "ok": False,
        "error": {
            "type": "validation_error",
            "code": "USAGE_ERROR",
            "message": self.format_message(),
            "retryable": False,
        },
        "meta": {"exit_code": 2},
    }
    print(json.dumps(err, separators=(",", ":")), file=file or sys.stdout, flush=True)

click.ClickException.show = _json_show
click.UsageError.show = _json_show
click.BadParameter.show = _json_show


@app.callback()
def main(
    ctx: typer.Context,
    version: bool = typer.Option(False, "--version", callback=_version_callback, is_eager=True, help="Show version and exit"),
    fields: str | None = typer.Option(None, "--fields", help="Comma-separated field projection"),
    verbose: bool = typer.Option(False, "--verbose", help="Debug info to stderr"),
):
    """Regard CLI — multi-venue trading."""
    ctx.ensure_object(dict)
    ctx.obj["fields"] = fields
    ctx.obj["verbose"] = verbose


@hl_app.callback()
def hl_main(
    ctx: typer.Context,
    testnet: bool = typer.Option(False, "--testnet", help="Use testnet endpoints"),
):
    """Hyperliquid perp trading CLI."""
    ctx.ensure_object(dict)
    ctx.obj["testnet"] = testnet


app.add_typer(hl_app)

# Session commands (top-level, not venue-specific)
from regard.commands.session import session_app  # noqa: E402

app.add_typer(session_app)

# Update check (top-level)
from regard.commands.update import update_app  # noqa: E402

app.add_typer(update_app)

# Auth setup (top-level)
from regard.commands.auth import auth_app  # noqa: E402

app.add_typer(auth_app)

# Config (top-level)
from regard.commands.config import config_app  # noqa: E402

app.add_typer(config_app)

# Killswitch (top-level)
from regard.commands.killswitch import killswitch_app  # noqa: E402

app.add_typer(killswitch_app)

# Register all hl venue commands — must be after hl_app is defined
from regard.venues.hyperliquid.commands import act, orient, research, review  # noqa: E402, F401

# Polymarket venue
from regard.venues.polymarket.main import poly_app  # noqa: E402

app.add_typer(poly_app)

# Cross-venue portfolio
from regard.commands.portfolio import portfolio_app  # noqa: E402

app.add_typer(portfolio_app)


# ---------------------------------------------------------------------------
# Approve — execute a pending proposal (Constitution Article II)
# ---------------------------------------------------------------------------

@app.command()
def approve(
    proposal_id: Annotated[str, typer.Argument(help="Proposal ID (e.g. p_7f3a8b2c1d4e)")],
):
    """Approve and execute a pending proposal."""
    import math

    from regard.core.output import die, output
    from regard.core.proposal import (
        approve_proposal,
        claim_proposal,
        find_approved_result,
        get_executor,
        read_proposal,
        reject_proposal,
    )

    # 0. Validate proposal ID format (prevents path traversal)
    try:
        from regard.core.proposal import _validate_proposal_id
        _validate_proposal_id(proposal_id)
    except ValueError:
        die("validation_error", "INVALID_PROPOSAL_ID",
            f"Invalid proposal ID format: {proposal_id}",
            hint="Proposal IDs are p_ followed by 12 hex characters (e.g. p_7f3a8b2c1d4e)")

    # 1. Idempotency — already approved?
    cached = find_approved_result(proposal_id)
    if cached is not None:
        output({"status": "already_approved", "proposal_id": proposal_id, "result": cached})
        return

    # 2. Read proposal
    proposal = read_proposal(proposal_id)
    if proposal is None:
        die("validation_error", "PROPOSAL_NOT_FOUND",
            f"No pending proposal '{proposal_id}'",
            hint="Check pending proposals or verify the ID")

    # 3. Price delta check — reject if price moved beyond threshold
    mark_price = proposal["checks"].get("mark_price")
    if mark_price is not None:
        try:
            old = float(mark_price)
        except (ValueError, TypeError):
            old = float("nan")  # route to the rejection below
        if not math.isfinite(old) or old <= 0:
            reject_proposal(proposal_id, "invalid_mark_price", mark_price=str(mark_price))
            die("validation_error", "INVALID_MARK_PRICE",
                f"Proposal has invalid mark_price: {mark_price}",
                hint="Create a new proposal",
                extra={"execution_state": "not_executed"})

        current_price = _fetch_current_price(proposal["venue"], proposal["params"])

        # 3c. Fail-closed: if we can't fetch the current price, refuse
        if current_price is None:
            die("venue_error", "PRICE_FETCH_FAILED",
                f"Could not fetch current price for {proposal['venue']} — cannot verify price safety",
                hint="Retry shortly. If the venue is down, wait and try again.",
                retryable=True,
                extra={"execution_state": "not_executed"},
                exit_code=4)

        # 3b + 3d. Price delta with Decimal precision and crash protection
        try:
            from decimal import Decimal
            d_old = Decimal(str(mark_price))
            d_new = Decimal(str(current_price))
            if d_new > 0:
                delta_pct = float(abs(d_new - d_old) / d_old * 100)
                threshold = _get_price_threshold(proposal["venue"])
                if delta_pct > threshold:
                    reject_proposal(
                        proposal_id, "price_delta",
                        delta=f"{delta_pct:.2f}%",
                        old_price=mark_price,
                        new_price=current_price,
                        threshold=f"{threshold}%",
                    )
                    die("validation_error", "PRICE_DELTA_EXCEEDED",
                        f"Price moved {delta_pct:.2f}% since proposal "
                        f"(was {mark_price}, now {current_price}, threshold {threshold}%)",
                        hint="Create a new proposal with current prices",
                        extra={
                            "old_price": mark_price,
                            "new_price": current_price,
                            "delta": f"{delta_pct:.2f}%",
                            "threshold": f"{threshold}%",
                            "execution_state": "not_executed",
                        })
        except SystemExit:
            raise
        except Exception:
            # Non-numeric current_price or other conversion error
            die("venue_error", "PRICE_CHECK_FAILED",
                f"Price delta check failed — could not compare prices (proposal: {mark_price}, current: {current_price})",
                hint="Create a new proposal",
                extra={"execution_state": "not_executed"},
                exit_code=4)

    # 4. Look up executor
    venue = proposal["venue"]
    command = proposal["command"]
    executor = get_executor(venue, command)
    if executor is None:
        die("internal_error", "NO_EXECUTOR",
            f"No executor registered for {venue}.{command}",
            exit_code=7)

    # 5. Rate limit executions — check BEFORE claim so the proposal isn't
    #    consumed if the rate limit fires.
    from regard.core.proposal import _check_rate_limit, get_workspace_dir
    _check_rate_limit(get_workspace_dir(), "approved", "EXECUTION_RATE_EXCEEDED")

    # 6. Claim — atomic compare-and-swap BEFORE execution.
    #    If another process already claimed this proposal, return idempotent result.
    claimed = claim_proposal(proposal_id)
    if not claimed:
        # Another process claimed it. Check if it was approved already.
        cached = find_approved_result(proposal_id)
        if cached is not None:
            output({"status": "already_approved", "proposal_id": proposal_id, "result": cached})
            return
        die("venue_error", "ALREADY_CLAIMED",
            f"Proposal '{proposal_id}' was already claimed by another process",
            extra={"execution_state": "not_executed"},
            exit_code=4)

    # 7. Execute — pending file is gone, only this process proceeds
    try:
        result = executor(proposal["params"])
    except SystemExit:
        raise
    except Exception as e:
        die("venue_error", "EXECUTION_FAILED", str(e),
            extra={"execution_state": "unknown", "proposal_id": proposal_id},
            exit_code=4)

    # 7. Log approval — event stream is the durable record.
    #    If logging fails (disk full, permission), the trade is already live.
    #    Output the result regardless — don't hide a successful trade behind an audit failure.
    import sys as _sys
    try:
        approve_proposal(proposal_id, result)
    except Exception as audit_err:
        _sys.stderr.write(f"[warn] approve_proposal audit failed for {proposal_id}: {audit_err}\n")
    output(result)


def _fetch_current_price(venue: str, params: dict) -> str | None:
    """Re-fetch the current mark price for a proposal's asset.

    Returns None if the price cannot be fetched (non-fatal — skip delta check).
    """
    testnet = params.get("testnet", False)
    try:
        if venue == "hl":
            asset = params.get("asset")
            if not asset:
                return None
            from regard.venues.hyperliquid.client import get_all_mids, get_info
            info = get_info(testnet)
            mids = get_all_mids(info)
            return mids.get(asset)
        elif venue == "poly":
            slug = params.get("market_slug")
            outcome = params.get("outcome")
            if not slug or not outcome:
                return None
            from regard.venues.polymarket.client import get_gamma_client
            from regard.venues.polymarket.market import resolve_market
            gamma = get_gamma_client()
            m = resolve_market(slug, gamma)
            if not m:
                return None
            price = m["yes_price"] if outcome == "yes" else m["no_price"]
            return str(price) if price > 0 else None
    except Exception:
        pass
    return None


def _get_price_threshold(venue: str) -> float:
    """Get the price delta threshold (%) for a venue. Configurable in future."""
    # Defaults per the constitution design
    return {"hl": 0.5, "poly": 1.0}.get(venue, 0.5)


# ---------------------------------------------------------------------------
# Schema — introspect the live command tree (Constitution Article V)
# ---------------------------------------------------------------------------

# Command classification per CLI Constitution Article I
_MUTATING = frozenset({
    "hl.order", "hl.stop", "hl.cancel", "hl.cancel-all",
    "hl.leverage", "hl.transfer",
    "poly.approve", "poly.order", "poly.cancel", "poly.cancel-all",
})
_HUMAN_ONLY = frozenset({"approve", "killswitch", "auth.hl", "auth.poly"})
_META = frozenset({"help"})

_TYPE_MAP = {
    "TEXT": "string",
    "STRING": "string",
    "INT": "integer",
    "INTEGER": "integer",
    "FLOAT": "number",
    "BOOL": "boolean",
    "BOOLEAN": "boolean",
    "UUID": "string",
    "PATH": "string",
    "CHOICE": "string",
}


def _command_class(name):
    if name in _MUTATING:
        return "mutating"
    if name in _HUMAN_ONLY:
        return "human-only"
    if name in _META:
        return "meta"
    return "agent-safe"


def generate_schema(typer_app):
    """Walk the Typer command tree and return agent-friendly structured schema."""
    from typer.main import get_command

    click_app = get_command(typer_app)
    all_entries = {}  # path -> (cmd, is_group)

    def _walk(cmd, path=""):
        if isinstance(cmd, click.Group):
            ctx = click.Context(cmd, info_name=path.split()[-1] if path else "regard")
            for name in sorted(cmd.list_commands(ctx)):
                subcmd = cmd.get_command(ctx, name)
                if subcmd:
                    _walk(subcmd, f"{path} {name}".strip())
        if path:
            all_entries[path] = (cmd, isinstance(cmd, click.Group))

    _walk(click_app)

    # Groups with children are structural — skip them.
    # Groups with no children are invoke_without_command — include as commands.
    group_paths = {p for p, (_, is_g) in all_entries.items() if is_g}
    has_children = {g for g in group_paths if any(
        p != g and p.startswith(g + " ") for p in all_entries
    )}

    commands = []
    for path, (cmd, is_group) in sorted(all_entries.items()):
        if is_group and path in has_children:
            continue

        dot_name = path.replace(" ", ".")
        params = {}
        for p in cmd.params:
            if p.name == "help":
                continue
            try:
                type_name = p.type.name
            except AttributeError:
                type_name = str(p.type)

            schema_type = _TYPE_MAP.get(type_name.upper(), "string")
            info = {"type": schema_type, "required": p.required}

            if isinstance(p, click.Option) and p.is_flag:
                info["type"] = "boolean"
            if hasattr(p.type, "choices") and p.type.choices:
                info["enum"] = list(p.type.choices)
            if not p.required and p.default is not None:
                info["default"] = str(p.default)
            if hasattr(p, "help") and p.help:
                info["description"] = p.help

            params[p.name] = info

        commands.append({
            "name": dot_name,
            "description": (cmd.help or "").strip(),
            "class": _command_class(dot_name),
            "params": params,
        })

    return {
        "version": pkg_version("regard-cli"),
        "total_commands": len(commands),
        "commands": commands,
    }


@app.command()
def schema(
    command: str | None = typer.Argument(None, help="Command in dot notation (e.g. hl.order)"),
):
    """Introspect the CLI command tree as structured JSON."""
    from regard.core.output import die, output

    data = generate_schema(app)

    if command:
        match = [c for c in data["commands"] if c["name"] == command]
        if not match:
            die("validation_error", "UNKNOWN_COMMAND",
                f"No command '{command}'. Run 'regard schema' to see all.",
                retryable=False)
        output(match[0])
    else:
        output(data)


# ---------------------------------------------------------------------------
# Wrapped entry point — last-resort catch for any exception that escapes
# all command-level handlers. Ensures stdout is always valid JSON.
# ---------------------------------------------------------------------------

def run():
    """Entry point with global exception safety net."""
    try:
        app()
    except SystemExit:
        raise
    except Exception as e:
        error = {
            "ok": False,
            "error": {
                "type": "internal_error",
                "code": type(e).__name__,
                "message": str(e),
                "retryable": False,
            },
            "meta": {"exit_code": 7},
        }
        print(json.dumps(error, separators=(",", ":")), flush=True)
        sys.exit(7)
