"""Propose/approve system — two-step safety gate for all mutating commands.

Every mutating command creates a proposal (pending file + event stream entry).
`regard approve <id>` validates and executes. No proposal, no execution.

Storage layout:
  ~/.regard/projects/<workspace_id>/
    events.jsonl        ← append-only audit trail
    pending/
      p_<hex12>.json    ← active proposal (deleted on approve/reject)

Constitution Article II governs this module.
"""

import fcntl
import hashlib
import json
import os
import re
import uuid
from datetime import datetime, timedelta, timezone
from pathlib import Path
from typing import Any

_VALID_PROPOSAL_ID = re.compile(r"^p_[0-9a-f]{12}$")

# ---------------------------------------------------------------------------
# Workspace directory
# ---------------------------------------------------------------------------

_REGARD_BASE = Path.home() / ".regard" / "projects"


def get_workspace_dir(cwd: str | None = None) -> Path:
    """Return the workspace directory for the given (or current) working dir.

    Format: <basename>_<sha256(realpath)[:8]>
    Creates the directory tree (including pending/) if it doesn't exist.
    """
    real = os.path.realpath(cwd or os.getcwd())
    basename = os.path.basename(real)
    digest = hashlib.sha256(real.encode()).hexdigest()[:8]
    workspace = _REGARD_BASE / f"{basename}_{digest}"
    workspace.mkdir(parents=True, exist_ok=True)
    (workspace / "pending").mkdir(exist_ok=True)
    return workspace


# ---------------------------------------------------------------------------
# Proposal CRUD
# ---------------------------------------------------------------------------

def _now_iso() -> str:
    return datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ")


def _generate_id() -> str:
    return "p_" + uuid.uuid4().hex[:12]


def _validate_proposal_id(proposal_id: str):
    """Validate proposal ID format. Prevents path traversal."""
    if not _VALID_PROPOSAL_ID.match(proposal_id):
        raise ValueError(f"Invalid proposal ID: {proposal_id!r}")


def _append_event(workspace: Path, event: dict):
    """Append a single event to events.jsonl with file locking."""
    events_path = workspace / "events.jsonl"
    line = json.dumps(event, separators=(",", ":")) + "\n"
    fd = os.open(str(events_path), os.O_WRONLY | os.O_CREAT | os.O_APPEND)
    try:
        fcntl.flock(fd, fcntl.LOCK_EX)
        os.write(fd, line.encode())
    finally:
        fcntl.flock(fd, fcntl.LOCK_UN)
        os.close(fd)


# Rate limit defaults — prevents runaway agent behavior.
# A model in a bad loop can flood proposals or approvals faster than
# a human can intervene.
_RATE_LIMIT = 10          # max events per window
_RATE_WINDOW_MINUTES = 5  # sliding window size


def _check_rate_limit(workspace: Path, event_type: str, error_code: str):
    """Check rate limit by counting recent events in the event stream.

    Dies if the count exceeds _RATE_LIMIT within _RATE_WINDOW_MINUTES.
    """
    events_path = workspace / "events.jsonl"
    if not events_path.exists():
        return

    cutoff = datetime.now(timezone.utc) - timedelta(minutes=_RATE_WINDOW_MINUTES)
    count = 0
    for line in events_path.read_text().splitlines():
        if not line.strip():
            continue
        try:
            event = json.loads(line)
            if event.get("event") != event_type:
                continue
            ts_str = event.get("ts", "")
            if ts_str:
                ts = datetime.fromisoformat(ts_str.replace("Z", "+00:00"))
                if ts >= cutoff:
                    count += 1
        except Exception:
            continue

    if count >= _RATE_LIMIT:
        from regard.core.output import die
        die("rate_limit_error", error_code,
            f"Rate limit exceeded: {count} {event_type} events in the last {_RATE_WINDOW_MINUTES} minutes (limit: {_RATE_LIMIT})",
            hint="Wait a few minutes before retrying. This limit prevents runaway agent behavior.",
            retryable=True,
            exit_code=5)


def create_proposal(
    venue: str,
    command: str,
    params: dict,
    checks: dict,
    warnings: list,
    *,
    cwd: str | None = None,
) -> dict:
    """Create a proposal: write pending file + append 'proposed' event.

    Returns the full proposal dict.
    """
    workspace = get_workspace_dir(cwd)

    # Rate limit proposals
    _check_rate_limit(workspace, "proposed", "PROPOSAL_RATE_EXCEEDED")
    proposal_id = _generate_id()
    ts = _now_iso()

    proposal = {
        "id": proposal_id,
        "created_at": ts,
        "venue": venue,
        "command": command,
        "params": params,
        "checks": checks,
        "warnings": warnings,
        "status": "pending",
    }

    # Log first, then act — event stream is the source of truth.
    # If we crash after logging but before writing the pending file,
    # the event exists (recoverable). The reverse leaves an orphan.
    _append_event(workspace, {
        "event": "proposed",
        "id": proposal_id,
        "venue": venue,
        "command": command,
        "params": params,
        "checks": checks,
        "warnings": warnings,
        "ts": ts,
    })

    pending_path = workspace / "pending" / f"{proposal_id}.json"
    pending_path.write_text(json.dumps(proposal, separators=(",", ":")) + "\n")

    return proposal


def read_proposal(proposal_id: str, *, cwd: str | None = None) -> dict | None:
    """Read a pending proposal by ID. Returns None if not found."""
    _validate_proposal_id(proposal_id)
    workspace = get_workspace_dir(cwd)
    pending_path = workspace / "pending" / f"{proposal_id}.json"
    if not pending_path.exists():
        return None
    return json.loads(pending_path.read_text())


def claim_proposal(proposal_id: str, *, cwd: str | None = None) -> bool:
    """Atomically claim a pending proposal for execution.

    Uses rename() as compare-and-swap. Returns True if this process
    claimed the proposal, False if another process got there first
    or the proposal doesn't exist.
    """
    _validate_proposal_id(proposal_id)
    workspace = get_workspace_dir(cwd)
    pending_path = workspace / "pending" / f"{proposal_id}.json"
    claim_path = workspace / "pending" / f"{proposal_id}.claiming"

    try:
        pending_path.rename(claim_path)
        claim_path.unlink()
        return True
    except FileNotFoundError:
        return False


def approve_proposal(
    proposal_id: str,
    result: dict,
    *,
    cwd: str | None = None,
) -> dict:
    """Record an approved event in the audit log.

    Called AFTER execution succeeds. The pending file should already
    be claimed via claim_proposal() before execution.
    Returns the event dict (including the execution result).
    """
    _validate_proposal_id(proposal_id)
    workspace = get_workspace_dir(cwd)

    # Log the approval — event stream is source of truth
    ts = _now_iso()
    event = {
        "event": "approved",
        "id": proposal_id,
        "result": result,
        "ts": ts,
    }
    _append_event(workspace, event)
    return event


_RESERVED_EVENT_KEYS = frozenset({"event", "id", "reason", "ts"})


def reject_proposal(
    proposal_id: str,
    reason: str,
    *,
    cwd: str | None = None,
    **extra,
) -> dict:
    """Reject a proposal: delete pending file + append 'rejected' event.

    Extra kwargs (e.g. delta, old_price, new_price) are merged into the event.
    Reserved keys (event, id, reason, ts) are silently dropped.
    """
    _validate_proposal_id(proposal_id)
    workspace = get_workspace_dir(cwd)
    pending_path = workspace / "pending" / f"{proposal_id}.json"

    # Log first, then remove pending file
    ts = _now_iso()
    event = {
        "event": "rejected",
        "id": proposal_id,
        "reason": reason,
        "ts": ts,
    }
    safe_extra = {k: v for k, v in extra.items() if k not in _RESERVED_EVENT_KEYS}
    event.update(safe_extra)
    _append_event(workspace, event)

    if pending_path.exists():
        pending_path.unlink()

    return event


def list_pending(*, cwd: str | None = None) -> list[dict]:
    """List all pending proposals. Returns list of proposal dicts."""
    workspace = get_workspace_dir(cwd)
    pending_dir = workspace / "pending"
    proposals = []
    for path in sorted(pending_dir.glob("p_*.json")):
        try:
            proposals.append(json.loads(path.read_text()))
        except (json.JSONDecodeError, OSError):
            continue
    return proposals


def read_events(*, cwd: str | None = None) -> list[dict]:
    """Read all events from the event stream. Returns list of event dicts."""
    workspace = get_workspace_dir(cwd)
    events_path = workspace / "events.jsonl"
    if not events_path.exists():
        return []
    events = []
    for line in events_path.read_text().splitlines():
        line = line.strip()
        if line:
            try:
                events.append(json.loads(line))
            except json.JSONDecodeError:
                continue
    return events


def find_approved_result(proposal_id: str, *, cwd: str | None = None) -> dict | None:
    """Scan events.jsonl for a cached approved result (idempotency).

    Returns the result dict if the proposal was already approved, else None.
    """
    for event in read_events(cwd=cwd):
        if event.get("event") == "approved" and event.get("id") == proposal_id:
            return event.get("result")
    return None


# ---------------------------------------------------------------------------
# Executor registry
# ---------------------------------------------------------------------------

EXECUTORS: dict[tuple[str, str], Any] = {}


def register_executor(venue: str, command: str, fn: Any):
    """Register an executor function for a (venue, command) pair."""
    EXECUTORS[(venue, command)] = fn


def get_executor(venue: str, command: str) -> Any:
    """Look up the executor for a (venue, command) pair."""
    return EXECUTORS.get((venue, command))
