"""EVM transaction safety — gas ceiling and simulation.

Constitution Article II: gas price ceiling per chain, simulation before submission.
"""


class EVMSafetyError(Exception):
    """Raised when a gas ceiling or simulation check fails."""


# Internal multiplier: reject if current gas exceeds this multiple of
# the recent median effective gas price. 10x is generous — catches genuine
# anomalies (RPC garbage, flash spikes) without triggering on normal
# fluctuations.
_GAS_CEILING_MULTIPLIER = 10

# Number of recent blocks to sample for fee history baseline.
_FEE_HISTORY_BLOCKS = 20


def get_safe_gas_price(w3) -> int:
    """Fetch current gas price, validate against recent chain history.

    Compares the current gas price (base fee + priority fee) to the median
    effective gas price over the last 20 blocks. Uses fee_history with
    reward percentiles so both sides of the comparison include the priority
    fee — avoids false rejections on chains like Polygon where the tip is
    large relative to base fee.

    Returns the gas price (wei) if safe. Raises EVMSafetyError if too high.
    """
    gas_price = w3.eth.gas_price

    try:
        # Request 50th percentile priority fee per block so we compare
        # total effective gas prices (base + tip), not base-only.
        history = w3.eth.fee_history(_FEE_HISTORY_BLOCKS, "latest", [50])
        base_fees = history["baseFeePerGas"]
        rewards = history.get("reward", [])

        # Compute total effective gas price per block
        effective = []
        for i in range(len(rewards)):
            tip = rewards[i][0] if rewards[i] else 0
            effective.append(base_fees[i] + tip)

        if not effective:
            return gas_price

        median = sorted(effective)[len(effective) // 2]
    except Exception:
        # If fee history is unavailable (old node, non-EIP-1559 chain),
        # skip the ceiling check — we still have simulation as a safety net.
        return gas_price

    if median <= 0:
        return gas_price

    ratio = gas_price / median
    if ratio > _GAS_CEILING_MULTIPLIER:
        current_gwei = gas_price / 10**9
        median_gwei = median / 10**9
        raise EVMSafetyError(
            f"Transaction fees are unusually high right now. "
            f"Current fee is {ratio:.0f}x above the recent average "
            f"({current_gwei:.1f} vs {median_gwei:.1f} gwei)."
        )

    return gas_price


def simulate_and_send(w3, tx: dict, account) -> bytes:
    """Simulate a transaction via eth_call, then sign and send.

    Takes an unsigned transaction dict (from build_transaction) and an
    account. Runs eth_call to catch reverts, insufficient balances, and
    state-dependent failures before spending gas.

    Returns the transaction hash. Raises EVMSafetyError if simulation reverts.
    """
    # Build simulation params — eth_call only needs these fields
    sim = {k: v for k, v in tx.items() if k in ("from", "to", "value", "data", "gas")}

    try:
        w3.eth.call(sim)
    except Exception as e:
        raise EVMSafetyError(f"Transaction would fail: {e}") from e

    signed = account.sign_transaction(tx)
    return w3.eth.send_raw_transaction(signed.raw_transaction)
