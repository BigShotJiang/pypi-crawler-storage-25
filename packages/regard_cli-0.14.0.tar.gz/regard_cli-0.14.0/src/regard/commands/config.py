"""Config — surface and inspect CLI configuration."""

import typer

from regard.core.output import output

config_app = typer.Typer(
    name="config",
    no_args_is_help=True,
    help="View CLI configuration.",
)

DEFAULT_POLYGON_RPC = "https://rpc.regard.computer/regard/evm/137"
DEFAULT_KILLSWITCH_SLIPPAGE = 0.10


def _effective_slippage(raw_val) -> float:
    """Return the slippage that killswitch will actually use."""
    if raw_val:
        try:
            s = float(raw_val)
            if 0.001 <= s <= 0.5:
                return s
        except (ValueError, TypeError):
            pass
    return DEFAULT_KILLSWITCH_SLIPPAGE


@config_app.command()
def show():
    """Show current configuration."""
    from regard.venues.hyperliquid.client import _load_settings_env

    settings = _load_settings_env()
    custom_rpc = settings.get("POLYGON_RPC")

    killswitch_addr = settings.get("KILLSWITCH_ADDRESS")
    custom_slippage = settings.get("KILLSWITCH_SLIPPAGE")
    effective_slip = _effective_slippage(custom_slippage)

    result = {
        "polygon_rpc": {
            "current": custom_rpc or DEFAULT_POLYGON_RPC,
            "source": "settings" if custom_rpc else "default",
            "default": DEFAULT_POLYGON_RPC,
        },
        "killswitch_address": {
            "current": killswitch_addr or None,
            "configured": killswitch_addr is not None,
        },
        "killswitch_slippage": {
            "current": effective_slip,
            "source": "settings" if custom_slippage and effective_slip != DEFAULT_KILLSWITCH_SLIPPAGE else "default",
            "default": DEFAULT_KILLSWITCH_SLIPPAGE,
        },
    }
    output(result, None)
