"""Session commands — context management and trading analysis.

Reads Claude Code session transcripts (~/.claude/projects/<encoded-cwd>/*.jsonl),
extracts trades, research chains, tilt signals, and session context.

Commands: gm, gg, cope, pnl, tilt, what
"""

import json
import os
import re
from datetime import datetime, timedelta, timezone
from pathlib import Path

import typer

session_app = typer.Typer(
    name="session",
    no_args_is_help=True,
    help="Session commands — context management and trading analysis.",
)


# --- Session discovery ---

UUID_RE = re.compile(r'^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}\.jsonl$')


def _get_session_base_path():
    """Derive session directory from CWD."""
    cwd = os.getcwd()
    encoded = cwd.replace("/", "-")
    session_dir = Path.home() / ".claude" / "projects" / encoded
    return str(session_dir) if session_dir.is_dir() else None


def _find_session_files(base_path):
    """Session JSONL files sorted by modification time, newest first."""
    try:
        files = [
            os.path.join(base_path, f) for f in os.listdir(base_path)
            if UUID_RE.match(f)
        ]
    except OSError:
        return []
    files.sort(key=lambda f: os.path.getmtime(f), reverse=True)
    return files


# --- Entry parsing ---

def _extract_entries(filepath):
    """Parse session JSONL into (timestamp, role, text) tuples.

    Roles: U=user, A=assistant, T=tool_use, R=tool_result
    """
    entries = []
    try:
        with open(filepath, encoding='utf-8', errors='ignore') as f:
            for line in f:
                line = line.strip()
                if not line:
                    continue
                try:
                    e = json.loads(line)
                    ts = e.get("timestamp", "")
                    t = e.get("type")

                    if t == "user":
                        c = e.get("message", {}).get("content", "")
                        if isinstance(c, str) and c.strip():
                            if "<command-name>" not in c[:50]:
                                entries.append((ts, "U", c))
                        elif isinstance(c, list):
                            for item in c:
                                if item.get("type") == "text":
                                    entries.append((ts, "U", item.get("text", "")))
                                elif item.get("type") == "tool_result":
                                    content = item.get("content", "")
                                    if isinstance(content, list):
                                        content = " ".join(
                                            b.get("text", str(b)) if isinstance(b, dict) else str(b)
                                            for b in content
                                        )
                                    entries.append((ts, "R", content))

                    elif t == "assistant":
                        for b in e.get("message", {}).get("content", []) or []:
                            if b.get("type") == "text":
                                entries.append((ts, "A", b.get("text", "")))
                            elif b.get("type") == "tool_use":
                                n = b.get("name", "")
                                inp = json.dumps(b.get("input", {}))
                                entries.append((ts, "T", f"{n}: {inp}"))
                except (json.JSONDecodeError, KeyError):
                    pass
    except OSError:
        pass
    return entries


def _load_entries(session_files, max_sessions=5):
    """Load and merge entries from multiple session files."""
    all_entries = []
    for sf in session_files[:max_sessions]:
        all_entries.extend(_extract_entries(sf))
    all_entries.sort(key=lambda x: x[0])
    return all_entries


# --- Trade & research extraction ---

RESEARCH_SKILLS = frozenset({
    'chans-research', 'discord-research', 'dune', 'x',
    'substack-research', 'telegram-research', 'reddit-chainstack',
    'search-obsidian', 'youtube-transcript',
})


def _extract_hl_command(text):
    """Extract regard hl command string from a Bash tool call entry."""
    m = re.search(r'"command":\s*"(regard hl [^"]+)"', text)
    return m.group(1) if m else None


def _is_hl_order(text):
    return text.startswith("Bash:") and '"regard hl order' in text


def _parse_hl_order(cmd):
    """Parse 'regard hl order ASSET SIDE SIZE [PRICE] [--flags]' into dict."""
    parts = cmd.split()
    if len(parts) < 6:
        return None
    # regard=0, hl=1, order=2, ASSET=3, SIDE=4, SIZE=5
    return {
        'asset': parts[3],
        'side': parts[4],
        'size': parts[5],
        'price': parts[6] if len(parts) > 6 and not parts[6].startswith('--') else None,
        'market': '--market' in cmd,
        'reduce_only': '--reduce-only' in cmd,
    }


def _extract_trades(entries):
    """Find all regard hl order calls with their results."""
    trades = []
    for i, (ts, role, text) in enumerate(entries):
        if role != "T" or not _is_hl_order(text):
            continue
        cmd = _extract_hl_command(text)
        if not cmd:
            continue
        info = _parse_hl_order(cmd)
        if not info:
            continue
        info['timestamp'] = ts
        info['index'] = i
        info['raw'] = cmd
        # Find result (next R entry within 10 entries)
        for j in range(i + 1, min(i + 10, len(entries))):
            if entries[j][1] == "R":
                try:
                    raw = json.loads(entries[j][2])
                    # Unwrap output envelope if present
                    if isinstance(raw, dict) and raw.get("ok") and "data" in raw:
                        info['result'] = raw["data"]
                    else:
                        info['result'] = raw
                except (json.JSONDecodeError, TypeError):
                    info['result_raw'] = entries[j][2][:500]
                break
        trades.append(info)
    return trades


def _extract_research(entries):
    """Find research skill invocations and web searches."""
    research = []
    for i, (ts, role, text) in enumerate(entries):
        if role != "T":
            continue
        if text.startswith("Skill:"):
            m = re.search(r'"skill":\s*"([^"]+)"', text)
            if m:
                name = m.group(1).split(':')[0]
                if name in RESEARCH_SKILLS:
                    research.append({'timestamp': ts, 'skill': m.group(1), 'index': i})
        elif text.startswith(("WebSearch:", "WebFetch:")):
            research.append({'timestamp': ts, 'skill': text.split(':')[0], 'index': i})
    return research


def _get_context_window(entries, trade_index):
    """Entries between previous trade (or start) and this trade."""
    prev = 0
    for i in range(trade_index - 1, -1, -1):
        if entries[i][1] == "T" and _is_hl_order(entries[i][2]):
            prev = i + 1
            break
    return entries[prev:trade_index]



# --- Time helpers ---

def _parse_ts(ts):
    if not ts:
        return None
    try:
        return datetime.fromisoformat(ts.replace("Z", "+00:00"))
    except (ValueError, TypeError):
        return None


def _parse_time_modifier(mod):
    """Parse pnl modifier into (start, end) UTC datetimes."""
    now = datetime.now(timezone.utc)
    today_start = now.replace(hour=0, minute=0, second=0, microsecond=0)

    if not mod or mod == '1d':
        return today_start, now
    if mod == 'max':
        return datetime.min.replace(tzinfo=timezone.utc), now
    if mod == 'ytd':
        return now.replace(month=1, day=1, hour=0, minute=0, second=0, microsecond=0), now

    m = re.match(r'^(\d+)([dwmy])$', mod)
    if m:
        n, u = int(m.group(1)), m.group(2)
        delta = {'d': timedelta(days=n), 'w': timedelta(weeks=n),
                 'm': timedelta(days=n * 30), 'y': timedelta(days=n * 365)}[u]
        return now - delta, now

    m = re.match(r'^(\d{1,2}/\d{1,2})-(\d{1,2}/\d{1,2})$', mod)
    if m:
        y = now.year
        start = datetime.strptime(f"{y}/{m.group(1)}", "%Y/%m/%d").replace(tzinfo=timezone.utc)
        end = datetime.strptime(f"{y}/{m.group(2)}", "%Y/%m/%d").replace(
            hour=23, minute=59, second=59, tzinfo=timezone.utc)
        return start, end

    return today_start, now


def _filter_by_time(entries, start, end):
    return [(ts, r, t) for ts, r, t in entries
            if (dt := _parse_ts(ts)) and start <= dt <= end]


def _today_entries(entries):
    today = datetime.now().date()
    return [(ts, r, t) for ts, r, t in entries
            if (dt := _parse_ts(ts)) and dt.astimezone().date() == today]



# --- Session loading helper ---

# Scan depth per command
_DEPTHS = {
    'gm': 10,
    'gg': 3,
    'cope': 20,
    'pnl': 30,
    'tilt': 3,
    'what': 5,
}


def _load_session(command: str, pnl_max: bool = False):
    """Load session entries, exit with error if none found."""
    from regard.core.output import die
    base_path = _get_session_base_path()
    if not base_path:
        die("validation_error", "NO_SESSION_DIR", "No session directory found for CWD",
            hint="Run from the regard-computer workspace directory", exit_code=2)

    session_files = _find_session_files(base_path)
    if not session_files:
        die("validation_error", "NO_SESSION_FILES", "No session files found",
            hint="Start a session first — session transcripts accumulate automatically", exit_code=2)

    if pnl_max:
        return _load_entries(session_files, max_sessions=len(session_files))
    return _load_entries(session_files, max_sessions=_DEPTHS.get(command, 5))


# --- Commands ---

def _find_gg_handoffs() -> list:
    """Find gg handoff docs in CWD/gg/handoffs/, newest first."""
    gg_dir = Path.cwd() / "gg" / "handoffs"
    if not gg_dir.is_dir():
        return []
    files = sorted(gg_dir.glob("*.md"), key=lambda f: f.stat().st_mtime, reverse=True)
    return [str(f) for f in files]


@session_app.command()
def gm():
    """Pick up where you left off — reads gg handoffs, falls back to transcript reconstruction.

    Outputs JSON with handoff content, recent trades, and research for the skill to present.
    """
    from regard.core.output import output

    result = {
        "handoff": None,
        "handoff_path": None,
        "unwrapped_trades": [],
        "unwrapped_research": [],
        "transcript_trades": [],
        "transcript_research": [],
        "source": "none",
    }

    # 1. Check for gg handoff docs
    handoffs = _find_gg_handoffs()
    if handoffs:
        latest = handoffs[0]
        try:
            content = Path(latest).read_text()
            result["handoff"] = content
            result["handoff_path"] = latest
            result["source"] = "handoff"
        except Exception:
            pass

    # 2. Load transcripts for unwrapped activity / fallback reconstruction
    base_path = _get_session_base_path()
    if not base_path:
        output(result, None)
        return
    session_files = _find_session_files(base_path)
    if not session_files:
        output(result, None)
        return
    entries = _load_entries(session_files[:_DEPTHS.get('gm', 10)])

    trades = _extract_trades(entries)
    research = _extract_research(entries)

    if result["handoff"]:
        # Find activity AFTER the handoff file's mtime
        handoff_mtime = Path(result["handoff_path"]).stat().st_mtime
        handoff_ts = datetime.fromtimestamp(handoff_mtime, tz=timezone.utc).isoformat()
        after = [(ts, r, t) for ts, r, t in entries if ts > handoff_ts]
        after_trades = _extract_trades(after)
        after_research = _extract_research(after)
        result["unwrapped_trades"] = [{"asset": t["asset"], "side": t["side"], "size": t["size"],
                                        "timestamp": t.get("timestamp", ""), "raw": t.get("raw", "")}
                                       for t in after_trades]
        result["unwrapped_research"] = [{"timestamp": r["timestamp"], "skill": r["skill"]}
                                         for r in after_research]
    else:
        # No handoff — fall back to transcript reconstruction
        result["source"] = "transcript"
        for t in trades[-20:]:
            ctx = _get_context_window(entries, t['index'])
            ctx_entries = [{"timestamp": ts, "role": {"U": "user", "A": "assistant", "T": "tool", "R": "result"}.get(role, role),
                            "text": text[:300]} for ts, role, text in ctx]
            result["transcript_trades"].append({
                "asset": t["asset"], "side": t["side"], "size": t["size"],
                "price": t.get("price"), "reduce_only": t.get("reduce_only", False),
                "timestamp": t.get("timestamp", ""),
                "result": t.get("result", ""),
                "context": ctx_entries,
            })
        result["transcript_research"] = [{"timestamp": r["timestamp"], "skill": r["skill"]}
                                          for r in research[-20:]]

    result["all_handoffs"] = handoffs[:10]
    output(result, None)


@session_app.command()
def gg():
    """Wrap session — extract structured data for handoff doc.

    Outputs JSON with trades, research, context per trade, and key messages.
    The skill reads this output and writes the actual handoff markdown to gg/handoffs/.
    """
    from regard.core.output import output

    entries = _load_session('gg')
    today = _today_entries(entries)
    if not today:
        today = entries[-500:]  # fallback: last 500 entries if nothing "today"

    trades = _extract_trades(today)
    research = _extract_research(today)

    # Build per-trade context (conversation leading up to each trade)
    trade_data = []
    for t in trades:
        ctx = _get_context_window(today, t['index'])
        ctx_entries = []
        for ts, role, text in ctx:
            ctx_entries.append({
                "timestamp": ts,
                "role": {"U": "user", "A": "assistant", "T": "tool", "R": "result"}.get(role, role),
                "text": text[:500],
            })
        trade_data.append({
            "asset": t["asset"],
            "side": t["side"],
            "size": t["size"],
            "price": t.get("price"),
            "market": t.get("market", False),
            "reduce_only": t.get("reduce_only", False),
            "timestamp": t.get("timestamp", ""),
            "result": t.get("result", t.get("result_raw", "")),
            "context": ctx_entries,
        })

    research_data = [{"timestamp": r["timestamp"], "skill": r["skill"]} for r in research]

    # Key user messages (for thesis extraction)
    user_msgs = []
    for ts, role, text in today:
        if role == "U" and len(text.strip()) > 20:
            user_msgs.append({"timestamp": ts, "text": text[:500]})

    # Key assistant messages (for reasoning extraction)
    assistant_msgs = []
    for ts, role, text in today:
        if role == "A" and len(text.strip()) > 50:
            assistant_msgs.append({"timestamp": ts, "text": text[:500]})

    result = {
        "trades": trade_data,
        "trade_count": len(trade_data),
        "research": research_data,
        "research_count": len(research_data),
        "user_messages": user_msgs[-30:],
        "assistant_messages": assistant_msgs[-30:],
        "total_entries": len(today),
        "time_range": {
            "first": today[0][0] if today else "",
            "last": today[-1][0] if today else "",
        },
    }
    output(result, None)


@session_app.command()
def cope(
    assets: list[str] = typer.Argument(None, help="Assets to check thesis for"),
):
    """Thesis check — find original reasoning for positions.

    Searches gg handoff docs first, falls back to transcript reconstruction.
    Outputs JSON with thesis context per asset for the skill to reason about.
    """
    from regard.core.output import output

    if not assets:
        from regard.core.output import die
        die("validation_error", "MISSING_ARGUMENT", "Specify assets to check", hint="cope BTC ETH", exit_code=2)

    # Search handoff docs for thesis
    handoffs = _find_gg_handoffs()
    handoff_content = {}
    for hf in handoffs:
        try:
            content = Path(hf).read_text()
            for asset in assets:
                au = asset.upper()
                if au in content.upper() and au not in handoff_content:
                    handoff_content[au] = {"path": hf, "content": content}
        except Exception:
            continue

    # Search transcripts for trade context
    base_path = _get_session_base_path()
    if base_path:
        session_files = _find_session_files(base_path)
        entries = _load_entries(session_files[:_DEPTHS.get('cope', 20)]) if session_files else []
    else:
        entries = []

    trades = _extract_trades(entries) if entries else []

    results = []
    for asset in assets:
        au = asset.upper()
        entry = {"asset": au, "source": "none", "handoff": None, "trade": None, "context": []}

        # Handoff doc?
        if au in handoff_content:
            entry["source"] = "handoff"
            entry["handoff"] = {
                "path": handoff_content[au]["path"],
                "content": handoff_content[au]["content"][:3000],
            }

        # Transcript trade?
        opening = None
        for t in reversed(trades):
            if t['asset'].upper() == au and not t.get('reduce_only'):
                opening = t
                break

        if opening:
            r = opening.get('result', {})
            price = r.get('avg_price', opening.get('price', '?')) if isinstance(r, dict) else '?'
            entry["trade"] = {
                "side": opening["side"],
                "size": opening["size"],
                "price": price,
                "timestamp": opening.get("timestamp", ""),
            }

            ctx = _get_context_window(entries, opening['index'])
            entry["context"] = [
                {"timestamp": ts, "role": {"U": "user", "A": "assistant", "T": "tool", "R": "result"}.get(role, role),
                 "text": text[:500]}
                for ts, role, text in ctx
            ]
            if entry["source"] == "none":
                entry["source"] = "transcript"

        results.append(entry)

    output(results, None)


@session_app.command()
def pnl(
    modifier: str | None = typer.Argument(None, help="Time range: 1d, 5d, 1m, ytd, max, MM/DD-MM/DD"),
):
    """P&L for a time range."""
    from regard.core.output import output

    entries = _load_session('pnl', pnl_max=(modifier == 'max'))
    start, end = _parse_time_modifier(modifier)
    filtered = _filter_by_time(entries, start, end)
    trades = _extract_trades(filtered)

    balance_calls = []
    for ts, role, text in filtered:
        if role == "T":
            cmd = _extract_hl_command(text)
            if cmd and (cmd.startswith('regard hl balance') or cmd.startswith('regard hl status')):
                balance_calls.append(ts)

    trade_data = []
    for t in trades:
        r = t.get('result', {})
        price = r.get('avg_price', t.get('price', '')) if isinstance(r, dict) else t.get('price', '')
        status = r.get('status', '') if isinstance(r, dict) else ''
        trade_data.append({
            "asset": t["asset"],
            "side": t["side"],
            "size": t["size"],
            "price": price,
            "status": status,
            "reduce_only": t.get("reduce_only", False),
            "timestamp": t.get("timestamp", ""),
        })

    result = {
        "range": modifier or "1d",
        "trade_count": len(trades),
        "balance_checks": len(balance_calls),
        "trades": trade_data,
        "time_range": {
            "start": start.isoformat(),
            "end": end.isoformat(),
        },
    }
    output(result, None)


@session_app.command()
def tilt():
    """Session health check — data-driven tilt detection."""
    from regard.core.output import output

    entries = _load_session('tilt')
    today = _today_entries(entries)
    trades = _extract_trades(today)

    if len(trades) < 2:
        output({
            "level": "GREEN",
            "session_health": 100,
            "trades_today": len(trades),
            "indicators": [],
            "note": "need 2+ trades to assess",
        }, None)
        return

    timestamps = [dt for t in trades if (dt := _parse_ts(t['timestamp']))]
    intervals = [(timestamps[i] - timestamps[i - 1]).total_seconds()
                 for i in range(1, len(timestamps))]

    freq_factor = 0.0
    if len(intervals) >= 3:
        avg_iv = sum(intervals) / len(intervals)
        if intervals[-1] > 0 and avg_iv > 0:
            freq_factor = max(0, (avg_iv / intervals[-1]) - 1)

    sizes = []
    for t in trades:
        try:
            sizes.append(float(t['size']))
        except (ValueError, TypeError):
            pass

    size_dev = 0.0
    if len(sizes) >= 3:
        avg_sz = sum(sizes) / len(sizes)
        if avg_sz > 0:
            size_dev = max(0, ((sizes[-1] / avg_sz) - 1) * 100)

    revenge = 0
    for i in range(1, len(trades)):
        prev, curr = trades[i - 1], trades[i]
        if (curr['asset'].upper() == prev['asset'].upper()
                and curr['side'] == prev['side']):
            t1, t2 = _parse_ts(prev['timestamp']), _parse_ts(curr['timestamp'])
            if t1 and t2 and (t2 - t1).total_seconds() < 300:
                revenge += 1

    health = 100 - freq_factor * 15 - size_dev * 0.5 - revenge * 20
    health = max(0, min(100, health))

    indicators = []
    if freq_factor >= 1.0:
        indicators.append(f"frequency: {freq_factor:.1f}x faster than avg")
    if size_dev >= 50:
        indicators.append(f"size: +{size_dev:.0f}% vs avg")
    if revenge > 0:
        indicators.append(f"revenge: {revenge} re-entry(s) <5min")

    n = len(indicators)
    level = "RED" if n >= 3 else "ORANGE" if n >= 2 else "YELLOW" if n >= 1 else "GREEN"

    result = {
        "level": level,
        "session_health": round(health),
        "trades_today": len(trades),
        "indicators": indicators,
    }
    if intervals:
        result["avg_interval_min"] = round(sum(intervals) / len(intervals) / 60, 1)
        result["last_interval_min"] = round(intervals[-1] / 60, 1)
    if sizes:
        result["avg_size"] = round(sum(sizes) / len(sizes), 4)
        result["last_size"] = round(sizes[-1], 4)

    output(result, None)


@session_app.command()
def what():
    """Session context for open-ended trading interview."""
    from regard.core.output import output

    entries = _load_session('what')
    today = _today_entries(entries)
    if not today:
        today = entries[-100:] if len(entries) > 100 else entries

    trades = _extract_trades(today)
    research = _extract_research(today)

    timeline = []
    for ts, role, text in today[-50:]:
        text_clean = text.replace('\n', ' ')
        if role == "U":
            timeline.append({"timestamp": ts, "role": "user", "text": text_clean[:500]})
        elif role == "A":
            timeline.append({"timestamp": ts, "role": "assistant", "text": text_clean[:500]})
        elif role == "T" and ('regard hl ' in text or
              any(s in text for s in RESEARCH_SKILLS) or
              text.startswith(("WebSearch:", "WebFetch:", "Skill:"))):
            timeline.append({"timestamp": ts, "role": "tool", "text": text_clean[:200]})

    result = {
        "total_entries": len(today),
        "trade_count": len(trades),
        "research_count": len(research),
        "timeline": timeline,
    }
    output(result, None)


@session_app.command()
def ctx():
    """Context estimate — rough session weight from transcript data."""
    from regard.core.output import die
    base_path = _get_session_base_path()
    if not base_path:
        die("validation_error", "NO_SESSION_DIR", "No session directory found for CWD",
            hint="Run from the regard-computer workspace directory", exit_code=2)

    session_files = _find_session_files(base_path)
    if not session_files:
        die("validation_error", "NO_SESSION_FILES", "No session files found",
            hint="Start a session first — session transcripts accumulate automatically", exit_code=2)

    # Read the current (most recent) session file raw
    current = session_files[0]

    total_chars = 0

    try:
        with open(current, encoding='utf-8', errors='ignore') as f:
            for line in f:
                line = line.strip()
                if not line:
                    continue
                try:
                    e = json.loads(line)
                    t = e.get("type")

                    if t == "user":
                        c = e.get("message", {}).get("content", "")
                        if isinstance(c, str):
                            total_chars += len(c)
                        elif isinstance(c, list):
                            for item in c:
                                if item.get("type") == "text":
                                    total_chars += len(item.get("text", ""))
                                elif item.get("type") == "tool_result":
                                    content = item.get("content", "")
                                    if isinstance(content, str):
                                        total_chars += len(content)
                                    elif isinstance(content, list):
                                        for b in content:
                                            if isinstance(b, dict):
                                                total_chars += len(b.get("text", ""))

                    elif t == "assistant":
                        for b in e.get("message", {}).get("content", []) or []:
                            if b.get("type") == "text":
                                total_chars += len(b.get("text", ""))
                            elif b.get("type") == "tool_use":
                                total_chars += len(json.dumps(b.get("input", {})))
                            elif b.get("type") == "thinking":
                                total_chars += len(b.get("thinking", ""))

                except (json.JSONDecodeError, KeyError):
                    pass
    except OSError:
        pass

    from regard.core.output import output
    output({"estimated_tokens": total_chars // 4}, None)
