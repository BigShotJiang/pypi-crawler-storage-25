"""Orient commands — status, balance, positions, orders."""

import typer
from pydantic import ValidationError

from regard.core.output import die, output
from regard.venues.polymarket.client import (
    get_clob_client,
    get_collateral_token,
    get_positions,
    get_wallet_balances,
)
from regard.venues.polymarket.main import poly_app
from regard.venues.polymarket.models import ClobOrder


def _get_balance(clob):
    from py_clob_client_v2.clob_types import AssetType, BalanceAllowanceParams
    return clob.get_balance_allowance(BalanceAllowanceParams(asset_type=AssetType.COLLATERAL))


@poly_app.command()
def status(ctx: typer.Context):
    """Account overview — balance, positions, open orders."""
    opts = ctx.obj
    try:
        clob = get_clob_client()
    except SystemExit:
        raise
    except Exception as e:
        die("venue_error", "CLOB_CONNECT_FAILED", str(e), exit_code=4)

    # Balance (USDC allowance on CLOB)
    try:
        balance_resp = _get_balance(clob)
    except SystemExit:
        raise
    except Exception:
        balance_resp = {}

    # Open orders
    try:
        open_orders = clob.get_open_orders()
    except SystemExit:
        raise
    except Exception:
        open_orders = []
    orders = []
    for o in (open_orders if isinstance(open_orders, list) else []):
        try:
            ClobOrder.model_validate(o)
        except ValidationError:
            pass
        orders.append({
            "order_id": o.get("id", ""),
            "market": o.get("market", ""),
            "asset_id": o.get("asset_id", ""),
            "side": o.get("side", ""),
            "price": o.get("price", ""),
            "original_size": o.get("original_size", ""),
            "size_matched": o.get("size_matched", ""),
            "status": o.get("status", ""),
        })

    # On-chain wallet balances + collateral token (best-effort)
    try:
        collateral = get_collateral_token()
    except Exception:
        collateral = {"name": "USDC.e", "address": "", "source": "fallback"}

    try:
        wallet = get_wallet_balances()
    except Exception:
        wallet = {"usdc_e": "?", "usdc": "?", "pol": "?"}

    output({
        "collateral_token": collateral["name"],
        "wallet": wallet,
        "clob_balance": balance_resp.get("balance", "0") if isinstance(balance_resp, dict) else "0",
        "open_orders": orders,
        "open_order_count": len(orders),
    }, opts["fields"])


@poly_app.command()
def balance(ctx: typer.Context):
    """USDC balance and allowance on Polymarket."""
    opts = ctx.obj
    clob = get_clob_client()
    clob_resp = _get_balance(clob)

    try:
        wallet = get_wallet_balances()
    except Exception:
        wallet = {"usdc_e": "?", "usdc": "?", "pol": "?"}

    output({
        "wallet": wallet,
        "clob_balance": clob_resp.get("balance", "0") if isinstance(clob_resp, dict) else "0",
        "allowances": clob_resp.get("allowances", {}) if isinstance(clob_resp, dict) else {},
    }, opts["fields"])


@poly_app.command()
def positions(ctx: typer.Context):
    """Open token positions."""
    opts = ctx.obj

    pos_list = get_positions()

    result = []
    for p in pos_list:
        result.append({
            "asset_id": p.get("asset_id", ""),
            "market": p.get("market", ""),
            "side": p.get("side", ""),
            "size": p.get("size", ""),
            "avg_price": p.get("avg_price", ""),
            "cur_price": p.get("cur_price", ""),
            "pnl": p.get("pnl", ""),
        })

    output(result, opts["fields"])


@poly_app.command()
def orders(ctx: typer.Context):
    """Open orders."""
    opts = ctx.obj
    try:
        clob = get_clob_client()
    except SystemExit:
        raise
    except Exception as e:
        die("venue_error", "CLOB_CONNECT_FAILED", str(e), exit_code=4)

    try:
        open_orders = clob.get_open_orders()
    except SystemExit:
        raise
    except Exception as e:
        die("venue_error", "FETCH_FAILED", str(e), exit_code=4)

    result = []
    for o in (open_orders if isinstance(open_orders, list) else []):
        try:
            ClobOrder.model_validate(o)
        except ValidationError:
            pass
        result.append({
            "order_id": o.get("id", ""),
            "market": o.get("market", ""),
            "asset_id": o.get("asset_id", ""),
            "side": o.get("side", ""),
            "price": o.get("price", ""),
            "original_size": o.get("original_size", ""),
            "size_matched": o.get("size_matched", ""),
            "status": o.get("status", ""),
            "created_at": o.get("created_at", ""),
        })

    output(result, opts["fields"])
