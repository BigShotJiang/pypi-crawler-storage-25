"""Client factory — creates Polymarket CLOB and Gamma API clients."""

import os

import eth_account
import httpx
from pydantic import ValidationError

from regard.core.output import die
from regard.venues.polymarket.models import DataApiPosition


def _validate(model_cls, data, label: str = ""):
    """Validate data against a Pydantic model. Silently passes on failure."""
    try:
        model_cls.model_validate(data)
    except ValidationError:
        pass

GAMMA_BASE_URL = "https://gamma-api.polymarket.com"
CLOB_BASE_URL = "https://clob.polymarket.com"
DEFAULT_POLYGON_RPC = "https://rpc.regard.computer/regard/evm/137"

# Polymarket Polygon mainnet contracts
CONTRACTS = {
    "USDC_E": "0x2791Bca1f2de4661ED88A30C99A7a9449Aa84174",
    "CTF": "0x4D97DCd97eC945f40cF65F87097ACe5EA0476045",
    "CTF_EXCHANGE": "0x4bFb41d5B3570DeFd03C39a9A4D8dE6Bd8B8982E",
    "NEG_RISK_CTF_EXCHANGE": "0xC5d563A36AE78145C45a50134d48A1215220f80a",
    "NEG_RISK_ADAPTER": "0xd91E80cF2E7be2e162c6513ceD06f1dD0dA35296",
}

ERC20_ABI = [
    {"constant": True, "inputs": [{"name": "_owner", "type": "address"}], "name": "balanceOf", "outputs": [{"name": "", "type": "uint256"}], "type": "function"},
    {"constant": True, "inputs": [{"name": "_owner", "type": "address"}, {"name": "_spender", "type": "address"}], "name": "allowance", "outputs": [{"name": "", "type": "uint256"}], "type": "function"},
    {"constant": False, "inputs": [{"name": "_spender", "type": "address"}, {"name": "_value", "type": "uint256"}], "name": "approve", "outputs": [{"name": "", "type": "bool"}], "type": "function"},
]

CTF_ABI = [
    {"constant": True, "inputs": [{"name": "_owner", "type": "address"}, {"name": "_operator", "type": "address"}], "name": "isApprovedForAll", "outputs": [{"name": "", "type": "bool"}], "type": "function"},
    {"constant": False, "inputs": [{"name": "_operator", "type": "address"}, {"name": "_approved", "type": "bool"}], "name": "setApprovalForAll", "outputs": [], "type": "function"},
]

EXCHANGE_ABI = [
    {"constant": True, "inputs": [], "name": "getCollateral", "outputs": [{"name": "", "type": "address"}], "type": "function"},
]

# Known token names by address (for display)
TOKEN_NAMES = {
    "0x2791Bca1f2de4661ED88A30C99A7a9449Aa84174": "USDC.e",
    "0x3c499c542cEF5E3811e1192ce70d8cC03d5c3359": "USDC",
}


def _get_key() -> str:
    key = os.environ.get("POLYMARKET_PRIVATE_KEY")
    if not key:
        # Fallback: read from settings file directly
        from regard.venues.hyperliquid.client import _load_settings_env
        key = _load_settings_env().get("POLYMARKET_PRIVATE_KEY")
    if not key:
        die(
            "auth_error", "NO_KEY",
            "No Polymarket key set",
            hint="Run 'regard auth poly' in a separate terminal to set up credentials",
            exit_code=3,
        )
    return key


def get_address(explicit: str = None) -> str:
    """Get Polygon wallet address. Priority: explicit arg > derived from key."""
    if explicit:
        return explicit
    key = _get_key()
    return eth_account.Account.from_key(key).address


def get_gamma_client() -> httpx.Client:
    """Create Gamma API client (unauthenticated, no geo-restriction)."""
    return httpx.Client(base_url=GAMMA_BASE_URL, timeout=30.0)


DATA_API_BASE = "https://data-api.polymarket.com"


def get_positions(address: str = None, raise_on_error: bool = False) -> list:
    """Fetch current positions from the Polymarket Data API.

    Not geo-restricted (unlike CLOB). Returns normalized list matching
    the field names used throughout the codebase.

    Args:
        raise_on_error: If True, propagate exceptions instead of returning [].
            Use True in killswitch (must know if fetch failed vs empty account).
    """
    if not address:
        address = get_address()
    all_positions = []
    try:
        offset = 0
        limit = 500
        while True:
            resp = httpx.get(
                f"{DATA_API_BASE}/positions",
                params={"user": address, "sizeThreshold": 0, "limit": limit, "offset": offset},
                timeout=30.0,
            )
            resp.raise_for_status()
            page = resp.json()
            if not isinstance(page, list):
                break
            all_positions.extend(page)
            if len(page) < limit:
                break
            offset += limit
    except Exception:
        if raise_on_error:
            raise
        if not all_positions:
            return []
        # Partial results from earlier pages — return what we have

    result = []
    for p in all_positions:
        _validate(DataApiPosition, p, "position")
        size = float(p.get("size", 0) or 0)
        if size == 0:
            continue
        result.append({
            "asset_id": p.get("asset", ""),
            "market": p.get("title", ""),
            "side": "BUY",  # Data API positions are always long (you hold outcome tokens)
            "size": str(size),
            "avg_price": str(p.get("avgPrice", "")),
            "cur_price": str(p.get("curPrice", "")),
            "pnl": str(p.get("cashPnl", "")),
            "condition_id": p.get("conditionId", ""),
            "outcome": p.get("outcome", ""),
            "redeemable": p.get("redeemable", False),
            "mergeable": p.get("mergeable", False),
        })
    return result


def get_clob_client():
    """Create authenticated CLOB client with derived API credentials.

    Geo-restricted — will fail from blocked regions (US, Singapore, etc.).
    Use Dublin VPN for trading.
    """
    from py_clob_client_v2.client import ClobClient

    key = _get_key()
    if not key.startswith("0x"):
        key = f"0x{key}"
    address = eth_account.Account.from_key(key).address

    client = ClobClient(
        CLOB_BASE_URL,
        key=key,
        chain_id=137,
        signature_type=0,
        funder=address,
    )
    creds = client.derive_api_key()
    client.set_api_creds(creds)
    return client


def _make_retry_session():
    """Create a requests Session with retry-on-429 and transient error handling."""
    import requests
    from requests.adapters import HTTPAdapter
    from urllib3.util.retry import Retry

    retry = Retry(
        total=3,
        backoff_factor=1,             # 1s, 2s, 4s
        status_forcelist=[429, 502, 503, 504],
        allowed_methods=["POST"],      # JSON-RPC is always POST
        raise_on_status=False,         # let web3 handle the response
    )
    session = requests.Session()
    session.mount("https://", HTTPAdapter(max_retries=retry))
    session.mount("http://", HTTPAdapter(max_retries=retry))
    return session


def get_web3():
    """Create Web3 client for Polygon mainnet.

    Uses POLYGON_RPC from settings if set (with eRPC as fallback),
    otherwise the default eRPC endpoint. All sessions retry on 429/5xx.
    """
    from web3 import Web3

    from regard.venues.hyperliquid.client import _load_settings_env

    custom = _load_settings_env().get("POLYGON_RPC")
    rpcs = [custom, DEFAULT_POLYGON_RPC] if custom else [DEFAULT_POLYGON_RPC]
    session = _make_retry_session()

    for rpc_url in rpcs:
        try:
            w3 = Web3(Web3.HTTPProvider(rpc_url, session=session, request_kwargs={"timeout": 10}))
            w3.eth.block_number  # verify connectivity (is_connected uses web3_clientVersion which eRPC blocks)
            return w3
        except Exception:
            continue

    return Web3(Web3.HTTPProvider(DEFAULT_POLYGON_RPC, session=session, request_kwargs={"timeout": 30}))


_collateral_cache = None


def clear_collateral_cache():
    """Reset collateral cache. Used by tests to prevent cross-test pollution."""
    global _collateral_cache
    _collateral_cache = None


DECIMALS_ABI = [
    {"constant": True, "inputs": [], "name": "decimals", "outputs": [{"name": "", "type": "uint8"}], "type": "function"},
]


def get_collateral_token(w3=None) -> dict:
    """Discover the collateral token Polymarket uses.

    Reads on-chain from CTF Exchange getCollateral(). Falls back to
    hardcoded USDC.e address if RPC is unavailable. Cached after first call.

    Returns {"address": "0x...", "name": "USDC.e", "decimals": 6, "source": "on-chain"|"fallback"}.
    """
    global _collateral_cache
    if _collateral_cache is not None:
        return _collateral_cache

    if w3 is None:
        w3 = get_web3()

    fallback = CONTRACTS["USDC_E"]

    try:
        exchange = w3.eth.contract(
            address=w3.to_checksum_address(CONTRACTS["CTF_EXCHANGE"]),
            abi=EXCHANGE_ABI,
        )
        address = exchange.functions.getCollateral().call()
        name = TOKEN_NAMES.get(address, "unknown")

        # Read decimals from the token contract
        try:
            token = w3.eth.contract(address=w3.to_checksum_address(address), abi=DECIMALS_ABI)
            decimals = token.functions.decimals().call()
        except Exception:
            decimals = 6  # USDC.e and USDC are both 6

        if address.lower() != fallback.lower():
            import sys
            print(f"warning: collateral token changed to {name} ({address})", file=sys.stderr)

        _collateral_cache = {"address": address, "name": name, "decimals": decimals, "source": "on-chain"}
    except Exception:
        _collateral_cache = {"address": fallback, "name": "USDC.e", "decimals": 6, "source": "fallback"}

    return _collateral_cache


USDC_NATIVE = "0x3c499c542cEF5E3811e1192ce70d8cC03d5c3359"


def get_wallet_balances(w3=None, address=None) -> dict:
    """Get on-chain wallet balances on Polygon (USDC.e, USDC native, POL).

    Returns {"usdc_e": "0.00", "usdc": "5.00", "pol": "2.94", "rpc_ok": true}.
    Sets rpc_ok=false if RPC is unreachable — balances may be stale/wrong.
    """
    if w3 is None:
        w3 = get_web3()
    if address is None:
        address = get_address()

    checksummed = w3.to_checksum_address(address)
    result = {"usdc_e": "0.00", "usdc": "0.00", "pol": "0.00", "rpc_ok": False}

    ok = False
    try:
        pol_wei = w3.eth.get_balance(checksummed)
        result["pol"] = f"{pol_wei / 1e18:.4f}"
        ok = True
    except Exception:
        pass
    try:
        usdc_e = w3.eth.contract(address=w3.to_checksum_address(CONTRACTS["USDC_E"]), abi=ERC20_ABI)
        result["usdc_e"] = f"{usdc_e.functions.balanceOf(checksummed).call() / 1e6:.2f}"
        ok = True
    except Exception:
        pass
    try:
        usdc = w3.eth.contract(address=w3.to_checksum_address(USDC_NATIVE), abi=ERC20_ABI)
        result["usdc"] = f"{usdc.functions.balanceOf(checksummed).call() / 1e6:.2f}"
        ok = True
    except Exception:
        pass

    result["rpc_ok"] = ok
    return result


def check_geo_block():
    """Check if CLOB trading is accessible from current IP.

    Calls a lightweight CLOB endpoint. Dies with actionable hint if blocked.
    """
    try:
        resp = httpx.get(f"{CLOB_BASE_URL}/time", timeout=10.0)
        if resp.status_code == 403:
            die(
                "geo_error", "GEO_BLOCKED",
                "Polymarket trading is restricted from your region",
                hint="Polymarket trading requires a non-US/non-SG IP (e.g. Ireland VPN)",
                exit_code=4,
            )
    except httpx.HTTPError:
        pass  # network error, let the actual trade call handle it
