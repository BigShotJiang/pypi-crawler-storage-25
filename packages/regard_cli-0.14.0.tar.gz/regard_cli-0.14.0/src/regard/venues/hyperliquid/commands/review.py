"""Review commands — trades."""

from typing import Annotated

import typer

from regard.core.output import format_timestamp, make_table, output, parse_time
from regard.main import hl_app
from regard.venues.hyperliquid.client import _validate, get_address, get_info
from regard.venues.hyperliquid.models import Fill
from regard.venues.hyperliquid.resolver import get_resolver


@hl_app.command()
def trades(
    ctx: typer.Context,
    asset: Annotated[str | None, typer.Argument(help="Filter by asset")] = None,
    limit: Annotated[int, typer.Option("--limit", help="Number of trades (max 2000)")] = 20,
    start: Annotated[str | None, typer.Option("--start", help="Start time (ISO 8601)")] = None,
    end: Annotated[str | None, typer.Option("--end", help="End time (ISO 8601)")] = None,
):
    """Recent trade history."""
    opts = ctx.obj
    info = get_info(opts["testnet"])
    addr = get_address()

    resolved = None
    if asset:
        resolver = get_resolver(info)
        resolved = resolver.resolve(asset)

    if start or end:
        start_ms = parse_time(start) if start else 0
        end_ms = parse_time(end) if end else None
        data = info.user_fills_by_time(addr, start_ms, end_ms)
    else:
        data = info.user_fills(addr)

    result = []
    for f in data:
        _validate(Fill, f, "fill")
        coin = f["coin"]
        if resolved and coin != resolved:
            continue
        result.append({
            "asset": coin,
            "side": "buy" if f["side"] == "B" else "sell",
            "direction": f.get("dir", ""),
            "price": f["px"],
            "size": f["sz"],
            "fee": f.get("fee", ""),
            "closed_pnl": f.get("closedPnl", "0"),
            "time": format_timestamp(f.get("time", 0)),
        })

    result = result[-limit:]

    cols = [
        ("asset", "Asset", "<"),
        ("side", "Side", "<"),
        ("direction", "Dir", "<"),
        ("size", "Size", ">"),
        ("price", "Price", ">"),
        ("closed_pnl", "PnL", ">"),
        ("fee", "Fee", ">"),
        ("time", "Time", "<"),
    ]
    display = make_table(result, cols) if result else "No trades"
    output(result, opts["fields"], display=display)


