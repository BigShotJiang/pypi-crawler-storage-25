"""Orient commands — status, balance, positions, orders."""

from typing import Annotated

import typer

from regard.core.output import bar, format_timestamp, make_table, output
from regard.main import hl_app
from regard.venues.hyperliquid.client import (
    get_account_mode,
    get_address,
    get_all_mids,
    get_all_orders,
    get_all_positions,
    get_dex_balances,
    get_info,
    get_spot_balances,
)
from regard.venues.hyperliquid.resolver import get_resolver


def _build_order(o: dict) -> dict:
    """Build a normalized order dict from a frontendOpenOrders entry."""
    is_trigger = o.get("isTrigger", False)
    return {
        "oid": o["oid"],
        "asset": o["coin"],
        "side": "buy" if o["side"] == "B" else "sell",
        "price": o.get("triggerPx", o.get("limitPx", "?")) if o.get("isTrigger") else o.get("limitPx", "?"),
        "size": o.get("origSz") or o["sz"],
        "type": (o.get("orderType") or "Limit").lower(),
        "tif": (o.get("tif") or "").lower() or None,
        "reduce_only": o.get("reduceOnly", False),
        "is_trigger": is_trigger,
        "trigger_condition": o.get("triggerCondition", "") if is_trigger else "",
        "timestamp": format_timestamp(o.get("timestamp", 0)),
    }


@hl_app.command()
def status(
    ctx: typer.Context,
    address: Annotated[str | None, typer.Option("--address", help="Check another address")] = None,
):
    """One-shot account overview: balance + positions + open orders."""
    opts = ctx.obj
    info = get_info(opts["testnet"])
    addr = get_address(address)

    state = info.user_state(addr)
    raw_orders = get_all_orders(info, addr)
    mids = get_all_mids(info)
    account_mode = get_account_mode(info, addr)
    spot_balances = get_spot_balances(info, addr)
    dex_balances = get_dex_balances(info, addr)
    all_pos = get_all_positions(info, addr)

    margin = state.get("marginSummary", state.get("crossMarginSummary", {}))

    positions = []
    total_unrealized = 0.0
    for pos in all_pos:
        size = float(pos["szi"])
        coin = pos["coin"]
        lev = pos["leverage"]
        upnl = pos["unrealizedPnl"]
        total_unrealized += float(upnl)
        positions.append({
            "asset": coin,
            "side": "long" if size > 0 else "short",
            "size": str(abs(size)),
            "entry_price": pos["entryPx"],
            "mark_price": mids.get(coin, ""),
            "unrealized_pnl": upnl,
            "liquidation_price": pos.get("liquidationPx", ""),
            "leverage": str(lev["value"]) if isinstance(lev, dict) else str(lev),
            "margin_used": pos["marginUsed"],
        })

    order_list = [_build_order(o) for o in raw_orders]

    # Total equity = sum of all dex account values (each includes unrealized PnL for that dex)
    total_equity = sum(float(d.get("account_value", 0)) for d in dex_balances)

    result = {
        "account_mode": account_mode,
        "account_value": f"{total_equity:.6f}",
        "withdrawable": state.get("withdrawable", "0"),
        "total_margin_used": margin.get("totalMarginUsed", "0"),
        "total_ntl_pos": margin.get("totalNtlPos", "0"),
        "total_unrealized_pnl": f"{total_unrealized:.6f}",
        "positions": positions,
        "open_orders": order_list,
        "spot_balances": spot_balances,
        "dex_balances": dex_balances,
    }
    output(result, opts["fields"], display=_display_status(result))


@hl_app.command()
def balance(
    ctx: typer.Context,
    address: Annotated[str | None, typer.Option("--address", help="Check another address")] = None,
):
    """Account balance."""
    opts = ctx.obj
    info = get_info(opts["testnet"])
    addr = get_address(address)

    state = info.user_state(addr)
    account_mode = get_account_mode(info, addr)
    spot_balances = get_spot_balances(info, addr)
    dex_balances = get_dex_balances(info, addr)
    margin = state.get("marginSummary", state.get("crossMarginSummary", {}))

    total_equity = sum(float(d.get("account_value", 0)) for d in dex_balances)

    result = {
        "account_mode": account_mode,
        "account_value": f"{total_equity:.6f}",
        "total_margin_used": margin.get("totalMarginUsed", "0"),
        "total_ntl_pos": margin.get("totalNtlPos", "0"),
        "withdrawable": state.get("withdrawable", "0"),
        "spot_balances": spot_balances,
        "dex_balances": dex_balances,
    }
    output(result, opts["fields"], display=_display_balance(result))


@hl_app.command()
def positions(
    ctx: typer.Context,
    asset: Annotated[str | None, typer.Argument(help="Filter by asset")] = None,
    address: Annotated[str | None, typer.Option("--address", help="Check another address")] = None,
):
    """Open positions with P&L."""
    opts = ctx.obj
    info = get_info(opts["testnet"])
    addr = get_address(address)

    all_pos = get_all_positions(info, addr)
    mids = get_all_mids(info)

    resolved = None
    if asset:
        resolver = get_resolver(info)
        resolved = resolver.resolve(asset)

    result = []
    for pos in all_pos:
        size = float(pos["szi"])
        coin = pos["coin"]
        if resolved and coin != resolved:
            continue
        lev = pos["leverage"]
        result.append({
            "asset": coin,
            "side": "long" if size > 0 else "short",
            "size": str(abs(size)),
            "entry_price": pos["entryPx"],
            "mark_price": mids.get(coin, ""),
            "unrealized_pnl": pos["unrealizedPnl"],
            "liquidation_price": pos.get("liquidationPx", ""),
            "leverage": str(lev["value"]) if isinstance(lev, dict) else str(lev),
            "margin_used": pos["marginUsed"],
        })

    output(result, opts["fields"], display=_display_positions(result))


@hl_app.command()
def orders(
    ctx: typer.Context,
    asset: Annotated[str | None, typer.Argument(help="Filter by asset")] = None,
):
    """Open/pending orders."""
    opts = ctx.obj
    info = get_info(opts["testnet"])
    addr = get_address()

    raw = get_all_orders(info, addr)

    resolved = None
    if asset:
        resolver = get_resolver(info)
        resolved = resolver.resolve(asset)

    result = []
    for o in raw:
        if resolved and o["coin"] != resolved:
            continue
        result.append(_build_order(o))

    output(result, opts["fields"], display=_display_orders(result))


@hl_app.command(name="spot-balances")
def spot_balances(ctx: typer.Context):
    """Spot token balances."""
    opts = ctx.obj
    info = get_info(opts["testnet"])
    addr = get_address()
    result = get_spot_balances(info, addr)
    output(result, opts["fields"])


# ---------------------------------------------------------------------------
# Display builders
# ---------------------------------------------------------------------------

_POS_COLS = [
    ("asset", "Asset", "<"),
    ("side", "Side", "<"),
    ("size", "Size", ">"),
    ("entry_price", "Entry", ">"),
    ("mark_price", "Mark", ">"),
    ("unrealized_pnl", "PnL", ">"),
    ("leverage", "Lev", ">"),
    ("margin_used", "Margin", ">"),
]

_ORDER_COLS = [
    ("asset", "Asset", "<"),
    ("side", "Side", "<"),
    ("type", "Type", "<"),
    ("size", "Size", ">"),
    ("price", "Price", ">"),
    ("trigger_condition", "Trigger", "<"),
]


def _display_positions(positions: list[dict]) -> str:
    if not positions:
        return "No open positions"
    return make_table(positions, _POS_COLS)


def _display_orders(orders: list[dict]) -> str:
    if not orders:
        return "No open orders"
    return make_table(orders, _ORDER_COLS)


def _display_balance(data: dict) -> str:
    lines = [
        f"Account value  {data['account_value']} USDC",
        f"Withdrawable   {data['withdrawable']}",
        f"Margin used    {data['total_margin_used']}",
        f"Net position   {data['total_ntl_pos']}",
    ]

    dex_bals = data.get("dex_balances", [])
    if dex_bals:
        max_val = max(float(d.get("account_value", 0)) for d in dex_bals) or 1
        lines.append("")
        lines.append("Dex balances")
        for d in dex_bals:
            val = float(d.get("account_value", 0))
            b = bar(val, max_val, 12)
            pos_count = d.get("positions", 0)
            pos_tag = f"  ({pos_count} pos)" if pos_count else ""
            lines.append(f"  {d['dex']:<10} {b:<13} {d['account_value']}{pos_tag}")

    spot = data.get("spot_balances", [])
    if spot:
        lines.append("")
        lines.append("Spot")
        for s in spot:
            lines.append(f"  {s['token']:<8} {s['balance']}")

    return "\n".join(lines)


def _display_status(data: dict) -> str:
    sections = [_display_balance(data)]

    positions = data.get("positions", [])
    if positions:
        sections.append("")
        sections.append("Positions")
        sections.append(_display_positions(positions))

    orders = data.get("open_orders", [])
    if orders:
        sections.append("")
        sections.append("Orders")
        sections.append(_display_orders(orders))

    return "\n".join(sections)
