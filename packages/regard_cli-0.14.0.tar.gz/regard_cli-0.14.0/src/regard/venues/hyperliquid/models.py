"""Pydantic models for Hyperliquid API response shapes.

These models validate the seam between raw HL API responses and regard-cli's
internal domain. They use extra="ignore" so the CLI never crashes when HL adds
a new field. Tests validate with extra="forbid" to catch schema drift.

Field names match the API exactly (camelCase). Types are permissive where the
API is inconsistent (e.g., leverage as dict or int).

Reference: hyperliquid-python-sdk/hyperliquid/utils/types.py
"""

from __future__ import annotations

from typing import Any

from pydantic import BaseModel, ConfigDict

# --- Shared config ---

_API_CONFIG = ConfigDict(extra="ignore")


# --- Orders ---

class FrontendOrder(BaseModel):
    """A single entry from frontendOpenOrders.

    Known gotcha: triggerPx is always present as a string, even on non-trigger
    orders where it is "0.0" (truthy in Python). Always check isTrigger first.
    """
    model_config = _API_CONFIG

    coin: str
    oid: int
    side: str  # "A" (sell) or "B" (buy)
    limitPx: str
    sz: str
    orderType: str | None = None
    tif: str | None = None
    reduceOnly: bool = False
    timestamp: int = 0
    isTrigger: bool | None = None
    triggerPx: str | None = None
    triggerCondition: str | None = None
    origSz: str | None = None
    cloid: str | None = None
    children: list[FrontendOrder] | None = None
    isPositionTpsl: bool | None = None


# --- Order responses ---

class FilledStatus(BaseModel):
    model_config = _API_CONFIG
    oid: int
    totalSz: str
    avgPx: str


class RestingStatus(BaseModel):
    model_config = _API_CONFIG
    oid: int


class OrderResponseData(BaseModel):
    """Wrapper for the statuses array inside an order response."""
    model_config = _API_CONFIG
    statuses: list[dict[str, Any]]


class OrderResponsePayload(BaseModel):
    model_config = _API_CONFIG
    type: str
    data: OrderResponseData | None = None


class OrderResponse(BaseModel):
    """Top-level order/cancel response from the exchange.

    statuses[i] is one of:
      {"filled": {"oid": int, "totalSz": str, "avgPx": str}}
      {"resting": {"oid": int}}
      {"error": str}
    """
    model_config = _API_CONFIG
    status: str  # "ok" or "err"
    response: OrderResponsePayload | str | None = None


# --- Positions ---

class Position(BaseModel):
    """A single perp position from clearinghouseState.assetPositions[].position.

    leverage is polymorphic:
      - {"type": "cross", "value": 10}
      - {"type": "isolated", "value": 20, "rawUsd": "0.0"}
      - Occasionally a bare int or string in edge cases.
    """
    model_config = _API_CONFIG

    coin: str
    szi: str
    entryPx: str
    unrealizedPnl: str
    liquidationPx: str | None = None
    leverage: dict[str, Any] | int | str = 0
    marginUsed: str = "0"
    returnOnEquity: str | None = None
    positionValue: str | None = None
    maxTradeSzs: list[str] | None = None
    cumFunding: dict[str, str] | None = None


class AssetPosition(BaseModel):
    """Wrapper: assetPositions[] entry."""
    model_config = _API_CONFIG
    position: Position
    type: str | None = None


# --- Account state ---

class MarginSummary(BaseModel):
    model_config = _API_CONFIG
    accountValue: str
    totalMarginUsed: str
    totalNtlPos: str
    totalRawUsd: str | None = None


class UserState(BaseModel):
    model_config = _API_CONFIG
    crossMarginSummary: MarginSummary | None = None
    marginSummary: MarginSummary | None = None
    withdrawable: str = "0"
    assetPositions: list[AssetPosition] = []
    crossMaintenanceMarginUsed: str | None = None
    time: int | None = None


# --- Market metadata ---

class AssetInfo(BaseModel):
    model_config = _API_CONFIG
    name: str
    szDecimals: int
    maxLeverage: int | None = None
    marginTableId: int | None = None
    isDelisted: bool | None = None
    growthMode: str | None = None
    lastGrowthModeChangeTime: str | int | None = None
    onlyIsolated: bool | None = None
    marginMode: str | None = None


class MetaInfo(BaseModel):
    model_config = _API_CONFIG
    universe: list[AssetInfo]


class AssetCtx(BaseModel):
    """Per-asset context from metaAndAssetCtxs[1]."""
    model_config = _API_CONFIG
    markPx: str
    oraclePx: str | None = None
    prevDayPx: str
    funding: str
    openInterest: str
    dayNtlVlm: str
    premium: str | None = None
    midPx: str | None = None
    dayBaseVlm: str | None = None
    impactPxs: list[str] | None = None


# --- Spot ---

class SpotBalance(BaseModel):
    """A single balance entry from spotUserState.balances[].

    Unified format: uses "total" (float string).
    Legacy format: uses "holds"/"withdrawn" (wei strings).
    """
    model_config = _API_CONFIG
    token: int  # token index, not name
    total: str | None = None
    holds: str | None = None
    withdrawn: str | None = None
    coin: str | None = None
    entryNtl: str | None = None
    hold: str | None = None


class SpotTokenMeta(BaseModel):
    model_config = _API_CONFIG
    name: str
    szDecimals: int
    weiDecimals: int
    index: int
    tokenId: str
    isCanonical: bool
    evmContract: dict[str, Any] | str | None = None  # dict on mainnet (address + extra_wei_decimals), str in SDK types
    fullName: str | None = None


class SpotAssetInfo(BaseModel):
    model_config = _API_CONFIG
    name: str
    tokens: list[int]
    index: int
    isCanonical: bool


class SpotMeta(BaseModel):
    model_config = _API_CONFIG
    tokens: list[SpotTokenMeta]
    universe: list[SpotAssetInfo]


class SpotAssetCtx(BaseModel):
    model_config = _API_CONFIG
    markPx: str
    prevDayPx: str
    dayNtlVlm: str
    midPx: str | None = None
    circulatingSupply: str | None = None
    coin: str | None = None


# --- Active asset data ---

class ActiveAssetData(BaseModel):
    model_config = _API_CONFIG
    user: str
    coin: str
    leverage: dict[str, Any] | int | str
    maxTradeSzs: list[str]
    availableToTrade: list[str]
    markPx: str


# --- Order book ---

class L2Level(BaseModel):
    model_config = _API_CONFIG
    px: str
    sz: str
    n: int


class L2Snapshot(BaseModel):
    model_config = _API_CONFIG
    levels: list[list[L2Level]]
    coin: str | None = None
    time: int | None = None


# --- Funding ---

class FundingEntry(BaseModel):
    model_config = _API_CONFIG
    coin: str | None = None
    fundingRate: str
    premium: str | None = None
    time: int


# --- Candles ---

class Candle(BaseModel):
    model_config = _API_CONFIG
    t: int  # timestamp
    o: str  # open
    h: str  # high
    l: str  # low
    c: str  # close
    v: str  # volume
    n: int  # num trades
    T: int | None = None  # close timestamp
    i: str | None = None  # interval
    s: str | None = None  # symbol


# --- Fills ---

class Fill(BaseModel):
    model_config = _API_CONFIG
    coin: str
    px: str
    sz: str
    side: str  # "A" or "B"
    time: int
    dir: str | None = None
    closedPnl: str | None = None
    fee: str | None = None
    hash: str | None = None
    oid: int | None = None
    crossed: bool | None = None
    tid: int | None = None
    twapId: int | None = None
    feeToken: str | None = None
    startPosition: str | None = None


# --- Dex/meta structures ---

class PerpDexInfo(BaseModel):
    """A single dex entry from perpDexs.

    Index 0 is None on mainnet (the default dex). Callers must filter None
    entries before validating: [PerpDexInfo.model_validate(d) for d in perp_dexs if d is not None]
    """
    model_config = _API_CONFIG
    name: str
    fullName: str | None = None
    deployer: str | None = None
    collateralToken: int | None = None
    oracleUpdater: str | None = None
    feeRecipient: str | None = None
    deployerFeeScale: int | float | None = None
    lastDeployerFeeScaleChangeTime: int | str | None = None  # int or ISO datetime string
    subDeployers: list[Any] | None = None  # list of [action, [addresses]] pairs
    assetToFundingMultiplier: list[list[Any]] | dict[str, Any] | None = None  # [[asset, rate], ...]
    assetToFundingInterestRate: list[list[Any]] | dict[str, Any] | None = None
    assetToStreamingOiCap: list[list[Any]] | dict[str, Any] | None = None


class PerpMetaEntry(BaseModel):
    """A single entry from allPerpMetas — one per dex."""
    model_config = _API_CONFIG
    universe: list[AssetInfo]
    collateralToken: int | None = None
    marginTables: Any | None = None
