"""Scraped example library for build123d + Cubit.

Two sources, two layouts:

* **build123d** — GitHub `gumyr/build123d/examples/` (~65 curated Python
  files).  Listing via `api.github.com/repos/.../contents/examples`,
  bodies via `raw.githubusercontent.com`.  One cache file per example.

* **cubit** — Coreform forum (`forum.coreform.com`, Discourse).  Posts
  tagged / matching `tutorial example mesh` are fetched (JSON API),
  markdown code fences (```...```) are extracted as individual snippets.
  Each post becomes one "example" (metadata + concatenated code).

Both layouts serialize to `<state_dir>/examples/{source}/`:
  - `index.json` — list of `{name, title, url, code_path, tokens, token_set}`
  - `<name>.py` / `<name>.jou` — the actual code

The tf-idf retrieval machinery (`search_examples`) is shared with the
lookup tools — same scoring / heading-boost approach.
"""

from __future__ import annotations

import hashlib
import json
import math
import re
import time
import urllib.error
import urllib.parse
import urllib.request
from pathlib import Path
from typing import Any

from .failure_log import state_dir
from .web_docs import _USER_AGENT, _TIMEOUT_SECONDS


_WORD_RE = re.compile(r"[a-zA-Z_][a-zA-Z0-9_]*")
_CODE_FENCE_RE = re.compile(r"```[a-z]*\n?([\s\S]*?)```", re.MULTILINE)
_REFRESH_TTL_SECONDS = 7 * 24 * 3600  # one week


def _examples_dir(source: str) -> Path:
	d = state_dir() / "examples" / source
	d.mkdir(parents=True, exist_ok=True)
	return d


def _index_path(source: str) -> Path:
	return _examples_dir(source) / "index.json"


def _tokenize(s: str) -> list[str]:
	"""Lower-case identifier tokens + their underscore-split sub-tokens.

	`roller_coaster` indexes as both `roller_coaster` and `roller` +
	`coaster`, so both the exact identifier and free-form queries match.
	"""
	out: list[str] = []
	for m in _WORD_RE.finditer(s):
		w = m.group(0).lower()
		out.append(w)
		if "_" in w:
			out.extend(p for p in w.split("_") if p)
	return out


def _http_get(url: str, accept: str = "text/plain") -> bytes | None:
	req = urllib.request.Request(url, headers={
		"User-Agent": _USER_AGENT,
		"Accept": accept,
	})
	try:
		with urllib.request.urlopen(req, timeout=_TIMEOUT_SECONDS) as resp:  # noqa: S310
			return resp.read()
	except (urllib.error.HTTPError, urllib.error.URLError,
	        TimeoutError, OSError):
		return None


def _safe_name(s: str) -> str:
	"""Sanitize a filename component."""
	return re.sub(r"[^A-Za-z0-9_.-]+", "_", s)[:96] or "unnamed"


# ---------------------------------------------------------------------------
# build123d: GitHub `gumyr/build123d/examples/*.py`
# ---------------------------------------------------------------------------

_BUILD123D_LIST_URL = ("https://api.github.com/repos/gumyr/build123d/"
                       "contents/examples")


def refresh_build123d_examples(limit: int = 0) -> dict:
	"""Fetch the build123d examples folder from GitHub and populate the cache.

	Args:
	    limit: cap on number of files to fetch (0 = all).

	Returns stats dict: {fetched, failed, total, index_path}.
	"""
	raw = _http_get(_BUILD123D_LIST_URL, accept="application/vnd.github+json")
	if not raw:
		return {"status": "error", "error": "GitHub listing fetch failed"}
	try:
		listing = json.loads(raw)
	except json.JSONDecodeError as e:
		return {"status": "error", "error": f"listing JSON decode: {e}"}
	if not isinstance(listing, list):
		return {"status": "error",
		        "error": f"unexpected listing shape: {str(listing)[:200]}"}

	py_files = [f for f in listing
	            if isinstance(f, dict) and f.get("name", "").endswith(".py")]
	if limit > 0:
		py_files = py_files[:limit]

	d = _examples_dir("build123d")
	index: list[dict[str, Any]] = []
	fetched = 0
	failed: list[str] = []

	for f in py_files:
		name = f.get("name", "")
		dl = f.get("download_url")
		if not (name and dl):
			failed.append(name)
			continue
		body_raw = _http_get(dl, accept="text/plain")
		if body_raw is None:
			failed.append(name)
			continue
		body = body_raw.decode("utf-8", errors="replace")

		code_path = d / _safe_name(name)
		try:
			code_path.write_text(body, encoding="utf-8")
		except OSError:
			failed.append(name)
			continue

		# Extract title from docstring/comments
		title = _guess_python_title(body, fallback=name)
		tokens = _tokenize(body)
		index.append({
			"name": name,
			"title": title,
			"url": f.get("html_url")
			       or f"https://github.com/gumyr/build123d/blob/dev/examples/{name}",
			"code_path": str(code_path),
			"size": f.get("size", 0),
			"tokens": tokens,
			"token_set": sorted(set(tokens)),
		})
		fetched += 1

	index_data = {
		"fetched_at": time.time(),
		"source": "build123d",
		"items": index,
	}
	_index_path("build123d").write_text(
		json.dumps(index_data, ensure_ascii=False, indent=2),
		encoding="utf-8",
	)
	return {
		"status": "ok",
		"fetched": fetched,
		"failed": failed,
		"total": len(py_files),
		"index_path": str(_index_path("build123d")),
	}


def _guess_python_title(body: str, fallback: str) -> str:
	"""Pick a 1-line title from a Python file.

	Priority: module docstring first line → first comment line → fallback.
	"""
	# Module docstring
	m = re.match(r'\s*(?:[ru]?["\']{3})([\s\S]*?)["\']{3}', body)
	if m:
		first = m.group(1).strip().splitlines()
		if first:
			return first[0][:120]
	# First `# ...` comment line
	for line in body.splitlines()[:20]:
		ls = line.strip()
		if ls.startswith("#") and len(ls) > 1:
			return ls.lstrip("# ").strip()[:120]
	return fallback


# ---------------------------------------------------------------------------
# cubit: Discourse forum (forum.coreform.com)
# ---------------------------------------------------------------------------

_CUBIT_FORUM_BASE = "https://forum.coreform.com"
_CUBIT_QUERIES = [
	"tutorial example mesh",
	"hex meshing tutorial",
	"sweep scheme example",
	"journal file example",
	"radia_export example",
]


def refresh_cubit_examples(limit_per_query: int = 5) -> dict:
	"""Fetch Cubit example snippets from the Coreform forum.

	For each seed query, hits `/search.json`, takes up to `limit_per_query`
	top posts, fetches each post's raw markdown, extracts triple-backtick
	code fences as one concatenated journal snippet per post.

	Args:
	    limit_per_query: max posts per query (default 5).

	Returns stats dict.
	"""
	d = _examples_dir("cubit")
	seen_post_ids: set[int] = set()
	index: list[dict[str, Any]] = []
	fetched = 0
	failed: list[str] = []

	for q in _CUBIT_QUERIES:
		url = (f"{_CUBIT_FORUM_BASE}/search.json?q="
		       + urllib.parse.quote(q))
		raw = _http_get(url, accept="application/json")
		if raw is None:
			failed.append(f"search: {q}")
			continue
		try:
			search_json = json.loads(raw)
		except json.JSONDecodeError:
			failed.append(f"search json: {q}")
			continue
		topics_by_id = {t["id"]: t for t in search_json.get("topics", [])
		                if isinstance(t, dict)}
		posts = search_json.get("posts", [])[:limit_per_query]
		for post in posts:
			pid = post.get("id")
			if not pid or pid in seen_post_ids:
				continue
			seen_post_ids.add(pid)
			post_url = f"{_CUBIT_FORUM_BASE}/posts/{pid}.json"
			praw = _http_get(post_url, accept="application/json")
			if praw is None:
				failed.append(f"post {pid}")
				continue
			try:
				pdata = json.loads(praw)
			except json.JSONDecodeError:
				failed.append(f"post json {pid}")
				continue
			body = pdata.get("raw") or ""
			fences = _CODE_FENCE_RE.findall(body)
			if not fences:
				continue
			code = "\n\n# ---- next snippet ----\n\n".join(
				f.strip() for f in fences if f.strip()
			)
			if not code:
				continue

			topic = topics_by_id.get(post.get("topic_id"), {})
			title = topic.get("title", "") or f"forum post {pid}"
			slug = topic.get("slug", "")
			tid = topic.get("id", post.get("topic_id"))
			pnum = post.get("post_number", 1)
			html_url = (f"{_CUBIT_FORUM_BASE}/t/{slug}/{tid}/{pnum}"
			            if slug and tid else f"{_CUBIT_FORUM_BASE}/p/{pid}")

			name = f"{_safe_name(title)[:60]}__p{pid}.jou"
			code_path = d / name
			# Store both prose and code so retrieval indexes both
			blob = (f"# {title}\n# source: {html_url}\n# "
			        f"post id: {pid}\n\n# --- prose ---\n"
			        + "\n".join("# " + line for line in body.splitlines()[:60])
			        + "\n\n# --- code ---\n" + code + "\n")
			try:
				code_path.write_text(blob, encoding="utf-8")
			except OSError:
				failed.append(name)
				continue

			tokens = _tokenize(blob)
			index.append({
				"name": name,
				"title": title,
				"url": html_url,
				"code_path": str(code_path),
				"post_id": pid,
				"tokens": tokens,
				"token_set": sorted(set(tokens)),
			})
			fetched += 1

	index_data = {
		"fetched_at": time.time(),
		"source": "cubit",
		"items": index,
	}
	_index_path("cubit").write_text(
		json.dumps(index_data, ensure_ascii=False, indent=2),
		encoding="utf-8",
	)
	return {
		"status": "ok",
		"fetched": fetched,
		"failed": failed,
		"posts_seen": len(seen_post_ids),
		"index_path": str(_index_path("cubit")),
	}


# ---------------------------------------------------------------------------
# Retrieval
# ---------------------------------------------------------------------------

def _load_index(source: str) -> dict:
	p = _index_path(source)
	if not p.exists():
		return {"fetched_at": 0, "items": []}
	try:
		return json.loads(p.read_text(encoding="utf-8"))
	except (OSError, json.JSONDecodeError):
		return {"fetched_at": 0, "items": []}


def _is_stale(index: dict, ttl: int = _REFRESH_TTL_SECONDS) -> bool:
	return time.time() - float(index.get("fetched_at", 0)) > ttl


REFRESH_FUNCS = {
	"build123d": refresh_build123d_examples,
	"cubit": refresh_cubit_examples,
}


def search_examples(source: str, query: str, limit: int = 5,
                    force_refresh: bool = False,
                    auto_refresh_if_empty: bool = True) -> dict:
	"""tf-idf search across cached examples for `source`.

	Args:
	    source: "build123d" or "cubit".
	    query: keywords (AND-scored, stop-words stripped).
	    limit: cap on returned examples.
	    force_refresh: re-scrape ignoring cache.
	    auto_refresh_if_empty: if the cache is empty or stale, scrape
	        before searching. Default True.

	Returns dict with `results`: each hit has title / url / score /
	excerpt (first 1600 chars of code) / full_path.
	"""
	if force_refresh or (auto_refresh_if_empty and _is_stale(_load_index(source))):
		fn = REFRESH_FUNCS.get(source)
		if fn is None:
			return {"status": "error",
			        "error": f"unknown source {source!r}",
			        "known": list(REFRESH_FUNCS.keys())}
		fn()

	idx = _load_index(source)
	items = idx.get("items", [])
	if not items:
		return {"status": "ok", "source": source, "query": query,
		        "results": [], "note": "empty index"}

	q_terms = [t for t in _tokenize(query or "")]
	if not q_terms:
		return {"status": "error", "error": "empty query"}

	# idf
	n = max(1, len(items))
	idf: dict[str, float] = {}
	for t in q_terms:
		df = sum(1 for it in items if t in (it.get("token_set") or []))
		idf[t] = math.log((n + 1) / (df + 1)) + 1.0

	scored: list[tuple[float, dict]] = []
	for it in items:
		tokens = it.get("tokens") or []
		if not tokens:
			continue
		tf: dict[str, int] = {}
		for tok in tokens:
			tf[tok] = tf.get(tok, 0) + 1
		inv_len = 1.0 / (1.0 + math.log(1 + len(tokens)))
		score = 0.0
		hits = 0
		for term in q_terms:
			f = tf.get(term, 0)
			if f == 0:
				continue
			hits += 1
			score += (1.0 + math.log(f)) * idf.get(term, 1.0) * inv_len
		if hits == 0:
			continue
		# title boost
		title_lc = (it.get("title") or "").lower()
		head_hits = sum(1 for t in q_terms if t in title_lc)
		if head_hits:
			score *= 1.0 + 0.75 * head_hits
		score *= 1.0 + 0.25 * (hits / max(1, len(q_terms)))
		scored.append((score, it))

	scored.sort(key=lambda x: (-x[0], x[1].get("name", "")))
	top = scored[: max(1, int(limit))]

	results: list[dict] = []
	for score, it in top:
		excerpt = ""
		p = Path(it.get("code_path", ""))
		if p.exists():
			try:
				excerpt = p.read_text(encoding="utf-8", errors="replace")[:1600]
			except OSError:
				pass
		results.append({
			"name": it.get("name"),
			"title": it.get("title"),
			"url": it.get("url"),
			"score": round(score, 3),
			"excerpt": excerpt,
			"path": it.get("code_path"),
		})

	return {
		"status": "ok",
		"source": source,
		"query": query,
		"total_indexed": len(items),
		"fetched_at": idx.get("fetched_at"),
		"results": results,
	}
