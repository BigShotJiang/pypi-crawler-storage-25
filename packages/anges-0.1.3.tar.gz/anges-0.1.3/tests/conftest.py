import pytest
from dotenv import load_dotenv
import os

def pytest_configure(config):
    """Load environment variables before any tests run"""
    # Load from .env file
    load_dotenv()