from openai import OpenAI
from anthropic import AnthropicVertex
import anthropic
import logging
import functools
import subprocess
import time
from anges.config import config
import os


OPENAI_API_KEY = os.environ.get("OPENAI_API_KEY") or config.model_api.openai.api_key or ""
DEEPSEEK_API_KEY = os.environ.get("DEEPSEEK_API_KEY") or config.model_api.deepseek.api_key or ""
GEMINI_API_KEY = os.environ.get("GEMINI_API_KEY") or config.model_api.genai_gemini.api_key or ""
ANTHROPIC_API_KEY = os.environ.get("ANTHROPIC_API_KEY") or config.model_api.anthropic.api_key or ""


# Default model versions from configuration
OAI_MODEL = config.model_api.openai.model

CLAUDE_MODEL = config.model_api.anthropic.model

GEMINI_MODEL = config.model_api.gemini.model

DEEPSEEK_MODEL = config.model_api.deepseek.model
VERTEX_CLAUDE_MODEL = config.model_api.vertex_claude.model


def _get_gcloud_config(key):
    """Get a value from gcloud config, trying CLI first then config files."""
    try:
        result = subprocess.run(
            ["gcloud", "config", "get-value", key],
            capture_output=True, text=True, timeout=5
        )
        value = result.stdout.strip()
        if value and value != "(unset)":
            return value
    except (subprocess.SubprocessError, FileNotFoundError):
        pass

    # Fallback: read from gcloud config files directly (works without gcloud CLI)
    import configparser
    config_paths = [
        os.path.join(os.environ.get("CLOUDSDK_CONFIG", os.path.expanduser("~/.config/gcloud")), "configurations", "config_default"),
        os.path.join(os.environ.get("CLOUDSDK_CONFIG", os.path.expanduser("~/.config/gcloud")), "properties"),
    ]
    # key format: "project" → [core]/project, "compute/region" → [compute]/region
    parts = key.rsplit("/", 1)
    if len(parts) == 2:
        section, option = parts
    else:
        section, option = "core", parts[0]

    cp = configparser.ConfigParser()
    for path in config_paths:
        if os.path.exists(path):
            cp.read(path)
            try:
                return cp.get(section, option)
            except (configparser.NoSectionError, configparser.NoOptionError):
                continue
    return ""


def _resolve_vertex_config():
    """Resolve Vertex AI GCP project and region, falling back to gcloud config."""
    project = config.model_api.vertex_claude.gcp_project
    region = config.model_api.vertex_claude.gcp_region
    if not project:
        project = os.environ.get("GOOGLE_CLOUD_PROJECT") or os.environ.get("GCLOUD_PROJECT") or _get_gcloud_config("project")
    if not region:
        region = os.environ.get("GOOGLE_CLOUD_REGION") or _get_gcloud_config("compute/region") or "us-east5"
    return project, region


VERTEX_GCP_PROJECT, VERTEX_GCP_REGION = _resolve_vertex_config()

# Lazy-initialized clients
_vertex_claude_client = None
_oai_client = None
_anthropic_claude_client = None


def _get_vertex_claude_client():
    global _vertex_claude_client
    if _vertex_claude_client is None:
        if not VERTEX_GCP_PROJECT:
            raise ValueError(
                "Vertex AI requires a GCP project. Set it via:\n"
                "  1. gcloud config set project <PROJECT_ID>, or\n"
                "  2. GOOGLE_CLOUD_PROJECT env var, or\n"
                "  3. vertex_claude.gcp_project in ~/.anges/config.yaml"
            )
        _vertex_claude_client = AnthropicVertex(region=VERTEX_GCP_REGION, project_id=VERTEX_GCP_PROJECT)
    return _vertex_claude_client


def _get_oai_client():
    global _oai_client
    if _oai_client is None:
        if not OPENAI_API_KEY:
            raise ValueError(
                "OpenAI requires an API key. Set it via:\n"
                "  1. OPENAI_API_KEY env var, or\n"
                "  2. openai.api_key in ~/.anges/config.yaml"
            )
        _oai_client = OpenAI(api_key=OPENAI_API_KEY)
    return _oai_client


def _get_anthropic_claude_client():
    global _anthropic_claude_client
    if _anthropic_claude_client is None:
        if not ANTHROPIC_API_KEY:
            raise ValueError(
                "Anthropic Claude requires an API key. Set it via:\n"
                "  1. ANTHROPIC_API_KEY env var, or\n"
                "  2. anthropic.api_key in ~/.anges/config.yaml"
            )
        _anthropic_claude_client = anthropic.Anthropic(api_key=ANTHROPIC_API_KEY)
    return _anthropic_claude_client


def retry_on_quota_exceeded(max_attempts=30, initial_delay=1.0, backoff_factor=2):
    """A decorator for retrying a function call with exponential backoff on quota errors.

    Retries if the error message contains "Quota exceeded" or "Content has no parts".

    Args:
        max_attempts: Maximum number of attempts.
        initial_delay: Initial delay between retries in seconds.
        backoff_factor: Factor by which the delay increases after each retry.
    """
    def decorator(func):
        @functools.wraps(func)
        def wrapper(*args, **kwargs):
            attempts = 0
            delay = initial_delay
            while attempts < max_attempts:
                try:
                    return func(*args, **kwargs)
                except Exception as e:
                    if (
                        "429" in str(e)
                        or "529" in str(e)
                        or "503" in str(e)
                        or "Quota exceeded" in str(e)
                        or "Content has no parts" in str(e)
                        or "Cannot get the response text" in str(e)
                    ) and attempts < max_attempts:
                        logging.warning(
                            f"Retriable error: {e}, retrying {attempts + 1}/{max_attempts} in {delay:.1f}s"
                        )
                        time.sleep(delay)
                        delay *= backoff_factor
                        attempts += 1
                    else:
                        logging.error(f"Final attempt failed or non-quota error: {e}")
                        raise
        return wrapper
    return decorator


def deepseek_inference(prompt, temperature=0.6):
    """Performs inference using Deepseek's API."""
    from openai import OpenAI
    client = OpenAI(api_key=DEEPSEEK_API_KEY, base_url="https://api.deepseek.com")
    response = client.chat.completions.create(
        model=DEEPSEEK_MODEL,
        messages=[
            {"role": "system", "content": ""},
            {"role": "user", "content": prompt},
        ],
        temperature=temperature,
        stream=False
    )
    response_text = response.choices[0].message.content
    if "</think>" in response_text:
        response_text = response_text.split("</think>")[-1]
    return response_text


def openai_inference(prompt, temperature=0.3):
    """Performs inference using OpenAI's API."""
    completion = _get_oai_client().chat.completions.create(
        model=OAI_MODEL,
        messages=[
            {"role": "system", "content": ""},
            {"role": "user", "content": prompt},
        ],
        temperature=temperature,
    )
    return completion.choices[0].message.content


def anthropic_claude_inference(prompt, temperature=0.3):
    """Performs inference using Anthropic's API."""
    message = _get_anthropic_claude_client().messages.create(
        model=CLAUDE_MODEL,
        max_tokens=8096,
        temperature=temperature,
        messages=[
            {
                "role": "user",
                "content": [
                    {
                        "type": "text",
                        "text": prompt,
                    }
                ]
            }
        ]
    )
    return message.content[0].text


@retry_on_quota_exceeded()
def vertex_claude_inference(prompt, temperature=0.6, enforce_json=False):
    """Performs inference using Anthropic's Claude API via Vertex AI."""
    message = _get_vertex_claude_client().messages.create(
        max_tokens=8096,
        messages=[{"role": "user", "content": prompt}],
        model=VERTEX_CLAUDE_MODEL,
        temperature=temperature,
    )
    return message.content[0].text


@retry_on_quota_exceeded()
def genai_gemini_model(prompt, temperature: float = 0.3, enforce_json=False):
    from google import genai
    from google.genai import types
    api_key = GEMINI_API_KEY
    client = genai.Client(
        api_key=api_key,
    )
    model = config.model_api.genai_gemini.model
    contents = [
        types.Content(
            role="user",
            parts=[
                types.Part.from_text(text=prompt),
            ],
        ),
    ]
    mime_type = "application/json" if enforce_json else "text/plain"
    generate_content_config = types.GenerateContentConfig(
        response_mime_type=mime_type,
    )

    response = client.models.generate_content(
        model=model,
        contents=contents,
        config=generate_content_config,
    )
    return response.text


@retry_on_quota_exceeded()
def gemini_inference(prompt, temperature: float = 0.3, enforce_json=True):
    from google import genai
    from google.genai import types
    api_key = GEMINI_API_KEY
    if api_key:
        client = genai.Client(
            api_key=api_key,
        )
    else:
        client = genai.Client(
            vertexai=True,
            project=VERTEX_GCP_PROJECT,
            location="global",
        )
    model = config.model_api.gemini.model
    contents = [
        types.Content(
            role="user",
            parts=[
                types.Part.from_text(text=prompt),
            ],
        ),
    ]
    if enforce_json:
        mime_type = "application/json"
    else:
        mime_type = "text/plain"
    generate_content_config = types.GenerateContentConfig(
        response_mime_type=mime_type,
        temperature=temperature,
        safety_settings = [types.SafetySetting(
        category="HARM_CATEGORY_HATE_SPEECH",
        threshold="OFF"
        ),types.SafetySetting(
        category="HARM_CATEGORY_DANGEROUS_CONTENT",
        threshold="OFF"
        ),types.SafetySetting(
        category="HARM_CATEGORY_SEXUALLY_EXPLICIT",
        threshold="OFF"
        ),types.SafetySetting(
        category="HARM_CATEGORY_HARASSMENT",
        threshold="OFF"
        )],
    )
    response = client.models.generate_content(
        model=model,
        contents=contents,
        config=generate_content_config,
    )
    return response.text

# Dictionary mapping inference function names to their implementations
INFERENCE_FUNC_DICT = {
    "openai": openai_inference,
    "vertex_claude": vertex_claude_inference,
    "gemini": gemini_inference,
    "genai_gemini": genai_gemini_model,
    "deepseek": deepseek_inference,
    "claude": anthropic_claude_inference,
}
