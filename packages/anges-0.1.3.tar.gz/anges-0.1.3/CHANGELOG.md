# Changelog

All notable changes to the Anges project will be documented in this file.

## [0.1.1] - 2024-08-19

### Improved
- **Chat Interface Enhancements**:
  - Fixed chat info display color theme from purple to neutral white/light grey
  - Implemented K/M notation for large numbers in token usage display (e.g., 61.7K instead of 61660)
  - Added text truncation with ellipsis for long chat titles to prevent multi-line wrapping
  - Reduced chat item height by adjusting vertical padding for better visual density
  - Enhanced overall user experience and visual organization of chat drawer

## [Unreleased]

### Added
- **Notes Feature**:
  - Added notes from CLI and UI
  - Prompt tuning

## [0.1.0] - 2025-07-15

### Added
Anges is an open-source engineering agent system designed to be install-and-go, but also highly customizable and minimalist.
