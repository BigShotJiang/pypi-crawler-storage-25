# Documentation TODO: panelmark-web

All panelmark-docs links in this file use the base:
`https://github.com/sirrommit/panelmark-docs/blob/main/docs`

---

## README.md

### 1 — Add "Not Implemented" section

The current README lists what is implemented but does not state what is absent.
After the "## What it includes" section (ends around line 37), add:

```markdown
## What is not implemented

The following optional interactions and widgets from the portable library are
**not** implemented in this version:

| Item | Type | Notes |
|------|------|-------|
| `TreeView` | Interaction | Not implemented |
| `DatePicker` | Widget | Not implemented |
| `Progress` | Widget | Not implemented |
| `Spinner` | Widget | Not implemented |
| `Toast` | Widget | Not implemented |

See the [interaction coverage matrix](docs/interaction-coverage.md) for the full
status of every portable interaction, widget, and draw command.
```

### 2 — Add also-implemented interactions note

After "## What it includes", before the "Not Implemented" section added above,
add a note that panelmark-web also implements three frequently-used optional
interactions beyond the 8 required portable ones:

```markdown
Beyond the 8 required portable interactions, `panelmark-web` also implements:
`MenuFunction`, `ListView`, `TableView`.
```

Add this as a sentence/paragraph below the Interactions and Widgets bullet
points in "## What it includes".

### 3 — Add CursorCmd note to Compatibility status section

The compatibility section (lines 52–70) already mentions `CursorCmd` is ignored
on line 58. Confirm line 58 reads:
`- draw-command execution (\`WriteCmd\`, \`FillCmd\`; \`CursorCmd\` ignored)`

If it reads differently, update it to match exactly. No other change needed in
that section.

### 4 — Replace relative docs/ links with panelmark-docs links

The following relative links exist in the README and must be updated:

- Line 37: `[docs/interaction-coverage.md](docs/interaction-coverage.md)`
  → replace with local repo link (this file lives in this repo):
  `[interaction coverage matrix](docs/interaction-coverage.md)` — **keep as-is**;
  `docs/interaction-coverage.md` is a repo-local file (see Local docs section below).

- Line 67: second `[docs/interaction-coverage.md](docs/interaction-coverage.md)`
  → same as above; keep as-is.

- Line 87: `[docs/getting-started.md](docs/getting-started.md)`
  → replace with panelmark-docs link:
  `[docs/getting-started.md](https://github.com/sirrommit/panelmark-docs/blob/main/docs/panelmark-web/getting-started.md)`

The `examples/` links on lines 91–92 are repo-local and correct; leave them
unchanged.

### 5 — Add Documentation Links section

After the "## Quick start" section (currently the last section), add:

```markdown
## Documentation

| Document | Description |
|----------|-------------|
| [Getting Started](https://github.com/sirrommit/panelmark-docs/blob/main/docs/panelmark-web/getting-started.md) | Step-by-step guide: interaction definition, FastAPI/Flask wiring, browser setup |
| [Interaction Coverage](docs/interaction-coverage.md) | Status matrix: every portable interaction, widget, and draw command |
| [WebSocket Protocol](docs/protocol.md) | Client→server and server→client message format; key mapping reference |
| [Hook Usage](docs/hook-usage.md) | How panelmark-web reads and writes the panelmark-html DOM hook contract |
| [DOM Hook Contract](https://github.com/sirrommit/panelmark-html/blob/main/docs/hook-contract.md) | Stable DOM interface defined by panelmark-html that this package depends on |
| [Portable Library Spec](https://github.com/sirrommit/panelmark-docs/blob/main/docs/renderer-spec/portable-library.md) | Normative spec for all 8 portable interactions and 6 portable widgets |
| [Renderer Spec](https://github.com/sirrommit/panelmark-docs/blob/main/docs/renderer-spec/overview.md) | Core renderer contract; compatibility levels; extension policy |
| [Shell Language](https://github.com/sirrommit/panelmark-docs/blob/main/docs/shell-language/overview.md) | ASCII-art layout syntax reference |
| [Ecosystem Overview](https://github.com/sirrommit/panelmark-docs/blob/main/docs/ecosystem.md) | How panelmark-web fits into the panelmark package ecosystem |
```

### 6 — Shorten portable list in "What it includes"

The current "What it includes" section lists all 8 portable interactions and all
6 portable widgets by name. Shorten to a reference rather than a full
enumeration. Replace the two bullet points with:

```markdown
- **Interactions** (`panelmark_web.interactions`): all 8 required portable
  interactions — `StatusMessage`, `MenuReturn`, `RadioList`, `CheckBox`,
  `TextBox`, `NestedMenu`, `FormInput`, `DataclassFormInteraction` — plus
  `MenuFunction`, `ListView`, `TableView`.
  See [portable library spec](https://github.com/sirrommit/panelmark-docs/blob/main/docs/renderer-spec/portable-library.md)
  for the full normative specification.

- **Widgets** (`panelmark_web.widgets`): all 6 required portable widgets —
  `Alert`, `Confirm`, `InputPrompt`, `ListSelect`, `DataclassForm`, `FilePicker`.
  Web-specific note: widgets are async/non-blocking; see
  [overview](https://github.com/sirrommit/panelmark-docs/blob/main/docs/panelmark-web/overview.md)
  for the async widget model.
```

---

## Local docs/ folder

Three files exist in `docs/`. Each must be audited:

### docs/interaction-coverage.md

- [ ] This file is repo-local and repo-specific (tracks implementation status
  for this renderer). **Keep it.** Verify the matrix is current:
  - All 8 portable interactions: `StatusMessage`, `MenuReturn`, `NestedMenu`,
    `RadioList`, `CheckBox`, `TextBox`, `FormInput`, `DataclassFormInteraction`
    should be marked implemented.
  - All 6 portable widgets: `Alert`, `Confirm`, `InputPrompt`, `ListSelect`,
    `DataclassForm`, `FilePicker` should be marked implemented.
  - Optional implemented: `MenuFunction`, `ListView`, `TableView` — mark implemented.
  - Not implemented: `TreeView`, `DatePicker`, `Progress`, `Spinner`, `Toast` —
    mark not implemented.
  - Draw commands: `WriteCmd` ✅, `FillCmd` ✅, `CursorCmd` — mark as "accepted,
    ignored" (not an error, just a no-op).
  - Update any stale entries and add any missing rows.

### docs/getting-started.md

- [ ] This file is mirrored at
  `https://github.com/sirrommit/panelmark-docs/blob/main/docs/panelmark-web/getting-started.md`.
  Compare both versions:
  - If panelmark-docs is more complete, update this local file to match and add
    a header:
    ```markdown
    > **Note:** This document is also available on
    > [panelmark-docs](https://github.com/sirrommit/panelmark-docs/blob/main/docs/panelmark-web/getting-started.md).
    ```
  - If the local file is more complete, note the gap for panelmark-docs maintainers;
    do not delete the local copy.
  - README link to `docs/getting-started.md` was replaced with the panelmark-docs
    URL in step 4 above. Confirm the local file is not orphaned by checking for
    any remaining links to it:
    `grep -rn "docs/getting-started" . --include="*.md"`

### docs/hook-contract-web.md

- [ ] Read this file. It likely documents how panelmark-web reads/writes the
  panelmark-html hook contract (equivalent to
  `https://github.com/sirrommit/panelmark-docs/blob/main/docs/panelmark-web/hook-usage.md`).
  - Compare against the panelmark-docs version.
  - Rename this file to `docs/hook-usage.md` to match the canonical name used in
    the Documentation table added in step 5 above.
  - Add a header to the renamed file:
    ```markdown
    > **Note:** This document is also mirrored at
    > [panelmark-docs](https://github.com/sirrommit/panelmark-docs/blob/main/docs/panelmark-web/hook-usage.md).
    ```
  - Confirm no other file links to the old name `docs/hook-contract-web.md` after
    the rename:
    `grep -rn "hook-contract-web" . --include="*.md"`

### docs/protocol.md (check existence)

- [ ] Run: `ls /home/sirrommit/claude_play/panelmark-web/docs/`
  If `docs/protocol.md` does not exist, create it by fetching the content from:
  `https://github.com/sirrommit/panelmark-docs/blob/main/docs/panelmark-web/protocol.md`
  and adding this header at the top:
  ```markdown
  > **Note:** This document is also mirrored at
  > [panelmark-docs](https://github.com/sirrommit/panelmark-docs/blob/main/docs/panelmark-web/protocol.md).
  ```
  If it already exists, compare against panelmark-docs and sync, adding the same header.

---

## Validation

- [ ] Grep for any remaining relative `docs/getting-started` links in README:
  `grep -n "docs/getting-started" README.md`
  Result must be empty (replaced with panelmark-docs URL in step 4).

- [ ] Confirm "Not implemented" section is present:
  `grep -n "not implemented\|Not Implemented\|What is not" README.md`

- [ ] Confirm `CursorCmd` is mentioned in the Compatibility section:
  `grep -n "CursorCmd" README.md`

- [ ] Confirm `docs/hook-contract-web.md` has been renamed to `docs/hook-usage.md`:
  `ls /home/sirrommit/claude_play/panelmark-web/docs/`
  Should show `hook-usage.md`, not `hook-contract-web.md`.

- [ ] Confirm `docs/protocol.md` exists.

- [ ] Run tests (doc-only change — if no automated check exists, state that
  explicitly in the commit message):
  `cd /home/sirrommit/claude_play/panelmark-web && PYTHONPATH=/home/sirrommit/claude_play/panelmark-web:/home/sirrommit/claude_play/panelmark:/home/sirrommit/claude_play/panelmark-html pytest -q`

- [ ] Review `git diff --stat` and confirm only `README.md`, `docs/` files are
  changed. No Python source changes.

- [ ] Commit:
  ```
  docs: add not-implemented list, documentation links section, fix relative links; rename hook-contract-web.md to hook-usage.md
  ```

- [ ] Push to `origin main`.
