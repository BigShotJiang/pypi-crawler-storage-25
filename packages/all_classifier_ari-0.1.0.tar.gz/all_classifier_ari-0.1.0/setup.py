from setuptools import setup, find_packages
import all_classifier

with open("README.md", "r", encoding="utf-8") as file:
    long_desc = file.read()

setup(
    name="all-classifier-ari",
    version=all_classifier.__version__,
    author="ArıBilgi Fan",
    author_email="aribilgiogr@gmail.com",
    description="Test multiple classification models and return their performance metric values.",
    long_description=long_desc,
    long_description_content_type="text/markdown",
    packages=find_packages(),
    install_requires=[
        "pandas",
        "scikit-learn",
        "xgboost",
        "lightgbm"
    ],
    license="MIT",
    classifiers=[
        "License :: OSI Approved :: MIT License",
        "Programming Language :: Python :: 3",
        "Operating System :: OS Independent"
    ],
    python_requires=">=3.11",
    url="https://github.com/aribilgiogr/all_classifier"
)
