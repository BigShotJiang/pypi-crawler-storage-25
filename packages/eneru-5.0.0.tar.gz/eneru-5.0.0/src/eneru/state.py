"""Monitor state tracking for Eneru."""

from dataclasses import dataclass, field
from collections import deque


@dataclass
class MonitorState:
    """Tracks the current state of the UPS monitor."""
    previous_status: str = ""
    on_battery_start_time: int = 0
    extended_time_logged: bool = False
    voltage_state: str = "NORMAL"
    avr_state: str = "INACTIVE"
    bypass_state: str = "INACTIVE"
    overload_state: str = "INACTIVE"
    connection_state: str = "OK"
    connection_lost_time: float = 0.0
    connection_flap_count: int = 0
    connection_first_flap_time: float = 0.0
    stale_data_count: int = 0
    voltage_warning_low: float = 0.0
    voltage_warning_high: float = 0.0
    nominal_voltage: float = 230.0
    battery_history: deque = field(default_factory=lambda: deque(maxlen=1000))
    # Battery anomaly detection (recalibration, sudden drops while online)
    last_battery_charge: float = -1.0  # -1 = not yet initialized
    last_battery_charge_time: float = 0.0
    # Sustained-reading confirmation: anomaly must persist across 3 consecutive
    # polls to filter out transient firmware jitter after OB→OL transitions
    # (known behavior on APC, CyberPower, and Ubiquiti UniFi UPS units).
    pending_anomaly_charge: float = -1.0  # -1 = no pending anomaly
    pending_anomaly_prev_charge: float = 0.0
    pending_anomaly_time: float = 0.0
    pending_anomaly_count: int = 0  # consecutive polls confirming the anomaly
