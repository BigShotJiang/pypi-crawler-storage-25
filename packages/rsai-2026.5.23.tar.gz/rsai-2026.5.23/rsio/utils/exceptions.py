"""
@File    : exceptions.py.py
@Time    : 2025/7/17 上午9:03
@Author  : xiashuobad
@Desc    : 

/**
 * _ooOoo_
 * o8888888o
 * 88" . "88
 * (| -_- |)
 *  O\ = /O
 * ___/`---'\____
 * .   ' \\| |// `.
 * / \\||| : |||// \
 * / _||||| -:- |||||- \
 * | | \\\ - /// | |
 * | \_| ''\---/'' | |
 * \ .-\__ `-` ___/-. /
 * ___`. .' /--.--\ `. . __
 * ."" '< `.___\_<|>_/___.' >'"".
 * | | : `- \`.;`\ _ /`;.`/ - ` : | |
 * \ \ `-. \_ __\ /__ _/ .-` / /
 * ======`-.____`-.___\_____/___.-`____.-'======
 * `=---=' bug泛滥 佛已瘫痪
"""


# rsio/core/exceptions.py


class BaseError(Exception):
    """图像操作基类异常"""
    desc = ""

    def __init__(self, *args):
        if not args:
            args = (self.desc,)
        super().__init__(*args)


class CV2ArrayTypeError(BaseError):
    """cv2图像数组类型错误"""
    desc = 'img_array格式有误！cv2格式要求为numpy.ndarray，shape为：(H, W, C)或(H, W)！'


class PILArrayTypeError(CV2ArrayTypeError):
    """PIL图像数组类型错误"""
    desc = 'img_array格式有误！PIL格式要求为numpy.ndarray，shape为：(H, W, C)或(H, W)！'


class GdalArrayTypeError(CV2ArrayTypeError):
    """PIL图像数组类型错误"""
    desc = 'img_array格式有误！gdal格式要求为numpy.ndarray，shape为：(C, H, W)或(H, W)！'


class RasterioArrayTypeError(CV2ArrayTypeError):
    """PIL图像数组类型错误"""
    desc = 'img_array格式有误！rasterio格式要求为numpy.ndarray，shape为：(C, H, W)或(H, W)！'


class ImageOpenError(BaseError):
    """打开图像失败"""
    desc = '打开图像文件失败！'


class ImageModeError(BaseError):
    """图像模式错误"""
    desc = '图片文件打开模式设置错误！'


class ImageReadError(BaseError):
    """读取图像array数据失败"""
    desc = '读取图像array数据失败！'


class ImageWriteError(BaseError):
    """写入图像数据失败"""
    desc = '写入图像数据失败！'


class NoImageDataError(BaseError):
    """图像数据文件对象为空"""
    desc = '图像数据文件对象为空！'


class ImageProcessError(BaseError):
    """图片处理错误"""
    desc = '图片处理错误！'


class ImageShowError(BaseError):
    """图片显示错误"""
    desc = '图片显示错误！'


class NotSupportError(BaseError):
    desc = '不支持该操作！'
