"""
Author: xiash$
Date: 2025/9/30$
Project: open-image$
Description: $
***
* _ooOoo_
* o8888888o
* 88" . "88
* (| -_- |)
*  O\ = /O
* ___/`---'\____
* .   ' \\| |// `.
* / \\||| : |||// \
* / _||||| -:- |||||- \
* | | \\\ - /// | |
* | \_| ''\---/'' | |
* \ .-\__ `-` ___/-. /
* ___`. .' /--.--\ `. . __
* ."" '< `.___\_<|>_/___.' >'"".
* | | : `- \`.;`\ _ /`;.`/ - ` : | |
* \ \ `-. \_ __\ /__ _/ .-` / /
* ======`-.____`-.___\_____/___.-`____.-'======
* `=---='
*          .............................................
*           佛曰：bug泛滥，我已瘫痪！
"""
import mercantile
import numpy as np

from pathlib import Path
from typing import Any
from osgeo import ogr, gdal, osr


# ---------------- 矢量相关工具函数----------------
def safe_create_shp_field(ogr_layer: ogr.Layer, field_name: str, field_type: int):
    """
    安全的创建shp字段
    :param ogr_layer: ogr.Layer
    :param field_name: shp字段名称
    :param field_type: shp字段数据类型，如 ogr.OFTString
    :return:
    """
    # 检查字段是否已存在
    layer_defn = ogr_layer.GetLayerDefn()
    field_index = layer_defn.GetFieldIndex(field_name)
    if field_index >= 0 and layer_defn.GetFieldDefn(field_index).GetType() != field_type:
        # 先删除现有字段
        ret = ogr_layer.DeleteField(field_index)
        if ret != 0:
            raise ValueError(f"无法创建字段: {field_name}！")
    if field_index < 0 or layer_defn.GetFieldDefn(field_index).GetType() != field_type:
        # 创建新字段
        field_defn = ogr.FieldDefn(field_name, field_type)
        ogr_layer.CreateField(field_defn)


def copy_data_source(src_data_source: ogr.DataSource, save_shp_path: str):
    """
    复制数据源
    :param src_data_source: 源数据源
    :param save_shp_path: 保存路径
    :return:
    """
    Path(save_shp_path).parent.mkdir(parents=True, exist_ok=True)
    shp_driver: ogr.Driver = ogr.GetDriverByName("ESRI Shapefile")
    shp_driver.CopyDataSource(src_data_source, save_shp_path)
    with open(Path(save_shp_path).with_suffix('.cpg'), 'w', encoding='utf-8') as f:
        f.write('GBK')


def create_shp_data(
        geo_projection: str = None,
        geom_type=ogr.wkbPolygon,
        layer_name='layer'
) -> tuple[ogr.DataSource, ogr.Layer]:
    """
    创建shp数据
    :param geo_projection: 投影信息
    :param geom_type: 几何类型，如ogr.wkbPolygon
    :param layer_name: 图层名称
    :return: ogr.DataSource, ogr.Layer
    """
    shp_driver: ogr.Driver = ogr.GetDriverByName("Memory")  # 创建矢量内存驱动
    dst_shp_ds: ogr.DataSource = shp_driver.CreateDataSource('')  # 创建文件资源
    proj = osr.SpatialReference()  # 创建坐标系类
    proj.ImportFromWkt(geo_projection if geo_projection else '')  # 导入坐标系
    dst_layer: ogr.Layer = dst_shp_ds.CreateLayer(layer_name, geom_type=geom_type, srs=proj)
    return dst_shp_ds, dst_layer


# --------------------------- 栅格处理相关工具函数 -----------------------------
def read_image_data(raster_path: str, backend: str = "gdal") -> Any:
    """
    读取栅格数据
    :param raster_path: 栅格数据路径
    :param backend: 使用的后端库名称
    :return: gdal.Dataset
    """
    img_data = None
    match backend:
        case "gdal":
            img_data = gdal.Open(raster_path)
            if not img_data:
                raise ValueError(f"无法打开图片: {raster_path}！")
        case "rasterio":
            import rasterio
            img_data = rasterio.open(raster_path)
        case "pil":
            from PIL import Image
            img_data = Image.open(raster_path)
        case 'cv2':
            import cv2
            img_data = cv2.imdecode(np.fromfile(raster_path, dtype=np.uint8), cv2.IMREAD_UNCHANGED)
        case _:
            raise ValueError(f"不支持的backend: {backend}！")

    return img_data


def copy_rasterio_data(img_data: 'rasterio.DatasetReader | rasterio.io.DatasetWriter', dst_path: str):
    import rasterio
    from ..backends import RasterioImage
    Path(dst_path).parent.mkdir(parents=True, exist_ok=True)
    profile = img_data.profile
    RasterioImage.write_array(dst_path, img_data.read(), profile.get('transform'), profile.get('crs'),
                              profile.get('nodata'), RasterioImage.colormap(img_data))
    copied_data: rasterio.DatasetReader = rasterio.open(dst_path, 'r+')
    return copied_data


def crop_gdal_data(
        image: gdal.Dataset,
        x_off: int = 0,
        y_off: int = 0,
        window_x_size: int = None,
        window_y_size: int = None,
        dst: str = ''
) -> gdal.Dataset:
    from ..backends import GDALImage
    x_off, y_off, window_x_size, window_y_size = GDALImage.checked_crop_window(image.RasterXSize, image.RasterYSize,
                                                                               x_off, y_off, window_x_size,
                                                                               window_y_size)
    img_data: gdal.Dataset = gdal.Translate(
        dst,
        image,
        srcWin=[x_off, y_off, window_x_size, window_y_size],
        format='GTiff',
    )
    return img_data


def crop_rasterio_data(
        image: 'rasterio.datasetBase',
        x_off: int = 0,
        y_off: int = 0,
        window_x_size: int = None,
        window_y_size: int = None,
        save_path: str = ''
) -> 'rasterio.datasetReader':
    import rasterio
    from rasterio.windows import Window
    from ..backends import RasterioImage
    x_off, y_off, window_x_size, window_y_size = RasterioImage.checked_crop_window(image.width, image.height, x_off,
                                                                                   y_off, window_x_size, window_y_size)
    window = Window(x_off, y_off, window_x_size, window_y_size)
    cropped_array = image.read(window=window)
    # 需要根据新的窗口位置更新 transform
    out_transform = image.window_transform(window)
    profile: dict = image.profile
    profile.update(dict(height=window_y_size, width=window_x_size, transform=out_transform))
    img_data: rasterio.io.DatasetWriter = rasterio.open(save_path, 'w+', **profile)
    img_data.write(cropped_array)
    return img_data

# ------------------------------ ogc相关工具函数 -----------------------------
