"""
@File    : rsio.py.py
@Time    : 2025/7/15 下午5:21
@Author  : xiashuobad
@Desc    : 

/**
 * _ooOoo_
 * o8888888o
 * 88" . "88
 * (| -_- |)
 *  O\ = /O
 * ___/`---'\____
 * .   ' \\| |// `.
 * / \\||| : |||// \
 * / _||||| -:- |||||- \
 * | | \\\ - /// | |
 * | \_| ''\---/'' | |
 * \ .-\__ `-` ___/-. /
 * ___`. .' /--.--\ `. . __
 * ."" '< `.___\_<|>_/___.' >'"".
 * | | : `- \`.;`\ _ /`;.`/ - ` : | |
 * \ \ `-. \_ __\ /__ _/ .-` / /
 * ======`-.____`-.___\_____/___.-`____.-'======
 * `=---=' bug泛滥 佛已瘫痪
"""
# rsio/rsio.py
import os
import numpy as np
import math
import pyproj

os.environ['PROJ_DATA'] = pyproj.datadir.get_data_dir()

from functools import reduce
from pathlib import Path
from typing import Union, Generator
from itertools import product
from osgeo import osr
from loguru import logger

from .backends import ImageBackend
from .utils import ArrayShapeConverter, GeoConverter

# gdal.SetCacheMax(0)
# if util.find_spec('rasterio'):
#     import rasterio
#
#     rasterio.Env(GDAL_CACHEMAX=0).__enter__()


class OpenImage:
    registered_backends = ImageBackend.registered_backends

    def __init__(self, fp: Union[str, Path], mode: str = 'r', backend: str = 'gdal', **kwargs):
        self.backend_image: ImageBackend = self.registered_backends[backend](fp, mode, **kwargs)
        self.backend_name = backend

    def __enter__(self) -> 'OpenImage|ImageBackend':
        return self

    def __exit__(self, exc_type, exc_val, exc_tb):
        self.backend_image.close()

    def __getattr__(self, attr):
        return getattr(self.backend_image, attr)

    def set_backend_image(self, backend_image):
        self.backend_image = backend_image
        return self

    @property
    def pixel_size(self) -> tuple[float, float]:
        """
        像素大小/像元大小
        :return: (x_pixel_size,y_pixel_size)
        """
        geo_transform = GeoConverter.geo_transform2gdal(self.geo_transform)
        x_pixel_size, y_pixel_size = geo_transform[1], geo_transform[5]
        return x_pixel_size, y_pixel_size

    def sliding_window_tiles(
            self,
            window_size: int | tuple[int, int] = (512, 512),
            stride: int | tuple[int, int] | list[int] = None,
            max_tiles: int = None,
            band_indexes: int | list[int] = None
    ):
        """
        滑动窗口对大图像进行切片，返回一个生成器
        @param window_size: 窗口大小, (width,height)
        @param stride: 步长, (x_stride,y_stride)
        @param max_tiles: 最大切片数量，默认切割所有，设置后会限制切片数量
        @param band_indexes: 波段索引，默认切割所有波段
        @return:
        """
        if isinstance(window_size, int):
            window_size = (window_size, window_size)
        if len(window_size) == 1:
            window_size = window_size * 2

        for count, (x, y) in enumerate(OpenImage.sliding_window_x_y(self.width, self.height, window_size, stride),
                                       start=1):
            yield self.backend_image.read_window_array(x, y, *window_size, band_indexes), (x, y)
            if max_tiles and count == max_tiles:
                break

    def count_tiles(
            self,
            stride: int | tuple[int, int] | list[int]
    ) -> int:
        """
        计算滑动窗口切片数量
        @param stride: 步长, (x_stride,y_stride)
        @return:
        """
        if isinstance(stride, int):
            stride = (stride, stride)
        stride_x, stride_y = stride[0], stride[-1]
        return math.ceil(self.width / stride_x) * math.ceil(self.height / stride_y)

    def reproject(self,
                  dst_srs_obj: 'int|str|OpenImage',
                  dst_width=None,
                  dst_height=None,
                  num_threads: int = 2) -> 'OpenImage|ImageBackend':
        """
        对图片进行重投影
        :param dst_srs_obj: 参考投影对象，支持int类型epsg代码 xxxx，字符串格式 "epsg:xxxx","EPSG:xxxx"，wkt字符串，或者OpenImage对象
        :param dst_width: 目标宽度
        :param dst_height: 目标高度
        :param num_threads: 重投影的线程数
        :return: 重投影后的图片对象
        """
        if isinstance(dst_srs_obj, OpenImage):
            dst_srs_obj = dst_srs_obj.backend_image
        self.backend_image.reproject(dst_srs_obj, dst_width, dst_height, num_threads)
        return self

    def valid_mask(self):
        """
        计算本图像的有效值掩码
        """
        return OpenImage.valid_mask_of_image(self.img_array)

    def image_blocks(self, num_blocks) -> Generator[tuple[ImageBackend, tuple[int, int]], None, None]:
        """
        图像均匀分块
        @param num_blocks: 分块数量
        @return: 返回所有的图像块
        """
        rows, cols = OpenImage.calculate_rows_cols_for_blocks(self.width, self.height, num_blocks)
        block_width = math.ceil(self.width / cols)
        block_height = math.ceil(self.height / rows)
        list_x = list(range(0, self.width - block_width, block_width)) + [self.width - block_width]
        list_y = list(range(0, self.height - block_height, block_height)) + [self.height - block_height]
        for x, y in product(list_x, list_y):
            image = self.cropped(self.backend_image, x, y, block_width, block_height)
            yield image, (x, y)

    def crop_by_geojson(self, geojson: dict | list[dict]|str):
        """
        根据地理区域裁剪图片
        :param geojson: 地理范围
        :return: 裁剪后的图片对象
        """
        assert self.backend_name == 'rasterio', "该功能需要使用rasterio后端！"
        self.backend_image.crop_by_geojson(geojson)

        return self

    @staticmethod
    def sliding_window_x_y(
            width: int,
            height: int,
            window_size: int | tuple[int, int] = (512, 512),
            stride: int | tuple[int, int] | list[int] = None,
    ):
        if isinstance(window_size, int):
            window_size = (window_size, window_size)
        if len(window_size) == 1:
            window_size = window_size * 2
        if not stride:
            stride = window_size
        if isinstance(stride, int):
            stride = (stride, stride)
        list_x = list(range(0, width - window_size[0], stride[0])) + [width - window_size[0]]
        list_y = list(range(0, height - window_size[-1], stride[-1])) + [height - window_size[-1]]
        return product(list_x, list_y)

    @staticmethod
    def write_array(file_path: str | Path, array: np.ndarray, backend: str = 'gdal', **kwargs):
        OpenImage.registered_backends[backend].write_array(file_path, array, **kwargs)

    @staticmethod
    def show_image(img_array: np.ndarray, window_name: str = 'image', backend: str = 'pil'):
        """
        显示指定图像array
        :param img_array:
        :param window_name:
        :param backend:
        :return:
        """
        OpenImage.registered_backends[backend].show_image(img_array, window_name)

    @staticmethod
    def resize_img(
            img_array: np.ndarray,
            target_size: tuple[int, int] | int,
            keep_ratio: bool = False,
            pad: int = None,
            resample: int = 1,
            box: list[int] | tuple[int, int, int, int] = None,
            backend: str = 'cv2',
            **kwargs
    ) -> np.ndarray:
        """
        对指定图像array进行resize
        :param img_array: 图像array
        :param target_size: (width,height)
        :param keep_ratio: 是否保持宽高比
        :param pad: keep_ratio为True时进行pad填充
        :param resample: 重采样策略，同cv2：0,1,2,3,4 分别对应 cv2.INTER_NEAREST，cv2.INTER_LINEAR,cv2.INTER_CUBIC,
                        cv2.INTER_AREA,cv2.INTER_LANCZOS4
        :param box: 指定窗口resize，[x_min,y_min,x_max,y_max]
        :param backend: 后端名称，cv2，pil，gdal，rasterio
        :return: resize后的array
        """
        return OpenImage.registered_backends[backend].resize_img(
            img_array,
            target_size,
            keep_ratio,
            pad,
            resample,
            box,
            **kwargs
        )

    @staticmethod
    def reversed_rgb(img_array: np.ndarray, backend: str = 'cv2') -> np.ndarray:
        """
        :param img_array: numpy数组
        :param backend: 后端名称，['gdal','cv2','pil','rasterio']
        :return: 反转后的数组
        """
        return OpenImage.registered_backends[backend].reversed_rgb(img_array)

    @staticmethod
    def intersection_bounds(bounds_list: list[tuple[float, float, float, float]]):
        """
        计算多个bounds的公共区域的边界框bounds
        bounds: (left,top,right,bottom)
        @param bounds_list: [bounds1,bounds2,...]，
        @return:
        """

        # 初始化为第一个bounds
        intersection_left, intersection_top, intersection_right, intersection_bottom = bounds_list[0]

        # 依次与后续的bounds求交集
        for bounds in bounds_list[1:]:
            left, top, right, bottom = bounds

            # 更新交集边界
            intersection_left = max(intersection_left, left)
            intersection_top = min(intersection_top, top)  # top是较大的y值
            intersection_right = min(intersection_right, right)
            intersection_bottom = max(intersection_bottom, bottom)  # bottom是较小的y值

            # 检查是否还有交集
            if intersection_left >= intersection_right or intersection_top <= intersection_bottom:
                return None

        return intersection_left, intersection_top, intersection_right, intersection_bottom

    @staticmethod
    def intersection_image(image_list: list['OpenImage|ImageBackend']) -> list['OpenImage']:
        """
        求多个OpenImage对象的公共地理区域后并返回各自修改后的OpenImage
        @param image_list: OpenImage列表
        @return:
        """
        assert len(image_list) >= 2
        geo_projection = image_list[0].geo_projection
        for image in image_list[1:]:
            if not OpenImage.is_same_projection(geo_projection, image.geo_projection):
                logger.warning(f'{image.file_name} 与原图投影不一致，将进行投影转换...')
                image.reproject(geo_projection)
        bounds_list = [image.geo_bounds for image in image_list]
        if any(not OpenImage.is_equal_bounds(bounds_list[0], bounds) for bounds in bounds_list[1:]):
            intersection_geo_bounds = OpenImage.intersection_bounds(bounds_list)
            if intersection_geo_bounds is None:
                raise ValueError("这些图像没有公共地理区域！")
            logger.info(f'截取图像的公共地理区域...')
            for image in image_list:
                image.crop_by_geo_bounds(intersection_geo_bounds)
        return image_list

    @staticmethod
    def is_same_projection(proj1: int | str, proj2: int | str) -> bool:
        """
        使用GDAL比较两个投影信息是否表示相同的坐标系
        """
        proj1 = GeoConverter.geo_projection2wkt(proj1)
        proj2 = GeoConverter.geo_projection2wkt(proj2)
        # 创建空间参考对象
        srs1 = osr.SpatialReference()
        srs2 = osr.SpatialReference()
        # 导入投影信息
        if srs1.ImportFromWkt(proj1) != 0:
            # 如果不是WKT格式，尝试其他格式
            srs1.ImportFromProj4(proj1)
        if srs2.ImportFromWkt(proj2) != 0:
            srs2.ImportFromProj4(proj2)
        # 标准化坐标系
        srs1.AutoIdentifyEPSG()
        srs2.AutoIdentifyEPSG()
        # 比较是否相同
        return srs1.IsSame(srs2)

    @staticmethod
    def is_equal_bounds(bounds1, bounds2, rtol=1e-9, atol=1e-12):
        """
        比较两个地理边界是否相等（考虑浮点数精度）

        Args:
            bounds1: 第一个边界 (min_x, max_y, max_x, min_y)
            bounds2: 第二个边界 (min_x, max_y, max_x, min_y)
            rtol: 相对容差
            atol: 绝对容差

        Returns:
            bool: 是否相等
        """
        return np.allclose(bounds1, bounds2, rtol=rtol, atol=atol)

    @staticmethod
    def valid_mask_of_image(img_array: np.ndarray):
        """
            计算所给图像的有效值掩码,即多个通道不全为0或者不全为255的为有效
            :param img_array:
            :return:
        """
        img_array = ArrayShapeConverter.array_shape_to_gdal(img_array)
        mask_nodata1 = img_array != 0
        mask_nodata2 = img_array != 255
        if img_array.ndim == 3:  # 如果是rgb影像，需要对多个通道进行判断有效值，并转为单通道掩码，与最终预测结果shape保持一致
            mask_nodata1 = reduce(lambda _x, _y: _x | _y, mask_nodata1)  # 多个通道取并，即只要任意一个通道不是无效值，就判断为有效
            mask_nodata2 = reduce(lambda _x, _y: _x | _y, mask_nodata2)
        return mask_nodata1 * mask_nodata2

    @staticmethod
    def calculate_rows_cols_for_blocks(image_width, image_height, num_blocks):
        """
        计算将图像分割成指定数量的面积相近的块的最优方案

        Args:
            image_width (int): 原始图像的宽度
            image_height (int): 原始图像的高度
            num_blocks (int): 要分割的块数

        Returns:
            tuple: (rows, cols) 表示在行和列上的分割数
        """
        if num_blocks <= 0:
            raise ValueError("num_blocks must be a positive integer")

        # 寻找最优的行列分割数
        best_rows, best_cols = 1, num_blocks
        best_diff = float('inf')

        # 遍历所有可能的因数组合
        for rows in range(1, int(math.sqrt(num_blocks)) + 1):
            if num_blocks % rows == 0:
                cols = num_blocks // rows
                # 计算每个块的尺寸
                block_width = image_width / cols
                block_height = image_height / rows
                # 计算宽高差值
                diff = abs(block_width - block_height)

                # 检查当前组合是否更优
                if diff < best_diff:
                    best_diff = diff
                    best_rows, best_cols = rows, cols

                # 也检查行列互换的情况
                block_width_alt = image_width / rows
                block_height_alt = image_height / cols
                diff_alt = abs(block_width_alt - block_height_alt)

                if diff_alt < best_diff:
                    best_diff = diff_alt
                    best_rows, best_cols = cols, rows

        return best_rows, best_cols


def open_image(file_path: str, mode: str = 'r', backend: str = 'gdal', **kwargs) -> ImageBackend | OpenImage:
    return OpenImage(file_path, mode, backend, **kwargs)
