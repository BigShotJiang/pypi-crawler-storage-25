"""
Author: xiash$
Date: 2025/8/9$
Project: open-image$
Description: $
***
* _ooOoo_
* o8888888o
* 88" . "88
* (| -_- |)
*  O\ = /O
* ___/`---'\____
* .   ' \\| |// `.
* / \\||| : |||// \
* / _||||| -:- |||||- \
* | | \\\ - /// | |
* | \_| ''\---/'' | |
* \ .-\__ `-` ___/-. /
* ___`. .' /--.--\ `. . __
* ."" '< `.___\_<|>_/___.' >'"".
* | | : `- \`.;`\ _ /`;.`/ - ` : | |
* \ \ `-. \_ __\ /__ _/ .-` / /
* ======`-.____`-.___\_____/___.-`____.-'======
* `=---='
*          .............................................
*           佛曰：bug泛滥，我已瘫痪！
"""

# 导入所需的库和模块
import json  # 用于JSON数据的读写
import sys  # 用于系统相关的参数和函数
import numpy as np  # 用于科学计算
import random  # 用于生成随机数
import atexit  # 用于注册退出时的处理函数
import uuid
from functools import partial  # 用于偏函数应用
from typing import Union, Any  # 用于类型提示
from pathlib import Path  # 用于路径操作
from concurrent.futures import ProcessPoolExecutor, as_completed  # 用于并行处理
from rich.progress import Progress, MofNCompleteColumn, TimeElapsedColumn  # 用于进度条显示
from rich.panel import Panel  # 用于面板显示
from rich import print  # 用于美化输出
from collections import Counter  # 用于计数
from itertools import product  # 用于生成笛卡尔积
from loguru import logger  # 用于日志记录

# 导入自定义模块
from .open_image import open_image, OpenImage  # 用于图像打开和处理
from .enums import ImageFormat  # 用于图像格式枚举
from .open_shp import open_shp  # 用于shapefile文件打开
from .utils import setup_logger, is_seq_of  # 用于工具函数
from .utils.converters import ColorTypeConverter, PaletteConverter  # 用于数据类型转换


def _build_one_json_shape(contour_array, label_name):
    """将opencv轮廓转为labelme shape格式"""
    points = [[float(pt[0][0]), float(pt[0][1])] for pt in contour_array]
    if len(points) < 3:
        return None
    return {
        "label": label_name,
        "score": None,
        "points": points,
        "group_id": None,
        "description": "",
        "difficult": False,
        "shape_type": "polygon",
        "flags": {},
        "attributes": {},
        "kie_linking": []
    }


def _process_contours_recursive(contours, hierarchy, contour_idx, class_name, label_array, class_names, shapes):
    """
    递归处理轮廓树，支持环形嵌套结构
    @param contours: 所有轮廓列表
    @param hierarchy: 轮廓层级关系 [next, prev, first_child, parent]
    @param contour_idx: 当前轮廓索引
    @param class_name: 当前轮廓所属类别名称
    @param label_array: 标签数组，用于判断孔洞内的实际类别
    @param class_names: 类别名称列表
    @param shapes: 结果shapes列表
    """
    if contour_idx < 0 or contour_idx >= len(contours):
        return
    # 构建当前轮廓的shape
    shape = _build_one_json_shape(contours[contour_idx], class_name)
    if shape is not None:
        shapes.append(shape)
    # 遍历子轮廓（孔洞）
    child_idx = hierarchy[contour_idx][2]
    while child_idx != -1:
        # 孔洞内部可能嵌套其他类别，通过孙子轮廓确定实际类别
        grandchild_idx = hierarchy[child_idx][2]
        if grandchild_idx != -1:
            # 孔洞内存在嵌套对象，取第一个孙子轮廓的采样点确定孔洞的实际类别
            sample_point = tuple(int(v) for v in contours[grandchild_idx][0][0])
            hole_class_id = int(label_array[sample_point[1], sample_point[0]])
            hole_class_name = class_names[hole_class_id] if hole_class_id < len(class_names) else class_names[0]
        else:
            # 孔洞内无嵌套对象，标记为背景
            hole_class_name = class_names[0]
        # 添加孔洞shape
        hole_shape = _build_one_json_shape(contours[child_idx], hole_class_name)
        if hole_shape is not None:
            shapes.append(hole_shape)
        # 递归处理孔洞内部的嵌套轮廓
        _process_contours_recursive(contours, hierarchy, grandchild_idx, hole_class_name, label_array, class_names,
                                    shapes)
        # 移动到下一个同级孔洞
        child_idx = hierarchy[child_idx][0]


def _get_save_directory_by_cycle(index: int, directories_dict: dict, ratios: list) -> tuple:
    """
    根据循环模式分配保存目录，确保数据均匀分布
    @param index: 图片序号（从1开始）
    @param directories_dict: 目录字典，如 {'train':'训练集', 'val':'验证集', 'test':'测试集'}
    @param ratios: 对应比例，如 [0.7, 0.2, 0.1]，会转换为 [7, 2, 1] 的循环模式
    @return: 应该保存到的目录路径
    """
    if len(directories_dict) != len(ratios):
        raise ValueError("目录数量和比例数量必须相同!")
    list_directories = list(directories_dict.keys())
    if len(list_directories) == 1:
        save_dir = list_directories[0]
        return save_dir, directories_dict[save_dir]
    # 将比例转换为整数循环模式
    # 例如 [0.7, 0.2, 0.1] -> [7, 2, 1]
    # 找到最小比例单位
    min_ratio = min(ratios)
    cycle_pattern = [round(r / min_ratio) for r in ratios]
    # 构建循环序列
    cycle_sequence = []
    for dir_idx, count in enumerate(cycle_pattern):
        cycle_sequence.extend([list_directories[dir_idx]] * count)
    # 根据索引循环分配
    cycle_length = len(cycle_sequence)
    sequence_index = (index - 1) % cycle_length
    save_dir = cycle_sequence[sequence_index]
    return save_dir, directories_dict[save_dir]


def overlab_ratio(image_bounds: tuple, intersection_bounds: tuple):
    """
    计算交集区域与图像区域的面积比例
    参数:
        image_bounds: 包含图像边界坐标的元组，格式为 (x1, y1, x2, y2)
        intersection_bounds: 包含交集区域边界坐标的元组，格式为 (x1, y1, x2, y2)
    返回:
        float: 交集区域面积与图像区域面积的比值
    """
    # 计算交集区域的宽度
    intersection_w = (intersection_bounds[2] - intersection_bounds[0])
    # 计算交集区域的高度
    intersection_h = abs(intersection_bounds[1] - intersection_bounds[3])
    # 计算图像区域的宽度
    image_w = (image_bounds[2] - image_bounds[0])
    # 计算图像区域的高度
    image_h = abs(image_bounds[1] - image_bounds[3])
    # 返回交集区域面积与图像区域面积的比值
    return intersection_w * intersection_h / (image_w * image_h)


def draw_images(
        draws,  # 绘图对象或绘图对象列表
        draw_type,  # 绘制类型，支持'line'或'text'
        *,  # 后面的参数为关键字参数，必须使用关键字传递
        contour=None,  # 轮廓坐标点列表（用于绘制线条）
        contour_width=None,  # 轮廓线条宽度
        fill=None,  # 填充颜色
        center_xy=None,  # 文本中心坐标位置（用于绘制文本）
        text=None,  # 要绘制的文本内容
        font=None,  # 文本字体对象
):
    from PIL.ImageDraw import ImageDraw
    if isinstance(draws, ImageDraw):
        draws = [draws]  # 如果输入单个ImageDraw对象，转换为列表形式统一处理
    if draw_type == 'line':
        for draw in draws:
            draw.line(contour, fill=fill, width=contour_width)  # 绘制线条
    elif draw_type == 'text':
        for draw in draws:
            draw.text(center_xy, text, fill=fill, font=font)  # 绘制文本
    else:
        raise ValueError(f'不支持的绘制类型：{draw_type}')  # 如果绘制类型不支持，抛出异常


def cal_text_box(draws, center_xy, text, font):
    from PIL.ImageDraw import ImageDraw
    # 检查draws是否为ImageDraw对象的序列
    if is_seq_of(draws, ImageDraw):
        # 如果是序列，则取第一个元素
        draws = draws[0]
    # 计算文本边界框，使用给定的中心点坐标、文本内容和字体
    text_bbox = draws.textbbox(center_xy, text, font=font)
    # 返回计算得到的文本边界框
    return text_bbox


def stack_images(images: Any | list[Any], gap=10):
    """
    将多个图像水平堆叠在一起
    参数:
        images: 可以是单个PIL.Image对象或包含多个PIL.Image对象的列表
        gap: 图像之间的间隔像素数，默认为10
    返回:
        一个新的PIL.Image对象，包含所有输入图像水平堆叠的结果
    异常:
        AssertionError: 当输入不是PIL.Image或list[PIL.Image]类型时抛出
    """
    from PIL import Image
    if isinstance(images, Image.Image):
        images = [images]  # 如果输入是单个图像，转换为列表形式
    assert is_seq_of(images, Image.Image), '输入必须是Image 或 list[Image] 类型!'  # 验证输入类型
    num_images = len(images)
    if num_images == 1:
        return images[0]  # 如果只有一张图像，直接返回
    unit_width, unit_height = images[0].size  # 获取第一张图像的尺寸作为基准
    new_width = (unit_width + gap) * num_images - gap  # 计算新图像的总宽度
    new_image = Image.new('RGB', (new_width, unit_height), color=(255,) * 3)  # 创建新图像
    new_image.paste(images[0])  # 粘贴第一张图像
    for i in range(1, num_images):
        image = images[i]
        if image.size != (unit_width, unit_height):
            image = image.resize((unit_width, unit_height))  # 调整图像尺寸以保持一致
        new_image.paste(image, (i * unit_width + gap, 0))  # 粘贴后续图像，考虑间隔
    return new_image


class SemanticSampleBuilder:
    """
    语义分割样本制作类，用于处理和生成语义分割训练数据集
    """
    loaded_data: list[tuple[OpenImage, OpenImage]] = []
    temp_dir: Path = None

    def __init__(
            self,
            input_images: list[str] | str,  # 输入图像路径列表或单个图像路径
            input_labels: list[str] | str,  # 输入标签路径列表或单个标签路径
            output_dir: str | Path,  # 输出目录路径
            attribute_field: str = 'class_id',  # shp属性字段名称
            mapping_field: dict = None,  # shp属性字段映射表
            window_size: int | tuple[int, int] = 512,  # 切片大小，可以是整数或元组
            stride: int | tuple[int, int] = None,  # 步长，可以是整数或元组
            max_samples: int = None,  # 最大切片数量
            band_indexes: int | list[int] = None,  # 波段索引，可以是单个索引或索引列表
            palette: Union[list, tuple, dict, bytes, np.ndarray] = None,  # 颜色映射表
            split_val_ratio: float = 0,  # 验证集比例
            split_test_ratio: float = 0,  # 测试集比例
            save_blank_sample_prob: float = 0,  # 保存空白样本的概率
            save_file_name: str = None,  # 保存样本文件时的基础文件名
            image_prefix: str = None,  # 图像文件前缀
            label_prefix: str = None,  # 标签文件前缀
            image_suffix: str = None,  # 图像文件后缀
            label_suffix: str = None,  # 标签文件后缀
            input_mode: int = 0,  # 输入模式 0:文件路径列表,1:目录根据文件名匹配，2：目录根据地理范围匹配
            crop=False,  # 是否裁剪图像
            log_file: str = None,  # 日志输出到文件
            print_progress_rate: bool = True,  # 是否打印进度完成百分比
            num_workers: int = 4,  # 进程池线程数
    ):
        # 初始化进度条
        self.progress_bar = Progress(*Progress.get_default_columns(), MofNCompleteColumn(), TimeElapsedColumn())
        self.progress_task = self.progress_bar.add_task(f'数据准备中...', total=None)
        self.progress_bar.start()
        # 设置基本参数
        self.input_images = input_images
        self.input_labels = input_labels
        self.output_dir = Path(output_dir)
        self.__class__.temp_dir = self.output_dir / f'temp-{uuid.uuid4()}'
        self.attribute_field = attribute_field
        self.mapping_field = mapping_field
        self.window_size = (window_size, window_size) if isinstance(window_size, int) else window_size
        self.stride = stride or self.window_size
        self.max_samples = max_samples
        self.band_indexes = band_indexes
        self.palette = palette
        self.split_val_ratio = split_val_ratio
        self.split_test_ratio = split_test_ratio
        self.save_blank_sample_prob = save_blank_sample_prob
        self.save_file_name = save_file_name
        self.image_prefix = image_prefix
        self.label_prefix = label_prefix
        self.image_suffix = image_suffix
        self.label_suffix = label_suffix
        self.input_mode = input_mode
        self.crop = crop
        self.print_progress_rate = print_progress_rate
        # 设置日志
        setup_logger(print_progress_rate, log_file=log_file)
        # 初始化保存目录和比例
        self.save_dirs = {}
        self.split_ratios = [1 - self.split_val_ratio - self.split_test_ratio]
        # 准备输入数据
        self.progress_total = 0
        # 初始化保存目录
        self.progress_completed = 0
        # 初始化进度
        self.input_data, self.__class__.loaded_data = self._prepare_data()
        # 设置打印间隔
        self._init_save_dir()
        # 初始化进程池
        self._init_progress()
        self.print_interval = self.progress_total // 20
        # 更新进度状态
        self.executor = ProcessPoolExecutor(max_workers=num_workers, initializer=self._init_workers,
                                            initargs=(self.input_data, self.temp_dir))
        self._update_progress(description='数据准备完成')

    def _get_input_image_files(self) -> list[Path]:
        return self.__class__.input_to_list_files(self.input_images, self.image_suffix or ImageFormat.all_formats())

    def _get_input_label_files(self):
        return self.__class__.input_to_list_files(
            self.input_labels,
            self.label_suffix or ['.shp'] + ImageFormat.all_formats()
        )

    def _close(self):
        self.executor.shutdown()
        self.progress_bar.stop()
        self._close_image_data()

    @classmethod
    def _close_image_data(cls):
        for image, label in cls.loaded_data:
            image.close()
            label.close()

    def calculate_one_data_tiles(self, image: OpenImage):
        return sum(1 for _ in OpenImage.sliding_window_x_y(image.width, image.height, self.window_size, self.stride))

    def _init_progress(self):
        """
        初始化进度条
        该方法用于设置进度条的基本参数，包括步长计算和总进度量计算
        """
        # 检查stride是否为整数类型，如果是则转换为元组形式
        if isinstance(self.stride, int):
            self.stride = (self.stride, self.stride)
        # 遍历已加载数据，计算每个图像需要处理的瓦片(tile)数量
        # 并累加到进度总量中
        for image, _ in self.loaded_data:
            self.progress_total += self.calculate_one_data_tiles(image)
        # 添加输入数据的长度和1到进度总量中
        self.progress_total += len(self.input_data) + 1
        # 更新进度条，设置总任务量为计算得到的progress_total
        self.progress_bar.update(self.progress_task, total=self.progress_total)

    def _init_save_dir(self):
        assert self.split_ratios[0] > 0, '验证集和测试集比例之和不能大于等于1!'
        self._init_sub_dir_names()
        split_dirs = dict()
        split_dirs[self.output_dir / 'train'] = '训练集'
        if self.split_val_ratio:
            split_dirs[self.output_dir / 'val'] = '验证集'
            self.split_ratios.append(self.split_val_ratio)
        if self.split_test_ratio:
            split_dirs[self.output_dir / 'test'] = '测试集'
            self.split_ratios.append(self.split_test_ratio)
        for save_dir, sub_dirname in product(split_dirs, self.save_dirs['sub_dir_names']):
            (save_dir / sub_dirname).mkdir(parents=True, exist_ok=True)
        self.save_dirs['split_dirs'] = split_dirs

    def _init_sub_dir_names(self):
        self.save_dirs['sub_dir_names'] = ['images', 'labels']

    def _update_progress(self, advance=1., description=None, status='PROGRESS', level='info', forced=True):

        """
        更新进度条的方法

        参数:
            advance (float): 进度增加的量，默认为1
            description (str): 进度条的描述信息，可选
            status (str): 进度状态，默认为'PROGRESS'
            level (str): 日志级别，默认为'info'
            forced (bool): 是否强制更新进度，默认为True

        功能:
            1. 增加已完成进度
            2. 更新进度条显示
            3. 根据条件打印进度日志
        """
        self.progress_completed += advance  # 增加已完成进度
        self.progress_bar.update(self.progress_task, completed=self.progress_completed,
                                 description=description)  # 更新进度条
        # 如果是强制更新或者达到打印间隔，则打印进度日志
        if forced or self.progress_completed % self.print_interval == 0:
            print_log = getattr(logger, level)  # 获取对应的日志方法
            print_log(f'[{status}][{self.progress_completed * 100 / self.progress_total:.2f}%]{description}')  # 打印进度日志

    def build(self):
        """
        制作样本
    该方法用于处理输入数据并生成样本切片，支持多线程处理，并提供进度更新和样本统计功能。
    Returns:
        Counter: 包含各类样本统计信息的计数器对象
        """
        save_index = 0  # 用于记录当前切片的索引
        sample_counter = Counter()  # 用于统计各类样本的数量
        try:
            # 遍历所有加载的数据
            for idx, loaded_one_data in enumerate(self.loaded_data):
                # 创建部分函数，用于处理单个瓦片
                func_worker = partial(self.__class__._crop_one_tile, idx=idx, window_size=self.window_size,
                                      palette=self.palette, band_indexes=self.band_indexes,
                                      save_blank_sample_prob=self.save_blank_sample_prob)
                # 获取当前数据的信息
                data_info = self.__class__._one_data_info(loaded_one_data)
                desc = data_info.pop('desc')  # 描述信息
                self._update_progress(description=f'{desc} 任务创建中...')  # 更新进度
                futures = {}  # 存储Future对象和对应的分割名称
                save_file_name = self.save_file_name or data_info['file_stem']  # 保存文件名
                width, height = data_info['size']  # 图像尺寸
                # 使用滑动窗口遍历图像
                for x, y in OpenImage.sliding_window_x_y(width, height, self.window_size, self.stride):
                    save_index += 1  # 增加切片索引
                    # 根据周期确定保存目录和分割名称
                    save_dir, split_name = _get_save_directory_by_cycle(save_index, self.save_dirs['split_dirs'],
                                                                        self.split_ratios)
                    # 构建保存路径
                    save_paths = [save_dir / f'{sub_dirname}/{save_file_name}_{save_index}.png' for sub_dirname in
                                  self.save_dirs['sub_dir_names']]
                    # 提交任务到线程池
                    futures[
                        self.executor.submit(func_worker, save_paths, x, y)
                    ] = split_name
                # 处理完成的任务
                for future in as_completed(futures):
                    self._update_progress(description=f'{desc} 样本切片中...', forced=False)
                    split_name = futures.pop(future)
                    is_blank, save_tile = future.result()  # 获取结果
                    # 统计空白样本
                    if is_blank:
                        sample_counter['空白标签样本数量'] += 1
                        if not save_tile:
                            sample_counter['删除空白标签样本数量'] += 1
                    # 统计保留的样本
                    if save_tile:
                        sample_counter[f'{split_name}数量'] += 1
                        sample_counter['保留样本数量'] += 1
                        # 检查是否达到最大样本数
                        if sample_counter['保留样本数量'] == self.max_samples:
                            self._update_progress(
                                advance=self.progress_total - self.progress_completed,
                                description=f'已生成设置的最大样本数量:{self.max_samples}，程序提前结束'
                            )
                            sys.exit(1)

            return sample_counter
        except Exception as e:
            logger.exception(e)  # 记录异常
        finally:
            # 更新样本统计信息
            sample_counter['总切片数量'] = save_index
            self.print_sample_info(
                sample_counter, tile=f'{len(self.input_data)}组源图和标签生成总样本量统计'
            )
            self.save_sample_info(
                self.output_dir, sample_counter, self.window_size, self.stride, self.palette
            )
            # 完成进度更新
            self._update_progress(advance=self.progress_total - self.progress_completed, description='样本切片完成！',
                                  status='COMPLETED', level='success')
            self._close()  # 关闭资源

    def _prepare_data(self) -> tuple[list[tuple[str, str]], list[tuple[OpenImage, OpenImage]]]:
        """
        读取所有图像和标签
    该方法根据不同的输入模式处理图像和标签数据，将它们配对并加载。
    返回两个列表：一个包含图像和标签的临时路径，另一个包含加载的图像和标签对象。
    Returns:
        tuple[list[tuple[str, str]], list[tuple[OpenImage, OpenImage]]]:
            - 第一个列表包含图像和标签的临时路径元组
            - 第二个列表包含加载的图像和标签对象元组
    Raises:
        ValueError: 当输入模式不是0、1或2时抛出异常
        """
        # 获取所有输入图像文件和标签文件
        input_images = self._get_input_image_files()
        input_labels = self._get_input_label_files()

        # 初始化存储数据列表
        input_data: list[tuple[str, str]] = []  # 存储图像和标签的临时路径
        loaded_data: list[tuple[OpenImage, OpenImage]] = []  # 存储加载的图像和标签对象
        # 根据输入模式选择数据处理方式
        match self.input_mode:
            case 0:  # 简单配对模式：按顺序配对图像和标签
                iter_data = zip(input_images, input_labels)
            case 1:  # 精确匹配模式：只匹配前缀和后缀完全对应的图像和标签
                iter_data = filter(
                    lambda data: self.image_matched_label_by_name(
                        data[0], data[1], self.image_prefix,
                        self.label_prefix, self.image_suffix,
                        self.label_suffix),
                    product(input_images, input_labels)
                )
            case 2:  # 完全组合模式：所有图像与所有标签组合
                iter_data = product(input_images, input_labels)
            case _:  # 无效输入模式
                raise ValueError(f'输入模式错误：{self.input_mode}！必须是[0,1,2]其中之一！')
        # 处理每一对图像和标签
        for image_path, label_path in iter_data:
            try:
                # 尝试读取并处理一对图像和标签
                image, label = self._read_one_data(image_path, label_path, self.attribute_field,
                                                   self.mapping_field, self.crop)
            except ValueError as e:
                # 如果读取失败且是简单配对模式，记录警告并跳过
                if self.input_mode != 2:
                    logger.warning(str(e))
            else:
                # 如果读取成功，将数据添加到结果列表
                input_data.append((image.current_temp_path, label.current_temp_path))
                loaded_data.append((image, label))

        # 返回处理后的数据
        return input_data, loaded_data

    @classmethod
    def _init_workers(cls, input_data: list[tuple[str, str]], temp_dir: Path):

        """
        初始化工作线程，加载图像数据

        参数:
            cls: 类方法中的类引用
            input_data: 包含图像路径和标签路径的元组列表
            temp_dir: 临时目录路径，用于存储加载的图像数据

        返回:
            无返回值，但会设置类属性并注册退出处理函数
        """
        cls.temp_dir = temp_dir  # 设置临时目录路径为类属性
        for image_path, label_path in input_data:  # 遍历输入数据中的图像路径和标签路径
            cls.loaded_data.append(  # 将加载的图像数据添加到类属性loaded_data中
                (open_image(image_path, temp_dir=temp_dir), open_image(label_path, temp_dir=temp_dir))
            )
        atexit.register(cls._close_image_data)  # 注册退出处理函数，确保程序退出时正确关闭图像数据

    @classmethod  # 使用类方法装饰器，表示这是一个类方法，可以通过类或类实例调用
    def _crop_one_tile(  # 定义一个名为_crop_one_tile的类方法
            cls,  # 表示类本身，作为第一个参数
            save_paths: list[Path],  # 保存路径的列表，包含图像和标签的保存路径
            off_x: int,  # x方向的偏移量，用于裁剪窗口的位置
            off_y: int,  # y方向的偏移量，用于裁剪窗口的位置
            idx: int,  # 数据索引，用于获取要处理的图像和标签
            window_size=(512, 512),  # 默认窗口大小，用于定义裁剪区域的大小
            palette=None,  # 调色板，用于标签图像的颜色映射
            band_indexes=None,  # 波段索引，用于指定要读取的图像波段
            save_blank_sample_prob=0  # 保存空白样本的概率，默认为0，即不保存空白样本
    ):
        image, label = cls.loaded_data[idx]  # 根据索引从已加载数据中获取图像和标签
        image_save_path, label_save_path = save_paths  # 解包保存路径，分别用于图像和标签
        # 裁剪标签瓦片，并判断是否为空白样本以及是否需要保存
        label_tile, is_blank, save_tile = cls._crop_one_label_tile(label, off_x, off_y, window_size,
                                                                   save_blank_sample_prob)
        if save_tile:  # 如果需要保存该瓦片
            # 从图像中读取指定窗口的数组，根据波段索引
            image_tile = image.read_window_array(off_x, off_y, window_size[0], window_size[-1], band_indexes)
            # 将图像数组写入指定路径，使用PIL格式，RGB模式
            OpenImage.write_array(image_save_path, image_tile, 'pil', mode='RGB')
            # 将标签数组写入指定路径，使用PIL格式，L模式，并应用调色板
            OpenImage.write_array(label_save_path, label_tile, 'pil', mode='L', palette=palette)
        return is_blank, save_tile  # 返回是否为空白样本和是否保存的信息

    @classmethod
    def _read_one_data(
            cls,
            image_path: str | Path,  # 图像文件路径，可以是字符串或Path对象
            label_path: str | Path,  # 标签文件路径，可以是字符串或Path对象
            attribute_field: str = 'class_id',
            mapping_field: dict = None,
            crop: bool = False
    ) -> tuple[OpenImage, OpenImage]:
        image = open_image(str(image_path), temp_dir=cls.temp_dir)
        if Path(label_path).suffix == '.shp':
            with open_shp(label_path) as shp:
                if not OpenImage.is_same_projection(image.geo_projection, shp.geo_projection):
                    logger.debug(f'标签[{shp.file_name}]和图像[{image.file_name}]的投影不匹配，将重新投影')
                    shp.reproject(image.geo_projection)
                inter_geo_bounds = OpenImage.intersection_bounds([image.geo_bounds, shp.geo_bounds])
                if not inter_geo_bounds:
                    image.close()
                    shp.close()
                    raise ValueError(f'标签[{shp.file_name}]和图像[{image.file_name}]的地理范围没有交集')
                crop and image.crop_by_geo_bounds(inter_geo_bounds)
                label = shp.convert_to_open_image(
                    out_width=image.width,
                    out_height=image.height,
                    attribute_field=attribute_field,
                    mapping_field=mapping_field,
                    geo_transform=image.geo_transform,
                    geo_projection=image.geo_projection,
                    data_type=image.dtype,
                    temp_dir=cls.temp_dir
                )
        else:
            label = open_image(str(label_path), temp_dir=cls.temp_dir)
            if label.geo_transform != (0, 1, 0, 0, 0, 1):
                image, label = OpenImage.intersection_image([image, label])
            label.resize(image.size)
        return image, label

    @classmethod
    def image_matched_label_by_name(
            cls,
            image_path: str | Path,
            label_path: str | Path,
            image_prefix: str = None,
            label_prefix: str = None,
            image_suffix: str = None,
            label_suffix: str = None,
    ):
        """
        判断图像和标签是否匹配
        @param image_path: 图像路径
        @param label_path: 标签路径
        @param image_prefix: 图像文件前缀
        @param label_prefix: 标签文件前缀
        @param image_suffix: 图像文件后缀
        @param label_suffix: 标签文件后缀
        @return: 是否匹配
        """
        image_path, label_path = Path(image_path), Path(label_path)
        image_name, label_name = image_path.name, label_path.name
        image_suffix = image_suffix or image_path.suffix
        label_suffix = label_suffix or label_path.suffix
        image_prefix = image_prefix or ''
        label_prefix = label_prefix or ''
        return image_name.removeprefix(image_prefix).removesuffix(image_suffix) == label_name \
            .removeprefix(label_prefix).removesuffix(label_suffix)

    @classmethod
    def batch_build_color_label(
            cls,
            ori_label_dir: str,
            color_label_dir: str,
            palette: Union[list, tuple, dict, bytes, np.ndarray],
            rgb_reversed_mapping: dict[tuple, int] = None,
            sieve_size: int = None,
    ):
        """
        批量将整个目录的原始标签转为伪彩色标签

        @param ori_label_dir: 原始标签目录
        @param color_label_dir: 伪彩标签保存目录
        @param palette: 颜色表
        @param rgb_reversed_mapping: rgb->class_id 映射表，标签为rgb图像时使用，例如：{(255,0,0):1}
        @param sieve_size: 过滤小目标像素面积阈值
        """
        with (
            ProcessPoolExecutor(4) as executor,
            Progress(*Progress.get_default_columns(), MofNCompleteColumn(), TimeElapsedColumn()) as progress
        ):
            p_bar = progress.add_task('[green]批量转伪彩标签图像...', total=None)
            ori_label_dir, color_label_dir = Path(ori_label_dir), Path(color_label_dir)
            futures = []
            for file in ori_label_dir.iterdir():
                if not ImageFormat.is_image_format(file):
                    continue
                ori_label_path = str(file)
                color_label_path = str(color_label_dir / f'{file.stem}.png')
                futures.append(executor.submit(
                    cls.build_color_label,
                    ori_label_path,
                    color_label_path,
                    palette,
                    rgb_reversed_mapping,
                    sieve_size
                ))
            progress.update(p_bar, total=len(futures))
            for future in as_completed(futures):
                future.result()
                progress.advance(p_bar)
            progress.update(p_bar, description='[purple]批量转伪彩标签图像完成！')

    @classmethod
    def batch_build_visualizer_label(
            cls,
            image_dir: str | Any,
            label_dir: str,
            visualizer_label_dir: str,
            palette: Union[list, tuple, dict, bytes, np.ndarray],
            contour_width: int = 2,
            class_names: dict[int, str] = None,
            font_size: int = 8,
            font_color: str | tuple[int, int, int] = '白色',
            prefixes: tuple[str, str] = None,
            suffixes: tuple[str, str] = None,

    ):
        """
        批量将目录下的所有语义分割标签转图像轮廓画到原图上

        @param image_dir: 原始图像文件夹路径
        @param label_dir: 语义分割标签文件夹路径
        @param visualizer_label_dir: 可视化标签文件夹路径
        @param palette: 调色板,支持pil，rasterio等多种风格，且支持常见中英文颜色名称如"red","yellow","blue"等
        @param contour_width: 轮廓线宽度
        @param class_names: 所有类别名称，格式为字典如 {1:'建筑',2:'道路'}
        @param font_size: 字体大小
        @param font_color: 字体颜色
        @param prefixes: 文件名前缀，格式如：('img_','label_')
        @param suffixes: 文件名后缀，格式如：('_img.tif','_label.png')
        """
        font = None
        if class_names is not None:
            from PIL import ImageFont
            from importlib import resources
            font_path = resources.files('rsio.assets').joinpath('simhei.ttf')
            font = ImageFont.truetype(font_path, font_size)

        with (
            ProcessPoolExecutor(4) as executor,
            Progress(*Progress.get_default_columns(), MofNCompleteColumn(), TimeElapsedColumn()) as progress
        ):
            p_bar = progress.add_task('[green]批量可视化标签图像...', total=None)
            futures = []
            run_func = partial(cls.build_visualizer_label,
                               palette=palette,
                               contour_width=contour_width,
                               class_names=class_names,
                               font_color=font_color,
                               font=font)
            for label_path in Path(label_dir).iterdir():
                if not ImageFormat.is_image_format(label_path):
                    continue
                image_path, visualizer_label_path = cls._get_image_path(prefixes, suffixes, image_dir,
                                                                        visualizer_label_dir, label_path.name)
                futures.append(executor.submit(
                    run_func,
                    image_path=image_path,
                    label_path=label_path,
                    visualizer_label_path=visualizer_label_path
                ))
            progress.update(p_bar, total=len(futures))
            for future in as_completed(futures):
                future.result()
                progress.advance(p_bar)
            progress.update(p_bar, description='[purple]批量可视化标签图像完成！')

    @staticmethod
    def build_json_label(label_path: str, json_path: str, class_names: list[str]):
        """
        将单个语义分割标签图片转为JSON标签（labelme格式），支持环形嵌套结构

        @param label_path: 原始标签图片路径（单波段索引图，像素值为类别索引）
        @param json_path: JSON标签保存路径
        @param class_names: 类别名称列表，第一个元素为背景类（像素值0）
        """
        import cv2
        from PIL import Image
        image = Image.open(label_path)
        label_array = np.array(image)
        if label_array.ndim == 3:
            label_array = label_array[:, :, 0]
        height, width = label_array.shape
        # 处理imagePath，尝试将标签后缀替换为png作为对应图像路径
        image_name = Path(label_path).stem + '.png'
        json_data = {
            "version": "4.0.0-beta.7",
            "flags": {},
            "checked": False,
            "shapes": [],
            "imagePath": f"..\\images\\{image_name}",
            "imageData": None,
            "imageHeight": height,
            "imageWidth": width
        }
        shapes = []
        # 遍历每个非背景类别，提取轮廓
        for class_id in range(1, len(class_names)):
            binary_mask = (label_array == class_id).astype(np.uint8)
            if not np.any(binary_mask):
                continue
            contours, hierarchy = cv2.findContours(binary_mask, cv2.RETR_TREE, cv2.CHAIN_APPROX_SIMPLE)
            if not contours or hierarchy is None:
                continue
            hierarchy = hierarchy[0]
            # 处理所有顶层轮廓（无父级的轮廓）
            for i in range(len(contours)):
                if hierarchy[i][3] == -1:
                    _process_contours_recursive(
                        contours, hierarchy, i, class_names[class_id], label_array, class_names, shapes
                    )
        json_data["shapes"] = shapes
        Path(json_path).parent.mkdir(parents=True, exist_ok=True)
        with open(json_path, 'w', encoding='utf-8') as f:
            json.dump(json_data, f, ensure_ascii=False, indent=2)

    @classmethod
    def batch_build_json_label(
            cls,
            ori_label_dir: str | Path,
            json_label_dir: str | Path,
            class_names: list[str],
    ):
        """
        批量将语义分割标签图片转为JSON标签（labelme格式），支持环形嵌套结构

        @param ori_label_dir: 原始标签图片目录（单波段索引图，像素值为类别索引）
        @param json_label_dir: JSON标签保存目录
        @param class_names: 类别名称列表，第一个元素为背景类（像素值0）
        """
        with (
            ProcessPoolExecutor(4) as executor,
            Progress(*Progress.get_default_columns(), MofNCompleteColumn(), TimeElapsedColumn()) as progress
        ):
            p_bar = progress.add_task('[green]批量转JSON标签...', total=None)
            ori_label_dir, json_label_dir = Path(ori_label_dir), Path(json_label_dir)
            futures = []
            for file in ori_label_dir.iterdir():
                if not ImageFormat.is_image_format(file):
                    continue
                json_path = str(json_label_dir / f'{file.stem}.json')
                futures.append(executor.submit(cls.build_json_label, str(file), json_path, class_names))
            progress.update(p_bar, total=len(futures))
            for future in as_completed(futures):
                try:
                    future.result()
                except Exception as e:
                    logger.error(f'转换JSON标签失败: {e}')
                progress.advance(p_bar)
            progress.update(p_bar, description='[purple]批量转JSON标签完成！')

    @classmethod
    def build_visualizer_label(
            cls,
            image_path: str,
            label_path: str,
            palette: Union[list, tuple, dict, bytes, np.ndarray],
            visualizer_label_path: str = None,
            contour_width: int = 2,
            class_names: dict[int, str] = None,
            font=None,
            font_color: str | tuple[int, int, int] = '白色',
            show=False
    ):
        """
        将语义分割标签转图像轮廓画到原图上

        @param image_path: 原始图像路径
        @param label_path: 标签路径
        @param palette: 调色板,支持pil，rasterio等多种风格，且支持常见中英文颜色名称如"red","yellow","blue"等
        @param visualizer_label_path: 可视化标签路径，不为空时会保存结果
        @param contour_width: 轮廓线宽度
        @param class_names: 所有类别名称，格式为字典如 {1:'建筑',2:'道路'}
        @param font: 字体对象，PIL。ImageFont
        @param font_color: 字体颜色
        @param show: 是否显示图片
        @return: None
        """
        from PIL import Image
        from skimage.measure import find_contours

        # 加载原图和mask
        image, draw = cls._read_image_to_draw(image_path)
        mask = Image.open(label_path)
        # 定义类别名称（支持中文）和颜色（RGB格式）
        palette: dict = PaletteConverter.convert('rasterio', palette)
        font_color = ColorTypeConverter.to_rgb_tuple(font_color)
        # 将mask转换为NumPy数组
        mask_array = np.array(mask)
        0 in palette and palette.pop(0)
        for class_id, class_color in palette.items():
            # 创建当前类别的二值mask数组（0/1）
            binary_mask = (mask_array == class_id).astype(bool)  # find_contours需要float或bool
            # 使用scikit-image提取精确轮廓（level=0.5表示边界）
            contours = find_contours(binary_mask, level=0.5)
            # 绘制每个轮廓（contours是list of arrays，每个array是(y, x)坐标）
            for contour in contours:
                # 转换为整数坐标并绘制多段线（精确轮廓）
                contour = contour.astype(int)
                # PIL的line需要(x, y)列表，所以翻转轴并转换为list of tuples
                contour_list = [(x, y) for y, x in contour]  # 注意：find_contours返回(row, col)即(y, x)
                draw_images(draw, 'line', contour=contour_list, contour_width=contour_width, fill=class_color)
                # 计算这个轮廓的质心（使用轮廓点的均值）
                if class_names is not None:
                    cy, cx = np.mean(contour, axis=0).astype(int)  # (y, x)
                    text = class_names.get(class_id, f'class_{class_id}')
                    # 获取文本边界框以居中
                    text_bbox = cal_text_box(draw, (cx, cy), text, font)
                    text_width = text_bbox[2] - text_bbox[0]
                    text_height = text_bbox[3] - text_bbox[1]
                    draw_images(draw, 'text', center_xy=(cx - text_width // 2, cy - text_height // 2),
                                text=text, fill=font_color, font=font)
        image = stack_images(image)
        show and image.show()
        if visualizer_label_path is not None:
            Path(visualizer_label_path).parent.resolve().mkdir(parents=True, exist_ok=True)
            # 确保图像不是P模式，如果是则转换为RGB模式再保存为JPEG
            image.convert('RGB').save(visualizer_label_path)
        return image

    @staticmethod
    def _read_image_to_draw(image_path: str):
        from PIL import Image, ImageDraw
        image = Image.open(image_path)
        draw = ImageDraw.Draw(image)
        return image, draw

    @staticmethod
    def build_color_label(
            ori_label_path: str,
            color_label_path: str,
            palette: Union[list, tuple, dict, bytes, np.ndarray],
            rgb_reversed_mapping: dict[tuple, int] = None,
            sieve_size: int = None
    ):
        """
        将原始标签转为伪彩色标签

        @param ori_label_path: 原始标签路径
        @param color_label_path: 伪彩标签路径
        @param palette: 颜色标签的调色板，支持pil，rasterio等风格
        @param rgb_reversed_mapping: RGB颜色反向映射，当原始标签图像是rgb三波段时设置，例如：{(255,0,0):1}
        @param sieve_size: 过滤目标像素尺寸
        @return: None
        """
        from PIL import Image
        Image.MAX_IMAGE_PIXELS = None
        with (
            open_image(ori_label_path, backend='pil') as ori_label,
            open_image(color_label_path, mode='L', backend='pil') as color_label
        ):
            match ori_label.channel:
                case 1:
                    color_label_array = ori_label.img_array
                case i if i >= 3:
                    assert rgb_reversed_mapping is not None, '请设置RGB颜色反向映射！'
                    ori_label_array = ori_label.img_array[..., :3]
                    color_label_array = np.zeros((ori_label.height, ori_label.width), dtype=np.uint8)
                    for (r, g, b), class_id in rgb_reversed_mapping.items():
                        color_label_array[
                            (ori_label_array[..., 0] == r) & (ori_label_array[..., 1] == g) & (
                                    ori_label_array[..., 2] == b)
                            ] = class_id
                case _:
                    raise ValueError(f'{ori_label_path} 原始标签图像格式有误，必须是单波段或大于等于三波段！')
            if sieve_size is not None:
                from rasterio.features import sieve
                color_label_array = sieve(color_label_array, sieve_size, connectivity=8)
            color_label.set_img_array(color_label_array).set_palette(palette).save()

    @staticmethod
    def _one_data_info(loaded_one_data: tuple[OpenImage, OpenImage]):
        image, label = loaded_one_data
        data_info = dict()
        data_info['desc'] = f'[图像：{image.file_name}][标签：{label.file_name}]'
        data_info['size'] = image.size
        data_info['file_stem'] = image.file_stem
        return data_info

    @staticmethod
    def _crop_one_label_tile(
            label: OpenImage,
            off_x: int,
            off_y: int,
            window_size: tuple[int, int],
            save_blank_sample_prob: float = 0
    ):
        label_tile = label.read_window_array(off_x, off_y, window_size[0], window_size[-1])
        is_blank, save_tile = False, True
        if np.all(label_tile == 0):
            is_blank = True
            if not random.choices([True, False], [save_blank_sample_prob, 1 - save_blank_sample_prob])[0]:
                save_tile = False
        return label_tile, is_blank, save_tile

    @staticmethod
    def input_to_list_files(input_data: list[str] | str, suffixes: str | list[str] = None) -> list[Path]:
        if isinstance(suffixes, str):
            suffixes = [suffixes]
        if isinstance(input_data, str):
            input_path = Path(input_data)
            if input_path.is_file():
                list_files = [input_path]
            elif input_path.is_dir():
                list_files = [file for file in input_path.rglob('*') if
                              any(file.name.endswith(suffix) for suffix in suffixes)] if suffixes else (
                    list(input_path.rglob('*')))
            else:
                raise ValueError(f'输入路径错误：{input_data}')
        elif isinstance(input_data, list):
            list_files = [Path(file) for file in input_data]
        else:
            raise ValueError(f'输入数据类型错误：{input_data}')
        return list_files

    @staticmethod
    def print_sample_info(list_sample_info: list[dict] | dict, tile: str = None):
        """
        打印样本信息

        @param list_sample_info: 样本信息列表
        @param tile: 标题
        @return: None
        """
        if isinstance(list_sample_info, dict):
            list_sample_info = [list_sample_info]
        print_info = Counter()
        for sample_info in list_sample_info:
            print_info += Counter(sample_info)
        print(Panel(
            '\n'.join([f'{key}: {value}' for key, value in print_info.items()]),
            title=tile,
            border_style="green"
        ))

    @staticmethod
    def save_sample_info(output_dir, total_sample_counter, window_size, stride, palette=None):
        sample_info = dict(total_sample_counter)
        sample_info.update({
            '切片大小': window_size,
            '切割步长': stride or window_size,
        })
        palette and sample_info.update({'标签颜色映射表': PaletteConverter.convert('rasterio', palette)})
        save_path = str(Path(output_dir) / 'sample_info.json')
        with open(save_path, 'w', encoding='utf-8') as f:
            json.dump(sample_info, f, ensure_ascii=False, indent=4)

    @staticmethod
    def _get_image_path(prefixes: tuple[str, str], suffixes: tuple[str, str], image_dir: str, visualizer_label_dir: str,
                        filename: str):
        if prefixes is not None:
            image_prefix, label_prefix = prefixes
            filename = filename.replace(label_prefix, image_prefix)
        if suffixes is not None:
            image_suffix, label_suffix = suffixes
            filename = filename.replace(label_suffix, image_suffix)

        return Path(image_dir) / filename, Path(visualizer_label_dir) / filename


class ChangedSampleBuilder(SemanticSampleBuilder):
    loaded_data: list[tuple[tuple[OpenImage, OpenImage], OpenImage]] = []

    def __init__(
            self,
            input_images: list[tuple[str | Path, str | Path]] | tuple[str | Path, str | Path],  # 输入前后期图像路径
            input_labels: list[str | Path] | str,  # 输入标签路径
            output_dir: str | Path,  # 输出目录
            attribute_field: str = 'class_id',  # shp属性字段
            mapping_field: dict = None,  # shp属性字段映射表
            window_size: int | tuple[int, int] = 512,  # 切片大小
            stride: int | tuple[int, int] = None,  # 步长
            max_samples: int = None,  # 最大切片数量
            band_indexes: int | list[int] = None,  # 波段索引
            palette: Union[list, tuple, dict, bytes, np.ndarray] = None,  # 颜色映射表
            split_val_ratio: float = 0,  # 验证集比例
            split_test_ratio: float = 0,  # 测试集比例
            save_blank_sample_prob: float = 0,  # 保存空白样本的概率
            save_file_name: str = None,  # 保存样本文件时的基础文件名
            image_prefix: str | tuple[str, str] = None,  # 图像文件前缀
            label_prefix: str = None,  # 标签文件前缀
            image_suffix: str | tuple[str, str] = None,  # 图像文件后缀
            label_suffix: str = None,  # 标签文件后缀
            input_mode: int = 0,  # 输入模式 0:文件路径列表,1:目录根据文件名匹配，2：目录根据地理范围匹配
            crop=True,  # 是否裁剪
            log_file: str = None,  # 日志输出到文件
            print_progress_rate: bool = True,  # 是否打印进度完成百分比
            num_workers: int = 4,  # 进程池线程数
    ):
        super().__init__(
            input_images,
            input_labels,
            output_dir,
            attribute_field,
            mapping_field,
            window_size,
            stride,
            max_samples,
            band_indexes,
            palette,
            split_val_ratio,
            split_test_ratio,
            save_blank_sample_prob,
            save_file_name,
            image_prefix,
            label_prefix,
            image_suffix,
            label_suffix,
            input_mode,
            crop,
            log_file,
            print_progress_rate,
            num_workers
        )

    def _get_input_image_files(self) -> list[tuple[Path, Path]]:
        if is_seq_of(self.input_images, (str, Path)):
            input_before_images, input_after_images = self.input_images
        else:
            input_before_images, input_after_images = zip(*self.input_images)
        return list(zip(self.input_to_list_files(input_before_images, ImageFormat.all_formats()),
                        self.input_to_list_files(input_after_images, ImageFormat.all_formats())))

    def _prepare_data(
            self
    ) -> tuple[list[tuple[tuple[str, str], str]], list[tuple[tuple[OpenImage, OpenImage], OpenImage]]]:
        """
        读取所有前后期图像和标签
        """
        input_images = self._get_input_image_files()
        input_labels = self._get_input_label_files()
        input_data: list[tuple[tuple[str, str], str]] = []
        loaded_data: list[tuple[tuple[OpenImage, OpenImage], OpenImage]] = []
        if not self.image_prefix or isinstance(self.image_prefix, str):
            before_image_prefix = after_image_prefix = self.image_prefix
        else:
            before_image_prefix, after_image_prefix = self.image_prefix
        if not self.image_suffix or isinstance(self.image_suffix, str):
            before_image_suffix = after_image_suffix = self.image_suffix
        else:
            before_image_suffix, after_image_suffix = self.image_suffix
        match self.input_mode:
            case 0:
                iter_data = zip(input_images, input_labels)
            case 1:
                iter_data = filter(
                    lambda data: self.image_matched_label_by_name(
                        data[0][0], data[1], before_image_prefix,
                        self.label_prefix, before_image_suffix,
                        self.label_suffix) and self.image_matched_label_by_name(
                        data[0][1], data[1], after_image_prefix,
                        self.label_prefix, after_image_suffix,
                        self.label_suffix),
                    product(input_images, input_labels)
                )
            case 2:
                iter_data = product(input_images, input_labels)
            case _:
                raise ValueError(f'输入模式错误：{self.input_mode}！必须是[0,1,2]其中之一！')
        for image_path, label_path in iter_data:
            try:
                before_image, after_image, label = self._read_one_data(image_path, label_path, self.attribute_field,
                                                                       self.mapping_field)
            except ValueError:
                if self.input_mode == 0:
                    logger.warning(
                        f'[前期图像：{image_path[0].name}][后期图像：{image_path[1].name}][标签：{label_path.name}]不匹配，已跳过！')
            else:
                input_data.append(
                    ((before_image.current_temp_path, after_image.current_temp_path), label.current_temp_path))
                loaded_data.append(((before_image, after_image), label))

        return input_data, loaded_data

    def _init_sub_dir_names(self):
        self.save_dirs['sub_dir_names'] = ['images1', 'images2', 'labels']

    def calculate_one_data_tiles(self, image: tuple[OpenImage, OpenImage]):
        return super().calculate_one_data_tiles(image[0])

    def _close_image_data(self):
        for (before_image, after_image), label in self.loaded_data:
            before_image.close()
            after_image.close()
            label.close()

    @classmethod
    def _init_workers(cls, input_data: list[tuple[str, str, str]], temp_dir: str):
        cls.temp_dir = temp_dir
        for (before_image_path, after_image_path), label_path in input_data:
            cls.loaded_data.append(
                ((open_image(before_image_path, temp_dir=cls.temp_dir),
                  open_image(after_image_path, temp_dir=cls.temp_dir)),
                 open_image(label_path, temp_dir=cls.temp_dir))
            )

    @classmethod
    def _crop_one_tile(
            cls,
            save_paths: list[Path],
            off_x: int,
            off_y: int,
            idx: int,
            window_size=(512, 512),
            palette=None,
            band_indexes=None,
            save_blank_sample_prob=0
    ):
        (before_image, after_image), label = cls.loaded_data[idx]
        before_image_save_path, after_image_save_path, label_save_path = save_paths
        label_tile, is_blank, save_tile = cls._crop_one_label_tile(label, off_x, off_y, window_size,
                                                                   save_blank_sample_prob)
        if save_tile:
            before_image_tile = before_image.read_window_array(off_x, off_y, window_size[0], window_size[-1],
                                                               band_indexes)
            after_image_tile = after_image.read_window_array(off_x, off_y, window_size[0], window_size[-1],
                                                             band_indexes)
            OpenImage.write_array(before_image_save_path, before_image_tile, 'pil', mode='RGB')
            OpenImage.write_array(after_image_save_path, after_image_tile, 'pil', mode='RGB')
            OpenImage.write_array(label_save_path, label_tile, 'pil', mode='L', palette=palette)
        return is_blank, save_tile

    @classmethod
    def _read_one_data(
            cls,
            image_path: tuple[str | Path, str | Path],
            label_path: str | Path,
            attribute_field: str = 'class_id',
            mapping_field: dict = None,
            crop=True
    ) -> tuple[OpenImage, OpenImage, OpenImage]:
        before_image_path, after_image_path = image_path
        before_image, after_image = (open_image(str(before_image_path), temp_dir=cls.temp_dir),
                                     open_image(str(after_image_path), temp_dir=cls.temp_dir))
        if not OpenImage.is_same_projection(before_image.geo_projection, after_image.geo_projection):
            logger.debug(
                f'[后期影像:{after_image.file_name}]与[前期影像:{before_image.file_name}] 投影不匹配，将重新投影')
            after_image.reproject(before_image.geo_projection)
        if Path(label_path).suffix == '.shp':
            with open_shp(label_path) as shp:
                if not OpenImage.is_same_projection(before_image.geo_projection, shp.geo_projection):
                    logger.debug(f'[标签:{shp.file_name}]与[前期影像:{before_image.file_name}] 投影不匹配，将重新投影')
                    shp.reproject(before_image.geo_projection)
                inter_geo_bounds = OpenImage.intersection_bounds(
                    [before_image.geo_bounds, after_image.geo_bounds, shp.geo_bounds])
                if not inter_geo_bounds:
                    before_image.close()
                    after_image.close()
                    shp.close()
                    raise ValueError(
                        f'标签[{shp.file_name}] 前期图像[{before_image.file_name}] 后期图像[{after_image.file_name}] 地理范围没有交集')

                if crop:
                    before_image.crop_by_geo_bounds(inter_geo_bounds)
                    after_image.crop_by_geo_bounds(inter_geo_bounds)
                # elif overlab_ratio(before_image.geo_bounds, after_image.geo_bounds) < 1 - 1e-5:
                #     before_image, after_image = OpenImage.intersection_image([before_image, after_image])
                label = shp.convert_to_open_image(
                    out_width=before_image.width,
                    out_height=before_image.height,
                    attribute_field=attribute_field,
                    mapping_field=mapping_field,
                    geo_transform=before_image.geo_transform,
                    geo_projection=before_image.geo_projection,
                    data_type=before_image.dtype,
                    temp_dir=cls.temp_dir
                )
        else:
            label = open_image(str(label_path), temp_dir=cls.temp_dir)
            if label.geo_transform != (0, 1, 0, 0, 0, 1):
                before_image, after_image, label = OpenImage.intersection_image([before_image, after_image, label])
        after_image.resize(before_image.size)
        label.resize(before_image.size)
        return before_image, after_image, label

    @staticmethod
    def _one_data_info(loaded_one_data: tuple[tuple[OpenImage, OpenImage], OpenImage]):
        (before_image, after_image), label = loaded_one_data
        data_info = dict()
        data_info[
            'desc'] = f'[前期影像：{before_image.file_name}][后期影像：{after_image.file_name}][标签：{label.file_name}]'
        data_info['size'] = before_image.size
        data_info['file_stem'] = f'{before_image.file_stem}-{after_image.file_stem}'
        return data_info

    @staticmethod
    def _read_image_to_draw(image_path: tuple[str, str]):
        from PIL import Image, ImageDraw
        before_image, after_image = Image.open(image_path[0]), Image.open(image_path[1])
        before_draw, after_draw = ImageDraw.Draw(before_image), ImageDraw.Draw(after_image)
        return [before_image, after_image], [before_draw, after_draw]

    @staticmethod
    def _get_image_path(prefixes: tuple[str, str, str], suffixes: tuple[str, str, str], image_dir: tuple[str, str],
                        visualizer_label_dir: str, filename: str):
        before_filename = after_filename = filename
        before_image_dir, after_image_dir = image_dir
        if prefixes is not None:
            before_image_prefix, after_image_prefix, label_prefix = prefixes
            before_filename = before_filename.replace(label_prefix, before_image_prefix)
            after_filename = after_filename.replace(label_prefix, after_image_prefix)
        if suffixes is not None:
            before_image_suffix, after_image_suffix, label_suffix = suffixes
            before_filename = before_filename.replace(label_suffix, before_image_suffix)
            after_filename = after_filename.replace(label_suffix, after_image_suffix)

        return (Path(before_image_dir) / before_filename, Path(after_image_dir) / after_filename), Path(
            visualizer_label_dir) / before_filename
