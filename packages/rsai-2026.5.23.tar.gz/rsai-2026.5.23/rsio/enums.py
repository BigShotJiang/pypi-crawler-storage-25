"""
Author: xiash$
Date: 2025/8/19$
Project: open-image$
Description: $
***
* _ooOoo_
* o8888888o
* 88" . "88
* (| -_- |)
*  O\ = /O
* ___/`---'\____
* .   ' \\| |// `.
* / \\||| : |||// \
* / _||||| -:- |||||- \
* | | \\\ - /// | |
* | \_| ''\---/'' | |
* \ .-\__ `-` ___/-. /
* ___`. .' /--.--\ `. . __
* ."" '< `.___\_<|>_/___.' >'"".
* | | : `- \`.;`\ _ /`;.`/ - ` : | |
* \ \ `-. \_ __\ /__ _/ .-` / /
* ======`-.____`-.___\_____/___.-`____.-'======
* `=---='
*          .............................................
*           佛曰：bug泛滥，我已瘫痪！
"""
from enum import Enum
from pathlib import Path


class ImageFormat(Enum):
    """
    常见图像格式后缀枚举
    """
    JPG = ".jpg"
    JPEG = ".jpeg"
    PNG = ".png"
    BMP = ".bmp"
    TIF = ".tif"
    TIFF = ".tiff"
    IMG = ".img"

    @classmethod
    def all_formats(cls):
        """
        获取所有支持的图像格式后缀列表
        """
        return [_format.value for _format in cls]

    @classmethod
    def is_image_format(cls, file_path: str | Path):
        """
        判断给定的文件名是否为支持的图像格式
        """
        return Path(file_path).suffix.lower() in cls.all_formats()
