"""
@File    : open_ogc_services.py
@Time    : 2026/2/13 上午10:34
@Author  : xiashuobad
@Desc    : 

/**
 * _ooOoo_
 * o8888888o
 * 88" . "88
 * (| -_- |)
 *  O\ = /O
 * ___/`---'\____
 * .   ' \\| |// `.
 * / \\||| : |||// \
 * / _||||| -:- |||||- \
 * | | \\\ - /// | |
 * | \_| ''\---/'' | |
 * \ .-\__ `-` ___/-. /
 * ___`. .' /--.--\ `. . __
 * ."" '< `.___\_<|>_/___.' >'"".
 * | | : `- \`.;`\ _ /`;.`/ - ` : | |
 * \ \ `-. \_ __\ /__ _/ .-` / /
 * ======`-.____`-.___\_____/___.-`____.-'======
 * `=---=' bug泛滥 佛已瘫痪
"""
import numpy as np
from abc import ABC
from loguru import logger
from rasterio.features import sieve

from .open_image import open_image, OpenImage
from .open_ogc import open_ogc_image
from .utils import GeoConverter, ArrayShapeConverter


class OpenOgcService(ABC):
    default_params = {}
    register_services = {}
    rgb_reversed_mapping = {}

    def __init__(
            self,
            raster_path: str = None,
            geo_bounds: tuple[float, float, float, float] = None,
            max_concurrent: int = 20,
            zoom: int = 15,
            class_names: list[str] = None,
            sieve_size: int = 50,
            simplify_tolerance: float = 1,
            **kwargs
    ):
        if raster_path is not None:
            with open_image(raster_path) as img:
                geo_bounds = img.geo_bounds
                geo_projection = img.geo_projection
        if not OpenImage.is_same_projection(geo_projection, 4326):
            geo_bounds = GeoConverter.bounds2bounds_proj_transform(geo_bounds, geo_projection, 4326)
        self._image = open_ogc_image(
            **self.default_params,
            geo_bounds=geo_bounds,
            max_concurrent=max_concurrent,
            zoom=zoom,
            **kwargs
        )
        self.adjust_image()
        self.sieve_size = sieve_size
        self.class_names = class_names
        self.simplify_tolerance = simplify_tolerance
        self._label = None
        self._shp = None

    def __enter__(self):
        return self

    def __exit__(self, exc_type, exc_val, exc_tb):
        self.close()

    def __init_subclass__(cls, service=None):
        cls.register_services[service] = cls

    @property
    def image(self):
        return self._image

    @property
    def label(self):
        if self.rgb_reversed_mapping and self._label is None:
            logger.info('转换标签图像...')
            self.class_names = self.class_names or ['背景'] + list(set(self.rgb_reversed_mapping.values()))
            class_mapping = {class_name: i for i, class_name in enumerate(self.class_names)}
            ori_label_array = self.image.img_array
            label_array = np.zeros((self.image.height, self.image.width), dtype=np.uint8)
            for (min_pixel, max_pixel), class_name in self.rgb_reversed_mapping.items():
                if class_name in class_mapping:
                    label_array[(ori_label_array >= min_pixel) * (ori_label_array <= max_pixel)] = class_mapping[
                        class_name]
            label_array = sieve(label_array, self.sieve_size, connectivity=8)
            self._label = open_image('', 'w').set_img_array(label_array).set_geo_transform(
                self.image.geo_transform).set_geo_projection(self.image.geo_projection)
        return self._label

    @property
    def shp(self):
        if self.label is not None and self._shp is None:
            logger.info('转换标签矢量...')
            self._shp = self.label.convert_to_open_shp(
                class_names=self.class_names,
                simplify_tolerance=self.simplify_tolerance
            )

        return self._shp

    def adjust_image(self):
        ...

    def close(self):
        self._image.close()

    def save(self, save_image_path=None, save_label_path=None, save_shp_path=None):
        save_image_path and self.image.save(save_image_path)
        save_label_path and (
            self.label.save(save_label_path) if self.label else logger.warning('标签图像为空，无法保存！'))
        save_shp_path and (self.shp.save(save_shp_path) if self.shp else logger.warning('shp矢量为空，无法保存！'))


class OpenTiandituVectorMap(OpenOgcService, service='天地图矢量'):
    default_params = dict(
        server_url='https://t0.tianditu.gov.cn/vec_w/wmts',
        service='WMTS',
        # version='1.0.0',
        # request='GetTile',
        # format='tiles',
        # layer='vec',
        # style='default',
        # tile_matrix_set='w',
    )
    rgb_reversed_mapping = {
        (247, 251): '建筑',
        (208, 212): '道路',
        (227, 235): '道路',
        (252, 255): '道路',
        (193, 197): '水体',
        (221, 225): '林地',
    }

    def __init__(
            self,
            raster_path: str,
            geo_bounds: tuple[float, float, float, float] = None,
            max_concurrent: int = 20,
            zoom: int = 17,
            class_names: list[str] = None,
            sieve_size: int = 50,
            simplify_tolerance: float = 1,
            tk='434f436c2dbca883ae618968e14831e0'
    ):
        super().__init__(raster_path, geo_bounds, max_concurrent, zoom, class_names, sieve_size, simplify_tolerance,
                         tk=tk)

    def adjust_image(self):
        self._image.convert_to_gray()


class OpenCartoDBVectorMap(OpenOgcService, service='CartoDB矢量'):
    default_params = dict(
        service='XYZ',
        server_url='https://a.basemaps.cartocdn.com/light_nolabels/{z}/{x}/{y}@2x.png',
        tile_size=512
    )
    rgb_reversed_mapping = {
        (235, 239): '建筑',
        (251, 255): '道路',
        (214, 218): '水体',
        (239, 243): '林地',
    }

    def adjust_image(self):
        self._image.convert_to_gray()


class OpenESRIImage(OpenOgcService, service='ESRI影像'):
    default_params = dict(
        service='XYZ',
        server_url='https://server.arcgisonline.com/ArcGIS/rest/services/World_Imagery/MapServer/tile/{z}/{y}/{x}'
    )


class OpenGoogleImage(OpenOgcService, service='谷歌矢量'):
    default_params = dict(
        service='xyz',
        server_url='https://mt1.google.com/vt/lyrs=p&x={x}&y={y}&z={z}'
    )


def open_ogc_service(
        raster_path: str = None,
        geo_bound: tuple[float, float, float, float] = None,
        service: str = '天地图矢量',
        zoom: int = 17,
        max_concurrent: int = 20,
        class_names: list[str] = None,
        sieve_size: int = 50,
        simplify_tolerance: float = 2,
        **kwargs
) -> OpenOgcService:
    return OpenOgcService.register_services[service](
        raster_path, geo_bound, max_concurrent, zoom, class_names, sieve_size, simplify_tolerance,
        **kwargs
    )
