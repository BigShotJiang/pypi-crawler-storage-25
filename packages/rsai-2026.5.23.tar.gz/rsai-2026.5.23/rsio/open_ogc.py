"""
Author: xiashuobad$
Date: 2026/2/7$
Project: rsio$
Description: $
***
* _ooOoo_
* o8888888o
* 88" . "88
* (| -_- |)
*  O\ = /O
* ___/`---'\____
* .   ' \\| |// `.
* / \\||| : |||// \
* / _||||| -:- |||||- \
* | | \\\ - /// | |
* | \_| ''\---/'' | |
* \ .-\__ `-` ___/-. /
* ___`. .' /--.--\ `. . __
* ."" '< `.___\_<|>_/___.' >'"".
* | | : `- \`.;`\ _ /`;.`/ - ` : | |
* \ \ `-. \_ __\ /__ _/ .-` / /
* ======`-.____`-.___\_____/___.-`____.-'======
* `=---='
*          .............................................
*           佛曰：bug泛滥，我已瘫痪！
"""
import asyncio
import io
import aiohttp
import mercantile
import numpy as np
import requests

from abc import ABC, abstractmethod
from PIL import Image
from loguru import logger
from requests.adapters import HTTPAdapter
from rich.progress import Progress, MofNCompleteColumn, TimeElapsedColumn
from urllib3 import Retry

from rsio import open_image, OpenImage


class Ogc(ABC):
    registered_services = {}

    def __init__(
            self,
            server_url: str,
            geo_bounds: tuple[float, float, float, float],
            tile_size: tuple[int, int] = (256, 256),
            zoom: int = 15,
            max_concurrent: int = 20,
            **kwargs
    ):
        self._init_progress_bar()
        self._init_params(server_url, geo_bounds, tile_size, zoom, max_concurrent, **kwargs)
        self._download()

    def __enter__(self):
        return self

    def __exit__(self, exc_type, exc_val, exc_tb):
        self.close()

    def __init_subclass__(cls, **kwargs):
        cls.registered_services[kwargs['service']] = cls

    def _init_progress_bar(self):
        self.progress_bar = Progress(*Progress.get_default_columns(), MofNCompleteColumn(), TimeElapsedColumn())
        self.progress_task = self.progress_bar.add_task(f'数据初始化...', total=None)
        self.progress_bar.start()

    def _get_list_tiles(self):
        west, north, east, south = self.geo_bounds
        tiles = mercantile.tiles(west, south, east, north, zooms=[self.zoom])
        return list(tiles)

    def close(self):
        self.image.close()

    def save(self, save_path: str):
        self.image.save(save_path)

    def _create_base_image(self):
        # 计算网格尺寸
        width_tiles = self.max_tile.x - self.min_tile.x + 1
        height_tiles = self.max_tile.y - self.min_tile.y + 1
        # 创建空白画布
        merged_width = width_tiles * self.tile_size[0]
        merged_height = height_tiles * self.tile_size[1]
        # 计算瓦片网格的实际地理范围
        # 获取最小瓦片的左上角和最大瓦片的右下角坐标
        min_tile_bounds = mercantile.bounds(self.min_tile)
        max_tile_bounds = mercantile.bounds(self.max_tile)

        # 使用瓦片网格的实际边界计算地理变换参数
        actual_west, actual_north = min_tile_bounds.west, min_tile_bounds.north
        actual_east, actual_south = max_tile_bounds.east, max_tile_bounds.south

        # 计算精确的地理变换参数
        pixel_width = (actual_east - actual_west) / merged_width
        pixel_height = (actual_south - actual_north) / merged_height
        geo_transform = (actual_west, pixel_width, 0., actual_north, 0., pixel_height)
        self.image = open_image('', 'w', out_width=merged_width, out_height=merged_height).set_geo_transform(
            geo_transform).set_geo_projection(4326)

    def _init_params(
            self,
            server_url: str,
            geo_bounds: tuple[float, float, float, float],
            tile_size: tuple[int, int] = (256, 256),
            zoom: int = 15,
            max_concurrent: int = 20,
            **kwargs
    ):
        self.server_url = server_url
        self.geo_bounds = self.checked_geo_bounds(geo_bounds)
        self.max_concurrent = max_concurrent
        self.tile_size = (tile_size, tile_size) if isinstance(tile_size, int) else tile_size
        self.zoom = zoom
        self.base_url = self._build_base_url(**kwargs)
        self.list_tiles = self._get_list_tiles()
        self.min_tile = mercantile.tile(self.geo_bounds[0], self.geo_bounds[1], zoom)
        self.max_tile = mercantile.tile(self.geo_bounds[2], self.geo_bounds[3], zoom)
        self._create_base_image()
        self.progress_bar.update(self.progress_task, total=len(self.list_tiles) + 2, advance=1)
        self.headers = {
            "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36",
            "Accept": "image/webp,image/apng,image/*,*/*;q=0.8",
            "Accept-Language": "en-US,en;q=0.9",
            "Accept-Encoding": "gzip, deflate",
            "Connection": "keep-alive",
            "Upgrade-Insecure-Requests": "1",
            "Sec-Fetch-Dest": "image",
            "Sec-Fetch-Mode": "no-cors",
            "Sec-Fetch-Site": "cross-site",
        }

    def _download(self):
        asyncio.run(self._download_all())

    async def _download_all(self):
        self.progress_bar.update(self.progress_task, description='图像下载中...')

        connector = aiohttp.TCPConnector(
            limit=10,  # 降低总连接数
            limit_per_host=2,  # 降低每个域名的连接数
            ttl_dns_cache=300,  # DNS 缓存 5 分钟
            use_dns_cache=True,
            force_close=False,  # 启用连接复用
            enable_cleanup_closed=True,  # 自动清理关闭的连接
            ssl=False  # 禁用 SSL 验证（仅用于测试，生产环境不建议）
        )
        timeout = aiohttp.ClientTimeout(total=60, connect=30)  # 增加总超时和连接超时时间
        session = aiohttp.ClientSession(
            timeout=timeout,
            headers=self.headers,
            connector=connector
        )
        self.semaphore = asyncio.Semaphore(self.max_concurrent)
        try:
            tasks = [self._download_one(session, tile) for tile in self.list_tiles]
            for task in asyncio.as_completed(tasks):
                result = await task
                if result is None:
                    continue
                img_array, (x_offset, y_offset) = result
                self.image.set_img_array(img_array, x_offset, y_offset)
                self.progress_bar.advance(self.progress_task)
            self.image.crop_by_geo_bounds(self.geo_bounds)
            self.progress_bar.update(self.progress_task, completed=len(self.list_tiles) + 2, description='图像下载完成')
        finally:
            await session.close()
            self.progress_bar.stop()

    async def _download_one(self, session: aiohttp.ClientSession, tile: mercantile.Tile, retry_times: int = 3):
        async with self.semaphore:
            for attempt in range(retry_times):
                try:
                    url = self._build_request_url(tile)
                    async with session.get(url) as resp:
                        if resp.status == 200:
                            data = await resp.read()
                            img = np.array(Image.open(io.BytesIO(data)).convert('RGB'))
                            return img, ((tile.x - self.min_tile.x) * self.tile_size[0],
                                         (tile.y - self.min_tile.y) * self.tile_size[1])
                        else:
                            await asyncio.sleep(1)
                except Exception as e:
                    logger.debug(f"瓦片{tile}下载失败: {e}")
                    await asyncio.sleep(1)

        logger.error(f"瓦片{tile}下载失败！")
        return None

    @abstractmethod
    def _build_request_url(self, tile: mercantile.Tile) -> str:
        ...

    @abstractmethod
    def _build_base_url(self, *args, **kwargs):
        ...

    @staticmethod
    def checked_geo_bounds(geo_bounds: tuple[float, float, float, float]):
        west, north, east, south = geo_bounds
        if (west < -180 or west > 180 or east < -180 or east > 180 or north < -85.0511 or north > 85.0511 or
                south < -85.0511 or south > 85.0511):
            raise ValueError("geo_bounds 超出范围！坐标范围必须是基于4326坐标系。")
        return geo_bounds


class WmtsOgc(Ogc, service='WMTS'):

    def __init__(
            self,
            server_url: str,
            geo_bounds: tuple[float, float, float, float],
            tile_size: tuple[int, int] = (256, 256),
            zoom: int = 15,
            max_concurrent: int = 20,
            version: str = '1.0.0',
            request: str = 'GetTile',
            format: str = 'tiles',
            layer: str = 'vec',
            style: str = 'default',
            tile_matrix_set: str = 'w',
            **kwargs,
    ):
        super().__init__(
            server_url, geo_bounds, tile_size, zoom, max_concurrent,
            version=version,
            request=request,
            format=format,
            layer=layer,
            style=style,
            tile_matrix_set=tile_matrix_set,
            **kwargs
        )

    def _build_request_url(self, tile: mercantile.Tile) -> str:
        url = self.base_url.format(x=tile.x, y=tile.y)
        return url

    def _build_base_url(
            self,
            version: str = '1.0.0',
            request: str = 'GetTile',
            layer: str = 'vec',
            style: str = 'default',
            tile_matrix_set: str = 'w',
            **kwargs
    ):
        base_url = (
            f'{self.server_url}?SERVICE=WMTS&REQUEST={request}&VERSION={version}&LAYER={layer}'
            f'&STYLE={style}&TILEMATRIXSET={tile_matrix_set}&FORMAT={format}&TILECOL={{x}}&TILEROW={{y}}'
            f'&TILEMATRIX={self.zoom}'
        )
        if kwargs is not None:
            base_url += ''.join(f'&{key}={value}' for key, value in kwargs.items())

        return base_url


class WmsOgc(Ogc, service='WMS'):

    def __init__(
            self,
            server_url: str,
            geo_bounds: tuple[float, float, float, float],
            tile_size: tuple[int, int] = (256, 256),
            zoom: int = 15,
            max_concurrent: int = 20,
            version: str = '1.0.0',
            request: str = 'GetMap',
            format: str = 'image/png',
            layers: str = '',
            styles: str = '',
            **kwargs
    ):
        super().__init__(
            server_url, geo_bounds, tile_size, zoom, max_concurrent,
            version=version,
            request=request,
            format=format,
            layers=layers,
            styles=styles,
            **kwargs
        )

    def _build_request_url(self, tile: mercantile.Tile) -> str:
        min_x, min_y, max_x, max_y = mercantile.bounds(tile)
        url = self.base_url.format(min_x=min_x, min_y=min_y, max_x=max_x, max_y=max_y)
        return url

    def _build_base_url(
            self,
            version: str = '1.3.0',
            request: str = 'GetMap',
            format: str = 'image/png',
            layers: str = '',
            styles: str = '',
            **kwargs
    ):
        if version == '1.3.0':
            param_bbox = '&BBOX={min_y}%2C{min_x}%2C{max_y}%2C{max_x}'
            param_crs = f'&CRS=EPSG:4326'
        else:
            param_bbox = '&BBOX={min_x}%2C{min_y}%2C{max_x}%2C{max_y}'
            param_crs = f'&SRS=EPSG:4326'
        base_url = (
                       f'{self.server_url}?SERVICE=WMS&version={version}&REQUEST={request}'
                       f'&LAYERS={layers}&STYLES={styles}&Width={self.tile_size[0]}&Height={self.tile_size[1]}'
                       f'&FORMAT={format}'
                   ) + param_bbox + param_crs
        if kwargs is not None:
            base_url += ''.join(f'&{key}={value}' for key, value in kwargs.items())

        return base_url


class XYZOgc(Ogc, service='XYZ'):

    def _build_request_url(self, tile: mercantile.Tile) -> str:
        return self.base_url.format(x=tile.x, y=tile.y, z=self.zoom)

    def _build_base_url(self):
        return self.server_url

    def _download(self):
        self.progress_bar.update(self.progress_task, description='图像下载中...')
        session = requests.Session()
        retry_strategy = Retry(
            total=30,
            backoff_factor=0.5,
            status_forcelist=(500, 502, 503, 504),
            allowed_methods=("GET", "POST"),
            raise_on_status=False  # 不因重试失败抛出异常
        )

        adapter = HTTPAdapter(max_retries=retry_strategy)
        session.mount("http://", adapter)
        session.mount("https://", adapter)
        try:
            for tile in self.list_tiles:
                url = self._build_request_url(tile)
                try:
                    resp = requests.get(url, headers=self.headers, timeout=10)
                    if resp.status_code == 200:
                        img_array = np.array(Image.open(io.BytesIO(resp.content)).convert('RGB'))
                        x_offset, y_offset = (
                            (tile.x - self.min_tile.x) * self.tile_size[0],
                            (tile.y - self.min_tile.y) * self.tile_size[1]
                        )
                        self.image.set_img_array(img_array, x_offset, y_offset)
                        self.progress_bar.advance(self.progress_task)
                    else:
                        logger.debug(f"❌ HTTP {resp.status_code}: {resp.reason}")
                except requests.exceptions.RequestException as e:
                    logger.error(f"💥 请求失败(已重试): {e}")
            self.image.crop_by_geo_bounds(self.geo_bounds)
            self.progress_bar.update(self.progress_task, completed=len(self.list_tiles) + 2, description='图像下载完成')
        finally:
            session.close()
            self.progress_bar.stop()


def open_ogc_image(
        server_url: str,
        geo_bounds: tuple[float, float, float, float],
        service: str = 'WTMS',
        tile_size: tuple[int, int] = (256, 256),
        zoom: int = 15,
        max_concurrent: int = 20,
        **kwargs
) -> OpenImage:
    return Ogc.registered_services[service.upper()](
        server_url, geo_bounds, tile_size, zoom, max_concurrent, **kwargs
    ).image
