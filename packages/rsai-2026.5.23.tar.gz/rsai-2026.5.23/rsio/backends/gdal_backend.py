"""
@File    : gdal_backend.py.py
@Time    : 2025/7/15 下午8:27
@Author  : xiashuobad
@Desc    : 

/**
 * _ooOoo_
 * o8888888o
 * 88" . "88
 * (| -_- |)
 *  O\ = /O
 * ___/`---'\____
 * .   ' \\| |// `.
 * / \\||| : |||// \
 * / _||||| -:- |||||- \
 * | | \\\ - /// | |
 * | \_| ''\---/'' | |
 * \ .-\__ `-` ___/-. /
 * ___`. .' /--.--\ `. . __
 * ."" '< `.___\_<|>_/___.' >'"".
 * | | : `- \`.;`\ _ /`;.`/ - ` : | |
 * \ \ `-. \_ __\ /__ _/ .-` / /
 * ======`-.____`-.___\_____/___.-`____.-'======
 * `=---=' bug泛滥 佛已瘫痪
"""
# rsio/core/backends/gdal_backend.py
import numpy as np
import tempfile
from pathlib import Path
from osgeo import gdal, osr
from typing import Literal, Union, Type
from uuid import uuid4
from .pil_backend import PILImage
from ..utils.exceptions import *
from ..utils import (catch_exception, require_attr_not_empty, type_check, PaletteConverter, DataTypeConverter,
                     ArrayShapeConverter, require_python_library, GeoConverter, crop_gdal_data)


class GDALImage(PILImage, backend_name='gdal'):
    open_mode = Literal['r', 'w']

    def _init_temp_dir(self, temp_dir: str = None):
        self.temp_dir = Path(temp_dir) if temp_dir else Path(tempfile.gettempdir()) / 'Temp'
        self.temp_dir.mkdir(parents=True, exist_ok=True)

    @property
    def auto_temp_path(self) -> Path:
        temp_path = self.temp_dir / f'temp-{uuid4()}.tif'
        return temp_path

    @property
    @require_attr_not_empty('img_data')
    def current_temp_path(self):
        return self.img_data.GetFileList()[0]

    @property
    @require_attr_not_empty('img_data')
    def size(self) -> tuple[int, ...]:
        return self.img_data.RasterXSize, self.img_data.RasterYSize

    @property
    @require_attr_not_empty('img_data')
    def shape(self) -> tuple[int, ...]:
        return self.channel, self.height, self.width

    @property
    @require_attr_not_empty('img_data')
    def width(self) -> int:
        return self.img_data.RasterXSize

    @property
    @require_attr_not_empty('img_data')
    def height(self) -> int:
        return self.img_data.RasterYSize

    @property
    @require_attr_not_empty('img_data')
    def channel(self) -> int:
        return self.img_data.RasterCount

    @property
    @require_attr_not_empty('img_data')
    def dtype(self) -> Type[np.number]:
        return DataTypeConverter.gdal_type_to_np(self.img_data.GetRasterBand(1).DataType)

    @property
    @require_attr_not_empty('img_data')
    def geo_bounds(self) -> tuple[float, float, float, float]:
        left, top = self.geo_transform[0], self.geo_transform[3]
        right, bottom = GeoConverter.pixel_to_geo(self.width, self.height, self.geo_transform)
        return left, top, right, bottom

    @property
    @require_attr_not_empty('img_data')
    def nodata(self) -> int | float:
        return self.img_data.GetRasterBand(1).GetNoDataValue()

    @nodata.setter
    @require_attr_not_empty('img_data')
    @type_check
    def nodata(self, nodata: int | float):
        with catch_exception(ImageProcessError('gdal设置nodata失败！')):
            for i in range(1, self.channel + 1):
                self.img_data.GetRasterBand(i).SetNoDataValue(nodata)

    def set_nodata(self, nodata: int | float) -> 'GDALImage':
        self.nodata = nodata
        return self

    @property
    @require_attr_not_empty('img_data')
    def geo_transform(self) -> tuple[float, ...]:
        return self.img_data.GetGeoTransform()

    @geo_transform.setter
    @require_attr_not_empty('img_data')
    @type_check
    def geo_transform(self, geo_transform: tuple[float, ...]):
        self.img_data.SetGeoTransform(GeoConverter.geo_transform2gdal(geo_transform))

    def set_geo_transform(self, geo_transform: tuple[float, ...]) -> 'GDALImage':
        self.geo_transform = geo_transform
        return self

    @property
    @require_attr_not_empty('img_data')
    def geo_projection(self) -> str:
        return self.img_data.GetProjection()

    @geo_projection.setter
    @require_attr_not_empty('img_data')
    @type_check
    def geo_projection(self, geo_projection: str | int | osr.SpatialReference):
        with catch_exception(ImageProcessError('gdal 设置投影失败！')):
            self.img_data.SetProjection(GeoConverter.geo_projection2wkt(geo_projection))

    def set_geo_projection(self, geo_projection: str | int | osr.SpatialReference) -> 'GDALImage':
        self.geo_projection = geo_projection
        return self

    @property
    @require_attr_not_empty('img_data')
    def img_array(self) -> np.ndarray:
        with catch_exception(ImageReadError()):
            return self.img_data.ReadAsArray()

    def set_img_array(
            self, array: np.ndarray, x_offset: int = 0, y_offset: int = 0, band_list: list[int] = None,
            **kwargs
    ) -> 'GDALImage':
        array = ArrayShapeConverter.array_shape_to_gdal(array)
        if self.img_data is None:
            driver: gdal.Driver = gdal.GetDriverByName('GTiff')
            self._img_data: gdal.Dataset = driver.Create(
                self.auto_temp_path.as_posix(),
                array.shape[-1] + x_offset,
                array.shape[-2] + y_offset,
                self.array_channels(array),
                DataTypeConverter.np_type_to_gdal(array.dtype)
            )
        self._img_data.WriteArray(array, x_offset, y_offset, band_list, **kwargs)

        return self

    def _checked_mode(self, mode: open_mode) -> open_mode:
        if mode not in self.open_mode.__args__:
            raise ImageModeError(f'不支持的打开模式：{mode}, 请使用以下模式：{self.open_mode.__args__}！')
        return mode

    @property
    def img_data(self) -> gdal.Dataset:
        return self._img_data

    @img_data.setter
    @type_check
    def img_data(self, img_data: gdal.Dataset):
        driver = gdal.GetDriverByName('GTiff')
        self._img_data = driver.CreateCopy(self.auto_temp_path.as_posix(), img_data)
        self._img_data.FlushCache()

    def set_img_data(self, img_data: gdal.Dataset) -> 'GDALImage':
        self.img_data = img_data
        return self

    @property
    @require_attr_not_empty('img_data')
    def palette(self) -> gdal.ColorTable:
        return self.img_data.GetRasterBand(1).GetColorTable()

    @palette.setter
    @require_attr_not_empty('img_data')
    @type_check
    def palette(self, palette: Union[list, tuple, dict, bytes, np.ndarray, gdal.ColorTable]):
        with catch_exception(ImageProcessError('gdal设置palette失败！')):
            palette: gdal.ColorTable = PaletteConverter.convert('gdal', palette)
            for i in range(1, self.channel + 1):
                self.img_data.GetRasterBand(i).SetColorTable(palette)

    def set_palette(self, palette: Union[list, tuple, dict, bytes, np.ndarray, gdal.ColorTable]) -> 'GDALImage':
        self.palette = palette
        return self

    def _open(self, out_width=None, out_height=None, out_channel=3, **kwargs):
        if self.mode == 'r':
            self._img_data = gdal.Open(self.file_path, gdal.GA_ReadOnly)
            if not self._img_data:
                raise ImageOpenError(f"gdal打开文件失败: {self.file_path}")
        else:
            if out_width and out_height:
                out_shape = (out_channel, out_height, out_width) if out_channel > 1 else (out_height, out_width)
                array = np.zeros(out_shape, dtype=np.uint8)
                self.set_img_array(array)

    @require_attr_not_empty('img_data')
    def save(self, save_path: str = None):
        with catch_exception(ImageWriteError(f'gdal 保存图像失败！')):
            save_path = save_path or self.file_path
            if save_path == self.file_path and self.mode == 'r':
                self.set_img_data(self._img_data)
            Path(save_path).resolve().parent.mkdir(parents=True, exist_ok=True)
            driver = gdal.GetDriverByName('GTiff')
            driver.CreateCopy(save_path, self.img_data)

    def close(self):
        self._close_img_data()
        self._clean_temp_dir()

    def _close_img_data(self):
        self._img_data = None

    @require_attr_not_empty('img_data')
    @type_check
    def resize(self,
               target_size: tuple[int, int] | int,
               keep_ratio: bool = False,
               pad: int = None,
               resample: int = None,
               box: list[int] | tuple[int, int, int, int] = None,
               **kwargs
               ) -> 'GDALImage':
        if isinstance(target_size, int):
            target_size = (target_size, target_size)
        if target_size == self.size:
            return self
        # 原图无坐标系时将坐标轴映射到正方向,防止gdal报错
        self.geo_transform == (0, 1, 0, 0, 0, 1) and self.set_geo_transform((0, 1, 0, 0, 0, -1))
        if box:
            left, top, right, bottom = box
            self.crop(left, top, right - left, bottom - top)

        if keep_ratio:
            # 计算保持纵横比的新尺寸
            target_width, target_height = target_size
            # 计算缩放比例
            scale_x = target_width / self.width
            scale_y = target_height / self.height
            scale = min(scale_x, scale_y)
            # 计算新的尺寸
            new_width = round(self.width * scale)
            new_height = round(self.height * scale)
            # 先缩放到保持纵横比的尺寸
            self._img_data: gdal.Dataset = gdal.Warp(
                self.auto_temp_path.as_posix(),
                self.img_data,
                width=new_width,
                height=new_height,
                resampleAlg=resample,
                format='GTiff'
            )
            if pad is not None:
                channel = self.channel
                data_type = self.img_data.GetRasterBand(1).DataType
                array = self.img_array
                geo_transform = list(self.geo_transform)
                geo_projection = self.geo_projection
                nodata = self.nodata
                palette = PaletteConverter.clone_color_table(self.palette)

                # 创建带有padding的目标数据集
                driver = gdal.GetDriverByName('GTiff')
                self._img_data: gdal.Dataset = driver.Create(
                    self.auto_temp_path.as_posix(),
                    target_width,
                    target_height,
                    channel,
                    data_type,
                )

                # 计算在目标图像中的位置（居中）
                x_offset = (target_width - new_width) // 2
                y_offset = (target_height - new_height) // 2
                # 将缩放后的图像复制到padding图像的中心
                for i in range(1, channel + 1):
                    # 先填充padding值
                    padded_band = self.img_data.GetRasterBand(i)
                    padded_band.Fill(pad)
                    # 复制缩放后的图像数据
                    padded_band.WriteArray(array[i - 1], x_offset, y_offset)

                # 设置地理变换、投影等元数据
                # 由于内容向右下偏移，左上角坐标需要相应调整
                geo_transform[0] -= x_offset * geo_transform[1]  # X坐标减小
                geo_transform[3] -= y_offset * geo_transform[5]  # Y坐标增大
                self.set_geo_transform(tuple(geo_transform))
                geo_projection is not None and self.set_geo_projection(geo_projection)
                # # 设置无数据值
                nodata is not None and self.set_nodata(nodata)
                palette is not None and self.set_palette(palette)

        else:
            # 直接调整到目标尺寸
            self._img_data = gdal.Warp(
                self.auto_temp_path.as_posix(),
                self.img_data,
                width=target_size[0],
                height=target_size[1],
                resampleAlg=resample,
                format='GTiff',
            )
        return self

    def reverse_rgb(self) -> 'GDALImage':
        array_reversed = self.reversed_rgb(self.img_array, 'gdal')
        self.img_data.WriteArray(array_reversed)
        return self

    @require_attr_not_empty('img_data')
    @type_check
    def read_window_array(self, x_off: int = 0, y_off: int = 0, window_x_size: int = None,
                          window_y_size: int = None,
                          band_indexes: int | list[int] = None, **kwargs):
        if isinstance(band_indexes, int):
            band_indexes = [band_indexes]
        if isinstance(band_indexes, list):
            for i, band_index in enumerate(band_indexes):
                if band_index < 0 or band_index >= self.channel:
                    raise ValueError(f'波段索引值：{band_indexes} 超出了范围：{tuple(range(self.channel))}')
                band_indexes[i] = band_index + 1
        return self.img_data.ReadAsArray(x_off, y_off, window_x_size, window_y_size, band_list=band_indexes,
                                         **kwargs)

    @require_attr_not_empty('img_data')
    @type_check
    def crop(self,
             x_off: int = 0,
             y_off: int = 0,
             window_x_size: int = None,
             window_y_size: int = None
             ) -> 'GDALImage':
        self._img_data: gdal.Dataset = crop_gdal_data(
            self.img_data, x_off, y_off, window_x_size, window_y_size, self.auto_temp_path.as_posix()
        )
        if not self._img_data:
            raise ImageProcessError('裁剪图片失败！')
        return self

    @classmethod
    def cropped(
            cls,
            image: 'GDALImage',
            x_off: int = 0,
            y_off: int = 0,
            window_x_size: int = None,
            window_y_size: int = None
    ) -> 'GDALImage':
        img_data = crop_gdal_data(image.img_data, x_off, y_off, window_x_size, window_y_size,
                                  image.auto_temp_path.as_posix())
        cropped_image = cls('', 'w').set_img_data(img_data)
        return cropped_image

    @require_attr_not_empty('img_data')
    @require_python_library('PIL', 'pillow')
    def show(self, title: str = None):
        from PIL import Image
        image_show = Image.fromarray(ArrayShapeConverter.convert('pil', self.img_array))
        if self.palette:
            image_show.putpalette(PaletteConverter.convert('pil', self.palette))
        image_show.show(title)

    def reproject(self, dst_srs_obj: 'int|str|GDALImage', dst_width=None, dst_height=None, num_threads: int = 2):
        if not self.geo_projection:
            raise ImageProcessError(f'图像:{self.file_name} 未定义投影信息，请先设置投影！')
        if isinstance(dst_srs_obj, GDALImage):
            dst_srs_wkt = dst_srs_obj.geo_projection
            dst_width, dst_height = dst_srs_obj.size
        else:
            dst_srs_wkt = GeoConverter.geo_projection2wkt(dst_srs_obj)

        warp_options = gdal.WarpOptions(
            format='GTiff',
            srcSRS=self.geo_projection,
            dstSRS=dst_srs_wkt,
            resampleAlg=gdal.GRA_Bilinear,
            multithread=num_threads is not None,  # 是否启用多线程
            warpOptions=dict(NUM_THREADS=num_threads) if num_threads else None,
            width=dst_width,
            height=dst_height,
        )
        # 执行重投影
        self._img_data = gdal.Warp(self.auto_temp_path.as_posix(), self.img_data, options=warp_options)
        return self

    def crop_by_geo_bounds(
            self,
            geo_bounds: tuple[float, float, float, float],
    ) -> 'GDALImage':
        """
        根据地理范围裁剪图片
        :param geo_bounds: 地理范围 (左，上，右，下)
        :return: 裁剪后的图片对象
        """
        self._img_data: gdal.Dataset = gdal.Translate(
            self.auto_temp_path.as_posix(),
            self.img_data,
            projWin=list(geo_bounds),
            format='GTiff',
        )
        if not self._img_data:
            raise Exception('根据地理范围裁剪图片失败！')
        return self

    @require_attr_not_empty('img_array')
    def convert_to_rgb(self):
        new_image = GDALImage(
            self.file_path.replace(self.img_suffix, f'_to_rgb{self.img_suffix}'),
            'w',
        )
        array_to_rgb = ArrayShapeConverter.array_shape_to_rgb(self.img_array)
        new_image.set_img_array(array_to_rgb).set_geo_transform(
            self.geo_transform).set_geo_projection(self.geo_projection)

        return new_image

    @require_attr_not_empty('img_data')
    def convert_to_gray(self) -> 'GDALImage':
        from PIL import Image
        img_array = ArrayShapeConverter.array_shape_to_pil(self.img_array)
        img_array = np.array(Image.fromarray(img_array).convert('L'))
        self._img_data = self.__class__('', 'w').set_img_array(img_array).set_geo_transform(
            self.geo_transform).set_geo_projection(self.geo_projection)
        return self

    @require_attr_not_empty('img_array')
    def convert_to_open_shp(
            self,
            class_names: list[str] | list[list[str]] = None,
            del_zero_value: bool = True,
            simplify_tolerance: float = 2,
            **kwargs
    ):
        from ..open_shp import open_shp
        shp_data = GeoConverter.mask_array_to_shp(
            self.img_array,
            class_names=class_names,
            geo_transform=self.geo_transform,
            geo_projection=self.geo_projection,
            del_zero_value=del_zero_value,
            simplify_tolerance=simplify_tolerance,
            **kwargs
        )
        shp = open_shp('', 'w')
        shp.set_data_source(shp_data)
        return shp

    @staticmethod
    @type_check
    def write_array(
            fp: str,
            array: np.ndarray,
            geo_transform: tuple[float, ...] = None,
            geo_projection: str = None,
            nodata: Union[int, float] = None,
            palette: Union[list, tuple, dict, bytes, np.ndarray] = None,
            **kwargs
    ):
        with catch_exception(ImageWriteError(f'gdal 保存图片失败！')):
            array = ArrayShapeConverter.array_shape_to_gdal(array)
            driver = gdal.GetDriverByName('GTiff')
            dtype = DataTypeConverter.np_type_to_gdal(array.dtype)
            dataset: gdal.Dataset = driver.Create(
                fp,
                array.shape[-1],
                array.shape[-2],
                array.shape[0] if len(array.shape) == 3 else 1,
                dtype
            )
            dataset.WriteArray(array, **kwargs)
            geo_transform and dataset.SetGeoTransform(geo_transform)
            geo_projection and dataset.SetProjection(geo_projection)
            nodata and [dataset.GetRasterBand(i).SetNoDataValue(nodata) for i in range(1, array.shape[0] + 1)]
            if palette:
                palette = PaletteConverter.convert('gdal', palette)
                for i in range(1, array.shape[0] + 1):
                    dataset.GetRasterBand(i).SetColorTable(palette)
            dataset.FlushCache()

    @staticmethod
    @type_check
    def resize_img(
            img_array: np.ndarray,
            target_size: tuple[int, int] | int,
            keep_ratio: bool = False,
            pad: int = None,
            resample: int = 1,
            out: np.ndarray = None,
            fx: float = None,
            fy: float = None,
            box: list[int] | tuple[int, int, int, int] = None,
    ) -> np.ndarray:
        array = super().resize_img(img_array, target_size, keep_ratio, pad, resample, out, fx, fy, box)
        array = ArrayShapeConverter.array_shape_to_gdal(array)
        return array

    @staticmethod
    @type_check
    def reversed_rgb(img_array: np.ndarray) -> np.ndarray:
        img_array = super().reversed_rgb(img_array)
        img_array = ArrayShapeConverter.array_shape_to_gdal(img_array)
        return img_array
