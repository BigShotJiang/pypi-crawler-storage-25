"""
@File    : __init__.py.py
@Time    : 2025/7/15 下午5:31
@Author  : xiashuobad
@Desc    : 

/**
 * _ooOoo_
 * o8888888o
 * 88" . "88
 * (| -_- |)
 *  O\ = /O
 * ___/`---'\____
 * .   ' \\| |// `.
 * / \\||| : |||// \
 * / _||||| -:- |||||- \
 * | | \\\ - /// | |
 * | \_| ''\---/'' | |
 * \ .-\__ `-` ___/-. /
 * ___`. .' /--.--\ `. . __
 * ."" '< `.___\_<|>_/___.' >'"".
 * | | : `- \`.;`\ _ /`;.`/ - ` : | |
 * \ \ `-. \_ __\ /__ _/ .-` / /
 * ======`-.____`-.___\_____/___.-`____.-'======
 * `=---=' bug泛滥 佛已瘫痪
"""
# rsio/core/backends/image_backend.py
import numpy as np
from abc import ABC, abstractmethod
from pathlib import Path

from ..utils import type_check, ArrayShapeConverter, require_attr_not_empty


class ImageBackend(ABC):
    """
    图像 IO 后端抽象基类
    """
    registered_backends = {}

    def __init__(
            self, file_path: str, mode: str = 'r', out_width=None, out_height: int = None, temp_dir: str = None,
            **kwargs
    ):
        self._fp = Path(file_path)
        self._mode = self._checked_mode(mode)
        self._img_array = None
        self._img_data = None
        self._init_temp_dir(temp_dir)
        self._open(out_width, out_height, **kwargs)

    @classmethod
    def __init_subclass__(cls, **kwargs):
        ImageBackend.registered_backends[kwargs['backend_name']] = cls

    def __enter__(self):
        return self

    def __exit__(self, exc_type, exc_val, exc_tb):
        self.close()

    @require_attr_not_empty('img_array')
    def __getattr__(self, attr: str):
        return getattr(self.img_array, attr)

    def _init_temp_dir(self, temp_dir: str = None):
        self.temp_dir = temp_dir

    @property
    @abstractmethod
    def auto_temp_path(self):
        ...

    @property
    @abstractmethod
    def current_temp_path(self):
        ...

    @property
    def file_path(self) -> str:
        return str(self._fp)

    @property
    def mode(self) -> str:
        return self._mode

    @property
    def file_name(self) -> str:
        return self._fp.name

    @property
    def file_stem(self) -> str:
        return self._fp.stem

    @property
    def img_suffix(self) -> str:
        return self._fp.suffix.lower()

    @property
    def img_array(self) -> np.ndarray:
        return self._img_array

    @abstractmethod
    def set_img_array(
            self, array: np.ndarray, x_offset: int = 0, y_offset: int = 0, band_list: list[int] = None
    ) -> 'ImageBackend':
        ...

    @property
    @abstractmethod
    def img_data(self):
        ...

    @img_data.setter
    @abstractmethod
    def img_data(self, img_data):
        ...

    @abstractmethod
    def set_img_data(self, img_data) -> 'ImageBackend':
        ...

    @property
    def palette(self):
        return None

    @palette.setter
    @type_check
    def palette(self, palette):
        ...

    def set_palette(self, palette) -> 'ImageBackend':
        self.palette = palette
        return self

    @property
    def geo_bounds(self):
        return None

    @property
    @require_attr_not_empty('img_array')
    def shape(self) -> tuple[int, int] | tuple[int, int, int]:
        return self._img_array.shape

    @property
    @abstractmethod
    def size(self) -> tuple[int, int]:
        ...

    @property
    @abstractmethod
    def channel(self) -> int:
        ...

    @property
    @require_attr_not_empty('img_array')
    def width(self) -> int:
        return self.size[0]

    @property
    @require_attr_not_empty('img_array')
    def height(self) -> int:
        return self.size[1]

    @property
    @require_attr_not_empty('img_array')
    def dtype(self) -> np.dtype:
        return self.img_array.dtype

    @property
    def nodata(self):
        return None

    @nodata.setter
    def nodata(self, nodata: int | float):
        ...

    def set_nodata(self, nodata: int | float) -> 'ImageBackend':
        self.nodata = nodata
        return self

    @property
    def geo_transform(self):
        return None

    @geo_transform.setter
    def geo_transform(self, geo_transform):
        ...

    def set_geo_transform(self, geo_transform) -> 'ImageBackend':
        self.geo_transform = geo_transform
        return self

    @property
    def geo_projection(self):
        return None

    @geo_projection.setter
    @type_check
    def geo_projection(self, geo_projection):
        ...

    def set_geo_projection(self, geo_projection) -> 'ImageBackend':
        self.geo_projection = geo_projection
        return self

    @abstractmethod
    def resize(self, target_size: tuple[int, int], *args, **kwargs) -> 'ImageBackend':
        ...

    @abstractmethod
    def reverse_rgb(self) -> 'ImageBackend':
        ...

    @abstractmethod
    def crop(
            self, x_off: int = 0, y_off: int = 0, window_x_size: int = None, window_y_size: int = None
    ) -> 'ImageBackend':
        ...

    @classmethod
    @abstractmethod
    def cropped(
            cls,
            image: 'ImageBackend',
            x_off: int = 0,
            y_off: int = 0,
            window_x_size: int = None,
            window_y_size: int = None
    ) -> 'ImageBackend':
        ...

    @abstractmethod
    def read_window_array(self, x_off: int = 0, y_off: int = 0, window_x_size: int = None,
                          window_y_size: int = None,
                          band_indexes: int | list[int] = None, *args, **kwargs):
        ...

    @abstractmethod
    def _open(self, *args, **kwargs):
        ...

    @abstractmethod
    def save(self, *args, **kwargs):
        ...

    def close(self):
        self._img_array = None

    def _close_img_data(self):
        self._img_data = None

    def _clean_temp_dir(self):
        import shutil
        shutil.rmtree(self.temp_dir, ignore_errors=True)

    def _checked_mode(self, mode: str) -> str:
        return mode

    @abstractmethod
    def show(self, title: str = None):
        ...

    @abstractmethod
    def reproject(self, *args, **kwargs) -> 'ImageBackend':
        ...

    @abstractmethod
    def crop_by_geo_bounds(
            self,
            geo_bounds: tuple[float, float, float, float],
    ) -> 'ImageBackend':
        ...

    @abstractmethod
    def convert_to_rgb(self) -> 'ImageBackend':
        ...

    @abstractmethod
    def convert_to_gray(self):
        ...

    @abstractmethod
    def convert_to_open_shp(self, *args, **kwargs):
        ...

    @staticmethod
    @type_check
    def array_channels(array: np.ndarray) -> int:
        array = ArrayShapeConverter.array_shape_to_gdal(array)
        return 1 if len(array.shape) == 2 else array.shape[0]

    @staticmethod
    @abstractmethod
    def write_array(
            fp: str,
            array: np.ndarray,
            *args,
            **kwargs
    ):
        ...

    @staticmethod
    @abstractmethod
    def show_image(img_array: np.ndarray, *args, **kwargs):
        ...

    @staticmethod
    @abstractmethod
    def resize_img(
            img_array: np.ndarray,
            target_size: tuple[int, int] | int,
            keep_ratio: bool = False,
            pad: int = None,
            resample: int = None,
            **kwargs
    ) -> np.ndarray:
        ...

    @staticmethod
    @abstractmethod
    def reversed_rgb(img_array: np.ndarray) -> np.ndarray:
        ...

    @staticmethod
    @abstractmethod
    def colormap(img_data):
        ...

    @staticmethod
    def checked_crop_window(
            width,
            height,
            x_off: int,
            y_off: int,
            window_x_size: int,
            window_y_size: int
    ) -> tuple[int, int, int, int]:
        if not window_x_size and not window_y_size:
            raise ValueError("裁剪的宽度和高度不能同时为空或0！")
        if not window_x_size:
            window_x_size = window_y_size
        if not window_y_size:
            window_y_size = window_x_size
        if x_off < 0:
            x_off = 0
        if y_off < 0:
            y_off = 0
        if x_off + window_x_size > width:
            window_x_size = width - x_off
        if y_off + window_y_size > height:
            window_y_size = height - y_off

        return x_off, y_off, window_x_size, window_y_size
