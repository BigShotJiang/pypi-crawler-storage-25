"""
@File    : rasterio_backend.py.py
@Time    : 2025/7/15 下午10:59
@Author  : xiashuobad
@Desc    : 

/**
 * _ooOoo_
 * o8888888o
 * 88" . "88
 * (| -_- |)
 *  O\ = /O
 * ___/`---'\____
 * .   ' \\| |// `.
 * / \\||| : |||// \
 * / _||||| -:- |||||- \
 * | | \\\ - /// | |
 * | \_| ''\---/'' | |
 * \ .-\__ `-` ___/-. /
 * ___`. .' /--.--\ `. . __
 * ."" '< `.___\_<|>_/___.' >'"".
 * | | : `- \`.;`\ _ /`;.`/ - ` : | |
 * \ \ `-. \_ __\ /__ _/ .-` / /
 * ======`-.____`-.___\_____/___.-`____.-'======
 * `=---=' bug泛滥 佛已瘫痪
"""
# rsio/core/backends/rasterio_backend.py
import numpy as np
from typing import Union, Any
from loguru import logger
from pathlib import Path

from .gdal_backend import GDALImage
from ..utils import (type_check, require_python_library, PaletteConverter, ArrayShapeConverter, GeoConverter,
                     require_attr_not_empty, ImageModeError, copy_rasterio_data, crop_rasterio_data)


class RasterioImage(GDALImage, backend_name='rasterio'):

    @property
    @require_attr_not_empty('img_data')
    def current_temp_path(self):
        return self.img_data.files[0]

    @require_python_library('rasterio', 'rasterio')
    def _open(self, out_width=None, out_height=None, out_channel=3, **kwargs):
        import rasterio
        if self.mode == 'r':
            self._img_data = rasterio.open(self.file_path, 'r')
        else:
            if out_width and out_height and out_channel:
                out_shape = (out_channel, out_height, out_width)
                array = np.zeros(out_shape, dtype=np.uint8)
                self.set_img_array(array)

    @property
    @require_attr_not_empty('img_data')
    def img_array(self) -> np.ndarray:
        return self._img_data.read().squeeze()

    def set_img_array(
            self, array: np.ndarray, x_offset: int = 0, y_offset: int = 0, band_list: list[int] = None,
            **kwargs
    ) -> 'RasterioImage':
        import rasterio
        from rasterio.windows import Window
        array = ArrayShapeConverter.array_shape_to_rasterio(array)
        if not self.img_data:
            meta = {
                'driver': 'GTiff',
                'width': array.shape[2] + x_offset,  # 注意 rasterio 使用 (bands, height, width) 格式
                'height': array.shape[1] + y_offset,
                'count': array.shape[0],  # 波段数
                'dtype': array.dtype,
            }
            self._img_data: rasterio.DatasetReader = rasterio.open(self.auto_temp_path.as_posix(), 'w+', **meta)
        elif self.img_data.mode == 'r':
            self.set_img_data(self._img_data)
        self.img_data.write(array, band_list, window=Window(col_off=x_offset, row_off=y_offset, width=array.shape[-1],
                                                            height=array.shape[-2]), **kwargs)

        return self

    @staticmethod
    def colormap(dataset: 'rasterio.DatasetBase') -> dict[int, tuple[int, int, int, int]]:
        try:
            palette = dataset.colormap(1)
        except ValueError:
            palette = None

        return palette

    @property
    def img_data(self) -> 'rasterio.io.DatasetWriter':
        return self._img_data

    @img_data.setter
    def img_data(self, img_data: 'rasterio.DatasetReader | rasterio.io.DatasetWriter'):
        self._img_data = copy_rasterio_data(img_data, self.auto_temp_path.as_posix())

    def set_img_data(self, img_data: 'rasterio.DatasetBase') -> 'RasterioImage':
        self.img_data = img_data
        return self

    @require_attr_not_empty('img_data')
    def save(self, save_path: str = None):
        save_path = save_path or self.file_path
        copy_rasterio_data(self.img_data, save_path)

    @property
    @require_attr_not_empty('img_data')
    def shape(self) -> tuple[int, ...]:
        return super().shape

    @property
    @require_attr_not_empty('img_data')
    def size(self) -> tuple[int, int]:
        return self.width, self.height

    @property
    @require_attr_not_empty('img_data')
    def channel(self) -> int:
        return self.img_data.count

    @property
    @require_attr_not_empty('img_data')
    def width(self) -> int:
        return self.img_data.width

    @property
    @require_attr_not_empty('img_data')
    def height(self) -> int:
        return self.img_data.height

    @property
    @require_attr_not_empty('img_data')
    def dtype(self) -> str:
        return self._img_data.dtypes[0]

    @property
    @require_attr_not_empty('img_data')
    def geo_bounds(self) -> tuple[float, float, float, float]:
        left, bottom, right, top = self.img_data.bounds
        return left, top, right, bottom

    @property
    @require_attr_not_empty('img_data')
    def nodata(self) -> int | float:
        return self._img_data.nodata

    @nodata.setter
    @require_attr_not_empty('img_data')
    @type_check
    def nodata(self, nodata: int | float):
        if self.img_data.mode == 'r':
            self.set_img_data(self._img_data)
        self._img_data.nodata = nodata

    def set_nodata(self, nodata: int | float) -> 'RasterioImage':
        self.nodata = nodata
        return self

    @property
    @require_attr_not_empty('img_data')
    def geo_transform(self) -> 'affine.Affine':
        return self.img_data.transform

    @geo_transform.setter
    @require_attr_not_empty('img_data')
    @type_check
    def geo_transform(self, geo_transform: tuple[float, ...]):
        if self.img_data.mode == 'r':
            self.set_img_data(self._img_data)
        self._img_data.transform = GeoConverter.geo_transform2rasterio(geo_transform)

    def set_geo_transform(self, geo_transform: tuple[float, ...]) -> 'RasterioImage':
        self.geo_transform = geo_transform
        return self

    @property
    @require_attr_not_empty('img_data')
    def geo_projection(self) -> str | None:
        crs = self.img_data.crs
        if crs:
            return crs.wkt
        return None

    @geo_projection.setter
    @require_attr_not_empty('img_data')
    @type_check
    def geo_projection(self, geo_projection: str | int):
        if self.img_data.mode == 'r':
            self.set_img_data(self._img_data)
        if not geo_projection:
            logger.warning('投影为空，设置无效！')
        else:
            self.img_data.crs = GeoConverter.geo_projection2wkt(geo_projection)

    def set_geo_projection(self, geo_projection: str | int) -> 'RasterioImage':
        self.geo_projection = geo_projection
        return self

    def _checked_mode(self, mode: GDALImage.open_mode) -> GDALImage.open_mode:
        if mode not in self.open_mode.__args__:
            raise ImageModeError(f'不支持的打开模式：{mode}, 请使用以下模式：{self.open_mode.__args__}！')
        return mode

    @property
    @require_attr_not_empty('img_data')
    def palette(self) -> dict:
        return self.colormap(self.img_data)

    @palette.setter
    @require_attr_not_empty('img_data')
    @type_check
    def palette(self, palette: Union[list, tuple, dict, bytes, np.ndarray]):
        if self.img_data.mode == 'r':
            self.set_img_data(self._img_data)
        palette = PaletteConverter.convert('rasterio', palette)
        if self.channel == 1:
            self.img_data.write_colormap(1, palette)
        else:
            logger.warning('当前图像为多波段，设置colormap无效！')

    def set_palette(self, palette: Union[list, tuple, dict, bytes, np.ndarray]) -> 'RasterioImage':
        self.palette = palette
        return self

    @require_attr_not_empty('img_data')
    @type_check
    def resize(self,
               target_size: tuple[int, int] | int,
               keep_ratio: bool = False,
               pad: int = None,
               resample: int = None,
               box: list[int] | tuple[int, int, int, int] = None,
               **kwargs
               ) -> 'RasterioImage':
        # 处理目标尺寸
        if isinstance(target_size, int):
            target_size = (target_size, target_size)
        if target_size == self.size:
            return self
        target_width, target_height = target_size
        if box:
            x_min, y_min, x_max, y_max = box
            self.crop(x_min, y_min, x_max - x_min, y_max - y_min)
        # 处理保持比例的情况
        if keep_ratio:
            src_width, src_height, = self.width, self.height
            scale = min(target_width / src_width, target_height / src_height)
            new_width = int(src_width * scale)
            new_height = int(src_height * scale)
        else:
            new_width, new_height = target_width, target_height
        # 读取并重采样
        from rasterio.enums import Resampling
        resized_array = self.img_data.read(
            out_shape=(self.channel, new_height, new_width),
            resampling=resample or Resampling.bilinear
        )

        # 更新元数据
        from affine import Affine
        geo_transform = self.geo_transform * Affine.scale((self.width / new_width), (self.height / new_height))
        if pad is not None:
            # 计算在目标图像中的位置（居中）
            x_offset = (target_width - new_width) // 2
            y_offset = (target_height - new_height) // 2
            geo_transform = self.geo_transform * Affine.scale(self.width / new_width,
                                                              self.height / new_height
                                                              ) * Affine.translation(-x_offset, -y_offset)
            temp_array = np.full((resized_array.shape[0], target_height, target_width), pad, dtype=resized_array.dtype)
            temp_array[:, y_offset:y_offset + new_height, x_offset:x_offset + new_width] = resized_array
            resized_array = temp_array
        import rasterio
        temp_path = self.auto_temp_path.as_posix()
        self.__class__.write_array(temp_path, resized_array, geo_transform, self.geo_projection, self.nodata,
                                   self.palette)
        self._img_data: rasterio.DatasetReader = rasterio.open(temp_path, 'r+')
        return self

    def reverse_rgb(self) -> 'RasterioImage':
        if self.img_data.mode == 'r':
            self.set_img_data(self._img_data)
        array_reversed = self.reversed_rgb(self.img_array, 'rasterio')
        self.img_data.write(array_reversed, self.channel == 1 or None)
        return self

    @require_attr_not_empty('img_data')
    @type_check
    def crop(self,
             x_off: int = 0,
             y_off: int = 0,
             window_x_size: int = None,
             window_y_size: int = None
             ) -> 'RasterioImage':
        self._img_data = crop_rasterio_data(self.img_data, x_off, y_off, window_x_size, window_y_size,
                                            self.auto_temp_path.as_posix())
        return self

    @classmethod
    def cropped(
            cls,
            image: 'RasterioImage',
            x_off: int = 0,
            y_off: int = 0,
            window_x_size: int = None,
            window_y_size: int = None
    ) -> 'RasterioImage':
        img_data = crop_rasterio_data(image._img_data, x_off, y_off, window_x_size, window_y_size,
                                      image.auto_temp_path.as_posix())
        cropped_image = cls('', 'w').set_img_data(img_data)
        return cropped_image

    @require_attr_not_empty('img_data')
    @type_check
    def read_window_array(self, x_off: int = 0, y_off: int = 0, window_x_size: int = None, window_y_size: int = None,
                          band_indexes: int | list[int] = None, **kwargs) -> np.ndarray:
        if isinstance(band_indexes, int):
            band_indexes = [band_indexes]
        if isinstance(band_indexes, list):
            for i, band_index in enumerate(band_indexes):
                if band_index < 0 or band_index >= self.channel:
                    raise ValueError(f'波段索引：{band_indexes} 超出了范围：{tuple(range(self.channel))}！')
                band_indexes[i] += 1
        from rasterio.windows import Window
        return self.img_data.read(band_indexes, window=Window(x_off, y_off, window_x_size, window_y_size),
                                  **kwargs).squeeze()

    def show(self, title: str = None):
        super().show(title)

    def _close_img_data(self):
        if hasattr(self, '_img_data'):
            self._img_data.close()

    def reproject(self,
                  dst_srs_obj: 'int|str|dict|RasterioImage|rasterio.CRS',
                  dst_width=None,
                  dst_height=None,
                  num_threads: int = 2
                  ) -> 'RasterioImage':
        import rasterio
        from rasterio.warp import calculate_default_transform, reproject, Resampling

        if isinstance(dst_srs_obj, RasterioImage):
            dst_srs = dst_srs_obj.img_data.crs
            dst_width, dst_height = dst_srs_obj.size
        else:
            dst_srs = GeoConverter.geo_projection2wkt(dst_srs_obj)
        left, top, right, bottom = self.geo_bounds
        dst_transform, dst_width, dst_height = calculate_default_transform(
            self.img_data.crs, dst_srs, self.width, self.height, left, bottom, right, top, dst_width=dst_width,
            dst_height=dst_height
        )
        kwargs = self.img_data.meta.copy()
        kwargs.update({
            'crs': dst_srs,
            'transform': dst_transform,
            'width': dst_width,
            'height': dst_height
        })
        src_img_data = self.img_data
        temp_path = self.auto_temp_path.as_posix()
        self._img_data: rasterio.DatasetReader = rasterio.open(temp_path, 'w+', **kwargs)
        for i in range(1, self.channel + 1):  # 处理每个波段
            reproject(
                source=rasterio.band(src_img_data, i),
                destination=rasterio.band(self.img_data, i),
                src_transform=src_img_data.transform,
                src_crs=src_img_data.crs,
                dst_transform=dst_transform,
                dst_crs=dst_srs,
                resampling=Resampling.bilinear,  # 重采样方法：可选项如nearest、cubic
                num_threads=num_threads
            )
        self._img_data: rasterio.DatasetReader = rasterio.open(temp_path, 'r+')
        return self

    def crop_by_geojson(self, geojson: dict | list[dict] | str):
        """
        根据地理区域裁剪图片,可以是geojson字典也可以是shp文件路径
        :param geojson: 地理范围
        :return: 裁剪后的图片对象
        """
        assert isinstance(geojson, (dict, list, str)), "geojson参数类型错误！"
        if isinstance(geojson, dict):
            if 'features' in geojson:
                geojson = list(map(lambda feature: feature['geometry'], geojson['features']))
            elif 'geometry' in geojson:
                geojson = [geojson['geometry']]
            else:
                geojson = [geojson]
        elif isinstance(geojson, str):
            assert geojson.endswith('.shp') and Path(
                geojson).exists(), f'geojson: {geojson} 参数类型错误或文件不存在！只能是.shp文件。'
            from rsio import open_shp, OpenImage
            import json
            shp = open_shp(geojson).reproject(self.geo_projection)
            geojson = [json.loads(feature.geometry().ExportToJson()) for feature in shp.features]
        from rasterio.mask import mask
        import rasterio
        out_image, out_transform = mask(self.img_data, geojson, nodata=self.nodata, crop=True)
        temp_path = self.auto_temp_path
        self.__class__.write_array(temp_path.as_posix(), out_image, out_transform, self.geo_projection, self.nodata)
        self._img_data: rasterio.DatasetReader = rasterio.open(temp_path, 'r+')
        return self

    def crop_by_geo_bounds(
            self,
            geo_bounds: tuple[float, float, float, float],
    ) -> 'GDALImage':
        """
        根据地理范围裁剪图片
        :param geo_bounds: 地理范围 (左，上，右，下)
        :return: 裁剪后的图片对象
        """
        left, top, right, bottom = geo_bounds
        geo_json = {
            "coordinates": [[[left, top], [right, top], [right, bottom], [left, bottom], [left, top]]],
            "type": "Polygon"
        }
        return self.crop_by_geojson(geo_json)

    @require_attr_not_empty('img_array')
    def convert_to_rgb(self):
        array_to_rgb = ArrayShapeConverter.array_shape_to_rgb(self.img_array)
        self.set_img_array(array_to_rgb)

        return self

    @staticmethod
    @require_python_library('rasterio', 'rasterio')
    def write_array(
            fp: str,
            array: np.ndarray,
            geo_transform: tuple[float, ...] = None,
            geo_projection: Any = None,
            nodata: int | float = None,
            palette: Union[list, tuple, dict, bytes, np.ndarray] = None,
            **meta
    ):
        import rasterio
        array = ArrayShapeConverter.array_shape_to_rasterio(array)
        count = RasterioImage.array_channels(array)
        meta.update({
            'driver': 'GTiff',
            'width': array.shape[-1],
            'height': array.shape[-2],
            'count': count,
            'dtype': array.dtype,
            'nodata': nodata,
            'transform': GeoConverter.geo_transform2rasterio(geo_transform),
            'crs': geo_projection
        })
        with rasterio.open(fp, 'w', **meta) as dst:
            dst.write(array)
            if palette is not None:
                if count == 1:
                    dst.write_colormap(1, PaletteConverter.convert('rasterio', palette))
                else:
                    logger.warning(f'图像波段数为：{count}，无法写入颜色表！仅单波段图像有效。')
