"""
@File    : cv2_backend.py.py
@Time    : 2025/7/15 下午10:49
@Author  : xiashuobad
@Desc    : 

/**
 * _ooOoo_
 * o8888888o
 * 88" . "88
 * (| -_- |)
 *  O\ = /O
 * ___/`---'\____
 * .   ' \\| |// `.
 * / \\||| : |||// \
 * / _||||| -:- |||||- \
 * | | \\\ - /// | |
 * | \_| ''\---/'' | |
 * \ .-\__ `-` ___/-. /
 * ___`. .' /--.--\ `. . __
 * ."" '< `.___\_<|>_/___.' >'"".
 * | | : `- \`.;`\ _ /`;.`/ - ` : | |
 * \ \ `-. \_ __\ /__ _/ .-` / /
 * ======`-.____`-.___\_____/___.-`____.-'======
 * `=---=' bug泛滥 佛已瘫痪
"""
# rsio/core/backends/cv2_backend.py
import os
import numpy as np
from pathlib import Path
from typing import Literal, Sequence
from loguru import logger

from .base_backend import ImageBackend
from ..utils.exceptions import *
from ..utils import (catch_exception, require_attr_not_empty, require_python_library, type_check, ArrayShapeConverter)


class OpencvImage(ImageBackend, backend_name='cv2'):
    open_mode = Literal['r', 'w']

    @property
    def auto_temp_path(self):
        raise NotSupportError('不支持auto_temp_path属性！')

    @property
    def current_temp_path(self):
        raise NotSupportError('不支持current_temp_path属性！')

    def _checked_mode(self, mode: open_mode) -> open_mode:
        if mode not in ['r', 'w']:
            raise ImageModeError(f'不支持的打开模式：{mode}，请传入 "r" 或 "w"')
        return mode

    @require_python_library('cv2', 'opencv-python')
    def _open(self, out_width=None, out_height=None, out_channel=3, **kwargs):
        import cv2
        if self.mode == 'r':
            with catch_exception(ImageOpenError()):
                self._img_array = cv2.imdecode(np.fromfile(self.file_path, dtype=np.uint8), kwargs.get('flags', 1))
        else:
            if out_width and out_height:
                array_shape = (out_height, out_width, out_channel) if out_channel > 1 else (out_height, out_width)
                self._img_array = np.zeros(array_shape, dtype=np.uint8)

    @property
    def img_data(self):
        raise NotSupportError('不支持img_data属性！')

    @img_data.setter
    def img_data(self, img_data):
        raise NotSupportError('不支持img_data属性！')

    def set_img_data(self, img_data) -> 'ImageBackend':
        raise NotSupportError('不支持img_data属性！')

    def set_img_array(
            self,
            array: np.ndarray,
            x_offset: int = 0,
            y_offset: int = 0,
            band_list: list[int] = None
    ) -> 'OpencvImage':
        """
        设置图像数组
        :param array: numpy.ndarray
        :param x_offset: x轴偏移
        :param y_offset: y轴偏移
        :param band_list: 波段列表
        :return: None
        """
        with catch_exception(ImageProcessError()):
            array = ArrayShapeConverter.array_shape_to_cv2(array)
            array_height, array_width = (array_shape := array.shape[:2])
            if self.img_array is None:
                if len(array_shape) == 3:
                    new_shape = (array_height + y_offset, array_width + x_offset, array_shape[2])
                else:
                    new_shape = (array_height + y_offset, array_width + x_offset)
                self._img_array = np.zeros(new_shape, dtype=array.dtype)
            if band_list is None:
                self._img_array[y_offset:y_offset + array_height, x_offset:x_offset + array_width] = array
            else:
                self._img_array[
                    y_offset:y_offset + array_height, x_offset:x_offset + array_width, band_list] = array
        return self

    @require_attr_not_empty('img_array')
    def save(self, save_path: str = None, params=None):
        with catch_exception(ImageWriteError("cv2写入图像失败！")):
            import cv2
            save_path = save_path or self.file_path
            os.makedirs(os.path.dirname(save_path), exist_ok=True)
            ext = Path(save_path).suffix.lower()
            success, encoded_image = cv2.imencode(ext, self.img_array, params)
            encoded_image.tofile(save_path)

    @property
    @require_attr_not_empty('img_array')
    def size(self) -> tuple[int, ...]:
        return self.img_array.shape[1::-1]

    @property
    @require_attr_not_empty('img_array')
    def channel(self) -> int:
        if len(self.shape) == 2:
            return 1
        return self.shape[-1]

    @require_attr_not_empty('img_array')
    def resize(self,
               target_size: tuple[int, int] | int,
               keep_ratio: bool = False,
               pad: int = None,
               resample: int = None,
               box: list[int] | tuple[int, int, int, int] = None,
               out: np.ndarray = None,
               fx: float = None,
               fy: float = None,
               ) -> 'OpencvImage':
        self._img_array = self.resize_img(
            self.img_array, target_size, keep_ratio, pad,
            resample=resample, box=box, out=out, fx=fx, fy=fy
        )
        return self

    @require_attr_not_empty('img_array')
    def reverse_rgb(self) -> 'OpencvImage':
        with catch_exception(ImageProcessError()):
            if self.channel == 3:
                self._img_array = self.img_array[..., ::-1]
            elif self.channel > 3:
                self.img_array[..., :3] = self.img_array[..., 2::-1]
            else:
                logger.warning(f'当前array的通道数为 {self.channels}，无需进行RGB反转！')
            return self

    @require_attr_not_empty('img_array')
    @type_check
    def read_window_array(
            self,
            x_off: int = 0,
            y_off: int = 0,
            window_x_size: int = None,
            window_y_size: int = None,
            band_indexes: int | list[int] = None,
    ) -> np.ndarray:
        with catch_exception(ImageReadError()):
            window_x_size = window_x_size or self.width
            window_y_size = window_y_size or self.height
            window_array = self.img_array[y_off:y_off + window_y_size, x_off:x_off + window_x_size]
            if band_indexes and len(window_array.shape) == 3:
                window_array = window_array[..., band_indexes]
            if len(array_shape := window_array.shape) == 3 and array_shape[2] == 1:
                window_array = window_array[..., 0]
            return window_array

    @require_attr_not_empty('img_array')
    def show(self, window_name: str = None):
        self.show_image(self.img_array, window_name or self.file_stem)

    @require_attr_not_empty('img_array')
    @type_check
    def crop(self,
             x_off: int = 0,
             y_off: int = 0,
             window_x_size: int = None,
             window_y_size: int = None
             ) -> 'OpencvImage':
        """
        裁剪图片
        :param x_off: 裁剪的起始x坐标
        :param y_off: 裁剪的起始y坐标
        :param window_x_size: 裁剪的宽度
        :param window_y_size: 裁剪的高度
        :return: 裁剪后的图片对象
        """
        x_off, y_off, window_x_size, window_y_size = self.checked_crop_window(self.width, self.height, x_off, y_off,
                                                                              window_x_size, window_y_size)
        self._img_array = self.img_array[y_off:y_off + window_y_size, x_off:x_off + window_x_size]
        return self

    @classmethod
    def cropped(
            cls,
            image: 'OpencvImage',
            x_off: int = 0,
            y_off: int = 0,
            window_x_size: int = None,
            window_y_size: int = None
    ) -> 'OpencvImage':
        x_off, y_off, window_x_size, window_y_size = cls.checked_crop_window(image.width, image.height, x_off, y_off,
                                                                             window_x_size, window_y_size)
        cropped_array = image.img_array[y_off:y_off + window_y_size, x_off:x_off + window_x_size]
        cropped_image = cls('', 'w').set_img_array(cropped_array)
        return cropped_image

    @require_attr_not_empty('img_array')
    def convert_to_rgb(self) -> 'OpencvImage':
        self._img_array = ArrayShapeConverter.array_shape_to_rgb(self.img_array)
        return self

    @require_attr_not_empty('img_array')
    def convert_to_gray(self) -> 'OpencvImage':
        import cv2
        self._img_array = cv2.cvtColor(self.img_array, cv2.COLOR_BGR2GRAY)
        return self

    def convert_to_open_shp(self):
        raise NotSupportError('不支持转 open_shp 操作！')

    def reproject(self, *args, **kwargs) -> 'OpencvImage':
        raise NotSupportError('不支持 reproject 操作！')

    @staticmethod
    @require_python_library('cv2', 'opencv-python')
    @type_check
    def write_array(file_path: str, array: np.ndarray, params: Sequence[int] = None):
        import cv2
        with catch_exception(ImageWriteError('cv2写入图片出错！')):
            array = ArrayShapeConverter.array_shape_to_cv2(array)
            ext = Path(file_path).suffix.lower()
            success, encoded_image = cv2.imencode(ext, array, params)
            encoded_image.tofile(file_path)

    @staticmethod
    @require_python_library('cv2', 'opencv-python')
    def show_image(img_array: np.ndarray, window_name: str = 'image'):
        import cv2
        with catch_exception(ImageShowError()):
            img_array = ArrayShapeConverter.array_shape_to_cv2(img_array)
            cv2.imshow(window_name, img_array)
            cv2.waitKey(0)

    @staticmethod
    @require_python_library('cv2', 'opencv-python')
    @type_check
    def resize_img(
            img_array: np.ndarray,
            target_size: tuple[int, int] | int,
            keep_ratio: bool = False,
            pad: int = None,
            resample: int = None,
            out: np.ndarray = None,
            fx: float = None,
            fy: float = None,
            box: list[int] | tuple[int, int, int, int] = None,
    ) -> np.ndarray:
        """
        使用cv2对图像进行resize
        :param img_array: 图像数组
        :param target_size: 目标尺寸，可以是int或者tuple
        :param keep_ratio: 是否保持横纵比例
        :param pad: 填充值
        :param resample: 重采样方法,cv2.INTER_LINEAR,cv2.INTER_NEAREST。。。
        :param out: 输出数组
        :param fx: x方向缩放比例
        :param fy: y方向缩放比例
        :param box: 裁剪框
        :return:
        """
        import cv2

        with catch_exception(ImageProcessError('图像resize操作失败！')):
            img_array = ArrayShapeConverter.array_shape_to_cv2(img_array)
            if box is not None:
                img_array = img_array[box[1]:box[3], box[0]:box[2]]
            if isinstance(target_size, int):
                target_size = (target_size, target_size)
            if not keep_ratio:
                return cv2.resize(img_array, target_size, out, fx, fy, resample)
            # 计算缩放比例
            src_height, src_width = img_array.shape[:2]
            dst_width, dst_height = target_size
            scale = min(dst_width / src_width, dst_height / src_height)
            # 计算新的尺寸
            new_width = int(src_width * scale)
            new_height = int(src_height * scale)
            resized_img = cv2.resize(img_array, (new_width, new_height), out, fx, fy, resample)
            # 如果不填充，直接返回缩放后的图像
            if pad is None:
                return resized_img
            # 创建填充图像
            result = np.full((dst_height, dst_width, img_array.shape[2]), pad, dtype=img_array.dtype)
            # 计算粘贴位置
            paste_x = (dst_width - new_width) // 2
            paste_y = (dst_height - new_height) // 2
            # 将缩放后的图像粘贴到中心位置
            result[paste_y:paste_y + new_height, paste_x:paste_x + new_width] = resized_img
            return result

    @staticmethod
    @type_check
    def reversed_rgb(img_array: np.ndarray) -> np.ndarray:
        img_array = ArrayShapeConverter.array_shape_to_cv2(img_array.copy())
        img_shape = img_array.shape
        match len(img_shape):
            case 2:
                logger.warning('img_array的维度为2，无需进行RGB反转！')
            case 3:
                img_array[..., :3] = img_array[..., 2::-1]

        return img_array

    def crop_by_geo_bounds(self, geo_bounds: tuple[float, float, float, float]) -> 'OpencvImage':
        raise NotSupportError('不支持 crop_by_geo_bounds 操作！')

    @staticmethod
    def colormap(img_data):
        raise NotSupportError('不支持 colormap！')
