"""
tests/test_dataset_loading.py
-----------------------------
Parametrized loading tests for all registered datasets.

Each dataset is attempted once. Outcomes:
  - PASS  : dataset loaded and shapes/dtypes are correct
  - SKIP  : file not found (expected in environments without data)
  - FAIL  : any other exception (genuine loading error)
"""

import gc

import numpy as np
import pytest

from haphazard.data import _DATASET_REGISTRY
from haphazard import load_dataset, load_model


# ---------------------------------------------------------------------------
# Build parametrize list from the live registry at collection time
# ---------------------------------------------------------------------------

def _get_params():
    params = []
    for name in _DATASET_REGISTRY:
        kwargs = (
            {"n_samples": 100, "n_features": 10, "task": "classification", "num_classes": 2}
            if name == "dummy"
            else {}
        )

        mask_params = {
            "scheme": "probabilistic",
            "availability_prob": 0.5,
            "norm": "zscore",
        }
        params.append(pytest.param(name, kwargs, mask_params, id=name))
    return params


# ---------------------------------------------------------------------------
# Tests
# ---------------------------------------------------------------------------

@pytest.mark.parametrize("name, kwargs, mask_params", _get_params())
def test_dataset_loads(name, kwargs, mask_params):
    try:
        dataset = load_dataset(name, base_path="../", **kwargs, **mask_params)
    except FileNotFoundError as e:
        pytest.skip(f"Data file not found for '{name}': {e}")

    assert dataset.x.shape == (dataset.n_samples, dataset.n_features), \
        f"x shape mismatch: got {dataset.x.shape}"
    assert dataset.mask.shape == (dataset.n_samples, dataset.n_features), \
        f"mask shape mismatch: got {dataset.mask.shape}"
    assert dataset.y.shape == (dataset.n_samples,), \
        f"y shape mismatch: got {dataset.y.shape}"

    assert dataset.x.dtype == np.float64, \
        f"x dtype should be float64, got {dataset.x.dtype}"
    assert dataset.mask.dtype == np.bool_, \
        f"mask dtype should be bool, got {dataset.mask.dtype}"

    if dataset.task == "classification":
        assert dataset.y.dtype == np.int64, \
            f"y dtype should be int64, got {dataset.y.dtype}"
    elif dataset.task == "regression":
        assert dataset.y.dtype == np.float64, \
            f"y dtype should be float64, got {dataset.y.dtype}"
    else:
        raise ValueError(
            f"`task` attribute must be 'classification' or 'regression', got '{dataset.task}'"
        )

    # Free the arrays explicitly before gc, as datasets can be large
    del dataset.x, dataset.y, dataset.mask
    del dataset
    gc.collect()


# ---------------------------------------------------------------------------
# Dummy model pass-through
# ---------------------------------------------------------------------------

@pytest.mark.parametrize("name, kwargs, mask_params", _get_params())
def test_dataset_dummy_model(name, kwargs, mask_params):
    try:
        dataset = load_dataset(name, base_path="../", **kwargs, **mask_params)
    except FileNotFoundError as e:
        pytest.skip(f"Data file not found for '{name}': {e}")

    model = load_model("Dummy")
    results = model.fit(dataset, seed=42)

    n = dataset.n_samples

    if dataset.task == "classification":
        assert "labels"     in results
        assert "preds"      in results
        assert "logits"     in results
        assert "time_taken" in results
        assert "is_logit"   in results

        assert results["labels"].shape == (n,), \
            f"labels shape mismatch: got {results['labels'].shape}"
        assert results["preds"].shape == (n,), \
            f"preds shape mismatch: got {results['preds'].shape}"

        if dataset.num_classes == 2:
            assert results["logits"].shape == (n,), \
                f"binary logits shape mismatch: got {results['logits'].shape}"
        else:
            assert results["logits"].shape == (n, dataset.num_classes), \
                f"multiclass logits shape mismatch: got {results['logits'].shape}"

        assert results["labels"].dtype == np.int64
        assert results["preds"].dtype  == np.int64
        assert results["logits"].dtype == np.float64
        assert isinstance(results["is_logit"], bool)
        assert isinstance(results["time_taken"], float)

    elif dataset.task == "regression":
        assert "targets"    in results
        assert "preds"      in results
        assert "time_taken" in results

        assert results["targets"].shape == (n,), \
            f"targets shape mismatch: got {results['targets'].shape}"
        assert results["preds"].shape == (n,), \
            f"preds shape mismatch: got {results['preds'].shape}"

        assert results["targets"].dtype == np.float64
        assert results["preds"].dtype   == np.float64
        assert isinstance(results["time_taken"], float)

    del dataset
    gc.collect()