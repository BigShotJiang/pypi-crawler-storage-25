"""
tests/test_seeding.py
---------------------
Unit tests for haphazard.utils.seeding

Tests cover:
- Normal operation: seed_everything sets all RNGs correctly
- Reproducibility: same seed yields identical random outputs across libs
- State persistence: get_seed returns the last set seed
- Error handling: invalid types and out-of-range values
- Environment variables: PYTHONHASHSEED and CUBLAS_WORKSPACE_CONFIG are set
- CuDNN flags: deterministic mode and benchmark flag
- deterministic_torch flag: opt-in strict mode
- Boundary seeds: 0 and 2**32 - 1
- Re-seeding: overwriting a prior seed
"""

import os
import random

import numpy as np
import pytest
import torch

from haphazard.utils.seeding import get_seed, seed_everything


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def _sample_random() -> float:
    return random.random()


def _sample_numpy() -> float:
    return np.random.random()


def _sample_torch_cpu() -> float:
    return torch.rand(1).item()


def _collect_samples(seed: int) -> tuple[float, float, float]:
    """Seed then draw one sample from each RNG."""
    seed_everything(seed)
    return _sample_random(), _sample_numpy(), _sample_torch_cpu()


# ---------------------------------------------------------------------------
# Normal operation
# ---------------------------------------------------------------------------

class TestSeedEverythingNormal:

    def test_returns_none(self):
        assert seed_everything(42) is None

    def test_active_seed_stored(self):
        seed_everything(42)
        assert get_seed() == 42

    def test_env_pythonhashseed(self):
        seed_everything(42)
        assert os.environ.get("PYTHONHASHSEED") == "42"

    def test_env_cublas_workspace(self):
        seed_everything(42)
        assert os.environ.get("CUBLAS_WORKSPACE_CONFIG") == ":4096:8"

    def test_cudnn_deterministic_true(self):
        seed_everything(42)
        assert torch.backends.cudnn.deterministic is True

    def test_cudnn_benchmark_false(self):
        seed_everything(42)
        assert torch.backends.cudnn.benchmark is False

    def test_deterministic_torch_flag(self):
        # Should not raise on supported ops
        seed_everything(42, deterministic_torch=True)
        _ = torch.zeros(3) + torch.ones(3)

    def test_deterministic_torch_default_is_false(self):
        # Default should not enable strict mode (no error expected on normal ops)
        seed_everything(42)
        _ = torch.rand(10)


# ---------------------------------------------------------------------------
# Reproducibility
# ---------------------------------------------------------------------------

class TestReproducibility:

    def test_random_module_reproducible(self):
        seed_everything(0)
        a = _sample_random()
        seed_everything(0)
        b = _sample_random()
        assert a == b

    def test_numpy_reproducible(self):
        seed_everything(0)
        a = _sample_numpy()
        seed_everything(0)
        b = _sample_numpy()
        assert a == b

    def test_torch_cpu_reproducible(self):
        seed_everything(0)
        a = _sample_torch_cpu()
        seed_everything(0)
        b = _sample_torch_cpu()
        assert a == b

    def test_all_libs_reproducible_together(self):
        s1 = _collect_samples(123)
        s2 = _collect_samples(123)
        assert s1 == s2

    def test_different_seeds_differ(self):
        s1 = _collect_samples(1)
        s2 = _collect_samples(2)
        # At least one RNG should differ (astronomically unlikely to collide)
        assert s1 != s2

    def test_numpy_array_reproducible(self):
        seed_everything(99)
        a = np.random.randint(0, 1000, size=50)
        seed_everything(99)
        b = np.random.randint(0, 1000, size=50)
        np.testing.assert_array_equal(a, b)

    def test_torch_tensor_reproducible(self):
        seed_everything(77)
        a = torch.randn(10)
        seed_everything(77)
        b = torch.randn(10)
        assert torch.equal(a, b)

    def test_sequential_draws_are_deterministic(self):
        """Multiple draws after a single seed call should match exactly."""
        seed_everything(42)
        seq1 = [random.random() for _ in range(20)]

        seed_everything(42)
        seq2 = [random.random() for _ in range(20)]

        assert seq1 == seq2

    def test_reseed_resets_rng_state(self):
        """Re-seeding mid-experiment should reset state, not continue it."""
        seed_everything(42)
        _ = _sample_numpy()          # advance state
        seed_everything(42)          # re-seed
        after_reseed = _sample_numpy()

        seed_everything(42)          # fresh baseline
        baseline = _sample_numpy()

        assert after_reseed == baseline


# ---------------------------------------------------------------------------
# get_seed
# ---------------------------------------------------------------------------

class TestGetSeed:

    def test_returns_correct_seed(self):
        seed_everything(7)
        assert get_seed() == 7

    def test_reflects_latest_seed(self):
        seed_everything(1)
        seed_everything(2)
        assert get_seed() == 2

    def test_raises_before_seed_everything(self, monkeypatch):
        import haphazard.utils.seeding as seeding_mod
        monkeypatch.setattr(seeding_mod, "_ACTIVE_SEED", None)
        with pytest.raises(RuntimeError, match="seed_everything"):
            get_seed()

    def test_seed_usable_as_sklearn_random_state(self):
        seed_everything(42)
        from sklearn.linear_model import SGDClassifier
        clf = SGDClassifier(random_state=get_seed())
        assert clf.random_state == 42


# ---------------------------------------------------------------------------
# Input validation — TypeError
# ---------------------------------------------------------------------------

class TestTypeErrors:

    @pytest.mark.parametrize("bad_seed", [
        3.14, "42", None, [42], (42,), True, False,
    ])
    def test_non_integer_raises_type_error(self, bad_seed):
        with pytest.raises(TypeError, match="integer"):
            seed_everything(bad_seed)

    def test_bool_raises_type_error(self):
        """bool is a subclass of int in Python — library explicitly rejects it."""
        with pytest.raises(TypeError):
            seed_everything(True)


# ---------------------------------------------------------------------------
# Input validation — ValueError
# ---------------------------------------------------------------------------

class TestValueErrors:

    @pytest.mark.parametrize("bad_seed", [
        -1, -1000, 2**32, 2**32 + 1, -(2**32),
    ])
    def test_out_of_range_raises_value_error(self, bad_seed):
        with pytest.raises(ValueError, match=r"\[0, 2\*\*32 - 1\]"):
            seed_everything(bad_seed)


# ---------------------------------------------------------------------------
# Boundary seeds
# ---------------------------------------------------------------------------

class TestBoundarySeeds:

    def test_seed_zero(self):
        seed_everything(0)
        assert get_seed() == 0
        assert os.environ["PYTHONHASHSEED"] == "0"

    def test_seed_max(self):
        max_seed = 2**32 - 1
        seed_everything(max_seed)
        assert get_seed() == max_seed
        assert os.environ["PYTHONHASHSEED"] == str(max_seed)

    def test_seed_zero_reproducible(self):
        s1 = _collect_samples(0)
        s2 = _collect_samples(0)
        assert s1 == s2

    def test_seed_max_reproducible(self):
        s1 = _collect_samples(2**32 - 1)
        s2 = _collect_samples(2**32 - 1)
        assert s1 == s2