"""
tests/test_metrics.py
---------------------
Unit tests for haphazard.utils.metrics

Covers:
  - Individual metric functions: accuracy, balanced_accuracy, auroc, auprc,
    number_of_errors, regression_metrics
  - Unified dispatcher: get_all_metrics (classification + regression)
  - Edge cases: perfect predictions, all-wrong, single-class edge, invalid inputs
"""

import numpy as np
import pytest

from haphazard.utils.metrics import (
    accuracy,
    auroc,
    auprc,
    balanced_accuracy,
    get_all_metrics,
    number_of_errors,
    regression_metrics,
)


# ---------------------------------------------------------------------------
# Fixtures
# ---------------------------------------------------------------------------

N = 200

@pytest.fixture
def binary():
    rng = np.random.default_rng(0)
    true  = rng.integers(0, 2, size=N)
    preds = rng.integers(0, 2, size=N)
    probs = rng.random(N)
    return true, preds, probs

@pytest.fixture
def multiclass():
    rng = np.random.default_rng(1)
    K = 4
    true   = rng.integers(0, K, size=N)
    preds  = rng.integers(0, K, size=N)
    logits = rng.random((N, K))
    return true, preds, logits, K

@pytest.fixture
def regression():
    rng = np.random.default_rng(2)
    true  = rng.random(N)
    preds = true + rng.normal(0, 0.1, size=N)
    return true, preds


# ---------------------------------------------------------------------------
# accuracy
# ---------------------------------------------------------------------------

class TestAccuracy:

    def test_perfect(self):
        y = np.array([0, 1, 2, 1])
        assert accuracy(y, y) == 1.0

    def test_all_wrong(self):
        true  = np.array([0, 0, 0, 0])
        preds = np.array([1, 1, 1, 1])
        assert accuracy(true, preds) == 0.0

    def test_half_correct(self):
        true  = np.array([0, 0, 1, 1])
        preds = np.array([0, 1, 0, 1])
        assert accuracy(true, preds) == 0.5

    def test_returns_float(self, binary):
        true, preds, _ = binary
        assert isinstance(accuracy(true, preds), float)


# ---------------------------------------------------------------------------
# balanced_accuracy
# ---------------------------------------------------------------------------

class TestBalancedAccuracy:

    def test_perfect(self):
        y = np.array([0, 1, 0, 1])
        assert balanced_accuracy(y, y) == 1.0

    def test_returns_float(self, binary):
        true, preds, _ = binary
        assert isinstance(balanced_accuracy(true, preds), float)

    def test_value_between_0_and_1(self, binary):
        true, preds, _ = binary
        score = balanced_accuracy(true, preds)
        assert 0.0 <= score <= 1.0


# ---------------------------------------------------------------------------
# number_of_errors
# ---------------------------------------------------------------------------

class TestNumberOfErrors:

    def test_perfect_is_zero(self):
        y = np.array([0, 1, 2])
        assert number_of_errors(y, y) == 0

    def test_all_wrong(self):
        true  = np.array([0, 0, 0])
        preds = np.array([1, 1, 1])
        assert number_of_errors(true, preds) == 3

    def test_partial_errors(self):
        true  = np.array([0, 1, 0, 1])
        preds = np.array([0, 0, 0, 1])
        assert number_of_errors(true, preds) == 1

    def test_returns_int(self, binary):
        true, preds, _ = binary
        assert isinstance(number_of_errors(true, preds), int)


# ---------------------------------------------------------------------------
# auroc
# ---------------------------------------------------------------------------

class TestAUROC:

    def test_binary_perfect(self):
        true  = np.array([0, 0, 1, 1])
        probs = np.array([0.1, 0.2, 0.8, 0.9])
        score = auroc(true, probs, num_classes=2, is_logit=False)
        assert score == 1.0

    def test_binary_random_in_range(self, binary):
        true, _, probs = binary
        score = auroc(true, probs, num_classes=2, is_logit=False)
        assert 0.0 <= score <= 1.0

    def test_binary_with_logits(self, binary):
        true, _, _ = binary
        rng = np.random.default_rng(0)
        logits = rng.normal(size=N)
        score = auroc(true, logits, num_classes=2, is_logit=True)
        assert 0.0 <= score <= 1.0

    def test_multiclass_in_range(self, multiclass):
        true, _, logits, K = multiclass
        score = auroc(true, logits, num_classes=K, is_logit=False)
        assert 0.0 <= score <= 1.0

    def test_multiclass_with_logits(self, multiclass):
        true, _, logits, K = multiclass
        score = auroc(true, logits, num_classes=K, is_logit=True)
        assert 0.0 <= score <= 1.0

    def test_invalid_num_classes_raises(self, binary):
        true, _, probs = binary
        with pytest.raises(ValueError):
            auroc(true, probs, num_classes=1, is_logit=False)

    def test_returns_float(self, binary):
        true, _, probs = binary
        assert isinstance(auroc(true, probs, num_classes=2, is_logit=False), float)


# ---------------------------------------------------------------------------
# auprc
# ---------------------------------------------------------------------------

class TestAUPRC:

    def test_binary_perfect(self):
        true  = np.array([0, 0, 1, 1])
        probs = np.array([0.1, 0.2, 0.8, 0.9])
        score = auprc(true, probs, num_classes=2, is_logit=False)
        assert score == 1.0

    def test_binary_in_range(self, binary):
        true, _, probs = binary
        score = auprc(true, probs, num_classes=2, is_logit=False)
        assert 0.0 <= score <= 1.0

    def test_multiclass_in_range(self, multiclass):
        true, _, logits, K = multiclass
        score = auprc(true, logits, num_classes=K, is_logit=False)
        assert 0.0 <= score <= 1.0

    def test_invalid_num_classes_raises(self, binary):
        true, _, probs = binary
        with pytest.raises(ValueError):
            auprc(true, probs, num_classes=1, is_logit=False)

    def test_returns_float(self, binary):
        true, _, probs = binary
        assert isinstance(auprc(true, probs, num_classes=2, is_logit=False), float)


# ---------------------------------------------------------------------------
# regression_metrics
# ---------------------------------------------------------------------------

class TestRegressionMetrics:

    def test_perfect_predictions_rmse_zero(self):
        true = np.array([1.0, 2.0, 3.0])
        result = regression_metrics(true, true)
        assert result["rmse"] == pytest.approx(0.0)

    def test_rmse_in_range(self, regression):
        true, preds = regression
        result = regression_metrics(true, preds)
        assert result["rmse"] >= 0.0

    def test_returns_dict_with_rmse(self, regression):
        true, preds = regression
        result = regression_metrics(true, preds)
        assert isinstance(result, dict)
        assert "rmse" in result
        assert isinstance(result["rmse"], float)

    def test_known_rmse(self):
        true  = np.array([0.0, 0.0, 0.0, 0.0])
        preds = np.array([1.0, 1.0, 1.0, 1.0])
        result = regression_metrics(true, preds)
        assert result["rmse"] == pytest.approx(1.0)


# ---------------------------------------------------------------------------
# get_all_metrics — classification
# ---------------------------------------------------------------------------

class TestGetAllMetricsClassification:

    def test_returns_dict(self, binary):
        true, preds, probs = binary
        result = get_all_metrics(true, preds, probs, task="classification",
                                 num_classes=2, is_logit=False)
        assert isinstance(result, dict)

    def test_classification_keys_present(self, binary):
        true, preds, probs = binary
        result = get_all_metrics(true, preds, probs, task="classification",
                                 num_classes=2, is_logit=False)
        for key in ("acc", "bal_acc", "num_errors", "auroc", "auprc"):
            assert key in result, f"Missing key: {key}"

    def test_classification_no_logits_skips_auroc_auprc(self, binary):
        true, preds, _ = binary
        result = get_all_metrics(true, preds, task="classification",
                                 num_classes=2)
        assert "auroc" not in result
        assert "auprc" not in result

    def test_multiclass_keys_present(self, multiclass):
        true, preds, logits, K = multiclass
        result = get_all_metrics(true, preds, logits, task="classification",
                                 num_classes=K, is_logit=False)
        for key in ("acc", "bal_acc", "num_errors", "auroc", "auprc"):
            assert key in result

    def test_all_values_are_numeric(self, binary):
        true, preds, probs = binary
        result = get_all_metrics(true, preds, probs, task="classification",
                                 num_classes=2, is_logit=False)
        for k, v in result.items():
            assert isinstance(v, (int, float)), f"Non-numeric value for '{k}': {v}"


# ---------------------------------------------------------------------------
# get_all_metrics — regression
# ---------------------------------------------------------------------------

class TestGetAllMetricsRegression:

    def test_returns_dict(self, regression):
        true, preds = regression
        result = get_all_metrics(true, preds, task="regression")
        assert isinstance(result, dict)

    def test_rmse_key_present(self, regression):
        true, preds = regression
        result = get_all_metrics(true, preds, task="regression")
        assert "rmse" in result

    def test_rmse_non_negative(self, regression):
        true, preds = regression
        result = get_all_metrics(true, preds, task="regression")
        assert result["rmse"] >= 0.0


# ---------------------------------------------------------------------------
# get_all_metrics — invalid task
# ---------------------------------------------------------------------------

class TestGetAllMetricsInvalidTask:

    def test_unknown_task_raises_value_error(self):
        true  = np.array([0, 1, 0])
        preds = np.array([0, 0, 1])
        with pytest.raises(ValueError, match="Unsupported task"):
            get_all_metrics(true, preds, task="ranking")