"""
tests/test_models.py
--------------------
Parametrized functional tests for all registered models.

Each model is run against binary and multi-class classification datasets.
Models not listed in _MODEL_PARAMS are skipped (not a failure).
"""

import gc

import pytest

from haphazard import load_model, load_dataset
from haphazard.utils import get_all_metrics
from haphazard.models import _MODEL_REGISTRY


# ---------------------------------------------------------------------------
# Models under test — add params here to enable, remove/comment to skip
# ---------------------------------------------------------------------------

_MODEL_PARAMS: dict = {
    "dummy": {},

    # "dynfo": {},
    # "fae": {},
    # "haptransformer": {},
    # "hi2": {},
    # "nb3": {},
    # "ocds": {},
    # "olifl": {},
    # "olvf": {},
    # "orf3v": {},
    # "ovfm": {},
    # "v2f": {},
}

_CLASSIFICATION_CASES = [
    pytest.param("binary",     2, id="binary"),
    pytest.param("multiclass", 6, id="multiclass"),
]


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def _get_model_params():
    params = []
    for model_name in _MODEL_REGISTRY:
        model_params = _MODEL_PARAMS.get(model_name)
        params.append(pytest.param(model_name, model_params, id=model_name))
    return params


# ---------------------------------------------------------------------------
# Tests
# ---------------------------------------------------------------------------

@pytest.mark.parametrize("model_name, model_params", _get_model_params())
@pytest.mark.parametrize("_case_name, num_classes", _CLASSIFICATION_CASES)
def test_model_classification(model_name, model_params, _case_name, num_classes):
    if model_params is None:
        pytest.skip(f"'{model_name}' not enabled in _MODEL_PARAMS")

    dataset = load_dataset(
        "Dummy",
        n_samples=100,
        n_features=10,
        task="classification",
        num_classes=num_classes,
        scheme="probabilistic",
        availability_prob=0.5,
        norm="zscore",
    )

    model = load_model(model_name)
    output = model(dataset, **model_params.copy())

    results = get_all_metrics(
        true=output["labels"],
        preds=output["preds"],
        logits=output["logits"],
        task="classification",
        num_classes=dataset.num_classes,
        is_logit=output["is_logit"],
    )
    results["time_taken"] = output["time_taken"]

    assert isinstance(results, dict), "get_all_metrics must return a dict"
    assert "time_taken" in results

    del dataset, model, output, results
    gc.collect()