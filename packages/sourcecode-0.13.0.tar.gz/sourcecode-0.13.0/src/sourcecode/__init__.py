"""sourcecode — Genera mapas de contexto estructurado para agentes IA."""

__version__ = "0.13.0"
