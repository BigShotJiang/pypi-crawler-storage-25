# Copyright (c) 2024-2026 Centre National d'Etudes Spatiales (CNES).
#
# This file is part of AtmoTools
# (see https://github.com/CNES/AtmoTools).
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

def remove_lines(text: str, lines_to_remove: int | list[int] | tuple[int, ...] | slice):
    """
    Removes specified lines from a given text.

    :param text: The input string containing multiple lines.
    :param lines_to_remove: The line number(s) to remove. 0 is the first line.
                            If a single integer is provided, only that line is removed.
                            Negative integers can be used to refer to lines from the end (e.g., -1 for the last line).
                            A slice can be used to specify a range of lines to remove
                            (e.g., slice(2, 5) for third to fourth lines) .
    :return: A new string with the specified lines removed.
    """
    # Split the string into lines
    lines = text.splitlines()

    if isinstance(lines_to_remove, int):
        lines_to_remove = [lines_to_remove]
    elif isinstance(lines_to_remove, slice):
        # Convert slice to a range of indices
        lines_to_remove = range(lines_to_remove.start or 0, lines_to_remove.stop, lines_to_remove.step or 1)

    # Convert negative indices to positive indices
    valid_indices = []
    for num in lines_to_remove:
        if num < 0:
            num = len(lines) + num  # Convert negative index
        valid_indices.append(num)

    # Create a new list with lines that are not to be removed
    new_lines = [line for index, line in enumerate(lines, start=0) if index not in valid_indices]

    # Reassemble the string from the remaining lines
    return "\n".join(new_lines)


def align_left(text: str) -> str:
    """
    Return the input string aligned to the left by removing the spaces at the beginning of each line

    :param text: the text to align
    :return: text aligned to the left
    """
    # Split the text into lines
    lines = text.splitlines()

    # Find the number of spaces at the beginning of the first line that contains non-space characters
    indentations = [len(line) - len(line.lstrip()) for line in lines if line.strip()]

    # If there are non-empty lines, adjust the indentation
    if indentations:
        min_indent = min(indentations)
    else:
        min_indent = 0

    # Remove spaces from the beginning of each line according to the detected indentation
    result = '\n'.join(line[min_indent:] for line in lines)

    return result


def add_line(initial_string: str, *other_strings: str) -> str:
    """
    Return the initial string with a new line for each 'other_string' input

    :param initial_string: the string to modify
    :param other_strings: the strings to add as lines
    :return: the initial string with new lines
    """
    string_list = [initial_string]
    string_list.extend(other_strings)
    # Exclude empty string from the concatenation
    filtered_strings = [line for line in string_list if line]

    return "\n".join(filtered_strings)
