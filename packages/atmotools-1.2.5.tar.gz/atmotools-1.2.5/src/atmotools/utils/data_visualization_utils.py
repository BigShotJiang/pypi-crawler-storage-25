# Copyright (c) 2024-2026 Centre National d'Etudes Spatiales (CNES).
#
# This file is part of AtmoTools
# (see https://github.com/CNES/AtmoTools).
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

import matplotlib.pyplot as plt
import matplotlib.cm as cm
import numpy as np
from typing import Literal


def plot_vectors(y_vectors, x_vectors: list = None, colors: list[str] = None, titles: list[str] = None,
                 x_labels: list[str] = None, y_labels: list[str] = None, labels: list[str] = None,
                 markers: list[str] = None, fig_title: str = None, show: bool = True) -> plt.Figure:
    """
    Plot one vector per graph using matplotlib.pyplot.subplots. Each vector is determined by an ordinate vector
    (element of y_vectors) and an abscissa vector (element of x_vectors).
    Optional parameters enable to customize the display.

    :param y_vectors: List of ordinate vectors to display (y-axis)
    :param x_vectors: (optional) List of abscissa vectors (x-axis)
    :param colors: (optional) List of colors. One color per vector to display 
    :param titles: (optional) List of titles. One title per graph
    :param x_labels: (optional) List of labels for each x-axis
    :param y_labels: (optional) List of labels for each y-axis
    :param labels: (optional) List of labels for each vector
    :param markers: (optional) List of line markers
    :param fig_title: (optional) The title of the figure
    :param show: (optional) If True, shows the figure
    :return: the figure

    For more details about:
    - markers: https://matplotlib.org/stable/api/markers_api.html#module-matplotlib.markers
    - colors: https://matplotlib.org/stable/users/explain/colors/colors.html#colors-def
    """
    n_vectors = len(y_vectors)

    # Initialize parameters if not set
    if x_vectors is None:
        x_vectors = [None] * n_vectors
    if colors is None:
        colors = ["red"] * n_vectors
    if titles is None:
        titles = [f"Graph {i}" for i in range(n_vectors)]
    if x_labels is None:
        x_labels = ["x"] * n_vectors
    if y_labels is None:
        y_labels = ["y"] * n_vectors
    if labels is None:
        labels = [None] * n_vectors
    if markers is None:
        markers = ["o"] * n_vectors

    # Determine the number of rows and columns for the grid
    n_cols = int(np.ceil(np.sqrt(n_vectors)))  # Calculate the number of columns (approximately the square root)
    n_rows = int(np.ceil(n_vectors / n_cols))  # Calculate the required number of rows

    # Create a figure and subplots
    fig, axs = plt.subplots(n_rows, n_cols, figsize=(n_cols * 5, n_rows * 4))

    # Set the title of the whole figure
    if fig_title:
        fig.suptitle(fig_title)

    # Flatten axes for easier iteration
    axs = axs.flatten()

    # Display each vector in a subplot
    for i in range(n_vectors):
        plot_vector_on_ax(axs[i], y_vectors[i], x_vectors[i], color=colors[i], marker=markers[i], label=labels[i],
                          title=titles[i], x_label=x_labels[i], y_label=y_labels[i])

    # Hide unused axes
    for j in range(n_vectors, len(axs)):
        axs[j].axis('off')

    # Adjusts spacing between plots
    plt.tight_layout()
    # Display the graphs
    if show:
        plt.show()
    return fig


def plot_vector_on_ax(ax: plt.Axes, y, x: list = None, color: str = "red", title: str = "One vector",
                      x_label: str = "x", y_label: str = "y", label: str = None, marker: str = "+"):
    """
    Plot the input y vector as function of x with the input instance of matplotlib.pyplot.Axes.
    Optional parameters enable to customize the display.

    :param ax: the instance of Axes to use to plot
    :param y: the ordinate vector to display (y-axis)
    :param x: (optional) the abscissa vector to display (x-axis)
    :param color: (optional) the color of the vector to plot
    :param title: (optional) the title of the graph
    :param x_label: (optional) the label of the x-axis
    :param y_label: (optional) the label of the y-axis
    :param label: (optional) the label of the vector
    :param marker: (optional) the line marker of the vector to plot

    For more details about:
    - markers: https://matplotlib.org/stable/api/markers_api.html#module-matplotlib.markers
    - colors: https://matplotlib.org/stable/users/explain/colors/colors.html#colors-def
    """
    # Initialize x if not set
    if x is None:
        x = [i for i in range(len(y))]

    if label:
        ax.plot(x, y, color=color, marker=marker, label=label)
        ax.legend()
    else:
        ax.plot(x, y, color=color, marker=marker)

    # Set title
    ax.set_title(title)

    # Set labels
    ax.set_xlabel(x_label)
    ax.set_ylabel(y_label)

    # Add a grid with details
    activate_grid_on_ax(ax, grid_lines='major', color='0.5', linewidth=0.5)
    activate_grid_on_ax(ax, grid_lines='minor', color='0.8', linewidth=0.5, ticks_on=True)


def plot_vector(y, x: list = None, color: str = "red", title: str = "One plot", x_label: str = "x",
                y_label: str = "y", label: str = None, marker: str = "+", show: bool = True) -> plt.Figure | None:
    """
    Plot a vector using matplotlib.pyplot.
    Optional parameters enable to customize the display.

    :param y: the ordinate vector to display (y-axis)
    :param x: (optional) the abscissa vector (x-axis)
    :param color: (optional) the color of the vector to display
    :param title: (optional) the title of the graph
    :param x_label: (optional) the label of the x-axis
    :param y_label: (optional) the label of the y-axis
    :param label: (optional) the label of the marker
    :param marker: (optional) the line marker
    :param show: (optional) If True, shows the figure
    :return: the figure
    """
    # Initialize x if not set
    if x is None:
        x = [i for i in range(len(y))]

    # Plot
    line, = plt.plot(x, y, color=color, marker=marker)

    # Set the label
    if label:
        line.set_label(label)
        plt.legend()

    # Set title
    plt.title(title)

    # Set the labels of axes
    plt.xlabel(x_label)
    plt.ylabel(y_label)

    # Add a grid with details
    activate_grid(grid_lines='major', color='0.5', linewidth=0.5)
    activate_grid(grid_lines='minor', color='0.8', linewidth=0.5, ticks_on=True)

    # Display the graph
    if show:
        plt.show()

    if plt.get_fignums():
        return plt.gcf()
    else:
        return None


def plot_multiple_vectors(y_list, x: list = None, colors: list[str] = None, title: str = "Multiple Vectors",
                          x_label: str = "x", y_label: str = "y", labels: list[str] = None, markers: list[str] = None,
                          show: bool = True) -> plt.Figure | None:
    """
    Plots multiple input y vectors as functions of x on the same graph.
    Optional parameters enable to customize the display.

    :param y_list: the list of ordinate vectors to display (y-axis)
    :param x: (optional) the abscissa vector (x-axis)
    :param colors: (optional) List of colors. One color per vector to display
    :param title: (optional) the title of the graph
    :param x_label: (optional) the label of the x-axis
    :param y_label: (optional) the label of the y-axis
    :param labels: (optional) List of labels for each vector
    :param markers: (optional) List of line markers
    :param show: (optional) If True, shows the figure
    :return: the figure

    For more details about:
    - markers: https://matplotlib.org/stable/api/markers_api.html#module-matplotlib.markers
    - colors: https://matplotlib.org/stable/users/explain/colors/colors.html#colors-def
    """
    n_vectors = len(y_list)

    # Initialize parameters if not set
    if colors is None:
        # Define a color map to generate different colors for each vector
        colors = cm.Paired(np.linspace(0, 1, n_vectors))
    if labels is None:
        labels = [f"Vector {i + 1}" for i in range(n_vectors)]
    if markers is None:
        markers = ["o"] * n_vectors

    # Plot each y vector on the same graph
    if x is None:
        x = [i for i in range(len(y_list[0]))]
    for i in range(n_vectors):
        plt.plot(x, y_list[i], label=labels[i], color=colors[i], marker=markers[i])

    # Set the labels of axes
    plt.xlabel(x_label)
    plt.ylabel(y_label)

    # Set the title
    plt.title(title)

    # Show the legend to distinguish between the vectors
    plt.legend()

    # Add a grid with details
    activate_grid(grid_lines='major', color='0.5', linewidth=0.5)
    activate_grid(grid_lines='minor', color='0.8', linewidth=0.5, ticks_on=True)

    # Display the graph
    if show:
        plt.show()

    if plt.get_fignums():
        return plt.gcf()
    else:
        return None


def activate_grid(grid_lines: Literal["major", "minor", "both"] = "both", axis: Literal["x", "y", "both"] = "both",
                  ticks_on: bool = False, **args):
    """
    Activate the grid of the current figure with the input options.

    :param grid_lines: (optional) The grid lines to apply the changes on
    :param axis: (optional) The axis to apply the changes on
    :param ticks_on: (optional) If True, displays minor ticks on the Axes
    :param args: (optional) Line2D properties

    Fore more details about args, see: https://matplotlib.org/stable/api/_as_gen/matplotlib.pyplot.grid.html
    """
    plt.grid(True, which=grid_lines, axis=axis, **args)
    if ticks_on:
        plt.minorticks_on()


def activate_grid_on_ax(ax: plt.Axes, grid_lines: Literal["major", "minor", "both"] = "both",
                        axis: Literal["x", "y", "both"] = "both", ticks_on: bool = False, **args):
    """
    Activate the grid of the current figure using the input Axes instance with the input options.

    :param ax: the Axes instance used to plot the grid
    :param grid_lines: (optional) The grid lines to apply the changes on
    :param axis: (optional) The axis to apply the changes on
    :param ticks_on: (optional) If True, displays minor ticks on the Axes
    :param args: (optional) Line2D properties

    Fore more details about args, see: https://matplotlib.org/stable/api/_as_gen/matplotlib.pyplot.grid.html
    """
    ax.grid(True, which=grid_lines, axis=axis, **args)
    if ticks_on:
        ax.minorticks_on()
