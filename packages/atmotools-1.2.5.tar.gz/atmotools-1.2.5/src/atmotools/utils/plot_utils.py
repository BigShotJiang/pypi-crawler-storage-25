# Copyright (c) 2024-2026 Centre National d'Etudes Spatiales (CNES).
#
# This file is part of AtmoTools
# (see https://github.com/CNES/AtmoTools).
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

import numpy as np
import pandas as pd
import plotly.express as px
import matplotlib.pyplot as plt
from mpl_toolkits.basemap import Basemap

import atmotools.utils.hdf_netcdf_tools as hdfu
import atmotools.utils.path_utils as pu


def plot1D(var: hdfu.HDFVariable, display: str = None, save_path: str = None):
    """
        This function plot data from a var with 0 or 1 dimensions.

        :param var_path: group/name of the variable
        :param data: Contains the data of the variable to plot
        :param display : None (default), plotly, matplotlib. Display or not the figure created.
        :param save_path : Path of the folder to save the figure. None (default), "folder/to/save/the/figure"
    """

    data = var.get_data()
    dimensions = var.get_dimensions()
    var_path = f"{var.group_path}/{var.name}"

    try :
        X = range(len(data))

    except TypeError as e:
        title = f"Error with {var_path}"
        X = range(0)
        Y = range(0)
        x_label = ""
        y_label = ""
        print(f"ERROR : Data in {var_path} is not a list.")

    else :
        title = var_path
        y_label = list(dimensions.keys())[0] if dimensions else var_path
        x_label = "Index"
        Y = data

    finally :
        match display :
            case 'matplotlib':
                # Create the figure 
                plt.plot(X,Y)
                plt.title(title)
                plt.xlabel(x_label)
                plt.ylabel(y_label)
                if save_path:
                    plt.savefig(f"{save_path}/{pu.get_last_element_in_path(var_path)[0]}")
                    print(f"Figure saved as {save_path}/{pu.get_last_element_in_path(var_path)[0]}.png")
                plt.show()

            case 'plotly' :

                fig = px.line(dict(x = X, y = Y), 
                    x = 'x', y = 'y', 
                    title = title,
                    labels={
                        'x' : x_label,
                        'y' : y_label
                    })
                if save_path :
                    fig.write_html(f"{save_path}/{pu.get_last_element_in_path(var_path)[0]}.html")
                    print(f"Figure saved as {save_path}/{pu.get_last_element_in_path(var_path)[0]}.html")
                fig.show()

            case _:
                plt.plot(X,Y)
                plt.title(title)
                plt.xlabel(x_label)
                plt.ylabel(y_label)
                if save_path:
                    plt.savefig(f"{save_path}/{pu.get_last_element_in_path(var_path)[0]}")
                    print(f"Figure saved as {save_path}/{pu.get_last_element_in_path(var_path)[0]}.png")
                plt.clf()


def plot2D(var: hdfu.HDFVariable, x: str = None, y: str = None, display: str = None, save_path: str = None, dims_values: dict = {}):
    """
        This function plot data from a HdfVariable on a heatmap with 2 dimensions or more.

        :param var: variable to plot.
        :param x : dimension name taken for the x-axe
        :param y : dimension name taken for the y-axe
        :param display : None (default), plotly, matplotlib. Display or not the figure created.
        :param save_path : Path of the folder to save the figure. None (default), "folder/to/save/the/figure"
        :param dims_values :  Dimensions and their value exemple: {'dimension1' : 5, 'dimension2' = 1} 
    """

    # Get var dimensions 
    dimensions = var.get_dimensions()

    # Get a copy of var dimensions. Will contain selected dimensions and values 
    selected_dimensions = dimensions.copy()
    # Reduce by 1 the value in the dict to have the max value in the size of data.    
    for key,value in selected_dimensions.items():
        selected_dimensions[key] = value-1

    # Get the path of the variable group/name
    var_path = f"{var.group_path}/{var.name}"
    
    
    # Check validity of arguments x, y and dims_values.
    if x not in dimensions.keys() and x!= None:
        print(f"ERROR : {x} is not a dimension")
        print(f"Valid dimensions : {dimensions}")
        return None
    if y not in dimensions.keys() and y!= None:
        print(f"ERROR : {x} is not a dimension")
        print(f"Valid dimensions : {dimensions}")
        return None
    for dim in dims_values:
        if dim not in dimensions.keys():
            print(f"ERROR : {x} is not a dimension")
            print(f"Valid dimensions : {dimensions}")
            return None
    if (len(dimensions) - len(dims_values))<2 :
        print("ERROR : Too many dimensions are fixed. ")
        print("Fixed dimensions : ",dims_values)
        print("Dimensions : ",dimensions)
        return None

    # Attribute the choosen value for each dimensions selected in argument by the user 
    selected_dimensions.update(dims_values)

    if x and y :
        selected_dimensions[x] = slice(None)
        selected_dimensions[y] = slice(None) 
    else : 
    # Determine the 2 dimensions to take if x or y not given. 
        for dim in selected_dimensions.keys():
            if selected_dimensions[dim]  != slice(None) and (x == None or y == None) and dim not in dims_values.keys():
                selected_dimensions[dim] = slice(None)
                if x == None :
                    x = dim
                else :
                    y = dim
    
    # Get data with selected dimensions
    selected_data = var.get_value_by_dim(selected_dimensions)  

    if list(dimensions.keys()).index(x) < list(dimensions.keys()).index(y):
        selected_data = np.transpose(selected_data)

    # Display final parameters :
    print(f"Variable: {var_path}")
    print(f"x = {x}, y = {y}")
    print(f"Selected dimensions: {selected_dimensions}")
    print(f"Dimensions size: {dimensions}")

    # Create figure
    match display :
        case 'matplotlib':
            plot_matplotlib(selected_data,title = f"{var_path} \n {selected_dimensions}", x_label = x, y_label = y, save_path = save_path)

        case 'plotly':
            fig = px.imshow(selected_data, labels=dict(x=x, y=y), origin = 'lower', title = f"{var_path} {selected_dimensions}", aspect="auto")
            if save_path :
                fig.write_html(f"{save_path}/{pu.get_last_element_in_path(var_path)[0]}.html")
                print(f"Figure saved as {save_path}/{pu.get_last_element_in_path(var_path)[0]}.html")
            fig.show()

        case _:
            plot_matplotlib(selected_data,title = var_path, x_label = x, y_label = y, save_path = save_path, display = False) if save_path else None

def plot_map(var: hdfu.HDFVariable, lat: np.ndarray = [], lon: np.ndarray = [],  display: str = None, save_path: str = None, dims_values: dict = {}):
    """
        This function plot data from an HdfVariable on a map with given data about latitude and longitude. The HdfVariable can have one or more dimension. 

        :param var: variable to plot.
        :param lat : lat data
        :param lon : lon data
        :param display : None (default), plotly, matplotlib. Display or not the figure created.
        :param save_path : Path of the folder to save the figure. None (default), "folder/to/save/the/figure"
        :param dims_values :  Dimensions and their value exemple: {'dimension1' : 5, 'dimension2' = 1} 
    """

    # Get var dimensions 
    dimensions = var.get_dimensions()

    # Get a copy of var dimensions. Will contain selected dimensions and values 
    selected_dimensions = dimensions.copy()
    # Reduce by 1 the value in the dict to have the max value in the size of data.    
    for key,value in selected_dimensions.items():
        selected_dimensions[key] = value-1

    # Get the path of the variable group/name
    var_path = f"{var.group_path}/{var.name}"
    
    
    # Check validity of arguments x, y and dims_values.
    for dim in dims_values:
        if dim not in dimensions.keys():
            print(f"ERROR : {x} is not a dimension")
            print(f"Valid dimensions : {dimensions}")
            return None
    if (len(dimensions) - len(dims_values))<1:
        print("ERROR : Too many dimensions are fixed. ")
        print("Fixed dimensions : ",dims_values)
        print("Dimensions : ",dimensions)
        return None

    # Attribute the choosen value for each dimensions selected in argument by the user 
    selected_dimensions.update(dims_values)

    # Select all data in only 1 dimension but not in a dimensions fixed by the user   
    for dim in selected_dimensions.keys():
        if dim not in dims_values.keys():
            selected_dimensions[dim] = slice(None)
            break
    
    # Get data with selected dimensions
    selected_data = var.get_value_by_dim(selected_dimensions)  

    # Display final parameters :
    print(f"Variable: {var_path}")
    print(f"lat, Lon coordinates")
    print(f"Selected dimensions: {selected_dimensions}")
    print(f"Dimensions size: {dimensions}")

    # Create figure
    match display :
        case 'matplotlib':
            m = Basemap(projection='merc', llcrnrlat=-80,urcrnrlat=80,llcrnrlon=-180,urcrnrlon=180)
            x, y = m(lon,lat)
            m.drawmapboundary(fill_color='#99ffff')
            m.fillcontinents(color='#cc9966',lake_color='#99ffff')
            m.scatter(x,y,3,marker='o',c=selected_data)
            plt.title(f"{var_path} \n {selected_dimensions}")
            if save_path:
                plt.savefig(f"{save_path}/{pu.get_last_element_in_path(var_path)[0]}")
                print(f"Figure saved as {save_path}/{pu.get_last_element_in_path(var_path)[0]}.png")
            plt.show()

        case 'plotly':
            fig = px.scatter_map(selected_data, lat = lat, lon = lon, color=selected_data, title = f"{var_path} <br> {selected_dimensions}")
            if save_path :
                fig.write_html(f"{save_path}/{pu.get_last_element_in_path(var_path)[0]}.html")
                print(f"Figure saved as {save_path}/{pu.get_last_element_in_path(var_path)[0]}.html")
            fig.show()

        case _:
            fig = px.scatter_map(selected_data, lat = lat, lon = lon, color=selected_data, title = var_path)
            if save_path :
                fig.write_html(f"{save_path}/{pu.get_last_element_in_path(var_path)[0]}.html")
                print(f"Figure saved as {save_path}/{pu.get_last_element_in_path(var_path)[0]}.html")



def plot_matplotlib(data: np.ndarray , title: str = "Figure1",x_label: str = None, y_label: str = None, save_path: str = None, display: bool = True):
    """
        This function plot a heatmap (pcolor) using matplotlib
        
        :param data : Contains data to plot
        :param title : Title of the figure
        :param x_label: Name of the label for x-axis
        :param y_label: Name of the label for y-axis
        :param save_path : Path of the folder to save the figure. None (default), "folder/to/save/the/figure"
        :param display : None (default), plotly, matplotlib. Display or not the figure created.

    """

    plt.pcolor(data).set_array(data)
    plt.colorbar()

    plt.title(title)
    plt.xlabel(x_label)
    plt.ylabel(y_label)
    if save_path:
        plt.savefig(f"{save_path}/{pu.get_last_element_in_path(title)[0]}")
        print(f"Figure saved as {save_path}/{pu.get_last_element_in_path(title)[0]}.png")
    plt.show() if display else plt.clf()


def plot_plotly(data: np.ndarray , title: str = "Figure1",x_label: str = None, y_label: str = None, save_path: str = None):
    """
        This function plot a heatmap using plotly
        
        :param data : Contains data to plot
        :param title : Title of the figure
        :param x_label: Name of the label for x-axis
        :param y_label: Name of the label for y-axis
        :param save_path : Path of the folder to save the figure. None (default), "folder/to/save/the/figure"
    """
    pass