# Copyright (c) 2024-2026 Centre National d'Etudes Spatiales (CNES).
#
# This file is part of AtmoTools
# (see https://github.com/CNES/AtmoTools).
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

import numpy as np
import atmotools.utils.hdf_netcdf_tools as hdfu
import pandas as pd


def decode_flag(reader: hdfu.AbstractHDFReader, flag_doc: dict[str, tuple],
                  flag_var_path: str,
                  flag_count_key: str | None,
                  nb_bits: int = 16,
                #   bitzero_as_count: bool = True,
                  transpose = False) -> dict[str, list | int]:
    """
    In NetCDF4/HDF5 files, flags are generally stored as an integer, whose binary decomposition represents flag features.
    This function decodes that int value to define the values of the individual flags, according to the documentation of the flag decomposition.
    For example, a flag value of 5, i.e. 101 in binary, corresponds to flag values of 1 for the first and third flags (if each bit corresponds to 1 flag feature in the flag_doc).

    :param: reader
    :param: flag_doc: dictionnary of the physics meanings in the flag, to which is associated its location in the flag bits ( (first_bit, size) )
        Example for a 3-bit int where the first (on the far-right) is for the general quality, and the next two for the clouds {  "General Quality": (0, 1), "Clouds": (1, 2) }.
        IMPORTANT If a flag feature is a subfeature of another flag feature, it should have the same name as its parent feature, with the suffix "_subtype" (its meaning depends on the parent feature value anyway)
    :param: flag_var_path: path of the flag variable to decode
    :param: flag_count_key: if set, the given key (typically, the general quality key) will return the total count of flag features being equal to 1, instead of its own 0 or 1 value.
    :param: nb_bits: number of bits in the flag to decode
    # :param: bitzero_as_count: if set to True, the first bit (which is generally the general quality bit) will return the total count of flag features being equal to 1, instead of its own 0 or 1 value.
    :param: transpose: this should be set to True if the dimensions of the flag are not in the same order as the coordinates.
        For example, if the flag dimensions are (ncol, nline) and the longitude/latitude dimensions are (nline, ncol).

    :return: flags_val: dictionnary of each flag name and its corresponding values for each fov. For single bits, the values are 0 or 1 for each fov.
        If bitzero_as_count is set to True, the first bit is not 0 or 1 but the total number of flags raised (i.e. 1s) in the bit.
    """
    flags_vals = dict()
    # Get the flag data (or its transpose if transpose is set to True)
    all_flags_int = reader.get_var(flag_var_path).get_data().T if transpose else reader.get_var(flag_var_path).get_data()
    # Transform the int values in the data into their binary values
    all_flags_bin = np.vectorize(lambda x : bin(int(x))[2:].zfill(nb_bits))(all_flags_int)
    # Extract the value for each flag feature
    for flag_key in flag_doc:
        # TODO check list size
        # Skip the count bit if it is defined
        if flag_count_key and flag_key == flag_count_key:
            continue
        # if first_bit == 0:
        #     if not bitzero_as_count:
        #         # Turn the binary value of the corresponding bit(s) back to integer
        #         flag_val_int = np.vectorize(lambda x : int(x[-(first_bit + size):], 2))(all_flags_bin)
        #     else:
        #         first_key = flag_key
        #         continue
        # Turn the binary value of the corresponding bit(s) back to integer (does not change for single bits, but for double bits: get 2 and 3 instead of 10 and 11)
        else:
            # Get the location and size of the flag feature to extract the correct bit(s) from the data
            first_bit, size = flag_doc[flag_key]
            flag_val_int = np.vectorize(lambda x : int(x[-(first_bit + size):], 2) if first_bit==0 else \
                                                    int(x[-(first_bit + size):-first_bit], 2))(all_flags_bin)
            # flag_val_int = np.vectorize(lambda x : int(x[-(first_bit + size):-first_bit], 2))(all_flags_bin)
        flags_vals.update( {flag_key: flag_val_int} )
    # Add up the non 0 values for all flag features if the first bit is used as count
    if flag_count_key:
        general_qual_count = [np.vectorize(lambda x : 0 if x==0 else 1)(flags_vals[key]) for key in flags_vals.keys()]
        general_qual_count = np.array(general_qual_count).sum(axis=0, keepdims=False)
        flags_vals.update({flag_count_key: general_qual_count})

    return flags_vals


def get_flag_as_str(flags_int: dict, flag_doc_str: dict, flag_count_key: str | None) -> dict[str, list | str]:
    """
    This method takes the int values of all flag features and returns its corresponding description according to the documentation dictionnary flag_doc.

    :param: flags_int: dictionnary of flag values (as int) by fov obtained from decode_flag function
    :param: flag_doc: detailed documentation for the flag's meaning. It should be in the following format\: {  'valid' \: [ {0\: 'valid', 1\: 'not valid'}, None ],
                            'parent_feature' \: [ {0\: 'aerosols', 1\: 'clouds', 2\: stratospheric aerosol"}, None ],
                            'clouds' \: [ {0\: 'cirrus', 1\: 'stratus', 2\: 'cumulus', 3: 'nimbus'}, ('parent_feature', 1) ]}  ->  'clouds' is a subfeature of 'parent_feature', and it corresponds to the value 1 of 'parent_feature'.
                            The second element of the list should be None if a flag feature is not another flag's subfeature.
    :param: flag_count_key: this is the key in the dictionnary *_flags_int_* that is used as the total count of flags raised, can be None.
    The values for this flag that are different than 0 will be considered as the meaning for 1 specified in the *_flag_doc_str_*

    :return: dictionnary of flattened flag values (as str) by fov
    """
    flags_str = dict()
    flag1d = dict()
    for key in flags_int:
        flag1d[key] = np.array(flags_int[key]).flatten()
    flags_df = pd.DataFrame(flag1d)

    for flag_key in flag_doc_str:
        # Get the flag feature values directly if the flag feature has no parent feature
        if flag_doc_str[flag_key][1] == None:
            # Get the value for the count flag: value for 0 if it is 0, value for 1 if it is 1 or more
            if flag_count_key and flag_key == flag_count_key:
                flag_val_str = np.vectorize(lambda int_key : flag_doc_str[flag_key][0][int_key if int_key==0 else 1])(flag1d[flag_key])
            # Get the string meaning, contained in flag_doc_str of the int value contained in the flattened flags_int, for the flag feature
            else:
                flag_val_str = np.vectorize(lambda int_key : flag_doc_str[flag_key][0][int_key])(flag1d[flag_key])

        # Add a new column for a flag feature if it has a parent feature
        else:
            parent_bit, parent_bit_val = flag_doc_str[flag_key][1]
            # For rows in the dataframe corresponding to the subfeature (i.e. where the 'parent_bit' column has the value 'parent_bit_val'), get the string meaning of the int value contained in the 'subtype' column
            flags_df.loc[flags_df[parent_bit] == parent_bit_val, flag_key] = flags_df.loc[flags_df[parent_bit] == parent_bit_val, parent_bit + "_subtype"].apply(lambda x: flag_doc_str[flag_key][0][x])
            flag_val_str = list(flags_df[flag_key])

        flags_str.update({flag_key: flag_val_str})

    return flags_str



# ### SPECTRUMS

# def get_spectrum_from_lonlat(reader: hdfu.AbstractHDFReader, lon: int, lat: int,
#                              lon_dim_dame: str = "GeoTrack:L1C_AIRS_Science", lat_dim_dame: str = "GeoXTrack:L1C_AIRS_Science",
#                              wn_dim_name: str = "Channel:L1C_AIRS_Science",
#                              spectrum_var_path: str = "/L1C_AIRS_Science/Data Fields/radiances"):
#     spectrum_vals = {'Wave_number': [], 'Absorption': []}
#     spectrum = reader.get_var(spectrum_var_path)
#     for wni in range(spectrum.dimensions[wn_dim_name]):
#         absorption = spectrum.get_value_by_dim({lon_dim_dame: lon, lat_dim_dame: lat, wn_dim_name: wni})
#         spectrum_vals["Wave_number"].append(wni)
#         spectrum_vals["Absorption"].append(absorption if abs(absorption)< 1E8 else 0)
#     return spectrum_vals