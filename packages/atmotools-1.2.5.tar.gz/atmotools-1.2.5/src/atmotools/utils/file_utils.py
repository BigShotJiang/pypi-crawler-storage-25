# Copyright (c) 2024-2026 Centre National d'Etudes Spatiales (CNES).
#
# This file is part of AtmoTools
# (see https://github.com/CNES/AtmoTools).
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

import glob
import os
from typing import TextIO, BinaryIO


def check_file_exists(file_path: str) -> bool:
    """
    Check the file given by the input file path exists

    :param file_path: absolute file path of the file to check
    :return: True if the file exists, else False
    """
    return os.path.isfile(file_path)


def check_file_exists_with_extension(file_path_without_extension: str, extensions: list[str]) -> bool:
    """
    Check the file given by the input file path exists without its extension

    :param file_path: absolute file path of the file to check.
    :param extensions: list of extensions to add to the file path to check
    :return: True if the file exists, else False
    :return existing_extensions: list of extensions with which the file exists
    """
    existing_extensions = []
    for extension in extensions:
        if check_file_exists(file_path_without_extension + extension):
            existing_extensions.append(extension)
        
    if existing_extensions != []:
        return True, existing_extensions
    return False, existing_extensions

def skip_lines(n_lines: int, opened_file: TextIO | BinaryIO):
    """
    In an opened file, move the file cursor n_lines after its current position

    :param n_lines: the number of lines to skip
    :param opened_file: the opened file
    """
    for _ in range(n_lines):
        next(opened_file)


def get_first_line(file: str, encoding: str = "utf-8", ignore_empty_lines: bool = False, lines_to_skip: int = 0):
    """
    Return the first line of a text file

    :param file: the path of the file to read
    :param encoding: (optional) the encoding to use (examples: utf-8, ascii, utf-16, iso-8859-1)
    :param ignore_empty_lines: (optional) if True, ignore the empty lines or containing leading and trailing whitespace
    :param lines_to_skip: (optional) number of lines to skip before returning the "first" line
    :return: the first line of the file, or None if the file is empty
    """
    with open(file, 'r', encoding=encoding) as f:
        # Skip lines if needed
        skip_lines(lines_to_skip, f)

        # Read line by line
        for line in f:
            if ignore_empty_lines:
                # Return the first non-empty line
                stripped_line = line.strip()
                if stripped_line:
                    return stripped_line
            else:
                # Return the first line
                return line.strip()
    return None


def get_last_line(file: str, encoding: str = "utf-8", ignore_empty_lines: bool = False) -> str:
    """
    Returns the last line of a text file by reading it from the end.

    :param file: The path to the text file to read.
    :param encoding: (optional) the encoding to use (examples: utf-8, ascii, utf-16, iso-8859-1)
    :param ignore_empty_lines: (optional) If True, only the last non-empty line will be returned.
                               If False, the last line (even if empty) will be returned.

    :return: The last line of the file, or None if the file is empty.
    """
    # Open the file in binary mode to enable reading from the end
    with open(file, 'rb') as f:
        # Move the file pointer to the end
        f.seek(0, 2)  # SEEK_END
        position = f.tell()  # Get the file size (current position)

        line = b''  # To hold the current line
        while position > 0:
            position -= 1
            f.seek(position)  # Move the pointer one byte back
            byte = f.read(1)  # Read one byte at a time

            if byte == b'\n':  # When newline is found, check for non-empty line
                if ignore_empty_lines and line.strip():
                    return line.decode(encoding)  # Return non-empty line
                elif not ignore_empty_lines:
                    if line:  # If not ignoring empty lines, return the line
                        return line.decode(encoding)
                    else:
                        return ""

                # Reset the line for the next potential line
                line = b''

            else:
                line = byte + line  # Add byte to the front of the line

        # If no newline found, return the remaining line (could be the only line)
        return line.decode(encoding) if line.strip() or not ignore_empty_lines else None


def find_files(*paths: str, recursive=False) -> list[str]:
    """
    Find the absolute paths corresponding to the input paths.
    The input paths may include patterns using wildcards (* or ?).
    Set to True the 'recursive' parameter to find files in all child directories recursively.
    In this case use the '**' wildcard.

    :param paths: paths to find
    :param recursive: (optional) activate the recursive search
    :return: the absolute paths of matching files
    """
    abs_matching_path = []
    for path in paths:
        # Use glob to find files matching the pattern
        matching_files = glob.glob(path, recursive=recursive)
        # Convert relative paths to absolute paths
        abs_matching_path.extend([os.path.abspath(file) for file in matching_files])
    return abs_matching_path
