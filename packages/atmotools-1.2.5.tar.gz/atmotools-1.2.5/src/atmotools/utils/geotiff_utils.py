# Copyright (c) 2024-2026 Centre National d'Etudes Spatiales (CNES).
#
# This file is part of AtmoTools
# (see https://github.com/CNES/AtmoTools).
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

from rioxarray.merge import merge_arrays

import geoviews as gv
from geoviews import opts

import pandas as pd
import numpy as np

import holoviews as hv

from bokeh.embed import file_html, components
from bokeh.resources import CDN

from dash import html

# import matplotlib, matplotlib.pyplot

import os

from dash import Dash

import xarray as xr

### CONSTANTES ###

COLORMAP_TO_USE = 'Greys'
NAN_COLOR = '#00000000'

SCATTER_COLOR = 'blue'
SCATTER_SIZE = 8
SCATTER_OPACITY = 0.9

MAP_HEIGHT, MAP_WIDTH = 600, 1000
IMAGE_HEIGHT, IMAGE_WIDTH = 600, 600

def create_geotiff_tiles(geotiffs : list[xr.DataArray]) -> tuple:
    """
    Create holoviews tiles and general caracteristic of selected geotiffs
    :param geotiffs : List of all selected Geotiffs as xarray.DataArray
    :return Tuple with folowing data : 
        da_mercator : xarray.DataArray containing all selected Geotiffs
        bounds : Boundary of one global Geotiff
        q1 : First quantile of values of global Geotiff
        q3 : Third quatile of values of global Geotiff
        max_value : Maximum value of global Geotiff
        min_value : Minimum value of global Geotiff
        geotiff_tiles : A holoviews tile with all Geotiffs tiles 
    """
    da_mercator = xr.DataArray()
    geotiff_tiles = hv.element.tiles.OSM()

    for i, geotiff in enumerate(geotiffs) :
        # Convert into Mercator projection
        da = geotiff.rio.reproject('EPSG:3857')
        da_mercator = merge_arrays([da_mercator,da], nodata = np.nan) if not i == 0 else da
        # Create holoview dataset (for the image tile)
        hv_dataset_mercator = hv.Dataset(da_mercator, vdims="value", kdims=['x', 'y'])
        # Combine geotiff tiles
        # print(f"Create tile {i}")
        geotiff_tiles = geotiff_tiles * hv.Image(hv_dataset_mercator) if not i == 0 else hv.Image(hv_dataset_mercator)

    # Bounds of the image
    min_lat = np.nanmin(da_mercator.rio.reproject('EPSG:4327')['x'])
    min_lon = np.nanmin(da_mercator.rio.reproject('EPSG:4327')['y'])
    max_lat = np.nanmax(da_mercator.rio.reproject('EPSG:4327')['x'])
    max_lon = np.nanmax(da_mercator.rio.reproject('EPSG:4327')['y'])
    bounds = [min_lat, min_lon, max_lat, max_lon]

    # Max, min and quantiles
    q1 = da_mercator.quantile(0.25).values.item() # First quantile
    q3 = da_mercator.quantile(0.75).values.item() # Third quantile
    max_value = da_mercator.max().values.item() # Max value
    min_value = da_mercator.min().values.item()# Min value

    return (da_mercator,bounds, q1, q3, max_value, min_value, geotiff_tiles)

def plot_geotiff(df_scatter = pd.DataFrame({'Latitude': [], 'Longitude': [], 'Line': [], 'For': [], 'Fov': [], 'Eng_path' : []}), geotiffs : list[xr.DataArray] = []) -> html.Iframe :
    """
    Create an iframe of a bokeh figure containing plot of Geotiff on a map.

    :param df_scatter : A dataframe containing information of all selected fov on the map (Lat, Lon, Line, For, Fov, Path of the ENG file)
    :param geotiffs :   List of all selected Geotiffs as xarray.DataArray

    :return iframe : Return an html.iframe containing a bokeh figure of Geotiffs 
    """

    ######## CREATE GEOTIFF TILES ########

    (da_mercator, bounds, q1, q3, max_value, min_value, geotiff_tiles) = create_geotiff_tiles(geotiffs)

    ######## HOLOVIEWS ########

    hv.extension('bokeh', logo=False)
    clipping = {'NaN': NAN_COLOR} # Color for NaN values
    # Default parameters for tiles
    hv.opts.defaults(
        hv.opts.Image(alpha=1, cmap=COLORMAP_TO_USE, clim = (q1*0.9, q3*1.1), height=IMAGE_HEIGHT, width=IMAGE_WIDTH, colorbar=True, active_tools=['wheel_zoom'], clipping_colors=clipping),
        hv.opts.Tiles(active_tools=['wheel_zoom'], height=MAP_HEIGHT, width=MAP_WIDTH)
    )

    # Tile of the map
    hv_tiles_osm = hv.element.tiles.OSM()

    # Modify dataframe for display information (Line, For, Fov start at 1 instead of 0) 
    displayed_df = df_scatter
    displayed_df['Line'] = [i+1 for i in displayed_df['Line']]   
    displayed_df['For'] = [i+1 for i in displayed_df['For']]   
    displayed_df['Fov'] = [i+1 for i in displayed_df['Fov']]   

    # Tile of Scatter on the map
    hv_scatter = gv.Points(displayed_df, ['Longitude', 'Latitude']).opts(
        opts.Points(
            width=MAP_WIDTH,
            height=MAP_HEIGHT,
            title='Geotiff',
            color=SCATTER_COLOR,
            size=SCATTER_SIZE,
            marker='circle',
            alpha=SCATTER_OPACITY,
            tools=['hover', 'pan', 'wheel_zoom', 'reset', 'tap'],
            # nonselection_fill_alpha=0.5,     # Opacité des points non sélectionnés
            # selection_fill_alpha=1.0
        )
    )

    # Combine all tiles
    hv_combined = hv_tiles_osm * geotiff_tiles * hv_scatter

    # Transform holoviews object into bokeh object
    plot = hv.render(hv_combined, backend='bokeh')

    ######## CONVERTION TO HTML ########

    # Convert into Iframe to display in Dash
    html_string = file_html(plot, CDN, "GeoTIFF Heatmap")
    iframe = html.Iframe(
                id = 'bokeh-map',
                srcDoc=html_string,
                style={"width": "100%", "height": "600px", "border": "none"}
            )

    return iframe