# Copyright (c) 2024-2026 Centre National d'Etudes Spatiales (CNES).
#
# This file is part of AtmoTools
# (see https://github.com/CNES/AtmoTools).
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

import json
import os.path
from abc import ABC, abstractmethod
import warnings
from texttable import Texttable
import plotly.express as px
import matplotlib.pyplot as plt

import numpy as np
from numpy.typing import ArrayLike
import xarray as xr
import netCDF4 as nc
from pyhdf.HDF import HDF, HC
from pyhdf.SD import SD, SDC, SDS
from pyhdf.V import V, VG
from pyhdf.VS import VS
from typing import Union

import atmotools.utils.path_utils as pu
import atmotools.utils.file_utils as fu
import atmotools.utils.string_utils as su


# ===========================
# CONSTANTS
# ===========================
# Standard names for the attribute fillValue in HDF and NetCDF files
FILL_VALUE_NAMES = ["_FillValue", "missing_value"]
# Name of the attribute scale_factor
SCALE_FACTOR_NAME = "scale_factor"
# Name of the attribute add_offset
ADD_OFFSET_NAME = "add_offset"
# Name of the attribute valid_min
VALID_MIN_NAME = "valid_min"
# Name of the attribute valid_max
VALID_MAX_NAME = "valid_max"

# Default fillValue
DEFAULT_FILL_VALUE = -9999

# ===========================
# CLASSES
# ===========================
class HDFVariable:
    """
    This class represents an HDF or NetCDF variable.

    Attributes:
        name: the name of the variable
        data: the value of the variable as a numpy array
        dimensions: the dictionary of dimensions: the name of dimensions as keys and their values as values
        dtype: the data type of the variable
        attributes: the attributes of the variable
        file_path: the path of the file where the variable is/will be located
        group_path: the path of the group where the variable is/will be located
    """

    def __init__(self, name: str, data: np.ndarray, dimensions: dict, dtype: str | np.dtype = None,
                 attributes: dict = None, file_path=None, group_path=None):
        """
        Initialize the class attributes.

        :param name: the name of the variable
        :param data: the value of the variable as a numpy array
        :param dimensions: the dictionary of dimensions: the name of dimensions as keys and their values as values
        :param dtype: (optional) the data type of the variable. If not set, use the dtype of data.
        :param attributes: (optional) the attributes of the variable. If not set, use the empty dictionary.
        :param file_path: (optional) the path of the file where the variable is/will be located
        :param group_path: (optional) the path of the group where the variable is/will be located
        """
        # Check dimensions
        if tuple(dimensions.values()) != data.shape:
            # raise RuntimeError(f"Dimensions of variable {name} are different from the values dimensions: "
            #                    f"{tuple(dimensions.values())} != {data.shape} ")
            print(f"Dimensions of variable {name} are different from the values dimensions: "
                               f"{tuple(dimensions.values())} != {data.shape} ")
        # Set the name
        self.name = name
        # Set the data
        self.data = data
        # Set the dimensions
        self.dimensions = dimensions

        # Set the data type
        if dtype is None:
            self.dtype = data.dtype
        else:
            self.dtype = dtype

        # Set the attributes
        self.attributes = attributes if attributes is not None else {}
        # Set the file path
        self.file_path = file_path
        # Set the group path
        self.group_path = group_path

        #Set de default mode
        # Mode 1 : Applies scale factor and addoffset and replace fillvalues with NaN 
        # Mode 2 : Does Not apply scale factor and addoffset and not replace fillvalues with NaN
        self.mode = 1

    def change_mode(self, mode_value) :
        self.mode = mode_value

    def get_data(self):
        """
        Return the data as a numpy array

        :return: the data
        """
        # It's possible to have 2 mode of data. 
        match self.mode :
            # Mode 1 : Like Xarray (Applies scale factor and addoffset and replace fillvalues with NaN)
            # To give data like Xarray
            case 1 :
                try :
                    if self.dtype in [np.int16, np.uint32, np.uint8, np.int8] :
                        data = self.data
                    else :  
                        masked_data = np.ma.masked_equal(self.data, self.get_fill_value()) # Ignore fillvalues in get_data() 
                        masked_data.fill_value = np.nan # Define the value to fill masked values with. 
                        data = masked_data.filled() #Replace masked value with NaN 

                except Exception as e:
                    data = self.data
                    print(f"[WARN] Impossible to replace fillvalues with NaN in variable {self.name} with datatype : {self.dtype}. Error : {e}")
            
            # Mode 2 : Does not apply scale factor and addoffset and does not replace fillvalues with NaN)
            case 2 :
                data = self.data
                ao = self.get_add_offset() if self.get_add_offset() != None else 0
                sf = self.get_scale_factor() if self.get_scale_factor() != None else 1

                # Case when data contains NaN values. We have to replace NaN by Fillvalues
                if np.any(np.isnan(self.data)) : 
                    data = np.nan_to_num(data, nan=self.get_fill_value())

                #  Remove scale factor and addoffset from the data values
                masked_data = np.ma.masked_equal(data, self.get_fill_value()) #To don't take the Fillvalues 
                data = np.array([(x-ao)/sf for x in masked_data])

            # Mode : Default  (It's the mode 1)      
            case _ : 
                try :
                    if self.dtype in [np.int16, np.uint32, np.uint8, np.int8] :
                        data = self.data

                    else :  
                        masked_data = np.ma.masked_equal(self.data, self.get_fill_value()) # Ignore fillvalues in get_data() 
                        masked_data.fill_value = np.nan # Define the value to fill masked values with. 
                        data = masked_data.filled() #Replace masked value with NaN 

                except Exception as e:
                    data = self.data
                    print(f"[WARN] Impossible to replace fillvalues with NaN in variable {self.name} with datatype : {self.dtype}. Error : {e}")

        return data

    def get_min(self, axis = None):
        """
        Return the minimum values of the data along axis

        :return: the min of the data
        """
        # return self.get_data().min(axis=axis)
        try : 
            if not axis or np.array(axis).dtype == int:
                return np.nanmin(self.get_data(),axis=axis)

            else:
                dim_idx = tuple([list(self.dimensions.keys()).index(dim_name) for dim_name in np.array(axis)]) if np.array(axis).shape != () else tuple([list(self.dimensions.keys()).index(axis)])
                return np.nanmin(self.get_data(), axis=dim_idx)
        except Exception as e: 
            print(self.name, self.dtype, e)
            return None

    def get_max(self, axis = None):
        """
        Return the maximum values of the data along axis

        :return: the max of the data
        """
        # return self.get_data().max(axis=axis)
        try :
            if not axis or np.array(axis).dtype == int:
                return np.nanmax(self.get_data(),axis=axis)
            else:
                dim_idx = tuple([list(self.dimensions.keys()).index(dim_name) for dim_name in np.array(axis)]) if np.array(axis).shape != () else tuple([list(self.dimensions.keys()).index(axis)])
                return np.nanmax(self.get_data(),axis=dim_idx)
        except Exception as e: 
            print(self.name, self.dtype, e)
            return None

    def get_mean(self, axis = None):
        """
        Return the mean of the data along axis (dimension names or dimension indexes)

        :return: the mean of the data
        """
        if not axis or np.array(axis).dtype == int:
            return self.get_data().mean(axis=axis)
        else:
            dim_idx = tuple([list(self.dimensions.keys()).index(dim_name) for dim_name in np.array(axis)]) if np.array(axis).shape != () else tuple([list(self.dimensions.keys()).index(axis)])
            return self.get_data().mean(axis=dim_idx)

    def get_shape(self):
        """
        Return the shape of the data

        :return: the shape of the data
        """
        return self.data.shape

    def get_attribute(self, attr_name):
        """
        Return the value of the input attribute

        :param attr_name: the name of the attribute to extract
        :return: the value of the attribute
        """
        return self.attributes.get(attr_name, None)
    
    def get_dimensions(self):
        """
        Return the dimensions

        :return: the dimensions
        """
        return self.dimensions


    def set_attribute(self, attr_name, attr_value):
        """
        Set the value of the input attribute with the given value.

        :param attr_name: the name of the attribute to set
        :param attr_value: the value of the attribute
        """
        self.attributes[attr_name] = attr_value

    def describe(self, call_print: bool = True, prefix: str = "  -- \033[1m"):
        """
        Return a description of the variable as a string: file path, group path, name, dimensions, data type
        and attributes. By default, print the output description.

        :param call_print: (optional) If True, print the description
        :param prefix: (optional) a string to add before each line of the summary
        :return: the description of the variable
        """
        # Return a summary of the variable: name, dimensions, data type and attributes
        result = ""
        result = su.add_line(result, prefix + f"Name: \033[0m{self.name}")
        result = su.add_line(result, prefix + f"Group path: \033[0m{self.group_path}")
        result = su.add_line(result, prefix + f"File path: \033[0m{self.file_path}")
        result = su.add_line(result, prefix + f"Dimensions: \033[0m{self.dimensions}")
        result = su.add_line(result, prefix + f"Data Type: \033[0m{self.dtype}")
        if self.attributes:
            result = su.add_line(result, prefix + f"Attributes: \033[0m{self.attributes}")

        if call_print:
            print(result + '\033[0m')
        return result

    def change_type(self, dtype: str | np.dtype, force: bool = False):
        """
        Convert the attribute data to the given type and update the attribute dtype.

        :param dtype: the new data type
        :param force: (optional) If True, modify the attribute data even if it implies a loss of data.
        :raises RuntimeWarning: If parameter force is False and the new data type implies a loss of data
        """
        converted_array = self.data.astype(dtype=dtype)
        # Check any loss of data
        if force or np.array_equal(converted_array, self.data):
            self.data = converted_array
            self.dtype = self.data.dtype
        else:
            raise RuntimeWarning(f"Cannot convert array of type {self.dtype} into {dtype}: data may be lost. "
                                 f"Please use the optional input 'force=True' to convert anyway.")

    def get_fill_value(self):
        """
        Return the fill value if it exists. Search for the attributes '_FillValue' and 'missing_value'.

        :return: the fill value
        """
        result = None
        for fill_name in FILL_VALUE_NAMES:
            fill_value = self.get_attribute(fill_name)
            if fill_value:
                result = fill_value
                break
        return result

    def get_add_offset(self):
        """
        Return the value of add_offset if it exists.

        :return: the value of add_offset
        """
        return self.get_attribute(ADD_OFFSET_NAME)

    def get_scale_factor(self):
        """
        Return the value of scale_factor if it exists.

        :return: the value of scale_factor
        """
        return self.get_attribute(SCALE_FACTOR_NAME)

    def get_valid_min(self):
        """
        Return the value of valid_min if it exists.

        :return: the value of valid_min
        """
        return self.get_attribute(VALID_MIN_NAME)

    def get_valid_max(self):
        """
        Return the value of valid_max if it exists.

        :return: the value of valid_max
        """
        return self.get_attribute(VALID_MAX_NAME)

    def get_value_by_dim(self, dim_selected: dict[str, Union[int, list, slice]]):
        """
        Return the value of the variable according to the input dimensions.

        :param dim_selected: dictionary of dimensions to extract and their values (for example: {"<dim_name>":[0,4]})
        :return: the filtered value
        """
        # Check all input dimensions exist
        for dim_sel_name in dim_selected.keys():
            if dim_sel_name not in self.dimensions.keys():
                raise ValueError(f"Dimension {dim_sel_name} not in dimensions of the variable: {self.dimensions}")

        # Initialize the list of indices of values to extract
        indices = []

        for dim_name in self.dimensions.keys():
            if dim_name in dim_selected.keys():
                # Keep the values of the input dimensions
                indices.append(dim_selected[dim_name])
            else:
                # For other dimensions, keep all values
                indices.append(slice(None))
        # Extract values of the variable
        return self.data[tuple(indices)]


class AbstractHDFReader(ABC):
    """
    Abstract class to open a HDF5 or NetCDF file and read its data.

    Attributes:
        file_path(str): the absolute file path of the HDF file to read
        vars: the dictionary of variables already read via 'get_var': {variable_path: HDFVariable}
    """

    def __init__(self, file_path: str) -> None:
        """
        Initialize the class attributes and read the input file.
        :param file_path: the file path of the HDF file to read
        """
        self.file_path = os.path.abspath(file_path)
        self._init_reader()
        self.vars = dict()

    def get_file_path(self) -> str:
        """
        Return the path of HDF file read
        :return: file path
        """
        return self.file_path

    @abstractmethod
    def _init_reader(self) -> None:
        """
        Check the existence of the file and initialize the reader and its specific attributes
        """
        # Check the file exists before opening it with a reader
        if not fu.check_file_exists(self.file_path):
            raise RuntimeError(f"File does not exist: {self.file_path}")

    @abstractmethod
    def _generate_hdf_var(self, var_name: str, group_path: str) -> HDFVariable:
        """
        Generates an instance of HDFVariable corresponding to the input variable

        :param var_name: the name of the variable
        :param group_path: the path of the group where is located the variable
        :return the generated instance of HDFVariable
        """
        pass

    def get_var(self, var_path: str) -> HDFVariable:
        """
        Return an instance of HDFVariable corresponding to the input variable

        :param var_path: the variable path (for example: <group>/<var_name> or <var_name>)
        :return an instance of HDFVariable
        """
        if var_path in self.vars.keys():
            # If the variable has already been extracted, return it
            return self.vars[var_path]
        else:
            # Create a new HDFVariable instance
            var_name, group_path = pu.get_last_element_in_path(var_path)
            hdf_var = self._generate_hdf_var(var_name, group_path)
            # Save the created instance
            self.vars[var_path] = hdf_var
            return hdf_var
        
    def fetch_vars(self, var_paths: list[str]) -> None:
        """
        For each variable in the input list, load an instance of HDFVariable in the vars dictionnary

        :param var_paths: list of variable paths to load
        """
        for var_path in var_paths:
            self.get_var(var_path)

    @abstractmethod
    def _get_root_object(self):
        """
        Return the object representing the root group of the current file

        :return the root group
        """
        pass

    @abstractmethod
    def _get_groups(self, group) -> list:
        """
        Return a list of objects representing subgroups of the input group

        :param group: the object group to explore
        :return the list of subgroups of the input group
        """
        pass

    @abstractmethod
    def _get_group_from_path(self, group_path):
        """
        Return an object group from its path

        :param group: the path of the group to find
        :return the object group
        """
        pass

    @abstractmethod
    def _get_attributes(self, group) -> dict:
        """
        Return a dictionary containing the attributes of the input group: {attribute_name: attribute_value}

        :param group: the object group to explore
        :return the dictionary of attributes of the input group
        """
        pass

    @abstractmethod
    def _get_variables(self, group) -> dict:
        """
        Return a dictionary containing the variables of the input group: {variable_name: variable_object}

        :param group: the object group to explore
        :return the dictionary of variables of the input group
        """
        pass

    @abstractmethod
    def _get_group_name(self, group) -> str:
        """
        Return the name of the input group

        :param group: the group to process
        """
        pass

    @abstractmethod
    def _get_var_dimensions(self, var) -> dict:
        """
        Return the dimensions of the input variable

        :param var: the variable to process
        """
        pass

    @abstractmethod
    def _get_var_dtype(self, var) -> np.dtype:
        """
        Return the data type of the input variable

        :param var: the variable to process
        """
        pass

    @abstractmethod
    def _get_var_attributes(self, var) -> dict:
        """
        Return the attributes of the input variable

        :param var: the variable to process
        """
        pass

    def __describe_group(self, group, indent: int = 0, is_root: bool = False, group_described = [], full: bool = False):
        """
        Return a description of the input group as a string: attributes, variables (name, dimensions and data type)
        and subgroups.
        Recursive function.

        :param group: the group to explore
        :param indent: (optional) the number of spaces to add before each line of the output string
        :return: the description of the group
        """
        # Initialize the result
        result = ""

        # Get the group name
        group_name = self._get_group_name(group)
        group_described.append(group_name)

        if full :
            # Get the attributes of the group as a dictionary {attr_name: attr_value}
            attr_dict = self._get_attributes(group)
            # Add the description of each attribute (if any) to the result
            if attr_dict:
                # Set the prefix to add at the beginning of the attribute line
                # If current group is root, use "global attributes", else "attributes"
                attributes_prefix = "Global attributes:" if is_root else f"Attributes of group '{group_name}':"
                result = su.add_line(result, " " * indent + "|_" + attributes_prefix)
                for attr_name, attr_val in attr_dict.items():
                    result = su.add_line(result, " " * (indent + 5) + "|_ " + f"{attr_name}")

        # Get the variables of the group as a dictionary {var_name: var_object}
        var_dict = self._get_variables(group)
        # Add the description of each variable (if any) to the result: name, dimensions and data type
        if var_dict:
            variables_prefix = "Global variables:" if is_root else f"Variables in group '{group_name}':"
        
            result = su.add_line(result, " " * indent + "|_" + variables_prefix)
            if full:
                for var_name, var in var_dict.items():
                    var_dim = self._get_var_dimensions(var)
                    var_dtype = self._get_var_dtype(var)
                    result = su.add_line(result,
                                          " " * (indent + 5) + "|_ " + f"{var_name} (dimensions: {var_dim}, dtype: {var_dtype})")
            else:
                t = Texttable()
                t.add_rows([['Variable Name', 'Dimensions', 'Data Type']])
                t.set_cols_width([25, 50, 15])
                for var_name, var in var_dict.items():
                    var_dim = self._get_var_dimensions(var)
                    var_dtype = self._get_var_dtype(var)
                    t.add_rows([[var_name, var_dim, var_dtype]], header=False)
                indented_table = "\n".join([" " * (indent + 5) + line for line in t.draw().split("\n")])
                result = su.add_line(result, indented_table)

        # Iterates over subgroups
        for subgroup in self._get_groups(group):
            # Skip groups already described (as subgroups for example)
            if self._get_group_name(subgroup) not in group_described:
                result = su.add_line(result, " " * indent + "|_" + f"Group '{self._get_group_name(subgroup)}':")
                result = su.add_line(result, self.__describe_group(subgroup, indent + 4, group_described = group_described, full=full))
        return result

    def describe_file(self, show_abs_path: bool = False, call_print: bool = True, full: bool = False):
        """
        Return a description of the file of the current instance: file name by default, global and other attributes, groups and
        variables. By default, print the output description.

        :param show_abs_path: (optional) If True, show the absolute path in the description. Else show the file name.
        :param call_print: (optional) If True, print the description
        :return: the description of the file
        """
        # Set the string corresponding to the file: its name or its absolute file path
        file = self.file_path
        if not show_abs_path:
            file = pu.get_last_element_in_path(file)[0]

        # Initialize the result
        result = f"Data in file '{file}':"

        # Get the object representing the root group
        root = self._get_root_object()

        # Concatenate the description of the root group to the result
        result = su.add_line(result, self.__describe_group(root, is_root=True, full=full, group_described=[]))

        # Print the result if needed
        if call_print:
            print(result)

        return result
    
    def describe_all_vars(self, group_path:str = None, call_print: bool = True, json_path: str | None = None):
        """
        Return a description of the variables of the file. By default, print the output description in a json format.

        :param group_path: (optional) If True, describe the variables found in group path. If False, describe all variables in the file.
        :param call_print: (optional) If True, print the description
        :param: json_path: (optional) if set, a json file is created with the contents of the description
        :return: the description of the variables in the file or group
        """
        result = self.__describe_all_group_vars(group_path, group_described=[])

        if json_path:
            with open(json_path, "w") as f:
                json.dump(result, f, indent=4)

        if call_print:
            print(json.dumps(result, indent=4))

        return result

    def __describe_all_group_vars(self, group_path: str = "", group_described = []) -> dict:
        """
        Return a description of the variables in the input group and subgroups.
        Recursive function.

        :param group_path: the group to explore
        :param group_described: the list of groups that have already been described (only useful for HDF4 files)
        :return: the description of the group
        """
        vars_descr_dict = dict()
        if group_path:
            group = self._get_group_from_path(group_path)
        # if group else self._get_root_object() 

        else:
            group = self._get_root_object()

        group_described.append(group_path)
        group_described.append(str(pu.get_last_element_in_path(group_path)[0]))

        var_dict = self._get_variables(group)
        for var_name in var_dict:
            var_descr = dict()

            var_path = group_path + '/' + var_name if group_path else var_name
            var = var_dict[var_name]
        
            var_descr['name'] = var_name
            var_descr['group_path'] = group_path + '/' if group_path else '/'
            var_descr['dimensions'] = self._get_var_dimensions(var)
            var_descr['dtype'] = str(self._get_var_dtype(var))
            var_descr['attributes'] = str(self._get_var_attributes(var))

            vars_descr_dict[var_path] = var_descr
        
        for subgroup in self._get_groups(group):
            subgroup_path = group_path + '/' + self._get_group_name(subgroup) if group_path else self._get_group_name(subgroup)
            # Skip groups already described (as subgroups for example)
            if subgroup_path not in group_described and self._get_group_name(subgroup) not in group_described:
                vars_descr_dict.update(self.__describe_all_group_vars(subgroup_path, group_described))

        return vars_descr_dict

    def get_global_attributes(self) -> dict:
        """
        Return a dictionary containing the global attributes of the current file: {attr_name: attr_value}

        :return: the global attributes
        """
        return self._get_attributes(self._get_root_object())

    def plot(self, var_path: str, x: str = None, y: str = None, display: str = None, save_path: str = None, **dims_values):
        """
            :param var_path : group/name of the variable
            :param x : dimension name taken for the x-axe
            :param y : dimension name taken for the y-axe
            :param display : None (default), plotly, matplotlib. Display ot not the figure created.
            :param save_path : None (default), "folder/to/save/the/figure"
            :param **dims_values :  dimensions and their value exemple:  dimension1 = 5, dimension2 = 1
        """
        # Lazy import. Avoid circular import issue
        # plot_utils.py uses HDFVariable.
        # This import append only when the user want to plot an HDFVariable. 
        import atmotools.utils.plot_utils as ptu

        # Get data of the variable to plot 
        var = self.get_var(var_path)
        data = var.get_data()

        # Get dimensions  
        dimensions = var.get_dimensions()

        try :# Try to get latitude and longitude
            lat = self.get_var('latitude').get_data()
            lon = self.get_var('longitude').get_data()
            ptu.plot_map(var, lat = lat, lon = lon, display = display, save_path = save_path, dims_values = dims_values)

        except Exception as e:
            print("WARNING : File doesn't have latitude or longitude in global variables") 
            if len(dimensions) < 2 : # Plot if there no dimension or only 1 dimension in the variable 
                ptu.plot1D(var, display = display, save_path = save_path)
        
            elif len(dimensions) >= 2: # Plot if there is more than 1 dimension 
                ptu.plot2D(var, x = x, y = y, display = display, save_path = save_path, dims_values = dims_values)          

class XarrayReader(AbstractHDFReader):
    """
    This class enables to open a HDF5 or NetCDF file and read its data with the library Xarray.

    Attributes:
        file_path(str): the file path of the HDF file to read
    """

    def __init__(self, file_path: str) -> None:
        self.__root_datatree = None
        super().__init__(file_path)

    def __del__(self):
        """
        Delete the reader
        """
        if self.__root_datatree:
            self.__root_datatree.close()

    def _init_reader(self):
        super()._init_reader()
        try:
            self.__root_datatree = xr.open_datatree(self.file_path)
        except Exception as err:
            raise RuntimeError(f"ERROR while loading HDF/NetCDF file: {err}")

    def _generate_hdf_var(self, var_name: str, group_path: str) -> HDFVariable:
        # Initialize the group to process
        group_found = self.__root_datatree

        # Retrieve the group of the variable if defined
        if group_path:
            try:
                # Retrieve the xarray.DataArray representing the given variable
                group_found = self.__root_datatree[group_path]
            except Exception as err:
                raise RuntimeError(f"ERROR while loading variable from HDF/NetCDF file: {err}")

        # Retrieve the xarray.DataArray representing the given variable
        if var_name in group_found.variables:
            var = group_found[var_name]
        else:
            raise RuntimeError(f"ERROR cannot find variable '{var_name}' under group '{group_path}'")

        # Retrieve the dictionary of dimensions {'name': 'size'}
        dimensions_dict = dict(var.sizes)

        # Retrieve attributes 
        if 'scale_factor' in var.encoding.keys() : var.attrs['scale_factor'] = var.encoding['scale_factor']
        if 'add_offset' in var.encoding.keys() :var.attrs['add_offset'] = var.encoding['add_offset']
        if '_FillValue' in var.encoding.keys() :var.attrs['_FillValue'] = var.encoding['_FillValue']
        if 'missing_value' in var.encoding.keys() :var.attrs['missing_value'] = var.encoding['missing_value']    

        # Generate an HDFVariable. Use 'data' property for np.ndarray type
        return HDFVariable(var.name, var.data, dimensions_dict, var.dtype, var.attrs, self.file_path, group_path)

    def _get_root_object(self) -> xr.DataTree:
        return self.__root_datatree

    def _get_groups(self, group: xr.DataTree) -> list[xr.DataTree]:
        return list(group.children.values())
    
    def _get_group_from_path(self, group_path: str) -> xr.DataTree:
        if group_path:
            try:
                # Retrieve the xarray.DataTree representing the given group
                group = self._get_root_object()[group_path]
            except Exception as err:
                raise RuntimeError(f"ERROR cannot find group '{group_path}'")
        else:
            group = self._get_root_object()

        return group

    def _get_attributes(self, group: xr.DataTree) -> dict:
        return group.attrs

    def _get_variables(self, group: xr.DataTree) -> dict:
        return dict(group.variables)

    def _get_group_name(self, group: xr.DataTree) -> str:
        return group.name

    def _get_var_dimensions(self, var: xr.Variable) -> dict:
        return dict(var.sizes)

    def _get_var_dtype(self, var: xr.Variable) -> np.dtype:
        return var.dtype

    def _get_var_attributes(self, var: xr.Variable) -> dict:
        return var.attrs


class Netcdf4Reader(AbstractHDFReader):
    """
    This class enables to open a HDF5 or NetCDF file and read its data with the library NetCDF4

    Attributes:
        file_path(str): the file path of the HDF file to read
    """

    def __init__(self, file_path: str) -> None:
        self.__root_dataset = None
        super().__init__(file_path)

    def __del__(self):
        """
        Delete the reader
        """
        if self.__root_dataset:
            self.__root_dataset.close()

    def _init_reader(self):
        super()._init_reader()
        try:
            # Cannot use with/as block to set nc_dataset: nc_dataset disappears as the file closes
            # The dataset is closed in the destructor
            self.__root_dataset = nc.Dataset(self.file_path, 'r')
        except Exception as err:
            raise RuntimeError(f"ERROR while loading HDF/NetCDF file: {err}")

    def _generate_hdf_var(self, var_name: str, group_path: str) -> HDFVariable:
        group_found = self.__root_dataset

        # Retrieve the group of the variable if defined
        if group_path:
            try:
                group_found = group_found[group_path]
            except Exception as e:
                raise RuntimeError(f"ERROR cannot find group '{group_path}'")

        # Retrieve the netCDF4.Variable representing the given variable
        if var_name in group_found.variables:
            var = group_found[var_name]
        else:
            raise RuntimeError(f"ERROR cannot find variable '{var_name}' under group '{group_path}'")

        # Retrieve the dictionary of dimensions {'name': 'size'}
        dimensions_dict = {var.dimensions[i]: var.shape[i] for i in range(len(var.dimensions))}

        # Create the dictionary of attributes
        # Iterates over the name of attributes and retrieve their value
        attributes = {attr_name: var.getncattr(attr_name) for attr_name in var.ncattrs()}

        # Get the data
        if type(var[:]) == np.ma.MaskedArray:
            # data = var[:].data

            # marray = var[:] 
            # data = marray.filled(np.nan) # Return a copy of self, with masked values filled with NaN value. However, if there are no masked values to fill, self will be returned instead as an ndarray 

            data = var[:].data 

        else:
            data = np.array(var[:])

        # Generate an HDFVariable
        return HDFVariable(var.name, data, dimensions_dict, var.dtype, attributes, self.file_path, group_path)

    def _get_root_object(self) -> nc.Dataset:
        """
        Get root dataset of file.
        :return: root dataset of file
        """
        return self.__root_dataset

    def _get_groups(self, group: nc.Dataset | nc.Group) -> list[nc.Group]:
        return list(group.groups.values())
    
    def _get_group_from_path(self, group_path: str) -> nc.Group | nc.Dataset:
        if group_path:
            try:
                group = self._get_root_object()[group_path]
            except Exception as e:
                raise RuntimeError(f"ERROR cannot find group '{group_path}'")
        else:
            group = self._get_root_object()

        return group

    def _get_attributes(self, group: nc.Dataset | nc.Group) -> dict:
        attributes = {attr_name: group.getncattr(attr_name) for attr_name in group.ncattrs()}
        return attributes

    def _get_variables(self, group: nc.Dataset | nc.Group) -> dict:
        return group.variables

    def _get_group_name(self, group: nc.Dataset | nc.Group) -> str:
        return group.name

    def _get_var_dimensions(self, var: nc.Variable) -> dict:
        dimensions_dict = {var.dimensions[i]: var.shape[i] for i in range(len(var.dimensions))}
        return dimensions_dict

    def _get_var_dtype(self, var: nc.Variable) -> np.dtype:
        return var.dtype

    def _get_var_attributes(self, var: nc.Variable) -> dict:
        attributes = {attr_name: var.getncattr(attr_name) for attr_name in var.ncattrs()}
        return attributes

class HDF4Reader(AbstractHDFReader):
    """
    This class enables to open a HDF4 file and read its data with the library HDF4

    Attributes:
        file_path(str): the file path of the HDF file to read
    """

    def __init__(self, file_path: str) -> None:
        self.__root_dataset = None
        self.__root_group = None
        self.__root_vdata = None
        self.allGroups = []
        super().__init__(file_path)

    def __del__(self):
        """
        Delete the reader
        """
        if self.__root_dataset:
            self.__root_dataset.end()
        if self.__root_group:
            self.__root_group.end()
        if self.__root_vdata:
            self.__root_vdata.end()
    
    def _init_reader(self):
        super()._init_reader()
        try:
            self.__root_dataset = SD(self.file_path, SDC.READ)
        except Exception as err:
            raise RuntimeError(f"ERROR while loading HDF file: {err}")
        try:
            hdf = HDF(self.file_path, HC.READ)
            self.__root_group = hdf.vgstart()
            self.__root_vdata = hdf.vstart()
        except Exception as err:
            raise RuntimeError(f"ERROR while loading HDF file: {err}")
        self.allGroups = self._get_all_groups(self.__root_group)

    def _generate_hdf_var(self, var_name: str, group_path: str) -> HDFVariable:
        group_found = self.__root_group

        # Retrieve the group of the variable if defined
        if group_path:
            group_name, _ = pu.get_last_element_in_path(group_path)
            try:
                group_found = group_found.attach(self.__root_group.find(group_name))
            except Exception as e:
                raise RuntimeError(f"ERROR cannot find group '{group_name}'")

        # Retrieve the HDF4 Dataset representing the given variable
        variables = self._get_variables(group_found)
        if var_name in variables:
            var = variables[var_name]
        else:
            raise RuntimeError(f"ERROR cannot find variable '{var_name}' under group '{group_path}'")

        # Retrieve the dictionary of dimensions {'name': 'size'}
        dimensions_dict = var.dimensions(full = False)

        # Create the dictionary of attributes
        attributes = var.attributes(full = False)

        # Get the data
        data = var.get()

        var_dtype = self._get_var_dtype(var)

        # Generate an HDFVariable
        return HDFVariable(var_name, data, dimensions_dict, var_dtype, attributes, self.file_path, group_path) 

    def _get_root_object(self) -> VG:
        try:
            # Get the last of the references in the file, i.e. the root group
            return self.allGroups[-1]
        except:
            raise RuntimeError("Root object cannot be found") 
    
    def _get_all_groups(self, group: V) -> list[VG]:
        """
        Retrieve list of all subgroups in the HDF4 file.

        :return: list of groups
        """
        groups = []
        # Prevent the "groups" of single datasets from being read outside of their group
        ref_read = list(self.__root_dataset.datasets().keys()).copy()
        gref = -1
        last_ref = False

        while not last_ref:
            try:
                # Get the next available group reference
                gref = self.__root_group.getid(gref)
                vg = self.__root_group.attach(gref)
                # Get next group that has not been read already (as subgroup for example)
                while str(vg._name) in ref_read:
                    gref = self.__root_group.getid(gref)
                    vg = self.__root_group.attach(gref)
            except:
                print("Last reference reached")
                last_ref = True
                break

            isEmpty = True
            for tag, ref in vg.tagrefs():
                # Vdata in the group
                if tag == HC.DFTAG_VH:
                    vd = self.__root_vdata.attach(ref)
                    nrecs, intmode, fields, size, name = vd.inquire()
                    # Skip vdata that is a variable or a dimension also stored as vdata
                    if name in ref_read or vd._class == 'DimVal0.1':
                        continue
                    vd.detach()
                    # The group is not empty, it is added to the list of groups
                    isEmpty = False
                    break
                # Dataset in the group
                if tag == HC.DFTAG_NDG:
                    sds = self.__root_dataset.select(self.__root_dataset.reftoindex(ref))
                    name, rank, dims, type, nattrs = sds.info()
                    # The variable is added to the list of read members (a duplicate group will be skipped)
                    ref_read.append(name)
                    sds.endaccess()
                    # The group is not empty, it is added to the list of groups
                    isEmpty = False
                    break
                # Subgroup in group
                if tag == HC.DFTAG_VG:
                    vg0 = self.__root_group.attach(ref)
                    if vg0._name in ref_read:
                        continue
                    vg0.detach()
                    # The group is not empty, it is added to the list of groups
                    isEmpty = False
                    break
            # Is this the last ref? (i.e. is this the root group)
            try:
                next_ref = self.__root_group.getid(gref)
            except:
                last_ref = True

            # If the group is the root group or is not empty, it is added to the list of groups
            if last_ref or not isEmpty:
                groups.append(vg)
        
        return groups

    def _get_groups(self, group: VG) -> list[VG]:
        all_groups = self.allGroups

        if group._name == self._get_root_object()._name:
            return all_groups
        
        groups = []
        for tag, ref in group.tagrefs():
            if tag == HC.DFTAG_VG:
                vg0 = self.__root_group.attach(ref)
                # Skip empty groups
                if str(vg0._name) not in [gp._name for gp in all_groups]:
                    continue
                groups.append(vg0)
                # vg0.detach()

        return groups
    
    def _get_group_from_path(self, group_path: str) -> VG:
        if not group_path or group_path==self._get_group_name(self.allGroups[-1]):
            group = self._get_root_object()
        elif group_path:
            group_name = pu.get_last_element_in_path(group_path)[0]
            for group in self.allGroups:
                if self._get_group_name(group) == group_name:
                    return group
            raise RuntimeError(f"ERROR cannot find group '{group_path}'") 

        return group
    
    def _get_attributes(self, group : VG) -> dict:
        # Get attributes stored as attributes
        attributes = {attr_name: group.attr(attr_name).get() for attr_name in group.attrinfo()}
        
        # Get attributes stored as vdata
        for tag, ref in group.tagrefs():
            if tag == HC.DFTAG_VH:
                vd = self.__root_vdata.attach(ref)
                if vd._isattr:
                    nrecs, intmode, fields, size, name = vd.inquire()
                    attributes[name] = vd.read()[0][0]
                vd.detach()

        return attributes
            
    # def _get_variables(self, group: SD) -> dict:
    #     # vars_dict = dict()
    #     # for var in group.datasets():
    #     #     vars_dict[var] = group.select(var)
    #     # return vars_dict
    #     return self._get_variables(group = self._get_root_group)
    
    def _get_variables(self, group: VG) -> dict:
        if len(self.allGroups) <= 1:
            return {sds_name : self.__root_dataset.select(sds_name) for sds_name in self.__root_dataset.datasets()}

        vars_dict = dict()
        for tag, ref in group.tagrefs():
            # If variable is stored as dataset
            if tag == HC.DFTAG_NDG:
                sds = self.__root_dataset.select(self.__root_dataset.reftoindex(ref))
                name, rank, dims, type, nattrs = sds.info()
                vars_dict[name] = sds
                # sds.endaccess()
            # If variable is stored as "vdata" :
            # if tag == HC.DFTAG_VH:
            #     vd = self.__root_vdata.attach(ref)
            #     if vd._class == "":
            #         nrecs, intmode, fields, size, name = vd.inquire()
            #         vars_dict[name] = vd.read(nfields)[0][0]
            #     vd.detach()
        return vars_dict

    def _get_group_name(self, group: VG) -> str:
        return group._name

    def _get_var_dimensions(self, var: SDS) -> dict:
        return var.dimensions(full=False)

    def _get_var_dtype(self, var: SDS) -> np.dtype:
        typeTab = {
           SDC.CHAR:    np.dtype('U').type,
           SDC.CHAR8:   np.dtype('U').type,
           SDC.UCHAR8:  np.dtype('U').type,
           SDC.INT8:    np.int8,
           SDC.UINT8:   np.uint8,
           SDC.INT16:   np.int16,
           SDC.UINT16:  np.uint16,
           SDC.INT32:   np.int32,
           SDC.UINT32:  np.uint32,
           SDC.FLOAT32: np.float32,
           SDC.FLOAT64: np.float64
           }
        # SDS.info() returns a tuple containing the datasets's name, rank, shape, type and nb of attributes
        return typeTab[var.info()[-2]]

    def _get_var_attributes(self, var: SDS) -> dict:
        return var.attributes(full=False)

def createReader(path, useXarray=True):
    """
    Create reader for file of any format among NetCDF, HDF5 and HDF4.

    :param: path: path of the file
    :param: useXarray: (optional) If True, the library used for NetCDF or HDF5 file will be xarray instead of netcdf.
    :return: reader
    """
    extension = pu.get_extension_in_path(path)
    if not extension:
        new_path = input(f"ERROR: no extension in file path {path}. Please enter file path again with extension: ")
        return createReader(new_path)
    if extension in ["nc", "hdf5", "h5"]:
        reader = XarrayReader(path) if useXarray else Netcdf4Reader(path)
    elif extension in ["hdf", "h4", "hdf4"]:
        reader = HDF4Reader(path)
    else:
        new_path = input(f"ERROR: Extension in file path {path} is not valid here. Please enter file path with NetCDF, HDF5 or HDF4 extension: ")
        return createReader(new_path)
    return reader


# class AbstractHDFWriter(ABC):
#     """
#     Abstract class to create or open a HDF5, NetCDF or HDF4 file and write data on it.

#     Attributes:
#         file_path(str): the absolute file path of the file to create or update
#         mode(str): mode of the file. 'w' means write; a new file is created, an existing file with the same name is deleted. 'a' means append; an existing file is opened for reading and writing, if file does not exist already, one is created.
#         format(str): format of the file. Use 'NETCDF4' for a NetCDF4 file, or 'HDF5' for an HDF5 file
#         bypass_warning(bool): if set to False (default) and if there is an existing file with the same name, a warning is raised. If True, no warning is raised. 
#     """

#     def __init__(self, file_path: str, mode: str, bypass_warning: bool = False) -> None:
#         """
#         Initialize the class attributes and create/open the output file.
        
#         Parameters:
#             file_path: the file path of the HDF file to write
#             mode(str): mode of the file. 'w' means write; a new file is created, an existing file with the same name is deleted. 'a' means append; an existing file is opened for reading and writing, if file does not exist already, one is created.
#             bypass_warning(bool): if set to False (default) and if there is an existing file with the same name, a warning is raised. If True, no warning is raised. 
#         """
#         self.file_path =  os.path.abspath(file_path)
        
#         if mode in ["a", "w", "r+"]:
#             self.mode = mode
#         else:
#             raise ValueError("Invalid value for mode. Please select 'a' (append) or 'w' (overwrite)")
        
#         self._init_writer(bypass_warning)
    
#     def get_file_path(self) -> str:
#         """
#         Return the path of written HDF file
        
#         :return: file path
#         """
#         return self.file_path
   
#     @abstractmethod
#     def _init_writer(self, bypass_warning: bool) -> str:
#         """
#         Check the existence of the file and initialize the writer and its specific attributes
        
#         :param bypass_warning: if set to False (default) and if there is an existing file with the same name, a warning is raised. If True, no warning is raised. 
#         """

#         # Check if the file exists before opening it or creating it with a writer
#         if fu.check_file_exists(self.file_path) and not bypass_warning:
#             user_input = input("File already exists. Do you wish to continue? (yes[y]/no[n]): ")
#             invalid = True
#             while invalid :
#                 if user_input.lower() in ["yes", "y"]:
#                     invalid = False
#                     return
#                 elif user_input.lower() in ["no", "n"]:
#                     invalid = False
#                     raise RuntimeError('Please select a new file path')
#                 else:
#                     user_input = input("Invalid input. Please enter yes[y]/no[n]: ")
    
#     def _get_root_object(self):
#         """
#         Return the object representing the root group of the current file

#         :return: the root group
#         """
#         pass

#     @abstractmethod
#     def _add_variable(self, var_path: str, dtype: str, dimensions: tuple[str], attrs: dict = {}, custom_FillValue = DEFAULT_FILL_VALUE, value: ArrayLike | None = None):
#         """
#         Create a variable at the input path with the input attributes.
        
#         Parameters:
#             var_path: path of the variable to create (group/subgroup/.../var_name)
#             dtype: data type for the variable values
#             dimensions: tuple of the variable dimensions ( ("dim1", "dim2", ...) )
#             attrs: dictionnary {attr_name: attr_value}, where attr_value is the value to set to the attribute attr_name.
#             custom_FillValue: custom value used to represent missing or undefined data for the variable. If not set, a default fillValue is used. It cannot be changed once the variable is created.
#             valu: value to assign to the data
#         """
#         pass

#     @abstractmethod
#     def _rename_variable(self, var_path: str, var_new_name: str):
#         """
#         Rename the variable corresponding to the input path

#         Parameters:
#             var_path: path of the variable to rename (group/subgroup/.../var_name)
#             var_new_name: new name to give to the variable (without its path)
#         """
#         pass

#     @abstractmethod
#     def _change_variable_value(self, var_path: str, new_value: ArrayLike):
#         """
#         Replace the values in a variable (or add it if the variable is empty)

#         Parameters:
#             var_path: path of the variable to modify the value of (group/subgroup/.../var_name)
#             new_value: new data to assign to the variable
#         """

#     @abstractmethod
#     def _add_group(self, group_path: str):
#         """
#         Create a group at the input path. If a directory in the path does not exist, it will be created.

#         Parameters:
#             group_path: path of the variable to create (group/subgroup/.../group_name)
#         """
#         pass

#     @abstractmethod
#     def _rename_group(self, group_path: str, group_new_name: str):
#         """
#         Rename the group corresponding to the input path

#         Parameters:
#             group_path: path of the group to rename (group/subgroup/.../group_name)
#             group_new_name: new name to give to the group (without its path)
#         """
#         pass
        
#     @abstractmethod
#     def _create_dimension(self, dim_name: str, dim_size: int | None, group_path: str | None = None):
#         """
#         Create a new dimension

#         Parameters:
#             dim_name: name to give the new dimension
#             dim_size: size to give the new dimension. If not set, the dimension is unlimited (i.e. it can be appended to)
#             group_path: path to create dimension. It is unset by default, meaning that the dimension exists for the entire dataset.
#         """
#         pass
        
#     @abstractmethod
#     def _rename_dimension(self, dim_name: str, new_dim_name: str, group_path: str | None = None):
#         """
#         Rename the dimension corresponding to the input name

#         Parameters:
#             dim_name: old name of the dimension
#             dim_size: new name to give the dimension.
#             group_path: path of dimension. It is unset by default, meaning that we only consider global dimensions.
#         """
#         pass

#     @abstractmethod
#     def _set_attribute(self, attribute_name: str, attribute_value, object_path: str | None = None):
#         """
#         Create or change the value of an attribute of a group, variable, or a global attribute.

#         Parameters:
#             attribute_name: name of the attribute to set
#             attribute_value: value to give the attribute
#             object_path: path of object to which the attribute belongs. It is unset by default, meaning that a global attribute will be set.
#         """
#         pass    
    
#     @abstractmethod
#     def _add_global_attributes(self, attrs: dict):
#         """
#         Create global attributes.

#         Parameters:
#             attrs: dictionnary {attr_name: attr_value}, where attr_value is the value to set to the attribute attr_name.
#         """
#         pass


class Hdf5Netcdf4Writer(Netcdf4Reader):
    """
    This class enables to create or open a HDF5 or NetCDF file and write data on it using the Netcdf4 library.

    Attributes:
        file_path(str): the absolute file path of the file to create or update
        mode(str): mode of the file. 'w' means write; a new file is created, an existing file with the same name is deleted. 'a' means append; an existing file is opened for reading and writing, if file does not exist already, one is created.
        extension(str): extension of the file. Use '.nc' for a NetCDF4 file, '.h5' for an HDF5 file, and '.hdf4' for an HDF4 file.
        bypass_warning(bool): if set to False (default) and if there is an existing file with the same name, a warning is raised. If True, no warning is raised. 
    """

    def __init__(self, file_path: str, mode: str, extension: str, bypass_warning: bool = False) -> None:
        """
        Initialize the class attributes and read the input file.
        :param file_path: the file path of the HDF file on which to write
        :param mode: mode of the file. 'w' means write; a new file is created, an existing file with the same name is deleted. 'a' means append; an existing file is opened for reading and writing, if file does not exist already, one is created.
        :param: extension: extension of the file. Use '.nc' for a NetCDF4 file, '.h5' for an HDF5 file, and '.hdf4' for an HDF4 file.
        :param: bypass_warning: if set to False (default) and if there is an existing file with the same name, a warning is raised. If True, no warning is raised.
        """
        self.__root_dataset = None
        # Check desired extension is valid for this writer
        if extension.lower() in [".nc", ".h5"]:
            self.extension = extension
        else:
            raise ValueError("Invalid extension. Please select '.nc' or '.h5'.")
        self.file_path =  os.path.abspath(file_path)

        if mode in ["a", "w", "r+"]:
            self.mode = mode
        else:
            raise ValueError("Invalid value for mode. Please select 'a' (append) or 'w' (overwrite)")

        self._init_writer(bypass_warning)
        super().__init__(self.file_path)


    def __del__(self):
        if self.__root_dataset:
            self.__root_dataset.close()

    def _init_writer(self, bypass_warning):
        """
        Check the existence of the file and initialize the writer and its specific attributes
        """
        # Check if the file exists before opening it or creating it with a writer
        # Remove any hdf extension that might have been written in the file path and add the desired one
        for extension in [".nc", ".hdf5", ".h5", ".hdf", ".h4", ".hdf4"]:
            self.file_path = self.file_path.removesuffix(extension)
        file_exists, existing_extensions = fu.check_file_exists_with_extension(self.file_path, extensions=[".nc", ".hdf5", ".h5", ".hdf", ".h4", ".hdf4"])
        if file_exists:
            # if file exists with same extension, raise warning
            if self.extension in existing_extensions:
                mode_full = "append to" if self.mode == "a" else "overwrite"
                print(Warning(f"WARNING: File already exists: {self.file_path + self.extension}. Continuing will {mode_full} the file"))
            # for an HDF5 file, check if file exists with '.hdf5' extension
            elif self.extension == ".h5" and ".hdf5" in existing_extensions:
                self.extension = ".hdf5"
                mode_full = "append to" if self.mode == "a" else "overwrite"
                print(Warning(f"WARNING: File already exists: {self.file_path + self.extension}. Continuing will {mode_full} the file"))
            # if file exists but only with another hdf extension
            else:
                print(Warning(f"WARNING: File already exists with extension {existing_extensions}. Creating a new file with the extension '{self.extension}'"))

        self.file_path = self.file_path + self.extension
        if fu.check_file_exists(self.file_path) and not bypass_warning:
            user_input = input("File already exists. Do you wish to continue? (yes[y]/no[n]): ")
            invalid = True
            while invalid :
                if user_input.lower() in ["yes", "y"]:
                    invalid = False
                    self.__root_dataset = nc.Dataset(self.file_path, self.mode)
                    return
                elif user_input.lower() in ["no", "n"]:
                    invalid = False
                    raise RuntimeError('Please select a new file path')
                else:
                    user_input = input("Invalid input. Please enter yes[y]/no[n]: ")
        self.__root_dataset = nc.Dataset(self.file_path, self.mode)

    def _get_root_object(self) -> nc.Dataset:
        return self.__root_dataset

    def _add_variable(self, var_path: str, dtype: str, dimensions: tuple[str], attrs: dict = {}, custom_FillValue = DEFAULT_FILL_VALUE, value: ArrayLike | None = None):
        """
        Create variable.

        Parameters:
            var_path: path of the variable to create (group/subgroup/.../var_name)
            dtype: data type for the variable values. Here are some examples of frequently used types:
                - float: 'f4' (32-bit floating point), 'f8' (64-bit floating point)
                - int: 'i4' (32-bit signed integer), 'i2' (16-bit signed integer), 'i8' (64-bit signed integer)
                - str: 'S1' (single-character string), 'str'
            dimensions: tuple of the variable dimensions ( ("dim1", "dim2", ...) )
            attrs: dictionnary {attr_name: attr_value}, where attr_value is the value to set to the attribute attr_name. For the attr_name keys, select among the following:
                - 'units': string that represents the units of measurement.
                - 'long_name': descriptive name that indicates a variable's content.
                - 'standard_name': standard name that references a description of a variable's content in the standard name table of CF conventions. 
                - 'valid_min': smallest valid value of a variable.
                - 'valid_max': largest valid value of a variable.
                - 'valid_range': smallest and largest valid values of a variable.
                - 'scale_factor': if present for a variable, the data are to be multiplied by this factor after the data are read by an application.
                - 'add_offset': if present for a variable, this number is to be added to the data after it is read by an application. If both scale_factor and add_offset attributes are present, the data are first scaled before the offset is added.
                - 'coordinates': identifies a variable's coordinates. "time latitude longitude"
                - 'maturity_level': indication of the data product maturity based on ESDIS definition. 'Beta' 'Provisional' 'Validated-Stage 1' 'Validated-Stage 4'
                - 'bounds': added to each applicable coordinate dimension. "time_bounds, latitude_bounds, longitude_bounds"
            custom_FillValue: custom value used to represent missing or undefined data for the variable. If not set, a default fillValue is used. It cannot be changed once the variable is created.
            value: value to assign to the data
        """
        # Check that all the dimensions of the variable exist in at least one of the parent groups of the variable
        # Get a list of all the group parents of the variable
        all_dirs = [self._get_root_object()]
        _, group_dir = pu.get_last_element_in_path(var_path)
        while group_dir:
            all_dirs.append(self._get_root_object()[group_dir])
            _, group_dir = pu.get_last_element_in_path(group_dir)
        # Check for all dimensions
        for dim_name in dimensions:
            exists = False
            for dir in all_dirs:
                if dim_name in dir.dimensions:
                    exists = True
                    break
            if not exists:    
                raise ValueError(f"Dimension {dim_name} does not exist in {var_path}. Please create corresponding dimension before its associated variables.")

        # Check that the path for the variable is valid (for example, not "/group/variable1/variable2")
        try: 
            var = self._get_root_object().createVariable(var_path, dtype, dimensions, fill_value=custom_FillValue)
        except:
            raise ValueError(f"Variable already exists or path {var_path} is not valid to create a variable.")
        
        # Set the variable attributes
        for attr_name in attrs:
            setattr(var, attr_name, attrs[attr_name])

        # Assign values (if given) to the variable
        if value is not None:
            value = np.array(value)
            # Check that the new data type is the same as the variable
            try:
                value.astype(var.dtype)
            except:
                raise TypeError(f"Cannot convert type {value.dtype} to type {var.dtype}. Please enter data compatible with variable type {var.dtype}.")
            # Check that the new data dimensions are the same as the variable
            if var.shape != value.shape:
                for i in range(len(var.shape)):
                    if var.shape[i] != value.shape[i] and not var.get_dims()[i].isunlimited():
                        raise ValueError(f"Mismatch between data shape {value.shape} and variable shape {var.shape}. Please enter data of shape {var.shape}.")
                    elif value.shape[i] > var.shape[i] and var.get_dims()[i].isunlimited():
                        print(f"WARNING: Size for unlimited dimension '{var.get_dims()[i].name}' in variable will be set to {value.shape[i]}. If a later new value is set with a size n < {value.shape[i]}, only the first n values will be updated, the others will remain the same.")
                    elif value.shape[i] < var.shape[i] and var.get_dims()[i].isunlimited():
                        print(f"WARNING: Size for unlimited dimension '{var.get_dims()[i].name}' in new dataset is inferior to current value in variable. Only the first {value.shape[i]} values will be updated.")
            # Assign the new value to the variable
            var[:] = value

    def _change_variable_value(self, var_path: str, new_value: ArrayLike):
        """
        Change the value of a variable.

        :param: var_path: path of the variable to change
        :param: new_value: value to give the variable. Has to be of the same size as the previous value if dimensions are limited.
        """
        group = self.__root_dataset
        var_name, group_dir = pu.get_last_element_in_path(var_path)
        if group_dir:
            # Check that the directory of the variable exists and that it is a group
            try:
                group = self.__root_dataset[group_dir]
            except:
                raise ValueError(f"Group {group_dir} does not exist.")
            if not isinstance(group, nc.Group):
                raise ValueError(f"{group_dir} is not a group.")
        # Check that the variable exists
        if var_name in group.variables:
            var = group.variables[var_name]
        else:
            raise ValueError(f"Variable {var_name} does not exist in group {group_dir}.")
        
        new_value = np.array(new_value)
        # Check that the new data type is the same as the variable
        try:
            new_value.astype(var.dtype)
        except:
            raise TypeError(f"Cannot convert type {new_value.dtype} to type {var.dtype}. Please enter data compatible with variable type {var.dtype}.")
        # Check that the new data dimensions are the same as the variable
        if var.shape != new_value.shape:
            for i in range(len(var.shape)):
                if var.shape[i] != new_value.shape[i] and not var.get_dims()[i].isunlimited():
                    raise ValueError(f"Mismatch between data shape {new_value.shape} and variable shape {var.shape}. Please enter data of shape {var.shape}.")
                elif new_value.shape[i] > var.shape[i] and var.get_dims()[i].isunlimited():
                    print(f"WARNING: size for dimension '{var.get_dims()[i].name}' in variable will be set to {new_value.shape[i]}. If a later new value is set with a size n < {new_value.shape[i]}, only the first n values will be updated, the others will remain the same.")
                elif new_value.shape[i] < var.shape[i] and var.get_dims()[i].isunlimited():
                    print(f"WARNING: Size for dimension '{var.get_dims()[i].name}' in new dataset is inferior to current value in variable. Only the first {new_value.shape[i]} values will be updated.")

        value_range = [var.valid_min * var.scale_factor + var.add_offset if ("valid_min" in var.ncattrs() and "scale_factor" in var.ncattrs() and "add_offset" in var.ncattrs()) else var.valid_min if "valid_min" in var.ncattrs() else None,
                           var.valid_max * var.scale_factor + var.add_offset if ("valid_max" in var.ncattrs() and "scale_factor" in var.ncattrs() and "add_offset" in var.ncattrs()) else var.valid_min if "valid_max" in var.ncattrs() else None]
        # Assign the new value toS the variable
        try:
            with warnings.catch_warnings():
                warnings.simplefilter("error", RuntimeWarning)
                var[:] = new_value
        except RuntimeWarning:
            raise RuntimeWarning(f"Invalid value: make sure that the new entered value for {var_name} is within range {value_range}.")

    def _rename_variable(self, var_path: str, var_new_name: str):
        """
        Rename variable.

        :param: var_path: old path of the variable to rename
        :param: var_new_name: new name to give the variable (without its path)
        """
        group = self.__root_dataset
        var_name, group_dir = pu.get_last_element_in_path(var_path)
        if group_dir:
            # Check that the directory of the variable exists and that it is a group
            try:
                group = self.__root_dataset[group_dir]
            except:
                raise ValueError(f"Group {group_dir} does not exist.")
            if not isinstance(group, nc.Group):
                raise ValueError(f"{group_dir} is not a group.")
        # Check that the variable exists
        if var_name not in group.variables:
            raise ValueError(f"Variable {var_name} does not exist in group {group_dir}.")
        group.renameVariable(var_name, var_new_name)

    def _add_group(self, group_path: str):
        """
        Create group.

        :param: group_path: path of the group to create
        """
        # Check that the path for the group is valid (for example, not "/group1/variable1/group")
        try: 
            self.__root_dataset.createGroup(group_path)
        except:
            raise ValueError(f"Path {group_path} is not valid to create a group.")

    def _rename_group(self, group_path: str, group_new_name: str):
        """
        Rename group.

        :param: group_path: old path of the group to rename
        :param: group_new_name: new name to give the group (without its path)
        """
        group = self.__root_dataset
        group_name, group_dir = pu.get_last_element_in_path(group_path)
        if group_dir:
            # Check that the directory of the group exists and that it is a group
            try:
                group = self.__root_dataset[group_dir]
            except:
                raise ValueError(f"Group {group_dir} does not exist.")
            if not isinstance(group, nc.Group):
                raise ValueError(f"{group_dir} is not a group.")
        # Check that the group exists        
        if group_name not in group.groups:
            raise ValueError(f"Group {group_name} does not exist in group {group_dir}.")
        group.renameGroup(group_name, group_new_name)

    def _create_dimension(self, dim_name: str, dim_size: int | None, group_path: str | None = None):
        """
        Create dimension

        :param: dim_name: name to give the dimension
        :param: dim_size: size of the dimension. If None, the dimension is unlimited
        :param: group_path: (optional) path of the group to which the dimension is linked. If None, the dimension is global
        """
        # group = self.__root_dataset
        group = self._get_root_object()
        if group_path:
            # Check that the desired directory for the dimension exists and that it is a group
            try :
                group = group[group_path]
            except:
                raise ValueError(f"Group {group_path} cannot be found.")
            if not isinstance(group, nc.Group):
                raise ValueError(f"{group_path} is not a group.")
        # check if the dimension already exists
        if dim_name not in group.dimensions:
            group.createDimension(dim_name, dim_size)
        else:
            print(f"ERROR: dimension {dim_name} already exists at path {group_path if group_path else 'root'}")
        
    def _rename_dimension(self, dim_name: str, new_dim_name: str, group_path: str | None = None):
        """
        Rename dimension.

        :param: dim_name: old name of the dimebnion to rename
        :param: new_dim_name: new name to give the dimension
        :param: group_path: (optional) set to the dimension group path if the dimension is not global
        """
        group = self.__root_dataset
        if group_path:
            # Check that the directory of the dimension exists and that it is a group
            try :
                group = self.__root_dataset[group_path]
            except:
                raise ValueError(f"Group {group_path} cannot be found.")
            if not isinstance(group, nc.Group):
                raise ValueError(f"{group_path} is not a group.")
        # Check that the dimension exists        
        if dim_name not in group.dimensions:
            raise ValueError(f"Dimension {dim_name} does not exist in group {group_path}.")
        group.renameDimension(dim_name, new_dim_name)
        
    def _add_global_attributes(self, attrs: dict):
        """
        Create global attributes.

        Parameters:
            attrs: dictionnary {attr_name: attr_value}, where attr_value is the value to set to the attribute attr_name. For the attr_name keys, select among the following:
                - 'title'
                - 'institution' : Institution which produced the data.	NASA, JAXA, AERIS
                - 'platform_name' : ID platform name.	PMM, Storm
                - 'instrument_name' : ID instrument name.	COMODO
                - 'history' : List of the applications that have modified the original data. i.e : It could be an array of strings, with one line (containing date, time, user name, program name and command arguments) for each call of a program that has modified the data set.
                - 'references' : References that describe the data or the methods used to produce it.	
                - 'tracking_id' : An UUID (Universal Unique Identifier) or DOI (Digital Object Identifier) value.	
                - 'naming_authority' : The organization that provides the 'tracking_id' identifier for the dataset.
                - 'conventions' : A text string identifying the NetCDF convention followed. This attribute should be set to "CF-1.6" to indicate compatibility with the Climate and Forecast.	CF-1.6, CF-1.8
                - 'product_version' : Release number of the data file.	
                - 'processing_level' : Product level.	L1B
                - 'comment' : Other information about the data, not specified in other fields.	
                - 'acknowledgment' : A section to acknowledge the various types of support for the project that produced this data.
                - 'license' : Provides the URL of a standard or specific license. Indicate "Freely distributed" or "None," or describe any access and distribution restrictions in free text.	
                - 'contact' : Free text string indicating the primary contact for obtaining information about the dataset.
                - 'NetCDF_version_id' : NetCDF version.
                - 'spatial_resolution' : Product spatial resolution.
                - 'start_time' : Time of first measurement in data file (UTC). Format 'hh:mm:ss' with hh = hours ; mm = minutes ; ss = seconds.
                - 'stop_time' : Time of last measurement in data file (UTC). Format 'hh:mm:ss' with hh = hours ; mm = minutes ; ss = seconds.
                - 'start_date' : Date of first measurement in data file. Format 'YYYY:MM:DD' with YYYY = years; MM = months ; DD = days.
                - 'stop_date' : Date of last measurement in data file. Format 'YYYY:MM:DD' with YYYY = years; MM = months ; DD = days.
                - 'northernmost_latitude' : Degrees north, range -90° to +90°
                - 'southernmost_latitude' : Degrees north, range -90° to +90°
                - 'easternmost_longitude' : Degrees east, range -180° to +180°
                - 'westernmost_longitude' : Degrees east, range -180° to +180°          
        """
        for attribute_name in attrs:
            setattr(self.__root_dataset, attribute_name, attrs[attribute_name])

    def _set_attribute(self, attribute_name: str, attribute_value, object_path: str | None = None):
        """
        Set attribute.
        :param: attribute_name: name to give the attribute
        :param: attribute_value: value to give the attribute
        :param: object_path: (optional) object to which the attribute belongs to. If None, creates a global attribute
        """
        object = self.__root_dataset
        if object_path:
            # Check that the object to which the attribute belongs exists
            try :
                object = self.__root_dataset[object_path]
            except:
                raise ValueError(f"Object {object_path} cannot be found.")
        setattr(object, attribute_name, attribute_value)
    

    
# class XarrayWriter(AbstractHDFWriter):
#     """
#     This class enables to create or open a HDF5 or NetCDF file and write data on it using the Xarray library.

#     Attributes:
#         file_path(str): the absolute file path of the file to create or update
#     """

#     def __init__(self, file_path: str) -> None:
#         self.__root_dataset = None
#         super().__init__(file_path)
    
#     def __del__(self):
#         if self.__root_dataset:
#             self.__root_dataset.close()

#     def _init_writer(self):
#         mode = super()._init_writer()
#         if mode == 'a':
#             self.__root_dataset = xr.open_dataset(self.file_path)
#         if mode in ['x', 'w']:
#             self.__root_dataset = xr.Dataset()

#     def _add_variable(self, var_path: str, dtype: str, dimensions: tuple[str], units, customFillValue = None):
#         dim_sizes = []
#         for dim_name in dimensions:
#             if dim_name not in self.__root_dataset.dims:
#                 raise ValueError(f"Dimension {dim_name} does not exist")
#             dim_sizes.append(dim_sizes)
#         var = xr.Variable(dimensions, 
#                           data = np.zeros(dim_sizes),
#                           encoding={'dtype' : dtype, '_FillValue' : customFillValue})
#         self.__root_dataset = self.__root_dataset.assign({var_path : var})
        
#         # as attribute    
#         var.units = units