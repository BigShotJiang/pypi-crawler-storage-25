# Copyright (c) 2024-2026 Centre National d'Etudes Spatiales (CNES).
#
# This file is part of AtmoTools
# (see https://github.com/CNES/AtmoTools).
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

import os
import inspect
from typing import Optional


def __get_caller_file() -> str:
    """
    Retrieve the caller file outside of this module

    :return: the caller file
    """
    # Get the frame of the caller file
    caller_frame = inspect.currentframe()

    # Get previous frame while the module name is the current module name
    module_name = __name__
    while inspect.getmodule(caller_frame).__name__ == module_name:
        caller_frame = caller_frame.f_back

    # Get the caller file
    caller_file = caller_frame.f_code.co_filename

    return caller_file


def get_abs_current_file_path() -> str:
    """
    Retrieve the absolute path of the caller file.

    :return: the absolute path of the caller file.
    """
    return os.path.abspath(__get_caller_file())


def get_abs_current_folder_path() -> str:
    """
    Retrieve the absolute path of the folder containing the caller file.

    :return: the absolute path of the folder containing the caller file.
    """

    # Return the absolute path of the folder containing the caller file
    return os.path.abspath(os.path.dirname(__get_caller_file()))


def append_path(path: str, *strings: str) -> str:
    """
    Append any number of strings to the end of a base path.

    :param path: The base path to which strings will be appended.
    :param strings: Any number of strings to append to the base path.
    :return: the resulting path after appending the strings to the base path
    """
    return os.path.join(path, *strings)


def append_current_folder(*strings: str) -> str:
    """
    Append any number of strings to the folder containing the caller file.

    :param strings: Any number of strings to append to the folder containing the caller file.
    :return: the resulting absolute path after appending the strings to the current folder path
    """
    return append_path(get_abs_current_folder_path(), *strings)


def get_last_element_in_path(path: str) -> tuple[Optional[str], Optional[str]]:
    """
    Retrieve the last element in the input path and the rest of the path.

    :param path: the string representing a path
    :return: the last element of the path and the rest of the path i.e. the last element container path

    For example: for the input "folder/subfolder/file", the function will return "file" and "folder/subfolder"
    """
    last_element = None
    container_path = None
    if path:
        # Split the path with slash
        parts = path.split('/')

        # Get last element of path
        last_element = parts[-1]

        if len(parts) > 1:
            container_path = '/'.join(parts[:-1])

    return last_element, container_path

def get_extension_in_path(path: str) -> str:
    """
    Retrieve the extension in the input path.

    :param path: the string representing a path
    :return: the extension of the path
    """
    return path.split(".")[-1] if len(path.split(".")) > 1 else None