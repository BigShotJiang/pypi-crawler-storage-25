# Copyright (c) 2024-2026 Centre National d'Etudes Spatiales (CNES).
#
# This file is part of AtmoTools
# (see https://github.com/CNES/AtmoTools).
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

import numpy as np


def generate_random_int_array(dimensions: int | tuple[int, ...], min_val: int, max_val: int,
                              seed: int | str | float | bytes | bytearray = None) -> np.ndarray:
    """
    Generate a random int array with input dimensions and values between min_val and max_val

    :param dimensions: the dimension of the resulting array
    :param min_val: the minimum value of resulting integers
    :param max_val: the maximum value of resulting integers
    :param seed: the seed used to initialize the random number generator
    :return: a random int array
    """
    # Set the seed for reproducibility
    if seed is not None:
        np.random.seed(seed)

    # Create a random integer array
    array = np.random.randint(min_val, max_val + 1, size=dimensions)
    return array


def get_indexes_from_array_interval(array, min_val, max_val):
    """
    Return the indexes for which the values of the input array are between min_val and max_val

    :param array: the array to inspect
    :param min_val: the minimum value
    :param max_val: the maximum value
    :return: the indexes for which the values are in the input interval
    """
    # Get the indexes of the array corresponding to the values in the input interval
    indexes = np.where((min_val <= array) & (max_val >= array))
    return indexes


def sort_container_by_reference(ref_container: list | tuple | np.ndarray,
                                *other_containers: list | tuple | np.ndarray,
                                reverse: bool = False) -> tuple[np.ndarray, list[np.ndarray]]:
    """
    Sort all containers (list, tuple or np.ndarray) based on the order of the `ref_container`.

    :param ref_container: The main container that determines the sort order
    :param other_containers: Additional containers to sort based on the `ref_container`
    :param reverse: If True, sorts in descending order; otherwise, sorts in ascending order
    :return: The sorted main container and the sorted other containers
    """
    # Convert ref_container to a numpy array if it's not already
    main_array = np.array(ref_container)

    # Get the sorted indices (ascending or descending based on the `reverse` flag)
    sorted_indices = np.argsort(main_array)
    if reverse:
        sorted_indices = sorted_indices[::-1]  # Reverse for descending order

    # Sort the main container and other containers based on the obtained indices
    sorted_ref = main_array[sorted_indices]
    sorted_other_containers = [np.array(container)[sorted_indices] for container in other_containers]

    return sorted_ref, sorted_other_containers


def generate_nd_array(dimensions: tuple | list) -> np.ndarray:
    """
    Generates an n-dimensional array where each element is a string "i1i2...in",
    where i1, i2, ..., in are the indices of each dimension.

    :param dimensions: A tuple or list representing the size of each dimension. Each size is an int between 1 and 9.
    :return: An n-dimensional array with the formatted "i1i2...in" values.
    """
    # Check if dimensions are between 1 and 9
    for dim in dimensions:
        if dim < 1 or dim > 9:
            raise ValueError(f"Dimension is outside of [1 ; 9]: {dim}")
    # Create an empty array with the specified dimensions
    shape = tuple(dimensions)
    table = np.empty(shape, dtype=object)

    # Use numpy's n-dimensional grid indexing to generate the table
    for index in np.ndindex(shape):
        table[index] = ''.join(map(str, index))

    return table


def check_same_shape(*arrays: np.ndarray):
    """
    Return if all input numpy arrays have the same shape
    :param arrays: the arrays to compare
    :return: True if all arrays have the same shape
    """
    return all(array.shape == arrays[0].shape for array in arrays)
