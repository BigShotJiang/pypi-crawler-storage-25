# Copyright (c) 2024-2026 Centre National d'Etudes Spatiales (CNES).
#
# This file is part of AtmoTools
# (see https://github.com/CNES/AtmoTools).
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

import os

import rasterio as rio
import rioxarray
import xarray as xr
import numpy as np
import pandas as pd
from scipy.interpolate import griddata, CloughTocher2DInterpolator
import h5py as nc
import pyproj

from dash import html

import matplotlib.pyplot as plt
import matplotlib
matplotlib.use('TkAgg')

import atmotools.utils.path_utils as pu
import atmotools.utils.geotiff_utils as gu

# Supprime l'avertissement informant que le fichier geotiff ouvert de possède pas d'information de géoréférencement.
# Les information de géoréférencement sont définies une fois le fichier ouvert.
# De plus on souhaite ouvrir un fichier vide pour enregistrer le Geotiff dedans. 
# Cette avertissement n'est donc pas pertinent et on peux s'en passer
# Concerne le code ligne 458 : rio.open()  
import warnings
warnings.filterwarnings("ignore", category=rio.errors.NotGeoreferencedWarning)

###### CONSTANTES ######

MANAGE_INVALID_VALUES = False   # retire les eventuelles valeurs invalides (typiquement a NaN) des donnees d'entree
# PRODUCT_TYPE = 'ENG'
PRODUCT_TYPE = 'RDCAL-GEOES'

ENG_RAD_VAR = 'data/measurement_data/rdcal_image'
ENG_LAT_VAR = 'data/measurement_data/geolc_imager_latitude'
ENG_LON_VAR = 'data/measurement_data/geolc_imager_longitude'
RDCAL_GEOES_RAD_VAR = 'data/measurement_data/image'
RDCAL_GEOES_LAT_VAR = 'data/measurement_data/imager_pixel_lat'
RDCAL_GEOES_LON_VAR = 'data/measurement_data/imager_pixel_long'

WGS84_EPSG = '4326'
NORTH_POLE_EPSG = '32661'
SOUTH_POLE_EPSG = '32761'
RESOLUTION_IN_METERS = 500      # 500m de resol, juste inferieur au 700m natif NADIR

MARGIN_RATIO = 1/50.0

DATA_FOLDER_PATH = os.path.normpath(os.path.join(pu.get_abs_current_folder_path(),"../../data"))
OUTPATH = os.path.join(DATA_FOLDER_PATH,"geotiffs")

# Voir pour récupérer ce valeurs de manière automatique
NB_LINE = 5
NB_FOR = 14
NB_FOV = 16


###### FUNCTIONS ######

def check_var_inbound(var, var_name, valid_min, valid_max):

    out_of_bounds_mask = (var < valid_min) | (var > valid_max)
    if np.any(out_of_bounds_mask):
        out_of_bounds_indices = np.where(out_of_bounds_mask)
        out_of_bounds_values = var[out_of_bounds_mask]
        # print(f"Warning: {var_name} contains {len(out_of_bounds_values)} value(s) "
            #   f"outside of the valid range [{valid_min}, {valid_max}] at the positions:\n"
            #   f"\t Indices [(iBRC, iFOR, iDet, iRow, iCol)]: {list(zip(*out_of_bounds_indices))}\n"
            #   f"\t Value(s): {out_of_bounds_values}")
    return out_of_bounds_mask


def check_var_nan(var, var_name, nan_value, missing_value):

    nan_or_miss_mask = (var == nan_value) | (var == missing_value)
    if np.any(nan_or_miss_mask):
        nan_or_miss_indices = np.where(nan_or_miss_mask)
        nan_or_miss_values = var[nan_or_miss_mask]
        # print(f"Warning: {var_name} contains {len(nan_or_miss_values)} "
            #   f"NaN ({nan_value}) or missing value(s) ({missing_value}) at the positions:\n"
            #   f"\t Indices [(iBRC, iFOR, iDet, iRow, iCol)]: {list(zip(*nan_or_miss_indices))}\n"
            #   f"\t Value(s): {nan_or_miss_values}")
    return nan_or_miss_mask


def check_var(var, var_name, valid_min, valid_max, nan_value, missing_value):

    # test hors du range de valeurs valides
    out_of_bounds_mask = check_var_inbound(var, var_name, valid_min, valid_max)
    # test NaN ou missing value
    nan_or_miss_mask = check_var_nan(var, var_name, nan_value, missing_value)
    return out_of_bounds_mask, nan_or_miss_mask


def convert_lonlat(longitudes, latitudes, src_epsg, dest_epsg):

    # definition des systemes de coordonnees et init convertisseur de l'un vers l'autre
    src_crs = pyproj.CRS("EPSG:"+src_epsg)
    dest_crs = pyproj.CRS("EPSG:"+dest_epsg)
    proj_transformer = pyproj.Transformer.from_crs(src_crs, dest_crs, always_xy=True)
    # note : always_xy=True garantit que l'ordre des coordonnees est (lon, lat) en entree

    # conversion des lon/lat de la projection source a la projection d'arrivee
    longitudes_proj, latitudes_proj = proj_transformer.transform(longitudes, latitudes)

    # calcul coordonnees min/max dans le repere d'arrivee
    min_lon = np.min(longitudes_proj)
    max_lon = np.max(longitudes_proj)
    min_lat = np.min(latitudes_proj)
    max_lat = np.max(latitudes_proj)

    return longitudes_proj, latitudes_proj, min_lon, max_lon, min_lat, max_lat

def create_geotiff(inputfile, outputdirectory, geotiff_index = [], save_geotiff = False) -> list[xr.DataArray]: # Gérer avec des valeurs par défaut ou erreur
    """
    Create Geotiffs for IASI-NG using an ENG file in input.
    For each geotiff_index (line,for,detector) in input, this function create a geotiff. 

    :param inputfile: ENG file used to produce Geotiffs (str)
    :param outputdirectory: Directory which Geotiffs are saved and loaded (str) 
    :param geotiff_index: List of Index of each Geotiff as  (line, for, detector)
    :param save_geotiff: Activate of desactive saving option

    :return iframe : Return an html.iframe containing a bokeh figure of Geotiffs 

    """

    ###### OUTPUT DIRECTORY ######
    if save_geotiff :
        out_dirname = os.path.join(outputdirectory,pu.get_last_element_in_path(inputfile)[0].split('.')[0])
        if not os.path.isdir(out_dirname):
            os.makedirs(out_dirname)
        else:
            print('Warning: Output directory already exists, you may overwrite previous results')

        if (PRODUCT_TYPE != 'ENG') and (PRODUCT_TYPE != 'RDCAL-GEOES'):
            print('Error: Unknown product type: %s, it must be ENG or RDCAL-GEOES' % PRODUCT_TYPE)

    ####### ENG #######

    ncFile = nc.File(inputfile, "r")
    rad_img_nc = ncFile.get(ENG_RAD_VAR)                                # radiance de chaque pixel IMA
    lat_img_nc = ncFile.get(ENG_LAT_VAR)                                # latitude de chaque ou certains pixels IMA
    lon_img_nc = ncFile.get(ENG_LON_VAR)                                # idem : longitude
    lin_img_nc = ncFile.get('data/measurement_data/geolc_nlin_geo')     # idem : indices ligne
    col_img_nc = ncFile.get('data/measurement_data/geolc_ncol_geo')     # idem : indices colonne

    rad_img = np.array(rad_img_nc)
    lat_img = np.array(lat_img_nc)
    lon_img = np.array(lon_img_nc)
    lin_img = np.array(lin_img_nc)
    col_img = np.array(col_img_nc)

    # recuperation des attributs de validite ou non des valeurs pour les radiances, latitudes et longitudes
    # note : "[0]" car attrs renvoit une liste contenant la valeur (unique) a recuperer
    rad_valid_min = rad_img_nc.attrs['valid_min'][0]
    lat_valid_min = lat_img_nc.attrs['valid_min'][0]
    lon_valid_min = lon_img_nc.attrs['valid_min'][0]
    rad_valid_max = rad_img_nc.attrs['valid_max'][0]
    lat_valid_max = lat_img_nc.attrs['valid_max'][0]
    lon_valid_max = lon_img_nc.attrs['valid_max'][0]
    rad_nan_value = rad_img_nc.attrs['_FillValue'][0]
    lat_nan_value = lat_img_nc.attrs['_FillValue'][0]
    lon_nan_value = lon_img_nc.attrs['_FillValue'][0]
    rad_missing_value = rad_img_nc.attrs['missing_value'][0]
    lat_missing_value = lat_img_nc.attrs['missing_value'][0]
    lon_missing_value = lon_img_nc.attrs['missing_value'][0]

    # tests de presence de valeurs invalides pour ces variables
    rad_out_of_bounds_mask, rad_nan_or_miss_mask \
        = check_var(rad_img, ENG_RAD_VAR, rad_valid_min, rad_valid_max, rad_nan_value, rad_missing_value)
    lat_out_of_bounds_mask, lat_nan_or_miss_mask \
        = check_var(lat_img, ENG_LAT_VAR, lat_valid_min, lat_valid_max, lat_nan_value, lat_missing_value)
    lon_out_of_bounds_mask, lon_nan_or_miss_mask \
        = check_var(lon_img, ENG_LON_VAR, lon_valid_min, lon_valid_max, lon_nan_value, lon_missing_value)

    # enregistrement des eventuelles valeurs invalides dans un masque commun (si requis)
    if MANAGE_INVALID_VALUES:
        invalid_values_mask = rad_out_of_bounds_mask | rad_nan_or_miss_mask \
            | lat_out_of_bounds_mask | lat_nan_or_miss_mask \
            | lon_out_of_bounds_mask | lon_nan_or_miss_mask

    # recuperation des attributs de scaling et d'offset correspondant aux radiance, latitude et longitude
    rad_scaling = rad_img_nc.attrs['scale_factor']
    lat_scaling = lat_img_nc.attrs['scale_factor']
    lon_scaling = lon_img_nc.attrs['scale_factor']
    rad_offset = rad_img_nc.attrs['add_offset']
    lat_offset = lat_img_nc.attrs['add_offset']
    lon_offset = lon_img_nc.attrs['add_offset']

    # application du scaling et de l'offset aux donnees
    rad_img = rad_img * rad_scaling + rad_offset
    lat_img = lat_img * lat_scaling + lat_offset
    lon_img = lon_img * lon_scaling + lon_offset

    ncFile.close()

    ###### ######

    nbBRC = rad_img.shape[0]
    nbFOR = rad_img.shape[1]
    nbDetectors = rad_img.shape[2]

    # if np.max(lines) > nbBRC or np.max(fors) > nbFOR or np.max(fovs) > nbDetectors :
    #     print("Lines, fors or fovs index out of range")
    #     raise IndexError

    # selected_BRC = lines if len(lines) > 0 else range(nbBRC)
    # selected_FOR = fors if len(fors) > 0 else range(nbFOR)
    # selected_Detectors = detectors if len(detectors) > 0 else range(nbDetectors)

    img_nrows = rad_img.shape[3]
    img_ncols = rad_img.shape[4]
    grid_nrows = lat_img.shape[3]
    grid_ncols = lat_img.shape[4]

    # print('\nGlobal processing infos:')
    # print(' %s BRCs, %s FORs, %s detectors' % (nbBRC, nbFOR, nbDetectors))
    # print(' Selected %s BRCs, %s FORs, %s detectors' % (selected_BRC, selected_FOR, selected_Detectors))
    # print(" IMA size: [%s, %s] " % (img_nrows, img_ncols))
    # print(" lat/lon grids size: [%s, %s] " % (grid_nrows, grid_ncols))

    isDenseGrid = (img_nrows == grid_nrows) and (img_ncols == grid_ncols)

    # Si les grilles de lat/lon sont "laches" :
    # 1. on verifie qu'elles ont le meme nombre de col/lig que les grilles d'indices des pixels IMA
    # 2. on prepare les indices de la grille dense
    if not isDenseGrid:

        if (grid_nrows != lin_img.shape[1]) or (grid_ncols != col_img.shape[1]):
            print('\nError: The lat/lon grids and the indices grids of IMA pixels must have the same number of rows/cols')
            exit(1)

        # print('Interpolations will be performed on lat/lon grids so they have the size of IMA')
        all_rows = []
        all_cols = []
        for idet in range(nbDetectors):
            rows = list(range(lin_img[idet][0], lin_img[idet][-1] + 1))
            cols = list(range(col_img[idet][0], col_img[idet][-1] + 1))
            all_rows.append(rows)
            all_cols.append(cols)

    # init ellipsoide WGS84 pour estimation des pas lat/lon en geo
    geo_ellps = pyproj.Geod(ellps="WGS84")

    # Init la liste des xarray de geotiff à retourner
    geotiffs = []

    # TODO : boucle sur les fichiers ENG en entrée ?
    # for ibrc in selected_BRC:

        # brc_name = "BRC" + str(ibrc)
        # print('\n\nProcessing', brc_name)

        # # creation du dossier de sortie pour le BRC courant
        # brc_dirpath = os.path.join(out_dirname, brc_name)
        # if not os.path.isdir(brc_dirpath):
        #     os.makedirs(brc_dirpath)

        # for ifor in selected_FOR:

            # for_name = "FOR" + str(ifor)
            # print('\nProcessing', for_name)

            # for idet in selected_Detectors:

    
    for index in geotiff_index:

        ibrc = int(index[0])
        ifor = int(index[1])
        idet = int(index[2])

        for_name = "FOR" + str(ifor)
        brc_name = "BRC" + str(ibrc)


        if idet == 0:
            det_name = "IMA_A"
        elif idet == 1:
            det_name = "IMA_B"
        else:
            print("\nError: There should be only 2 detectors, here this is the number", idet+1)
            exit(2)

        # print(f"Processing {brc_name}_{for_name}_{det_name}")

        if save_geotiff : 
            # definitions dependant du BRC, du FOR et du detecteur
            out_filename = brc_name + '_' + for_name + '_' + det_name + ".tif"
            out_filepath = os.path.join(out_dirname, out_filename)

            # Skip iteration if the geotiff already exist
            if os.path.isfile(out_filepath) :
                with rioxarray.open_rasterio(out_filepath, load_data=False) as da :
                    geotiffs.append(da)
                continue

        theRad = rad_img[ibrc, ifor, idet, :, :]
        theLat = lat_img[ibrc, ifor, idet, :, :]
        theLon = lon_img[ibrc, ifor, idet, :, :]

        # preparation a l'interpolation a venir
        theLat_r = theLat.ravel()
        theLon_r = theLon.ravel()
        theRad_r = theRad.ravel()

        # preparation a l'interpolation des grilles de lat/lon laches pour le detecteur courant
        if not isDenseGrid:
            theLin = lin_img[idet, :]
            theCol = col_img[idet, :]
            theLinFull = all_rows[idet][:]
            theColFull = all_cols[idet][:]
        # preparation au filtrage des valeurs invalides (si requis)
        if MANAGE_INVALID_VALUES:
            theMask = invalid_values_mask[ibrc, ifor, idet, :, :]
            theMask_r = theMask.ravel()
            # retrait des eventuelles valeurs invalides avant interpolation (si requis)
            theLat_r = theLat_r[~theMask_r]
            theLon_r = theLon_r[~theMask_r]
            theRad_r = theRad_r[~theMask_r]

        # coordonnees min/max
        min_lat = np.min(theLat_r)
        max_lat = np.max(theLat_r)
        min_lon = np.min(theLon_r)
        max_lon = np.max(theLon_r)
        cur_epsg = WGS84_EPSG

        # estimation du pas en lat/lon correspondant a 500m dans le detecteur courant
        center_lat = (min_lat + max_lat) / 2
        center_lon = (min_lon + max_lon) / 2
        _, north_lat, _ = geo_ellps.fwd(lons=center_lon, lats=center_lat, az=0, dist=RESOLUTION_IN_METERS)
        east_lon, _, _ = geo_ellps.fwd(lons=center_lon, lats=center_lat, az=90, dist=RESOLUTION_IN_METERS)
        cur_lat_resol = north_lat - center_lat
        cur_lon_resol = east_lon - center_lon

        # adaptation eventuelle de la projection geographique a utiliser suivant les coordonnees geo
        # pour toujours rester dans une geometrie continue pour les traitements a venir
        # projection polaire nord
        if max_lat > 80:

            # print('North pole alert => we convert coordinates to EPSG:32661 (projection on UPS North (N,E))')s

            theLon_r, theLat_r, min_lon, max_lon, min_lat, max_lat \
                = convert_lonlat(theLon_r, theLat_r, WGS84_EPSG, NORTH_POLE_EPSG)

            cur_epsg = NORTH_POLE_EPSG
            cur_lat_resol = RESOLUTION_IN_METERS
            cur_lon_resol = RESOLUTION_IN_METERS

        # projection polaire sud
        elif min_lat < -80:

            # print('South pole alert => we convert coordinates to EPSG:32761 (projection on UPS South (N,E))')

            theLon_r, theLat_r, min_lon, max_lon, min_lat, max_lat \
                = convert_lonlat(theLon_r, theLat_r, WGS84_EPSG, SOUTH_POLE_EPSG)

            cur_epsg = SOUTH_POLE_EPSG
            cur_lat_resol = RESOLUTION_IN_METERS
            cur_lon_resol = RESOLUTION_IN_METERS

        # projection sur UTM en cas de proximite avec l'antimeridien
        elif min_lon < -170 or max_lon > 170:

            # print('Antimeridian alert => we convert coordinates to the UTM zone mostly covering them')

            # estimation du code EPSG correspondant a la zone UTM du detecteur courant
            # ajout de 360 degres aux eventuelles longitudes negatives pour eviter le saut 180/-180
            theLon_r = np.where(theLon_r < 0, theLon_r + 360, theLon_r)
            # determination de la zone UTM centrale a partir de la longitude moyenne
            mean_lon = np.mean(theLon_r)
            utm_zone = int((mean_lon + 180) // 6) % 60 + 1
            # note: "% 60" pour mean_lon >= 180, i.e. longitudes initiales entre [-180, 0[
            # print(f"Chosen UTM zone: {utm_zone:02d}")
            cur_epsg = f"326{utm_zone:02d}" if theLat_r.mean() >= 0 else f"327{utm_zone:02d}"
            # note: ":02d" pour ajouter un "0" au debut du numero UTM s'il s'agit d'un simple chiffre
            #       sinon le code EPSG n'est pas le bon !

            theLon_r, theLat_r, min_lon, max_lon, min_lat, max_lat \
                = convert_lonlat(theLon_r, theLat_r, WGS84_EPSG, cur_epsg)

            cur_lat_resol = RESOLUTION_IN_METERS
            cur_lon_resol = RESOLUTION_IN_METERS

        # print("initial latmin, latmax, lonmin, lonmax, ", min_lat, max_lat, min_lon, max_lon)
        # print(" initial reso lat, lon ", theLat[0, 0] - theLat[1, 1], theLon[0, 0] - theLon[1, 1])
        # print(" target reso lat, lon ", cur_lat_resol, cur_lon_resol)

        # Cas ou certaines coordonées sont manquantes et que la conversion donne des valeurs à l'infinie    
        if np.isinf([min_lat, max_lat, min_lon, max_lon]).any() :
            continue 

        diff_lat = max_lat - min_lat
        min_lat = min_lat - diff_lat * MARGIN_RATIO
        max_lat = max_lat + diff_lat * MARGIN_RATIO
        diff_lon = max_lon - min_lon
        min_lon = min_lon - diff_lon * MARGIN_RATIO
        max_lon = max_lon + diff_lon * MARGIN_RATIO

        reso_lat = cur_lat_resol
        reso_lon = cur_lon_resol
    
        nb_lat = int((max_lat - min_lat)/reso_lat)
        nb_lon = int((max_lon - min_lon)/reso_lon)

        # print("final latmin, latmax, lonmin, lonmax, ", min_lat, max_lat, min_lon, max_lon)
        # print(" nblig, nbcol ", nb_lat, nb_lon)

        # origine au coin haut gauche dans la definition geotiff
        lat_ori = max_lat + reso_lat/2
        lon_ori = min_lon - reso_lon/2

        # print(" origine coin haut gauche (lon,lat)", lon_ori, lat_ori)

        # interpolation des grilles de lat/lon si elles ne sont pas pleines
        if not isDenseGrid:

            # print('lat/lon grids interpolation')

            # creation des listes de points laches pour l'interpolation
            sparse_lat_r = theLat_r
            sparse_lon_r = theLon_r

            # retrait des eventuelles valeurs invalides avant interpolation (si requis)
            if MANAGE_INVALID_VALUES:
                sparse_lat_r = sparse_lat_r[~theMask_r]
                sparse_lon_r = sparse_lon_r[~theMask_r]
                theLin = theLin[~theMask_r]
                theCol = theCol[~theMask_r]

            # creation de la grille pleine des col/lig
            grid_x, grid_y = np.meshgrid(theColFull, theLinFull)

            # interpolation des lat/lon sur la grille pleine
            sparse_rows_cols = np.array(np.meshgrid(theLin, theCol)).T.reshape(-1, 2)
            theLat = griddata(sparse_rows_cols, sparse_lat_r, (grid_y, grid_x), method='linear')
            theLon = griddata(sparse_rows_cols, sparse_lon_r, (grid_y, grid_x), method='linear')

            # retour au format vectoriel
            theLat_r = theLat.ravel()
            theLon_r = theLon.ravel()

        # print('orthorectification...')

        # definition de la fonction d'interpolation sur grille non reguliere
        f = CloughTocher2DInterpolator(list(zip(theLat_r, theLon_r)), theRad_r)

        # resampling
        rad_resampled = np.zeros((nb_lat, nb_lon))
        for i in range(nb_lat):
            i_lat = max_lat - reso_lat * i
            for j in range(nb_lon):
                j_lon = min_lon + reso_lon * j
                rad_resampled[i, j] = f(i_lat, j_lon)

        # sauvegarde en geotif
        if save_geotiff :
            with rio.open(out_filepath, 'w', driver='GTiff', count=1,
                        height=rad_resampled.shape[0], width=rad_resampled.shape[1],
                        dtype=str(rad_resampled.dtype)) as raster:
                raster.crs = rio.crs.CRS.from_epsg(cur_epsg)
                raster.transform = rio.Affine.from_gdal(lon_ori, reso_lon, 0, lat_ori, 0, -reso_lat)
                raster.write(rad_resampled, 1)

        if ifor in []:
            plt.figure("resampled")
            plt.imshow(rad_resampled)
            plt.figure("raw")
            plt.imshow(theRad)
            plt.show()

        da = xr.DataArray(rad_resampled, dims=['y', 'x'])
        height, width = rad_resampled.shape[-2], rad_resampled.shape[-1]
        transform = rio.Affine.from_gdal(lon_ori, reso_lon, 0, lat_ori, 0, -reso_lat)
        y_coords = np.arange(height) * transform[4] + transform[5] + transform[4]/2
        x_coords = np.arange(width) * transform[0] + transform[2] + transform[0]/2
        da = da.assign_coords(x=x_coords, y=y_coords)
        da.rio.write_crs(rio.crs.CRS.from_epsg(cur_epsg), inplace=True)

        geotiffs.append(da)
    print(f"INFO : Geotiffs saved in {out_filepath}") if save_geotiff else None
    return  geotiffs

def plot_geotiff(df_scatter = pd.DataFrame({'Latitude': [], 'Longitude': [], 'Line': [], 'For': [], 'Fov': [], 'Eng_path' : []}), save_geotiff = False) -> html.Iframe :
    """
    Find the 4 nearest Geotiff of each selected fovs.
    Then use the fonction create_geotiff() and utils fonction to create and plot geotiff on a map.
    Return an iframe with the bokeh figure.

    :param df_scatter : A dataframe containing information of all selected fov on the map (Lat, Lon, Line, For, Fov, Path of the ENG file)
    :param save_geotiff : Activate of desactive saving option

    :return iframe : Return an html.iframe containing a bokeh figure of Geotiffs
    """
    ######## CREATE GEOTIFF ########
    print("Loading Geotiffs...") 
    # Generate Geotiff for each selected file
    eng_paths = set(df_scatter['Eng_path'])
    geotiffs = []  # Contains all geotiffs  

    for path in eng_paths : 
        df_scatter_by_file = df_scatter[df_scatter['Eng_path'] == path] # Get selected fovs by selected file 

        geotiffs_index = set() # Contains (line,for,detector) of each Geotiff to load. 

        # Find the 3 nearest geotiff of the geotiff corresponding to the selected fov
        for i, selected_fov in df_scatter_by_file.iterrows() :
            main_line = int(selected_fov['Line'])
            main_for = int(selected_fov['For'])
            main_fov = int(selected_fov['Fov'])

            lines = [] 

            # Find the nearest line.
            if main_fov in range(int(NB_FOV/2)):
                lines.append(main_line)
                lines.append(main_line+1 if main_line < (NB_LINE-2) else main_line)

            else :
                lines.append(main_line)
                lines.append(main_line-1 if main_line > 0 else main_line)

            # Find the nearest For and Detector. 
            for l in lines :
                if main_fov in range(0, NB_FOV, 4) :
                    geotiffs_index.add((l, main_for, 0))
                    geotiffs_index.add((l, main_for-1 if main_for > 0 else main_for , 1))
                elif main_fov in range(3, NB_FOV, 4):
                    geotiffs_index.add((l, main_for, 1))
                    geotiffs_index.add((l, main_for+1 if main_for < (NB_FOR-2) else main_for , 0))
                else :
                    geotiffs_index.add((l, main_for, 0))
                    geotiffs_index.add((l, main_for, 1))

        # Create Geotiffs 
        geotiffs += create_geotiff(path, OUTPATH, geotiff_index = geotiffs_index, save_geotiff = save_geotiff)
        # Create an iframe with Geotiff map and selected fovs using Bokeh
    print(f"Geotiffs loaded : {len(geotiffs)}")
    iframe_geotiffs = gu.plot_geotiff(df_scatter, geotiffs)

    return iframe_geotiffs