# Copyright (c) 2024-2026 Centre National d'Etudes Spatiales (CNES).
#
# This file is part of AtmoTools
# (see https://github.com/CNES/AtmoTools).
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

import os

import numpy as np
import pandas as pd

import atmotools.missions.IASI_NG.models.iasing_l1c_product as l1cproduct
import atmotools.missions.IASI_NG.models.iasing_l0_product as l0product

from atmotools.missions.IASI_NG.config import SPEED_OF_LIGHT, CSV_SEPARATOR, DATA_FOLDER_PATH

import atmotools.utils.path_utils as pu
import atmotools.utils.time_utils as tu

class DataManager():
    """
        This class load products files and give some methods to manipulate data.
        :param : nc_eng_paths : List of eng files 
        :param : nc_rad_paths : List of rad files
        :param : nc_ods_paths : List of ods files

        Atrributes : 
            isENG : Bool : True = at least 1 ENG file loaded ; False = no ENG file loaded
            isRAD : Bool : True = at least 1 RAD file loaded ; False = no RAD file loaded
            isODS : Bool : True = at least 1 ODS file loaded ; False = no ODS file loaded
            eng_products : dict(<acquisition_id :str>:<product :IASING_L1C_ENG>) : Dict of L1C ENG products
            rad_products : dict(<acquisition_id :str>:<product :IASING_L1C_RAD>) : Dict of L1C RAD products
            ods_products : dict(<acquisition_id :str>:<product :IASING_L0_ODS>) : Dict of L0 ODS products
            all_products : dict(<acquisition_id :str>:dict()) : Dict of all loaded products for each acquisition_id 
            all_acqu_ids : list(<acquisition_id :str>)

            df : pandas.DataFrame() : Contains all coordinates and other information for each fov
            filtered_df : pandas.DataFrame()
            file_index_to_prod : dict(<file_index :int>:<acquisition_id :str>)

            all_flags_int_dicts : dict() : Group all parts of the flag and their values (int and str) in a single dictionnary for each file
            all_flags_str_dicts : dict()

            features : dict() Geometry of all selected fovs circle as a GeoJson

            all_vars_rad : dict() : Dicts of additional RAD variables, from available ones in RAD file
            var_paths : list(<str>) : List of paths for variables that are along fov dimensions
            all_vars_ods : dict() : Dicts of additional ODS variables, from available ones in ODS file

        Methods:
            mask(lines, fors, fovs, selected_files) ......................................... This method return values of the dataframe corresponding to the selection (lines, fors, fovs and files)
            get_data_for_geotiff(selectedData) .............................................. This method filter df by selected fovs and add the file_path as a colomun of the dataframe
            select(selectedData, selected_file) ............................................. This method return select fovs using selectedData and selected_file
            get_geojson_geometry(lines, fors, fovs, selected_files) ......................... This method create fovs circle as GeoJSON multiPolygons
            get_spectra_data(fovs, selected_spectra, eng) ................................... This method get data from products to plot spectra graphs.
            export_spectra_as_csv() ......................................................... This method create two csv files with spectra data at data/iasing_spectra
            get_flag_details(fovs) .......................................................... This method return the flags details as records
            get_add_vars(fovs, paths_list) .................................................. This method return variables to add to the variables table as records
            get_zpd() ....................................................................... This method get zpd data from products
            get_nzpd() ...................................................................... This method get nzpd data from product
            get_general_quality_flags_ratio() ............................................... This method get ratio for all flags, per file
            get_spike_flags_ratio() ......................................................... This method get spike flags ration from l0 product
            get_l1c_or_l0_variables_mean(product_name, var_path, dim_names, remaining_dim) .. This method get the mean of a variable from l1c or l0 product
    """

    def __init__(self, nc_eng_paths: list[str| None], nc_rad_paths: list[str| None], nc_ods_paths: list[str | None]):

        self.isENG = nc_eng_paths != []
        self.isRAD = nc_rad_paths != []
        self.isODS = nc_ods_paths != []

        print("---- Input files ----")
        print(f'ENG file(s) provided as input : {self.isENG}\nRAD file(s) provided as input : {self.isRAD}\nODS file(s) provided as input : {self.isODS}')
        print("---------------------")
        
        # Get necessary info from the files
        self.eng_products, self.rad_products, self.ods_products, self.all_products, self.all_acqu_ids = self._load_products(nc_eng_paths, nc_rad_paths, nc_ods_paths)
        print("------------all_products------------\n",self.all_products,"\n------------end all_products------------")
        
        # Use the ENG file if present
        if self.isENG or self.isRAD:
            # Group all the fov coordinates of all files in a single dataframe (if and ENG or RAD file is present)
            self.df, self.filtered_df, self.file_index_to_prod = self._load_coordinates()
            print("------------df.info------------")
            print(self.df.info(),"\n------------end df.info------------")

            # Group all parts of the flag FLAG_TO_SHOW_PATH and their values (int and str) in a single dictionnary for each file
            self.all_flags_int_dicts, self.all_flags_str_dicts = self._load_flags()

            # Add flags values to dataframe
            for key in self.all_flags_int_dicts[list(self.all_flags_int_dicts.keys())[0]].keys():
                self.df[key] = "no info"
                self.df[key] = self.df.apply(lambda row: self.all_flags_int_dicts[self.file_index_to_prod[row["File index"]]][key][row["Line"]][row["For"]][row["Fov"]], axis = 1)
                self.df[key] = self.df[key].astype("category")

            # Group all fov ful shapes in a list of geojsons
            self.features = self.get_geojson_geometry()

        # Create lists of additional RAD variables, from available ones in RAD file
        if self.isRAD:
            self.all_vars_rad = self.rad_products[list(self.rad_products.keys())[0]].get_reader().describe_all_vars(call_print= False)
            # Create list of paths for variables that are along fov dimensions
            self.var_paths = [key for key in self.all_vars_rad.keys() \
                        if list(self.all_vars_rad[key]["dimensions"].keys()) == [l1cproduct.AbstractIASING_L1C.N_LINES_DIM,
                                                                            l1cproduct.AbstractIASING_L1C.N_FORS_DIM,
                                                                            l1cproduct.AbstractIASING_L1C.N_FOVS_DIM]]

        # Create list of additional ODS variables, from available ones in ODS file
        if self.isODS:
            self.all_vars_ods = self.ods_products[list(self.ods_products.keys())[0]].get_reader().describe_all_vars(call_print= False)

    def _close_products(self):
        # Close the files and delete the readers to ensure there is no data corruption
        for eng_id in self.eng_products:
            del self.eng_products[eng_id].reader
        for rad_id in self.rad_products:
            del self.rad_products[rad_id].reader
        for ods_id in self.ods_products:
            del self.ods_products[ods_id].reader

        print("Files closed")

    
    def _load_products(self, nc_eng_paths: list[str| None], nc_rad_paths: list[str| None], nc_ods_paths: list[str | None]):

        # Create a product for each of the files to show, both RAD and ENG, and store them in lists
        eng_products = {l1cproduct.IASING_L1C_ENG(nc_eng_path, useXarray=False).get_acquisition_id(): l1cproduct.IASING_L1C_ENG(nc_eng_path, useXarray=False) for nc_eng_path in nc_eng_paths}
        rad_products = {l1cproduct.IASING_L1C_RAD(nc_rad_path, useXarray=False).get_acquisition_id(): l1cproduct.IASING_L1C_RAD(nc_rad_path, useXarray=False) for nc_rad_path in nc_rad_paths}
        ods_products = {l0product.IASING_L0_ODS(nc_ods_path, useXarray=False)._get_acquisition_id(): l0product.IASING_L0_ODS(nc_ods_path, useXarray=False) for nc_ods_path in nc_ods_paths}
        all_products = dict()
        all_acqu_ids = list(set(list(eng_products.keys()) + list(rad_products.keys()) + list(ods_products.keys())))
        for i, key in enumerate(all_acqu_ids):
            all_products[key] = {"Acquisition time": "_".join(key.split("_")[0:2]),
                                "L1C-ENG": eng_products[key] if key in eng_products.keys() else None,
                                "L1C-RAD": rad_products[key] if key in rad_products.keys() else None,
                                "ODS": ods_products[key] if key in ods_products.keys() else None}
        return eng_products, rad_products, ods_products, all_products, all_acqu_ids

    def _load_coordinates(self):
        # Group all the fov coordinates of all files in a single dataframe (if and ENG or RAD file is present)
        # Use the ENG file if present
        file_index_to_prod = dict()
        i = 0
        df = pd.DataFrame()
        for id in self.all_products:
            eng_product = self.all_products[id]['L1C-ENG'] if self.all_products[id]['L1C-ENG'] else None
            rad_product = self.all_products[id]['L1C-RAD'] if self.all_products[id]['L1C-RAD'] else None
            if not eng_product and not rad_product:
                continue
            df_new = eng_product._get_all_coordinates(rad_product=rad_product) if eng_product else rad_product._get_all_coordinates()
            df_new["File index"] = i
            df_new["File name"] = eng_product.get_short_file_name() if eng_product else rad_product.get_short_file_name()
            df_new["File acq_id"] = eng_product.get_acquisition_id() if eng_product else rad_product.get_acquisition_id()
            file_index_to_prod[i] = id
            i += 1
        # Delete rows where there is no information on latitude or longitude
            if eng_product:
                max_val = eng_product.extract_var(eng_product.LAT_PATH_ENG).get_fill_value() + 100 if eng_product.extract_var(eng_product.LAT_PATH_ENG).get_fill_value() else -1000
                df_new.loc[df_new['Latitude'] <= max_val, ['Latitude', 'Longitude', 'Coordinates']] = np.nan
                df_new.loc[df_new['Longitude'] <= max_val, ['Latitude', 'Longitude', 'Coordinates']] = np.nan
            elif rad_product:
                max_val = rad_product.extract_var(rad_product.LAT_PATH_RAD).get_fill_value() + 100 if rad_product.extract_var(rad_product.LAT_PATH_RAD).get_fill_value() else -1000
                df_new.loc[df_new['Latitude'] <= max_val, ['Latitude', 'Longitude']] = np.nan
                df_new.loc[df_new['Longitude'] <= max_val, ['Latitude', 'Longitude']] = np.nan
            df = pd.concat([df, df_new], ignore_index=True)
        df.dropna(subset = df.columns.difference(['Coordinates']),inplace=True)

        # Dataframe with separate columns for lines, fors and fovs
        parsed = df['Fov index'].apply(lambda x: pd.Series({'Line': x[0], 'For': x[1], 'Fov': x[2]}))
        filtered_df = df.join(parsed)
        df = filtered_df

        return df, filtered_df, file_index_to_prod

    def _load_flags(self):
        # Group all parts of the flag FLAG_TO_SHOW_PATH and their values (int and str) in a single dictionnary for each file
        all_flags_int_dicts = {}
        all_flags_str_dicts = {}
        for id in self.all_products:
            l1c_product = self.all_products[id]['L1C-ENG'] if self.all_products[id]['L1C-ENG'] else self.all_products[id]['L1C-RAD'] if self.all_products[id]['L1C-RAD'] else None
            if not l1c_product:
                continue
            flags_values_int = l1c_product.get_flag_int_values()
            all_flags_int_dicts[l1c_product.get_acquisition_id()] = flags_values_int
            all_flags_str_dicts[l1c_product.get_acquisition_id()] = l1c_product.get_flag_str_values(flags_int_values=flags_values_int)

        return  all_flags_int_dicts, all_flags_str_dicts

    def mask(self, lines = None, fors = None, fovs = None, selected_files = None):
        """
            This method return values of the dataframe corresponding to the selection (lines, fors, fovs and files)

            :param: lines : list(<int>)
            :param: fors : list(<int>)
            :param: fovs : list(<int>)
            :param: selected_files : list(<str>) 

            :return: filtered_df : pandas.DataFrame()
        """
        if not lines and not fors and not fovs and not selected_files:
            return self.df
        else :
            mask = (
                (self.filtered_df['Line'].isin(lines) if lines else True) &
                (self.filtered_df['For'].isin(fors) if fors else True) &
                (self.filtered_df['Fov'].isin(fovs) if fovs else True) &
                (self.filtered_df['File acq_id'].isin(selected_files) if selected_files else True )
            )
            return self.filtered_df[mask]

    def get_data_for_geotiff(self, selectedData):
        """
            This method filter df by selected fovs and add the file_path as a colomun of the dataframe

            :param: selectedData : dict() : Contains file, line, for, fov indexes
            :return: scatter_df : pandas.DataFrame() : The fitlered dataframe
        """
        scatter_df =pd.DataFrame({'Latitude': [], 'Longitude': [], 'Line': [], 'For': [], 'Fov': [], 'Eng_path' : []}) # Contains data about selected fovs 
        for point in selectedData['points'] :

            # get the corresponding ENG file
            index_file = point['customdata'][3]-1
            acq_id = self.file_index_to_prod[index_file]
            l1c_prod = self.all_products[acq_id]['L1C-ENG']

            if l1c_prod :
                # Get data about the selected fov  
                eng_path = l1c_prod.get_file_path()
                dff = self.df[self.df['Latitude'] == point['lat']]
                dff = dff[dff['Longitude'] == point['lon']]
                dff = dff[dff['File index'] == index_file]
                dff['Eng_path'] = [eng_path] 
                scatter_df = pd.concat([scatter_df,dff[['Latitude', 'Longitude', 'Line', 'For', 'Fov', 'Eng_path']]])
            else :
                print("ERROR: No ENG file for Geotiff loading. Please make sure to upload the corresponding file.")
                if len(selectedData['points'] ) > 1:
                    continue
                else : 
                    return None
        return scatter_df if len(scatter_df) > 0 else None

    def select(self, selectedData, selected_file):
        """ 
            This method return select fovs using selectedData and selected_file

            :param: selectedData: dict() : Contains file, line, for, fov indexes
            :param: selectedFile: list(<str>) : Contains selected file name
            :return: selected_fovs : list( list(int)) : List of all selected fovs
        """
        if not selectedData :
            return [] 
        # Get the info for all selected fovs (i.e. file number, line, for and fov)
        selected_fovs = [] 
        for point in selectedData['points']:
            dff = self.df[self.df['Latitude'] == point['lat']]
            dff = dff[dff['Longitude'] == point['lon']]
            fov = (dff["Fov index"].values[0])
            # Get info for all files or only selected files (if a fov is in multiple files)  
            for file in dff["File index"].values :
                if selected_file :
                    if self.file_index_to_prod[file] in selected_file :   
                        selected_fovs.append([fov[0], fov[1], fov[2], file])
                else :
                    selected_fovs.append([fov[0], fov[1], fov[2], file])
        return selected_fovs

    def get_geojson_geometry(self, lines = None, fors = None, fovs = None, selected_files = None):
        """
            This method create fovs circle as GeoJSON multiPolygons

            :param: lines : list(<int>)
            :param: fors : list(<int>)
            :param: fovs : list(<int>)
            :param: selected_files : list(<str>)

            :return: features : dict()  
        """
        if not lines and not fors and not fovs and not selected_files:
                selected_df = self.df
        else:
            selected_df = self.mask(lines, fors, fovs, selected_files)
            
        if self.isENG:
            features = [
                    {
                    'type': 'Feature',
                    'geometry': {
                        'type': 'MultiPolygon',
                        'coordinates': [[coords + [coords[0]] if coords[0] != coords[-1] else coords]]
                    }
                }
                for coords in selected_df['Coordinates'] if coords and coords == coords]
            return features
        else :
            print("ERROR: No ENG file. Please make sure to upload the corresponding file.")
            return None

    def get_spectra_data(self, fovs, selected_spectra, eng = True):
        """
            This method get data from products to plot spectra graphs.
            If needed, subtract spectra

            :param: fovs : list(list(<int>)) : Selected fov 
            :param: selected_spectra : list(<str>) : selected spectra for the subtraction
            :param: eng : bool : True = data from ENG file ; False = data from RAD file
            :param: spectra_df : pandas.DataFrame() :  Contains spectra data for each fov
        """

        spc = {'Fov index': [], 'Wave number': [], 'Wavelength' : [], 'Frequency' : [], 'Radiance': [], 'Color' : []}
        for fov in fovs:
            if tuple(fov) in spc["Fov index"]:
                continue
            # Get the correct product from file number of fov
            acq_id = self.file_index_to_prod[fov[3]]
            l1c_product =  self.all_products[acq_id]['L1C-ENG'] if eng else self.all_products[acq_id]['L1C-RAD']
            if not l1c_product:
                print(f"ERROR: No {'ENG' if eng else 'RAD'} file for acquisiton time {self.all_products[acq_id]['Acquisition time']}. Please make sure to upload the corresponding file.")
                continue
            spectrum = l1c_product._get_spectrum_from_fov(n_line=fov[0], n_for=fov[1], n_fov=fov[2])
            spc["Fov index"] += (tuple([fov[3]] + fov[:3]) for i in range(len(spectrum["Wave_number"])))
            spc["Wave number"] += list(spectrum["Wave_number"])
            spc["Wavelength"] += (1/wave_number for wave_number in list(spectrum["Wave_number"]))
            spc["Frequency"] += (SPEED_OF_LIGHT*wave_number for wave_number in list(spectrum["Wave_number"]))
            spc["Radiance"] += list(spectrum["Radiance"])
            # The column 'Color' is only for the displayed legend of the spectrum graph  
            spc["Color"] +=  (f"File: {fov[3]+1},({fov[0]+1},{fov[1]+1},{fov[2]+1})" for i in range(len(spectrum["Wave_number"]))) # Add +1 to start at 1 only on display

        spectra_df = pd.DataFrame(spc, columns=['Fov index', 'Wave number', 'Wavelength', 'Frequency', 'Radiance', 'Color'])

        if selected_spectra and len(selected_spectra) > 1 :
            result_df = self._subtract_spectra(spectra_df, selected_spectra)
            spectra_df = pd.concat([spectra_df, result_df], axis=0)

        # Save spectra as class attributes
        if eng:
            self.spectra_eng_df = spectra_df
        else :
            self.spectra_rad_df = spectra_df

        return spectra_df


    # Subtract selected spectra on the graph   
    def _subtract_spectra(self, spc_df, selected_spectra) :

        spc_calcul = {} # Contains the absportion value of each selected point.
        # Get the absporption value of each selected point on the map. The values are multiplies by -1 except for the first selected point_index. 
        for point_index in selected_spectra : 
            try :
                if spc_calcul == {} :  
                    spc_calcul[point_index] = spc_df[spc_df.apply(lambda x: str(x["Fov index"]) == point_index, axis=1)].Radiance.values
                else : 
                    spc_calcul[point_index] = spc_df[spc_df.apply(lambda x: str(x["Fov index"]) == point_index, axis=1)].Radiance.values * -1
            except Exception as e:
                print(e)
                continue

        # Delete fov with no values 
        deleted_keys = [] 
        for key in spc_calcul:
            if len(spc_calcul[key]) == 0:
                  deleted_keys.append(key)
        for key in deleted_keys: 
            del spc_calcul[key]

        # If there is only one spectrum avaible for subtraction 
        if len(spc_calcul) <= 1:
            return None

        spc_df_calcul = pd.DataFrame(spc_calcul).fillna(0)
        spc_df_calcul['Result'] = spc_df_calcul.sum(axis = 1) # subtraction

        # Create a new dataframe for the concatenation with spc_df  
        wave_numbers = spc_df['Wave number'].unique()
        result = {"Fov index" : ["Result" for _ in spc_df_calcul.Result] , 
        "Radiance" : spc_df_calcul.Result.values,
        "Wave number" : wave_numbers,
        "Wavelength" : (1/wave_number for wave_number in wave_numbers),
        "Frequency" : (SPEED_OF_LIGHT*wave_number for wave_number in wave_numbers),
        "Color" : ["Result" for _ in spc_df_calcul.Result]}

        result_df = pd.DataFrame(result)

        return result_df

    def export_spectra_as_csv(self):
        """
            This method create two csv files with spectra data at data/iasing_spectra
            One file for imaginary spectra and an other for real spectra
        """
        # Create the folder  
        folder_path = os.path.join(DATA_FOLDER_PATH,"iasing_spectra")
        if not os.path.isdir(folder_path):
            os.makedirs(folder_path)

        # Export eng spectra 
        file_name = "spectrum_eng.csv"
        file_path =  os.path.join(folder_path,file_name)
        self.spectra_eng_df.to_csv(file_path, sep = CSV_SEPARATOR, index=False)

        # Export rad spectra 
        file_name = "spectrum_rad.csv" 
        file_path =  os.path.join(folder_path,file_name)
        self.spectra_rad_df.to_csv(file_path, sep = CSV_SEPARATOR, index=False)

        print(f"INFO : Spectra saved in {file_path}")

    def get_flag_details(self, fovs):
        """
            This method return the flags details as records
            :param: fovs : list(list(<int>))
            :return : records_flags : list(dict())
        """
        records_flags = []
        for fov in fovs:
            flg_dict = {'File': fov[3], 'Line': fov[0], 'For' : fov[1], 'Fov' : fov[2]}
            # Get the correct dimension sizes from file number of fov
            acq_id = self.file_index_to_prod[fov[3]]
            l1c_prod = self.all_products[acq_id]['L1C-ENG'] if self.all_products[acq_id]['L1C-ENG'] else self.all_products[acq_id]['L1C-RAD']
            # Add the detailed flag of the fov to the dictionary
            flg_dict.update(l1c_prod.get_flag_str_from_fov(nline = fov[0], nfor = fov[1], nfov=fov[2],
                                                           flags_str_values = self.all_flags_str_dicts[acq_id]))
            records_flags.append(flg_dict)
        return records_flags

    # Return variables to add to the variables table as records
    # (Maybe this method could be simpilify and optimize using DataManager attributes and method ?) 
    def get_add_vars(self, fovs, paths_list):
        """
            This method return variables to add to the variables table as records

            :param: fovs : list(list(<int>))
            :param: paths_list : list(<str>)
            :return: dict()
        """
        dict_vars = {"File": [], "Fov_index": [], 'Line': [], 'For' : [], 'Fov' : []}
        if not paths_list:
            return
        for path in paths_list:
            # Create a new column for each variable (with only its name, not full path)
            dict_vars[pu.get_last_element_in_path(path)[0]] = []
            for fov in fovs:
                 # Get the correct product from file number of fov
                rad_product =  self.all_products[self.file_index_to_prod[fov[3]]]['L1C-RAD']
                if not rad_product:
                    print(f"ERROR: No RAD file for acquisiton time {self.all_products[self.file_index_to_prod[fov[3]]]['Acquisition time']}. Please make sure to upload the corresponding file.")
                    continue
                var = rad_product.extract_var(path)
                # Fill columns for fov identification (will only do it for the first path)
                if not tuple(fov) in dict_vars["Fov_index"] :
                    dict_vars["Fov_index"].append(tuple(fov))
                    dict_vars["File"].append(fov[3])
                    dict_vars["Line"].append(fov[0])
                    dict_vars["For"].append(fov[1])
                    dict_vars["Fov"].append(fov[2])
                # Add value of variable to the variable column, for each fov
                dict_vars[pu.get_last_element_in_path(path)[0]].append(var.get_value_by_dim({rad_product.N_LINES_DIM: fov[0], rad_product.N_FORS_DIM: fov[1], rad_product.N_FOVS_DIM: fov[2]}))
        dict_vars.pop("Fov_index", None)

        return  pd.DataFrame(dict_vars).to_dict("records")

    def get_zpd(self):
        """
            This method get zpd data from products
            :return: (pandas.DataFrame(), pandas.DataFrame(), pandas.DataFrame())
        """
        granules = {"Acquisition Time": [], "Mean": [], "Min": [], "Max": []}
        # Get the min, max and mean for each file
        for acq_id, eng_product in self.eng_products.items():
            zpd = eng_product.extract_var(eng_product.ZPD_PATH)
            granules["Mean"] += [zpd.get_mean(axis=(0, 1))] # mean along axis (0, 1), i.e. (n_lines, n_for), per n_laser
            granules["Min"] += [zpd.get_min(axis=(0, 1))]
            granules["Max"] += [zpd.get_max(axis=(0, 1))]
            granules['Acquisition Time'] += ([acq_id] * len(granules["Mean"][0]))
        granules_df_mean = pd.DataFrame(granules["Mean"],
                            columns=[f"Laser {j+1}" for j in range(len(granules["Mean"][0]))],
                            index=granules['Acquisition Time'])
        granules_df_min = pd.DataFrame(granules["Min"],
                            columns=[f"Laser {j+1}" for j in range(len(granules["Min"][0]))],
                            index=granules['Acquisition Time'])
        granules_df_max = pd.DataFrame(granules["Max"],
                            columns=[f"Laser {j+1}" for j in range(len(granules["Max"][0]))],
                            index=granules['Acquisition Time'])
        return (granules_df_mean, granules_df_min, granules_df_max)

    def get_nzpd(self): 
        """
            This method get nzpd data from product
            :return: nzpd_df_mean : padans.DataFrame() 
        """
        nzpd_df = pd.DataFrame()
        for acq_id, ods_product in self.ods_products.items():
            nzpd_df_i = pd.DataFrame({"NZPD": ods_product.extract_var(l0product.IASING_L0_ODS.NZPD_PATH).get_data().flatten(),
                                        "DIRECTION": ods_product.extract_var(l0product.IASING_L0_ODS.MDE_IFM_CNT_PATH).get_data().flatten()})
            nzpd_df_i["Acquisition Time"] = acq_id
            nzpd_df = pd.concat([nzpd_df, nzpd_df_i], ignore_index=True)
        nzpd_df_mean = nzpd_df.groupby(["DIRECTION", "Acquisition Time"]).mean().reset_index()
        return nzpd_df_mean

    def get_general_quality_flags_ratio(self): 
        """
            This method get ratio for all flags, per file
            :return : df_ratio : pandas.DataFrame() 
        """
        ratio = self.df[[key for key in l1cproduct.AbstractIASING_L1C.FLAG_DOC if "subtype" not in key] + ['File index']].astype(int).groupby(['File index']).mean()
        df_ratio = ratio.reset_index()
        df_ratio["Acquisition Time"] = df_ratio.apply(lambda row: self.file_index_to_prod[row['File index']], axis = 1)
        df_ratio.sort_values("Acquisition Time")
        return df_ratio

    def get_spike_flags_ratio(self):
        """
            This method get spike flags ration from l0 product
            :return: df_ration : pandas.DataFrame()
        """
        spks = {band: [] for band in l0product.IASING_L0_ODS.SPIKE_FLAG_PATHS}
        spks["Acquisition Time"] = []
        for acq_id, ods_product in self.ods_products.items():
            spks["Acquisition Time"].append(acq_id)
            for band in l0product.IASING_L0_ODS.SPIKE_FLAG_PATHS:
                # mean along axis (0, 1, 2), i.e. respectively (n_fov, n_fovr, n_lines)
                spks[band].append(ods_product.extract_var(l0product.IASING_L0_ODS.SPIKE_FLAG_PATHS[band]).get_mean(axis=(0, 1, 2)))
        df_ratio = pd.DataFrame(spks)
        return df_ratio
    
    def get_l1c_or_l0_variables_mean(self, product_name: str, var_path, dim_names = [] , remaining_dim = ""):
        """
            This method get the mean of a variable from l1c or l0 product

            :param: product_name : srt : Three choices ODS or L1C-RAD or L1C-ENG
            :param: var_path : str : Path of the variable
            :param: dim_names : list(<str>) : list of all dimensions ofthe variable
            :param: remaining_dim : str : name of previously selected dimension 
        """
        if not dim_names and not remaining_dim:
            means = {'Acquisition Time': [], 'Mean':[]}

            for i in self.all_products:
                product = self.all_products[i][product_name]
                if not product:
                    continue
                means['Acquisition Time'].append(i)
                means['Mean'].append(product.extract_var(var_path).get_mean(axis = None))
            df_means = pd.DataFrame(means).sort_values("Acquisition Time")
            return df_means

        else : 
            means = []

            for i in self.all_products:
                product = self.all_products[i][product_name]
                if not product:
                    continue
                mean_i = np.array(product.extract_var(var_path).get_mean(axis=tuple(dim_names))).flatten()
                data = {'Acquisition Time': [i] * mean_i.size, 'Mean': list(mean_i)}
                data[remaining_dim] = list(np.arange(mean_i.size))
                df_i = pd.DataFrame(data)
                means.append(df_i)

            df_means = pd.concat(means, ignore_index=True).sort_values("Acquisition Time").sort_values(remaining_dim)

            return df_means

if __name__ == '__main__':
    pass