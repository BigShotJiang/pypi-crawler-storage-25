# Copyright (c) 2024-2026 Centre National d'Etudes Spatiales (CNES).
#
# This file is part of AtmoTools
# (see https://github.com/CNES/AtmoTools).
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

import plotly.express as px
import pandas as pd

import atmotools.utils.time_utils as tu
import atmotools.missions.IASI_NG.models.iasing_l1c_product as l1cproduct
from atmotools.missions.IASI_NG.config import UNITS, MAP_STYLE, FOV_COLOR

def show_scatter_on_map(df, features, selected_flag, show_circles):
    """
        This function create a map with scatter point.
        :param: df : pd.DataFrame : The dataframe with all coordinates of all fovs
        :param: features : dict() : GeoJSON of all fovs circle
        :param: selected_flag : str : Name of the selected flag
        :param: show_circle :  str : Value of the checklist
    """

    flag_color = None if selected_flag == "No flag" else selected_flag
    
    fig = px.scatter_map(df, lat="Latitude", lon="Longitude", hover_name=df["Fov index"].map(lambda x:[x[0]+1, x[1]+1, x[2]+1]), # In hover_name add +1 to star the display at 1 instead of 0  
                                 hover_data={"file" : df["File name"],
                                    "Acq time" : df["File acq_id"].map(lambda x: tu.convert_date(x.split("_")[0])) ,
                                    "Prod time" : df["File acq_id"].map(lambda x: tu.convert_date(x.split("_")[2])) ,
                                    "File" : df["File index"].map(lambda x: x+1), # Add +1 to start at 1 only on display
                                    # Add 1 to start at 1 instead of 0 in the tool
                                     "line" : df["Fov index"].map(lambda x: x[0]+1),
                                     "for" : df["Fov index"].map(lambda x: x[1]+1),
                                     "fov" : df["Fov index"].map(lambda x: x[2]+1)},
                                zoom = 4,
                                center = {"lat": df["Latitude"].median(), "lon": df["Longitude"].median()},
                                color = flag_color,
                                color_discrete_map={0: "forestgreen", 1: "red"},
                                height=800, width = 900)
    # Add the fov circles if the option is checked
    fig.update_layout(margin={"r":0,"t":0,"l":0,"b":0},
            uirevision=str(selected_flag),
            clickmode='event+select',
            map_style=MAP_STYLE,
            legend=dict(
                        yanchor="top",
                        y=0.99,
                        xanchor="right",
                        x=0.99),
            map = {'style': MAP_STYLE,
                'layers' : [{
                    'source': {
                        'type': "FeatureCollection",
                        'features': features
                        }
                        ,
                        'type': "line", 'below': "traces", 'color': FOV_COLOR, 'opacity' : 0.45
                        }] if show_circles else None
                })

    return fig


def show_spectrum(spc_df, unit_selected, eng = True, ):
    """
        This function return the figure with the spectrum (real or imaginary) for all selected fovs

        :param: spc_df : pandas_DataFrame() : Data of the spectra
        :param: unit_selected : str : Name of the selected unit for the x-axis
        :param: eng : bool : True = data from ENG file ; False = data from RAD file
        :return: fig : plotly.figure : Plot of the spectrum
    """
    # Create spectrum graph 
    fig = px.line(spc_df, x=unit_selected, y='Radiance', color = 'Color', title= 'Imaginary part of spectrum' if eng else 'Real part of spectrum', height=400)
    fig.update_layout(xaxis = dict(title = dict(text = f"{unit_selected} {UNITS[unit_selected]}")), yaxis = dict(title = dict(text = "Radiance (W/m²/sr/m-1)")))

    return fig

def show_empty_spectrum(title: str):
    empty_df = pd.DataFrame(columns = ["Fov_index", "Wave_number", "Radiance"])
    return (px.line(empty_df, x='Wave_number', y='Radiance', color = 'Fov_index', title= title, height = 400))

def show_empty_map():
    return (px.scatter_map(data_frame = pd.DataFrame({"lat": [None],"lon": [None]}), lat = "lat", lon = "lon",
                                        center={"lat": 43.6048, "lon": 1.4428}, zoom = 6, height=800, width = 900))

def show_zpd(granules_df, title : str):
    fig = px.line(granules_df,
                        x=granules_df.index, 
                        y=granules_df.columns,
                        title= title, 
                        height=400)
    fig.update_layout(xaxis=dict(title=dict(text="Acquisition Time")), 
                            yaxis=dict(title=dict(text=title.split(" ")[0])), 
                            legend=dict(title=dict(text="Laser")))
    return fig

def show_nzpd(nzpd_df):
    fig = px.line(nzpd_df, 
                x = 'Acquisition Time', 
                y = "NZPD", color='DIRECTION', 
                labels = {'Acquisition Time': "Acquisition Time", 'NZPD': 'Mean NZPD', 'DIRECTION': 'Direction'},
                title= 'Mean NZPD along orbit for each direction', 
                height=400)
    return fig

def show_general_quality_flags_ratio(df_ratio):
    fig = px.line(df_ratio, 
                    x = "Acquisition Time", 
                    y = [key for key in l1cproduct.AbstractIASING_L1C.FLAG_DOC if "subtype" not in key],
                    title= 'Ratio of each bit of the General Quality Flag along orbit', 
                    height=400)
    fig.update_layout(yaxis = dict(title = dict(text = "Ratio")), 
                    legend=dict(title=dict(text="Bits")))

    return fig

def show_spike_flags_ratio(df_ratio):
    fig = px.line(df_ratio, 
                    y = [col for col in df_ratio.columns if col != "Acquisition Time"], 
                    x = "Acquisition Time",
                    title= 'Ratio of Spike along orbit for each band', 
                    height=400)
    fig.update_layout(yaxis = dict(title = dict(text = "Ratio")), 
                    legend=dict(title=dict(text="Band")))

    return fig

def show_variable_mean(df_means, title: str, color = None):
    fig = px.line(df_means, 
                    x = 'Acquisition Time', 
                    y = 'Mean',
                    color = color,
                    title= title, 
                    height=400)
    return fig

if __name__ == '__main__':
    pass