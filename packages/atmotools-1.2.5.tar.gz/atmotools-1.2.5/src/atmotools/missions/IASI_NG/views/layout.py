# Copyright (c) 2024-2026 Centre National d'Etudes Spatiales (CNES).
#
# This file is part of AtmoTools
# (see https://github.com/CNES/AtmoTools).
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

import numpy as np

from dash import Dash, Input, Output, State, callback, dcc, html, dash_table
import atmotools.utils.path_utils as pu
import atmotools.utils.time_utils as tu

def create_layout(data) :

    return html.Div([
            # Dropdown to choose the displayed files.
                html.Div([
                    dcc.Dropdown([dict(label = f"{tu.convert_date(x.split('_')[0])} // Product time : {tu.convert_date(x.split('_')[2])} File : {np.where(data.df['File acq_id'].unique() == x)[0][0] +1} ",value = x) for x in data.df['File acq_id'].unique()] if (data.isENG or data.isRAD) else [""],
                    multi=True, id = "selected_file", placeholder="File selection", disabled=not (data.isENG or data.isRAD))
                ],style = {'marginBottom': '10px', 'width' : '100%'}),
            html.Div([
                # Map with fovs
                html.Div([
                    dcc.Graph(id="fov_map")],
                    style={
                    'flexShrink': 0
                            }
                    ),
                # Display choices next to map
                html.Div([
                    # Checklist for fov circles displays
                    html.Div([
                        dcc.Checklist(id="show-circles", options = ["Display fov circles"])
                        ],
                        style = {"marginBottom": "30px"} if data.isENG else {"marginBottom": "30px", "pointerEvents": "none", "opacity": 0.5}),
                    # Radio Button to choose the flag to display on the map
                    html.Div([
                        dcc.RadioItems(id="flag-radio", value = "No flag" if data.isRAD or data.isENG else None,
                                       options = ["No flag"] \
                                                    + [list(data.all_flags_int_dicts[list(data.all_flags_int_dicts.keys())[0]].keys())[-1]] \
                                                    + list(data.all_flags_int_dicts[list(data.all_flags_int_dicts.keys())[0]].keys())[:-1] if data.isRAD or data.isENG else ["No flag"])
                        ],
                        style = {"pointerEvents": "none", "opacity": 0.5} if not (data.isRAD or data.isENG) else None),
                    # Checklist for additional L1C statistics display
                    html.Div([
                        dcc.Checklist(id="ratio-checklist-L1CENG", options={"zpd": "ZPD Mean", "gq": "GQual Flag Ratio"})
                        ],
                        style = {"marginTop": '50px'} if data.isENG else {"marginTop": '50px', "pointerEvents": "none", "opacity": 0.5}),
                    # Checklist for additional ODS statistics display
                    html.Div([
                        dcc.Checklist(id="ratio-checklist-L0", options={"spk": "Spike Flag Ratio", "std": "NZPD Mean"})
                        ],
                        style = {"pointerEvents": "none", "opacity": 0.5} if not data.isODS else None),
                    # Checklist for Geotiff display 
                    html.Div([
                        html.Button('Load Geotiff', id="geotiff-button", n_clicks=0),
                        dcc.Checklist(id="save-geotiff-checklist", options=['Save Geotiff'])
                        ],
                        style = {"marginTop": '50px'} if data.isENG else {"marginTop": '50px', "pointerEvents": "none", "opacity": 0.5}),
                    ],
                    style={
                        'padding': 20,
                        'flexShrink': 0
                            }),

                html.Div([
                    # Dropdown menus to choose lines, fors and fovs to show on the map
                    html.Div([
                       # List of Dict for the dropdown option :  options={label = index+1 : value = index}
                       # Add +1 to start at 1 only on display
                        dcc.Dropdown(
                            [dict(label = x+1,value = x) for x in data.df['Fov index'].map(lambda x: x[0]).unique()] if (data.isENG or data.isRAD) else [""],
                            multi=True, id = "line_selection", placeholder="Line", disabled=not (data.isENG or data.isRAD)),
                        dcc.Dropdown(
                            [dict(label = x+1,value = x) for x in data.df['Fov index'].map(lambda x: x[1]).unique()]  if (data.isENG or data.isRAD) else [""],
                            multi=True, id = "for_selection", placeholder="For", disabled=not (data.isENG or data.isRAD)),
                        dcc.Dropdown(
                            [dict(label = x+1,value = x) for x in data.df['Fov index'].map(lambda x: x[2]).unique()]  if (data.isENG or data.isRAD) else [""],
                            multi=True, id = "fov_selection", placeholder="Fov", disabled=not (data.isENG or data.isRAD)),
                            ],
                        style = {'marginBottom': '30px'}
                        ),
                    # Dropdown menu to choose which additional L1C variables along fov dimensions to display in the variables table
                    html.Div([
                        dcc.Dropdown(
                            {path : pu.get_last_element_in_path(path)[0] for path in data.var_paths} if data.isRAD else [""],
                            multi=True, id = "var_selection", placeholder="Variables", disabled=not data.isRAD),
                        ],
                        style = {'flexShrink': 0,
                                'width' : 150,
                                }
                        )
                    ],
                    style={'display': 'flex',
                        'flexDirection': 'column',
                        'padding' : 20,
                        # 'flexGrow': 1
                        }),

                # Graphs for the spectrums
                html.Div([
                    html.Div([
                        # Dropdown to choose spectrum for spectrum substration
                        dcc.Dropdown(id = 'spectrum_fov_selection', placeholder = 'Spectrum substraction selector', multi=True)],
                        style = None),
                    html.Div([
                        dcc.Graph(id="spectrum"),
                        # Dropdown to change unit and convert x-axis data 
                        dcc.Dropdown(
                            options = [
                                {'label': 'Wave number', 'value': 'Wave number'}, 
                                {'label': 'Frequency', 'value': 'Frequency'},
                                {'label': 'Wavelength', 'value': 'Wavelength'}
                            ] 
                            ,value = 'Wave number',id = 'unit_selection')],
                            style = None if data.isENG else {"pointerEvents": "none", "opacity": 0.5}),
                    html.Div([
                        dcc.Graph(id="spectrum-rad"),
                        dcc.Dropdown(
                            options = [
                                {'label': 'Wave number', 'value': 'Wave number'}, 
                                {'label': 'Frequency', 'value': 'Frequency'},
                                {'label': 'Wavelength', 'value': 'Wavelength'}
                            ] 
                            ,value = 'Wave number',id = 'unit_rad_selection')],
                            style = None if data.isRAD else {"pointerEvents": "none", "opacity": 0.5}),
                    # Bouton to save spectrum to .csv format 
                    html.Div([
                        html.Button('Save as .csv', id="save-spectrum-button", n_clicks=0),
                        ],
                        style = {"marginTop": '50px'} if data.isENG else {"marginTop": '50px', "pointerEvents": "none", "opacity": 0.5}),
                    ],
                    style={
                        'flexShrink': 0,
                        'width' : 550,
                        'flexGrow': 1
                        }),

            ], style={
            'display': 'flex',
            'flexDirection': 'row',
            'alignItems': 'flex-start',
                }  ),
        html.Div([],
            id="geotiff-map",
            style={
                'padding': 50,
                'marginTop': '20px',
            }),
        # Panel underneath the rest
        html.Div([
            # Table of flags detail
            html.Div([ "Flags description: " if (data.isENG or data.isRAD) else None,
                dash_table.DataTable(
                    id="flag-tbl",
                    fixed_columns={'headers': True, 'data': 4},
                    style_table={'overflowX': 'auto','maxWidth': '100%'},
                    style_cell_conditional=[
                    {'if': {'column_id': 'File'}, 'width': '40px'},
                    {'if': {'column_id': 'Line'}, 'width': '35px'},
                    {'if': {'column_id': 'For'}, 'width': '30px'},
                    {'if': {'column_id': 'Fov'}, 'width': '30px'}]
                    )],
                style = {'marginBottom' : '30px'}),

            # Table with additional L1C variables along fov dimensions
            "Other Variables: " if data.isRAD else None,
            dash_table.DataTable(
                id="tbl",
                fixed_columns={'headers': True, 'data': 4},
                style_table={'overflowX': 'auto','maxWidth': '100%'},
                style_cell_conditional=[
                {'if': {'column_id': 'File'}, 'width': '40px'},
                {'if': {'column_id': 'Line'}, 'width': '35px'},
                {'if': {'column_id': 'For'}, 'width': '30px'},
                {'if': {'column_id': 'Fov'}, 'width': '30px'}]
                )],
            style={
            'padding': 50,
            'marginTop': '20px',
            }),

        # Additional statistics graphs from checklists
        html.Div(id="ratio-graphs",
            style={
                'display': 'flex',
                'flexDirection': 'row',
                'alignItems': 'flex-start',
                'flexWrap': 'wrap',
                # 'justifyContent': 'flex-start'
            }),

    html.Div([
        # Dropdown menus to choose a variable from L1C RAD files to display on graphs
        html.Div([
            dcc.Dropdown(
                options = {path : pu.get_last_element_in_path(path)[0]
                           for path in list(data.all_vars_rad.keys()) if list(data.all_vars_rad[path]["dimensions"].keys()) != []} if data.isRAD else [""],
                multi=False, id = "var_selection_mean", placeholder="L1C RAD Variables", disabled=not data.isRAD),
                ],
            style = {'marginRight': '30px', 'width' : 200}
            ),
        # Dropdown menus to choose the dimension(s) of the variable along which to plot the means
        html.Div([
            dcc.Dropdown(
                multi=True, id = "dim_selection_mean", placeholder="Dimensions", disabled=True),
                ],
            style = {'width' : 150}
            ),
        # Graphs for the L1C means
        html.Div(id = "mean_graphs",
            style={
                'display': 'flex',
                'flexDirection': 'row',
                'alignItems': 'flex-start',
                'flexWrap': 'wrap'
                }
            )],

        style={'display': 'flex',
            'flexDirection': 'row',
            'padding' : 20,
            # 'flexGrow': 1
            }),

    html.Div([
        # Dropdown menus to choose a variable from ODS files to display on graphs
        html.Div([
            dcc.Dropdown(
                options = {path : pu.get_last_element_in_path(path)[0]
                           for path in list(data.all_vars_ods.keys()) if list(data.all_vars_ods[path]["dimensions"].keys()) != []} if data.isODS else [""],
                multi=False, id = "var_selection_mean_l0", placeholder="L0 ODS Variables", disabled=not data.isODS),
                ],
            style = {'marginRight': '30px', 'width' : 200}
            ),
        # Dropdown menus to choose the dimension(s) of the variable along which to plot the means
        html.Div([
            dcc.Dropdown(
                multi=True, id = "dim_selection_mean_l0", placeholder="Dimensions", disabled=True),
                ],
            style = {'width' : 150}
            ),
        # Graphs for the ODS means
        html.Div(id = "mean_graphs_l0",
            style={
                'display': 'flex',
                'flexDirection': 'row',
                'alignItems': 'flex-start',
                'flexWrap': 'wrap'
                }
            )],

        style={'display': 'flex',
            'flexDirection': 'row',
            'padding' : 20,
            # 'flexGrow': 1
            }),
    ],
    style={
        'display': 'flex',
        'flexDirection': 'column'
    })

if __name__ == '__main__':
    pass