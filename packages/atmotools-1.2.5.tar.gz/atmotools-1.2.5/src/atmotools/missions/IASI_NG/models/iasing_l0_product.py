# Copyright (c) 2024-2026 Centre National d'Etudes Spatiales (CNES).
#
# This file is part of AtmoTools
# (see https://github.com/CNES/AtmoTools).
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

from abc import ABC, abstractmethod
import atmotools.utils.hdf_netcdf_tools as hdfu
import atmotools.utils.path_utils as pu
import pandas as pd
import numpy as np

# ===========================
# CLASSES
# ===========================

class IASING_L0():
    """This class enables to open a IASI-NG L0 product and extract its data

    Attributes:
        file_path(str): path of the L0 file
        reader: file reader
    """

    def __init__(self, file_path: str, useXarray = False) -> None:
        """
        Initialize the class attributes.

        :param: file_path: the file path of the IASI-NG L0 product
        :param: useXarray: if set to True, the product reader will use the xarray library instead of netcdf.
        """
        self.file_path = file_path
        self.reader = hdfu.createReader(file_path, useXarray=useXarray)

    def get_file_path(self) -> str:
        """
        Return the file path of the product.

        :return: file path
        """
        return self.file_path

    def get_reader(self) -> hdfu.AbstractHDFReader:
        """
        Return the reader corresponding to the product

        :return: the product reader
        """
        return self.reader

    def get_file_name(self) -> str:
        """
        Extract the file name of the product from its file path.

        :return: file name
        """
        return pu.get_last_element_in_path(self.get_file_path())[0]

    @abstractmethod
    def _get_acquisition_id(self) -> str:
        """
        Extract the acquisition id of the product from its file path.

        :return: file name
        """
        pass

    @abstractmethod
    def _get_product_level(self) -> str:
        """
        Extract the level of the product from its file path.

        :return: file name
        """
        pass

    def extract_var(self, var_path) -> hdfu.HDFVariable:
        """
        Return the HDFVariable corresponding to a given variable path

        :param: var_path: path of the variable to extract
        :return: corresponding variable
        """
        return self.get_reader().get_var(var_path)


class IASING_L0_ODS(IASING_L0):

    """This class enables to open a IASI-NG L0 ODS product and extract its data

    Attributes:
        file_path(str): path of the L0 file
        reader: file reader
    """
    N_BANDS = 4
    # Paths of variables
    SPIKE_FLAG_PATHS = {}
    for i in range(N_BANDS):
        SPIKE_FLAG_PATHS[f"band {i}"] = f"/data/measurement_data/packet_headers/ancillary_specific_header/b{i+1}_spike_cnt"
    NZPD_PATH = "/data/calibration_data/nzpd/nzpd"
    MDE_IFM_CNT_PATH = "/data/measurement_data/MDE_IFM_CNT"

    def __init__(self, file_path: str, useXarray = False) -> None:
        """
        Initialize the class attributes.

        :param: file_path: the file path of the IASI-NG L0 product
        :param: useXarray: if set to True, the product reader will use the xarray library instead of netcdf.
        """
        super().__init__(file_path=file_path, useXarray=useXarray)
        if self._get_product_level() != "ODS":
            raise f"ERROR: {self.file_path} is not an L0 ODS file."

    def _get_product_level(self) -> str:
        """
        Extract the level of the product from its file path.

        :return: file name
        """
        return self.get_file_name()[5:8]

    def _get_acquisition_id(self) -> str:
        """
        Extract the acquisition id of the product from its file path.

        :return: file name
        """
        return self.get_file_name()[21:35] + "_" + self.get_file_name()[38:52] + "_" + self.get_file_name()[55:67]+ "00" #Product date rounded to the nearest minute


