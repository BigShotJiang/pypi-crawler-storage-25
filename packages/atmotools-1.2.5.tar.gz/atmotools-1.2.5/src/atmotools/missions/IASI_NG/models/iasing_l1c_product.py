# Copyright (c) 2024-2026 Centre National d'Etudes Spatiales (CNES).
#
# This file is part of AtmoTools
# (see https://github.com/CNES/AtmoTools).
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

from abc import ABC, abstractmethod
import atmotools.utils.hdf_netcdf_tools as hdfu
import atmotools.utils.path_utils as pu
import pandas as pd
import numpy as np
import atmotools.utils.flag_utils as flagu

# ===========================
# CLASSES
# ===========================

class AbstractIASING_L1C(ABC):
    """
    Abstract class to open a IASI-NG L1C product and extract its data

    Attributes:
        file_path(str): path of the L1C file
        reader: file reader
    """
    # Names of dimensions
    N_LINES_DIM = "n_lines"
    N_FORS_DIM = "n_for"
    N_FOVS_DIM = "n_fov"
    N_WN_DIM = "n_wn"
    # Paths of variables
    WN_PATH = "/data/measurement_data/wn"
    GENERAL_QUALITY_FLAGS_PATH = "/data/quality_information/general_quality_flags"
    # Documentation {name: (bit number, bit size)} of each part of FLAG_TO_SHOW_PATH
    FLAG_DOC = {
                "Bit 0: general quality" : (0, 1),
                "Bit 1: general sounder quality band1" : (1, 1),
                "Bit 2: general sounder quality band2" : (2, 1),
                "Bit 3: general sounder quality band3" : (3, 1),
                "Bit 4: general sounder quality band4" : (4, 1),
                "Bit 5: sounder radiometric" : (5, 1),
                "Bit 6: sounder spectral" : (6, 1),
                "Bit 7: imager geometric" : (7, 1),
                "Bit 8: imager classification" : (8, 1),
                "Bit 9: imager radiometric" : (9, 1),
                "Bit 10: presence of mathematical errors" : (10, 1),
                "Bit 11: TM data missing" : (11, 1),
                "Bit 12: TM data corrupted" : (12, 1),
                "Bit 13: TM integrity instrument" : (13, 1),
                "Bit 14: TM in OPER-EXTCAL" : (14, 1)
                }
    FLAG_COUNT_KEY = "Bit 0: general quality"
    # Detailed documentation {name : [ {value: physical meaning of the value}, bit number of parent flag (if applicable) ] } of each part of FLAG_TO_SHOW_PATH
    FLAG_DOC_DETAILS = {
                "Bit 0: general quality" :  [ {0: "ok", 1: "nok"}, None ],
                "Bit 1: general sounder quality band1" :  [ {0: "ok", 1: "nok"}, None ],
                "Bit 2: general sounder quality band2" :  [ {0: "ok", 1: "nok"}, None ],
                "Bit 3: general sounder quality band3" :  [ {0: "ok", 1: "nok"}, None ],
                "Bit 4: general sounder quality band4" :  [ {0: "ok", 1: "nok"}, None ],
                "Bit 5: sounder radiometric" :  [ {0: "ok", 1: "nok"}, None ],
                "Bit 6: sounder spectral" :  [ {0: "ok", 1: "nok"}, None ],
                "Bit 7: imager geometric" :  [ {0: "ok", 1: "nok"}, None ],
                "Bit 8: imager classification" :  [ {0: "ok", 1: "nok"}, None ],
                "Bit 9: imager radiometric" :  [ {0: "ok", 1: "nok"}, None ],
                "Bit 10: presence of mathematical errors" :  [ {0: "ok", 1: "nok"}, None ],
                "Bit 11: TM data missing" :  [ {0: "ok", 1: "nok"}, None ],
                "Bit 12: TM data corrupted" :  [ {0: "ok", 1: "nok"}, None ],
                "Bit 13: TM integrity instrument" :  [ {0: "ok", 1: "nok"}, None ],
                "Bit 14: TM in OPER-EXTCAL" :  [ {0: "ok", 1: "nok"}, None ]
                }
    # Number of bits for the general quality flag
    N_BITS = 15
    # # Fill Value of variable "Latitude" in file
    # LAT_FILL_VALUE = -2E9

    def __init__(self, file_path: str, useXarray = False) -> None:
        """
        Initialize the class attributes.

        :param: file_path: the file path of the IASI-NG L1C product
        :param: useXarray: if set to True, the product reader will use the xarray library instead of netcdf.
        """
        self.file_path = file_path
        self.reader = hdfu.createReader(file_path, useXarray=useXarray)

    def get_file_path(self) -> str:
        """
        Return the file path of the product.

        :return: file path
        """
        return self.file_path

    def get_reader(self) -> hdfu.AbstractHDFReader:
        """
        Return the reader corresponding to the product

        :return: the product reader
        """
        return self.reader

    def get_file_name(self) -> str:
        """
        Extract the file name of the product from its file path.

        :return: file name
        """
        return pu.get_last_element_in_path(self.get_file_path())[0]

    def get_short_file_name(self) -> str:
        """
        Extract the short file name of the product from its file path.

        :return: short file name
        """
        parsed_file_name = self.get_file_name().split("," )[2].split("_")
        name = parsed_file_name[0]      

        return (f"{name}").strip()

    def get_file_date(self) -> str:
        """
        Extract the file start date of the product from its file path.

        :return: file date YYYYMMDDhhmmss
        """
        return self.get_file_name()[51:65] 

    def get_acquisition_id(self) -> str:
        """
        Extract the acquisition id of the product from its file path.

        :return: file name
        """

        return f"{self.get_file_name()[70:99]}_{self.get_file_name()[51:63]}00" # Product date rounded to the nearest minute to correspond at the right ENG or RAD

    def get_product_level(self) -> str:
        """
        Extract the level of the product from its file path.

        :return: file name
        """
        return self.get_file_name()[37:43]

    def extract_var(self, var_path) -> hdfu.HDFVariable:
        """
        Return the HDFVariable corresponding to a given variable path

        :param: var_path: path of the variable to extract
        :return: corresponding variable
        """
        return self.get_reader().get_var(var_path)

    @abstractmethod
    def _get_spectrum_from_fov(self, n_line: int, n_for: int, n_fov: int) -> dict[list]:
        """
        Get the spectrum for a specific fov.

        :param: n_line, n_for, n_fov: line, for and fov index for the desired fov

        :return: dictionnary following the format {"Wave_number": list of wave number values, "Radiance": list of corresponding Radiance values}
        """
        pass

    @abstractmethod
    def _get_coordinates_from_fov(self, n_line: int, n_for: int, n_fov: int) -> tuple[float | list]:
        """
        Get coordinates from desired fov.

        :return: tuple (lon, lat)
        """
        pass

    @abstractmethod
    def _get_all_coordinates(self) -> pd.DataFrame:
        """
        Get coordinates for all Fovs in the product.

        :return: dataframe following the format ("Fov index"\: tuples (line, for, fov), "Longitude"\: integers, "Latitude"\: integers)
        """
        pass

    def get_flag_int_values(self) -> dict[str, list[int]]:
        """
        Return the **int** values of flags stored in variable in self.GENERAL_QUALITY_FLAGS_PATH, according to self.FLAG_DOC.
        The first bit value is replaced with the total count of flags raised.

        :return: dictionnary of the following format {"Flag 0"\: [[[count of all 1s]]], "Flag 1"\: [[[0 or 1]]], "Flag 2"\: [[[0 or 1]]], ...}
        (shape of all values = (nlines, nfors, nfovs) )
        """
        return flagu.decode_flag(reader=self.get_reader(), flag_doc = self.FLAG_DOC,
                                flag_var_path = self.GENERAL_QUALITY_FLAGS_PATH,
                                nb_bits = self.N_BITS,
                                flag_count_key = self.FLAG_COUNT_KEY,
                                transpose = False)

    def get_flag_str_values(self, flags_int_values = None) -> dict[str, list[str]]:
        """
        Return the **string** values of flags stored in variable self.GENERAL_QUALITY_FLAGS_PATH, according to self.FLAG_DOC_DETAILS

        :return: flat dictionnary of the following format {"Flag 0"\: [ok or nok], "Flag 1"\: [ok or nok], ...}
        (shape of all values = (nlines\*nfors*nfovs) )
        """
        return flagu.get_flag_as_str(flags_int_values if flags_int_values else self.get_flag_int_values(), self.FLAG_DOC_DETAILS, flag_count_key = self.FLAG_COUNT_KEY)

    def get_flag_str_from_fov(self, nline: int, nfor: int, nfov: int, flags_str_values = None) -> dict[str, str]:
        """
        Return the string flag values of a specific fov

        :param: n_line, n_for, n_fov: line, for and fov index for the desired fov
        :param: flags_str_values: result of the method get_flag_str_flags_values, or any dictionnary of the following format
        {"Flag 0"\: [ok or nok, ...], "Flag 1"\: [ok or nok, ...], ...} where values are lists of length nlines\*nfors*nfovs
        """
        dims = self.extract_var(self.GENERAL_QUALITY_FLAGS_PATH).dimensions
        ntot_fors=dims[self.N_FORS_DIM]
        ntot_fovs=dims[self.N_FOVS_DIM]
        flags_str = flags_str_values if flags_str_values else self.get_flag_str_values()
        flag = dict()
        index = nline * (ntot_fors * ntot_fovs) + nfor * ntot_fovs + nfov
        # Get the correct value of each flag for the desired fov
        for key in flags_str:
            flag[key] = flags_str[key][index]
        return flag


class IASING_L1C_RAD(AbstractIASING_L1C):
    """
    This class enables to open a IASI-NG L1C RAD product and extract its data

    Attributes:
        file_path(str): path of the L1C RAD file
        reader: file reader
    """
    # Paths of variables
    LON_PATH_RAD = "data/measurement_data/geolocation_information/sounder_pixel_longitude"
    LAT_PATH_RAD = "data/measurement_data/geolocation_information/sounder_pixel_latitude"
    SPECTRUM_PATH_REAL = "/data/measurement_data/spectrum_real"

    def __init__(self, file_path, useXarray = False):
        """
        Initialize the class attributes.

        :param: file_path: the file path of the IASI-NG L1C RAD product
        :param: useXarray: if set to True, the product reader will use the xarray library instead of netcdf.
        """
        super().__init__(file_path, useXarray = useXarray)
        if self.get_product_level() != "1C-RAD":
            raise f"ERROR: {self.file_path} is not an L1C RAD file."

    def _get_spectrum_from_fov(self, n_line: int, n_for: int, n_fov: int) -> dict[list]:
        """
        Get the spectrum for a specific fov.

        :param: n_line, n_for, n_fov: line, for and fov index for the desired fov

        :return: dictionnary following the format {"Wave_number": list of wave number values, "Radiance": list of corresponding Radiance values}
        """
        spectrum_vals = {'Wave_number': [], 'Radiance': []}
        spectrum = self.extract_var(self.SPECTRUM_PATH_REAL)
        wavenb = self.extract_var(self.WN_PATH)
        spectrum_vals["Wave_number"] = wavenb.get_data()
        spectrum_vals["Radiance"] = spectrum.get_value_by_dim({self.N_LINES_DIM: n_line, self.N_FORS_DIM: n_for, self.N_FOVS_DIM: n_fov})
        spectrum_vals["Radiance"][spectrum_vals["Radiance"] <= spectrum.get_fill_value() + 10] = np.nan
        return spectrum_vals

    def _get_coordinates_from_fov(self, n_line: int, n_for: int, n_fov: int) -> tuple:
        """
        Get coordinates from desired fov.

        :return: tuple (lon, lat)
        """
        longitude = self.extract_var(self.LON_PATH_RAD)
        latitude = self.extract_var(self.LAT_PATH_RAD)
        lon = longitude.get_value_by_dim({self.N_LINES_DIM: n_line, self.N_FORS_DIM: n_for, self.N_FOVS_DIM: n_fov})
        lat = latitude.get_value_by_dim({self.N_LINES_DIM: n_line, self.N_FORS_DIM: n_for, self.N_FOVS_DIM: n_fov})
        return (lon, lat)

    def _get_all_coordinates(self) -> pd.DataFrame:
        """
        Get coordinates for all Fovs in the product.

        :return: dataframe following the format ("Fov index"\: tuples (line, for, fov), "Longitude"\: integers, "Latitude"\: integers)
        """
        tot_lines = self.extract_var(self.LON_PATH_RAD).dimensions[self.N_LINES_DIM]
        tot_fors = self.extract_var(self.LON_PATH_RAD).dimensions[self.N_FORS_DIM]
        tot_fovs = self.extract_var(self.LON_PATH_RAD).dimensions[self.N_FOVS_DIM]
        all_centers_dict = {'Fov index': [], 'Longitude': [], 'Latitude': []}
        for line in range(tot_lines):
            for fors in range(tot_fors):
                for fov in range(tot_fovs):
                    lon, lat = self._get_coordinates_from_fov(line, fors, fov)
                    all_centers_dict['Fov index'].append([line, fors, fov])
                    all_centers_dict['Longitude'].append(lon)
                    all_centers_dict['Latitude'].append(lat)
        all_centers_df = pd.DataFrame(all_centers_dict)
        return all_centers_df



class IASING_L1C_ENG(AbstractIASING_L1C):
    """
    This class enables to open a IASI-NG L1C ENG product and extract its data

    Attributes:
        file_path(str): path of the L1C ENG file
        reader: file reader
    """
    # Name of additional dimension
    N_FORS_DIM_EV = "n_for_ev"
    # Paths of variables
    LON_PATH_ENG = "data/measurement_data/geolc_sounder_perimeter_longitude"
    LAT_PATH_ENG = "data/measurement_data/geolc_sounder_perimeter_latitude"
    SPECTRUM_PATH_IMG = "/data/measurement_data/spectrum_imaginary"
    ZPD_PATH = "/data/measurement_data/zpdme_zpd_met"

    def __init__(self, file_path, useXarray = False):
        """
        Initialize the class attributes.

        :param: file_path: the file path of the IASI-NG L1C ENG product
        :param: useXarray: if set to True, the product reader will use the xarray library instead of netcdf.
        """
        super().__init__(file_path, useXarray = useXarray)
        if self.get_product_level() != "1C-ENG":
            raise f"ERROR: {self.file_path} is not an L1C ENG file."

    def _get_spectrum_from_fov(self, n_line: int, n_for: int, n_fov: int) -> dict[list]:
        """
        Get the spectrum for a specific fov.

        :param: n_line, n_for, n_fov: line, for and fov index for the desired fov

        :return: dictionnary following the format {"Wave_number": list of wave number values, "Radiance": list of corresponding Radiance values}
        """
        spectrum_vals = {'Wave_number': [], 'Radiance': []}
        spectrum = self.extract_var(self.SPECTRUM_PATH_IMG)
        wavenb = self.extract_var(self.WN_PATH)
        spectrum_vals["Wave_number"] = wavenb.get_data()
        spectrum_vals["Radiance"] = spectrum.get_value_by_dim({self.N_LINES_DIM: n_line, self.N_FORS_DIM_EV: n_for, self.N_FOVS_DIM: n_fov})
        spectrum_vals["Radiance"][spectrum_vals["Radiance"] <= spectrum.get_fill_value() + 10] = np.nan
        return spectrum_vals

    def _get_coordinates_from_fov(self, n_line: int, n_for: int, n_fov: int) -> tuple[list]:
        """
        Get coordinates from desired fov.

        :return: tuple (list of lon of all points on the fov circle, list of lat of all points on the fov circle)
        """
        perim_longitude = self.extract_var(self.LON_PATH_ENG)
        perim_latitude = self.extract_var(self.LAT_PATH_ENG)
        perim_lon = perim_longitude.get_value_by_dim({self.N_LINES_DIM: n_line, self.N_FORS_DIM_EV: n_for, self.N_FOVS_DIM: n_fov})
        perim_lat = perim_latitude.get_value_by_dim({self.N_LINES_DIM: n_line, self.N_FORS_DIM_EV: n_for, self.N_FOVS_DIM: n_fov})
        return perim_lon, perim_lat

    def _get_all_coordinates(self, rad_product: IASING_L1C_RAD | None = None) -> pd.DataFrame:
        """
        Get coordinates for all Fovs in the product.

        :param: rad_product: if present, the RAD product will be used to show the fov centers instead of a mean of the circle ENG coordinates

        :return: dataframe following the format ("Fov index"\: tuples (line, for, fov), "Longitude"\: integers, "Latitude"\: integers,
        "Coordinates"\: list of lists [ [lon, lat] for all points in the fov circle] )
        """
        tot_lines = self.extract_var(self.LON_PATH_ENG).dimensions[self.N_LINES_DIM]
        tot_fors = self.extract_var(self.LON_PATH_ENG).dimensions[self.N_FORS_DIM_EV]
        tot_fovs = self.extract_var(self.LON_PATH_ENG).dimensions[self.N_FOVS_DIM]
        all_circles_dict = {'Fov index': [], 'Coordinates': [], 'Longitude': [], 'Latitude': []}
        for line in range(tot_lines):
            for fors in range(tot_fors):
                for fov in range(tot_fovs):
                    # Get the coordinates for all points on the fov circle
                    lon_perim, lat_perim = self._get_coordinates_from_fov(line, fors, fov)
                    if np.array(lon_perim).std() > 10:
                        lon_perim = [360 - abs(lon) if lon < 0 else lon for lon in lon_perim]
                    if np.array(lat_perim).std() > 10:
                        lat_perim = [360 - abs(lat) if lat < 0 else lon for lat in lat_perim]
                    all_circles_dict['Fov index'].append([line, fors, fov])
                    all_circles_dict['Coordinates'].append([[lon_perim[i], lat_perim[i]] for i in range(len(lon_perim))])
                    # Get the fov center coordinates from the RAD product if availale, if not use the mean from the ENG product
                    if not rad_product:
                        all_circles_dict['Longitude'].append(np.mean(lon_perim))
                        all_circles_dict['Latitude'].append(np.mean(lat_perim))
                    else:
                        lon, lat = rad_product._get_coordinates_from_fov(line, fors, fov)
                        all_circles_dict["Longitude"].append(lon)
                        all_circles_dict["Latitude"].append(lat)
        all_circles_df = pd.DataFrame(all_circles_dict)
        return all_circles_df