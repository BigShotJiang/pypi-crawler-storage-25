# Copyright (c) 2024-2026 Centre National d'Etudes Spatiales (CNES).
#
# This file is part of AtmoTools
# (see https://github.com/CNES/AtmoTools).
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

"""
    This file is the entry point of the IASI-NG visualization tool
    To run this script with custom entry files : 
    python app.py -eng <ENG_PATH> -rad <RAD_PATH> -ods <ODS_PATH>
    
    This script import the following script :
    - config.py : Contains constants of the visualization tool
    - services/data_manager.py : Allow the load and manipulate data
    - views/layout.py : Create all Dash components 
    - controllers/callbacks.py : Create all the callbacks of the Dash components
"""

from dash import Dash, Input, Output, State, callback, dcc, html, dash_table
from atmotools.missions.IASI_NG.services.data_manager import DataManager
from atmotools.missions.IASI_NG.views.layout import create_layout
from atmotools.missions.IASI_NG.controllers.callbacks import create_callbacks
from atmotools.missions.IASI_NG.config import DEFAULT_ENG, DEFAULT_RAD, DEFAULT_ODS, APP_PORT, DATA_FOLDER_PATH
import argparse

def init_app():

    #Argument parser
    parser = argparse.ArgumentParser()
    parser.add_argument("-eng", "--ENG_L1C", help = "ENG L1C files", nargs="*")
    parser.add_argument("-rad", "--RAD_L1C", help = "RAD L1C files", nargs="*")
    parser.add_argument("-ods", "--ODS_L0", help = "ODS L0 files", nargs="*")
    args = parser.parse_args()

    rads = args.RAD_L1C if args.RAD_L1C else []
    engs = args.ENG_L1C if args.ENG_L1C else []
    ods = args.ODS_L0 if args.ODS_L0 else []

    # Create the data manager to load and process data 
    data = DataManager(engs if (engs!=[] or rads!=[] or ods!=[]) else DEFAULT_ENG,  rads if (engs!=[] or rads!=[] or ods!=[]) else DEFAULT_RAD, ods if (engs!=[] or rads!=[] or ods!=[]) else DEFAULT_ODS)

    # Initialize the Dash app 
    app = Dash(name="IASI-NG Visu Tool", title="IASI-NG Visualization Tool")

    # Create de dash layout  
    app.layout = create_layout(data)

    # Create the callbacks
    create_callbacks(app, data)

    return app, data

def main():
    # Create app 
    app, data = init_app()

    # Run the app 
    app.run(debug=True, use_reloader=False, port=APP_PORT) 

    # Close the files and delete the readers to ensure there is no data corruption
    data._close_products()

if __name__ == '__main__':
    
    # Create app 
    app, data = init_app()

    # Run the app 
    app.run(debug=True, use_reloader=False, port=APP_PORT) 

    # Close the files and delete the readers to ensure there is no data corruption
    data._close_products()