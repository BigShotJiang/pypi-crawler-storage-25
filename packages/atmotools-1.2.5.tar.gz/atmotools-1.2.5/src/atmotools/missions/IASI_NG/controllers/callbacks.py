# Copyright (c) 2024-2026 Centre National d'Etudes Spatiales (CNES).
#
# This file is part of AtmoTools
# (see https://github.com/CNES/AtmoTools).
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

from dash import Dash, Input, Output, State, callback, dcc, html, dash_table

import numpy as np
import pandas as pd
import os

import atmotools.utils.path_utils as pu

import atmotools.missions.IASI_NG.services.ima_geotiff as ig
import atmotools.missions.IASI_NG.services.figures as fg
from atmotools.missions.IASI_NG.config import UNITS

def create_callbacks(app, data):
    """
        Create all the callbacks for the Dash app.
        
        :param: app : The Dash app
        :param: data : DataManager with loaded data
    """
    @app.callback(
        Output('spectrum', 'figure'),
        Output('spectrum-rad', 'figure'),
        Output('tbl', 'data'),
        Output('flag-tbl', 'data'),
        Input('fov_map', 'selectedData'),
        Input('var_selection', 'value'),
        Input('unit_selection','value'),
        Input('unit_rad_selection','value'),
        Input('selected_file','value'),
        Input("spectrum_fov_selection","value"), # fov of the spectrum selected to be substracted 
        prevent_initial_call = True)
    def update_spectrum(selected_data, paths, selected_unit, selected_unit_rad,selected_file, selected_spectrums):
        """
            This function update spectra graph. This callback is call by some inputs :
            
            :input: ('fov_map', 'selectedData') : The main map, selectedData contains information about selected element on the map.
            :input: ('var_selection', 'value') : The selected value of a Dropdown with all additionnal variable of a L1C-RAD file.
            :input: ('unit_selection','value') : The selected value of a Dropdown of units for the imaginary spectra graph
            :input: ('unit_rad_selection','value') : The selected value of a Dropdown of units for the imaginary spectra graph
            :input: ('selected_file','value') : The selected value of a Dropdown with the name of laoded files
            :input: ("spectrum_fov_selection","value") : A Dropdown with the name of the selected spectra to subtract (named by the selected fov)
            :output: ('spectrum', 'figure') : Imaginary spectrum as a figure
            :output: ('spectrum-rad', 'figure') : Real spectrum as a figure
            :output: ('tbl', 'data') : Information about the selected additionnal variable as a dict()
            :output: ('flag-tbl', 'data') : Details flags of the selected fovs as a list()
        """
        # Return default graphs to the app if no fov is selected on the map
        if not selected_data:
            return [fg.show_empty_spectrum('Spectrum Imaginary'),
                    fg.show_empty_spectrum('Spectrum Real'),
                    None,
                    None,]

        # Get selected fovs 
        selected_fovs = data.select(selected_data, selected_file)

        # Get data for spectrum graph 
        spc_eng_df = data.get_spectra_data(selected_fovs, selected_spectrums, eng = True)
        spc_rad_df = data.get_spectra_data(selected_fovs, selected_spectrums, eng = False)

        return (fg.show_spectrum(spc_eng_df, selected_unit, eng=True) if data.isENG else fg.show_empty_spectrum('Spectrum Imaginary'),
                fg.show_spectrum(spc_rad_df, selected_unit_rad, eng=False) if data.isRAD else fg.show_empty_spectrum('Spectrum Real'),
                data.get_add_vars(selected_fovs, paths),
                data.get_flag_details(selected_fovs))

    # Export selected spectra as csv file 
    @app.callback(
    Output('save-spectrum-button','n_clicks'),
    Input('save-spectrum-button','n_clicks'), 
    prevent_initial_call = True)
    def export_spectra(n_clicks):
        if n_clicks == 1:
            data.export_spectra_as_csv()
        return(0)

    # Update map on flag or line, for, fov selection
    @app.callback(
        Output("fov_map", "figure"),
        Input("line_selection", "value"),
        Input("for_selection", "value"),
        Input("fov_selection", "value"),
        Input("flag-radio", "value"),
        Input("show-circles", "value"),
        Input("selected_file","value"),
        prevent_initial_call = False)
    def update_flags_map(lines, fors, fovs, flag_radio, show_circles, selected_file):
        """
            This callback update the main map
            
            :input : ("line_selection", "value") : The selected value of a Dropdown with all line numbers
            :input : ("for_selection", "value") : The selected value of a Dropdown with all for numbers
            :input : ("fov_selection", "value") : The selected value of a Dropdown with all fov numbers
            :input : ("flag-radio", "value") : The selected value of a radio button to choose the flag display on the map
            :input : ("show-circles", "value") : The value of a checklist for fov circle display
            :input : ("selected_file","value") : The value of a Dropdown with all loaded file name
            :output : ("fov_map", "figure") : The updated map as a figure

        """
        # Return figure with all fovs if no selection is made, depending on the flag chosen
        if not data.isENG and not data.isRAD:
                fig = fg.show_empty_map()
        else: 
            selected_df = data.mask(lines, fors, fovs, selected_file)
            selected_feat = data.get_geojson_geometry(lines, fors, fovs, selected_file)
            fig = fg.show_scatter_on_map(selected_df, selected_feat, flag_radio, show_circles)

        return fig

    # Update predefined graphs for statistics checked in checklist
    @app.callback(
        Output('ratio-graphs', 'children'),
        Input("ratio-checklist-L1CENG", "value"),
        Input("ratio-checklist-L0", "value"),
        prevent_initial_call = False)
    def update_ratio_graphs(ratio_checklist_L1, ratio_checklist_L0):
        """
        """
        figs = []

        # Concatenate lists of options chosen
        if ratio_checklist_L1 and ratio_checklist_L0:
            ratio_checklist = ratio_checklist_L1 + ratio_checklist_L0
        else:
            ratio_checklist = ratio_checklist_L1 or ratio_checklist_L0
        if not ratio_checklist:
            return None

        # Adjust the width as needed
        graph_width = '33%' if len(ratio_checklist)%3 == 0 else '48%'
        if "zpd" in ratio_checklist:
            graph_width = '33%' if (len(ratio_checklist) + 2)%3 == 0 else '48%'

        # Show graphs for each selected options in checklist
        for val in ratio_checklist:
            fig = None
            # Return min, max and mean for zpd along the different files for each laser
            if val == "zpd":

                (granules_df_mean, granules_df_min, granules_df_max) = data.get_zpd()

                # Add figures for min and max to list of figures
                fig_min = fg.show_zpd(granules_df_min, 'Min Relative Metrology ZPD along orbit for each laser')
                fig_max = fg.show_zpd(granules_df_max, 'Max Relative Metrology ZPD along orbit for each laser')
                figs.append(dcc.Graph(id=val + "min", style={'width': graph_width, 'display': 'inline-block'}, figure=fig_min))
                figs.append(dcc.Graph(id=val + "max", style={'width': graph_width, 'display': 'inline-block'}, figure=fig_max))
                
                # Create figure for mean, added below to list of figures
                fig = fg.show_zpd(granules_df_mean, 'Mean Relative Metrology ZPD along orbit for each laser')

            # Return mean of NZPD for each direction
            elif val == "std":
                
                nzpd_df_mean = data.get_nzpd()
                fig = fg.show_nzpd(nzpd_df_mean)

            # Return ratio of general quality flag
            elif val == "gq":

                df_ratio = data.get_general_quality_flags_ratio()
                fig = fg.show_general_quality_flags_ratio(df_ratio)

            # Return ratio of spike flags for each band along the different files
            elif val == "spk":

                df_ratio = data.get_spike_flags_ratio()
                fig = fg.show_spike_flags_ratio(df_ratio)

            figs.append(dcc.Graph(id=val, style={'width': graph_width, 'display': 'inline-block'}, figure=fig))

        return figs

    # Update choice of dimensions to compute mean of selected variable from L1C variables list
    @callback(
        Output('dim_selection_mean', 'options'),
        Output('dim_selection_mean', 'disabled'),
        Input('var_selection_mean', 'value'),
        prevent_initial_call = True)
    def update_dim_selection_menu(path):
        if path:
            return list(data.all_vars_rad[path]["dimensions"].keys()), False
        else:
            return [], True

    # Update choice of dimensions to compute mean of selected variable from ODS variables list
    @callback(
        Output('dim_selection_mean_l0', 'options'),
        Output('dim_selection_mean_l0', 'disabled'),
        Input('var_selection_mean_l0', 'value'),
        prevent_initial_call = True)
    def update_dim_selection_menu_l0(path):
        if path:
            return list(data.all_vars_ods[path]["dimensions"].keys()), False
        else:
            return [], True

    # Update graphs for mean of selected variable along selected dimensions in L1C variables list and their dimensions list
    @callback(
        Output('mean_graphs', 'children'),
        Input('var_selection_mean', 'value'),
        Input('dim_selection_mean', 'value'),
        Input('dim_selection_mean', 'options'),
        prevent_initial_call = False)
    def update_mean_graphs(var_path, selected_dims, all_dims):
        """
        """
        if var_path and selected_dims:
            all_graphs = []
            # Store the dimensions to keep
            remaining_dims = [dim_name for dim_name in all_dims if dim_name not in selected_dims]
            # Return mean of variable on all dimensions if all dimensions have been selected
            if not remaining_dims:

                df_means = data.get_l1c_or_l0_variables_mean('L1C-RAD', var_path)

                title = f"Mean of variable {pu.get_last_element_in_path(var_path)[0]} along {'axes' if len(selected_dims)>=2 else 'axis'} {selected_dims}"
                fig = fg.show_variable_mean(df_means, title)

                return dcc.Graph(figure=fig)

            # Return graph of mean on only one dimension left, for each remaining dimension
            for remaining_dim in remaining_dims:

                # Update list of selected dimensions to compute the mean by adding all other remaining dimensions except remaining_dim
                dim_names = selected_dims + [dim for dim in remaining_dims if dim != remaining_dim]

                df_means = data.get_l1c_or_l0_variables_mean('L1C-RAD', var_path, dim_names, remaining_dim)

                title= f"Mean of variable {pu.get_last_element_in_path(var_path)[0]} along {'axes' if len(dim_names)>=2 else 'axis'} {dim_names}"
                fig = fg.show_variable_mean(df_means, title = title, color = remaining_dim)

                all_graphs.append(dcc.Graph(figure=fig))

            return all_graphs

        # Return no graphs if no variable or no dimension have been selected
        else:
            return None

    # Update graphs for mean of selected variable along selected dimensions in ODS variables list and their dimensions list
    @callback(
        Output('mean_graphs_l0', 'children'),
        Input('var_selection_mean_l0', 'value'),
        Input('dim_selection_mean_l0', 'value'),
        Input('dim_selection_mean_l0', 'options'),
        prevent_initial_call = False)
    def update_mean_graphs_l0(var_path, selected_dims, all_dims):
        """
        """
        if var_path and selected_dims:
            all_graphs = []
            # Store the dimensions to keep
            remaining_dims = [dim_name for dim_name in all_dims if dim_name not in selected_dims]
            # Return mean of variable on all dimensions if all dimensions have been selected
            if not remaining_dims:
                df_means = data.get_l1c_or_l0_variables_mean('ODS', var_path)

                title= f"Mean of variable {pu.get_last_element_in_path(var_path)[0]} along {'axes' if len(selected_dims)>=2 else 'axis'} {selected_dims}"
                fig = fg.show_variable_mean(df_means, title)
                return dcc.Graph(figure=fig)

            # Return graph of mean on only one dimension left, for each emaining dimension
            for remaining_dim in remaining_dims:

                # Update list of selected dimensions to compute the mean by adding all other remaining dimensions except remaining_dim
                dim_names = selected_dims + [dim for dim in remaining_dims if dim != remaining_dim]
                df_means = data.get_l1c_or_l0_variables_mean('ODS', var_path, dim_names, remaining_dim)

                title= f"Mean of variable {pu.get_last_element_in_path(var_path)[0]} along {'axes' if len(dim_names)>=2 else 'axis'} {dim_names}"
                fig = fg.show_variable_mean(df_means, title)
                all_graphs.append(dcc.Graph(figure=fig))

            return all_graphs

        # Return no graphs if no variable or no dimension have been selected
        else:
            return None

    @callback(
        Output("spectrum_fov_selection","options"),
        Input('fov_map', 'selectedData'),
        Input("selected_file","value"),
        prevent_initial_call = False)
    def update_dropdown(selectedData, selected_file):
        """
            This callback update spectrum dropdown options on selection of a fov on the map

            :input: ('fov_map', 'selectedData') : The value of selected element on the main map
            :input: ("selected_file","value"): The value of a dropdown with the name of the loaded file
            :output: ("spectrum_fov_selection","options"): The options of a dropdown as a list()
        """

        options = [] 

        selected_fovs = data.select(selectedData, selected_file)

        for fov in selected_fovs : 
            index_value = (fov[3] , fov[0], fov[1], fov[2])
            index_label = (f"File: {fov[3]+1}",fov[0]+1,fov[1]+1,fov[2]+1) # Add +1 to start at 1 only on display   
            options.append({'label' : str(index_label), 'value' : str(index_value)})


        return options

    @callback(
        Output("geotiff-map","children"),
        Input("geotiff-button","n_clicks"),
        State('fov_map', 'selectedData'),
        State('save-geotiff-checklist','value'),
        prevent_initial_call = True)
    def update_geotiff(geotiff_button, selectedData, save_geotiff):
        """
            This callback update geotiff map on selection of a fov on the map or with dropdown selector

            :input: ("geotiff-button","n_clicks"): The number of click on the button as a int
            :state: ('fov_map', 'selectedData'): The value a selected element on the main map as a dict()
            :state: ('save-geotiff-checklist','value'): The value of the checklist to save geotiff as a str
            :output: ("geotiff-map","children"): A map with Geotiff image and fovs as an iframe 
        """
        if geotiff_button > 0 : 
            # Fovs selected directly on the map
            if selectedData and data.isENG:
                selected_df = data.get_data_for_geotiff(selectedData)
            # No selected fovs 
            else : 
                print("WARNING : No selected Fov for Geotiff generation")
                return None
            return ig.plot_geotiff(selected_df[['Latitude', 'Longitude', 'Line', 'For', 'Fov', 'Eng_path']], save_geotiff = save_geotiff) if type(selected_df) !=  type(None) else None
        elif not data.isENG :
            print("ERROR: No ENG file for Geotiff loading. Please make sure to upload the corresponding file.")
            return None
        else :
            return None

if __name__ == '__main__':
    pass