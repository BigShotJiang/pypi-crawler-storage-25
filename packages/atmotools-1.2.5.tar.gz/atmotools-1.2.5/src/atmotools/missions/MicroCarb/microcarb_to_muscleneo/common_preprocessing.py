# Copyright (c) 2024-2026 Centre National d'Etudes Spatiales (CNES).
#
# This file is part of AtmoTools
# (see https://github.com/CNES/AtmoTools).
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

import math
from datetime import datetime
import numpy as np
from scipy import interpolate

from Mission.MicroCarb.src.latmos_sun_irradiance import LATMOSSunIrradiance
from Mission.MicroCarb.src.microcarb_l1_product import MicroCarbL1C
import utils.src.array_utils as au
from Mission.MicroCarb.src.microcarb_to_muscleneo.exogeneous_files import *

# ===========================
# CONSTANTS
# ===========================
# ISRF thresholds
ISRF_NULL_THRESHOLD = - np.inf
ISRF_GRID_INTERP_ACC = np.inf


# ===========================
# FUNCTIONS
# ===========================
def execute_all_steps(mc_l1c_file_path: str, *solspec_paths: str):
    """
    Execute all steps described in section §4.1 "common Pre-processing" of Specification Document

    :param mc_l1c_file_path: the absolute path of MicroCarb L1C product
    :param solspec_paths: the absolute paths of LATMOS solspec files. They may contain patterns using wildcards (* or ?)
    """
    mc_l1c = MicroCarbL1C(mc_l1c_file_path)

    # Extract dimensions
    n_band = mc_l1c.extract_dimension("nBand")
    n_fov = mc_l1c.extract_dimension("nFov")
    n_fs = mc_l1c.extract_dimension("nFs")
    n_lambda = mc_l1c.extract_dimension("nLambda")
    n_uniform_isrf = mc_l1c.extract_dimension("nUniformIsrf")

    # ===========================
    # §4.1.1.1 MicroCarb ISRFs
    # ===========================
    # Size: nFov x nBand x nLambda x nUniformIsrf
    l1c_uniform_isrfs = mc_l1c.extract_uniform_isrf()

    # ===========================
    # §4.1.1.2 Sun spectral irradiance
    # ===========================
    l1c_lambda = mc_l1c.extract_lambda()
    l1c_isrf_coordinates = mc_l1c.extract_uniform_isrf_d_lambda()
    wn_min, wn_max = compute_wavenumber_interval(
        l1c_lambda.get_data(), l1c_isrf_coordinates.get_data()
    )

    # Extract data for wavenumbers in [wn_min ; wn_max] for each band
    # The sun spectral irradiance is computed in LATMOSSunIrradiance
    latmos_instances = []
    for band in range(n_band):
        wn_min_band = wn_min[band]
        wn_max_band = wn_max[band]
        latmos = LATMOSSunIrradiance(*solspec_paths, wn_min=wn_min_band, wn_max=wn_max_band)
        latmos_instances.append(latmos)

    # ===========================
    # §4.1.1.3 Calculation of earth-sun distance correction factor
    # ===========================
    try:
        l1c_acq_time_var = mc_l1c.extract_acq_time_string().get_data()
        if isinstance(l1c_acq_time_var, np.ndarray):
            raw0 = l1c_acq_time_var.item()
        else:
            raw0 = l1c_acq_time_var
        if isinstance(raw0, (bytes, np.bytes_)):
            acq_time_str = raw0.decode()
        else:
            acq_time_str = str(raw0)
        doy = [convert_date_to_day_of_year(date) for date in acq_time_str] \
              if isinstance(acq_time_str, (list, np.ndarray)) else [convert_date_to_day_of_year(acq_time_str)]
    except Exception:
        from datetime import datetime
        iso_now = datetime.utcnow().strftime("%Y-%m-%dT%H:%M:%S.%f")[:-3] + "Z"
        doy = [convert_date_to_day_of_year(iso_now)]
    
    dist_cor_factor = compute_earth_sun_distance_correction_factor(doy)

    # ===========================
    # §4.1.1.4 Calculation of TOA reflectance in each channel
    # ===========================
    l1c_radiance = mc_l1c.extract_radiance()
    l1c_solar_zenith = mc_l1c.extract_solar_zenith()
    toa_reflectance = compute_toa_reflectance(
        n_fs, n_fov, n_band, n_lambda,
        l1c_radiance.get_data(),
        l1c_solar_zenith.get_data(),
        l1c_lambda.get_data(),
        l1c_isrf_coordinates.get_data(),
        l1c_uniform_isrfs.get_data(),
        dist_cor_factor, latmos_instances
    )


def convert_date_to_day_of_year(date_str: str) -> int:
    """
    Convert a date string in the format 'YYYY-MM-DDThh:mm:ss.nnnZ' to the corresponding day of the year.

    :param date_str: A date string in the format 'YYYY-MM-DDThh:mm:ss.nnnZ'
    :return: The day of the year (1 to 366) corresponding to the input date.
    :raises ValueError: if date_str does not match the expected format
    """
    try:
        # Parse the input date string
        dt = datetime.strptime(date_str, "%Y-%m-%dT%H:%M:%S.%fZ")

        # Ensure that the microseconds part has exactly 3 digits
        if len(date_str.split('.')[-1]) != 4:  # 3 digits + 'Z'
            raise ValueError(f"Microseconds must be exactly 3 digits. Got: '{date_str}'")

        # Return the day of the year
        return dt.timetuple().tm_yday
    except ValueError as e:
        # Raise an error if the format is incorrect
        raise ValueError(f"Invalid date format: '{date_str}'. Expected format is 'YYYY-MM-DDThh:mm:ss.nnnZ' "
                         f"with exactly 3 digits for microseconds.")


def compute_earth_sun_distance_correction_factor(day_of_year: list[int]) -> np.ndarray:
    """
    Compute the earth-sun distance correction factor from the day of the year
    Spec §4.1.1.3

    :param day_of_year: day of the year
    :return: the earth-sun distance correction factor
    """
    om = (0.9856 * (np.array(day_of_year) - 4) * math.pi) / 180
    cos_om = np.cos(om)
    d_sun = 1 - (0.01673 * cos_om)
    d_sun = d_sun * d_sun
    return 1 / d_sun


def compute_wavenumber_interval(wavelengths: np.ndarray, isrf_coordinates: np.ndarray) -> tuple[np.ndarray,
                                                                                                np.ndarray]:
    """
    Compute the wavenumber interval to extract from LATMOS sun spectrum for each band.
    If possible return the wavenumber interval corresponding to [wl_min - 0.5 * isrf_length ; wl_max + 0.5 isrf_length]

    :param wavelengths: the MicroCarb L1C wavelenghts
    :param isrf_coordinates: the MicroCarb L1C spectral coordinates of uniform ISRF around barycenter
    :return: a tuple of minimum and maximum wavenumbers (both numpy.arrays) to extract for each band
    """
    wl_min_out = []
    wl_max_out = []
    n_fs, n_fov, n_band, n_lambda = wavelengths.shape
    for band in range(n_band):
        # Compute the wavelength interval: [wl_min - 0.5 * isrf ; wl_max + 0.5 isrf]
        wl_min = np.nanmin(wavelengths[:, :, band, :])
        wl_max = np.nanmax(wavelengths[:, :, band, :])
        # The wavelengths to extract
        wl_min_out.append(wl_min + isrf_coordinates[band, 0])
        wl_max_out.append(wl_max + isrf_coordinates[band, -1])

    # Convert the wavelengths to wavenumbers
    wn_min_out = 1e4 / np.array(wl_max_out)
    wn_max_out = 1e4 / np.array(wl_min_out)
    return wn_min_out, wn_max_out


def compute_toa_reflectance(n_fs: int, n_fov: int, n_band: int, n_lambda: int,
                            l1c_radiance, l1c_solar_zenith, l1c_lambda, l1c_isrf_coordinates, l1c_uniform_isrfs,
                            earth_sun_cor_f: np.ndarray, latmos_instances: list[LATMOSSunIrradiance]) -> np.ndarray:
    """
    Compute the TOA reflectance
    Spec §4.1.1.4

    :param n_fs: dimension nFs from MicroCarb L1C product
    :param n_fov: dimension nFov from MicroCarb L1C product
    :param n_band: dimension nBand from MicroCarb L1C product
    :param n_lambda: dimension nLambda from MicroCarb L1C product
    :param l1c_radiance: the measured radiance from MicroCarb L1C product (size: nFs x nFov x nBand x nLambda)
    :param l1c_solar_zenith: the solar zenith from MicroCarb L1C product (size: nFs x nFov)
    :param l1c_lambda: the wavelengths sample from MicroCarb L1C product (size: nFs x nFov x nBand x nLambda)
    :param l1c_isrf_coordinates: the spectral coordinates from MicroCarb L1C product (size: nBand x nUniformIsrf)
    :param l1c_uniform_isrfs: the ISRF from MicroCarb L1C product (size: nFov x nBand x nLambda x nUniformIsrf)
    :param earth_sun_cor_f: the earth sun distance correction factor (size: nFs)
    :param latmos_instances: the LATMOSSunIrradiance instance for each band (size: nBand)
    :return: TOA reflectance as an array of size nFs x nFov x nBand x nLambda. May contain NaN values.
    """
    # Initialize the TOA reflectance with numpy.nan values
    toa_reflectance = np.full((n_fs, n_fov, n_band, n_lambda), np.nan, float)

    for frame in range(n_fs):
        d_sun_cor = earth_sun_cor_f[frame]
        for fov in range(n_fov):
            solar_zenith = l1c_solar_zenith[frame, fov]
            for band in range(n_band):
                # Extract LATMOS solspec wavelenghts and sun spectral irradiances
                latmos_wavelengths = latmos_instances[band].wavelengths
                latmos_sun_irradiances = latmos_instances[band].sun_spect_irradiances

                # Extract the channels
                channels = l1c_lambda[frame, fov, band]

                # Exclude NaN channels
                # Get the index of channels that are not NaN
                ch_indices = np.where(~np.isnan(channels))[0]
                channels = channels[ch_indices]
                n_lambda_filtered = len(channels)

                # Extract the ISRFs excluding values corresponding to NaN channels
                # Current size of isrf_ampl: n_lambda_filtered x nUniformIsrf
                isrf_ampl = l1c_uniform_isrfs[fov, band, ch_indices]

                # Get the positions of remaining NaN
                nan_isrf_positions = np.where(np.isnan(isrf_ampl))
                if len(nan_isrf_positions[0]) > 0:
                    raise ValueError(f"NaN found in L1C UniformIsrfs after excluding NaN channels for frame "
                                     f"{frame}, fov {fov}, band {band}. Positions of NaN: {nan_isrf_positions}")

                # Create an ISRF grid corresponding to the channels and the ISRF coordinates
                isrf_grid = np.array(n_lambda_filtered * [l1c_isrf_coordinates[band]])

                # Compute the equivalent Sun Irradiance for all channels
                # Size: n_lambda_filtered
                irr_sun = apply_isrf(latmos_wavelengths, latmos_sun_irradiances, channels, isrf_grid, isrf_ampl)
                irr_sun_eq = irr_sun / np.trapezoid(latmos_sun_irradiances, latmos_wavelengths)

                # Compute the TOA reflectance
                for ch_index in range(n_lambda_filtered):
                    radiance = l1c_radiance[frame, fov, band, ch_indices[ch_index]]
                    i_sun_eq_ch = irr_sun_eq[ch_index]
                    # Fill the output
                    toa_reflectance[frame, fov, band, ch_indices[ch_index]] = (math.pi * radiance) / (
                                i_sun_eq_ch * d_sun_cor *
                                math.cos(solar_zenith))
    return toa_reflectance


def convert_toa_reflectance_ground_calibration(ground_calib_coef: np.ndarray, official_coef: np.ndarray,
                                               toa_reflectance: np.ndarray):
    """
    Convert TOA reflectances to ground absolute calibration
    Spec §4.1.2

    :param ground_calib_coef: the ground calibration coefficients
    :param official_coef: the official calibration from TUN file
    :param toa_reflectance: the TOA reflectance
    :return: the converted TOA reflectance
    """
    if not au.check_same_shape(ground_calib_coef, official_coef, toa_reflectance):
        raise RuntimeError(f"Different shapes: {ground_calib_coef.shape}, {official_coef.shape}, "
                           f"{toa_reflectance.shape}")
    return toa_reflectance * official_coef / ground_calib_coef


def compute_valid_channels_for_band(chan_out_absorption: dict, spike_map: np.ndarray) -> list:
    """
    Return the list of indexes of valid channels for a fixed band.
    A channel is valid if it is outside of absorption lines and not flagged as spike.

    :param chan_out_absorption: the dictionary of channels outside of absorption lines for a fixed band
    :param spike_map: the boolean map of spikes for a fixed band (fixed frame, fov and band)
    :return the list of indexes of valid channels
    """
    # Initialize the valid channels for the current band
    valid_channels_band = []
    for chan_index, wavelength in chan_out_absorption.items():
        # TODO: wait answer about computation of valid_channels and fix it
        # Keep the channels that are not flagged as spikes (possible spike values: 0, 1 or 255)
        if spike_map[chan_index] == 0:
            valid_channels_band.append(chan_index)
    return valid_channels_band


def compute_all_valid_channels(n_fs: int, n_fov: int, n_band: int, spikes_map: np.ndarray,
                               valid_chan_files: list[str]) -> list[list[list[list]]]:
    """
    Compute the valid channels for all frames, fovs and bands

    :param n_fs: the number of frames
    :param n_fov: the number of fovs
    :param n_band: the number of bands
    :param spikes_map: the map of spikes
    :param valid_chan_files: the path of exogeneous files containing the channels outside of absorption lines.
                             The n-th element of the list corresponds to the n-th band.
    :return: the index of valid channels for all frames, fovs and bands
    """
    result = []
    for frame in range(n_fs):
        valid_chan_frame = []
        for fov in range(n_fov):
            valid_chan_fov = []
            for band in range(n_band):
                spikes_current = spikes_map[frame, fov, band]
                chan_out_absorption = read_valid_channels_files(valid_chan_files[band])
                valid_chan_indexes = compute_valid_channels_for_band(chan_out_absorption, spikes_current)
                valid_chan_fov.append(valid_chan_indexes)
            valid_chan_frame.append(valid_chan_fov)
        result.append(valid_chan_frame)
    return result


def compute_multispectral_equivalent_data(n_band: int, valid_chan_indexes, toa_reflectance_ground, equivalent_sun_irradiance) -> \
        tuple[list, list, list, list]:
    """
    Compute the multrispectral equivalent TOA reflectance, the standard deviation of TOA reflectances,
    the equivalent wavelengths and sun irradiance
    Spec §4.1.3

    :param n_band: the number of band to process
    :param valid_chan_indexes: the MicroCarb valid channels
    :param toa_reflectance_ground: the TOA reflectance converted to ground absolute calibration
    :param equivalent_sun_irradiance: the equivalent Sun Irradiance
    :return: the multrispectral equivalent TOA reflectance, the standard deviation of TOA reflectances, the
    equivalent wavelengths and sun irradiance for each band
    """
    # TODO: rewrite when dimensions are known
    # Initialize the results:
    # equivalent TOA reflectance
    rho_eq_toa = []
    # the standard deviation of TOA reflectances
    sigma = []
    # the equivalent wavelengths
    lambda_eq = []
    # sun irradiance
    i_s_eq = []

    # valid_channels depend on the band
    for band in range(n_band):
        lamb_valid = np.array(valid_chan_indexes[band])
        rho_gnd_toa_valid = np.array(toa_reflectance_ground[lamb_valid])
        i_eq_sun_valid = np.array(equivalent_sun_irradiance[lamb_valid])

        # Compute the equivalent TOA reflectance of the band
        rho_eq_toa[band] = np.mean(rho_gnd_toa_valid)

        # Compute the standard deviation of TOA reflectances. Default ddof = 0
        sigma[band] = np.std(rho_gnd_toa_valid)

        # Compute the equivalent wavelengths
        lambda_eq[band] = np.mean(lamb_valid)

        # Compute the equivalent sun irradiance
        i_s_eq[band] = np.mean(i_eq_sun_valid)
    return rho_eq_toa, sigma, lambda_eq, i_s_eq


def apply_isrf(grid_inf: np.ndarray, sp_inf: np.ndarray, channels: np.ndarray, isrf_grid: np.ndarray,
               isrf_ampl: np.ndarray, null_thr: float = ISRF_NULL_THRESHOLD,
               extrapolate_thr: int = ISRF_GRID_INTERP_ACC) -> np.ndarray:
    """
    apply_isrf computes and applies the I(J)SRF on each channel to return the instrument spectrum

    On each channel, an interpolation of the ISRF is performed so that the local ISRF matches the
    sampling points of the infinite spectrum. Then values, norm and spectral shift are ensured:
     - ISRF: unit intergral (and initial spectral shift)
     - JSRF: initial norm 1 is kept, and spectral shift

    The high resolution spectrum may be a ndarray, e.g. (channels, layers, gas) for gas Jacobians.
    The application of the spectral response will then be vectorized, and the spectral grid
    vectorized accordingly.

    :param np.ndarray grid_inf: spectral grid of pseudo-infinite spectrum (n_solar, )
    :param np.ndarray sp_inf: spectral amplitude of pseudo-infinite spectrum. (n_solar, )
    :param np.ndarray channels: instrument channels corresponding to each ISRF (nLambda, )
    :param np.ndarray isrf_grid: ISRF local spectral grids, (nLambda, nUniformIsrf)
    :param np.ndarray isrf_ampl: ISRF amplitude for each instrument channel. (nLambda, nUniformIsrf)
    :param float null_thr: threshold under which ISRF amplitude will be forced to zero.
        Defaults to ISRF_NULL_THRESHOLD
    :param float extrapolate_thr: threshold for null values for the ISRF
    :raises ValueError: if NaN are found after the application of the ISRF
    :return np.ndarray: instrument radiance spectra (nLambda, )
    """
    # Initialize the result for each channel
    result = []

    for ichan, chan in enumerate(channels):
        raw_grid = isrf_grid[ichan]
        raw_isrf = isrf_ampl[ichan]

        # Interpolation of the channel ISRF into a polynomial function
        # -------------------
        # Note : Extrapolation is allowed a priori, but is thresholded later on
        isrf_f = interpolate.InterpolatedUnivariateSpline(raw_grid, raw_isrf, ext='zeros')

        # Computation of the spectral amplitude on the instrument channel
        # -------------------
        # Determination of the neighbourhood of the computation point (channel) in the pseudo-
        # infinite spectrum. The neighbourhood is defined by local ISRF extension around the
        # sampling point.
        loca = np.logical_and(chan + raw_grid[0] <= grid_inf, grid_inf <= chan + raw_grid[-1])

        # The neighbourhood is centered to match centered ISRF coordinates
        neigh_inf = grid_inf[loca] - chan

        # Check for authorized extrapolation due to floating point precision.
        # Raise if unexpected behaviour occurs
        check_extrapolation_margin(raw_grid, neigh_inf, extrapolate_thr)

        # Definition of the ISRF on the neighbourhood points, and normalization.
        isrf_neigh = isrf_f(neigh_inf)

        # FTIR ISRF and JSRF may go far into negative values, hence the abs.
        isrf_neigh[np.abs(isrf_neigh) < null_thr] = 0

        # The ISRF integral is expected to be the unity: energy conservation
        isrf_neigh /= np.trapezoid(isrf_neigh, neigh_inf)

        # Check interpolated ISRF wrt source one
        check_isrf_wrt_source(raw_isrf, null_thr, isrf_neigh)

        # Computation of the radiance seen by the instrument:
        # Transposition to enable numpy to broadcast/vectorize the operation on required dimensions:
        # the last dimension must match. And transposition back to expected shape after integration
        result.append(np.trapezoid(isrf_neigh * sp_inf[loca].T, neigh_inf).T)

    if np.any(np.isnan(result)):
        raise ValueError('NaN are found after the application of the ISRF')  # garde fou

    return np.array(result)


def check_extrapolation_margin(isrf_grid: np.ndarray, neigh_inf: np.ndarray, extrapolate_thr: float):
    """
    check_extrapolation_margin checks for authorized extrapolation due to floating point precision
    and raises if unexpected behaviour occurs.

    :param np.ndarray isrf_grid: _description_
    :param np.ndarray neigh_inf: _description_
    :param float extrapolate_thr: _description_
    :raises ValueError: if extrapolation trespasses the thresholds on lower values of the grid
    :raises ValueError: if extrapolation trespasses the thresholds on higher values of the grid
    """
    if isrf_grid[0] - neigh_inf[0] > extrapolate_thr:
        raise ValueError(
            "Extrapolation not allowed for ISRF resampling: "
            f"{isrf_grid[0]} - {neigh_inf[0]} > {extrapolate_thr}"
        )
    if neigh_inf[-1] - isrf_grid[-1] > extrapolate_thr:
        raise ValueError(
            "Extrapolation not allowed for ISRF resampling: "
            f"{isrf_grid[0]} - {neigh_inf[0]} > {extrapolate_thr}"
        )


def check_isrf_wrt_source(raw_isrf: np.ndarray, null_thr: float, isrf_neigh: np.ndarray):
    """
    check_isrf_wrt_source checks interpolated ISRF wrt source one and log warnings if unexpected
    behaviour occurs

    Warning cases are :
        - Input ISRF has negative values but not the interpolated one
        - Input ISRF has only positive values but not the interpolated one

    :param np.ndarray raw_isrf: source ISRF
    :param float null_thr: threshold for null values for the ISRF
    :param np.ndarray isrf_neigh: interpolated ISRF
    """
    if np.any(raw_isrf < -null_thr) and np.all(isrf_neigh >= 0):
        print("Input ISRF has negative values but not the interpolated one")
    if np.all(raw_isrf >= 0) and np.any(isrf_neigh < -null_thr):
        print("Input ISRF has only positive values but not the interpolated one")
        print(f"{isrf_neigh[isrf_neigh < -null_thr]}")

def compute_water_vapor_column(
    h2o_profile: np.ndarray,
    pressure_grid: np.ndarray,
    surface_pressure: np.ndarray
) -> np.ndarray:
    """
    Computes the column-integrated water vapor (cm) from a MET H2O mixing-ratio profile.

    :param h2o_profile: Array of shape (nFs, nFov, nLevel), giving H2O mixing ratio [kg/kg] per level.
    :param pressure_grid: Array of shape (nFs, nFov, nLevel), giving pressure at each level [hPa].
    :param surface_pressure: Array of shape (nFs, nFov), giving surface pressure [hPa].
    :return: Array of shape (nFs, nFov) with column water vapor in cm (centimeters of precipitable water).
    """
    # Constants
    g = 9.80665  # gravitational acceleration [m/s²]
    Rv = 461.5   # specific gas constant for water vapor [J/(kg·K)]
    # NOTE: Without a temperature profile, we approximate via integral q dp / g

    nFs, nFov, nLevel = h2o_profile.shape
    # Convert pressure to Pa (hPa -> Pa)
    p_Pa = pressure_grid * 100.0  # shape (nFs, nFov, nLevel)
    # Prepare output
    column_kg_m2 = np.zeros((nFs, nFov), dtype=np.float64)

    # Compute dp safely, handling single-level (nLevel=1) case
    if nLevel == 1:
        # Single-level: dp is simply p_Pa at that one level
        dp = np.zeros_like(p_Pa)
        dp[..., 0] = p_Pa[..., 0]
    else:
        # Multi-level: standard trapezoidal slice thickness
        dp = np.diff(p_Pa, axis=2, prepend=0)  # shape (nFs, nFov, nLevel)
        # Correct top layer thickness explicitly
        dp[..., 0] = p_Pa[..., 0] - p_Pa[..., 1]

    # Integrate mixing_ratio * dp / g over all levels to get kg/m²
    integral = np.sum(h2o_profile * dp, axis=2) / g  # shape (nFs, nFov) [kg/m²]

    # Convert kg/m² to cm of water (1 kg/m² = 0.1 cm)
    column_cm = integral * 0.1
    return column_cm

def apply_ground_calibration(
    radiances: np.ndarray,
    lambdas: np.ndarray,
    ak_gnd_dict: Dict[int, np.ndarray]
) -> np.ndarray:
    """
    Applies ground calibration (A_gnd) to raw L1C radiances.

    :param radiances: L1C radiance array, shape (nFs, nFov, nBand, nLambda), units W/m²/sr/µm.
    :param lambdas:    L1C wavelengths array, shape (nBand, nLambda), units µm.
    :param ak_gnd_dict: {band_index: array of shape (M, 2)} giving [wavelength, A_gnd] per row.
    :return: Array of same shape as 'radiances', with radiances multiplied by A_gnd(Lambda).
    """
    # radiances dims: (nFs, nFov, nBand, nLambda)
    nFs, nFov, nBand, nLambda = radiances.shape
    output = np.zeros_like(radiances, dtype=np.float64)

    for b in range(nBand):
        # L1C band indices are assumed 1-based in ak_gnd_dict; convert zero-based index b -> band_index=b+1
        band_index = b + 1
        if band_index not in ak_gnd_dict:
            raise KeyError(f"No ground-calibration coefficients for band {band_index}")

        # Extract the AK_GND table for this band
        ak_table = ak_gnd_dict[band_index]  # shape (M, 2)
        wg = ak_table[:, 0]  # wavelengths for calibration [µm]
        ag = ak_table[:, 1]  # coefficients

        # L1C wavelengths for this band:
        lam_band = lambdas[b, :]  # shape (nLambda,)
        # Interpolate A_gnd to lam_band
        # If lam_band falls outside wg range, extrapolate by nearest value
        ag_interp = np.interp(lam_band, wg, ag, left=ag[0], right=ag[-1])  # shape (nLambda,)

        # Broadcast to (nFs, nFov, nLambda)
        # Multiply radiances[..., b, :] by ag_interp
        # radiances[..., b, :] has shape (nFs, nFov, nLambda)
        # ag_interp has shape (nLambda,)
        output[..., b, :] = radiances[..., b, :] * ag_interp[np.newaxis, np.newaxis, :]
    return output

def normalize_radiances_to_if(
    radiances: np.ndarray,
    lambdas: np.ndarray,
    sun_wavelengths: np.ndarray,
    sun_irradiances: np.ndarray,
    earth_sun_distance_au: float
) -> np.ndarray:
    """
    Converts ground-calibrated radiances L(Lambda) to I/F (unitless) using:
        I/F(Lambda) = Pi * L(Lambda) * d^2 / E_sun(Lambda),
    where E_sun(Lambda) is solar irradiance at TOA and d is Earth-Sun distance in AU.

    :param radiances:         shape (nFs, nFov, nBand, nLambda), ground-calibrated radiances.
    :param lambdas:           shape (nBand, nLambda), L1C wavelengths [µm].
    :param sun_wavelengths:   shape (N_sun,), wavelengths for solar irradiance.
    :param sun_irradiances:   shape (N_sun,), E_sun(Lambda) [W/m²/µm].
    :param earth_sun_distance_au: distance in astronomical units.
    :return: Array of same shape as radiances, containing I/F (unitless).
    """
    nFs, nFov, nBand, nLambda = radiances.shape
    # Precompute Pi * d^2
    factor = np.pi * (earth_sun_distance_au ** 2)

    output = np.zeros_like(radiances, dtype=np.float64)

    for b in range(nBand):
        lam_band = lambdas[b, :]  # shape (nLambda,)
        # Interpolate E_sun to lam_band
        E_interp = np.interp(lam_band, sun_wavelengths, sun_irradiances,
                                left=sun_irradiances[0], right=sun_irradiances[-1])  # shape (nLambda,)

        # Avoid division by zero
        E_interp[E_interp <= 0] = np.nan

        # Broadcast to (nFs, nFov, nLambda)
        # I/F = factor * L(Lambda) / E_sun(Lambda)
        output[..., b, :] = factor * radiances[..., b, :] / E_interp[np.newaxis, np.newaxis, :]

    return output

def filter_invalid_channels(
    if_cube: np.ndarray,
    valid_channels_dict: Dict[int, List[int]]
) -> np.ndarray:
    """
    Zeroes out any I/F values at wavelengths (channels) not listed as valid.

    :param if_cube:             shape (nFs, nFov, nBand, nLambda), I/F values.
    :param valid_channels_dict: {band_index: [valid_channel_indices (0-based)]}
    :return: A new array of same shape with invalid channels set to 0.
    """
    nFs, nFov, nBand, nLambda = if_cube.shape
    output = if_cube.copy()

    for b in range(nBand):
        band_index = b + 1
        if band_index not in valid_channels_dict:
            # If no valid list provided, assume all channels valid
            continue

        valid_idxs = set(valid_channels_dict[band_index])
        # For each channel index l in [0, nLambda), if l not in valid_idxs -> zero out
        mask = np.ones(nLambda, dtype=bool)
        for l in valid_idxs:
            if 0 <= l < nLambda:
                mask[l] = False  # this channel is valid -> do not zero
        # mask[i]==True means invalid channel -> zero it
        output[..., b, mask] = 0.0

    return output

# ---------------------------------------------------------------
# Common preprocessing "driver" for MicroCarb (§ 5.2)
# ---------------------------------------------------------------

def run_common_preprocessing(
    l1c_file: str,
    met_file: str,
    valid_channels_dir: str,
    ak_gnd_dir: str,
    sun_irradiance_file: str,
    tun_file: str,
    site_json: str
) -> Dict[str, np.ndarray]:
    """
    Executes the common-preprocessing pipeline steps:

        1. Load L1C -> radiances, wavelengths, acquisition time.
        2. Load MET -> H2O profile, pressure grid, surface pressure.
        3. Load exogenous inputs: valid-channels, AK_GND, TUN, sun irradiance, site JSON.
        4. Compute water-vapor column.
        5. Apply ground calibration to radiances.
        6. Compute Earth-Sun distance, normalize to I/F.
        7. Filter out invalid channels.

    :param l1c_file:            Path to L1C product (HDF5/NetCDF).
    :param met_file:            Path to MET product (HDF5/NetCDF).
    :param valid_channels_dir:  Directory containing 'valid_channels_B*.dat'.
    :param ak_gnd_dir:          Directory containing 'ak_gnd_B*.txt'.
    :param sun_irradiance_file: Path to solar irradiance model file (ASCII).
    :param tun_file:            Path to TUN parameter file (text).
    :param site_json:           Path to MuscleNeo_sites.json (calibration sites).
    :return: A dict with preprocessed arrays:
                {
                "if_cube":       np.ndarray (nFs, nFov, nBand, nLambda),
                "wv_column":     np.ndarray (nFs, nFov),
                "acq_time":      np.ndarray or str,
                "tun_params":    dict,
                "site_dict":     dict,
                "earth_sun_au":  float,
                ...
                }
    """
    # 1. Load L1C
    from Mission.MicroCarb.src.microcarb_l1_product import MicroCarbL1C
    l1c = MicroCarbL1C(l1c_file)

    # Radiances & Lambdas
    radiances = l1c.extract_radiance().get_data()     # shape (nFs, nFov, nBand, nLambda)
    lambdas = l1c.extract_lambda().get_data()         # shape (nBand, nLambda)

    # Acquisition time (ISO string)
    try:
        # Try to read the AcquisitionTimeString from L1C
        raw_var = l1c.extract_acq_time_string().get_data()
        if isinstance(raw_var, np.ndarray):
            tmp = raw_var.item()
        else:
            tmp = raw_var
        if isinstance(tmp, (bytes, np.bytes_)):
            acq_time_str = tmp.decode()
        else:
            acq_time_str = str(tmp)

        if isinstance(acq_time_str, (list, np.ndarray)):
            doy = [convert_date_to_day_of_year(dt) for dt in acq_time_str]
        else:
            doy = [convert_date_to_day_of_year(acq_time_str)]
    except Exception:
        from datetime import datetime
        now_iso = datetime.utcnow().strftime("%Y-%m-%dT%H:%M:%S.%f")[:-3] + "Z"
        acq_time_str = now_iso
        doy = [convert_date_to_day_of_year(now_iso)]

    # Compute the earth-sun distance correction factor
    dist_cor_factor = compute_earth_sun_distance_correction_factor(doy)


    # 2. Load MET
    from Mission.MicroCarb.src.microcarb_met_product import MicroCarbMET
    met = MicroCarbMET(met_file)

    h2o_profile = met.extract_h2o_mixing_ratio_profile().get_data()        # shape (nFs, nFov, nLevel)
    surface_pressure = met.extract_surface_pressure().get_data()            # shape (nFs, nFov)
    # We assume pressure_grid is provided by Co2Data; if not, modify accordingly:
    pressure_grid = met.extract_co2_pressure_grid().get_data()               # shape (nFs, nFov, nLevel)

    # 3. Load exogenous inputs
    #  3.1 Valid channels
    valid_channels = load_all_valid_channels(valid_channels_dir)           # {band: [channels]}

    #  3.2 Ground calibration coefficients
    ak_gnd = load_all_ground_calibration_coefficients(ak_gnd_dir)           # {band: np.ndarray((M,2))}

    #  3.3 TUN parameters
    tun_params = load_tun_file(tun_file)                                     # Dict[str, str]

    #  3.4 Solar irradiance model
    sun_wl, sun_irr = load_sun_irradiance_model(sun_irradiance_file)         # each shape (N,)

    #  3.5 Calibration site JSON
    site_dict = load_calibration_sites(site_json)                            # parsed JSON dict

    # 4. Compute water-vapor column (cm)
    wv_column = compute_water_vapor_column(
        h2o_profile=h2o_profile,
        pressure_grid=pressure_grid,
        surface_pressure=surface_pressure
    )  # shape (nFs, nFov)

    # 5. Apply ground calibration to radiances
    calibrated_radiances = apply_ground_calibration(
        radiances=radiances,
        lambdas=lambdas,
        ak_gnd_dict=ak_gnd
    )  # shape (nFs, nFov, nBand, nLambda)

    # 6. Compute Earth-Sun distance (AU)
    earth_sun_au = compute_earth_sun_distance_from_iso(acq_time_str)

    # 7. Normalize to I/F
    if_cube = normalize_radiances_to_if(
        radiances=calibrated_radiances,
        lambdas=lambdas,
        sun_wavelengths=sun_wl,
        sun_irradiances=sun_irr,
        earth_sun_distance_au=earth_sun_au
    )  # shape (nFs, nFov, nBand, nLambda)

    # 8. Filter invalid channels
    if_cube_filtered = filter_invalid_channels(
        if_cube=if_cube,
        valid_channels_dict=valid_channels
    )  # same shape, invalid channels zeroed

    # Bundle results into a dictionary
    return {
        "acq_time": acq_time_str,
        "tun_params": tun_params,
        "site_dict": site_dict,
        "wv_column": wv_column,                       # (nFs, nFov)
        "calibrated_radiances": calibrated_radiances, # (nFs, nFov, nBand, nLambda)
        "if_cube": if_cube,                           # (nFs, nFov, nBand, nLambda)
        "if_cube_filtered": if_cube_filtered          # (nFs, nFov, nBand, nLambda)
    }
