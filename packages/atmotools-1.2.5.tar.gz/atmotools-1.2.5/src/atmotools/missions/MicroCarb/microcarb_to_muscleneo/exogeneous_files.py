# Copyright (c) 2024-2026 Centre National d'Etudes Spatiales (CNES).
#
# This file is part of AtmoTools
# (see https://github.com/CNES/AtmoTools).
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

"""
Mission/MicroCarb/src/exogeneous_files.py
-- Implements readers for all exogenous files (valid channels, TUN, ground coefficients, sun irradiance, calibration sites).
"""

import os
import json
from typing import Dict, List, Tuple
import numpy as np
from datetime import datetime


def read_valid_channels_files(file_path: str) -> dict:
    """
    Read the input 'valid_channels' file and extract its data (channels outside absorption lines).
    Return a dictionary composed of channel index and wavelength centers in µm: {channel_index: wl_center}

    :param file_path:
    :return: a dictionary of channels indexes and their wavelength centers
    """
    # Expected format: one column of wavelength centers in µm and one column of channel index
    nb_columns = 2
    # Output dictionary {channel number: channel value}
    result = {}

    with open(file_path, 'r') as f:
        for line in f:
            # Skip empty lines
            if line.strip():
                # Extract the values of the line as strings
                values_str = line.split()
                if len(values_str) != nb_columns:
                    raise ValueError(f"In file {file_path}, expected {nb_columns} columns in this line: {line}")
                # Convert the strings into float and int
                result[int(values_str[1])] = float(values_str[0])

    return result

def load_valid_channels_file(file_path: str) -> Dict[int, List[int]]:
    """
    Reads a flat text or whitespace?delimited file listing valid channels for a single MicroCarb band.
    Each line in the file is assumed to be an integer channel index. Returns a dict {band_index: [channel_indices]}.
    
    :param file_path: Path to a valid?channels file (e.g. 'valid_channels_B1.dat').
    :return: A dictionary mapping the band number (extracted from the filename) to its list of valid channels.
    """
    if not os.path.isfile(file_path):
        raise FileNotFoundError(f"Valid channels file not found: {file_path}")

    # Infer band index from filename, e.g. 'valid_channels_B1.dat' ? 1
    base = os.path.basename(file_path)
    try:
        # Expect pattern 'valid_channels_B<band>.dat'
        band_str = base.split("_")[-1].split(".")[0]  # 'B1'
        band_index = int(band_str.lstrip("B"))
    except (IndexError, ValueError):
        raise ValueError(f"Cannot parse band index from filename '{base}'")

    # Read all lines as integers
    with open(file_path, "r") as f:
        lines = f.readlines()

    # Filter out blank/comment lines, convert to ints
    channels: List[int] = []
    for ln in lines:
        ln = ln.strip()
        if not ln or ln.startswith("#"):
            continue
        try:
            channels.append(int(ln))
        except ValueError:
            raise ValueError(f"Invalid channel index '{ln}' in {file_path}")

    return {band_index: channels}


def load_all_valid_channels(directory: str) -> Dict[int, List[int]]:
    """
    Scans a directory for files named 'valid_channels_B<band>.dat' and returns a dict
    mapping each band_index ? list of valid channels.

    :param directory: Path to the folder containing all 'valid_channels_B*.dat' files.
    :return: A combined dictionary {band_index: [channel_indices]} for every file found.
    """
    if not os.path.isdir(directory):
        raise NotADirectoryError(f"Directory not found: {directory}")

    result: Dict[int, List[int]] = {}
    for fn in os.listdir(directory):
        if fn.startswith("valid_channels_B") and fn.endswith(".dat"):
            full_path = os.path.join(directory, fn)
            band_dict = load_valid_channels_file(full_path)
            # Each call returns a single?key dict; merge it
            result.update(band_dict)
    return result

def load_ground_calibration_coefficients(file_path: str) -> Dict[int, np.ndarray]:
    """
    Reads a text file listing ground calibration coefficients for a single band.
    Each line must contain two floats: wavelength (µm) and coefficient A_gnd.
    Infers the band index from the filename 'ak_gnd_B<band>.txt'.

    :param file_path: Path to a ground?calibration file (e.g. 'ak_gnd_B1.txt').
    :return: {band_index: np.ndarray of shape (N, 2)} where each row is [wavelength, coefficient].
    """
    if not os.path.isfile(file_path):
        raise FileNotFoundError(f"AK_GND file not found: {file_path}")

    base = os.path.basename(file_path)
    try:
        band_str = base.split("_")[-1].split(".")[0]  # 'B1'
        band_index = int(band_str.lstrip("B"))
    except (IndexError, ValueError):
        raise ValueError(f"Cannot parse band index from filename '{base}'")

    # Use numpy to load two?column float data
    try:
        data = np.loadtxt(file_path, dtype=np.float64)
    except Exception as e:
        raise RuntimeError(f"Failed to parse AK_GND file '{file_path}': {e}")

    # Handle single?line case (1D array of length 2)
    if data.ndim == 1:
        data = data.reshape(1, 2)

    # Ensure shape is (N, 2)
    if data.ndim != 2 or data.shape[1] != 2:
        raise ValueError(f"Unexpected format in AK_GND file '{file_path}'; expected 2 columns")

    return {band_index: data}


def load_all_ground_calibration_coefficients(directory: str) -> Dict[int, np.ndarray]:
    """
    Scans 'directory' for files named 'ak_gnd_B<band>.txt' and merges them into one dict:
    {band_index: array_of_[wavelength, coefficient]}.

    :param directory: Path containing all 'ak_gnd_B*.txt' files.
    :return: Combined dict for every band found.
    """
    if not os.path.isdir(directory):
        raise NotADirectoryError(f"Directory not found: {directory}")

    result: Dict[int, np.ndarray] = {}
    for fn in os.listdir(directory):
        if fn.startswith("ak_gnd_B") and fn.endswith(".txt"):
            full_path = os.path.join(directory, fn)
            band_dict = load_ground_calibration_coefficients(full_path)
            result.update(band_dict)
    return result

def load_tun_file(file_path: str) -> Dict[str, str]:
    """
    Reads a TUN file (assumed to be a simple key=value ASCII file),
    returns a dict {parameter_name: parameter_value}.

    :param file_path: Path to the TUN text file.
    :return: Dictionary of TUN parameters. If the file contains no '=' lines, returns {'content': <raw_text>}.
    """
    if not os.path.isfile(file_path):
        raise FileNotFoundError(f"TUN file not found: {file_path}")

    params: Dict[str, str] = {}
    with open(file_path, "r") as f:
        lines = f.readlines()

    for ln in lines:
        ln = ln.strip()
        if not ln or ln.startswith("#"):
            continue
        if "=" in ln:
            key, val = ln.split("=", 1)
            params[key.strip()] = val.strip()
        else:
            # Collect raw lines under a special key
            params.setdefault("content", "")
            params["content"] += ln + "\n"

    return params

def load_sun_irradiance_model(file_path: str) -> Tuple[np.ndarray, np.ndarray]:
    """
    Reads a solar irradiance model file (two?column ASCII: wavelength [µm], E_sun [W/m²/µm]).
    Returns (wavelengths, irradiances) as float64 NumPy arrays.

    :param file_path: Path to the irradiance data file (e.g. 'solar_SOLSPEC17-TOON16-LATMOS-EchTOON16_0325.dat').
    :return: Tuple (wavelengths, irradiances), each shape (N,).
    """
    if not os.path.isfile(file_path):
        raise FileNotFoundError(f"Sun irradiance file not found: {file_path}")

    try:
        data = np.loadtxt(file_path, dtype=np.float64)
    except Exception as e:
        raise RuntimeError(f"Failed to parse sun irradiance file '{file_path}': {e}")

    if data.ndim != 2 or data.shape[1] < 2:
        raise ValueError(f"Unexpected format in sun irradiance file '{file_path}'; expected ?2 columns")

    # First column: wavelength (µm), second column: irradiance (W/m²/µm)
    wavelengths = data[:, 0]
    irradiances = data[:, 1]
    return wavelengths, irradiances

def compute_earth_sun_distance(dt: datetime) -> float:
    """
    Approximates Earth?Sun distance in astronomical units (AU) for a given date, using:
        d = 1.00014 - 0.01671*cos(g) - 0.00014*cos(2*g),
        where g = 2?*(day_of_year - 1)/365.

    :param dt: A datetime object (UTC) corresponding to acquisition date.
    :return: Earth?Sun distance in AU.
    """
    if not isinstance(dt, datetime):
        raise TypeError("Input must be a datetime instance")

    day_of_year = dt.timetuple().tm_yday
    g = 2 * np.pi * (day_of_year - 1) / 365.0
    d_au = 1.00014 - 0.01671 * np.cos(g) - 0.00014 * np.cos(2 * g)
    return float(d_au)


def compute_earth_sun_distance_from_iso(iso_str: str) -> float:
    """
    Convenience wrapper: parse ISO?8601 date string, then call compute_earth_sun_distance().
    Accepts e.g. '2025-06-03T10:15:00Z' or '2025-06-03 10:15:00'.

    :param iso_str: ISO?formatted date/time string in UTC.
    :return: Earth?Sun distance in AU.
    """
    try:
        dt = datetime.fromisoformat(iso_str.replace("Z", "+00:00"))
    except Exception as e:
        raise ValueError(f"Invalid ISO date string '{iso_str}': {e}")
    return compute_earth_sun_distance(dt)

def load_calibration_sites(json_path: str) -> Dict:
    """
    Loads the MuscleNeo calibration sites JSON and returns it as a Python dict.

    :param json_path: Path to 'MuscleNeo_sites.json'
    :return: Parsed JSON as a dictionary.
    """
    if not os.path.isfile(json_path):
        raise FileNotFoundError(f"Calibration sites JSON not found: {json_path}")
    with open(json_path, "r") as f:
        try:
            sites_dict = json.load(f)
        except json.JSONDecodeError as e:
            raise RuntimeError(f"Failed to parse JSON '{json_path}': {e}")
    return sites_dict

