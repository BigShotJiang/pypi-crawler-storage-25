# Copyright (c) 2024-2026 Centre National d'Etudes Spatiales (CNES).
#
# This file is part of AtmoTools
# (see https://github.com/CNES/AtmoTools).
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

"""
    This file is the entry point of the MicroCarb visualization tool
    To run this script with custom entry files : 
    python app.py -eng <ENG_PATH> -rad <RAD_PATH> -ods <ODS_PATH>

    This script import the following script :
    - config.py : Contains constants of the visualization tool
    - services/data_manager.py : Allow the load and manipulate data
    - views/layout.py : Create all Dash components 
    - controllers/callbacks.py : Create all the callbacks of the Dash components
"""

from dash import Dash, Input, Output, State, callback, dcc, html, dash_table
from atmotools.missions.MicroCarb.services.data_manager import DataManager
from atmotools.missions.MicroCarb.views.layout import create_layout
from atmotools.missions.MicroCarb.controllers.callbacks import create_callbacks
from atmotools.missions.MicroCarb.config import DEFAULT_L1C, DEFAULT_L1B, DEFAULT_ISRF, DEFAULT_ENG, DEFAULT_L2, DEFAULT_MET, APP_PORT
import argparse

def init_app():

    #Argument parser
    parser = argparse.ArgumentParser()
    parser.add_argument("-l1c", "--L1C_PRODUCT", help = "L1C product files", nargs="*")
    parser.add_argument("-l1b", "--L1B_PRODUCT", help = "L1B product files", nargs="*")
    parser.add_argument("-isrf", "--ISRF", help = "ISRF product files", nargs="*")
    parser.add_argument("-eng", "--L1B_ENG", help = "L1B engineering files", nargs="*")
    parser.add_argument("-l2", "--L2_LITE", help = "L2 lite files", nargs="*")
    parser.add_argument("-met", "--MET", help = "MET files", nargs="*")
    args = parser.parse_args()

    l1cs = args.L1C_PRODUCT if args.L1C_PRODUCT else []
    l1bs = args.L1B_PRODUCT if args.L1B_PRODUCT else []
    isrfs = args.ISRF if args.ISRF else []
    engs = args.L1B_ENG if args.L1B_ENG else []
    l2s = args.L2_LITE if args.L2_LITE else []
    mets = args.MET if args.MET else []

    # Create the data manager to load and process data 
    data = DataManager(l1bs if (l1bs!=[] or l1cs!=[] or isrfs!=[] or engs!=[] or l2s!=[] or mets!=[]) else DEFAULT_L1B,  
                        l1cs if (l1bs!=[] or l1cs!=[] or isrfs!=[] or engs!=[] or l2s!=[] or mets!=[]) else DEFAULT_L1C, 
                        isrfs if (l1bs!=[] or l1cs!=[] or isrfs!=[] or engs!=[] or l2s!=[] or mets!=[]) else DEFAULT_ISRF, 
                        engs if (l1bs!=[] or l1cs!=[] or isrfs!=[] or engs!=[] or l2s!=[] or mets!=[]) else DEFAULT_ENG, 
                        l2s if (l1bs!=[] or l1cs!=[] or isrfs!=[] or engs!=[] or l2s!=[] or mets!=[]) else DEFAULT_L2, 
                        mets if (l1bs!=[] or l1cs!=[] or isrfs!=[] or engs!=[] or l2s!=[] or mets!=[]) else DEFAULT_MET)

    # Initialize the Dash app 
    app = Dash(name="MicroCarb Visu Tool", title="MicroCarb Visualization Tool")

    # Create de dash layout  
    app.layout = create_layout(data)

    # Create the callbacks
    create_callbacks(app, data)

    return app, data

def main():
    
    # Create app 
    app, data = init_app()

    # Run the app 
    app.run(debug=True, use_reloader=False, port=APP_PORT) 

    # Close the files and delete the readers to ensure there is no data corruption
    data._close_products()

if __name__ == '__main__':
    
    # Create app 
    app, data = init_app()

    # Run the app 
    app.run(debug=True, use_reloader=False, port=APP_PORT) 

    # Close the files and delete the readers to ensure there is no data corruption
    data._close_products()