# Copyright (c) 2024-2026 Centre National d'Etudes Spatiales (CNES).
#
# This file is part of AtmoTools
# (see https://github.com/CNES/AtmoTools).
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

import plotly.express as px
import pandas as pd

import atmotools.utils.path_utils as pu

from atmotools.missions.MicroCarb.config import MAP_STYLE


def show_empty_spectra(title = "Spectrum Band"):
    empty_df = pd.DataFrame(columns = ["Fov Index", "Lambda", "Radiance"])
    figure = px.line(empty_df, x='Lambda', y='Radiance', color = 'Fov Index', title= title, height = 400)
    return figure

def trace_spectrum(spc_df, title, hover_data, color, legend = None, facet_col = None):
    """
        This function return the figure with the spectrum for all selected fovs

        :param: spc_df : pandas_DataFrame() : Data of the spectra
        :param: title : str : Title of the figure
        :param: hover_data : dict : Data display when data on the figure is hover by cursor.
        :param: color : str : Name of the dataframe column used for the color 
        :param: legend : dict() : Information to display as a legend of the figure.
        :param: facet_col : str : Name of the dataframe column used to separte the figure (in column).
        :return: fig : plotly.figure : Plot of the spectrum
    """

    fig = px.line(spc_df, x='Lambda', y='Radiance', color = color,
                          title= title, height=400,
                          hover_data= hover_data,
                          facet_col= facet_col)

    fig.update_layout(xaxis = dict(title = dict(text = "Lambda (µm)")), 
                        yaxis = dict(title = dict(text = "Radiance (W/m²/sr/µm)")), 
                        legend= legend )
    return fig

def show_empty_map():
    fig = px.scatter_map(pd.DataFrame({"Latitude": [], "Longitude": []}), lat="Latitude", lon="Longitude",
                                zoom = 4, height=800, width = 900)
    return fig

def show_scatter_on_map(df, color, filtermap, range_color_value, layers):
    """
        This function create a map with scatter point.
        :param: df : pd.DataFrame : The dataframe with all coordinates of all fovs
        :param: color :  pd.DataFrame : The name of the selected variable and the values
        :param: filtermap : str : Name of the selected variable for the color
        :param: range_color_value :  list() : Lis of two elements for color boundaries : [min, max]  
    """

    fig = px.scatter_map(df.dropna(subset=['Latitude','Longitude']).join(color), lat="Latitude", lon="Longitude", hover_name="Fov index",
                        hover_data={"Acquisition Time" : df["File_acq_id"],
                                "file" : df["File index"].dropna(),
                                "fs" : df["Fs"].dropna(),
                                "fov" : df["Fov"].dropna()},
                        zoom = 4,
                        height=800, width = 900,
                        color = filtermap if filtermap != "None" else None,
                        color_continuous_scale="jet",
                        range_color = range_color_value)
    
    fig.update_layout(margin={"r":0,"t":0,"l":0,"b":0},
                clickmode='event+select',
                map_style=MAP_STYLE,
                legend=dict(
                            yanchor="top",
                            y=0.99,
                            xanchor="right",
                            x=0.99),
                map = {'style': MAP_STYLE,
                    'layers' : layers
                    })

    return fig

def show_cloud_index_mean(files_df_mean):

    fig = px.line(files_df_mean,
                            title= 'Cloud Index mean along orbit for each Fov', height=400)
    fig.update_layout(xaxis=dict(title=dict(text="Acquisition Time")), 
                yaxis=dict(title=dict(text="Mean")), 
                legend=dict(title=dict(text="Fov")))
    return fig

def show_met_graph(profile_df, title, x, y, hover_data):

    fig = px.line(profile_df, x=x, y=y, color = 'Fov Index',
            title=title, height=400,
            hover_data = hover_data)
    fig.update_layout(xaxis = dict(title = dict(text = f"{x} {'(µm)' if x == 'Lambda' else ''}")),
            yaxis = dict(title = dict(text = f"{pu.get_last_element_in_path(y)[0]}")), 
            legend=dict(title=dict(text="Fov Index (Fs, Fov, File)")))
    return fig

def trace_isrf(spc_df, title, hover_data): 

    fig = px.line(spc_df, 
                    x='Lambda', 
                    y='SceneIsrf', 
                    color = 'Fov Index', 
                    title= title, 
                    height=400,
                    hover_data = hover_data)
    fig.update_layout(xaxis = dict(title = dict(text = "Lambda (µm)")), 
                legend=dict(title=dict(text="Fov Index (Fs, Fov, File)")))

    return fig