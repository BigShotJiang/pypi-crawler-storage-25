# Copyright (c) 2024-2026 Centre National d'Etudes Spatiales (CNES).
#
# This file is part of AtmoTools
# (see https://github.com/CNES/AtmoTools).
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

import os

import numpy as np
import pandas as pd

import atmotools.utils.path_utils as pu

import atmotools.missions.MicroCarb.models.microcarb_l1_product as mcal1
import atmotools.missions.MicroCarb.models.microcarb_l2_product as mcal2
import atmotools.missions.MicroCarb.models.microcarb_met_product as mcamet

from atmotools.missions.MicroCarb.config import DATA_FOLDER_PATH, CSV_SEPARATOR

class DataManager:

    def __init__(self, l1b_paths: list[str | None], l1c_paths: list[str | None], isrf_paths: list[str | None], l1b_eng_paths: list[str | None], l2_lite_paths: list[str | None], met_paths: list[str | None]):

        # Booleans for feature disabling
        self.isL1B = l1b_paths != []
        self.isL1C = l1c_paths != []
        self.isISRF = isrf_paths != []
        self.isL1BENG = l1b_eng_paths != []
        self.isL2 = l2_lite_paths != []
        self.isMET = met_paths != []

        print("---- Input files ----")
        print(f"L1B file(s) provided as input : {self.isL1B}")
        print(f"L1C file(s) provided as input : {self.isL1C}")
        print(f"ISRF file(s) provided as input : {self.isISRF}")
        print(f"L1BENG file(s) provided as input : {self.isL1BENG}")
        print(f"L2 file(s) provided as input : {self.isL2}")
        print(f"MET file(s) provided as input : {self.isMET}")
        print("---------------------")

        #  Get necessary info from the files
        self.l1b_products, self.l1c_products, self.isrf_products, self.l1b_eng_products, self.l2_products, self.met_products, self.all_products, self.all_acqu_ids = self._load_product(l1b_paths, l1c_paths, isrf_paths, l1b_eng_paths, l2_lite_paths, met_paths)
        print("------------all_products------------\n",self.all_products,"\n------------end all_products------------")

        # Group all the fov coordinates of all files in a single dataframe if there are L1 files or MET File
        if self.isL1C or self.isL1B or self.isISRF or self.isMET:

            self.df, self.file_index_to_prod, self.df_pif = self._load_coordinates()

            # Group all fov full shapes in a list of geojsons
            self.features = self.get_geojson_geometry()

            # Group all Pif vertices full shapes in a list of geojsons
            self.features_PifVertices = self.get_geojson_geometry_for_pif() if self.isL1C or self.isL1B  else None

            self.df.info()
 
        # Create dict of var_paths for all products of all files. dict() structure : { acqu_id: { product_name: [met variables], product_name: [L1B variables], ...}}
        self.var_paths = self.get_all_var_paths()

        # Get continuum data if there are L1B files
        # Contains variable data loaded at the start of the application
        self.preloaded_variable_df = self.get_continuum_data() if self.isL1B else pd.DataFrame() 

        # Itilialize spectra DataFrame 
        self.spectra_df = dict()  

    
    def _load_product(self, l1b_paths: list[str | None], l1c_paths: list[str | None], isrf_paths: list[str | None], l1b_eng_paths: list[str | None], l2_lite_paths: list[str | None], met_paths: list[str | None]):
        ### GET NECESSARY INFO FROM THE FILES
        # Create a product for each of the files to show and store them in lists
        l1b_products = {mcal1.MicroCarbL1B(l1b_path, useXarray=False).get_acquisition_id(): mcal1.MicroCarbL1B(l1b_path, useXarray=False) for l1b_path in l1b_paths}
        l1c_products = {mcal1.MicroCarbL1C(l1c_path, useXarray=False).get_acquisition_id(): mcal1.MicroCarbL1C(l1c_path, useXarray=False) for l1c_path in l1c_paths}
        isrf_products = {mcal1.MicroCarbISRF(isrf_path, useXarray=False).get_acquisition_id(): mcal1.MicroCarbISRF(isrf_path, useXarray=False) for isrf_path in isrf_paths}
        l1b_eng_products = {mcal1.MicroCarbL1BENG(l1b_eng_path, useXarray=False).get_acquisition_id(): mcal1.MicroCarbL1BENG(l1b_eng_path, useXarray=False) for l1b_eng_path in l1b_eng_paths}
        l2_products = {mcal2.MicroCarbL2(l2_lite_path, useXarray=False).get_acquisition_id(): mcal2.MicroCarbL2(l2_lite_path, useXarray=False) for l2_lite_path in l2_lite_paths}
        met_products = {mcamet.MicroCarbMET(met_paths, useXarray=False).get_acquisition_id(): mcamet.MicroCarbMET(met_paths, useXarray=False) for met_paths in met_paths}
        all_products = dict()
        all_acqu_ids = list(set(list(l1b_products.keys()) + list(l1c_products.keys()) + list(isrf_products.keys()) + list(l1b_eng_products.keys()) + list(l2_products.keys()) + list(met_products.keys())))
        for i, key in enumerate(all_acqu_ids):
            all_products[key] = {"Acquisition time": key,
                                "L1B": l1b_products[key] if key in l1b_products.keys() else None,
                                "L1C": l1c_products[key] if key in l1c_products.keys() else None,
                                "L1B-ISRF": isrf_products[key] if key in isrf_products.keys() else None,
                                "L1B-ENG": l1b_eng_products[key] if key in l1b_eng_products.keys() else None,
                                "L2": l2_products[key] if key in l2_products.keys() else None,
                                "MET": met_products[key] if key in met_products.keys() else None}
        return l1b_products, l1c_products, isrf_products, l1b_eng_products, l2_products, met_products, all_products, all_acqu_ids

    def _close_products(self):
        # Close the files and delete the readers to ensure there is no data corruption
        for l1b_id in self.l1b_products:
            del self.l1b_products[l1b_id].reader
        for l1c_id in self.l1c_products:
            del self.l1c_products[l1c_id].reader
        for isrf_id in self.isrf_products:
            del self.isrf_products[isrf_id].reader
        for l1b_id in self.l1b_eng_products:
            del self.l1b_eng_products[l1b_id].reader
        for l2_id in self.l2_products:
            del self.l2_products[l2_id].reader

    def _load_coordinates(self):
        # Group all the fov coordinates of all files in a single dataframe if there are L1 files or MET File
        file_index_to_prod = dict()
        df = pd.DataFrame()
        df_pif = pd.DataFrame()
        i = 0
        for id in self.all_products:
            l1_product = self.all_products[id]['L1B'] if self.all_products[id]['L1B'] \
                    else self.all_products[id]['L1C'] if self.all_products[id]['L1C'] \
                    else self.all_products[id]['L1B-ISRF'] if self.all_products[id]['L1B-ISRF'] \
                    else self.all_products[id]['MET'] if self.all_products[id]['MET'] \
                    else None
            if not l1_product:
                continue
            df_new = l1_product.get_all_coordinates()
            df_new["File index"] = i
            df_new["File_acq_id"] = id
            file_index_to_prod[i] = id
            i += 1
            df = pd.concat([df, df_new], ignore_index=True)

            if self.isL1C or self.isL1B :
                df_new_pif = l1_product.get_pif_vertices()
                df_new_pif["File index"] = i
                df_pif = pd.concat([df_pif, df_new_pif], ignore_index=True) #UPGRADETODO 
        # Delete rows where there is no information on latitude or longitude
        df.dropna(inplace=True)
        # Dataframe with separate columns for lines, fors and fovs
        parsed = df['Fov index'].apply(lambda x: pd.Series({'Fs': x[0], 'Fov': x[1]}))
        filtered_df = df.join(parsed)
        df = filtered_df
        
        return df, file_index_to_prod, df_pif

    def get_geojson_geometry(self, fss = None, fovs = None):
        """
            This method create fovs circle as GeoJSON multiPolygons

            :param: lines : list(<int>)
            :param: fors : list(<int>)
            :param: fovs : list(<int>)
            :param: selected_files : list(<str>)

            :return: features : dict()  
        """
        if not fss and not fovs :
                selected_df = self.df
        else:
            selected_df = self.mask(fss, fovs)
            
        features = [
                {
                'type': 'Feature',
                'geometry': {
                    'type': 'MultiPolygon',
                    'coordinates': [[coords + [coords[0]] if coords[0] != coords[-1] else coords]]
                }
            }
            for coords in selected_df['Coordinates'] if coords and coords == coords]
        return features

    def get_geojson_geometry_for_pif(self, fss = None, fovs = None, pif_acts = None, pif_alts = None):
        """
            This method create fovs circle as GeoJSON multiPolygons

            :param: lines : list(<int>)
            :param: fors : list(<int>)
            :param: fovs : list(<int>)
            :param: selected_files : list(<str>)

            :return: features : dict()  
        """
        if not fss and not fovs and not pif_acts and not pif_alts:
                selected_df = self.df_pif
        else:
            selected_df = self.mask_pif(fss, fovs, pif_acts, pif_alts)
            
        features = [
                {
                'type': 'Feature',
                'geometry': {
                    'type': 'MultiPolygon',
                    'coordinates': [[coords + [coords[0]] if coords[0] != coords[-1] else coords]]
                }
            }
            for coords in selected_df['Coordinates'] if coords and coords == coords]
        return features

    def get_all_var_paths(self):
        # Create dict of var_paths for all products of all files. dict() structure : { acqu_id: { product_name: [met variables], product_name: [L1B variables], ...}}
        var_paths = {}
        for acqu_id, products in self.all_products.items():
            var_paths[acqu_id] = {}
            for product_name, product in products.items() :
                if product_name in ["L1B", "L1C", "L1B-ISRF", "L1B-ENG", "MET"] and product != None:
                    all_vars = product.get_reader().describe_all_vars(call_print= False)
                    var_paths[acqu_id][product_name] = [variable for variable in all_vars.keys() \
                            if list(all_vars[variable]["dimensions"].keys()) == [product.N_FS_DIM,
                                                                                product.N_FOV_DIM]]
                elif product_name in ["L2"] and product != None :
                    all_vars = product.get_reader().describe_all_vars(call_print= False)
                    var_paths[acqu_id][product_name] = [variable for variable in all_vars.keys() \
                            if list(all_vars[variable]["dimensions"].keys()) == [product.SOUNDINGID_DIM]]
        return var_paths

    def get_continuum_data(self):
        for acqu_id, l1b_product in self.l1b_products.items():
            # Get meanRadiance value for each product
            vals_meanradiance = l1b_product.get_mean_radiance()
        df_vals_meanradiance = pd.DataFrame(vals_meanradiance)
        # Merge data with df by Fs and Fov
        preloaded_variable_df = pd.merge(self.df, df_vals_meanradiance.drop(columns=['Latitude', 'Longitude']), how = 'outer') # It's a better practice to join dataframes on Fs and Fov
        return preloaded_variable_df 

    def select(self, selectedData):
        """ 
            This method return select fovs using selectedData and selected_file

            :param: selectedData: dict() : Contains file, line, for, fov indexes
            :return: selected_fovs : list( list(int)) : List of all selected fovs
        """
        if not selectedData :
            return [] 
        else : 
            selected_fovs = [] 
            # Get the info for all selected fovs (i.e. file number, fs and fov)
            for point in selectedData['points']:
                dff = self.df[self.df['Latitude'] == point['lat']]
                dff = dff[dff['Longitude'] == point['lon']]
                fs = (dff["Fs"].values[0])
                fov = (dff["Fov"].values[0])
                file = (dff["File index"].values[0])
                selected_fovs.append([fs, fov, file])

        return selected_fovs

    def get_spectra_data(self, fovs, nband :int):
        """ 
            This method return data related to spectrum of selected fovs

            :param: fovs : list( list(int)) : List of all selected fovs
            :param: nband : int : int of the selected band
            :return: spc_df : pd.DataFrame : Spectrum data in a DataFrame
        """
        spc = {'File': [], 'Fov Index': [], 'Lambda': [], 'Radiance': []}
        for fov in fovs:
            if tuple(fov) in spc["Fov Index"]:
                continue
            # Get the correct product from file number of fov
            acq_id = self.file_index_to_prod[fov[2]]
            l1b_product = self.all_products[acq_id]['L1B']
            l1c_product = self.all_products[acq_id]['L1C']
            if not l1b_product and not l1c_product:
                print(f"ERROR: No L1B PRODUCT or L1C PRODUCT file for acqusition time {acq_id}. Please make sure to upload the corresponding file.")
                continue
            if not l1b_product:
                print(f"ERROR: No L1B PRODUCT file for acqusition time {acq_id}. Please make sure to upload the corresponding file.")
            if not l1c_product:
                print(f"ERROR: No L1C PRODUCT file for acqusition time {acq_id}. Please make sure to upload the corresponding file.")
            # Get the spectrum values for each selected fov
            spectra = [l1b_product.get_spectrum_from_fov(nfs = fov[0], nfov = fov[1], nband = nband) if l1b_product else None,
                       l1c_product.get_spectrum_from_fov(nfs = fov[0], nfov = fov[1], nband = nband) if l1c_product else None]
            for spectrum in spectra:
                if spectrum:
                    spc["File"] += (spectrum['File'])
                    spc["Fov Index"] += (tuple(fov) for i in range(len(spectrum["Radiance"])))
                    spc["Lambda"] += (spectrum["Lambda"])
                    spc["Radiance"] += (spectrum["Radiance"])
        spc_df = pd.DataFrame(spc, columns=['File', 'Fov Index', 'Lambda', 'Radiance'])

        self.spectra_df[nband] = spc_df  

        return spc_df

    def export_spectra_as_csv(self):
        folder_path = os.path.join(DATA_FOLDER_PATH,"microcarb_spectra")
        if not os.path.isdir(folder_path):
            os.makedirs(folder_path)
        for nband, spc_df in self.spectra_df.items():
            file_name = f"spectrum_band_{nband}.csv"
            file_path =  os.path.join(folder_path,file_name)
            spc_df.to_csv(file_path, sep = CSV_SEPARATOR, index=False)
            print(f"INFO : Spectra saved in {file_path}")

    def mask(self, fss, fovs):
        """
            This method return values of the dataframe corresponding to the selection ( fss, fovs)

            :param: fss : list(<int>)
            :param: fovs : list(<int>)

            :return: filtered_df : pandas.DataFrame()
        """
        if not fss and not fovs : 
            return self.df
        mask = (
                    (self.df['Fs'].isin(fss) if fss else True) &
                    (self.df['Fov'].isin(fovs) if fovs else True)
                )
        return self.df[mask]
    
    def mask_pif(self, fss, fovs, pif_acts, pif_alts): #UPGRADETODO 
        """
            This method return values of the PIF dataframe corresponding to the selection (fss, fovs, pif_acts, pif_alts)

            :param: fss : list(<int>)
            :param: fovs : list(<int>)
            :param: pif_acts : list(<int>)
            :param: pif_alts : list(<int>)

            :return: pandas.DataFrame()
        """
        if not fss and not fovs and not pif_acts and not pif_alts : 
            return self.df
        mask_pif = (
            (self.df_pif['Fs'].isin(fss) if fss else True) &
            (self.df_pif['Fov'].isin(fovs) if fovs else True)&
            (self.df_pif['PifAct'].isin(pif_acts) if pif_acts else True)&
            (self.df_pif['PifAlt'].isin(pif_alts) if pif_alts else True)
            )
        return self.df_pif[mask_pif]

    # Get values of the selected variable for colorscale of the map #UPGRADETODO 
    def get_color(self, var_path):
        if var_path not in self.preloaded_variable_df.columns : # Do not get the data again if already in the dataframe.
            # Find the product which have the selected variables
            vals_dict = {}
            i = 0
            for acq_id, products in self.var_paths.items():
                for product_name, variables in products.items() :
                    if var_path in variables :
                        selected_product_name = product_name
                        break
                    else :
                        continue

                selected_product =  self.all_products[acq_id][selected_product_name]

                # Get the data of the selected variable from the product previously found
                data = selected_product.get_var(var_path)

                # data['File index'] = [i for _ in range(len(data[var_path]))] # A REVOIR
                vals_dict.update(data)

                i += 1

            df_vals = pd.DataFrame(vals_dict)

            # Case of L2 files which have not the exact same latitude and longitude as L1B (use L1C Latitude and longitude to merge with df)
            if product_name == 'L2' and self.isL1C :
                df_vals_l1c = pd.DataFrame(self.all_products[acq_id]['L1C'].get_var('CloudFlags/CloudIndex'))
                df_vals = pd.merge(df_vals, df_vals_l1c, how = 'outer')

            df_vals = pd.merge(pd.DataFrame(self.df), df_vals.drop(columns=['Latitude', 'Longitude']), how = 'outer')
            return df_vals[var_path]

        else :
            return self.preloaded_variable_df[var_path]

    # Get mean of cloud index for each Fov, along the files (orbit) for each file
    def get_cloud_index_mean(self):

        files = {"Acquisition Time": [], "Mean": []}
        # Get mean of cloud index for each Fov, along the files (orbit)
        for acq_id, l1c_product in self.l1c_products.items():
            files["Mean"] += [list(l1c_product.extract_cloud_index().get_mean(l1c_product.N_FS_DIM))]
            files['Acquisition Time'] += [acq_id]

        files_df_mean = pd.DataFrame(files["Mean"],
                            columns=[f"Fov {i}" for i in range(len(files["Mean"][0]))],
                            index=files['Acquisition Time']).sort_index()

        return files_df_mean

    # Get data of a specific variable equivalent to a profile.  
    def get_profile_data(self, variable, selected_fovs):
        """
            This method return data of a variable equivalent to a profile for the selected fovs.
            For the moment, we have Lambda values only for AerosolData #UPGRADETODO 

            :param: variable : str : path and name of the selected variable
            :param: selected_fovs : list(<int>) : list of the selectedfovs

            :return: var_df : pandas.DataFrame()
        """

        isAerosolData = pu.get_last_element_in_path(variable)[1] == "AerosolData"
        var_dict ={"Fov Index": [], "Lambda" if isAerosolData else "Index": [], variable: []}

        for fov in selected_fovs:

            # Get the correct product from file number of fov
            acq_id = self.file_index_to_prod[fov[2]]
            met_product = self.all_products[acq_id]['MET']

            if not met_product :
                print(f"ERROR: No MET PRODUCT file for acqusition time {acq_id}. Please make sure to upload the corresponding file.")
                continue
            
            profile_data = met_product.get_aerosol_data(variable, fov[0], fov[1]) if isAerosolData else met_product.get_profile_data(variable, fov[0], fov[1])

            var_dict["Fov Index"] += (tuple(fov) for i in range(len(profile_data[variable])))
            if isAerosolData :
                var_dict["Lambda"] += (profile_data["Lambda"])
            else :
                var_dict['Index'] += [i for i in range(len(profile_data[variable]))]  
            var_dict[variable] += (profile_data[variable])

        var_df = pd.DataFrame(var_dict, columns=['Fov Index', 'Lambda', variable]) if isAerosolData else pd.DataFrame(var_dict, columns=['Fov Index', 'Index', variable])
        return var_df

    # Return the corresponding product (L1B, L1C, L1B-ENG, L2, MET, ISRF)of the selected fov  
    def get_products(self, selected_fovs, product_name : str, second_option_product_name = None):
        """
            This method return the selected product of a selected fovs
            If the product is not avaible for the selected fov, it's possible to specify another product to return. 

            :param: selected_fovs : list(<int>) : list of the selectedfovs
            :param: product_name : str : L1B, L1C, L1B-ENG, ISRF, MET, L2
            :param: second_option_product_name : str : L1B, L1C, L1B-ENG, ISRF, MET, L2

            :return: selected_files : list() : List of selected products.
        """
        second_option_product_name = product_name if second_option_product_name else second_option_product_name 
        selected_files = []
        for fov in selected_fovs:
            acq_id = self.file_index_to_prod[fov[2]]
            product = self.all_products[acq_id][product_name] if self.all_products[acq_id][product_name] else \
                    self.all_products[acq_id][second_option_product_name] if self.all_products[acq_id][second_option_product_name] else None
            if not product:
                print(f"ERROR: No L1B ENG file found for point ({fov}) of acquisition time {acq_id}")
                continue
            selected_files.append(product)
        return selected_files
  
    def get_min_wavelength(self, file):
        lambda_var = file.extract_var(file.LAMBDA_PATH)
        min_l = lambda_var.get_min([mcal1.AbstractMicroCarb_L1.N_FS_DIM,
                                    mcal1.AbstractMicroCarb_L1.N_FOV_DIM,
                                    mcal1.AbstractMicroCarb_L1.N_BAND_DIM,
                                    mcal1.AbstractMicroCarb_L1.N_LAMBDA_DIM])
        return min_l

    def get_max_wavelength(self, file):
        lambda_var = file.extract_var(file.LAMBDA_PATH)
        max_l = lambda_var.get_max([mcal1.AbstractMicroCarb_L1.N_FS_DIM,
                            mcal1.AbstractMicroCarb_L1.N_FOV_DIM,
                            mcal1.AbstractMicroCarb_L1.N_BAND_DIM,
                            mcal1.AbstractMicroCarb_L1.N_LAMBDA_DIM])
        return max_l

    def get_total_wavelength(self, file): 
        lambda_var = file.extract_var(file.LAMBDA_PATH)
        return lambda_var.dimensions[mcal1.AbstractMicroCarb_L1.N_LAMBDA_DIM]

    def get_min_pif_wavelength(self, file):
        lambda_var = file.extract_var(file.PIFLAMBDA_PATH)
        return lambda_var.get_min()

    def get_max_pif_wavelength(self, file):
        lambda_var = file.extract_var(file.PIFLAMBDA_PATH)
        return lambda_var.get_max()

    def get_total_pif_wavelength(self, file): 
        lambda_var = file.extract_var(file.PIFLAMBDA_PATH)
        return lambda_var.dimensions[file.N_PIFLAMBDA_DIM]

    # Get isrf data for the selected fovs 
    def get_isrf_data(self, fovs, nband :int, nwl):
        spc = {'Fov Index': [], 'Lambda': [], 'SceneIsrf': []}
        for fov in fovs:
            if tuple(fov) in spc["Fov Index"]:
                continue
            # Get the correct product from file number of fov
            acq_id = self.file_index_to_prod[fov[2]]
            isrf_product = self.all_products[acq_id]['L1B-ISRF']
            if not isrf_product:
                print(f"ERROR: No ISRF file for acquisition time {acq_id}. Please make sure to upload the corresponding file.")
                continue
            l1_product = self.all_products[acq_id]['L1C'] if self.all_products[acq_id]['L1C'] else self.all_products[acq_id]['L1B'] if self.all_products[acq_id]['L1B'] else None
            if not l1_product:
                print(f"ERROR: No L1 file for acquisition time {acq_id}. Please make sure to upload the corresponding file.")
                continue
            
            # Get the ISRF values for each fov
            sceneisrf = isrf_product.get_isrf_from_fov(l1_product = l1_product, nfs=fov[0], nfov=fov[1], nband=nband, nlambda=nwl)
            spc["Fov Index"] += (tuple(fov) for i in range(len(sceneisrf["SceneISRF"])))
            spc["Lambda"] += (sceneisrf["Lambda"])
            spc["SceneIsrf"] += (sceneisrf["SceneISRF"])
        return pd.DataFrame(spc, columns=['Fov Index', 'Lambda', 'SceneIsrf'])

    # Get pif isrf data for the selected fov  
    def get_pifisrf_data(self, fov, nband :int, nwl):
        acq_id = self.file_index_to_prod[fov[2]]
        l1b_eng_product = self.all_products[acq_id]['L1B-ENG']
        if not l1b_eng_product:
            print(f"ERROR: No L1B ENG file for acquisition time {acq_id}. Please make sure to upload the corresponding file.")
            return None
        pifs = l1b_eng_product.get_pifisrf_from_fov(nfs = fov[0], nfov = fov[1], nwl = nwl, nband = nband)
        return pd.DataFrame(pifs, columns=['Pif Index', 'Lambda', 'SceneISRF']) 
