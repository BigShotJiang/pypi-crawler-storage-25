# Copyright (c) 2024-2026 Centre National d'Etudes Spatiales (CNES).
#
# This file is part of AtmoTools
# (see https://github.com/CNES/AtmoTools).
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

"""
Mission/MicroCarb/src/microcarb_l2_product.py
-- Defines a data model for opening and querying a MicroCarb L2 product,
   based on the fields listed in Microcab_L2_extract_read_fields_from_metadata.csv.
"""

import atmotools.utils.hdf_netcdf_tools as hdfu
import atmotools.utils.path_utils as pu

class MicroCarbL2:
    """
    This class opens a MicroCarb L2 file and exposes all variables
    listed in the L2 metadata CSV.

    Attributes:
        file_path(str): the path of the L2 file
        reader: the file reader
    """
    # Names of dimensions
    SOUNDINGID_DIM = "SoundingId"

    # Paths of variables
    SOUNDINGID_LAT_PATH = "latitude"
    SOUNDINGID_LON_PATH = "longitude"
    CO2_COLUMN_PATH = "RetrievalResults/Co2Column"
    H2O_COLUMN_PATH = "RetrievalResults/H2oColumn"
    PSURF_PATH = "RetrievalResults/Psurf"
    MID_BAND_SIF_PATH = "RetrievalResults/MidBandSif"
    AIRGLOW_WARM_PATH = "RetrievalResults/AirglowWarm"
    AIRGLOW_COLD_PATH = "RetrievalResults/AirglowCold"
    AEROSOL_AOT_PATH = "RetrievalResults/AerosolAot"
    AEROSOL_Z_PATH = "RetrievalResults/AerosolZ"
    AEROSOL_K_PATH = "RetrievalResults/AerosolK"

    def __init__(self, file_path: str, useXarray = False) -> None:
        """
        :param: l2_file_path: Path to the MicroCarb L2 HDF5/NetCDF product.
        :param: useXarray: if set to True, the product reader will use the xarray library instead of netcdf.
        """
        self.file_path = file_path
        self.reader = hdfu.createReader(file_path, useXarray=useXarray)
        if self.get_product_level() != "2L_PRODUCT":
            raise f"ERROR: {self.file_path} is not an L1C RAD file."

    def get_file_path(self) -> str:
        """
        Return the file path of the product.

        :return: file path
        """
        return self.file_path

    def get_reader(self) -> hdfu.AbstractHDFReader:
        """
        Return the reader corresponding to the product

        :return: the product reader
        """
        return self.reader

    def get_file_name(self) -> str:
        """
        Extract the file name of the product from its file path.

        :return: file name
        """
        return pu.get_last_element_in_path(self.get_file_path())[0]

    def get_acquisition_id(self) -> str:
        """
        Extract the acquisition id of the product from its file path.

        :return: file name
        """
        return self.get_file_name()[18:49]

    def get_product_level(self) -> str:
        """
        Extract the level of the product from its file path.

        :return: file name
        """
        return self.get_file_name()[7:17]

    def extract_var(self, var_path) -> hdfu.HDFVariable:
        """
        Return the HDFVariable corresponding to a given variable path

        :param: var_path: path of the variable to extract
        :return: corresponding variable
        """
        return self.get_reader().get_var(var_path)

    def get_co2_colums(self) -> dict:
        """
        Return the value sof the CO2 column

        :return: dictionnary of the CO2 values and their corresponding coordinates
        """
        return self.get_var(self.CO2_COLUMN_PATH)

    def get_h2o_colums(self) -> dict:
        """
        Return the values of the H2O column

        :return: dictionnary of the H2O values and their corresponding coordinates
        """
        return self.get_var(self.H2O_COLUMN_PATH)
    
    def get_psurf(self) -> dict:
        """
        Return the values of psurf
        :return: dictionnary of the psurf values and their corresponding coordinates
        """
        return self.get_var(self.PSURF_PATH)
    
    def get_mid_band_sif(self) -> dict:
        """
        Return the values of MidBandSif
        MidBandSif : Retrieved fluorescence emission at the mid-wavelength of the band (B1- strong O2)', 'Unit': 'W/m²/sr/µm
        :return: dictionnary of the psurf values and their corresponding coordinates
        """
        return self.get_var(self.MID_BAND_SIF_PATH)

    def get_airglow_warm(self) -> dict:
        """
        Return the values of AirGlowWarm
        AirGlowWarm : Retrieved warm airglow emission in B4, 'Unit': 'W/m²/sr/µm
        :return: dictionnary of the AirGlowWarm values and their corresponding coordinates
        """
        return self.get_var(self.AIRGLOW_WARM_PATH)

    def get_airglow_cold(self):
        """
        Return the values of the AirGlowCold
        AirGlowCold : Retrieved cold airglow emission in B4, 'Unit': 'W/m²/sr/µm'
        :return: dictionnary of the AirGlowCold values and their corresponding coordinates
        """
        return self.get_var(self.AIRGLOW_COLD_PATH)

    def get_aerosol_aot(self):
        """
        Return the values of the AerosolAot
        AerosolAot : Retrieved Aerosol Optical Thickness, 'Unit': '-'
        :return: dictionnary of the AerosolAot values and their corresponding coordinates
        """
        return self.get_var(self.AEROSOL_AOT_PATH)

    def get_aerosol_z(self):
        """
        Return the values of the AerosolZ
        AerosolZ : Retrieved Gaussian height aerosol distribution, 'Unit': 'km'
        :return: dictionnary of the AerosolZ values and their corresponding coordinates
        """
        return self.get_var(self.AEROSOL_Z_PATH)

    def get_aerosol_k(self):
        """
        Return the values of the AerosolK
        AerosolK : Retrieved Ångström coefficient, 'Unit': '-'
        :return: dictionnary of the AerosolK values and their corresponding coordinates
        """
        return self.get_var(self.AEROSOL_K_PATH)


    def get_var(self,var_path: str) -> dict:
        """
            Return values of a variable and their corresponding coordinates
            :return dictionnary{Latitude: [], Longitudes: [], Values: []} 
        """
        latitude_var = self.extract_var(self.SOUNDINGID_LAT_PATH)
        longitude_var = self.extract_var(self.SOUNDINGID_LON_PATH)
        try :
            var = self.extract_var(var_path)
        except Exception as e: 
            print(e)
            return {'Latitude': [], 'Longitudes': [], var_path : []}
        vals = {"Latitude": latitude_var.get_data(),
                    "Longitude": longitude_var.get_data(),
                    var_path : var.get_data()}
        return vals

    # ---------------------------------------------------------------------
    # MetaDataGranule group
    # ---------------------------------------------------------------------

    def extract_l2_algorithm(self) -> hdfu.HDFVariable:
        """
        L2Algorithm: Identification of the algorithm and version used to generate this product.
        Size: 1 (string)
        """
        var_path = "MetaDataGranule/L2Algorithm"
        return self.reader.get_var(var_path)

    def extract_l2_gipp_id(self) -> hdfu.HDFVariable:
        """
        L2GippId: Identifier of GIPP used to generate the product.
        Size: nL2GippId (string)
        """
        var_path = "MetaDataGranule/L2GippId"
        return self.reader.get_var(var_path)

    def extract_l2_tun_id(self) -> hdfu.HDFVariable:
        """
        L2TunId: Identifier of TUN used to generate the product.
        Size: nL2TunId (string)
        """
        var_path = "MetaDataGranule/L2TunId"
        return self.reader.get_var(var_path)

    def extract_n_sounding_l2_filter(self) -> hdfu.HDFVariable:
        """
        nSoundingL2Filter: Number of L1C soundings that passed the L2 filter.
        Size: 1 (uint)
        """
        var_path = "MetaDataGranule/nSoundingL2Filter"
        return self.reader.get_var(var_path)

    def extract_l1c_data_id(self) -> hdfu.HDFVariable:
        """
        L1cDataId: Identifier of the L1C product used for this L2.
        Size: 1 (string)
        """
        var_path = "MetaDataGranule/L1cDataId"
        return self.reader.get_var(var_path)

    # ---------------------------------------------------------------------
    # Dimensions group
    # ---------------------------------------------------------------------

    def extract_n_retrieval(self) -> hdfu.HDFVariable:
        """
        nRetrieval: Number of retrievals reported in this L2 product.
        Size: 1 (uint)
        """
        var_path = "Dimensions/nRetrieval"
        return self.reader.get_var(var_path)

    # ---------------------------------------------------------------------
    # RetrievalResults group
    # ---------------------------------------------------------------------

    def extract_co2_column_error(self) -> hdfu.HDFVariable:
        """
        Co2ColumnError: A posteriori error on retrieved vertically-integrated CO2 column [ppm].
        Size: nRetrieval (float)
        """
        var_path = "RetrievalResults/Co2ColumnError"
        return self.reader.get_var(var_path)

    def extract_co2_column(self) -> hdfu.HDFVariable:
        """
        Co2Column: A posteriori vertically-integrated CO2 dry-air mole fraction [ppm].
        Size: nRetrieval (float)
        """
        var_path = "RetrievalResults/Co2Column"
        return self.reader.get_var(var_path)

    def extract_h2o_column_error(self) -> hdfu.HDFVariable:
        """
        H2oColumnError: A posteriori error on retrieved vertically-integrated H2O column [ppm].
        Size: nRetrieval (float)
        """
        var_path = "RetrievalResults/H2oColumnError"
        return self.reader.get_var(var_path)

    def extract_h2o_column(self) -> hdfu.HDFVariable:
        """
        H2oColumn: A posteriori vertically-integrated H2O column [ppm].
        Size: nRetrieval (float)
        """
        var_path = "RetrievalResults/H2oColumn"
        return self.reader.get_var(var_path)

    def extract_surface_wind_speed_error(self) -> hdfu.HDFVariable:
        """
        SurfaceWindSpeedError: A posteriori error on retrieved surface wind speed [m/s].
        Size: nRetrieval (float)
        """
        var_path = "RetrievalResults/SurfaceWindSpeedError"
        return self.reader.get_var(var_path)

    def extract_surface_wind_speed(self) -> hdfu.HDFVariable:
        """
        SurfaceWindSpeed: A posteriori retrieved surface wind speed [m/s].
        Size: nRetrieval (float)
        """
        var_path = "RetrievalResults/SurfaceWindSpeed"
        return self.reader.get_var(var_path)

    def extract_psurf_error(self) -> hdfu.HDFVariable:
        """
        PsurfError: A posteriori error on retrieved surface pressure [hPa].
        Size: nRetrieval (float)
        """
        var_path = "RetrievalResults/PsurfError"
        return self.reader.get_var(var_path)

    def extract_psurf(self) -> hdfu.HDFVariable:
        """
        Psurf: A posteriori retrieved surface pressure [hPa].
        Size: nRetrieval (float)
        """
        var_path = "RetrievalResults/Psurf"
        return self.reader.get_var(var_path)

    def extract_sentinel2_surf_ref(self) -> hdfu.HDFVariable:
        """
        Sentinel2SurfRef: A posteriori retrieved Sentinel-2 surface reflectance [unitless].
        Size: nRetrieval (float)
        """
        var_path = "RetrievalResults/Sentinel2SurfRef"
        return self.reader.get_var(var_path)

    def extract_sentinel2_surf_ref_error(self) -> hdfu.HDFVariable:
        """
        Sentinel2SurfRefError: A posteriori error on retrieved Sentinel-2 surface reflectance [unitless].
        Size: nRetrieval (float)
        """
        var_path = "RetrievalResults/Sentinel2SurfRefError"
        return self.reader.get_var(var_path)

    def extract_sr_aero_mcd12_cm2(self) -> hdfu.HDFVariable:
        """
        SrAeroMcd12Cm2: A posteriori retrieved aerosol optical thickness at MODIS bands 1 & 2 [unitless].
        Size: nRetrieval (float)
        """
        var_path = "RetrievalResults/SrAeroMcd12Cm2"
        return self.reader.get_var(var_path)

    def extract_sr_aero_mcd12_cm2_error(self) -> hdfu.HDFVariable:
        """
        SrAeroMcd12Cm2Error: A posteriori error on aerosol T at MODIS bands 1 & 2 [unitless].
        Size: nRetrieval (float)
        """
        var_path = "RetrievalResults/SrAeroMcd12Cm2Error"
        return self.reader.get_var(var_path)

    def extract_sr_aero_mcd19_cm2(self) -> hdfu.HDFVariable:
        """
        SrAeroMcd19Cm2: A posteriori retrieved aerosol optical thickness at MODIS bands 19 & 20 [unitless].
        Size: nRetrieval (float)
        """
        var_path = "RetrievalResults/SrAeroMcd19Cm2"
        return self.reader.get_var(var_path)

    def extract_sr_aero_mcd19_cm2_error(self) -> hdfu.HDFVariable:
        """
        SrAeroMcd19Cm2Error: A posteriori error on aerosol T at MODIS bands 19 & 20 [unitless].
        Size: nRetrieval (float)
        """
        var_path = "RetrievalResults/SrAeroMcd19Cm2Error"
        return self.reader.get_var(var_path)
    
    def extract_mid_band_sif(self) -> hdfu.HDFVariable:
        """
        MidBandSif : Retrieved fluorescence emission at the mid-wavelength of the band (B1- strong O2)', 'Unit': 'W/m²/sr/µm
        Size: nRetrieval (float)
        """ 
        var_path = "RetrievalResults/MidBandSif"
        return self.reader.get_var(var_path)

    def extract_mid_band_sif_error(self) -> hdfu.HDFVariable:
        """
        MidBandSifError : A posteriori error on retrieved fluorescence emission at the mid-wavelength of the band (B1- strong O2), 'Unit': 'W/m²/sr/µm'
        Size: nRetrieval (float)
        """ 
        var_path = "RetrievalResults/MidBandSifError"
        return self.reader.get_var(var_path)

    def extract_airglow_warm(self) -> hdfu.HDFVariable:
        """
        AirGlowWarm : Retrieved warm airglow emission in B4, 'Unit': 'W/m²/sr/µm
        Size: nRetrieval (float)
        """ 
        var_path = "RetrievalResults/AirglowWarm"
        return self.reader.get_var(var_path)
    
    def extract_airglow_warm_error(self) -> hdfu.HDFVariable:
        """
        AirGlowWarmError : A posteriori error on retrieved warm airglow emission in B4, 'Unit': 'W/m²/sr/µm'
        Size: nRetrieval (float)
        """ 
        var_path = "RetrievalResults/AirglowWarmError"
        return self.reader.get_var(var_path)
    
    def extract_airglow_cold(self) -> hdfu.HDFVariable:
        """
        AirGlowCold : Retrieved cold airglow emission in B4, 'Unit': 'W/m²/sr/µm'
        Size: nRetrieval (float)
        """ 
        var_path = "RetrievalResults/AirglowCold"
        return self.reader.get_var(var_path)
    
    def extract_airglow_cold_error(self) -> hdfu.HDFVariable:
        """
        AirGlowColdError : A posteriori error on retrieved cold airglow emission in B4, 'Unit': 'W/m²/sr/µm'
        Size: nRetrieval (float)
        """ 
        var_path = "RetrievalResults/AirglowColdError"
        return self.reader.get_var(var_path)

    def extract_aerosol_aot(self) -> hdfu.HDFVariable:
        """
        AerosolAot : Retrieved Aerosol Optical Thickness, 'Unit': '-'
        Size: nRetrieval (float)
        """ 
        var_path = "RetrievalResults/AerosolAot"
        return self.reader.get_var(var_path)
    
    def extract_aerosol_aot_error(self) -> hdfu.HDFVariable:
        """
        AerosolAotError : A posteriori error on retrieved Aerosol Optical Thickness, 'Unit': '-'
        Size: nRetrieval (float)
        """ 
        var_path = "RetrievalResults/AerosolAotError"
        return self.reader.get_var(var_path)

    def extract_aerosol_z(self) -> hdfu.HDFVariable:
        """
        AerosolZ : Retrieved Gaussian height aerosol distribution, 'Unit': 'km'
        Size: nRetrieval (float)
        """ 
        var_path = "RetrievalResults/AerosolZ"
        return self.reader.get_var(var_path)
    
    def extract_aerosol_z_error(self) -> hdfu.HDFVariable:
        """
        AerosolZError : A posteriori error on retrieved Gaussian height aerosol distribution, 'Unit': 'km'
        Size: nRetrieval (float)
        """ 
        var_path = "RetrievalResults/AerosolZError"
        return self.reader.get_var(var_path)

    def extract_aerosol_k(self) -> hdfu.HDFVariable:
        """
        AerosolK : Retrieved Ångström coefficient, 'Unit': '-'
        Size: nRetrieval (float)
        """ 
        var_path = "RetrievalResults/AerosolK"
        return self.reader.get_var(var_path)
    
    def extract_aerosol_k_error(self) -> hdfu.HDFVariable:
        """
        AerosolKError : A posteriori error on retrieved Ångström coefficient, 'Unit': '-'
        Size: nRetrieval (float)
        """ 
        var_path = "RetrievalResults/AerosolKError"
        return self.reader.get_var(var_path)

