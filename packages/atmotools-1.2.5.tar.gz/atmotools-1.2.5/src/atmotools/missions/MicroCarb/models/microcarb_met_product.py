# Copyright (c) 2024-2026 Centre National d'Etudes Spatiales (CNES).
#
# This file is part of AtmoTools
# (see https://github.com/CNES/AtmoTools).
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

"""
Mission/MicroCarb/src/microcarb_met_product.py
-- Defines a data model for opening and querying a MicroCarb MET product.
"""

import pandas as pd
import numpy as np

import atmotools.utils.hdf_netcdf_tools as hdfu
from atmotools.utils.hdf_netcdf_tools import Netcdf4Reader, HDFVariable

import atmotools.utils.path_utils as pu

class MicroCarbMET:
    """
    This class opens a MicroCarb MET file and exposes:
      - Fov Center LatLonAlt
      - Fov Vertices LatLonAlt

      - Aerosol optical depth (Aod)
      - Aerosol asymmetry factor
      - Aerosol single scattering albedo
      - Aerosol types (strings)
      - Water vapor mixing ratio profile (H2O)
      - Surface pressure
      - CO2 mixing ratio profile
      - CO2 pressure grid
    """

    # Names of dimensions
    N_FS_DIM = "nFs"
    N_FOV_DIM = "nFov"
    N_VERTEX_DIM = "nFovVertex"



    # Paths of variables
    # Coordinates
    CENTER_LATLONALT_PATH = "SpectrumGeometryFsFov/FovCenterLatLonAlt"
    VERTICES_LATLONALT_PATH = "SpectrumGeometryFsFov/FovVerticesLatLonAlt"
    # Others
    MET_SURFACE_PRESSURE_PATH = "MeteorologicalData/MetSurfacePressure" 
    KAERO_PATH = "AerosolData/Kaero"
    ZAERO_PATH = "AerosolData/Zaero"

    AOD_PATH = "AerosolData/Aod"
    H2O_MIXING_RATIO_PROFIL_PATH = "MeteorologicalData/H2oMixingRatioProfile"
    CO2_MIXING_RATIO_PROFIL_PATH = "Co2Data/Co2MixingRatioProfile"
    SINGLE_SCATTERING_ALBEDO_PATH = "AerosolSata/SingleScatteringAlbedo"
    ASYMMETRY_FACTOR_PATH = "AerosolData/AsymmetryFactor"

    AEROSOL_LAMBDA_PATH = 'AerosolData/AerosolLambda'

    def __init__(self, file_path: str, useXarray = False):
        """
        :param met_file_path: Path to the HDF5/NetCDF MET product
        """
        self.file_path = file_path
        self.reader = hdfu.createReader(file_path, useXarray=useXarray)

    def get_file_path(self) -> str:
        """
        Return the file path of the product.

        :return: file path
        """
        return self.file_path
    
    def get_reader(self) -> hdfu.AbstractHDFReader:
        """
        Return the reader corresponding to the product

        :return: the product reader
        """
        return self.reader

    def get_file_name(self) -> str:
        """
        Extract the file name of the product from its file path.

        :return: file name
        """
        return pu.get_last_element_in_path(self.get_file_path())[0]
    
    def get_acquisition_id(self) -> str:
        """
        Extract the acquisition id of the product from its file path.

        :return: file name
        """
        return self.get_file_name()[18:49]

    def get_all_coordinates(self) -> pd.DataFrame:
        """
        Get coordinates for all Fovs in the product.

        :return: dataframe following the format ("Fov index"\: tuples (fs, fov), "Longitude"\: integers, "Latitude"\: integers, "Coordinates"\: lists [ (lat, lon) for all 4 vertices])
        """
        # Get the coordinates of fov centers and corners
        center_coord_var = self.extract_var(self.CENTER_LATLONALT_PATH)
        vertices_coord_var = self.extract_var(self.VERTICES_LATLONALT_PATH)
        # Get dimensions sizes
        tot_fs = center_coord_var.dimensions[self.N_FS_DIM]
        tot_fovs = center_coord_var.dimensions[self.N_FOV_DIM]

        all_coords_dict = {'Fov index': [], 'Longitude': [], 'Latitude': [], 'Coordinates': []}
        for fs in range(tot_fs):
            for fov in range(tot_fovs):
                lat, lon, alt = center_coord_var.get_value_by_dim({self.N_FS_DIM: fs, self.N_FOV_DIM: fov})
                all_coords_dict['Fov index'].append([fs, fov])
                all_coords_dict['Longitude'].append(lon)
                all_coords_dict['Latitude'].append(lat)
                # Get the (lat, lon) for all 4 vertices of the fov
                latlons = [(tuple(vertices_coord_var.get_value_by_dim({self.N_FS_DIM: fs, self.N_FOV_DIM: fov,
                                                                    self.N_VERTEX_DIM: vertex})[:2])[::-1])
                            for vertex in range(4)]
                all_coords_dict['Coordinates'].append(latlons)
        all_coords_df = pd.DataFrame(all_coords_dict)
        return all_coords_df
    
    def get_var(self,var_path: str) -> dict:
        """
            Return values of a variable and their corresponding coordinates
            :return dictionnary{Latitude,Longitudes,Values} 
        """
        # Get the coordinates of fov centers and corners
        center_coord_var = self.extract_var(self.CENTER_LATLONALT_PATH)
        vertices_coord_var = self.extract_var(self.VERTICES_LATLONALT_PATH)
        # Get dimensions sizes
        tot_fs = center_coord_var.dimensions[self.N_FS_DIM]
        tot_fovs = center_coord_var.dimensions[self.N_FOV_DIM]

        try :
            var = self.extract_var(var_path)
        except Exception as e: 
            print(e)
            return {'Latitude': [], 'Longitude': [], 'Fs': [], 'Fov': [], var_path.split('/')[::-1][0] : []}
        else :
            vals = {'Fs': [], "Fov": [] , 'Longitude': [], 'Latitude': [], var_path: []}
            for fs in range(tot_fs):
                for fov in range(tot_fovs):
                    lat, lon, alt = center_coord_var.get_value_by_dim({self.N_FS_DIM: fs, self.N_FOV_DIM: fov})
                    var_value = var.get_value_by_dim({self.N_FS_DIM: fs, self.N_FOV_DIM: fov})
                    vals['Longitude'].append(lon)
                    vals['Latitude'].append(lat)
                    vals['Fov'].append(fov)
                    vals['Fs'].append(fs)
                    vals[var_path].append(var_value)
        return vals

    def get_aerosol_data(self,var_path: str, nfs: int, nfov: int) -> dict:
        """
            Return values of a aerosol variable corresponding to the selected dimensions
            :return list
        """
        # Initialize dict 
        aerosol_vals = {'Lambda': []}

        # Get lambdas var
        lambdas = self.extract_var(self.AEROSOL_LAMBDA_PATH)

        # Get aerosol var 
        var = self.extract_var(var_path)

        aerosol_vals["Lambda"] = list(lambdas.get_data())
        aerosol_data = var.get_value_by_dim({self.N_FS_DIM: nfs, self.N_FOV_DIM: nfov})
        if var.get_fill_value():
            aerosol_data[aerosol_data <= var.get_fill_value()] = np.nan
        aerosol_vals[var_path] = list(aerosol_data)
        return aerosol_vals
    
    def get_profile_data(self,var_path: str, nfs: int, nfov: int) -> dict:
        """
            Return values of a profile variable corresponding to the selected dimensions
            :return list
        """
        # Initialize dict 
        profile_vals = {}

        # Get var 
        var = self.extract_var(var_path)

        profile_data = var.get_value_by_dim({self.N_FS_DIM: nfs, self.N_FOV_DIM: nfov})
        if var.get_fill_value():
            profile_data[profile_data <= var.get_fill_value()] = np.nan
        profile_vals[var_path] = list(profile_data)
        return profile_vals

    def extract_var(self, var_path) -> hdfu.HDFVariable:
        """
        Return the HDFVariable corresponding to a given variable path

        :param: var_path: path of the variable to extract
        :return: corresponding variable
        """
        return self.get_reader().get_var(var_path)

    def get_met_surface_pressure(self) -> dict:
        """
        Return the values of MetSurfacePressure
        
        :return: dictionnary of the MetSurfacePressure values and their corresponding coordinates
        """
        return self.get_var(self.MET_SURFACE_PRESSURE_PATH)
    
    def get_kaero(self) -> dict:
        """
        Return the values of Kaero
        
        :return: dictionnary of the Kaero values and their corresponding coordinates
        """
        return self.get_var(self.KAERO_PATH)

    def get_zaero(self) -> dict:
        """
        Return the values of Kaero
        
        :return: dictionnary of the Kaero values and their corresponding coordinates
        """
        return self.get_var(self.ZAERO_PATH)

    def get_aod(self) -> dict:
        """
        Return the values of Aod
        Aod : Total aerosol optical depth at definition wavelengths
        :return: dictionnary of the Aod values and their corresponding coordinates
        """
        return self.get_var(self.AOD_PATH)



#----------------------------------------------------------------------------

    def extract_aod(self) -> HDFVariable:
        """
        Total aerosol optical depth at definition wavelengths,
        from field AerosolData/Aod
        Dimensions: (nFs, nFov, nLambdaAerosol)

        :return: HDFVariable array of AOD (float)
        """
        var_path = "AerosolData/Aod"
        return self.reader.get_var(var_path)

    def extract_asymmetry_factor(self) -> HDFVariable:
        """
        Aerosol asymmetry factor per type & wavelength,
        from field AerosolData/AsymmetryFactor
        Dimensions: (nFs, nFov, nLambdaAerosol)

        :return: HDFVariable array of asymmetry factors (float)
        """
        var_path = "AerosolData/AsymmetryFactor"
        return self.reader.get_var(var_path)

    def extract_single_scattering_albedo(self) -> HDFVariable:
        """
        Single scattering albedo per aerosol type & wavelength,
        from field AerosolData/SingleScatteringAlbedo
        Dimensions: (nFs, nFov, nLambdaAerosol)

        :return: HDFVariable array of single scattering albedo (float)
        """
        var_path = "AerosolData/SingleScatteringAlbedo"
        return self.reader.get_var(var_path)

    def extract_aerosol_types(self) -> HDFVariable:
        """
        List of aerosol type names (strings),
        from field AerosolData/AerosolTypes
        Dimensions: (nLambdaAerosol)

        :return: HDFVariable array of aerosol type names
        """
        var_path = "AerosolData/AerosolTypes"
        return self.reader.get_var(var_path)

    def extract_h2o_mixing_ratio_profile(self) -> HDFVariable:
        """
        Water vapor mixing ratio profile at FOV barycenter,
        from field MeteorologicalData/H2oMixingRatioProfile
        Dimensions: (nFs, nFov, nLevelIfs)

        :return: HDFVariable array of H2O mixing ratio (kg/kg)
        """
        var_path = "MeteorologicalData/H2oMixingRatioProfile"
        return self.reader.get_var(var_path)

    def extract_surface_pressure(self) -> HDFVariable:
        """
        Surface pressure, from field MeteorologicalData/MetSurfacePressure
        Dimensions: (nFs, nFov)

        :return: HDFVariable array of surface pressure (hPa)
        """
        var_path = "MeteorologicalData/MetSurfacePressure"
        return self.reader.get_var(var_path)

    def extract_co2_mixing_ratio_profile(self) -> HDFVariable:
        """
        CO2 mixing ratio profile at FOV barycenter,
        from field Co2Data/Co2MixingRatioProfile
        Dimensions: (nFs, nFov, nLevelCamsCo2)

        :return: HDFVariable array of CO2 mixing ratio (kg/kg)
        """
        var_path = "Co2Data/Co2MixingRatioProfile"
        return self.reader.get_var(var_path)

    def extract_co2_pressure_grid(self) -> HDFVariable:
        """
        CO2 pressure grid used for mixing ratio profile,
        from field Co2Data/Co2PressureGrid
        Dimensions: (nFs, nFov, nLevelCamsCo2)

        :return: HDFVariable array of CO2 pressure grid values (hPa)
        """
        var_path = "Co2Data/Co2PressureGrid"
        return self.reader.get_var(var_path)
