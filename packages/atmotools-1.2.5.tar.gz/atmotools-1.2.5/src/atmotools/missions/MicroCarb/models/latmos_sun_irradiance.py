# Copyright (c) 2024-2026 Centre National d'Etudes Spatiales (CNES).
#
# This file is part of AtmoTools
# (see https://github.com/CNES/AtmoTools).
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

import math
import numpy as np

import utils.file_utils as fu
import utils.array_utils as au

# ===========================
# CONSTANTS
# ===========================
# Sun radius (in km)
R_SUN = 695800
# The Earth-sun distance (in km)
D_EARTH_SUN = 1.496 * pow(10, 8)
# Sun solid angle (in sr)
OMEGA_SUN = math.pi * pow(R_SUN, 2) / pow(D_EARTH_SUN, 2)


# ===========================
# CLASSES
# ===========================
class LATMOSSunIrradiance:
    """
    This class enables to read SOLSPEC17-TOON16-LATMOS-EchTOON16-TOT-iss files and compute the corresponding wavelengths
     and the sun spectral irradiances.
    Spec §4.1.1.2

    Attributes:
        file_paths(str): the path of the LATMOS files. They may contain patterns using wildcards (* or ?).
        wavenumbers: the wavenumbers (in cm-1)
        radiances: the radiances (in W/m2/sr/cm-1)
        flags: the validity flags
        wavelengths: the wavelengths (in µm)
        sun_spect_irradiances: the sun spectral irradiance (in W/m2/µm)
    """

    # The number of columns in the files
    NB_COLUMNS = 3
    # The encoding of files
    ENCODING = "ascii"
    # The number of lines for header
    HEADER_LINES = 2

    # the sun irradiance model is SOLSPEC17-TOON16-LATMOS-EchTOON16-TOT-iss (see §4.1.1.2)
    def __init__(self, *file_paths: str, wn_min: float = None, wn_max: float = None):
        """
        Initialize the class attributes and read the input files.
        Extract the data corresponding to a wavenumber in interval:
        - [wn_min ; wn_max] if both bounds are set
        - [-inf ; wn_max] if only wn_max is set
        - [wn_min ;  +inf] if only wn_min is set
        If no bound is set, extract all the data. It is not recommended if you have many files to read.

        :param file_paths: the file paths of the LATMOS files to read.
               They may contain patterns using wildcards (* or ?).
        :param wn_min: (optional) the minimum wavenumber
        :param wn_max: (optional) the maximum wavenumber
        """
        self.file_paths = fu.find_files(*file_paths)
        self.wavenumbers, self.radiances, self.flags = None, None, None
        if wn_min is None and wn_max is None:
            # Extract all the data
            self.wavenumbers, self.radiances, self.flags = self.__extract_data_from_files()
        else:
            # Extract the data corresponding to a wavenumber within the input interval
            self.wavenumbers, self.radiances, self.flags = self.__filter_data_from_files(wn_min, wn_max)
        # Convert the wavenumbers (cm-1) into wavelengths (µm)
        self.wavelengths = 10000 / self.wavenumbers
        self.sun_spect_irradiances = self.__compute_sun_spectral_irradiances()

    def __extract_data_from_files(self):
        """
        Extract the wavenumbers, radiances and quality flags from the ASCII files

        :return: wavenumbers, radiances and quality flags as numpy.ndarray.
                 Data are sorted so that wavenumbers are in descending order.
        """
        # Initialize the result: wavenumbers, radiances and quality flags
        result = [[] for _ in range(self.NB_COLUMNS)]
        for file in self.file_paths:
            try:
                with open(file, 'r', encoding='ascii') as f:
                    # Skip the header lines
                    fu.skip_lines(self.HEADER_LINES, f)

                    for line in f:
                        # Skip empty lines
                        if line.strip():
                            wn_rad_flag = self.__get_data_from_line(line)

                            # Skip data already read
                            wn = wn_rad_flag[0]
                            if wn not in result[0]:
                                for i in range(len(result)):
                                    result[i].append(wn_rad_flag[i])
            except Exception as e:
                print(f'Error reading {file}: {e}')

        # Sort in descending order the wavenumbers and apply this order to other data
        sorted_wn, sorted_others = au.sort_container_by_reference(result[0],
                                                                  result[1],
                                                                  result[2],
                                                                  reverse=True)
        result = [sorted_wn, sorted_others[0], sorted_others[1]]

        # Convert the lists into numpy arrays
        for i in range(self.NB_COLUMNS):
            result[i] = np.asarray(result[i])
        return result

    def __get_wavenumber_from_line(self, line: str) -> float:
        """
        Return the wavenumber of the input line

        :param line: line of a LATMOS file
        :return: the wavenumber of the input line
        """
        return self.__get_data_from_line(line)[0]

    def __get_data_from_line(self, line: str) -> list[float, float, int]:
        """
        Return the wavenumber, the radiance and the quality flag of the input line as a list.

        :param line: line of a LATMOS file
        :return: a list containing the wavenumber, the radiance and the quality of the input line
        :raises ValueError: if the line does not contain the expected number of columns (three)
        """
        # Extract the values of the line as strings
        values_str = line.split()
        # Check the number of columns
        if len(values_str) != self.NB_COLUMNS:
            raise ValueError(f"Expected {self.NB_COLUMNS} columns in this line: {line}")
        # Convert the strings into (float, float, int)
        values = list(map(float, values_str))
        values[-1] = int(values[-1])
        return values

    def __filter_files_wavenumber_interval(self, wavenumber_min: float, wavenumber_max: float) -> tuple[list,
                                                                                                        list, list]:
        """
        Return:
         - the list of files which wavenumbers are partially or completely in the input wavenumber interval
         - the data (wavenumber, raidance and quality) corresponding to the first wavenumber before wavenumber_min
         - the data corresponding to the first wavenumber after wavenumber_max

        :param wavenumber_min: the minimum wavenumber to process
        :param wavenumber_max: the maximum wavenumber to process
        :return: a tuple containing the filtered files, the data before wavenumber_min and the data after wavenumber_max
        """
        # Initialize the list of files to keep
        files_to_keep = []
        # Initialize the line corresponding to the greatest wavenumber that is smaller than
        # the wavenumber_min (wavenumber, radiance and quality flag)
        before_wn_min = [None, None, None]
        # Initialize the line corresponding to the smallest wavenumber that is greater than
        # the wavenumber_max (wavenumber, radiance and quality flag)
        after_wn_max = [None, None, None]

        # For each file check if all wavenumbers are outside the input interval
        for file in self.file_paths:
            try:
                # Get the first line by skipping the header lines
                first_line = fu.get_first_line(file, encoding=self.ENCODING, ignore_empty_lines=True,
                                               lines_to_skip=self.HEADER_LINES)
                first_wn = self.__get_wavenumber_from_line(first_line)

                # Skip current file if first wavenumber is greater than the maximum wavenumber
                if first_wn and first_wn > wavenumber_max:
                    # Set after_wn_max if the current wn is smaller than the wavenumber in after_wn_max
                    if (after_wn_max[0] is None) or (first_wn < after_wn_max[0]):
                        after_wn_max = self.__get_data_from_line(first_line)
                    continue

                # Get the last line by reading the file from the end
                last_line = fu.get_last_line(file, encoding=self.ENCODING, ignore_empty_lines=True)
                last_wn = self.__get_wavenumber_from_line(last_line)

                # Skip current file if first wavenumber is greater than the maximum wavenumber
                if last_wn and last_wn < wavenumber_min:
                    # Set before_wn_min if the current wn is greater than the wavenumber in before_wn_min
                    if (before_wn_min[0] is None) or (last_wn > before_wn_min[0]):
                        before_wn_min = self.__get_data_from_line(last_line)
                    continue

                files_to_keep.append(file)
            except Exception as e:
                print(f'Error reading a file: {e}')
        return files_to_keep, before_wn_min, after_wn_max

    def __filter_data_from_files(self, wavenumber_min: float, wavenumber_max: float) -> list:
        """
        Extract the wavenumbers, radiances and quality flags from the ASCII files for wavenumbers within the interval
        [wavenumber_min, wavenumber_max].
        If possible, add data corresponding to the wavenumbers just before and just after the output wavenumber interval
        to make sure there are enough data.

        :param wavenumber_min: the minimum wavenumber to process
        :param wavenumber_max: the maximum wavenumber to process
        :return: tuple of wavenumbers, radiances and quality flags as numpy.ndarrays
                 Data are sorted so that wavenumbers are in descending order.
        """
        # Initialize the result: wavenumbers, radiances and quality flags
        result = [[] for _ in range(self.NB_COLUMNS)]

        # If wavenumber_min (resp. wavenumber_max) is None, replace it by - infinity (resp. infinity)
        if wavenumber_min is None:
            wavenumber_min = - math.inf
        if wavenumber_max is None:
            wavenumber_max = math.inf

        files_to_keep, before_wn_min, after_wn_max = self.__filter_files_wavenumber_interval(wavenumber_min,
                                                                                             wavenumber_max)
        # Extract the data from selected files according to the input wavenumber interval
        # Initialize a list for each column : wavenumbers, radiances and quality flags
        extracted_wn_rad_flag = [[] for _ in range(self.NB_COLUMNS)]
        for file in files_to_keep:
            try:
                with open(file, 'r', encoding=self.ENCODING) as f:
                    # Skip the header lines
                    fu.skip_lines(self.HEADER_LINES, f)

                    for line in f:
                        # Skip empty lines
                        if line.strip():
                            wn_rad_flag = self.__get_data_from_line(line)

                            # Skip data already read
                            wn = wn_rad_flag[0]
                            if wn not in extracted_wn_rad_flag[0]:
                                if wavenumber_min <= wn:
                                    if wn <= wavenumber_max:
                                        for i in range(len(extracted_wn_rad_flag)):
                                            extracted_wn_rad_flag[i].append(wn_rad_flag[i])
                                    else:
                                        # Set after_wn_max if the current wn is smaller than the wavenumber
                                        # in after_wn_max
                                        if (after_wn_max[0] is None) or (wn < after_wn_max[0]):
                                            after_wn_max = self.__get_data_from_line(line)
                                        # Skip all following lines: the wavenumbers are greater than the input maximum
                                        break
                                else:
                                    # Set before_wn_min if the current wn is greater than the wavenumber
                                    # in before_wn_min
                                    if (before_wn_min[0] is None) or (wn > before_wn_min[0]):
                                        before_wn_min = self.__get_data_from_line(line)
            except Exception as e:
                print(f'Error reading a filtered file: {e}')

        # Sort in descending order the wavenumbers and apply this order to other data
        sorted_wn, sorted_others = au.sort_container_by_reference(extracted_wn_rad_flag[0],
                                                                  extracted_wn_rad_flag[1],
                                                                  extracted_wn_rad_flag[2],
                                                                  reverse=True)
        sorted_wn_rad_flag = [sorted_wn, sorted_others[0], sorted_others[1]]

        # Add the data of the line before (resp. after) the first (resp. last) line extracted
        for i in range(len(result)):
            # Add the data corresponding to the wavenumber after the extracted wavenumbers
            if after_wn_max[0]:
                result[i].append(after_wn_max[i])
            # Add extracted data corresponding to a wavenumber within the input interval
            result[i].extend(sorted_wn_rad_flag[i])
            # Add the data corresponding to the wavenumber before the extracted wavenumbers
            if before_wn_min[0]:
                result[i].append(before_wn_min[i])

        # Convert the lists into numpy arrays
        for i in range(self.NB_COLUMNS):
            result[i] = np.asarray(result[i])
        return result

    def __compute_sun_spectral_irradiances(self) -> np.ndarray:
        """
        Compute the sun irradiance in W/m2/µm from the LATMOS read spectrum

        :return: the sun irradiance
        """
        i_sun = self.radiances * 1e4 * pow(self.wavelengths, -2) * OMEGA_SUN
        return i_sun

    def get_indexes_wavenumber_interval(self, wavenumber_min: float, wavenumber_max: float) -> list[int]:
        """
        Return the indices of the wavenumbers in the input interval. If possible, add the index of the wavenumber just
        before and just after the wavenumber interval

        :param wavenumber_min: the minimum wavenumber
        :param wavenumber_max: the maximum wavenumber
        :return: the indices of wavenumbers in the input interval
        """
        indexes = au.get_indexes_from_array_interval(self.wavenumbers, wavenumber_min, wavenumber_max)
        # Convert the indexes array to list
        indexes = indexes[0].tolist()
        indexes_min = min(indexes)
        indexes_max = max(indexes)

        # Initialize result
        result = []
        if indexes_min > 0:
            result.append(indexes_min - 1)
        result.extend(indexes)
        if indexes_max < len(self.wavenumbers) - 1:
            result.append(indexes_max + 1)
        return result
