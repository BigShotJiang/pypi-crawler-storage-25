# Copyright (c) 2024-2026 Centre National d'Etudes Spatiales (CNES).
#
# This file is part of AtmoTools
# (see https://github.com/CNES/AtmoTools).
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

from typing import Union
from abc import ABC, abstractmethod

import pandas as pd
import numpy as np

import atmotools.utils.hdf_netcdf_tools as hdfu
import atmotools.utils.path_utils as pu


# ===========================
# CLASSES
# ===========================


class AbstractMicroCarb_L1(ABC):
    """
    Abstract class to open a MicroCarb L1 product and extract its data

    Attributes:
        file_path(str): the path of the L1 file
        reader: the file reader
    """

    # Names of dimensions
    N_FS_DIM = "nFs"
    N_FOV_DIM = "nFov"
    N_VERTEX_DIM = "nFovVertex"
    N_BAND_DIM = "nBand"
    N_LAMBDA_DIM = "nLambda"
    N_PIF_ALT_DIM = "nPifAlt"
    N_PIF_ACT_DIM = "nPifAct"
    N_PIF_VERTEX_DIM = "nPifVertex"

    # Paths of variables
    # Coordinates
    VERTICES_LATLONALT_PATH = "SpectrumGeometryFsFov/FovVerticesLatLonAlt"
    CENTER_LATLONALT_PATH = "SpectrumGeometryFsFov/FovCenterLatLonAlt"
    # Continuum
    MEAN_RADIANCE_PATH = "SpectrumMeasurementFsFov/MeanRadiance" 
    # Cloud Index
    CLOUD_INDEX_PATH = "CloudFlags/CloudIndex" 

    def __init__(self, file_path: str, useXarray = False) -> None:
        """
        Initialize the class attributes.

        :param: file_path: the file path of the MicroCarb L1 product
        :param: useXarray: if set to True, the product reader will use the xarray library instead of netcdf.
        """
        self.file_path = file_path
        self.reader = hdfu.createReader(file_path, useXarray=useXarray)

    def get_file_path(self) -> str:
        """
        Return the file path of the product.

        :return: file path
        """
        return self.file_path

    def get_reader(self) -> hdfu.AbstractHDFReader:
        """
        Return the reader corresponding to the product

        :return: the product reader
        """
        return self.reader

    def get_file_name(self) -> str:
        """
        Extract the file name of the product from its file path.

        :return: file name
        """
        return pu.get_last_element_in_path(self.get_file_path())[0]

    def get_acquisition_id(self) -> str:
        """
        Extract the acquisition id of the product from its file path.

        :return: file name
        """
        return self.get_file_name()[18:49]

    def get_product_level(self) -> str:
        """
        Extract the level of the product from its file path.

        :return: file name
        """
        return self.get_file_name()[7:17]

    def extract_var(self, var_path) -> hdfu.HDFVariable:
        """
        Return the HDFVariable corresponding to a given variable path

        :param: var_path: path of the variable to extract
        :return: corresponding variable
        """
        return self.get_reader().get_var(var_path)

    def get_all_coordinates(self) -> pd.DataFrame:
        """
        Get coordinates for all Fovs in the product.

        :return: dataframe following the format ("Fov index"\: tuples (fs, fov), "Longitude"\: integers, "Latitude"\: integers, "Coordinates"\: lists [ (lat, lon) for all 4 vertices])
        """
        # Get the coordinates of fov centers and corners
        center_coord_var = self.extract_var(self.CENTER_LATLONALT_PATH)
        vertices_coord_var = self.extract_var(self.VERTICES_LATLONALT_PATH)
        # Get dimensions sizes
        tot_fs = center_coord_var.dimensions[self.N_FS_DIM]
        tot_fovs = center_coord_var.dimensions[self.N_FOV_DIM]

        all_coords_dict = {'Fov index': [], 'Longitude': [], 'Latitude': [], 'Coordinates': []}
        for fs in range(tot_fs):
            for fov in range(tot_fovs):
                lat, lon, alt = center_coord_var.get_value_by_dim({self.N_FS_DIM: fs, self.N_FOV_DIM: fov})
                all_coords_dict['Fov index'].append([fs, fov])
                all_coords_dict['Longitude'].append(lon)
                all_coords_dict['Latitude'].append(lat)
                # Get the (lat, lon) for all 4 vertices of the fov
                latlons = [(tuple(vertices_coord_var.get_value_by_dim({self.N_FS_DIM: fs, self.N_FOV_DIM: fov,
                                                                    self.N_VERTEX_DIM: vertex})[:2])[::-1])
                            for vertex in range(4)]
                all_coords_dict['Coordinates'].append(latlons)
        all_coords_df = pd.DataFrame(all_coords_dict)
        return all_coords_df

    def get_pif_vertices(self) -> pd.DataFrame:
        """
        Get coordinates (Latitude,longitude and pixel) for all Pif Vertices
        PifGeometryFsFovPif/VerticesLatLonAlt : Geodetic coordinates of PIF vertices, use loc on DEM (latitude/longitude/altitude)
        
        :return dataframe following the format : "Coordinates"\: lists [ (lat, lon) for all 4 vertices])
        """

        try :
            PifLatLonAlt_var = self.extract_var("PifGeometryFsFov/PifVerticesLatLonAlt")
        except Exception as err: 
            print(err)
            return pd.DataFrame({"Fs": [], "Fov": [], "Coordinates": []})

        tot_fs = PifLatLonAlt_var.dimensions[self.N_FS_DIM]
        tot_fovs = PifLatLonAlt_var.dimensions[self.N_FOV_DIM] 
        tot_pifalt = PifLatLonAlt_var.dimensions[self.N_PIF_ALT_DIM]
        tot_pifact = PifLatLonAlt_var.dimensions[self.N_PIF_ACT_DIM]
        tot_pifvertex = PifLatLonAlt_var.dimensions[self.N_PIF_VERTEX_DIM]

        data_dict ={"Fs": [], "Fov": [], "PifAlt": [], "PifAct":[], "Coordinates": []}

        for fs in range(tot_fs):
            for fov in range(tot_fovs):
                for pifalt in range(tot_pifalt):
                    for pifact in range(tot_pifact):
                        # print(f"nFs: {fs}, nFov: {fov}, nPifAlt: {pifalt}, nPifAct: {pifact}")
                        vertices = PifLatLonAlt_var.get_value_by_dim({self.N_FS_DIM: fs, self.N_FOV_DIM: fov, self.N_PIF_ALT_DIM: pifalt, self.N_PIF_ACT_DIM: pifact})
                        coords = [tuple(x[:2])[::-1] for x in vertices]
                        data_dict['Coordinates'].append(coords)
                        data_dict['Fs'].append(fs)
                        data_dict['Fov'].append(fov)
                        data_dict['PifAlt'].append(pifalt)
                        data_dict['PifAct'].append(pifact)

        return pd.DataFrame(data_dict)


class MicroCarbL1B(AbstractMicroCarb_L1):
    """
    This class enables to open a MicroCarb L1B product and extract its data

    Attributes:
        file_path(str): the path of the L1B file
        reader: the file reader
    """

    # Paths of variables
    SPECTRUM_PATH = "/SpectrumMeasurementFsFov/Radiance"
    LAMBDA_PATH = "/SpectrumMeasurementFsFov/Lambda"

    def __init__(self, file_path, useXarray=False) -> None:
        """
        Initialize the class attributes.

        :param: file_path: the file path of the MicroCarb L1B product
        :param: useXarray: if set to True, the product reader will use the xarray library instead of netcdf.
        """
        super().__init__(file_path, useXarray)
        if self.get_product_level() != "1B_PRODUCT":
            raise f"ERROR: {self.file_path} is not an L1B PRODUCT file."

    def get_spectrum_from_fov(self, nfs: int, nfov: int, nband: int) -> dict[list]:
        """
        Get the spectrum for a specific fov.

        :param: nfs, nfov: Fs and Fov index for the desired fov
        :param: nband: desired band for which to get the spectrum

        :return: dictionnary following the format {"File\: list of 'L1B's, "Lambda": list of lambda values, "Radiance": list of corresponding radiance values}
        """
        spectrum_vals = {'File': [], 'Lambda': [], 'Radiance': []}
        spectrum = self.extract_var(self.SPECTRUM_PATH)
        lambdas = self.extract_var(self.LAMBDA_PATH)
        spectrum_vals["File"] = ["L1B"] * spectrum.dimensions[self.N_LAMBDA_DIM]
        spectrum_vals["Lambda"] = list(lambdas.get_value_by_dim({self.N_FS_DIM: nfs, self.N_FOV_DIM: nfov, self.N_BAND_DIM: nband}))
        rad_spc = spectrum.get_value_by_dim({self.N_FS_DIM: nfs, self.N_FOV_DIM: nfov, self.N_BAND_DIM: nband})
        if spectrum.get_fill_value():
            rad_spc[rad_spc <= spectrum.get_fill_value()] = np.nan
        spectrum_vals["Radiance"] = list(rad_spc)
        return spectrum_vals

    def get_mean_radiance(self):
        """
        Get the continuum for each band.
        MeanRadiance : Average value of radiance in continuum for Bi band, 'Unit': 'W/m?/sr/?m'
        :return dictionnary folowwing the format{"Longitude" : list of float, "Latitude" : list of float, "MeanRadianceBx" : list of float} 
        """
        # Get the coordinates 
        center_coord_var = self.extract_var(self.CENTER_LATLONALT_PATH)
        # Get the mean radiance
        try :
            mean_radiance_var = self.extract_var(self.MEAN_RADIANCE_PATH)
        except Exception as e:
            print(e)
            return {"Longitude": [], "Latitude": [], "Fov": [], "Fs": [], "MeanRadianceBx": []}
        # Get dimensions sizes
        tot_fs = mean_radiance_var.dimensions[self.N_FS_DIM]
        tot_fovs = mean_radiance_var.dimensions[self.N_FOV_DIM]
        tot_bands = mean_radiance_var.dimensions[self.N_BAND_DIM] 

        # Create dict depends of the bands number 
        mean_radiance_dict = {"Longitude" :[], "Latitude" :[], "Fov": [], "Fs": []} 
        for n_bd in range(tot_bands):
            mean_radiance_dict[f"MeanRadianceB{n_bd+1}"] =[]  

        # Get the values  
        for fs in range(tot_fs):
            for fov in range(tot_fovs):
                band_values = mean_radiance_var.get_value_by_dim({self.N_FS_DIM: fs, self.N_FOV_DIM: fov})
                lat, lon, alt = center_coord_var.get_value_by_dim({self.N_FS_DIM: fs, self.N_FOV_DIM: fov})
                mean_radiance_dict['Longitude'].append(lon)
                mean_radiance_dict['Latitude'].append(lat)
                mean_radiance_dict['Fs'].append(fs)
                mean_radiance_dict['Fov'].append(fov)
                i=1
                for bd in band_values:
                    mean_radiance_dict[f"MeanRadianceB{i}"].append(bd) 
                    i+=1
        return mean_radiance_dict



class MicroCarbL1BENG(AbstractMicroCarb_L1):
    """
    This class enables to open a MicroCarb L1B ENG product and extract its data

    Attributes:
        file_path(str): the path of the L1B ENG file
        reader: the file reader
    """
    # Paths of variables
    PIFSCENEISRF_PATH = "PifIsrf/PifSceneIsrf"
    PIFISRFDLAMBDA_PATH = "PifIsrf/PifIsrfdLambda"
    PIFLAMBDA_PATH = "PifIsrf/PifLambda"
    # Dimension name
    N_PIFLAMBDA_DIM = "nPifLambdaMax"
    # N_PIFALT_DIM = "nPifAlt"
    # N_PIFACT_DIM = "nPifAct"

    def __init__(self, file_path, useXarray=False) -> None:
        """
        Initialize the class attributes.

        :param: file_path: the file path of the MicroCarb L1B ENG product
        :param: useXarray: if set to True, the product reader will use the xarray library instead of netcdf.
        """
        super().__init__(file_path, useXarray)
        if self.get_product_level() != "1B_ENGL1B_":
            raise f"ERROR: {self.file_path} is not an L1B ENG file."

    def get_pifisrf_from_fov(self, nfs: int, nfov: int, nwl:int, nband: int):
        """
        Get the pif ISRF for a specific fov.

        :param: nfs, nfov: Fs and Fov index for the desired fov
        :param: nband: desired band for which to get the pifisrf
        :param: nwl: desired wavelength index for which to get the pifisrf

        :return: dictionnary following the format {"Pif Index"\: list of tuples (pifalt, pifact), "Lambda": list of lambda values, "SceneISRF": list of corresponding ISRF values}
        """
        # Extract the lambda values: shape = (14, 5)
        lambdamax = self.extract_var(self.PIFLAMBDA_PATH).get_value_by_dim(
                            {self.N_FS_DIM: nfs, self.N_FOV_DIM: nfov, self.N_BAND_DIM: nband, self.N_LAMBDA_DIM: nwl})
        print(lambdamax.shape)
        lambdamax_broadcast = lambdamax[:, :, np.newaxis] # new shape = (14, 5, 1)
        # Extract the ISRF values: shape = (14, 5, 301)
        sceneisrf = self.extract_var(self.PIFSCENEISRF_PATH).get_value_by_dim(
                            {self.N_FS_DIM: nfs, self.N_FOV_DIM: nfov, self.N_BAND_DIM: nband, self.N_LAMBDA_DIM: nwl})
        print(sceneisrf.shape)
        # Extract the dlambda values: shape = (1, 1, 301)
        dlambda = self.extract_var(self.PIFISRFDLAMBDA_PATH).get_value_by_dim(
                            {self.N_FS_DIM: nfs, self.N_FOV_DIM: nfov, self.N_BAND_DIM: nband})
        print(dlambda.shape)
        lambdas = lambdamax_broadcast + dlambda # shape = (14, 5, 301)
        # Get the pif indexes before flattening
        i = np.repeat(np.arange(lambdas.shape[0]), lambdas.shape[1] * lambdas.shape[2])
        j = np.tile(np.repeat(np.arange(lambdas.shape[1]), lambdas.shape[2]), lambdas.shape[0])
        pifs = list(zip(i,j))
        print(pifs)

        isrf_vals_dict = {"Pif Index": pifs,
                            "SceneISRF": sceneisrf.flatten(),
                            "Lambda": lambdas.flatten()}
        return isrf_vals_dict


class MicroCarbISRF(AbstractMicroCarb_L1):
    """
    This class enables to open a MicroCarb ISRF product and extract its data

    Attributes:
        file_path(str): the path of the ISRF file
        reader: the file reader
    """
    # Paths of variable
    ISRFDLAMBDA_PATH= "Isrf/IsrfdLambda"
    SCENEISRF_PATH= "Isrf/SceneIsrf"
    # N_ISRF_DIM = "nIsrf"

    def __init__(self, file_path, useXarray=False) -> None:
        """
        Initialize the class attributes.

        :param: file_path: the file path of the MicroCarb ISRF product
        :param: useXarray: if set to True, the product reader will use the xarray library instead of netcdf.
        """
        super().__init__(file_path, useXarray)
        if self.get_product_level() != "1B_ISRF___":
            raise f"ERROR: {self.file_path} is not an L1B ISRF file."

    def get_isrf_from_fov(self, l1_product: AbstractMicroCarb_L1 | None, nfs: int, nfov: int, nband: int, nlambda: int) -> dict[list] | None:
        """
        Get the ISRF for a specific fov.

        :param: l1_product: MCA L1B or L1C product from which to get the lambda values to add to the dlambda values
        :param: nfs, nfov: Fs and Fov index for the desired fov
        :param: nband: desired band for which to get the isrf
        :param: nlambda: desired wavelength index for which to get the isrf

        :return: dictionnary following the format {"Lambda": list of lambda values, "SceneISRF": list of corresponding ISRF values}
        """
        if not l1_product:
            return None
        isrf_vals = {'Lambda': [], 'SceneISRF': []}
        sceneisrfs = self.extract_var(self.SCENEISRF_PATH)
        dlambdas = self.extract_var(self.ISRFDLAMBDA_PATH)
        lambda0 = l1_product.extract_var(l1_product.LAMBDA_PATH).get_value_by_dim(
                        {self.N_FS_DIM: nfs, self.N_FOV_DIM: nfov, self.N_BAND_DIM: nband, self.N_LAMBDA_DIM: nlambda})
        isrf_vals["SceneISRF"] = list(sceneisrfs.get_value_by_dim({self.N_FS_DIM: nfs, self.N_FOV_DIM: nfov, self.N_BAND_DIM: nband, self.N_LAMBDA_DIM: nlambda}))
        isrf_vals["Lambda"] = list(np.array(dlambdas.get_value_by_dim({self.N_FS_DIM: nfs, self.N_FOV_DIM: nfov, self.N_BAND_DIM: nband})) + lambda0)
        return isrf_vals


class MicroCarbL1C(AbstractMicroCarb_L1):
    """
    This class enables to open a MicroCarb L1C product and extract its data

    Attributes:
        file_path(str): the path of the L1C file
        reader: the file reader
    """
    # Paths of variables
    SPECTRUM_PATH = "/SpectrumMeasurementFsFov/Radiance"
    LAMBDA_PATH = "/SpectrumMeasurementFsFov/Lambda"

    def __init__(self, file_path, useXarray=False) -> None:
        """
        Initialize the class attributes.

        :param: file_path: the file path of the MicroCarb L1C product
        :param: useXarray: if set to True, the product reader will use the xarray library instead of netcdf.
        """
        super().__init__(file_path, useXarray)
        if self.get_product_level() != "1C_PRODUCT":
            raise f"ERROR: {self.file_path} is not an L1C PRODUCT file."

    def get_spectrum_from_fov(self, nfs: int, nfov: int, nband: int) -> dict[list]:
        """
        Get the spectrum for a specific fov.

        :param: nfs, nfov: Fs and Fov index for the desired fov
        :param: nband: desired band for which to get the spectrum

        :return: dictionnary following the format {"File\: list of 'L1C's, "Lambda": list of lambda values, "Radiance": list of corresponding radiance values}
        """
        spectrum_vals = {'File': [], 'Lambda': [], 'Radiance': []}
        spectrum = self.extract_var(self.SPECTRUM_PATH)
        lambdas = self.extract_var(self.LAMBDA_PATH)
        spectrum_vals["File"] = ["L1C"] * spectrum.dimensions[self.N_LAMBDA_DIM]
        spectrum_vals["Lambda"] = list(lambdas.get_value_by_dim({self.N_FS_DIM: nfs, self.N_FOV_DIM: nfov, self.N_BAND_DIM: nband}))
        rad_spc = spectrum.get_value_by_dim({self.N_FS_DIM: nfs, self.N_FOV_DIM: nfov, self.N_BAND_DIM: nband})
        if spectrum.get_fill_value():
            rad_spc[rad_spc <= spectrum.get_fill_value()] = np.nan
        spectrum_vals["Radiance"] = list(rad_spc)
        return spectrum_vals

    def get_var(self,var_path: str) -> dict:
        """
            Return values of a variable and their corresponding coordinates
            :return dictionnary{Latitude,Longitudes,Values} 
        """
        # Get the coordinates of fov centers and corners
        center_coord_var = self.extract_var(self.CENTER_LATLONALT_PATH)
        vertices_coord_var = self.extract_var(self.VERTICES_LATLONALT_PATH)
        # Get dimensions sizes
        tot_fs = center_coord_var.dimensions[self.N_FS_DIM]
        tot_fovs = center_coord_var.dimensions[self.N_FOV_DIM]

        try :
            var = self.extract_var(var_path)
        except Exception as e: 
            print(e)
            return {'Latitude': [], 'Longitude': [], 'Fs': [], 'Fov': [], var_path.split('/')[::-1][0] : []}
        else :
            vals = {'Fs': [], "Fov": [] , 'Longitude': [], 'Latitude': [], var_path: []}
            for fs in range(tot_fs):
                for fov in range(tot_fovs):
                    lat, lon, alt = center_coord_var.get_value_by_dim({self.N_FS_DIM: fs, self.N_FOV_DIM: fov})
                    var_value = var.get_value_by_dim({self.N_FS_DIM: fs, self.N_FOV_DIM: fov})
                    vals['Longitude'].append(lon)
                    vals['Latitude'].append(lat)
                    vals['Fov'].append(fov)
                    vals['Fs'].append(fs)
                    vals[var_path].append(var_value)
        return vals

    def get_cloud_index(self) -> dict :
        """
        Return the values of the Cloud Index

        :return: dictionnary of the Cloud Index values and their corresponding coordinates
        
        """

        # # Get the coordinates of fov centers and corners
        # center_coord_var = self.extract_var(self.CENTER_LATLONALT_PATH)
        # vertices_coord_var = self.extract_var(self.VERTICES_LATLONALT_PATH)
        # cloud_index_var = self.extract_var(self.CLOUD_INDEX_PATH)
        # # Get dimensions sizes
        # tot_fs = center_coord_var.dimensions[self.N_FS_DIM]
        # tot_fovs = center_coord_var.dimensions[self.N_FOV_DIM]

        # cloud_index_dict = {'Fs': [], "Fov": [] , 'Longitude': [], 'Latitude': [], 'CloudIndex': []}

        # for fs in range(tot_fs):
        #     for fov in range(tot_fovs):
        #         lat, lon, alt = center_coord_var.get_value_by_dim({self.N_FS_DIM: fs, self.N_FOV_DIM: fov})
        #         cloud_index = cloud_index_var.get_value_by_dim({self.N_FS_DIM: fs, self.N_FOV_DIM: fov})
        #         cloud_index_dict['Longitude'].append(lon)
        #         cloud_index_dict['Latitude'].append(lat)
        #         cloud_index_dict['Fov'].append(fov)
        #         cloud_index_dict['Fs'].append(fs)
        #         cloud_index_dict['CloudIndex'].append(cloud_index)
        
        return self.get_var(self.CLOUD_INDEX_PATH)

    def extract_uniform_isrf(self) -> hdfu.HDFVariable:
        """
        Extract ISRF from field SpectrumMeasurementFsFov/UniformIsrf
        Size: nFov x nBand x nLambda x nUniformIsrf

        :return: the uniform ISRF
        """
        var_path = "SpectrumMeasurementFsFov/UniformIsrf"
        return self.reader.get_var(var_path)

    def extract_acq_time_string(self) -> hdfu.HDFVariable:
        """
        Acquisition time for the center of the FrameSync (YYYY-MM-DDThh:mm:ss.nnnZ)
        from field MetaDataFs/AcquisitionTimeString
        Size: nFs

        :return: the acquisition time string
        """
        var_path = "MetaDataFs/AcquisitionTimeString"
        return self.reader.get_var(var_path)

    def extract_radiance(self) -> hdfu.HDFVariable:
        """
        Calibrated radiance for Bi band from field SpectrumMeasurementFsFov/Radiance
        Size: nFs x nFov x nBand x nLambda

        :return: the measured radiance
        """
        var_path = "SpectrumMeasurementFsFov/Radiance"
        return self.reader.get_var(var_path)

    def extract_solar_zenith(self) -> hdfu.HDFVariable:
        """
        Solar zenith angle of IFOV center, at acquisition mid-time from field SpectrumGeometryFsFov/SolarZenith
        Size: nFs x nFov

        :return: the sun zenith angle
        """
        var_path = "SpectrumGeometryFsFov/SolarZenith"
        return self.reader.get_var(var_path)

    def extract_tun_id(self) -> hdfu.HDFVariable:
        """
        Identifier of TUN used to generate the product from field MetaDataGranule/L1TunId
        Size: nL1TunId

        :return: the TUN ids
        """
        var_path = "MetaDataGranule/L1TunId"
        return self.reader.get_var(var_path)

    def extract_spike_map(self) -> hdfu.HDFVariable:
        """
        Boolean map of spikes on the detector from field SpectrumMeasurementFsFov/SpikeMap
        Size: nFs x nFov x nBand x nLambda

        :return: the spikes
        """
        var_path = "SpectrumMeasurementFsFov/SpikeMap"
        return self.reader.get_var(var_path)

    def extract_lambda(self) -> hdfu.HDFVariable:
        """
        Wavelength samples for Bi band from field SpectrumMeasurementFsFov/Lambda (in µm)
        Size: nFs x nFov x nBand x nLambda

        :return: the wavelengths
        """
        var_path = "SpectrumMeasurementFsFov/Lambda"
        return self.reader.get_var(var_path)

    def extract_uniform_isrf_d_lambda(self) -> hdfu.HDFVariable:
        """
        Spectral coordinates of uniform ISRF around barycenter from field SpectrumMeasurementFsFov/UniformIsrfdLambda (in µm)
        Size: nBand x nUniformIsrf

        :return: the wavelengths
        """
        var_path = "SpectrumMeasurementFsFov/UniformIsrfdLambda"
        return self.reader.get_var(var_path)

    def extract_dimension(self, dimension_name: str) -> int:
        """
        Return the value of the input dimension

        :param dimension_name: the dimension name (for example: nFov)
        """
        var_path = "Dimensions/" + dimension_name
        var = self.reader.get_var(var_path)
        return int(var.get_data())

    def extract_sun_azimuth(self) -> hdfu.HDFVariable:
        """
        Solar azimuth angle of IFOV center, from field SpectrumGeometryFsFov/SolarAzimuth
        Dimensions: (nFs, nFov)

        :return: hdfu.HDFVariable holding the sun azimuth angle (degrees)
        """
        var_path = "SpectrumGeometryFsFov/SolarAzimuth"
        return self.reader.get_var(var_path)

    def extract_satellite_zenith(self) -> hdfu.HDFVariable:
        """
        Satellite zenith angle of IFOV center, from field SpectrumGeometryFsFov/SatelliteZenith
        Dimensions: (nFs, nFov)

        :return: hdfu.HDFVariable holding the satellite zenith angle (degrees)
        """
        var_path = "SpectrumGeometryFsFov/SatelliteZenith"
        return self.reader.get_var(var_path)

    def extract_satellite_azimuth(self) -> hdfu.HDFVariable:
        """
        Satellite azimuth angle of IFOV center, from field SpectrumGeometryFsFov/SatelliteAzimuth
        Dimensions: (nFs, nFov)

        :return: hdfu.HDFVariable holding the satellite azimuth angle (degrees)
        """
        var_path = "SpectrumGeometryFsFov/SatelliteAzimuth"
        return self.reader.get_var(var_path)

    def extract_fov_center_geodet(self) -> hdfu.HDFVariable:
        """
        FOV center geodetic coordinates (latitude, longitude, altitude),
        from field SpectrumGeometryFsFov/FovCenterGeodet
        Dimensions: (nFs, nFov, 3)

        :return: hdfu.HDFVariable holding an array of shape (nFs, nFov, 3)
                 where the last index is [latitude (deg), longitude (deg), altitude (m)]
        """
        var_path = "SpectrumGeometryFsFov/FovCenterGeodet"
        return self.reader.get_var(var_path)

    def extract_cloud_index(self) -> hdfu.HDFVariable:
        """
        Synthetic cloud index (1=probably cloud-free; 3=probably cloudy; 4=surely cloudy),
        from field CloudFlags/CloudIndex
        Dimensions: (nFs, nFov)

        :return: hdfu.HDFVariable holding cloud index flags (ubyte)
        """
        var_path = "CloudFlags/CloudIndex"
        return self.reader.get_var(var_path)

    def extract_cloud_flag_inversion_fov(self) -> hdfu.HDFVariable:
        """
        Cloud detection flag from the inversion of several bands at FOV resolution,
        from field CloudFlags/CloudFlagInversionFov
        Dimensions: (nFs, nFov)

        :return: hdfu.HDFVariable holding inversion?based cloud flags (ubyte)
        """
        var_path = "CloudFlags/CloudFlagInversionFov"
        return self.reader.get_var(var_path)

    def extract_img_data_valid(self) -> hdfu.HDFVariable:
        """
        Image?data validity flag per FrameSync (nFs),
        from field MetaDataFs/ImgDataValid
        Dimensions: (nFs,)

        :return: hdfu.HDFVariable holding image validity flags (ubyte)
        """
        var_path = "MetaDataFs/ImgDataValid"
        return self.reader.get_var(var_path)

