# Copyright (c) 2024-2026 Centre National d'Etudes Spatiales (CNES).
#
# This file is part of AtmoTools
# (see https://github.com/CNES/AtmoTools).
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

import os

import numpy as np
import pandas as pd
import plotly.express as px

from dash import Dash, Input, Output, State, callback, dcc

import atmotools.utils.path_utils as pu
import atmotools.missions.MicroCarb.services.figures as fg
from atmotools.missions.MicroCarb.config import FOV_COLOR, PIF_COLOR


def create_callbacks(app, data):


    @app.callback(
        Output('spectra', 'children'),
        Output('save-spectrum-button','n_clicks'),
        Input('fov_map', 'selectedData'),
        Input('save-spectrum-button','n_clicks'),
        prevent_initial_call = False)
    def update_spectra(selectedData, nb_click_save_button):
        selected_fovs = []
        # Return default graphs to the app if no fov is selected on the map
        if not selectedData:
            return ([dcc.Graph(figure = fg.show_empty_spectra("Spectrum Band 1")),
                    dcc.Graph(figure = fg.show_empty_spectra("Spectrum Band 2")),
                    dcc.Graph(figure = fg.show_empty_spectra("Spectrum Band 3")),
                    dcc.Graph(figure = fg.show_empty_spectra("Spectrum Band 4"))], 
                    0) # Reset nb_click of the  save-spectrum-button

        # Get the info for all selected fovs (i.e. file number, fs and fov)
        selected_fovs = data.select(selectedData)

        return ([show_spectrum(selected_fovs, band, nb_click_save_button) for band in range(4)], 0) if (data.isL1B or data.isL1C) else ([
                    dcc.Graph(figure = fg.show_empty_spectra("Spectrum Band 1")),
                    dcc.Graph(figure = fg.show_empty_spectra("Spectrum Band 2")),
                    dcc.Graph(figure = fg.show_empty_spectra("Spectrum Band 3")),
                    dcc.Graph(figure = fg.show_empty_spectra("Spectrum Band 4"))],
                0) # Reset nb_click of the  save-spectrum-button


    # Return the figure with the spectrums for all selected fovs for all bands
    def show_spectrum(fovs, nband :int, nb_click_save_button):

        # Get spectrum data 
        spc_df = data.get_spectra_data(fovs, nband)

        # Save the graph as a .csv file #MOVE TO A SPECIFIC CALLBACK #UPGRADETODO
        if nb_click_save_button > 0 :
            data.export_spectra_as_csv()

        # Show L1C and L1B on same graph if only one fov is selected, else show L1B and L1C on two separate graphs for better readability
        if len(fovs) <= 1:
            fov = fovs[0] 
            mean_radiance = data.preloaded_variable_df[(data.preloaded_variable_df.Fs==fov[0]) & (data.preloaded_variable_df.Fov==fov[1])][f'MeanRadianceB{nband+1}'].values[0] #Get the meanRadiance continuum
            
            fig = fg.trace_spectrum(spc_df, 
                    title = f'Spectrum Band {nband + 1} for (Fs: {int(fov[0])}, For: {int(fov[1])}) in file {fov[2]} ({data.file_index_to_prod[fov[2]]})<br>MeanRadiance(L1B): {mean_radiance} W/m²/sr/µm', 
                    hover_data = {"Acquisition Time": spc_df.apply(lambda row : data.file_index_to_prod[row['Fov Index'][2]], axis=1)}, 
                    color = 'File')
        else:
            fig = fg.trace_spectrum(spc_df, 
                    title = f'Spectrum Band {nband + 1}', 
                    hover_data = {"Acquisition Time": spc_df.apply(lambda row : data.file_index_to_prod[row['Fov Index'][2]], axis=1)}, 
                    color = 'Fov Index', 
                    legend = dict(title=dict(text="Fov Index (Fs, Fov, File)")),
                    facet_col='File')
                    
        return dcc.Graph(figure = fig)

    # Update map on fs, fov selection
    @app.callback(
        Output("fov_map", "figure"),
        Input("fs_selection", "value"),
        Input("fov_selection", "value"),
        Input("show-squares", "value"),
        Input("filtermap-radio", "value"),
        Input("slider", "value"),
        Input("show-pif", "value"),
        Input("pif-alt-selection","value"),
        Input("pif-act-selection","value"),
        prevent_initial_call = False)
    def update_flags_map(fss, fovs, show_squares, filtermap, slider, show_pif, pif_alts, pif_acts):
        # Initialize lists of selected objects
        selected_feat = []
        indexes = []
        range_color_value =[slider[0],slider[1]] if slider else None

        if filtermap != 'None' :
            color = pd.DataFrame({filtermap : data.get_color(filtermap)}) # Get the data for the color of the map values
        else :
            color = pd.DataFrame({filtermap :[]})

        # Compute layers for selected data 
        layers = []
        if show_squares :
            selected_feat = data.get_geojson_geometry(fss, fovs)
            layers.append({
                            'source': {
                                    'type': "FeatureCollection",
                                    'features': selected_feat
                                },
                                'type': "line", 'below': "traces", 'color': FOV_COLOR, 'opacity' : 0.45,
                            })
        if show_pif :
            selected_feat_pif = data.get_geojson_geometry_for_pif(fss, fovs, pif_acts, pif_alts)
            layers.append({
                            'source': {
                                    'type': "FeatureCollection",
                                    'features': selected_feat_pif
                                },
                                'type': "fill", 'below': "traces", 'color': PIF_COLOR, 'opacity' : 0.30
                            })

        # Return figure with all fovs if no selection is made or with selected fovs

        # Return empty map if no L1 file
        if not (data.isL1C or data.isL1B or data.isISRF or data.isMET):
            fig = fg.show_empty_map()

        else:
            # Keep only selected fovs 
            selected_df = data.mask(fss, fovs)
            indexes = selected_df.index.tolist()

            fig = fg.show_scatter_on_map(selected_df, 
                color = color, 
                filtermap = filtermap, 
                range_color_value = range_color_value, 
                layers = layers)

        return fig

    # Display cloud index mean when button checked
    @app.callback(
        Output('cloud-graph', 'children'),
        Input("cloudindex_mean", "value"),
        prevent_initial_call = False)
    def update_ratio_graphs(ratio_checklist):
        if not ratio_checklist:
            return None
        else :
            # Get mean of cloud index for each Fov, along the files (orbit) for each file
            files_df_mean = data.get_cloud_index_mean()

            fig = fg.show_cloud_index_mean(files_df_mean=files_df_mean)

        return dcc.Graph(id=ratio_checklist[0] , style={'display': 'inline-block'}, figure=fig)

    # Display met graphs of the selected met variables 
    @app.callback(
        Output('met_graphs', 'children'),
        Input("met_variables", "value"),
        Input('fov_map', 'selectedData'),
        prevent_initial_call = False)
    def update_met_graphs(met_variables, selectedData):

        if selectedData and met_variables: 
            # Get the info for all selected fovs (i.e. file number, fs and fov)
            selected_fovs = data.select(selectedData)

            figs = []

            for variable in met_variables:
                # If it's AerosolData we have to use lambda for x-axis 
                isAerosolData = pu.get_last_element_in_path(variable)[1] == "AerosolData"

                # Get profile data 
                profile_df = data.get_profile_data(variable, selected_fovs)

                fig= fg.show_met_graph(profile_df,
                            title = variable,
                            x = 'Lambda' if isAerosolData else 'Index',
                            y = variable,
                            hover_data = {"Acquisition Time": profile_df.apply(lambda row : data.file_index_to_prod[row['Fov Index'][2]], axis=1)})

                figs.append(dcc.Graph(figure = fig))

            return figs

    # Display choice of lambda value with a slider when isrf button is checked, depending on selected fovs
    @app.callback(
        Output('lambda_title', 'children'),
        Output('lambda', 'min'),
        Output('lambda', 'max'),
        Output('lambda', 'step'),
        Output('lambda', 'value'),
        Output('lambda', 'marks'),
        Output('lambda_container', 'style'),
        Input('isrf_checklist', 'value'),
        Input('fov_map', 'selectedData'),
        prevent_initial_call = True)
    def update_lambda_input(check_isrf, selectedData):
        if check_isrf:
            for val in check_isrf:
                if val=="isrf" and selectedData:

                    # Get all selected fovs 
                    selected_fovs = data.select(selectedData)

                    # Get all products associated to selected fovs 
                    selected_files = data.get_products(selected_fovs, 'L1C', 'L1B')

                    # Get min and max wavelengths to set slider limits
                    # mins = np.array([selected_product.extract(selected_product.LAMBDA_PATH).get_min([N_FS_DIM, N_FOV_DIM, N_BAND_DIM, N_LAMBDA_DIM]) for selected_product in selected_files])
                    # maxs = np.array([selected_product.extract(selected_product.LAMBDA_PATH).get_max([N_FS_DIM, N_FOV_DIM, N_BAND_DIM, N_LAMBDA_DIM]) for selected_product in selected_files])
                    # step = (maxs[0] - mins[0])/(N_LAMBDA - 1)
                    # min_l = mins.max()
                    # max_l = maxs.min()
                    # Less accurate but better complexity :

                    # Get min and max wavelengths to set slider limits
                    min_l = data.get_min_wavelength(selected_files[0])
                    max_l = data.get_max_wavelength(selected_files[0])
                    ntot_lambda = data.get_total_wavelength(selected_files[0])

                    step = (max_l - min_l)/(ntot_lambda - 1)
                    vals = [ntot_lambda//4*step*i + min_l for i in range(4)] + [float(max_l)]

                    # Mark for the sliders, each wavelength number is associated to its value
                    marks = {i*ntot_lambda//4 : str(round(l, 3)) for i, l in enumerate(vals)}

                    return ["Choose lambda value", 0, ntot_lambda - 1, 1, ntot_lambda//2, marks, {'marginRight': '30px', 'marginLeft': 100, 'marginTop': 50, 'width' : 600}]

            return [None, -10, 0, 1, -5, None, {'display' : "none", 'marginRight': '30px', 'width' : 600}]
        else:
            return [None, -10, 0, 1, -5, None, {'display' : "none", 'marginRight': '30px', 'width' : 600}]


    # Display choice of pif lambda value with a slider when pif isrf button is checked, depending on first selected fov
    @app.callback(
        Output('piflambda_title', 'children'),
        Output('piflambda', 'min'),
        Output('piflambda', 'max'),
        Output('piflambda', 'step'),
        Output('piflambda', 'value'),
        Output('piflambda', 'marks'),
        Output('piflambda_container', 'style'),
        Input('pifisrf_checklist', 'value'),
        Input('fov_map', 'selectedData'),
        prevent_initial_call = True)
    def update_piflambda_input(check_pifisrf, selectedData):
        if check_pifisrf:
            for val in check_pifisrf:
                if val=="pifisrf" and selectedData:
                    
                    # Get selected fovs
                    selected_fovs = data.select(selectedData) 

                    # Get products associated to first selected fov
                    l1b_eng_products = data.get_products(selected_fovs, 'L1B-ENG')
                    if not l1b_eng_products[0] :
                        # print(f"ERROR: No L1B ENG file found for point ({dff['Fs']}, {dff['Fov']}) of acquisition time {acq_id}")
                        return [None, -10, 0, 1, -5, None, {'display' : "none", 'marginRight': '30px', 'width' : 600}]

                    # Get min and max wavelengths to set slider limits
                    min_l = data.get_min_pif_wavelength(l1b_eng_products[0])
                    # Return empty slider if no info on pif isrf (i.e. if wavelengths are nan)
                    if not min_l or min_l!= min_l:
                        print("ERROR: No data found for pif ISRF")
                        return [None, -10, 0, 1, -5, None, {'display' : "none", 'marginRight': '30px', 'width' : 600}]

                    max_l = data.get_max_pif_wavelength(l1b_eng_products[0])
                    ntot_piflambda = data.get_total_pif_wavelength(l1b_eng_products[0])

                    step = (max_l - min_l)/(ntot_piflambda - 1)
                    vals = [ntot_piflambda//4*step*i + min_l for i in range(4)] + [float(max_l)]
                    # Mark for the sliders, each wavelength number is associated to its value
                    marks = {i*ntot_piflambda//4 : str(round(l, 3)) for i, l in enumerate(vals)}

                    return ["Choose lambda value", 0, ntot_piflambda - 1, 1, ntot_piflambda//2, marks, {'marginRight': '30px', 'marginLeft': 100, 'marginTop': 50, 'width' : 600}]

            return [None, -10, 0, 1, -5, None, {'display' : "none", 'marginRight': '30px', 'width' : 600}]
        else:
            return [None, -10, 0, 1, -5, None, {'display' : "none", 'marginRight': '30px', 'width' : 600}]


    # Display ISRF graphs depending on selected fovs and chosen lambda value
    @app.callback(
        Output('isrf_graphs', 'children'),
        Input('fov_map', 'selectedData'),
        Input('lambda', 'value'),
        prevent_initial_call = True)
    def update_isrf(selectedData, nwl):
        selected_fovs = []
        # Return default graphs to the app if no fov is selected on the map
        if not selectedData or nwl < 0:
            return None

        selected_fovs = data.select(selectedData)

        return [show_isrf(selected_fovs, band, nwl) for band in range(4)] if data.isISRF else None


    # Return the figure with the isrf for all selected fovs, for a certain wavelength and a certain band
    def show_isrf(fovs, nband :int, nwl):
        spc_df = data.get_isrf_data(fovs, nband, nwl)

        fig = fg.trace_isrf(spc_df, 
                title = f'SceneISRF for Band {nband + 1} at wavelength number {nwl}',
                hover_data = {"Acquisition Time": spc_df.apply(lambda row : data.file_index_to_prod[row['Fov Index'][2]], axis=1)})

        return dcc.Graph(figure = fig)

    # Display Pif ISRF graphs depending on first selected fov and chosen lambda value
    @app.callback(
        Output('pifisrf_graphs', 'children'),
        Input('fov_map', 'selectedData'),
        Input('piflambda', 'value'),
        prevent_initial_call = True)
    def update_pifisrf(selectedData, nwl):
        # Return None if no fov is selected on the map
        if not selectedData or nwl < 0:
            return None

        # Get the info for first selected fov (i.e. file number, fs and fov)
        selected_fov = data.select(selectedData)[0]  

        return [show_pifisrf(selected_fov, band, nwl) for band in range(4)] if data.isL1BENG else None


    # Return the figure with the pif isrf for first selected fov, for a certain wavelength and a certain band
    def show_pifisrf(fov, nband :int, nwl):
        
        # Get pif isrf data 
        pifs_df = data.get_pifisrf_data(fov, nband, nwl)

        fig = px.line(pifs_df, x='Lambda', y='SceneISF', color = 'Pif Index',
                      title= f'PifSceneISRF for Band {nband + 1} at wavelength number {nwl} for Fov {tuple(fov[:2])} in file {fov[2]} ({data.file_index_to_prod[fov[2]]})', height=400)
        return dcc.Graph(figure = fig)

    # Display the range slider to change the max and the min of the co2 colorscale
    @app.callback(
        Output("slider-div","children"),
        Input("filtermap-radio", "value"),
        prevent_initial_call = False
    )
    def display_slider(filtermap) :
        if filtermap not in ["None", "CloudFlags/CloudIndex"] :
            color = data.get_color(filtermap)
            if not pd.isna(color).all() :
                max_value = np.nanmax(color)
                min_value = np.nanmin(color)
            else :
                min_value = -50
                max_value = 50
            return dcc.RangeSlider(min_value, max_value,id = 'slider',vertical=True,marks=None,tooltip={"always_visible": True} )

        else :
            return None

    @app.callback(
        Output("pif-div","children"),
        Input("show-pif","value"),
        prevent_initial_call = False
    )
    def display_pif_dropdown(show_pif):
        if show_pif :
                    return [
                        dcc.Dropdown(data.df_pif['PifAlt'].dropna().unique() if (data.isL1C or data.isL1B) else [""],multi=True, id = "pif-alt-selection", placeholder="Pif Alt", disabled=not (data.isL1C or data.isL1B)),
                        dcc.Dropdown(data.df_pif['PifAct'].dropna().unique() if (data.isL1C or data.isL1B) else [""],multi=True, id = "pif-act-selection", placeholder="Pif Act", disabled=not (data.isL1C or data.isL1B))
                    ]
        else :
            return None