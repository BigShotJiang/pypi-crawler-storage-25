# Copyright (c) 2024-2026 Centre National d'Etudes Spatiales (CNES).
#
# This file is part of AtmoTools
# (see https://github.com/CNES/AtmoTools).
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

from dash import dcc, html

def create_layout(data):

    return html.Div([
            html.Div([
                html.Div([
                    # Map with colored fovs
                    html.Div([
                        dcc.Graph(id="fov_map")],
                        style={
                        'flexShrink': 0
                                }
                        ),
                    # Range slider for the min and max of CO2 scale
                    html.Div([
                        dcc.RangeSlider(0,0,id = 'slider')
                    ],
                        id = 'slider-div',
                        style ={},
                    ),
                    # Checklist to choose what to display
                    html.Div([
                        # Check button to diplay fov squares or not
                        html.Div([
                            dcc.Checklist(id="show-squares", options = ["Display fov squares"])
                            ],
                            style = {"marginBottom": "30px"} if (data.isL1C or data.isL1B or data.isISRF or data.isMET) else {"marginBottom": "30px", "pointerEvents": "none", "opacity": 0.5}),
                        # Check button to diplay Pif squares or not
                        html.Div([
                            dcc.Checklist(id="show-pif", options = ["Display Pif squares"])
                            ],
                            style = {"marginBottom": "30px"} if (data.isL1C or data.isL1B) else {"marginBottom": "30px", "pointerEvents": "none", "opacity": 0.5}),
                        # Dropdown menus to choose Pif Alt and Pif Act on the map
                        html.Div([
                            dcc.Dropdown(id = "pif-alt-selection"),
                            dcc.Dropdown(id = "pif-act-selection")
                                ],
                            id = 'pif-div',
                            style = {'marginBottom': '30px'}),
                        # Check buttons to choose graphs to display
                        html.Div([
                            dcc.Checklist(id="cloudindex_mean", options={"cloud": "Cloud Index mean"})
                            ],
                            style = {"marginTop": '50px'} if data.isL1C else {"marginTop": '50px', "pointerEvents": "none", "opacity": 0.5}),
                        html.Div([
                            dcc.Checklist(id="met_variables", 
                                options=[
                                    {'label': 'Co2 MixingRatio Profile', 'value': 'Co2Data/Co2MixingRatioProfile'} ,
                                    {'label': 'H2o MixingRatio Profile', 'value': 'MeteorologicalData/H2oMixingRatioProfile'},
                                    {'label': 'Single Scattering Albedo', 'value': 'AerosolData/SingleScatteringAlbedo'},
                                    {'label': 'Asymmetry Factor', 'value': 'AerosolData/AsymmetryFactor'},
                                    {'label': 'Aod', 'value': 'AerosolData/Aod'}
                                ])
                            ],
                            style = {"marginTop": '50px'} if data.isMET else {"marginTop": '50px', "pointerEvents": "none", "opacity": 0.5}),
                        # Check buttons to choose values to display as color on the map
                        html.Div([
                            dcc.RadioItems([
                                    {'label': 'None', 'value': 'None', 'disabled': False},
                                    {'label': 'Co2 Column', 'value': 'RetrievalResults/Co2Column', 'disabled': False if data.isL2 else True},
                                    {'label': 'H2O Column', 'value': 'RetrievalResults/H2oColumn', 'disabled': False if data.isL2 else True},
                                    {'label': 'Surface Pressure', 'value': 'RetrievalResults/Psurf', 'disabled': False if data.isL2 else True},
                                    {'label': 'Cloud Index', 'value': 'CloudFlags/CloudIndex', 'disabled': False if data.isL1C else True},
                                    {'label': 'MidBandSif', 'value': 'RetrievalResults/MidBandSif', 'disabled': False if data.isL2 else True},
                                    {'label': 'AirglowWarm', 'value': 'RetrievalResults/AirglowWarm', 'disabled': False if data.isL2 else True},
                                    {'label': 'AirglowCold', 'value': 'RetrievalResults/AirglowCold', 'disabled': False if data.isL2 else True},
                                    {'label': 'AerosolAot', 'value': 'RetrievalResults/AerosolAot', 'disabled': False if data.isL2 else True},
                                    {'label': 'AerosolZ', 'value': 'RetrievalResults/AerosolZ', 'disabled': False if data.isL2 else True},
                                    {'label': 'AerosolK', 'value': 'RetrievalResults/AerosolK', 'disabled': False if data.isL2 else True},
                                    {'label': 'Continuum Band 1', 'value': 'MeanRadianceB1', 'disabled': False if data.isL2 else True},
                                    {'label': 'Continuum Band 2', 'value': 'MeanRadianceB2', 'disabled': False if data.isL2 else True},
                                    {'label': 'Continuum Band 3', 'value': 'MeanRadianceB3', 'disabled': False if data.isL2 else True},
                                    {'label': 'Continuum Band 4', 'value': 'MeanRadianceB4', 'disabled': False if data.isL2 else True},
                                    {'label': 'MetSurfacePressure', 'value': 'MeteorologicalData/MetSurfacePressure', 'disabled': False if data.isMET else True },
                                    {'label': 'Kaero', 'value': 'AerosolData/Kaero', 'disabled': False if data.isMET else True },
                                    {'label': 'Zaero', 'value': 'AerosolData/Zaero', 'disabled': False if data.isMET else True },
                                ], value = 'None', id="filtermap-radio")
                            ],
                            style = {"marginBottom": '20px'}),
                        html.Div([
                            dcc.Checklist(id="isrf_checklist", options={"isrf": "ISRF"})
                            ],
                            style = {"pointerEvents": "none", "opacity": 0.5} if not (data.isISRF and (data.isL1C or data.isL1B)) else None),
                        html.Div([
                            dcc.Checklist(id="pifisrf_checklist", options={"pifisrf": "ISRF per Pif"})
                            ],
                            style = {"pointerEvents": "none", "opacity": 0.5} if not data.isL1BENG else None)
                        ],
                        style={
                            'padding': 20,
                            'flexShrink': 0
                                }),

                    html.Div([
                        # Dropdown menus to choose fs and fovs to show on the map
                        html.Div([
                            dcc.Dropdown(
                                data.df['Fs'].dropna().unique()  if (data.isL1C or data.isL1B or data.isMET) else [""],
                                multi=True, id = "fs_selection", placeholder="Fs", disabled=not (data.isL1C or data.isL1B or data.isISRF or data.isMET)),
                            dcc.Dropdown(
                                data.df['Fov'].dropna().unique() if (data.isL1C or data.isL1B or data.isMET) else [""],
                                multi=True, id = "fov_selection", placeholder="Fov", disabled=not (data.isL1C or data.isL1B or data.isISRF or data.isMET)),
                                ],
                            style = {'marginBottom': '30px'}
                            ),
                        ],
                        style={'display': 'flex',
                            'flexDirection': 'column',
                            'padding' : 20,
                            'width' : 150
                            }),

                ], style={
                'display': 'flex',
                'flexDirection': 'row',
                'alignItems': 'flex-start',
                    }  ),

            # Graph for the cloud index
            html.Div(id="cloud-graph",
                style={
                    'display': 'flex',
                    'flexDirection': 'row',
                    'alignItems': 'flex-start',
                    'flexWrap': 'wrap',
                    'padding' : 20
                }),

            # Graph for the data profiles
            html.Div(id="met_graphs",
                style={
                    'display': 'flex',
                    'flexDirection': 'row',
                    'alignItems': 'flex-start',
                    'flexWrap': 'wrap',
                    'padding' : 20
                }),

        html.Div([
            # Slider to choose the value of lambda for the ISRF graphs
            html.Div([
                html.Div(id="lambda_title"),
                dcc.Slider(id = "lambda", min = -10, max = 0, step = 1, value=-5, tooltip={"always_visible": True})
                ], id = "lambda_container",
                style = {'display' : "none", 'marginRight': '30px', 'marginLeft': '30px', 'width' : 600}
                ),
            # Graph for the ISRF
            html.Div(id = "isrf_graphs",
                style={
                    'display': 'flex',
                    'flexDirection': 'row',
                    'alignItems': 'flex-start',
                    'flexWrap': 'wrap',
                    'padding': 20
                    }
                ),

            # Slider to choose the value of lambda for the PifISRF graphs
            html.Div([
                html.Div(id="piflambda_title"),
                dcc.Slider(id = "piflambda", min = -10, max = 0, step = 1, value=-5, tooltip={"always_visible": True})
                ], id = "piflambda_container",
                style = {'display' : "none", 'marginRight': '30px', 'marginLeft': 200, 'width' : 600}
                ),
            # Graph for the PifISRF
            html.Div(id = "pifisrf_graphs",
                style={
                    'display': 'flex',
                    'flexDirection': 'row',
                    'alignItems': 'flex-start',
                    'flexWrap': 'wrap',
                    'padding': 20
                    }
                ),
                ],
        )],

        style={
            'display': 'flex',
            'flexDirection': 'column',
        }),
        # Button to save spectrum to .csv format 
            html.Div([
                html.Button('Save spectra as .csv', id="save-spectrum-button", n_clicks=0),
                ],
                style = {"marginTop": '50px'} if (data.isL1C or data.isL1B) else {"marginTop": '50px', "pointerEvents": "none", "opacity": 0.5}),
        # Graphs for the spectra
            html.Div([
                html.Div(id="spectra"),
                    ],
                    style={'flexShrink': 0, 'width' : 550, 'flexGrow': 1} if (data.isL1C or data.isL1B) else {
                        'flexShrink': 0,'width' : 550, 'flexGrow': 1, "pointerEvents": "none", "opacity": 0.5})
        ],
            style={
                'display': 'flex',
                'flexDirection': 'row',
                'alignItems': 'flex-start',
        })