from __future__ import annotations

from saasbase.common.actor import ActorRef
from saasbase.common.authz import Action, Role
from saasbase.common.resource import ResourceRef


def object_string(resource: ResourceRef) -> str:
    return f"{resource.type.name.lower()}:{resource.id}"


def user_string(actor: ActorRef) -> str:
    return f"{actor.type.name.lower()}:{actor.id}"


def role_relation(role: Role) -> str:
    return role.name.lower()


def action_relation(action: Action) -> str:
    return action.name.lower()
