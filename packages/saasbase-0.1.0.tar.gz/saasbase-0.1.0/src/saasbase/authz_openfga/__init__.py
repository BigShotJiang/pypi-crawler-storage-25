"""OpenFGA-backed authorization engine — forwards check/grant/revoke/list-objects to an OpenFGA server."""

from saasbase.authz_openfga.config import OpenFgaConfig
from saasbase.authz_openfga.engine import OpenFgaAuthzEngine

__all__ = ["OpenFgaAuthzEngine", "OpenFgaConfig"]
