from __future__ import annotations

import json
from typing import Any

from saasbase.common.exceptions import SaaSBaseError


class OpenFgaHttpClient:
    """Thin HTTP wrapper for the OpenFGA REST API. Uses httpx if available, falls back to urllib."""

    def __init__(self, api_url: str, bearer_token: str | None = None) -> None:
        self._api_url = api_url.rstrip("/")
        self._bearer_token = bearer_token
        self._client: Any = None
        try:
            import httpx  # type: ignore

            self._client = httpx.Client(timeout=10.0)
        except ImportError:
            self._client = None

    def _headers(self) -> dict[str, str]:
        headers = {"content-type": "application/json", "accept": "application/json"}
        if self._bearer_token:
            headers["authorization"] = f"Bearer {self._bearer_token}"
        return headers

    def post(self, path: str, body: dict[str, Any]) -> dict[str, Any]:
        url = f"{self._api_url}/{path.lstrip('/')}"
        payload = json.dumps(body).encode("utf-8")
        headers = self._headers()
        if self._client is not None:
            response = self._client.post(url, content=payload, headers=headers)
            if response.status_code >= 400:
                raise SaaSBaseError(
                    f"OpenFGA {path} failed: HTTP {response.status_code}: {response.text}"
                )
            return response.json()
        # urllib fallback
        import urllib.error
        import urllib.request

        request = urllib.request.Request(url, data=payload, headers=headers, method="POST")
        try:
            with urllib.request.urlopen(request, timeout=10.0) as resp:
                return json.loads(resp.read().decode("utf-8"))
        except urllib.error.HTTPError as exc:  # pragma: no cover
            raise SaaSBaseError(
                f"OpenFGA {path} failed: HTTP {exc.code}: {exc.read().decode('utf-8', 'replace')}"
            ) from exc

    def close(self) -> None:
        if self._client is not None:
            try:
                self._client.close()
            except Exception:
                pass
