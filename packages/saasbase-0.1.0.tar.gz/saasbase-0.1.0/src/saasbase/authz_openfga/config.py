from __future__ import annotations

from dataclasses import dataclass


@dataclass(frozen=True, slots=True)
class OpenFgaConfig:
    api_url: str
    store_id: str
    authorization_model_id: str
    bearer_token: str | None = None
