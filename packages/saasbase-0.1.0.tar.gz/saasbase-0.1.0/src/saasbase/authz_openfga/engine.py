from __future__ import annotations

from saasbase.authz_openfga.config import OpenFgaConfig
from saasbase.authz_openfga.http_client import OpenFgaHttpClient
from saasbase.authz_openfga.tuple_mapper import (
    action_relation,
    object_string,
    role_relation,
    user_string,
)
from saasbase.common.actor import ActorRef, ActorType
from saasbase.common.authz import Action, Role
from saasbase.common.resource import ResourceRef


class OpenFgaAuthzEngine:
    """AuthzEngine that forwards to an OpenFGA server.

    Grant/revoke are translated to role-relation tuples; `can` uses the check API; parent-child
    hierarchy is written as an explicit `parent` relation.
    """

    def __init__(self, config: OpenFgaConfig) -> None:
        self._config = config
        self._client = OpenFgaHttpClient(config.api_url, config.bearer_token)

    def _store_path(self, suffix: str) -> str:
        return f"stores/{self._config.store_id}/{suffix}"

    def grant(self, resource: ResourceRef, actor: ActorRef, role: Role) -> None:
        self._client.post(
            self._store_path("write"),
            {
                "authorization_model_id": self._config.authorization_model_id,
                "writes": {
                    "tuple_keys": [
                        {
                            "user": user_string(actor),
                            "relation": role_relation(role),
                            "object": object_string(resource),
                        }
                    ]
                },
            },
        )

    def revoke(self, resource: ResourceRef, actor: ActorRef, role: Role) -> None:
        self._client.post(
            self._store_path("write"),
            {
                "authorization_model_id": self._config.authorization_model_id,
                "deletes": {
                    "tuple_keys": [
                        {
                            "user": user_string(actor),
                            "relation": role_relation(role),
                            "object": object_string(resource),
                        }
                    ]
                },
            },
        )

    def link_parent(self, child: ResourceRef, parent: ResourceRef) -> None:
        self._client.post(
            self._store_path("write"),
            {
                "authorization_model_id": self._config.authorization_model_id,
                "writes": {
                    "tuple_keys": [
                        {
                            "user": object_string(parent),
                            "relation": "parent",
                            "object": object_string(child),
                        }
                    ]
                },
            },
        )

    def unlink_parent(self, child: ResourceRef, parent: ResourceRef) -> None:
        self._client.post(
            self._store_path("write"),
            {
                "authorization_model_id": self._config.authorization_model_id,
                "deletes": {
                    "tuple_keys": [
                        {
                            "user": object_string(parent),
                            "relation": "parent",
                            "object": object_string(child),
                        }
                    ]
                },
            },
        )

    def can(self, actor: ActorRef, action: Action, resource: ResourceRef) -> bool:
        response = self._client.post(
            self._store_path("check"),
            {
                "authorization_model_id": self._config.authorization_model_id,
                "tuple_key": {
                    "user": user_string(actor),
                    "relation": action_relation(action),
                    "object": object_string(resource),
                },
            },
        )
        return bool(response.get("allowed", False))

    def who_can(self, action: Action, resource: ResourceRef) -> list[ActorRef]:
        actors: list[ActorRef] = []
        for actor_type in ActorType:
            response = self._client.post(
                self._store_path("list-users"),
                {
                    "authorization_model_id": self._config.authorization_model_id,
                    "object": {
                        "type": resource.type.name.lower(),
                        "id": str(resource.id),
                    },
                    "user_filters": [{"type": actor_type.name.lower()}],
                    "relation": action_relation(action),
                },
            )
            for user in response.get("users", []):
                obj = user.get("object") or {}
                user_id = obj.get("id")
                if user_id:
                    actors.append(ActorRef(actor_type, str(user_id)))
        return actors

    def close(self) -> None:
        self._client.close()
