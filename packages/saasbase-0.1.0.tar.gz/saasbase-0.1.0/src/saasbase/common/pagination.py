from __future__ import annotations

from dataclasses import dataclass, replace
from enum import Enum
from typing import Generic, Sequence, TypeVar

T = TypeVar("T")


class SortDirection(str, Enum):
    ASC = "ASC"
    DESC = "DESC"


@dataclass(frozen=True, slots=True)
class PageRequest:
    page: int = 0
    size: int = 20
    sort_by: str | None = None
    direction: SortDirection = SortDirection.ASC

    def __post_init__(self) -> None:
        if self.page < 0:
            raise ValueError("page must be >= 0")
        if self.size <= 0:
            raise ValueError("size must be > 0")
        if self.size > 500:
            raise ValueError("size must be <= 500")

    @property
    def offset(self) -> int:
        return self.page * self.size

    @staticmethod
    def first_page() -> PageRequest:
        return PageRequest()

    @staticmethod
    def of(page: int, size: int) -> PageRequest:
        return PageRequest(page=page, size=size)

    def with_sort(self, sort_by: str, direction: SortDirection = SortDirection.ASC) -> PageRequest:
        return replace(self, sort_by=sort_by, direction=direction)


@dataclass(frozen=True, slots=True)
class Page(Generic[T]):
    items: Sequence[T]
    total_items: int
    page: int
    size: int
    total_pages: int

    @property
    def has_next(self) -> bool:
        return self.page + 1 < self.total_pages

    @property
    def has_previous(self) -> bool:
        return self.page > 0

    @staticmethod
    def of(items: Sequence[T], total_items: int, request: PageRequest) -> Page[T]:
        size = request.size if request.size > 0 else 1
        total_pages = int((total_items + size - 1) // size) if total_items > 0 else 0
        return Page(
            items=list(items),
            total_items=total_items,
            page=request.page,
            size=request.size,
            total_pages=total_pages,
        )
