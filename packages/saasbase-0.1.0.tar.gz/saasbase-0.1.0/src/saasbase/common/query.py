from __future__ import annotations

from dataclasses import dataclass, field, replace
from datetime import datetime
from typing import Any
from uuid import UUID

from saasbase.common.actor import ActorRef
from saasbase.common.audit import AuditAction
from saasbase.common.resource import ResourceType
from saasbase.common.status import ApiCallStatus, ExecutionStatus


@dataclass(frozen=True, slots=True)
class OrganizationQuery:
    slug_contains: str | None = None
    name_contains: str | None = None
    created_by_subject: str | None = None

    @staticmethod
    def all() -> OrganizationQuery:
        return OrganizationQuery()

    def with_slug_contains(self, value: str | None) -> OrganizationQuery:
        return replace(self, slug_contains=value)

    def with_name_contains(self, value: str | None) -> OrganizationQuery:
        return replace(self, name_contains=value)

    def with_created_by_subject(self, value: str | None) -> OrganizationQuery:
        return replace(self, created_by_subject=value)


@dataclass(frozen=True, slots=True)
class ProjectQuery:
    organization_id: UUID | None = None
    name_contains: str | None = None
    created_by_subject: str | None = None

    @staticmethod
    def all() -> ProjectQuery:
        return ProjectQuery()

    def with_organization_id(self, value: UUID | None) -> ProjectQuery:
        return replace(self, organization_id=value)

    def with_name_contains(self, value: str | None) -> ProjectQuery:
        return replace(self, name_contains=value)

    def with_created_by_subject(self, value: str | None) -> ProjectQuery:
        return replace(self, created_by_subject=value)


@dataclass(frozen=True, slots=True)
class DocumentQuery:
    organization_id: UUID | None = None
    project_id: UUID | None = None
    name_contains: str | None = None
    media_type: str | None = None
    created_by_subject: str | None = None

    @staticmethod
    def all() -> DocumentQuery:
        return DocumentQuery()

    def with_organization_id(self, value: UUID | None) -> DocumentQuery:
        return replace(self, organization_id=value)

    def with_project_id(self, value: UUID | None) -> DocumentQuery:
        return replace(self, project_id=value)

    def with_name_contains(self, value: str | None) -> DocumentQuery:
        return replace(self, name_contains=value)

    def with_media_type(self, value: str | None) -> DocumentQuery:
        return replace(self, media_type=value)

    def with_created_by_subject(self, value: str | None) -> DocumentQuery:
        return replace(self, created_by_subject=value)


@dataclass(frozen=True, slots=True)
class DocumentVersionQuery:
    organization_id: UUID | None = None
    project_id: UUID | None = None
    document_id: UUID | None = None
    name_contains: str | None = None
    version_name: str | None = None
    media_type: str | None = None
    created_by_subject: str | None = None
    metadata: dict[str, Any] = field(default_factory=dict)

    @staticmethod
    def all() -> DocumentVersionQuery:
        return DocumentVersionQuery()

    def with_organization_id(self, value: UUID | None) -> DocumentVersionQuery:
        return replace(self, organization_id=value)

    def with_project_id(self, value: UUID | None) -> DocumentVersionQuery:
        return replace(self, project_id=value)

    def with_document_id(self, value: UUID | None) -> DocumentVersionQuery:
        return replace(self, document_id=value)

    def with_name_contains(self, value: str | None) -> DocumentVersionQuery:
        return replace(self, name_contains=value)

    def with_version_name(self, value: str | None) -> DocumentVersionQuery:
        return replace(self, version_name=value)

    def with_media_type(self, value: str | None) -> DocumentVersionQuery:
        return replace(self, media_type=value)

    def with_created_by_subject(self, value: str | None) -> DocumentVersionQuery:
        return replace(self, created_by_subject=value)

    def with_metadata(self, key: str, value: Any) -> DocumentVersionQuery:
        merged = dict(self.metadata)
        merged[key] = value
        return replace(self, metadata=merged)


@dataclass(frozen=True, slots=True)
class ApiCallQuery:
    organization_id: UUID | None = None
    project_id: UUID | None = None
    status: ApiCallStatus | None = None
    operation_key: str | None = None
    external_request_id: str | None = None
    idempotency_key: str | None = None
    correlation_id: str | None = None
    created_by_subject: str | None = None

    @staticmethod
    def all() -> ApiCallQuery:
        return ApiCallQuery()

    def with_organization_id(self, value: UUID | None) -> ApiCallQuery:
        return replace(self, organization_id=value)

    def with_project_id(self, value: UUID | None) -> ApiCallQuery:
        return replace(self, project_id=value)

    def with_status(self, value: ApiCallStatus | None) -> ApiCallQuery:
        return replace(self, status=value)

    def with_operation_key(self, value: str | None) -> ApiCallQuery:
        return replace(self, operation_key=value)

    def with_external_request_id(self, value: str | None) -> ApiCallQuery:
        return replace(self, external_request_id=value)

    def with_idempotency_key(self, value: str | None) -> ApiCallQuery:
        return replace(self, idempotency_key=value)

    def with_correlation_id(self, value: str | None) -> ApiCallQuery:
        return replace(self, correlation_id=value)

    def with_created_by_subject(self, value: str | None) -> ApiCallQuery:
        return replace(self, created_by_subject=value)


@dataclass(frozen=True, slots=True)
class ExecutionQuery:
    organization_id: UUID | None = None
    project_id: UUID | None = None
    status: ExecutionStatus | None = None
    actor: ActorRef | None = None
    target_resource_type: ResourceType | None = None
    correlation_id: str | None = None
    parent_execution_id: UUID | None = None
    operation: str | None = None
    model_provider: str | None = None
    model_name: str | None = None

    @staticmethod
    def all() -> ExecutionQuery:
        return ExecutionQuery()

    def with_organization_id(self, value: UUID | None) -> ExecutionQuery:
        return replace(self, organization_id=value)

    def with_project_id(self, value: UUID | None) -> ExecutionQuery:
        return replace(self, project_id=value)

    def with_status(self, value: ExecutionStatus | None) -> ExecutionQuery:
        return replace(self, status=value)

    def with_actor(self, value: ActorRef | None) -> ExecutionQuery:
        return replace(self, actor=value)

    def with_target_resource_type(self, value: ResourceType | None) -> ExecutionQuery:
        return replace(self, target_resource_type=value)

    def with_correlation_id(self, value: str | None) -> ExecutionQuery:
        return replace(self, correlation_id=value)

    def with_parent_execution_id(self, value: UUID | None) -> ExecutionQuery:
        return replace(self, parent_execution_id=value)

    def with_operation(self, value: str | None) -> ExecutionQuery:
        return replace(self, operation=value)

    def with_model_provider(self, value: str | None) -> ExecutionQuery:
        return replace(self, model_provider=value)

    def with_model_name(self, value: str | None) -> ExecutionQuery:
        return replace(self, model_name=value)


@dataclass(frozen=True, slots=True)
class AuditQuery:
    organization_id: UUID | None = None
    project_id: UUID | None = None
    action: AuditAction | None = None
    actor: ActorRef | None = None
    resource_type: ResourceType | None = None
    correlation_id: str | None = None
    occurred_from: datetime | None = None
    occurred_to: datetime | None = None

    @staticmethod
    def all() -> AuditQuery:
        return AuditQuery()

    def with_organization_id(self, value: UUID | None) -> AuditQuery:
        return replace(self, organization_id=value)

    def with_project_id(self, value: UUID | None) -> AuditQuery:
        return replace(self, project_id=value)

    def with_action(self, value: AuditAction | None) -> AuditQuery:
        return replace(self, action=value)

    def with_actor(self, value: ActorRef | None) -> AuditQuery:
        return replace(self, actor=value)

    def with_resource_type(self, value: ResourceType | None) -> AuditQuery:
        return replace(self, resource_type=value)

    def with_correlation_id(self, value: str | None) -> AuditQuery:
        return replace(self, correlation_id=value)

    def with_occurred_from(self, value: datetime | None) -> AuditQuery:
        return replace(self, occurred_from=value)

    def with_occurred_to(self, value: datetime | None) -> AuditQuery:
        return replace(self, occurred_to=value)
