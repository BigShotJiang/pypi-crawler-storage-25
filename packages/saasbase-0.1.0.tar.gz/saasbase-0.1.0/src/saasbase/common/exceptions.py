from __future__ import annotations


class SaaSBaseError(Exception):
    """Base exception for all SaaSBase runtime errors."""


class PermissionDeniedError(SaaSBaseError):
    """Raised when an authorization check fails."""


class NotFoundError(SaaSBaseError):
    """Raised when a referenced entity does not exist."""


class ConflictError(SaaSBaseError):
    """Raised when an operation violates a uniqueness or idempotency constraint."""


class ValidationError(SaaSBaseError):
    """Raised when a request fails validation."""
