from __future__ import annotations

from enum import Enum
from types import MappingProxyType
from typing import Mapping


class Role(str, Enum):
    ORG_OWNER = "ORG_OWNER"
    ORG_ADMIN = "ORG_ADMIN"
    ORG_MEMBER = "ORG_MEMBER"
    PROJECT_OWNER = "PROJECT_OWNER"
    PROJECT_EDITOR = "PROJECT_EDITOR"
    PROJECT_VIEWER = "PROJECT_VIEWER"
    DOCUMENT_OWNER = "DOCUMENT_OWNER"
    DOCUMENT_EDITOR = "DOCUMENT_EDITOR"
    DOCUMENT_VIEWER = "DOCUMENT_VIEWER"
    API_CALL_OWNER = "API_CALL_OWNER"
    API_CALL_EDITOR = "API_CALL_EDITOR"
    API_CALL_VIEWER = "API_CALL_VIEWER"


class Action(str, Enum):
    ORGANIZATION_READ = "ORGANIZATION_READ"
    ORGANIZATION_UPDATE = "ORGANIZATION_UPDATE"
    ORGANIZATION_DELETE = "ORGANIZATION_DELETE"
    PROJECT_CREATE = "PROJECT_CREATE"
    PROJECT_READ = "PROJECT_READ"
    PROJECT_UPDATE = "PROJECT_UPDATE"
    PROJECT_DELETE = "PROJECT_DELETE"
    DOCUMENT_CREATE = "DOCUMENT_CREATE"
    DOCUMENT_READ = "DOCUMENT_READ"
    DOCUMENT_WRITE = "DOCUMENT_WRITE"
    DOCUMENT_DELETE = "DOCUMENT_DELETE"
    DOCUMENT_SHARE = "DOCUMENT_SHARE"
    API_CALL_CREATE = "API_CALL_CREATE"
    API_CALL_READ = "API_CALL_READ"
    API_CALL_WRITE = "API_CALL_WRITE"
    API_CALL_DELETE = "API_CALL_DELETE"
    API_CALL_SHARE = "API_CALL_SHARE"
    MEMBER_MANAGE = "MEMBER_MANAGE"
    METADATA_READ = "METADATA_READ"
    METADATA_WRITE = "METADATA_WRITE"
    EXECUTION_CREATE = "EXECUTION_CREATE"
    EXECUTION_READ = "EXECUTION_READ"


_ROLE_ACTIONS: Mapping[Role, frozenset[Action]] = MappingProxyType(
    {
        Role.ORG_OWNER: frozenset({
            Action.ORGANIZATION_READ, Action.ORGANIZATION_UPDATE, Action.ORGANIZATION_DELETE,
            Action.PROJECT_CREATE, Action.PROJECT_READ, Action.PROJECT_UPDATE, Action.PROJECT_DELETE,
            Action.DOCUMENT_CREATE, Action.DOCUMENT_READ, Action.DOCUMENT_WRITE, Action.DOCUMENT_DELETE, Action.DOCUMENT_SHARE,
            Action.API_CALL_CREATE, Action.API_CALL_READ, Action.API_CALL_WRITE, Action.API_CALL_DELETE, Action.API_CALL_SHARE,
            Action.EXECUTION_CREATE, Action.EXECUTION_READ,
            Action.MEMBER_MANAGE, Action.METADATA_READ, Action.METADATA_WRITE,
        }),
        Role.ORG_ADMIN: frozenset({
            Action.ORGANIZATION_READ, Action.ORGANIZATION_UPDATE,
            Action.PROJECT_CREATE, Action.PROJECT_READ, Action.PROJECT_UPDATE,
            Action.DOCUMENT_CREATE, Action.DOCUMENT_READ, Action.DOCUMENT_WRITE,
            Action.API_CALL_CREATE, Action.API_CALL_READ, Action.API_CALL_WRITE,
            Action.EXECUTION_CREATE, Action.EXECUTION_READ,
            Action.MEMBER_MANAGE, Action.METADATA_READ, Action.METADATA_WRITE,
        }),
        Role.ORG_MEMBER: frozenset({
            Action.ORGANIZATION_READ,
            Action.PROJECT_READ,
            Action.DOCUMENT_READ,
            Action.API_CALL_READ,
            Action.EXECUTION_READ,
            Action.METADATA_READ,
        }),
        Role.PROJECT_OWNER: frozenset({
            Action.PROJECT_READ, Action.PROJECT_UPDATE, Action.PROJECT_DELETE,
            Action.DOCUMENT_CREATE, Action.DOCUMENT_READ, Action.DOCUMENT_WRITE, Action.DOCUMENT_DELETE, Action.DOCUMENT_SHARE,
            Action.API_CALL_CREATE, Action.API_CALL_READ, Action.API_CALL_WRITE, Action.API_CALL_DELETE, Action.API_CALL_SHARE,
            Action.EXECUTION_CREATE, Action.EXECUTION_READ,
            Action.MEMBER_MANAGE, Action.METADATA_READ, Action.METADATA_WRITE,
        }),
        Role.PROJECT_EDITOR: frozenset({
            Action.PROJECT_READ, Action.PROJECT_UPDATE,
            Action.DOCUMENT_CREATE, Action.DOCUMENT_READ, Action.DOCUMENT_WRITE,
            Action.API_CALL_CREATE, Action.API_CALL_READ, Action.API_CALL_WRITE,
            Action.EXECUTION_CREATE, Action.EXECUTION_READ,
            Action.METADATA_READ, Action.METADATA_WRITE,
        }),
        Role.PROJECT_VIEWER: frozenset({
            Action.PROJECT_READ,
            Action.DOCUMENT_READ,
            Action.API_CALL_READ,
            Action.EXECUTION_READ,
            Action.METADATA_READ,
        }),
        Role.DOCUMENT_OWNER: frozenset({
            Action.DOCUMENT_READ, Action.DOCUMENT_WRITE, Action.DOCUMENT_DELETE, Action.DOCUMENT_SHARE,
            Action.METADATA_READ, Action.METADATA_WRITE,
        }),
        Role.DOCUMENT_EDITOR: frozenset({
            Action.DOCUMENT_READ, Action.DOCUMENT_WRITE,
            Action.METADATA_READ, Action.METADATA_WRITE,
        }),
        Role.DOCUMENT_VIEWER: frozenset({
            Action.DOCUMENT_READ,
            Action.METADATA_READ,
        }),
        Role.API_CALL_OWNER: frozenset({
            Action.API_CALL_READ, Action.API_CALL_WRITE, Action.API_CALL_DELETE, Action.API_CALL_SHARE,
            Action.METADATA_READ, Action.METADATA_WRITE,
        }),
        Role.API_CALL_EDITOR: frozenset({
            Action.API_CALL_READ, Action.API_CALL_WRITE,
            Action.METADATA_READ, Action.METADATA_WRITE,
        }),
        Role.API_CALL_VIEWER: frozenset({
            Action.API_CALL_READ,
            Action.METADATA_READ,
        }),
    }
)


class AuthorizationPolicy:
    """Default role-to-action permission matrix. Mirrors the Java AuthorizationPolicy 1:1."""

    @staticmethod
    def allows(role: Role | None, action: Action | None) -> bool:
        if role is None or action is None:
            return False
        return action in _ROLE_ACTIONS.get(role, frozenset())

    @staticmethod
    def actions(role: Role) -> frozenset[Action]:
        return _ROLE_ACTIONS.get(role, frozenset())

    @staticmethod
    def roles(action: Action | None) -> frozenset[Role]:
        if action is None:
            return frozenset()
        return frozenset(role for role, actions in _ROLE_ACTIONS.items() if action in actions)

    @staticmethod
    def permissions() -> Mapping[Role, frozenset[Action]]:
        return _ROLE_ACTIONS
