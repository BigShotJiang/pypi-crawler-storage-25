from __future__ import annotations

from dataclasses import dataclass
from enum import Enum


class ActorType(str, Enum):
    USER = "USER"
    SERVICE = "SERVICE"
    AGENT = "AGENT"
    GROUP = "GROUP"
    API_KEY = "API_KEY"


@dataclass(frozen=True, slots=True)
class ActorRef:
    type: ActorType
    id: str

    def __post_init__(self) -> None:
        if not isinstance(self.type, ActorType):
            raise TypeError("type must be an ActorType")
        if not self.id or not self.id.strip():
            raise ValueError("id must not be blank")

    def subject(self) -> str:
        return f"{self.type.name.lower()}:{self.id}"

    @staticmethod
    def user(id: str) -> ActorRef:
        return ActorRef(ActorType.USER, id)

    @staticmethod
    def service(id: str) -> ActorRef:
        return ActorRef(ActorType.SERVICE, id)

    @staticmethod
    def agent(id: str) -> ActorRef:
        return ActorRef(ActorType.AGENT, id)

    @staticmethod
    def group(id: str) -> ActorRef:
        return ActorRef(ActorType.GROUP, id)

    @staticmethod
    def api_key(id: str) -> ActorRef:
        return ActorRef(ActorType.API_KEY, id)
