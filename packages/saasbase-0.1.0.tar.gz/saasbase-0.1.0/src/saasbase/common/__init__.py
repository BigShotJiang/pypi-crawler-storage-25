"""Shared primitives used across the SaaSBase SDK — enums, value objects, pagination, queries, and exceptions."""

from saasbase.common.actor import ActorRef, ActorType
from saasbase.common.audit import AuditAction
from saasbase.common.authz import Action, AuthorizationPolicy, Role
from saasbase.common.exceptions import (
    ConflictError,
    NotFoundError,
    PermissionDeniedError,
    SaaSBaseError,
    ValidationError,
)
from saasbase.common.pagination import Page, PageRequest, SortDirection
from saasbase.common.query import (
    ApiCallQuery,
    AuditQuery,
    DocumentQuery,
    DocumentVersionQuery,
    ExecutionQuery,
    OrganizationQuery,
    ProjectQuery,
)
from saasbase.common.resource import ResourceRef, ResourceType
from saasbase.common.status import ApiCallStatus, ExecutionStatus

__all__ = [
    "Action",
    "ActorRef",
    "ActorType",
    "ApiCallQuery",
    "ApiCallStatus",
    "AuditAction",
    "AuditQuery",
    "AuthorizationPolicy",
    "ConflictError",
    "DocumentQuery",
    "DocumentVersionQuery",
    "ExecutionQuery",
    "ExecutionStatus",
    "NotFoundError",
    "OrganizationQuery",
    "Page",
    "PageRequest",
    "PermissionDeniedError",
    "ProjectQuery",
    "ResourceRef",
    "ResourceType",
    "Role",
    "SaaSBaseError",
    "SortDirection",
    "ValidationError",
]
