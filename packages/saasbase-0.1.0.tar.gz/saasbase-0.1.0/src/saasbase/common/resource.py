from __future__ import annotations

from dataclasses import dataclass
from enum import Enum
from uuid import UUID


class ResourceType(str, Enum):
    ORGANIZATION = "ORGANIZATION"
    PROJECT = "PROJECT"
    DOCUMENT = "DOCUMENT"
    API_CALL = "API_CALL"


@dataclass(frozen=True, slots=True)
class ResourceRef:
    type: ResourceType
    id: UUID

    def __post_init__(self) -> None:
        if not isinstance(self.type, ResourceType):
            raise TypeError("type must be a ResourceType")
        if not isinstance(self.id, UUID):
            raise TypeError("id must be a UUID")

    def subject(self) -> str:
        return f"{self.type.name.lower()}:{self.id}"

    @staticmethod
    def organization(id: UUID) -> ResourceRef:
        return ResourceRef(ResourceType.ORGANIZATION, id)

    @staticmethod
    def project(id: UUID) -> ResourceRef:
        return ResourceRef(ResourceType.PROJECT, id)

    @staticmethod
    def document(id: UUID) -> ResourceRef:
        return ResourceRef(ResourceType.DOCUMENT, id)

    @staticmethod
    def api_call(id: UUID) -> ResourceRef:
        return ResourceRef(ResourceType.API_CALL, id)
