from __future__ import annotations

from typing import Callable, TypeVar

from saasbase.persistence.connection import ThreadLocalConnectionProvider

T = TypeVar("T")


class DbApiTransactionManager:
    """TransactionManager implementation that delegates to ThreadLocalConnectionProvider."""

    def __init__(self, provider: ThreadLocalConnectionProvider) -> None:
        self._provider = provider

    def required(self, action: Callable[[], T]) -> T:
        with self._provider.transactional_scope():
            return action()
