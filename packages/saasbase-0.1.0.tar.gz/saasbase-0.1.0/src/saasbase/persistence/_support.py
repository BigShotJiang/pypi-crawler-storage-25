"""Internal helpers for SQL repositories — pagination, filter assembly, row iteration."""

from __future__ import annotations

from typing import Any, Callable, Sequence

from saasbase.common.pagination import Page, PageRequest, SortDirection
from saasbase.persistence.connection import ConnectionProvider
from saasbase.persistence.dialect import Dialect


def fetch_all(
    provider: ConnectionProvider, dialect: Dialect, sql: str, params: Sequence[Any]
) -> list[tuple]:
    with provider.connection() as conn:
        cur = conn.cursor()
        try:
            cur.execute(dialect.sql(sql), list(params))
            return list(cur.fetchall())
        finally:
            cur.close()


def fetch_one(
    provider: ConnectionProvider, dialect: Dialect, sql: str, params: Sequence[Any]
) -> tuple | None:
    with provider.connection() as conn:
        cur = conn.cursor()
        try:
            cur.execute(dialect.sql(sql), list(params))
            return cur.fetchone()
        finally:
            cur.close()


def execute(
    provider: ConnectionProvider, dialect: Dialect, sql: str, params: Sequence[Any]
) -> int:
    with provider.connection() as conn:
        cur = conn.cursor()
        try:
            cur.execute(dialect.sql(sql), list(params))
            return cur.rowcount if cur.rowcount is not None else 0
        finally:
            cur.close()


def count_scalar(
    provider: ConnectionProvider, dialect: Dialect, sql: str, params: Sequence[Any]
) -> int:
    row = fetch_one(provider, dialect, sql, params)
    if row is None:
        return 0
    return int(row[0] or 0)


def order_by_clause(
    page_request: PageRequest, allowed_columns: dict[str, str], default: str
) -> str:
    key = (page_request.sort_by or "").lower()
    column = allowed_columns.get(key, default)
    direction = "DESC" if page_request.direction == SortDirection.DESC else "ASC"
    return f"ORDER BY {column} {direction}"


def query_page(
    provider: ConnectionProvider,
    dialect: Dialect,
    *,
    select_sql: str,
    count_sql: str,
    where_clauses: list[str],
    params: list[Any],
    page_request: PageRequest,
    sort_columns: dict[str, str],
    default_sort: str,
    mapper: Callable[[tuple], Any],
) -> Page[Any]:
    where_sql = f"WHERE {' AND '.join(where_clauses)}" if where_clauses else ""
    order_sql = order_by_clause(page_request, sort_columns, default_sort)
    final_sql = f"{select_sql} {where_sql} {order_sql} LIMIT ? OFFSET ?".strip()
    final_params = [*params, page_request.size, page_request.offset]

    count_full_sql = f"{count_sql} {where_sql}".strip()
    total_items = count_scalar(provider, dialect, count_full_sql, params)

    rows = fetch_all(provider, dialect, final_sql, final_params)
    items = [mapper(row) for row in rows]
    return Page.of(items, total_items, page_request)
