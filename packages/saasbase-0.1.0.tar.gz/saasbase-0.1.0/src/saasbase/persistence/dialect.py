from __future__ import annotations

import json
from abc import ABC, abstractmethod
from datetime import datetime, timezone
from typing import Any
from uuid import UUID


def instant_to_iso(value: datetime | None) -> str | None:
    if value is None:
        return None
    if value.tzinfo is None:
        value = value.replace(tzinfo=timezone.utc)
    return value.astimezone(timezone.utc).isoformat().replace("+00:00", "Z")


def iso_to_instant(value: str | None) -> datetime | None:
    if value is None:
        return None
    text = value.strip()
    if not text:
        return None
    if text.endswith("Z"):
        text = text[:-1] + "+00:00"
    return datetime.fromisoformat(text)


def uuid_to_text(value: UUID | None) -> str | None:
    return str(value) if value is not None else None


def text_to_uuid(value: Any) -> UUID | None:
    if value is None:
        return None
    if isinstance(value, UUID):
        return value
    return UUID(str(value))


class Dialect(ABC):
    """Abstracts parameter style and JSON handling differences between backends."""

    paramstyle: str

    @abstractmethod
    def sql(self, sql: str) -> str:
        """Rewrite `?` placeholders for the native driver if needed."""

    @abstractmethod
    def json_param(self, value: Any) -> Any:
        """Convert a dict/list to the driver's preferred JSON parameter form."""

    @abstractmethod
    def json_result(self, value: Any) -> dict[str, Any]:
        """Convert a JSON column's raw value back into a Python dict."""

    def json_list_result(self, value: Any) -> list[Any]:
        if value is None:
            return []
        if isinstance(value, (list, tuple)):
            return list(value)
        if isinstance(value, str):
            if not value:
                return []
            return json.loads(value)
        return []


class SQLiteDialect(Dialect):
    paramstyle = "qmark"

    def sql(self, sql: str) -> str:
        return sql

    def json_param(self, value: Any) -> Any:
        if value is None:
            return None
        return json.dumps(value)

    def json_result(self, value: Any) -> dict[str, Any]:
        if value is None:
            return {}
        if isinstance(value, dict):
            return dict(value)
        if isinstance(value, str):
            if not value:
                return {}
            return json.loads(value)
        raise ValueError(f"Unsupported JSON column value: {type(value).__name__}")


class PostgresDialect(Dialect):
    paramstyle = "pyformat"

    def sql(self, sql: str) -> str:
        # psycopg uses %s for positional parameters
        out: list[str] = []
        i = 0
        in_single = False
        in_double = False
        while i < len(sql):
            ch = sql[i]
            if ch == "'" and not in_double:
                in_single = not in_single
                out.append(ch)
            elif ch == '"' and not in_single:
                in_double = not in_double
                out.append(ch)
            elif ch == "?" and not in_single and not in_double:
                out.append("%s")
            elif ch == "%" and not in_single and not in_double:
                out.append("%%")
            else:
                out.append(ch)
            i += 1
        return "".join(out)

    def json_param(self, value: Any) -> Any:
        if value is None:
            return None
        try:
            from psycopg.types.json import Jsonb  # type: ignore
        except ImportError:  # pragma: no cover
            return json.dumps(value)
        return Jsonb(value)

    def json_result(self, value: Any) -> dict[str, Any]:
        if value is None:
            return {}
        if isinstance(value, dict):
            return dict(value)
        if isinstance(value, str):
            if not value:
                return {}
            return json.loads(value)
        raise ValueError(f"Unsupported JSON column value: {type(value).__name__}")
