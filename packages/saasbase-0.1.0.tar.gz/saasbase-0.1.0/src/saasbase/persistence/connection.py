from __future__ import annotations

import threading
from contextlib import contextmanager
from typing import Any, Callable, Iterator, Protocol


class ConnectionProvider(Protocol):
    """Yields a DB-API connection for the current transaction scope. Caller must not close it."""

    @contextmanager
    def connection(self) -> Iterator[Any]: ...


class ThreadLocalConnectionProvider:
    """Per-thread connection that is reused across nested operations inside a transaction.

    Connections are created on demand via the supplied factory and cached in thread-local state
    so that nested calls (e.g. a repository call from within a transaction block) share the same
    connection.
    """

    def __init__(
        self,
        factory: Callable[[], Any],
        auto_commit: bool = True,
    ) -> None:
        self._factory = factory
        self._auto_commit = auto_commit
        self._state = threading.local()

    @contextmanager
    def connection(self) -> Iterator[Any]:
        conn = getattr(self._state, "conn", None)
        owns_transaction = getattr(self._state, "owns_transaction", False)
        created_here = False
        if conn is None:
            conn = self._factory()
            self._state.conn = conn
            self._state.owns_transaction = False
            created_here = True
        try:
            yield conn
            if created_here and self._auto_commit and not owns_transaction:
                conn.commit()
        except Exception:
            if created_here and not owns_transaction:
                try:
                    conn.rollback()
                except Exception:
                    pass
            raise
        finally:
            if created_here:
                try:
                    conn.close()
                finally:
                    self._state.conn = None

    # --- transactional scope hooks used by DbApiTransactionManager ---

    @contextmanager
    def transactional_scope(self) -> Iterator[Any]:
        existing = getattr(self._state, "conn", None)
        if existing is not None:
            # Nested transaction — participate in the outer one.
            yield existing
            return

        conn = self._factory()
        self._state.conn = conn
        self._state.owns_transaction = True
        try:
            yield conn
            conn.commit()
        except Exception:
            try:
                conn.rollback()
            except Exception:
                pass
            raise
        finally:
            try:
                conn.close()
            finally:
                self._state.conn = None
                self._state.owns_transaction = False

    def close_idle(self) -> None:
        conn = getattr(self._state, "conn", None)
        if conn is not None:
            try:
                conn.close()
            finally:
                self._state.conn = None
                self._state.owns_transaction = False
