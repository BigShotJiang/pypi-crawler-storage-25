from __future__ import annotations

from typing import Any
from uuid import UUID

from saasbase.common.actor import ActorRef, ActorType
from saasbase.common.pagination import Page, PageRequest
from saasbase.common.query import ExecutionQuery
from saasbase.common.resource import ResourceRef, ResourceType
from saasbase.common.status import ExecutionStatus
from saasbase.persistence._support import execute, fetch_all, fetch_one, query_page
from saasbase.persistence.connection import ConnectionProvider
from saasbase.persistence.dialect import (
    Dialect,
    instant_to_iso,
    iso_to_instant,
    text_to_uuid,
    uuid_to_text,
)
from saasbase.spi.persistence import ExecutionRecord

_COLS = (
    "id, organization_id, project_id, operation, status, actor_type, actor_id, "
    "target_resource_type, target_resource_id, correlation_id, parent_execution_id, "
    "agent_version, model_provider, model_name, confidence, warnings_json, provenance_json, "
    "started_at, ended_at, input_json, output_json, metadata_json"
)
_SELECT = f"SELECT {_COLS} FROM executions"
_COUNT = "SELECT COUNT(*) FROM executions"

_SORT_COLUMNS = {
    "started_at": "started_at",
    "ended_at": "ended_at",
    "operation": "operation",
    "status": "status",
}


class ExecutionSqlRepository:
    def __init__(self, provider: ConnectionProvider, dialect: Dialect) -> None:
        self._provider = provider
        self._dialect = dialect

    def _map(self, row: tuple) -> ExecutionRecord:
        target: ResourceRef | None = None
        if row[7] and row[8]:
            target = ResourceRef(ResourceType(row[7]), text_to_uuid(row[8]))  # type: ignore[arg-type]
        warnings_raw = self._dialect.json_list_result(row[15])
        warnings = [str(w) for w in warnings_raw]
        return ExecutionRecord(
            id=text_to_uuid(row[0]),  # type: ignore[arg-type]
            organization_id=text_to_uuid(row[1]),  # type: ignore[arg-type]
            project_id=text_to_uuid(row[2]),  # type: ignore[arg-type]
            operation=row[3],
            status=ExecutionStatus(row[4]),
            actor=ActorRef(ActorType(row[5]), row[6]),
            target=target,
            correlation_id=row[9],
            parent_execution_id=text_to_uuid(row[10]),
            agent_version=row[11],
            model_provider=row[12],
            model_name=row[13],
            confidence=float(row[14]) if row[14] is not None else None,
            warnings=warnings,
            provenance=self._dialect.json_result(row[16]),
            started_at=iso_to_instant(row[17]),
            ended_at=iso_to_instant(row[18]),
            input=self._dialect.json_result(row[19]),
            output=self._dialect.json_result(row[20]),
            metadata=self._dialect.json_result(row[21]),
        )

    def create(self, record: ExecutionRecord) -> ExecutionRecord:
        sql = (
            f"INSERT INTO executions ({_COLS}) "
            "VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)"
        )
        execute(
            self._provider,
            self._dialect,
            sql,
            [
                uuid_to_text(record.id),
                uuid_to_text(record.organization_id),
                uuid_to_text(record.project_id),
                record.operation,
                record.status.value,
                record.actor.type.value,
                record.actor.id,
                record.target.type.value if record.target else None,
                uuid_to_text(record.target.id) if record.target else None,
                record.correlation_id,
                uuid_to_text(record.parent_execution_id),
                record.agent_version,
                record.model_provider,
                record.model_name,
                record.confidence,
                self._dialect.json_param(record.warnings),
                self._dialect.json_param(record.provenance),
                instant_to_iso(record.started_at),
                instant_to_iso(record.ended_at),
                self._dialect.json_param(record.input),
                self._dialect.json_param(record.output),
                self._dialect.json_param(record.metadata),
            ],
        )
        return record

    def find_by_id(self, id: UUID) -> ExecutionRecord | None:
        row = fetch_one(
            self._provider, self._dialect, f"{_SELECT} WHERE id = ?", [uuid_to_text(id)]
        )
        return self._map(row) if row else None

    def list_by_project(self, project_id: UUID) -> list[ExecutionRecord]:
        rows = fetch_all(
            self._provider,
            self._dialect,
            f"{_SELECT} WHERE project_id = ? ORDER BY started_at ASC",
            [uuid_to_text(project_id)],
        )
        return [self._map(r) for r in rows]

    def list_by_correlation_id(self, correlation_id: str) -> list[ExecutionRecord]:
        rows = fetch_all(
            self._provider,
            self._dialect,
            f"{_SELECT} WHERE correlation_id = ? ORDER BY started_at ASC",
            [correlation_id],
        )
        return [self._map(r) for r in rows]

    def list_children(self, parent_execution_id: UUID) -> list[ExecutionRecord]:
        rows = fetch_all(
            self._provider,
            self._dialect,
            f"{_SELECT} WHERE parent_execution_id = ? ORDER BY started_at ASC",
            [uuid_to_text(parent_execution_id)],
        )
        return [self._map(r) for r in rows]

    def query(self, query: ExecutionQuery, page_request: PageRequest) -> Page[ExecutionRecord]:
        clauses: list[str] = []
        params: list[Any] = []
        if query.organization_id is not None:
            clauses.append("organization_id = ?")
            params.append(uuid_to_text(query.organization_id))
        if query.project_id is not None:
            clauses.append("project_id = ?")
            params.append(uuid_to_text(query.project_id))
        if query.status is not None:
            clauses.append("status = ?")
            params.append(query.status.value)
        if query.actor is not None:
            clauses.append("actor_type = ? AND actor_id = ?")
            params.append(query.actor.type.value)
            params.append(query.actor.id)
        if query.target_resource_type is not None:
            clauses.append("target_resource_type = ?")
            params.append(query.target_resource_type.value)
        if query.correlation_id:
            clauses.append("correlation_id = ?")
            params.append(query.correlation_id)
        if query.parent_execution_id is not None:
            clauses.append("parent_execution_id = ?")
            params.append(uuid_to_text(query.parent_execution_id))
        if query.operation:
            clauses.append("operation = ?")
            params.append(query.operation)
        if query.model_provider:
            clauses.append("model_provider = ?")
            params.append(query.model_provider)
        if query.model_name:
            clauses.append("model_name = ?")
            params.append(query.model_name)
        return query_page(
            self._provider,
            self._dialect,
            select_sql=_SELECT,
            count_sql=_COUNT,
            where_clauses=clauses,
            params=params,
            page_request=page_request,
            sort_columns=_SORT_COLUMNS,
            default_sort="started_at",
            mapper=self._map,
        )

    def update(self, record: ExecutionRecord) -> ExecutionRecord:
        sql = (
            "UPDATE executions SET status = ?, confidence = ?, warnings_json = ?, "
            "provenance_json = ?, ended_at = ?, output_json = ?, metadata_json = ? WHERE id = ?"
        )
        execute(
            self._provider,
            self._dialect,
            sql,
            [
                record.status.value,
                record.confidence,
                self._dialect.json_param(record.warnings),
                self._dialect.json_param(record.provenance),
                instant_to_iso(record.ended_at),
                self._dialect.json_param(record.output),
                self._dialect.json_param(record.metadata),
                uuid_to_text(record.id),
            ],
        )
        return record
