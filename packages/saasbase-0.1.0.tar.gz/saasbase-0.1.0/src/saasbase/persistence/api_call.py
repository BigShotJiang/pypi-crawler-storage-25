from __future__ import annotations

from typing import Any
from uuid import UUID

from saasbase.common.pagination import Page, PageRequest
from saasbase.common.query import ApiCallQuery
from saasbase.common.status import ApiCallStatus
from saasbase.persistence._support import execute, fetch_all, fetch_one, query_page
from saasbase.persistence.connection import ConnectionProvider
from saasbase.persistence.dialect import (
    Dialect,
    instant_to_iso,
    iso_to_instant,
    text_to_uuid,
    uuid_to_text,
)
from saasbase.spi.persistence import ApiCallRecord

_COLS = (
    "id, organization_id, project_id, name, operation_key, external_request_id, idempotency_key, "
    "correlation_id, status, requested_at, responded_at, request_payload_json, "
    "response_payload_json, metadata_json, created_at, updated_at, created_by_subject"
)
_SELECT = f"SELECT {_COLS} FROM api_calls"
_COUNT = "SELECT COUNT(*) FROM api_calls"

_SORT_COLUMNS = {
    "name": "name",
    "requested_at": "requested_at",
    "responded_at": "responded_at",
    "created_at": "created_at",
    "updated_at": "updated_at",
    "status": "status",
    "operation_key": "operation_key",
}


class ApiCallSqlRepository:
    def __init__(self, provider: ConnectionProvider, dialect: Dialect) -> None:
        self._provider = provider
        self._dialect = dialect

    def _map(self, row: tuple) -> ApiCallRecord:
        return ApiCallRecord(
            id=text_to_uuid(row[0]),  # type: ignore[arg-type]
            organization_id=text_to_uuid(row[1]),  # type: ignore[arg-type]
            project_id=text_to_uuid(row[2]),  # type: ignore[arg-type]
            name=row[3],
            operation_key=row[4],
            external_request_id=row[5],
            idempotency_key=row[6],
            correlation_id=row[7],
            status=ApiCallStatus(row[8]),
            requested_at=iso_to_instant(row[9]),  # type: ignore[arg-type]
            responded_at=iso_to_instant(row[10]),
            request_payload=self._dialect.json_result(row[11]),
            response_payload=self._dialect.json_result(row[12]),
            metadata=self._dialect.json_result(row[13]),
            created_at=iso_to_instant(row[14]),  # type: ignore[arg-type]
            updated_at=iso_to_instant(row[15]),  # type: ignore[arg-type]
            created_by_subject=row[16],
        )

    def create(self, record: ApiCallRecord) -> ApiCallRecord:
        sql = (
            f"INSERT INTO api_calls ({_COLS}) "
            "VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)"
        )
        execute(
            self._provider,
            self._dialect,
            sql,
            [
                uuid_to_text(record.id),
                uuid_to_text(record.organization_id),
                uuid_to_text(record.project_id),
                record.name,
                record.operation_key,
                record.external_request_id,
                record.idempotency_key,
                record.correlation_id,
                record.status.value,
                instant_to_iso(record.requested_at),
                instant_to_iso(record.responded_at),
                self._dialect.json_param(record.request_payload),
                self._dialect.json_param(record.response_payload),
                self._dialect.json_param(record.metadata),
                instant_to_iso(record.created_at),
                instant_to_iso(record.updated_at),
                record.created_by_subject,
            ],
        )
        return record

    def find_by_id(self, id: UUID) -> ApiCallRecord | None:
        row = fetch_one(
            self._provider, self._dialect, f"{_SELECT} WHERE id = ?", [uuid_to_text(id)]
        )
        return self._map(row) if row else None

    def list_by_project(self, project_id: UUID) -> list[ApiCallRecord]:
        rows = fetch_all(
            self._provider,
            self._dialect,
            f"{_SELECT} WHERE project_id = ? ORDER BY requested_at ASC",
            [uuid_to_text(project_id)],
        )
        return [self._map(r) for r in rows]

    def list_by_correlation_id(self, correlation_id: str) -> list[ApiCallRecord]:
        rows = fetch_all(
            self._provider,
            self._dialect,
            f"{_SELECT} WHERE correlation_id = ? ORDER BY requested_at ASC",
            [correlation_id],
        )
        return [self._map(r) for r in rows]

    def query(self, query: ApiCallQuery, page_request: PageRequest) -> Page[ApiCallRecord]:
        clauses: list[str] = []
        params: list[Any] = []
        if query.organization_id is not None:
            clauses.append("organization_id = ?")
            params.append(uuid_to_text(query.organization_id))
        if query.project_id is not None:
            clauses.append("project_id = ?")
            params.append(uuid_to_text(query.project_id))
        if query.status is not None:
            clauses.append("status = ?")
            params.append(query.status.value)
        if query.operation_key:
            clauses.append("operation_key = ?")
            params.append(query.operation_key)
        if query.external_request_id:
            clauses.append("external_request_id = ?")
            params.append(query.external_request_id)
        if query.idempotency_key:
            clauses.append("idempotency_key = ?")
            params.append(query.idempotency_key)
        if query.correlation_id:
            clauses.append("correlation_id = ?")
            params.append(query.correlation_id)
        if query.created_by_subject:
            clauses.append("created_by_subject = ?")
            params.append(query.created_by_subject)
        return query_page(
            self._provider,
            self._dialect,
            select_sql=_SELECT,
            count_sql=_COUNT,
            where_clauses=clauses,
            params=params,
            page_request=page_request,
            sort_columns=_SORT_COLUMNS,
            default_sort="requested_at",
            mapper=self._map,
        )

    def update(self, record: ApiCallRecord) -> ApiCallRecord:
        sql = (
            "UPDATE api_calls SET name = ?, operation_key = ?, external_request_id = ?, "
            "idempotency_key = ?, correlation_id = ?, status = ?, requested_at = ?, "
            "responded_at = ?, request_payload_json = ?, response_payload_json = ?, "
            "metadata_json = ?, updated_at = ? WHERE id = ?"
        )
        execute(
            self._provider,
            self._dialect,
            sql,
            [
                record.name,
                record.operation_key,
                record.external_request_id,
                record.idempotency_key,
                record.correlation_id,
                record.status.value,
                instant_to_iso(record.requested_at),
                instant_to_iso(record.responded_at),
                self._dialect.json_param(record.request_payload),
                self._dialect.json_param(record.response_payload),
                self._dialect.json_param(record.metadata),
                instant_to_iso(record.updated_at),
                uuid_to_text(record.id),
            ],
        )
        return record

    def delete(self, id: UUID) -> None:
        execute(
            self._provider, self._dialect, "DELETE FROM api_calls WHERE id = ?", [uuid_to_text(id)]
        )
