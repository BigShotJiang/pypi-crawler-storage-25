from __future__ import annotations

from typing import Any

from saasbase.common.actor import ActorRef, ActorType
from saasbase.common.audit import AuditAction
from saasbase.common.pagination import Page, PageRequest
from saasbase.common.query import AuditQuery
from saasbase.common.resource import ResourceRef, ResourceType
from saasbase.persistence._support import execute, fetch_all, query_page
from saasbase.persistence.connection import ConnectionProvider
from saasbase.persistence.dialect import (
    Dialect,
    instant_to_iso,
    iso_to_instant,
    text_to_uuid,
    uuid_to_text,
)
from saasbase.spi.audit import AuditEventRecord

_COLS = (
    "id, occurred_at, actor_type, actor_id, action, resource_type, resource_id, "
    "organization_id, project_id, correlation_id, details_json"
)
_SELECT = f"SELECT {_COLS} FROM audit_events"
_COUNT = "SELECT COUNT(*) FROM audit_events"

_SORT_COLUMNS = {
    "occurred_at": "occurred_at",
    "action": "action",
}


class AuditEventSqlSink:
    def __init__(self, provider: ConnectionProvider, dialect: Dialect) -> None:
        self._provider = provider
        self._dialect = dialect

    def _map(self, row: tuple) -> AuditEventRecord:
        return AuditEventRecord(
            id=text_to_uuid(row[0]),  # type: ignore[arg-type]
            occurred_at=iso_to_instant(row[1]),  # type: ignore[arg-type]
            actor=ActorRef(ActorType(row[2]), row[3]),
            action=AuditAction(row[4]),
            resource=ResourceRef(ResourceType(row[5]), text_to_uuid(row[6])),  # type: ignore[arg-type]
            organization_id=text_to_uuid(row[7]),
            project_id=text_to_uuid(row[8]),
            correlation_id=row[9],
            details=self._dialect.json_result(row[10]),
        )

    def record(self, event: AuditEventRecord) -> None:
        sql = f"INSERT INTO audit_events ({_COLS}) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)"
        execute(
            self._provider,
            self._dialect,
            sql,
            [
                uuid_to_text(event.id),
                instant_to_iso(event.occurred_at),
                event.actor.type.value,
                event.actor.id,
                event.action.value,
                event.resource.type.value,
                uuid_to_text(event.resource.id),
                uuid_to_text(event.organization_id),
                uuid_to_text(event.project_id),
                event.correlation_id,
                self._dialect.json_param(event.details),
            ],
        )

    def list(self, resource: ResourceRef) -> list[AuditEventRecord]:
        rows = fetch_all(
            self._provider,
            self._dialect,
            f"{_SELECT} WHERE resource_type = ? AND resource_id = ? ORDER BY occurred_at ASC",
            [resource.type.value, uuid_to_text(resource.id)],
        )
        return [self._map(r) for r in rows]

    def list_by_correlation_id(self, correlation_id: str) -> list[AuditEventRecord]:
        rows = fetch_all(
            self._provider,
            self._dialect,
            f"{_SELECT} WHERE correlation_id = ? ORDER BY occurred_at ASC",
            [correlation_id],
        )
        return [self._map(r) for r in rows]

    def _build_filter(self, query: AuditQuery) -> tuple[list[str], list[Any]]:
        clauses: list[str] = []
        params: list[Any] = []
        if query.organization_id is not None:
            clauses.append("organization_id = ?")
            params.append(uuid_to_text(query.organization_id))
        if query.project_id is not None:
            clauses.append("project_id = ?")
            params.append(uuid_to_text(query.project_id))
        if query.action is not None:
            clauses.append("action = ?")
            params.append(query.action.value)
        if query.actor is not None:
            clauses.append("actor_type = ? AND actor_id = ?")
            params.append(query.actor.type.value)
            params.append(query.actor.id)
        if query.resource_type is not None:
            clauses.append("resource_type = ?")
            params.append(query.resource_type.value)
        if query.correlation_id:
            clauses.append("correlation_id = ?")
            params.append(query.correlation_id)
        if query.occurred_from is not None:
            clauses.append("occurred_at >= ?")
            params.append(instant_to_iso(query.occurred_from))
        if query.occurred_to is not None:
            clauses.append("occurred_at <= ?")
            params.append(instant_to_iso(query.occurred_to))
        return clauses, params

    def query(self, query: AuditQuery, page_request: PageRequest) -> Page[AuditEventRecord]:
        clauses, params = self._build_filter(query)
        return query_page(
            self._provider,
            self._dialect,
            select_sql=_SELECT,
            count_sql=_COUNT,
            where_clauses=clauses,
            params=params,
            page_request=page_request,
            sort_columns=_SORT_COLUMNS,
            default_sort="occurred_at",
            mapper=self._map,
        )

    def prune(self, query: AuditQuery) -> int:
        clauses, params = self._build_filter(query)
        where_sql = f"WHERE {' AND '.join(clauses)}" if clauses else ""
        return execute(
            self._provider, self._dialect, f"DELETE FROM audit_events {where_sql}".strip(), params
        )
