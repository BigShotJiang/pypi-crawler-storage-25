from __future__ import annotations

from typing import Any
from uuid import UUID

from saasbase.common.pagination import Page, PageRequest
from saasbase.common.query import DocumentVersionQuery
from saasbase.persistence._support import execute, fetch_all, fetch_one, query_page
from saasbase.persistence.connection import ConnectionProvider
from saasbase.persistence.dialect import (
    Dialect,
    instant_to_iso,
    iso_to_instant,
    text_to_uuid,
    uuid_to_text,
)
from saasbase.spi.persistence import DocumentVersionRecord

_COLS = (
    "id, document_id, organization_id, project_id, version_number, version_name, name, "
    "media_type, size_bytes, checksum, storage_key, storage_uri, metadata_json, created_at, "
    "created_by_subject"
)
_SELECT = f"SELECT {_COLS} FROM document_versions"
_COUNT = "SELECT COUNT(*) FROM document_versions"

_SORT_COLUMNS = {
    "version_number": "version_number",
    "version_name": "version_name",
    "created_at": "created_at",
}


class DocumentVersionSqlRepository:
    def __init__(self, provider: ConnectionProvider, dialect: Dialect) -> None:
        self._provider = provider
        self._dialect = dialect

    def _map(self, row: tuple) -> DocumentVersionRecord:
        return DocumentVersionRecord(
            id=text_to_uuid(row[0]),  # type: ignore[arg-type]
            document_id=text_to_uuid(row[1]),  # type: ignore[arg-type]
            organization_id=text_to_uuid(row[2]),  # type: ignore[arg-type]
            project_id=text_to_uuid(row[3]),  # type: ignore[arg-type]
            version_number=int(row[4]),
            version_name=row[5],
            name=row[6],
            media_type=row[7],
            size_bytes=int(row[8]),
            checksum=row[9],
            storage_key=row[10],
            storage_uri=row[11],
            metadata=self._dialect.json_result(row[12]),
            created_at=iso_to_instant(row[13]),  # type: ignore[arg-type]
            created_by_subject=row[14],
        )

    def create(self, record: DocumentVersionRecord) -> DocumentVersionRecord:
        sql = (
            f"INSERT INTO document_versions ({_COLS}) "
            "VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)"
        )
        execute(
            self._provider,
            self._dialect,
            sql,
            [
                uuid_to_text(record.id),
                uuid_to_text(record.document_id),
                uuid_to_text(record.organization_id),
                uuid_to_text(record.project_id),
                record.version_number,
                record.version_name,
                record.name,
                record.media_type,
                record.size_bytes,
                record.checksum,
                record.storage_key,
                record.storage_uri,
                self._dialect.json_param(record.metadata),
                instant_to_iso(record.created_at),
                record.created_by_subject,
            ],
        )
        return record

    def find_by_id(self, id: UUID) -> DocumentVersionRecord | None:
        row = fetch_one(
            self._provider, self._dialect, f"{_SELECT} WHERE id = ?", [uuid_to_text(id)]
        )
        return self._map(row) if row else None

    def find_by_document_id_and_version_name(
        self, document_id: UUID, version_name: str
    ) -> DocumentVersionRecord | None:
        row = fetch_one(
            self._provider,
            self._dialect,
            f"{_SELECT} WHERE document_id = ? AND version_name = ?",
            [uuid_to_text(document_id), version_name],
        )
        return self._map(row) if row else None

    def list_by_document_id(self, document_id: UUID) -> list[DocumentVersionRecord]:
        rows = fetch_all(
            self._provider,
            self._dialect,
            f"{_SELECT} WHERE document_id = ? ORDER BY version_number ASC",
            [uuid_to_text(document_id)],
        )
        return [self._map(r) for r in rows]

    def query(
        self, query: DocumentVersionQuery, page_request: PageRequest
    ) -> Page[DocumentVersionRecord]:
        clauses: list[str] = []
        params: list[Any] = []
        if query.organization_id is not None:
            clauses.append("organization_id = ?")
            params.append(uuid_to_text(query.organization_id))
        if query.project_id is not None:
            clauses.append("project_id = ?")
            params.append(uuid_to_text(query.project_id))
        if query.document_id is not None:
            clauses.append("document_id = ?")
            params.append(uuid_to_text(query.document_id))
        if query.name_contains:
            clauses.append("name LIKE ?")
            params.append(f"%{query.name_contains}%")
        if query.version_name:
            clauses.append("version_name = ?")
            params.append(query.version_name)
        if query.media_type:
            clauses.append("media_type = ?")
            params.append(query.media_type)
        if query.created_by_subject:
            clauses.append("created_by_subject = ?")
            params.append(query.created_by_subject)
        return query_page(
            self._provider,
            self._dialect,
            select_sql=_SELECT,
            count_sql=_COUNT,
            where_clauses=clauses,
            params=params,
            page_request=page_request,
            sort_columns=_SORT_COLUMNS,
            default_sort="version_number",
            mapper=self._map,
        )

    def delete_by_document_id(self, document_id: UUID) -> None:
        execute(
            self._provider,
            self._dialect,
            "DELETE FROM document_versions WHERE document_id = ?",
            [uuid_to_text(document_id)],
        )
