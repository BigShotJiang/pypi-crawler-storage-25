"""DB-API 2.0-backed persistence — repository implementations that work against SQLite or Postgres via a Dialect."""

from saasbase.persistence.api_call import ApiCallSqlRepository
from saasbase.persistence.api_key import ApiKeySqlRepository
from saasbase.persistence.audit import AuditEventSqlSink
from saasbase.persistence.connection import ConnectionProvider, ThreadLocalConnectionProvider
from saasbase.persistence.dialect import Dialect, PostgresDialect, SQLiteDialect
from saasbase.persistence.document import DocumentSqlRepository
from saasbase.persistence.document_version import DocumentVersionSqlRepository
from saasbase.persistence.execution import ExecutionSqlRepository
from saasbase.persistence.membership import MembershipSqlRepository
from saasbase.persistence.organization import OrganizationSqlRepository
from saasbase.persistence.project import ProjectSqlRepository
from saasbase.persistence.tx import DbApiTransactionManager

__all__ = [
    "ApiCallSqlRepository",
    "ApiKeySqlRepository",
    "AuditEventSqlSink",
    "ConnectionProvider",
    "DbApiTransactionManager",
    "Dialect",
    "DocumentSqlRepository",
    "DocumentVersionSqlRepository",
    "ExecutionSqlRepository",
    "MembershipSqlRepository",
    "OrganizationSqlRepository",
    "PostgresDialect",
    "ProjectSqlRepository",
    "SQLiteDialect",
    "ThreadLocalConnectionProvider",
]
