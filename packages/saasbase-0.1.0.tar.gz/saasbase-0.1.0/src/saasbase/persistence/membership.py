from __future__ import annotations

from saasbase.common.actor import ActorRef, ActorType
from saasbase.common.authz import Role
from saasbase.common.resource import ResourceRef, ResourceType
from saasbase.persistence._support import execute, fetch_all
from saasbase.persistence.connection import ConnectionProvider
from saasbase.persistence.dialect import (
    Dialect,
    instant_to_iso,
    iso_to_instant,
    text_to_uuid,
    uuid_to_text,
)
from saasbase.spi.persistence import MembershipRecord

_COLS = "id, resource_type, resource_id, actor_type, actor_id, role, inherited, granted_at"
_SELECT = f"SELECT {_COLS} FROM memberships"


class MembershipSqlRepository:
    def __init__(self, provider: ConnectionProvider, dialect: Dialect) -> None:
        self._provider = provider
        self._dialect = dialect

    def _map(self, row: tuple) -> MembershipRecord:
        return MembershipRecord(
            id=text_to_uuid(row[0]),  # type: ignore[arg-type]
            resource=ResourceRef(ResourceType(row[1]), text_to_uuid(row[2])),  # type: ignore[arg-type]
            actor=ActorRef(ActorType(row[3]), row[4]),
            role=Role(row[5]),
            inherited=bool(row[6]),
            granted_at=iso_to_instant(row[7]),  # type: ignore[arg-type]
        )

    def create(self, record: MembershipRecord) -> MembershipRecord:
        sql = f"INSERT INTO memberships ({_COLS}) VALUES (?, ?, ?, ?, ?, ?, ?, ?)"
        execute(
            self._provider,
            self._dialect,
            sql,
            [
                uuid_to_text(record.id),
                record.resource.type.value,
                uuid_to_text(record.resource.id),
                record.actor.type.value,
                record.actor.id,
                record.role.value,
                1 if record.inherited else 0,
                instant_to_iso(record.granted_at),
            ],
        )
        return record

    def list(self, resource: ResourceRef) -> list[MembershipRecord]:
        rows = fetch_all(
            self._provider,
            self._dialect,
            f"{_SELECT} WHERE resource_type = ? AND resource_id = ? ORDER BY granted_at ASC",
            [resource.type.value, uuid_to_text(resource.id)],
        )
        return [self._map(r) for r in rows]

    def revoke(self, resource: ResourceRef, actor: ActorRef, role: Role) -> None:
        execute(
            self._provider,
            self._dialect,
            "DELETE FROM memberships WHERE resource_type = ? AND resource_id = ? "
            "AND actor_type = ? AND actor_id = ? AND role = ?",
            [
                resource.type.value,
                uuid_to_text(resource.id),
                actor.type.value,
                actor.id,
                role.value,
            ],
        )

    def remove(self, resource: ResourceRef, actor: ActorRef) -> None:
        execute(
            self._provider,
            self._dialect,
            "DELETE FROM memberships WHERE resource_type = ? AND resource_id = ? "
            "AND actor_type = ? AND actor_id = ?",
            [
                resource.type.value,
                uuid_to_text(resource.id),
                actor.type.value,
                actor.id,
            ],
        )
