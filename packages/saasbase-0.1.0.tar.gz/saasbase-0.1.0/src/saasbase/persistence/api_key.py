from __future__ import annotations

from datetime import datetime
from uuid import UUID

from saasbase.common.authz import Role
from saasbase.common.resource import ResourceRef, ResourceType
from saasbase.persistence._support import execute, fetch_all, fetch_one
from saasbase.persistence.connection import ConnectionProvider
from saasbase.persistence.dialect import (
    Dialect,
    instant_to_iso,
    iso_to_instant,
    text_to_uuid,
    uuid_to_text,
)
from saasbase.spi.persistence import ApiKeyRecord

_COLS = (
    "id, name, prefix, secret_hash, scope_type, scope_id, role, organization_id, project_id, "
    "expires_at, last_used_at, revoked_at, metadata_json, created_at, updated_at, created_by_subject"
)
_SELECT = f"SELECT {_COLS} FROM api_keys"


class ApiKeySqlRepository:
    def __init__(self, provider: ConnectionProvider, dialect: Dialect) -> None:
        self._provider = provider
        self._dialect = dialect

    def _map(self, row: tuple) -> ApiKeyRecord:
        return ApiKeyRecord(
            id=text_to_uuid(row[0]),  # type: ignore[arg-type]
            name=row[1],
            prefix=row[2],
            secret_hash=row[3],
            scope=ResourceRef(ResourceType(row[4]), text_to_uuid(row[5])),  # type: ignore[arg-type]
            role=Role(row[6]),
            organization_id=text_to_uuid(row[7]),  # type: ignore[arg-type]
            project_id=text_to_uuid(row[8]),
            expires_at=iso_to_instant(row[9]),
            last_used_at=iso_to_instant(row[10]),
            revoked_at=iso_to_instant(row[11]),
            metadata=self._dialect.json_result(row[12]),
            created_at=iso_to_instant(row[13]),  # type: ignore[arg-type]
            updated_at=iso_to_instant(row[14]),  # type: ignore[arg-type]
            created_by_subject=row[15],
        )

    def create(self, record: ApiKeyRecord) -> ApiKeyRecord:
        sql = (
            f"INSERT INTO api_keys ({_COLS}) "
            "VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)"
        )
        execute(
            self._provider,
            self._dialect,
            sql,
            [
                uuid_to_text(record.id),
                record.name,
                record.prefix,
                record.secret_hash,
                record.scope.type.value,
                uuid_to_text(record.scope.id),
                record.role.value,
                uuid_to_text(record.organization_id),
                uuid_to_text(record.project_id),
                instant_to_iso(record.expires_at),
                instant_to_iso(record.last_used_at),
                instant_to_iso(record.revoked_at),
                self._dialect.json_param(record.metadata),
                instant_to_iso(record.created_at),
                instant_to_iso(record.updated_at),
                record.created_by_subject,
            ],
        )
        return record

    def find_by_id(self, id: UUID) -> ApiKeyRecord | None:
        row = fetch_one(
            self._provider, self._dialect, f"{_SELECT} WHERE id = ?", [uuid_to_text(id)]
        )
        return self._map(row) if row else None

    def find_by_prefix(self, prefix: str) -> ApiKeyRecord | None:
        row = fetch_one(
            self._provider, self._dialect, f"{_SELECT} WHERE prefix = ?", [prefix]
        )
        return self._map(row) if row else None

    def list_by_scope(self, scope: ResourceRef) -> list[ApiKeyRecord]:
        rows = fetch_all(
            self._provider,
            self._dialect,
            f"{_SELECT} WHERE scope_type = ? AND scope_id = ? ORDER BY created_at ASC",
            [scope.type.value, uuid_to_text(scope.id)],
        )
        return [self._map(r) for r in rows]

    def list_by_organization(self, organization_id: UUID) -> list[ApiKeyRecord]:
        rows = fetch_all(
            self._provider,
            self._dialect,
            f"{_SELECT} WHERE organization_id = ? ORDER BY created_at ASC",
            [uuid_to_text(organization_id)],
        )
        return [self._map(r) for r in rows]

    def update(self, record: ApiKeyRecord) -> ApiKeyRecord:
        sql = (
            "UPDATE api_keys SET name = ?, role = ?, expires_at = ?, last_used_at = ?, "
            "revoked_at = ?, metadata_json = ?, updated_at = ? WHERE id = ?"
        )
        execute(
            self._provider,
            self._dialect,
            sql,
            [
                record.name,
                record.role.value,
                instant_to_iso(record.expires_at),
                instant_to_iso(record.last_used_at),
                instant_to_iso(record.revoked_at),
                self._dialect.json_param(record.metadata),
                instant_to_iso(record.updated_at),
                uuid_to_text(record.id),
            ],
        )
        return record

    def touch_last_used(self, id: UUID, when: datetime) -> None:
        execute(
            self._provider,
            self._dialect,
            "UPDATE api_keys SET last_used_at = ? WHERE id = ?",
            [instant_to_iso(when), uuid_to_text(id)],
        )

    def delete(self, id: UUID) -> None:
        execute(
            self._provider, self._dialect, "DELETE FROM api_keys WHERE id = ?", [uuid_to_text(id)]
        )
