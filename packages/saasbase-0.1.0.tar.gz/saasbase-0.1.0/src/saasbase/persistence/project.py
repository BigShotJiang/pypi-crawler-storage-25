from __future__ import annotations

from typing import Any
from uuid import UUID

from saasbase.common.pagination import Page, PageRequest
from saasbase.common.query import ProjectQuery
from saasbase.persistence._support import execute, fetch_all, fetch_one, query_page
from saasbase.persistence.connection import ConnectionProvider
from saasbase.persistence.dialect import (
    Dialect,
    instant_to_iso,
    iso_to_instant,
    text_to_uuid,
    uuid_to_text,
)
from saasbase.spi.persistence import ProjectRecord

_SELECT = (
    "SELECT id, organization_id, name, metadata_json, created_at, updated_at, created_by_subject "
    "FROM projects"
)
_COUNT = "SELECT COUNT(*) FROM projects"

_SORT_COLUMNS = {
    "name": "name",
    "created_at": "created_at",
    "updated_at": "updated_at",
}


class ProjectSqlRepository:
    def __init__(self, provider: ConnectionProvider, dialect: Dialect) -> None:
        self._provider = provider
        self._dialect = dialect

    def _map(self, row: tuple) -> ProjectRecord:
        return ProjectRecord(
            id=text_to_uuid(row[0]),  # type: ignore[arg-type]
            organization_id=text_to_uuid(row[1]),  # type: ignore[arg-type]
            name=row[2],
            metadata=self._dialect.json_result(row[3]),
            created_at=iso_to_instant(row[4]),  # type: ignore[arg-type]
            updated_at=iso_to_instant(row[5]),  # type: ignore[arg-type]
            created_by_subject=row[6],
        )

    def create(self, record: ProjectRecord) -> ProjectRecord:
        sql = (
            "INSERT INTO projects "
            "(id, organization_id, name, metadata_json, created_at, updated_at, created_by_subject) "
            "VALUES (?, ?, ?, ?, ?, ?, ?)"
        )
        execute(
            self._provider,
            self._dialect,
            sql,
            [
                uuid_to_text(record.id),
                uuid_to_text(record.organization_id),
                record.name,
                self._dialect.json_param(record.metadata),
                instant_to_iso(record.created_at),
                instant_to_iso(record.updated_at),
                record.created_by_subject,
            ],
        )
        return record

    def find_by_id(self, id: UUID) -> ProjectRecord | None:
        row = fetch_one(
            self._provider, self._dialect, f"{_SELECT} WHERE id = ?", [uuid_to_text(id)]
        )
        return self._map(row) if row else None

    def list_by_organization(self, organization_id: UUID) -> list[ProjectRecord]:
        rows = fetch_all(
            self._provider,
            self._dialect,
            f"{_SELECT} WHERE organization_id = ? ORDER BY created_at ASC",
            [uuid_to_text(organization_id)],
        )
        return [self._map(r) for r in rows]

    def query(self, query: ProjectQuery, page_request: PageRequest) -> Page[ProjectRecord]:
        clauses: list[str] = []
        params: list[Any] = []
        if query.organization_id is not None:
            clauses.append("organization_id = ?")
            params.append(uuid_to_text(query.organization_id))
        if query.name_contains:
            clauses.append("name LIKE ?")
            params.append(f"%{query.name_contains}%")
        if query.created_by_subject:
            clauses.append("created_by_subject = ?")
            params.append(query.created_by_subject)
        return query_page(
            self._provider,
            self._dialect,
            select_sql=_SELECT,
            count_sql=_COUNT,
            where_clauses=clauses,
            params=params,
            page_request=page_request,
            sort_columns=_SORT_COLUMNS,
            default_sort="created_at",
            mapper=self._map,
        )

    def update(self, record: ProjectRecord) -> ProjectRecord:
        sql = "UPDATE projects SET name = ?, metadata_json = ?, updated_at = ? WHERE id = ?"
        execute(
            self._provider,
            self._dialect,
            sql,
            [
                record.name,
                self._dialect.json_param(record.metadata),
                instant_to_iso(record.updated_at),
                uuid_to_text(record.id),
            ],
        )
        return record

    def delete(self, id: UUID) -> None:
        execute(
            self._provider, self._dialect, "DELETE FROM projects WHERE id = ?", [uuid_to_text(id)]
        )
