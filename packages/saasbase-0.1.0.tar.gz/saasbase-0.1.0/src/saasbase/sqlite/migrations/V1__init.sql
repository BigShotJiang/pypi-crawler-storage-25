CREATE TABLE IF NOT EXISTS organizations (
    id TEXT PRIMARY KEY,
    slug TEXT NOT NULL UNIQUE,
    name TEXT NOT NULL,
    metadata_json TEXT,
    created_at TEXT NOT NULL,
    updated_at TEXT NOT NULL,
    created_by_subject TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS projects (
    id TEXT PRIMARY KEY,
    organization_id TEXT NOT NULL,
    name TEXT NOT NULL,
    metadata_json TEXT,
    created_at TEXT NOT NULL,
    updated_at TEXT NOT NULL,
    created_by_subject TEXT NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_projects_organization_id ON projects (organization_id);

CREATE TABLE IF NOT EXISTS documents (
    id TEXT PRIMARY KEY,
    organization_id TEXT NOT NULL,
    project_id TEXT NOT NULL,
    current_version_id TEXT NOT NULL,
    current_version_number INTEGER NOT NULL,
    current_version_name TEXT NOT NULL,
    name TEXT NOT NULL,
    media_type TEXT NOT NULL,
    size_bytes INTEGER NOT NULL,
    checksum TEXT NOT NULL,
    storage_key TEXT NOT NULL,
    storage_uri TEXT NOT NULL,
    metadata_json TEXT,
    created_at TEXT NOT NULL,
    updated_at TEXT NOT NULL,
    created_by_subject TEXT NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_documents_project_id ON documents (project_id);
CREATE INDEX IF NOT EXISTS idx_documents_organization_id ON documents (organization_id);

CREATE TABLE IF NOT EXISTS document_versions (
    id TEXT PRIMARY KEY,
    document_id TEXT NOT NULL,
    organization_id TEXT NOT NULL,
    project_id TEXT NOT NULL,
    version_number INTEGER NOT NULL,
    version_name TEXT NOT NULL,
    name TEXT NOT NULL,
    media_type TEXT NOT NULL,
    size_bytes INTEGER NOT NULL,
    checksum TEXT NOT NULL,
    storage_key TEXT NOT NULL,
    storage_uri TEXT NOT NULL,
    metadata_json TEXT,
    created_at TEXT NOT NULL,
    created_by_subject TEXT NOT NULL
);
CREATE UNIQUE INDEX IF NOT EXISTS idx_document_versions_document_version_number
    ON document_versions (document_id, version_number);
CREATE UNIQUE INDEX IF NOT EXISTS idx_document_versions_document_version_name
    ON document_versions (document_id, version_name);
CREATE INDEX IF NOT EXISTS idx_document_versions_document_id ON document_versions (document_id);
CREATE INDEX IF NOT EXISTS idx_document_versions_project_id ON document_versions (project_id);
CREATE INDEX IF NOT EXISTS idx_document_versions_organization_id ON document_versions (organization_id);

CREATE TABLE IF NOT EXISTS api_calls (
    id TEXT PRIMARY KEY,
    organization_id TEXT NOT NULL,
    project_id TEXT NOT NULL,
    name TEXT NOT NULL,
    operation_key TEXT NOT NULL,
    external_request_id TEXT,
    idempotency_key TEXT,
    correlation_id TEXT,
    status TEXT NOT NULL,
    requested_at TEXT NOT NULL,
    responded_at TEXT,
    request_payload_json TEXT,
    response_payload_json TEXT,
    metadata_json TEXT,
    created_at TEXT NOT NULL,
    updated_at TEXT NOT NULL,
    created_by_subject TEXT NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_api_calls_project_id ON api_calls (project_id);
CREATE INDEX IF NOT EXISTS idx_api_calls_organization_id ON api_calls (organization_id);
CREATE INDEX IF NOT EXISTS idx_api_calls_requested_at ON api_calls (requested_at);
CREATE INDEX IF NOT EXISTS idx_api_calls_correlation_id ON api_calls (correlation_id);

CREATE TABLE IF NOT EXISTS memberships (
    id TEXT PRIMARY KEY,
    resource_type TEXT NOT NULL,
    resource_id TEXT NOT NULL,
    actor_type TEXT NOT NULL,
    actor_id TEXT NOT NULL,
    role TEXT NOT NULL,
    inherited INTEGER NOT NULL,
    granted_at TEXT NOT NULL
);
CREATE UNIQUE INDEX IF NOT EXISTS idx_memberships_unique_grant
    ON memberships (resource_type, resource_id, actor_type, actor_id, role);
CREATE INDEX IF NOT EXISTS idx_memberships_resource ON memberships (resource_type, resource_id);
CREATE INDEX IF NOT EXISTS idx_memberships_actor ON memberships (actor_type, actor_id);

CREATE TABLE IF NOT EXISTS executions (
    id TEXT PRIMARY KEY,
    organization_id TEXT NOT NULL,
    project_id TEXT NOT NULL,
    operation TEXT NOT NULL,
    status TEXT NOT NULL,
    actor_type TEXT NOT NULL,
    actor_id TEXT NOT NULL,
    target_resource_type TEXT,
    target_resource_id TEXT,
    correlation_id TEXT,
    parent_execution_id TEXT,
    agent_version TEXT,
    model_provider TEXT,
    model_name TEXT,
    confidence REAL,
    warnings_json TEXT,
    provenance_json TEXT,
    started_at TEXT NOT NULL,
    ended_at TEXT,
    input_json TEXT,
    output_json TEXT,
    metadata_json TEXT
);
CREATE INDEX IF NOT EXISTS idx_executions_project_id ON executions (project_id);
CREATE INDEX IF NOT EXISTS idx_executions_organization_id ON executions (organization_id);
CREATE INDEX IF NOT EXISTS idx_executions_correlation_id ON executions (correlation_id);
CREATE INDEX IF NOT EXISTS idx_executions_parent_execution_id ON executions (parent_execution_id);
CREATE INDEX IF NOT EXISTS idx_executions_model_provider_name ON executions (model_provider, model_name);

CREATE TABLE IF NOT EXISTS audit_events (
    id TEXT PRIMARY KEY,
    occurred_at TEXT NOT NULL,
    actor_type TEXT NOT NULL,
    actor_id TEXT NOT NULL,
    action TEXT NOT NULL,
    resource_type TEXT NOT NULL,
    resource_id TEXT NOT NULL,
    organization_id TEXT,
    project_id TEXT,
    correlation_id TEXT,
    details_json TEXT
);
CREATE INDEX IF NOT EXISTS idx_audit_events_resource ON audit_events (resource_type, resource_id, occurred_at);
CREATE INDEX IF NOT EXISTS idx_audit_events_correlation_id ON audit_events (correlation_id, occurred_at);
CREATE INDEX IF NOT EXISTS idx_audit_events_org_project_occurred_at ON audit_events (organization_id, project_id, occurred_at);
CREATE INDEX IF NOT EXISTS idx_audit_events_action_occurred_at ON audit_events (action, occurred_at);
CREATE INDEX IF NOT EXISTS idx_audit_events_actor_occurred_at ON audit_events (actor_type, actor_id, occurred_at);

CREATE TABLE IF NOT EXISTS api_keys (
    id TEXT PRIMARY KEY,
    name TEXT NOT NULL,
    prefix TEXT NOT NULL,
    secret_hash TEXT NOT NULL,
    scope_type TEXT NOT NULL,
    scope_id TEXT NOT NULL,
    role TEXT NOT NULL,
    organization_id TEXT NOT NULL,
    project_id TEXT,
    expires_at TEXT,
    last_used_at TEXT,
    revoked_at TEXT,
    metadata_json TEXT,
    created_at TEXT NOT NULL,
    updated_at TEXT NOT NULL,
    created_by_subject TEXT NOT NULL
);
CREATE UNIQUE INDEX IF NOT EXISTS idx_api_keys_prefix ON api_keys (prefix);
CREATE INDEX IF NOT EXISTS idx_api_keys_scope ON api_keys (scope_type, scope_id);
CREATE INDEX IF NOT EXISTS idx_api_keys_organization_id ON api_keys (organization_id);
CREATE INDEX IF NOT EXISTS idx_api_keys_project_id ON api_keys (project_id);
