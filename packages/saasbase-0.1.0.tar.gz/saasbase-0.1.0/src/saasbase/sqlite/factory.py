from __future__ import annotations

import sqlite3
from importlib import resources
from pathlib import Path
from typing import Any

from saasbase.common.exceptions import SaaSBaseError

DEFAULT_URL = "jdbc:sqlite:./data/saasbase.db"
MIGRATION_RESOURCE = "V1__init.sql"


def sqlite_path_from_url(url: str) -> Path | None:
    """Extract the filesystem path from a JDBC-style SQLite URL. Returns None for in-memory."""
    if not url:
        return None
    raw = url
    if raw.startswith("jdbc:sqlite:"):
        raw = raw[len("jdbc:sqlite:"):]
    raw = raw.strip()
    if not raw:
        return None
    # Drop query string
    q = raw.find("?")
    if q >= 0:
        raw = raw[:q]
    if raw in (":memory:", "file::memory:") or raw.startswith("file::memory:"):
        return None
    if raw.startswith("file:"):
        # sqlite file URI — strip scheme
        raw = raw[len("file:"):]
    return Path(raw)


def _load_migration_sql() -> str:
    pkg_files = resources.files("saasbase.sqlite.migrations")
    return (pkg_files / MIGRATION_RESOURCE).read_text(encoding="utf-8")


class SQLiteFactory:
    """Creates sqlite3 Connection objects and applies the V1 migration on first build."""

    def __init__(self, url: str | None = None) -> None:
        self._url = url or DEFAULT_URL
        self._path = sqlite_path_from_url(self._url)

    @property
    def url(self) -> str:
        return self._url

    def ensure_parent_directory(self) -> None:
        if self._path is None:
            return
        parent = self._path.parent
        if parent and str(parent) and parent != Path():
            parent.mkdir(parents=True, exist_ok=True)

    def apply_schema(self) -> None:
        sql = _load_migration_sql()
        self.ensure_parent_directory()
        conn = self.connect()
        try:
            conn.executescript(sql)
            conn.commit()
        except sqlite3.Error as exc:
            try:
                conn.rollback()
            except sqlite3.Error:
                pass
            raise SaaSBaseError(f"Failed to initialize SQLite schema: {exc}") from exc
        finally:
            conn.close()

    def connect(self) -> sqlite3.Connection:
        target: Any
        if self._path is None:
            if self._url.startswith("jdbc:sqlite:"):
                inner = self._url[len("jdbc:sqlite:"):]
            else:
                inner = self._url
            inner = inner.strip() or ":memory:"
            target = inner
        else:
            target = str(self._path)
        conn = sqlite3.connect(target, isolation_level=None, check_same_thread=False)
        conn.execute("PRAGMA foreign_keys = ON")
        return conn
