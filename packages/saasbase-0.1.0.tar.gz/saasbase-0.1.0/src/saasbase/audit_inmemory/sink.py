from __future__ import annotations

import threading

from saasbase.common.pagination import Page, PageRequest
from saasbase.common.query import AuditQuery
from saasbase.common.resource import ResourceRef
from saasbase.spi.audit import AuditEventRecord


def _matches(event: AuditEventRecord, query: AuditQuery) -> bool:
    if query.organization_id is not None and event.organization_id != query.organization_id:
        return False
    if query.project_id is not None and event.project_id != query.project_id:
        return False
    if query.action is not None and event.action != query.action:
        return False
    if query.actor is not None and event.actor != query.actor:
        return False
    if query.resource_type is not None and event.resource.type != query.resource_type:
        return False
    if query.correlation_id and event.correlation_id != query.correlation_id:
        return False
    if query.occurred_from is not None and event.occurred_at < query.occurred_from:
        return False
    if query.occurred_to is not None and event.occurred_at > query.occurred_to:
        return False
    return True


class InMemoryAuditEventSink:
    def __init__(self) -> None:
        self._events: list[AuditEventRecord] = []
        self._lock = threading.RLock()

    def record(self, event: AuditEventRecord) -> None:
        with self._lock:
            self._events.append(event)

    def list(self, resource: ResourceRef) -> list[AuditEventRecord]:
        with self._lock:
            return [e for e in self._events if e.resource == resource]

    def list_by_correlation_id(self, correlation_id: str) -> list[AuditEventRecord]:
        with self._lock:
            return [e for e in self._events if e.correlation_id == correlation_id]

    def query(self, query: AuditQuery, page_request: PageRequest) -> Page[AuditEventRecord]:
        with self._lock:
            filtered = [e for e in self._events if _matches(e, query)]
        filtered.sort(key=lambda e: e.occurred_at)
        total = len(filtered)
        start = page_request.offset
        end = start + page_request.size
        return Page.of(filtered[start:end], total, page_request)

    def prune(self, query: AuditQuery) -> int:
        with self._lock:
            before = len(self._events)
            self._events = [e for e in self._events if not _matches(e, query)]
            return before - len(self._events)


class NoOpAuditEventSink:
    """AuditEventSink that discards everything — used when no audit backend is configured."""

    def record(self, event: AuditEventRecord) -> None:
        return None

    def list(self, resource: ResourceRef) -> list[AuditEventRecord]:
        return []

    def list_by_correlation_id(self, correlation_id: str) -> list[AuditEventRecord]:
        return []

    def query(self, query: AuditQuery, page_request: PageRequest) -> Page[AuditEventRecord]:
        return Page.of([], 0, page_request)

    def prune(self, query: AuditQuery) -> int:
        return 0
