from __future__ import annotations

from dataclasses import dataclass, field
from enum import Enum
from typing import Protocol

from saasbase.common.actor import ActorRef
from saasbase.common.authz import Action, Role
from saasbase.common.resource import ResourceRef


class AuthorizationExplanationSource(str, Enum):
    EFFECTIVE_ROLE = "EFFECTIVE_ROLE"
    AUTHZ_ENGINE = "AUTHZ_ENGINE"
    NONE = "NONE"


@dataclass(frozen=True, slots=True)
class EffectiveAuthorizationRole:
    role: Role
    granted_on: ResourceRef
    effective_on: ResourceRef
    inherited: bool
    actions: list[Action] = field(default_factory=list)


@dataclass(frozen=True, slots=True)
class AuthorizationExplanation:
    actor: ActorRef
    action: Action
    resource: ResourceRef
    allowed: bool
    source: AuthorizationExplanationSource
    reason: str
    evaluated_scopes: list[ResourceRef] = field(default_factory=list)
    effective_roles: list[EffectiveAuthorizationRole] = field(default_factory=list)
    matching_roles: list[EffectiveAuthorizationRole] = field(default_factory=list)


class AuthorizationApi(Protocol):
    def can(self, actor: ActorRef, action: Action, resource: ResourceRef) -> bool: ...

    def check(self, actor: ActorRef, action: Action, resource: ResourceRef) -> None:
        """Raise PermissionDeniedError if the actor cannot perform the action on the resource."""

    def effective_roles(
        self, actor: ActorRef, resource: ResourceRef
    ) -> list[EffectiveAuthorizationRole]: ...

    def explain(
        self, actor: ActorRef, action: Action, resource: ResourceRef
    ) -> AuthorizationExplanation: ...

    def who_can(self, action: Action, resource: ResourceRef) -> list[ActorRef]: ...

    def who_can_explain(
        self, action: Action, resource: ResourceRef
    ) -> list[AuthorizationExplanation]: ...
