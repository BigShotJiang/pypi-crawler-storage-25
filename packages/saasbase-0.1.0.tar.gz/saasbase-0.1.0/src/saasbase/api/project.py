from __future__ import annotations

from dataclasses import dataclass, field
from typing import TYPE_CHECKING, Any, Protocol
from uuid import UUID

from saasbase.common.pagination import Page, PageRequest
from saasbase.common.query import ProjectQuery
from saasbase.common.resource import ResourceRef

if TYPE_CHECKING:
    from saasbase.api.apicall import ApiCallCollection
    from saasbase.api.document import DocumentCollection
    from saasbase.api.membership import MemberCollection


@dataclass(frozen=True, slots=True)
class CreateProjectRequest:
    organization_id: UUID
    name: str
    metadata: dict[str, Any] = field(default_factory=dict)


@dataclass(frozen=True, slots=True)
class UpdateProjectRequest:
    name: str | None = None
    metadata: dict[str, Any] | None = None


class Project(Protocol):
    @property
    def id(self) -> UUID: ...
    @property
    def organization_id(self) -> UUID: ...
    @property
    def name(self) -> str: ...
    @property
    def metadata(self) -> dict[str, Any]: ...
    @property
    def ref(self) -> ResourceRef: ...
    @property
    def documents(self) -> DocumentCollection: ...
    @property
    def api_calls(self) -> ApiCallCollection: ...
    @property
    def members(self) -> MemberCollection: ...

    def rename(self, new_name: str) -> Project: ...
    def put_metadata(self, key: str, value: Any) -> Project: ...
    def remove_metadata(self, key: str) -> Project: ...
    def delete(self) -> None: ...


class ProjectCollection(Protocol):
    """Projects navigation from an Organization."""

    def create(self, name: str, metadata: dict[str, Any] | None = None) -> Project: ...
    def list(self) -> list[Project]: ...
    def find_by_id(self, id: UUID) -> Project | None: ...


class ProjectApi(Protocol):
    def create(
        self,
        organization_id: UUID,
        name: str,
        metadata: dict[str, Any] | None = None,
    ) -> Project: ...

    def create_from(self, request: CreateProjectRequest) -> Project: ...

    def find_by_id(self, id: UUID) -> Project | None: ...

    def list_by_organization(self, organization_id: UUID) -> list[Project]: ...

    def query(self, query: ProjectQuery, page_request: PageRequest) -> Page[Project]: ...

    def update(self, id: UUID, request: UpdateProjectRequest) -> Project: ...

    def delete(self, id: UUID) -> None: ...
