from __future__ import annotations

from dataclasses import dataclass, field
from datetime import datetime
from pathlib import Path
from typing import TYPE_CHECKING, Any, BinaryIO, Protocol
from uuid import UUID

from saasbase.api.resource import ProjectResource
from saasbase.common.pagination import Page, PageRequest
from saasbase.common.query import DocumentQuery, DocumentVersionQuery

if TYPE_CHECKING:
    pass


@dataclass(frozen=True, slots=True)
class UploadDocumentRequest:
    project_id: UUID
    name: str
    content: BinaryIO
    media_type: str
    version_name: str | None = None
    metadata: dict[str, Any] = field(default_factory=dict)


@dataclass(frozen=True, slots=True)
class CreateDocumentVersionRequest:
    content: BinaryIO
    media_type: str
    version_name: str | None = None
    name: str | None = None
    metadata: dict[str, Any] = field(default_factory=dict)


@dataclass(frozen=True, slots=True)
class UpdateDocumentRequest:
    name: str | None = None
    metadata: dict[str, Any] | None = None


class Document(ProjectResource, Protocol):
    @property
    def current_version_id(self) -> UUID: ...
    @property
    def current_version_number(self) -> int: ...
    @property
    def current_version_name(self) -> str: ...
    @property
    def media_type(self) -> str: ...
    @property
    def size_bytes(self) -> int: ...
    @property
    def checksum(self) -> str: ...
    @property
    def storage_uri(self) -> str: ...

    def open_stream(self) -> BinaryIO: ...
    def download_to(self, target_directory: Path) -> Path: ...


class DocumentVersion(Protocol):
    @property
    def id(self) -> UUID: ...
    @property
    def document_id(self) -> UUID: ...
    @property
    def organization_id(self) -> UUID: ...
    @property
    def project_id(self) -> UUID: ...
    @property
    def version_number(self) -> int: ...
    @property
    def version_name(self) -> str: ...
    @property
    def name(self) -> str: ...
    @property
    def media_type(self) -> str: ...
    @property
    def size_bytes(self) -> int: ...
    @property
    def checksum(self) -> str: ...
    @property
    def storage_uri(self) -> str: ...
    @property
    def metadata(self) -> dict[str, Any]: ...
    @property
    def created_at(self) -> datetime: ...
    @property
    def created_by_subject(self) -> str: ...

    def open_stream(self) -> BinaryIO: ...
    def download_to(self, target_directory: Path) -> Path: ...


class DocumentCollection(Protocol):
    def upload(
        self,
        name: str,
        content: BinaryIO,
        media_type: str,
        version_name: str | None = None,
        metadata: dict[str, Any] | None = None,
    ) -> Document: ...
    def upload_path(self, path: Path, media_type: str | None = None) -> Document: ...
    def list(self) -> list[Document]: ...
    def find_by_id(self, id: UUID) -> Document | None: ...


class DocumentApi(Protocol):
    def upload(
        self,
        project_id: UUID,
        name: str,
        content: BinaryIO,
        media_type: str,
        version_name: str | None = None,
        metadata: dict[str, Any] | None = None,
    ) -> Document: ...

    def upload_path(
        self, project_id: UUID, path: Path, media_type: str | None = None
    ) -> Document: ...

    def upload_from(self, request: UploadDocumentRequest) -> Document: ...

    def find_by_id(self, id: UUID) -> Document | None: ...

    def list_by_project(self, project_id: UUID) -> list[Document]: ...

    def query(self, query: DocumentQuery, page_request: PageRequest) -> Page[Document]: ...

    def create_version(self, id: UUID, request: CreateDocumentVersionRequest) -> Document: ...

    def find_version_by_id(self, id: UUID) -> DocumentVersion | None: ...

    def find_version(self, document_id: UUID, version_name: str) -> DocumentVersion | None: ...

    def list_versions(self, document_id: UUID) -> list[DocumentVersion]: ...

    def query_versions(
        self, query: DocumentVersionQuery, page_request: PageRequest
    ) -> Page[DocumentVersion]: ...

    def update(self, id: UUID, request: UpdateDocumentRequest) -> Document: ...

    def delete(self, id: UUID) -> None: ...
