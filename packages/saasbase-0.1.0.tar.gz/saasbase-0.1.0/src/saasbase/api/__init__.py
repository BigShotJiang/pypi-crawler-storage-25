"""Public API — Protocols for the SaaSBase entry point and per-domain APIs, plus their DTOs."""

from saasbase.api.apicall import (
    ApiCall,
    ApiCallApi,
    ApiCallCollection,
    ApiCallCreateRequest,
    ApiCallUpdateRequest,
)
from saasbase.api.apikey import (
    ApiKey,
    ApiKeyApi,
    CreateApiKeyRequest,
    CreatedApiKey,
    UpdateApiKeyRequest,
)
from saasbase.api.audit import AuditApi, AuditEvent
from saasbase.api.authorization import (
    AuthorizationApi,
    AuthorizationExplanation,
    AuthorizationExplanationSource,
    EffectiveAuthorizationRole,
)
from saasbase.api.base import Builder, SaaSBase, SaaSBaseContext
from saasbase.api.document import (
    CreateDocumentVersionRequest,
    Document,
    DocumentApi,
    DocumentCollection,
    DocumentVersion,
    UpdateDocumentRequest,
    UploadDocumentRequest,
)
from saasbase.api.execution import (
    CompleteExecutionRequest,
    Execution,
    ExecutionApi,
    FailExecutionRequest,
    StartExecutionRequest,
)
from saasbase.api.membership import MemberCollection, Membership, MembershipApi
from saasbase.api.organization import (
    CreateOrganizationRequest,
    Organization,
    OrganizationApi,
    UpdateOrganizationRequest,
)
from saasbase.api.project import (
    CreateProjectRequest,
    Project,
    ProjectApi,
    ProjectCollection,
    UpdateProjectRequest,
)
from saasbase.api.resource import ProjectResource

__all__ = [
    "ApiCall",
    "ApiCallApi",
    "ApiCallCollection",
    "ApiCallCreateRequest",
    "ApiCallUpdateRequest",
    "ApiKey",
    "ApiKeyApi",
    "AuditApi",
    "AuditEvent",
    "AuthorizationApi",
    "AuthorizationExplanation",
    "AuthorizationExplanationSource",
    "Builder",
    "CompleteExecutionRequest",
    "CreateApiKeyRequest",
    "CreateDocumentVersionRequest",
    "CreateOrganizationRequest",
    "CreateProjectRequest",
    "CreatedApiKey",
    "Document",
    "DocumentApi",
    "DocumentCollection",
    "DocumentVersion",
    "EffectiveAuthorizationRole",
    "Execution",
    "ExecutionApi",
    "FailExecutionRequest",
    "MemberCollection",
    "Membership",
    "MembershipApi",
    "Organization",
    "OrganizationApi",
    "Project",
    "ProjectApi",
    "ProjectCollection",
    "ProjectResource",
    "SaaSBase",
    "SaaSBaseContext",
    "StartExecutionRequest",
    "UpdateApiKeyRequest",
    "UpdateDocumentRequest",
    "UpdateOrganizationRequest",
    "UpdateProjectRequest",
    "UploadDocumentRequest",
]
