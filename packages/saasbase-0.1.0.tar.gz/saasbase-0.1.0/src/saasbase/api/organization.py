from __future__ import annotations

from dataclasses import dataclass, field
from typing import TYPE_CHECKING, Any, Protocol
from uuid import UUID

from saasbase.common.pagination import Page, PageRequest
from saasbase.common.query import OrganizationQuery
from saasbase.common.resource import ResourceRef

if TYPE_CHECKING:
    from saasbase.api.membership import MemberCollection
    from saasbase.api.project import ProjectCollection


@dataclass(frozen=True, slots=True)
class CreateOrganizationRequest:
    slug: str
    name: str | None = None
    metadata: dict[str, Any] = field(default_factory=dict)


@dataclass(frozen=True, slots=True)
class UpdateOrganizationRequest:
    name: str | None = None
    metadata: dict[str, Any] | None = None


class Organization(Protocol):
    @property
    def id(self) -> UUID: ...
    @property
    def slug(self) -> str: ...
    @property
    def name(self) -> str: ...
    @property
    def metadata(self) -> dict[str, Any]: ...
    @property
    def ref(self) -> ResourceRef: ...
    @property
    def projects(self) -> ProjectCollection: ...
    @property
    def members(self) -> MemberCollection: ...

    def rename(self, new_name: str) -> Organization: ...
    def put_metadata(self, key: str, value: Any) -> Organization: ...
    def remove_metadata(self, key: str) -> Organization: ...
    def delete(self) -> None: ...


class OrganizationApi(Protocol):
    def create(
        self,
        slug: str,
        name: str | None = None,
        metadata: dict[str, Any] | None = None,
    ) -> Organization: ...

    def create_from(self, request: CreateOrganizationRequest) -> Organization: ...

    def find_by_id(self, id: UUID) -> Organization | None: ...

    def find_by_slug(self, slug: str) -> Organization | None: ...

    def list(self) -> list[Organization]: ...

    def query(self, query: OrganizationQuery, page_request: PageRequest) -> Page[Organization]: ...

    def update(self, id: UUID, request: UpdateOrganizationRequest) -> Organization: ...

    def delete(self, id: UUID) -> None: ...
