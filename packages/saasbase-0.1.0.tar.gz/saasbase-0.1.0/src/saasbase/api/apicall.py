from __future__ import annotations

from dataclasses import dataclass, field
from datetime import datetime
from typing import Any, Protocol
from uuid import UUID

from saasbase.api.resource import ProjectResource
from saasbase.common.pagination import Page, PageRequest
from saasbase.common.query import ApiCallQuery
from saasbase.common.status import ApiCallStatus


@dataclass(frozen=True, slots=True)
class ApiCallCreateRequest:
    name: str
    operation_key: str
    external_request_id: str | None = None
    idempotency_key: str | None = None
    correlation_id: str | None = None
    request_payload: dict[str, Any] = field(default_factory=dict)
    metadata: dict[str, Any] = field(default_factory=dict)


@dataclass(frozen=True, slots=True)
class ApiCallUpdateRequest:
    status: ApiCallStatus | None = None
    response_payload: dict[str, Any] | None = None
    metadata: dict[str, Any] | None = None


class ApiCall(ProjectResource, Protocol):
    @property
    def operation_key(self) -> str: ...
    @property
    def external_request_id(self) -> str | None: ...
    @property
    def idempotency_key(self) -> str | None: ...
    @property
    def correlation_id(self) -> str | None: ...
    @property
    def status(self) -> ApiCallStatus: ...
    @property
    def requested_at(self) -> datetime: ...
    @property
    def responded_at(self) -> datetime | None: ...
    @property
    def request_payload(self) -> dict[str, Any]: ...
    @property
    def response_payload(self) -> dict[str, Any]: ...

    def update_status(self, status: ApiCallStatus) -> ApiCall: ...
    def set_response_payload(self, payload: dict[str, Any]) -> ApiCall: ...


class ApiCallCollection(Protocol):
    def create(self, request: ApiCallCreateRequest) -> ApiCall: ...
    def list(self) -> list[ApiCall]: ...
    def find_by_id(self, id: UUID) -> ApiCall | None: ...


class ApiCallApi(Protocol):
    def create(self, project_id: UUID, request: ApiCallCreateRequest) -> ApiCall: ...

    def find_by_id(self, id: UUID) -> ApiCall | None: ...

    def list_by_project(self, project_id: UUID) -> list[ApiCall]: ...

    def list_by_correlation_id(self, correlation_id: str) -> list[ApiCall]: ...

    def query(self, query: ApiCallQuery, page_request: PageRequest) -> Page[ApiCall]: ...

    def update(self, id: UUID, request: ApiCallUpdateRequest) -> ApiCall: ...

    def delete(self, id: UUID) -> None: ...
