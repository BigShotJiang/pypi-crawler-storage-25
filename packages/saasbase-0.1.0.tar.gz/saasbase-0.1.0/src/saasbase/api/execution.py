from __future__ import annotations

from dataclasses import dataclass, field
from datetime import datetime
from typing import Any, Protocol
from uuid import UUID

from saasbase.common.actor import ActorRef
from saasbase.common.pagination import Page, PageRequest
from saasbase.common.query import ExecutionQuery
from saasbase.common.resource import ResourceRef
from saasbase.common.status import ExecutionStatus


@dataclass(frozen=True, slots=True)
class StartExecutionRequest:
    organization_id: UUID
    project_id: UUID
    operation: str
    target: ResourceRef | None = None
    correlation_id: str | None = None
    parent_execution_id: UUID | None = None
    agent_version: str | None = None
    model_provider: str | None = None
    model_name: str | None = None
    confidence: float | None = None
    warnings: list[str] = field(default_factory=list)
    provenance: dict[str, Any] = field(default_factory=dict)
    input: dict[str, Any] = field(default_factory=dict)
    metadata: dict[str, Any] = field(default_factory=dict)


@dataclass(frozen=True, slots=True)
class CompleteExecutionRequest:
    output: dict[str, Any] = field(default_factory=dict)
    metadata: dict[str, Any] | None = None


@dataclass(frozen=True, slots=True)
class FailExecutionRequest:
    error_code: str | None = None
    error_message: str | None = None
    metadata: dict[str, Any] | None = None


class Execution(Protocol):
    @property
    def id(self) -> UUID: ...
    @property
    def organization_id(self) -> UUID: ...
    @property
    def project_id(self) -> UUID: ...
    @property
    def operation(self) -> str: ...
    @property
    def status(self) -> ExecutionStatus: ...
    @property
    def actor(self) -> ActorRef: ...
    @property
    def target(self) -> ResourceRef | None: ...
    @property
    def correlation_id(self) -> str | None: ...
    @property
    def parent_execution_id(self) -> UUID | None: ...
    @property
    def agent_version(self) -> str | None: ...
    @property
    def model_provider(self) -> str | None: ...
    @property
    def model_name(self) -> str | None: ...
    @property
    def confidence(self) -> float | None: ...
    @property
    def warnings(self) -> list[str]: ...
    @property
    def provenance(self) -> dict[str, Any]: ...
    @property
    def started_at(self) -> datetime | None: ...
    @property
    def ended_at(self) -> datetime | None: ...
    @property
    def input(self) -> dict[str, Any]: ...
    @property
    def output(self) -> dict[str, Any]: ...
    @property
    def metadata(self) -> dict[str, Any]: ...


class ExecutionApi(Protocol):
    def start(self, request: StartExecutionRequest) -> Execution: ...

    def complete(self, execution_id: UUID, request: CompleteExecutionRequest) -> Execution: ...

    def fail(self, execution_id: UUID, request: FailExecutionRequest) -> Execution: ...

    def find_by_id(self, execution_id: UUID) -> Execution | None: ...

    def list_by_project(self, project_id: UUID) -> list[Execution]: ...

    def list_by_correlation_id(self, correlation_id: str) -> list[Execution]: ...

    def list_children(self, parent_execution_id: UUID) -> list[Execution]: ...

    def query(self, query: ExecutionQuery, page_request: PageRequest) -> Page[Execution]: ...
