from __future__ import annotations

from dataclasses import dataclass, field
from datetime import datetime
from typing import Any, Protocol
from uuid import UUID

from saasbase.common.actor import ActorRef
from saasbase.common.authz import Role
from saasbase.common.resource import ResourceRef


@dataclass(frozen=True, slots=True)
class CreateApiKeyRequest:
    scope: ResourceRef
    role: Role
    name: str
    expires_at: datetime | None = None
    metadata: dict[str, Any] = field(default_factory=dict)


@dataclass(frozen=True, slots=True)
class UpdateApiKeyRequest:
    name: str | None = None
    expires_at: datetime | None = None
    metadata: dict[str, Any] | None = None


class ApiKey(Protocol):
    """A persisted API key (secret not included — only available once at creation)."""

    @property
    def id(self) -> UUID: ...
    @property
    def name(self) -> str: ...
    @property
    def prefix(self) -> str: ...
    @property
    def scope(self) -> ResourceRef: ...
    @property
    def role(self) -> Role: ...
    @property
    def organization_id(self) -> UUID: ...
    @property
    def project_id(self) -> UUID | None: ...
    @property
    def expires_at(self) -> datetime | None: ...
    @property
    def last_used_at(self) -> datetime | None: ...
    @property
    def revoked_at(self) -> datetime | None: ...
    @property
    def metadata(self) -> dict[str, Any]: ...
    @property
    def created_at(self) -> datetime: ...
    @property
    def updated_at(self) -> datetime: ...
    @property
    def created_by_subject(self) -> str: ...

    @property
    def is_active(self) -> bool: ...
    @property
    def actor(self) -> ActorRef: ...


@dataclass(frozen=True, slots=True)
class CreatedApiKey:
    """Return value from ``create`` — the persisted key plus its one-time-visible secret.

    The raw token (``sbk_<prefix>.<secret>``) is the ONLY moment a caller can obtain the full
    credential; it is not recoverable later.
    """

    api_key: ApiKey
    token: str


class ApiKeyApi(Protocol):
    def create(self, request: CreateApiKeyRequest) -> CreatedApiKey: ...

    def find_by_id(self, id: UUID) -> ApiKey | None: ...

    def list_by_scope(self, scope: ResourceRef) -> list[ApiKey]: ...

    def list_by_organization(self, organization_id: UUID) -> list[ApiKey]: ...

    def update(self, id: UUID, request: UpdateApiKeyRequest) -> ApiKey: ...

    def revoke(self, id: UUID) -> ApiKey: ...

    def delete(self, id: UUID) -> None: ...

    def authenticate(self, token: str) -> ApiKey | None:
        """Verify a token and return the matching active ApiKey.

        Returns ``None`` for any of: malformed token, unknown prefix, secret mismatch, revoked key,
        expired key. Updates ``last_used_at`` on success.
        """
