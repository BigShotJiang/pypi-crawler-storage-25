"""SaaSBase — Embedded Python SDK for multi-tenant SaaS products.

Quick start:

    from saasbase import SaaSBase

    sb = (SaaSBase.builder()
          .sqlite()
          .local_storage("./data")
          .build())

    with sb.as_user("alice") as ctx:
        org = ctx.organizations.create("acme")
        project = ctx.projects.create(org.id, "alpha")
"""

from __future__ import annotations

from datetime import timedelta

try:
    # _version.py is written at build time by hatch-vcs from the git tag; present in any installed
    # wheel/sdist and in editable installs.
    from saasbase._version import __version__, version  # type: ignore[import-not-found]
except ImportError:  # pragma: no cover — running from a source tree with no build yet
    try:
        from importlib.metadata import PackageNotFoundError, version as _pkg_version

        __version__ = _pkg_version("saasbase")
    except (ImportError, PackageNotFoundError):
        __version__ = "0.0.0+unknown"
    version = __version__

from saasbase.api.apicall import ApiCallCreateRequest, ApiCallUpdateRequest
from saasbase.api.apikey import (
    CreateApiKeyRequest,
    CreatedApiKey,
    UpdateApiKeyRequest,
)
from saasbase.api.authorization import (
    AuthorizationExplanation,
    AuthorizationExplanationSource,
    EffectiveAuthorizationRole,
)
from saasbase.api.document import (
    CreateDocumentVersionRequest,
    UpdateDocumentRequest,
    UploadDocumentRequest,
)
from saasbase.api.execution import (
    CompleteExecutionRequest,
    FailExecutionRequest,
    StartExecutionRequest,
)
from saasbase.api.organization import CreateOrganizationRequest, UpdateOrganizationRequest
from saasbase.api.project import CreateProjectRequest, UpdateProjectRequest
from saasbase.common.actor import ActorRef, ActorType
from saasbase.common.audit import AuditAction
from saasbase.common.authz import Action, AuthorizationPolicy, Role
from saasbase.common.exceptions import (
    ConflictError,
    NotFoundError,
    PermissionDeniedError,
    SaaSBaseError,
    ValidationError,
)
from saasbase.common.pagination import Page, PageRequest, SortDirection
from saasbase.common.query import (
    ApiCallQuery,
    AuditQuery,
    DocumentQuery,
    DocumentVersionQuery,
    ExecutionQuery,
    OrganizationQuery,
    ProjectQuery,
)
from saasbase.common.resource import ResourceRef, ResourceType
from saasbase.common.status import ApiCallStatus, ExecutionStatus
from saasbase.core.base import DefaultSaaSBase, DefaultSaaSBaseContext
from saasbase.core.builder import DefaultSaaSBaseBuilder


class SaaSBase(DefaultSaaSBase):
    """Public entry point. Use `SaaSBase.builder()` to construct a runtime."""

    @staticmethod
    def builder() -> DefaultSaaSBaseBuilder:
        return DefaultSaaSBaseBuilder()


# Keep `SaaSBaseContext` available as a public alias for type hints.
SaaSBaseContext = DefaultSaaSBaseContext

__all__ = [
    "Action",
    "ActorRef",
    "ActorType",
    "ApiCallCreateRequest",
    "ApiCallQuery",
    "ApiCallStatus",
    "ApiCallUpdateRequest",
    "AuditAction",
    "AuditQuery",
    "AuthorizationExplanation",
    "AuthorizationExplanationSource",
    "AuthorizationPolicy",
    "CompleteExecutionRequest",
    "ConflictError",
    "CreateApiKeyRequest",
    "CreateDocumentVersionRequest",
    "CreatedApiKey",
    "CreateOrganizationRequest",
    "CreateProjectRequest",
    "DocumentQuery",
    "DocumentVersionQuery",
    "EffectiveAuthorizationRole",
    "ExecutionQuery",
    "ExecutionStatus",
    "FailExecutionRequest",
    "NotFoundError",
    "OrganizationQuery",
    "Page",
    "PageRequest",
    "PermissionDeniedError",
    "ProjectQuery",
    "ResourceRef",
    "ResourceType",
    "Role",
    "SaaSBase",
    "SaaSBaseContext",
    "SaaSBaseError",
    "SortDirection",
    "StartExecutionRequest",
    "UpdateApiKeyRequest",
    "UpdateDocumentRequest",
    "UpdateOrganizationRequest",
    "UpdateProjectRequest",
    "UploadDocumentRequest",
    "ValidationError",
    "timedelta",
]
