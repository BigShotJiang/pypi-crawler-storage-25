from __future__ import annotations

from typing import Annotated
from uuid import UUID

from fastapi import APIRouter, Query, status
from fastapi.responses import Response

from saasbase.common.actor import ActorRef, ActorType
from saasbase.common.authz import Role
from saasbase.common.resource import ResourceRef, ResourceType
from saasbase.fastapi.deps import ContextDep, run_sync
from saasbase.fastapi.schemas import MembershipGrantRequest, MembershipResponse

router = APIRouter(prefix="/memberships", tags=["memberships"])


@router.post("", response_model=MembershipResponse, status_code=status.HTTP_201_CREATED)
async def grant(body: MembershipGrantRequest, ctx: ContextDep) -> MembershipResponse:
    resource = ResourceRef(body.resource_type, body.resource_id)
    actor = ActorRef(body.actor_type, body.actor_id)
    m = await run_sync(ctx.memberships.grant, resource, actor, body.role)
    return MembershipResponse.of(m)


@router.get("", response_model=list[MembershipResponse])
async def list_(
    ctx: ContextDep,
    resource_type: Annotated[ResourceType, Query()],
    resource_id: Annotated[UUID, Query()],
    effective: Annotated[bool, Query()] = False,
) -> list[MembershipResponse]:
    resource = ResourceRef(resource_type, resource_id)
    fn = ctx.memberships.list_effective if effective else ctx.memberships.list
    result = await run_sync(fn, resource)
    return [MembershipResponse.of(m) for m in result]


@router.delete("", status_code=status.HTTP_204_NO_CONTENT)
async def revoke(
    ctx: ContextDep,
    resource_type: Annotated[ResourceType, Query()],
    resource_id: Annotated[UUID, Query()],
    actor_type: Annotated[ActorType, Query()],
    actor_id: Annotated[str, Query()],
    role: Annotated[Role, Query()],
) -> Response:
    resource = ResourceRef(resource_type, resource_id)
    actor = ActorRef(actor_type, actor_id)
    await run_sync(ctx.memberships.revoke, resource, actor, role)
    return Response(status_code=status.HTTP_204_NO_CONTENT)
