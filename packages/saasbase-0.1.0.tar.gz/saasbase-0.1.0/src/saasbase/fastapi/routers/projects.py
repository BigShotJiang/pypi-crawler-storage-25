from __future__ import annotations

from typing import Annotated
from uuid import UUID

from fastapi import APIRouter, Depends, Query, status

from saasbase.api.project import CreateProjectRequest, UpdateProjectRequest
from saasbase.common.exceptions import NotFoundError
from saasbase.common.pagination import PageRequest
from saasbase.common.query import ProjectQuery
from saasbase.fastapi.deps import ContextDep, run_sync
from saasbase.fastapi.routers._page import to_page_request
from saasbase.fastapi.schemas import (
    PageEnvelope,
    ProjectCreateRequest,
    ProjectResponse,
    ProjectUpdateRequest,
)

router = APIRouter(prefix="/projects", tags=["projects"])

PageRequestDep = Annotated[PageRequest, Depends(to_page_request)]


@router.post("", response_model=ProjectResponse, status_code=status.HTTP_201_CREATED)
async def create(body: ProjectCreateRequest, ctx: ContextDep) -> ProjectResponse:
    req = CreateProjectRequest(
        organization_id=body.organization_id, name=body.name, metadata=body.metadata or {}
    )
    project = await run_sync(ctx.projects.create_from, req)
    return ProjectResponse.of(project)


@router.get("", response_model=PageEnvelope[ProjectResponse])
async def query(
    ctx: ContextDep,
    page_request: PageRequestDep,
    organization_id: Annotated[UUID | None, Query()] = None,
    name_contains: Annotated[str | None, Query()] = None,
) -> PageEnvelope[ProjectResponse]:
    q = ProjectQuery.all().with_organization_id(organization_id).with_name_contains(name_contains)
    page = await run_sync(ctx.projects.query, q, page_request)
    return PageEnvelope(
        items=[ProjectResponse.of(e) for e in page.items],
        total_items=page.total_items,
        page=page.page,
        size=page.size,
        total_pages=page.total_pages,
        has_next=page.has_next,
        has_previous=page.has_previous,
    )


@router.get("/by-organization/{organization_id}", response_model=list[ProjectResponse])
async def list_by_organization(
    organization_id: UUID, ctx: ContextDep
) -> list[ProjectResponse]:
    projects = await run_sync(ctx.projects.list_by_organization, organization_id)
    return [ProjectResponse.of(p) for p in projects]


@router.get("/{id}", response_model=ProjectResponse)
async def find_by_id(id: UUID, ctx: ContextDep) -> ProjectResponse:
    project = await run_sync(ctx.projects.find_by_id, id)
    if project is None:
        raise NotFoundError(f"Project not found: {id}")
    return ProjectResponse.of(project)


@router.patch("/{id}", response_model=ProjectResponse)
async def update(id: UUID, body: ProjectUpdateRequest, ctx: ContextDep) -> ProjectResponse:
    req = UpdateProjectRequest(name=body.name, metadata=body.metadata)
    project = await run_sync(ctx.projects.update, id, req)
    return ProjectResponse.of(project)


@router.delete("/{id}", status_code=status.HTTP_204_NO_CONTENT)
async def delete(id: UUID, ctx: ContextDep) -> None:
    await run_sync(ctx.projects.delete, id)
