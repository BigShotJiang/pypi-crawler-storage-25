from __future__ import annotations

from typing import Annotated
from uuid import UUID

from fastapi import APIRouter, Query

from saasbase.common.actor import ActorRef, ActorType
from saasbase.common.authz import Action
from saasbase.common.resource import ResourceRef, ResourceType
from saasbase.fastapi.deps import ContextDep, run_sync
from saasbase.fastapi.schemas import (
    ActorRefModel,
    AuthorizationCheckQuery,
    AuthorizationCheckResponse,
    AuthorizationExplanationResponse,
    EffectiveRoleResponse,
)

router = APIRouter(prefix="/authz", tags=["authorization"])


@router.post("/check", response_model=AuthorizationCheckResponse)
async def check(
    body: AuthorizationCheckQuery, ctx: ContextDep
) -> AuthorizationCheckResponse:
    actor = ActorRef(body.actor_type, body.actor_id)
    resource = ResourceRef(body.resource_type, body.resource_id)
    allowed = await run_sync(ctx.authorization.can, actor, body.action, resource)
    return AuthorizationCheckResponse(allowed=allowed)


@router.post("/explain", response_model=AuthorizationExplanationResponse)
async def explain(
    body: AuthorizationCheckQuery, ctx: ContextDep
) -> AuthorizationExplanationResponse:
    actor = ActorRef(body.actor_type, body.actor_id)
    resource = ResourceRef(body.resource_type, body.resource_id)
    explanation = await run_sync(ctx.authorization.explain, actor, body.action, resource)
    return AuthorizationExplanationResponse.of(explanation)


@router.get("/effective-roles", response_model=list[EffectiveRoleResponse])
async def effective_roles(
    ctx: ContextDep,
    actor_type: Annotated[ActorType, Query()],
    actor_id: Annotated[str, Query()],
    resource_type: Annotated[ResourceType, Query()],
    resource_id: Annotated[UUID, Query()],
) -> list[EffectiveRoleResponse]:
    actor = ActorRef(actor_type, actor_id)
    resource = ResourceRef(resource_type, resource_id)
    roles = await run_sync(ctx.authorization.effective_roles, actor, resource)
    return [EffectiveRoleResponse.of(r) for r in roles]


@router.get("/who-can", response_model=list[ActorRefModel])
async def who_can(
    ctx: ContextDep,
    action: Annotated[Action, Query()],
    resource_type: Annotated[ResourceType, Query()],
    resource_id: Annotated[UUID, Query()],
) -> list[ActorRefModel]:
    actors = await run_sync(
        ctx.authorization.who_can, action, ResourceRef(resource_type, resource_id)
    )
    return [ActorRefModel.of(a) for a in actors]


@router.get("/who-can-explain", response_model=list[AuthorizationExplanationResponse])
async def who_can_explain(
    ctx: ContextDep,
    action: Annotated[Action, Query()],
    resource_type: Annotated[ResourceType, Query()],
    resource_id: Annotated[UUID, Query()],
) -> list[AuthorizationExplanationResponse]:
    explanations = await run_sync(
        ctx.authorization.who_can_explain, action, ResourceRef(resource_type, resource_id)
    )
    return [AuthorizationExplanationResponse.of(e) for e in explanations]
