from __future__ import annotations

from datetime import datetime
from typing import Annotated
from uuid import UUID

from fastapi import APIRouter, Depends, Query

from saasbase.common.actor import ActorRef, ActorType
from saasbase.common.audit import AuditAction
from saasbase.common.pagination import PageRequest
from saasbase.common.query import AuditQuery
from saasbase.common.resource import ResourceRef, ResourceType
from saasbase.fastapi.deps import ContextDep, run_sync
from saasbase.fastapi.routers._page import to_page_request
from saasbase.fastapi.schemas import AuditEventResponse, PageEnvelope

router = APIRouter(prefix="/audit-events", tags=["audit"])

PageRequestDep = Annotated[PageRequest, Depends(to_page_request)]


def _build_query(
    organization_id: UUID | None,
    project_id: UUID | None,
    action: AuditAction | None,
    actor_type: ActorType | None,
    actor_id: str | None,
    resource_type: ResourceType | None,
    correlation_id: str | None,
    occurred_from: datetime | None,
    occurred_to: datetime | None,
) -> AuditQuery:
    q = (
        AuditQuery.all()
        .with_organization_id(organization_id)
        .with_project_id(project_id)
        .with_action(action)
        .with_resource_type(resource_type)
        .with_correlation_id(correlation_id)
        .with_occurred_from(occurred_from)
        .with_occurred_to(occurred_to)
    )
    if actor_type and actor_id:
        q = q.with_actor(ActorRef(actor_type, actor_id))
    return q


@router.get("", response_model=PageEnvelope[AuditEventResponse])
async def query(
    ctx: ContextDep,
    page_request: PageRequestDep,
    organization_id: Annotated[UUID | None, Query()] = None,
    project_id: Annotated[UUID | None, Query()] = None,
    action: Annotated[AuditAction | None, Query()] = None,
    actor_type: Annotated[ActorType | None, Query()] = None,
    actor_id: Annotated[str | None, Query()] = None,
    resource_type: Annotated[ResourceType | None, Query()] = None,
    correlation_id: Annotated[str | None, Query()] = None,
    occurred_from: Annotated[datetime | None, Query()] = None,
    occurred_to: Annotated[datetime | None, Query()] = None,
) -> PageEnvelope[AuditEventResponse]:
    q = _build_query(
        organization_id, project_id, action, actor_type, actor_id,
        resource_type, correlation_id, occurred_from, occurred_to,
    )
    page = await run_sync(ctx.audits.query, q, page_request)
    return PageEnvelope(
        items=[AuditEventResponse.of(e) for e in page.items],
        total_items=page.total_items,
        page=page.page,
        size=page.size,
        total_pages=page.total_pages,
        has_next=page.has_next,
        has_previous=page.has_previous,
    )


@router.get("/by-resource", response_model=list[AuditEventResponse])
async def list_by_resource(
    ctx: ContextDep,
    resource_type: Annotated[ResourceType, Query()],
    resource_id: Annotated[UUID, Query()],
) -> list[AuditEventResponse]:
    events = await run_sync(ctx.audits.list, ResourceRef(resource_type, resource_id))
    return [AuditEventResponse.of(e) for e in events]


@router.get("/by-correlation/{correlation_id}", response_model=list[AuditEventResponse])
async def list_by_correlation(
    correlation_id: str, ctx: ContextDep
) -> list[AuditEventResponse]:
    events = await run_sync(ctx.audits.list_by_correlation_id, correlation_id)
    return [AuditEventResponse.of(e) for e in events]


@router.delete("")
async def prune(
    ctx: ContextDep,
    occurred_to: Annotated[datetime | None, Query()] = None,
    action: Annotated[AuditAction | None, Query()] = None,
    organization_id: Annotated[UUID | None, Query()] = None,
    project_id: Annotated[UUID | None, Query()] = None,
) -> dict[str, int]:
    q = _build_query(organization_id, project_id, action, None, None, None, None, None, occurred_to)
    pruned = await run_sync(ctx.audits.prune, q)
    return {"pruned": pruned}
