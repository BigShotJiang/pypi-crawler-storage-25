"""Shared page-parameter dependency for paginated list endpoints."""

from __future__ import annotations

from typing import Annotated

from fastapi import Query

from saasbase.common.pagination import PageRequest, SortDirection


def to_page_request(
    page: Annotated[int, Query(ge=0)] = 0,
    size: Annotated[int, Query(ge=1, le=500)] = 20,
    sort: Annotated[str | None, Query()] = None,
    direction: Annotated[str | None, Query()] = None,
) -> PageRequest:
    pr = PageRequest.of(page, size)
    if sort:
        try:
            dir_enum = SortDirection[direction.upper()] if direction else SortDirection.ASC
        except KeyError:
            dir_enum = SortDirection.ASC
        pr = pr.with_sort(sort, dir_enum)
    return pr
