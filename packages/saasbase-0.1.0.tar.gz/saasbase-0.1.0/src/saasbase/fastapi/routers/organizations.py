from __future__ import annotations

from typing import Annotated
from uuid import UUID

from fastapi import APIRouter, Depends, Query, status

from saasbase.api.organization import CreateOrganizationRequest, UpdateOrganizationRequest
from saasbase.common.exceptions import NotFoundError
from saasbase.common.pagination import PageRequest
from saasbase.common.query import OrganizationQuery
from saasbase.fastapi.deps import ContextDep, run_sync
from saasbase.fastapi.routers._page import to_page_request
from saasbase.fastapi.schemas import (
    OrganizationCreateRequest,
    OrganizationResponse,
    OrganizationUpdateRequest,
    PageEnvelope,
)

router = APIRouter(prefix="/organizations", tags=["organizations"])

PageRequestDep = Annotated[PageRequest, Depends(to_page_request)]


@router.post("", response_model=OrganizationResponse, status_code=status.HTTP_201_CREATED)
async def create(body: OrganizationCreateRequest, ctx: ContextDep) -> OrganizationResponse:
    req = CreateOrganizationRequest(
        slug=body.slug, name=body.name or body.slug, metadata=body.metadata or {}
    )
    org = await run_sync(ctx.organizations.create_from, req)
    return OrganizationResponse.of(org)


@router.get("", response_model=PageEnvelope[OrganizationResponse])
async def query(
    ctx: ContextDep,
    page_request: PageRequestDep,
    slug: Annotated[str | None, Query()] = None,
    name_contains: Annotated[str | None, Query()] = None,
) -> PageEnvelope[OrganizationResponse]:
    q = OrganizationQuery.all().with_slug_contains(slug).with_name_contains(name_contains)
    page = await run_sync(ctx.organizations.query, q, page_request)
    return PageEnvelope(
        items=[OrganizationResponse.of(e) for e in page.items],
        total_items=page.total_items,
        page=page.page,
        size=page.size,
        total_pages=page.total_pages,
        has_next=page.has_next,
        has_previous=page.has_previous,
    )


@router.get("/all", response_model=list[OrganizationResponse])
async def list_all(ctx: ContextDep) -> list[OrganizationResponse]:
    orgs = await run_sync(ctx.organizations.list)
    return [OrganizationResponse.of(o) for o in orgs]


@router.get("/by-slug/{slug}", response_model=OrganizationResponse)
async def find_by_slug(slug: str, ctx: ContextDep) -> OrganizationResponse:
    org = await run_sync(ctx.organizations.find_by_slug, slug)
    if org is None:
        raise NotFoundError(f"Organization not found: {slug}")
    return OrganizationResponse.of(org)


@router.get("/{id}", response_model=OrganizationResponse)
async def find_by_id(id: UUID, ctx: ContextDep) -> OrganizationResponse:
    org = await run_sync(ctx.organizations.find_by_id, id)
    if org is None:
        raise NotFoundError(f"Organization not found: {id}")
    return OrganizationResponse.of(org)


@router.patch("/{id}", response_model=OrganizationResponse)
async def update(
    id: UUID, body: OrganizationUpdateRequest, ctx: ContextDep
) -> OrganizationResponse:
    req = UpdateOrganizationRequest(name=body.name, metadata=body.metadata)
    org = await run_sync(ctx.organizations.update, id, req)
    return OrganizationResponse.of(org)


@router.delete("/{id}", status_code=status.HTTP_204_NO_CONTENT)
async def delete(id: UUID, ctx: ContextDep) -> None:
    await run_sync(ctx.organizations.delete, id)
