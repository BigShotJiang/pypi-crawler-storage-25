"""FastAPI routers — one per SaaSBase domain API."""
