from __future__ import annotations

from typing import Annotated
from uuid import UUID

from fastapi import APIRouter, Depends, Query, status

from saasbase.api.apicall import ApiCallCreateRequest as SdkCreateReq
from saasbase.api.apicall import ApiCallUpdateRequest as SdkUpdateReq
from saasbase.common.exceptions import NotFoundError
from saasbase.common.pagination import PageRequest
from saasbase.common.query import ApiCallQuery
from saasbase.common.status import ApiCallStatus
from saasbase.fastapi.deps import ContextDep, run_sync
from saasbase.fastapi.routers._page import to_page_request
from saasbase.fastapi.schemas import (
    ApiCallCreateRequest,
    ApiCallResponse,
    ApiCallUpdateRequest,
    PageEnvelope,
)

router = APIRouter(tags=["api-calls"])

PageRequestDep = Annotated[PageRequest, Depends(to_page_request)]


@router.post(
    "/projects/{project_id}/api-calls",
    response_model=ApiCallResponse,
    status_code=status.HTTP_201_CREATED,
)
async def create(
    project_id: UUID, body: ApiCallCreateRequest, ctx: ContextDep
) -> ApiCallResponse:
    req = SdkCreateReq(
        name=body.name,
        operation_key=body.operation_key,
        external_request_id=body.external_request_id,
        idempotency_key=body.idempotency_key,
        correlation_id=body.correlation_id,
        request_payload=body.request_payload or {},
        metadata=body.metadata or {},
    )
    call = await run_sync(ctx.api_calls.create, project_id, req)
    return ApiCallResponse.of(call)


@router.get("/api-calls", response_model=PageEnvelope[ApiCallResponse])
async def query(
    ctx: ContextDep,
    page_request: PageRequestDep,
    organization_id: Annotated[UUID | None, Query()] = None,
    project_id: Annotated[UUID | None, Query()] = None,
    status_filter: Annotated[ApiCallStatus | None, Query(alias="status")] = None,
    operation_key: Annotated[str | None, Query()] = None,
    external_request_id: Annotated[str | None, Query()] = None,
    idempotency_key: Annotated[str | None, Query()] = None,
    correlation_id: Annotated[str | None, Query()] = None,
) -> PageEnvelope[ApiCallResponse]:
    q = (
        ApiCallQuery.all()
        .with_organization_id(organization_id)
        .with_project_id(project_id)
        .with_status(status_filter)
        .with_operation_key(operation_key)
        .with_external_request_id(external_request_id)
        .with_idempotency_key(idempotency_key)
        .with_correlation_id(correlation_id)
    )
    page = await run_sync(ctx.api_calls.query, q, page_request)
    return PageEnvelope(
        items=[ApiCallResponse.of(e) for e in page.items],
        total_items=page.total_items,
        page=page.page,
        size=page.size,
        total_pages=page.total_pages,
        has_next=page.has_next,
        has_previous=page.has_previous,
    )


@router.get("/projects/{project_id}/api-calls", response_model=list[ApiCallResponse])
async def list_by_project(project_id: UUID, ctx: ContextDep) -> list[ApiCallResponse]:
    calls = await run_sync(ctx.api_calls.list_by_project, project_id)
    return [ApiCallResponse.of(c) for c in calls]


@router.get("/api-calls/by-correlation/{correlation_id}", response_model=list[ApiCallResponse])
async def list_by_correlation(
    correlation_id: str, ctx: ContextDep
) -> list[ApiCallResponse]:
    calls = await run_sync(ctx.api_calls.list_by_correlation_id, correlation_id)
    return [ApiCallResponse.of(c) for c in calls]


@router.get("/api-calls/{id}", response_model=ApiCallResponse)
async def find_by_id(id: UUID, ctx: ContextDep) -> ApiCallResponse:
    call = await run_sync(ctx.api_calls.find_by_id, id)
    if call is None:
        raise NotFoundError(f"ApiCall not found: {id}")
    return ApiCallResponse.of(call)


@router.patch("/api-calls/{id}", response_model=ApiCallResponse)
async def update(
    id: UUID, body: ApiCallUpdateRequest, ctx: ContextDep
) -> ApiCallResponse:
    req = SdkUpdateReq(
        status=body.status,
        response_payload=body.response_payload,
        metadata=body.metadata,
    )
    call = await run_sync(ctx.api_calls.update, id, req)
    return ApiCallResponse.of(call)


@router.delete("/api-calls/{id}", status_code=status.HTTP_204_NO_CONTENT)
async def delete(id: UUID, ctx: ContextDep) -> None:
    await run_sync(ctx.api_calls.delete, id)
