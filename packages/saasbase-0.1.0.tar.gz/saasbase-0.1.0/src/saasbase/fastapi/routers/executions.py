from __future__ import annotations

from typing import Annotated
from uuid import UUID

from fastapi import APIRouter, Depends, Query, status

from saasbase.api.execution import (
    CompleteExecutionRequest,
    FailExecutionRequest,
    StartExecutionRequest,
)
from saasbase.common.exceptions import NotFoundError
from saasbase.common.pagination import PageRequest
from saasbase.common.query import ExecutionQuery
from saasbase.common.resource import ResourceRef, ResourceType
from saasbase.common.status import ExecutionStatus
from saasbase.fastapi.deps import ContextDep, run_sync
from saasbase.fastapi.routers._page import to_page_request
from saasbase.fastapi.schemas import (
    ExecutionCompleteRequest,
    ExecutionFailRequest,
    ExecutionResponse,
    ExecutionStartRequest,
    PageEnvelope,
)

router = APIRouter(prefix="/executions", tags=["executions"])

PageRequestDep = Annotated[PageRequest, Depends(to_page_request)]


@router.post("", response_model=ExecutionResponse, status_code=status.HTTP_201_CREATED)
async def start(body: ExecutionStartRequest, ctx: ContextDep) -> ExecutionResponse:
    target: ResourceRef | None = None
    if body.target_type is not None and body.target_id is not None:
        target = ResourceRef(body.target_type, body.target_id)
    req = StartExecutionRequest(
        organization_id=body.organization_id,
        project_id=body.project_id,
        operation=body.operation,
        target=target,
        correlation_id=body.correlation_id,
        parent_execution_id=body.parent_execution_id,
        agent_version=body.agent_version,
        model_provider=body.model_provider,
        model_name=body.model_name,
        confidence=body.confidence,
        warnings=list(body.warnings or []),
        provenance=body.provenance or {},
        input=body.input or {},
        metadata=body.metadata or {},
    )
    ex = await run_sync(ctx.executions.start, req)
    return ExecutionResponse.of(ex)


@router.post("/{id}/complete", response_model=ExecutionResponse)
async def complete(
    id: UUID, body: ExecutionCompleteRequest, ctx: ContextDep
) -> ExecutionResponse:
    req = CompleteExecutionRequest(output=body.output or {}, metadata=body.metadata)
    ex = await run_sync(ctx.executions.complete, id, req)
    return ExecutionResponse.of(ex)


@router.post("/{id}/fail", response_model=ExecutionResponse)
async def fail(
    id: UUID, body: ExecutionFailRequest, ctx: ContextDep
) -> ExecutionResponse:
    req = FailExecutionRequest(
        error_code=body.error_code, error_message=body.error_message, metadata=body.metadata
    )
    ex = await run_sync(ctx.executions.fail, id, req)
    return ExecutionResponse.of(ex)


@router.get("", response_model=PageEnvelope[ExecutionResponse])
async def query(
    ctx: ContextDep,
    page_request: PageRequestDep,
    organization_id: Annotated[UUID | None, Query()] = None,
    project_id: Annotated[UUID | None, Query()] = None,
    status_filter: Annotated[ExecutionStatus | None, Query(alias="status")] = None,
    target_resource_type: Annotated[ResourceType | None, Query()] = None,
    correlation_id: Annotated[str | None, Query()] = None,
    parent_execution_id: Annotated[UUID | None, Query()] = None,
    operation: Annotated[str | None, Query()] = None,
    model_provider: Annotated[str | None, Query()] = None,
    model_name: Annotated[str | None, Query()] = None,
) -> PageEnvelope[ExecutionResponse]:
    q = (
        ExecutionQuery.all()
        .with_organization_id(organization_id)
        .with_project_id(project_id)
        .with_status(status_filter)
        .with_target_resource_type(target_resource_type)
        .with_correlation_id(correlation_id)
        .with_parent_execution_id(parent_execution_id)
        .with_operation(operation)
        .with_model_provider(model_provider)
        .with_model_name(model_name)
    )
    page = await run_sync(ctx.executions.query, q, page_request)
    return PageEnvelope(
        items=[ExecutionResponse.of(e) for e in page.items],
        total_items=page.total_items,
        page=page.page,
        size=page.size,
        total_pages=page.total_pages,
        has_next=page.has_next,
        has_previous=page.has_previous,
    )


@router.get("/{id}", response_model=ExecutionResponse)
async def find_by_id(id: UUID, ctx: ContextDep) -> ExecutionResponse:
    ex = await run_sync(ctx.executions.find_by_id, id)
    if ex is None:
        raise NotFoundError(f"Execution not found: {id}")
    return ExecutionResponse.of(ex)


@router.get("/by-project/{project_id}", response_model=list[ExecutionResponse])
async def list_by_project(project_id: UUID, ctx: ContextDep) -> list[ExecutionResponse]:
    ex = await run_sync(ctx.executions.list_by_project, project_id)
    return [ExecutionResponse.of(e) for e in ex]


@router.get("/by-correlation/{correlation_id}", response_model=list[ExecutionResponse])
async def list_by_correlation(
    correlation_id: str, ctx: ContextDep
) -> list[ExecutionResponse]:
    ex = await run_sync(ctx.executions.list_by_correlation_id, correlation_id)
    return [ExecutionResponse.of(e) for e in ex]


@router.get("/{id}/children", response_model=list[ExecutionResponse])
async def list_children(id: UUID, ctx: ContextDep) -> list[ExecutionResponse]:
    ex = await run_sync(ctx.executions.list_children, id)
    return [ExecutionResponse.of(e) for e in ex]
