from __future__ import annotations

from typing import Annotated
from uuid import UUID

from fastapi import APIRouter, Query, status
from fastapi.responses import Response

from saasbase.api.apikey import CreateApiKeyRequest, UpdateApiKeyRequest
from saasbase.common.exceptions import NotFoundError
from saasbase.common.resource import ResourceRef, ResourceType
from saasbase.fastapi.deps import ContextDep, run_sync
from saasbase.fastapi.schemas import (
    ApiKeyCreatedResponse,
    ApiKeyCreateRequest,
    ApiKeyResponse,
    ApiKeyUpdateRequest,
)

router = APIRouter(prefix="/api-keys", tags=["api-keys"])


@router.post("", response_model=ApiKeyCreatedResponse, status_code=status.HTTP_201_CREATED)
async def create(body: ApiKeyCreateRequest, ctx: ContextDep) -> ApiKeyCreatedResponse:
    scope = ResourceRef(body.scope_type, body.scope_id)
    request = CreateApiKeyRequest(
        scope=scope,
        role=body.role,
        name=body.name,
        expires_at=body.expires_at,
        metadata=body.metadata or {},
    )
    created = await run_sync(ctx.api_keys.create, request)
    return ApiKeyCreatedResponse(
        api_key=ApiKeyResponse.of(created.api_key),
        token=created.token,
    )


@router.get("", response_model=list[ApiKeyResponse])
async def list_(
    ctx: ContextDep,
    organization_id: Annotated[UUID | None, Query()] = None,
    scope_type: Annotated[ResourceType | None, Query()] = None,
    scope_id: Annotated[UUID | None, Query()] = None,
) -> list[ApiKeyResponse]:
    if scope_type is not None and scope_id is not None:
        keys = await run_sync(ctx.api_keys.list_by_scope, ResourceRef(scope_type, scope_id))
    elif organization_id is not None:
        keys = await run_sync(ctx.api_keys.list_by_organization, organization_id)
    else:
        raise ValueError("Supply either organization_id, or both scope_type and scope_id")
    return [ApiKeyResponse.of(k) for k in keys]


@router.get("/{id}", response_model=ApiKeyResponse)
async def find_by_id(id: UUID, ctx: ContextDep) -> ApiKeyResponse:
    key = await run_sync(ctx.api_keys.find_by_id, id)
    if key is None:
        raise NotFoundError(f"ApiKey not found: {id}")
    return ApiKeyResponse.of(key)


@router.patch("/{id}", response_model=ApiKeyResponse)
async def update(id: UUID, body: ApiKeyUpdateRequest, ctx: ContextDep) -> ApiKeyResponse:
    request = UpdateApiKeyRequest(
        name=body.name, expires_at=body.expires_at, metadata=body.metadata
    )
    key = await run_sync(ctx.api_keys.update, id, request)
    return ApiKeyResponse.of(key)


@router.post("/{id}/revoke", response_model=ApiKeyResponse)
async def revoke(id: UUID, ctx: ContextDep) -> ApiKeyResponse:
    key = await run_sync(ctx.api_keys.revoke, id)
    return ApiKeyResponse.of(key)


@router.delete("/{id}", status_code=status.HTTP_204_NO_CONTENT)
async def delete(id: UUID, ctx: ContextDep) -> Response:
    await run_sync(ctx.api_keys.delete, id)
    return Response(status_code=status.HTTP_204_NO_CONTENT)
