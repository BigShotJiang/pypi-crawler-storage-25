from __future__ import annotations

import io
from typing import Annotated
from uuid import UUID

from fastapi import APIRouter, Depends, File, Form, Query, UploadFile, status
from fastapi.responses import StreamingResponse

from saasbase.api.document import (
    CreateDocumentVersionRequest,
    UpdateDocumentRequest,
    UploadDocumentRequest,
)
from saasbase.common.exceptions import NotFoundError, ValidationError
from saasbase.common.pagination import PageRequest
from saasbase.common.query import DocumentQuery, DocumentVersionQuery
from saasbase.fastapi.deps import ContextDep, run_sync
from saasbase.fastapi.routers._page import to_page_request
from saasbase.fastapi.schemas import (
    DocumentResponse,
    DocumentUpdateRequest,
    DocumentVersionResponse,
    PageEnvelope,
)

router = APIRouter(tags=["documents"])

PageRequestDep = Annotated[PageRequest, Depends(to_page_request)]


@router.post(
    "/projects/{project_id}/documents",
    response_model=DocumentResponse,
    status_code=status.HTTP_201_CREATED,
)
async def upload(
    project_id: UUID,
    ctx: ContextDep,
    file: Annotated[UploadFile, File()],
    name: Annotated[str | None, Form()] = None,
    version_name: Annotated[str | None, Form()] = None,
    media_type: Annotated[str | None, Form()] = None,
) -> DocumentResponse:
    if file is None or file.size == 0:
        raise ValidationError("file multipart part is required")
    content_bytes = await file.read()
    effective_name = name or file.filename or "document"
    effective_type = media_type or file.content_type or "application/octet-stream"
    req = UploadDocumentRequest(
        project_id=project_id,
        name=effective_name,
        content=io.BytesIO(content_bytes),
        media_type=effective_type,
        version_name=version_name,
        metadata={},
    )
    doc = await run_sync(ctx.documents.upload_from, req)
    return DocumentResponse.of(doc)


@router.post(
    "/documents/{id}/versions",
    response_model=DocumentResponse,
    status_code=status.HTTP_201_CREATED,
)
async def create_version(
    id: UUID,
    ctx: ContextDep,
    file: Annotated[UploadFile, File()],
    version_name: Annotated[str, Form()],
    name: Annotated[str | None, Form()] = None,
    media_type: Annotated[str | None, Form()] = None,
) -> DocumentResponse:
    if file is None or file.size == 0:
        raise ValidationError("file multipart part is required")
    content_bytes = await file.read()
    effective_name = name or file.filename or "document"
    effective_type = media_type or file.content_type or "application/octet-stream"
    req = CreateDocumentVersionRequest(
        content=io.BytesIO(content_bytes),
        media_type=effective_type,
        version_name=version_name,
        name=effective_name,
        metadata={},
    )
    doc = await run_sync(ctx.documents.create_version, id, req)
    return DocumentResponse.of(doc)


@router.get("/documents", response_model=PageEnvelope[DocumentResponse])
async def query(
    ctx: ContextDep,
    page_request: PageRequestDep,
    organization_id: Annotated[UUID | None, Query()] = None,
    project_id: Annotated[UUID | None, Query()] = None,
    name_contains: Annotated[str | None, Query()] = None,
    media_type: Annotated[str | None, Query()] = None,
) -> PageEnvelope[DocumentResponse]:
    q = (
        DocumentQuery.all()
        .with_organization_id(organization_id)
        .with_project_id(project_id)
        .with_name_contains(name_contains)
        .with_media_type(media_type)
    )
    page = await run_sync(ctx.documents.query, q, page_request)
    return PageEnvelope(
        items=[DocumentResponse.of(e) for e in page.items],
        total_items=page.total_items,
        page=page.page,
        size=page.size,
        total_pages=page.total_pages,
        has_next=page.has_next,
        has_previous=page.has_previous,
    )


@router.get("/documents/{id}", response_model=DocumentResponse)
async def find_by_id(id: UUID, ctx: ContextDep) -> DocumentResponse:
    doc = await run_sync(ctx.documents.find_by_id, id)
    if doc is None:
        raise NotFoundError(f"Document not found: {id}")
    return DocumentResponse.of(doc)


@router.get("/projects/{project_id}/documents", response_model=list[DocumentResponse])
async def list_by_project(project_id: UUID, ctx: ContextDep) -> list[DocumentResponse]:
    docs = await run_sync(ctx.documents.list_by_project, project_id)
    return [DocumentResponse.of(d) for d in docs]


@router.get("/documents/{id}/content")
async def download(id: UUID, ctx: ContextDep) -> StreamingResponse:
    doc = await run_sync(ctx.documents.find_by_id, id)
    if doc is None:
        raise NotFoundError(f"Document not found: {id}")

    def _iter():
        with doc.open_stream() as stream:
            while True:
                chunk = stream.read(64 * 1024)
                if not chunk:
                    break
                yield chunk

    return StreamingResponse(
        _iter(),
        media_type=doc.media_type,
        headers={
            "Content-Length": str(doc.size_bytes),
            "Content-Disposition": f'attachment; filename="{doc.name}"',
        },
    )


@router.get("/documents/{id}/versions", response_model=list[DocumentVersionResponse])
async def list_versions(id: UUID, ctx: ContextDep) -> list[DocumentVersionResponse]:
    versions = await run_sync(ctx.documents.list_versions, id)
    return [DocumentVersionResponse.of(v) for v in versions]


@router.get(
    "/documents/{id}/versions/{version_name}", response_model=DocumentVersionResponse
)
async def find_version(
    id: UUID, version_name: str, ctx: ContextDep
) -> DocumentVersionResponse:
    version = await run_sync(ctx.documents.find_version, id, version_name)
    if version is None:
        raise NotFoundError(f"Document version not found: {id} @ {version_name}")
    return DocumentVersionResponse.of(version)


@router.get("/document-versions", response_model=PageEnvelope[DocumentVersionResponse])
async def query_versions(
    ctx: ContextDep,
    page_request: PageRequestDep,
    organization_id: Annotated[UUID | None, Query()] = None,
    project_id: Annotated[UUID | None, Query()] = None,
    document_id: Annotated[UUID | None, Query()] = None,
    version_name: Annotated[str | None, Query()] = None,
    name_contains: Annotated[str | None, Query()] = None,
) -> PageEnvelope[DocumentVersionResponse]:
    q = (
        DocumentVersionQuery.all()
        .with_organization_id(organization_id)
        .with_project_id(project_id)
        .with_document_id(document_id)
        .with_version_name(version_name)
        .with_name_contains(name_contains)
    )
    page = await run_sync(ctx.documents.query_versions, q, page_request)
    return PageEnvelope(
        items=[DocumentVersionResponse.of(e) for e in page.items],
        total_items=page.total_items,
        page=page.page,
        size=page.size,
        total_pages=page.total_pages,
        has_next=page.has_next,
        has_previous=page.has_previous,
    )


@router.patch("/documents/{id}", response_model=DocumentResponse)
async def update(id: UUID, body: DocumentUpdateRequest, ctx: ContextDep) -> DocumentResponse:
    req = UpdateDocumentRequest(name=body.name, metadata=body.metadata)
    doc = await run_sync(ctx.documents.update, id, req)
    return DocumentResponse.of(doc)


@router.delete("/documents/{id}", status_code=status.HTTP_204_NO_CONTENT)
async def delete(id: UUID, ctx: ContextDep) -> None:
    await run_sync(ctx.documents.delete, id)
