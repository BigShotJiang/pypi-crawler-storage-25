"""Pydantic models — request bodies, response payloads, and the generic paged response envelope."""

from __future__ import annotations

from datetime import datetime
from typing import Any, Generic, TypeVar
from uuid import UUID

from pydantic import BaseModel, Field

from saasbase.common.actor import ActorRef, ActorType
from saasbase.common.audit import AuditAction
from saasbase.common.authz import Action, Role
from saasbase.common.pagination import Page
from saasbase.common.resource import ResourceRef, ResourceType
from saasbase.common.status import ApiCallStatus, ExecutionStatus

T = TypeVar("T")


class ActorRefModel(BaseModel):
    type: ActorType
    id: str

    @staticmethod
    def of(ref: ActorRef) -> ActorRefModel:
        return ActorRefModel(type=ref.type, id=ref.id)

    def to_ref(self) -> ActorRef:
        return ActorRef(self.type, self.id)


class ResourceRefModel(BaseModel):
    type: ResourceType
    id: UUID

    @staticmethod
    def of(ref: ResourceRef) -> ResourceRefModel:
        return ResourceRefModel(type=ref.type, id=ref.id)

    def to_ref(self) -> ResourceRef:
        return ResourceRef(self.type, self.id)


class PageEnvelope(BaseModel, Generic[T]):
    items: list[T]
    total_items: int
    page: int
    size: int
    total_pages: int
    has_next: bool
    has_previous: bool

    @staticmethod
    def from_page(page: Page[Any], item_model: type[BaseModel]) -> PageEnvelope[Any]:
        mapped = [item_model.model_validate(_as_dict(e)) for e in page.items]
        return PageEnvelope(
            items=mapped,
            total_items=page.total_items,
            page=page.page,
            size=page.size,
            total_pages=page.total_pages,
            has_next=page.has_next,
            has_previous=page.has_previous,
        )


def _as_dict(entity: Any) -> Any:
    """Entity protocols don't support ``model_validate`` directly — convert to a dict first."""
    if isinstance(entity, BaseModel):
        return entity
    if isinstance(entity, dict):
        return entity
    return entity


# ----- Organization -----


class OrganizationCreateRequest(BaseModel):
    slug: str = Field(min_length=1)
    name: str | None = None
    metadata: dict[str, Any] = Field(default_factory=dict)


class OrganizationUpdateRequest(BaseModel):
    name: str | None = None
    metadata: dict[str, Any] | None = None


class OrganizationResponse(BaseModel):
    id: UUID
    slug: str
    name: str
    metadata: dict[str, Any]

    @staticmethod
    def of(org: Any) -> OrganizationResponse:
        return OrganizationResponse(id=org.id, slug=org.slug, name=org.name, metadata=dict(org.metadata))


# ----- Project -----


class ProjectCreateRequest(BaseModel):
    organization_id: UUID
    name: str = Field(min_length=1)
    metadata: dict[str, Any] = Field(default_factory=dict)


class ProjectUpdateRequest(BaseModel):
    name: str | None = None
    metadata: dict[str, Any] | None = None


class ProjectResponse(BaseModel):
    id: UUID
    organization_id: UUID
    name: str
    metadata: dict[str, Any]

    @staticmethod
    def of(project: Any) -> ProjectResponse:
        return ProjectResponse(
            id=project.id,
            organization_id=project.organization_id,
            name=project.name,
            metadata=dict(project.metadata),
        )


# ----- Document -----


class DocumentResponse(BaseModel):
    id: UUID
    organization_id: UUID
    project_id: UUID
    name: str
    media_type: str
    size_bytes: int
    checksum: str
    storage_uri: str
    current_version_id: UUID
    current_version_number: int
    current_version_name: str
    metadata: dict[str, Any]

    @staticmethod
    def of(doc: Any) -> DocumentResponse:
        return DocumentResponse(
            id=doc.id,
            organization_id=doc.organization_id,
            project_id=doc.project_id,
            name=doc.name,
            media_type=doc.media_type,
            size_bytes=doc.size_bytes,
            checksum=doc.checksum,
            storage_uri=doc.storage_uri,
            current_version_id=doc.current_version_id,
            current_version_number=doc.current_version_number,
            current_version_name=doc.current_version_name,
            metadata=dict(doc.metadata),
        )


class DocumentVersionResponse(BaseModel):
    id: UUID
    document_id: UUID
    organization_id: UUID
    project_id: UUID
    version_number: int
    version_name: str
    name: str
    media_type: str
    size_bytes: int
    checksum: str
    storage_uri: str
    metadata: dict[str, Any]
    created_at: datetime
    created_by_subject: str

    @staticmethod
    def of(v: Any) -> DocumentVersionResponse:
        return DocumentVersionResponse(
            id=v.id,
            document_id=v.document_id,
            organization_id=v.organization_id,
            project_id=v.project_id,
            version_number=v.version_number,
            version_name=v.version_name,
            name=v.name,
            media_type=v.media_type,
            size_bytes=v.size_bytes,
            checksum=v.checksum,
            storage_uri=v.storage_uri,
            metadata=dict(v.metadata),
            created_at=v.created_at,
            created_by_subject=v.created_by_subject,
        )


class DocumentUpdateRequest(BaseModel):
    name: str | None = None
    metadata: dict[str, Any] | None = None


# ----- ApiCall -----


class ApiCallCreateRequest(BaseModel):
    name: str = Field(min_length=1)
    operation_key: str = Field(min_length=1)
    external_request_id: str | None = None
    idempotency_key: str | None = None
    correlation_id: str | None = None
    request_payload: dict[str, Any] = Field(default_factory=dict)
    metadata: dict[str, Any] = Field(default_factory=dict)


class ApiCallUpdateRequest(BaseModel):
    status: ApiCallStatus | None = None
    response_payload: dict[str, Any] | None = None
    metadata: dict[str, Any] | None = None


class ApiCallResponse(BaseModel):
    id: UUID
    organization_id: UUID
    project_id: UUID
    name: str
    operation_key: str
    external_request_id: str | None
    idempotency_key: str | None
    correlation_id: str | None
    status: ApiCallStatus
    requested_at: datetime
    responded_at: datetime | None
    request_payload: dict[str, Any]
    response_payload: dict[str, Any]
    metadata: dict[str, Any]

    @staticmethod
    def of(c: Any) -> ApiCallResponse:
        return ApiCallResponse(
            id=c.id,
            organization_id=c.organization_id,
            project_id=c.project_id,
            name=c.name,
            operation_key=c.operation_key,
            external_request_id=c.external_request_id,
            idempotency_key=c.idempotency_key,
            correlation_id=c.correlation_id,
            status=c.status,
            requested_at=c.requested_at,
            responded_at=c.responded_at,
            request_payload=dict(c.request_payload),
            response_payload=dict(c.response_payload),
            metadata=dict(c.metadata),
        )


# ----- Execution -----


class ExecutionStartRequest(BaseModel):
    organization_id: UUID
    project_id: UUID
    operation: str = Field(min_length=1)
    target_type: ResourceType | None = None
    target_id: UUID | None = None
    correlation_id: str | None = None
    parent_execution_id: UUID | None = None
    agent_version: str | None = None
    model_provider: str | None = None
    model_name: str | None = None
    confidence: float | None = None
    warnings: list[str] = Field(default_factory=list)
    provenance: dict[str, Any] = Field(default_factory=dict)
    input: dict[str, Any] = Field(default_factory=dict)
    metadata: dict[str, Any] = Field(default_factory=dict)


class ExecutionCompleteRequest(BaseModel):
    output: dict[str, Any] = Field(default_factory=dict)
    metadata: dict[str, Any] | None = None


class ExecutionFailRequest(BaseModel):
    error_code: str | None = None
    error_message: str | None = None
    metadata: dict[str, Any] | None = None


class ExecutionResponse(BaseModel):
    id: UUID
    organization_id: UUID
    project_id: UUID
    operation: str
    status: ExecutionStatus
    actor: ActorRefModel
    target: ResourceRefModel | None
    correlation_id: str | None
    parent_execution_id: UUID | None
    agent_version: str | None
    model_provider: str | None
    model_name: str | None
    confidence: float | None
    warnings: list[str]
    provenance: dict[str, Any]
    started_at: datetime | None
    ended_at: datetime | None
    input: dict[str, Any]
    output: dict[str, Any]
    metadata: dict[str, Any]

    @staticmethod
    def of(e: Any) -> ExecutionResponse:
        return ExecutionResponse(
            id=e.id,
            organization_id=e.organization_id,
            project_id=e.project_id,
            operation=e.operation,
            status=e.status,
            actor=ActorRefModel.of(e.actor),
            target=ResourceRefModel.of(e.target) if e.target else None,
            correlation_id=e.correlation_id,
            parent_execution_id=e.parent_execution_id,
            agent_version=e.agent_version,
            model_provider=e.model_provider,
            model_name=e.model_name,
            confidence=e.confidence,
            warnings=list(e.warnings),
            provenance=dict(e.provenance),
            started_at=e.started_at,
            ended_at=e.ended_at,
            input=dict(e.input),
            output=dict(e.output),
            metadata=dict(e.metadata),
        )


# ----- Membership -----


class MembershipGrantRequest(BaseModel):
    resource_type: ResourceType
    resource_id: UUID
    actor_type: ActorType
    actor_id: str
    role: Role


class MembershipResponse(BaseModel):
    id: UUID
    actor: ActorRefModel
    role: Role
    resource: ResourceRefModel
    inherited: bool
    granted_at: datetime

    @staticmethod
    def of(m: Any) -> MembershipResponse:
        return MembershipResponse(
            id=m.id,
            actor=ActorRefModel.of(m.actor),
            role=m.role,
            resource=ResourceRefModel.of(m.resource),
            inherited=m.inherited,
            granted_at=m.granted_at,
        )


# ----- ApiKey -----


class ApiKeyCreateRequest(BaseModel):
    name: str = Field(min_length=1)
    scope_type: ResourceType
    scope_id: UUID
    role: Role
    expires_at: datetime | None = None
    metadata: dict[str, Any] = Field(default_factory=dict)


class ApiKeyUpdateRequest(BaseModel):
    name: str | None = None
    expires_at: datetime | None = None
    metadata: dict[str, Any] | None = None


class ApiKeyResponse(BaseModel):
    id: UUID
    name: str
    prefix: str
    scope: ResourceRefModel
    role: Role
    organization_id: UUID
    project_id: UUID | None
    expires_at: datetime | None
    last_used_at: datetime | None
    revoked_at: datetime | None
    metadata: dict[str, Any]
    created_at: datetime
    updated_at: datetime
    created_by_subject: str
    is_active: bool

    @staticmethod
    def of(k: Any) -> "ApiKeyResponse":
        return ApiKeyResponse(
            id=k.id,
            name=k.name,
            prefix=k.prefix,
            scope=ResourceRefModel.of(k.scope),
            role=k.role,
            organization_id=k.organization_id,
            project_id=k.project_id,
            expires_at=k.expires_at,
            last_used_at=k.last_used_at,
            revoked_at=k.revoked_at,
            metadata=dict(k.metadata),
            created_at=k.created_at,
            updated_at=k.updated_at,
            created_by_subject=k.created_by_subject,
            is_active=k.is_active,
        )


class ApiKeyCreatedResponse(BaseModel):
    api_key: ApiKeyResponse
    token: str


# ----- Audit -----


class AuditEventResponse(BaseModel):
    id: UUID
    occurred_at: datetime
    actor: ActorRefModel
    action: AuditAction
    resource: ResourceRefModel
    organization_id: UUID | None
    project_id: UUID | None
    correlation_id: str | None
    details: dict[str, Any]

    @staticmethod
    def of(e: Any) -> AuditEventResponse:
        return AuditEventResponse(
            id=e.id,
            occurred_at=e.occurred_at,
            actor=ActorRefModel.of(e.actor),
            action=e.action,
            resource=ResourceRefModel.of(e.resource),
            organization_id=e.organization_id,
            project_id=e.project_id,
            correlation_id=e.correlation_id,
            details=dict(e.details),
        )


# ----- Authorization -----


class AuthorizationCheckQuery(BaseModel):
    actor_type: ActorType
    actor_id: str = Field(min_length=1)
    action: Action
    resource_type: ResourceType
    resource_id: UUID


class AuthorizationCheckResponse(BaseModel):
    allowed: bool


class EffectiveRoleResponse(BaseModel):
    role: Role
    granted_on: ResourceRefModel
    effective_on: ResourceRefModel
    inherited: bool
    actions: list[Action]

    @staticmethod
    def of(r: Any) -> EffectiveRoleResponse:
        return EffectiveRoleResponse(
            role=r.role,
            granted_on=ResourceRefModel.of(r.granted_on),
            effective_on=ResourceRefModel.of(r.effective_on),
            inherited=r.inherited,
            actions=list(r.actions),
        )


class AuthorizationExplanationResponse(BaseModel):
    actor: ActorRefModel
    action: Action
    resource: ResourceRefModel
    allowed: bool
    source: str
    reason: str
    evaluated_scopes: list[ResourceRefModel]
    effective_roles: list[EffectiveRoleResponse]
    matching_roles: list[EffectiveRoleResponse]

    @staticmethod
    def of(e: Any) -> AuthorizationExplanationResponse:
        return AuthorizationExplanationResponse(
            actor=ActorRefModel.of(e.actor),
            action=e.action,
            resource=ResourceRefModel.of(e.resource),
            allowed=e.allowed,
            source=e.source.value if hasattr(e.source, "value") else str(e.source),
            reason=e.reason,
            evaluated_scopes=[ResourceRefModel.of(r) for r in e.evaluated_scopes],
            effective_roles=[EffectiveRoleResponse.of(r) for r in e.effective_roles],
            matching_roles=[EffectiveRoleResponse.of(r) for r in e.matching_roles],
        )
