"""Settings loaded from environment variables with the ``SAASBASE_`` prefix.

The FastAPI layer uses these to build a ``SaaSBase`` instance when the caller doesn't supply one.
"""

from __future__ import annotations

from datetime import timedelta

from pydantic import BaseModel, Field
from pydantic_settings import BaseSettings, SettingsConfigDict


class LocalStorageSettings(BaseModel):
    base_path: str | None = None


class S3StorageSettings(BaseModel):
    endpoint: str | None = None
    region: str | None = None
    bucket: str | None = None
    prefix: str = ""
    access_key: str | None = None
    secret_key: str | None = None
    path_style: bool = True


class StorageSettings(BaseModel):
    local: LocalStorageSettings = LocalStorageSettings()
    s3: S3StorageSettings | None = None


class OpenFgaSettings(BaseModel):
    api_url: str | None = None
    store_id: str | None = None
    authorization_model_id: str | None = None
    bearer_token: str | None = None


class AuditSettings(BaseModel):
    retention: timedelta | None = None


class WebSettings(BaseModel):
    enabled: bool = True
    base_path: str = "/api"


class ActorSettings(BaseModel):
    header: str = "X-SaaSBase-Actor"
    anonymous: str | None = "service:anonymous"


class SaaSBaseSettings(BaseSettings):
    """Environment-backed configuration, mirroring the Spring Boot starter's ``saasbase.*`` keys.

    Environment variable style: ``SAASBASE_DB_URL``, ``SAASBASE_STORAGE__LOCAL__BASE_PATH``,
    ``SAASBASE_WEB__BASE_PATH``, ``SAASBASE_ACTOR__HEADER``, etc. (double underscore for nested keys).
    """

    model_config = SettingsConfigDict(
        env_prefix="SAASBASE_",
        env_nested_delimiter="__",
        extra="ignore",
    )

    db_url: str | None = None
    storage: StorageSettings = Field(default_factory=StorageSettings)
    openfga: OpenFgaSettings | None = None
    audit: AuditSettings = Field(default_factory=AuditSettings)
    web: WebSettings = Field(default_factory=WebSettings)
    actor: ActorSettings = Field(default_factory=ActorSettings)
