"""Map SaaSBase domain exceptions onto HTTP status codes with a consistent JSON error body."""

from __future__ import annotations

from datetime import datetime, timezone

from fastapi import FastAPI, Request
from fastapi.responses import JSONResponse

from saasbase.common.exceptions import (
    ConflictError,
    NotFoundError,
    PermissionDeniedError,
    SaaSBaseError,
    ValidationError,
)


def _body(status_code: int, error: str, message: str) -> dict:
    return {
        "status": status_code,
        "error": error,
        "message": message,
        "timestamp": datetime.now(timezone.utc).isoformat().replace("+00:00", "Z"),
    }


def register_exception_handlers(app: FastAPI) -> None:
    @app.exception_handler(NotFoundError)
    async def _handle_not_found(_: Request, exc: NotFoundError) -> JSONResponse:
        return JSONResponse(_body(404, "NotFound", str(exc)), status_code=404)

    @app.exception_handler(PermissionDeniedError)
    async def _handle_permission_denied(_: Request, exc: PermissionDeniedError) -> JSONResponse:
        return JSONResponse(_body(403, "PermissionDenied", str(exc)), status_code=403)

    @app.exception_handler(ConflictError)
    async def _handle_conflict(_: Request, exc: ConflictError) -> JSONResponse:
        return JSONResponse(_body(409, "Conflict", str(exc)), status_code=409)

    @app.exception_handler(ValidationError)
    async def _handle_validation(_: Request, exc: ValidationError) -> JSONResponse:
        return JSONResponse(_body(400, "ValidationError", str(exc)), status_code=400)

    @app.exception_handler(SaaSBaseError)
    async def _handle_saasbase(_: Request, exc: SaaSBaseError) -> JSONResponse:
        return JSONResponse(_body(500, "SaaSBaseError", str(exc)), status_code=500)
