"""Shared FastAPI dependencies — the configured ``SaaSBase`` instance and the per-request context."""

from __future__ import annotations

from typing import Annotated

import anyio
from fastapi import Depends, Request

from saasbase import SaaSBase
from saasbase.common.actor import ActorRef
from saasbase.core.base import DefaultSaaSBaseContext
from saasbase.fastapi.actor import require_actor


def get_saasbase(request: Request) -> SaaSBase:
    """Returns the ``SaaSBase`` instance stored on ``app.state`` by ``create_app``."""
    sb: SaaSBase | None = getattr(request.app.state, "saasbase", None)
    if sb is None:  # pragma: no cover — configuration error
        raise RuntimeError("SaaSBase instance is not bound to app.state")
    return sb


async def get_context(
    actor: Annotated[ActorRef, Depends(require_actor)],
    sb: Annotated[SaaSBase, Depends(get_saasbase)],
) -> DefaultSaaSBaseContext:
    """Returns an actor-scoped SaaSBaseContext for the current request."""
    return sb.as_actor(actor)


async def run_sync(fn, *args, **kwargs):
    """Offload a blocking SaaSBase call onto the default thread pool.

    All SaaSBase I/O (sqlite3 / psycopg / file I/O) is synchronous. Wrapping each call here lets the
    event loop continue serving other requests while the SDK call runs on a worker thread.
    """
    return await anyio.to_thread.run_sync(lambda: fn(*args, **kwargs))


SaaSBaseDep = Annotated[SaaSBase, Depends(get_saasbase)]
ContextDep = Annotated[DefaultSaaSBaseContext, Depends(get_context)]
