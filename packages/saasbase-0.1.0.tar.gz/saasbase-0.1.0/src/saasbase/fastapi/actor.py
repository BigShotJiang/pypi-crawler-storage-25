"""Actor resolution for incoming HTTP requests.

The default chain, in order:

1. ``Authorization: Bearer sbk_...`` — authenticate against a SaaSBase API key and act as the
   ``API_KEY`` actor bound to that key.
2. ``X-SaaSBase-Actor`` header — free-form ``type:id`` identity (configurable via
   ``SAASBASE_ACTOR__HEADER``).
3. Configurable anonymous fallback (``saasbase.actor.anonymous``, default ``service:anonymous``).

Custom resolvers (JWT claims, session cookies, etc.) can be supplied to
``create_app(actor_resolver=...)``.
"""

from __future__ import annotations

from typing import Awaitable, Callable

import anyio
from fastapi import HTTPException, Request, status

from saasbase.common.actor import ActorRef, ActorType
from saasbase.core.apis.api_key_api import TOKEN_SCHEME

ActorResolver = Callable[[Request], Awaitable[ActorRef | None]]


def _parse_header(value: str) -> ActorRef | None:
    value = value.strip()
    if not value:
        return None
    sep = value.find(":")
    if sep <= 0 or sep == len(value) - 1:
        return ActorRef(ActorType.USER, value)
    type_token = value[:sep].upper()
    id_token = value[sep + 1 :].strip()
    if not id_token:
        return None
    try:
        actor_type = ActorType[type_token]
    except KeyError:
        return ActorRef(ActorType.USER, value)
    return ActorRef(actor_type, id_token)


def _extract_bearer(request: Request) -> str | None:
    raw = request.headers.get("authorization") or request.headers.get("Authorization")
    if not raw:
        return None
    parts = raw.split(None, 1)
    if len(parts) != 2 or parts[0].lower() != "bearer":
        return None
    return parts[1].strip() or None


def make_api_key_actor_resolver() -> ActorResolver:
    """Resolve the actor from a ``Bearer sbk_...`` token using the app's SaaSBase instance.

    Only SaaSBase-issued tokens (prefixed ``sbk_``) are consumed here — non-SaaSBase bearer tokens
    fall through so JWT/session auth can still own the ``Authorization`` header.
    """

    async def resolver(request: Request) -> ActorRef | None:
        token = _extract_bearer(request)
        if token is None or not token.startswith(f"{TOKEN_SCHEME}_"):
            return None
        sb = getattr(request.app.state, "saasbase", None)
        if sb is None:
            return None
        key = await anyio.to_thread.run_sync(lambda: sb.api_keys.authenticate(token))
        if key is None:
            # Reject actively rather than falling through — a Bearer sbk_* token that's invalid
            # should produce an auth failure rather than silently downgrading to anonymous.
            raise HTTPException(status.HTTP_401_UNAUTHORIZED, "Invalid or expired API key")
        return key.actor

    return resolver


def make_header_actor_resolver(header_name: str, anonymous: str | None) -> ActorResolver:
    """Chain the bearer-token resolver, the header resolver, and the anonymous fallback."""

    bearer = make_api_key_actor_resolver()
    fallback = _parse_header(anonymous) if anonymous else None

    async def resolver(request: Request) -> ActorRef | None:
        bearer_actor = await bearer(request)
        if bearer_actor is not None:
            return bearer_actor
        raw = request.headers.get(header_name)
        if raw:
            actor = _parse_header(raw)
            if actor is not None:
                return actor
        return fallback

    return resolver


async def require_actor(request: Request) -> ActorRef:
    """Dependency that returns the resolved actor or raises 401 if none is available."""
    resolver: ActorResolver | None = getattr(request.app.state, "actor_resolver", None)
    if resolver is None:
        raise HTTPException(status.HTTP_500_INTERNAL_SERVER_ERROR, "Actor resolver is not configured")
    actor = await resolver(request)
    if actor is None:
        raise HTTPException(
            status.HTTP_401_UNAUTHORIZED,
            "Unable to resolve caller actor. Provide an X-SaaSBase-Actor header or authenticate.",
        )
    return actor
