"""Build a FastAPI application that exposes the SaaSBase APIs."""

from __future__ import annotations

from contextlib import asynccontextmanager
from typing import AsyncIterator

from fastapi import FastAPI

from saasbase import SaaSBase
from saasbase.fastapi.actor import ActorResolver, make_header_actor_resolver
from saasbase.fastapi.errors import register_exception_handlers
from saasbase.fastapi.routers import (
    api_calls,
    api_keys,
    audits,
    authorization,
    documents,
    executions,
    memberships,
    organizations,
    projects,
)
from saasbase.fastapi.settings import SaaSBaseSettings


def _build_saasbase(settings: SaaSBaseSettings) -> SaaSBase:
    builder = SaaSBase.builder()
    if settings.db_url:
        builder.db_url(settings.db_url)
    else:
        builder.sqlite()

    if settings.storage.s3 and settings.storage.s3.endpoint:
        s3 = settings.storage.s3
        builder.s3_storage(
            endpoint=s3.endpoint,
            region=s3.region or "",
            bucket=s3.bucket or "",
            access_key=s3.access_key or "",
            secret_key=s3.secret_key or "",
            prefix=s3.prefix,
            path_style=s3.path_style,
        )
    elif settings.storage.local.base_path:
        builder.local_storage(settings.storage.local.base_path)
    else:
        raise RuntimeError(
            "Storage is not configured. Set SAASBASE_STORAGE__LOCAL__BASE_PATH or the S3 variables."
        )

    openfga = settings.openfga
    if openfga and openfga.api_url and openfga.store_id and openfga.authorization_model_id:
        builder.open_fga(
            api_url=openfga.api_url,
            store_id=openfga.store_id,
            authorization_model_id=openfga.authorization_model_id,
            bearer_token=openfga.bearer_token,
        )

    if settings.audit.retention is not None:
        builder.audit_retention(settings.audit.retention)

    return builder.build()


def create_app(
    saasbase: SaaSBase | None = None,
    settings: SaaSBaseSettings | None = None,
    actor_resolver: ActorResolver | None = None,
) -> FastAPI:
    """Create a FastAPI app wired to a SaaSBase instance.

    ``saasbase`` and ``settings`` are both optional:

    - If ``saasbase`` is provided it's used as-is (the caller owns its lifecycle).
    - Otherwise ``settings`` is read (or env-loaded) and a new instance is built and closed on
      shutdown.
    - ``actor_resolver`` can override the default header-based resolver with e.g. a JWT-aware one.
    """
    settings = settings or SaaSBaseSettings()
    owns_saasbase = saasbase is None
    sb = saasbase or _build_saasbase(settings)

    resolver = actor_resolver or make_header_actor_resolver(
        settings.actor.header, settings.actor.anonymous
    )

    @asynccontextmanager
    async def lifespan(app: FastAPI) -> AsyncIterator[None]:
        try:
            yield
        finally:
            if owns_saasbase:
                sb.close()

    app = FastAPI(
        title="SaaSBase",
        description="Embedded SaaSBase SDK exposed over HTTP.",
        version="0.1.0",
        lifespan=lifespan,
    )

    # Set state eagerly so ASGI clients that don't trigger the lifespan hook (e.g. httpx's
    # ASGITransport in tests) still see the configured runtime. Lifespan handles teardown only.
    app.state.saasbase = sb
    app.state.settings = settings
    app.state.actor_resolver = resolver

    register_exception_handlers(app)

    if settings.web.enabled:
        base_path = settings.web.base_path.rstrip("/")
        app.include_router(organizations.router, prefix=base_path)
        app.include_router(projects.router, prefix=base_path)
        app.include_router(documents.router, prefix=base_path)
        app.include_router(api_calls.router, prefix=base_path)
        app.include_router(executions.router, prefix=base_path)
        app.include_router(memberships.router, prefix=base_path)
        app.include_router(audits.router, prefix=base_path)
        app.include_router(authorization.router, prefix=base_path)
        app.include_router(api_keys.router, prefix=base_path)

    return app
