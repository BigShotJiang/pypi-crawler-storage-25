"""FastAPI integration for SaaSBase — exposes every domain API over async HTTP.

Example:

    from saasbase import SaaSBase
    from saasbase.fastapi import create_app

    sb = SaaSBase.builder().sqlite().local_storage("./data").build()
    app = create_app(sb)

    # uvicorn my_module:app --reload

The underlying SaaSBase runtime is synchronous (sqlite3 / psycopg / file I/O). Async handlers
offload calls via ``anyio.to_thread`` so the event loop stays non-blocking under concurrent load.
"""

from saasbase.fastapi.app import create_app
from saasbase.fastapi.settings import SaaSBaseSettings

__all__ = ["SaaSBaseSettings", "create_app"]
