"""SPI (Service Provider Interface) contracts — pluggable backends for persistence, storage, authorization, and audit."""

from saasbase.spi.audit import AuditEventRecord, AuditEventSink
from saasbase.spi.authz import AuthzEngine
from saasbase.spi.infra import ClockProvider, IdGenerator
from saasbase.spi.persistence import (
    ApiCallRecord,
    ApiCallRepository,
    ApiKeyRecord,
    ApiKeyRepository,
    DocumentRecord,
    DocumentRepository,
    DocumentVersionRecord,
    DocumentVersionRepository,
    ExecutionRecord,
    ExecutionRepository,
    MembershipRecord,
    MembershipRepository,
    OrganizationRecord,
    OrganizationRepository,
    ProjectRecord,
    ProjectRepository,
)
from saasbase.spi.storage import DocumentStorage, StoreDocumentRequest, StoredDocument
from saasbase.spi.tx import TransactionManager

__all__ = [
    "ApiCallRecord",
    "ApiCallRepository",
    "ApiKeyRecord",
    "ApiKeyRepository",
    "AuditEventRecord",
    "AuditEventSink",
    "AuthzEngine",
    "ClockProvider",
    "DocumentRecord",
    "DocumentRepository",
    "DocumentStorage",
    "DocumentVersionRecord",
    "DocumentVersionRepository",
    "ExecutionRecord",
    "ExecutionRepository",
    "IdGenerator",
    "MembershipRecord",
    "MembershipRepository",
    "OrganizationRecord",
    "OrganizationRepository",
    "ProjectRecord",
    "ProjectRepository",
    "StoreDocumentRequest",
    "StoredDocument",
    "TransactionManager",
]
