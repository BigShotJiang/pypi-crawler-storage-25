from __future__ import annotations

from typing import Callable, Protocol, TypeVar

T = TypeVar("T")


class TransactionManager(Protocol):
    """Runs a block within a database transaction; nested calls reuse the outer transaction."""

    def required(self, action: Callable[[], T]) -> T: ...
