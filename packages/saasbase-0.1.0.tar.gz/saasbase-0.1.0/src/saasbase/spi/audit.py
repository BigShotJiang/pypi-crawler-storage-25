from __future__ import annotations

from dataclasses import dataclass, field
from datetime import datetime
from typing import Any, Protocol
from uuid import UUID

from saasbase.common.actor import ActorRef
from saasbase.common.audit import AuditAction
from saasbase.common.pagination import Page, PageRequest
from saasbase.common.query import AuditQuery
from saasbase.common.resource import ResourceRef


@dataclass(frozen=True, slots=True)
class AuditEventRecord:
    id: UUID
    occurred_at: datetime
    actor: ActorRef
    action: AuditAction
    resource: ResourceRef
    organization_id: UUID | None
    project_id: UUID | None
    correlation_id: str | None
    details: dict[str, Any] = field(default_factory=dict)


class AuditEventSink(Protocol):
    """Durable or in-memory audit event store."""

    def record(self, event: AuditEventRecord) -> None: ...

    def list(self, resource: ResourceRef) -> list[AuditEventRecord]: ...

    def list_by_correlation_id(self, correlation_id: str) -> list[AuditEventRecord]: ...

    def query(self, query: AuditQuery, page_request: PageRequest) -> Page[AuditEventRecord]: ...

    def prune(self, query: AuditQuery) -> int: ...
