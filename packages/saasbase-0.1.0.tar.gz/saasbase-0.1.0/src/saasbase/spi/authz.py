from __future__ import annotations

from typing import Protocol

from saasbase.common.actor import ActorRef
from saasbase.common.authz import Action, Role
from saasbase.common.resource import ResourceRef


class AuthzEngine(Protocol):
    """Pluggable authorization engine — manages role grants and evaluates permissions."""

    def grant(self, resource: ResourceRef, actor: ActorRef, role: Role) -> None: ...

    def revoke(self, resource: ResourceRef, actor: ActorRef, role: Role) -> None: ...

    def link_parent(self, child: ResourceRef, parent: ResourceRef) -> None:
        """Declare a parent-child hierarchy tuple. Optional — engines that infer hierarchy may no-op."""
        return None

    def unlink_parent(self, child: ResourceRef, parent: ResourceRef) -> None:
        return None

    def can(self, actor: ActorRef, action: Action, resource: ResourceRef) -> bool: ...

    def who_can(self, action: Action, resource: ResourceRef) -> list[ActorRef]: ...
