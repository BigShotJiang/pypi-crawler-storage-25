from __future__ import annotations

from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, BinaryIO, Protocol


@dataclass(frozen=True, slots=True)
class StoreDocumentRequest:
    name: str
    media_type: str
    content: BinaryIO
    metadata: dict[str, Any] = field(default_factory=dict)


@dataclass(frozen=True, slots=True)
class StoredDocument:
    storage_key: str
    uri: str
    checksum: str
    size_bytes: int
    media_type: str


class DocumentStorage(Protocol):
    """Pluggable binary document storage."""

    def store(self, request: StoreDocumentRequest) -> StoredDocument: ...

    def read(self, storage_key: str) -> BinaryIO: ...

    def download(self, storage_key: str, target_directory: Path) -> Path: ...

    def delete(self, storage_key: str) -> None: ...
