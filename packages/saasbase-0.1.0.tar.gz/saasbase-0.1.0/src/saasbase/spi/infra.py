from __future__ import annotations

from datetime import datetime, timezone
from typing import Callable
from uuid import UUID, uuid4

IdGenerator = Callable[[], UUID]
"""Callable that returns a fresh UUID — used for entity IDs."""

ClockProvider = Callable[[], datetime]
"""Callable that returns the current instant (timezone-aware UTC)."""


def default_id_generator() -> UUID:
    return uuid4()


def default_clock_provider() -> datetime:
    return datetime.now(timezone.utc)
