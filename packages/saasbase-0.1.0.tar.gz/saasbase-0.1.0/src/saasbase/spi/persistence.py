from __future__ import annotations

from dataclasses import dataclass, field
from datetime import datetime
from typing import Any, Protocol
from uuid import UUID

from saasbase.common.actor import ActorRef
from saasbase.common.authz import Role
from saasbase.common.pagination import Page, PageRequest
from saasbase.common.query import (
    ApiCallQuery,
    DocumentQuery,
    DocumentVersionQuery,
    ExecutionQuery,
    OrganizationQuery,
    ProjectQuery,
)
from saasbase.common.resource import ResourceRef
from saasbase.common.status import ApiCallStatus, ExecutionStatus


@dataclass(frozen=True, slots=True)
class OrganizationRecord:
    id: UUID
    slug: str
    name: str
    metadata: dict[str, Any]
    created_at: datetime
    updated_at: datetime
    created_by_subject: str


@dataclass(frozen=True, slots=True)
class ProjectRecord:
    id: UUID
    organization_id: UUID
    name: str
    metadata: dict[str, Any]
    created_at: datetime
    updated_at: datetime
    created_by_subject: str


@dataclass(frozen=True, slots=True)
class DocumentRecord:
    id: UUID
    organization_id: UUID
    project_id: UUID
    current_version_id: UUID
    current_version_number: int
    current_version_name: str
    name: str
    media_type: str
    size_bytes: int
    checksum: str
    storage_key: str
    storage_uri: str
    metadata: dict[str, Any]
    created_at: datetime
    updated_at: datetime
    created_by_subject: str


@dataclass(frozen=True, slots=True)
class DocumentVersionRecord:
    id: UUID
    document_id: UUID
    organization_id: UUID
    project_id: UUID
    version_number: int
    version_name: str
    name: str
    media_type: str
    size_bytes: int
    checksum: str
    storage_key: str
    storage_uri: str
    metadata: dict[str, Any]
    created_at: datetime
    created_by_subject: str


@dataclass(frozen=True, slots=True)
class ApiCallRecord:
    id: UUID
    organization_id: UUID
    project_id: UUID
    name: str
    operation_key: str
    external_request_id: str | None
    idempotency_key: str | None
    correlation_id: str | None
    status: ApiCallStatus
    requested_at: datetime
    responded_at: datetime | None
    request_payload: dict[str, Any]
    response_payload: dict[str, Any]
    metadata: dict[str, Any]
    created_at: datetime
    updated_at: datetime
    created_by_subject: str


@dataclass(frozen=True, slots=True)
class ExecutionRecord:
    id: UUID
    organization_id: UUID
    project_id: UUID
    operation: str
    status: ExecutionStatus
    actor: ActorRef
    target: ResourceRef | None
    correlation_id: str | None
    parent_execution_id: UUID | None
    agent_version: str | None
    model_provider: str | None
    model_name: str | None
    confidence: float | None
    warnings: list[str] = field(default_factory=list)
    provenance: dict[str, Any] = field(default_factory=dict)
    started_at: datetime | None = None
    ended_at: datetime | None = None
    input: dict[str, Any] = field(default_factory=dict)
    output: dict[str, Any] = field(default_factory=dict)
    metadata: dict[str, Any] = field(default_factory=dict)


@dataclass(frozen=True, slots=True)
class ApiKeyRecord:
    id: UUID
    name: str
    prefix: str
    secret_hash: str
    scope: ResourceRef
    role: Role
    organization_id: UUID
    project_id: UUID | None
    expires_at: datetime | None
    last_used_at: datetime | None
    revoked_at: datetime | None
    metadata: dict[str, Any]
    created_at: datetime
    updated_at: datetime
    created_by_subject: str


@dataclass(frozen=True, slots=True)
class MembershipRecord:
    id: UUID
    resource: ResourceRef
    actor: ActorRef
    role: Role
    inherited: bool
    granted_at: datetime


class OrganizationRepository(Protocol):
    def create(self, record: OrganizationRecord) -> OrganizationRecord: ...
    def find_by_id(self, id: UUID) -> OrganizationRecord | None: ...
    def find_by_slug(self, slug: str) -> OrganizationRecord | None: ...
    def list(self) -> list[OrganizationRecord]: ...
    def query(self, query: OrganizationQuery, page_request: PageRequest) -> Page[OrganizationRecord]: ...
    def update(self, record: OrganizationRecord) -> OrganizationRecord: ...
    def delete(self, id: UUID) -> None: ...


class ProjectRepository(Protocol):
    def create(self, record: ProjectRecord) -> ProjectRecord: ...
    def find_by_id(self, id: UUID) -> ProjectRecord | None: ...
    def list_by_organization(self, organization_id: UUID) -> list[ProjectRecord]: ...
    def query(self, query: ProjectQuery, page_request: PageRequest) -> Page[ProjectRecord]: ...
    def update(self, record: ProjectRecord) -> ProjectRecord: ...
    def delete(self, id: UUID) -> None: ...


class DocumentRepository(Protocol):
    def create(self, record: DocumentRecord) -> DocumentRecord: ...
    def find_by_id(self, id: UUID) -> DocumentRecord | None: ...
    def list_by_project(self, project_id: UUID) -> list[DocumentRecord]: ...
    def query(self, query: DocumentQuery, page_request: PageRequest) -> Page[DocumentRecord]: ...
    def update(self, record: DocumentRecord) -> DocumentRecord: ...
    def delete(self, id: UUID) -> None: ...


class DocumentVersionRepository(Protocol):
    def create(self, record: DocumentVersionRecord) -> DocumentVersionRecord: ...
    def find_by_id(self, id: UUID) -> DocumentVersionRecord | None: ...
    def find_by_document_id_and_version_name(
        self, document_id: UUID, version_name: str
    ) -> DocumentVersionRecord | None: ...
    def list_by_document_id(self, document_id: UUID) -> list[DocumentVersionRecord]: ...
    def query(
        self, query: DocumentVersionQuery, page_request: PageRequest
    ) -> Page[DocumentVersionRecord]: ...
    def delete_by_document_id(self, document_id: UUID) -> None: ...


class ApiCallRepository(Protocol):
    def create(self, record: ApiCallRecord) -> ApiCallRecord: ...
    def find_by_id(self, id: UUID) -> ApiCallRecord | None: ...
    def list_by_project(self, project_id: UUID) -> list[ApiCallRecord]: ...
    def list_by_correlation_id(self, correlation_id: str) -> list[ApiCallRecord]: ...
    def query(self, query: ApiCallQuery, page_request: PageRequest) -> Page[ApiCallRecord]: ...
    def update(self, record: ApiCallRecord) -> ApiCallRecord: ...
    def delete(self, id: UUID) -> None: ...


class ExecutionRepository(Protocol):
    def create(self, record: ExecutionRecord) -> ExecutionRecord: ...
    def find_by_id(self, id: UUID) -> ExecutionRecord | None: ...
    def list_by_project(self, project_id: UUID) -> list[ExecutionRecord]: ...
    def list_by_correlation_id(self, correlation_id: str) -> list[ExecutionRecord]: ...
    def list_children(self, parent_execution_id: UUID) -> list[ExecutionRecord]: ...
    def query(self, query: ExecutionQuery, page_request: PageRequest) -> Page[ExecutionRecord]: ...
    def update(self, record: ExecutionRecord) -> ExecutionRecord: ...


class MembershipRepository(Protocol):
    def create(self, record: MembershipRecord) -> MembershipRecord: ...
    def list(self, resource: ResourceRef) -> list[MembershipRecord]: ...
    def revoke(self, resource: ResourceRef, actor: ActorRef, role: Role) -> None: ...
    def remove(self, resource: ResourceRef, actor: ActorRef) -> None: ...


class ApiKeyRepository(Protocol):
    def create(self, record: ApiKeyRecord) -> ApiKeyRecord: ...
    def find_by_id(self, id: UUID) -> ApiKeyRecord | None: ...
    def find_by_prefix(self, prefix: str) -> ApiKeyRecord | None: ...
    def list_by_scope(self, scope: ResourceRef) -> list[ApiKeyRecord]: ...
    def list_by_organization(self, organization_id: UUID) -> list[ApiKeyRecord]: ...
    def update(self, record: ApiKeyRecord) -> ApiKeyRecord: ...
    def touch_last_used(self, id: UUID, when: datetime) -> None: ...
    def delete(self, id: UUID) -> None: ...
