from __future__ import annotations

from dataclasses import dataclass
from typing import Callable

from saasbase.core.hierarchy import ResourceHierarchyResolver
from saasbase.core.recorder import AuditRecorder
from saasbase.spi.audit import AuditEventSink
from saasbase.spi.authz import AuthzEngine
from saasbase.spi.infra import ClockProvider, IdGenerator
from saasbase.spi.persistence import (
    ApiCallRepository,
    ApiKeyRepository,
    DocumentRepository,
    DocumentVersionRepository,
    ExecutionRepository,
    MembershipRepository,
    OrganizationRepository,
    ProjectRepository,
)
from saasbase.spi.storage import DocumentStorage
from saasbase.spi.tx import TransactionManager


@dataclass(slots=True)
class Runtime:
    """Bag of SPI components the API implementations depend on — shared across all entities."""

    organizations: OrganizationRepository
    projects: ProjectRepository
    documents: DocumentRepository
    document_versions: DocumentVersionRepository
    api_calls: ApiCallRepository
    executions: ExecutionRepository
    memberships: MembershipRepository
    api_keys: ApiKeyRepository
    tx: TransactionManager
    storage: DocumentStorage
    authz: AuthzEngine
    audit: AuditEventSink
    clock: ClockProvider
    id_generator: IdGenerator
    recorder: AuditRecorder
    hierarchy: ResourceHierarchyResolver
    closer: Callable[[], None] | None = None
