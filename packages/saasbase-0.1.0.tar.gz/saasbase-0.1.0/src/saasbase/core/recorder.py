"""Builds AuditEventRecord instances and pushes them to the configured sink."""

from __future__ import annotations

from typing import Any
from uuid import UUID

from saasbase.common.actor import ActorRef
from saasbase.common.audit import AuditAction
from saasbase.common.resource import ResourceRef
from saasbase.spi.audit import AuditEventRecord, AuditEventSink
from saasbase.spi.infra import ClockProvider, IdGenerator


class AuditRecorder:
    def __init__(
        self,
        sink: AuditEventSink,
        clock: ClockProvider,
        id_generator: IdGenerator,
    ) -> None:
        self._sink = sink
        self._clock = clock
        self._id_generator = id_generator

    def record(
        self,
        actor: ActorRef,
        action: AuditAction,
        resource: ResourceRef,
        organization_id: UUID | None = None,
        project_id: UUID | None = None,
        correlation_id: str | None = None,
        details: dict[str, Any] | None = None,
    ) -> AuditEventRecord:
        event = AuditEventRecord(
            id=self._id_generator(),
            occurred_at=self._clock(),
            actor=actor,
            action=action,
            resource=resource,
            organization_id=organization_id,
            project_id=project_id,
            correlation_id=correlation_id,
            details=details or {},
        )
        self._sink.record(event)
        return event
