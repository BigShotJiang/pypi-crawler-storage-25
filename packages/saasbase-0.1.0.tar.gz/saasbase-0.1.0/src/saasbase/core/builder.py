from __future__ import annotations

from datetime import timedelta
from enum import Enum
from typing import Any, Callable

from saasbase.audit_inmemory.sink import InMemoryAuditEventSink, NoOpAuditEventSink
from saasbase.authz_inmemory.engine import InMemoryAuthzEngine
from saasbase.common.exceptions import SaaSBaseError
from saasbase.common.query import AuditQuery
from saasbase.core.base import DefaultSaaSBase
from saasbase.core.hierarchy import ResourceHierarchyResolver
from saasbase.core.recorder import AuditRecorder
from saasbase.core.runtime import Runtime
from saasbase.persistence import (
    ApiCallSqlRepository,
    ApiKeySqlRepository,
    AuditEventSqlSink,
    DocumentSqlRepository,
    DocumentVersionSqlRepository,
    ExecutionSqlRepository,
    MembershipSqlRepository,
    OrganizationSqlRepository,
    PostgresDialect,
    ProjectSqlRepository,
    SQLiteDialect,
    ThreadLocalConnectionProvider,
)
from saasbase.persistence.tx import DbApiTransactionManager
from saasbase.spi.audit import AuditEventSink
from saasbase.spi.authz import AuthzEngine
from saasbase.spi.infra import default_clock_provider, default_id_generator
from saasbase.spi.storage import DocumentStorage
from saasbase.storage.local import LocalDocumentStorage

_SQLITE_DEFAULT_URL = "jdbc:sqlite:./data/saasbase.db"
_POSTGRES_DEFAULT_URL = "jdbc:postgresql://localhost:5432/saasbase?user=saasbase&password=saasbase"


class _DatabaseMode(str, Enum):
    UNSET = "UNSET"
    SQLITE = "SQLITE"
    POSTGRES = "POSTGRES"


class _StorageMode(str, Enum):
    UNSET = "UNSET"
    LOCAL = "LOCAL"
    S3 = "S3"


def _infer_db_mode(url: str | None) -> _DatabaseMode:
    if not url:
        return _DatabaseMode.UNSET
    if url.startswith("jdbc:sqlite:") or url.startswith("sqlite:") or url.endswith(".db"):
        return _DatabaseMode.SQLITE
    if url.startswith("jdbc:postgresql:") or url.startswith("postgresql:") or url.startswith(
        "postgres:"
    ):
        return _DatabaseMode.POSTGRES
    return _DatabaseMode.UNSET


class DefaultSaaSBaseBuilder:
    """Fluent builder — selects database, storage, authz, audit retention."""

    def __init__(self) -> None:
        self._db_mode: _DatabaseMode = _DatabaseMode.UNSET
        self._db_url: str | None = None
        self._storage_mode: _StorageMode = _StorageMode.UNSET
        self._local_storage_base_path: str | None = None
        self._s3_settings: dict[str, Any] | None = None
        self._openfga_settings: dict[str, Any] | None = None
        self._audit_retention: timedelta | None = None

    # ---- database ----

    def sqlite(self) -> "DefaultSaaSBaseBuilder":
        if self._db_mode not in (_DatabaseMode.UNSET, _DatabaseMode.SQLITE):
            raise SaaSBaseError(
                f"Database backend already configured as {self._db_mode.name.lower()}; "
                "remove the conflicting sqlite() call."
            )
        self._db_mode = _DatabaseMode.SQLITE
        if self._db_url is None:
            self._db_url = _SQLITE_DEFAULT_URL
        return self

    def postgres(self) -> "DefaultSaaSBaseBuilder":
        if self._db_mode not in (_DatabaseMode.UNSET, _DatabaseMode.POSTGRES):
            raise SaaSBaseError(
                f"Database backend already configured as {self._db_mode.name.lower()}; "
                "remove the conflicting postgres() call."
            )
        self._db_mode = _DatabaseMode.POSTGRES
        if self._db_url is None:
            self._db_url = _POSTGRES_DEFAULT_URL
        return self

    def db_url(self, url: str) -> "DefaultSaaSBaseBuilder":
        if not url or not url.strip():
            raise ValueError("url must not be blank")
        self._db_url = url
        return self

    # ---- storage ----

    def local_storage(self, base_path: str) -> "DefaultSaaSBaseBuilder":
        if not base_path or not base_path.strip():
            raise ValueError("base_path must not be blank")
        if self._storage_mode not in (_StorageMode.UNSET, _StorageMode.LOCAL):
            raise SaaSBaseError(
                f"Document storage already configured as {self._storage_mode.name.lower()}; "
                "remove the conflicting local_storage(...) call."
            )
        self._storage_mode = _StorageMode.LOCAL
        self._local_storage_base_path = base_path
        self._s3_settings = None
        return self

    def s3_storage(
        self,
        endpoint: str,
        region: str,
        bucket: str,
        access_key: str,
        secret_key: str,
        prefix: str = "",
        path_style: bool = True,
    ) -> "DefaultSaaSBaseBuilder":
        if self._storage_mode not in (_StorageMode.UNSET, _StorageMode.S3):
            raise SaaSBaseError(
                f"Document storage already configured as {self._storage_mode.name.lower()}; "
                "remove the conflicting s3_storage(...) call."
            )
        self._storage_mode = _StorageMode.S3
        self._s3_settings = {
            "endpoint": endpoint,
            "region": region,
            "bucket": bucket,
            "access_key": access_key,
            "secret_key": secret_key,
            "prefix": prefix,
            "path_style": path_style,
        }
        self._local_storage_base_path = None
        return self

    # ---- authz ----

    def open_fga(
        self,
        api_url: str,
        store_id: str,
        authorization_model_id: str,
        bearer_token: str | None = None,
    ) -> "DefaultSaaSBaseBuilder":
        self._openfga_settings = {
            "api_url": api_url,
            "store_id": store_id,
            "authorization_model_id": authorization_model_id,
            "bearer_token": bearer_token,
        }
        return self

    # ---- audit ----

    def audit_retention(self, retention: timedelta) -> "DefaultSaaSBaseBuilder":
        if retention <= timedelta(0):
            raise ValueError("retention must be > 0")
        self._audit_retention = retention
        return self

    # ---- build ----

    def build(self) -> DefaultSaaSBase:
        db_mode = self._db_mode
        if db_mode == _DatabaseMode.UNSET:
            inferred = _infer_db_mode(self._db_url)
            if inferred == _DatabaseMode.UNSET:
                raise SaaSBaseError(
                    "Database configuration is required. Call sqlite(), postgres(), "
                    "or db_url('jdbc:sqlite:...')/db_url('jdbc:postgresql:...')."
                )
            db_mode = inferred
        else:
            inferred = _infer_db_mode(self._db_url)
            if inferred != _DatabaseMode.UNSET and inferred != db_mode:
                raise SaaSBaseError(
                    f"Configured database mode {db_mode.name.lower()} conflicts with "
                    f"URL '{self._db_url}'."
                )

        if self._storage_mode == _StorageMode.UNSET:
            raise SaaSBaseError(
                "Document storage must be configured. Call local_storage('<path>') or s3_storage(...)."
            )

        provider, dialect, closers = self._build_persistence(db_mode)

        organizations = OrganizationSqlRepository(provider, dialect)
        projects = ProjectSqlRepository(provider, dialect)
        documents = DocumentSqlRepository(provider, dialect)
        document_versions = DocumentVersionSqlRepository(provider, dialect)
        api_calls = ApiCallSqlRepository(provider, dialect)
        executions = ExecutionSqlRepository(provider, dialect)
        memberships = MembershipSqlRepository(provider, dialect)
        api_keys = ApiKeySqlRepository(provider, dialect)
        tx = DbApiTransactionManager(provider)

        storage = self._build_storage()
        authz = self._build_authz()
        audit = self._build_audit(provider, dialect)

        clock = default_clock_provider
        id_generator = default_id_generator
        recorder = AuditRecorder(audit, clock, id_generator)
        hierarchy = ResourceHierarchyResolver(projects, documents, api_calls)

        runtime = Runtime(
            organizations=organizations,
            projects=projects,
            documents=documents,
            document_versions=document_versions,
            api_calls=api_calls,
            executions=executions,
            memberships=memberships,
            api_keys=api_keys,
            tx=tx,
            storage=storage,
            authz=authz,
            audit=audit,
            clock=clock,
            id_generator=id_generator,
            recorder=recorder,
            hierarchy=hierarchy,
        )

        self._apply_audit_retention(audit, clock)

        def _close() -> None:
            for fn in closers:
                try:
                    fn()
                except Exception:
                    pass

        runtime.closer = _close
        return DefaultSaaSBase(runtime)

    def _build_persistence(self, db_mode: _DatabaseMode):
        closers: list[Callable[[], None]] = []
        if db_mode == _DatabaseMode.SQLITE:
            from saasbase.sqlite.factory import SQLiteFactory

            factory = SQLiteFactory(self._db_url)
            factory.apply_schema()
            dialect = SQLiteDialect()
            provider = ThreadLocalConnectionProvider(factory.connect)
            closers.append(provider.close_idle)
            return provider, dialect, closers
        if db_mode == _DatabaseMode.POSTGRES:
            from saasbase.postgres.factory import PostgresFactory

            factory = PostgresFactory(self._db_url)
            factory.apply_schema()
            dialect = PostgresDialect()
            provider = ThreadLocalConnectionProvider(factory.connect)
            closers.append(provider.close_idle)
            return provider, dialect, closers
        raise SaaSBaseError(f"Unsupported database mode: {db_mode}")

    def _build_storage(self) -> DocumentStorage:
        if self._storage_mode == _StorageMode.LOCAL:
            assert self._local_storage_base_path is not None
            return LocalDocumentStorage(self._local_storage_base_path)
        if self._storage_mode == _StorageMode.S3:
            from saasbase.storage.s3 import S3DocumentStorage, S3DocumentStorageConfig

            assert self._s3_settings is not None
            cfg = S3DocumentStorageConfig(**self._s3_settings)
            return S3DocumentStorage(cfg)
        raise SaaSBaseError(f"Unsupported storage mode: {self._storage_mode}")

    def _build_authz(self) -> AuthzEngine:
        if self._openfga_settings is None:
            return InMemoryAuthzEngine()
        from saasbase.authz_openfga.config import OpenFgaConfig
        from saasbase.authz_openfga.engine import OpenFgaAuthzEngine

        config = OpenFgaConfig(**self._openfga_settings)
        return OpenFgaAuthzEngine(config)

    def _build_audit(self, provider, dialect) -> AuditEventSink:
        # Prefer the SQL sink so audit events persist alongside state. Fall back to in-memory.
        try:
            return AuditEventSqlSink(provider, dialect)
        except Exception:
            try:
                return InMemoryAuditEventSink()
            except Exception:
                return NoOpAuditEventSink()

    def _apply_audit_retention(self, audit: AuditEventSink, clock) -> None:
        if self._audit_retention is None:
            return
        cutoff = clock() - self._audit_retention
        try:
            audit.prune(AuditQuery.all().with_occurred_to(cutoff))
        except Exception:
            pass
