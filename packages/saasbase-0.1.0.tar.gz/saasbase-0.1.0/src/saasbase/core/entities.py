"""Concrete entity implementations that wrap persistence records and expose fluent helpers."""

from __future__ import annotations

import io
import shutil
from dataclasses import replace
from datetime import datetime
from pathlib import Path
from typing import TYPE_CHECKING, Any, BinaryIO
from uuid import UUID

from saasbase.api.document import CreateDocumentVersionRequest, UpdateDocumentRequest
from saasbase.api.organization import UpdateOrganizationRequest
from saasbase.api.project import UpdateProjectRequest
from saasbase.common.actor import ActorRef
from saasbase.common.audit import AuditAction
from saasbase.common.authz import Role
from saasbase.common.resource import ResourceRef, ResourceType
from saasbase.common.status import ApiCallStatus
from saasbase.common.actor import ActorType
from saasbase.spi.audit import AuditEventRecord
from saasbase.spi.persistence import (
    ApiCallRecord,
    ApiKeyRecord,
    DocumentRecord,
    DocumentVersionRecord,
    ExecutionRecord,
    MembershipRecord,
    OrganizationRecord,
    ProjectRecord,
)

if TYPE_CHECKING:
    from saasbase.core.runtime import Runtime
    from saasbase.core.apis.membership_api import MembershipApiImpl


class EntityBase:
    """Helpers shared by all entities."""

    _runtime: "Runtime"
    _actor: ActorRef | None

    def __init__(self, runtime: "Runtime", actor: ActorRef | None) -> None:
        self._runtime = runtime
        self._actor = actor

    @property
    def _subject(self) -> str:
        return self._actor.subject() if self._actor else "system"


class OrganizationEntity(EntityBase):
    def __init__(
        self, runtime: "Runtime", actor: ActorRef | None, record: OrganizationRecord
    ) -> None:
        super().__init__(runtime, actor)
        self._record = record

    @property
    def record(self) -> OrganizationRecord:
        return self._record

    @property
    def id(self) -> UUID:
        return self._record.id

    @property
    def slug(self) -> str:
        return self._record.slug

    @property
    def name(self) -> str:
        return self._record.name

    @property
    def metadata(self) -> dict[str, Any]:
        return dict(self._record.metadata)

    @property
    def ref(self) -> ResourceRef:
        return ResourceRef(ResourceType.ORGANIZATION, self._record.id)

    @property
    def projects(self):
        from saasbase.core.apis.project_api import ProjectApiImpl

        org_id = self._record.id
        api = ProjectApiImpl(self._runtime, self._actor)

        class _Collection:
            def create(_self, name: str, metadata: dict[str, Any] | None = None):
                return api.create(org_id, name, metadata)

            def list(_self):
                return api.list_by_organization(org_id)

            def find_by_id(_self, id: UUID):
                return api.find_by_id(id)

        return _Collection()

    @property
    def members(self):
        return _member_collection(self._runtime, self._actor, self.ref)

    def rename(self, new_name: str) -> "OrganizationEntity":
        from saasbase.core.apis.organization_api import OrganizationApiImpl

        api = OrganizationApiImpl(self._runtime, self._actor)
        return api.update(self._record.id, UpdateOrganizationRequest(name=new_name))  # type: ignore[return-value]

    def put_metadata(self, key: str, value: Any) -> "OrganizationEntity":
        from saasbase.core.apis.organization_api import OrganizationApiImpl

        merged = dict(self._record.metadata)
        merged[key] = value
        api = OrganizationApiImpl(self._runtime, self._actor)
        return api.update(self._record.id, UpdateOrganizationRequest(metadata=merged))  # type: ignore[return-value]

    def remove_metadata(self, key: str) -> "OrganizationEntity":
        from saasbase.core.apis.organization_api import OrganizationApiImpl

        merged = dict(self._record.metadata)
        merged.pop(key, None)
        api = OrganizationApiImpl(self._runtime, self._actor)
        return api.update(self._record.id, UpdateOrganizationRequest(metadata=merged))  # type: ignore[return-value]

    def delete(self) -> None:
        from saasbase.core.apis.organization_api import OrganizationApiImpl

        OrganizationApiImpl(self._runtime, self._actor).delete(self._record.id)


class ProjectEntity(EntityBase):
    def __init__(self, runtime: "Runtime", actor: ActorRef | None, record: ProjectRecord) -> None:
        super().__init__(runtime, actor)
        self._record = record

    @property
    def record(self) -> ProjectRecord:
        return self._record

    @property
    def id(self) -> UUID:
        return self._record.id

    @property
    def organization_id(self) -> UUID:
        return self._record.organization_id

    @property
    def name(self) -> str:
        return self._record.name

    @property
    def metadata(self) -> dict[str, Any]:
        return dict(self._record.metadata)

    @property
    def ref(self) -> ResourceRef:
        return ResourceRef(ResourceType.PROJECT, self._record.id)

    @property
    def documents(self):
        from saasbase.core.apis.document_api import DocumentApiImpl

        project_id = self._record.id
        api = DocumentApiImpl(self._runtime, self._actor)

        class _Collection:
            def upload(_self, name: str, content: BinaryIO, media_type: str,
                       version_name: str | None = None, metadata: dict[str, Any] | None = None):
                return api.upload(project_id, name, content, media_type, version_name, metadata)

            def upload_path(_self, path: Path, media_type: str | None = None):
                return api.upload_path(project_id, path, media_type)

            def list(_self):
                return api.list_by_project(project_id)

            def find_by_id(_self, id: UUID):
                return api.find_by_id(id)

        return _Collection()

    @property
    def api_calls(self):
        from saasbase.api.apicall import ApiCallCreateRequest
        from saasbase.core.apis.apicall_api import ApiCallApiImpl

        project_id = self._record.id
        api = ApiCallApiImpl(self._runtime, self._actor)

        class _Collection:
            def create(_self, request: ApiCallCreateRequest):
                return api.create(project_id, request)

            def list(_self):
                return api.list_by_project(project_id)

            def find_by_id(_self, id: UUID):
                return api.find_by_id(id)

        return _Collection()

    @property
    def members(self):
        return _member_collection(self._runtime, self._actor, self.ref)

    def rename(self, new_name: str) -> "ProjectEntity":
        from saasbase.core.apis.project_api import ProjectApiImpl

        return ProjectApiImpl(self._runtime, self._actor).update(  # type: ignore[return-value]
            self._record.id, UpdateProjectRequest(name=new_name)
        )

    def put_metadata(self, key: str, value: Any) -> "ProjectEntity":
        from saasbase.core.apis.project_api import ProjectApiImpl

        merged = dict(self._record.metadata)
        merged[key] = value
        return ProjectApiImpl(self._runtime, self._actor).update(  # type: ignore[return-value]
            self._record.id, UpdateProjectRequest(metadata=merged)
        )

    def remove_metadata(self, key: str) -> "ProjectEntity":
        from saasbase.core.apis.project_api import ProjectApiImpl

        merged = dict(self._record.metadata)
        merged.pop(key, None)
        return ProjectApiImpl(self._runtime, self._actor).update(  # type: ignore[return-value]
            self._record.id, UpdateProjectRequest(metadata=merged)
        )

    def delete(self) -> None:
        from saasbase.core.apis.project_api import ProjectApiImpl

        ProjectApiImpl(self._runtime, self._actor).delete(self._record.id)


class DocumentVersionEntity(EntityBase):
    def __init__(
        self, runtime: "Runtime", actor: ActorRef | None, record: DocumentVersionRecord
    ) -> None:
        super().__init__(runtime, actor)
        self._record = record

    @property
    def record(self) -> DocumentVersionRecord:
        return self._record

    @property
    def id(self) -> UUID:
        return self._record.id

    @property
    def document_id(self) -> UUID:
        return self._record.document_id

    @property
    def organization_id(self) -> UUID:
        return self._record.organization_id

    @property
    def project_id(self) -> UUID:
        return self._record.project_id

    @property
    def version_number(self) -> int:
        return self._record.version_number

    @property
    def version_name(self) -> str:
        return self._record.version_name

    @property
    def name(self) -> str:
        return self._record.name

    @property
    def media_type(self) -> str:
        return self._record.media_type

    @property
    def size_bytes(self) -> int:
        return self._record.size_bytes

    @property
    def checksum(self) -> str:
        return self._record.checksum

    @property
    def storage_uri(self) -> str:
        return self._record.storage_uri

    @property
    def metadata(self) -> dict[str, Any]:
        return dict(self._record.metadata)

    @property
    def created_at(self) -> datetime:
        return self._record.created_at

    @property
    def created_by_subject(self) -> str:
        return self._record.created_by_subject

    def open_stream(self) -> BinaryIO:
        return self._runtime.storage.read(self._record.storage_key)

    def download_to(self, target_directory: Path) -> Path:
        return self._runtime.storage.download(self._record.storage_key, target_directory)


class DocumentEntity(EntityBase):
    def __init__(self, runtime: "Runtime", actor: ActorRef | None, record: DocumentRecord) -> None:
        super().__init__(runtime, actor)
        self._record = record

    @property
    def record(self) -> DocumentRecord:
        return self._record

    @property
    def id(self) -> UUID:
        return self._record.id

    @property
    def organization_id(self) -> UUID:
        return self._record.organization_id

    @property
    def project_id(self) -> UUID:
        return self._record.project_id

    @property
    def name(self) -> str:
        return self._record.name

    @property
    def resource_type(self) -> ResourceType:
        return ResourceType.DOCUMENT

    @property
    def ref(self) -> ResourceRef:
        return ResourceRef(ResourceType.DOCUMENT, self._record.id)

    @property
    def metadata(self) -> dict[str, Any]:
        return dict(self._record.metadata)

    @property
    def members(self):
        return _member_collection(self._runtime, self._actor, self.ref)

    @property
    def current_version_id(self) -> UUID:
        return self._record.current_version_id

    @property
    def current_version_number(self) -> int:
        return self._record.current_version_number

    @property
    def current_version_name(self) -> str:
        return self._record.current_version_name

    @property
    def media_type(self) -> str:
        return self._record.media_type

    @property
    def size_bytes(self) -> int:
        return self._record.size_bytes

    @property
    def checksum(self) -> str:
        return self._record.checksum

    @property
    def storage_uri(self) -> str:
        return self._record.storage_uri

    def open_stream(self) -> BinaryIO:
        return self._runtime.storage.read(self._record.storage_key)

    def download_to(self, target_directory: Path) -> Path:
        return self._runtime.storage.download(self._record.storage_key, target_directory)

    def rename(self, new_name: str) -> "DocumentEntity":
        from saasbase.core.apis.document_api import DocumentApiImpl

        return DocumentApiImpl(self._runtime, self._actor).update(  # type: ignore[return-value]
            self._record.id, UpdateDocumentRequest(name=new_name)
        )

    def put_metadata(self, key: str, value: Any) -> "DocumentEntity":
        from saasbase.core.apis.document_api import DocumentApiImpl

        merged = dict(self._record.metadata)
        merged[key] = value
        return DocumentApiImpl(self._runtime, self._actor).update(  # type: ignore[return-value]
            self._record.id, UpdateDocumentRequest(metadata=merged)
        )

    def remove_metadata(self, key: str) -> "DocumentEntity":
        from saasbase.core.apis.document_api import DocumentApiImpl

        merged = dict(self._record.metadata)
        merged.pop(key, None)
        return DocumentApiImpl(self._runtime, self._actor).update(  # type: ignore[return-value]
            self._record.id, UpdateDocumentRequest(metadata=merged)
        )

    def delete(self) -> None:
        from saasbase.core.apis.document_api import DocumentApiImpl

        DocumentApiImpl(self._runtime, self._actor).delete(self._record.id)


class ApiCallEntity(EntityBase):
    def __init__(self, runtime: "Runtime", actor: ActorRef | None, record: ApiCallRecord) -> None:
        super().__init__(runtime, actor)
        self._record = record

    @property
    def record(self) -> ApiCallRecord:
        return self._record

    @property
    def id(self) -> UUID:
        return self._record.id

    @property
    def organization_id(self) -> UUID:
        return self._record.organization_id

    @property
    def project_id(self) -> UUID:
        return self._record.project_id

    @property
    def name(self) -> str:
        return self._record.name

    @property
    def resource_type(self) -> ResourceType:
        return ResourceType.API_CALL

    @property
    def ref(self) -> ResourceRef:
        return ResourceRef(ResourceType.API_CALL, self._record.id)

    @property
    def metadata(self) -> dict[str, Any]:
        return dict(self._record.metadata)

    @property
    def members(self):
        return _member_collection(self._runtime, self._actor, self.ref)

    @property
    def operation_key(self) -> str:
        return self._record.operation_key

    @property
    def external_request_id(self) -> str | None:
        return self._record.external_request_id

    @property
    def idempotency_key(self) -> str | None:
        return self._record.idempotency_key

    @property
    def correlation_id(self) -> str | None:
        return self._record.correlation_id

    @property
    def status(self) -> ApiCallStatus:
        return self._record.status

    @property
    def requested_at(self) -> datetime:
        return self._record.requested_at

    @property
    def responded_at(self) -> datetime | None:
        return self._record.responded_at

    @property
    def request_payload(self) -> dict[str, Any]:
        return dict(self._record.request_payload)

    @property
    def response_payload(self) -> dict[str, Any]:
        return dict(self._record.response_payload)

    def rename(self, new_name: str) -> "ApiCallEntity":
        from saasbase.api.apicall import ApiCallUpdateRequest
        from saasbase.core.apis.apicall_api import ApiCallApiImpl

        api = ApiCallApiImpl(self._runtime, self._actor)
        updated = replace(self._record, name=new_name, updated_at=self._runtime.clock())
        api._update_record(updated)  # type: ignore[attr-defined]
        return ApiCallEntity(self._runtime, self._actor, updated)

    def put_metadata(self, key: str, value: Any) -> "ApiCallEntity":
        from saasbase.core.apis.apicall_api import ApiCallApiImpl

        merged = dict(self._record.metadata)
        merged[key] = value
        api = ApiCallApiImpl(self._runtime, self._actor)
        updated = replace(self._record, metadata=merged, updated_at=self._runtime.clock())
        api._update_record(updated)  # type: ignore[attr-defined]
        return ApiCallEntity(self._runtime, self._actor, updated)

    def remove_metadata(self, key: str) -> "ApiCallEntity":
        from saasbase.core.apis.apicall_api import ApiCallApiImpl

        merged = dict(self._record.metadata)
        merged.pop(key, None)
        api = ApiCallApiImpl(self._runtime, self._actor)
        updated = replace(self._record, metadata=merged, updated_at=self._runtime.clock())
        api._update_record(updated)  # type: ignore[attr-defined]
        return ApiCallEntity(self._runtime, self._actor, updated)

    def delete(self) -> None:
        from saasbase.core.apis.apicall_api import ApiCallApiImpl

        ApiCallApiImpl(self._runtime, self._actor).delete(self._record.id)

    def update_status(self, status: ApiCallStatus) -> "ApiCallEntity":
        from saasbase.api.apicall import ApiCallUpdateRequest
        from saasbase.core.apis.apicall_api import ApiCallApiImpl

        return ApiCallApiImpl(self._runtime, self._actor).update(  # type: ignore[return-value]
            self._record.id, ApiCallUpdateRequest(status=status)
        )

    def set_response_payload(self, payload: dict[str, Any]) -> "ApiCallEntity":
        from saasbase.api.apicall import ApiCallUpdateRequest
        from saasbase.core.apis.apicall_api import ApiCallApiImpl

        return ApiCallApiImpl(self._runtime, self._actor).update(  # type: ignore[return-value]
            self._record.id, ApiCallUpdateRequest(response_payload=payload)
        )


class ExecutionEntity(EntityBase):
    def __init__(
        self, runtime: "Runtime", actor: ActorRef | None, record: ExecutionRecord
    ) -> None:
        super().__init__(runtime, actor)
        self._record = record

    @property
    def record(self) -> ExecutionRecord:
        return self._record

    @property
    def id(self) -> UUID:
        return self._record.id

    @property
    def organization_id(self) -> UUID:
        return self._record.organization_id

    @property
    def project_id(self) -> UUID:
        return self._record.project_id

    @property
    def operation(self) -> str:
        return self._record.operation

    @property
    def status(self):
        return self._record.status

    @property
    def actor(self):
        return self._record.actor

    @property
    def target(self):
        return self._record.target

    @property
    def correlation_id(self) -> str | None:
        return self._record.correlation_id

    @property
    def parent_execution_id(self) -> UUID | None:
        return self._record.parent_execution_id

    @property
    def agent_version(self) -> str | None:
        return self._record.agent_version

    @property
    def model_provider(self) -> str | None:
        return self._record.model_provider

    @property
    def model_name(self) -> str | None:
        return self._record.model_name

    @property
    def confidence(self) -> float | None:
        return self._record.confidence

    @property
    def warnings(self) -> list[str]:
        return list(self._record.warnings)

    @property
    def provenance(self) -> dict[str, Any]:
        return dict(self._record.provenance)

    @property
    def started_at(self) -> datetime | None:
        return self._record.started_at

    @property
    def ended_at(self) -> datetime | None:
        return self._record.ended_at

    @property
    def input(self) -> dict[str, Any]:
        return dict(self._record.input)

    @property
    def output(self) -> dict[str, Any]:
        return dict(self._record.output)

    @property
    def metadata(self) -> dict[str, Any]:
        return dict(self._record.metadata)


class MembershipEntity(EntityBase):
    def __init__(
        self, runtime: "Runtime", actor: ActorRef | None, record: MembershipRecord
    ) -> None:
        super().__init__(runtime, actor)
        self._record = record

    @property
    def record(self) -> MembershipRecord:
        return self._record

    @property
    def id(self) -> UUID:
        return self._record.id

    @property
    def actor(self) -> ActorRef:
        return self._record.actor

    @property
    def role(self) -> Role:
        return self._record.role

    @property
    def resource(self) -> ResourceRef:
        return self._record.resource

    @property
    def inherited(self) -> bool:
        return self._record.inherited

    @property
    def granted_at(self) -> datetime:
        return self._record.granted_at


class ApiKeyEntity(EntityBase):
    def __init__(
        self, runtime: "Runtime", actor: ActorRef | None, record: ApiKeyRecord
    ) -> None:
        super().__init__(runtime, actor)
        self._record = record

    @property
    def record(self) -> ApiKeyRecord:
        return self._record

    @property
    def id(self) -> UUID:
        return self._record.id

    @property
    def name(self) -> str:
        return self._record.name

    @property
    def prefix(self) -> str:
        return self._record.prefix

    @property
    def scope(self) -> ResourceRef:
        return self._record.scope

    @property
    def role(self) -> Role:
        return self._record.role

    @property
    def organization_id(self) -> UUID:
        return self._record.organization_id

    @property
    def project_id(self) -> UUID | None:
        return self._record.project_id

    @property
    def expires_at(self) -> datetime | None:
        return self._record.expires_at

    @property
    def last_used_at(self) -> datetime | None:
        return self._record.last_used_at

    @property
    def revoked_at(self) -> datetime | None:
        return self._record.revoked_at

    @property
    def metadata(self) -> dict[str, Any]:
        return dict(self._record.metadata)

    @property
    def created_at(self) -> datetime:
        return self._record.created_at

    @property
    def updated_at(self) -> datetime:
        return self._record.updated_at

    @property
    def created_by_subject(self) -> str:
        return self._record.created_by_subject

    @property
    def actor(self) -> ActorRef:
        return ActorRef(ActorType.API_KEY, str(self._record.id))

    @property
    def is_active(self) -> bool:
        if self._record.revoked_at is not None:
            return False
        if self._record.expires_at is not None:
            return self._record.expires_at > self._runtime.clock()
        return True


class AuditEventEntity(EntityBase):
    def __init__(
        self, runtime: "Runtime", actor: ActorRef | None, record: AuditEventRecord
    ) -> None:
        super().__init__(runtime, actor)
        self._record = record

    @property
    def record(self) -> AuditEventRecord:
        return self._record

    @property
    def id(self) -> UUID:
        return self._record.id

    @property
    def occurred_at(self) -> datetime:
        return self._record.occurred_at

    @property
    def actor(self) -> ActorRef:
        return self._record.actor

    @property
    def action(self) -> AuditAction:
        return self._record.action

    @property
    def resource(self) -> ResourceRef:
        return self._record.resource

    @property
    def organization_id(self) -> UUID | None:
        return self._record.organization_id

    @property
    def project_id(self) -> UUID | None:
        return self._record.project_id

    @property
    def correlation_id(self) -> str | None:
        return self._record.correlation_id

    @property
    def details(self) -> dict[str, Any]:
        return dict(self._record.details)


def _member_collection(
    runtime: "Runtime", actor: ActorRef | None, resource: ResourceRef
):
    """Build a MemberCollection adapter scoped to the given resource."""

    from saasbase.core.apis.membership_api import MembershipApiImpl

    api = MembershipApiImpl(runtime, actor)

    class _Collection:
        def add(_self, a: ActorRef, role: Role):
            return api.grant(resource, a, role)

        def list(_self):
            return api.list(resource)

        def list_effective(_self):
            return api.list_effective(resource)

        def revoke(_self, a: ActorRef, role: Role):
            return api.revoke(resource, a, role)

        def remove(_self, a: ActorRef):
            return api.remove(resource, a)

    return _Collection()
