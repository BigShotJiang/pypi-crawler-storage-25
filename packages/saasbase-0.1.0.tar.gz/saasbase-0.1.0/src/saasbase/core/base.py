from __future__ import annotations

from saasbase.api.apicall import ApiCallApi
from saasbase.api.apikey import ApiKeyApi
from saasbase.api.audit import AuditApi
from saasbase.api.authorization import AuthorizationApi
from saasbase.api.document import DocumentApi
from saasbase.api.execution import ExecutionApi
from saasbase.api.membership import MembershipApi
from saasbase.api.organization import OrganizationApi
from saasbase.api.project import ProjectApi
from saasbase.common.actor import ActorRef, ActorType
from saasbase.core.apis.api_key_api import ApiKeyApiImpl
from saasbase.core.apis.apicall_api import ApiCallApiImpl
from saasbase.core.apis.audit_api import AuditApiImpl
from saasbase.core.apis.authorization_api import AuthorizationApiImpl
from saasbase.core.apis.document_api import DocumentApiImpl
from saasbase.core.apis.execution_api import ExecutionApiImpl
from saasbase.core.apis.membership_api import MembershipApiImpl
from saasbase.core.apis.organization_api import OrganizationApiImpl
from saasbase.core.apis.project_api import ProjectApiImpl
from saasbase.core.runtime import Runtime


class DefaultSaaSBase:
    """Concrete SaaSBase runtime. Created by DefaultSaaSBaseBuilder."""

    def __init__(self, runtime: Runtime) -> None:
        self._runtime = runtime

    # ----- unscoped APIs (system actor) -----

    @property
    def organizations(self) -> OrganizationApi:
        return OrganizationApiImpl(self._runtime, None)

    @property
    def projects(self) -> ProjectApi:
        return ProjectApiImpl(self._runtime, None)

    @property
    def documents(self) -> DocumentApi:
        return DocumentApiImpl(self._runtime, None)

    @property
    def api_calls(self) -> ApiCallApi:
        return ApiCallApiImpl(self._runtime, None)

    @property
    def memberships(self) -> MembershipApi:
        return MembershipApiImpl(self._runtime, None)

    @property
    def audits(self) -> AuditApi:
        return AuditApiImpl(self._runtime, None)

    @property
    def authorization(self) -> AuthorizationApi:
        return AuthorizationApiImpl(self._runtime, None)

    @property
    def executions(self) -> ExecutionApi:
        return ExecutionApiImpl(self._runtime, None)

    @property
    def api_keys(self) -> ApiKeyApi:
        return ApiKeyApiImpl(self._runtime, None)

    # ----- actor contexts -----

    def as_actor(self, actor: ActorRef) -> "DefaultSaaSBaseContext":
        return DefaultSaaSBaseContext(self._runtime, actor)

    def as_user(self, user_id: str) -> "DefaultSaaSBaseContext":
        return self.as_actor(ActorRef(ActorType.USER, user_id))

    def as_service(self, service_id: str) -> "DefaultSaaSBaseContext":
        return self.as_actor(ActorRef(ActorType.SERVICE, service_id))

    def as_agent(self, agent_id: str) -> "DefaultSaaSBaseContext":
        return self.as_actor(ActorRef(ActorType.AGENT, agent_id))

    def as_group(self, group_id: str) -> "DefaultSaaSBaseContext":
        return self.as_actor(ActorRef(ActorType.GROUP, group_id))

    # ----- lifecycle -----

    def close(self) -> None:
        if self._runtime.closer is not None:
            try:
                self._runtime.closer()
            finally:
                self._runtime.closer = None

    def __enter__(self) -> "DefaultSaaSBase":
        return self

    def __exit__(self, exc_type, exc, tb) -> None:
        self.close()


class DefaultSaaSBaseContext:
    def __init__(self, runtime: Runtime, actor: ActorRef) -> None:
        self._runtime = runtime
        self._actor = actor

    @property
    def actor(self) -> ActorRef:
        return self._actor

    @property
    def organizations(self) -> OrganizationApi:
        return OrganizationApiImpl(self._runtime, self._actor)

    @property
    def projects(self) -> ProjectApi:
        return ProjectApiImpl(self._runtime, self._actor)

    @property
    def documents(self) -> DocumentApi:
        return DocumentApiImpl(self._runtime, self._actor)

    @property
    def api_calls(self) -> ApiCallApi:
        return ApiCallApiImpl(self._runtime, self._actor)

    @property
    def memberships(self) -> MembershipApi:
        return MembershipApiImpl(self._runtime, self._actor)

    @property
    def audits(self) -> AuditApi:
        return AuditApiImpl(self._runtime, self._actor)

    @property
    def authorization(self) -> AuthorizationApi:
        return AuthorizationApiImpl(self._runtime, self._actor)

    @property
    def executions(self) -> ExecutionApi:
        return ExecutionApiImpl(self._runtime, self._actor)

    @property
    def api_keys(self) -> ApiKeyApi:
        return ApiKeyApiImpl(self._runtime, self._actor)

    def close(self) -> None:
        return None

    def __enter__(self) -> "DefaultSaaSBaseContext":
        return self

    def __exit__(self, exc_type, exc, tb) -> None:
        self.close()
