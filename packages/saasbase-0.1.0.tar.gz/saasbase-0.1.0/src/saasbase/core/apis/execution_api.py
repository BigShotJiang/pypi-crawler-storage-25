from __future__ import annotations

from dataclasses import replace
from uuid import UUID

from saasbase.api.execution import (
    CompleteExecutionRequest,
    Execution,
    FailExecutionRequest,
    StartExecutionRequest,
)
from saasbase.common.actor import ActorRef
from saasbase.common.audit import AuditAction
from saasbase.common.exceptions import NotFoundError
from saasbase.common.pagination import Page, PageRequest
from saasbase.common.query import ExecutionQuery
from saasbase.common.resource import ResourceRef, ResourceType
from saasbase.common.status import ExecutionStatus
from saasbase.core.entities import ExecutionEntity
from saasbase.core.runtime import Runtime
from saasbase.spi.persistence import ExecutionRecord


class ExecutionApiImpl:
    def __init__(self, runtime: Runtime, actor: ActorRef | None) -> None:
        self._runtime = runtime
        self._actor = actor

    def _wrap(self, record: ExecutionRecord) -> ExecutionEntity:
        return ExecutionEntity(self._runtime, self._actor, record)

    def start(self, request: StartExecutionRequest) -> Execution:
        now = self._runtime.clock()
        actor = self._actor or ActorRef.service("system")
        record = ExecutionRecord(
            id=self._runtime.id_generator(),
            organization_id=request.organization_id,
            project_id=request.project_id,
            operation=request.operation,
            status=ExecutionStatus.RUNNING,
            actor=actor,
            target=request.target,
            correlation_id=request.correlation_id,
            parent_execution_id=request.parent_execution_id,
            agent_version=request.agent_version,
            model_provider=request.model_provider,
            model_name=request.model_name,
            confidence=request.confidence,
            warnings=list(request.warnings or []),
            provenance=dict(request.provenance or {}),
            started_at=now,
            ended_at=None,
            input=dict(request.input or {}),
            output={},
            metadata=dict(request.metadata or {}),
        )

        def _commit() -> ExecutionRecord:
            created = self._runtime.executions.create(record)
            target_ref = created.target or ResourceRef(ResourceType.PROJECT, created.project_id)
            self._runtime.recorder.record(
                actor=actor,
                action=AuditAction.EXECUTION_STARTED,
                resource=target_ref,
                organization_id=created.organization_id,
                project_id=created.project_id,
                correlation_id=created.correlation_id,
                details={
                    "execution_id": str(created.id),
                    "operation": created.operation,
                    "model_provider": created.model_provider,
                    "model_name": created.model_name,
                },
            )
            return created

        return self._wrap(self._runtime.tx.required(_commit))

    def complete(self, execution_id: UUID, request: CompleteExecutionRequest) -> Execution:
        existing = self._runtime.executions.find_by_id(execution_id)
        if existing is None:
            raise NotFoundError(f"Execution not found: {execution_id}")
        merged_metadata = (
            dict(request.metadata) if request.metadata is not None else dict(existing.metadata)
        )
        updated = replace(
            existing,
            status=ExecutionStatus.COMPLETED,
            ended_at=self._runtime.clock(),
            output=dict(request.output or {}),
            metadata=merged_metadata,
        )

        def _commit() -> ExecutionRecord:
            persisted = self._runtime.executions.update(updated)
            target_ref = persisted.target or ResourceRef(ResourceType.PROJECT, persisted.project_id)
            self._runtime.recorder.record(
                actor=persisted.actor,
                action=AuditAction.EXECUTION_COMPLETED,
                resource=target_ref,
                organization_id=persisted.organization_id,
                project_id=persisted.project_id,
                correlation_id=persisted.correlation_id,
                details={"execution_id": str(persisted.id)},
            )
            return persisted

        return self._wrap(self._runtime.tx.required(_commit))

    def fail(self, execution_id: UUID, request: FailExecutionRequest) -> Execution:
        existing = self._runtime.executions.find_by_id(execution_id)
        if existing is None:
            raise NotFoundError(f"Execution not found: {execution_id}")
        metadata = dict(existing.metadata)
        if request.metadata:
            metadata.update(request.metadata)
        if request.error_code:
            metadata["error_code"] = request.error_code
        if request.error_message:
            metadata["error_message"] = request.error_message
        updated = replace(
            existing,
            status=ExecutionStatus.FAILED,
            ended_at=self._runtime.clock(),
            metadata=metadata,
        )

        def _commit() -> ExecutionRecord:
            persisted = self._runtime.executions.update(updated)
            target_ref = persisted.target or ResourceRef(ResourceType.PROJECT, persisted.project_id)
            self._runtime.recorder.record(
                actor=persisted.actor,
                action=AuditAction.EXECUTION_FAILED,
                resource=target_ref,
                organization_id=persisted.organization_id,
                project_id=persisted.project_id,
                correlation_id=persisted.correlation_id,
                details={
                    "execution_id": str(persisted.id),
                    "error_code": request.error_code,
                    "error_message": request.error_message,
                },
            )
            return persisted

        return self._wrap(self._runtime.tx.required(_commit))

    def find_by_id(self, execution_id: UUID) -> Execution | None:
        record = self._runtime.executions.find_by_id(execution_id)
        return self._wrap(record) if record else None

    def list_by_project(self, project_id: UUID) -> list[Execution]:
        return [self._wrap(r) for r in self._runtime.executions.list_by_project(project_id)]

    def list_by_correlation_id(self, correlation_id: str) -> list[Execution]:
        return [
            self._wrap(r) for r in self._runtime.executions.list_by_correlation_id(correlation_id)
        ]

    def list_children(self, parent_execution_id: UUID) -> list[Execution]:
        return [self._wrap(r) for r in self._runtime.executions.list_children(parent_execution_id)]

    def query(self, query: ExecutionQuery, page_request: PageRequest) -> Page[Execution]:
        page = self._runtime.executions.query(query, page_request)
        return Page(
            items=[self._wrap(r) for r in page.items],
            total_items=page.total_items,
            page=page.page,
            size=page.size,
            total_pages=page.total_pages,
        )
