from __future__ import annotations

from saasbase.api.authorization import (
    AuthorizationExplanation,
    AuthorizationExplanationSource,
    EffectiveAuthorizationRole,
)
from saasbase.common.actor import ActorRef
from saasbase.common.authz import Action, AuthorizationPolicy
from saasbase.common.exceptions import PermissionDeniedError
from saasbase.common.resource import ResourceRef
from saasbase.core.runtime import Runtime


class AuthorizationApiImpl:
    def __init__(self, runtime: Runtime, actor: ActorRef | None) -> None:
        self._runtime = runtime
        self._actor = actor

    def can(self, actor: ActorRef, action: Action, resource: ResourceRef) -> bool:
        if self._runtime.authz.can(actor, action, resource):
            return True
        for parent in self._runtime.hierarchy.ancestors(resource):
            if self._runtime.authz.can(actor, action, parent):
                return True
        return False

    def check(self, actor: ActorRef, action: Action, resource: ResourceRef) -> None:
        if not self.can(actor, action, resource):
            raise PermissionDeniedError(
                f"{actor.subject()} is not permitted to {action.value} on {resource.subject()}"
            )

    def effective_roles(
        self, actor: ActorRef, resource: ResourceRef
    ) -> list[EffectiveAuthorizationRole]:
        effective: list[EffectiveAuthorizationRole] = []
        for m in self._runtime.memberships.list(resource):
            if m.actor == actor:
                effective.append(
                    EffectiveAuthorizationRole(
                        role=m.role,
                        granted_on=resource,
                        effective_on=resource,
                        inherited=False,
                        actions=sorted(
                            AuthorizationPolicy.actions(m.role), key=lambda a: a.value
                        ),
                    )
                )
        for parent in self._runtime.hierarchy.ancestors(resource):
            for m in self._runtime.memberships.list(parent):
                if m.actor == actor:
                    effective.append(
                        EffectiveAuthorizationRole(
                            role=m.role,
                            granted_on=parent,
                            effective_on=resource,
                            inherited=True,
                            actions=sorted(
                                AuthorizationPolicy.actions(m.role), key=lambda a: a.value
                            ),
                        )
                    )
        return effective

    def explain(
        self, actor: ActorRef, action: Action, resource: ResourceRef
    ) -> AuthorizationExplanation:
        scopes = self._runtime.hierarchy.scopes(resource)
        effective = self.effective_roles(actor, resource)
        matching = [
            ear for ear in effective if AuthorizationPolicy.allows(ear.role, action)
        ]
        if matching:
            return AuthorizationExplanation(
                actor=actor,
                action=action,
                resource=resource,
                allowed=True,
                source=AuthorizationExplanationSource.EFFECTIVE_ROLE,
                reason=f"Allowed by role(s): {', '.join(ear.role.value for ear in matching)}",
                evaluated_scopes=scopes,
                effective_roles=effective,
                matching_roles=matching,
            )
        if self.can(actor, action, resource):
            return AuthorizationExplanation(
                actor=actor,
                action=action,
                resource=resource,
                allowed=True,
                source=AuthorizationExplanationSource.AUTHZ_ENGINE,
                reason="Allowed by authorization engine",
                evaluated_scopes=scopes,
                effective_roles=effective,
                matching_roles=[],
            )
        return AuthorizationExplanation(
            actor=actor,
            action=action,
            resource=resource,
            allowed=False,
            source=AuthorizationExplanationSource.NONE,
            reason="No effective role grants the requested action",
            evaluated_scopes=scopes,
            effective_roles=effective,
            matching_roles=[],
        )

    def who_can(self, action: Action, resource: ResourceRef) -> list[ActorRef]:
        actors: set[ActorRef] = set()
        for scope in self._runtime.hierarchy.scopes(resource):
            actors.update(self._runtime.authz.who_can(action, scope))
        return sorted(actors, key=lambda a: (a.type.value, a.id))

    def who_can_explain(
        self, action: Action, resource: ResourceRef
    ) -> list[AuthorizationExplanation]:
        return [self.explain(actor, action, resource) for actor in self.who_can(action, resource)]
