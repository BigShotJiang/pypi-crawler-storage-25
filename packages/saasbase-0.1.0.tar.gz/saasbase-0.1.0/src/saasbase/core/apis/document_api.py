from __future__ import annotations

import mimetypes
from pathlib import Path
from typing import Any, BinaryIO
from uuid import UUID

from saasbase.api.document import (
    CreateDocumentVersionRequest,
    Document,
    DocumentVersion,
    UpdateDocumentRequest,
    UploadDocumentRequest,
)
from saasbase.common.actor import ActorRef
from saasbase.common.audit import AuditAction
from saasbase.common.exceptions import NotFoundError, ValidationError
from saasbase.common.pagination import Page, PageRequest
from saasbase.common.query import DocumentQuery, DocumentVersionQuery
from saasbase.common.resource import ResourceRef
from saasbase.core.entities import DocumentEntity, DocumentVersionEntity
from saasbase.core.runtime import Runtime
from saasbase.spi.persistence import DocumentRecord, DocumentVersionRecord
from saasbase.spi.storage import StoreDocumentRequest


class DocumentApiImpl:
    def __init__(self, runtime: Runtime, actor: ActorRef | None) -> None:
        self._runtime = runtime
        self._actor = actor

    def _subject(self) -> str:
        return self._actor.subject() if self._actor else "system"

    def _wrap(self, record: DocumentRecord) -> DocumentEntity:
        return DocumentEntity(self._runtime, self._actor, record)

    def _wrap_version(self, record: DocumentVersionRecord) -> DocumentVersionEntity:
        return DocumentVersionEntity(self._runtime, self._actor, record)

    def upload(
        self,
        project_id: UUID,
        name: str,
        content: BinaryIO,
        media_type: str,
        version_name: str | None = None,
        metadata: dict[str, Any] | None = None,
    ) -> Document:
        return self.upload_from(
            UploadDocumentRequest(
                project_id=project_id,
                name=name,
                content=content,
                media_type=media_type,
                version_name=version_name,
                metadata=metadata or {},
            )
        )

    def upload_path(
        self, project_id: UUID, path: Path, media_type: str | None = None
    ) -> Document:
        if not path.exists() or not path.is_file():
            raise ValidationError(f"File does not exist: {path}")
        mime = media_type or mimetypes.guess_type(path.name)[0] or "application/octet-stream"
        with path.open("rb") as handle:
            return self.upload(project_id, path.name, handle, mime)

    def upload_from(self, request: UploadDocumentRequest) -> Document:
        project = self._runtime.projects.find_by_id(request.project_id)
        if project is None:
            raise NotFoundError(f"Project not found: {request.project_id}")

        stored = self._runtime.storage.store(
            StoreDocumentRequest(
                name=request.name,
                media_type=request.media_type,
                content=request.content,
                metadata=dict(request.metadata or {}),
            )
        )

        now = self._runtime.clock()
        doc_id = self._runtime.id_generator()
        version_id = self._runtime.id_generator()
        version_name = request.version_name or "v1"

        doc = DocumentRecord(
            id=doc_id,
            organization_id=project.organization_id,
            project_id=project.id,
            current_version_id=version_id,
            current_version_number=1,
            current_version_name=version_name,
            name=request.name,
            media_type=stored.media_type,
            size_bytes=stored.size_bytes,
            checksum=stored.checksum,
            storage_key=stored.storage_key,
            storage_uri=stored.uri,
            metadata=dict(request.metadata or {}),
            created_at=now,
            updated_at=now,
            created_by_subject=self._subject(),
        )
        version = DocumentVersionRecord(
            id=version_id,
            document_id=doc_id,
            organization_id=project.organization_id,
            project_id=project.id,
            version_number=1,
            version_name=version_name,
            name=request.name,
            media_type=stored.media_type,
            size_bytes=stored.size_bytes,
            checksum=stored.checksum,
            storage_key=stored.storage_key,
            storage_uri=stored.uri,
            metadata=dict(request.metadata or {}),
            created_at=now,
            created_by_subject=self._subject(),
        )

        def _commit() -> DocumentRecord:
            self._runtime.document_versions.create(version)
            created = self._runtime.documents.create(doc)
            self._runtime.recorder.record(
                actor=self._actor or ActorRef.service("system"),
                action=AuditAction.DOCUMENT_CREATED,
                resource=ResourceRef.document(created.id),
                organization_id=created.organization_id,
                project_id=created.project_id,
                details={"name": created.name, "version_name": version_name, "size_bytes": created.size_bytes},
            )
            return created

        return self._wrap(self._runtime.tx.required(_commit))

    def find_by_id(self, id: UUID) -> Document | None:
        record = self._runtime.documents.find_by_id(id)
        return self._wrap(record) if record else None

    def list_by_project(self, project_id: UUID) -> list[Document]:
        return [self._wrap(r) for r in self._runtime.documents.list_by_project(project_id)]

    def query(self, query: DocumentQuery, page_request: PageRequest) -> Page[Document]:
        page = self._runtime.documents.query(query, page_request)
        return Page(
            items=[self._wrap(r) for r in page.items],
            total_items=page.total_items,
            page=page.page,
            size=page.size,
            total_pages=page.total_pages,
        )

    def create_version(self, id: UUID, request: CreateDocumentVersionRequest) -> Document:
        existing = self._runtime.documents.find_by_id(id)
        if existing is None:
            raise NotFoundError(f"Document not found: {id}")

        stored = self._runtime.storage.store(
            StoreDocumentRequest(
                name=request.name or existing.name,
                media_type=request.media_type,
                content=request.content,
                metadata=dict(request.metadata or {}),
            )
        )

        now = self._runtime.clock()
        version_number = existing.current_version_number + 1
        version_name = request.version_name or f"v{version_number}"
        version_id = self._runtime.id_generator()

        version = DocumentVersionRecord(
            id=version_id,
            document_id=existing.id,
            organization_id=existing.organization_id,
            project_id=existing.project_id,
            version_number=version_number,
            version_name=version_name,
            name=request.name or existing.name,
            media_type=stored.media_type,
            size_bytes=stored.size_bytes,
            checksum=stored.checksum,
            storage_key=stored.storage_key,
            storage_uri=stored.uri,
            metadata=dict(request.metadata or {}),
            created_at=now,
            created_by_subject=self._subject(),
        )
        updated = DocumentRecord(
            id=existing.id,
            organization_id=existing.organization_id,
            project_id=existing.project_id,
            current_version_id=version_id,
            current_version_number=version_number,
            current_version_name=version_name,
            name=request.name or existing.name,
            media_type=stored.media_type,
            size_bytes=stored.size_bytes,
            checksum=stored.checksum,
            storage_key=stored.storage_key,
            storage_uri=stored.uri,
            metadata=existing.metadata,
            created_at=existing.created_at,
            updated_at=now,
            created_by_subject=existing.created_by_subject,
        )

        def _commit() -> DocumentRecord:
            self._runtime.document_versions.create(version)
            persisted = self._runtime.documents.update(updated)
            self._runtime.recorder.record(
                actor=self._actor or ActorRef.service("system"),
                action=AuditAction.DOCUMENT_VERSION_CREATED,
                resource=ResourceRef.document(persisted.id),
                organization_id=persisted.organization_id,
                project_id=persisted.project_id,
                details={
                    "version_name": version_name,
                    "version_number": version_number,
                    "size_bytes": persisted.size_bytes,
                },
            )
            return persisted

        return self._wrap(self._runtime.tx.required(_commit))

    def find_version_by_id(self, id: UUID) -> DocumentVersion | None:
        record = self._runtime.document_versions.find_by_id(id)
        return self._wrap_version(record) if record else None

    def find_version(self, document_id: UUID, version_name: str) -> DocumentVersion | None:
        record = self._runtime.document_versions.find_by_document_id_and_version_name(
            document_id, version_name
        )
        return self._wrap_version(record) if record else None

    def list_versions(self, document_id: UUID) -> list[DocumentVersion]:
        return [
            self._wrap_version(r)
            for r in self._runtime.document_versions.list_by_document_id(document_id)
        ]

    def query_versions(
        self, query: DocumentVersionQuery, page_request: PageRequest
    ) -> Page[DocumentVersion]:
        page = self._runtime.document_versions.query(query, page_request)
        return Page(
            items=[self._wrap_version(r) for r in page.items],
            total_items=page.total_items,
            page=page.page,
            size=page.size,
            total_pages=page.total_pages,
        )

    def update(self, id: UUID, request: UpdateDocumentRequest) -> Document:
        existing = self._runtime.documents.find_by_id(id)
        if existing is None:
            raise NotFoundError(f"Document not found: {id}")

        name = request.name if request.name is not None else existing.name
        metadata = (
            dict(request.metadata) if request.metadata is not None else dict(existing.metadata)
        )
        updated = DocumentRecord(
            id=existing.id,
            organization_id=existing.organization_id,
            project_id=existing.project_id,
            current_version_id=existing.current_version_id,
            current_version_number=existing.current_version_number,
            current_version_name=existing.current_version_name,
            name=name,
            media_type=existing.media_type,
            size_bytes=existing.size_bytes,
            checksum=existing.checksum,
            storage_key=existing.storage_key,
            storage_uri=existing.storage_uri,
            metadata=metadata,
            created_at=existing.created_at,
            updated_at=self._runtime.clock(),
            created_by_subject=existing.created_by_subject,
        )

        def _commit() -> DocumentRecord:
            persisted = self._runtime.documents.update(updated)
            self._runtime.recorder.record(
                actor=self._actor or ActorRef.service("system"),
                action=AuditAction.DOCUMENT_UPDATED,
                resource=ResourceRef.document(persisted.id),
                organization_id=persisted.organization_id,
                project_id=persisted.project_id,
                details={"name": persisted.name},
            )
            return persisted

        return self._wrap(self._runtime.tx.required(_commit))

    def delete(self, id: UUID) -> None:
        def _commit() -> None:
            existing = self._runtime.documents.find_by_id(id)
            if existing is None:
                raise NotFoundError(f"Document not found: {id}")
            versions = self._runtime.document_versions.list_by_document_id(id)
            self._runtime.document_versions.delete_by_document_id(id)
            self._runtime.documents.delete(id)
            for v in versions:
                try:
                    self._runtime.storage.delete(v.storage_key)
                except Exception:
                    pass
            self._runtime.recorder.record(
                actor=self._actor or ActorRef.service("system"),
                action=AuditAction.DOCUMENT_DELETED,
                resource=ResourceRef.document(id),
                organization_id=existing.organization_id,
                project_id=existing.project_id,
                details={"name": existing.name},
            )

        self._runtime.tx.required(_commit)
