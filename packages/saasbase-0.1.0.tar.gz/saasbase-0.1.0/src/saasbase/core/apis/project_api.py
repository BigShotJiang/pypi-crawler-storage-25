from __future__ import annotations

from typing import Any
from uuid import UUID

from saasbase.api.project import CreateProjectRequest, Project, UpdateProjectRequest
from saasbase.common.actor import ActorRef
from saasbase.common.audit import AuditAction
from saasbase.common.exceptions import NotFoundError
from saasbase.common.pagination import Page, PageRequest
from saasbase.common.query import ProjectQuery
from saasbase.common.resource import ResourceRef
from saasbase.core.entities import ProjectEntity
from saasbase.core.runtime import Runtime
from saasbase.spi.persistence import ProjectRecord


class ProjectApiImpl:
    def __init__(self, runtime: Runtime, actor: ActorRef | None) -> None:
        self._runtime = runtime
        self._actor = actor

    def _subject(self) -> str:
        return self._actor.subject() if self._actor else "system"

    def _wrap(self, record: ProjectRecord) -> ProjectEntity:
        return ProjectEntity(self._runtime, self._actor, record)

    def create(
        self,
        organization_id: UUID,
        name: str,
        metadata: dict[str, Any] | None = None,
    ) -> Project:
        return self.create_from(
            CreateProjectRequest(
                organization_id=organization_id, name=name, metadata=metadata or {}
            )
        )

    def create_from(self, request: CreateProjectRequest) -> Project:
        now = self._runtime.clock()
        record = ProjectRecord(
            id=self._runtime.id_generator(),
            organization_id=request.organization_id,
            name=request.name,
            metadata=dict(request.metadata or {}),
            created_at=now,
            updated_at=now,
            created_by_subject=self._subject(),
        )

        def _commit() -> ProjectRecord:
            created = self._runtime.projects.create(record)
            self._runtime.recorder.record(
                actor=self._actor or ActorRef.service("system"),
                action=AuditAction.PROJECT_CREATED,
                resource=ResourceRef.project(created.id),
                organization_id=created.organization_id,
                project_id=created.id,
                details={"name": created.name},
            )
            return created

        return self._wrap(self._runtime.tx.required(_commit))

    def find_by_id(self, id: UUID) -> Project | None:
        record = self._runtime.projects.find_by_id(id)
        return self._wrap(record) if record else None

    def list_by_organization(self, organization_id: UUID) -> list[Project]:
        return [self._wrap(r) for r in self._runtime.projects.list_by_organization(organization_id)]

    def query(self, query: ProjectQuery, page_request: PageRequest) -> Page[Project]:
        page = self._runtime.projects.query(query, page_request)
        return Page(
            items=[self._wrap(r) for r in page.items],
            total_items=page.total_items,
            page=page.page,
            size=page.size,
            total_pages=page.total_pages,
        )

    def update(self, id: UUID, request: UpdateProjectRequest) -> Project:
        existing = self._runtime.projects.find_by_id(id)
        if existing is None:
            raise NotFoundError(f"Project not found: {id}")
        name = request.name if request.name is not None else existing.name
        metadata = (
            dict(request.metadata) if request.metadata is not None else dict(existing.metadata)
        )
        updated = ProjectRecord(
            id=existing.id,
            organization_id=existing.organization_id,
            name=name,
            metadata=metadata,
            created_at=existing.created_at,
            updated_at=self._runtime.clock(),
            created_by_subject=existing.created_by_subject,
        )

        def _commit() -> ProjectRecord:
            persisted = self._runtime.projects.update(updated)
            self._runtime.recorder.record(
                actor=self._actor or ActorRef.service("system"),
                action=AuditAction.PROJECT_UPDATED,
                resource=ResourceRef.project(persisted.id),
                organization_id=persisted.organization_id,
                project_id=persisted.id,
                details={"name": persisted.name},
            )
            return persisted

        return self._wrap(self._runtime.tx.required(_commit))

    def delete(self, id: UUID) -> None:
        def _commit() -> None:
            existing = self._runtime.projects.find_by_id(id)
            if existing is None:
                raise NotFoundError(f"Project not found: {id}")
            self._runtime.projects.delete(id)
            self._runtime.recorder.record(
                actor=self._actor or ActorRef.service("system"),
                action=AuditAction.PROJECT_DELETED,
                resource=ResourceRef.project(id),
                organization_id=existing.organization_id,
                project_id=id,
                details={"name": existing.name},
            )

        self._runtime.tx.required(_commit)
