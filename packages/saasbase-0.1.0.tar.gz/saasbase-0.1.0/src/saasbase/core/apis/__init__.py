"""Concrete API implementations — wired by DefaultSaaSBase."""
