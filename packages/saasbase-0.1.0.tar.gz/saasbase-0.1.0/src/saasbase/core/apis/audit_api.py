from __future__ import annotations

from saasbase.api.audit import AuditEvent
from saasbase.common.actor import ActorRef
from saasbase.common.pagination import Page, PageRequest
from saasbase.common.query import AuditQuery
from saasbase.common.resource import ResourceRef
from saasbase.core.entities import AuditEventEntity
from saasbase.core.runtime import Runtime
from saasbase.spi.audit import AuditEventRecord


class AuditApiImpl:
    def __init__(self, runtime: Runtime, actor: ActorRef | None) -> None:
        self._runtime = runtime
        self._actor = actor

    def _wrap(self, record: AuditEventRecord) -> AuditEventEntity:
        return AuditEventEntity(self._runtime, self._actor, record)

    def list(self, resource: ResourceRef) -> list[AuditEvent]:
        return [self._wrap(r) for r in self._runtime.audit.list(resource)]

    def list_by_correlation_id(self, correlation_id: str) -> list[AuditEvent]:
        return [self._wrap(r) for r in self._runtime.audit.list_by_correlation_id(correlation_id)]

    def query(self, query: AuditQuery, page_request: PageRequest) -> Page[AuditEvent]:
        page = self._runtime.audit.query(query, page_request)
        return Page(
            items=[self._wrap(r) for r in page.items],
            total_items=page.total_items,
            page=page.page,
            size=page.size,
            total_pages=page.total_pages,
        )

    def prune(self, query: AuditQuery) -> int:
        return self._runtime.audit.prune(query)
