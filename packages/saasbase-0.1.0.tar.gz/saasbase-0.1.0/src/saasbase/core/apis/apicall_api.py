from __future__ import annotations

from uuid import UUID

from saasbase.api.apicall import ApiCall, ApiCallCreateRequest, ApiCallUpdateRequest
from saasbase.common.actor import ActorRef
from saasbase.common.audit import AuditAction
from saasbase.common.exceptions import NotFoundError
from saasbase.common.pagination import Page, PageRequest
from saasbase.common.query import ApiCallQuery
from saasbase.common.resource import ResourceRef
from saasbase.common.status import ApiCallStatus
from saasbase.core.entities import ApiCallEntity
from saasbase.core.runtime import Runtime
from saasbase.spi.persistence import ApiCallRecord


class ApiCallApiImpl:
    def __init__(self, runtime: Runtime, actor: ActorRef | None) -> None:
        self._runtime = runtime
        self._actor = actor

    def _subject(self) -> str:
        return self._actor.subject() if self._actor else "system"

    def _wrap(self, record: ApiCallRecord) -> ApiCallEntity:
        return ApiCallEntity(self._runtime, self._actor, record)

    def _update_record(self, record: ApiCallRecord) -> ApiCallRecord:
        """Internal hook used by ApiCallEntity for in-place mutations."""
        return self._runtime.tx.required(lambda: self._runtime.api_calls.update(record))

    def create(self, project_id: UUID, request: ApiCallCreateRequest) -> ApiCall:
        project = self._runtime.projects.find_by_id(project_id)
        if project is None:
            raise NotFoundError(f"Project not found: {project_id}")

        now = self._runtime.clock()
        record = ApiCallRecord(
            id=self._runtime.id_generator(),
            organization_id=project.organization_id,
            project_id=project.id,
            name=request.name,
            operation_key=request.operation_key,
            external_request_id=request.external_request_id,
            idempotency_key=request.idempotency_key,
            correlation_id=request.correlation_id,
            status=ApiCallStatus.RECEIVED,
            requested_at=now,
            responded_at=None,
            request_payload=dict(request.request_payload or {}),
            response_payload={},
            metadata=dict(request.metadata or {}),
            created_at=now,
            updated_at=now,
            created_by_subject=self._subject(),
        )

        def _commit() -> ApiCallRecord:
            created = self._runtime.api_calls.create(record)
            self._runtime.recorder.record(
                actor=self._actor or ActorRef.service("system"),
                action=AuditAction.API_CALL_CREATED,
                resource=ResourceRef.api_call(created.id),
                organization_id=created.organization_id,
                project_id=created.project_id,
                correlation_id=created.correlation_id,
                details={
                    "name": created.name,
                    "operation_key": created.operation_key,
                    "status": created.status.value,
                },
            )
            return created

        return self._wrap(self._runtime.tx.required(_commit))

    def find_by_id(self, id: UUID) -> ApiCall | None:
        record = self._runtime.api_calls.find_by_id(id)
        return self._wrap(record) if record else None

    def list_by_project(self, project_id: UUID) -> list[ApiCall]:
        return [self._wrap(r) for r in self._runtime.api_calls.list_by_project(project_id)]

    def list_by_correlation_id(self, correlation_id: str) -> list[ApiCall]:
        return [
            self._wrap(r) for r in self._runtime.api_calls.list_by_correlation_id(correlation_id)
        ]

    def query(self, query: ApiCallQuery, page_request: PageRequest) -> Page[ApiCall]:
        page = self._runtime.api_calls.query(query, page_request)
        return Page(
            items=[self._wrap(r) for r in page.items],
            total_items=page.total_items,
            page=page.page,
            size=page.size,
            total_pages=page.total_pages,
        )

    def update(self, id: UUID, request: ApiCallUpdateRequest) -> ApiCall:
        existing = self._runtime.api_calls.find_by_id(id)
        if existing is None:
            raise NotFoundError(f"ApiCall not found: {id}")

        status = request.status if request.status is not None else existing.status
        response_payload = (
            dict(request.response_payload)
            if request.response_payload is not None
            else dict(existing.response_payload)
        )
        metadata = (
            dict(request.metadata) if request.metadata is not None else dict(existing.metadata)
        )
        now = self._runtime.clock()
        responded_at = existing.responded_at
        if status in (ApiCallStatus.COMPLETED, ApiCallStatus.FAILED, ApiCallStatus.CANCELLED):
            responded_at = responded_at or now

        updated = ApiCallRecord(
            id=existing.id,
            organization_id=existing.organization_id,
            project_id=existing.project_id,
            name=existing.name,
            operation_key=existing.operation_key,
            external_request_id=existing.external_request_id,
            idempotency_key=existing.idempotency_key,
            correlation_id=existing.correlation_id,
            status=status,
            requested_at=existing.requested_at,
            responded_at=responded_at,
            request_payload=dict(existing.request_payload),
            response_payload=response_payload,
            metadata=metadata,
            created_at=existing.created_at,
            updated_at=now,
            created_by_subject=existing.created_by_subject,
        )

        def _commit() -> ApiCallRecord:
            persisted = self._runtime.api_calls.update(updated)
            self._runtime.recorder.record(
                actor=self._actor or ActorRef.service("system"),
                action=AuditAction.API_CALL_UPDATED,
                resource=ResourceRef.api_call(persisted.id),
                organization_id=persisted.organization_id,
                project_id=persisted.project_id,
                correlation_id=persisted.correlation_id,
                details={"status": persisted.status.value},
            )
            return persisted

        return self._wrap(self._runtime.tx.required(_commit))

    def delete(self, id: UUID) -> None:
        def _commit() -> None:
            existing = self._runtime.api_calls.find_by_id(id)
            if existing is None:
                raise NotFoundError(f"ApiCall not found: {id}")
            self._runtime.api_calls.delete(id)
            self._runtime.recorder.record(
                actor=self._actor or ActorRef.service("system"),
                action=AuditAction.API_CALL_DELETED,
                resource=ResourceRef.api_call(id),
                organization_id=existing.organization_id,
                project_id=existing.project_id,
                correlation_id=existing.correlation_id,
                details={"name": existing.name},
            )

        self._runtime.tx.required(_commit)
