from __future__ import annotations

import hashlib
import hmac
import secrets
from dataclasses import replace
from datetime import datetime
from typing import Any
from uuid import UUID

from saasbase.api.apikey import (
    ApiKey,
    CreateApiKeyRequest,
    CreatedApiKey,
    UpdateApiKeyRequest,
)
from saasbase.common.actor import ActorRef, ActorType
from saasbase.common.audit import AuditAction
from saasbase.common.authz import Role
from saasbase.common.exceptions import NotFoundError, ValidationError
from saasbase.common.resource import ResourceRef, ResourceType
from saasbase.core.entities import ApiKeyEntity
from saasbase.core.runtime import Runtime
from saasbase.spi.persistence import ApiKeyRecord, MembershipRecord

TOKEN_SCHEME = "sbk"
PREFIX_LEN = 12
SECRET_BYTES = 32  # 256 bits of entropy; base64url-encoded ~43 chars


def _hash_secret(secret: str) -> str:
    return hashlib.sha256(secret.encode("utf-8")).hexdigest()


def _generate_prefix() -> str:
    # 12 chars of base32-style lowercase letters and digits; collisions vanishingly rare and a
    # unique index guards us either way.
    alphabet = "0123456789abcdefghijklmnopqrstuvwxyz"
    return "".join(secrets.choice(alphabet) for _ in range(PREFIX_LEN))


def _generate_secret() -> str:
    return secrets.token_urlsafe(SECRET_BYTES)


def build_token(prefix: str, secret: str) -> str:
    return f"{TOKEN_SCHEME}_{prefix}.{secret}"


def parse_token(token: str) -> tuple[str, str] | None:
    """Split ``sbk_<prefix>.<secret>`` into its pieces, or ``None`` if malformed."""
    if not token or not token.startswith(f"{TOKEN_SCHEME}_"):
        return None
    remainder = token[len(TOKEN_SCHEME) + 1 :]
    dot = remainder.find(".")
    if dot <= 0 or dot == len(remainder) - 1:
        return None
    prefix = remainder[:dot]
    secret = remainder[dot + 1 :]
    if not prefix or not secret:
        return None
    return prefix, secret


def _resource_organization_id(
    runtime: Runtime, scope: ResourceRef
) -> tuple[UUID, UUID | None]:
    """Resolve (organization_id, project_id) pair for a supported scope."""
    if scope.type == ResourceType.ORGANIZATION:
        org = runtime.organizations.find_by_id(scope.id)
        if org is None:
            raise NotFoundError(f"Organization not found: {scope.id}")
        return scope.id, None
    if scope.type == ResourceType.PROJECT:
        project = runtime.projects.find_by_id(scope.id)
        if project is None:
            raise NotFoundError(f"Project not found: {scope.id}")
        return project.organization_id, project.id
    raise ValidationError(
        f"API keys can only be scoped to ORGANIZATION or PROJECT, not {scope.type.name}"
    )


class ApiKeyApiImpl:
    def __init__(self, runtime: Runtime, actor: ActorRef | None) -> None:
        self._runtime = runtime
        self._actor = actor

    def _subject(self) -> str:
        return self._actor.subject() if self._actor else "system"

    def _wrap(self, record: ApiKeyRecord) -> ApiKeyEntity:
        return ApiKeyEntity(self._runtime, self._actor, record)

    def create(self, request: CreateApiKeyRequest) -> CreatedApiKey:
        if not request.name or not request.name.strip():
            raise ValidationError("api key name must not be blank")

        organization_id, project_id = _resource_organization_id(self._runtime, request.scope)

        prefix = _generate_prefix()
        secret = _generate_secret()
        now = self._runtime.clock()
        record = ApiKeyRecord(
            id=self._runtime.id_generator(),
            name=request.name,
            prefix=prefix,
            secret_hash=_hash_secret(secret),
            scope=request.scope,
            role=request.role,
            organization_id=organization_id,
            project_id=project_id,
            expires_at=request.expires_at,
            last_used_at=None,
            revoked_at=None,
            metadata=dict(request.metadata or {}),
            created_at=now,
            updated_at=now,
            created_by_subject=self._subject(),
        )

        def _commit() -> ApiKeyRecord:
            persisted = self._runtime.api_keys.create(record)
            api_key_actor = ActorRef(ActorType.API_KEY, str(persisted.id))
            # Grant the role so authorization checks automatically allow whatever the role covers
            # on the scoped resource (and inherited scopes via the hierarchy resolver).
            self._runtime.authz.grant(request.scope, api_key_actor, request.role)
            # Persist a MembershipRecord too so `memberships.list()` / effective-role queries
            # surface the API key just like any other grant.
            self._runtime.memberships.create(
                MembershipRecord(
                    id=self._runtime.id_generator(),
                    resource=request.scope,
                    actor=api_key_actor,
                    role=request.role,
                    inherited=False,
                    granted_at=now,
                )
            )
            self._runtime.recorder.record(
                actor=self._actor or ActorRef.service("system"),
                action=AuditAction.MEMBERSHIP_GRANTED,
                resource=request.scope,
                organization_id=organization_id,
                project_id=project_id,
                details={
                    "api_key_id": str(persisted.id),
                    "api_key_prefix": prefix,
                    "role": request.role.value,
                    "origin": "api_key",
                },
            )
            return persisted

        persisted = self._runtime.tx.required(_commit)
        return CreatedApiKey(api_key=self._wrap(persisted), token=build_token(prefix, secret))

    def find_by_id(self, id: UUID) -> ApiKey | None:
        record = self._runtime.api_keys.find_by_id(id)
        return self._wrap(record) if record else None

    def list_by_scope(self, scope: ResourceRef) -> list[ApiKey]:
        return [self._wrap(r) for r in self._runtime.api_keys.list_by_scope(scope)]

    def list_by_organization(self, organization_id: UUID) -> list[ApiKey]:
        return [
            self._wrap(r) for r in self._runtime.api_keys.list_by_organization(organization_id)
        ]

    def update(self, id: UUID, request: UpdateApiKeyRequest) -> ApiKey:
        existing = self._runtime.api_keys.find_by_id(id)
        if existing is None:
            raise NotFoundError(f"ApiKey not found: {id}")
        metadata = (
            dict(request.metadata) if request.metadata is not None else dict(existing.metadata)
        )
        updated = replace(
            existing,
            name=request.name if request.name is not None else existing.name,
            expires_at=request.expires_at if request.expires_at is not None else existing.expires_at,
            metadata=metadata,
            updated_at=self._runtime.clock(),
        )

        def _commit() -> ApiKeyRecord:
            return self._runtime.api_keys.update(updated)

        return self._wrap(self._runtime.tx.required(_commit))

    def revoke(self, id: UUID) -> ApiKey:
        existing = self._runtime.api_keys.find_by_id(id)
        if existing is None:
            raise NotFoundError(f"ApiKey not found: {id}")
        if existing.revoked_at is not None:
            return self._wrap(existing)
        now = self._runtime.clock()
        updated = replace(existing, revoked_at=now, updated_at=now)

        def _commit() -> ApiKeyRecord:
            persisted = self._runtime.api_keys.update(updated)
            api_key_actor = ActorRef(ActorType.API_KEY, str(persisted.id))
            # Drop the backing membership so authz engines that cache grants stop honoring this key.
            try:
                self._runtime.authz.revoke(persisted.scope, api_key_actor, persisted.role)
            except Exception:
                # Tolerate engines that don't track the grant explicitly (e.g. OpenFGA with
                # divergent tuples) — the revoked_at check on authenticate() remains authoritative.
                pass
            self._runtime.memberships.revoke(persisted.scope, api_key_actor, persisted.role)
            self._runtime.recorder.record(
                actor=self._actor or ActorRef.service("system"),
                action=AuditAction.MEMBERSHIP_REVOKED,
                resource=persisted.scope,
                organization_id=persisted.organization_id,
                project_id=persisted.project_id,
                details={
                    "api_key_id": str(persisted.id),
                    "api_key_prefix": persisted.prefix,
                    "role": persisted.role.value,
                    "origin": "api_key",
                },
            )
            return persisted

        return self._wrap(self._runtime.tx.required(_commit))

    def delete(self, id: UUID) -> None:
        existing = self._runtime.api_keys.find_by_id(id)
        if existing is None:
            raise NotFoundError(f"ApiKey not found: {id}")
        api_key_actor = ActorRef(ActorType.API_KEY, str(existing.id))

        def _commit() -> None:
            try:
                self._runtime.authz.revoke(existing.scope, api_key_actor, existing.role)
            except Exception:
                pass
            self._runtime.memberships.remove(existing.scope, api_key_actor)
            self._runtime.api_keys.delete(id)

        self._runtime.tx.required(_commit)

    def authenticate(self, token: str) -> ApiKey | None:
        parsed = parse_token(token)
        if parsed is None:
            return None
        prefix, secret = parsed
        record = self._runtime.api_keys.find_by_prefix(prefix)
        if record is None:
            return None
        if not hmac.compare_digest(record.secret_hash, _hash_secret(secret)):
            return None
        if record.revoked_at is not None:
            return None
        now = self._runtime.clock()
        if record.expires_at is not None and record.expires_at <= now:
            return None

        self._runtime.api_keys.touch_last_used(record.id, now)
        return self._wrap(replace(record, last_used_at=now))
