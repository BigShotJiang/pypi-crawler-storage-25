from __future__ import annotations

from typing import Any
from uuid import UUID

from saasbase.api.organization import (
    CreateOrganizationRequest,
    Organization,
    UpdateOrganizationRequest,
)
from saasbase.common.actor import ActorRef
from saasbase.common.audit import AuditAction
from saasbase.common.exceptions import NotFoundError
from saasbase.common.pagination import Page, PageRequest
from saasbase.common.query import OrganizationQuery
from saasbase.common.resource import ResourceRef
from saasbase.core.entities import OrganizationEntity
from saasbase.core.runtime import Runtime
from saasbase.spi.persistence import OrganizationRecord


class OrganizationApiImpl:
    def __init__(self, runtime: Runtime, actor: ActorRef | None) -> None:
        self._runtime = runtime
        self._actor = actor

    def _wrap(self, record: OrganizationRecord) -> OrganizationEntity:
        return OrganizationEntity(self._runtime, self._actor, record)

    def _subject(self) -> str:
        return self._actor.subject() if self._actor else "system"

    def create(
        self,
        slug: str,
        name: str | None = None,
        metadata: dict[str, Any] | None = None,
    ) -> Organization:
        return self.create_from(
            CreateOrganizationRequest(slug=slug, name=name or slug, metadata=metadata or {})
        )

    def create_from(self, request: CreateOrganizationRequest) -> Organization:
        now = self._runtime.clock()
        record = OrganizationRecord(
            id=self._runtime.id_generator(),
            slug=request.slug,
            name=request.name or request.slug,
            metadata=dict(request.metadata or {}),
            created_at=now,
            updated_at=now,
            created_by_subject=self._subject(),
        )

        def _commit() -> OrganizationRecord:
            created = self._runtime.organizations.create(record)
            self._runtime.recorder.record(
                actor=self._actor or ActorRef.service("system"),
                action=AuditAction.ORGANIZATION_CREATED,
                resource=ResourceRef.organization(created.id),
                organization_id=created.id,
                details={"slug": created.slug, "name": created.name},
            )
            return created

        return self._wrap(self._runtime.tx.required(_commit))

    def find_by_id(self, id: UUID) -> Organization | None:
        record = self._runtime.organizations.find_by_id(id)
        return self._wrap(record) if record else None

    def find_by_slug(self, slug: str) -> Organization | None:
        record = self._runtime.organizations.find_by_slug(slug)
        return self._wrap(record) if record else None

    def list(self) -> list[Organization]:
        return [self._wrap(r) for r in self._runtime.organizations.list()]

    def query(self, query: OrganizationQuery, page_request: PageRequest) -> Page[Organization]:
        page = self._runtime.organizations.query(query, page_request)
        return Page(
            items=[self._wrap(r) for r in page.items],
            total_items=page.total_items,
            page=page.page,
            size=page.size,
            total_pages=page.total_pages,
        )

    def update(self, id: UUID, request: UpdateOrganizationRequest) -> Organization:
        existing = self._runtime.organizations.find_by_id(id)
        if existing is None:
            raise NotFoundError(f"Organization not found: {id}")
        name = request.name if request.name is not None else existing.name
        metadata = (
            dict(request.metadata) if request.metadata is not None else dict(existing.metadata)
        )
        updated = OrganizationRecord(
            id=existing.id,
            slug=existing.slug,
            name=name,
            metadata=metadata,
            created_at=existing.created_at,
            updated_at=self._runtime.clock(),
            created_by_subject=existing.created_by_subject,
        )

        def _commit() -> OrganizationRecord:
            persisted = self._runtime.organizations.update(updated)
            self._runtime.recorder.record(
                actor=self._actor or ActorRef.service("system"),
                action=AuditAction.ORGANIZATION_UPDATED,
                resource=ResourceRef.organization(persisted.id),
                organization_id=persisted.id,
                details={"name": persisted.name},
            )
            return persisted

        return self._wrap(self._runtime.tx.required(_commit))

    def delete(self, id: UUID) -> None:
        def _commit() -> None:
            existing = self._runtime.organizations.find_by_id(id)
            if existing is None:
                raise NotFoundError(f"Organization not found: {id}")
            self._runtime.organizations.delete(id)
            self._runtime.recorder.record(
                actor=self._actor or ActorRef.service("system"),
                action=AuditAction.ORGANIZATION_DELETED,
                resource=ResourceRef.organization(id),
                organization_id=id,
                details={"slug": existing.slug},
            )

        self._runtime.tx.required(_commit)
