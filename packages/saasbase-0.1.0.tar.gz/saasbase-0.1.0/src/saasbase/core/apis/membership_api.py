from __future__ import annotations

from saasbase.api.membership import Membership
from saasbase.common.actor import ActorRef
from saasbase.common.audit import AuditAction
from saasbase.common.authz import Role
from saasbase.common.resource import ResourceRef, ResourceType
from saasbase.core.entities import MembershipEntity
from saasbase.core.runtime import Runtime
from saasbase.spi.persistence import MembershipRecord


def _resource_org_project(runtime: Runtime, resource: ResourceRef) -> tuple:
    """Resolve (organization_id, project_id) for a resource, for audit enrichment."""
    if resource.type == ResourceType.ORGANIZATION:
        return resource.id, None
    if resource.type == ResourceType.PROJECT:
        project = runtime.projects.find_by_id(resource.id)
        return (project.organization_id if project else None), resource.id
    if resource.type == ResourceType.DOCUMENT:
        doc = runtime.documents.find_by_id(resource.id)
        if doc:
            return doc.organization_id, doc.project_id
        return None, None
    if resource.type == ResourceType.API_CALL:
        call = runtime.api_calls.find_by_id(resource.id)
        if call:
            return call.organization_id, call.project_id
        return None, None
    return None, None


class MembershipApiImpl:
    def __init__(self, runtime: Runtime, actor: ActorRef | None) -> None:
        self._runtime = runtime
        self._actor = actor

    def _wrap(self, record: MembershipRecord) -> MembershipEntity:
        return MembershipEntity(self._runtime, self._actor, record)

    def grant(self, resource: ResourceRef, actor: ActorRef, role: Role) -> Membership:
        now = self._runtime.clock()
        record = MembershipRecord(
            id=self._runtime.id_generator(),
            resource=resource,
            actor=actor,
            role=role,
            inherited=False,
            granted_at=now,
        )

        def _commit() -> MembershipRecord:
            persisted = self._runtime.memberships.create(record)
            self._runtime.authz.grant(resource, actor, role)
            org_id, project_id = _resource_org_project(self._runtime, resource)
            self._runtime.recorder.record(
                actor=self._actor or ActorRef.service("system"),
                action=AuditAction.MEMBERSHIP_GRANTED,
                resource=resource,
                organization_id=org_id,
                project_id=project_id,
                details={
                    "actor": actor.subject(),
                    "role": role.value,
                },
            )
            return persisted

        return self._wrap(self._runtime.tx.required(_commit))

    def list(self, resource: ResourceRef) -> list[Membership]:
        return [self._wrap(r) for r in self._runtime.memberships.list(resource)]

    def list_effective(self, resource: ResourceRef) -> list[Membership]:
        direct = self._runtime.memberships.list(resource)
        result: list[MembershipRecord] = list(direct)
        for parent in self._runtime.hierarchy.ancestors(resource):
            for m in self._runtime.memberships.list(parent):
                result.append(
                    MembershipRecord(
                        id=m.id,
                        resource=resource,
                        actor=m.actor,
                        role=m.role,
                        inherited=True,
                        granted_at=m.granted_at,
                    )
                )
        return [self._wrap(r) for r in result]

    def revoke(self, resource: ResourceRef, actor: ActorRef, role: Role) -> None:
        def _commit() -> None:
            self._runtime.memberships.revoke(resource, actor, role)
            self._runtime.authz.revoke(resource, actor, role)
            org_id, project_id = _resource_org_project(self._runtime, resource)
            self._runtime.recorder.record(
                actor=self._actor or ActorRef.service("system"),
                action=AuditAction.MEMBERSHIP_REVOKED,
                resource=resource,
                organization_id=org_id,
                project_id=project_id,
                details={
                    "actor": actor.subject(),
                    "role": role.value,
                },
            )

        self._runtime.tx.required(_commit)

    def remove(self, resource: ResourceRef, actor: ActorRef) -> None:
        def _commit() -> None:
            existing = [
                m for m in self._runtime.memberships.list(resource) if m.actor == actor
            ]
            self._runtime.memberships.remove(resource, actor)
            for m in existing:
                self._runtime.authz.revoke(resource, actor, m.role)
            org_id, project_id = _resource_org_project(self._runtime, resource)
            self._runtime.recorder.record(
                actor=self._actor or ActorRef.service("system"),
                action=AuditAction.MEMBERSHIP_REMOVED,
                resource=resource,
                organization_id=org_id,
                project_id=project_id,
                details={"actor": actor.subject()},
            )

        self._runtime.tx.required(_commit)
