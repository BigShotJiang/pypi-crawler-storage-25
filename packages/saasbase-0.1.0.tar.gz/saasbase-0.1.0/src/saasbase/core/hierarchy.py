"""Resolves a resource's ancestor chain so authorization can inherit roles from parent scopes."""

from __future__ import annotations

from saasbase.common.resource import ResourceRef, ResourceType
from saasbase.spi.persistence import (
    ApiCallRepository,
    DocumentRepository,
    ProjectRepository,
)


class ResourceHierarchyResolver:
    def __init__(
        self,
        projects: ProjectRepository,
        documents: DocumentRepository,
        api_calls: ApiCallRepository,
    ) -> None:
        self._projects = projects
        self._documents = documents
        self._api_calls = api_calls

    def ancestors(self, resource: ResourceRef) -> list[ResourceRef]:
        """Return the list of parent scopes above `resource`, nearest first."""
        if resource.type == ResourceType.ORGANIZATION:
            return []
        if resource.type == ResourceType.PROJECT:
            project = self._projects.find_by_id(resource.id)
            if project is None:
                return []
            return [ResourceRef.organization(project.organization_id)]
        if resource.type == ResourceType.DOCUMENT:
            doc = self._documents.find_by_id(resource.id)
            if doc is None:
                return []
            return [
                ResourceRef.project(doc.project_id),
                ResourceRef.organization(doc.organization_id),
            ]
        if resource.type == ResourceType.API_CALL:
            call = self._api_calls.find_by_id(resource.id)
            if call is None:
                return []
            return [
                ResourceRef.project(call.project_id),
                ResourceRef.organization(call.organization_id),
            ]
        return []

    def scopes(self, resource: ResourceRef) -> list[ResourceRef]:
        """Return the resource itself plus all ancestors, in order."""
        return [resource, *self.ancestors(resource)]
