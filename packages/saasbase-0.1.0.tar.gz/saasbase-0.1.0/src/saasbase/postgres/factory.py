from __future__ import annotations

from importlib import resources
from typing import Any
from urllib.parse import parse_qs, urlparse

from saasbase.common.exceptions import SaaSBaseError

DEFAULT_URL = "jdbc:postgresql://localhost:5432/saasbase?user=saasbase&password=saasbase"
MIGRATION_RESOURCE = "V1__init.sql"


def jdbc_url_to_dsn(url: str) -> str:
    """Translate a jdbc:postgresql://... URL into a libpq-style DSN.

    Accepts either a jdbc-style URL (to match the Java SDK convention) or a plain
    `postgresql://` URL / DSN. Returns a DSN usable by psycopg.
    """
    raw = url
    if raw.startswith("jdbc:postgresql:"):
        raw = raw[len("jdbc:"):]
    # If already DSN with key=value pairs, pass through.
    if "=" in raw and "://" not in raw:
        return raw

    parsed = urlparse(raw)
    scheme = parsed.scheme or "postgresql"
    host = parsed.hostname or "localhost"
    port = parsed.port or 5432
    dbname = (parsed.path or "/").lstrip("/") or "postgres"
    qs = parse_qs(parsed.query or "")
    user = parsed.username or (qs.get("user", [None])[0])
    password = parsed.password or (qs.get("password", [None])[0])

    params = [f"host={host}", f"port={port}", f"dbname={dbname}"]
    if user:
        params.append(f"user={user}")
    if password:
        params.append(f"password={password}")
    # Pass through any other parameters (e.g. sslmode) except user/password/stringtype.
    for k, v in qs.items():
        if k in ("user", "password", "stringtype"):
            continue
        if v:
            params.append(f"{k}={v[0]}")
    return " ".join(params)


def _load_migration_sql() -> str:
    pkg_files = resources.files("saasbase.postgres.migrations")
    return (pkg_files / MIGRATION_RESOURCE).read_text(encoding="utf-8")


class PostgresFactory:
    """Creates psycopg Connection objects and applies the V1 migration on first build."""

    def __init__(self, url: str | None = None) -> None:
        self._url = url or DEFAULT_URL
        self._dsn = jdbc_url_to_dsn(self._url)

    @property
    def url(self) -> str:
        return self._url

    @property
    def dsn(self) -> str:
        return self._dsn

    def apply_schema(self) -> None:
        sql = _load_migration_sql()
        conn = self.connect()
        try:
            with conn.cursor() as cur:
                cur.execute(sql)
            conn.commit()
        except Exception as exc:
            try:
                conn.rollback()
            except Exception:
                pass
            raise SaaSBaseError(f"Failed to initialize PostgreSQL schema: {exc}") from exc
        finally:
            conn.close()

    def connect(self) -> Any:
        try:
            import psycopg  # type: ignore
        except ImportError as exc:  # pragma: no cover
            raise SaaSBaseError(
                "psycopg is not installed. Install with: pip install 'saasbase[postgres]'"
            ) from exc
        return psycopg.connect(self._dsn)
