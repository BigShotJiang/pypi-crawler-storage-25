from __future__ import annotations

import hashlib
import io
from dataclasses import dataclass
from pathlib import Path
from typing import Any, BinaryIO
from uuid import uuid4

from saasbase.common.exceptions import NotFoundError, SaaSBaseError
from saasbase.spi.storage import StoreDocumentRequest, StoredDocument


@dataclass(frozen=True, slots=True)
class S3DocumentStorageConfig:
    endpoint: str
    region: str
    bucket: str
    access_key: str
    secret_key: str
    prefix: str = ""
    path_style: bool = True


def _extension_from_name(name: str) -> str:
    idx = name.rfind(".")
    if idx < 0 or idx == len(name) - 1:
        return ""
    return name[idx:]


def _object_key(prefix: str, storage_key: str) -> str:
    if not prefix:
        return storage_key
    return f"{prefix.rstrip('/')}/{storage_key}"


class S3DocumentStorage:
    """S3-compatible document storage backed by boto3. Install with `pip install 'saasbase[s3]'`."""

    def __init__(self, config: S3DocumentStorageConfig) -> None:
        try:
            import boto3  # type: ignore
            from botocore.client import Config  # type: ignore
        except ImportError as exc:  # pragma: no cover
            raise SaaSBaseError(
                "boto3 is not installed. Install with: pip install 'saasbase[s3]'"
            ) from exc

        self._config = config
        self._client = boto3.client(
            "s3",
            endpoint_url=config.endpoint,
            region_name=config.region,
            aws_access_key_id=config.access_key,
            aws_secret_access_key=config.secret_key,
            config=Config(
                s3={"addressing_style": "path" if config.path_style else "virtual"},
                signature_version="s3v4",
            ),
        )

    def store(self, request: StoreDocumentRequest) -> StoredDocument:
        ext = _extension_from_name(request.name)
        storage_key = f"{uuid4()}{ext}"
        object_key = _object_key(self._config.prefix, storage_key)

        buffer = io.BytesIO()
        digest = hashlib.sha256()
        size = 0
        chunk_size = 64 * 1024
        while True:
            chunk = request.content.read(chunk_size)
            if not chunk:
                break
            if isinstance(chunk, str):
                chunk = chunk.encode("utf-8")
            digest.update(chunk)
            buffer.write(chunk)
            size += len(chunk)
        buffer.seek(0)
        try:
            self._client.put_object(
                Bucket=self._config.bucket,
                Key=object_key,
                Body=buffer.getvalue(),
                ContentType=request.media_type,
            )
        except Exception as exc:
            raise SaaSBaseError(f"Failed to upload to S3 key {object_key}: {exc}") from exc
        uri = f"s3://{self._config.bucket}/{object_key}"
        return StoredDocument(
            storage_key=storage_key,
            uri=uri,
            checksum=digest.hexdigest(),
            size_bytes=size,
            media_type=request.media_type,
        )

    def read(self, storage_key: str) -> BinaryIO:
        object_key = _object_key(self._config.prefix, storage_key)
        try:
            response: Any = self._client.get_object(Bucket=self._config.bucket, Key=object_key)
        except Exception as exc:
            raise NotFoundError(f"Document not found in S3: {storage_key}") from exc
        body = response["Body"].read()
        return io.BytesIO(body)

    def download(self, storage_key: str, target_directory: Path) -> Path:
        target_directory.mkdir(parents=True, exist_ok=True)
        destination = target_directory / storage_key
        object_key = _object_key(self._config.prefix, storage_key)
        try:
            self._client.download_file(self._config.bucket, object_key, str(destination))
        except Exception as exc:
            raise NotFoundError(f"Document not found in S3: {storage_key}") from exc
        return destination

    def delete(self, storage_key: str) -> None:
        object_key = _object_key(self._config.prefix, storage_key)
        self._client.delete_object(Bucket=self._config.bucket, Key=object_key)
