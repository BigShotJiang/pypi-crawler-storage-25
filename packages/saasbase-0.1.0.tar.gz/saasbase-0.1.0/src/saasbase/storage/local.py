from __future__ import annotations

import hashlib
import io
import shutil
from pathlib import Path
from typing import BinaryIO
from uuid import uuid4

from saasbase.common.exceptions import NotFoundError, SaaSBaseError
from saasbase.spi.storage import StoreDocumentRequest, StoredDocument


def _extension_from_name(name: str) -> str:
    idx = name.rfind(".")
    if idx < 0 or idx == len(name) - 1:
        return ""
    return name[idx:]


class LocalDocumentStorage:
    """File-backed document storage. Computes SHA-256 checksum while streaming content to disk."""

    def __init__(self, base_path: str | Path) -> None:
        self._base_path = Path(base_path).resolve()
        self._base_path.mkdir(parents=True, exist_ok=True)

    @property
    def base_path(self) -> Path:
        return self._base_path

    def store(self, request: StoreDocumentRequest) -> StoredDocument:
        ext = _extension_from_name(request.name)
        storage_key = f"{uuid4()}{ext}"
        target = self._base_path / storage_key
        target.parent.mkdir(parents=True, exist_ok=True)

        digest = hashlib.sha256()
        size = 0
        chunk_size = 64 * 1024
        try:
            with target.open("wb") as sink:
                while True:
                    chunk = request.content.read(chunk_size)
                    if not chunk:
                        break
                    if isinstance(chunk, str):
                        chunk = chunk.encode("utf-8")
                    digest.update(chunk)
                    size += len(chunk)
                    sink.write(chunk)
        except OSError as exc:
            target.unlink(missing_ok=True)
            raise SaaSBaseError(f"Failed to store document '{request.name}': {exc}") from exc

        return StoredDocument(
            storage_key=storage_key,
            uri=target.as_uri(),
            checksum=digest.hexdigest(),
            size_bytes=size,
            media_type=request.media_type,
        )

    def read(self, storage_key: str) -> BinaryIO:
        target = self._base_path / storage_key
        if not target.exists():
            raise NotFoundError(f"Document not found: {storage_key}")
        return io.BufferedReader(open(target, "rb"))  # type: ignore[arg-type]

    def download(self, storage_key: str, target_directory: Path) -> Path:
        source = self._base_path / storage_key
        if not source.exists():
            raise NotFoundError(f"Document not found: {storage_key}")
        target_directory.mkdir(parents=True, exist_ok=True)
        destination = target_directory / storage_key
        shutil.copy2(source, destination)
        return destination

    def delete(self, storage_key: str) -> None:
        target = self._base_path / storage_key
        if target.exists():
            target.unlink()
