"""Document storage adapters — local filesystem and S3-compatible object storage."""

from saasbase.storage.local import LocalDocumentStorage
from saasbase.storage.s3 import S3DocumentStorage, S3DocumentStorageConfig

__all__ = ["LocalDocumentStorage", "S3DocumentStorage", "S3DocumentStorageConfig"]
