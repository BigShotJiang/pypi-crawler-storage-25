from __future__ import annotations

import threading
from collections import defaultdict

from saasbase.common.actor import ActorRef
from saasbase.common.authz import Action, AuthorizationPolicy, Role
from saasbase.common.resource import ResourceRef


class InMemoryAuthzEngine:
    """AuthzEngine backed by in-memory grants — resource -> actor -> set[Role].

    Parent-child resource links are ignored; inherited authorization is computed by the core runtime
    via the explicit resource-hierarchy resolver instead.
    """

    def __init__(self) -> None:
        self._grants: dict[ResourceRef, dict[ActorRef, set[Role]]] = defaultdict(
            lambda: defaultdict(set)
        )
        self._lock = threading.RLock()

    def grant(self, resource: ResourceRef, actor: ActorRef, role: Role) -> None:
        with self._lock:
            self._grants[resource][actor].add(role)

    def revoke(self, resource: ResourceRef, actor: ActorRef, role: Role) -> None:
        with self._lock:
            actor_roles = self._grants.get(resource, {}).get(actor)
            if actor_roles is None:
                return
            actor_roles.discard(role)
            if not actor_roles:
                self._grants[resource].pop(actor, None)
            if not self._grants[resource]:
                self._grants.pop(resource, None)

    def link_parent(self, child: ResourceRef, parent: ResourceRef) -> None:
        return None

    def unlink_parent(self, child: ResourceRef, parent: ResourceRef) -> None:
        return None

    def can(self, actor: ActorRef, action: Action, resource: ResourceRef) -> bool:
        with self._lock:
            for role in self._grants.get(resource, {}).get(actor, set()):
                if AuthorizationPolicy.allows(role, action):
                    return True
            return False

    def who_can(self, action: Action, resource: ResourceRef) -> list[ActorRef]:
        with self._lock:
            result: set[ActorRef] = set()
            for actor, roles in self._grants.get(resource, {}).items():
                if any(AuthorizationPolicy.allows(r, action) for r in roles):
                    result.add(actor)
            return sorted(result, key=lambda a: (a.type.value, a.id))

    def actor_roles(self, actor: ActorRef, resource: ResourceRef) -> set[Role]:
        with self._lock:
            return set(self._grants.get(resource, {}).get(actor, set()))
