"""In-memory authorization engine — single-process, no persistence. Useful for dev and tests."""

from saasbase.authz_inmemory.engine import InMemoryAuthzEngine

__all__ = ["InMemoryAuthzEngine"]
