import pandas as pd 
import numpy as np
import requests
import json


# we're now going to load these functions in which will interact with the eikon API

# ----------------------------------------
# POI based similarity API functions
# ----------------------------------------


# visual similarity function
# -----

def visual_similarity(location_1_lat_lon_list, location_2_lat_lon_list, resolution, user_api_key):
    """
    This is a function to get a visual similarity image between two locations given their lat, lon coordinates.
    This function requires latitude, longitude values to be in float format and provided as lists of two elements each.
    Latiude and longitude values should be in the format [latitude, longitude].
    It also requires a resolution parameter which is can be set as either "low", "medium", or "high".
    The function also requires a user_api_key which can be obtained by registering at https://slugai.pagekite.me/register
    
    Example usage:
    
    visual_similarity([51.5074, -0.1278], [48.8566, 2.3522], "low", "your_api_key_here")
    
    Example response:
    
    0.838

    The function returns a a float value between 0 and 1 if successful, otherwise it returns None.
    Values closer to 1 indicate higher visual similarity and values closer to 0 indicate lower visual similarity.
    
    """
    payload = {
            "text": "placeholder",
            "location_1": [location_1_lat_lon_list[0], location_1_lat_lon_list[1]], 
            "location_2": [location_2_lat_lon_list[0], location_2_lat_lon_list[1]],
            "api_key": user_api_key,
            "resolution": resolution
          }
    base_api_address = "https://slugai.pagekite.me/"
    endpoint_name = "get_similarity_image"
    r = requests.post(base_api_address + endpoint_name, json=payload, timeout=120)
    if r.ok:
        visual_similarity_value = r.json()["location_pair_similarity_value"]
        return float(visual_similarity_value)
    else:
        return None
    
# Descriptive similarity function
# -----
def descriptive_similarity(location_1_lat_lon_list, location_2_lat_lon_list, resolution, user_api_key):
    """
    This is a function to get a descriptive similarity value between two locations given their lat, lon coordinates.
    This function requires latitude, longitude values to be in float format and provided as lists of two elements each.
    Latiude and longitude values should be in the format [latitude, longitude].
    It also requires a resolution parameter which is can be set as either "low", "medium", or "high".
    The function also requires a user_api_key which can be obtained by registering at https://slugai.pagekite.me/register
    
    Example usage:
    
    descriptive_similarity([51.5074, -0.1278], [48.8566, 2.3522], "low", "your_api_key_here")
    
    Example response:
    
    0.65

    The function returns a a float value between 0 and 1 if successful, otherwise it returns None.
    Values closer to 1 indicate higher descriptive similarity and values closer to 0 indicate lower descriptive similarity.
    
    """
    payload = {
            "text": "placeholder",
            "location_1": [location_1_lat_lon_list[0], location_1_lat_lon_list[1]], 
            "location_2": [location_2_lat_lon_list[0], location_2_lat_lon_list[1]],
            "api_key": user_api_key,
            "resolution": resolution
          }
    base_api_address = "https://slugai.pagekite.me/"
    endpoint_name = "get_similarity_descriptive"
    r = requests.post(base_api_address + endpoint_name, json=payload, timeout=120)
    if r.ok:
        descriptive_similarity_value = r.json()["location_pair_descriptive_similarity_value"]
        return float(descriptive_similarity_value)
    else:
        return None
    

# combined similarity function
# -----
def combined_similarity(location_1_lat_lon_list, location_2_lat_lon_list, resolution, user_api_key):
    """
    This is a function to get a combined similarity value between two locations given their lat, lon coordinates.
    This combined similarity is made up of both visual and descriptive similarity.
    This function requires latitude, longitude values to be in float format and provided as lists of two elements each.
    Latiude and longitude values should be in the format [latitude, longitude].
    It also requires a resolution parameter which is can be set as either "low", "medium", or "high".
    The function also requires a user_api_key which can be obtained by registering at https://slugai.pagekite.me/register
    
    Example usage:
    
    combined_similarity([51.5074, -0.1278], [48.8566, 2.3522], "low", "your_api_key_here")
    
    Example response:
    
    0.74

    The function returns a float value between 0 and 1 if successful, otherwise it returns None.
    Values closer to 1 indicate higher combined similarity and values closer to 0 indicate lower combined similarity.
    
    """
    payload = {
            "text": "placeholder",
            "location_1": [location_1_lat_lon_list[0], location_1_lat_lon_list[1]], 
            "location_2": [location_2_lat_lon_list[0], location_2_lat_lon_list[1]],
            "api_key": user_api_key,
            "resolution": resolution
          }
    base_api_address = "https://slugai.pagekite.me/"
    endpoint_name = "get_combined_location_similarity"
    r = requests.post(base_api_address + endpoint_name, json=payload, timeout=120)
    if r.ok:
        combined_similarity_value = r.json()["combined_similarity_value"]
        return float(combined_similarity_value)
    else:
        return None
    


# -----------------------------------
# Abstracted similarity (all in one)
# -----------------------------------


def similarity(location_1_lat_lon_list,
                        location_2_lat_lon_list,
                        similarity_type,
                        resolution,
                        user_api_key):
    """
    This is a function to get similarity value between two locations given their lat, lon coordinates.
    This similarity must be one of the following:

    ['visual'
    'descriptive'
    'combined']


    This function requires latitude, longitude values to be in float format and provided as lists of two elements each.
    Latiude and longitude values should be in the format [latitude, longitude].
    It also requires a resolution parameter which is can be set as either "low", "medium", or "high".
    The function also requires a user_api_key which can be obtained by registering at https://slugai.pagekite.me/register
    
    Example usage:
    
    similarity(location_1_lat_lon_list=[51.5074, -0.1278],
               location_2_lat_lon_list=[48.8566, 2.3522],
               similarity_type="visual",
               resolution="low",
               user_api_key="your_api_key_here")
    
    Example response:
    
    0.74

    The function returns a float value between 0 and 1 if successful, otherwise it returns None.
    Values closer to 1 indicate higher combined similarity and values closer to 0 indicate lower combined similarity.
    
    """
    payload = {
            "text": "placeholder",
            "location_1_lat_lon_list": [location_1_lat_lon_list[0], location_1_lat_lon_list[1]], 
            "location_2_lat_lon_list": [location_2_lat_lon_list[0], location_2_lat_lon_list[1]],
            "resolution": resolution,
            "similarity_type":similarity_type,
            "api_key": user_api_key,

          }
    base_api_address = "https://slugai.pagekite.me/"
    endpoint_name = "abstracted_similarity_comparison"


    r = requests.post(base_api_address + endpoint_name, json=payload, timeout=120)
    if r.ok:
        similarity_value = r.json()["location_pair_similarity_value"]
        return float(similarity_value)
    else:
        print(r)
        return None
    

# ----------------------------------------
# Area based similarity API functions
# ----------------------------------------
# tbd...

def area_similarity(area_1, area_2, similarity_type, user_api_key):
    """
    This is a function to get the visual , descriptive or combined similarity value between two areas given their area names.

    A full list of supported location names can be accessed using:
     
    'eikon.utils.list_of_supported_areas()'

    The area similarity follows the same principle as the lat / lon similarity functions but compares the similarity of an entire area to another area.

    This function requires the following parameters:

    area_1 - this is the string value of the first area you would like to use in your comparison
    area_2 - this is the string value of the second area you would like to use in your comparison
    similarity_type - this must be either one of the following: "visual", "descriptive","combined"
    user_api_key - you must provide your api_key

    If you do not have an API key, you can get one by registering at https://slugai.pagekite.me/register
    
    Example usage:

    import eikonsai as eikon
    
    eikon.similarity.area_similarity(
                    area_1 = "Brent",
                    area_2 = "Camden",
                    similarity_type = "visual",
                    user_api_key = "your_api_key_here"
                    )
    
    Example response:
    
    orig         dest        similarity_score
    area_1       area_2       0.85

    The function returns a pandas dataframe with area_1, area_2 and a similarity score for these two location pairs that is a float value between 0 and 1 if successful, otherwise it returns None.
    Values closer to 1 indicate higher similarity and values closer to 0 indicate lower similarity.
    
    """
    payload = {
            "area_1": area_1,
            "area_2": area_2,
            "similarity_type": similarity_type,
            "api_key": user_api_key,
          }
    base_api_address = "https://slugai.pagekite.me/"
    endpoint_name = "get_area_similarity"
    r = requests.post(base_api_address + endpoint_name, json=payload, timeout=120)
    if r.ok:
        area_similarity_result_json = r.json()["area_similarity_result"]
        # convert to dataframe and return to user
        area_similarity_df = pd.DataFrame.from_dict(json.loads(area_similarity_result_json))
        return area_similarity_df
    else:
        return None