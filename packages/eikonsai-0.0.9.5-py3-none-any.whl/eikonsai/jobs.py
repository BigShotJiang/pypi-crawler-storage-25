import pandas as pd
import json
import requests
from PIL import Image
import base64, io, requests
import matplotlib.pyplot as plt
import time
import numpy as np
# eikon search function
# -----
# def search_api(
#                 my_search_prompt,
#                 user_api_key,
#                 effort_selection,
#                 spatial_resolution_for_search,
#                 selected_london_borough = None
#             ):
    
#     """ 
#     This is a function to search for locations in London based on a user prompt using the Eikon Search API.
#     The function requires a user_api_key which can be obtained by registering for an eikon account.
#     The function returns a pandas DataFrame of search results if successful, otherwise it returns an error message.

#     spatial resolution can be set to either "test", "quick", "moderate" or "exhaustive".

#     Example usage:

#     # London - all
#     results_df = search_api(
#                 my_search_prompt="Find me a quiet park with lots of trees",
#                 user_api_key="your_api_key_here",
#                 effort_selection="low",
#                 spatial_resolution_for_search="London - all"
#             )
    
#     # for a specfic borough (i.e. Camden)
#     results_df = search_api(
#                 my_search_prompt="Find me a quiet park with lots of trees",
#                 user_api_key="your_api_key_here",
#                 effort_selection="low",
#                 spatial_resolution_for_search="London - borough",
#                 selected_london_borough="Camden"
#             )
#     """


#     import requests
#     import pandas as pd

#     # ping the endpoint to do the initial user search
#     base_api_address = f'https://slugai.pagekite.me/eikon_search_agent_api'
#     payload = {
#             "prompt": my_search_prompt,
#             "api_key":user_api_key,
#             "effort_selection":effort_selection,
#             "spatial_resolution_for_search": spatial_resolution_for_search,
#             "selected_london_borough":selected_london_borough,
#     }
        
#     if spatial_resolution_for_search == "London - all" and selected_london_borough is None:
   
#         r = requests.post(base_api_address, json=payload, timeout=10000)
#         if r.ok:
#             results_json = r.json()["successful_job_completion"]
#             results_df = pd.DataFrame.from_dict(json.loads(results_json))
#             return results_df
#     elif spatial_resolution_for_search != "London - all" and selected_london_borough is not None:
#         r = requests.post(base_api_address, json=payload, timeout=10000)
#         if r.ok:
#             results_json = r.json()["successful_job_completion"]
#             results_df = pd.DataFrame.from_dict(json.loads(results_json))
#             return results_df
#     else:
#         return ("You have made an incompatible query")
    

def search_api(
                my_search_prompt,
                user_api_key,
                effort_selection,
                spatial_resolution_for_search,
                selected_london_borough = None
            ):
    
    """ 
    This is a function to search for locations in London based on a user prompt using the Eikon Search API.
    The function requires a user_api_key which can be obtained by registering for an eikon account.
    The function returns a pandas DataFrame of search results if successful, otherwise it returns an error message.

    spatial resolution can be set to either "test", "quick", "moderate" or "exhaustive".
    
    Example usage:

    # London - all
    results_df = search_api(
                my_search_prompt="Find me a quiet park with lots of trees",
                user_api_key="your_api_key_here",
                effort_selection="low",
                spatial_resolution_for_search="London - all"
            )
    
    # for a specfic borough (i.e. Camden)
    results_df = search_api(
                my_search_prompt="Find me a quiet park with lots of trees",
                user_api_key="your_api_key_here",
                effort_selection="low",
                spatial_resolution_for_search="London - borough",
                selected_london_borough="Camden"
            )
    """


    import requests
    import pandas as pd

    # first check to see whether a worker is awake
    base_api_address = f'https://slugai.pagekite.me/eikon_search_worker_awake'
    payload = {
            "check": "placeholder",
    }

    # we're going to do a couple of checks to see if the server is active
    num_pings = 0
    successful_delivery = False
    while not successful_delivery and num_pings < 5:
        try:
            print(f"Num attempts: {num_pings}")
            check_r = requests.post(base_api_address, json=payload, timeout=30)
            print(check_r)
            if check_r.ok:
                check_status = check_r.json()["status"]
                if check_status == "awake":
                # looks like everything is fine so go ahead
                    # ping the endpoint to do the initial user search
                    base_api_address = f'https://slugai.pagekite.me/eikon_search_agent_api_queue'

                    payload = {
                            "prompt": my_search_prompt,
                            "api_key":user_api_key,
                            "effort_selection":effort_selection,
                            "spatial_resolution_for_search": spatial_resolution_for_search,
                            "selected_london_borough":selected_london_borough,
                    }

                    num_int_pings = 0

                    while num_int_pings == 0:

                        if spatial_resolution_for_search == "London - all" and selected_london_borough is None:

                            r = requests.post(base_api_address, json=payload, timeout=10000)

                            successful_delivery = True

                            if r.ok:
                                results_json = r.json()["successful_job_completion"]
                                results_df = pd.DataFrame.from_dict(json.loads(results_json))
                                return results_df
                        elif spatial_resolution_for_search != "London - all" and selected_london_borough is not None:
                            r = requests.post(base_api_address, json=payload, timeout=10000)

                            successful_delivery = True

                            if r.ok:
                                results_json = r.json()["successful_job_completion"]
                                results_df = pd.DataFrame.from_dict(json.loads(results_json))
                                return results_df
                        else:
                            return ("You have made an incompatible query")

                        time.sleep(np.random.randint(1,5))
                        num_int_pings += 1
                else:
                    num_pings +=1
                    time.sleep(np.random.randint(1,5))
            else:
                num_pings +=1
                time.sleep(np.random.randint(1,5))

        except Exception as e:
            num_pings +=1
            print(e)
            time.sleep(np.random.randint(1,5))

    return ("It looks like our servers are not available at the moment. Please try again later.")

def crawl_uk(
                my_search_prompt,
                user_api_key,
                effort_selection,
                spatial_resolution_for_search,
                selected_area = None
            ):
    
    """ 
    This is a function to search for locations in the UK based on a user prompt using the Eikon Search API.
    The function requires a user_api_key which can be obtained by registering for an eikon account.
    The function returns a pandas DataFrame of search results if successful, otherwise it returns an error message.

    spatial resolution can be set to either "test", "quick", "moderate" or "exhaustive".
    
    Example usage:

    # London - all
    results_df = search_api(
                my_search_prompt="Find me a quiet park with lots of trees",
                user_api_key="your_api_key_here",
                effort_selection="low",
                spatial_resolution_for_search="UK - all"
            )
    
    # for a specfic borough (i.e. Camden)
    results_df = search_api(
                my_search_prompt="Find me a quiet park with lots of trees",
                user_api_key="your_api_key_here",
                effort_selection="low",
                spatial_resolution_for_search="UK - area",
                selected_area="Camden"
            )
    """


    import requests
    import pandas as pd

    # first check to see whether a worker is awake
    base_api_address = f'https://slugai.pagekite.me/eikon_search_worker_awake'
    payload = {
            "check": "placeholder",
    }

    # we're going to do a couple of checks to see if the server is active
    num_pings = 0
    successful_delivery = False
    while not successful_delivery and num_pings < 5:
        try:
            print(f"Num attempts: {num_pings}")
            check_r = requests.post(base_api_address, json=payload, timeout=30)
            print(check_r)
            if check_r.ok:
                check_status = check_r.json()["status"]
                if check_status == "awake":
                # looks like everything is fine so go ahead
                    # ping the endpoint to do the initial user search
                    base_api_address = f'https://slugai.pagekite.me/eikon_search_agent_api_uk'

                    payload = {
                            "prompt": my_search_prompt,
                            "api_key":user_api_key,
                            "effort_selection":effort_selection,
                            "spatial_resolution_for_search": spatial_resolution_for_search,
                            "selected_area":selected_area,
                    }

                    num_int_pings = 0

                    while num_int_pings == 0:

                        if spatial_resolution_for_search == "UK - all" and selected_area is None:

                            r = requests.post(base_api_address, json=payload, timeout=10000)

                            successful_delivery = True

                            if r.ok:
                                results_json = r.json()["successful_job_completion"]
                                results_df = pd.DataFrame.from_dict(json.loads(results_json))
                                return results_df
                        elif spatial_resolution_for_search != "UK - all" and selected_area is not None:
                            r = requests.post(base_api_address, json=payload, timeout=10000)

                            successful_delivery = True

                            if r.ok:
                                results_json = r.json()["successful_job_completion"]
                                results_df = pd.DataFrame.from_dict(json.loads(results_json))
                                return results_df
                        else:
                            return ("You have made an incompatible query")

                        time.sleep(np.random.randint(1,5))
                        num_int_pings += 1
                else:
                    num_pings +=1
                    time.sleep(np.random.randint(1,5))
            else:
                num_pings +=1
                time.sleep(np.random.randint(1,5))

        except Exception as e:
            num_pings +=1
            print(e)
            time.sleep(np.random.randint(1,5))

    return ("It looks like our servers are not available at the moment. Please try again later.")

# the eikon portfolio comparison function
# -----

def eikon_portfolio_comparison(orig_uniq_id,
                              dest_uniq_id,
                              orig_lat_list,
                              orig_lon_list,
                              dest_lat_list,
                              dest_lon_list,
                              user_api_key,
                              resolution,
                              similarity_type="combined"):
    
    """
    This is a function to compare two portfolios of locations using the Eikon Portfolio Comparison API.
    The function requires two lists of unique location IDs, two lists of latitude values, and two lists of longitude values.

    The function also requires a user_api_key which can be obtained by registering for an eikon account.

    The function requires a resolution parameter which can be set as either "low", "medium", or "high".
    The function also requires a similarity_type parameter which can be set as either "visual", "descriptive", or "combined".
    The function returns a pandas DataFrame of comparison results if successful, otherwise it returns an error message.
    Example usage:
    portfolio_comparison_df = eikon_portfolio_comparison(
                                orig_uniq_id = ["loc_1","loc_2","loc_3"],
                                dest_uniq_id = ["loc_A","loc_B","loc_C"],
                                orig_lat_list = [51.5074, 51.5155, 51.5236],
                                orig_lon_list = [-0.1278, -0.1410, -0.1580],
                                dest_lat_list = [51.5090, 51.5180, 51.5250],
                                dest_lon_list = [-0.1300, -0.1450, -0.1600],
                                user_api_key="your_api_key_here",
                                resolution="medium",
                                similarity_type="combined"
                            )

    Example response: 

    A dataframe containing all combinations of location pairs 3 columns - orig, dest and similarity score column.

    orig         dest        similarity_score
    loc_1       loc_A       0.85
    loc_2       loc_B       0.78
    loc_3       loc_C       0.92
    ...


    
    """

    # check that all the datasets are of equal length
    variables_container = [orig_uniq_id,
                          dest_uniq_id,
                          orig_lat_list,
                          orig_lon_list,
                          dest_lat_list,
                          dest_lon_list]

    
    cumulative_diff = 0

    for x in variables_container:
        for y in variables_container:
            if x != y:
                comp_diff = len(x) - len(y)
                cumulative_diff += comp_diff

    # if all the columns are the same length proceed otherwise return an error:
    if cumulative_diff == 0:
        print("VALID: all inputs are the same length")

        # ping the endpoint to do the portfolio comparison
        base_api_address = f'https://slugai.pagekite.me/eikon_portfolio_comparison'
        payload = {"origin_uniq_id": orig_uniq_id,
                   "destination_uniq_id": dest_uniq_id,
                   "origin_lat_list": orig_lat_list,
                   "origin_lon_list": orig_lon_list,
                   "destination_lat_list": dest_lat_list,
                   "destination_lon_list": dest_lon_list,
                   "api_key":user_api_key,
                   "resolution":resolution,
                   "similarity_type":similarity_type,
                  }
        r = requests.post(base_api_address, json=payload, timeout=1000)
        if r.ok:
            portfolio_comparison_result_json = r.json()["portfolio_comparison_result"]
            # reconstruct dataframe
            portfolio_comparison_result_df = pd.DataFrame.from_dict(json.loads(portfolio_comparison_result_json))
            
            return portfolio_comparison_result_df
        else:
            return r.status_code
        

    else:
        return ("inputs are not of the same length. Ensure all inputs are the same length.")


def eikon_portfolio_comparison_uk(orig_uniq_id,
                              dest_uniq_id,
                              orig_lat_list,
                              orig_lon_list,
                              dest_lat_list,
                              dest_lon_list,
                              user_api_key,
                              resolution,
                              similarity_type="combined"):
    
    """
    This is a function to compare two portfolios of locations using the Eikon Portfolio Comparison API.
    The function requires two lists of unique location IDs, two lists of latitude values, and two lists of longitude values.

    The function also requires a user_api_key which can be obtained by registering for an eikon account.

    The function requires a resolution parameter which can be set as either "low", "medium", or "high".
    The function also requires a similarity_type parameter which can be set as either "visual", "descriptive", or "combined".
    The function returns a pandas DataFrame of comparison results if successful, otherwise it returns an error message.
    Example usage:
    portfolio_comparison_df = eikon_portfolio_comparison(
                                orig_uniq_id = ["loc_1","loc_2","loc_3"],
                                dest_uniq_id = ["loc_A","loc_B","loc_C"],
                                orig_lat_list = [51.5074, 51.5155, 51.5236],
                                orig_lon_list = [-0.1278, -0.1410, -0.1580],
                                dest_lat_list = [51.5090, 51.5180, 51.5250],
                                dest_lon_list = [-0.1300, -0.1450, -0.1600],
                                user_api_key="your_api_key_here",
                                resolution="medium",
                                similarity_type="combined"
                            )

    Example response: 

    A dataframe containing all combinations of location pairs 3 columns - orig, dest and similarity score column.

    orig         dest        similarity_score
    loc_1       loc_A       0.85
    loc_2       loc_B       0.78
    loc_3       loc_C       0.92
    ...


    
    """

    # check that all the datasets are of equal length
    variables_container = [orig_uniq_id,
                          dest_uniq_id,
                          orig_lat_list,
                          orig_lon_list,
                          dest_lat_list,
                          dest_lon_list]

    
    cumulative_diff = 0

    for x in variables_container:
        for y in variables_container:
            if x != y:
                comp_diff = len(x) - len(y)
                cumulative_diff += comp_diff

    # if all the columns are the same length proceed otherwise return an error:
    if cumulative_diff == 0:
        print("VALID: all inputs are the same length")

        # ping the endpoint to do the portfolio comparison
        base_api_address = f'https://slugai.pagekite.me/eikon_portfolio_comparison_uk_dnn'
        payload = {"origin_uniq_id": orig_uniq_id,
                   "destination_uniq_id": dest_uniq_id,
                   "origin_lat_list": orig_lat_list,
                   "origin_lon_list": orig_lon_list,
                   "destination_lat_list": dest_lat_list,
                   "destination_lon_list": dest_lon_list,
                   "api_key":user_api_key,
                   "resolution":resolution,
                   "similarity_type":similarity_type,
                  }
        r = requests.post(base_api_address, json=payload, timeout=50000)
        if r.ok:
            portfolio_comparison_result_json = r.json()["portfolio_comparison_result"]
            # reconstruct dataframe
            portfolio_comparison_result_df = pd.DataFrame.from_dict(json.loads(portfolio_comparison_result_json))
            
            return portfolio_comparison_result_df
        else:
            return r.status_code, r.json()
        

    else:
        return ("inputs are not of the same length. Ensure all inputs are the same length.")
    


def eikon_ai_chat(user_api_key):

    """
    This is a function to chat with the EIKON AI chat agent using the Eikon AI Chat API.
    The function requires a user_api_key which can be obtained by registering for an eikon account

    Example usage:
    eikon_ai_chat(user_api_key="your_api_key_here")

    This function initiates a chat session with the EIKON AI chat agent.
    The user can type messages and receive responses from the AI agent.
    The chat session continues until the user types "/quit" to exit.

    This function uses a queue-based system:
    1. Submits the chat request to the queue endpoint and receives a job_id
    2. Polls the queue status endpoint until the job completes or fails

    """

    import re
    from colorama import Fore, Style

    # load some helper functions

    def extract_response(response):
        # simple regex search to extract answers
        answer = re.search(f"<response>(.*?)</response>", response, re.DOTALL)
        if answer is not None:
            return answer.group(1)
        return answer

    def extract_output(response):
        # simple regex search to extract answers
        answer = re.search(f"<output>(.*?)</output>", response, re.DOTALL)
        if answer is not None:
            return answer.group(1)
        return answer

    print("Welcome to EIKON AI chat! Type /quit to exit.")

    model_cot_container = []
    conversation_container = []
    print(f"what do you want to say to EIKON?: ")
    while True:
        user_comment = input("> ").strip()
        if user_comment.lower() == "/quit":
            print("Good-bye!")
            break


        cleaned_user_comment = f"USER: {user_comment}"


        # chat with agent loop using queue-based system
        invalid_response_counter = 0
        valid_response = 0
        max_retries = 10
        while valid_response != 1:
            if invalid_response_counter > max_retries:
                issue_response = "EIKON is currently experiencing high demand. Please try again later."
                print(issue_response)
                print("Shutting down chat session.")
                break

            try:

                # Step 1: Submit to the queue
                queue_status_url = f'https://slugai.pagekite.me/eikon_ai_chat_queue_status'

                payload = {"model_cot_history": "\n -".join(model_cot_container[-3:]),
                           "conversation_history": "\n\n ".join(conversation_container[-3:] + [cleaned_user_comment]),
                            "api_key":user_api_key,
                        }

                submit_response = requests.post(queue_submit_url, json=payload, timeout=30)
                if not submit_response.ok:
                    print(f"Failed to submit chat request: {submit_response.status_code}")
                    invalid_response_counter += 1
                    time.sleep(5)
                    continue

                job_id = submit_response.json().get("job_id")
                if not job_id:
                    print("No job_id returned from queue endpoint")
                    invalid_response_counter += 1
                    time.sleep(5)
                    continue

                # Step 2: Poll for the result
                max_wait = 900  # 15 minutes max
                poll_interval = 3  # seconds between polls
                elapsed = 0

                while elapsed < max_wait:
                    time.sleep(poll_interval)
                    elapsed += poll_interval

                    status_response = requests.get(
                        queue_status_url,
                        params={"job_id": job_id},
                        timeout=30
                    )

                    if not status_response.ok and status_response.status_code != 500:
                        print(f"Queue status check failed: {status_response.status_code}")
                        invalid_response_counter += 1
                        break

                    status_data = status_response.json()

                    if status_data["status"] == "completed":
                        response_json = status_data["result"]

                        model_cot = response_json["in_conversation_information"]
                        model_cot_list = model_cot.split("\n *")
                        character_response = response_json["model_response"]
                        try:
                            map_response = response_json["map_bytes"]
                            for idx in range(len(map_response)):
                                img_bytes = base64.b64decode(map_response[idx])

                                # load into an image object
                                img = Image.open(io.BytesIO(img_bytes))

                                plt.figure()
                                plt.imshow(img)
                                plt.axis("off")
                                plt.show()
                        except Exception as e:
                            # there were no maps returned by Eikon
                            pass

                        character_response_init = extract_output(character_response)
                        character_response = extract_response(character_response_init)

                        valid_response = 1
                        break

                    elif status_data["status"] == "failed":
                        print(f"Chat processing failed: {status_data.get('error', 'Unknown error')}")
                        invalid_response_counter += 1
                        break
                    # else still queued/processing — keep polling

                else:
                    # max_wait exceeded — don't retry, just break out entirely
                    print("Chat request timed out after waiting in queue. Please try again.")
                    break

            except requests.exceptions.Timeout:
                invalid_response_counter += 1
                print("Chat request timed out. The server may be busy, please try again.")
                time.sleep(5)
            except Exception as e:
                invalid_response_counter += 1
                time.sleep(5)
                pass
        # we'll only add the users comment if we got a valid response
        conversation_container.append(cleaned_user_comment)
        # now extract the model response
        cleaned_character_response = f"EIKON: {character_response}"
        print("\n---\n")
        print(f"{Fore.BLUE}{Style.BRIGHT}{cleaned_character_response}{Style.RESET_ALL}")
        print("\n---\n")

        conversation_container.append(cleaned_character_response)
        for i in model_cot_list:
            if i not in model_cot_container:
                model_cot_container.append(i)


def run_assessment(user_api_key):
    """
    Interactive assessment function that guides the user through defining assessment
    criteria and location scope, then runs hierarchical classification (H7, H8, H9)
    via the Eikon Assessment API to score every H9 cell in the chosen area.

    The function walks through three steps:
    1. Choose location scope (whole of London or a specific borough)
    2. Define assessment criteria (how many and what they are)
    3. Confirm and submit to the assessment API

    Returns a pandas DataFrame with columns:
        - h3_index_9: H3 index at resolution 9
        - pred_h9: Normalized H9 prediction score
        - pred_h8: Normalized H8 prediction score
        - pred_h7: Normalized H7 prediction score
        - cum_score: Cumulative weighted score (0.0 to 1.0)

    Example usage:
        results_df = run_assessment(user_api_key="your_api_key_here")

    Parameters:
        user_api_key (str): Your Eikon API key obtained by registering for an account.

    Returns:
        pd.DataFrame: Assessment results with cumulative scores per H9 cell,
                       or a string error message if the assessment fails.
    """

    from colorama import Fore, Style

    print(f"\n{Fore.BLUE}{Style.BRIGHT}=== EIKON Location Assessment ==={Style.RESET_ALL}\n")

    # --- Step 1: Location scope ---
    print("Where would you like to run this assessment?")
    print("  1. Whole of London")
    print("  2. A specific London borough")

    location_choice = None
    while location_choice not in ["1", "2"]:
        location_choice = input("> ").strip()
        if location_choice not in ["1", "2"]:
            print("Please enter 1 or 2.")

    location_scope = None
    selected_london_borough = None

    if location_choice == "1":
        location_scope = "London - all"
        print(f"\n{Fore.GREEN}Location: Whole of London{Style.RESET_ALL}\n")
    else:
        location_scope = "London - borough"

        london_boroughs = [
            "Barking and Dagenham",
            "Barnet",
            "Bexley",
            "Brent",
            "Bromley",
            "Camden",
            "City of London",
            "Croydon",
            "Ealing",
            "Enfield",
            "Greenwich",
            "Hackney",
            "Hammersmith and Fulham",
            "Haringey",
            "Harrow",
            "Havering",
            "Hillingdon",
            "Hounslow",
            "Islington",
            "Kensington and Chelsea",
            "Kingston upon Thames",
            "Lambeth",
            "Lewisham",
            "Merton",
            "Newham",
            "Redbridge",
            "Richmond upon Thames",
            "Southwark",
            "Sutton",
            "Tower Hamlets",
            "Waltham Forest",
            "Wandsworth",
            "Westminster",
        ]

        print("\nSelect a borough by number:")
        for idx, borough in enumerate(london_boroughs, start=1):
            print(f"  {idx:>2}. {borough}")

        borough_choice = None
        while borough_choice is None:
            try:
                raw = int(input("> ").strip())
                if 1 <= raw <= len(london_boroughs):
                    borough_choice = raw
                else:
                    print(f"Please enter a number between 1 and {len(london_boroughs)}.")
            except ValueError:
                print("Please enter a valid number.")

        selected_london_borough = london_boroughs[borough_choice - 1]
        print(f"\n{Fore.GREEN}Location: {selected_london_borough}{Style.RESET_ALL}\n")

    # --- Step 2: Criteria collection ---
    num_criteria = None
    while num_criteria is None:
        print("How many criteria would you like to assess?")
        try:
            num_criteria = int(input("> ").strip())
            if num_criteria <= 0:
                print("Please enter a positive number.")
                num_criteria = None
        except ValueError:
            print("Please enter a valid number.")

    assessment_criteria = []
    print()
    for i in range(num_criteria):
        criterion = input(f"Enter criterion {i + 1}: ").strip()
        assessment_criteria.append(criterion)

    # --- Step 3: Confirmation ---
    print(f"\n{Fore.BLUE}{Style.BRIGHT}--- Assessment Summary ---{Style.RESET_ALL}")
    if selected_london_borough:
        print(f"  Location: {selected_london_borough}")
    else:
        print(f"  Location: Whole of London")
    print(f"  Criteria ({len(assessment_criteria)}):")
    for i, criterion in enumerate(assessment_criteria):
        print(f"    {i + 1}. {criterion}")
    print()

    proceed = None
    while proceed not in ["yes", "no"]:
        proceed = input("Proceed? (yes/no): ").strip().lower()
        if proceed not in ["yes", "no"]:
            print("Please enter 'yes' or 'no'.")

    if proceed == "no":
        print("Assessment cancelled.")
        return "Assessment cancelled by user."

    # --- Step 4: Check server availability and send API call ---
    print(f"\n{Fore.BLUE}Submitting assessment to Eikon API...{Style.RESET_ALL}")

    base_api_address = f'https://slugai.pagekite.me/eikon_search_worker_awake'
    payload = {"check": "placeholder"}

    num_pings = 0
    successful_delivery = False
    while not successful_delivery and num_pings < 5:
        try:
            print(f"Checking server availability (attempt {num_pings + 1})...")
            check_r = requests.post(base_api_address, json=payload, timeout=30)
            if check_r.ok:
                check_status = check_r.json()["status"]
                if check_status == "awake":
                    # Server is available, submit assessment
                    assessment_api_address = f'https://slugai.pagekite.me/run_assessment'

                    assessment_payload = {
                        "api_key": user_api_key,
                        "assessment_criteria": assessment_criteria,
                        "location_scope": location_scope,
                        "selected_london_borough": selected_london_borough,
                    }

                    print(f"{Fore.GREEN}Server is available. Running assessment...{Style.RESET_ALL}")
                    print("This may take several minutes depending on the area size and number of criteria.")

                    r = requests.post(assessment_api_address, json=assessment_payload, timeout=50000)

                    successful_delivery = True

                    if r.ok:
                        result_json = r.json()["assessment_result"]
                        results_df = pd.DataFrame.from_dict(json.loads(result_json))

                        num_cells = r.json().get("num_h9_cells_assessed", len(results_df))
                        print(f"\n{Fore.GREEN}{Style.BRIGHT}Assessment complete!{Style.RESET_ALL}")
                        print(f"  H9 cells assessed: {num_cells}")
                        print(f"  Score range: {results_df['cum_score'].min():.5f} to {results_df['cum_score'].max():.5f}")

                        return results_df
                    else:
                        error_msg = r.json() if r.headers.get("content-type", "").startswith("application/json") else r.text
                        print(f"{Fore.RED}Assessment failed: {error_msg}{Style.RESET_ALL}")
                        return f"Assessment failed with status {r.status_code}: {error_msg}"
                else:
                    num_pings += 1
                    time.sleep(np.random.randint(1, 5))
            else:
                num_pings += 1
                time.sleep(np.random.randint(1, 5))

        except requests.exceptions.Timeout:
            num_pings += 1
            print("Request timed out. Retrying...")
            time.sleep(np.random.randint(1, 5))
        except Exception as e:
            num_pings += 1
            print(f"Error: {e}")
            time.sleep(np.random.randint(1, 5))

    return "It looks like our servers are not available at the moment. Please try again later."


def run_assessment_custom_polygon(user_api_key, h3_cells, assessment_criteria):
    """
    Runs a hierarchical assessment across H7, H8, and H9 resolution levels
    using DualInputClassifier neural networks. Accepts a list of H3 cells
    (resolution 9) to define a custom area of interest and a list of
    assessment criteria, then returns cumulative scores for every matched
    H9 cell.

    Parameters:
        user_api_key (str): Your Eikon API key obtained by registering for an account.
        h3_cells (list[str]): List of H3 cell indices at resolution 9 defining the area of interest.
        assessment_criteria (list[str]): List of assessment criteria strings describing what to search for.

    Returns:
        pd.DataFrame: Assessment results with cumulative scores per H9 cell,
                       or a string error message if the assessment fails.

    Example usage:
        results_df = run_assessment_custom_polygon(
            user_api_key="your_api_key_here",
            h3_cells=["89195da584fffff", "89195da586fffff"],
            assessment_criteria=["Find locations with large parks"]
        )
    """

    from colorama import Fore, Style

    # --- Validation ---
    if not isinstance(h3_cells, list) or len(h3_cells) == 0:
        print("h3_cells must be a non-empty list of H3 cell indices.")
        return "Invalid h3_cells parameter."

    if not isinstance(assessment_criteria, list) or len(assessment_criteria) == 0:
        print("assessment_criteria must be a non-empty list.")
        return "Invalid assessment_criteria parameter."

    # --- Summary ---
    print(f"\n{Fore.BLUE}{Style.BRIGHT}=== EIKON Location Assessment (Custom Polygon) ==={Style.RESET_ALL}\n")
    print(f"  H3 cells provided: {len(h3_cells)}")
    print(f"  Criteria ({len(assessment_criteria)}):")
    for i, criterion in enumerate(assessment_criteria):
        print(f"    {i + 1}. {criterion}")
    print()

    # --- Check server availability and send API call ---
    print(f"{Fore.BLUE}Submitting assessment to Eikon API...{Style.RESET_ALL}")

    base_api_address = f'https://slugai.pagekite.me/eikon_search_worker_awake'
    payload = {"check": "placeholder"}

    num_pings = 0
    successful_delivery = False
    while not successful_delivery and num_pings < 5:
        try:
            print(f"Checking server availability (attempt {num_pings + 1})...")
            check_r = requests.post(base_api_address, json=payload, timeout=30)
            if check_r.ok:
                check_status = check_r.json()["status"]
                if check_status == "awake":
                    # Server is available, submit assessment
                    assessment_api_address = f'https://slugai.pagekite.me/run_assessment_custom_polygon'

                    assessment_payload = {
                        "api_key": user_api_key,
                        "assessment_criteria": assessment_criteria,
                        "h3_cells": h3_cells,
                    }

                    print(f"{Fore.GREEN}Server is available. Running assessment...{Style.RESET_ALL}")
                    print("This may take several minutes depending on the area size and number of criteria.")

                    r = requests.post(assessment_api_address, json=assessment_payload, timeout=50000)

                    successful_delivery = True

                    if r.ok:
                        result_json = r.json()["assessment_result"]
                        results_df = pd.DataFrame.from_dict(json.loads(result_json))

                        num_cells = r.json().get("num_h9_cells_assessed", len(results_df))
                        print(f"\n{Fore.GREEN}{Style.BRIGHT}Assessment complete!{Style.RESET_ALL}")
                        print(f"  H9 cells assessed: {num_cells}")
                        print(f"  Score range: {results_df['cum_score'].min():.5f} to {results_df['cum_score'].max():.5f}")

                        return results_df
                    else:
                        error_msg = r.json() if r.headers.get("content-type", "").startswith("application/json") else r.text
                        print(f"{Fore.RED}Assessment failed: {error_msg}{Style.RESET_ALL}")
                        return f"Assessment failed with status {r.status_code}: {error_msg}"
                else:
                    num_pings += 1
                    time.sleep(np.random.randint(1, 5))
            else:
                num_pings += 1
                time.sleep(np.random.randint(1, 5))

        except requests.exceptions.Timeout:
            num_pings += 1
            print("Request timed out. Retrying...")
            time.sleep(np.random.randint(1, 5))
        except Exception as e:
            num_pings += 1
            print(f"Error: {e}")
            time.sleep(np.random.randint(1, 5))

    return "It looks like our servers are not available at the moment. Please try again later."