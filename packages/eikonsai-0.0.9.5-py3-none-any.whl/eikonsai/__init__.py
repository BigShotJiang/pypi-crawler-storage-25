from . import similarity as _similarity_module
from . import context as _context_module
from . import models as _models_module
from . import utils as _utils_module
from . import jobs as _jobs_module

from .similarity import *
from .context import *
from .models import *
from .utils import *
from .jobs import *

# Reattach module namespaces so attributes like eikon.similarity remain modules
similarity = _similarity_module
context = _context_module
models = _models_module
utils = _utils_module
jobs = _jobs_module
