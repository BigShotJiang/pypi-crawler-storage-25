import logging
from contextlib import asynccontextmanager
from typing import Annotated

from fastapi import Depends, FastAPI, HTTPException, Request, Security, status
from fastapi.security import OAuth2PasswordRequestForm

from auth import authenticate_user, create_access_token, get_user_from_token
from db import User, create_db_and_tables
from items import router as items_router
from settings import Settings

# 快速配置
logging.basicConfig(level=logging.INFO)


@asynccontextmanager
async def lifespan(app: FastAPI):
    create_db_and_tables()
    logging.info("Application startup: Database tables created")
    yield


app = FastAPI(
    debug=True,
    title="My API123",
    description="This is a sample API456",
    version="1.0.0",
    lifespan=lifespan,
)
app.include_router(items_router)

settings = Settings()


@app.get("/", tags=["root"])
async def root():
    return {"message": "Hello World!", "settings": settings.model_dump()}


@app.post("/token", tags=["root"])
async def login(form_data: Annotated[OAuth2PasswordRequestForm, Depends()]):
    user = authenticate_user(form_data.username, form_data.password)
    if not user:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Incorrect username or password",
            headers={"WWW-Authenticate": "Bearer"},
        )
    access_token = create_access_token(user)
    return {"access_token": access_token, "token_type": "bearer"}


@app.get("/users/me", tags=["root"])
async def read_users_me(
    current_user: Annotated[User, Security(get_user_from_token, scopes=["me"])],
    request: Request,
):
    return current_user
