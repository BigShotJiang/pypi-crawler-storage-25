from typing import Optional

from sqlmodel import Field, Session, SQLModel, create_engine, select

from settings import Settings

settings = Settings()

engine = create_engine(settings.DATABASE_URL, echo=True)


class User(SQLModel, table=True):
    # Define the table name
    __tablename__ = "t_user"
    id: Optional[int] = Field(default=None, primary_key=True)
    username: str = Field(index=True)
    full_name: Optional[str] = Field(default="")
    email: Optional[str] = Field(default="")
    hashed_password: str = Field(default="")
    disabled: bool = Field(default=False)
    scopes: Optional[str] = Field(default="")


def create_db_and_tables():
    SQLModel.metadata.create_all(engine)


# create user
def create_user(user: User):
    with Session(engine) as session:
        session.add(user)
        session.commit()
        session.refresh(user)
        return user


# get user by username
def get_user_by_username(username: str) -> Optional[User]:
    with Session(engine) as session:
        statement = select(User).where(User.username == username).limit(1)
        return session.exec(statement).first()


# get all users
def get_all_users() -> list[User]:
    with Session(engine) as session:
        statement = select(User)
        return session.exec(statement).all()
