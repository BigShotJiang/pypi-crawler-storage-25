from pwdlib import PasswordHash

from db import User, create_user

password_hash = PasswordHash.recommended()

if __name__ == "__main__":
    # Create a new user
    # user = User(
    #     username="johndoe",
    #     full_name="John Doe",
    #     email="johndoe@example.com",
    #     hashed_password=password_hash.hash("password123"),
    #     disabled=False,
    # )
    user = User(
        username="kim",
        full_name="阿凯",
        email="kim@example.com",
        hashed_password=password_hash.hash("123456"),
        disabled=False,
        scopes=["me"],
    )
    create_user(user)
    print("User created successfully!")
