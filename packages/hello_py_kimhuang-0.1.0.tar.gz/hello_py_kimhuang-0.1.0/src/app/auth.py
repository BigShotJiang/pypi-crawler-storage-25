from typing import Annotated

import jwt
from fastapi import Depends, HTTPException, status
from fastapi.security import OAuth2PasswordBearer, SecurityScopes
from jwt.exceptions import InvalidTokenError
from pwdlib import PasswordHash

from db import User, get_user_by_username
from settings import Settings

settings = Settings()
password_hash = PasswordHash.recommended()
oauth2_scheme = OAuth2PasswordBearer(tokenUrl="token")


def authenticate_user(username: str, password: str) -> User | bool:
    """Authenticate user by username and password."""
    user = get_user_by_username(username)
    if not user:
        return False
    if not password_hash.verify(password, user.hashed_password):
        return False
    return user


def create_access_token(user: User) -> str:
    """Create an access token for the user."""
    to_encode = user.model_dump()
    encoded_jwt = jwt.encode(
        to_encode, settings.SECRET_KEY, algorithm=settings.ALGORITHM
    )
    return encoded_jwt


def get_user_from_token(
    token: Annotated[str, Depends(oauth2_scheme)], security_scopes: SecurityScopes
) -> User | None:
    """Get user from access token."""
    credentials_exception = HTTPException(
        status_code=status.HTTP_401_UNAUTHORIZED,
        detail="Could not validate credentials",
        headers={"WWW-Authenticate": "Bearer"},
    )
    try:
        payload = jwt.decode(
            token, settings.SECRET_KEY, algorithms=[settings.ALGORITHM]
        )
        username: str = payload.get("username")
        if username is None:
            raise credentials_exception
        user = get_user_by_username(username)
        if user is None:
            raise credentials_exception
        if user.disabled:
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST, detail="Inactive user"
            )
        user_scopes = user.scopes.split(" ") if user.scopes else []
        for scope in security_scopes.scopes:
            if scope not in user_scopes:
                raise HTTPException(
                    status_code=status.HTTP_403_FORBIDDEN,
                    detail="Not enough permissions",
                )
        return user
    except InvalidTokenError:
        raise credentials_exception
