# 定义常量
PI = 3.14159


# plus
def plus(x, y):
    return x + y


# minus
def minus(x, y):
    return x - y
