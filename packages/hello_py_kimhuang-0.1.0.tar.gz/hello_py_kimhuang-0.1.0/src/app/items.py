from typing import Annotated, Optional

from fastapi import APIRouter, Depends
from fastapi.security import OAuth2PasswordBearer
from pydantic import AfterValidator, BaseModel

oauth2_scheme = OAuth2PasswordBearer(tokenUrl="token")


def is_positive(value: float) -> float:
    if value <= 0:
        raise ValueError("Value must be positive")
    return value


class Item(BaseModel):
    name: str
    description: Optional[str] = None
    price: Annotated[float, AfterValidator(is_positive), "The price of the item"]
    tax: Optional[
        Annotated[float, AfterValidator(is_positive), "The tax of the item"]
    ] = None


router = APIRouter(prefix="/items", tags=["items123"])


@router.get("/{item_id}")
async def read_item(item_id: int, q: Optional[str] = None):
    return {"item_id": item_id, "q": q}


@router.post("/")
async def create_item(item: Item, token: Annotated[str, Depends(oauth2_scheme)]):
    return {
        **item.model_dump(),
        "token": token,
    }
