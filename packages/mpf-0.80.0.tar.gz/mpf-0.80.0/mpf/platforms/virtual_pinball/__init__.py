"""VPX platform in MPF."""
