"""Mypinballs platform in MPF."""
