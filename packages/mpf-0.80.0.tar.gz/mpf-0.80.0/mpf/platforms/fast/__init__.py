"""FAST hardware platform."""
