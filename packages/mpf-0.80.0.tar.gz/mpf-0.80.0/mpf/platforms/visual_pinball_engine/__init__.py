"""VPE platform in MPF."""
