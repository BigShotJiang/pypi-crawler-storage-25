"""Segment display device module."""
