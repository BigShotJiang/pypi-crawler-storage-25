"""Ball device and ejectors."""
