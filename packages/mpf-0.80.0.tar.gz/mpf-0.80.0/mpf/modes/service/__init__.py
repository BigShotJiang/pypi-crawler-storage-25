"""Default service mode."""
