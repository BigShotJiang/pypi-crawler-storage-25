"""hqdata data sources"""
