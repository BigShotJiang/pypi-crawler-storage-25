"""
Glyphh Code plugin for the Glyphh runtime shell.

Registers as 'code' command via entry points:
    glyphh> code init .
    glyphh> code compile .
    glyphh> code status
"""

import json
import subprocess
import sys
import time
from pathlib import Path

import click

try:
    from glyphh.cli import theme
except ImportError:
    class _FallbackTheme:
        PRIMARY = "magenta"
        ACCENT = "bright_magenta"
        MUTED = "bright_black"
        SUCCESS = "green"
        WARNING = "yellow"
        ERROR = "red"
        INFO = "cyan"
        TEXT = "white"
        TEXT_DIM = "bright_black"
    theme = _FallbackTheme()

_PACKAGE_DIR = Path(__file__).parent  # glyphh_code package directory
_GLYPHH_DIR = Path.home() / ".glyphh"
_STATE_FILE = _GLYPHH_DIR / "code.json"


def _get_session() -> dict:
    """Load CLI session from ~/.glyphh/config.json."""
    config_file = _GLYPHH_DIR / "config.json"
    if config_file.exists():
        try:
            return json.loads(config_file.read_text())
        except Exception:
            pass
    return {}


def _get_org_id() -> str | None:
    """Get org_id from CLI session."""
    return _get_session().get("user", {}).get("org_id")


def _get_token() -> str | None:
    """Get auth token from CLI session (with auto-refresh if expired)."""
    session = _get_session()
    # Per-endpoint token → runtime_token → CLI get_token (with refresh)
    runtime_tokens = session.get("runtime_tokens", {})
    if isinstance(runtime_tokens, dict):
        for token in runtime_tokens.values():
            if token.strip():
                return token.strip()
    rt = session.get("runtime_token", "").strip()
    if rt:
        return rt
    # Fallback to Platform JWT via CLI auth (handles auto-refresh)
    try:
        from glyphh.cli.auth import get_token
        return get_token()
    except ImportError:
        return session.get("access_token", "").strip() or None


def _get_runtime_url() -> str:
    """Get the runtime URL. Defaults to localhost:8002."""
    try:
        from glyphh.cli.config import resolve_runtime_url
        return resolve_runtime_url()
    except ImportError:
        return "http://localhost:8002"


def _require_auth() -> tuple[str, str, str | None]:
    """Return (runtime_url, org_id, token) or exit with error."""
    org_id = _get_org_id()
    if not org_id:
        click.secho("  Not logged in. Run: glyphh auth login", fg=theme.ERROR)
        raise SystemExit(1)
    return _get_runtime_url(), org_id, _get_token()


def _render_bar(current: int, total: int, width: int = 24) -> str:
    """Render a compact progress bar: ████████░░░░ 412/766 (54%)"""
    if total <= 0:
        return ""
    pct = min(current / total, 1.0)
    filled = int(width * pct)
    bar = "█" * filled + "░" * (width - filled)
    return f"{bar}  {current}/{total} ({pct:.0%})"


def _compile_repo(repo_path: str, runtime_url: str, org_id: str, token: str | None) -> tuple[int, list[str]]:
    """Compile the repository into the Glyphh index.

    Streams subprocess stderr for PROGRESS lines and renders a live
    progress bar for extraction and upload phases.

    Returns (file_count, job_ids).
    """
    import io
    import threading

    cmd = [
        sys.executable, "-m", "glyphh_code.compile", repo_path,
        "--runtime-url", runtime_url,
        "--org-id", org_id,
    ]
    if token:
        cmd.extend(["--token", token])

    env = {**__import__("os").environ, "PYTHONWARNINGS": "ignore"}
    proc = subprocess.Popen(
        cmd,
        stdout=subprocess.PIPE,
        stderr=subprocess.PIPE,
        text=True,
        env=env,
    )

    # Read stderr in a background thread to parse progress without blocking
    stderr_lines: list[str] = []
    current_phase = ""

    def _read_stderr():
        nonlocal current_phase
        assert proc.stderr is not None
        for raw in proc.stderr:
            line = raw.rstrip("\n")
            stderr_lines.append(line)
            if not line.startswith("PROGRESS:"):
                continue
            parts = line.split(":")
            if len(parts) != 4:
                continue
            phase, cur_s, tot_s = parts[1], parts[2], parts[3]
            try:
                cur, tot = int(cur_s), int(tot_s)
            except ValueError:
                continue
            if phase != current_phase:
                if current_phase:
                    click.echo("\r" + " " * 72 + "\r", nl=False)
                current_phase = phase
                phase_labels = {
                    "extract": "Extracting",
                    "relationships": "Building graph",
                    "upload": "Encoding & uploading",
                }
                label = phase_labels.get(phase, phase.capitalize())
                click.secho(f"         {label}...", fg=theme.TEXT_DIM)
            bar = _render_bar(cur, tot)
            click.echo(f"\r         {bar}", nl=False)
            if cur >= tot:
                click.echo()

    t = threading.Thread(target=_read_stderr, daemon=True)
    t.start()

    # Collect stdout while stderr thread runs in parallel
    stdout_buf = io.StringIO()
    assert proc.stdout is not None
    for line in proc.stdout:
        stdout_buf.write(line)

    proc.wait()
    t.join(timeout=5)
    stdout = stdout_buf.getvalue()

    if proc.returncode != 0:
        err = "\n".join(stderr_lines[-5:]) if stderr_lines else "(no output)"
        click.secho(f"  Compile error: {err[:200]}", fg=theme.ERROR)
        return 0, []

    # Parse file count and job IDs from stdout
    file_count = 0
    job_ids = []
    for line in stdout.strip().split("\n"):
        if "files indexed" in line:
            try:
                file_count = int(line.split(":")[1].strip().split()[0])
            except (IndexError, ValueError):
                pass
        if "Encoded:" in line:
            try:
                file_count = int(line.split(":")[1].strip().split()[0])
            except (IndexError, ValueError):
                pass
        if "→ job " in line:
            try:
                job_id = line.split("→ job ")[1].strip()
                if job_id and job_id != "?":
                    job_ids.append(job_id)
            except (IndexError, ValueError):
                pass
    return file_count, job_ids


def _wait_for_jobs(
    job_ids: list[str],
    runtime_url: str,
    org_id: str,
    model_id: str = "code",
    token: str | None = None,
    timeout: int = 300,
    poll_interval: float = 1.0,
) -> bool:
    """Poll the runtime until all encoding jobs complete.

    Returns True if all jobs completed successfully, False on error/timeout.
    """
    if not job_ids:
        return True

    import warnings
    with warnings.catch_warnings():
        warnings.simplefilter("ignore")
        import requests

    headers = {}
    if token:
        headers["Authorization"] = f"Bearer {token}"

    pending = set(job_ids)
    deadline = time.time() + timeout

    while pending and time.time() < deadline:
        time.sleep(poll_interval)
        done = set()
        for job_id in pending:
            try:
                r = requests.get(
                    f"{runtime_url}/{org_id}/{model_id}/listener/jobs/{job_id}",
                    headers=headers,
                    timeout=10,
                )
                if r.status_code != 200:
                    continue
                status = r.json().get("status", "")
                if status == "completed":
                    done.add(job_id)
                elif status == "error":
                    msg = r.json().get("error", "unknown error")
                    click.secho(f"  Job {job_id[:8]}… failed: {msg}", fg=theme.ERROR)
                    done.add(job_id)
            except Exception:
                pass  # Network blip — retry on next poll
        pending -= done

    if pending:
        click.secho(f"  Warning: {len(pending)} job(s) did not complete in {timeout}s", fg=theme.WARNING)
        return False
    return True


def _deploy_model(runtime_url: str, org_id: str, token: str | None, project_dir: Path | None = None) -> bool:
    """Deploy the code model to the running runtime via API.

    Uses the runtime's package_model to create a .glyphh ZIP,
    then uploads it as a multipart file — same flow as `model deploy`.
    If project_dir is set, stores the .glyphh file there for visibility.
    """
    try:
        from glyphh.cli.packaging import package_model
        import httpx

        # Package the model directory into a .glyphh file
        glyphh_file = package_model(_PACKAGE_DIR)

        # If project_dir is set, copy the .glyphh file there for visibility
        if project_dir:
            dest_dir = project_dir / ".glyphh"
            dest_dir.mkdir(parents=True, exist_ok=True)
            dest = dest_dir / glyphh_file.name
            import shutil
            shutil.copy2(glyphh_file, dest)
            click.secho(f"  Model stored: {dest}", fg=theme.TEXT_DIM)

        try:
            headers = {}
            if token:
                headers["Authorization"] = f"Bearer {token}"
            with httpx.Client(timeout=60) as client:
                with open(glyphh_file, "rb") as f:
                    r = client.post(
                        f"{runtime_url}/{org_id}/code/model/deploy",
                        files={"file": (glyphh_file.name, f, "application/octet-stream")},
                        headers=headers,
                    )
            return r.status_code in (200, 201)
        finally:
            # Clean up the temporary .glyphh file (project copy already saved)
            glyphh_file.unlink(missing_ok=True)
    except Exception as e:
        click.secho(f"  Deploy warning: {e}", fg=theme.WARNING)
        return False


def _hook_cmd(subcommand: str, *args: str) -> str:
    """Build a portable hook command that works across venvs and source trees.

    Prefers `glyphh-hook` on PATH (global/pipx install), falls back to
    `python -m glyphh_code.hooks` using the current interpreter.
    """
    import shutil
    suffix = " ".join(str(a) for a in args)
    if shutil.which("glyphh-hook"):
        return f"glyphh-hook {subcommand} {suffix}".strip()
    # Fall back to the interpreter that's running right now
    return f"{sys.executable} -m glyphh_code.hooks {subcommand} {suffix}".strip()


def _configure_claude_code(repo_path: str, mcp_url: str, is_upgrade: bool = False):
    """Configure Claude Code: MCP server, hooks, permissions, rules.

    Does NOT touch the user's CLAUDE.md. Behavioral guidance is written to
    .claude/rules/glyphh.md (separate file, no conflicts). Enforcement is
    via a PreToolUse search gate hook that blocks Grep/Glob/Bash(grep|find)
    until glyphh_search has been called at least once per session.
    """
    repo = Path(repo_path).resolve()
    claude_dir = repo / ".claude"
    claude_dir.mkdir(parents=True, exist_ok=True)

    # 1. Add MCP server to Claude Code
    try:
        result = subprocess.run(
            ["claude", "mcp", "add", "--transport", "http", "glyphh", mcp_url],
            capture_output=True,
            text=True,
            cwd=str(repo),
        )
        if result.returncode == 0:
            click.secho("  ✓ MCP server added to Claude Code", fg=theme.SUCCESS)
        else:
            click.secho(f"  ✗ MCP failed: {result.stderr.strip()[:80]}", fg=theme.WARNING)
            click.secho(f"    Run: claude mcp add --transport http glyphh {mcp_url}", fg=theme.TEXT_DIM)
    except FileNotFoundError:
        click.secho("  ✗ Claude Code CLI not found (npm install -g @anthropic-ai/claude-code)", fg=theme.WARNING)
        click.secho(f"    Run: claude mcp add --transport http glyphh {mcp_url}", fg=theme.TEXT_DIM)

    # 2. Migrate: remove Glyphh section from CLAUDE.md if previously injected
    target_claude_md = repo / "CLAUDE.md"
    _GLYPHH_MARKER = "# Glyphh Code Intelligence"
    if target_claude_md.exists():
        existing = target_claude_md.read_text()
        if _GLYPHH_MARKER in existing:
            marker_pos = existing.index(_GLYPHH_MARKER)
            cleaned = existing[:marker_pos].rstrip()
            if cleaned:
                target_claude_md.write_text(cleaned + "\n")
            else:
                target_claude_md.unlink()
            click.secho("  ✓ Migrated Glyphh instructions out of CLAUDE.md", fg=theme.SUCCESS)

    # 3. Add hooks + permissions to .claude/settings.json
    settings_file = claude_dir / "settings.json"

    settings = {}
    if settings_file.exists():
        try:
            settings = json.loads(settings_file.read_text())
        except json.JSONDecodeError:
            pass

    # MCP tool permissions
    permissions = settings.setdefault("permissions", {})
    allow_list = permissions.setdefault("allow", [])
    if "mcp__glyphh__*" not in allow_list:
        allow_list.append("mcp__glyphh__*")

    # Hooks — on upgrade, refresh paths (package dir may have moved)
    hooks = settings.setdefault("hooks", {})

    # ── SessionStart: reset the search-gate flag ──────────────────────────
    session_hooks = hooks.setdefault("SessionStart", [])
    glyphh_dir = repo / ".glyphh"
    reset_cmd = f"rm -f {glyphh_dir}/.search_used"
    # Remove stale glyphh session hooks, then add current
    session_hooks[:] = [
        h for h in session_hooks
        if ".search_used" not in h.get("hooks", [{}])[0].get("command", "")
    ]
    session_hooks.append({
        "hooks": [{"type": "command", "command": reset_cmd}],
    })

    # ── PreToolUse: gate Grep/Glob/Bash(grep|find) until glyphh_search called ─
    pre_hooks = hooks.setdefault("PreToolUse", [])
    gate_cmd = _hook_cmd("search-gate", glyphh_dir)
    # Remove stale glyphh gate hooks (old absolute paths + new), then add current
    pre_hooks[:] = [
        h for h in pre_hooks
        if "search-gate" not in h.get("hooks", [{}])[0].get("command", "")
        and ".search_used" not in h.get("hooks", [{}])[0].get("command", "")
        and "enforce-glyphh-search" not in h.get("hooks", [{}])[0].get("command", "")
    ]
    pre_hooks.append({
        "matcher": "Grep|Glob|Bash",
        "hooks": [{"type": "command", "command": gate_cmd}],
    })

    # ── PostToolUse: set search-gate flag after glyphh_search ────────────
    post_hooks = hooks.setdefault("PostToolUse", [])
    flag_cmd = f"mkdir -p {glyphh_dir} && touch {glyphh_dir}/.search_used"
    # Remove stale glyphh flag hooks
    post_hooks[:] = [
        h for h in post_hooks
        if ".search_used" not in h.get("hooks", [{}])[0].get("command", "")
    ]
    post_hooks.append({
        "matcher": "mcp__glyphh__glyphh_search",
        "hooks": [{"type": "command", "command": flag_cmd}],
    })

    # ── PostToolUse: incremental compile after git commits ───────────────
    compile_cmd = _hook_cmd("post-git-compile", repo)
    if is_upgrade:
        # Replace existing compile hook with updated command
        post_hooks[:] = [
            h for h in post_hooks
            if "post-git-compile" not in h.get("hooks", [{}])[0].get("command", "")
            and "post-commit-compile" not in h.get("hooks", [{}])[0].get("command", "")
        ]
    else:
        # First init — just clean up legacy hook name
        post_hooks[:] = [
            h for h in post_hooks
            if "post-commit-compile" not in h.get("hooks", [{}])[0].get("command", "")
        ]
    if not any("post-git-compile" in h.get("hooks", [{}])[0].get("command", "") for h in post_hooks):
        post_hooks.append({
            "matcher": "Bash",
            "hooks": [{"type": "command", "command": compile_cmd}],
        })

    settings_file.write_text(json.dumps(settings, indent=2) + "\n")
    click.secho("  ✓ Hooks and permissions configured", fg=theme.SUCCESS)

    # 4. Write .claude/rules/glyphh.md — behavioral guidance for the LLM
    rules_dir = claude_dir / "rules"
    rules_dir.mkdir(parents=True, exist_ok=True)
    rules_file = rules_dir / "glyphh.md"
    rules_file.write_text(
        "# Glyphh Code Intelligence\n"
        "\n"
        "This project has a Glyphh semantic index.\n"
        "Use glyphh MCP tools for codebase search.\n"
        "\n"
        "## Rules\n"
        "\n"
        "ALWAYS call glyphh_search before using Grep, Glob, or the Agent tool.\n"
        "NEVER use the Agent tool to explore the codebase. Use glyphh_search.\n"
        "NEVER scan directories or read multiple files speculatively.\n"
        "Use glyphh_context INSTEAD of Read when you have a specific question\n"
        "about a file. It returns only the matching sections, not the full file.\n"
        "Only fall back to Read when you need the complete file.\n"
        "Call glyphh_related before editing any file to understand blast radius.\n"
        "\n"
        "## Session Memory\n"
        "\n"
        "Use glyphh_session_write to record important decisions, changes, and\n"
        "context as you work. This encodes notes into HDC vectors so they persist\n"
        "across context window compactions.\n"
        "Use glyphh_session_recall to retrieve prior notes by semantic similarity\n"
        "before re-reading files or re-exploring code you already investigated.\n"
    )
    click.secho("  ✓ Navigation rules written to .claude/rules/glyphh.md", fg=theme.SUCCESS)

    # 5. Write .glyphh/manifest.yaml so `model` commands resolve model_id
    glyphh_dir.mkdir(parents=True, exist_ok=True)
    manifest_path = glyphh_dir / "manifest.yaml"
    manifest_path.write_text(
        "# Auto-generated by glyphh code init — do not edit\n"
        "model_id: code\n"
        "name: Glyphh Code\n"
    )

    # 6. Add .glyphh/ to .gitignore
    gitignore = repo / ".gitignore"
    if gitignore.exists():
        content = gitignore.read_text()
        if ".glyphh/" not in content:
            with open(gitignore, "a") as f:
                f.write("\n# Glyphh local index\n.glyphh/\n")
            click.secho("  ✓ .glyphh/ added to .gitignore", fg=theme.SUCCESS)
    else:
        gitignore.write_text("# Glyphh local index\n.glyphh/\n")
        click.secho("  ✓ .gitignore created", fg=theme.SUCCESS)


def _cmd_init(args: str):
    """code init [path] — setup or upgrade a repository."""
    repo = str(Path(args.strip() or ".").resolve())

    if not Path(repo).is_dir():
        click.secho(f"  Not a directory: {repo}", fg=theme.ERROR)
        return

    # Require auth
    runtime_url, org_id, token = _require_auth()

    # Detect upgrade: state file exists for this repo
    is_upgrade = False
    if _STATE_FILE.exists():
        try:
            prev = json.loads(_STATE_FILE.read_text())
            if prev.get("repo") == repo:
                is_upgrade = True
        except (json.JSONDecodeError, KeyError):
            pass

    mode = "upgrade" if is_upgrade else "init"
    click.echo()
    click.secho(f"  Glyphh Code  ·  {mode}", fg=theme.TEXT, bold=True)
    click.secho(f"  {repo}", fg=theme.TEXT_DIM)
    click.echo()

    # Step 1: Deploy model (stores .glyphh file in project dir)
    click.secho("  [1/4] Deploying model...", fg=theme.MUTED)
    _deploy_model(runtime_url, org_id, token, project_dir=Path(repo))

    # Step 2: Clear existing index (stale data from old weights)
    click.secho("  [2/4] Clearing index...", fg=theme.MUTED)
    try:
        import httpx
        headers = {}
        if token:
            headers["Authorization"] = f"Bearer {token}"
        with httpx.Client(timeout=30) as client:
            r = client.delete(
                f"{runtime_url}/{org_id}/code/data",
                headers=headers,
            )
            if r.status_code == 200:
                deleted = r.json().get("glyphs_deleted", 0)
                if deleted:
                    click.secho(f"         {deleted} stale glyphs removed", fg=theme.TEXT_DIM)
    except Exception:
        pass  # Fresh install — nothing to clear

    # Step 3: Compile + encode
    click.secho("  [3/4] Compiling codebase...", fg=theme.MUTED)
    file_count, job_ids = _compile_repo(repo, runtime_url, org_id, token)
    click.secho(f"         {file_count} files indexed", fg=theme.TEXT_DIM)

    # Step 4: Configure Claude Code
    click.secho("  [4/4] Configuring Claude Code...", fg=theme.MUTED)
    mcp_url = f"{runtime_url}/{org_id}/code/mcp"
    _configure_claude_code(repo, mcp_url, is_upgrade=is_upgrade)

    # Save state
    _STATE_FILE.write_text(json.dumps({
        "repo": repo,
        "runtime_url": runtime_url,
        "org_id": org_id,
        "mcp_url": mcp_url,
        "file_count": file_count,
    }))

    click.echo()
    dot = click.style("●", fg=theme.SUCCESS)
    label = "upgraded" if is_upgrade else "ready"
    click.echo(f"  {dot} {click.style(label, fg=theme.SUCCESS)}")
    click.echo()
    click.secho(f"  Repo:      {repo}", fg=theme.TEXT_DIM)
    click.secho(f"  Files:     {file_count} indexed", fg=theme.TEXT_DIM)
    click.secho(f"  MCP:       {mcp_url}", fg=theme.ACCENT)
    click.echo()
    click.secho("  Restart Claude Code to activate.", fg=theme.MUTED)
    click.secho("  VS Code: Cmd+Shift+P → 'Claude Code: Restart'", fg=theme.TEXT_DIM)
    click.echo()
    click.secho("  To keep the runtime alive after quitting the shell:", fg=theme.MUTED)
    click.secho("    glyphh serve &", fg=theme.TEXT_DIM)
    click.echo()


def _cmd_deploy(args: str):
    """code deploy — redeploy the model without re-encoding."""
    runtime_url, org_id, token = _require_auth()

    click.secho("  Deploying model...", fg=theme.TEXT)
    if _deploy_model(runtime_url, org_id, token):
        click.secho("  Model deployed.", fg=theme.SUCCESS)
        click.echo()
        click.secho("  Restart Claude Code to activate.", fg=theme.MUTED)
        click.secho("  VS Code: Cmd+Shift+P → 'Claude Code: Restart'", fg=theme.TEXT_DIM)
    else:
        click.secho("  Deploy failed.", fg=theme.ERROR)


def _cmd_compile(args: str):
    """code compile [path] — recompile the index."""
    runtime_url, org_id, token = _require_auth()

    repo = str(Path(args.strip() or ".").resolve())
    click.secho(f"  Compiling: {repo}", fg=theme.TEXT)
    count, job_ids = _compile_repo(repo, runtime_url, org_id, token)
    click.secho(f"  Done: {count} files indexed", fg=theme.SUCCESS)


def _cmd_status(args: str):
    """code status — show current status."""
    if not _STATE_FILE.exists():
        click.secho("  Glyphh Code not initialized.", fg=theme.TEXT_DIM)
        click.secho("  Run: code init /path/to/repo", fg=theme.MUTED)
        return

    state = json.loads(_STATE_FILE.read_text())

    click.echo()
    org_id = state.get("org_id", _get_org_id() or "?")
    click.secho(f"  Org:     {org_id}", fg=theme.TEXT_DIM)
    click.secho(f"  Repo:    {state.get('repo', '?')}", fg=theme.TEXT_DIM)
    click.secho(f"  Files:   {state.get('file_count', '?')} indexed", fg=theme.TEXT_DIM)
    click.secho(f"  MCP:     {state.get('mcp_url', '?')}", fg=theme.ACCENT)
    click.echo()
    click.secho("  Model commands work from this repo:", fg=theme.TEXT_DIM)
    click.secho("    model count, model data, model status, model re-encode", fg=theme.MUTED)
    click.echo()


def handle_code(func: str | None, args: str = ""):
    """Route code subcommands from the Glyphh shell."""
    commands = {
        "init": _cmd_init,
        "deploy": _cmd_deploy,
        "compile": _cmd_compile,
        "status": _cmd_status,
    }

    if func is None:
        _cmd_status(args)
        return

    handler = commands.get(func)
    if handler:
        handler(args)
    else:
        click.secho(f"  Unknown: code {func}", fg=theme.WARNING)
        click.secho("  Available: init, deploy, compile, status", fg=theme.TEXT_DIM)


def register():
    """Entry point registration — called by runtime shell plugin discovery."""
    return {
        "handler": handle_code,
        "subcommands": ["init", "deploy", "compile", "status"],
    }
