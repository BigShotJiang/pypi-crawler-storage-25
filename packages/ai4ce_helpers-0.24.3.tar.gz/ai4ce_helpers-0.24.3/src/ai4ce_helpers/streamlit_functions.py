import uuid

import streamlit as st
import streamlit_mermaid as stmd

from ._backend_calls import _backend_GET
from ._backend_calls import get_running_backend_version
from .functions import cleanup_parameters
from .functions import move_parameter_placeholder
from .functions_projects import get_list_of_all_project_infos
from .functions_projects import get_recent_project, get_enabled_components, get_enabled_systems
from .logging_setup import logger_ai4cehelper


def _resolve_session_state_prefix(prefix: str | None = None) -> dict:
    if prefix:
        if prefix not in st.session_state:
            st.session_state[prefix] = {}
        return st.session_state[prefix]
    return st.session_state

def st_get_comp(uid: str, prefix: str = None) -> dict:
    
    ss = _resolve_session_state_prefix(prefix)
    
    if "db" not in ss:
        ss["db"] = {}
    if "components" not in ss["db"]:
        ss["db"]["components"] = {}
    
    if uid in ss["db"]["components"]:
        return ss["db"]["components"][uid]
    
    status_code, component = _backend_GET(f"/components/{uid}")
    if status_code != 200:
        logger_ai4cehelper.error(f"(gc) Failed to get component from Backend: {component}")
        raise Exception(f"(gc) Failed to get component from Backend: {component}")
    ss["db"]["components"][uid] = component
    return component

def st_get_eval_prep(project_id: int, force_reload: bool = False, prefix: str = None) -> dict:

    ss = _resolve_session_state_prefix(prefix)

    project_data = st_get_project(project_id, force_reload=force_reload, prefix=prefix)

    _p_db = ss["db"]["projects"][project_id]
    
    project_system = project_data.get("system")
    project_mission = project_data.get("mission")
    
    if force_reload or any(k not in _p_db for k in ["enabled_components", "enabled_systems", "subsystems"]):
        enabled_components = get_enabled_components(project_data.get("system"))
        enabled_systems = get_enabled_systems(project_system)
        subsystems = {subsystem: project_system[subsystem] for subsystem in project_system if subsystem in enabled_systems}
        
        _p_db["enabled_components"] = enabled_components
        _p_db["enabled_systems"] = enabled_systems
        _p_db["subsystems"] = subsystems

    return project_mission, project_system, _p_db["enabled_components"], _p_db["enabled_systems"], _p_db["subsystems"]

    
def st_get_project(project_id: int, force_reload: bool = False, prefix: str = None) -> dict:
    
    ss = _resolve_session_state_prefix(prefix)
    if "db" not in ss:
        ss["db"] = {}
    if "components" not in ss["db"]:
        ss["db"]["projects"] = {}
    if project_id in ss["db"]["projects"] and not force_reload:
        return ss["db"]["projects"][project_id]
    
    ss["db"]["projects"][project_id] = {}
    status_code, project_mission = _backend_GET(endpoint=f"/v2/projects/{project_id}/mission/")
    if status_code != 200:
        logger_ai4cehelper.debug(f"Error fetching mission details for project {project_id}: {project_mission}")
    ss["db"]["projects"][project_id]["mission"] = project_mission
    status_code, project_system = _backend_GET(endpoint=f"/v2/projects/{project_id}/system/")
    if status_code != 200:
        logger_ai4cehelper.debug(f"Error fetching sysarch details for project {project_id}: {project_system}")
    ss["db"]["projects"][project_id]["system"] = project_system
    status_code, project_sysgen = _backend_GET(endpoint=f"/v2/projects/{project_id}/sysgen/")
    if status_code != 200:
        logger_ai4cehelper.debug(f"Error fetching system generator details for project {project_id}: {project_sysgen}")
    ss["db"]["projects"][project_id]["sysgen"] = project_sysgen
    
    return ss["db"]["projects"][project_id]


def st_project_selector(title: str = None, use_columns: bool = True, use_loaded: bool = False, prefix: str = None) -> int | None:

    ss = _resolve_session_state_prefix(prefix)

    projects_simple_list = get_list_of_all_project_infos()

    # col_title, col_button, col_selectbox, col_metric = st.columns([4, 1, 1.3, 1])
    col_1, col_2, col_3, col_4 = st.columns([4, 1, 1.3, 1])
    if not use_columns:
        col_title = col_button = col_selectbox = col_metric = st.columns(1)[0]
    else:
        col_title, col_button, col_selectbox, col_metric = (
            col_1,
            col_2,
            col_3,
            col_4,
        )

    with col_title:
        if title:
            st.title(title)

    with col_button:
        if st.button("Get recent project"):
            (
                ss["project_id"],
                ss["project_name"],
                ss["modified"],
            ) = get_recent_project()

    # Let the user select a project from the list of projects in the project DB
    default_project = 0
    if "project_id" in ss and use_loaded:
        for idx, project in enumerate(projects_simple_list):
            if project[0] == ss["project_id"]:
                default_project = idx
                break
    with col_selectbox:
        selected_project = st.selectbox(
            "Project",
            projects_simple_list,
            index=(None if "project_id" not in ss or not use_loaded else default_project),
            placeholder="Select a project",
            format_func=lambda x: f"{x[1]}",
        )

    with col_metric:
        if selected_project is not None:
            ss["project_id"] = selected_project[0]
            ss["project_name"] = selected_project[1]

        if "project_id" not in ss or ss["project_id"] is None:
            st.metric(label="   ", value="<-- Please select")
        else:
            st.metric(
                label=f"Active project ID: {ss['project_id']}",
                value=f"{ss['project_name']}",
            )

    return ss.get("project_id", None)


def st_system_generator_selector(prefix: str | None = None):
    """A function which adds a system generator selector to the top of the page.
    A system generator is the stored as part of the project in the backend.

    Suitable to be used in conjunction with st_project_selector().
    """
    ss = _resolve_session_state_prefix(prefix)
    
    # check if the project is set and exit without doing anything if not
    if "project_id" not in ss:
        return None

    # get the list of system generators for the current project
    status_code, system_generators = _backend_GET(f"/projects/{ss['project_id']}/sysgen/")

    # if successful display a selector for the system generators based on their IDs and names
    if status_code == 200:
        selected_sysgen = st.selectbox(
            "System Generator",
            [(sysgen["id"], sysgen["description"]) for sysgen in system_generators],
            index=None,
            placeholder="Select a system generator",
            format_func=lambda x: f"{x[1]}",
        )

        if selected_sysgen is not None:
            ss["sysgen_id"] = int(selected_sysgen[0])
            ss["sysgen_description"] = selected_sysgen[1]
    else:
        logger_ai4cehelper.error(f"(st_sgs) Error while loading system generators: {system_generators}")
        st.error(f"Error while loading system generators: {system_generators}")

    # After selecting a system generator, extract and present the generated designs from system_generators with the ID system_generators_id
    if "sysgen_id" not in ss:
        st.stop()

    status_code, system_generator = _backend_GET(
        f"/projects/{ss['project_id']}/sysgen/{ss['sysgen_id']}/"
    )
    if status_code == 200:
        ss["system_generator"] = system_generator
        ss["generated_designs"] = system_generator.get("generated_designs")
    else:
        logger_ai4cehelper.error(f"(st_sgs) Error while loading generated designs: {system_generator}")
        st.error(f"Error while loading generated designs: {system_generator}")

    return ss.get("sysgen_id", None)


def st_generated_design_selector(prefix: str | None = None):
    """A function which adds a generated design selector to the top of the page.
    A generated design is the stored as part of the project in the backend.

    Suitable to be used in conjunction with st_project_selector().
    """
    ss = _resolve_session_state_prefix(prefix)
    
    # check if the project is set and exit without doing anything if not
    if "project_id" not in ss:
        return None

    # get the list of system generators for the current project
    status_code, system_generators = _backend_GET(f"/projects/{ss['project_id']}/sysgen/")

    # if successful display a selector for the system generators based on their IDs and names
    if status_code == 200:
        selected_sysgen = st.selectbox(
            "System Generator",
            [(sysgen["id"], sysgen["description"]) for sysgen in system_generators],
            index=None,
            placeholder="Select a system generator",
            format_func=lambda x: f"{x[1]}",
        )

        if selected_sysgen is not None:
            ss["sysgen_id"] = int(selected_sysgen[0])
            ss["sysgen_description"] = selected_sysgen[1]
    else:
        logger_ai4cehelper.error(f"(st_gds) Error while loading system generators: {system_generators}")
        st.error(f"Error while loading system generators: {system_generators}")

    # After selecting a system generator, extract and present the generated designs from system_generators with the ID system_generators_id
    if "sysgen_id" in ss:
        status_code, system_generator = _backend_GET(
            f"/projects/{ss['project_id']}/sysgen/{ss['sysgen_id']}/"
        )
        if status_code == 200:
            ss["system_generator"] = system_generator
            ss["generated_designs"] = system_generator.get("generated_designs")
        else:
            logger_ai4cehelper.error(f"(st_gds) Error while loading generated designs: {system_generator}")
            st.error(f"Error while loading generated designs: {system_generator}")

    # display the generated designs (comp_list_uids) in a selectbox
    # Only show design selector and warnings if a system generator has been selected
    if "sysgen_id" in ss:
        if "generated_designs" in ss and ss["generated_designs"]:
            selected_generated_design = st.selectbox(
                "Generated Design",
                [(design["id"], design["comp_list_uids"]) for design in ss["generated_designs"]],
                index=None,
                placeholder="Select a generated design",
                format_func=lambda x: f"Design #{x[0]}, Components: {x[1]}",
            )
            if selected_generated_design is not None:
                ss["generated_design_id"] = selected_generated_design[0]
                ss["generated_design_comp_list_uids"] = selected_generated_design[1]
        else:
            logger_ai4cehelper.warning(f"(st_gds) No generated designs available for the selected system generator.")
            st.warning("No generated designs available for the selected system generator.")

    # display the selected system generator and generated design
    if "sysgen_description" in ss and "generated_design_comp_list_uids" in ss:
        st.metric(
            label=f"Selected System Generator (ID: {ss['sysgen_id']})",
            value=ss["sysgen_description"],
        )
        st.metric(
            label=f"Selected Generated Design (ID: {ss['generated_design_id']})",
            value=str(ss["generated_design_comp_list_uids"]),
        )
    elif "sysgen_description" in ss:
        st.metric(
            label="Selected System Generator",
            value=ss["sysgen_description"],
        )

    return ss.get("generated_design_id", None)


def st_generated_design_multiselect(
    multi_select: bool = False, max_selections: int = None, prefix: str | None = None
) -> list[dict]:
    """
    Streamlit multiselect to select generated designs from all generated designs with a project.
    Stores the selected generated designs in session state under "selected_generated_designs".
    """
    ss = _resolve_session_state_prefix(prefix)
    
    # check if the project is set and exit without doing anything if not
    if "project_id" not in ss:
        return None

    # get the list of system generators for the current project
    status_code, system_generators = _backend_GET(f"/projects/{ss['project_id']}/sysgen/")
    if status_code != 200:
        logger_ai4cehelper.error(
            f"(st_gdms) Error retrieving system generators for project {ss['project_id']}: {system_generators}"
        )
        return []

    generated_designs = []
    for sysgen in system_generators:
        if "generated_designs" not in sysgen:
            logger_ai4cehelper.debug(f"(st_gdms) No generated designs found in system generator {sysgen['id']}")
            continue
        for generated_design in sysgen["generated_designs"]:
            if "comp_scores" not in generated_design:
                logger_ai4cehelper.debug(f"(st_gdms) No scores found in generated design {generated_design['id']}")
                continue
            generated_design["sysgen_id"] = sysgen["id"]
            generated_design["sysgen_type"] = sysgen.get("type", "UnkownType")
            generated_design["sysgen_name"] = sysgen.get("name", "UnknownName")
            generated_designs.append(generated_design)

    if not generated_designs:
        logger_ai4cehelper.error(
            f"(st_gdms) No generated valid generated designs were found in project {ss['project_id']}"
        )
        return []

    logger_ai4cehelper.debug(
        f"(st_gdms) Retrieved {len(generated_designs)} generated designs for project {ss['project_id']}"
    )

    if multi_select:
        # create a multiselect of generated designs
        if max_selections:
            selected_generated_designs = st.multiselect(
                "Select generated designs to compare",
                options=generated_designs,
                format_func=lambda x: f"{x['sysgen_name']}-{x['id']}",
                default=generated_designs[:max_selections],
                max_selections=max_selections,
            )
        else:
            selected_generated_designs = st.multiselect(
                "Select generated designs to compare",
                options=generated_designs,
                format_func=lambda x: f"{x['sysgen_name']}-{x['id']}",
                default=generated_designs,
            )
    else:
        selected_generated_designs = st.selectbox(
            f"Select {prefix} Generated Design",
            options=generated_designs,
            format_func=lambda x: f"{x['sysgen_name']}-{x['id']}",
        )
        selected_generated_designs = [selected_generated_designs]

    # store selected generated designs in session state
    ss["selected_generated_designs"] = selected_generated_designs
    logger_ai4cehelper.debug(f"(st_gdms) Selected generated designs: {selected_generated_designs}")
    return selected_generated_designs


def st_load_components(uid_list: list[str] = None, prefix: str | None = None) -> dict[str, dict]:
    """Loads the defined UIDs from the backend into the session state under session_state['db']['components'][{uid}]
    If no list of UIDs is given, check the current projects system generators and iterate over all generated designs with their comp_list_uids.

    Displays a cute spinner while loading.
    """
    ss = _resolve_session_state_prefix(prefix)

    # exit if no data is given to act upon (selection has not been made previously)
    if "project_id" not in ss and uid_list is None:
        return {}

    # create sessions state db if not exists
    if "db" not in ss:
        ss["db"] = {}
    if "components" not in ss["db"]:
        ss["db"]["components"] = {}

    # show infobox with loading message
    with st.spinner("Loading components..."):
        logger_ai4cehelper.info(f"(s_lc) Loading components, uid_list: {uid_list}")
        if uid_list is None and "project_id" in ss:
            status_code, system_generators = _backend_GET(f"/projects/{ss['project_id']}/sysgen/")
            if status_code != 200:
                logger_ai4cehelper.error(f"(s_lc) Error loading system generators: {system_generators}")
                st.error(f"Error loading system generators: {system_generators}")
                return {}
            for sysgen in system_generators:
                status_code, system_generator = _backend_GET(
                    f"/projects/{ss['project_id']}/sysgen/{sysgen['id']}/"
                )
                if status_code == 200:
                    for design in system_generator.get("generated_designs", []):
                        for component_uid in design.get("comp_list_uids", []):
                            if component_uid not in ss["db"]["components"]:
                                status_code, component = _backend_GET(f"/v2/components/{component_uid}")
                                if status_code == 200 and isinstance(component, dict):
                                    ss["db"]["components"][component_uid] = component
                                    if component_uid != component.get("uid"):
                                        ss["db"]["components"][component["uid"]] = component
                                    if "hash" in component:
                                        hash_uid = f"{component['uid'].rsplit('_', 1)[0]}_{component['hash']}"
                                        ss["db"]["components"][hash_uid] = component
                                else:
                                    logger_ai4cehelper.error(
                                        f"(s_lc) Error loading component {component_uid}: {component}"
                                    )
                                    st.error(f"Error loading component {component_uid}: {component}")
                else:
                    logger_ai4cehelper.error(
                        f"(s_lc) Error loading system generator {sysgen['id']}: {system_generator}"
                    )
                    st.error(f"Error loading system generator {sysgen['id']}: {system_generator}")

        else:
            # Load each component by UID
            for component_uid in uid_list:
                status_code, component = _backend_GET(f"/v2/components/{component_uid}")
                if status_code == 200:
                    ss["db"]["components"][component_uid] = component
                else:
                    logger_ai4cehelper.error(f"(s_lc) Error loading component {component_uid}: {component}")
                    st.error(f"Error loading component {component_uid}: {component}")

        for component_uid, component in ss["db"]["components"].items():
            ss["db"]["components"][component_uid] = cleanup_parameters(
                move_parameter_placeholder(component)
            )

    return ss["db"]["components"]


def show_mermaid_diagram(mermaid_code: str = None, prefix: str | None = None):
    """
    Display a Mermaid diagram in Streamlit using streamlit-mermaid.

    Parameters:
        mermaid_code (str, optional): Mermaid diagram definition as a string. If not provided, a default simple graph is shown.

    Streamlit-Mermaid Options Reference:
        https://github.com/neka-nat/streamlit-mermaid/blob/main/streamlit_mermaid/frontend/src/MermaidViewer.tsx#L12
    """

    ss = _resolve_session_state_prefix(prefix)
    
    if not mermaid_code:
        mermaid_code = """
        graph LR
            A[Ex] -->|sam| D[(ple)]
        """
    stmd.st_mermaid(
        mermaid_code,
        show_controls=False,
        pan=True,
        zoom=True,
        key=f"mermaid_{uuid.uuid4()}",
    )


def st_show_backend_version():
    """Display the running backend version in the Streamlit app sidebar."""
    version = get_running_backend_version()
    st.sidebar.markdown(f"Backend Version: {version}")
    return version
