"""Thin synchronous Jira Cloud REST v3 client.

Single entry point: `with JiraClient.from_env() as jc: jc.create_issue(...)`.
Each method maps to one HTTP call; error handling raises `JiraAPIError`
so the MCP layer can serialize the failure back to the model cleanly
instead of crashing the server.
"""

from __future__ import annotations

from base64 import b64encode
from dataclasses import dataclass
from typing import Any, Iterator

import httpx

from . import __version__
from .adf import to_adf_doc
from .config import Config, ConfigError


# ---------------------------------------------------------------------------
# Errors
# ---------------------------------------------------------------------------


class JiraAPIError(RuntimeError):
    """Raised when a Jira REST call returns a non-2xx status."""

    def __init__(self, operation: str, status: int, detail: Any):
        self.operation = operation
        self.status = status
        self.detail = detail
        super().__init__(f"Jira API {operation} failed ({status}): {detail}")

    def to_dict(self) -> dict:
        return {
            "error": f"Jira API {self.operation} failed",
            "status": self.status,
            "detail": self.detail,
        }


# ---------------------------------------------------------------------------
# Link-type shortcuts
# ---------------------------------------------------------------------------
#
# Semantic keys → (outward_role, inward_role). Jira stores directional
# link types with an active-verb ordering: for "A blocks B" (or "A causes
# B", "A duplicates B", "A clones B"), A is the inwardIssue (subject) and
# B is the outwardIssue (object). Callers pass the semantic key
# (blocker/blockee, cause/incident, etc.) and we pick the right
# `outwardIssue` / `inwardIssue` JSON fields to produce the intended
# direction in the Jira UI.

LINK_SHORTCUTS: dict[str, tuple[str, str]] = {
    "Blocks":     ("blockee",   "blocker"),
    "Relates":    ("a",         "b"),
    "Duplicate":  ("canonical", "duplicate"),
    "Duplicates": ("canonical", "duplicate"),
    "Clones":     ("original",  "clone"),
    "Cloners":    ("original",  "clone"),
    "Problem/Incident": ("incident", "cause"),
    "Causes":     ("incident",  "cause"),
}


# ---------------------------------------------------------------------------
# Client
# ---------------------------------------------------------------------------


@dataclass
class JiraClient:
    config: Config
    _client: httpx.Client

    # -- lifecycle --------------------------------------------------------

    @classmethod
    def from_config(cls, cfg: Config) -> "JiraClient":
        auth = b64encode(f"{cfg.email}:{cfg.api_token}".encode()).decode()
        http = httpx.Client(
            base_url=cfg.base_url,
            headers={
                "Authorization": f"Basic {auth}",
                "Accept": "application/json",
                "Content-Type": "application/json",
                "User-Agent": f"jira-aie-mcp/{__version__}",
            },
            timeout=30.0,
        )
        return cls(config=cfg, _client=http)

    @classmethod
    def from_env(cls) -> "JiraClient":
        return cls.from_config(Config.from_env())

    def close(self) -> None:
        self._client.close()

    def __enter__(self) -> "JiraClient":
        return self

    def __exit__(self, *exc: Any) -> None:
        self.close()

    # -- building blocks --------------------------------------------------

    def _check(self, operation: str, r: httpx.Response) -> None:
        if r.status_code < 300:
            return
        try:
            detail: Any = r.json()
        except Exception:
            detail = r.text
        raise JiraAPIError(operation, r.status_code, detail)

    def _build_fields(self, payload: dict) -> dict:
        """Translate a create/update payload into the `fields` dict Jira expects."""
        fields: dict[str, Any] = {}
        if "project_key" in payload or payload.get("op") == "create":
            pk = payload.get("project_key") or self.config.default_project_key
            if not pk:
                raise ConfigError(
                    "No project key supplied. Pass `project_key` in the "
                    "payload, or set JIRA_DEFAULT_PROJECT_KEY in the MCP "
                    "server's env."
                )
            fields["project"] = {"key": pk}
        if "summary" in payload:
            fields["summary"] = payload["summary"]
        if "issue_type" in payload:
            fields["issuetype"] = {"name": payload["issue_type"]}
        if "labels" in payload:
            fields["labels"] = list(payload["labels"])
        if "priority" in payload:
            fields["priority"] = {"name": payload["priority"]}
        if "assignee_id" in payload:
            fields["assignee"] = {"accountId": payload["assignee_id"]}
        for k, v in (payload.get("fields") or {}).items():
            fields[k] = v
        if "description" in payload and payload["description"] is not None:
            fields["description"] = to_adf_doc(payload["description"])
        return fields

    def browse_url(self, key: str) -> str:
        return f"{self.config.base_url}/browse/{key}"

    # -- issue CRUD -------------------------------------------------------

    def create_issue(self, payload: dict) -> dict:
        fields = self._build_fields({**payload, "op": "create"})
        r = self._client.post("/rest/api/3/issue", json={"fields": fields})
        self._check("create", r)
        data = r.json()
        out: dict[str, Any] = {
            "op": "create",
            "key": data["key"],
            "id": data["id"],
            "url": self.browse_url(data["key"]),
        }
        epic = payload.get("epic_key")
        if epic:
            self.link_to_epic(data["key"], epic)
            out["epic"] = epic
        return out

    def update_issue(self, payload: dict) -> dict:
        key = payload["issue_key"]
        fields = self._build_fields(payload)
        # `fields["project"]` is only for creates; strip if it snuck in.
        fields.pop("project", None)
        r = self._client.put(f"/rest/api/3/issue/{key}", json={"fields": fields})
        self._check("update", r)
        return {"op": "update", "key": key, "url": self.browse_url(key)}

    def get_issue(self, key: str, fields: list[str] | None = None) -> dict:
        params = {"fields": ",".join(fields)} if fields else None
        r = self._client.get(f"/rest/api/3/issue/{key}", params=params)
        self._check("get", r)
        return r.json()

    def get_transitions(self, key: str) -> dict:
        r = self._client.get(f"/rest/api/3/issue/{key}/transitions")
        self._check("transitions", r)
        return r.json()

    def link_to_epic(self, child_key: str, epic_key: str) -> None:
        # Team-managed projects use the `parent` field on the child.
        r = self._client.put(
            f"/rest/api/3/issue/{child_key}",
            json={"fields": {"parent": {"key": epic_key}}},
        )
        self._check(f"link {child_key} → {epic_key}", r)

    # -- issue links ------------------------------------------------------

    def create_link(self, payload: dict) -> dict:
        link_type = payload.get("type")
        if not link_type:
            raise ValueError("link payload needs 'type'")
        outward = payload.get("outwardIssue")
        inward = payload.get("inwardIssue")

        if not (outward and inward):
            match = LINK_SHORTCUTS.get(link_type)
            if not match:
                raise ValueError(
                    f"Link type {link_type!r} has no semantic shortcut. "
                    f"Pass 'inwardIssue' and 'outwardIssue' explicitly."
                )
            outward_role, inward_role = match
            outward = payload.get(outward_role)
            inward = payload.get(inward_role)
            if not (outward and inward):
                raise ValueError(
                    f"Link type {link_type!r} expects '{outward_role}' and '{inward_role}' keys "
                    f"(or explicit 'outwardIssue' / 'inwardIssue')."
                )

        body = {
            "type": {"name": link_type},
            "outwardIssue": {"key": outward},
            "inwardIssue": {"key": inward},
        }
        r = self._client.post("/rest/api/3/issueLink", json=body)
        self._check("link", r)
        return {"op": "link", "type": link_type, "outward": outward, "inward": inward}

    # -- batch ------------------------------------------------------------

    def batch(self, ops: list[dict]) -> list[dict]:
        """Run a mixed list of create/update/link operations.

        Errors on one operation do not halt the batch — failing entries
        return `{error, status?, detail?, index}` and the rest proceed.
        """
        results: list[dict] = []
        for i, entry in enumerate(ops):
            kind = entry.get("op", "create")
            try:
                if kind == "create":
                    results.append(self.create_issue(entry))
                elif kind == "update":
                    results.append(self.update_issue(entry))
                elif kind == "link":
                    results.append(self.create_link(entry))
                else:
                    results.append({"op": kind, "index": i, "error": f"unknown op {kind}"})
            except JiraAPIError as e:
                results.append({"op": kind, "index": i, **e.to_dict()})
            except Exception as e:  # noqa: BLE001 — translate any error into a record
                results.append({"op": kind, "index": i, "error": str(e)})
        return results

    # -- search & writeback ----------------------------------------------

    def search_jql(self, jql: str, fields: list[str]) -> list[dict]:
        """Paginated search via /search/jql. Returns a flat list of issues."""
        body: dict[str, Any] = {"jql": jql, "fields": fields, "maxResults": 100}
        out: list[dict] = []
        next_token: str | None = None
        while True:
            if next_token:
                body["nextPageToken"] = next_token
            r = self._client.post("/rest/api/3/search/jql", json=body)
            self._check("search", r)
            page = r.json()
            out.extend(page.get("issues", []))
            next_token = page.get("nextPageToken")
            if not next_token or page.get("isLast", True):
                break
        return out

    def set_duedate(self, key: str, iso_date: str) -> None:
        r = self._client.put(
            f"/rest/api/3/issue/{key}",
            json={"fields": {"duedate": iso_date}},
        )
        self._check(f"set duedate {key}", r)

    def iter_duedate_results(self, updates: Iterator[tuple[str, str]]) -> list[dict]:
        """Apply (key, iso_date) pairs; return per-key result records."""
        results: list[dict] = []
        for key, iso in updates:
            try:
                self.set_duedate(key, iso)
                results.append({"key": key, "ok": True, "duedate": iso})
            except JiraAPIError as e:
                results.append({"key": key, "ok": False, **e.to_dict()})
        return results
