"""`Slide` — the ABC every slide-type inherits from.

`Slide.render(pptx_slide, theme)` is the single entry point `Deck` calls
during save. Subclasses implement it by composing `pptxforge.layouts`
primitives/containers. `LayoutOverflowError` must propagate to the Deck
so it can aggregate failures into `DeckValidationError`.

`notes`, `transition`, and `morph_from_previous` are stored on the slide
and applied by the Deck during save. Transition XML emission runs after
render; see `pptxforge.transitions` for the sealed class hierarchy.
"""

from abc import ABC, abstractmethod
from typing import TYPE_CHECKING, Any, Literal

# Re-export the transition types via the slides namespace so existing
# imports `from pptxforge.slides import Transition` keep working. The
# canonical location is now `pptxforge.transitions`.
from pptxforge.transitions import (
    Fade,
    Morph,
    Push,
    Transition,
    Wipe,
    Zoom,
)
from pptxforge.transitions import (
    MorphMatch as MorphOption,
)
from pptxforge.transitions import (
    None_ as NoneTransition,
)

if TYPE_CHECKING:
    from pptxforge.design import Theme


# Legacy alias — retained for Phase-2/4 call sites that used string-kind
# literals in public signatures. New code should pass a Transition
# instance directly.
TransitionKind = Literal["none", "fade", "morph"]


class Slide(ABC):
    """Abstract base class for every slide kind.

    Concrete subclasses (TitleSlide, ContentSlide, AddInSlide, …) implement
    `render(pptx_slide, theme)` to populate a python-pptx `Slide` object.
    They typically do so by composing `pptxforge.layouts` primitives.

    Shared attributes:

    - `notes` — speaker notes text; stored on the python-pptx notes slide
      during Deck.save.
    - `transition` — entry transition (a `pptxforge.transitions.Transition`
      instance, or None to inherit the deck-wide default).
    - `morph_from_previous` — boolean sugar set by 3D slides; when True,
      Model3DSlide sets `transition = Morph()` at construction.

    Example:
        >>> from pptxforge import transitions
        >>> class MySlide(Slide):
        ...     def __init__(self):
        ...         self.notes = None
        ...         self.transition = transitions.Fade(duration=0.3)
        ...         self.morph_from_previous = False
        ...     def render(self, pptx_slide, theme): ...
    """

    notes: str | None
    transition: Transition | None
    morph_from_previous: bool

    @abstractmethod
    def render(self, pptx_slide: Any, theme: "Theme") -> None:
        """Populate `pptx_slide` with this slide's content against `theme`.

        Raise `pptxforge.layouts.LayoutOverflowError` to report overflow —
        Deck collects these across all slides and re-raises as a single
        `DeckValidationError` during save.
        """


# Back-compat alias. Existing stubs (TitleSlide, etc.) import this name.
BaseSlide = Slide


__all__ = [
    "Slide",
    "BaseSlide",
    "Transition",
    "TransitionKind",
    "MorphOption",
    "Fade",
    "Morph",
    "Push",
    "Wipe",
    "Zoom",
    "NoneTransition",
]
