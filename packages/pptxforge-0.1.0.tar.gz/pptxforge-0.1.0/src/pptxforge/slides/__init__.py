"""Slide types — the ten built-in templates plus their value objects."""

from pptxforge.slides._base import (
    BaseSlide,
    MorphOption,
    Slide,
    Transition,
    TransitionKind,
)
from pptxforge.slides._helpers import ComparisonSide, Event, Stat

# Stubs retained for future phases (Phase 5/3); instantiating them still
# raises NotImplementedError until their phase lands.
from pptxforge.slides.addin import AddInSlide
from pptxforge.slides.chart import ChartSlide

# Phase-4 slide types
from pptxforge.slides.closing import ClosingSlide
from pptxforge.slides.code import CodeSlide
from pptxforge.slides.comparison import ComparisonSlide
from pptxforge.slides.content import ContentSlide
from pptxforge.slides.image import ImageSlide
from pptxforge.slides.media import MediaSlide
from pptxforge.slides.model3d import Model3DSlide
from pptxforge.slides.quote import QuoteSlide
from pptxforge.slides.section import SectionSlide
from pptxforge.slides.stat import StatSlide
from pptxforge.slides.table import TableSlide
from pptxforge.slides.timeline import TimelineSlide
from pptxforge.slides.title import TitleSlide
from pptxforge.slides.two_column import TwoColumnSlide

# Back-compat alias: Phase 2 shipped `SectionDividerSlide` as a stub name
# for what is now `SectionSlide`. Keep the alias so existing imports
# don't break; drop when nothing references it.
SectionDividerSlide = SectionSlide

__all__ = [
    # Base
    "Slide",
    "BaseSlide",
    "Transition",
    "TransitionKind",
    "MorphOption",
    # Value objects
    "Stat",
    "Event",
    "ComparisonSide",
    # Phase-4 templates
    "TitleSlide",
    "SectionSlide",
    "ContentSlide",
    "MediaSlide",
    "QuoteSlide",
    "StatSlide",
    "CodeSlide",
    "ComparisonSlide",
    "TimelineSlide",
    "ClosingSlide",
    # Stubs (later phases)
    "ChartSlide",
    "TableSlide",
    "Model3DSlide",
    "AddInSlide",
    "ImageSlide",
    "TwoColumnSlide",
    "SectionDividerSlide",
]
