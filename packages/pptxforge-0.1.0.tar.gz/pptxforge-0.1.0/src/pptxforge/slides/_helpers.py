"""Helpers shared by the built-in slide types.

`set_slide_background` paints the python-pptx slide's page background from
a palette role. The region helpers encode the "safe content area" every
slide uses so the ten slide types land on the same rhythm.

Also the tight value objects the Phase 4 slide types consume: `Stat`,
`Event`, `ComparisonSide`. Each is a frozen dataclass with no behaviour
beyond validation — the slide's `render` method turns them into
layout primitives.
"""

from collections.abc import Sequence
from dataclasses import dataclass
from typing import TYPE_CHECKING, Any

from pptx.dml.color import RGBColor

from pptxforge.layouts import Region
from pptxforge.layouts._rendering import resolve_color
from pptxforge.slides._base import Transition, TransitionKind

if TYPE_CHECKING:
    from pptxforge.design import Theme


# Standard PowerPoint 16:9 slide — Deck enforces this when building the
# Presentation; keep the numbers here consistent with deck._ASPECT_DIMS.
SLIDE_WIDTH_IN = 13.333
SLIDE_HEIGHT_IN = 7.5
SAFE_MARGIN_IN = 0.75


def set_slide_background(
    pptx_slide: Any, theme: "Theme", *, role: str = "background_light"
) -> None:
    """Paint the slide's page background from a palette role.

    Called by every built-in slide's `render` as the first step, so the
    slide's content lands on a theme-consistent surface. `role` defaults
    to `background_light`; section and closing slides override to
    `background_dark` for dramatic contrast.
    """
    tok = resolve_color(theme, role)
    fill = pptx_slide.background.fill
    fill.solid()
    fill.fore_color.rgb = RGBColor(*tok.rgb)  # type: ignore[no-untyped-call]


def full_slide_region() -> Region:
    """The full 16:9 slide, edge to edge. Used for full-bleed backgrounds."""
    return Region.inches(x=0, y=0, w=SLIDE_WIDTH_IN, h=SLIDE_HEIGHT_IN)


def safe_content_region(
    *,
    margin: float = SAFE_MARGIN_IN,
    top: float | None = None,
    bottom: float | None = None,
) -> Region:
    """The content region with safe margins (default 0.75" all around).

    `top` / `bottom` override the vertical margins independently.
    """
    t = margin if top is None else top
    b = margin if bottom is None else bottom
    return Region.inches(
        x=margin,
        y=t,
        w=SLIDE_WIDTH_IN - 2 * margin,
        h=SLIDE_HEIGHT_IN - t - b,
    )


def coerce_transition(
    value: TransitionKind | Transition | None,
) -> Transition | None:
    """Accept either a raw kind string or a `Transition` instance; normalize.

    Delegates to `pptxforge.transitions.coerce` so every slide's
    `transition` kwarg honors the same contract:

    - `None` → `None` (inherit the deck-wide default)
    - `"none"` → `None_()` (explicit opt-out)
    - `"fade"` → `Fade()`
    - `"morph"` → `Morph()`
    - a `Transition` instance → passed through as-is
    """
    from pptxforge.transitions import coerce

    return coerce(value)


# ---------------------------------------------------------------------------
# Value objects consumed by the slide constructors.
# ---------------------------------------------------------------------------


@dataclass(frozen=True, slots=True)
class Stat:
    """One KPI for `StatSlide` — a big number + a label + an optional caption.

    `number` is rendered as-is — use `"42%"` / `"2.4s"` / `"$3.1M"`; the
    slide does not format. `caption` appears as a small aside under the
    label.

    Example:
        >>> Stat(number="42%", label="Conversion lift", caption="vs. Q3 2025")
    """

    number: str
    label: str
    caption: str | None = None

    def __post_init__(self) -> None:
        if not self.number.strip():
            raise ValueError("Stat.number must not be empty")
        if not self.label.strip():
            raise ValueError("Stat.label must not be empty")


@dataclass(frozen=True, slots=True)
class Event:
    """One event on `TimelineSlide` — a `when` label + title + optional description.

    `when` is arbitrary free text ("Q1 2024", "2026-01-15", "Day 1");
    the slide renders it verbatim and treats it as an eyebrow tag.

    Example:
        >>> Event(when="Q1 2024", title="Launch",
        ...       description="Public release; 8k users week 1.")
    """

    when: str
    title: str
    description: str | None = None

    def __post_init__(self) -> None:
        if not self.when.strip():
            raise ValueError("Event.when must not be empty")
        if not self.title.strip():
            raise ValueError("Event.title must not be empty")


@dataclass(frozen=True, slots=True)
class ComparisonSide:
    """One side of `ComparisonSlide` — a header + bullets.

    Use cases: before / after, pros / cons, option A / option B. The
    header typically uses one palette role on each side (e.g. primary
    vs accent) so the sides are visually distinct beyond just position.

    Example:
        >>> ComparisonSide(header="Before", items=["Manual", "Slow", "Error-prone"])
    """

    header: str
    items: Sequence[str]

    def __post_init__(self) -> None:
        if not self.header.strip():
            raise ValueError("ComparisonSide.header must not be empty")
        if not self.items:
            raise ValueError("ComparisonSide.items must contain at least one bullet")
