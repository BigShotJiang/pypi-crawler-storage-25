"""ChartSlide — routes to charts/core or charts/chartex."""

from typing import TYPE_CHECKING, Any, Literal

from pptxforge.design import Theme
from pptxforge.layouts import Layout
from pptxforge.slides._base import BaseSlide

if TYPE_CHECKING:
    from pptxforge.charts import ChartData

ChartType = Literal[
    "bar",
    "column",
    "line",
    "pie",
    "scatter",
    "area",
    "radar",
    "waterfall",
    "funnel",
    "treemap",
    "sunburst",
    "histogram",
    "box",
    "map",
]


class ChartSlide(BaseSlide):
    """A chart. Core types emit native `c:chart`; chartex types
    (`waterfall`, `funnel`, `treemap`, `sunburst`, `histogram`, `box`,
    `map`) emit `cx:chartSpace` — see `research/python-pptx-extensions.md`
    for the injection mechanics.

    Example:
        >>> deck.add_chart_slide(
        ...     title="MRR", chart_type="line",
        ...     data=ChartData.from_dict({"Jan": 10, "Feb": 14, "Mar": 21}),
        ... )
    """

    def __init__(
        self,
        *,
        title: str,
        chart_type: ChartType,
        data: "ChartData",
        layout: Layout | None = None,
        notes: str | None = None,
        transition: Literal["none", "fade", "morph"] | None = None,
        morph_from_previous: bool = False,
    ) -> None:
        raise NotImplementedError

    def render(self, pptx_slide: Any, theme: Theme) -> None:
        raise NotImplementedError
