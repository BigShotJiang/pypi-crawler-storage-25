"""Model3DSlide — title + embedded GLB 3D model.

Layout: a slim title band at the top, the 3D frame below filling most of
the slide. `morph_from_previous=True` wires the slide's entry transition
to Morph (per research/morph.md) and stamps a stable `a16:creationId`
on the 3D shape so PowerPoint pairs it with the prior slide's model for
smooth camera-orbit interpolation.
"""

from pathlib import Path
from typing import TYPE_CHECKING, Any, Literal

from pptxforge.layouts import Region, Text
from pptxforge.model3d import Camera, insert_model
from pptxforge.slides._base import Slide, Transition
from pptxforge.slides._helpers import (
    SAFE_MARGIN_IN,
    coerce_transition,
    set_slide_background,
)

if TYPE_CHECKING:
    from pptxforge.design import Theme


Animation = Literal["embedded", "turntable"]


class Model3DSlide(Slide):
    """A slide hosting a GLB 2.0 3D model.

    Two ways to orbit the camera:

    - `orbit=True` — applies PowerPoint's native Turntable preset. The
      preset-ID triple is UNVERIFIED (see research/embedded-3d.md §5.2)
      until empirical capture; this path is a best-effort.
    - `morph_from_previous=True` with a prior 3D slide on the same
      `stable_key`: the camera/pose interpolates smoothly from the
      previous slide's camera to this one's during the Morph transition.

    `stable_key` is the pairing identity for the Morph case. Two slides
    that share a `stable_key` and pass `morph_from_previous=True` on the
    second produce a camera orbit in PowerPoint F5 mode.

    Example:
        >>> Model3DSlide(
        ...     title="Aspirin (axial)",
        ...     model=Path("aspirin.glb"),
        ...     camera=Camera(azimuth=45, elevation=20),
        ...     stable_key="aspirin",
        ...     morph_from_previous=True,
        ... )
    """

    _TITLE_HEIGHT_IN = 0.9

    def __init__(
        self,
        *,
        title: str,
        model: Path | str,
        camera: Camera | None = None,
        orbit: bool = False,
        morph_from_previous: bool = False,
        preview: Path | str | None = None,
        stable_key: str | None = None,
        notes: str | None = None,
        transition: Literal["none", "fade", "morph"] | Transition | None = None,
    ) -> None:
        if not title or not title.strip():
            raise ValueError("Model3DSlide requires a non-empty title")
        model_path = Path(model)
        # Don't call validate_glb here — validation runs at render time
        # so Deck.save reports failures via DeckValidationError alongside
        # any other slide failures.

        self.title = title
        self.model = model_path
        self.camera = camera or Camera()
        self.orbit = orbit
        self.morph_from_previous = morph_from_previous
        self.preview = Path(preview) if preview is not None else None
        self.stable_key = stable_key
        self.notes = notes
        # If morph_from_previous is set and no explicit transition was
        # given, implicitly use Morph.
        if morph_from_previous and transition is None:
            transition = "morph"
        self.transition = coerce_transition(transition)

    def render(self, pptx_slide: Any, theme: "Theme") -> None:
        # 3D slides override the deck-wide background with a near-black,
        # theme-tinted surface so models read as physical objects against
        # a viewer-style backdrop (DECISIONS 2026-04-27). Title text
        # flips to text_on_dark for the same reason.
        set_slide_background(pptx_slide, theme, role="surface_three_d")

        # Title band at the top.
        title_region = Region.inches(
            x=SAFE_MARGIN_IN,
            y=0.55,
            w=13.333 - 2 * SAFE_MARGIN_IN,
            h=self._TITLE_HEIGHT_IN,
        )
        Text(self.title, role="h1", color="text_on_dark", bold=True).render(
            pptx_slide, title_region, theme
        )

        # 3D frame — the remainder below the title.
        model_region = Region.inches(
            x=SAFE_MARGIN_IN,
            y=0.55 + self._TITLE_HEIGHT_IN + 0.25,
            w=13.333 - 2 * SAFE_MARGIN_IN,
            h=7.5 - (0.55 + self._TITLE_HEIGHT_IN + 0.25) - SAFE_MARGIN_IN,
        )

        animation: Animation | None
        if self.orbit:
            animation = "turntable"
        elif self._glb_has_animation():
            animation = "embedded"
        else:
            animation = None

        insert_model(
            pptx_slide,
            self.model,
            model_region,
            camera=self.camera,
            animation=animation,
            preview_png=self.preview,
            stable_key=self.stable_key,
            shape_name=f"3D Model - {self.title}",
            description=self.title,
        )
        # Transition emission — including morph_from_previous → Morph() —
        # is handled centrally by Deck.save from `self.transition`.

    def _glb_has_animation(self) -> bool:
        """Heuristic: does the GLB's JSON chunk declare any animations?

        Read the first 4 KiB of the JSON chunk and look for the
        `"animations"` key. Cheap and not parse-accurate, but good
        enough to decide whether to emit an embedded-animation timing
        tree.
        """
        try:
            with self.model.open("rb") as f:
                f.seek(12)  # skip header
                header = f.read(8)
                if len(header) < 8:
                    return False
                chunk_len = int.from_bytes(header[0:4], "little")
                json_bytes = f.read(min(chunk_len, 4096))
            return b'"animations"' in json_bytes
        except OSError:
            return False
