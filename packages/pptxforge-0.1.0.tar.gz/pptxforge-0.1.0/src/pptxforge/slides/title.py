"""TitleSlide — the cover slide.

Layout: typography-driven, anchored in the lower-half of the slide. Eyebrow
tag (optional) in accent caps above the hero title, subtitle (optional)
muted below. No accent rule, no decorative color bars, no cream background.
"""

from typing import TYPE_CHECKING, Any, Literal

from pptxforge.layouts import Region, Stack, Text
from pptxforge.slides._base import Slide, Transition
from pptxforge.slides._helpers import coerce_transition, set_slide_background

if TYPE_CHECKING:
    from pptxforge.design import Theme


class TitleSlide(Slide):
    """The cover slide. One per deck, as slide 0.

    `title` is the hero-size main label. `subtitle` is the lead-size line
    beneath (date, tagline, author). `eyebrow` is a small all-caps tag
    above the title in the accent color — useful for "FORECAST Q4 2026"
    style labels.

    Example:
        >>> TitleSlide(title="Q1 Results", subtitle="Jane · 2026-05",
        ...            eyebrow="Quarterly review")
    """

    def __init__(
        self,
        *,
        title: str,
        subtitle: str | None = None,
        eyebrow: str | None = None,
        notes: str | None = None,
        transition: Literal["none", "fade", "morph"] | Transition | None = None,
    ) -> None:
        if not title or not title.strip():
            raise ValueError("TitleSlide requires a non-empty title")
        self.title = title
        self.subtitle = subtitle
        self.eyebrow = eyebrow
        self.notes = notes
        self.transition = coerce_transition(transition)
        self.morph_from_previous = False

    def render(self, pptx_slide: Any, theme: "Theme") -> None:
        set_slide_background(pptx_slide, theme)

        # Anchor the title block in the lower two-thirds of the slide,
        # left-aligned. Generous left/right margins.
        body = Region.inches(x=1.0, y=3.0, w=11.333, h=3.8)

        children: list[Any] = []
        weights: list[float] = []

        if self.eyebrow:
            children.append(
                Text(
                    self.eyebrow.upper(),
                    role="caption",
                    color="accent",
                    bold=True,
                    use_display_font=True,
                )
            )
            weights.append(0.35)

        children.append(
            Text(
                self.title,
                role="hero",
                color="primary",
                bold=True,
                anchor="top",
            )
        )
        weights.append(2.0)

        if self.subtitle:
            children.append(
                Text(
                    self.subtitle,
                    role="lead",
                    color="text_muted",
                )
            )
            weights.append(0.7)

        Stack(children, gap=0.25, weights=tuple(weights)).render(pptx_slide, body, theme)
