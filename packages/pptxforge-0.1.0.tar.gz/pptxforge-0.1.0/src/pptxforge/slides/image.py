"""ImageSlide."""

from pathlib import Path
from typing import Any, Literal

from pptxforge.design import Theme
from pptxforge.layouts import Layout
from pptxforge.slides._base import BaseSlide


class ImageSlide(BaseSlide):
    """A single image with optional caption/title. Supports morph pairing
    across adjacent slides via `morph_tag` (becomes `!!<tag>` internally).

    Example:
        >>> deck.add_image_slide(image=Path("hero.jpg"), fit="cover")
    """

    def __init__(
        self,
        *,
        image: Path,
        caption: str | None = None,
        title: str | None = None,
        fit: Literal["contain", "cover", "fill"] = "contain",
        layout: Layout | None = None,
        notes: str | None = None,
        transition: Literal["none", "fade", "morph"] | None = None,
        morph_from_previous: bool = False,
        morph_tag: str | None = None,
    ) -> None:
        raise NotImplementedError

    def render(self, pptx_slide: Any, theme: Theme) -> None:
        raise NotImplementedError
