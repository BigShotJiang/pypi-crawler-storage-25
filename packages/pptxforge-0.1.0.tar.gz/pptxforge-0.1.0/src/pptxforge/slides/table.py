"""TableSlide."""

from typing import TYPE_CHECKING, Any, Literal

from pptxforge.design import Theme
from pptxforge.layouts import Layout
from pptxforge.slides._base import BaseSlide

if TYPE_CHECKING:
    from pptxforge.tables import TableData


class TableSlide(BaseSlide):
    """A data table. Column widths default to equal; override via
    `TableData.column_widths`.

    Example:
        >>> deck.add_table_slide(
        ...     title="Costs", data=TableData.from_csv("costs.csv"),
        ... )
    """

    def __init__(
        self,
        *,
        title: str,
        data: "TableData",
        layout: Layout | None = None,
        notes: str | None = None,
        transition: Literal["none", "fade", "morph"] | None = None,
        morph_from_previous: bool = False,
    ) -> None:
        raise NotImplementedError

    def render(self, pptx_slide: Any, theme: Theme) -> None:
        raise NotImplementedError
