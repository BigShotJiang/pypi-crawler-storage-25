"""TwoColumnSlide."""

from collections.abc import Sequence
from pathlib import Path
from typing import Any, Literal

from pptxforge.design import Theme
from pptxforge.layouts import Layout
from pptxforge.slides._base import BaseSlide


class TwoColumnSlide(BaseSlide):
    """Two-column comparison or image+text. Each column accepts string,
    bullet sequence, or image path; types may differ between columns.

    Example:
        >>> deck.add_two_column_slide(
        ...     title="Before / after",
        ...     left=Path("before.png"), right=Path("after.png"),
        ... )
    """

    def __init__(
        self,
        *,
        title: str,
        left: str | Sequence[str] | Path,
        right: str | Sequence[str] | Path,
        left_caption: str | None = None,
        right_caption: str | None = None,
        layout: Layout | None = None,
        notes: str | None = None,
        transition: Literal["none", "fade", "morph"] | None = None,
        morph_from_previous: bool = False,
    ) -> None:
        raise NotImplementedError

    def render(self, pptx_slide: Any, theme: Theme) -> None:
        raise NotImplementedError
