"""ClosingSlide — centered final message with an optional call to action."""

from typing import TYPE_CHECKING, Any, Literal

from pptxforge.layouts import Centered, Region, Shape, Stack, Text
from pptxforge.layouts._base import Layout
from pptxforge.slides._base import Slide, Transition
from pptxforge.slides._helpers import (
    coerce_transition,
    full_slide_region,
    set_slide_background,
)

if TYPE_CHECKING:
    from pptxforge.design import Theme


class ClosingSlide(Slide):
    """Final slide: a centered message over a dark background, optional CTA below.

    Like `SectionSlide`, this is deliberately distinctive — dark ground
    and hero-size centered message signal "end of deck". `call_to_action`
    renders as a caption-size all-caps tag under the message.

    Example:
        >>> ClosingSlide(message="Thank you.",
        ...              call_to_action="Questions? jane@acme.com")
    """

    def __init__(
        self,
        *,
        message: str,
        call_to_action: str | None = None,
        notes: str | None = None,
        transition: Literal["none", "fade", "morph"] | Transition | None = None,
    ) -> None:
        if not message or not message.strip():
            raise ValueError("ClosingSlide requires a non-empty message")
        self.message = message
        self.call_to_action = call_to_action
        self.notes = notes
        self.transition = coerce_transition(transition)
        self.morph_from_previous = False

    def render(self, pptx_slide: Any, theme: "Theme") -> None:
        set_slide_background(pptx_slide, theme, role="background_dark")

        # Center a stack of (message, divider-accent, cta) in the full slide.
        children: list[Layout] = [
            Text(
                self.message,
                role="hero",
                color="background_light",  # reverse out
                bold=True,
                align="center",
                anchor="bottom",
            )
        ]
        weights: list[float] = [2.0]

        # Short accent-colored bar below message (not full-width; this is
        # a small callout, NOT the forbidden full-width decorative bar).
        children.append(Shape("rectangle", fill="accent"))
        weights.append(0.05)

        if self.call_to_action:
            children.append(
                Text(
                    self.call_to_action,
                    role="body",
                    color="secondary",
                    align="center",
                    anchor="top",
                )
            )
            weights.append(0.6)

        # Constrain the centered block to a reasonable width so the short
        # accent bar beneath the message reads as a punctuation mark, not
        # a decorative stripe.
        body = Region.inches(x=2.5, y=2.2, w=8.333, h=3.1)
        Centered(
            Stack(children, gap=0.4, weights=tuple(weights)),
        ).render(pptx_slide, body, theme)


# Silence unused-import: full_slide_region reserved for future closing-bleed variants.
_ = full_slide_region
