"""AddInSlide — slide hosting a ContentAddIn component."""

from typing import TYPE_CHECKING, Any, Literal

from pptxforge.design import Theme
from pptxforge.layouts import Layout
from pptxforge.slides._base import BaseSlide

if TYPE_CHECKING:
    from pptxforge.addins.components._base import AddInComponent

AddInPosition = Literal[
    "full",
    "right-half",
    "left-half",
    "lower-third",
    "upper-third",
    "center",
]


class AddInSlide(BaseSlide):
    """A slide hosting a live webview via a slide-embedded Office
    content add-in.

    The same `component` instance may be added to multiple slides;
    each instance is scaffolded once under `out/addins/<name>/`.

    Example:
        >>> from pptxforge.addins.components import MoleculeViewer
        >>> mol = MoleculeViewer(smiles="CC(=O)OC1=CC=CC=C1C(=O)O")
        >>> deck.add_addin_slide(title="Aspirin", component=mol)
    """

    def __init__(
        self,
        *,
        title: str | None,
        component: "AddInComponent",
        position: AddInPosition = "full",
        caption: str | None = None,
        layout: Layout | None = None,
        notes: str | None = None,
        transition: Literal["none", "fade", "morph"] | None = None,
    ) -> None:
        raise NotImplementedError

    def render(self, pptx_slide: Any, theme: Theme) -> None:
        raise NotImplementedError
