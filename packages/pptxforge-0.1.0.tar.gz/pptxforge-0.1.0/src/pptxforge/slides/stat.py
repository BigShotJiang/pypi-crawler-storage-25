"""StatSlide — a grid of KPI callouts."""

from collections.abc import Sequence
from typing import TYPE_CHECKING, Any, ClassVar, Literal

from pptxforge.layouts import Grid, Region, Stack, StatCallout, Text
from pptxforge.layouts._base import Layout
from pptxforge.slides._base import Slide, Transition
from pptxforge.slides._helpers import (
    SAFE_MARGIN_IN,
    Stat,
    coerce_transition,
    set_slide_background,
)

if TYPE_CHECKING:
    from pptxforge.design import Theme


class StatSlide(Slide):
    """A dashboard-style slide with 2-6 big-number callouts arranged in a grid.

    Layout cols/rows are chosen from `len(stats)`:
    - 2 stats → 1 row × 2 cols
    - 3 stats → 1 row × 3 cols
    - 4 stats → 2 rows × 2 cols
    - 5 or 6 stats → 2 rows × 3 cols (6-slot grid; 5 stats leave one empty)
    More than 6 raises — break into multiple slides.

    `title` is optional; if provided it sits at h1 above the grid.

    Example:
        >>> from pptxforge.slides import Stat
        >>> StatSlide(stats=[
        ...     Stat(number="42%", label="Conversion lift"),
        ...     Stat(number="2.4s", label="P95 load time"),
        ...     Stat(number="$3.1M", label="Pipeline MRR"),
        ... ], title="Q1 results")
    """

    def __init__(
        self,
        *,
        stats: Sequence[Stat],
        title: str | None = None,
        notes: str | None = None,
        transition: Literal["none", "fade", "morph"] | Transition | None = None,
    ) -> None:
        if not stats:
            raise ValueError("StatSlide requires at least one Stat")
        if len(stats) > 6:
            raise ValueError(
                f"StatSlide supports at most 6 stats per slide; got {len(stats)}. "
                "Break into multiple slides."
            )
        self.title = title
        self.stats = tuple(stats)
        self.notes = notes
        self.transition = coerce_transition(transition)
        self.morph_from_previous = False

    _GRID: ClassVar[dict[int, tuple[int, int]]] = {
        1: (1, 1),
        2: (1, 2),
        3: (1, 3),
        4: (2, 2),
        5: (2, 3),
        6: (2, 3),
    }

    def render(self, pptx_slide: Any, theme: "Theme") -> None:
        set_slide_background(pptx_slide, theme)

        title_h = 1.0 if self.title else 0.0

        if self.title:
            title_region = Region.inches(
                x=SAFE_MARGIN_IN,
                y=0.6,
                w=13.333 - 2 * SAFE_MARGIN_IN,
                h=title_h,
            )
            Text(self.title, role="h1", color="primary", bold=True).render(
                pptx_slide, title_region, theme
            )

        body = Region.inches(
            x=SAFE_MARGIN_IN,
            y=0.6 + title_h + (0.4 if self.title else 0.0),
            w=13.333 - 2 * SAFE_MARGIN_IN,
            h=7.5 - (0.6 + title_h + (0.4 if self.title else 0.0)) - SAFE_MARGIN_IN,
        )

        rows, cols = self._GRID[len(self.stats)]
        cells: list[Layout] = []
        for stat in self.stats:
            cell_children: list[Layout] = [
                StatCallout(
                    stat.number,
                    label=stat.label,
                )
            ]
            cell_weights: list[float] = [3.0]
            if stat.caption:
                cell_children.append(
                    Text(
                        stat.caption,
                        role="caption",
                        color="text_muted",
                        align="center",
                    )
                )
                cell_weights.append(0.6)
            cells.append(
                Stack(cell_children, gap=0.15, weights=tuple(cell_weights))
                if len(cell_children) > 1
                else cell_children[0]
            )

        Grid(cells, cols=cols, rows=rows, gap=0.5).render(pptx_slide, body, theme)
