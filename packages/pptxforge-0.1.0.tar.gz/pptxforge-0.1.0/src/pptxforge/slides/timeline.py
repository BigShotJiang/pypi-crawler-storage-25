"""TimelineSlide — a horizontal timeline of events with a spine rule and dots."""

from collections.abc import Sequence
from typing import TYPE_CHECKING, Any, Literal

from pptxforge.layouts import Region, Shape, Stack, Text
from pptxforge.slides._base import Slide, Transition
from pptxforge.slides._helpers import (
    SAFE_MARGIN_IN,
    Event,
    coerce_transition,
    set_slide_background,
)

if TYPE_CHECKING:
    from pptxforge.design import Theme


class TimelineSlide(Slide):
    """Title + a horizontal timeline of 2-5 events.

    The visual element is the timeline spine: a thin `divider`-colored line
    across the body, with `accent`-colored dots at each event position.
    Each event's (when, title, description) sits below its dot.

    Example:
        >>> from pptxforge.slides import Event
        >>> TimelineSlide(title="Roadmap", events=[
        ...     Event(when="Q1", title="Alpha", description="50 users"),
        ...     Event(when="Q2", title="Beta", description="500 users"),
        ...     Event(when="Q3", title="GA", description="General availability"),
        ... ])
    """

    _TITLE_HEIGHT_IN = 1.0
    _SPINE_Y_FRAC = 0.22  # vertical position of the spine inside the body
    _DOT_DIAMETER_IN = 0.22

    def __init__(
        self,
        *,
        title: str,
        events: Sequence[Event],
        notes: str | None = None,
        transition: Literal["none", "fade", "morph"] | Transition | None = None,
    ) -> None:
        if not title or not title.strip():
            raise ValueError("TimelineSlide requires a non-empty title")
        if len(events) < 2:
            raise ValueError(f"TimelineSlide requires at least 2 events; got {len(events)}")
        if len(events) > 5:
            raise ValueError(
                f"TimelineSlide supports at most 5 events per slide; got "
                f"{len(events)}. Break into multiple slides."
            )
        self.title = title
        self.events = tuple(events)
        self.notes = notes
        self.transition = coerce_transition(transition)
        self.morph_from_previous = False

    def render(self, pptx_slide: Any, theme: "Theme") -> None:
        set_slide_background(pptx_slide, theme)

        title_region = Region.inches(
            x=SAFE_MARGIN_IN,
            y=0.6,
            w=13.333 - 2 * SAFE_MARGIN_IN,
            h=self._TITLE_HEIGHT_IN,
        )
        Text(self.title, role="h1", color="primary", bold=True).render(
            pptx_slide, title_region, theme
        )

        body_top = 0.6 + self._TITLE_HEIGHT_IN + 0.4
        body = Region.inches(
            x=SAFE_MARGIN_IN,
            y=body_top,
            w=13.333 - 2 * SAFE_MARGIN_IN,
            h=7.5 - body_top - SAFE_MARGIN_IN,
        )

        # Spine: a thin divider-colored horizontal line ~22% down the body.
        spine_y = body.y + int(body.h * self._SPINE_Y_FRAC)
        spine_region = Region(x=body.x, y=spine_y, w=body.w, h=0)
        Shape("line", stroke="divider", stroke_width_pt=1.0).render(pptx_slide, spine_region, theme)

        # Place events at evenly-spaced slot centers along the body width.
        n = len(self.events)
        # Reserve a little side-padding so end-dots don't touch the margins.
        edge_pad_in = 0.5
        edge_pad = int(edge_pad_in * 914400)
        span = body.w - 2 * edge_pad
        step = span // (n - 1) if n > 1 else 0

        dot_r = int(self._DOT_DIAMETER_IN * 914400)
        card_w = min(body.w // n - int(0.3 * 914400), int(3.0 * 914400))
        card_top = spine_y + int(0.25 * 914400)
        card_h = body.y + body.h - card_top

        for i, event in enumerate(self.events):
            cx = body.x + edge_pad + i * step
            # Dot on spine
            dot_region = Region(
                x=cx - dot_r // 2,
                y=spine_y - dot_r // 2,
                w=dot_r,
                h=dot_r,
            )
            Shape("circle", fill="accent").render(pptx_slide, dot_region, theme)

            # Event card below the dot — `when` eyebrow, title, description.
            card_x = cx - card_w // 2
            card_x = max(body.x, min(card_x, body.x + body.w - card_w))
            card_region = Region(x=card_x, y=card_top, w=card_w, h=card_h)

            children: list[Any] = [
                Text(
                    event.when.upper(),
                    role="caption",
                    color="accent",
                    bold=True,
                    use_display_font=True,
                ),
                Text(event.title, role="h2", color="text_primary", bold=True),
            ]
            weights: list[float] = [0.5, 1.0]
            if event.description:
                children.append(
                    Text(
                        event.description,
                        role="body",
                        color="text_muted",
                    )
                )
                weights.append(1.5)

            Stack(children, gap=0.12, weights=tuple(weights)).render(pptx_slide, card_region, theme)
