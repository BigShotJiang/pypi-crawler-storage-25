"""ContentSlide — generic title + body-layout.

The body is a caller-provided `Layout` instance from `pptxforge.layouts`.
This is the composable escape hatch for any slide shape not covered by
the specialized types (Media / Quote / Stat / Code / Comparison /
Timeline / Closing). Title at top, body fills the rest.
"""

from typing import TYPE_CHECKING, Any, Literal

from pptxforge.layouts import Layout, Region, Stack, Text
from pptxforge.slides._base import Slide, Transition
from pptxforge.slides._helpers import (
    SAFE_MARGIN_IN,
    coerce_transition,
    safe_content_region,
    set_slide_background,
)

if TYPE_CHECKING:
    from pptxforge.design import Theme


class ContentSlide(Slide):
    """General-purpose slide: a title at top, a user-built `Layout` beneath.

    Pass any `pptxforge.layouts.Layout` as `layout` — a `Stack` of
    `Text`s, an `IconRow`, a nested `TwoColumn`, whatever you need. The
    slide wraps the layout with a themed title and safe margins.

    Example:
        >>> from pptxforge.layouts import Stack, Text
        >>> ContentSlide(
        ...     title="Findings",
        ...     layout=Stack([
        ...         Text("- Latency down 30%", role="body"),
        ...         Text("- Cost down 12%", role="body"),
        ...         Text("- Adoption up 4x", role="body"),
        ...     ], gap=0.15),
        ... )
    """

    _TITLE_HEIGHT_IN = 1.1

    def __init__(
        self,
        *,
        title: str,
        layout: Layout,
        notes: str | None = None,
        transition: Literal["none", "fade", "morph"] | Transition | None = None,
        morph_from_previous: bool = False,
    ) -> None:
        if not title or not title.strip():
            raise ValueError("ContentSlide requires a non-empty title")
        if layout is None:
            raise ValueError("ContentSlide requires a layout; pass any pptxforge.layouts.Layout")
        self.title = title
        self.layout = layout
        self.notes = notes
        self.transition = coerce_transition(transition)
        self.morph_from_previous = morph_from_previous

    def render(self, pptx_slide: Any, theme: "Theme") -> None:
        set_slide_background(pptx_slide, theme)

        # Title band: top, h1-size, left-aligned, primary color.
        title_region = Region.inches(
            x=SAFE_MARGIN_IN,
            y=0.6,
            w=13.333 - 2 * SAFE_MARGIN_IN,
            h=self._TITLE_HEIGHT_IN,
        )
        Text(self.title, role="h1", color="primary", bold=True).render(
            pptx_slide, title_region, theme
        )

        # Body: the remainder below the title, with a small air-gap.
        body = Region.inches(
            x=SAFE_MARGIN_IN,
            y=0.6 + self._TITLE_HEIGHT_IN + 0.35,
            w=13.333 - 2 * SAFE_MARGIN_IN,
            h=7.5 - (0.6 + self._TITLE_HEIGHT_IN + 0.35) - SAFE_MARGIN_IN,
        )
        self.layout.render(pptx_slide, body, theme)


# Silence unused-import (kept for future extensions that compute regions here).
_ = (safe_content_region, Stack)
