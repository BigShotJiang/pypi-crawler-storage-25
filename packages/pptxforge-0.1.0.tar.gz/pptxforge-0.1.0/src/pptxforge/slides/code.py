"""CodeSlide — a monospace code block on a themed surface card."""

from collections.abc import Sequence
from typing import TYPE_CHECKING, Any, Literal

from pptxforge.layouts import CodeBlock, Region, Text
from pptxforge.slides._base import Slide, Transition
from pptxforge.slides._helpers import (
    SAFE_MARGIN_IN,
    coerce_transition,
    set_slide_background,
)

if TYPE_CHECKING:
    from pptxforge.design import Theme


Language = Literal[
    "python",
    "typescript",
    "javascript",
    "rust",
    "go",
    "sql",
    "bash",
    "yaml",
    "json",
    "toml",
]


class CodeSlide(Slide):
    """Title + a syntax-highlighted code block.

    `lang` identifies the language; highlighting lands in a later phase
    (Pygments → SVG → `a:pic`). Phase 4 renders plain mono text on a
    surface-colored rounded rectangle — the language is recorded for the
    upgrade path.

    `highlight_lines` is accepted and recorded; Phase 4 does not visually
    highlight (no rendering inside the CodeBlock supports it yet).

    Example:
        >>> CodeSlide(
        ...     title="Install",
        ...     code="pip install pptxforge",
        ...     lang="bash",
        ... )
    """

    _TITLE_HEIGHT_IN = 0.9

    def __init__(
        self,
        *,
        title: str,
        code: str,
        lang: Language = "python",
        highlight_lines: Sequence[int] | None = None,
        notes: str | None = None,
        transition: Literal["none", "fade", "morph"] | Transition | None = None,
    ) -> None:
        if not title or not title.strip():
            raise ValueError("CodeSlide requires a non-empty title")
        if not code:
            raise ValueError("CodeSlide requires non-empty code")
        self.title = title
        self.code = code
        self.lang = lang
        self.highlight_lines = tuple(highlight_lines) if highlight_lines else ()
        self.notes = notes
        self.transition = coerce_transition(transition)
        self.morph_from_previous = False

    def render(self, pptx_slide: Any, theme: "Theme") -> None:
        set_slide_background(pptx_slide, theme)

        title_region = Region.inches(
            x=SAFE_MARGIN_IN,
            y=0.6,
            w=13.333 - 2 * SAFE_MARGIN_IN,
            h=self._TITLE_HEIGHT_IN,
        )
        Text(self.title, role="h1", color="primary", bold=True).render(
            pptx_slide, title_region, theme
        )

        code_region = Region.inches(
            x=SAFE_MARGIN_IN,
            y=0.6 + self._TITLE_HEIGHT_IN + 0.3,
            w=13.333 - 2 * SAFE_MARGIN_IN,
            h=7.5 - (0.6 + self._TITLE_HEIGHT_IN + 0.3) - SAFE_MARGIN_IN,
        )
        # Keep code at 14pt so a reasonable amount of code fits; still in
        # the 14-16pt body range the anti-slop rules target.
        CodeBlock(self.code, lang=self.lang, size_pt=14.0).render(pptx_slide, code_region, theme)
