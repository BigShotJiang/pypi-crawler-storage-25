"""SectionSlide — a "Part N: Title" interstitial.

Layout: full-bleed dark background to signal a section break. An oversized
numeric anchor ("01") in accent color takes the left third; the section
title sits in the right two-thirds at hero size. The number is the visual
element — no accent rule, no decorative bars.
"""

from typing import TYPE_CHECKING, Any, Literal

from pptxforge.layouts import Grid, Region, Stack, Text
from pptxforge.slides._base import Slide, Transition
from pptxforge.slides._helpers import coerce_transition, set_slide_background

if TYPE_CHECKING:
    from pptxforge.design import Theme


class SectionSlide(Slide):
    """A section divider: big number + title, over a dark background.

    `number` is an integer position (1, 2, 3, …); it's zero-padded to
    two digits when rendered ("01", "02", …). Pass `number=None` for a
    title-only divider.

    Example:
        >>> SectionSlide(number=2, title="Results")
    """

    def __init__(
        self,
        *,
        number: int | None,
        title: str,
        caption: str | None = None,
        notes: str | None = None,
        transition: Literal["none", "fade", "morph"] | Transition | None = None,
    ) -> None:
        if not title or not title.strip():
            raise ValueError("SectionSlide requires a non-empty title")
        if number is not None and number < 0:
            raise ValueError(f"SectionSlide.number must be non-negative, got {number}")
        self.number = number
        self.title = title
        self.caption = caption
        self.notes = notes
        self.transition = coerce_transition(transition)
        self.morph_from_previous = False

    def render(self, pptx_slide: Any, theme: "Theme") -> None:
        # Dark background is the section-break signal.
        set_slide_background(pptx_slide, theme, role="background_dark")

        body = Region.inches(x=0.75, y=1.5, w=11.833, h=4.5)

        title_stack: list[Any] = [
            Text(
                self.title,
                role="hero",
                color="background_light",  # reverse out on dark bg
                bold=True,
                anchor="middle",
            )
        ]
        title_weights: list[float] = [2.0]
        if self.caption:
            title_stack.append(Text(self.caption, role="body", color="secondary", anchor="top"))
            title_weights.append(0.7)

        if self.number is None:
            Stack(title_stack, gap=0.25, weights=tuple(title_weights)).render(
                pptx_slide, body, theme
            )
            return

        # Oversized number on the left, title block on the right.
        number_text = f"{self.number:02d}"

        Grid(
            [
                Text(
                    number_text,
                    role="hero",
                    color="accent",
                    bold=True,
                    anchor="middle",
                    align="left",
                ),
                Stack(title_stack, gap=0.25, weights=tuple(title_weights)),
            ],
            cols=2,
            rows=1,
            gap=0.5,
        ).render(pptx_slide, body, theme)
