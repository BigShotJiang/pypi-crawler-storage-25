"""MediaSlide — image-dominant layout with a titled caption panel.

Structure: half-bleed image on the left, title + caption panel on the right.
The image uses fit="cover" so it fills its half without distortion — any
excess is cropped at the OOXML level (preserving the original PIL bytes).
"""

from pathlib import Path
from typing import TYPE_CHECKING, Any, Literal

from pptxforge.layouts import HalfBleed, Image, Shape, Stack, Text
from pptxforge.slides._base import Slide, Transition
from pptxforge.slides._helpers import (
    coerce_transition,
    full_slide_region,
    set_slide_background,
)

if TYPE_CHECKING:
    from pptxforge.design import Theme


class MediaSlide(Slide):
    """A slide dominated by one image with a titled caption panel alongside.

    `media` is a path to an image file (png, jpg, etc.). `side` controls
    which half of the slide the image occupies; content lands on the
    other half.

    Example:
        >>> MediaSlide(
        ...     title="Morphology under stress",
        ...     media=Path("fig-3.png"),
        ...     caption="Scanning electron micrograph, 500x.",
        ... )
    """

    def __init__(
        self,
        *,
        title: str,
        media: Path | str,
        caption: str | None = None,
        side: Literal["left", "right"] = "left",
        notes: str | None = None,
        transition: Literal["none", "fade", "morph"] | Transition | None = None,
    ) -> None:
        if not title or not title.strip():
            raise ValueError("MediaSlide requires a non-empty title")
        media_path = Path(media)
        if not media_path.is_file():
            raise FileNotFoundError(f"MediaSlide media not found: {media_path}")
        self.title = title
        self.media = media_path
        self.caption = caption
        self.side = side
        self.notes = notes
        self.transition = coerce_transition(transition)
        self.morph_from_previous = False

    def render(self, pptx_slide: Any, theme: "Theme") -> None:
        set_slide_background(pptx_slide, theme)

        content_children: list[Any] = [Text(self.title, role="h1", color="primary", bold=True)]
        content_weights: list[float] = [1.4]
        # Thin divider rule between title and caption — divider role (NOT
        # accent) so this doesn't violate the "no accent lines under
        # titles" anti-slop rule.
        content_children.append(Shape("line", stroke="divider", stroke_width_pt=0.75))
        content_weights.append(0.05)
        if self.caption:
            content_children.append(Text(self.caption, role="body", color="text_primary"))
            content_weights.append(1.2)

        HalfBleed(
            image=Image(self.media, fit="cover"),
            content=Stack(
                content_children,
                gap=0.25,
                weights=tuple(content_weights),
            ),
            side=self.side,
        ).render(pptx_slide, full_slide_region(), theme)
