"""ComparisonSlide — side-by-side before/after or pros/cons."""

from typing import TYPE_CHECKING, Any, Literal

from pptxforge.layouts import Region, Shape, Stack, Text, TwoColumn
from pptxforge.layouts._base import Layout
from pptxforge.slides._base import Slide, Transition
from pptxforge.slides._helpers import (
    SAFE_MARGIN_IN,
    ComparisonSide,
    coerce_transition,
    set_slide_background,
)

if TYPE_CHECKING:
    from pptxforge.design import Theme


class ComparisonSlide(Slide):
    """Title above two labeled columns of bullets.

    Use for before/after, pros/cons, option A / option B. Each side is a
    `ComparisonSide(header, items)`. The left header is colored with the
    theme's `primary` role and the right with `accent` by default, so
    the two sides read as visually distinct from across the room.

    Example:
        >>> from pptxforge.slides import ComparisonSide
        >>> ComparisonSlide(
        ...     title="Before / after",
        ...     left=ComparisonSide(
        ...         header="Before",
        ...         items=["Manual copy-paste", "14 min p95", "3 bugs/week"],
        ...     ),
        ...     right=ComparisonSide(
        ...         header="After",
        ...         items=["One click", "2.4 min p95", "0 bugs YTD"],
        ...     ),
        ... )
    """

    _TITLE_HEIGHT_IN = 1.0

    def __init__(
        self,
        *,
        title: str,
        left: ComparisonSide,
        right: ComparisonSide,
        left_color: str = "primary",
        right_color: str = "accent",
        notes: str | None = None,
        transition: Literal["none", "fade", "morph"] | Transition | None = None,
    ) -> None:
        if not title or not title.strip():
            raise ValueError("ComparisonSlide requires a non-empty title")
        if not isinstance(left, ComparisonSide):
            raise TypeError("ComparisonSlide.left must be a ComparisonSide instance")
        if not isinstance(right, ComparisonSide):
            raise TypeError("ComparisonSlide.right must be a ComparisonSide instance")
        self.title = title
        self.left = left
        self.right = right
        self.left_color = left_color
        self.right_color = right_color
        self.notes = notes
        self.transition = coerce_transition(transition)
        self.morph_from_previous = False

    def _column(self, side: ComparisonSide, header_color: str) -> Layout:
        children: list[Layout] = [
            Text(side.header, role="h2", color=header_color, bold=True),
            Shape("line", stroke="divider", stroke_width_pt=0.75),
        ]
        weights: list[float] = [1.0, 0.05]
        for item in side.items:
            children.append(Text(f"\u2022  {item}", role="body", color="text_primary"))
            weights.append(1.0)
        return Stack(children, gap=0.18, weights=tuple(weights))

    def render(self, pptx_slide: Any, theme: "Theme") -> None:
        set_slide_background(pptx_slide, theme)

        title_region = Region.inches(
            x=SAFE_MARGIN_IN,
            y=0.6,
            w=13.333 - 2 * SAFE_MARGIN_IN,
            h=self._TITLE_HEIGHT_IN,
        )
        Text(self.title, role="h1", color="primary", bold=True).render(
            pptx_slide, title_region, theme
        )

        body_top = 0.6 + self._TITLE_HEIGHT_IN + 0.3
        body = Region.inches(
            x=SAFE_MARGIN_IN,
            y=body_top,
            w=13.333 - 2 * SAFE_MARGIN_IN,
            h=7.5 - body_top - SAFE_MARGIN_IN,
        )

        TwoColumn(
            left=self._column(self.left, self.left_color),
            right=self._column(self.right, self.right_color),
            split=0.5,
            gap=0.6,
        ).render(pptx_slide, body, theme)
