"""QuoteSlide — an oversized quotation with attribution.

Layout: a giant opening-quote glyph (") in the accent color anchors the
top-left; the quote body sits in h1 size beneath, left-aligned with hanging
indent from the glyph. Attribution below in a muted caption. No accent
rule, no color bars.
"""

from typing import TYPE_CHECKING, Any, Literal

from pptxforge.layouts import Region, Stack, Text
from pptxforge.slides._base import Slide, Transition
from pptxforge.slides._helpers import coerce_transition, set_slide_background

if TYPE_CHECKING:
    from pptxforge.design import Theme


class QuoteSlide(Slide):
    """A single quotation styled as an editorial pull-quote.

    `quote` is the quotation text (without surrounding quotes — the slide
    adds its own decorative glyph). `attribution` is the "— Name, Role"
    line.

    Example:
        >>> QuoteSlide(
        ...     quote="Ship it.",
        ...     attribution="— The founder, on every feature",
        ... )
    """

    def __init__(
        self,
        *,
        quote: str,
        attribution: str | None = None,
        notes: str | None = None,
        transition: Literal["none", "fade", "morph"] | Transition | None = None,
    ) -> None:
        if not quote or not quote.strip():
            raise ValueError("QuoteSlide requires non-empty quote text")
        self.quote = quote
        self.attribution = attribution
        self.notes = notes
        self.transition = coerce_transition(transition)
        self.morph_from_previous = False

    def render(self, pptx_slide: Any, theme: "Theme") -> None:
        set_slide_background(pptx_slide, theme)

        # Oversized quote glyph as a visual anchor.
        glyph_region = Region.inches(x=1.0, y=1.0, w=2.5, h=2.5)
        Text(
            "\u201c",  # left double quotation mark
            role="hero",
            color="accent",
            bold=True,
            anchor="top",
        ).render(pptx_slide, glyph_region, theme)

        # Quote body, offset to the right of the glyph's visual column.
        body = Region.inches(x=1.2, y=2.6, w=11.1, h=4.0)

        children: list[Any] = [
            Text(
                self.quote,
                role="h1",
                color="text_primary",
                italic=True,
                bold=False,
                anchor="top",
            )
        ]
        weights: list[float] = [3.0]
        if self.attribution:
            children.append(
                Text(
                    self.attribution,
                    role="body",
                    color="text_muted",
                )
            )
            weights.append(0.6)

        Stack(children, gap=0.4, weights=tuple(weights)).render(pptx_slide, body, theme)
