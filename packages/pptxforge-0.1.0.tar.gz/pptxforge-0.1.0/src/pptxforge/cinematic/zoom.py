"""`cinematic_zoom` — smooth dolly-in from a wide image to a detail.

Two slides: the full image, then the same image scaled and offset so
the user-supplied sub-region fills the slide. The Morph engine pairs
the two image shapes by `!!Name` (set by `_CinematicImageSlide`) and
interpolates the position+scale, producing the dolly-in.

This is the most-used "mind-blowing" PowerPoint transition pattern —
not because the engine is special, but because the math turns one
image into a cinematic move.
"""

from __future__ import annotations

from pathlib import Path
from typing import TYPE_CHECKING

from pptxforge.cinematic._math import (
    compute_image_placement,
    image_pixel_size,
    validate_norm_region,
    warn_on_low_zoom_dpi,
)
from pptxforge.cinematic._slide import _CinematicImageSlide
from pptxforge.transitions import Morph

if TYPE_CHECKING:
    from pptxforge.deck import Deck


def cinematic_zoom(
    deck: Deck,
    image: str | Path,
    zoom_to: tuple[float, float, float, float],
    *,
    duration: float = 2.0,
    title: str | None = None,
    detail_title: str | None = None,
    morph_tag: str | None = None,
) -> None:
    """**Inserts two slides into `deck`** wired to morph as a dolly-in.

    The slide-pair is appended to the deck via `deck.add_slide(...)`
    twice, so the deck's slide count grows by 2. Slide A shows the
    full image; slide B shows the `zoom_to` sub-region scaled to fill
    the slide. PowerPoint's morph engine then plays a smooth zoom from
    A to B.

    Args:
        deck: The Deck to append slides to.
        image: Path to the source image. Must be at least a few MP for
            zoom factors above ~3× without visible pixelation; the
            function emits a UserWarning if the projected DPI falls
            below 100 (see `cinematic._math.warn_on_low_zoom_dpi`).
        zoom_to: `(x, y, w, h)` of the target sub-region in normalized
            image coordinates (each in `[0, 1]`). Pick `w` and `h`
            with the same aspect ratio as the slide (16:9) to avoid
            asymmetric scaling that crops one axis on slide B.
        duration: Morph duration in seconds. Cinematic dolly-ins want
            1.5–2.5 s; defaults to 2.0.
        title: Optional title shown on slide A above the image.
        detail_title: Optional title shown on slide B above the image.
        morph_tag: Override the auto-generated `!!Name` shared by the
            paired images. Default is a `cinematic_zoom_<id>` derived
            from the deck's current slide count — unique within one
            deck, so calling this helper multiple times in a row is
            safe.

    Example:
        >>> from pptxforge import Deck, themes
        >>> from pptxforge.cinematic import cinematic_zoom
        >>> deck = Deck(theme=themes.MIDNIGHT_EXECUTIVE)
        >>> cinematic_zoom(
        ...     deck,
        ...     image="hemoglobin_diagram.png",
        ...     zoom_to=(0.4, 0.3, 0.2, 0.2),
        ...     duration=2.5,
        ...     title="The full structure",
        ...     detail_title="Inside the heme group",
        ... )
        >>> deck.save("out/")
    """
    image_path = Path(image)
    if not image_path.is_file():
        raise FileNotFoundError(f"cinematic_zoom: image not found at {image_path}")
    validate_norm_region(zoom_to)
    if duration <= 0:
        raise ValueError(f"cinematic_zoom: duration must be positive, got {duration}")

    img_w_px, img_h_px = image_pixel_size(image_path)
    warn_on_low_zoom_dpi(img_w_px, img_h_px, zoom_to, helper_name="cinematic_zoom")

    if morph_tag is None:
        morph_tag = f"cinematic_zoom_{len(deck.slides)}"

    # Slide A: the whole image (norm_region = full image rectangle).
    a_x, a_y, a_w, a_h = compute_image_placement(img_w_px, img_h_px, (0.0, 0.0, 1.0, 1.0))
    deck.add_slide(
        _CinematicImageSlide(
            image_path=image_path,
            x_emu=a_x,
            y_emu=a_y,
            w_emu=a_w,
            h_emu=a_h,
            morph_tag=morph_tag,
            title=title,
        )
    )

    # Slide B: the zoom_to sub-region fills the slide.
    b_x, b_y, b_w, b_h = compute_image_placement(img_w_px, img_h_px, zoom_to)
    deck.add_slide(
        _CinematicImageSlide(
            image_path=image_path,
            x_emu=b_x,
            y_emu=b_y,
            w_emu=b_w,
            h_emu=b_h,
            morph_tag=morph_tag,
            title=detail_title,
            transition=Morph(duration=duration),
        )
    )
