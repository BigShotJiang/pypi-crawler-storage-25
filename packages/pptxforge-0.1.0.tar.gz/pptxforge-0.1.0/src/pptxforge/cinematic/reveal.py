"""`number_reveal` — counter morph (crossfade, sells as count-up).

The mechanic: two slides each carry a single big-number textbox sharing
the same `!!Name`. PowerPoint's morph engine pairs them and crossfades
the text between slide A's value and slide B's value.

**This is a crossfade, not a digit-by-digit interpolation.** PowerPoint
does not animate per-digit count-up; the text element fades from one
state to the other while the position/size morph plays underneath. At
duration ≥ 1.5 s with large bold text the eye reads the change as a
count-up. Don't oversell it.

Use cases:
- "Started at 0% → finished at 97%" — single-stat reveal.
- "$120k → $210k" — Q3 vs Q4 movement on a stat slide.
"""

from __future__ import annotations

from typing import TYPE_CHECKING

from pptxforge.cinematic._math import SLIDE_H_EMU, SLIDE_W_EMU
from pptxforge.cinematic._slide import _CinematicTextSlide
from pptxforge.transitions import Morph

if TYPE_CHECKING:
    from pptxforge.deck import Deck


def _format_value(v: int | float, suffix: str) -> str:
    """Render `v` as a string with `suffix` attached.

    Integers print without a decimal point; floats use `g` formatting
    (drops trailing zeros). The suffix is appended verbatim — pass `"%"`
    or `"M"` or `" users"` per your stat's natural form.
    """
    if isinstance(v, bool):  # bool is a subclass of int — guard
        raise TypeError(f"number_reveal: value must be numeric, got bool {v}")
    if isinstance(v, int):
        return f"{v}{suffix}"
    # float
    return f"{v:g}{suffix}"


def number_reveal(
    deck: Deck,
    start: int | float,
    end: int | float,
    label: str,
    *,
    duration: float = 1.5,
    suffix: str = "",
    morph_tag: str | None = None,
) -> None:
    """**Inserts two slides into `deck`** showing `start` then `end`.

    Both slides have a centered big-number textbox with the same
    `!!Name`. PowerPoint's morph engine pairs them and crossfades the
    digits — at `duration ≥ 1.5 s` with the default 200 pt bold text
    this reads to the audience as a count-up, even though it's a
    crossfade under the hood (PowerPoint's morph doesn't interpolate
    per-digit).

    The smaller `label` line below the number stays in place — same
    position, same colour, same text — across both slides, so it does
    not animate.

    Args:
        deck: The Deck to append slides to.
        start: Starting numeric value. `int` prints without decimal;
            `float` uses `g` format (`1.5`, `2.4`, `1234`).
        end: Ending numeric value, same formatting rules.
        label: Smaller line rendered below the value. Used as a
            description ("Conversion lift", "Active users", …) — the
            value carries the eye-grabbing count, the label tells the
            audience what's being counted.
        duration: Morph duration in seconds. ≥ 1.5 s is the rule of
            thumb for the crossfade to read as a count-up.
        suffix: String appended to the number, e.g. `"%"`, `"M"`,
            `" users"`. The full displayed text on slide A is
            `f"{start}{suffix}"`; same on B with `end`.
        morph_tag: Override the auto-generated `!!Name` shared by both
            value textboxes. Default: `"number_reveal_<id>"` derived
            from the deck's slide count.

    Example:
        >>> from pptxforge import Deck, themes
        >>> from pptxforge.cinematic import number_reveal
        >>> deck = Deck(theme=themes.MIDNIGHT_EXECUTIVE)
        >>> number_reveal(deck, start=0, end=97, label="Conversion lift",
        ...               suffix="%", duration=2.0)
    """
    if duration <= 0:
        raise ValueError(f"number_reveal: duration must be positive, got {duration}")
    if not label or not label.strip():
        raise ValueError("number_reveal: label must be non-empty")

    if morph_tag is None:
        morph_tag = f"number_reveal_{len(deck.slides)}"

    # Centred big-number region. Sized for ~200pt bold text on a 16:9
    # slide. The textbox itself is anchored middle-vertically so the
    # number sits a hair above slide centre; the label drops just below.
    box_w_emu = int(0.7 * SLIDE_W_EMU)
    box_h_emu = int(0.35 * SLIDE_H_EMU)
    box_x_emu = (SLIDE_W_EMU - box_w_emu) // 2
    box_y_emu = (SLIDE_H_EMU - box_h_emu) // 2 - int(0.05 * SLIDE_H_EMU)

    # Slide A: starting value.
    deck.add_slide(
        _CinematicTextSlide(
            text=_format_value(start, suffix),
            morph_tag=morph_tag,
            x_emu=box_x_emu,
            y_emu=box_y_emu,
            w_emu=box_w_emu,
            h_emu=box_h_emu,
            sub_label=label,
        )
    )
    # Slide B: ending value, with morph entry.
    deck.add_slide(
        _CinematicTextSlide(
            text=_format_value(end, suffix),
            morph_tag=morph_tag,
            x_emu=box_x_emu,
            y_emu=box_y_emu,
            w_emu=box_w_emu,
            h_emu=box_h_emu,
            sub_label=label,
            transition=Morph(duration=duration),
        )
    )
