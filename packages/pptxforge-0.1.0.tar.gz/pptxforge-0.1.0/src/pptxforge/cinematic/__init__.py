"""Cinematic morph helpers — the "mind-blowing" transitions, mechanically.

Every helper here builds *pairs (or chains) of slides* whose shapes
are positioned and tagged so PowerPoint's morph engine produces a
specific cinematic effect. The mechanics — `!!Name` shape pairing,
image positioning, autoshape kinds — all live in research/morph.md
and `pptxforge.morph`. This module is the API surface that turns
those primitives into one-call effects.

**Side-effect API.** Helpers append slides to the deck via
`deck.add_slide(...)`. Each helper's docstring leads with "Inserts N
slides into the deck" so callers aren't surprised when their slide
count jumps by 2 (or more) per call.

Available helpers:

- `cinematic_zoom(deck, image, zoom_to, ...)` — 2 slides; smooth
  dolly-in from a wide image to a detail.
- `prezi_canvas(deck, image, stops, ...)` — N slides; chained morph
  panning across one large image (Prezi-style).
- `number_reveal(deck, start, end, label, ...)` — 2 slides;
  text-shape morph that reads as a counter from `start` to `end`.
  Crossfade under the hood (PowerPoint's morph doesn't interpolate
  digits) — sells the count if duration ≥ 1.5 s.
- `shape_transform(deck, from_shape, to_shape, ...)` — 2 slides;
  forces dissimilar autoshapes (circle → square, star → arrow) to
  morph via the `!!Name` convention.
- `model3d_flight(deck, model, waypoints, ...)` — N slides; chained
  morph between camera poses on one 3D model. Same model file across
  every slide; PowerPoint flies the camera between waypoints in
  slideshow mode.

Three more helpers (`vertical_scroll`, `screen_dive`, `grid_focus`)
are deferred — see FOLLOWUPS.md 2026-04-27 for the mechanic each
introduces and the rough effort to land them.
"""

from pptxforge.cinematic.canvas import CanvasStop, prezi_canvas
from pptxforge.cinematic.flight import FlightWaypoint, model3d_flight
from pptxforge.cinematic.reveal import number_reveal
from pptxforge.cinematic.transform import ShapeSpec, shape_transform
from pptxforge.cinematic.zoom import cinematic_zoom

__all__ = [
    "cinematic_zoom",
    "prezi_canvas",
    "CanvasStop",
    "number_reveal",
    "shape_transform",
    "ShapeSpec",
    "model3d_flight",
    "FlightWaypoint",
]
