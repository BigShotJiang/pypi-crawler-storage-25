"""Slide subclasses used by the cinematic helpers.

Each helper places shapes outside the layout-region paradigm — images
that bleed off-slide at scale 5×, autoshapes positioned with `!!Name`
for forced morph pairing, etc. The helpers are not user-facing
templates so these subclasses are intentionally private (`_` prefix).

Three shapes:

- `_CinematicImageSlide` — one image at arbitrary `(x, y, w, h)` Emu,
  optionally tagged for `!!Name` morph pairing. Used by
  `cinematic_zoom`, `prezi_canvas`, and (in followups)
  `vertical_scroll` / `screen_dive` / `grid_focus`.
- `_CinematicTextSlide` — one big text box at arbitrary position with a
  morph tag. Used by `number_reveal`.
- `_CinematicShapeSlide` — one autoshape with a morph tag. Used by
  `shape_transform`.

Optional title text on every slide is rendered through the standard
`Text` primitive against `safe_content_region`-style coordinates so
the deck-wide theme applies.
"""

from __future__ import annotations

from pathlib import Path
from typing import TYPE_CHECKING, Any

from pptx.dml.color import RGBColor
from pptx.enum.text import MSO_ANCHOR, PP_ALIGN
from pptx.util import Emu, Pt

from pptxforge.layouts import Region, Text
from pptxforge.layouts._rendering import _SHAPE_KIND_TO_MSO, resolve_color
from pptxforge.morph import set_morph_tag
from pptxforge.slides._base import Slide, Transition
from pptxforge.slides._helpers import SAFE_MARGIN_IN, set_slide_background
from pptxforge.transitions import Morph

if TYPE_CHECKING:
    from pptxforge.design import Theme


_TITLE_HEIGHT_IN = 0.7
_TITLE_TOP_IN = 0.4


def _render_title(pptx_slide: Any, theme: Theme, title: str) -> None:
    """Render the helper's optional title text in the existing theme h2 step."""
    region = Region.inches(
        x=SAFE_MARGIN_IN,
        y=_TITLE_TOP_IN,
        w=13.333 - 2 * SAFE_MARGIN_IN,
        h=_TITLE_HEIGHT_IN,
    )
    Text(title, role="h2", color="primary", bold=True).render(pptx_slide, region, theme)


class _CinematicImageSlide(Slide):
    """Slide carrying one image at arbitrary Emu placement.

    The image's `cnvPr/@name` is rewritten to `!!<morph_tag>` via
    `pptxforge.morph.set_morph_tag` so PowerPoint's morph engine pairs
    it with the matching-tagged image on a neighbouring slide
    (research/morph.md §4.1, tier-1).
    """

    def __init__(
        self,
        *,
        image_path: Path,
        x_emu: int,
        y_emu: int,
        w_emu: int,
        h_emu: int,
        morph_tag: str,
        title: str | None = None,
        notes: str | None = None,
        transition: Transition | None = None,
    ) -> None:
        self.image_path = image_path
        self.x_emu = x_emu
        self.y_emu = y_emu
        self.w_emu = w_emu
        self.h_emu = h_emu
        self.morph_tag = morph_tag
        self.title = title
        self.notes = notes
        self.transition = transition
        self.morph_from_previous = isinstance(transition, Morph)

    def render(self, pptx_slide: Any, theme: Theme) -> None:
        set_slide_background(pptx_slide, theme)
        if self.title:
            _render_title(pptx_slide, theme, self.title)
        pic = pptx_slide.shapes.add_picture(
            str(self.image_path),
            Emu(self.x_emu),
            Emu(self.y_emu),
            width=Emu(self.w_emu),
            height=Emu(self.h_emu),
        )
        set_morph_tag(pic, self.morph_tag)


class _CinematicTextSlide(Slide):
    """Slide carrying one large text box tagged for morph pairing.

    Used by `number_reveal` — both the start-value and end-value slides
    have a textbox with the same `!!<morph_tag>` so the morph engine
    pairs them and crossfades the digits between them.
    """

    def __init__(
        self,
        *,
        text: str,
        morph_tag: str,
        x_emu: int,
        y_emu: int,
        w_emu: int,
        h_emu: int,
        size_pt: float = 200.0,
        color_token: str = "primary",
        sub_label: str | None = None,
        title: str | None = None,
        notes: str | None = None,
        transition: Transition | None = None,
    ) -> None:
        self.text = text
        self.morph_tag = morph_tag
        self.x_emu = x_emu
        self.y_emu = y_emu
        self.w_emu = w_emu
        self.h_emu = h_emu
        self.size_pt = size_pt
        self.color_token = color_token
        self.sub_label = sub_label
        self.title = title
        self.notes = notes
        self.transition = transition
        self.morph_from_previous = isinstance(transition, Morph)

    def render(self, pptx_slide: Any, theme: Theme) -> None:
        set_slide_background(pptx_slide, theme)
        if self.title:
            _render_title(pptx_slide, theme, self.title)
        # The morphing text element — its !!Name pairs across slides.
        box = pptx_slide.shapes.add_textbox(
            Emu(self.x_emu), Emu(self.y_emu), Emu(self.w_emu), Emu(self.h_emu)
        )
        tf = box.text_frame
        tf.margin_left = Emu(0)
        tf.margin_right = Emu(0)
        tf.margin_top = Emu(0)
        tf.margin_bottom = Emu(0)
        tf.word_wrap = True
        tf.vertical_anchor = MSO_ANCHOR.MIDDLE
        p = tf.paragraphs[0]
        p.alignment = PP_ALIGN.CENTER
        run = p.add_run()
        run.text = self.text
        run.font.size = Pt(self.size_pt)
        run.font.bold = True
        run.font.color.rgb = RGBColor(*resolve_color(theme, self.color_token).rgb)  # type: ignore[no-untyped-call]
        set_morph_tag(box, self.morph_tag)
        # Optional smaller label below the value.
        if self.sub_label:
            label_h_emu = Emu(int(0.6 * 914_400))
            label_box = pptx_slide.shapes.add_textbox(
                Emu(self.x_emu),
                Emu(self.y_emu + self.h_emu + int(0.1 * 914_400)),
                Emu(self.w_emu),
                label_h_emu,
            )
            ltf = label_box.text_frame
            ltf.margin_left = Emu(0)
            ltf.margin_right = Emu(0)
            ltf.margin_top = Emu(0)
            ltf.margin_bottom = Emu(0)
            lp = ltf.paragraphs[0]
            lp.alignment = PP_ALIGN.CENTER
            lrun = lp.add_run()
            lrun.text = self.sub_label
            lrun.font.size = Pt(20)
            lrun.font.color.rgb = RGBColor(*resolve_color(theme, "text_muted").rgb)  # type: ignore[no-untyped-call]


class _CinematicShapeSlide(Slide):
    """Slide carrying one autoshape tagged for morph pairing.

    Used by `shape_transform` — both slides emit one shape with the
    same `!!<morph_tag>`. The shape *kinds* differ between slides, so
    the morph engine forces a kind-to-kind interpolation per the
    research-doc §4.1 tier-1 contract ("any two objects of the same
    kind, plus the cross-kind exception under !!Name").
    """

    def __init__(
        self,
        *,
        kind: str,
        morph_tag: str,
        x_emu: int,
        y_emu: int,
        w_emu: int,
        h_emu: int,
        fill_token: str = "accent",
        text: str | None = None,
        title: str | None = None,
        notes: str | None = None,
        transition: Transition | None = None,
    ) -> None:
        if kind not in _SHAPE_KIND_TO_MSO:
            valid = sorted(_SHAPE_KIND_TO_MSO.keys())
            raise ValueError(
                f"_CinematicShapeSlide: unknown kind {kind!r}; expected one of {valid}"
            )
        self.kind = kind
        self.morph_tag = morph_tag
        self.x_emu = x_emu
        self.y_emu = y_emu
        self.w_emu = w_emu
        self.h_emu = h_emu
        self.fill_token = fill_token
        self.text = text
        self.title = title
        self.notes = notes
        self.transition = transition
        self.morph_from_previous = isinstance(transition, Morph)

    def render(self, pptx_slide: Any, theme: Theme) -> None:
        set_slide_background(pptx_slide, theme)
        if self.title:
            _render_title(pptx_slide, theme, self.title)
        shape_type = _SHAPE_KIND_TO_MSO[self.kind]
        shape = pptx_slide.shapes.add_shape(
            shape_type,
            Emu(self.x_emu),
            Emu(self.y_emu),
            Emu(self.w_emu),
            Emu(self.h_emu),
        )
        shape.fill.solid()
        shape.fill.fore_color.rgb = RGBColor(*resolve_color(theme, self.fill_token).rgb)  # type: ignore[no-untyped-call]
        shape.line.fill.background()
        shape.shadow.inherit = False
        if self.text:
            tf = shape.text_frame
            tf.margin_left = Emu(int(0.1 * 914_400))
            tf.margin_right = Emu(int(0.1 * 914_400))
            tf.margin_top = Emu(int(0.05 * 914_400))
            tf.margin_bottom = Emu(int(0.05 * 914_400))
            tf.vertical_anchor = MSO_ANCHOR.MIDDLE
            p = tf.paragraphs[0]
            p.alignment = PP_ALIGN.CENTER
            run = p.add_run()
            run.text = self.text
            run.font.size = Pt(28)
            run.font.bold = True
            run.font.color.rgb = RGBColor(*resolve_color(theme, "background_light").rgb)  # type: ignore[no-untyped-call]
        set_morph_tag(shape, self.morph_tag)
