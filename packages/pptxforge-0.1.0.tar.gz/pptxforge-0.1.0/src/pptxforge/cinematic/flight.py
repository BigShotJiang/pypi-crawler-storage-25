"""`model3d_flight` --- chained morph between N camera views of one 3D model.

The mechanic: N consecutive `Model3DSlide`s, each with the same `model`
and `stable_key` and a different `Camera`. Slide 2..N carry
`Morph(duration=...)`, so PowerPoint pairs the 3D shapes by
`a16:creationId` and interpolates the camera between waypoints
(research/morph.md section 4.2).

Why a helper: spelling this out by hand is tedious --- callers had to
repeat the model path, set `morph_from_previous=True` on every slide
except the first, and invent a stable key shared across all stops. A
five-stop flight is a one-call here.

Same shape as `prezi_canvas`: a deck-mutating function that takes a
list of waypoints. The image-part dedup that made `prezi_canvas`
cheap shows up here too --- python-pptx hashes the GLB bytes, so all
N slides reference one media part in the saved .pptx.
"""

from __future__ import annotations

import warnings
from collections.abc import Sequence
from dataclasses import dataclass
from pathlib import Path
from typing import TYPE_CHECKING
from uuid import uuid5

from pptxforge.model3d import PPTXFORGE_UUID_NAMESPACE, Camera
from pptxforge.slides.model3d import Model3DSlide
from pptxforge.transitions import Morph

if TYPE_CHECKING:
    from pptxforge.deck import Deck


_DEFAULT_DURATION = 1.5
_SOFT_WAYPOINT_LIMIT = 12


@dataclass(frozen=True, slots=True)
class FlightWaypoint:
    """One stop on a `model3d_flight` camera tour.

    Attributes:
        camera: The `Camera` pose at this waypoint. Required.
        title: Optional slide title. Titles ideally appear on every
            waypoint --- PowerPoint's morph engine fades unmatched
            shapes, so a title that exists on slide 3 but not slides
            1-2 will fade in (still cinematic, just be intentional).
        caption: Reserved for a future caption band; currently unused
            by the renderer (`Model3DSlide` doesn't take a caption).
            Carried so callers can document intent in the source and
            so the dataclass shape is forward-compatible.
        duration: Override the flight's default morph duration into
            this waypoint, in seconds. `None` (the default) uses the
            flight-wide default. Ignored on the first waypoint, which
            has no incoming morph.
    """

    camera: Camera
    title: str | None = None
    caption: str | None = None
    duration: float | None = None


def model3d_flight(
    deck: Deck,
    model: str | Path,
    waypoints: Sequence[FlightWaypoint],
    *,
    duration: float = _DEFAULT_DURATION,
) -> None:
    """**Inserts `len(waypoints)` slides into `deck`** chained by Morph.

    Each slide hosts the same `model` from a different `Camera` pose.
    Slide 1 has no incoming transition; slides 2..N carry
    `Morph(duration=...)`, so PowerPoint flies the camera between
    waypoints in slideshow mode.

    Slide-pairing is via `stable_key` (UUIDv5 over the deck's current
    slide count + the model path), so multiple `model3d_flight` calls
    in the same deck don't collide --- each gets its own key and pairs
    only within itself.

    Duration resolves per-waypoint > flight default > library default
    (1.5 s). The library default lives at the call signature, so
    callers see it in tooling.

    Args:
        deck: The Deck to append slides to.
        model: Path to the GLB 2.0 model. Re-used across every
            waypoint; python-pptx dedupes the media part so the
            saved .pptx ships one copy of the GLB regardless of N.
        waypoints: At least 2 `FlightWaypoint`s. >12 emits a
            UserWarning suggesting the flight be split --- audiences
            lose track past ~12 stops and PowerPoint's frame
            interpolation can struggle.
        duration: Default morph duration between consecutive waypoints,
            in seconds. Overridden by `waypoint.duration` when set.
            Cinematic camera flights want 1.5-2.5 s per leg.

    Raises:
        ValueError: When `len(waypoints) < 2`. For a single 3D slide,
            call `deck.add_3d_slide` directly.
        ValueError: When `duration <= 0`, or when any waypoint
            override `duration <= 0`.
        TypeError: When a waypoint's `camera` isn't a `Camera`
            instance.

    Example:
        >>> from pptxforge import Deck, themes, model3d_flight, FlightWaypoint
        >>> from pptxforge.model3d import Camera
        >>> deck = Deck(theme=themes.MIDNIGHT_EXECUTIVE)
        >>> model3d_flight(
        ...     deck,
        ...     model="helmet.glb",
        ...     waypoints=[
        ...         FlightWaypoint(Camera(azimuth=20, elevation=15),
        ...                        title="Wide"),
        ...         FlightWaypoint(Camera(azimuth=0, elevation=0,
        ...                               distance=0.5),
        ...                        title="Front close-up"),
        ...         FlightWaypoint(Camera(azimuth=90, elevation=10),
        ...                        title="Side profile"),
        ...     ],
        ...     duration=2.0,
        ... )
    """
    if len(waypoints) < 2:
        raise ValueError(
            f"model3d_flight requires at least 2 waypoints; got {len(waypoints)}. "
            "For a single 3D slide use add_3d_slide directly."
        )
    if duration <= 0:
        raise ValueError(f"model3d_flight: duration must be positive, got {duration}")
    for i, wp in enumerate(waypoints):
        if not isinstance(wp.camera, Camera):
            raise TypeError(
                f"model3d_flight: waypoints[{i}].camera must be a Camera instance, "
                f"got {type(wp.camera).__name__}"
            )
        if wp.duration is not None and wp.duration <= 0:
            raise ValueError(
                f"model3d_flight: waypoints[{i}].duration must be positive when set, "
                f"got {wp.duration}"
            )

    if len(waypoints) > _SOFT_WAYPOINT_LIMIT:
        warnings.warn(
            f"model3d_flight: {len(waypoints)} waypoints exceeds the soft limit of "
            f"{_SOFT_WAYPOINT_LIMIT}. PowerPoint's morph frame interpolation can "
            "struggle past this and audiences lose track of the camera path. "
            "Consider breaking the flight into multiple shorter cinematics.",
            category=UserWarning,
            stacklevel=2,
        )

    model_path = Path(model)
    # UUIDv5 namespaced to this deck position + model. Two flights in the
    # same deck get distinct stable_keys and pair only within themselves.
    flight_id = f"model3d_flight:{len(deck.slides)}:{model_path}"
    stable_key = str(uuid5(PPTXFORGE_UUID_NAMESPACE, flight_id))

    for i, wp in enumerate(waypoints):
        leg_duration = wp.duration if wp.duration is not None else duration
        transition: Morph | None = Morph(duration=leg_duration) if i > 0 else None
        title = wp.title if wp.title is not None else ""
        # Model3DSlide requires a non-empty title; fall back to a synthetic
        # "Waypoint N of M" so callers can leave titles off without the
        # constructor rejecting the slide.
        if not title.strip():
            title = f"Waypoint {i + 1} of {len(waypoints)}"
        deck.add_slide(
            Model3DSlide(
                title=title,
                model=model_path,
                camera=wp.camera,
                stable_key=stable_key,
                morph_from_previous=i > 0,
                transition=transition,
            )
        )
