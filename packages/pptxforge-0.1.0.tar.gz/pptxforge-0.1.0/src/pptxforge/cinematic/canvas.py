"""`prezi_canvas` — chained morph panning across one image (Prezi-style).

`cinematic_zoom`'s mechanic, generalised to N stops in a row. The same
image is referenced by every slide; only its position and scale change.
Morph between consecutive slides interpolates the camera move.

Image-part dedup matters here: python-pptx's
`SlidePart.get_or_add_image_part` SHA-1-dedupes when you call
`add_picture(same_path, …)` across slides, so a 12-stop tour over a
2 MB image still ships ~2 MB of image data, not 24 MB.
"""

from __future__ import annotations

from collections.abc import Sequence
from dataclasses import dataclass
from pathlib import Path
from typing import TYPE_CHECKING

from pptxforge.cinematic._math import (
    compute_image_placement,
    image_pixel_size,
    validate_norm_region,
    warn_on_low_zoom_dpi,
)
from pptxforge.cinematic._slide import _CinematicImageSlide
from pptxforge.transitions import Morph

if TYPE_CHECKING:
    from pptxforge.deck import Deck


@dataclass(frozen=True, slots=True)
class CanvasStop:
    """One stop on a `prezi_canvas` tour.

    Attributes:
        region: `(x, y, w, h)` in normalized image coords (`[0, 1]`)
            — the visible window onto the canvas at this stop.
        title: Optional title rendered above the image.
    """

    region: tuple[float, float, float, float]
    title: str | None = None


def prezi_canvas(
    deck: Deck,
    image: str | Path,
    stops: Sequence[CanvasStop],
    *,
    duration: float = 1.5,
    morph_tag: str | None = None,
) -> None:
    """**Inserts `len(stops)` slides into `deck`** chained by Morph.

    Each slide shows the same `image` positioned and scaled so that
    `stops[i].region` fills the slide rectangle. The first slide has
    no transition; slides 2..N each carry `Morph(duration=...)`. The
    image part is deduped across slides via python-pptx's SHA-1
    cache, so the deck size doesn't multiply with stop count.

    Args:
        deck: The Deck to append slides to.
        image: Path to the canvas image. Must be at least
            `100 DPI × 13.33"` ≈ 1333 pixels wide divided by the
            smallest stop's `w` to avoid triggering the low-DPI
            warning at the most-zoomed stop.
        stops: At least 2 stops. Each is a `CanvasStop`.
        duration: Morph duration between consecutive stops. Cinematic
            pans want 1.5–2.5 s.
        morph_tag: Override the auto-generated `!!Name` shared by all
            stop images. Default: `"prezi_canvas_<id>"` derived from
            deck slide count.

    Example:
        >>> from pptxforge import Deck, themes
        >>> from pptxforge.cinematic import prezi_canvas, CanvasStop
        >>> deck = Deck(theme=themes.MIDNIGHT_EXECUTIVE)
        >>> prezi_canvas(
        ...     deck,
        ...     image="city_skyline.jpg",
        ...     stops=[
        ...         CanvasStop(region=(0.0, 0.0, 1.0, 1.0), title="The skyline"),
        ...         CanvasStop(region=(0.1, 0.4, 0.3, 0.3), title="The harbour"),
        ...         CanvasStop(region=(0.6, 0.2, 0.3, 0.3), title="The new tower"),
        ...     ],
        ...     duration=2.0,
        ... )
    """
    image_path = Path(image)
    if not image_path.is_file():
        raise FileNotFoundError(f"prezi_canvas: image not found at {image_path}")
    if len(stops) < 2:
        raise ValueError(
            f"prezi_canvas requires at least 2 stops; got {len(stops)}. "
            "For a single zoom move use cinematic_zoom instead."
        )
    if duration <= 0:
        raise ValueError(f"prezi_canvas: duration must be positive, got {duration}")
    for stop in stops:
        validate_norm_region(stop.region)
    # Run the DPI check on each stop so the most-zoomed stop is
    # caught even if earlier stops don't trigger it.
    img_w_px, img_h_px = image_pixel_size(image_path)
    for stop in stops:
        warn_on_low_zoom_dpi(img_w_px, img_h_px, stop.region, helper_name="prezi_canvas")

    if morph_tag is None:
        morph_tag = f"prezi_canvas_{len(deck.slides)}"

    for i, stop in enumerate(stops):
        x, y, w, h = compute_image_placement(img_w_px, img_h_px, stop.region)
        # First slide has no transition; subsequent ones carry Morph.
        transition = Morph(duration=duration) if i > 0 else None
        deck.add_slide(
            _CinematicImageSlide(
                image_path=image_path,
                x_emu=x,
                y_emu=y,
                w_emu=w,
                h_emu=h,
                morph_tag=morph_tag,
                title=stop.title,
                transition=transition,
            )
        )
