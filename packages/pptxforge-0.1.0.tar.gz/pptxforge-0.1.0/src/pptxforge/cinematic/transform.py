"""`shape_transform` — force two autoshapes to morph via `!!Name`.

Without `!!`-tagging, PowerPoint's morph engine refuses to pair shapes
of different kinds (research/morph.md §4.1, tier-4 says "same shape
type" is required). Tagging both shapes with the same `!!Name`
overrides this — tier-1 in the cascade — and PowerPoint forces a
kind-to-kind interpolation. Circle → square, star → arrow, triangle
→ heart all work.

Use cases:
- A logo morphs into the product it represents.
- A simple shape (circle) morphs into a more complex one (star) as
  emphasis.
- Iconography that changes between slides while still feeling like
  the same element.
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import TYPE_CHECKING, Literal

from pptxforge.cinematic._math import SLIDE_H_EMU, SLIDE_W_EMU
from pptxforge.cinematic._slide import _CinematicShapeSlide
from pptxforge.layouts._rendering import _SHAPE_KIND_TO_MSO
from pptxforge.transitions import Morph

if TYPE_CHECKING:
    from pptxforge.deck import Deck


# The subset of `_SHAPE_KIND_TO_MSO` keys exposed via ShapeSpec.kind.
# Keep it focused on shapes likely to look intentional in a morph —
# decorative kinds (heart) are included; obscure kinds (e.g. action
# buttons) are not. Callers who want an autoshape outside this list
# should reach for the `Shape` primitive directly.
ShapeSpecKind = Literal[
    "rectangle",
    "square",
    "rounded_rectangle",
    "circle",
    "oval",
    "triangle",
    "diamond",
    "pentagon",
    "hexagon",
    "star",
    "arrow",
    "arrow_up",
    "arrow_down",
    "arrow_left",
    "arrow_right",
    "heart",
]


@dataclass(frozen=True, slots=True)
class ShapeSpec:
    """One shape on either side of a `shape_transform` pair.

    Attributes:
        kind: An autoshape kind. Accepts any key in `_SHAPE_KIND_TO_MSO`
            (see `pptxforge.layouts.Shape` for the full list); the
            `Literal` here is the curated subset most useful for morph.
        color_token: Palette role name for the fill. Default `"accent"`.
            Pass `"primary"` / `"secondary"` / dotted aliases like
            `"accent.key"` (resolved via `pptxforge.layouts._tokens`).
        text: Optional centered text inside the shape (rendered in
            `text_on_dark`-style reverse-out). Useful for label-and-
            shape morph pairs.
    """

    kind: ShapeSpecKind
    color_token: str = "accent"
    text: str | None = None

    def __post_init__(self) -> None:
        if self.kind not in _SHAPE_KIND_TO_MSO:
            valid = sorted(_SHAPE_KIND_TO_MSO.keys())
            raise ValueError(f"ShapeSpec.kind must be one of {valid}; got {self.kind!r}")


def shape_transform(
    deck: Deck,
    from_shape: ShapeSpec,
    to_shape: ShapeSpec,
    *,
    duration: float = 1.5,
    title: str | None = None,
    morph_tag: str | None = None,
) -> None:
    """**Inserts two slides into `deck`** with shapes that morph into each other.

    Both slides emit a single autoshape with the same `!!Name` (the
    `morph_tag`). PowerPoint's morph engine treats matching `!!`-named
    shapes as paired regardless of kind — so a circle on slide A and a
    square on slide B render as a smooth shape interpolation rather
    than two unrelated shapes fading.

    Both shapes are rendered at the same centered position and size
    so the interpolation reads as a transformation rather than a move.
    To layer in a position move, follow this helper with a manual
    `Morph` slide that places the same `!!`-tagged shape elsewhere.

    Args:
        deck: The Deck to append slides to.
        from_shape: ShapeSpec for slide A's shape.
        to_shape: ShapeSpec for slide B's shape.
        duration: Morph duration in seconds. 1.0–1.5 s reads as
            "transformation"; 2.0+ s drags.
        title: Optional title shown above both slides.
        morph_tag: Override the auto-generated `!!Name`. Default:
            `"shape_transform_<id>"` derived from the deck's slide
            count.

    Example:
        >>> from pptxforge import Deck, themes
        >>> from pptxforge.cinematic import shape_transform, ShapeSpec
        >>> deck = Deck(theme=themes.MIDNIGHT_EXECUTIVE)
        >>> shape_transform(
        ...     deck,
        ...     from_shape=ShapeSpec(kind="circle", color_token="accent",
        ...                          text="Idea"),
        ...     to_shape=ShapeSpec(kind="star", color_token="accent",
        ...                        text="Idea"),
        ...     duration=1.5,
        ...     title="From idea to highlight",
        ... )
    """
    if duration <= 0:
        raise ValueError(f"shape_transform: duration must be positive, got {duration}")

    if morph_tag is None:
        morph_tag = f"shape_transform_{len(deck.slides)}"

    # Centred shape, sized to ~40% of slide width × 60% of slide height
    # — enough to read as the slide's primary element without filling
    # the whole canvas.
    shape_w_emu = int(0.40 * SLIDE_W_EMU)
    shape_h_emu = int(0.60 * SLIDE_H_EMU)
    shape_x_emu = (SLIDE_W_EMU - shape_w_emu) // 2
    shape_y_emu = (SLIDE_H_EMU - shape_h_emu) // 2 + int(0.05 * SLIDE_H_EMU)

    # Slide A.
    deck.add_slide(
        _CinematicShapeSlide(
            kind=from_shape.kind,
            morph_tag=morph_tag,
            x_emu=shape_x_emu,
            y_emu=shape_y_emu,
            w_emu=shape_w_emu,
            h_emu=shape_h_emu,
            fill_token=from_shape.color_token,
            text=from_shape.text,
            title=title,
        )
    )
    # Slide B with morph entry.
    deck.add_slide(
        _CinematicShapeSlide(
            kind=to_shape.kind,
            morph_tag=morph_tag,
            x_emu=shape_x_emu,
            y_emu=shape_y_emu,
            w_emu=shape_w_emu,
            h_emu=shape_h_emu,
            fill_token=to_shape.color_token,
            text=to_shape.text,
            title=title,
            transition=Morph(duration=duration),
        )
    )
