"""Geometry helpers shared by the cinematic helpers.

The core operation: given an image and a normalized sub-region of it
that should "fill" a slide, compute the (x, y, w, h) Emu placement of
the entire image such that the sub-region occupies the slide rectangle.

`compute_image_placement` is the workhorse. `cinematic_zoom`,
`prezi_canvas`, `vertical_scroll`, `screen_dive`, `grid_focus` all
share its math — only the choice of `norm_region` differs per helper.
"""

from __future__ import annotations

import warnings
from pathlib import Path

from pptxforge.layouts._base import EMU_PER_INCH

# Slide standard 16:9 dimensions. The canonical PowerPoint values are
# exact integers in EMU; derive inches FROM EMU rather than the other
# way round so 1920×1080 images line up to the EMU exactly. (Deriving
# EMU from `13.333 * 914_400` truncates to 12_192_665, off by 665 EMU
# from PowerPoint's actual 12_192_000 — small but enough to make
# placement math fail equality checks.) Source: `_ASPECT_DIMS["16:9"]`
# in `pptxforge.deck`.
SLIDE_W_EMU = 12_192_000
SLIDE_H_EMU = 6_858_000
SLIDE_W_IN = SLIDE_W_EMU / EMU_PER_INCH  # 13 + 1/3
SLIDE_H_IN = SLIDE_H_EMU / EMU_PER_INCH  # 7.5

# Below this projected DPI on the slide, raster zoom looks pixelated
# in PowerPoint's renderer. Empirical floor; warn rather than reject so
# the caller can ignore it for stylistic effect (deliberate pixel art,
# illustrative pixelation).
_MIN_PROJECTED_DPI = 100.0


def image_pixel_size(path: Path) -> tuple[int, int]:
    """Return `(width_px, height_px)` of the image at `path`.

    Uses PIL (a transitive dependency of python-pptx). Raises
    `ValueError` on non-positive dimensions.
    """
    from PIL import Image as PILImage

    with PILImage.open(path) as im:
        w, h = im.size
    if w <= 0 or h <= 0:
        raise ValueError(f"image {path} has non-positive dimensions {w}x{h}")
    return w, h


def validate_norm_region(region: tuple[float, float, float, float]) -> None:
    """Reject a sub-region that lies outside `[0, 1]` or has non-positive size."""
    x, y, w, h = region
    if w <= 0 or h <= 0:
        raise ValueError(f"norm_region width/height must be positive; got w={w}, h={h}")
    # Allow tiny epsilons over 1.0 for floating-point round-trips.
    eps = 1e-6
    if not (0.0 - eps <= x <= 1.0 + eps and 0.0 - eps <= y <= 1.0 + eps):
        raise ValueError(f"norm_region origin {(x, y)} outside [0, 1]")
    if x + w > 1.0 + eps or y + h > 1.0 + eps:
        raise ValueError(
            f"norm_region {region} extends past the image bounds (x+w={x + w}, y+h={y + h})"
        )


def compute_image_placement(
    image_w_px: int,
    image_h_px: int,
    norm_region: tuple[float, float, float, float],
    slide_w_emu: int = SLIDE_W_EMU,
    slide_h_emu: int = SLIDE_H_EMU,
) -> tuple[int, int, int, int]:
    """Place the image so that `norm_region` fills the slide rectangle.

    Returns `(x, y, w, h)` in slide-EMU coords for the entire image. The
    image's `(norm_region.x, norm_region.y)` corner maps to a point on
    or inside the slide; the corresponding sub-rectangle covers the
    slide. Uses **cover** semantics — when the sub-region's aspect ratio
    differs from the slide's, the longer dimension overshoots and is
    centred so the slide is fully filled with no letterboxing.

    Math:

        # Source pixels per slide-EMU after scaling such that norm_region fills slide:
        scale = max(slide_w / (rw * image_w_px), slide_h / (rh * image_h_px))
        full_w_emu = scale * image_w_px       # in slide-EMU units
        full_h_emu = scale * image_h_px

        # Position so region centre lands on slide centre:
        img_x = slide_w/2 - (rx + rw/2) * full_w_emu
        img_y = slide_h/2 - (ry + rh/2) * full_h_emu

    The `cinematic_zoom` use case typically picks norm_region to match
    slide aspect — both axes scale by the same factor and the math is
    exact. When aspect ratios differ, cover wins on the dimension that
    needs the larger scale.
    """
    validate_norm_region(norm_region)

    rx, ry, rw, rh = norm_region

    # Scale factor needed on each axis so norm_region.dim fills slide.dim.
    scale_x = slide_w_emu / (rw * image_w_px)
    scale_y = slide_h_emu / (rh * image_h_px)
    # Cover semantics: pick the larger scale so the slide is fully covered.
    pixels_per_emu_inv = max(scale_x, scale_y)

    # Full image size in slide-EMU after the chosen scale.
    full_w_emu = pixels_per_emu_inv * image_w_px
    full_h_emu = pixels_per_emu_inv * image_h_px

    # Centre norm_region on the slide.
    img_x = slide_w_emu / 2 - (rx + rw / 2) * full_w_emu
    img_y = slide_h_emu / 2 - (ry + rh / 2) * full_h_emu

    return (
        round(img_x),
        round(img_y),
        round(full_w_emu),
        round(full_h_emu),
    )


def warn_on_low_zoom_dpi(
    image_w_px: int,
    image_h_px: int,
    norm_region: tuple[float, float, float, float],
    slide_w_emu: int = SLIDE_W_EMU,
    slide_h_emu: int = SLIDE_H_EMU,
    *,
    helper_name: str = "cinematic_zoom",
) -> None:
    """Emit a `UserWarning` if zooming into `norm_region` projects under
    `_MIN_PROJECTED_DPI` source pixels per visible inch.

    For a 1920×1080 image with `norm_region=(0.4, 0.3, 0.2, 0.2)`, the
    projected width is 0.2 × 1920 = 384 px stretched over 13.33" =
    ~28.8 DPI — well under the 100 DPI floor; warns. Bump the source
    image to 6000+ px wide or pick a less aggressive zoom region.
    """
    _rx, _ry, rw, rh = norm_region
    visible_px_w = rw * image_w_px
    visible_in_w = slide_w_emu / EMU_PER_INCH
    dpi_w = visible_px_w / visible_in_w if visible_in_w > 0 else 0
    visible_px_h = rh * image_h_px
    visible_in_h = slide_h_emu / EMU_PER_INCH
    dpi_h = visible_px_h / visible_in_h if visible_in_h > 0 else 0
    effective_dpi = min(dpi_w, dpi_h)

    if effective_dpi < _MIN_PROJECTED_DPI:
        warnings.warn(
            f"{helper_name}: norm_region {norm_region} on a "
            f"{image_w_px}x{image_h_px} image projects ~{effective_dpi:.0f} DPI "
            f'at 13.33" slide width. PowerPoint will likely render this '
            f"pixelated; use a larger source image (>= "
            f"{int(_MIN_PROJECTED_DPI * visible_in_w / max(rw, 1e-9)):,}px wide) "
            f"or pick a less aggressive zoom region.",
            stacklevel=3,
            category=UserWarning,
        )
