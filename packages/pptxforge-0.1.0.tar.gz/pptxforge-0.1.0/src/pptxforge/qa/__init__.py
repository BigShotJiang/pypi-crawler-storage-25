"""Deck-level quality checks.

These run alongside (not inside) `Deck.save()`'s overflow validation
pass. Failures are *non-blocking* — they're surfaced as warnings (and
collected on the returned `QAReport`), where overflow is hard-blocking
because it produces a malformed deck.

`check_deck(deck)` returns a `QAReport` carrying the list of warnings.
Callers wire this into their build script after `deck.save()` returns
successfully.
"""

from pptxforge.qa.layout_variation import (
    LayoutVariationWarning,
    check_layout_variation,
)
from pptxforge.qa.report import QAIssue, QAReport, check_deck

__all__ = [
    "QAIssue",
    "QAReport",
    "check_deck",
    "LayoutVariationWarning",
    "check_layout_variation",
]
