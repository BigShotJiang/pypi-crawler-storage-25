"""QAReport - the return-value contract for deck-level QA checks.

`check_deck(deck)` runs every registered check and returns a
`QAReport` with a list of `QAIssue`s. Callers who care print them or
fail the build at their own discretion; nothing inside the library
treats these as blockers.
"""

from __future__ import annotations

from collections.abc import Sequence
from dataclasses import dataclass, field
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from pptxforge.deck import Deck


@dataclass(frozen=True, slots=True)
class QAIssue:
    """One non-blocking observation surfaced by a deck QA check.

    Attributes:
        check: Name of the check that produced this issue.
        message: Human-readable description.
        slides: Slide indices the issue refers to (zero-based).
    """

    check: str
    message: str
    slides: tuple[int, ...] = ()


@dataclass(slots=True)
class QAReport:
    """Aggregated QA-check output for one deck.

    Use `report.is_clean` for a one-shot "did anything fire?" check, and
    iterate `report.issues` to enumerate them. Callers decide whether
    issues are advisory or build-failing.
    """

    issues: list[QAIssue] = field(default_factory=list)

    @property
    def is_clean(self) -> bool:
        return not self.issues

    def add(self, issue: QAIssue) -> None:
        self.issues.append(issue)

    def extend(self, issues: Sequence[QAIssue]) -> None:
        self.issues.extend(issues)

    def __str__(self) -> str:
        if self.is_clean:
            return "QA: clean (no issues)"
        lines = [f"QA: {len(self.issues)} issue(s)"]
        for i in self.issues:
            slide_str = f" [slides {','.join(str(s + 1) for s in i.slides)}]" if i.slides else ""
            lines.append(f"  [{i.check}]{slide_str} {i.message}")
        return "\n".join(lines)


def check_deck(deck: Deck) -> QAReport:
    """Run every registered deck-level QA check and return a `QAReport`.

    Currently registered:

    - `layout_variation`: warns when 3+ consecutive content slides
      share a layout fingerprint.
    """
    from pptxforge.qa.layout_variation import check_layout_variation

    report = QAReport()
    report.extend(check_layout_variation(deck))
    return report
