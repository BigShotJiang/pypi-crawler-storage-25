"""Layout-variation check: detect three+ consecutive content slides
with identical layout fingerprints.

The designer feedback that prompted this check: "Wenn ich die vier
Folien nebeneinanderlege, sehe ich vier fast identische Layouts" -
when several content slides have the same shape, the deck reads as
visually monotonous regardless of content.

A "layout fingerprint" is the recursive sequence of layout-primitive
class names used in a slide's body. Two slides share a fingerprint
iff their layouts are structurally identical (regardless of text or
colour). Three or more consecutive content slides sharing one
fingerprint emits one `LayoutVariationWarning`.

Title slides, section dividers, closing slides, and 3D slides are
exempt - they're allowed to repeat patterns by design.
"""

from __future__ import annotations

import warnings
from collections.abc import Sequence
from typing import TYPE_CHECKING, Any

from pptxforge.qa.report import QAIssue

if TYPE_CHECKING:
    from pptxforge.deck import Deck
    from pptxforge.layouts._base import Layout


class LayoutVariationWarning(UserWarning):
    """Raised by the layout-variation check when consecutive content
    slides share an identical layout fingerprint."""


_EXEMPT_SLIDE_CLASSNAMES: frozenset[str] = frozenset(
    {
        "TitleSlide",
        "SectionSlide",
        "ClosingSlide",
        "Model3DSlide",
        "QuoteSlide",
        # Stat / Comparison / Code / Timeline slides build their own
        # layout from value objects rather than a free-form Layout, so
        # their fingerprint is constant by construction. Don't flag.
        "StatSlide",
        "ComparisonSlide",
        "CodeSlide",
        "TimelineSlide",
        "MediaSlide",
    }
)


def fingerprint(layout: Layout) -> str:
    """Recursively serialise a Layout's structure into a string token.

    Container children are walked; leaf primitives terminate the
    recursion. The fingerprint ignores text, colour, gap values, and
    weights — only the *shape* of the layout matters.

    Example fingerprints:
      Stack[Text,Text,Text]                       (a 3-row text stack)
      TwoColumn[Stack[Text,Text],Stack[Text,Text]] (two columns of stacks)
      CardGrid                                     (a CardGrid, opaque inside)
    """
    name = type(layout).__name__
    children = _children_of(layout)
    if not children:
        return name
    inner = ",".join(fingerprint(c) for c in children)
    return f"{name}[{inner}]"


def _children_of(layout: Layout) -> list[Layout]:
    """Best-effort enumeration of a Layout's child Layouts.

    Walks the well-known container fields (`children`, `left`/`right`,
    `child`, `image`/`content`). Returns `[]` for opaque primitives —
    `Text`, `Image`, `CardGrid`, `LabeledScale`, etc. — whose internal
    structure isn't part of the deck's visual rhythm.
    """
    out: list[Any] = []
    for attr in ("children",):
        if hasattr(layout, attr):
            v = getattr(layout, attr)
            if isinstance(v, (list, tuple)):
                out.extend(v)
                return out
    for attr in ("left", "right"):
        if hasattr(layout, attr):
            out.append(getattr(layout, attr))
    if out:
        return out
    if hasattr(layout, "image") and hasattr(layout, "content"):
        return [layout.image, layout.content]
    if hasattr(layout, "child"):
        return [layout.child]
    return []


def slide_fingerprint(slide: Any) -> str | None:
    """Return the fingerprint string for a slide, or None for exempt types.

    Exempt: TitleSlide / SectionSlide / ClosingSlide / Model3DSlide,
    plus the specialised content templates that build their own bodies
    from value objects. Generic ContentSlide instances fingerprint by
    walking `.layout`.
    """
    if type(slide).__name__ in _EXEMPT_SLIDE_CLASSNAMES:
        return None
    if hasattr(slide, "layout") and slide.layout is not None:
        return fingerprint(slide.layout)
    return None


def check_layout_variation(deck: Deck, *, run_length: int = 3) -> Sequence[QAIssue]:
    """Walk `deck.slides`, return one `QAIssue` per identical-fingerprint run
    of length >= `run_length`.

    Also emits a `LayoutVariationWarning` via `warnings.warn(...)` for
    each issue, so callers get the warning even if they ignore the
    returned `QAIssue` list.
    """
    if run_length < 2:
        raise ValueError(f"run_length must be >= 2, got {run_length}")

    issues: list[QAIssue] = []
    slides = list(deck.slides)
    if not slides:
        return issues

    run_start = 0
    run_print: str | None = None
    for i, s in enumerate(slides):
        fp = slide_fingerprint(s)
        if fp is None or fp != run_print:
            _emit_if_long_enough(slides, run_start, i, run_print, run_length, issues)
            run_start = i if fp is not None else i + 1
            run_print = fp
    _emit_if_long_enough(slides, run_start, len(slides), run_print, run_length, issues)
    return issues


def _emit_if_long_enough(
    slides: list[Any],
    run_start: int,
    run_end_excl: int,
    fp: str | None,
    run_length: int,
    out: list[QAIssue],
) -> None:
    if fp is None:
        return
    length = run_end_excl - run_start
    if length < run_length:
        return
    indices = tuple(range(run_start, run_end_excl))
    msg = (
        f"Slides {', '.join(str(i + 1) for i in indices)} use identical "
        f"layout fingerprint {fp!r} ({length} consecutive). "
        "Consider varying the layout for visual rhythm."
    )
    out.append(QAIssue(check="layout_variation", message=msg, slides=indices))
    warnings.warn(msg, category=LayoutVariationWarning, stacklevel=3)
