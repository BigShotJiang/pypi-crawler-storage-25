"""Offline GLB → PNG preview rendering for the raster fallback."""

from pathlib import Path


def render_glb_preview(
    glb_path: Path,
    *,
    width_px: int = 1280,
    height_px: int = 720,
) -> bytes:
    """Render `glb_path` to a PNG used as the `am3d:raster` / `mc:Fallback`
    preview. Returns the PNG bytes.
    """
    raise NotImplementedError
