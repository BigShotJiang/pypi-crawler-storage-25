"""`<p:timing>` builder for GLB-embedded animation playback.

Emits the standard PresentationML timing tree that drives the magic
`embedded1` attribute on a 3D graphicFrame — this is how PowerPoint
plays a glTF animation track baked into the GLB. Full XML spec quoted
in research/embedded-3d.md §5.1.

The outer `<p:cTn>` uses `presetID=100 presetClass="emph" presetSubtype=1`
(Microsoft's generic Fade Emphasis preset) as the vehicle; the animation
itself is the `<p:anim>` that sweeps `embedded1` from 0.0 to 1.0.
"""

from typing import Any

from lxml import etree

from pptxforge.model3d._xml import NS_P

EMBEDDED_ATTR_NAME = "embedded1"


def attach_embedded_timing(slide: Any, *, shape_id: int, duration_ms: int) -> None:
    """Append a `<p:timing>` block to the slide that plays the embedded GLB animation.

    If the slide already has a `<p:timing>` element (unusual but possible
    — morph also uses it, though via `<p:transition>`), we bail rather
    than clobber or merge. A future phase will fold multiple timings
    together properly.
    """
    sld = slide.part._element
    existing = sld.find(f"{{{NS_P}}}timing")
    if existing is not None:
        # Already have a timing tree — don't stomp it. Deck.save will still
        # emit the AlternateContent shape; the animation simply won't play
        # until the existing timing gets merged with this one.
        return
    sld.append(_build_timing(shape_id=shape_id, duration_ms=duration_ms))


def _build_timing(*, shape_id: int, duration_ms: int) -> etree._Element:
    """Build the `<p:timing>` subtree. Structure mirrors the MS sample verbatim."""
    return etree.fromstring(
        _TIMING_TEMPLATE.format(
            spid=shape_id,
            dur=duration_ms,
            attr=EMBEDDED_ATTR_NAME,
        ).encode("utf-8")
    )


# The timing tree is static modulo three hole-fills: `spid`, `dur`, and
# the `attr` name. Using a string template keeps the emission byte-stable
# against Microsoft's sample.
_TIMING_TEMPLATE = """\
<p:timing xmlns:p="http://schemas.openxmlformats.org/presentationml/2006/main">
  <p:tnLst>
    <p:par>
      <p:cTn id="1" dur="indefinite" restart="never" nodeType="tmRoot">
        <p:childTnLst>
          <p:seq concurrent="1" nextAc="seek">
            <p:cTn id="2" dur="indefinite" nodeType="mainSeq">
              <p:childTnLst>
                <p:par>
                  <p:cTn id="3" fill="hold">
                    <p:stCondLst>
                      <p:cond delay="indefinite"/>
                      <p:cond evt="begin" delay="0"><p:tn val="2"/></p:cond>
                    </p:stCondLst>
                    <p:childTnLst>
                      <p:par>
                        <p:cTn id="4" fill="hold">
                          <p:stCondLst><p:cond delay="0"/></p:stCondLst>
                          <p:childTnLst>
                            <p:par>
                              <p:cTn id="5" presetID="100" presetClass="emph"
                                     presetSubtype="1" repeatCount="indefinite"
                                     fill="hold" nodeType="withEffect">
                                <p:stCondLst><p:cond delay="0"/></p:stCondLst>
                                <p:childTnLst>
                                  <p:anim calcmode="lin" valueType="num">
                                    <p:cBhvr>
                                      <p:cTn id="6" dur="{dur}" fill="hold"/>
                                      <p:tgtEl><p:spTgt spid="{spid}"/></p:tgtEl>
                                      <p:attrNameLst>
                                        <p:attrName>{attr}</p:attrName>
                                      </p:attrNameLst>
                                    </p:cBhvr>
                                    <p:tavLst>
                                      <p:tav tm="0">
                                        <p:val><p:fltVal val="0"/></p:val>
                                      </p:tav>
                                      <p:tav tm="100000">
                                        <p:val><p:fltVal val="1"/></p:val>
                                      </p:tav>
                                    </p:tavLst>
                                  </p:anim>
                                </p:childTnLst>
                              </p:cTn>
                            </p:par>
                          </p:childTnLst>
                        </p:cTn>
                      </p:par>
                    </p:childTnLst>
                  </p:cTn>
                </p:par>
              </p:childTnLst>
            </p:cTn>
            <p:prevCondLst>
              <p:cond evt="onPrev" delay="0"><p:tgtEl><p:sldTgt/></p:tgtEl></p:cond>
            </p:prevCondLst>
            <p:nextCondLst>
              <p:cond evt="onNext" delay="0"><p:tgtEl><p:sldTgt/></p:tgtEl></p:cond>
            </p:nextCondLst>
          </p:seq>
        </p:childTnLst>
      </p:cTn>
    </p:par>
  </p:tnLst>
</p:timing>
"""
