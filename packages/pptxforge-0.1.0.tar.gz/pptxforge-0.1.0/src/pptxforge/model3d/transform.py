"""3D model transform — see research/embedded-3d.md §4.2."""

from dataclasses import dataclass

from pptxforge._types import EMU


@dataclass(frozen=True, slots=True)
class Transform3D:
    """The `am3d:trans` subtree: pre-translate → scale → Euler rotate →
    post-translate, plus `meterPerModelUnit` normalization.

    Rotations (`rot_ax`, `rot_ay`, `rot_az`) are in 60000ths of a degree
    per `ST_Angle`. Scales (`scale_*_n/d`) are rationals. Translations are
    EMU vectors.

    Example:
        >>> Transform3D(meter_per_model_unit_n=30569,
        ...             meter_per_model_unit_d=1000000)
    """

    meter_per_model_unit_n: int = 1
    meter_per_model_unit_d: int = 1
    pre_trans_dx: EMU = 0
    pre_trans_dy: EMU = 0
    pre_trans_dz: EMU = 0
    scale_sx_n: int = 1000000
    scale_sx_d: int = 1000000
    scale_sy_n: int = 1000000
    scale_sy_d: int = 1000000
    scale_sz_n: int = 1000000
    scale_sz_d: int = 1000000
    rot_ax: int = 0
    rot_ay: int = 0
    rot_az: int = 0
    post_trans_dx: EMU = 0
    post_trans_dy: EMU = 0
    post_trans_dz: EMU = 0
