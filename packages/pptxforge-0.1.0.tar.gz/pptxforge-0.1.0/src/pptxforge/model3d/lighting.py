"""3D lighting rig with a default ambient + 3-point configuration."""

from dataclasses import dataclass

from typing_extensions import Self


@dataclass(frozen=True, slots=True)
class LightRig:
    """A lighting configuration for an `am3d:model3d`: one ambient light
    plus a list of point / spot / directional lights.

    The default rig mirrors Microsoft's AnimatedModel3DExample: 50% gray
    ambient + 3 point lights (warm key, cool rim, cool fill) positioned
    relative to the object viewport.

    Example:
        >>> LightRig.default()
    """

    ambient_r: int = 50000
    ambient_g: int = 50000
    ambient_b: int = 50000
    ambient_illuminance_n: int = 500000
    ambient_illuminance_d: int = 1000000

    @classmethod
    def default(cls) -> Self:
        """The Microsoft AnimatedModel3DExample rig."""
        raise NotImplementedError
