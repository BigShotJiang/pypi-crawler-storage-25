"""3D animation preset lookup.

PowerPoint's built-in 3D animations (Turntable / Swing / Jump & Turn /
Arrive / Leave) are emitted as standard PresentationML `p:anim*` elements
with specific `presetID / presetClass / presetSubtype` triples. The triples
are UNVERIFIED as of 2026-04-20 (see research/embedded-3d.md §5.2 and §11
Open questions) — the table below is a placeholder until empirical capture
through PowerPoint desktop.
"""

from typing import Literal, TypedDict


class PresetTriple(TypedDict):
    preset_id: int
    preset_class: str
    preset_subtype: int


PresetName = Literal["turntable", "swing", "jumpturn", "arrive", "leave"]


def resolve_preset(name: PresetName) -> PresetTriple:
    """Look up the preset-ID triple for a named 3D animation preset.

    Raises `NotImplementedError` until the triples have been captured
    empirically from a PowerPoint-authored reference deck.
    """
    raise NotImplementedError
