"""3D-model injection API.

See `research/embedded-3d.md` for the OOXML recipe and known pitfalls,
and `evidence/fov-derivation.md` for PowerPoint's framing math.
"""

from pptxforge.model3d.bounds import (
    ModelBounds,
    read_model_bounds,
    read_model_bounds_from_bytes,
)
from pptxforge.model3d.camera import (
    EMU_PER_METER,
    Am3dCameraValues,
    Camera,
    autofit_distance_emu,
    resolve_camera,
)
from pptxforge.model3d.validators import (
    DEFAULT_MAX_SIZE_BYTES,
    InvalidModelError,
    validate_glb,
    validate_glb_bytes,
)
from pptxforge.model3d.writer import PPTXFORGE_UUID_NAMESPACE, insert_model

__all__ = [
    "Camera",
    "Am3dCameraValues",
    "resolve_camera",
    "autofit_distance_emu",
    "EMU_PER_METER",
    "ModelBounds",
    "read_model_bounds",
    "read_model_bounds_from_bytes",
    "insert_model",
    "InvalidModelError",
    "validate_glb",
    "validate_glb_bytes",
    "DEFAULT_MAX_SIZE_BYTES",
    "PPTXFORGE_UUID_NAMESPACE",
]
