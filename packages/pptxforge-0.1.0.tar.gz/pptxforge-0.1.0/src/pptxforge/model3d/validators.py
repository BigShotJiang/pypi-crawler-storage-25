"""GLB 2.0 header + chunk validation.

Per `research/embedded-3d.md` §9:
- PowerPoint only accepts self-contained `.glb` 2.0 files.
- Multi-file `.gltf` + external `.bin` buffers are rejected.
- Draco compression is untested; rejected pending empirical confirmation.

Every invalid input must fail at build time with `InvalidModelError`,
never silently propagate to a broken `.pptx`.
"""

from pathlib import Path

# GLB 2.0 magic constants (glTF spec §4.4.1).
_GLB_MAGIC = 0x46546C67  # b"glTF" as little-endian uint32
_GLB_VERSION = 2
_CHUNK_TYPE_JSON = 0x4E4F534A  # b"JSON" as LE uint32
_CHUNK_TYPE_BIN = 0x004E4942  # b"BIN\0" as LE uint32
_HEADER_SIZE = 12
_CHUNK_HEADER_SIZE = 8

# Conservative cap — PowerPoint tolerates larger, but >50 MB decks become
# painful to ship. The cap is a soft default; callers may raise it via
# `max_size_bytes`. Overriding past ~200 MB is almost always a mistake.
DEFAULT_MAX_SIZE_BYTES = 50 * 1024 * 1024


class InvalidModelError(ValueError):
    """Raised when a GLB file fails pre-insertion validation.

    Attributes:
        path: The offending file path.
        reason: Machine-readable short key (e.g. `"wrong-extension"`,
            `"bad-magic"`, `"wrong-version"`, `"too-large"`).
        detail: Human-readable explanation with remediation.

    Example:
        >>> try:
        ...     validate_glb(Path("scene.gltf"))
        ... except InvalidModelError as exc:
        ...     print(exc.reason)
        wrong-extension
    """

    def __init__(self, *, path: Path, reason: str, detail: str) -> None:
        self.path = path
        self.reason = reason
        self.detail = detail
        super().__init__(f"Invalid model {path.name} ({reason}): {detail}")


def validate_glb_bytes(
    data: bytes,
    *,
    path: Path | None = None,
    max_size_bytes: int = DEFAULT_MAX_SIZE_BYTES,
) -> None:
    """Validate GLB 2.0 binary bytes. Raise `InvalidModelError` on failure.

    Checks:
    - Total size <= `max_size_bytes`.
    - File length >= 12-byte header.
    - Magic = 0x46546C67 ("glTF").
    - Version == 2.
    - Declared length matches byte length.
    - First chunk is JSON (type 0x4E4F534A).
    """
    p = path or Path("<bytes>")

    total = len(data)
    if total > max_size_bytes:
        raise InvalidModelError(
            path=p,
            reason="too-large",
            detail=(
                f"GLB is {total} bytes ({total / 1024 / 1024:.1f} MB); cap is "
                f"{max_size_bytes} bytes ({max_size_bytes / 1024 / 1024:.1f} MB). "
                "Large models slow presentations and bloat deck transport. "
                "Pass `max_size_bytes=...` to raise the cap if you really need to."
            ),
        )
    if total < _HEADER_SIZE:
        raise InvalidModelError(
            path=p,
            reason="truncated",
            detail=f"GLB is only {total} bytes; header alone is {_HEADER_SIZE}.",
        )

    magic = int.from_bytes(data[0:4], "little")
    if magic != _GLB_MAGIC:
        raise InvalidModelError(
            path=p,
            reason="bad-magic",
            detail=(
                f"Header magic is 0x{magic:08X}; expected 0x{_GLB_MAGIC:08X} "
                f"(b'glTF'). This file is not a GLB container."
            ),
        )

    version = int.from_bytes(data[4:8], "little")
    if version != _GLB_VERSION:
        raise InvalidModelError(
            path=p,
            reason="wrong-version",
            detail=(
                f"GLB version is {version}; pptxforge only supports version 2. "
                "Re-export from your 3D tool with the glTF 2.0 binary preset."
            ),
        )

    declared_length = int.from_bytes(data[8:12], "little")
    if declared_length != total:
        raise InvalidModelError(
            path=p,
            reason="length-mismatch",
            detail=(
                f"Header declares length {declared_length}; file is {total} bytes. "
                "GLB is truncated or has been appended to."
            ),
        )

    if total < _HEADER_SIZE + _CHUNK_HEADER_SIZE:
        raise InvalidModelError(
            path=p,
            reason="truncated",
            detail="File ends before the first chunk header.",
        )

    chunk_len = int.from_bytes(data[12:16], "little")
    chunk_type = int.from_bytes(data[16:20], "little")
    if chunk_type != _CHUNK_TYPE_JSON:
        raise InvalidModelError(
            path=p,
            reason="bad-chunk-order",
            detail=(
                f"First chunk type is 0x{chunk_type:08X}; expected JSON "
                f"(0x{_CHUNK_TYPE_JSON:08X}). The glTF 2.0 spec requires the "
                "JSON chunk first."
            ),
        )
    if _HEADER_SIZE + _CHUNK_HEADER_SIZE + chunk_len > total:
        raise InvalidModelError(
            path=p,
            reason="truncated",
            detail=(
                f"JSON chunk declares {chunk_len} bytes but file has only "
                f"{total - _HEADER_SIZE - _CHUNK_HEADER_SIZE} remaining."
            ),
        )


def validate_glb(
    path: Path | str,
    *,
    max_size_bytes: int = DEFAULT_MAX_SIZE_BYTES,
) -> None:
    """Validate a GLB file at `path`. Raises `InvalidModelError` on failure.

    Includes a fast-path extension check so `.gltf` (multi-file glTF)
    rejects without opening the file.
    """
    p = Path(path)
    # Extension check runs before existence so `.gltf` users get the
    # more-useful "wrong extension" error rather than "file not found"
    # when they point at a non-existent .gltf.
    suffix = p.suffix.lower()
    if suffix != ".glb":
        if suffix == ".gltf":
            raise InvalidModelError(
                path=p,
                reason="wrong-extension",
                detail=(
                    "File is `.gltf` (JSON + external buffers); PowerPoint's "
                    "3D importer only accepts self-contained `.glb`. Re-export "
                    "with the glTF 2.0 binary preset."
                ),
            )
        raise InvalidModelError(
            path=p,
            reason="wrong-extension",
            detail=f"Expected `.glb`, got `{suffix}`.",
        )

    if not p.is_file():
        raise InvalidModelError(
            path=p,
            reason="not-found",
            detail="File does not exist or is not a regular file.",
        )

    data = p.read_bytes()
    validate_glb_bytes(data, path=p, max_size_bytes=max_size_bytes)
