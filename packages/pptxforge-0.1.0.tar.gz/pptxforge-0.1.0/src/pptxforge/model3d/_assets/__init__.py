"""Bundled binary resources for the 3D writer.

`placeholder_3d.png` is the default raster fallback used when the caller
does not supply a `preview_png`. It is shipped as a static resource (not
generated at runtime) so that decks render with a recognisable "3D model"
icon in non-PowerPoint viewers (LibreOffice, Google Slides, Keynote, PDF
export) and so the wheel has no PIL hard-dependency for the no-preview
path. See DECISIONS.md.
"""
