"""3D camera --- spherical input, am3d `pos`/`up`/`lookAt` output.

End-users work in spherical coordinates (azimuth, elevation, distance)
because that's the intuitive mental model: "swing 45 degrees around the
model and look down 20 degrees". The writer converts to the world-space
``pos`` + ``up`` + ``lookAt`` + projection triple that ``am3d:camera``
demands (per research/embedded-3d.md section 4.1).

## How auto-fit works

Pipeline matches PowerPoint Desktop's Insert > 3D Models default,
back-solved in ``evidence/fov-derivation.md``:

1. The writer computes a per-model ``meterPerModelUnit`` and ``preTrans``
   so the model is normalized to a fixed size in scene EMU and centered
   on the scene origin.
2. ``lookAt`` is therefore always ``(0, 0, 0)``.
3. The camera distance is ``r / sin(fov/2)`` --- the *tight-fit*
   distance where the model's bounding sphere exactly inscribes the
   FOV cone. PowerPoint applies no padding, so neither do we.

``Camera.distance`` (a multiplier of the tight-fit base):

* ``None`` (default): tight-fit. The model fills the FOV cone exactly
  --- same framing PowerPoint Desktop produces on auto-insert.
* ``1.0``: same as ``None`` --- exposed so callers can be explicit.
* ``2.0``: twice as far. Model linear silhouette ~50%.
* ``0.5``: half as far. Model overflows.

## Handedness

Research section 4.5 left the am3d coordinate handedness ambiguous.
Empirically the PowerPoint reference renders correctly with
``up = (0, +Y, 0)`` and the camera pulled out along +Z --- so this module
feeds those conventions. Users who round-trip a 45-degree azimuth through
PowerPoint should reality-check and report back.
"""

from __future__ import annotations

import math
from dataclasses import dataclass

# Sample-derived defaults. The up vector magnitude matches Microsoft's
# AnimatedModel3DExample (and the helmet reference --- it's a stable value
# across PowerPoint-authored 3D shapes). 1m = 36e6 EMU.
_DEFAULT_UP_MAGNITUDE_EMU = 36_000_000
_DEFAULT_FOV_DEG = (
    45.0  # Empirical: PowerPoint's Insert > 3D default. See evidence/fov-derivation.md.
)

_MAX_ABS_ELEVATION_DEG = 89.0

# 1 metre in scene EMU --- exposed for callers that want to convert raw
# bounding-sphere radii (in scene metres) to scene EMU themselves.
EMU_PER_METER = 36_000_000

# Distance the camera falls back to when the GLB has no measurable bounds
# (e.g. proteins-in-motion's 48-byte placeholder GLBs). Picked to match
# the original AnimatedModel3DExample sample so empty-GLB decks render
# with a position similar to what they rendered with before. Not a target
# for tuning --- the right fix for empty GLBs is to ship real geometry.
_FALLBACK_DISTANCE_EMU = 67_733_325  # 12.5 * 5_418_666, sample's sceneCubeSide


@dataclass(frozen=True, slots=True)
class Camera:
    """A spherical-coordinate camera description.

    Attributes:
        azimuth: Horizontal rotation around the Y axis, in degrees. Zero
            places the camera on +Z (facing the origin along -Z). Positive
            values rotate CCW looking down from +Y.
        elevation: Vertical angle above the horizon, in degrees. Zero is
            level with the target; positive pitches the camera up. Clamped
            to +/-89 degrees to avoid the gimbal-lock case where ``up``
            becomes parallel to the look direction.
        distance: Multiplier of the tight-fit auto-fit distance. ``None``
            (the default) is exactly tight-fit (same framing PowerPoint
            Desktop produces on Insert > 3D Models). ``1.0`` is identical
            to ``None`` --- exposed so callers can be explicit. ``2.0``
            puts the camera twice as far back; the model linear silhouette
            shrinks to ~50%. ``0.5`` puts the camera close enough that
            the model overflows the viewport.
        target: Look-at point in EMU. ``None`` (the default) uses scene
            origin --- which is the model's centre in scene space, since
            the writer sets ``preTrans`` to centre it there. Pass an
            explicit ``(x, y, z)`` to override (e.g. to look at a
            specific feature of the model rather than its centroid;
            note that ``preTrans`` still centres the model, so the
            override is in centred-model coords).
        fov_deg: Perspective field-of-view in degrees. Default 45 degrees
            (PowerPoint's empirical default; do not change without a
            re-derivation against a fresh reference file).

    Example:
        >>> Camera()                                  # tight-fit, default 3/4 view
        >>> Camera(azimuth=45, elevation=30)          # tight-fit at this angle
        >>> Camera(azimuth=45, elevation=30, distance=1.5)  # 1.5x out
    """

    azimuth: float = 20.0
    elevation: float = 15.0
    distance: float | None = None
    target: tuple[int, int, int] | None = None
    fov_deg: float = _DEFAULT_FOV_DEG

    def __post_init__(self) -> None:
        if not -_MAX_ABS_ELEVATION_DEG <= self.elevation <= _MAX_ABS_ELEVATION_DEG:
            raise ValueError(
                f"Camera.elevation must lie in "
                f"[-{_MAX_ABS_ELEVATION_DEG}, {_MAX_ABS_ELEVATION_DEG}] degrees "
                f"(gimbal lock at +/-90 degrees); got {self.elevation}"
            )
        if self.distance is not None and self.distance <= 0:
            raise ValueError(
                f"Camera.distance must be positive when given (or None for "
                f"auto-fit); got {self.distance}"
            )
        if not 0 < self.fov_deg < 180:
            raise ValueError(f"Camera.fov_deg must lie in (0, 180) exclusive, got {self.fov_deg}")


@dataclass(frozen=True, slots=True)
class Am3dCameraValues:
    """The am3d:camera child values in EMU / 60000ths-of-a-degree.

    Ready to feed into the XML builder as-is.
    """

    pos: tuple[int, int, int]
    up: tuple[int, int, int]
    look_at: tuple[int, int, int]
    fov_60000ths: int


def autofit_distance_emu(model_radius_emu: int, fov_deg: float) -> int:
    """Distance at which a sphere of ``model_radius_emu`` exactly inscribes
    the FOV cone.

    Tight-fit, no padding. Matches the formula PowerPoint Desktop applies
    when it auto-inserts a 3D model (verified against
    ``evidence/helmet-reference.pptx`` in ``evidence/fov-derivation.md`` to
    sub-EMU precision).
    """
    half_fov_rad = math.radians(fov_deg / 2.0)
    return round(model_radius_emu / math.sin(half_fov_rad))


def resolve_camera(
    camera: Camera,
    *,
    model_radius_emu: int = 0,
) -> Am3dCameraValues:
    """Turn a spherical ``Camera`` into the ``pos``/``up``/``lookAt``/``fov``
    triple, sized to the model's scene-EMU bounding sphere.

    ``model_radius_emu`` is the bounding-sphere half-diagonal of the
    *centred*, post-``meterPerModelUnit``-and-EMU-scaled model. The writer
    is responsible for computing it from the GLB (via
    :mod:`pptxforge.model3d.bounds` and the per-model
    ``meterPerModelUnit``) and passing it through.

    When ``model_radius_emu <= 0`` (no measurable geometry), the camera
    falls back to a fixed legacy distance --- ``Camera.distance`` is then
    interpreted as a multiplier of that fallback. This keeps placeholder
    GLB decks (proteins-in-motion etc.) producing a valid camera position
    rather than a divide-by-zero.

    ``Camera.target`` defaults to scene origin (``(0, 0, 0)``); under the
    new pipeline the writer's ``preTrans`` centres the model on scene
    origin, so this is also the model's centre. An explicit non-None
    target overrides without asking questions --- callers know what they
    want to look at.
    """
    az_rad = math.radians(camera.azimuth)
    el_rad = math.radians(camera.elevation)

    if model_radius_emu > 0:
        tight_fit_emu = autofit_distance_emu(model_radius_emu, camera.fov_deg)
    else:
        tight_fit_emu = _FALLBACK_DISTANCE_EMU

    multiplier = 1.0 if camera.distance is None else camera.distance
    r_emu = tight_fit_emu * multiplier

    target = camera.target if camera.target is not None else (0, 0, 0)
    tx, ty, tz = target

    pos_x = round(tx + r_emu * math.cos(el_rad) * math.sin(az_rad))
    pos_y = round(ty + r_emu * math.sin(el_rad))
    pos_z = round(tz + r_emu * math.cos(el_rad) * math.cos(az_rad))

    return Am3dCameraValues(
        pos=(pos_x, pos_y, pos_z),
        up=(0, _DEFAULT_UP_MAGNITUDE_EMU, 0),
        look_at=(round(tx), round(ty), round(tz)),
        fov_60000ths=round(camera.fov_deg * 60000),
    )
