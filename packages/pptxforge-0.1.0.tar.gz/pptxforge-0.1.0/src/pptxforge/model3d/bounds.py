"""Compute the world-space bounding box of a GLB.

The world-space bbox is the bbox of the GLB's POSITION extents *after*
the scene-graph node transforms are applied. PowerPoint's framing math
(see ``evidence/fov-derivation.md``) keys off this bbox: the longest
half-extent determines ``meterPerModelUnit``, and the bbox center
determines ``preTrans``. Skipping node transforms makes the framing wrong
for any model whose authoring scale is normalized at the scene-graph
layer rather than baked into POSITION coords --- Khronos ``Duck.glb``
(root node has a 0.01 scale) is the canonical example.

The glTF 2.0 spec requires every POSITION accessor to declare ``min`` and
``max``, so the bbox is fully derivable from the JSON chunk --- no need
to parse the BIN chunk or decode vertex data.

Implementation choices:

* Multi-mesh GLBs: bbox is the union of every (mesh-instance, accumulated-
  transform) bbox in the scene graph.
* Multiple scenes: only ``scenes[scene]`` (the default scene) is walked.
  GLBs that depend on alternate scene roots aren't a real-world concern
  for PowerPoint embedding (PowerPoint reads the default scene).
* Sparse accessors / morph targets: ignored. POSITION min/max already
  reflects the base mesh; deformations don't widen the bbox enough to
  matter for camera framing.
"""

from __future__ import annotations

import json
import math
import struct
from dataclasses import dataclass
from pathlib import Path
from typing import Any

# GLB constants (subset of validators._GLB_*; duplicated here so this module
# stays standalone and doesn't pull validators into its import graph).
_GLB_MAGIC = 0x46546C67
_CHUNK_TYPE_JSON = 0x4E4F534A

# Returned for GLBs with no measurable POSITION extents (proteins-in-motion's
# 48-byte placeholder GLBs, hand-synthesized test fixtures, etc.). The writer
# falls back to its sample-derived constants when has_geometry=False.
_FALLBACK_HALF_EXTENTS = (1.0, 1.0, 1.0)


@dataclass(frozen=True, slots=True)
class ModelBounds:
    """World-space bbox of a GLB after scene-graph node transforms.

    Attributes:
        center: Bbox center, glTF model units, in world space (i.e. after
            node transforms have been applied).
        half_extents: Per-axis half-extents in world-space glTF units. The
            value PowerPoint uses for ``meterPerModelUnit`` is
            ``1 / (2 * max(half_extents))``.
        has_geometry: ``False`` when the GLB had no measurable POSITION
            data and ``center``/``half_extents`` are placeholder fallback
            values. The writer uses this to swap in its sample-derived
            transform constants for empty-GLB cases.

    The (legacy) bounding-sphere radius is the bbox half-diagonal:
    ``sqrt(sum(h*h for h in half_extents))``. Exposed via the ``radius``
    property for callers that already use it.
    """

    center: tuple[float, float, float]
    half_extents: tuple[float, float, float]
    has_geometry: bool

    @property
    def radius(self) -> float:
        """Bounding-sphere radius (bbox half-diagonal), glTF units."""
        return math.sqrt(sum(h * h for h in self.half_extents))


def read_model_bounds(glb_path: Path | str) -> ModelBounds:
    """Read the world-space POSITION bbox of the GLB at ``glb_path``."""
    return read_model_bounds_from_bytes(Path(glb_path).read_bytes())


def read_model_bounds_from_bytes(data: bytes) -> ModelBounds:
    """Walk the GLB's scene graph and aggregate transformed POSITION extents.

    Returns the fallback bounds (origin-centered unit half-extents,
    ``has_geometry = False``) for any GLB that:

    * has no JSON chunk we can locate
    * has malformed JSON
    * has no scene / mesh / POSITION accessor structure we recognise
    * has POSITION accessors but no ``min``/``max`` (some exporters skip
      the spec-required min/max; we cannot recover bounds without them
      without reading the BIN chunk, which is out of scope)
    """
    json_text = _extract_json_chunk(data)
    if json_text is None:
        return _fallback_bounds()
    try:
        root = json.loads(json_text)
    except json.JSONDecodeError:
        return _fallback_bounds()
    if not isinstance(root, dict):
        return _fallback_bounds()

    accessors = root.get("accessors") or []
    meshes = root.get("meshes") or []
    nodes = root.get("nodes") or []
    scenes = root.get("scenes") or []
    if (
        not isinstance(accessors, list)
        or not isinstance(meshes, list)
        or not isinstance(nodes, list)
    ):
        return _fallback_bounds()

    scene_idx = root.get("scene")
    if not isinstance(scene_idx, int) or not (0 <= scene_idx < len(scenes)):
        scene_idx = 0
    if not scenes and not nodes:
        # GLB declares meshes directly without any scene-graph wrapping
        # (test fixtures, hand-rolled GLBs). Synthesize a flat node-per-
        # mesh chain with identity transforms so the bbox aggregator sees
        # them.
        nodes = [{"mesh": i} for i in range(len(meshes))]
        root_nodes = list(range(len(meshes)))
    elif not scenes:
        # Some GLBs declare nodes without scenes. Walk every node as if it
        # were a root; child relationships still get resolved.
        root_nodes = list(range(len(nodes)))
    else:
        scene = scenes[scene_idx]
        scene_nodes = scene.get("nodes") if isinstance(scene, dict) else None
        if not isinstance(scene_nodes, list):
            return _fallback_bounds()
        root_nodes = scene_nodes

    overall_min: list[float] | None = None
    overall_max: list[float] | None = None

    identity = _identity_matrix()
    for n_idx in root_nodes:
        if not isinstance(n_idx, int):
            continue
        for m in _walk_node_meshes(nodes, n_idx, identity):
            mesh_idx, accum_matrix = m
            if not (0 <= mesh_idx < len(meshes)):
                continue
            mesh = meshes[mesh_idx]
            if not isinstance(mesh, dict):
                continue
            primitives = mesh.get("primitives")
            if not isinstance(primitives, list):
                continue
            for prim in primitives:
                if not isinstance(prim, dict):
                    continue
                attrs = prim.get("attributes")
                if not isinstance(attrs, dict):
                    continue
                pos_idx = attrs.get("POSITION")
                if not isinstance(pos_idx, int) or not (0 <= pos_idx < len(accessors)):
                    continue
                acc = accessors[pos_idx]
                amin = _vec3(acc.get("min"))
                amax = _vec3(acc.get("max"))
                if amin is None or amax is None:
                    continue
                t_min, t_max = _transform_bbox(amin, amax, accum_matrix)
                if overall_min is None:
                    overall_min = list(t_min)
                    overall_max = list(t_max)
                else:
                    assert overall_max is not None
                    for i in range(3):
                        overall_min[i] = min(overall_min[i], t_min[i])
                        overall_max[i] = max(overall_max[i], t_max[i])

    if overall_min is None or overall_max is None:
        return _fallback_bounds()

    center = (
        (overall_min[0] + overall_max[0]) / 2.0,
        (overall_min[1] + overall_max[1]) / 2.0,
        (overall_min[2] + overall_max[2]) / 2.0,
    )
    half_extents = (
        (overall_max[0] - overall_min[0]) / 2.0,
        (overall_max[1] - overall_min[1]) / 2.0,
        (overall_max[2] - overall_min[2]) / 2.0,
    )
    if max(half_extents) <= 0.0:
        # Degenerate (single-point or NaN) extents; fall back rather than
        # divide-by-zero downstream.
        return _fallback_bounds()
    return ModelBounds(center=center, half_extents=half_extents, has_geometry=True)


def _fallback_bounds() -> ModelBounds:
    return ModelBounds(
        center=(0.0, 0.0, 0.0),
        half_extents=_FALLBACK_HALF_EXTENTS,
        has_geometry=False,
    )


# ---------------------------------------------------------------------------
# Scene-graph traversal: yield (mesh_index, accumulated 4x4 transform)
# ---------------------------------------------------------------------------


def _walk_node_meshes(
    nodes: list[Any],
    n_idx: int,
    parent_matrix: list[list[float]],
) -> list[tuple[int, list[list[float]]]]:
    """DFS the scene graph from ``n_idx`` and yield every mesh instance.

    Returns a list (not a generator) because the call sites are short and
    a list keeps the static type cleaner.
    """
    out: list[tuple[int, list[list[float]]]] = []
    stack: list[tuple[int, list[list[float]]]] = [(n_idx, parent_matrix)]
    visited: set[int] = set()
    while stack:
        idx, accum = stack.pop()
        if idx in visited:
            # Defensive: cyclic glTF is technically malformed but we won't
            # spin if we hit one.
            continue
        visited.add(idx)
        if not (0 <= idx < len(nodes)):
            continue
        node = nodes[idx]
        if not isinstance(node, dict):
            continue
        local = _node_matrix(node)
        composed = _matmul(accum, local)
        mesh_idx = node.get("mesh")
        if isinstance(mesh_idx, int):
            out.append((mesh_idx, composed))
        children = node.get("children")
        if isinstance(children, list):
            for c in children:
                if isinstance(c, int):
                    stack.append((c, composed))
    return out


def _node_matrix(node: dict[str, Any]) -> list[list[float]]:
    """Return a 4x4 row-major matrix for ``node``.

    Per glTF 2.0 spec: a node has either an explicit ``matrix`` (16 floats
    in column-major order) OR independent ``translation``/``rotation``/
    ``scale`` (TRS) components --- never both. If neither is present, the
    transform is identity.
    """
    explicit = node.get("matrix")
    if isinstance(explicit, list) and len(explicit) == 16:
        # Spec: column-major. Convert to row-major (rows of (m00, m01, m02, m03), ...)
        m = [float(v) for v in explicit]
        return [
            [m[0], m[4], m[8], m[12]],
            [m[1], m[5], m[9], m[13]],
            [m[2], m[6], m[10], m[14]],
            [m[3], m[7], m[11], m[15]],
        ]

    translation = _vec3(node.get("translation")) or (0.0, 0.0, 0.0)
    rotation = _vec4(node.get("rotation")) or (0.0, 0.0, 0.0, 1.0)
    scale = _vec3(node.get("scale")) or (1.0, 1.0, 1.0)
    return _trs_matrix(translation, rotation, scale)


def _trs_matrix(
    t: tuple[float, float, float],
    r: tuple[float, float, float, float],
    s: tuple[float, float, float],
) -> list[list[float]]:
    """Compose T * R * S into a row-major 4x4."""
    qx, qy, qz, qw = r
    sx, sy, sz = s
    tx, ty, tz = t

    # Rotation matrix from quaternion (qx, qy, qz, qw); right-handed.
    xx = qx * qx
    yy = qy * qy
    zz = qz * qz
    xy = qx * qy
    xz = qx * qz
    yz = qy * qz
    wx = qw * qx
    wy = qw * qy
    wz = qw * qz

    r00 = 1 - 2 * (yy + zz)
    r01 = 2 * (xy - wz)
    r02 = 2 * (xz + wy)
    r10 = 2 * (xy + wz)
    r11 = 1 - 2 * (xx + zz)
    r12 = 2 * (yz - wx)
    r20 = 2 * (xz - wy)
    r21 = 2 * (yz + wx)
    r22 = 1 - 2 * (xx + yy)

    # T * R * S: scale first (multiply rotation columns), then add translation.
    return [
        [r00 * sx, r01 * sy, r02 * sz, tx],
        [r10 * sx, r11 * sy, r12 * sz, ty],
        [r20 * sx, r21 * sy, r22 * sz, tz],
        [0.0, 0.0, 0.0, 1.0],
    ]


def _identity_matrix() -> list[list[float]]:
    return [
        [1.0, 0.0, 0.0, 0.0],
        [0.0, 1.0, 0.0, 0.0],
        [0.0, 0.0, 1.0, 0.0],
        [0.0, 0.0, 0.0, 1.0],
    ]


def _matmul(a: list[list[float]], b: list[list[float]]) -> list[list[float]]:
    """4x4 row-major matrix multiplication."""
    out = [[0.0] * 4 for _ in range(4)]
    for i in range(4):
        for j in range(4):
            out[i][j] = sum(a[i][k] * b[k][j] for k in range(4))
    return out


def _transform_bbox(
    bmin: tuple[float, float, float],
    bmax: tuple[float, float, float],
    matrix: list[list[float]],
) -> tuple[tuple[float, float, float], tuple[float, float, float]]:
    """Transform an axis-aligned bbox by a 4x4 matrix.

    Computes the axis-aligned bbox of all 8 transformed corners. The
    result is conservative: a rotated bbox grows when re-projected to
    AABB. For framing this is fine --- the auto-fit math wants an upper
    bound on the model's spatial extent.
    """
    corners = [
        (bmin[0], bmin[1], bmin[2]),
        (bmin[0], bmin[1], bmax[2]),
        (bmin[0], bmax[1], bmin[2]),
        (bmin[0], bmax[1], bmax[2]),
        (bmax[0], bmin[1], bmin[2]),
        (bmax[0], bmin[1], bmax[2]),
        (bmax[0], bmax[1], bmin[2]),
        (bmax[0], bmax[1], bmax[2]),
    ]
    transformed = [_apply_matrix(matrix, c) for c in corners]
    out_min = (
        min(p[0] for p in transformed),
        min(p[1] for p in transformed),
        min(p[2] for p in transformed),
    )
    out_max = (
        max(p[0] for p in transformed),
        max(p[1] for p in transformed),
        max(p[2] for p in transformed),
    )
    return out_min, out_max


def _apply_matrix(
    m: list[list[float]],
    p: tuple[float, float, float],
) -> tuple[float, float, float]:
    """Apply a 4x4 row-major matrix to a homogenous point (assumes w=1)."""
    x, y, z = p
    return (
        m[0][0] * x + m[0][1] * y + m[0][2] * z + m[0][3],
        m[1][0] * x + m[1][1] * y + m[1][2] * z + m[1][3],
        m[2][0] * x + m[2][1] * y + m[2][2] * z + m[2][3],
    )


# ---------------------------------------------------------------------------
# Tiny GLB parser helpers
# ---------------------------------------------------------------------------


def _extract_json_chunk(data: bytes) -> str | None:
    if len(data) < 20:
        return None
    magic = struct.unpack_from("<I", data, 0)[0]
    if magic != _GLB_MAGIC:
        return None
    chunk_len, chunk_type = struct.unpack_from("<II", data, 12)
    if chunk_type != _CHUNK_TYPE_JSON:
        return None
    end = 20 + chunk_len
    if end > len(data):
        return None
    try:
        return data[20:end].decode("utf-8")
    except UnicodeDecodeError:
        return None


def _vec3(v: Any) -> tuple[float, float, float] | None:
    if not isinstance(v, list) or len(v) != 3:
        return None
    if not all(isinstance(c, (int, float)) and not isinstance(c, bool) for c in v):
        return None
    return (float(v[0]), float(v[1]), float(v[2]))


def _vec4(v: Any) -> tuple[float, float, float, float] | None:
    if not isinstance(v, list) or len(v) != 4:
        return None
    if not all(isinstance(c, (int, float)) and not isinstance(c, bool) for c in v):
        return None
    return (float(v[0]), float(v[1]), float(v[2]), float(v[3]))
