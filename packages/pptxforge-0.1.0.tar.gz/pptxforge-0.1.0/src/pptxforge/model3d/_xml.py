"""Low-level XML builders for the 3D-model subtree.

The bytes written here are lifted section by section from
`research/embedded-3d.md` §3. Every qualified name, attribute, and GUID
that flows into the slide XML is sourced from that doc (which in turn
derives from Microsoft's own AnimatedModel3DExample). Drift from those
conventions risks PowerPoint silently rewriting our XML — so these
builders stay boring by design.
"""

from typing import Any
from uuid import UUID

from lxml import etree

from pptxforge.model3d.camera import Am3dCameraValues

# ---------------------------------------------------------------------------
# Namespaces (verbatim from research/embedded-3d.md §1).
# ---------------------------------------------------------------------------

NS_A = "http://schemas.openxmlformats.org/drawingml/2006/main"
NS_R = "http://schemas.openxmlformats.org/officeDocument/2006/relationships"
NS_P = "http://schemas.openxmlformats.org/presentationml/2006/main"
NS_MC = "http://schemas.openxmlformats.org/markup-compatibility/2006"
NS_AM3D = "http://schemas.microsoft.com/office/drawing/2017/model3d"
NS_A3DANIM = "http://schemas.microsoft.com/office/drawing/2018/animation/model3d"
NS_AANIM = "http://schemas.microsoft.com/office/drawing/2018/animation"
NS_A16 = "http://schemas.microsoft.com/office/drawing/2014/main"
NS_P14 = "http://schemas.microsoft.com/office/powerpoint/2010/main"
NS_P159 = "http://schemas.microsoft.com/office/powerpoint/2015/09/main"

# Extension URI wrappers (verbatim — these are GUIDs Microsoft chose).
EXT_CREATION_ID = "{FF2B5EF4-FFF2-40B4-BE49-F238E27FC236}"
EXT_MOD_ID = "{D42A27DB-BD31-4B8C-83A1-F6EECF244321}"
EXT_EMBED_ANIM = "{9A65AA19-BECB-4387-8358-8AD5134E1D82}"
EXT_POSTER_FRAME = "{E9DE012E-A134-456F-84FE-255F9AAD75C6}"

# Relationship type for the .glb media part.
RELTYPE_MODEL3D = "http://schemas.microsoft.com/office/2017/06/relationships/model3d"
CT_MODEL3D = "model/gltf-binary"

# Microsoft's sample values — lifted so our output matches what PowerPoint
# writes byte-for-byte wherever possible.
SAMPLE_VIEWPORT_SZ_EMU = 5418666
SAMPLE_METER_PER_MODEL_UNIT_N = 30569
SAMPLE_METER_PER_MODEL_UNIT_D = 1000000
SAMPLE_PRE_TRANS = (-98394, -14223043, -1124542)


_NSMAP_CHOICE: dict[str | None, str] = {
    "am3d": NS_AM3D,
    "a": NS_A,
    "r": NS_R,
    "p": NS_P,
    "a3danim": NS_A3DANIM,
    "aanim": NS_AANIM,
    "a16": NS_A16,
    "p14": NS_P14,
}


def _qn(prefix_uri: str, local: str) -> str:
    """Clark-style qualified name: `{uri}local`."""
    return f"{{{prefix_uri}}}{local}"


# ---------------------------------------------------------------------------
# creationId helper
# ---------------------------------------------------------------------------


def braced_guid(uuid_value: UUID) -> str:
    """Format a UUID as `{XXXXXXXX-XXXX-XXXX-XXXX-XXXXXXXXXXXX}` (upper case).

    a:ST_Guid requires the braces and rejects lowercase hex in strict
    schemas — matches what PowerPoint itself writes.
    """
    return "{" + str(uuid_value).upper() + "}"


# ---------------------------------------------------------------------------
# am3d:model3d subtree
# ---------------------------------------------------------------------------


def build_alternate_content(
    *,
    shape_id: int,
    shape_name: str,
    description: str,
    creation_id: UUID,
    offset_emu: tuple[int, int],
    extent_emu: tuple[int, int],
    glb_rid: str,
    png_rid: str,
    camera: Am3dCameraValues,
    animation: dict[str, int] | None,
    meter_per_model_unit_n_d: tuple[int, int] = (
        SAMPLE_METER_PER_MODEL_UNIT_N,
        SAMPLE_METER_PER_MODEL_UNIT_D,
    ),
    pre_trans_emu: tuple[int, int, int] = SAMPLE_PRE_TRANS,
    viewport_sz_emu: int = SAMPLE_VIEWPORT_SZ_EMU,
) -> etree._Element:
    """Build the complete `<mc:AlternateContent>` subtree.

    Shape of the output matches research/embedded-3d.md §3 literally:

      <mc:AlternateContent>
        <mc:Choice Requires="am3d">
          <p:graphicFrame>...</p:graphicFrame>   ← hosts the 3D model
        </mc:Choice>
        <mc:Fallback>
          <p:pic>...</p:pic>                      ← PNG for legacy clients
        </mc:Fallback>
      </mc:AlternateContent>

    `animation`, when given, carries `{"animId": 0, "len_ms": 1899}` —
    the GLB-embedded animation reference that pairs with a `<p:timing>`
    node driving the `embedded1` attribute.
    """
    ac = etree.Element(_qn(NS_MC, "AlternateContent"), nsmap={"mc": NS_MC})

    # Declare `am3d` on the Choice element itself — the `Requires="am3d"`
    # attribute references that prefix, so the declaration must scope the
    # whole `<mc:Choice>` body.
    choice = etree.SubElement(
        ac,
        _qn(NS_MC, "Choice"),
        attrib={"Requires": "am3d"},
        nsmap={"am3d": NS_AM3D},
    )

    choice.append(
        _build_graphic_frame(
            shape_id=shape_id,
            shape_name=shape_name,
            description=description,
            creation_id=creation_id,
            offset_emu=offset_emu,
            extent_emu=extent_emu,
            glb_rid=glb_rid,
            png_rid=png_rid,
            camera=camera,
            animation=animation,
            meter_per_model_unit_n_d=meter_per_model_unit_n_d,
            pre_trans_emu=pre_trans_emu,
            viewport_sz_emu=viewport_sz_emu,
        )
    )

    fallback = etree.SubElement(ac, _qn(NS_MC, "Fallback"))
    fallback.append(
        _build_picture_fallback(
            shape_id=shape_id,
            shape_name=shape_name,
            description=description,
            offset_emu=offset_emu,
            extent_emu=extent_emu,
            png_rid=png_rid,
        )
    )

    return ac


def _build_graphic_frame(
    *,
    shape_id: int,
    shape_name: str,
    description: str,
    creation_id: UUID,
    offset_emu: tuple[int, int],
    extent_emu: tuple[int, int],
    glb_rid: str,
    png_rid: str,
    camera: Am3dCameraValues,
    animation: dict[str, int] | None,
    meter_per_model_unit_n_d: tuple[int, int] = (
        SAMPLE_METER_PER_MODEL_UNIT_N,
        SAMPLE_METER_PER_MODEL_UNIT_D,
    ),
    pre_trans_emu: tuple[int, int, int] = SAMPLE_PRE_TRANS,
    viewport_sz_emu: int = SAMPLE_VIEWPORT_SZ_EMU,
) -> etree._Element:
    """Build `<p:graphicFrame>` — the 3D object host."""
    gf = etree.Element(_qn(NS_P, "graphicFrame"), nsmap={"p": NS_P})

    # nvGraphicFramePr: identity (shape id, name, creationId, modId).
    nv = etree.SubElement(gf, _qn(NS_P, "nvGraphicFramePr"))
    cnv_pr = etree.SubElement(
        nv,
        _qn(NS_P, "cNvPr"),
        attrib={"id": str(shape_id), "name": shape_name, "descr": description},
    )
    ext_lst = etree.SubElement(cnv_pr, _qn(NS_A, "extLst"))
    a16_ext = etree.SubElement(
        ext_lst,
        _qn(NS_A, "ext"),
        attrib={"uri": EXT_CREATION_ID},
    )
    etree.SubElement(
        a16_ext,
        _qn(NS_A16, "creationId"),
        attrib={"id": braced_guid(creation_id)},
        nsmap={"a16": NS_A16},
    )

    etree.SubElement(nv, _qn(NS_P, "cNvGraphicFramePr"))

    nv_pr = etree.SubElement(nv, _qn(NS_P, "nvPr"))
    nvpr_ext_lst = etree.SubElement(nv_pr, _qn(NS_P, "extLst"))
    p14_ext = etree.SubElement(
        nvpr_ext_lst,
        _qn(NS_P, "ext"),
        attrib={"uri": EXT_MOD_ID},
    )
    etree.SubElement(
        p14_ext,
        _qn(NS_P14, "modId"),
        attrib={"val": "0"},
        nsmap={"p14": NS_P14},
    )

    # p:xfrm — position + size.
    xfrm = etree.SubElement(gf, _qn(NS_P, "xfrm"))
    etree.SubElement(
        xfrm,
        _qn(NS_A, "off"),
        attrib={"x": str(offset_emu[0]), "y": str(offset_emu[1])},
    )
    etree.SubElement(
        xfrm,
        _qn(NS_A, "ext"),
        attrib={"cx": str(extent_emu[0]), "cy": str(extent_emu[1])},
    )

    # a:graphic / a:graphicData uri="...am3d..." > am3d:model3d
    graphic = etree.SubElement(gf, _qn(NS_A, "graphic"))
    graphic_data = etree.SubElement(graphic, _qn(NS_A, "graphicData"), attrib={"uri": NS_AM3D})
    graphic_data.append(
        _build_model3d(
            creation_id_for_inner=creation_id,  # unused for now; reserved
            extent_emu=extent_emu,
            glb_rid=glb_rid,
            png_rid=png_rid,
            camera=camera,
            animation=animation,
            meter_per_model_unit_n_d=meter_per_model_unit_n_d,
            pre_trans_emu=pre_trans_emu,
            viewport_sz_emu=viewport_sz_emu,
        )
    )
    return gf


def _build_model3d(
    *,
    creation_id_for_inner: UUID,
    extent_emu: tuple[int, int],
    glb_rid: str,
    png_rid: str,
    camera: Am3dCameraValues,
    animation: dict[str, int] | None,
    meter_per_model_unit_n_d: tuple[int, int] = (
        SAMPLE_METER_PER_MODEL_UNIT_N,
        SAMPLE_METER_PER_MODEL_UNIT_D,
    ),
    pre_trans_emu: tuple[int, int, int] = SAMPLE_PRE_TRANS,
    viewport_sz_emu: int = SAMPLE_VIEWPORT_SZ_EMU,
) -> etree._Element:
    """Build `<am3d:model3d>` — the 3D body itself."""
    del creation_id_for_inner  # reserved for future 3D-side identity stamping

    model = etree.Element(
        _qn(NS_AM3D, "model3d"),
        attrib={_qn(NS_R, "embed"): glb_rid},
        nsmap={"am3d": NS_AM3D, "r": NS_R},
    )

    # spPr (shape properties inside the 3D body — positions the model's
    # shadow rect inside the graphicFrame).
    sp_pr = etree.SubElement(model, _qn(NS_AM3D, "spPr"))
    sp_pr_xfrm = etree.SubElement(sp_pr, _qn(NS_A, "xfrm"))
    etree.SubElement(sp_pr_xfrm, _qn(NS_A, "off"), attrib={"x": "0", "y": "0"})
    etree.SubElement(
        sp_pr_xfrm,
        _qn(NS_A, "ext"),
        attrib={"cx": str(extent_emu[0]), "cy": str(extent_emu[1])},
    )
    prst_geom = etree.SubElement(sp_pr, _qn(NS_A, "prstGeom"), attrib={"prst": "rect"})
    etree.SubElement(prst_geom, _qn(NS_A, "avLst"))

    # am3d:camera — pos / up / lookAt / perspective fov.
    cam = etree.SubElement(model, _qn(NS_AM3D, "camera"))
    etree.SubElement(
        cam,
        _qn(NS_AM3D, "pos"),
        attrib={
            "x": str(camera.pos[0]),
            "y": str(camera.pos[1]),
            "z": str(camera.pos[2]),
        },
    )
    etree.SubElement(
        cam,
        _qn(NS_AM3D, "up"),
        attrib={
            "dx": str(camera.up[0]),
            "dy": str(camera.up[1]),
            "dz": str(camera.up[2]),
        },
    )
    etree.SubElement(
        cam,
        _qn(NS_AM3D, "lookAt"),
        attrib={
            "x": str(camera.look_at[0]),
            "y": str(camera.look_at[1]),
            "z": str(camera.look_at[2]),
        },
    )
    etree.SubElement(
        cam,
        _qn(NS_AM3D, "perspective"),
        attrib={"fov": str(camera.fov_60000ths)},
    )

    # am3d:trans — transform, scale, Euler rotation, pre/post-translate.
    # `meterPerModelUnit` and `preTrans` are computed per-model by the
    # writer to match PowerPoint's auto-insert framing (see
    # evidence/fov-derivation.md). Defaults remain the sample's values
    # so callers that bypass the writer (or that pass an empty GLB) still
    # get a valid transform tree.
    trans = etree.SubElement(model, _qn(NS_AM3D, "trans"))
    mpmu_n, mpmu_d = meter_per_model_unit_n_d
    etree.SubElement(
        trans,
        _qn(NS_AM3D, "meterPerModelUnit"),
        attrib={"n": str(mpmu_n), "d": str(mpmu_d)},
    )
    etree.SubElement(
        trans,
        _qn(NS_AM3D, "preTrans"),
        attrib={
            "dx": str(pre_trans_emu[0]),
            "dy": str(pre_trans_emu[1]),
            "dz": str(pre_trans_emu[2]),
        },
    )
    scale = etree.SubElement(trans, _qn(NS_AM3D, "scale"))
    for axis in ("sx", "sy", "sz"):
        etree.SubElement(
            scale,
            _qn(NS_AM3D, axis),
            attrib={"n": "1000000", "d": "1000000"},
        )
    etree.SubElement(trans, _qn(NS_AM3D, "rot"), attrib={"ax": "0", "ay": "0", "az": "0"})
    etree.SubElement(
        trans,
        _qn(NS_AM3D, "postTrans"),
        attrib={"dx": "0", "dy": "0", "dz": "0"},
    )

    # am3d:raster — PNG preview for PDF/export + Older-client render path.
    raster = etree.SubElement(
        model,
        _qn(NS_AM3D, "raster"),
        attrib={"rName": "Office3DRenderer", "rVer": "16.0.8326"},
    )
    etree.SubElement(raster, _qn(NS_A, "blip"), attrib={_qn(NS_R, "embed"): png_rid})

    # am3d:extLst — embedded animation + poster frame, if present.
    if animation is not None:
        ext_lst = etree.SubElement(model, _qn(NS_AM3D, "extLst"))
        anim_ext = etree.SubElement(ext_lst, _qn(NS_A, "ext"), attrib={"uri": EXT_EMBED_ANIM})
        embed_anim = etree.SubElement(
            anim_ext,
            _qn(NS_A3DANIM, "embedAnim"),
            attrib={"animId": str(animation["animId"])},
            nsmap={"a3danim": NS_A3DANIM},
        )
        etree.SubElement(
            embed_anim,
            _qn(NS_AANIM, "animPr"),
            attrib={"len": str(animation["len_ms"]), "count": "indefinite"},
            nsmap={"aanim": NS_AANIM},
        )
        poster_ext = etree.SubElement(ext_lst, _qn(NS_A, "ext"), attrib={"uri": EXT_POSTER_FRAME})
        etree.SubElement(
            poster_ext,
            _qn(NS_A3DANIM, "posterFrame"),
            attrib={"animId": str(animation["animId"]), "frame": "0"},
            nsmap={"a3danim": NS_A3DANIM},
        )

    # am3d:objViewport — the scene cube.
    etree.SubElement(
        model,
        _qn(NS_AM3D, "objViewport"),
        attrib={"viewportSz": str(viewport_sz_emu)},
    )

    # Default lighting — ambient + 3 point lights, sample values.
    _append_default_lighting(model)

    return model


def _append_default_lighting(model: etree._Element) -> None:
    """Ambient + 3-point lighting rig from Microsoft's AnimatedModel3DExample."""
    ambient = etree.SubElement(model, _qn(NS_AM3D, "ambientLight"))
    _append_rgb_color(ambient, 50000, 50000, 50000)
    etree.SubElement(
        ambient,
        _qn(NS_AM3D, "illuminance"),
        attrib={"n": "500000", "d": "1000000"},
    )

    for color, intensity, pos in (
        ((100000, 75000, 50000), (9765625, 1000000), (21959998, 70920001, 16344003)),
        ((40000, 60000, 95000), (12250000, 1000000), (-37964106, 51130435, 57631972)),
        ((86837, 72700, 100000), (3125000, 1000000), (-37739122, 58056624, -34769649)),
    ):
        pt = etree.SubElement(model, _qn(NS_AM3D, "ptLight"), attrib={"rad": "0"})
        _append_rgb_color(pt, *color)
        etree.SubElement(
            pt,
            _qn(NS_AM3D, "intensity"),
            attrib={"n": str(intensity[0]), "d": str(intensity[1])},
        )
        etree.SubElement(
            pt,
            _qn(NS_AM3D, "pos"),
            attrib={"x": str(pos[0]), "y": str(pos[1]), "z": str(pos[2])},
        )


def _append_rgb_color(parent: etree._Element, r: int, g: int, b: int) -> None:
    clr = etree.SubElement(parent, _qn(NS_AM3D, "clr"))
    etree.SubElement(
        clr,
        _qn(NS_A, "scrgbClr"),
        attrib={"r": str(r), "g": str(g), "b": str(b)},
    )


# ---------------------------------------------------------------------------
# mc:Fallback (legacy p:pic)
# ---------------------------------------------------------------------------


def _build_picture_fallback(
    *,
    shape_id: int,
    shape_name: str,
    description: str,
    offset_emu: tuple[int, int],
    extent_emu: tuple[int, int],
    png_rid: str,
) -> etree._Element:
    """Build `<p:pic>` — the static-PNG fallback for non-3D-aware clients."""
    pic = etree.Element(_qn(NS_P, "pic"), nsmap={"p": NS_P, "a": NS_A, "r": NS_R})

    nv_pic_pr = etree.SubElement(pic, _qn(NS_P, "nvPicPr"))
    etree.SubElement(
        nv_pic_pr,
        _qn(NS_P, "cNvPr"),
        attrib={"id": str(shape_id), "name": shape_name, "descr": description},
    )
    cnv_pic_pr = etree.SubElement(nv_pic_pr, _qn(NS_P, "cNvPicPr"))
    etree.SubElement(
        cnv_pic_pr,
        _qn(NS_A, "picLocks"),
        attrib={
            "noGrp": "1",
            "noRot": "1",
            "noChangeAspect": "1",
            "noMove": "1",
            "noResize": "1",
            "noEditPoints": "1",
            "noAdjustHandles": "1",
            "noChangeArrowheads": "1",
            "noChangeShapeType": "1",
            "noCrop": "1",
        },
    )
    etree.SubElement(nv_pic_pr, _qn(NS_P, "nvPr"))

    blip_fill = etree.SubElement(pic, _qn(NS_P, "blipFill"))
    etree.SubElement(blip_fill, _qn(NS_A, "blip"), attrib={_qn(NS_R, "embed"): png_rid})
    stretch = etree.SubElement(blip_fill, _qn(NS_A, "stretch"))
    etree.SubElement(stretch, _qn(NS_A, "fillRect"))

    sp_pr = etree.SubElement(pic, _qn(NS_P, "spPr"))
    sp_pr_xfrm = etree.SubElement(sp_pr, _qn(NS_A, "xfrm"))
    etree.SubElement(
        sp_pr_xfrm,
        _qn(NS_A, "off"),
        attrib={"x": str(offset_emu[0]), "y": str(offset_emu[1])},
    )
    etree.SubElement(
        sp_pr_xfrm,
        _qn(NS_A, "ext"),
        attrib={"cx": str(extent_emu[0]), "cy": str(extent_emu[1])},
    )
    prst_geom = etree.SubElement(sp_pr, _qn(NS_A, "prstGeom"), attrib={"prst": "rect"})
    etree.SubElement(prst_geom, _qn(NS_A, "avLst"))
    return pic


# ---------------------------------------------------------------------------
# Helpers for the caller (writer.py)
# ---------------------------------------------------------------------------


def find_existing_model3d(sp_tree: etree._Element) -> etree._Element | None:
    """Find an existing `<mc:AlternateContent>` that hosts an `am3d:model3d`.

    Returns the AlternateContent element if found, else None. Used for
    idempotent updates: a second `insert_model` call on the same slide
    should REPLACE the prior block, not add a second.
    """
    # Scan direct children of spTree for the AlternateContent wrapper that
    # contains an am3d:model3d graphicData.
    for child in sp_tree:
        if _local_name(child.tag) != "AlternateContent":
            continue
        # Poke at choice → graphicFrame → graphic → graphicData/@uri.
        uri = _find_graphic_data_uri(child)
        if uri == NS_AM3D:
            return child
    return None


def _local_name(tag: Any) -> str:
    if isinstance(tag, str) and tag.startswith("{"):
        return tag.rsplit("}", 1)[1]
    return str(tag)


def _find_graphic_data_uri(alt_content: etree._Element) -> str | None:
    choice_ns = _qn(NS_MC, "Choice")
    for choice in alt_content.iter(choice_ns):
        for gd in choice.iter(_qn(NS_A, "graphicData")):
            uri = gd.get("uri")
            if isinstance(uri, str):
                return uri
    return None
