"""`insert_model` --- the top-level orchestrator for 3D model injection.

Wraps the four moving pieces the OOXML recipe requires:

1. A `.glb` media part at `/ppt/media/model3dN.glb` with content type
   `model/gltf-binary`, related to the slide via the custom Microsoft
   relationship type `.../2017/06/relationships/model3d`.
2. A `.png` preview part (or a baked-in placeholder if none supplied)
   at `/ppt/media/imageN.png` via the standard image rel.
3. A per-model transform (`meterPerModelUnit` + `preTrans`) computed
   from the GLB's world-space bbox so the rendered model is normalized
   to a fixed scene-EMU size and centered at scene origin --- matching
   PowerPoint Desktop's auto-insert behaviour (see
   `evidence/fov-derivation.md`).
4. An `<mc:AlternateContent>` block injected under `<p:spTree>` carrying
   the `<am3d:model3d>` body + a `<p:pic>` fallback.

Idempotent: calling `insert_model` twice on the same slide replaces the
prior 3D block (orphaning its old parts --- they fall out of the package
when python-pptx serializes since they're no longer reachable via the
relationship graph).
"""

import math
from io import BytesIO
from pathlib import Path
from typing import Any, Literal
from uuid import UUID, uuid5

from pptxforge.layouts import Region
from pptxforge.model3d._xml import (
    CT_MODEL3D,
    RELTYPE_MODEL3D,
    SAMPLE_METER_PER_MODEL_UNIT_D,
    SAMPLE_METER_PER_MODEL_UNIT_N,
    SAMPLE_PRE_TRANS,
    SAMPLE_VIEWPORT_SZ_EMU,
    build_alternate_content,
    find_existing_model3d,
)
from pptxforge.model3d.bounds import ModelBounds, read_model_bounds_from_bytes
from pptxforge.model3d.camera import EMU_PER_METER, Camera, resolve_camera
from pptxforge.model3d.validators import InvalidModelError, validate_glb

# Deterministic-UUID namespace for stable creationIds. Pinned once; changing
# this is a breaking change for any deck that relied on a stable key paired
# via morph across builds. See research/morph.md §8.3.
PPTXFORGE_UUID_NAMESPACE = UUID("f4e9b1a0-31c7-4a2c-bd3a-b59e3b9a19e7")

# meterPerModelUnit is encoded as an n/d rational; the writer pins the
# denominator at 1_000_000 (matches every PowerPoint-authored reference
# we've inspected). The numerator is then int(round(value * 1_000_000)).
_METER_PER_MODEL_UNIT_DENOM = 1_000_000


_AnimationMode = Literal["embedded", "turntable"]


def insert_model(
    slide: Any,
    glb_path: Path | str,
    region: Region,
    *,
    camera: Camera | None = None,
    animation: _AnimationMode | None = None,
    animation_duration_ms: int = 1900,
    preview_png: Path | str | None = None,
    stable_key: str | None = None,
    shape_name: str = "3D Model 1",
    description: str = "",
) -> None:
    """Insert (or replace) a 3D model on `slide` inside `region`.

    Idempotent: a second call on the same slide tears down the prior
    3D block before installing the new one. Pair that with a matching
    `stable_key` to get camera-orbit-via-morph across adjacent slides.

    `animation="embedded"` drives the first glTF animation track baked
    into the GLB. `animation="turntable"` reserves a preset-ID slot that
    will drive a camera rotation once the triple is empirically captured
    (see research/embedded-3d.md §5.2 Open Questions); in the meantime
    turntable is a no-op on the OOXML timing tree, and the user should
    rely on `morph_from_previous` for camera orbits.

    `stable_key`, when given, hashes into a deterministic
    `a16:creationId` (UUIDv5) --- the key by which PowerPoint's morph
    transition pairs shapes across slides (research/morph.md §4.2).
    """
    glb = Path(glb_path)
    # validate_glb is path-based: checks the .glb extension before reading
    # bytes (so .gltf inputs raise the more-useful 'wrong-extension' error).
    validate_glb(glb)
    glb_bytes = glb.read_bytes()

    # --- A. World-space bounds drive the per-model transform & camera. ---
    bounds = read_model_bounds_from_bytes(glb_bytes)
    transform = _compute_transform(bounds)

    resolved_camera = resolve_camera(
        camera or Camera(),
        model_radius_emu=transform.radius_emu,
    )

    # --- 1. Remove any prior 3D block on this slide (idempotency) -----------
    sp_tree = slide.shapes._spTree
    prior = find_existing_model3d(sp_tree)
    if prior is not None:
        sp_tree.remove(prior)

    # --- 2. Register the PNG preview as an image part ------------------------
    png_blob = _read_preview_png(preview_png)
    image_part, png_rid = _add_image_part(slide, png_blob)
    del image_part  # rId is all we need

    # --- 3. Register the GLB as a custom-reltype part ------------------------
    glb_rid = _add_glb_part(slide, glb_bytes)

    # --- 4. Compute a stable creationId for this shape -----------------------
    creation_id = (
        uuid5(PPTXFORGE_UUID_NAMESPACE, stable_key)
        if stable_key is not None
        else _new_creation_id()
    )

    # --- 5. Build and append the AlternateContent subtree -------------------
    shape_id = slide.shapes._next_shape_id
    anim_payload: dict[str, int] | None
    if animation == "embedded":
        anim_payload = {"animId": 0, "len_ms": animation_duration_ms}
    else:
        anim_payload = None

    ac = build_alternate_content(
        shape_id=shape_id,
        shape_name=shape_name,
        description=description or shape_name,
        creation_id=creation_id,
        offset_emu=(region.x, region.y),
        extent_emu=(region.w, region.h),
        glb_rid=glb_rid,
        png_rid=png_rid,
        camera=resolved_camera,
        animation=anim_payload,
        meter_per_model_unit_n_d=transform.meter_per_model_unit_n_d,
        pre_trans_emu=transform.pre_trans_emu,
        viewport_sz_emu=transform.viewport_sz_emu,
    )
    sp_tree.append(ac)

    # --- 6. Timing block for embedded animation -----------------------------
    if anim_payload is not None:
        from pptxforge.model3d._timing import attach_embedded_timing

        attach_embedded_timing(slide, shape_id=shape_id, duration_ms=animation_duration_ms)


# ---------------------------------------------------------------------------
# Per-model transform computation: meterPerModelUnit + preTrans + radius_emu
# ---------------------------------------------------------------------------


class _ResolvedTransform:
    """The four per-model values the writer needs at insertion time.

    Plain attribute container, not a frozen dataclass --- this is purely
    internal plumbing between `_compute_transform` and `insert_model`.
    """

    __slots__ = (
        "meter_per_model_unit_n_d",
        "pre_trans_emu",
        "radius_emu",
        "viewport_sz_emu",
    )

    def __init__(
        self,
        *,
        meter_per_model_unit_n_d: tuple[int, int],
        pre_trans_emu: tuple[int, int, int],
        viewport_sz_emu: int,
        radius_emu: int,
    ) -> None:
        self.meter_per_model_unit_n_d = meter_per_model_unit_n_d
        self.pre_trans_emu = pre_trans_emu
        self.viewport_sz_emu = viewport_sz_emu
        self.radius_emu = radius_emu


def _compute_transform(bounds: ModelBounds) -> _ResolvedTransform:
    """Map world-space bounds to PowerPoint's per-model transform values.

    Algorithm back-solved from `evidence/helmet-reference.pptx` and
    documented in `evidence/fov-derivation.md`:

        meterPerModelUnit = 1 / (2 * max(half_extents_after_node_transforms))
        preTrans          = -bbox_center * meterPerModelUnit * EMU_PER_METER
        radius_emu        = sqrt(sum((h * meterPerModelUnit * EMU_PER_METER)**2))

    For empty / no-geometry GLBs (proteins-in-motion's 48-byte
    placeholders, hand-synthesized test fixtures), fall back to the
    AnimatedModel3DExample sample's hardcoded values --- these decks
    already won't render geometry; the priority is producing a syntactically
    valid `am3d:trans` so the rest of the pipeline doesn't fault.
    """
    if not bounds.has_geometry:
        return _ResolvedTransform(
            meter_per_model_unit_n_d=(
                SAMPLE_METER_PER_MODEL_UNIT_N,
                SAMPLE_METER_PER_MODEL_UNIT_D,
            ),
            pre_trans_emu=SAMPLE_PRE_TRANS,
            viewport_sz_emu=SAMPLE_VIEWPORT_SZ_EMU,
            radius_emu=0,
        )

    max_half = max(bounds.half_extents)
    if max_half <= 0.0:
        # `bounds.has_geometry` should already gate this, but defend anyway.
        return _compute_transform(
            ModelBounds(
                center=bounds.center,
                half_extents=bounds.half_extents,
                has_geometry=False,
            )
        )

    mpmu = 1.0 / (2.0 * max_half)
    n = round(mpmu * _METER_PER_MODEL_UNIT_DENOM)
    if n <= 0:
        n = 1  # vanishingly small models still need a positive numerator
    scale_to_emu = mpmu * EMU_PER_METER

    cx, cy, cz = bounds.center
    pre_trans_emu = (
        -round(cx * scale_to_emu),
        -round(cy * scale_to_emu),
        -round(cz * scale_to_emu),
    )

    hx, hy, hz = bounds.half_extents
    radius_emu = round(
        math.sqrt((hx * scale_to_emu) ** 2 + (hy * scale_to_emu) ** 2 + (hz * scale_to_emu) ** 2)
    )

    return _ResolvedTransform(
        meter_per_model_unit_n_d=(n, _METER_PER_MODEL_UNIT_DENOM),
        pre_trans_emu=pre_trans_emu,
        viewport_sz_emu=SAMPLE_VIEWPORT_SZ_EMU,
        radius_emu=radius_emu,
    )


# ---------------------------------------------------------------------------
# Part-registration helpers --- thin shims over python-pptx internals.
# ---------------------------------------------------------------------------


def _add_image_part(slide: Any, png_blob: bytes) -> tuple[Any, str]:
    """Register the raster fallback PNG on `slide` and return `(part, rId)`.

    `SlidePart.get_or_add_image_part` dedups by SHA-1 hash AND wires the
    relationship --- returns `(image_part, rId)`. Two 3D slides that share
    a preview share a single image part.
    """
    image_part, rid = slide.part.get_or_add_image_part(BytesIO(png_blob))
    return image_part, rid


def _add_glb_part(slide: Any, glb_bytes: bytes) -> str:
    """Register the `.glb` as a custom-reltype part and return its rId.

    SHA-1-deduped within the package: a second call with byte-identical
    `glb_bytes` reuses the existing part and just adds a fresh slide rel
    pointing at it. Mirrors python-pptx's image-part dedup, so an N-stop
    `model3d_flight` over one model ships one GLB blob, not N copies.
    """
    from pptx.opc.package import Part

    package = slide.part.package
    existing_part = _find_matching_glb_part(package, glb_bytes)
    if existing_part is not None:
        rid: str = slide.part.relate_to(existing_part, RELTYPE_MODEL3D)
        return rid

    partname = _next_model3d_partname(package)
    # Part signature: (partname, content_type, package, blob=None) ---
    # `package` comes BEFORE `blob` in python-pptx 1.0.
    part = Part(partname, CT_MODEL3D, package, blob=glb_bytes)
    new_rid: str = slide.part.relate_to(part, RELTYPE_MODEL3D)
    return new_rid


def _find_matching_glb_part(package: Any, glb_bytes: bytes) -> Any | None:
    """Return the package part whose blob equals `glb_bytes`, or None.

    Cheap-but-correct: SHA-1 the candidate once, then compare against
    SHA-1s of existing model3d parts. Equal-length byte comparison would
    work too but the hash makes the intent obvious and stays cheap when
    a deck has many flights with different models.
    """
    import hashlib

    target_sha = hashlib.sha1(glb_bytes, usedforsecurity=False).digest()
    for part in package.iter_parts():
        if getattr(part, "content_type", None) != CT_MODEL3D:
            continue
        if hashlib.sha1(part.blob, usedforsecurity=False).digest() == target_sha:
            return part
    return None


def _next_model3d_partname(package: Any) -> Any:
    """Next unused /ppt/media/model3dN.glb partname."""
    from pptx.opc.packuri import PackURI

    template = "/ppt/media/model3d{i}.glb"
    existing = {str(p.partname).lower() for p in package.iter_parts()}
    i = 1
    while True:
        candidate = PackURI(template.format(i=i))
        if str(candidate).lower() not in existing:
            return candidate
        i += 1


def _new_creation_id() -> UUID:
    """Fresh random creationId for shapes not opted into stable pairing."""
    from uuid import uuid4

    return uuid4()


# ---------------------------------------------------------------------------
# Preview PNG resolution
# ---------------------------------------------------------------------------


def _read_preview_png(preview_png: Path | str | None) -> bytes:
    """Return PNG bytes for the raster fallback.

    With no caller-supplied preview, return a baked-in package-resource
    PNG: a small isometric "3D model" cube. The placeholder is shipped
    as static bytes (not rendered at runtime) so that the wheel has no
    headless-3D dependency and the fallback has consistent visual
    identity in non-PowerPoint viewers (LibreOffice, Google Slides,
    Keynote, PDF export). See DECISIONS.md.
    """
    if preview_png is not None:
        p = Path(preview_png)
        if not p.is_file():
            raise FileNotFoundError(f"preview_png not found: {p}")
        return p.read_bytes()

    from importlib.resources import files

    return (files("pptxforge.model3d._assets") / "placeholder_3d.png").read_bytes()


# Re-export InvalidModelError at package scope for callers.
__all__ = [
    "insert_model",
    "Camera",
    "InvalidModelError",
    "PPTXFORGE_UUID_NAMESPACE",
]
