"""Theme — complete visual contract — plus the ten built-in palettes.

A `Theme` bundles: (a) a `Palette` of nine semantic color roles, (b) a
`TypographyPair` of font stacks, (c) a `TypeScale` of sized/weighted
type-scale steps, (d) a `SpacingScale` of named EMU steps, (e) a `Radii`
set. Themes are pure value-objects; mutation is disallowed after
construction.

The ten built-ins are module-level constants in UPPER_SNAKE_CASE. They are
pptxforge's interpretation of the pptx skill's "Color Palettes" table —
the three names the user explicitly cited (Midnight Executive, Forest &
Moss, Coral Energy) are anchored to the descriptions they gave; the other
seven round out a set that covers common presentation moods (corporate,
organic, energetic, minimal, editorial, cool, mono, warm, bright, bold).

**Explicit pitfall, per brief.** No theme ships with a cream or beige
light background. Every `background_light` is pure white (`#FFFFFF`); any
warm tinting happens on the `surface` token, never on the slide base.
"""

from dataclasses import dataclass
from pathlib import Path

from pydantic import BaseModel, ConfigDict

from pptxforge.design.tokens import (
    ColorToken,
    RadiusToken,
    SpacingToken,
    TypographyToken,
)
from pptxforge.design.typography import (
    CLASSIC_SERIF,
    CORPORATE,
    EDITORIAL,
    MODERN_SANS,
    TypographyPair,
)

# ---------------------------------------------------------------------------
# Typed scales — each theme gets one of each.
# ---------------------------------------------------------------------------


class Palette(BaseModel):
    """The eleven required color roles every theme must populate.

    A typed container (instead of a free-form dict) so mypy can enforce
    the complete set at construction. Adding a role is a library-wide
    refactor — intentional, to keep downstream layout code honest.

    `surface_three_d` and `text_on_dark` exist specifically for the
    Model3DSlide dark-surface treatment (DECISIONS 2026-04-27): every
    theme — including light themes — needs a near-black slide fill so
    3D models read as physical objects, plus a paired light text colour
    so the slide title stays readable against that dark fill.
    """

    model_config = ConfigDict(frozen=True, strict=True)

    primary: ColorToken
    secondary: ColorToken
    accent: ColorToken
    background_light: ColorToken
    background_dark: ColorToken
    surface: ColorToken
    surface_three_d: ColorToken
    text_primary: ColorToken
    text_muted: ColorToken
    text_on_dark: ColorToken
    divider: ColorToken


class TypeScale(BaseModel):
    """Named type-scale steps: hero / h1 / h2 / lead / body / caption."""

    model_config = ConfigDict(frozen=True, strict=True)

    hero: TypographyToken
    h1: TypographyToken
    h2: TypographyToken
    lead: TypographyToken
    body: TypographyToken
    caption: TypographyToken


class SpacingScale(BaseModel):
    """Named spacing steps: xs / sm / md / lg / xl."""

    model_config = ConfigDict(frozen=True, strict=True)

    xs: SpacingToken
    sm: SpacingToken
    md: SpacingToken
    lg: SpacingToken
    xl: SpacingToken


class Radii(BaseModel):
    """Named corner-radius steps: none / sm / md / lg."""

    model_config = ConfigDict(frozen=True, strict=True)

    none: RadiusToken
    sm: RadiusToken
    md: RadiusToken
    lg: RadiusToken


# ---------------------------------------------------------------------------
# Defaults — every theme inherits these unless it has an opinion.
# ---------------------------------------------------------------------------

DEFAULT_TYPE_SCALE = TypeScale(
    # Calibrated to the pptx skill's anti-AI-slop rules:
    # - slide titles >= 36pt → h1 at 40pt, hero at 56pt
    # - body sits in 14-16pt → body at 16pt
    # - caption slightly under body at 12pt
    # Any slide element labelled a "title" (TitleSlide hero, SectionSlide
    # title, ContentSlide title, ...) maps to hero or h1.
    hero=TypographyToken(size_pt=56, weight="bold", line_height=1.05),
    h1=TypographyToken(size_pt=40, weight="semibold", line_height=1.15),
    h2=TypographyToken(size_pt=24, weight="semibold", line_height=1.25),
    lead=TypographyToken(size_pt=20, weight="regular", line_height=1.4),
    body=TypographyToken(size_pt=16, weight="regular", line_height=1.5),
    caption=TypographyToken(size_pt=12, weight="regular", line_height=1.4),
)

DEFAULT_SPACING = SpacingScale(
    xs=SpacingToken(value_emu=50800),  # 4 pt
    sm=SpacingToken(value_emu=101600),  # 8 pt
    md=SpacingToken(value_emu=203200),  # 16 pt
    lg=SpacingToken(value_emu=304800),  # 24 pt
    xl=SpacingToken(value_emu=457200),  # 36 pt
)

DEFAULT_RADII = Radii(
    none=RadiusToken(value_emu=0),
    sm=RadiusToken(value_emu=50800),  # 4 pt
    md=RadiusToken(value_emu=101600),  # 8 pt
    lg=RadiusToken(value_emu=152400),  # 12 pt
)


# ---------------------------------------------------------------------------
# Theme
# ---------------------------------------------------------------------------


@dataclass(frozen=True, slots=True)
class Theme:
    """A complete visual contract: palette, typography, scales.

    Construct from one of the ten module-level constants (`MIDNIGHT_EXECUTIVE`,
    `FOREST_MOSS`, …) or build your own. Themes are immutable; derive a
    variant with `dataclasses.replace(theme, ...)`.

    Call `theme.preview(path)` to render a 3-slide sanity-check deck that
    exercises every color role — useful when iterating on a custom palette.

    Example:
        >>> from pptxforge import themes
        >>> themes.MIDNIGHT_EXECUTIVE.name
        'Midnight Executive'
        >>> themes.MIDNIGHT_EXECUTIVE.preview("out/midnight.pptx")
    """

    name: str
    description: str
    palette: Palette
    typography: TypographyPair
    type_scale: TypeScale = DEFAULT_TYPE_SCALE
    spacing: SpacingScale = DEFAULT_SPACING
    radii: Radii = DEFAULT_RADII

    def preview(self, path: Path | str) -> Path:
        """Render a 3-slide sanity-check deck demonstrating every token.

        Slide 1 (title): display font + hero type step + background_light.
        Slide 2 (content): every palette role used at least once, plus
            every type-scale step.
        Slide 3 (accent): dark-background slide featuring the accent
            token + background_dark.

        Returns the absolute `Path` written.
        """
        from pptxforge.design._preview import render_theme_preview

        out = Path(path).resolve()
        out.parent.mkdir(parents=True, exist_ok=True)
        render_theme_preview(self, out)
        return out


# ---------------------------------------------------------------------------
# The ten built-ins.
#
# Order below matches the pptx skill's table as best we could reconstruct it;
# if you discover the canonical ordering please update here and in the
# `ALL_THEMES` tuple.
# ---------------------------------------------------------------------------


def _ct(value: str, description: str | None = None) -> ColorToken:
    """Concise ColorToken constructor for the theme tables below."""
    return ColorToken(value=value, description=description)


MIDNIGHT_EXECUTIVE = Theme(
    name="Midnight Executive",
    description=(
        "Deep navy primary, ice-blue secondary, warm gold accent. "
        "For C-suite decks where the palette should read as disciplined, "
        "not decorative."
    ),
    palette=Palette(
        primary=_ct("#0B1F3A", "Deep navy — body titles, chart series 1"),
        secondary=_ct("#4A6FA5", "Steel blue — supporting text, chart series 2"),
        accent=_ct("#D4AF37", "Antique gold — callouts, quote rules, key numbers"),
        background_light=_ct("#FFFFFF"),
        background_dark=_ct("#0B1F3A"),
        surface=_ct("#F4F7FB", "Ice-blue tint for elevated cards"),
        surface_three_d=_ct("#0B1220", "Near-black navy for 3D slide backgrounds"),
        text_primary=_ct("#0B1F3A"),
        text_muted=_ct("#4A6FA5"),
        text_on_dark=_ct("#F5F5F7", "Off-white for text on dark surfaces"),
        divider=_ct("#DCE4EF"),
    ),
    typography=CORPORATE,
)

FOREST_MOSS = Theme(
    name="Forest & Moss",
    description=(
        "Forest-green primary, moss secondary, mustard-gold accent. "
        "Grounded and organic without drifting into cream/beige — the "
        "`surface` token is a pale sage tint, never warm neutral."
    ),
    palette=Palette(
        primary=_ct("#1F3B2C", "Deep forest"),
        secondary=_ct("#7A9B6E", "Moss"),
        accent=_ct("#D4A441", "Mustard gold"),
        background_light=_ct("#FFFFFF"),
        background_dark=_ct("#1A2E22"),
        surface=_ct("#F2F6EF", "Pale sage — NOT beige"),
        surface_three_d=_ct("#0E1A12", "Near-black forest for 3D slide backgrounds"),
        text_primary=_ct("#1F3B2C"),
        text_muted=_ct("#5F7457"),
        text_on_dark=_ct("#F5F5F7", "Off-white for text on dark surfaces"),
        divider=_ct("#D8E0D4"),
    ),
    typography=EDITORIAL,
)

CORAL_ENERGY = Theme(
    name="Coral Energy",
    description=(
        "Warm coral primary, peach secondary, complementary teal accent. "
        "Bright without being saccharine; dark-mode background sits on a "
        "plum-black so coral pops."
    ),
    palette=Palette(
        primary=_ct("#E4572E", "Coral"),
        secondary=_ct("#F4A261", "Peach"),
        accent=_ct("#2A9D8F", "Teal — complementary contrast"),
        background_light=_ct("#FFFFFF"),
        background_dark=_ct("#2D1B2E", "Plum-black backdrop"),
        surface=_ct("#FFF7F2", "Pale peach tint for cards"),
        surface_three_d=_ct("#1A1614", "Near-black warm gray for 3D slide backgrounds"),
        text_primary=_ct("#2D1B2E"),
        text_muted=_ct("#8B5A4E"),
        text_on_dark=_ct("#F5F5F7", "Off-white for text on dark surfaces"),
        divider=_ct("#F2D9C8"),
    ),
    typography=MODERN_SANS,
)

SLATE_MINIMALIST = Theme(
    name="Slate Minimalist",
    description=(
        "Cool charcoal primaries, a single sky-blue accent. Neutral, "
        "product-launch aesthetic. Works for technical content."
    ),
    palette=Palette(
        primary=_ct("#1F2937", "Charcoal"),
        secondary=_ct("#64748B", "Slate"),
        accent=_ct("#0EA5E9", "Sky blue"),
        background_light=_ct("#FFFFFF"),
        background_dark=_ct("#0F172A"),
        surface=_ct("#F8FAFC"),
        surface_three_d=_ct("#1A1F2C", "Dark slate for 3D slide backgrounds"),
        text_primary=_ct("#0F172A"),
        text_muted=_ct("#64748B"),
        text_on_dark=_ct("#F5F5F7", "Off-white for text on dark surfaces"),
        divider=_ct("#E2E8F0"),
    ),
    typography=MODERN_SANS,
)

ROYAL_PLUM = Theme(
    name="Royal Plum",
    description=(
        "Deep plum primary, lavender secondary, golden-yellow accent. "
        "Luxe without the velvet-and-gold cliché."
    ),
    palette=Palette(
        primary=_ct("#4A1942", "Plum"),
        secondary=_ct("#9B5B9B", "Lavender"),
        accent=_ct("#F5C518", "Golden yellow"),
        background_light=_ct("#FFFFFF"),
        background_dark=_ct("#2A0E26"),
        surface=_ct("#F9F5F8", "Very pale plum tint"),
        surface_three_d=_ct("#150815", "Near-black plum for 3D slide backgrounds"),
        text_primary=_ct("#2A0E26"),
        text_muted=_ct("#7A5A7A"),
        text_on_dark=_ct("#F5F5F7", "Off-white for text on dark surfaces"),
        divider=_ct("#E8D8E3"),
    ),
    typography=CLASSIC_SERIF,
)

PACIFIC_DEEP = Theme(
    name="Pacific Deep",
    description=(
        "Deep teal primary, aqua secondary, orange accent. Ocean-inspired; "
        "the orange accent is chromatically opposite and carries the pop."
    ),
    palette=Palette(
        primary=_ct("#004D5C", "Deep teal"),
        secondary=_ct("#4FB3BF", "Aqua"),
        accent=_ct("#F97316", "Saturated orange"),
        background_light=_ct("#FFFFFF"),
        background_dark=_ct("#002A35"),
        surface=_ct("#F0F9FB", "Pale cyan"),
        surface_three_d=_ct("#0A1F26", "Near-black teal for 3D slide backgrounds"),
        text_primary=_ct("#002A35"),
        text_muted=_ct("#4F7D87"),
        text_on_dark=_ct("#F5F5F7", "Off-white for text on dark surfaces"),
        divider=_ct("#CCE4E8"),
    ),
    typography=MODERN_SANS,
)

MONOCHROME_INK = Theme(
    name="Monochrome Ink",
    description=(
        "Pure black, pure white, one blood-red accent. The editorial choice "
        "when the content is the design. Use Classic Serif to lean "
        "newspaper; pair with the Universal stack to lean brutalist."
    ),
    palette=Palette(
        primary=_ct("#000000", "Pure black"),
        secondary=_ct("#525252", "Graphite"),
        accent=_ct("#E50914", "Blood red — single pop"),
        background_light=_ct("#FFFFFF"),
        background_dark=_ct("#000000"),
        surface=_ct("#F5F5F5", "Neutral gray card"),
        surface_three_d=_ct("#161618", "Near-black charcoal for 3D slide backgrounds"),
        text_primary=_ct("#000000"),
        text_muted=_ct("#737373"),
        text_on_dark=_ct("#F5F5F7", "Off-white for text on dark surfaces"),
        divider=_ct("#D4D4D4"),
    ),
    typography=CLASSIC_SERIF,
)

AMBER_EDITORIAL = Theme(
    name="Amber Editorial",
    description=(
        "Burnt-amber primary, deep-amber secondary, indigo accent. "
        "Warm but disciplined — background_light stays pure white; warmth "
        "lives in the primary, not the page."
    ),
    palette=Palette(
        primary=_ct("#B45309", "Burnt amber"),
        secondary=_ct("#92400E", "Deep amber"),
        accent=_ct("#1E3A8A", "Deep indigo"),
        background_light=_ct("#FFFFFF"),
        background_dark=_ct("#451A03"),
        surface=_ct("#FAFAFA", "Neutral — NOT beige"),
        surface_three_d=_ct("#1A0E03", "Near-black amber for 3D slide backgrounds"),
        text_primary=_ct("#451A03"),
        text_muted=_ct("#78716C"),
        text_on_dark=_ct("#F5F5F7", "Off-white for text on dark surfaces"),
        divider=_ct("#E7E5E4"),
    ),
    typography=EDITORIAL,
)

SUNRISE_CITRUS = Theme(
    name="Sunrise Citrus",
    description=(
        "Amber-yellow primary, orange secondary, sky-blue accent. "
        "Optimistic without being childish. Good for product-update decks."
    ),
    palette=Palette(
        primary=_ct("#F59E0B", "Amber-yellow"),
        secondary=_ct("#EF6C00", "Bright orange"),
        accent=_ct("#0284C7", "Sky blue"),
        background_light=_ct("#FFFFFF"),
        background_dark=_ct("#1E293B"),
        surface=_ct("#FAFAFA"),
        surface_three_d=_ct("#171008", "Near-black warm for 3D slide backgrounds"),
        text_primary=_ct("#1E293B"),
        text_muted=_ct("#78716C"),
        text_on_dark=_ct("#F5F5F7", "Off-white for text on dark surfaces"),
        divider=_ct("#E5E5E5"),
    ),
    typography=MODERN_SANS,
)

BERRY_BOLD = Theme(
    name="Berry Bold",
    description=(
        "Berry primary, pink secondary, deep-purple accent. Editorial "
        "and loud without being pink-for-pink's-sake."
    ),
    palette=Palette(
        primary=_ct("#BE185D", "Berry"),
        secondary=_ct("#EC4899", "Pink"),
        accent=_ct("#4C1D95", "Deep purple"),
        background_light=_ct("#FFFFFF"),
        background_dark=_ct("#4C1D95"),
        surface=_ct("#FDF2F8", "Pale pink"),
        surface_three_d=_ct("#180810", "Near-black berry for 3D slide backgrounds"),
        text_primary=_ct("#500724", "Very dark berry"),
        text_muted=_ct("#9F1239"),
        text_on_dark=_ct("#F5F5F7", "Off-white for text on dark surfaces"),
        divider=_ct("#FCE7F3"),
    ),
    typography=MODERN_SANS,
)


ALL_THEMES: tuple[Theme, ...] = (
    MIDNIGHT_EXECUTIVE,
    FOREST_MOSS,
    CORAL_ENERGY,
    SLATE_MINIMALIST,
    ROYAL_PLUM,
    PACIFIC_DEEP,
    MONOCHROME_INK,
    AMBER_EDITORIAL,
    SUNRISE_CITRUS,
    BERRY_BOLD,
)
"""Every built-in theme, in display order."""
