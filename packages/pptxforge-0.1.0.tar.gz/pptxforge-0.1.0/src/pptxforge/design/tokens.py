"""Semantic design tokens.

Tokens are named by *role* (e.g. `primary`, `text.primary`, `accent`), never
by literal value (no `blue500`, no `gray300`). A `Theme` collects the tokens
into a complete contract; consumers — slides, layouts — reach for tokens by
role, not hex.
"""

import re
from typing import Literal

from pydantic import BaseModel, ConfigDict, field_validator

_HEX_PATTERN = re.compile(r"^#[0-9A-Fa-f]{6}$")


class ColorToken(BaseModel):
    """A hex color value inside a theme's palette.

    The semantic role (`primary`, `surface`, `text.primary`, …) is carried
    by the containing `Palette` field — the token itself only stores the
    sRGB value. Hex is validated at construction and normalized to upper
    case.

    Example:
        >>> ColorToken(value="#0B1F3A").value
        '#0B1F3A'
    """

    model_config = ConfigDict(frozen=True, strict=True)

    value: str
    description: str | None = None

    @field_validator("value")
    @classmethod
    def _valid_hex(cls, v: str) -> str:
        if not _HEX_PATTERN.fullmatch(v):
            raise ValueError(f"not a valid #RRGGBB hex color: {v!r}")
        return v.upper()

    @property
    def rgb(self) -> tuple[int, int, int]:
        """Return the 0–255 `(r, g, b)` tuple."""
        return (int(self.value[1:3], 16), int(self.value[3:5], 16), int(self.value[5:7], 16))


class SpacingToken(BaseModel):
    """A spacing step, stored in EMU (914400 = 1 inch).

    Used for margins, gutters, padding. Themes expose a named scale
    (xs / sm / md / lg / xl) built from these.

    Example:
        >>> SpacingToken(value_emu=101600).as_points()
        8.0
    """

    model_config = ConfigDict(frozen=True, strict=True)

    value_emu: int
    description: str | None = None

    @field_validator("value_emu")
    @classmethod
    def _non_negative(cls, v: int) -> int:
        if v < 0:
            raise ValueError(f"spacing must be non-negative EMU, got {v}")
        return v

    def as_points(self) -> float:
        """Return the spacing in points (1 pt = 12700 EMU)."""
        return self.value_emu / 12700


class TypographyToken(BaseModel):
    """A type-scale step: size, weight, line-height, letter-spacing.

    A theme's `type_scale` collects these under role names (`hero`, `h1`,
    `h2`, `lead`, `body`, `caption`). The font FACE lives on
    `Theme.typography` (a `TypographyPair`); this token controls size and
    tracking only.

    Example:
        >>> TypographyToken(size_pt=32, weight="semibold").size_pt
        32.0
    """

    model_config = ConfigDict(frozen=True, strict=True)

    size_pt: float
    weight: Literal["regular", "medium", "semibold", "bold"] = "regular"
    line_height: float = 1.4
    letter_spacing_em: float = 0.0
    italic: bool = False

    @field_validator("size_pt")
    @classmethod
    def _positive_size(cls, v: float) -> float:
        if v <= 0:
            raise ValueError(f"type size must be positive, got {v}")
        return v


class RadiusToken(BaseModel):
    """A corner-radius step, stored in EMU.

    Used for card surfaces, callouts, image frames. Themes expose a named
    scale (none / sm / md / lg).

    Example:
        >>> RadiusToken(value_emu=50800).value_emu
        50800
    """

    model_config = ConfigDict(frozen=True, strict=True)

    value_emu: int
    description: str | None = None

    @field_validator("value_emu")
    @classmethod
    def _non_negative(cls, v: int) -> int:
        if v < 0:
            raise ValueError(f"radius must be non-negative EMU, got {v}")
        return v
