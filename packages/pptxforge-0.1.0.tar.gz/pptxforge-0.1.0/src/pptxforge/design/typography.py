"""Font stacks and named typography pairings.

A `FontStack` is a primary font plus an ordered fallback chain. A
`TypographyPair` bundles a display stack, a body stack, and a mono stack.
Themes reference a `TypographyPair` — the pair is emitted into OOXML as
`<a:latin typeface=...>` on the primary and the fallback chain is preserved
so PowerPoint's substitution table picks a reasonable alternative when the
primary isn't installed.

## Known pitfall — font substitution

OOXML has no native "font stack" concept. PowerPoint substitutes silently
if the primary font isn't installed on the presenter's machine, often
landing on Calibri. `pptxforge` compensates by (a) preferring fonts that
ship with Windows + macOS Office out of the box, (b) writing the fallback
chain into the theme's `fontScheme` so clients with that part of the
substitution table respect it, and (c) exposing the whole stack on the
`FontStack` model so a future renderer (PDF export via a headless
engine) can honour it too.

Fonts below are grouped by cross-platform availability:

- **Windows + macOS + Office (safest):** Arial, Times New Roman, Georgia,
  Verdana, Tahoma, Trebuchet MS, Courier New, Comic Sans MS.
- **Windows + macOS Office 2016+:** Calibri, Cambria, Consolas.
- **Windows-only (macOS substitutes):** Segoe UI. Renders as a Helvetica
  variant on macOS.
- **macOS-only (Windows substitutes):** Helvetica Neue, Helvetica, SF Pro.
- **Common modern additions:** Inter (requires install or embed).

Every pairing below ends its fallback chain with `"sans-serif"` or
`"serif"` so the last-resort generic family is always honoured.
"""

from pydantic import BaseModel, ConfigDict, field_validator


class FontStack(BaseModel):
    """A primary font plus an ordered list of fallbacks.

    `primary` is the font PowerPoint will attempt first; `fallbacks` is
    the ordered list tried if the primary isn't present. The final
    fallback is conventionally a generic family (`"sans-serif"`,
    `"serif"`, `"monospace"`).

    Example:
        >>> FontStack(primary="Inter", fallbacks=["Segoe UI", "Arial", "sans-serif"])
    """

    model_config = ConfigDict(frozen=True, strict=True)

    primary: str
    fallbacks: tuple[str, ...]

    @field_validator("primary")
    @classmethod
    def _primary_non_empty(cls, v: str) -> str:
        if not v.strip():
            raise ValueError("primary font name cannot be empty")
        return v

    @field_validator("fallbacks")
    @classmethod
    def _at_least_one_fallback(cls, v: tuple[str, ...]) -> tuple[str, ...]:
        if len(v) == 0:
            raise ValueError(
                "at least one fallback is required; end with 'sans-serif', "
                "'serif', or 'monospace' as the generic family"
            )
        return v

    def as_css(self) -> str:
        """Emit as a CSS font-family string (for add-in webview stylesheets)."""
        names = [self.primary, *self.fallbacks]
        return ", ".join(_css_quote(name) for name in names)


def _css_quote(name: str) -> str:
    if name in {"serif", "sans-serif", "monospace", "cursive", "fantasy", "system-ui"}:
        return name
    if any(c in name for c in " -"):
        return f'"{name}"'
    return name


class TypographyPair(BaseModel):
    """A theme's font contract: display + body + mono, each a `FontStack`.

    `display` is used for titles and headings; `body` for paragraphs,
    bullets, and captions; `mono` for code and tabular figures. The
    downstream slide writer emits the primary of each stack into the
    `<a:majorFont>` / `<a:minorFont>` elements of the theme's font scheme
    and records the fallback chain alongside for future consumers.

    Example:
        >>> TypographyPair(
        ...     name="corporate",
        ...     display=FontStack(primary="Calibri", fallbacks=("Segoe UI", "Arial", "sans-serif")),
        ...     body=FontStack(primary="Calibri", fallbacks=("Segoe UI", "Arial", "sans-serif")),
        ...     mono=FontStack(primary="Consolas", fallbacks=("Menlo", "Courier New", "monospace")),
        ... )
    """

    model_config = ConfigDict(frozen=True, strict=True)

    name: str
    display: FontStack
    body: FontStack
    mono: FontStack


_ARIAL_FALLBACKS: tuple[str, ...] = ("Helvetica", "sans-serif")
_SEGOE_FALLBACKS: tuple[str, ...] = ("Helvetica Neue", "Arial", "sans-serif")
_CALIBRI_FALLBACKS: tuple[str, ...] = ("Segoe UI", "Helvetica Neue", "Arial", "sans-serif")
_GEORGIA_FALLBACKS: tuple[str, ...] = ("Cambria", "Times New Roman", "serif")
_CAMBRIA_FALLBACKS: tuple[str, ...] = ("Georgia", "Times New Roman", "serif")
_HELVETICA_NEUE_FALLBACKS: tuple[str, ...] = ("Helvetica", "Arial", "sans-serif")
_CONSOLAS_FALLBACKS: tuple[str, ...] = ("Menlo", "SF Mono", "Consolas", "Courier New", "monospace")


CORPORATE = TypographyPair(
    name="corporate",
    display=FontStack(primary="Calibri", fallbacks=_CALIBRI_FALLBACKS),
    body=FontStack(primary="Calibri", fallbacks=_CALIBRI_FALLBACKS),
    mono=FontStack(primary="Consolas", fallbacks=_CONSOLAS_FALLBACKS),
)
"""The PowerPoint default pair. Widest reach on Windows; Office-installed Macs have it too."""

EDITORIAL = TypographyPair(
    name="editorial",
    display=FontStack(primary="Georgia", fallbacks=_GEORGIA_FALLBACKS),
    body=FontStack(primary="Verdana", fallbacks=("Tahoma", "Arial", "sans-serif")),
    mono=FontStack(primary="Consolas", fallbacks=_CONSOLAS_FALLBACKS),
)
"""Serif display + sans body. Long-form narrative decks."""

CLASSIC_SERIF = TypographyPair(
    name="classic-serif",
    display=FontStack(primary="Cambria", fallbacks=_CAMBRIA_FALLBACKS),
    body=FontStack(primary="Calibri", fallbacks=_CALIBRI_FALLBACKS),
    mono=FontStack(primary="Consolas", fallbacks=_CONSOLAS_FALLBACKS),
)
"""PowerPoint's built-in serif display paired with sans body."""

MODERN_SANS = TypographyPair(
    name="modern-sans",
    display=FontStack(primary="Segoe UI", fallbacks=_SEGOE_FALLBACKS),
    body=FontStack(primary="Segoe UI", fallbacks=_SEGOE_FALLBACKS),
    mono=FontStack(primary="Consolas", fallbacks=_CONSOLAS_FALLBACKS),
)
"""Modern humanist sans. Substitutes to Helvetica Neue on macOS."""

KEYNOTE = TypographyPair(
    name="keynote",
    display=FontStack(primary="Helvetica Neue", fallbacks=_HELVETICA_NEUE_FALLBACKS),
    body=FontStack(primary="Helvetica Neue", fallbacks=_HELVETICA_NEUE_FALLBACKS),
    mono=FontStack(primary="Menlo", fallbacks=("Consolas", "SF Mono", "Courier New", "monospace")),
)
"""Apple-keynote aesthetic. Substitutes to Arial on Windows."""

UNIVERSAL = TypographyPair(
    name="universal",
    display=FontStack(primary="Arial", fallbacks=_ARIAL_FALLBACKS),
    body=FontStack(primary="Arial", fallbacks=_ARIAL_FALLBACKS),
    mono=FontStack(primary="Courier New", fallbacks=("Consolas", "monospace")),
)
"""The safest possible stack. Use when you cannot assume Office is installed."""


ALL_PAIRINGS: tuple[TypographyPair, ...] = (
    CORPORATE,
    EDITORIAL,
    CLASSIC_SERIF,
    MODERN_SANS,
    KEYNOTE,
    UNIVERSAL,
)
