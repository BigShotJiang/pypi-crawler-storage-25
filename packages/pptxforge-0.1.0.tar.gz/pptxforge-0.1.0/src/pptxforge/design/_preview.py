"""Renderer for `Theme.preview(path)` — a 3-slide sanity-check deck.

Kept out of `themes.py` so importing a theme doesn't force python-pptx
loading, and isolated so the implementation (which is prose-heavy) doesn't
crowd the data model.

Layout, slide by slide:

1. **Title** — hero-size theme name on `background_light`, description
   beneath, tiny "display / body font" tag at the bottom.
2. **Content** — every palette role demonstrated:
   - primary as the title color
   - secondary as the section divider label
   - accent as a left-side callout bar + a highlighted phrase
   - surface as a card behind a bullet list
   - divider as a hairline rule
   - text_primary as body copy
   - text_muted as a caption
3. **Accent** — dark-mode preview: `background_dark`, theme name in
   white, accent token used as a large number/marker, secondary as a
   tagline.
"""

from pathlib import Path
from typing import TYPE_CHECKING, Any

from pptx import Presentation
from pptx.dml.color import RGBColor
from pptx.enum.shapes import MSO_SHAPE
from pptx.enum.text import MSO_ANCHOR, PP_ALIGN
from pptx.util import Emu, Pt

if TYPE_CHECKING:
    from pptxforge.design.themes import Theme
    from pptxforge.design.tokens import ColorToken
    from pptxforge.design.typography import FontStack


SLIDE_W_EMU = 12192000  # 13.333 in — 16:9
SLIDE_H_EMU = 6858000  # 7.5 in


def render_theme_preview(theme: "Theme", out_path: Path) -> None:
    """Build and save the 3-slide preview deck for `theme`.

    `slide`-typed params below are annotated `Any` because python-pptx
    ships without type stubs; mypy's strict mode runs against `pptxforge`
    only, so leaking `Any` here is contained.
    """
    prs = Presentation()
    prs.slide_width = Emu(SLIDE_W_EMU)
    prs.slide_height = Emu(SLIDE_H_EMU)

    blank = prs.slide_layouts[6]

    _render_title_slide(prs.slides.add_slide(blank), theme)
    _render_content_slide(prs.slides.add_slide(blank), theme)
    _render_accent_slide(prs.slides.add_slide(blank), theme)

    prs.save(str(out_path))


# ---------------------------------------------------------------------------
# Helpers — slide/shape/run are python-pptx types which arrive as Any.
# ---------------------------------------------------------------------------


def _rgb(token: "ColorToken") -> Any:
    return RGBColor(*token.rgb)  # type: ignore[no-untyped-call]


def _set_slide_bg(slide: Any, token: "ColorToken") -> None:
    fill = slide.background.fill
    fill.solid()
    fill.fore_color.rgb = _rgb(token)


def _fill_rect(
    slide: Any,
    *,
    x: int,
    y: int,
    w: int,
    h: int,
    color: "ColorToken",
    line: "ColorToken | None" = None,
) -> Any:
    shape = slide.shapes.add_shape(MSO_SHAPE.RECTANGLE, Emu(x), Emu(y), Emu(w), Emu(h))
    shape.fill.solid()
    shape.fill.fore_color.rgb = _rgb(color)
    if line is None:
        shape.line.fill.background()
    else:
        shape.line.color.rgb = _rgb(line)
    shape.shadow.inherit = False
    return shape


def _apply_font(
    run: Any,
    stack: "FontStack",
    *,
    size_pt: float,
    color: "ColorToken",
    bold: bool = False,
    italic: bool = False,
) -> None:
    font = run.font
    font.name = stack.primary
    font.size = Pt(size_pt)
    font.bold = bold
    font.italic = italic
    font.color.rgb = _rgb(color)


def _add_text(
    slide: Any,
    *,
    text: str,
    x: int,
    y: int,
    w: int,
    h: int,
    stack: "FontStack",
    size_pt: float,
    color: "ColorToken",
    bold: bool = False,
    italic: bool = False,
    align: Any = PP_ALIGN.LEFT,
    anchor: Any = MSO_ANCHOR.TOP,
) -> Any:
    box = slide.shapes.add_textbox(Emu(x), Emu(y), Emu(w), Emu(h))
    tf = box.text_frame
    tf.word_wrap = True
    tf.vertical_anchor = anchor
    tf.margin_left = Emu(0)
    tf.margin_right = Emu(0)
    tf.margin_top = Emu(0)
    tf.margin_bottom = Emu(0)
    p = tf.paragraphs[0]
    p.alignment = align
    run = p.add_run()
    run.text = text
    _apply_font(run, stack, size_pt=size_pt, color=color, bold=bold, italic=italic)
    return box


# ---------------------------------------------------------------------------
# Slide renderers
# ---------------------------------------------------------------------------


def _render_title_slide(slide: Any, theme: "Theme") -> None:
    pal = theme.palette
    _set_slide_bg(slide, pal.background_light)

    # Accent rule — thin bar on the left.
    _fill_rect(
        slide,
        x=914400,
        y=1828800,
        w=76200,
        h=3200400,  # 1" × 3.5" at (1", 2")
        color=pal.accent,
    )

    # Theme name (hero)
    _add_text(
        slide,
        text=theme.name,
        x=1219200,
        y=1828800,
        w=9144000,
        h=914400,
        stack=theme.typography.display,
        size_pt=theme.type_scale.hero.size_pt,
        color=pal.primary,
        bold=True,
    )

    # Description (lead)
    _add_text(
        slide,
        text=theme.description,
        x=1219200,
        y=2844800,
        w=9144000,
        h=2133600,
        stack=theme.typography.body,
        size_pt=theme.type_scale.lead.size_pt,
        color=pal.text_primary,
    )

    # Footer — typography pair identifier
    _add_text(
        slide,
        text=f"{theme.typography.name}  •  {theme.typography.display.primary} / {theme.typography.body.primary}",
        x=914400,
        y=6172200,
        w=10363200,
        h=381000,
        stack=theme.typography.body,
        size_pt=theme.type_scale.caption.size_pt,
        color=pal.text_muted,
    )


def _render_content_slide(slide: Any, theme: "Theme") -> None:
    pal = theme.palette
    ts = theme.type_scale
    _set_slide_bg(slide, pal.background_light)

    # h1 title
    _add_text(
        slide,
        text="Every token, one slide",
        x=914400,
        y=609600,
        w=10363200,
        h=685800,
        stack=theme.typography.display,
        size_pt=ts.h1.size_pt,
        color=pal.primary,
        bold=True,
    )

    # divider hairline
    _fill_rect(
        slide,
        x=914400,
        y=1371600,
        w=10363200,
        h=12700,  # 1pt rule
        color=pal.divider,
    )

    # h2 subheading
    _add_text(
        slide,
        text="Section heading",
        x=914400,
        y=1524000,
        w=6096000,
        h=457200,
        stack=theme.typography.display,
        size_pt=ts.h2.size_pt,
        color=pal.secondary,
        bold=True,
    )

    # body paragraph
    body_text = (
        "Body copy in text_primary on background_light. "
        "Muted asides land in text_muted. "
        "The accent color carries the one emphasis per slide."
    )
    _add_text(
        slide,
        text=body_text,
        x=914400,
        y=2057400,
        w=6096000,
        h=1371600,
        stack=theme.typography.body,
        size_pt=ts.body.size_pt,
        color=pal.text_primary,
    )

    # caption (muted)
    _add_text(
        slide,
        text="— caption text, text_muted",
        x=914400,
        y=3505200,
        w=6096000,
        h=381000,
        stack=theme.typography.body,
        size_pt=ts.caption.size_pt,
        color=pal.text_muted,
        italic=True,
    )

    # Surface card on the right
    card_x, card_y = 7315200, 1524000
    card_w, card_h = 4267200, 3962400
    _fill_rect(
        slide,
        x=card_x,
        y=card_y,
        w=card_w,
        h=card_h,
        color=pal.surface,
    )
    # Accent bar inside the card
    _fill_rect(
        slide,
        x=card_x + 228600,
        y=card_y + 228600,
        w=76200,
        h=457200,
        color=pal.accent,
    )
    _add_text(
        slide,
        text="Surface card",
        x=card_x + 457200,
        y=card_y + 228600,
        w=card_w - 457200 - 228600,
        h=457200,
        stack=theme.typography.display,
        size_pt=ts.lead.size_pt,
        color=pal.text_primary,
        bold=True,
    )
    _add_text(
        slide,
        text="Elevated surface uses the surface token. Divider rules use divider.",
        x=card_x + 228600,
        y=card_y + 838200,
        w=card_w - 457200,
        h=1524000,
        stack=theme.typography.body,
        size_pt=ts.body.size_pt,
        color=pal.text_primary,
    )

    # Footer: lead-size callout in accent
    _add_text(
        slide,
        text="Accent is for emphasis — one per slide.",
        x=914400,
        y=5943600,
        w=10363200,
        h=609600,
        stack=theme.typography.body,
        size_pt=ts.lead.size_pt,
        color=pal.accent,
        bold=True,
    )


def _render_accent_slide(slide: Any, theme: "Theme") -> None:
    pal = theme.palette
    ts = theme.type_scale
    _set_slide_bg(slide, pal.background_dark)

    # Massive accent numeral as a visual anchor
    _add_text(
        slide,
        text="01",
        x=914400,
        y=1143000,
        w=3657600,
        h=3657600,
        stack=theme.typography.display,
        size_pt=ts.hero.size_pt * 2,  # 96pt-ish
        color=pal.accent,
        bold=True,
    )

    # Title reversed out in white/very-light
    _add_text(
        slide,
        text=theme.name,
        x=4800600,
        y=1828800,
        w=6400800,
        h=914400,
        stack=theme.typography.display,
        size_pt=ts.h1.size_pt,
        color=pal.background_light,
        bold=True,
    )

    # Secondary-color tagline
    _add_text(
        slide,
        text="Accent + background_dark preview",
        x=4800600,
        y=2895600,
        w=6400800,
        h=609600,
        stack=theme.typography.body,
        size_pt=ts.lead.size_pt,
        color=pal.secondary,
    )

    # Accent bar bottom
    _fill_rect(
        slide,
        x=914400,
        y=6172200,
        w=76200,
        h=228600,
        color=pal.accent,
    )
    _add_text(
        slide,
        text=f"{pal.primary.value}  {pal.secondary.value}  {pal.accent.value}",
        x=1143000,
        y=6172200,
        w=10058400,
        h=228600,
        stack=theme.typography.mono,
        size_pt=ts.caption.size_pt,
        color=pal.background_light,
    )
