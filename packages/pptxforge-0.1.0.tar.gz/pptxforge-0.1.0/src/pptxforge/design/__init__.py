"""Design primitives — tokens, typography, themes.

Public surface:

- `ColorToken`, `SpacingToken`, `TypographyToken`, `RadiusToken` — the four
  pydantic token models that slides and layouts consume.
- `FontStack`, `TypographyPair` — font-stack primitives and the six named
  font pairings.
- `Theme`, `Palette`, `TypeScale`, `SpacingScale`, `Radii` — the typed
  scales + the Theme dataclass that holds them.
- `themes` — the ten module-level built-in palettes.
"""

from pptxforge.design import themes
from pptxforge.design.themes import Palette, Radii, SpacingScale, Theme, TypeScale
from pptxforge.design.tokens import (
    ColorToken,
    RadiusToken,
    SpacingToken,
    TypographyToken,
)
from pptxforge.design.typography import FontStack, TypographyPair

__all__ = [
    # Tokens
    "ColorToken",
    "SpacingToken",
    "TypographyToken",
    "RadiusToken",
    # Typography
    "FontStack",
    "TypographyPair",
    # Theme + scales
    "Theme",
    "Palette",
    "TypeScale",
    "SpacingScale",
    "Radii",
    # Namespace of built-ins
    "themes",
]
