"""Entrance / Emphasis / Exit preset-ID catalog.

UNVERIFIED pending empirical capture — see research/embedded-3d.md §5.2.
"""

from typing import TypedDict


class PresetTriple(TypedDict):
    preset_id: int
    preset_class: str
    preset_subtype: int
