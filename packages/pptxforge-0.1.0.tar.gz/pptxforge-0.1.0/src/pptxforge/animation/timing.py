"""`<p:timing>` tree builder."""

from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from lxml import etree


def build_timing_tree(
    *,
    shape_id: int,
    attribute_name: str,
    duration_ms: int,
    loop: bool,
) -> "etree._Element":
    """Build a minimal `<p:timing>` tree that drives one attribute on one
    shape from 0 → 1 over `duration_ms` milliseconds.

    This is the carrier used for GLB-embedded 3D animation (`attribute_name
    = "embedded1"`) per research/embedded-3d.md §5.1.
    """
    raise NotImplementedError
