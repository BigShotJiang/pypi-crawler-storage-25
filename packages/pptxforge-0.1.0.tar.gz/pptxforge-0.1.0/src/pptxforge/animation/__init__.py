"""Animation timing-tree builders and preset IDs."""
