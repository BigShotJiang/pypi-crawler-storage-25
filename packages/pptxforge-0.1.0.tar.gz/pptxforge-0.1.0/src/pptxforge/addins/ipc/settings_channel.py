"""TypeScript snippets emitted into add-in templates implementing the
`Office.context.document.settings` channel. See `research/office-addins.md`
§4 for the IPC model.
"""


def emit_ts_client_helpers() -> str:
    """Return the TypeScript source of the client-side settings-channel
    helpers that get written into each scaffolded add-in template.
    """
    raise NotImplementedError
