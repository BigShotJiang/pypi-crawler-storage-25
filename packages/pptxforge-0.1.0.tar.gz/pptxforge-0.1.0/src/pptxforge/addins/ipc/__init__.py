"""IPC between content add-ins and the task pane.

See `DECISIONS.md` 2026-04-20 for why the channel is
`Office.context.document.settings`.
"""
