"""Built-in content-add-in components."""

from pptxforge.addins.components._base import AddInComponent
from pptxforge.addins.components.code_runner.component import CodeRunner
from pptxforge.addins.components.kiosk_webview.component import KioskWebview
from pptxforge.addins.components.map_viewer.component import MapViewer
from pptxforge.addins.components.molecule_viewer.component import MoleculeViewer
from pptxforge.addins.components.presenter_console.component import PresenterConsole
from pptxforge.addins.components.spreadsheet_preview.component import SpreadsheetPreview

__all__ = [
    "AddInComponent",
    "MoleculeViewer",
    "SpreadsheetPreview",
    "MapViewer",
    "CodeRunner",
    "KioskWebview",
    "PresenterConsole",
]
