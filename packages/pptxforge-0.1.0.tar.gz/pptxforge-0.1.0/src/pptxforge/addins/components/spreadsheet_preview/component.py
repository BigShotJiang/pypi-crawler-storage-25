"""SpreadsheetPreview: live CSV/XLSX view."""

from typing import Literal

from pptxforge.addins.components._base import AddInComponent


class SpreadsheetPreview(AddInComponent):
    """Live read-only view of a CSV/XLSX fetched from a URL. Refreshes
    on slide enter.

    Example:
        >>> SpreadsheetPreview(source_url="https://example.com/metrics.csv")
    """

    def __init__(
        self,
        *,
        source_url: str,
        max_rows: int = 100,
        format: Literal["csv", "xlsx", "tsv"] = "csv",
    ) -> None:
        raise NotImplementedError
