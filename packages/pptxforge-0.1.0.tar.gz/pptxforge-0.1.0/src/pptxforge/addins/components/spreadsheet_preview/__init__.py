"""SpreadsheetPreview content-add-in component."""

from pptxforge.addins.components.spreadsheet_preview.component import SpreadsheetPreview

__all__ = ["SpreadsheetPreview"]
