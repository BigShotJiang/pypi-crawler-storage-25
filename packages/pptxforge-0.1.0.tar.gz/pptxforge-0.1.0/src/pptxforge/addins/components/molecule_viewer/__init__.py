"""MoleculeViewer content-add-in component."""

from pptxforge.addins.components.molecule_viewer.component import MoleculeViewer

__all__ = ["MoleculeViewer"]
