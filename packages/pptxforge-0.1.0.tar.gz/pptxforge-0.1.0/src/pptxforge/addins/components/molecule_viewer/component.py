"""MoleculeViewer: 3D molecule renderer (3Dmol.js) in a content add-in."""

from typing import Literal

from pptxforge.addins.components._base import AddInComponent


class MoleculeViewer(AddInComponent):
    """3D molecule renderer (3Dmol.js under the hood). Accepts SMILES,
    InChI, or an explicit PDB string.

    Example:
        >>> MoleculeViewer(smiles="CC(=O)OC1=CC=CC=C1C(=O)O")  # aspirin
    """

    def __init__(
        self,
        *,
        smiles: str | None = None,
        inchi: str | None = None,
        pdb: str | None = None,
        style: Literal["stick", "ball-and-stick", "cartoon", "surface"] = "ball-and-stick",
        rotate_on_load: bool = True,
    ) -> None:
        raise NotImplementedError
