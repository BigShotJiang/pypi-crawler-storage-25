"""`AddInComponent` — the abstract base class for a scaffoldable Office content add-in.

Phase 8 promotes this from a thin dataclass stub to a proper ABC. A
subclass declares what files to copy (`template_dir`), what props it
accepts (`props_model`, a pydantic `BaseModel`), what Office.js
permissions to request, what extra assets to include, and an optional
`init_code` string to inject into the add-in's `index.html`.

Each instance stores concrete `props` values; the scaffolder walks all
slides that reference instances, dedupes by `(component_id, props)`
hash, and emits one Vite+TS project per unique instance under
`out/addins/<component_id>-<hash>/`.

Later prompts ship concrete subclasses (MoleculeViewer, etc.). End users
can always subclass `AddInComponent` in their own code for a custom
surface — the scaffolder doesn't care where the subclass lives.
"""

import hashlib
import json
from abc import ABC
from pathlib import Path
from typing import Any, ClassVar, Literal

from pydantic import BaseModel

# Default location of the shared Vite+TS template bundled with pptxforge.
# Subclasses that don't override `template_dir` fall back to this.
_SHARED_TEMPLATE_DIR = Path(__file__).resolve().parents[1] / "_templates" / "shared"


_Permission = Literal["Restricted", "ReadDocument", "ReadAllDocument", "ReadWriteDocument"]


class _EmptyProps(BaseModel):
    """Default props model for subclasses that don't declare their own."""

    pass


class AddInComponent(ABC):  # noqa: B024 — intentionally abstract via runtime check
    # Marked ABC to make subclass intent explicit. We enforce abstractness at
    # runtime (`__init__` rejects when `component_id` is empty) rather than
    # via `@abstractmethod`, because subclasses declare ClassVars rather than
    # override methods — B024 doesn't fit the shape.
    """Abstract base for a scaffoldable Office content-add-in component.

    Subclasses declare (as ClassVars):

    - `component_id` — stable short slug. Part of the output-directory
      name. Required; no default.
    - `props_model` — pydantic `BaseModel` subclass describing the
      props this component accepts. Defaults to `_EmptyProps` for
      components that have no user-facing props.
    - `template_dir` — directory to copy for the Vite+TS scaffold.
      Defaults to the bundled shared template (a minimal "Hello from
      <component_id>" surface).
    - `required_permissions` — list of Office.js permission strings.
      Flows into the generated manifest's `<Permissions>` when callers
      pair the component with a `ContentAddIn`.
    - `static_assets` — list of extra file paths to copy into
      `<outdir>/src/public/`. Typical use: icons, lookup tables,
      pre-baked model files.
    - `init_code` — JS string inlined near the top of the add-in's
      `index.html`. Executes before `main.ts`.

    The instance layer stores only one attribute: `props`, a validated
    `props_model` instance. The instance_hash is derived from the
    component_id + the serialized props; two constructions with
    identical props produce the same hash and share one scaffolded
    directory.

    Example:
        >>> from pydantic import BaseModel
        >>> class HeroProps(BaseModel):
        ...     headline: str = "Hello"
        >>> class HeroComponent(AddInComponent):
        ...     component_id = "hero"
        ...     props_model = HeroProps
        ...     required_permissions = ["ReadDocument"]
        >>> HeroComponent(headline="Q1 launch").instance_hash()
        ...                                             # 10-hex-char digest
    """

    # --- ClassVars subclasses declare ---------------------------------------

    component_id: ClassVar[str] = ""
    """Stable short slug — part of the output directory name. Required."""

    props_model: ClassVar[type[BaseModel]] = _EmptyProps
    """Pydantic BaseModel subclass describing the props this component accepts."""

    template_dir: ClassVar[Path] = _SHARED_TEMPLATE_DIR
    """Directory whose contents are copied into the scaffolded project."""

    required_permissions: ClassVar[tuple[_Permission, ...]] = ("ReadDocument",)
    """Office.js permissions this component requires to function."""

    static_assets: ClassVar[tuple[Path, ...]] = ()
    """Extra files copied into `<outdir>/src/public/` alongside the template."""

    init_code: ClassVar[str] = ""
    """Optional JS inlined at the top of index.html, before main.ts."""

    # --- construction -------------------------------------------------------

    def __init__(self, **props_kwargs: Any) -> None:
        if not self.component_id:
            raise TypeError(
                f"{type(self).__name__} must declare a non-empty `component_id`. "
                "See AddInComponent docstring."
            )
        self.props: BaseModel = self.props_model(**props_kwargs)

    # --- identity -----------------------------------------------------------

    def instance_hash(self) -> str:
        """Stable 10-hex-char hash of (component_id + serialized props).

        Two instances with identical props produce the same hash — the
        scaffolder dedupes on this. The hash is intentionally short
        (40 bits) for readable directory names; collisions across
        unrelated components are impossible because the hash input
        prefixes `component_id`.

        Deterministic across runs because props are serialized with
        `sort_keys=True` and `default=str` (for UUIDs / Paths / etc.).
        """
        payload = self._canonical_payload()
        digest = hashlib.blake2b(payload.encode("utf-8"), digest_size=5)
        return digest.hexdigest()

    def _canonical_payload(self) -> str:
        """Stable JSON payload hashed into the instance_hash."""
        props_dict = self.props.model_dump(mode="json")
        return json.dumps(
            {"component_id": self.component_id, "props": props_dict},
            sort_keys=True,
            separators=(",", ":"),
            default=str,
        )

    @property
    def output_dir_name(self) -> str:
        """`<component_id>-<hash>` — the per-instance directory basename.

        This is the path segment under `out/addins/` where the
        scaffolder lands the Vite project.
        """
        return f"{self.component_id}-{self.instance_hash()}"


__all__ = ["AddInComponent"]
