"""MapViewer content-add-in component."""

from pptxforge.addins.components.map_viewer.component import MapViewer

__all__ = ["MapViewer"]
