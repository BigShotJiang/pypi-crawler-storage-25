"""MapViewer: Leaflet-based interactive map."""

from pathlib import Path
from typing import Literal

from pptxforge.addins.components._base import AddInComponent


class MapViewer(AddInComponent):
    """Interactive map (Leaflet). Accepts a center+zoom, optional GeoJSON
    overlay, optional clustered markers.

    Example:
        >>> MapViewer(center=(37.7749, -122.4194), zoom=11)
    """

    def __init__(
        self,
        *,
        center: tuple[float, float],
        zoom: int = 10,
        geojson: Path | None = None,
        tiles: Literal["osm", "carto-light", "carto-dark"] = "carto-light",
    ) -> None:
        raise NotImplementedError
