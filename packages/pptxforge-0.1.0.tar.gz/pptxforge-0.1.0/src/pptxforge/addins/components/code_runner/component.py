"""CodeRunner: sandboxed Python/JavaScript evaluator."""

from typing import Literal

from pptxforge.addins.components._base import AddInComponent


class CodeRunner(AddInComponent):
    """Editable code block that runs in a sandboxed iframe (Pyodide for
    Python, QuickJS for JS). Writes stdout back into the slide via
    settings IPC so the task pane can mirror output.

    Example:
        >>> CodeRunner(language="python", source="print(2+2)")
    """

    def __init__(
        self,
        *,
        language: Literal["python", "javascript"],
        source: str,
        autorun: bool = False,
        max_runtime_ms: int = 5000,
    ) -> None:
        raise NotImplementedError
