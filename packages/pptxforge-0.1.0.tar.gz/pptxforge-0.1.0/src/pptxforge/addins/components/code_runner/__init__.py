"""CodeRunner content-add-in component."""

from pptxforge.addins.components.code_runner.component import CodeRunner

__all__ = ["CodeRunner"]
