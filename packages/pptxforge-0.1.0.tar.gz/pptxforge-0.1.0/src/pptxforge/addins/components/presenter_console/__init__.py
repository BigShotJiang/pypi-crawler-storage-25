"""PresenterConsole content-add-in component."""

from pptxforge.addins.components.presenter_console.component import PresenterConsole

__all__ = ["PresenterConsole"]
