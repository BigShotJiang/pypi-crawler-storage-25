"""PresenterConsole: mirrors TaskPane state onto a slide region."""

from pptxforge.addins.components._base import AddInComponent


class PresenterConsole(AddInComponent):
    """A content add-in that mirrors TaskPane state onto a slide region —
    useful for recording a walkthrough where the presenter's controls
    should appear in-frame.

    Example:
        >>> PresenterConsole(show_timer=True, show_next_slide=True)
    """

    def __init__(
        self,
        *,
        show_timer: bool = True,
        show_next_slide: bool = False,
        show_notes: bool = True,
    ) -> None:
        raise NotImplementedError
