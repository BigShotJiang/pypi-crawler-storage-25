"""KioskWebview content-add-in component."""

from pptxforge.addins.components.kiosk_webview.component import KioskWebview

__all__ = ["KioskWebview"]
