"""KioskWebview: arbitrary URL in a webview."""

from pptxforge.addins.components._base import AddInComponent


class KioskWebview(AddInComponent):
    """Arbitrary URL in a webview. The escape hatch for anything the
    catalog doesn't cover. Warns loudly if the URL is http:// (add-in
    webviews demand https).

    Example:
        >>> KioskWebview(url="https://dashboard.internal.example.com/")
    """

    def __init__(
        self,
        *,
        url: str,
        allow_navigation: bool = False,
    ) -> None:
        raise NotImplementedError
