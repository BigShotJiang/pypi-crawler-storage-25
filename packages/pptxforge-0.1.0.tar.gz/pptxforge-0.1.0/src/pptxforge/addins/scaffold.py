"""Scaffold `AddInComponent` instances into deployable Vite+TS projects.

Public surface:

- `scaffold_component(component, out_dir, *, build=True, reuse=True)`
  — one component → `out_dir/addins/<component.output_dir_name>/src/`
  (plus `dist/` when built). Returns the path created. Idempotent: a
  second call with an identical instance_hash returns the existing
  path and skips work.
- `scaffold_all(components, out_dir, ...)` — takes an iterable of
  components, dedupes by `instance_hash`, scaffolds each unique one.
- `render_deploy_readme_section(components)` — markdown that
  `Deck.save()` splices into `out/README.md`.
- `ScaffoldError` / `NpmBuildError` — specific exceptions so the caller
  can distinguish "npm missing" from "build failed".
"""

from __future__ import annotations

import json
import shutil
import subprocess
import sys
from collections.abc import Iterable
from dataclasses import dataclass
from pathlib import Path

from pptxforge.addins.components._base import AddInComponent

# ---------------------------------------------------------------------------
# Exceptions
# ---------------------------------------------------------------------------


class ScaffoldError(RuntimeError):
    """Raised when the scaffolder can't produce a usable project."""


class NpmBuildError(ScaffoldError):
    """Raised when `npm install` or `npm run build` fails.

    Attributes:
        step: "install" or "build".
        returncode: subprocess exit code.
        stdout / stderr: captured output.
    """

    def __init__(self, *, step: str, returncode: int, stdout: str, stderr: str, cwd: Path) -> None:
        self.step = step
        self.returncode = returncode
        self.stdout = stdout
        self.stderr = stderr
        self.cwd = cwd
        preview = (stderr or stdout or "").strip().splitlines()[-5:]
        super().__init__(
            f"npm {step} failed with exit {returncode} in {cwd}. "
            f"Last lines:\n  " + "\n  ".join(preview)
        )


# ---------------------------------------------------------------------------
# Public API
# ---------------------------------------------------------------------------


@dataclass(frozen=True, slots=True)
class ScaffoldResult:
    """What `scaffold_component` returns: paths + whether anything was built."""

    component_id: str
    instance_hash: str
    project_dir: Path
    src_dir: Path
    dist_dir: Path | None  # None when build=False
    reused: bool  # True when an existing scaffold was found and reused


def scaffold_component(
    component: AddInComponent,
    out_dir: Path | str,
    *,
    build: bool = True,
    reuse: bool = True,
    npm: str | None = None,
) -> ScaffoldResult:
    """Scaffold `component` into `out_dir/addins/<instance-dir>/`.

    Steps:

    1. Compute `out_dir/addins/<component.output_dir_name>/`.
    2. If the directory exists AND `reuse=True`, return it without
       rebuilding. This is the dedup path — two slides with the same
       `(component_id, props)` share one scaffolded project.
    3. Copy `component.template_dir` → `<projdir>/src/` (or direct
       children when the template is already a project root).
    4. Copy any `static_assets` to `<projdir>/src/public/`.
    5. Render `<projdir>/props.json` from `component.props` + metadata.
    6. If `build=True`: run `npm install` then `npm run build` via
       subprocess. Move the resulting `<projdir>/dist/` up one level
       so the final layout is:

           <projdir>/
             ├── src/            (the Vite project source)
             ├── props.json
             └── dist/           (static-host-ready build output)
    """
    out_root = Path(out_dir).resolve()
    project_dir = out_root / "addins" / component.output_dir_name
    # The template IS the Vite project root: config files at `project_dir/`
    # and sources under `project_dir/src/` (Vite's convention). `dist/`
    # lands at the project root after `npm run build`.
    src_dir = project_dir / "src"
    dist_dir = project_dir / "dist"

    if project_dir.is_dir() and reuse:
        return ScaffoldResult(
            component_id=component.component_id,
            instance_hash=component.instance_hash(),
            project_dir=project_dir,
            src_dir=src_dir,
            dist_dir=dist_dir if dist_dir.is_dir() else None,
            reused=True,
        )

    # Fresh scaffold: wipe any partial prior state to keep the build clean.
    if project_dir.exists():
        shutil.rmtree(project_dir)
    project_dir.parent.mkdir(parents=True, exist_ok=True)

    # --- 1. Copy the template as the project root ------------------------
    tpl = component.template_dir
    if not tpl.is_dir():
        raise ScaffoldError(f"{type(component).__name__}.template_dir does not exist: {tpl}")
    shutil.copytree(tpl, project_dir)

    # --- 2. Copy static assets -------------------------------------------
    if component.static_assets:
        public_dir = project_dir / "public"
        public_dir.mkdir(exist_ok=True)
        for asset in component.static_assets:
            asset_path = Path(asset)
            if not asset_path.is_file():
                raise ScaffoldError(
                    f"static asset missing: {asset_path} (referenced by {type(component).__name__})"
                )
            shutil.copy2(asset_path, public_dir / asset_path.name)

    # --- 3. Render props.json --------------------------------------------
    props_payload = {
        "component_id": component.component_id,
        "instance_hash": component.instance_hash(),
        **component.props.model_dump(mode="json"),
    }
    props_json_bytes = json.dumps(props_payload, indent=2, sort_keys=True, default=str)
    # At the project root for humans/deploy pipelines to inspect…
    (project_dir / "props.json").write_text(props_json_bytes, encoding="utf-8")
    # …and inside src/ so main.ts can `import props from "./props.json"`.
    (src_dir / "props.json").write_text(props_json_bytes, encoding="utf-8")

    # --- 4. Inject init_code if supplied ---------------------------------
    if component.init_code:
        _inject_init_code(project_dir / "index.html", component.init_code)

    # --- 5. npm install + build ------------------------------------------
    if build:
        _npm_install_and_build(project_dir, npm_binary=npm)
        built_dist = project_dir / "dist"
        if not built_dist.is_dir():
            raise ScaffoldError(f"vite build did not produce {built_dist}; something went wrong.")

    return ScaffoldResult(
        component_id=component.component_id,
        instance_hash=component.instance_hash(),
        project_dir=project_dir,
        src_dir=src_dir,
        dist_dir=dist_dir if build else None,
        reused=False,
    )


def scaffold_all(
    components: Iterable[AddInComponent],
    out_dir: Path | str,
    *,
    build: bool = True,
    reuse: bool = True,
    npm: str | None = None,
) -> list[ScaffoldResult]:
    """Scaffold every component, dedupe by instance_hash.

    Order preserved: the returned list matches the order of first-seen
    components in the input iterable. Duplicates (same component_id +
    same props) produce a single entry.
    """
    seen: dict[str, ScaffoldResult] = {}
    out_list: list[ScaffoldResult] = []
    for comp in components:
        key = f"{comp.component_id}::{comp.instance_hash()}"
        if key in seen:
            continue
        result = scaffold_component(comp, out_dir, build=build, reuse=reuse, npm=npm)
        seen[key] = result
        out_list.append(result)
    return out_list


# ---------------------------------------------------------------------------
# README generation
# ---------------------------------------------------------------------------


def render_deploy_readme_section(components: Iterable[AddInComponent]) -> str:
    """Return a markdown section for `out/README.md` covering hosting + sideload.

    Lists each scaffolded add-in, shows the directory layout, and walks
    through the three standard deployment paths (local dev server,
    Cloudflare Pages, Vercel). Also explains how to sideload the
    `manifest.*.xml` generated in Phase 7.

    `Deck.save()` calls this and splices it into the deck's README.
    """
    component_list = list(components)
    lines: list[str] = [
        "## Deploying the add-in web bundles",
        "",
    ]
    if not component_list:
        lines.append("_No content add-ins in this deck._")
        lines.append("")
        return "\n".join(lines)

    lines.extend(
        [
            "This deck uses live content add-ins. Each one was scaffolded as a",
            "Vite + TypeScript project under `addins/<component-id>-<hash>/`:",
            "",
        ]
    )
    for c in component_list:
        lines.append(f"- `addins/{c.output_dir_name}/` — `{c.component_id}`")
    lines.extend(
        [
            "",
            "Per-project layout:",
            "",
            "```",
            "addins/<component-id>-<hash>/",
            "├── src/            # Vite + TypeScript source — edit here",
            "│   ├── index.html",
            "│   ├── main.ts",
            "│   ├── postmessage.ts",
            "│   └── theme.css",
            "├── props.json      # runtime settings rendered by pptxforge",
            "└── dist/           # built output (only when build=True)",
            "```",
            "",
            "### Step 1 — Host `dist/` over HTTPS",
            "",
            "Office.js refuses to load the add-in over plain HTTP.",
            "Pick one:",
            "",
            "- **Local dev** (mkcert + Vite):",
            "  ```bash",
            "  cd addins/<component-id>-<hash>/src",
            "  npm run dev  # Vite dev server on https://localhost:3000/",
            "  ```",
            "  Update the manifest's `SourceLocation` to `https://localhost:3000/index.html`.",
            "",
            "- **Cloudflare Pages** (zero-config static host):",
            "  ```bash",
            "  cd addins/<component-id>-<hash>",
            "  npx wrangler pages deploy dist",
            "  ```",
            "  Point the manifest's `SourceLocation` at the deployed URL.",
            "",
            "- **Vercel**:",
            "  ```bash",
            "  cd addins/<component-id>-<hash>",
            "  vercel --prod dist",
            "  ```",
            "",
            "### Step 2 — Sideload the manifest",
            "",
            "- **Windows (network share)**: copy `manifest.content.xml` "
            "(and `manifest.taskpane.xml` if present) into a folder on a "
            "shared drive. In PowerPoint: `File → Options → Trust Center → "
            "Trust Center Settings → Trusted Add-in Catalogs`, add the "
            "folder, restart PowerPoint, then `Insert → Add-ins → Shared "
            "Folder`.",
            "",
            "- **Mac / Web**: upload the manifest via the Microsoft 365 "
            "admin center under `Integrated apps → Upload custom apps`.",
            "",
            "See research/office-addins.md §1 in the pptxforge repo for "
            "full sideload documentation.",
            "",
        ]
    )
    return "\n".join(lines)


# ---------------------------------------------------------------------------
# Internals
# ---------------------------------------------------------------------------


def _inject_init_code(html_path: Path, init_code: str) -> None:
    """Inline `init_code` in a <script> tag inside `<head>` of index.html."""
    if not html_path.is_file():
        raise ScaffoldError(f"cannot inject init_code: {html_path} does not exist")
    html = html_path.read_text(encoding="utf-8")
    # Very small surgery — insert right before </head>. Avoids a full HTML
    # parser on the hot path.
    marker = "</head>"
    idx = html.lower().find(marker)
    if idx < 0:
        raise ScaffoldError(f"cannot inject init_code: {html_path} has no </head> tag")
    snippet = f"\n    <script>\n/* pptxforge init_code */\n{init_code}\n    </script>\n  "
    new_html = html[:idx] + snippet + html[idx:]
    html_path.write_text(new_html, encoding="utf-8")


def _find_npm(npm_binary: str | None) -> str:
    """Locate the `npm` executable or raise."""
    if npm_binary is not None:
        if not Path(npm_binary).is_file():
            raise NpmBuildError(
                step="install",
                returncode=-1,
                stdout="",
                stderr=f"npm binary not found at {npm_binary}",
                cwd=Path.cwd(),
            )
        return npm_binary
    # shutil.which handles Windows `.cmd` wrappers.
    found = shutil.which("npm")
    if found is None and sys.platform == "win32":
        # Fallback: common npm locations.
        for candidate in (
            Path(sys.prefix) / "npm.cmd",
            Path("C:/Program Files/nodejs/npm.cmd"),
        ):
            if candidate.is_file():
                return str(candidate)
    if found is None:
        raise NpmBuildError(
            step="install",
            returncode=-1,
            stdout="",
            stderr=(
                "npm is not on $PATH. Install Node.js (https://nodejs.org) "
                "or pass `npm=...` to scaffold_component."
            ),
            cwd=Path.cwd(),
        )
    return found


def _npm_install_and_build(src_dir: Path, *, npm_binary: str | None) -> None:
    """Run `npm install` then `npm run build` in `src_dir`."""
    npm = _find_npm(npm_binary)

    install = subprocess.run(
        [npm, "install", "--no-audit", "--no-fund", "--loglevel=error"],
        cwd=str(src_dir),
        capture_output=True,
        text=True,
        encoding="utf-8",
        errors="replace",
        check=False,
        timeout=600,
    )
    if install.returncode != 0:
        raise NpmBuildError(
            step="install",
            returncode=install.returncode,
            stdout=install.stdout,
            stderr=install.stderr,
            cwd=src_dir,
        )

    build = subprocess.run(
        [npm, "run", "build"],
        cwd=str(src_dir),
        capture_output=True,
        text=True,
        encoding="utf-8",
        errors="replace",
        check=False,
        timeout=300,
    )
    if build.returncode != 0:
        raise NpmBuildError(
            step="build",
            returncode=build.returncode,
            stdout=build.stdout,
            stderr=build.stderr,
            cwd=src_dir,
        )


__all__ = [
    "AddInComponent",
    "ScaffoldResult",
    "ScaffoldError",
    "NpmBuildError",
    "scaffold_component",
    "scaffold_all",
    "render_deploy_readme_section",
]
