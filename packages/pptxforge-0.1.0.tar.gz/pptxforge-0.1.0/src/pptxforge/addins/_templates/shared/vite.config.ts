// Vite config for a pptxforge-scaffolded Office Add-in.
//
// The Office.js host refuses to load add-ins over plain HTTP, so the dev
// server must speak HTTPS. In production the built `dist/` lands on
// Cloudflare Pages / Vercel / a static HTTPS host (see out/README.md).

import { defineConfig } from "vite";

export default defineConfig({
  base: "./",
  build: {
    outDir: "dist",
    emptyOutDir: true,
    sourcemap: true,
    rollupOptions: {
      output: {
        // Predictable filenames so the manifest's SourceLocation can pin them.
        entryFileNames: "assets/[name].js",
        chunkFileNames: "assets/[name].js",
        assetFileNames: "assets/[name].[ext]",
      },
    },
  },
  server: {
    port: 3000,
    strictPort: true,
    // HTTPS handled externally (mkcert/caddy) — Office requires it in prod.
  },
});
