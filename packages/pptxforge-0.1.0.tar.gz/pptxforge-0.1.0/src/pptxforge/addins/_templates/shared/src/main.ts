// pptxforge add-in entry point.
//
// Waits for Office.onReady, loads props.json (written by the pptxforge
// scaffolder), renders a default "Hello from <component_id>" surface, and
// wires postMessage into/out of the host task pane. Subclasses overwrite
// the `render()` call's body in their own templates; this default exists
// so a freshly-scaffolded project builds and runs without edits.

import { postToParent, onMessageFromParent } from "./postmessage";
import props from "../props.json";

type Props = { component_id: string; instance_hash: string } & Record<string, unknown>;

function render(app: HTMLElement, props: Props): void {
  app.innerHTML = `
    <div class="pptxforge-card">
      <h1>Hello from <code>${escapeHtml(props.component_id)}</code></h1>
      <p class="pptxforge-muted">instance hash: <code>${escapeHtml(
        props.instance_hash,
      )}</code></p>
      <pre class="pptxforge-props">${escapeHtml(JSON.stringify(props, null, 2))}</pre>
    </div>
  `;
}

function escapeHtml(s: string): string {
  return s
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;")
    .replace(/"/g, "&quot;")
    .replace(/'/g, "&#39;");
}

// Office.onReady resolves whether or not we're actually inside Office —
// `info.host` is null when the add-in is served stand-alone (dev preview).
// We render in both cases so `npm run build` + a static host produces a
// visibly-working page for humans eyeballing the output.
Office.onReady((info) => {
  const app = document.getElementById("app");
  if (!app) {
    console.error("pptxforge: #app element missing from index.html");
    return;
  }
  render(app, props as Props);

  postToParent({
    kind: "pptxforge:ready",
    component_id: (props as Props).component_id,
    instance_hash: (props as Props).instance_hash,
    office_host: info.host ?? null,
    office_platform: info.platform ?? null,
  });
});

onMessageFromParent((msg) => {
  // Default behavior: log. Real components override this by swapping main.ts.
  console.log("pptxforge add-in received:", msg);
});
