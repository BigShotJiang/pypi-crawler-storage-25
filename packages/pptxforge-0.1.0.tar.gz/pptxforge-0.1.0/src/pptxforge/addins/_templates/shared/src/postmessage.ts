// postMessage helpers for the slide↔add-in channel.
//
// The task-pane and content add-ins live in separate iframes; the primary
// IPC channel pptxforge uses is `Office.context.document.settings` plus
// the `SettingsChanged` event (see DECISIONS.md 2026-04-20). This postMessage
// helper is the secondary channel used when both ends are in the same
// browser context (e.g. during local development against a mock parent
// page, or when one add-in opens another in an in-document dialog).

export function postToParent(message: unknown): void {
  if (window.parent !== window) {
    // targetOrigin "*" is intentional — Office iframes rotate origins and
    // pinning a specific one breaks on Mac/Web. Messages carry their own
    // `kind` discriminator that receivers check.
    window.parent.postMessage(message, "*");
  }
}

export type MessageHandler = (message: unknown) => void;

export function onMessageFromParent(handler: MessageHandler): () => void {
  const listener = (event: MessageEvent): void => handler(event.data);
  window.addEventListener("message", listener);
  return () => window.removeEventListener("message", listener);
}
