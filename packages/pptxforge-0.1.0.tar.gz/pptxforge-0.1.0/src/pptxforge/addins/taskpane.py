"""TaskPane — ribbon-hosted presenter-controls add-in.

Phase 7 promotes this from stub to a frozen dataclass. The fields here
map onto the `VersionOverrides` section of the task-pane manifest; see
research/office-addins.md §1.2 for the reference fixture.
"""

from dataclasses import dataclass
from pathlib import Path
from typing import Literal
from uuid import UUID


@dataclass(frozen=True, slots=True)
class TaskPane:
    """Defines a ribbon-hosted task-pane add-in for presenter controls.

    Every task-pane manifest needs: (a) a taskpane HTML URL
    (`source_url`), (b) a commands HTML URL (`commands_url`) that hosts
    the ribbon-button click handler, (c) three icon sizes (16/32/80px)
    for the ribbon button. The `entry` field (path to TS source)
    identifies the Vite scaffold on disk; the URL fields identify where
    the built output will be hosted after `npm run build` + deploy.

    One TaskPane per deck; pass to `Deck(task_pane=...)`.

    Example:
        >>> tp = TaskPane(
        ...     id=UUID("22222222-3333-4444-5555-666666666666"),
        ...     display_name="Acme Presenter",
        ...     provider="Acme Research",
        ...     entry=Path("./presenter/src/main.ts"),
        ...     source_url="https://addins.acme.com/taskpane.html",
        ...     commands_url="https://addins.acme.com/commands.html",
        ...     icon_16_url="https://addins.acme.com/icon-16.png",
        ...     icon_32_url="https://addins.acme.com/icon-32.png",
        ...     icon_80_url="https://addins.acme.com/icon-80.png",
        ... )
    """

    id: UUID
    display_name: str
    provider: str
    entry: Path
    source_url: str
    commands_url: str
    icon_16_url: str
    icon_32_url: str
    icon_80_url: str
    description: str = "A pptxforge-generated task-pane add-in."
    support_url: str | None = None
    learn_more_url: str | None = None
    template: Literal["vanilla", "react"] = "vanilla"
    ribbon_label: str = "Show Controls"
    ribbon_group_label: str = "pptxforge"
    ribbon_tip: str = "Open the presenter controls task pane."
    ribbon_icon: Path | None = None
    manifest_format: Literal["xml", "json", "both"] = "xml"
    permissions: Literal["Restricted", "ReadDocument", "ReadAllDocument", "ReadWriteDocument"] = (
        "ReadWriteDocument"
    )
    version: str = "1.0.0.0"
    default_locale: str = "en-US"
