"""Runs `npm ci && npm run build` per scaffolded component."""

from pathlib import Path


def build_component(component_dir: Path) -> None:
    """Run `npm ci` then `npm run build` in `component_dir`. Raises on
    non-zero exit.
    """
    raise NotImplementedError
