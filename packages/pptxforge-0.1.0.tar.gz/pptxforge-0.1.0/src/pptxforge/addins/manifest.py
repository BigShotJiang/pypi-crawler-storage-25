"""Office Add-in XML manifest generator.

Produces the XML manifests defined in research/office-addins.md §1 from
the `ContentAddIn` / `TaskPane` value objects in `pptxforge.addins`.

Public surface:

- `Manifest(apps)` — top-level container for one or more `OfficeApp`
  instances. A deck with one ContentAddIn produces a Manifest with one
  app; add a TaskPane and the Manifest carries two (each rendered to a
  separate file).
- `Manifest.from_components(components)` — build from a mixed list of
  ContentAddIn and TaskPane value objects.
- `Manifest.to_xml()` — serialize the SINGLE app as an XML string.
  Raises when the Manifest holds multiple apps; use `.to_files()` for
  that case.
- `Manifest.to_files()` — `{filename: xml}` for every app.
- `Manifest.validate()` — in-process validation (required fields, HTTPS,
  ID format, ID collisions) plus external `office-addin-manifest`
  integration when it's on `$PATH`.

The XML namespaces, xsi:type discriminators, and element order all match
research/_fixtures/manifest.*.xml byte-for-byte where the pydantic model
allows it.
"""

from __future__ import annotations

import re
import shutil
import subprocess
import tempfile
from dataclasses import dataclass
from pathlib import Path
from typing import Literal
from uuid import UUID

from lxml import etree
from pydantic import BaseModel, ConfigDict, Field, field_validator

from pptxforge.addins.content_addin import ContentAddIn
from pptxforge.addins.taskpane import TaskPane

# ---------------------------------------------------------------------------
# Namespaces + manifest constants
# ---------------------------------------------------------------------------

NS_OFFICEAPP = "http://schemas.microsoft.com/office/appforoffice/1.1"
NS_XSI = "http://www.w3.org/2001/XMLSchema-instance"
NS_BT = "http://schemas.microsoft.com/office/officeappbasictypes/1.0"
NS_OV = "http://schemas.microsoft.com/office/taskpaneappversionoverrides"

PermissionLevel = Literal["Restricted", "ReadDocument", "ReadAllDocument", "ReadWriteDocument"]

# Strict HTTPS pattern. Office Add-in manifests reject plain HTTP; pydantic's
# HttpUrl accepts both, so we validate in a custom regex.
_HTTPS_PATTERN = re.compile(r"^https://[^\s]+$")
# Office version strings: four dot-separated integers.
_VERSION_PATTERN = re.compile(r"^\d+\.\d+\.\d+\.\d+$")


# ---------------------------------------------------------------------------
# ValidationError — one issue surfaced by `.validate()`
# ---------------------------------------------------------------------------


@dataclass(frozen=True, slots=True)
class ValidationError:
    """A single manifest-validation issue.

    `code` is a stable machine-readable key (`"missing-icon"`,
    `"non-https-url"`, `"duplicate-id"`, `"invalid-uuid"`,
    `"external-validator-error"`, `"external-validator-unavailable"`,
    etc.).
    """

    severity: Literal["error", "warning"]
    code: str
    message: str
    path: str | None = None  # path to the field that caused the issue


# ---------------------------------------------------------------------------
# Model tree
# ---------------------------------------------------------------------------


class LocalizableString(BaseModel):
    """A manifest string with a default value + optional per-locale overrides.

    Emitted as `<Element DefaultValue="..."/>` with `<Override Locale="..."
    Value="..."/>` children for each locale override.
    """

    model_config = ConfigDict(frozen=True, strict=True)

    default_value: str = Field(min_length=1)
    overrides: dict[str, str] = Field(default_factory=dict)


class Host(BaseModel):
    """A `<Host Name="Presentation"/>` entry in `<Hosts>`."""

    model_config = ConfigDict(frozen=True, strict=True)

    name: Literal["Presentation"] = "Presentation"


class DefaultSettings(BaseModel):
    """`<DefaultSettings>` — the add-in's entry point.

    `requested_width` / `requested_height` are optional and only
    meaningful for ContentApp (content add-ins). TaskPaneApp ignores them.
    """

    model_config = ConfigDict(frozen=True, strict=True)

    source_location: str
    requested_width: int | None = None
    requested_height: int | None = None

    @field_validator("source_location")
    @classmethod
    def _https_only(cls, v: str) -> str:
        if not _HTTPS_PATTERN.fullmatch(v):
            raise ValueError(
                f"source_location must be an HTTPS URL; got {v!r}. "
                "Office refuses to load add-ins from http:// or non-URL values."
            )
        return v


class OfficeApp(BaseModel):
    """Shared `OfficeApp` fields between Content and Task-Pane manifests."""

    model_config = ConfigDict(frozen=True, strict=True)

    id: UUID
    version: str = "1.0.0.0"
    provider_name: str = Field(min_length=1)
    default_locale: str = "en-US"
    display_name: LocalizableString
    description: LocalizableString
    icon_url: str | None = None
    icon_url_hires: str | None = None
    support_url: str | None = None
    hosts: list[Host] = Field(default_factory=lambda: [Host()])
    default_settings: DefaultSettings
    permissions: PermissionLevel = "ReadWriteDocument"

    @field_validator("version")
    @classmethod
    def _version_format(cls, v: str) -> str:
        if not _VERSION_PATTERN.fullmatch(v):
            raise ValueError(
                f"version must be 4 dot-separated integers (e.g. '1.0.0.0'); got {v!r}"
            )
        return v

    @field_validator("default_locale")
    @classmethod
    def _locale_format(cls, v: str) -> str:
        # Very light check: "en-US", "fr-FR", etc.
        if not re.fullmatch(r"[a-z]{2,3}-[A-Z]{2}", v):
            raise ValueError(f"default_locale must be a BCP-47 tag like 'en-US'; got {v!r}")
        return v

    @field_validator("icon_url", "icon_url_hires", "support_url")
    @classmethod
    def _optional_https(cls, v: str | None) -> str | None:
        if v is None:
            return None
        if not _HTTPS_PATTERN.fullmatch(v):
            raise ValueError(f"must be an HTTPS URL; got {v!r}")
        return v


class ContentOfficeApp(OfficeApp):
    """A Content Office App — a slide-embedded webview.

    Emits `<OfficeApp xsi:type="ContentApp">`. Requires IconUrl,
    HighResolutionIconUrl, and SupportUrl per the office-addin-manifest
    validator (despite the XSD marking them optional).
    """

    xsi_type: Literal["ContentApp"] = "ContentApp"


class Resources(BaseModel):
    """`<Resources>` block inside `<VersionOverrides>` — referenced by `resid`."""

    model_config = ConfigDict(frozen=True, strict=True)

    images: dict[str, str] = Field(default_factory=dict)
    urls: dict[str, str] = Field(default_factory=dict)
    short_strings: dict[str, str] = Field(default_factory=dict)
    long_strings: dict[str, str] = Field(default_factory=dict)

    @field_validator("images", "urls")
    @classmethod
    def _resource_urls_https(cls, v: dict[str, str]) -> dict[str, str]:
        for rid, url in v.items():
            if not _HTTPS_PATTERN.fullmatch(url):
                raise ValueError(f"resource {rid!r} must be an HTTPS URL; got {url!r}")
        return v


class RibbonConfig(BaseModel):
    """Presentation-host ribbon configuration for a TaskPaneOfficeApp.

    Captures just enough of the `VersionOverrides/Hosts/Host/DesktopFormFactor`
    tree for a single ribbon button that opens one task pane. Anything
    beyond that lands in a later phase.
    """

    model_config = ConfigDict(frozen=True, strict=True)

    group_label: str = "pptxforge"
    button_label: str = "Show Controls"
    button_tip: str = "Open the presenter controls task pane."
    button_id: str = "pptxforgeOpen"
    group_id: str = "pptxforgeGroup"
    tab: str = "TabHome"  # built-in tab id
    taskpane_id: str = "Main"

    # Resources the ribbon references — all required.
    icon_16_url: str
    icon_32_url: str
    icon_80_url: str
    commands_url: str
    taskpane_url: str
    learn_more_url: str | None = None

    @field_validator(
        "icon_16_url",
        "icon_32_url",
        "icon_80_url",
        "commands_url",
        "taskpane_url",
    )
    @classmethod
    def _required_https(cls, v: str) -> str:
        if not _HTTPS_PATTERN.fullmatch(v):
            raise ValueError(f"must be an HTTPS URL; got {v!r}")
        return v

    @field_validator("learn_more_url")
    @classmethod
    def _optional_https(cls, v: str | None) -> str | None:
        if v is None:
            return None
        if not _HTTPS_PATTERN.fullmatch(v):
            raise ValueError(f"must be an HTTPS URL; got {v!r}")
        return v


class TaskPaneOfficeApp(OfficeApp):
    """A Task Pane Office App — a ribbon-hosted task pane.

    Emits `<OfficeApp xsi:type="TaskPaneApp">` with a
    `<VersionOverrides xsi:type="VersionOverridesV1_0">` carrying the
    ribbon button + resources.
    """

    xsi_type: Literal["TaskPaneApp"] = "TaskPaneApp"
    ribbon: RibbonConfig


# ---------------------------------------------------------------------------
# Manifest container
# ---------------------------------------------------------------------------


class Manifest(BaseModel):
    """Container for one or more OfficeApp manifests.

    Construct via `Manifest.from_components(...)` when you have pptxforge's
    `ContentAddIn`/`TaskPane` value objects; construct directly when
    driving the tree programmatically.

    `to_xml()` returns the SINGLE app's XML and raises when the Manifest
    holds multiple; use `to_files()` for the general case.
    """

    model_config = ConfigDict(frozen=True, strict=True)

    apps: list[ContentOfficeApp | TaskPaneOfficeApp]

    # --- construction -------------------------------------------------------

    @classmethod
    def from_components(cls, components: list[ContentAddIn | TaskPane]) -> Manifest:
        """Build a Manifest from ContentAddIn / TaskPane value objects.

        Returns a `Manifest` whose `.apps` list mirrors the input order:
        each ContentAddIn becomes a `ContentOfficeApp`; each TaskPane
        becomes a `TaskPaneOfficeApp`.

        Raises `pydantic.ValidationError` on missing required fields
        (non-HTTPS URL, empty display_name, malformed version, …) —
        whatever the models flag at construction.
        """
        apps: list[ContentOfficeApp | TaskPaneOfficeApp] = []
        for comp in components:
            if isinstance(comp, ContentAddIn):
                apps.append(_content_app_from(comp))
            elif isinstance(comp, TaskPane):
                apps.append(_taskpane_app_from(comp))
            else:
                raise TypeError(
                    f"from_components: expected ContentAddIn or TaskPane, got {type(comp).__name__}"
                )
        return cls(apps=apps)

    # --- serialization ------------------------------------------------------

    def to_xml(self) -> str:
        """Emit the single app's XML as a UTF-8 string.

        Raises `ValueError` when this Manifest holds zero or multiple apps.
        Use `to_files()` for multi-app manifests.
        """
        if len(self.apps) == 0:
            raise ValueError("Manifest has no apps — nothing to emit.")
        if len(self.apps) > 1:
            raise ValueError(
                f"to_xml() requires exactly 1 app; this Manifest has "
                f"{len(self.apps)}. Use `to_files()` to emit all of them."
            )
        return _render_app(self.apps[0])

    def to_files(self) -> dict[str, str]:
        """Return `{filename: xml}` for every app in this Manifest.

        Filenames follow the convention used throughout research/: content
        add-ins go to `manifest.content.xml`; task panes go to
        `manifest.taskpane.xml`. If the deck carries two ContentAddIns
        the filenames disambiguate with a suffix `manifest.content.<id-short>.xml`.
        """
        out: dict[str, str] = {}
        content_count = 0
        taskpane_count = 0
        for app in self.apps:
            xml = _render_app(app)
            if isinstance(app, ContentOfficeApp):
                content_count += 1
                fname = (
                    "manifest.content.xml"
                    if content_count == 1
                    else f"manifest.content.{str(app.id)[:8]}.xml"
                )
            else:
                taskpane_count += 1
                fname = (
                    "manifest.taskpane.xml"
                    if taskpane_count == 1
                    else f"manifest.taskpane.{str(app.id)[:8]}.xml"
                )
            if fname in out:
                # Defensive: disambiguate unconditionally.
                fname = fname.replace(".xml", f".{str(app.id)[:8]}.xml")
            out[fname] = xml
        return out

    # --- validation ---------------------------------------------------------

    def validate(self) -> list[ValidationError]:  # type: ignore[override]
        """Return validation errors for this manifest.

        Runs in-process checks (ID collision, icon requirements, HTTPS on
        every URL) plus — when the `office-addin-manifest` CLI is on
        `$PATH` — the official schema validator.

        The list is ordered: in-process errors first, then external
        results. Empty list means the manifest passes every check that
        ran.
        """
        errors: list[ValidationError] = []

        # In-process: ID collision
        seen_ids: dict[UUID, int] = {}
        for i, app in enumerate(self.apps):
            if app.id in seen_ids:
                errors.append(
                    ValidationError(
                        severity="error",
                        code="duplicate-id",
                        message=(
                            f"Two OfficeApp entries share id {app.id} "
                            f"(indexes {seen_ids[app.id]} and {i}). Every "
                            "manifest must have a unique Id."
                        ),
                        path=f"apps[{i}].id",
                    )
                )
            seen_ids[app.id] = i

        # In-process: content add-ins must have icon + support URLs
        for i, app in enumerate(self.apps):
            if isinstance(app, ContentOfficeApp):
                if app.icon_url is None:
                    errors.append(
                        ValidationError(
                            severity="error",
                            code="missing-icon",
                            message=(
                                "ContentApp requires icon_url — the "
                                "office-addin-manifest validator marks "
                                "this as required even though the XSD "
                                "doesn't."
                            ),
                            path=f"apps[{i}].icon_url",
                        )
                    )
                if app.icon_url_hires is None:
                    errors.append(
                        ValidationError(
                            severity="error",
                            code="missing-icon-hires",
                            message="ContentApp requires icon_url_hires.",
                            path=f"apps[{i}].icon_url_hires",
                        )
                    )
                if app.support_url is None:
                    errors.append(
                        ValidationError(
                            severity="error",
                            code="missing-support-url",
                            message="ContentApp requires support_url.",
                            path=f"apps[{i}].support_url",
                        )
                    )

        # External validator — one subprocess call per app.
        external_errors = _run_external_validator(self)
        errors.extend(external_errors)

        return errors


# ---------------------------------------------------------------------------
# Conversion helpers — ContentAddIn/TaskPane → ContentOfficeApp/TaskPaneOfficeApp
# ---------------------------------------------------------------------------


def _content_app_from(addin: ContentAddIn) -> ContentOfficeApp:
    """Build a ContentOfficeApp from a ContentAddIn value object."""
    emu_per_point = 12700
    req_w = addin.requested_width_emu // emu_per_point
    req_h = addin.requested_height_emu // emu_per_point
    return ContentOfficeApp(
        id=addin.id,
        version=addin.version,
        provider_name=addin.provider,
        default_locale=addin.default_locale,
        display_name=LocalizableString(default_value=addin.display_name),
        description=LocalizableString(default_value=addin.description),
        icon_url=addin.icon_url,
        icon_url_hires=addin.icon_url_hires,
        support_url=addin.support_url,
        default_settings=DefaultSettings(
            source_location=addin.source_url,
            requested_width=req_w,
            requested_height=req_h,
        ),
        permissions=addin.permissions,
    )


def _taskpane_app_from(taskpane: TaskPane) -> TaskPaneOfficeApp:
    """Build a TaskPaneOfficeApp from a TaskPane value object."""
    return TaskPaneOfficeApp(
        id=taskpane.id,
        version=taskpane.version,
        provider_name=taskpane.provider,
        default_locale=taskpane.default_locale,
        display_name=LocalizableString(default_value=taskpane.display_name),
        description=LocalizableString(default_value=taskpane.description),
        icon_url=taskpane.icon_32_url,
        icon_url_hires=taskpane.icon_80_url,
        support_url=taskpane.support_url,
        default_settings=DefaultSettings(source_location=taskpane.source_url),
        permissions=taskpane.permissions,
        ribbon=RibbonConfig(
            group_label=taskpane.ribbon_group_label,
            button_label=taskpane.ribbon_label,
            button_tip=taskpane.ribbon_tip,
            icon_16_url=taskpane.icon_16_url,
            icon_32_url=taskpane.icon_32_url,
            icon_80_url=taskpane.icon_80_url,
            commands_url=taskpane.commands_url,
            taskpane_url=taskpane.source_url,
            learn_more_url=taskpane.learn_more_url,
        ),
    )


# ---------------------------------------------------------------------------
# XML serialization
# ---------------------------------------------------------------------------


_XML_PROLOG = '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>\n'


def _render_app(app: ContentOfficeApp | TaskPaneOfficeApp) -> str:
    """Serialize an OfficeApp subtree to an XML string."""
    if isinstance(app, TaskPaneOfficeApp):
        root = _build_taskpane_root(app)
    else:
        root = _build_content_root(app)
    body_bytes: bytes = etree.tostring(
        root,
        pretty_print=True,
        xml_declaration=False,
    )
    return _XML_PROLOG + body_bytes.decode("utf-8")


def _q(ns: str, local: str) -> str:
    return f"{{{ns}}}{local}"


def _build_base_root(
    app: OfficeApp, xsi_type: str, extra_nsmap: dict[str, str] | None = None
) -> etree._Element:
    """Build the shared `<OfficeApp xsi:type="...">` skeleton (Id..Permissions)."""
    nsmap: dict[str | None, str] = {None: NS_OFFICEAPP, "xsi": NS_XSI}
    if extra_nsmap:
        nsmap.update(extra_nsmap)

    root = etree.Element(_q(NS_OFFICEAPP, "OfficeApp"), nsmap=nsmap)
    root.set(_q(NS_XSI, "type"), xsi_type)

    etree.SubElement(root, _q(NS_OFFICEAPP, "Id")).text = str(app.id)
    etree.SubElement(root, _q(NS_OFFICEAPP, "Version")).text = app.version
    etree.SubElement(root, _q(NS_OFFICEAPP, "ProviderName")).text = app.provider_name
    etree.SubElement(root, _q(NS_OFFICEAPP, "DefaultLocale")).text = app.default_locale

    _append_localizable(root, "DisplayName", app.display_name)
    _append_localizable(root, "Description", app.description)

    if app.icon_url is not None:
        etree.SubElement(root, _q(NS_OFFICEAPP, "IconUrl"), attrib={"DefaultValue": app.icon_url})
    if app.icon_url_hires is not None:
        etree.SubElement(
            root,
            _q(NS_OFFICEAPP, "HighResolutionIconUrl"),
            attrib={"DefaultValue": app.icon_url_hires},
        )
    if app.support_url is not None:
        etree.SubElement(
            root,
            _q(NS_OFFICEAPP, "SupportUrl"),
            attrib={"DefaultValue": app.support_url},
        )

    hosts = etree.SubElement(root, _q(NS_OFFICEAPP, "Hosts"))
    for h in app.hosts:
        etree.SubElement(hosts, _q(NS_OFFICEAPP, "Host"), attrib={"Name": h.name})

    ds = etree.SubElement(root, _q(NS_OFFICEAPP, "DefaultSettings"))
    etree.SubElement(
        ds,
        _q(NS_OFFICEAPP, "SourceLocation"),
        attrib={"DefaultValue": app.default_settings.source_location},
    )
    if app.default_settings.requested_width is not None:
        etree.SubElement(ds, _q(NS_OFFICEAPP, "RequestedWidth")).text = str(
            app.default_settings.requested_width
        )
    if app.default_settings.requested_height is not None:
        etree.SubElement(ds, _q(NS_OFFICEAPP, "RequestedHeight")).text = str(
            app.default_settings.requested_height
        )

    etree.SubElement(root, _q(NS_OFFICEAPP, "Permissions")).text = app.permissions

    return root


def _build_content_root(app: ContentOfficeApp) -> etree._Element:
    return _build_base_root(app, xsi_type="ContentApp")


def _build_taskpane_root(app: TaskPaneOfficeApp) -> etree._Element:
    root = _build_base_root(
        app,
        xsi_type="TaskPaneApp",
        extra_nsmap={"bt": NS_BT, "ov": NS_OV},
    )
    _append_version_overrides(root, app.ribbon)
    return root


def _append_localizable(parent: etree._Element, local: str, value: LocalizableString) -> None:
    el = etree.SubElement(
        parent, _q(NS_OFFICEAPP, local), attrib={"DefaultValue": value.default_value}
    )
    for locale, text in value.overrides.items():
        etree.SubElement(
            el,
            _q(NS_OFFICEAPP, "Override"),
            attrib={"Locale": locale, "Value": text},
        )


def _append_version_overrides(root: etree._Element, ribbon: RibbonConfig) -> None:
    """Build the `<VersionOverrides>` subtree for a task-pane manifest."""
    vo = etree.SubElement(
        root,
        _q(NS_OV, "VersionOverrides"),
        nsmap={None: NS_OV},
    )
    vo.set(_q(NS_XSI, "type"), "VersionOverridesV1_0")

    hosts = etree.SubElement(vo, _q(NS_OV, "Hosts"))
    host = etree.SubElement(hosts, _q(NS_OV, "Host"))
    host.set(_q(NS_XSI, "type"), "Presentation")

    dff = etree.SubElement(host, _q(NS_OV, "DesktopFormFactor"))

    # GetStarted (nice-to-have; fixture has it).
    gs = etree.SubElement(dff, _q(NS_OV, "GetStarted"))
    etree.SubElement(gs, _q(NS_OV, "Title"), attrib={"resid": "GetStarted.Title"})
    etree.SubElement(gs, _q(NS_OV, "Description"), attrib={"resid": "GetStarted.Description"})
    if ribbon.learn_more_url is not None:
        etree.SubElement(gs, _q(NS_OV, "LearnMoreUrl"), attrib={"resid": "GetStarted.LearnMoreUrl"})

    etree.SubElement(dff, _q(NS_OV, "FunctionFile"), attrib={"resid": "Commands.Url"})

    ep = etree.SubElement(dff, _q(NS_OV, "ExtensionPoint"))
    ep.set(_q(NS_XSI, "type"), "PrimaryCommandSurface")
    tab = etree.SubElement(ep, _q(NS_OV, "OfficeTab"), attrib={"id": ribbon.tab})
    group = etree.SubElement(tab, _q(NS_OV, "Group"), attrib={"id": ribbon.group_id})
    etree.SubElement(group, _q(NS_OV, "Label"), attrib={"resid": "Group.Label"})
    icon = etree.SubElement(group, _q(NS_OV, "Icon"))
    for sz in ("16", "32", "80"):
        etree.SubElement(icon, _q(NS_BT, "Image"), attrib={"size": sz, "resid": f"Icon.{sz}"})
    control = etree.SubElement(group, _q(NS_OV, "Control"), attrib={"id": ribbon.button_id})
    control.set(_q(NS_XSI, "type"), "Button")
    etree.SubElement(control, _q(NS_OV, "Label"), attrib={"resid": "Btn.Label"})
    supertip = etree.SubElement(control, _q(NS_OV, "Supertip"))
    etree.SubElement(supertip, _q(NS_OV, "Title"), attrib={"resid": "Btn.Label"})
    etree.SubElement(supertip, _q(NS_OV, "Description"), attrib={"resid": "Btn.Tip"})
    ctrl_icon = etree.SubElement(control, _q(NS_OV, "Icon"))
    for sz in ("16", "32", "80"):
        etree.SubElement(ctrl_icon, _q(NS_BT, "Image"), attrib={"size": sz, "resid": f"Icon.{sz}"})
    action = etree.SubElement(control, _q(NS_OV, "Action"))
    action.set(_q(NS_XSI, "type"), "ShowTaskpane")
    etree.SubElement(action, _q(NS_OV, "TaskpaneId")).text = ribbon.taskpane_id
    etree.SubElement(action, _q(NS_OV, "SourceLocation"), attrib={"resid": "Taskpane.Url"})

    # Resources — compiled from the ribbon config.
    resources = etree.SubElement(vo, _q(NS_OV, "Resources"))

    images = etree.SubElement(resources, _q(NS_BT, "Images"))
    for resid, url in (
        ("Icon.16", ribbon.icon_16_url),
        ("Icon.32", ribbon.icon_32_url),
        ("Icon.80", ribbon.icon_80_url),
    ):
        etree.SubElement(images, _q(NS_BT, "Image"), attrib={"id": resid, "DefaultValue": url})

    urls = etree.SubElement(resources, _q(NS_BT, "Urls"))
    etree.SubElement(
        urls,
        _q(NS_BT, "Url"),
        attrib={"id": "Commands.Url", "DefaultValue": ribbon.commands_url},
    )
    etree.SubElement(
        urls,
        _q(NS_BT, "Url"),
        attrib={"id": "Taskpane.Url", "DefaultValue": ribbon.taskpane_url},
    )
    if ribbon.learn_more_url is not None:
        etree.SubElement(
            urls,
            _q(NS_BT, "Url"),
            attrib={
                "id": "GetStarted.LearnMoreUrl",
                "DefaultValue": ribbon.learn_more_url,
            },
        )

    short = etree.SubElement(resources, _q(NS_BT, "ShortStrings"))
    etree.SubElement(
        short,
        _q(NS_BT, "String"),
        attrib={"id": "Group.Label", "DefaultValue": ribbon.group_label},
    )
    etree.SubElement(
        short,
        _q(NS_BT, "String"),
        attrib={"id": "Btn.Label", "DefaultValue": ribbon.button_label},
    )
    etree.SubElement(
        short,
        _q(NS_BT, "String"),
        attrib={"id": "GetStarted.Title", "DefaultValue": "pptxforge is ready."},
    )

    long = etree.SubElement(resources, _q(NS_BT, "LongStrings"))
    etree.SubElement(
        long,
        _q(NS_BT, "String"),
        attrib={"id": "Btn.Tip", "DefaultValue": ribbon.button_tip},
    )
    etree.SubElement(
        long,
        _q(NS_BT, "String"),
        attrib={
            "id": "GetStarted.Description",
            "DefaultValue": "Use the ribbon button to open the task pane.",
        },
    )


# ---------------------------------------------------------------------------
# External validator integration
# ---------------------------------------------------------------------------


def _find_office_addin_manifest() -> str | None:
    """Locate the `office-addin-manifest` CLI on `$PATH`, or return None.

    Also checks the local `node_modules/.bin/` — pptxforge's own repo ships
    the validator as a dev dependency. On Windows we prefer the `.cmd`
    wrapper over the extension-less POSIX shim so subprocess.run can
    actually launch it (WinError 193 otherwise).
    """
    import sys

    # System $PATH first — shutil.which handles Windows extensions.
    p = shutil.which("office-addin-manifest")
    if p is not None:
        return p

    # Local node_modules, walking up from cwd AND from this file.
    suffix_priority = (".cmd", ".ps1", "") if sys.platform == "win32" else ("", ".cmd", ".ps1")
    for cwd in (Path.cwd(), *Path(__file__).resolve().parents):
        bin_dir = cwd / "node_modules" / ".bin"
        if not bin_dir.is_dir():
            continue
        for suffix in suffix_priority:
            exe = bin_dir / f"office-addin-manifest{suffix}"
            if exe.is_file():
                return str(exe)
    return None


def _run_external_validator(manifest: Manifest) -> list[ValidationError]:
    """Run `office-addin-manifest validate` per app, collect errors."""
    tool = _find_office_addin_manifest()
    if tool is None:
        return [
            ValidationError(
                severity="warning",
                code="external-validator-unavailable",
                message=(
                    "office-addin-manifest is not on $PATH. In-process "
                    "validation passed, but the official schema validator "
                    "was not run. Install with `npm i -g office-addin-manifest`."
                ),
            )
        ]

    errors: list[ValidationError] = []
    for i, app in enumerate(manifest.apps):
        xml = _render_app(app)
        with tempfile.NamedTemporaryFile(
            mode="w", suffix=".xml", delete=False, encoding="utf-8"
        ) as tmp:
            tmp.write(xml)
            tmp_path = tmp.name
        try:
            proc = subprocess.run(
                [tool, "validate", tmp_path],
                capture_output=True,
                text=True,
                check=False,
                timeout=60,
            )
        except subprocess.TimeoutExpired:
            errors.append(
                ValidationError(
                    severity="error",
                    code="external-validator-timeout",
                    message=f"office-addin-manifest timed out on app {i}.",
                    path=f"apps[{i}]",
                )
            )
            continue
        finally:
            Path(tmp_path).unlink(missing_ok=True)

        if proc.returncode != 0:
            combined = (proc.stdout or "") + (proc.stderr or "")
            errors.append(
                ValidationError(
                    severity="error",
                    code="external-validator-error",
                    message=(
                        f"office-addin-manifest rejected app {i} (exit "
                        f"{proc.returncode}). Output:\n{combined.strip()}"
                    ),
                    path=f"apps[{i}]",
                )
            )

    return errors


__all__ = [
    "Manifest",
    "OfficeApp",
    "ContentOfficeApp",
    "TaskPaneOfficeApp",
    "LocalizableString",
    "Host",
    "DefaultSettings",
    "Resources",
    "RibbonConfig",
    "ValidationError",
    "PermissionLevel",
]
