"""Office Add-in escape hatch: content add-ins, task panes, manifest, scaffold."""

from pptxforge.addins import components, manifest, scaffold
from pptxforge.addins.components._base import AddInComponent
from pptxforge.addins.content_addin import ContentAddIn
from pptxforge.addins.manifest import Manifest, ValidationError
from pptxforge.addins.scaffold import (
    NpmBuildError,
    ScaffoldError,
    ScaffoldResult,
    render_deploy_readme_section,
    scaffold_all,
    scaffold_component,
)
from pptxforge.addins.taskpane import TaskPane

__all__ = [
    # Manifest value objects (Phase 7)
    "ContentAddIn",
    "TaskPane",
    # Scaffold-side ABC + results (Phase 8)
    "AddInComponent",
    "ScaffoldResult",
    "ScaffoldError",
    "NpmBuildError",
    "scaffold_component",
    "scaffold_all",
    "render_deploy_readme_section",
    # Manifest generator (Phase 7)
    "Manifest",
    "ValidationError",
    # Submodules
    "components",
    "manifest",
    "scaffold",
]
