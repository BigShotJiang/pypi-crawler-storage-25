"""ContentAddIn — slide-embedded live-webview add-in.

Phase 7 promotes this from stub to a frozen dataclass. `Manifest.from_components`
in `pptxforge.addins.manifest` consumes a list of these (plus TaskPanes) and
emits the OOXML XML manifest(s) each add-in needs for sideload.
"""

from dataclasses import dataclass
from typing import Literal
from uuid import UUID


@dataclass(frozen=True, slots=True)
class ContentAddIn:
    """Defines the Office content add-in manifest shared by every live
    webview embedded on slides in this deck.

    One ContentAddIn per deck is typical. Multiple ContentAddIns are
    allowed but each gets its own manifest file — use the `id` field to
    keep them distinct in PowerPoint's add-in registry.

    Example:
        >>> addin = ContentAddIn(
        ...     id=UUID("11111111-2222-3333-4444-555555555555"),
        ...     display_name="Acme Slide Widgets",
        ...     provider="Acme Research",
        ...     source_url="https://addins.acme.com/slide/",
        ...     icon_url="https://addins.acme.com/icon-32.png",
        ...     icon_url_hires="https://addins.acme.com/icon-64.png",
        ...     support_url="https://addins.acme.com/support",
        ... )
    """

    id: UUID
    display_name: str
    provider: str
    source_url: str
    description: str = "A pptxforge-generated content add-in."
    support_url: str | None = None
    icon_url: str | None = None
    icon_url_hires: str | None = None
    permissions: Literal["Restricted", "ReadDocument", "ReadAllDocument", "ReadWriteDocument"] = (
        "ReadWriteDocument"
    )
    manifest_format: Literal["xml", "json", "both"] = "xml"
    requested_width_emu: int = 3657600  # 4 inches
    requested_height_emu: int = 2743200  # 3 inches
    version: str = "1.0.0.0"
    default_locale: str = "en-US"
