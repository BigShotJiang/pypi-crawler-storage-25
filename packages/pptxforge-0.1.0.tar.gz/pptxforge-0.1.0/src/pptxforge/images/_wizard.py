"""Interactive setup wizard for Unsplash / Pexels API keys.

Walks a first-time user through the signup flow:

1. Prints what to do.
2. Opens the provider's developer-dashboard URL in the default browser.
3. Reads the pasted key from stdin, with format validation + retry.
4. Writes it to `pptxforge.config`.

Headless / non-interactive callers (CI, redirected stdin, no
`$DISPLAY` on Linux) get a `SetupError` with manual env-var
instructions instead of a hung readline. The browser-open call is
best-effort — if `webbrowser.open` fails or returns False, we print
the URL plain-text.
"""

from __future__ import annotations

import os
import re
import sys
import webbrowser
from pathlib import Path
from typing import Literal

from pptxforge.config import set_api_key
from pptxforge.images._errors import ImageFetchError


class SetupError(ImageFetchError):
    """Raised when the wizard can't run interactively.

    Subclass of `ImageFetchError` so a single `except ImageFetchError`
    catches both "key missing" and "wizard couldn't run" failures.
    """


# Per-source dashboard URL + a short signup script. Keep the steps
# concrete and verbatim — first-time users follow exactly these
# clicks; vague language ("create an account") loses people.
_PROVIDERS: dict[str, dict[str, str | list[str]]] = {
    "unsplash": {
        "label": "Unsplash",
        "url": "https://unsplash.com/developers",
        "steps": [
            "Sign in (or sign up — it's free).",
            'Click "New Application".',
            "Accept the API guidelines.",
            "Name your app (any name) and add a brief description.",
            "Copy the **Access Key** (NOT the Secret key).",
        ],
    },
    "pexels": {
        "label": "Pexels",
        "url": "https://www.pexels.com/api/new/",
        "steps": [
            "Sign in (or sign up — it's free).",
            "Describe what you'll use the API for (one sentence is fine).",
            "Submit the request — Pexels grants the key immediately.",
            "Copy the API key from the dashboard.",
        ],
    },
}

# Validation: real keys are dense alphanumeric (with `-` / `_` for
# Unsplash). The minimums catch typos / partial pastes; we allow up
# to 100 chars of slack so a future longer key format doesn't reject
# valid input. Regex anchors to the whole string.
_KEY_FORMAT = re.compile(r"^[A-Za-z0-9_\-]{20,100}$")
_MAX_RETRIES = 3


def _stdin_interactive() -> bool:
    """Same check as `fetch._stdin_is_interactive` — kept local to
    avoid a circular dependency between the wizard and fetch."""
    try:
        return sys.stdin.isatty()
    except (AttributeError, ValueError, OSError):
        return False


def _looks_headless() -> bool:
    """Best-effort check for "no GUI to open a browser into".

    Linux without `$DISPLAY` / `$WAYLAND_DISPLAY` set is the canonical
    case — the SSH-into-a-server-and-run-the-build scenario. macOS
    and Windows always have a browser available; we skip the heuristic
    on those platforms.
    """
    if sys.platform.startswith("linux"):
        return not (os.environ.get("DISPLAY") or os.environ.get("WAYLAND_DISPLAY"))
    return False


def setup_wizard(source: Literal["unsplash", "pexels"] = "unsplash") -> Path:
    """Run the interactive setup for `source`. Returns the config file path.

    `source` defaults to `"unsplash"` — the recommended provider for
    most decks (better photography catalog than Pexels, smaller-grained
    rate limit but the cache makes it irrelevant for normal use).

    Raises:
        SetupError: stdin isn't a tty (CI, redirected stdin); the
            error message includes the env-var fallback so the caller
            knows what to do without re-reading the docs.
        ValueError: `source` not in `{"unsplash", "pexels"}`.

    Mocking the wizard in tests: monkeypatch `sys.stdin`, `sys.stdout`,
    and `webbrowser.open` per the patterns in `tests/images/test_wizard.py`.
    """
    if source not in _PROVIDERS:
        raise ValueError(
            f"setup_wizard: unknown source {source!r}; expected one of {sorted(_PROVIDERS.keys())}"
        )

    provider = _PROVIDERS[source]
    label = provider["label"]
    url = str(provider["url"])

    if not _stdin_interactive():
        raise SetupError(
            f"setup_wizard cannot run: stdin is not interactive (CI, redirected "
            f"input, etc.). To configure {label} manually, set "
            f"`{source.upper()}_ACCESS_KEY` (or `_API_KEY` for Pexels) in your "
            f"environment, or write the key to "
            f"`[api_keys].{source}` in pptxforge's config file. The dashboard "
            f"is at {url}.",
            source=source,
        )

    out = sys.stdout
    out.write(f"\nSetting up {label} for high-quality images.\n\n")
    if isinstance(provider["steps"], list):
        for i, step in enumerate(provider["steps"], 1):
            out.write(f"  {i}. {step}\n")
    out.write("\n")

    # Try to open the browser; fall back to printing the URL if the
    # platform has no usable browser registered (headless server).
    opened = False
    if not _looks_headless():
        try:
            opened = webbrowser.open(url)
        except webbrowser.Error:
            opened = False
    if opened:
        out.write(f"Opened your browser at {url}.\n")
    else:
        out.write(f"Open this URL in a browser: {url}\n")
    out.write("\n")
    out.flush()

    # Read + validate the key, with retry. Each retry message points
    # at the most likely paste error so the user can spot it.
    key: str | None = None
    for attempt in range(1, _MAX_RETRIES + 1):
        out.write(f"Paste your {label} key here: ")
        out.flush()
        candidate = sys.stdin.readline().strip()
        if not candidate:
            out.write("Empty input. ")
        elif not _KEY_FORMAT.match(candidate):
            out.write(
                f"That doesn't look like a {label} key "
                f"(expected {_KEY_FORMAT.pattern!r}). "
                f"Common mistakes: pasted the *Secret* key by accident, "
                f"included quotes, or trailing whitespace. "
            )
        else:
            key = candidate
            break
        if attempt < _MAX_RETRIES:
            out.write(f"Try again ({attempt}/{_MAX_RETRIES}).\n")
        else:
            out.write(f"Giving up after {_MAX_RETRIES} attempts.\n")
            out.flush()
            raise SetupError(
                f"setup_wizard: too many invalid {label} keys entered.",
                source=source,
            )

    assert key is not None
    path = set_api_key(source, key)
    out.write(f"\nSaved! Your key is stored at {path}.\n")
    out.write(f"`fetch_image(...)` will now use {label} automatically.\n\n")
    out.flush()
    return path


__all__ = ["setup_wizard", "SetupError"]
