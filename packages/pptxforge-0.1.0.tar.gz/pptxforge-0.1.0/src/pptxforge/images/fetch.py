"""`fetch_image` and `attribution_for` — the user-facing surface.

Build-time only. Calls the source's API once per (query, orientation,
index, source) tuple, caches the result on disk, returns the local
path. Subsequent calls with the same arguments hit the cache — zero
network.
"""

from __future__ import annotations

import sys
from pathlib import Path
from typing import Literal

import httpx

from pptxforge.config import get_api_key
from pptxforge.images._backends import (
    Orientation,
    download_image,
    fetch_pexels,
    fetch_unsplash,
    fetch_wikimedia,
)
from pptxforge.images._cache import (
    cached_paths,
    find_cached,
    read_metadata,
    write_metadata,
)
from pptxforge.images._errors import APIKeyMissingError

# `source=` accepts the three concrete backends plus "auto" — auto
# picks Unsplash / Pexels / Wikimedia in that order based on which
# keys are configured (env or config file). Wikimedia is the
# zero-config floor; auto always resolves to *something*.
SourceArg = Literal["auto", "unsplash", "pexels", "wikimedia"]

_DEFAULT_CACHE_DIR = ".pptxforge_images"


def _resolve_auto_source() -> Literal["unsplash", "pexels", "wikimedia"]:
    """Pick the best source for the user's current configuration.

    Order: Unsplash > Pexels > Wikimedia. Unsplash and Pexels offer
    photography-quality results when the user has set up keys;
    Wikimedia is the always-available floor (encyclopaedic content,
    no key, no signup).
    """
    if get_api_key("unsplash"):
        return "unsplash"
    if get_api_key("pexels"):
        return "pexels"
    return "wikimedia"


def _stdin_is_interactive() -> bool:
    """True iff stdin is a real tty we can prompt against.

    Pytest, CI runners, piped input, and `< file` redirections all
    return False — and the wizard / auto-prompt fall back to raising
    `APIKeyMissingError` so non-interactive callers get the
    actionable error instead of an indefinite read on stdin.
    """
    try:
        return sys.stdin.isatty()
    except (AttributeError, ValueError, OSError):
        return False


def fetch_image(
    query: str,
    *,
    source: SourceArg = "auto",
    orientation: Orientation = "landscape",
    min_width: int = 1920,
    cache_dir: Path | str = _DEFAULT_CACHE_DIR,
    index: int = 0,
    timeout: float = 10.0,
    client: httpx.Client | None = None,
) -> Path:
    """Fetch a photo matching `query`; return its local cache path.

    On cache hit (same `source` + `query` + `orientation` + `index`),
    returns immediately with no network call. On miss, calls the
    source's search API, downloads the photo, writes a sidecar
    metadata file, returns the path.

    Args:
        query: The search string passed verbatim to the source's API.
        source: `"auto"` (default), `"unsplash"`, `"pexels"`, or
            `"wikimedia"`. `auto` resolves to Unsplash if a key is
            configured (env or config file), then Pexels, then
            Wikimedia — so first-install with no setup still produces
            a working image (Wikimedia requires no key). Explicit
            sources skip the auto resolution and use the named source
            directly.
        orientation: `"landscape"` (default) / `"portrait"` /
            `"square"`. Translated to source-specific terms internally
            (Unsplash calls "square" "squarish"). Wikimedia ignores
            this — Commons doesn't filter by aspect ratio.
        min_width: Above 1080 px, `unsplash` switches from
            `urls.regular` to `urls.full` so PowerPoint doesn't
            render scaled-up JPEGs. `pexels` always uses `src.large2x`
            (~1880 px). Wikimedia requests a 1920px-wide rendition.
        cache_dir: Directory for cached images + sidecar metadata.
            Defaults to `.pptxforge_images/` in CWD. Commit this to
            your project's git so builds are reproducible across
            machines without re-fetching.
        index: 0-indexed pick from the search result page. Default 0
            (first result). For Wikimedia, indexed against the
            quality-filtered results (post-min-width / post-format),
            not the raw search hits.
        timeout: Per-request timeout in seconds. Applied to both the
            search call and the image download.
        client: Inject a preconstructed `httpx.Client` — used by tests
            with a `MockTransport`. Production callers leave this None.

    Returns:
        Absolute `Path` to the cached image file. The sidecar
        `{stem}.meta.json` lives next to it; `attribution_for(path)`
        reads it.

    Raises:
        APIKeyMissingError: explicit `source="unsplash"` or `"pexels"`
            with no key configured AND stdin is non-interactive (in
            an interactive terminal, the user is prompted to run the
            setup wizard first).
        NoResultsError: source returned an empty result list, or
            `index` exceeds the result count (or, for Wikimedia, no
            result passed the quality filter).
        ImageFetchError: any other HTTP / parsing / download failure.

    Example:
        >>> from pptxforge.images import fetch_image, attribution_for
        >>> path = fetch_image("modern coffee shop")           # auto → Wikimedia or Unsplash
        >>> note = attribution_for(path)                       # source-aware string

    Cache invalidation: none. The cache is content-addressable by
    query; if you want a different image, change the query or `index`.

    Rate limits: Unsplash demo tier is 50 requests/hour; Pexels
    200/hour; Wikimedia is unmetered for read traffic at this volume
    but be reasonable. The cache makes this fine for normal use.
    """
    if not query or not query.strip():
        raise ValueError("fetch_image: query must be non-empty")
    if source not in ("auto", "unsplash", "pexels", "wikimedia"):
        raise ValueError(
            f"fetch_image: source must be 'auto' / 'unsplash' / 'pexels' / 'wikimedia'; "
            f"got {source!r}"
        )
    if orientation not in ("landscape", "portrait", "square"):
        raise ValueError(
            f"fetch_image: orientation must be 'landscape' / 'portrait' / 'square'; "
            f"got {orientation!r}"
        )
    if index < 0:
        raise ValueError(f"fetch_image: index must be non-negative; got {index}")
    if timeout <= 0:
        raise ValueError(f"fetch_image: timeout must be positive; got {timeout}")

    # Resolve `auto` to a concrete source. After this point the rest
    # of the function works against a definite backend.
    if source == "auto":
        resolved_source = _resolve_auto_source()
    else:
        # Auto-prompt path: explicit Unsplash/Pexels with no key in
        # an interactive terminal offers the wizard before erroring.
        if source in ("unsplash", "pexels") and not get_api_key(source):
            _maybe_offer_wizard(source)
        resolved_source = source

    cache_path = Path(cache_dir).resolve()

    # Cache hit? Both image AND metadata must exist.
    hit = find_cached(cache_path, resolved_source, query, orientation, index)
    if hit is not None:
        return hit[0]

    # Cache miss — call the source.
    if resolved_source == "unsplash":
        result = fetch_unsplash(
            query=query,
            orientation=orientation,
            index=index,
            min_width=min_width,
            timeout=timeout,
            client=client,
        )
    elif resolved_source == "pexels":
        result = fetch_pexels(
            query=query,
            orientation=orientation,
            index=index,
            min_width=min_width,
            timeout=timeout,
            client=client,
        )
    else:  # wikimedia
        result = fetch_wikimedia(
            query=query,
            orientation=orientation,
            index=index,
            min_width=min_width,
            timeout=timeout,
            client=client,
        )

    image_path, meta_path = cached_paths(
        cache_path, resolved_source, query, orientation, index, result.file_extension
    )

    download_image(
        result.image_url,
        image_path,
        timeout=timeout,
        source=resolved_source,
        query=query,
        client=client,
    )

    write_metadata(
        meta_path,
        source=resolved_source,
        photographer=result.photographer,
        photographer_url=result.photographer_url,
        source_url=result.source_url,
        query=query,
        licence=result.licence,
    )

    return image_path


def _maybe_offer_wizard(source: Literal["unsplash", "pexels"]) -> None:
    """If stdin is interactive, prompt to run the setup wizard.

    Yes → wizard runs inline (writes config), function returns and
    `fetch_image` continues. No (or non-interactive) → raise
    `APIKeyMissingError` so the caller sees the actionable error.

    The wizard's own logic also handles the non-interactive case, but
    we re-check here so the y/N prompt itself doesn't fire on CI.
    """
    if not _stdin_is_interactive():
        # Fall through; the backend will raise APIKeyMissingError
        # with the actionable message naming setup_wizard + the env var.
        return

    label = source.title()
    sys.stdout.write(f"\n{label} key not set. Run setup wizard now to add one? [y/N]: ")
    sys.stdout.flush()
    answer = sys.stdin.readline().strip().lower()
    if answer in ("y", "yes"):
        # Lazy import to avoid a circular import (wizard imports
        # config which is fine; wizard does not import fetch).
        from pptxforge.images._wizard import setup_wizard

        setup_wizard(source)
        # If the wizard returned without raising, the key is now in
        # the config file. Continue.
        return

    # User declined — surface the actionable error like before.
    raise APIKeyMissingError(
        f"{label} key not set. Run "
        f"`pptxforge.images.setup_wizard({source!r})` "
        f"or set the env var. See the SKILL.md image-fetching section.",
        source=source,
        query="",
    )


def attribution_for(image_path: Path | str) -> str:
    """Render an attribution string for a `fetch_image`-returned path.

    Reads the sidecar `{stem}.meta.json` next to the image and
    returns a source-appropriate credit:

    - Unsplash / Pexels: `"Photo by Jane Doe on Unsplash"`.
    - Wikimedia: `"Photo by Jane Doe via Wikimedia Commons (CC BY-SA 4.0)"`
      — the licence string varies per image (CC0, CC BY 4.0, CC BY-SA
      4.0, Public domain, …) and is captured in the sidecar.

    Both sets of licences require attribution wherever the deck is
    *published*. Pass the result as `caption=...` on `add_media_slide`,
    or render it as small text in a corner of the slide. The library
    does not enforce that attribution appears — that's on the caller —
    but `attribution_for` makes it a one-liner.

    Args:
        image_path: A path returned from `fetch_image`. The function
            looks for `{stem}.meta.json` in the same directory.

    Returns:
        Source-appropriate attribution string.

    Raises:
        FileNotFoundError: sidecar metadata is missing (image was not
            produced by `fetch_image`, or someone moved the .meta.json).
    """
    path = Path(image_path)
    meta_path = path.with_suffix(".meta.json")
    if not meta_path.is_file():
        raise FileNotFoundError(
            f"attribution_for: sidecar metadata not found at {meta_path}. "
            f"Was {path.name} produced by pptxforge.images.fetch_image?"
        )

    meta = read_metadata(meta_path)
    photographer = str(meta.get("photographer") or "Unknown")
    source = str(meta.get("source") or "")
    licence = str(meta.get("licence") or "").strip()

    if source == "wikimedia":
        # "via" rather than "on" because Commons is a repository, not
        # the work's primary publication surface; "via" reads as
        # acknowledging the route to the image rather than authorship.
        if licence:
            return f"Photo by {photographer} via Wikimedia Commons ({licence})"
        return f"Photo by {photographer} via Wikimedia Commons"

    source_pretty = {"unsplash": "Unsplash", "pexels": "Pexels"}.get(source, source.title())
    return f"Photo by {photographer} on {source_pretty}"
