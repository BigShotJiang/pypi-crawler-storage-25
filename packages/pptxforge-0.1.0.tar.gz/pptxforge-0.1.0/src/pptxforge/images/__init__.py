"""Image fetching from Unsplash, Pexels, and Wikimedia Commons.

`fetch_image(query)` runs at build time. The default `source="auto"`
picks the best backend for your configuration: Unsplash if you have a
key, then Pexels, then Wikimedia (which needs no key — zero-config
floor). Subsequent calls hit the on-disk cache in `.pptxforge_images/`
with no network.

`attribution_for(path)` renders a source-appropriate credit string.

`setup_wizard(source)` walks first-time users through getting an
Unsplash or Pexels key — opens the dashboard, prompts for the pasted
key, writes it to `pptxforge.config`. After that, `fetch_image`
finds the key automatically.

The CLI subcommand `pptxforge fetch-image <query>` is still deferred
— `src/pptxforge/cli/main.py` is a stub. See `FOLLOWUPS.md`
2026-04-27.

Example:

    from pptxforge.images import fetch_image, attribution_for

    # Works on first install with no setup — uses Wikimedia.
    path = fetch_image("industrial mayonnaise factory")
    deck.add_media_slide(
        title="Production line",
        media=path,
        caption=attribution_for(path),
    )

    # For higher-quality photography, run the wizard once.
    from pptxforge.images import setup_wizard
    setup_wizard("unsplash")  # opens browser, prompts, saves to config
"""

from pptxforge.images._errors import (
    APIKeyMissingError,
    ImageFetchError,
    NoResultsError,
)
from pptxforge.images._wizard import SetupError, setup_wizard
from pptxforge.images.fetch import attribution_for, fetch_image

__all__ = [
    "fetch_image",
    "attribution_for",
    "setup_wizard",
    "ImageFetchError",
    "APIKeyMissingError",
    "NoResultsError",
    "SetupError",
]
