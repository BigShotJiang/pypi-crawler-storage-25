"""Content-addressable on-disk cache for fetched images.

Cache key is `sha1(f"{source}:{query}:{orientation}:{index}")`. Two
files per cached image:

- `{cache_key[:12]}_{slug}.{ext}` — the image bytes (whatever extension
  the source served, jpg or png).
- `{cache_key[:12]}_{slug}.meta.json` — sidecar metadata used by
  `attribution_for(...)`.

A cache hit requires BOTH files to exist; a partial download leaves
no metadata and re-fetches cleanly on the next call.
"""

from __future__ import annotations

import hashlib
import json
import re
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

# Cap slug length so cached filenames stay reasonable on filesystems
# with 255-char limits (NTFS, ext4) — leaves room for the 12-char
# hash prefix + extension + path components.
_MAX_SLUG_LEN = 40
_HASH_PREFIX_LEN = 12
_META_SUFFIX = ".meta.json"


def _slugify(query: str) -> str:
    """Render `query` as a filesystem-safe lowercase slug.

    Non-alphanumeric runs collapse to single hyphens; leading/trailing
    hyphens stripped; empty result substituted with `"img"` so the
    filename always has a body. Truncated to `_MAX_SLUG_LEN`.
    """
    safe = re.sub(r"[^a-z0-9]+", "-", query.lower()).strip("-")
    if not safe:
        return "img"
    return safe[:_MAX_SLUG_LEN]


def cache_key(source: str, query: str, orientation: str, index: int) -> str:
    """Return the SHA-1 hex digest of the canonical cache-key string."""
    return hashlib.sha1(
        f"{source}:{query}:{orientation}:{index}".encode(),
    ).hexdigest()


def cached_paths(
    cache_dir: Path,
    source: str,
    query: str,
    orientation: str,
    index: int,
    ext: str,
) -> tuple[Path, Path]:
    """Return `(image_path, metadata_path)` for the given cache key.

    `ext` is the file extension WITHOUT the leading dot (e.g. `"jpg"`).
    The image path uses that extension; the metadata path always uses
    `.meta.json`.
    """
    key = cache_key(source, query, orientation, index)
    stem = f"{key[:_HASH_PREFIX_LEN]}_{_slugify(query)}"
    return cache_dir / f"{stem}.{ext}", cache_dir / f"{stem}{_META_SUFFIX}"


def find_cached(
    cache_dir: Path,
    source: str,
    query: str,
    orientation: str,
    index: int,
) -> tuple[Path, Path] | None:
    """Return `(image, metadata)` if both exist for the cache key.

    Returns `None` on cache miss. We don't know the extension up front
    (Unsplash and Pexels each pick), so we look for any extension on
    the hash-prefixed stem.
    """
    if not cache_dir.is_dir():
        return None
    key = cache_key(source, query, orientation, index)
    stem = f"{key[:_HASH_PREFIX_LEN]}_{_slugify(query)}"
    meta_path = cache_dir / f"{stem}{_META_SUFFIX}"
    if not meta_path.is_file():
        return None
    # Find the image file with any extension matching the stem.
    for path in cache_dir.glob(f"{stem}.*"):
        if path == meta_path or path.name.endswith(_META_SUFFIX):
            continue
        return path, meta_path
    return None


def write_metadata(
    metadata_path: Path,
    *,
    source: str,
    photographer: str,
    photographer_url: str,
    source_url: str,
    query: str,
    licence: str = "",
) -> None:
    """Write the sidecar JSON used by `attribution_for(...)`.

    Includes `fetched_at` (ISO-8601 UTC) so future tooling can do
    cache-age checks without touching mtime (which `git checkout`
    rewrites).

    `licence` is populated for Wikimedia (per-image licence varies —
    "CC BY-SA 4.0" / "Public domain" / etc.) and stored as an empty
    string for Unsplash / Pexels (where the licence is uniform per
    source and documented at the source level).
    """
    metadata: dict[str, Any] = {
        "source": source,
        "photographer": photographer,
        "photographer_url": photographer_url,
        "source_url": source_url,
        "query": query,
        "licence": licence,
        "fetched_at": datetime.now(timezone.utc).isoformat(),
    }
    metadata_path.parent.mkdir(parents=True, exist_ok=True)
    metadata_path.write_text(json.dumps(metadata, indent=2), encoding="utf-8")


def read_metadata(metadata_path: Path) -> dict[str, Any]:
    """Read and parse the sidecar JSON. Raises `OSError` / `JSONDecodeError`."""
    data: dict[str, Any] = json.loads(metadata_path.read_text(encoding="utf-8"))
    return data
