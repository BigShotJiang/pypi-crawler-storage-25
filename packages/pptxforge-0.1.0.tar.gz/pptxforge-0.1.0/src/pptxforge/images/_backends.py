"""HTTP backends for `fetch_image`.

Each backend resolves a query+orientation+index into a single
`_FetchResult` (URL of the image to download + attribution metadata),
or raises one of the `_errors.ImageFetchError` subclasses. The shared
download path in `fetch.py` then handles the cache-write side
identically for all sources.
"""

from __future__ import annotations

import html
import os
from dataclasses import dataclass
from typing import Any, Literal

import httpx

from pptxforge.config import get_api_key
from pptxforge.images._errors import APIKeyMissingError, ImageFetchError, NoResultsError

# `Source` is the user-facing literal for the backends that actually
# round-trip a request. `auto` and the wizard live above this layer
# (in fetch.py); the backend functions only know about concrete
# sources.
Source = Literal["unsplash", "pexels", "wikimedia"]
Orientation = Literal["landscape", "portrait", "square"]


@dataclass(frozen=True, slots=True)
class _FetchResult:
    """The pieces a backend returns for one image lookup.

    The download is done by the shared caller, not the backend, so
    this dataclass carries the URL plus the metadata we'll write to
    the sidecar after the bytes land on disk.

    `licence` is populated for Wikimedia (where the licence varies per
    image — CC0, CC BY-SA 4.0, etc.) and left as an empty string for
    Unsplash / Pexels (where the licence is uniform per source and
    documented at the source level rather than per-image).
    """

    image_url: str
    photographer: str
    photographer_url: str
    source_url: str
    file_extension: str  # "jpg" or "png" — chosen by inspecting URL or content-type
    licence: str = ""


_UNSPLASH_SEARCH_URL = "https://api.unsplash.com/search/photos"
_PEXELS_SEARCH_URL = "https://api.pexels.com/v1/search"
_WIKIMEDIA_API_URL = "https://commons.wikimedia.org/w/api.php"

# Wikimedia's User-Agent policy requires identifying the bot. Per
# https://meta.wikimedia.org/wiki/User-Agent_policy.
_WIKIMEDIA_USER_AGENT = "pptxforge/0.1 (https://github.com/GA16-24/pptxforge)"

# Wikimedia search returns lots of irrelevant tiny diagrams + scanned
# book pages. Filter results by minimum image width (px) and reject
# vector formats (SVG embeds in pptx don't render reliably without a
# raster conversion step we don't ship).
_WIKIMEDIA_MIN_WIDTH_PX = 800
_WIKIMEDIA_REJECTED_EXTENSIONS = {"svg", "tif", "tiff", "ogv", "webm"}


# Unsplash uses "squarish" while the public API of pptxforge accepts "square"
# (matches Pexels and standard ImageMagick / PIL terminology). We translate at
# the boundary — never leak the source-specific spelling out.
_UNSPLASH_ORIENTATION_MAP: dict[Orientation, str] = {
    "landscape": "landscape",
    "portrait": "portrait",
    "square": "squarish",
}


def fetch_unsplash(
    *,
    query: str,
    orientation: Orientation,
    index: int,
    min_width: int,
    timeout: float,
    client: httpx.Client | None = None,
) -> _FetchResult:
    """Look up `query` on Unsplash; return the `index`-th result.

    Auth via `UNSPLASH_ACCESS_KEY` env var, sent as
    `Authorization: Client-ID <key>` (Unsplash supports both this
    header form and a `client_id=` query param; header form keeps
    the key out of URL-logging surfaces).

    `min_width` chooses between `urls.regular` (~1080 px) and
    `urls.full` (original full-size). Above 1080, we ask for `.full`
    so PowerPoint doesn't render scaled-up JPEGs.
    """
    key = get_api_key("unsplash")
    if not key:
        raise APIKeyMissingError(
            "Unsplash API key not set. Run `pptxforge.images.setup_wizard("
            '"unsplash")` for interactive setup, or set the '
            "`UNSPLASH_ACCESS_KEY` environment variable. Free keys at "
            "https://unsplash.com/developers.",
            source="unsplash",
            query=query,
        )

    per_page = max(5, index + 1)
    params = {
        "query": query,
        "orientation": _UNSPLASH_ORIENTATION_MAP[orientation],
        "per_page": per_page,
    }
    headers = {"Authorization": f"Client-ID {key}"}

    payload = _request_json(
        client,
        _UNSPLASH_SEARCH_URL,
        params=params,
        headers=headers,
        timeout=timeout,
        source="unsplash",
        query=query,
    )

    results = payload.get("results")
    if not isinstance(results, list) or not results:
        raise NoResultsError(
            f"Unsplash returned no results for query {query!r}",
            source="unsplash",
            query=query,
        )
    if index >= len(results):
        raise NoResultsError(
            f"Unsplash returned only {len(results)} result(s) for query "
            f"{query!r}; requested index={index}.",
            source="unsplash",
            query=query,
        )

    photo = results[index]
    urls = photo.get("urls") or {}
    image_url = urls.get("full") if min_width > 1080 else urls.get("regular")
    if not isinstance(image_url, str):
        raise ImageFetchError(
            f"Unsplash result {index} for {query!r} missing urls.regular/urls.full",
            source="unsplash",
            query=query,
        )

    user = photo.get("user") or {}
    user_links = user.get("links") or {}
    links = photo.get("links") or {}

    return _FetchResult(
        image_url=image_url,
        photographer=str(user.get("name") or "Unknown"),
        photographer_url=str(user_links.get("html") or "https://unsplash.com"),
        source_url=str(links.get("html") or "https://unsplash.com"),
        file_extension="jpg",  # Unsplash's CDN serves JPEG for both regular/full.
    )


def fetch_pexels(
    *,
    query: str,
    orientation: Orientation,
    index: int,
    min_width: int,
    timeout: float,
    client: httpx.Client | None = None,
) -> _FetchResult:
    """Look up `query` on Pexels; return the `index`-th result.

    Auth via `PEXELS_API_KEY`, sent as the bare `Authorization: <key>`
    header (Pexels does NOT prefix with `Bearer` per their docs).
    `min_width` is informational here — Pexels's `src.large2x` is
    ~1880 px wide which clears any reasonable threshold; we don't
    switch to `src.original` even at high `min_width` because original
    sizes vary wildly and bloat decks.
    """
    del min_width  # see docstring — large2x always

    key = get_api_key("pexels")
    if not key:
        raise APIKeyMissingError(
            "Pexels API key not set. Run `pptxforge.images.setup_wizard("
            '"pexels")` for interactive setup, or set the '
            "`PEXELS_API_KEY` environment variable. Free keys at "
            "https://www.pexels.com/api/.",
            source="pexels",
            query=query,
        )

    per_page = max(5, index + 1)
    params = {
        "query": query,
        "orientation": orientation,
        "per_page": per_page,
    }
    headers = {"Authorization": key}

    payload = _request_json(
        client,
        _PEXELS_SEARCH_URL,
        params=params,
        headers=headers,
        timeout=timeout,
        source="pexels",
        query=query,
    )

    photos = payload.get("photos")
    if not isinstance(photos, list) or not photos:
        raise NoResultsError(
            f"Pexels returned no results for query {query!r}",
            source="pexels",
            query=query,
        )
    if index >= len(photos):
        raise NoResultsError(
            f"Pexels returned only {len(photos)} result(s) for query "
            f"{query!r}; requested index={index}.",
            source="pexels",
            query=query,
        )

    photo = photos[index]
    src = photo.get("src") or {}
    image_url = src.get("large2x") or src.get("large") or src.get("original")
    if not isinstance(image_url, str):
        raise ImageFetchError(
            f"Pexels result {index} for {query!r} missing src.large2x",
            source="pexels",
            query=query,
        )

    return _FetchResult(
        image_url=image_url,
        photographer=str(photo.get("photographer") or "Unknown"),
        photographer_url=str(photo.get("photographer_url") or "https://www.pexels.com"),
        source_url=str(photo.get("url") or "https://www.pexels.com"),
        file_extension="jpg",  # Pexels src.* URLs serve JPEG.
    )


def fetch_wikimedia(
    *,
    query: str,
    orientation: Orientation,
    index: int,
    min_width: int,
    timeout: float,
    client: httpx.Client | None = None,
) -> _FetchResult:
    """Look up `query` on Wikimedia Commons; return the `index`-th usable result.

    No API key — Wikimedia is open API. The `User-Agent` header is
    required by their policy.

    Two-call flow per https://commons.wikimedia.org/w/api.php:

    1. `action=query&list=search&srnamespace=6` — search the File: namespace.
    2. For the candidate file, `action=query&prop=imageinfo` to fetch the
       direct URL + `extmetadata` for licence + photographer.

    `orientation` is informational — the Commons API doesn't filter by
    aspect ratio. The fetcher applies a quality filter instead: skip
    files whose `imageinfo[0].width < {min}` (default 800 px) and skip
    SVG / TIFF / video formats. With those filters the result list is
    typically shorter than the raw search hits, so `index` is taken
    against the *filtered* list.

    Attribution metadata: `extmetadata.Artist.value` (sometimes HTML —
    we strip tags + decode entities), `extmetadata.LicenseShortName.value`
    for the licence label.
    """
    del orientation, min_width  # filter by quality, not aspect.

    headers = {"User-Agent": _WIKIMEDIA_USER_AGENT}

    # 1. Search the File: namespace. srlimit chosen to give us ~3x the
    #    requested index so we still find a usable result after the
    #    quality filter trims half.
    srlimit = max(10, (index + 1) * 3)
    search_payload = _request_json(
        client,
        _WIKIMEDIA_API_URL,
        params={
            "action": "query",
            "list": "search",
            "srnamespace": 6,
            "srsearch": query,
            "srlimit": srlimit,
            "format": "json",
        },
        headers=headers,
        timeout=timeout,
        source="wikimedia",
        query=query,
    )
    raw_search = (search_payload.get("query") or {}).get("search") or []
    if not isinstance(raw_search, list) or not raw_search:
        raise NoResultsError(
            f"Wikimedia returned no results for query {query!r}",
            source="wikimedia",
            query=query,
        )
    titles = [r.get("title") for r in raw_search if isinstance(r.get("title"), str)]
    if not titles:
        raise NoResultsError(
            f"Wikimedia search returned malformed results for query {query!r}",
            source="wikimedia",
            query=query,
        )

    # 2. Walk titles in order, asking imageinfo for each, applying the
    #    quality filter, picking the index-th passing result.
    passed = 0
    last_skip_reason = ""
    for title in titles:
        info = _wikimedia_image_info(
            title=title,
            client=client,
            headers=headers,
            timeout=timeout,
            query=query,
        )
        if info is None:
            last_skip_reason = "no imageinfo"
            continue
        url = info.get("url")
        width = info.get("width")
        if not isinstance(url, str) or not isinstance(width, int):
            last_skip_reason = "missing url/width"
            continue
        ext = url.rsplit(".", 1)[-1].lower() if "." in url else ""
        if ext in _WIKIMEDIA_REJECTED_EXTENSIONS:
            last_skip_reason = f"rejected extension {ext!r}"
            continue
        if width < _WIKIMEDIA_MIN_WIDTH_PX:
            last_skip_reason = f"width {width} < {_WIKIMEDIA_MIN_WIDTH_PX}"
            continue
        if passed < index:
            passed += 1
            continue

        artist_raw = (info.get("extmetadata") or {}).get("Artist") or {}
        artist = _strip_html(str(artist_raw.get("value") or "Unknown"))
        licence_raw = (info.get("extmetadata") or {}).get("LicenseShortName") or {}
        licence = html.unescape(str(licence_raw.get("value") or ""))
        # `descriptionurl` is the Commons File: page; falls back to a
        # constructed URL if the API omits it.
        source_url = str(
            info.get("descriptionurl")
            or f"https://commons.wikimedia.org/wiki/{title.replace(' ', '_')}"
        )
        # Normalise extension to jpg/png; default jpg for safety on
        # unusual cases (Commons URLs end with the actual extension).
        file_ext = "jpg" if ext in ("jpg", "jpeg", "") else "png" if ext == "png" else "jpg"
        return _FetchResult(
            image_url=url,
            photographer=artist,
            # Wikimedia doesn't expose a structured photographer URL;
            # the file's description page is the canonical place to
            # follow back to the artist's profile.
            photographer_url=source_url,
            source_url=source_url,
            file_extension=file_ext,
            licence=licence,
        )

    raise NoResultsError(
        f"Wikimedia: searched {len(titles)} title(s) for {query!r}; none passed the "
        f"quality filter (min width {_WIKIMEDIA_MIN_WIDTH_PX}px, no SVG/TIFF/video). "
        f"Last skip reason: {last_skip_reason or '(none)'}.",
        source="wikimedia",
        query=query,
    )


def _wikimedia_image_info(
    *,
    title: str,
    client: httpx.Client | None,
    headers: dict[str, str],
    timeout: float,
    query: str,
) -> dict[str, Any] | None:
    """Fetch `imageinfo` for a single Commons title; return the first
    `imageinfo` dict or None if the response shape is unexpected."""
    payload = _request_json(
        client,
        _WIKIMEDIA_API_URL,
        params={
            "action": "query",
            "prop": "imageinfo",
            "iiprop": "url|size|extmetadata",
            "iiurlwidth": 1920,
            "titles": title,
            "format": "json",
        },
        headers=headers,
        timeout=timeout,
        source="wikimedia",
        query=query,
    )
    pages = (payload.get("query") or {}).get("pages") or {}
    if not isinstance(pages, dict):
        return None
    # `pages` is keyed by page-id (or "-1" for missing). Take the first.
    for page in pages.values():
        if not isinstance(page, dict):
            continue
        infos = page.get("imageinfo")
        if isinstance(infos, list) and infos:
            first = infos[0]
            if isinstance(first, dict):
                return first
    return None


def _strip_html(value: str) -> str:
    """Strip HTML tags + decode entities from a Wikimedia metadata field.

    Wikimedia's `extmetadata.Artist.value` is sometimes a bare name,
    sometimes a `<a href="…">Jane Doe</a>` anchor, sometimes
    `Jane &amp; Doe` with HTML entities. Use a one-pass regex strip
    + `html.unescape` rather than pulling in a parser dep — the
    structures we hit are always simple enough.
    """
    import re

    no_tags = re.sub(r"<[^>]+>", "", value)
    return html.unescape(no_tags).strip()


def _request_json(
    client: httpx.Client | None,
    url: str,
    *,
    params: dict[str, Any],
    headers: dict[str, str],
    timeout: float,
    source: str,
    query: str,
) -> dict[str, Any]:
    """Run a GET, parse JSON, raise `ImageFetchError` on any failure.

    Accepts an optional preconstructed `httpx.Client` (used by tests
    to inject a `MockTransport`). When `client` is None, builds a
    one-shot client and closes it after the request.
    """
    if client is not None:
        return _do_get(client, url, params, headers, timeout, source, query)
    with httpx.Client(timeout=timeout) as fresh:
        return _do_get(fresh, url, params, headers, timeout, source, query)


def _do_get(
    client: httpx.Client,
    url: str,
    params: dict[str, Any],
    headers: dict[str, str],
    timeout: float,
    source: str,
    query: str,
) -> dict[str, Any]:
    try:
        resp = client.get(url, params=params, headers=headers, timeout=timeout)
    except httpx.HTTPError as exc:
        raise ImageFetchError(
            f"{source} request failed for {query!r}: {exc}",
            source=source,
            query=query,
        ) from exc
    if resp.status_code != 200:
        body_preview = resp.text[:300] if resp.text else ""
        raise ImageFetchError(
            f"{source} returned HTTP {resp.status_code} for {query!r}: {body_preview}",
            source=source,
            query=query,
        )
    try:
        data = resp.json()
    except ValueError as exc:
        raise ImageFetchError(
            f"{source} returned non-JSON body for {query!r}: {resp.text[:200]}",
            source=source,
            query=query,
        ) from exc
    if not isinstance(data, dict):
        raise ImageFetchError(
            f"{source} returned unexpected JSON shape for {query!r}: {type(data).__name__}",
            source=source,
            query=query,
        )
    return data


def download_image(
    image_url: str,
    target_path: os.PathLike[str],
    *,
    timeout: float,
    source: str,
    query: str,
    client: httpx.Client | None = None,
) -> None:
    """Download `image_url` to `target_path` atomically.

    Writes to `<target_path>.tmp` and renames on success so an
    interrupted download doesn't leave a half-finished image in the
    cache (which would still pass the cache-hit existence check on
    the next call).

    Wikimedia image downloads carry the same `User-Agent` as the
    API calls — Wikimedia's UA policy applies to all
    `*.wikimedia.org` requests including `upload.wikimedia.org`. The
    other backends use httpx's default UA (their CDNs don't gate on
    it).
    """
    from pathlib import Path

    target = Path(target_path)
    tmp = target.with_suffix(target.suffix + ".tmp")
    target.parent.mkdir(parents=True, exist_ok=True)

    headers: dict[str, str] = {"User-Agent": _WIKIMEDIA_USER_AGENT} if source == "wikimedia" else {}

    try:
        if client is not None:
            resp = client.get(image_url, timeout=timeout, headers=headers)
        else:
            with httpx.Client(timeout=timeout) as fresh:
                resp = fresh.get(image_url, timeout=timeout, headers=headers)
    except httpx.HTTPError as exc:
        raise ImageFetchError(
            f"{source} image download failed for {query!r}: {exc}",
            source=source,
            query=query,
        ) from exc
    if resp.status_code != 200:
        raise ImageFetchError(
            f"{source} image download returned HTTP {resp.status_code} for {query!r}",
            source=source,
            query=query,
        )

    tmp.write_bytes(resp.content)
    tmp.replace(target)
