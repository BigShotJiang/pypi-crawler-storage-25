"""Errors raised by the image-fetching helpers.

All extend `RuntimeError` to match the precedent set by
`addins/scaffold.py:ScaffoldError` — no shared `pptxforgeError` base
exists in the library today.
"""

from __future__ import annotations


class ImageFetchError(RuntimeError):
    """Base class for any failure inside `pptxforge.images.fetch_image`.

    Carries the originating `source` ("unsplash" / "pexels") and the
    `query` that triggered the call, plus the message describing what
    went wrong. Use as a catch-all for fetch retries:

        try:
            path = fetch_image(query, source="unsplash")
        except ImageFetchError as e:
            log.warning("first fetch failed: %s", e)
            path = fetch_image(query, source="pexels")
    """

    def __init__(self, message: str, *, source: str = "", query: str = "") -> None:
        super().__init__(message)
        self.source = source
        self.query = query


class APIKeyMissingError(ImageFetchError):
    """The required env var for `source` is not set.

    The error message names the env var and points the user at
    `setx` (Windows) or `export` (POSIX). Subclass of `ImageFetchError`
    so a single `except ImageFetchError` clause catches both
    auth-missing and on-the-wire failures.
    """


class NoResultsError(ImageFetchError):
    """The source returned an empty result set for `query`.

    Hit when:
    - The query is too narrow (no photographer has uploaded a match).
    - The query has spelling errors that the source doesn't fuzzy-match.
    - `index` is past the available result count for a small result set.

    Distinct from `ImageFetchError` so callers can fall back to a
    different source / broader query without catching genuine HTTP
    failures.
    """
