"""Persistent user configuration — TOML at the OS-appropriate location.

Two pieces of public surface:

- `get_api_key(source)` — returns the value of `<SOURCE>_ACCESS_KEY` /
  `<SOURCE>_API_KEY` from the environment, falling back to the config
  file. Env wins so users can temporarily override per-shell or per-
  project. Returns `None` if neither is set.
- `set_api_key(source, key)` — writes `key` to the config file under
  `[api_keys].<source>`. Creates the file (and parent directory) if
  needed. On POSIX, the file is chmod 0600 — user-only readable —
  because it stores secrets.

`config_path()` returns the path the helpers use, derived from
`platformdirs.user_config_dir("pptxforge")`. On Windows that's
`%APPDATA%\\pptxforge\\config.toml`; on macOS / Linux that's
`~/.config/pptxforge/config.toml` (overridable via `$XDG_CONFIG_HOME`).
"""

from __future__ import annotations

import os
import sys
from pathlib import Path
from typing import Any

import platformdirs

# tomllib is stdlib from 3.11; we still target 3.10+ so the
# `tomli; python_version < "3.11"` runtime dep covers that case
# transparently (same API).
if sys.version_info >= (3, 11):
    import tomllib
else:  # pragma: no cover — exercised on the py3.10 build only
    import tomli as tomllib

# Source name → env var that overrides the config file. We store keys
# under their source name (e.g. `[api_keys].unsplash`) but read the
# environment under the public env-var convention each provider
# documents (`UNSPLASH_ACCESS_KEY`, `PEXELS_API_KEY`). Wikimedia is
# absent because it requires no key.
_ENV_VARS: dict[str, str] = {
    "unsplash": "UNSPLASH_ACCESS_KEY",
    "pexels": "PEXELS_API_KEY",
}


def config_path() -> Path:
    """Return the path to `config.toml`. Doesn't create it.

    Resolved via `platformdirs.user_config_dir`:

    - Windows: `%APPDATA%\\pptxforge\\config.toml` (Roaming — survives
      profile sync). `appauthor=False` skips platformdirs' default
      author-name folder so the path stays one level deep.
    - macOS: `~/Library/Application Support/pptxforge/config.toml`.
    - Linux: `~/.config/pptxforge/config.toml`
      (or `$XDG_CONFIG_HOME/pptxforge/config.toml` if set).
    """
    return (
        Path(platformdirs.user_config_dir("pptxforge", appauthor=False, roaming=True))
        / "config.toml"
    )


def _read_config() -> dict[str, Any]:
    """Read the config file if present; return `{}` on missing / unreadable."""
    path = config_path()
    if not path.is_file():
        return {}
    try:
        with path.open("rb") as f:
            data: dict[str, Any] = tomllib.load(f)
            return data
    except (OSError, tomllib.TOMLDecodeError):
        # A malformed config file shouldn't break image fetching; the
        # env-var path still works, and `set_api_key` will overwrite.
        return {}


def get_api_key(source: str) -> str | None:
    """Return the key for `source` ("unsplash" / "pexels"), or None.

    Read order: environment variable first, then config file. Env wins
    so callers can override the persisted key per-shell without
    rewriting the file.

    Returns `None` for unknown source names — callers that pass a
    source that doesn't take a key (e.g. "wikimedia", "auto") expect
    None and skip the auth step. Doesn't raise.
    """
    env_var = _ENV_VARS.get(source)
    if env_var is not None:
        env_value = os.environ.get(env_var, "").strip()
        if env_value:
            return env_value

    cfg = _read_config()
    api_keys = cfg.get("api_keys") if isinstance(cfg, dict) else None
    if isinstance(api_keys, dict):
        value = api_keys.get(source)
        if isinstance(value, str) and value.strip():
            return value.strip()
    return None


def set_api_key(source: str, key: str) -> Path:
    """Write `key` to the config file under `[api_keys].{source}`.

    Creates parent directories as needed. On POSIX, chmods the file to
    0600 (user-only readable) since it stores secrets — the chmod is a
    no-op on Windows. Returns the path written.

    Preserves any other config sections / api keys already in the file
    so calling this twice for two different sources doesn't lose the
    first.
    """
    if source not in _ENV_VARS:
        raise ValueError(
            f"set_api_key: unknown source {source!r}; expected one of {sorted(_ENV_VARS.keys())}"
        )
    if not key or not key.strip():
        raise ValueError("set_api_key: key must be non-empty")

    path = config_path()
    path.parent.mkdir(parents=True, exist_ok=True)

    cfg = _read_config()
    api_keys = cfg.get("api_keys") if isinstance(cfg, dict) else None
    if not isinstance(api_keys, dict):
        api_keys = {}
        cfg["api_keys"] = api_keys
    api_keys[source] = key.strip()

    # Hand-render the TOML — stdlib has no writer in 3.10+ (tomllib is
    # read-only) and adding `tomli-w` for two lines of output isn't
    # worth a new dep. Section order is api_keys-first; future sections
    # would append.
    lines = ["# pptxforge config — secrets live here. chmod 0600 on POSIX.\n", "\n"]
    if isinstance(cfg.get("api_keys"), dict):
        lines.append("[api_keys]\n")
        for k, v in sorted(cfg["api_keys"].items()):
            # TOML basic-string with backslash + double-quote escapes.
            escaped = str(v).replace("\\", "\\\\").replace('"', '\\"')
            lines.append(f'{k} = "{escaped}"\n')
        lines.append("\n")
    path.write_text("".join(lines), encoding="utf-8")

    # 0600 only on POSIX — Windows ignores the mode bits and chmod
    # there has weird semantics; we let NTFS ACLs do their default
    # thing (user-only access in the typical case under %APPDATA%).
    if sys.platform != "win32":
        # Filesystem may not support chmod (e.g. WSL on a Windows
        # mount). Non-fatal — the key is still written.
        import contextlib

        with contextlib.suppress(OSError):
            path.chmod(0o600)

    return path


__all__ = ["config_path", "get_api_key", "set_api_key"]
