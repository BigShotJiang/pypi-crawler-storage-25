"""`Deck` — the top-level builder, plus `DeckValidationError`.

Phase 4 surface:

- `Deck(theme, aspect, template, ...)` initializes a themed python-pptx
  Presentation sized to the chosen aspect.
- `deck.add_slide(slide)` appends any `Slide` subclass.
- Ten convenience wrappers (`add_title_slide`, `add_content_slide`, ...)
  build one of the ten built-in slide types and append it.
- `deck.save(out_dir)` runs validation (renders every slide into a
  throwaway Presentation, catching `LayoutOverflowError` per slide),
  then writes `out_dir/deck.pptx` + `out_dir/README.md`.

Validation failures are aggregated and re-raised as a single
`DeckValidationError`; the output directory is not touched on failure.
"""

from collections.abc import Sequence
from dataclasses import dataclass, field
from datetime import date as _date
from pathlib import Path
from typing import Any, Literal

from pptx import Presentation
from pptx.util import Emu

from pptxforge.addins import TaskPane
from pptxforge.design import Theme
from pptxforge.layouts import Layout, LayoutOverflowError
from pptxforge.model3d import Camera
from pptxforge.slides import (
    AddInSlide,
    ClosingSlide,
    CodeSlide,
    ComparisonSide,
    ComparisonSlide,
    ContentSlide,
    Event,
    MediaSlide,
    Model3DSlide,
    QuoteSlide,
    SectionSlide,
    Slide,
    Stat,
    StatSlide,
    TimelineSlide,
    TitleSlide,
    Transition,
)
from pptxforge.slides.code import Language

Aspect = Literal["16:9", "4:3", "16:10"]


# Slide dimensions in EMU per aspect. Matches PowerPoint's standard values.
_ASPECT_DIMS: dict[Aspect, tuple[int, int]] = {
    "16:9": (12192000, 6858000),  # 13.333" x 7.5"
    "4:3": (9144000, 6858000),  # 10" x 7.5"
    "16:10": (12192000, 7620000),  # 13.333" x 8.333"
}


# ---------------------------------------------------------------------------
# Validation
# ---------------------------------------------------------------------------


@dataclass(frozen=True, slots=True)
class SlideValidationFailure:
    """One slide's failure collected during Deck.save's validation pass."""

    index: int
    slide_type: str
    exc: Exception


class DeckValidationError(ValueError):
    """Raised by `Deck.save` when one or more slides fail validation.

    Carries the list of per-slide failures on `.failures`. Message lists
    every offender with its index, slide-type, and the root exception —
    typically `LayoutOverflowError` with element and overflow details.

    Example:
        >>> try:
        ...     deck.save("out/")
        ... except DeckValidationError as e:
        ...     for f in e.failures:
        ...         print(f.index, f.slide_type, f.exc)
    """

    def __init__(self, failures: Sequence[SlideValidationFailure]) -> None:
        if not failures:
            raise ValueError("DeckValidationError requires at least one failure")
        self.failures = tuple(failures)
        lines = [f"Deck failed validation — {len(failures)} slide(s) could not be rendered:"]
        for f in failures:
            lines.append(f"  [slide {f.index}] {f.slide_type}: {f.exc}")
        super().__init__("\n".join(lines))


# ---------------------------------------------------------------------------
# Deck
# ---------------------------------------------------------------------------


@dataclass(slots=True)
class _DeckState:
    """Internal, mutable slide list kept off the public Deck surface."""

    slides: list[Slide] = field(default_factory=list)


_TransitionArg = Literal["none", "fade", "morph"] | Transition | None
_DeckTransitionArg = Literal["none", "fade", "morph"] | Transition | None


class Deck:
    """A presentation under construction.

    Use this as the entrypoint for every pptxforge program. Slides are
    populated via `add_slide(...)` or one of the ten `add_*_slide`
    convenience wrappers. Nothing touches disk until `save()`.

    Example:
        >>> from pptxforge import Deck, themes
        >>> from pptxforge.slides import Stat
        >>> deck = Deck(theme=themes.MIDNIGHT_EXECUTIVE)
        >>> deck.add_title_slide(title="Q1 Results", subtitle="Jane, 2026-05")
        >>> deck.add_stat_slide(stats=[
        ...     Stat(number="42%", label="Conversion lift"),
        ...     Stat(number="2.4s", label="P95 load time"),
        ... ])
        >>> deck.save("out/")
    """

    def __init__(
        self,
        *,
        theme: Theme,
        aspect: Aspect = "16:9",
        template: Path | str | None = None,
        title: str | None = None,
        author: str | None = None,
        task_pane: TaskPane | None = None,
        transition: "_DeckTransitionArg" = None,
    ) -> None:
        if aspect not in _ASPECT_DIMS:
            valid = sorted(_ASPECT_DIMS.keys())
            raise ValueError(f"unknown aspect {aspect!r}; valid: {valid}")
        if template is not None:
            template = Path(template)
            if not template.is_file():
                raise FileNotFoundError(f"template pptx not found: {template}")

        from pptxforge.transitions import coerce as _coerce_trans

        self._theme = theme
        self._aspect = aspect
        self._template = template
        self._title = title
        self._author = author
        self._task_pane = task_pane
        # Deck-wide default transition; slides that pass `transition=None`
        # (the Python default) inherit this. Slides that pass
        # `transition=transitions.None_()` explicitly opt out.
        self._default_transition = _coerce_trans(transition)
        self._state = _DeckState()

    # --- read-only access ----------------------------------------------------

    @property
    def theme(self) -> Theme:
        return self._theme

    @property
    def aspect(self) -> Aspect:
        return self._aspect

    @property
    def slides(self) -> Sequence[Slide]:
        return tuple(self._state.slides)

    @property
    def task_pane(self) -> TaskPane | None:
        return self._task_pane

    @property
    def default_transition(self) -> Transition | None:
        """The deck-wide default transition, or None."""
        return self._default_transition

    # --- mutation ------------------------------------------------------------

    def add_slide(self, slide: Slide) -> Slide:
        """Append any `Slide` subclass instance to the deck. Returns `slide`.

        Example:
            >>> class MySlide(Slide): ...
            >>> deck.add_slide(MySlide())
        """
        if not isinstance(slide, Slide):
            raise TypeError(
                f"add_slide expects a pptxforge.slides.Slide subclass instance, "
                f"got {type(slide).__name__}"
            )
        self._state.slides.append(slide)
        return slide

    # --- save ---------------------------------------------------------------

    def save(self, out_dir: Path | str) -> Path:
        """Validate and write the deck to `out_dir`.

        Produces:

        - `out_dir/deck.pptx` — the presentation.
        - `out_dir/README.md` — auto-generated deploy instructions skeleton.

        Runs a validation pass first: every slide is rendered into a
        throwaway python-pptx Presentation. `LayoutOverflowError`
        exceptions are collected and re-raised as a single
        `DeckValidationError`; the target directory is not touched.

        Returns the absolute path to the written `deck.pptx`.
        """
        out = Path(out_dir).resolve()

        prs = self._build_presentation()
        failures: list[SlideValidationFailure] = []
        blank_layout = prs.slide_layouts[6]

        pptx_slides: list[Any] = []
        for i, slide in enumerate(self._state.slides):
            pptx_slide = prs.slides.add_slide(blank_layout)
            pptx_slides.append(pptx_slide)
            try:
                slide.render(pptx_slide, self._theme)
            except LayoutOverflowError as exc:
                failures.append(
                    SlideValidationFailure(index=i, slide_type=type(slide).__name__, exc=exc)
                )
            if slide.notes:
                pptx_slide.notes_slide.notes_text_frame.text = slide.notes

        if failures:
            raise DeckValidationError(failures)

        # Transition emission — resolved per slide (slide's transition
        # wins over deck default). Runs after render so transitions that
        # inspect the rendered shape tree (e.g. Morph identity-overlap
        # warning) see the final state.
        self._apply_transitions(pptx_slides)

        out.mkdir(parents=True, exist_ok=True)
        pptx_path = out / "deck.pptx"
        prs.save(str(pptx_path))
        (out / "README.md").write_text(self._render_readme(), encoding="utf-8")
        return pptx_path

    def _apply_transitions(self, pptx_slides: list[Any]) -> None:
        """Emit the per-slide transition XML and warn on broken Morph pairs."""
        from pptxforge.morph import apply_transition_block
        from pptxforge.transitions import Morph

        for i, slide in enumerate(self._state.slides):
            effective = (
                slide.transition if slide.transition is not None else self._default_transition
            )
            if effective is None:
                continue

            # Morph warning: firing here so we catch it before PowerPoint
            # would silently fall back to fade. Only checks tier-1/2/3
            # pairing (explicit) — tier-4 geometric heuristics aren't
            # predictable from Python.
            if isinstance(effective, Morph) and i > 0:
                prev_pptx = pptx_slides[i - 1]
                curr_pptx = pptx_slides[i]
                if not _has_morph_pair(prev_pptx, curr_pptx):
                    import warnings

                    warnings.warn(
                        f"Slide {i} ({type(slide).__name__}) uses Morph but has no "
                        "shape-identity overlap with the previous slide — PowerPoint "
                        "will silently fall back to a fade. Share a stable_key on a "
                        "3D slide, `!!`-prefix a shape name, or give matching shapes "
                        "the same p:cNvPr/@name to pair them.",
                        category=UserWarning,
                        stacklevel=3,
                    )

            apply_transition_block(pptx_slides[i], effective)

    # --- internal ------------------------------------------------------------

    def _build_presentation(self) -> Any:
        prs = Presentation(str(self._template)) if self._template is not None else Presentation()
        w, h = _ASPECT_DIMS[self._aspect]
        prs.slide_width = Emu(w)
        prs.slide_height = Emu(h)
        if self._title:
            prs.core_properties.title = self._title
        if self._author:
            prs.core_properties.author = self._author
        return prs

    def _render_readme(self) -> str:
        today = _date.today().isoformat()
        lines = [
            "# Deck output",
            "",
            f"Built by pptxforge on {today}.",
            "",
            "## Contents",
            "",
            "- `deck.pptx` — the presentation. Open with PowerPoint on Windows",
            "  (primary target) or PowerPoint for Mac / the web (secondary).",
            "",
            "## Deploy / sideload instructions",
            "",
        ]
        if self._task_pane is not None or any(
            isinstance(s, AddInSlide) for s in self._state.slides
        ):
            lines.extend(
                [
                    "This deck uses Office Add-ins. Sideload instructions for "
                    "the manifests in this directory are generated when add-in ",
                    "artifacts land (Phase 3).",
                    "",
                ]
            )
        else:
            lines.extend(["_No add-ins in this deck._", ""])
        lines.extend(
            [
                "## Regenerate",
                "",
                "Re-run the deck's build script; `out/` is overwritten atomically.",
                "",
                f"Theme: **{self._theme.name}**",
                "",
            ]
        )
        return "\n".join(lines)

    # --- convenience methods (Phase 4) --------------------------------------

    def add_title_slide(
        self,
        *,
        title: str,
        subtitle: str | None = None,
        eyebrow: str | None = None,
        notes: str | None = None,
        transition: _TransitionArg = None,
    ) -> TitleSlide:
        """Cover slide. One per deck, as slide 0.

        Example:
            >>> deck.add_title_slide(title="Q1 Results", subtitle="Jane, 2026-05")
        """
        slide = TitleSlide(
            title=title,
            subtitle=subtitle,
            eyebrow=eyebrow,
            notes=notes,
            transition=transition,
        )
        self.add_slide(slide)
        return slide

    def add_section_slide(
        self,
        *,
        number: int | None,
        title: str,
        caption: str | None = None,
        notes: str | None = None,
        transition: _TransitionArg = None,
    ) -> SectionSlide:
        """A "Part N: Title" interstitial with oversized numeric anchor.

        Example:
            >>> deck.add_section_slide(number=2, title="Results")
        """
        slide = SectionSlide(
            number=number,
            title=title,
            caption=caption,
            notes=notes,
            transition=transition,
        )
        self.add_slide(slide)
        return slide

    def add_content_slide(
        self,
        *,
        title: str,
        layout: Layout,
        notes: str | None = None,
        transition: _TransitionArg = None,
        morph_from_previous: bool = False,
    ) -> ContentSlide:
        """Title + a caller-composed body layout.

        Example:
            >>> from pptxforge.layouts import Stack, Text
            >>> deck.add_content_slide(
            ...     title="Findings",
            ...     layout=Stack([
            ...         Text("- Latency down 30%", role="body"),
            ...         Text("- Cost down 12%", role="body"),
            ...     ], gap=0.15),
            ... )
        """
        slide = ContentSlide(
            title=title,
            layout=layout,
            notes=notes,
            transition=transition,
            morph_from_previous=morph_from_previous,
        )
        self.add_slide(slide)
        return slide

    def add_media_slide(
        self,
        *,
        title: str,
        media: Path | str,
        caption: str | None = None,
        side: Literal["left", "right"] = "left",
        notes: str | None = None,
        transition: _TransitionArg = None,
    ) -> MediaSlide:
        """Half-bleed image + titled caption panel.

        Example:
            >>> deck.add_media_slide(
            ...     title="Morphology under stress",
            ...     media=Path("fig-3.png"),
            ...     caption="Scanning electron micrograph, 500x.",
            ... )
        """
        slide = MediaSlide(
            title=title,
            media=media,
            caption=caption,
            side=side,
            notes=notes,
            transition=transition,
        )
        self.add_slide(slide)
        return slide

    def add_quote_slide(
        self,
        *,
        quote: str,
        attribution: str | None = None,
        notes: str | None = None,
        transition: _TransitionArg = None,
    ) -> QuoteSlide:
        """Editorial pull-quote with attribution.

        Example:
            >>> deck.add_quote_slide(quote="Ship it.", attribution="— Mgmt")
        """
        slide = QuoteSlide(
            quote=quote,
            attribution=attribution,
            notes=notes,
            transition=transition,
        )
        self.add_slide(slide)
        return slide

    def add_stat_slide(
        self,
        *,
        stats: Sequence[Stat],
        title: str | None = None,
        notes: str | None = None,
        transition: _TransitionArg = None,
    ) -> StatSlide:
        """A 2-6 KPI callout dashboard.

        Example:
            >>> from pptxforge.slides import Stat
            >>> deck.add_stat_slide(stats=[
            ...     Stat(number="42%", label="Conversion lift"),
            ...     Stat(number="2.4s", label="P95 load time"),
            ... ])
        """
        slide = StatSlide(
            stats=stats,
            title=title,
            notes=notes,
            transition=transition,
        )
        self.add_slide(slide)
        return slide

    def add_code_slide(
        self,
        *,
        title: str,
        code: str,
        lang: Language = "python",
        highlight_lines: Sequence[int] | None = None,
        notes: str | None = None,
        transition: _TransitionArg = None,
    ) -> CodeSlide:
        """Title + a mono code block on a surface card.

        Example:
            >>> deck.add_code_slide(title="Install",
            ...                     code="pip install pptxforge",
            ...                     lang="bash")
        """
        slide = CodeSlide(
            title=title,
            code=code,
            lang=lang,
            highlight_lines=highlight_lines,
            notes=notes,
            transition=transition,
        )
        self.add_slide(slide)
        return slide

    def add_comparison_slide(
        self,
        *,
        title: str,
        left: ComparisonSide,
        right: ComparisonSide,
        left_color: str = "primary",
        right_color: str = "accent",
        notes: str | None = None,
        transition: _TransitionArg = None,
    ) -> ComparisonSlide:
        """Title + two labeled columns (before/after, pros/cons).

        Example:
            >>> from pptxforge.slides import ComparisonSide
            >>> deck.add_comparison_slide(
            ...     title="Before / after",
            ...     left=ComparisonSide(header="Before", items=["Slow", "Manual"]),
            ...     right=ComparisonSide(header="After", items=["Fast", "Auto"]),
            ... )
        """
        slide = ComparisonSlide(
            title=title,
            left=left,
            right=right,
            left_color=left_color,
            right_color=right_color,
            notes=notes,
            transition=transition,
        )
        self.add_slide(slide)
        return slide

    def add_timeline_slide(
        self,
        *,
        title: str,
        events: Sequence[Event],
        notes: str | None = None,
        transition: _TransitionArg = None,
    ) -> TimelineSlide:
        """Title + a horizontal timeline of 2-5 events.

        Example:
            >>> from pptxforge.slides import Event
            >>> deck.add_timeline_slide(title="Roadmap", events=[
            ...     Event(when="Q1", title="Alpha"),
            ...     Event(when="Q2", title="Beta"),
            ...     Event(when="Q3", title="GA"),
            ... ])
        """
        slide = TimelineSlide(
            title=title,
            events=events,
            notes=notes,
            transition=transition,
        )
        self.add_slide(slide)
        return slide

    def add_3d_slide(
        self,
        *,
        title: str,
        model: Path | str,
        camera: Camera | None = None,
        orbit: bool = False,
        morph_from_previous: bool = False,
        preview: Path | str | None = None,
        stable_key: str | None = None,
        notes: str | None = None,
        transition: _TransitionArg = None,
    ) -> Model3DSlide:
        """A GLB 2.0 3D model slide. See `Model3DSlide` for the morph contract.

        Example:
            >>> from pptxforge.model3d import Camera
            >>> deck.add_3d_slide(
            ...     title="Aspirin",
            ...     model=Path("aspirin.glb"),
            ...     camera=Camera(azimuth=30, elevation=15),
            ...     stable_key="aspirin",
            ... )
        """
        slide = Model3DSlide(
            title=title,
            model=model,
            camera=camera,
            orbit=orbit,
            morph_from_previous=morph_from_previous,
            preview=preview,
            stable_key=stable_key,
            notes=notes,
            transition=transition,
        )
        self.add_slide(slide)
        return slide

    def add_closing_slide(
        self,
        *,
        message: str,
        call_to_action: str | None = None,
        notes: str | None = None,
        transition: _TransitionArg = None,
    ) -> ClosingSlide:
        """Dark-background final slide with a centered message.

        Example:
            >>> deck.add_closing_slide(
            ...     message="Thank you.",
            ...     call_to_action="questions@acme.com",
            ... )
        """
        slide = ClosingSlide(
            message=message,
            call_to_action=call_to_action,
            notes=notes,
            transition=transition,
        )
        self.add_slide(slide)
        return slide


# ---------------------------------------------------------------------------
# Shape-identity overlap — consumed by the Morph warning path in Deck.save.
# ---------------------------------------------------------------------------


def _has_morph_pair(prev_pptx_slide: Any, curr_pptx_slide: Any) -> bool:
    """Return True when `curr` shares an identity-level pairing with `prev`.

    Checks the three explicit tiers from research/morph.md §4:

    1. `!!`-prefixed `p:cNvPr/@name` match (forced pairing).
    2. `a16:creationId` GUID match.
    3. Plain `@name` match (no `!!`).

    Tier-4 geometry heuristics are unpredictable from Python alone and
    not checked — a false negative here triggers a UserWarning; a false
    positive (warning when PowerPoint WOULD have geometry-paired) is
    acceptable because the warning is advisory.
    """
    from pptxforge.model3d._xml import EXT_CREATION_ID, NS_A, NS_A16, NS_P

    def _collect(pptx_slide: Any) -> tuple[set[str], set[str]]:
        sp_tree = pptx_slide.shapes._spTree
        names: set[str] = set()
        creation_ids: set[str] = set()
        for cnv_pr in sp_tree.iter(f"{{{NS_P}}}cNvPr"):
            name = cnv_pr.get("name")
            if isinstance(name, str) and name:
                names.add(name)
            for ext in cnv_pr.iter(f"{{{NS_A}}}ext"):
                if ext.get("uri") != EXT_CREATION_ID:
                    continue
                cid = ext.find(f"{{{NS_A16}}}creationId")
                if cid is not None:
                    cid_val = cid.get("id")
                    if isinstance(cid_val, str):
                        creation_ids.add(cid_val)
        return names, creation_ids

    prev_names, prev_ids = _collect(prev_pptx_slide)
    curr_names, curr_ids = _collect(curr_pptx_slide)

    prev_bang = {n for n in prev_names if n.startswith("!!")}
    curr_bang = {n for n in curr_names if n.startswith("!!")}
    if prev_bang & curr_bang:
        return True

    if prev_ids & curr_ids:
        return True

    prev_plain = prev_names - prev_bang
    curr_plain = curr_names - curr_bang
    return bool(prev_plain & curr_plain)
