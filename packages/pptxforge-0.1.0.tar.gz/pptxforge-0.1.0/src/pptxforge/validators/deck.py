"""Pre-save deck-level validators.

Checks: empty decks, orphan add-ins, duplicate morph stable-keys, missing
raster fallbacks for 3D, etc. Runs during Deck.save phase 2.
"""

from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from pptxforge.deck import Deck


def validate_deck(deck: "Deck") -> None:
    """Raise `ValueError` on any pre-save validation failure."""
    raise NotImplementedError
