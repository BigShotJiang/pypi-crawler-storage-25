"""Emits `UserWarning` for Mac / Web / mobile degradation scenarios.

Per the ARCHITECTURE.md §8 compatibility contract: loud warnings, never
silent downgrades.
"""

from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from pptxforge.deck import Deck


def emit_platform_warnings(deck: "Deck", *, strict: bool) -> None:
    """Walk `deck`, emit a `UserWarning` per degraded platform surface.

    If `strict=True`, warnings are upgraded to `ValueError`.
    """
    raise NotImplementedError
