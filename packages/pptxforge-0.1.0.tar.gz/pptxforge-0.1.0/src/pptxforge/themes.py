"""`pptxforge.themes` — the ten built-in palettes.

Thin re-export of `pptxforge.design.themes`. Exposed at the top level so
that `from pptxforge import themes` and `themes.MIDNIGHT_EXECUTIVE` work
per the ARCHITECTURE.md contract.
"""

from pptxforge.design.themes import (
    ALL_THEMES,
    AMBER_EDITORIAL,
    BERRY_BOLD,
    CORAL_ENERGY,
    DEFAULT_RADII,
    DEFAULT_SPACING,
    DEFAULT_TYPE_SCALE,
    FOREST_MOSS,
    MIDNIGHT_EXECUTIVE,
    MONOCHROME_INK,
    PACIFIC_DEEP,
    ROYAL_PLUM,
    SLATE_MINIMALIST,
    SUNRISE_CITRUS,
    Palette,
    Radii,
    SpacingScale,
    Theme,
    TypeScale,
)

__all__ = [
    "Theme",
    "Palette",
    "TypeScale",
    "SpacingScale",
    "Radii",
    "DEFAULT_TYPE_SCALE",
    "DEFAULT_SPACING",
    "DEFAULT_RADII",
    "ALL_THEMES",
    "MIDNIGHT_EXECUTIVE",
    "FOREST_MOSS",
    "CORAL_ENERGY",
    "SLATE_MINIMALIST",
    "ROYAL_PLUM",
    "PACIFIC_DEEP",
    "MONOCHROME_INK",
    "AMBER_EDITORIAL",
    "SUNRISE_CITRUS",
    "BERRY_BOLD",
]
