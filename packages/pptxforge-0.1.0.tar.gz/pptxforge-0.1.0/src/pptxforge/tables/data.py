"""TableData value object."""

from collections.abc import Sequence
from pathlib import Path

from typing_extensions import Self

from pptxforge._types import EMU


class TableData:
    """Canonical table-data shape consumed by `TableSlide`.

    Construct via `TableData.from_csv(...)`, `TableData.from_rows(...)`, or
    `TableData.from_dataframe(...)` (requires pandas, optional). Immutable.

    Example:
        >>> TableData.from_rows(
        ...     header=["Quarter", "Revenue"],
        ...     rows=[["Q1", "$10M"], ["Q2", "$14M"]],
        ... )
    """

    @classmethod
    def from_rows(
        cls,
        *,
        header: Sequence[str],
        rows: Sequence[Sequence[str]],
    ) -> Self:
        """Build a table from explicit header + row lists of strings."""
        raise NotImplementedError

    @classmethod
    def from_csv(cls, path: Path | str) -> Self:
        """Load from a CSV file. First row is the header."""
        raise NotImplementedError

    @property
    def header(self) -> Sequence[str]:
        raise NotImplementedError

    @property
    def rows(self) -> Sequence[Sequence[str]]:
        raise NotImplementedError

    @property
    def column_widths(self) -> Sequence[EMU] | None:
        raise NotImplementedError
