"""Table data model."""

from pptxforge.tables.data import TableData

__all__ = ["TableData"]
