"""pptxforge — opinionated `.pptx` generator.

See ARCHITECTURE.md at the repo root for the public-API contract.
"""

from pptxforge import addins, layouts, themes
from pptxforge.cinematic import FlightWaypoint, model3d_flight
from pptxforge.deck import Deck
from pptxforge.layouts import (
    Callout,
    Card,
    CardGrid,
    LabeledScale,
    ScaleMarker,
    ScaleZone,
    StatRow,
    StatRowStat,
)

__version__ = "0.1.0"

__all__ = [
    "Deck",
    "themes",
    "layouts",
    "addins",
    "__version__",
    # Visual primitives shortcut: `from pptxforge import LabeledScale, ...`.
    "LabeledScale",
    "ScaleZone",
    "ScaleMarker",
    "CardGrid",
    "Card",
    "Callout",
    "StatRow",
    "StatRowStat",
    # Cinematic helpers worth reaching for from the top level.
    "model3d_flight",
    "FlightWaypoint",
]
