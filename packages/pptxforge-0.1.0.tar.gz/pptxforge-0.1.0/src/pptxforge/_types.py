"""Common type aliases used across pptxforge."""

from typing import TypeAlias

EMU: TypeAlias = int
"""English Metric Unit. 914400 per inch, 360000 per cm, 12700 per point."""

StableKey: TypeAlias = str
"""User-chosen string that hashes deterministically into an `a16:creationId`."""

ColorHex: TypeAlias = str
"""`#RRGGBB` hex string. Use `design.Color.from_hex(...)` to construct."""
