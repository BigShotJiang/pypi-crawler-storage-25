"""Native `c:chart` emission via python-pptx's chart APIs."""

from typing import TYPE_CHECKING

from pptxforge.charts.data import ChartData

if TYPE_CHECKING:
    from lxml import etree


def emit_core_chart(
    chart_type: str,
    data: ChartData,
) -> "etree._Element":
    """Build a `<c:chart>` subtree for one of the core chart types
    (`bar`, `column`, `line`, `pie`, `scatter`, `area`, `radar`).
    """
    raise NotImplementedError
