"""Chart data model and emission routers."""

from pptxforge.charts.data import ChartData

__all__ = ["ChartData"]
