"""`cx:chartSpace` emission for chartex types (waterfall, funnel, treemap, etc.).

See `research/python-pptx-extensions.md` §4.4 for the injection mechanics.
"""

from typing import TYPE_CHECKING

from pptxforge.charts.data import ChartData

if TYPE_CHECKING:
    from lxml import etree


def emit_chartex(
    chart_type: str,
    data: ChartData,
) -> "etree._Element":
    """Build a `<cx:chartSpace>` subtree for a chartex type
    (`waterfall`, `funnel`, `treemap`, `sunburst`, `histogram`, `box`, `map`).
    """
    raise NotImplementedError
