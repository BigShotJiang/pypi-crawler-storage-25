"""ChartData value object."""

from collections.abc import Mapping, Sequence
from pathlib import Path

from typing_extensions import Self


class ChartData:
    """Canonical chart-data shape consumed by `ChartSlide`.

    Construct via `ChartData.from_dict(...)`, `ChartData.from_csv(...)`, or
    directly with series. Immutable; transformations return new instances.

    Example:
        >>> ChartData.from_dict({"Jan": 10, "Feb": 14, "Mar": 21})
    """

    @classmethod
    def from_dict(cls, data: Mapping[str, float]) -> Self:
        """Build a single-series chart from category → value."""
        raise NotImplementedError

    @classmethod
    def from_csv(cls, path: Path | str, *, header: bool = True) -> Self:
        """Load chart data from a CSV file. First column = categories;
        remaining columns = series.
        """
        raise NotImplementedError

    @property
    def categories(self) -> Sequence[str]:
        raise NotImplementedError

    @property
    def series(self) -> Mapping[str, Sequence[float]]:
        raise NotImplementedError
