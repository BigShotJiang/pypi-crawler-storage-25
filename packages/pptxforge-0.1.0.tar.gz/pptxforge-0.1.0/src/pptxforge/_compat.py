"""Namespace-map patches applied once at pptxforge import time.

Per `research/python-pptx-extensions.md` §2.1: python-pptx's `_nsmap` must be
extended before any code uses `qn("prefix:...")` for pptxforge's extension
prefixes (`we`, `am3d`, `a3danim`, `p159`, etc.). This module does the mutation
exactly once, at pptxforge package import.
"""


def apply_namespace_patches() -> None:
    """Register pptxforge's extension namespaces in python-pptx's `_nsmap`.

    Idempotent: safe to call more than once, but `pptxforge/__init__.py`
    calls it exactly once at import.
    """
    raise NotImplementedError
