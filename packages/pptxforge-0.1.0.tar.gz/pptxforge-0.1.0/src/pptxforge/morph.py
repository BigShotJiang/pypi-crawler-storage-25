"""Morph-specific helpers — creationId + `!!` tag + inline morph trigger.

Morph has two pieces of state beyond the transition itself:

- `ensure_creation_id(cnv_pr, stable_key)` stamps a deterministic
  `a16:creationId` under `<p:cNvPr>` — PowerPoint's tier-2 shape-pairing
  key (research/morph.md §4.2).
- `set_morph_tag(shape, tag)` rewrites `<p:cNvPr @name>` to `!!<tag>` —
  PowerPoint's tier-1 forced-pairing key (research/morph.md §4.1).

Transition XML emission itself moved to `pptxforge.transitions` in
Phase 6; this module now only owns the identity-stamping helpers.
`apply_transition_block(pptx_slide, transition)` is the low-level
per-slide injector, re-exported here for callers (e.g. Deck.save) that
need to emit transitions outside Deck's default path.
"""

from typing import Any, Literal
from uuid import UUID, uuid5

from lxml import etree

from pptxforge.model3d._xml import (
    EXT_CREATION_ID,
    NS_A,
    NS_A16,
    NS_MC,
    NS_P,
    braced_guid,
)
from pptxforge.model3d.writer import PPTXFORGE_UUID_NAMESPACE
from pptxforge.transitions import Morph, Transition

# NS_P14 / NS_P159 are carried in pptxforge.transitions now.

MorphOption = Literal["byObject", "byWord", "byChar"]


def apply_transition_block(pptx_slide: Any, transition: Transition | None) -> None:
    """Inject `transition`'s XML into `pptx_slide` (or strip any prior).

    Idempotent: always removes any existing `<p:transition>` or
    transition-carrying `<mc:AlternateContent>` block first, then
    appends the new one at the ECMA-376 child-order position
    (between `<p:clrMapOvr>` and `<p:timing>`).

    If `transition` is None or the transition's `to_xml_block()` returns
    None (e.g. `None_()`), the slide ends up with no transition element.
    """
    sld = pptx_slide.part._element
    _remove_existing_transition_blocks(sld)
    if transition is None:
        return
    block = transition.to_xml_block()
    if block is None:
        return
    sld.insert(_transition_insert_index(sld), block)


def apply_morph_transition(
    pptx_slide: Any,
    *,
    duration_ms: int = 2000,
    option: MorphOption = "byObject",
) -> None:
    """Legacy helper — emits a `<mc:AlternateContent>` morph block on a slide.

    Kept as a thin convenience wrapper; new code should pass a
    `pptxforge.transitions.Morph(duration=..., match=...)` via a slide's
    `transition=` kwarg and let Deck.save apply it.
    """
    apply_transition_block(pptx_slide, Morph(duration=duration_ms / 1000, match=option))


def enable_morph(
    slide: Any,
    *,
    option: MorphOption = "byObject",
    duration_ms: int = 2000,
) -> None:
    """Set a pptxforge `Slide`'s transition to Morph, or apply directly on pptx slide.

    - If `slide` is a `pptxforge.slides.Slide`: sets `slide.transition`
      to a `Morph(...)` instance. Deck.save emits it during the save pass.
    - If `slide` is a python-pptx slide: writes the XML immediately via
      `apply_morph_transition`.
    """
    from pptxforge.slides._base import Slide

    if isinstance(slide, Slide):
        slide.transition = Morph(duration=duration_ms / 1000, match=option)
        return
    apply_morph_transition(slide, duration_ms=duration_ms, option=option)


def set_morph_tag(shape: Any, tag: str) -> None:
    """Rewrite a shape's `p:cNvPr/@name` to `!!<tag>`.

    The `!!` prefix is morph's tier-1 pairing key per research/morph.md
    §4.1 — shapes with matching `!!`-prefixed names morph across slides
    regardless of type or geometry.
    """
    cnv_pr = _find_cnv_pr(shape)
    if cnv_pr is None:
        raise ValueError(f"set_morph_tag: shape {type(shape).__name__} has no p:cNvPr child")
    cnv_pr.set("name", f"!!{tag}")


def ensure_creation_id(cnv_pr: Any, *, stable_key: str | None = None) -> UUID:
    """Guarantee `<a16:creationId>` exists under `cnv_pr`'s `<a:extLst>`.

    If `stable_key` is given, the UUID is derived deterministically
    (UUIDv5 under the pptxforge namespace) so the same key yields the
    same creationId across builds — the key PowerPoint pairs on
    (research/morph.md §4.2). Otherwise a fresh random UUID is stamped.

    Returns the resolved UUID.
    """
    guid = (
        uuid5(PPTXFORGE_UUID_NAMESPACE, stable_key)
        if stable_key is not None
        else _new_creation_id()
    )

    # Locate (or create) the <a:extLst> child.
    ext_lst = cnv_pr.find(f"{{{NS_A}}}extLst")
    if ext_lst is None:
        ext_lst = etree.SubElement(cnv_pr, f"{{{NS_A}}}extLst")

    # Locate (or create) the <a:ext uri="{creationId-guid}"> wrapper.
    target_ext: etree._Element | None = None
    for ext in ext_lst.findall(f"{{{NS_A}}}ext"):
        if ext.get("uri") == EXT_CREATION_ID:
            target_ext = ext
            break
    if target_ext is None:
        target_ext = etree.SubElement(ext_lst, f"{{{NS_A}}}ext", attrib={"uri": EXT_CREATION_ID})

    # Replace any prior creationId with the new one.
    for child in list(target_ext):
        target_ext.remove(child)
    etree.SubElement(
        target_ext,
        f"{{{NS_A16}}}creationId",
        attrib={"id": braced_guid(guid)},
        nsmap={"a16": NS_A16},
    )
    return guid


# ---------------------------------------------------------------------------
# Internals
# ---------------------------------------------------------------------------


def _new_creation_id() -> UUID:
    from uuid import uuid4

    return uuid4()


def _find_cnv_pr(shape: Any) -> Any:
    """Best-effort locate the `<p:cNvPr>` under a python-pptx shape."""
    elem = shape._element if hasattr(shape, "_element") else shape
    for path in (
        f"{{{NS_P}}}nvSpPr/{{{NS_P}}}cNvPr",
        f"{{{NS_P}}}nvPicPr/{{{NS_P}}}cNvPr",
        f"{{{NS_P}}}nvGraphicFramePr/{{{NS_P}}}cNvPr",
        f"{{{NS_P}}}nvCxnSpPr/{{{NS_P}}}cNvPr",
        f"{{{NS_P}}}nvGrpSpPr/{{{NS_P}}}cNvPr",
    ):
        cnv = elem.find(path)
        if cnv is not None:
            return cnv
    return None


def _remove_existing_transition_blocks(sld: etree._Element) -> None:
    """Drop any prior `<p:transition>` or `<mc:AlternateContent>` transition."""
    for child in list(sld):
        tag = child.tag
        if tag == f"{{{NS_P}}}transition":
            sld.remove(child)
        elif tag == f"{{{NS_MC}}}AlternateContent" and (
            child.find(f".//{{{NS_MC}}}Choice/{{{NS_P}}}transition") is not None
            or child.find(f".//{{{NS_MC}}}Fallback/{{{NS_P}}}transition") is not None
        ):
            # A transition-carrying AlternateContent — drop it.
            sld.remove(child)


def _transition_insert_index(sld: etree._Element) -> int:
    """Index at which to insert the transition — after clrMapOvr, before timing."""
    # Child order per ECMA-376 CT_Slide: cSld, clrMapOvr, transition, timing, extLst.
    child_tags = [c.tag for c in sld]
    # Prefer: right after clrMapOvr if present.
    for i, tag in enumerate(child_tags):
        if tag == f"{{{NS_P}}}clrMapOvr":
            return i + 1
    # Otherwise: before timing/extLst if present.
    for i, tag in enumerate(child_tags):
        if tag in {f"{{{NS_P}}}timing", f"{{{NS_P}}}extLst"}:
            return i
    # Fall through: append at the end.
    return len(child_tags)
