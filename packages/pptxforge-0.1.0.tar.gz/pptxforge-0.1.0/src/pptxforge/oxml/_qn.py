"""Qualified-name helpers."""


def qn(prefix_tag: str) -> str:
    """Expand `"prefix:local"` to `"{uri}local"` using the pptxforge namespace map.

    Example: `qn("p159:morph") == "{http://schemas.microsoft.com/office/powerpoint/2015/09/main}morph"`
    """
    raise NotImplementedError
