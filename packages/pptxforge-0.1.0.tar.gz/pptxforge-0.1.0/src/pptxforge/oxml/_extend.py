"""Low-level primitives for adding OPC parts, relationships, and non-standard XML."""

from collections.abc import Iterable, Mapping
from typing import TYPE_CHECKING, Any

if TYPE_CHECKING:
    from lxml import etree


def add_part(
    package: Any,
    partname: Any,
    content_type: str,
    *,
    blob: bytes | None = None,
    element: "etree._Element | None" = None,
) -> Any:
    """Construct and attach a new `Part` to `package`.

    Exactly one of `blob` or `element` must be provided. If `element` is given,
    an `XmlPart` is returned whose `._element` is `element`; otherwise a plain
    `Part` with the given `blob` is returned.

    The returned part is **not yet reachable** from the package relationship
    graph — the caller MUST immediately call `add_relationship(...)` from some
    already-reachable source, or the part will be silently dropped at
    `package.save()` time.

    `partname` must begin with `/`. Caller is responsible for uniqueness; use
    `next_partname` for the common numbered pattern.
    """
    raise NotImplementedError


def next_partname(package: Any, template: str) -> Any:
    """Return the next unused partname matching `template`.

    `template` is a printf-style string with exactly one `%d`, e.g.
    `"/ppt/webextensions/webextension%d.xml"`.
    """
    raise NotImplementedError


def add_relationship(
    source: Any,
    target: "Any | str",
    reltype: str,
    *,
    is_external: bool = False,
) -> str:
    """Relate `source` to `target`. Returns the assigned `rId`.

    `target` is a `Part` for internal relationships or a URL `str` for external
    (in which case `is_external=True` is required).

    Idempotent: if an identical relationship already exists, the existing `rId`
    is returned rather than adding a duplicate.
    """
    raise NotImplementedError


def sub_element(
    parent: "etree._Element",
    nsptag: str,
    *,
    attrib: Mapping[str, str] | None = None,
    text: str | None = None,
    nsmap: Mapping[str, str] | None = None,
) -> "etree._Element":
    """Append a new child element to `parent` with prefix-qualified tag `nsptag`.

    `nsptag` is `"prefix:local"`. If `prefix` is already in python-pptx's
    `_nsmap` (either natively or via a prior `register_namespace` call), the
    prefix/URI mapping is resolved automatically. If it is not, `nsmap` MUST
    be supplied and include the prefix.
    """
    raise NotImplementedError


def insert_in_seq(
    parent: "etree._Element",
    new_child: "etree._Element",
    seq: Iterable[str],
) -> "etree._Element":
    """Insert `new_child` into `parent` honoring python-pptx's tag sequence.

    `seq` is the ordered iterable of qualified tag names as used in
    `pptx.oxml.xmlchemy._tag_seq` (e.g. `("p:cSld", "p:clrMapOvr",
    "p:transition", "p:timing", "p:extLst")`). `new_child`'s qualified tag
    must be somewhere in `seq`. Returns `new_child` for chaining.
    """
    raise NotImplementedError


def add_extlst_ext(
    owner: "etree._Element",
    uri_guid: str,
    inner: "etree._Element",
    *,
    extlst_tag: str = "p:extLst",
) -> "etree._Element":
    """Append `<p:ext uri="{uri_guid}">{inner}</p:ext>` under `owner`'s `p:extLst`.

    Creates the `p:extLst` container if missing. Used for every feature that
    piggybacks on the OOXML extension mechanism: Office Add-in slide refs,
    slide zoom, morph, embedded 3D.
    """
    raise NotImplementedError
