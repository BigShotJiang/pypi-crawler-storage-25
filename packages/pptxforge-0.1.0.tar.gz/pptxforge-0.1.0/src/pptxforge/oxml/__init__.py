"""Low-level OOXML injection primitives.

See `research/python-pptx-extensions.md` §3 for the helper contracts.
"""

from pptxforge.oxml._extend import (
    add_extlst_ext,
    add_part,
    add_relationship,
    insert_in_seq,
    next_partname,
    sub_element,
)
from pptxforge.oxml._ns import register_namespace

__all__ = [
    "register_namespace",
    "add_part",
    "next_partname",
    "add_relationship",
    "sub_element",
    "insert_in_seq",
    "add_extlst_ext",
]
