"""Namespace registry and registration helpers.

Mutating `pptx.oxml.ns._nsmap` is load-bearing for every pptxforge feature
that touches a non-standard namespace (we, am3d, a3danim, p159, a16, ...).
See `research/python-pptx-extensions.md` §2.1.
"""

NAMESPACES: dict[str, str] = {
    "mc": "http://schemas.openxmlformats.org/markup-compatibility/2006",
    "p14": "http://schemas.microsoft.com/office/powerpoint/2010/main",
    "p159": "http://schemas.microsoft.com/office/powerpoint/2015/09/main",
    "p15": "http://schemas.microsoft.com/office/powerpoint/2012/main",
    "we": "http://schemas.microsoft.com/office/webextensions/webextension/2010/11",
    "am3d": "http://schemas.microsoft.com/office/drawing/2017/model3d",
    "a3danim": "http://schemas.microsoft.com/office/drawing/2018/animation/model3d",
    "aanim": "http://schemas.microsoft.com/office/drawing/2018/animation",
    "a14": "http://schemas.microsoft.com/office/drawing/2010/main",
    "a16": "http://schemas.microsoft.com/office/drawing/2014/main",
}


def register_namespace(prefix: str, uri: str) -> None:
    """Register `prefix` → `uri` in python-pptx's module-level namespace map.

    Idempotent: re-registering the same prefix with the same URI is a no-op;
    re-registering with a different URI raises `ValueError` (caller almost
    certainly has a typo; silent override would be a debugging nightmare).

    Must be called before any python-pptx code uses `qn("prefix:...")` with
    the new prefix. Call once at pptxforge import time from `pptxforge._compat`.
    """
    raise NotImplementedError
