"""CardGrid - a row/grid of cards for "three things to know" content.

Used when the alternative would be a bullet list at the same level of
abstraction. Each card has: a tinted background, optional big number /
country tag at the top, a bold short title, and a body sentence.
`accent_first=True` swaps the first card's background to the accent
tint so the deck has a focal card.
"""

from __future__ import annotations

import textwrap
from collections.abc import Sequence
from dataclasses import dataclass
from typing import TYPE_CHECKING, Any

from pptxforge.layouts._base import EMU_PER_INCH, Layout, LayoutOverflowError, Region
from pptxforge.layouts._rendering import add_rect, add_textbox, resolve_type_step
from pptxforge.layouts._tokens import resolve_token, slide_background, tint

if TYPE_CHECKING:
    from pptxforge.design import Theme


@dataclass(frozen=True, slots=True)
class Card:
    """One cell in a `CardGrid`.

    Attributes:
        title: Bold one-line label (~14 pt).
        body: One short paragraph below the title (~12 pt, muted).
        number: Optional big numeral / short label rendered top-left in the
            accent colour (~36 pt). Use for "1, 2, 3" rhythm or "0.5%".
        tag: Optional small pill rendered top-right (~9 pt). Use for
            country codes, dates, status flags.
    """

    title: str
    body: str
    number: str | None = None
    tag: str | None = None


class CardGrid(Layout):
    """A grid of `Card`s with tinted backgrounds.

    Reach for this when the alternative is a Stack of Texts at the
    same level of abstraction. The cards' geometric repetition is what
    communicates "these are three peers" without spelling it out.

    Example:
        >>> CardGrid([
        ...     Card("EU", "Approved as E472c.", tag="EU", number=None),
        ...     Card("USA", "GRAS per 21 CFR 172.832.", tag="USA", number=None),
        ... ], columns=2, accent_first=False)
    """

    _GAP_IN = 0.25
    _CORNER_IN = 0.15
    _PAD_IN = 0.30
    _NUMBER_TINT_FRACTION = 0.78  # base card tint (78% toward background)
    _ACCENT_TINT_FRACTION = 0.62  # accent_first cards: stronger fill
    _NUMBER_SIZE_PT = 36.0
    _TITLE_SIZE_PT = 14.0
    _BODY_SIZE_PT = 12.0
    _TAG_SIZE_PT = 9.0
    _NUMBER_BAND_HEIGHT_IN = 0.6
    _TITLE_BAND_HEIGHT_IN = 0.36
    _TAG_HEIGHT_IN = 0.28
    _TAG_PAD_PT = 6.0

    def __init__(
        self,
        cards: Sequence[Card],
        *,
        columns: int = 3,
        accent_first: bool = False,
    ) -> None:
        if not cards:
            raise ValueError("CardGrid requires at least one Card")
        if columns <= 0:
            raise ValueError(f"CardGrid: columns must be positive, got {columns}")
        if len(cards) > columns * 4:  # arbitrary sanity ceiling
            raise ValueError(f"CardGrid: {len(cards)} cards in {columns}-column grid is excessive")
        self.cards = tuple(cards)
        self.columns = columns
        self.accent_first = accent_first

    @property
    def rows(self) -> int:
        return (len(self.cards) + self.columns - 1) // self.columns

    def render(self, slide: Any, region: Region, theme: Theme) -> Region:
        gap_emu = int(self._GAP_IN * EMU_PER_INCH)
        cols = min(self.columns, len(self.cards))
        rows = self.rows
        total_col_gap = gap_emu * (cols - 1)
        total_row_gap = gap_emu * (rows - 1)
        if total_col_gap > region.w:
            raise LayoutOverflowError(
                element=f'CardGrid({cols} cols, gap={self._GAP_IN}")',
                required_emu=(total_col_gap, region.h),
                region_emu=(region.w, region.h),
                axis="width",
            )
        cell_w = (region.w - total_col_gap) // cols
        cell_h = (region.h - total_row_gap) // max(1, rows)

        # Up-front overflow check: confirm each card's static contents fit.
        for card in self.cards:
            self._check_card_fits(card, cell_w, cell_h)

        bg = slide_background(theme)
        surface = resolve_token(theme, "surface.muted")
        accent = resolve_token(theme, "accent.key")
        text_primary = resolve_token(theme, "text_primary")
        text_muted = resolve_token(theme, "text.muted")
        divider = resolve_token(theme, "divider")

        base_fill = tint(surface, bg, 0.0)  # surface tone, no extra mix
        accent_fill = tint(accent, bg, self._ACCENT_TINT_FRACTION)

        body_step = resolve_type_step(theme, "body")

        for i, card in enumerate(self.cards):
            col = i % cols
            row = i // cols
            cx = region.x + col * (cell_w + gap_emu)
            cy = region.y + row * (cell_h + gap_emu)
            cell = Region(x=cx, y=cy, w=cell_w, h=cell_h)
            is_accent = bool(self.accent_first and i == 0)
            fill = accent_fill if is_accent else base_fill

            corner_emu = int(self._CORNER_IN * EMU_PER_INCH)
            add_rect(
                slide,
                cell,
                fill_token=fill,
                stroke_token=None if is_accent else divider,
                stroke_width_pt=0.5,
                kind="roundrect",
                corner_radius_emu=corner_emu,
            )

            inner = cell.padded(inches=self._PAD_IN)

            # Card text colours: body text on the accent variant flips to
            # the slide background tone for contrast.
            on_accent_color = bg if is_accent else text_primary
            on_accent_muted = bg if is_accent else text_muted
            number_color = bg if is_accent else accent

            cursor_y = inner.y

            # Number band (top-left).
            number_band_h = int(self._NUMBER_BAND_HEIGHT_IN * EMU_PER_INCH)
            if card.number is not None:
                add_textbox(
                    slide,
                    Region(x=inner.x, y=cursor_y, w=inner.w, h=number_band_h),
                    text=card.number,
                    stack=theme.typography.display,
                    size_pt=self._NUMBER_SIZE_PT,
                    color_token=number_color,
                    bold=True,
                    align="left",
                    anchor="top",
                    line_height=1.0,
                )
                cursor_y += number_band_h

            # Tag pill (top-right of the card, independent of the number).
            if card.tag is not None:
                tag_w = int(0.7 * EMU_PER_INCH)
                tag_h = int(self._TAG_HEIGHT_IN * EMU_PER_INCH)
                tag_x = cell.x + cell.w - tag_w - int(self._PAD_IN * EMU_PER_INCH)
                tag_y = cell.y + int(self._PAD_IN * EMU_PER_INCH)
                add_rect(
                    slide,
                    Region(x=tag_x, y=tag_y, w=tag_w, h=tag_h),
                    fill_token=tint(accent, bg, 0.55) if not is_accent else tint(bg, accent, 0.4),
                    stroke_token=None,
                    kind="roundrect",
                    corner_radius_emu=tag_h // 2,
                )
                add_textbox(
                    slide,
                    Region(x=tag_x, y=tag_y, w=tag_w, h=tag_h),
                    text=card.tag,
                    stack=theme.typography.body,
                    size_pt=self._TAG_SIZE_PT,
                    color_token=on_accent_color if is_accent else accent,
                    bold=True,
                    align="center",
                    anchor="middle",
                    line_height=1.0,
                )

            # Title.
            title_band_h = int(self._TITLE_BAND_HEIGHT_IN * EMU_PER_INCH)
            add_textbox(
                slide,
                Region(x=inner.x, y=cursor_y, w=inner.w, h=title_band_h),
                text=card.title,
                stack=theme.typography.body,
                size_pt=self._TITLE_SIZE_PT,
                color_token=on_accent_color,
                bold=True,
                align="left",
                anchor="top",
                line_height=body_step.line_height,
            )
            cursor_y += title_band_h

            # Body.
            body_h = max(0, inner.y + inner.h - cursor_y)
            add_textbox(
                slide,
                Region(x=inner.x, y=cursor_y, w=inner.w, h=body_h),
                text=card.body,
                stack=theme.typography.body,
                size_pt=self._BODY_SIZE_PT,
                color_token=on_accent_muted,
                align="left",
                anchor="top",
                line_height=body_step.line_height,
            )

        return region

    @classmethod
    def _check_card_fits(cls, card: Card, cell_w_emu: int, cell_h_emu: int) -> None:
        """Heuristic overflow detection: longest body line vs cell width and height."""
        # Available width inside the inner padded region.
        pad_emu = int(cls._PAD_IN * EMU_PER_INCH)
        avail_w_emu = cell_w_emu - 2 * pad_emu
        if avail_w_emu <= 0:
            raise LayoutOverflowError(
                element=f"CardGrid({card.title!r})",
                required_emu=(2 * pad_emu, cell_h_emu),
                region_emu=(cell_w_emu, cell_h_emu),
                axis="width",
            )
        # Body width estimate at 12pt body, average char ratio 0.55.
        avg_char_pt = cls._BODY_SIZE_PT * 0.55
        chars_per_line = max(1, int(avail_w_emu / 12700 / avg_char_pt))
        body_lines = sum(
            max(1, len(textwrap.wrap(p, width=chars_per_line, break_long_words=False)))
            for p in card.body.split("\n")
        )
        body_height_pt = body_lines * cls._BODY_SIZE_PT * 1.5
        # Reserve title + (number band if present) above the body.
        title_height_pt = cls._TITLE_BAND_HEIGHT_IN * 72
        number_height_pt = cls._NUMBER_BAND_HEIGHT_IN * 72 if card.number is not None else 0
        required_h_pt = body_height_pt + title_height_pt + number_height_pt + (cls._PAD_IN * 2 * 72)
        required_h_emu = int(required_h_pt * 12700)
        if required_h_emu > cell_h_emu:
            raise LayoutOverflowError(
                element=f"CardGrid card {card.title!r} (body too tall)",
                required_emu=(cell_w_emu, required_h_emu),
                region_emu=(cell_w_emu, cell_h_emu),
                axis="height",
            )
