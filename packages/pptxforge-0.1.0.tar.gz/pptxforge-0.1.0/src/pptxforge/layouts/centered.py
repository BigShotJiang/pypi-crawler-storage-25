"""Center a child inside a region."""

from typing import TYPE_CHECKING, Any

from pptxforge.layouts._base import Layout, LayoutOverflowError, Region

if TYPE_CHECKING:
    from pptxforge.design import Theme


class Centered(Layout):
    """Center `child` inside the region.

    If `child.measure(theme)` returns an intrinsic size, the child is
    placed in a sub-region of that size, centered on both axes. If it
    returns `None` (the typical case — the child fills), `Centered` is a
    no-op wrapper: the child gets the full region.

    Composes well with leaf primitives that have intrinsic sizes
    (`StatCallout` with a measure override, future `BadgedIcon`, etc.).

    Example:
        >>> Centered(Text("Thank you.", role="h1"))
    """

    def __init__(self, child: Layout) -> None:
        self.child = child

    def render(self, slide: Any, region: Region, theme: "Theme") -> Region:
        intrinsic = self.child.measure(theme)
        if intrinsic is None:
            return self.child.render(slide, region, theme)
        w, h = intrinsic
        if w > region.w:
            raise LayoutOverflowError(
                element=f"Centered({type(self.child).__name__})",
                required_emu=(w, h),
                region_emu=(region.w, region.h),
                axis="width",
            )
        if h > region.h:
            raise LayoutOverflowError(
                element=f"Centered({type(self.child).__name__})",
                required_emu=(w, h),
                region_emu=(region.w, region.h),
                axis="height",
            )
        x = region.x + (region.w - w) // 2
        y = region.y + (region.h - h) // 2
        centered_region = Region(x=x, y=y, w=w, h=h)
        return self.child.render(slide, centered_region, theme)
