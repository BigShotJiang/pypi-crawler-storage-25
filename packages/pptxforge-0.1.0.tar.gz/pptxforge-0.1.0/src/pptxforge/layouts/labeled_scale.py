"""LabeledScale - a horizontal bar showing where a value sits on a continuum.

Used for any "value on a range" content: HLB scales, pH scales,
percentage spectra. Replaces the "list of bullet ranges" anti-pattern
where the audience has to mentally reconstruct the geometry.

Visual structure (top to bottom):

    [marker label]      "CITREM"
        |
        v
    +============+========+============+============+
    |  W/O       |  Wett  |  O/W       |  Solu      |  zone bands
    +============+========+============+============+   (tinted bg)
    0            6        9            12           20  axis numbers
                                                        (tick marks)
                          HLB-Wert                     label_below

The bar is centred horizontally inside ~80% of the region width so the
axis labels at the ends don't crowd the safe margins.
"""

from __future__ import annotations

from collections.abc import Sequence
from dataclasses import dataclass
from typing import TYPE_CHECKING, Any

from pptxforge.layouts._base import EMU_PER_INCH, Layout, LayoutOverflowError, Region
from pptxforge.layouts._rendering import add_line, add_rect, add_textbox, resolve_type_step
from pptxforge.layouts._tokens import resolve_token, slide_background, tint

if TYPE_CHECKING:
    from pptxforge.design import Theme


# Repulsion parameters for marker label collision avoidance. The
# marker-label area used to be a single horizontal row with each label
# centred on its `value`; multiple markers in dense regions overlapped
# silently. We now resolve overlaps in two passes:
#
#   1) Damped repulsion along the bar axis. Each iteration pushes
#      overlapping pairs apart by ¼ of the overlap per side (`damping`
#      0.5 × half-overlap), so dense clusters converge over several
#      iterations without oscillation. Each label is clamped to a
#      maximum displacement of ``_MAX_DISPLACEMENT_FRAC`` of the bar
#      width — beyond that the label would lie about its value.
#   2) Vertical row stacking for whatever didn't fit. Labels are placed
#      greedily into the lowest row (closest to the bar) where they
#      don't clash with an already-placed label; new rows are added
#      above as needed. Each non-row-0 label and each label whose
#      displaced x differs from its true-value x gets a thin leader
#      line back to the true value on the bar.
_MAX_DISPLACEMENT_FRAC = 0.10
_MAX_REPULSION_ITERS = 30
_LEADER_STROKE_WIDTH_PT = 0.5
# Conservative text-width factor: average glyph width relative to font
# size. Real sans-serif body fonts run ~0.55–0.6× their pt size in
# width per character; we use 0.65 so estimates trend wide and the
# textbox we allocate is always big enough to render the label on a
# single line (a wrap into a second line breaks the layout because
# the marker-label row has a fixed 0.4" height).
_GLYPH_WIDTH_FRAC = 0.65
# Inner padding inside each label textbox so the bold text doesn't sit
# flush against the box edge.
_LABEL_INNER_PAD_EMU = 45_720  # 0.05"
# Inter-label visible gap. The collision algorithm converges to "just
# zero overlap" between collision rects; setting collision_width =
# textbox_width + this gap guarantees the *rendered* labels sit at
# least this far apart edge-to-edge. 0.15" reads as clear separation
# at typical slide-zoom without forcing aggressive displacement.
_LABEL_GAP_EMU = 137_160  # 0.15"
# Hard ceiling on per-label textbox width. Long labels (e.g.
# "Emulsionsstabilität", 19 chars) at 13pt estimate to ~2.0", which
# happens to land at the previous fixed-width textbox cap; allow some
# headroom so very long labels still render on one line.
_LABEL_MAX_W_IN = 3.0


@dataclass(frozen=True, slots=True)
class _ResolvedMarker:
    """One marker after collision resolution.

    ``rendered_x`` is the centre x of the label box on the slide;
    ``true_value_x`` is the centre x corresponding to the marker's
    actual value on the bar. They differ when repulsion or stacking
    moved the label off its anchor — the leader line bridges that gap
    so the displaced label can't be misread.

    ``textbox_w`` is the per-label textbox width chosen to fit the
    label text on a single line (uniform 2"-wide boxes wrapped long
    German labels mid-line and broke the layout). The collision
    algorithm separates labels by ``textbox_w`` plus a fixed
    ``_LABEL_GAP_EMU`` of breathing room.
    """

    marker: ScaleMarker
    true_value_x: int
    rendered_x: int
    row: int
    textbox_w: int


@dataclass(frozen=True, slots=True)
class ScaleZone:
    """A coloured band along a `LabeledScale` covering `[start, end]`.

    `color_token` is one of the dotted aliases (`accent.context`,
    `accent.key`) or a flat palette role. The band is rendered as a
    ~20% tint of the resolved colour against the slide background; the
    label sits below the band.
    """

    start: float
    end: float
    label: str
    color_token: str = "accent.context"


@dataclass(frozen=True, slots=True)
class ScaleMarker:
    """A vertical pin on a `LabeledScale` at a specific `value`.

    `label` is rendered above the pin, value below the pin (as part of
    the axis row when it lines up, otherwise alongside the label).
    """

    value: float
    label: str
    color_token: str = "accent.key"


class LabeledScale(Layout):
    """A horizontal labelled scale for a value or range on a continuum.

    Use when the content is "where on this spectrum does X sit?" — HLB
    values, pH ranges, % composition. The geometry does the explaining;
    a bullet list of "0-6 means W/O, 8-12 means O/W..." would not.

    Example:
        >>> LabeledScale(
        ...     min_value=0, max_value=20,
        ...     zones=[
        ...         ScaleZone(0, 6, "W/O Emulgator"),
        ...         ScaleZone(9, 12, "O/W Emulgator", color_token="accent.key"),
        ...     ],
        ...     markers=[ScaleMarker(value=10, label="CITREM")],
        ...     label_below="HLB-Wert",
        ... )
    """

    _BAR_WIDTH_FRAC = 0.8  # bar uses 80% of region width
    _BAR_HEIGHT_IN = 0.4
    _MARKER_LABEL_HEIGHT_IN = 0.4  # space above the bar for marker labels
    _ZONE_LABEL_HEIGHT_IN = 0.4  # space below the bar for zone labels
    _AXIS_HEIGHT_IN = 0.3  # numeric axis labels under zones
    _BELOW_LABEL_HEIGHT_IN = 0.35  # the optional "HLB-Wert" caption
    _ZONE_TINT_FRACTION = 0.78  # ~22% accent against the background
    _MARKER_PIN_WIDTH_PT = 2.5

    def __init__(
        self,
        min_value: float,
        max_value: float,
        *,
        zones: Sequence[ScaleZone] = (),
        markers: Sequence[ScaleMarker] = (),
        label_below: str | None = None,
        unit: str | None = None,
    ) -> None:
        if max_value <= min_value:
            raise ValueError(
                f"LabeledScale requires max_value > min_value; got min={min_value}, max={max_value}"
            )
        for z in zones:
            if z.start < min_value or z.end > max_value or z.end <= z.start:
                raise ValueError(
                    f"ScaleZone {z.label!r} ({z.start}..{z.end}) is outside or empty "
                    f"on a [{min_value}, {max_value}] scale"
                )
        for m in markers:
            if not (min_value <= m.value <= max_value):
                raise ValueError(
                    f"ScaleMarker {m.label!r} value={m.value} is outside [{min_value}, {max_value}]"
                )
        self.min_value = float(min_value)
        self.max_value = float(max_value)
        self.zones = tuple(zones)
        self.markers = tuple(markers)
        self.label_below = label_below
        self.unit = unit

    def measure(self, theme: Theme) -> tuple[int, int] | None:
        return None  # sized to the region

    def render(self, slide: Any, region: Region, theme: Theme) -> Region:
        bar_w = int(region.w * self._BAR_WIDTH_FRAC)
        bar_x = region.x + (region.w - bar_w) // 2

        marker_label_h = int(self._MARKER_LABEL_HEIGHT_IN * EMU_PER_INCH)
        bar_h = int(self._BAR_HEIGHT_IN * EMU_PER_INCH)
        zone_label_h = int(self._ZONE_LABEL_HEIGHT_IN * EMU_PER_INCH)
        axis_h = int(self._AXIS_HEIGHT_IN * EMU_PER_INCH)

        # Marker step font size affects collision width, so resolve it
        # before the layout pass.
        marker_step = resolve_type_step(theme, "caption")
        marker_font_pt = marker_step.size_pt + 1

        # Resolve marker label positions before sizing the region — the
        # number of stacked rows feeds into `required_h`.
        resolved = _resolve_marker_labels(
            self.markers,
            bar_x=bar_x,
            bar_w=bar_w,
            min_value=self.min_value,
            span=self._span(),
            label_font_pt=marker_font_pt,
        )
        n_rows = max((rm.row for rm in resolved), default=0) + 1 if resolved else 1

        marker_area_h = marker_label_h * n_rows

        required_h = (
            marker_area_h
            + bar_h
            + zone_label_h
            + axis_h
            + (int(self._BELOW_LABEL_HEIGHT_IN * EMU_PER_INCH) if self.label_below else 0)
        )
        if required_h > region.h:
            raise LayoutOverflowError(
                element=f"LabeledScale({self.min_value}..{self.max_value})",
                required_emu=(region.w, required_h),
                region_emu=(region.w, region.h),
                axis="height",
            )

        bar_y = region.y + marker_area_h
        zone_label_y = bar_y + bar_h
        axis_y = zone_label_y + zone_label_h
        below_label_y = axis_y + axis_h

        bg = slide_background(theme)
        surface = resolve_token(theme, "surface.muted")
        text_primary = resolve_token(theme, "text_primary")
        text_muted = resolve_token(theme, "text.muted")

        # 1) Bar background: a soft surface band the zones overlay.
        bar_region = Region(x=bar_x, y=bar_y, w=bar_w, h=bar_h)
        add_rect(
            slide,
            bar_region,
            fill_token=tint(surface, bg, 0.2),
            stroke_token=resolve_token(theme, "divider"),
            stroke_width_pt=0.5,
        )

        # 2) Tinted zone bands.
        for zone in self.zones:
            zx0 = bar_x + int(bar_w * (zone.start - self.min_value) / self._span())
            zx1 = bar_x + int(bar_w * (zone.end - self.min_value) / self._span())
            zone_color = resolve_token(theme, zone.color_token)
            add_rect(
                slide,
                Region(x=zx0, y=bar_y, w=zx1 - zx0, h=bar_h),
                fill_token=tint(zone_color, bg, self._ZONE_TINT_FRACTION),
                stroke_token=None,
            )

        # 3) Tick marks at min, max, and every zone boundary; numeric axis.
        boundaries: list[float] = [self.min_value, self.max_value]
        for z in self.zones:
            boundaries.append(z.start)
            boundaries.append(z.end)
        # Sort + de-duplicate (within a small tolerance) so labels don't stack.
        boundaries = sorted(set(round(v, 4) for v in boundaries))
        divider = resolve_token(theme, "divider")
        body_step = resolve_type_step(theme, "caption")
        for v in boundaries:
            tx = bar_x + int(bar_w * (v - self.min_value) / self._span())
            add_line(
                slide,
                x1_emu=tx,
                y1_emu=bar_y,
                x2_emu=tx,
                y2_emu=bar_y + bar_h,
                stroke_token=divider,
                stroke_width_pt=0.75,
            )
            # Centred numeric label under the tick.
            lbl_w = int(0.7 * EMU_PER_INCH)
            label_text = self._format_value(v)
            add_textbox(
                slide,
                Region(x=tx - lbl_w // 2, y=axis_y, w=lbl_w, h=axis_h),
                text=label_text,
                stack=theme.typography.body,
                size_pt=body_step.size_pt,
                color_token=text_muted,
                align="center",
                anchor="top",
                line_height=body_step.line_height,
            )

        # 4) Zone labels under each band.
        zone_step = resolve_type_step(theme, "caption")
        for zone in self.zones:
            zx0 = bar_x + int(bar_w * (zone.start - self.min_value) / self._span())
            zx1 = bar_x + int(bar_w * (zone.end - self.min_value) / self._span())
            add_textbox(
                slide,
                Region(x=zx0, y=zone_label_y, w=max(1, zx1 - zx0), h=zone_label_h),
                text=zone.label,
                stack=theme.typography.body,
                size_pt=zone_step.size_pt,
                color_token=text_muted,
                align="center",
                anchor="top",
                line_height=zone_step.line_height,
            )

        # 5) Markers: vertical pin + label (possibly displaced or stacked
        # to avoid collisions; leader line drawn back to the true value
        # whenever the rendered label position differs from the value).
        for rm in resolved:
            marker = rm.marker
            mc = resolve_token(theme, marker.color_token)
            add_line(
                slide,
                x1_emu=rm.true_value_x,
                y1_emu=bar_y - int(0.08 * EMU_PER_INCH),
                x2_emu=rm.true_value_x,
                y2_emu=bar_y + bar_h + int(0.08 * EMU_PER_INCH),
                stroke_token=mc,
                stroke_width_pt=self._MARKER_PIN_WIDTH_PT,
            )
            # Row 0 sits closest to the bar; higher rows stack upward
            # towards region.y. This keeps a single un-stacked label in
            # the same vertical position as the pre-collision-fix
            # rendering (no visual change for the common case).
            label_y = region.y + (n_rows - 1 - rm.row) * marker_label_h
            label_rect = Region(
                x=rm.rendered_x - rm.textbox_w // 2,
                y=label_y,
                w=rm.textbox_w,
                h=marker_label_h,
            )
            # Leader line from the true value (top of bar) to the
            # bottom-centre of the displaced label box. Drawn before
            # the textbox so the text reads on top.
            if rm.row > 0 or rm.rendered_x != rm.true_value_x:
                add_line(
                    slide,
                    x1_emu=rm.true_value_x,
                    y1_emu=bar_y,
                    x2_emu=rm.rendered_x,
                    y2_emu=label_y + marker_label_h,
                    stroke_token=mc,
                    stroke_width_pt=_LEADER_STROKE_WIDTH_PT,
                )
            add_textbox(
                slide,
                label_rect,
                text=marker.label,
                stack=theme.typography.body,
                size_pt=marker_font_pt,
                color_token=mc,
                bold=True,
                align="center",
                anchor="middle",
                line_height=marker_step.line_height,
            )

        # 6) Below-bar label ("HLB-Wert", optional unit).
        if self.label_below:
            below_text = self.label_below
            if self.unit:
                below_text = f"{below_text} ({self.unit})"
            below_step = resolve_type_step(theme, "body")
            add_textbox(
                slide,
                Region(
                    x=bar_x,
                    y=below_label_y,
                    w=bar_w,
                    h=int(self._BELOW_LABEL_HEIGHT_IN * EMU_PER_INCH),
                ),
                text=below_text,
                stack=theme.typography.body,
                size_pt=below_step.size_pt,
                color_token=text_primary,
                bold=True,
                align="center",
                anchor="top",
                line_height=below_step.line_height,
            )

        return Region(x=region.x, y=region.y, w=region.w, h=required_h)

    def _span(self) -> float:
        return self.max_value - self.min_value

    @staticmethod
    def _format_value(v: float) -> str:
        if abs(v - round(v)) < 1e-6:
            return f"{round(v)}"
        return f"{v:g}"


def _label_textbox_width(text: str, font_pt: float) -> int:
    """Pick a textbox width that fits ``text`` on one line at ``font_pt``.

    Uses a deliberately wide glyph factor (0.65) so the textbox is
    always big enough to hold the rendered text without wrapping; if
    the text wraps, the marker-label row's fixed 0.4" height clips
    the second line and the label reads as broken (this was the
    second cause of the originally-reported visual overlap — long
    German labels like "Emulsionsstabilität" wrapped inside the old
    pinned 2.0" textbox). Bounded above by ``_LABEL_MAX_W_IN`` so a
    pathologically long label can't blow the bar's available width.
    """
    pt_per_emu = 12700
    char_w_emu = max(1, int(font_pt * _GLYPH_WIDTH_FRAC * pt_per_emu))
    glyph_w = max(char_w_emu, len(text) * char_w_emu)
    box_w = glyph_w + 2 * _LABEL_INNER_PAD_EMU
    return min(int(_LABEL_MAX_W_IN * EMU_PER_INCH), box_w)


def _resolve_marker_labels(
    markers: Sequence[ScaleMarker],
    *,
    bar_x: int,
    bar_w: int,
    min_value: float,
    span: float,
    label_font_pt: float,
) -> list[_ResolvedMarker]:
    """Pick a final (rendered_x, row) for each marker label.

    Pass 1 — damped repulsion along the bar axis. Each iteration walks
    pairs in true-value order and pushes overlapping pairs apart by
    ¼ of the overlap per side (= ½ × half-overlap, the 0.5 damping
    factor). Each label is clamped to a maximum displacement of
    ``_MAX_DISPLACEMENT_FRAC`` of the bar width — past that the label
    would lie about its anchor.

    Pass 2 — vertical stacking for the leftover overlaps. Walking left
    to right, each label is placed in the lowest row that doesn't clash
    with an already-placed label in that row. Row 0 sits closest to the
    bar; row 1 sits above row 0; etc. Single-row decks (the common
    case) keep their pre-fix vertical position.
    """
    if not markers:
        return []

    max_disp = int(bar_w * _MAX_DISPLACEMENT_FRAC)

    true_xs = [
        bar_x + int(bar_w * (m.value - min_value) / span) if span > 0 else bar_x for m in markers
    ]
    rendered_xs = list(true_xs)
    # Textbox widths are sized to fit each label's text on one line.
    # Collision widths add an inter-label gap so adjacent labels don't
    # render flush against each other.
    textbox_widths = [_label_textbox_width(m.label, label_font_pt) for m in markers]
    widths = [tw + _LABEL_GAP_EMU for tw in textbox_widths]

    # Walk pairs in left-to-right (true-value) order so the repulsion
    # pass is stable: index i is always to the left of index j.
    order = sorted(range(len(markers)), key=lambda k: true_xs[k])

    for _ in range(_MAX_REPULSION_ITERS):
        moved = False
        for k in range(len(order) - 1):
            i, j = order[k], order[k + 1]
            wi, wj = widths[i], widths[j]
            ri = rendered_xs[i] + wi // 2
            lj = rendered_xs[j] - wj // 2
            if ri <= lj:
                continue
            overlap = ri - lj
            # Damping 0.5: push by quarter of the overlap per side (the
            # un-damped repulsion would push by half-overlap each side).
            push = max(1, overlap // 4)
            new_i = max(true_xs[i] - max_disp, rendered_xs[i] - push)
            new_j = min(true_xs[j] + max_disp, rendered_xs[j] + push)
            if new_i != rendered_xs[i] or new_j != rendered_xs[j]:
                rendered_xs[i] = new_i
                rendered_xs[j] = new_j
                moved = True
        if not moved:
            break

    # Pass 2: row-stack any pairs that still overlap.
    rows = [0] * len(markers)
    placed: list[list[int]] = []  # rows[r] = list of indices already in row r
    for idx in order:
        li = rendered_xs[idx] - widths[idx] // 2
        ri = rendered_xs[idx] + widths[idx] // 2
        for r, row_indices in enumerate(placed):
            collides = False
            for j in row_indices:
                lj = rendered_xs[j] - widths[j] // 2
                rj = rendered_xs[j] + widths[j] // 2
                if not (ri <= lj or rj <= li):
                    collides = True
                    break
            if not collides:
                rows[idx] = r
                row_indices.append(idx)
                break
        else:
            rows[idx] = len(placed)
            placed.append([idx])

    return [
        _ResolvedMarker(
            marker=m,
            true_value_x=true_xs[k],
            rendered_x=rendered_xs[k],
            row=rows[k],
            textbox_w=textbox_widths[k],
        )
        for k, m in enumerate(markers)
    ]
