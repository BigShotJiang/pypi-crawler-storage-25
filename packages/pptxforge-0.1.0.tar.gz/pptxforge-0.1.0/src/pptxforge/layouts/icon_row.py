"""Icon row: N columns of (icon, header, description)."""

from collections.abc import Sequence
from dataclasses import dataclass
from typing import TYPE_CHECKING, Any

from pptxforge.layouts._base import Layout, Region
from pptxforge.layouts.grid import Grid
from pptxforge.layouts.primitives import Icon, Text
from pptxforge.layouts.stack import Stack

if TYPE_CHECKING:
    from pptxforge.design import Theme


@dataclass(frozen=True, slots=True)
class IconRowItem:
    """One column of an `IconRow`: icon glyph + bold header + description.

    Example:
        >>> IconRowItem(icon=Icon("bolt", color="accent"),
        ...             header="Fast",
        ...             description="Ships in under 50ms.")
    """

    icon: Icon
    header: str
    description: str


class IconRow(Layout):
    """A horizontal row of (icon, header, description) columns.

    Columns are equal-width; vertical weights inside each column are tuned
    so the description paragraph gets the most space, then the header,
    then the icon. Colors come from the theme palette (icon in `accent`
    per the item, header in `text_primary`, description in `text_muted`).

    Example:
        >>> IconRow([
        ...     IconRowItem(Icon("bolt"), "Fast", "Ships in <50ms."),
        ...     IconRowItem(Icon("check"), "Correct", "Typed end to end."),
        ...     IconRowItem(Icon("star"), "Opinionated", "One good default."),
        ... ])
    """

    _ICON_WEIGHT = 1.4
    _HEADER_WEIGHT = 1.0
    _DESCRIPTION_WEIGHT = 2.2

    def __init__(
        self,
        items: Sequence[IconRowItem],
        *,
        gap: float = 0.5,
        inner_gap: float = 0.15,
        header_color: str = "text_primary",
        description_color: str = "text_muted",
    ) -> None:
        if not items:
            raise ValueError("IconRow requires at least one item")
        self.items = tuple(items)
        self.gap = gap
        self.inner_gap = inner_gap
        self.header_color = header_color
        self.description_color = description_color

    def render(self, slide: Any, region: Region, theme: "Theme") -> Region:
        columns: list[Layout] = [
            Stack(
                [
                    item.icon,
                    Text(item.header, role="h2", color=self.header_color, bold=True),
                    Text(item.description, role="body", color=self.description_color),
                ],
                gap=self.inner_gap,
                weights=(
                    self._ICON_WEIGHT,
                    self._HEADER_WEIGHT,
                    self._DESCRIPTION_WEIGHT,
                ),
            )
            for item in self.items
        ]
        return Grid(columns, cols=len(columns), rows=1, gap=self.gap).render(slide, region, theme)
