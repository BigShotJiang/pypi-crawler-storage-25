"""N×M grid layout."""

from collections.abc import Sequence
from typing import TYPE_CHECKING, Any

from pptxforge.layouts._base import EMU_PER_INCH, Layout, LayoutOverflowError, Region

if TYPE_CHECKING:
    from pptxforge.design import Theme


class Grid(Layout):
    """A `cols × rows` grid with equal cells and a uniform gap.

    Children are placed row-major: left-to-right across each row, then
    top-to-bottom. Fewer children than cells is allowed; empty cells stay
    empty. More children than cells raises `ValueError` at construction.

    `gap` is inches.

    Example:
        >>> Grid([Text("A"), Text("B"), Text("C"), Text("D")], cols=2, rows=2, gap=0.3)
    """

    def __init__(
        self,
        children: Sequence[Layout],
        *,
        cols: int,
        rows: int,
        gap: float = 0.2,
    ) -> None:
        if cols <= 0 or rows <= 0:
            raise ValueError(f"Grid: cols/rows must be positive, got cols={cols}, rows={rows}")
        if len(children) > cols * rows:
            raise ValueError(
                f"Grid: {len(children)} children exceed {cols}x{rows}={cols * rows} cells"
            )
        self.children = tuple(children)
        self.cols = cols
        self.rows = rows
        self.gap = gap

    def render(self, slide: Any, region: Region, theme: "Theme") -> Region:
        gap_emu = int(self.gap * EMU_PER_INCH)
        total_col_gap = gap_emu * (self.cols - 1)
        total_row_gap = gap_emu * (self.rows - 1)

        if total_col_gap > region.w:
            raise LayoutOverflowError(
                element=f'Grid({self.cols}x{self.rows}, gap={self.gap}")',
                required_emu=(total_col_gap, region.h),
                region_emu=(region.w, region.h),
                axis="width",
            )
        if total_row_gap > region.h:
            raise LayoutOverflowError(
                element=f'Grid({self.cols}x{self.rows}, gap={self.gap}")',
                required_emu=(region.w, total_row_gap),
                region_emu=(region.w, region.h),
                axis="height",
            )

        cell_w = (region.w - total_col_gap) // self.cols
        cell_h = (region.h - total_row_gap) // self.rows

        for i, child in enumerate(self.children):
            col = i % self.cols
            row = i // self.cols
            x = region.x + col * (cell_w + gap_emu)
            y = region.y + row * (cell_h + gap_emu)
            cell_region = Region(x=x, y=y, w=cell_w, h=cell_h)
            child.render(slide, cell_region, theme)

        return region
