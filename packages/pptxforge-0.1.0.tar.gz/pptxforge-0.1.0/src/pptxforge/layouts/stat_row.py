"""StatRow - a horizontal row of (value, label, caption) statistics.

Use when several measurements belong on the same axis of comparison
("0.1-0.5 % use level / 70-80 % oil / 6-9 months shelf life"). The row
makes the parallel structure visually obvious in a way three sentences
do not.

Distinct from `StatSlide` (which is a full-slide template wrapping a
similar concept): `StatRow` is a layout primitive callable inside any
`add_content_slide(layout=...)` body.
"""

from __future__ import annotations

import re
import warnings
from collections.abc import Sequence
from dataclasses import dataclass
from typing import TYPE_CHECKING, Any, Literal

from pptxforge.layouts._base import EMU_PER_INCH, Layout, LayoutOverflowError, Region
from pptxforge.layouts._rendering import add_textbox, resolve_type_step
from pptxforge.layouts._tokens import resolve_token

if TYPE_CHECKING:
    from pptxforge.design import Theme


StatRowAlign = Literal["distribute", "left", "center"]

# A bare bracketed token like ``[FLOW_TIME_A]`` is the deck-scaffold
# convention from the example decks: a placeholder the author plans to
# fill in later. We detect it here so the renderer can drop the value
# down to a small muted size — the placeholder reads as scaffolding
# rather than masquerading as real data at full stat-row weight.
_PLACEHOLDER_RE = re.compile(r"^\[[A-Z_]+\]$")

# Above this length the value can't possibly fit at the column width
# StatRow assumes; the caller should be using Callout or CardGrid instead.
_HARD_CAP_CHARS = 30
# Above this length we keep rendering but shrink the font proportionally
# so the value still fits its column. 12 is the longest "comfortable"
# value the row was designed for (e.g. "0.1-0.5 %", "6-9 Monate").
_SOFT_CAP_CHARS = 12
# Floor for the auto-scaled font. Below this even the soft-cap math gives
# unreadable text; the warning at the call site is the user's signal that
# they're outside the primitive's intended use.
_MIN_VALUE_SIZE_PT = 20.0
# Pinned size for placeholder-style values. Half the base size so it
# reads as scaffolding without being unreadable.
_PLACEHOLDER_SIZE_PT = 24.0


@dataclass(frozen=True, slots=True)
class StatRowStat:
    """One column of a `StatRow`.

    Distinct from `pptxforge.slides.Stat` (which is a value object for
    the `StatSlide` template): this dataclass is the per-column input
    for the `StatRow` layout primitive.

    Attributes:
        value: Big value, ~48 pt accent (e.g. "0.5%", "70-80%", "12").
        label: One-line label below value, theme body colour.
        caption: Optional smaller line below label, muted.
    """

    value: str
    label: str
    caption: str | None = None


class StatRow(Layout):
    """A horizontal row of statistics with big value + label + optional caption.

    Reach for this when several numbers belong to the same comparison
    axis. Each stat reads as a peer of the others; the row's geometry
    communicates "these are equally important".

    Example:
        >>> StatRow([
        ...     StatRowStat(value="0.1-0.5 %", label="Einsatzkonzentration"),
        ...     StatRowStat(value="70-80 %", label="Oelanteil"),
        ...     StatRowStat(value="6-9 Monate", label="Mindesthaltbarkeit"),
        ... ])
    """

    _MAX_STATS = 5
    _VALUE_SIZE_PT = 48.0
    _LABEL_SIZE_PT = 12.0
    _CAPTION_SIZE_PT = 10.0
    _GAP_IN = 0.5

    def __init__(
        self,
        stats: Sequence[StatRowStat],
        *,
        align: StatRowAlign = "distribute",
    ) -> None:
        if not stats:
            raise ValueError("StatRow requires at least one Stat")
        if len(stats) > self._MAX_STATS:
            raise ValueError(
                f"StatRow supports at most {self._MAX_STATS} stats per row; "
                f"got {len(stats)}. Break into a CardGrid or a second row."
            )
        if align not in ("distribute", "left", "center"):
            raise ValueError(
                f"StatRow align must be 'distribute' | 'left' | 'center'; got {align!r}"
            )
        for s in stats:
            if len(s.value) > _HARD_CAP_CHARS and not _PLACEHOLDER_RE.match(s.value):
                raise ValueError(
                    f"StatRow main stat must be ≤ {_HARD_CAP_CHARS} chars; "
                    f"got {len(s.value)} chars: {s.value[:40]!r}.... "
                    "Use Callout or CardGrid for longer text."
                )
        self.stats = tuple(stats)
        self.align = align

    @staticmethod
    def _stat_font_size(value: str, base_pt: float) -> float:
        """Pick the value font size for one stat.

        Placeholder tokens (``[FOO]``) render at a pinned small size so
        scaffolded decks read as scaffolds rather than as broken layouts.
        Strings within the soft cap render at ``base_pt``; longer strings
        scale down proportionally with a floor at ``_MIN_VALUE_SIZE_PT``.
        """
        if _PLACEHOLDER_RE.match(value):
            return _PLACEHOLDER_SIZE_PT
        n = len(value)
        if n <= _SOFT_CAP_CHARS:
            return base_pt
        scaled = base_pt * _SOFT_CAP_CHARS / n
        return max(_MIN_VALUE_SIZE_PT, scaled)

    @staticmethod
    def _is_placeholder(value: str) -> bool:
        return bool(_PLACEHOLDER_RE.match(value))

    def render(self, slide: Any, region: Region, theme: Theme) -> Region:
        n = len(self.stats)
        gap_emu = int(self._GAP_IN * EMU_PER_INCH)

        if self.align == "distribute":
            cell_w = (region.w - gap_emu * (n - 1)) // n
            start_x = region.x
        else:
            # Each cell sized to fit its value + label at a comfortable width.
            cell_w = min(int(2.6 * EMU_PER_INCH), (region.w - gap_emu * (n - 1)) // n)
            block_w = cell_w * n + gap_emu * (n - 1)
            if block_w > region.w:
                raise LayoutOverflowError(
                    element=f"StatRow({n} stats, align={self.align})",
                    required_emu=(block_w, region.h),
                    region_emu=(region.w, region.h),
                    axis="width",
                )
            start_x = region.x if self.align == "left" else region.x + (region.w - block_w) // 2

        accent = resolve_token(theme, "accent.key")
        text_primary = resolve_token(theme, "text_primary")
        text_muted = resolve_token(theme, "text.muted")

        body_step = resolve_type_step(theme, "body")
        caption_step = resolve_type_step(theme, "caption")

        # Reserve enough vertical space for the largest configured value
        # font size — keeps the row's baseline consistent across stats
        # even when one stat got auto-scaled down for length.
        value_h = int(self._VALUE_SIZE_PT * 1.05 * 12700)
        label_h = int(self._LABEL_SIZE_PT * 1.4 * 12700)
        caption_h = int(self._CAPTION_SIZE_PT * 1.4 * 12700)

        max_caption = max((caption_h if s.caption else 0 for s in self.stats), default=0)
        required_h = value_h + label_h + max_caption + int(0.15 * EMU_PER_INCH)
        if required_h > region.h:
            raise LayoutOverflowError(
                element=f"StatRow({n} stats)",
                required_emu=(region.w, required_h),
                region_emu=(region.w, region.h),
                axis="height",
            )

        for i, stat in enumerate(self.stats):
            cx = start_x + i * (cell_w + gap_emu)
            cell = Region(x=cx, y=region.y, w=cell_w, h=region.h)

            value_size_pt = self._stat_font_size(stat.value, self._VALUE_SIZE_PT)
            is_placeholder = self._is_placeholder(stat.value)
            value_color = text_muted if is_placeholder else accent

            if (
                not is_placeholder
                and len(stat.value) > _SOFT_CAP_CHARS
                and value_size_pt < self._VALUE_SIZE_PT
            ):
                warnings.warn(
                    f"StatRow value {stat.value!r} is {len(stat.value)} chars "
                    f"(soft cap {_SOFT_CAP_CHARS}); auto-scaling font from "
                    f"{self._VALUE_SIZE_PT:g}pt to {value_size_pt:.1f}pt. "
                    "Consider a shorter value or switch to Callout/CardGrid.",
                    category=UserWarning,
                    stacklevel=2,
                )

            cursor_y = cell.y
            add_textbox(
                slide,
                Region(x=cell.x, y=cursor_y, w=cell.w, h=value_h),
                text=stat.value,
                stack=theme.typography.display,
                size_pt=value_size_pt,
                color_token=value_color,
                bold=not is_placeholder,
                align="left",
                anchor="top",
                line_height=1.05,
            )
            cursor_y += value_h

            add_textbox(
                slide,
                Region(x=cell.x, y=cursor_y, w=cell.w, h=label_h),
                text=stat.label,
                stack=theme.typography.body,
                size_pt=self._LABEL_SIZE_PT,
                color_token=text_primary,
                bold=True,
                align="left",
                anchor="top",
                line_height=body_step.line_height,
            )
            cursor_y += label_h

            if stat.caption:
                add_textbox(
                    slide,
                    Region(x=cell.x, y=cursor_y, w=cell.w, h=caption_h),
                    text=stat.caption,
                    stack=theme.typography.body,
                    size_pt=self._CAPTION_SIZE_PT,
                    color_token=text_muted,
                    align="left",
                    anchor="top",
                    line_height=caption_step.line_height,
                )

        return Region(x=region.x, y=region.y, w=region.w, h=required_h)
