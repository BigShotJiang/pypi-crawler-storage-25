"""Composable layout primitives.

Two families of classes:

- **Containers** — arrange children into regions:
  `Stack`, `Grid`, `TwoColumn`, `HalfBleed`, `Centered`, `IconRow`.
- **Leaf primitives** — render one element:
  `Text`, `Image`, `Icon`, `Shape`, `StatCallout`, `CodeBlock`.

Everything subclasses `Layout` and implements
`render(slide, region, theme) -> Region`. Overflow is a build-time error:
see `LayoutOverflowError`.

All colors, fonts, and type-scale steps come from a `Theme` — no
hardcoded hex inside this package.
"""

from pptxforge.layouts._base import (
    EMU_PER_INCH,
    Layout,
    LayoutOverflowError,
    Region,
)
from pptxforge.layouts.callout import Callout, CalloutVariant
from pptxforge.layouts.card_grid import Card, CardGrid
from pptxforge.layouts.centered import Centered
from pptxforge.layouts.grid import Grid
from pptxforge.layouts.half_bleed import HalfBleed
from pptxforge.layouts.icon_row import IconRow, IconRowItem
from pptxforge.layouts.labeled_scale import LabeledScale, ScaleMarker, ScaleZone
from pptxforge.layouts.primitives import (
    CodeBlock,
    Icon,
    Image,
    Shape,
    StatCallout,
    Text,
)
from pptxforge.layouts.stack import Stack
from pptxforge.layouts.stat_row import StatRow, StatRowAlign, StatRowStat
from pptxforge.layouts.two_column import TwoColumn

__all__ = [
    # Base
    "Layout",
    "Region",
    "LayoutOverflowError",
    "EMU_PER_INCH",
    # Containers
    "Stack",
    "Grid",
    "TwoColumn",
    "HalfBleed",
    "Centered",
    "IconRow",
    "IconRowItem",
    # Leaf primitives
    "Text",
    "Image",
    "Icon",
    "Shape",
    "StatCallout",
    "CodeBlock",
    # Visual primitives (designer feedback round)
    "LabeledScale",
    "ScaleZone",
    "ScaleMarker",
    "CardGrid",
    "Card",
    "Callout",
    "CalloutVariant",
    "StatRow",
    "StatRowStat",
    "StatRowAlign",
]
