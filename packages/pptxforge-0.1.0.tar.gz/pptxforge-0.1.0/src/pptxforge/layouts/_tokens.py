"""Token aliasing and tinting helpers shared by the visual primitives.

The `LabeledScale`, `CardGrid`, `Callout`, and `StatRow` primitives accept
the dotted-token names from the visual-primitives spec
(`accent.context`, `accent.key`, `surface.muted`, `text.muted`,
`state.warning`). The library's `Palette` only carries the nine flat
roles (`primary`, `accent`, `surface`, `text_primary`, `text_muted`,
...), so this module maps the dotted aliases onto existing flat roles
and provides an alpha-blending helper for the tinted-band fills the
spec calls for.

Mapping (read these as "if a primitive asks for X, hand it Y"):

    accent.context  -> primary       # the theme's described/context colour
    accent.key      -> accent        # the theme's punch colour
    surface.muted   -> surface       # already the only surface tint we ship
    text.muted      -> text_muted    # straight through (dotted form)
    state.warning   -> accent        # no warning role exists; accent is the
                                     # most attention-getting hue

`pptxforge.layouts._rendering.resolve_color` already accepts dotted form
(it normalises `.` and `-` to `_`), so non-aliased names like
`primary` / `text.primary` keep working unchanged.
"""

from __future__ import annotations

from typing import TYPE_CHECKING

from pptxforge.design.tokens import ColorToken
from pptxforge.layouts._rendering import resolve_color

if TYPE_CHECKING:
    from pptxforge.design import Theme


# Dotted -> existing palette role.
_ALIASES: dict[str, str] = {
    "accent.context": "primary",
    "accent.key": "accent",
    "surface.muted": "surface",
    "text.muted": "text_muted",
    "state.warning": "accent",  # no warning role; accent is the loudest stand-in
}


def resolve_alias(role: str) -> str:
    """Return the underlying flat palette role for a primitive token name."""
    return _ALIASES.get(role, role)


def resolve_token(theme: Theme, role: str) -> ColorToken:
    """Resolve `role` (dotted alias or flat) to a `ColorToken` in `theme.palette`."""
    return resolve_color(theme, resolve_alias(role))


def tint(token: ColorToken, base: ColorToken, fraction: float) -> ColorToken:
    """Linearly blend `token` toward `base` and return the result.

    `fraction=0.0` returns `token` unchanged; `fraction=1.0` returns
    `base`. Used to derive low-alpha "tinted" backgrounds from a theme
    accent against the slide's background colour. The library does not
    yet support transparent fills, so we mix in sRGB instead.
    """
    if not 0.0 <= fraction <= 1.0:
        raise ValueError(f"tint fraction must be in [0.0, 1.0], got {fraction}")
    fr, fg, fb = token.rgb
    br, bg, bb = base.rgb
    r = round(fr + (br - fr) * fraction)
    g = round(fg + (bg - fg) * fraction)
    b = round(fb + (bb - fb) * fraction)
    return ColorToken(value=f"#{r:02X}{g:02X}{b:02X}")


def slide_background(theme: Theme) -> ColorToken:
    """Return the slide's base background colour for the active theme.

    Light themes return `background_light`; dark themes return
    `background_dark`. The library decides "is this theme dark?" by
    comparing the luminance of `background_light` to `background_dark`
    — whichever is closer to the surface tone wins.
    """
    pal = theme.palette
    surface_lum = _luminance(pal.surface)
    light_lum = _luminance(pal.background_light)
    dark_lum = _luminance(pal.background_dark)
    if abs(surface_lum - dark_lum) < abs(surface_lum - light_lum):
        return pal.background_dark
    return pal.background_light


def _luminance(token: ColorToken) -> float:
    r, g, b = token.rgb
    return 0.2126 * r + 0.7152 * g + 0.0722 * b
