"""Half-bleed layout: image on one side, content on the other."""

from typing import TYPE_CHECKING, Any, Literal

from pptxforge.layouts._base import Layout, Region

if TYPE_CHECKING:
    from pptxforge.design import Theme


class HalfBleed(Layout):
    """A full-height image taking half the region, content on the other half.

    The image half is rendered flush to the region edge (hence "bleed"),
    with no inset. The content half is inset by a generous margin so text
    breathes against the image edge.

    Example:
        >>> HalfBleed(
        ...     image=Image("cover.jpg", fit="cover"),
        ...     content=Stack([Text("Title", role="h1"), Text("Body")]),
        ...     side="left",
        ... )
    """

    _CONTENT_PAD_IN = 0.6

    def __init__(
        self,
        *,
        image: Layout,
        content: Layout,
        side: Literal["left", "right"] = "left",
    ) -> None:
        self.image = image
        self.content = content
        self.side = side

    def render(self, slide: Any, region: Region, theme: "Theme") -> Region:
        half_w = region.w // 2
        other_w = region.w - half_w

        if self.side == "left":
            image_region = Region(x=region.x, y=region.y, w=half_w, h=region.h)
            content_region = Region(x=region.x + half_w, y=region.y, w=other_w, h=region.h)
        else:
            content_region = Region(x=region.x, y=region.y, w=other_w, h=region.h)
            image_region = Region(x=region.x + other_w, y=region.y, w=half_w, h=region.h)

        self.image.render(slide, image_region, theme)
        self.content.render(slide, content_region.padded(inches=self._CONTENT_PAD_IN), theme)
        return region
