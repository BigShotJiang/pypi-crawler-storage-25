"""Shared python-pptx call helpers used by primitives and containers.

python-pptx leaks `Any` everywhere (no type stubs); this module keeps the
`Any` surface area small by centralising shape-creation calls. Outside of
here, the layout code stays in typed pptxforge territory.
"""

from typing import TYPE_CHECKING, Any

from pptx.dml.color import RGBColor
from pptx.enum.shapes import MSO_SHAPE
from pptx.enum.text import MSO_ANCHOR, PP_ALIGN
from pptx.util import Emu, Pt

if TYPE_CHECKING:
    from pptxforge.design import Theme
    from pptxforge.design.tokens import ColorToken
    from pptxforge.design.typography import FontStack
    from pptxforge.layouts._base import Region


# ---------------------------------------------------------------------------
# Token resolution
# ---------------------------------------------------------------------------


def resolve_color(theme: "Theme", role: str) -> "ColorToken":
    """Resolve a palette role name to its `ColorToken`.

    Accepts dotted names like `"text.primary"` as well as the canonical
    underscore form `"text_primary"`.
    """
    field = role.replace(".", "_").replace("-", "_")
    try:
        return getattr(theme.palette, field)  # type: ignore[no-any-return]
    except AttributeError as exc:
        valid = sorted(type(theme.palette).model_fields.keys())
        raise KeyError(f"Unknown palette role {role!r}; valid roles: {valid}") from exc


def resolve_type_step(theme: "Theme", role: str) -> Any:
    """Resolve a type-scale role (`hero`, `h1`, `h2`, `lead`, `body`, `caption`)."""
    try:
        return getattr(theme.type_scale, role)
    except AttributeError as exc:
        valid = sorted(type(theme.type_scale).model_fields.keys())
        raise KeyError(f"Unknown type-scale role {role!r}; valid roles: {valid}") from exc


# ---------------------------------------------------------------------------
# python-pptx shape helpers
# ---------------------------------------------------------------------------


def _rgb(token: "ColorToken") -> Any:
    return RGBColor(*token.rgb)  # type: ignore[no-untyped-call]


# Mapping from pptxforge `kind` strings to python-pptx MSO_SHAPE enum
# values. Aliases are documented inline. The cinematic helpers' ShapeSpec
# uses this mapping verbatim — extending the table here is the right
# place to add new shape kinds for any caller, not just cinematic.
_SHAPE_KIND_TO_MSO: dict[str, Any] = {
    # Rectangles & boxes.
    "rectangle": MSO_SHAPE.RECTANGLE,
    "square": MSO_SHAPE.RECTANGLE,  # alias — caller controls aspect.
    "roundrect": MSO_SHAPE.ROUNDED_RECTANGLE,
    "rounded_rectangle": MSO_SHAPE.ROUNDED_RECTANGLE,  # alias for ShapeSpec parity.
    # Curved.
    "circle": MSO_SHAPE.OVAL,
    "oval": MSO_SHAPE.OVAL,  # alias.
    # Polygons.
    "triangle": MSO_SHAPE.ISOSCELES_TRIANGLE,
    "right_triangle": MSO_SHAPE.RIGHT_TRIANGLE,
    "diamond": MSO_SHAPE.DIAMOND,
    "pentagon": MSO_SHAPE.PENTAGON,
    "hexagon": MSO_SHAPE.HEXAGON,
    # Stars (5-point is the default "star").
    "star": MSO_SHAPE.STAR_5_POINT,
    "star_5": MSO_SHAPE.STAR_5_POINT,
    "star_6": MSO_SHAPE.STAR_6_POINT,
    "star_8": MSO_SHAPE.STAR_8_POINT,
    # Arrows.
    "arrow": MSO_SHAPE.RIGHT_ARROW,  # default direction matches "arrow" reading.
    "arrow_right": MSO_SHAPE.RIGHT_ARROW,
    "arrow_left": MSO_SHAPE.LEFT_ARROW,
    "arrow_up": MSO_SHAPE.UP_ARROW,
    "arrow_down": MSO_SHAPE.DOWN_ARROW,
    # Decorative.
    "heart": MSO_SHAPE.HEART,
}


def add_rect(
    slide: Any,
    region: "Region",
    *,
    fill_token: "ColorToken | None",
    stroke_token: "ColorToken | None" = None,
    stroke_width_pt: float = 1.0,
    kind: str = "rectangle",
    corner_radius_emu: int | None = None,
) -> Any:
    """Draw an autoshape (rectangle, oval, triangle, star, arrow, …) at `region`.

    `kind` accepts any key in `_SHAPE_KIND_TO_MSO`. Common values:
    `"rectangle"`, `"square"`, `"roundrect"` / `"rounded_rectangle"`,
    `"circle"` / `"oval"`, `"triangle"`, `"diamond"`, `"pentagon"`,
    `"hexagon"`, `"star"`, `"arrow"` (plus directional variants).

    `fill_token=None` produces an unfilled shape; `stroke_token=None`
    produces a stroke-less shape.

    The function is named `add_rect` for backwards compatibility with
    Phase-2 callers; despite the name it now handles every autoshape
    kind in the mapping.
    """
    shape_type = _SHAPE_KIND_TO_MSO.get(kind)
    if shape_type is None:
        valid = sorted(_SHAPE_KIND_TO_MSO.keys())
        raise ValueError(f"unknown shape kind {kind!r}; expected one of {valid}")

    shape = slide.shapes.add_shape(
        shape_type, Emu(region.x), Emu(region.y), Emu(region.w), Emu(region.h)
    )

    if kind == "roundrect" and corner_radius_emu is not None:
        # Adjustment value 0 is square; 0.5 of the short side is max curvature.
        # python-pptx exposes adjustments via shape.adjustments; max radius
        # corresponds to adjustment 0.5.
        short_side = min(region.w, region.h)
        if short_side > 0:
            shape.adjustments[0] = min(0.5, corner_radius_emu / short_side)

    if fill_token is None:
        shape.fill.background()
    else:
        shape.fill.solid()
        shape.fill.fore_color.rgb = _rgb(fill_token)

    if stroke_token is None:
        shape.line.fill.background()
    else:
        shape.line.color.rgb = _rgb(stroke_token)
        shape.line.width = Pt(stroke_width_pt)

    shape.shadow.inherit = False
    return shape


def add_line(
    slide: Any,
    *,
    x1_emu: int,
    y1_emu: int,
    x2_emu: int,
    y2_emu: int,
    stroke_token: "ColorToken",
    stroke_width_pt: float = 1.0,
) -> Any:
    """Draw a straight line from (x1,y1) to (x2,y2).

    python-pptx's `add_connector(type, begin_x, begin_y, end_x, end_y)`
    takes absolute END coordinates for the last two args — NOT width /
    height. An earlier version of this helper passed `(x2-x1, y2-y1)`,
    which silently produced diagonals from (x1, y1) to roughly (0, 0)
    for every "vertical" or "horizontal" line because end_x collapsed
    to the span and end_y to a tiny offset. See
    `evidence/labeled-scale-fix.md`.
    """
    from pptx.enum.shapes import MSO_CONNECTOR

    shape = slide.shapes.add_connector(
        MSO_CONNECTOR.STRAIGHT,
        Emu(x1_emu),
        Emu(y1_emu),
        Emu(x2_emu),
        Emu(y2_emu),
    )
    shape.line.color.rgb = _rgb(stroke_token)
    shape.line.width = Pt(stroke_width_pt)
    return shape


def add_textbox(
    slide: Any,
    region: "Region",
    *,
    text: str,
    stack: "FontStack",
    size_pt: float,
    color_token: "ColorToken",
    bold: bool = False,
    italic: bool = False,
    align: str = "left",
    anchor: str = "top",
    line_height: float = 1.4,
    preserve_whitespace: bool = False,
) -> Any:
    """Create a text box at `region` with zero margins and the given run properties.

    **Pitfall handled**: python-pptx text boxes default to non-zero
    `margin_*` padding (~0.1"). Every text box pptxforge emits sets all
    four margins explicitly to `0` so that the caller's sizing math —
    computed against `region.w` / `region.h` — actually holds.
    """
    box = slide.shapes.add_textbox(Emu(region.x), Emu(region.y), Emu(region.w), Emu(region.h))
    tf = box.text_frame
    tf.word_wrap = True
    tf.margin_left = Emu(0)
    tf.margin_right = Emu(0)
    tf.margin_top = Emu(0)
    tf.margin_bottom = Emu(0)

    tf.vertical_anchor = {
        "top": MSO_ANCHOR.TOP,
        "middle": MSO_ANCHOR.MIDDLE,
        "bottom": MSO_ANCHOR.BOTTOM,
    }[anchor]

    align_enum = {
        "left": PP_ALIGN.LEFT,
        "center": PP_ALIGN.CENTER,
        "right": PP_ALIGN.RIGHT,
        "justify": PP_ALIGN.JUSTIFY,
    }[align]

    lines = text.split("\n") if preserve_whitespace else [text]
    for i, line in enumerate(lines):
        p = tf.paragraphs[0] if i == 0 else tf.add_paragraph()
        p.alignment = align_enum
        p.line_spacing = line_height
        run = p.add_run()
        run.text = line
        font = run.font
        font.name = stack.primary
        font.size = Pt(size_pt)
        font.bold = bold
        font.italic = italic
        font.color.rgb = _rgb(color_token)

    return box
