"""Leaf content primitives: Text, Image, Icon, Shape, StatCallout, CodeBlock.

Each primitive is a `Layout` subclass that renders directly (i.e. does not
take child layouts). They all consume tokens from `theme` — no hardcoded
colors, font sizes, or fonts. Overflow is raised at build time, never
silently clipped.
"""

import textwrap
from pathlib import Path
from typing import TYPE_CHECKING, Any, Literal

from pptx.util import Emu

from pptxforge.layouts._base import EMU_PER_INCH, Layout, LayoutOverflowError, Region
from pptxforge.layouts._rendering import (
    add_line,
    add_rect,
    add_textbox,
    resolve_color,
    resolve_type_step,
)

if TYPE_CHECKING:
    from pptxforge.design import Theme


# ---------------------------------------------------------------------------
# Text
# ---------------------------------------------------------------------------


# Empirical: average sans-serif glyph is roughly 0.55 × cap-height wide.
# We use this to estimate wrap width and line count for overflow detection.
_AVG_CHAR_WIDTH_PT_RATIO = 0.55
_PT_PER_EMU = 1 / 12700


def _estimate_text_bounds(
    body: str,
    *,
    size_pt: float,
    line_height: float,
    region_w_emu: int,
) -> tuple[int, int]:
    """Return the estimated `(w, h)` EMU the text will occupy inside `region_w_emu`.

    Uses textwrap with an avg-char-width heuristic — sufficient to catch
    egregious overflow. Real font metrics are deferred to a future phase
    (requires PIL.ImageFont or harfbuzz).
    """
    if not body:
        return (0, 0)

    avg_char_width_pt = size_pt * _AVG_CHAR_WIDTH_PT_RATIO
    available_pt = max(1.0, region_w_emu * _PT_PER_EMU)
    max_chars_per_line = max(1, int(available_pt / avg_char_width_pt))

    lines: list[str] = []
    for paragraph in body.split("\n"):
        if not paragraph:
            lines.append("")
            continue
        wrapped = textwrap.wrap(
            paragraph,
            width=max_chars_per_line,
            break_long_words=False,
            break_on_hyphens=False,
        )
        lines.extend(wrapped if wrapped else [paragraph])

    longest_chars = max((len(line) for line in lines), default=0)
    used_w_pt = longest_chars * avg_char_width_pt
    used_h_pt = len(lines) * size_pt * line_height

    return (int(used_w_pt / _PT_PER_EMU), int(used_h_pt / _PT_PER_EMU))


_TextRole = Literal["hero", "h1", "h2", "lead", "body", "caption"]


class Text(Layout):
    """A block of text rendered in a typography token's size/weight.

    `role` selects the type-scale step (`hero`, `h1`, `h2`, `lead`, `body`,
    or `caption`) — the font FACE comes from `theme.typography.body` by
    default, or `theme.typography.display` when `use_display=True` (set
    automatically for heading roles).

    `color` names a palette role — `text_primary`, `text_muted`, `primary`,
    `accent`, etc. Hardcoded hex is not accepted; fail loud.

    Example:
        >>> Text("Quarterly findings", role="h1", color="primary")
    """

    def __init__(
        self,
        body: str,
        *,
        role: _TextRole = "body",
        color: str = "text_primary",
        align: Literal["left", "center", "right", "justify"] = "left",
        anchor: Literal["top", "middle", "bottom"] = "top",
        bold: bool | None = None,
        italic: bool = False,
        use_display_font: bool | None = None,
    ) -> None:
        self.body = body
        self.role = role
        self.color = color
        self.align = align
        self.anchor = anchor
        self._bold_override = bold
        self.italic = italic
        self._use_display_override = use_display_font

    # Roles that pull the display font by default.
    _DISPLAY_ROLES: frozenset[str] = frozenset({"hero", "h1", "h2"})

    def _resolve_stack(self, theme: "Theme") -> Any:
        if self._use_display_override is None:
            use_display = self.role in self._DISPLAY_ROLES
        else:
            use_display = self._use_display_override
        return theme.typography.display if use_display else theme.typography.body

    def measure(self, theme: "Theme") -> tuple[int, int] | None:
        return None  # width depends on region; height needs the region too

    def render(self, slide: Any, region: Region, theme: "Theme") -> Region:
        step = resolve_type_step(theme, self.role)
        color_tok = resolve_color(theme, self.color)

        required_w, required_h = _estimate_text_bounds(
            self.body,
            size_pt=step.size_pt,
            line_height=step.line_height,
            region_w_emu=region.w,
        )

        if required_w > region.w:
            raise LayoutOverflowError(
                element=f"Text({self.body[:30]!r})",
                required_emu=(required_w, required_h),
                region_emu=(region.w, region.h),
                axis="width",
            )
        if required_h > region.h:
            raise LayoutOverflowError(
                element=f"Text({self.body[:30]!r})",
                required_emu=(required_w, required_h),
                region_emu=(region.w, region.h),
                axis="height",
            )

        bold = (
            step.weight in {"semibold", "bold"}
            if self._bold_override is None
            else self._bold_override
        )

        add_textbox(
            slide,
            region,
            text=self.body,
            stack=self._resolve_stack(theme),
            size_pt=step.size_pt,
            color_token=color_tok,
            bold=bold,
            italic=self.italic or step.italic,
            align=self.align,
            anchor=self.anchor,
            line_height=step.line_height,
        )
        return Region(x=region.x, y=region.y, w=region.w, h=required_h)


# ---------------------------------------------------------------------------
# Image
# ---------------------------------------------------------------------------


_ImageFit = Literal["cover", "contain", "fill"]


class Image(Layout):
    """A raster image, fitted into its region in one of three modes.

    - `fit="cover"`: image fills the region with no distortion; excess is
      cropped centered via an EMU-level `srcRect` on the picture. The
      original image bytes are preserved — we do NOT downscale the PIL
      image in memory, per the task brief's pitfall note.
    - `fit="contain"`: image is scaled to fit entirely within the region
      preserving aspect ratio; any excess space is empty.
    - `fit="fill"`: image is stretched to exactly fill the region (may
      distort).

    Example:
        >>> Image(Path("hero.jpg"), fit="cover")
    """

    def __init__(self, path: Path | str, *, fit: _ImageFit = "contain") -> None:
        self.path = Path(path)
        self.fit = fit

    def _aspect_ratio(self) -> float:
        # PIL is a transitive dependency via python-pptx.
        from PIL import Image as PILImage

        with PILImage.open(self.path) as im:
            w, h = im.size
        if w <= 0 or h <= 0:
            raise ValueError(f"Image {self.path} has non-positive dimensions {w}x{h}")
        return w / h

    def render(self, slide: Any, region: Region, theme: "Theme") -> Region:
        del theme  # images don't consume palette tokens

        if self.fit == "fill":
            slide.shapes.add_picture(
                str(self.path),
                Emu(region.x),
                Emu(region.y),
                width=Emu(region.w),
                height=Emu(region.h),
            )
            return region

        ar_img = self._aspect_ratio()
        ar_reg = region.w / region.h if region.h > 0 else 1.0

        if self.fit == "contain":
            if ar_img > ar_reg:
                # Wider than region: fit width, letterbox vertically
                final_w = region.w
                final_h = int(region.w / ar_img)
            else:
                final_h = region.h
                final_w = int(region.h * ar_img)
            final_x = region.x + (region.w - final_w) // 2
            final_y = region.y + (region.h - final_h) // 2
            slide.shapes.add_picture(
                str(self.path),
                Emu(final_x),
                Emu(final_y),
                width=Emu(final_w),
                height=Emu(final_h),
            )
            return Region(x=final_x, y=final_y, w=final_w, h=final_h)

        # fit == "cover": stretch to region, but set crop rect so the
        # visible portion has the region's aspect ratio.
        pic = slide.shapes.add_picture(
            str(self.path),
            Emu(region.x),
            Emu(region.y),
            width=Emu(region.w),
            height=Emu(region.h),
        )
        if ar_img > ar_reg:
            # Image wider than region → crop left/right
            frac = (1 - ar_reg / ar_img) / 2
            pic.crop_left = frac
            pic.crop_right = frac
            pic.crop_top = 0
            pic.crop_bottom = 0
        elif ar_img < ar_reg:
            # Image taller than region → crop top/bottom
            frac = (1 - ar_img / ar_reg) / 2
            pic.crop_top = frac
            pic.crop_bottom = frac
            pic.crop_left = 0
            pic.crop_right = 0
        else:
            pic.crop_left = pic.crop_right = pic.crop_top = pic.crop_bottom = 0
        return region


# ---------------------------------------------------------------------------
# Icon
# ---------------------------------------------------------------------------


# Minimal named-icon set. Phase 2 will ship a bundled SVG library; for
# now a small Unicode palette covers the common cases and survives
# font-substitution because every font here has these glyphs.
_ICON_GLYPHS: dict[str, str] = {
    "check": "\u2713",  # ✓
    "cross": "\u2717",  # ✗
    "x": "\u2717",  # alias
    "arrow-right": "\u2192",  # →
    "arrow-left": "\u2190",  # ←
    "arrow-up": "\u2191",  # ↑
    "arrow-down": "\u2193",  # ↓
    "star": "\u2605",  # ★
    "circle": "\u25cf",  # ●
    "square": "\u25a0",  # ■
    "triangle": "\u25b2",  # ▲
    "diamond": "\u25c6",  # ◆
    "heart": "\u2665",  # ♥
    "plus": "+",
    "minus": "\u2212",  # −
    "warning": "\u26a0",  # ⚠
    "info": "\u24d8",  # ⓘ
    "bolt": "\u26a1",  # ⚡
    "sparkle": "\u2728",  # ✨
    "dot": "\u2022",  # •
}


class Icon(Layout):
    """A small named-glyph icon colored from a palette role.

    The built-in icon set is a curated Unicode subset. Unknown names
    raise `KeyError` at construction — no silent fallbacks.

    The rendered size is governed by the region: the icon glyph is set
    at 60% of the region's short side (in points) and vertically centered.

    Example:
        >>> Icon("check", color="accent")
    """

    def __init__(self, name: str, *, color: str = "accent") -> None:
        if name not in _ICON_GLYPHS:
            valid = sorted(_ICON_GLYPHS.keys())
            raise KeyError(f"unknown icon {name!r}; valid names: {valid}")
        self.name = name
        self.color = color

    def measure(self, theme: "Theme") -> tuple[int, int] | None:
        return None  # sized by region

    def render(self, slide: Any, region: Region, theme: "Theme") -> Region:
        color_tok = resolve_color(theme, self.color)
        short_side_emu = min(region.w, region.h)
        glyph_size_pt = max(1.0, short_side_emu * _PT_PER_EMU * 0.6)

        # Use body stack — mono might render some glyphs awkwardly.
        add_textbox(
            slide,
            region,
            text=_ICON_GLYPHS[self.name],
            stack=theme.typography.body,
            size_pt=glyph_size_pt,
            color_token=color_tok,
            align="center",
            anchor="middle",
            line_height=1.0,
        )
        return region


# ---------------------------------------------------------------------------
# Shape
# ---------------------------------------------------------------------------


_ShapeKind = Literal[
    "rectangle",
    "square",
    "roundrect",
    "rounded_rectangle",
    "circle",
    "oval",
    "triangle",
    "right_triangle",
    "diamond",
    "pentagon",
    "hexagon",
    "star",
    "star_5",
    "star_6",
    "star_8",
    "arrow",
    "arrow_right",
    "arrow_left",
    "arrow_up",
    "arrow_down",
    "heart",
    "line",
]


class Shape(Layout):
    """A solid geometric shape filled from a palette role.

    Useful as a background for text (Shape(roundrect, fill="surface")) or
    as a divider (`Shape("line", fill="divider")`). Hardcoded hex colors
    are rejected; use `fill=<palette-role>` always.

    Example:
        >>> Shape("roundrect", fill="surface", stroke="divider")
    """

    def __init__(
        self,
        kind: _ShapeKind,
        *,
        fill: str | None = "surface",
        stroke: str | None = None,
        stroke_width_pt: float = 1.0,
        corner_radius_in: float = 0.08,
    ) -> None:
        self.kind = kind
        self.fill = fill
        self.stroke = stroke
        self.stroke_width_pt = stroke_width_pt
        self.corner_radius_in = corner_radius_in

    def render(self, slide: Any, region: Region, theme: "Theme") -> Region:
        fill_tok = resolve_color(theme, self.fill) if self.fill else None
        stroke_tok = resolve_color(theme, self.stroke) if self.stroke else None

        if self.kind == "line":
            if stroke_tok is None:
                # A line with no stroke is an invisible primitive; require one.
                stroke_tok = fill_tok or resolve_color(theme, "divider")
            add_line(
                slide,
                x1_emu=region.x,
                y1_emu=region.y + region.h // 2,
                x2_emu=region.x + region.w,
                y2_emu=region.y + region.h // 2,
                stroke_token=stroke_tok,
                stroke_width_pt=self.stroke_width_pt,
            )
            return Region(x=region.x, y=region.y + region.h // 2, w=region.w, h=0)

        corner_radius_emu = (
            int(self.corner_radius_in * EMU_PER_INCH) if self.kind == "roundrect" else None
        )
        add_rect(
            slide,
            region,
            fill_token=fill_tok,
            stroke_token=stroke_tok,
            stroke_width_pt=self.stroke_width_pt,
            kind=self.kind,
            corner_radius_emu=corner_radius_emu,
        )
        return region


# ---------------------------------------------------------------------------
# StatCallout
# ---------------------------------------------------------------------------


class StatCallout(Layout):
    """A big number + small label — the dashboard-style stat block.

    Renders the number at hero size in the `number_color` palette role,
    with the label beneath at caption size in `text_muted`.

    Example:
        >>> StatCallout("42%", label="Conversion rate")
    """

    def __init__(
        self,
        number: str,
        *,
        label: str,
        number_color: str = "accent",
        label_color: str = "text_muted",
        number_role: _TextRole = "hero",
        label_role: _TextRole = "caption",
    ) -> None:
        self.number = number
        self.label = label
        self.number_color = number_color
        self.label_color = label_color
        self.number_role = number_role
        self.label_role = label_role

    def render(self, slide: Any, region: Region, theme: "Theme") -> Region:
        # Vertical split: number gets ~65%, label gets the rest.
        number_h = int(region.h * 0.65)
        number_region = Region(x=region.x, y=region.y, w=region.w, h=number_h)
        label_region = Region(
            x=region.x,
            y=region.y + number_h,
            w=region.w,
            h=region.h - number_h,
        )
        Text(
            self.number,
            role=self.number_role,
            color=self.number_color,
            bold=True,
            anchor="bottom",
        ).render(slide, number_region, theme)
        Text(
            self.label,
            role=self.label_role,
            color=self.label_color,
            anchor="top",
        ).render(slide, label_region, theme)
        return region


# ---------------------------------------------------------------------------
# CodeBlock
# ---------------------------------------------------------------------------


class CodeBlock(Layout):
    """A monospace code block on a surface-colored rounded rectangle.

    No syntax highlighting in Phase 2 — the `lang` attribute is recorded
    for downstream use (future Pygments → SVG → a:pic path). Whitespace
    is preserved.

    Example:
        >>> CodeBlock("print('hi')", lang="python")
    """

    _PADDING_IN = 0.3

    def __init__(
        self,
        code: str,
        *,
        lang: str = "python",
        background: str = "surface",
        foreground: str = "text_primary",
        size_pt: float = 14.0,
    ) -> None:
        self.code = code
        self.lang = lang
        self.background = background
        self.foreground = foreground
        self.size_pt = size_pt

    def render(self, slide: Any, region: Region, theme: "Theme") -> Region:
        # Background card
        Shape("roundrect", fill=self.background, corner_radius_in=0.08).render(slide, region, theme)

        # Content region (padded)
        content = region.padded(inches=self._PADDING_IN)

        # Overflow check (approximate): mono fonts are ~0.6 × size_pt wide per char.
        lines = self.code.split("\n")
        longest = max((len(line) for line in lines), default=0)
        required_w = int(longest * self.size_pt * 0.6 / _PT_PER_EMU)
        required_h = int(len(lines) * self.size_pt * 1.3 / _PT_PER_EMU)

        if required_w > content.w:
            raise LayoutOverflowError(
                element=f"CodeBlock(lang={self.lang!r}, {len(lines)} lines)",
                required_emu=(required_w, required_h),
                region_emu=(content.w, content.h),
                axis="width",
            )
        if required_h > content.h:
            raise LayoutOverflowError(
                element=f"CodeBlock(lang={self.lang!r}, {len(lines)} lines)",
                required_emu=(required_w, required_h),
                region_emu=(content.w, content.h),
                axis="height",
            )

        fg_tok = resolve_color(theme, self.foreground)
        add_textbox(
            slide,
            content,
            text=self.code,
            stack=theme.typography.mono,
            size_pt=self.size_pt,
            color_token=fg_tok,
            align="left",
            anchor="top",
            line_height=1.3,
            preserve_whitespace=True,
        )
        return region


# Re-export for type-hint friendliness.
__all__ = [
    "Text",
    "Image",
    "Icon",
    "Shape",
    "StatCallout",
    "CodeBlock",
]
