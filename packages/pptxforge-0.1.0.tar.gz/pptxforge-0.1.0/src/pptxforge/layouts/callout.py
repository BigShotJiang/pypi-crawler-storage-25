"""Callout - a tinted box that emphasises a single key statement.

Use this when one sentence is the slide's punchline and would
otherwise read as a generic body bullet. The box, the eyebrow, and the
left accent border are the visual cues that say "read this part".
"""

from __future__ import annotations

import textwrap
from typing import TYPE_CHECKING, Any, ClassVar, Literal

from pptxforge.layouts._base import EMU_PER_INCH, Layout, LayoutOverflowError, Region
from pptxforge.layouts._rendering import add_rect, add_textbox, resolve_type_step
from pptxforge.layouts._tokens import resolve_token, slide_background, tint

if TYPE_CHECKING:
    from pptxforge.design import Theme


CalloutVariant = Literal["info", "key", "warning"]


class Callout(Layout):
    """A tinted box highlighting one short statement.

    Body must be <= 200 characters; raise otherwise. The library also
    refuses more than two callouts on one slide (enforced at the slide
    level by the layout-variation validator).

    Example:
        >>> Callout(
        ...     "CITREM ist sicher und wirksam, aber Clean-Label-Marketing.",
        ...     eyebrow="Pointe",
        ...     variant="key",
        ... )
    """

    _CORNER_IN = 0.15
    _PAD_IN = 0.30
    _BORDER_WIDTH_PT = 4.0
    _EYEBROW_SIZE_PT = 10.0
    _BODY_SIZE_PT = 14.0
    _TINT_FRACTION = 0.82  # ~18% of the variant colour against bg
    _MAX_BODY_CHARS: ClassVar[int] = 200

    _VARIANT_TO_TOKEN: ClassVar[dict[str, str]] = {
        "info": "accent.context",
        "key": "accent.key",
        "warning": "state.warning",
    }

    def __init__(
        self,
        body: str,
        *,
        eyebrow: str | None = None,
        variant: CalloutVariant = "info",
        icon: str | None = None,
    ) -> None:
        if not body or not body.strip():
            raise ValueError("Callout requires a non-empty body")
        if len(body) > self._MAX_BODY_CHARS:
            raise ValueError(
                f"Callout body is {len(body)} chars; max is {self._MAX_BODY_CHARS}. "
                "Callouts highlight one short statement; split into a card or content slide."
            )
        if variant not in self._VARIANT_TO_TOKEN:
            valid = sorted(self._VARIANT_TO_TOKEN.keys())
            raise ValueError(f"Callout variant must be one of {valid}; got {variant!r}")
        self.body = body
        self.eyebrow = eyebrow
        self.variant = variant
        self.icon = icon  # reserved; the bundled Icon set lacks "info"/"warning" glyphs

    def render(self, slide: Any, region: Region, theme: Theme) -> Region:
        bg = slide_background(theme)
        accent = resolve_token(theme, self._VARIANT_TO_TOKEN[self.variant])
        text_primary = resolve_token(theme, "text_primary")

        # Up-front overflow check.
        pad_emu = int(self._PAD_IN * EMU_PER_INCH)
        avail_w_emu = region.w - 2 * pad_emu - int(self._BORDER_WIDTH_PT * 12700)
        if avail_w_emu <= 0:
            raise LayoutOverflowError(
                element=f"Callout({self.body[:30]!r})",
                required_emu=(2 * pad_emu, region.h),
                region_emu=(region.w, region.h),
                axis="width",
            )
        avg_char_pt = self._BODY_SIZE_PT * 0.55
        chars_per_line = max(1, int(avail_w_emu / 12700 / avg_char_pt))
        body_lines = sum(
            max(1, len(textwrap.wrap(p, width=chars_per_line, break_long_words=False)))
            for p in self.body.split("\n")
        )
        body_height_pt = body_lines * self._BODY_SIZE_PT * 1.5
        eyebrow_height_pt = self._EYEBROW_SIZE_PT * 1.4 if self.eyebrow else 0.0
        required_h_pt = body_height_pt + eyebrow_height_pt + (self._PAD_IN * 2 * 72)
        required_h_emu = int(required_h_pt * 12700)
        if required_h_emu > region.h:
            raise LayoutOverflowError(
                element=f"Callout({self.body[:30]!r})",
                required_emu=(region.w, required_h_emu),
                region_emu=(region.w, region.h),
                axis="height",
            )

        # 1) Tinted background.
        add_rect(
            slide,
            region,
            fill_token=tint(accent, bg, self._TINT_FRACTION),
            stroke_token=None,
            kind="roundrect",
            corner_radius_emu=int(self._CORNER_IN * EMU_PER_INCH),
        )

        # 2) Left accent border (a slim solid rect flush to the left edge).
        border_w_emu = int(self._BORDER_WIDTH_PT * 12700)
        add_rect(
            slide,
            Region(x=region.x, y=region.y, w=border_w_emu, h=region.h),
            fill_token=accent,
            stroke_token=None,
            kind="rectangle",
        )

        # 3) Inner content stack.
        inner = Region(
            x=region.x + border_w_emu + pad_emu,
            y=region.y + pad_emu,
            w=region.w - border_w_emu - 2 * pad_emu,
            h=region.h - 2 * pad_emu,
        )
        cursor_y = inner.y

        if self.eyebrow:
            eyebrow_step = resolve_type_step(theme, "caption")
            eyebrow_h = int(self._EYEBROW_SIZE_PT * 1.4 * 12700)
            add_textbox(
                slide,
                Region(x=inner.x, y=cursor_y, w=inner.w, h=eyebrow_h),
                text=self.eyebrow.upper(),
                stack=theme.typography.body,
                size_pt=self._EYEBROW_SIZE_PT,
                color_token=accent,
                bold=True,
                align="left",
                anchor="top",
                line_height=eyebrow_step.line_height,
            )
            cursor_y += eyebrow_h

        body_step = resolve_type_step(theme, "body")
        add_textbox(
            slide,
            Region(
                x=inner.x,
                y=cursor_y,
                w=inner.w,
                h=max(0, inner.y + inner.h - cursor_y),
            ),
            text=self.body,
            stack=theme.typography.body,
            size_pt=self._BODY_SIZE_PT,
            color_token=text_primary,
            align="left",
            anchor="top",
            line_height=body_step.line_height,
        )
        return region
