"""Layout ABC, `Region`, and `LayoutOverflowError`.

A `Layout` is anything that can be rendered into a rectangular region on a
slide given a `Theme`. Leaf primitives (`Text`, `Image`, `Icon`, `Shape`,
`StatCallout`, `CodeBlock`) and composable containers (`Stack`, `Grid`,
`TwoColumn`, `HalfBleed`, `Centered`, `IconRow`) all implement this
contract.

Coordinates are EMU throughout; `Region.inches(...)` is the convenience
constructor that takes python-pptx-flavored inches. Overflow is detected
and raises `LayoutOverflowError` at build time — never silently clipped.
"""

from abc import ABC, abstractmethod
from dataclasses import dataclass
from typing import TYPE_CHECKING, Any

if TYPE_CHECKING:
    from pptxforge.design import Theme


EMU_PER_INCH = 914400
"""1 inch in EMU. Use via `Region.inches(...)` rather than multiplying by hand."""


class LayoutOverflowError(ValueError):
    """Raised when a layout element's required bounds exceed its region.

    Carries `element` (a short human label), `required_emu`, `region_emu`,
    and the `axis` that overflowed (`"width"` or `"height"`). The string
    form reports inches of overflow for easy diagnosis.

    Example:
        >>> raise LayoutOverflowError(
        ...     element="Text('Lorem ipsum...')",
        ...     required_emu=(5000000, 2500000),
        ...     region_emu=(4000000, 1500000),
        ...     axis="height",
        ... )
    """

    def __init__(
        self,
        *,
        element: str,
        required_emu: tuple[int, int],
        region_emu: tuple[int, int],
        axis: str,
    ) -> None:
        self.element = element
        self.required_emu = required_emu
        self.region_emu = region_emu
        self.axis = axis
        if axis == "width":
            over = required_emu[0] - region_emu[0]
        elif axis == "height":
            over = required_emu[1] - region_emu[1]
        else:
            raise ValueError(f"axis must be 'width' or 'height', got {axis!r}")
        msg = (
            f"{element} overflows region on {axis}: "
            f"needs {required_emu[0]}x{required_emu[1]} EMU "
            f'({required_emu[0] / EMU_PER_INCH:.2f}" x {required_emu[1] / EMU_PER_INCH:.2f}"), '
            f"region is {region_emu[0]}x{region_emu[1]} EMU "
            f'({region_emu[0] / EMU_PER_INCH:.2f}" x {region_emu[1] / EMU_PER_INCH:.2f}") '
            f"- over by {over} EMU ({over / EMU_PER_INCH:.2f} inches)"
        )
        super().__init__(msg)


@dataclass(frozen=True, slots=True)
class Region:
    """A rectangular region on a slide, stored as EMU integers.

    Construct via `Region(x=…, y=…, w=…, h=…)` when you already have EMU
    values, or via `Region.inches(x=…, y=…, w=…, h=…)` for the common
    "inches" case. Negative widths or heights are rejected.

    Example:
        >>> Region.inches(x=1, y=1, w=8, h=5).w
        7315200
    """

    x: int
    y: int
    w: int
    h: int

    def __post_init__(self) -> None:
        if self.w < 0:
            raise ValueError(f"Region.w must be non-negative EMU, got {self.w}")
        if self.h < 0:
            raise ValueError(f"Region.h must be non-negative EMU, got {self.h}")

    @classmethod
    def inches(cls, *, x: float, y: float, w: float, h: float) -> "Region":
        """Construct from inch floats. 1 inch = 914400 EMU."""
        return cls(
            x=int(x * EMU_PER_INCH),
            y=int(y * EMU_PER_INCH),
            w=int(w * EMU_PER_INCH),
            h=int(h * EMU_PER_INCH),
        )

    def padded(self, *, inches: float) -> "Region":
        """Shrink this region by `inches` on every side."""
        pad = int(inches * EMU_PER_INCH)
        return Region(
            x=self.x + pad,
            y=self.y + pad,
            w=self.w - 2 * pad,
            h=self.h - 2 * pad,
        )


class Layout(ABC):
    """Abstract base class for layouts and leaf primitives.

    Subclasses implement `render(slide, region, theme)` which draws the
    element into `region` on `slide` (a python-pptx `Slide`) using token
    values from `theme`. The return value is the `Region` actually
    occupied — useful for composition and debugging.

    Subclasses MAY override `measure(theme)` to advertise an intrinsic
    bounding size (for e.g. `Centered` to auto-center). `None` means
    "I fill whatever region I'm given".

    Example:
        >>> class MyBox(Layout):
        ...     def render(self, slide, region, theme):
        ...         return region
    """

    @abstractmethod
    def render(self, slide: Any, region: Region, theme: "Theme") -> Region:
        """Render into `region` on `slide`. Return the Region actually occupied.

        Implementations must:

        1. Validate that the element's required bounds fit inside `region`;
           raise `LayoutOverflowError` if not.
        2. Emit python-pptx shapes on `slide`.
        3. Return the `Region` actually occupied (usually == `region` for
           containers; may be smaller for auto-sized primitives).
        """

    def measure(self, theme: "Theme") -> tuple[int, int] | None:
        """Return intrinsic `(width, height)` in EMU, or `None` to mean "fill".

        Override when the element has a known intrinsic size (e.g. `Text`
        at a specific size, `Icon` box, `StatCallout`). Containers that
        stretch to fill their parent region return `None`.
        """
        return None
