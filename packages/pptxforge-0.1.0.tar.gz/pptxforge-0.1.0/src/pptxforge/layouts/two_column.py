"""Two-column layout."""

from typing import TYPE_CHECKING, Any

from pptxforge.layouts._base import EMU_PER_INCH, Layout, LayoutOverflowError, Region

if TYPE_CHECKING:
    from pptxforge.design import Theme


class TwoColumn(Layout):
    """Two children side by side with a configurable split and gap.

    `split` is the fraction of the available width (after the gap) allocated
    to the left column — defaults to `0.5` (equal columns). `gap` is the
    inter-column gutter in inches.

    Example:
        >>> TwoColumn(
        ...     left=Text("Left column", role="body"),
        ...     right=Image("hero.jpg", fit="cover"),
        ...     split=0.4, gap=0.4,
        ... )
    """

    def __init__(
        self,
        *,
        left: Layout,
        right: Layout,
        split: float = 0.5,
        gap: float = 0.3,
    ) -> None:
        if not 0.0 < split < 1.0:
            raise ValueError(f"TwoColumn: split must be in (0, 1), got {split}")
        if gap < 0:
            raise ValueError(f"TwoColumn: gap must be non-negative, got {gap}")
        self.left = left
        self.right = right
        self.split = split
        self.gap = gap

    def render(self, slide: Any, region: Region, theme: "Theme") -> Region:
        gap_emu = int(self.gap * EMU_PER_INCH)
        if gap_emu >= region.w:
            raise LayoutOverflowError(
                element=f'TwoColumn(gap={self.gap}")',
                required_emu=(gap_emu, region.h),
                region_emu=(region.w, region.h),
                axis="width",
            )
        available_w = region.w - gap_emu
        left_w = int(available_w * self.split)
        right_w = available_w - left_w

        left_region = Region(x=region.x, y=region.y, w=left_w, h=region.h)
        right_region = Region(
            x=region.x + left_w + gap_emu,
            y=region.y,
            w=right_w,
            h=region.h,
        )
        self.left.render(slide, left_region, theme)
        self.right.render(slide, right_region, theme)
        return region
