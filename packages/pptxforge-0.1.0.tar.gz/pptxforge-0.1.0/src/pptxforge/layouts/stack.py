"""Vertical stack layout."""

from collections.abc import Sequence
from typing import TYPE_CHECKING, Any

from pptxforge.layouts._base import EMU_PER_INCH, Layout, LayoutOverflowError, Region

if TYPE_CHECKING:
    from pptxforge.design import Theme


class Stack(Layout):
    """Stack children vertically with a configurable gap.

    Each child gets an equal share of the available height unless
    `weights=` is supplied — in which case space is allocated proportionally
    to the provided weights. Width always matches the region.

    `gap` is in inches (typical: 0.1–0.4 for tight UI, 0.5+ for airy).

    Example:
        >>> Stack([Text("Title", role="h2"), Text("Body", role="body")], gap=0.2)
    """

    def __init__(
        self,
        children: Sequence[Layout],
        *,
        gap: float = 0.2,
        weights: Sequence[float] | None = None,
    ) -> None:
        if not children:
            raise ValueError("Stack requires at least one child")
        if weights is not None and len(weights) != len(children):
            raise ValueError(
                f"Stack: weights length {len(weights)} does not match "
                f"children length {len(children)}"
            )
        if weights is not None and any(w <= 0 for w in weights):
            raise ValueError("Stack: weights must be positive")
        self.children = tuple(children)
        self.gap = gap
        self.weights = tuple(weights) if weights is not None else None

    def render(self, slide: Any, region: Region, theme: "Theme") -> Region:
        n = len(self.children)
        gap_emu = int(self.gap * EMU_PER_INCH)
        total_gap = gap_emu * (n - 1)

        if total_gap > region.h:
            raise LayoutOverflowError(
                element=f'Stack({n} children, gap={self.gap}")',
                required_emu=(region.w, total_gap),
                region_emu=(region.w, region.h),
                axis="height",
            )

        available_h = region.h - total_gap
        weights = [1.0] * n if self.weights is None else list(self.weights)
        weight_sum = sum(weights)

        cursor_y = region.y
        for child, w in zip(self.children, weights, strict=True):
            child_h = int(available_h * w / weight_sum)
            child_region = Region(x=region.x, y=cursor_y, w=region.w, h=child_h)
            child.render(slide, child_region, theme)
            cursor_y += child_h + gap_emu
        return region
