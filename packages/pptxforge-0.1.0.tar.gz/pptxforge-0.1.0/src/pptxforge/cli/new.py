"""`pptxforge new` — scaffold a starter deck from a template."""

from pathlib import Path


def run_new(*, name: str, theme: str, target_dir: Path) -> None:
    """Create a starter `<name>.py` + `out/` directory next to it."""
    raise NotImplementedError
