"""`pptxforge` CLI entrypoint."""


def main() -> None:
    """click entrypoint; dispatches to `new`, `build`, etc."""
    raise NotImplementedError
