"""Command-line interface. Entry point `pptxforge` = `pptxforge.cli.main:main`."""
