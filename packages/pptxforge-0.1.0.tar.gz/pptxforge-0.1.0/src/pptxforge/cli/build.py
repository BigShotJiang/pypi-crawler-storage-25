"""`pptxforge build` — execute a user's deck.py and save to out/."""

from pathlib import Path


def run_build(*, deck_path: Path, out_dir: Path, strict: bool) -> None:
    """Import `deck_path`, call `.save(out_dir)` on its `deck` module-level."""
    raise NotImplementedError
