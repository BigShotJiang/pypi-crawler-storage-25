"""Slide-entry transitions — a sealed hierarchy.

Each concrete `Transition` renders itself into the OOXML fragment that
PowerPoint expects in a slide's `<p:transition>` slot (ECMA-376 Part 1
§19.3.1.50 — sits between `<p:clrMapOvr>` and `<p:timing>` under
`<p:sld>`).

Six concrete types:

- `Fade(duration)` — cross-fade.
- `Morph(duration, match)` — PowerPoint's shape-pairing transition.
  `match` ∈ `{"byObject", "byWord", "byChar"}` per research/morph.md §5.
- `Push(direction, duration)` — new slide pushes the old one off.
- `Wipe(direction, duration)` — new slide wipes in.
- `Zoom(direction, duration)` — zoom-in or zoom-out.
- `None_()` — explicit no-transition (emits nothing).

`duration` is in seconds; OOXML wants milliseconds internally.

## Deck vs slide resolution

`Deck(transition=...)` sets a deck-wide default. A slide that passes
`transition=...` to its constructor overrides. A slide that passes
`transition=None` (the Python default) inherits the deck default. A
slide that passes `transition=transitions.None_()` explicitly opts out —
"no transition on this slide, even though the deck defaults to one".
"""

from abc import ABC, abstractmethod
from dataclasses import dataclass
from typing import Literal

from lxml import etree

# ---------------------------------------------------------------------------
# Namespaces — local copies to keep this module self-contained.
# ---------------------------------------------------------------------------

_NS_P = "http://schemas.openxmlformats.org/presentationml/2006/main"
_NS_MC = "http://schemas.openxmlformats.org/markup-compatibility/2006"
_NS_P14 = "http://schemas.microsoft.com/office/powerpoint/2010/main"
_NS_P159 = "http://schemas.microsoft.com/office/powerpoint/2015/09/main"


def _qn(ns: str, local: str) -> str:
    return f"{{{ns}}}{local}"


def _seconds_to_dur_ms(seconds: float) -> int:
    """Convert seconds to the integer milliseconds OOXML's `p14:dur` wants."""
    if seconds <= 0:
        raise ValueError(f"transition duration must be positive seconds, got {seconds}")
    return round(seconds * 1000)


# OOXML's CT_SideDirection enum — used by Push and Wipe.
_SIDE_DIR: dict[str, str] = {"left": "l", "right": "r", "up": "u", "down": "d"}
SideDirection = Literal["left", "right", "up", "down"]

ZoomDirection = Literal["in", "out"]

MorphMatch = Literal["byObject", "byWord", "byChar"]


# ---------------------------------------------------------------------------
# Abstract base
# ---------------------------------------------------------------------------


class Transition(ABC):
    """Abstract base for every slide-entry transition.

    Subclasses are frozen dataclasses. `to_xml_block()` returns the XML
    element to insert under `<p:sld>`, or `None` when no element should
    be emitted (i.e. `None_`).

    Example:
        >>> from pptxforge import transitions
        >>> t = transitions.Fade(duration=0.3)
        >>> t.to_xml_block().tag.endswith('transition')
        True
    """

    @abstractmethod
    def to_xml_block(self) -> etree._Element | None:
        """Render this transition as the element to insert under `<p:sld>`."""


# ---------------------------------------------------------------------------
# None_ — explicit no transition
# ---------------------------------------------------------------------------


@dataclass(frozen=True, slots=True)
class None_(Transition):  # noqa: N801 — public name spec'd by the user brief
    """Explicit "no transition". Emits no `<p:transition>` element.

    Use this to override a deck-wide default on a specific slide:

        >>> Deck(transition=transitions.Fade()).add_content_slide(
        ...     title="...", layout=..., transition=transitions.None_(),
        ... )
    """

    def to_xml_block(self) -> None:
        return None


# ---------------------------------------------------------------------------
# Fade
# ---------------------------------------------------------------------------


@dataclass(frozen=True, slots=True)
class Fade(Transition):
    """Cross-fade from the previous slide.

    Example:
        >>> Fade(duration=0.3)
    """

    duration: float = 0.3

    def to_xml_block(self) -> etree._Element:
        dur_ms = _seconds_to_dur_ms(self.duration)
        trans = etree.Element(
            _qn(_NS_P, "transition"),
            attrib={"spd": "fast", _qn(_NS_P14, "dur"): str(dur_ms)},
            nsmap={"p": _NS_P, "p14": _NS_P14},
        )
        etree.SubElement(trans, _qn(_NS_P, "fade"))
        return trans


# ---------------------------------------------------------------------------
# Morph
# ---------------------------------------------------------------------------


@dataclass(frozen=True, slots=True)
class Morph(Transition):
    """PowerPoint's shape-pairing Morph transition.

    `match` controls what moves:
    - `"byObject"` (default): only shape-level pairing.
    - `"byWord"`: pair shapes AND smoothly rearrange matching words.
    - `"byChar"`: same but per-character (the anagram effect).

    Per research/morph.md §2, Morph requires an `<mc:AlternateContent>`
    wrapper so PowerPoint 2013 and LibreOffice degrade gracefully to a
    fade instead of rendering nothing.

    Example:
        >>> Morph(duration=1.5, match="byWord")
    """

    duration: float = 2.0
    match: MorphMatch = "byObject"

    def to_xml_block(self) -> etree._Element:
        dur_ms = _seconds_to_dur_ms(self.duration)

        ac = etree.Element(_qn(_NS_MC, "AlternateContent"), nsmap={"mc": _NS_MC})

        choice = etree.SubElement(
            ac,
            _qn(_NS_MC, "Choice"),
            attrib={"Requires": "p159"},
            nsmap={"p159": _NS_P159},
        )
        trans = etree.SubElement(
            choice,
            _qn(_NS_P, "transition"),
            attrib={"spd": "slow", _qn(_NS_P14, "dur"): str(dur_ms)},
            nsmap={"p": _NS_P, "p14": _NS_P14},
        )
        etree.SubElement(trans, _qn(_NS_P159, "morph"), attrib={"option": self.match})

        fallback = etree.SubElement(ac, _qn(_NS_MC, "Fallback"))
        fb_trans = etree.SubElement(
            fallback,
            _qn(_NS_P, "transition"),
            attrib={"spd": "slow"},
            nsmap={"p": _NS_P},
        )
        etree.SubElement(fb_trans, _qn(_NS_P, "fade"))
        return ac


# ---------------------------------------------------------------------------
# Push
# ---------------------------------------------------------------------------


@dataclass(frozen=True, slots=True)
class Push(Transition):
    """New slide pushes the old one off.

    `direction` names the direction the NEW slide comes FROM. For "left"
    (default), the new slide enters from the left and pushes the old
    slide out to the right.

    Example:
        >>> Push(direction="right")
    """

    direction: SideDirection = "left"
    duration: float = 0.5

    def to_xml_block(self) -> etree._Element:
        dur_ms = _seconds_to_dur_ms(self.duration)
        trans = etree.Element(
            _qn(_NS_P, "transition"),
            attrib={"spd": "med", _qn(_NS_P14, "dur"): str(dur_ms)},
            nsmap={"p": _NS_P, "p14": _NS_P14},
        )
        etree.SubElement(trans, _qn(_NS_P, "push"), attrib={"dir": _SIDE_DIR[self.direction]})
        return trans


# ---------------------------------------------------------------------------
# Wipe
# ---------------------------------------------------------------------------


@dataclass(frozen=True, slots=True)
class Wipe(Transition):
    """Directional wipe reveal.

    `direction` names the direction the wipe TRAVELS. `"left"` wipes from
    the right side of the slide toward the left (revealing the new slide
    as it goes).

    Example:
        >>> Wipe(direction="up")
    """

    direction: SideDirection = "left"
    duration: float = 0.5

    def to_xml_block(self) -> etree._Element:
        dur_ms = _seconds_to_dur_ms(self.duration)
        trans = etree.Element(
            _qn(_NS_P, "transition"),
            attrib={"spd": "med", _qn(_NS_P14, "dur"): str(dur_ms)},
            nsmap={"p": _NS_P, "p14": _NS_P14},
        )
        etree.SubElement(trans, _qn(_NS_P, "wipe"), attrib={"dir": _SIDE_DIR[self.direction]})
        return trans


# ---------------------------------------------------------------------------
# Zoom
# ---------------------------------------------------------------------------


@dataclass(frozen=True, slots=True)
class Zoom(Transition):
    """Zoom in or zoom out.

    `direction="in"` (default) zooms the new slide in from the center.
    `direction="out"` shrinks the old slide away.

    Example:
        >>> Zoom(direction="out")
    """

    direction: ZoomDirection = "in"
    duration: float = 0.5

    def to_xml_block(self) -> etree._Element:
        dur_ms = _seconds_to_dur_ms(self.duration)
        trans = etree.Element(
            _qn(_NS_P, "transition"),
            attrib={"spd": "med", _qn(_NS_P14, "dur"): str(dur_ms)},
            nsmap={"p": _NS_P, "p14": _NS_P14},
        )
        etree.SubElement(trans, _qn(_NS_P, "zoom"), attrib={"dir": self.direction})
        return trans


# ---------------------------------------------------------------------------
# Coercion — accept string kinds too
# ---------------------------------------------------------------------------


TransitionArg = Transition | Literal["none", "fade", "morph"] | None


def coerce(value: TransitionArg) -> Transition | None:
    """Accept a `Transition`, a string kind, or `None` — normalize to `Transition | None`.

    Back-compat with pre-Phase-6 callers that pass `"fade"` / `"morph"`:

    - `None` → `None` (inherit deck default)
    - `"none"` → `None_()` (explicit opt-out)
    - `"fade"` → `Fade()`
    - `"morph"` → `Morph()`
    - `Transition` instance → passed through

    Any other string raises `ValueError`; any other type raises `TypeError`.
    """
    if value is None:
        return None
    if isinstance(value, Transition):
        return value
    if isinstance(value, str):
        if value == "none":
            return None_()
        if value == "fade":
            return Fade()
        if value == "morph":
            return Morph()
        raise ValueError(
            f"unknown transition kind {value!r}; "
            f"expected 'none', 'fade', 'morph', or a Transition instance"
        )
    raise TypeError(f"transition must be None, str, or Transition; got {type(value).__name__}")


__all__ = [
    "Transition",
    "None_",
    "Fade",
    "Morph",
    "Push",
    "Wipe",
    "Zoom",
    "SideDirection",
    "ZoomDirection",
    "MorphMatch",
    "TransitionArg",
    "coerce",
]
