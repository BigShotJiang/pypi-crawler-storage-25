"""Tests for `pptxforge.Deck` and `DeckValidationError`.

Covers the acceptance criteria from the deck-skeleton phase:

- Empty deck renders a valid .pptx plus a README skeleton.
- Adding a slide that overflows raises `DeckValidationError` at save time,
  naming the offending slide by index + type.
- Speaker notes round-trip through save → open → save without corruption.
"""

from pathlib import Path
from typing import Any

import pytest
from pptx import Presentation

from pptxforge import Deck, themes
from pptxforge.deck import DeckValidationError, SlideValidationFailure
from pptxforge.layouts import Region, Text
from pptxforge.slides import Slide, Transition


class _EmptySlide(Slide):
    """Minimal Slide subclass that renders nothing — used as a size/smoke baseline."""

    def __init__(
        self,
        *,
        notes: str | None = None,
        transition: Transition | None = None,
        morph_from_previous: bool = False,
    ) -> None:
        self.notes = notes
        self.transition = transition
        self.morph_from_previous = morph_from_previous

    def render(self, pptx_slide: Any, theme: Any) -> None:
        # Intentionally empty: we're testing the Deck skeleton, not render.
        return


class _HelloSlide(Slide):
    """Renders a single `Text` primitive into a sensible region."""

    def __init__(self, *, text: str = "Hello", notes: str | None = None) -> None:
        self.text = text
        self.notes = notes
        self.transition: Transition | None = None
        self.morph_from_previous = False

    def render(self, pptx_slide: Any, theme: Any) -> None:
        Text(self.text, role="h1", color="primary").render(
            pptx_slide,
            Region.inches(x=1, y=2.5, w=11, h=1.5),
            theme,
        )


class _OverflowingSlide(Slide):
    """Guaranteed to raise LayoutOverflowError because the region is absurd."""

    def __init__(self) -> None:
        self.notes: str | None = None
        self.transition: Transition | None = None
        self.morph_from_previous = False

    def render(self, pptx_slide: Any, theme: Any) -> None:
        tiny = Region.inches(x=0, y=0, w=0.5, h=0.05)
        huge = "The quick brown fox jumps over the lazy dog. " * 20
        Text(huge, role="hero").render(pptx_slide, tiny, theme)


# ---------------------------------------------------------------------------
# Construction / aspect
# ---------------------------------------------------------------------------


class TestDeckInit:
    def test_default_aspect_is_16_9(self) -> None:
        d = Deck(theme=themes.MIDNIGHT_EXECUTIVE)
        assert d.aspect == "16:9"

    def test_unknown_aspect_rejected(self) -> None:
        with pytest.raises(ValueError, match="unknown aspect"):
            Deck(theme=themes.MIDNIGHT_EXECUTIVE, aspect="21:9")  # type: ignore[arg-type]

    def test_missing_template_rejected(self, tmp_path: Path) -> None:
        with pytest.raises(FileNotFoundError):
            Deck(
                theme=themes.MIDNIGHT_EXECUTIVE,
                template=tmp_path / "nope.pptx",
            )

    @pytest.mark.parametrize(
        "aspect,w,h",
        [
            ("16:9", 12192000, 6858000),
            ("4:3", 9144000, 6858000),
            ("16:10", 12192000, 7620000),
        ],
    )
    def test_aspect_dims(self, tmp_path: Path, aspect: str, w: int, h: int) -> None:
        d = Deck(theme=themes.MIDNIGHT_EXECUTIVE, aspect=aspect)  # type: ignore[arg-type]
        d.save(tmp_path)
        prs = Presentation(str(tmp_path / "deck.pptx"))
        assert prs.slide_width == w
        assert prs.slide_height == h


# ---------------------------------------------------------------------------
# add_slide
# ---------------------------------------------------------------------------


class TestAddSlide:
    def test_add_slide_appends(self) -> None:
        d = Deck(theme=themes.MIDNIGHT_EXECUTIVE)
        s1 = _EmptySlide()
        s2 = _EmptySlide()
        d.add_slide(s1)
        d.add_slide(s2)
        assert d.slides == (s1, s2)

    def test_add_slide_returns_slide(self) -> None:
        d = Deck(theme=themes.MIDNIGHT_EXECUTIVE)
        s = _EmptySlide()
        assert d.add_slide(s) is s

    def test_add_slide_type_check(self) -> None:
        d = Deck(theme=themes.MIDNIGHT_EXECUTIVE)
        with pytest.raises(TypeError, match=r"expects a pptxforge\.slides\.Slide"):
            d.add_slide("not a slide")  # type: ignore[arg-type]

    def test_slides_is_tuple_copy(self) -> None:
        """`deck.slides` returns a snapshot — mutation does not affect the deck."""
        d = Deck(theme=themes.MIDNIGHT_EXECUTIVE)
        d.add_slide(_EmptySlide())
        snapshot = d.slides
        assert len(snapshot) == 1
        # Tuples are immutable — can't mutate. But more importantly,
        # adding a slide doesn't retroactively appear in the snapshot.
        d.add_slide(_EmptySlide())
        assert len(snapshot) == 1
        assert len(d.slides) == 2


# ---------------------------------------------------------------------------
# save — success paths
# ---------------------------------------------------------------------------


class TestSaveEmpty:
    def test_empty_deck_produces_valid_pptx(self, tmp_path: Path) -> None:
        d = Deck(theme=themes.MIDNIGHT_EXECUTIVE)
        pptx_path = d.save(tmp_path)
        assert pptx_path == (tmp_path / "deck.pptx").resolve()
        assert pptx_path.exists()
        # Re-open via python-pptx to prove it's a valid OOXML package.
        prs = Presentation(str(pptx_path))
        assert len(prs.slides) == 0

    def test_empty_deck_writes_readme(self, tmp_path: Path) -> None:
        d = Deck(theme=themes.MIDNIGHT_EXECUTIVE)
        d.save(tmp_path)
        readme = tmp_path / "README.md"
        assert readme.exists()
        content = readme.read_text(encoding="utf-8")
        assert "Midnight Executive" in content
        assert "No add-ins in this deck" in content

    def test_save_creates_output_dir(self, tmp_path: Path) -> None:
        d = Deck(theme=themes.MIDNIGHT_EXECUTIVE)
        target = tmp_path / "nested" / "deep"
        d.save(target)
        assert (target / "deck.pptx").exists()

    def test_save_returns_absolute_path(self, tmp_path: Path) -> None:
        d = Deck(theme=themes.MIDNIGHT_EXECUTIVE)
        out = d.save(tmp_path)
        assert out.is_absolute()

    def test_save_only_writes_pptx_and_readme(self, tmp_path: Path) -> None:
        """No add-in artifacts in this phase — strictly 2 files per save."""
        d = Deck(theme=themes.MIDNIGHT_EXECUTIVE)
        d.save(tmp_path)
        contents = sorted(p.name for p in tmp_path.iterdir())
        assert contents == ["README.md", "deck.pptx"]


class TestSaveWithSlides:
    def test_single_slide_renders(self, tmp_path: Path) -> None:
        d = Deck(theme=themes.MIDNIGHT_EXECUTIVE)
        d.add_slide(_HelloSlide(text="Only slide"))
        d.save(tmp_path)
        prs = Presentation(str(tmp_path / "deck.pptx"))
        assert len(prs.slides) == 1
        # At least one textbox on the slide
        assert len(prs.slides[0].shapes) >= 1


# ---------------------------------------------------------------------------
# save — validation
# ---------------------------------------------------------------------------


class TestValidation:
    def test_overflow_raises_deck_validation_error(self, tmp_path: Path) -> None:
        d = Deck(theme=themes.MIDNIGHT_EXECUTIVE)
        d.add_slide(_OverflowingSlide())
        with pytest.raises(DeckValidationError) as exc_info:
            d.save(tmp_path)
        err = exc_info.value
        assert len(err.failures) == 1
        assert err.failures[0].index == 0
        assert err.failures[0].slide_type == "_OverflowingSlide"

    def test_error_message_names_slide(self, tmp_path: Path) -> None:
        d = Deck(theme=themes.MIDNIGHT_EXECUTIVE)
        d.add_slide(_HelloSlide())
        d.add_slide(_OverflowingSlide())
        d.add_slide(_HelloSlide())
        with pytest.raises(DeckValidationError) as exc_info:
            d.save(tmp_path)
        msg = str(exc_info.value)
        assert "slide 1" in msg
        assert "_OverflowingSlide" in msg
        assert "overflows region" in msg

    def test_all_overflows_collected(self, tmp_path: Path) -> None:
        d = Deck(theme=themes.MIDNIGHT_EXECUTIVE)
        d.add_slide(_OverflowingSlide())
        d.add_slide(_HelloSlide())
        d.add_slide(_OverflowingSlide())
        with pytest.raises(DeckValidationError) as exc_info:
            d.save(tmp_path)
        assert len(exc_info.value.failures) == 2
        assert [f.index for f in exc_info.value.failures] == [0, 2]

    def test_failed_save_writes_no_files(self, tmp_path: Path) -> None:
        """On validation failure, the target directory stays clean."""
        d = Deck(theme=themes.MIDNIGHT_EXECUTIVE)
        d.add_slide(_OverflowingSlide())
        target = tmp_path / "out"
        with pytest.raises(DeckValidationError):
            d.save(target)
        assert not target.exists(), "save must not create output dir on failure"

    def test_validation_error_requires_failures(self) -> None:
        with pytest.raises(ValueError, match="at least one"):
            DeckValidationError([])

    def test_failure_dataclass_fields(self) -> None:
        f = SlideValidationFailure(index=3, slide_type="FooSlide", exc=ValueError("oops"))
        assert f.index == 3
        assert f.slide_type == "FooSlide"
        assert isinstance(f.exc, ValueError)


# ---------------------------------------------------------------------------
# Speaker notes round-trip
# ---------------------------------------------------------------------------


class TestNotesRoundTrip:
    def test_notes_survive_save_open(self, tmp_path: Path) -> None:
        d = Deck(theme=themes.MIDNIGHT_EXECUTIVE)
        d.add_slide(_HelloSlide(text="Slide A", notes="Talk about X for 90 seconds."))
        d.add_slide(_HelloSlide(text="Slide B", notes="Then Y — hand off to Jane."))
        d.save(tmp_path)

        prs = Presentation(str(tmp_path / "deck.pptx"))
        notes_0 = prs.slides[0].notes_slide.notes_text_frame.text
        notes_1 = prs.slides[1].notes_slide.notes_text_frame.text
        assert "Talk about X for 90 seconds." in notes_0
        assert "Then Y — hand off to Jane." in notes_1

    def test_notes_survive_save_open_save(self, tmp_path: Path) -> None:
        """Open a save, re-save via python-pptx, and verify notes still intact."""
        d = Deck(theme=themes.MIDNIGHT_EXECUTIVE)
        d.add_slide(
            _HelloSlide(
                text="Slide",
                notes="Keep intact across two round-trips.",
            )
        )
        d.save(tmp_path)

        prs = Presentation(str(tmp_path / "deck.pptx"))
        prs.save(str(tmp_path / "deck-2.pptx"))

        prs2 = Presentation(str(tmp_path / "deck-2.pptx"))
        notes = prs2.slides[0].notes_slide.notes_text_frame.text
        assert "Keep intact across two round-trips." in notes

    def test_empty_notes_is_fine(self, tmp_path: Path) -> None:
        d = Deck(theme=themes.MIDNIGHT_EXECUTIVE)
        d.add_slide(_HelloSlide(text="No notes"))
        d.save(tmp_path)
        # Re-open to confirm validity
        Presentation(str(tmp_path / "deck.pptx"))


# ---------------------------------------------------------------------------
# Properties / miscellaneous
# ---------------------------------------------------------------------------


def test_theme_property_returns_given_theme() -> None:
    theme = themes.FOREST_MOSS
    d = Deck(theme=theme)
    assert d.theme is theme


def test_different_themes_produce_different_readmes(tmp_path: Path) -> None:
    d1 = Deck(theme=themes.MIDNIGHT_EXECUTIVE)
    d1.save(tmp_path / "a")
    d2 = Deck(theme=themes.FOREST_MOSS)
    d2.save(tmp_path / "b")

    r1 = (tmp_path / "a" / "README.md").read_text(encoding="utf-8")
    r2 = (tmp_path / "b" / "README.md").read_text(encoding="utf-8")
    assert "Midnight Executive" in r1
    assert "Forest & Moss" in r2
    assert r1 != r2


def test_title_and_author_in_core_properties(tmp_path: Path) -> None:
    d = Deck(
        theme=themes.MIDNIGHT_EXECUTIVE,
        title="Q1 results",
        author="Jane Doe",
    )
    d.save(tmp_path)
    prs = Presentation(str(tmp_path / "deck.pptx"))
    assert prs.core_properties.title == "Q1 results"
    assert prs.core_properties.author == "Jane Doe"
