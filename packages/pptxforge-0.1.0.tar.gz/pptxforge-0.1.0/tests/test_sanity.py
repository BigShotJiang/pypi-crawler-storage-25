"""Sanity: the package imports and exposes its public surface."""

import pptxforge


def test_import() -> None:
    assert pptxforge.__version__


def test_public_surface() -> None:
    assert hasattr(pptxforge, "Deck")
    assert hasattr(pptxforge, "themes")
    assert hasattr(pptxforge, "layouts")
    assert hasattr(pptxforge, "addins")


def test_theme_catalog() -> None:
    from pptxforge import themes

    for name in (
        "Theme",
        "Palette",
        "MIDNIGHT_EXECUTIVE",
        "FOREST_MOSS",
        "CORAL_ENERGY",
        "SLATE_MINIMALIST",
        "ROYAL_PLUM",
        "PACIFIC_DEEP",
        "MONOCHROME_INK",
        "AMBER_EDITORIAL",
        "SUNRISE_CITRUS",
        "BERRY_BOLD",
    ):
        assert hasattr(themes, name), name


def test_addin_component_catalog() -> None:
    from pptxforge.addins import components

    for name in (
        "AddInComponent",
        "MoleculeViewer",
        "SpreadsheetPreview",
        "MapViewer",
        "CodeRunner",
        "KioskWebview",
        "PresenterConsole",
    ):
        assert hasattr(components, name), name
