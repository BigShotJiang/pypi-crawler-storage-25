"""Tests for `pptxforge.transitions` — per-type XML, Deck resolution, morph warning."""

import warnings
import zipfile
from pathlib import Path
from typing import Any

import pytest
from lxml import etree
from pptx import Presentation
from pptx.util import Emu

from pptxforge import Deck, themes, transitions
from pptxforge.layouts import Region, Text
from pptxforge.slides import Slide
from pptxforge.transitions import (
    Fade,
    Morph,
    None_,
    Push,
    Transition,
    Wipe,
    Zoom,
    coerce,
)

NS_P = "http://schemas.openxmlformats.org/presentationml/2006/main"
NS_MC = "http://schemas.openxmlformats.org/markup-compatibility/2006"
NS_P14 = "http://schemas.microsoft.com/office/powerpoint/2010/main"
NS_P159 = "http://schemas.microsoft.com/office/powerpoint/2015/09/main"


def _qn(uri: str, local: str) -> str:
    return f"{{{uri}}}{local}"


# ---------------------------------------------------------------------------
# Helper slide for Deck-level tests
# ---------------------------------------------------------------------------


class _NamedSlide(Slide):
    """Minimal Slide with a named shape we can pair on."""

    def __init__(
        self,
        *,
        text: str,
        shape_name: str,
        transition: Transition | None = None,
        notes: str | None = None,
    ) -> None:
        self.text = text
        self.shape_name = shape_name
        self.notes = notes
        self.transition = transition
        self.morph_from_previous = False

    def render(self, pptx_slide: Any, theme: Any) -> None:
        Text(self.text, role="h1", color="primary").render(
            pptx_slide, Region.inches(x=1, y=2.5, w=11, h=2), theme
        )
        # Rewrite the newly added text box's cNvPr/@name so two slides can
        # pair by @name during the morph warning check.
        sp_tree = pptx_slide.shapes._spTree
        for cnv_pr in sp_tree.iter(_qn(NS_P, "cNvPr")):
            if cnv_pr.get("id") != "1":  # skip the spTree's own cNvPr
                cnv_pr.set("name", self.shape_name)
                break


# ---------------------------------------------------------------------------
# Per-type XML shape
# ---------------------------------------------------------------------------


class TestNoneTransition:
    def test_emits_no_element(self) -> None:
        # Upcast to the abstract type so mypy picks the base signature
        # (which is Optional) instead of None_'s narrower `-> None`.
        t: Transition = None_()
        assert t.to_xml_block() is None


class TestFade:
    def test_default_renders(self) -> None:
        el = Fade().to_xml_block()
        assert el is not None
        assert el.tag == _qn(NS_P, "transition")
        assert el.find(_qn(NS_P, "fade")) is not None

    def test_duration_converted_to_ms(self) -> None:
        el = Fade(duration=0.5).to_xml_block()
        assert el.get(_qn(NS_P14, "dur")) == "500"

    def test_negative_duration_rejected(self) -> None:
        with pytest.raises(ValueError, match="positive"):
            Fade(duration=0).to_xml_block()
        with pytest.raises(ValueError, match="positive"):
            Fade(duration=-1).to_xml_block()


class TestMorphTransition:
    def test_emits_alternate_content_with_p159(self) -> None:
        el = Morph().to_xml_block()
        assert el.tag == _qn(NS_MC, "AlternateContent")
        choice = el.find(_qn(NS_MC, "Choice"))
        assert choice is not None
        assert choice.get("Requires") == "p159"
        morph = choice.find(f"{_qn(NS_P, 'transition')}/{_qn(NS_P159, 'morph')}")
        assert morph is not None
        assert morph.get("option") == "byObject"

    def test_has_fade_fallback(self) -> None:
        el = Morph().to_xml_block()
        fallback = el.find(_qn(NS_MC, "Fallback"))
        assert fallback is not None
        assert fallback.find(f"{_qn(NS_P, 'transition')}/{_qn(NS_P, 'fade')}") is not None

    @pytest.mark.parametrize("match", ["byObject", "byWord", "byChar"])
    def test_match_options(self, match: str) -> None:
        el = Morph(match=match).to_xml_block()  # type: ignore[arg-type]
        morph = el.find(f".//{_qn(NS_P159, 'morph')}")
        assert morph.get("option") == match

    def test_duration_converted_to_ms(self) -> None:
        el = Morph(duration=1.5).to_xml_block()
        trans = el.find(f"{_qn(NS_MC, 'Choice')}/{_qn(NS_P, 'transition')}")
        assert trans.get(_qn(NS_P14, "dur")) == "1500"


class TestPush:
    @pytest.mark.parametrize(
        "direction,dir_attr",
        [("left", "l"), ("right", "r"), ("up", "u"), ("down", "d")],
    )
    def test_direction_mapped(self, direction: str, dir_attr: str) -> None:
        el = Push(direction=direction).to_xml_block()  # type: ignore[arg-type]
        push = el.find(_qn(NS_P, "push"))
        assert push is not None
        assert push.get("dir") == dir_attr


class TestWipe:
    @pytest.mark.parametrize(
        "direction,dir_attr",
        [("left", "l"), ("right", "r"), ("up", "u"), ("down", "d")],
    )
    def test_direction_mapped(self, direction: str, dir_attr: str) -> None:
        el = Wipe(direction=direction).to_xml_block()  # type: ignore[arg-type]
        wipe = el.find(_qn(NS_P, "wipe"))
        assert wipe is not None
        assert wipe.get("dir") == dir_attr


class TestZoom:
    @pytest.mark.parametrize("direction", ["in", "out"])
    def test_direction(self, direction: str) -> None:
        el = Zoom(direction=direction).to_xml_block()  # type: ignore[arg-type]
        zoom = el.find(_qn(NS_P, "zoom"))
        assert zoom is not None
        assert zoom.get("dir") == direction


# ---------------------------------------------------------------------------
# coerce
# ---------------------------------------------------------------------------


class TestCoerce:
    def test_none_passes_through(self) -> None:
        assert coerce(None) is None

    def test_instance_passes_through(self) -> None:
        f = Fade(duration=0.2)
        assert coerce(f) is f

    def test_string_none_returns_none_instance(self) -> None:
        assert isinstance(coerce("none"), None_)

    def test_string_fade_returns_fade(self) -> None:
        assert isinstance(coerce("fade"), Fade)

    def test_string_morph_returns_morph(self) -> None:
        assert isinstance(coerce("morph"), Morph)

    def test_unknown_string_rejected(self) -> None:
        with pytest.raises(ValueError, match="unknown transition kind"):
            coerce("zoom")  # type: ignore[arg-type]  # not a back-compat alias

    def test_bad_type_rejected(self) -> None:
        with pytest.raises(TypeError):
            coerce(42)  # type: ignore[arg-type]


# ---------------------------------------------------------------------------
# Deck-level resolution
# ---------------------------------------------------------------------------


class TestDeckDefault:
    def test_deck_default_applies_to_slides_without_override(self, tmp_path: Path) -> None:
        deck = Deck(theme=themes.MIDNIGHT_EXECUTIVE, transition=transitions.Fade(duration=0.3))
        deck.add_slide(_NamedSlide(text="A", shape_name="Shape 1"))
        deck.save(tmp_path)

        with zipfile.ZipFile(tmp_path / "deck.pptx") as z:
            slide1_xml = z.read("ppt/slides/slide1.xml")
        tree = etree.fromstring(slide1_xml)
        trans = tree.find(f".//{_qn(NS_P, 'transition')}")
        assert trans is not None
        assert trans.find(_qn(NS_P, "fade")) is not None

    def test_slide_override_wins_over_deck_default(self, tmp_path: Path) -> None:
        deck = Deck(theme=themes.MIDNIGHT_EXECUTIVE, transition=transitions.Fade())
        deck.add_slide(
            _NamedSlide(
                text="Override",
                shape_name="Shape 1",
                transition=transitions.Push(direction="left"),
            )
        )
        deck.save(tmp_path)

        with zipfile.ZipFile(tmp_path / "deck.pptx") as z:
            slide1_xml = z.read("ppt/slides/slide1.xml")
        tree = etree.fromstring(slide1_xml)
        assert tree.find(f".//{_qn(NS_P, 'push')}") is not None
        assert tree.find(f".//{_qn(NS_P, 'fade')}") is None

    def test_none_instance_opts_out_of_deck_default(self, tmp_path: Path) -> None:
        """`transitions.None_()` explicitly suppresses the deck default."""
        deck = Deck(theme=themes.MIDNIGHT_EXECUTIVE, transition=transitions.Fade())
        deck.add_slide(
            _NamedSlide(
                text="Silent",
                shape_name="Shape 1",
                transition=transitions.None_(),
            )
        )
        deck.save(tmp_path)

        with zipfile.ZipFile(tmp_path / "deck.pptx") as z:
            slide1_xml = z.read("ppt/slides/slide1.xml")
        tree = etree.fromstring(slide1_xml)
        assert tree.find(f".//{_qn(NS_P, 'transition')}") is None

    def test_no_deck_default_and_no_slide_override_emits_nothing(self, tmp_path: Path) -> None:
        deck = Deck(theme=themes.MIDNIGHT_EXECUTIVE)
        deck.add_slide(_NamedSlide(text="x", shape_name="Shape 1"))
        deck.save(tmp_path)

        with zipfile.ZipFile(tmp_path / "deck.pptx") as z:
            slide1_xml = z.read("ppt/slides/slide1.xml")
        tree = etree.fromstring(slide1_xml)
        assert tree.find(f".//{_qn(NS_P, 'transition')}") is None


# ---------------------------------------------------------------------------
# Morph UserWarning
# ---------------------------------------------------------------------------


class TestMorphWarning:
    def test_warns_on_broken_morph_pair(self, tmp_path: Path) -> None:
        """Two slides with distinct shape names → warn on second slide's Morph."""
        deck = Deck(theme=themes.MIDNIGHT_EXECUTIVE)
        deck.add_slide(_NamedSlide(text="A", shape_name="Unique A"))
        deck.add_slide(_NamedSlide(text="B", shape_name="Unique B", transition=transitions.Morph()))
        with warnings.catch_warnings(record=True) as caught:
            warnings.simplefilter("always")
            deck.save(tmp_path)
        matched = [w for w in caught if issubclass(w.category, UserWarning)]
        assert matched, "expected UserWarning for broken morph pair"
        msg = str(matched[0].message)
        assert "Morph" in msg
        assert "shape-identity overlap" in msg

    def test_no_warning_when_names_match(self, tmp_path: Path) -> None:
        """Both slides carry a shape named 'Hero' → no warning."""
        deck = Deck(theme=themes.MIDNIGHT_EXECUTIVE)
        deck.add_slide(_NamedSlide(text="A", shape_name="Hero"))
        deck.add_slide(_NamedSlide(text="B", shape_name="Hero", transition=transitions.Morph()))
        with warnings.catch_warnings(record=True) as caught:
            warnings.simplefilter("always")
            deck.save(tmp_path)
        assert not [w for w in caught if issubclass(w.category, UserWarning)], (
            "unexpected UserWarning for a deck with matching shape names"
        )

    def test_no_warning_when_bang_names_match(self, tmp_path: Path) -> None:
        """Two slides carry `!!hero` → tier-1 pairing, no warning."""
        deck = Deck(theme=themes.MIDNIGHT_EXECUTIVE)
        deck.add_slide(_NamedSlide(text="A", shape_name="!!hero"))
        deck.add_slide(_NamedSlide(text="B", shape_name="!!hero", transition=transitions.Morph()))
        with warnings.catch_warnings(record=True) as caught:
            warnings.simplefilter("always")
            deck.save(tmp_path)
        assert not [w for w in caught if issubclass(w.category, UserWarning)]

    def test_no_warning_for_non_morph_transitions(self, tmp_path: Path) -> None:
        """Fade / Push / etc. don't care about pairing — no warning."""
        deck = Deck(theme=themes.MIDNIGHT_EXECUTIVE)
        deck.add_slide(_NamedSlide(text="A", shape_name="A"))
        deck.add_slide(_NamedSlide(text="B", shape_name="B", transition=transitions.Fade()))
        with warnings.catch_warnings(record=True) as caught:
            warnings.simplefilter("always")
            deck.save(tmp_path)
        assert not [w for w in caught if issubclass(w.category, UserWarning)]

    def test_no_warning_on_first_slide(self, tmp_path: Path) -> None:
        """A Morph on slide 0 has no predecessor — don't warn."""
        deck = Deck(theme=themes.MIDNIGHT_EXECUTIVE)
        deck.add_slide(_NamedSlide(text="A", shape_name="A", transition=transitions.Morph()))
        with warnings.catch_warnings(record=True) as caught:
            warnings.simplefilter("always")
            deck.save(tmp_path)
        assert not [w for w in caught if issubclass(w.category, UserWarning)]


# ---------------------------------------------------------------------------
# Round-trip — save/open/save preserves the transition element.
# ---------------------------------------------------------------------------


class TestRoundTrip:
    @pytest.mark.parametrize(
        "transition,probe_tag",
        [
            (transitions.Fade(), _qn(NS_P, "fade")),
            (transitions.Push(direction="right"), _qn(NS_P, "push")),
            (transitions.Wipe(direction="up"), _qn(NS_P, "wipe")),
            (transitions.Zoom(direction="in"), _qn(NS_P, "zoom")),
            (transitions.Morph(match="byChar"), _qn(NS_P159, "morph")),
        ],
    )
    def test_transition_survives_python_pptx_roundtrip(
        self, tmp_path: Path, transition: Transition, probe_tag: str
    ) -> None:
        """Save, reopen via python-pptx, resave, confirm the tag is still there."""
        deck = Deck(theme=themes.MIDNIGHT_EXECUTIVE)
        deck.add_slide(_NamedSlide(text="A", shape_name="Hero"))
        deck.add_slide(_NamedSlide(text="B", shape_name="Hero", transition=transition))
        deck.save(tmp_path)

        # python-pptx open + save dance.
        prs = Presentation(str(tmp_path / "deck.pptx"))
        prs.save(str(tmp_path / "roundtrip.pptx"))

        with zipfile.ZipFile(tmp_path / "roundtrip.pptx") as z:
            slide2_xml = z.read("ppt/slides/slide2.xml")
        tree = etree.fromstring(slide2_xml)
        assert tree.find(f".//{probe_tag}") is not None, (
            f"{probe_tag} missing after python-pptx round-trip"
        )

    def test_none_still_emits_nothing_after_roundtrip(self, tmp_path: Path) -> None:
        deck = Deck(theme=themes.MIDNIGHT_EXECUTIVE)
        deck.add_slide(_NamedSlide(text="A", shape_name="A", transition=transitions.None_()))
        deck.save(tmp_path)

        prs = Presentation(str(tmp_path / "deck.pptx"))
        prs.save(str(tmp_path / "roundtrip.pptx"))

        with zipfile.ZipFile(tmp_path / "roundtrip.pptx") as z:
            slide1_xml = z.read("ppt/slides/slide1.xml")
        tree = etree.fromstring(slide1_xml)
        assert tree.find(f".//{_qn(NS_P, 'transition')}") is None


# Sanity check that the sealed hierarchy really is what we claim.
def test_all_transitions_subclass_Transition() -> None:
    for cls in (None_, Fade, Morph, Push, Wipe, Zoom):
        assert issubclass(cls, Transition)


def test_Emu_import_not_needed() -> None:
    """Transition classes should not require python-pptx's Emu —
    they emit raw lxml elements.
    """
    # Fade().to_xml_block() should not crash on bare construction.
    assert Fade().to_xml_block() is not None


# Silence unused-import (Emu imported defensively for fixtures).
_ = Emu
