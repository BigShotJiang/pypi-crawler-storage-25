import colorama
from ollama import chat as ollama_chat, Client as OllamaClient
from openai import OpenAI
import argparse
import subprocess
import os
import json
import urllib.request
import urllib.error

def get_settings_path():
    return os.path.join(os.path.dirname(__file__), "settings.json")

def load_settings():
    path = get_settings_path()
    if os.path.exists(path):
        try:
            with open(path, "r", encoding="utf-8") as f:
                return json.load(f)
        except Exception:
            pass
    return {}

def save_settings(provider, model):
    path = get_settings_path()
    try:
        with open(path, "w", encoding="utf-8") as f:
            json.dump({"provider": provider, "model": model}, f)
    except Exception:
        pass

def check_endpoint(url):
    try:
        urllib.request.urlopen(url, timeout=1.0)
        return True
    except (urllib.error.URLError, ValueError):
        return False

def main():
    parser = argparse.ArgumentParser(description="Comet - AI commit message generator")
    parser.add_argument("--provider", choices=["auto", "ollama", "lmstudio"], default="auto", help="Choose AI provider")
    args = parser.parse_args()

    provider = args.provider
    model = ""
    if provider == "auto":
        settings = load_settings()
        if "provider" in settings:
            provider = settings["provider"]
        if "model" in settings:
            model = settings["model"]

    diff = subprocess.run(["git", "diff", "HEAD", "-U5"], cwd=os.getcwd(), capture_output=True, text=True, check=True, encoding="utf-8").stdout
    commits = subprocess.run(["git", "log", "-n", "5", "--oneline"], cwd=os.getcwd(), capture_output=True, text=True, check=True, encoding="utf-8").stdout
    
    app = CometTUI(commit="Generating...", model=model, diff=diff, commits=commits, allModels=[], provider=provider, client=None)
    result = app.run()
    if result: print(result)

from textual.app import App, ComposeResult
from textual.widgets import TextArea, Button, Label
from textual.containers import Horizontal, Vertical
from textual.binding import Binding
from textual import work, events
import subprocess, colorama

class CustomTextArea(TextArea):
    Binding("ctrl+r", "regenerate_action", "Regenerate", priority=True),
    Binding("ctrl+t", "exit_action", "Terminate", priority=True)

    def on_key(self, event: events.Key) -> None:
        if event.key == "enter":
            self.app.action_commit_action()
            event.prevent_default()

    def action_cursor_down(self, select: bool = False) -> None:
        if self.cursor_location[0] == self.document.line_count - 1:
            loc = self.cursor_location
            self.cursor_location = (self.document.line_count - 1, len(self.document.get_line(self.document.line_count - 1)))
            self.insert("\n")
            self.cursor_location = (loc[0] + 1, min(loc[1], len(self.document.get_line(loc[0] + 1))))
        else:
            super().action_cursor_down(select=select)

    def action_cursor_up(self, select: bool = False) -> None:
        row = self.cursor_location[0]
        if row > 0 and row == self.document.line_count - 1 and len(self.document.get_line(row)) == 0:
            self.action_delete_left()
        else:
            super().action_cursor_up(select=select)

class CometTUI(App):
    DEFAULT_CSS = """
    Screen {
        width: 100%;
        height: 100%;
        align: center middle;
        background: $surface;
    }

    Static {
        background: $surface;
    }

    Button {
        border: none;
    }
    
    Button:focus {
        border: none;
    }
    
    Button:hover {
        border: none;
    }

    #main_container {
        width: 100%;
        height: 100%;
        padding: 1 2;
        background: $surface;
    }

    #input_row {
        height: auto;
        padding: 1;
        background: $surface;
        border: $primary;
    }

    #input {
        width: 1fr;
        height: 3;
        border: none;
        background: transparent;
    }

    #input:focus {
        border: none;
    }

    #regenBtn {
        height: 3;
        margin-left: 1;
        background: $primary;
        border: none;
    }

    #action_row {
        height: auto;
        margin-top: 1;
    }

    #commitBtn {
        width: 1fr;
        height: 3;
        background: $primary;
        border: none;
    }

    #cancelBtn {
        margin-left: 1;
        height: 3;
        background: $secondary;
        border: none;
    }

    #shortcuts {
        width: 100%;
        text-align: center;
        color: white;
        margin-top: 1;
    }

    #logo {
        width: 100%;
        text-align: center;
        color: $primary;
        margin-bottom: 1;
    }
    """

    BINDINGS = [
        Binding("ctrl+r", "regenerate_action", "Regenerate", priority=True),
        Binding("ctrl+t", "exit_action", "Terminate", priority=True),
        Binding("ctrl+z", "undo_commit", "Undo Commit", priority=True),
        Binding("tab", "swap_model", "Swap Model", priority=True)
    ]

    def __init__(self, commit: str, model: str, diff: str, commits: str, allModels: list[str], provider: str = "ollama", client = None):
        super().__init__()
        self.commit = commit
        self.model = model or "Loading..."
        self.diff = diff
        self.commits = commits
        self.allModels = allModels
        self.provider = provider
        self.client = client

    def compose(self) -> ComposeResult:
        with Vertical(id="main_container"):
            #ascii logo
            yield Label(""" ▄▄▄▄  ▄▄▄  ▄▄   ▄▄ ▄▄▄▄▄ ▄▄▄▄▄▄   ┌─┐┬  ┬\n██▀▀▀ ██▀██ ██▀▄▀██ ██▄▄    ██     │  │  │\n▀████ ▀███▀ ██   ██ ██▄▄▄   ██     └─┘┴─┘┴""", id="logo")
            with Horizontal(id="input_row"):
                yield CustomTextArea(self.commit, id="input", show_line_numbers=False)
                yield Button(" ₊✦  Regenerate  ", id="regenBtn")
            with Horizontal(id="action_row"):
                yield Button(" ✔   Commit", id="commitBtn")
                yield Button(" 🗙   Terminate", id="cancelBtn")
            yield Label("[white][b]ctrl+r[/b][/white] [gray]regenerate[/gray]    [white][b]enter[/b][/white] [gray]continue[/gray]    [white][b]tab[/b][/white] [gray]swap model[/gray]    [white][b]ctrl+z[/b][/white] [gray]undo[/gray]    [white][b]↓/↑[/b][/white] [gray]move lines[/gray]    [white][b]ctrl+t[/b][/white] [gray]terminate[/gray]", id="shortcuts")

    def action_swap_model(self) -> None:
        if not self.allModels: return
        try:
            currentIndex = self.allModels.index(self.model)
        except ValueError:
            currentIndex = -1
        nextIndex = (currentIndex + 1) % len(self.allModels)
        self.model = self.allModels[nextIndex]
        self.query_one("#input_row").border_title = f"{self.model}"
        save_settings(self.provider, self.model)

    def action_regenerate_action(self) -> None:
        regenBtn = self.query_one("#regenBtn", Button)
        if not regenBtn.disabled:
            regenBtn.press()

    def action_exit_action(self) -> None:
        self.query_one("#cancelBtn", Button).press()

    def action_commit_action(self) -> None:
        commitBtn = self.query_one("#commitBtn", Button)
        if not commitBtn.disabled:
            commitBtn.press()

    def action_undo_commit(self) -> None:
        commitBtn = self.query_one("#commitBtn", Button)
        if str(commitBtn.label).strip() == "Sync  ➤":
            subprocess.run(["git", "reset", "HEAD~1"], capture_output=True)
            commitBtn.label = " ✔   Commit"

    def on_mount(self) -> None:
        self.query_one("#input_row").border_title = f"{self.model}"
        self.query_one("#regenBtn").disabled = True
        self.query_one("#commitBtn").disabled = True
        self.initialize_llm()

    @work(thread=True)
    def initialize_llm(self) -> None:
        if self.provider == "auto":
            lmstudioUp = check_endpoint("http://localhost:1234/v1/models")
            ollamaUp = check_endpoint("http://localhost:11434/api/tags")
            if lmstudioUp and not ollamaUp:
                self.provider = "lmstudio"
            else:
                self.provider = "ollama"

        if self.provider == "ollama":
            self.client = OllamaClient()
            try:
                allModelsData = sorted(self.client.list().models, key=lambda m:m.size, reverse=False)
                self.allModels = [m.model for m in allModelsData]
                loadedModels = self.client.ps().models
                defaultModel = loadedModels[0].model if loadedModels else (self.allModels[0] if self.allModels else "unknown")
            except Exception:
                self.allModels = ["unknown"]
                defaultModel = "unknown"
        elif self.provider == "lmstudio":
            self.client = OpenAI(base_url="http://localhost:1234/v1", api_key="lm-studio")
            try:
                modelsData = self.client.models.list().data
                self.allModels = [m.id for m in modelsData]
                defaultModel = self.allModels[0] if self.allModels else "unknown"
            except Exception:
                self.allModels = ["unknown"]
                defaultModel = "unknown"

        if getattr(self, "model", "") in self.allModels and self.model != "Loading...":
            pass
        else:
            self.model = defaultModel

        save_settings(self.provider, self.model)
        
        self.call_from_thread(self.post_initialize_llm)

    def post_initialize_llm(self) -> None:
        self.query_one("#input_row").border_title = f"{self.model}"
        self.query_one("#commitBtn").disabled = False
        self.regenerate()

    def on_button_pressed(self, event: Button.Pressed) -> None:
        if event.button.id == "commitBtn":
            if str(event.button.label).strip() == "Sync  ➤":
                event.button.label = "Syncing..."
                event.button.disabled = True
                subprocess.run(["git", "push"], capture_output=True)
                self.exit(f"{colorama.Fore.GREEN}Comet committed and synced successfully! {colorama.Style.RESET_ALL}")
                return

            textArea = self.query_one("#input", TextArea)
            finalMessage = textArea.text.strip()
            
            subprocess.run(["git", "commit", "-a", "-m", finalMessage], capture_output=True)
            event.button.label = "Sync  ➤"
            
        elif event.button.id == "cancelBtn":
            self.exit(f"{colorama.Fore.RED}User cancelled the operation. {colorama.Style.RESET_ALL}")
            
        elif event.button.id == "regenBtn":
            event.button.disabled = True
            textArea = self.query_one("#input", TextArea)
            textArea.text = ""
            self.regenerate()

    @work(thread=True)
    def regenerate(self) -> None:
        if not hasattr(self, "pastResponses"):
            self.pastResponses = set()
            
        systemPath = os.path.join(os.path.dirname(__file__), "system.md")
        systemPrompt = open(systemPath, "r", encoding="utf-8").read()
        systemPrompt += f"\n\nRecent Commits (For Context Only. DO NOT SUMMARIZE THESE. They are just for tone/style reference):\n{self.commits}"
        
        promptContent = f"Diff to summarize:\n```diff\n{self.diff}\n```"
        
        while True:
            messages = [{"role": "system", "content": systemPrompt}]
            messages.append({"role": "user", "content": promptContent})
            
            for pastResponse in self.pastResponses:
                messages.append({"role": "assistant", "content": pastResponse})
                messages.append({"role": "user", "content": "Please provide a DIFFERENT summary. Do not repeat the previous ones."})
                
            if self.provider == "ollama":
                response = ollama_chat(model=self.model, messages=messages, options={"temperature": 0.9}, think=False, keep_alive="60m", stream=True)
                message = ""
                for chunk in response:
                    message += chunk['message']['content']
                    self.call_from_thread(self.update_textarea, message, False)
            elif self.provider == "lmstudio":
                response = self.client.chat.completions.create(model=self.model, messages=messages, temperature=0.9, stream=True)
                message = ""
                for chunk in response:
                    if chunk.choices[0].delta.content is not None:
                        message += chunk.choices[0].delta.content
                        self.call_from_thread(self.update_textarea, message, False)
            
            if message not in self.pastResponses:
                self.pastResponses.add(message)
                self.call_from_thread(self.update_textarea, message, True)
                break

    def update_textarea(self, message: str, finished: bool) -> None:
        textArea = self.query_one("#input", TextArea)
        textArea.text = message
        if finished:
            self.query_one("#regenBtn").disabled = False

if __name__ == "__main__": main()