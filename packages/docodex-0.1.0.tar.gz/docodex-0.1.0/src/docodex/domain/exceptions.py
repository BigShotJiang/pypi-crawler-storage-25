"""Domain-specific exceptions."""

class KBCompilerError(Exception):
    """Base exception for all Docodex errors."""
    pass


class IngestionError(KBCompilerError):
    """Raised when document ingestion fails."""
    pass


class SourceNotFoundError(IngestionError):
    """Raised when source cannot be found."""
    pass


class AuthenticationError(IngestionError):
    """Raised when authentication fails."""
    pass


class NetworkError(IngestionError):
    """Raised when network request fails."""
    pass


class CompilationError(KBCompilerError):
    """Raised when compilation fails."""
    pass


class LLMError(CompilationError):
    """Raised when LLM API call fails."""
    pass


class InvalidDocumentError(CompilationError):
    """Raised when document is invalid."""
    pass


class StorageError(KBCompilerError):
    """Raised when storage operation fails."""
    pass


class FileNotFoundError(StorageError):
    """Raised when file cannot be found."""
    pass


class PermissionError(StorageError):
    """Raised when permission is denied."""
    pass
