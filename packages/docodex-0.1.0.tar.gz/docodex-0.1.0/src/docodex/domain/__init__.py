"""Domain layer - core business entities and logic."""
