"""Immutable value objects."""
