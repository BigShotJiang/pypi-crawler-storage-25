"""Docodex - LLM-powered documentation compilation."""

__version__ = "0.1.0"
