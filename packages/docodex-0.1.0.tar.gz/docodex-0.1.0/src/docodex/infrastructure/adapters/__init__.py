"""Source adapter implementations."""
