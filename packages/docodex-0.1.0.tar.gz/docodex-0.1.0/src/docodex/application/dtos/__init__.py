"""Data transfer objects."""
