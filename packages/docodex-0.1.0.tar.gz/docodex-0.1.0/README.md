# Docodex

**An LLM-powered library that compiles scattered documentation into a unified, queryable knowledge base.**

Inspired by Andrej Karpathy's approach to building personal knowledge bases with LLMs.

## What It Does

```
Raw docs (GitHub, Azure Wiki, local files)
    ↓
Ingest → Extract & Store
    ↓
Compile → LLM generates summaries, concepts, relationships
    ↓
Wiki (markdown files in Git)
    ↓
Visualize → Graphs, timelines, clusters
```

## Philosophy

- **Simple & Transparent**: Human-readable markdown, not opaque databases
- **Git-Native**: Version control for your knowledge
- **LLM as Compiler**: AI extracts and organizes, humans review
- **No Vector DB**: LLM-maintained indexes beat RAG at this scale (100-10K docs)
- **Compounding Intelligence**: Every query enhances the wiki

## Architecture

Clean Architecture with SOLID principles:
- **Domain Layer**: Entities, protocols
- **Application Layer**: Use cases (Ingest, Compile, Visualize)
- **Infrastructure Layer**: Adapters (GitHub, Azure Wiki), LLM providers

## Phase 1 Goals

✅ Ingest from GitHub repos, Azure Wiki, local files  
✅ LLM compilation (summaries, concepts, relationships, timelines)  
✅ Git-based storage (markdown with YAML frontmatter)  
✅ Visualizations (knowledge graph, timeline, clusters)  
✅ Incremental updates (only recompile changed docs)  
✅ View in Obsidian or any markdown viewer  

## Project Structure

```
docodex/
├── .claude/              # Claude Code context and skills
├── docs/                 # Architecture and design docs
├── src/docodex/      # Main library code
├── tests/                # Test suite
└── examples/             # Usage examples
```

## Getting Started

See [QUICK_START.md](docs/QUICK_START.md) for development setup.

## Documentation

- [Architecture Overview](docs/ARCHITECTURE.md)
- [Domain Models](docs/DOMAIN_MODELS.md)
- [Protocols & Interfaces](docs/PROTOCOLS.md)
- [Use Cases](docs/USE_CASES.md)
- [Design Decisions](docs/DESIGN_DECISIONS.md)

## Tech Stack

- Python 3.11+
- Pydantic v2 for models/DTOs
- Anthropic SDK (with adapters for other LLMs)
- Git for storage
- Markdown + YAML frontmatter

## License

MIT

## Author

Rohit

---

**Note**: This project uses AI assistance for development, but all code, commits, and releases are authored solely by the human developer.
