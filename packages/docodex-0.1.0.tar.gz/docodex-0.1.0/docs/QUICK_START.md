# Quick Start Guide

## Prerequisites

- Python 3.11 or higher
- Git
- An LLM API key (Anthropic, OpenAI, or local Ollama)

## Installation

### 1. Clone and Setup

```bash
# The setup script will create the project structure
bash setup.sh
```

This creates:
```
docodex/
├── .claude/              # Claude Code context
├── docs/                 # Architecture docs
├── src/docodex/      # Source code
├── tests/                # Test suite
├── examples/             # Usage examples
└── pyproject.toml        # Project config
```

### 2. Install Dependencies

```bash
cd docodex

# Create virtual environment
python -m venv venv
source venv/bin/activate  # On Windows: venv\Scripts\activate

# Install package in editable mode with dev dependencies
uv uv pip install -e ".[dev]"
```

### 3. Configure LLM Provider

Create `.env` file:

```bash
# For Anthropic
ANTHROPIC_API_KEY=sk-ant-xxx

# OR for OpenAI
OPENAI_API_KEY=sk-xxx

# OR for local Ollama
OLLAMA_BASE_URL=http://localhost:11434
OLLAMA_MODEL=llama3
```

## Development Workflow

### 1. Open in Claude Code

```bash
cd docodex
claude-code .
```

Claude Code will automatically load:
- Context from `.claude/context.md`
- Skills from `.claude/skills/`
- Rules from `.claude/rules.md`

### 2. Implement a Feature

Example: Implement the Document entity

```python
# Ask Claude Code:
"Implement the Document entity based on DOMAIN_MODELS.md"

# Claude Code will:
# 1. Read docs/DOMAIN_MODELS.md
# 2. Create src/docodex/domain/entities/document.py
# 3. Follow SOLID principles and type hints
# 4. Add tests in tests/unit/domain/entities/test_document.py
```

### 3. Run Tests

```bash
# Run all tests
pytest

# Run with coverage
pytest --cov=docodex --cov-report=html

# Run specific test file
pytest tests/unit/domain/entities/test_document.py
```

### 4. Type Checking

```bash
# Run mypy
mypy src/docodex
```

### 5. Linting & Formatting

```bash
# Format code
black src/ tests/
isort src/ tests/

# Lint code
ruff check src/ tests/
```

## Project Structure

```
src/docodex/
├── domain/
│   ├── entities/          # Core business entities
│   │   ├── __init__.py
│   │   ├── document.py
│   │   ├── wiki_page.py
│   │   ├── concept.py
│   │   └── relationship.py
│   ├── value_objects/     # Immutable value types
│   │   ├── __init__.py
│   │   ├── source_info.py
│   │   ├── metadata.py
│   │   └── timestamp.py
│   ├── protocols/         # Interface definitions
│   │   ├── __init__.py
│   │   ├── source_adapter.py
│   │   ├── llm_provider.py
│   │   ├── storage.py
│   │   └── visualizer.py
│   └── exceptions.py      # Domain-specific errors
├── application/
│   ├── use_cases/         # Business logic
│   │   ├── __init__.py
│   │   ├── ingest.py
│   │   ├── compile.py
│   │   ├── visualize.py
│   │   └── lint.py
│   └── dtos/              # Data transfer objects
│       ├── __init__.py
│       ├── ingest_request.py
│       └── compile_request.py
├── infrastructure/
│   ├── adapters/          # External system connectors
│   │   ├── __init__.py
│   │   ├── github_adapter.py
│   │   ├── azure_wiki_adapter.py
│   │   └── local_file_adapter.py
│   ├── providers/         # LLM implementations
│   │   ├── __init__.py
│   │   ├── anthropic_provider.py
│   │   ├── openai_provider.py
│   │   └── ollama_provider.py
│   └── storage/           # Persistence layer
│       ├── __init__.py
│       ├── filesystem_storage.py
│       └── git_storage.py
└── utils/                 # Shared utilities
    ├── __init__.py
    ├── config.py
    └── logger.py
```

## Example Usage (Once Implemented)

```python
from docodex.application.use_cases.ingest import IngestUseCase
from docodex.infrastructure.adapters.github_adapter import GitHubAdapter
from docodex.infrastructure.storage.git_storage import GitStorage
from docodex.domain.value_objects.source_info import SourceInfo, SourceType

# Setup
adapter = GitHubAdapter(token="ghp_xxx")
storage = GitStorage(vault_path="/path/to/vault")

use_case = IngestUseCase(
    adapters=[adapter],
    storage=storage,
    logger=logger
)

# Ingest from GitHub
source = SourceInfo(
    source_type=SourceType.GITHUB,
    url="https://github.com/carmax/search",
    repo="carmax/search",
    path="docs/",
    branch="main"
)

result = await use_case.execute(IngestRequest(source=source))
print(f"Ingested {result.stats.files_ingested} files")
```

## Development Tips

### Working with Claude Code

1. **Always refer to docs**: Claude Code can read all the .md files in docs/
2. **Ask for architecture first**: Before implementing, ask Claude to explain the architecture
3. **Test-driven development**: Ask Claude to write tests first
4. **Follow patterns**: Reference ARCHITECTURE.md and PROTOCOLS.md

### Example Prompts for Claude Code

```
"Implement the Document entity following DOMAIN_MODELS.md. 
Include all fields, validation, and the to_markdown() method. 
Write tests for all methods."

"Create the SourceAdapter protocol based on PROTOCOLS.md. 
Make sure it follows the async pattern."

"Implement GitHubAdapter that implements SourceAdapter protocol. 
Use aiohttp for API calls and handle rate limiting."

"Create the IngestUseCase following USE_CASES.md. 
Include error handling and progress tracking."
```

### Debugging

```bash
# Run with verbose logging
PYTHONPATH=src python -m docodex.cli --verbose

# Run specific test with print statements
pytest tests/unit/domain/entities/test_document.py -s

# Debug with pdb
python -m pdb -m pytest tests/unit/domain/entities/test_document.py
```

## Common Issues

### Import Errors

Make sure you're in the virtual environment:
```bash
source venv/bin/activate
uv uv pip install -e ".[dev]"
```

### Type Checking Errors

Run mypy to see all type errors:
```bash
mypy src/docodex
```

### Test Failures

Run tests with verbose output:
```bash
pytest -vv
```

## Next Steps

1. Read all docs in `docs/` directory
2. Implement domain entities (start with Document)
3. Implement protocols
4. Implement infrastructure (adapters, providers, storage)
5. Implement use cases
6. Write integration tests
7. Test with real GitHub repos

## Resources

- [Clean Architecture](https://blog.cleancoder.com/uncle-bob/2012/08/13/the-clean-architecture.html)
- [Pydantic Documentation](https://docs.pydantic.dev/)
- [Anthropic API Docs](https://docs.anthropic.com/)
- [Obsidian](https://obsidian.md)
