# Domain Models

This document defines the core business entities and value objects that represent the knowledge base domain.

## Core Entities

### 1. Document

Represents a raw source document that has been ingested.

**Attributes**:
```python
@dataclass
class Document:
    id: str                      # Unique identifier (hash of source path)
    source: SourceInfo           # Where it came from
    content: str                 # Raw markdown content
    metadata: Metadata           # Title, author, dates, tags
    created_at: datetime
    updated_at: datetime
    hash: str                    # Content hash for change detection
```

**Invariants**:
- `id` must be unique
- `content` cannot be empty
- `hash` must match actual content hash

**Behaviors**:
- `has_changed(other: Document) -> bool`: Compare hashes
- `to_markdown() -> str`: Export as markdown with frontmatter

### 2. WikiPage

Represents a compiled page in the knowledge base.

**Attributes**:
```python
@dataclass
class WikiPage:
    id: str                      # Unique identifier (path in wiki/)
    title: str                   # Page title
    content: str                 # Compiled markdown content
    page_type: PageType          # Summary, Concept, System, Index
    sources: list[SourceInfo]    # Source documents used
    relationships: list[str]     # Related page IDs ([[backlinks]])
    metadata: Metadata
    created_at: datetime
    updated_at: datetime
```

**Page Types**:
```python
class PageType(Enum):
    SUMMARY = "summary"          # Summary of a single document
    CONCEPT = "concept"          # Extracted concept from multiple docs
    SYSTEM = "system"            # System/architecture overview
    INDEX = "index"              # Index/navigation page
    GRAPH = "graph"              # Relationship visualization
```

**Invariants**:
- `title` cannot be empty
- `sources` must contain at least one source (except for INDEX pages)
- `relationships` must reference valid page IDs

**Behaviors**:
- `add_relationship(page_id: str) -> None`: Add backlink
- `to_markdown() -> str`: Export with YAML frontmatter
- `extract_backlinks() -> list[str]`: Parse [[links]] from content

### 3. Concept

Represents a domain concept extracted from documents.

**Attributes**:
```python
@dataclass
class Concept:
    id: str                      # Unique identifier
    name: str                    # Concept name (e.g., "search ranking")
    description: str             # Brief description
    sources: list[SourceInfo]    # Where it was extracted from
    related_concepts: list[str]  # Related concept IDs
    tags: list[str]              # Categorization tags
    created_at: datetime
    updated_at: datetime
```

**Invariants**:
- `name` must be unique within vault
- `sources` cannot be empty

**Behaviors**:
- `add_source(source: SourceInfo) -> None`
- `relate_to(concept_id: str) -> None`

### 4. Relationship

Represents a connection between two entities (pages, concepts, documents).

**Attributes**:
```python
@dataclass
class Relationship:
    id: str                      # Unique identifier
    from_entity: str             # Source entity ID
    to_entity: str               # Target entity ID
    relationship_type: RelationType
    strength: float              # 0.0 to 1.0 (how strong is connection)
    metadata: dict[str, Any]     # Additional context
```

**Relationship Types**:
```python
class RelationType(Enum):
    REFERENCES = "references"        # Doc A references Doc B
    DERIVED_FROM = "derived_from"    # Page derived from Doc
    RELATED_TO = "related_to"        # Conceptually related
    PART_OF = "part_of"              # Component of system
    DEPENDS_ON = "depends_on"        # Technical dependency
    EVOLVED_FROM = "evolved_from"    # Historical evolution
```

**Invariants**:
- `from_entity` and `to_entity` must be different
- `strength` must be between 0.0 and 1.0

**Behaviors**:
- `reverse() -> Relationship`: Create reverse relationship
- `strengthen(delta: float) -> None`: Increase strength

## Value Objects

### SourceInfo

Immutable representation of where a document came from.

**Attributes**:
```python
@dataclass(frozen=True)
class SourceInfo:
    source_type: SourceType      # GitHub, Azure Wiki, Local
    url: str                     # Full URL or path
    repo: str | None             # Repo name (for GitHub)
    path: str                    # Path within source
    branch: str | None           # Git branch (if applicable)
    commit: str | None           # Git commit hash (if applicable)
```

**Source Types**:
```python
class SourceType(Enum):
    GITHUB = "github"
    AZURE_WIKI = "azure_wiki"
    LOCAL_FILE = "local_file"
    WEB_URL = "web_url"
```

**Behaviors**:
- `to_url() -> str`: Generate clickable URL
- `to_path() -> str`: Generate filesystem path for raw/

### Metadata

Document/page metadata.

**Attributes**:
```python
@dataclass
class Metadata:
    title: str | None
    author: str | None
    created_date: datetime | None
    modified_date: datetime | None
    tags: list[str]
    custom: dict[str, Any]       # Extensible metadata
```

**Behaviors**:
- `to_frontmatter() -> str`: Convert to YAML frontmatter
- `from_frontmatter(yaml_str: str) -> Metadata`: Parse from YAML

### Timestamp

Immutable timestamp value.

**Attributes**:
```python
@dataclass(frozen=True)
class Timestamp:
    value: datetime
    
    @classmethod
    def now(cls) -> Timestamp:
        return cls(value=datetime.now(timezone.utc))
    
    def to_iso(self) -> str:
        return self.value.isoformat()
```

## Aggregates

### CompilationResult

Result of a compilation operation.

**Attributes**:
```python
@dataclass
class CompilationResult:
    status: CompilationStatus
    wiki_pages: list[WikiPage]
    relationships: list[Relationship]
    concepts: list[Concept]
    errors: list[CompilationError]
    duration_seconds: float
    stats: CompilationStats
```

**Compilation Status**:
```python
class CompilationStatus(Enum):
    SUCCESS = "success"
    PARTIAL = "partial"          # Some docs failed
    FAILED = "failed"
```

**Compilation Stats**:
```python
@dataclass
class CompilationStats:
    docs_processed: int
    pages_created: int
    pages_updated: int
    concepts_extracted: int
    relationships_created: int
    llm_calls_made: int
    tokens_used: int
```

### IngestionResult

Result of an ingestion operation.

**Attributes**:
```python
@dataclass
class IngestionResult:
    status: IngestionStatus
    documents: list[Document]
    errors: list[IngestionError]
    duration_seconds: float
    stats: IngestionStats
```

**Ingestion Stats**:
```python
@dataclass
class IngestionStats:
    files_found: int
    files_ingested: int
    files_skipped: int
    total_size_bytes: int
```

## Domain Events (Future)

Events that represent state changes in the domain.

```python
@dataclass
class DocumentIngested:
    document_id: str
    timestamp: Timestamp
    
@dataclass
class WikiPageCompiled:
    page_id: str
    timestamp: Timestamp
    source_docs: list[str]
    
@dataclass
class ConceptExtracted:
    concept_id: str
    timestamp: Timestamp
    sources: list[str]
```

## Entity Relationships

```
Document (1) ----derives----> (N) WikiPage
                |
                |
                v
           (N) Concept (N)
                |
                |
                v
         (N) Relationship (N)
```

## Validation Rules

### Document Validation
- Content must not exceed 10MB
- Must be valid UTF-8
- Hash must be SHA-256
- Source info must be complete

### WikiPage Validation
- Title must be 1-200 characters
- Page type must be valid enum value
- Backlinks must reference existing pages
- YAML frontmatter must be valid

### Concept Validation
- Name must be 1-100 characters
- Name must be unique in vault
- Must have at least one source

### Relationship Validation
- Both entities must exist
- Circular dependencies allowed (for REFERENCES)
- Strength must be 0.0-1.0

## Example Entity Creation

### Creating a Document

```python
from docodex.domain.entities import Document
from docodex.domain.value_objects import SourceInfo, Metadata, Timestamp

doc = Document(
    id="github-carmax-search-readme",
    source=SourceInfo(
        source_type=SourceType.GITHUB,
        url="https://github.com/carmax/search",
        repo="carmax/search",
        path="README.md",
        branch="main",
        commit="abc123"
    ),
    content="# Search Service\n\nOverview of search...",
    metadata=Metadata(
        title="Search Service README",
        author="team-search",
        created_date=datetime(2024, 1, 1),
        modified_date=datetime(2026, 4, 5),
        tags=["search", "ml", "ranking"],
        custom={}
    ),
    created_at=Timestamp.now().value,
    updated_at=Timestamp.now().value,
    hash="def456..."
)
```

### Creating a WikiPage

```python
from docodex.domain.entities import WikiPage, PageType

page = WikiPage(
    id="concepts/search-ranking",
    title="Search Ranking",
    content="## Overview\n\nSearch ranking determines...",
    page_type=PageType.CONCEPT,
    sources=[doc.source],
    relationships=["concepts/indexing", "systems/search-service"],
    metadata=Metadata(
        title="Search Ranking",
        tags=["search", "ranking", "ml"],
        custom={"difficulty": "intermediate"}
    ),
    created_at=Timestamp.now().value,
    updated_at=Timestamp.now().value
)
```

### Creating a Relationship

```python
from docodex.domain.entities import Relationship, RelationType

rel = Relationship(
    id="rel-search-ranking-to-indexing",
    from_entity="concepts/search-ranking",
    to_entity="concepts/indexing",
    relationship_type=RelationType.DEPENDS_ON,
    strength=0.8,
    metadata={"reason": "Ranking requires indexed documents"}
)
```

## Design Considerations

### Why Dataclasses?

- Immutability where needed (`frozen=True`)
- Type safety with type hints
- Auto-generated `__init__`, `__repr__`, `__eq__`
- Works well with Pydantic for validation

### Why Separate Value Objects?

- SourceInfo, Metadata, Timestamp are reused across entities
- Immutability prevents accidental modification
- Easier to test and reason about

### Why Explicit IDs?

- Predictable, reproducible IDs (hash-based)
- Easy to reference across entities
- No database auto-increment needed

### Why Enums for Types?

- Type safety (can't pass invalid type)
- Easy to extend with new types
- Self-documenting code
