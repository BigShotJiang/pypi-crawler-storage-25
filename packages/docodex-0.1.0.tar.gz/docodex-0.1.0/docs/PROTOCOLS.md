# Protocols & Interfaces

This document defines the protocol interfaces that enable clean separation between domain logic and infrastructure implementations.

## Why Protocols?

Protocols (PEP 544) enable structural subtyping in Python:
- Infrastructure can implement protocols without inheriting from base classes
- Easy to mock for testing
- Clear contracts between layers
- Type-safe dependency injection

## Core Protocols

### 1. SourceAdapter

**Purpose**: Abstract how documents are fetched from different sources.

```python
from typing import Protocol
from docodex.domain.entities import Document
from docodex.domain.value_objects import SourceInfo

class SourceAdapter(Protocol):
    """Protocol for fetching documents from external sources."""
    
    async def can_handle(self, source: SourceInfo) -> bool:
        """Check if this adapter can handle the given source.
        
        Args:
            source: Source information
            
        Returns:
            True if this adapter can fetch from this source
        """
        ...
    
    async def ingest(self, source: SourceInfo) -> list[Document]:
        """Fetch all documents from the source.
        
        Args:
            source: Source to fetch from
            
        Returns:
            List of ingested documents
            
        Raises:
            IngestionError: If fetching fails
        """
        ...
    
    async def get_changes_since(
        self, 
        source: SourceInfo, 
        since: datetime
    ) -> list[Document]:
        """Fetch only documents changed since a timestamp.
        
        Args:
            source: Source to check
            since: Only return docs modified after this time
            
        Returns:
            List of changed documents
        """
        ...
```

**Implementations**:
- `GitHubAdapter`: Fetch from GitHub repos via API
- `AzureWikiAdapter`: Fetch from Azure DevOps Wiki
- `LocalFileAdapter`: Read from local filesystem
- `WebAdapter`: Fetch from web URLs

**Example Usage**:
```python
adapter = GitHubAdapter(token="ghp_xxx")
source = SourceInfo(
    source_type=SourceType.GITHUB,
    url="https://github.com/carmax/search",
    repo="carmax/search",
    path="docs/",
    branch="main"
)

if await adapter.can_handle(source):
    documents = await adapter.ingest(source)
```

### 2. LLMProvider

**Purpose**: Abstract LLM API calls for summarization, extraction, and compilation.

```python
from typing import Protocol
from docodex.domain.entities import Document, WikiPage, Concept, Relationship

class LLMProvider(Protocol):
    """Protocol for LLM operations."""
    
    async def summarize(self, document: Document, max_words: int = 200) -> str:
        """Generate a summary of the document.
        
        Args:
            document: Document to summarize
            max_words: Maximum words in summary
            
        Returns:
            Summary text
        """
        ...
    
    async def extract_concepts(
        self, 
        documents: list[Document]
    ) -> list[Concept]:
        """Extract key concepts from multiple documents.
        
        Args:
            documents: Documents to analyze
            
        Returns:
            Extracted concepts
        """
        ...
    
    async def generate_wiki_page(
        self,
        concept: Concept,
        related_docs: list[Document]
    ) -> WikiPage:
        """Generate a wiki page for a concept.
        
        Args:
            concept: Concept to write about
            related_docs: Supporting documents
            
        Returns:
            Compiled wiki page
        """
        ...
    
    async def build_index(
        self,
        pages: list[WikiPage]
    ) -> WikiPage:
        """Build master index page from all pages.
        
        Args:
            pages: All wiki pages
            
        Returns:
            Index page with categorization
        """
        ...
    
    async def find_relationships(
        self,
        pages: list[WikiPage]
    ) -> list[Relationship]:
        """Identify relationships between pages.
        
        Args:
            pages: Pages to analyze
            
        Returns:
            Discovered relationships
        """
        ...
```

**Implementations**:
- `AnthropicProvider`: Claude API
- `OpenAIProvider`: GPT API
- `OllamaProvider`: Local Ollama models
- `AzureOpenAIProvider`: Azure-hosted OpenAI

**Example Usage**:
```python
provider = AnthropicProvider(api_key="sk-ant-xxx")

# Summarize a document
summary = await provider.summarize(document, max_words=150)

# Extract concepts from multiple docs
concepts = await provider.extract_concepts([doc1, doc2, doc3])

# Generate wiki page
page = await provider.generate_wiki_page(concept, related_docs)
```

### 3. Storage

**Purpose**: Abstract persistence layer for documents, wiki pages, and state.

```python
from typing import Protocol
from pathlib import Path

class Storage(Protocol):
    """Protocol for storage operations."""
    
    async def save_document(self, document: Document, path: Path) -> None:
        """Save document to raw/ directory.
        
        Args:
            document: Document to save
            path: Relative path in raw/
        """
        ...
    
    async def read_document(self, path: Path) -> Document:
        """Read document from raw/ directory.
        
        Args:
            path: Relative path in raw/
            
        Returns:
            Loaded document
        """
        ...
    
    async def save_wiki_page(self, page: WikiPage, path: Path) -> None:
        """Save wiki page to wiki/ directory.
        
        Args:
            page: Wiki page to save
            path: Relative path in wiki/
        """
        ...
    
    async def read_wiki_page(self, path: Path) -> WikiPage:
        """Read wiki page from wiki/ directory.
        
        Args:
            path: Relative path in wiki/
            
        Returns:
            Loaded wiki page
        """
        ...
    
    async def list_documents(self, directory: Path) -> list[Path]:
        """List all documents in a directory.
        
        Args:
            directory: Directory to scan
            
        Returns:
            List of document paths
        """
        ...
    
    async def save_state(self, state: dict) -> None:
        """Save compilation state to _state.json.
        
        Args:
            state: State dictionary
        """
        ...
    
    async def read_state(self) -> dict:
        """Read compilation state from _state.json.
        
        Returns:
            State dictionary
        """
        ...
    
    async def commit(self, message: str) -> None:
        """Commit changes to Git (if git storage).
        
        Args:
            message: Commit message
        """
        ...
```

**Implementations**:
- `FilesystemStorage`: Simple file-based storage
- `GitStorage`: Filesystem + Git operations
- `MemoryStorage`: In-memory for testing

**Example Usage**:
```python
storage = GitStorage(vault_path=Path("/path/to/vault"))

# Save document
await storage.save_document(doc, Path("github/carmax/search/README.md"))

# Save wiki page
await storage.save_wiki_page(page, Path("concepts/search-ranking.md"))

# Commit to Git
await storage.commit("Added search ranking concept")
```

### 4. Visualizer

**Purpose**: Generate visual representations of knowledge.

```python
from typing import Protocol

class Visualizer(Protocol):
    """Protocol for generating visualizations."""
    
    async def generate_graph(
        self,
        pages: list[WikiPage],
        relationships: list[Relationship]
    ) -> str:
        """Generate knowledge graph visualization.
        
        Args:
            pages: All wiki pages (nodes)
            relationships: Connections (edges)
            
        Returns:
            HTML content with embedded visualization
        """
        ...
    
    async def generate_timeline(
        self,
        pages: list[WikiPage]
    ) -> str:
        """Generate timeline of concept evolution.
        
        Args:
            pages: Pages to visualize on timeline
            
        Returns:
            HTML content with timeline
        """
        ...
    
    async def generate_clusters(
        self,
        concepts: list[Concept]
    ) -> str:
        """Generate concept clustering visualization.
        
        Args:
            concepts: Concepts to cluster
            
        Returns:
            HTML content with clusters
        """
        ...
```

**Implementations**:
- `D3Visualizer`: D3.js-based graphs
- `CytoscapeVisualizer`: Cytoscape.js graphs
- `ObsidianGraphVisualizer`: Export for Obsidian graph view

## Supporting Protocols

### ConfigProvider

**Purpose**: Abstract configuration loading.

```python
class ConfigProvider(Protocol):
    """Protocol for configuration access."""
    
    def get(self, key: str, default: Any = None) -> Any:
        """Get configuration value.
        
        Args:
            key: Config key (dot-notation: "llm.provider")
            default: Default if not found
            
        Returns:
            Configuration value
        """
        ...
    
    def get_required(self, key: str) -> Any:
        """Get required configuration value.
        
        Args:
            key: Config key
            
        Returns:
            Configuration value
            
        Raises:
            ConfigError: If key not found
        """
        ...
```

### Logger

**Purpose**: Abstract logging.

```python
class Logger(Protocol):
    """Protocol for logging."""
    
    def debug(self, message: str, **kwargs) -> None:
        ...
    
    def info(self, message: str, **kwargs) -> None:
        ...
    
    def warning(self, message: str, **kwargs) -> None:
        ...
    
    def error(self, message: str, **kwargs) -> None:
        ...
```

### ProgressTracker

**Purpose**: Track long-running operations.

```python
class ProgressTracker(Protocol):
    """Protocol for progress tracking."""
    
    def start(self, total_items: int, description: str) -> None:
        """Start tracking progress.
        
        Args:
            total_items: Total number of items to process
            description: What we're doing
        """
        ...
    
    def update(self, items_completed: int) -> None:
        """Update progress.
        
        Args:
            items_completed: Number of items done
        """
        ...
    
    def complete(self) -> None:
        """Mark as complete."""
        ...
```

## Protocol Composition

Protocols can be combined for complex operations:

```python
class CompilationPipeline:
    def __init__(
        self,
        storage: Storage,
        llm: LLMProvider,
        visualizer: Visualizer,
        logger: Logger,
        progress: ProgressTracker
    ):
        self.storage = storage
        self.llm = llm
        self.visualizer = visualizer
        self.logger = logger
        self.progress = progress
```

## Testing with Protocols

Protocols make mocking easy:

```python
class MockLLMProvider:
    """Mock LLM for testing."""
    
    async def summarize(self, document: Document, max_words: int = 200) -> str:
        return f"Summary of {document.metadata.title}"
    
    async def extract_concepts(self, documents: list[Document]) -> list[Concept]:
        return [
            Concept(
                id="test-concept",
                name="Test Concept",
                description="A test concept",
                sources=[doc.source for doc in documents],
                related_concepts=[],
                tags=["test"],
                created_at=datetime.now(),
                updated_at=datetime.now()
            )
        ]

# Use in tests
async def test_compilation():
    mock_llm = MockLLMProvider()
    use_case = CompileUseCase(llm=mock_llm, storage=mock_storage)
    result = await use_case.execute(request)
    assert result.status == CompilationStatus.SUCCESS
```

## Protocol Adapters (Bridge Pattern)

Sometimes we need to adapt external libraries to our protocols:

```python
class AnthropicProviderAdapter:
    """Adapter that wraps Anthropic SDK to match LLMProvider protocol."""
    
    def __init__(self, api_key: str):
        self.client = anthropic.Anthropic(api_key=api_key)
    
    async def summarize(self, document: Document, max_words: int = 200) -> str:
        prompt = f"Summarize in {max_words} words:\n\n{document.content}"
        
        message = await self.client.messages.create(
            model="claude-sonnet-4-20250514",
            max_tokens=1000,
            messages=[{"role": "user", "content": prompt}]
        )
        
        return message.content[0].text
```

## Factory Pattern with Protocols

Create implementations based on configuration:

```python
class LLMProviderFactory:
    @staticmethod
    def create(provider_name: str, config: dict) -> LLMProvider:
        if provider_name == "anthropic":
            return AnthropicProvider(api_key=config["api_key"])
        elif provider_name == "openai":
            return OpenAIProvider(api_key=config["api_key"])
        elif provider_name == "ollama":
            return OllamaProvider(base_url=config["base_url"])
        else:
            raise ValueError(f"Unknown provider: {provider_name}")
```

## Protocol Validation

Use mypy to ensure protocol compliance:

```bash
# In pyproject.toml
[tool.mypy]
python_version = "3.12"
warn_return_any = true
warn_unused_configs = true
disallow_untyped_defs = true
```

This ensures all implementations actually satisfy the protocol.

## Best Practices

1. **Keep protocols small**: Single Responsibility Principle
2. **Use async by default**: All I/O operations should be async
3. **Type hints everywhere**: Enable static type checking
4. **Document protocol contracts**: Clear expectations in docstrings
5. **Version protocols carefully**: Breaking changes affect all implementations
6. **Test with mocks**: Protocol-based design makes testing easy
