# Use Cases

This document defines the high-level business operations (use cases) that orchestrate domain entities and infrastructure to fulfill requirements.

## Use Case Pattern

All use cases follow this structure:

```python
class UseCase:
    async def execute(self, request: RequestDTO) -> ResultDTO:
        """Execute the use case.
        
        Args:
            request: Input data
            
        Returns:
            Result data
            
        Raises:
            UseCaseError: If execution fails
        """
        ...
```

## Core Use Cases

### 1. IngestUseCase

**Purpose**: Fetch documents from external sources and store in raw/.

**Flow**:
```
1. Validate ingest request
2. Select appropriate adapter for source
3. Fetch documents from source
4. Store documents in raw/
5. Update _state.json
6. Return ingestion result
```

**Implementation**:
```python
@dataclass
class IngestRequest:
    source: SourceInfo
    force_refresh: bool = False  # Re-fetch even if unchanged

@dataclass
class IngestResponse:
    status: IngestionStatus
    documents: list[Document]
    errors: list[str]
    stats: IngestionStats

class IngestUseCase:
    def __init__(
        self,
        adapters: list[SourceAdapter],
        storage: Storage,
        logger: Logger
    ):
        self.adapters = adapters
        self.storage = storage
        self.logger = logger
    
    async def execute(self, request: IngestRequest) -> IngestResponse:
        # Find adapter that can handle this source
        adapter = self._find_adapter(request.source)
        
        # Check if already ingested (unless force_refresh)
        if not request.force_refresh:
            state = await self.storage.read_state()
            if self._is_up_to_date(state, request.source):
                self.logger.info(f"Source {request.source.url} is up-to-date")
                return IngestResponse(
                    status=IngestionStatus.SKIPPED,
                    documents=[],
                    errors=[],
                    stats=IngestionStats(files_found=0, files_ingested=0)
                )
        
        # Ingest documents
        try:
            documents = await adapter.ingest(request.source)
            
            # Save to raw/
            for doc in documents:
                path = self._get_raw_path(doc.source)
                await self.storage.save_document(doc, path)
            
            # Update state
            await self._update_state(request.source, documents)
            
            return IngestResponse(
                status=IngestionStatus.SUCCESS,
                documents=documents,
                errors=[],
                stats=IngestionStats(
                    files_found=len(documents),
                    files_ingested=len(documents),
                    files_skipped=0,
                    total_size_bytes=sum(len(d.content) for d in documents)
                )
            )
            
        except Exception as e:
            self.logger.error(f"Ingestion failed: {e}")
            return IngestResponse(
                status=IngestionStatus.FAILED,
                documents=[],
                errors=[str(e)],
                stats=IngestionStats()
            )
```

**Example Usage**:
```python
use_case = IngestUseCase(
    adapters=[GitHubAdapter(), AzureWikiAdapter()],
    storage=GitStorage(vault_path),
    logger=logger
)

request = IngestRequest(
    source=SourceInfo(
        source_type=SourceType.GITHUB,
        url="https://github.com/carmax/search",
        repo="carmax/search",
        path="docs/",
        branch="main"
    )
)

response = await use_case.execute(request)
print(f"Ingested {response.stats.files_ingested} files")
```

### 2. CompileUseCase

**Purpose**: Read raw documents, use LLM to compile into wiki pages.

**Flow** (Hierarchical Compilation):
```
1. Read all documents from raw/
2. Phase 1: Generate summaries
   - For each document, LLM creates summary
   - Save to wiki/summaries/
3. Phase 2: Extract concepts
   - Group related summaries
   - LLM extracts common concepts
   - Save to wiki/concepts/
4. Phase 3: Generate system overviews
   - Group by system/component
   - LLM creates overview pages
   - Save to wiki/systems/
5. Phase 4: Build index & relationships
   - LLM analyzes all pages
   - Creates master index
   - Identifies relationships
   - Save to wiki/_index.md and wiki/_graph.md
6. Update _state.json
7. Commit to Git
8. Return compilation result
```

**Implementation**:
```python
@dataclass
class CompileRequest:
    incremental: bool = True     # Only compile changed docs
    force_full: bool = False     # Force full recompilation

@dataclass
class CompileResponse:
    status: CompilationStatus
    wiki_pages: list[WikiPage]
    concepts: list[Concept]
    relationships: list[Relationship]
    stats: CompilationStats
    errors: list[str]

class CompileUseCase:
    def __init__(
        self,
        storage: Storage,
        llm: LLMProvider,
        logger: Logger,
        progress: ProgressTracker
    ):
        self.storage = storage
        self.llm = llm
        self.logger = logger
        self.progress = progress
    
    async def execute(self, request: CompileRequest) -> CompileResponse:
        # Determine which docs to compile
        if request.force_full or not request.incremental:
            docs_to_compile = await self._get_all_documents()
        else:
            docs_to_compile = await self._get_changed_documents()
        
        if not docs_to_compile:
            self.logger.info("No documents to compile")
            return CompileResponse(
                status=CompilationStatus.SUCCESS,
                wiki_pages=[],
                concepts=[],
                relationships=[],
                stats=CompilationStats(),
                errors=[]
            )
        
        self.progress.start(len(docs_to_compile), "Compiling documents")
        
        try:
            # Phase 1: Summaries
            summaries = await self._generate_summaries(docs_to_compile)
            
            # Phase 2: Concepts
            concepts = await self._extract_concepts(summaries)
            
            # Phase 3: System overviews
            systems = await self._generate_system_pages(concepts, docs_to_compile)
            
            # Phase 4: Index & relationships
            all_pages = summaries + concepts + systems
            index_page = await self.llm.build_index(all_pages)
            relationships = await self.llm.find_relationships(all_pages)
            
            # Save everything
            await self._save_pages(all_pages + [index_page])
            await self._save_relationships(relationships)
            
            # Update state
            await self._update_compilation_state(docs_to_compile, all_pages)
            
            # Commit to Git
            await self.storage.commit(
                f"Compiled {len(docs_to_compile)} documents into {len(all_pages)} pages"
            )
            
            self.progress.complete()
            
            return CompileResponse(
                status=CompilationStatus.SUCCESS,
                wiki_pages=all_pages + [index_page],
                concepts=concepts,
                relationships=relationships,
                stats=CompilationStats(
                    docs_processed=len(docs_to_compile),
                    pages_created=len(all_pages),
                    concepts_extracted=len(concepts),
                    relationships_created=len(relationships)
                ),
                errors=[]
            )
            
        except Exception as e:
            self.logger.error(f"Compilation failed: {e}")
            return CompileResponse(
                status=CompilationStatus.FAILED,
                wiki_pages=[],
                concepts=[],
                relationships=[],
                stats=CompilationStats(),
                errors=[str(e)]
            )
    
    async def _generate_summaries(self, docs: list[Document]) -> list[WikiPage]:
        """Phase 1: Generate summary for each document."""
        summaries = []
        for doc in docs:
            summary_text = await self.llm.summarize(doc)
            page = WikiPage(
                id=f"summaries/{doc.id}",
                title=f"Summary: {doc.metadata.title}",
                content=summary_text,
                page_type=PageType.SUMMARY,
                sources=[doc.source],
                relationships=[],
                metadata=doc.metadata,
                created_at=datetime.now(),
                updated_at=datetime.now()
            )
            summaries.append(page)
            await self.storage.save_wiki_page(page, Path(page.id + ".md"))
            self.progress.update(1)
        return summaries
    
    async def _extract_concepts(self, summaries: list[WikiPage]) -> list[Concept]:
        """Phase 2: Extract concepts from summaries."""
        # Group summaries by topic (simplified - in reality, use tags/clustering)
        grouped = self._group_summaries(summaries)
        
        concepts = []
        for group_name, group_summaries in grouped.items():
            # Convert summaries to documents for LLM
            docs = [self._summary_to_doc(s) for s in group_summaries]
            extracted = await self.llm.extract_concepts(docs)
            concepts.extend(extracted)
        
        return concepts
```

### 3. VisualizeUseCase

**Purpose**: Generate visual representations of compiled knowledge.

**Flow**:
```
1. Read all wiki pages and relationships
2. Generate knowledge graph (HTML)
3. Generate timeline (HTML)
4. Generate clusters (HTML)
5. Save to outputs/
6. Return paths to visualizations
```

**Implementation**:
```python
@dataclass
class VisualizeRequest:
    types: list[str] = field(default_factory=lambda: ["graph", "timeline", "clusters"])

@dataclass
class VisualizeResponse:
    visualizations: dict[str, Path]  # type -> output path
    errors: list[str]

class VisualizeUseCase:
    def __init__(
        self,
        storage: Storage,
        visualizer: Visualizer,
        logger: Logger
    ):
        self.storage = storage
        self.visualizer = visualizer
        self.logger = logger
    
    async def execute(self, request: VisualizeRequest) -> VisualizeResponse:
        # Load all wiki pages
        pages = await self._load_all_pages()
        relationships = await self._load_relationships()
        concepts = await self._load_concepts()
        
        visualizations = {}
        errors = []
        
        # Generate requested visualizations
        if "graph" in request.types:
            try:
                graph_html = await self.visualizer.generate_graph(pages, relationships)
                path = Path("outputs/knowledge-graph.html")
                await self.storage.save_visualization(graph_html, path)
                visualizations["graph"] = path
            except Exception as e:
                errors.append(f"Graph generation failed: {e}")
        
        if "timeline" in request.types:
            try:
                timeline_html = await self.visualizer.generate_timeline(pages)
                path = Path("outputs/timeline.html")
                await self.storage.save_visualization(timeline_html, path)
                visualizations["timeline"] = path
            except Exception as e:
                errors.append(f"Timeline generation failed: {e}")
        
        if "clusters" in request.types:
            try:
                clusters_html = await self.visualizer.generate_clusters(concepts)
                path = Path("outputs/clusters.html")
                await self.storage.save_visualization(clusters_html, path)
                visualizations["clusters"] = path
            except Exception as e:
                errors.append(f"Cluster generation failed: {e}")
        
        return VisualizeResponse(
            visualizations=visualizations,
            errors=errors
        )
```

### 4. LintUseCase

**Purpose**: Check wiki health, find issues, suggest improvements.

**Flow**:
```
1. Read all wiki pages
2. Check for broken backlinks
3. Check for orphaned pages (no incoming links)
4. Check for outdated content (sources have been updated)
5. Check for missing relationships
6. Return lint report
```

**Implementation**:
```python
@dataclass
class LintIssue:
    severity: str  # "error", "warning", "info"
    page_id: str
    issue_type: str
    message: str
    suggestion: str | None

@dataclass
class LintResponse:
    issues: list[LintIssue]
    stats: dict[str, int]  # issue_type -> count

class LintUseCase:
    async def execute(self) -> LintResponse:
        pages = await self._load_all_pages()
        issues = []
        
        # Check broken backlinks
        issues.extend(await self._check_backlinks(pages))
        
        # Check orphaned pages
        issues.extend(await self._check_orphans(pages))
        
        # Check outdated content
        issues.extend(await self._check_outdated(pages))
        
        # Check missing relationships
        issues.extend(await self._check_missing_relationships(pages))
        
        stats = Counter(issue.issue_type for issue in issues)
        
        return LintResponse(issues=issues, stats=dict(stats))
```

### 5. IncrementalCompileUseCase

**Purpose**: Only recompile what changed (smart compilation).

**Flow**:
```
1. Read _state.json
2. For each source, check if changed
   - GitHub: compare commit hash
   - Azure Wiki: compare last_modified
   - Local: compare file hash
3. If changed:
   - Re-ingest changed source
   - Mark dependent wiki pages as stale
   - Recompile only stale pages
4. Update _state.json
```

**Implementation**:
```python
class IncrementalCompileUseCase:
    async def execute(self) -> CompileResponse:
        state = await self.storage.read_state()
        
        # Check each source for changes
        changed_sources = []
        for source_id, source_state in state["sources"].items():
            if await self._has_changed(source_id, source_state):
                changed_sources.append(source_id)
        
        if not changed_sources:
            self.logger.info("No sources changed, skipping compilation")
            return CompileResponse(status=CompilationStatus.SUCCESS, ...)
        
        # Re-ingest changed sources
        new_docs = []
        for source_id in changed_sources:
            docs = await self._reingest_source(source_id)
            new_docs.extend(docs)
        
        # Find stale pages (pages derived from changed docs)
        stale_pages = await self._find_stale_pages(new_docs)
        
        # Recompile only stale pages
        recompiled = await self._recompile_pages(stale_pages, new_docs)
        
        # Update relationships
        relationships = await self.llm.find_relationships(recompiled)
        
        # Update state
        await self._update_state(changed_sources, recompiled)
        
        return CompileResponse(...)
```

## Use Case Orchestration

Combine multiple use cases:

```python
class KnowledgeBaseOrchestrator:
    """High-level orchestration of multiple use cases."""
    
    def __init__(
        self,
        ingest: IngestUseCase,
        compile: CompileUseCase,
        visualize: VisualizeUseCase,
        lint: LintUseCase
    ):
        self.ingest = ingest
        self.compile = compile
        self.visualize = visualize
        self.lint = lint
    
    async def build_from_scratch(self, sources: list[SourceInfo]) -> None:
        """Ingest + Compile + Visualize in one operation."""
        
        # Ingest all sources
        for source in sources:
            await self.ingest.execute(IngestRequest(source=source))
        
        # Compile everything
        await self.compile.execute(CompileRequest(force_full=True))
        
        # Generate visualizations
        await self.visualize.execute(VisualizeRequest())
        
        # Run health check
        lint_result = await self.lint.execute()
        if lint_result.issues:
            print(f"Found {len(lint_result.issues)} issues")
    
    async def update(self) -> None:
        """Incremental update workflow."""
        
        # Check for changes and recompile
        compile_result = await self.compile.execute(CompileRequest(incremental=True))
        
        if compile_result.stats.pages_created > 0:
            # Regenerate visualizations
            await self.visualize.execute(VisualizeRequest())
```

## Testing Use Cases

```python
async def test_ingest_use_case():
    # Arrange
    mock_adapter = MockGitHubAdapter()
    mock_storage = MockStorage()
    mock_logger = MockLogger()
    
    use_case = IngestUseCase(
        adapters=[mock_adapter],
        storage=mock_storage,
        logger=mock_logger
    )
    
    request = IngestRequest(
        source=SourceInfo(
            source_type=SourceType.GITHUB,
            url="https://github.com/test/repo",
            repo="test/repo",
            path="docs/",
            branch="main"
        )
    )
    
    # Act
    response = await use_case.execute(request)
    
    # Assert
    assert response.status == IngestionStatus.SUCCESS
    assert len(response.documents) > 0
    assert mock_storage.save_document.called
```
