# Architecture Overview

## System Design

The Docodex follows Clean Architecture principles with clear separation between domain logic, application use cases, and infrastructure concerns.

## Layers

### 1. Domain Layer (Core Business Logic)

**Purpose**: Define the business entities and rules. No external dependencies.

**Components**:
- **Entities**: Core business objects (Document, WikiPage, Relationship, Concept)
- **Value Objects**: Immutable types (SourceInfo, Metadata, Timestamp)
- **Protocols**: Interface definitions that infrastructure must implement
- **Exceptions**: Domain-specific errors

**Key Principle**: This layer knows nothing about databases, APIs, or frameworks.

```
domain/
├── entities/
│   ├── document.py          # Raw source document
│   ├── wiki_page.py         # Compiled wiki page
│   ├── relationship.py      # Connection between concepts
│   └── concept.py           # Extracted concept
├── value_objects/
│   ├── source_info.py       # Where doc came from
│   ├── metadata.py          # Doc metadata
│   └── timestamp.py         # When doc was created/updated
├── protocols/
│   ├── source_adapter.py    # How to read from sources
│   ├── llm_provider.py      # How to call LLM
│   ├── storage.py           # How to persist data
│   └── visualizer.py        # How to generate visuals
└── exceptions.py            # Domain errors
```

### 2. Application Layer (Use Cases)

**Purpose**: Orchestrate domain entities to fulfill business requirements. No framework dependencies.

**Components**:
- **Use Cases**: High-level business operations
- **DTOs**: Data transfer objects for use case inputs/outputs
- **Interfaces**: Additional abstractions for application needs

**Key Use Cases**:
1. **IngestUseCase**: Fetch docs from sources → store in raw/
2. **CompileUseCase**: Read raw docs → LLM compilation → store in wiki/
3. **VisualizeUseCase**: Read wiki → generate graphs/timelines
4. **LintUseCase**: Scan wiki → find issues → report
5. **IncrementalCompileUseCase**: Check what changed → recompile only those

```
application/
├── use_cases/
│   ├── ingest.py            # Ingest from sources
│   ├── compile.py           # LLM compilation
│   ├── visualize.py         # Generate visualizations
│   ├── lint.py              # Health checks
│   └── incremental.py       # Smart recompilation
└── dtos/
    ├── ingest_request.py
    ├── compile_request.py
    └── compile_result.py
```

### 3. Infrastructure Layer (External Concerns)

**Purpose**: Implement protocols defined in domain. Handle all external dependencies.

**Components**:
- **Adapters**: Implementations of SourceAdapter protocol
- **Providers**: Implementations of LLMProvider protocol
- **Storage**: Implementations of Storage protocol
- **Visualizers**: Implementations of Visualizer protocol

```
infrastructure/
├── adapters/
│   ├── github_adapter.py       # Fetch from GitHub
│   ├── azure_wiki_adapter.py   # Fetch from Azure Wiki
│   └── local_file_adapter.py   # Read local files
├── providers/
│   ├── anthropic_provider.py   # Anthropic API
│   ├── openai_provider.py      # OpenAI API
│   └── ollama_provider.py      # Local Ollama
├── storage/
│   ├── filesystem_storage.py   # Save to disk
│   └── git_storage.py          # Git operations
└── visualizers/
    ├── graph_visualizer.py     # Knowledge graph
    └── timeline_visualizer.py  # Timeline view
```

## Data Flow

### Ingestion Flow

```
User → IngestUseCase
         ↓
   GitHubAdapter.ingest()
         ↓
   Fetch files from GitHub API
         ↓
   Create Document entities
         ↓
   FilesystemStorage.save(raw/)
         ↓
   Return list[Document]
```

### Compilation Flow (Hierarchical)

```
User → CompileUseCase
         ↓
   FilesystemStorage.read(raw/)
         ↓
   For each Document:
     ↓
   LLMProvider.summarize(doc)
     ↓
   Create WikiPage entity
     ↓
   FilesystemStorage.save(wiki/summaries/)
         ↓
   LLMProvider.extract_concepts(summaries)
     ↓
   Create Concept entities
     ↓
   FilesystemStorage.save(wiki/concepts/)
         ↓
   LLMProvider.build_index(concepts)
     ↓
   Create index WikiPage
     ↓
   FilesystemStorage.save(wiki/_index.md)
```

### Visualization Flow

```
User → VisualizeUseCase
         ↓
   FilesystemStorage.read(wiki/)
         ↓
   Parse all WikiPages + Relationships
         ↓
   GraphVisualizer.generate(pages, relationships)
         ↓
   Create HTML/JSON output
         ↓
   FilesystemStorage.save(outputs/graph.html)
```

## Design Patterns

### 1. Adapter Pattern

**Problem**: Need to support multiple data sources (GitHub, Azure Wiki, local files)

**Solution**: Define `SourceAdapter` protocol, create adapter for each source

```python
class SourceAdapter(Protocol):
    async def ingest(self, source: Source) -> list[Document]:
        """Fetch documents from source"""
        ...
```

**Implementations**:
- `GitHubAdapter`: Uses GitHub API
- `AzureWikiAdapter`: Uses Azure DevOps REST API
- `LocalFileAdapter`: Reads from filesystem

### 2. Strategy Pattern

**Problem**: Need to support multiple LLM providers (Anthropic, OpenAI, Ollama)

**Solution**: Define `LLMProvider` protocol, swap implementations

```python
class LLMProvider(Protocol):
    async def summarize(self, text: str) -> str:
        """Generate summary of text"""
        ...
    
    async def extract_concepts(self, texts: list[str]) -> list[Concept]:
        """Extract concepts from multiple texts"""
        ...
```

### 3. Repository Pattern

**Problem**: Abstract storage details from business logic

**Solution**: Define `Storage` protocol

```python
class Storage(Protocol):
    async def save(self, path: str, content: str) -> None:
        """Save content to path"""
        ...
    
    async def read(self, path: str) -> str:
        """Read content from path"""
        ...
```

### 4. Factory Pattern

**Problem**: Need to create different adapters/providers based on config

**Solution**: Factory classes

```python
class AdapterFactory:
    @staticmethod
    def create(source_type: str) -> SourceAdapter:
        if source_type == "github":
            return GitHubAdapter()
        elif source_type == "azure_wiki":
            return AzureWikiAdapter()
        ...
```

### 5. Chain of Responsibility

**Problem**: Document processing has multiple steps

**Solution**: Pipeline of processors

```python
class ProcessorChain:
    def __init__(self):
        self.processors = [
            ExtractMetadataProcessor(),
            ConvertToMarkdownProcessor(),
            ValidateProcessor(),
        ]
    
    async def process(self, doc: Document) -> Document:
        for processor in self.processors:
            doc = await processor.process(doc)
        return doc
```

## Storage Strategy

### Filesystem Layout

```
vault/                          # Git repository
├── raw/                        # Original ingested docs
│   ├── github/
│   │   └── {org}/{repo}/
│   ├── azure-wiki/
│   │   └── {project}/{space}/
│   └── local/
├── wiki/                       # Compiled knowledge
│   ├── _index.md               # Master index
│   ├── _graph.md               # Relationship map
│   ├── summaries/              # Document summaries
│   ├── concepts/               # Extracted concepts
│   └── systems/                # System overviews
├── outputs/                    # Generated visualizations
│   ├── graph.html
│   └── timeline.html
└── _state.json                 # Compilation state
```

### State Tracking (_state.json)

```json
{
  "last_compile": "2026-04-05T10:30:00Z",
  "sources": {
    "github/carmax/search": {
      "last_fetched": "2026-04-05T10:00:00Z",
      "last_commit": "abc123",
      "files": {
        "README.md": {
          "hash": "def456",
          "compiled": true
        }
      }
    }
  },
  "wiki_pages": {
    "concepts/search-ranking.md": {
      "created": "2026-04-01T12:00:00Z",
      "updated": "2026-04-05T10:30:00Z",
      "sources": ["github/carmax/search/README.md"]
    }
  }
}
```

### Incremental Compilation Strategy

1. Read `_state.json`
2. For each source, check if changed (compare hash/commit)
3. If changed:
   - Fetch new content
   - Mark related wiki pages as stale
   - Recompile affected pages only
4. Update `_state.json`

## LLM Compilation Strategy (Karpathy's Approach)

### Phase 1: Individual Summaries

For each document in `raw/`:
```
Input: raw/github/search/README.md (1000 words)
LLM Prompt: "Summarize this document in 200 words, extract key concepts"
Output: wiki/summaries/search-readme.md
```

### Phase 2: Concept Extraction

For each group of related summaries:
```
Input: All summaries tagged with "search"
LLM Prompt: "Extract common concepts, create concept pages"
Output: wiki/concepts/search-ranking.md, wiki/concepts/indexing.md
```

### Phase 3: System Overview

For each system:
```
Input: All concepts + summaries related to "search service"
LLM Prompt: "Create system overview, include architecture, components"
Output: wiki/systems/search-service.md
```

### Phase 4: Index & Graph

```
Input: All wiki pages
LLM Prompt: "Create master index with categories, build relationship graph"
Output: wiki/_index.md, wiki/_graph.md
```

## Visualization Strategy

### Knowledge Graph

**Nodes**: Concepts, systems, documents  
**Edges**: Relationships (uses, depends-on, related-to)

**Output**: HTML with D3.js or Cytoscape.js

### Timeline

**Events**: Document creation, updates, concept evolution  
**Output**: HTML timeline visualization

### Clusters

**Algorithm**: Group concepts by similarity (based on shared sources/tags)  
**Output**: HTML cluster visualization

## Error Handling

### Exception Hierarchy

```
KBCompilerError (base)
├── IngestionError
│   ├── SourceNotFoundError
│   ├── AuthenticationError
│   └── NetworkError
├── CompilationError
│   ├── LLMError
│   └── InvalidDocumentError
└── StorageError
    ├── FileNotFoundError
    └── PermissionError
```

### Error Recovery

- **Network errors**: Retry with exponential backoff
- **LLM errors**: Fall back to simpler prompts or skip
- **Storage errors**: Fail fast, log clearly

## Performance Considerations

### Async I/O

All network and file operations are async:
```python
async def ingest_all(sources: list[Source]) -> list[Document]:
    tasks = [adapter.ingest(source) for source in sources]
    results = await asyncio.gather(*tasks)
    return [doc for result in results for doc in result]
```

### LLM Rate Limiting

```python
class RateLimitedLLMProvider:
    def __init__(self, provider: LLMProvider, max_rpm: int):
        self.provider = provider
        self.semaphore = asyncio.Semaphore(max_rpm / 60)
    
    async def summarize(self, text: str) -> str:
        async with self.semaphore:
            return await self.provider.summarize(text)
```

### Caching

Cache LLM responses to avoid re-processing:
```python
cache_key = hashlib.sha256(prompt.encode()).hexdigest()
if cached := cache.get(cache_key):
    return cached
result = await llm.call(prompt)
cache.set(cache_key, result)
```

## Testing Strategy

### Unit Tests

Test each layer independently:
- Domain entities: Pure logic tests
- Use cases: Mock protocols
- Infrastructure: Integration tests with real APIs (or mocks)

### Integration Tests

Test full flows:
- Ingest → Compile → Verify output
- Use test fixtures (small repos, sample docs)

### Test Structure

```
tests/
├── unit/
│   ├── domain/
│   ├── application/
│   └── infrastructure/
├── integration/
│   └── test_full_flow.py
└── fixtures/
    └── sample_docs/
```

## Deployment Considerations (Future)

### Phase 2: Add CLI

```bash
docodex init my-vault
docodex ingest github --repo carmax/search
docodex compile
docodex visualize --type graph
```

### Phase 3: Add Web UI

- FastAPI backend serving compiled wiki
- React frontend with graph visualization
- Real-time compilation status

### Phase 4: Enterprise Features

- Multi-user permissions
- SSO integration
- Scheduled compilation jobs
- Webhook listeners for auto-updates

## Key Architectural Decisions

See [DESIGN_DECISIONS.md](DESIGN_DECISIONS.md) for rationale on:
- Why markdown over database
- Why no vector DB
- Why Git-based storage
- Why hierarchical compilation
- Why async-first design
