# Design Decisions

This document records key architectural and design decisions made for the Docodex.

## Format

Each decision follows this structure:
- **Context**: What problem are we solving?
- **Decision**: What did we decide?
- **Rationale**: Why did we choose this?
- **Consequences**: What are the tradeoffs?
- **Alternatives Considered**: What else did we think about?

---

## DD-001: Markdown + Git Over Database

**Context**: We need to store compiled knowledge in a way that's auditable, versionable, and human-readable.

**Decision**: Use markdown files with YAML frontmatter stored in a Git repository.

**Rationale**:
- **Auditability**: Every claim traces back to source documents
- **Human-readable**: Engineers can review and edit compiled output
- **Version control**: See how knowledge evolved over time
- **Collaboration**: Teams can fork, branch, merge knowledge bases
- **No lock-in**: Works with any markdown viewer (Obsidian, VS Code, etc.)
- **Simple**: No database to maintain, backup, or migrate

**Consequences**:
- ✅ Easy to inspect and debug
- ✅ Git provides free versioning and collaboration
- ✅ Platform-independent (just text files)
- ❌ Not optimized for complex queries (but LLM can read files directly)
- ❌ No ACID transactions (but Git provides consistency)

**Alternatives Considered**:
- **SQLite**: More queryable but opaque, harder to version control
- **PostgreSQL**: Too heavyweight for personal/team use
- **Vector DB**: Solves different problem (semantic search vs knowledge compilation)

---

## DD-002: No Vector Database / RAG

**Context**: At 100-10K document scale, how should we enable querying?

**Decision**: Use LLM-maintained markdown indexes instead of vector embeddings.

**Rationale** (from Karpathy):
- **Transparency**: Indexes are human-readable (see what was indexed)
- **Explicit relationships**: `[[backlinks]]` are clear, not implicit similarity
- **Better at this scale**: LLMs can read 100-10K docs directly with good indexes
- **Compounding**: Indexes improve as wiki grows, RAG doesn't compound
- **Auditability**: Can trace every claim to source document
- **No embedding drift**: Embeddings can become stale, indexes stay fresh

**Consequences**:
- ✅ Complete transparency (see what the LLM indexed)
- ✅ Knowledge compounds through structured compilation
- ✅ No embedding model to maintain or update
- ❌ May need to add vector search at very large scale (>10K docs)
- ❌ Requires good index maintenance (linting)

**Alternatives Considered**:
- **ChromaDB**: Standard RAG approach, but opaque and doesn't compound
- **Pinecone**: Cloud vector DB, but adds complexity and cost
- **Hybrid**: Both indexes and vectors (maybe in future if needed)

---

## DD-003: Clean Architecture with Protocols

**Context**: How should we structure code to be maintainable and extensible?

**Decision**: Use Clean Architecture with protocol-based dependency inversion.

**Rationale**:
- **Separation of concerns**: Domain logic separate from infrastructure
- **Testability**: Easy to mock protocols for unit tests
- **Extensibility**: New adapters/providers without changing core
- **Type safety**: Protocols enable static type checking
- **No framework coupling**: Core domain has zero external dependencies

**Consequences**:
- ✅ Easy to add new source adapters (GitHub, Azure Wiki, etc.)
- ✅ Easy to swap LLM providers (Anthropic, OpenAI, Ollama)
- ✅ Domain logic is framework-agnostic
- ❌ More boilerplate (interfaces, adapters)
- ❌ Steeper learning curve for contributors

**Alternatives Considered**:
- **Django/Flask style**: Too monolithic, hard to extend
- **Simple scripts**: Would work for MVP but not maintainable at scale

---

## DD-004: Hierarchical Compilation (Karpathy's Approach)

**Context**: Compiling 1000+ docs exceeds LLM context limits. How to compile efficiently?

**Decision**: Build wiki in layers (summaries → concepts → systems → index).

**Rationale**:
- **Context window**: Each LLM call stays within limits
- **Quality**: Summaries are more accurate than trying to process everything at once
- **Incremental**: Can recompile just one layer if needed
- **Transparent**: Each layer is visible and reviewable

**Consequences**:
- ✅ Scales to thousands of documents
- ✅ Each layer can be independently improved
- ✅ Parallel processing possible (summarize all docs in parallel)
- ❌ More LLM calls = higher cost (but better quality)
- ❌ Multi-phase compilation takes longer

**Alternatives Considered**:
- **Single-pass**: Send all docs to LLM at once (doesn't scale)
- **Map-reduce**: Similar to hierarchical but less structured
- **Pre-chunk documents**: Loses document context

---

## DD-005: Async-First Design

**Context**: Compilation involves many I/O operations (API calls, file reads).

**Decision**: All I/O operations are async using asyncio.

**Rationale**:
- **Performance**: Parallel API calls (summarize 100 docs concurrently)
- **Scalability**: Non-blocking I/O handles many concurrent operations
- **Modern Python**: Async is the future of Python I/O

**Consequences**:
- ✅ Much faster compilation (parallel LLM calls)
- ✅ Better resource utilization
- ❌ More complex code (async/await everywhere)
- ❌ Can't easily mix with sync libraries

**Alternatives Considered**:
- **Sync with threading**: Works but harder to reason about
- **Sync with multiprocessing**: Overkill, harder to share state

---

## DD-006: Pydantic v2 for Models

**Context**: Need runtime validation for DTOs and configuration.

**Decision**: Use Pydantic v2 for all data models and configuration.

**Rationale**:
- **Runtime validation**: Catch errors early
- **Type safety**: Works with mypy for static checking
- **Serialization**: Easy JSON/YAML serialization
- **Documentation**: Auto-generates JSON schemas

**Consequences**:
- ✅ Fewer runtime errors (invalid data caught early)
- ✅ Self-documenting models
- ✅ Easy to extend with validators
- ❌ Additional dependency
- ❌ Slight performance overhead (but negligible)

**Alternatives Considered**:
- **Dataclasses only**: No runtime validation
- **attrs**: Similar but Pydantic is more popular

---

## DD-007: Git Storage as Primary Persistence

**Context**: How should we persist compiled wiki and track changes?

**Decision**: Store everything in Git repository, commit after each compilation.

**Rationale**:
- **Version history**: See how knowledge evolved
- **Collaboration**: Teams can fork/branch/merge
- **Backup**: Git remotes provide automatic backup
- **Diffing**: See exactly what changed in each compilation
- **Rollback**: Bad compilation? Just `git revert`

**Consequences**:
- ✅ Full audit trail
- ✅ Easy collaboration
- ✅ Works with existing workflows (GitHub, GitLab, etc.)
- ❌ Git repo can get large (but Git LFS helps)
- ❌ Requires Git knowledge

**Alternatives Considered**:
- **No versioning**: Just overwrite files (loses history)
- **Custom versioning**: Reinventing Git

---

## DD-008: LLM Provider Adapter Pattern

**Context**: Want to support multiple LLM providers (Anthropic, OpenAI, Ollama).

**Decision**: Define `LLMProvider` protocol, create adapter for each provider.

**Rationale**:
- **Flexibility**: Swap providers based on cost/quality/privacy needs
- **Testing**: Easy to mock for tests
- **Future-proof**: New providers added without changing core

**Consequences**:
- ✅ Not locked into one LLM provider
- ✅ Can use local LLMs (Ollama) for privacy
- ✅ Easy to A/B test different providers
- ❌ Must implement each adapter
- ❌ Provider-specific features not exposed

**Alternatives Considered**:
- **Hard-code Anthropic**: Simpler but inflexible
- **LangChain**: Too heavyweight, adds complexity

---

## DD-009: YAML Frontmatter for Metadata

**Context**: How should we store page metadata (sources, tags, dates)?

**Decision**: Use YAML frontmatter at top of markdown files.

**Rationale**:
- **Standard**: Common pattern (Jekyll, Obsidian, etc.)
- **Human-readable**: Easy to edit manually
- **Parseable**: Libraries exist to parse it
- **Flexible**: Can add custom fields easily

**Consequences**:
- ✅ Compatible with existing markdown tools
- ✅ Easy to extend with new metadata
- ✅ Human-editable
- ❌ Slightly verbose

**Alternatives Considered**:
- **Separate .meta files**: More files to manage
- **JSON frontmatter**: Less readable
- **No metadata**: Loses important context

---

## DD-010: Incremental Compilation with State Tracking

**Context**: Don't want to recompile everything on every run.

**Decision**: Track compilation state in `_state.json`, only recompile what changed.

**Rationale**:
- **Performance**: Only process changed docs
- **Cost**: Fewer LLM API calls
- **Practicality**: Daily incremental updates are realistic

**Consequences**:
- ✅ Much faster compilation after initial build
- ✅ Lower LLM costs
- ✅ Can run on a schedule (nightly)
- ❌ State management adds complexity
- ❌ State can get out of sync (need force_full option)

**Alternatives Considered**:
- **Always full recompile**: Simple but slow and expensive
- **Git-based detection only**: Works but misses non-Git sources

---

## DD-011: Obsidian as Primary Viewer (But Not Required)

**Context**: How should users view the compiled wiki?

**Decision**: Optimize for Obsidian but support any markdown viewer.

**Rationale**:
- **Graph view**: Obsidian's graph visualization is excellent
- **Backlinks**: Native `[[link]]` support
- **Plugins**: Extensible with community plugins
- **Free**: No cost for personal use
- **Optional**: Wiki is just markdown, works anywhere

**Consequences**:
- ✅ Great UX for knowledge exploration
- ✅ No vendor lock-in (wiki is standard markdown)
- ✅ Active plugin ecosystem
- ❌ Teams may need to learn Obsidian
- ❌ Commercial license may be needed

**Alternatives Considered**:
- **Custom web UI**: More work, less features
- **VS Code**: Works but limited graph view
- **Notion**: Not file-based, lock-in

---

## DD-012: Library-First, CLI/UI Later

**Context**: What should we build first?

**Decision**: Build pure library first, add CLI/UI in later phases.

**Rationale**:
- **Focus**: Get core compilation right before adding UX
- **Reusability**: Library can be used by CLI, web UI, MCP server, etc.
- **Testing**: Easier to test pure library
- **Flexibility**: Multiple frontends can use same library

**Consequences**:
- ✅ Clean separation of concerns
- ✅ Multiple delivery options (CLI, web, MCP)
- ✅ Better architecture
- ❌ No user-facing product in Phase 1
- ❌ Harder to demo early

**Alternatives Considered**:
- **CLI-first**: Easier to demo but couples logic to CLI
- **Web UI first**: Most work, hardest to get right initially

---

## Future Decisions (TBD)

These decisions will be made in future phases:

- **DD-013**: CLI framework (Click vs Typer vs argparse)
- **DD-014**: Web UI framework (FastAPI + React vs Flask + HTMX)
- **DD-015**: MCP server implementation strategy
- **DD-016**: Multi-tenancy and permissions model
- **DD-017**: Caching strategy for LLM responses
- **DD-018**: Observability and monitoring
- **DD-019**: Deployment model (Docker, K8s, serverless)
