"""Pytest configuration and fixtures."""
import pytest


@pytest.fixture
def sample_document():
    """Create a sample document for testing."""
    from docodex.domain.entities.document import Document
    from docodex.domain.value_objects.source_info import SourceInfo, SourceType
    from docodex.domain.value_objects.metadata import Metadata
    from datetime import datetime
    
    return Document(
        id="test-doc-1",
        source=SourceInfo(
            source_type=SourceType.LOCAL_FILE,
            url="file:///test.md",
            path="test.md"
        ),
        content="# Test Document\n\nThis is a test.",
        metadata=Metadata(
            title="Test Document",
            tags=["test"]
        ),
        created_at=datetime.now(),
        updated_at=datetime.now(),
        hash="abc123"
    )
