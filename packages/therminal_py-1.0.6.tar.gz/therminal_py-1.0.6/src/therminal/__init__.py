"""Therminal — Python SDK for Kalshi temperature prediction markets + NWS weather data."""

from therminal._version import __version__
from therminal.client import TherminalClient
from therminal.config import TherminalConfig
from therminal.exceptions import (
    AuthenticationError,
    ForbiddenError,
    NotFoundError,
    RateLimitError,
    ServerError,
    TherminalError,
    ValidationError,
)
from therminal.markets import MarketsClient
from therminal.models import (
    Candle,
    Climate,
    Level,
    LOBSnapshot,
    Market,
    Observation,
    Series,
)
from therminal.weather import WeatherClient, WeatherHistory, WeatherLive

__all__ = [
    "__version__",
    # Clients
    "TherminalClient",
    "WeatherHistory",
    "WeatherLive",
    "MarketsClient",
    "WeatherClient",  # backward compat alias for WeatherHistory
    # Config
    "TherminalConfig",
    # Models
    "Observation",
    "Candle",
    "Market",
    "Series",
    "Climate",
    "LOBSnapshot",
    "Level",
    # Exceptions
    "TherminalError",
    "NotFoundError",
    "RateLimitError",
    "ValidationError",
    "ServerError",
    "AuthenticationError",
    "ForbiddenError",
]
