from __future__ import annotations

from dataclasses import dataclass
from typing import Any

from therminal.models._base import DictLikeMixin


@dataclass(frozen=True)
class Candle(DictLikeMixin):
    market_ticker: str
    period_interval: int
    end_period_ts: str
    open: int
    high: int
    low: int
    close: int
    volume: int
    open_interest: int
    filled: bool

    @classmethod
    def from_api_dict(cls, d: dict[str, Any]) -> Candle:
        return cls(
            market_ticker=d.get("market_ticker", ""),
            period_interval=d.get("period_interval", 0),
            end_period_ts=d.get("end_period_ts", ""),
            open=d.get("open", 0),
            high=d.get("high", 0),
            low=d.get("low", 0),
            close=d.get("close", 0),
            volume=d.get("volume", 0),
            open_interest=d.get("open_interest", 0),
            filled=d.get("filled", False),
        )
