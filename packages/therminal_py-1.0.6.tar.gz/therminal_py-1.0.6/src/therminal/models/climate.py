from __future__ import annotations

from dataclasses import dataclass
from typing import Any

from therminal.models._base import DictLikeMixin, _to_float


@dataclass(frozen=True)
class Climate(DictLikeMixin):
    station_code: str
    observation_date: str
    high_temp_f: float | None
    low_temp_f: float | None
    report_type: str
    source: str
    product_id: str | None
    issued_at: str | None

    @classmethod
    def from_api_dict(cls, d: dict[str, Any]) -> Climate:
        return cls(
            station_code=d.get("station_code", ""),
            observation_date=d.get("observation_date", ""),
            high_temp_f=_to_float(d.get("high_temp_f")),
            low_temp_f=_to_float(d.get("low_temp_f")),
            report_type=d.get("report_type", ""),
            source=d.get("source", ""),
            product_id=d.get("product_id"),
            issued_at=d.get("issued_at"),
        )
