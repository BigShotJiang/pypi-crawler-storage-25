from __future__ import annotations

from dataclasses import dataclass
from typing import Any

from therminal.models._base import DictLikeMixin, _to_float


@dataclass(frozen=True)
class Series(DictLikeMixin):
    ticker: str
    measure_type: str
    title: str
    station_code: str | None
    category: str | None
    frequency: str | None
    tags: tuple[str, ...] | None
    active: bool
    last_seen_at: str

    @classmethod
    def from_api_dict(cls, d: dict[str, Any]) -> Series:
        raw_tags = d.get("tags")
        tags = tuple(raw_tags) if raw_tags is not None else None
        return cls(
            ticker=d.get("ticker", ""),
            measure_type=d.get("measure_type", ""),
            title=d.get("title", ""),
            station_code=d.get("station_code"),
            category=d.get("category"),
            frequency=d.get("frequency"),
            tags=tags,
            active=d.get("active", False),
            last_seen_at=d.get("last_seen_at", ""),
        )


@dataclass(frozen=True)
class Market(DictLikeMixin):
    ticker: str
    event_ticker: str
    series_ticker: str
    status: str
    strike_type: str | None
    floor_strike: float | None
    cap_strike: float | None
    result: str
    close_time: str | None

    @classmethod
    def from_api_dict(cls, d: dict[str, Any]) -> Market:
        return cls(
            ticker=d.get("ticker", ""),
            event_ticker=d.get("event_ticker", ""),
            series_ticker=d.get("series_ticker", ""),
            status=d.get("status", ""),
            strike_type=d.get("strike_type"),
            floor_strike=_to_float(d.get("floor_strike")),
            cap_strike=_to_float(d.get("cap_strike")),
            result=d.get("result", ""),
            close_time=d.get("close_time"),
        )
