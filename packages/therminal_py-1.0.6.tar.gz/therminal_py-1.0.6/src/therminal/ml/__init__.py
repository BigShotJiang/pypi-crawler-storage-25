"""therminal.ml — scikit-learn compatible feature engineering for weather prediction.

Usage::

    from therminal.ml import WeatherFeatures
    from sklearn.pipeline import make_pipeline
    from sklearn.ensemble import GradientBoostingRegressor

    pipe = make_pipeline(
        WeatherFeatures(station="ATL", sources=["omo", "metar"]),
        StandardScaler(),
        GradientBoostingRegressor(),
    )
    pipe.fit(dates_train, y_train)

Install: pip install therminal-py[ml]
"""

from therminal.ml.features import WeatherFeatures
from therminal.ml.lob import LOBFeatures

__all__ = ["WeatherFeatures", "LOBFeatures"]

try:
    from therminal.ml.torch import TherminalDataset  # noqa: F401

    __all__.append("TherminalDataset")
except ImportError:
    pass  # torch not installed
