"""Backward compatibility tests — v0.5.0 import patterns still work in v1.0.0."""

from __future__ import annotations


class TestLegacyImports:
    """v0.5.0 import paths must continue to resolve."""

    def test_import_therminal_client(self) -> None:
        from therminal import TherminalClient

        assert TherminalClient is not None

    def test_import_exceptions(self) -> None:
        from therminal import NotFoundError, RateLimitError, TherminalError

        assert TherminalError is not None
        assert NotFoundError is not None
        assert RateLimitError is not None

    def test_version_is_1_0_0(self) -> None:
        from therminal import __version__

        assert __version__.startswith("1.")


class TestTherminalClientMethods:
    """TherminalClient exposes all original v0.5.0 method names."""

    REQUIRED_METHODS = [
        "health",
        "series",
        "series_detail",
        "markets",
        "market",
        "candles",
        "observations",
        "climate",
        "climate_gaps",
        "lob",
    ]

    def test_has_all_original_methods(self) -> None:
        from therminal import TherminalClient

        for method_name in self.REQUIRED_METHODS:
            assert hasattr(TherminalClient, method_name), (
                f"TherminalClient missing method: {method_name}"
            )
            assert callable(getattr(TherminalClient, method_name)), (
                f"TherminalClient.{method_name} is not callable"
            )

    def test_constructor_accepts_v050_kwargs(self) -> None:
        from therminal import TherminalClient

        client = TherminalClient(base_url="https://test.api", timeout=10.0)
        assert client is not None
        client.close()

    def test_context_manager(self) -> None:
        from therminal import TherminalClient

        with TherminalClient(base_url="https://test.api") as client:
            assert client is not None


class TestNewImports:
    """New v1.0.0 import paths work."""

    def test_top_level_new_clients(self) -> None:
        from therminal import (
            MarketsClient,
            TherminalConfig,
            WeatherClient,
            WeatherHistory,
            WeatherLive,
        )

        assert WeatherHistory is not None
        assert WeatherLive is not None
        assert MarketsClient is not None
        assert TherminalConfig is not None
        assert WeatherClient is WeatherHistory  # backward compat alias

    def test_weather_subpackage(self) -> None:
        from therminal.weather import WeatherClient, WeatherHistory, WeatherLive

        assert WeatherHistory is not None
        assert WeatherLive is not None
        assert WeatherClient is WeatherHistory  # backward compat alias

    def test_markets_subpackage(self) -> None:
        from therminal.markets import MarketsClient

        assert MarketsClient is not None

    def test_models_subpackage(self) -> None:
        from therminal.models import Candle, Climate, Market, Observation, Series

        assert Observation is not None
        assert Candle is not None
        assert Market is not None
        assert Series is not None
        assert Climate is not None
