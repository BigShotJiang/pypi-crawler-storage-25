"""Shared test fixtures."""

import pytest

from therminal import TherminalClient


@pytest.fixture
def client():
    """Create a TherminalClient pointing at a test URL."""
    c = TherminalClient(base_url="https://test.api")
    yield c
    c.close()
