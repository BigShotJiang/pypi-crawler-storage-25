"""Tests for TherminalConfig."""

from __future__ import annotations

import pytest

from therminal.config import TherminalConfig

# ── Default Values ──────────────────────────────────────────


def test_default_units():
    cfg = TherminalConfig()
    assert cfg.units == "raw"


def test_default_tz():
    cfg = TherminalConfig()
    assert cfg.tz == "UTC"


def test_default_station():
    cfg = TherminalConfig()
    assert cfg.station is None


# ── Constructor Kwargs Override ─────────────────────────────


def test_kwargs_override_units():
    cfg = TherminalConfig(units="metric")
    assert cfg.units == "metric"


def test_kwargs_override_tz():
    cfg = TherminalConfig(tz="America/New_York")
    assert cfg.tz == "America/New_York"


def test_kwargs_override_station():
    cfg = TherminalConfig(station="ATL")
    assert cfg.station == "ATL"


# ── TOML File Loading ──────────────────────────────────────


def test_toml_loads_values(tmp_path):
    toml_file = tmp_path / "config.toml"
    toml_file.write_text(
        '[defaults]\nunits = "metric"\ntz = "US/Eastern"\nstation = "NYC"\n'
    )
    cfg = TherminalConfig(path=toml_file)
    assert cfg.units == "metric"
    assert cfg.tz == "US/Eastern"
    assert cfg.station == "NYC"


def test_missing_toml_uses_defaults(tmp_path):
    missing = tmp_path / "nonexistent.toml"
    cfg = TherminalConfig(path=missing)
    assert cfg.units == "raw"
    assert cfg.tz == "UTC"
    assert cfg.station is None


def test_invalid_toml_raises_value_error(tmp_path):
    bad_file = tmp_path / "bad.toml"
    bad_file.write_text("this is not [valid toml <<<")
    with pytest.raises(ValueError, match="Invalid TOML config"):
        TherminalConfig(path=bad_file)


# ── Environment Variable Overrides ─────────────────────────


def test_env_units_override(monkeypatch):
    monkeypatch.setenv("THERMINAL_UNITS", "imperial")
    cfg = TherminalConfig()
    assert cfg.units == "imperial"


def test_env_tz_override(monkeypatch):
    monkeypatch.setenv("THERMINAL_TZ", "America/Chicago")
    cfg = TherminalConfig()
    assert cfg.tz == "America/Chicago"


def test_env_station_override(monkeypatch):
    monkeypatch.setenv("THERMINAL_STATION", "MDW")
    cfg = TherminalConfig()
    assert cfg.station == "MDW"


# ── Layered Precedence: file < env < kwargs ────────────────


def test_layered_precedence(tmp_path, monkeypatch):
    toml_file = tmp_path / "config.toml"
    toml_file.write_text('[defaults]\nunits = "metric"\n')

    monkeypatch.setenv("THERMINAL_UNITS", "imperial")

    cfg = TherminalConfig(path=toml_file, units="raw")
    assert cfg.units == "raw"


def test_env_overrides_toml(tmp_path, monkeypatch):
    toml_file = tmp_path / "config.toml"
    toml_file.write_text('[defaults]\nunits = "metric"\n')

    monkeypatch.setenv("THERMINAL_UNITS", "imperial")

    cfg = TherminalConfig(path=toml_file)
    assert cfg.units == "imperial"


# ── resolve() Method ───────────────────────────────────────


def test_resolve_with_override():
    cfg = TherminalConfig()
    result = cfg.resolve(units="metric")
    assert result == {"units": "metric", "tz": "UTC", "station": None}


def test_resolve_defaults():
    cfg = TherminalConfig()
    result = cfg.resolve()
    assert result == {"units": "raw", "tz": "UTC", "station": None}


def test_resolve_station_override():
    cfg = TherminalConfig(station="NYC")
    result = cfg.resolve(station="ATL")
    assert result["station"] == "ATL"


def test_resolve_falls_back_to_config():
    cfg = TherminalConfig(station="NYC", units="metric")
    result = cfg.resolve()
    assert result["station"] == "NYC"
    assert result["units"] == "metric"
