"""Long-lived WSS client to broker.haon.run/v1/byoc/connect.

Lifecycle:

  - `connect_forever(state)` opens the WSS with Bearer permanent_token,
    runs the dispatch loop until cancelled, and reconnects on drops
    with exponential backoff (2/4/8/16/30s cap per Caio's Q-6).
  - Inbound `{msg:"ping"}` → reply with `{msg:"pong", ts}`.
  - Inbound `{msg:"workflow", id, envelope}` → routes to
    `byoc.dispatch.handle_workflow_frame` (Sprint 1B). Progress + done
    frames flow OUT via the same WSS.
  - Backoff resets to 2s on successful PONG after reconnect (Caio's
    Q-6 add-on).
"""

from __future__ import annotations

import asyncio
import json
import random
import time
from typing import Any

import structlog
import websockets
# `websockets.connect` (top-level) in websockets 13.x routes to the
# LEGACY asyncio client, which still expects `extra_headers` (not the
# 12+ kwarg `additional_headers`). The legacy interface is deprecated
# in v14 and will be removed in v15. The new asyncio client lives at
# `websockets.asyncio.client.connect` and accepts `additional_headers`
# — matches the symmetric interface the broker uses
# (`websockets.asyncio.server.serve`). Importing it explicitly avoids
# the silent TypeError trap at runtime (caught smoke 2026-05-18 on
# Windows / Python 3.13 / websockets 13.1).
from websockets.asyncio.client import connect as ws_connect

from haon_agent import __version__ as _agent_version
from haon_agent.byoc import capabilities as _byoc_capabilities
from haon_agent.byoc import dispatch, identity


log = structlog.get_logger("agent.byoc.transport")


_BACKOFF_LADDER_S = [2, 4, 8, 16, 30]
_HEARTBEAT_TIMEOUT_S = 70   # broker pings every 20s; ~3 missed = 60s+


class Transport:
    """One-instance-per-process WSS client. State machine:

        IDLE → CONNECTING → CONNECTED ─┐
                                       ├─> reconnect with backoff
        CLOSED (cancelled) ←──────────-┘
    """

    def __init__(
        self,
        *,
        broker_ws_url: str,
        permanent_token: str,
    ) -> None:
        self.broker_ws_url = broker_ws_url
        self.permanent_token = permanent_token
        self._stop = asyncio.Event()
        # Backoff state — reset to 0 (ladder index) on successful PONG.
        self._backoff_idx = 0
        # Sprint 1F.4 phase 4 — active Studio BrowserSessions keyed by
        # session_id. Audit emission goes through THIS transport's main
        # WSS (`_send`); when the main WSS drops + reconnects, the
        # audit channel is gone for any sessions still running, so on
        # reconnect we close them all (cleanest semantics for the user
        # — coworker viewer reconnects fresh from haonhub).
        self._sessions: dict[str, Any] = {}
        # Sprint 1F.4 phase 5 — slot capacity per runtime kind.
        # Populated from capabilities.detect_slots() at hello-send
        # time. Re-detected on each WSS reconnect in case the
        # operator restarted with new HAON_BYOC_SLOTS env.
        self._slot_capacity: dict[str, int] = {}

    def request_stop(self) -> None:
        """Signal the connect_forever loop to exit cleanly. Idempotent."""
        self._stop.set()

    async def connect_forever(self) -> None:
        """Outer loop — reconnects until `request_stop` fires.

        Each iteration: open WSS → run dispatch loop until close →
        sleep backoff → retry. Backoff resets to the start of the
        ladder on first successful PONG inside a session.
        """
        while not self._stop.is_set():
            try:
                await self._run_one_session()
                # Normal session close (no exception) — also backoff.
            except asyncio.CancelledError:
                # On cancel, close all live BrowserSessions before exit
                await self._close_all_sessions()
                return
            except Exception as exc:  # noqa: BLE001
                log.warning(
                    "byoc_transport_session_failed",
                    error_type=type(exc).__name__,
                    error=str(exc) or repr(exc),
                )
            # Main WSS dropped — close every live BrowserSession before
            # backoff retry. Audit channel went down with the WSS;
            # keeping sessions running would leak audit events into
            # the void and confuse haonhub state. Coworker viewer will
            # reconnect from haonhub side after a fresh session start.
            await self._close_all_sessions()
            if self._stop.is_set():
                return
            await self._sleep_backoff()

    async def _sleep_backoff(self) -> None:
        """Wait per the current backoff position + a small jitter so
        a fleet of agents doesn't thundering-herd the broker."""
        delay = _BACKOFF_LADDER_S[
            min(self._backoff_idx, len(_BACKOFF_LADDER_S) - 1)
        ]
        jitter = random.uniform(0, delay * 0.1)
        log.info("byoc_transport_reconnect_pending", delay_s=delay + jitter)
        try:
            await asyncio.wait_for(
                self._stop.wait(), timeout=delay + jitter
            )
        except asyncio.TimeoutError:
            pass
        if self._backoff_idx < len(_BACKOFF_LADDER_S) - 1:
            self._backoff_idx += 1

    def _reset_backoff(self) -> None:
        self._backoff_idx = 0

    async def _run_one_session(self) -> None:
        """Open the WSS, run inbound dispatch + ping handling, return
        when the connection closes (any reason)."""
        headers = {"Authorization": f"Bearer {self.permanent_token}"}

        log.info("byoc_transport_connecting", url=self.broker_ws_url)
        # Subprotocol contract: `byoc.haon.run.v1` is the BYOC frame
        # protocol (workflow / progress / done / error / ping / pong).
        # Broker's serve(subprotocols=...) requires a match — without
        # this the upgrade fails 400 "missing subprotocol" before the
        # path router runs (caught r6.1 smoke 2026-05-17). Future wire
        # bumps cut a new agent release with `byoc.haon.run/v2` etc.
        async with ws_connect(
            self.broker_ws_url,
            additional_headers=headers,
            subprotocols=["byoc.haon.run.v1"],
            open_timeout=15,
            close_timeout=5,
        ) as ws:
            log.info("byoc_transport_connected", subprotocol=ws.subprotocol)
            await self._read_loop(ws)

    async def _read_loop(self, ws: Any) -> None:
        """Per-message dispatch. Caller's `async with websockets.connect`
        handles close on exit."""
        async for raw in ws:
            if isinstance(raw, bytes):
                try:
                    raw = raw.decode("utf-8")
                except UnicodeDecodeError:
                    log.warning("byoc_transport_frame_not_utf8")
                    continue
            try:
                frame = json.loads(raw)
            except json.JSONDecodeError:
                log.warning("byoc_transport_frame_not_json")
                continue
            if not isinstance(frame, dict):
                continue
            msg = frame.get("msg")
            if msg == "ping":
                await self._send(ws, {"msg": "pong", "ts": int(time.time())})
                # Server liveness confirmed → backoff back to start
                self._reset_backoff()
                continue
            if msg == "ready":
                log.info(
                    "byoc_transport_ready",
                    agent_id=frame.get("agent_id"),
                    capabilities=frame.get("capabilities"),
                )
                self._reset_backoff()
                # Sprint 1F.1 — declare local runtime_kinds + agent
                # version. Detection runs once per connect (capabilities
                # don't change mid-session; restart agent if you install
                # Chrome). Broker tolerates absence (pre-1F.1 fallback).
                try:
                    kinds = _byoc_capabilities.detect_runtime_kinds()
                except Exception:  # noqa: BLE001 — detect must never break connect
                    log.exception("byoc_transport_detect_failed")
                    kinds = ["ollama"]  # safest fallback
                try:
                    slots = _byoc_capabilities.detect_slots()
                except Exception:  # noqa: BLE001
                    log.exception("byoc_transport_slot_detect_failed")
                    slots = {}
                # Cache slots for the session_offer capacity check below
                self._slot_capacity = slots

                # Hotfix 0.5.1: expanded capability probe (Ollama version
                # + models + GPU info + runtimes_active). Bundled into
                # the existing hello frame as new fields — broker's
                # sanitise_hello_payload accepts unknown fields and
                # persists the whole dict at caps:<agent_id>.
                try:
                    full_caps = _byoc_capabilities.detect_full_capabilities()
                    ollama_info = full_caps.get("ollama") or {}
                    gpu_info = full_caps.get("gpu") or {}
                    runtimes_active = full_caps.get("runtimes_active") or []
                except Exception:  # noqa: BLE001
                    log.exception("byoc_transport_full_caps_detect_failed")
                    ollama_info = {}
                    gpu_info = {}
                    runtimes_active = []

                await self._send(ws, {
                    "msg": "hello",
                    "v": 1,
                    "runtime_kinds": kinds,
                    "agent_version": _agent_version,
                    "slots": slots,
                    # New fields (hotfix 0.5.1):
                    "ollama": ollama_info,
                    "gpu": gpu_info,
                    "runtimes_active": runtimes_active,
                })
                log.info(
                    "byoc_transport_hello_sent",
                    runtime_kinds=kinds,
                    agent_version=_agent_version,
                    slots=slots,
                    ollama_daemon=ollama_info.get("daemon_running") if isinstance(ollama_info, dict) else None,
                    ollama_models_count=len(ollama_info.get("models", [])) if isinstance(ollama_info, dict) else 0,
                    gpu_detected=gpu_info.get("detected") if isinstance(gpu_info, dict) else False,
                )
                continue
            if msg == "workflow":
                # Round 5/6 wiring — broker delivers a workflow envelope
                # which we route to the Sprint 1B byoc dispatcher.
                #
                # Hotfix 0.5.1.1: workflow now runs as a BACKGROUND task
                # instead of awaited inline. Why: handle_workflow_frame
                # blocks for the entire duration of the workflow
                # (ollama.generate on a 14b model from cold-start =
                # 60-90s). While blocked, the read_loop can't consume
                # incoming frames → broker's ping never gets a pong →
                # broker marks the agent offline → the next dispatch
                # from haonhub returns AGENT_OFFLINE even though the
                # current workflow IS running fine.
                wf_id = frame.get("id")
                envelope = frame.get("envelope")
                if not isinstance(envelope, dict):
                    log.warning(
                        "byoc_transport_workflow_missing_envelope",
                        wf_id=wf_id,
                    )
                    continue

                # send_back binds wf_id via default arg so each task
                # carries its own id (defensive against closure capture
                # bugs if multiple concurrent workflows ever overlap).
                async def send_back(
                    out_frame: dict[str, Any],
                    _wf_id: str | None = wf_id,
                ) -> None:
                    if _wf_id and "id" not in out_frame:
                        out_frame = {**out_frame, "id": _wf_id}
                    await self._send(ws, out_frame)

                async def _run_workflow_bg(
                    _envelope: dict[str, Any] = envelope,
                    _send: Any = send_back,
                    _wf_id: str | None = wf_id,
                ) -> None:
                    # handle_workflow_frame catches its own exceptions
                    # and emits an error frame via `send`. Outer try
                    # here is defensive — ensures the task never raises
                    # to the asyncio loop (would print "Task exception
                    # was never retrieved" otherwise) and keeps the
                    # event loop quiet.
                    try:
                        await dispatch.handle_workflow_frame(
                            _envelope, send=_send
                        )
                    except Exception:  # noqa: BLE001
                        log.exception(
                            "byoc_transport_workflow_bg_crashed",
                            wf_id=_wf_id,
                        )

                bg = asyncio.create_task(
                    _run_workflow_bg(),
                    name=f"byoc_workflow_{wf_id or 'anon'}",
                )
                # Keep strong reference so GC doesn't reap mid-flight
                # (asyncio docs: "Save a reference to the result of
                # this function, to avoid a task disappearing mid-
                # execution"). Prune done tasks to bound memory.
                if not hasattr(self, "_workflow_tasks"):
                    self._workflow_tasks = []
                self._workflow_tasks = [
                    t for t in self._workflow_tasks if not t.done()
                ] + [bg]
                log.info(
                    "byoc_transport_workflow_spawned_bg",
                    wf_id=wf_id,
                    active_workflows=len(self._workflow_tasks),
                )
                continue
            if msg == "session_offer":
                # Sprint 1F.4 phase 4 — broker pushed a Studio session
                # offer (from a haonhub /v1/byoc/sessions POST). Spawn
                # a BrowserSession that does the full bring-up:
                # Chrome --app + CDP + url_guard + page_guard + monitor
                # + WebRTC peer + signaling WSS handshake.
                #
                # Lazy import — keeps `haon-agent --help` snappy for
                # users without Studio interest (aiortc/av are heavy).
                from haon_agent.byoc.runtime.browser.session import (
                    BrowserSession,
                )

                # Sprint 1F.4 phase 5 — slot capacity enforcement.
                # Broker advertised our slot caps via the hello frame;
                # we count active sessions of the requested runtime
                # kind and reject if at capacity. Defense-in-depth on
                # top of broker's eventual enforcement (future PR).
                requested_kind = frame.get("runtime_kind", "browser")
                kind_cap = self._slot_capacity.get(requested_kind, 1)
                active_count = sum(
                    1 for s in self._sessions.values()
                    if getattr(s, "_offer", {}).get("runtime_kind") == requested_kind
                )
                if active_count >= kind_cap:
                    log.warning(
                        "byoc_transport_session_offer_slots_full",
                        runtime_kind=requested_kind,
                        active=active_count,
                        cap=kind_cap,
                        session_id=frame.get("session_id"),
                    )
                    # Best-effort: tell broker via audit that we
                    # rejected. Coworker viewer will hit signaling
                    # WSS but never get an offer + eventually time
                    # out client-side.
                    sid = frame.get("session_id", "unknown")
                    await self._send(ws, {
                        "msg": "audit_event",
                        "v": 1,
                        "session_id": sid,
                        "event_type": "session_rejected_slots_full",
                        "event_data": {
                            "runtime_kind": requested_kind,
                            "active_count": active_count,
                            "capacity": kind_cap,
                        },
                        "ts": int(time.time()),
                    })
                    continue

                async def main_ws_sender(out_frame: dict[str, Any]) -> None:
                    """Audit emitter sends through this — frames land on
                    the main /v1/byoc/connect WSS, broker forwards
                    audit_event frames to haonhub /audit/broker."""
                    await self._send(ws, out_frame)

                try:
                    session = BrowserSession(frame, main_ws_send=main_ws_sender)
                    await session.start()
                except Exception:  # noqa: BLE001
                    log.exception(
                        "byoc_transport_session_start_failed",
                        session_id=frame.get("session_id"),
                    )
                    # Clean up any partial state — close() is idempotent
                    # and safe even when start() raised mid-bring-up.
                    try:
                        await session.close()
                    except Exception:  # noqa: BLE001
                        pass
                    continue

                # Run session lifetime in a background task — transport
                # read loop must keep flowing so heartbeat + future
                # offers/workflows aren't blocked behind this session.
                # Track via session registry on the Transport instance
                # so connect_forever() can close them all on reconnect.
                self._sessions[session.session_id] = session

                async def _drain_session(sess: BrowserSession) -> None:
                    try:
                        await sess.wait()
                    finally:
                        # Unregister so reconnect cleanup is bounded
                        self._sessions.pop(sess.session_id, None)

                asyncio.create_task(
                    _drain_session(session),
                    name=f"browser-session-{session.session_id}",
                )
                log.info(
                    "byoc_transport_session_offer_handled",
                    session_id=session.session_id,
                )
                continue
            log.info("byoc_transport_unknown_msg", msg=msg)

    async def _send(self, ws: Any, frame: dict[str, Any]) -> None:
        try:
            await ws.send(json.dumps(frame, ensure_ascii=False))
        except websockets.ConnectionClosed:
            pass

    async def _close_all_sessions(self) -> None:
        """Close every live BrowserSession. Called on main WSS drop or
        on transport stop. Idempotent — sessions already closing are
        no-op'd by their own close lock.

        Audit emission for these sessions goes through the (now-dead)
        main WSS; we can't reach haonhub /audit/broker anymore, so any
        emit attempts during close just drop silently. That's
        acceptable — broker liveness > audit completeness, per the
        same rule as the rest of the audit pipeline.
        """
        if not self._sessions:
            return
        sessions = list(self._sessions.values())
        self._sessions.clear()
        log.info("byoc_transport_closing_all_sessions", count=len(sessions))
        # Bound the close fan-out so a stuck session doesn't block
        # reconnect indefinitely. Per-session close is also bounded
        # internally by the various sub-component timeouts.
        await asyncio.gather(
            *(s.close() for s in sessions),
            return_exceptions=True,
        )
