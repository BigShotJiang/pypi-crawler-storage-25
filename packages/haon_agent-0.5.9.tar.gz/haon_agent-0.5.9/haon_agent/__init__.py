"""HAON PowerHub — Miner Agent."""

# Keep in lockstep with pyproject.toml [project].version. Both bumped
# together every release. The .github/workflows/publish-miner.yml
# checks tag matches pyproject; we should also assert this matches
# at import time (tracked as a small follow-up).
__version__ = "0.5.9"
