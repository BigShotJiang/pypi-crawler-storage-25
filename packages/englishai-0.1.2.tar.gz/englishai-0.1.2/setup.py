from setuptools import setup, find_packages

setup(
    name="englishai",
    version="0.1.2",

    description="Rule-based symbolic English parsing and reasoning engine",

    packages=find_packages(),

    python_requires=">=3.8",

    install_requires=[]
)
