from collections import defaultdict

from itemadapter import ItemAdapter
from scrapy import Item
from scrapy.exceptions import DropItem, NotConfigured

from spidermon.contrib.utils.attributes import (
    get_nested_attribute,
    set_nested_attribute,
)
from spidermon.contrib.validation import JSONSchemaValidator
from spidermon.contrib.validation.jsonschema.tools import get_schema_from

from .stats import ValidationStatsManager

DEFAULT_ERRORS_FIELD = "_validation"
DEFAULT_ADD_ERRORS_TO_ITEM = False
DEFAULT_DROP_ITEMS_WITH_ERRORS = False


class PassThroughPipeline:
    def process_item(self, item, *args):
        return item


class ItemValidationPipeline:
    def __init__(
        self,
        validators,
        stats,
        drop_items_with_errors=DEFAULT_DROP_ITEMS_WITH_ERRORS,
        add_errors_to_items=DEFAULT_ADD_ERRORS_TO_ITEM,
        errors_field=None,
    ):
        self.drop_items_with_errors = drop_items_with_errors
        self.add_errors_to_items = add_errors_to_items or DEFAULT_ADD_ERRORS_TO_ITEM
        self.errors_field = errors_field or DEFAULT_ERRORS_FIELD
        self.validators = validators
        self.stats = ValidationStatsManager(stats)
        for _type, vals in validators.items():
            [self.stats.add_validator(_type, val.name) for val in vals]

    @classmethod
    def from_crawler(cls, crawler):
        spidermon_enabled = crawler.settings.getbool("SPIDERMON_ENABLED")
        if not spidermon_enabled:
            return PassThroughPipeline()

        validators = defaultdict(list)
        allowed_types = (list, tuple, dict)

        def set_validators(loader, schema):
            if type(schema) in (list, tuple):
                schema = {Item: schema}
            for obj, paths_value in schema.items():
                key = obj.__name__
                paths = (
                    paths_value if type(paths_value) in (list, tuple) else [paths_value]
                )
                objects = [loader(v) for v in paths]
                validators[key].extend(objects)

        for loader, name in [
            (cls._load_jsonschema_validator, "SPIDERMON_VALIDATION_SCHEMAS"),
        ]:
            res = crawler.settings.get(name)
            if not res:
                continue
            if type(res) not in allowed_types:
                raise NotConfigured(
                    f"Invalid <{type(res)}> type for <{name}> settings, dict or list/tuple"
                    "is required",
                )
            set_validators(loader, res)

        if not validators:
            raise NotConfigured("No validators were found")

        return cls(
            validators=validators,
            stats=crawler.stats,
            drop_items_with_errors=crawler.settings.getbool(
                "SPIDERMON_VALIDATION_DROP_ITEMS_WITH_ERRORS",
            ),
            add_errors_to_items=crawler.settings.getbool(
                "SPIDERMON_VALIDATION_ADD_ERRORS_TO_ITEMS",
            ),
            errors_field=crawler.settings.get("SPIDERMON_VALIDATION_ERRORS_FIELD"),
        )

    @classmethod
    def _load_jsonschema_validator(cls, schema):
        if isinstance(schema, str):
            schema = get_schema_from(schema)
        if not isinstance(schema, dict):
            raise NotConfigured(
                "Invalid schema, jsonschemas must be defined as:\n"
                "- a python dict.\n"
                "- an object path to a python dict.\n"
                "- an object path to a JSON string.\n"
                "- a path to a JSON file.",
            )
        return JSONSchemaValidator(schema)

    def process_item(self, item, spider=None):
        validators = self.find_validators(item)
        if not validators:
            # No validators match this specific item type
            return item

        item_adapter = ItemAdapter(item)
        item_dict = item_adapter.asdict()
        self.stats.add_item()
        self.stats.add_fields(len(item_dict.keys()))
        for validator in validators:
            ok, errors = validator.validate(item_dict)
            if not ok:
                self._add_error_stats(errors)
                if self.add_errors_to_items:
                    self._add_errors_to_item(item_adapter, errors)
                if self.drop_items_with_errors:
                    self._drop_item(item, errors)
        return item

    def find_validators(self, item):
        def find(x):
            return self.validators.get(x.__name__, [])

        return find(item.__class__) or find(Item)

    def _add_errors_to_item(self, item: ItemAdapter, errors: dict[str, str]):
        errors_field_instance = get_nested_attribute(item, self.errors_field)

        if errors_field_instance is None:
            errors_field_instance = defaultdict(list)

        for field_name, messages in errors.items():
            errors_field_instance[field_name] += messages

        # change defaultdict to dict for errors_field_instance
        set_nested_attribute(item, self.errors_field, dict(errors_field_instance))

    def _drop_item(self, item, errors):
        """
        Drop the item after detecting validation errors. Note that you could
        override it to add more details about the item that is being dropped
        or to drop the item only when some specific errors are detected.
        """
        self.stats.add_dropped_item()
        raise DropItem("Validation failed!")

    def _add_error_stats(self, errors):
        """
        Add validation error stats that can be later used to detect alert
        conditions in the monitors.
        """
        for field_name, messages in errors.items():
            for message in messages:
                self.stats.add_field_error(field_name, message)
        self.stats.add_item_with_errors()
