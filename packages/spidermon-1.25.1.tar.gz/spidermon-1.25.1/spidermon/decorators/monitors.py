from typing import Any, ClassVar

from spidermon import settings
from spidermon.core.options import MonitorOptions
from spidermon.decorators import DecoratorWithAttributes, OptionsDecorator


class LevelDecorator(DecoratorWithAttributes):
    name = "level"
    attributes: ClassVar[dict[str, Any]] = {
        "high": OptionsDecorator.set_fixed_value(
            MonitorOptions,
            name,
            settings.MONITOR.LEVEL.HIGH,
        ),
        "normal": OptionsDecorator.set_fixed_value(
            MonitorOptions,
            name,
            settings.MONITOR.LEVEL.NORMAL,
        ),
        "low": OptionsDecorator.set_fixed_value(
            MonitorOptions,
            name,
            settings.MONITOR.LEVEL.LOW,
        ),
    }


name = OptionsDecorator.set_value(MonitorOptions, "name")
description = OptionsDecorator.set_value(MonitorOptions, "description")
order = OptionsDecorator.set_value(MonitorOptions, "order")
level = LevelDecorator()
