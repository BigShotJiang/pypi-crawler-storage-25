from __future__ import annotations

from aictx.report import build_real_usage_report
from aictx.scaffold import init_repo_scaffold
from aictx.state import write_json
from aictx.work_state import start_work_state


def test_real_usage_report_includes_repomap_defaults(tmp_path):
    repo = tmp_path / "repo"
    init_repo_scaffold(repo, update_gitignore=False)

    report = build_real_usage_report(repo)

    assert report["repo_map"] == {
        "enabled": False,
        "available": False,
        "provider_available": False,
        "index_available": False,
        "query_available": False,
        "refresh_available": False,
        "files_indexed": 0,
        "symbols_indexed": 0,
        "last_refresh_status": "never",
    }


def test_real_usage_report_includes_repomap_status_and_counts(tmp_path):
    repo = tmp_path / "repo"
    init_repo_scaffold(repo, update_gitignore=False)
    write_json(repo / ".aictx" / "repo_map" / "config.json", {"enabled": True})
    write_json(repo / ".aictx" / "repo_map" / "status.json", {"available": True, "last_refresh_status": "ok"})
    write_json(repo / ".aictx" / "repo_map" / "manifest.json", {"files_indexed": 12, "symbols_indexed": 44})

    report = build_real_usage_report(repo)

    assert report["repo_map"] == {
        "enabled": True,
        "available": True,
        "provider_available": True,
        "index_available": True,
        "query_available": True,
        "refresh_available": True,
        "files_indexed": 12,
        "symbols_indexed": 44,
        "last_refresh_status": "ok",
    }


def test_real_usage_report_separates_provider_from_queryable_index(tmp_path):
    repo = tmp_path / "repo"
    init_repo_scaffold(repo, update_gitignore=False)
    write_json(repo / ".aictx" / "repo_map" / "config.json", {"enabled": True})
    write_json(repo / ".aictx" / "repo_map" / "status.json", {"available": False, "last_refresh_status": "skipped"})
    write_json(repo / ".aictx" / "repo_map" / "manifest.json", {"files_indexed": 12, "symbols_indexed": 44})

    report = build_real_usage_report(repo)

    assert report["repo_map"]["provider_available"] is False
    assert report["repo_map"]["index_available"] is True
    assert report["repo_map"]["query_available"] is True
    assert report["repo_map"]["refresh_available"] is False
    assert report["repo_map"]["available"] is True


def test_real_usage_report_includes_work_state_defaults(tmp_path):
    repo = tmp_path / "repo"
    init_repo_scaffold(repo, update_gitignore=False)

    report = build_real_usage_report(repo)

    assert report["work_state"] == {
        "active": False,
        "task_id": "",
        "status": "",
        "threads_count": 0,
        "last_updated_at": "",
        "recent_statuses": {},
    }


def test_real_usage_report_includes_active_work_state_snapshot(tmp_path):
    repo = tmp_path / "repo"
    init_repo_scaffold(repo, update_gitignore=False)
    start_work_state(repo, "Fix login token refresh")
    start_work_state(repo, "Validate runtime summary")

    report = build_real_usage_report(repo)

    assert report["work_state"]["active"] is True
    assert report["work_state"]["task_id"] == "validate-runtime-summary"
    assert report["work_state"]["status"] == "in_progress"
    assert report["work_state"]["threads_count"] == 2
    assert report["work_state"]["recent_statuses"] == {"in_progress": 2}
    assert report["work_state"]["last_updated_at"]
from pathlib import Path

from aictx.context_planner import structural_context_status
from aictx.repo_map.config import write_repomap_config
from aictx.scaffold import init_repo_scaffold
from aictx.state import write_json


def test_structural_context_status_exposes_repomap_availability_axes(tmp_path: Path) -> None:
    repo = tmp_path / "repo"
    init_repo_scaffold(repo, update_gitignore=False)
    write_repomap_config(repo, {"enabled": True})
    write_json(repo / ".aictx" / "repo_map" / "status.json", {"available": False, "last_refresh_status": "missing_dependency"})
    write_json(repo / ".aictx" / "repo_map" / "manifest.json", {"files_indexed": 3, "symbols_indexed": 7})

    status = structural_context_status([{"path": "src/app.py"}], repo_root=repo)

    assert status["provider_available"] is False
    assert status["index_available"] is True
    assert status["query_available"] is True
    assert status["refresh_available"] is False
    assert status["last_refresh_status"] == "missing_dependency"
    assert status["files_indexed"] == 3
    assert status["symbols_indexed"] == 7
    assert status["used"] is True
    assert status["entry_point_count"] == 1
