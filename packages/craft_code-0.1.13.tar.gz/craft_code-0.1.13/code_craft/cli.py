"""Interactive CLI for the deep coding agent — the main entry point."""

from __future__ import annotations

import itertools
import sys
import threading
import time
import uuid
from pathlib import Path

from langgraph.types import Command
from rich.console import Console
from rich.markdown import Markdown
from rich.rule import Rule

from .agent import build_agent
from .auth import ensure_api_key, logout, purge_config
from .config import AgentConfig
from .interrupt_handler import collect_decisions

from prompt_toolkit import prompt as pt_prompt
from prompt_toolkit.formatted_text import HTML

console = Console()

# ---------------------------------------------------------------------------
# Thinking spinner — rotating verbs shown while the agent is working
# ---------------------------------------------------------------------------
_THINKING_VERBS = [
    "Thinking", "Reasoning", "Analyzing", "Considering",
    "Planning", "Evaluating", "Processing", "Reflecting",
]

_SPINNER_FRAMES = ["⠋", "⠙", "⠹", "⠸", "⠼", "⠴", "⠦", "⠧", "⠇", "⠏"]


class ThinkingSpinner:
    """A background spinner that cycles through thinking verbs."""

    def __init__(self):
        self._stop_event = threading.Event()
        self._thread: threading.Thread | None = None
        self._current_line_len = 0

    def start(self) -> None:
        if self._thread and self._thread.is_alive():
            return  # Already running
        self._stop_event.clear()
        self._thread = threading.Thread(target=self._run, daemon=True)
        self._thread.start()

    def stop(self) -> None:
        self._stop_event.set()
        if self._thread:
            self._thread.join(timeout=1)
            self._thread = None
        # Clear the spinner line
        if self._current_line_len:
            sys.stderr.write(f"\r{' ' * self._current_line_len}\r")
            sys.stderr.flush()
            self._current_line_len = 0

    def _run(self) -> None:
        verbs = itertools.cycle(_THINKING_VERBS)
        frames = itertools.cycle(_SPINNER_FRAMES)
        current_verb = next(verbs)
        verb_tick = 0
        while not self._stop_event.is_set():
            frame = next(frames)
            line = f"\r  {frame} {current_verb}..."
            self._current_line_len = len(line)
            sys.stderr.write(line)
            sys.stderr.flush()
            verb_tick += 1
            # Change verb every ~2 seconds (20 ticks × 0.1s)
            if verb_tick >= 20:
                current_verb = next(verbs)
                verb_tick = 0
            self._stop_event.wait(0.1)


_spinner = ThinkingSpinner()

# Tools whose results are noisy / internal and should be hidden
_SILENT_RESULT_TOOLS = frozenset({
    "write_todos",
    "write_file",
    "edit_file",
    "delete_file",
    "read_file",
    "task",      # Subagent results are huge; main agent synthesizes in final response
    "glob",      # File lists can be very long
    "ls",        # Directory listings can be very long
})


BANNER = r"""
[bold cyan]╔══════════════════════════════════════════╗
║       Code-Craft Coding Agent v0.1.12    ║
╚══════════════════════════════════════════╝[/bold cyan]

Type your request, or use these commands:
  [green]/help[/green]     — show this help
  [green]/new[/green]      — start a new thread
  [green]/status[/green]   — show session info
  [green]/compact[/green]  — summarize and compact context
  [green]/clear[/green]    — clear terminal
  [green]/logout[/green]   — remove saved API key
  [green]/quit[/green]     — exit

"""


def _trust_check(project_root: Path) -> bool:
    """Show a Claude Code-style trust prompt before granting filesystem access.

    Returns True if the user trusts the folder, False to abort.
    """
    console.print()
    console.print(Rule("[bold yellow]Accessing workspace[/bold yellow]"))
    console.print()
    console.print(f"  [bold]{project_root}[/bold]")
    console.print()
    console.print(
        "  Quick safety check: Is this a project you created or one you trust?\n"
        "  (Like your own code, a well-known open source project, or work from\n"
        "  your team.) If not, take a moment to review what's in this folder first."
    )
    console.print()
    console.print("  [dim]The agent will be able to read, edit, and execute files here.[/dim]")
    console.print()

    options = [
        ("1", "Yes, I trust this folder", True),
        ("2", "No, exit",                 False),
    ]

    for key, label, _ in options:
        console.print(f"  [bold cyan]>[/bold cyan] [bold]{key}.[/bold] {label}")

    console.print()

    while True:
        try:
            choice = console.input("  Enter number to confirm (or Ctrl+C to cancel): ").strip()
        except (EOFError, KeyboardInterrupt):
            console.print()
            return False

        if choice == "1":
            console.print()
            return True
        elif choice == "2":
            console.print()
            return False
        else:
            console.print("  [yellow]Please enter 1 or 2.[/yellow]")


def _short_path(path: str) -> str:
    """Shorten a file path for display."""
    if not path:
        return ""
    return path


def _display_tool_call(tc: dict) -> None:
    """Display a tool call in Claude Code style: Read(path), Bash(cmd), etc."""
    name = tc["name"]
    args = tc.get("args", {})

    if name == "read_file":
        path = _short_path(args.get("file_path", ""))
        console.print(f"\n  [bold]Read[/bold]({path})")
    elif name == "edit_file":
        path = _short_path(args.get("file_path", ""))
        old = args.get("old_string", "")
        new = args.get("new_string", "")
        old_lines = len(old.splitlines()) if old else 0
        new_lines = len(new.splitlines()) if new else 0
        diff = new_lines - old_lines
        if diff > 0:
            summary = f"Added {diff} line{'s' if diff != 1 else ''}"
        elif diff < 0:
            summary = f"Removed {-diff} line{'s' if -diff != 1 else ''}"
        else:
            summary = f"Changed {new_lines} line{'s' if new_lines != 1 else ''}"
        console.print(f"\n  [bold]Update[/bold]({path})")
        console.print(f"    [dim]└ {summary}[/dim]")
    elif name == "write_file":
        path = _short_path(args.get("file_path", ""))
        content = args.get("content", "")
        lines = len(content.splitlines()) if content else 0
        console.print(f"\n  [bold]Write[/bold]({path})")
        if lines:
            console.print(f"    [dim]└ {lines} line{'s' if lines != 1 else ''}[/dim]")
    elif name == "execute":
        cmd = args.get("command", "")
        display_cmd = cmd if len(cmd) <= 80 else cmd[:77] + "..."
        console.print(f"\n  [bold]Bash[/bold]({display_cmd})")
    elif name == "delete_file":
        path = _short_path(args.get("file_path", ""))
        console.print(f"\n  [bold]Delete[/bold]({path})")
    elif name == "git_status":
        console.print(f"\n  [bold]Bash[/bold](git status)")
    elif name == "git_diff":
        path = args.get("path", "")
        console.print(f"\n  [bold]Bash[/bold](git diff {path})")
    elif name == "run_tests":
        cmd = args.get("command", "pytest")
        console.print(f"\n  [bold]Bash[/bold]({cmd})")
    elif name == "task":
        # Subagent delegation — show which subagent and what it's doing
        subagent = args.get("agent", args.get("name", "subagent"))
        task_desc = args.get("description", args.get("input", ""))
        if isinstance(task_desc, str) and len(task_desc) > 100:
            task_desc = task_desc[:97] + "..."
        console.print(f"\n  [bold]Agent[/bold]({subagent})")
        if task_desc:
            console.print(f"    [dim]└ {task_desc}[/dim]")
    elif name == "glob":
        pattern = args.get("pattern", "")
        console.print(f"\n  [bold]Glob[/bold]({pattern})")
    elif name == "grep":
        pattern = args.get("pattern", "")
        console.print(f"\n  [bold]Grep[/bold]({pattern})")
    elif name == "ls":
        path = args.get("path", "/")
        console.print(f"\n  [bold]List[/bold]({path})")
    else:
        console.print(f"\n  [bold]{name}[/bold](...)")


def _display_tool_result(msg) -> None:
    """Display a tool result with truncated output. Suppresses noisy internal tools."""
    name = getattr(msg, "name", "") or ""

    # Skip tools whose output is noisy or already summarised in the tool-call line
    if name in _SILENT_RESULT_TOOLS:
        return

    content = msg.content if isinstance(msg.content, str) else str(msg.content)
    if not content.strip():
        return

    lines = content.strip().split("\n")
    max_lines = 4
    for line in lines[:max_lines]:
        truncated = line[:120] + "..." if len(line) > 120 else line
        console.print(f"    [dim]└ {truncated}[/dim]")
    if len(lines) > max_lines:
        console.print(f"    [dim]  ... +{len(lines) - max_lines} lines[/dim]")


def _display_stream_chunk(chunk: dict) -> None:
    """Display a single stream update chunk — shows thinking, tool calls, and results."""
    if not isinstance(chunk, dict):
        return
    for node_name, output in chunk.items():
        if node_name == "__interrupt__":
            continue
        if not isinstance(output, dict):
            continue
        messages = output.get("messages", [])
        if not isinstance(messages, list):
            continue
        for msg in messages:
            msg_type = getattr(msg, "type", None)
            has_visible_content = False

            # Display AI thinking/reasoning as bullet points
            if msg_type == "ai" and hasattr(msg, "content") and msg.content:
                content = msg.content
                if isinstance(content, str) and content.strip():
                    # Only show thinking if there are also tool calls (intermediate step)
                    if hasattr(msg, "tool_calls") and msg.tool_calls:
                        _spinner.stop()
                        has_visible_content = True
                        for line in content.strip().split("\n"):
                            if line.strip():
                                console.print(f"\n  [bold]●[/bold] {line.strip()}")

            # Display tool calls in Claude Code style
            if hasattr(msg, "tool_calls") and msg.tool_calls:
                if not has_visible_content:
                    _spinner.stop()
                for tc in msg.tool_calls:
                    _display_tool_call(tc)
                # Restart spinner after showing tool call — agent is working
                _spinner.start()

            # Display tool results
            if msg_type == "tool":
                name = getattr(msg, "name", "") or ""
                if name not in _SILENT_RESULT_TOOLS:
                    _spinner.stop()
                _display_tool_result(msg)
                # Restart spinner — more work likely coming
                _spinner.start()


def _has_interrupts(state) -> bool:
    """Check whether a LangGraph state snapshot has pending interrupts."""
    return bool(state.tasks and any(t.interrupts for t in state.tasks))


def _get_interrupt_value(state) -> dict:
    """Extract the first interrupt value from a state snapshot."""
    for task in state.tasks:
        for interrupt in task.interrupts:
            return interrupt.value
    return {}


def _print_response(content: str) -> None:
    """Render the agent's response as markdown."""
    console.print()
    console.print(Markdown(content))
    console.print()


def main():
    """Run the interactive coding agent CLI."""
    import sys

    # Handle top-level subcommands before anything else
    if len(sys.argv) > 1:
        subcmd = sys.argv[1].lower()
        if subcmd == "logout":
            logout()
            sys.exit(0)
        elif subcmd == "uninstall":
            purge_config()
            console.print()
            console.print("  To fully uninstall the package, run:")
            console.print("  [bold]pip uninstall code-craft[/bold]")
            console.print("  [dim]or, if installed with uv:[/dim]")
            console.print("  [bold]uv pip uninstall code-craft[/bold]")
            sys.exit(0)
        elif subcmd in ("--help", "-h", "help"):
            console.print(BANNER)
            sys.exit(0)

    # Ensure API key is available before anything else — prompts once if missing
    ensure_api_key()

    config = AgentConfig()

    console.print(BANNER)

    # --- Trust gate: must pass before the agent is built or any files touched ---
    if not _trust_check(config.resolved_root):
        console.print("[dim]Exiting. No files were accessed.[/dim]")
        sys.exit(0)

    console.print(f"[dim]Model: {config.model}[/dim]")
    console.print(f"[dim]Project root: {config.resolved_root}[/dim]")
    console.print()

    try:
        agent, checkpointer, store = build_agent(config)
    except Exception as e:
        console.print(f"[red]Failed to build agent: {e}[/red]")
        sys.exit(1)

    thread_id = str(uuid.uuid4())
    lang_config = {"configurable": {"thread_id": thread_id}}
    session_start = time.time()

    console.print(f"[dim]Thread: {thread_id[:8]}...[/dim]")

    while True:
        try:
            console.rule()
            user_input = pt_prompt(HTML("<ansigreen><b>&gt;</b></ansigreen> ")).strip()
            console.rule()
        except (EOFError, KeyboardInterrupt):
            console.print("\n[dim]Goodbye![/dim]")
            break

        if not user_input:
            continue

        # Handle commands
        if user_input.startswith("/"):
            cmd = user_input.lower()
            if cmd in ("/quit", "/exit", "/q"):
                console.print("[dim]Goodbye![/dim]")
                break
            elif cmd == "/new":
                thread_id = str(uuid.uuid4())
                lang_config = {"configurable": {"thread_id": thread_id}}
                console.print(f"[dim]New thread: {thread_id[:8]}...[/dim]")
                continue
            elif cmd == "/help":
                console.print(BANNER)
                continue
            elif cmd == "/logout":
                logout()
                continue
            elif cmd == "/status":
                elapsed = time.time() - session_start
                mins = int(elapsed // 60)
                console.print(f"\n  [bold]Session Info[/bold]")
                console.print(f"  Thread:  [cyan]{thread_id[:8]}...[/cyan]")
                console.print(f"  Model:   [cyan]{config.model}[/cyan]")
                console.print(f"  Root:    [cyan]{config.resolved_root}[/cyan]")
                console.print(f"  Uptime:  [cyan]{mins}m {int(elapsed % 60)}s[/cyan]")
                console.print()
                continue
            elif cmd == "/clear":
                console.clear()
                continue
            elif cmd == "/compact":
                thread_id = str(uuid.uuid4())
                lang_config = {"configurable": {"thread_id": thread_id}}
                console.print(f"[dim]Context compacted → new thread: {thread_id[:8]}...[/dim]")
                continue
            else:
                console.print(f"[yellow]Unknown command: {user_input}[/yellow]")
                continue

        # Stream agent execution with real-time step display
        try:
            input_data = {"messages": [{"role": "user", "content": user_input}]}
            start_time = time.time()

            _spinner.start()

            for chunk in agent.stream(input_data, lang_config, stream_mode="updates"):
                _display_stream_chunk(chunk)

            _spinner.stop()

            # Handle interrupts (approval loop)
            state = agent.get_state(lang_config)
            while _has_interrupts(state):
                decisions = collect_decisions(_get_interrupt_value(state))
                _spinner.start()
                for chunk in agent.stream(
                    Command(resume={"decisions": decisions}),
                    lang_config,
                    stream_mode="updates",
                ):
                    _display_stream_chunk(chunk)
                _spinner.stop()
                state = agent.get_state(lang_config)

            # Print the final response
            messages = state.values.get("messages", [])
            if messages:
                last_msg = messages[-1]
                content = getattr(last_msg, "content", str(last_msg))
                if content:
                    _print_response(content)

            # Show elapsed time
            elapsed = time.time() - start_time
            if elapsed >= 60:
                mins = int(elapsed // 60)
                secs = int(elapsed % 60)
                console.print(f"  [dim]* Completed in {mins}m {secs}s[/dim]")
            else:
                console.print(f"  [dim]* Completed in {elapsed:.0f}s[/dim]")

        except KeyboardInterrupt:
            _spinner.stop()
            console.print("\n[yellow]Interrupted.[/yellow]")
        except Exception as e:
            _spinner.stop()
            console.print(f"\n[red]Error: {e}[/red]")


if __name__ == "__main__":
    main()
