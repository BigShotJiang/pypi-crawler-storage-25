"""Configuration for the coding agent."""

import os
from dataclasses import dataclass, field
from pathlib import Path

from dotenv import load_dotenv

load_dotenv()

# Directory containing this file — used to locate bundled package data
_PACKAGE_DIR = Path(__file__).parent


@dataclass
class AgentConfig:
    """Configuration for the deep coding agent."""

    # Model settings
    # Supports provider:model format — e.g. anthropic:claude-sonnet-4-6
    # or openrouter:anthropic/claude-sonnet-4-6 (requires langchain-openrouter)
    # Uses field(default_factory=...) so env vars are read at instantiation time,
    # after ensure_api_key() has loaded credentials into the environment.
    model: str = field(default_factory=lambda: os.getenv("MODEL", "openrouter:anthropic/claude-sonnet-4-6"))
    # Subagent model defaults to main model if unset — set to a cheaper model to save credits
    subagent_model: str = field(
        default_factory=lambda: os.getenv("SUBAGENT_MODEL", "") or os.getenv("MODEL", "openrouter:anthropic/claude-haiku-4.5")
    )
    max_retries: int = 3
    timeout: int = 120_000  # milliseconds (120 seconds)

    # Project settings
    project_root: str = os.getenv("PROJECT_ROOT", ".")

    # Agent limits
    model_call_limit: int = 50
    tool_call_limit: int = 100

    # Display settings
    show_token_usage: bool = True
    auto_compact_threshold: int = 40  # auto-compact after N model calls

    # Human-in-the-loop: which tools require approval
    interrupt_tools: dict = field(default_factory=lambda: {
        "execute": True,
        "write_file": {"allowed_decisions": ["approve", "reject"]},
        "edit_file": True,
    })

    # Paths — skills_dir defaults to the bundled package skills, so they work
    # whether the package is installed via pip or run from source.
    agents_md_path: str = "AGENTS.md"
    memories_dir: str = "/memories/"
    skills_dir: str = str(_PACKAGE_DIR / "skills")

    @property
    def resolved_root(self) -> Path:
        return Path(self.project_root).resolve()

    @property
    def agents_md_file(self) -> Path:
        """AGENTS.md: prefer the project's own file, fall back to bundled template."""
        project_file = self.resolved_root / self.agents_md_path
        if project_file.exists():
            return project_file
        return _PACKAGE_DIR / "AGENTS.md"
