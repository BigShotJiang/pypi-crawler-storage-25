# Project: Code Craft

## Overview
A Claude Code-like AI coding assistant built with LangChain Deep Agents.
Provides interactive CLI-based coding assistance with file system access,
shell execution, human-in-the-loop approvals, and persistent memory.

## Tech Stack
- Python 3.11+
- LangChain Deep Agents framework (deepagents)
- LangGraph for orchestration and state management
- Rich for terminal UI
- prompt-toolkit for interactive input

## Project Structure
```
code_craft/
├── __init__.py            — package metadata and version
├── __main__.py            — entry point for `python -m code_craft`
├── agent.py               — core agent factory (build_agent)
├── cli.py                 — interactive CLI with streaming display
├── config.py              — AgentConfig dataclass and settings
├── interrupt_handler.py   — human-in-the-loop approval UI with diffs
├── prompts.py             — system prompts for agent and subagents
├── tools.py               — custom tools (git, delete, test runner)
└── skills/
    ├── code-review/SKILL.md  — code review workflow
    ├── commit/SKILL.md       — git commit workflow
    ├── pr-creation/SKILL.md  — pull request creation workflow
    └── testing/SKILL.md      — test writing workflow
```

## Commands
- **Run:** `craft-code` or `python -m code_craft`
- **Test:** `pytest`
- **Lint:** `ruff check .`
- **Build:** `python -m build`
- **Install (dev):** `pip install -e ".[dev]"`

## Coding Conventions
- Use type hints on all public functions and method signatures
- Keep modules focused — one responsibility per file
- Use Rich for ALL terminal output (never bare print)
- Use dataclasses for configuration objects
- Follow existing patterns: check how similar features are implemented before adding new ones
- Prefer editing existing files over creating new ones

## Key Patterns
- Agent construction: see `agent.py:build_agent()` for the full factory pattern
- Streaming display: see `cli.py:_display_stream_chunk()` for how tool calls are shown
- Interrupt handling: see `interrupt_handler.py:collect_decisions()` for approval UI
- Subagent definition: see `agent.py:_build_subagents()` for the subagent spec format
- Custom tools: see `tools.py:CUSTOM_TOOLS` for tool definition using @tool decorator

## Known Issues / Gotchas
- The deepagents framework maps the project root to `/` in the virtual filesystem
- Shell commands run via LocalShellBackend with CWD set to project root
- Memory files at `/memories/` are routed to StoreBackend, not the local filesystem
- OpenRouter model names use format `openrouter:provider/model-name`
- The interrupt system requires a checkpointer (MemorySaver) to persist state
