"""Core agent factory — builds the deep coding agent with all capabilities."""

from __future__ import annotations

import os
from pathlib import Path

from deepagents import create_deep_agent
from deepagents.backends import (
    CompositeBackend,
    LocalShellBackend,
    StateBackend,
    StoreBackend,
)
from deepagents.backends.utils import create_file_data
from langchain.chat_models import init_chat_model
from langgraph.checkpoint.memory import MemorySaver
from langgraph.store.memory import InMemoryStore

from .config import AgentConfig
from .prompts import (
    CODE_REVIEW_PROMPT,
    CODING_SYSTEM_PROMPT,
    EXPLORE_PROMPT,
    PLAN_PROMPT,
    RESEARCH_PROMPT,
)
from .tools import CUSTOM_TOOLS


def _load_agents_md(config: AgentConfig, store: InMemoryStore) -> None:
    """Load AGENTS.md into the store if it exists on disk."""
    agents_md_file = config.agents_md_file
    if agents_md_file.exists():
        content = agents_md_file.read_text()
        store.put(
            namespace=("filesystem",),
            key="/AGENTS.md",
            value=create_file_data(content),
        )


def _build_memory_prompt(config: AgentConfig) -> str:
    """Append project root and persistent memory instructions to the system prompt."""
    return CODING_SYSTEM_PROMPT + f"""

## Working directory
Your project root is: `{config.resolved_root}`
In the virtual filesystem exposed by your tools, this maps to `/`.
**Always start file exploration from `/`** — never explore system paths like /usr, /bin, /etc.
When using `ls`, `read_file`, `write_file`, or `edit_file` without an explicit path, default to `/`.

## Persistent memory
You have access to persistent memory at {config.memories_dir}:
- {config.memories_dir}project_context.md — tech stack, architecture, conventions
- {config.memories_dir}user_preferences.md — coding style preferences
- {config.memories_dir}known_issues.md — recurring bugs or gotchas

Read these at session start. Update them when you learn something new about the project.
"""


def _build_subagents(main_model, subagent_model) -> list[dict]:
    """Define specialized subagents the main agent can delegate to."""
    return [
        {
            "name": "code-reviewer",
            "description": (
                "Performs in-depth code review: checks for bugs, security issues, "
                "performance problems, and style violations."
            ),
            "system_prompt": CODE_REVIEW_PROMPT,
            "model": subagent_model,
        },
        {
            "name": "researcher",
            "description": (
                "Researches APIs, libraries, and documentation to answer "
                "technical questions."
            ),
            "system_prompt": RESEARCH_PROMPT,
            "model": subagent_model,
        },
        {
            "name": "explore",
            "description": (
                "Fast, read-only codebase exploration — find files by pattern, "
                "search code content, understand project architecture. Use for "
                "quick searches and analysis before making changes."
            ),
            "system_prompt": EXPLORE_PROMPT,
            "model": subagent_model,
        },
        {
            "name": "planner",
            "description": (
                "Software architect that designs implementation plans. Analyzes "
                "codebase, identifies files to modify, finds reusable code, and "
                "proposes a concrete step-by-step approach. Use for non-trivial "
                "tasks before starting implementation."
            ),
            "system_prompt": PLAN_PROMPT,
            "model": main_model,
        },
    ]


def _make_backend(config: AgentConfig):
    """Build a composite backend: local filesystem + persistent memory store."""

    def factory(runtime):
        return CompositeBackend(
            default=LocalShellBackend(
                root_dir=str(config.resolved_root),
                env={**os.environ, "PWD": str(config.resolved_root)},
            ),
            routes={
                config.memories_dir: StoreBackend(runtime),
            },
        )

    return factory


def _init_model(model_str: str, max_retries: int, timeout: int):
    """Initialize a chat model, handling openrouter: prefix separately."""
    if model_str.startswith("openrouter:"):
        from langchain_openrouter import ChatOpenRouter
        return ChatOpenRouter(model=model_str[len("openrouter:"):])
    return init_chat_model(model=model_str, max_retries=max_retries, timeout=timeout)


def build_agent(config: AgentConfig | None = None):
    """Build and return the fully configured deep coding agent.

    Returns:
        (agent, checkpointer, store) tuple for use in the CLI or programmatically.
    """
    if config is None:
        config = AgentConfig()

    checkpointer = MemorySaver()
    store = InMemoryStore()

    # Pre-load AGENTS.md into the store
    _load_agents_md(config, store)

    model = _init_model(config.model, config.max_retries, config.timeout)

    system_prompt = _build_memory_prompt(config)

    # Resolve skills directory relative to the project root, not the shell's CWD
    skills_dir = (config.resolved_root / config.skills_dir).resolve()
    skills = [str(skills_dir)] if skills_dir.exists() else []

    agent = create_deep_agent(
        model=model,
        system_prompt=system_prompt,
        backend=_make_backend(config),
        tools=CUSTOM_TOOLS,
        subagents=_build_subagents(model, _init_model(config.subagent_model, config.max_retries, config.timeout)),
        skills=skills,
        interrupt_on=config.interrupt_tools,
        memory=["/AGENTS.md"],
        store=store,
        checkpointer=checkpointer,
    )

    return agent, checkpointer, store
