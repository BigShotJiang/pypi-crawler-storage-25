---
name: code-review
description: Use when asked to review code, check for bugs, audit security, or assess code quality.
---

# Code Review Workflow

## Step 1: Gather context
- Read the file(s) to review
- Check git diff if reviewing recent changes
- Understand the module's purpose and how it fits in the architecture

## Step 2: Review checklist

### Security (OWASP Top 10)
- Injection flaws (SQL, command, XSS, LDAP)
- Broken authentication or session management
- Sensitive data exposure (hardcoded secrets, logging PII)
- Path traversal and insecure file operations
- Missing input validation and sanitization

### Bugs & Logic
- Off-by-one errors, null/undefined references
- Race conditions in concurrent code
- Logic errors in conditionals and loops
- Unhandled edge cases (empty input, large input, negative values)
- Resource leaks (unclosed files, connections, streams)

### Performance
- N+1 query patterns
- Unnecessary memory allocations or copies
- Blocking I/O in async code paths
- Missing database indexes for frequent queries
- Redundant computations that could be cached

### Style & Maintainability
- Naming clarity and consistency
- Dead code or unused imports
- Missing or misleading comments
- Inconsistent error handling patterns
- Overly complex functions that should be split

## Step 3: Report findings
For each issue found:
- **Severity**: critical | warning | info
- **Location**: file_path:line_number
- **Issue**: One-sentence description
- **Fix**: Concrete code suggestion

End with a 1-2 sentence overall assessment.

## Rules
- Be specific — always reference line numbers
- Suggest fixes, don't just point out problems
- Prioritize critical issues over style nits
- If the code is clean, say so briefly — don't invent issues
