---
name: pr-creation
description: Use when the user asks to create a pull request, open a PR, or submit changes for review.
---

# Pull Request Creation Workflow

## Step 1: Analyze all changes
Run these commands to understand the full scope:
- `git status` — check for uncommitted changes
- `git log --oneline main..HEAD` (or appropriate base branch) — see ALL commits to include
- `git diff main...HEAD` — see the complete diff against base branch

Important: Review ALL commits that will be in the PR, not just the latest one.

## Step 2: Draft PR content
- **Title**: Short, under 70 characters. Use description/body for details.
- **Summary**: 1-3 bullet points explaining what changed and why
- **Test plan**: How to verify the changes work

## Step 3: Push and create
- Create a new branch if needed
- Push to remote with `-u` flag: `git push -u origin <branch-name>`
- Create PR using gh CLI:

```bash
gh pr create --title "the pr title" --body "$(cat <<'EOF'
## Summary
- <bullet points>

## Test plan
- [ ] <verification steps>

🤖 Generated with [craft-code](https://github.com/Shubham-1994/code-craft)
EOF
)"
```

## Step 4: Report
- Show the PR URL to the user
- Summarize what's included in the PR

## Rules
- Never force push to main/master
- Always use `gh` CLI for GitHub operations
- Include all relevant commits in the PR description
