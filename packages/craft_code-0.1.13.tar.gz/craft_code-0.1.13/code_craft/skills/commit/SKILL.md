---
name: commit
description: Use when the user asks to commit changes, create a git commit, or save their work to git.
---

# Git Commit Workflow

Follow these steps precisely when creating a git commit:

## Step 1: Understand the changes
Run these commands to understand what will be committed:
- `git status` — see all modified, staged, and untracked files
- `git diff` — see unstaged changes
- `git diff --cached` — see staged changes
- `git log --oneline -5` — see recent commit style

## Step 2: Draft commit message
- Summarize the nature of changes (new feature, bug fix, refactor, etc.)
- Use the correct verb: "add" for new features, "fix" for bugs, "update" for enhancements, "refactor" for restructuring
- Write 1-2 concise sentences focusing on WHY, not WHAT
- Follow the repository's existing commit message style

## Step 3: Stage files
- Stage specific files by name: `git add file1.py file2.py`
- NEVER use `git add .` or `git add -A` — this can accidentally include secrets or large files
- NEVER commit files containing secrets (.env, credentials, API keys, tokens)
- If unsure, ask the user which files to include

## Step 4: Create the commit
Use HEREDOC format for the commit message:
```
git commit -m "$(cat <<'EOF'
<commit message here>

Co-Authored-By: craft-code <noreply@craft-code.dev>
EOF
)"
```

## Step 5: Verify
- Run `git status` to confirm the commit succeeded
- Run `git log --oneline -1` to show the new commit
- Report the commit hash and message to the user

## Rules
- NEVER amend existing commits unless the user explicitly asks
- NEVER skip pre-commit hooks (no --no-verify)
- NEVER push unless the user explicitly asks
- If a pre-commit hook fails: fix the issue, re-stage, and create a NEW commit
