---
name: testing
description: Use when asked to write, run, or debug tests for any module or function.
---

# Testing Workflow

## Step 1: Understand the code
- Read the source file being tested
- Identify all public functions/methods and their edge cases
- Check for existing tests to avoid duplication

## Step 2: Write tests
- Test file path: `tests/test_<module>.py`
- Use the project's test framework (default: pytest)
- Each test must be independent and deterministic
- Naming convention: `test_<function>_<scenario>_<expected>`

### Test structure
- Use fixtures for shared setup (conftest.py for cross-module fixtures)
- Mock external dependencies (APIs, databases, file system) but NOT internal logic
- Test both happy path and edge cases: empty inputs, None, boundary values, errors
- Include at least one negative test (expected failure)

## Step 3: Run and verify
- Run the specific test file: `pytest tests/test_<module>.py -v`
- Fix any failures and re-run until all tests pass
- Check coverage if the project uses it: `pytest --cov=<module>`

## Rules
- Never modify the source code to make tests pass (unless there's an actual bug)
- Tests should document behavior, not implementation details
- Avoid testing private/internal methods directly
- Don't over-mock — test real behavior when possible
