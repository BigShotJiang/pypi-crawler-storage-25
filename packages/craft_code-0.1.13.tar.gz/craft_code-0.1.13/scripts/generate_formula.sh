#!/usr/bin/env bash
# Generate a complete Homebrew formula for craft-code.
# Requires: Python 3
#
# Usage:
#   ./scripts/generate_formula.sh [VERSION]
#
# Example:
#   ./scripts/generate_formula.sh 0.1.11
#
# OUTPUT: homebrew-tap/Formula/craft-code.rb (overwritten)

set -euo pipefail

VERSION="${1:-$(python3 -c "import tomllib; d=tomllib.load(open('pyproject.toml','rb')); print(d['project']['version'])")}"
FORMULA_PATH="homebrew-tap/Formula/craft-code.rb"
REPO="Shubham-1994/code-craft"

echo "==> Generating formula for craft-code v${VERSION}"

# ---- 1. Get sdist URL and SHA256 from PyPI JSON API --------------------
# This works without any local tarball or GitHub tag.
echo "==> Fetching sdist URL and SHA256 from PyPI..."
PYPI_JSON=$(curl -fsSL "https://pypi.org/pypi/craft-code/${VERSION}/json")
TARBALL_URL=$(echo "${PYPI_JSON}" | python3 -c "
import json, sys
data = json.load(sys.stdin)
for f in data['urls']:
    if f['packagetype'] == 'sdist':
        print(f['url'])
        break
")
SHA256=$(echo "${PYPI_JSON}" | python3 -c "
import json, sys
data = json.load(sys.stdin)
for f in data['urls']:
    if f['packagetype'] == 'sdist':
        print(f['digests']['sha256'])
        break
")

if [[ -z "${TARBALL_URL}" || -z "${SHA256}" ]]; then
  echo "ERROR: Could not find sdist for craft-code==${VERSION} on PyPI."
  echo "  Make sure the package is published: https://pypi.org/project/craft-code/${VERSION}/"
  exit 1
fi
echo "    url:    ${TARBALL_URL}"
echo "    sha256: ${SHA256}"

# ---- 2. Install craft-code + deps in an isolated venv -----------------
# A fresh venv avoids all system-Python conflicts (no pkg_resources needed).
VENV_DIR="$(mktemp -d)/gen-venv"
python3 -m venv "${VENV_DIR}"
"${VENV_DIR}/bin/pip" install --quiet craft-code=="${VERSION}"

# ---- 3. Generate resource blocks via PyPI API -------------------------
echo "==> Generating resource blocks (this may take a moment)..."
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
RESOURCES=$("${VENV_DIR}/bin/python3" "${SCRIPT_DIR}/gen_resources.py" craft-code)

if [[ -z "${RESOURCES}" ]]; then
  echo "ERROR: poet returned empty output for craft-code."
  exit 1
fi

# ---- 4. Write the formula ----------------------------------------------
cat > "${FORMULA_PATH}" <<RUBY
class CraftCode < Formula
  include Language::Python::Virtualenv

  desc "An AI coding assistant"
  homepage "https://github.com/${REPO}"
  url "${TARBALL_URL}"
  sha256 "${SHA256}"
  license "MIT"

  depends_on "python@3.12"
  depends_on "rust" => :build

  # Resources generated with homebrew-pypi-poet on $(date -u +%Y-%m-%d)
${RESOURCES}

  def install
    virtualenv_install_with_resources
  end

  test do
    assert_match version.to_s, shell_output("#{bin}/craft-code --version 2>&1", 1)
    system bin/"craft-code", "--help"
  end
end
RUBY

echo "==> Written to ${FORMULA_PATH}"
echo ""
echo "Next steps:"
echo "  1. Review ${FORMULA_PATH}"
echo "  2. Push homebrew-tap/ contents to: https://github.com/shubhamagarwal/homebrew-craft-code"
echo "  3. Users can then install with:"
echo "       brew tap shubhamagarwal/craft-code"
echo "       brew install craft-code"
