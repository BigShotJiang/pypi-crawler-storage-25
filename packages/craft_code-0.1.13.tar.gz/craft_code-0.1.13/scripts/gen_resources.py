#!/usr/bin/env python3
"""
Generate Homebrew resource blocks for a Python package.
Queries the PyPI JSON API directly — no pkg_resources/setuptools needed.

Usage:
    python3 gen_resources.py <package-name>

The calling script must first install the package (and its deps) into the
current Python environment so that `pip freeze` can enumerate them.
"""
import json
import subprocess
import sys
import urllib.request


def get_pypi_sdist(name: str, version: str):
    """Return (url, sha256) for the sdist of name==version, or (None, None)."""
    for candidate in [name, name.replace("_", "-"), name.replace("-", "_")]:
        try:
            api_url = f"https://pypi.org/pypi/{candidate}/{version}/json"
            with urllib.request.urlopen(api_url, timeout=15) as r:
                data = json.loads(r.read())
            for entry in data["urls"]:
                if entry["packagetype"] == "sdist":
                    return entry["url"], entry["digests"]["sha256"]
        except Exception:
            continue
    return None, None


def main():
    if len(sys.argv) < 2:
        sys.exit("Usage: gen_resources.py <package-to-skip>")

    skip_name = sys.argv[1].lower()
    skip = {skip_name, skip_name.replace("-", "_"), skip_name.replace("_", "-"),
            "pip", "setuptools", "wheel", "pkg_resources", "pkg-resources"}

    result = subprocess.run(
        [sys.executable, "-m", "pip", "freeze"],
        capture_output=True, text=True, check=True,
    )

    errors = []
    for line in sorted(result.stdout.splitlines()):
        if "==" not in line:
            continue
        name, version = line.split("==", 1)
        if name.lower().replace("-", "_") in {s.replace("-", "_") for s in skip}:
            continue

        url, sha256 = get_pypi_sdist(name, version)
        if url and sha256:
            print(f'  resource "{name}" do')
            print(f'    url "{url}"')
            print(f'    sha256 "{sha256}"')
            print(f'  end')
            print()
        else:
            errors.append(f"WARNING: no sdist found for {name}=={version}")

    for e in errors:
        print(e, file=sys.stderr)


if __name__ == "__main__":
    main()
