from ontoenv import OntoEnv, version
from rdflib import Graph


print(version)

print("Make env")
env = OntoEnv(search_directories=["../brick"], strict=False, offline=False, create_or_use_cached=True)
print(env)
print("get brick")
g = Graph()
env.get_closure("https://brickschema.org/schema/1.4/Brick", g)
print(len(g))

print("get brick 2")
brick = Graph()
brick.parse("../brick/Brick.ttl", format="turtle")
env.import_dependencies(brick)
print(len(brick))
brick_name = env.add("https://brickschema.org/schema/1.4.4/Brick.ttl")
print(f"Added {brick_name}")
del env

print("new env")
env2 = OntoEnv(create_or_use_cached=True)
print(env2.store_path())

print("get brick again from URL")
brick = env2.get_graph("https://brickschema.org/schema/1.4/Brick")
print(len(brick))
print(brick)
print(type(brick))

print("brick closure", env2.list_closure("https://brickschema.org/schema/1.4/Brick"))

env2.import_graph(brick, "https://w3id.org/rec")
brick.serialize("test.ttl", format="turtle")

print("qudtqk deps", env2.get_importers("http://qudt.org/2.1/vocab/quantitykind"))

# get an rdflib.Dataset (https://rdflib.readthedocs.io/en/stable/apidocs/rdflib.html#rdflib.Dataset)
ds = env2.to_rdflib_dataset()
for graph in list(ds.graphs()):
    print(f"Graph {graph.identifier} has {len(graph)} triples")
