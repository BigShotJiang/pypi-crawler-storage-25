---
name: fact-tdd
description: Test-Driven Development discipline. Loaded by fact-implement when a task touches business logic (typically anything under src/, lib/, app/). Enforces the RED → GREEN → REFACTOR cycle: write a failing test first, write the minimum code to pass, then clean up. Skipped for config tweaks, throwaway scripts, and non-logic edits.
---

# fact-tdd

You're about to write code for a task. Before you touch the implementation, follow the cycle below. The point is not religious purity — it's that **a failing test you write first is the only way to know your test is actually testing your code**, and not silently passing because the assertion was always true.

## When TDD applies

Apply this skill when the task touches:
- New business logic (functions, classes, modules under `src/`, `lib/`, `app/`).
- Bug fixes (the bug **is** the missing test).
- API contracts (new endpoints, new public functions).
- State transitions, validation, parsing, anything with branches.

## When to skip

Skip TDD when the task is:
- A config edit (`pyproject.toml`, `.env.example`, JSON/YAML structure).
- A pure rename / move.
- A typo fix.
- A throwaway script that runs once.
- A UI-only tweak with no testable logic (a button color change).
- Documentation.

If you're unsure, default to **applying** TDD. The cost of a 5-line test you didn't strictly need is much lower than the cost of a missing test you needed.

## The cycle

### RED — write a failing test

1. Decide the **smallest behavior** you want this task to deliver. Not the whole task — the next observable step. Examples:
   - "`parse_iso(s)` returns a UTC datetime when given `2026-05-07T15:00Z`."
   - "`/login` returns 401 when password is wrong."
2. Write **one test** that asserts that behavior. Don't write five.
3. Run it. Confirm it fails — and fails for the **right reason** (the function doesn't exist, the assertion is unmet). If it fails with `ImportError` because you forgot to import the module under test, that doesn't count yet — fix the import, re-run, confirm it fails on the assertion.
4. **A test that goes RED for a reason unrelated to your assertion is a false RED.** Common cause: the assertion was always true, the test framework was never going to fail it, you just didn't know.

### GREEN — minimum code to pass

1. Write **the simplest code that makes the test pass**. Not "the right" implementation — the simplest. Hardcoded return values are fine at this stage.
2. Run the test. Confirm it passes.
3. Run **all** other tests in the affected module. None should regress.

### REFACTOR — clean up

1. Now you have a green safety net. Refactor the implementation — extract helpers, simplify branches, rename variables, replace the hardcoded return with the real logic.
2. After every meaningful refactor, run the tests again. They must stay green.
3. **Don't add features in this phase.** If you find yourself wanting to handle another case, that's a new RED — open a new cycle.

## The "no fixes without root cause" red flag

If a test is failing and your instinct is to:
- Catch the exception silently.
- Add a `try/except` that swallows the failure.
- Adjust the assertion until it passes.
- Mark the test `skip`/`xfail`.

…stop. The test is telling you something. Find why it fails before you change anything. Most "fix the test" patches are bug-introducers in disguise.

## Iron law

**Failing test first, then implementation.** If you find yourself writing implementation code without a corresponding RED test in this task, stop and write the test first — even if it's "obvious" what the code should do. The point is the discipline, not the test.

## Working with `fact-verify`

`fact-verify` runs at task close and checks tests pass. If you skipped TDD entirely on a task that should have applied it, `fact-verify` will likely catch it (no new tests in the diff, missing-test smell from the quality audit). The two skills compose: `fact-tdd` is the prevention, `fact-verify` is the gate.

## When you can't TDD a piece

Some things are hard to test before they exist:
- Exploratory work where you genuinely don't know the shape yet.
- UI behavior that requires a running browser.
- Integration with a flaky external service.

For these, write the test **right after** the smallest piece works (within the same task), not "later". A test added 30 minutes later is a real test; a test added "next week" is a never-test.
