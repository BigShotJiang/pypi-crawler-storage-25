---
name: fact-audit
description: Orchestrator for security / architecture / quality audits, plus running the project test suite as a separate action. Triggered automatically by hooks on per-edit and per-task events; comprehensive session reviews are opt-in via /fact-audit. Spawns sub-agents loaded with domain skills from skills.sh, aggregates findings, and routes the user-approval flow before the workflow continues.
---

# fact-audit

You don't decide *when* to audit — the hooks do. When the hook fires
it pauses the workflow and writes a `🔒 FACT AUDIT — workflow halted`
message to your next turn. This skill is the protocol you run when
you see that message.

The hook never produces findings itself. **You** are the one who
runs the audit, by spawning sub-agents loaded with domain skills.

## Triggers and what they mean

| Trigger        | When                            | Scope                                            | Dimensions                            | Sub-agent model |
| -------------- | ------------------------------- | ------------------------------------------------ | ------------------------------------- | --------------- |
| `source-edit`  | After every Edit/Write to `.py`/`.ts`/etc | the single file the agent just wrote      | security, quality                     | Haiku           |
| `task-close`   | When the agent edits `tasks.md` | files modified since the last audit              | security, architecture, quality       | Sonnet          |
| `/fact-audit`  | The user runs the slash command on demand | scope arg (`all` / `security` / …)       | per the arg                           | Sonnet          |

Note: there is no auto-fired audit at session-stop. The Stop event in
Claude Code fires every time the agent ends a turn — including when
it's just asking the user a question — so an auto trigger there
interrupted normal workflow with a long sub-agent review while the
user was about to type their next prompt. Use `/fact-audit all`
explicitly when you want a comprehensive end-of-session check.

## Domain skills (from skills.sh)

For each dimension you need, find or install a domain skill. Check
`.claude/skills/` first — if a matching one is already installed,
reuse it. If not, load `fact-skill-installer` and search skills.sh
with these queries (try in order, take the top reasonable hit):

- **security**:     `OWASP web app security`, `secrets detection`,
                    `<stack>-security-audit`, `static-analysis-security`
- **architecture**: `clean architecture review`, `SOLID principles audit`,
                    `<stack>-architecture-review`, `domain-driven-design`
- **quality**:      `code review checklist`, `code quality audit`,
                    `<stack>-best-practices`, `maintainability review`,
                    `test coverage audit`, `test smell detection`
                    (`quality` covers both code quality AND test quality —
                    naming, complexity, dead code, missing/weak tests, smells)

Replace `<stack>` with what's in `plan.md` (`fastapi`, `nextjs`,
`rails`, etc).

Filter candidates by:
1. install count / repo stars,
2. org reputation (vendor / well-known org > random user),
3. recency (updated in the last few months).

Confirm each install with the user (P7) before downloading.

If nothing reasonable exists for a dimension, proceed without a
domain skill and note that in the report — the sub-agent will use
its general knowledge.

## Per-edit review (`source-edit` trigger)

A single source file just changed. Cheap, narrow.

1. Identify the file from the trigger message.
2. For `[security, quality]`:
   a. Load (or install with confirmation) the domain skill.
   b. Spawn a **Haiku sub-agent** with the domain skill loaded and
      the file as context. Prompt it to return structured findings
      in the format below.
3. Aggregate. Skip dimensions that returned `findings: []`.
4. **If any critical or high finding** → §User-approval flow.
5. **Only medium/low/info** → mention briefly in chat ("noted N
   medium issues, continuing"), don't block.

## Per-task review (`task-close` trigger)

The agent just edited `tasks.md` — a task likely closed.

1. From `.specify/fact/session_state.json`, list
   `files_modified_this_turn` (cap 5 entries by design).
2. For `[security, architecture, quality]`:
   a. Load / install the domain skill.
   b. Spawn a **Sonnet sub-agent** with the skill, the constitution,
      the relevant section of plan.md, and the listed source files.
3. Aggregate. Always run §User-approval flow.

## On-demand comprehensive audit (`/fact-audit all`)

The user invokes this when they want a full end-of-session review.
Same shape as the auto triggers, just broader scope.

1. Run the project test suite via Bash if available (`pytest`,
   `npm test`, `cargo test`, etc). Test failures count as `critical`.
2. Compute the union of all source files modified this session
   (use `session_state.json` and the conversation history).
3. For `[security, architecture, quality]`, spawn three Sonnet
   sub-agents in parallel with their domain skills + the file set.
4. Aggregate test results + sub-agent findings.
5. Run §User-approval flow.

Variants: `/fact-audit security`, `/fact-audit architecture`,
`/fact-audit quality` run a single dimension only.

## Pre-implement gate (used by `fact-discovery` / `fact-research`)

Not hook-triggered. Called explicitly by the workflow skills after
`/speckit.plan` and before `/speckit.tasks`. The plan.md has design
decisions but no code yet, so deterministic linters don't apply —
this is purely sub-agent driven.

1. For `[security, architecture, quality]`, spawn three Sonnet
   sub-agents in parallel with the constitution + spec + plan +
   their domain skill.
2. Sub-agents return findings on the *plan* itself (e.g., "the auth
   approach in §3 doesn't account for token revocation").
3. Aggregate. Run §User-approval flow.
4. If any critical → return to the plan phase. If high → ask the
   user to confirm proceeding. Otherwise continue to
   `/speckit.tasks`.

## Sub-agent invocation — pass `model` explicitly

Every audit sub-agent MUST be invoked with the `model` parameter
set, otherwise it inherits Opus from the main agent and the
audit's cost balloons (3 audit sub-agents × Opus = ~$2-3 per
audit; with Sonnet, ~$0.30-0.50). See fact-rpi-harness §3.

```
# source-edit per-file audit (security/quality, narrow)
Agent(
  description="audit src/x.py for security and quality",
  subagent_type="general-purpose",
  model="haiku",                ← per-edit, narrow scope
  prompt="<security/quality prompt + file content>"
)

# task-close or comprehensive audit (sec/arch/qual, broader)
Agent(
  description="architecture audit on US1 files",
  subagent_type="general-purpose",
  model="sonnet",               ← deeper review, multiple files
  prompt="<architecture audit prompt + file set>"
)
```

If you find yourself omitting `model`, stop and add it. This is
the difference between a $0.50 audit and a $3 one.

## Sub-agent prompt (use verbatim)

When you spawn a sub-agent, include this in the prompt:

```
You are auditing for <DIMENSION>. Read the loaded skill (if any),
then review the provided files / plan / spec. Return findings as a
YAML list (and ONLY a YAML list — no prose around it):

findings:
  - severity: critical | high | medium | low | info
    title: <one-line>
    location: <file:line> or <module name>
    description: |
      <2-3 lines on what is wrong and why it matters>
    recommendation: |
      <1-2 lines on how to fix>

If you find nothing, return `findings: []`. Do not invent issues
to fill space. Be concise.
```

## User-approval flow

```
[You — to user]:

🔒 The audit hook found <N> blocking finding(s) (<dimension>):

  [CRITICAL] <title>
    where: <location>
    why:   <description (one-line)>
    fix:   <recommendation (one-line)>

  [HIGH] <title>
    ...

How would you like to proceed?

  (1) Fix automatically — I'll edit the affected files now.
  (2) I'll fix it manually — pause while you make the changes.
  (3) Override — proceed despite the finding(s). Tell me why; I'll
      log it in the next session summary.
  (4) Rollback — undo the last edit and reconsider.
```

Wait for an explicit choice. Don't proceed on ambiguous answers.

After the user picks:

- **Fix automatically (1)**: make the smallest edit that resolves
  each blocking finding. After your edit, the audit hook fires
  again on PostToolUse — wait for the next agent turn. Re-loop
  through this skill if findings remain.
- **Fix manually (2)**: acknowledge and pause. Once the user says
  they're done, offer `/fact-audit` to run a fresh check (their
  manual editor edit doesn't trigger the hook).
- **Override (3)**: record the finding(s) and the user's reason in
  the next session summary's `What was decided` section. Continue.
- **Rollback (4)**: propose the inverse of your last edit, confirm
  with the user, apply it, then revisit the task with a different
  approach.

## Cost discipline

- `source-edit` audits use Haiku; budget ≤$0.001 per file.
- `task-close` and `session-stop` use Sonnet; budget ≤$0.05 per audit.
- Reuse installed domain skills — only re-search skills.sh if a
  dimension has no skill at all.
- Total audit budget per session ≤20% of session tokens. If
  exceeded, fall back to gate-only audits and tell the user.
- Findings are not persisted to a dashboard panel; they live in
  the conversation. Optionally, write a copy of the aggregate to
  `.specify/fact/audits/<UTC>-<trigger>.md` for record.

## What this skill does NOT do

- It does not silently fix code. The agent (you) edits in response
  to user decision.
- It does not run if no domain skill is found and no fallback is
  available. In that case, surface "no audit performed" to the user.
- It does not bypass the hook. Even if you think the trigger is
  wrong, run the protocol and let the user decide.
