---
name: fact-implement
description: Implementation phase — reads the plan, applies relevant skills, writes code per task, marks tasks done with proof of work.
---

# fact-implement

Loaded after `/speckit.tasks`. You are now executing the plan.

## 1. Before each task

1. Read the task line from `tasks.md` and the corresponding section in `plan.md`.
2. Note the **code snippets** in the plan — those are your contract for shape and signatures.
3. Check `.claude/skills/` for any skill whose name matches the technology in this task. If one matches, load it (read its `SKILL.md`) and follow it.
4. If the task involves a tech with no matching skill and you'd benefit from one, load `fact-skill-installer` and ask the user about installing one.
5. **If the task touches business logic** (anything under `src/`, `lib/`, `app/`, or any file that contains branching/state/parsing — not config or pure renames), **load `fact-tdd`** and follow its RED-GREEN-REFACTOR cycle. The `fact-tdd` skill itself lists when to skip.

## 2. Update mechanical state

Before doing real work, update `.specify/fact/session_state.json` so the dashboard and any future resume protocol know what's active:

```json
{
  "active_feature": "<feature-slug>",
  "active_task_id": "T-007",
  "active_task_started_at": "<UTC timestamp>"
}
```

(In practice the `PostToolUse` hook keeps `updated_at`, `model`, and `files_modified_this_turn` fresh on each turn — you only need to set the *active* fields when they change.)

When you finish a task, clear `active_task_id` (set to `null`) before picking the next one. When you transition to the next task, set both `active_task_id` and `active_task_started_at` again.

### Parallel tasks (`[P]` + worktrees)

If you delegate one or more `[P]`-marked tasks to sub-agents in parallel
(typically via `spec-kit-worktree-parallel`), append entries to
`parallel_tasks` so the dashboard shows them all as in progress:

```json
{
  "active_task_id": "T-002",
  "active_task_started_at": "2026-04-30T01:14:22Z",
  "parallel_tasks": [
    { "id": "T-005", "started_at": "2026-04-30T01:14:30Z", "subagent_id": "sa_xyz", "model": "claude-haiku-4-5" },
    { "id": "T-006", "started_at": "2026-04-30T01:14:31Z", "subagent_id": "sa_abc", "model": "claude-sonnet-4-6" }
  ]
}
```

Rules:
- Use `parallel_tasks` only for tasks tagged `[P]` that you actually
  delegated to a sub-agent in its own worktree. Sub-agents you spawned
  for context forking (lookup, synthesis) DO NOT belong here.
- `active_task_id` and `parallel_tasks` are disjoint: the entry the main
  agent is doing goes in `active_task_id`, never duplicated in
  `parallel_tasks`.
- Remove an entry from `parallel_tasks` as soon as that sub-agent
  finishes (success or failure). Don't let stale entries linger.
- `subagent_id` and `model` are optional but recommended — the dashboard
  shows them on the card so the human can see who's doing what.

## 3. Implement

Style:
- **TDD if the plan says so**, otherwise iterative.
- Make the smallest change that satisfies the task. Don't refactor neighboring code unless the task asks for it.
- Don't add scaffolding, error-handling, or "future-proofing" the task didn't ask for (FACT inherits CLAUDE.md guidance: scope-tight code).

After each non-trivial edit, run the project's tests / type-checker / linter for the touched module. Don't wait until the end.

## 4. Closing a task

**Before flipping `[x]`, load `fact-verify` and run its checklist.** That skill is the proactive gate: it confirms tests pass, type-check is clean, behavior matches the plan, no TODOs / skipped tests / commented-out code were left, and the diff matches the files the plan said you'd touch. State the receipts in your closing message — don't just say "done".

A task is done when:
- `fact-verify`'s checklist all-green.
- The code compiles / type-checks.
- Its tests pass (the ones the task asked for).
- The behavior matches the plan.

Mark the task `[x]` in `tasks.md` and run `/speckit.verify-tasks` if the extension is installed (it cross-checks that real code exists, not just a checked box).

**Per-task audit (continuous).** Load `fact-audit` and run its per-task check (Haiku sub-agent, security-only) on the files this task touched. If a critical finding appears, halt before the next task and surface it.

**End-of-user-story audit.** When the *last* task in a User Story is closed (you can tell from the section heading in `tasks.md`), load `fact-audit` and run its per-user-story check (3 Sonnet sub-agents in parallel, one per dimension). Surface findings before starting the next User Story.

## 5. Watch the 40% line

After every 2-3 closed tasks, estimate context usage. If you're approaching 40%:
1. Write a session summary (fact-rpi-harness §4) describing what you've shipped this batch and the decisions made.
2. Propose intentional compaction.

Don't push past 40%. The plan is still on disk; a fresh session will pick up cleanly.

## 6. Sub-agents during implementation

Use sub-agents to **forkear contexto** while implementing (fact-rpi-harness §2-3). Examples:
- "Find all places that call `getUser()`" → Haiku sub-agent.
- "Read the docs page for `<library>` and tell me how to configure X" → Haiku sub-agent.
- "Summarize the tests in `tests/auth/` that touch session expiry" → Sonnet sub-agent.

You stay focused on the change; the sub-agent comes back with 10 lines you can act on.

## 7. End of phase

When all tasks in `tasks.md` are `[x]`:
- Write a closing session summary (fact-rpi-harness §4) covering the whole feature.
- Tell the user the feature is done and ask whether they want to start a new feature, refactor, or close the project.
