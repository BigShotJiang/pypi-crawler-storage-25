---
name: fact-discovery
description: Greenfield discovery — Socratic conversation to capture vision, then hand off to constitution → specify → plan. The agent never dumps a question list; it asks one thing, listens, decides whether to dig deeper, pivot, or move on.
---

# fact-discovery

Loaded when the user picks "greenfield" in `/fact-start`. Your job is to extract enough vision in **one short, *humane*** conversation that `/speckit.specify` can produce a useful first spec.

## Posture

- **One question per message.** Never bullet-list multiple questions in a single turn. The user reads the first; the rest get ignored.
- **Listen, then decide.** After every answer, you have three moves:
  - **Dig deeper** — the user said something interesting or ambiguous and one more question would unlock it.
  - **Pivot** — the user opened a new topic; honor it, ask about that next.
  - **Move on** — you have what you need on this topic; advance.
- **The user is in charge.** If they say "wait, first I want to talk about X" or "skip that, I don't care", do it. Don't restart your script.
- **Don't extract a 12-page brief.** Six exchanges is usually enough; ten is too many. Vision is a starting point, not a contract.

## The topics you need to leave the conversation having covered

These are not a checklist to march through. They are the topics that should be covered, in any order the conversation produces:

1. **What** — what they want to build, in one paragraph.
2. **For whom** — target users (not "everyone").
3. **Why** — what problem it solves.
4. **Scope v1** — 3-5 core features (push back on scope creep).
5. **References** — projects they admire / want to avoid.
6. **Constraints** — budget, deadline, deployment target, product language.
7. **Stack preference** — only if they have one; otherwise suggest after the vision draft.

Order is a hint, not a script. If the user volunteers stack on turn 1, log it and skip the question.

## Decision after every answer

Before you respond, classify the user's last answer:

| Signal in their answer | Move |
| --- | --- |
| Vague / abstract / contradictory | **Dig deeper.** One follow-up question, no more. |
| Surfaces a new topic you hadn't asked yet | **Pivot.** Acknowledge, then ask about that. |
| Clear and specific | **Move on** to the next uncovered topic. |
| Says "I don't know yet" | **Move on**, log as open question for `/speckit.clarify`. |
| Says "first let me tell you about X" | **Pivot, no resistance.** |

State the move briefly when it helps the conversation breathe ("Got it on the users — now, what problem are you solving?"). Don't over-narrate; one short transition is enough.

## Investigate references (when mentioned)

If the user mentions a reference ("like Notion", "like Linear but…"), spawn a **sub-agent** (Haiku or Sonnet — see `fact-rpi-harness` §3) with a focused prompt:

> Investigate in one pass the typical features and value proposition of <reference>. Return 5-10 bullets, no more.

Don't read the response into the main context until the sub-agent returns its summary.

## Vision draft — the explicit gate

Once you have what you need (typically after 5-7 exchanges), synthesize the vision in this exact shape and show it to the user as a block:

```markdown
# Vision — <project-name>

## For whom
<1-2 lines>

## Problem it solves
<1-2 lines>

## Core features v1
- <feature 1>
- <feature 2>
- ...

## Tentative stack
<one line>

## Constraints
<one line>
```

Then ask, **explicitly**:

> "Does this capture what you want? Tell me what you'd change — anything from a single bullet to the whole framing. Or say 'looks good' and I'll move to constitution."

Iterate **at most twice**. If the user keeps adding scope on the third iteration, push back:

> "We're at iteration 3 on scope. FACT separates phases — is this v1, or are you imagining v2? I'll lock v1 here if you say so."

## Skill suggestion (with confirmation)

Once vision is approved, scan the proposed stack for technologies that benefit from procedural skills (e.g. Next.js, Supabase, Stripe, Tailwind, Postgres patterns). If you identify candidates, **load the skill `fact-skill-installer`** and follow its protocol — never download anything without an explicit "yes" from the user.

## Hand-off to Spec Kit

Trigger Spec Kit in this order:

1. `/speckit.constitution` — derive 4-6 principles from the vision (taste, scope discipline, target users).
2. `/speckit.specify` — feed it the approved vision.
3. `/speckit.clarify` — let it surface ambiguities; resolve them with the user.
4. `/speckit.plan` — with the agreed stack.
5. **Pre-implementation audit gate (mandatory).** Load `fact-audit` and run its pre-implement gate against `constitution.md` + `spec.md` + `plan.md`. If any critical findings, return to step 4 to revise the plan. Only proceed past the gate when no critical finding remains.
6. `/speckit.tasks`.

Between each step: write a short summary to `.specify/fact/sessions/` (per `fact-rpi-harness` §4) and ask the user if they want to review the generated file before continuing.

After `/speckit.tasks`: load `fact-implement` and stop narrating from this skill.

## Anti-patterns

Watch for these — they're the failure modes this skill exists to prevent:

- **Question dump**: "Tell me 1) what you're building 2) for whom 3) what problem…" → Pick one and ask only that.
- **Script lock-in**: user pivots, you ignore them and ask the next scripted question. → Always honor the pivot.
- **Scope creep tolerance**: user keeps adding features past iteration 2, you keep iterating. → Push back. Lock v1.
- **Premature stack debate**: arguing about Postgres vs MongoDB before knowing what the app does. → Stack is the *last* topic, after the vision is clear.
- **Brief inflation**: trying to extract every edge case before constitution. → That's what `/speckit.clarify` is for. Vision is the starting point, not the spec.
