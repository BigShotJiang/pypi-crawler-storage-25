---
name: fact-verify
description: Verification protocol the agent runs before marking any task `[x]` in tasks.md. Loaded by fact-implement at task close. The single purpose is to prevent the failure mode "task marked done but the work doesn't actually work" — tests not re-run, type-check skipped, behavior diverges from the plan, TODOs left behind.
---

# fact-verify

You're about to mark a task `[x]` in `tasks.md`. Before you do, run this checklist. If any item fails, **the task is not done** — fix it (or surface the gap to the user) before flipping the bit.

This skill is the proactive layer. The audit hooks are reactive — they catch problems after the fact. `fact-verify` prevents them.

## The checklist

For the task you're closing, confirm each item below. State the outcome of each in your message to the user when you announce the task is done — do not just say "done", show the receipts.

1. **Tests for this task pass.** Run them, don't assume.
   - If the task's plan section listed test names or a test file, run those specifically.
   - If the project has a runner and you don't know which subset, run the whole suite if it takes < 30s; otherwise run the module's tests.
   - **Failing tests = task not done.** Don't mark `[x]` and "come back to it later".

2. **Type-check / lint passes for the touched files.**
   - Python: `ruff check <file>` + `mypy <file>` (if either is configured).
   - TypeScript: `tsc --noEmit` (or `pnpm typecheck`) + `eslint <file>`.
   - Other stacks: whatever `plan.md` says.
   - New errors introduced by your edit = task not done.

3. **The behavior matches the plan.**
   - Re-read the task's section in `plan.md` (the code-snippet contract).
   - Compare signatures, side effects, return shape.
   - If you diverged, justify in one sentence in the closing message — or revert and align.

4. **No "I'll come back to this" left in the change.**
   - No `TODO` / `FIXME` / `XXX` you added in this task.
   - No `pytest.mark.skip` / `it.skip` / `xtest` introduced for tests that "almost work".
   - No commented-out code that was meant to be the implementation.
   - No `pass` body where logic was supposed to go.

5. **You actually edited the files the task said you would.**
   - Open the diff (or `git status`) and confirm the files modified match what `plan.md` listed for this task.
   - If you edited extra files, say which and why in the closing message.
   - If you edited fewer, the task may not be done.

6. **The task counter on the dashboard reflects reality.**
   - After flipping `[x]`, glance at `.specify/fact/session_state.json` — `active_task_id` cleared, `files_modified_this_turn` reflects this task's edits.

## What "done" means in your closing message

When you announce the task is closed, name the receipts:

> "T-007 done. Tests: 3 of 3 pass (`tests/auth/test_session.py`). Type-check clean. Behavior matches §3.2 of plan.md (token-revocation path). Diff: `src/auth/session.py`, `tests/auth/test_session.py`."

Not:

> "T-007 done."

The first is verifiable. The second invites the failure mode this skill exists to prevent.

## When this skill does NOT apply

- **Pure planning / spec tasks** (e.g., a task that says "decide between X and Y and write rationale to plan.md"). There's nothing to type-check or test. Confirm the file exists and the rationale is there. Skip items 1-2.
- **Pure documentation tasks** (README sections, comments). Items 1-2 N/A; items 3-5 still apply.
- **Tasks the user explicitly told you to fast-track**. Note the override in the closing message. Don't make this a habit.

## Iron law

A task is `[x]` only when **a fresh reader could open the diff and confirm each checklist item without trusting your word**. If you'd hesitate to show the diff, the task isn't done.
