---
name: fact-rpi-harness
description: Materializes the RPI (Research-Plan-Implement) discipline. Always loaded. Owns the 40% rule, intentional compaction, sub-agent strategy, and semantic state writes.
---

# fact-rpi-harness

These rules are **non-negotiable** (P4 in the FACT spec). If a decision in the conversation conflicts with one of them, surface the conflict to the user — don't silently bend the rule.

## 1. The 40% rule

Models perform reliably up to ~40% of their context window. Past that you enter the **dumb zone**: silent quality drops, dropped instructions, fabrication.

**At every turn**, estimate your context usage. If you're approaching 40% (or you can already feel quality slipping), stop and do **intentional compaction**:

1. Pick a natural seam — a finished task, a closed phase, a decision just made.
2. Write a concise markdown summary (`What was done`, `What was decided`, `What's pending / next`) to `.specify/fact/sessions/<UTC-timestamp>.md`. See §4 for the exact format.
3. Offer the user **three options** (the first is the cheapest and recommended):
   - **(a) Run `/compact` here** — Claude Code's built-in slash command summarizes the running conversation and continues in the *same* session with reduced context. The user types it; the agent can't run it. After /compact, every turn from here pays cache_read on the smaller summary, not the full transcript.
   - **(b) Close + reopen** — start a fresh Claude Code session. `fact-onboarding` will pick up the file you just wrote as the primer.
   - **(c) Keep going as-is** — every turn keeps paying cache_read on the full transcript. Sometimes the right call (mid-task, no time to switch). The hook's next 1M milestone will offer again later.
4. **Always close with a "how to wake me up" hint**, because Claude Code does NOT auto-take a turn after `/compact`. Without it, the user types the slash command, sees a recap, and is then staring at a blank prompt with no idea what to type. Example:
   > "After /compact, just type your answer to <open question> (or `continue`) and I'll pick up from <next concrete step>."
5. On the next session (after option a or b), the resumen + the Spec Kit files are the only context that needs to load.

**Don't try to power through the dumb zone.** The cost of a fresh session with a good resumen is always lower than the cost of bad work that has to be redone.

### Auto-trigger from the hooks

There is **one** trigger: the active context cache reaches 60% of
the model's context window (600K on Opus 4.7 with 1M context, 120K
on Sonnet/Haiku with 200K). 5-min cooldown between fires so it
doesn't re-prompt while you're mid-response.

Earlier versions also fired on section closures, feature complete,
phase transitions, and session-stop. Those were removed because
they triggered too often during normal flow. If you want a
compaction at a natural seam (you just finished a feature, you're
about to start a long Phase 0 research), do it on your own:
write the summary file and propose the 3 options to the user.

## 2. Sub-agents to fork context, not split roles (P5)

A sub-agent is a **compression tool**, not a job title. There is no "frontend agent" and no "backend agent". There are tasks that need to read a lot to produce a little.

Fork a sub-agent when:
- You'd otherwise have to read 10+ files just to answer one question.
- A search/grep across the codebase would dump pages of results into your context.
- You need to investigate an external library or doc page that isn't worth keeping in context.

Don't fork a sub-agent when:
- The work is creative or design-level reasoning (do it yourself).
- You'd be paraphrasing instructions you already have (just do it).
- The task fits in one or two file reads (just read them).

## 3. Sub-agent model selection (P6)

Default model heuristic:

| Sub-agent task                                       | Model         |
| ---------------------------------------------------- | ------------- |
| Lookup in codebase, file/grep search, config reads   | **Haiku**     |
| Synthesis across multiple sources, structured summaries | **Sonnet** |
| Architectural reasoning, design choices              | inherit (Opus) |

**Pass the `model` parameter EXPLICITLY** when invoking sub-agents.
Without it, every sub-agent inherits the main agent's model — almost
always Opus — and FACT's cost discipline silently collapses. This is
the single biggest token leak observed in practice (115 turns × Opus
when half should have been Haiku/Sonnet).

Concrete invocation patterns (Claude Code's `Agent` tool):

```
# Lookup / grep / file mapping → Haiku (~10× cheaper than Opus)
Agent(
  description="map src/ folder layout",
  subagent_type="Explore",
  model="haiku",                    # ← REQUIRED, no default. Don't omit.
  prompt="List src/ folders, return one line each. ≤30 lines."
)

# Multi-file synthesis, structured review → Sonnet (~5× cheaper)
Agent(
  description="audit src/auth.py for OWASP issues",
  subagent_type="general-purpose",
  model="sonnet",
  prompt="<your security-audit prompt + file content>"
)

# Hard architectural reasoning where Opus is genuinely worth it
Agent(
  description="evaluate three storage approaches",
  subagent_type="general-purpose",
  # model omitted → inherits Opus (rare, must justify in prompt)
  prompt="..."
)
```

**Verify after the fact**: open the dashboard's `By model` panel.
If everything is `opus-4-7`, the differentiation didn't happen.
Adjust the next call.

Cost note: for a typical 7-Explore brownfield mapping pass, Haiku
sub-agents save roughly 10× over Opus. A 3-dimension audit gate on
Sonnet saves 3-5× over Opus. Across a session that's the difference
between $8 and $25.

## 4. Semantic state writes — `.specify/fact/sessions/`

Write a brief markdown summary at these moments:

- **A workflow phase closed** (constitution → specify → plan → tasks → implement).
- **A large kanban task is done** (multi-file, multi-turn).
- **You triggered intentional compaction** (§1).

File path: `.specify/fact/sessions/<UTC-timestamp>.md` where the timestamp is `YYYY-MM-DDTHHMM`.

Format (keep it tight — this is a summary, not a transcript):

```markdown
# Session <date> <time> — <phase>, <task or milestone>

## What was done
- <bullet, one line each>

## What was decided
- <decisions worth remembering, with rationale in <=1 line>

## What's pending / next
- <what to start next session>
```

Notes:
- One file per event, never edit old ones.
- Keep each section to 3-7 bullets max. If it's longer, it's not a summary.
- If nothing was decided, omit "What was decided" rather than padding it.

### Auto-trigger from the Stop hook

When you see a `📦 FACT COMPACTION` message in your next turn, the
session-stop hook is asking for the summary now (the session is
about to close). The marker that prevents loops is already in place;
just write the file at the suggested path and confirm with one
short line. Do NOT prompt the user — the framework asked for this
automatically. The summary at this moment covers the *whole
session*, not just the last phase.

## 5. Plans must include code snippets (P4 / RPI)

When you write or read a `plan.md`, every non-trivial task should include a code snippet showing the expected shape — function signature, imports, key call sites — not the full implementation. If a `plan.md` lacks snippets, flag it and offer to enrich it before `implement` starts.

## 6. The human reads research and plan (P4 / RPI)

Before `/speckit.implement` runs, **stop and ask the user to review** `research.md` (if present) and `plan.md`. Don't outsource the thinking to the user, but don't run past the gate either. A literal sentence is enough:

> "Before implementing: did you review the plan? If you want to adjust anything, now is the time. If it looks good, tell me and I'll proceed."

## 7. Honest metrics (P10)

If something can't be measured, don't fabricate. Examples:
- "I'm at ~30% context" — fine, you can estimate.
- "This will take 4 hours" — only if you genuinely have a basis.
- "I saved 60% in tokens" — only if the dashboard's counterfactual showed it.

Otherwise: "I'm not sure" beats a confident guess.

## 8. Two-stage review of `[P]` sub-agent results

When you delegate a `[P]`-marked task to a sub-agent in its own
worktree (typically via `spec-kit-worktree-parallel`), the sub-agent
returns a diff. **Don't merge it blindly.** Run a two-stage review
before you accept the work and update `tasks.md`. Each stage is its
own sub-agent — fork context, don't bloat the main one.

Why two stages: a single review prompt mixes two questions ("does
this match the spec?" and "is this clean code?"), and the answer
to either gets diluted. Splitting them keeps each pass focused and
costs less because each can use a smaller model.

### Stage 1 — spec-compliance check (Haiku)

Cheap and narrow. Did the sub-agent build what `tasks.md` and the
relevant `plan.md` snippet asked for?

```
Agent(
  description="spec-compliance check on T-005 diff",
  subagent_type="general-purpose",
  model="haiku",                ← REQUIRED
  prompt="""
You are reviewing a diff for spec compliance only — not code quality.

Task line (from tasks.md):
<paste the [x] line + dependencies>

Plan section (from plan.md):
<paste the relevant §, including code snippet>

Diff:
<paste the unified diff>

Answer in this exact YAML shape (and only YAML):

compliance:
  matches_signature: yes | no | partial
  matches_behavior: yes | no | partial
  notes: |
    <2-3 lines on any divergence; empty string if all 'yes'>
  blocking: yes | no    # 'yes' if you'd ask for changes before merging
"""
)
```

If `blocking: yes`, surface the notes to the user and ask whether to
re-dispatch the sub-agent with corrections, fix in main, or accept
the divergence (logged in the next session summary).

### Stage 2 — code-quality check (Sonnet)

Only run this if Stage 1 passed (or the user accepted the
divergence). Stage 2 reviews **the diff itself** for clean code:
naming, complexity, dead code, side effects, missing tests for new
branches.

```
Agent(
  description="code-quality review on T-005 diff",
  subagent_type="general-purpose",
  model="sonnet",               ← REQUIRED
  prompt="""
You are reviewing a diff for code quality. Spec compliance has already
been checked separately — focus on the code itself.

Diff:
<paste the unified diff>

Answer in this exact YAML shape:

quality:
  findings:
    - severity: critical | high | medium | low
      title: <one-line>
      location: <file:line>
      why: <one-line>
      fix: <one-line suggestion>
  overall: ship_as_is | ship_with_minor_fixes | needs_rework
"""
)
```

If `overall != ship_as_is`, route through `fact-audit`'s user-approval
flow (fix automatically / manually / override / rollback). Critical
findings block the `[x]`; medium/low can be noted and moved on.

### Why these models

Stage 1 is pattern matching against a known spec — Haiku handles it
cheaply (~$0.001 per task). Stage 2 needs more judgement (is this
naming clear? is this branch missing a test?) — Sonnet is the right
tier (~$0.02 per task). Sending either to Opus is over-spending.

### When to skip

- Tasks the user explicitly fast-tracked (note the override).
- Trivial `[P]` tasks that touch < 20 lines and < 2 files.
- Pure renames / config edits (no behavior change to spec-check).

For everything else, run both stages. Across a session this typically
adds < 5% to total token cost and catches real bugs the main agent
would have merged silently.
