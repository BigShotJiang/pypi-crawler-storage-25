"""Background dashboard process management — start, stop, ping."""

from __future__ import annotations

import os
import signal
import subprocess
import sys
import time
from pathlib import Path

import httpx

from fact.paths import ProjectPaths


def is_running(paths: ProjectPaths) -> int | None:
    """Return PID if dashboard is running for this project, else None."""
    if not paths.dashboard_pid.exists():
        return None
    try:
        pid = int(paths.dashboard_pid.read_text(encoding="utf-8").strip())
    except ValueError:
        paths.dashboard_pid.unlink(missing_ok=True)
        return None
    try:
        os.kill(pid, 0)
    except OSError:
        paths.dashboard_pid.unlink(missing_ok=True)
        return None
    return pid


def start(paths: ProjectPaths, port: int, host: str = "127.0.0.1") -> int:
    """Spawn the FastAPI server in the background, return PID."""
    paths.fact_dir.mkdir(parents=True, exist_ok=True)
    log = paths.fact_dir / "dashboard.log"
    env = os.environ.copy()
    env["FACT_PROJECT_ROOT"] = str(paths.root)
    env["FACT_DASHBOARD_PORT"] = str(port)
    env["FACT_DASHBOARD_HOST"] = host
    cmd = [sys.executable, "-m", "fact.dashboard.server"]
    f = open(log, "ab")
    proc = subprocess.Popen(
        cmd,
        cwd=paths.root,
        env=env,
        stdout=f,
        stderr=f,
        start_new_session=True,
    )
    paths.dashboard_pid.write_text(str(proc.pid), encoding="utf-8")
    # Wait briefly for readiness
    url = f"http://{host}:{port}/healthz"
    for _ in range(40):
        try:
            r = httpx.get(url, timeout=0.3)
            if r.status_code == 200:
                break
        except httpx.HTTPError:
            time.sleep(0.1)
    return proc.pid


def stop(paths: ProjectPaths) -> bool:
    pid = is_running(paths)
    if pid is None:
        return False
    try:
        os.kill(pid, signal.SIGTERM)
    except OSError:
        pass
    paths.dashboard_pid.unlink(missing_ok=True)
    return True


def ping(host: str, port: int) -> bool:
    try:
        r = httpx.get(f"http://{host}:{port}/healthz", timeout=0.5)
        return r.status_code == 200
    except httpx.HTTPError:
        return False
