"""Read-only inspection of Spec Kit state.

Per P1 (single source of truth), FACT never writes to .specify/specs/* —
it derives every view from those files. This module is the only place that
parses them.
"""

from __future__ import annotations

import re
from dataclasses import dataclass, field
from pathlib import Path

from fact.paths import ProjectPaths


PHASE_FILES = {
    "constitution": "constitution.md",
    "specify": "spec.md",
    "clarify": "spec.md",  # clarify edits spec.md
    "plan": "plan.md",
    "tasks": "tasks.md",
    "implement": "tasks.md",  # implement updates tasks.md
    "research": "research.md",
}


@dataclass
class Task:
    id: str
    title: str
    done: bool
    raw_line: str
    description: str = ""
    files: list[str] = field(default_factory=list)
    tags: list[str] = field(default_factory=list)       # ["P", "US1", ...]
    deps: list[str] = field(default_factory=list)       # ["T-007", ...]
    section: str = ""                                   # H2/H3 heading above the task
    position: int = 0                                   # 1-based index across the file
    # File-backed metadata (for synthetic phase tasks)
    file_path: str | None = None
    file_size: int | None = None
    file_mtime: str | None = None


@dataclass
class UserStory:
    number: int
    title: str
    priority: str = ""    # "P1", "P2", …


@dataclass
class Story:
    """A group of tasks shown as one kanban card.

    Stories come from four sources:
      - foundation: a project-level story holding the Constitution.
      - workflow:   per-feature Spec/Plan/Research/Tasks-decomposition.
      - user_story: a section in tasks.md whose heading mentions
                    "User Story N". Title is enriched from spec.md
                    when possible.
      - phase:      any other section in tasks.md (Phase 1: Setup,
                    Polish, etc) — Spec Kit work that isn't tied to a
                    user story.
    """

    id: str
    title: str
    kind: str                        # "foundation" | "workflow" | "user_story" | "phase"
    feature_slug: str | None
    tasks: list[Task]
    priority: str = ""               # only set for user_story (P1/P2/P3)
    user_story_number: int | None = None


@dataclass
class FeatureState:
    slug: str
    dir: Path
    has_spec: bool
    has_plan: bool
    has_tasks: bool
    has_research: bool
    tasks: list[Task]

    @property
    def total_tasks(self) -> int:
        return len(self.tasks)

    @property
    def done_tasks(self) -> int:
        return sum(1 for t in self.tasks if t.done)


@dataclass
class ProjectState:
    has_constitution: bool
    features: list[FeatureState]
    current_phase: str  # "none" | "constitution" | "specify" | "plan" | "tasks" | "implement"
    active_feature: FeatureState | None


# ---- Parsing ---------------------------------------------------------------

_TASK_RE = re.compile(
    r"^\s*-\s*\[(?P<done>[ xX])\]\s*(?:\*\*)?(?P<id>T-?\d+)(?:\*\*)?[\s:.\-—]+(?P<title>.+?)\s*$"
)
_HEADING_RE = re.compile(r"^(#{2,4})\s+(?P<text>.+?)\s*$")
_TAG_RE = re.compile(r"\[(?P<tag>P|US\d+|REVIEW|BLOCKED|TODO)\]")
_FILE_RE = re.compile(r"`([^`]+\.(?:py|ts|tsx|js|jsx|md|json|html|css|sh|toml|ya?ml|sql|rs|go|java|kt|rb|php))`")
# Both English and Spanish, since spec-kit is bilingual in practice.
_DEP_RE = re.compile(
    r"(?:[Dd]epende\s+de|[Dd]epends?\s+on|after)\s+((?:T-?\d+(?:\s*,\s*(?:and\s*)?T-?\d+)*))"
)


def parse_tasks(tasks_md: Path) -> list[Task]:
    if not tasks_md.exists():
        return []
    out: list[Task] = []
    current_section = ""
    position = 0
    for line in tasks_md.read_text(encoding="utf-8").splitlines():
        h = _HEADING_RE.match(line)
        if h:
            current_section = h.group("text").strip()
            continue
        m = _TASK_RE.match(line)
        if not m:
            continue
        position += 1
        title = m.group("title").strip()
        # Extract tags ([P], [US1], …) and strip them from the visible title.
        tags = [tm.group("tag") for tm in _TAG_RE.finditer(title)]
        clean_title = _TAG_RE.sub("", title).strip()
        # File references (backtick-delimited paths with known extensions).
        files = []
        for fm in _FILE_RE.finditer(title):
            f = fm.group(1)
            if f not in files:
                files.append(f)
        # Dependencies ("depende de T-007, T-008").
        deps: list[str] = []
        for dm in _DEP_RE.finditer(title):
            for raw in dm.group(1).split(","):
                normalized = re.sub(r"^T-?", "T-", raw.strip())
                if normalized not in deps:
                    deps.append(normalized)

        tid = re.sub(r"^T-?", "T-", m.group("id").upper())
        out.append(
            Task(
                id=tid,
                title=clean_title,
                done=m.group("done").lower() == "x",
                raw_line=line,
                files=files,
                tags=tags,
                deps=deps,
                section=current_section,
                position=position,
            )
        )
    return out


def read_features(paths: ProjectPaths) -> list[FeatureState]:
    """Read feature directories from .specify/specs/ AND specs/ (project
    root). The latter is the AGENTS.md convention used by some brownfield
    projects. We accept directories that contain spec.md as features —
    loose .md files (e.g. specs/spec_xxx.md) are ignored."""
    out: list[FeatureState] = []
    seen_slugs: set[str] = set()

    for base in (paths.specs_dir, paths.alt_specs_dir):
        if not base.exists():
            continue
        for d in sorted(p for p in base.iterdir() if p.is_dir()):
            if not (d / "spec.md").exists():
                continue
            if d.name in seen_slugs:
                # Duplicate slug across both dirs: prefer the one in
                # .specify/specs/ (already added; skip the alt copy).
                continue
            seen_slugs.add(d.name)
            tasks_md = d / "tasks.md"
            out.append(
                FeatureState(
                    slug=d.name,
                    dir=d,
                    has_spec=(d / "spec.md").exists(),
                    has_plan=(d / "plan.md").exists(),
                    has_tasks=tasks_md.exists(),
                    has_research=(d / "research.md").exists(),
                    tasks=parse_tasks(tasks_md),
                )
            )
    return out


def derive_phase(feature: FeatureState | None, has_constitution: bool) -> str:
    if not has_constitution:
        return "constitution"
    if feature is None:
        return "specify"
    if feature.has_tasks and feature.tasks:
        return "done" if feature.done_tasks == feature.total_tasks else "implement"
    if feature.has_plan:
        return "tasks"
    if feature.has_spec:
        return "plan"
    return "specify"


_HTML_COMMENT_RE = re.compile(r"<!--.*?-->", re.DOTALL)
# Spec Kit templates litter content with placeholders like [PROJECT_NAME],
# [PRINCIPLE_1_DESCRIPTION], [FEATURE_NAME], etc. Stripping them lets us tell
# "the template is still untouched" from "the human filled it in".
_TEMPLATE_PLACEHOLDER_RE = re.compile(r"\[[A-Z][A-Z0-9_]*\]")


def _has_substantive_content(p: Path, min_chars: int = 120) -> bool:
    """True only if the file has real content beyond Spec Kit's template skeleton.

    Strips multi-line HTML comments (`<!-- ... -->`), heading lines, and any
    line that is *only* `[ALL_CAPS_PLACEHOLDER]` text. Whatever remains has
    to clear `min_chars`. Files whose first 400 chars still contain a
    `[PLACEHOLDER]` (e.g. `# Implementation Plan: [FEATURE]`) are flagged as
    template-only regardless of body size — Spec Kit ships templates that
    pre-fill several KB from the constitution, which would otherwise pass.
    """
    if not p.exists() or not p.is_file():
        return False
    raw = p.read_text(encoding="utf-8", errors="ignore")
    # Title-area placeholder (e.g. "# Plan: [FEATURE]") = template skeleton.
    if _TEMPLATE_PLACEHOLDER_RE.search(raw[:400]):
        return False
    text = _HTML_COMMENT_RE.sub("", raw)
    body_lines: list[str] = []
    for line in text.splitlines():
        s = line.strip()
        if not s or s.startswith("#") or s.startswith("<!--"):
            continue
        without_placeholders = _TEMPLATE_PLACEHOLDER_RE.sub("", s).strip()
        if not without_placeholders:
            continue
        body_lines.append(line)
    return len("\n".join(body_lines)) >= min_chars


def _last_active_file(session_files: list[str]) -> str | None:
    """The most recent file in the rolling buffer that ISN'T FACT meta-noise.

    Compaction summaries (.specify/fact/sessions/), audit reports
    (.specify/fact/audits/), and other framework files are written by the
    agent in response to its own hooks — they're not "the file the agent is
    currently working on for the user". Filter them out, then return the
    last entry; that's the one truly active right now."""
    META_PREFIXES = ("/.specify/fact/",)
    candidates = [
        f for f in session_files
        if not any(prefix in f for prefix in META_PREFIXES)
    ]
    return candidates[-1] if candidates else None


def _file_meta(p: Path) -> dict:
    if not p.exists() or not p.is_file():
        return {"file_path": None, "file_size": None, "file_mtime": None}
    from datetime import datetime, timezone
    st = p.stat()
    return {
        "file_size": st.st_size,
        "file_mtime": datetime.fromtimestamp(st.st_mtime, tz=timezone.utc).isoformat(timespec="seconds"),
    }


PHASE_DESCRIPTIONS = {
    "Φ-CONST":         "Project principles and governance — `.specify/memory/constitution.md`",
    "Φ-PROJ-RESEARCH": "Codebase mapping (brownfield) — `.specify/memory/research.md`",
    "Φ-RESEARCH":      "Tech research for this feature — APIs, libraries, edge cases (`research.md` inside the feature folder; written by `/speckit.plan` alongside data-model and contracts)",
    "Φ-SPEC":          "What the feature is and why",
    "Φ-PLAN":          "How to build it — stack, architecture, code snippets",
    "Φ-TASKS":         "Decomposition into actionable T-NNN tasks",
}


def _project_phase_task(
    paths: ProjectPaths,
    file_path: Path,
    tid: str,
    title: str,
    session_files: list[str] | None,
) -> Task:
    rel = str(file_path.relative_to(paths.root)) if file_path.is_absolute() else str(file_path)
    # Only the SINGLE most-recent non-FACT-meta file counts as "currently
    # active". Older entries in the buffer were edited recently but the
    # agent has moved on; marking them in_progress shows multiple tasks
    # "in flight" when really only one is.
    active_file = _last_active_file(session_files or [])
    in_prog = active_file is not None and (rel in active_file or str(file_path) in active_file)
    done = (not in_prog) and _has_substantive_content(file_path)
    meta = _file_meta(file_path)
    return Task(
        id=tid,
        title=title,
        done=done,
        raw_line="",
        description=PHASE_DESCRIPTIONS.get(tid, ""),
        files=[rel] if file_path.exists() else [],
        tags=["IN PROGRESS"] if in_prog else [],
        file_path=rel,
        file_size=meta.get("file_size"),
        file_mtime=meta.get("file_mtime"),
    )


def project_phase_tasks(
    paths: ProjectPaths,
    session_files: list[str] | None = None,
) -> list[Task]:
    """Project-level phase tasks: Constitution always; codebase mapping only
    when `.specify/memory/research.md` exists (brownfield)."""
    out = [
        _project_phase_task(
            paths, paths.constitution, "Φ-CONST", "Constitution", session_files,
        )
    ]
    if paths.project_research.exists():
        out.append(
            _project_phase_task(
                paths, paths.project_research, "Φ-PROJ-RESEARCH",
                "Codebase mapping", session_files,
            )
        )
    return out


# Back-compat shim: callers that only want the constitution.
def constitution_task(
    paths: ProjectPaths,
    session_files: list[str] | None = None,
) -> Task:
    return project_phase_tasks(paths, session_files)[0]


def feature_phase_tasks(
    paths: ProjectPaths,
    feature: "FeatureState",
    session_files: list[str] | None = None,
) -> list[Task]:
    """Phase tasks tied to a specific feature: Research / Spec / Plan / Tasks."""
    active_file = _last_active_file(session_files or [])

    def status_for_paths(match_paths: list[str], primary: Path) -> tuple[bool, bool]:
        """A phase task is in_progress if the agent is currently editing
        ANY file in `match_paths` (relative substrings). It's done if the
        primary file has substantive content and nothing in match_paths
        is currently active. Lets one card cover several artifacts (e.g.
        Plan covers plan.md + data-model.md + quickstart.md + contracts/)."""
        in_prog = active_file is not None and any(p in active_file for p in match_paths)
        done = (not in_prog) and _has_substantive_content(primary)
        return done, in_prog

    def _make(tid: str, title: str, ap: Path, rel: str, done: bool, in_prog: bool) -> Task:
        meta = _file_meta(ap)
        return Task(
            id=tid,
            title=title,
            done=done,
            raw_line="",
            description=PHASE_DESCRIPTIONS.get(tid, ""),
            files=[rel] if ap.exists() else [],
            tags=["IN PROGRESS"] if in_prog else [],
            file_path=rel,
            file_size=meta.get("file_size"),
            file_mtime=meta.get("file_mtime"),
        )

    out: list[Task] = []
    # The Plan phase produces several artifacts, all under the feature dir.
    # Editing any of them keeps the Plan card in_progress.
    plan_extras = ["data-model.md", "quickstart.md", "contracts/"]
    feat_files = [
        ("Φ-RESEARCH", "Tech research",       feature.dir / "research.md", ["research.md"]),
        ("Φ-SPEC",     "Spec",                feature.dir / "spec.md",     ["spec.md"]),
        ("Φ-PLAN",     "Plan",                feature.dir / "plan.md",     ["plan.md"] + plan_extras),
        ("Φ-TASKS",    "Tasks decomposition", feature.dir / "tasks.md",    ["tasks.md"]),
    ]
    for tid, title, ap, alt_files in feat_files:
        rel = str(ap.relative_to(paths.root))
        if tid == "Φ-RESEARCH" and not ap.exists():
            continue
        # Match any of the alt_files (substring against the active file).
        done, in_prog = status_for_paths(alt_files, ap)
        if tid == "Φ-TASKS":
            done = bool(feature.tasks)
            in_prog = (not done) and active_file is not None and rel in active_file
        out.append(_make(tid, title, ap, rel, done, in_prog))
    return out


def synthetic_phase_tasks(
    paths: ProjectPaths,
    state: "ProjectState",
    session_files: list[str] | None = None,
) -> list[Task]:
    """Tasks that represent the workflow's pre-implement phases.

    Always show: Constitution. If a feature directory exists: Research, Spec,
    Plan, Tasks-decomposition. Status:
      - done       : the file has substantive content.
      - in_progress: the file is in `session_files` (i.e. the agent edited it
                     in the last turn) AND not yet done.
      - pending    : neither.
    """
    active_file = _last_active_file(session_files or [])

    def status_for(rel_path: str, abs_path: Path) -> tuple[bool, bool]:
        # Only the single most-recent non-FACT-meta file is "currently
        # being edited" — see _last_active_file for the filter logic.
        in_prog = active_file is not None and (rel_path in active_file or str(abs_path) in active_file)
        done = (not in_prog) and _has_substantive_content(abs_path)
        return done, in_prog

    out: list[Task] = []

    def _make(tid: str, title: str, ap: Path, rel: str, done: bool, in_prog: bool) -> Task:
        meta = _file_meta(ap)
        return Task(
            id=tid,
            title=title,
            done=done,
            raw_line="",
            description=PHASE_DESCRIPTIONS.get(tid, ""),
            files=[rel] if ap.exists() else [],
            tags=["IN PROGRESS"] if in_prog else [],
            file_path=rel,
            file_size=meta.get("file_size"),
            file_mtime=meta.get("file_mtime"),
        )

    # Constitution — always shown.
    rel = str(paths.constitution.relative_to(paths.root))
    done, in_prog = status_for(rel, paths.constitution)
    out.append(_make("Φ-CONST", "Constitution", paths.constitution, rel, done, in_prog))

    # Phase tasks tied to the active feature.
    feat = state.active_feature
    if feat is None:
        return out

    feat_files = [
        ("Φ-RESEARCH", "Research",            feat.dir / "research.md"),
        ("Φ-SPEC",     "Spec",                feat.dir / "spec.md"),
        ("Φ-PLAN",     "Plan",                feat.dir / "plan.md"),
        ("Φ-TASKS",    "Tasks decomposition", feat.dir / "tasks.md"),
    ]
    for tid, title, ap in feat_files:
        rel = str(ap.relative_to(paths.root))
        if tid == "Φ-RESEARCH" and not ap.exists():
            continue
        done, in_prog = status_for(rel, ap)
        if tid == "Φ-TASKS":
            done = bool(feat.tasks)
            in_prog = (not done) and active_file is not None and rel in active_file
        out.append(_make(tid, title, ap, rel, done, in_prog))
    return out


def _slugify(text: str) -> str:
    s = re.sub(r"[^\w\s-]", "", text.lower())
    s = re.sub(r"[\s_-]+", "-", s).strip("-")
    return s or "section"


_US_HEADING_RE = re.compile(
    # Matches: ### User Story 1 — title (Priority: P1)
    r"^#{2,4}\s*User\s+Story\s+(?P<n>\d+)\s*[—\-:]\s*"
    r"(?P<title>.+?)"
    r"(?:\s*\(Priority:\s*(?P<priority>P\d+)\))?\s*$",
    re.IGNORECASE | re.MULTILINE,
)


def parse_user_stories(spec_md: Path) -> dict[int, UserStory]:
    """Extract `### User Story N — <title> (Priority: PN)` from spec.md."""
    if not spec_md.exists():
        return {}
    out: dict[int, UserStory] = {}
    for m in _US_HEADING_RE.finditer(spec_md.read_text(encoding="utf-8", errors="ignore")):
        n = int(m.group("n"))
        out[n] = UserStory(
            number=n,
            title=m.group("title").strip().rstrip("."),
            priority=(m.group("priority") or "").strip(),
        )
    return out


_TASKS_SECTION_US_RE = re.compile(
    r"[Uu]ser\s+[Ss]tory\s+(\d+)",
)


def build_stories(
    paths: ProjectPaths,
    project: "ProjectState",
    session_files: list[str] | None = None,
) -> list[Story]:
    """Group tasks into stories — what the dashboard renders as cards."""
    stories: list[Story] = []

    # Project-level foundation: Constitution + (Research, brownfield only).
    foundation = project_phase_tasks(paths, session_files)
    stories.append(Story(
        id=":foundation",
        title="Project foundation",
        kind="foundation",
        feature_slug=None,
        tasks=foundation,
    ))

    for feature in project.features:
        # `_root` is a legacy slug from older fact-research instructions that
        # told the agent to write research to .specify/specs/_root/. We now
        # treat that file as project-level research (Foundation card). Skip
        # the synthetic feature so it doesn't pollute the kanban.
        if feature.slug == "_root":
            continue
        # Workflow story per feature: Spec, Plan, Research (if present), Tasks decomp.
        phase = feature_phase_tasks(paths, feature, session_files)
        if phase:
            stories.append(Story(
                id=f"{feature.slug}:workflow",
                title=f"Workflow — {feature.slug}",
                kind="workflow",
                feature_slug=feature.slug,
                tasks=phase,
            ))

        # Pull user-story descriptions from spec.md (if present), so a section
        # like "Implementation for User Story 1" becomes
        # "User Story 1 — Vista de quién está en qué".
        us_index = parse_user_stories(feature.dir / "spec.md")

        # Real tasks grouped by section. Preserve order of first appearance.
        groups: dict[str, list[Task]] = {}
        order: list[str] = []
        for t in feature.tasks:
            key = t.section or "Uncategorized"
            if key not in groups:
                groups[key] = []
                order.append(key)
            groups[key].append(t)

        for sec in order:
            us_match = _TASKS_SECTION_US_RE.search(sec)
            if us_match:
                n = int(us_match.group(1))
                us = us_index.get(n)
                if us:
                    title = f"User Story {n} — {us.title}"
                    priority = us.priority
                else:
                    title = f"User Story {n}"
                    priority = ""
                stories.append(Story(
                    id=f"{feature.slug}:us-{n}",
                    title=title,
                    kind="user_story",
                    feature_slug=feature.slug,
                    tasks=groups[sec],
                    priority=priority,
                    user_story_number=n,
                ))
            else:
                stories.append(Story(
                    id=f"{feature.slug}:{_slugify(sec)}",
                    title=sec,
                    kind="phase",
                    feature_slug=feature.slug,
                    tasks=groups[sec],
                ))

    return stories


def read_project_state(paths: ProjectPaths) -> ProjectState:
    has_constitution = paths.constitution.exists()
    features = read_features(paths)
    # Active feature: the one with the most progress that isn't fully done.
    active: FeatureState | None = None
    for f in features:
        if active is None:
            active = f
            continue
        if f.total_tasks > 0 and f.done_tasks < f.total_tasks:
            if active.done_tasks >= active.total_tasks > 0:
                active = f
            elif f.has_tasks and not active.has_tasks:
                active = f
    if active is None and features:
        active = features[-1]
    phase = derive_phase(active, has_constitution)
    return ProjectState(
        has_constitution=has_constitution,
        features=features,
        current_phase=phase,
        active_feature=active,
    )
