"""Wrappers around the external `specify` CLI.

FACT delegates to Spec Kit; it never reimplements its commands. We try to
install `specify-cli` automatically (via uv > pipx > pip --user). If that
fails we degrade gracefully — `fact doctor` will tell the user how to fix it.
"""

from __future__ import annotations

import os
import shutil
import subprocess
from dataclasses import dataclass
from pathlib import Path


@dataclass
class SpecifyAvailability:
    installed: bool
    version: str | None = None


def _utf8_env() -> dict[str, str]:
    """Subprocess env that forces UTF-8 stdio on the child Python.

    On Windows, a child Python process whose stdout is captured uses the
    system codec (cp1252 in es-AR/en-US locales) to encode prints. Programs
    that print emoji or non-Latin-1 characters crash with UnicodeEncodeError.
    PYTHONUTF8=1 (PEP 540) and PYTHONIOENCODING=utf-8 force UTF-8 regardless.
    """
    env = os.environ.copy()
    env["PYTHONUTF8"] = "1"
    env["PYTHONIOENCODING"] = "utf-8"
    return env


def specify_available() -> SpecifyAvailability:
    if shutil.which("specify") is None:
        return SpecifyAvailability(False)
    try:
        out = subprocess.run(
            ["specify", "--version"],
            capture_output=True,
            text=True,
            encoding="utf-8",
            errors="replace",
            timeout=5,
            check=False,
            env=_utf8_env(),
        )
        return SpecifyAvailability(True, out.stdout.strip() or None)
    except Exception:
        return SpecifyAvailability(True, None)


def init_in(project_root: Path) -> tuple[bool, str]:
    """Run `specify init --here --integration claude --force` if available.

    Idempotent: --force skips the "directory not empty" prompt, --no-git keeps
    git state under the user's control (we don't create or rewrite repos).

    Returns (ok, error). When ok is False, error contains the tail of the last
    subprocess's stderr/stdout so the caller can surface it to the user.
    """
    if not specify_available().installed:
        return False, "specify CLI not installed"
    candidates = [
        ["specify", "init", "--here", "--integration", "claude", "--force", "--no-git", "--ignore-agent-tools"],
        ["specify", "init", "--here", "--integration", "claude", "--force", "--no-git"],
        ["specify", "init", ".", "--integration", "claude", "--force", "--no-git"],
        ["specify", "init", "--here"],
    ]
    last_err = ""
    for cmd in candidates:
        try:
            r = subprocess.run(
                cmd,
                cwd=project_root,
                capture_output=True,
                text=True,
                encoding="utf-8",
                errors="replace",
                timeout=180,
                input="",  # decline any interactive prompt
                env=_utf8_env(),
            )
            if r.returncode == 0:
                return True, ""
            last_err = (r.stderr or r.stdout).strip()[-400:]
        except Exception as e:
            last_err = f"{type(e).__name__}: {e}"
    return False, last_err


def install_extension(name: str, project_root: Path) -> bool:
    if not specify_available().installed:
        return False
    try:
        r = subprocess.run(
            ["specify", "extension", "add", name],
            cwd=project_root,
            capture_output=True,
            text=True,
            encoding="utf-8",
            errors="replace",
            timeout=120,
            env=_utf8_env(),
        )
        return r.returncode == 0
    except Exception:
        return False


RECOMMENDED_EXTENSIONS = (
    "spec-kit-worktree-parallel",
    "spec-kit-verify-tasks",
    "spec-kit-tinyspec",
    "spec-kit-brownfield",
)


@dataclass
class InstallResult:
    ok: bool
    method: str  # "already-installed" | "uv" | "pipx" | "pip-user" | "failed"
    message: str = ""


def _run(cmd: list[str], timeout: int = 300) -> tuple[int, str]:
    try:
        r = subprocess.run(
            cmd,
            capture_output=True,
            text=True,
            encoding="utf-8",
            errors="replace",
            timeout=timeout,
            env=_utf8_env(),
        )
        return r.returncode, (r.stdout + r.stderr).strip()
    except FileNotFoundError as e:
        return 127, str(e)
    except subprocess.TimeoutExpired:
        return 124, "timeout"


def _refresh_path_with_user_bins() -> None:
    """Add common user-bin dirs that uv/pipx use, so `which specify` finds it
    in the same process after an install."""
    extra = [
        os.path.expanduser("~/.local/bin"),
        os.path.expanduser("~/.cargo/bin"),
        "/opt/homebrew/bin",
    ]
    cur = os.environ.get("PATH", "")
    parts = cur.split(os.pathsep)
    for p in extra:
        if p and p not in parts and Path(p).exists():
            parts.insert(0, p)
    os.environ["PATH"] = os.pathsep.join(parts)


def ensure_installed() -> InstallResult:
    """Make sure `specify` is on PATH. Tries uv → pipx → pip --user."""
    _refresh_path_with_user_bins()
    if specify_available().installed:
        return InstallResult(True, "already-installed", "specify already on PATH")

    if shutil.which("uv"):
        rc, out = _run(["uv", "tool", "install", "specify-cli", "--from", "git+https://github.com/github/spec-kit.git"])
        _refresh_path_with_user_bins()
        if rc == 0 and specify_available().installed:
            return InstallResult(True, "uv", "installed via uv tool install")
        # Some users have specify-cli on PyPI; fall through with the error.
        last = out

    if shutil.which("pipx"):
        rc, out = _run(["pipx", "install", "git+https://github.com/github/spec-kit.git"])
        _refresh_path_with_user_bins()
        if rc == 0 and specify_available().installed:
            return InstallResult(True, "pipx", "installed via pipx")
        last = out

    # Last resort: pip --user
    rc, out = _run(["python3", "-m", "pip", "install", "--user", "git+https://github.com/github/spec-kit.git"])
    _refresh_path_with_user_bins()
    if rc == 0 and specify_available().installed:
        return InstallResult(True, "pip-user", "installed via pip --user")

    return InstallResult(
        False,
        "failed",
        "could not install specify-cli automatically. "
        "Install manually: `uv tool install --from git+https://github.com/github/spec-kit.git specify-cli`",
    )
