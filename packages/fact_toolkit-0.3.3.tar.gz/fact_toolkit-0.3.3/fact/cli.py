"""FACT CLI entry point. `fact init`, `fact dashboard`, `fact stop`, `fact doctor`, `fact upgrade`."""

from __future__ import annotations

import json
import shutil
import subprocess
import sys
import webbrowser
from pathlib import Path
from typing import Optional

import typer
from rich.console import Console
from rich.panel import Panel
from rich.table import Table

from fact import __version__, data, dashboard_proc, speckit
from fact.agents import get_adapter
from fact.paths import ProjectPaths


app = typer.Typer(
    name="fact",
    help="FACT — Focused Agentic Context Toolkit. Spec Kit + RPI for Claude Code.",
    no_args_is_help=True,
    add_completion=False,
)
console = Console()


DEFAULT_PORT = 7842


def _project_paths(target: Path | None = None) -> ProjectPaths:
    return ProjectPaths(target or Path.cwd())


def _read_config(paths: ProjectPaths) -> dict:
    if paths.config_file.exists():
        try:
            return json.loads(paths.config_file.read_text(encoding="utf-8"))
        except json.JSONDecodeError:
            return {}
    return {}


def _write_config(paths: ProjectPaths, cfg: dict) -> None:
    paths.fact_dir.mkdir(parents=True, exist_ok=True)
    paths.config_file.write_text(json.dumps(cfg, indent=2) + "\n", encoding="utf-8")


# ---- init ------------------------------------------------------------------


@app.command()
def init(
    path: Optional[Path] = typer.Argument(None, help="Project root (defaults to cwd)."),
    port: int = typer.Option(DEFAULT_PORT, help="Dashboard port."),
    no_browser: bool = typer.Option(False, help="Don't open browser after init."),
    no_dashboard: bool = typer.Option(False, help="Skip starting the dashboard."),
    no_speckit: bool = typer.Option(False, help="Skip auto-installing specify-cli."),
    force: bool = typer.Option(False, "--force", help="Overwrite CLAUDE.md if it exists."),
) -> None:
    """Set up FACT in the current project. Idempotent."""
    paths = _project_paths(path)
    paths.ensure_dirs()

    console.print(Panel.fit(f"[bold]FACT v{__version__}[/]  •  setup", border_style="cyan"))

    # Step 1: project root sanity
    if not (paths.root / ".git").exists():
        console.print(
            "[yellow]No .git/ detected — proceeding anyway. Run 'git init' if this is a new project.[/]"
        )

    # Step 2: agent detection
    adapter = get_adapter("claude-code")
    if not adapter.detect():
        console.print(
            "[red]Claude Code is not installed.[/] Install from https://claude.com/claude-code, then re-run."
        )
        raise typer.Exit(1)
    console.print("[green]✓[/] Claude Code detected")

    # Step 3: ensure Spec Kit is installed
    avail = speckit.specify_available()
    if not avail.installed and not no_speckit:
        console.print("• Installing [cyan]specify-cli[/] (Spec Kit) …")
        result = speckit.ensure_installed()
        if result.ok:
            console.print(f"[green]✓[/] Spec Kit installed ({result.method})")
            avail = speckit.specify_available()
        else:
            console.print(f"[yellow]⚠[/] {result.message}")
    elif avail.installed:
        console.print(f"[green]✓[/] Spec Kit available ({avail.version or 'version unknown'})")

    # Step 4: Spec Kit init
    if avail.installed:
        if not paths.specify_dir.exists() or not paths.constitution.exists():
            console.print("• Running [cyan]specify init[/] …")
            ok, err = speckit.init_in(paths.root)
            if ok:
                console.print("[green]✓[/] Spec Kit initialized")
            else:
                console.print("[yellow]⚠[/] specify init failed; continuing with stubs")
                if err:
                    console.print(f"[dim]  └ {err}[/]")
        else:
            console.print("[green]✓[/] Spec Kit already initialized")
    else:
        # Stub minimal structure so FACT still works without speckit
        if not paths.constitution.exists():
            paths.constitution.write_text(
                "# Constitution\n\n_Pending — run `/speckit.constitution` once `specify` is installed._\n",
                encoding="utf-8",
            )

    paths.ensure_dirs()

    # Step 5: extensions (best-effort)
    if avail.installed:
        for ext in speckit.RECOMMENDED_EXTENSIONS:
            ok = speckit.install_extension(ext, paths.root)
            mark = "[green]✓[/]" if ok else "[dim]·[/]"
            console.print(f"  {mark} extension {ext}")

    # Step 6: skills
    skills = adapter.install_skills(data.skills_dir(), paths.skills_dir)
    console.print(f"[green]✓[/] Skills installed: {', '.join(skills)}")

    # Step 6: slash commands
    cmds = adapter.install_commands(data.commands_dir(), paths.commands_dir)
    console.print(f"[green]✓[/] Commands installed: {', '.join('/' + c for c in cmds)}")

    # Step 7: hook scripts and settings.json wiring
    _install_hook_scripts(paths)
    adapter.install_hooks(paths.hooks_dir, dashboard_url=f"http://127.0.0.1:{port}")
    console.print("[green]✓[/] Hooks configured")

    # Step 8: CLAUDE.md
    if not paths.claude_md.exists() or force:
        paths.claude_md.write_text(_claude_md_template(paths.root.name), encoding="utf-8")
        console.print(f"[green]✓[/] CLAUDE.md {'rewritten' if force else 'created'}")
    else:
        console.print("[dim]·[/] CLAUDE.md already exists (use --force to overwrite)")

    # Step 9: config.json
    cfg = _read_config(paths)
    cfg.setdefault("version", __version__)
    cfg.setdefault("dashboard", {"host": "127.0.0.1", "port": port})
    cfg["dashboard"]["port"] = port
    cfg.setdefault("agent", "claude-code")
    _write_config(paths, cfg)

    # Step 10: dashboard
    if not no_dashboard:
        if dashboard_proc.is_running(paths):
            console.print(f"[dim]·[/] Dashboard already running on port {cfg['dashboard']['port']}")
        else:
            console.print(f"• Starting dashboard on port {port} …")
            dashboard_proc.start(paths, port=port)
        url = f"http://127.0.0.1:{port}"
        console.print(f"[green]✓[/] Dashboard at [link={url}]{url}[/link]")
        if not no_browser:
            webbrowser.open(url)

    console.print()
    console.print(
        Panel.fit(
            "[bold]Next:[/] open Claude Code in this directory and run [cyan]/fact-start[/]\n\n"
            "  $ claude\n  > /fact-start",
            border_style="green",
        )
    )


# ---- dashboard / stop ------------------------------------------------------


@app.command()
def dashboard(
    restart: bool = typer.Option(False, "--restart", help="Force restart."),
    no_browser: bool = typer.Option(False, "--no-browser"),
) -> None:
    """Start the dashboard server (idempotent)."""
    paths = _project_paths()
    if not paths.fact_dir.exists():
        console.print("[red]This directory isn't FACT-initialized. Run `fact init` first.[/]")
        raise typer.Exit(1)
    cfg = _read_config(paths)
    port = cfg.get("dashboard", {}).get("port", DEFAULT_PORT)

    if restart:
        dashboard_proc.stop(paths)

    pid = dashboard_proc.is_running(paths)
    if pid:
        console.print(f"[green]✓[/] Already running (pid {pid}) on port {port}")
    else:
        console.print(f"• Starting dashboard on port {port} …")
        dashboard_proc.start(paths, port=port)
        console.print(f"[green]✓[/] Dashboard up on port {port}")
    url = f"http://127.0.0.1:{port}"
    if not no_browser:
        webbrowser.open(url)
    console.print(f"[link={url}]{url}[/link]")


@app.command()
def stop() -> None:
    """Stop the dashboard server."""
    paths = _project_paths()
    if dashboard_proc.stop(paths):
        console.print("[green]✓[/] Dashboard stopped")
    else:
        console.print("[dim]·[/] Dashboard wasn't running")


# ---- doctor ----------------------------------------------------------------


@app.command()
def doctor(
    fix: bool = typer.Option(False, "--fix", help="Try to install anything missing (currently: specify-cli)."),
) -> None:
    """Diagnose the FACT setup."""
    if fix:
        avail = speckit.specify_available()
        if not avail.installed:
            console.print("• Installing [cyan]specify-cli[/] …")
            r = speckit.ensure_installed()
            console.print(("[green]✓[/] " if r.ok else "[red]✗[/] ") + r.message)
    paths = _project_paths()
    table = Table(show_header=True, header_style="bold")
    table.add_column("Check")
    table.add_column("Status")
    table.add_column("Detail")

    adapter = get_adapter("claude-code")
    table.add_row("Claude Code", _ok(adapter.detect()), "claude on PATH" if adapter.detect() else "missing")

    avail = speckit.specify_available()
    table.add_row("specify CLI", _ok(avail.installed), avail.version or ("install with uv tool install specify-cli" if not avail.installed else ""))

    table.add_row(".specify/", _ok(paths.specify_dir.exists()), str(paths.specify_dir))
    table.add_row(".specify/fact/", _ok(paths.fact_dir.exists()), str(paths.fact_dir))
    table.add_row(".claude/skills/", _ok(paths.skills_dir.exists()), str(paths.skills_dir))
    table.add_row(".claude/commands/", _ok(paths.commands_dir.exists()), str(paths.commands_dir))
    table.add_row(".claude/hooks/", _ok(paths.hooks_dir.exists()), str(paths.hooks_dir))
    table.add_row("CLAUDE.md", _ok(paths.claude_md.exists()), str(paths.claude_md))

    cfg = _read_config(paths)
    port = cfg.get("dashboard", {}).get("port", DEFAULT_PORT)
    pid = dashboard_proc.is_running(paths)
    if pid and dashboard_proc.ping("127.0.0.1", port):
        table.add_row("Dashboard", _ok(True), f"pid {pid} on port {port}")
    else:
        table.add_row("Dashboard", _ok(False), "not running (run `fact dashboard`)")

    skills_present = sorted(p.name for p in paths.skills_dir.glob("*") if (p / "SKILL.md").exists()) if paths.skills_dir.exists() else []
    table.add_row("Skills installed", str(len(skills_present)), ", ".join(skills_present) or "none")

    console.print(table)


# ---- upgrade ---------------------------------------------------------------


@app.command()
def upgrade() -> None:
    """Re-copy FACT's bundled skills and commands into the project."""
    paths = _project_paths()
    if not paths.fact_dir.exists():
        console.print("[red]Run `fact init` first.[/]")
        raise typer.Exit(1)
    adapter = get_adapter("claude-code")

    # Only refresh FACT's own skills (the ones bundled with this release).
    # Externally-installed skills are left untouched.
    fact_skill_names = {p.name for p in data.skills_dir().iterdir() if p.is_dir()}
    for name in fact_skill_names:
        src = data.skills_dir() / name
        dest = paths.skills_dir / name
        if dest.exists():
            shutil.rmtree(dest)
        shutil.copytree(src, dest)
    console.print(f"[green]✓[/] Refreshed {len(fact_skill_names)} FACT skills")

    cmds = adapter.install_commands(data.commands_dir(), paths.commands_dir)
    console.print(f"[green]✓[/] Refreshed commands: {', '.join('/' + c for c in cmds)}")

    _install_hook_scripts(paths)
    cfg = _read_config(paths)
    port = cfg.get("dashboard", {}).get("port", DEFAULT_PORT)
    adapter.install_hooks(paths.hooks_dir, dashboard_url=f"http://127.0.0.1:{port}")
    console.print("[green]✓[/] Hooks refreshed")


# ---- helpers ---------------------------------------------------------------


def _install_hook_scripts(paths: ProjectPaths) -> None:
    src = data.hooks_dir()
    paths.hooks_dir.mkdir(parents=True, exist_ok=True)
    # Hook helpers are pure-Python — no bash shim. Claude Code calls these
    # directly via `sys.executable` (see ClaudeCodeAdapter.install_hooks).
    for helper in (
        "fact_hook.py",
        "fact_audit.py",
        "fact_audit_stop.py",
        "fact_compact.py",
        "fact_compact_progress.py",
        "fact_session_resume.py",
    ):
        helper_src = src / helper
        if helper_src.exists():
            shutil.copy2(helper_src, paths.hooks_dir / helper)
    # Sweep any legacy bash wrappers from a previous FACT install. settings.json
    # no longer references them; leaving them on disk would just be noise.
    for stale in paths.hooks_dir.glob("*.sh"):
        stale.unlink()


def _claude_md_template(name: str) -> str:
    return f"""# Project: {name}

This project uses **FACT** (Focused Agentic Context Toolkit).

## On every new session — load this BEFORE responding

If `.specify/fact/sessions/` contains any file, this is a **resumed**
project. Before answering the user's first message, even if it's just
"hola" or "continuar":

1. Load the `fact-onboarding` skill (read `.claude/skills/fact-onboarding/SKILL.md`).
2. Load the `fact-rpi-harness` skill (always-on rules).
3. Follow `fact-onboarding §1` — read `.specify/fact/session_state.json`
   and the most recent `.specify/fact/sessions/*.md`.
4. Present a one-paragraph continuity message to the user (per `§3 Resume protocol`)
   and ask whether to continue from where they were, instead of generic
   "how can I help you?".

If `.specify/fact/sessions/` is empty (new project), still load both
skills and follow `fact-onboarding §2` (ask greenfield / brownfield / demo).

## Slash commands

  /fact-start    (first time — picks workflow type and starts)
  /fact-next     (continue the current phase)
  /fact-status   (quick status report)
  /fact-audit    (security / architecture / quality on demand)

## Non-negotiable rules

- Respect the 40% smart-zone (see `fact-rpi-harness`).
- Compactation at natural seams: closures, phase transitions, ≥60% of
  context window. The hooks fire prompts; you respond by writing the
  summary and recommending `/compact`.
- Use sub-agents to fork context — and **always pass `model="haiku"` or
  `model="sonnet"` explicitly** when invoking the Agent tool, otherwise
  sub-agents inherit Opus and the cost discipline collapses.
- The human reviews research and plan before implement.
- FACT's layout (`.specify/specs/`, `.specify/memory/`, `.specify/fact/`)
  is canonical. Do not write features under a project-root `specs/`
  directory even if a legacy `AGENTS.md` says so.
"""


def _ok(b: bool) -> str:
    return "[green]✓[/]" if b else "[red]✗[/]"


if __name__ == "__main__":
    app()
