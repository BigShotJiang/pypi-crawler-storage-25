"""FACT — Focused Agentic Context Toolkit."""

from importlib.metadata import PackageNotFoundError, version as _pkg_version

try:
    __version__ = _pkg_version("fact-toolkit")
except PackageNotFoundError:
    # editable install before metadata is generated
    __version__ = "0.0.0+local"
