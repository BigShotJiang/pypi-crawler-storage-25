"""Token cost calculation. Loads pricing.json once and caches."""

from __future__ import annotations

import json
from dataclasses import dataclass
from functools import lru_cache
from pathlib import Path


@dataclass
class CostBreakdown:
    cost_usd: float
    is_complete: bool  # False when the model wasn't in pricing.json


@lru_cache(maxsize=1)
def _load_default() -> dict:
    pkg_pricing = Path(__file__).parent / "_data" / "pricing.json"
    repo_pricing = Path(__file__).parent.parent / "pricing.json"
    src = pkg_pricing if pkg_pricing.exists() else repo_pricing
    return json.loads(src.read_text(encoding="utf-8"))


def load_pricing(path: Path | None = None) -> dict:
    if path is None:
        return _load_default()
    return json.loads(Path(path).read_text(encoding="utf-8"))


def _resolve_rates(model: str | None, pricing: dict) -> dict | None:
    """Find pricing entry for a model id. Falls back to stripping a date
    suffix like '-20251001' so 'claude-haiku-4-5-20251001' matches the
    canonical 'claude-haiku-4-5' entry."""
    if not model:
        return None
    models = pricing.get("models", {})
    if model in models:
        return models[model]
    import re
    stripped = re.sub(r"-\d{8}$", "", model)
    if stripped != model and stripped in models:
        return models[stripped]
    return None


def cost_of_event(event: dict, pricing: dict | None = None) -> CostBreakdown:
    pricing = pricing or load_pricing()
    model = event.get("model")
    rates = _resolve_rates(model, pricing)
    if not rates:
        return CostBreakdown(0.0, is_complete=False)
    cost = (
        event.get("input_tokens", 0) * rates["input_per_million"] / 1_000_000
        + event.get("output_tokens", 0) * rates["output_per_million"] / 1_000_000
        + event.get("cache_read_tokens", 0) * rates.get("cache_read_per_million", 0) / 1_000_000
    )
    return CostBreakdown(cost, is_complete=True)


def counterfactual_opus_cost(events: list[dict], pricing: dict | None = None) -> float:
    """What the workload *would* have cost if every token were Opus."""
    pricing = pricing or load_pricing()
    opus = next(
        (m for m, info in pricing["models"].items() if info.get("tier") == "opus"),
        None,
    )
    if opus is None:
        return 0.0
    rates = pricing["models"][opus]
    total = 0.0
    for e in events:
        total += (
            e.get("input_tokens", 0) * rates["input_per_million"] / 1_000_000
            + e.get("output_tokens", 0) * rates["output_per_million"] / 1_000_000
            + e.get("cache_read_tokens", 0) * rates.get("cache_read_per_million", 0) / 1_000_000
        )
    return total
