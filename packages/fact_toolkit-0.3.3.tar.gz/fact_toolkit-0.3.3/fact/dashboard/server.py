"""FastAPI dashboard server.

Single-page app:
- GET /            — HTML dashboard.
- GET /healthz     — liveness probe.
- GET /api/state   — current snapshot.
- GET /api/file?p= — render a markdown file (whitelisted to project root).
- POST /event      — hook ingestion from Claude Code.
- WS  /ws          — push updates on file change or new event.

Watches `.specify/`, `.claude/skills/`, and `events.jsonl` via watchdog.
"""

from __future__ import annotations

import asyncio
import json
import os
from contextlib import asynccontextmanager
from pathlib import Path

from fastapi import FastAPI, Request, WebSocket, WebSocketDisconnect
from fastapi.responses import HTMLResponse, JSONResponse, PlainTextResponse
from fastapi.staticfiles import StaticFiles
from starlette.types import Scope
from jinja2 import Environment, FileSystemLoader, select_autoescape
from markdown_it import MarkdownIt
from watchdog.events import FileSystemEvent, FileSystemEventHandler
from watchdog.observers import Observer

from fact import data
from fact.dashboard.state import build_snapshot
from fact.dashboard.tree import IGNORED_DIRS
from fact.paths import ProjectPaths


PROJECT_ROOT = Path(os.environ.get("FACT_PROJECT_ROOT", os.getcwd())).resolve()
HOST = os.environ.get("FACT_DASHBOARD_HOST", "127.0.0.1")
PORT = int(os.environ.get("FACT_DASHBOARD_PORT", "7842"))
PATHS = ProjectPaths(PROJECT_ROOT)


# ---- Connection manager ----------------------------------------------------


class WSManager:
    def __init__(self) -> None:
        self.connections: set[WebSocket] = set()
        self._lock = asyncio.Lock()

    async def connect(self, ws: WebSocket) -> None:
        await ws.accept()
        async with self._lock:
            self.connections.add(ws)

    async def disconnect(self, ws: WebSocket) -> None:
        async with self._lock:
            self.connections.discard(ws)

    async def broadcast(self, payload: dict) -> None:
        msg = json.dumps(payload)
        async with self._lock:
            stale: list[WebSocket] = []
            for ws in self.connections:
                try:
                    await ws.send_text(msg)
                except Exception:
                    stale.append(ws)
            for ws in stale:
                self.connections.discard(ws)


manager = WSManager()


# ---- Watchdog --------------------------------------------------------------


class _Coalescer(FileSystemEventHandler):
    """Coalesces bursts of FS events into one snapshot push.

    Triggers on:
      - any change inside .specify/ or .claude/skills (state, sessions, skills),
      - any .md / .markdown file change anywhere in the project,
      - the events.jsonl file.
    """

    def __init__(self, loop: asyncio.AbstractEventLoop) -> None:
        self.loop = loop
        self._scheduled = False

    def _should_fire(self, path: str) -> bool:
        # Quick exclusions for noisy paths.
        for ignored in IGNORED_DIRS:
            if f"{os.sep}{ignored}{os.sep}" in path or path.endswith(f"{os.sep}{ignored}"):
                return False
        if path.endswith(".egg-info") or f".egg-info{os.sep}" in path:
            return False
        # Always fire for FACT operational state.
        if (
            f"{os.sep}.specify{os.sep}" in path
            or f"{os.sep}.claude{os.sep}skills" in path
            or path.endswith("events.jsonl")
            or path.endswith("session_state.json")
        ):
            return True
        # Fire for any .md file change in the project.
        if path.lower().endswith((".md", ".markdown")):
            return True
        return False

    def on_any_event(self, event: FileSystemEvent) -> None:
        if not self._should_fire(event.src_path):
            return
        if self._scheduled:
            return
        self._scheduled = True
        self.loop.call_soon_threadsafe(asyncio.create_task, self._fire_after_delay())

    async def _fire_after_delay(self) -> None:
        try:
            await asyncio.sleep(0.15)
            snap = build_snapshot(PATHS)
            await manager.broadcast({"kind": "snapshot", "data": snap})
        finally:
            self._scheduled = False


_observer: Observer | None = None


def _start_watcher(loop: asyncio.AbstractEventLoop) -> None:
    """Watch the project root recursively, except for ignored dirs.

    We schedule a recursive watch on each non-ignored top-level dir, plus the
    project root non-recursively (so root-level CLAUDE.md / README.md changes
    fire). This keeps watchdog out of node_modules / .venv / .git.
    """
    global _observer
    handler = _Coalescer(loop)
    obs = Observer()

    if PATHS.root.exists():
        obs.schedule(handler, str(PATHS.root), recursive=False)
        try:
            for entry in PATHS.root.iterdir():
                if not entry.is_dir():
                    continue
                if entry.name in IGNORED_DIRS or entry.name.endswith(".egg-info"):
                    continue
                obs.schedule(handler, str(entry), recursive=True)
        except (PermissionError, OSError):
            pass

    obs.daemon = True
    obs.start()
    _observer = obs


def _stop_watcher() -> None:
    global _observer
    if _observer is not None:
        _observer.stop()
        _observer.join(timeout=1.0)
        _observer = None


# ---- App -------------------------------------------------------------------


@asynccontextmanager
async def lifespan(app: FastAPI):
    loop = asyncio.get_running_loop()
    _start_watcher(loop)
    try:
        yield
    finally:
        _stop_watcher()


app = FastAPI(title="FACT Dashboard", lifespan=lifespan)

_templates_dir = data.dashboard_templates_dir()
_static_dir = data.dashboard_static_dir()
_jinja = Environment(
    loader=FileSystemLoader(str(_templates_dir)),
    autoescape=select_autoescape(["html", "xml"]),
)
_md = MarkdownIt("commonmark", {"html": False, "linkify": True, "breaks": False}).enable("table")

class _NoCacheStatic(StaticFiles):
    """Serve static assets with Cache-Control: no-store so browsers always
    fetch the latest dashboard.js / dashboard.css after the server restarts."""

    async def get_response(self, path: str, scope: Scope):
        response = await super().get_response(path, scope)
        response.headers["Cache-Control"] = "no-store, no-cache, must-revalidate, max-age=0"
        response.headers["Pragma"] = "no-cache"
        response.headers["Expires"] = "0"
        return response


app.mount("/static", _NoCacheStatic(directory=str(_static_dir)), name="static")


@app.get("/healthz")
async def healthz() -> PlainTextResponse:
    return PlainTextResponse("ok")


_BOOT_TOKEN = str(int(__import__("time").time()))


@app.get("/", response_class=HTMLResponse)
async def index() -> HTMLResponse:
    tmpl = _jinja.get_template("index.html")
    return HTMLResponse(
        tmpl.render(project_name=PATHS.root.name, port=PORT, asset_v=_BOOT_TOKEN)
    )


@app.get("/api/state")
async def api_state() -> JSONResponse:
    return JSONResponse(build_snapshot(PATHS))


@app.get("/api/file")
async def api_file(p: str) -> JSONResponse:
    """Render a markdown or text file inside the project root."""
    target = (PATHS.root / p).resolve()
    if not _is_within(target, PATHS.root):
        return JSONResponse({"error": "outside project root"}, status_code=400)
    if not target.exists() or not target.is_file():
        return JSONResponse({"error": "not found", "path": p}, status_code=404)
    text = target.read_text(encoding="utf-8", errors="replace")
    if target.suffix.lower() in (".md", ".markdown"):
        html = _md.render(text)
    else:
        html = f"<pre><code>{_html_escape(text)}</code></pre>"
    return JSONResponse({"path": p, "html": html, "raw": text})


@app.post("/event")
async def post_event(request: Request) -> JSONResponse:
    try:
        payload = await request.json()
    except Exception:
        body = await request.body()
        payload = {"_unparsed": body.decode("utf-8", errors="replace")}

    PATHS.fact_dir.mkdir(parents=True, exist_ok=True)
    with PATHS.events_file.open("a") as f:
        f.write(json.dumps(payload) + "\n")

    snap = build_snapshot(PATHS)
    await manager.broadcast({"kind": "snapshot", "data": snap})
    return JSONResponse({"ok": True})


@app.websocket("/ws")
async def ws_endpoint(ws: WebSocket) -> None:
    await manager.connect(ws)
    try:
        await ws.send_text(json.dumps({"kind": "snapshot", "data": build_snapshot(PATHS)}))
        while True:
            # We don't expect client messages, but draining keeps the socket alive.
            await ws.receive_text()
    except WebSocketDisconnect:
        pass
    finally:
        await manager.disconnect(ws)


# ---- helpers ---------------------------------------------------------------


def _is_within(target: Path, root: Path) -> bool:
    try:
        target.resolve().relative_to(root.resolve())
        return True
    except ValueError:
        return False


def _html_escape(s: str) -> str:
    return s.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;")


def main() -> None:
    import uvicorn

    uvicorn.run(
        "fact.dashboard.server:app",
        host=HOST,
        port=PORT,
        log_level="warning",
        access_log=False,
    )


if __name__ == "__main__":
    main()
