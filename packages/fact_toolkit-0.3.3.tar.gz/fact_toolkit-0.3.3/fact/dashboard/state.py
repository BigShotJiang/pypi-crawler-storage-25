"""In-memory dashboard state derived from disk + event log."""

from __future__ import annotations

import json
from dataclasses import dataclass, field
from pathlib import Path

from fact import pricing
from fact.dashboard.tree import build_tree


def _context_window_for(model: str | None) -> int:
    """Look up the context window for a model from pricing.json. Strips
    `-YYYYMMDD` date suffixes so e.g. `claude-haiku-4-5-20251001` matches
    the canonical `claude-haiku-4-5` entry. Defaults to 200K if unknown."""
    if not model:
        return 200_000
    import re
    data = pricing.load_pricing()
    models = data.get("models", {})
    m = models.get(model)
    if not isinstance(m, dict):
        stripped = re.sub(r"-\d{8}$", "", model)
        m = models.get(stripped) if stripped != model else None
    if not isinstance(m, dict):
        return 200_000
    return int(m.get("context_window", 200_000))
from fact.paths import ProjectPaths
from fact.spec_state import (
    ProjectState,
    build_stories,
    constitution_task,
    feature_phase_tasks,
    read_project_state,
)


@dataclass
class TokenStats:
    total_input: int = 0
    total_output: int = 0
    total_cache_read: int = 0
    cost_usd: float = 0.0
    cost_complete: bool = True  # False if any event referenced an unknown model
    by_model: dict[str, dict] = field(default_factory=dict)
    by_phase: dict[str, dict] = field(default_factory=dict)
    by_source: dict[str, dict] = field(default_factory=dict)  # "main" vs "sub"
    counterfactual_opus: float = 0.0
    event_count: int = 0
    skills_installed: list[str] = field(default_factory=list)
    # Cache_read of the *most recent* unique MAIN-AGENT assistant message —
    # proxy for "size of the conversation cache right now". Sub-agent context
    # is intentionally excluded: it's ephemeral per spawn and doesn't reflect
    # what the user perceives as "their" conversation weight.
    current_context_size: int = 0
    current_context_model: str | None = None


def _empty_bucket() -> dict:
    return {"input": 0, "output": 0, "cache_read": 0, "cost_usd": 0.0, "events": 0}


def _accumulate(
    stats: TokenStats,
    *,
    model: str,
    inp: int,
    out: int,
    cache: int,
    phase: str,
    pricing_data: dict,
    cf_events: list,
    source: str = "main",
) -> None:
    if inp == 0 and out == 0 and cache == 0:
        return
    stats.total_input += inp
    stats.total_output += out
    stats.total_cache_read += cache

    cb = pricing.cost_of_event(
        {"model": model, "input_tokens": inp, "output_tokens": out, "cache_read_tokens": cache},
        pricing_data,
    )
    if not cb.is_complete:
        stats.cost_complete = False
    stats.cost_usd += cb.cost_usd

    bucket = stats.by_model.setdefault(model, _empty_bucket())
    bucket["input"] += inp
    bucket["output"] += out
    bucket["cache_read"] += cache
    bucket["cost_usd"] += cb.cost_usd
    bucket["events"] += 1

    pb = stats.by_phase.setdefault(phase, _empty_bucket())
    pb["input"] += inp
    pb["output"] += out
    pb["cache_read"] += cache
    pb["cost_usd"] += cb.cost_usd
    pb["events"] += 1

    sb = stats.by_source.setdefault(source, _empty_bucket())
    sb["input"] += inp
    sb["output"] += out
    sb["cache_read"] += cache
    sb["cost_usd"] += cb.cost_usd
    sb["events"] += 1

    cf_events.append(
        {"input_tokens": inp, "output_tokens": out, "cache_read_tokens": cache}
    )


def _discover_subagent_transcripts(main_transcript_path: str) -> list[str]:
    """Sub-agent transcripts live next to the main one, in
    `<session_id>/subagents/agent-<id>.jsonl`. Returns paths or [] if none."""
    p = Path(main_transcript_path)
    if not p.exists():
        return []
    sub_dir = p.parent / p.stem / "subagents"
    if not sub_dir.exists():
        return []
    return [str(f) for f in sorted(sub_dir.glob("*.jsonl"))]


def _scan_transcript(path: str) -> list[dict]:
    """Return unique assistant records (by uuid) with model+usage from a Claude Code transcript."""
    p = Path(path)
    if not p.exists() or not p.is_file():
        return []
    seen: set[str] = set()
    out: list[dict] = []
    try:
        with p.open() as f:
            for line in f:
                line = line.strip()
                if not line:
                    continue
                try:
                    rec = json.loads(line)
                except json.JSONDecodeError:
                    continue
                if rec.get("type") != "assistant":
                    continue
                msg = rec.get("message") or {}
                if not isinstance(msg, dict):
                    continue
                usage = msg.get("usage")
                if not usage:
                    continue
                uid = msg.get("id") or rec.get("uuid")
                if not uid or uid in seen:
                    continue
                seen.add(uid)
                out.append(
                    {
                        "uuid": uid,
                        "model": msg.get("model"),
                        "usage": usage,
                    }
                )
    except OSError:
        pass
    return out


def aggregate_events_since(
    events_path: Path,
    since_iso: str | None,
) -> dict:
    """Sum tokens from events recorded after a given ISO timestamp.

    Used for the "since last compaction" header metric. Returns the same
    shape (input/output/cache_read/total) over the slice.
    """
    out = {"input": 0, "output": 0, "cache_read": 0, "total": 0, "events": 0}
    if not events_path.exists() or not since_iso:
        return out
    seen: set[str] = set()
    with events_path.open() as f:
        for line in f:
            line = line.strip()
            if not line:
                continue
            try:
                e = json.loads(line)
            except json.JSONDecodeError:
                continue
            ts = e.get("fact_received_at") or ""
            if ts <= since_iso:
                continue
            uid = e.get("message_uuid")
            if uid:
                if uid in seen:
                    continue
                seen.add(uid)
            usage = e.get("usage") or {}
            inp = int(usage.get("input_tokens", 0) or 0)
            outp = int(usage.get("output_tokens", 0) or 0)
            cache = int(usage.get("cache_read_input_tokens", 0) or 0)
            if inp == 0 and outp == 0 and cache == 0:
                continue
            out["input"] += inp
            out["output"] += outp
            out["cache_read"] += cache
            out["total"] += inp + outp + cache
            out["events"] += 1
    return out


def aggregate_events(events_path: Path, current_phase: str) -> TokenStats:
    """Aggregate token usage and cost.

    Two sources are merged, deduplicated by message uuid:
      1. Direct usage attached to events posted by the hook (forward-looking).
      2. The Claude Code transcript files referenced in those events
         (backfill — covers events that landed before the hook learned to
         attach usage).
    """
    stats = TokenStats()
    pricing_data = pricing.load_pricing()
    cf_events: list[dict] = []
    seen_uuids: set[str] = set()
    transcript_paths: set[str] = set()

    if events_path.exists():
        with events_path.open() as f:
            for line in f:
                line = line.strip()
                if not line:
                    continue
                try:
                    e = json.loads(line)
                except json.JSONDecodeError:
                    continue
                stats.event_count += 1

                kind = e.get("hook_event_name") or e.get("kind")
                if kind == "skill_installed":
                    name = e.get("name")
                    if name and name not in stats.skills_installed:
                        stats.skills_installed.append(name)
                    continue

                tp = e.get("transcript_path")
                if tp:
                    transcript_paths.add(tp)

                usage = e.get("usage") or {}
                if not usage:
                    continue

                uid = e.get("message_uuid")
                if uid:
                    if uid in seen_uuids:
                        continue
                    seen_uuids.add(uid)

                model = e.get("model") or "unknown"
                phase = e.get("fact_phase") or current_phase
                cache_read = int(usage.get("cache_read_input_tokens", 0) or 0)
                _accumulate(
                    stats,
                    model=model,
                    inp=int(usage.get("input_tokens", 0) or 0),
                    out=int(usage.get("output_tokens", 0) or 0),
                    cache=cache_read,
                    phase=phase,
                    pricing_data=pricing_data,
                    cf_events=cf_events,
                )
                # Latest unique message's cache_read proxies the current
                # context size. Events.jsonl is ordered; we overwrite as we
                # iterate, so the final value is the most recent.
                if cache_read > 0:
                    stats.current_context_size = cache_read
                    stats.current_context_model = model

    # Backfill from referenced transcripts (main agent).
    for tp in transcript_paths:
        for rec in _scan_transcript(tp):
            if rec["uuid"] in seen_uuids:
                continue
            seen_uuids.add(rec["uuid"])
            usage = rec["usage"]
            cache_read = int(usage.get("cache_read_input_tokens", 0) or 0)
            _accumulate(
                stats,
                model=rec.get("model") or "unknown",
                inp=int(usage.get("input_tokens", 0) or 0),
                out=int(usage.get("output_tokens", 0) or 0),
                cache=cache_read,
                phase=current_phase,
                pricing_data=pricing_data,
                cf_events=cf_events,
                source="main",
            )
            # Update current context size from the latest MAIN-agent record
            # only — sub-agent contexts are independent and shouldn't pollute it.
            if cache_read > 0:
                stats.current_context_size = cache_read
                stats.current_context_model = rec.get("model") or stats.current_context_model

        # Sub-agent transcripts live alongside the main one. Their token
        # usage adds to the cumulative total but NOT to current_context_size.
        for sub_tp in _discover_subagent_transcripts(tp):
            for rec in _scan_transcript(sub_tp):
                if rec["uuid"] in seen_uuids:
                    continue
                seen_uuids.add(rec["uuid"])
                usage = rec["usage"]
                _accumulate(
                    stats,
                    model=rec.get("model") or "unknown",
                    inp=int(usage.get("input_tokens", 0) or 0),
                    out=int(usage.get("output_tokens", 0) or 0),
                    cache=int(usage.get("cache_read_input_tokens", 0) or 0),
                    phase=current_phase,
                    pricing_data=pricing_data,
                    cf_events=cf_events,
                    source="sub",
                )

    stats.counterfactual_opus = pricing.counterfactual_opus_cost(cf_events, pricing_data)
    return stats


def installed_skills(paths: ProjectPaths) -> list[dict]:
    if not paths.skills_dir.exists():
        return []
    out = []
    for d in sorted(p for p in paths.skills_dir.iterdir() if p.is_dir()):
        skill_md = d / "SKILL.md"
        if not skill_md.exists():
            continue
        first_line = ""
        for line in skill_md.read_text(encoding="utf-8").splitlines():
            if line.startswith("description:"):
                first_line = line.split(":", 1)[1].strip()
                break
        is_fact = d.name.startswith("fact-")
        out.append({"name": d.name, "description": first_line, "builtin": is_fact})
    return out


def session_state(paths: ProjectPaths) -> dict | None:
    if not paths.session_state.exists():
        return None
    try:
        return json.loads(paths.session_state.read_text(encoding="utf-8"))
    except json.JSONDecodeError:
        return None


_FRONTMATTER_RE = None  # lazily compiled


def _parse_audit_frontmatter(text: str) -> dict:
    """Pull the YAML frontmatter (if any) from an audit report."""
    if not text.startswith("---"):
        return {}
    end = text.find("\n---", 3)
    if end == -1:
        return {}
    block = text[3:end].strip()
    out: dict = {}
    counts: dict = {}
    in_counts = False
    for raw in block.splitlines():
        line = raw.rstrip()
        if not line:
            in_counts = False
            continue
        if line.startswith("counts:"):
            in_counts = True
            continue
        if in_counts:
            if line.startswith("  ") and ":" in line:
                k, v = line.strip().split(":", 1)
                try:
                    counts[k.strip()] = int(v.strip())
                except ValueError:
                    pass
            else:
                in_counts = False
        if not in_counts and ":" in line and not line.startswith(" "):
            k, _, v = line.partition(":")
            out[k.strip()] = v.strip()
    if counts:
        out["counts"] = counts
    return out


def recent_compactions(paths: ProjectPaths, limit: int = 8) -> list[dict]:
    """Find compaction events from disk.

    Two sources:
      - `.specify/fact/sessions/*compact*.md` — the summary the agent
        wrote in response to a compaction trigger.
      - `.specify/fact/.compact-progress-<sid>-NM.fired` markers — the
        progress hook records the moment a milestone fired.

    Both have the timestamp embedded (mtime). Newest first.
    """
    out: list[dict] = []
    if paths.sessions_dir.exists():
        for p in paths.sessions_dir.glob("*compact*.md"):
            try:
                mtime = p.stat().st_mtime
            except OSError:
                continue
            out.append({
                "kind": "summary",
                "name": p.name,
                "path": str(p.relative_to(paths.root)),
                "ts": _iso_from_mtime(mtime),
                "ts_epoch": mtime,
            })
    if paths.fact_dir.exists():
        for m in paths.fact_dir.glob(".compact-progress-*.fired"):
            try:
                mtime = m.stat().st_mtime
            except OSError:
                continue
            # Pull milestone N from .compact-progress-<sid>-NM.fired
            stem = m.stem  # ".compact-progress-<sid>-NM"
            milestone = stem.rsplit("-", 1)[-1] if "-" in stem else "?"
            out.append({
                "kind": "trigger",
                "name": m.name,
                "milestone": milestone,
                "path": str(m.relative_to(paths.root)),
                "ts": _iso_from_mtime(mtime),
                "ts_epoch": mtime,
            })
    out.sort(key=lambda d: d["ts_epoch"], reverse=True)
    return out[:limit]


def _iso_from_mtime(mtime: float) -> str:
    from datetime import datetime, timezone
    return datetime.fromtimestamp(mtime, tz=timezone.utc).isoformat(timespec="seconds")


def recent_audits(paths: ProjectPaths, limit: int = 12) -> list[dict]:
    if not paths.audits_dir.exists():
        return []
    files = sorted(paths.audits_dir.glob("*.md"), reverse=True)[:limit]
    out: list[dict] = []
    for f in files:
        text = f.read_text(encoding="utf-8", errors="ignore")
        meta = _parse_audit_frontmatter(text)
        out.append({
            "name": f.name,
            "path": str(f.relative_to(paths.root)),
            "dimension": meta.get("dimension", "?"),
            "trigger": meta.get("trigger", "?"),
            "scope": meta.get("scope", ""),
            "skill": meta.get("skill", ""),
            "created_at": meta.get("created_at", ""),
            "counts": meta.get("counts") or {},
        })
    return out


def recent_session_summaries(paths: ProjectPaths, limit: int = 5) -> list[dict]:
    if not paths.sessions_dir.exists():
        return []
    files = sorted(paths.sessions_dir.glob("*.md"), reverse=True)[:limit]
    out = []
    for f in files:
        text = f.read_text(encoding="utf-8")
        title = next((l.lstrip("# ").rstrip() for l in text.splitlines() if l.startswith("#")), f.stem)
        out.append({"name": f.name, "title": title, "path": str(f)})
    return out


def build_snapshot(paths: ProjectPaths) -> dict:
    """Single payload pushed over WebSocket on every change."""
    project: ProjectState = read_project_state(paths)
    stats = aggregate_events(paths.events_file, project.current_phase)
    state = session_state(paths)
    summaries = recent_session_summaries(paths)
    compactions = recent_compactions(paths)
    last_compact_ts = compactions[0]["ts"] if compactions else None
    since = aggregate_events_since(paths.events_file, last_compact_ts)

    session_files = (state or {}).get("files_modified_this_turn", []) if state else []
    const_task = constitution_task(paths, session_files)

    active = project.active_feature

    parallel_tasks_raw = (state.get("parallel_tasks") or []) if state else []
    parallel_index = {
        p["id"]: p
        for p in parallel_tasks_raw
        if isinstance(p, dict) and isinstance(p.get("id"), str)
    }

    # Are recent file edits "fresh"? We only infer in-progress when the agent
    # has been active in the last ~5 minutes; older state is presumed idle.
    from datetime import datetime, timezone

    fresh_window_seconds = 300
    is_fresh = False
    if state and state.get("updated_at"):
        try:
            ts = state["updated_at"].replace("Z", "+00:00")
            updated_dt = datetime.fromisoformat(ts)
            is_fresh = (datetime.now(timezone.utc) - updated_dt).total_seconds() < fresh_window_seconds
        except Exception:
            is_fresh = False

    # Only the SINGLE most-recent non-meta file is "currently active". Older
    # entries in the buffer are still recent edits but the agent has moved
    # on. Compaction summaries / audit reports under .specify/fact/ are
    # filtered as agent meta-noise.
    META_PREFIXES = ("/.specify/fact/",)
    non_meta = [f for f in session_files if not any(p in f for p in META_PREFIXES)]
    active_file = non_meta[-1] if (is_fresh and non_meta) else None

    # Compute, ONCE, which tasks are inferred in-progress. Pick the single
    # lowest-position pending task that mentions the active file.
    inferred_winners: set[str] = set()
    if active_file:
        winner = None
        for f in project.features:
            for t in f.tasks:
                if t.done or not t.files:
                    continue
                if any(tf and tf in active_file for tf in t.files):
                    if winner is None or t.position < winner.position:
                        winner = t
        if winner is not None:
            inferred_winners.add(winner.id)

    def _is_inferred(task_id: str) -> bool:
        return task_id in inferred_winners

    def task_dict(t, *, synthetic: bool, feature_slug: str | None = None) -> dict:
        active_task = state.get("active_task_id") if state else None
        parallel = parallel_index.get(t.id)
        # Infer in-progress when the agent edited one of this task's files in
        # the last few minutes — covers the common case where the agent didn't
        # write active_task_id to session_state.json (per fact-implement §2).
        inferred = (
            not synthetic
            and not t.done
            and active_task != t.id
            and parallel is None
            and _is_inferred(t.id)
        )

        in_prog_real = (
            not synthetic
            and not t.done
            and (active_task == t.id or parallel is not None or inferred)
        )
        in_prog_synth = synthetic and "IN PROGRESS" in t.tags

        started_at = None
        if parallel:
            started_at = parallel.get("started_at")
        elif state and active_task == t.id and not synthetic:
            started_at = state.get("active_task_started_at")
        elif inferred and state:
            started_at = state.get("updated_at")

        subagent_info = None
        if parallel:
            subagent_info = {
                "id": parallel.get("subagent_id"),
                "model": parallel.get("model"),
            }

        return {
            "id": t.id,
            "title": t.title,
            "description": t.description,
            "done": t.done,
            "synthetic": synthetic,
            "in_progress": in_prog_real or in_prog_synth,
            "tags": [tg for tg in t.tags if tg != "IN PROGRESS"],
            "files": t.files,
            "deps": t.deps,
            "section": t.section,
            "position": t.position,
            "raw_line": t.raw_line,
            "file_path": t.file_path,
            "file_size": t.file_size,
            "file_mtime": t.file_mtime,
            "active_task_started_at": started_at,
            "subagent": subagent_info,
            "feature_slug": feature_slug,
            "inferred_in_progress": inferred,  # heuristic, not declared by agent
        }

    # Build stories — these are the new top-level kanban units.
    stories = build_stories(paths, project, session_files)

    def story_dict(s) -> dict:
        # Mark synthetic phase tasks (workflow / foundation stories) appropriately.
        synth = s.kind in ("foundation", "workflow")
        task_dicts = [
            task_dict(t, synthetic=synth or t.id.startswith("Φ-"), feature_slug=s.feature_slug)
            for t in s.tasks
        ]
        done_n = sum(1 for t in task_dicts if t["done"])
        in_prog_n = sum(1 for t in task_dicts if t["in_progress"])
        total_n = len(task_dicts)
        if total_n == 0:
            status = "pending"
        elif done_n == total_n:
            status = "done"
        elif in_prog_n > 0:
            status = "in_progress"
        else:
            status = "pending"
        return {
            "id": s.id,
            "title": s.title,
            "kind": s.kind,
            "feature_slug": s.feature_slug,
            "priority": s.priority,
            "user_story_number": s.user_story_number,
            "status": status,
            "done_count": done_n,
            "total_count": total_n,
            "in_progress_count": in_prog_n,
            "tasks": task_dicts,
        }

    kanban_stories = [story_dict(s) for s in stories]

    # Aggregate counters for the header.
    total_tasks = sum(st["total_count"] for st in kanban_stories)
    total_done = sum(st["done_count"] for st in kanban_stories)

    return {
        "tree": build_tree(paths.root),
        "project": {
            "name": paths.root.name,
            "phase": project.current_phase,
            "has_constitution": project.has_constitution,
            "active_feature": (
                {
                    "slug": active.slug,
                    "has_spec": active.has_spec,
                    "has_plan": active.has_plan,
                    "has_tasks": active.has_tasks,
                    "has_research": active.has_research,
                    "done_tasks": active.done_tasks,
                    "total_tasks": active.total_tasks,
                }
                if active
                else None
            ),
            "kanban_stories": kanban_stories,
            "kanban_tasks": [t for s in kanban_stories for t in s["tasks"]],  # back-compat
            "kanban_done": total_done,
            "kanban_total": total_tasks,
            "active_feature_slug": active.slug if active else None,
            "all_features": [
                {"slug": f.slug, "done": f.done_tasks, "total": f.total_tasks}
                for f in project.features
            ],
        },
        "session": state,
        "summaries": summaries,
        "skills": installed_skills(paths),
        "metrics": {
            "total_input": stats.total_input,
            "total_output": stats.total_output,
            "total_cache_read": stats.total_cache_read,
            "total_tokens": stats.total_input + stats.total_output + stats.total_cache_read,
            "cost_usd": round(stats.cost_usd, 4),
            "cost_complete": stats.cost_complete,
            "by_model": stats.by_model,
            "by_phase": stats.by_phase,
            "by_source": stats.by_source,
            "counterfactual_opus": round(stats.counterfactual_opus, 4),
            "savings_vs_opus": round(max(0.0, stats.counterfactual_opus - stats.cost_usd), 4),
            "event_count": stats.event_count,
            "since_last_compaction": since,
            "last_compaction_at": last_compact_ts,
            "current_context_size": stats.current_context_size,
            "current_context_model": stats.current_context_model,
            "current_context_window": _context_window_for(stats.current_context_model),
            "current_context_pct": (
                stats.current_context_size / _context_window_for(stats.current_context_model)
                if _context_window_for(stats.current_context_model) > 0 else 0
            ),
        },
        "compactions": compactions,
    }
