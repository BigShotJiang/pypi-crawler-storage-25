# Contributing to FACT

This file is for **maintainers** of the FACT toolkit. End users only need the
[README](README.md).

## Releasing to PyPI

The repo ships a [trusted-publishing](https://docs.pypi.org/trusted-publishers/)
workflow at `.github/workflows/release.yml`. No API tokens — PyPI verifies the
GitHub Actions OIDC token directly.

### One-time setup on PyPI

1. Claim the project name (`fact-toolkit`) — first manual upload, or by
   reserving via the PyPI account UI.
2. On the project's *Publishing* page, add a Trusted Publisher for:
   - owner: `holaPymbu`
   - repository: `fact`
   - workflow: `release.yml`
   - environment: `release`
3. In this repo's *Settings → Environments*, create an environment
   named `release`. No secrets needed — OIDC handles it.

### Cutting a release

```bash
# 1. Bump the version in pyproject.toml (and only there — fact/__init__.py
#    reads it from package metadata via importlib.metadata).
# 2. Commit + push to main.
git add pyproject.toml
git commit -m "release: vX.Y.Z"
git push origin main

# 3. Tag and push.
git tag vX.Y.Z
git push origin vX.Y.Z
```

The workflow:
1. Checks the tag matches `pyproject.toml`'s `version`.
2. Builds the sdist + wheel.
3. Publishes them to PyPI via OIDC.

### Verifying

```bash
# Workflow status:
gh run watch $(gh run list --workflow=release.yml --limit 1 --json databaseId --jq '.[0].databaseId')

# PyPI propagation (it can take a few seconds after the workflow finishes):
curl -s "https://pypi.org/simple/fact-toolkit/" -H "Accept: application/vnd.pypi.simple.v1+json" | python3 -c "import sys,json; d=json.load(sys.stdin); print(sorted({f['filename'].split('-')[1] for f in d['files'] if f['filename'].endswith('.whl')}))"
```

### Yanking a bad release

If a release ships broken, **don't delete the file** — yank it instead. Yanking
keeps the file resolvable so existing pinned installs still work, but new
`uv tool install fact-toolkit` won't pick it up:

1. Go to https://pypi.org/manage/project/fact-toolkit/releases/
2. Click the version → *Options* → *Yank this release*
3. Cut a new patch release (`vX.Y.Z+1`) with the fix.

Never `pypi-delete` a published version — it makes the version number
permanently unusable, which is worse than yanking.

## Local development

```bash
# Editable install with dev deps:
python3 -m venv .venv
source .venv/bin/activate
pip install -e ".[dev]"

# Run tests:
pytest tests/ -q

# Run with warnings-as-errors to catch deprecation drift:
pytest tests/ -W error
```

After bumping deps in `pyproject.toml`, reinstall: `pip install -e ".[dev]" --upgrade`.

## Versioning

Loose semver:
- **Patch** (`0.X.Y`): bug fix, doc, dep bump that doesn't change behavior.
- **Minor** (`0.X.0`): new skill, new command, new behavior; backward-compatible.
- **Major** (`X.0.0`): reserved for the 1.0 cut. Until then, breaking changes
  go in a minor bump with a clear note in the commit message.

`fact/__init__.py` reads the version from package metadata (`importlib.metadata.version("fact-toolkit")`),
so you only ever bump the string in **one place**: `pyproject.toml`.

## Project layout

When FACT manages a project:

```
my-project/
├── .claude/
│   ├── skills/
│   │   ├── fact-*/SKILL.md                  (FACT base skills)
│   │   └── speckit-*/SKILL.md               (Spec Kit's own skills)
│   ├── commands/
│   │   ├── fact-start.md
│   │   ├── fact-next.md
│   │   ├── fact-status.md
│   │   └── fact-audit.md
│   ├── hooks/                               (pure-Python — Claude Code calls them directly)
│   │   ├── fact_hook.py                     (FACT observation; tool/session/subagent events)
│   │   ├── fact_audit.py                    (per-file audit trigger on PostToolUse)
│   │   ├── fact_audit_stop.py               (session-stop audit + test-suite runner helper)
│   │   ├── fact_compact_progress.py         (60% context-window compaction trigger)
│   │   ├── fact_compact.py                  (compaction helper, invoked on demand)
│   │   └── fact_session_resume.py           (resume nudge on SessionStart)
│   └── settings.json                        (hook wiring)
├── .specify/
│   ├── memory/
│   │   └── constitution.md                  (Spec Kit)
│   ├── specs/
│   │   └── <NNN-feature>/                   (Spec Kit per-feature)
│   │       ├── spec.md, plan.md, tasks.md, research.md
│   │       ├── checklists/, contracts/, …
│   └── fact/                                (FACT operational state)
│       ├── config.json                      (port, host, agent type)
│       ├── dashboard.pid                    (running dashboard pid)
│       ├── events.jsonl                     (append-only hook log)
│       ├── session_state.json               (mechanical state)
│       ├── sessions/<UTC>.md                (semantic summaries)
│       ├── audits/<UTC>-<dim>.md            (audit reports)
│       └── .stop-audit-<id>.fired           (loop guard markers)
├── CLAUDE.md                                (~20 lines, points at skills)
└── (your code: src/, tests/, etc)
```

Key principle: **everything FACT writes lives under `.specify/fact/`**.
There is no parallel `~/.fact/` or `./fact/` directory in the project.
If you `rm -rf .specify/`, you reset both Spec Kit AND FACT — clean slate.

## Design principles

These guide every implementation decision in FACT. If a change violates
one, the change is wrong, not the principle.

1. **Single source of truth: Spec Kit `.md` files.** FACT never writes
   parallel state files as a substitute. Every derived view (dashboard,
   status command) reads from the Spec Kit files.
2. **The agent never spends tokens maintaining FACT metadata.** What
   FACT needs to know is deduced from hooks, the filesystem, and the
   files Spec Kit already generates. Semantic summaries the agent writes
   are the same it would write under good RPI practice.
3. **`CLAUDE.md` is 20 lines or less.** Detailed rules live in skills,
   loaded on demand.
4. **RPI rules are non-negotiable.** The 40% smart-zone, intentional
   compaction, sub-agents for forking context, code snippets in plans —
   these aren't bendable.
5. **Sub-agents fork context, not roles.** No "frontend agent" or
   "backend agent". Sub-agents are a compression mechanism.
6. **Sub-agents use differentiated models.** Haiku for lookup, Sonnet
   for synthesis, the main model for deep reasoning.
7. **External skills require explicit user confirmation.** The agent
   never downloads a skill without a clear "yes" in chat.
8. **FACT runs alongside, never in the middle.** No wrapping, no proxying.
9. **Cheap extensibility, not expensive.** A single Protocol
   (`AgentAdapter`), one concrete impl. No plugin registry.
10. **Honest metrics.** If a number can't be computed accurately, show
    a placeholder, never fabricate.
11. **One project folder.** Everything FACT writes is under
    `.specify/fact/`. No parallel root directories.
12. **Continuity is automatic.** The user never runs a `pause` or `save`
    ritual. Close anytime, reopen, the agent catches up.
