#!/usr/bin/env python3
"""Session-stop audit trigger.

Fires when the agent attempts to close the session. Emits a structured
prompt that the agent's `fact-audit` skill turns into a comprehensive
review (security + architecture + quality) plus running the project
test suite as a separate action, before the session is allowed to end.

Dedup via a marker file so we don't loop: once the skill finishes a
session-stop audit, it writes `.specify/fact/.stop-audit-<session>.done`
and the agent's next stop attempt sees the marker, skips the trigger,
and the session closes cleanly.
"""

from __future__ import annotations

import json
import os
import sys
from datetime import datetime, timezone
from pathlib import Path


def _project_root() -> Path:
    return Path(os.environ.get("CLAUDE_PROJECT_DIR", os.getcwd()))


def _read_payload() -> dict:
    raw = sys.stdin.read().strip()
    if not raw:
        return {}
    try:
        return json.loads(raw)
    except json.JSONDecodeError:
        return {}


def main() -> int:
    payload = _read_payload()
    session_id = payload.get("session_id") or "unknown"
    root = _project_root()
    fact_dir = root / ".specify" / "fact"

    # Final dedup marker (written by the agent once the user has fully
    # resolved the audit). If present, let the stop close cleanly.
    done_marker = fact_dir / f".stop-audit-{session_id}.done"
    if done_marker.exists():
        return 0

    # First-fire marker. We trigger AT MOST ONCE per session — otherwise
    # every turn the agent spends waiting for the user's decision re-fires
    # the Stop hook (each of its "esperando: 1/2/3/4" messages ends a turn,
    # and Claude Code calls Stop again). Loop city.
    #
    # First fire: write the marker, print the audit trigger, exit 2.
    # Any subsequent fire in the same session: exit 0 silently. The trigger
    # message is already in the conversation; the agent is mid-flow.
    fired_marker = fact_dir / f".stop-audit-{session_id}.fired"
    if fired_marker.exists():
        return 0

    fact_dir.mkdir(parents=True, exist_ok=True)
    fired_marker.write_text(datetime.now(timezone.utc).isoformat(timespec="seconds"), encoding="utf-8")

    print("\n".join([
        "🔒 FACT AUDIT — session-stop trigger",
        "Scope:      all files modified during this session",
        "Dimensions: security, architecture, quality (incl. test quality)",
        "Plus:       run the project test suite as a separate action",
        f"Session id: {session_id}",
        "",
        "PROTOCOL — load the `fact-audit` skill and follow §Session-stop review:",
        "",
        "  1. Run the project test suite if a runner is available (pytest /",
        "     npm test / cargo test / etc). Failures count as critical.",
        "",
        "  2. For each of [security, architecture, quality], spawn a Sonnet",
        "     sub-agent with a domain skill from skills.sh against the union",
        "     of files modified this session. Quality covers test smells and",
        "     missing-test detection — there is no separate testing dimension.",
        "",
        "  3. Aggregate test results + sub-agent findings. Show them to the",
        "     user verbatim.",
        "",
        "  4. Ask: fix automatically · I'll fix manually · override (with",
        "     logged reason) · rollback.",
        "",
        "  5. After the user has fully resolved the audit, write the .done",
        "     marker so any later Stop attempt closes immediately:",
        f"        touch {done_marker.relative_to(root)}",
        "     (the .fired marker that broke this loop is already in place;",
        "      this hook won't trigger again on the same session even without",
        "      the .done.)",
        "",
        "  6. Do NOT let the session close until the user has decided.",
    ]), file=sys.stderr)
    return 2


if __name__ == "__main__":
    # Fail-soft: clamp exit to {0, 2}. A hook crash must never block stop.
    try:
        rc = main()
    except Exception:
        rc = 0
    sys.exit(rc if rc in (0, 2) else 0)
