#!/usr/bin/env python3
"""Stop-hook trigger — emits a compaction prompt once per session if the
session had substantial activity (≥5 file edits). The agent loads
fact-rpi-harness and writes a session summary to .specify/fact/sessions/
before the session closes.

Why this exists
---------------
fact-rpi-harness §4 already says the agent should write semantic
summaries at phase boundaries. In practice it doesn't always do it,
and the next session re-reads the entire 130K transcript instead of
a 30K summary — every turn pays cache_read on the bigger context.

The trigger here forces the discipline at the cheapest possible
moment (right before close), and only fires when it would actually
matter (5+ edits = real work happened, not a 2-turn chat).

Loop safety
-----------
Marker `.compact-<session>.fired` written on first fire; subsequent
Stops on the same session exit 0 silently. The user is never asked
to choose anything — the agent just writes the file and lets the
session close.
"""

from __future__ import annotations

import json
import os
import sys
from datetime import datetime, timezone
from pathlib import Path


MIN_EDITS = 5  # don't bother compacting tiny sessions


def _project_root() -> Path:
    return Path(os.environ.get("CLAUDE_PROJECT_DIR", os.getcwd()))


def _read_payload() -> dict:
    raw = sys.stdin.read().strip()
    if not raw:
        return {}
    try:
        return json.loads(raw)
    except json.JSONDecodeError:
        return {}


def _session_has_activity(session_id: str, root: Path) -> bool:
    events_file = root / ".specify" / "fact" / "events.jsonl"
    if not events_file.exists():
        return False
    count = 0
    edit_tools = {"Edit", "Write", "MultiEdit"}
    try:
        with events_file.open() as f:
            for line in f:
                line = line.strip()
                if not line:
                    continue
                try:
                    e = json.loads(line)
                except json.JSONDecodeError:
                    continue
                if e.get("session_id") != session_id:
                    continue
                if e.get("tool_name") in edit_tools:
                    count += 1
                    if count >= MIN_EDITS:
                        return True
    except OSError:
        return False
    return False


def _trigger_message(session_id: str) -> str:
    ts = datetime.now(timezone.utc).strftime("%Y-%m-%dT%H%M")
    return "\n".join([
        "📦 FACT COMPACTION — write the session summary before closing",
        f"Session id: {session_id}",
        f"Suggested file: .specify/fact/sessions/{ts}-compact.md",
        "",
        "PROTOCOL — load `fact-rpi-harness` and follow §4 (Semantic state writes):",
        "",
        "  1. Write a concise markdown summary to that path with the three",
        "     sections fact-rpi-harness §4 specifies:",
        "       ## What was done       — bullets, one line each (3-7 max).",
        "       ## What was decided     — decisions worth remembering",
        "                                 (rationale ≤1 line each).",
        "       ## What's pending / next — what to start next session.",
        "",
        "  2. Keep it under ~150 lines. This file replaces the 130K transcript",
        "     as next session's primer context — the smaller it is, the",
        "     cheaper every subsequent turn becomes (cache_read at parent's",
        "     model rate).",
        "",
        "  3. After the summary is on disk, suggest the user run `/compact`",
        "     before they close — Claude Code's built-in summarizes the",
        "     running conversation in place, so even if they don't restart",
        "     they immediately stop paying cache_read on the full transcript.",
        "     /compact is a slash command only the USER can run; the agent",
        "     can suggest it but not execute it.",
        "",
        "  4. CRITICAL — tell the user how to wake the agent up afterwards.",
        "     Example: \"After /compact, just type `continue` or your next",
        "     instruction — Claude Code won't auto-take a turn after the",
        "     compact recap; I need a message from you to resume.\"",
        "",
        "  5. Confirm with one short line. The dedup marker is in place;",
        "     this Stop trigger won't fire again on this session_id.",
        "",
        "Cost rationale: a 25K summary read once at next session start",
        "replaces ~130K of transcript re-read on every turn. Roughly",
        "$0.10 of write effort avoids $4-5 of cache_read across a follow-up",
        "session of comparable length.",
    ])


def main() -> int:
    payload = _read_payload()
    session_id = payload.get("session_id") or "unknown"
    root = _project_root()
    fact_dir = root / ".specify" / "fact"

    fired = fact_dir / f".compact-{session_id}.fired"
    if fired.exists():
        return 0

    if not _session_has_activity(session_id, root):
        # Tiny session — nothing worth compacting.
        return 0

    # If a per-million progress trigger already fired in this session,
    # the agent has already been prompted to compact. Don't double-fire
    # at Stop — that's how the user got the cascade of three summary
    # files in 3 minutes (2M trigger → Stop trigger → 3M trigger).
    progress_markers = list(fact_dir.glob(f".compact-progress-{session_id}-*.fired"))
    if progress_markers:
        return 0

    fact_dir.mkdir(parents=True, exist_ok=True)
    fired.write_text(datetime.now(timezone.utc).isoformat(timespec="seconds"), encoding="utf-8")

    print(_trigger_message(session_id), file=sys.stderr)
    return 2


if __name__ == "__main__":
    # Fail-soft: clamp exit to {0, 2}. A hook crash must never block stop.
    try:
        rc = main()
    except Exception:
        rc = 0
    sys.exit(rc if rc in (0, 2) else 0)
