"""Command-line interface for dead-cst."""

from __future__ import annotations

import contextlib
import json
import logging
import re
import sys
from enum import Enum
from pathlib import Path
from typing import Annotated, Iterator, Mapping, Sequence

import typer
from libcst.metadata import CodeRange

from ._graphstore import SymbolGraph
from .analyze import Analysis, _count_nodes_by_prefix, _entrypoint_seeds, _find_reachable
from .cache import (
    GraphCache,
    clear_cache,
    default_cache_path,
)
from .codemod import generate_patch
from .graph import NodeFlags, SymbolNode
from .plugins import (
    EXTERNAL_PREFIXES,
    EdgePlugin,
    ExplicitEntrypointPlugin,
    ModuleDundersPlugin,
    load_plugin,
    simple_name,
)
from .plugins.module_dunders import DUNDER_PREFIX
from .resolvers import (
    ManualResolver,
    PathResolver,
    load_resolver,
)


app = typer.Typer(help="Dead code analysis for Python using libcst.")


WorkersOption = Annotated[
    int | None,
    typer.Option(
        "--workers",
        "-j",
        help="Run cache-miss visitor passes in this many worker processes (>=2 enables it).",
    ),
]


class OutputFormat(str, Enum):
    text = "text"
    json = "json"


def setup_logging(verbose: bool) -> None:
    level = logging.DEBUG if verbose else logging.WARNING
    logging.basicConfig(
        level=level,
        format="%(name)s: %(message)s",
        stream=sys.stderr,
    )


def parse_entrypoint(ep: str) -> str | re.Pattern[str]:
    if ep.startswith("re:"):
        return re.compile(ep[3:])
    return ep


def _rel_path(path: Path, root: Path) -> Path:
    """``path`` made relative to ``root`` if possible, else ``path`` unchanged."""
    try:
        return path.relative_to(root)
    except ValueError:
        return path


def build_plugins(
    *,
    entrypoints: list[str],
    plugin_names: list[str],
) -> list[EdgePlugin]:
    """Compose the plugin list from CLI flags.

    Order: user-specified plugins first, then ``ModuleDundersPlugin``, then
    ``ExplicitEntrypointPlugin`` with the ``-e`` specs. ``-e`` runs last so
    it can hang entrypoints off any synthetic nodes contributed upstream.
    """
    plugins: list[EdgePlugin] = []
    for name in plugin_names:
        plugins.append(load_plugin(name))
    plugins.append(ModuleDundersPlugin())
    if entrypoints:
        specs = [parse_entrypoint(ep) for ep in entrypoints]
        plugins.append(ExplicitEntrypointPlugin(specs=specs))
    return plugins


@contextlib.contextmanager
def _maybe_cache(
    root: Path,
    no_cache: bool,
) -> Iterator[GraphCache | None]:
    """Yield a per-run :class:`GraphCache`, or ``None`` when ``--no-cache`` is set.

    The analysis fingerprint (computed inside :class:`Analysis`) gates
    individual cache rows, so this just opens the database. A
    schema-version mismatch on open wipes ``file_cache`` automatically.
    The context manager closes the SQLite connection on exit, even
    when the analysis raises.
    """
    if no_cache:
        yield None
        return
    with GraphCache(default_cache_path(root)) as cache:
        yield cache


def build_resolver(path_specs: list[str], resolver_name: str | None) -> PathResolver:
    """Pick the single resolver from ``-p`` specs or ``--resolver``.

    The two flags are mutually exclusive: ``-p`` becomes a
    :class:`ManualResolver`, ``--resolver`` loads a named resolver, and
    passing both is a usage error. With neither flag supplied, falls
    back to a :class:`ManualResolver` that treats the project root
    itself as the only package.
    """
    if path_specs and resolver_name is not None:
        raise typer.BadParameter("`-p`/`--path` and `--resolver` are mutually exclusive.")
    if resolver_name is not None:
        return load_resolver(resolver_name)
    if path_specs:
        return ManualResolver(specs=path_specs)
    return ManualResolver(specs=["."])


def version_callback(value: bool) -> None:
    if value:
        from importlib.metadata import version

        typer.echo(f"dead-cst {version('dead-cst')}")
        raise typer.Exit()


@app.callback()
def main(
    version: Annotated[
        bool | None,
        typer.Option("--version", callback=version_callback, is_eager=True, help="Show version."),
    ] = None,
) -> None:
    """Dead code analysis for Python using libcst."""


@app.command()
def analyze(
    root: Annotated[Path, typer.Argument(help="Root directory to analyze.")],
    entrypoint: Annotated[
        list[str] | None,
        typer.Option(
            "-e",
            "--entrypoint",
            help="Entrypoint: file path, FQN, or 're:pattern' for regex.",
        ),
    ] = None,
    path: Annotated[
        list[str] | None,
        typer.Option("-p", "--path", help="Search path spec: 'package:dep1,dep2' or 'package'."),
    ] = None,
    resolver: Annotated[
        str | None,
        typer.Option("--resolver", help="Path resolver to run (e.g. uv)."),
    ] = None,
    plugin: Annotated[
        list[str] | None,
        typer.Option("--plugin", help="Edge plugin to run (e.g. main_block, project_scripts)."),
    ] = None,
    verbose: Annotated[
        bool, typer.Option("-v", "--verbose", help="Enable verbose output.")
    ] = False,
    output_format: Annotated[
        OutputFormat, typer.Option("--format", help="Output format.")
    ] = OutputFormat.text,
    no_cache: Annotated[
        bool, typer.Option("--no-cache", help="Bypass the per-file VisitorPayload cache.")
    ] = False,
    workers: WorkersOption = None,
) -> None:
    """Analyze a Python codebase for dead code."""
    setup_logging(verbose)
    root = root.resolve()

    path_resolver = build_resolver(path or [], resolver)

    typer.echo(f"Building symbol graph for {root}...", err=True)
    plugins = build_plugins(
        entrypoints=entrypoint or [],
        plugin_names=plugin or [],
    )
    with _maybe_cache(root, no_cache) as cache:
        analysis = Analysis(
            root,
            resolver=path_resolver,
            plugins=plugins,
            cache=cache,
            workers=workers,
        )
        graph = analysis.materialize_all()
    reachable = _find_reachable(graph, _entrypoint_seeds(graph))

    unreachable_graph = graph.subgraph([n for n in graph.nodes if n not in reachable])

    package_paths = [p.path for p in analysis.packages]
    dead_suites = analysis.dead_suites()
    if output_format == OutputFormat.json:
        _output_json(graph, unreachable_graph, root, package_paths, dead_suites)
    else:
        _output_text(graph, unreachable_graph, root, package_paths, dead_suites)

    if len(unreachable_graph) > 0:
        raise typer.Exit(1)


def _output_text(
    graph: SymbolGraph,
    unreachable: SymbolGraph,
    root: Path,
    package_paths: Sequence[Path],
    dead_suites: Mapping[Path, tuple[CodeRange, ...]],
) -> None:
    total_by_path = _count_nodes_by_prefix(graph.nodes, package_paths)
    unreachable_by_path = _count_nodes_by_prefix(unreachable.nodes, package_paths)
    for path in package_paths:
        typer.echo(f"\n{path}:")
        total_counts = total_by_path[path]
        unreachable_counts = unreachable_by_path[path]
        for kind in sorted(total_counts):
            # Synthetic nodes (entrypoint sentinels, external-dist markers,
            # dunder-all stand-ins) don't represent user-visible
            # declarations; reporting them alongside functions/classes
            # would be misleading.
            if kind == "synthetic":
                continue
            total = total_counts[kind]
            dead = unreachable_counts.get(kind, 0)
            if dead > 0:
                typer.echo(f"  {kind}: {total} total, {dead} dead")
            else:
                typer.echo(f"  {kind}: {total} total")

    dead_real = _dead_real(unreachable)
    if dead_real:
        typer.echo(f"\nDead symbols ({len(dead_real)}):")
        for node in sorted(dead_real, key=lambda n: (str(n.path), n.fqname)):
            typer.echo(f"  {node.fqname} ({node.type}) at {_rel_path(node.path, root)}")

    branches = _dead_suite_locations(dead_suites, package_paths)
    if branches:
        typer.echo(f"\nUnreachable branches ({len(branches)}):")
        for path, pos in branches:
            rel = _rel_path(path, root)
            start = pos.start
            end = pos.end
            typer.echo(f"  {rel}:{start.line}:{start.column}-{end.line}:{end.column}")


def _dead_real(unreachable: SymbolGraph) -> list[SymbolNode]:
    """Return real (non-synthetic) dead nodes from ``unreachable``.

    Synthetic nodes -- entrypoint sentinels, external-dist markers,
    dunder-all stand-ins -- are excluded; they don't represent
    user-visible declarations and would confuse the dead-code report.
    """
    return [n for n in unreachable.nodes if n.type != "synthetic"]


def _dead_suite_locations(
    dead_suites: Mapping[Path, tuple[CodeRange, ...]], package_paths: Sequence[Path]
) -> list[tuple[Path, CodeRange]]:
    """Flatten :meth:`Analysis.dead_suites` into a sorted ``(path, pos)`` list.

    Restricted to files under one of the analyzed packages' paths so
    the report doesn't surface dead suites in workspace dependencies
    that the user isn't asking about.
    """
    out: list[tuple[Path, CodeRange]] = []
    for path, suites in dead_suites.items():
        if not any(path.is_relative_to(p) for p in package_paths):
            continue
        for pos in suites:
            out.append((path, pos))
    out.sort(key=lambda entry: (str(entry[0]), entry[1].start.line, entry[1].start.column))
    return out


def _output_json(
    graph: SymbolGraph,
    unreachable: SymbolGraph,
    root: Path,
    package_paths: Sequence[Path],
    dead_suites: Mapping[Path, tuple[CodeRange, ...]],
) -> None:
    result: dict = {
        "summary": {},
        "dead_symbols": [],
        "unreachable_branches": [],
    }

    total_by_path = _count_nodes_by_prefix(graph.nodes, package_paths)
    unreachable_by_path = _count_nodes_by_prefix(unreachable.nodes, package_paths)
    for path in package_paths:
        path_str = str(path)
        total_counts = total_by_path[path]
        unreachable_counts = unreachable_by_path[path]
        # Same rationale as the text output: synthetic nodes are reported
        # via ``unreachable_branches`` (and entrypoint sentinels), not as
        # part of the per-kind summary.
        result["summary"][path_str] = {
            kind: {"total": total_counts[kind], "dead": unreachable_counts.get(kind, 0)}
            for kind in total_counts
            if kind != "synthetic"
        }

    for node in sorted(_dead_real(unreachable), key=lambda n: (str(n.path), n.fqname)):
        result["dead_symbols"].append(
            {
                "fqname": node.fqname,
                "type": node.type,
                "path": str(_rel_path(node.path, root)),
            }
        )

    for path, pos in _dead_suite_locations(dead_suites, package_paths):
        result["unreachable_branches"].append(
            {
                "path": str(_rel_path(path, root)),
                "start": {"line": pos.start.line, "column": pos.start.column},
                "end": {"line": pos.end.line, "column": pos.end.column},
            }
        )

    typer.echo(json.dumps(result, indent=2))


@app.command("why-alive")
def why_alive(
    root: Annotated[Path, typer.Argument(help="Root directory to analyze.")],
    fqname: Annotated[str, typer.Argument(help="Fully qualified name of the symbol to check.")],
    path: Annotated[
        list[str] | None,
        typer.Option("-p", "--path", help="Search path spec: 'package:dep1,dep2' or 'package'."),
    ] = None,
    resolver: Annotated[
        str | None,
        typer.Option("--resolver", help="Path resolver to run (e.g. uv)."),
    ] = None,
    plugin: Annotated[
        list[str] | None,
        typer.Option("--plugin", help="Edge plugin to run (e.g. main_block, project_scripts)."),
    ] = None,
    verbose: Annotated[
        bool, typer.Option("-v", "--verbose", help="Enable verbose output.")
    ] = False,
    no_cache: Annotated[
        bool, typer.Option("--no-cache", help="Bypass the per-file VisitorPayload cache.")
    ] = False,
    workers: WorkersOption = None,
) -> None:
    """Show why a symbol is considered alive (reachable)."""
    setup_logging(verbose)
    root = root.resolve()

    path_resolver = build_resolver(path or [], resolver)

    typer.echo(f"Building symbol graph for {root}...", err=True)
    plugins = build_plugins(
        entrypoints=[],
        plugin_names=plugin or [],
    )
    with _maybe_cache(root, no_cache) as cache:
        graph = Analysis(
            root,
            resolver=path_resolver,
            plugins=plugins,
            cache=cache,
            workers=workers,
        ).materialize_all()

    target_node: SymbolNode | None = None
    for node in graph.nodes:
        if node.fqname == fqname:
            target_node = node
            break

    if target_node is None:
        typer.echo(f"Symbol not found: {fqname}", err=True)
        raise typer.Exit(1)

    typer.echo(f"\nSymbol: {target_node.fqname} ({target_node.type})")
    typer.echo(f"Path: {_rel_path(target_node.path, root)}")
    typer.echo(f"In-degree: {graph.raw.in_degree(graph.index(target_node))}")
    typer.echo("\nPredecessor chain:")

    seen_idx: set[int] = set()
    stack: list[int] = [graph.index(target_node)]
    while stack:
        i = stack.pop()
        if i in seen_idx:
            continue
        seen_idx.add(i)
        node = graph.node(i)
        typer.echo(f"  <- {node.fqname} ({node.type}) at {_rel_path(node.path, root)}")
        stack.extend(graph.raw.predecessor_indices(i))


def _is_dunder_all(node: SymbolNode) -> bool:
    return node.type == "variable" and simple_name(node.fqname) == "__all__"


def _is_external_dep(node: SymbolNode) -> bool:
    return node.type == "synthetic" and node.fqname.startswith(EXTERNAL_PREFIXES)


@app.command()
def dependencies(
    root: Annotated[Path, typer.Argument(help="Root directory to analyze.")],
    path: Annotated[
        list[str] | None,
        typer.Option("-p", "--path", help="Search path spec: 'package:dep1,dep2' or 'package'."),
    ] = None,
    resolver: Annotated[
        str | None,
        typer.Option("--resolver", help="Path resolver to run (e.g. uv)."),
    ] = None,
    verbose: Annotated[
        bool, typer.Option("-v", "--verbose", help="Enable verbose output.")
    ] = False,
    output_format: Annotated[
        OutputFormat, typer.Option("--format", help="Output format.")
    ] = OutputFormat.text,
    no_cache: Annotated[
        bool, typer.Option("--no-cache", help="Bypass the per-file VisitorPayload cache.")
    ] = False,
    workers: WorkersOption = None,
) -> None:
    """List third-party dependencies imported by the codebase."""
    setup_logging(verbose)
    root = root.resolve()

    path_resolver = build_resolver(path or [], resolver)

    typer.echo(f"Building symbol graph for {root}...", err=True)
    with _maybe_cache(root, no_cache) as cache:
        analysis = Analysis(
            root,
            resolver=path_resolver,
            cache=cache,
            workers=workers,
        )
        graph = analysis.materialize_all()

    deps_by_package: dict[Path, list[SymbolNode]] = {p.path: [] for p in analysis.packages}
    for node in graph.nodes:
        if not _is_external_dep(node):
            continue
        if node.path in deps_by_package:
            deps_by_package[node.path].append(node)

    if output_format == OutputFormat.json:
        result = {
            str(pkg_path): sorted(n.fqname for n in nodes)
            for pkg_path, nodes in deps_by_package.items()
        }
        typer.echo(json.dumps(result, indent=2))
        return

    for pkg_path, nodes in deps_by_package.items():
        typer.echo(f"\n{pkg_path}:")
        if not nodes:
            typer.echo("  (no third-party dependencies found)")
            continue
        for node in sorted(nodes, key=lambda n: n.fqname):
            typer.echo(f"  {node.fqname}")


@app.command("unused-exports")
def unused_exports(
    root: Annotated[Path, typer.Argument(help="Root directory to analyze.")],
    entrypoint: Annotated[
        list[str] | None,
        typer.Option(
            "-e",
            "--entrypoint",
            help="Entrypoint: file path, FQN, or 're:pattern' for regex.",
        ),
    ] = None,
    path: Annotated[
        list[str] | None,
        typer.Option("-p", "--path", help="Search path spec: 'package:dep1,dep2' or 'package'."),
    ] = None,
    resolver: Annotated[
        str | None,
        typer.Option("--resolver", help="Path resolver to run (e.g. uv)."),
    ] = None,
    plugin: Annotated[
        list[str] | None,
        typer.Option("--plugin", help="Edge plugin to run (e.g. main_block, project_scripts)."),
    ] = None,
    verbose: Annotated[
        bool, typer.Option("-v", "--verbose", help="Enable verbose output.")
    ] = False,
    no_cache: Annotated[
        bool, typer.Option("--no-cache", help="Bypass the per-file VisitorPayload cache.")
    ] = False,
    workers: WorkersOption = None,
) -> None:
    """Report __all__ entries whose targets are only alive because of __all__."""
    setup_logging(verbose)
    root = root.resolve()

    path_resolver = build_resolver(path or [], resolver)

    typer.echo(f"Building symbol graph for {root}...", err=True)
    plugins = build_plugins(
        entrypoints=entrypoint or [],
        plugin_names=plugin or [],
    )
    with _maybe_cache(root, no_cache) as cache:
        graph = Analysis(
            root,
            resolver=path_resolver,
            plugins=plugins,
            cache=cache,
            workers=workers,
        ).materialize_all()
    reachable = _find_reachable(graph, _entrypoint_seeds(graph))

    # ModuleDundersPlugin keeps each ``__all__`` alive via a synthetic
    # entrypoint node ``<dunder>:<fqname>``. Re-run reachability while
    # skipping edges from such synthetics into ``__all__`` variables;
    # whatever drops out was alive only because of __all__.
    def _is_dunder_seed(node: SymbolNode) -> bool:
        return node.type == "synthetic" and node.fqname.startswith(DUNDER_PREFIX)

    visited_idx: set[int] = set()
    stack: list[int] = [graph.index(n) for n in graph.nodes if n.flags & NodeFlags.ENTRYPOINT]
    while stack:
        i = stack.pop()
        if i in visited_idx:
            continue
        visited_idx.add(i)
        is_seed = _is_dunder_seed(graph.node(i))
        for j in graph.raw.successor_indices(i):
            if is_seed and _is_dunder_all(graph.node(j)):
                continue
            stack.append(j)
    visited = {graph.node(i) for i in visited_idx}
    only_via_all = reachable - visited

    by_all: dict[SymbolNode, list[SymbolNode]] = {}
    for sym in only_via_all:
        if _is_dunder_all(sym):
            continue
        for j in graph.raw.predecessor_indices(graph.index(sym)):
            pred = graph.node(j)
            if _is_dunder_all(pred):
                by_all.setdefault(pred, []).append(sym)

    if not by_all:
        typer.echo("No __all__ entries are kept alive only by __all__.")
        return

    for all_sym in sorted(by_all, key=lambda n: n.fqname):
        typer.echo(f"\n{all_sym.fqname} at {_rel_path(all_sym.path, root)}:")
        for sym in sorted(by_all[all_sym], key=lambda n: n.fqname):
            typer.echo(f"  {sym.fqname} ({sym.type})")


@app.command()
def remove(
    root: Annotated[Path, typer.Argument(help="Root directory to analyze.")],
    entrypoint: Annotated[
        list[str] | None,
        typer.Option(
            "-e",
            "--entrypoint",
            help="Entrypoint: file path, FQN, or 're:pattern' for regex.",
        ),
    ] = None,
    path: Annotated[
        list[str] | None,
        typer.Option("-p", "--path", help="Search path spec: 'package:dep1,dep2' or 'package'."),
    ] = None,
    resolver: Annotated[
        str | None,
        typer.Option("--resolver", help="Path resolver to run (e.g. uv)."),
    ] = None,
    plugin: Annotated[
        list[str] | None,
        typer.Option("--plugin", help="Edge plugin to run (e.g. main_block, project_scripts)."),
    ] = None,
    verbose: Annotated[
        bool, typer.Option("-v", "--verbose", help="Enable verbose output.")
    ] = False,
    output: Annotated[
        Path | None,
        typer.Option(
            "-o",
            "--output",
            help="Write patch to this file instead of stdout.",
        ),
    ] = None,
    no_cache: Annotated[
        bool, typer.Option("--no-cache", help="Bypass the per-file VisitorPayload cache.")
    ] = False,
    workers: WorkersOption = None,
) -> None:
    """Emit a unified diff that removes dead code; pipe to ``git apply``.

    Writes the patch to stdout (or to ``--output``) without touching any
    source files. Apply with::

        dead-cst remove . | git apply

    or, with an explicit output path::

        dead-cst remove . -o dead.patch && git apply dead.patch
    """
    setup_logging(verbose)
    root = root.resolve()

    path_resolver = build_resolver(path or [], resolver)

    typer.echo(f"Building symbol graph for {root}...", err=True)
    plugins = build_plugins(
        entrypoints=entrypoint or [],
        plugin_names=plugin or [],
    )
    with _maybe_cache(root, no_cache) as cache:
        analysis = Analysis(
            root,
            resolver=path_resolver,
            plugins=plugins,
            cache=cache,
            workers=workers,
        )
        graph = analysis.materialize_all()
    reachable = _find_reachable(graph, _entrypoint_seeds(graph))

    unreachable_graph = graph.subgraph([n for n in graph.nodes if n not in reachable])

    patch = generate_patch(unreachable_graph, root)

    if not patch:
        typer.echo("No dead code found.", err=True)
        return

    if output is not None:
        output.write_text(patch)
        typer.echo(f"Wrote patch to {output}. Apply with: git apply {output}", err=True)
    else:
        sys.stdout.write(patch)
        typer.echo("Apply with: dead-cst remove ... | git apply", err=True)


cache_app = typer.Typer(help="Manage the on-disk analysis cache.")
app.add_typer(cache_app, name="cache")


@cache_app.command("clear")
def cache_clear(
    root: Annotated[
        Path,
        typer.Argument(help="Project root whose .dead-cst-cache directory should be removed."),
    ] = Path("."),
) -> None:
    """Delete the cached :class:`VisitorPayload` database for ``root``."""
    db = default_cache_path(root.resolve())
    removed = clear_cache(db)
    if removed:
        typer.echo(f"Removed {db}.")
    else:
        typer.echo(f"No cache found at {db}.")


def main_cli() -> None:
    app()


if __name__ == "__main__":
    main_cli()
