"""Tests for import resolution in the symbol graph.

Every case adds a ``p/x.py`` file on top of the shared package fixture
below and asserts the complete set of edges the graph contains.
``IMPORT_BASE_EDGES`` captures the edges that are always present from
the fixture so individual cases only list the edges they introduce.
"""

import logging

import pytest

from dead_cst.plugins._core import EXTERNAL_PREFIXES, STDLIB_PREFIX, UNRESOLVED_PREFIX

IMPORT_TEST_FILES = {
    "p/__init__.py": "",
    "p/functions.py": "def f(): pass\ndef g(): pass",
    "p/classes.py": "class C(): pass",
    "p/chain.py": "from . import functions",
}

# Edges always produced by IMPORT_TEST_FILES plus an (empty-or-populated)
# p/x.py file: module-hierarchy edges, the `p.chain` re-import, and the
# parent edges for p.x itself.
IMPORT_BASE_EDGES = frozenset(
    {
        "p.chain -> p",
        "p.chain.functions -> p.chain",
        "p.chain.functions -> p.functions",
        "p.classes -> p",
        "p.classes.C -> p.classes",
        "p.functions -> p",
        "p.functions.f -> p.functions",
        "p.functions.g -> p.functions",
        "p.x -> p",
    }
)

# Edges from materializing ``from p.functions import *`` (or a synonym)
# into ``p/x.py``: one synthetic re-export per name plus the
# ``module -> synthetic -> target`` chain. Used by every star-shaped
# test case in this file.
STAR_REEXPORT_EDGES = frozenset(
    {
        "p.x -> p.x.f",
        "p.x -> p.x.g",
        "p.x.f -> p.functions",
        "p.x.f -> p.functions.f",
        "p.x.f -> p.x",
        "p.x.g -> p.functions",
        "p.x.g -> p.functions.g",
        "p.x.g -> p.x",
    }
)


@pytest.mark.parametrize(
    "src, expected_extra_edges",
    [
        pytest.param(
            "import p.functions\ndef a(): p.functions.f()",
            {
                "p.x.a -> p.functions",
                "p.x.a -> p.functions.f",
                "p.x.a -> p.x",
                "p.x.a -> p.x.p",
                "p.x.p -> p.functions",
                "p.x.p -> p.x",
            },
            id="cst.Import-dotted-module",
        ),
        pytest.param(
            "from p.functions import f\ndef a(): f()",
            {
                "p.x.a -> p.functions",
                "p.x.a -> p.functions.f",
                "p.x.a -> p.x",
                "p.x.a -> p.x.f",
                "p.x.f -> p.functions",
                "p.x.f -> p.functions.f",
                "p.x.f -> p.x",
            },
            id="cst.ImportFrom-function",
        ),
        pytest.param(
            "from p.classes import C\ndef a(): C.f()",
            {
                "p.x.C -> p.classes",
                "p.x.C -> p.classes.C",
                "p.x.C -> p.x",
                "p.x.a -> p.classes",
                "p.x.a -> p.classes.C",
                "p.x.a -> p.x",
                "p.x.a -> p.x.C",
            },
            id="cst.ImportFrom-class-attribute-access",
        ),
        pytest.param(
            "import p.functions as f\ndef a(): f.f()",
            {
                "p.x.a -> p.functions",
                "p.x.a -> p.functions.f",
                "p.x.a -> p.x",
                "p.x.a -> p.x.f",
                "p.x.f -> p.functions",
                "p.x.f -> p.x",
            },
            id="cst.Import-with-alias",
        ),
        pytest.param(
            "from p import functions as f\ndef a(): f.f()",
            {
                "p.x.a -> p.functions",
                "p.x.a -> p.functions.f",
                "p.x.a -> p.x",
                "p.x.a -> p.x.f",
                "p.x.f -> p.functions",
                "p.x.f -> p.x",
            },
            id="cst.ImportFrom-with-alias",
        ),
        pytest.param(
            "def a(): import p.functions; p.functions.f()",
            {
                "p.x.a -> p.functions",
                "p.x.a -> p.functions.f",
                "p.x.a -> p.x",
            },
            id="nested-cst.Import",
        ),
        pytest.param(
            "def a(): from p.functions import f; f()",
            {
                "p.x.a -> p.functions",
                "p.x.a -> p.functions.f",
                "p.x.a -> p.x",
            },
            id="nested-cst.ImportFrom",
        ),
        pytest.param(
            "from .functions import f\ndef a(): f()",
            {
                "p.x.a -> p.functions",
                "p.x.a -> p.functions.f",
                "p.x.a -> p.x",
                "p.x.a -> p.x.f",
                "p.x.f -> p.functions",
                "p.x.f -> p.functions.f",
                "p.x.f -> p.x",
            },
            id="relative-import",
        ),
        pytest.param(
            "from p.chain import functions as g\ndef a(): g.f()",
            {
                "p.x.a -> p.chain",
                "p.x.a -> p.chain.functions",
                "p.x.a -> p.functions.f",
                "p.x.a -> p.x",
                "p.x.a -> p.x.g",
                "p.x.g -> p.chain",
                "p.x.g -> p.chain.functions",
                "p.x.g -> p.x",
            },
            id="import-chain-via-reexport",
        ),
        pytest.param(
            "from p.functions import f\nfrom p.classes import C\ndef a(): f(); C()",
            {
                "p.x.C -> p.classes",
                "p.x.C -> p.classes.C",
                "p.x.C -> p.x",
                "p.x.a -> p.classes",
                "p.x.a -> p.classes.C",
                "p.x.a -> p.functions",
                "p.x.a -> p.functions.f",
                "p.x.a -> p.x",
                "p.x.a -> p.x.C",
                "p.x.a -> p.x.f",
                "p.x.f -> p.functions",
                "p.x.f -> p.functions.f",
                "p.x.f -> p.x",
            },
            id="multiple-from-imports",
        ),
        pytest.param(
            "import p.functions\n",
            {
                "p.x.p -> p.functions",
                "p.x.p -> p.x",
            },
            id="bare-cst.Import-keeps-module-alive",
        ),
        pytest.param(
            "from p.functions import f\n",
            {
                "p.x.f -> p.functions",
                "p.x.f -> p.functions.f",
                "p.x.f -> p.x",
            },
            id="bare-cst.ImportFrom-keeps-module-alive",
        ),
        pytest.param(
            "from p.functions import f\nf()",
            {
                "p.x -> p.functions",
                "p.x -> p.functions.f",
                "p.x -> p.x.f",
                "p.x.f -> p.functions",
                "p.x.f -> p.functions.f",
                "p.x.f -> p.x",
            },
            id="module-level-call-of-imported-symbol",
        ),
        pytest.param(
            "from p.chain import functions\ndef a(): functions.f()",
            {
                "p.x.a -> p.chain",
                "p.x.a -> p.chain.functions",
                "p.x.a -> p.functions.f",
                "p.x.a -> p.x",
                "p.x.a -> p.x.functions",
                "p.x.functions -> p.chain",
                "p.x.functions -> p.chain.functions",
                "p.x.functions -> p.x",
            },
            id="reexport-through-package-init",
        ),
        pytest.param(
            "import p\ndef a(): p.functions.f()",
            # The access ``p.functions.f`` synthesizes an
            # ``Import(module="p", decl="functions.f")``; the stitcher
            # canonicalizes it to ``module="p.functions"`` because the
            # whole prefix resolves as a submodule, so the edge points
            # at the deepest reached module rather than at ``p``.
            # Reachability of ``p`` itself is still preserved through
            # ``p.x.p -> p`` plus the ``p.functions -> p`` parent-edge.
            {
                "p.x.a -> p.functions",
                "p.x.a -> p.functions.f",
                "p.x.a -> p.x",
                "p.x.a -> p.x.p",
                "p.x.p -> p",
                "p.x.p -> p.x",
            },
            id="import-package-then-dotted-access",
        ),
        pytest.param(
            "from p.functions import *\ndef a(): f()",
            STAR_REEXPORT_EDGES
            | {
                "p.x -> p.functions",
                "p.x -> p.functions.f",
                "p.x -> p.functions.g",
                "p.x.a -> p.x",
            },
            id="star-import-fans-out-to-all-decls",
        ),
        pytest.param(
            "__import__('p.functions')",
            STAR_REEXPORT_EDGES
            | {
                "p.x -> p.functions",
                "p.x -> p.functions.f",
                "p.x -> p.functions.g",
            },
            id="dunder-import-call-fans-out-like-star",
        ),
        pytest.param(
            "def a(): getattr(__import__('p.functions'), 'f')()",
            {
                "p.x.a -> p.functions",
                "p.x.a -> p.functions.f",
                "p.x.a -> p.functions.g",
                "p.x.a -> p.x",
            },
            id="dunder-import-call-inside-function-attributes-to-enclosing-decl",
        ),
        pytest.param(
            "import importlib\nimportlib.import_module('p.functions')",
            STAR_REEXPORT_EDGES
            | {
                "p.x -> p.functions",
                "p.x -> p.functions.f",
                "p.x -> p.functions.g",
                "p.x -> p.x.importlib",
                "p.x.importlib -> p.x",
            },
            id="importlib-import-module-fans-out-like-star",
        ),
        pytest.param(
            "import importlib\ndef a(): importlib.import_module('p.functions')",
            {
                "p.x.a -> p.functions",
                "p.x.a -> p.functions.f",
                "p.x.a -> p.functions.g",
                "p.x.a -> p.x",
                "p.x.a -> p.x.importlib",
                "p.x.importlib -> p.x",
            },
            id="importlib-import-module-inside-function",
        ),
        pytest.param(
            "import importlib\nimportlib.import_module('.functions', 'p')",
            STAR_REEXPORT_EDGES
            | {
                "p.x -> p.functions",
                "p.x -> p.functions.f",
                "p.x -> p.functions.g",
                "p.x -> p.x.importlib",
                "p.x.importlib -> p.x",
            },
            id="importlib-import-module-relative-positional-package",
        ),
        pytest.param(
            "import importlib\nimportlib.import_module('.functions', package='p')",
            STAR_REEXPORT_EDGES
            | {
                "p.x -> p.functions",
                "p.x -> p.functions.f",
                "p.x -> p.functions.g",
                "p.x -> p.x.importlib",
                "p.x.importlib -> p.x",
            },
            id="importlib-import-module-relative-keyword-package",
        ),
        pytest.param(
            "import importlib\nimportlib.import_module('.functions')",
            STAR_REEXPORT_EDGES
            | {
                "p.x -> p.functions",
                "p.x -> p.functions.f",
                "p.x -> p.functions.g",
                "p.x -> p.x.importlib",
                "p.x.importlib -> p.x",
            },
            id="importlib-import-module-relative-uses-enclosing-package",
        ),
        pytest.param(
            "__import__('functions', globals(), locals(), [], 1)",
            STAR_REEXPORT_EDGES
            | {
                "p.x -> p.functions",
                "p.x -> p.functions.f",
                "p.x -> p.functions.g",
            },
            id="dunder-import-positional-level-resolves-relative",
        ),
        pytest.param(
            "__import__('functions', level=1)",
            STAR_REEXPORT_EDGES
            | {
                "p.x -> p.functions",
                "p.x -> p.functions.f",
                "p.x -> p.functions.g",
            },
            id="dunder-import-keyword-level-resolves-relative",
        ),
    ],
)
def test_imports(build_decl_graph, assert_edges, src, expected_extra_edges):
    graph = build_decl_graph({**IMPORT_TEST_FILES, "p/x.py": src})
    assert_edges(graph, IMPORT_BASE_EDGES | expected_extra_edges)


@pytest.mark.parametrize(
    "src, expected_extra_edges",
    [
        pytest.param(
            'from p.functions import f\n__all__ = ["f"]',
            {
                "p.x.__all__ -> p.x",
                "p.x.__all__ -> p.x.f",
                "p.x.f -> p.functions",
                "p.x.f -> p.functions.f",
                "p.x.f -> p.x",
            },
            id="dunder-all-references-import",
        ),
        pytest.param(
            'from p.functions import f\nfrom p.classes import C\n__all__ = ("f", "C")',
            {
                "p.x.C -> p.classes",
                "p.x.C -> p.classes.C",
                "p.x.C -> p.x",
                "p.x.__all__ -> p.x",
                "p.x.__all__ -> p.x.C",
                "p.x.__all__ -> p.x.f",
                "p.x.f -> p.functions",
                "p.x.f -> p.functions.f",
                "p.x.f -> p.x",
            },
            id="dunder-all-tuple-of-imports",
        ),
        pytest.param(
            'def g(): pass\nfrom p.functions import f\n__all__ = ["f", "g"]',
            {
                "p.x.__all__ -> p.x",
                "p.x.__all__ -> p.x.f",
                "p.x.__all__ -> p.x.g",
                "p.x.f -> p.functions",
                "p.x.f -> p.functions.f",
                "p.x.f -> p.x",
                "p.x.g -> p.x",
            },
            id="dunder-all-mixes-local-and-imported",
        ),
        pytest.param(
            'from p.functions import f\n__all__: list[str] = ["f"]',
            {
                "p.x.__all__ -> p.x",
                "p.x.__all__ -> p.x.f",
                "p.x.f -> p.functions",
                "p.x.f -> p.functions.f",
                "p.x.f -> p.x",
            },
            id="dunder-all-annotated-assignment",
        ),
        pytest.param(
            'from p.functions import f\n__all__ = ["missing"]',
            {
                "p.x.__all__ -> p.x",
                "p.x.f -> p.functions",
                "p.x.f -> p.functions.f",
                "p.x.f -> p.x",
            },
            id="dunder-all-unknown-name-is-ignored",
        ),
    ],
)
def test_dunder_all_edges(build_decl_graph, assert_edges, src, expected_extra_edges):
    graph = build_decl_graph({**IMPORT_TEST_FILES, "p/x.py": src})
    assert_edges(graph, IMPORT_BASE_EDGES | expected_extra_edges)


def test_dynamic_import_non_literal_warns(build_decl_graph, visitor_warnings):
    """Non-literal ``__import__(name)`` / ``importlib.import_module(name)`` skip with a warning."""
    build_decl_graph(
        {
            "p/__init__.py": "",
            "p/x.py": (
                "import importlib\n"
                "name = 'p.functions'\n"
                "def a(): __import__(name)\n"
                "def b(): importlib.import_module(name)\n"
            ),
        }
    )

    messages = visitor_warnings()
    assert any("Skipping dynamic import '__import__(...)'" in m for m in messages), messages
    assert any("Skipping dynamic import 'importlib.import_module(...)'" in m for m in messages), (
        messages
    )


@pytest.mark.parametrize(
    "src",
    [
        pytest.param("__import__('p', None, None, ['functions'])", id="fromlist-positional"),
        pytest.param("__import__('p', fromlist=['functions'])", id="fromlist-keyword"),
    ],
)
def test_dunder_import_fromlist_resolves_submodules(build_decl_graph, assert_edges, src):
    """Literal ``fromlist`` entries that resolve as submodules are fanned out too."""
    graph = build_decl_graph({**IMPORT_TEST_FILES, "p/x.py": src})
    assert_edges(
        graph,
        IMPORT_BASE_EDGES
        | STAR_REEXPORT_EDGES
        | {
            "p.x -> p.functions",
            "p.x -> p.functions.f",
            "p.x -> p.functions.g",
        },
    )


def test_dunder_import_fromlist_attribute_entries_silent(
    build_decl_graph, assert_edges, visitor_warnings
):
    """Fromlist entries that are not submodules don't warn (already covered by name fan-out)."""
    graph = build_decl_graph(
        {**IMPORT_TEST_FILES, "p/x.py": "__import__('p.functions', fromlist=['f', ''])"}
    )

    assert visitor_warnings() == []
    assert_edges(
        graph,
        IMPORT_BASE_EDGES
        | STAR_REEXPORT_EDGES
        | {
            "p.x -> p.functions",
            "p.x -> p.functions.f",
            "p.x -> p.functions.g",
        },
    )


@pytest.mark.parametrize(
    "src, fragment",
    [
        pytest.param(
            "__import__('.functions')",
            "leading dots are invalid for __import__",
            id="dunder-import-leading-dot-name",
        ),
        pytest.param(
            "level = 1\n__import__('functions', level=level)",
            "level is not an int literal",
            id="dunder-import-non-literal-level",
        ),
        pytest.param(
            "import importlib\npkg = 'p'\nimportlib.import_module('.functions', package=pkg)",
            "package is not a string literal",
            id="importlib-non-literal-package",
        ),
    ],
)
def test_dynamic_import_relative_warnings(build_decl_graph, visitor_warnings, src, fragment):
    build_decl_graph({**IMPORT_TEST_FILES, "p/x.py": src})
    messages = visitor_warnings()
    assert any(fragment in m for m in messages), messages


def test_dunder_import_fromlist_non_literal_warns(build_decl_graph, visitor_warnings):
    """Non-literal fromlists warn (we can't enumerate entries)."""
    build_decl_graph(
        {
            **IMPORT_TEST_FILES,
            "p/x.py": "names = ['functions']\n__import__('p', fromlist=names)",
        }
    )

    messages = visitor_warnings()
    assert any("fromlist is not a literal" in m and "'p'" in m for m in messages), messages


def test_third_party_import_creates_synthetic_node(build_decl_graph):
    graph = build_decl_graph(
        {
            "p/__init__.py": "",
            "p/uses_rx.py": "import rustworkx as rx\ndef build(): return rx.PyDiGraph()",
        }
    )
    rx_nodes = {
        n
        for n in graph.nodes
        if n.type == "synthetic"
        and n.fqname.startswith(EXTERNAL_PREFIXES)
        and "rustworkx" in n.fqname
    }
    assert rx_nodes, (
        "expected an external-dep synthetic node for rustworkx, got "
        f"{[n.fqname for n in graph.nodes if n.type == 'synthetic']}"
    )

    edge_srcs = {
        graph.node(u).fqname for u, v in graph.raw.edge_list() if graph.node(v) in rx_nodes
    }
    assert {"p.uses_rx.rx", "p.uses_rx.build"} <= edge_srcs


def test_stdlib_imports_are_silent(build_decl_graph, caplog):
    """Stdlib imports drop without surfacing a synthetic node or a warning."""
    with caplog.at_level(logging.WARNING, logger="dead_cst._edges"):
        graph = build_decl_graph(
            {
                "p/__init__.py": "",
                "p/uses_stdlib.py": (
                    "import datetime\n"
                    "import os\n"
                    "from pathlib import Path\n"
                    "from collections.abc import Iterable\n"
                ),
            }
        )

    assert [r.getMessage() for r in caplog.records] == []
    synthetics = {n.fqname for n in graph.nodes if n.type == "synthetic"}
    # No stdlib ever surfaces as a graph node, and ``collections.abc``
    # must not fall through to ``[unresolved] collections`` (regression
    # against the synthesized-submodule parent-fallback).
    assert not [fq for fq in synthetics if fq.startswith(STDLIB_PREFIX)]
    assert f"{UNRESOLVED_PREFIX}collections" not in synthetics


def test_unresolved_import_emits_synthetic_silently(build_decl_graph, caplog):
    """A genuinely-missing top-level import gets a ``[unresolved]`` node, no warning."""
    with caplog.at_level(logging.WARNING, logger="dead_cst._edges"):
        graph = build_decl_graph(
            {
                "p/__init__.py": "",
                "p/uses_missing.py": "from unknown_pkg_xyz import thing\n",
            }
        )

    assert [r.getMessage() for r in caplog.records] == []
    assert any(
        n.type == "synthetic" and n.fqname == f"{UNRESOLVED_PREFIX}unknown_pkg_xyz"
        for n in graph.nodes
    )


def test_module_runtime_dunder_access_is_module_dep(build_decl_graph, assert_edges, caplog):
    """``pkg.__file__`` collapses to a plain ``Import(module=pkg, decl=None)``.

    The import machinery injects ``__file__`` / ``__name__`` / ``__spec__`` /
    etc. onto every module object at runtime -- attribute access past one of
    these is a path / string op, not a symbol reference. The visitor truncates
    the access chain at the dunder so the edge stitcher sees a clean module-
    level dependency (no speculative ``decl="__file__"`` that it would warn
    about, no synthetic node for the missing attribute).
    """
    with caplog.at_level(logging.WARNING, logger="dead_cst._edges"):
        graph = build_decl_graph(
            {
                "pkg/__init__.py": "",
                "pkg/config.py": (
                    "from pathlib import Path\n"
                    "import pkg as pkg_alias\n"
                    "FILE_PATH = Path(pkg_alias.__file__).parent\n"
                    "NAME = pkg_alias.__name__\n"
                    "SPEC = pkg_alias.__spec__\n"
                ),
            }
        )

    assert [r.getMessage() for r in caplog.records] == []
    # No synthetic was minted for the missing-dunder lookup.
    assert not [n.fqname for n in graph.nodes if n.fqname.endswith(".__file__")]
    # The module-level dependency edges remain intact for each user of a dunder.
    edge_strs = {
        f"{graph.node(u).fqname} -> {graph.node(v).fqname}" for u, v in graph.raw.edge_list()
    }
    assert "pkg.config.FILE_PATH -> pkg" in edge_strs
    assert "pkg.config.NAME -> pkg" in edge_strs
    assert "pkg.config.SPEC -> pkg" in edge_strs


def test_dunder_on_imported_symbol_strips_dunder_tail(build_decl_graph, assert_edges):
    """``from pkg import Cls; Cls.__name__`` -> edge to ``Cls``, not ``Cls.__name__``.

    Regression guard for the visitor-level dunder strip: the truncation
    drops the dunder *and everything after it*, so an access through an
    imported symbol still resolves to that symbol (not past it).
    """
    graph = build_decl_graph(
        {
            "pkg/__init__.py": "",
            "pkg/lib.py": "class Cls:\n    pass\n",
            "pkg/uses.py": ("from pkg.lib import Cls\nWHO = Cls.__name__\nDOCSTR = Cls.__doc__\n"),
        }
    )
    edge_strs = {
        f"{graph.node(u).fqname} -> {graph.node(v).fqname}" for u, v in graph.raw.edge_list()
    }
    assert "pkg.uses.WHO -> pkg.lib.Cls" in edge_strs
    assert "pkg.uses.DOCSTR -> pkg.lib.Cls" in edge_strs


def test_cyclic_reexport_terminates(build_decl_graph, assert_edges):
    """Re-export cycle (``A.x: from B import x``, ``B.x: from A import x``) terminates with both legs emitted."""
    graph = build_decl_graph(
        {
            "A.py": "from B import x",
            "B.py": "from A import x",
            "main.py": "from A import x\nx()",
        }
    )

    assert_edges(
        graph,
        {
            "A.x -> A",
            "A.x -> A.x",
            "A.x -> B",
            "A.x -> B.x",
            "B.x -> A",
            "B.x -> A.x",
            "B.x -> B",
            "B.x -> B.x",
            "main -> A",
            "main -> A.x",
            "main -> B.x",
            "main -> main.x",
            "main.x -> A",
            "main.x -> A.x",
            "main.x -> B.x",
            "main.x -> main",
        },
    )


def test_import_resolves_through_star_reexport(build_decl_graph, assert_edges):
    """``from pkg import g`` resolves through ``from pkg._internal import *``."""
    graph = build_decl_graph(
        {
            "pkg/__init__.py": "from pkg._internal import *\n",
            "pkg/_internal.py": "def g(): pass\n",
            "consumer.py": "from pkg import g\ng()\n",
        }
    )
    edge_strs = {
        f"{graph.node(u).fqname} -> {graph.node(v).fqname}" for u, v in graph.raw.edge_list()
    }
    assert "consumer.g -> pkg._internal.g" in edge_strs
    assert "consumer.g -> pkg.g" in edge_strs


def test_import_resolves_through_chained_star_reexports(build_decl_graph, assert_edges):
    """``from A import g`` follows ``A -> B -> C`` star chain to ``C.g``."""
    graph = build_decl_graph(
        {
            "A.py": "from B import *\n",
            "B.py": "from C import *\n",
            "C.py": "def g(): pass\n",
            "consumer.py": "from A import g\ng()\n",
        }
    )
    edge_strs = {
        f"{graph.node(u).fqname} -> {graph.node(v).fqname}" for u, v in graph.raw.edge_list()
    }
    assert "consumer.g -> C.g" in edge_strs


def test_star_reexport_cycle_terminates(build_decl_graph, assert_edges):
    """Mutual ``from B import *`` / ``from A import *`` terminates without spinning."""
    graph = build_decl_graph(
        {
            "A.py": "from B import *\ndef a(): pass\n",
            "B.py": "from A import *\ndef b(): pass\n",
            "consumer.py": "from A import b\n",
        }
    )
    edge_strs = {
        f"{graph.node(u).fqname} -> {graph.node(v).fqname}" for u, v in graph.raw.edge_list()
    }
    assert "consumer.b -> B.b" in edge_strs


def test_star_reexport_shadowed_by_real_decl(build_decl_graph, assert_edges):
    """A real decl in the importing module wins over a star re-export of the same name."""
    graph = build_decl_graph(
        {
            "other.py": "def g(): pass\n",
            "mod.py": "from other import *\ndef g(): return 1\n",
            "consumer.py": "from mod import g\ng()\n",
        }
    )
    edge_strs = {
        f"{graph.node(u).fqname} -> {graph.node(v).fqname}" for u, v in graph.raw.edge_list()
    }
    assert "consumer.g -> mod.g" in edge_strs
    assert "consumer.g -> other.g" not in edge_strs


def test_star_reexport_is_skipped_by_codemod(build_decl_graph, tmp_path, assert_edges):
    """Star re-export synthetics carry ``STAR_REEXPORT`` and stay out of the codemod's hands."""
    from dead_cst.graph import NodeFlags

    graph = build_decl_graph(
        {
            "pkg/__init__.py": "from pkg._internal import *\n",
            "pkg/_internal.py": "def g(): pass\n",
        }
    )
    reexports = [
        n for n in graph.nodes if n.fqname == "pkg.g" and n.flags & NodeFlags.STAR_REEXPORT
    ]
    assert len(reexports) == 1, [n.fqname for n in graph.nodes if "pkg" in n.fqname]


def test_star_reexport_inherits_exported_from_importing_module(tmp_path, make_analysis):
    """A re-export's ``EXPORTED`` flag mirrors the importing module's."""
    from dead_cst.graph import NodeFlags
    from dead_cst.resolvers import ManualResolver, Package

    (tmp_path / "mypkg").mkdir()
    (tmp_path / "mypkg" / "__init__.py").write_text("from mypkg._impl import *\n")
    (tmp_path / "mypkg" / "_impl.py").write_text("def g(): pass\n")
    (tmp_path / "mypkg" / "api").mkdir()
    (tmp_path / "mypkg" / "api" / "__init__.py").write_text("from mypkg._impl import *\n")

    class FixedResolver:
        name = "fixed"
        version = 0

        def resolve(self, project_root):
            return (
                Package(
                    path=tmp_path,
                    name="mypkg",
                    exported=(tmp_path / "mypkg" / "api",),
                    deps=(),
                ),
            )

        def resolve_import(self, name, search_paths):
            return ManualResolver(specs=[]).resolve_import(name, search_paths)

    analysis = make_analysis(resolver=FixedResolver())
    graph = analysis.materialize_all()

    by_fqname: dict[str, list] = {}
    for n in graph.nodes:
        if n.flags & NodeFlags.STAR_REEXPORT:
            by_fqname.setdefault(n.fqname, []).append(n)

    # ``mypkg.api.g`` lives in an exported file -> EXPORTED set.
    assert "mypkg.api.g" in by_fqname, list(by_fqname)
    assert all(n.flags & NodeFlags.EXPORTED for n in by_fqname["mypkg.api.g"])

    # ``mypkg.g`` lives in a non-exported file -> EXPORTED not set.
    assert "mypkg.g" in by_fqname, list(by_fqname)
    assert not any(n.flags & NodeFlags.EXPORTED for n in by_fqname["mypkg.g"])


def test_star_reexport_crosses_packages(tmp_path, make_analysis, assert_edges):
    """``from dep import *`` in a consumer materializes against the dep's trie."""
    pkg_a = tmp_path / "pkg_a"
    pkg_b = tmp_path / "pkg_b"
    (pkg_a / "A").mkdir(parents=True)
    (pkg_b / "B").mkdir(parents=True)
    (pkg_a / "A" / "__init__.py").write_text("def g(): pass\n")
    (pkg_b / "B" / "__init__.py").write_text("from A import *\n")

    graph = make_analysis(["pkg_b:pkg_a", "pkg_a"]).materialize_all()
    edge_strs = {
        f"{graph.node(u).fqname} -> {graph.node(v).fqname}" for u, v in graph.raw.edge_list()
    }
    assert "B.g -> A.g" in edge_strs
    assert "B -> B.g" in edge_strs


def test_cross_dep_submodule_import(tmp_path, make_analysis, assert_edges):
    """Importing a submodule from a dep base resolves through the dep's exported trie.

    Layout:
        pkg_a/A/__init__.py  -- empty package
        pkg_a/A/sub.py       -- def f(): ...
        pkg_b/B/__init__.py  -- from A import sub; sub.f()

    Packages: pkg_b(deps=("pkg_a",)), pkg_a(deps=())

    ``A.sub`` lives in the dep's exported trie, not the consumer's own
    trie. ``resolve_edges`` must find it via the merged ``symbol_lookup``
    and follow the submodule through ``cur.children`` (since ``A/__init__.py``
    has no explicit ``import sub`` declaration -- the name resolves as a
    real submodule path).
    """
    pkg_a = tmp_path / "pkg_a"
    pkg_b = tmp_path / "pkg_b"
    (pkg_a / "A").mkdir(parents=True)
    (pkg_b / "B").mkdir(parents=True)
    (pkg_a / "A" / "__init__.py").write_text("")
    (pkg_a / "A" / "sub.py").write_text("def f(): ...\n")
    (pkg_b / "B" / "__init__.py").write_text("from A import sub\nsub.f()\n")

    graph = make_analysis(["pkg_b:pkg_a", "pkg_a"]).materialize_all()
    assert_edges(
        graph,
        {
            "A.sub -> A",
            "A.sub.f -> A.sub",
            "B -> A.sub",
            "B -> A.sub.f",
            "B -> B.sub",
            "B.sub -> A.sub",
            "B.sub -> B",
        },
    )
