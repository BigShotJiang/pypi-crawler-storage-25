# coding=utf-8
# ======================================
# File:     trading_util.py
# Author:   Jackie PENG
# Contact:  jackie.pengzhao@gmail.com
# Created:  2023-02-20
# Desc:
#   utility functions that may be shared
# between live-trading, back-testing, 
# optimization and other trading-related
# modules.
# ======================================

import os
import warnings
from dataclasses import dataclass
import datetime as dt

import pandas as pd
import numpy as np
from typing import NamedTuple, Optional, Union

from numba import njit

from qteasy.__init__ import logger_core as logger
from qteasy.qt_operator import Operator
from qteasy.configure import QT_CONFIG
from qteasy.utilfuncs import (
    get_current_timezone_datetime,
    regulate_date_format, str_to_list,
    nearest_market_trade_day,
    next_market_trade_day,
    pandas_freq_alias_version_conversion,
    sanitize_filename,
)

from qteasy.finance import get_purchase_result, get_selling_result

from qteasy.trade_recording import (
    read_trade_order,
    get_position_by_id,
    get_account,
    update_trade_order,
    read_trade_order_detail,
    read_trade_results_by_delivery_status,
    write_trade_result,
    read_trade_result_by_broker_result_id,
    read_trade_results_by_order_id,
    get_account_cash_availabilities,
    update_account_balance,
    update_position,
    update_trade_result,
    query_trade_orders,
    get_account_positions,
)


CASH_DECIMAL_PLACES = QT_CONFIG['cash_decimal_places']
AMOUNT_DECIMAL_PLACES = QT_CONFIG['amount_decimal_places']


@dataclass(frozen=True)
class ScheduleTaskSpec:
    """日程任务规范结构（任务名 + 参数元组）。"""

    name: str
    args: tuple = ()

    def as_legacy(self) -> Union[str, tuple]:
        """导出历史兼容任务表示（str 或 (name, payload)）。"""
        if not self.args:
            return self.name
        if len(self.args) == 1 and self.name == 'run_strategy':
            return self.name, self.args[0]
        return self.name, self.args


@dataclass(frozen=True)
class ScheduledTask:
    """标准化日程项（执行时间 + 任务规范）。"""

    task_time: str
    task_spec: ScheduleTaskSpec

    def as_legacy_tuple(self) -> tuple:
        """导出历史兼容 tuple。"""
        legacy = self.task_spec.as_legacy()
        if isinstance(legacy, tuple):
            return (self.task_time,) + legacy
        return self.task_time, legacy


def build_operator_schedule_time_kwargs(market_open_time_am: str,
                                        market_close_time_am: str,
                                        market_open_time_pm: str,
                                        market_close_time_pm: str,
                                        include_start_am: bool = True,
                                        include_end_am: bool = True,
                                        include_start_pm: bool = True,
                                        include_end_pm: bool = True,
                                        ) -> dict:
    """构建 ``Operator.prepare_running_schedule()`` 的统一时段参数。"""

    return {
        'start_am':         market_open_time_am,
        'end_am':           market_close_time_am,
        'include_start_am': include_start_am,
        'include_end_am':   include_end_am,
        'start_pm':         market_open_time_pm,
        'end_pm':           market_close_time_pm,
        'include_start_pm': include_start_pm,
        'include_end_pm':   include_end_pm,
    }


def apply_schedule_catch_up_policy(task_schedule: list,
                                   current_time: dt.time,
                                   market_open_time_am: str,
                                   market_close_time_am: str,
                                   market_open_time_pm: str,
                                   market_close_time_pm: str,
                                   ) -> list:
    """按盘中启动追赶策略过滤当日未过期任务。

    该函数只负责“保留哪些过期关键任务”，不改变任务先后顺序与任务内容。
    """

    def _task_name(task):
        if isinstance(task, ScheduledTask):
            return task.task_spec.name
        return task[1]

    def _task_time(task):
        if isinstance(task, ScheduledTask):
            return pd.to_datetime(task.task_time).time()
        return pd.to_datetime(task[0]).time()

    moa = pd.to_datetime(market_open_time_am).time()
    mca = pd.to_datetime(market_close_time_am).time()
    moc = pd.to_datetime(market_open_time_pm).time()
    mcc = pd.to_datetime(market_close_time_pm).time()

    if current_time < moa:
        return task_schedule
    if moa < current_time < mca:
        keep_names = {'pre_open', 'open_market'}
    elif mca < current_time < moc:
        keep_names = {'pre_open', 'open_market', 'close_market'}
    elif moc < current_time < mcc:
        keep_names = {'pre_open', 'open_market', 'close_market'}
    elif mcc < current_time:
        keep_names = {'pre_open', 'post_close'}
    else:
        raise ValueError(f'Invalid current time: {current_time}')

    return [
        task for task in task_schedule
        if (_task_time(task) >= current_time) or (_task_name(task) in keep_names)
    ]


def create_daily_task_plan(operator,
                           is_trade_day: bool = True,
                           exchange_market: str = 'SSE',
                           market_open_time_am: str = '09:30:00',
                           market_close_time_am: str = '11:30:00',
                           market_open_time_pm: str = '13:00:00',
                           market_close_time_pm: str = '15:00:00',
                           open_close_timing_offset: int = 0,
                           daily_refill_tables: str = '',
                           weekly_refill_tables: str = '',
                           monthly_refill_tables: str = '',
                           live_price_frequency: str = '1min',
    current_date=None,
                           ) -> list[ScheduledTask]:
    """生成标准化的每日任务计划（阶段3调度适配层）。"""

    if current_date is None:
        current_date = get_current_timezone_datetime().date()
    current_date = pd.to_datetime(current_date).date()
    tomorrow = current_date + pd.Timedelta(days=1)

    # 保留原 create_daily_task_schedule 的行为：通过 next_market_trade_day 取得交易日并据此生成日内网格
    from qteasy.utilfuncs import next_market_trade_day
    a_trade_day = next_market_trade_day(current_date, exchange=exchange_market)

    if not isinstance(operator, Operator):
        raise TypeError(f'operator must be an Operator object, got {type(operator)} instead.')

    task_plan: list[ScheduledTask] = []

    # 调整任务时间，开盘任务在开盘时执行，收盘任务在收盘时执行，sleep和wakeup任务在开盘前后5分钟执行
    open_close_lead = 0
    noon_close_delay = 5
    pre_open_lead = 15
    post_close_delay = 15
    data_source_delay = 30
    market_open_time = (pd.to_datetime(market_open_time_am) -
                        pd.Timedelta(minutes=open_close_lead)).strftime('%H:%M:%S')
    market_close_time = (pd.to_datetime(market_close_time_pm) +
                         pd.Timedelta(minutes=open_close_lead)).strftime('%H:%M:%S')
    pre_open_time = (pd.to_datetime(market_open_time_am) -
                     pd.Timedelta(minutes=pre_open_lead)).strftime('%H:%M:%S')
    wakeup_time_pm = (pd.to_datetime(market_open_time_pm) -
                      pd.Timedelta(minutes=noon_close_delay)).strftime('%H:%M:%S')
    sleep_time_am = (pd.to_datetime(market_close_time_am) +
                     pd.Timedelta(minutes=noon_close_delay)).strftime('%H:%M:%S')
    post_close_time = (pd.to_datetime(market_close_time_pm) +
                       pd.Timedelta(minutes=post_close_delay)).strftime('%H:%M:%S')
    data_source_refilling_time = (pd.to_datetime(market_close_time_pm) +
                                  pd.Timedelta(minutes=data_source_delay)).strftime('%H:%M:%S')

    if is_trade_day:
        if a_trade_day is not None:
            the_next_day = (a_trade_day + pd.Timedelta(days=1)).strftime('%Y-%m-%d')
        else:
            raise ValueError(f'no next trade day of today({current_date})')

        price_time_kwargs = build_operator_schedule_time_kwargs(
            market_open_time_am=market_open_time_am,
            market_close_time_am=market_close_time_am,
            market_open_time_pm=market_open_time_pm,
            market_close_time_pm=market_close_time_pm,
            include_start_am=False,
            include_end_am=True,
            include_start_pm=False,
            include_end_pm=True,
        )
        price_filling_time_index = trade_time_index(
            start=a_trade_day,
            end=the_next_day,
            freq=live_price_frequency,
            **price_time_kwargs,
        ).strftime('%H:%M:%S').tolist()
        for t in price_filling_time_index:
            tt = (pd.to_datetime(t) + pd.Timedelta(seconds=5)).strftime('%H:%M:%S')
            task_plan.append(ScheduledTask(tt, ScheduleTaskSpec('acquire_live_price')))

        operator.prepare_running_schedule(
            start_date=current_date,
            end_date=tomorrow,
            trade_days_only=False,
            **build_operator_schedule_time_kwargs(
                market_open_time_am=market_open_time_am,
                market_close_time_am=market_close_time_am,
                market_open_time_pm=market_open_time_pm,
                market_close_time_pm=market_close_time_pm,
                include_start_am=True,
                include_end_am=True,
                include_start_pm=True,
                include_end_pm=True,
            ),
        )
        stg_run_time_index = operator.group_timing_table.index.strftime('%H:%M:%S').tolist()
        split_prepare = bool(QT_CONFIG.get('live_trade_split_strategy_prepare', False))
        lead_sec = int(QT_CONFIG.get('live_trade_prepare_lead_seconds', 5))
        day_str = a_trade_day.strftime('%Y-%m-%d')
        for signal_index, t in enumerate(stg_run_time_index):
            if split_prepare:
                run_dt = pd.Timestamp(f'{day_str} {t}')
                prep_dt = run_dt - pd.Timedelta(seconds=lead_sec)
                prep_t = prep_dt.strftime('%H:%M:%S')
                task_plan.append(ScheduledTask(prep_t, ScheduleTaskSpec('prepare_strategy_snapshot', (signal_index,))))
            task_plan.append(ScheduledTask(t, ScheduleTaskSpec('run_strategy', (signal_index,))))

        open_close_timing_offset = int(open_close_timing_offset)
        if open_close_timing_offset > 0:
            market_open_dt = pd.to_datetime(market_open_time)
            market_close_dt = pd.to_datetime(market_close_time)
            offset_plan = []
            for item in task_plan:
                if item.task_spec.name not in ('run_strategy', 'prepare_strategy_snapshot'):
                    offset_plan.append(item)
                    continue
                task_time = pd.to_datetime(item.task_time)
                if task_time <= market_open_dt:
                    task_time = task_time + pd.Timedelta(minutes=open_close_timing_offset)
                elif task_time >= market_close_dt:
                    task_time = task_time - pd.Timedelta(minutes=open_close_timing_offset)
                offset_plan.append(
                    ScheduledTask(task_time.strftime('%H:%M:%S'), item.task_spec)
                )
            task_plan = offset_plan

        task_plan.extend([
            ScheduledTask(market_open_time, ScheduleTaskSpec('open_market')),
            ScheduledTask(pre_open_time, ScheduleTaskSpec('pre_open')),
            ScheduledTask(sleep_time_am, ScheduleTaskSpec('close_market')),
            ScheduledTask(wakeup_time_pm, ScheduleTaskSpec('open_market')),
            ScheduledTask(market_close_time, ScheduleTaskSpec('close_market')),
            ScheduledTask(post_close_time, ScheduleTaskSpec('post_close')),
        ])

    if daily_refill_tables and is_trade_day:
        task_plan.append(
            ScheduledTask(data_source_refilling_time, ScheduleTaskSpec('refill', (daily_refill_tables, 1)))
        )
    if current_date.weekday() == 4 and weekly_refill_tables:
        task_plan.append(
            ScheduledTask(data_source_refilling_time, ScheduleTaskSpec('refill', (weekly_refill_tables, 7)))
        )
    if current_date.day == 1 and monthly_refill_tables:
        task_plan.append(
            ScheduledTask(data_source_refilling_time, ScheduleTaskSpec('refill', (monthly_refill_tables, 31)))
        )

    def _scheduled_task_sort_key(st: ScheduledTask) -> tuple:
        """同一时刻任务排序：prepare_strategy_snapshot 先于 run_strategy。"""
        name = st.task_spec.name
        if name == 'prepare_strategy_snapshot':
            pri = 0
        elif name == 'run_strategy':
            pri = 1
        elif name == 'acquire_live_price':
            pri = 2
        else:
            pri = 9
        return st.task_time, pri

    task_plan.sort(key=_scheduled_task_sort_key)
    return task_plan


def create_daily_task_schedule(operator,
                               is_trade_day: bool = True,
                               exchange_market: str = 'SSE',
                               market_open_time_am: str = '09:30:00',
                               market_close_time_am: str = '11:30:00',
                               market_open_time_pm: str = '13:00:00',
                               market_close_time_pm: str = '15:00:00',
                               open_close_timing_offset: int = 0,
                               daily_refill_tables: str = '',
                               weekly_refill_tables: str = '',
                               monthly_refill_tables: str = '',
                               live_price_frequency: str = '1min',
                               current_date=None,
                               ) -> list[tuple]:
    """ 根据operator对象中的交易策略以及环境变量生成每日任务日程

    每日任务日程包括含 sleep / wake_up / run_stg 等所有有效任务类型的任务列表，
    以及每项任务在正常交易日内的执行时间

    Parameters
    ----------
    operator: Operator
        交易策略的Operator对象
    is_trade_day: bool, optional
        是否是交易日, 默认为True
    exchange_market: str, optional, default 'SSE'
        交易市场, 默认为'SSE'
    market_open_time_am: str, optional, default '09:30:00'
        交易市场上午开盘时间, 格式为'HH:MM:SS'
    market_close_time_am: str, optional, default '11:30:00'
        交易市场上午收盘时间, 格式为'HH:MM:SS'
    market_open_time_pm: str, optional, default '13:00:00'
        交易市场下午开盘时间, 格式为'HH:MM:SS'
    market_close_time_pm: str, optional, default '15:00:00'
        交易市场下午收盘时间, 格式为'HH:MM:SS'
    open_close_timing_offset: int, optional, default 0
        交易市场开收盘时间偏移量, 单位为分钟, 默认为0
    daily_refill_tables: str, optional, default ''
        每日补充DataSource数据库的任务列表, 格式为'table1,table2,table3'
    weekly_refill_tables: str, optional, default ''
        每周补充DataSource数据库的任务列表, 格式为'table1,table2,table3'
    monthly_refill_tables: str, optional, default ''
        每月补充DataSource数据库的任务列表, 格式为'table1,table2,table3'
    live_price_frequency: str, optional, default '1min'
        实时价格获取频率, 格式为pandas的时间频率字符串, 如'1min', '5min', '15min'等
    current_date: date-like, optional
        计划生成使用的交易日期；为 None 时使用当前本地日期。

    Returns
    -------
    task_agenda: list of tuple [(datetime.time, str, optional: list of str)]
        每日任务日程, 每项任务是一个tuple, 包含任务的执行时间, 任务的名称, 以及任务的参数列表(optional)
    """
    # 检查输入数据的类型是否正确
    if not isinstance(operator, Operator):
        raise TypeError(f'operator must be an Operator object, got {type(operator)} instead.')

    task_plan = create_daily_task_plan(
        operator=operator,
        is_trade_day=is_trade_day,
        exchange_market=exchange_market,
        market_open_time_am=market_open_time_am,
        market_close_time_am=market_close_time_am,
        market_open_time_pm=market_open_time_pm,
        market_close_time_pm=market_close_time_pm,
        open_close_timing_offset=open_close_timing_offset,
        daily_refill_tables=daily_refill_tables,
        weekly_refill_tables=weekly_refill_tables,
        monthly_refill_tables=monthly_refill_tables,
        live_price_frequency=live_price_frequency,
        current_date=current_date,
    )
    return [item.as_legacy_tuple() for item in task_plan]


# Utility functions for live trade
# @njit()
def parse_live_trade_signal(signals,
                            signal_type,
                            shares,
                            prices,
                            own_amounts,
                            own_cash,
                            available_amounts=None,
                            available_cash=None,
                            cost_params: np.ndarray = np.array([0., 0., 0., 0., 0.,]),
                            pt_buy_threshold: float = 0.0,
                            pt_sell_threshold: float = 0.0,
                            allow_sell_short: bool = False,
                            trade_batch_size: float = 0.01,
                            sell_batch_size: float = 0.01,
                            long_position_limit: float = 1.0,
                            short_position_limit: float = -1.0,
                            cash_delivery_period: int = 0,
                            ) -> tuple[list[str], list[str], list[str], list[float], list[float], list[str]]:
    """ 根据signal_type的值，将operator生成的qt交易信号解析为标准的交易订单元素，包括
    资产代码、头寸类型、交易方向、交易数量等, 不检查账户的可用资金和持仓数量

    Parameters
    ----------
    signals: np.ndarray
        交易信号
    signal_type: str, {'PT', 'PS', 'VS'}
        交易信号类型
    shares: list of str
        股票代码
    prices: np.ndarray
        股票价格
    own_amounts: np.ndarray
        股票持仓数量, 与shares对应, 顺序一致, 无持仓的股票数量为0, 负数表示空头持仓
    own_cash: float
        账户可用资金总额
    available_amounts: np.ndarray
        股票可用持仓数量, 与shares对应, 顺序一致, 无持仓的股票数量为0, 负数表示空头持仓
    available_cash: float
        账户可用资金总额
    cost_params: np.ndarray, default=get_cost_params()
        交易成本参数, 一个长度为5的数组，包含以下内容：
        [0] - buy_rate: float, 交易成本：固定买入费率
        [1] - sell_rate: float, 交易成本：固定卖出费率
        [2] - buy_min: float, 交易成本：最低买入费用
        [3] - sell_min: float, 交易成本：最低卖出费用
        [4] - slippage: float, 交易成本：滑点
    pt_buy_threshold: float, default=0.0
        PT买入阈值
    pt_sell_threshold: float, default=0.0
        PT卖出阈值
    allow_sell_short: bool, default=False
        是否允许卖空
    trade_batch_size: float, default=0.01
        买入交易批量大小
    sell_batch_size: float, default=0.01
        卖出交易批量大小
    long_position_limit: float, default=1.0
        多头持仓限制
    short_position_limit: float, default=-1.0
        空头持仓限制
    cash_delivery_period: int, default=0
        现金交割周期；与回测一致，``PT`` 且为 ``0`` 时买入意图可计入本期卖出现金预览。

    Returns
    -------
    order_elements: tuple, (symbols, positions, directions, quantities, quoted_prices)
        symbols: list of str, 交易信号对应的股票代码
        positions: list of str, 交易信号对应的持仓类型
        directions: list of str, 交易信号对应的交易方向
        quantities: list of float, 交易信号对应的交易数量
        quoted_prices: list of float, 交易信号对应的交易价格
    """

    # 处理optional参数:
    # 如果没有提供可用资金和持仓数量，使用当前的资金和持仓数量
    if available_amounts is None:
        available_amounts = own_amounts
    if available_cash is None:
        available_cash = own_cash

    # 在进入 numba 解析函数前统一参数形状和类型，避免广播错误信息不明确
    signals = np.asarray(signals, dtype=np.float64).ravel()
    prices = np.asarray(prices, dtype=np.float64).ravel()
    own_amounts = np.asarray(own_amounts, dtype=np.float64).ravel()
    available_amounts = np.asarray(available_amounts, dtype=np.float64).ravel()
    own_cash_values = np.asarray(own_cash, dtype=np.float64).ravel()
    available_cash_values = np.asarray(available_cash, dtype=np.float64).ravel()
    if own_cash_values.size == 0:
        raise ValueError('parse_live_trade_signal: own_cash must contain at least one value.')
    if available_cash_values.size == 0:
        raise ValueError('parse_live_trade_signal: available_cash must contain at least one value.')
    own_cash = float(own_cash_values[0])
    available_cash = float(available_cash_values[0])

    _sig_len = signals.size
    _prc_len = prices.size
    _amt_len = own_amounts.size
    _avail_len = available_amounts.size
    if not (_sig_len == _prc_len == _amt_len == _avail_len):
        raise ValueError(
            f'parse_live_trade_signal: array length mismatch! '
            f'signals({_sig_len}) vs prices({_prc_len}) vs own_amounts({_amt_len}) '
            f'vs available_amounts({_avail_len}).'
        )
    try:
        _share_len = len(shares)
    except TypeError as err:
        raise TypeError('parse_live_trade_signal: shares must be a sequence of symbols.') from err
    if _share_len != _prc_len:
        raise ValueError(
            f'parse_live_trade_signal: shares length mismatch! '
            f'shares({_share_len}) vs prices({_prc_len}).'
        )

    if not isinstance(trade_batch_size, (float, int)):
        raise TypeError('trade_batch_size must be a number.')
    if not isinstance(sell_batch_size, (float, int)):
        raise TypeError('sell_batch_size must be a number.')
    if float(trade_batch_size) < 0.01:
        raise ValueError('trade_batch_size must be >= 0.01.')
    if float(sell_batch_size) < 0.01:
        raise ValueError('sell_batch_size must be >= 0.01.')
    # 如果没有提供交易信号的配置，使用QT_CONFIG中的默认配置

    # 1, 将交易信号解析为交易意图 trade_intentions (即cash_to_spend和amounts_to_sell)

    # PT交易信号和PS/VS交易信号需要分开解析
    if signal_type.lower() == 'pt':
        trimmed_signals = trim_pt_type_signals(
            op_signals=signals,
            long_pos_limit=long_position_limit,
            short_pos_limit=short_position_limit,
        )
        cash_to_spend, amounts_to_sell = parse_pt_signals(
            signals=trimmed_signals,
            prices=prices,
            own_amounts=own_amounts,
            own_cash=own_cash,
            pt_buy_threshold=pt_buy_threshold,
            pt_sell_threshold=pt_sell_threshold,
            allow_sell_short=allow_sell_short,
        )
    # 解析PT交易信号：
    # 读取当前的所有持仓，与signal比较，根据差值确定计划买进和卖出的数量
    # 解析PS/VS交易信号
    # 直接根据交易信号确定计划买进和卖出的数量
    elif signal_type.lower() == 'ps':
        cash_to_spend, amounts_to_sell = parse_ps_signals(
            signals=signals,
            prices=prices,
            own_amounts=own_amounts,
            own_cash=own_cash,
            allow_sell_short=allow_sell_short
        )
    elif signal_type.lower() == 'vs':
        cash_to_spend, amounts_to_sell = parse_vs_signals(
            signals=signals,
            prices=prices,
            own_amounts=own_amounts,
            allow_sell_short=allow_sell_short,
            cost_params=cost_params,
        )
    else:
        raise ValueError('Unknown signal type: {}'.format(signal_type))

    if np.allclose(cash_to_spend, 0.) and np.allclose(amounts_to_sell, 0.):
        return [], [], [], [], [], []

    # 2，Operator 级风控：与回测 calculate_trade_results 同序
    cash_to_spend, amounts_to_sell = sell_direction_adjustment(
            cash_to_spend,
            amounts_to_sell,
            own_amounts,
            available_amounts,
            prices,
            allow_sell_short,
            cost_params,
    )
    moq_sell_f = float(sell_batch_size)
    amount_sold_pv, cash_gained_pv, _fee_s = get_selling_result(
            prices,
            amounts_to_sell,
            moq_sell_f,
            cost_params,
    )
    st_lower = signal_type.lower()
    if st_lower == 'pt':
        signal_type_id = 0
    elif st_lower == 'ps':
        signal_type_id = 1
    else:
        signal_type_id = 2
    if not np.allclose(cash_to_spend, 0.0, atol=0.001):
        pre_values = own_amounts * prices
        total_value_bt = float(own_cash) + float(np.sum(pre_values))
        cash_to_spend = buy_direction_adjustment(
                cash_to_spend,
                signal_type_id,
                int(cash_delivery_period),
                float(available_cash),
                cash_gained_pv,
                amount_sold_pv,
                own_amounts,
                prices,
                float(long_position_limit),
                float(short_position_limit),
                allow_sell_short,
                total_value_bt,
        )

    # 将计算出的买入和卖出的数量转换为交易订单
    symbols, positions, directions, quantities, quoted_prices, remarks = _signal_to_order_elements(
        shares=shares,
        cash_to_spend=cash_to_spend,
        amounts_to_sell=amounts_to_sell,
        prices=prices,
        available_cash=available_cash,
        available_amounts=available_amounts,
        moq_buy=trade_batch_size,
        moq_sell=sell_batch_size,
        allow_sell_short=allow_sell_short,
        cost_params=cost_params,
    )
    return symbols, positions, directions, quantities, quoted_prices, remarks


@njit(cache=True)
def trim_pt_type_signals(op_signals: np.ndarray,
                         long_pos_limit: float,
                         short_pos_limit: float) -> np.ndarray:
    """ 修剪PT类型的交易信号，使得交易信号不超过多头和空头的持仓限制

    Parameters
    ----------
    op_signals: np.ndarray
        交易信号
    long_pos_limit: float
        多头持仓限制
    short_pos_limit: float
        空头持仓限制

    Returns
    -------
    trimmed_op_signals: np.ndarray
        返回修改后的signals数组
    """
    # 分别计算多头和空头信号的总和
    long_signals = np.where(op_signals > 0, op_signals, 0.)
    short_signals = np.where(op_signals < 0, op_signals, 0.)

    long_sum = np.sum(long_signals)
    short_sum = np.sum(short_signals)

    # 如果多头信号总和超过多头持仓限制，则按比例缩减多头信号
    if long_sum > long_pos_limit:
        long_signals = long_signals * long_pos_limit / long_sum
    # 如果空头信号总和小于空头持仓限制，则按比例缩减空头信号
    if short_sum < short_pos_limit:
        short_signals = short_signals * short_pos_limit / short_sum

    trimmed_op_signals = long_signals + short_signals

    return trimmed_op_signals


@njit(cache=True)
def parse_pt_signals(signals: np.ndarray,
                     prices: np.ndarray,
                     own_amounts: np.ndarray,
                     own_cash: Union[float, np.float64, np.int64, np.ndarray],
                     pt_buy_threshold: float,
                     pt_sell_threshold: float,
                     allow_sell_short: bool) -> tuple[np.ndarray, np.ndarray]:
    """ 解析PT类型的交易信号，生成“理论目标调仓计划”

    Parameters
    ----------
    signals: np.ndarray
        交易信号
    prices: np.ndarray
        各个资产的价格
    own_amounts: np.ndarray
        各个资产的持仓数量
    own_cash: float, np.float64
        账户的现金
    pt_buy_threshold: float
        PT买入的阈值
    pt_sell_threshold: float
        PT卖出的阈值
    allow_sell_short: bool
        是否允许卖空

    Returns
    -------
    tuple: (cash_to_spend, amounts_to_sell)
        cash_to_spend: np.ndarray, 买入资产的现金金额，正数表示买入多头，负数表示买入空头
        amounts_to_sell: np.ndarray, 卖出资产的数量，正数表示卖出空头，负数表示卖出多头
    """

    # 计算当前总资产
    # import pdb; pdb.set_trace()
    total_value = np.nansum(prices * own_amounts) + own_cash

    ptbt = pt_buy_threshold
    ptst = -pt_sell_threshold
    # 计算当前持有头寸的持仓占比，与交易信号相比较，计算持仓差异
    previous_pos = own_amounts * prices / total_value
    position_diff = signals - previous_pos
    # 当不允许买空卖空操作时，只需要考虑持有股票时卖出或买入，即开多仓和平多仓
    # 当持有份额大于零且交易信号为负时，平多仓：卖出数量 = 仓位差 * 持仓份额，此时持仓份额需大于零
    amounts_to_sell = np.where((position_diff < ptst) & (own_amounts > 0),
                               position_diff / previous_pos * own_amounts,
                               0.)
    # 当持有份额不小于0且交易信号为正时，开多仓：买入金额 = 仓位差 * 当前总资产，此时不能持有空头头寸
    cash_to_spend = np.where((position_diff > ptbt) & (own_amounts >= 0),
                             position_diff * total_value,
                             0.)
    # 当允许买空卖空操作时，需要考虑持有股票时卖出或买入，即开多仓和平多仓，以及开空仓和平空仓
    if allow_sell_short:

        # 当持有份额小于等于零且交易信号为负，开空仓：买入空头金额 = 仓位差 * 当前总资产，此时持有份额为0
        cash_to_spend += np.where((position_diff < ptst) & (own_amounts <= 0),
                                  position_diff * total_value,
                                  0.)
        # 当持有份额小于0（即持有空头头寸）且交易信号为正时，平空仓：卖出空头数量 = 仓位差 * 当前持有空头份额
        amounts_to_sell += np.where((position_diff > ptbt) & (own_amounts < 0),
                                    position_diff / previous_pos * own_amounts,
                                    0.)

    return cash_to_spend, amounts_to_sell


@njit(cache=True)
def parse_ps_signals(signals: np.ndarray,
                     prices: np.ndarray,
                     own_amounts: np.ndarray,
                     own_cash: Union[float, np.float64, np.ndarray],
                     allow_sell_short: bool) -> tuple[np.ndarray, np.ndarray]:
    """ 解析PS类型的交易信号，将信号解释为基于当前总资产和持仓比例的订单规模

    Parameters
    ----------
    signals: np.ndarray
        交易信号
    prices: np.ndarray
        当前资产的价格
    own_amounts: np.ndarray
        当前持有的资产份额
    own_cash: float
        当前持有的现金
    allow_sell_short: bool
        是否允许卖空

    Returns
    -------
    tuple: (cash_to_spend, amounts_to_sell)
        cash_to_spend: np.ndarray, 买入资产的现金金额，正数表示买入多头，负数表示买入空头
        amounts_to_sell: np.ndarray, 卖出资产的数量，正数表示卖出空头，负数表示卖出多头
    """

    # 计算当前总资产
    # 注意：prices 中可能存在 NaN（例如停牌/无行情），此时不能让整个 total_value 变成 NaN，
    # 否则会污染所有标的的 cash_to_spend 解析结果。
    total_value = np.nansum(prices * own_amounts) + own_cash

    # 当不允许买空卖空操作时，只需要考虑持有股票时卖出或买入，即开多仓和平多仓
    # 当持有份额大于零时，平多仓：卖出数量 = 交易信号 * 持仓份额，此时持仓份额需大于零
    amounts_to_sell = np.where((signals < 0) & (own_amounts > 0), signals * own_amounts, 0.)
    # 当持有份额不小于0时，开多仓：买入金额 = 交易信号 * 当前总资产，此时不能持有空头头寸
    cash_to_spend = np.where((signals > 0) & (own_amounts >= 0), signals * total_value, 0.)

    # 当允许买空卖空时，允许开启空头头寸：
    if allow_sell_short:

        # 当持有份额小于等于零且交易信号为负，开空仓：买入空头金额 = 交易信号 * 当前总资产
        cash_to_spend += np.where((signals < 0) & (own_amounts <= 0), signals * total_value, 0.)
        # 当持有份额小于0（即持有空头头寸）且交易信号为正时，平空仓：卖出空头数量 = 交易信号 * 当前持有空头份额
        amounts_to_sell -= np.where((signals > 0) & (own_amounts < 0), signals * own_amounts, 0.)

    return cash_to_spend, amounts_to_sell


@njit(cache=True)
def parse_vs_signals(signals: np.ndarray,
                     prices: np.ndarray,
                     own_amounts: np.ndarray,
                     allow_sell_short: bool,
                     cost_params: np.ndarray, ) -> tuple[np.ndarray, np.ndarray]:
    """ 解析VS类型的交易信号，将信号解释为绝对金额/数量级订单

    多头/开空买入侧 ``cash_to_spend`` 在 ``signals * prices`` 本金意向之上，叠加与
    ``get_purchase_result`` 配套的佣金预算 ``max(buy_min, |本金| * buy_rate)``；**不含**滑点
    （滑点仅在回测执行层追加）。

    Parameters
    ----------
    signals: np.ndarray
        交易信号
    prices: np.ndarray
        当前资产的价格
    own_amounts: np.ndarray
        当前持有的资产的数量
    allow_sell_short: bool
        是否允许卖空
    cost_params: np.ndarray
        ``[buy_rate, sell_rate, buy_min, sell_min, slippage]``；本函数仅使用 ``buy_rate``、
        ``buy_min``，不使用 ``slippage``。

    Returns
    -------
    tuple: (cash_to_spend, amounts_to_sell)
        cash_to_spend: np.ndarray, 买入资产的现金
        amounts_to_sell: np.ndarray, 卖出资产的数量
    """

    buy_rate = cost_params[0]
    buy_min = cost_params[2]

    # 计算各个资产的计划买入金额和计划卖出数量
    # 当持有份额大于零且信号为负时，平多仓：卖出数量 = 信号数量，此时持仓份额需大于零
    amounts_to_sell = np.where((signals < 0) & (own_amounts > 0), signals, 0.)
    # 当持有份额不小于0且信号为正时，开多仓：本金 + 预估买入费用（不含滑点）
    base_long = np.where((signals > 0) & (own_amounts >= 0), signals * prices, 0.)
    addon_long = np.where(base_long > 0., np.fmax(buy_min, base_long * buy_rate), 0.)
    cash_to_spend = base_long + addon_long

    # 当允许买空卖空时，允许开启空头头寸：
    if allow_sell_short:
        # 当持有份额小于等于零且交易信号为负，开空仓：买入空头金额 = 信号数量 * 资产价格
        cash_to_spend += np.where((signals < 0) & (own_amounts <= 0), signals * prices, 0.)
        # 当持有份额小于0（即持有空头头寸）且交易信号为正时，平空仓：卖出空头数量 = 交易信号 * 当前持有空头份额
        amounts_to_sell -= np.where((signals > 0) & (own_amounts < 0), -signals, 0.)

    # prices 为 NaN 时，该标的不可成交；将解析层面的买入现金规模置 0，
    # 避免 NaN 在后续步骤继续传播（成交执行层仍会再次用 prices 屏蔽 NaN）。
    cash_to_spend = np.where(np.isnan(prices), 0.0, cash_to_spend)

    return cash_to_spend, amounts_to_sell


class TradeIntent(NamedTuple):
    """Operator 级交易意图：解析后的计划买入现金与计划卖出数量向量。"""
    cash_to_spend: np.ndarray
    amounts_to_sell: np.ndarray


@njit(cache=True)
def sell_direction_adjustment(
        cash_to_spend: np.ndarray,
        amounts_to_sell: np.ndarray,
        own_amounts: np.ndarray,
        available_amounts: np.ndarray,
        prices: np.ndarray,
        allow_sell_short: bool,
        cost_params: np.ndarray,
) -> tuple[np.ndarray, np.ndarray]:
    """按可用持仓与卖空规则调整卖出意图；超额空头卖出转多头买入时叠加买入佣金预算。

    Parameters
    ----------
    cash_to_spend : np.ndarray
        计划买入现金（正多头、负空头）。
    amounts_to_sell : np.ndarray
        计划卖出数量（负为卖多、正为卖空）。
    own_amounts, available_amounts, prices : np.ndarray
        与标的维度一致。
    allow_sell_short : bool
        是否允许卖空。
    cost_params : np.ndarray
        ``[buy_rate, sell_rate, buy_min, sell_min, slippage]``；本函数仅用 ``buy_rate``、``buy_min``。

    Returns
    -------
    tuple[np.ndarray, np.ndarray]
        调整后的 ``(cash_to_spend, amounts_to_sell)``。
    """
    c_out = np.copy(cash_to_spend)
    a_out = np.copy(amounts_to_sell)
    if not allow_sell_short:
        a_out = -np.fmin(-a_out, available_amounts)
    else:
        excesive_long = np.where(
                (a_out < 0) & (own_amounts + a_out < 0),
                own_amounts + a_out,
                0.,
        )
        c_out = c_out + excesive_long * prices
        excesive_short = np.where(
                (a_out > 0) & (own_amounts + a_out > 0),
                own_amounts + a_out,
                0.,
        )
        principal = excesive_short * prices
        buy_rate = cost_params[0]
        buy_min = cost_params[2]
        addon = np.where(principal > 0., np.fmax(buy_min, principal * buy_rate), 0.)
        c_out = c_out + principal + addon
        a_out = a_out - excesive_long - excesive_short
    return c_out, a_out


@njit(cache=True)
def buy_direction_adjustment(
        cash_to_spend: np.ndarray,
        signal_type: int,
        cash_delivery_period: int,
        available_cash: float,
        cash_gained: np.ndarray,
        amount_sold: np.ndarray,
        own_amounts: np.ndarray,
        prices: np.ndarray,
        long_pos_limit: float,
        short_pos_limit: float,
        allow_sell_short: bool,
        total_value: float,
) -> np.ndarray:
    """在卖出预览之后，按可用现金与多空限额缩放买入意图 ``cash_to_spend``。

    Parameters
    ----------
    cash_to_spend : np.ndarray
        待调整的买入现金向量。
    signal_type : int
        ``0`` PT，``1`` PS，``2`` VS。
    cash_delivery_period : int
        现金交割周期；PT 且为 ``0`` 时可用本期 ``cash_gained`` 计入有效可用现金。
    available_cash : float
        期初可用现金标量。
    cash_gained, amount_sold : np.ndarray
        与 ``get_selling_result`` 输出一致。
    own_amounts, prices : np.ndarray
        期初持仓与价格。
    long_pos_limit, short_pos_limit : float
        多空仓位上限参数。
    allow_sell_short : bool
        是否允许卖空。
    total_value : float
        与回测一步开始时一致的期初总资产。

    Returns
    -------
    np.ndarray
        调整后的 ``cash_to_spend``。
    """
    c_out = np.copy(cash_to_spend)
    if not allow_sell_short:
        if signal_type == 0 and cash_delivery_period == 0:
            effective_available_cash = available_cash + np.sum(cash_gained)
        else:
            effective_available_cash = available_cash
        c_pos = np.where(c_out > 0.001, c_out, 0.)
        s = np.sum(c_pos)
        if s > effective_available_cash:
            c_pos = c_pos * (effective_available_cash / s)
        c_out = c_pos
    elif signal_type >= 1:
        next_own_values = (own_amounts + amount_sold) * prices
        long_cash = np.where(c_out > 0.001, c_out, 0.)
        total_long = np.sum(long_cash)
        max_long = long_pos_limit * total_value - np.sum(
                np.where(c_out > 0.001, next_own_values, 0.))
        short_cash = np.where(c_out < -0.001, c_out, 0.)
        total_short = np.sum(short_cash)
        max_short = short_pos_limit * total_value - np.sum(
                np.where(c_out < -0.001, next_own_values, 0.))
        if total_long > max_long:
            long_cash = long_cash * (max_long / total_long)
        if total_short < max_short:
            short_cash = short_cash * (max_short / total_short)
        c_out = long_cash + short_cash
    return c_out


def _signal_to_order_elements(shares,
                              cash_to_spend,
                              amounts_to_sell,
                              prices,
                              available_cash,
                              available_amounts,
                              moq_buy=0,
                              moq_sell=0,
                              allow_sell_short=False,
                              cost_params: Optional[np.ndarray] = None):
    """将经 Operator 风控后的 ``cash_to_spend`` / ``amounts_to_sell`` 展开为订单行。

    可用现金与持仓截断已在 ``sell_direction_adjustment`` / ``buy_direction_adjustment`` 中完成；
    本函数不再按比例缩放现金，不再因可用不足拆出对向腿。订单行顺序为**先全部卖出、再全部买入**。

    Parameters
    ----------
    shares: list of str
        各个资产的代码
    cash_to_spend: np.ndarray
        各个资产的买入金额
    amounts_to_sell: np.ndarray
        各个资产的卖出数量
    prices: np.ndarray
        各个资产的价格
    available_cash: float
        可用现金
    available_amounts: np.ndarray
        可用资产的数量
    moq_buy: float, default 0
        买入的最小交易单位
    moq_sell: float, default 0
        卖出的最小交易单位
    allow_sell_short: bool, default False
        是否允许卖空，如果允许，当可用资产不足时，会增加空头买入信号
    cost_params: np.ndarray, optional
        长度 5 的交易成本数组 [buy_rate, sell_rate, buy_min, sell_min, slippage]；
        多头买入数量由 ``get_purchase_result`` 按此参数与 ``moq_buy`` 计算。默认全 0。

    Returns
    -------
    order_elements: tuple, (symbols, positions, directions, quantities, quoted_prices)
    - symbols: list of str, 产生交易信号的资产代码
    - positions: list of str, 产生交易信号的各各资产的头寸类型('long', 'short')
    - directions: list of str, 产生的交易信号的交易方向('buy', 'sell')
    - quantities: list of float, 所有交易信号的交易数量
    - quoted_prices: list of float, 所有交易信号的交易报价
    -     remarks: list of str, 生成交易信号的说明，用于为trader提供提示
    """

    if cost_params is None:
        cost_params = np.zeros(5, dtype=np.float64)
    else:
        cost_params = np.asarray(cost_params, dtype=np.float64).reshape(-1)
        if cost_params.size < 5:
            raise ValueError('cost_params must have at least 5 elements')

    symbols: list[str] = []
    positions: list[str] = []
    directions: list[str] = []
    quantities: list[float] = []
    quoted_prices: list[float] = []
    remarks: list[str] = []
    base_remark = ''

    n = len(shares)
    for i in range(n):
        sym = shares[i]
        if amounts_to_sell[i] < -0.001:
            qty = float(np.round(-amounts_to_sell[i], AMOUNT_DECIMAL_PLACES))
            if moq_sell > 0:
                qty = float(np.trunc(qty / moq_sell) * moq_sell)
            if qty <= 0.001:
                continue
            symbols.append(sym)
            positions.append('long')
            directions.append('sell')
            quantities.append(qty)
            quoted_prices.append(float(prices[i]))
            remarks.append(base_remark)
        if allow_sell_short and amounts_to_sell[i] > 0.001:
            qty = float(np.round(amounts_to_sell[i], AMOUNT_DECIMAL_PLACES))
            if moq_sell > 0:
                qty = float(np.trunc(qty / moq_sell) * moq_sell)
            if qty <= 0.001:
                continue
            symbols.append(sym)
            positions.append('short')
            directions.append('sell')
            quantities.append(qty)
            quoted_prices.append(float(prices[i]))
            remarks.append(base_remark)

    for i in range(n):
        sym = shares[i]
        if cash_to_spend[i] > 0.001:
            px = prices[i]
            if (not np.isfinite(px)) or np.isnan(px) or px <= 0:
                continue
            p1 = np.array([float(px)], dtype=np.float64)
            c1 = np.array([float(cash_to_spend[i])], dtype=np.float64)
            a_purchased, _cash_spent, _fees = get_purchase_result(
                    p1, c1, float(moq_buy), cost_params,
            )
            quantity = float(a_purchased[0])
            if moq_buy <= 0:
                quantity = float(np.round(quantity, AMOUNT_DECIMAL_PLACES))
            if quantity <= 0.001:
                continue
            symbols.append(sym)
            positions.append('long')
            directions.append('buy')
            quantities.append(quantity)
            quoted_prices.append(float(prices[i]))
            remarks.append(base_remark)
        if (cash_to_spend[i] < -0.001) and allow_sell_short:
            px = prices[i]
            if (not np.isfinite(px)) or np.isnan(px) or px <= 0:
                continue
            quantity = float(np.round(-cash_to_spend[i] / prices[i], AMOUNT_DECIMAL_PLACES))
            if moq_buy > 0:
                quantity = float(np.trunc(quantity / moq_buy) * moq_buy)
            if quantity <= 0.001:
                continue
            symbols.append(sym)
            positions.append('short')
            directions.append('buy')
            quantities.append(quantity)
            quoted_prices.append(float(prices[i]))
            remarks.append(base_remark)

    return symbols, positions, directions, quantities, quoted_prices, remarks


def output_trade_order():
    """ 将交易订单输出到终端或TUI

    Returns
    -------
    order_id: int
        交易订单的id
    """
    pass


def submit_order(order_id, data_source, mark_submitted: bool = True):
    """ 将交易订单提交给交易平台或用户以等待交易结果，同时更新账户和持仓信息

    只有刚刚创建的交易订单（status == 'created'）才能提交，否则不需要再次提交
    在提交交易订单以前，对于买入订单，会检查账户的现金是否足够，如果不足，则会按比例调整交易订单的委托数量
    对于卖出订单，会检查账户的持仓是否足够，如果不足，则会按比例调整交易订单的委托数量
    交易订单提交后，会将交易订单的状态设置为submitted，同时将交易订单保存到数据库中
    - 只有使用submit_order才能将信号保存到数据库中，同时调整相应的账户和持仓信息

    Parameters
    ----------
    order_id: int
        交易订单的id
    data_source: Any
        数据源的名称

    Returns
    -------
    int, 交易订单的id
    None, 如果交易订单的状态不为created，则说明交易订单已经提交过，不需要再次提交
    """

    # 读取交易订单
    trade_order = read_trade_order(order_id, data_source=data_source)
    # 如果交易订单的状态不为created，则说明交易订单已经提交过，不需要再次提交
    if trade_order['status'] != 'created':
        return None

    # 如果交易方向为buy，则需要检查账户的现金是否足够
    position_id = trade_order['pos_id']
    position = get_position_by_id(position_id, data_source=data_source)
    pos_type = position['position']
    if pos_type == 'short':
        # TODO: position为short时做法不同，需要进一步调整
        raise NotImplementedError('short position orders submission is not realized')
    if trade_order['direction'] == 'buy':
        account_id = position['account_id']
        account = get_account(account_id, data_source=data_source)
        required_cash = float(trade_order['qty']) * float(trade_order['price'])
        # 现金不足时拒绝提交，避免订单进入submitted后在记账阶段失败
        if account['available_cash'] < required_cash:
            logger.warning(
                    f'Available cash {account["available_cash"]:.3f} is not enough for trade order: \n'
                    f'{trade_order}'
            )
            raise RuntimeError(
                    f'Insufficient available cash for order {order_id}: '
                    f'need {required_cash:.3f}, available {float(account["available_cash"]):.3f}'
            )

    # 如果交易方向为sell，则需要检查账户的持仓是否足够
    elif trade_order['direction'] == 'sell':
        # 如果账户的持仓不足，则输出警告信息
        if position['available_qty'] < trade_order['qty']:
            logger.warning(f'Available quantity {position["available_qty"]} is not enough for trade order: \n'
                           f'{trade_order}'
                           f'trade order might not be executed!')

    if mark_submitted:
        # 将signal的status改为"submitted"，并将trade_signal写入数据库
        order_id = update_trade_order(order_id=order_id, data_source=data_source, status='submitted')
    return order_id


def cancel_order(order_id, data_source=None, config=None, account_id: int = None) -> int:
    """ 取消交易订单

    对于已经提交但尚未执行或者partially_fill的订单，可以取消订单，将订单的状态设置为 'canceled'
    取消订单时，生成这个订单的交易结果，交易结果的"canceled_qty"为订单的"qty"，交易结果的 "status" 为 "canceled"
    如果订单的状态为部分成交partial- filled，生成的交易结果的quantity为订单的数量减去已经成交的数量

    Parameters
    ----------
    order_id: int
        交易订单的id
    data_source: str, optional
        数据源的名称, 默认为None, 表示使用默认的数据源
    config: dict, optional
        配置参数，主要包含股票和现金交割周期信息，如果为None，则使用默认的配置参数
    account_id: int, optional
        限制可撤单的账户ID。若给定，则仅允许撤销该账户下的订单。

    Returns
    -------
    int, 如果成功生成取消结果，则返回交易订单的id，如果交易订单已经没有剩余数量可以取消，则返回-1
    """
    # TODO: further test this function

    order_details = read_trade_order_detail(order_id=order_id, data_source=data_source)
    order_status = order_details['status']
    if order_status not in ['submitted', 'partial-filled']:
        raise RuntimeError(f'order status wrong: {order_status} cannot be canceled')
    if account_id is not None and int(order_details['account_id']) != int(account_id):
        raise ValueError(
                f'Order {order_id} does not belong to account {account_id}, '
                f'it belongs to account {order_details["account_id"]}',
        )

    order_results = read_trade_results_by_order_id(order_id=order_id, data_source=data_source)
    if not order_results.empty:  # 如果有交易结果，计算已经成交的数量和已经取消的数量
        total_filled_qty = np.round(
                order_results['filled_qty'].sum(),
                AMOUNT_DECIMAL_PLACES,
        )
        already_canceled_qty = np.round(
                order_results['canceled_qty'].sum(),
                AMOUNT_DECIMAL_PLACES,
        )
    else:  # 如果没有交易结果，已经成交的数量和已经取消的数量都为0
        total_filled_qty = 0.
        already_canceled_qty = 0.
    if already_canceled_qty > 0:
        # TODO: there is a bug: if order status is submitted, then canceled_qty should be 0
        raise RuntimeError(f'order status wrong: canceled qty should be 0 '
                           f'unless order is canceled! actual: {already_canceled_qty} for order \n{order_details}\n'
                           f'and result: \n{order_results}')
    remaining_qty = np.round(
            order_details['qty'] - total_filled_qty,
            AMOUNT_DECIMAL_PLACES,
    )

    if remaining_qty <= 0:
        # in this case there will be nothing to be canceled
        return -1

    result_of_cancel = {
        'order_id':        order_id,
        'filled_qty':      0.,
        'price':           order_details['price'],
        'transaction_fee': 0.,
        'canceled_qty':    remaining_qty,
        'delivery_amount': 0,
        'delivery_status': 'ND',
    }
    process_trade_result(
            raw_trade_result=result_of_cancel,
            data_source=data_source
    )

    return order_id


def process_account_delivery(account_id,
                             data_source=None,
                             stock_delivery_period=0,
                             cash_delivery_period=0) -> list:
    """ 处理account_id账户中所有持仓和现金的交割

    从交易历史中读取尚未交割的现金和持仓，根据config中的设置值 'cash_delivery_period' 和
    'stock_delivery_period' 执行交割，将完成交割的现金和持仓数量更新到现金和持仓的available
    中，并将已完成交割的交易结果的交割状态更新为"DL"

    Parameters
    ----------
    account_id: int
        账户的id
    data_source: str, optional
        数据源的名称, 默认为None, 表示使用默认的数据源
    stock_delivery_period: int, default 0
        股票交割周期，单位为天
    cash_delivery_period: int, default 0
        现金交割周期，单位为天


    Returns
    -------
    delivery_result: list
        包含所有交割结果的列表
    """

    if not isinstance(account_id, (int, np.int64)):
        raise TypeError('account_id must be an int')

    delivery_result = []

    undelivered_results = read_trade_results_by_delivery_status(
            delivery_status='ND',
            data_source=data_source,
    )
    if undelivered_results.empty:
        return delivery_result

    # 循环处理每一条未交割的交易结果：
    for result_id, result in undelivered_results.iterrows():

        res = deliver_trade_result(
                result_id=int(result_id),
                account_id=account_id,
                result=result.to_dict(),
                stock_delivery_period=stock_delivery_period,
                cash_delivery_period=cash_delivery_period,
                data_source=data_source,
        )
        delivery_result.append(res)

    return delivery_result


def deliver_trade_result(result_id, account_id, result=None, stock_delivery_period=0, cash_delivery_period=0,
                         data_source=None):
    """ 处理交易结果的交割，给出交易结果ID，根据结交割周期修改可用现金/可用持仓，并修改结果的delivery_status为'DL'

    注意，如果delivery_status已经为DL，则不交割，直接返回
    如果结果的交割期尚未达到，则不执行交割，直接返回
    如果result_id对应的account_id与参数account_id不符合，也不执行交割，直接返回

    Parameters
    ----------
    result_id: int
        结果ID，需要交割的交易结果的ID
    account_id: int
        账户ID，如果result所属的account与account_id不匹配则不执行交割
    result: dict, default None
        交易结果，如果不给出，则通过result_id读取结果
    stock_delivery_period: int, default 0
        股票交割周期，单位为天
    cash_delivery_period: int, default 0
        现金交割周期，单位为天
    data_source: str, optional
        数据源的名称, 默认为None, 表示使用默认的数据源

    Returns
    -------
    delivery_result: dict
    交割结果：包含以下信息
    {
        'order_id': int, 交割的订单的ID, 总是等于交易结果的order_id
        'account_id': int, 更新的账户ID，如果没有更新则为None
        'pos_id': int, 更新的持仓ID，如果没有更新则为None
        'symbol': str, 更新的持仓代码，如果没有更新则为None
        'position': str, 更新的持仓方向，如果没有更新则为None
        'prev_qty': float, 更新前的资产可用持仓数量，如果没有更新则为None
        'updated_qty': float, 更新后的资产可用持仓数量，如果没有更新则为None
        'prev_amount': float, 更新前的账户可用现金余额，如果没有更新则为None
        'updated_amount': float, 更新后的账户可用现金余额，如果没有更新则为None
        'delivery_status': str, 更新后订单的交割状态，如果正常交割，则为'DL',否则为None
    }
    """
    from .trade_recording import read_trade_result_by_id
    if result is None:
        result = read_trade_result_by_id(result_id=result_id, data_source=data_source)
    if not isinstance(result, dict):
        err = RuntimeError(f'Wrong trade result, expect a dict, got {type(result)} instead')
        raise err
    if result['delivery_status'] != 'ND':
        # 如果交易结果已经交割过了，则不再交割
        # print(f'[DEBUG]: in deliver_trade_result, got result {result}, status is '
        #       f'{result["delivery_status"]}, no need to deliver')
        return {}
    order_id = result['order_id']
    order_detail = read_trade_order_detail(order_id=order_id, data_source=data_source)
    if order_detail is None:
        err = RuntimeError(f'Cannot find order detail for order_id: {order_id}')
        raise err

    # 初始化交割结果字典
    delivery_result = {'order_id': order_id,
                       'account_id':  None,
                       'pos_id': None,
                       'symbol': None,
                       'position': None,
                       'prev_qty': None,
                       'updated_qty': None,
                       'prev_amount': None,
                       'updated_amount': None,
                       'delivery_status': None}

    if order_detail['account_id'] != account_id:
        # 如果订单不是发自account_id，则不予交割
        # print(f'[DEBUG]: in deliver_trade_result, got order detail {order_detail} with ID '
        #       f'{order_detail["account_id"]} != account_id {account_id}, no need to deliver')
        return {}

    # 读取交易方向，根据方向判断需要交割现金还是持仓，并分别读取现金/持仓的交割期
    trade_direction = order_detail['direction']
    if trade_direction == 'buy':
        delivery_period = stock_delivery_period
    elif trade_direction == 'sell':
        delivery_period = cash_delivery_period
    else:
        err = ValueError(f'Invalid direction: {trade_direction}')
        raise err

    # print(f'[DEBUG]: in deliver_trade_result, got delivery periods: '
    #       f'stock {stock_delivery_period}, cash {cash_delivery_period}')

    # 读取交易结果的execution_time，如果execution_time与现在的日期差小于交割期，则不予交割
    execution_date = pd.to_datetime(result['execution_time']).date()
    current_date = pd.to_datetime('today').date()
    day_diff = (current_date - execution_date).days
    if day_diff < delivery_period:
        # print(f'[DEBUG]: in deliver_trade_result, calculating day diff: {day_diff} '
        #       f'is < delivery_period {delivery_period}, thus no need to deliver')
        return delivery_result

    # 执行交割，更新现金/持仓的available，更新交易结果的delivery_status
    position_id = order_detail['pos_id']
    position = get_position_by_id(pos_id=position_id, data_source=data_source)
    delivery_result['pos_id'] = position_id
    delivery_result['position'] = position['position']
    delivery_result['symbol'] = position['symbol']

    delivery_result['account_id'] = account_id
    account = get_account(account_id, data_source=data_source)

    if trade_direction == 'buy':
        # 如果交易方向为买入，买入的股票持仓需要进行交割
        delivery_result['prev_qty'] = position['available_qty']

        try:
            update_position(
                    position_id=position_id,
                    data_source=data_source,
                    available_qty_change=result['delivery_amount'],
            )
            delivery_result['updated_qty'] = delivery_result['prev_qty'] + result['delivery_amount']

            # print(f'[DEBUG]: in deliver_trade_result, did actual delivery: position {position_id} available'
            #       f'quantity changed from {delivery_result["prev_qty"]} to {delivery_result["updated_qty"]}')
        except Exception as e:
            # print(f'{e} failed to updated position, position will NOT be updated, '
            #       f'result {result_id} will remain un-delivered')
            delivery_result['updated_qty'] = delivery_result['prev_qty']

            return delivery_result

    else:  # trade_direction == 'sell', 其他情况已经排除过了
        # 如果交易方向为卖出，卖出后获得的现金需要进行交割
        delivery_result['prev_amount'] = account['available_cash']

        try:
            update_account_balance(
                    account_id=account_id,
                    data_source=data_source,
                    available_cash_change=result['delivery_amount'],
            )
            delivery_result['updated_amount'] = delivery_result['prev_amount'] + result['delivery_amount']
            # print(f'[DEBUG]: in deliver_trade_result, did actual delivery: account {account_id} available'
            #       f'cash changed from {delivery_result["prev_amount"]} to {delivery_result["updated_amount"]}')
        except Exception as e:
            # print(f'{e} failed to updated account cashes, account will NOT be updated, '
            #       f'result {result_id} will remain un-delivered')
            delivery_result['updated_amount'] = delivery_result['prev_amount']

            return delivery_result

    update_trade_result(
            result_id=result_id,
            data_source=data_source,
            delivery_status='DL',
    )
    delivery_result['delivery_status'] = 'DL'
    # print(f'[DEBUG]: in deliver_trade_result, updated result delivery status to '
    #       f'{delivery_result["delivery_status"]} and will return')

    return delivery_result


def process_trade_result(raw_trade_result, data_source=None) -> dict:
    """ 处理交易结果: 更新交易订单的状态，更新账户的持仓，更新持有现金金额

    交易结果一旦生成，其内容就不会再改变，因此不需要更新交易结果，只需要根据交易结果
    更新相应交易订单（委托）的状态，更新账户的持仓，更新账户的现金余额

    Parameters
    ----------
    raw_trade_result: dict
        原始交易结果, 与正式交易结果的区别在于，原始交易结果不包含execution_time字段，
        原始交易结果是尚未确认的交易结果，只有确认有足够的现金和持仓时才能确认交易结果
    data_source: str, optional
        数据源的名称, 默认为None, 表示使用默认的数据源

    Returns
    -------
    full_trade_result: dict
        交易结果的完整信息，包含以下字段
        {
            'result_id': int, 交易结果的id
            'order_id': int, 交易订单的id
            'pos_id': int, 交易订单的持仓id
            'symbol': str, 股票代码
            'position': str, 持仓类型
            'direction': str, 交易方向
            'filled_qty': float, 成交数量
            'price': float, 成交价格
            'transaction_fee': float, 交易费用
            'canceled_qty': float, 取消数量
            'delivery_amount': float, 交割数量
            'qty_change': float, 持仓变动数量
            'available_qty_change': float, 可用持仓数量变动
            'cost_change': float,  持仓成本变动
            'cash_amount_change': float,  持有现金金额变动
            'available_cash_change': float,  可用现金金额变动量
            'delivery_status': str, 交易结果的交割状态 'DL'/'ND'
            'order_status': str, 交易订单的状态 'filled'/'partial-filled'/'canceled'
        }
    """
    if not isinstance(raw_trade_result, dict):
        raise TypeError(f'raw_trade_result must be a dict, got {type(raw_trade_result)} instead')
    if data_source is None:
        import qteasy as qt
        data_source = qt.QT_DATA_SOURCE

    order_id = raw_trade_result['order_id']
    broker_result_id = raw_trade_result.get('broker_result_id', '')
    if not isinstance(broker_result_id, str):
        raise TypeError(f'broker_result_id must be a str, got {type(broker_result_id)} instead')

    if broker_result_id:
        existed_result = read_trade_result_by_broker_result_id(broker_result_id, data_source=data_source)
        if existed_result:
            if int(existed_result['order_id']) != int(order_id):
                raise RuntimeError(
                        f'broker_result_id {broker_result_id} already exists on order '
                        f'{existed_result["order_id"]}, can not reuse on order {order_id}'
                )
            existed_order = read_trade_order_detail(int(existed_result['order_id']), data_source=data_source)
            existed_result['order_status'] = existed_order.get('status')
            return existed_result

    def _do_process_once() -> dict:
        order_detail = read_trade_order_detail(order_id, data_source=data_source)

        # 确认交易订单的状态不为 'created'. 'filled' or 'canceled'，如果是，则抛出异常
        if order_detail['status'] in ['created']:
            raise AttributeError(f'order {order_id} is noy submitted yet')
        if order_detail['status'] in ['filled', 'canceled']:
            raise AttributeError(f'order {order_id} has already been filled or canceled')

        # 读取交易订单的历史交易记录，计算尚未成交的数量：remaining_qty
        trade_results = read_trade_results_by_order_id(order_id, data_source=data_source)
        filled_qty = np.round(
                trade_results['filled_qty'].sum(),
                AMOUNT_DECIMAL_PLACES
        ) if not trade_results.empty else 0
        remaining_qty = np.round(
                order_detail['qty'] - filled_qty,
                AMOUNT_DECIMAL_PLACES,
        )
        if not isinstance(remaining_qty, (int, float, np.int64, np.float64)):
            raise TypeError(f'remaining qty {remaining_qty} is not a number!')
        # 当前交易结果确认后的累计成交量，用于稳定判定订单状态，避免依赖上一笔结果先写库
        filled_qty_after = np.round(filled_qty + raw_trade_result['filled_qty'], AMOUNT_DECIMAL_PLACES)
        total_order_qty = np.round(order_detail['qty'], AMOUNT_DECIMAL_PLACES)

        if raw_trade_result['canceled_qty'] > 0:
            if raw_trade_result['canceled_qty'] != remaining_qty:
                err = RuntimeError(f'canceled_qty {raw_trade_result["canceled_qty"]} '
                                   f'does not match remaining_qty {remaining_qty}')
                raise err
            order_detail['status'] = 'canceled'
        else:
            if raw_trade_result['filled_qty'] > remaining_qty:
                err = RuntimeError(f'filled_qty {raw_trade_result["filled_qty"]} '
                                   f'is greater than remaining_qty {remaining_qty}')
                raise err
            if filled_qty_after == total_order_qty:
                order_detail['status'] = 'filled'
            elif filled_qty_after < total_order_qty:
                order_detail['status'] = 'partial-filled'
            else:
                err = RuntimeError(f'filled_qty_after {filled_qty_after} exceeds order_qty {total_order_qty}')
                raise err

        if order_detail['direction'] == 'sell':
            position_change = - raw_trade_result['filled_qty']
            cash_change = np.round(
                    raw_trade_result['filled_qty'] * raw_trade_result['price'] - raw_trade_result['transaction_fee'],
                    CASH_DECIMAL_PLACES,
            )
        elif order_detail['direction'] == 'buy':
            position_change = raw_trade_result['filled_qty']
            cash_change = np.round(
                    - raw_trade_result['filled_qty'] * raw_trade_result['price'] - raw_trade_result['transaction_fee'],
                    CASH_DECIMAL_PLACES,
            )
        else:
            err = ValueError(f'Invalid direction: {order_detail["direction"]}')
            raise err

        position_info = get_position_by_id(order_detail['pos_id'], data_source=data_source)
        owned_qty = position_info['qty']
        available_qty = position_info['available_qty']
        position_cost = position_info['cost']
        if position_cost is None:
            position_cost = 0

        available_cash = get_account_cash_availabilities(order_detail['account_id'], data_source=data_source)[1]
        if available_qty + position_change < 0:
            err = RuntimeError(f'position_change {position_change} is greater than '
                               f'available position amount {available_qty}')
            raise err
        if available_cash + cash_change < 0:
            err = RuntimeError(f'cash_change {cash_change:.3f} is greater than '
                               f'available cash {available_cash:.3f}')
            raise err

        writable_trade_result = raw_trade_result.copy()
        writable_trade_result['broker_result_id'] = broker_result_id
        if order_detail['direction'] == 'buy':
            writable_trade_result['delivery_amount'] = position_change
        elif order_detail['direction'] == 'sell':
            writable_trade_result['delivery_amount'] = cash_change
        else:
            err = ValueError(f'direction must be buy or sell, got {order_detail["direction"]} instead')
            raise err
        writable_trade_result['delivery_status'] = 'ND'
        execution_time = pd.to_datetime('today').strftime('%Y-%m-%d %H:%M:%S')
        writable_trade_result['execution_time'] = execution_time
        result_id = write_trade_result(writable_trade_result, data_source=data_source)

        full_trade_result = writable_trade_result.copy()
        full_trade_result['result_id'] = result_id
        full_trade_result['order_id'] = order_id
        full_trade_result['pos_id'] = order_detail['pos_id']
        full_trade_result['symbol'] = order_detail['symbol']
        full_trade_result['position'] = position_info['position']
        full_trade_result['direction'] = order_detail['direction']
        full_trade_result['order_status'] = order_detail['status']

        cost_change, new_cost = calculate_cost_change(
                prev_qty=owned_qty,
                prev_unit_cost=position_cost,
                qty_change=position_change,
                price=raw_trade_result['price'],
                transaction_fee=raw_trade_result['transaction_fee'],
        )
        full_trade_result['cost_change'] = cost_change
        cash_amount_change = available_cash_change = cash_change
        qty_change = available_qty_change = position_change
        if order_detail['direction'] == 'buy':
            available_qty_change = 0
        else:
            available_cash_change = 0
        full_trade_result['qty_change'] = qty_change
        full_trade_result['available_qty_change'] = available_qty_change
        full_trade_result['cash_amount_change'] = cash_amount_change
        full_trade_result['available_cash_change'] = available_cash_change

        update_account_balance(
                account_id=order_detail['account_id'],
                data_source=data_source,
                cash_amount_change=cash_amount_change,
                available_cash_change=available_cash_change,
        )
        update_position(
                position_id=order_detail['pos_id'],
                data_source=data_source,
                qty_change=qty_change,
                available_qty_change=available_qty_change,
                cost=new_cost,
        )
        update_trade_order(order_id, data_source=data_source, status=order_detail['status'])
        return full_trade_result

    if getattr(data_source, 'source_type', None) == 'db':
        return data_source.db_run_in_transaction(_do_process_once)
    return _do_process_once()


def calculate_cost_change(prev_qty, prev_unit_cost, qty_change, price, transaction_fee) -> tuple:
    """ 当股票持仓的数量发生变化后，根据买入价格、买入数量和交易费用计算新的持仓成本

    Parameters
    ----------
    prev_qty: float
        变动前持仓数量
    prev_unit_cost: float
        变动前单位持仓成本
    qty_change: float
        持仓变化量
    price: float
        交易价格
    transaction_fee: float
        交易费用

    Returns
    -------
    tuple:
    cost_change: float, 持仓成本变动量
    new_cost: float, 新的持仓成本
    """
    prev_cost = prev_unit_cost * prev_qty
    if prev_qty + qty_change == 0:
        new_cost = 0
    else:
        additional_cost = qty_change * price + transaction_fee
        new_cost = (prev_cost + additional_cost) / (prev_qty + qty_change)
    return new_cost - prev_unit_cost, new_cost


def get_last_trade_result_summary(account_id, shares=None, data_source=None):
    """ 获取指定账户的最近的交易结果汇总，获取的结果为ndarray，按照shares的顺序排列
    如果shares为None，则结果按照order_id排序

    结果包含最近一次成交量（正数表示买入，负数表示卖出）以及最近一次成交价格，如果最近没有成交，
    则返回值为0/0

    Parameters
    ----------
    account_id: str,
        账户ID
    shares: list of str,
        股票代码列表, 如果不给出股票代码列表，则返回所有持仓股票的最近一次成交量和成交价格
    data_source: str,
        数据源名称

    Returns
    -------
    tuple: (symbols, amounts_changed, trade_prices)
    symbols: ndarray of str,
        股票代码列表
    amounts_changed: ndarray of float,
        最近一次成交量
    trade_prices: ndarray of float,
        最近一次成交价格
    """
    # TODO: test this function, causing error in live mode

    # read all filled and partially filled orders

    all_positions = get_account_positions(account_id=account_id, data_source=data_source)
    if all_positions.empty and (shares is None):
        return [], np.array([]), np.array([])

    all_position_symbols = all_positions['symbol'].to_dict()
    if shares is None:
        shares = list(all_position_symbols.values())

    if isinstance(shares, str):
        shares = str_to_list(shares)
    else:
        if not isinstance(shares, list):
            raise ValueError(f'shares must be a list of symbols, got {type(shares)} instead')

    all_orders = query_trade_orders(
            account_id=account_id,
            data_source=data_source,
    )
    if all_orders.empty:
        return shares, np.zeros(shape=(len(shares),)), np.zeros(shape=(len(shares),))
    all_orders = all_orders[all_orders['status'].isin(['filled', 'partial-filled'])]

    all_results = read_trade_results_by_order_id(
            order_id=all_orders.index.tolist(),
            data_source=data_source,
    )

    if all_orders.empty or (all_results is None):
        return shares, np.zeros(shape=(len(shares),)), np.zeros(shape=(len(shares),))

    # 将交易订单和交易结果合并生成订单交易记录
    all_order_results = all_orders.join(
            all_results.set_index('order_id'),
            how='left',
            lsuffix='-o',
            rsuffix='-e',
    )
    all_order_results = all_order_results.sort_values(by='execution_time')
    # 所有卖出的交易结果的filled_qty为负数，所有买入的交易结果的filled_qty为正数
    all_order_results['filled_qty'] = np.where(
            all_order_results['direction'] == 'sell',
            -all_order_results['filled_qty'],
            all_order_results['filled_qty']
    )

    # 如果同一个order有多次成交记录，则需计算多次成交记录的总数量，并计算多次成交的平均价格
    all_order_results['filled_qty'] = all_order_results['filled_qty'].groupby('order_id').sum()
    all_order_results['price-e'] = all_order_results['price-e'].groupby('order_id').mean()

    # 然后按照position分组并选取时间最后的交易结果记录
    last_trades_by_pos = all_order_results.groupby('pos_id').last()
    # 从结果中读取成交量和平均成交价格
    last_filled_qty = last_trades_by_pos['filled_qty'].to_dict()
    last_filled_price = last_trades_by_pos['price-e'].to_dict()
    # 重新整理key的顺序
    last_filled_qty = {all_position_symbols[k]: v for k, v in last_filled_qty.items()}
    last_filled_price = {all_position_symbols[k]: v for k, v in last_filled_price.items()}

    # update filled qty and filled prices with last filled qty and last filled price
    shares_filled_qty = {k: 0 for k in shares}
    shares_filled_price = {k: 0 for k in shares}
    shares_filled_qty.update(last_filled_qty)
    shares_filled_price.update(last_filled_price)
    last_filled_qty = shares_filled_qty
    last_filled_price = shares_filled_price

    # 删除生成的结果中不需要的shares
    last_filled_qty = {k: v for k, v in last_filled_qty.items() if k in shares}
    last_filled_price = {k: v for k, v in last_filled_price.items() if k in shares}

    amounts_changed = np.array(list(last_filled_qty.values()), dtype='float')
    trade_prices = np.array(list(last_filled_price.values()), dtype='float')

    return shares, amounts_changed, trade_prices


def trade_time_index(start=None,
                     end=None,
                     periods=None,
                     freq=None,
                     trade_days_only=True,
                     time_offset=None,
                     market='SSE',
                     include_start=True,
                     include_end=True,
                     start_am='9:30:00',
                     end_am='11:30:00',
                     include_start_am=False,
                     include_end_am=True,
                     start_pm='13:00:00',
                     end_pm='15:00:00',
                     include_start_pm=False,
                     include_end_pm=True):
    """ 通过start/end/periods/freq生成一个符合交易时间段的datetime series，这个序列中的
    每一个时间都在交易时段内，排除所有的非交易日以及非交易时间的序列

    Parameters
    ----------
    start: datetime like str,
        日期时间序列的开始日期/时间
    end: datetime like str,
        日期时间序列的终止日期/时间
    periods: int
        日期时间序列的分段数量
    freq: str, {'min', 'h', 'D', 'W', 'M', 'Q', 'Y'}
        日期时间序列的频率，支持特殊频率如W-FRI, MS(月初), ME(月末), QE-5(季度末倒数第五天)等
    trade_days_only: bool, Default True
        是否仅返回交易日，如果频率高于日频，则偏移到最近的交易日
    time_offset: str, Default None
        时间偏移量，代表时间的字符串，"00:00"到"23:59"之间，当freq低于等于一天('d', 'w', ...)时有效
    market: str, {'SSE', 'SZSE', 'SHFE', ...}, Default 'SSE'
        交易市场类型，不同的交易市场交易日定义可能不同, 默认上交所，trade_days_only为False时无效
    include_start: bool, Default True
        日期时间序列是否包含开始日期/时间
    include_end: bool, Default True
        日期时间序列是否包含结束日期/时间
    start_am: datetime like str, Default '9:30:00'
        早晨交易时段的开始时间
    end_am: datetime like str, Default '11:30:00'
        早晨交易时段的结束时间
    include_start_am: bool, Default False
        早晨交易时段是否包括开始时间
    include_end_am: bool, Default True
        早晨交易时段是否包括结束时间
    start_pm: datetime like str, Default '13:00:00'
        下午交易时段的开始时间
    end_pm: datetime like str, Default '15:00:00'
        下午交易时段的结束时间
    include_start_pm: bool, Default False
        下午交易时段是否包含开始时间
    include_end_pm: bool, Default True
        下午交易时段是否包含结束时间

    Returns
    -------
    time_index: pd.DatetimeIndex

    Examples
    --------
    # target time index not in trading day
    >>> trade_time_index(start='2021-01-01', end='2021-01-02', freq='h')
    DatetimeIndex([], dtype='datetime64[ns]', freq=None)
    # target time index is in trading day
    >>> trade_time_index(start='2021-02-01', end='2021-02-02', freq='h')
    DatetimeIndex(['2020-02-01 09:30:00', '2020-02-01 10:30:00',
                   '2020-02-01 11:30:00', '2020-02-01 13:00:00',
                   '2020-02-01 14:00:00', '2020-02-01 15:00:00',
                   '2020-02-02 09:30:00', '2020-02-02 10:30:00',
                   '2020-02-02 11:30:00', '2020-02-02 13:00:00',
                   '2020-02-02 14:00:00', '2020-02-02 15:00:00'],
                    dtype='datetime64[ns]', freq=None)
    """

    day_delta = None
    low_frequency = False

    # 检查输入数据, freq不能为除了min、h、d、w、m、q、a之外的其他形式
    if freq is not None:
        freq = str(freq)

        # 判断freq是大于日频还是小于日频
        if freq[0] in 'wWMQY':
            low_frequency = True

        # 解析M/Q/Y-num类型的偏移数据，调整低频数据的日期偏移值
        if ('-' in freq) and (freq[0] in 'MQY'):
            try:
                # ME-5或M-5表示从月底向前偏移5天即月底前五天，MS-3表示从月初向后偏移3天即月初第三天
                day_offset = int(freq.split('-')[-1]) - 1
                day_offset_direction = 1 if freq[1] == 'S' else -1
                freq = '-'.join(freq.split('-')[:-1])
                if 0 < day_offset < 27:
                    day_delta = day_offset_direction * pd.Timedelta(day_offset, 'd')
            except:
                # 这种情况通常由Y-JAN / Q-NOV等freq引起的，此时不需要调整
                pass

        # 如果需要偏移日期，起止日期也需要同样偏移
        if day_delta is not None:
            if start is not None:
                start = regulate_date_format(pd.to_datetime(start) - day_delta)
            if end is not None:
                end = regulate_date_format(pd.to_datetime(end) - day_delta)

    freq = pandas_freq_alias_version_conversion(freq)
    # 获取基准区间，基准区间包括开始和结束日期
    time_index = pd.date_range(
            start=start,
            end=end,
            periods=periods,
            freq=freq,
    )
    if len(time_index) == 0:
        err = ValueError('No time index can be extracted with given start/end/freq/periods parameters, '
                         'please check your input')
        raise err

    # 处理日期偏移
    if day_delta is not None:
        time_index += day_delta

    if trade_days_only and low_frequency:
        # 因为数据频率小于日频，因此不能直接剔除非交易日，而应该将其偏移到最近的交易日，偏移的规则为
        # - 如果基准日期是在周/月/季/年初，则偏移到下一个交易日
        # - 如果基准日期是在周/月/季/年末，则偏移到前一个交易日
        if (len(freq) > 1) and (freq[1] == 'S'):
            time_index = pd.DatetimeIndex(map(next_market_trade_day, time_index))
        else:
            time_index = pd.DatetimeIndex(map(nearest_market_trade_day, time_index))
    elif trade_days_only:
        # 当时间频率高于或等于日频时，剔除time_index中的非交易日
        from qteasy import QT_TRADE_CALENDAR as calendar
        calendar = calendar.is_open.unstack(level='exchange')
        try:
            calendar = calendar[market]
        except Exception as e:
            raise RuntimeError(f'Wrong market type is given, {e}')
        trade_cal = calendar.reindex(index=time_index)
        # 如果time_index不是从某天的00:00:00开始，则trade_cal中的第一个值会为nan
        # 此时需要用检查trade_cal的日期，填充正确的交易日标记
        if pd.isna(trade_cal.iloc[0]):
            date = pd.to_datetime(time_index[0].date())
            trade_cal.iloc[0] = calendar.loc[date]

        trade_cal = trade_cal.ffill()
        time_index = trade_cal.loc[trade_cal == 1].index

    # 判断time_index的freq，确定频率低于等于1天(d/w/m)还是高于1天(h/min)
    if time_index.freqstr is not None:
        freq_str = time_index.freqstr.split('-')[0]
    else:
        freq_str = time_index.inferred_freq
        if isinstance(freq_str, str):
            freq_str = freq_str
        elif len(time_index) >= 2:
            time_delta = time_index[1] - time_index[0]
            if time_delta < pd.Timedelta(1, 'd'):
                freq_str = 'h'
            else:
                freq_str = 'd'
        else:  # len(time_index) == 1
            freq_str = 'd'
    ''' freq_str有以下几种不同的情况：
        min:        T/min
        hour:       H
        day:        D
        week:       W/W-SUN/...
        month:      MS/ME/M-1/...
        quarter:    QS/QE/QE-DEC/...
        year:       YS/YE-DEC/...
        由于周、月、季、年三种情况存在复合字符串，因此需要split
    '''
    # 当freq小于一天时，需要按交易时段去掉不在交易时段以内的时间点
    if (freq_str[-1:].lower() in ['t', 'h']) or (freq_str[-3:].lower() in ['min']):
        # 在这里还有一处细节需要处理：当freq=‘h'的时候，生成的时间是整点如：
        # 09:00:00 / 10:00:00 / 11:00:00
        # 然而，如果start_am或者start_pm不是整点而是半点时，如start_am=09:30:00，
        # 那么实际上应该生成的时间点均需要延后半小时，变成：
        # 09:30:00 / 10:30:00 / 11:30:00
        # 因此，需要根据start_am和start_pm的时间，将上午/下午的time_index分别延后一定
        # 时间再处理
        time_index_am = time_index.copy()
        time_index_pm = time_index.copy()
        start_am_min = pd.to_datetime(start_am).minute
        start_pm_min = pd.to_datetime(start_pm).minute
        if (freq_str[-1:].lower() in ['h']) and (start_am_min > 0):
            time_index_am = time_index_am + pd.Timedelta(minutes=start_am_min)
        if (freq_str[-1:].lower() in ['h']) and (start_pm_min > 0):
            time_index_pm = time_index_pm + pd.Timedelta(minutes=start_pm_min)

        # freq_str for min in pandas 2.0 is 'T', in pandas 2.2 is 'MIN'
        idx_am = time_index_am.indexer_between_time(
                start_time=start_am,
                end_time=end_am,
                include_start=include_start_am,
                include_end=include_end_am,
        )
        idx_pm = time_index_pm.indexer_between_time(
                start_time=start_pm,
                end_time=end_pm,
                include_start=include_start_pm,
                include_end=include_end_pm,
        )
        time_index_am_pm = np.union1d(
                time_index_am[idx_am],
                time_index_pm[idx_pm],
        )
        time_index = pd.to_datetime(time_index_am_pm)

    else:  # 当freq大于等于一天时，需查看是否需要对时间进行偏移
        if time_offset is not None:
            from qteasy.utilfuncs import time_string_to_hour_float
            try:
                offset_hour = time_string_to_hour_float(time_offset)
                offset = pd.Timedelta(hours=offset_hour)
            except Exception as e:
                raise ValueError(f'Invalid time_offset {time_offset}, should be format like "HH:MM", {e}')
            time_index = time_index + offset

    # 最后的处理1：检查是否出现不在用户指定start/end时间段内的时间点，剔除超过范围的时间点
    if end is not None:
        if include_end:
            time_index = time_index[np.where(time_index <= pd.to_datetime(end))]
        else:
            time_index = time_index[np.where(time_index < pd.to_datetime(end))]
    if start is not None:
        if include_start:
            time_index = time_index[np.where(time_index >= pd.to_datetime(start))]
        else:
            time_index = time_index[np.where(time_index > pd.to_datetime(start))]

    # 最后的处理2：检查index中是否存在重复的时间点，如果存在，则剔除重复的时间点
    time_index = pd.DatetimeIndex(sorted(set(time_index)))

    return time_index


def get_symbol_names(datasource, symbols, asset_types: list = None, refresh: bool = False):
    """ 获取股票代码对应的股票名称, 必须给出完整的代码，如果代码错误，返回值为'N/A'，如果代码正确但
    基础数据表未下载，则返回值为'N/A'

    Parameters
    ----------
    datasource: DataSource
        数据源
    symbols: str or list of str
        股票代码列表
    asset_types: list, default None
        资产类型列表，如果给出，则只返回给定资产类型的股票名称，如果不给出，则返回所有资产类型的股票名称
    refresh: bool, default False
        是否刷新缓存，默认情况下从缓存数据中读取基本信息以加快速度，如果数据源中的数据已更新，需要刷新缓存

    Returns
    -------
    names: list
        股票名称列表，如果某个名称无法获取，该列表元素为'N/A'
        本函数不会返回空列表，除非输入的symbols为空列表

    Examples
    --------
    >>> get_symbol_names(datasource, '000001.SZ')
    ['平安银行']
    >>> get_symbol_names(datasource, ['000001.SZ', '000002.SZ'])
    ['平安银行', '万科A']
    >>> get_symbol_names(datasource, ['no_such_symbol', '000001.SZ'])
    ['N/A', '平安银行']
    """
    from qteasy import DataSource, QT_DATA_SOURCE
    if datasource is None:
        datasource = QT_DATA_SOURCE
    if not isinstance(datasource, DataSource):
        raise TypeError(f'datasource must be an instance of DataSource, got {type(datasource)} instead')

    if isinstance(symbols, str):
        symbols = str_to_list(symbols)
    if not isinstance(symbols, list):
        raise TypeError(f'symbols must be str or list of str, got {type(symbols)} instead')

    if not symbols:
        return []

    if asset_types is None:
        asset_types = ['stock', 'index', 'fund', 'future', 'option']
    else:
        if isinstance(asset_types, str):
            asset_types = str_to_list(asset_types)
        if not isinstance(asset_types, list):
            raise TypeError(f'asset_types must be str or list of str, got {type(asset_types)} instead')
        asset_types = [asset_type.lower() for asset_type in asset_types]
        if not all([asset_type in ['stock', 'index', 'fund', 'future', 'option'] for asset_type in asset_types]):
            raise ValueError(f'invalid asset_types: {asset_types}, must be one of '
                             f'["stock", "index", "fund", "future", "option"]')

    df_s, df_i, df_f, df_ft, df_o, df_ths = datasource.get_all_basic_table_data(
            raise_error=False,
            refresh_cache=refresh,
    )
    all_data_types = {
        'stock':  df_s[['name']] if not df_s.empty else pd.DataFrame(),
        'index':  df_i[['name']] if not df_i.empty else pd.DataFrame(),
        'fund':   df_f[['name']] if not df_f.empty else pd.DataFrame(),
        'future': df_ft[['name']] if not df_ft.empty else pd.DataFrame(),
        'option': df_o[['name']] if not df_o.empty else pd.DataFrame(),
    }
    all_basics = pd.concat(
            (
                all_data_types[asset_type.lower()] for asset_type in asset_types
            ),
    )
    if all_basics.empty:
        return ['N/A'] * len(symbols)
    try:
        names_found = all_basics.reindex(index=symbols)["name"].tolist()
    except Exception as e:
        raise RuntimeError(f'Error in get_symbol_names(): {e}')
    # replace all nan with 'N/A'
    names_found = ['N/A' if pd.isna(name) else name for name in names_found]

    return names_found


def account_log_file_name(account_id, datasource) -> str:
    """ 根据account_ID获取该account所存储的log文件的文件名（不同的扩展名用于不同类型的log文件，但文件名相同）

    Parameters
    ----------
    account_id: int
        账户的ID
    datasource: Datasource
        存储account信息的数据源

    Returns
    -------
    file_name: str
        文件名不含扩展名，系统记录文件扩展名为.lo，交易记录文件扩展名为.csv
    """
    account = get_account(account_id, data_source=datasource)
    account_name = account['user_name']
    return f'live_log_{account_id}_{account_name}'


def sys_log_file_path_name(account_id, datasource) -> str:
    """ 返回指定交易账户实盘系统记录文件的路径和文件名，文件路径为QT_SYS_LOG_PATH

    Parameters
    ----------
    account_id: int
        账户的ID
    datasource: Datasource
        存储account信息的数据源

    Returns
    -------
    file_path_name: str
        完整的系统记录文件路径和文件名，含扩展名.log
    """

    from qteasy import QT_SYS_LOG_PATH
    sys_log_file_name = sanitize_filename(
        account_log_file_name(account_id, datasource) + '.log'
    )
    log_file_path_name = os.path.join(QT_SYS_LOG_PATH, sys_log_file_name)
    return log_file_path_name


def break_point_file_path_name(account_id, datasource) -> str:
    """ 返回指定交易账户实盘断点文件的路径和文件名，目录为 ``QT_SYS_LOG_PATH``（与系统日志同根）。

    Parameters
    ----------
    account_id: int
        账户的ID
    datasource: Datasource
        存储account信息的数据源

    Returns
    -------
    file_path_name: str
        完整的断点文件路径和文件名，含扩展名 .bkp
    """

    from qteasy import QT_SYS_LOG_PATH
    trade_config_file_name = sanitize_filename(
        account_log_file_name(account_id, datasource) + '.bkp'
    )
    bp_file_path_name = os.path.join(QT_SYS_LOG_PATH, trade_config_file_name)
    return bp_file_path_name


def trade_log_file_path_name(account_id, datasource) -> str:
    """ 返回指定交易账户实盘交易记录文件的路径和文件名，文件路径为QT_TRADE_LOG_PATH

    Parameters
    ----------
    account_id: int
        账户的ID
    datasource: Datasource
        存储account信息的数据源

    Returns
    -------
    file_path_name: str
        完整的系统记录文件路径和文件名，含扩展名.csv
    """

    from qteasy import QT_TRADE_LOG_PATH
    trade_log_file_name = sanitize_filename(
        account_log_file_name(account_id, datasource) + '.csv'
    )
    log_file_path_name = os.path.join(QT_TRADE_LOG_PATH, trade_log_file_name)
    return log_file_path_name


def risk_log_file_path_name(account_id: int, datasource) -> str:
    """返回指定交易账户风控拒单审计日志文件的绝对路径，目录为 ``QT_TRADE_LOG_PATH``。

    文件名与 ``account_log_file_name`` 一致并经 ``sanitize_filename`` 处理，扩展名为 ``.risk.log``。

    Parameters
    ----------
    account_id : int
        账户 ID。
    datasource : DataSource
        账户所在数据源。

    Returns
    -------
    str
        风控审计日志完整路径。

    Raises
    ------
    TypeError
        ``datasource`` 不是 ``DataSource`` 实例。
    KeyError
        账户不存在（与 ``get_account`` 行为一致）。
    """

    from qteasy import DataSource, QT_TRADE_LOG_PATH

    if not isinstance(datasource, DataSource):
        raise TypeError(f'datasource must be a DataSource instance, got {type(datasource)} instead')
    stem = sanitize_filename(account_log_file_name(account_id, datasource))
    risk_file_name = stem + '.risk.log'
    return os.path.join(QT_TRADE_LOG_PATH, risk_file_name)


def list_live_trade_artifacts(account_id: int, data_source=None) -> dict[str, str]:
    """枚举指定实盘账户相关的磁盘产物路径（不要求文件已存在）。

    返回固定四键：``sys_log``、``trade_log``、``break_point``、``risk_log``，值均为
    当前 ``QT_SYS_LOG_PATH`` / ``QT_TRADE_LOG_PATH`` 解析下的绝对路径。
    若用户已通过 ``qt.configure`` 热更新日志目录，本函数与 ``delete_account`` 均与最新路径一致。

    Parameters
    ----------
    account_id : int
        账户 ID。
    data_source : DataSource, optional
        数据源；默认 ``None`` 时使用 ``QT_DATA_SOURCE``。

    Returns
    -------
    dict[str, str]
        键为 ``sys_log`` / ``trade_log`` / ``break_point`` / ``risk_log`` 的路径字典。

    Raises
    ------
    TypeError
        ``data_source`` 非 ``None`` 且不是 ``DataSource`` 实例。
    KeyError
        账户不存在。
    """

    import qteasy as qt
    from qteasy import DataSource

    if data_source is None:
        data_source = qt.QT_DATA_SOURCE
    if not isinstance(data_source, DataSource):
        raise TypeError(f'data_source must be a DataSource instance, got {type(data_source)} instead')
    return {
        'sys_log': sys_log_file_path_name(account_id, data_source),
        'trade_log': trade_log_file_path_name(account_id, data_source),
        'break_point': break_point_file_path_name(account_id, data_source),
        'risk_log': risk_log_file_path_name(account_id, data_source),
    }


def append_live_trade_risk_log_line(account_id: int, line: str, datasource) -> None:
    """向账户风控审计日志追加一行 UTF-8 文本（用于 ``<RISK REJECTED>`` 等）。

    写入失败时不抛出异常，仅发出英文 ``RuntimeWarning``，以免阻断拒单主流程。

    Parameters
    ----------
    account_id : int
        账户 ID。
    line : str
        待写入的一行文本（可不含换行符，函数会补全）。
    datasource : DataSource
        账户所在数据源。

    Returns
    -------
    None
    """

    from qteasy import DataSource

    if not isinstance(datasource, DataSource):
        raise TypeError(f'datasource must be a DataSource instance, got {type(datasource)} instead')
    path = risk_log_file_path_name(account_id, datasource)
    try:
        os.makedirs(os.path.dirname(path) or '.', exist_ok=True)
        payload = line if line.endswith('\n') else line + '\n'
        with open(path, 'a', encoding='utf-8') as f:
            f.write(payload)
    except OSError as exc:
        warnings.warn(
            f'Failed to append live-trade risk log for account {account_id}: {exc}',
            RuntimeWarning,
            stacklevel=2,
        )
