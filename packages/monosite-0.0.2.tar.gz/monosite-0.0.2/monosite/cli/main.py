import typer

app = typer.Typer()


@app.command()
def main():
    """Main entry point for the Monosite CLI."""
    print("Hello, Monosite!")

if __name__ == "__main__":
    app()
