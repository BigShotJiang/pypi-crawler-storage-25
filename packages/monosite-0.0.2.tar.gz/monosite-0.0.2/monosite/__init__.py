# 版本号将由 hatch-vcs 在构建时动态写入
# 开发时如果是 editable install，可能需要手动指定或依赖 setuptools_scm 的机制
try:
    from ._version import __version__
except ImportError:
    # Fallback for direct execution or when _version.py doesn't exist yet
    __version__ = "0.0.0+unknown"
