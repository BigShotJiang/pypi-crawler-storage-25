from pydantic_settings import BaseSettings, SettingsConfigDict
from pydantic import BaseModel

class ProjectSettings(BaseModel):
    name: str = "Monosite"
    version: str = "0.0.0"
    description: str = "Add your description here"

class ServerSettings(BaseModel):
    host: str = "0.0.0.0"
    port: int = 8000

class RouterSettings(BaseModel):
    frontend_port: int | None = None
    is_auto_router: bool = True

class FrontendSettings(BaseModel):
    management: str  = "pnpm" #可选 npm pnpm yarn

class Settings(BaseSettings):
    model_config = SettingsConfigDict(
        env_prefix="MONOSITE_",
    )

    project: ProjectSettings = ProjectSettings()
    server: ServerSettings = ServerSettings()
    router: RouterSettings = RouterSettings()
    frontend: FrontendSettings = FrontendSettings()
    