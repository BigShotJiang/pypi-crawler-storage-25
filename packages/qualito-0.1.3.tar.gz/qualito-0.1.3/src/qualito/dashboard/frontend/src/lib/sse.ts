/**
 * SSE client placeholder.
 *
 * The generic /api/events endpoint does not exist. Real-time setup events
 * are handled via subscribeToSetupEvents() in api.ts which connects to
 * /api/setup/events with a token. This module is kept for backward compat
 * but connectSSE/disconnectSSE are no-ops.
 */

/** Connect to the SSE event stream. No-op — setup SSE is in api.ts. */
export function connectSSE() {
	// No-op: there is no generic /api/events endpoint.
	// Setup SSE is handled via subscribeToSetupEvents() in api.ts.
}

/** Disconnect from the SSE event stream. No-op. */
export function disconnectSSE() {
	// No-op
}
