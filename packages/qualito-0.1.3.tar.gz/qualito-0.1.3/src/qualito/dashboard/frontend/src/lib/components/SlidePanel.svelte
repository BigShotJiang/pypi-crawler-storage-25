<script lang="ts">
	import type { Snippet } from 'svelte';

	interface Props {
		open: boolean;
		title?: string;
		onclose: () => void;
		children: Snippet;
	}

	let { open, title = '', onclose, children }: Props = $props();
</script>

{#if open}
	<!-- Backdrop -->
	<button
		class="fixed inset-0 z-40"
		style="background: rgba(0,0,0,0.5); backdrop-filter: blur(2px);"
		onclick={onclose}
		aria-label="Close panel"
	></button>

	<!-- Panel -->
	<div
		class="fixed top-0 right-0 z-50 h-full overflow-y-auto"
		style="width: min(480px, 90vw); background: var(--bg-subtle); border-left: 1px solid var(--border);"
	>
		<div class="flex items-center justify-between p-4" style="border-bottom: 1px solid var(--border)">
			{#if title}
				<h2 class="text-sm font-semibold" style="color: var(--text)">{title}</h2>
			{/if}
			<button
				class="p-1 rounded"
				style="color: var(--text-muted); transition: color 120ms ease;"
				onclick={onclose}
				aria-label="Close"
			>
				<svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round">
					<path d="M18 6 6 18M6 6l12 12" />
				</svg>
			</button>
		</div>
		<div class="p-4">
			{@render children()}
		</div>
	</div>
{/if}
