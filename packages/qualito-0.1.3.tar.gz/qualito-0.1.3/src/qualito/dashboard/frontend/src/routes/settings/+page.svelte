<script lang="ts">
	import { onMount } from 'svelte';
	import { getMe, listApiKeys, createApiKey, revokeApiKey, createCheckout, getBillingStatus, cancelSubscription, createPortalSession, resendVerification, deleteAccount, deleteAllData } from '$lib/api';
	import type { User, ApiKey, BillingStatus } from '$lib/types';

	let user: User | null = $state(null);
	let apiKeys: ApiKey[] = $state([]);
	let newKeyName = $state('');
	let createdKey = $state('');
	let loading = $state(true);
	let creating = $state(false);

	// Billing state
	let billingStatus: BillingStatus | null = $state(null);
	let billingLoading = $state(false);
	let billingError = $state('');
	let billingMessage = $state('');
	let cancelling = $state(false);

	// Verification state
	let verificationSending = $state(false);
	let verificationMessage = $state('');

	// Data deletion state
	let deletingData = $state(false);
	let dataDeleteMessage = $state('');

	// Account deletion state
	let deleting = $state(false);
	let deleteError = $state('');

	onMount(async () => {
		// Check for URL params
		const params = new URLSearchParams(window.location.search);
		const billingParam = params.get('billing');
		const verifiedParam = params.get('verified');
		if (billingParam === 'success') {
			billingMessage = 'Upgrade successful! Welcome to Pro.';
			window.history.replaceState({}, '', '/settings');
		} else if (billingParam === 'cancelled') {
			billingMessage = 'Checkout cancelled.';
			window.history.replaceState({}, '', '/settings');
		}
		if (verifiedParam === 'true') {
			verificationMessage = 'Email verified successfully!';
			window.history.replaceState({}, '', '/settings');
		}

		try {
			user = await getMe();
			const res = await listApiKeys();
			apiKeys = res.api_keys;
			// Load billing status
			await loadBillingStatus();
		} catch {
			// handled by layout redirect
		} finally {
			loading = false;
		}
	});

	async function loadBillingStatus() {
		try {
			billingStatus = await getBillingStatus();
		} catch {
			// Billing may not be available (503) — that's fine
			billingStatus = null;
		}
	}

	async function handleUpgrade() {
		billingLoading = true;
		billingError = '';
		try {
			const res = await createCheckout();
			window.location.href = res.url;
		} catch (e: any) {
			billingError = e.message || 'Failed to start checkout';
		} finally {
			billingLoading = false;
		}
	}

	async function handleCancel() {
		if (!confirm('Are you sure you want to cancel your Pro subscription? You will keep access until the end of your billing period.')) {
			return;
		}
		cancelling = true;
		billingError = '';
		try {
			await cancelSubscription();
			billingMessage = 'Subscription cancelled. You will keep Pro access until the end of your billing period.';
			await loadBillingStatus();
		} catch (e: any) {
			billingError = e.message || 'Failed to cancel subscription';
		} finally {
			cancelling = false;
		}
	}

	async function manageBilling() {
		billingLoading = true;
		billingError = '';
		try {
			const res = await createPortalSession();
			window.location.href = res.url;
		} catch (e: any) {
			billingError = e.message || 'Failed to open billing portal';
		} finally {
			billingLoading = false;
		}
	}

	async function handleCreateKey() {
		creating = true;
		createdKey = '';
		try {
			const res = await createApiKey(newKeyName || undefined);
			createdKey = res.key;
			apiKeys = [res.api_key, ...apiKeys];
			newKeyName = '';
		} catch {
			// ignore
		} finally {
			creating = false;
		}
	}

	async function handleRevoke(id: number) {
		await revokeApiKey(id);
		apiKeys = apiKeys.map((k) =>
			k.id === id ? { ...k, revoked_at: new Date().toISOString() } : k
		);
	}

	async function handleResendVerification() {
		verificationSending = true;
		verificationMessage = '';
		try {
			const res = await resendVerification();
			verificationMessage = res.message;
		} catch (e: any) {
			verificationMessage = e.message || 'Failed to send verification email';
		} finally {
			verificationSending = false;
		}
	}

	async function handleDeleteAllData() {
		if (!confirm('This will delete all your synced runs and metrics. Your account will remain. Continue?')) {
			return;
		}
		deletingData = true;
		dataDeleteMessage = '';
		try {
			const res = await deleteAllData();
			dataDeleteMessage = `All data deleted (${res.deleted_runs} runs removed).`;
		} catch (e: any) {
			dataDeleteMessage = e.message || 'Failed to delete data';
		} finally {
			deletingData = false;
		}
	}

	async function handleDeleteAccount() {
		if (!confirm('Are you sure? This will permanently delete your account and all data.')) {
			return;
		}
		deleting = true;
		deleteError = '';
		try {
			await deleteAccount();
			localStorage.removeItem('qualito_token');
			localStorage.removeItem('qualito_setup_token');
			window.location.href = '/login';
		} catch (e: any) {
			deleteError = e.message || 'Failed to delete account';
		} finally {
			deleting = false;
		}
	}

	function formatDate(iso: string | null): string {
		if (!iso) return '--';
		return new Date(iso).toLocaleDateString('en-US', {
			month: 'short',
			day: 'numeric',
			year: 'numeric'
		});
	}

	function formatUnixDate(ts: number | undefined): string {
		if (!ts) return '--';
		return new Date(ts * 1000).toLocaleDateString('en-US', {
			month: 'short',
			day: 'numeric',
			year: 'numeric'
		});
	}
</script>

<div class="space-y-8">
	<h1 class="text-xl font-semibold">Settings</h1>

	{#if loading}
		<div class="skeleton h-40 w-full"></div>
	{:else if user}
		<!-- Email verification banner -->
		{#if !user.email_verified}
			<div
				class="p-4 rounded-lg flex items-center justify-between"
				style="background: rgba(245,158,11,0.1); border: 1px solid rgba(245,158,11,0.3);"
			>
				<div>
					<div class="text-sm font-medium" style="color: var(--warning, #f59e0b);">
						Verify your email to unlock all features
					</div>
					{#if verificationMessage}
						<div class="text-xs mt-1" style="color: var(--text-muted)">{verificationMessage}</div>
					{/if}
				</div>
				<button
					class="btn btn-primary text-xs"
					disabled={verificationSending}
					onclick={handleResendVerification}
				>
					{verificationSending ? 'Sending...' : 'Resend verification email'}
				</button>
			</div>
		{/if}

		<!-- Account -->
		<section>
			<h2 class="section-title">Account</h2>
			<div class="card p-5 space-y-3">
				<div class="flex items-center gap-3">
					<div
						class="w-10 h-10 rounded-full flex items-center justify-center text-sm font-semibold"
						style="background: var(--accent-subtle); color: var(--accent);"
					>
						{(user.name || user.email)[0].toUpperCase()}
					</div>
					<div>
						<div class="text-sm font-medium" style="color: var(--text)">
							{user.name || 'No name set'}
						</div>
						<div class="text-xs" style="color: var(--text-muted)">{user.email}</div>
					</div>
				</div>
			</div>
		</section>

		<!-- Billing -->
		<section>
			<h2 class="section-title">Billing</h2>

			{#if billingMessage}
				<div
					class="mb-4 p-4 rounded-lg"
					style="background: var(--success-muted); border: 1px solid rgba(52,211,153,0.3);"
				>
					<div class="text-sm" style="color: var(--success)">{billingMessage}</div>
				</div>
			{/if}

			{#if billingError}
				<div
					class="mb-4 p-4 rounded-lg"
					style="background: rgba(239,68,68,0.1); border: 1px solid rgba(239,68,68,0.3);"
				>
					<div class="text-sm" style="color: var(--error, #ef4444)">{billingError}</div>
				</div>
			{/if}

			<div class="card p-5">
				<div class="flex items-center justify-between">
					<div>
						<div class="text-sm font-medium capitalize" style="color: var(--text)">
							{user.plan} plan
						</div>
						<div class="text-xs" style="color: var(--text-muted)">
							{#if user.plan === 'free'}
								100 runs, 3 workspaces. Upgrade for unlimited.
							{:else}
								Unlimited runs and workspaces.
							{/if}
						</div>
					</div>

					{#if user.plan === 'free'}
						<button
							class="btn btn-primary"
							disabled={billingLoading}
							onclick={handleUpgrade}
						>
							{billingLoading ? 'Loading...' : 'Upgrade to Pro'}
						</button>
					{/if}
				</div>

				{#if user.plan === 'pro' && billingStatus}
					<div class="mt-4 pt-4 space-y-2" style="border-top: 1px solid var(--border-subtle);">
						<div class="flex justify-between text-sm">
							<span style="color: var(--text-muted)">Status</span>
							<span class="capitalize" style="color: var(--text)">{billingStatus.status}</span>
						</div>
						{#if billingStatus.current_period_end}
							<div class="flex justify-between text-sm">
								<span style="color: var(--text-muted)">Next billing date</span>
								<span style="color: var(--text)">{formatUnixDate(billingStatus.current_period_end)}</span>
							</div>
						{/if}
						{#if billingStatus.cancel_at_period_end}
							<div class="text-xs p-2 rounded" style="background: rgba(245,158,11,0.1); color: var(--warning, #f59e0b);">
								Cancels at end of billing period
							</div>
						{:else}
							<div class="flex items-center gap-2 mt-2">
								<button
									class="btn btn-primary text-xs"
									disabled={billingLoading}
									onclick={manageBilling}
								>
									{billingLoading ? 'Loading...' : 'Manage Billing'}
								</button>
								<button
									class="btn btn-ghost text-xs"
									style="color: var(--text-muted);"
									disabled={cancelling}
									onclick={handleCancel}
								>
									{cancelling ? 'Cancelling...' : 'Cancel subscription'}
								</button>
							</div>
						{/if}
					</div>
				{/if}
			</div>
		</section>

		<!-- MCP Configuration -->
		<section>
			<h2 class="section-title">MCP Configuration</h2>
			<div class="card p-5 space-y-3">
				<p class="text-xs" style="color: var(--text-muted)">
					Add this to your <a href="https://docs.anthropic.com/en/docs/claude-code/mcp" target="_blank" rel="noopener" style="color: var(--accent); text-decoration: underline;">Claude Code settings</a> to connect Qualito.
				</p>
				{#if apiKeys.length > 0 && !apiKeys[0].revoked_at}
					{@const mcpKey = apiKeys.find(k => !k.revoked_at)}
					{#if mcpKey}
						{@const mcpConfig = JSON.stringify({ qualito: { type: 'http', url: `https://api.qualito.ai/mcp/?key=${mcpKey.key_prefix}...` } }, null, 2)}
						<div class="relative">
							<pre class="font-mono text-xs px-4 py-3 rounded-lg overflow-x-auto"
								style="background: var(--bg-inset); color: var(--accent-hover); border: 1px solid var(--border-subtle); line-height: 1.6; margin: 0;">{mcpConfig}</pre>
						</div>
						<p class="text-xs" style="color: var(--text-faint)">
							The full API key is shown only at creation. Use the key prefix above to identify which key to use, or create a new one below.
						</p>
					{/if}
				{:else}
					<p class="text-xs" style="color: var(--text-muted)">
						Create an API key below to get your MCP config.
					</p>
				{/if}
			</div>
		</section>

		<!-- API Keys -->
		<section>
			<h2 class="section-title">API Keys</h2>

			{#if createdKey}
				<div
					class="mb-4 p-4 rounded-lg"
					style="background: var(--success-muted); border: 1px solid rgba(52,211,153,0.3);"
				>
					<div class="text-xs font-medium mb-1" style="color: var(--success)">
						Key created -- copy it now, it won't be shown again
					</div>
					<code class="text-sm font-mono break-all" style="color: var(--text)">{createdKey}</code>
				</div>
			{/if}

			<div class="card p-5 space-y-4">
				<!-- Create form -->
				<form
					onsubmit={(e) => { e.preventDefault(); handleCreateKey(); }}
					class="flex gap-2"
				>
					<input
						type="text"
						bind:value={newKeyName}
						class="input flex-1"
						placeholder="Key name (optional)"
					/>
					<button type="submit" class="btn btn-primary" disabled={creating}>
						{creating ? 'Creating...' : 'Create Key'}
					</button>
				</form>

				<!-- Key list -->
				{#if apiKeys.length === 0}
					<p class="text-sm" style="color: var(--text-muted)">No API keys yet.</p>
				{:else}
					<div class="space-y-2">
						{#each apiKeys as key}
							<div
								class="flex items-center justify-between px-3 py-2 rounded-lg"
								style="background: var(--bg-inset); border: 1px solid var(--border-subtle);
									opacity: {key.revoked_at ? '0.5' : '1'};"
							>
								<div class="flex-1 min-w-0">
									<div class="flex items-center gap-2">
										<span class="text-sm font-mono" style="color: var(--text-secondary)">
											{key.key_prefix}...
										</span>
										{#if key.name}
											<span class="text-xs" style="color: var(--text-muted)">{key.name}</span>
										{/if}
										{#if key.revoked_at}
											<span class="badge badge-error">Revoked</span>
										{/if}
									</div>
									<div class="text-xs mt-0.5" style="color: var(--text-faint)">
										Created {formatDate(key.created_at)}
										{#if key.last_used_at}
											&middot; Last used {formatDate(key.last_used_at)}
										{/if}
									</div>
								</div>
								{#if !key.revoked_at}
									<button
										class="btn btn-ghost text-xs"
										onclick={() => handleRevoke(key.id)}
									>
										Revoke
									</button>
								{/if}
							</div>
						{/each}
					</div>
				{/if}
			</div>
		</section>

		<!-- Danger Zone -->
		<section>
			<h2 class="section-title">Danger Zone</h2>
			{#if dataDeleteMessage}
				<div
					class="mb-4 p-4 rounded-lg"
					style="background: var(--success-muted); border: 1px solid rgba(52,211,153,0.3);"
				>
					<div class="text-sm" style="color: var(--success)">{dataDeleteMessage}</div>
				</div>
			{/if}
			{#if deleteError}
				<div
					class="mb-4 p-4 rounded-lg"
					style="background: rgba(239,68,68,0.1); border: 1px solid rgba(239,68,68,0.3);"
				>
					<div class="text-sm" style="color: var(--error, #ef4444)">{deleteError}</div>
				</div>
			{/if}
			<div
				class="card p-5 space-y-4"
				style="border: 1px solid rgba(239,68,68,0.3);"
			>
				<div class="flex items-center justify-between">
					<div>
						<div class="text-sm font-medium" style="color: var(--text)">Delete all data</div>
						<div class="text-xs" style="color: var(--text-muted)">
							Delete all synced runs and metrics. Your account will remain.
						</div>
					</div>
					<button
						class="btn text-xs"
						style="background: rgba(239,68,68,0.15); color: #ef4444; border: 1px solid rgba(239,68,68,0.3);"
						disabled={deletingData}
						onclick={handleDeleteAllData}
					>
						{deletingData ? 'Deleting...' : 'Delete All Data'}
					</button>
				</div>
				<div style="border-top: 1px solid var(--border-subtle);"></div>
				<div class="flex items-center justify-between">
					<div>
						<div class="text-sm font-medium" style="color: var(--text)">Delete account</div>
						<div class="text-xs" style="color: var(--text-muted)">
							Permanently delete your account, API keys, and all associated data.
						</div>
					</div>
					<button
						class="btn text-xs"
						style="background: rgba(239,68,68,0.15); color: #ef4444; border: 1px solid rgba(239,68,68,0.3);"
						disabled={deleting}
						onclick={handleDeleteAccount}
					>
						{deleting ? 'Deleting...' : 'Delete Account'}
					</button>
				</div>
			</div>
		</section>
	{/if}
</div>
