<script lang="ts">
	import { onMount } from 'svelte';
	import Card from '$lib/components/Card.svelte';
	import Badge from '$lib/components/Badge.svelte';
	import StatusBadge from '$lib/components/StatusBadge.svelte';
	import { listIncidents } from '$lib/api';
	import { formatDate, severityColor } from '$lib/format';
	import type { Incident } from '$lib/types';

	let incidents = $state<Incident[]>([]);
	let error = $state<string | null>(null);
	let loading = $state(true);

	// Filters
	let filterWorkspace = $state('');
	let filterStatus = $state('');
	let filterSeverity = $state('');

	async function fetchIncidents() {
		loading = true;
		error = null;
		try {
			const params: Record<string, string> = {};
			if (filterWorkspace) params.workspace = filterWorkspace;
			if (filterStatus) params.status = filterStatus;
			if (filterSeverity) params.severity = filterSeverity;
			const res = await listIncidents(params);
			incidents = res.incidents;
		} catch (e) {
			error = e instanceof Error ? e.message : 'Failed to load incidents';
		} finally {
			loading = false;
		}
	}

	onMount(fetchIncidents);

	let workspaces = $derived(() => {
		const ws = new Set<string>();
		for (const i of incidents) if (i.workspace) ws.add(i.workspace);
		return [...ws].sort();
	});

	let statuses = $derived(() => {
		const s = new Set<string>();
		for (const i of incidents) if (i.status) s.add(i.status);
		return [...s].sort();
	});

	function severityVariant(sev: string): 'error' | 'warning' | 'info' | 'neutral' {
		if (sev === 'critical') return 'error';
		if (sev === 'warning') return 'warning';
		if (sev === 'info') return 'info';
		return 'neutral';
	}

	function onFilterChange() {
		fetchIncidents();
	}
</script>

<div class="space-y-6">
	<h1 class="text-xl font-semibold" style="color: var(--text)">Incidents</h1>

	<!-- Filter bar -->
	<div class="flex flex-wrap gap-3 items-center">
		<select class="select-field text-sm" bind:value={filterSeverity} onchange={onFilterChange}>
			<option value="">All severities</option>
			<option value="critical">Critical</option>
			<option value="warning">Warning</option>
			<option value="info">Info</option>
		</select>

		<select class="select-field text-sm" bind:value={filterStatus} onchange={onFilterChange}>
			<option value="">All statuses</option>
			{#each statuses() as s}
				<option value={s}>{s}</option>
			{/each}
		</select>

		<select class="select-field text-sm" bind:value={filterWorkspace} onchange={onFilterChange}>
			<option value="">All workspaces</option>
			{#each workspaces() as ws}
				<option value={ws}>{ws}</option>
			{/each}
		</select>

		<span class="text-xs ml-auto" style="color: var(--text-muted)">
			{incidents.length} incident{incidents.length !== 1 ? 's' : ''}
		</span>
	</div>

	{#if error}
		<div class="card p-4" style="border-color: var(--error)">
			<p style="color: var(--error)">{error}</p>
		</div>
	{:else if loading}
		<div class="space-y-2">
			{#each Array(5) as _}
				<div class="skeleton h-12 rounded-lg"></div>
			{/each}
		</div>
	{:else if incidents.length === 0}
		<Card padding="p-8">
			<p class="text-center text-sm" style="color: var(--text-muted)">No incidents found</p>
		</Card>
	{:else}
		<div class="table-container">
			<table>
				<thead>
					<tr>
						<th style="width: 4px; padding: 0;"></th>
						<th>Severity</th>
						<th>Title</th>
						<th>Workspace</th>
						<th>Status</th>
						<th>Detector</th>
						<th>Date</th>
					</tr>
				</thead>
				<tbody>
					{#each incidents as incident}
						<tr class="cursor-pointer" onclick={() => window.location.href = `/incidents/${incident.id}`}>
							<td style="padding: 0; width: 4px;">
								<div style="width: 4px; height: 100%; min-height: 42px; background: {severityColor(incident.severity)};"></div>
							</td>
							<td>
								<Badge variant={severityVariant(incident.severity)} text={incident.severity} />
							</td>
							<td>
								<span class="text-sm font-medium" style="color: var(--text)">
									{incident.title}
								</span>
							</td>
							<td>
								{#if incident.workspace}
									<span class="badge badge-accent">{incident.workspace}</span>
								{:else}
									<span class="text-xs" style="color: var(--text-faint)">—</span>
								{/if}
							</td>
							<td><StatusBadge status={incident.status} /></td>
							<td>
								<span class="text-xs font-mono" style="color: var(--text-muted)">{incident.detector}</span>
							</td>
							<td class="text-sm" style="color: var(--text-muted)">{formatDate(incident.created_at)}</td>
						</tr>
					{/each}
				</tbody>
			</table>
		</div>
	{/if}
</div>
