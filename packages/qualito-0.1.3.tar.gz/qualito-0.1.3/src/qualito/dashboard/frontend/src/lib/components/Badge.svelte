<script lang="ts">
	interface Props {
		variant?: 'success' | 'warning' | 'error' | 'accent' | 'info' | 'neutral';
		text: string;
	}

	let { variant = 'neutral', text }: Props = $props();
</script>

<span class="badge badge-{variant}">{text}</span>
