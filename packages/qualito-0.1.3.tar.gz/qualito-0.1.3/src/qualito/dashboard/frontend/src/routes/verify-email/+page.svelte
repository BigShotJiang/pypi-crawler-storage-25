<script lang="ts">
	import { onMount } from 'svelte';
	import { goto } from '$app/navigation';
	import { verifyEmail } from '$lib/api';

	const params = typeof window !== 'undefined' ? new URLSearchParams(window.location.search) : null;
	const token = params?.get('token') || '';

	let status: 'verifying' | 'success' | 'error' = $state('verifying');
	let errorMessage = $state('');

	onMount(async () => {
		if (!token) {
			status = 'error';
			errorMessage = 'Missing verification token.';
			return;
		}

		try {
			await verifyEmail(token);
			status = 'success';
			setTimeout(() => {
				goto('/settings?verified=true');
			}, 2000);
		} catch (e: unknown) {
			status = 'error';
			errorMessage = e instanceof Error ? e.message : 'Verification failed';
		}
	});
</script>

<div class="min-h-screen flex items-center justify-center" style="background: var(--bg);">
	<div class="w-full max-w-sm">
		<div class="text-center mb-8">
			<span class="font-mono text-3xl font-semibold" style="color: var(--accent)">Qualito</span>
		</div>

		<div class="card p-6 text-center">
			{#if status === 'verifying'}
				<div class="flex items-center justify-center gap-2">
					<span class="inline-block w-4 h-4 border-2 border-white/30 border-t-white rounded-full animate-spin"></span>
					<span class="text-sm" style="color: var(--text-muted)">Verifying your email...</span>
				</div>
			{:else if status === 'success'}
				<div class="text-sm px-3 py-2 rounded-lg" style="background: var(--success-muted); color: var(--success);">
					Email verified! Redirecting to settings...
				</div>
			{:else}
				<div class="text-sm px-3 py-2 rounded-lg mb-4" style="background: var(--error-muted); color: var(--error);">
					{errorMessage}
				</div>
				<a
					href="/settings"
					class="btn btn-primary"
					style="text-decoration: none;"
				>
					Go to Settings
				</a>
			{/if}
		</div>
	</div>
</div>
