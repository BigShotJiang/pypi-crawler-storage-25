<script lang="ts">
	import { dqiColor } from '$lib/format';
	import { getTier } from '$lib/dqi-constants';

	interface Props {
		score: number;
		size?: number;
	}

	let { score, size = 180 }: Props = $props();

	const strokeWidth = 12;
	let radius = $derived((size - strokeWidth) / 2);
	let circumference = $derived(2 * Math.PI * radius);
	let center = $derived(size / 2);

	let dashOffset = $derived(circumference * (1 - Math.min(Math.max(score, 0), 1)));
	let color = $derived(dqiColor(score));
	let tier = $derived(getTier(score));
</script>

<div class="relative inline-flex items-center justify-center" style="width: {size}px; height: {size}px;">
	<svg width={size} height={size} class="-rotate-90">
		<!-- Background ring -->
		<circle
			cx={center}
			cy={center}
			r={radius}
			fill="none"
			stroke="var(--bg-inset)"
			stroke-width={strokeWidth}
		/>
		<!-- Score arc -->
		<circle
			cx={center}
			cy={center}
			r={radius}
			fill="none"
			stroke={color}
			stroke-width={strokeWidth}
			stroke-linecap="round"
			stroke-dasharray={circumference}
			stroke-dashoffset={dashOffset}
			style="transition: stroke-dashoffset 1s ease, stroke 0.3s ease; filter: drop-shadow(0 0 8px {color}40);"
		/>
	</svg>
	<!-- Center text -->
	<div class="absolute inset-0 flex flex-col items-center justify-center">
		<span class="text-3xl font-mono font-semibold" style="color: {color}">
			{(score * 100).toFixed(0)}
		</span>
		<span class="text-xs mt-0.5" style="color: {tier.color}">
			{tier.label}
		</span>
	</div>
</div>
