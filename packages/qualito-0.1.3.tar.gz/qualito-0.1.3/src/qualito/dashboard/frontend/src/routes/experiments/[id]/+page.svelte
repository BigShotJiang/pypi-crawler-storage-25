<script lang="ts">
	import { onMount } from 'svelte';
	import { page } from '$app/stores';
	import Breadcrumb from '$lib/components/Breadcrumb.svelte';
	import Card from '$lib/components/Card.svelte';
	import DqiGauge from '$lib/components/DqiGauge.svelte';
	import StatusBadge from '$lib/components/StatusBadge.svelte';
	import Badge from '$lib/components/Badge.svelte';
	import { getExperiment, getExperimentTransitions, transitionExperiment } from '$lib/api';
	import { formatDate, dqiColor } from '$lib/format';

	interface ExperimentDetail {
		id: number;
		name: string;
		description: string | null;
		suite_id: number | null;
		status: string;
		avg_dqi: number | null;
		created_at: string;
		completed_at: string | null;
		per_task_dqi: Record<string, number>;
		run_ids: string[];
		config_snapshot: Record<string, unknown>;
	}

	let experiment = $state<ExperimentDetail | null>(null);
	let error = $state<string | null>(null);
	let transitions = $state<string[]>([]);
	let transitioning = $state(false);

	let activeTab = $state<'overview' | 'results' | 'config'>('overview');

	let expId = $derived($page.params.id ?? '');

	onMount(async () => {
		try {
			const [exp, trans] = await Promise.all([
				getExperiment(expId),
				getExperimentTransitions(expId)
			]);
			experiment = exp as ExperimentDetail;
			transitions = trans.available_transitions;
		} catch (e) {
			error = e instanceof Error ? e.message : 'Failed to load experiment';
		}
	});

	async function doTransition(status: string) {
		if (!experiment) return;
		transitioning = true;
		try {
			await transitionExperiment(String(experiment.id), status);
			// Reload
			const [exp, trans] = await Promise.all([
				getExperiment(expId),
				getExperimentTransitions(expId)
			]);
			experiment = exp as ExperimentDetail;
			transitions = trans.available_transitions;
		} catch (e) {
			error = e instanceof Error ? e.message : 'Transition failed';
		} finally {
			transitioning = false;
		}
	}

	let taskEntries = $derived(() => {
		if (!experiment?.per_task_dqi) return [];
		return Object.entries(experiment.per_task_dqi).sort((a, b) => a[0].localeCompare(b[0]));
	});

	let taskCount = $derived(() => {
		return experiment?.per_task_dqi ? Object.keys(experiment.per_task_dqi).length : 0;
	});

	let runCount = $derived(() => {
		return experiment?.run_ids?.length ?? 0;
	});

	const tabs = ['overview', 'results', 'config'] as const;
</script>

<div class="space-y-6">
	<Breadcrumb items={[
		{ label: 'Experiments', href: '/experiments' },
		{ label: experiment?.name ?? expId }
	]} />

	{#if error}
		<div class="card p-4" style="border-color: var(--error)">
			<p style="color: var(--error)">{error}</p>
		</div>
	{:else if !experiment}
		<div class="space-y-4">
			<div class="skeleton h-10 w-64 rounded-lg"></div>
			<div class="grid grid-cols-1 md:grid-cols-3 gap-4">
				{#each Array(3) as _}
					<div class="skeleton h-24 rounded-xl"></div>
				{/each}
			</div>
		</div>
	{:else}
		<!-- Header -->
		<div class="flex flex-wrap items-center gap-3">
			<h1 class="text-lg font-semibold" style="color: var(--text)">{experiment.name}</h1>
			<StatusBadge status={experiment.status} />
			<span class="text-xs" style="color: var(--text-muted)">{formatDate(experiment.created_at)}</span>
			{#if experiment.completed_at}
				<span class="text-xs" style="color: var(--text-faint)">→ {formatDate(experiment.completed_at)}</span>
			{/if}
		</div>

		<!-- Metric cards -->
		<div class="grid grid-cols-2 md:grid-cols-4 gap-4">
			<Card padding="p-4">
				<div class="flex flex-col items-center">
					<DqiGauge score={experiment.avg_dqi ?? 0} size={100} />
					<span class="text-[10px] mt-1" style="color: var(--text-faint)">Avg DQI</span>
				</div>
			</Card>
			<div class="metric-card">
				<div class="relative z-10">
					<p class="text-xs" style="color: var(--text-faint)">Tasks</p>
					<p class="text-2xl font-semibold font-mono mt-1" style="color: var(--text)">{taskCount()}</p>
				</div>
			</div>
			<div class="metric-card">
				<div class="relative z-10">
					<p class="text-xs" style="color: var(--text-faint)">Runs</p>
					<p class="text-2xl font-semibold font-mono mt-1" style="color: var(--text)">{runCount()}</p>
				</div>
			</div>
			<div class="metric-card">
				<div class="relative z-10">
					<p class="text-xs" style="color: var(--text-faint)">Suite ID</p>
					<p class="text-2xl font-semibold font-mono mt-1" style="color: var(--text)">
						{experiment.suite_id ?? '—'}
					</p>
				</div>
			</div>
		</div>

		<!-- Transition actions -->
		{#if transitions.length > 0}
			<div class="flex gap-2">
				{#each transitions as t}
					<button
						class="btn btn-secondary text-xs"
						onclick={() => doTransition(t)}
						disabled={transitioning}
					>
						→ {t}
					</button>
				{/each}
			</div>
		{/if}

		<!-- Tabs -->
		<div class="flex gap-1" style="border-bottom: 1px solid var(--border)">
			{#each tabs as tab}
				<button
					class="px-4 py-2 text-xs font-medium transition-colors"
					style="color: {activeTab === tab ? 'var(--accent)' : 'var(--text-muted)'};
						border-bottom: 2px solid {activeTab === tab ? 'var(--accent)' : 'transparent'};"
					onclick={() => activeTab = tab}
				>
					{tab[0].toUpperCase() + tab.slice(1)}
				</button>
			{/each}
		</div>

		<!-- Tab content -->
		{#if activeTab === 'overview'}
			<Card title="Description" padding="p-5">
				<p class="text-sm" style="color: var(--text-secondary); white-space: pre-wrap;">
					{experiment.description ?? 'No description provided.'}
				</p>
			</Card>

			{#if experiment.run_ids.length > 0}
				<Card title="Associated Runs" padding="p-0">
					<div class="table-container" style="border: none; border-radius: 0;">
						<table>
							<thead>
								<tr>
									<th>Run ID</th>
								</tr>
							</thead>
							<tbody>
								{#each experiment.run_ids as rid}
									<tr class="cursor-pointer" onclick={() => window.location.href = `/runs/${rid}`}>
										<td>
											<span class="font-mono text-xs" style="color: var(--accent)">{rid.slice(0, 12)}</span>
										</td>
									</tr>
								{/each}
							</tbody>
						</table>
					</div>
				</Card>
			{/if}

		{:else if activeTab === 'results'}
			{#if taskEntries().length > 0}
				<Card title="Per-Task DQI" padding="p-0">
					<div class="table-container" style="border: none; border-radius: 0;">
						<table>
							<thead>
								<tr>
									<th>Task</th>
									<th>DQI Score</th>
									<th>Bar</th>
								</tr>
							</thead>
							<tbody>
								{#each taskEntries() as [label, score]}
									<tr>
										<td>
											<span class="text-sm font-medium" style="color: var(--text)">{label}</span>
										</td>
										<td>
											<span class="font-mono text-sm font-semibold" style="color: {dqiColor(score)}">
												{(score * 100).toFixed(0)}
											</span>
										</td>
										<td>
											<div class="w-24 h-1.5 rounded-full" style="background: var(--bg-inset)">
												<div class="h-full rounded-full" style="width: {score * 100}%; background: {dqiColor(score)}"></div>
											</div>
										</td>
									</tr>
								{/each}
							</tbody>
						</table>
					</div>
				</Card>
			{:else}
				<Card padding="p-8">
					<p class="text-center text-sm" style="color: var(--text-muted)">No task results yet</p>
				</Card>
			{/if}

		{:else if activeTab === 'config'}
			<Card title="Config Snapshot" padding="p-5">
				<pre class="text-xs font-mono overflow-x-auto" style="color: var(--text-secondary)">{JSON.stringify(experiment.config_snapshot, null, 2)}</pre>
			</Card>
		{/if}
	{/if}
</div>
