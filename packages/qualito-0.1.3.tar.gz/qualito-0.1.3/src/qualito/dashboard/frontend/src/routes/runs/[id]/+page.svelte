<script lang="ts">
	import { onMount } from 'svelte';
	import { page } from '$app/stores';
	import Breadcrumb from '$lib/components/Breadcrumb.svelte';
	import Card from '$lib/components/Card.svelte';
	import DqiGauge from '$lib/components/DqiGauge.svelte';
	import DqiBreakdown from '$lib/components/DqiBreakdown.svelte';
	import StatusBadge from '$lib/components/StatusBadge.svelte';
	import Badge from '$lib/components/Badge.svelte';
	import { getRun } from '$lib/api';
	import { formatDate, formatCost, dqiColor } from '$lib/format';
	import type { RunDetail } from '$lib/types';

	let run = $state<RunDetail | null>(null);
	let error = $state<string | null>(null);

	let runId = $derived($page.params.id ?? '');

	onMount(async () => {
		try {
			run = await getRun(runId!);
		} catch (e) {
			error = e instanceof Error ? e.message : 'Failed to load run';
		}
	});

	function formatDurationMs(ms: number | null): string {
		if (ms == null) return '—';
		const secs = ms / 1000;
		if (secs < 60) return `${Math.round(secs)}s`;
		const m = Math.floor(secs / 60);
		const s = Math.round(secs % 60);
		if (m < 60) return `${m}m ${s}s`;
		const h = Math.floor(m / 60);
		const rm = m % 60;
		return `${h}h ${rm}m`;
	}

	function formatTokens(n: number | null): string {
		if (n == null) return '—';
		if (n >= 1_000_000) return `${(n / 1_000_000).toFixed(1)}M`;
		if (n >= 1000) return `${(n / 1000).toFixed(1)}k`;
		return String(n);
	}

	// Build DQI dimension scores from evaluations
	let dimensionScores = $derived(() => {
		if (!run?.evaluations) return {};
		const scores: Record<string, number> = {};
		for (const ev of run.evaluations) {
			if (ev.eval_type !== 'dqi' && ev.dimension) {
				scores[ev.dimension] = ev.score;
			}
		}
		return scores;
	});

	// Get the overall DQI score
	let dqiScore = $derived(() => {
		if (!run?.evaluations) return null;
		const dqiEval = run.evaluations.find((e) => e.eval_type === 'dqi');
		return dqiEval ? dqiEval.score : run.dqi;
	});

	// Non-DQI evaluations (auto-eval checks)
	let autoEvals = $derived(() => {
		if (!run?.evaluations) return [];
		return run.evaluations.filter((e) => e.eval_type !== 'dqi');
	});
</script>

<div class="space-y-6">
	<Breadcrumb items={[
		{ label: 'Runs', href: '/runs' },
		{ label: runId.slice(0, 8) }
	]} />

	{#if error}
		<div class="card p-4" style="border-color: var(--error)">
			<p style="color: var(--error)">{error}</p>
		</div>
	{:else if !run}
		<div class="space-y-4">
			<div class="skeleton h-10 w-64 rounded-lg"></div>
			<div class="grid grid-cols-1 md:grid-cols-4 gap-4">
				{#each Array(4) as _}
					<div class="skeleton h-24 rounded-xl"></div>
				{/each}
			</div>
		</div>
	{:else}
		<!-- Header -->
		<div class="flex flex-wrap items-center gap-3">
			<h1 class="text-lg font-semibold font-mono" style="color: var(--text)">{run.id.slice(0, 12)}</h1>
			{#if run.workspace}
				<span class="badge badge-accent">{run.workspace}</span>
			{/if}
			<StatusBadge status={run.status} />
			<span class="text-xs" style="color: var(--text-muted)">{formatDate(run.started_at)}</span>
			{#if run.model}
				<span class="badge badge-neutral">{run.model}</span>
			{/if}
		</div>

		<!-- Metric cards row -->
		<div class="grid grid-cols-2 md:grid-cols-5 gap-4">
			<Card padding="p-4">
				<div class="flex flex-col items-center">
					<DqiGauge score={dqiScore() ?? 0} size={100} />
					<span class="text-[10px] mt-1" style="color: var(--text-faint)">DQI Score</span>
				</div>
			</Card>
			<div class="metric-card">
				<div class="relative z-10">
					<p class="text-xs" style="color: var(--text-faint)">Cost</p>
					<p class="text-xl font-semibold font-mono mt-1" style="color: var(--text)">{formatCost(run.cost_usd)}</p>
				</div>
			</div>
			<div class="metric-card">
				<div class="relative z-10">
					<p class="text-xs" style="color: var(--text-faint)">Duration</p>
					<p class="text-xl font-semibold font-mono mt-1" style="color: var(--text)">{formatDurationMs(run.duration_ms)}</p>
				</div>
			</div>
			<div class="metric-card">
				<div class="relative z-10">
					<p class="text-xs" style="color: var(--text-faint)">Input Tokens</p>
					<p class="text-xl font-semibold font-mono mt-1" style="color: var(--text)">{formatTokens(run.input_tokens)}</p>
				</div>
			</div>
			<div class="metric-card">
				<div class="relative z-10">
					<p class="text-xs" style="color: var(--text-faint)">Output Tokens</p>
					<p class="text-xl font-semibold font-mono mt-1" style="color: var(--text)">{formatTokens(run.output_tokens)}</p>
					{#if run.cache_read_tokens}
						<p class="text-[10px] mt-0.5" style="color: var(--text-faint)">
							+{formatTokens(run.cache_read_tokens)} cache
						</p>
					{/if}
				</div>
			</div>
		</div>

		<!-- DQI Breakdown -->
		{#if Object.keys(dimensionScores()).length > 0}
			<Card title="DQI Breakdown" padding="p-5">
				<DqiBreakdown scores={dimensionScores()} />
			</Card>
		{/if}

		<!-- Task / Summary -->
		<Card title="Task" padding="p-5">
			<p class="text-sm" style="color: var(--text-secondary); white-space: pre-wrap;">{run.task}</p>
		</Card>

		{#if run.summary}
			<Card title="Summary" padding="p-5">
				<p class="text-sm" style="color: var(--text-secondary); white-space: pre-wrap;">{run.summary}</p>
			</Card>
		{/if}

		<!-- Evaluations -->
		{#if autoEvals().length > 0}
			<Card title="Evaluations" padding="p-0">
				<div class="table-container" style="border: none; border-radius: 0;">
					<table>
						<thead>
							<tr>
								<th>Check</th>
								<th>Score</th>
								<th>Type</th>
								<th>Detail</th>
							</tr>
						</thead>
						<tbody>
							{#each autoEvals() as ev}
								<tr>
									<td>
										<span class="text-sm font-medium" style="color: var(--text)">
											{ev.dimension ?? ev.eval_type}
										</span>
									</td>
									<td>
										<span class="font-mono text-sm font-semibold" style="color: {dqiColor(ev.score)}">
											{(ev.score * 100).toFixed(0)}
										</span>
									</td>
									<td>
										<Badge variant={ev.evaluator === 'auto' ? 'info' : 'accent'} text={ev.evaluator} />
									</td>
									<td class="text-sm" style="color: var(--text-muted)">
										{ev.detail ?? '—'}
									</td>
								</tr>
							{/each}
						</tbody>
					</table>
				</div>
			</Card>
		{/if}

		<!-- Tool Calls -->
		{#if run.tool_calls && run.tool_calls.length > 0}
			<Card title="Tool Calls ({run.tool_calls.length})" padding="p-0">
				<div class="table-container" style="border: none; border-radius: 0;">
					<table>
						<thead>
							<tr>
								<th>Tool</th>
								<th>Duration</th>
								<th>Status</th>
							</tr>
						</thead>
						<tbody>
							{#each run.tool_calls.slice(0, 50) as tc}
								<tr>
									<td class="font-mono text-xs" style="color: var(--text-secondary)">{tc.tool_name}</td>
									<td class="text-xs" style="color: var(--text-muted)">
										{tc.duration_ms != null ? `${tc.duration_ms}ms` : '—'}
									</td>
									<td>
										{#if tc.error}
											<span class="text-xs" style="color: var(--error)">error</span>
										{:else}
											<span class="text-xs" style="color: var(--success)">ok</span>
										{/if}
									</td>
								</tr>
							{/each}
						</tbody>
					</table>
					{#if run.tool_calls.length > 50}
						<div class="p-2 text-center text-xs" style="color: var(--text-faint)">
							Showing 50 of {run.tool_calls.length} tool calls
						</div>
					{/if}
				</div>
			</Card>
		{/if}

		<!-- File Activity -->
		{#if run.file_activity && run.file_activity.length > 0}
			<Card title="File Activity ({run.file_activity.length})" padding="p-0">
				<div class="table-container" style="border: none; border-radius: 0;">
					<table>
						<thead>
							<tr>
								<th>File</th>
								<th>Action</th>
							</tr>
						</thead>
						<tbody>
							{#each run.file_activity.slice(0, 30) as fa}
								<tr>
									<td class="font-mono text-xs" style="color: var(--text-secondary)">{fa.file_path}</td>
									<td>
										<Badge
											variant={fa.action === 'create' ? 'success' : fa.action === 'delete' ? 'error' : 'neutral'}
											text={fa.action}
										/>
									</td>
								</tr>
							{/each}
						</tbody>
					</table>
					{#if run.file_activity.length > 30}
						<div class="p-2 text-center text-xs" style="color: var(--text-faint)">
							Showing 30 of {run.file_activity.length} files
						</div>
					{/if}
				</div>
			</Card>
		{/if}
	{/if}
</div>
