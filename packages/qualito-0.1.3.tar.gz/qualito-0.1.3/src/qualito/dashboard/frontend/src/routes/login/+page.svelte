<script lang="ts">
	import { goto } from '$app/navigation';
	import { login, register, forgotPassword } from '$lib/api';

	let mode: 'login' | 'register' = $state('login');
	let email = $state('');
	let password = $state('');
	let name = $state('');
	let tosAccepted = $state(false);
	let privacyAccepted = $state(false);
	let marketingOptIn = $state(false);
	let error = $state('');
	let loading = $state(false);

	// Forgot password state
	let showForgotPassword = $state(false);
	let forgotEmail = $state('');
	let forgotLoading = $state(false);
	let forgotMessage = $state('');

	// Check for URL message params
	const urlParams = typeof window !== 'undefined' ? new URLSearchParams(window.location.search) : null;
	let urlMessage = $state(urlParams?.get('message') || '');

	async function handleSubmit() {
		error = '';
		loading = true;
		try {
			const result =
				mode === 'login'
					? await login(email, password)
					: await register(email, password, name || undefined, {
							tos_accepted: tosAccepted,
							privacy_accepted: privacyAccepted,
							marketing_opt_in: marketingOptIn
						});

			localStorage.setItem('qualito_token', result.token);
			localStorage.setItem('qualito_user', JSON.stringify(result.user));
			if ('setup_token' in result && result.setup_token) {
				localStorage.setItem('qualito_setup_token', result.setup_token);
			}
			if ('api_key' in result && result.api_key) {
				localStorage.setItem('qualito_api_key', result.api_key);
			}
			goto('/');
		} catch (e: unknown) {
			error = e instanceof Error ? e.message : 'Something went wrong';
		} finally {
			loading = false;
		}
	}

	async function handleForgotPassword() {
		forgotMessage = '';
		error = '';
		forgotLoading = true;
		try {
			const res = await forgotPassword(forgotEmail);
			forgotMessage = res.message;
		} catch (e: unknown) {
			error = e instanceof Error ? e.message : 'Something went wrong';
		} finally {
			forgotLoading = false;
		}
	}
</script>

<div class="min-h-screen flex items-center justify-center" style="background: var(--bg);">
	<div class="w-full max-w-sm">
		<!-- Logo -->
		<div class="text-center mb-8">
			<span class="font-mono text-3xl font-semibold" style="color: var(--accent)">Qualito</span>
			<p class="mt-2 text-sm" style="color: var(--text-muted)">Quality metrics for AI-assisted development</p>
		</div>

		<!-- Card -->
		<div class="card p-6">
			{#if urlMessage}
				<div class="mb-4 text-sm px-3 py-2 rounded-lg" style="background: var(--success-muted); color: var(--success);">
					{urlMessage}
				</div>
			{/if}

			{#if showForgotPassword}
				<!-- Forgot password form -->
				<div class="mb-4">
					<button
						class="text-xs"
						style="color: var(--text-muted)"
						onclick={() => { showForgotPassword = false; forgotMessage = ''; error = ''; }}
					>
						&larr; Back to login
					</button>
				</div>
				<h2 class="text-sm font-semibold mb-4" style="color: var(--text)">Reset Password</h2>

				{#if forgotMessage}
					<div class="text-sm px-3 py-2 rounded-lg mb-4" style="background: var(--success-muted); color: var(--success);">
						{forgotMessage}
					</div>
				{/if}

				<form onsubmit={(e) => { e.preventDefault(); handleForgotPassword(); }} class="space-y-4">
					<div>
						<label class="block text-xs font-medium mb-1.5" style="color: var(--text-secondary);">Email</label>
						<input
							type="email"
							bind:value={forgotEmail}
							class="input w-full"
							placeholder="you@example.com"
							required
						/>
					</div>

					{#if error}
						<div class="text-sm px-3 py-2 rounded-lg" style="background: var(--error-muted); color: var(--error);">
							{error}
						</div>
					{/if}

					<button
						type="submit"
						class="btn btn-primary w-full justify-center"
						disabled={forgotLoading}
					>
						{forgotLoading ? 'Sending...' : 'Send Reset Link'}
					</button>
				</form>
			{:else}
				<!-- Mode toggle -->
				<div class="flex rounded-lg overflow-hidden mb-6" style="background: var(--bg-inset); border: 1px solid var(--border);">
					<button
						class="flex-1 py-2 text-sm font-medium transition-all"
						style="background: {mode === 'login' ? 'var(--accent-subtle)' : 'transparent'};
							color: {mode === 'login' ? 'var(--accent)' : 'var(--text-muted)'};"
						onclick={() => { mode = 'login'; error = ''; }}
					>
						Sign In
					</button>
					<button
						class="flex-1 py-2 text-sm font-medium transition-all"
						style="background: {mode === 'register' ? 'var(--accent-subtle)' : 'transparent'};
							color: {mode === 'register' ? 'var(--accent)' : 'var(--text-muted)'};"
						onclick={() => { mode = 'register'; error = ''; }}
					>
						Register
					</button>
				</div>

				<form onsubmit={(e) => { e.preventDefault(); handleSubmit(); }} class="space-y-4">
					{#if mode === 'register'}
						<div>
							<label class="block text-xs font-medium mb-1.5" style="color: var(--text-secondary);">Name</label>
							<input
								type="text"
								bind:value={name}
								class="input w-full"
								placeholder="Your name"
							/>
						</div>
					{/if}

					<div>
						<label class="block text-xs font-medium mb-1.5" style="color: var(--text-secondary);">Email</label>
						<input
							type="email"
							bind:value={email}
							class="input w-full"
							placeholder="you@example.com"
							required
						/>
					</div>

					<div>
						<label class="block text-xs font-medium mb-1.5" style="color: var(--text-secondary);">Password</label>
						<input
							type="password"
							bind:value={password}
							class="input w-full"
							placeholder="Min 8 characters"
							required
							minlength="8"
						/>
					</div>

					{#if mode === 'login'}
						<div class="text-right">
							<button
								type="button"
								class="text-xs"
								style="color: var(--accent); background: none; border: none; cursor: pointer;"
								onclick={() => { showForgotPassword = true; forgotEmail = email; error = ''; }}
							>
								Forgot password?
							</button>
						</div>
					{/if}

					{#if mode === 'register'}
						<div class="space-y-3">
							<label class="flex items-start gap-2 cursor-pointer">
								<input type="checkbox" bind:checked={tosAccepted} class="mt-0.5" required />
								<span class="text-xs" style="color: var(--text-secondary);">
									I accept the Terms of Service
								</span>
							</label>
							<label class="flex items-start gap-2 cursor-pointer">
								<input type="checkbox" bind:checked={privacyAccepted} class="mt-0.5" required />
								<span class="text-xs" style="color: var(--text-secondary);">
									I accept the Privacy Policy
								</span>
							</label>
							<label class="flex items-start gap-2 cursor-pointer">
								<input type="checkbox" bind:checked={marketingOptIn} class="mt-0.5" />
								<span class="text-xs" style="color: var(--text-secondary);">
									Send me product updates and tips (optional)
								</span>
							</label>
						</div>
					{/if}

					{#if error}
						<div class="text-sm px-3 py-2 rounded-lg" style="background: var(--error-muted); color: var(--error);">
							{error}
						</div>
					{/if}

					<button
						type="submit"
						class="btn btn-primary w-full justify-center"
						disabled={loading}
					>
						{#if loading}
							<span class="inline-block w-4 h-4 border-2 border-white/30 border-t-white rounded-full animate-spin"></span>
						{:else}
							{mode === 'login' ? 'Sign In' : 'Create Account'}
						{/if}
					</button>
				</form>
			{/if}
		</div>
	</div>
</div>
