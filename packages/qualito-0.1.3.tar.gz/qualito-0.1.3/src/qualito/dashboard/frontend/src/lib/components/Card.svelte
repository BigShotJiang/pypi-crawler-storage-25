<script lang="ts">
	import type { Snippet } from 'svelte';

	interface Props {
		title?: string;
		variant?: 'default' | 'elevated' | 'inset';
		padding?: string;
		children: Snippet;
	}

	let { title, variant = 'default', padding = 'p-4', children }: Props = $props();

	const classMap = {
		default: 'card',
		elevated: 'card-elevated',
		inset: 'card-inset'
	};
</script>

<div class="{classMap[variant]} {padding}">
	{#if title}
		<h3 class="text-xs font-semibold uppercase tracking-wider mb-3" style="color: var(--text-faint)">
			{title}
		</h3>
	{/if}
	{@render children()}
</div>
