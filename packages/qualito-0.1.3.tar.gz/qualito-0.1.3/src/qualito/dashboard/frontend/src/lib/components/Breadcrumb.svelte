<script lang="ts">
	interface Crumb {
		label: string;
		href?: string;
	}

	interface Props {
		items: Crumb[];
	}

	let { items }: Props = $props();
</script>

<nav class="flex items-center gap-1.5 text-xs" style="color: var(--text-muted)">
	{#each items as item, i}
		{#if i > 0}
			<span style="color: var(--text-faint)">/</span>
		{/if}
		{#if item.href && i < items.length - 1}
			<a href={item.href} class="hover:underline" style="color: var(--text-muted); transition: color 120ms ease;">
				{item.label}
			</a>
		{:else}
			<span style="color: var(--text-secondary)">{item.label}</span>
		{/if}
	{/each}
</nav>
