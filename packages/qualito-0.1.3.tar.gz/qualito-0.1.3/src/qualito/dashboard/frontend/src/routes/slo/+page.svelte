<script lang="ts">
	import { onMount } from 'svelte';
	import Card from '$lib/components/Card.svelte';
	import Badge from '$lib/components/Badge.svelte';
	import { getSloData } from '$lib/api';
	import type { SloStatus } from '$lib/types';

	interface SloResponse {
		quality: SloStatus;
		availability: SloStatus;
		cost: SloStatus;
	}

	let slo = $state<SloResponse | null>(null);
	let error = $state<string | null>(null);

	onMount(async () => {
		try {
			slo = (await getSloData()) as SloResponse;
		} catch (e) {
			error = e instanceof Error ? e.message : 'Failed to load SLO data';
		}
	});

	interface SloItem {
		key: string;
		label: string;
		description: string;
		data: SloStatus;
	}

	let sloItems = $derived((): SloItem[] => {
		if (!slo) return [];
		return [
			{
				key: 'quality',
				label: 'Quality',
				description: '% of runs with DQI >= target',
				data: slo.quality
			},
			{
				key: 'availability',
				label: 'Availability',
				description: 'Run completion rate',
				data: slo.availability
			},
			{
				key: 'cost',
				label: 'Cost',
				description: '% of runs under cost threshold',
				data: slo.cost
			}
		];
	});

	function formatPct(v: number | null): string {
		if (v == null) return '—';
		return `${(v * 100).toFixed(1)}%`;
	}

	function progressColor(pass: boolean): string {
		return pass ? 'var(--success)' : 'var(--error)';
	}

	function progressBg(pass: boolean): string {
		return pass ? 'var(--success-muted)' : 'var(--error-muted)';
	}
</script>

<div class="space-y-6">
	<h1 class="text-xl font-semibold" style="color: var(--text)">SLO Dashboard</h1>

	{#if error}
		<div class="card p-4" style="border-color: var(--error)">
			<p style="color: var(--error)">{error}</p>
		</div>
	{:else if !slo}
		<div class="grid grid-cols-1 md:grid-cols-3 gap-6">
			{#each Array(3) as _}
				<div class="skeleton h-48 rounded-xl"></div>
			{/each}
		</div>
	{:else}
		<!-- SLO gauges -->
		<div class="grid grid-cols-1 md:grid-cols-3 gap-6">
			{#each sloItems() as item}
				{@const pct = item.data.current != null ? Math.min(item.data.current * 100, 100) : 0}
				{@const targetPct = item.data.target * 100}
				<Card padding="p-6">
					<div class="space-y-4">
						<!-- Header -->
						<div class="flex items-center justify-between">
							<div>
								<h3 class="text-sm font-semibold" style="color: var(--text)">{item.label}</h3>
								<p class="text-[10px] mt-0.5" style="color: var(--text-faint)">{item.description}</p>
							</div>
							<Badge
								variant={item.data.pass ? 'success' : 'error'}
								text={item.data.pass ? 'PASS' : 'FAIL'}
							/>
						</div>

						<!-- Large value -->
						<div class="text-center">
							<span
								class="text-4xl font-mono font-semibold"
								style="color: {progressColor(item.data.pass)}"
							>
								{formatPct(item.data.current)}
							</span>
						</div>

						<!-- Progress bar with target line -->
						<div class="relative">
							<div class="h-3 rounded-full" style="background: var(--bg-inset)">
								<div
									class="h-full rounded-full transition-all duration-700"
									style="width: {pct}%; background: {progressColor(item.data.pass)};"
								></div>
							</div>
							<!-- Target line -->
							<div
								class="absolute top-0 h-3 w-0.5"
								style="left: {targetPct}%; background: var(--text-muted);"
								title="Target: {targetPct.toFixed(0)}%"
							></div>
						</div>

						<!-- Footer -->
						<div class="flex items-center justify-between text-[10px]">
							<span style="color: var(--text-faint)">0%</span>
							<span class="font-mono" style="color: var(--text-muted)">
								Target: {(item.data.target * 100).toFixed(0)}%
							</span>
							<span style="color: var(--text-faint)">100%</span>
						</div>
					</div>
				</Card>
			{/each}
		</div>
	{/if}
</div>
