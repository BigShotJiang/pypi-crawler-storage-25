<script lang="ts">
	import { onMount } from 'svelte';
	import { page } from '$app/stores';
	import Breadcrumb from '$lib/components/Breadcrumb.svelte';
	import Card from '$lib/components/Card.svelte';
	import Badge from '$lib/components/Badge.svelte';
	import { compareExperiments } from '$lib/api';
	import { dqiColor } from '$lib/format';

	interface ComparisonData {
		before: { id: number; name: string; avg_dqi: number | null };
		after: { id: number; name: string; avg_dqi: number | null };
		per_task_delta: Record<string, { before: number; after: number; delta: number }>;
		comparison: {
			wilcoxon_p: number | null;
			p_improvement: number | null;
			effect_size: number | null;
			verdict: string;
		} | null;
	}

	let data = $state<ComparisonData | null>(null);
	let error = $state<string | null>(null);

	let beforeId = $derived($page.params.before_id ?? '');
	let afterId = $derived($page.params.after_id ?? '');

	onMount(async () => {
		try {
			data = (await compareExperiments(Number(beforeId), Number(afterId))) as ComparisonData;
		} catch (e) {
			error = e instanceof Error ? e.message : 'Failed to load comparison';
		}
	});

	let verdict = $derived(() => {
		if (!data?.comparison?.verdict) return 'inconclusive';
		return data.comparison.verdict.toLowerCase();
	});

	let verdictVariant = $derived((): 'success' | 'error' | 'warning' => {
		const v = verdict();
		if (v === 'improved') return 'success';
		if (v === 'degraded') return 'error';
		return 'warning';
	});

	let verdictColor = $derived(() => {
		const v = verdictVariant();
		if (v === 'success') return 'var(--success)';
		if (v === 'error') return 'var(--error)';
		return 'var(--warning)';
	});

	let taskDeltas = $derived(() => {
		if (!data?.per_task_delta) return [];
		return Object.entries(data.per_task_delta).sort((a, b) => a[0].localeCompare(b[0]));
	});

	function formatDelta(d: number): string {
		const pct = (d * 100).toFixed(1);
		return d >= 0 ? `+${pct}` : pct;
	}

	function deltaColor(d: number): string {
		if (d > 0.02) return 'var(--success)';
		if (d < -0.02) return 'var(--error)';
		return 'var(--text-muted)';
	}
</script>

<div class="space-y-6">
	<Breadcrumb items={[
		{ label: 'Experiments', href: '/experiments' },
		{ label: 'Compare' }
	]} />

	{#if error}
		<div class="card p-4" style="border-color: var(--error)">
			<p style="color: var(--error)">{error}</p>
		</div>
	{:else if !data}
		<div class="space-y-4">
			<div class="skeleton h-10 w-96 rounded-lg"></div>
			<div class="skeleton h-48 rounded-xl"></div>
		</div>
	{:else}
		<!-- Header: before vs after -->
		<div class="flex flex-wrap items-center gap-3">
			<a href="/experiments/{data.before.id}" class="text-sm font-medium" style="color: var(--accent)">
				{data.before.name}
			</a>
			<span class="text-xs" style="color: var(--text-faint)">vs</span>
			<a href="/experiments/{data.after.id}" class="text-sm font-medium" style="color: var(--accent)">
				{data.after.name}
			</a>
		</div>

		<!-- Verdict banner -->
		<div class="card p-4" style="border-color: {verdictColor()}; background: {verdictColor()}15;">
			<div class="flex items-center gap-3">
				<Badge variant={verdictVariant()} text={verdict().toUpperCase()} />
				<div class="flex gap-6">
					{#if data.comparison}
						{#if data.comparison.wilcoxon_p != null}
							<div>
								<span class="text-[10px] uppercase tracking-wider" style="color: var(--text-faint)">Wilcoxon p</span>
								<p class="font-mono text-sm font-semibold" style="color: var(--text)">{data.comparison.wilcoxon_p.toFixed(4)}</p>
							</div>
						{/if}
						{#if data.comparison.p_improvement != null}
							<div>
								<span class="text-[10px] uppercase tracking-wider" style="color: var(--text-faint)">P(improvement)</span>
								<p class="font-mono text-sm font-semibold" style="color: var(--text)">{(data.comparison.p_improvement * 100).toFixed(1)}%</p>
							</div>
						{/if}
						{#if data.comparison.effect_size != null}
							<div>
								<span class="text-[10px] uppercase tracking-wider" style="color: var(--text-faint)">Effect Size</span>
								<p class="font-mono text-sm font-semibold" style="color: var(--text)">{data.comparison.effect_size.toFixed(3)}</p>
							</div>
						{/if}
					{/if}
				</div>
			</div>
		</div>

		<!-- Avg DQI comparison -->
		<div class="grid grid-cols-2 gap-4">
			<div class="metric-card">
				<div class="relative z-10">
					<p class="text-xs" style="color: var(--text-faint)">Before — {data.before.name}</p>
					<p class="text-2xl font-semibold font-mono mt-1" style="color: {dqiColor(data.before.avg_dqi)}">
						{data.before.avg_dqi != null ? (data.before.avg_dqi * 100).toFixed(0) : '—'}
					</p>
				</div>
			</div>
			<div class="metric-card">
				<div class="relative z-10">
					<p class="text-xs" style="color: var(--text-faint)">After — {data.after.name}</p>
					<p class="text-2xl font-semibold font-mono mt-1" style="color: {dqiColor(data.after.avg_dqi)}">
						{data.after.avg_dqi != null ? (data.after.avg_dqi * 100).toFixed(0) : '—'}
					</p>
				</div>
			</div>
		</div>

		<!-- Per-task delta table -->
		{#if taskDeltas().length > 0}
			<Card title="Per-Task Delta" padding="p-0">
				<div class="table-container" style="border: none; border-radius: 0;">
					<table>
						<thead>
							<tr>
								<th>Task</th>
								<th>Before</th>
								<th>After</th>
								<th>Delta</th>
							</tr>
						</thead>
						<tbody>
							{#each taskDeltas() as [label, vals]}
								<tr>
									<td>
										<span class="text-sm font-medium" style="color: var(--text)">{label}</span>
									</td>
									<td>
										<span class="font-mono text-sm" style="color: {dqiColor(vals.before)}">
											{(vals.before * 100).toFixed(0)}
										</span>
									</td>
									<td>
										<span class="font-mono text-sm" style="color: {dqiColor(vals.after)}">
											{(vals.after * 100).toFixed(0)}
										</span>
									</td>
									<td>
										<span class="font-mono text-sm font-semibold" style="color: {deltaColor(vals.delta)}">
											{formatDelta(vals.delta)}
										</span>
									</td>
								</tr>
							{/each}
						</tbody>
					</table>
				</div>
			</Card>
		{:else}
			<Card padding="p-8">
				<p class="text-center text-sm" style="color: var(--text-muted)">No common tasks to compare</p>
			</Card>
		{/if}
	{/if}
</div>
