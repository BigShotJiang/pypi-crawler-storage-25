export interface Run {
	id: string;
	workspace: string;
	task: string;
	task_type: string | null;
	model: string | null;
	pipeline_mode: string | null;
	status: string;
	summary: string | null;
	files_changed: string | null;
	cost_usd: number | null;
	input_tokens: number | null;
	output_tokens: number | null;
	cache_read_tokens: number | null;
	duration_ms: number | null;
	branch: string | null;
	started_at: string;
	completed_at: string | null;
	source: string | null;
	dqi: number | null;
}

export interface RunDetail extends Run {
	prompt: string | null;
	original_prompt: string | null;
	researcher_summary: string | null;
	implementer_summary: string | null;
	verifier_verdict: string | null;
	skill_name: string | null;
	evaluations: Evaluation[];
	tool_calls: ToolCallRecord[];
	file_activity: FileActivityRecord[];
}

export interface Evaluation {
	id: number;
	run_id: string;
	eval_type: string;
	dimension: string | null;
	score: number;
	detail: string | null;
	evaluator: string;
	created_at: string;
}

export interface ToolCallRecord {
	id: number;
	run_id: string;
	tool_name: string;
	input_tokens: number | null;
	output_tokens: number | null;
	duration_ms: number | null;
	success: boolean | null;
	error: string | null;
}

export interface FileActivityRecord {
	id: number;
	run_id: string;
	file_path: string;
	action: string;
}

export interface Experiment {
	id: number;
	name: string;
	description: string | null;
	suite_id: number | null;
	status: string;
	avg_dqi: number | null;
	created_at: string;
	completed_at: string | null;
}

export interface ExperimentComparison {
	id: string;
	experiment_id: string;
	metric: string;
	baseline_mean: number;
	variant_mean: number;
	p_value: number | null;
	effect_size: number | null;
	significant: boolean;
}

export interface Incident {
	id: number;
	title: string;
	severity: 'critical' | 'warning' | 'info';
	status: string;
	detector: string;
	workspace: string | null;
	run_id: string | null;
	created_at: string;
	resolved_at: string | null;
	details: string | null;
}

export interface IncidentEvent {
	id: string;
	incident_id: string;
	event_type: string;
	message: string;
	created_at: string;
	metadata: Record<string, unknown>;
}

export interface SloData {
	name: string;
	target: number;
	current: number;
	window_days: number;
	budget_remaining: number;
	status: 'met' | 'at_risk' | 'breached';
}

export interface SloStatus {
	current: number | null;
	target: number;
	pass: boolean;
}

export interface DashboardData {
	avg_dqi: number | null;
	run_count: number;
	total_cost_30d: number;
	active_incidents: number;
	slo_status: {
		quality: SloStatus;
		availability: SloStatus;
		cost: SloStatus;
	};
}

export interface MetricsData {
	dqi_trend: { date: string; avg_dqi: number | null }[];
	cost_trend: { date: string; total_cost: number }[];
	by_workspace: WorkspaceMetric[];
	by_task_type: TaskTypeMetric[];
}

export interface WorkspaceMetric {
	workspace: string;
	run_count: number;
	avg_cost: number | null;
	total_cost: number;
	completed: number;
}

export interface TaskTypeMetric {
	task_type: string | null;
	run_count: number;
	avg_cost: number | null;
	total_cost: number;
	completed: number;
}

export interface TransitionDef {
	from: string;
	to: string;
	label: string;
}

export interface User {
	id: number;
	email: string;
	name: string | null;
	plan: string;
	email_verified: boolean;
}

export interface ApiKey {
	id: number;
	key_prefix: string;
	name: string | null;
	last_used_at: string | null;
	created_at: string;
	revoked_at: string | null;
}

export interface BillingStatus {
	status: string;
	plan: string;
	current_period_end?: number;
	cancel_at_period_end?: boolean;
	subscription_id?: string;
}

export interface SetupEvent {
	step: string;
	detail: string;
	timestamp: string;
}
