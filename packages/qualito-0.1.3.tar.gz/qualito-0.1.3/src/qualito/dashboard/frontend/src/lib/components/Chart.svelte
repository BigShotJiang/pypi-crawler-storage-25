<script lang="ts">
	import { onMount, onDestroy } from 'svelte';
	import { Chart as ChartJS, registerables } from 'chart.js';

	ChartJS.register(...registerables);

	interface Props {
		type: 'line' | 'bar' | 'doughnut';
		data: import('chart.js').ChartData;
		options?: import('chart.js').ChartOptions;
		height?: number;
	}

	let { type, data, options = {}, height = 300 }: Props = $props();

	let canvas: HTMLCanvasElement;
	let chart: ChartJS | null = null;

	const defaultOptions: import('chart.js').ChartOptions = {
		responsive: true,
		maintainAspectRatio: false,
		plugins: {
			legend: {
				display: false
			}
		},
		scales: type !== 'doughnut' ? {
			x: {
				grid: { color: 'rgba(28, 40, 53, 0.5)' },
				ticks: { color: '#64748b', font: { size: 11 } }
			},
			y: {
				grid: { color: 'rgba(28, 40, 53, 0.5)' },
				ticks: { color: '#64748b', font: { size: 11 } }
			}
		} : undefined
	};

	onMount(() => {
		chart = new ChartJS(canvas, {
			type,
			data,
			options: { ...defaultOptions, ...options }
		});
	});

	onDestroy(() => {
		chart?.destroy();
	});

	$effect(() => {
		if (chart) {
			chart.data = data;
			chart.update('none');
		}
	});
</script>

<div style="height: {height}px; position: relative;">
	<canvas bind:this={canvas}></canvas>
</div>
