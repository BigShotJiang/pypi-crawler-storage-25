<script lang="ts">
	import { goto } from '$app/navigation';
	import { resetPassword } from '$lib/api';

	const params = typeof window !== 'undefined' ? new URLSearchParams(window.location.search) : null;
	const token = params?.get('token') || '';

	let password = $state('');
	let confirmPassword = $state('');
	let error = $state('');
	let loading = $state(false);
	let success = $state(false);

	async function handleReset() {
		error = '';
		if (password !== confirmPassword) {
			error = 'Passwords do not match';
			return;
		}
		if (password.length < 8) {
			error = 'Password must be at least 8 characters';
			return;
		}

		loading = true;
		try {
			await resetPassword(token, password);
			success = true;
			setTimeout(() => {
				goto('/login?message=Password+reset+successful.+Please+sign+in.');
			}, 2000);
		} catch (e: unknown) {
			error = e instanceof Error ? e.message : 'Something went wrong';
		} finally {
			loading = false;
		}
	}
</script>

<div class="min-h-screen flex items-center justify-center" style="background: var(--bg);">
	<div class="w-full max-w-sm">
		<!-- Logo -->
		<div class="text-center mb-8">
			<span class="font-mono text-3xl font-semibold" style="color: var(--accent)">Qualito</span>
			<p class="mt-2 text-sm" style="color: var(--text-muted)">Reset your password</p>
		</div>

		<div class="card p-6">
			{#if !token}
				<div class="text-sm px-3 py-2 rounded-lg" style="background: var(--error-muted); color: var(--error);">
					Invalid or missing reset token. Please request a new password reset.
				</div>
				<a
					href="/login"
					class="btn btn-primary w-full justify-center mt-4"
					style="text-decoration: none; display: block; text-align: center;"
				>
					Back to Login
				</a>
			{:else if success}
				<div class="text-sm px-3 py-2 rounded-lg" style="background: var(--success-muted); color: var(--success);">
					Password reset successful! Redirecting to login...
				</div>
			{:else}
				<form onsubmit={(e) => { e.preventDefault(); handleReset(); }} class="space-y-4">
					<div>
						<label class="block text-xs font-medium mb-1.5" style="color: var(--text-secondary);">New Password</label>
						<input
							type="password"
							bind:value={password}
							class="input w-full"
							placeholder="Min 8 characters"
							required
							minlength="8"
						/>
					</div>

					<div>
						<label class="block text-xs font-medium mb-1.5" style="color: var(--text-secondary);">Confirm Password</label>
						<input
							type="password"
							bind:value={confirmPassword}
							class="input w-full"
							placeholder="Repeat password"
							required
							minlength="8"
						/>
					</div>

					{#if error}
						<div class="text-sm px-3 py-2 rounded-lg" style="background: var(--error-muted); color: var(--error);">
							{error}
						</div>
					{/if}

					<button
						type="submit"
						class="btn btn-primary w-full justify-center"
						disabled={loading}
					>
						{loading ? 'Resetting...' : 'Reset Password'}
					</button>
				</form>
			{/if}
		</div>
	</div>
</div>
