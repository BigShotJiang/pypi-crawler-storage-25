<script lang="ts">
	import { DQI_DIMENSIONS } from '$lib/dqi-constants';
	import { dqiColor } from '$lib/format';

	interface Props {
		scores: Record<string, number>;
	}

	let { scores }: Props = $props();
</script>

<div class="space-y-3">
	{#each DQI_DIMENSIONS as dim}
		{@const value = scores[dim.key] ?? 0}
		<div>
			<div class="flex items-center justify-between mb-1">
				<span class="text-xs font-medium" style="color: var(--text-secondary)">
					{dim.label}
					<span class="text-[10px]" style="color: var(--text-faint)">({(dim.weight * 100).toFixed(0)}%)</span>
				</span>
				<span class="text-xs font-mono font-semibold" style="color: {dqiColor(value)}">
					{(value * 100).toFixed(0)}
				</span>
			</div>
			<div class="h-1.5 rounded-full" style="background: var(--bg-inset)">
				<div
					class="h-full rounded-full transition-all duration-500"
					style="width: {value * 100}%; background: {dqiColor(value)}"
				></div>
			</div>
		</div>
	{/each}
</div>
