<script lang="ts">
	let mobileNavOpen = $state(false);
	let openFaq = $state(-1);
	let copied = $state(false);

	function copyInstall() {
		navigator.clipboard.writeText('uvx qualito setup');
		copied = true;
		setTimeout(() => (copied = false), 2000);
	}

	function toggleFaq(index: number) {
		openFaq = openFaq === index ? -1 : index;
	}

	function scrollTo(id: string) {
		mobileNavOpen = false;
		document.getElementById(id)?.scrollIntoView({ behavior: 'smooth' });
	}

	const features = [
		{
			title: 'DQI Scoring',
			subtitle: 'Every session, scored 0\u2013100',
			desc: 'Your AI sessions are no longer a black box. See which ones delivered and which went in circles.',
			icon: '<circle cx="12" cy="14" r="8" /><path d="M12 14l3-5" /><circle cx="12" cy="14" r="1" />'
		},
		{
			title: 'Experiments',
			subtitle: 'Stop debating. Test it.',
			desc: 'Does your 2,500-line CLAUDE.md actually help? Run both approaches for a week. Qualito tells you which one wins \u2014 with statistical significance, not vibes.',
			icon: '<path d="M9 3h6v4l3 8H6l3-8V3z" /><path d="M6 15v3a2 2 0 002 2h8a2 2 0 002-2v-3" /><path d="M12 3v4" />'
		},
		{
			title: 'Incident Detection',
			subtitle: 'Catch regressions before they cost you',
			desc: 'Qualito auto-detects when your session quality drops \u2014 cost spikes, error loops, declining scores. You get alerted, not surprised.',
			icon: '<path d="M12 9v4m0 4h.01" /><path d="M10.29 3.86L1.82 18a2 2 0 001.71 3h16.94a2 2 0 001.71-3L13.71 3.86a2 2 0 00-3.42 0z" />'
		},
		{
			title: 'Pattern Recognition',
			subtitle: 'See what you actually do',
			desc: 'Qualito classifies your sessions by task type and surfaces patterns. Find out that your code reviews score 0.84 but your refactors score 0.52.',
			icon: '<path d="M3 3v18h18" /><path d="M7 16l4-8 4 5 4-10" />'
		},
		{
			title: 'MCP Integration',
			subtitle: 'Ask Claude about your quality',
			desc: 'Add one line to your config. Ask \u201chow am I doing?\u201d Claude analyzes your sessions and tells you \u2014 right where you work.',
			icon: '<rect x="3" y="4" width="18" height="16" rx="2" /><path d="M7 9l3 3-3 3" /><path d="M13 15h4" />'
		},
		{
			title: 'Cross-Project Discovery',
			subtitle: 'All your projects, one command',
			desc: 'Qualito scans every Claude Code project on your machine. No per-project setup. Import everything in under 2 minutes.',
			icon: '<rect x="3" y="3" width="7" height="7" rx="1.5" /><rect x="14" y="3" width="7" height="7" rx="1.5" /><rect x="3" y="14" width="7" height="7" rx="1.5" /><rect x="14" y="14" width="7" height="7" rx="1.5" />'
		}
	];

	const faqs = [
		{
			q: 'What is a DQI score?',
			a: 'DQI (Delegation Quality Index) is a composite score from 0 to 100 that measures the quality of an AI coding session. It evaluates factors like task completion, code correctness, test coverage, cost efficiency, and whether the session introduced regressions. The score is not a report card \u2014 it\u2019s a mirror. Developers who track their DQI find patterns they can\u2019t see otherwise: which task types they handle well, where sessions go off-rails, and what changes actually improve their workflow. Higher is better \u2014 70+ is good, 40\u201369 is fair, below 40 needs attention.'
		},
		{
			q: 'Is my code sent anywhere?',
			a: 'No. Qualito is local-first. The CLI reads Claude Code session logs from your machine and computes scores locally. Your source code never leaves your machine. Only aggregate metrics (scores, costs, durations) are synced to the cloud dashboard \u2014 never code content.'
		},
		{
			q: 'Does it work with Cursor or Copilot?',
			a: 'Qualito currently supports Claude Code only. Claude Code stores structured session logs that Qualito can analyze. Support for other AI coding tools is on the roadmap.'
		},
		{
			q: 'Is it open source?',
			a: 'The CLI tool is MIT licensed and open source on GitHub. The cloud dashboard is hosted at qualito.ai. You can use the CLI standalone without the cloud dashboard.'
		},
		{
			q: 'How long does setup take?',
			a: 'Under 2 minutes. Run "uvx qualito setup", answer one prompt, and your sessions are imported and scored. No configuration files to edit, no Docker containers to run.'
		}
	];
</script>

<svelte:head>
	<title>Qualito \u2014 Every session has a score</title>
	<meta
		name="description"
		content="Know what your Claude Code sessions actually produce. Qualito scores every session, detects regressions, and tells you what to change."
	/>
</svelte:head>

<!-- ──────────── NAV ──────────── -->
<nav class="landing-nav">
	<div class="landing-container nav-inner">
		<a href="/" class="nav-logo">
			<span class="font-mono" style="font-size: 20px; font-weight: 600; color: var(--accent);"
				>Qualito</span
			>
		</a>

		<div class="nav-links">
			<button onclick={() => scrollTo('features')} class="nav-link">Features</button>
			<button onclick={() => scrollTo('experiments')} class="nav-link">Experiments</button>
			<button onclick={() => scrollTo('pricing')} class="nav-link">Pricing</button>
			<button onclick={() => scrollTo('faq')} class="nav-link">FAQ</button>
			<a href="https://github.com/mp-web3/qualito" target="_blank" rel="noopener" class="nav-link"
				>GitHub</a
			>
			<a href="/login" class="nav-cta">Sign In</a>
		</div>

		<button
			class="nav-mobile-toggle"
			onclick={() => (mobileNavOpen = !mobileNavOpen)}
			aria-label="Toggle menu"
		>
			<svg
				width="22"
				height="22"
				viewBox="0 0 24 24"
				fill="none"
				stroke="currentColor"
				stroke-width="2"
				stroke-linecap="round"
			>
				{#if mobileNavOpen}
					<path d="M18 6L6 18M6 6l12 12" />
				{:else}
					<path d="M4 6h16M4 12h16M4 18h16" />
				{/if}
			</svg>
		</button>
	</div>

	{#if mobileNavOpen}
		<div class="mobile-menu">
			<button
				onclick={() => scrollTo('features')}
				class="mobile-link">Features</button
			>
			<button
				onclick={() => scrollTo('experiments')}
				class="mobile-link">Experiments</button
			>
			<button
				onclick={() => scrollTo('pricing')}
				class="mobile-link">Pricing</button
			>
			<button
				onclick={() => scrollTo('faq')}
				class="mobile-link">FAQ</button
			>
			<a
				href="https://github.com/mp-web3/qualito"
				target="_blank"
				rel="noopener"
				class="mobile-link">GitHub</a
			>
			<a href="/login" class="mobile-link" style="color: var(--accent);">Sign In</a>
		</div>
	{/if}
</nav>

<!-- ──────────── HERO ──────────── -->
<section class="hero-section">
	<div class="landing-container hero-content">
		<h1 class="hero-headline">Every session has a score.</h1>
		<p class="hero-sub">
			Know what your Claude Code sessions actually produce. Qualito scores every session,
			detects regressions, and tells you what to change &mdash; so you get better at working
			with AI, not just spending on it.
		</p>

		<div class="hero-actions">
			<div class="install-pill">
				<code class="font-mono">uvx qualito setup</code>
				<button class="copy-btn" onclick={copyInstall}>
					{copied ? 'Copied' : 'Copy'}
				</button>
			</div>
			<a href="/login" class="btn-landing-primary">See Your Score &rarr;</a>
			<a
				href="https://github.com/mp-web3/qualito"
				target="_blank"
				rel="noopener"
				class="btn-landing-secondary"
			>
				View on GitHub
			</a>
		</div>

		<!-- Terminal mockup -->
		<div class="terminal">
			<div class="terminal-header">
				<div class="terminal-dots">
					<span class="dot" style="background: #ff5f57;"></span>
					<span class="dot" style="background: #ffbd2e;"></span>
					<span class="dot" style="background: #28c840;"></span>
				</div>
				<span class="terminal-title font-mono">Terminal</span>
			</div>
			<div class="terminal-body font-mono">
				<div class="term-line">
					<span class="term-prompt">$</span>
					<span class="term-cmd">qualito setup</span>
				</div>
				<div class="term-line term-blank"></div>
				<div class="term-line">
					<span class="term-dim">&nbsp;&nbsp;Scanning ~/.claude/projects/ ...</span>
				</div>
				<div class="term-line term-blank"></div>
				<div class="term-line">
					<span class="term-text"
						>&nbsp;&nbsp;Found <span class="term-num">8</span> projects (<span
							class="term-num">312</span
						> sessions, ~<span class="term-num">$186</span> total):</span
					>
				</div>
				<div class="term-line term-blank"></div>
				<div class="term-line">
					<span class="term-dim"
						>&nbsp;&nbsp;&nbsp;&nbsp;#&nbsp;&nbsp;Project&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Sessions&nbsp;&nbsp;Est.
						Cost</span
					>
				</div>
				<div class="term-line">
					<span class="term-text"
						>&nbsp;&nbsp;&nbsp;&nbsp;1&nbsp;&nbsp;my-app&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;89&nbsp;&nbsp;&nbsp;&nbsp;$52.30</span
					>
				</div>
				<div class="term-line">
					<span class="term-text"
						>&nbsp;&nbsp;&nbsp;&nbsp;2&nbsp;&nbsp;api-service&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;67&nbsp;&nbsp;&nbsp;&nbsp;$41.20</span
					>
				</div>
				<div class="term-line">
					<span class="term-text"
						>&nbsp;&nbsp;&nbsp;&nbsp;3&nbsp;&nbsp;frontend&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;54&nbsp;&nbsp;&nbsp;&nbsp;$38.10</span
					>
				</div>
				<div class="term-line">
					<span class="term-dim">&nbsp;&nbsp;&nbsp;&nbsp;...</span>
				</div>
				<div class="term-line term-blank"></div>
				<div class="term-line">
					<span class="term-text">&nbsp;&nbsp;Importing all projects...</span>
				</div>
				<div class="term-line">
					<span class="term-accent"
						>&nbsp;&nbsp;████████████████████████████</span
					>
					<span class="term-text"> 312/312</span>
				</div>
				<div class="term-line term-blank"></div>
				<div class="term-line">
					<span class="term-text">&nbsp;&nbsp;Results:</span>
				</div>
				<div class="term-line">
					<span class="term-dim"
						>&nbsp;&nbsp;┌─────────────┬──────┬────────┬─────────┐</span
					>
				</div>
				<div class="term-line">
					<span class="term-dim"
						>&nbsp;&nbsp;│</span
					><span class="term-text"> Workspace&nbsp;&nbsp; </span><span class="term-dim">│</span><span class="term-text"> Runs </span><span class="term-dim">│</span><span class="term-text"> Avg DQI</span><span class="term-dim">│</span><span class="term-text"> Cost&nbsp;&nbsp;&nbsp; </span><span class="term-dim">│</span>
				</div>
				<div class="term-line">
					<span class="term-dim"
						>&nbsp;&nbsp;├─────────────┼──────┼────────┼─────────┤</span
					>
				</div>
				<div class="term-line">
					<span class="term-dim">&nbsp;&nbsp;│</span><span class="term-text"> my-app&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span><span class="term-dim">│</span><span class="term-text">&nbsp;&nbsp; 89 </span><span class="term-dim">│</span><span class="term-green">&nbsp; 0.78&nbsp; </span><span class="term-dim">│</span><span class="term-text"> $52.30&nbsp; </span><span class="term-dim">│</span>
				</div>
				<div class="term-line">
					<span class="term-dim">&nbsp;&nbsp;│</span><span class="term-text"> api-service&nbsp; </span><span class="term-dim">│</span><span class="term-text">&nbsp;&nbsp; 67 </span><span class="term-dim">│</span><span class="term-yellow">&nbsp; 0.65&nbsp; </span><span class="term-dim">│</span><span class="term-text"> $41.20&nbsp; </span><span class="term-dim">│</span>
				</div>
				<div class="term-line">
					<span class="term-dim">&nbsp;&nbsp;│</span><span class="term-text"> frontend&nbsp;&nbsp;&nbsp;&nbsp; </span><span class="term-dim">│</span><span class="term-text">&nbsp;&nbsp; 54 </span><span class="term-dim">│</span><span class="term-green">&nbsp; 0.82&nbsp; </span><span class="term-dim">│</span><span class="term-text"> $38.10&nbsp; </span><span class="term-dim">│</span>
				</div>
				<div class="term-line">
					<span class="term-dim"
						>&nbsp;&nbsp;└─────────────┴──────┴────────┴─────────┘</span
					>
				</div>
				<div class="term-line term-blank"></div>
				<div class="term-line">
					<span class="term-text">&nbsp;&nbsp;Average DQI: </span><span class="term-green"
						>0.74</span
					><span class="term-text"> (</span><span class="term-green">Good</span><span
						class="term-text">)</span
					>
				</div>
				<div class="term-line">
					<span class="term-accent">&nbsp;&nbsp;Setup complete.</span>
				</div>
			</div>
		</div>
	</div>
</section>

<!-- ──────────── TRUST BAR ──────────── -->
<section class="trust-section">
	<div class="landing-container trust-inner">
		<div class="trust-item">
			<svg
				width="16"
				height="16"
				viewBox="0 0 24 24"
				fill="none"
				stroke="currentColor"
				stroke-width="2"
				stroke-linecap="round"
				stroke-linejoin="round"
			>
				<path d="M9 12l2 2 4-4" />
				<circle cx="12" cy="12" r="10" />
			</svg>
			<span>Works with Claude Code</span>
		</div>
		<span class="trust-dot"></span>
		<div class="trust-item">
			<span class="trust-badge font-mono">PyPI v0.1.1</span>
		</div>
		<span class="trust-dot"></span>
		<div class="trust-item">
			<span>MIT License</span>
		</div>
		<span class="trust-dot"></span>
		<div class="trust-item">
			<span>82 tests passing</span>
		</div>
	</div>
</section>

<!-- ──────────── PROBLEM ──────────── -->
<section class="section-padding">
	<div class="landing-container problem-content">
		<h2 class="section-headline">
			Cost tracking tells you what you spent.<br />
			<span style="color: var(--text-muted);">Not whether it was worth it.</span>
		</h2>
		<p class="section-body">
			One developer tracked 147 decision points across 23 sessions. Found 25% of time lost
			to context re-establishment. Another lost $234 from a single missed magic number.
		</p>
		<p class="section-body" style="margin-top: 16px;">
			Cost tracking tells you what you spent. Qualito tells you why &mdash; and what to change.
		</p>
	</div>
</section>

<!-- ──────────── FEATURES ──────────── -->
<section class="section-padding" id="features">
	<div class="landing-container">
		<div class="section-label">Features</div>
		<h2 class="section-headline" style="margin-bottom: 48px;">
			Everything you need to measure delegation quality.
		</h2>

		<div class="features-grid">
			{#each features as feat}
				<div class="feature-card">
					<div class="feature-icon">
						<svg
							width="24"
							height="24"
							viewBox="0 0 24 24"
							fill="none"
							stroke="var(--accent)"
							stroke-width="1.5"
							stroke-linecap="round"
							stroke-linejoin="round"
						>
							{@html feat.icon}
						</svg>
					</div>
					<h3 class="feature-title">{feat.title}</h3>
					<p class="feature-subtitle">{feat.subtitle}</p>
					<p class="feature-desc">{feat.desc}</p>
				</div>
			{/each}
		</div>
	</div>
</section>

<!-- ──────────── EXPERIMENTS ──────────── -->
<section class="experiments-section" id="experiments">
	<div class="glow-line"></div>
	<div class="landing-container experiments-inner">
		<div class="section-label">Experiments</div>
		<h2 class="experiments-headline">Test what works. Drop what doesn't.</h2>
		<p class="experiments-sub">
			Run controlled experiments on your AI workflows. Qualito tracks the results with real statistics.
		</p>

		<!-- Side-by-side comparison -->
		<div class="experiment-comparison">
			<div class="experiment-card experiment-winner">
				<div class="experiment-card-header">
					<span class="experiment-label">Strategy A: Detailed context</span>
					<span class="experiment-badge-winner">
						<svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round">
							<path d="M20 6L9 17l-5-5" />
						</svg>
						WINNER
					</span>
				</div>
				<div class="experiment-score-row">
					<div class="experiment-bar-container">
						<div class="experiment-bar experiment-bar-good" style="width: 82%;"></div>
					</div>
					<span class="experiment-score-value font-mono" style="color: var(--accent);">0.82</span>
				</div>
				<div class="experiment-stats">
					<div class="experiment-stat">
						<span class="experiment-stat-label">Sessions</span>
						<span class="experiment-stat-value font-mono">24</span>
					</div>
					<div class="experiment-stat">
						<span class="experiment-stat-label">Avg cost</span>
						<span class="experiment-stat-value font-mono">$1.40</span>
					</div>
					<div class="experiment-stat">
						<span class="experiment-stat-label">Success</span>
						<span class="experiment-stat-value font-mono" style="color: var(--success);">91%</span>
					</div>
				</div>
			</div>

			<div class="experiment-vs font-mono">vs</div>

			<div class="experiment-card experiment-loser">
				<div class="experiment-card-header">
					<span class="experiment-label">Strategy B: Minimal prompts</span>
				</div>
				<div class="experiment-score-row">
					<div class="experiment-bar-container">
						<div class="experiment-bar experiment-bar-medium" style="width: 61%;"></div>
					</div>
					<span class="experiment-score-value font-mono" style="color: var(--warning);">0.61</span>
				</div>
				<div class="experiment-stats">
					<div class="experiment-stat">
						<span class="experiment-stat-label">Sessions</span>
						<span class="experiment-stat-value font-mono">24</span>
					</div>
					<div class="experiment-stat">
						<span class="experiment-stat-label">Avg cost</span>
						<span class="experiment-stat-value font-mono">$3.20</span>
					</div>
					<div class="experiment-stat">
						<span class="experiment-stat-label">Success</span>
						<span class="experiment-stat-value font-mono" style="color: var(--warning);">67%</span>
					</div>
				</div>
			</div>
		</div>

		<!-- Statistical result -->
		<div class="experiment-result">
			<p class="experiment-result-stat font-mono">
				Statistical significance: <span style="color: var(--accent);">p = 0.003</span> (Wilcoxon test)
			</p>
			<p class="experiment-result-savings">
				Switching to Strategy A saves <span style="color: var(--accent); font-weight: 600;">$43/month</span>
			</p>
		</div>

		<!-- Bullet points -->
		<div class="experiment-bullets">
			<div class="experiment-bullet">
				<svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="var(--accent)" stroke-width="2" stroke-linecap="round"><path d="M20 6L9 17l-5-5" /></svg>
				<span>Define experiments in one command</span>
			</div>
			<div class="experiment-bullet">
				<svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="var(--accent)" stroke-width="2" stroke-linecap="round"><path d="M20 6L9 17l-5-5" /></svg>
				<span>Qualito tracks sessions automatically</span>
			</div>
			<div class="experiment-bullet">
				<svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="var(--accent)" stroke-width="2" stroke-linecap="round"><path d="M20 6L9 17l-5-5" /></svg>
				<span>Get verdicts backed by real statistics, not gut feel</span>
			</div>
		</div>
	</div>
	<div class="glow-line"></div>
</section>

<!-- ──────────── DEMO / DASHBOARD PREVIEW ──────────── -->
<section class="section-padding" style="background: var(--bg-subtle);">
	<div class="landing-container">
		<div class="section-label">Dashboard</div>
		<h2 class="section-headline" style="margin-bottom: 48px;">
			See your quality at a glance.
		</h2>

		<div class="demo-dashboard">
			<div class="demo-header">
				<div class="terminal-dots" style="margin-right: 12px;">
					<span class="dot" style="background: #ff5f57;"></span>
					<span class="dot" style="background: #ffbd2e;"></span>
					<span class="dot" style="background: #28c840;"></span>
				</div>
				<span class="font-mono" style="font-size: 12px; color: var(--text-faint);"
					>qualito.ai/dashboard</span
				>
			</div>
			<div class="demo-body">
				<!-- Gauge -->
				<div class="demo-row">
					<div class="demo-gauge-card">
						<svg width="120" height="80" viewBox="0 0 120 80">
							<path
								d="M 15 70 A 50 50 0 0 1 105 70"
								fill="none"
								stroke="var(--border)"
								stroke-width="8"
								stroke-linecap="round"
							/>
							<path
								d="M 15 70 A 50 50 0 0 1 90 28"
								fill="none"
								stroke="var(--accent)"
								stroke-width="8"
								stroke-linecap="round"
							/>
							<text
								x="60"
								y="60"
								text-anchor="middle"
								fill="var(--text)"
								font-size="28"
								font-weight="600"
								font-family="JetBrains Mono, monospace">74</text
							>
							<text
								x="60"
								y="75"
								text-anchor="middle"
								fill="var(--text-muted)"
								font-size="10"
								font-family="Inter, sans-serif">Avg DQI</text
							>
						</svg>
					</div>
					<div class="demo-stats">
						<div class="demo-stat">
							<span class="demo-stat-label">Runs (30d)</span>
							<span class="demo-stat-value font-mono">312</span>
						</div>
						<div class="demo-stat">
							<span class="demo-stat-label">Total Cost</span>
							<span class="demo-stat-value font-mono">$186.40</span>
						</div>
						<div class="demo-stat">
							<span class="demo-stat-label">Incidents</span>
							<span class="demo-stat-value font-mono" style="color: var(--success);"
								>0</span
							>
						</div>
						<div class="demo-stat">
							<span class="demo-stat-label">SLO Status</span>
							<span class="demo-stat-value"
								><span style="color: var(--success);">Q</span>
								<span style="color: var(--success);">A</span>
								<span style="color: var(--success);">C</span></span
							>
						</div>
					</div>
				</div>
				<!-- Trend bars -->
				<div class="demo-trend">
					<span
						class="demo-trend-label font-mono"
						style="font-size: 11px; color: var(--text-faint);">DQI Trend (30d)</span
					>
					<div class="demo-bars">
						{#each [45, 52, 58, 61, 55, 63, 68, 72, 70, 74, 78, 76, 80, 74] as h}
							<div
								class="demo-bar"
								style="height: {h}%; background: var(--accent); opacity: {0.4 + h / 130};"
							></div>
						{/each}
					</div>
				</div>
			</div>
		</div>
	</div>
</section>

<!-- ──────────── THE JOURNEY ──────────── -->
<section class="section-padding journey-section" id="journey">
	<div class="landing-container">
		<div class="section-label">The Journey</div>
		<h2 class="section-headline" style="margin-bottom: 56px; text-align: center;">
			From scorecard to coach
		</h2>

		<div class="journey-steps">
			<div class="journey-step">
				<div class="journey-icon">
					<svg width="28" height="28" viewBox="0 0 24 24" fill="none" stroke="var(--accent)" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round">
						<path d="M1 12s4-8 11-8 11 8 11 8-4 8-11 8-11-8-11-8z" />
						<circle cx="12" cy="12" r="3" />
					</svg>
				</div>
				<div class="journey-step-number font-mono">01</div>
				<h3 class="journey-step-title">See</h3>
				<p class="journey-step-desc">Score every session. See where quality drops. Know your cost per run.</p>
				<span class="badge badge-success">Available now</span>
			</div>

			<div class="journey-connector">
				<div class="journey-line"></div>
			</div>

			<div class="journey-step">
				<div class="journey-icon">
					<svg width="28" height="28" viewBox="0 0 24 24" fill="none" stroke="var(--accent)" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round">
						<path d="M9 3h6v4l3 8H6l3-8V3z" />
						<path d="M6 15v3a2 2 0 002 2h8a2 2 0 002-2v-3" />
						<path d="M12 3v4" />
					</svg>
				</div>
				<div class="journey-step-number font-mono">02</div>
				<h3 class="journey-step-title">Improve</h3>
				<p class="journey-step-desc">Run experiments. Test your prompting strategies. Apply what works.</p>
				<span class="badge badge-success">Available now</span>
			</div>

			<div class="journey-connector">
				<div class="journey-line"></div>
			</div>

			<div class="journey-step journey-step-future">
				<div class="journey-icon">
					<svg width="28" height="28" viewBox="0 0 24 24" fill="none" stroke="var(--accent)" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round">
						<path d="M17 1l4 4-4 4" />
						<path d="M3 11V9a4 4 0 014-4h14" />
						<path d="M7 23l-4-4 4-4" />
						<path d="M21 13v2a4 4 0 01-4 4H3" />
					</svg>
				</div>
				<div class="journey-step-number font-mono">03</div>
				<h3 class="journey-step-title">Automate</h3>
				<p class="journey-step-desc">Qualito learns what works for you and suggests changes automatically. Productive friction, not a black box.</p>
				<span class="badge badge-neutral">Coming Q3 2026</span>
			</div>
		</div>
	</div>
</section>

<!-- ──────────── ONBOARDING PATHS ──────────── -->
<section class="section-padding">
	<div class="landing-container">
		<div class="section-label">Get Started</div>
		<h2 class="section-headline" style="margin-bottom: 48px;">Three ways to start measuring.</h2>

		<div class="paths-grid">
			<div class="path-card">
				<div class="path-number font-mono">1</div>
				<h3 class="path-title">Cloud Dashboard</h3>
				<p class="path-desc">
					Register, copy one command, done. Your sessions sync to qualito.ai where you can
					track trends across all projects.
				</p>
				<a href="/login" class="path-cta">Create Account &rarr;</a>
			</div>
			<div class="path-card">
				<div class="path-number font-mono">2</div>
				<h3 class="path-title">CLI Wizard</h3>
				<p class="path-desc">
					Full control over what to import. Run the setup wizard, pick your projects, and get
					scores in your terminal.
				</p>
				<div class="path-cmd font-mono">
					<code>uvx qualito setup</code>
				</div>
			</div>
			<div class="path-card">
				<div class="path-number font-mono">3</div>
				<h3 class="path-title">MCP-First</h3>
				<p class="path-desc">
					Ask Claude about your quality. Add the MCP server to your editor and get DQI
					insights inline as you code.
				</p>
				<div class="path-cmd font-mono">
					<code>uvx qualito-mcp</code>
				</div>
			</div>
		</div>
	</div>
</section>

<!-- ──────────── PRICING ──────────── -->
<section class="section-padding" id="pricing" style="background: var(--bg-subtle);">
	<div class="landing-container">
		<div class="section-label">Pricing</div>
		<h2 class="section-headline" style="margin-bottom: 48px;">
			Start free. Upgrade when you need more.
		</h2>

		<div class="pricing-grid">
			<div class="pricing-card">
				<div class="pricing-tier">Free</div>
				<div class="pricing-price">
					<span class="pricing-amount font-mono">$0</span>
					<span class="pricing-period">forever</span>
				</div>
				<ul class="pricing-features">
					<li>100 runs per month</li>
					<li>3 workspaces</li>
					<li>DQI scoring</li>
					<li>CLI + MCP tools</li>
					<li>7-day history</li>
					<li>Community support</li>
				</ul>
				<a href="/login" class="btn-landing-secondary" style="width: 100%; text-align: center;"
					>Install Free</a
				>
			</div>
			<div class="pricing-card pricing-card-pro">
				<div class="pricing-tier" style="color: var(--accent);">Pro</div>
				<div class="pricing-price">
					<span class="pricing-amount font-mono">$29</span>
					<span class="pricing-period">/ month</span>
				</div>
				<ul class="pricing-features">
					<li>Unlimited runs</li>
					<li>Unlimited workspaces</li>
					<li>Everything in Free</li>
					<li>Full cloud dashboard</li>
					<li>Unlimited history</li>
					<li>Team features</li>
					<li>Priority support</li>
				</ul>
				<a href="/login" class="btn-landing-primary" style="width: 100%; text-align: center;"
					>Start Pro</a
				>
			</div>
		</div>
	</div>
</section>

<!-- ──────────── FAQ ──────────── -->
<section class="section-padding" id="faq">
	<div class="landing-container" style="max-width: 720px;">
		<div class="section-label">FAQ</div>
		<h2 class="section-headline" style="margin-bottom: 48px;">Common questions.</h2>

		<div class="faq-list">
			{#each faqs as faq, i}
				<button class="faq-item" onclick={() => toggleFaq(i)}>
					<div class="faq-q">
						<span>{faq.q}</span>
						<svg
							width="18"
							height="18"
							viewBox="0 0 24 24"
							fill="none"
							stroke="currentColor"
							stroke-width="2"
							stroke-linecap="round"
							class="faq-chevron"
							style="transform: rotate({openFaq === i ? '180deg' : '0deg'});"
						>
							<path d="M6 9l6 6 6-6" />
						</svg>
					</div>
					{#if openFaq === i}
						<p class="faq-a">{faq.a}</p>
					{/if}
				</button>
			{/each}
		</div>
	</div>
</section>

<!-- ──────────── FINAL CTA ──────────── -->
<section class="cta-section">
	<div class="landing-container cta-content">
		<h2 class="cta-headline">Your next AI coding session has a score.</h2>
		<p class="cta-sub">See it.</p>
		<div class="hero-actions" style="margin-top: 32px;">
			<div class="install-pill">
				<code class="font-mono">uvx qualito setup</code>
				<button class="copy-btn" onclick={copyInstall}>
					{copied ? 'Copied' : 'Copy'}
				</button>
			</div>
			<a href="/login" class="btn-landing-primary">See Your Score &rarr;</a>
		</div>
		<p class="cta-note">Free for 100 runs/month. No credit card required.</p>
	</div>
</section>

<!-- ──────────── FOOTER ──────────── -->
<footer class="landing-footer">
	<div class="landing-container footer-inner">
		<div class="footer-left">
			<span class="font-mono" style="font-size: 14px; font-weight: 600; color: var(--accent);"
				>Qualito</span
			>
			<span style="color: var(--text-faint); font-size: 12px;">
				Quality metrics for AI-assisted development.
			</span>
		</div>
		<div class="footer-links">
			<a href="https://github.com/mp-web3/qualito" target="_blank" rel="noopener">GitHub</a>
			<a href="https://pypi.org/project/qualito/" target="_blank" rel="noopener">PyPI</a>
			<a href="/login">Sign In</a>
		</div>
	</div>
</footer>

<style>
	/* ── Layout ── */
	.landing-container {
		max-width: 1100px;
		margin: 0 auto;
		padding: 0 24px;
	}

	.section-padding {
		padding: 96px 0;
	}

	/* ── Nav ── */
	.landing-nav {
		position: fixed;
		top: 0;
		left: 0;
		right: 0;
		z-index: 100;
		background: rgba(10, 15, 18, 0.85);
		backdrop-filter: blur(16px) saturate(180%);
		-webkit-backdrop-filter: blur(16px) saturate(180%);
		border-bottom: 1px solid var(--border-subtle);
	}

	.nav-inner {
		display: flex;
		align-items: center;
		justify-content: space-between;
		height: 60px;
	}

	.nav-logo {
		text-decoration: none;
	}

	.nav-links {
		display: flex;
		align-items: center;
		gap: 8px;
	}

	.nav-link {
		background: none;
		border: none;
		color: var(--text-muted);
		font-size: 13px;
		font-weight: 500;
		padding: 6px 12px;
		border-radius: 6px;
		cursor: pointer;
		transition: color 0.15s;
		text-decoration: none;
	}

	.nav-link:hover {
		color: var(--text);
	}

	.nav-cta {
		color: var(--accent);
		font-size: 13px;
		font-weight: 500;
		padding: 6px 14px;
		border-radius: 8px;
		border: 1px solid var(--accent-muted);
		text-decoration: none;
		transition: all 0.15s;
		margin-left: 8px;
	}

	.nav-cta:hover {
		background: var(--accent-subtle);
	}

	.nav-mobile-toggle {
		display: none;
		background: none;
		border: none;
		color: var(--text-secondary);
		cursor: pointer;
		padding: 4px;
	}

	.mobile-menu {
		display: none;
		flex-direction: column;
		padding: 8px 24px 16px;
		border-top: 1px solid var(--border-subtle);
	}

	.mobile-link {
		background: none;
		border: none;
		color: var(--text-secondary);
		font-size: 14px;
		padding: 10px 0;
		text-align: left;
		cursor: pointer;
		text-decoration: none;
		border-bottom: 1px solid var(--border-subtle);
	}

	@media (max-width: 768px) {
		.nav-links {
			display: none;
		}
		.nav-mobile-toggle {
			display: block;
		}
		.mobile-menu {
			display: flex;
		}
	}

	/* ── Hero ── */
	.hero-section {
		padding-top: 140px;
		padding-bottom: 80px;
		text-align: center;
	}

	.hero-content {
		max-width: 800px;
	}

	.hero-headline {
		font-size: clamp(36px, 5vw, 56px);
		font-weight: 700;
		line-height: 1.1;
		color: var(--text);
		letter-spacing: -0.02em;
		margin-bottom: 20px;
	}

	.hero-sub {
		font-size: clamp(16px, 2vw, 19px);
		line-height: 1.6;
		color: var(--text-secondary);
		max-width: 620px;
		margin: 0 auto 36px;
	}

	.hero-actions {
		display: flex;
		align-items: center;
		justify-content: center;
		gap: 12px;
		flex-wrap: wrap;
	}

	/* ── Install Pill ── */
	.install-pill {
		display: inline-flex;
		align-items: center;
		gap: 12px;
		background: var(--bg-inset);
		border: 1px solid var(--border);
		border-radius: 10px;
		padding: 10px 14px 10px 18px;
		font-size: 14px;
		color: var(--accent-hover);
	}

	.copy-btn {
		background: var(--bg-card);
		border: 1px solid var(--border);
		color: var(--text-secondary);
		font-size: 12px;
		font-weight: 500;
		padding: 4px 10px;
		border-radius: 6px;
		cursor: pointer;
		transition: all 0.12s;
	}

	.copy-btn:hover {
		background: var(--bg-hover);
		color: var(--text);
		border-color: var(--border-active);
	}

	/* ── Buttons ── */
	.btn-landing-primary {
		display: inline-flex;
		align-items: center;
		gap: 6px;
		padding: 10px 20px;
		background: var(--accent);
		color: white;
		font-size: 14px;
		font-weight: 500;
		border-radius: 10px;
		text-decoration: none;
		border: none;
		cursor: pointer;
		transition: all 0.15s;
	}

	.btn-landing-primary:hover {
		background: var(--accent-hover);
		box-shadow: 0 0 24px var(--accent-glow);
	}

	.btn-landing-secondary {
		display: inline-flex;
		align-items: center;
		gap: 6px;
		padding: 10px 20px;
		background: transparent;
		color: var(--text-secondary);
		font-size: 14px;
		font-weight: 500;
		border-radius: 10px;
		border: 1px solid var(--border);
		text-decoration: none;
		cursor: pointer;
		transition: all 0.15s;
	}

	.btn-landing-secondary:hover {
		background: var(--bg-hover);
		color: var(--text);
		border-color: var(--border-active);
	}

	/* ── Terminal ── */
	.terminal {
		margin-top: 48px;
		border-radius: 12px;
		overflow: hidden;
		border: 1px solid var(--border);
		background: #0d1117;
		text-align: left;
		max-width: 620px;
		margin-left: auto;
		margin-right: auto;
		box-shadow: 0 24px 64px rgba(0, 0, 0, 0.4);
	}

	.terminal-header {
		display: flex;
		align-items: center;
		padding: 12px 16px;
		background: #161b22;
		border-bottom: 1px solid rgba(255, 255, 255, 0.06);
	}

	.terminal-dots {
		display: flex;
		gap: 6px;
	}

	.dot {
		width: 10px;
		height: 10px;
		border-radius: 50%;
	}

	.terminal-title {
		margin-left: 12px;
		font-size: 11px;
		color: var(--text-faint);
	}

	.terminal-body {
		padding: 16px 20px 20px;
		font-size: 12.5px;
		line-height: 1.65;
		overflow-x: auto;
	}

	.term-line {
		white-space: pre;
		min-height: 1em;
	}

	.term-blank {
		height: 8px;
	}

	.term-prompt {
		color: var(--accent);
	}

	.term-cmd {
		color: var(--text);
		font-weight: 600;
	}

	.term-text {
		color: var(--text-secondary);
	}

	.term-dim {
		color: var(--text-faint);
	}

	.term-num {
		color: var(--text);
		font-weight: 600;
	}

	.term-accent {
		color: var(--accent);
	}

	.term-green {
		color: var(--success);
		font-weight: 600;
	}

	.term-yellow {
		color: var(--warning);
		font-weight: 600;
	}

	/* ── Trust ── */
	.trust-section {
		padding: 28px 0;
		border-top: 1px solid var(--border-subtle);
		border-bottom: 1px solid var(--border-subtle);
	}

	.trust-inner {
		display: flex;
		align-items: center;
		justify-content: center;
		gap: 20px;
		flex-wrap: wrap;
	}

	.trust-item {
		display: flex;
		align-items: center;
		gap: 6px;
		font-size: 13px;
		color: var(--text-muted);
	}

	.trust-dot {
		width: 3px;
		height: 3px;
		border-radius: 50%;
		background: var(--text-faint);
	}

	.trust-badge {
		font-size: 11px;
		padding: 2px 8px;
		border-radius: 999px;
		background: var(--accent-subtle);
		color: var(--accent);
	}

	@media (max-width: 640px) {
		.trust-dot {
			display: none;
		}
		.trust-inner {
			gap: 12px;
		}
	}

	/* ── Section headlines ── */
	.section-label {
		font-size: 11px;
		font-weight: 600;
		letter-spacing: 0.1em;
		text-transform: uppercase;
		color: var(--accent);
		margin-bottom: 12px;
	}

	.section-headline {
		font-size: clamp(24px, 3.5vw, 36px);
		font-weight: 600;
		line-height: 1.25;
		color: var(--text);
		letter-spacing: -0.01em;
	}

	.section-body {
		font-size: 17px;
		line-height: 1.7;
		color: var(--text-secondary);
		max-width: 600px;
		margin: 20px auto 0;
	}

	.problem-content {
		text-align: center;
		max-width: 700px;
	}

	/* ── Features grid ── */
	.features-grid {
		display: grid;
		grid-template-columns: repeat(3, 1fr);
		gap: 16px;
	}

	.feature-card {
		background: var(--bg-card);
		border: 1px solid var(--border);
		border-radius: 14px;
		padding: 28px 24px;
		transition:
			border-color 0.2s,
			transform 0.12s;
		position: relative;
		overflow: hidden;
	}

	.feature-card::before {
		content: '';
		position: absolute;
		inset: 0;
		background: linear-gradient(135deg, var(--accent-subtle) 0%, transparent 50%);
		opacity: 0;
		transition: opacity 0.2s;
	}

	.feature-card:hover {
		border-color: var(--border-active);
		transform: translateY(-2px);
	}

	.feature-card:hover::before {
		opacity: 1;
	}

	.feature-icon {
		position: relative;
		z-index: 1;
		width: 40px;
		height: 40px;
		border-radius: 10px;
		background: var(--accent-subtle);
		display: flex;
		align-items: center;
		justify-content: center;
		margin-bottom: 16px;
	}

	.feature-title {
		position: relative;
		z-index: 1;
		font-size: 15px;
		font-weight: 600;
		color: var(--text);
		margin-bottom: 4px;
	}

	.feature-subtitle {
		position: relative;
		z-index: 1;
		font-size: 12px;
		font-weight: 500;
		color: var(--accent);
		margin-bottom: 10px;
	}

	.feature-desc {
		position: relative;
		z-index: 1;
		font-size: 13px;
		line-height: 1.6;
		color: var(--text-muted);
	}

	@media (max-width: 900px) {
		.features-grid {
			grid-template-columns: repeat(2, 1fr);
		}
	}

	@media (max-width: 600px) {
		.features-grid {
			grid-template-columns: 1fr;
		}
	}

	/* ── Experiments Section ── */
	.experiments-section {
		padding: 96px 0;
		position: relative;
		overflow: hidden;
		background: linear-gradient(
			180deg,
			var(--bg) 0%,
			rgba(20, 184, 166, 0.03) 30%,
			rgba(20, 184, 166, 0.05) 50%,
			rgba(20, 184, 166, 0.03) 70%,
			var(--bg) 100%
		);
	}

	.experiments-inner {
		text-align: center;
	}

	.experiments-headline {
		font-size: clamp(28px, 4vw, 44px);
		font-weight: 700;
		line-height: 1.15;
		color: var(--text);
		letter-spacing: -0.02em;
		margin-bottom: 16px;
	}

	.experiments-sub {
		font-size: clamp(15px, 1.8vw, 18px);
		line-height: 1.6;
		color: var(--text-secondary);
		max-width: 520px;
		margin: 0 auto 56px;
	}

	.experiment-comparison {
		display: flex;
		align-items: stretch;
		justify-content: center;
		gap: 20px;
		max-width: 780px;
		margin: 0 auto;
	}

	.experiment-vs {
		display: flex;
		align-items: center;
		justify-content: center;
		font-size: 14px;
		color: var(--text-faint);
		flex-shrink: 0;
	}

	.experiment-card {
		flex: 1;
		max-width: 340px;
		background: var(--bg-card);
		border: 1px solid var(--border);
		border-radius: 14px;
		padding: 24px;
		text-align: left;
		transition: border-color 0.2s;
	}

	.experiment-winner {
		border-color: rgba(20, 184, 166, 0.3);
		box-shadow: 0 0 40px rgba(20, 184, 166, 0.08), 0 0 80px rgba(20, 184, 166, 0.04);
	}

	.experiment-loser {
		opacity: 0.85;
	}

	.experiment-card-header {
		display: flex;
		align-items: center;
		justify-content: space-between;
		margin-bottom: 20px;
		gap: 8px;
	}

	.experiment-label {
		font-size: 13px;
		font-weight: 500;
		color: var(--text-secondary);
	}

	.experiment-badge-winner {
		display: inline-flex;
		align-items: center;
		gap: 4px;
		padding: 3px 10px;
		border-radius: 999px;
		font-size: 10px;
		font-weight: 600;
		letter-spacing: 0.05em;
		background: var(--success-muted);
		color: var(--success);
	}

	.experiment-score-row {
		display: flex;
		align-items: center;
		gap: 12px;
		margin-bottom: 20px;
	}

	.experiment-bar-container {
		flex: 1;
		height: 8px;
		border-radius: 4px;
		background: var(--bg-inset);
		overflow: hidden;
	}

	.experiment-bar {
		height: 100%;
		border-radius: 4px;
		transition: width 0.6s ease;
	}

	.experiment-bar-good {
		background: var(--accent);
	}

	.experiment-bar-medium {
		background: var(--warning);
	}

	.experiment-score-value {
		font-size: 24px;
		font-weight: 700;
		flex-shrink: 0;
	}

	.experiment-stats {
		display: flex;
		gap: 12px;
	}

	.experiment-stat {
		flex: 1;
		background: var(--bg-inset);
		border: 1px solid var(--border-subtle);
		border-radius: 8px;
		padding: 10px;
		text-align: center;
	}

	.experiment-stat-label {
		display: block;
		font-size: 10px;
		color: var(--text-faint);
		margin-bottom: 4px;
	}

	.experiment-stat-value {
		font-size: 14px;
		font-weight: 600;
		color: var(--text);
	}

	/* Experiment results */
	.experiment-result {
		text-align: center;
		margin: 36px auto 0;
		max-width: 500px;
	}

	.experiment-result-stat {
		font-size: 13px;
		color: var(--text-muted);
		margin-bottom: 8px;
	}

	.experiment-result-savings {
		font-size: 16px;
		color: var(--text-secondary);
	}

	/* Experiment bullets */
	.experiment-bullets {
		display: flex;
		justify-content: center;
		gap: 32px;
		margin-top: 40px;
		flex-wrap: wrap;
	}

	.experiment-bullet {
		display: flex;
		align-items: center;
		gap: 8px;
		font-size: 14px;
		color: var(--text-secondary);
	}

	@media (max-width: 700px) {
		.experiment-comparison {
			flex-direction: column;
			align-items: center;
		}
		.experiment-card {
			max-width: 100%;
		}
		.experiment-vs {
			padding: 4px 0;
		}
		.experiment-bullets {
			flex-direction: column;
			align-items: center;
			gap: 16px;
		}
	}

	/* ── Journey / Stepper ── */
	.journey-section {
		text-align: center;
	}

	.journey-steps {
		display: flex;
		align-items: flex-start;
		justify-content: center;
		gap: 0;
		max-width: 900px;
		margin: 0 auto;
	}

	.journey-step {
		flex: 1;
		max-width: 280px;
		display: flex;
		flex-direction: column;
		align-items: center;
		text-align: center;
		padding: 0 16px;
	}

	.journey-step-future {
		opacity: 0.55;
	}

	.journey-icon {
		width: 56px;
		height: 56px;
		border-radius: 16px;
		background: var(--accent-subtle);
		border: 1px solid rgba(20, 184, 166, 0.15);
		display: flex;
		align-items: center;
		justify-content: center;
		margin-bottom: 16px;
	}

	.journey-step-number {
		font-size: 11px;
		color: var(--text-faint);
		margin-bottom: 8px;
	}

	.journey-step-title {
		font-size: 20px;
		font-weight: 600;
		color: var(--text);
		margin-bottom: 10px;
	}

	.journey-step-desc {
		font-size: 13px;
		line-height: 1.6;
		color: var(--text-muted);
		margin-bottom: 16px;
	}

	.journey-connector {
		display: flex;
		align-items: center;
		padding-top: 28px;
		flex-shrink: 0;
		width: 48px;
	}

	.journey-line {
		width: 100%;
		height: 1px;
		background: linear-gradient(90deg, var(--accent), rgba(20, 184, 166, 0.2));
	}

	@media (max-width: 700px) {
		.journey-steps {
			flex-direction: column;
			align-items: center;
			gap: 8px;
		}
		.journey-connector {
			width: 1px;
			height: 32px;
			padding-top: 0;
		}
		.journey-line {
			width: 1px;
			height: 100%;
			background: linear-gradient(180deg, var(--accent), rgba(20, 184, 166, 0.2));
		}
	}

	/* ── Demo dashboard ── */
	.demo-dashboard {
		max-width: 680px;
		margin: 0 auto;
		border-radius: 12px;
		overflow: hidden;
		border: 1px solid var(--border);
		background: var(--bg-card);
		box-shadow: 0 24px 64px rgba(0, 0, 0, 0.3);
	}

	.demo-header {
		display: flex;
		align-items: center;
		padding: 12px 16px;
		background: var(--bg-inset);
		border-bottom: 1px solid var(--border-subtle);
	}

	.demo-body {
		padding: 24px;
	}

	.demo-row {
		display: flex;
		gap: 20px;
		align-items: flex-start;
		margin-bottom: 24px;
	}

	.demo-gauge-card {
		background: var(--bg-inset);
		border: 1px solid var(--border-subtle);
		border-radius: 10px;
		padding: 16px 20px;
		flex-shrink: 0;
	}

	.demo-stats {
		flex: 1;
		display: grid;
		grid-template-columns: 1fr 1fr;
		gap: 12px;
	}

	.demo-stat {
		background: var(--bg-inset);
		border: 1px solid var(--border-subtle);
		border-radius: 8px;
		padding: 12px 14px;
	}

	.demo-stat-label {
		display: block;
		font-size: 10px;
		color: var(--text-faint);
		margin-bottom: 4px;
	}

	.demo-stat-value {
		font-size: 18px;
		font-weight: 600;
		color: var(--text);
	}

	.demo-trend {
		background: var(--bg-inset);
		border: 1px solid var(--border-subtle);
		border-radius: 10px;
		padding: 14px 16px;
	}

	.demo-trend-label {
		display: block;
		margin-bottom: 10px;
	}

	.demo-bars {
		display: flex;
		align-items: flex-end;
		gap: 4px;
		height: 60px;
	}

	.demo-bar {
		flex: 1;
		border-radius: 3px 3px 0 0;
		min-width: 0;
	}

	@media (max-width: 600px) {
		.demo-row {
			flex-direction: column;
		}
		.demo-gauge-card {
			align-self: center;
		}
	}

	/* ── Paths grid ── */
	.paths-grid {
		display: grid;
		grid-template-columns: repeat(3, 1fr);
		gap: 16px;
	}

	.path-card {
		background: var(--bg-card);
		border: 1px solid var(--border);
		border-radius: 14px;
		padding: 28px 24px;
		display: flex;
		flex-direction: column;
	}

	.path-number {
		width: 32px;
		height: 32px;
		border-radius: 8px;
		background: var(--accent-subtle);
		color: var(--accent);
		display: flex;
		align-items: center;
		justify-content: center;
		font-size: 14px;
		font-weight: 600;
		margin-bottom: 16px;
		border: 1px solid var(--border);
	}

	.path-title {
		font-size: 15px;
		font-weight: 600;
		color: var(--text);
		margin-bottom: 8px;
	}

	.path-desc {
		font-size: 13px;
		line-height: 1.6;
		color: var(--text-muted);
		flex: 1;
		margin-bottom: 16px;
	}

	.path-cta {
		font-size: 13px;
		font-weight: 500;
		color: var(--accent);
		text-decoration: none;
	}

	.path-cta:hover {
		color: var(--accent-hover);
	}

	.path-cmd {
		font-size: 12px;
		padding: 6px 10px;
		border-radius: 6px;
		background: var(--bg-inset);
		border: 1px solid var(--border-subtle);
		color: var(--accent-hover);
	}

	@media (max-width: 768px) {
		.paths-grid {
			grid-template-columns: 1fr;
		}
	}

	/* ── Pricing ── */
	.pricing-grid {
		display: grid;
		grid-template-columns: repeat(2, 1fr);
		gap: 20px;
		max-width: 680px;
		margin: 0 auto;
	}

	.pricing-card {
		background: var(--bg-card);
		border: 1px solid var(--border);
		border-radius: 14px;
		padding: 32px 28px;
		display: flex;
		flex-direction: column;
	}

	.pricing-card-pro {
		border-color: var(--accent-muted);
		position: relative;
	}

	.pricing-card-pro::before {
		content: '';
		position: absolute;
		inset: 0;
		border-radius: 14px;
		background: linear-gradient(135deg, var(--accent-subtle) 0%, transparent 40%);
		pointer-events: none;
	}

	.pricing-tier {
		font-size: 14px;
		font-weight: 600;
		color: var(--text-secondary);
		margin-bottom: 12px;
		position: relative;
		z-index: 1;
	}

	.pricing-price {
		margin-bottom: 24px;
		position: relative;
		z-index: 1;
	}

	.pricing-amount {
		font-size: 40px;
		font-weight: 700;
		color: var(--text);
	}

	.pricing-period {
		font-size: 14px;
		color: var(--text-muted);
		margin-left: 4px;
	}

	.pricing-features {
		list-style: none;
		padding: 0;
		margin: 0 0 28px;
		flex: 1;
		position: relative;
		z-index: 1;
	}

	.pricing-features li {
		font-size: 13px;
		color: var(--text-secondary);
		padding: 6px 0;
		border-bottom: 1px solid var(--border-subtle);
	}

	.pricing-features li:last-child {
		border-bottom: none;
	}

	@media (max-width: 600px) {
		.pricing-grid {
			grid-template-columns: 1fr;
		}
	}

	/* ── FAQ ── */
	.faq-list {
		display: flex;
		flex-direction: column;
		gap: 2px;
	}

	.faq-item {
		width: 100%;
		background: var(--bg-card);
		border: 1px solid var(--border);
		border-radius: 10px;
		padding: 0;
		cursor: pointer;
		text-align: left;
		transition: border-color 0.15s;
	}

	.faq-item:hover {
		border-color: var(--border-active);
	}

	.faq-q {
		display: flex;
		align-items: center;
		justify-content: space-between;
		padding: 16px 20px;
		font-size: 14px;
		font-weight: 500;
		color: var(--text);
	}

	.faq-chevron {
		flex-shrink: 0;
		color: var(--text-faint);
		transition: transform 0.2s;
	}

	.faq-a {
		padding: 0 20px 16px;
		font-size: 13px;
		line-height: 1.7;
		color: var(--text-muted);
	}

	/* ── Final CTA ── */
	.cta-section {
		padding: 96px 0;
		text-align: center;
		position: relative;
		overflow: hidden;
	}

	.cta-section::before {
		content: '';
		position: absolute;
		inset: 0;
		background: linear-gradient(
			180deg,
			transparent 0%,
			rgba(20, 184, 166, 0.04) 50%,
			transparent 100%
		);
		pointer-events: none;
	}

	.cta-content {
		position: relative;
		z-index: 1;
	}

	.cta-headline {
		font-size: clamp(24px, 3.5vw, 36px);
		font-weight: 600;
		color: var(--text);
		letter-spacing: -0.01em;
	}

	.cta-sub {
		font-size: 20px;
		color: var(--accent);
		font-weight: 500;
		margin-top: 8px;
	}

	.cta-note {
		font-size: 13px;
		color: var(--text-faint);
		margin-top: 20px;
	}

	/* ── Footer ── */
	.landing-footer {
		padding: 32px 0;
		border-top: 1px solid var(--border-subtle);
	}

	.footer-inner {
		display: flex;
		align-items: center;
		justify-content: space-between;
		flex-wrap: wrap;
		gap: 16px;
	}

	.footer-left {
		display: flex;
		align-items: center;
		gap: 12px;
	}

	.footer-links {
		display: flex;
		gap: 20px;
	}

	.footer-links a {
		font-size: 13px;
		color: var(--text-muted);
		text-decoration: none;
		transition: color 0.15s;
	}

	.footer-links a:hover {
		color: var(--text);
	}

	/* ── Scroll ── */
	:global(html) {
		scroll-behavior: smooth;
	}

	/* ── Anchor offset for fixed nav ── */
	:global(section[id]) {
		scroll-margin-top: 72px;
	}
</style>
