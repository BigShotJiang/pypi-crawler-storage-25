<script lang="ts">
	import Badge from './Badge.svelte';

	interface Props {
		status: string;
	}

	let { status }: Props = $props();

	const variantMap: Record<string, 'success' | 'warning' | 'error' | 'accent' | 'info' | 'neutral'> = {
		completed: 'success',
		running: 'accent',
		failed: 'error',
		timeout: 'warning',
		draft: 'neutral',
		cancelled: 'neutral',
		open: 'error',
		acknowledged: 'warning',
		resolved: 'success',
		met: 'success',
		at_risk: 'warning',
		breached: 'error'
	};

	let variant = $derived(variantMap[status] ?? 'neutral');
</script>

<Badge {variant} text={status} />
