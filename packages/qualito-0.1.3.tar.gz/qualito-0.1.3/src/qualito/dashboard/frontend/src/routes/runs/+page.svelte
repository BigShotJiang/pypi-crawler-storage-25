<script lang="ts">
	import { onMount } from 'svelte';
	import Card from '$lib/components/Card.svelte';
	import StatusBadge from '$lib/components/StatusBadge.svelte';
	import { listRuns } from '$lib/api';
	import { formatDate, formatCost, dqiColor } from '$lib/format';
	import type { Run } from '$lib/types';

	let runs = $state<Run[]>([]);
	let total = $state(0);
	let error = $state<string | null>(null);
	let loading = $state(true);

	// Filters
	let filterWorkspace = $state('');
	let filterTaskType = $state('');
	let filterStatus = $state('');

	// Pagination
	let pageSize = 25;
	let currentPage = $state(0);

	// Sorting
	let sortColumn = $state<string>('started_at');
	let sortAsc = $state(false);

	// Unique filter values from runs
	let workspaces = $state<string[]>([]);
	let taskTypes = $state<string[]>([]);
	let statuses = $state<string[]>([]);

	async function fetchRuns() {
		loading = true;
		error = null;
		try {
			const params: Record<string, string | number> = {
				limit: pageSize,
				offset: currentPage * pageSize
			};
			if (filterWorkspace) params.workspace = filterWorkspace;
			if (filterTaskType) params.task_type = filterTaskType;
			if (filterStatus) params.status = filterStatus;

			const res = await listRuns(params as any);
			runs = res.runs;
			total = res.total;
		} catch (e) {
			error = e instanceof Error ? e.message : 'Failed to load runs';
		} finally {
			loading = false;
		}
	}

	async function fetchFilterValues() {
		try {
			const res = await listRuns({ limit: 200 });
			const ws = new Set<string>();
			const tt = new Set<string>();
			const st = new Set<string>();
			for (const r of res.runs) {
				if (r.workspace) ws.add(r.workspace);
				if (r.task_type) tt.add(r.task_type);
				if (r.status) st.add(r.status);
			}
			workspaces = [...ws].sort();
			taskTypes = [...tt].sort();
			statuses = [...st].sort();
		} catch {
			// Ignore — filter values are non-critical
		}
	}

	onMount(() => {
		fetchRuns();
		fetchFilterValues();
	});

	function onFilterChange() {
		currentPage = 0;
		fetchRuns();
	}

	function toggleSort(col: string) {
		if (sortColumn === col) {
			sortAsc = !sortAsc;
		} else {
			sortColumn = col;
			sortAsc = false;
		}
	}

	let sortedRuns = $derived(() => {
		const sorted = [...runs];
		sorted.sort((a, b) => {
			let va: any = (a as any)[sortColumn];
			let vb: any = (b as any)[sortColumn];
			if (va == null) return 1;
			if (vb == null) return -1;
			if (typeof va === 'string') va = va.toLowerCase();
			if (typeof vb === 'string') vb = vb.toLowerCase();
			if (va < vb) return sortAsc ? -1 : 1;
			if (va > vb) return sortAsc ? 1 : -1;
			return 0;
		});
		return sorted;
	});

	let totalPages = $derived(Math.ceil(total / pageSize));

	function prevPage() {
		if (currentPage > 0) {
			currentPage--;
			fetchRuns();
		}
	}

	function nextPage() {
		if (currentPage < totalPages - 1) {
			currentPage++;
			fetchRuns();
		}
	}

	function formatDurationMs(ms: number | null): string {
		if (ms == null) return '—';
		const secs = ms / 1000;
		if (secs < 60) return `${Math.round(secs)}s`;
		const m = Math.floor(secs / 60);
		const s = Math.round(secs % 60);
		return `${m}m ${s}s`;
	}

	function sortArrow(col: string): string {
		if (sortColumn !== col) return '';
		return sortAsc ? ' ↑' : ' ↓';
	}
</script>

<div class="space-y-6">
	<h1 class="text-xl font-semibold" style="color: var(--text)">Runs</h1>

	<!-- Filter bar -->
	<div class="flex flex-wrap gap-3 items-center">
		<select
			class="select-field text-sm"
			bind:value={filterWorkspace}
			onchange={onFilterChange}
		>
			<option value="">All workspaces</option>
			{#each workspaces as ws}
				<option value={ws}>{ws}</option>
			{/each}
		</select>

		<select
			class="select-field text-sm"
			bind:value={filterTaskType}
			onchange={onFilterChange}
		>
			<option value="">All task types</option>
			{#each taskTypes as tt}
				<option value={tt}>{tt}</option>
			{/each}
		</select>

		<select
			class="select-field text-sm"
			bind:value={filterStatus}
			onchange={onFilterChange}
		>
			<option value="">All statuses</option>
			{#each statuses as s}
				<option value={s}>{s}</option>
			{/each}
		</select>

		<span class="text-xs ml-auto" style="color: var(--text-muted)">
			{total} run{total !== 1 ? 's' : ''}
		</span>
	</div>

	{#if error}
		<div class="card p-4" style="border-color: var(--error)">
			<p style="color: var(--error)">{error}</p>
		</div>
	{:else if loading}
		<div class="space-y-2">
			{#each Array(5) as _}
				<div class="skeleton h-12 rounded-lg"></div>
			{/each}
		</div>
	{:else if sortedRuns().length === 0}
		<Card padding="p-8">
			<p class="text-center text-sm" style="color: var(--text-muted)">No runs found</p>
		</Card>
	{:else}
		<div class="table-container">
			<table>
				<thead>
					<tr>
						<th class="cursor-pointer" onclick={() => toggleSort('id')}>
							Run ID{sortArrow('id')}
						</th>
						<th class="cursor-pointer" onclick={() => toggleSort('workspace')}>
							Workspace{sortArrow('workspace')}
						</th>
						<th class="cursor-pointer" onclick={() => toggleSort('task')}>
							Task{sortArrow('task')}
						</th>
						<th class="cursor-pointer" onclick={() => toggleSort('dqi')}>
							DQI{sortArrow('dqi')}
						</th>
						<th class="cursor-pointer" onclick={() => toggleSort('cost_usd')}>
							Cost{sortArrow('cost_usd')}
						</th>
						<th class="cursor-pointer" onclick={() => toggleSort('duration_ms')}>
							Duration{sortArrow('duration_ms')}
						</th>
						<th class="cursor-pointer" onclick={() => toggleSort('status')}>
							Status{sortArrow('status')}
						</th>
						<th class="cursor-pointer" onclick={() => toggleSort('started_at')}>
							Date{sortArrow('started_at')}
						</th>
					</tr>
				</thead>
				<tbody>
					{#each sortedRuns() as run}
						<tr class="cursor-pointer" onclick={() => window.location.href = `/runs/${run.id}`}>
							<td>
								<span class="font-mono text-xs" style="color: var(--text-muted)">{run.id.slice(0, 8)}</span>
							</td>
							<td>
								{#if run.workspace}
									<span class="badge badge-accent">{run.workspace}</span>
								{/if}
							</td>
							<td>
								<span class="text-sm" style="color: var(--text-secondary)">
									{run.task.slice(0, 50)}{run.task.length > 50 ? '…' : ''}
								</span>
							</td>
							<td>
								{#if run.dqi != null}
									<div class="flex items-center gap-2">
										<span class="font-mono text-sm font-semibold" style="color: {dqiColor(run.dqi)}">
											{(run.dqi * 100).toFixed(0)}
										</span>
										<div class="w-12 h-1.5 rounded-full" style="background: var(--bg-inset)">
											<div class="h-full rounded-full" style="width: {run.dqi * 100}%; background: {dqiColor(run.dqi)}"></div>
										</div>
									</div>
								{:else}
									<span class="text-sm" style="color: var(--text-faint)">—</span>
								{/if}
							</td>
							<td class="font-mono text-sm">{formatCost(run.cost_usd)}</td>
							<td class="text-sm" style="color: var(--text-secondary)">{formatDurationMs(run.duration_ms)}</td>
							<td><StatusBadge status={run.status} /></td>
							<td class="text-sm" style="color: var(--text-muted)">{formatDate(run.started_at)}</td>
						</tr>
					{/each}
				</tbody>
			</table>
		</div>

		<!-- Pagination -->
		{#if totalPages > 1}
			<div class="flex items-center justify-between">
				<span class="text-xs" style="color: var(--text-muted)">
					Page {currentPage + 1} of {totalPages}
				</span>
				<div class="flex gap-2">
					<button class="btn btn-ghost text-xs" onclick={prevPage} disabled={currentPage === 0}>
						← Prev
					</button>
					<button class="btn btn-ghost text-xs" onclick={nextPage} disabled={currentPage >= totalPages - 1}>
						Next →
					</button>
				</div>
			</div>
		{/if}
	{/if}
</div>
