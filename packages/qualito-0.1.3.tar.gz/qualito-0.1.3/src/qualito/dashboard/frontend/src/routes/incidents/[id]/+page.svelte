<script lang="ts">
	import { onMount } from 'svelte';
	import { page } from '$app/stores';
	import Breadcrumb from '$lib/components/Breadcrumb.svelte';
	import Card from '$lib/components/Card.svelte';
	import Badge from '$lib/components/Badge.svelte';
	import StatusBadge from '$lib/components/StatusBadge.svelte';
	import SlidePanel from '$lib/components/SlidePanel.svelte';
	import { getIncident } from '$lib/api';
	import { formatDate, severityColor } from '$lib/format';
	import type { Incident, IncidentEvent } from '$lib/types';

	let incident = $state<(Incident & { events: IncidentEvent[] }) | null>(null);
	let error = $state<string | null>(null);
	let reportOpen = $state(false);

	let incidentId = $derived($page.params.id ?? '');

	onMount(async () => {
		try {
			incident = await getIncident(incidentId);
		} catch (e) {
			error = e instanceof Error ? e.message : 'Failed to load incident';
		}
	});

	function severityVariant(sev: string): 'error' | 'warning' | 'info' | 'neutral' {
		if (sev === 'critical') return 'error';
		if (sev === 'warning') return 'warning';
		if (sev === 'info') return 'info';
		return 'neutral';
	}

	function eventDotColor(eventType: string): string {
		switch (eventType) {
			case 'detected': return 'var(--error)';
			case 'confirmed': return 'var(--warning)';
			case 'resolved': return 'var(--success)';
			case 'escalated': return 'var(--error)';
			default: return 'var(--text-faint)';
		}
	}

	let details = $derived(() => {
		if (!incident?.details) return null;
		try {
			return JSON.parse(incident.details);
		} catch {
			return incident.details;
		}
	});
</script>

<div class="space-y-6">
	<Breadcrumb items={[
		{ label: 'Incidents', href: '/incidents' },
		{ label: incident ? `#${incident.id}` : incidentId }
	]} />

	{#if error}
		<div class="card p-4" style="border-color: var(--error)">
			<p style="color: var(--error)">{error}</p>
		</div>
	{:else if !incident}
		<div class="space-y-4">
			<div class="skeleton h-10 w-64 rounded-lg"></div>
			<div class="grid grid-cols-1 md:grid-cols-4 gap-4">
				{#each Array(4) as _}
					<div class="skeleton h-24 rounded-xl"></div>
				{/each}
			</div>
		</div>
	{:else}
		<!-- Severity banner -->
		<div class="rounded-xl overflow-hidden" style="border: 1px solid {severityColor(incident.severity)};">
			<div class="h-1" style="background: {severityColor(incident.severity)};"></div>
			<div class="p-4 flex flex-wrap items-center gap-3" style="background: var(--bg-card);">
				<Badge variant={severityVariant(incident.severity)} text={incident.severity} />
				<h1 class="text-lg font-semibold" style="color: var(--text)">{incident.title}</h1>
				<StatusBadge status={incident.status} />
			</div>
		</div>

		<!-- Metric cards -->
		<div class="grid grid-cols-2 md:grid-cols-4 gap-4">
			<div class="metric-card">
				<div class="relative z-10">
					<p class="text-xs" style="color: var(--text-faint)">Workspace</p>
					<p class="text-lg font-semibold mt-1" style="color: var(--text)">
						{incident.workspace ?? '—'}
					</p>
				</div>
			</div>
			<div class="metric-card">
				<div class="relative z-10">
					<p class="text-xs" style="color: var(--text-faint)">Detection Method</p>
					<p class="text-lg font-semibold font-mono mt-1" style="color: var(--text)">
						{incident.detector}
					</p>
				</div>
			</div>
			<div class="metric-card">
				<div class="relative z-10">
					<p class="text-xs" style="color: var(--text-faint)">Created</p>
					<p class="text-sm font-medium mt-1" style="color: var(--text)">
						{formatDate(incident.created_at)}
					</p>
				</div>
			</div>
			<div class="metric-card">
				<div class="relative z-10">
					<p class="text-xs" style="color: var(--text-faint)">Resolved</p>
					<p class="text-sm font-medium mt-1" style="color: {incident.resolved_at ? 'var(--success)' : 'var(--text-muted)'}">
						{incident.resolved_at ? formatDate(incident.resolved_at) : 'Open'}
					</p>
				</div>
			</div>
		</div>

		<!-- Linked run -->
		{#if incident.run_id}
			<Card title="Affected Run" padding="p-4">
				<a
					href="/runs/{incident.run_id}"
					class="font-mono text-sm"
					style="color: var(--accent)"
				>
					{incident.run_id.slice(0, 12)} →
				</a>
			</Card>
		{/if}

		<!-- Event timeline -->
		{#if incident.events && incident.events.length > 0}
			<Card title="Event Timeline" padding="p-5">
				<div class="space-y-0">
					{#each incident.events as event, i}
						<div class="flex gap-3">
							<!-- Timeline rail -->
							<div class="flex flex-col items-center">
								<div
									class="w-3 h-3 rounded-full flex-shrink-0 mt-0.5"
									style="background: {eventDotColor(event.event_type)}; box-shadow: 0 0 6px {eventDotColor(event.event_type)}40;"
								></div>
								{#if i < incident.events.length - 1}
									<div class="w-px flex-1 my-1" style="background: var(--border);"></div>
								{/if}
							</div>
							<!-- Content -->
							<div class="pb-4 flex-1 min-w-0">
								<div class="flex items-center gap-2 mb-1">
									<span class="text-xs font-semibold uppercase" style="color: {eventDotColor(event.event_type)}">
										{event.event_type}
									</span>
									<span class="text-[10px]" style="color: var(--text-faint)">
										{formatDate(event.created_at)}
									</span>
								</div>
								<p class="text-sm" style="color: var(--text-secondary)">{event.message}</p>
							</div>
						</div>
					{/each}
				</div>
			</Card>
		{/if}

		<!-- Details / Report -->
		{#if details()}
			<div class="flex gap-2">
				<button class="btn btn-secondary text-xs" onclick={() => reportOpen = true}>
					View Full Details
				</button>
			</div>

			<SlidePanel open={reportOpen} title="Incident Details" onclose={() => reportOpen = false}>
				{#if typeof details() === 'string'}
					<pre class="text-sm whitespace-pre-wrap" style="color: var(--text-secondary)">{details()}</pre>
				{:else}
					<pre class="text-xs font-mono overflow-x-auto" style="color: var(--text-secondary)">{JSON.stringify(details(), null, 2)}</pre>
				{/if}
			</SlidePanel>
		{/if}
	{/if}
</div>
