<script lang="ts">
	import { onMount } from 'svelte';
	import Card from '$lib/components/Card.svelte';
	import StatusBadge from '$lib/components/StatusBadge.svelte';
	import { listExperiments } from '$lib/api';
	import { formatDate, dqiColor } from '$lib/format';
	import type { Experiment } from '$lib/types';

	let experiments = $state<Experiment[]>([]);
	let error = $state<string | null>(null);
	let loading = $state(true);

	// Filters
	let filterStatus = $state('');
	let searchQuery = $state('');

	async function fetchExperiments() {
		loading = true;
		error = null;
		try {
			const res = await listExperiments();
			experiments = res.experiments;
		} catch (e) {
			error = e instanceof Error ? e.message : 'Failed to load experiments';
		} finally {
			loading = false;
		}
	}

	onMount(fetchExperiments);

	let statuses = $derived(() => {
		const s = new Set<string>();
		for (const e of experiments) if (e.status) s.add(e.status);
		return [...s].sort();
	});

	let filtered = $derived(() => {
		let list = experiments;
		if (filterStatus) list = list.filter((e) => e.status === filterStatus);
		if (searchQuery) {
			const q = searchQuery.toLowerCase();
			list = list.filter(
				(e) =>
					e.name.toLowerCase().includes(q) ||
					(e.description ?? '').toLowerCase().includes(q)
			);
		}
		return list;
	});
</script>

<div class="space-y-6">
	<h1 class="text-xl font-semibold" style="color: var(--text)">Experiments</h1>

	<!-- Filter bar -->
	<div class="flex flex-wrap gap-3 items-center">
		<select
			class="select-field text-sm"
			bind:value={filterStatus}
		>
			<option value="">All statuses</option>
			{#each statuses() as s}
				<option value={s}>{s}</option>
			{/each}
		</select>

		<input
			class="input text-sm flex-1 min-w-[200px]"
			type="text"
			placeholder="Search experiments…"
			bind:value={searchQuery}
		/>

		<span class="text-xs ml-auto" style="color: var(--text-muted)">
			{filtered().length} experiment{filtered().length !== 1 ? 's' : ''}
		</span>
	</div>

	{#if error}
		<div class="card p-4" style="border-color: var(--error)">
			<p style="color: var(--error)">{error}</p>
		</div>
	{:else if loading}
		<div class="grid grid-cols-1 md:grid-cols-2 gap-4">
			{#each Array(4) as _}
				<div class="skeleton h-40 rounded-xl"></div>
			{/each}
		</div>
	{:else if filtered().length === 0}
		<Card padding="p-8">
			<p class="text-center text-sm" style="color: var(--text-muted)">No experiments found</p>
		</Card>
	{:else}
		<div class="grid grid-cols-1 md:grid-cols-2 gap-4">
			{#each filtered() as exp}
				<a href="/experiments/{exp.id}" class="block">
					<Card padding="p-5">
						<div class="space-y-3">
							<!-- Header -->
							<div class="flex items-start justify-between gap-2">
								<h3 class="text-sm font-semibold" style="color: var(--text)">
									{exp.name}
								</h3>
								<StatusBadge status={exp.status} />
							</div>

							<!-- Description -->
							{#if exp.description}
								<p class="text-xs" style="color: var(--text-muted)">
									{exp.description.slice(0, 120)}{exp.description.length > 120 ? '…' : ''}
								</p>
							{/if}

							<!-- Metrics row -->
							<div class="flex items-center gap-4 pt-1">
								<div class="flex items-center gap-1.5">
									<span class="text-[10px] uppercase tracking-wider" style="color: var(--text-faint)">Avg DQI</span>
									<span class="font-mono text-sm font-semibold" style="color: {dqiColor(exp.avg_dqi)}">
										{exp.avg_dqi != null ? (exp.avg_dqi * 100).toFixed(0) : '—'}
									</span>
								</div>

								<span class="text-xs" style="color: var(--text-faint)">
									{formatDate(exp.created_at)}
								</span>
							</div>
						</div>
					</Card>
				</a>
			{/each}
		</div>
	{/if}
</div>
