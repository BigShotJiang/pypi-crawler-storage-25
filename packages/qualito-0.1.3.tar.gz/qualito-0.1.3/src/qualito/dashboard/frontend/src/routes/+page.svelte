<script lang="ts">
	import { onMount } from 'svelte';
	import DqiGauge from '$lib/components/DqiGauge.svelte';
	import Card from '$lib/components/Card.svelte';
	import Chart from '$lib/components/Chart.svelte';
	import StatusBadge from '$lib/components/StatusBadge.svelte';
	import { getDashboard, getMetrics, listRuns } from '$lib/api';
	import { formatDate, formatCost, dqiColor } from '$lib/format';
	import type { DashboardData, MetricsData, Run } from '$lib/types';

	let dashboard = $state<DashboardData | null>(null);
	let metrics = $state<MetricsData | null>(null);
	let recentRuns = $state<Run[]>([]);
	let error = $state<string | null>(null);

	// MCP onboarding state
	let apiKey = $state<string | null>(null);
	let importCmd = $derived(apiKey ? `uvx qualito setup ${apiKey}` : 'uvx qualito setup YOUR_API_KEY');
	let showOnboarding = $state(false);
	let showImportSection = $state(false);

	onMount(async () => {
		// Check for API key (set during registration)
		if (typeof localStorage !== 'undefined') {
			apiKey = localStorage.getItem('qualito_api_key');
		}

		try {
			const [d, m, r] = await Promise.all([
				getDashboard(),
				getMetrics({ days: 30 }),
				listRuns({ limit: 10 })
			]);
			dashboard = d;
			metrics = m;
			recentRuns = r.runs;
		} catch (e) {
			error = e instanceof Error ? e.message : 'Failed to load dashboard';
		}

		// Show onboarding if user has no runs and has an API key from registration
		if (apiKey && dashboard && dashboard.run_count === 0) {
			showOnboarding = true;
		}
		// Also show onboarding for users with no runs and no API key (returning users)
		if (!apiKey && dashboard && dashboard.run_count === 0) {
			showOnboarding = true;
		}
	});

	function getMcpConfigJson(_key: string): string {
		return JSON.stringify({
			qualito: {
				type: 'http',
				url: 'https://api.qualito.ai/mcp/',
				headers: {
					Authorization: 'Bearer ${QUALITO_API_KEY}'
				}
			}
		}, null, 2);
	}

	function clearOnboarding() {
		localStorage.removeItem('qualito_setup_token');
		showOnboarding = false;
	}

	let trendChartData = $derived(
		metrics
			? {
					labels: metrics.dqi_trend.map((d) => d.date),
					datasets: [
						{
							label: 'DQI',
							data: metrics.dqi_trend.map((d) => d.avg_dqi != null ? +(d.avg_dqi * 100).toFixed(1) : null),
							borderColor: '#14b8a6',
							backgroundColor: 'rgba(20, 184, 166, 0.1)',
							fill: true,
							tension: 0.3,
							pointRadius: 3,
							pointBackgroundColor: '#14b8a6'
						}
					]
				}
			: null
	);

	let trendChartOptions = {
		scales: {
			y: {
				min: 0,
				max: 100,
				grid: { color: 'rgba(28, 40, 53, 0.5)' },
				ticks: { color: '#64748b', font: { size: 11 } }
			},
			x: {
				grid: { color: 'rgba(28, 40, 53, 0.5)' },
				ticks: { color: '#64748b', font: { size: 11 }, maxTicksLimit: 10 }
			}
		},
		plugins: { legend: { display: false } }
	} as any;

	function sloIcon(pass: boolean): string {
		return pass ? '✓' : '✗';
	}

	function formatDurationMs(ms: number | null): string {
		if (ms == null) return '—';
		const secs = ms / 1000;
		if (secs < 60) return `${Math.round(secs)}s`;
		const m = Math.floor(secs / 60);
		const s = Math.round(secs % 60);
		return `${m}m ${s}s`;
	}
</script>

<div class="space-y-6">
	<h1 class="text-xl font-semibold" style="color: var(--text)">Dashboard</h1>

	{#if error}
		<div class="card p-4" style="border-color: var(--error)">
			<p style="color: var(--error)">{error}</p>
		</div>
	{:else if !dashboard}
		<div class="grid grid-cols-1 md:grid-cols-4 gap-4">
			{#each Array(4) as _}
				<div class="skeleton h-24 rounded-xl"></div>
			{/each}
		</div>
	{:else if showOnboarding}
		<!-- MCP-first onboarding -->
		<div class="space-y-8 max-w-2xl mx-auto py-4">
			<div class="text-center space-y-3">
				<div class="inline-flex items-center justify-center w-14 h-14 rounded-2xl" style="background: var(--accent-subtle); border: 1px solid var(--border);">
					<svg width="28" height="28" viewBox="0 0 24 24" fill="none" stroke="var(--accent)" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round">
						<path d="M12 20V10" /><path d="M18 20V4" /><path d="M6 20v-4" />
					</svg>
				</div>
				<h2 class="text-2xl font-semibold" style="color: var(--text)">
					Welcome to <span class="text-gradient">Qualito</span>
				</h2>
				<p class="text-sm" style="color: var(--text-muted); max-width: 420px; margin: 0 auto;">
					Add Qualito to Claude Code and get quality metrics for every session.
				</p>
			</div>

			<div class="glow-line"></div>

			<!-- Step 1: Save API key -->
			<div class="card p-5 space-y-4">
				<div class="flex items-center gap-3">
					<div class="flex-shrink-0 w-8 h-8 rounded-lg flex items-center justify-center font-mono text-sm font-semibold"
						style="background: var(--accent); color: white;">
						1
					</div>
					<div>
						<p class="text-sm font-medium" style="color: var(--text)">Save your API key</p>
						<p class="text-xs mt-0.5" style="color: var(--text-muted)">
							Add this to your shell profile (<code style="color: var(--accent);">~/.zshrc</code> or <code style="color: var(--accent);">~/.bashrc</code>), then restart your terminal.
						</p>
					</div>
				</div>

				{#if apiKey}
					<div class="relative">
						<pre class="font-mono text-xs px-4 py-3 rounded-lg select-all overflow-x-auto"
							style="background: var(--bg-inset); color: var(--accent-hover); border: 1px solid var(--border-subtle); line-height: 1.6; margin: 0;">export QUALITO_API_KEY="{apiKey}"</pre>
						<button class="btn btn-ghost text-xs absolute top-2 right-2"
							style="padding: 4px 8px;"
							onclick={(e) => {
								navigator.clipboard.writeText(`export QUALITO_API_KEY="${apiKey}"`);
								const btn = e.currentTarget;
								btn.textContent = 'Copied';
								setTimeout(() => btn.textContent = 'Copy', 1500);
							}}>
							Copy
						</button>
					</div>
					<p class="text-xs" style="color: var(--text-faint)">
						This key is shown only once. Copy it now.
					</p>
				{:else}
					<div class="px-4 py-3 rounded-lg text-xs" style="background: var(--bg-inset); border: 1px solid var(--border-subtle); color: var(--text-muted);">
						Create an API key in <a href="/settings" style="color: var(--accent); text-decoration: underline;">Settings</a> to get started.
					</div>
				{/if}
			</div>

			<!-- Step 2: Add MCP config -->
			<div class="card p-5 space-y-4">
				<div class="flex items-center gap-3">
					<div class="flex-shrink-0 w-8 h-8 rounded-lg flex items-center justify-center font-mono text-sm font-semibold"
						style="background: var(--accent); color: white;">
						2
					</div>
					<div>
						<p class="text-sm font-medium" style="color: var(--text)">Add Qualito to Claude Code</p>
						<p class="text-xs mt-0.5" style="color: var(--text-muted)">
							Add this to your <a href="https://docs.anthropic.com/en/docs/claude-code/mcp" target="_blank" rel="noopener" style="color: var(--accent); text-decoration: underline;">Claude Code MCP settings</a> (<code style="color: var(--accent);">.mcp.json</code>), then restart Claude Code.
						</p>
					</div>
				</div>

				<div class="relative">
					<pre class="font-mono text-xs px-4 py-3 rounded-lg select-all overflow-x-auto"
						style="background: var(--bg-inset); color: var(--accent-hover); border: 1px solid var(--border-subtle); line-height: 1.6; margin: 0;">{getMcpConfigJson(apiKey || '')}</pre>
					<button class="btn btn-ghost text-xs absolute top-2 right-2"
						style="padding: 4px 8px;"
						onclick={(e) => {
							navigator.clipboard.writeText(getMcpConfigJson(apiKey || ''));
							const btn = e.currentTarget;
							btn.textContent = 'Copied';
							setTimeout(() => btn.textContent = 'Copy', 1500);
						}}>
						Copy
					</button>
				</div>
				<p class="text-xs" style="color: var(--text-faint)">
					The <code style="color: var(--accent);">${'${QUALITO_API_KEY}'}</code> is automatically read from your shell environment. No key in the config file.
				</p>
			</div>

			<!-- Step 3: Import existing sessions (collapsible) -->
			<div class="card p-5 space-y-3">
				<button class="flex items-center gap-3 w-full text-left"
					onclick={() => showImportSection = !showImportSection}>
					<div class="flex-shrink-0 w-8 h-8 rounded-lg flex items-center justify-center font-mono text-sm font-semibold"
						style="background: var(--accent-subtle); color: var(--accent); border: 1px solid var(--border);">
						3
					</div>
					<div class="flex-1">
						<p class="text-sm font-medium" style="color: var(--text)">Import existing sessions</p>
						<p class="text-xs mt-0.5" style="color: var(--text-muted)">Optional — import past Claude Code sessions for historical data</p>
					</div>
					<svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="var(--text-muted)" stroke-width="2" stroke-linecap="round"
						style="transform: rotate({showImportSection ? '180deg' : '0deg'}); transition: transform 0.2s;">
						<path d="M6 9l6 6 6-6" />
					</svg>
				</button>

				{#if showImportSection}
					<div class="pt-2 space-y-3">
						<p class="text-xs" style="color: var(--text-muted)">
							Already been using Claude Code? Import your existing sessions to see historical quality data:
						</p>
						<div class="flex items-center gap-2">
							<code class="font-mono text-xs px-3 py-2 rounded-lg flex-1 select-all"
								style="background: var(--bg-inset); color: var(--accent-hover); border: 1px solid var(--border-subtle);">
								$ {importCmd}
							</code>
							<button class="btn btn-ghost text-xs flex-shrink-0"
								style="padding: 6px 10px;"
								onclick={(e) => {
									navigator.clipboard.writeText(importCmd);
									const btn = e.currentTarget;
									btn.textContent = 'Copied';
									setTimeout(() => btn.textContent = 'Copy', 1500);
								}}>
								Copy
							</button>
						</div>
						<p class="text-xs" style="color: var(--text-faint)">
							The MCP tools work without this step — you just won't have historical data.
						</p>
					</div>
				{/if}
			</div>

			<!-- Step 3: Go to Dashboard -->
			<div class="text-center space-y-3">
				<button class="btn btn-primary" onclick={clearOnboarding}>
					Go to Dashboard
				</button>
				<p>
					<button class="text-xs" style="color: var(--text-faint); text-decoration: underline; background: none; border: none; cursor: pointer; padding: 0;"
						onclick={clearOnboarding}>
						Skip setup
					</button>
				</p>
			</div>
		</div>

	{:else}
		<!-- Active incidents banner -->
		{#if dashboard.active_incidents > 0}
			<a href="/incidents" class="block">
				<div class="card p-3 flex items-center gap-3" style="border-color: var(--error); background: var(--error-muted);">
					<svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="var(--error)" stroke-width="2" stroke-linecap="round">
						<path d="M12 9v2m0 4h.01m-6.938 4h13.856c1.54 0 2.502-1.667 1.732-3L13.732 4c-.77-1.333-2.694-1.333-3.464 0L3.34 16c-.77 1.333.192 3 1.732 3z" />
					</svg>
					<span class="text-sm font-medium" style="color: var(--error)">
						{dashboard.active_incidents} active incident{dashboard.active_incidents !== 1 ? 's' : ''} — click to view
					</span>
				</div>
			</a>
		{/if}

		<!-- Hero section -->
		<div class="flex flex-col md:flex-row gap-6 items-start">
			<Card padding="p-6">
				<div class="flex flex-col items-center">
					<DqiGauge score={dashboard.avg_dqi ?? 0} />
					<span class="text-xs mt-2" style="color: var(--text-faint)">Average DQI (30d)</span>
				</div>
			</Card>

			<!-- Stats grid -->
			<div class="flex-1 grid grid-cols-2 gap-4">
				<div class="metric-card">
					<div class="relative z-10">
						<p class="text-xs" style="color: var(--text-faint)">Runs (30d)</p>
						<p class="text-2xl font-semibold font-mono mt-1" style="color: var(--text)">{dashboard.run_count}</p>
					</div>
				</div>
				<div class="metric-card">
					<div class="relative z-10">
						<p class="text-xs" style="color: var(--text-faint)">Total Cost (30d)</p>
						<p class="text-2xl font-semibold font-mono mt-1" style="color: var(--text)">{formatCost(dashboard.total_cost_30d)}</p>
					</div>
				</div>
				<div class="metric-card">
					<div class="relative z-10">
						<p class="text-xs" style="color: var(--text-faint)">Active Incidents</p>
						<p class="text-2xl font-semibold font-mono mt-1" style="color: {dashboard.active_incidents > 0 ? 'var(--error)' : 'var(--success)'}">
							{dashboard.active_incidents}
						</p>
					</div>
				</div>
				<div class="metric-card">
					<div class="relative z-10">
						<p class="text-xs" style="color: var(--text-faint)">SLO Status</p>
						<div class="flex items-center gap-2 mt-1">
							{#each ['quality', 'availability', 'cost'] as key}
								{@const slo = dashboard.slo_status[key as keyof typeof dashboard.slo_status]}
								<span class="text-xs font-mono font-semibold" style="color: {slo.pass ? 'var(--success)' : 'var(--error)'}">
									{sloIcon(slo.pass)} {key[0].toUpperCase()}
								</span>
							{/each}
						</div>
					</div>
				</div>
			</div>
		</div>

		<!-- DQI Trend Chart -->
		{#if trendChartData && trendChartData.labels.length > 0}
			<Card title="DQI Trend (30d)" padding="p-4">
				<Chart type="line" data={trendChartData} options={trendChartOptions} height={250} />
			</Card>
		{/if}

		<!-- Recent Runs -->
		{#if recentRuns.length > 0}
			<Card title="Recent Runs" padding="p-0">
				<div class="table-container" style="border: none; border-radius: 0;">
					<table>
						<thead>
							<tr>
								<th>Run ID</th>
								<th>Workspace</th>
								<th>Task</th>
								<th>DQI</th>
								<th>Cost</th>
								<th>Duration</th>
								<th>Date</th>
							</tr>
						</thead>
						<tbody>
							{#each recentRuns as run}
								<tr class="cursor-pointer" onclick={() => window.location.href = `/runs/${run.id}`}>
									<td>
										<span class="font-mono text-xs" style="color: var(--text-muted)">{run.id.slice(0, 8)}</span>
									</td>
									<td>
										{#if run.workspace}
											<span class="badge badge-accent">{run.workspace}</span>
										{/if}
									</td>
									<td>
										<span class="text-sm" style="color: var(--text-secondary)">
											{run.task.slice(0, 60)}{run.task.length > 60 ? '…' : ''}
										</span>
									</td>
									<td>
										<span class="font-mono text-sm font-semibold" style="color: {dqiColor(run.dqi)}">
											{run.dqi != null ? (run.dqi * 100).toFixed(0) : '—'}
										</span>
									</td>
									<td class="font-mono text-sm">{formatCost(run.cost_usd)}</td>
									<td class="text-sm" style="color: var(--text-secondary)">{formatDurationMs(run.duration_ms)}</td>
									<td class="text-sm" style="color: var(--text-muted)">{formatDate(run.started_at)}</td>
								</tr>
							{/each}
						</tbody>
					</table>
				</div>
				<div class="p-3 text-center">
					<a href="/runs" class="text-xs font-medium" style="color: var(--accent)">View all runs →</a>
				</div>
			</Card>
		{/if}
	{/if}
</div>
