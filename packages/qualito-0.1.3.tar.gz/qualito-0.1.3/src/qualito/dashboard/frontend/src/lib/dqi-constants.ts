/** DQI tier labels and color mappings. */
export const DQI_TIERS = [
	{ min: 0.8, label: 'Excellent', color: 'var(--success)', bgColor: 'var(--success-muted)' },
	{ min: 0.6, label: 'Good', color: 'var(--accent)', bgColor: 'var(--accent-subtle)' },
	{ min: 0.4, label: 'Fair', color: 'var(--warning)', bgColor: 'var(--warning-muted)' },
	{ min: 0.0, label: 'Poor', color: 'var(--error)', bgColor: 'var(--error-muted)' }
] as const;

export function getTier(score: number) {
	return DQI_TIERS.find((t) => score >= t.min) ?? DQI_TIERS[DQI_TIERS.length - 1];
}

/** DQI score dimension weights and descriptions. */
export const DQI_DIMENSIONS = [
	{ key: 'correctness', label: 'Correctness', weight: 0.30, description: 'Does the output match the task requirements?' },
	{ key: 'efficiency', label: 'Efficiency', weight: 0.25, description: 'Token/cost efficiency of the delegation.' },
	{ key: 'autonomy', label: 'Autonomy', weight: 0.25, description: 'How much human intervention was needed?' },
	{ key: 'safety', label: 'Safety', weight: 0.20, description: 'Were dangerous operations avoided?' }
] as const;

/** Default SLO targets. */
export const SLO_DEFAULTS = {
	dqi_p50: { target: 0.7, window_days: 7, label: 'DQI p50' },
	dqi_p90: { target: 0.5, window_days: 7, label: 'DQI p90' },
	cost_per_run: { target: 0.50, window_days: 7, label: 'Cost per run (USD)' },
	incident_rate: { target: 0.05, window_days: 30, label: 'Incident rate' }
} as const;
