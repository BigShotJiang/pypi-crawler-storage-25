<script lang="ts">
	import { onMount } from 'svelte';
	import Card from '$lib/components/Card.svelte';
	import Chart from '$lib/components/Chart.svelte';
	import { getMetrics, listRuns } from '$lib/api';
	import { formatCost } from '$lib/format';
	import type { MetricsData } from '$lib/types';

	let metrics = $state<MetricsData | null>(null);
	let error = $state<string | null>(null);

	// Summary stats
	let avgDqi = $state<number | null>(null);
	let totalSpend = $state(0);
	let wasteEstimate = $state(0);
	let runCount = $state(0);

	onMount(async () => {
		try {
			const [m, r] = await Promise.all([
				getMetrics({ days: 30 }),
				listRuns({ limit: 200 })
			]);
			metrics = m;

			// Compute summary stats from runs
			const runs = r.runs;
			runCount = r.total;
			let dqiSum = 0;
			let dqiCount = 0;
			let waste = 0;
			let spend = 0;
			for (const run of runs) {
				if (run.cost_usd != null) spend += run.cost_usd;
				if (run.dqi != null) {
					dqiSum += run.dqi;
					dqiCount++;
					if (run.dqi < 0.5 && run.cost_usd != null) waste += run.cost_usd;
				}
			}
			avgDqi = dqiCount > 0 ? dqiSum / dqiCount : null;
			totalSpend = spend;
			wasteEstimate = waste;
		} catch (e) {
			error = e instanceof Error ? e.message : 'Failed to load metrics';
		}
	});

	// DQI Trend chart
	let dqiTrendData = $derived(
		metrics
			? {
					labels: metrics.dqi_trend.map((d) => d.date),
					datasets: [
						{
							label: 'Avg DQI',
							data: metrics.dqi_trend.map((d) => d.avg_dqi != null ? +(d.avg_dqi * 100).toFixed(1) : null),
							borderColor: '#14b8a6',
							backgroundColor: 'rgba(20, 184, 166, 0.1)',
							fill: true,
							tension: 0.3,
							pointRadius: 3,
							pointBackgroundColor: '#14b8a6'
						}
					]
				}
			: null
	);

	// Cost Trend chart
	let costTrendData = $derived(
		metrics
			? {
					labels: metrics.cost_trend.map((d) => d.date),
					datasets: [
						{
							label: 'Daily Cost',
							data: metrics.cost_trend.map((d) => d.total_cost),
							borderColor: '#38bdf8',
							backgroundColor: 'rgba(56, 189, 248, 0.1)',
							fill: true,
							tension: 0.3,
							pointRadius: 3,
							pointBackgroundColor: '#38bdf8'
						}
					]
				}
			: null
	);

	// DQI by Workspace (horizontal bar)
	let byWorkspaceData = $derived(
		metrics && metrics.by_workspace.length > 0
			? {
					labels: metrics.by_workspace.map((w) => w.workspace || '(none)'),
					datasets: [
						{
							label: 'Runs',
							data: metrics.by_workspace.map((w) => w.run_count),
							backgroundColor: 'rgba(20, 184, 166, 0.6)',
							borderColor: '#14b8a6',
							borderWidth: 1,
							borderRadius: 4
						}
					]
				}
			: null
	);

	// DQI by Task Type (horizontal bar)
	let byTaskTypeData = $derived(
		metrics && metrics.by_task_type.length > 0
			? {
					labels: metrics.by_task_type.map((t) => t.task_type || '(none)'),
					datasets: [
						{
							label: 'Runs',
							data: metrics.by_task_type.map((t) => t.run_count),
							backgroundColor: 'rgba(56, 189, 248, 0.6)',
							borderColor: '#38bdf8',
							borderWidth: 1,
							borderRadius: 4
						}
					]
				}
			: null
	);

	const lineChartOptions: any = {
		scales: {
			y: {
				grid: { color: 'rgba(28, 40, 53, 0.5)' },
				ticks: { color: '#64748b', font: { size: 11 } }
			},
			x: {
				grid: { color: 'rgba(28, 40, 53, 0.5)' },
				ticks: { color: '#64748b', font: { size: 11 }, maxTicksLimit: 10 }
			}
		},
		plugins: { legend: { display: false } }
	};

	const dqiLineOptions: any = {
		...lineChartOptions,
		scales: {
			...lineChartOptions.scales,
			y: { ...lineChartOptions.scales.y, min: 0, max: 100 }
		}
	};

	const costLineOptions: any = {
		...lineChartOptions,
		scales: {
			...lineChartOptions.scales,
			y: {
				...lineChartOptions.scales.y,
				ticks: {
					...lineChartOptions.scales.y.ticks,
					callback: (v: string | number) => `$${Number(v).toFixed(2)}`
				}
			}
		}
	};

	const barChartOptions: any = {
		indexAxis: 'y',
		scales: {
			x: {
				grid: { color: 'rgba(28, 40, 53, 0.5)' },
				ticks: { color: '#64748b', font: { size: 11 } }
			},
			y: {
				grid: { display: false },
				ticks: { color: '#94a3b8', font: { size: 11 } }
			}
		},
		plugins: { legend: { display: false } }
	};
</script>

<div class="space-y-6">
	<h1 class="text-xl font-semibold" style="color: var(--text)">Metrics</h1>

	{#if error}
		<div class="card p-4" style="border-color: var(--error)">
			<p style="color: var(--error)">{error}</p>
		</div>
	{:else if !metrics}
		<div class="grid grid-cols-2 md:grid-cols-4 gap-4">
			{#each Array(4) as _}
				<div class="skeleton h-24 rounded-xl"></div>
			{/each}
		</div>
	{:else}
		<!-- Key numbers row -->
		<div class="grid grid-cols-2 md:grid-cols-4 gap-4">
			<div class="metric-card">
				<div class="relative z-10">
					<p class="text-xs" style="color: var(--text-faint)">Avg DQI</p>
					<p class="text-2xl font-semibold font-mono mt-1" style="color: var(--accent)">
						{avgDqi != null ? (avgDqi * 100).toFixed(0) : '—'}
					</p>
				</div>
			</div>
			<div class="metric-card">
				<div class="relative z-10">
					<p class="text-xs" style="color: var(--text-faint)">Total Spend (30d)</p>
					<p class="text-2xl font-semibold font-mono mt-1" style="color: var(--text)">{formatCost(totalSpend)}</p>
				</div>
			</div>
			<div class="metric-card">
				<div class="relative z-10">
					<p class="text-xs" style="color: var(--text-faint)">Waste (DQI &lt; 50)</p>
					<p class="text-2xl font-semibold font-mono mt-1" style="color: {wasteEstimate > 0 ? 'var(--warning)' : 'var(--success)'}">
						{formatCost(wasteEstimate)}
					</p>
				</div>
			</div>
			<div class="metric-card">
				<div class="relative z-10">
					<p class="text-xs" style="color: var(--text-faint)">Run Count</p>
					<p class="text-2xl font-semibold font-mono mt-1" style="color: var(--text)">{runCount}</p>
				</div>
			</div>
		</div>

		<!-- Charts grid -->
		<div class="grid grid-cols-1 md:grid-cols-2 gap-6">
			{#if dqiTrendData && dqiTrendData.labels.length > 0}
				<Card title="DQI Trend (30d)" padding="p-4">
					<Chart type="line" data={dqiTrendData} options={dqiLineOptions} height={280} />
				</Card>
			{:else}
				<Card title="DQI Trend (30d)" padding="p-8">
					<p class="text-sm text-center" style="color: var(--text-muted)">No DQI data yet</p>
				</Card>
			{/if}

			{#if costTrendData && costTrendData.labels.length > 0}
				<Card title="Cost Trend (30d)" padding="p-4">
					<Chart type="line" data={costTrendData} options={costLineOptions} height={280} />
				</Card>
			{:else}
				<Card title="Cost Trend (30d)" padding="p-8">
					<p class="text-sm text-center" style="color: var(--text-muted)">No cost data yet</p>
				</Card>
			{/if}

			{#if byWorkspaceData}
				<Card title="Runs by Workspace" padding="p-4">
					<Chart type="bar" data={byWorkspaceData} options={barChartOptions} height={280} />
				</Card>
			{:else}
				<Card title="Runs by Workspace" padding="p-8">
					<p class="text-sm text-center" style="color: var(--text-muted)">No workspace data yet</p>
				</Card>
			{/if}

			{#if byTaskTypeData}
				<Card title="Runs by Task Type" padding="p-4">
					<Chart type="bar" data={byTaskTypeData} options={barChartOptions} height={280} />
				</Card>
			{:else}
				<Card title="Runs by Task Type" padding="p-8">
					<p class="text-sm text-center" style="color: var(--text-muted)">No task type data yet</p>
				</Card>
			{/if}
		</div>
	{/if}
</div>
