<script lang="ts">
	import '../app.css';
	import { onMount, onDestroy } from 'svelte';
	import { page } from '$app/stores';
	import { goto } from '$app/navigation';
	import { connectSSE, disconnectSSE } from '$lib/sse';
	import { getIncidentSummary, getMe } from '$lib/api';
	import type { Snippet } from 'svelte';
	import type { User } from '$lib/types';

	interface Props {
		children: Snippet;
	}

	let { children }: Props = $props();

	let mobileOpen = $state(false);
	let incidentCount = $state(0);
	let user: User | null = $state(null);
	let authChecked = $state(false);

	const navItems = [
		{
			href: '/',
			label: 'Dashboard',
			icon: `<path d="M3 12l2-2m0 0l7-7 7 7M5 10v10a1 1 0 001 1h3m10-11l2 2m-2-2v10a1 1 0 01-1 1h-3m-6 0a1 1 0 001-1v-4a1 1 0 011-1h2a1 1 0 011 1v4a1 1 0 001 1m-6 0h6" />`
		},
		{
			href: '/runs',
			label: 'Runs',
			icon: `<path d="M13 10V3L4 14h7v7l9-11h-7z" />`
		},
		{
			href: '/metrics',
			label: 'Metrics',
			icon: `<path d="M9 19v-6a2 2 0 00-2-2H5a2 2 0 00-2 2v6a2 2 0 002 2h2a2 2 0 002-2zm0 0V9a2 2 0 012-2h2a2 2 0 012 2v10m-6 0a2 2 0 002 2h2a2 2 0 002-2m0 0V5a2 2 0 012-2h2a2 2 0 012 2v14a2 2 0 01-2 2h-2a2 2 0 01-2-2z" />`
		},
		{
			href: '/experiments',
			label: 'Experiments',
			icon: `<path d="M19.428 15.428a2 2 0 00-1.022-.547l-2.387-.477a6 6 0 00-3.86.517l-.318.158a6 6 0 01-3.86.517L6.05 15.21a2 2 0 00-1.806.547M8 4h8l-1 1v5.172a2 2 0 00.586 1.414l5 5c1.26 1.26.367 3.414-1.415 3.414H4.828c-1.782 0-2.674-2.154-1.414-3.414l5-5A2 2 0 009 10.172V5L8 4z" />`
		},
		{
			href: '/incidents',
			label: 'Incidents',
			icon: `<path d="M12 9v2m0 4h.01m-6.938 4h13.856c1.54 0 2.502-1.667 1.732-3L13.732 4c-.77-1.333-2.694-1.333-3.464 0L3.34 16c-.77 1.333.192 3 1.732 3z" />`
		},
		{
			href: '/slo',
			label: 'SLO',
			icon: `<path d="M9 12l2 2 4-4m5.618-4.016A11.955 11.955 0 0112 2.944a11.955 11.955 0 01-8.618 3.04A12.02 12.02 0 003 9c0 5.591 3.824 10.29 9 11.622 5.176-1.332 9-6.03 9-11.622 0-1.042-.133-2.052-.382-3.016z" />`
		},
		{
			href: '/settings',
			label: 'Settings',
			icon: `<path d="M10.325 4.317c.426-1.756 2.924-1.756 3.35 0a1.724 1.724 0 002.573 1.066c1.543-.94 3.31.826 2.37 2.37a1.724 1.724 0 001.066 2.573c1.756.426 1.756 2.924 0 3.35a1.724 1.724 0 00-1.066 2.573c.94 1.543-.826 3.31-2.37 2.37a1.724 1.724 0 00-2.573 1.066c-.426 1.756-2.924 1.756-3.35 0a1.724 1.724 0 00-2.573-1.066c-1.543.94-3.31-.826-2.37-2.37a1.724 1.724 0 00-1.066-2.573c-1.756-.426-1.756-2.924 0-3.35a1.724 1.724 0 001.066-2.573c-.94-1.543.826-3.31 2.37-2.37.996.608 2.296.07 2.572-1.065z" /><circle cx="12" cy="12" r="3" />`
		}
	];

	function isActive(href: string, pathname: string): boolean {
		if (href === '/') return pathname === '/';
		return pathname.startsWith(href);
	}

	function handleLogout() {
		localStorage.removeItem('qualito_token');
		localStorage.removeItem('qualito_user');
		user = null;
		goto('/login');
	}

	onMount(async () => {
		const pathname = window.location.pathname;

		// Skip auth check on public pages
		const publicPaths = ['/login', '/reset-password', '/verify-email'];
		if (publicPaths.some(p => pathname.startsWith(p))) {
			authChecked = true;
			return;
		}

		const token = localStorage.getItem('qualito_token');
		if (!token) {
			authChecked = true;
			goto('/login');
			return;
		}

		try {
			user = await getMe();
			localStorage.setItem('qualito_user', JSON.stringify(user));
		} catch {
			localStorage.removeItem('qualito_token');
			localStorage.removeItem('qualito_user');
			authChecked = true;
			goto('/login');
			return;
		}

		authChecked = true;
		connectSSE();
		getIncidentSummary()
			.then((s) => { incidentCount = s.total; })
			.catch(() => {});
	});

	onDestroy(() => {
		disconnectSSE();
	});
</script>

{#if !authChecked}
	<!-- Loading -->
	<div class="flex items-center justify-center h-screen" style="background: var(--bg);">
		<span class="font-mono text-xl" style="color: var(--accent)">DQI</span>
	</div>
{:else if ['/login', '/reset-password', '/verify-email'].some(p => $page.url.pathname.startsWith(p))}
	{@render children()}
{:else}
	<div class="flex h-screen overflow-hidden">
		<!-- Mobile hamburger -->
		<button
			class="fixed top-3 left-3 z-50 p-2 rounded-lg md:hidden"
			style="background: var(--bg-card); border: 1px solid var(--border); color: var(--text-secondary);"
			onclick={() => mobileOpen = !mobileOpen}
			aria-label="Toggle navigation"
		>
			<svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round">
				{#if mobileOpen}
					<path d="M18 6 6 18M6 6l12 12" />
				{:else}
					<path d="M4 6h16M4 12h16M4 18h16" />
				{/if}
			</svg>
		</button>

		<!-- Sidebar -->
		<aside
			class="flex-shrink-0 flex flex-col h-full overflow-y-auto transition-transform duration-200 z-40
				{mobileOpen ? 'translate-x-0' : '-translate-x-full'} md:translate-x-0"
			style="width: 220px; background: var(--bg-subtle); border-right: 1px solid var(--border);
				position: fixed; md:position: static;"
		>
			<!-- Logo -->
			<div class="px-5 py-5">
				<a href="/" class="flex items-center gap-2">
					<span class="font-mono text-xl font-semibold" style="color: var(--accent)">Qualito</span>
				</a>
			</div>

			<!-- Nav -->
			<nav class="flex-1 px-3 space-y-0.5">
				{#each navItems as item}
					{@const active = isActive(item.href, $page.url.pathname)}
					<a
						href={item.href}
						class="flex items-center gap-3 px-3 py-2 rounded-lg text-[13px] font-medium relative transition-all duration-150"
						style="color: {active ? 'var(--text)' : 'var(--text-muted)'};
							background: {active ? 'var(--accent-subtle)' : 'transparent'};"
						onclick={() => mobileOpen = false}
					>
						{#if active}
							<div class="absolute left-0 top-1/2 -translate-y-1/2 w-[3px] h-5 rounded-r" style="background: var(--accent)"></div>
						{/if}
						<svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"
							style="color: {active ? 'var(--accent)' : 'var(--text-faint)'}; flex-shrink: 0;">
							{@html item.icon}
						</svg>
						<span>{item.label}</span>
						{#if item.label === 'Incidents' && incidentCount > 0}
							<span class="ml-auto badge badge-error text-[10px] px-1.5">{incidentCount}</span>
						{/if}
					</a>
				{/each}
			</nav>

			<!-- Footer with user -->
			<div class="px-4 py-4 space-y-3" style="border-top: 1px solid var(--border)">
				{#if user}
					<div class="flex items-center gap-2">
						<div
							class="w-7 h-7 rounded-full flex items-center justify-center text-[10px] font-semibold flex-shrink-0"
							style="background: var(--accent-subtle); color: var(--accent);"
						>
							{(user.name || user.email)[0].toUpperCase()}
						</div>
						<div class="min-w-0 flex-1">
							<div class="text-[12px] font-medium truncate" style="color: var(--text-secondary)">
								{user.email}
							</div>
						</div>
					</div>
					<button
						class="btn btn-ghost text-xs w-full justify-center"
						onclick={handleLogout}
					>
						Sign Out
					</button>
				{/if}
				<div class="text-center">
					<span class="text-[11px] font-mono" style="color: var(--text-faint)">Qualito v0.1.2</span>
				</div>
			</div>
		</aside>

		<!-- Main content -->
		<main class="flex-1 overflow-y-auto md:ml-0" style="margin-left: 0;">
			<div class="md:hidden h-14"></div>
			<div class="p-6 max-w-7xl mx-auto">
				{@render children()}
			</div>
		</main>
	</div>
{/if}

<style>
	@media (min-width: 768px) {
		aside {
			position: static !important;
			transform: none !important;
		}
	}
</style>
