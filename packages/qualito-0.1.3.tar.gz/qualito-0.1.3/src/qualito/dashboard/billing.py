"""Stripe billing integration for the Qualito dashboard.

Handles checkout sessions, webhooks, subscription status, and cancellation.
Gracefully degrades when the stripe package is not installed.
"""

import logging
import os

from qualito.core.db import processed_events_table, users_table

try:
    import stripe
except ImportError:
    stripe = None  # type: ignore[assignment]

logger = logging.getLogger(__name__)

# ---------------------------------------------------------------------------
# Config
# ---------------------------------------------------------------------------

STRIPE_SECRET_KEY = os.environ.get("STRIPE_SECRET_KEY", "")
STRIPE_WEBHOOK_SECRET = os.environ.get("STRIPE_WEBHOOK_SECRET", "")
STRIPE_PRO_PRICE_ID = os.environ.get("STRIPE_PRO_PRICE_ID", "")

# Success/cancel redirect URLs (dashboard frontend)
DASHBOARD_URL = os.environ.get("DASHBOARD_URL", "http://localhost:5173")


def _stripe_available() -> bool:
    """Check whether stripe is importable and configured."""
    return stripe is not None and bool(STRIPE_SECRET_KEY)


def _init_stripe() -> None:
    """Set the stripe API key."""
    if stripe is not None:
        stripe.api_key = STRIPE_SECRET_KEY


# ---------------------------------------------------------------------------
# Checkout
# ---------------------------------------------------------------------------


def create_checkout_session(user_id: int, email: str, plan: str = "pro") -> str:
    """Create a Stripe Checkout session and return the checkout URL.

    Raises RuntimeError if stripe is unavailable.
    """
    if not _stripe_available():
        raise RuntimeError("Stripe billing is not configured")

    _init_stripe()

    session = stripe.checkout.Session.create(
        mode="subscription",
        customer_email=email,
        line_items=[{"price": STRIPE_PRO_PRICE_ID, "quantity": 1}],
        allow_promotion_codes=True,
        success_url=f"{DASHBOARD_URL}/settings?billing=success",
        cancel_url=f"{DASHBOARD_URL}/settings?billing=cancelled",
        metadata={"user_id": str(user_id), "plan": plan},
    )
    return session.url  # type: ignore[return-value]


# ---------------------------------------------------------------------------
# Customer Portal
# ---------------------------------------------------------------------------


def create_portal_session(stripe_customer_id: str) -> str:
    """Create a Stripe Customer Portal session and return the URL.

    Raises RuntimeError if stripe is unavailable.
    """
    if not _stripe_available():
        raise RuntimeError("Stripe billing is not configured")

    _init_stripe()

    session = stripe.billing_portal.Session.create(
        customer=stripe_customer_id,
        return_url=f"{DASHBOARD_URL}/settings",
    )
    return session.url


# ---------------------------------------------------------------------------
# Webhooks
# ---------------------------------------------------------------------------


def handle_webhook(payload: bytes, sig_header: str) -> dict:
    """Verify and handle a Stripe webhook event.

    Returns a dict with the event type and action taken.
    Raises ValueError on signature verification failure.
    """
    if not _stripe_available():
        raise RuntimeError("Stripe billing is not configured")

    _init_stripe()

    event = stripe.Webhook.construct_event(payload, sig_header, STRIPE_WEBHOOK_SECRET)

    event_type: str = event["type"]
    event_id: str = event["id"]
    result: dict = {"event_type": event_type, "action": "ignored"}

    # Idempotency check — skip already-processed events
    from qualito.dashboard.api import _get_conn

    conn = _get_conn()
    try:
        from sqlalchemy import select

        row = conn.execute(
            select(processed_events_table.c.event_id)
            .where(processed_events_table.c.event_id == event_id)
        ).fetchone()
        if row:
            conn.close()
            return {"event_type": event_type, "action": "already_processed"}

        # Route by event type
        if event_type == "checkout.session.completed":
            try:
                session = event["data"]["object"]
                _activate_plan(session)
                result["action"] = "plan_activated"
                # Send subscription confirmed email
                try:
                    from qualito.dashboard.email import send_subscription_confirmed_email
                    customer_email = session.get("customer_email") or session.get("customer_details", {}).get("email")
                    if customer_email:
                        send_subscription_confirmed_email(customer_email)
                except Exception:
                    logger.warning("Failed to send subscription confirmed email")
            except Exception:
                logger.exception("Error handling checkout.session.completed")

        elif event_type == "customer.subscription.created":
            try:
                subscription = event["data"]["object"]
                _handle_subscription_created(subscription)
                result["action"] = "subscription_created"
            except Exception:
                logger.exception("Error handling customer.subscription.created")

        elif event_type == "customer.subscription.updated":
            try:
                subscription = event["data"]["object"]
                _handle_subscription_updated(subscription)
                result["action"] = "subscription_updated"
            except Exception:
                logger.exception("Error handling customer.subscription.updated")

        elif event_type == "customer.subscription.deleted":
            try:
                subscription = event["data"]["object"]
                _deactivate_plan(subscription)
                # Send cancellation email
                try:
                    from qualito.dashboard.email import send_subscription_cancelled_email
                    customer_id = subscription.get("customer")
                    if customer_id:
                        _init_stripe()
                        customer = stripe.Customer.retrieve(customer_id)
                        if customer and customer.get("email"):
                            send_subscription_cancelled_email(customer["email"])
                except Exception:
                    logger.warning("Failed to send subscription cancelled email")
                result["action"] = "plan_deactivated"
            except Exception:
                logger.exception("Error handling customer.subscription.deleted")

        elif event_type == "invoice.payment_succeeded":
            try:
                invoice = event["data"]["object"]
                logger.info(
                    "Payment succeeded for customer %s, invoice %s",
                    invoice.get("customer"),
                    invoice.get("id"),
                )
                result["action"] = "payment_logged"
            except Exception:
                logger.exception("Error handling invoice.payment_succeeded")

        elif event_type == "invoice.payment_failed":
            try:
                invoice = event["data"]["object"]
                logger.warning(
                    "Payment failed for customer %s, invoice %s",
                    invoice.get("customer"),
                    invoice.get("id"),
                )
                result["action"] = "failure_logged"
                # Send payment failed email
                try:
                    from qualito.dashboard.email import send_payment_failed_email
                    customer_id = invoice.get("customer")
                    customer_email = invoice.get("customer_email")
                    if customer_id and customer_email:
                        portal_url = f"{DASHBOARD_URL}/settings"
                        try:
                            portal_url = create_portal_session(customer_id)
                        except Exception:
                            pass  # Fall back to settings page
                        send_payment_failed_email(customer_email, portal_url)
                except Exception:
                    logger.warning("Failed to send payment failed email")
            except Exception:
                logger.exception("Error handling invoice.payment_failed")

        elif event_type == "customer.subscription.trial_will_end":
            try:
                subscription = event["data"]["object"]
                logger.info(
                    "Trial ending for customer %s, subscription %s",
                    subscription.get("customer"),
                    subscription.get("id"),
                )
                result["action"] = "trial_end_logged"
            except Exception:
                logger.exception("Error handling customer.subscription.trial_will_end")

        # Mark event as processed
        conn.execute(
            processed_events_table.insert().values(
                event_id=event_id,
                event_type=event_type,
            )
        )
        conn.commit()
    finally:
        conn.close()

    return result


# ---------------------------------------------------------------------------
# Webhook handlers
# ---------------------------------------------------------------------------


def _activate_plan(session: dict) -> None:
    """Activate the user's plan after successful checkout."""
    from qualito.dashboard.api import _get_conn

    user_id = session.get("metadata", {}).get("user_id")
    customer_id = session.get("customer")
    plan = session.get("metadata", {}).get("plan", "pro")
    subscription_id = session.get("subscription")

    if not user_id:
        return

    u = users_table
    conn = _get_conn()
    try:
        values: dict = {"plan": plan, "stripe_customer_id": customer_id}
        if subscription_id:
            values["stripe_subscription_id"] = subscription_id
        conn.execute(
            u.update()
            .where(u.c.id == int(user_id))
            .values(**values)
        )
        conn.commit()
    finally:
        conn.close()


def _handle_subscription_created(subscription: dict) -> None:
    """Store subscription ID and period dates on user record."""
    from qualito.dashboard.api import _get_conn

    customer_id = subscription.get("customer")
    subscription_id = subscription.get("id")
    if not customer_id:
        return

    u = users_table
    conn = _get_conn()
    try:
        conn.execute(
            u.update()
            .where(u.c.stripe_customer_id == customer_id)
            .values(stripe_subscription_id=subscription_id)
        )
        conn.commit()
    finally:
        conn.close()


def _handle_subscription_updated(subscription: dict) -> None:
    """Sync plan status and cancel_at_period_end from Stripe."""
    from qualito.dashboard.api import _get_conn

    customer_id = subscription.get("customer")
    status = subscription.get("status")
    if not customer_id:
        return

    u = users_table
    conn = _get_conn()
    try:
        # If subscription is active/trialing, ensure plan is pro
        # If it's canceled/past_due, keep current plan (will be deactivated on delete)
        if status in ("active", "trialing"):
            conn.execute(
                u.update()
                .where(u.c.stripe_customer_id == customer_id)
                .values(plan="pro")
            )
        conn.commit()
    finally:
        conn.close()


def _deactivate_plan(subscription: dict) -> None:
    """Downgrade user to free when subscription is cancelled."""
    from qualito.dashboard.api import _get_conn

    customer_id = subscription.get("customer")
    if not customer_id:
        return

    u = users_table
    conn = _get_conn()
    try:
        conn.execute(
            u.update()
            .where(u.c.stripe_customer_id == customer_id)
            .values(plan="free", stripe_subscription_id=None)
        )
        conn.commit()
    finally:
        conn.close()


# ---------------------------------------------------------------------------
# Subscription queries
# ---------------------------------------------------------------------------


def get_subscription_status(stripe_customer_id: str) -> dict:
    """Query Stripe for the customer's current subscription status."""
    if not _stripe_available():
        raise RuntimeError("Stripe billing is not configured")

    _init_stripe()

    subscriptions = stripe.Subscription.list(customer=stripe_customer_id, limit=1)

    if not subscriptions.data:
        return {"status": "none", "plan": "free"}

    sub = subscriptions.data[0]
    return {
        "status": sub.status,
        "plan": "pro",
        "current_period_end": sub.current_period_end,
        "cancel_at_period_end": sub.cancel_at_period_end,
        "subscription_id": sub.id,
    }


def cancel_subscription(stripe_customer_id: str) -> bool:
    """Cancel the customer's subscription at period end.

    Returns True if cancellation was successful.
    """
    if not _stripe_available():
        raise RuntimeError("Stripe billing is not configured")

    _init_stripe()

    subscriptions = stripe.Subscription.list(customer=stripe_customer_id, limit=1)

    if not subscriptions.data:
        return False

    sub = subscriptions.data[0]
    stripe.Subscription.modify(sub.id, cancel_at_period_end=True)
    return True
