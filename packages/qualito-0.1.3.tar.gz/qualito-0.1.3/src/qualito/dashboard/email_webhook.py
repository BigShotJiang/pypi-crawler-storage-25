"""Resend email webhook endpoint for delivery tracking.

Receives webhook events from Resend (via svix) and updates
email_logs with delivery status. Gracefully degrades when svix
is not installed or RESEND_WEBHOOK_SECRET is not set.
"""

import json
import logging
import os
from datetime import datetime, timezone

from fastapi import APIRouter, HTTPException, Request

from qualito.core.db import email_logs_table, get_sa_connection

try:
    from svix.webhooks import Webhook, WebhookVerificationError
except ImportError:
    Webhook = None  # type: ignore[assignment, misc]
    WebhookVerificationError = None  # type: ignore[assignment, misc]

logger = logging.getLogger(__name__)

router = APIRouter(prefix="/api/email", tags=["email"])

RESEND_WEBHOOK_SECRET = os.environ.get("RESEND_WEBHOOK_SECRET", "")

# Resend event types we handle
_DELIVERY_STATUS_MAP = {
    "email.sent": "sent",
    "email.delivered": "delivered",
    "email.bounced": "bounced",
    "email.complained": "complained",
    "email.delivery_delayed": "delayed",
}


def _verify_signature(payload: bytes, headers: dict[str, str]) -> dict:
    """Verify svix webhook signature and return parsed payload.

    Raises HTTPException(400) on invalid signature.
    """
    if Webhook is None:
        logger.warning("svix not installed — skipping webhook signature verification")
        return json.loads(payload)

    if not RESEND_WEBHOOK_SECRET:
        logger.warning("RESEND_WEBHOOK_SECRET not set — skipping webhook signature verification")
        return json.loads(payload)

    wh = Webhook(RESEND_WEBHOOK_SECRET)
    try:
        return wh.verify(payload, headers)
    except WebhookVerificationError:
        raise HTTPException(status_code=400, detail="Invalid webhook signature")


def _update_delivery_status(provider_id: str, status: str) -> bool:
    """Update the delivery status of an email log entry by provider_id.

    Returns True if a row was updated.
    """
    conn = get_sa_connection()
    try:
        result = conn.execute(
            email_logs_table.update()
            .where(email_logs_table.c.provider_id == provider_id)
            .values(
                delivery_status=status,
                delivery_updated_at=datetime.now(timezone.utc).isoformat(),
            )
        )
        conn.commit()
        return result.rowcount > 0
    finally:
        conn.close()


@router.post("/webhook")
async def email_webhook(request: Request):
    """Resend webhook endpoint. Validates signature via svix, updates delivery status."""
    payload = await request.body()

    # Extract svix headers for verification
    svix_headers = {
        "svix-id": request.headers.get("svix-id", ""),
        "svix-timestamp": request.headers.get("svix-timestamp", ""),
        "svix-signature": request.headers.get("svix-signature", ""),
    }

    data = _verify_signature(payload, svix_headers)

    event_type = data.get("type", "")
    delivery_status = _DELIVERY_STATUS_MAP.get(event_type)

    if not delivery_status:
        # Unknown event type — acknowledge but don't process
        logger.debug(f"Ignoring unhandled Resend webhook event: {event_type}")
        return {"status": "ignored", "event": event_type}

    email_data = data.get("data", {})
    email_id = email_data.get("email_id", "")

    if not email_id:
        logger.warning(f"Resend webhook missing email_id in data: {event_type}")
        return {"status": "ignored", "reason": "no_email_id"}

    updated = _update_delivery_status(email_id, delivery_status)

    if updated:
        logger.info(f"Email delivery status updated: {email_id} -> {delivery_status}")
    else:
        logger.warning(f"No email_log found for provider_id={email_id} (event={event_type})")

    return {"status": "ok", "delivery_status": delivery_status, "matched": updated}
