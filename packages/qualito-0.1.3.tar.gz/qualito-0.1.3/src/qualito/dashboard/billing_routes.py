"""Billing API routes for the Qualito dashboard."""

from fastapi import APIRouter, Depends, HTTPException, Request

from qualito.dashboard.auth import get_current_user
from qualito.dashboard.billing import (
    _stripe_available,
    cancel_subscription,
    create_checkout_session,
    create_portal_session,
    get_subscription_status,
    handle_webhook,
)

router = APIRouter(prefix="/api/billing", tags=["billing"])


def _require_stripe() -> None:
    """Raise 503 if Stripe is not configured."""
    if not _stripe_available():
        raise HTTPException(status_code=503, detail="Billing is not available")


# ---------------------------------------------------------------------------
# POST /api/billing/checkout
# ---------------------------------------------------------------------------


@router.post("/checkout")
def checkout(user: dict = Depends(get_current_user)):
    """Create a Stripe Checkout session and return the URL."""
    _require_stripe()

    if user.get("plan") == "pro":
        raise HTTPException(status_code=400, detail="Already on Pro plan")

    try:
        url = create_checkout_session(user["id"], user["email"])
        return {"url": url}
    except RuntimeError as e:
        raise HTTPException(status_code=503, detail=str(e))


# ---------------------------------------------------------------------------
# POST /api/billing/webhook
# ---------------------------------------------------------------------------


@router.post("/webhook")
async def webhook(request: Request):
    """Stripe webhook endpoint. Validated by signature, no auth required."""
    _require_stripe()

    payload = await request.body()
    sig_header = request.headers.get("stripe-signature", "")

    try:
        result = handle_webhook(payload, sig_header)
        return result
    except ValueError:
        raise HTTPException(status_code=400, detail="Invalid webhook signature")


# ---------------------------------------------------------------------------
# GET /api/billing/status
# ---------------------------------------------------------------------------


@router.get("/status")
def billing_status(user: dict = Depends(get_current_user)):
    """Return the user's subscription status."""
    _require_stripe()

    customer_id = user.get("stripe_customer_id")
    if not customer_id:
        return {"status": "none", "plan": user.get("plan", "free")}

    try:
        return get_subscription_status(customer_id)
    except RuntimeError as e:
        raise HTTPException(status_code=503, detail=str(e))


# ---------------------------------------------------------------------------
# POST /api/billing/cancel
# ---------------------------------------------------------------------------


@router.post("/cancel")
def cancel(user: dict = Depends(get_current_user)):
    """Cancel the user's subscription at period end."""
    _require_stripe()

    customer_id = user.get("stripe_customer_id")
    if not customer_id:
        raise HTTPException(status_code=400, detail="No active subscription")

    try:
        success = cancel_subscription(customer_id)
        if not success:
            raise HTTPException(status_code=400, detail="No active subscription to cancel")
        return {"cancelled": True}
    except RuntimeError as e:
        raise HTTPException(status_code=503, detail=str(e))


# ---------------------------------------------------------------------------
# POST /api/billing/portal
# ---------------------------------------------------------------------------


@router.post("/portal")
def portal(user: dict = Depends(get_current_user)):
    """Create a Stripe Customer Portal session and return the URL."""
    _require_stripe()

    customer_id = user.get("stripe_customer_id")
    if not customer_id:
        raise HTTPException(status_code=400, detail="No billing account")

    try:
        url = create_portal_session(customer_id)
        return {"url": url}
    except RuntimeError as e:
        raise HTTPException(status_code=503, detail=str(e))
