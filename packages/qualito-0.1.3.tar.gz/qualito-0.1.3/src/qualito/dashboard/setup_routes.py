"""Setup API routes for SSE-driven onboarding."""

import asyncio
import json
import logging
import secrets
from datetime import datetime, timezone, timedelta

from fastapi import APIRouter, HTTPException, Query
from fastapi.responses import StreamingResponse
from pydantic import BaseModel
from sqlalchemy import select

from qualito.core.db import setup_tokens_table
from qualito.dashboard.api import _get_conn
from qualito.dashboard.auth import create_api_key

logger = logging.getLogger(__name__)

router = APIRouter(prefix="/api/setup", tags=["setup"])

# ---------------------------------------------------------------------------
# In-memory fallback (used when DB write fails)
# ---------------------------------------------------------------------------

_setup_tokens: dict[str, dict] = {}

_SETUP_TOKEN_TTL = timedelta(minutes=15)


def _is_expired(token_data: dict) -> bool:
    created = datetime.fromisoformat(token_data["created_at"])
    if created.tzinfo is None:
        created = created.replace(tzinfo=timezone.utc)
    return datetime.now(timezone.utc) - created > _SETUP_TOKEN_TTL


# ---------------------------------------------------------------------------
# DB helpers
# ---------------------------------------------------------------------------


def store_setup_token(token: str, user_id: int, email: str) -> None:
    """Store a setup token in PostgreSQL, falling back to in-memory dict."""
    now = datetime.now(timezone.utc)
    expires = now + _SETUP_TOKEN_TTL
    token_data = {
        "user_id": user_id,
        "email": email,
        "created_at": now.isoformat(),
        "progress": [],
    }

    try:
        conn = _get_conn()
        try:
            conn.execute(
                setup_tokens_table.insert().values(
                    token=token,
                    user_id=user_id,
                    email=email,
                    created_at=now.isoformat(),
                    expires_at=expires.isoformat(),
                    used=False,
                )
            )
            conn.commit()
        finally:
            conn.close()
    except Exception:
        logger.warning("Failed to store setup token in DB, using in-memory fallback")

    # Always store in-memory too (for progress tracking and SSE within this process)
    _setup_tokens[token] = token_data


def _load_token_from_db(token: str) -> dict | None:
    """Load a setup token from DB. Returns dict or None."""
    try:
        conn = _get_conn()
        try:
            row = conn.execute(
                select(setup_tokens_table).where(
                    setup_tokens_table.c.token == token
                )
            ).mappings().fetchone()
            if not row:
                return None
            if row["used"]:
                return None
            # Check expiry
            expires = datetime.fromisoformat(row["expires_at"])
            if expires.tzinfo is None:
                expires = expires.replace(tzinfo=timezone.utc)
            if datetime.now(timezone.utc) > expires:
                return None
            return {
                "user_id": row["user_id"],
                "email": row["email"],
                "created_at": row["created_at"],
                "progress": [],
            }
        finally:
            conn.close()
    except Exception:
        return None


def _get_token_data(token: str) -> dict | None:
    """Get token data from in-memory dict or DB, checking expiry."""
    # Check in-memory first (has progress state)
    data = _setup_tokens.get(token)
    if data and not _is_expired(data):
        return data

    # Fall back to DB
    db_data = _load_token_from_db(token)
    if db_data:
        # Cache in memory for progress tracking
        _setup_tokens[token] = db_data
        return db_data

    return None


def _mark_token_used(token: str) -> None:
    """Mark a setup token as used in the DB."""
    try:
        conn = _get_conn()
        try:
            conn.execute(
                setup_tokens_table.update()
                .where(setup_tokens_table.c.token == token)
                .values(used=True)
            )
            conn.commit()
        finally:
            conn.close()
    except Exception:
        logger.warning("Failed to mark setup token as used in DB")


# ---------------------------------------------------------------------------
# Request models
# ---------------------------------------------------------------------------


class ValidateRequest(BaseModel):
    token: str


class ProgressRequest(BaseModel):
    token: str
    step: str
    detail: str = ""


# ---------------------------------------------------------------------------
# Routes
# ---------------------------------------------------------------------------


@router.post("/validate")
def validate_token(body: ValidateRequest):
    """Validate a setup token and generate an API key."""
    token_data = _get_token_data(body.token)
    if not token_data:
        raise HTTPException(status_code=400, detail="Invalid or expired setup token")

    # Generate API key if not already created
    if not token_data.get("api_key"):
        conn = _get_conn()
        try:
            plaintext, _record = create_api_key(conn, token_data["user_id"], name="Setup (auto)")
            token_data["api_key"] = plaintext
        finally:
            conn.close()

    return {
        "api_key": token_data["api_key"],
        "user": {"id": token_data["user_id"], "email": token_data["email"]},
    }


@router.post("/progress")
def update_progress(body: ProgressRequest):
    """Update progress for a setup token."""
    token_data = _get_token_data(body.token)
    if not token_data:
        raise HTTPException(status_code=400, detail="Invalid or expired setup token")

    valid_steps = ("connected", "importing", "scoring", "syncing", "complete")
    if body.step not in valid_steps:
        raise HTTPException(status_code=400, detail=f"Invalid step. Must be one of: {valid_steps}")

    event = {
        "step": body.step,
        "detail": body.detail,
        "timestamp": datetime.now(timezone.utc).isoformat(),
    }
    token_data["progress"].append(event)

    # Mark as used on complete
    if body.step == "complete":
        _mark_token_used(body.token)

    return {"ok": True}


@router.get("/events")
async def setup_events(token: str = Query(...)):
    """SSE endpoint for setup progress events."""
    token_data = _get_token_data(token)
    if not token_data:
        raise HTTPException(status_code=400, detail="Invalid or expired setup token")

    async def event_stream():
        last_index = 0
        start = datetime.now(timezone.utc)

        while True:
            # Check TTL
            if datetime.now(timezone.utc) - start > _SETUP_TOKEN_TTL:
                yield f"data: {json.dumps({'step': 'timeout', 'detail': 'Setup token expired', 'timestamp': datetime.now(timezone.utc).isoformat()})}\n\n"
                break

            progress = token_data.get("progress", [])
            # Send any new events
            while last_index < len(progress):
                event = progress[last_index]
                yield f"data: {json.dumps(event)}\n\n"
                last_index += 1

                # Close stream on complete
                if event["step"] == "complete":
                    return

            await asyncio.sleep(1)

    return StreamingResponse(
        event_stream(),
        media_type="text/event-stream",
        headers={
            "Cache-Control": "no-cache",
            "Connection": "keep-alive",
            "X-Accel-Buffering": "no",
        },
    )
