"""Authentication module for the Qualito dashboard.

Provides JWT tokens, API keys, password hashing, and FastAPI dependencies.
"""

import hashlib
import os
import secrets
from datetime import datetime, timedelta, timezone

import bcrypt
from fastapi import HTTPException, Request
from jose import JWTError, jwt
from sqlalchemy import select
from sqlalchemy.exc import IntegrityError

from qualito.core.db import api_keys_table, users_table

# ---------------------------------------------------------------------------
# JWT config
# ---------------------------------------------------------------------------

JWT_SECRET = os.environ.get("QUALITO_JWT_SECRET") or secrets.token_hex(32)
JWT_ALGORITHM = "HS256"
JWT_EXPIRY_DAYS = 30


# ---------------------------------------------------------------------------
# Database tables
# ---------------------------------------------------------------------------


def init_auth_tables(conn) -> None:
    """No-op — tables are created by init_db() via metadata.create_all().

    Kept for backward compatibility with callers that still invoke it.
    """
    pass


# ---------------------------------------------------------------------------
# Auth service functions
# ---------------------------------------------------------------------------


def create_user(conn, email: str, password: str, name: str | None = None,
                role: str = "user") -> dict:
    """Create a new user with hashed password. Returns user dict (no password_hash)."""
    password_hash = bcrypt.hashpw(password.encode(), bcrypt.gensalt()).decode()
    try:
        result = conn.execute(
            users_table.insert().values(
                email=email.lower().strip(),
                password_hash=password_hash,
                name=name,
                role=role,
            )
        )
        conn.commit()
    except IntegrityError:
        conn.rollback()
        raise HTTPException(status_code=409, detail="Email already registered")

    return {
        "id": result.inserted_primary_key[0],
        "email": email.lower().strip(),
        "name": name,
        "plan": "free",
        "role": role,
        "email_verified": False,
        "suspended": False,
    }


def verify_password(plain: str, hashed: str) -> bool:
    """Verify a plaintext password against a bcrypt hash."""
    return bcrypt.checkpw(plain.encode(), hashed.encode())


def create_jwt(user_id: int, email: str, expiry_days: int = JWT_EXPIRY_DAYS) -> str:
    """Create a JWT token with user claims."""
    payload = {
        "sub": str(user_id),
        "email": email,
        "exp": datetime.now(timezone.utc) + timedelta(days=expiry_days),
        "iat": datetime.now(timezone.utc),
    }
    return jwt.encode(payload, JWT_SECRET, algorithm=JWT_ALGORITHM)


def decode_jwt(token: str) -> dict:
    """Decode and validate a JWT token. Raises HTTPException on failure."""
    try:
        payload = jwt.decode(token, JWT_SECRET, algorithms=[JWT_ALGORITHM])
        return payload
    except JWTError:
        raise HTTPException(status_code=401, detail="Invalid or expired token")


def create_api_key(conn, user_id: int, name: str | None = None) -> tuple[str, dict]:
    """Generate an API key. Returns (plaintext_key, api_key_record).

    The plaintext key is shown once — only the SHA256 hash is stored.
    """
    raw = secrets.token_hex(24)
    plaintext_key = f"qualito_{raw}"
    key_hash = hashlib.sha256(plaintext_key.encode()).hexdigest()
    key_prefix = plaintext_key[:12]

    result = conn.execute(
        api_keys_table.insert().values(
            user_id=user_id,
            key_hash=key_hash,
            key_prefix=key_prefix,
            name=name,
        )
    )
    conn.commit()

    record = {
        "id": result.inserted_primary_key[0],
        "user_id": user_id,
        "key_prefix": key_prefix,
        "name": name,
        "created_at": datetime.now(timezone.utc).isoformat(),
        "revoked_at": None,
    }
    return plaintext_key, record


def verify_api_key(conn, key: str) -> dict | None:
    """Look up an API key by its hash, update last_used_at, return the user."""
    key_hash = hashlib.sha256(key.encode()).hexdigest()
    ak = api_keys_table
    u = users_table

    row = conn.execute(
        select(
            ak.c.id.label("key_id"),
            ak.c.user_id,
            ak.c.revoked_at,
            u.c.id,
            u.c.email,
            u.c.name,
            u.c.plan,
            u.c.email_verified,
            u.c.role,
            u.c.suspended,
        )
        .select_from(ak.join(u, u.c.id == ak.c.user_id))
        .where(ak.c.key_hash == key_hash)
    ).mappings().fetchone()

    if not row or row["revoked_at"] is not None:
        return None

    # Update last_used_at
    conn.execute(
        ak.update()
        .where(ak.c.id == row["key_id"])
        .values(last_used_at=datetime.now(timezone.utc).isoformat())
    )
    conn.commit()

    return {
        "id": row["user_id"],
        "email": row["email"],
        "name": row["name"],
        "plan": row["plan"],
        "email_verified": bool(row["email_verified"]),
        "role": row["role"] or "user",
        "suspended": bool(row["suspended"]),
    }


# ---------------------------------------------------------------------------
# FastAPI dependencies
# ---------------------------------------------------------------------------


def _extract_token(request: Request) -> str | None:
    """Extract bearer token or API key from Authorization header."""
    auth = request.headers.get("Authorization")
    if not auth:
        return None
    if auth.startswith("Bearer "):
        return auth[7:]
    return auth


def _get_user_from_token(conn, token: str) -> dict | None:
    """Try JWT first, then API key."""
    # Try JWT
    try:
        payload = jwt.decode(token, JWT_SECRET, algorithms=[JWT_ALGORITHM])
        user_id = int(payload["sub"])
        row = conn.execute(
            select(
                users_table.c.id,
                users_table.c.email,
                users_table.c.name,
                users_table.c.plan,
                users_table.c.email_verified,
                users_table.c.role,
                users_table.c.suspended,
            ).where(users_table.c.id == user_id)
        ).mappings().fetchone()
        if row:
            return {
                "id": row["id"],
                "email": row["email"],
                "name": row["name"],
                "plan": row["plan"],
                "email_verified": bool(row["email_verified"]),
                "role": row["role"] or "user",
                "suspended": bool(row["suspended"]),
            }
    except (JWTError, KeyError, ValueError):
        pass

    # Try API key
    if token.startswith("qualito_"):
        return verify_api_key(conn, token)

    return None


def get_current_user(request: Request) -> dict:
    """FastAPI dependency: require authenticated user.

    Checks Authorization header for JWT or API key.
    Raises 401 if neither is valid.
    """
    from qualito.dashboard.api import _get_conn

    token = _extract_token(request)
    if not token:
        raise HTTPException(status_code=401, detail="Authentication required")

    conn = _get_conn()
    try:
        user = _get_user_from_token(conn, token)
    finally:
        conn.close()

    if not user:
        raise HTTPException(status_code=401, detail="Invalid credentials")
    if user.get("suspended"):
        raise HTTPException(status_code=403, detail="Account suspended")
    return user


def get_admin_user(request: Request) -> dict:
    """FastAPI dependency: require authenticated admin user.

    Raises 403 if the user is not an admin.
    """
    user = get_current_user(request)
    if user.get("role") != "admin":
        raise HTTPException(status_code=403, detail="Admin access required")
    return user


def user_has_plan(user: dict, plan: str = "pro") -> bool:
    """Check whether the user's plan matches the required plan.

    'pro' plan also satisfies any lower tier check.
    """
    user_plan = (user.get("plan") or "free").lower()
    if plan == "free":
        return True
    return user_plan == plan


def optional_user(request: Request) -> dict | None:
    """FastAPI dependency: optional user — returns None instead of 401."""
    from qualito.dashboard.api import _get_conn

    token = _extract_token(request)
    if not token:
        return None

    conn = _get_conn()
    try:
        return _get_user_from_token(conn, token)
    finally:
        conn.close()
