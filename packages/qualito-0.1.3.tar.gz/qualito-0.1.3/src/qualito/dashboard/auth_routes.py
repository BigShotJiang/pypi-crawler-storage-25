"""Auth API routes for the Qualito dashboard."""

import logging
import secrets
from datetime import datetime, timezone

import bcrypt
from fastapi import APIRouter, Depends, HTTPException, Request
from pydantic import BaseModel, EmailStr
from sqlalchemy import select

from qualito.core.db import (
    api_keys_table,
    consent_table,
    email_logs_table,
    evaluations_table,
    file_activity_table,
    runs_table,
    setup_tokens_table,
    tool_calls_table,
    users_table,
)
from qualito.dashboard.api import _get_conn
from qualito.dashboard.auth import (
    create_api_key,
    create_jwt,
    create_user,
    get_current_user,
    verify_password,
)
from qualito.dashboard.email import (
    decode_reset_token,
    decode_verification_token,
    send_password_reset_email,
    send_verification_email,
    send_welcome_email,
)

logger = logging.getLogger(__name__)
from qualito.dashboard.setup_routes import store_setup_token

try:
    from slowapi import Limiter
    from slowapi.util import get_remote_address

    limiter = Limiter(key_func=get_remote_address)
    _has_limiter = True
except ImportError:
    limiter = None  # type: ignore[assignment]
    _has_limiter = False

router = APIRouter(prefix="/api/auth", tags=["auth"])


def _rate_limit(limit_str: str):
    """Apply rate limiting if slowapi is available, otherwise no-op."""
    if _has_limiter:
        return limiter.limit(limit_str)
    return lambda f: f


# ---------------------------------------------------------------------------
# Request / Response models
# ---------------------------------------------------------------------------


class RegisterRequest(BaseModel):
    email: EmailStr
    password: str
    name: str | None = None
    tos_accepted: bool = False
    privacy_accepted: bool = False
    marketing_opt_in: bool = False


class LoginRequest(BaseModel):
    email: EmailStr
    password: str


class ApiKeyCreateRequest(BaseModel):
    name: str | None = None


class ForgotPasswordRequest(BaseModel):
    email: EmailStr


class ResetPasswordRequest(BaseModel):
    token: str
    password: str


class VerifyEmailRequest(BaseModel):
    token: str


# ---------------------------------------------------------------------------
# In-memory CLI token store (short-lived, per-process)
# ---------------------------------------------------------------------------

_cli_tokens: dict[str, dict] = {}


# ---------------------------------------------------------------------------
# Routes
# ---------------------------------------------------------------------------


@router.post("/register")
@_rate_limit("5/minute")
def register(request: Request, body: RegisterRequest):
    """Register a new user. Returns user + JWT token."""
    if len(body.password) < 8:
        raise HTTPException(status_code=400, detail="Password must be at least 8 characters")

    conn = _get_conn()
    try:
        user = create_user(conn, body.email, body.password, body.name)
        token = create_jwt(user["id"], user["email"])

        # Record consent
        conn.execute(
            consent_table.insert().values(
                user_id=user["id"],
                tos_accepted=body.tos_accepted,
                privacy_accepted=body.privacy_accepted,
                marketing_opt_in=body.marketing_opt_in,
                tos_version="v1.0",
                privacy_version="v1.0",
            )
        )
        # If marketing opt-in, update user record
        if body.marketing_opt_in:
            conn.execute(
                users_table.update()
                .where(users_table.c.id == user["id"])
                .values(
                    marketing_consent=True,
                    marketing_consent_date=datetime.now(timezone.utc).isoformat(),
                )
            )
        conn.commit()

        # Generate setup token for SSE-driven onboarding (stored in DB + in-memory)
        setup_token = "st_setup_" + secrets.token_urlsafe(24)
        store_setup_token(setup_token, user["id"], body.email)

        # Auto-create an API key for MCP-first onboarding
        plaintext_api_key, _api_key_record = create_api_key(
            conn, user["id"], name="Auto (registration)"
        )

        # Send welcome email (non-blocking — registration succeeds even if email fails)
        try:
            send_welcome_email(body.email, body.name or "", user["id"])
        except Exception:
            logger.warning("Failed to send welcome email to %s", body.email)

        return {
            "user": user,
            "token": token,
            "setup_token": setup_token,
            "api_key": plaintext_api_key,
        }
    finally:
        conn.close()


@router.post("/login")
@_rate_limit("5/minute")
def login(request: Request, body: LoginRequest):
    """Authenticate and return user + JWT token."""
    conn = _get_conn()
    try:
        u = users_table
        row = conn.execute(
            select(
                u.c.id, u.c.email, u.c.password_hash,
                u.c.name, u.c.plan, u.c.email_verified,
                u.c.role, u.c.suspended,
            ).where(u.c.email == body.email.lower().strip())
        ).mappings().fetchone()

        if not row or not verify_password(body.password, row["password_hash"]):
            raise HTTPException(status_code=401, detail="Invalid email or password")

        if bool(row["suspended"]):
            raise HTTPException(status_code=403, detail="Account suspended")

        user = {
            "id": row["id"],
            "email": row["email"],
            "name": row["name"],
            "plan": row["plan"],
            "email_verified": bool(row["email_verified"]),
            "role": row["role"] or "user",
            "suspended": False,
        }
        token = create_jwt(user["id"], user["email"])
        return {"user": user, "token": token}
    finally:
        conn.close()


@router.get("/me")
def me(user: dict = Depends(get_current_user)):
    """Return the currently authenticated user."""
    return user


@router.post("/api-keys")
def create_key(body: ApiKeyCreateRequest, user: dict = Depends(get_current_user)):
    """Create a new API key. The plaintext key is returned once."""
    conn = _get_conn()
    try:
        plaintext, record = create_api_key(conn, user["id"], body.name)
        return {"key": plaintext, "api_key": record}
    finally:
        conn.close()


@router.get("/api-keys")
def list_keys(user: dict = Depends(get_current_user)):
    """List the user's API keys (no plaintext)."""
    conn = _get_conn()
    try:
        ak = api_keys_table
        rows = conn.execute(
            select(
                ak.c.id, ak.c.key_prefix, ak.c.name,
                ak.c.last_used_at, ak.c.created_at, ak.c.revoked_at,
            )
            .where(ak.c.user_id == user["id"])
            .order_by(ak.c.created_at.desc())
        ).mappings().fetchall()
        return {"api_keys": [dict(row) for row in rows]}
    finally:
        conn.close()


@router.delete("/api-keys/{key_id}")
def revoke_key(key_id: int, user: dict = Depends(get_current_user)):
    """Revoke an API key."""
    conn = _get_conn()
    try:
        ak = api_keys_table
        row = conn.execute(
            select(ak.c.id, ak.c.user_id).where(ak.c.id == key_id)
        ).mappings().fetchone()
        if not row:
            raise HTTPException(status_code=404, detail="API key not found")
        if row["user_id"] != user["id"]:
            raise HTTPException(status_code=403, detail="Not your API key")

        conn.execute(
            ak.update()
            .where(ak.c.id == key_id)
            .values(revoked_at=datetime.now(timezone.utc).isoformat())
        )
        conn.commit()
        return {"revoked": True}
    finally:
        conn.close()


@router.post("/cli-token")
def cli_token(user: dict = Depends(get_current_user)):
    """Generate a short-lived token for CLI callback (5 min expiry)."""
    state = secrets.token_urlsafe(32)
    token = create_jwt(user["id"], user["email"], expiry_days=0)
    # Store with 5 min TTL (in-memory — survives only within the process)
    _cli_tokens[state] = {
        "user_id": user["id"],
        "email": user["email"],
        "created_at": datetime.now(timezone.utc).isoformat(),
    }
    return {"state": state, "token": token}


@router.get("/cli-callback")
def cli_callback(state: str):
    """Validate CLI state param and return an API key."""
    info = _cli_tokens.pop(state, None)
    if not info:
        raise HTTPException(status_code=400, detail="Invalid or expired state token")

    conn = _get_conn()
    try:
        plaintext, record = create_api_key(conn, info["user_id"], name="CLI (auto)")
        return {"key": plaintext, "api_key": record}
    finally:
        conn.close()


def _delete_user_runs(conn, user_id: int) -> int:
    """Delete all runs and their children for a user. Returns count of deleted runs."""
    run_rows = conn.execute(
        select(runs_table.c.id).where(runs_table.c.user_id == user_id)
    ).fetchall()
    run_ids = [r[0] for r in run_rows]

    if run_ids:
        conn.execute(evaluations_table.delete().where(evaluations_table.c.run_id.in_(run_ids)))
        conn.execute(tool_calls_table.delete().where(tool_calls_table.c.run_id.in_(run_ids)))
        conn.execute(file_activity_table.delete().where(file_activity_table.c.run_id.in_(run_ids)))
        conn.execute(runs_table.delete().where(runs_table.c.user_id == user_id))

    return len(run_ids)


def cascade_delete_user(conn, user_id: int, user_email: str) -> None:
    """Delete a user and all FK-dependent records (children before parent)."""
    _delete_user_runs(conn, user_id)
    conn.execute(
        email_logs_table.delete().where(
            email_logs_table.c.recipient_email == user_email
        )
    )
    conn.execute(
        consent_table.delete().where(consent_table.c.user_id == user_id)
    )
    conn.execute(
        setup_tokens_table.delete().where(
            setup_tokens_table.c.user_id == user_id
        )
    )
    conn.execute(
        api_keys_table.delete().where(api_keys_table.c.user_id == user_id)
    )
    conn.execute(
        users_table.delete().where(users_table.c.id == user_id)
    )
    conn.commit()


@router.delete("/account")
def delete_account(user: dict = Depends(get_current_user)):
    """Delete the current user's account and all associated data."""
    from qualito.dashboard.mcp_oauth import revoke_tokens_for_user
    conn = _get_conn()
    try:
        cascade_delete_user(conn, user["id"], user["email"])
        revoke_tokens_for_user(user["id"])
        return {"deleted": True}
    finally:
        conn.close()


@router.delete("/data")
def delete_all_data(user: dict = Depends(get_current_user)):
    """Delete all synced data, API keys, setup tokens, and OAuth tokens but keep the account."""
    from qualito.dashboard.mcp_oauth import revoke_tokens_for_user
    conn = _get_conn()
    try:
        deleted_count = _delete_user_runs(conn, user["id"])
        conn.execute(
            api_keys_table.delete().where(api_keys_table.c.user_id == user["id"])
        )
        conn.execute(
            setup_tokens_table.delete().where(setup_tokens_table.c.user_id == user["id"])
        )
        conn.commit()
        revoke_tokens_for_user(user["id"])
        return {"deleted_runs": deleted_count}
    finally:
        conn.close()


# ---------------------------------------------------------------------------
# Email verification + password reset routes
# ---------------------------------------------------------------------------


@router.post("/verify-email")
def verify_email(body: VerifyEmailRequest):
    """Validate a verification token and set email_verified=True."""
    try:
        payload = decode_verification_token(body.token)
    except ValueError as e:
        raise HTTPException(status_code=400, detail=str(e))

    user_id = int(payload["sub"])
    conn = _get_conn()
    try:
        conn.execute(
            users_table.update()
            .where(users_table.c.id == user_id)
            .values(email_verified=True)
        )
        conn.commit()
        return {"verified": True}
    finally:
        conn.close()


@router.post("/resend-verification")
@_rate_limit("3/minute")
def resend_verification(request: Request, user: dict = Depends(get_current_user)):
    """Resend the verification email for the current user."""
    if user.get("email_verified"):
        return {"message": "Email already verified"}

    try:
        send_verification_email(user["email"], user["id"])
    except Exception:
        logger.warning("Failed to resend verification email to %s", user["email"])

    return {"message": "Verification email sent"}


@router.post("/forgot-password")
@_rate_limit("3/minute")
def forgot_password(request: Request, body: ForgotPasswordRequest):
    """Send a password reset email. Always returns 200 to avoid leaking email existence."""
    conn = _get_conn()
    try:
        row = conn.execute(
            select(users_table.c.id, users_table.c.email)
            .where(users_table.c.email == body.email.lower().strip())
        ).mappings().fetchone()

        if row:
            try:
                send_password_reset_email(row["email"], row["id"])
            except Exception:
                logger.warning("Failed to send reset email to %s", body.email)
    finally:
        conn.close()

    # Always return the same response — don't leak whether the email exists
    return {"message": "If an account exists with that email, a reset link has been sent."}


@router.post("/reset-password")
@_rate_limit("3/minute")
def reset_password(request: Request, body: ResetPasswordRequest):
    """Reset password using a valid reset token."""
    try:
        payload = decode_reset_token(body.token)
    except ValueError as e:
        raise HTTPException(status_code=400, detail=str(e))

    if len(body.password) < 8:
        raise HTTPException(status_code=400, detail="Password must be at least 8 characters")

    user_id = int(payload["sub"])
    password_hash = bcrypt.hashpw(body.password.encode(), bcrypt.gensalt()).decode()

    conn = _get_conn()
    try:
        conn.execute(
            users_table.update()
            .where(users_table.c.id == user_id)
            .values(password_hash=password_hash)
        )
        conn.commit()
        return {"reset": True}
    finally:
        conn.close()
