"""Email service module for the Qualito dashboard.

Sends transactional emails via Resend: welcome, verification, password reset,
subscription confirmed, payment failed. Gracefully degrades when Resend is
not installed or not configured.
"""

import logging
import os
import secrets
from datetime import datetime, timedelta, timezone

from jose import JWTError, jwt

from qualito.core.db import email_logs_table

try:
    import resend
except ImportError:
    resend = None  # type: ignore[assignment]

logger = logging.getLogger(__name__)

# ---------------------------------------------------------------------------
# Config
# ---------------------------------------------------------------------------

RESEND_QUALITO_API_KEY = os.environ.get("RESEND_QUALITO_API_KEY", "")
FROM_EMAIL = "Qualito <noreply@qualito.ai>"
FRONTEND_URL = os.environ.get("DASHBOARD_URL", "http://localhost:5173")
API_URL = os.environ.get("API_URL", "http://localhost:8000")
EMAIL_VERIFY_SECRET = os.environ.get("EMAIL_VERIFY_SECRET", "") or secrets.token_hex(32)
PASSWORD_RESET_SECRET = os.environ.get("PASSWORD_RESET_SECRET", "") or secrets.token_hex(32)


# ---------------------------------------------------------------------------
# Resend integration
# ---------------------------------------------------------------------------


def _email_available() -> bool:
    """Check whether resend is importable and configured."""
    return resend is not None and bool(RESEND_QUALITO_API_KEY)


def send_email(to: str, subject: str, html: str) -> dict | None:
    """Send an email via Resend. Returns the result dict or None on failure."""
    if not _email_available():
        logger.warning("Email not sent (resend not installed or RESEND_QUALITO_API_KEY not set)")
        return None

    resend.api_key = RESEND_QUALITO_API_KEY
    try:
        result = resend.Emails.send({
            "from": FROM_EMAIL,
            "to": [to],
            "subject": subject,
            "html": html,
        })
        _log_email("SENT", to, subject, provider_id=result.get("id") if isinstance(result, dict) else None)
        return result
    except Exception as e:
        logger.error(f"Email send failed: {e}")
        _log_email("FAILED", to, subject, error=str(e))
        return None


# ---------------------------------------------------------------------------
# Email logging
# ---------------------------------------------------------------------------


def _log_email(status: str, recipient: str, subject: str,
               provider_id: str | None = None, error: str | None = None) -> None:
    """Log an email send attempt to the email_logs table."""
    try:
        from qualito.dashboard.api import _get_conn

        conn = _get_conn()
        try:
            conn.execute(
                email_logs_table.insert().values(
                    email_type=_subject_to_type(subject),
                    recipient_email=recipient,
                    status=status,
                    provider_id=provider_id,
                    error_message=error,
                )
            )
            conn.commit()
        finally:
            conn.close()
    except Exception as e:
        logger.error(f"Email log insert failed: {e}")


def _subject_to_type(subject: str) -> str:
    """Map email subject to a type for logging."""
    s = subject.lower()
    if "welcome" in s:
        return "WELCOME"
    if "verify" in s or "confirm your" in s:
        return "VERIFY"
    if "reset" in s:
        return "RESET"
    if "subscription" in s or "upgraded" in s:
        return "SUBSCRIPTION_CONFIRMED"
    if "payment" in s or "failed" in s:
        return "PAYMENT_FAILED"
    return "OTHER"


# ---------------------------------------------------------------------------
# Token functions
# ---------------------------------------------------------------------------


def create_verification_token(user_id: int, email: str) -> str:
    """Create a JWT token for email verification (24h expiry)."""
    payload = {
        "sub": str(user_id),
        "email": email,
        "type": "email_verify",
        "exp": datetime.now(timezone.utc) + timedelta(hours=24),
        "iat": datetime.now(timezone.utc),
    }
    return jwt.encode(payload, EMAIL_VERIFY_SECRET, algorithm="HS256")


def create_reset_token(user_id: int, email: str) -> str:
    """Create a JWT token for password reset (1h expiry)."""
    payload = {
        "sub": str(user_id),
        "email": email,
        "type": "password_reset",
        "exp": datetime.now(timezone.utc) + timedelta(hours=1),
        "iat": datetime.now(timezone.utc),
    }
    return jwt.encode(payload, PASSWORD_RESET_SECRET, algorithm="HS256")


def decode_verification_token(token: str) -> dict:
    """Decode a verification token. Raises ValueError on invalid/expired."""
    try:
        payload = jwt.decode(token, EMAIL_VERIFY_SECRET, algorithms=["HS256"])
        if payload.get("type") != "email_verify":
            raise ValueError("Invalid token type")
        return payload
    except JWTError as e:
        raise ValueError(f"Invalid or expired verification token: {e}")


def decode_reset_token(token: str) -> dict:
    """Decode a password reset token. Raises ValueError on invalid/expired."""
    try:
        payload = jwt.decode(token, PASSWORD_RESET_SECRET, algorithms=["HS256"])
        if payload.get("type") != "password_reset":
            raise ValueError("Invalid token type")
        return payload
    except JWTError as e:
        raise ValueError(f"Invalid or expired reset token: {e}")


# ---------------------------------------------------------------------------
# Email templates (simple inline CSS)
# ---------------------------------------------------------------------------

_STYLE = """
    font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
    max-width: 480px; margin: 0 auto; padding: 32px 24px;
    background: #0f172a; color: #e2e8f0;
"""

_BTN_STYLE = """
    display: inline-block; padding: 12px 24px; border-radius: 8px;
    background: #14b8a6; color: #fff; text-decoration: none;
    font-weight: 600; font-size: 14px;
"""


def welcome_email_html(name: str, verify_url: str) -> str:
    """Welcome email with verification link."""
    display_name = name or "there"
    return f"""<div style="{_STYLE}">
    <h2 style="color: #14b8a6; margin-bottom: 16px;">Welcome to Qualito</h2>
    <p>Hi {display_name},</p>
    <p>Thanks for signing up! Qualito helps you measure and improve your AI-assisted development quality.</p>
    <p>Please verify your email to unlock all features:</p>
    <p style="text-align: center; margin: 24px 0;">
        <a href="{verify_url}" style="{_BTN_STYLE}">Verify Email</a>
    </p>
    <p style="font-size: 12px; color: #94a3b8;">This link expires in 24 hours. If you didn't create this account, ignore this email.</p>
</div>"""


def verification_email_html(verify_url: str) -> str:
    """Standalone verification email (for resend)."""
    return f"""<div style="{_STYLE}">
    <h2 style="color: #14b8a6; margin-bottom: 16px;">Verify Your Email</h2>
    <p>Click the button below to verify your email address:</p>
    <p style="text-align: center; margin: 24px 0;">
        <a href="{verify_url}" style="{_BTN_STYLE}">Verify Email</a>
    </p>
    <p style="font-size: 12px; color: #94a3b8;">This link expires in 24 hours.</p>
</div>"""


def password_reset_email_html(reset_url: str) -> str:
    """Password reset email."""
    return f"""<div style="{_STYLE}">
    <h2 style="color: #14b8a6; margin-bottom: 16px;">Reset Your Password</h2>
    <p>We received a request to reset your password. Click below to set a new one:</p>
    <p style="text-align: center; margin: 24px 0;">
        <a href="{reset_url}" style="{_BTN_STYLE}">Reset Password</a>
    </p>
    <p style="font-size: 12px; color: #94a3b8;">This link expires in 1 hour. If you didn't request this, ignore this email.</p>
</div>"""


def subscription_confirmed_email_html() -> str:
    """Subscription confirmed email."""
    return f"""<div style="{_STYLE}">
    <h2 style="color: #14b8a6; margin-bottom: 16px;">Welcome to Qualito Pro!</h2>
    <p>Your Pro subscription is now active. You have access to:</p>
    <ul style="color: #cbd5e1; line-height: 1.8;">
        <li>Unlimited runs and workspaces</li>
        <li>Advanced analytics and benchmarks</li>
        <li>Priority support</li>
    </ul>
    <p style="text-align: center; margin: 24px 0;">
        <a href="{FRONTEND_URL}/settings" style="{_BTN_STYLE}">Go to Dashboard</a>
    </p>
</div>"""


def payment_failed_email_html(portal_url: str) -> str:
    """Payment failed email with portal link."""
    return f"""<div style="{_STYLE}">
    <h2 style="color: #f59e0b; margin-bottom: 16px;">Payment Failed</h2>
    <p>We couldn't process your latest payment. Please update your payment method to keep your Pro access:</p>
    <p style="text-align: center; margin: 24px 0;">
        <a href="{portal_url}" style="{_BTN_STYLE}">Update Payment Method</a>
    </p>
    <p style="font-size: 12px; color: #94a3b8;">If you've already updated your payment method, you can ignore this email.</p>
</div>"""


def subscription_cancelled_email_html() -> str:
    """Subscription cancelled email."""
    return f"""<div style="{_STYLE}">
    <h2 style="color: #94a3b8; margin-bottom: 16px;">Your Pro Plan Has Ended</h2>
    <p>Your Qualito Pro subscription has been cancelled. You're now on the Free plan.</p>
    <p style="margin-top: 16px;"><strong>What changes:</strong></p>
    <ul style="padding-left: 20px; margin-top: 8px;">
        <li>Run limit: 100 per month</li>
        <li>Workspace limit: 1</li>
        <li>History: 7 days</li>
    </ul>
    <p>Your data is safe — you can upgrade again anytime to unlock unlimited access.</p>
    <p style="text-align: center; margin: 24px 0;">
        <a href="{FRONTEND_URL}/settings" style="{_BTN_STYLE}">Resubscribe</a>
    </p>
</div>"""


# ---------------------------------------------------------------------------
# High-level send functions
# ---------------------------------------------------------------------------


def send_welcome_email(email: str, name: str, user_id: int) -> None:
    """Send welcome email with verification link."""
    token = create_verification_token(user_id, email)
    verify_url = f"{FRONTEND_URL}/verify-email?token={token}"
    html = welcome_email_html(name, verify_url)
    send_email(email, "Welcome to Qualito — Verify Your Email", html)


def send_verification_email(email: str, user_id: int) -> None:
    """Send standalone verification email."""
    token = create_verification_token(user_id, email)
    verify_url = f"{FRONTEND_URL}/verify-email?token={token}"
    html = verification_email_html(verify_url)
    send_email(email, "Verify Your Email — Qualito", html)


def send_password_reset_email(email: str, user_id: int) -> None:
    """Send password reset email."""
    token = create_reset_token(user_id, email)
    reset_url = f"{FRONTEND_URL}/reset-password?token={token}"
    html = password_reset_email_html(reset_url)
    send_email(email, "Reset Your Password — Qualito", html)


def send_subscription_confirmed_email(email: str) -> None:
    """Send subscription confirmed email."""
    html = subscription_confirmed_email_html()
    send_email(email, "You're Upgraded — Qualito Pro", html)


def send_payment_failed_email(email: str, portal_url: str) -> None:
    """Send payment failed email with portal link."""
    html = payment_failed_email_html(portal_url)
    send_email(email, "Payment Failed — Qualito", html)


def send_subscription_cancelled_email(email: str) -> None:
    """Send subscription cancelled email."""
    html = subscription_cancelled_email_html()
    send_email(email, "Your Pro Plan Has Ended — Qualito", html)
