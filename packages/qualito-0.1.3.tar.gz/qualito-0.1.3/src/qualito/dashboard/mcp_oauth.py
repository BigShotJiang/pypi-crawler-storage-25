"""OAuth 2.0 provider for Qualito remote MCP server.

Implements MCP SDK's OAuthAuthorizationServerProvider protocol.
Authorization flow: user enters their Qualito API key in a browser form,
we validate it and issue an OAuth access token for MCP requests.

Storage is in-memory — Railway redeploys clear all tokens (clients must re-auth).
"""

import hashlib
import logging
import secrets
import time
from dataclasses import dataclass, field

from mcp.server.auth.provider import (
    AccessToken,
    AuthorizationParams,
    OAuthClientInformationFull,
    OAuthToken,
)

logger = logging.getLogger("qualito-mcp-oauth")

# ---------------------------------------------------------------------------
# In-memory storage
# ---------------------------------------------------------------------------

_clients: dict[str, OAuthClientInformationFull] = {}
_auth_codes: dict[str, "AuthCodeData"] = {}
_access_tokens: dict[str, "TokenData"] = {}
_pending_auths: dict[str, "PendingAuth"] = {}


@dataclass
class AuthCodeData:
    code: str
    client_id: str
    redirect_uri: str
    redirect_uri_provided_explicitly: bool
    code_challenge: str
    user_id: int
    scopes: list[str] = field(default_factory=list)
    created_at: float = field(default_factory=time.time)
    expires_at: float = field(default_factory=lambda: time.time() + 600)


@dataclass
class TokenData:
    token: str
    client_id: str
    user_id: int
    scopes: list[str] = field(default_factory=list)
    created_at: float = field(default_factory=time.time)


@dataclass
class PendingAuth:
    client_id: str
    redirect_uri: str
    redirect_uri_provided_explicitly: bool
    code_challenge: str
    state: str | None
    scopes: list[str] | None
    created_at: float = field(default_factory=time.time)


def get_user_id_for_token(token: str) -> int | None:
    """Get user_id associated with an access token."""
    data = _access_tokens.get(token)
    return data.user_id if data else None


def revoke_tokens_for_user(user_id: int) -> int:
    """Revoke all OAuth access tokens for a user. Returns count revoked."""
    to_remove = [k for k, v in _access_tokens.items() if v.user_id == user_id]
    for k in to_remove:
        _access_tokens.pop(k, None)
    return len(to_remove)


# ---------------------------------------------------------------------------
# OAuth provider
# ---------------------------------------------------------------------------


class QualitOAuthProvider:
    """OAuth provider that authenticates via Qualito API keys."""

    async def get_client(self, client_id: str) -> OAuthClientInformationFull | None:
        return _clients.get(client_id)

    async def register_client(self, client_info: OAuthClientInformationFull) -> None:
        _clients[client_info.client_id] = client_info
        logger.info("Registered OAuth client: %s", client_info.client_id)

    async def authorize(
        self, client: OAuthClientInformationFull, params: AuthorizationParams
    ) -> str:
        state = params.state or secrets.token_urlsafe(16)
        _pending_auths[state] = PendingAuth(
            client_id=client.client_id,
            redirect_uri=str(params.redirect_uri),
            redirect_uri_provided_explicitly=params.redirect_uri_provided_explicitly,
            code_challenge=params.code_challenge,
            state=params.state,
            scopes=params.scopes,
        )
        return f"/mcp-authorize?state={state}"

    async def load_authorization_code(
        self, client: OAuthClientInformationFull, authorization_code: str
    ) -> AuthCodeData | None:
        data = _auth_codes.get(authorization_code)
        if not data:
            return None
        if data.client_id != client.client_id:
            return None
        if time.time() > data.expires_at:
            _auth_codes.pop(authorization_code, None)
            return None
        return data

    async def exchange_authorization_code(
        self, client: OAuthClientInformationFull, authorization_code: AuthCodeData
    ) -> OAuthToken:
        access_token = secrets.token_urlsafe(32)
        _access_tokens[access_token] = TokenData(
            token=access_token,
            client_id=client.client_id,
            user_id=authorization_code.user_id,
            scopes=authorization_code.scopes,
        )
        _auth_codes.pop(authorization_code.code, None)
        logger.info("Issued access token for user %d", authorization_code.user_id)
        return OAuthToken(
            access_token=access_token,
            token_type="Bearer",
            scope=" ".join(authorization_code.scopes) if authorization_code.scopes else None,
        )

    async def load_refresh_token(
        self, client: OAuthClientInformationFull, refresh_token: str
    ) -> None:
        return None

    async def exchange_refresh_token(
        self,
        client: OAuthClientInformationFull,
        refresh_token: None,
        scopes: list[str],
    ) -> OAuthToken:
        raise NotImplementedError("Refresh tokens not supported")

    async def load_access_token(self, token: str) -> AccessToken | None:
        data = _access_tokens.get(token)
        if not data:
            return None
        return AccessToken(
            token=data.token,
            client_id=data.client_id,
            scopes=data.scopes,
            expires_at=None,
        )

    async def revoke_token(self, token: TokenData | None) -> None:
        if token and hasattr(token, "token"):
            _access_tokens.pop(token.token, None)


# ---------------------------------------------------------------------------
# Token verifier (used by MCP SDK auth middleware)
# ---------------------------------------------------------------------------


class QualitTokenVerifier:
    """Verifies OAuth access tokens for MCP requests."""

    async def verify_token(self, token: str) -> AccessToken | None:
        data = _access_tokens.get(token)
        if not data:
            return None
        return AccessToken(
            token=data.token,
            client_id=data.client_id,
            scopes=data.scopes,
            expires_at=None,
        )


# ---------------------------------------------------------------------------
# Authorization form HTML
# ---------------------------------------------------------------------------

_AUTH_FORM_HTML = """<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Qualito — Authorize MCP</title>
    <style>
        * { margin: 0; padding: 0; box-sizing: border-box; }
        body {
            font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', sans-serif;
            background: #0a0a0a; color: #e5e5e5;
            display: flex; justify-content: center; align-items: center;
            min-height: 100vh; padding: 20px;
        }
        .card {
            background: #171717; border: 1px solid #262626;
            border-radius: 12px; padding: 32px; max-width: 420px; width: 100%;
        }
        h1 { font-size: 20px; font-weight: 600; margin-bottom: 8px; }
        .subtitle { color: #a3a3a3; font-size: 14px; margin-bottom: 24px; }
        label { display: block; font-size: 13px; color: #a3a3a3; margin-bottom: 6px; }
        input[type="text"] {
            width: 100%; padding: 10px 12px; background: #0a0a0a;
            border: 1px solid #333; border-radius: 6px; color: #e5e5e5;
            font-family: 'SF Mono', monospace; font-size: 14px;
        }
        input[type="text"]:focus { outline: none; border-color: #3b82f6; }
        .help { font-size: 12px; color: #737373; margin-top: 6px; }
        button {
            width: 100%; margin-top: 20px; padding: 10px;
            background: #3b82f6; color: white; border: none;
            border-radius: 6px; font-size: 14px; font-weight: 500;
            cursor: pointer; transition: background 0.2s;
        }
        button:hover { background: #2563eb; }
        .error { color: #ef4444; font-size: 13px; margin-top: 12px; display: none; }
    </style>
</head>
<body>
    <div class="card">
        <h1>Authorize Qualito MCP</h1>
        <p class="subtitle">Enter your API key to connect Claude Code to Qualito.</p>
        <form method="POST" action="/mcp-authorize-callback">
            <input type="hidden" name="state" value="{state}">
            <label for="api_key">API Key</label>
            <input type="text" id="api_key" name="api_key"
                   placeholder="qualito_..." autocomplete="off" required>
            <p class="help">Find your API key at
                <a href="https://app.qualito.ai/settings" style="color: #3b82f6;">
                app.qualito.ai/settings</a></p>
            <button type="submit">Authorize</button>
            {error_html}
        </form>
    </div>
</body>
</html>"""

_AUTH_ERROR_HTML = '<p class="error" style="display:block">{message}</p>'
