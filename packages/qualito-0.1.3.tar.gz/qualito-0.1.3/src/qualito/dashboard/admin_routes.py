"""Admin API routes for the Qualito dashboard.

Provides user management endpoints for admin users: list, create, delete,
suspend, activate, and role management.
"""

from fastapi import APIRouter, Depends, HTTPException
from pydantic import BaseModel, EmailStr
from sqlalchemy import select

from qualito.core.db import users_table
from qualito.dashboard.api import _get_conn
from qualito.dashboard.auth import create_user, get_admin_user
from qualito.dashboard.auth_routes import cascade_delete_user

router = APIRouter(prefix="/api/admin", tags=["admin"])


# ---------------------------------------------------------------------------
# Request models
# ---------------------------------------------------------------------------


class AdminCreateUserRequest(BaseModel):
    email: EmailStr
    password: str
    name: str | None = None
    role: str = "user"


class RoleUpdateRequest(BaseModel):
    role: str


# ---------------------------------------------------------------------------
# Routes
# ---------------------------------------------------------------------------


@router.get("/users")
def list_users(admin: dict = Depends(get_admin_user)):
    """List all users."""
    conn = _get_conn()
    try:
        rows = conn.execute(
            select(
                users_table.c.id,
                users_table.c.email,
                users_table.c.name,
                users_table.c.plan,
                users_table.c.role,
                users_table.c.suspended,
                users_table.c.email_verified,
                users_table.c.created_at,
            ).order_by(users_table.c.id)
        ).mappings().fetchall()
        return {"users": [dict(row) for row in rows]}
    finally:
        conn.close()


@router.post("/users")
def admin_create_user(body: AdminCreateUserRequest,
                      admin: dict = Depends(get_admin_user)):
    """Create a new user as admin."""
    if len(body.password) < 8:
        raise HTTPException(status_code=400, detail="Password must be at least 8 characters")
    if body.role not in ("user", "admin"):
        raise HTTPException(status_code=400, detail="Role must be 'user' or 'admin'")

    conn = _get_conn()
    try:
        user = create_user(conn, body.email, body.password, body.name, body.role)
        return {"user": user}
    finally:
        conn.close()


@router.delete("/users/{user_id}")
def admin_delete_user(user_id: int, admin: dict = Depends(get_admin_user)):
    """Delete a user account and all associated data."""
    if user_id == admin["id"]:
        raise HTTPException(status_code=400, detail="Cannot delete your own account")

    conn = _get_conn()
    try:
        row = conn.execute(
            select(users_table.c.id, users_table.c.email)
            .where(users_table.c.id == user_id)
        ).mappings().fetchone()
        if not row:
            raise HTTPException(status_code=404, detail="User not found")

        cascade_delete_user(conn, user_id, row["email"])
        return {"deleted": True}
    finally:
        conn.close()


@router.post("/users/{user_id}/suspend")
def suspend_user(user_id: int, admin: dict = Depends(get_admin_user)):
    """Suspend a user account."""
    conn = _get_conn()
    try:
        row = conn.execute(
            select(users_table.c.id).where(users_table.c.id == user_id)
        ).mappings().fetchone()
        if not row:
            raise HTTPException(status_code=404, detail="User not found")

        conn.execute(
            users_table.update()
            .where(users_table.c.id == user_id)
            .values(suspended=True)
        )
        conn.commit()
        return {"suspended": True}
    finally:
        conn.close()


@router.post("/users/{user_id}/activate")
def activate_user(user_id: int, admin: dict = Depends(get_admin_user)):
    """Activate a suspended user account."""
    conn = _get_conn()
    try:
        row = conn.execute(
            select(users_table.c.id).where(users_table.c.id == user_id)
        ).mappings().fetchone()
        if not row:
            raise HTTPException(status_code=404, detail="User not found")

        conn.execute(
            users_table.update()
            .where(users_table.c.id == user_id)
            .values(suspended=False)
        )
        conn.commit()
        return {"activated": True}
    finally:
        conn.close()


@router.patch("/users/{user_id}/role")
def change_role(user_id: int, body: RoleUpdateRequest,
                admin: dict = Depends(get_admin_user)):
    """Change a user's role. Admin cannot change their own role."""
    if user_id == admin["id"]:
        raise HTTPException(status_code=400, detail="Cannot change your own role")
    if body.role not in ("user", "admin"):
        raise HTTPException(status_code=400, detail="Role must be 'user' or 'admin'")

    conn = _get_conn()
    try:
        row = conn.execute(
            select(users_table.c.id).where(users_table.c.id == user_id)
        ).mappings().fetchone()
        if not row:
            raise HTTPException(status_code=404, detail="User not found")

        conn.execute(
            users_table.update()
            .where(users_table.c.id == user_id)
            .values(role=body.role)
        )
        conn.commit()
        return {"role": body.role}
    finally:
        conn.close()
