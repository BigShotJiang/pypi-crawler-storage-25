"""Tests for Phase 3 — Dashboard SA Core migration.

Tests auth.py, api.py, auth_routes.py, and billing.py using SA connections.
Uses TestClient against the FastAPI app with monkeypatched _get_conn.
"""

import json

import pytest
from sqlalchemy import select

from qualito.core.db import (
    api_keys_table,
    consent_table,
    email_logs_table,
    evaluations_table,
    experiments_table,
    benchmark_suites_table,
    experiment_comparisons_table,
    get_engine,
    incidents_table,
    init_db,
    runs_table,
    setup_tokens_table,
    users_table,
)


# ---------------------------------------------------------------------------
# Fixtures
# ---------------------------------------------------------------------------


@pytest.fixture
def sa_engine(tmp_path):
    """Fresh SA engine with all tables."""
    db_file = str(tmp_path / "test.db")
    engine = get_engine(db_file)
    init_db(engine)
    return engine


@pytest.fixture
def sa_conn(sa_engine):
    """SA connection from the engine."""
    conn = sa_engine.connect()
    yield conn
    conn.close()


# ---------------------------------------------------------------------------
# auth.py — create_user, create_api_key, verify_api_key, _get_user_from_token
# ---------------------------------------------------------------------------


class TestCreateUser:
    def test_creates_user(self, sa_conn):
        from qualito.dashboard.auth import create_user

        user = create_user(sa_conn, "test@example.com", "password123", "Test User")
        assert user["email"] == "test@example.com"
        assert user["name"] == "Test User"
        assert user["plan"] == "free"
        assert isinstance(user["id"], int)

        # Verify in DB
        row = sa_conn.execute(
            select(users_table).where(users_table.c.email == "test@example.com")
        ).mappings().fetchone()
        assert row is not None
        assert row["password_hash"] is not None

    def test_duplicate_email_raises_409(self, sa_conn):
        from fastapi import HTTPException

        from qualito.dashboard.auth import create_user

        create_user(sa_conn, "dup@example.com", "password123")
        with pytest.raises(HTTPException) as exc_info:
            create_user(sa_conn, "dup@example.com", "password456")
        assert exc_info.value.status_code == 409

    def test_email_normalized(self, sa_conn):
        from qualito.dashboard.auth import create_user

        user = create_user(sa_conn, "  Upper@Example.COM  ", "password123")
        assert user["email"] == "upper@example.com"


class TestCreateApiKey:
    def test_creates_key(self, sa_conn):
        from qualito.dashboard.auth import create_api_key, create_user

        user = create_user(sa_conn, "key@example.com", "password123")
        plaintext, record = create_api_key(sa_conn, user["id"], "test-key")

        assert plaintext.startswith("qualito_")
        assert record["key_prefix"] == plaintext[:12]
        assert record["name"] == "test-key"
        assert isinstance(record["id"], int)

    def test_key_stored_as_hash(self, sa_conn):
        import hashlib

        from qualito.dashboard.auth import create_api_key, create_user

        user = create_user(sa_conn, "hash@example.com", "password123")
        plaintext, record = create_api_key(sa_conn, user["id"])

        # Verify stored as hash
        row = sa_conn.execute(
            select(api_keys_table).where(api_keys_table.c.id == record["id"])
        ).mappings().fetchone()
        expected_hash = hashlib.sha256(plaintext.encode()).hexdigest()
        assert row["key_hash"] == expected_hash


class TestVerifyApiKey:
    def test_valid_key_returns_user(self, sa_conn):
        from qualito.dashboard.auth import create_api_key, create_user, verify_api_key

        user = create_user(sa_conn, "verify@example.com", "password123", "Verifier")
        plaintext, _ = create_api_key(sa_conn, user["id"])

        result = verify_api_key(sa_conn, plaintext)
        assert result is not None
        assert result["email"] == "verify@example.com"
        assert result["name"] == "Verifier"

    def test_invalid_key_returns_none(self, sa_conn):
        from qualito.dashboard.auth import verify_api_key

        result = verify_api_key(sa_conn, "qualito_invalid_key_1234")
        assert result is None

    def test_revoked_key_returns_none(self, sa_conn):
        from datetime import datetime, timezone

        from qualito.dashboard.auth import create_api_key, create_user, verify_api_key

        user = create_user(sa_conn, "revoke@example.com", "password123")
        plaintext, record = create_api_key(sa_conn, user["id"])

        # Revoke the key
        sa_conn.execute(
            api_keys_table.update()
            .where(api_keys_table.c.id == record["id"])
            .values(revoked_at=datetime.now(timezone.utc).isoformat())
        )
        sa_conn.commit()

        result = verify_api_key(sa_conn, plaintext)
        assert result is None

    def test_updates_last_used_at(self, sa_conn):
        from qualito.dashboard.auth import create_api_key, create_user, verify_api_key

        user = create_user(sa_conn, "used@example.com", "password123")
        plaintext, record = create_api_key(sa_conn, user["id"])

        # Before verification, last_used_at should be None
        row = sa_conn.execute(
            select(api_keys_table.c.last_used_at)
            .where(api_keys_table.c.id == record["id"])
        ).mappings().fetchone()
        assert row["last_used_at"] is None

        verify_api_key(sa_conn, plaintext)

        row = sa_conn.execute(
            select(api_keys_table.c.last_used_at)
            .where(api_keys_table.c.id == record["id"])
        ).mappings().fetchone()
        assert row["last_used_at"] is not None


class TestGetUserFromToken:
    def test_jwt_returns_user(self, sa_conn):
        from qualito.dashboard.auth import _get_user_from_token, create_jwt, create_user

        user = create_user(sa_conn, "jwt@example.com", "password123", "JWT User")
        token = create_jwt(user["id"], user["email"])

        result = _get_user_from_token(sa_conn, token)
        assert result is not None
        assert result["email"] == "jwt@example.com"

    def test_api_key_returns_user(self, sa_conn):
        from qualito.dashboard.auth import (
            _get_user_from_token,
            create_api_key,
            create_user,
        )

        user = create_user(sa_conn, "apikey@example.com", "password123")
        plaintext, _ = create_api_key(sa_conn, user["id"])

        result = _get_user_from_token(sa_conn, plaintext)
        assert result is not None
        assert result["email"] == "apikey@example.com"

    def test_invalid_token_returns_none(self, sa_conn):
        from qualito.dashboard.auth import _get_user_from_token

        assert _get_user_from_token(sa_conn, "invalid_token") is None


# ---------------------------------------------------------------------------
# auth.py — init_auth_tables backward compat
# ---------------------------------------------------------------------------


class TestInitAuthTables:
    def test_sa_connection_is_noop(self, sa_conn):
        """SA path should not raise — tables already exist from init_db."""
        from qualito.dashboard.auth import init_auth_tables

        init_auth_tables(sa_conn)  # should not raise

    def test_noop_is_safe(self, sa_conn):
        """init_auth_tables is a no-op — calling it multiple times is safe."""
        from qualito.dashboard.auth import init_auth_tables

        init_auth_tables(sa_conn)
        init_auth_tables(sa_conn)  # should not raise


# ---------------------------------------------------------------------------
# api.py — _get_conn returns SA Connection
# ---------------------------------------------------------------------------


class TestGetConn:
    def test_returns_sa_connection(self, tmp_path, monkeypatch):
        """_get_conn should return an SA Connection, not sqlite3.Connection."""
        import sqlite3

        from sqlalchemy.engine import Connection as SAConnection

        # Create DB file first
        db_dir = tmp_path / ".qualito"
        db_dir.mkdir()
        db_path = db_dir / "qualito.db"
        db_path.touch()

        monkeypatch.chdir(tmp_path)
        monkeypatch.delenv("DATABASE_URL", raising=False)
        monkeypatch.delenv("QUALITO_DIR", raising=False)

        from qualito.dashboard.api import _get_conn

        conn = _get_conn()
        try:
            assert isinstance(conn, SAConnection)
            assert not isinstance(conn, sqlite3.Connection)
        finally:
            conn.close()

    def test_raises_503_when_no_db(self, tmp_path, monkeypatch):
        from fastapi import HTTPException

        monkeypatch.chdir(tmp_path)
        monkeypatch.delenv("DATABASE_URL", raising=False)
        monkeypatch.delenv("QUALITO_DIR", raising=False)

        from qualito.dashboard.api import _get_conn

        with pytest.raises(HTTPException) as exc_info:
            _get_conn()
        assert exc_info.value.status_code == 503


# ---------------------------------------------------------------------------
# api.py — dashboard endpoints via SA
# ---------------------------------------------------------------------------


class TestDashboardHero:
    def test_empty_db(self, sa_engine, monkeypatch):
        """Dashboard hero with no data should return zeros/nulls."""
        from qualito.dashboard import api as api_mod

        def mock_get_conn():
            return sa_engine.connect()

        monkeypatch.setattr(api_mod, "_get_conn", mock_get_conn)

        from fastapi.testclient import TestClient

        from qualito.dashboard.app import create_app

        # Prevent startup from running its own init_db
        app = create_app()
        client = TestClient(app)
        resp = client.get("/api/dashboard")
        assert resp.status_code == 200
        data = resp.json()
        assert data["avg_dqi"] is None
        assert data["run_count"] == 0
        assert data["total_cost_30d"] == 0
        assert data["active_incidents"] == 0

    def test_with_data(self, sa_engine, sa_conn, monkeypatch):
        """Dashboard hero with data should compute averages."""
        from datetime import datetime, timedelta

        from qualito.dashboard import api as api_mod

        # Insert a recent run + eval
        recent_date = (datetime.now() - timedelta(days=5)).strftime("%Y-%m-%dT%H:%M:%SZ")
        sa_conn.execute(runs_table.insert().values(
            id="hero-run-1", workspace="ws", task="t",
            started_at=recent_date, status="completed", cost_usd=1.50,
        ))
        sa_conn.execute(evaluations_table.insert().values(
            run_id="hero-run-1", eval_type="dqi", score=0.85,
        ))
        sa_conn.commit()

        def mock_get_conn():
            return sa_engine.connect()

        monkeypatch.setattr(api_mod, "_get_conn", mock_get_conn)

        from fastapi.testclient import TestClient

        from qualito.dashboard.app import create_app

        app = create_app()
        client = TestClient(app)
        resp = client.get("/api/dashboard")
        assert resp.status_code == 200
        data = resp.json()
        assert data["avg_dqi"] == 0.85
        assert data["run_count"] == 1
        assert data["total_cost_30d"] == 1.50


class TestListRuns:
    def test_empty_list(self, sa_engine, monkeypatch):
        from qualito.dashboard import api as api_mod

        def mock_get_conn():
            return sa_engine.connect()

        monkeypatch.setattr(api_mod, "_get_conn", mock_get_conn)

        from fastapi.testclient import TestClient

        from qualito.dashboard.app import create_app

        app = create_app()
        client = TestClient(app)
        resp = client.get("/api/runs")
        assert resp.status_code == 200
        data = resp.json()
        assert data["runs"] == []
        assert data["total"] == 0

    def test_with_filter(self, sa_engine, sa_conn, monkeypatch):
        from qualito.dashboard import api as api_mod

        sa_conn.execute(runs_table.insert().values(
            id="r1", workspace="ws-a", task="t", started_at="2026-04-01T00:00:00Z",
        ))
        sa_conn.execute(runs_table.insert().values(
            id="r2", workspace="ws-b", task="t", started_at="2026-04-01T00:00:00Z",
        ))
        sa_conn.commit()

        def mock_get_conn():
            return sa_engine.connect()

        monkeypatch.setattr(api_mod, "_get_conn", mock_get_conn)

        from fastapi.testclient import TestClient

        from qualito.dashboard.app import create_app

        app = create_app()
        client = TestClient(app)
        resp = client.get("/api/runs?workspace=ws-a")
        data = resp.json()
        assert data["total"] == 1
        assert data["runs"][0]["workspace"] == "ws-a"


class TestIncidentsSummary:
    def test_counts_by_severity(self, sa_engine, sa_conn, monkeypatch):
        from qualito.dashboard import api as api_mod

        for i, sev in enumerate(["warning", "critical", "warning"]):
            sa_conn.execute(incidents_table.insert().values(
                incident_key=f"sum-{i}",
                category="quality",
                severity=sev,
                status="detected",
                workspace="ws",
                title=f"Inc {i}",
            ))
        sa_conn.commit()

        def mock_get_conn():
            return sa_engine.connect()

        monkeypatch.setattr(api_mod, "_get_conn", mock_get_conn)

        from fastapi.testclient import TestClient

        from qualito.dashboard.app import create_app

        app = create_app()
        client = TestClient(app)
        resp = client.get("/api/incidents/summary")
        assert resp.status_code == 200
        data = resp.json()
        assert data["total"] == 3
        assert data["by_severity"]["warning"] == 2
        assert data["by_severity"]["critical"] == 1


# ---------------------------------------------------------------------------
# Experiments endpoints
# ---------------------------------------------------------------------------


class TestExperiments:
    def _setup_suite_and_experiments(self, sa_conn):
        """Helper to insert a suite with two experiments."""
        sa_conn.execute(benchmark_suites_table.insert().values(
            name="test-suite", description="", tasks="[]",
        ))
        sa_conn.commit()
        suite_row = sa_conn.execute(
            select(benchmark_suites_table.c.id)
            .where(benchmark_suites_table.c.name == "test-suite")
        ).mappings().fetchone()
        suite_id = suite_row["id"]

        sa_conn.execute(experiments_table.insert().values(
            name="exp-a", suite_id=suite_id, status="completed",
            avg_dqi=0.6, per_task_dqi=json.dumps({"t1": 0.6}), run_ids="[]",
        ))
        sa_conn.execute(experiments_table.insert().values(
            name="exp-b", suite_id=suite_id, status="running",
            avg_dqi=0.8, per_task_dqi=json.dumps({"t1": 0.8}), run_ids="[]",
        ))
        sa_conn.commit()

    def test_list_experiments(self, sa_engine, sa_conn, monkeypatch):
        from qualito.dashboard import api as api_mod

        self._setup_suite_and_experiments(sa_conn)

        def mock_get_conn():
            return sa_engine.connect()

        monkeypatch.setattr(api_mod, "_get_conn", mock_get_conn)

        from fastapi.testclient import TestClient

        from qualito.dashboard.app import create_app

        app = create_app()
        client = TestClient(app)
        resp = client.get("/api/experiments")
        assert resp.status_code == 200
        assert len(resp.json()["experiments"]) == 2

    def test_experiment_transitions(self, sa_engine, sa_conn, monkeypatch):
        from qualito.dashboard import api as api_mod

        self._setup_suite_and_experiments(sa_conn)

        # Get the running experiment's ID
        row = sa_conn.execute(
            select(experiments_table.c.id)
            .where(experiments_table.c.name == "exp-b")
        ).mappings().fetchone()
        exp_id = row["id"]

        def mock_get_conn():
            return sa_engine.connect()

        monkeypatch.setattr(api_mod, "_get_conn", mock_get_conn)

        from fastapi.testclient import TestClient

        from qualito.dashboard.app import create_app

        app = create_app()
        client = TestClient(app)

        # Check transitions
        resp = client.get(f"/api/experiments/{exp_id}/transitions")
        assert resp.status_code == 200
        data = resp.json()
        assert data["current_status"] == "running"
        assert "completed" in data["available_transitions"]

        # Transition to completed
        resp = client.post(
            f"/api/experiments/{exp_id}/transition",
            json={"status": "completed"},
        )
        assert resp.status_code == 200
        assert resp.json()["status"] == "completed"


# ---------------------------------------------------------------------------
# billing.py — SA queries
# ---------------------------------------------------------------------------


class TestBillingSA:
    def test_activate_plan(self, sa_engine, sa_conn, monkeypatch):
        from qualito.dashboard import api as api_mod
        from qualito.dashboard.billing import _activate_plan

        # Create a user
        sa_conn.execute(users_table.insert().values(
            email="billing@example.com", password_hash="hash", name="Biller",
        ))
        sa_conn.commit()
        user_row = sa_conn.execute(
            select(users_table.c.id).where(users_table.c.email == "billing@example.com")
        ).mappings().fetchone()
        user_id = user_row["id"]

        def mock_get_conn():
            return sa_engine.connect()

        monkeypatch.setattr(api_mod, "_get_conn", mock_get_conn)

        _activate_plan({
            "metadata": {"user_id": str(user_id), "plan": "pro"},
            "customer": "cus_test123",
        })

        # Verify plan was updated
        row = sa_conn.execute(
            select(users_table.c.plan, users_table.c.stripe_customer_id)
            .where(users_table.c.id == user_id)
        ).mappings().fetchone()
        assert row["plan"] == "pro"
        assert row["stripe_customer_id"] == "cus_test123"

    def test_deactivate_plan(self, sa_engine, sa_conn, monkeypatch):
        from qualito.dashboard import api as api_mod
        from qualito.dashboard.billing import _deactivate_plan

        # Create a user with pro plan
        sa_conn.execute(users_table.insert().values(
            email="deact@example.com", password_hash="hash",
            plan="pro", stripe_customer_id="cus_deact",
        ))
        sa_conn.commit()

        def mock_get_conn():
            return sa_engine.connect()

        monkeypatch.setattr(api_mod, "_get_conn", mock_get_conn)

        _deactivate_plan({"customer": "cus_deact"})

        row = sa_conn.execute(
            select(users_table.c.plan)
            .where(users_table.c.email == "deact@example.com")
        ).mappings().fetchone()
        assert row["plan"] == "free"


# ---------------------------------------------------------------------------
# Sync endpoints
# ---------------------------------------------------------------------------


class TestSyncRuns:
    def test_sync_upserts_runs(self, sa_engine, sa_conn, monkeypatch):
        from qualito.dashboard import api as api_mod

        # Create a user for auth
        sa_conn.execute(users_table.insert().values(
            email="sync@example.com", password_hash="hash", name="Syncer",
        ))
        sa_conn.commit()

        def mock_get_conn():
            return sa_engine.connect()

        monkeypatch.setattr(api_mod, "_get_conn", mock_get_conn)

        from qualito.dashboard.auth import create_jwt

        user_row = sa_conn.execute(
            select(users_table.c.id).where(users_table.c.email == "sync@example.com")
        ).mappings().fetchone()
        token = create_jwt(user_row["id"], "sync@example.com")

        from fastapi.testclient import TestClient

        from qualito.dashboard.app import create_app

        app = create_app()
        client = TestClient(app)

        runs = [
            {
                "id": "sync-run-1",
                "workspace": "ws",
                "task": "sync task",
                "started_at": "2026-04-01T00:00:00Z",
                "status": "completed",
                "cost_usd": 0.5,
            },
        ]
        resp = client.post(
            "/api/sync/runs",
            json={"runs": runs},
            headers={"Authorization": f"Bearer {token}"},
        )
        assert resp.status_code == 200
        data = resp.json()
        assert data["synced"] == 1
        assert data["skipped"] == 0

        # Re-sync should skip
        resp = client.post(
            "/api/sync/runs",
            json={"runs": runs},
            headers={"Authorization": f"Bearer {token}"},
        )
        data = resp.json()
        assert data["synced"] == 0
        assert data["skipped"] == 1


# ---------------------------------------------------------------------------
# DELETE /api/auth/account — account deletion
# ---------------------------------------------------------------------------


class TestDeleteAccount:
    def test_deletes_user_and_related_data(self, sa_engine, sa_conn, monkeypatch):
        """DELETE /api/auth/account removes user and all FK-dependent records."""
        from qualito.dashboard import api as api_mod
        from qualito.dashboard.auth import create_api_key, create_jwt, create_user

        user = create_user(sa_conn, "delete@example.com", "password123", "Deleter")
        user_id = user["id"]

        # Create related records
        sa_conn.execute(consent_table.insert().values(
            user_id=user_id, tos_accepted=True, privacy_accepted=True,
        ))
        sa_conn.execute(email_logs_table.insert().values(
            email_type="welcome", recipient_email="delete@example.com",
            status="sent",
        ))
        sa_conn.execute(setup_tokens_table.insert().values(
            token="st_setup_test123", user_id=user_id,
            email="delete@example.com", expires_at="2099-01-01T00:00:00Z",
        ))
        sa_conn.commit()

        _, _ = create_api_key(sa_conn, user_id, "test-key")
        token = create_jwt(user_id, "delete@example.com")

        def mock_get_conn():
            return sa_engine.connect()

        monkeypatch.setattr(api_mod, "_get_conn", mock_get_conn)

        from qualito.dashboard import auth_routes as auth_routes_mod
        monkeypatch.setattr(auth_routes_mod, "_get_conn", mock_get_conn)

        from fastapi.testclient import TestClient

        from qualito.dashboard.app import create_app

        app = create_app()
        client = TestClient(app)
        resp = client.delete(
            "/api/auth/account",
            headers={"Authorization": f"Bearer {token}"},
        )
        assert resp.status_code == 200
        assert resp.json() == {"deleted": True}

        # Verify all records are gone (fresh connection to see committed changes)
        verify = sa_engine.connect()
        try:
            assert verify.execute(
                select(users_table).where(users_table.c.id == user_id)
            ).fetchone() is None

            assert verify.execute(
                select(consent_table).where(consent_table.c.user_id == user_id)
            ).fetchone() is None

            assert verify.execute(
                select(api_keys_table).where(api_keys_table.c.user_id == user_id)
            ).fetchone() is None

            assert verify.execute(
                select(setup_tokens_table).where(
                    setup_tokens_table.c.user_id == user_id
                )
            ).fetchone() is None

            assert verify.execute(
                select(email_logs_table).where(
                    email_logs_table.c.recipient_email == "delete@example.com"
                )
            ).fetchone() is None
        finally:
            verify.close()

    def test_requires_auth(self, sa_engine, monkeypatch):
        """DELETE /api/auth/account without auth returns 401."""
        from qualito.dashboard import api as api_mod

        def mock_get_conn():
            return sa_engine.connect()

        monkeypatch.setattr(api_mod, "_get_conn", mock_get_conn)

        from fastapi.testclient import TestClient

        from qualito.dashboard.app import create_app

        app = create_app()
        client = TestClient(app)
        resp = client.delete("/api/auth/account")
        assert resp.status_code == 401


# ---------------------------------------------------------------------------
# Admin account management
# ---------------------------------------------------------------------------


class TestAdminRoutes:
    """Tests for /api/admin/* endpoints."""

    def _make_admin(self, sa_conn):
        """Create an admin user and return (user_dict, jwt_token)."""
        from qualito.dashboard.auth import create_jwt, create_user

        user = create_user(sa_conn, "admin@example.com", "password123",
                           "Admin", role="admin")
        token = create_jwt(user["id"], user["email"])
        return user, token

    def _make_user(self, sa_conn, email="user@example.com"):
        """Create a regular user and return (user_dict, jwt_token)."""
        from qualito.dashboard.auth import create_jwt, create_user

        user = create_user(sa_conn, email, "password123", "Regular")
        token = create_jwt(user["id"], user["email"])
        return user, token

    def _client(self, sa_engine, monkeypatch):
        """Create a TestClient with monkeypatched _get_conn."""
        from qualito.dashboard import admin_routes as admin_mod
        from qualito.dashboard import api as api_mod
        from qualito.dashboard import auth_routes as auth_routes_mod

        def mock_get_conn():
            return sa_engine.connect()

        monkeypatch.setattr(api_mod, "_get_conn", mock_get_conn)
        monkeypatch.setattr(auth_routes_mod, "_get_conn", mock_get_conn)
        monkeypatch.setattr(admin_mod, "_get_conn", mock_get_conn)

        from fastapi.testclient import TestClient

        from qualito.dashboard.app import create_app

        app = create_app()
        return TestClient(app)

    def test_admin_list_users(self, sa_engine, sa_conn, monkeypatch):
        """Admin can list all users."""
        admin, token = self._make_admin(sa_conn)
        self._make_user(sa_conn)

        client = self._client(sa_engine, monkeypatch)
        resp = client.get("/api/admin/users",
                          headers={"Authorization": f"Bearer {token}"})
        assert resp.status_code == 200
        data = resp.json()
        assert len(data["users"]) == 2
        emails = {u["email"] for u in data["users"]}
        assert "admin@example.com" in emails
        assert "user@example.com" in emails

    def test_admin_create_user(self, sa_engine, sa_conn, monkeypatch):
        """Admin can create a new user."""
        admin, token = self._make_admin(sa_conn)
        client = self._client(sa_engine, monkeypatch)

        resp = client.post(
            "/api/admin/users",
            json={"email": "new@example.com", "password": "password123",
                  "name": "New User", "role": "user"},
            headers={"Authorization": f"Bearer {token}"},
        )
        assert resp.status_code == 200
        data = resp.json()
        assert data["user"]["email"] == "new@example.com"
        assert data["user"]["role"] == "user"

    def test_admin_delete_user_cascade(self, sa_engine, sa_conn, monkeypatch):
        """Admin delete removes user and all FK-dependent records."""
        admin, token = self._make_admin(sa_conn)
        target, _ = self._make_user(sa_conn)
        target_id = target["id"]

        # Add related records
        sa_conn.execute(consent_table.insert().values(
            user_id=target_id, tos_accepted=True, privacy_accepted=True,
        ))
        sa_conn.execute(api_keys_table.insert().values(
            user_id=target_id, key_hash="fakehash", key_prefix="qualito_fak",
        ))
        sa_conn.commit()

        client = self._client(sa_engine, monkeypatch)
        resp = client.delete(
            f"/api/admin/users/{target_id}",
            headers={"Authorization": f"Bearer {token}"},
        )
        assert resp.status_code == 200
        assert resp.json() == {"deleted": True}

        # Verify cascade
        verify = sa_engine.connect()
        try:
            assert verify.execute(
                select(users_table).where(users_table.c.id == target_id)
            ).fetchone() is None
            assert verify.execute(
                select(consent_table).where(consent_table.c.user_id == target_id)
            ).fetchone() is None
            assert verify.execute(
                select(api_keys_table).where(api_keys_table.c.user_id == target_id)
            ).fetchone() is None
        finally:
            verify.close()

    def test_admin_suspend_activate(self, sa_engine, sa_conn, monkeypatch):
        """Admin can suspend and activate users."""
        admin, token = self._make_admin(sa_conn)
        target, target_token = self._make_user(sa_conn)
        target_id = target["id"]

        client = self._client(sa_engine, monkeypatch)

        # Suspend
        resp = client.post(
            f"/api/admin/users/{target_id}/suspend",
            headers={"Authorization": f"Bearer {token}"},
        )
        assert resp.status_code == 200
        assert resp.json() == {"suspended": True}

        # Suspended user gets 403 on authenticated endpoints
        resp = client.get("/api/auth/me",
                          headers={"Authorization": f"Bearer {target_token}"})
        assert resp.status_code == 403
        assert "suspended" in resp.json()["detail"].lower()

        # Activate
        resp = client.post(
            f"/api/admin/users/{target_id}/activate",
            headers={"Authorization": f"Bearer {token}"},
        )
        assert resp.status_code == 200
        assert resp.json() == {"activated": True}

        # User can access again
        resp = client.get("/api/auth/me",
                          headers={"Authorization": f"Bearer {target_token}"})
        assert resp.status_code == 200

    def test_non_admin_gets_403(self, sa_engine, sa_conn, monkeypatch):
        """Non-admin user gets 403 on admin endpoints."""
        _, user_token = self._make_user(sa_conn)

        client = self._client(sa_engine, monkeypatch)
        resp = client.get("/api/admin/users",
                          headers={"Authorization": f"Bearer {user_token}"})
        assert resp.status_code == 403
        assert "admin" in resp.json()["detail"].lower()

    def test_admin_cannot_self_delete(self, sa_engine, sa_conn, monkeypatch):
        """Admin cannot delete their own account via admin endpoint."""
        admin, token = self._make_admin(sa_conn)

        client = self._client(sa_engine, monkeypatch)
        resp = client.delete(
            f"/api/admin/users/{admin['id']}",
            headers={"Authorization": f"Bearer {token}"},
        )
        assert resp.status_code == 400
        assert "own account" in resp.json()["detail"].lower()

    def test_admin_cannot_change_own_role(self, sa_engine, sa_conn, monkeypatch):
        """Admin cannot change their own role."""
        admin, token = self._make_admin(sa_conn)

        client = self._client(sa_engine, monkeypatch)
        resp = client.patch(
            f"/api/admin/users/{admin['id']}/role",
            json={"role": "user"},
            headers={"Authorization": f"Bearer {token}"},
        )
        assert resp.status_code == 400
        assert "own role" in resp.json()["detail"].lower()

    def test_admin_change_role(self, sa_engine, sa_conn, monkeypatch):
        """Admin can change another user's role."""
        admin, token = self._make_admin(sa_conn)
        target, _ = self._make_user(sa_conn)

        client = self._client(sa_engine, monkeypatch)
        resp = client.patch(
            f"/api/admin/users/{target['id']}/role",
            json={"role": "admin"},
            headers={"Authorization": f"Bearer {token}"},
        )
        assert resp.status_code == 200
        assert resp.json() == {"role": "admin"}

    def test_delete_nonexistent_user_404(self, sa_engine, sa_conn, monkeypatch):
        """Deleting a nonexistent user returns 404."""
        admin, token = self._make_admin(sa_conn)

        client = self._client(sa_engine, monkeypatch)
        resp = client.delete(
            "/api/admin/users/99999",
            headers={"Authorization": f"Bearer {token}"},
        )
        assert resp.status_code == 404
