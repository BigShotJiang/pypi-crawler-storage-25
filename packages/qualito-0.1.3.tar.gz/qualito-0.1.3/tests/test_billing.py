"""Tests for Phase 5a — Stripe hardening.

Tests idempotent webhook processing, portal session creation,
consent recording, and new webhook event handlers.
"""


import pytest
from sqlalchemy import select

from qualito.core.db import (
    consent_table,
    get_engine,
    init_db,
    processed_events_table,
    users_table,
)

# ---------------------------------------------------------------------------
# Fixtures
# ---------------------------------------------------------------------------


@pytest.fixture
def sa_engine(tmp_path):
    """Fresh SA engine with all tables."""
    db_file = str(tmp_path / "test.db")
    engine = get_engine(db_file)
    init_db(engine)
    return engine


@pytest.fixture
def sa_conn(sa_engine):
    """SA connection from the engine."""
    conn = sa_engine.connect()
    yield conn
    conn.close()


# ---------------------------------------------------------------------------
# Idempotent webhook processing
# ---------------------------------------------------------------------------


class TestWebhookIdempotency:
    def test_event_processed_once(self, sa_engine, sa_conn, monkeypatch):
        """Same event ID processed twice → second returns already_processed."""
        from qualito.dashboard import api as api_mod
        from qualito.dashboard import billing as billing_mod

        # Create a user
        sa_conn.execute(users_table.insert().values(
            email="idem@example.com", password_hash="hash",
            plan="free", stripe_customer_id="cus_idem",
        ))
        sa_conn.commit()

        def mock_get_conn():
            return sa_engine.connect()

        monkeypatch.setattr(api_mod, "_get_conn", mock_get_conn)

        # Mock stripe to bypass signature verification
        class FakeEvent(dict):
            pass

        fake_event = FakeEvent({
            "id": "evt_test_123",
            "type": "customer.subscription.deleted",
            "data": {
                "object": {"customer": "cus_idem", "id": "sub_123"},
            },
        })

        def mock_construct_event(payload, sig, secret):
            return fake_event

        monkeypatch.setattr(billing_mod, "STRIPE_SECRET_KEY", "sk_test")

        import stripe
        monkeypatch.setattr(stripe.Webhook, "construct_event", mock_construct_event)

        # First call should process
        result = billing_mod.handle_webhook(b"payload", "sig")
        assert result["action"] == "plan_deactivated"

        # Second call with same event ID should be skipped
        result = billing_mod.handle_webhook(b"payload", "sig")
        assert result["action"] == "already_processed"

    def test_processed_event_stored_in_db(self, sa_engine, sa_conn, monkeypatch):
        """Processed events are stored in processed_events table."""
        from qualito.dashboard import api as api_mod
        from qualito.dashboard import billing as billing_mod

        def mock_get_conn():
            return sa_engine.connect()

        monkeypatch.setattr(api_mod, "_get_conn", mock_get_conn)
        monkeypatch.setattr(billing_mod, "STRIPE_SECRET_KEY", "sk_test")

        fake_event = {
            "id": "evt_stored_456",
            "type": "invoice.payment_succeeded",
            "data": {
                "object": {"customer": "cus_x", "id": "inv_123"},
            },
        }

        import stripe
        monkeypatch.setattr(
            stripe.Webhook, "construct_event",
            lambda p, s, sec: fake_event,
        )

        billing_mod.handle_webhook(b"payload", "sig")

        # Check the event is in the DB
        row = sa_conn.execute(
            select(processed_events_table)
            .where(processed_events_table.c.event_id == "evt_stored_456")
        ).mappings().fetchone()
        assert row is not None
        assert row["event_type"] == "invoice.payment_succeeded"


# ---------------------------------------------------------------------------
# Portal session
# ---------------------------------------------------------------------------


class TestPortalSession:
    def test_portal_requires_stripe(self, monkeypatch):
        import qualito.dashboard.billing as billing_mod
        from qualito.dashboard.billing import create_portal_session

        monkeypatch.setattr(billing_mod, "STRIPE_SECRET_KEY", "")

        with pytest.raises(RuntimeError, match="not configured"):
            create_portal_session("cus_test")

    def test_portal_route_no_customer(self, sa_engine, sa_conn, monkeypatch):
        """Portal route returns 400 when user has no stripe_customer_id."""
        from qualito.dashboard import api as api_mod

        # Create a user without stripe_customer_id
        sa_conn.execute(users_table.insert().values(
            email="noportal@example.com", password_hash="hash",
            name="No Portal", plan="free",
        ))
        sa_conn.commit()

        def mock_get_conn():
            return sa_engine.connect()

        monkeypatch.setattr(api_mod, "_get_conn", mock_get_conn)

        from qualito.dashboard.auth import create_jwt

        user_row = sa_conn.execute(
            select(users_table.c.id)
            .where(users_table.c.email == "noportal@example.com")
        ).mappings().fetchone()
        token = create_jwt(user_row["id"], "noportal@example.com")

        from fastapi.testclient import TestClient

        from qualito.dashboard.app import create_app

        app = create_app()
        client = TestClient(app)

        # Stripe must be "available" to get past _require_stripe
        import qualito.dashboard.billing as billing_mod
        monkeypatch.setattr(billing_mod, "STRIPE_SECRET_KEY", "sk_test")

        resp = client.post(
            "/api/billing/portal",
            headers={"Authorization": f"Bearer {token}"},
        )
        assert resp.status_code == 400
        assert "No billing account" in resp.json()["detail"]


# ---------------------------------------------------------------------------
# Consent recording
# ---------------------------------------------------------------------------


class TestConsentRecording:
    def test_consent_stored_on_register(self, sa_engine, monkeypatch):
        """Registration stores consent record in consent table."""
        from qualito.dashboard import api as api_mod
        from qualito.dashboard import auth_routes as auth_routes_mod

        def mock_get_conn():
            return sa_engine.connect()

        monkeypatch.setattr(api_mod, "_get_conn", mock_get_conn)
        monkeypatch.setattr(auth_routes_mod, "_get_conn", mock_get_conn)

        from fastapi.testclient import TestClient

        from qualito.dashboard.app import create_app

        app = create_app()
        client = TestClient(app)

        resp = client.post("/api/auth/register", json={
            "email": "consent@example.com",
            "password": "password123",
            "name": "Consenter",
            "tos_accepted": True,
            "privacy_accepted": True,
            "marketing_opt_in": True,
        })
        assert resp.status_code == 200

        user = resp.json()["user"]

        # Use a fresh connection to read (SQLite isolation)
        verify_conn = sa_engine.connect()
        try:
            row = verify_conn.execute(
                select(consent_table)
                .where(consent_table.c.user_id == user["id"])
            ).mappings().fetchone()
            assert row is not None
            assert row["tos_accepted"] in (True, 1)
            assert row["privacy_accepted"] in (True, 1)
            assert row["marketing_opt_in"] in (True, 1)
            assert row["tos_version"] == "v1.0"
        finally:
            verify_conn.close()

    def test_marketing_consent_updates_user(self, sa_engine, monkeypatch):
        """Marketing opt-in sets marketing_consent and date on user record."""
        from qualito.dashboard import api as api_mod
        from qualito.dashboard import auth_routes as auth_routes_mod

        def mock_get_conn():
            return sa_engine.connect()

        monkeypatch.setattr(api_mod, "_get_conn", mock_get_conn)
        monkeypatch.setattr(auth_routes_mod, "_get_conn", mock_get_conn)

        from fastapi.testclient import TestClient

        from qualito.dashboard.app import create_app

        app = create_app()
        client = TestClient(app)

        resp = client.post("/api/auth/register", json={
            "email": "marketing@example.com",
            "password": "password123",
            "marketing_opt_in": True,
        })
        assert resp.status_code == 200

        user_id = resp.json()["user"]["id"]
        verify_conn = sa_engine.connect()
        try:
            row = verify_conn.execute(
                select(users_table.c.marketing_consent, users_table.c.marketing_consent_date)
                .where(users_table.c.id == user_id)
            ).mappings().fetchone()
            assert row["marketing_consent"] in (True, 1)
            assert row["marketing_consent_date"] is not None
        finally:
            verify_conn.close()

    def test_no_marketing_consent_by_default(self, sa_engine, monkeypatch):
        """Register without marketing opt-in leaves marketing_consent false."""
        from qualito.dashboard import api as api_mod
        from qualito.dashboard import auth_routes as auth_routes_mod

        def mock_get_conn():
            return sa_engine.connect()

        monkeypatch.setattr(api_mod, "_get_conn", mock_get_conn)
        monkeypatch.setattr(auth_routes_mod, "_get_conn", mock_get_conn)

        from fastapi.testclient import TestClient

        from qualito.dashboard.app import create_app

        app = create_app()
        client = TestClient(app)

        resp = client.post("/api/auth/register", json={
            "email": "nomarketing@example.com",
            "password": "password123",
        })
        assert resp.status_code == 200

        user_id = resp.json()["user"]["id"]
        verify_conn = sa_engine.connect()
        try:
            row = verify_conn.execute(
                select(users_table.c.marketing_consent, users_table.c.marketing_consent_date)
                .where(users_table.c.id == user_id)
            ).mappings().fetchone()
            assert row["marketing_consent"] in (False, 0)
            assert row["marketing_consent_date"] is None
        finally:
            verify_conn.close()


# ---------------------------------------------------------------------------
# New webhook event handlers
# ---------------------------------------------------------------------------


class TestWebhookHandlers:
    def _setup_user(self, sa_conn, email="handler@example.com",
                    plan="free", customer_id="cus_handler"):
        sa_conn.execute(users_table.insert().values(
            email=email, password_hash="hash",
            plan=plan, stripe_customer_id=customer_id,
        ))
        sa_conn.commit()

    def _mock_webhook(self, monkeypatch, sa_engine, event_id, event_type, data_object):
        from qualito.dashboard import api as api_mod
        from qualito.dashboard import billing as billing_mod

        def mock_get_conn():
            return sa_engine.connect()

        monkeypatch.setattr(api_mod, "_get_conn", mock_get_conn)
        monkeypatch.setattr(billing_mod, "STRIPE_SECRET_KEY", "sk_test")

        fake_event = {
            "id": event_id,
            "type": event_type,
            "data": {"object": data_object},
        }

        import stripe
        monkeypatch.setattr(
            stripe.Webhook, "construct_event",
            lambda p, s, sec: fake_event,
        )
        return billing_mod

    def test_subscription_created(self, sa_engine, sa_conn, monkeypatch):
        """subscription.created stores subscription ID on user."""
        self._setup_user(sa_conn)

        billing_mod = self._mock_webhook(
            monkeypatch, sa_engine,
            "evt_sub_created_1",
            "customer.subscription.created",
            {"customer": "cus_handler", "id": "sub_new_123"},
        )

        result = billing_mod.handle_webhook(b"p", "s")
        assert result["action"] == "subscription_created"

        row = sa_conn.execute(
            select(users_table.c.stripe_subscription_id)
            .where(users_table.c.stripe_customer_id == "cus_handler")
        ).mappings().fetchone()
        assert row["stripe_subscription_id"] == "sub_new_123"

    def test_subscription_updated_active(self, sa_engine, sa_conn, monkeypatch):
        """subscription.updated with active status ensures plan=pro."""
        self._setup_user(sa_conn, plan="free")

        billing_mod = self._mock_webhook(
            monkeypatch, sa_engine,
            "evt_sub_updated_1",
            "customer.subscription.updated",
            {"customer": "cus_handler", "id": "sub_123", "status": "active"},
        )

        result = billing_mod.handle_webhook(b"p", "s")
        assert result["action"] == "subscription_updated"

        row = sa_conn.execute(
            select(users_table.c.plan)
            .where(users_table.c.stripe_customer_id == "cus_handler")
        ).mappings().fetchone()
        assert row["plan"] == "pro"

    def test_invoice_payment_succeeded(self, sa_engine, sa_conn, monkeypatch):
        """invoice.payment_succeeded logs and returns payment_logged."""
        billing_mod = self._mock_webhook(
            monkeypatch, sa_engine,
            "evt_pay_ok_1",
            "invoice.payment_succeeded",
            {"customer": "cus_x", "id": "inv_ok_1"},
        )

        result = billing_mod.handle_webhook(b"p", "s")
        assert result["action"] == "payment_logged"

    def test_invoice_payment_failed(self, sa_engine, sa_conn, monkeypatch):
        """invoice.payment_failed logs and returns failure_logged."""
        billing_mod = self._mock_webhook(
            monkeypatch, sa_engine,
            "evt_pay_fail_1",
            "invoice.payment_failed",
            {"customer": "cus_x", "id": "inv_fail_1"},
        )

        result = billing_mod.handle_webhook(b"p", "s")
        assert result["action"] == "failure_logged"

    def test_trial_will_end(self, sa_engine, sa_conn, monkeypatch):
        """trial_will_end logs and returns trial_end_logged."""
        billing_mod = self._mock_webhook(
            monkeypatch, sa_engine,
            "evt_trial_1",
            "customer.subscription.trial_will_end",
            {"customer": "cus_x", "id": "sub_trial_1"},
        )

        result = billing_mod.handle_webhook(b"p", "s")
        assert result["action"] == "trial_end_logged"

    def test_activate_plan_stores_subscription_id(self, sa_engine, sa_conn, monkeypatch):
        """_activate_plan stores stripe_subscription_id from checkout session."""
        from qualito.dashboard import api as api_mod
        from qualito.dashboard.billing import _activate_plan

        sa_conn.execute(users_table.insert().values(
            email="activate@example.com", password_hash="hash",
        ))
        sa_conn.commit()
        user_row = sa_conn.execute(
            select(users_table.c.id).where(users_table.c.email == "activate@example.com")
        ).mappings().fetchone()

        def mock_get_conn():
            return sa_engine.connect()

        monkeypatch.setattr(api_mod, "_get_conn", mock_get_conn)

        _activate_plan({
            "metadata": {"user_id": str(user_row["id"]), "plan": "pro"},
            "customer": "cus_activate",
            "subscription": "sub_activate_123",
        })

        row = sa_conn.execute(
            select(
                users_table.c.plan,
                users_table.c.stripe_customer_id,
                users_table.c.stripe_subscription_id,
            ).where(users_table.c.id == user_row["id"])
        ).mappings().fetchone()
        assert row["plan"] == "pro"
        assert row["stripe_customer_id"] == "cus_activate"
        assert row["stripe_subscription_id"] == "sub_activate_123"

    def test_deactivate_clears_subscription_id(self, sa_engine, sa_conn, monkeypatch):
        """_deactivate_plan clears stripe_subscription_id."""
        from qualito.dashboard import api as api_mod
        from qualito.dashboard.billing import _deactivate_plan

        sa_conn.execute(users_table.insert().values(
            email="deact2@example.com", password_hash="hash",
            plan="pro", stripe_customer_id="cus_deact2",
            stripe_subscription_id="sub_old",
        ))
        sa_conn.commit()

        def mock_get_conn():
            return sa_engine.connect()

        monkeypatch.setattr(api_mod, "_get_conn", mock_get_conn)

        _deactivate_plan({"customer": "cus_deact2"})

        row = sa_conn.execute(
            select(users_table.c.plan, users_table.c.stripe_subscription_id)
            .where(users_table.c.email == "deact2@example.com")
        ).mappings().fetchone()
        assert row["plan"] == "free"
        assert row["stripe_subscription_id"] is None


# ---------------------------------------------------------------------------
# Checkout promo codes
# ---------------------------------------------------------------------------


class TestCheckoutPromo:
    def test_allow_promotion_codes_in_source(self):
        """Verify create_checkout_session calls stripe with allow_promotion_codes."""
        import inspect

        from qualito.dashboard.billing import create_checkout_session

        source = inspect.getsource(create_checkout_session)
        assert "allow_promotion_codes=True" in source
