"""Tests for Phase 5b — Email service, verification, and password reset.

Tests token creation/decoding, email_logs table, and auth routes
for email verification and password reset.
"""

import time

import pytest
from sqlalchemy import select

from qualito.core.db import (
    email_logs_table,
    get_engine,
    init_db,
    users_table,
)


# ---------------------------------------------------------------------------
# Fixtures
# ---------------------------------------------------------------------------


@pytest.fixture
def sa_engine(tmp_path):
    """Fresh SA engine with all tables."""
    db_file = str(tmp_path / "test.db")
    engine = get_engine(db_file)
    init_db(engine)
    return engine


@pytest.fixture
def sa_conn(sa_engine):
    """SA connection from the engine."""
    conn = sa_engine.connect()
    yield conn
    conn.close()


# ---------------------------------------------------------------------------
# Token creation and decoding
# ---------------------------------------------------------------------------


class TestTokens:
    def test_create_and_decode_verification_token(self):
        """Verification token round-trips correctly."""
        from qualito.dashboard.email import (
            create_verification_token,
            decode_verification_token,
        )

        token = create_verification_token(42, "test@example.com")
        payload = decode_verification_token(token)
        assert payload["sub"] == "42"
        assert payload["email"] == "test@example.com"
        assert payload["type"] == "email_verify"

    def test_create_and_decode_reset_token(self):
        """Reset token round-trips correctly."""
        from qualito.dashboard.email import (
            create_reset_token,
            decode_reset_token,
        )

        token = create_reset_token(99, "reset@example.com")
        payload = decode_reset_token(token)
        assert payload["sub"] == "99"
        assert payload["email"] == "reset@example.com"
        assert payload["type"] == "password_reset"

    def test_expired_verification_token_rejected(self, monkeypatch):
        """Expired verification token is rejected."""
        from datetime import datetime, timedelta, timezone

        from jose import jwt

        from qualito.dashboard.email import (
            EMAIL_VERIFY_SECRET,
            decode_verification_token,
        )

        # Create an already-expired token
        payload = {
            "sub": "1",
            "email": "expired@example.com",
            "type": "email_verify",
            "exp": datetime.now(timezone.utc) - timedelta(hours=1),
            "iat": datetime.now(timezone.utc) - timedelta(hours=25),
        }
        token = jwt.encode(payload, EMAIL_VERIFY_SECRET, algorithm="HS256")

        with pytest.raises(ValueError, match="Invalid or expired"):
            decode_verification_token(token)

    def test_expired_reset_token_rejected(self):
        """Expired reset token is rejected."""
        from datetime import datetime, timedelta, timezone

        from jose import jwt

        from qualito.dashboard.email import (
            PASSWORD_RESET_SECRET,
            decode_reset_token,
        )

        payload = {
            "sub": "1",
            "email": "expired@example.com",
            "type": "password_reset",
            "exp": datetime.now(timezone.utc) - timedelta(hours=1),
            "iat": datetime.now(timezone.utc) - timedelta(hours=2),
        }
        token = jwt.encode(payload, PASSWORD_RESET_SECRET, algorithm="HS256")

        with pytest.raises(ValueError, match="Invalid or expired"):
            decode_reset_token(token)

    def test_wrong_token_type_verification(self):
        """A reset token cannot be decoded as a verification token."""
        from qualito.dashboard.email import (
            create_reset_token,
            decode_verification_token,
        )

        token = create_reset_token(1, "test@example.com")

        with pytest.raises(ValueError, match="Invalid"):
            decode_verification_token(token)

    def test_wrong_token_type_reset(self):
        """A verification token cannot be decoded as a reset token."""
        from qualito.dashboard.email import (
            create_verification_token,
            decode_reset_token,
        )

        token = create_verification_token(1, "test@example.com")

        with pytest.raises(ValueError, match="Invalid"):
            decode_reset_token(token)


# ---------------------------------------------------------------------------
# Email logs table
# ---------------------------------------------------------------------------


class TestEmailLogs:
    def test_email_logs_table_insert(self, sa_conn):
        """Email logs can be inserted and queried."""
        sa_conn.execute(
            email_logs_table.insert().values(
                email_type="WELCOME",
                recipient_email="log@example.com",
                status="SENT",
                provider_id="resend_abc123",
            )
        )
        sa_conn.commit()

        row = sa_conn.execute(
            select(email_logs_table)
            .where(email_logs_table.c.recipient_email == "log@example.com")
        ).mappings().fetchone()
        assert row is not None
        assert row["email_type"] == "WELCOME"
        assert row["status"] == "SENT"
        assert row["provider_id"] == "resend_abc123"

    def test_email_logs_failed_entry(self, sa_conn):
        """Failed email logs store the error message."""
        sa_conn.execute(
            email_logs_table.insert().values(
                email_type="RESET",
                recipient_email="fail@example.com",
                status="FAILED",
                error_message="Connection timeout",
            )
        )
        sa_conn.commit()

        row = sa_conn.execute(
            select(email_logs_table)
            .where(email_logs_table.c.recipient_email == "fail@example.com")
        ).mappings().fetchone()
        assert row is not None
        assert row["status"] == "FAILED"
        assert row["error_message"] == "Connection timeout"


# ---------------------------------------------------------------------------
# Auth routes — email verification + password reset
# ---------------------------------------------------------------------------


class TestVerifyEmailRoute:
    def test_verify_email_sets_verified(self, sa_engine, monkeypatch):
        """POST /api/auth/verify-email sets email_verified=True."""
        from qualito.dashboard import api as api_mod
        from qualito.dashboard import auth_routes as auth_routes_mod
        from qualito.dashboard.email import create_verification_token

        def mock_get_conn():
            return sa_engine.connect()

        monkeypatch.setattr(api_mod, "_get_conn", mock_get_conn)
        monkeypatch.setattr(auth_routes_mod, "_get_conn", mock_get_conn)

        # Create a user
        conn = sa_engine.connect()
        conn.execute(users_table.insert().values(
            email="verify@example.com", password_hash="hash",
            name="Verifier", email_verified=False,
        ))
        conn.commit()
        user_row = conn.execute(
            select(users_table.c.id).where(users_table.c.email == "verify@example.com")
        ).mappings().fetchone()
        conn.close()

        token = create_verification_token(user_row["id"], "verify@example.com")

        from fastapi.testclient import TestClient
        from qualito.dashboard.app import create_app

        app = create_app()
        client = TestClient(app)

        resp = client.post("/api/auth/verify-email", json={"token": token})
        assert resp.status_code == 200
        assert resp.json()["verified"] is True

        # Verify the DB was updated
        verify_conn = sa_engine.connect()
        try:
            row = verify_conn.execute(
                select(users_table.c.email_verified)
                .where(users_table.c.email == "verify@example.com")
            ).mappings().fetchone()
            assert row["email_verified"] in (True, 1)
        finally:
            verify_conn.close()

    def test_verify_email_invalid_token(self, sa_engine, monkeypatch):
        """POST /api/auth/verify-email with bad token returns 400."""
        from qualito.dashboard import api as api_mod
        from qualito.dashboard import auth_routes as auth_routes_mod

        def mock_get_conn():
            return sa_engine.connect()

        monkeypatch.setattr(api_mod, "_get_conn", mock_get_conn)
        monkeypatch.setattr(auth_routes_mod, "_get_conn", mock_get_conn)

        from fastapi.testclient import TestClient
        from qualito.dashboard.app import create_app

        app = create_app()
        client = TestClient(app)

        resp = client.post("/api/auth/verify-email", json={"token": "invalid_token"})
        assert resp.status_code == 400


class TestForgotPasswordRoute:
    def test_forgot_password_always_200(self, sa_engine, monkeypatch):
        """POST /api/auth/forgot-password returns 200 even for non-existent email."""
        from qualito.dashboard import api as api_mod
        from qualito.dashboard import auth_routes as auth_routes_mod

        def mock_get_conn():
            return sa_engine.connect()

        monkeypatch.setattr(api_mod, "_get_conn", mock_get_conn)
        monkeypatch.setattr(auth_routes_mod, "_get_conn", mock_get_conn)

        from fastapi.testclient import TestClient
        from qualito.dashboard.app import create_app

        app = create_app()
        client = TestClient(app)

        resp = client.post(
            "/api/auth/forgot-password",
            json={"email": "nonexistent@example.com"},
        )
        assert resp.status_code == 200
        assert "reset link" in resp.json()["message"].lower()

    def test_forgot_password_existing_email(self, sa_engine, monkeypatch):
        """POST /api/auth/forgot-password for existing user returns 200."""
        from qualito.dashboard import api as api_mod
        from qualito.dashboard import auth_routes as auth_routes_mod
        from qualito.dashboard import email as email_mod

        def mock_get_conn():
            return sa_engine.connect()

        monkeypatch.setattr(api_mod, "_get_conn", mock_get_conn)
        monkeypatch.setattr(auth_routes_mod, "_get_conn", mock_get_conn)

        # Disable actual email sending
        monkeypatch.setattr(email_mod, "_email_available", lambda: False)

        # Create user
        conn = sa_engine.connect()
        conn.execute(users_table.insert().values(
            email="exists@example.com", password_hash="hash",
        ))
        conn.commit()
        conn.close()

        from fastapi.testclient import TestClient
        from qualito.dashboard.app import create_app

        app = create_app()
        client = TestClient(app)

        resp = client.post(
            "/api/auth/forgot-password",
            json={"email": "exists@example.com"},
        )
        assert resp.status_code == 200


class TestResetPasswordRoute:
    def test_reset_password_updates_hash(self, sa_engine, monkeypatch):
        """POST /api/auth/reset-password changes the password."""
        import bcrypt

        from qualito.dashboard import api as api_mod
        from qualito.dashboard import auth_routes as auth_routes_mod
        from qualito.dashboard.email import create_reset_token

        def mock_get_conn():
            return sa_engine.connect()

        monkeypatch.setattr(api_mod, "_get_conn", mock_get_conn)
        monkeypatch.setattr(auth_routes_mod, "_get_conn", mock_get_conn)

        # Create user with known password
        old_hash = bcrypt.hashpw(b"oldpassword", bcrypt.gensalt()).decode()
        conn = sa_engine.connect()
        conn.execute(users_table.insert().values(
            email="resetme@example.com", password_hash=old_hash,
        ))
        conn.commit()
        user_row = conn.execute(
            select(users_table.c.id).where(users_table.c.email == "resetme@example.com")
        ).mappings().fetchone()
        conn.close()

        token = create_reset_token(user_row["id"], "resetme@example.com")

        from fastapi.testclient import TestClient
        from qualito.dashboard.app import create_app

        app = create_app()
        client = TestClient(app)

        resp = client.post("/api/auth/reset-password", json={
            "token": token,
            "password": "newpassword123",
        })
        assert resp.status_code == 200
        assert resp.json()["reset"] is True

        # Verify the password was actually changed
        verify_conn = sa_engine.connect()
        try:
            row = verify_conn.execute(
                select(users_table.c.password_hash)
                .where(users_table.c.email == "resetme@example.com")
            ).mappings().fetchone()
            assert row["password_hash"] != old_hash
            assert bcrypt.checkpw(b"newpassword123", row["password_hash"].encode())
        finally:
            verify_conn.close()

    def test_reset_password_invalid_token(self, sa_engine, monkeypatch):
        """POST /api/auth/reset-password with bad token returns 400."""
        from qualito.dashboard import api as api_mod
        from qualito.dashboard import auth_routes as auth_routes_mod

        def mock_get_conn():
            return sa_engine.connect()

        monkeypatch.setattr(api_mod, "_get_conn", mock_get_conn)
        monkeypatch.setattr(auth_routes_mod, "_get_conn", mock_get_conn)

        from fastapi.testclient import TestClient
        from qualito.dashboard.app import create_app

        app = create_app()
        client = TestClient(app)

        resp = client.post("/api/auth/reset-password", json={
            "token": "bad_token",
            "password": "newpassword123",
        })
        assert resp.status_code == 400

    def test_reset_password_short_password(self, sa_engine, monkeypatch):
        """POST /api/auth/reset-password with short password returns 400."""
        from qualito.dashboard import api as api_mod
        from qualito.dashboard import auth_routes as auth_routes_mod
        from qualito.dashboard.email import create_reset_token

        def mock_get_conn():
            return sa_engine.connect()

        monkeypatch.setattr(api_mod, "_get_conn", mock_get_conn)
        monkeypatch.setattr(auth_routes_mod, "_get_conn", mock_get_conn)

        # Create user
        conn = sa_engine.connect()
        conn.execute(users_table.insert().values(
            email="short@example.com", password_hash="hash",
        ))
        conn.commit()
        user_row = conn.execute(
            select(users_table.c.id).where(users_table.c.email == "short@example.com")
        ).mappings().fetchone()
        conn.close()

        token = create_reset_token(user_row["id"], "short@example.com")

        from fastapi.testclient import TestClient
        from qualito.dashboard.app import create_app

        app = create_app()
        client = TestClient(app)

        resp = client.post("/api/auth/reset-password", json={
            "token": token,
            "password": "short",
        })
        assert resp.status_code == 400
        assert "8 characters" in resp.json()["detail"]


# ---------------------------------------------------------------------------
# Email availability graceful degradation
# ---------------------------------------------------------------------------


class TestEmailDegradation:
    def test_send_email_returns_none_without_resend(self, monkeypatch):
        """send_email returns None when resend is not available."""
        import qualito.dashboard.email as email_mod

        monkeypatch.setattr(email_mod, "resend", None)

        result = email_mod.send_email("test@example.com", "Test", "<p>Hi</p>")
        assert result is None

    def test_send_email_returns_none_without_api_key(self, monkeypatch):
        """send_email returns None when RESEND_QUALITO_API_KEY is empty."""
        import qualito.dashboard.email as email_mod

        monkeypatch.setattr(email_mod, "RESEND_QUALITO_API_KEY", "")

        result = email_mod.send_email("test@example.com", "Test", "<p>Hi</p>")
        assert result is None
