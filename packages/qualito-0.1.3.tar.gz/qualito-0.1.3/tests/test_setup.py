"""Tests for the qualito setup command."""

import json
from pathlib import Path

from click.testing import CliRunner

from qualito.cli.main import (
    _compute_date_range,
    _dqi_label,
    _parse_selection,
    cli,
    safe_add_mcp_to_claude_json,
)


# ---------------------------------------------------------------------------
# Helper unit tests
# ---------------------------------------------------------------------------


def test_parse_selection_all():
    assert _parse_selection("all", 5) == [0, 1, 2, 3, 4]


def test_parse_selection_none():
    assert _parse_selection("none", 5) is None


def test_parse_selection_specific():
    assert _parse_selection("1,3,5", 5) == [0, 2, 4]


def test_parse_selection_out_of_range():
    # "10" is out of range for max_n=3
    assert _parse_selection("1,10", 3) == [0]


def test_parse_selection_empty():
    assert _parse_selection("", 5) is None


def test_parse_selection_whitespace():
    assert _parse_selection(" 2 , 4 ", 5) == [1, 3]


def test_dqi_label_excellent():
    assert _dqi_label(0.85) == "Excellent"


def test_dqi_label_good():
    assert _dqi_label(0.72) == "Good"


def test_dqi_label_fair():
    assert _dqi_label(0.55) == "Fair"


def test_dqi_label_needs_attention():
    assert _dqi_label(0.30) == "Needs attention"


def test_dqi_label_none():
    assert _dqi_label(None) == "N/A"


def test_compute_date_range_all_time():
    assert _compute_date_range("a") is None


def test_compute_date_range_last_30():
    result = _compute_date_range("b")
    assert result is not None
    start, end = result
    assert len(start) == 10  # YYYY-MM-DD
    assert len(end) == 10


def test_compute_date_range_last_7():
    result = _compute_date_range("c")
    assert result is not None
    start, end = result
    assert len(start) == 10
    assert len(end) == 10


# ---------------------------------------------------------------------------
# safe_add_mcp_to_claude_json
# ---------------------------------------------------------------------------


def test_mcp_creates_new_file(tmp_path, monkeypatch):
    """Creates ~/.claude.json when it doesn't exist."""
    monkeypatch.setattr(Path, "home", lambda: tmp_path)
    result = safe_add_mcp_to_claude_json()
    assert result is True

    target = tmp_path / ".claude.json"
    assert target.exists()
    data = json.loads(target.read_text())
    assert "qualito" in data["mcpServers"]
    assert data["mcpServers"]["qualito"]["command"] == "uvx"


def test_mcp_adds_to_existing_file(tmp_path, monkeypatch):
    """Adds qualito to existing ~/.claude.json with other servers."""
    monkeypatch.setattr(Path, "home", lambda: tmp_path)
    target = tmp_path / ".claude.json"
    existing = {"mcpServers": {"other-server": {"command": "node"}}}
    target.write_text(json.dumps(existing))

    result = safe_add_mcp_to_claude_json()
    assert result is True

    data = json.loads(target.read_text())
    assert "qualito" in data["mcpServers"]
    assert "other-server" in data["mcpServers"]  # preserved


def test_mcp_already_configured(tmp_path, monkeypatch):
    """Returns False when qualito is already in ~/.claude.json."""
    monkeypatch.setattr(Path, "home", lambda: tmp_path)
    target = tmp_path / ".claude.json"
    existing = {
        "mcpServers": {"qualito": {"command": "uvx", "args": ["qualito-mcp"]}}
    }
    target.write_text(json.dumps(existing))

    result = safe_add_mcp_to_claude_json()
    assert result is False


def test_mcp_malformed_json(tmp_path, monkeypatch):
    """Handles malformed ~/.claude.json gracefully."""
    monkeypatch.setattr(Path, "home", lambda: tmp_path)
    target = tmp_path / ".claude.json"
    target.write_text("not valid json {{{")

    result = safe_add_mcp_to_claude_json()
    assert result is False


def test_mcp_no_mcp_servers_key(tmp_path, monkeypatch):
    """Adds mcpServers key when file exists but doesn't have it."""
    monkeypatch.setattr(Path, "home", lambda: tmp_path)
    target = tmp_path / ".claude.json"
    target.write_text(json.dumps({"someOtherKey": True}))

    result = safe_add_mcp_to_claude_json()
    assert result is True

    data = json.loads(target.read_text())
    assert "qualito" in data["mcpServers"]
    assert data["someOtherKey"] is True  # preserved


# ---------------------------------------------------------------------------
# Setup command — auto mode (with token)
# ---------------------------------------------------------------------------


def _make_session_jsonl(path: Path, session_id: str, task: str = "test task"):
    """Create a minimal valid session JSONL file."""
    events = [
        {
            "type": "user",
            "timestamp": "2024-01-01T10:00:00Z",
            "message": {"content": task},
        },
        {
            "type": "assistant",
            "timestamp": "2024-01-01T10:01:00Z",
            "message": {
                "content": [{"type": "tool_use", "name": "Read", "input": {}}],
                "usage": {"input_tokens": 100, "output_tokens": 50},
            },
        },
    ]
    lines = [json.dumps(e) for e in events]
    path.write_text("\n".join(lines) + "\n")


def test_auto_setup_no_projects(tmp_path, monkeypatch):
    """Auto setup with token but no projects prints message."""
    monkeypatch.setattr(Path, "home", lambda: tmp_path)
    import qualito.importer as imp
    monkeypatch.setattr(imp, "CLAUDE_PROJECTS_DIR", tmp_path / ".claude" / "projects")
    runner = CliRunner()
    result = runner.invoke(cli, ["setup", "test-token-123"])
    assert result.exit_code == 0
    assert "No Claude Code projects found" in result.output


def test_auto_setup_imports_all(tmp_path, monkeypatch):
    """Auto setup with token imports all discovered projects."""
    monkeypatch.setattr(Path, "home", lambda: tmp_path)
    import qualito.importer as imp
    monkeypatch.setattr(imp, "CLAUDE_PROJECTS_DIR", tmp_path / ".claude" / "projects")

    # Create mock claude projects
    claude_dir = tmp_path / ".claude" / "projects"
    p1 = claude_dir / "-Users-test-projectA"
    p1.mkdir(parents=True)
    _make_session_jsonl(p1 / "sess1.jsonl", "sess1")

    runner = CliRunner()
    result = runner.invoke(cli, ["setup", "test-token-123"])
    assert result.exit_code == 0
    assert "Imported" in result.output
    assert (tmp_path / ".qualito" / "config.toml").exists()


# ---------------------------------------------------------------------------
# Setup command — interactive first run
# ---------------------------------------------------------------------------


def test_interactive_setup_first_run_no_projects(tmp_path, monkeypatch):
    """Interactive setup with no projects prints helpful message."""
    monkeypatch.setattr(Path, "home", lambda: tmp_path)
    import qualito.importer as imp
    monkeypatch.setattr(imp, "CLAUDE_PROJECTS_DIR", tmp_path / ".claude" / "projects")
    runner = CliRunner()
    result = runner.invoke(cli, ["setup"], input="\n")
    assert result.exit_code == 0
    assert "No Claude Code projects found" in result.output


def test_interactive_setup_first_run_with_projects(tmp_path, monkeypatch):
    """Interactive first-run setup discovers, imports, and shows results."""
    monkeypatch.setattr(Path, "home", lambda: tmp_path)
    import qualito.importer as imp
    monkeypatch.setattr(imp, "CLAUDE_PROJECTS_DIR", tmp_path / ".claude" / "projects")

    # Create mock claude projects
    claude_dir = tmp_path / ".claude" / "projects"
    p1 = claude_dir / "-Users-test-myapp"
    p1.mkdir(parents=True)
    _make_session_jsonl(p1 / "sess1.jsonl", "sess1")
    _make_session_jsonl(p1 / "sess2.jsonl", "sess2")

    runner = CliRunner()
    # Input: select all, all time, default workspace name, yes to MCP
    result = runner.invoke(cli, ["setup"], input="all\na\n\ny\n")
    assert result.exit_code == 0
    assert "Found 1 Claude Code project" in result.output
    assert "Importing" in result.output
    assert "Setup complete" in result.output


def test_interactive_setup_select_none(tmp_path, monkeypatch):
    """Interactive setup with 'none' selection exits cleanly."""
    monkeypatch.setattr(Path, "home", lambda: tmp_path)
    import qualito.importer as imp
    monkeypatch.setattr(imp, "CLAUDE_PROJECTS_DIR", tmp_path / ".claude" / "projects")

    claude_dir = tmp_path / ".claude" / "projects"
    p1 = claude_dir / "-Users-test-myapp"
    p1.mkdir(parents=True)
    _make_session_jsonl(p1 / "sess1.jsonl", "sess1")

    runner = CliRunner()
    result = runner.invoke(cli, ["setup"], input="none\n")
    assert result.exit_code == 0
    assert "No projects selected" in result.output


# ---------------------------------------------------------------------------
# Setup command — re-run
# ---------------------------------------------------------------------------


def test_interactive_setup_rerun_exit(tmp_path, monkeypatch):
    """Re-run setup with 'd' (exit) exits cleanly."""
    monkeypatch.setattr(Path, "home", lambda: tmp_path)
    import qualito.importer as imp
    monkeypatch.setattr(imp, "CLAUDE_PROJECTS_DIR", tmp_path / ".claude" / "projects")

    from qualito.config import init_project

    init_project(project_dir=tmp_path, local=False)

    runner = CliRunner()
    result = runner.invoke(cli, ["setup"], input="d\n")
    assert result.exit_code == 0
    assert "Found existing Qualito config" in result.output


def test_interactive_setup_rerun_reimport(tmp_path, monkeypatch):
    """Re-run setup with 'b' (re-import) discovers and imports."""
    monkeypatch.setattr(Path, "home", lambda: tmp_path)
    import qualito.importer as imp
    monkeypatch.setattr(imp, "CLAUDE_PROJECTS_DIR", tmp_path / ".claude" / "projects")

    from qualito.config import init_project

    init_project(project_dir=tmp_path, local=False)

    # Create mock claude projects
    claude_dir = tmp_path / ".claude" / "projects"
    p1 = claude_dir / "-Users-test-proj"
    p1.mkdir(parents=True)
    _make_session_jsonl(p1 / "sess1.jsonl", "sess1")

    runner = CliRunner()
    result = runner.invoke(cli, ["setup"], input="b\n")
    assert result.exit_code == 0
    assert "Re-importing" in result.output


def test_interactive_setup_rerun_rescore(tmp_path, monkeypatch):
    """Re-run setup with 'c' (re-score) runs scoring on existing data."""
    monkeypatch.setattr(Path, "home", lambda: tmp_path)
    import qualito.importer as imp
    monkeypatch.setattr(imp, "CLAUDE_PROJECTS_DIR", tmp_path / ".claude" / "projects")

    from qualito.config import init_project

    init_project(project_dir=tmp_path, local=False)

    runner = CliRunner()
    result = runner.invoke(cli, ["setup"], input="c\n")
    assert result.exit_code == 0
    assert "Re-scoring" in result.output


# ---------------------------------------------------------------------------
# Setup API routes — token validation, progress, SSE
# ---------------------------------------------------------------------------


from datetime import datetime, timezone, timedelta

from qualito.dashboard.setup_routes import _setup_tokens


def _make_setup_app():
    """Create a FastAPI test app with setup routes."""
    from fastapi import FastAPI
    from qualito.dashboard.setup_routes import router as setup_router

    app = FastAPI()
    app.include_router(setup_router)
    return app


def _insert_token(token, user_id=1, email="test@example.com", **kwargs):
    """Insert a setup token directly."""
    _setup_tokens[token] = {
        "user_id": user_id,
        "email": email,
        "created_at": kwargs.get("created_at", datetime.now(timezone.utc).isoformat()),
        "progress": kwargs.get("progress", []),
    }


def _clear_tokens():
    _setup_tokens.clear()


def test_api_validate_valid_token(tmp_path, monkeypatch):
    """POST /api/setup/validate accepts a valid token and returns an API key."""
    import os
    from fastapi.testclient import TestClient
    from qualito.core.db import get_engine, get_sa_connection, init_db, users_table

    _clear_tokens()

    # Set up temp DB with auth tables
    db_path = tmp_path / "qualito.db"
    monkeypatch.setenv("QUALITO_DIR", str(tmp_path))
    engine = get_engine(str(db_path))
    init_db(engine)
    conn = get_sa_connection(engine)
    # Insert a dummy user
    conn.execute(
        users_table.insert().values(
            id=1, email="test@example.com", password_hash="hash", name="Test"
        )
    )
    conn.commit()
    conn.close()

    app = _make_setup_app()
    client = TestClient(app)
    _insert_token("st_setup_abc")

    resp = client.post("/api/setup/validate", json={"token": "st_setup_abc"})
    assert resp.status_code == 200
    data = resp.json()
    assert "api_key" in data
    assert data["user"]["id"] == 1


def test_api_validate_invalid_token():
    """POST /api/setup/validate rejects an unknown token."""
    from fastapi.testclient import TestClient

    _clear_tokens()
    app = _make_setup_app()
    client = TestClient(app)

    resp = client.post("/api/setup/validate", json={"token": "st_setup_nope"})
    assert resp.status_code == 400
    assert "Invalid or expired" in resp.json()["detail"]


def test_api_validate_expired_token():
    """POST /api/setup/validate rejects an expired token (>15 min)."""
    from fastapi.testclient import TestClient

    _clear_tokens()
    app = _make_setup_app()
    client = TestClient(app)

    old = (datetime.now(timezone.utc) - timedelta(minutes=20)).isoformat()
    _insert_token("st_setup_old", created_at=old)

    resp = client.post("/api/setup/validate", json={"token": "st_setup_old"})
    assert resp.status_code == 400


def test_api_progress_updates():
    """POST /api/setup/progress records step events."""
    from fastapi.testclient import TestClient

    _clear_tokens()
    app = _make_setup_app()
    client = TestClient(app)
    _insert_token("st_setup_prog")

    resp = client.post(
        "/api/setup/progress",
        json={"token": "st_setup_prog", "step": "connected", "detail": ""},
    )
    assert resp.status_code == 200
    assert len(_setup_tokens["st_setup_prog"]["progress"]) == 1
    assert _setup_tokens["st_setup_prog"]["progress"][0]["step"] == "connected"


def test_api_progress_invalid_step():
    """POST /api/setup/progress rejects invalid step names."""
    from fastapi.testclient import TestClient

    _clear_tokens()
    app = _make_setup_app()
    client = TestClient(app)
    _insert_token("st_setup_bad")

    resp = client.post(
        "/api/setup/progress",
        json={"token": "st_setup_bad", "step": "dancing", "detail": ""},
    )
    assert resp.status_code == 400


def test_api_events_invalid_token():
    """GET /api/setup/events rejects invalid tokens."""
    from fastapi.testclient import TestClient

    _clear_tokens()
    app = _make_setup_app()
    client = TestClient(app)

    resp = client.get("/api/setup/events?token=st_setup_fake")
    assert resp.status_code == 400


def test_api_events_streams_and_closes():
    """GET /api/setup/events streams progress and closes on 'complete'."""
    import json as _json
    from fastapi.testclient import TestClient

    _clear_tokens()
    app = _make_setup_app()
    client = TestClient(app)
    _insert_token("st_setup_sse", progress=[
        {"step": "connected", "detail": "", "timestamp": "2026-01-01T00:00:00"},
        {"step": "importing", "detail": "47/127", "timestamp": "2026-01-01T00:00:01"},
        {"step": "complete", "detail": "done", "timestamp": "2026-01-01T00:00:02"},
    ])

    resp = client.get("/api/setup/events?token=st_setup_sse")
    assert resp.status_code == 200
    assert "text/event-stream" in resp.headers["content-type"]

    data_lines = [l for l in resp.text.strip().split("\n") if l.startswith("data: ")]
    assert len(data_lines) == 3

    events = [_json.loads(l.removeprefix("data: ")) for l in data_lines]
    assert events[0]["step"] == "connected"
    assert events[1]["detail"] == "47/127"
    assert events[2]["step"] == "complete"


def test_api_token_expiry_15_min():
    """Tokens expire after 15 minutes."""
    from fastapi.testclient import TestClient

    _clear_tokens()
    app = _make_setup_app()
    client = TestClient(app)

    # Token created 14 minutes ago — still valid
    recent = (datetime.now(timezone.utc) - timedelta(minutes=14)).isoformat()
    _insert_token("st_setup_14m", created_at=recent)
    resp = client.post("/api/setup/validate", json={"token": "st_setup_14m"})
    assert resp.status_code == 200

    # Token created 16 minutes ago — expired
    old = (datetime.now(timezone.utc) - timedelta(minutes=16)).isoformat()
    _insert_token("st_setup_16m", created_at=old)
    resp = client.post("/api/setup/validate", json={"token": "st_setup_16m"})
    assert resp.status_code == 400
