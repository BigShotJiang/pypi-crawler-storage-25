from collections.abc import Hashable, Mapping
from threading import Lock
from typing import Any, Optional

from ..core import (
    NOT_FOUND,
    CacheEntry,
    MetricsCollector,
    Orchestrator,
    Policy,
    Storage,
)


class SimpleOrchestrator(Orchestrator):
    """
    Realization of simple orchestrator that manages with a cache storage and
    only with a sinlge policy if it was provided, otherwise only stores a cache.
    Uses when needed simplified and lighter version of cacher.

    SimpleOrchestrator is responsible for:
        - storage of data (Storage)
        - application of policy if its not None (Policy)
        - collecting metrics (MetricsCollector)
        - thread-safety (Lock)
        - cache size control (max_size)
        - limit of evictions when cache is raised max size (eviction limit)

    Logic of work procces:
        - get: checks for contains -> validity (if policy is provided) -> updates metadata -> notifies policy
        - put: adds/updates entry -> calls eviction when raised max size (only if policy and max_size is provided)
        - delete/clear: removing and notifying policy (only if it was provided)
        - stats: returns stats of metrics and storage

    Notes:
        - If you want to use policy or max size ou need to provide both of them.
    """

    def __init__(
        self,
        policy: Optional[Policy],
        storage: Storage,
        metrics: MetricsCollector,
        max_size: Optional[int],
        eviction_limit: Optional[int],
    ) -> None:
        """Initializes orchestrator all dependency attribute objects."""
        self._policy: Optional[Policy] = policy
        self._storage: Storage = storage
        self._metrics: MetricsCollector = metrics
        self._max_size: Optional[int] = max_size
        self._eviction_limit: Optional[int] = eviction_limit
        self._lock: Lock = Lock()

    def _force_remove(self, key: Hashable, entry: CacheEntry) -> None:
        """
        Removes entry from storage and notifies policy about that if policy is not None.
        Calls only inside locker (thread-safety).
        Needs only for public methods to DRY (Do no Repeat Yourself).
        """
        self._storage.delete(key)

        if self._policy is not None:
            self._policy.on_remove(key, entry)

    def _enforce_size_limit(self) -> None:
        """
        Evicts entries if size of storage raised max_size.
        If policy or max_size or evictions_limit is not
        provived silently ignores and does nothing. Cause both three objects
        depends each other to work properly.

        Steps:
            While size is bigger that max_size:
                - requests policy for evicting candidates (until raises evictions limit)
                - if policy returns empty sequence - breaks (safety)
                - removes received keys from storage
                - increases evictions counter in metrics
        """
        if (
            self._policy is None
            or self._max_size is None
            or self._eviction_limit is None
        ):
            return

        while self._storage.size() > self._max_size:
            candidates = self._policy.evict_candidates(limit=self._eviction_limit)
            if not candidates:
                break

            for candidate in candidates:
                entry = self._storage.get(candidate)
                if entry is None:
                    continue

                self._force_remove(candidate, entry)
                self._metrics.evict(candidate)

    def get(self, key: Hashable) -> Optional[Any]:
        """
        Returns value of entry under the provided key, if it exists, otherwise
        returns NOT_FOUND object to avoid confusing NoneType object with not founded.

        How it works:
            1. Locker blocks acces to other threads (thread-safety).
            2. Getts entry from storage.
            3. If entry is not found in storage, increases misses count and return NOT_FOUND.
            4. If entry is founded but policy (if it was provided) decides this entry is not valid removes it and
                                    increases misses count after returns NOT_FOUND.
            5. If entry is exists and it's valid:
                - updates metadata of entry (entry.touch())
                - notifies policy only if it was provided (policy.on_acces())
                - increases hits count in metrics
                - returns value of entry
        """
        with self._lock:
            entry = self._storage.get(key)
            if entry is None:
                self._metrics.miss(key)
                return NOT_FOUND

            if self._policy is not None and not self._policy.is_valid(key, entry):
                self._force_remove(key, entry)
                self._metrics.miss(key)
                self._metrics.evict(key)
                return NOT_FOUND

            entry.touch()

            if self._policy is not None:
                self._policy.on_access(key, entry)

            self._metrics.hit(key)

        return entry.value

    def put(self, key: Hashable, value: Any) -> None:
        """
        Wraps value into an entry object and adds it to the storage or updates.

        How it works:
            1. Locker blocks acces to other threads (thread-safety).
            2. If key is exists in storage, removes it and notifies policy.
            3. Wraps value into an entry object.
            4. Stores it to the storage.
            5. Notifies policy (on_add) only if it was provided.
            6. Checks storage raised max size or not.
        """
        with self._lock:
            old_entry = self._storage.get(key)
            if old_entry is not None:
                self._force_remove(key, old_entry)

            entry = CacheEntry(value=value)

            self._storage.put(key, entry)

            if self._policy is not None:
                self._policy.on_add(key, entry)

            self._enforce_size_limit()

    def delete(self, key: Hashable) -> None:
        """Removes entry from storage and notifies policy (only if it was provided)."""
        with self._lock:
            entry = self._storage.get(key)
            if entry is not None:
                self._force_remove(key, entry)

    def clear(self) -> None:
        """
        Completely resets storage and
        restores to default all policy and metrics internal stats.
        """
        with self._lock:
            self._storage.clear()
            if self._policy is not None:
                self._policy.on_clear()
            self._metrics.reset()

    def stats(self) -> Mapping:
        """
        Returns mapping object of stats.
        Includes statistics of metric and storage.
        """
        with self._lock:
            stats = {}
            stats["metrics"] = self._metrics.stats()
            stats["storage"] = {"size": self._storage.size()}

        return stats
