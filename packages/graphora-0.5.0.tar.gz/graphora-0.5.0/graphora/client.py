"""
Graphora Client

Main client class for interacting with the Graphora API.
"""

import json
import os
import time
import warnings
from pathlib import Path
from typing import Any, BinaryIO, Dict, List, Optional, Union

import requests

from graphora.models import (
    OntologyResponse,
    TransformResponse,
    TransformStatus,
    TransformRunStatus,
    MergeInitResponse,
    MergeState,
    GraphResponse,
    DocumentMetadata,
    ChangeLog,
    ResolutionStrategy,
    SaveGraphRequest,
    SaveGraphResponse,
    QualityResults,
    QualityRuleType,
    QualitySeverity,
    ApprovalRequest,
    RejectQualityRequest,
    QualityApprovalResponse,
    QualityRejectionResponse,
    QualityViolationsResponse,
    QualitySummaryResponse,
    QualityDeleteResponse,
    QualityHealthResponse,
    RecentRunsResponse,
    DashboardSummaryResponse,
    DashboardPerformanceResponse,
    DashboardQualityResponse,
)
from graphora.exceptions import GraphoraAPIError, GraphoraClientError
from graphora.utils import get_api_url


class GraphoraClient:
    """
    Client for interacting with the Graphora API.
    
    This client provides methods for all major Graphora API endpoints, including:
    - Ontology management
    - Document transformation
    - Graph merging
    - Graph querying and manipulation
    - Quality validation and approval workflows
    """
    
    def __init__(
        self,
        base_url: Optional[str] = None,
        auth_token: Optional[str] = None,
        user_id: Optional[str] = None,
        timeout: int = 60,
    ):
        """
        Initialize a new Graphora client.
        
        Args:
            base_url: Base URL of the Graphora API. If omitted, the client uses the
                `GRAPHORA_API_URL` environment variable or the value derived from
                `graphora.utils.get_api_url()`.
            auth_token: Clerk-issued bearer token for authentication. If not provided,
                the client will read GRAPHORA_AUTH_TOKEN from the environment.
            user_id: Optional user identifier for client-side bookkeeping (not sent automatically)
            timeout: Request timeout in seconds
        """
        resolved_base_url = base_url or os.environ.get("GRAPHORA_API_URL") or get_api_url()
        self.base_url = resolved_base_url.rstrip('/')
        env_token = os.environ.get("GRAPHORA_AUTH_TOKEN")
        self.auth_token = auth_token or env_token
        if not self.auth_token:
            raise ValueError(
                "A Clerk bearer token is required. Provide it via auth_token="
                " or the GRAPHORA_AUTH_TOKEN environment variable."
            )
        if os.environ.get("GRAPHORA_API_KEY") and not auth_token:
            warnings.warn(
                "GRAPHORA_API_KEY is deprecated; use GRAPHORA_AUTH_TOKEN instead.",
                DeprecationWarning,
                stacklevel=2,
            )
        self.user_id = user_id
        self.timeout = timeout
        self.api_version = "v1"

    @property
    def headers(self) -> Dict[str, str]:
        """Get headers for API requests."""
        headers = {
            "Accept": "application/json",
        }
        if self.auth_token:
            headers["Authorization"] = f"Bearer {self.auth_token}"
        return headers
    
    def _build_url(self, endpoint: str) -> str:
        """Build a full URL for the given endpoint."""
        if endpoint.startswith("/"):
            endpoint = endpoint[1:]
        return f"{self.base_url}/api/{self.api_version}/{endpoint}"

    def _build_system_url(self, path: str) -> str:
        """Build URL for system-level endpoints that are not versioned."""
        if not path.startswith("/"):
            path = "/" + path
        return f"{self.base_url}{path}"
    
    def _handle_response(self, response: requests.Response) -> Dict[str, Any]:
        """Handle API response and raise appropriate exceptions."""
        try:
            response.raise_for_status()
            return response.json()
        except requests.exceptions.HTTPError as e:
            error_msg = str(e)
            try:
                error_data = response.json()
                if "detail" in error_data:
                    error_msg = error_data["detail"]
            except (ValueError, json.JSONDecodeError):
                pass
            raise GraphoraAPIError(f"API error: {error_msg}", response.status_code)
        except (ValueError, json.JSONDecodeError):
            raise GraphoraClientError("Invalid JSON response from API")
        except requests.exceptions.RequestException as e:
            raise GraphoraClientError(f"Request failed: {str(e)}")
    
    # Ontology Endpoints
    
    def register_ontology(self, ontology_yaml: str) -> OntologyResponse:
        """
        Register, validate and upload an ontology definition.
        
        Args:
            ontology_yaml: Ontology definition in YAML format
            
        Returns:
            OntologyResponse with the ID of the validated ontology
        """
        url = self._build_url("ontology")
        data = {"text": ontology_yaml}
        response = requests.post(url, json=data, headers=self.headers, timeout=self.timeout)
        result = self._handle_response(response)
        return OntologyResponse(**result)
    
    def get_ontology(self, ontology_id: str) -> str:
        """
        Retrieve an ontology by ID.
        
        Args:
            ontology_id: ID of the ontology to retrieve
            
        Returns:
            Ontology YAML text
        """
        url = self._build_url(f"ontology/{ontology_id}")
        response = requests.get(url, headers=self.headers, timeout=self.timeout)
        result = self._handle_response(response)
        return result.get("text", "")
    
    # Transform Endpoints
    
    def transform(
        self,
        ontology_id: str,
        files: List[Union[str, Path, BinaryIO]],
        metadata: Optional[List[DocumentMetadata]] = None
    ) -> TransformResponse:
        """
        Upload documents for processing.
        
        Args:
            ontology_id: ID of the ontology to use for transformation
            files: List of files to process (paths or file-like objects)
            metadata: Optional metadata for each document
            
        Returns:
            TransformResponse with the ID for tracking progress
        """
        url = self._build_url(f"transform/{ontology_id}/upload")
        
        multipart_files: List[Any] = []
        opened_files: List[BinaryIO] = []
        for i, file in enumerate(files):
            if isinstance(file, (str, Path)):
                path = Path(file)
                filename = path.name
                file_obj = open(path, "rb")
                opened_files.append(file_obj)
            else:
                filename = getattr(file, "name", f"file_{i}")
                file_obj = file

            multipart_files.append(("files", (filename, file_obj)))

        try:
            response = requests.post(
                url,
                files=multipart_files,
                headers=self.headers,
                timeout=self.timeout,
            )
        finally:
            for fh in opened_files:
                try:
                    fh.close()
                except Exception:  # pragma: no cover - best effort cleanup
                    pass

        result = self._handle_response(response)
        return TransformResponse(**result)
    
    def get_transform_status(
        self,
        transform_id: str,
        include_metrics: bool = True
    ) -> TransformStatus:
        """
        Get the status of a transformation.
        
        Args:
            transform_id: ID of the transformation to check
            include_metrics: Whether to include resource metrics
            
        Returns:
            TransformStatus with current progress
        """
        url = self._build_url(f"transform/status/{transform_id}")
        params = {"include_metrics": include_metrics}
        response = requests.get(url, params=params, headers=self.headers, timeout=self.timeout)
        result = self._handle_response(response)
        return TransformStatus(**result)
    
    def wait_for_transform(
        self,
        transform_id: str,
        timeout: int = 300,
        poll_interval: int = 5
    ) -> TransformStatus:
        """
        Wait for a transformation to complete.
        
        Args:
            transform_id: ID of the transformation to wait for
            timeout: Maximum time to wait in seconds
            poll_interval: Time between status checks in seconds
            
        Returns:
            Final TransformStatus
            
        Raises:
            GraphoraClientError: If the transformation fails or times out
        """
        start_time = time.time()
        while time.time() - start_time < timeout:
            status = self.get_transform_status(transform_id)
            if status.overall_status in (
                TransformRunStatus.COMPLETED,
                TransformRunStatus.FAILED,
            ):
                return status
            time.sleep(poll_interval)
        
        raise GraphoraClientError(f"Transform {transform_id} timed out after {timeout} seconds")
    
    def cleanup_transform(self, transform_id: str) -> bool:
        """
        Clean up transformation data.
        
        Args:
            transform_id: ID of the transformation to clean up
            
        Returns:
            True if cleanup was successful
        """
        url = self._build_url(f"transform/status/{transform_id}/cleanup")
        response = requests.post(url, headers=self.headers, timeout=self.timeout)
        self._handle_response(response)
        return True
    
    def get_transformed_graph(
        self,
        transform_id: str,
        limit: int = 1000,
        skip: int = 0
    ) -> GraphResponse:
        """
        Retrieve graph data by transform ID.
        
        Args:
            transform_id: ID of the transformation
            limit: Maximum number of nodes to return
            skip: Number of nodes to skip for pagination
            
        Returns:
            GraphResponse with nodes and edges
        """
        url = self._build_url(f"graph/{transform_id}")
        params = {"limit": limit, "skip": skip}
        response = requests.get(url, params=params, headers=self.headers, timeout=self.timeout)
        result = self._handle_response(response)
        return GraphResponse(**result)

    def find_node(
        self,
        transform_id: str,
        node_id: str,
        *,
        page_size: int = 1000,
        max_pages: int = 10,
    ) -> Optional[Dict[str, Any]]:
        """Locate a node by id, paginating ``get_transformed_graph``
        until found or exhausted.

        The REST API has no "fetch one node" endpoint, so evidence
        lookup has to scan. Returns the full graph slice containing
        the node (so callers also have its incident edges available
        for context) or ``None`` when the node isn't present in any
        page up to ``max_pages``.

        Used by ``get_evidence`` to back ``graphora explain <node>``;
        ``max_pages * page_size`` covers the server-side hard cap
        of 10,000 nodes per graph.
        """
        for page in range(max_pages):
            skip = page * page_size
            data = self.get_transformed_graph(
                transform_id, limit=page_size, skip=skip
            )
            nodes = data.nodes or []
            if any(getattr(n, "id", None) == node_id for n in nodes):
                return data.model_dump() if hasattr(data, "model_dump") else dict(data)
            if len(nodes) < page_size:
                break
        return None

    def find_edge(
        self,
        transform_id: str,
        edge_id: str,
        *,
        page_size: int = 1000,
        max_pages: int = 10,
    ) -> Optional[Dict[str, Any]]:
        """Locate an edge by id, paginating until found or exhausted.

        Mirror of ``find_node`` for edges. Pagination scans node
        pages because the server keys pagination on nodes; each page
        ships all edges incident to nodes in that window. Returns
        the graph slice or ``None`` on exhaust.

        Powers the edge path of ``get_evidence`` /
        ``graphora explain <edge>``.
        """
        for page in range(max_pages):
            skip = page * page_size
            data = self.get_transformed_graph(
                transform_id, limit=page_size, skip=skip
            )
            edges = data.edges or []
            if any(getattr(e, "id", None) == edge_id for e in edges):
                return data.model_dump() if hasattr(data, "model_dump") else dict(data)
            nodes = data.nodes or []
            if len(nodes) < page_size:
                break
        return None

    def get_decisions(
        self,
        transform_id: str,
        *,
        node_id: Optional[str] = None,
        edge_id: Optional[str] = None,
    ) -> Dict[str, Any]:
        """Fetch Decision Log entries for a transform.

        Pass ``node_id`` OR ``edge_id`` (mutually exclusive) to
        narrow to a single target's decisions. The endpoint always
        returns the schema-decision prefix for causation context
        regardless of which target kind is queried. Without either
        id, returns schema-only.

        Returns ``{decision_log: [...], alternatives: [...]}``. The
        endpoint rejects setting both ids with a 400.
        """
        if node_id and edge_id:
            raise GraphoraClientError(
                "node_id and edge_id are mutually exclusive; pass exactly one."
            )
        url = self._build_url(f"graph/{transform_id}/decisions")
        params: Dict[str, Any] = {}
        if node_id is not None:
            params["node_id"] = node_id
        if edge_id is not None:
            params["edge_id"] = edge_id
        response = requests.get(
            url, params=params, headers=self.headers, timeout=self.timeout
        )
        return self._handle_response(response)

    def get_evidence(
        self,
        transform_id: str,
        *,
        node_id: Optional[str] = None,
        edge_id: Optional[str] = None,
    ) -> Dict[str, Any]:
        """Composite evidence lookup for a node OR an edge.

        Mirrors the MCP server's ``get_evidence`` shape so the CLI
        and the agent surface render identical payloads. Returns a
        discriminated dict:

          * ``kind=node``: ``{kind, node, incoming_edges, outgoing_edges,
            evidence, decision_log, alternatives}``
          * ``kind=edge``: ``{kind, edge, source_node, target_node,
            evidence, decision_log, alternatives}``

        Where ``evidence`` is the source-span subset of the target's
        properties (source_chunk_id, source_text, document_name,
        page_number, extraction_confidence, plus B0-prov-extend
        fields like extractor_model, prompt_version, validator_score).
        ``decision_log`` is the schema-prefixed list of Decision Log
        entries; ``alternatives`` aggregates candidate entities the
        pipeline considered.

        Exactly one of ``node_id`` / ``edge_id`` must be supplied.
        """
        if bool(node_id) == bool(edge_id):
            raise GraphoraClientError(
                "Provide exactly one of node_id or edge_id (not both, not neither)."
            )

        if node_id:
            return self._get_node_evidence(transform_id, node_id)
        assert edge_id is not None
        return self._get_edge_evidence(transform_id, edge_id)

    def _get_node_evidence(
        self, transform_id: str, node_id: str
    ) -> Dict[str, Any]:
        data = self.find_node(transform_id, node_id)
        if data is None:
            return {
                "kind": "node",
                "node": None,
                "incoming_edges": [],
                "outgoing_edges": [],
                "evidence": {},
                "decision_log": [],
                "alternatives": [],
            }

        nodes = data.get("nodes", []) or []
        edges = data.get("edges", []) or []
        node = next((n for n in nodes if n.get("id") == node_id), None)
        if node is None:
            return {
                "kind": "node",
                "node": None,
                "incoming_edges": [],
                "outgoing_edges": [],
                "evidence": {},
                "decision_log": [],
                "alternatives": [],
            }

        incoming = [e for e in edges if e.get("target") == node_id]
        outgoing = [e for e in edges if e.get("source") == node_id]
        decisions = self._fetch_decisions_safely(transform_id, node_id=node_id)

        return {
            "kind": "node",
            "node": node,
            "incoming_edges": incoming,
            "outgoing_edges": outgoing,
            "evidence": _extract_evidence_fields(node.get("properties", {})),
            "decision_log": decisions.get("decision_log", []),
            "alternatives": decisions.get("alternatives", []),
        }

    def _get_edge_evidence(
        self, transform_id: str, edge_id: str
    ) -> Dict[str, Any]:
        data = self.find_edge(transform_id, edge_id)
        if data is None:
            return {
                "kind": "edge",
                "edge": None,
                "source_node": None,
                "target_node": None,
                "evidence": {},
                "decision_log": [],
                "alternatives": [],
            }

        nodes = data.get("nodes", []) or []
        edges = data.get("edges", []) or []
        edge = next((e for e in edges if e.get("id") == edge_id), None)
        if edge is None:
            return {
                "kind": "edge",
                "edge": None,
                "source_node": None,
                "target_node": None,
                "evidence": {},
                "decision_log": [],
                "alternatives": [],
            }

        source = next((n for n in nodes if n.get("id") == edge.get("source")), None)
        target = next((n for n in nodes if n.get("id") == edge.get("target")), None)
        decisions = self._fetch_decisions_safely(transform_id, edge_id=edge_id)

        return {
            "kind": "edge",
            "edge": edge,
            "source_node": source,
            "target_node": target,
            "evidence": _extract_evidence_fields(edge.get("properties", {})),
            "decision_log": decisions.get("decision_log", []),
            "alternatives": decisions.get("alternatives", []),
        }

    def _fetch_decisions_safely(
        self,
        transform_id: str,
        *,
        node_id: Optional[str] = None,
        edge_id: Optional[str] = None,
    ) -> Dict[str, Any]:
        """Decisions are observability — a transient error fetching
        them must not blank the rest of the evidence response. Match
        the MCP server's fail-open semantics (commit eb22a79 over
        in graphora-server) so the agent always sees the source-
        span payload even if /decisions is degraded."""
        try:
            return self.get_decisions(
                transform_id, node_id=node_id, edge_id=edge_id
            )
        except (GraphoraAPIError, GraphoraClientError, requests.RequestException):
            return {"decision_log": [], "alternatives": []}

    def update_transform_graph(
        self,
        transform_id: str,
        changes: SaveGraphRequest
    ) -> SaveGraphResponse:
        """
        Save bulk modifications to the graph.
        
        Args:
            transform_id: ID of the transformation
            changes: Batch of modifications to apply
            
        Returns:
            SaveGraphResponse with updated graph data
        """
        url = self._build_url(f"graph/{transform_id}")
        payload = changes.model_dump(exclude_none=True)
        response = requests.put(
            url, json=payload, headers=self.headers, timeout=self.timeout
        )
        result = self._handle_response(response)
        return SaveGraphResponse(**result)
    
    # Diff Endpoints

    def diff_transforms(
        self,
        base_transform_id: str,
        compare_transform_id: str,
    ) -> Dict[str, Any]:
        """Compute the structured graph-state diff between two transforms.

        Backed by graphora-server's GET /api/v1/graph/{base}/diff/
        {compare} (B3-diff, commit a75cd73). Useful when re-running
        a transform after prompt tweaks or ontology changes —
        callers inspect the added/removed/changed delta before
        accepting / publishing the new extraction.

        Both transforms must belong to the authenticated user; the
        server's storage-layer routing scopes by user_id, so a
        request for another user's transform_id surfaces the same
        "not found" treatment as a missing transform.

        Args:
            base_transform_id: The "before" transform.
            compare_transform_id: The "after" transform.

        Returns:
            Raw diff dict with keys ``base_transform_id``,
            ``compare_transform_id``, ``summary`` (nested
            ``{nodes: {added, removed, changed, unchanged},
            edges: {...}}``), ``added_nodes`` / ``removed_nodes``
            (full Node payloads), ``changed_nodes`` (each with
            ``{canonical_id, type, base_id, compare_id,
            property_changes: {<key>: {base, compare}}}``), and
            the three matching edge lists.

        Raises:
            GraphoraAPIError: 413 when either side's graph exceeds
                the diff loader's 10k-node cap (mirrors the
                /golden/score truncation guard); 404 / 5xx
                otherwise.
        """
        url = self._build_url(
            f"graph/{base_transform_id}/diff/{compare_transform_id}"
        )
        response = requests.get(url, headers=self.headers, timeout=self.timeout)
        return self._handle_response(response)

    # Golden Corpus Endpoints

    def score_against_golden(
        self,
        expected: Dict[str, Any],
        transform_id: str,
        corpus_slug: Optional[str] = None,
    ) -> Dict[str, Any]:
        """Score a live transform against a caller-supplied ground-truth graph.

        Backed by graphora-server's POST /api/v1/golden/score
        (b4-test, commit 9fb4909 + 834d724). The runner side of
        the contract: the CLI ``graphora test`` command composes
        register_ontology → transform → wait_for_transform with
        this method to produce a per-document P/R/F1 report.

        Args:
            expected: Ground-truth graph dict, same shape as the
                ``GraphResponse`` returned by ``get_transformed_graph``
                (nodes/edges arrays with type-prefixed canonical_id
                + canonical_key in properties). Typically loaded
                from a ``golden/<slug>/expected.json`` corpus file.
            transform_id: A live, user-owned transform whose
                extraction will be compared against ``expected``.
                Missing or cross-tenant transform_ids surface as
                an empty actual graph — scoring proceeds and
                produces an all-FN report (every expected node
                becomes a false negative, recall 0). Callers
                should treat 0-recall as a regression signal that
                may also mean a malformed transform_id.
            corpus_slug: Optional corpus directory name. Echoed
                back on the response so multi-document batch
                runners can tag each report.

        Returns:
            Raw ScoringReport dict (per-type and aggregate
            precision/recall/F1 plus TP/FP/FN counts). The shape
            is pinned by graphora_server.services.golden_corpus.scorer.

        Raises:
            GraphoraAPIError: 413 when the actual graph exceeds
                the diff loader's 10k-node cap (mirrors /diff).
                422 if ``expected`` violates the GraphResponse
                schema.
        """
        url = self._build_url("golden/score")
        payload: Dict[str, Any] = {
            "expected": expected,
            "transform_id": transform_id,
        }
        if corpus_slug:
            payload["corpus_slug"] = corpus_slug
        response = requests.post(
            url, json=payload, headers=self.headers, timeout=self.timeout
        )
        return self._handle_response(response)

    # Scenario Endpoints

    def create_scenario(
        self,
        transform_id: str,
        name: str,
        description: Optional[str] = None,
    ) -> Dict[str, Any]:
        """Snapshot a transform's current graph into a new scenario.

        Backed by graphora-server's POST /api/v1/scenarios
        (B6-scenario slice 1, commit d7a1f6e + 088692b). A
        scenario is a named, point-in-time snapshot — the
        primitive behind "what if we re-ran with this ontology
        change?" or "what if Alice and Alicia are the same
        entity?" workflows.

        Args:
            transform_id: Live transform whose current graph is
                snapshotted into the new scenario. Must belong
                to the authenticated user.
            name: Human-readable scenario name. Unique per
                (user, transform_id) — a duplicate surfaces as
                ``GraphoraAPIError`` with status_code 409.
            description: Optional free-form description (why this
                scenario was created).

        Returns:
            Full scenario record dict: id, transform_id, name,
            description, created_at, node_count, edge_count,
            and the embedded ``graph`` payload (GraphResponse
            shape).

        Raises:
            GraphoraAPIError: 409 on duplicate name; 404 when
                the transform doesn't exist or belongs to
                another user; 413 when the transform exceeds
                the 10k-node diff cap (mirrors /diff and
                /golden/score).
        """
        url = self._build_url("scenarios")
        payload: Dict[str, Any] = {
            "transform_id": transform_id,
            "name": name,
        }
        if description is not None:
            payload["description"] = description
        response = requests.post(
            url, json=payload, headers=self.headers, timeout=self.timeout
        )
        return self._handle_response(response)

    def list_scenarios(self) -> List[Dict[str, Any]]:
        """List scenarios owned by the authenticated user, newest first.

        Returns the lightweight summary shape (no embedded graph)
        so the list stays fast even with many large scenarios.
        Use ``get_scenario(id)`` to fetch the full record
        including the graph payload.
        """
        url = self._build_url("scenarios")
        response = requests.get(
            url, headers=self.headers, timeout=self.timeout
        )
        return self._handle_response(response)

    def get_scenario(self, scenario_id: str) -> Dict[str, Any]:
        """Fetch one scenario by id, including the materialized graph.

        Raises:
            GraphoraAPIError: 404 when the scenario doesn't
                exist OR belongs to another tenant (the server
                doesn't distinguish — see /api/v1/scenarios docs).
        """
        url = self._build_url(f"scenarios/{scenario_id}")
        response = requests.get(
            url, headers=self.headers, timeout=self.timeout
        )
        return self._handle_response(response)

    def delete_scenario(self, scenario_id: str) -> None:
        """Delete one scenario by id.

        Raises:
            GraphoraAPIError: 404 when the scenario doesn't
                exist OR belongs to another tenant (intentionally
                not idempotent — see the server's delete docstring
                for the timing-side-channel rationale).
        """
        url = self._build_url(f"scenarios/{scenario_id}")
        response = requests.delete(
            url, headers=self.headers, timeout=self.timeout
        )
        # 204 No Content has no body — handle response would try
        # to .json() it. Use raise_for_status directly and skip
        # the JSON parse.
        try:
            response.raise_for_status()
        except requests.exceptions.HTTPError as exc:
            error_msg = str(exc)
            try:
                error_data = response.json()
                if "detail" in error_data:
                    error_msg = error_data["detail"]
            except (ValueError, json.JSONDecodeError):
                pass
            raise GraphoraAPIError(
                f"API error: {error_msg}", response.status_code
            )

    # Merge Endpoints

    def start_merge(
        self,
        session_id: str,
        transform_id: str,
        merge_id: Optional[str] = None,
    ) -> MergeInitResponse:
        """
        Start a new merge process.
        
        Args:
            session_id: Session ID (ontology ID)
            transform_id: ID of the transformation to merge
            merge_id: Optional custom merge ID
            
        Returns:
            MergeInitResponse with the ID for tracking progress
        """
        url = self._build_url(f"merge/{session_id}/{transform_id}/start")
        params = {}
        if merge_id:
            params["merge_id"] = merge_id
            
        response = requests.post(url, params=params, headers=self.headers, timeout=self.timeout)
        result = self._handle_response(response)
        return MergeInitResponse(**result)
    
    def get_merge_status(self, merge_id: str) -> MergeState:
        """
        Get the status of a merge process.
        
        Args:
            merge_id: ID of the merge to check
            
        Returns:
            MergeStatus with current progress
        """
        url = self._build_url(f"merge/{merge_id}/status")
        response = requests.get(url, headers=self.headers, timeout=self.timeout)
        result = self._handle_response(response)
        if isinstance(result, str):
            return MergeState(result)
        raise GraphoraClientError(
            f"Unexpected merge status payload for {merge_id}: {result}"
        )
    
    def get_conflicts(self, merge_id: str) -> List[ChangeLog]:
        """
        Get conflicts for a merge process.
        
        Args:
            merge_id: ID of the merge process
            
        Returns:
            List of conflicts requiring resolution
        """
        url = self._build_url(f"merge/{merge_id}/conflicts")
        response = requests.get(url, headers=self.headers, timeout=self.timeout)
        result = self._handle_response(response)
        return [ChangeLog(**item) for item in result]
    
    def resolve_conflict(
        self,
        merge_id: str,
        conflict_id: str,
        changed_props: Dict[str, Any],
        resolution: ResolutionStrategy,
        learning_comment: str = ""
    ) -> bool:
        """
        Apply a resolution to a specific conflict.
        
        Args:
            merge_id: ID of the merge process
            conflict_id: ID of the conflict to resolve
            changed_props: Properties that were changed
            resolution: The resolution decision
            learning_comment: Comment on the resolution
            
        Returns:
            True if the resolution was applied successfully
        """
        url = self._build_url(f"merge/{merge_id}/conflicts/{conflict_id}/resolve")
        resolution_value = resolution.value if isinstance(resolution, ResolutionStrategy) else resolution
        data = {
            "changed_props": changed_props,
            "resolution": resolution_value,
            "learning_comment": learning_comment,
        }
        response = requests.post(url, json=data, headers=self.headers, timeout=self.timeout)
        result = self._handle_response(response)
        return result
    
    def get_merge_statistics(self, merge_id: str) -> Dict[str, Any]:
        """
        Get detailed statistics of a merge operation.
        
        Args:
            merge_id: ID of the merge process
            
        Returns:
            Dictionary of merge statistics
        """
        url = self._build_url(f"merge/statistics/{merge_id}")
        response = requests.get(url, headers=self.headers, timeout=self.timeout)
        return self._handle_response(response)
    
    def get_merged_graph(self, merge_id: str, transform_id: str) -> GraphResponse:
        """
        Retrieve graph data for a merge process.
        
        Args:
            merge_id: ID of the merge process
            transform_id: ID of the transformation
            
        Returns:
            GraphResponse with nodes and edges
        """
        url = self._build_url(f"merge/graph/{merge_id}/{transform_id}")
        response = requests.get(url, headers=self.headers, timeout=self.timeout)
        result = self._handle_response(response)
        return GraphResponse(**result)
    
    # Quality Validation Endpoints
    
    def get_quality_results(self, transform_id: str) -> QualityResults:
        """
        Get quality validation results for a transform.
        
        Args:
            transform_id: ID of the transformation to get quality results for
            
        Returns:
            QualityResults with validation metrics, violations, and scores
        """
        url = self._build_url(f"quality/results/{transform_id}")
        response = requests.get(url, headers=self.headers, timeout=self.timeout)
        result = self._handle_response(response)
        return QualityResults(**result)
    
    def approve_quality_results(
        self, 
        transform_id: str, 
        approval_comment: Optional[str] = None
    ) -> QualityApprovalResponse:
        """
        Approve quality validation results and proceed to merge.
        
        Args:
            transform_id: ID of the transformation to approve
            approval_comment: Optional comment about the approval
            
        Returns:
            QualityApprovalResponse confirming the approval
        """
        url = self._build_url(f"quality/approve/{transform_id}")
        data = ApprovalRequest(approval_comment=approval_comment).dict()
        response = requests.post(url, json=data, headers=self.headers, timeout=self.timeout)
        result = self._handle_response(response)
        return QualityApprovalResponse(**result)
    
    def reject_quality_results(
        self, 
        transform_id: str, 
        rejection_reason: str
    ) -> QualityRejectionResponse:
        """
        Reject quality validation results and stop the process.
        
        Args:
            transform_id: ID of the transformation to reject
            rejection_reason: Required reason for rejecting the results
            
        Returns:
            QualityRejectionResponse confirming the rejection
        """
        url = self._build_url(f"quality/reject/{transform_id}")
        data = RejectQualityRequest(rejection_reason=rejection_reason).dict()
        response = requests.post(url, json=data, headers=self.headers, timeout=self.timeout)
        result = self._handle_response(response)
        return QualityRejectionResponse(**result)
    
    def get_quality_violations(
        self,
        transform_id: str,
        violation_type: Optional[QualityRuleType] = None,
        severity: Optional[QualitySeverity] = None,
        entity_type: Optional[str] = None,
        limit: int = 100,
        offset: int = 0
    ) -> QualityViolationsResponse:
        """
        Get detailed quality violations with filtering and pagination.
        
        Args:
            transform_id: ID of the transformation
            violation_type: Filter by rule type (format, business, etc.)
            severity: Filter by severity level (error, warning, info)
            entity_type: Filter by entity type
            limit: Maximum number of violations to return (1-1000)
            offset: Number of violations to skip for pagination
            
        Returns:
            QualityViolationsResponse with filtered violations
        """
        url = self._build_url(f"quality/violations/{transform_id}")
        params = {
            "limit": min(max(limit, 1), 1000),  # Ensure within bounds
            "offset": max(offset, 0)  # Ensure non-negative
        }
        
        if violation_type:
            params["violation_type"] = violation_type
        if severity:
            params["severity"] = severity
        if entity_type:
            params["entity_type"] = entity_type
            
        response = requests.get(url, params=params, headers=self.headers, timeout=self.timeout)
        result = self._handle_response(response)
        return QualityViolationsResponse(**result)
    
    def get_quality_summary(self, limit: int = 10) -> QualitySummaryResponse:
        """
        Get summary of recent quality results for the user.
        
        Args:
            limit: Number of recent results to return (1-50)
            
        Returns:
            QualitySummaryResponse with recent quality result summaries
        """
        url = self._build_url("quality/summary")
        params = {"limit": min(max(limit, 1), 50)}  # Ensure within bounds
        response = requests.get(url, params=params, headers=self.headers, timeout=self.timeout)
        result = self._handle_response(response)
        return QualitySummaryResponse(**result)
    
    def delete_quality_results(self, transform_id: str) -> QualityDeleteResponse:
        """
        Delete quality validation results for a transform.
        
        Args:
            transform_id: ID of the transformation to delete results for
            
        Returns:
            QualityDeleteResponse confirming the deletion
        """
        url = self._build_url(f"quality/results/{transform_id}")
        response = requests.delete(url, headers=self.headers, timeout=self.timeout)
        result = self._handle_response(response)
        return QualityDeleteResponse(**result)
    
    def get_quality_health(self) -> QualityHealthResponse:
        """
        Check the health and availability of the quality validation API.
        
        Returns:
            QualityHealthResponse with health status information
        """
        url = self._build_url("quality/health")
        response = requests.get(url, timeout=self.timeout)  # No auth headers needed for health check
        result = self._handle_response(response)
        return QualityHealthResponse(**result)

    # Dashboard Endpoints

    def get_dashboard_runs(
        self,
        limit: int = 20,
        days: int = 14
    ) -> RecentRunsResponse:
        """Fetch the most recent transform runs with quality and usage context."""

        url = self._build_url("dashboard/runs")
        params = {
            "limit": min(max(limit, 1), 50),
            "days": min(max(days, 1), 90)
        }
        response = requests.get(url, params=params, headers=self.headers, timeout=self.timeout)
        result = self._handle_response(response)
        return RecentRunsResponse(**result)

    def get_dashboard_summary(
        self,
        days: int = 14,
        max_runs: int = 200
    ) -> DashboardSummaryResponse:
        """Retrieve aggregated KPI metrics for the dashboard summary header."""

        url = self._build_url("dashboard/summary")
        params = {
            "days": min(max(days, 1), 90),
            "max_runs": min(max(max_runs, 1), 1000)
        }
        response = requests.get(url, params=params, headers=self.headers, timeout=self.timeout)
        result = self._handle_response(response)
        return DashboardSummaryResponse(**result)

    def get_dashboard_performance(
        self,
        days: int = 14,
        max_runs: int = 200
    ) -> DashboardPerformanceResponse:
        """Retrieve performance time-series metrics for dashboard charts."""

        url = self._build_url("dashboard/performance")
        params = {
            "days": min(max(days, 1), 90),
            "max_runs": min(max(max_runs, 1), 1000)
        }
        response = requests.get(url, params=params, headers=self.headers, timeout=self.timeout)
        result = self._handle_response(response)
        return DashboardPerformanceResponse(**result)

    def get_dashboard_quality(
        self,
        days: int = 14,
        max_runs: int = 200
    ) -> DashboardQualityResponse:
        """Retrieve quality aggregates for the dashboard quality section."""

        url = self._build_url("dashboard/quality")
        params = {
            "days": min(max(days, 1), 90),
            "max_runs": min(max(max_runs, 1), 1000)
        }
        response = requests.get(url, params=params, headers=self.headers, timeout=self.timeout)
        result = self._handle_response(response)
        return DashboardQualityResponse(**result)


# ---- Evidence helpers ------------------------------------------------------
# Mirrors graphora_server/mcp/server.py::_EVIDENCE_KEYS so the CLI surface
# renders the same source-span subset the agent sees. Kept duplicated rather
# than imported because graphora-client must not depend on graphora-server.

_EVIDENCE_KEYS = frozenset(
    {
        "source_chunk_id",
        "source_text",
        "source",
        "document_id",
        "document_name",
        "chunk_offset",
        "page_number",
        "extraction_confidence",
        # B0-prov-extend (Gate 4 entry) — decision-trail provenance.
        "extractor_model",
        "prompt_version",
        "validator_score",
    }
)


def _extract_evidence_fields(props: Dict[str, Any]) -> Dict[str, Any]:
    """Filter a property bag down to source-span fields. Used by
    ``get_evidence`` to mirror the MCP server's evidence shape."""
    return {k: v for k, v in (props or {}).items() if k in _EVIDENCE_KEYS}
