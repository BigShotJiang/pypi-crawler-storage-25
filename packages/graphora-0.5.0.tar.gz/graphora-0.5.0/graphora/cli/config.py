"""Configuration management for Graphora CLI.

Stores config in ~/.graphora/config.yaml similar to other CLI tools.
"""

import os
from pathlib import Path
from typing import Any, Dict, Optional
import yaml


CONFIG_DIR = Path.home() / ".graphora"
CONFIG_FILE = CONFIG_DIR / "config.yaml"

DEFAULT_CONFIG = {
    "llm": {
        "provider": "gemini",
        "api_key": None,
        "model": "gemini-2.5-flash-lite",
    },
    "api": {
        "url": None,  # Remote API URL (for remote mode)
        "auth_token": None,  # Auth token for remote API
    },
    "embedded": {
        "api_path": None,  # Path to graphora-api directory
    },
    "defaults": {
        "output_format": "json",
        "auto_schema": True,
        "mode": "embedded",  # 'embedded' or 'remote'
    },
}


def ensure_config_dir() -> Path:
    """Ensure config directory exists."""
    CONFIG_DIR.mkdir(parents=True, exist_ok=True)
    return CONFIG_DIR


def load_config() -> Dict[str, Any]:
    """Load config from file, merging with defaults."""
    config = _deep_copy(DEFAULT_CONFIG)

    if CONFIG_FILE.exists():
        try:
            with open(CONFIG_FILE, "r") as f:
                user_config = yaml.safe_load(f) or {}
            config = _deep_merge(config, user_config)
        except Exception:
            # If config is corrupted, use defaults
            pass

    return config


def save_config(config: Dict[str, Any]) -> None:
    """Save config to file."""
    ensure_config_dir()

    with open(CONFIG_FILE, "w") as f:
        yaml.dump(config, f, default_flow_style=False, sort_keys=False)


def get_config_value(key: str) -> Any:
    """Get a config value by dotted key path (e.g., 'llm.api_key')."""
    config = load_config()

    parts = key.split(".")
    value = config

    for part in parts:
        if isinstance(value, dict) and part in value:
            value = value[part]
        else:
            return None

    return value


def set_config_value(key: str, value: Any) -> None:
    """Set a config value by dotted key path (e.g., 'llm.api_key')."""
    config = load_config()

    parts = key.split(".")
    current = config

    # Navigate to parent
    for part in parts[:-1]:
        if part not in current:
            current[part] = {}
        current = current[part]

    # Set value
    current[parts[-1]] = value

    save_config(config)


def _deep_copy(d: Dict) -> Dict:
    """Deep copy a dictionary."""
    result = {}
    for key, value in d.items():
        if isinstance(value, dict):
            result[key] = _deep_copy(value)
        else:
            result[key] = value
    return result


def _deep_merge(base: Dict, override: Dict) -> Dict:
    """Deep merge two dictionaries."""
    result = _deep_copy(base)

    for key, value in override.items():
        if key in result and isinstance(result[key], dict) and isinstance(value, dict):
            result[key] = _deep_merge(result[key], value)
        else:
            result[key] = value

    return result


def get_api_key() -> Optional[str]:
    """Get the configured LLM API key."""
    # Check environment variable first
    env_key = os.environ.get("GRAPHORA_API_KEY") or os.environ.get("GEMINI_API_KEY")
    if env_key:
        return env_key

    # Fall back to config file
    return get_config_value("llm.api_key")


def get_llm_model() -> str:
    """Get the configured LLM model."""
    return get_config_value("llm.model") or "gemini-2.5-flash-lite"


def get_llm_provider() -> str:
    """Get the configured LLM provider."""
    return get_config_value("llm.provider") or "gemini"


def get_mode() -> str:
    """Get the CLI mode (embedded or remote)."""
    return get_config_value("defaults.mode") or "embedded"


def get_api_url() -> Optional[str]:
    """Get the remote API URL."""
    return os.environ.get("GRAPHORA_API_URL") or get_config_value("api.url")


def get_auth_token() -> Optional[str]:
    """Get the remote API auth token."""
    return os.environ.get("GRAPHORA_AUTH_TOKEN") or get_config_value("api.auth_token")


def get_embedded_api_path() -> Optional[str]:
    """Get the path to graphora-api directory for embedded mode.

    Checks in order:
    1. Environment variable GRAPHORA_API_PATH
    2. Custom path from config (embedded.api_path)
    3. Auto-downloaded cache (~/.graphora/api/)
    """
    # Environment variable override
    env_path = os.environ.get("GRAPHORA_API_PATH")
    if env_path:
        return env_path

    # Custom path from config
    custom_path = get_config_value("embedded.api_path")
    if custom_path:
        return os.path.expanduser(custom_path)

    # Check auto-downloaded cache
    from graphora.cli.api_manager import get_api_path
    api_path = get_api_path()
    if api_path:
        return str(api_path)

    return None


def setup_embedded_path() -> bool:
    """Add graphora-api to Python path.

    Also sets required environment variables BEFORE any imports.

    Returns:
        True if path was set up successfully, False otherwise.
    """
    # Set env vars BEFORE adding to path and importing
    # This is critical because graphora-api loads settings at import time
    os.environ.setdefault("TEST_MODE", "true")
    os.environ.setdefault("DATABASE_URL", "sqlite:///memory")
    os.environ.setdefault("AUTH_BYPASS_ENABLED", "true")
    os.environ.setdefault("GRAPH_STORAGE_MODE", "memory")
    os.environ.setdefault("STORAGE_TYPE", "memory")
    os.environ.setdefault("PREFECT_API_URL", "")

    from graphora.cli.api_manager import add_api_to_path
    return add_api_to_path()


def is_embedded_available() -> bool:
    """Check if embedded mode is available (graphora-api accessible)."""
    # Set up path and env vars
    setup_embedded_path()

    try:
        from graphora_server.services.transform.graph_transformer import build_graph_from_chunks  # noqa: F401
        return True
    except ImportError:
        return False
    except Exception:
        # Config errors etc - API is there but misconfigured
        return True
