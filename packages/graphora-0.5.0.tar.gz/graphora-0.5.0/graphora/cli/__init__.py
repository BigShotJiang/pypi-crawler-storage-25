"""Graphora CLI - Command-line interface for knowledge graph extraction."""

from importlib.metadata import version, PackageNotFoundError

try:
    __version__ = version("graphora")
except PackageNotFoundError:
    __version__ = "0.0.0-dev"
