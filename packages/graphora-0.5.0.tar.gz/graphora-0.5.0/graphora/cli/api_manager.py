"""API Manager - handles downloading and managing graphora-api.

Automatically downloads and caches graphora-api from GitHub for embedded mode.
"""

import os
import shutil
import subprocess
import sys
import tempfile
import zipfile
from pathlib import Path
from typing import Optional, Tuple

import requests

from graphora.cli.config import CONFIG_DIR, get_config_value, set_config_value


# Default GitHub repo
GITHUB_REPO = "graphora/graphora-api"
GITHUB_API_URL = f"https://api.github.com/repos/{GITHUB_REPO}"
DEFAULT_BRANCH = "main"

# Cache directory
API_CACHE_DIR = CONFIG_DIR / "api"
DEPS_INSTALLED_MARKER = ".deps_installed"

# Version channels
VERSION_CHANNELS = {
    "stable": "latest",      # Latest stable release
    "nightly": "nightly",    # Latest nightly build
    "main": "main",          # Main branch (development)
}


def get_api_path() -> Optional[Path]:
    """Get the path to graphora-api (cached or custom).

    Returns:
        Path to graphora-api directory, or None if not available.
    """
    # Check for custom path override first
    custom_path = get_config_value("embedded.api_path")
    if custom_path:
        custom_path = Path(os.path.expanduser(custom_path))
        if custom_path.is_dir():
            return custom_path

    # Check cached version
    cached_path = get_cached_api_path()
    if cached_path and cached_path.is_dir():
        return cached_path

    return None


def get_cached_api_path() -> Optional[Path]:
    """Get path to the cached graphora-api."""
    if not API_CACHE_DIR.exists():
        return None

    # Look for the extracted directory
    for item in API_CACHE_DIR.iterdir():
        if item.is_dir() and item.name.startswith("graphora-api"):
            return item

    return None


def get_installed_version() -> Optional[str]:
    """Get the currently installed version."""
    return get_config_value("embedded.installed_version")


def get_latest_version(channel: str = "stable") -> str:
    """Fetch the latest version from GitHub.

    Args:
        channel: Version channel - "stable", "nightly", or "main"

    Returns:
        Version string (e.g., "v1.0.0", "nightly-20240101", or "main")
    """
    if channel == "main":
        return DEFAULT_BRANCH

    if channel == "nightly":
        # Get latest nightly release
        try:
            response = requests.get(
                f"{GITHUB_API_URL}/releases",
                timeout=10,
                headers={"Accept": "application/vnd.github.v3+json"},
                params={"per_page": 20}
            )
            if response.status_code == 200:
                releases = response.json()
                for release in releases:
                    tag = release.get("tag_name", "")
                    if tag.startswith("nightly-"):
                        return tag
        except Exception:
            pass
        # Fall back to nightly tag
        return "nightly"

    # Stable channel - get latest non-prerelease
    try:
        response = requests.get(
            f"{GITHUB_API_URL}/releases/latest",
            timeout=10,
            headers={"Accept": "application/vnd.github.v3+json"}
        )
        if response.status_code == 200:
            data = response.json()
            tag = data.get("tag_name")
            if tag:
                return tag
    except Exception:
        pass

    # No releases found, use main branch
    return DEFAULT_BRANCH


def is_api_available() -> bool:
    """Check if graphora-api is available and ready to use."""
    api_path = get_api_path()
    if not api_path:
        return False

    # Check if key files exist
    required_files = [
        "app/__init__.py",
        "app/services/transform/graph_transformer.py",
    ]

    for file in required_files:
        if not (api_path / file).exists():
            return False

    return True


def is_deps_installed() -> bool:
    """Check if dependencies have been installed."""
    cached_path = get_cached_api_path()
    if not cached_path:
        return False
    return (cached_path / DEPS_INSTALLED_MARKER).exists()


def download_api(
    version: Optional[str] = None,
    channel: str = "main",
    force: bool = False,
    progress_callback=None,
) -> Tuple[bool, str]:
    """Download graphora-api from GitHub.

    Args:
        version: Version to download (tag or branch). Defaults to main branch.
        channel: Version channel - "stable", "nightly", or "main". Default: main.
        force: Force re-download even if already cached.
        progress_callback: Optional callback for progress updates.

    Returns:
        Tuple of (success, message).
    """
    if progress_callback:
        progress_callback("Checking for updates...")

    # Determine version to download
    if not version:
        configured_channel = get_config_value("embedded.channel") or channel
        version = get_config_value("embedded.version") or get_latest_version(configured_channel)

    # Check if already installed
    installed_version = get_installed_version()
    if not force and installed_version == version and is_api_available():
        return True, f"graphora-api {version} already installed"

    if progress_callback:
        progress_callback(f"Downloading graphora-api {version}...")

    # Create cache directory
    API_CACHE_DIR.mkdir(parents=True, exist_ok=True)

    # Determine download URL based on version format
    # Formats: YYYY-MM-vX.Y.Z, vX.Y.Z, nightly-YYYYMMDD, main
    if version in ["main", "nightly", "latest"]:
        # It's a branch or special tag - use branch URL
        zip_url = f"https://github.com/{GITHUB_REPO}/archive/refs/heads/{version}.zip"
    else:
        # It's a tag (YYYY-MM-vX.Y.Z, vX.Y.Z, nightly-YYYYMMDD, etc.)
        zip_url = f"https://github.com/{GITHUB_REPO}/archive/refs/tags/{version}.zip"

    try:
        response = requests.get(zip_url, stream=True, timeout=60)
        response.raise_for_status()

        # Save to temp file
        with tempfile.NamedTemporaryFile(delete=False, suffix=".zip") as tmp_file:
            total_size = int(response.headers.get("content-length", 0))
            downloaded = 0

            for chunk in response.iter_content(chunk_size=8192):
                tmp_file.write(chunk)
                downloaded += len(chunk)
                if progress_callback and total_size:
                    pct = int(downloaded / total_size * 100)
                    progress_callback(f"Downloading... {pct}%")

            tmp_path = tmp_file.name

        if progress_callback:
            progress_callback("Extracting...")

        # Remove old cached version
        if API_CACHE_DIR.exists():
            for item in API_CACHE_DIR.iterdir():
                if item.is_dir() and item.name.startswith("graphora-api"):
                    shutil.rmtree(item)

        # Extract zip
        with zipfile.ZipFile(tmp_path, "r") as zip_ref:
            zip_ref.extractall(API_CACHE_DIR)

        # Clean up temp file
        os.unlink(tmp_path)

        # Save installed version
        set_config_value("embedded.installed_version", version)

        return True, f"Successfully downloaded graphora-api {version}"

    except requests.exceptions.RequestException as e:
        return False, f"Download failed: {e}"
    except zipfile.BadZipFile:
        return False, "Downloaded file is not a valid zip"
    except Exception as e:
        return False, f"Installation failed: {e}"


def _extract_deps_from_pyproject(pyproject_path: Path) -> list:
    """Extract dependency list from pyproject.toml without installing the package itself.

    This avoids `pip install -e .` which would register the `graphora_server`
    package with incomplete subpackage discovery (packages=["graphora_server"]),
    shadowing the sys.path-based imports that the CLI relies on.
    """
    try:
        import tomllib
    except ImportError:
        try:
            import tomli as tomllib
        except ImportError:
            # Fall back to basic parsing
            return []

    try:
        with open(pyproject_path, "rb") as f:
            data = tomllib.load(f)
        return data.get("project", {}).get("dependencies", [])
    except Exception:
        return []


def install_dependencies(progress_callback=None) -> Tuple[bool, str]:
    """Install graphora-api dependencies.

    IMPORTANT: We install only the dependencies, NOT the package itself.
    The API's pyproject.toml uses packages=["graphora_server"] which only
    registers the top-level graphora_server package without subpackages.
    This shadows the sys.path-based import that the CLI uses, breaking
    imports like graphora_server.services.document_parser.

    Args:
        progress_callback: Optional callback for progress updates.

    Returns:
        Tuple of (success, message).
    """
    api_path = get_cached_api_path()
    if not api_path:
        return False, "graphora-api not downloaded"

    requirements_file = api_path / "requirements.txt"
    if not requirements_file.exists():
        # Extract deps from pyproject.toml WITHOUT installing the package
        pyproject_file = api_path / "pyproject.toml"
        if pyproject_file.exists():
            deps = _extract_deps_from_pyproject(pyproject_file)
            if deps:
                if progress_callback:
                    progress_callback("Installing API dependencies...")
                try:
                    subprocess.check_call(
                        [sys.executable, "-m", "pip", "install"] + deps + ["-q"],
                        stdout=subprocess.DEVNULL,
                    )
                except subprocess.CalledProcessError:
                    # Non-fatal: CLI extras already include key deps (aiofiles, google-genai)
                    if progress_callback:
                        progress_callback("Some API dependencies could not be installed (non-fatal)")
    else:
        if progress_callback:
            progress_callback("Installing dependencies...")

        try:
            subprocess.check_call(
                [sys.executable, "-m", "pip", "install", "-r", str(requirements_file), "-q"],
                stdout=subprocess.DEVNULL,
            )
        except subprocess.CalledProcessError as e:
            return False, f"Failed to install dependencies: {e}"

    # Mark deps as installed
    marker_file = api_path / DEPS_INSTALLED_MARKER
    marker_file.touch()

    return True, "Dependencies installed successfully"


def setup_api(
    version: Optional[str] = None,
    channel: str = "main",
    force: bool = False,
    install_deps: bool = True,
    progress_callback=None,
) -> Tuple[bool, str]:
    """Download and set up graphora-api.

    This is the main entry point for setting up embedded mode.

    Args:
        version: Version to install (defaults to latest based on channel).
        channel: Version channel - "stable", "nightly", or "main".
        force: Force re-download.
        install_deps: Whether to install Python dependencies.
        progress_callback: Optional callback for progress updates.

    Returns:
        Tuple of (success, message).
    """
    # Download
    success, message = download_api(version, channel, force, progress_callback)
    if not success:
        return False, message

    # Install dependencies
    if install_deps and not is_deps_installed():
        if progress_callback:
            progress_callback("Installing dependencies...")

        success, dep_message = install_dependencies(progress_callback)
        if not success:
            return False, dep_message

    if progress_callback:
        progress_callback("Setup complete!")

    return True, "graphora-api setup complete"


def add_api_to_path() -> bool:
    """Add graphora-api to Python path.

    Returns:
        True if successful, False otherwise.
    """
    api_path = get_api_path()
    if not api_path:
        return False

    api_path_str = str(api_path)
    if api_path_str not in sys.path:
        sys.path.insert(0, api_path_str)

    return True
