"""LLM credential resolution for CLI-driven embedded extraction.

The `graphora` CLI patches
graphora_server.utils.llm_helper.get_user_llm_credentials so embedded-mode
extraction uses env vars instead of looking up a per-user credential row
in a database.

This module is the single source of truth for that resolution. Both
graphora.cli.runtime._patch_llm_credentials and
graphora.cli.commands.extract._run_embedded_extraction_async route
through `resolve_cli_credentials`.

Precedence (first match wins):

    1. Ollama — if OLLAMA_HOST is set OR localhost:11434 is reachable AND
       the user set LLM_MODEL to an Ollama-compatible tag. Requires
       graphora-server Ollama provider support. TODO: wire this once the
       server-side BAML Ollama client lands.
    2. OpenRouter — if OPENROUTER_API_KEY is set. One key, many models.
    3. Anthropic — if ANTHROPIC_API_KEY is set.
    4. OpenAI — if OPENAI_API_KEY is set.
    5. Gemini — if GEMINI_API_KEY or GOOGLE_API_KEY is set.
    6. Hosted demo token — future work, not yet configured.

The return shape matches the upstream
graphora_server.utils.llm_helper.get_user_llm_credentials function so
the monkey-patch swap is transparent:

    (api_key: str, model_name: str)

On complete failure, raises ValueError with an actionable multi-line
error message listing which env vars would fix the problem.
"""

from __future__ import annotations

import os
from dataclasses import dataclass
from typing import Optional, Tuple


@dataclass(frozen=True)
class _Provider:
    """One credential-source candidate."""

    name: str
    env_var: str
    default_model: str
    alt_env_var: Optional[str] = None


# Precedence is significant: Ollama first (zero-cost local), then
# OpenRouter (one key unlocks many models), then per-provider keys.
_PROVIDERS: Tuple[_Provider, ...] = (
    # Ollama is listed for visibility in the error message but cannot
    # yet be selected programmatically — see TODO in module docstring.
    # _Provider(name="Ollama", env_var="OLLAMA_HOST", default_model="llama3.2"),
    _Provider(
        name="OpenRouter",
        env_var="OPENROUTER_API_KEY",
        default_model="openrouter/anthropic/claude-3.5-sonnet",
    ),
    _Provider(
        name="Anthropic",
        env_var="ANTHROPIC_API_KEY",
        default_model="claude-haiku-4-5",
    ),
    _Provider(
        name="OpenAI",
        env_var="OPENAI_API_KEY",
        default_model="gpt-4o-mini",
    ),
    _Provider(
        name="Gemini",
        env_var="GEMINI_API_KEY",
        alt_env_var="GOOGLE_API_KEY",
        default_model="gemini-2.5-flash-lite",
    ),
)


_NO_CREDENTIALS_ERROR = """\
No LLM credentials found. Set one of:

  export OPENROUTER_API_KEY=...   # one key, many models
  export ANTHROPIC_API_KEY=...
  export OPENAI_API_KEY=...
  export GEMINI_API_KEY=...       # or GOOGLE_API_KEY

To override the default model, also set:
  export LLM_MODEL=<provider-specific-model-id>

Ollama-first auto-detect is on the roadmap but requires graphora-server
Ollama provider support, which is not yet wired end-to-end.
"""


def resolve_cli_credentials(user_id: Optional[str] = None) -> Tuple[str, str]:
    """Resolve `(api_key, model_name)` for embedded-mode extraction.

    Args:
        user_id: Accepted for compatibility with the upstream
            graphora_server.utils.llm_helper.get_user_llm_credentials
            signature. Ignored here; the CLI is a single-tenant context.

    Returns:
        Tuple of ``(api_key, model_name)``.

    Raises:
        ValueError: When no provider credentials are set. The message
            lists every accepted env var so the fix is self-describing.
    """
    del user_id  # accepted for signature compat; unused in CLI mode

    override_model = os.environ.get("LLM_MODEL")
    for provider in _PROVIDERS:
        api_key = os.environ.get(provider.env_var)
        if not api_key and provider.alt_env_var:
            api_key = os.environ.get(provider.alt_env_var)
        if api_key:
            return api_key, (override_model or provider.default_model)

    raise ValueError(_NO_CREDENTIALS_ERROR)


async def resolve_cli_credentials_async(user_id: Optional[str] = None) -> Tuple[str, str]:
    """Async wrapper matching the upstream function's coroutine signature."""
    return resolve_cli_credentials(user_id)
