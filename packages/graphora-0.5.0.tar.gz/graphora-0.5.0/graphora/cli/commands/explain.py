"""Explain command — show why a node or edge is in a graph.

Surfaces the source-span evidence + decision log for a node or
edge from a Graphora transform. Closes the Gate-4 exit signal
"for every edge ``graphora explain <edge>`` returns the exact
source text that produced it."

Backend support landed in graphora-server commit b8504e7 (REST +
MCP edge-evidence) and f78cd6d (FastMCP registered tool surface).
This command is the user-facing CLI on top — it talks REST via
GraphoraClient, not MCP, so it works whether or not the [mcp]
extra is installed.
"""

from __future__ import annotations

import json
from typing import Optional

import typer
from rich.console import Console
from rich.json import JSON
from rich.panel import Panel
from rich.table import Table
from rich import box

from graphora.client import GraphoraClient
from graphora.cli.config import get_api_url, get_auth_token
from graphora.cli.runtime import get_missing_config, validate_remote_environment
from graphora.exceptions import GraphoraAPIError, GraphoraClientError

console = Console()


def explain(
    transform_id: str = typer.Argument(
        ...,
        help="Transform ID the node or edge belongs to.",
    ),
    node_id: Optional[str] = typer.Option(
        None,
        "--node-id",
        "-n",
        help="Node ID to explain. Mutually exclusive with --edge-id.",
    ),
    edge_id: Optional[str] = typer.Option(
        None,
        "--edge-id",
        "-e",
        help="Edge ID to explain. Mutually exclusive with --node-id.",
    ),
    json_output: bool = typer.Option(
        False,
        "--json",
        help="Emit the raw JSON evidence payload instead of the formatted view.",
    ),
    base_url: Optional[str] = typer.Option(
        None,
        "--api-url",
        help=(
            "Graphora API base URL. Falls back to GRAPHORA_API_URL "
            "and then ~/.graphora/config.yaml (api.url)."
        ),
    ),
    auth_token: Optional[str] = typer.Option(
        None,
        "--auth-token",
        help=(
            "Clerk bearer token. Falls back to GRAPHORA_AUTH_TOKEN "
            "and then ~/.graphora/config.yaml (api.auth_token)."
        ),
    ),
):
    """Explain why a node or edge is in the graph.

    Renders the source-span evidence (the text and document that
    produced the target), the Decision Log entries the pipeline
    emitted for it (schema inference, entity merges, relationship
    accept/reject), and any alternatives the pipeline considered
    before settling on this version.

    Exactly one of ``--node-id`` / ``--edge-id`` must be supplied.

    Examples:

        graphora explain tx_abc123 --node-id n_alice
        graphora explain tx_abc123 --edge-id e_works_at --json
        graphora explain tx_abc123 -e e1 > evidence.json
    """
    # Mutex check matches the API contract (graphora-server returns
    # 400 if both ids are set; we surface the same message early so
    # users don't pay the roundtrip).
    if bool(node_id) == bool(edge_id):
        console.print(
            "[red]Error:[/red] provide exactly one of --node-id or --edge-id."
        )
        raise typer.Exit(code=2)

    # Credential resolution order: explicit CLI option > env var >
    # persisted config (~/.graphora/config.yaml). Reviewer-flagged
    # on commit 68ae817: the previous version only checked the
    # typer-resolved option/envvar pair, which silently bypassed
    # the config file users set up with `graphora config init
    # --mode remote`. The other remote commands (extract) resolve
    # via get_api_url() / get_auth_token() helpers — explain now
    # follows the same path so a single config init covers
    # everything.
    #
    # get_api_url() / get_auth_token() themselves check env first
    # then config, so an explicit --api-url / --auth-token still
    # wins via the ``or`` short-circuit.
    resolved_base_url = base_url or get_api_url()
    resolved_auth_token = auth_token or get_auth_token()

    if not validate_remote_environment() and not (
        resolved_base_url and resolved_auth_token
    ):
        # Friendly diagnostic mirroring extract.py's _extract_remote.
        # validate_remote_environment looks at the same get_*
        # helpers we used above, but the secondary check covers
        # the case where the user passed credentials via CLI flags
        # only (validate_remote_environment returns False, but the
        # explicit overrides are enough to proceed).
        missing = get_missing_config("remote")
        console.print("[red]Missing required configuration:[/red]")
        for item in missing:
            console.print(f"  - {item}")
        console.print(
            "\nRun [cyan]graphora config init --mode remote[/cyan] "
            "to set up configuration, or pass --api-url + "
            "--auth-token."
        )
        raise typer.Exit(code=2)

    try:
        client = GraphoraClient(
            base_url=resolved_base_url, auth_token=resolved_auth_token
        )
    except ValueError as exc:
        # The client's __init__ raises a friendly message when
        # auth is still missing after our resolution above (e.g.,
        # the config file has api.url but not api.auth_token).
        console.print(f"[red]Error:[/red] {exc}")
        raise typer.Exit(code=2)

    try:
        payload = client.get_evidence(
            transform_id, node_id=node_id, edge_id=edge_id
        )
    except GraphoraAPIError as exc:
        console.print(f"[red]API error:[/red] {exc}")
        raise typer.Exit(code=1)
    except GraphoraClientError as exc:
        console.print(f"[red]Client error:[/red] {exc}")
        raise typer.Exit(code=2)

    if json_output:
        # When piped (`> file.json`), Rich's default would still
        # wrap output as terminal text. Print plain JSON instead so
        # the output is machine-parseable.
        if console.is_terminal:
            console.print(JSON(json.dumps(payload, default=str)))
        else:
            print(json.dumps(payload, indent=2, default=str))
        return

    _render(payload)


def _render(payload: dict) -> None:
    """Human-readable render. The shape carries a ``kind``
    discriminator so we can branch cleanly between node and edge
    views. Empty sections still render with a "(none)" placeholder
    so the absence is visible — pipelines that didn't emit
    decisions are common, and silently dropping the section would
    look like the rendering broke."""
    kind = payload.get("kind")
    if kind == "node":
        _render_node(payload)
    elif kind == "edge":
        _render_edge(payload)
    else:
        # Defensive: future server-side schema drift. Fall back to
        # the JSON dump so users still see the payload rather than
        # a blank screen.
        console.print(
            f"[yellow]Unknown evidence kind: {kind!r}; "
            "showing raw payload.[/yellow]"
        )
        console.print(JSON(json.dumps(payload, default=str)))


def _render_node(payload: dict) -> None:
    node = payload.get("node")
    if node is None:
        console.print("[yellow]Node not found in this transform.[/yellow]")
        return

    header = (
        f"[bold]{node.get('label') or node.get('id')}[/bold]  "
        f"[dim]({node.get('type', '?')})[/dim]\n"
        f"[dim]id:[/dim] {node.get('id')}"
    )
    console.print(Panel(header, title="Node", box=box.ROUNDED))

    _render_evidence(payload.get("evidence", {}))

    incoming = payload.get("incoming_edges", []) or []
    outgoing = payload.get("outgoing_edges", []) or []
    if incoming or outgoing:
        table = Table(title="Incident edges", box=box.SIMPLE)
        table.add_column("Direction")
        table.add_column("Type")
        table.add_column("Other endpoint")
        table.add_column("Edge ID", style="dim")
        for e in outgoing:
            table.add_row("out →", e.get("type", "?"), e.get("target", ""), e.get("id", ""))
        for e in incoming:
            table.add_row("in ←", e.get("type", "?"), e.get("source", ""), e.get("id", ""))
        console.print(table)

    _render_decision_log(payload.get("decision_log", []))
    _render_alternatives(payload.get("alternatives", []))


def _render_edge(payload: dict) -> None:
    edge = payload.get("edge")
    if edge is None:
        console.print("[yellow]Edge not found in this transform.[/yellow]")
        return

    source = payload.get("source_node") or {}
    target = payload.get("target_node") or {}
    src_label = source.get("label") or source.get("id") or edge.get("source", "?")
    tgt_label = target.get("label") or target.get("id") or edge.get("target", "?")
    header = (
        f"[bold]{src_label}[/bold] —[bold cyan]"
        f"{edge.get('type', '?')}[/bold cyan]→ "
        f"[bold]{tgt_label}[/bold]\n"
        f"[dim]edge id:[/dim] {edge.get('id')}"
    )
    console.print(Panel(header, title="Edge", box=box.ROUNDED))

    _render_evidence(payload.get("evidence", {}))
    _render_decision_log(payload.get("decision_log", []))
    _render_alternatives(payload.get("alternatives", []))


def _render_evidence(evidence: dict) -> None:
    """Source-span evidence. We render the body field
    (``source_text``) inline as a quoted block, then a key/value
    table of the surrounding provenance fields. Empty evidence
    renders an explicit "(no source span recorded)" line — the
    pipeline normally stamps these at extraction time so absence
    is worth surfacing rather than hiding."""
    if not evidence:
        console.print(
            "[yellow](no source span recorded for this target)[/yellow]\n"
        )
        return

    source_text = evidence.get("source_text")
    if source_text:
        console.print(
            Panel(
                str(source_text),
                title="Source text",
                title_align="left",
                box=box.SIMPLE,
                border_style="dim",
            )
        )

    other = {k: v for k, v in evidence.items() if k != "source_text"}
    if other:
        table = Table(title="Provenance", box=box.SIMPLE, show_header=False)
        table.add_column("Field", style="dim")
        table.add_column("Value")
        # Stable display order: document context first, then chunk
        # location, then decision-trail (B0-prov-extend) fields.
        preferred = [
            "document_name",
            "document_id",
            "source",
            "page_number",
            "source_chunk_id",
            "chunk_offset",
            "extraction_confidence",
            "extractor_model",
            "prompt_version",
            "validator_score",
        ]
        rendered_keys = set()
        for key in preferred:
            if key in other:
                table.add_row(key, _format_value(other[key]))
                rendered_keys.add(key)
        # Anything unexpected (forward-compatibility) goes at the end.
        for key, value in other.items():
            if key not in rendered_keys:
                table.add_row(key, _format_value(value))
        console.print(table)


def _render_decision_log(entries: list) -> None:
    if not entries:
        console.print("[dim]Decision log: (none)[/dim]\n")
        return

    table = Table(title="Decision log", box=box.SIMPLE)
    table.add_column("When", style="dim")
    table.add_column("Type")
    table.add_column("Target")
    table.add_column("Reason")
    for d in entries:
        table.add_row(
            str(d.get("created_at", ""))[:19],  # trim subsecond/timezone
            str(d.get("decision_type", "")),
            f"{d.get('target_kind', '?')}:{d.get('target_id') or '-'}",
            _truncate(d.get("reason") or "", 80),
        )
    console.print(table)


def _render_alternatives(alts: list) -> None:
    if not alts:
        return
    console.print(f"[dim]Alternatives considered: {len(alts)}[/dim]")
    for i, alt in enumerate(alts[:5], 1):
        console.print(f"  [dim]{i}.[/dim] {_format_value(alt)}")
    if len(alts) > 5:
        console.print(f"  [dim]... ({len(alts) - 5} more)[/dim]")


def _format_value(value) -> str:
    if isinstance(value, (dict, list)):
        return json.dumps(value, default=str, ensure_ascii=False)
    return str(value)


def _truncate(text: str, max_len: int) -> str:
    if len(text) <= max_len:
        return text
    return text[: max_len - 1] + "…"
