"""Diff command — compare two transforms and show what changed.

B3-diff (Gate 4) CLI. Backed by graphora-server's
GET /api/v1/graph/{base}/diff/{compare} (commit a75cd73) and
the matching MCP ``review_diff`` tool. The frontend Diff/Review
tab in graphora-fe (commit 4ce2fe2) renders the same shape;
this command is the terminal-side equivalent for operators who
want to inspect a delta from the CLI or pipe it into a script.

Typical flow: re-run a transform after a prompt tweak or
ontology change, then ``graphora diff <old-tx> <new-tx>`` to
see the added / removed / changed nodes + edges before
accepting or publishing.

Node identity matches across transforms by canonical_id (Gate 4
entity resolution), falling back to type:canonical_key, then
per-transform id. Edge identity uses the same rule on each
endpoint. Property comparison filters system fields
(source_chunk_id, validator_score, etc.) so re-extraction churn
doesn't drown out the actual signal.
"""

from __future__ import annotations

import json
from typing import Any, Dict, List, Optional

import typer
from rich import box
from rich.console import Console
from rich.json import JSON
from rich.markup import escape as rich_escape
from rich.panel import Panel
from rich.table import Table

from graphora.cli.config import get_api_url, get_auth_token
from graphora.cli.runtime import get_missing_config, validate_remote_environment
from graphora.client import GraphoraClient
from graphora.exceptions import GraphoraAPIError, GraphoraClientError

console = Console()


def diff(
    base_transform_id: str = typer.Argument(
        ...,
        help="The 'before' transform ID.",
    ),
    compare_transform_id: str = typer.Argument(
        ...,
        help="The 'after' transform ID — the one being reviewed against base.",
    ),
    json_output: bool = typer.Option(
        False,
        "--json",
        help=(
            "Emit the raw diff payload as JSON instead of the "
            "Rich summary view. Same shape the /diff endpoint "
            "returns; pipe to jq / scripts as needed."
        ),
    ),
    show_unchanged: bool = typer.Option(
        False,
        "--show-unchanged",
        help=(
            "Include the unchanged counts in the summary table. "
            "Off by default to keep the focus on the delta — turn "
            "on when you want to sanity-check that 'most things "
            "didn't move' alongside the changes."
        ),
    ),
    limit: int = typer.Option(
        20,
        "--limit",
        "-n",
        help=(
            "Per-section entry cap on the added / removed / changed "
            "detail tables. Note: for the changed sections each "
            "entry expands to one row per property change, so the "
            "rendered row count can exceed --limit when entries "
            "have multiple property changes. The full set is "
            "always available via --json; this only trims the "
            "terminal view."
        ),
        min=1,
    ),
    base_url: Optional[str] = typer.Option(
        None,
        "--api-url",
        help=(
            "Graphora API base URL. Falls back to GRAPHORA_API_URL "
            "and then ~/.graphora/config.yaml (api.url)."
        ),
    ),
    auth_token: Optional[str] = typer.Option(
        None,
        "--auth-token",
        help=(
            "Clerk bearer token. Falls back to GRAPHORA_AUTH_TOKEN "
            "and then ~/.graphora/config.yaml (api.auth_token)."
        ),
    ),
):
    """Compare two transforms and show added / removed / changed.

    Renders a summary table (counts per dimension) plus per-section
    detail tables for added, removed, and changed nodes + edges.
    Use ``--json`` to emit the raw payload for piping into other
    tools.

    Examples:

        graphora diff tx-old tx-new
        graphora diff tx-old tx-new --show-unchanged
        graphora diff tx-old tx-new --json | jq '.summary'
        graphora diff tx-old tx-new -n 5    # trim long detail tables
    """
    # Credential resolution — same chain as ``graphora explain``
    # and ``graphora test``. Explicit option > env var > persisted
    # config (~/.graphora/config.yaml).
    resolved_base_url = base_url or get_api_url()
    resolved_auth_token = auth_token or get_auth_token()

    if not validate_remote_environment() and not (
        resolved_base_url and resolved_auth_token
    ):
        missing = get_missing_config("remote")
        console.print("[red]Missing required configuration:[/red]")
        for item in missing:
            console.print(f"  - {item}")
        console.print(
            "\nRun [cyan]graphora config init --mode remote[/cyan] "
            "to set up configuration, or pass --api-url + "
            "--auth-token."
        )
        raise typer.Exit(code=2)

    try:
        client = GraphoraClient(
            base_url=resolved_base_url, auth_token=resolved_auth_token
        )
    except ValueError as exc:
        console.print(f"[red]Error:[/red] {exc}")
        raise typer.Exit(code=2)

    try:
        payload = client.diff_transforms(
            base_transform_id, compare_transform_id
        )
    except GraphoraAPIError as exc:
        # 413 is the well-known "too big to diff" case (mirrors
        # /golden/score). Surface a specific message so users
        # don't think the diff service is broken.
        if exc.status_code == 413:
            console.print(
                "[red]Diff refused:[/red] one side of this comparison "
                "exceeds the 10k-node diff cap. Streaming diff for "
                "large transforms is not yet supported."
            )
            raise typer.Exit(code=1)
        console.print(f"[red]API error:[/red] {exc}")
        raise typer.Exit(code=1)
    except GraphoraClientError as exc:
        console.print(f"[red]Client error:[/red] {exc}")
        raise typer.Exit(code=2)

    if json_output:
        # Plain print so piping to a file doesn't get Rich's
        # terminal-wrapping treatment.
        if console.is_terminal:
            console.print(JSON(json.dumps(payload, default=str)))
        else:
            print(json.dumps(payload, indent=2, default=str))
        return

    _render(payload, show_unchanged=show_unchanged, limit=limit)


# ============================================================
# Rendering
# ============================================================


def _render(
    payload: Dict[str, Any], *, show_unchanged: bool, limit: int
) -> None:
    """Render the diff payload as a summary table + detail tables.

    Layout: header panel naming the two transforms, summary table
    of counts, then one detail block per change category that has
    at least one entry. Empty sections are skipped to keep the
    output tight — operators can see at a glance whether there's
    any delta in a given category.
    """
    base = payload.get("base_transform_id", "?")
    compare = payload.get("compare_transform_id", "?")
    console.print(
        Panel(
            f"[bold]base:[/bold] {_safe(base)}\n[bold]compare:[/bold] {_safe(compare)}",
            title="Transform Diff",
            box=box.ROUNDED,
        )
    )

    _render_summary_table(payload.get("summary", {}), show_unchanged=show_unchanged)

    # Detail sections — skip those with no entries so a "nothing
    # added" run doesn't paint three empty tables. The summary
    # already conveys "zero" via its counts.
    _render_node_detail(
        "Added nodes",
        payload.get("added_nodes", []),
        style="green",
        limit=limit,
    )
    _render_node_detail(
        "Removed nodes",
        payload.get("removed_nodes", []),
        style="red",
        limit=limit,
    )
    _render_changed_nodes(payload.get("changed_nodes", []), limit=limit)
    _render_edge_detail(
        "Added edges",
        payload.get("added_edges", []),
        style="green",
        limit=limit,
    )
    _render_edge_detail(
        "Removed edges",
        payload.get("removed_edges", []),
        style="red",
        limit=limit,
    )
    _render_changed_edges(payload.get("changed_edges", []), limit=limit)


def _render_summary_table(
    summary: Dict[str, Any], *, show_unchanged: bool
) -> None:
    """Render the per-dimension count table. ``unchanged`` is
    optional because the operator usually only cares about
    added / removed / changed when reviewing a delta — but it's
    useful for sanity-checking 'most things stayed the same' so
    we expose it behind a flag."""
    table = Table(title="Summary", box=box.ROUNDED)
    table.add_column("Dimension", style="cyan")
    table.add_column("Added", justify="right", style="green")
    table.add_column("Removed", justify="right", style="red")
    table.add_column("Changed", justify="right", style="yellow")
    if show_unchanged:
        table.add_column("Unchanged", justify="right", style="dim")

    for dimension in ("nodes", "edges"):
        section = summary.get(dimension, {})
        row = [
            dimension.capitalize(),
            str(section.get("added", 0)),
            str(section.get("removed", 0)),
            str(section.get("changed", 0)),
        ]
        if show_unchanged:
            row.append(str(section.get("unchanged", 0)))
        table.add_row(*row)

    console.print(table)


def _render_node_detail(
    title: str, nodes: List[Dict[str, Any]], *, style: str, limit: int
) -> None:
    """Render a node-detail table (added or removed). Skipped
    silently when ``nodes`` is empty — the summary already shows
    the zero count, an empty table would just be noise."""
    if not nodes:
        return

    extra = max(0, len(nodes) - limit)
    table = Table(
        title=f"{title} ({len(nodes)})",
        box=box.SIMPLE,
        border_style=style,
    )
    table.add_column("Label / id", style=style)
    table.add_column("Type", style="dim")
    table.add_column("canonical_id", style="dim")

    for node in nodes[:limit]:
        props = node.get("properties", {}) or {}
        canonical_id = props.get("canonical_id") or "—"
        # Truncate canonical_id to keep the column tight — full
        # value is in --json output if the operator needs it.
        if len(canonical_id) > 36:
            canonical_id = canonical_id[:8] + "…" + canonical_id[-4:]
        table.add_row(
            _safe(node.get("label") or node.get("id", "?")),
            _safe(node.get("type", "?")),
            _safe(canonical_id),
        )

    if extra:
        table.add_row(
            f"[dim]… {extra} more (use --json or -n {len(nodes)} to see all)[/dim]",
            "",
            "",
        )
    console.print(table)


def _render_changed_nodes(
    changed: List[Dict[str, Any]], *, limit: int
) -> None:
    """Render the changed-nodes section. Each entry has a
    property_changes dict — the table shows one row per
    (node, property) pair so the user sees exactly which fields
    moved without expanding nested JSON in their head."""
    if not changed:
        return

    extra = max(0, len(changed) - limit)
    table = Table(
        title=f"Changed nodes ({len(changed)})",
        box=box.SIMPLE,
        border_style="yellow",
    )
    table.add_column("Type", style="dim")
    table.add_column("canonical_id", style="dim")
    table.add_column("Property", style="yellow")
    table.add_column("base", style="red")
    table.add_column("compare", style="green")

    for entry in changed[:limit]:
        canonical_id = entry.get("canonical_id") or "—"
        if len(canonical_id) > 36:
            canonical_id = canonical_id[:8] + "…" + canonical_id[-4:]
        node_type = entry.get("type", "?")
        prop_changes = entry.get("property_changes") or {}
        if not prop_changes:
            # Defensive: changed-but-no-property-changes shouldn't
            # happen given the server's filtering, but if it does
            # surface a row so the operator knows the node was in
            # the changed set.
            table.add_row(
                _safe(node_type),
                _safe(canonical_id),
                "(no properties)",
                "",
                "",
            )
            continue
        # First row carries the type + canonical_id; subsequent
        # rows for the same node leave those columns blank so the
        # eye groups by node naturally.
        first = True
        for prop, change in prop_changes.items():
            base_val = _format_change_val(change.get("base"))
            compare_val = _format_change_val(change.get("compare"))
            table.add_row(
                _safe(node_type) if first else "",
                _safe(canonical_id) if first else "",
                _safe(prop),
                base_val,  # already escaped via _format_change_val
                compare_val,
            )
            first = False

    if extra:
        table.add_row(
            f"[dim]… {extra} more (use --json or -n {len(changed)} to see all)[/dim]",
            "",
            "",
            "",
            "",
        )
    console.print(table)


def _render_edge_detail(
    title: str, edges: List[Dict[str, Any]], *, style: str, limit: int
) -> None:
    """Render an edge-detail table (added or removed). Same shape
    as the node version but with source/target columns."""
    if not edges:
        return

    extra = max(0, len(edges) - limit)
    table = Table(
        title=f"{title} ({len(edges)})",
        box=box.SIMPLE,
        border_style=style,
    )
    table.add_column("Type", style=style)
    table.add_column("Source", style="dim")
    table.add_column("Target", style="dim")
    table.add_column("Edge id", style="dim")

    for edge in edges[:limit]:
        table.add_row(
            _safe(edge.get("type", "?")),
            _safe(edge.get("source", "—")),
            _safe(edge.get("target", "—")),
            _safe(edge.get("id", "—")),
        )

    if extra:
        table.add_row(
            f"[dim]… {extra} more (use --json or -n {len(edges)} to see all)[/dim]",
            "",
            "",
            "",
        )
    console.print(table)


def _render_changed_edges(
    changed: List[Dict[str, Any]], *, limit: int
) -> None:
    """Render the changed-edges section. Mirrors changed-nodes
    layout: one row per (edge, property) pair, grouped by edge."""
    if not changed:
        return

    extra = max(0, len(changed) - limit)
    table = Table(
        title=f"Changed edges ({len(changed)})",
        box=box.SIMPLE,
        border_style="yellow",
    )
    table.add_column("Type", style="dim")
    table.add_column("base→compare ids", style="dim")
    table.add_column("Property", style="yellow")
    table.add_column("base", style="red")
    table.add_column("compare", style="green")

    for entry in changed[:limit]:
        edge_type = entry.get("type", "?")
        base_id = entry.get("base_id") or "—"
        compare_id = entry.get("compare_id") or "—"
        # Compose the ids string from already-escaped pieces — using
        # raw concatenation here would re-introduce the markup hole
        # if either base_id or compare_id contained Rich tags.
        ids = f"{_safe(base_id)} → {_safe(compare_id)}"
        prop_changes = entry.get("property_changes") or {}
        if not prop_changes:
            table.add_row(_safe(edge_type), ids, "(no properties)", "", "")
            continue
        first = True
        for prop, change in prop_changes.items():
            base_val = _format_change_val(change.get("base"))
            compare_val = _format_change_val(change.get("compare"))
            table.add_row(
                _safe(edge_type) if first else "",
                ids if first else "",
                _safe(prop),
                base_val,  # already escaped via _format_change_val
                compare_val,
            )
            first = False

    if extra:
        table.add_row(
            f"[dim]… {extra} more (use --json or -n {len(changed)} to see all)[/dim]",
            "",
            "",
            "",
            "",
        )
    console.print(table)


def _safe(value: Any) -> str:
    """Stringify + escape a server/user-supplied value for a Rich cell.

    Rich treats ``[tag]…[/tag]`` substrings as inline markup, so an
    extracted property value like ``[admin]`` or ``[red]old[/red]``
    would either silently apply markup (text disappears or recolors)
    or raise a tag-mismatch error at render time — neither acceptable
    for a diff tool whose entire job is to faithfully show what
    changed. Reviewer-flagged Medium on commit `f667979`. Escape at
    every cell-add site for untrusted data; intentional markup
    (column styles via ``style=``, the dim "N more" footer string
    we build ourselves) keeps its semantics because the escape only
    applies where called.
    """
    if value is None:
        return "—"
    return rich_escape(str(value))


def _format_change_val(value: Any) -> str:
    """Stringify a property value for the changed table.

    JSON-encode complex values (dicts, lists) so a multi-key
    property change renders in one cell rather than blowing out
    the column. None becomes the em-dash so absence is visible
    rather than blank. All paths flow through ``_safe`` so a
    property value containing Rich markup (intentional or
    accidental) renders as text, not active formatting.
    """
    if value is None:
        return "—"
    if isinstance(value, (dict, list)):
        # compact JSON keeps the cell narrow; full structure is
        # always in --json output.
        return rich_escape(json.dumps(value, default=str, separators=(",", ":")))
    return rich_escape(str(value))
