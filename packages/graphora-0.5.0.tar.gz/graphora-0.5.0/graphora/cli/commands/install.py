"""``graphora install <client>`` — write MCP server config for an
agent client.

A7-cli (Gate 3 slice 1). Backed by graphora-server's
``graphora-mcp`` console script (audited end-to-end in
graphora-api commit 2fef273). The install command is the
operator-facing glue that wires the user's running Graphora
deployment (URL + auth token from the persisted config) into a
specific agent client's MCP configuration file.

Per-client plugin BUNDLES — skills, rules files, the
``.claude-plugin/`` directory — are tracked separately as
A7-claude / A7-codex / A7-cursor / A7-vscode in the execution
plan. This command ships the MCP-config-writing layer that
makes the per-client G3 exit signals' "MCP works in this
client" half achievable independently of bundle work.

Supported clients:
  * ``claude-desktop`` — user-global config at
    ``~/Library/Application Support/Claude/claude_desktop_config.json``
    (macOS) / ``%APPDATA%\\Claude\\claude_desktop_config.json``
    (Windows). Restart Claude Desktop after install.
  * ``claude-code`` — workspace-relative ``.mcp.json`` (the
    project-level MCP config Claude Code looks for when run
    from inside a workspace).
  * ``cursor`` — workspace-relative ``.cursor/mcp.json``. The
    workspace config wins over Cursor's user-global config
    when both exist.
  * ``codex`` — workspace-relative ``.codex-plugin/.mcp.json``
    inside the plugin bundle directory.
  * ``vscode`` — workspace-relative ``.vscode/mcp.json`` (read
    by MCP-compatible VS Code extensions).

Modes are deliberately conservative on overwrite: by default,
the command refuses to clobber an existing config file. Pass
``--force`` to overwrite, or accept the default merge behavior
which preserves any non-``graphora`` MCP servers in the
existing file and just upserts the ``graphora`` entry.
"""

from __future__ import annotations

import json
import os
import platform
import shutil
from dataclasses import dataclass
from pathlib import Path
from typing import Dict, List, Optional

import typer
from rich.console import Console
from rich.panel import Panel

from graphora.cli.config import get_api_url, get_auth_token

console = Console()


# ============================================================
# Client adapters
# ============================================================


@dataclass(frozen=True)
class ClientAdapter:
    """One per supported client. Encodes:
      * config_path: where to write the MCP config JSON.
        Absolute for user-global locations (claude-desktop);
        workspace-relative for everything else.
      * description: surfaced in the help / dry-run output so
        operators see what's about to happen without guessing.
    """

    name: str
    description: str
    config_path: Path
    workspace_relative: bool

    def resolve_path(self, workspace_root: Path) -> Path:
        """Absolute path the install will write to.

        Workspace-relative adapters resolve against the
        ``workspace_root`` (typically the operator's current
        directory). User-global adapters return their absolute
        path as-is, ignoring the workspace.
        """
        if self.workspace_relative:
            return workspace_root / self.config_path
        return self.config_path


def _claude_desktop_path() -> Path:
    """User-global Claude Desktop config file. Platform-aware —
    macOS uses ``~/Library/Application Support/Claude/``,
    Windows uses ``%APPDATA%\\Claude\\``, Linux uses
    ``~/.config/Claude/`` (the path Claude Desktop on Linux
    expects; though Claude Desktop itself is macOS-and-Windows
    today, the Linux path covers third-party MCP clients that
    follow the same convention)."""
    system = platform.system()
    if system == "Darwin":
        return (
            Path.home()
            / "Library"
            / "Application Support"
            / "Claude"
            / "claude_desktop_config.json"
        )
    if system == "Windows":
        appdata = os.environ.get("APPDATA")
        if appdata:
            return Path(appdata) / "Claude" / "claude_desktop_config.json"
        # Fallback path for environments without %APPDATA% set.
        return (
            Path.home() / "AppData" / "Roaming" / "Claude" / "claude_desktop_config.json"
        )
    return Path.home() / ".config" / "Claude" / "claude_desktop_config.json"


CLIENT_ADAPTERS: Dict[str, ClientAdapter] = {
    "claude-desktop": ClientAdapter(
        name="claude-desktop",
        description=(
            "Claude Desktop (user-global). Writes "
            "claude_desktop_config.json under the OS-specific "
            "Claude config directory. Restart Claude Desktop after "
            "install for the new MCP server to appear."
        ),
        config_path=_claude_desktop_path(),
        workspace_relative=False,
    ),
    "claude-code": ClientAdapter(
        name="claude-code",
        description=(
            "Claude Code (workspace). Writes .mcp.json at the "
            "workspace root — Claude Code picks this up on the "
            "next session start in this directory."
        ),
        config_path=Path(".mcp.json"),
        workspace_relative=True,
    ),
    "cursor": ClientAdapter(
        name="cursor",
        description=(
            "Cursor (workspace). Writes .cursor/mcp.json. The "
            "workspace config wins over Cursor's user-global "
            "config when both exist."
        ),
        config_path=Path(".cursor") / "mcp.json",
        workspace_relative=True,
    ),
    "codex": ClientAdapter(
        name="codex",
        description=(
            "Codex (workspace). Writes .codex-plugin/.mcp.json — "
            "the MCP config inside the Codex plugin bundle "
            "directory."
        ),
        config_path=Path(".codex-plugin") / ".mcp.json",
        workspace_relative=True,
    ),
    "vscode": ClientAdapter(
        name="vscode",
        description=(
            "VS Code (workspace). Writes .vscode/mcp.json — read "
            "by MCP-compatible VS Code extensions."
        ),
        config_path=Path(".vscode") / "mcp.json",
        workspace_relative=True,
    ),
}


# ============================================================
# Config building + merging
# ============================================================


def _build_graphora_server_config(
    api_url: str, auth_token: Optional[str], command: str
) -> Dict[str, object]:
    """Build the ``mcpServers.graphora`` entry the agent client
    will read. ``command`` is the graphora-mcp executable —
    typically just ``"graphora-mcp"`` (relying on PATH); the
    --command flag lets operators point at an absolute path
    when the client launches from a shell that doesn't include
    the install directory."""
    env: Dict[str, str] = {"GRAPHORA_API_URL": api_url}
    if auth_token:
        env["GRAPHORA_AUTH_TOKEN"] = auth_token
    return {"command": command, "env": env}


def _merge_config(
    existing: Optional[Dict[str, object]],
    graphora_server: Dict[str, object],
) -> Dict[str, object]:
    """Merge the graphora MCP server entry into the existing
    config file's ``mcpServers`` mapping.

    Preserves any other MCP server entries the operator has
    configured (e.g., a filesystem MCP server alongside
    graphora) — only the ``graphora`` key gets upserted. If
    ``mcpServers`` doesn't exist, creates it. If the existing
    config has top-level keys beyond ``mcpServers`` (some
    clients carry other config under the same file), those keys
    are preserved.
    """
    merged: Dict[str, object] = dict(existing) if existing else {}
    servers = merged.get("mcpServers")
    if not isinstance(servers, dict):
        servers = {}
    servers = dict(servers)
    servers["graphora"] = graphora_server
    merged["mcpServers"] = servers
    return merged


def _read_existing(path: Path) -> Optional[Dict[str, object]]:
    """Read and parse an existing config file. Returns None if
    the file doesn't exist; raises typer.Exit on malformed
    JSON (don't silently overwrite something the operator
    might have hand-edited)."""
    if not path.exists():
        return None
    try:
        text = path.read_text()
    except OSError as exc:
        console.print(
            f"[red]Could not read existing config at[/red] {path}: {exc}"
        )
        raise typer.Exit(code=2)
    if not text.strip():
        return None
    try:
        parsed = json.loads(text)
    except json.JSONDecodeError as exc:
        console.print(
            f"[red]Existing config at {path} is not valid JSON:[/red] "
            f"{exc.msg}"
        )
        console.print(
            "Refusing to overwrite — fix the JSON or pass [cyan]--force[/cyan] "
            "to replace the file."
        )
        raise typer.Exit(code=2)
    if not isinstance(parsed, dict):
        console.print(
            f"[red]Existing config at {path} is not a JSON object[/red]"
        )
        raise typer.Exit(code=2)
    # Reviewer-flagged Medium on commit bca4c4b: pre-fix the merge
    # path silently replaced a non-dict ``mcpServers`` value with
    # ``{}``, so a semantically-malformed config (e.g.,
    # ``{"mcpServers": [...]}`` where the value is a list) got
    # quietly overwritten without --force — exactly the failure
    # mode the malformed-JSON refusal posture was protecting
    # against. Treat non-dict ``mcpServers`` as malformed at the
    # read layer so the refusal posture covers both shapes
    # (invalid JSON AND invalid ``mcpServers`` type). ``null``
    # and missing keys stay legitimate empty-state representations
    # (the merge path handles both as "no servers configured").
    servers = parsed.get("mcpServers")
    if servers is not None and not isinstance(servers, dict):
        console.print(
            f"[red]Existing config at {path} has a non-object "
            f"``mcpServers`` value[/red] (got {type(servers).__name__})."
        )
        console.print(
            "Refusing to overwrite — fix the shape or pass "
            "[cyan]--force[/cyan] to replace the file."
        )
        raise typer.Exit(code=2)
    return parsed


# ============================================================
# CLI entry point
# ============================================================


def install(
    client: str = typer.Argument(
        ...,
        help=(
            "Agent client to install for. One of: "
            + ", ".join(sorted(CLIENT_ADAPTERS.keys()))
        ),
    ),
    api_url: Optional[str] = typer.Option(
        None,
        "--api-url",
        help=(
            "Graphora API URL the MCP server will talk to. "
            "Defaults to the URL from `graphora config init` / "
            "the GRAPHORA_API_URL env var."
        ),
    ),
    auth_token: Optional[str] = typer.Option(
        None,
        "--auth-token",
        help=(
            "Auth token for the Graphora API. Optional — when "
            "omitted, falls back to the token from "
            "`graphora config init` / GRAPHORA_AUTH_TOKEN. If "
            "the server has auth bypass enabled, you can pass "
            "an empty string or skip this flag."
        ),
    ),
    command: str = typer.Option(
        "graphora-mcp",
        "--command",
        help=(
            "Path to the graphora-mcp executable. Defaults to "
            "the unqualified ``graphora-mcp`` (relying on PATH). "
            "If your agent client launches from a shell that "
            "doesn't include the install directory, pass an "
            "absolute path here (e.g., /Users/you/.local/bin/"
            "graphora-mcp or your venv's "
            ".venv/bin/graphora-mcp)."
        ),
    ),
    workspace: Optional[Path] = typer.Option(
        None,
        "--workspace",
        help=(
            "Workspace root for workspace-relative configs "
            "(cursor / vscode / codex / claude-code). Defaults "
            "to the current directory. Ignored for "
            "claude-desktop, which is user-global."
        ),
    ),
    force: bool = typer.Option(
        False,
        "--force",
        help=(
            "Overwrite the existing config file completely "
            "instead of merging the graphora entry into "
            "mcpServers. Destructive — use only when you want "
            "to wipe other MCP server entries."
        ),
    ),
    dry_run: bool = typer.Option(
        False,
        "--dry-run",
        help=(
            "Print the resolved config + target path without "
            "writing the file."
        ),
    ),
):
    """Wire Graphora's MCP server into an agent client's config.

    Examples:

      # Workspace-relative install for Cursor
      graphora install cursor

      # User-global install for Claude Desktop
      graphora install claude-desktop

      # Preview the config without writing
      graphora install cursor --dry-run

      # Override the API URL + auth token for a one-off
      graphora install cursor --api-url http://localhost:8000 \\
          --auth-token <jwt>
    """
    if client not in CLIENT_ADAPTERS:
        console.print(
            f"[red]Unknown client[/red] {client!r}. Supported: "
            + ", ".join(sorted(CLIENT_ADAPTERS.keys()))
        )
        raise typer.Exit(code=2)
    adapter = CLIENT_ADAPTERS[client]

    resolved_url = api_url or get_api_url()
    if not resolved_url:
        console.print(
            "[red]No API URL configured.[/red] Pass [cyan]--api-url[/cyan] "
            "or run [cyan]graphora config init --mode remote[/cyan] first."
        )
        raise typer.Exit(code=2)
    resolved_token = auth_token if auth_token is not None else get_auth_token()

    workspace_root = workspace or Path.cwd()
    target_path = adapter.resolve_path(workspace_root)

    graphora_server = _build_graphora_server_config(
        api_url=resolved_url,
        auth_token=resolved_token,
        command=command,
    )

    if force:
        # Force mode: skip the merge and emit just the graphora
        # entry. Operators who pass --force are explicitly opting
        # into a clean slate.
        final_config: Dict[str, object] = {"mcpServers": {"graphora": graphora_server}}
    else:
        existing = _read_existing(target_path)
        final_config = _merge_config(existing, graphora_server)

    if dry_run:
        console.print(
            Panel.fit(
                f"[bold]{adapter.name}[/bold]\n{adapter.description}",
                title="install (dry-run)",
            )
        )
        console.print(f"\nTarget: [cyan]{target_path}[/cyan]")
        console.print("\n[bold]Resolved config:[/bold]")
        console.print(json.dumps(final_config, indent=2))
        return

    # Write the config — create the parent directory if needed
    # (workspace-relative paths often need .cursor/, .vscode/,
    # .codex-plugin/ created).
    target_path.parent.mkdir(parents=True, exist_ok=True)
    target_path.write_text(json.dumps(final_config, indent=2) + "\n")

    console.print(
        f"[green]Wrote MCP config for {adapter.name}[/green] to {target_path}"
    )
    if not _command_is_resolvable(command):
        # Reviewer-flagged Open Question on commit bca4c4b: the
        # generated config references ``graphora-mcp``, but that
        # binary only lands when ``graphora-server[mcp]`` is
        # installed — NOT just from installing graphora-client.
        # If the agent client tries to launch a missing command,
        # it surfaces as an opaque "MCP server failed to start"
        # error in the client UI. Catch the foot-gun at install
        # time: when ``shutil.which`` (or a direct file check for
        # absolute paths) misses the command, warn so the
        # operator sees the missing prerequisite before they
        # bounce off the agent client's error message.
        #
        # Warn-only (not error) because the install machine and
        # the agent-client-launching machine can differ. An
        # operator preparing a workspace config to commit might
        # not have graphora-mcp locally — that's fine; the
        # warning still flags the dependency so they document it
        # for downstream users.
        # Rich treats ``[mcp]`` as an unclosed markup tag and
        # strips it from the rendered output — escape the
        # literal brackets so the install hint actually
        # mentions the [mcp] extra. Pre-fix this rendered as
        # "pip install 'graphora-server'." (without the
        # extra), exactly the foot-gun the warning is meant to
        # prevent.
        console.print(
            f"[yellow]Warning:[/yellow] {command} is not on PATH "
            "in this shell. Agent clients that launch the MCP "
            "server will fail unless [cyan]graphora-mcp[/cyan] is "
            "installed and discoverable from the client's "
            "environment. Install with: [cyan]pip install "
            "'graphora-server\\[mcp]'[/cyan]. If the command is "
            "available in a different location (e.g., a venv), "
            "pass [cyan]--command /absolute/path/to/graphora-mcp"
            "[/cyan]."
        )
    if not resolved_token:
        console.print(
            "[yellow]Note:[/yellow] no auth token was configured. The "
            "MCP server will rely on the Graphora API having auth "
            "bypass enabled. Set one with [cyan]graphora config init"
            "[/cyan] or pass [cyan]--auth-token[/cyan]."
        )
    if adapter.name == "claude-desktop":
        console.print(
            "Restart Claude Desktop for the new MCP server to appear "
            "in the tool list."
        )


def _command_is_resolvable(command: str) -> bool:
    """Return True if the operator's machine can launch ``command``.

    Two cases:
      * Unqualified name (e.g., ``graphora-mcp``) → check PATH via
        ``shutil.which``. Returns True if the binary is on PATH.
      * Path-shaped (contains ``/`` or starts with ``.``) → check
        the file exists and is executable. shutil.which doesn't
        handle absolute-or-relative paths the way we want on all
        platforms, so do it directly.

    Windows: shutil.which handles PATHEXT for the unqualified
    case. The absolute-path case checks for the literal file —
    operators on Windows passing a ``.exe`` path get the right
    answer; operators passing a bare path without the extension
    will see a warning, which is the right diagnostic (Windows
    won't launch it either).

    Reviewer-flagged Low on commit 7e7202a: the absolute-path
    branch previously only checked ``is_file()`` and missed the
    executability requirement. A path-shaped --command pointing
    at a non-executable file (chmod -x'd by mistake) suppressed
    the warning even though the agent client couldn't actually
    launch it. Pair ``is_file()`` with ``os.access(path, os.X_OK)``
    so the warning fires whenever the binary won't actually run.
    """
    if not command:
        return False
    looks_like_path = (
        "/" in command
        or "\\" in command
        or command.startswith(".")
    )
    if looks_like_path:
        path = Path(command).expanduser()
        # os.access checks effective permissions (with cross-
        # platform semantics: on Windows X_OK is True for any
        # readable file, which matches Windows's launch
        # behavior — the .exe extension is what gates
        # executability there, not POSIX permission bits).
        return path.is_file() and os.access(path, os.X_OK)
    return shutil.which(command) is not None


# ============================================================
# Helpers exposed for tests
# ============================================================


def supported_clients() -> List[str]:
    """Stable list of supported client names. Used by the test
    suite to walk every adapter in a single parametrize."""
    return sorted(CLIENT_ADAPTERS.keys())
