"""Test command — run extraction against a golden corpus and score the results.

B4-test (Gate 4) runner. The companion to graphora-server's
golden-corpus seed (commit 48dbe0a / a1505e0) and scoring
endpoint (commit 9fb4909 / e21c1f5 / 834d724). Given a directory
of curated docs with ground-truth expectations, this command
orchestrates the full extract-and-score loop:

    for each <slug>/ subdir under the corpus root:
        register_ontology(<slug>/ontology.yaml)
        transform(<slug>/document.txt)  →  transform_id
        wait_for_transform(transform_id)
        score_against_golden(<slug>/expected.json, transform_id)
        record the report

At the end, render a Rich table of per-doc P/R/F1 + aggregate
counts, and exit with code 0 when every doc's F1 meets the
``--min-f1`` threshold (default 0.0 — informational mode). CI
pipelines that want gating pass ``--min-f1 0.6`` (or similar)
and treat exit code 1 as a regression signal.

The command intentionally has no schema-inference path: B4-test
benchmarks a model + ontology combination against a fixed
ground truth, so an unstable LLM-inferred schema would
introduce noise that defeats the regression-detection purpose.
The corpus owns the ontology; the runner consumes it as-is.
"""

from __future__ import annotations

import json
from pathlib import Path
from typing import Any, Dict, List, Optional

import typer
from rich import box
from rich.console import Console
from rich.json import JSON
from rich.progress import (
    BarColumn,
    Progress,
    SpinnerColumn,
    TextColumn,
    TimeElapsedColumn,
)
from rich.table import Table

from graphora.cli.config import get_api_url, get_auth_token
from graphora.cli.runtime import get_missing_config, validate_remote_environment
from graphora.client import GraphoraClient
from graphora.exceptions import GraphoraAPIError, GraphoraClientError

console = Console()


# ============================================================
# CLI entry point
# ============================================================


def run(
    corpus_path: Path = typer.Argument(
        ...,
        help=(
            "Path to a golden corpus directory. The runner walks "
            "each immediate subdirectory and treats any subdir that "
            "contains document.txt + ontology.yaml + expected.json "
            "as a single corpus entry."
        ),
        exists=True,
        file_okay=False,
        dir_okay=True,
    ),
    min_f1: float = typer.Option(
        0.0,
        "--min-f1",
        help=(
            "Minimum F1 score required for the run to exit 0. "
            "Applied to both nodes.f1 and edges.f1 of each "
            "corpus entry. Default 0.0 makes the runner "
            "informational — set above 0 to gate CI."
        ),
        min=0.0,
        max=1.0,
    ),
    output: Optional[Path] = typer.Option(
        None,
        "--output",
        "-o",
        help=(
            "Write the full per-doc report set + summary to this "
            "path as JSON. If omitted, only the Rich summary table "
            "is rendered."
        ),
    ),
    json_output: bool = typer.Option(
        False,
        "--json",
        help=(
            "Emit the aggregated report set to stdout as JSON "
            "instead of the Rich table. Useful for piping into "
            "scripts. Implies --output behaviour for stdout."
        ),
    ),
    timeout: int = typer.Option(
        600,
        "--timeout",
        help=(
            "Per-document timeout for wait_for_transform, in "
            "seconds. Large docs with slow LLMs may need >300; "
            "default 600 covers the corpus seed entries with "
            "comfortable headroom."
        ),
        min=30,
    ),
    base_url: Optional[str] = typer.Option(
        None,
        "--api-url",
        help=(
            "Graphora API base URL. Falls back to GRAPHORA_API_URL "
            "and then ~/.graphora/config.yaml (api.url)."
        ),
    ),
    auth_token: Optional[str] = typer.Option(
        None,
        "--auth-token",
        help=(
            "Clerk bearer token. Falls back to GRAPHORA_AUTH_TOKEN "
            "and then ~/.graphora/config.yaml (api.auth_token)."
        ),
    ),
):
    """Run a golden-corpus regression test against a Graphora API.

    For each document subdirectory under ``corpus_path``, the runner:
        1. Registers the ontology from ``ontology.yaml``.
        2. Uploads ``document.txt`` and starts a transform.
        3. Waits for extraction to complete.
        4. POSTs the live transform_id + ``expected.json`` to
           /api/v1/golden/score and records the report.

    At the end, prints a per-doc + aggregate summary. Exit code:
        0 — every doc's nodes.f1 and edges.f1 met --min-f1.
        1 — at least one doc fell below the threshold.
        2 — configuration / corpus problem (no docs, missing
            credentials, etc.).

    Examples:

        graphora test golden/
        graphora test golden/ --min-f1 0.6
        graphora test golden/ --json > report.json
        graphora test golden/ -o report.json --min-f1 0.5
    """
    # ----- Credential resolution (mirrors explain.py's pattern) -----
    # The same reviewer-flagged resolution chain explain uses:
    # explicit option > env var > persisted config. Without this,
    # users who set up ~/.graphora/config.yaml via `graphora config
    # init --mode remote` would silently fall through to a "missing
    # token" error.
    resolved_base_url = base_url or get_api_url()
    resolved_auth_token = auth_token or get_auth_token()

    if not validate_remote_environment() and not (
        resolved_base_url and resolved_auth_token
    ):
        missing = get_missing_config("remote")
        console.print("[red]Missing required configuration:[/red]")
        for item in missing:
            console.print(f"  - {item}")
        console.print(
            "\nRun [cyan]graphora config init --mode remote[/cyan] "
            "to set up configuration, or pass --api-url + "
            "--auth-token."
        )
        raise typer.Exit(code=2)

    # ----- Corpus discovery -----
    entries = _discover_corpus_entries(corpus_path)
    if not entries:
        console.print(
            f"[red]No corpus entries found under {corpus_path}.[/red] "
            "Each entry must be a subdirectory containing "
            "document.txt, ontology.yaml, and expected.json."
        )
        raise typer.Exit(code=2)

    # ----- Client init -----
    try:
        client = GraphoraClient(
            base_url=resolved_base_url,
            auth_token=resolved_auth_token,
            timeout=timeout,
        )
    except ValueError as exc:
        # Auth missing after resolution — surface the same friendly
        # message explain does.
        console.print(f"[red]Error:[/red] {exc}")
        raise typer.Exit(code=2)

    # ----- Run each entry -----
    reports: List[Dict[str, Any]] = []
    failures: List[Dict[str, Any]] = []

    # Progress bar suppressed in JSON mode so stdout stays
    # machine-parseable for downstream piping. Without this,
    # the Rich bar's characters leak into the captured stdout
    # and break `graphora test ... --json | jq ...`.
    with Progress(
        SpinnerColumn(),
        TextColumn("[progress.description]{task.description}"),
        BarColumn(),
        TimeElapsedColumn(),
        console=console,
        transient=False,
        disable=json_output,
    ) as progress:
        overall = progress.add_task(
            f"Scoring {len(entries)} corpus entries...", total=len(entries)
        )
        for entry in entries:
            slug = entry["slug"]
            try:
                report = _run_entry(client, entry, timeout=timeout)
                reports.append(report)
            except (
                GraphoraAPIError,
                GraphoraClientError,
                OSError,
                ValueError,
            ) as exc:
                # Per-entry failure mode: record the error but keep
                # going. A single broken doc shouldn't abort the
                # whole corpus run — the operator wants to see the
                # other docs' regressions too. Reviewer-flagged
                # Medium on commit 80e1509: this catch must cover
                # both remote-side (GraphoraAPIError/ClientError)
                # AND local-side errors. ``_run_entry`` reads
                # ontology.yaml + expected.json from disk before
                # touching the network — an OSError from a missing
                # file or a json.JSONDecodeError (subclass of
                # ValueError) from a malformed expected.json must
                # land here too. Otherwise one corpus dir with a
                # typo in expected.json would kill the whole run
                # instead of being recorded as a single failed
                # entry — breaking the isolation contract.
                failures.append({"slug": slug, "error": str(exc)})
            progress.advance(overall)

    # ----- Output -----
    aggregate = _build_aggregate(reports, failures, min_f1=min_f1)

    if json_output:
        # Plain print (not console.print) so piping to a file
        # doesn't get Rich's terminal-wrapping treatment.
        print(json.dumps(aggregate, indent=2, default=str))
    else:
        _render_summary(aggregate, min_f1=min_f1)

    if output:
        output.write_text(json.dumps(aggregate, indent=2, default=str))
        if not json_output:
            console.print(f"\n[dim]Full report written to {output}[/dim]")

    # Gating: aggregate has ``passed`` already computed against
    # --min-f1.
    if not aggregate["passed"]:
        raise typer.Exit(code=1)


# ============================================================
# Corpus discovery
# ============================================================


def _discover_corpus_entries(corpus_root: Path) -> List[Dict[str, Any]]:
    """Walk the corpus root for entry directories.

    A corpus entry is a subdirectory containing all three of:
        document.txt
        ontology.yaml
        expected.json

    Other subdirectories are silently skipped so the corpus root
    can also hold a README, helpers, etc. Returns a sorted list
    so the run order is stable across invocations — important
    for reproducible regression reports.
    """
    entries: List[Dict[str, Any]] = []
    for child in sorted(corpus_root.iterdir()):
        if not child.is_dir():
            continue
        document = child / "document.txt"
        ontology = child / "ontology.yaml"
        expected = child / "expected.json"
        if document.exists() and ontology.exists() and expected.exists():
            entries.append(
                {
                    "slug": child.name,
                    "document_path": document,
                    "ontology_path": ontology,
                    "expected_path": expected,
                }
            )
    return entries


# ============================================================
# Per-entry runner
# ============================================================


def _run_entry(
    client: GraphoraClient,
    entry: Dict[str, Any],
    timeout: int,
) -> Dict[str, Any]:
    """Orchestrate the four-step pipeline for one corpus entry.

    Step 1 (register_ontology): the corpus owns the ontology, so
    we register exactly what's on disk. Inferring would defeat
    the regression-detection purpose.

    Step 2 (transform): upload document.txt with the registered
    ontology. The server enqueues a transform; the synchronous
    flow lives in graphora-server's transform router.

    Step 3 (wait_for_transform): poll until COMPLETED or FAILED.
    Failures abort the entry — there's no actual graph to score
    against. The exception bubbles up to the per-entry try/except
    in the orchestrator.

    Step 4 (score_against_golden): POST expected.json + the live
    transform_id; the server-side CorpusScorer wraps DiffService
    for identity matching and returns the P/R/F1 report.
    """
    slug = entry["slug"]
    ontology_yaml = entry["ontology_path"].read_text()
    expected = json.loads(entry["expected_path"].read_text())

    # Step 1: register ontology.
    ontology_response = client.register_ontology(ontology_yaml)
    ontology_id = ontology_response.id

    # Step 2: upload + transform.
    transform_response = client.transform(ontology_id, [entry["document_path"]])
    transform_id = transform_response.id

    # Step 3: wait for extraction.
    final_status = client.wait_for_transform(transform_id, timeout=timeout)

    # Step 4: score. Even a FAILED transform gets scored — the
    # /golden/score endpoint produces an all-FN report on an
    # empty actual graph (commit 834d724), which is exactly the
    # regression signal the runner needs to surface.
    report = client.score_against_golden(
        expected=expected,
        transform_id=transform_id,
        corpus_slug=slug,
    )

    # Stitch on runner-level metadata so the JSON output is
    # self-contained.
    report["_meta"] = {
        "slug": slug,
        "transform_id": transform_id,
        "ontology_id": ontology_id,
        "transform_status": getattr(final_status, "overall_status", "unknown").value
        if hasattr(getattr(final_status, "overall_status", None), "value")
        else str(getattr(final_status, "overall_status", "unknown")),
    }
    return report


# ============================================================
# Aggregation + threshold gating
# ============================================================


def _build_aggregate(
    reports: List[Dict[str, Any]],
    failures: List[Dict[str, Any]],
    min_f1: float,
) -> Dict[str, Any]:
    """Stitch per-doc reports into a single summary payload.

    The ``passed`` flag is the gating signal — true iff every
    successful report has each *applicable* dimension's F1 above
    ``min_f1``, AND no orchestration failures occurred. Failures
    always fail the run because we have no evidence the doc
    would have scored above the threshold.

    A dimension is "applicable" when it has at least one TP, FP,
    or FN — i.e., either the ground truth had items in that
    dimension or the extractor produced some. Dimensions with
    TP+FP+FN == 0 are skipped: the server scorer returns 0.0
    F1 for zero-denominator dimensions (intentionally, for JSON
    cleanliness — NaN doesn't serialize), but that's a
    placeholder, not a real score. Reviewer-flagged High on
    commit 80e1509: gating on the placeholder makes node-only
    corpus entries (expected.edges == []) impossible to pass
    any ``--min-f1 > 0`` even when the extractor's behavior is
    correct.
    """
    all_pass = not failures
    for report in reports:
        for dimension in ("nodes", "edges"):
            scores = report.get(dimension, {})
            if not _dimension_is_applicable(scores):
                continue
            if scores.get("f1", 0.0) < min_f1:
                all_pass = False

    return {
        "reports": reports,
        "failures": failures,
        "min_f1": min_f1,
        "passed": all_pass,
        "total_entries": len(reports) + len(failures),
        "successful_entries": len(reports),
        "failed_entries": len(failures),
    }


# ============================================================
# Rich rendering
# ============================================================


def _render_summary(aggregate: Dict[str, Any], min_f1: float) -> None:
    """Render the per-doc + aggregate summary as a Rich table.

    The columns are picked to match what an operator scans for
    during a regression review: slug first (so eye can match the
    corpus dir name), then the two F1 scores side-by-side with
    color coding against the threshold. Raw TP/FP/FN counts are
    secondary — they're the why behind the F1 score, not the
    primary signal.
    """
    reports = aggregate["reports"]
    failures = aggregate["failures"]

    if reports:
        table = Table(
            title="Golden Corpus Scoring",
            box=box.ROUNDED,
            caption=(
                f"min_f1={min_f1} | "
                f"{aggregate['successful_entries']} scored, "
                f"{aggregate['failed_entries']} failed"
            ),
        )
        table.add_column("Slug", style="cyan")
        table.add_column("Nodes F1", justify="right")
        table.add_column("Recall", justify="right", style="dim")
        table.add_column("Precision", justify="right", style="dim")
        table.add_column("Edges F1", justify="right")
        table.add_column("TP / FP / FN", justify="right", style="dim")

        for report in reports:
            slug = report.get("corpus_slug", "?") or report.get("_meta", {}).get(
                "slug", "?"
            )
            nodes = report.get("nodes", {})
            edges = report.get("edges", {})

            # Node-side TP/FP/FN totals across types — same shape
            # the scorer's ScoringReport surfaces.
            counts = (
                f"{_sum_counts(nodes, 'true_positives')}/"
                f"{_sum_counts(nodes, 'false_positives')}/"
                f"{_sum_counts(nodes, 'false_negatives')}"
            )

            table.add_row(
                slug,
                _render_f1_cell(nodes, min_f1),
                f"{nodes.get('recall', 0.0):.3f}",
                f"{nodes.get('precision', 0.0):.3f}",
                _render_f1_cell(edges, min_f1),
                counts,
            )

        console.print(table)

    if failures:
        fail_table = Table(
            title="Orchestration Failures",
            box=box.ROUNDED,
            border_style="red",
        )
        fail_table.add_column("Slug", style="cyan")
        fail_table.add_column("Error", style="red")
        for failure in failures:
            fail_table.add_row(failure["slug"], failure["error"])
        console.print(fail_table)

    # Verdict line — the one line a CI dashboard can scrape.
    if aggregate["passed"]:
        console.print(
            f"\n[green]PASS[/green] — all entries scored at or "
            f"above F1={min_f1}."
        )
    else:
        console.print(
            f"\n[red]FAIL[/red] — at least one entry fell below "
            f"F1={min_f1} or failed orchestration."
        )


def _render_f1_cell(graph_scores: Dict[str, Any], threshold: float) -> str:
    """Render an F1 cell with appropriate coloring or N/A.

    Mirrors the gating logic in ``_build_aggregate``: a dimension
    with no expected/predicted items is not gated, so showing its
    placeholder 0.0 colored red would be misleading. Render it as
    "N/A" in dim style instead — operators can see at a glance
    that this dimension isn't a regression signal for the entry.
    """
    if not _dimension_is_applicable(graph_scores):
        return "[dim]N/A[/dim]"
    score = graph_scores.get("f1", 0.0)
    color = _f1_color(score, threshold)
    return f"[{color}]{score:.3f}[/{color}]"


def _f1_color(score: float, threshold: float) -> str:
    """Map an F1 score to a Rich color tag relative to the gate.

    Green when at/above threshold, yellow within 0.1 below, red
    further out. The 0.1 yellow band is a heuristic — close to the
    line is worth flagging visually even when technically passing
    or failing.
    """
    if score >= threshold:
        return "green"
    if score >= max(0.0, threshold - 0.1):
        return "yellow"
    return "red"


def _dimension_is_applicable(graph_scores: Dict[str, Any]) -> bool:
    """Return True iff the dimension has at least one TP, FP, or FN.

    Used by ``_build_aggregate`` to skip dimensions where the
    scorer's 0.0 F1 is a placeholder (zero-denominator) rather
    than a real "extractor scored badly" signal. Looks at both
    the top-level aggregate counts and the by_type breakdown so
    a dimension that only has type-level entries (older scorer
    payloads) still classifies correctly.
    """
    aggregate_tp = int(graph_scores.get("true_positives") or 0)
    aggregate_fp = int(graph_scores.get("false_positives") or 0)
    aggregate_fn = int(graph_scores.get("false_negatives") or 0)
    if aggregate_tp + aggregate_fp + aggregate_fn > 0:
        return True
    by_type = graph_scores.get("by_type") or {}
    for type_scores in by_type.values():
        tp = int(type_scores.get("true_positives") or 0)
        fp = int(type_scores.get("false_positives") or 0)
        fn = int(type_scores.get("false_negatives") or 0)
        if tp + fp + fn > 0:
            return True
    return False


def _sum_counts(graph_scores: Dict[str, Any], key: str) -> int:
    """Aggregate a per-type count across the by_type breakdown.

    The ScoringReport returns counts both at the top level
    (aggregate) and per-type (by_type). Some scorer versions only
    populate the by_type dict, so fall back to summing if the
    top-level int is missing/zero.
    """
    top_level = graph_scores.get(key)
    if isinstance(top_level, int) and top_level > 0:
        return top_level
    by_type = graph_scores.get("by_type") or {}
    return sum(int(v.get(key, 0)) for v in by_type.values())
