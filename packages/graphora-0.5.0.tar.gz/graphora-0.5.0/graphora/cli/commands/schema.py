"""Schema command - infer and manage ontology schemas."""

import asyncio
from pathlib import Path
from typing import List, Optional

import typer
from rich.console import Console
from rich.progress import Progress, SpinnerColumn, TextColumn
from rich import print as rprint
import yaml

from graphora.cli.config import get_mode, is_embedded_available
from graphora.cli.runtime import (
    init_embedded_environment,
    validate_embedded_environment,
    get_missing_config,
)

app = typer.Typer(help="Infer and manage ontology schemas")
console = Console()


@app.command("infer")
def infer(
    files: List[Path] = typer.Argument(
        ...,
        help="Document files to analyze for schema inference",
        exists=True,
    ),
    output: Path = typer.Option(
        Path("ontology.yaml"),
        "--output",
        "-o",
        help="Output file path for the inferred schema",
    ),
    api_key: Optional[str] = typer.Option(
        None,
        "--api-key",
        "-k",
        help="LLM API key (overrides config)",
        envvar="GRAPHORA_API_KEY",
    ),
    verbose: bool = typer.Option(
        False,
        "--verbose",
        "-v",
        help="Show detailed progress",
    ),
):
    """Infer an ontology schema from documents.

    Analyzes the content of provided documents and generates an ontology
    YAML file that can be used for extraction.

    Examples:
        graphora schema infer document.pdf -o ontology.yaml
        graphora schema infer doc1.pdf doc2.pdf -o combined-schema.yaml
    """
    # Check if embedded mode is available (schema inference requires it)
    if not is_embedded_available():
        rprint("[red]Schema inference requires embedded mode.[/red]")
        rprint("Install with: [cyan]pip install graphora[embedded][/cyan]")
        raise typer.Exit(1)

    # Initialize environment
    init_embedded_environment(api_key)

    # Validate configuration
    if not validate_embedded_environment():
        missing = get_missing_config("embedded")
        rprint("[red]Missing required configuration:[/red]")
        for item in missing:
            rprint(f"  - {item}")
        rprint("\nRun [cyan]graphora config init[/cyan] to set up configuration.")
        raise typer.Exit(1)

    # Collect files
    all_files = _collect_files(files)

    if not all_files:
        rprint("[red]No valid document files found.[/red]")
        raise typer.Exit(1)

    rprint(f"[cyan]Analyzing {len(all_files)} document(s) for schema inference...[/cyan]")

    try:
        # Run inference
        schema = asyncio.run(
            _infer_schema_async(
                files=all_files,
                verbose=verbose,
            )
        )

        # Write output
        with open(output, "w") as f:
            yaml.dump(schema, f, default_flow_style=False, sort_keys=False)

        # Summary
        entities = list(schema.get("entities", {}).keys())
        relationships = list(schema.get("relationships", {}).keys())

        rprint(f"\n[green]Schema inference complete![/green]")
        rprint(f"  Entities: {len(entities)}")
        if verbose and entities:
            for entity in entities:
                rprint(f"    - {entity}")
        rprint(f"  Relationships: {len(relationships)}")
        if verbose and relationships:
            for rel in relationships:
                rprint(f"    - {rel}")
        rprint(f"  Output: [cyan]{output}[/cyan]")

    except Exception as e:
        rprint(f"[red]Schema inference failed: {str(e)}[/red]")
        if verbose:
            console.print_exception()
        raise typer.Exit(1)


@app.command("validate")
def validate(
    schema_file: Path = typer.Argument(
        ...,
        help="Ontology YAML file to validate",
        exists=True,
    ),
    verbose: bool = typer.Option(
        False,
        "--verbose",
        "-v",
        help="Show detailed validation output",
    ),
):
    """Validate an ontology schema file.

    Checks the schema for structural correctness and common issues.

    Examples:
        graphora schema validate ontology.yaml
    """
    try:
        with open(schema_file, "r") as f:
            schema = yaml.safe_load(f.read())

        errors = []
        warnings = []

        # Check for required sections
        if "entities" not in schema:
            errors.append("Missing 'entities' section")
        elif not isinstance(schema["entities"], dict):
            errors.append("'entities' must be a dictionary")
        else:
            # Validate entities
            for entity_name, entity_def in schema["entities"].items():
                if not isinstance(entity_def, dict):
                    errors.append(f"Entity '{entity_name}' must be a dictionary")
                    continue

                if "properties" not in entity_def:
                    warnings.append(f"Entity '{entity_name}' has no properties defined")

                if verbose:
                    props = entity_def.get("properties", {})
                    rprint(f"  [dim]Entity '{entity_name}': {len(props)} properties[/dim]")

        # Check relationships
        if "relationships" in schema:
            if not isinstance(schema["relationships"], dict):
                errors.append("'relationships' must be a dictionary")
            else:
                entity_names = set(schema.get("entities", {}).keys())

                for rel_name, rel_def in schema["relationships"].items():
                    if not isinstance(rel_def, dict):
                        errors.append(f"Relationship '{rel_name}' must be a dictionary")
                        continue

                    source = rel_def.get("source")
                    target = rel_def.get("target")

                    if source and source not in entity_names:
                        warnings.append(f"Relationship '{rel_name}' references unknown source entity '{source}'")
                    if target and target not in entity_names:
                        warnings.append(f"Relationship '{rel_name}' references unknown target entity '{target}'")

                    if verbose:
                        rprint(f"  [dim]Relationship '{rel_name}': {source} -> {target}[/dim]")

        # Report results
        if errors:
            rprint(f"\n[red]Validation failed with {len(errors)} error(s):[/red]")
            for error in errors:
                rprint(f"  [red]- {error}[/red]")

        if warnings:
            rprint(f"\n[yellow]Warnings ({len(warnings)}):[/yellow]")
            for warning in warnings:
                rprint(f"  [yellow]- {warning}[/yellow]")

        if not errors:
            if warnings:
                rprint(f"\n[green]Schema is valid with {len(warnings)} warning(s).[/green]")
            else:
                rprint(f"\n[green]Schema is valid![/green]")
        else:
            raise typer.Exit(1)

    except yaml.YAMLError as e:
        rprint(f"[red]Invalid YAML: {e}[/red]")
        raise typer.Exit(1)


def _collect_files(paths: List[Path]) -> List[Path]:
    """Collect all document files from paths."""
    supported_extensions = {".pdf", ".txt", ".md", ".docx", ".doc"}
    files = []

    for path in paths:
        if path.is_file():
            if path.suffix.lower() in supported_extensions:
                files.append(path)
        elif path.is_dir():
            for ext in supported_extensions:
                files.extend(path.glob(f"**/*{ext}"))

    return sorted(set(files))


async def _infer_schema_async(
    files: List[Path],
    verbose: bool,
) -> dict:
    """Run schema inference asynchronously."""
    from graphora_server.services.schema_inference import infer_schema_from_text
    from graphora_server.services.document_parser import parse_document

    chunks = []

    with Progress(
        SpinnerColumn(),
        TextColumn("[progress.description]{task.description}"),
        console=console,
    ) as progress:
        # Parse documents
        task = progress.add_task("Parsing documents...", total=len(files))

        for file_path in files:
            try:
                doc_chunks = await parse_document(file_path)
                chunks.extend(doc_chunks)
                if verbose:
                    rprint(f"  [dim]Parsed {file_path.name}: {len(doc_chunks)} chunks[/dim]")
            except Exception as e:
                rprint(f"  [yellow]Warning: Failed to parse {file_path.name}: {e}[/yellow]")
            progress.advance(task)

        if not chunks:
            raise ValueError("No content extracted from documents")

        # Infer schema
        task = progress.add_task("Inferring schema...", total=1)
        schema = await infer_schema_from_text(
            [c.get("text", c) if isinstance(c, dict) else str(c) for c in chunks]
        )
        progress.advance(task)

    return schema
