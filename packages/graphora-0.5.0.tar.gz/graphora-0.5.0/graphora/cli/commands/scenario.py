"""Scenario command group — create / list / show / delete graph snapshots.

B6-scenario slice 2a (Gate 4) CLI. Backed by graphora-server's
``/api/v1/scenarios`` endpoints (commit d7a1f6e + reviewer fixes
in 088692b + 3b008fc). A scenario is a named, point-in-time
snapshot of a transform's graph — the primitive behind
"what if we re-ran with this ontology change?" and "what if
Alice and Alicia are the same entity?" workflows.

Slice 2a covers the four CRUD verbs that match the server's
existing surface: create, list, show, delete. Scenario
mutations (add/remove nodes, branching from a scenario) land
in slice 2b alongside the CoW storage migration on the server.
"""

from __future__ import annotations

import json
from typing import Any, Dict, Optional

import typer
from rich import box
from rich.console import Console
from rich.json import JSON
from rich.markup import escape as rich_escape
from rich.panel import Panel
from rich.table import Table

from graphora.cli.config import get_api_url, get_auth_token
from graphora.cli.runtime import get_missing_config, validate_remote_environment
from graphora.client import GraphoraClient
from graphora.exceptions import GraphoraAPIError, GraphoraClientError

console = Console()


# ============================================================
# Typer app — scenario is a sub-command group, mounted in main.py
# ============================================================


app = typer.Typer(
    name="scenario",
    help=(
        "Create and inspect graph snapshots (scenarios). A "
        "scenario is a named point-in-time snapshot of a "
        "transform's extraction — useful for branching what-if "
        "comparisons before publishing."
    ),
    no_args_is_help=True,
)


def _resolve_client(
    base_url: Optional[str], auth_token: Optional[str]
) -> GraphoraClient:
    """Shared credential resolution + client construction for all
    scenario subcommands. Mirrors the chain used by explain /
    diff / test: explicit option > env var > persisted config.
    A friendly diagnostic surfaces when credentials are missing
    so users see the 'run config init' hint, not a raw ValueError.
    """
    resolved_base_url = base_url or get_api_url()
    resolved_auth_token = auth_token or get_auth_token()

    if not validate_remote_environment() and not (
        resolved_base_url and resolved_auth_token
    ):
        missing = get_missing_config("remote")
        console.print("[red]Missing required configuration:[/red]")
        for item in missing:
            console.print(f"  - {item}")
        console.print(
            "\nRun [cyan]graphora config init --mode remote[/cyan] "
            "to set up configuration, or pass --api-url + "
            "--auth-token."
        )
        raise typer.Exit(code=2)

    try:
        return GraphoraClient(
            base_url=resolved_base_url, auth_token=resolved_auth_token
        )
    except ValueError as exc:
        console.print(f"[red]Error:[/red] {exc}")
        raise typer.Exit(code=2)


def _handle_api_error(exc: GraphoraAPIError, *, action: str) -> None:
    """Map well-known status codes to specific operator messages.

    The defaults (raw exception → exit 1) work, but for the
    common 404/409/413 cases a tailored message helps users
    distinguish "the scenario doesn't exist for you" from
    "the API is broken." Each branch ends with typer.Exit so
    callers can ``raise _handle_api_error(...)``-style flow.
    """
    if exc.status_code == 404:
        console.print(
            f"[red]Not found:[/red] {exc}. Run "
            f"[cyan]graphora scenario list[/cyan] to see what's "
            f"available for your account."
        )
        raise typer.Exit(code=1)
    if exc.status_code == 409:
        console.print(
            f"[red]Conflict:[/red] {exc}. Choose a different "
            f"--name or delete the existing scenario first."
        )
        raise typer.Exit(code=1)
    if exc.status_code == 413:
        console.print(
            f"[red]{action.capitalize()} refused:[/red] the source "
            f"transform exceeds the 10k-node diff cap. Streaming "
            f"scenario snapshots aren't supported yet."
        )
        raise typer.Exit(code=1)
    console.print(f"[red]API error:[/red] {exc}")
    raise typer.Exit(code=1)


# ============================================================
# create
# ============================================================


@app.command("create")
def create(
    transform_id: str = typer.Option(
        ...,
        "--transform-id",
        "-t",
        help="Transform ID whose graph will be snapshotted into the scenario.",
    ),
    name: str = typer.Option(
        ...,
        "--name",
        "-n",
        help=(
            "Scenario name. Must be unique per (you, transform_id) — "
            "a duplicate returns 409."
        ),
    ),
    description: Optional[str] = typer.Option(
        None,
        "--description",
        "-d",
        help="Optional free-form note about what this scenario captures.",
    ),
    json_output: bool = typer.Option(
        False,
        "--json",
        help=(
            "Emit the full scenario record as JSON (incl. the "
            "embedded graph snapshot) instead of the Rich summary."
        ),
    ),
    base_url: Optional[str] = typer.Option(
        None,
        "--api-url",
        help=(
            "Graphora API base URL. Falls back to GRAPHORA_API_URL "
            "and then ~/.graphora/config.yaml (api.url)."
        ),
    ),
    auth_token: Optional[str] = typer.Option(
        None,
        "--auth-token",
        help=(
            "Clerk bearer token. Falls back to GRAPHORA_AUTH_TOKEN "
            "and then ~/.graphora/config.yaml (api.auth_token)."
        ),
    ),
):
    """Snapshot a transform's graph into a new scenario.

    Examples:

        graphora scenario create -t tx-abc -n baseline
        graphora scenario create -t tx-abc -n "merge-alice-alicia" -d "what-if ER"
        graphora scenario create -t tx-abc -n baseline --json > scenario.json
    """
    client = _resolve_client(base_url, auth_token)

    try:
        payload = client.create_scenario(
            transform_id=transform_id,
            name=name,
            description=description,
        )
    except GraphoraAPIError as exc:
        _handle_api_error(exc, action="snapshot")
    except GraphoraClientError as exc:
        console.print(f"[red]Client error:[/red] {exc}")
        raise typer.Exit(code=2)

    if json_output:
        if console.is_terminal:
            console.print(JSON(json.dumps(payload, default=str)))
        else:
            print(json.dumps(payload, indent=2, default=str))
        return

    _render_scenario_panel(payload, action="Created scenario")


# ============================================================
# list
# ============================================================


@app.command("list")
def list_scenarios(
    json_output: bool = typer.Option(
        False,
        "--json",
        help="Emit the scenario list as JSON instead of the Rich table.",
    ),
    base_url: Optional[str] = typer.Option(
        None, "--api-url", help="Graphora API base URL."
    ),
    auth_token: Optional[str] = typer.Option(
        None, "--auth-token", help="Clerk bearer token."
    ),
):
    """List scenarios owned by you, newest first.

    Lightweight summary view — counts only, no embedded graph.
    Use ``graphora scenario show <id>`` to fetch the full
    scenario including the materialized snapshot.
    """
    client = _resolve_client(base_url, auth_token)

    try:
        scenarios = client.list_scenarios()
    except GraphoraAPIError as exc:
        _handle_api_error(exc, action="list")
    except GraphoraClientError as exc:
        console.print(f"[red]Client error:[/red] {exc}")
        raise typer.Exit(code=2)

    if json_output:
        if console.is_terminal:
            console.print(JSON(json.dumps(scenarios, default=str)))
        else:
            print(json.dumps(scenarios, indent=2, default=str))
        return

    if not scenarios:
        console.print(
            "[dim]No scenarios yet. Create one with "
            "[cyan]graphora scenario create[/cyan].[/dim]"
        )
        return

    table = Table(
        title=f"Your scenarios ({len(scenarios)})",
        box=box.ROUNDED,
    )
    table.add_column("ID", style="dim")
    table.add_column("Name", style="cyan")
    table.add_column("Transform", style="dim")
    table.add_column("Nodes", justify="right")
    table.add_column("Edges", justify="right")
    table.add_column("Created", style="dim")

    for scenario in scenarios:
        sid = scenario.get("id", "?")
        # Truncate the UUID for tight rendering; full id in --json.
        if len(sid) > 12:
            sid = sid[:8] + "…"
        table.add_row(
            rich_escape(sid),
            rich_escape(scenario.get("name", "?")),
            rich_escape(_short(scenario.get("transform_id", "?"))),
            str(scenario.get("node_count", 0)),
            str(scenario.get("edge_count", 0)),
            rich_escape(_short_timestamp(scenario.get("created_at", ""))),
        )
    console.print(table)


# ============================================================
# show
# ============================================================


@app.command("show")
def show(
    scenario_id: str = typer.Argument(
        ...,
        help="Scenario ID to fetch.",
    ),
    json_output: bool = typer.Option(
        False,
        "--json",
        help="Emit the full scenario record as JSON.",
    ),
    base_url: Optional[str] = typer.Option(
        None, "--api-url", help="Graphora API base URL."
    ),
    auth_token: Optional[str] = typer.Option(
        None, "--auth-token", help="Clerk bearer token."
    ),
):
    """Show one scenario including the materialized graph snapshot.

    Examples:

        graphora scenario show sc-abc123
        graphora scenario show sc-abc123 --json | jq '.graph.nodes | length'
    """
    client = _resolve_client(base_url, auth_token)

    try:
        payload = client.get_scenario(scenario_id)
    except GraphoraAPIError as exc:
        _handle_api_error(exc, action="show")
    except GraphoraClientError as exc:
        console.print(f"[red]Client error:[/red] {exc}")
        raise typer.Exit(code=2)

    if json_output:
        if console.is_terminal:
            console.print(JSON(json.dumps(payload, default=str)))
        else:
            print(json.dumps(payload, indent=2, default=str))
        return

    _render_scenario_panel(payload, action="Scenario")


# ============================================================
# delete
# ============================================================


@app.command("delete")
def delete(
    scenario_id: str = typer.Argument(
        ...,
        help="Scenario ID to delete.",
    ),
    yes: bool = typer.Option(
        False,
        "--yes",
        "-y",
        help=(
            "Skip the interactive confirmation prompt. Required "
            "for non-interactive contexts (CI, scripts)."
        ),
    ),
    base_url: Optional[str] = typer.Option(
        None, "--api-url", help="Graphora API base URL."
    ),
    auth_token: Optional[str] = typer.Option(
        None, "--auth-token", help="Clerk bearer token."
    ),
):
    """Delete one scenario by id. Asks for confirmation by default.

    The server's delete is intentionally non-idempotent — a 404
    fires when the scenario doesn't exist OR belongs to another
    user. Same posture as ``graphora explain`` / ``graphora diff``
    on cross-tenant access.

    Examples:

        graphora scenario delete sc-abc123
        graphora scenario delete sc-abc123 --yes    # no prompt
    """
    if not yes:
        confirmed = typer.confirm(
            f"Delete scenario {scenario_id}? This can't be undone."
        )
        if not confirmed:
            console.print("[dim]Aborted.[/dim]")
            raise typer.Exit(code=0)

    client = _resolve_client(base_url, auth_token)

    try:
        client.delete_scenario(scenario_id)
    except GraphoraAPIError as exc:
        _handle_api_error(exc, action="delete")
    except GraphoraClientError as exc:
        console.print(f"[red]Client error:[/red] {exc}")
        raise typer.Exit(code=2)

    console.print(f"[green]Deleted scenario {scenario_id}.[/green]")


# ============================================================
# Rendering helpers
# ============================================================


def _render_scenario_panel(payload: Dict[str, Any], *, action: str) -> None:
    """Render a single-scenario detail view as a Rich panel +
    optional embedded graph stats. Used by both ``create`` and
    ``show`` so the operator gets the same shape regardless of
    which verb landed them on the scenario.
    """
    name = payload.get("name", "?")
    sid = payload.get("id", "?")
    transform_id = payload.get("transform_id", "?")
    description = payload.get("description") or "(no description)"
    created_at = payload.get("created_at", "?")
    node_count = payload.get("node_count", 0)
    edge_count = payload.get("edge_count", 0)

    body = (
        f"[bold]name:[/bold] {rich_escape(name)}\n"
        f"[bold]id:[/bold] [dim]{rich_escape(sid)}[/dim]\n"
        f"[bold]transform_id:[/bold] [dim]{rich_escape(transform_id)}[/dim]\n"
        f"[bold]created_at:[/bold] [dim]{rich_escape(created_at)}[/dim]\n"
        f"[bold]description:[/bold] {rich_escape(description)}\n"
        f"[bold]graph:[/bold] {node_count} nodes, {edge_count} edges"
    )
    console.print(
        Panel(body, title=action, box=box.ROUNDED)
    )


def _short(value: str, length: int = 12) -> str:
    """Truncate long ids for table cells. Full value is always in --json."""
    if len(value) <= length:
        return value
    return value[: length - 1] + "…"


def _short_timestamp(value: str) -> str:
    """Strip subseconds from an ISO timestamp for tight rendering."""
    if not value:
        return "?"
    # Drop everything after the seconds-precision tail, keep
    # timezone suffix. Defensive — if the format isn't what we
    # expect, fall back to the raw value.
    if "T" in value and "." in value:
        head, _, _tail = value.partition(".")
        # Re-attach timezone marker if present.
        for suffix in ("+", "-", "Z"):
            if suffix in value:
                tz_part = value.rsplit(suffix, 1)[-1]
                if suffix == "Z":
                    return f"{head}Z"
                return f"{head}{suffix}{tz_part}"
        return head
    return value
