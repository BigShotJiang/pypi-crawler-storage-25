"""Smoke + contract tests for ``graphora scenario`` (B6-scenario slice 2a).

The CLI mirrors the server's /api/v1/scenarios surface
(graphora-server commit d7a1f6e + reviewer fixes). Tests cover:

  * GraphoraClient methods — URL/payload shape for the four CRUD
    verbs, 409/404/413 surfaces.
  * Typer CLI surface — argument parsing, credential resolution,
    delete confirmation flow, exit codes by failure mode.
  * Renderer pins — escape Rich markup in server data (same
    defense as diff.py); panel + table shapes survive refactor.
"""

from __future__ import annotations

import json
from typing import Any, Dict
from unittest.mock import MagicMock, patch

import pytest
from typer.testing import CliRunner

from graphora.cli.main import app
from graphora.client import GraphoraClient


def _fake_response(payload: Dict[str, Any], status: int = 200):
    resp = MagicMock()
    resp.status_code = status
    resp.json.return_value = payload
    resp.raise_for_status.return_value = None
    return resp


def _fake_error_response(status: int, detail: Any = "error"):
    """Build a fake response that raises HTTPError on
    raise_for_status — used to drive the 4xx/5xx paths through
    _handle_response."""
    import requests as requests_module

    resp = MagicMock()
    resp.status_code = status
    resp.json.return_value = {"detail": detail}
    err = requests_module.exceptions.HTTPError(response=resp)
    resp.raise_for_status.side_effect = err
    return resp


def _scenario_record(
    *,
    scenario_id: str = "sc-1",
    name: str = "baseline",
    transform_id: str = "tx-1",
    description: str = None,
    node_count: int = 2,
    edge_count: int = 1,
) -> Dict[str, Any]:
    """Wire-shape scenario record matching what the server returns
    on POST / GET /scenarios/{id}."""
    return {
        "id": scenario_id,
        "transform_id": transform_id,
        "parent_scenario_id": None,
        "name": name,
        "description": description,
        "created_at": "2026-05-17T19:00:00+00:00",
        "node_count": node_count,
        "edge_count": edge_count,
        "graph": {
            "nodes": [
                {
                    "id": "n1",
                    "label": "N1",
                    "type": "Person",
                    "properties": {},
                }
            ],
            "edges": [],
            "total_nodes": 1,
            "total_edges": 0,
        },
    }


@pytest.fixture
def runner():
    return CliRunner()


@pytest.fixture
def auth_env(monkeypatch):
    monkeypatch.setenv("GRAPHORA_AUTH_TOKEN", "test-token")
    monkeypatch.setenv("GRAPHORA_API_URL", "https://test.example/api")


# ============================================================
# CLI surface — help discoverability
# ============================================================


def test_scenario_group_help_lists_four_verbs(runner):
    """Pin the visible verb set: create / list / show / delete.
    A refactor that drops one (or accidentally hides one behind
    a different name) regresses here."""
    result = runner.invoke(app, ["scenario", "--help"])
    assert result.exit_code == 0
    out = result.stdout
    assert "create" in out
    assert "list" in out
    assert "show" in out
    assert "delete" in out


def test_scenario_create_help_describes_required_options(runner):
    """create needs both --transform-id and --name. Pin so a
    refactor that loosens either to optional doesn't slip past."""
    result = runner.invoke(app, ["scenario", "create", "--help"])
    assert result.exit_code == 0
    out = result.stdout
    assert "--transform-id" in out
    assert "--name" in out


# ============================================================
# GraphoraClient method shapes
# ============================================================


def test_client_create_scenario_posts_to_correct_endpoint(auth_env):
    """URL + payload shape for POST /scenarios. Pin so a path
    drift breaks here, not silently against new servers."""
    with patch("graphora.client.requests.post") as mock_post:
        mock_post.return_value = _fake_response(_scenario_record())
        client = GraphoraClient()
        result = client.create_scenario(
            transform_id="tx-1",
            name="baseline",
            description="initial",
        )

    url = mock_post.call_args.args[0]
    assert url.endswith("/api/v1/scenarios"), f"URL drifted: {url}"
    posted = mock_post.call_args.kwargs["json"]
    assert posted == {
        "transform_id": "tx-1",
        "name": "baseline",
        "description": "initial",
    }
    assert result["id"] == "sc-1"


def test_client_create_scenario_omits_description_when_none(auth_env):
    """description is optional server-side. The client must
    NOT send the key when caller omits it — otherwise the wire
    contract drifts and server-side aggregations get polluted
    with empty-string descriptions."""
    with patch("graphora.client.requests.post") as mock_post:
        mock_post.return_value = _fake_response(_scenario_record())
        client = GraphoraClient()
        client.create_scenario(transform_id="tx-1", name="x")

    posted = mock_post.call_args.kwargs["json"]
    assert "description" not in posted


def test_client_list_scenarios_uses_get(auth_env):
    """GET /scenarios — pin the verb so a refactor that switches
    to POST or sends a body regresses."""
    summaries = [_scenario_record(scenario_id="sc-1")]
    # The list endpoint returns summary shape (no graph), but the
    # wire matches a strict subset of the detail shape so the
    # full record works for the test mock.
    with patch("graphora.client.requests.get") as mock_get:
        mock_get.return_value = _fake_response(summaries)
        client = GraphoraClient()
        result = client.list_scenarios()

    url = mock_get.call_args.args[0]
    assert url.endswith("/api/v1/scenarios")
    assert isinstance(result, list)
    assert result[0]["id"] == "sc-1"


def test_client_get_scenario_path_includes_id(auth_env):
    """Pin the path shape /scenarios/{id} — accidental URL
    drift (e.g., to a query param ?id=...) would silently 404."""
    with patch("graphora.client.requests.get") as mock_get:
        mock_get.return_value = _fake_response(_scenario_record())
        client = GraphoraClient()
        client.get_scenario("sc-42")

    url = mock_get.call_args.args[0]
    assert url.endswith("/api/v1/scenarios/sc-42")


def test_client_delete_scenario_uses_delete_verb(auth_env):
    """DELETE verb pin. The server's delete is non-idempotent
    by design (returns 404 on cross-tenant or missing) — the
    client must use DELETE to hit the right route."""
    with patch("graphora.client.requests.delete") as mock_delete:
        resp = MagicMock()
        resp.status_code = 204
        resp.raise_for_status.return_value = None
        mock_delete.return_value = resp
        client = GraphoraClient()
        client.delete_scenario("sc-42")

    url = mock_delete.call_args.args[0]
    assert url.endswith("/api/v1/scenarios/sc-42")


def test_client_delete_scenario_handles_204_empty_body(auth_env):
    """The server returns 204 No Content on success — the response
    has no JSON body. The client's delete path must NOT try to
    .json() the empty response. Pin so a refactor that routes
    through _handle_response (which calls .json()) regresses."""
    with patch("graphora.client.requests.delete") as mock_delete:
        resp = MagicMock()
        resp.status_code = 204
        resp.raise_for_status.return_value = None
        # If anything tried to call .json(), we'd want it to fail
        # — but the default MagicMock returns a fresh MagicMock,
        # so just confirming no exception bubbled up is the
        # observable contract.
        mock_delete.return_value = resp
        client = GraphoraClient()
        # The call must succeed without raising.
        result = client.delete_scenario("sc-42")
        assert result is None


def test_client_create_scenario_surfaces_409_as_api_error(auth_env):
    """Duplicate name → 409 from the server. The client must
    raise GraphoraAPIError preserving the status code so CLI
    can branch on it."""
    from graphora.exceptions import GraphoraAPIError

    with patch(
        "graphora.client.requests.post",
        return_value=_fake_error_response(409, "duplicate"),
    ):
        client = GraphoraClient()
        with pytest.raises(GraphoraAPIError) as exc_info:
            client.create_scenario(transform_id="tx", name="dup")
    assert exc_info.value.status_code == 409


def test_client_delete_scenario_surfaces_404_as_api_error(auth_env):
    """Cross-tenant / missing id → 404. The CLI uses this to
    show 'not found, run scenario list'. Pin so a refactor
    that downgrades to a generic ClientError breaks here."""
    from graphora.exceptions import GraphoraAPIError

    with patch(
        "graphora.client.requests.delete",
        return_value=_fake_error_response(404, "not found"),
    ):
        client = GraphoraClient()
        with pytest.raises(GraphoraAPIError) as exc_info:
            client.delete_scenario("sc-missing")
    assert exc_info.value.status_code == 404


# ============================================================
# CLI exit codes by failure mode
# ============================================================


def test_create_409_exits_1_with_friendly_message(runner, auth_env):
    """409 (duplicate name) → exit 1 with a 'choose a different
    name' hint, not the raw API error. Pin the operator-facing
    surface for the common 'I already created this' case."""
    with patch(
        "graphora.client.requests.post",
        return_value=_fake_error_response(409, "dup"),
    ):
        result = runner.invoke(
            app,
            ["scenario", "create", "-t", "tx-1", "-n", "dup"],
        )
    assert result.exit_code == 1
    assert "Conflict" in result.stdout
    assert "different --name" in result.stdout


def test_create_413_exits_1_with_truncation_message(runner, auth_env):
    """413 (transform too large for diff cap) → exit 1 with a
    specific 'streaming snapshots not supported' message rather
    than the raw error. Pin so operators recognize the known-
    limitation case."""
    with patch(
        "graphora.client.requests.post",
        return_value=_fake_error_response(
            413,
            {"error": "transform_too_large_to_diff", "side": "scenario_source"},
        ),
    ):
        result = runner.invoke(
            app,
            ["scenario", "create", "-t", "tx-huge", "-n", "x"],
        )
    assert result.exit_code == 1
    assert "10k" in result.stdout


def test_show_404_exits_1_with_hint_to_list(runner, auth_env):
    """404 on show → exit 1 with a 'graphora scenario list' hint
    so operators see how to discover what they own."""
    with patch(
        "graphora.client.requests.get",
        return_value=_fake_error_response(404, "not found"),
    ):
        result = runner.invoke(app, ["scenario", "show", "sc-missing"])
    assert result.exit_code == 1
    assert "Not found" in result.stdout
    assert "graphora scenario list" in result.stdout


# ============================================================
# create — rendering
# ============================================================


def test_create_renders_scenario_panel_with_counts(runner, auth_env):
    """Default (non-JSON) create render shows name, ids, counts
    in a panel. Pin so a refactor that drops a field regresses."""
    with patch(
        "graphora.client.requests.post",
        return_value=_fake_response(
            _scenario_record(
                name="my-snapshot",
                node_count=42,
                edge_count=7,
            )
        ),
    ):
        result = runner.invoke(
            app,
            ["scenario", "create", "-t", "tx-1", "-n", "my-snapshot"],
        )

    assert result.exit_code == 0
    assert "my-snapshot" in result.stdout
    assert "42 nodes" in result.stdout
    assert "7 edges" in result.stdout


def test_create_json_mode_emits_full_record(runner, auth_env):
    """--json emits the full payload (incl. embedded graph) so
    callers can pipe to jq. Pin that the embedded graph survives
    serialization unmodified."""
    with patch(
        "graphora.client.requests.post",
        return_value=_fake_response(_scenario_record()),
    ):
        result = runner.invoke(
            app,
            ["scenario", "create", "-t", "tx-1", "-n", "x", "--json"],
        )

    assert result.exit_code == 0
    payload = json.loads(result.stdout)
    assert payload["id"] == "sc-1"
    assert "graph" in payload
    assert payload["graph"]["nodes"][0]["id"] == "n1"


# ============================================================
# list — rendering
# ============================================================


def test_list_empty_renders_hint_to_create(runner, auth_env):
    """Empty list → friendly 'create one with graphora scenario
    create' hint, not an empty table. Pin the discoverable
    onboarding nudge so a refactor that just prints '0 rows'
    regresses noisily."""
    with patch(
        "graphora.client.requests.get",
        return_value=_fake_response([]),
    ):
        result = runner.invoke(app, ["scenario", "list"])

    assert result.exit_code == 0
    assert "No scenarios" in result.stdout
    assert "graphora scenario create" in result.stdout


def test_list_renders_table_with_name_and_counts(runner, auth_env):
    """Multi-row list renders the columns we promised: name +
    counts visible. Pin so a refactor that drops a column
    regresses."""
    with patch(
        "graphora.client.requests.get",
        return_value=_fake_response(
            [
                _scenario_record(
                    scenario_id="sc-1",
                    name="alpha",
                    node_count=10,
                    edge_count=4,
                ),
                _scenario_record(
                    scenario_id="sc-2",
                    name="beta",
                    node_count=2,
                    edge_count=0,
                ),
            ]
        ),
    ):
        result = runner.invoke(app, ["scenario", "list"])

    assert result.exit_code == 0
    assert "alpha" in result.stdout
    assert "beta" in result.stdout
    assert "10" in result.stdout
    assert "Your scenarios (2)" in result.stdout


# ============================================================
# delete — confirmation flow
# ============================================================


def test_delete_with_yes_skips_confirmation(runner, auth_env):
    """--yes bypasses the interactive prompt so CI / scripts
    can call delete non-interactively. Pin so a refactor that
    forces interactive confirmation regardless of --yes
    breaks here."""
    with patch("graphora.client.requests.delete") as mock_delete:
        resp = MagicMock()
        resp.status_code = 204
        resp.raise_for_status.return_value = None
        mock_delete.return_value = resp

        result = runner.invoke(
            app, ["scenario", "delete", "sc-1", "--yes"]
        )

    assert result.exit_code == 0
    assert "Deleted" in result.stdout
    mock_delete.assert_called_once()


def test_delete_aborted_at_prompt_does_not_call_api(runner, auth_env):
    """Answering 'n' to the confirmation aborts without making
    an API call. Pin so a refactor that fires the DELETE
    regardless regresses noisily."""
    with patch("graphora.client.requests.delete") as mock_delete:
        result = runner.invoke(
            app, ["scenario", "delete", "sc-1"], input="n\n"
        )

    assert result.exit_code == 0
    assert "Aborted" in result.stdout
    mock_delete.assert_not_called()


# ============================================================
# Rich markup escape (same defense as diff.py)
# ============================================================


def test_show_escapes_rich_markup_in_scenario_name(runner, auth_env):
    """A scenario name with Rich-flavored brackets must render
    literally, not as active markup. Same defense diff.py
    needed — pin so a refactor that drops the rich_escape calls
    silently breaks the render for hostile inputs."""
    record = _scenario_record(name="[admin] my-scenario")
    with patch(
        "graphora.client.requests.get",
        return_value=_fake_response(record),
    ):
        result = runner.invoke(app, ["scenario", "show", "sc-1"])

    assert result.exit_code == 0
    # The bracketed prefix must appear literally — if Rich
    # interpreted it as markup, the brackets would vanish.
    assert "[admin]" in result.stdout


def test_list_escapes_rich_markup_in_name_column(runner, auth_env):
    """Same defense at the table-cell layer. Pin the list
    surface in addition to the panel surface."""
    record = _scenario_record(name="[red]danger[/red]", scenario_id="sc-1")
    with patch(
        "graphora.client.requests.get",
        return_value=_fake_response([record]),
    ):
        result = runner.invoke(app, ["scenario", "list"])

    assert result.exit_code == 0
    assert "[red]" in result.stdout


# ============================================================
# Credential resolution (mirrors explain/diff)
# ============================================================


def test_create_friendly_error_when_no_credentials(runner, monkeypatch):
    """Same 'run config init' UX as the other remote commands.
    Pin so a regression that bubbles the raw ValueError from
    GraphoraClient regresses here too."""
    monkeypatch.delenv("GRAPHORA_API_URL", raising=False)
    monkeypatch.delenv("GRAPHORA_AUTH_TOKEN", raising=False)

    with patch(
        "graphora.cli.commands.scenario.get_api_url",
        return_value=None,
    ), patch(
        "graphora.cli.commands.scenario.get_auth_token",
        return_value=None,
    ), patch(
        "graphora.cli.commands.scenario.validate_remote_environment",
        return_value=False,
    ), patch(
        "graphora.cli.commands.scenario.get_missing_config",
        return_value=["api.url", "api.auth_token"],
    ):
        result = runner.invoke(
            app, ["scenario", "create", "-t", "tx-1", "-n", "x"]
        )

    assert result.exit_code == 2
    assert "Missing required configuration" in result.stdout
    assert "graphora config init" in result.stdout
