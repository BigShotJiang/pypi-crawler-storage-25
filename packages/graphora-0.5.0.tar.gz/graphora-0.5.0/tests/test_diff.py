"""Smoke + contract tests for ``graphora diff``.

The B3-diff (Gate 4) CLI is the terminal-side companion of the
Diff/Review tab in graphora-fe and the MCP ``review_diff`` tool.
These tests exercise three layers:

  * Typer CLI surface — argument parsing, credential resolution,
    JSON output mode, --show-unchanged flag, --limit truncation.
  * GraphoraClient.diff_transforms — URL shape, 413 surface
    (mirrors /golden/score's truncation guard).
  * Renderer pin — summary + detail tables surface the expected
    labels/values so a refactor that drops a section regresses
    noisily.

All HTTP is mocked at the requests level. Tests follow
test_explain.py / test_test_cmd.py conventions.
"""

from __future__ import annotations

import json
from typing import Any, Dict, List, Optional
from unittest.mock import MagicMock, patch

import pytest
from typer.testing import CliRunner

from graphora.cli.main import app
from graphora.client import GraphoraClient


def _fake_response(payload: Dict[str, Any], status: int = 200):
    resp = MagicMock()
    resp.status_code = status
    resp.json.return_value = payload
    resp.raise_for_status.return_value = None
    return resp


def _diff_payload(
    *,
    added_nodes: Optional[List[Dict[str, Any]]] = None,
    removed_nodes: Optional[List[Dict[str, Any]]] = None,
    changed_nodes: Optional[List[Dict[str, Any]]] = None,
    added_edges: Optional[List[Dict[str, Any]]] = None,
    removed_edges: Optional[List[Dict[str, Any]]] = None,
    changed_edges: Optional[List[Dict[str, Any]]] = None,
    base: str = "tx-old",
    compare: str = "tx-new",
) -> Dict[str, Any]:
    """Build a diff-endpoint shape matching what /api/v1/graph/
    {base}/diff/{compare} returns. Mirrors _diff_to_dict in
    graphora_server/api/graph.py:532."""
    added_nodes = added_nodes or []
    removed_nodes = removed_nodes or []
    changed_nodes = changed_nodes or []
    added_edges = added_edges or []
    removed_edges = removed_edges or []
    changed_edges = changed_edges or []
    return {
        "base_transform_id": base,
        "compare_transform_id": compare,
        "summary": {
            "nodes": {
                "added": len(added_nodes),
                "removed": len(removed_nodes),
                "changed": len(changed_nodes),
                "unchanged": 5,
            },
            "edges": {
                "added": len(added_edges),
                "removed": len(removed_edges),
                "changed": len(changed_edges),
                "unchanged": 3,
            },
        },
        "added_nodes": added_nodes,
        "removed_nodes": removed_nodes,
        "changed_nodes": changed_nodes,
        "added_edges": added_edges,
        "removed_edges": removed_edges,
        "changed_edges": changed_edges,
    }


@pytest.fixture
def runner():
    return CliRunner()


@pytest.fixture
def auth_env(monkeypatch):
    monkeypatch.setenv("GRAPHORA_AUTH_TOKEN", "test-token")
    monkeypatch.setenv("GRAPHORA_API_URL", "https://test.example/api")


# ============================================================
# CLI surface + help
# ============================================================


def test_diff_help_describes_args_and_flags(runner):
    """Pin the user-facing surface: --help mentions both
    transform-id arguments plus --json and --show-unchanged so
    users discover the modes without reading source."""
    result = runner.invoke(app, ["diff", "--help"])
    assert result.exit_code == 0
    out = result.stdout
    assert "BASE_TRANSFORM_ID" in out
    assert "COMPARE_TRANSFORM_ID" in out
    assert "--json" in out
    assert "--show-unchanged" in out


def test_diff_requires_both_transform_ids(runner, auth_env):
    """typer enforces required positional args. Missing the
    second one is a 2-exit usage error, not a silent run."""
    result = runner.invoke(app, ["diff", "tx-only"])
    assert result.exit_code != 0


# ============================================================
# GraphoraClient.diff_transforms — URL + 413 surface
# ============================================================


def test_client_diff_transforms_posts_to_correct_endpoint(auth_env):
    """Pin the URL shape the server expects. A path drift here
    (e.g., the path moving under /diff/{base}/{compare} or
    similar) would silently break every CLI against new servers."""
    with patch("graphora.client.requests.get") as mock_get:
        mock_get.return_value = _fake_response(_diff_payload())
        client = GraphoraClient()
        result = client.diff_transforms("tx-base-1", "tx-compare-2")

    url = mock_get.call_args.args[0]
    assert url.endswith("/api/v1/graph/tx-base-1/diff/tx-compare-2"), (
        f"Diff endpoint URL drifted: {url}"
    )
    # Returns the raw dict — no Pydantic wrapping.
    assert result["base_transform_id"] == "tx-old"
    assert "summary" in result


def test_client_diff_transforms_surfaces_413_as_api_error(auth_env):
    """413 means one side exceeded the 10k-node diff cap (mirrors
    /golden/score's behavior — graphora-server commit a261321 /
    fae7e91 / 0850cbf). The client must surface this as a
    GraphoraAPIError with the status code intact so callers can
    distinguish 'too big to diff' from other failure modes."""
    import requests as requests_module

    from graphora.exceptions import GraphoraAPIError

    err_response = MagicMock()
    err_response.status_code = 413
    err_response.json.return_value = {
        "detail": {
            "error": "transform_too_large_to_diff",
            "side": "compare",
            "transform_id": "tx-huge",
            "truncated_dimension": "nodes",
        }
    }
    err = requests_module.exceptions.HTTPError(response=err_response)
    err_response.raise_for_status.side_effect = err

    with patch("graphora.client.requests.get", return_value=err_response):
        client = GraphoraClient()
        with pytest.raises(GraphoraAPIError) as exc_info:
            client.diff_transforms("tx-base", "tx-huge")

    assert exc_info.value.status_code == 413


# ============================================================
# CLI exit codes
# ============================================================


def test_diff_cli_413_exits_1_with_friendly_message(runner, auth_env):
    """The CLI must surface 413 as a specific 'too big to diff'
    message + exit 1, not the raw API error stack. Pin so
    operators get a useful diagnostic for the well-known
    'streaming diff isn't supported yet' case."""
    import requests as requests_module

    err_response = MagicMock()
    err_response.status_code = 413
    err_response.json.return_value = {"detail": {"error": "transform_too_large_to_diff"}}
    err = requests_module.exceptions.HTTPError(response=err_response)
    err_response.raise_for_status.side_effect = err

    with patch("graphora.client.requests.get", return_value=err_response):
        result = runner.invoke(app, ["diff", "tx-base", "tx-huge"])

    assert result.exit_code == 1
    assert "too big" in result.stdout.lower() or "10k" in result.stdout


# ============================================================
# JSON output
# ============================================================


def test_diff_json_mode_emits_machine_parseable_payload(runner, auth_env):
    """--json prints the raw payload (same shape the /diff
    endpoint returns) so callers can pipe to jq or scripts. Pin
    that the structure flows through unmodified — a refactor
    that collapsed the per-section lists into a single 'changes'
    array would break CI scripts that read summary.nodes.added."""
    payload = _diff_payload(
        added_nodes=[
            {"id": "n1", "label": "Alice", "type": "Person", "properties": {}},
        ],
    )

    with patch("graphora.client.requests.get") as mock_get:
        mock_get.return_value = _fake_response(payload)
        result = runner.invoke(
            app, ["diff", "tx-old", "tx-new", "--json"]
        )

    assert result.exit_code == 0
    parsed = json.loads(result.stdout)
    assert parsed["summary"]["nodes"]["added"] == 1
    assert parsed["added_nodes"][0]["id"] == "n1"


# ============================================================
# Rendering pins
# ============================================================


def test_diff_render_shows_transform_ids_in_header(runner, auth_env):
    """The header panel must name both transform_ids so the
    operator can confirm they're comparing the right pair when
    diff output scrolls. Pin so a refactor that drops the panel
    or renames the labels regresses noisily."""
    with patch("graphora.client.requests.get") as mock_get:
        mock_get.return_value = _fake_response(_diff_payload())
        result = runner.invoke(app, ["diff", "tx-old", "tx-new"])

    assert result.exit_code == 0
    # base + compare both appear in the rendered output.
    assert "tx-old" in result.stdout
    assert "tx-new" in result.stdout


def test_diff_render_shows_summary_counts(runner, auth_env):
    """Summary table is the headline view — counts per dimension
    drive the operator's decision to drill into the detail
    tables. Pin that the counts surface for both nodes and
    edges so a renderer regression that drops a row would
    fail loudly."""
    payload = _diff_payload(
        added_nodes=[
            {"id": "n1", "label": "Alice", "type": "Person", "properties": {}},
            {"id": "n2", "label": "Bob", "type": "Person", "properties": {}},
        ],
        removed_edges=[
            {
                "id": "e1",
                "source": "n3",
                "target": "n4",
                "type": "KNOWS",
                "properties": {},
            },
        ],
    )
    with patch("graphora.client.requests.get") as mock_get:
        mock_get.return_value = _fake_response(payload)
        result = runner.invoke(app, ["diff", "tx-old", "tx-new"])

    assert result.exit_code == 0
    # Summary table header.
    assert "Summary" in result.stdout
    # The two count values must appear somewhere in the rendered
    # output. We don't pin the exact layout (Rich's column widths
    # can shift between versions), just that the numbers surface.
    assert "2" in result.stdout  # added_nodes count
    assert "1" in result.stdout  # removed_edges count


def test_diff_render_skips_empty_detail_sections(runner, auth_env):
    """Empty detail sections must be skipped — printing an empty
    table for every category turns a 'nothing added' run into
    a wall of empty boxes. Pin that 'Added nodes' header
    doesn't appear when added_nodes is empty."""
    payload = _diff_payload(
        removed_nodes=[
            {"id": "n1", "label": "Old", "type": "Person", "properties": {}},
        ],
    )
    with patch("graphora.client.requests.get") as mock_get:
        mock_get.return_value = _fake_response(payload)
        result = runner.invoke(app, ["diff", "tx-old", "tx-new"])

    assert result.exit_code == 0
    # Empty section header must NOT appear.
    assert "Added nodes" not in result.stdout
    # Non-empty section MUST appear.
    assert "Removed nodes" in result.stdout
    assert "Old" in result.stdout


def test_diff_render_changed_node_unpacks_property_changes(runner, auth_env):
    """Changed nodes are the highest-signal part of the output —
    they tell the operator WHICH fields moved. Pin that each
    property_change pair renders as a row with base + compare
    values so a refactor that collapses them into a single
    JSON-blob cell would fail."""
    payload = _diff_payload(
        changed_nodes=[
            {
                "canonical_id": "cid-alice",
                "type": "Person",
                "base_id": "n1",
                "compare_id": "n2",
                "property_changes": {
                    "title": {"base": "Engineer", "compare": "Senior Engineer"},
                },
            }
        ],
    )
    with patch("graphora.client.requests.get") as mock_get:
        mock_get.return_value = _fake_response(payload)
        result = runner.invoke(app, ["diff", "tx-old", "tx-new"])

    assert result.exit_code == 0
    assert "Changed nodes" in result.stdout
    assert "title" in result.stdout
    assert "Engineer" in result.stdout
    assert "Senior Engineer" in result.stdout


def test_diff_render_unchanged_hidden_by_default(runner, auth_env):
    """Default rendering omits the unchanged column because the
    operator usually only cares about delta. --show-unchanged
    flips this on. Pin both states so a refactor that always-on
    or always-off the column regresses noisily."""
    with patch("graphora.client.requests.get") as mock_get:
        mock_get.return_value = _fake_response(_diff_payload())
        result_default = runner.invoke(app, ["diff", "tx-old", "tx-new"])
        mock_get.return_value = _fake_response(_diff_payload())
        result_with = runner.invoke(
            app, ["diff", "tx-old", "tx-new", "--show-unchanged"]
        )

    assert result_default.exit_code == 0
    assert result_with.exit_code == 0
    assert "Unchanged" not in result_default.stdout
    assert "Unchanged" in result_with.stdout


def test_diff_render_limit_truncates_detail_tables(runner, auth_env):
    """--limit caps the per-section row count so a 1k-row added
    list doesn't blow out the terminal. Pin that the trim
    happens AND that the 'N more' footnote appears so the
    operator knows there's more behind --json."""
    added = [
        {"id": f"n{i}", "label": f"Node{i}", "type": "T", "properties": {}}
        for i in range(15)
    ]
    payload = _diff_payload(added_nodes=added)
    with patch("graphora.client.requests.get") as mock_get:
        mock_get.return_value = _fake_response(payload)
        result = runner.invoke(
            app, ["diff", "tx-old", "tx-new", "--limit", "3"]
        )

    assert result.exit_code == 0
    # First three nodes visible.
    assert "Node0" in result.stdout
    assert "Node2" in result.stdout
    # 12 more hidden behind --json / larger -n.
    assert "12 more" in result.stdout


# ============================================================
# Rich-markup escaping (reviewer-flagged Medium on commit f667979)
# ============================================================


def test_diff_render_escapes_rich_markup_in_property_values(
    runner, auth_env
):
    """Reviewer-flagged Medium on commit f667979: Rich treats
    ``[tag]…[/tag]`` substrings as inline markup, so a property
    value of ``[red]old[/red]`` would render as the colored text
    ``old`` with the brackets stripped — losing the actual diff
    content. Server/user-supplied strings must be escaped before
    they hit the table cells. Pin so a future refactor that
    drops the _safe() wrapper regresses noisily.

    For Rich's escaped output, the bracketed substring is
    preserved with backslash-escaped brackets (``\\[red]``) so
    the original text is reconstructable; what we MUST see is the
    literal characters ``red`` and ``old`` inside brackets, NOT
    the bare colored ``old`` that markup-interpretation would
    produce."""
    payload = _diff_payload(
        changed_nodes=[
            {
                "canonical_id": "cid-alice",
                "type": "Person",
                "base_id": "n1",
                "compare_id": "n2",
                "property_changes": {
                    "title": {
                        "base": "[red]old[/red]",
                        "compare": "[bold]new[/bold]",
                    },
                },
            }
        ],
    )
    with patch("graphora.client.requests.get") as mock_get:
        mock_get.return_value = _fake_response(payload)
        result = runner.invoke(app, ["diff", "tx-old", "tx-new"])

    assert result.exit_code == 0
    # The literal bracketed content must survive into the output —
    # if Rich interpreted [red]old[/red] as markup, the brackets
    # AND the tag name "red" would both be gone (the substring
    # would render as just "old" in red). The escaped form keeps
    # the brackets visible (Rich renders ``\[red]`` as ``[red]``).
    assert "[red]" in result.stdout
    assert "old" in result.stdout
    assert "[bold]" in result.stdout
    assert "new" in result.stdout


def test_diff_render_escapes_rich_markup_in_node_label(runner, auth_env):
    """A node label containing Rich markup must also be escaped.
    Same defense: the extracted ``label`` can carry literal
    brackets, and rendering them as active formatting would
    silently distort the diff view."""
    payload = _diff_payload(
        added_nodes=[
            {
                "id": "n1",
                "label": "[admin] Alice",
                "type": "Person",
                "properties": {},
            }
        ],
    )
    with patch("graphora.client.requests.get") as mock_get:
        mock_get.return_value = _fake_response(payload)
        result = runner.invoke(app, ["diff", "tx-old", "tx-new"])

    assert result.exit_code == 0
    # The bracketed prefix must appear literally; the bare word
    # "Alice" would be present even if markup was interpreted,
    # so the bracket presence is the load-bearing assertion.
    assert "[admin]" in result.stdout


def test_diff_render_escapes_rich_markup_in_transform_id(runner, auth_env):
    """Header panel displays the transform_ids — also untrusted
    inputs in the same way property values are. Pin so a future
    refactor that drops the _safe() escape on header rendering
    regresses."""
    payload = _diff_payload(base="tx-[malicious]", compare="tx-new")
    with patch("graphora.client.requests.get") as mock_get:
        mock_get.return_value = _fake_response(payload)
        result = runner.invoke(app, ["diff", "tx-[malicious]", "tx-new"])

    assert result.exit_code == 0
    # The bracketed tx id must appear literally in the header
    # panel — markup interpretation would have stripped the
    # brackets entirely (`[malicious]` is not a real Rich tag,
    # so Rich would either error out or silently swallow it).
    assert "[malicious]" in result.stdout


# ============================================================
# Credential resolution (mirrors explain.py's pattern)
# ============================================================


def test_diff_uses_config_helpers_when_env_unset(runner, monkeypatch):
    """Persisted-config fallback pin. With env vars cleared,
    patching get_api_url / get_auth_token must be enough for
    ``graphora diff`` to authenticate — same chain explain and
    test commands use."""
    monkeypatch.delenv("GRAPHORA_API_URL", raising=False)
    monkeypatch.delenv("GRAPHORA_AUTH_TOKEN", raising=False)

    with patch(
        "graphora.cli.commands.diff.get_api_url",
        return_value="https://test.example/api",
    ), patch(
        "graphora.cli.commands.diff.get_auth_token",
        return_value="config-token",
    ), patch(
        "graphora.cli.commands.diff.validate_remote_environment",
        return_value=True,
    ), patch("graphora.client.requests.get") as mock_get:
        mock_get.return_value = _fake_response(_diff_payload())
        result = runner.invoke(
            app, ["diff", "tx-old", "tx-new", "--json"]
        )

    assert result.exit_code == 0, (
        f"diff failed with config-only credentials. stdout={result.stdout!r}"
    )
    payload = json.loads(result.stdout)
    assert payload["base_transform_id"] == "tx-old"


def test_diff_friendly_error_when_no_credentials(runner, monkeypatch):
    """When neither flags, env vars, nor config provide credentials,
    surface the 'run config init' message — same UX as explain
    + test commands. Pin so a regression that lets the raw
    ValueError bubble up regresses."""
    monkeypatch.delenv("GRAPHORA_API_URL", raising=False)
    monkeypatch.delenv("GRAPHORA_AUTH_TOKEN", raising=False)

    with patch(
        "graphora.cli.commands.diff.get_api_url", return_value=None
    ), patch(
        "graphora.cli.commands.diff.get_auth_token", return_value=None
    ), patch(
        "graphora.cli.commands.diff.validate_remote_environment",
        return_value=False,
    ), patch(
        "graphora.cli.commands.diff.get_missing_config",
        return_value=["api.url", "api.auth_token"],
    ):
        result = runner.invoke(app, ["diff", "tx-old", "tx-new"])

    assert result.exit_code == 2
    assert "Missing required configuration" in result.stdout
    assert "graphora config init" in result.stdout
