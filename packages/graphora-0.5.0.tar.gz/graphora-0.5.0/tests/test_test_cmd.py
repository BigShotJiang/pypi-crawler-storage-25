"""Smoke + contract tests for ``graphora test``.

The B4-test (Gate 4) runner walks a corpus directory and scores
each entry's extraction against ground truth via graphora-server's
/api/v1/golden/score endpoint. These tests exercise three layers:

  * Typer CLI surface — argument parsing, corpus discovery,
    exit-code contract (0 = pass, 1 = below-threshold, 2 = config).
  * Orchestration — register_ontology → transform →
    wait_for_transform → score_against_golden, in that order,
    once per discovered entry.
  * GraphoraClient.score_against_golden — POST shape + 413
    surface (mirrors /diff's truncation guard).

All HTTP is mocked at the requests level so no network access
is required. Tests follow test_explain.py conventions.
"""

from __future__ import annotations

import json
from pathlib import Path
from typing import Any, Dict, List
from unittest.mock import MagicMock, patch

import pytest
from typer.testing import CliRunner

from graphora.cli.main import app
from graphora.client import GraphoraClient


def _fake_response(payload: Dict[str, Any], status: int = 200):
    """A stand-in for requests.Response that satisfies the client's
    _handle_response shape."""
    resp = MagicMock()
    resp.status_code = status
    resp.json.return_value = payload
    resp.raise_for_status.return_value = None
    return resp


def _scoring_report(
    slug: str,
    nodes_f1: float = 1.0,
    edges_f1: float = 1.0,
    *,
    nodes_tp: int = 1,
    nodes_fp: int = 0,
    nodes_fn: int = 0,
) -> Dict[str, Any]:
    """Minimum-viable ScoringReport shape matching what
    graphora_server.services.golden_corpus.scorer.ScoringReport
    emits via to_dict()."""
    return {
        "corpus_slug": slug,
        "nodes": {
            "f1": nodes_f1,
            "precision": nodes_f1,
            "recall": nodes_f1,
            "true_positives": nodes_tp,
            "false_positives": nodes_fp,
            "false_negatives": nodes_fn,
            "by_type": {
                "Person": {
                    "f1": nodes_f1,
                    "precision": nodes_f1,
                    "recall": nodes_f1,
                    "true_positives": nodes_tp,
                    "false_positives": nodes_fp,
                    "false_negatives": nodes_fn,
                }
            },
        },
        "edges": {
            "f1": edges_f1,
            "precision": edges_f1,
            "recall": edges_f1,
            "true_positives": 0,
            "false_positives": 0,
            "false_negatives": 0,
            "by_type": {},
        },
    }


@pytest.fixture
def runner():
    return CliRunner()


@pytest.fixture
def auth_env(monkeypatch):
    monkeypatch.setenv("GRAPHORA_AUTH_TOKEN", "test-token")
    monkeypatch.setenv("GRAPHORA_API_URL", "https://test.example/api")


@pytest.fixture
def corpus_dir(tmp_path: Path) -> Path:
    """Build a minimal two-entry corpus on disk that the runner
    can walk. Each entry has the trio document.txt + ontology.yaml
    + expected.json. Returns the corpus root path.
    """
    for slug in ("alice_doc", "bob_doc"):
        entry = tmp_path / slug
        entry.mkdir()
        (entry / "document.txt").write_text(f"{slug} document body")
        (entry / "ontology.yaml").write_text(
            "version: '0.1.0'\nentities:\n  Person:\n    properties:\n      "
            "name:\n        type: str\n        required: true\n        unique: true\n"
        )
        (entry / "expected.json").write_text(
            json.dumps(
                {
                    "nodes": [
                        {
                            "id": "n1",
                            "type": "Person",
                            "label": slug,
                            "properties": {
                                "name": slug,
                                "canonical_id": "cid-1",
                                "canonical_key": f"Person:name={slug}",
                            },
                        }
                    ],
                    "edges": [],
                }
            )
        )
    # A non-entry subdir (just a README) — verify the discoverer
    # skips it rather than treating it as a corpus entry.
    (tmp_path / "_helpers").mkdir()
    (tmp_path / "_helpers" / "README.md").write_text("ignore me")
    return tmp_path


# ============================================================
# CLI surface + help discoverability
# ============================================================


def test_test_help_describes_corpus_path_and_threshold(runner):
    """Pin the user-facing surface: --help mentions the corpus
    path argument, --min-f1 gating flag, and --json output. A
    user who runs ``graphora test --help`` should see what they
    can pass without reading source."""
    result = runner.invoke(app, ["test", "--help"])
    assert result.exit_code == 0
    out = result.stdout
    assert "corpus" in out.lower()
    assert "--min-f1" in out
    assert "--json" in out


def test_test_rejects_missing_corpus_path(runner, auth_env):
    """typer's exists=True / dir_okay=True on the corpus_path
    argument should reject a nonexistent path before we touch
    anything. Exit code 2 = usage error."""
    result = runner.invoke(app, ["test", "/nonexistent/path"])
    assert result.exit_code != 0
    # typer surfaces "does not exist" or similar — don't pin
    # exact wording, but the exit code is the contract.


def test_test_empty_corpus_exits_2(runner, auth_env, tmp_path):
    """A corpus root with no valid entries (no document.txt /
    ontology.yaml / expected.json trio in any subdir) is a
    configuration error, not a regression. Exit 2 so CI can
    distinguish "corpus is broken" from "extraction regressed"."""
    # Empty dir — passes typer's exists check, fails discovery.
    result = runner.invoke(app, ["test", str(tmp_path)])
    assert result.exit_code == 2
    assert "No corpus entries" in result.stdout


# ============================================================
# Corpus discovery
# ============================================================


def test_test_discovers_only_trio_complete_subdirs(corpus_dir, auth_env, runner):
    """The discoverer must skip subdirs that don't have all three
    of document.txt + ontology.yaml + expected.json. Pin so a
    helper directory like ``_helpers/`` doesn't get treated as a
    corpus entry and blow up the orchestration on missing files."""
    from graphora.cli.commands.test_cmd import _discover_corpus_entries

    entries = _discover_corpus_entries(corpus_dir)
    slugs = [e["slug"] for e in entries]
    assert sorted(slugs) == ["alice_doc", "bob_doc"]
    # The _helpers/ subdir has no document.txt and must not be
    # in the discovered set.
    assert "_helpers" not in slugs


def test_test_discovery_returns_sorted_for_stable_run_order(tmp_path):
    """Reports across runs need to be diff-able for regression
    review. The discoverer sorts entries by slug so a run that
    happens to walk the filesystem in a different order still
    produces the same report ordering."""
    from graphora.cli.commands.test_cmd import _discover_corpus_entries

    for slug in ("zebra", "alpha", "mango"):
        d = tmp_path / slug
        d.mkdir()
        (d / "document.txt").write_text("x")
        (d / "ontology.yaml").write_text("x")
        (d / "expected.json").write_text("{}")

    entries = _discover_corpus_entries(tmp_path)
    assert [e["slug"] for e in entries] == ["alpha", "mango", "zebra"]


# ============================================================
# Orchestration: 4-step pipeline per entry
# ============================================================


def test_test_orchestrates_register_transform_wait_score_per_entry(
    corpus_dir, auth_env, runner
):
    """The core integration pin: for each corpus entry the runner
    must call register_ontology → transform → wait_for_transform
    → score_against_golden, in that order. This wiring is the
    contract — a refactor that drops the wait step (causing scoring
    against an in-progress transform) would silently produce
    bogus reports.

    Mock at the GraphoraClient method level (not requests level)
    so we can assert call order + arguments precisely."""
    with patch("graphora.cli.commands.test_cmd.GraphoraClient") as MockClient:
        instance = MockClient.return_value
        instance.register_ontology.side_effect = [
            MagicMock(id="ont-1"),
            MagicMock(id="ont-2"),
        ]
        instance.transform.side_effect = [
            MagicMock(id="tx-1"),
            MagicMock(id="tx-2"),
        ]
        instance.wait_for_transform.return_value = MagicMock(
            overall_status=MagicMock(value="completed")
        )
        instance.score_against_golden.side_effect = [
            _scoring_report("alice_doc"),
            _scoring_report("bob_doc"),
        ]

        result = runner.invoke(app, ["test", str(corpus_dir), "--min-f1", "0.5"])

    assert result.exit_code == 0, (
        f"Two perfect-score entries above min_f1 must exit 0, got "
        f"{result.exit_code}: {result.stdout}"
    )
    # Two entries, four method classes — 2 calls each.
    assert instance.register_ontology.call_count == 2
    assert instance.transform.call_count == 2
    assert instance.wait_for_transform.call_count == 2
    assert instance.score_against_golden.call_count == 2

    # Each score call should pass corpus_slug + the expected payload
    # + the transform_id from the preceding transform call.
    scored_slugs = [
        c.kwargs.get("corpus_slug") for c in instance.score_against_golden.call_args_list
    ]
    assert sorted(scored_slugs) == ["alice_doc", "bob_doc"]


# ============================================================
# Threshold gating (exit code contract)
# ============================================================


def test_test_exits_1_when_any_entry_below_min_f1(corpus_dir, auth_env, runner):
    """Gating pin: one entry passes (F1=0.9), one fails (F1=0.3),
    threshold=0.5 → exit 1. CI relies on this exit code to flag
    regressions; a refactor that returns 0 silently would mean
    every run looks clean even when extraction broke."""
    with patch("graphora.cli.commands.test_cmd.GraphoraClient") as MockClient:
        instance = MockClient.return_value
        instance.register_ontology.return_value = MagicMock(id="ont")
        instance.transform.return_value = MagicMock(id="tx")
        instance.wait_for_transform.return_value = MagicMock(
            overall_status=MagicMock(value="completed")
        )
        instance.score_against_golden.side_effect = [
            _scoring_report("alice_doc", nodes_f1=0.9),
            _scoring_report("bob_doc", nodes_f1=0.3, nodes_tp=0, nodes_fn=1),
        ]

        result = runner.invoke(app, ["test", str(corpus_dir), "--min-f1", "0.5"])

    assert result.exit_code == 1, (
        "One entry below min_f1=0.5 must trigger exit 1, but got "
        f"{result.exit_code}. The CI gating signal is broken."
    )
    # Verdict line should reflect failure.
    assert "FAIL" in result.stdout


def test_test_node_only_corpus_entry_passes_above_threshold(
    corpus_dir, auth_env, runner
):
    """Reviewer-flagged High on commit 80e1509: a corpus entry
    with no expected edges and no extracted edges has a zero-
    denominator edges dimension. The server scorer returns 0.0
    for that (intentionally — NaN doesn't serialize), so a naive
    gate that checks ``edges_f1 >= min_f1`` would fail any
    --min-f1 > 0 even when the extractor's behavior is correct.

    Pin: a node-only entry with perfect nodes (F1=1.0) and an
    empty-edges dimension (TP=FP=FN=0) must EXIT 0 at any
    --min-f1, because the edges dimension is not applicable for
    gating. A regression here would silently make every node-
    only doc impossible to pass in CI."""
    # Override the default _scoring_report to produce a node-only
    # shape: perfect nodes, edges with all-zero counts (the real
    # server output when expected.edges == [] and actual.edges == []).
    node_only_report = _scoring_report("alice_doc")
    node_only_report["edges"] = {
        "f1": 0.0,
        "precision": 0.0,
        "recall": 0.0,
        "true_positives": 0,
        "false_positives": 0,
        "false_negatives": 0,
        "by_type": {},
    }

    with patch("graphora.cli.commands.test_cmd.GraphoraClient") as MockClient:
        instance = MockClient.return_value
        instance.register_ontology.return_value = MagicMock(id="ont")
        instance.transform.return_value = MagicMock(id="tx")
        instance.wait_for_transform.return_value = MagicMock(
            overall_status=MagicMock(value="completed")
        )
        # Apply the node-only shape to BOTH entries so the run
        # is uniformly node-only.
        instance.score_against_golden.side_effect = [
            node_only_report,
            {**node_only_report, "corpus_slug": "bob_doc"},
        ]

        result = runner.invoke(app, ["test", str(corpus_dir), "--min-f1", "0.5"])

    assert result.exit_code == 0, (
        "Node-only corpus entries with perfect nodes.f1 and "
        "zero-denominator edges must pass gating. Got exit "
        f"{result.exit_code} — the gate is treating the scorer's "
        "placeholder 0.0 edges_f1 as a real regression signal. "
        f"stdout: {result.stdout}"
    )


def test_test_exits_0_when_default_min_f1_is_zero(corpus_dir, auth_env, runner):
    """Informational-mode pin: default --min-f1 is 0.0 so even
    all-FN reports pass the gate. This is intentional — users
    running `graphora test` without setting a threshold want a
    score report, not a CI failure. The gate is opt-in."""
    with patch("graphora.cli.commands.test_cmd.GraphoraClient") as MockClient:
        instance = MockClient.return_value
        instance.register_ontology.return_value = MagicMock(id="ont")
        instance.transform.return_value = MagicMock(id="tx")
        instance.wait_for_transform.return_value = MagicMock(
            overall_status=MagicMock(value="completed")
        )
        # All-zero report — the "extractor found nothing" outcome.
        instance.score_against_golden.return_value = _scoring_report(
            "any", nodes_f1=0.0, edges_f1=0.0, nodes_tp=0, nodes_fn=1
        )

        result = runner.invoke(app, ["test", str(corpus_dir)])

    assert result.exit_code == 0, (
        "Default min_f1=0.0 must let all-FN reports pass — the "
        "runner is informational by default. Exit "
        f"{result.exit_code} means the default is now gating."
    )


# ============================================================
# Per-entry failure isolation
# ============================================================


def test_test_per_entry_failure_records_but_continues(corpus_dir, auth_env, runner):
    """If one entry's API calls explode, the runner should record
    the failure and keep going on the rest. A single broken doc
    shouldn't abort the whole corpus run — operators want to see
    every doc's regression at once. Pin so a future refactor that
    raises out of the loop doesn't silently kill multi-doc runs.

    But: any failure causes overall exit 1, because the failed
    entry has no evidence its extraction would have scored
    above the threshold."""
    from graphora.exceptions import GraphoraAPIError

    with patch("graphora.cli.commands.test_cmd.GraphoraClient") as MockClient:
        instance = MockClient.return_value
        instance.register_ontology.return_value = MagicMock(id="ont")
        # First entry transforms fine; second entry's wait fails.
        instance.transform.return_value = MagicMock(id="tx")
        instance.wait_for_transform.side_effect = [
            MagicMock(overall_status=MagicMock(value="completed")),
            GraphoraAPIError("Transform failed: chunking exploded", 500),
        ]
        instance.score_against_golden.return_value = _scoring_report(
            "alice_doc", nodes_f1=1.0, edges_f1=1.0
        )

        result = runner.invoke(app, ["test", str(corpus_dir), "--min-f1", "0.5"])

    # Exit 1: failure entry trips the gate regardless of the
    # passing entry's perfect score.
    assert result.exit_code == 1
    # The failure must be visible in output — operators need to
    # know WHICH doc failed.
    assert "Orchestration Failures" in result.stdout
    # The passing entry should still be in the scoring table.
    assert "alice_doc" in result.stdout


def test_test_malformed_expected_json_isolates_to_failure(
    auth_env, runner, tmp_path
):
    """Reviewer-flagged Medium on commit 80e1509: a corpus entry
    with a malformed expected.json must NOT abort the whole run.
    The per-entry catch must include local-side errors (OSError /
    ValueError / json.JSONDecodeError) so the failure is recorded
    in the failures table and the next entry still runs.

    Pin: one good entry + one with broken expected.json →
    runner still scores the good entry, records the broken one
    as a failure, and exits 1 (failure flips the gate
    regardless of the passing entry's perfect score). A
    regression where the catch only handled API errors would
    have the entire run propagate the JSONDecodeError out of
    typer with no diagnostic — the operator would see a stack
    trace and never see the good entry's report."""
    # Build a corpus with two entries — one good, one with
    # malformed expected.json. Both pass the discoverer (all
    # three files exist); only the second fails when loaded.
    for slug in ("good_doc", "broken_doc"):
        entry = tmp_path / slug
        entry.mkdir()
        (entry / "document.txt").write_text(f"{slug} body")
        (entry / "ontology.yaml").write_text(
            "version: '0.1.0'\nentities:\n  Person:\n    properties:\n      "
            "name:\n        type: str\n        required: true\n        unique: true\n"
        )
        if slug == "good_doc":
            (entry / "expected.json").write_text(
                json.dumps({"nodes": [], "edges": []})
            )
        else:
            # Deliberately malformed JSON — the json.loads in
            # _run_entry will raise JSONDecodeError (subclass of
            # ValueError). Pre-fix this would have propagated.
            (entry / "expected.json").write_text("{ this is not valid json")

    with patch("graphora.cli.commands.test_cmd.GraphoraClient") as MockClient:
        instance = MockClient.return_value
        instance.register_ontology.return_value = MagicMock(id="ont")
        instance.transform.return_value = MagicMock(id="tx")
        instance.wait_for_transform.return_value = MagicMock(
            overall_status=MagicMock(value="completed")
        )
        instance.score_against_golden.return_value = _scoring_report(
            "good_doc", nodes_f1=1.0
        )

        result = runner.invoke(app, ["test", str(tmp_path), "--min-f1", "0.5"])

    # Must NOT crash with a JSONDecodeError stack trace — that
    # was the pre-fix behavior. Typer catches uncaught exceptions
    # and surfaces them, but the test runner exposes the
    # exception via result.exception. Pin its absence.
    assert result.exception is None or isinstance(
        result.exception, SystemExit
    ), (
        "Malformed expected.json must be isolated, not propagated. "
        f"Got exception: {result.exception!r}"
    )
    # Exit 1 because the broken entry flips the gate (failures
    # always fail; we have no evidence the doc would have scored
    # above threshold).
    assert result.exit_code == 1, (
        "Broken entry must flip the gate to exit 1. Got "
        f"{result.exit_code}: {result.stdout}"
    )
    # The good entry should still appear in the reports table.
    assert "good_doc" in result.stdout
    # The broken entry should appear in the failures table with
    # a recognizable error string from the JSON parser.
    assert "broken_doc" in result.stdout
    assert "Orchestration Failures" in result.stdout


# ============================================================
# JSON output
# ============================================================


def test_test_json_output_emits_machine_parseable_aggregate(
    corpus_dir, auth_env, runner
):
    """--json emits the full aggregate (reports + failures +
    passed flag) to stdout for downstream piping. Pin the shape
    so a refactor that drops the failures array doesn't silently
    break CI scripts that look at it."""
    with patch("graphora.cli.commands.test_cmd.GraphoraClient") as MockClient:
        instance = MockClient.return_value
        instance.register_ontology.return_value = MagicMock(id="ont")
        instance.transform.return_value = MagicMock(id="tx")
        instance.wait_for_transform.return_value = MagicMock(
            overall_status=MagicMock(value="completed")
        )
        instance.score_against_golden.side_effect = [
            _scoring_report("alice_doc"),
            _scoring_report("bob_doc"),
        ]

        result = runner.invoke(
            app,
            ["test", str(corpus_dir), "--json", "--min-f1", "0.5"],
        )

    assert result.exit_code == 0
    payload = json.loads(result.stdout)
    # Top-level keys the CI tooling reads.
    assert payload["passed"] is True
    assert payload["min_f1"] == 0.5
    assert payload["successful_entries"] == 2
    assert payload["failed_entries"] == 0
    assert len(payload["reports"]) == 2


# ============================================================
# GraphoraClient.score_against_golden contract
# ============================================================


def test_client_score_against_golden_posts_to_correct_endpoint(auth_env):
    """Pin the URL + payload shape the server endpoint expects.
    A drift here (e.g., the path changing or the request body
    losing corpus_slug) would silently break every CLI runner
    against new servers."""
    expected_graph = {"nodes": [], "edges": []}

    with patch("graphora.client.requests.post") as mock_post:
        mock_post.return_value = _fake_response(
            _scoring_report("test_slug", nodes_f1=1.0)
        )
        client = GraphoraClient()
        result = client.score_against_golden(
            expected=expected_graph,
            transform_id="tx-42",
            corpus_slug="test_slug",
        )

    # URL: golden/score under the v1 prefix the client builds.
    posted_url = mock_post.call_args.args[0]
    assert posted_url.endswith("/api/v1/golden/score"), (
        f"Score endpoint URL drifted: {posted_url}"
    )
    # JSON body: all three fields present.
    posted_json = mock_post.call_args.kwargs["json"]
    assert posted_json == {
        "expected": expected_graph,
        "transform_id": "tx-42",
        "corpus_slug": "test_slug",
    }
    # Returns the raw dict — no model-wrapping.
    assert result["nodes"]["f1"] == 1.0


def test_client_score_against_golden_omits_corpus_slug_when_none(auth_env):
    """corpus_slug is optional server-side. The client should NOT
    send the key when caller omits it, mirroring the server's
    default-empty behavior. Pin so a future refactor doesn't
    start sending an explicit None / empty string and pollute
    server-side aggregation."""
    with patch("graphora.client.requests.post") as mock_post:
        mock_post.return_value = _fake_response(_scoring_report("", nodes_f1=1.0))
        client = GraphoraClient()
        client.score_against_golden(
            expected={"nodes": [], "edges": []},
            transform_id="tx-1",
        )

    posted_json = mock_post.call_args.kwargs["json"]
    assert "corpus_slug" not in posted_json, (
        "Omitted corpus_slug must not appear in the request body; "
        f"got {posted_json!r}"
    )


def test_client_score_against_golden_surfaces_413_as_api_error(auth_env):
    """413 means the actual graph exceeded the diff loader's cap
    (mirrors /diff — graphora-server commit e21c1f5). The client
    must surface this as a GraphoraAPIError, not eat it. Pin so
    a CLI runner can distinguish "too big to score" from "scored
    badly" — they're semantically different signals."""
    import requests as requests_module

    from graphora.exceptions import GraphoraAPIError

    err_response = MagicMock()
    err_response.status_code = 413
    err_response.json.return_value = {
        "detail": {
            "error": "transform_too_large_to_diff",
            "side": "actual",
            "transform_id": "tx-big",
            "truncated_dimension": "nodes",
        }
    }
    err = requests_module.exceptions.HTTPError(response=err_response)
    err_response.raise_for_status.side_effect = err

    with patch("graphora.client.requests.post", return_value=err_response):
        client = GraphoraClient()
        with pytest.raises(GraphoraAPIError) as exc_info:
            client.score_against_golden(
                expected={"nodes": [], "edges": []},
                transform_id="tx-big",
            )

    # Status code propagates so callers can branch on it.
    assert exc_info.value.status_code == 413
