"""Smoke + contract tests for ``graphora install`` (A7-cli).

The install command writes MCP server config files for agent
clients (Claude Desktop / Claude Code / Cursor / Codex / VS
Code). Tests cover:

  * Adapter table: every supported client is covered by exactly
    one adapter; help text mentions all of them.
  * Config-shape pin: the ``graphora`` ``mcpServers`` entry
    carries ``command`` + ``env`` with GRAPHORA_API_URL +
    (when configured) GRAPHORA_AUTH_TOKEN.
  * Merge behavior: when the target file already has other
    ``mcpServers`` entries, the install upserts ``graphora``
    without clobbering the rest. Top-level keys beyond
    ``mcpServers`` survive too.
  * Force mode: overwrites the file completely; preserves no
    pre-existing entries.
  * Workspace vs user-global: workspace-relative adapters
    resolve against ``--workspace`` (default cwd); user-global
    adapters ignore it.
  * Dry-run: prints the config without writing to disk.
  * Refuse-malformed: existing file with invalid JSON refuses
    rather than silently overwriting.
  * Auth posture: writes succeed even when no auth token is
    configured (the warning surfaces in stdout but the file
    lands).
"""

from __future__ import annotations

import json
from pathlib import Path
from typing import Any, Dict
from unittest.mock import patch

import pytest
from typer.testing import CliRunner

from graphora.cli.commands.install import (
    CLIENT_ADAPTERS,
    _build_graphora_server_config,
    _merge_config,
    supported_clients,
)
from graphora.cli.main import app


@pytest.fixture
def runner() -> CliRunner:
    return CliRunner()


# ============================================================
# Adapter table coverage
# ============================================================


def test_supported_clients_covers_all_spec_clients():
    """The five clients the execution plan calls out — every one
    needs an adapter. Pin so a future refactor that renames or
    drops one regresses noisily."""
    expected = {"claude-desktop", "claude-code", "cursor", "codex", "vscode"}
    assert set(supported_clients()) == expected


def test_help_lists_every_supported_client(runner):
    """The CLI help text must mention every client so operators
    discover them without reading the source. Pin so the help
    string drifts in lockstep with the adapter table."""
    result = runner.invoke(app, ["install", "--help"])
    assert result.exit_code == 0
    for name in supported_clients():
        assert name in result.stdout


def test_unknown_client_fails_with_exit_code_2(runner):
    result = runner.invoke(app, ["install", "no-such-client"])
    assert result.exit_code == 2
    assert "Unknown client" in result.stdout or "no-such-client" in result.stdout


# ============================================================
# Config-shape pin
# ============================================================


def test_graphora_server_entry_carries_command_and_env():
    config = _build_graphora_server_config(
        api_url="http://localhost:8000",
        auth_token="jwt-xyz",
        command="graphora-mcp",
    )
    assert config["command"] == "graphora-mcp"
    assert config["env"] == {
        "GRAPHORA_API_URL": "http://localhost:8000",
        "GRAPHORA_AUTH_TOKEN": "jwt-xyz",
    }


def test_graphora_server_entry_omits_token_when_unset():
    """When the operator hasn't configured an auth token, the
    env block must NOT include a ``GRAPHORA_AUTH_TOKEN`` key —
    setting it to None or "" via the MCP client's env JSON would
    break the server's bearer-token check. Auth bypass mode is
    the intended use case."""
    config = _build_graphora_server_config(
        api_url="http://localhost:8000",
        auth_token=None,
        command="graphora-mcp",
    )
    assert "GRAPHORA_AUTH_TOKEN" not in config["env"]
    assert config["env"] == {"GRAPHORA_API_URL": "http://localhost:8000"}


def test_command_override_is_absolute_path():
    """An operator who passes ``--command /Users/x/.venv/bin/
    graphora-mcp`` should see that absolute path in the written
    config. Pin against an over-eager normalizer that strips
    paths to basename."""
    config = _build_graphora_server_config(
        api_url="http://localhost:8000",
        auth_token=None,
        command="/Users/x/.venv/bin/graphora-mcp",
    )
    assert config["command"] == "/Users/x/.venv/bin/graphora-mcp"


# ============================================================
# Merge behavior
# ============================================================


def test_merge_preserves_other_mcp_servers():
    """A user with an existing ``filesystem`` MCP server entry
    must keep it after the install. Only the ``graphora`` key
    gets upserted."""
    existing: Dict[str, Any] = {
        "mcpServers": {
            "filesystem": {
                "command": "mcp-server-filesystem",
                "args": ["/some/path"],
            }
        }
    }
    graphora_server = _build_graphora_server_config(
        api_url="http://localhost:8000", auth_token=None, command="graphora-mcp"
    )
    merged = _merge_config(existing, graphora_server)
    servers = merged["mcpServers"]
    assert "filesystem" in servers
    assert "graphora" in servers
    # The filesystem entry must be unchanged.
    assert servers["filesystem"]["command"] == "mcp-server-filesystem"


def test_merge_preserves_top_level_keys():
    """Some clients carry other config alongside ``mcpServers``
    in the same file (e.g., Claude Desktop's global Claude
    config). Those keys must survive the install."""
    existing: Dict[str, Any] = {
        "theme": "dark",
        "mcpServers": {"a": {"command": "a"}},
    }
    graphora_server = _build_graphora_server_config(
        api_url="http://localhost:8000", auth_token=None, command="graphora-mcp"
    )
    merged = _merge_config(existing, graphora_server)
    assert merged["theme"] == "dark"
    assert "graphora" in merged["mcpServers"]
    assert "a" in merged["mcpServers"]


def test_merge_overwrites_stale_graphora_entry():
    """If a previous ``graphora install`` ran with different
    credentials, the new install must overwrite that
    ``graphora`` entry rather than appending. Pin so re-running
    install actually updates the config."""
    existing: Dict[str, Any] = {
        "mcpServers": {
            "graphora": {
                "command": "graphora-mcp",
                "env": {"GRAPHORA_API_URL": "http://old-url:8000"},
            }
        }
    }
    new_entry = _build_graphora_server_config(
        api_url="http://new-url:9000", auth_token=None, command="graphora-mcp"
    )
    merged = _merge_config(existing, new_entry)
    assert merged["mcpServers"]["graphora"]["env"]["GRAPHORA_API_URL"] == (
        "http://new-url:9000"
    )


# ============================================================
# Workspace adapters (cursor / vscode / codex / claude-code)
# ============================================================


def test_workspace_adapter_writes_to_workspace_relative_path(
    runner, tmp_path
):
    """``graphora install cursor`` in a workspace creates
    ``.cursor/mcp.json`` relative to the workspace root.
    Verifies the path resolution and that intermediate
    directories (``.cursor/``) are created on demand."""
    with patch(
        "graphora.cli.commands.install.get_api_url",
        return_value="http://localhost:8000",
    ), patch(
        "graphora.cli.commands.install.get_auth_token",
        return_value="jwt-test",
    ):
        result = runner.invoke(
            app,
            ["install", "cursor", "--workspace", str(tmp_path)],
        )

    assert result.exit_code == 0, result.stdout
    expected = tmp_path / ".cursor" / "mcp.json"
    assert expected.exists()
    written = json.loads(expected.read_text())
    assert "graphora" in written["mcpServers"]
    assert written["mcpServers"]["graphora"]["env"]["GRAPHORA_API_URL"] == (
        "http://localhost:8000"
    )
    assert written["mcpServers"]["graphora"]["env"]["GRAPHORA_AUTH_TOKEN"] == (
        "jwt-test"
    )


@pytest.mark.parametrize(
    "client,relative_path",
    [
        ("cursor", Path(".cursor") / "mcp.json"),
        ("vscode", Path(".vscode") / "mcp.json"),
        ("codex", Path(".codex-plugin") / ".mcp.json"),
        ("claude-code", Path(".mcp.json")),
    ],
)
def test_every_workspace_adapter_lands_at_documented_path(
    runner, tmp_path, client, relative_path
):
    """Each workspace adapter has a documented target path the
    agent client expects. Pin the per-client paths so a refactor
    that swaps one (say, moves Cursor's config) regresses here
    rather than at the next user install."""
    with patch(
        "graphora.cli.commands.install.get_api_url",
        return_value="http://localhost:8000",
    ), patch(
        "graphora.cli.commands.install.get_auth_token",
        return_value=None,
    ):
        result = runner.invoke(
            app,
            ["install", client, "--workspace", str(tmp_path)],
        )

    assert result.exit_code == 0, result.stdout
    expected = tmp_path / relative_path
    assert expected.exists(), (
        f"{client}: expected config at {expected} did not land"
    )


def test_user_global_adapter_ignores_workspace(runner, tmp_path):
    """claude-desktop writes to a user-global path; the
    --workspace flag must NOT redirect it into the tmp_path."""
    # Stub the user-global path through the adapter so the test
    # doesn't write into the real home directory.
    fake_target = tmp_path / "fake_home" / "claude_desktop_config.json"
    with patch.dict(
        CLIENT_ADAPTERS,
        {
            "claude-desktop": CLIENT_ADAPTERS["claude-desktop"].__class__(
                name="claude-desktop",
                description="test",
                config_path=fake_target,
                workspace_relative=False,
            )
        },
    ), patch(
        "graphora.cli.commands.install.get_api_url",
        return_value="http://localhost:8000",
    ), patch(
        "graphora.cli.commands.install.get_auth_token",
        return_value=None,
    ):
        result = runner.invoke(
            app,
            [
                "install",
                "claude-desktop",
                "--workspace",
                str(tmp_path / "elsewhere"),
            ],
        )

    assert result.exit_code == 0, result.stdout
    # The config landed at fake_target, NOT inside tmp_path/elsewhere.
    assert fake_target.exists()
    assert not (tmp_path / "elsewhere" / ".mcp.json").exists()


# ============================================================
# Dry-run + force + missing-credential paths
# ============================================================


def test_dry_run_does_not_write_file(runner, tmp_path):
    """--dry-run prints the resolved config but skips disk
    writes. Pin so a future refactor that forgets to early-return
    in dry-run mode regresses here."""
    with patch(
        "graphora.cli.commands.install.get_api_url",
        return_value="http://localhost:8000",
    ), patch(
        "graphora.cli.commands.install.get_auth_token",
        return_value="jwt",
    ):
        result = runner.invoke(
            app,
            [
                "install",
                "cursor",
                "--workspace",
                str(tmp_path),
                "--dry-run",
            ],
        )

    assert result.exit_code == 0, result.stdout
    # Resolved config printed.
    assert "GRAPHORA_API_URL" in result.stdout
    # No file landed.
    assert not (tmp_path / ".cursor" / "mcp.json").exists()


def test_force_overwrites_existing_other_servers(runner, tmp_path):
    """--force replaces the entire config file. Pre-existing
    ``mcpServers`` entries are wiped. Pin against a refactor
    that quietly preserves them — --force is the destructive
    opt-in for exactly that purpose."""
    target_dir = tmp_path / ".cursor"
    target_dir.mkdir()
    target = target_dir / "mcp.json"
    target.write_text(
        json.dumps(
            {
                "mcpServers": {
                    "filesystem": {"command": "mcp-server-filesystem"}
                }
            }
        )
    )

    with patch(
        "graphora.cli.commands.install.get_api_url",
        return_value="http://localhost:8000",
    ), patch(
        "graphora.cli.commands.install.get_auth_token",
        return_value=None,
    ):
        result = runner.invoke(
            app,
            [
                "install",
                "cursor",
                "--workspace",
                str(tmp_path),
                "--force",
            ],
        )

    assert result.exit_code == 0, result.stdout
    written = json.loads(target.read_text())
    # The graphora entry is present.
    assert "graphora" in written["mcpServers"]
    # The pre-existing filesystem entry was wiped by --force.
    assert "filesystem" not in written["mcpServers"]


def test_missing_api_url_fails_with_exit_2(runner, tmp_path):
    """No --api-url, no persisted config → exit 2 with a
    friendly diagnostic. Pin so the empty-config path stays
    actionable."""
    with patch(
        "graphora.cli.commands.install.get_api_url",
        return_value=None,
    ), patch(
        "graphora.cli.commands.install.get_auth_token",
        return_value=None,
    ):
        result = runner.invoke(
            app,
            ["install", "cursor", "--workspace", str(tmp_path)],
        )

    assert result.exit_code == 2
    assert "API URL" in result.stdout


def test_missing_auth_token_warns_but_succeeds(runner, tmp_path):
    """Auth bypass mode is a valid deployment. The install must
    succeed without an auth token but surface a yellow warning
    so the operator knows the bearer auth will be absent."""
    with patch(
        "graphora.cli.commands.install.get_api_url",
        return_value="http://localhost:8000",
    ), patch(
        "graphora.cli.commands.install.get_auth_token",
        return_value=None,
    ):
        result = runner.invoke(
            app,
            ["install", "cursor", "--workspace", str(tmp_path)],
        )

    assert result.exit_code == 0
    assert "auth token" in result.stdout.lower()
    written = json.loads((tmp_path / ".cursor" / "mcp.json").read_text())
    # Token is genuinely omitted from the env block — not
    # present as "" or null.
    assert "GRAPHORA_AUTH_TOKEN" not in (
        written["mcpServers"]["graphora"]["env"]
    )


# ============================================================
# Refuse-malformed defense
# ============================================================


def test_malformed_existing_json_refuses_overwrite(runner, tmp_path):
    """If the target file already exists but contains malformed
    JSON (operator hand-edited and left a syntax error), the
    install must refuse rather than silently overwrite. The
    refuse path keeps the operator's work safe."""
    target_dir = tmp_path / ".cursor"
    target_dir.mkdir()
    target = target_dir / "mcp.json"
    target.write_text("{not valid json")

    with patch(
        "graphora.cli.commands.install.get_api_url",
        return_value="http://localhost:8000",
    ), patch(
        "graphora.cli.commands.install.get_auth_token",
        return_value="jwt",
    ):
        result = runner.invoke(
            app,
            ["install", "cursor", "--workspace", str(tmp_path)],
        )

    assert result.exit_code == 2
    # Original malformed content survived.
    assert target.read_text() == "{not valid json"


def test_non_dict_mcp_servers_refuses_overwrite(runner, tmp_path):
    """Reviewer-flagged Medium on commit bca4c4b: pre-fix the merge
    path silently replaced a non-dict ``mcpServers`` value with
    ``{}``, clobbering a semantically-malformed config without
    --force. A file like ``{"mcpServers": [...]}`` has valid JSON
    but the wrong shape; the install must refuse rather than
    overwrite, matching the malformed-JSON refusal posture.

    Pin the array case explicitly so a refactor that re-relaxes
    the check (e.g., "we can always coerce to dict") fails here
    rather than silently destroys the operator's config."""
    target_dir = tmp_path / ".cursor"
    target_dir.mkdir()
    target = target_dir / "mcp.json"
    target.write_text(json.dumps({"mcpServers": [{"a": 1}]}))

    with patch(
        "graphora.cli.commands.install.get_api_url",
        return_value="http://localhost:8000",
    ), patch(
        "graphora.cli.commands.install.get_auth_token",
        return_value="jwt",
    ):
        result = runner.invoke(
            app,
            ["install", "cursor", "--workspace", str(tmp_path)],
        )

    assert result.exit_code == 2
    # Original malformed content survived.
    assert json.loads(target.read_text()) == {"mcpServers": [{"a": 1}]}
    # Diagnostic mentions the shape problem.
    assert "non-object" in result.stdout or "mcpServers" in result.stdout


def test_null_mcp_servers_is_legitimate_empty(runner, tmp_path):
    """The complement to the non-dict-array case: ``mcpServers:
    null`` IS legitimate empty-state representation (JSON for
    "no servers configured"). The install should treat it as
    missing-key and proceed without refusing.

    Pin so a future refactor that over-strictly rejects all
    non-dict ``mcpServers`` (including null) regresses here —
    the read layer has to thread the needle between "malformed
    shape" (arrays/strings/numbers) and "explicit empty"
    (null)."""
    target_dir = tmp_path / ".cursor"
    target_dir.mkdir()
    target = target_dir / "mcp.json"
    target.write_text(json.dumps({"mcpServers": None}))

    with patch(
        "graphora.cli.commands.install.get_api_url",
        return_value="http://localhost:8000",
    ), patch(
        "graphora.cli.commands.install.get_auth_token",
        return_value=None,
    ):
        result = runner.invoke(
            app,
            ["install", "cursor", "--workspace", str(tmp_path)],
        )

    assert result.exit_code == 0
    written = json.loads(target.read_text())
    assert "graphora" in written["mcpServers"]


def test_force_bypasses_non_dict_mcp_servers(runner, tmp_path):
    """--force overrides the malformed-mcpServers refusal too,
    same as it overrides malformed-JSON. Pin so the explicit
    destructive opt-in stays a single escape hatch — operators
    learn one flag, get unstuck from any malformed-existing
    state."""
    target_dir = tmp_path / ".cursor"
    target_dir.mkdir()
    target = target_dir / "mcp.json"
    target.write_text(json.dumps({"mcpServers": [{"a": 1}]}))

    with patch(
        "graphora.cli.commands.install.get_api_url",
        return_value="http://localhost:8000",
    ), patch(
        "graphora.cli.commands.install.get_auth_token",
        return_value=None,
    ):
        result = runner.invoke(
            app,
            [
                "install",
                "cursor",
                "--workspace",
                str(tmp_path),
                "--force",
            ],
        )

    assert result.exit_code == 0
    written = json.loads(target.read_text())
    assert "graphora" in written["mcpServers"]


def _normalize(stdout: str) -> str:
    """Collapse Rich's terminal line-wrapping for substring
    assertions. Rich inserts newlines based on console width
    (default 80 cols in CliRunner); a multi-word phrase like
    "not on PATH" can land split across a wrap boundary as
    "not \\non PATH". Normalize to a single line so assertions
    survive width changes."""
    return " ".join(stdout.split())


def test_warns_when_command_missing_from_path(runner, tmp_path):
    """Reviewer-flagged Open Question on commit bca4c4b: the
    generated config references ``graphora-mcp``, but that
    binary only lands with ``graphora-server[mcp]``. If the
    operator installed only graphora-client, the agent client
    will fail to launch the MCP server with an opaque error.

    Pin that the install surfaces a yellow warning when
    ``shutil.which(command)`` misses — operators see the
    missing prerequisite at install time, NOT at first-use
    time when they're already debugging in Claude Desktop's
    error log."""
    fake_missing_command = "graphora-mcp-nonexistent-xyz-123"
    with patch(
        "graphora.cli.commands.install.get_api_url",
        return_value="http://localhost:8000",
    ), patch(
        "graphora.cli.commands.install.get_auth_token",
        return_value=None,
    ), patch(
        "graphora.cli.commands.install.shutil.which",
        return_value=None,
    ):
        result = runner.invoke(
            app,
            [
                "install",
                "cursor",
                "--workspace",
                str(tmp_path),
                "--command",
                fake_missing_command,
            ],
        )

    # Install still succeeds — the warning is a foot-gun
    # heads-up, not a blocking error (install and runtime can
    # legitimately differ in environment).
    assert result.exit_code == 0
    out = _normalize(result.stdout)
    assert "not on PATH" in out
    # The actionable hint mentions the ``[mcp]`` extra
    # specifically — Rich would eat unescaped ``[mcp]`` as a
    # markup tag, so the install command escapes the brackets.
    # Pin the rendered form so a regression that drops the
    # escape (and silently loses the ``[mcp]`` suffix) fails
    # here.
    assert "graphora-server[mcp]" in out


def test_no_warning_when_command_resolves_on_path(runner, tmp_path):
    """The complement: when ``shutil.which`` finds the command,
    no warning surfaces. Pin so the warning doesn't fire
    spuriously and train operators to ignore it."""
    with patch(
        "graphora.cli.commands.install.get_api_url",
        return_value="http://localhost:8000",
    ), patch(
        "graphora.cli.commands.install.get_auth_token",
        return_value=None,
    ), patch(
        "graphora.cli.commands.install.shutil.which",
        return_value="/fake/bin/graphora-mcp",
    ):
        result = runner.invoke(
            app,
            ["install", "cursor", "--workspace", str(tmp_path)],
        )

    assert result.exit_code == 0
    out = _normalize(result.stdout)
    assert "not on PATH" not in out
    assert "graphora-server[mcp]" not in out


def test_warns_when_absolute_command_path_is_not_executable(
    runner, tmp_path
):
    """Reviewer-flagged Low on commit 7e7202a: the absolute-path
    branch previously only checked ``is_file()`` and missed the
    executability requirement. A path-shaped --command pointing
    at a non-executable file (chmod -x'd by mistake, copied
    from a tarball without preserving the +x bit, etc.)
    suppressed the warning even though the agent client
    couldn't actually launch it.

    Fixture: create a real file at the path but chmod it to
    644 (readable, not executable). The install must surface
    the warning — the file exists, but the binary won't run.

    Skipped on Windows because os.access(path, os.X_OK) on
    Windows returns True for any readable file (Windows uses
    PATHEXT for executability, not POSIX bits). The
    skip-by-platform pin keeps the test meaningful on the
    POSIX systems where the bug actually surfaces."""
    import os
    import sys

    if sys.platform == "win32":
        pytest.skip(
            "POSIX-only: Windows ignores X_OK permission bits "
            "(executability is determined by PATHEXT)."
        )

    fake_binary = tmp_path / "fake-graphora-mcp"
    fake_binary.write_text("#!/bin/sh\necho should-not-run\n")
    # Strip the execute bit explicitly. The default file mode
    # from write_text() varies by umask, so we pin 0o644 to
    # guarantee non-executable regardless of test environment.
    os.chmod(fake_binary, 0o644)
    # Sanity-check the fixture before exercising the install:
    # if the platform doesn't honor the chmod, the test would
    # silently pass even if the bug were back.
    assert fake_binary.is_file()
    assert not os.access(fake_binary, os.X_OK)

    with patch(
        "graphora.cli.commands.install.get_api_url",
        return_value="http://localhost:8000",
    ), patch(
        "graphora.cli.commands.install.get_auth_token",
        return_value=None,
    ):
        result = runner.invoke(
            app,
            [
                "install",
                "cursor",
                "--workspace",
                str(tmp_path),
                "--command",
                str(fake_binary),
            ],
        )

    assert result.exit_code == 0
    assert "not on PATH" in _normalize(result.stdout)


def test_warns_when_absolute_command_path_does_not_exist(
    runner, tmp_path
):
    """When the operator passes an absolute path to --command,
    skip ``shutil.which`` and check the file directly. Pin the
    absolute-path branch so a refactor that defers to which()
    for everything (which doesn't handle absolute paths the way
    we want) regresses here.

    The warning surfaces even when the path is well-formed but
    points at nothing — useful diagnostic for typos in long
    venv paths."""
    fake_path = tmp_path / "nonexistent-venv" / "bin" / "graphora-mcp"
    with patch(
        "graphora.cli.commands.install.get_api_url",
        return_value="http://localhost:8000",
    ), patch(
        "graphora.cli.commands.install.get_auth_token",
        return_value=None,
    ):
        result = runner.invoke(
            app,
            [
                "install",
                "cursor",
                "--workspace",
                str(tmp_path),
                "--command",
                str(fake_path),
            ],
        )

    assert result.exit_code == 0
    assert "not on PATH" in _normalize(result.stdout)


def test_force_bypasses_malformed_existing_json(runner, tmp_path):
    """--force is the explicit override — it overwrites the file
    regardless of pre-existing content, including malformed
    JSON. Pin that --force genuinely escapes the refuse-malformed
    safety, not just the merge-existing path."""
    target_dir = tmp_path / ".cursor"
    target_dir.mkdir()
    target = target_dir / "mcp.json"
    target.write_text("{not valid json")

    with patch(
        "graphora.cli.commands.install.get_api_url",
        return_value="http://localhost:8000",
    ), patch(
        "graphora.cli.commands.install.get_auth_token",
        return_value=None,
    ):
        result = runner.invoke(
            app,
            [
                "install",
                "cursor",
                "--workspace",
                str(tmp_path),
                "--force",
            ],
        )

    assert result.exit_code == 0
    written = json.loads(target.read_text())
    assert "graphora" in written["mcpServers"]
