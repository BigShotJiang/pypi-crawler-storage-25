"""Smoke + contract tests for ``graphora explain``.

These exercise three layers, top to bottom:

  * The typer CLI command (via CliRunner) — argument parsing,
    mutex validation, exit codes.
  * The ``GraphoraClient.get_evidence`` composite — node + edge
    dispatch, find_node/find_edge pagination, fail-open
    decision-log read.
  * The HTTP surface — mocked at requests level via unittest.mock
    so no network access is needed.

The graphora-client repo has no pre-existing test scaffold (the
tests/ directory was empty pre-fix). This file seeds it with the
explain coverage and the conventions other commands can follow.
"""

from __future__ import annotations

import json
from typing import Any, Dict, List, Optional
from unittest.mock import MagicMock, patch

import pytest
from typer.testing import CliRunner

from graphora.cli.main import app
from graphora.client import GraphoraClient


def _fake_response(payload: Dict[str, Any], status: int = 200):
    """Build a stand-in for requests.Response that the client's
    _handle_response can chew on."""
    resp = MagicMock()
    resp.status_code = status
    resp.json.return_value = payload
    resp.raise_for_status.return_value = None
    return resp


def _graph_page(
    nodes: Optional[List[Dict[str, Any]]] = None,
    edges: Optional[List[Dict[str, Any]]] = None,
) -> Dict[str, Any]:
    """A minimum-viable GraphResponse-shaped page."""
    return {
        "nodes": nodes or [],
        "edges": edges or [],
        "total_nodes": len(nodes or []),
        "total_edges": len(edges or []),
    }


@pytest.fixture
def runner():
    """Typer's CliRunner. Older typer versions (which graphora-client
    pins via the >=0.9 floor) merged stderr into stdout; newer
    versions added a mix_stderr toggle. Keep the default behavior
    so we don't drift across the supported version range."""
    return CliRunner()


@pytest.fixture
def auth_env(monkeypatch):
    """The GraphoraClient constructor refuses to instantiate
    without a bearer token. Set a fake one so the CLI commands
    can be exercised under test."""
    monkeypatch.setenv("GRAPHORA_AUTH_TOKEN", "test-token")
    monkeypatch.setenv("GRAPHORA_API_URL", "https://test.example/api")


# ============================================================
# CLI mutex + help surface
# ============================================================


def test_explain_help_lists_node_and_edge_options(runner):
    """Pin the discoverable surface: the --help output mentions
    both --node-id and --edge-id with the mutex hint, so a user
    running ``graphora explain --help`` knows the two paths
    exist."""
    result = runner.invoke(app, ["explain", "--help"])
    assert result.exit_code == 0
    out = result.stdout
    assert "--node-id" in out
    assert "--edge-id" in out
    assert "Mutually exclusive" in out


def test_explain_rejects_both_node_id_and_edge_id(runner, auth_env):
    """Mutex pin at the CLI surface. The server returns 400 for the
    same case, but rejecting client-side saves a roundtrip and
    surfaces the failure with a useful message + exit code."""
    result = runner.invoke(
        app, ["explain", "tx1", "--node-id", "n1", "--edge-id", "e1"]
    )
    assert result.exit_code == 2
    assert "exactly one" in result.stdout


def test_explain_rejects_neither_node_id_nor_edge_id(runner, auth_env):
    """Equivalent pin for the empty case — without either id we
    don't know which target the user wants."""
    result = runner.invoke(app, ["explain", "tx1"])
    assert result.exit_code == 2


# ============================================================
# GraphoraClient.get_evidence — node path
# ============================================================


def test_client_get_evidence_node_returns_kind_node_payload(auth_env):
    """End-to-end node path: stub requests.get to return one page
    of the graph then the decisions payload; assert the composite
    builds the expected kind=node shape with source-span filtering."""
    graph_page = _graph_page(
        nodes=[
            {
                "id": "n1",
                "label": "Alice",
                "type": "Person",
                "properties": {
                    "name": "Alice",
                    "source_chunk_id": "chunk-1",
                    "source_text": "Alice joined Acme.",
                    "extra_unrelated_prop": "ignored",
                },
            },
            {"id": "n2", "label": "Acme", "type": "Org", "properties": {}},
        ],
        edges=[
            {"id": "e1", "source": "n1", "target": "n2", "type": "WORKS_AT"},
        ],
    )
    decisions = {
        "decision_log": [
            {
                "id": "d1",
                "transform_id": "tx1",
                "target_id": "n1",
                "target_kind": "node",
                "decision_type": "entity_merged",
                "reason": "merge n1",
                "evidence": {},
                "alternatives": [{"id": "n1-alias"}],
                "created_at": "2026-05-15T00:00:00+00:00",
            }
        ],
        "alternatives": [{"id": "n1-alias"}],
    }

    with patch("graphora.client.requests.get") as mock_get:
        # First call: get_transformed_graph (find_node's pagination).
        # Second call: get_decisions.
        mock_get.side_effect = [
            _fake_response(graph_page),
            _fake_response(decisions),
        ]
        client = GraphoraClient()
        payload = client.get_evidence("tx1", node_id="n1")

    assert payload["kind"] == "node"
    assert payload["node"]["id"] == "n1"
    # Source-span filtering: extra_unrelated_prop is NOT in
    # evidence even though it's on the node's properties bag.
    assert payload["evidence"] == {
        "source_chunk_id": "chunk-1",
        "source_text": "Alice joined Acme.",
    }
    # Incident edges threaded through.
    assert [e["id"] for e in payload["outgoing_edges"]] == ["e1"]
    assert payload["incoming_edges"] == []
    # Decision log + alternatives surface unchanged from the API.
    assert payload["decision_log"] == decisions["decision_log"]
    assert payload["alternatives"] == decisions["alternatives"]


def test_client_get_evidence_node_missing_returns_null_shape(auth_env):
    """When the node isn't found across pagination, the response
    still carries the full kind=node schema with null/empty
    fields. Callers can rely on the keys being present without
    conditional access."""
    with patch("graphora.client.requests.get") as mock_get:
        # Empty page short-circuits find_node's pagination on the
        # first iteration. The decision-log call should NOT fire
        # because the node wasn't found.
        mock_get.return_value = _fake_response(_graph_page())
        client = GraphoraClient()
        payload = client.get_evidence("tx1", node_id="missing")

    assert payload["kind"] == "node"
    assert payload["node"] is None
    assert payload["incoming_edges"] == []
    assert payload["outgoing_edges"] == []
    assert payload["evidence"] == {}
    assert payload["decision_log"] == []
    assert payload["alternatives"] == []


# ============================================================
# GraphoraClient.get_evidence — edge path
# ============================================================


def test_client_get_evidence_edge_returns_kind_edge_payload(auth_env):
    """End-to-end edge path: source-span fields come from the
    EDGE's properties bag (not the source/target nodes). The
    discriminated payload includes source_node and target_node
    summaries pulled from the same graph slice — no extra
    roundtrip."""
    graph_page = _graph_page(
        nodes=[
            {"id": "n1", "label": "Alice", "type": "Person", "properties": {}},
            {"id": "n2", "label": "Acme", "type": "Org", "properties": {}},
        ],
        edges=[
            {
                "id": "e1",
                "source": "n1",
                "target": "n2",
                "type": "WORKS_AT",
                "properties": {
                    "source_chunk_id": "chunk-99",
                    "source_text": "Alice works at Acme.",
                    "extraction_confidence": 0.92,
                    "extra_unrelated_prop": "ignored",
                },
            },
        ],
    )
    decisions = {
        "decision_log": [
            {
                "id": "d1",
                "transform_id": "tx1",
                "target_id": "e1",
                "target_kind": "edge",
                "decision_type": "relationship_accepted",
                "reason": "validator confirmed",
                "evidence": {},
                "alternatives": [],
                "created_at": "2026-05-15T00:00:00+00:00",
            }
        ],
        "alternatives": [],
    }

    with patch("graphora.client.requests.get") as mock_get:
        mock_get.side_effect = [
            _fake_response(graph_page),
            _fake_response(decisions),
        ]
        client = GraphoraClient()
        payload = client.get_evidence("tx1", edge_id="e1")

    assert payload["kind"] == "edge"
    assert payload["edge"]["id"] == "e1"
    # Source/target hydrated from the same slice.
    assert payload["source_node"]["id"] == "n1"
    assert payload["target_node"]["id"] == "n2"
    # Evidence filtered to source-span fields only.
    assert payload["evidence"] == {
        "source_chunk_id": "chunk-99",
        "source_text": "Alice works at Acme.",
        "extraction_confidence": 0.92,
    }
    assert "extra_unrelated_prop" not in payload["evidence"]
    assert payload["decision_log"] == decisions["decision_log"]


def test_client_get_evidence_edge_missing_returns_null_shape(auth_env):
    """Mirror of the missing-node case for edges."""
    with patch("graphora.client.requests.get") as mock_get:
        mock_get.return_value = _fake_response(_graph_page())
        client = GraphoraClient()
        payload = client.get_evidence("tx1", edge_id="missing")

    assert payload["kind"] == "edge"
    assert payload["edge"] is None
    assert payload["source_node"] is None
    assert payload["target_node"] is None
    assert payload["evidence"] == {}
    assert payload["decision_log"] == []


# ============================================================
# GraphoraClient.get_evidence — fail-open decision read
# ============================================================


def test_client_decisions_failure_does_not_blank_evidence(auth_env):
    """Decisions are observability — a transient failure fetching
    them must NOT blank the rest of the evidence response. Pin
    the fail-open contract, mirroring the MCP server's pattern
    (graphora-server commit eb22a79)."""
    graph_page = _graph_page(
        nodes=[
            {
                "id": "n1",
                "label": "Alice",
                "type": "Person",
                "properties": {"source_chunk_id": "chunk-1"},
            },
        ],
    )
    # First call (find_node) returns the graph; second call
    # (get_decisions) raises a network error that the fail-open
    # wrapper should swallow.
    import requests as requests_module

    with patch("graphora.client.requests.get") as mock_get:
        mock_get.side_effect = [
            _fake_response(graph_page),
            requests_module.exceptions.ConnectTimeout("timed out"),
        ]
        client = GraphoraClient()
        payload = client.get_evidence("tx1", node_id="n1")

    # Source-span evidence + node payload intact.
    assert payload["kind"] == "node"
    assert payload["node"]["id"] == "n1"
    assert payload["evidence"]["source_chunk_id"] == "chunk-1"
    # Decision log + alternatives degraded to empty arrays.
    assert payload["decision_log"] == []
    assert payload["alternatives"] == []


# ============================================================
# CLI rendering (JSON mode)
# ============================================================


def test_explain_cli_json_mode_emits_machine_parseable_payload(runner, auth_env):
    """--json flag emits the discriminated payload as JSON so
    callers can pipe to jq / scripts. Pin the contract that the
    raw payload structure makes it through unmodified."""
    graph_page = _graph_page(
        nodes=[
            {
                "id": "n1",
                "label": "Alice",
                "type": "Person",
                "properties": {"source_chunk_id": "chunk-1"},
            },
        ],
    )
    decisions = {"decision_log": [], "alternatives": []}

    with patch("graphora.client.requests.get") as mock_get:
        mock_get.side_effect = [
            _fake_response(graph_page),
            _fake_response(decisions),
        ]
        result = runner.invoke(
            app, ["explain", "tx1", "--node-id", "n1", "--json"]
        )

    assert result.exit_code == 0
    payload = json.loads(result.stdout)
    assert payload["kind"] == "node"
    assert payload["node"]["id"] == "n1"


def test_explain_cli_renders_human_view_with_source_text(runner, auth_env):
    """Default (non-JSON) render surfaces the source_text in the
    Source-text panel, plus the node label in the header. Pin
    the surface so a regression that drops the source-span
    rendering would fail a smoke check."""
    graph_page = _graph_page(
        nodes=[
            {
                "id": "n1",
                "label": "Alice",
                "type": "Person",
                "properties": {
                    "source_chunk_id": "chunk-1",
                    "source_text": "Alice joined Acme in 2019.",
                },
            },
        ],
    )
    decisions = {"decision_log": [], "alternatives": []}

    with patch("graphora.client.requests.get") as mock_get:
        mock_get.side_effect = [
            _fake_response(graph_page),
            _fake_response(decisions),
        ]
        result = runner.invoke(app, ["explain", "tx1", "--node-id", "n1"])

    assert result.exit_code == 0
    # Node label visible in the panel header.
    assert "Alice" in result.stdout
    # Source text rendered in the body.
    assert "Alice joined Acme in 2019." in result.stdout


# ============================================================
# Credential resolution (reviewer-flagged P2 on commit 68ae817)
#
# The previous version of explain only checked typer's option +
# envvar pair, bypassing the persisted ~/.graphora/config.yaml
# that the other remote commands honor. Users who ran
# `graphora config init --mode remote` saw their config picked
# up by `graphora extract` but NOT by `graphora explain`. These
# tests pin the resolution chain: explicit option > env var >
# config file, with a friendly diagnostic when all three miss.
# ============================================================


def test_explain_uses_config_helpers_when_env_unset(
    runner, monkeypatch
):
    """Pin the persisted-config fallback. With env vars cleared,
    patching get_api_url / get_auth_token (which themselves read
    from ~/.graphora/config.yaml) must be enough for `graphora
    explain` to authenticate."""
    monkeypatch.delenv("GRAPHORA_API_URL", raising=False)
    monkeypatch.delenv("GRAPHORA_AUTH_TOKEN", raising=False)

    graph_page = _graph_page(
        nodes=[{"id": "n1", "label": "Alice", "type": "Person", "properties": {}}],
    )
    decisions = {"decision_log": [], "alternatives": []}

    # Patch the config helpers to mimic a populated config.yaml.
    # Note: the imports inside explain.py are module-level, so we
    # patch the names as bound in that module (not in cli.config).
    with patch(
        "graphora.cli.commands.explain.get_api_url",
        return_value="https://test.example/api",
    ), patch(
        "graphora.cli.commands.explain.get_auth_token",
        return_value="config-token",
    ), patch(
        "graphora.cli.commands.explain.validate_remote_environment",
        return_value=True,
    ), patch("graphora.client.requests.get") as mock_get:
        mock_get.side_effect = [
            _fake_response(graph_page),
            _fake_response(decisions),
        ]
        result = runner.invoke(
            app, ["explain", "tx1", "--node-id", "n1", "--json"]
        )

    assert result.exit_code == 0, (
        f"explain failed with config-only credentials. Pre-fix it "
        f"required env vars even when ~/.graphora/config.yaml had "
        f"api.url + api.auth_token. stdout={result.stdout!r}, "
        f"stderr={getattr(result, 'stderr', '')!r}"
    )
    payload = json.loads(result.stdout)
    assert payload["kind"] == "node"


def test_explain_cli_flag_overrides_config(runner, monkeypatch):
    """--api-url and --auth-token override BOTH env vars and the
    persisted config. Pin so a refactor that drops the explicit-
    flag short-circuit doesn't silently fall back to config when
    the user meant to target a different deployment."""
    monkeypatch.delenv("GRAPHORA_API_URL", raising=False)
    monkeypatch.delenv("GRAPHORA_AUTH_TOKEN", raising=False)

    graph_page = _graph_page(
        nodes=[{"id": "n1", "label": "Alice", "type": "Person", "properties": {}}],
    )
    decisions = {"decision_log": [], "alternatives": []}

    captured_urls = []

    def capture_get(url, **kwargs):
        captured_urls.append(url)
        # Return the graph page first, decisions second.
        return _fake_response(
            graph_page if "decisions" not in url else decisions
        )

    # Config returns OLD values; flags should override.
    with patch(
        "graphora.cli.commands.explain.get_api_url",
        return_value="https://OLD.example/api",
    ), patch(
        "graphora.cli.commands.explain.get_auth_token",
        return_value="OLD-token",
    ), patch(
        "graphora.cli.commands.explain.validate_remote_environment",
        return_value=True,
    ), patch(
        "graphora.client.requests.get", side_effect=capture_get
    ):
        result = runner.invoke(
            app,
            [
                "explain",
                "tx1",
                "--node-id",
                "n1",
                "--api-url",
                "https://NEW.example/api",
                "--auth-token",
                "new-token",
                "--json",
            ],
        )

    assert result.exit_code == 0
    # The HTTP calls must go to the NEW URL, not the config one.
    assert all("NEW.example" in url for url in captured_urls), (
        f"CLI flag didn't override config URL. URLs hit: {captured_urls}"
    )


def test_explain_friendly_error_when_no_credentials(runner, monkeypatch):
    """When neither flags, env vars, nor config provide credentials,
    surface the same 'run config init' message that extract shows
    — not the raw 'A Clerk bearer token is required' ValueError.
    UX pin: a config-mistake user should see how to fix it, not
    an internal client error."""
    monkeypatch.delenv("GRAPHORA_API_URL", raising=False)
    monkeypatch.delenv("GRAPHORA_AUTH_TOKEN", raising=False)

    with patch(
        "graphora.cli.commands.explain.get_api_url", return_value=None
    ), patch(
        "graphora.cli.commands.explain.get_auth_token", return_value=None
    ), patch(
        "graphora.cli.commands.explain.validate_remote_environment",
        return_value=False,
    ), patch(
        "graphora.cli.commands.explain.get_missing_config",
        return_value=["api.url", "api.auth_token"],
    ):
        result = runner.invoke(app, ["explain", "tx1", "--node-id", "n1"])

    assert result.exit_code == 2
    out = result.stdout
    assert "Missing required configuration" in out
    assert "graphora config init" in out
