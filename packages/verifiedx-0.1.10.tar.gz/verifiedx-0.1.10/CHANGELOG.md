# Changelog

## 0.1.10 - 2026-04-23

- Added the public one-shot install path for Python repos so VerifiedX can land additively at the native seam, lower seam, or raw runtime with smoke verification.
- Expanded installer support across LangGraph, LangChain, OpenAI Agents, Claude Agent SDK, OpenAI direct, Anthropic direct, MCP, and bare Python harnesses.
- Tightened repo-aware capture vs trigger binding so harmless helpers remain capture-only while true high-impact mutations are preflighted at the action boundary.

## 0.1.2 - 2026-04-09

- Added the newer core verification workflow and tightened V4 runtime capture, loopback, and receipt behavior across the raw Python lane.
- Upgraded standalone Python MCP wrappers so high-impact MCP tool handlers preflight protected actions and return the normal blocked loopback shape.
- Hardened Python client error handling, runtime config behavior, and zero-touch capture paths after the initial 0.1.1 release.

## 0.1.1 - 2026-04-05

- Stabilized raw Python runtime capture, chronological `tool_calls_in_run`, and lower-seam fallback coverage.
- Added first-class adapters for OpenAI direct, OpenAI Agents, Anthropic direct, Claude Agent SDK, LangGraph, and MCP.
- Hardened release packaging so the published wheel/sdist ship the SDK code and runtime shim assets without test or fixture baggage.
