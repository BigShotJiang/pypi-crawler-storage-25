"""
WSDL coverage utilities for Direct CLI.

Fetches and parses Yandex Direct API v5 WSDL definitions to verify
that the CLI implements all available services and methods.
"""

from __future__ import annotations

import xml.etree.ElementTree as ET
from functools import lru_cache
from io import StringIO
from pathlib import Path

WSDL_BASE_URL = "https://api.direct.yandex.com/v5/{service}?wsdl"
# Imported XSD schemas are served from a different host than the WSDL
# endpoints. If Yandex changes either domain, refresh_all_caches() and
# scripts/check_wsdl_drift.py would silently break — keep these as named
# constants so the failure surface is grep-able.
XSD_BASE_URL = "https://soap.direct.yandex.ru/v5/{filename}"
CACHE_DIR = Path(__file__).resolve().parent.parent / "tests" / "wsdl_cache"
IMPORTS_CACHE_DIR = CACHE_DIR / "imports"
XSD_NS = {"xsd": "http://www.w3.org/2001/XMLSchema"}

IMPORTED_XSD_REGISTRY = {
    "http://api.direct.yandex.com/v5/adextensiontypes": "adextensiontypes.xsd",
    "http://api.direct.yandex.com/v5/general": "general.xsd",
    "http://api.direct.yandex.com/v5/generalclients": "generalclients.xsd",
}

# ---------------------------------------------------------------------------
# Mappings
# ---------------------------------------------------------------------------

CLI_TO_API_SERVICE = {
    "campaigns": "campaigns",
    "adgroups": "adgroups",
    "ads": "ads",
    "keywords": "keywords",
    "keywordbids": "keywordbids",
    "bids": "bids",
    "bidmodifiers": "bidmodifiers",
    "audiencetargets": "audiencetargets",
    "retargeting": "retargetinglists",
    "creatives": "creatives",
    "adimages": "adimages",
    "advideos": "advideos",
    "adextensions": "adextensions",
    "sitelinks": "sitelinks",
    "vcards": "vcards",
    "leads": "leads",
    "clients": "clients",
    "agencyclients": "agencyclients",
    "dictionaries": "dictionaries",
    "changes": "changes",
    "turbopages": "turbopages",
    "negativekeywordsharedsets": "negativekeywordsharedsets",
    "feeds": "feeds",
    "smartadtargets": "smartadtargets",
    "businesses": "businesses",
    "keywordsresearch": "keywordsresearch",
    "dynamicads": "dynamictextadtargets",
    "dynamicfeedadtargets": "dynamicfeedadtargets",
    "strategies": "strategies",
    # reports excluded — uses JSON API, not WSDL
}

NON_WSDL_SERVICES = {"reports"}

# Non-WSDL service coverage policies. These services still belong to the
# supported API surface, but they require bespoke contract checks rather than
# SOAP/WSDL parity tests.
NON_WSDL_SERVICE_POLICIES = {
    "reports": {
        "kind": "json-api",
        "coverage": "contract-tests+spec-snapshot",
        "spec_snapshot": "tests/reports_cache/spec.json",
        "raw_sources": "tests/reports_cache/raw/",
        "drift_script": "scripts/check_reports_drift.py",
        "refresh_script": "scripts/refresh_reports_cache.py",
        "reason": (
            "Yandex Direct reports use the JSON reporting API. "
            "Coverage mirrors WSDL parity via HTML-doc spec snapshot."
        ),
    }
}

CANONICAL_API_SERVICES = sorted(
    [
        "adextensions",
        "adgroups",
        "adimages",
        "ads",
        "advideos",
        "agencyclients",
        "audiencetargets",
        "bids",
        "bidmodifiers",
        "businesses",
        "campaigns",
        "changes",
        "clients",
        "creatives",
        "dictionaries",
        "dynamicfeedadtargets",
        "dynamictextadtargets",
        "feeds",
        "keywordbids",
        "keywords",
        "keywordsresearch",
        "leads",
        "negativekeywordsharedsets",
        "retargetinglists",
        "sitelinks",
        "smartadtargets",
        "strategies",
        "turbopages",
        "vcards",
    ]
)

# Explicit live-discovery surface used to catch services omitted from the
# declared canonical coverage model. Keep this list conservative and sourced
# from live WSDL/API reference audits so CI does not depend on brittle doc
# navigation scraping.
LIVE_DISCOVERED_API_SERVICES = sorted(set(CANONICAL_API_SERVICES))

KNOWN_MISSING_SERVICES = set()

# Intentional CLI-only methods that are not 1:1 SOAP WSDL operations.
# They remain part of the supported CLI UX and must be documented explicitly.
INTENTIONAL_EXTRA_METHODS = {
    ("agencyclients", "delete"): (
        "CLI guard command: the Yandex Direct API does not support deleting "
        "agency clients, so the command aborts with an explicit message."
    ),
}

RUNTIME_DEPRECATED_METHODS = {
    ("agencyclients", "add"): {
        "error_code": 3500,
        "replacement": "direct agencyclients add-passport-organization",
        "reason": (
            "Yandex rejects agencyclients.add at runtime; use passport "
            "organization creation instead."
        ),
    },
}

METHOD_NAME_OVERRIDES = {
    "add-passport-organization": "addPassportOrganization",
    "add-passport-organization-member": "addPassportOrganizationMember",
    "check-campaigns": "checkCampaigns",
    "check-dictionaries": "checkDictionaries",
    "get-geo-regions": "getGeoRegions",
    "has-search-volume": "hasSearchVolume",
    "list-names": "get",
    "list-types": "get",
    "set-auto": "setAuto",
    "set-bids": "setBids",
}


def fetch_wsdl(service_name: str, use_cache: bool = True) -> str:
    """Fetch WSDL XML for a service."""
    cache_file = CACHE_DIR / f"{service_name}.xml"

    if use_cache and cache_file.exists():
        return cache_file.read_text(encoding="utf-8")

    import requests

    url = WSDL_BASE_URL.format(service=service_name)
    resp = requests.get(url, timeout=30)
    resp.raise_for_status()

    xml_text = resp.text

    CACHE_DIR.mkdir(parents=True, exist_ok=True)
    cache_file.write_text(xml_text, encoding="utf-8")

    return xml_text


def fetch_live_wsdl(service_name: str) -> str:
    """Fetch live WSDL XML without reading or writing the local cache."""
    import requests

    url = WSDL_BASE_URL.format(service=service_name)
    resp = requests.get(url, timeout=30)
    resp.raise_for_status()
    return resp.text


def parse_wsdl_operations(wsdl_xml: str) -> list:
    """Extract unique API method names from WSDL XML."""
    root = ET.fromstring(wsdl_xml)
    ns = {"wsdl": "http://schemas.xmlsoap.org/wsdl/"}
    ops = set()
    for op in root.findall(".//wsdl:operation", ns):
        name = op.get("name")
        if name:
            ops.add(name)
    return sorted(ops)


def parse_wsdl_field_enums(wsdl_xml: str) -> dict[str, list[str]]:
    """Return WSDL ``*FieldEnum`` simpleType values keyed by enum type name."""
    ns = XSD_NS
    enums = {}

    for context in _load_schema_contexts(wsdl_xml).values():
        for simple_type in context["schema"].findall("xsd:simpleType", ns):
            type_name = simple_type.get("name")
            if not type_name or not type_name.endswith("FieldEnum"):
                continue

            values = [
                enum.get("value")
                for enum in simple_type.findall(".//xsd:enumeration", ns)
                if enum.get("value")
            ]
            enums[type_name] = values

    return enums


def get_operation_field_name_enums(
    wsdl_xml: str, operation_name: str
) -> dict[str, dict[str, object]]:
    """Return request ``FieldNames`` params and their allowed enum values."""
    field_enums = parse_wsdl_field_enums(wsdl_xml)
    schema = get_operation_request_schema(wsdl_xml, operation_name)
    result = {}

    for field in schema["fields"]:
        name = field["name"]
        type_name = field["type"]
        if not name or not type_name:
            continue
        if name != "FieldNames" and not name.endswith("FieldNames"):
            continue
        if type_name not in field_enums:
            continue
        result[name] = {
            "enum_type": type_name,
            "values": field_enums[type_name],
        }

    return result


def get_cli_methods_for_service(cli_command_name: str) -> set:
    """Get the set of API method names that a CLI service implements."""
    from direct_cli.cli import cli

    group = cli.commands[cli_command_name]
    methods = set()
    for subcmd_name in group.commands:
        mapped = METHOD_NAME_OVERRIDES.get(subcmd_name)
        if mapped:
            methods.add(mapped)
        else:
            methods.add(subcmd_name)
    return methods


def refresh_all_caches() -> dict:
    """Fetch fresh WSDLs and imported XSDs for all known services."""
    all_services = set(CANONICAL_API_SERVICES) | set(CLI_TO_API_SERVICE.values())
    all_services -= NON_WSDL_SERVICES

    errors = {}
    for service in sorted(all_services):
        try:
            fetch_wsdl(service, use_cache=False)
        except Exception as exc:
            errors[service] = exc

    for namespace in sorted(IMPORTED_XSD_REGISTRY):
        try:
            fetch_imported_xsd(namespace, use_cache=False)
        except Exception as exc:
            errors[f"xsd:{namespace}"] = exc
    return errors


def get_api_coverage_policy() -> dict:
    """Return a machine-readable summary of the API coverage model."""
    return {
        "wsdl_base_url": WSDL_BASE_URL,
        "wsdl_services": dict(sorted(CLI_TO_API_SERVICE.items())),
        "canonical_api_services": list(CANONICAL_API_SERVICES),
        "live_discovered_api_services": list(LIVE_DISCOVERED_API_SERVICES),
        "non_wsdl_services": NON_WSDL_SERVICE_POLICIES,
        "intentional_extra_methods": {
            f"{service}.{method}": reason
            for (service, method), reason in sorted(INTENTIONAL_EXTRA_METHODS.items())
        },
        "runtime_deprecated_methods": {
            f"{service}.{method}": policy
            for (service, method), policy in sorted(RUNTIME_DEPRECATED_METHODS.items())
        },
    }


def _local_name(qname: str | None) -> str | None:
    """Return the local part of a QName-like ``prefix:name`` string."""
    if qname is None:
        return None
    return qname.split(":", 1)[1] if ":" in qname else qname


def _namespace_prefixes(xml_text: str) -> dict[str, str]:
    """Return namespace URI by XML prefix for an XML document."""
    prefixes: dict[str, str] = {}
    for _, item in ET.iterparse(StringIO(xml_text), events=("start-ns",)):
        prefix, namespace = item
        prefixes[prefix or ""] = namespace
    return prefixes


def _qname_parts(
    qname: str | None, prefixes: dict[str, str], default_ns: str
) -> tuple[str, str] | None:
    """Resolve a QName-like string to ``(namespace, local_name)``."""
    if qname is None:
        return None
    if qname.startswith("{"):
        namespace, _, local = qname[1:].partition("}")
        return namespace, local
    if ":" in qname:
        prefix, local = qname.split(":", 1)
        return prefixes.get(prefix, ""), local
    return default_ns, qname


def fetch_imported_xsd(namespace: str, use_cache: bool = True) -> str:
    """Fetch an imported XSD by namespace using the checked-in cache."""
    filename = IMPORTED_XSD_REGISTRY.get(namespace)
    if filename is None:
        raise KeyError(f"Unsupported imported XSD namespace: {namespace}")

    cache_file = IMPORTS_CACHE_DIR / filename
    if use_cache and cache_file.exists():
        return cache_file.read_text(encoding="utf-8")

    import requests

    url = XSD_BASE_URL.format(filename=filename)
    resp = requests.get(url, timeout=30)
    resp.raise_for_status()
    xml_text = resp.text

    IMPORTS_CACHE_DIR.mkdir(parents=True, exist_ok=True)
    cache_file.write_text(xml_text, encoding="utf-8")
    return xml_text


@lru_cache(maxsize=None)
def _cached_imported_xsd(namespace: str) -> str:
    """Return cached imported XSD XML for namespace."""
    return fetch_imported_xsd(namespace, use_cache=True)


def _load_schema_contexts(wsdl_xml: str) -> dict[str, dict]:
    """Load local and registered imported XSD schemas keyed by namespace."""
    ns = XSD_NS
    root, prefixes = _parse_xml(wsdl_xml)
    local_schema = root.find(".//xsd:schema", ns)
    if local_schema is None:
        raise ValueError("WSDL schema section not found")

    contexts = {}

    def add_schema(xml_text: str | None, schema_elem: ET.Element | None = None):
        if schema_elem is None:
            schema_root, schema_prefixes = _parse_xml(xml_text or "")
        else:
            schema_root = schema_elem
            schema_prefixes = prefixes
        target_ns = schema_root.get("targetNamespace", "")
        if target_ns in contexts:
            return
        contexts[target_ns] = {
            "schema": schema_root,
            "prefixes": schema_prefixes,
            "complex_types": {
                ctype.get("name"): ctype
                for ctype in schema_root.findall("xsd:complexType", ns)
            },
        }
        for import_elem in schema_root.findall("xsd:import", ns):
            import_ns = import_elem.get("namespace")
            if import_ns in IMPORTED_XSD_REGISTRY and import_ns not in contexts:
                add_schema(_cached_imported_xsd(import_ns))

    add_schema(None, local_schema)
    return contexts


def _parse_xml(xml_text: str) -> tuple[ET.Element, dict[str, str]]:
    """Parse XML and keep prefix-to-namespace declarations."""
    return ET.fromstring(xml_text), _namespace_prefixes(xml_text)


def _element_field(
    child: ET.Element,
    prefixes: dict[str, str],
    default_ns: str,
    contexts: dict[str, dict],
) -> dict:
    """Return schema metadata for an XSD element."""
    type_ref = _qname_parts(child.get("type"), prefixes, default_ns)
    type_namespace, type_name = type_ref if type_ref else (default_ns, None)
    return {
        "name": child.get("name"),
        "type": type_name,
        "type_namespace": type_namespace,
        "min_occurs": int(child.get("minOccurs", "1")),
        "max_occurs": child.get("maxOccurs", "1"),
        "item_fields": _collect_complex_type_fields(
            contexts, type_namespace, type_name
        ),
    }


def _collect_complex_type_fields(
    contexts: dict[str, dict],
    type_namespace: str | None,
    type_name: str | None,
    seen: frozenset[tuple[str, str]] = frozenset(),
) -> list[dict]:
    """Collect fields from local/imported XSD complex types, following inheritance."""
    if not type_namespace or not type_name:
        return []
    key = (type_namespace, type_name)
    if key in seen:
        return []
    context = contexts.get(type_namespace)
    if context is None:
        return []
    complex_type = context["complex_types"].get(type_name)
    if complex_type is None:
        return []

    prefixes = context["prefixes"]
    fields = []
    extension = complex_type.find("xsd:complexContent/xsd:extension", XSD_NS)
    if extension is not None:
        base_ref = _qname_parts(extension.get("base"), prefixes, type_namespace)
        if base_ref:
            fields.extend(
                _collect_complex_type_fields(
                    contexts, base_ref[0], base_ref[1], seen | {key}
                )
            )
        sequence = extension.find("xsd:sequence", XSD_NS)
    else:
        sequence = complex_type.find("xsd:sequence", XSD_NS)

    if sequence is None:
        return fields

    for child in sequence.findall("xsd:element", XSD_NS):
        fields.append(_element_field(child, prefixes, type_namespace, contexts))
    return fields


def get_operation_request_schema(wsdl_xml: str, operation_name: str) -> dict:
    """Return request schema metadata for a WSDL operation.

    Imported XSDs registered in ``IMPORTED_XSD_REGISTRY`` are resolved from the
    checked-in cache, and ``xsd:extension`` base fields are included.
    """
    root, prefixes = _parse_xml(wsdl_xml)
    ns = {
        "wsdl": "http://schemas.xmlsoap.org/wsdl/",
        "xsd": "http://www.w3.org/2001/XMLSchema",
    }

    schema = root.find(".//xsd:schema", ns)
    if schema is None:
        raise ValueError("WSDL schema section not found")

    messages = {}
    for message in root.findall(".//wsdl:message", ns):
        part = message.find("wsdl:part", ns)
        if part is not None:
            messages[message.get("name")] = _local_name(part.get("element"))

    operation = None
    for op in root.findall(".//wsdl:portType/wsdl:operation", ns):
        if op.get("name") == operation_name:
            operation = op
            break
    if operation is None:
        raise KeyError(f"Operation not found in WSDL: {operation_name}")

    input_ref = operation.find("wsdl:input", ns)
    if input_ref is None:
        raise ValueError(f"Operation has no input message: {operation_name}")

    message_name = _local_name(input_ref.get("message"))
    element_name = messages.get(message_name)
    if element_name is None:
        raise KeyError(f"Input element not found for operation: {operation_name}")

    elements = {elem.get("name"): elem for elem in schema.findall("xsd:element", ns)}
    target_ns = schema.get("targetNamespace", "")
    contexts = _load_schema_contexts(wsdl_xml)

    element = elements.get(element_name)
    if element is None:
        raise KeyError(f"Input element schema not found: {element_name}")

    complex_type = element.find("xsd:complexType", ns)
    if complex_type is None:
        raise ValueError(f"Input element has no inline complex type: {element_name}")

    extension = complex_type.find("xsd:complexContent/xsd:extension", ns)
    sequence = (
        extension.find("xsd:sequence", ns)
        if extension is not None
        else complex_type.find("xsd:sequence", ns)
    )

    fields = []
    if sequence is not None:
        for child in sequence.findall("xsd:element", ns):
            fields.append(_element_field(child, prefixes, target_ns, contexts))

    return {"input_element": element_name, "fields": fields}


def find_nested_schema_violations(
    body: dict, schema: dict, *, path: str = "params"
) -> list[str]:
    """Return dotted paths of body keys not declared in the WSDL schema.

    Walks the request body alongside ``schema["fields"]`` and recursively
    checks list items / nested objects for unknown keys. Only flags fields
    where the schema actually declares ``item_fields`` — fields whose nested
    type cannot be resolved (no item_fields in schema) are skipped, because
    we cannot tell which nested keys would be valid.
    """
    params = body.get("params", body)
    if not isinstance(params, dict):
        return []

    expected = {field["name"]: field for field in schema.get("fields", [])}
    violations: list[str] = []
    for key, value in params.items():
        if key not in expected:
            violations.append(f"{path}.{key}")
            continue
        item_fields = expected[key].get("item_fields") or []
        if not item_fields:
            continue
        nested_schema = {"fields": item_fields}
        # The recursive call walks the same expected/unknown logic against
        # ``nested_schema`` for each child, so we delegate unknown-key
        # detection to it instead of inlining a parallel loop here. Inlining
        # would double-report any unknown direct child.
        if isinstance(value, list):
            for index, entry in enumerate(value):
                if isinstance(entry, dict):
                    violations.extend(
                        find_nested_schema_violations(
                            {"params": entry},
                            nested_schema,
                            path=f"{path}.{key}[{index}]",
                        )
                    )
        elif isinstance(value, dict):
            violations.extend(
                find_nested_schema_violations(
                    {"params": value}, nested_schema, path=f"{path}.{key}"
                )
            )
    return violations
