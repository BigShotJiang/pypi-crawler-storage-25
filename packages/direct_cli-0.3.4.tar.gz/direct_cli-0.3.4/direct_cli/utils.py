"""
Utilities for Direct CLI
"""

import base64
import json
from datetime import datetime
from typing import Any, Dict, Iterable, List, Optional, Union

import click

from direct_cli._vendor.tapi_yandex_direct.resource_mapping import (
    RESOURCE_MAPPING_V5,
)


def parse_ids(ids_str: Optional[str]) -> Optional[List[int]]:
    """Parse comma-separated IDs"""
    if not ids_str:
        return None
    result = []
    for x in ids_str.split(","):
        x = x.strip()
        try:
            result.append(int(x))
        except ValueError:
            raise ValueError(f"Invalid ID: '{x}'. IDs must be integers.")
    return result


def parse_json(json_str: Optional[str]) -> Optional[Dict[str, Any]]:
    """Parse JSON string"""
    if not json_str:
        return None
    try:
        return json.loads(json_str)
    except json.JSONDecodeError as e:
        raise ValueError(f"Invalid JSON: {e}")


def assert_not_runtime_deprecated(cli_group: str, method: str) -> None:
    """Raise a stable usage error for methods known to fail at API runtime."""
    from direct_cli.wsdl_coverage import RUNTIME_DEPRECATED_METHODS

    policy = RUNTIME_DEPRECATED_METHODS.get((cli_group, method))
    if not policy:
        return

    message = (
        f"direct {cli_group} {method} is deprecated by the Yandex Direct API "
        f"and fails at runtime with error_code={policy['error_code']}. "
        f"Use {policy['replacement']}."
    )
    raise click.UsageError(message)


def parse_csv_strings(value: Optional[str]) -> Optional[List[str]]:
    """Parse comma-separated strings, trimming whitespace."""
    if not value:
        return None

    items = [item.strip() for item in value.split(",")]
    result = [item for item in items if item]
    return result or None


def parse_csv_upper(value: Optional[str]) -> Optional[List[str]]:
    """Parse comma-separated enum-like strings and uppercase each item."""
    parsed = parse_csv_strings(value)
    return [item.upper() for item in parsed] if parsed else None


def add_criteria_csv(
    criteria: Dict[str, Any],
    key: str,
    value: Optional[str],
    *,
    integers: bool = False,
    upper: bool = False,
) -> None:
    """Add a comma-separated CLI value to a SelectionCriteria dict."""
    if not value:
        return
    if integers:
        criteria[key] = parse_ids(value)
        return
    parsed = parse_csv_upper(value) if upper else parse_csv_strings(value)
    if parsed:
        criteria[key] = parsed


def build_selection_criteria(
    ids: Optional[List[int]] = None,
    status: Optional[str] = None,
    types: Optional[str] = None,
) -> Optional[Dict[str, Any]]:
    """Build SelectionCriteria from parameters"""
    criteria = {}

    if ids:
        criteria["Ids"] = ids
    if status:
        criteria["Statuses"] = [status]
    if types:
        criteria["Types"] = types.split(",")

    return criteria if criteria else None


def build_common_params(
    criteria: Optional[Dict[str, Any]] = None,
    field_names: Optional[List[str]] = None,
    limit: Optional[int] = None,
) -> Dict[str, Any]:
    """Build common params for get requests"""
    params = {}

    if criteria:
        params["SelectionCriteria"] = criteria
    if field_names:
        params["FieldNames"] = field_names
    if limit:
        params["Page"] = {"Limit": limit}

    return params


def parse_date(date_str: str) -> str:
    """Parse and validate date string"""
    try:
        datetime.strptime(date_str, "%Y-%m-%d")
        return date_str
    except ValueError:
        raise ValueError(f"Invalid date format: {date_str}. Expected: YYYY-MM-DD")


def parse_datetime(datetime_str: str) -> str:
    """Parse canonical CLI datetime and normalize it for the API."""
    try:
        datetime.strptime(datetime_str, "%Y-%m-%dT%H:%M:%S")
        return f"{datetime_str}Z"
    except ValueError:
        raise ValueError(
            "Invalid datetime format: " f"{datetime_str}. Expected: YYYY-MM-DDTHH:MM:SS"
        )


MICRO_RUBLE_MIN = 100_000  # 0.1 RUB — below this is almost certainly a mistake


class MicroRublesParamType(click.ParamType):
    """Click type that validates bid/budget values are in micro-rubles."""

    name = "MICRO_RUBLES"

    def convert(self, value, param, ctx):
        try:
            val = int(value)
        except (ValueError, TypeError):
            self.fail(f"Expected integer (micro-rubles), got '{value}'")
            return  # unreachable; satisfies type checkers
        if val < 0:
            self.fail(f"Bid must be non-negative, got {val}")
        if 0 < val < MICRO_RUBLE_MIN:
            self.fail(
                f"{val} seems too low for micro-rubles "
                f"(min {MICRO_RUBLE_MIN} = 0.1 RUB). "
                f"Did you mean {val * 1_000_000}?"
            )
        return val


MICRO_RUBLES = MicroRublesParamType()


def load_base64_file(file_path: str) -> str:
    """Read a file and return its base64-encoded contents."""
    with open(file_path, "rb") as file_obj:
        return base64.b64encode(file_obj.read()).decode("ascii")


def parse_setting_specs(specs: Optional[List[str]]) -> Optional[List[Dict[str, str]]]:
    """Parse repeated OPTION=VALUE campaign setting specs."""
    if not specs:
        return None

    settings = []
    for spec in specs:
        option, separator, value = spec.partition("=")
        if not separator:
            raise ValueError(
                f"Invalid setting: '{spec}'. Expected format: OPTION=VALUE"
            )
        settings.append({"Option": option.strip(), "Value": value.strip()})
    return settings


EMAIL_SUBSCRIPTION_OPTIONS = {
    "RECEIVE_RECOMMENDATIONS",
    "TRACK_MANAGED_CAMPAIGNS",
    "TRACK_POSITION_CHANGES",
}

CLIENT_SETTING_OPTIONS = {
    "CORRECT_TYPOS_AUTOMATICALLY",
    "DISPLAY_STORE_RATING",
}

AGENCY_CLIENT_GRANT_OPTIONS = {
    "EDIT_CAMPAIGNS",
    "IMPORT_XLS",
    "TRANSFER_MONEY",
}

TIN_TYPES = {
    "PHYSICAL",
    "FOREIGN_PHYSICAL",
    "LEGAL",
    "FOREIGN_LEGAL",
    "INDIVIDUAL",
}

YES_NO_VALUES = {"YES", "NO"}


def parse_yes_no_spec(
    spec: str,
    allowed_options: Iterable[str],
    label: str,
) -> Dict[str, str]:
    """Parse and validate one OPTION=YES|NO update spec."""
    option, separator, value = spec.partition("=")
    if not separator:
        raise click.UsageError(
            f"Invalid {label}: '{spec}'. Expected format: OPTION=YES|NO"
        )

    option = option.strip()
    value = value.strip()
    allowed_options = set(allowed_options)
    if option not in allowed_options:
        allowed = ", ".join(sorted(allowed_options))
        raise click.UsageError(
            f"Invalid {label} option: '{option}'. Expected one of: {allowed}"
        )
    if value not in YES_NO_VALUES:
        raise click.UsageError(f"Invalid {label} value: '{value}'. Expected YES or NO")

    return {"Option": option, "Value": value}


def parse_email_subscription_specs(
    specs: Optional[List[str]],
) -> Optional[List[Dict[str, str]]]:
    """Parse repeated Notification.EmailSubscriptions OPTION=YES|NO specs."""
    if not specs:
        return None
    return [
        parse_yes_no_spec(spec, EMAIL_SUBSCRIPTION_OPTIONS, "email subscription")
        for spec in specs
    ]


def parse_client_setting_specs(
    specs: Optional[List[str]],
) -> Optional[List[Dict[str, str]]]:
    """Parse repeated client Settings OPTION=YES|NO specs."""
    if not specs:
        return None
    return [
        parse_yes_no_spec(spec, CLIENT_SETTING_OPTIONS, "client setting")
        for spec in specs
    ]


def parse_grant_specs(specs: Optional[List[str]]) -> Optional[List[Dict[str, str]]]:
    """Parse repeated agency client Grants PRIVILEGE=YES|NO specs."""
    if not specs:
        return None
    grants = []
    for spec in specs:
        parsed = parse_yes_no_spec(spec, AGENCY_CLIENT_GRANT_OPTIONS, "grant")
        grants.append({"Privilege": parsed["Option"], "Value": parsed["Value"]})
    return grants


def parse_tin_info(
    tin_type: Optional[str],
    tin: Optional[str],
) -> Optional[Dict[str, str]]:
    """Build TinInfo from typed flags."""
    tin_info = {}
    if tin_type:
        if tin_type not in TIN_TYPES:
            allowed = ", ".join(sorted(TIN_TYPES))
            raise click.UsageError(
                f"Invalid tin type: '{tin_type}'. Expected one of: {allowed}"
            )
        tin_info["TinType"] = tin_type
    if tin:
        tin_info["Tin"] = tin
    return tin_info or None


def build_notification_update(
    email: Optional[str],
    lang: Optional[str],
    email_subscriptions: Optional[List[Dict[str, str]]],
) -> Optional[Dict[str, Any]]:
    """Build Notification update object from typed flags."""
    notification = {}
    if email:
        notification["Email"] = email
    if lang:
        notification["Lang"] = lang
    if email_subscriptions:
        notification["EmailSubscriptions"] = email_subscriptions
    return notification or None


def build_client_update_item(
    client_info: Optional[str],
    phone: Optional[str],
    notification: Optional[Dict[str, Any]],
    settings: Optional[List[Dict[str, str]]],
    tin_info: Optional[Dict[str, str]],
) -> Dict[str, Any]:
    """Build a generalclients ClientUpdateItem with WSDL-valid keys only."""
    item = {}
    if client_info:
        item["ClientInfo"] = client_info
    if phone:
        item["Phone"] = phone
    if notification:
        item["Notification"] = notification
    if settings:
        item["Settings"] = settings
    if tin_info:
        item["TinInfo"] = tin_info
    return item


def parse_condition_specs(specs: Optional[List[str]]) -> Optional[List[Dict[str, Any]]]:
    """Parse repeated OPERAND:OPERATOR:ARG1|ARG2 condition specs."""
    if not specs:
        return None

    conditions = []
    for spec in specs:
        parts = spec.split(":", 2)
        if len(parts) != 3:
            raise ValueError(
                "Invalid condition: "
                f"'{spec}'. Expected format: OPERAND:OPERATOR:ARG1|ARG2"
            )

        operand, operator, arguments = [part.strip() for part in parts]
        parsed_arguments = [arg.strip() for arg in arguments.split("|") if arg.strip()]
        if not parsed_arguments:
            raise ValueError(
                f"Invalid condition: '{spec}'. Provide at least one argument."
            )

        conditions.append(
            {
                "Operand": operand,
                "Operator": operator,
                "Arguments": parsed_arguments,
            }
        )
    return conditions


def parse_retargeting_rule_specs(
    specs: Optional[List[str]],
) -> Optional[List[Dict[str, Any]]]:
    """Parse repeated OPERATOR:EXTERNAL_ID[:LIFESPAN][|...] rule specs."""
    if not specs:
        return None

    rules = []
    for spec in specs:
        operator, separator, arguments_spec = spec.partition(":")
        if not separator:
            raise ValueError(
                "Invalid rule: "
                f"'{spec}'. Expected format: OPERATOR:EXTERNAL_ID[:LIFESPAN][|...]"
            )

        arguments = []
        for argument_spec in arguments_spec.split("|"):
            parts = [part.strip() for part in argument_spec.split(":") if part.strip()]
            if not parts:
                continue
            if len(parts) > 2:
                raise ValueError(
                    "Invalid rule argument: "
                    f"'{argument_spec}'. Expected EXTERNAL_ID[:LIFESPAN]"
                )

            argument = {"ExternalId": int(parts[0])}
            if len(parts) == 2:
                argument["MembershipLifeSpan"] = int(parts[1])
            arguments.append(argument)

        if not arguments:
            raise ValueError(
                f"Invalid rule: '{spec}'. Provide at least one rule argument."
            )

        rules.append({"Operator": operator.strip(), "Arguments": arguments})
    return rules


def parse_sitelink_specs(specs: Optional[List[str]]) -> Optional[List[Dict[str, str]]]:
    """Parse repeated TITLE|HREF[|DESCRIPTION] sitelink specs."""
    if not specs:
        return None

    sitelinks = []
    for spec in specs:
        parts = [part.strip() for part in spec.split("|")]
        if len(parts) not in (2, 3):
            raise ValueError(
                "Invalid sitelink: "
                f"'{spec}'. Expected format: TITLE|HREF[|DESCRIPTION]"
            )

        sitelink = {"Title": parts[0], "Href": parts[1]}
        if len(parts) == 3 and parts[2]:
            sitelink["Description"] = parts[2]
        sitelinks.append(sitelink)
    return sitelinks


COMMON_FIELDS: Dict[str, Union[List[str], Dict[str, List[str]]]] = {
    "campaigns": [
        "Id",
        "Name",
        "Status",
        "State",
        "StartDate",
        "EndDate",
        "Type",
        "DailyBudget",
        "ClientInfo",
    ],
    "adgroups": ["Id", "Name", "CampaignId", "Status", "Type", "RegionIds"],
    "ads": {
        "FieldNames": ["Id", "CampaignId", "AdGroupId", "Status", "State", "Type"],
        "TextAdFieldNames": ["Title", "Title2", "Text", "Href"],
    },
    "keywords": [
        "Id",
        "Keyword",
        "CampaignId",
        "AdGroupId",
        "Status",
        "ServingStatus",
        "Bid",
        "ContextBid",
    ],
    "clients": ["ClientId", "Login", "CountryId", "Currency"],
    "agencyclients": ["ClientId", "Login", "CountryId", "Currency"],
    "creatives": ["Id", "Name", "Type"],
    "adimages": ["AdImageHash", "Name"],
    "adextensions": ["Id", "Type", "State", "Status"],
    "negativekeywordsharedsets": ["Id", "Name", "NegativeKeywords"],
    "sitelinks": ["Id", "Sitelinks"],
    "vcards": ["Id", "CampaignId", "Country", "City", "CompanyName"],
    "leads": ["Id", "SubmittedAt", "TurboPageId", "TurboPageName"],
    "turbopages": [
        "Id",
        "Name",
        "Href",
        "TurboSiteHref",
        "PreviewHref",
        "BoundWithHref",
    ],
    "feeds": ["Id", "Name", "BusinessType", "SourceType", "Status"],
    "smartadtargets": ["Id", "CampaignId", "AdGroupId", "State"],
    "businesses": ["Id", "Name", "Address", "Phone", "ProfileUrl"],
    "changes": ["CampaignIds", "AdGroupIds", "AdIds", "CampaignsStat"],
    "retargetinglists": ["Id", "Name", "Type", "Scope"],
    "advideos": ["Id", "Status"],
    "bids": ["CampaignId", "AdGroupId", "KeywordId", "Bid"],
    "bidmodifiers": ["Id", "CampaignId", "AdGroupId", "Level", "Type"],
    "audiencetargets": [
        "Id",
        "AdGroupId",
        "RetargetingListId",
        "State",
        "ContextBid",
    ],
    "dynamicads": ["Id", "AdGroupId", "Conditions", "Bid"],
    "strategies": ["Id", "Name", "Type", "StatusArchived"],
    "dynamicfeedadtargets": [
        "Id",
        "AdGroupId",
        "CampaignId",
        "Name",
        "Bid",
        "ContextBid",
    ],
    # Multi-FieldNames resources: WSDL exposes more than one ``*FieldNames``
    # request param (e.g. SearchFieldNames + NetworkFieldNames). Each key is
    # the WSDL request-field name; values are the default enum-validated lists.
    "keywordbids": {
        "FieldNames": [
            "KeywordId",
            "AdGroupId",
            "CampaignId",
            "ServingStatus",
            "StrategyPriority",
        ],
        "SearchFieldNames": ["Bid"],
        "NetworkFieldNames": ["Bid"],
    },
    "keywordsresearch": ["Keyword", "AllDevices"],
}


def get_default_fields(resource: str, request_field: str = "FieldNames") -> List[str]:
    """Return default field names for a resource's WSDL request param.

    For single-FieldNames resources, ``COMMON_FIELDS[resource]`` is a list and
    ``request_field`` is ignored. For multi-FieldNames resources (like
    ``keywordbids`` with ``SearchFieldNames``/``NetworkFieldNames``), the
    value is a dict keyed by request-field name.
    """
    entry = COMMON_FIELDS.get(resource)
    if entry is None:
        return ["Id", "Name"]
    if isinstance(entry, dict):
        return entry.get(request_field, ["Id", "Name"])
    return entry


def get_docs_url(service: str) -> Optional[str]:
    """Return documentation URL for a service from tapi resource mapping."""
    entry = RESOURCE_MAPPING_V5.get(service)
    return entry.get("docs") if entry else None


def get_docs_pages(service: str) -> Dict[str, str]:
    """Return documentation page URLs for a service from tapi resource mapping."""
    entry = RESOURCE_MAPPING_V5.get(service)
    docs_pages = entry.get("docs_pages") if entry else None
    return dict(docs_pages) if docs_pages else {}
