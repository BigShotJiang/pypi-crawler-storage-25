"""
Sandbox integration tests for direct-cli write commands.

Exercises mutating commands against the Yandex Direct sandbox API.

**Two modes of operation (pytest-recording / vcrpy):**

- **Replay mode (default, CI)** — every test has a cassette YAML committed
  under ``tests/cassettes/test_integration_write/``.  Running
  ``pytest -m integration_write -v`` replays the recorded HTTP traffic
  without touching the real sandbox.  No token is required.

- **Rewrite mode (manual)** — to regenerate cassettes after a CLI change
  that affects the request payload, export ``YANDEX_DIRECT_TOKEN`` and
  run ``pytest -m integration_write --record-mode=rewrite -v``.  Review
  the generated YAMLs for leaked secrets (``grep -r <your-token>``)
  before committing.

**Sandbox limitations discovered during recording:**

The Yandex Direct sandbox does NOT persist nested resources (adgroups, ads,
keywords) reliably — ``adgroups add`` returns an ID but subsequent calls
report "Object not found".  Cassettes preserve whatever the sandbox
actually returned at record time; tests use ``_is_sandbox_error`` to
distinguish sandbox limitations from real CLI regressions.

Fixtures (campaign → adgroup → ad/keyword) are defined in conftest.py.
Top-level resource tests run without fixtures.

**Coverage status (issue #20 / #28 / #56):**

Passing in replay (10 tests, cassettes up to date):
  - campaigns lifecycle (add/update/suspend/resume/archive/unarchive/delete)
  - campaigns draft parity (add/get/delete/get, mirrors live draft tier)
  - adgroups add-update-delete
  - bidmodifiers add/delete (mobile adjustment)
  - bidmodifiers set regression guard (no-id rejection)
  - feeds add-update-delete
  - retargeting add-delete
  - vcards add-delete
  - adextensions add-delete
  - negativekeywordsharedsets add-update-delete

Sandbox-limited (confirmed via live recording, ``@pytest.mark.sandbox_limitation``):

  Category A — disabled in sandbox, supported in live API (codes 8800/1000/5004):
  - ads add/update/delete         — sandbox does not persist adgroups across calls (code 8800)
  - keywords add/update/delete    — same (code 8800)
  - bids set                      — depends on keyword persistence, sandbox_keyword fixture fails (code 8800 chain)
  - keywordbids set               — same (code 8800 chain)
  - sitelinks add/delete          — sandbox service permanently unavailable (code 1000)
  - adimages add/delete           — sandbox rejects valid 450x450 PNG uploads (code 5004)
  - audiencetargets add/delete    — sandbox does not persist adgroup/retargeting list (code 8800)

  Category B — unsupported resource type in sandbox (code 3500):
  - dynamicads add/delete         — sandbox does not support DYNAMIC_TEXT_CAMPAIGN creation
  - smartadtargets add/update/delete — sandbox does not support SMART_CAMPAIGN + SMART_AD_GROUP chain

  Category C — account-permission limited in sandbox (code 3001):
  - agencyclients add-passport-organization — current sandbox agency account can read
    agency clients but cannot create them ("No rights to create clients")

Part of axisrow/yandex-direct-mcp-plugin#61 (Etap 3).
"""

import json
from typing import Any, Dict, List, Optional

import pytest

import sys
import os

sys.path.insert(0, os.path.dirname(__file__))

from conftest import (  # noqa: E402
    _ARCHIVE_PATTERNS,
    _CAMPAIGN_STATUS_PATTERNS,
    _IMAGE_PATTERNS,
    _SITELINK_PATTERNS,
    _SMART_AD_PATTERNS,
    _has_result_errors,
    _invoke,
    _is_sandbox_error,
    assert_success,
    parse_add_result,
    parse_first_result,
    tomorrow,
)


def _extract_campaigns(output: str) -> List[Dict[str, Any]]:
    """Extract campaigns from common tapi-yandex-direct response shapes."""
    data = json.loads(output)
    if isinstance(data, list):
        return data
    if not isinstance(data, dict):
        return []

    result = data.get("result", data)
    campaigns = result.get("Campaigns", [])
    return campaigns if isinstance(campaigns, list) else []


def _find_campaign(output: str, campaign_id: int) -> Optional[Dict[str, Any]]:
    """Find a campaign by Id in a get response."""
    for campaign in _extract_campaigns(output):
        try:
            if int(campaign.get("Id")) == campaign_id:
                return campaign
        except (TypeError, ValueError):
            continue
    return None


# ── campaigns ────────────────────────────────────────────────────────────


@pytest.mark.integration_write
@pytest.mark.vcr
class TestWriteCampaigns:
    """Full lifecycle: add → update → archive → unarchive → delete."""

    def test_campaign_lifecycle(self, unique_suffix):
        name = f"lifecycle-{unique_suffix}"

        # add
        r = _invoke(
            "campaigns",
            "add",
            "--name",
            name,
            "--start-date",
            tomorrow(),
        )
        assert_success(r, "campaigns add")
        cid = parse_add_result(r)

        try:
            # update
            r = _invoke(
                "campaigns",
                "update",
                "--id",
                str(cid),
                "--name",
                f"{name}-renamed",
            )
            assert_success(r, "campaigns update")

            # suspend — a brand-new sandbox campaign is in DRAFT; the API
            # rejects suspend/resume with a known error.  Skip only that
            # specific case; any other non-zero exit is a regression.
            # Yandex Direct returns HTTP 200 with embedded SuspendResults
            # Errors for DRAFT campaigns — check both exit_code and body.
            r = _invoke("campaigns", "suspend", "--id", str(cid))
            if r.exit_code != 0 or _has_result_errors(r.output, "SuspendResults"):
                err = r.output
                if _is_sandbox_error(err, extra_patterns=_CAMPAIGN_STATUS_PATTERNS):
                    suspend_ok = False
                else:
                    pytest.fail(
                        f"campaigns suspend failed (CLI regression?): {err[:500]}"
                    )
            else:
                suspend_ok = True

            if suspend_ok:
                r = _invoke("campaigns", "resume", "--id", str(cid))
                if r.exit_code != 0 or _has_result_errors(r.output, "ResumeResults"):
                    if not _is_sandbox_error(
                        r.output, extra_patterns=_CAMPAIGN_STATUS_PATTERNS
                    ):
                        pytest.fail(
                            f"campaigns resume failed (CLI regression?): {r.output[:500]}"
                        )

            # archive — sandbox DRAFT campaigns return embedded
            # ArchiveResults errors (Code 8303) with HTTP 200.
            r = _invoke("campaigns", "archive", "--id", str(cid))
            if r.exit_code != 0 or _has_result_errors(r.output, "ArchiveResults"):
                if not _is_sandbox_error(r.output, extra_patterns=_ARCHIVE_PATTERNS):
                    pytest.fail(
                        f"campaigns archive failed (CLI regression?): {r.output[:500]}"
                    )
            else:
                assert_success(r, "campaigns archive")

            # unarchive
            r = _invoke("campaigns", "unarchive", "--id", str(cid))
            if r.exit_code != 0 or _has_result_errors(r.output, "UnarchiveResults"):
                if not _is_sandbox_error(r.output, extra_patterns=_ARCHIVE_PATTERNS):
                    pytest.fail(
                        f"campaigns unarchive failed (CLI regression?): {r.output[:500]}"
                    )
            else:
                assert_success(r, "campaigns unarchive")
        finally:
            _invoke("campaigns", "delete", "--id", str(cid))


@pytest.mark.integration_write
@pytest.mark.vcr
class TestWriteCampaignDraftLifecycle:
    """Sandbox parity check for the guarded live draft create/delete flow."""

    def test_draft_create_get_delete(self, unique_suffix):
        name = f"draft-lifecycle-{unique_suffix}"
        cid: Optional[int] = None

        r = _invoke(
            "campaigns",
            "add",
            "--name",
            name,
            "--start-date",
            tomorrow(),
        )

        try:
            assert_success(r, "campaigns draft add")
            try:
                cid = parse_add_result(r)
            except Exception:
                pass  # ID unknown; cleanup in finally is skipped — manual recovery via campaign name

            r = _invoke(
                "campaigns",
                "get",
                "--ids",
                str(cid),
                "--fields",
                "Id,Name,Status,State",
            )
            assert_success(r, "campaigns draft get")
            campaign = _find_campaign(r.output, cid)
            assert campaign is not None, (
                f"Created draft campaign {cid} not found in sandbox get response: "
                f"{r.output[:500]}"
            )
            assert campaign.get("Name") == name
            status = campaign.get("Status")
            state = campaign.get("State")
            assert status == "DRAFT" or state == "OFF", (
                "Expected a non-serving sandbox draft/off campaign, got "
                f"Status={status!r}, State={state!r}, campaign={campaign}"
            )
            if status is not None:
                assert status == "DRAFT"
            if state is not None:
                assert state == "OFF"
        finally:
            if cid is not None:
                _invoke("campaigns", "delete", "--id", str(cid))

        r = _invoke(
            "campaigns",
            "get",
            "--ids",
            str(cid),
            "--fields",
            "Id,Name,Status,State",
        )
        assert_success(r, "campaigns draft get after delete")
        assert _find_campaign(r.output, cid) is None


# ── adgroups ─────────────────────────────────────────────────────────────


@pytest.mark.integration_write
@pytest.mark.vcr
class TestWriteAdGroups:
    def test_add_update_delete(self, sandbox_campaign):
        campaign_id = sandbox_campaign

        # add
        r = _invoke(
            "adgroups",
            "add",
            "--name",
            "test-adgroup",
            "--campaign-id",
            str(campaign_id),
            "--region-ids",
            "1,225",
        )
        assert_success(r, "adgroups add")
        gid = parse_add_result(r)

        try:
            # update — may fail if sandbox doesn't persist adgroups
            r = _invoke(
                "adgroups",
                "update",
                "--id",
                str(gid),
                "--name",
                "test-adgroup-renamed",
            )
            if r.exit_code != 0:
                if _is_sandbox_error(r.output):
                    pytest.skip(f"adgroups not persisted in sandbox: {r.output[:200]}")
                pytest.fail(
                    f"adgroups update failed (CLI regression?): {r.output[:500]}"
                )
            assert_success(r, "adgroups update")
        finally:
            _invoke("adgroups", "delete", "--id", str(gid))


# ── ads ──────────────────────────────────────────────────────────────────


@pytest.mark.integration_write
@pytest.mark.vcr
@pytest.mark.sandbox_limitation(
    category="disabled",
    reason="Sandbox does not persist adgroups; ads add always returns 'Ad group not found'",
)
class TestWriteAds:
    """Confirms the Type-field fix from PR #12 works with live API."""

    def test_add_text_ad_update_delete(self, sandbox_adgroup):
        adgroup_id = sandbox_adgroup

        r = _invoke(
            "ads",
            "add",
            "--adgroup-id",
            str(adgroup_id),
            "--title",
            "Test Ad",
            "--text",
            "Test ad text body",
            "--href",
            "https://example.com",
        )
        assert_success(r, "ads add")
        data = json.loads(r.output)
        if isinstance(data, list):
            first = data[0]
        else:
            first = data.get("AddResults", [{}])[0]

        if "Errors" in first and first["Errors"]:
            err_text = str(first["Errors"])
            if _is_sandbox_error(err_text):
                pytest.skip(f"adgroup not persisted in sandbox: {first['Errors']}")
            pytest.fail(
                f"API rejected ads add (potential Type-field regression): {first['Errors']}"
            )

        ad_id = first["Id"]
        try:
            r = _invoke(
                "ads",
                "update",
                "--id",
                str(ad_id),
                "--title",
                "Updated Title",
            )
            assert_success(r, "ads update")
        finally:
            _invoke("ads", "delete", "--id", str(ad_id))


# ── keywords ─────────────────────────────────────────────────────────────


@pytest.mark.integration_write
@pytest.mark.vcr
@pytest.mark.sandbox_limitation(
    category="disabled",
    reason="Sandbox does not persist adgroups; keywords add always returns 'Ad group not found'",
)
class TestWriteKeywords:
    def test_add_update_delete(self, sandbox_adgroup):
        adgroup_id = sandbox_adgroup

        r = _invoke(
            "keywords",
            "add",
            "--adgroup-id",
            str(adgroup_id),
            "--keyword",
            "купить тест",
        )
        assert_success(r, "keywords add")
        data = json.loads(r.output)
        if isinstance(data, list):
            first = data[0]
        else:
            first = data.get("AddResults", [{}])[0]

        if "Errors" in first and first["Errors"]:
            err_text = str(first["Errors"])
            if _is_sandbox_error(err_text):
                pytest.skip(f"adgroup not persisted in sandbox: {first['Errors']}")
            pytest.fail(f"API rejected keywords add (CLI bug?): {first['Errors']}")

        kid = first["Id"]
        try:
            r = _invoke(
                "keywords",
                "update",
                "--id",
                str(kid),
                "--bid",
                "10000000",
            )
            assert_success(r, "keywords update")
        finally:
            _invoke("keywords", "delete", "--id", str(kid))


# ── bids ─────────────────────────────────────────────────────────────────


@pytest.mark.integration_write
@pytest.mark.vcr
@pytest.mark.sandbox_limitation(
    category="disabled",
    reason="Sandbox does not persist adgroups/keywords (code 8800 chain); inline _is_sandbox_error provides runtime defense",
)
class TestWriteBids:
    def test_set_bid(self, sandbox_keyword):
        r = _invoke(
            "bids",
            "set",
            "--keyword-id",
            str(sandbox_keyword),
            "--bid",
            "15000000",
        )
        if r.exit_code != 0:
            if _is_sandbox_error(r.output):
                pytest.skip(f"bids set not supported (sandbox): {r.output[:200]}")
            pytest.fail(f"bids set failed (CLI regression?): {r.output[:500]}")

        # Even with exit_code 0, the API can return embedded errors.
        if _has_result_errors(r.output, "SetResults"):
            if _is_sandbox_error(r.output):
                pytest.skip(f"bids set rejected (sandbox): {r.output[:200]}")
            pytest.fail(f"bids set returned errors (CLI regression?): {r.output[:500]}")


# ── keywordbids ──────────────────────────────────────────────────────────


@pytest.mark.integration_write
@pytest.mark.vcr
@pytest.mark.sandbox_limitation(
    category="disabled",
    reason="Sandbox does not persist adgroups/keywords; no keywords to bid on",
)
class TestWriteKeywordBids:
    def test_set_keyword_bid(self, sandbox_keyword):
        r = _invoke(
            "keywordbids",
            "set",
            "--keyword-id",
            str(sandbox_keyword),
            "--search-bid",
            "8000000",
            "--network-bid",
            "3000000",
        )
        if r.exit_code != 0:
            if _is_sandbox_error(r.output):
                pytest.skip(
                    f"keywordbids set not supported (sandbox): {r.output[:200]}"
                )
            pytest.fail(f"keywordbids set failed (CLI regression?): {r.output[:500]}")


# ── bidmodifiers ─────────────────────────────────────────────────────────


@pytest.mark.integration_write
@pytest.mark.vcr
class TestWriteBidModifiersAdd:
    """Lifecycle for the new ``bidmodifiers add`` subcommand.

    Creates a mobile bid adjustment on the sandbox campaign via the
    nested-object payload (``MobileAdjustment: {BidModifier: 120}``),
    parses the resulting modifier ID from ``AddResults``, and deletes
    it — a full add → delete round-trip against the live sandbox.
    """

    def test_add_delete_mobile(self, sandbox_campaign):
        r = _invoke(
            "bidmodifiers",
            "add",
            "--campaign-id",
            str(sandbox_campaign),
            "--type",
            "MOBILE_ADJUSTMENT",
            "--value",
            "120",
        )
        if r.exit_code != 0:
            if _is_sandbox_error(r.output):
                pytest.skip(
                    f"bidmodifiers add not supported (sandbox): {r.output[:200]}"
                )
            pytest.fail(f"bidmodifiers add failed (CLI regression?): {r.output[:500]}")

        # ``bidmodifiers/add`` returns ``{"Ids": [<long>]}`` rather than
        # the usual ``{"AddResults": [{"Id": <long>}]}`` wrapper.  Handle
        # both shapes because tapi-yandex-direct may unwrap differently.
        data = json.loads(r.output)
        if isinstance(data, dict) and "Ids" in data:
            ids = data["Ids"]
        elif (
            isinstance(data, list)
            and data
            and isinstance(data[0], dict)
            and "Ids" in data[0]
        ):
            ids = data[0]["Ids"]
        else:
            ids = None
        assert ids, f"bidmodifiers add returned no Ids: {r.output[:500]}"
        mid = ids[0]

        r = _invoke("bidmodifiers", "delete", "--id", str(mid))
        assert_success(r, "bidmodifiers delete")


@pytest.mark.integration_write
@pytest.mark.vcr
class TestWriteBidModifiersSet:
    """Regression guard: ``bidmodifiers set`` without ``--id`` is rejected.

    The API's ``set`` method updates EXISTING modifiers only — it
    requires the ``Id`` field.  The CLI's ``set`` subcommand builds a
    payload without ``Id``, so the call is by-design rejected.  New
    modifiers go through the ``bidmodifiers add`` subcommand instead
    (covered by ``TestWriteBidModifiersAdd``).

    This test freezes the broken-by-design behaviour: if the CLI ever
    starts including ``Id`` automatically, or the API stops returning
    this specific error, the cassette miss will flag it.
    """

    def test_set_without_id_is_rejected(self, sandbox_campaign):
        r = _invoke(
            "bidmodifiers",
            "set",
            "--campaign-id",
            str(sandbox_campaign),
            "--type",
            "MOBILE_ADJUSTMENT",
            "--value",
            "120",
        )
        assert r.exit_code != 0, (
            "bidmodifiers set unexpectedly succeeded without --id; either the "
            "CLI was fixed to include Id, or the API now allows creating "
            "modifiers via set. Update this test accordingly."
        )
        assert (
            "The required field Id is omitted" in r.output
        ), f"Unexpected failure mode from bidmodifiers set: {r.output[:500]}"


# ── feeds ────────────────────────────────────────────────────────────────


@pytest.mark.integration_write
@pytest.mark.vcr
class TestWriteFeeds:
    def test_add_update_delete(self, unique_suffix):
        r = _invoke(
            "feeds",
            "add",
            "--name",
            f"test-feed-{unique_suffix}",
            "--url",
            "https://example.com/feed.xml",
        )
        if r.exit_code != 0:
            if _is_sandbox_error(r.output):
                pytest.skip(f"feeds add not supported in sandbox: {r.output[:200]}")
            pytest.fail(f"feeds add failed (CLI regression?): {r.output[:500]}")

        fid = parse_add_result(r)
        try:
            r = _invoke(
                "feeds",
                "update",
                "--id",
                str(fid),
                "--name",
                f"test-feed-{unique_suffix}-renamed",
            )
            assert_success(r, "feeds update")
        finally:
            _invoke("feeds", "delete", "--id", str(fid))


# ── retargeting ──────────────────────────────────────────────────────────


@pytest.mark.integration_write
@pytest.mark.vcr
class TestWriteRetargeting:
    def test_add_delete(self, unique_suffix):
        # Typed --rule input must reproduce the historical cassette body.
        r = _invoke(
            "retargeting",
            "add",
            "--name",
            f"test-rtg-{unique_suffix}",
            "--type",
            "RETARGETING",
            "--rule",
            "ANY:1234567890",
        )
        if r.exit_code != 0:
            if _is_sandbox_error(r.output):
                pytest.skip(
                    f"retargeting add not supported (sandbox): {r.output[:200]}"
                )
            pytest.fail(f"retargeting add failed (CLI regression?): {r.output[:500]}")

        rid = parse_add_result(r)
        r = _invoke("retargeting", "delete", "--id", str(rid))
        assert_success(r, "retargeting delete")


# ── audiencetargets ──────────────────────────────────────────────────────


@pytest.mark.integration_write
@pytest.mark.vcr
@pytest.mark.sandbox_limitation(
    category="disabled",
    reason="Sandbox does not persist adgroup/retargeting list across API calls",
)
class TestWriteAudienceTargets:
    def test_add_delete(self, sandbox_adgroup, sandbox_retargeting_list):
        r = _invoke(
            "audiencetargets",
            "add",
            "--adgroup-id",
            str(sandbox_adgroup),
            "--retargeting-list-id",
            str(sandbox_retargeting_list),
        )
        if r.exit_code != 0:
            if _is_sandbox_error(r.output):
                pytest.skip(
                    f"audiencetargets add not supported (sandbox): {r.output[:200]}"
                )
            pytest.fail(
                f"audiencetargets add failed (CLI regression?): {r.output[:500]}"
            )

        data = json.loads(r.output)
        if isinstance(data, list):
            first = data[0]
        else:
            first = data.get("AddResults", [{}])[0]
        if "Errors" in first and first["Errors"]:
            err_text = str(first["Errors"])
            if _is_sandbox_error(err_text):
                pytest.skip(
                    f"audiencetargets add rejected (sandbox): {first['Errors']}"
                )
            pytest.fail(
                f"API rejected audiencetargets add (CLI bug?): {first['Errors']}"
            )

        tid = first["Id"]
        r = _invoke("audiencetargets", "delete", "--id", str(tid))
        assert_success(r, "audiencetargets delete")


# ── sitelinks ────────────────────────────────────────────────────────────


@pytest.mark.integration_write
@pytest.mark.vcr
@pytest.mark.sandbox_limitation(
    category="disabled",
    reason="Sandbox sitelinks service permanently unavailable (error 1000)",
)
class TestWriteSitelinks:
    def test_add_delete(self):
        r = _invoke(
            "sitelinks",
            "add",
            "--sitelink",
            "About|https://example.com/about",
            "--sitelink",
            "Contact|https://example.com/contact",
        )
        if r.exit_code != 0:
            if _is_sandbox_error(r.output, extra_patterns=_SITELINK_PATTERNS):
                pytest.skip(f"sitelinks add not available (sandbox): {r.output[:200]}")
            pytest.fail(f"sitelinks add failed (CLI regression?): {r.output[:500]}")

        first = parse_first_result(r)
        sid = first["Id"]
        r = _invoke("sitelinks", "delete", "--id", str(sid))
        assert_success(r, "sitelinks delete")


# ── vcards ───────────────────────────────────────────────────────────────


@pytest.mark.integration_write
@pytest.mark.vcr
class TestWriteVCards:
    def test_add_delete(self, sandbox_campaign):
        # Recorded at 2026-04-11 against sandbox.
        # WorkTime format: ``<day_from>#<day_to>#<hh_from>#<mm_from>#<hh_to>#<mm_to>``
        # Here: Mon(1) — Fri(5), 09:00 — 18:00.
        r = _invoke(
            "vcards",
            "add",
            "--campaign-id",
            str(sandbox_campaign),
            "--country",
            "Россия",
            "--city",
            "Москва",
            "--company-name",
            "Test Company",
            "--work-time",
            "1#5#9#0#18#0",
            "--phone-country-code",
            "+7",
            "--phone-city-code",
            "495",
            "--phone-number",
            "1234567",
        )
        if r.exit_code != 0:
            if _is_sandbox_error(r.output):
                pytest.skip(f"vcards add not supported (sandbox): {r.output[:200]}")
            pytest.fail(f"vcards add failed (CLI regression?): {r.output[:500]}")

        first = parse_first_result(r)
        vid = first["Id"]
        r = _invoke("vcards", "delete", "--id", str(vid))
        assert_success(r, "vcards delete")


# ── adextensions ─────────────────────────────────────────────────────────


@pytest.mark.integration_write
@pytest.mark.vcr
class TestWriteAdExtensions:
    """Live lifecycle for a typed ``--callout-text`` ad extension.

    Exercises the fix that stopped the CLI from sending the extra
    top-level ``Type`` field (the API derives the extension kind from
    the nested object name).  The regenerated cassette freezes the
    correct payload as a regression guard.
    """

    def test_add_delete(self):
        r = _invoke(
            "adextensions",
            "add",
            "--callout-text",
            "Free shipping",
        )
        if r.exit_code != 0:
            if _is_sandbox_error(r.output):
                pytest.skip(
                    f"adextensions add not supported (sandbox): {r.output[:200]}"
                )
            pytest.fail(f"adextensions add failed (CLI regression?): {r.output[:500]}")

        first = parse_first_result(r)
        eid = first["Id"]
        r = _invoke("adextensions", "delete", "--id", str(eid))
        assert_success(r, "adextensions delete")


# ── adimages ─────────────────────────────────────────────────────────────


@pytest.mark.integration_write
@pytest.mark.vcr
@pytest.mark.sandbox_limitation(
    category="disabled",
    reason="Sandbox rejects valid base64-encoded PNG image uploads (error 5004)",
)
class TestWriteAdImages:
    def test_add_delete(self):
        # 450x450 solid red PNG — meets Yandex Direct minimum image dimension
        # requirements. The previous 1x1px image was rejected by the API (error 5004).
        png_b64 = (
            "iVBORw0KGgoAAAANSUhEUgAAAcIAAAHCCAIAAADzel4SAAAGs0lEQVR4nO3OQQkAQRAEsf"
            "Fv+s7DfpqCQATkvjsAnu0HAGn7AUDafgCQth8ApO0HAGn7AUDafgCQth8ApO0HAGn7AUD"
            "afgCQth8ApO0HAGn7AUDafgCQth8ApO0HAGn7AUDafgCQth8ApO0HAGn7AUDafgCQth8A"
            "pO0HAGn7AUDafgCQth8ApO0HAGn7AUDafgCQth8ApO0HAGn7AUDafgCQth8ApO0HAGn7"
            "AUDafgCQth8ApO0HAGn7AUDafgCQth8ApO0HAGn7AUDafgCQth8ApO0HAGn7AUDafgCQ"
            "th8ApO0HAGn7AUDafgCQth8ApO0HAGn7AUDafgCQth8ApO0HAGn7AUDafgCQth8ApO0H"
            "AGn7AUDafgCQth8ApO0HAGn7AUDafgCQth8ApO0HAGn7AUDafgCQth8ApO0HAGn7AUDa"
            "fgCQth8ApO0HAGn7AUDafgCQth8ApO0HAGn7AUDafgCQth8ApO0HAGn7AUDafgCQth8A"
            "pO0HAGn7AUDafgCQth8ApO0HAGn7AUDafgCQth8ApO0HAGn7AUDafgCQth8ApO0HAGn7"
            "AUDafgCQth8ApO0HAGn7AUDafgCQth8ApO0HAGn7AUDafgCQth8ApO0HAGn7AUDafgCQ"
            "th8ApO0HAGn7AUDafgCQth8ApO0HAGn7AUDafgCQth8ApO0HAGn7AUDafgCQth8ApO0H"
            "AGn7AUDafgCQth8ApO0HAGn7AUDafgCQth8ApO0HAGn7AUDafgCQth8ApO0HAGn7AUDa"
            "fgCQth8ApO0HAGn7AUDafgCQth8ApO0HAGn7AUDafgCQth8ApO0HAGn7AUDafgCQth8A"
            "pO0HAGn7AUDafgCQth8ApO0HAGn7AUDafgCQth8ApO0HAGn7AUDafgCQth8ApO0HAGn7"
            "AUDafgCQth8ApO0HAGn7AUDafgCQth8ApO0HAGn7AUDafgCQth8ApO0HAGn7AUDafgCQ"
            "th8ApO0HAGn7AUDafgCQth8ApO0HAGn7AUDafgCQth8ApO0HAGn7AUDafgCQth8ApO0H"
            "AGn7AUDafgCQth8ApO0HAGn7AUDafgCQth8ApO0HAGn7AUDafgCQth8ApO0HAGn7AUDa"
            "fgCQth8ApO0HAGn7AUDafgCQth8ApO0HAGn7AUDafgCQth8ApO0HAGn7AUDafgCQth8A"
            "pO0HAGn7AUDafgCQth8ApO0HAGn7AUDafgCQth8ApO0HAGn7AUDafgCQth8ApO0HAGn7"
            "AUDafgCQth8ApO0HAGn7AUDafgCQth8ApO0HAGn7AUDafgCQth8ApO0HAGn7AUDafgCQ"
            "th8ApO0HAGn7AUDafgCQth8ApO0HAGn7AUDafgCQth8ApO0HAGn7AUDafgCQth8ApO0H"
            "AGn7AUDafgCQth8ApO0HAGn7AUDafgCQth8ApO0HAGn7AUDafgCQth8ApO0HAGn7AUDa"
            "fgCQth8ApO0HAGn7AUDafgCQth8ApO0HAGn7AUDafgCQth8ApO0HAGn7AUDafgCQth8A"
            "pO0HAGn7AUDafgCQth8ApO0HAGn7AUDafgCQth8ApO0HAGn7AUDafgCQth8ApO0HAGn7"
            "AUDafgCQth8ApO0HAGn7AUDafgCQth8ApO0HAGn7AUDafgCQth8ApO0HAGn7AUDafgCQ"
            "th8ApO0HAGn7AUDafgCQth8ApO0HAGn7AUDafgCQth8ApO0HAGn7AUDafgCQth8ApO0H"
            "AGn7AUDafgCQth8ApO0HAGn7AUDafgCQth8ApO0HAGn7AUDafgCQth8ApO0HAGn7AUDa"
            "fgCQth8ApO0HAGn7AUDafgCQth8ApO0HAGn7AUDafgCQth8ApO0HAGn7AUDafgCQth8A"
            "pO0HAGn7AUDafgCQth8ApO0HAGn7AUDafgCQth8ApO0HAGn7AUDafgCQth8ApO0HAGn7"
            "AUDafgCQth8ApO0HAGn7AUDafgCQth8ApO0HAGn7AUDafgCQth8ApO0HAGn7AUDafgCQ"
            "th8ApO0HAGn7AUDafgCQth8ApO0HAGn7AUDafgCQth8ApO0HAGn7AUDafgCQth8ApO0H"
            "AGn7AUDafgCQth8ApO0HAGn7AUDafgCQth8ApO0HAGn7AUDafgCQth8ApO0HAGn7AUDa"
            "fgCQth8ApO0HAGn7AUDafgCQth8ApO0HAGn7AUDafgCQth8ApO0HAGn7AUDafgCQth8A"
            "pO0HAGn7AUDafgCQth8ApO0HAGn7AUDafgCQth8ApO0HAGn7AUDafgCQth8ApO0HAGn7"
            "AUDafgCQth8ApO0HAGn7AUDafgCQth8ApO0HAGn7AUDafgCQth8ApO0HAGn7AUDafgCQ"
            "th8ApO0HAGn7AUDafgCQth8ApO0HAGn7AUDafgCQth8ApO0HAGn7AUDafgCQth8ApO0H"
            "AGn7AUDafgCQth8ApO0HAGn7AUDafgCQth8ApO0HAGn7AUDafgCQth8ApO0HAGn7AUDa"
            "fgCQth8ApO0HAGn7AUDafgCQth8ApO0HAGn7AUDafgCQth8ApO0HAGn7AUDafgCQth8A"
            "pO0HAGn7AUDafgCQth8ApO0HAGn7AUDafgCQth8ApO0HAGn7AUDafgCQth8ApO0HAGk/"
            "KWgbKQyncKAAAAAASUVORK5CYII="
        )
        r = _invoke(
            "adimages",
            "add",
            "--name",
            "test-image.png",
            "--image-data",
            png_b64,
        )
        if r.exit_code != 0:
            if _is_sandbox_error(r.output, extra_patterns=_IMAGE_PATTERNS):
                pytest.skip(f"adimages add not supported (sandbox): {r.output[:200]}")
            pytest.fail(f"adimages add failed (CLI regression?): {r.output[:500]}")

        data = json.loads(r.output)
        assert (
            isinstance(data, list) and data
        ), f"adimages add returned empty result: {r.output[:200]}"
        first = data[0]
        if "Errors" in first and first["Errors"]:
            err_text = str(first["Errors"])
            if _is_sandbox_error(err_text, extra_patterns=_IMAGE_PATTERNS):
                pytest.skip(f"adimages rejected (sandbox): {first['Errors']}")
            pytest.fail(f"API rejected adimages add (CLI bug?): {first['Errors']}")

        img_hash = first.get("AdImageHash") or first.get("Id")
        assert img_hash, f"adimages add returned no hash/id: {first}"
        r = _invoke("adimages", "delete", "--hash", str(img_hash))
        assert_success(r, "adimages delete")


# ── dynamicads (webpages) ────────────────────────────────────────────────


@pytest.mark.integration_write
@pytest.mark.vcr
@pytest.mark.sandbox_limitation(
    category="unsupported",
    reason="Sandbox does not support creating DYNAMIC_TEXT_CAMPAIGN type",
)
class TestWriteDynamicAds:
    def test_add_update_delete(self, sandbox_dynamic_adgroup):
        r = _invoke(
            "dynamicads",
            "add",
            "--adgroup-id",
            str(sandbox_dynamic_adgroup),
            "--name",
            "Test Webpage",
            "--condition",
            "URL:CONTAINS_ANY:test",
        )
        if r.exit_code != 0:
            if _is_sandbox_error(r.output):
                pytest.skip(f"dynamicads add not supported (sandbox): {r.output[:200]}")
            pytest.fail(f"dynamicads add failed (CLI regression?): {r.output[:500]}")

        data = json.loads(r.output)
        first = data[0] if isinstance(data, list) else data.get("AddResults", [{}])[0]
        if "Errors" in first and first["Errors"]:
            err_text = str(first["Errors"])
            if _is_sandbox_error(err_text):
                pytest.skip(f"dynamicads add rejected (sandbox): {first['Errors']}")
            pytest.fail(f"API rejected dynamicads add (CLI bug?): {first['Errors']}")

        wid = first["Id"]
        r = _invoke("dynamicads", "delete", "--id", str(wid))
        assert_success(r, "dynamicads delete")


# ── smartadtargets ───────────────────────────────────────────────────────


@pytest.mark.integration_write
@pytest.mark.vcr
@pytest.mark.sandbox_limitation(
    category="unsupported",
    reason="Sandbox does not support creating SMART_CAMPAIGN (code 3500); sandbox_smart_adgroup fixture skips before the test body runs",
)
class TestWriteSmartAdTargets:
    """Live-API regression guard for typed smart ad target flags."""

    def test_add_update_delete(self, sandbox_smart_adgroup):
        r = _invoke(
            "smartadtargets",
            "add",
            "--adgroup-id",
            str(sandbox_smart_adgroup),
            "--name",
            "regression-smart-target",
            "--audience",
            "ALL_SEGMENTS",
        )
        if r.exit_code != 0:
            if _is_sandbox_error(r.output, extra_patterns=_SMART_AD_PATTERNS):
                pytest.skip(
                    f"smartadtargets add not supported (sandbox): {r.output[:200]}"
                )
            pytest.fail(
                f"smartadtargets add failed (CLI regression?): {r.output[:500]}"
            )

        data = json.loads(r.output)
        first = data[0] if isinstance(data, list) else data.get("AddResults", [{}])[0]
        if "Errors" in first and first["Errors"]:
            err_text = str(first["Errors"])
            if _is_sandbox_error(err_text, extra_patterns=_SMART_AD_PATTERNS):
                pytest.skip(f"smartadtargets add rejected (sandbox): {first['Errors']}")
            pytest.fail(
                f"API rejected smartadtargets add (potential Type-field "
                f"regression from PR #12): {first['Errors']}"
            )

        tid = first["Id"]
        try:
            r = _invoke(
                "smartadtargets",
                "update",
                "--id",
                str(tid),
                "--priority",
                "HIGH",
            )
            assert_success(r, "smartadtargets update")
        finally:
            _invoke("smartadtargets", "delete", "--id", str(tid))


# ── negativekeywordsharedsets ────────────────────────────────────────────


@pytest.mark.integration_write
@pytest.mark.vcr
class TestWriteNegativeKeywordSharedSets:
    def test_add_update_delete(self, unique_suffix):
        r = _invoke(
            "negativekeywordsharedsets",
            "add",
            "--name",
            f"test-nk-{unique_suffix}",
            "--keywords",
            "спам,блок",
        )
        assert_success(r, "negativekeywordsharedsets add")
        nid = parse_add_result(r)

        try:
            r = _invoke(
                "negativekeywordsharedsets",
                "update",
                "--id",
                str(nid),
                "--keywords",
                "спам,блок,мусор",
            )
            assert_success(r, "negativekeywordsharedsets update")
        finally:
            _invoke("negativekeywordsharedsets", "delete", "--id", str(nid))


# NOTE: No ``turbopages`` write tests — the Yandex Direct API ``turbopages``
# service is read-only (``get`` only).  The earlier ``turbopages add`` CLI
# command was a ghost endpoint that never corresponded to any real API
# method and was removed together with its test coverage.
