"""LightClaw Agents Module.

This module provides agent utilities for building AI agents with tools,
skills, and memory management.

Sub-packages
------------
- ``core``     – graph execution, model factory, middleware, event bridge
- ``memory``   – compaction, facts, Qdrant indexing, proactive engine
- ``tools``    – raw tool implementations (browser, file I/O, shell …)
- ``skills``   – built-in skill definitions (SKILL.md + references)
- ``prompts``  – system-prompt markdown templates (en / zh)
- ``scenes``   – pre-configured scenario bundles
- ``utils``    – shared helpers (tokeniser, sanitiser, document parser …)
"""
