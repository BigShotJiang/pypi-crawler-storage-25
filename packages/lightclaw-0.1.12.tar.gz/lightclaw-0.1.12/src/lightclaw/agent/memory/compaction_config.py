"""Compaction configuration model and loader.

Provides fine-grained control over context compaction behavior,
inspired by OpenClaw's compaction-safeguard extension.
"""

from __future__ import annotations

import logging
from dataclasses import dataclass
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from lightclaw.config.config import Config

logger = logging.getLogger(__name__)

# Validation bounds (matching OpenClaw constants)
_MAX_RECENT_TURNS_PRESERVE = 12
_MAX_QUALITY_GUARD_RETRIES = 3
_MIN_HISTORY_SHARE = 0.1
_MAX_HISTORY_SHARE = 0.9

# Valid policy values
_VALID_IDENTIFIER_POLICIES = {"strict", "off", "custom"}


@dataclass(frozen=True)
class CompactionConfig:
    """Configuration for context compaction behavior.

    All compaction uses the safeguard pipeline: structured output with
    5 mandatory sections, identifier preservation policy, adaptive
    chunking, and optional quality guard with retry.

    Attributes:
        recent_turns_preserve: Number of most-recent messages to keep
            verbatim (not summarized). Clamped to 0–12.
        identifier_policy: How opaque identifiers are handled:
            ``"strict"`` preserves all identifiers exactly;
            ``"off"`` allows natural language summarization;
            ``"custom"`` uses *identifier_instructions*.
        identifier_instructions: Custom identifier preservation
            instructions (only used when ``identifier_policy="custom"``).
            Max 4000 characters.
        quality_guard_enabled: Run post-compaction quality audit.
        quality_guard_max_retries: Retries when audit fails (0–3).
        max_history_share: Fraction of context window reserved for
            history (0.1–0.9). Used by adaptive chunking.
        base_chunk_ratio: Default chunk size as fraction of context
            window (0.4 = 40%).
        min_chunk_ratio: Floor for chunk ratio when messages are large.
        safety_margin: Multiplier for token estimates to prevent
            underestimation (1.2 = 20% buffer).
        custom_instructions: Extra instructions appended to the
            compaction prompt.
        timeout_seconds: Timeout for the compaction LLM call.
    """

    recent_turns_preserve: int = 3
    identifier_policy: str = "strict"
    identifier_instructions: str = ""
    quality_guard_enabled: bool = True
    quality_guard_max_retries: int = 1
    max_history_share: float = 0.5
    base_chunk_ratio: float = 0.4
    min_chunk_ratio: float = 0.15
    safety_margin: float = 1.2
    custom_instructions: str = ""
    timeout_seconds: int = 900


def _clamp_int(value: int, lo: int, hi: int) -> int:
    return max(lo, min(hi, value))


def _clamp_float(value: float, lo: float, hi: float) -> float:
    return max(lo, min(hi, value))


def load_compaction_config(app_config: Config | None = None) -> CompactionConfig:
    """Build a validated ``CompactionConfig`` from application config.

    Reads ``agents.compaction`` from the Pydantic config model.  Missing
    or invalid fields fall back to dataclass defaults.  All numeric
    fields are clamped to their valid ranges.
    """
    if app_config is None:
        return CompactionConfig()

    try:
        compaction_cfg = app_config.agents.compaction
    except AttributeError:
        return CompactionConfig()

    # Extract raw values with safe getattr
    identifier_policy = getattr(compaction_cfg, "identifier_policy", "strict")
    if identifier_policy not in _VALID_IDENTIFIER_POLICIES:
        logger.warning(
            "Invalid identifier_policy '%s', falling back to 'strict'",
            identifier_policy,
        )
        identifier_policy = "strict"

    identifier_instructions = getattr(compaction_cfg, "identifier_instructions", "") or ""
    if len(identifier_instructions) > 4000:
        identifier_instructions = identifier_instructions[:4000]

    return CompactionConfig(
        recent_turns_preserve=_clamp_int(
            getattr(compaction_cfg, "recent_turns_preserve", 3),
            0,
            _MAX_RECENT_TURNS_PRESERVE,
        ),
        identifier_policy=identifier_policy,
        identifier_instructions=identifier_instructions,
        quality_guard_enabled=bool(getattr(compaction_cfg, "quality_guard_enabled", True)),
        quality_guard_max_retries=_clamp_int(
            getattr(compaction_cfg, "quality_guard_max_retries", 1),
            0,
            _MAX_QUALITY_GUARD_RETRIES,
        ),
        max_history_share=_clamp_float(
            getattr(compaction_cfg, "max_history_share", 0.5),
            _MIN_HISTORY_SHARE,
            _MAX_HISTORY_SHARE,
        ),
        base_chunk_ratio=_clamp_float(
            getattr(compaction_cfg, "base_chunk_ratio", 0.4),
            0.1,
            0.8,
        ),
        min_chunk_ratio=_clamp_float(
            getattr(compaction_cfg, "min_chunk_ratio", 0.15),
            0.05,
            0.5,
        ),
        safety_margin=_clamp_float(
            getattr(compaction_cfg, "safety_margin", 1.2),
            1.0,
            2.0,
        ),
        custom_instructions=getattr(compaction_cfg, "custom_instructions", "") or "",
        timeout_seconds=_clamp_int(
            getattr(compaction_cfg, "timeout_seconds", 900),
            60,
            3600,
        ),
    )
