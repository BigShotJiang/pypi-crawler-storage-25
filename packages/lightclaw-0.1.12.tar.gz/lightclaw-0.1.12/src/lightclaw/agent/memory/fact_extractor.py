"""Structured fact extraction and conflict resolution pipeline.

Implements the Mem0-style Extract → Match → Decide → Execute loop
that runs asynchronously after each conversation turn.

Usage::

    extractor = FactExtractor(fact_store, embedding_fn, llm)
    result = await extractor.process_turn(user_msg, assistant_msg, turn_id)
    # result.decisions  →  list of FactDecision (ADD/UPDATE/DELETE/NOOP)
"""

from __future__ import annotations

import json
import logging
import re
from collections.abc import Callable, Coroutine
from dataclasses import dataclass, field
from typing import Any

from lightclaw.agent.memory.fact_prompts import format_conflict_prompt, format_extraction_prompt
from lightclaw.agent.memory.fact_store import FactStore
from lightclaw.constant import FACT_MAX_COUNT, FACT_MAX_PER_TURN, FACT_MIN_MESSAGE_LENGTH, FACT_SIMILARITY_THRESHOLD

logger = logging.getLogger(__name__)


# ---------------------------------------------------------------------------
# Data classes
# ---------------------------------------------------------------------------


@dataclass
class FactCandidate:
    """A candidate fact extracted from a conversation turn."""

    content: str
    category: str
    importance: float


@dataclass
class ExistingFact:
    """An existing fact from the database that is similar to a candidate."""

    id: int
    content: str
    category: str
    importance: float
    similarity: float


@dataclass
class FactDecision:
    """The resolved decision for a single candidate fact."""

    action: str  # "ADD" | "UPDATE" | "DELETE" | "NOOP"
    candidate: FactCandidate
    target_fact_id: int | None = None
    merged_content: str | None = None
    reason: str = ""


@dataclass
class FactExtractionResult:
    """Summary of a complete extraction cycle for one turn."""

    candidates_extracted: int = 0
    decisions: list[FactDecision] = field(default_factory=list)
    errors: list[str] = field(default_factory=list)
    token_usage: dict[str, int] = field(
        default_factory=lambda: {"input_tokens": 0, "output_tokens": 0, "total_tokens": 0}
    )


# ---------------------------------------------------------------------------
# Extractor
# ---------------------------------------------------------------------------


class FactExtractor:
    """Mem0-style structured fact extraction pipeline.

    Pipeline stages for each turn:

    1. **Extract**: LLM extracts candidate facts from the turn.
    2. **Match**: For each candidate, find semantically similar existing facts.
    3. **Decide**: LLM decides ADD / UPDATE / DELETE / NOOP.
    4. **Execute**: Apply the decision to :class:`FactStore`.
    """

    def __init__(
        self,
        fact_store: FactStore,
        embedding_fn: Callable[[list[str]], Coroutine[Any, Any, list[list[float]]]] | None = None,
        invoke_llm: Callable[..., Coroutine[Any, Any, str]] | None = None,
        invoke_llm_with_usage: Callable[..., Coroutine[Any, Any, tuple[str, dict[str, int]]]] | None = None,
    ) -> None:
        """Initialise the extractor.

        Args:
            fact_store: The SQLite fact store to read/write facts.
            embedding_fn: Async function that embeds a list of texts.
                          If None, falls back to FTS-only matching.
            invoke_llm: Async function ``(system_prompt, user_prompt) -> str``
                        that calls an LLM. Typically wired to the session's
                        chat model. Used as a fallback when
                        ``invoke_llm_with_usage`` is not provided.
            invoke_llm_with_usage: Preferred async function
                ``(system_prompt, user_prompt) -> (text, usage_dict)`` that
                additionally returns per-call token usage. When present, the
                extractor accumulates token usage scoped strictly to its own
                LLM calls, avoiding cross-contamination with other memory
                workflows that share the same backing model.
        """
        self._store = fact_store
        self._embedding_fn = embedding_fn
        self._invoke_llm = invoke_llm
        self._invoke_llm_with_usage = invoke_llm_with_usage
        # Track last modification so FactInjector can invalidate cache.
        self.last_modified_ms: int = 0
        # Per-process accumulator: reset at the start of each process_turn().
        self._current_usage: dict[str, int] = {
            "input_tokens": 0,
            "output_tokens": 0,
            "total_tokens": 0,
        }

    def set_invoke_llm(
        self,
        invoke_llm: Callable[..., Coroutine[Any, Any, str]],
    ) -> None:
        """Wire the LLM invocation function after construction."""
        self._invoke_llm = invoke_llm

    def set_invoke_llm_with_usage(
        self,
        invoke_llm_with_usage: Callable[..., Coroutine[Any, Any, tuple[str, dict[str, int]]]],
    ) -> None:
        """Wire the usage-aware LLM invocation function after construction."""
        self._invoke_llm_with_usage = invoke_llm_with_usage

    async def _invoke(self, system_prompt: str, user_prompt: str) -> str:
        """Invoke the LLM and accumulate token usage scoped to this extractor.

        Prefers ``invoke_llm_with_usage`` so we can isolate fact-extraction
        token spend from any other concurrent memory workflows (compaction,
        distillation, heartbeat, etc.) that share the same backing model.
        Falls back to the plain ``invoke_llm`` when usage is unavailable.
        """
        if self._invoke_llm_with_usage is not None:
            text, usage = await self._invoke_llm_with_usage(system_prompt, user_prompt)
            if usage:
                self._current_usage["input_tokens"] += int(usage.get("input_tokens") or 0)
                self._current_usage["output_tokens"] += int(usage.get("output_tokens") or 0)
                self._current_usage["total_tokens"] += int(usage.get("total_tokens") or 0)
            return text
        assert self._invoke_llm is not None
        return await self._invoke_llm(system_prompt, user_prompt)

    # ------------------------------------------------------------------
    # Public API
    # ------------------------------------------------------------------

    async def process_turn(
        self,
        user_message: str,
        assistant_message: str,
        turn_id: str,
    ) -> FactExtractionResult:
        """Run the full extraction pipeline for a single turn.

        This is meant to be called as a fire-and-forget background task
        after the agent response has been streamed to the user.

        Args:
            user_message: The user's message text.
            assistant_message: The assistant's response text.
            turn_id: Unique identifier for this conversation turn.

        Returns:
            A :class:`FactExtractionResult` summarising what happened.
        """
        result = FactExtractionResult()

        # Reset the per-turn usage accumulator so we only report tokens for
        # this turn's LLM calls, not any prior ones.
        self._current_usage = {"input_tokens": 0, "output_tokens": 0, "total_tokens": 0}

        # Guard: skip trivially short messages
        if len(user_message.strip()) < FACT_MIN_MESSAGE_LENGTH:
            logger.debug("Skipping fact extraction: user message too short (%d chars)", len(user_message))
            return result

        if self._invoke_llm is None and self._invoke_llm_with_usage is None:
            result.errors.append("No LLM invocation function configured")
            return result

        # Stage 1: Extract candidates
        try:
            candidates = await self._extract_candidates(user_message, assistant_message)
        except Exception as exc:
            logger.exception("Fact extraction failed")
            result.errors.append(f"Extraction error: {exc}")
            return result

        result.candidates_extracted = len(candidates)
        if not candidates:
            return result

        # Stages 2–4: Match, Decide, Execute for each candidate
        for candidate in candidates:
            try:
                similar = await self._find_similar_facts(candidate)
                decision = await self._resolve_conflicts(candidate, similar)
                await self._execute_decision(decision, turn_id)
                result.decisions.append(decision)
            except Exception as exc:
                logger.exception("Fact conflict resolution failed for: %.60s", candidate.content)
                result.errors.append(f"Resolution error for '{candidate.content[:40]}': {exc}")

        # Auto-prune if fact count is getting large
        try:
            await self._store.prune_stale_facts(max_count=FACT_MAX_COUNT)
        except Exception:
            logger.exception("Fact pruning failed")

        if result.decisions:
            import time

            self.last_modified_ms = int(time.time() * 1000)

        # Surface token usage scoped strictly to this extractor's LLM calls.
        result.token_usage = dict(self._current_usage)
        return result

    # ------------------------------------------------------------------
    # Stage 1: Extract candidates
    # ------------------------------------------------------------------

    async def _extract_candidates(
        self,
        user_message: str,
        assistant_message: str,
    ) -> list[FactCandidate]:
        """Call LLM to extract candidate facts from the turn."""
        system_prompt, user_prompt = format_extraction_prompt(
            user_message=user_message,
            assistant_message=assistant_message,
            max_facts=FACT_MAX_PER_TURN,
        )

        raw = await self._invoke(system_prompt, user_prompt)
        return _parse_extraction_response(raw)

    # ------------------------------------------------------------------
    # Stage 2: Match — find similar existing facts
    # ------------------------------------------------------------------

    async def _find_similar_facts(
        self,
        candidate: FactCandidate,
    ) -> list[ExistingFact]:
        """Find existing facts similar to the candidate.

        Uses embedding cosine similarity if available, falls back to FTS5.
        """
        results: list[ExistingFact] = []

        # Embedding-based search (preferred)
        if self._embedding_fn is not None:
            try:
                embeddings = await self._embedding_fn([candidate.content])
                if embeddings and embeddings[0]:
                    matches = await self._store.search_facts_by_embedding(
                        query_embedding=embeddings[0],
                        limit=5,
                        min_score=FACT_SIMILARITY_THRESHOLD,
                    )
                    for m in matches:
                        results.append(
                            ExistingFact(
                                id=m["id"],
                                content=m["content"],
                                category=m["category"],
                                importance=m["importance"],
                                similarity=m["score"],
                            )
                        )
                    if results:
                        return results
            except Exception:
                logger.debug("Embedding search failed, falling back to FTS")

        # FTS fallback
        try:
            fts_matches = await self._store.search_facts_by_text(
                query=candidate.content,
                limit=5,
            )
            for m in fts_matches:
                results.append(
                    ExistingFact(
                        id=m["id"],
                        content=m["content"],
                        category=m["category"],
                        importance=m["importance"],
                        similarity=m.get("score", 0.5),
                    )
                )
        except Exception:
            logger.debug("FTS search failed for candidate: %.40s", candidate.content)

        return results

    # ------------------------------------------------------------------
    # Stage 3: Decide — LLM conflict resolution
    # ------------------------------------------------------------------

    async def _resolve_conflicts(
        self,
        candidate: FactCandidate,
        similar: list[ExistingFact],
    ) -> FactDecision:
        """Ask the LLM to decide ADD/UPDATE/DELETE/NOOP.

        If no similar facts exist, auto-decides ADD without an LLM call.
        Retries up to 2 times when the LLM returns unparseable JSON to avoid
        incorrect fallback-ADD decisions that corrupt the fact store.
        """
        if not similar:
            return FactDecision(action="ADD", candidate=candidate, reason="No similar facts found")

        existing_dicts = [
            {
                "id": f.id,
                "content": f.content,
                "category": f.category,
                "importance": f.importance,
            }
            for f in similar
        ]

        system_prompt, user_prompt = format_conflict_prompt(
            candidate_content=candidate.content,
            candidate_category=candidate.category,
            candidate_importance=candidate.importance,
            existing_facts=existing_dicts,
        )

        max_attempts = 3
        last_raw = ""
        for attempt in range(1, max_attempts + 1):
            raw = await self._invoke(system_prompt, user_prompt)
            last_raw = raw
            decision = _parse_conflict_response(raw, candidate)
            if decision.reason != "JSON parse failed, defaulting to ADD":
                return decision
            logger.warning(
                "Conflict resolution JSON parse failed (attempt %d/%d) for: %.60s",
                attempt,
                max_attempts,
                candidate.content,
            )

        # All retries exhausted — log and fall back to ADD
        logger.error(
            "Conflict resolution failed after %d attempts, falling back to ADD. Last raw response: %.200s",
            max_attempts,
            last_raw,
        )
        return FactDecision(
            action="ADD",
            candidate=candidate,
            reason=f"JSON parse failed after {max_attempts} attempts, defaulting to ADD",
        )

    # ------------------------------------------------------------------
    # Stage 4: Execute — apply decision to FactStore
    # ------------------------------------------------------------------

    async def _execute_decision(
        self,
        decision: FactDecision,
        turn_id: str,
    ) -> None:
        """Apply a single decision to the fact store."""
        action = decision.action.upper()

        if action == "ADD":
            # Compute embedding for the new fact
            embedding = await self._embed_text(decision.candidate.content)
            await self._store.add_fact(
                content=decision.candidate.content,
                category=decision.candidate.category,
                source_turn_id=turn_id,
                embedding=embedding,
                importance=decision.candidate.importance,
            )
            logger.info("Fact ADD: %.60s", decision.candidate.content)

        elif action == "UPDATE" and decision.target_fact_id is not None:
            content = decision.merged_content or decision.candidate.content
            embedding = await self._embed_text(content)
            await self._store.update_fact(
                fact_id=decision.target_fact_id,
                new_content=content,
                source_turn_id=turn_id,
                reason=decision.reason,
                new_embedding=embedding,
                new_importance=decision.candidate.importance,
            )
            logger.info("Fact UPDATE id=%d: %.60s", decision.target_fact_id, content)

        elif action == "DELETE" and decision.target_fact_id is not None:
            await self._store.delete_fact(
                fact_id=decision.target_fact_id,
                source_turn_id=turn_id,
                reason=decision.reason,
            )
            logger.info("Fact DELETE id=%d: %s", decision.target_fact_id, decision.reason)

        elif action == "NOOP":
            logger.debug("Fact NOOP: %.60s (%s)", decision.candidate.content, decision.reason)

        else:
            logger.warning("Unknown fact action: %s", action)

    # ------------------------------------------------------------------
    # Helpers
    # ------------------------------------------------------------------

    async def _embed_text(self, text: str) -> list[float] | None:
        """Embed a single text, returning None if embedding is unavailable."""
        if self._embedding_fn is None:
            return None
        try:
            results = await self._embedding_fn([text])
            return results[0] if results and results[0] else None
        except Exception:
            logger.debug("Embedding failed for text: %.40s", text)
            return None


# ---------------------------------------------------------------------------
# Response parsing helpers
# ---------------------------------------------------------------------------


def _extract_json_from_text(text: str) -> str:
    """Extract the first JSON array or object from LLM response text.

    Handles markdown code fences and stray text before/after JSON.
    """
    # Try to extract from code fence first
    fence_match = re.search(r"```(?:json)?\s*\n?([\s\S]*?)```", text)
    if fence_match:
        return fence_match.group(1).strip()

    # Try to find raw JSON array or object
    for start_char, end_char in [("[", "]"), ("{", "}")]:
        start = text.find(start_char)
        if start == -1:
            continue
        # Find the matching closing bracket
        depth = 0
        for i in range(start, len(text)):
            if text[i] == start_char:
                depth += 1
            elif text[i] == end_char:
                depth -= 1
                if depth == 0:
                    return text[start : i + 1]

    return text.strip()


def _parse_extraction_response(raw: str) -> list[FactCandidate]:
    """Parse the LLM's extraction response into FactCandidate objects."""
    json_str = _extract_json_from_text(raw)
    try:
        data = json.loads(json_str)
    except json.JSONDecodeError:
        logger.warning("Failed to parse extraction JSON: %.200s", raw)
        return []

    if not isinstance(data, list):
        data = [data]

    candidates = []
    for item in data:
        if not isinstance(item, dict):
            continue
        content = str(item.get("content", "")).strip()
        if not content:
            continue
        category = str(item.get("category", "general")).strip().lower()
        try:
            importance = float(item.get("importance", 0.5))
            importance = max(0.0, min(1.0, importance))
        except (ValueError, TypeError):
            importance = 0.5
        candidates.append(FactCandidate(content=content, category=category, importance=importance))

    return candidates[:FACT_MAX_PER_TURN]


def _parse_conflict_response(raw: str, candidate: FactCandidate) -> FactDecision:
    """Parse the LLM's conflict resolution response into a FactDecision."""
    json_str = _extract_json_from_text(raw)
    try:
        data = json.loads(json_str)
    except json.JSONDecodeError:
        logger.warning("Failed to parse conflict JSON: %.200s", raw)
        # Default to ADD when parsing fails
        return FactDecision(action="ADD", candidate=candidate, reason="JSON parse failed, defaulting to ADD")

    if not isinstance(data, dict):
        return FactDecision(action="ADD", candidate=candidate, reason="Invalid response format")

    action = str(data.get("action", "ADD")).upper().strip()
    if action not in {"ADD", "UPDATE", "DELETE", "NOOP"}:
        action = "ADD"

    target_id = data.get("target_fact_id")
    if target_id is not None:
        try:
            target_id = int(target_id)
        except (ValueError, TypeError):
            target_id = None

    merged = data.get("merged_content")
    if merged is not None:
        merged = str(merged).strip() or None

    reason = str(data.get("reason", "")).strip()

    return FactDecision(
        action=action,
        candidate=candidate,
        target_fact_id=target_id,
        merged_content=merged,
        reason=reason,
    )
