"""
Memory backend abstraction layer.

This module decouples backend startup orchestration from concrete backend
implementations:

- MemoryBackend: unified backend protocol (start/stop)
- HybridMemoryBackend: primary implementation (Qdrant + FTS)
- FtsOnlyMemoryBackend: degraded implementation (FTS-only)
- MemoryBackendBootstrapper: primary -> fallback selector
"""

from __future__ import annotations

import logging
import sqlite3
from typing import TYPE_CHECKING, Protocol, runtime_checkable

if TYPE_CHECKING:
    from lightclaw.agent.memory.memory_manager import MemoryManager

logger = logging.getLogger(__name__)


def _is_embedding_configured() -> bool:
    """Module-level wrapper so tests can monkeypatch it."""
    from lightclaw.agent.memory.init_memory_system import is_embedding_configured

    return is_embedding_configured()


@runtime_checkable
class MemoryBackend(Protocol):
    """Memory backend protocol.

    Implementations are responsible for:
    1. Lifecycle management (start / stop)
    2. Injecting adapters into MemoryManager (via set_memory_backend, etc.)
    """

    async def start(self, memory_manager: MemoryManager) -> None:
        """Start backend and inject search adapters into memory_manager."""
        ...

    def stop(self) -> None:
        """Synchronously stop backend and release resources."""
        ...


@runtime_checkable
class MemoryIndexer(Protocol):
    """Indexer interface consumed by MemoryManager."""

    _dirty: bool
    fts_db: sqlite3.Connection

    def read_file(self, rel_path: str, offset: int | None = None, limit: int | None = None) -> str: ...

    async def get_chunk_count(self) -> int: ...

    async def delete_chunks_by_ids(self, chunk_ids: list[str]) -> int: ...

    async def delete_file_chunks(self, rel_path: str) -> None: ...


@runtime_checkable
class MemorySearcher(Protocol):
    """Searcher interface consumed by MemoryManager."""

    embedding_fn: object | None

    async def search(self, query: str, *args, **kwargs): ...


class HybridMemoryBackend:
    """
    Primary backend implementation: Qdrant + SQLite FTS5 (hybrid).

    Encapsulates:
    - QdrantMemoryIndexer (indexing + file watch)
    - QdrantMemorySearcher (retrieval)
    - ProactiveMemoryEngine (optional proactive outreach)
    """

    def __init__(self, working_dir: str) -> None:
        self.working_dir = working_dir
        self._indexer = None
        self._proactive_engine = None

    async def start(self, memory_manager: MemoryManager) -> None:
        """Start hybrid backend and inject search adapters."""
        from lightclaw.agent.memory.init_memory_system import init_memory_system

        indexer, _searcher, proactive_engine = await init_memory_system(
            working_dir=self.working_dir,
            memory_manager=memory_manager,
        )
        self._indexer = indexer
        self._proactive_engine = proactive_engine
        if proactive_engine is not None:
            memory_manager.proactive_engine = proactive_engine
        has_vector = indexer.embedding_fn is not None
        logger.info(
            "✓ Memory backend ready: mode=%s, collection=%s",
            "vector+FTS" if has_vector else "FTS-only (no embedding)",
            getattr(indexer, "collection_name", "?"),
        )

    def stop(self) -> None:
        """Stop hybrid backend resources."""
        from lightclaw.agent.memory.init_memory_system import shutdown_memory_system

        try:
            shutdown_memory_system(self._indexer, self._proactive_engine)
        except Exception as e:
            logger.warning("HybridMemoryBackend stop failed: %s", e)
        finally:
            self._indexer = None
            self._proactive_engine = None


class FtsOnlyMemoryBackend:
    """Degraded backend implementation: SQLite FTS5 only."""

    def __init__(self, working_dir: str) -> None:
        self.working_dir = working_dir
        self._indexer = None
        self._proactive_engine = None

    async def start(self, memory_manager: MemoryManager) -> None:
        from lightclaw.agent.memory.init_memory_system import init_fts_only_system

        indexer, _searcher, proactive_engine = await init_fts_only_system(
            working_dir=self.working_dir,
            memory_manager=memory_manager,
        )
        self._indexer = indexer
        self._proactive_engine = proactive_engine
        if proactive_engine is not None:
            memory_manager.proactive_engine = proactive_engine
        logger.info("✓ Memory backend ready: mode=FTS-only")

    def stop(self) -> None:
        from lightclaw.agent.memory.init_memory_system import shutdown_memory_system

        try:
            shutdown_memory_system(self._indexer, self._proactive_engine)
        except Exception as e:
            logger.warning("FtsOnlyMemoryBackend stop failed: %s", e)
        finally:
            self._indexer = None
            self._proactive_engine = None


class MemoryBackendBootstrapper:
    """Backend startup orchestrator: primary -> fallback."""

    def __init__(self, working_dir: str) -> None:
        self.working_dir = working_dir
        self._backend: MemoryBackend | None = None
        # Track whether the active backend is a degraded fallback so callers
        # can surface this information to the user (e.g. in status APIs).
        self._is_degraded: bool = False

    @property
    def is_degraded(self) -> bool:
        """Return True if the active backend is FTS-only (degraded mode)."""
        return self._is_degraded

    async def start(self, memory_manager: MemoryManager) -> MemoryBackend | None:
        # Skip Qdrant entirely when no embedding provider is configured.
        # Creating an AsyncQdrantClient (even with client=None path) still mmap-loads
        # the local Qdrant data directory, consuming 50-80 MB for no benefit.
        # Jumping straight to FTS-only avoids that cost.
        if not _is_embedding_configured():
            logger.info("Embedding not configured — starting FTS-only backend (Qdrant skipped).")
            fts_backend: MemoryBackend = FtsOnlyMemoryBackend(working_dir=self.working_dir)
            try:
                await fts_backend.start(memory_manager)
                self._backend = fts_backend
                self._is_degraded = False  # intentional FTS-only, not a fallback
                return self._backend
            except Exception as fts_exc:
                logger.error("✗ FTS-only backend init failed: %s", fts_exc)
                self._backend = None
                self._is_degraded = False
                return None

        backend: MemoryBackend = HybridMemoryBackend(working_dir=self.working_dir)
        try:
            await backend.start(memory_manager)
            self._backend = backend
            self._is_degraded = False
            return self._backend
        except Exception as exc:
            logger.warning(
                "✗ Hybrid backend init failed, falling back to FTS-only: %s. "
                "Semantic search will be unavailable until the issue is resolved. "
                "Check EMBEDDING_BASE_URL / EMBEDDING_MODEL_NAME configuration.",
                exc,
            )

        fallback: MemoryBackend = FtsOnlyMemoryBackend(working_dir=self.working_dir)
        try:
            await fallback.start(memory_manager)
            self._backend = fallback
            # Mark as degraded so status APIs and health checks can surface this.
            self._is_degraded = True
            logger.warning(
                "⚠ Memory running in degraded FTS-only mode (vector search unavailable). "
                "Semantic recall quality is reduced. Fix the embedding configuration and "
                "restart to restore full hybrid search."
            )
            return self._backend
        except Exception as fallback_exc:
            logger.error(
                "✗ Memory search unavailable: both Hybrid and FTS-only init failed: %s",
                fallback_exc,
            )
            self._backend = None
            self._is_degraded = False
            return None

    def stop(self) -> None:
        if self._backend is None:
            return
        try:
            self._backend.stop()
        finally:
            self._backend = None
