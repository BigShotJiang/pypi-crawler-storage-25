"""Three-state event-time extractor for memory chunks.

Pure-function module — no LLM calls, no I/O, no external dependencies.
For each chunk this returns an ``EventTimeResult`` with:

  - ``event_at``        : ISO date "YYYY-MM-DD" — when the event itself occurs
  - ``event_kind``      : one of past_explicit / ongoing / future_explicit /
                          path_dated / unknown
  - ``confidence``      : 0.0 ~ 1.0

Algorithm (priority order, see docs/memory_event_time_plan.md §3.1):

  1. Resolve ``anchor_date`` from path (memory/YYYY-MM-DD.md) or fall back
     to the day part of ``created_at_iso``.
  2. ``temporal_resolver.resolve_first`` against the snippet:
       - first hard match with start > anchor_date  → future_explicit
       - first hard match with end   < anchor_date  → past_explicit
       - cross-anchor (e.g. "this week")            → past_explicit, conf 0.8
  3. If snippet contains a soft "ongoing" hint (最近 / lately ...)  → ongoing,
     event_at locked to created_at-day. This deliberately fixes the
     "X months ago you were still busy" hallucination by anchoring "ongoing"
     to **the day the user wrote it down**, not to "now".
  4. If path itself is dated and no temporal expression appeared → path_dated.
  5. Otherwise → unknown, event_at = created_at-day.
"""

from __future__ import annotations

import logging
import re
from dataclasses import dataclass
from datetime import UTC, date, datetime

from lightclaw.agent.memory.temporal_resolver import (
    has_ongoing_hint,
    resolve_first,
)

logger = logging.getLogger(__name__)

# Event kinds — exposed as constants so callers don't have to hard-code strings.
EVENT_PAST_EXPLICIT = "past_explicit"
EVENT_ONGOING = "ongoing"
EVENT_FUTURE_EXPLICIT = "future_explicit"
EVENT_PATH_DATED = "path_dated"
EVENT_UNKNOWN = "unknown"

# Confidence levels — empirical defaults from §1.1 of the plan.
_CONF_EXPLICIT = 1.0
_CONF_PATH_DATED = 0.7
_CONF_ONGOING = 0.6
_CONF_UNKNOWN = 0.3
_CONF_CROSS_ANCHOR = 0.8

# Path anchor: ``memory/YYYY-MM-DD.md`` (mirrors qdrant_searcher convention).
_DATED_MEMORY_PATH_RE = re.compile(r"(?:^|/)memory/(\d{4})-(\d{2})-(\d{2})\.md$")


@dataclass(frozen=True)
class EventTimeResult:
    """Resolved event-time triple for a memory chunk."""

    event_at: str  # ISO date "YYYY-MM-DD"
    event_kind: str  # one of EVENT_*
    confidence: float  # 0.0 ~ 1.0


def _parse_anchor_date(rel_path: str, created_at_iso: str) -> tuple[date, bool]:
    """Return ``(anchor_date, path_dated)``.

    *path_dated* is True when the anchor was derived from a ``memory/YYYY-MM-DD.md``
    path. It is used by the extractor to know whether the path-dated branch
    should fire when no temporal expression is present in the snippet.
    """
    match = _DATED_MEMORY_PATH_RE.search(rel_path or "")
    if match:
        try:
            return date(int(match.group(1)), int(match.group(2)), int(match.group(3))), True
        except ValueError:
            logger.debug("event_time_extractor: invalid date in path %s", rel_path)

    if created_at_iso:
        try:
            dt = datetime.fromisoformat(created_at_iso.replace("Z", "+00:00"))
            if dt.tzinfo is None:
                dt = dt.replace(tzinfo=UTC)
            return dt.astimezone(UTC).date(), False
        except (ValueError, TypeError):
            logger.debug("event_time_extractor: invalid created_at %s", created_at_iso)

    return datetime.now(UTC).date(), False


def _detect_language(text: str) -> str:
    """Crude CJK detection — used only to bias resolve_first scan order."""
    for ch in text:
        if "\u4e00" <= ch <= "\u9fff":
            return "zh"
    return "en"


def extract_event_time(
    snippet: str,
    rel_path: str,
    created_at_iso: str,
) -> EventTimeResult:
    """Resolve the three-state event time for a chunk.

    See module docstring for the algorithm. Returned ``event_at`` is always
    an ISO date string ``YYYY-MM-DD`` (no time-of-day, avoids UTC/local skew).
    """
    text = snippet or ""
    anchor, path_dated = _parse_anchor_date(rel_path, created_at_iso)
    created_day = (
        anchor if not path_dated and not _is_created_at_valid(created_at_iso) else _created_day(created_at_iso, anchor)
    )

    # Step 2: scan for an explicit (hard) temporal expression.
    language = _detect_language(text)
    resolved = resolve_first(text, ref=anchor, language=language) if text else None

    if resolved is not None:
        if resolved.start > anchor:
            return EventTimeResult(
                event_at=resolved.start.isoformat(),
                event_kind=EVENT_FUTURE_EXPLICIT,
                confidence=_CONF_EXPLICIT,
            )
        if resolved.end < anchor:
            return EventTimeResult(
                event_at=resolved.end.isoformat(),
                event_kind=EVENT_PAST_EXPLICIT,
                confidence=_CONF_EXPLICIT,
            )
        # Range straddles the anchor (e.g. "this week"). Keep anchor day with
        # reduced confidence and treat as past — the event has already started.
        return EventTimeResult(
            event_at=anchor.isoformat(),
            event_kind=EVENT_PAST_EXPLICIT,
            confidence=_CONF_CROSS_ANCHOR,
        )

    # Step 3: soft hint (最近 / lately ...) → ongoing, anchored to created day.
    if has_ongoing_hint(text):
        return EventTimeResult(
            event_at=created_day.isoformat(),
            event_kind=EVENT_ONGOING,
            confidence=_CONF_ONGOING,
        )

    # Step 4: path itself supplies the date.
    if path_dated:
        return EventTimeResult(
            event_at=anchor.isoformat(),
            event_kind=EVENT_PATH_DATED,
            confidence=_CONF_PATH_DATED,
        )

    # Step 5: unknown — fall back to the created-at day.
    return EventTimeResult(
        event_at=created_day.isoformat(),
        event_kind=EVENT_UNKNOWN,
        confidence=_CONF_UNKNOWN,
    )


def _is_created_at_valid(created_at_iso: str) -> bool:
    if not created_at_iso:
        return False
    try:
        datetime.fromisoformat(created_at_iso.replace("Z", "+00:00"))
        return True
    except (ValueError, TypeError):
        return False


def _created_day(created_at_iso: str, fallback: date) -> date:
    if not created_at_iso:
        return fallback
    try:
        dt = datetime.fromisoformat(created_at_iso.replace("Z", "+00:00"))
        if dt.tzinfo is None:
            dt = dt.replace(tzinfo=UTC)
        return dt.astimezone(UTC).date()
    except (ValueError, TypeError):
        return fallback
