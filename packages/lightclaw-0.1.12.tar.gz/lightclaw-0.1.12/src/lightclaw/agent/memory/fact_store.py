"""SQLite-backed structured fact storage for LightClaw memory.

Provides :class:`FactStore`, managing the ``facts``, ``fact_history``,
and ``facts_fts`` tables within the existing ``messages.db`` database.

This implements the storage layer of the Mem0-style structured memory
pipeline: facts are individual, self-contained sentences about the user
that can be independently created, updated, and soft-deleted.

Database location::

    {working_dir}/memory/messages.db

Vector similarity is computed in-process via numpy (no Qdrant dependency)
because the fact table is expected to remain small (< 1000 rows).
"""

from __future__ import annotations

import logging
import sqlite3
import struct
import time
from pathlib import Path
from typing import Any

logger = logging.getLogger(__name__)

# Valid fact categories.
FACT_CATEGORIES = frozenset(
    {
        "preference",
        "biographical",
        "project",
        "technical",
        "behavioral",
        "medical",
        "general",
    }
)


def _now_ms() -> int:
    """Current UTC time in milliseconds since epoch."""
    return int(time.time() * 1000)


def _pack_embedding(embedding: list[float]) -> bytes:
    """Serialize a float32 vector to bytes for BLOB storage."""
    return struct.pack(f"<{len(embedding)}f", *embedding)


def _unpack_embedding(blob: bytes) -> list[float]:
    """Deserialize a float32 vector from BLOB storage."""
    count = len(blob) // 4
    return list(struct.unpack(f"<{count}f", blob))


def _cosine_similarity(a: list[float], b: list[float]) -> float:
    """Compute cosine similarity between two vectors (pure Python fallback).

    For < 1000 facts this is fast enough (< 5 ms).  If numpy is available
    it is used for better performance; otherwise a pure-Python loop is used.
    """
    try:
        import numpy as np

        va = np.asarray(a, dtype=np.float32)
        vb = np.asarray(b, dtype=np.float32)
        dot = float(np.dot(va, vb))
        norm = float(np.linalg.norm(va) * np.linalg.norm(vb))
        return dot / norm if norm > 0 else 0.0
    except ImportError:
        dot = sum(x * y for x, y in zip(a, b, strict=False))
        norm_a = sum(x * x for x in a) ** 0.5
        norm_b = sum(x * x for x in b) ** 0.5
        norm = norm_a * norm_b
        return dot / norm if norm > 0 else 0.0


class FactStore:
    """Structured fact CRUD backed by SQLite.

    Lifecycle::

        store = FactStore(db_dir)
        await store.start()      # create tables / open connection
        ...
        await store.close()      # release connection
    """

    def __init__(self, db_dir: str | Path) -> None:
        """Initialise store (does **not** open the database yet).

        Args:
            db_dir: Directory where ``messages.db`` is located.
                    Typically ``{WORKING_DIR}/memory``.
        """
        self._db_dir = Path(db_dir)
        self._db_path = self._db_dir / "messages.db"
        self._conn: sqlite3.Connection | None = None

    # ------------------------------------------------------------------
    # Lifecycle
    # ------------------------------------------------------------------

    async def start(self) -> None:
        """Open the database and create fact tables if they don't exist."""
        if self._conn is not None:
            return

        self._db_dir.mkdir(parents=True, exist_ok=True)

        self._conn = sqlite3.connect(
            str(self._db_path),
            check_same_thread=False,
        )
        self._conn.execute("PRAGMA journal_mode=WAL")
        self._conn.execute("PRAGMA foreign_keys=ON")

        await self._create_tables()
        logger.info("FactStore opened: %s", self._db_path)

    async def close(self) -> None:
        """Close the database connection."""
        if self._conn is not None:
            self._conn.close()
            self._conn = None
            logger.info("FactStore closed.")

    # ------------------------------------------------------------------
    # Table creation
    # ------------------------------------------------------------------

    async def _create_tables(self) -> None:
        """Create fact-related tables (idempotent)."""
        assert self._conn is not None

        cursor = self._conn.cursor()
        try:
            cursor.execute("BEGIN")

            # Core facts table
            cursor.execute(
                """
                CREATE TABLE IF NOT EXISTS facts (
                    id              INTEGER PRIMARY KEY AUTOINCREMENT,
                    content         TEXT    NOT NULL,
                    category        TEXT    NOT NULL DEFAULT 'general',
                    embedding       BLOB,
                    source_turn_id  TEXT    NOT NULL,
                    importance      REAL    NOT NULL DEFAULT 0.5,
                    access_count    INTEGER NOT NULL DEFAULT 0,
                    is_active       INTEGER NOT NULL DEFAULT 1,
                    created_at      INTEGER NOT NULL,
                    updated_at      INTEGER NOT NULL
                )
                """
            )
            cursor.execute("CREATE INDEX IF NOT EXISTS idx_facts_category ON facts (category, is_active)")
            cursor.execute("CREATE INDEX IF NOT EXISTS idx_facts_active ON facts (is_active, updated_at DESC)")
            cursor.execute("CREATE INDEX IF NOT EXISTS idx_facts_importance ON facts (importance DESC)")

            # FTS5 virtual table for text search
            # Use content-less FTS (content=facts, content_rowid=id) so
            # updates/deletes are handled via explicit FTS commands.
            cursor.execute(
                """
                CREATE VIRTUAL TABLE IF NOT EXISTS facts_fts USING fts5(
                    content,
                    content=facts,
                    content_rowid=id,
                    tokenize='unicode61'
                )
                """
            )

            # Triggers to keep FTS in sync with the facts table.
            cursor.execute(
                """
                CREATE TRIGGER IF NOT EXISTS facts_ai AFTER INSERT ON facts BEGIN
                    INSERT INTO facts_fts(rowid, content) VALUES (new.id, new.content);
                END
                """
            )
            cursor.execute(
                """
                CREATE TRIGGER IF NOT EXISTS facts_ad AFTER DELETE ON facts BEGIN
                    INSERT INTO facts_fts(facts_fts, rowid, content)
                        VALUES('delete', old.id, old.content);
                END
                """
            )
            cursor.execute(
                """
                CREATE TRIGGER IF NOT EXISTS facts_au AFTER UPDATE OF content ON facts BEGIN
                    INSERT INTO facts_fts(facts_fts, rowid, content)
                        VALUES('delete', old.id, old.content);
                    INSERT INTO facts_fts(rowid, content) VALUES (new.id, new.content);
                END
                """
            )

            # Version history for auditing
            cursor.execute(
                """
                CREATE TABLE IF NOT EXISTS fact_history (
                    id              INTEGER PRIMARY KEY AUTOINCREMENT,
                    fact_id         INTEGER NOT NULL,
                    action          TEXT    NOT NULL,
                    old_content     TEXT,
                    new_content     TEXT,
                    source_turn_id  TEXT    NOT NULL,
                    reason          TEXT,
                    created_at      INTEGER NOT NULL,
                    FOREIGN KEY (fact_id) REFERENCES facts(id)
                )
                """
            )
            cursor.execute("CREATE INDEX IF NOT EXISTS idx_fh_fact ON fact_history (fact_id, created_at DESC)")

            cursor.execute("COMMIT")
        except Exception:
            cursor.execute("ROLLBACK")
            raise
        finally:
            cursor.close()

    # ------------------------------------------------------------------
    # Fact CRUD
    # ------------------------------------------------------------------

    async def add_fact(
        self,
        content: str,
        category: str,
        source_turn_id: str,
        embedding: list[float] | None = None,
        importance: float = 0.5,
    ) -> int:
        """Insert a new fact and record ADD in history.

        Args:
            content: The fact text (a single self-contained sentence).
            category: One of :data:`FACT_CATEGORIES`.
            source_turn_id: ID of the conversation turn that produced this fact.
            embedding: Optional pre-computed embedding vector.
            importance: Importance score 0.0–1.0.

        Returns:
            The auto-generated fact row ID.
        """
        assert self._conn is not None

        if category not in FACT_CATEGORIES:
            category = "general"

        now = _now_ms()
        emb_blob = _pack_embedding(embedding) if embedding else None

        cursor = self._conn.cursor()
        try:
            cursor.execute("BEGIN")
            cursor.execute(
                """
                INSERT INTO facts
                    (content, category, embedding, source_turn_id,
                     importance, access_count, is_active, created_at, updated_at)
                VALUES (?, ?, ?, ?, ?, 0, 1, ?, ?)
                """,
                (content, category, emb_blob, source_turn_id, importance, now, now),
            )
            fact_id: int = cursor.lastrowid  # type: ignore[assignment]

            # Record in history
            cursor.execute(
                """
                INSERT INTO fact_history
                    (fact_id, action, old_content, new_content,
                     source_turn_id, reason, created_at)
                VALUES (?, 'ADD', NULL, ?, ?, 'Initial extraction', ?)
                """,
                (fact_id, content, source_turn_id, now),
            )

            cursor.execute("COMMIT")
            logger.debug("Fact added: id=%d, category=%s, content=%.60s", fact_id, category, content)
            return fact_id

        except Exception:
            cursor.execute("ROLLBACK")
            raise
        finally:
            cursor.close()

    async def update_fact(
        self,
        fact_id: int,
        new_content: str,
        source_turn_id: str,
        reason: str = "",
        new_embedding: list[float] | None = None,
        new_importance: float | None = None,
    ) -> None:
        """Update an existing fact's content and record UPDATE in history.

        Args:
            fact_id: ID of the fact to update.
            new_content: Replacement text.
            source_turn_id: ID of the turn that triggered this update.
            reason: LLM reasoning for the update.
            new_embedding: Optional replacement embedding.
            new_importance: Optional new importance score.
        """
        assert self._conn is not None

        now = _now_ms()

        cursor = self._conn.cursor()
        try:
            cursor.execute("BEGIN")

            # Fetch old content for history
            row = cursor.execute("SELECT content FROM facts WHERE id = ?", (fact_id,)).fetchone()
            if row is None:
                cursor.execute("ROLLBACK")
                logger.warning("update_fact: fact_id=%d not found", fact_id)
                return
            old_content = row[0]

            # Build dynamic SET clause
            updates = ["content = ?", "source_turn_id = ?", "updated_at = ?"]
            params: list[Any] = [new_content, source_turn_id, now]

            if new_embedding is not None:
                updates.append("embedding = ?")
                params.append(_pack_embedding(new_embedding))

            if new_importance is not None:
                updates.append("importance = ?")
                params.append(new_importance)

            params.append(fact_id)
            cursor.execute(
                f"UPDATE facts SET {', '.join(updates)} WHERE id = ?",
                params,
            )

            # Record in history
            cursor.execute(
                """
                INSERT INTO fact_history
                    (fact_id, action, old_content, new_content,
                     source_turn_id, reason, created_at)
                VALUES (?, 'UPDATE', ?, ?, ?, ?, ?)
                """,
                (fact_id, old_content, new_content, source_turn_id, reason, now),
            )

            cursor.execute("COMMIT")
            logger.debug("Fact updated: id=%d, old=%.40s → new=%.40s", fact_id, old_content, new_content)

        except Exception:
            cursor.execute("ROLLBACK")
            raise
        finally:
            cursor.close()

    async def delete_fact(
        self,
        fact_id: int,
        source_turn_id: str,
        reason: str = "",
    ) -> None:
        """Soft-delete a fact (set is_active=0) and record DELETE in history.

        Args:
            fact_id: ID of the fact to delete.
            source_turn_id: ID of the turn that triggered deletion.
            reason: LLM reasoning for deletion.
        """
        assert self._conn is not None

        now = _now_ms()

        cursor = self._conn.cursor()
        try:
            cursor.execute("BEGIN")

            row = cursor.execute("SELECT content FROM facts WHERE id = ?", (fact_id,)).fetchone()
            if row is None:
                cursor.execute("ROLLBACK")
                logger.warning("delete_fact: fact_id=%d not found", fact_id)
                return
            old_content = row[0]

            cursor.execute(
                "UPDATE facts SET is_active = 0, updated_at = ? WHERE id = ?",
                (now, fact_id),
            )

            cursor.execute(
                """
                INSERT INTO fact_history
                    (fact_id, action, old_content, new_content,
                     source_turn_id, reason, created_at)
                VALUES (?, 'DELETE', ?, NULL, ?, ?, ?)
                """,
                (fact_id, old_content, source_turn_id, reason, now),
            )

            cursor.execute("COMMIT")
            logger.debug("Fact soft-deleted: id=%d, content=%.60s", fact_id, old_content)

        except Exception:
            cursor.execute("ROLLBACK")
            raise
        finally:
            cursor.close()

    # ------------------------------------------------------------------
    # Query
    # ------------------------------------------------------------------

    async def get_fact(self, fact_id: int) -> dict[str, Any] | None:
        """Retrieve a single fact by ID (including inactive ones)."""
        assert self._conn is not None

        row = self._conn.execute(
            """
            SELECT id, content, category, importance, access_count,
                   is_active, source_turn_id, created_at, updated_at
            FROM facts WHERE id = ?
            """,
            (fact_id,),
        ).fetchone()

        if row is None:
            return None
        return _row_to_dict(row)

    async def get_all_active_facts(self) -> list[dict[str, Any]]:
        """Return all active (non-deleted) facts, newest first."""
        assert self._conn is not None

        rows = self._conn.execute(
            """
            SELECT id, content, category, importance, access_count,
                   is_active, source_turn_id, created_at, updated_at
            FROM facts
            WHERE is_active = 1
            ORDER BY updated_at DESC
            """
        ).fetchall()

        return [_row_to_dict(r) for r in rows]

    async def search_facts_by_embedding(
        self,
        query_embedding: list[float],
        limit: int = 10,
        min_score: float = 0.5,
    ) -> list[dict[str, Any]]:
        """Find similar facts by cosine similarity against stored embeddings.

        Only searches active facts that have embeddings.

        Args:
            query_embedding: The query vector.
            limit: Maximum results to return.
            min_score: Minimum cosine similarity threshold.

        Returns:
            List of fact dicts with an added ``score`` key, sorted by
            similarity descending.
        """
        assert self._conn is not None

        # Load all active facts with embeddings
        rows = self._conn.execute(
            """
            SELECT id, content, category, importance, access_count,
                   is_active, source_turn_id, created_at, updated_at, embedding
            FROM facts
            WHERE is_active = 1 AND embedding IS NOT NULL
            """
        ).fetchall()

        scored: list[tuple[float, dict[str, Any]]] = []
        for row in rows:
            emb_blob = row[9]
            stored_emb = _unpack_embedding(emb_blob)
            score = _cosine_similarity(query_embedding, stored_emb)
            if score >= min_score:
                d = _row_to_dict(row[:9])
                d["score"] = round(score, 4)
                scored.append((score, d))

        scored.sort(key=lambda x: x[0], reverse=True)
        return [d for _, d in scored[:limit]]

    async def search_facts_by_text(
        self,
        query: str,
        limit: int = 10,
    ) -> list[dict[str, Any]]:
        """Full-text search on active facts using FTS5.

        Args:
            query: Search query (FTS5 MATCH syntax).
            limit: Maximum results.

        Returns:
            List of fact dicts with an added ``score`` key (BM25 rank).
        """
        assert self._conn is not None

        # Sanitize query for FTS5: remove special chars that cause syntax errors
        safe_query = _sanitize_fts_query(query)
        if not safe_query:
            return []

        try:
            rows = self._conn.execute(
                """
                SELECT f.id, f.content, f.category, f.importance, f.access_count,
                       f.is_active, f.source_turn_id, f.created_at, f.updated_at,
                       rank
                FROM facts_fts fts
                JOIN facts f ON f.id = fts.rowid
                WHERE facts_fts MATCH ? AND f.is_active = 1
                ORDER BY rank
                LIMIT ?
                """,
                (safe_query, limit),
            ).fetchall()
        except sqlite3.OperationalError:
            logger.debug("FTS query failed for: %s", safe_query)
            return []

        result = []
        for row in rows:
            d = _row_to_dict(row[:9])
            # FTS5 rank is negative (lower = more relevant), normalize to 0–1
            d["score"] = round(1.0 / (1.0 + abs(row[9])), 4)
            result.append(d)
        return result

    async def get_facts_by_category(self, category: str) -> list[dict[str, Any]]:
        """Return all active facts in a given category."""
        assert self._conn is not None

        rows = self._conn.execute(
            """
            SELECT id, content, category, importance, access_count,
                   is_active, source_turn_id, created_at, updated_at
            FROM facts
            WHERE is_active = 1 AND category = ?
            ORDER BY importance DESC, updated_at DESC
            """,
            (category,),
        ).fetchall()

        return [_row_to_dict(r) for r in rows]

    async def get_active_facts_by_categories(self, categories: list[str]) -> list[dict[str, Any]]:
        """Return all active facts whose category is in *categories*.

        More efficient than calling :meth:`get_facts_by_category` in a loop
        because it issues a single SQL query with an IN clause.

        Args:
            categories: List of category names to include.

        Returns:
            Facts ordered by importance descending, then updated_at descending.
        """
        assert self._conn is not None

        if not categories:
            return []

        placeholders = ",".join("?" for _ in categories)
        rows = self._conn.execute(
            f"""
            SELECT id, content, category, importance, access_count,
                   is_active, source_turn_id, created_at, updated_at
            FROM facts
            WHERE is_active = 1 AND category IN ({placeholders})
            ORDER BY importance DESC, updated_at DESC
            """,
            categories,
        ).fetchall()

        return [_row_to_dict(r) for r in rows]

    # ------------------------------------------------------------------
    # Access tracking & maintenance
    # ------------------------------------------------------------------

    async def increment_access(self, fact_ids: list[int]) -> None:
        """Bump access_count for the given facts (called on retrieval)."""
        if not fact_ids:
            return
        assert self._conn is not None

        placeholders = ",".join("?" for _ in fact_ids)
        self._conn.execute(
            f"UPDATE facts SET access_count = access_count + 1 WHERE id IN ({placeholders})",
            fact_ids,
        )
        self._conn.commit()

    async def count_active_facts(self) -> int:
        """Return the number of active facts."""
        assert self._conn is not None
        row = self._conn.execute("SELECT COUNT(*) FROM facts WHERE is_active = 1").fetchone()
        return row[0] if row else 0

    async def prune_stale_facts(
        self,
        max_count: int = 500,
        min_importance: float = 0.3,
        max_age_days: int = 30,
    ) -> int:
        """Soft-delete low-value facts when total count exceeds *max_count*.

        Targets facts that are:
        - never accessed (access_count = 0)
        - low importance (< min_importance)
        - old (updated_at > max_age_days ago)

        Returns:
            Number of facts pruned.
        """
        assert self._conn is not None

        count = await self.count_active_facts()
        if count <= max_count:
            return 0

        cutoff_ms = _now_ms() - (max_age_days * 86400 * 1000)

        cursor = self._conn.execute(
            """
            UPDATE facts SET is_active = 0, updated_at = ?
            WHERE is_active = 1
              AND access_count = 0
              AND importance < ?
              AND updated_at < ?
            """,
            (_now_ms(), min_importance, cutoff_ms),
        )
        self._conn.commit()
        pruned = cursor.rowcount
        if pruned:
            logger.info("Pruned %d stale facts (count was %d, max %d)", pruned, count, max_count)
        return pruned

    # ------------------------------------------------------------------
    # History
    # ------------------------------------------------------------------

    async def get_fact_history(self, fact_id: int) -> list[dict[str, Any]]:
        """Return the change history for a fact (newest first)."""
        assert self._conn is not None

        rows = self._conn.execute(
            """
            SELECT id, fact_id, action, old_content, new_content,
                   source_turn_id, reason, created_at
            FROM fact_history
            WHERE fact_id = ?
            ORDER BY created_at DESC
            """,
            (fact_id,),
        ).fetchall()

        return [
            {
                "id": r[0],
                "fact_id": r[1],
                "action": r[2],
                "old_content": r[3],
                "new_content": r[4],
                "source_turn_id": r[5],
                "reason": r[6],
                "created_at": r[7],
            }
            for r in rows
        ]


# ---------------------------------------------------------------------------
# Module-level helpers
# ---------------------------------------------------------------------------


def _row_to_dict(row: tuple) -> dict[str, Any]:
    """Convert a 9-column fact row to a dict."""
    return {
        "id": row[0],
        "content": row[1],
        "category": row[2],
        "importance": row[3],
        "access_count": row[4],
        "is_active": row[5],
        "source_turn_id": row[6],
        "created_at": row[7],
        "updated_at": row[8],
    }


def _sanitize_fts_query(query: str) -> str:
    """Sanitize a query string for SQLite FTS5 MATCH syntax.

    Removes characters that would cause FTS5 syntax errors and wraps
    individual tokens in double quotes for literal matching.
    """
    import re

    # Remove FTS5 special operators
    cleaned = re.sub(r'["\'\(\)\*\+\-\^~{}]', " ", query)
    tokens = cleaned.split()
    if not tokens:
        return ""
    # Quote each token for literal matching, join with OR
    return " OR ".join(f'"{t}"' for t in tokens[:10])
