"""Multilingual keyword extraction for FTS-only search mode.

When no embedding provider is available, search falls back to SQLite FTS5.
FTS works best with precise keywords, but user queries are often colloquial.
This module extracts meaningful keywords from natural-language queries to
improve FTS recall.
"""

from __future__ import annotations

import re

# ── English stop words ────────────────────────────────────────────────────────
STOP_WORDS_EN: frozenset[str] = frozenset(
    {
        # articles / determiners
        "a",
        "an",
        "the",
        "this",
        "that",
        "these",
        "those",
        # pronouns
        "i",
        "me",
        "my",
        "we",
        "our",
        "you",
        "your",
        "he",
        "she",
        "it",
        "they",
        "them",
        # common verbs
        "is",
        "are",
        "was",
        "were",
        "be",
        "been",
        "being",
        "have",
        "has",
        "had",
        "do",
        "does",
        "did",
        "will",
        "would",
        "could",
        "should",
        "can",
        "may",
        "might",
        # prepositions
        "in",
        "on",
        "at",
        "to",
        "for",
        "of",
        "with",
        "by",
        "from",
        "about",
        "into",
        "through",
        "during",
        "before",
        "after",
        "above",
        "below",
        "between",
        "under",
        "over",
        # conjunctions
        "and",
        "or",
        "but",
        "if",
        "then",
        "because",
        "as",
        "while",
        "when",
        "where",
        "what",
        "which",
        "who",
        "how",
        "why",
        # vague time words
        "yesterday",
        "today",
        "tomorrow",
        "earlier",
        "later",
        "recently",
        "ago",
        "just",
        "now",
        "thing",
        "things",
        "stuff",
        "something",
        "anything",
        "everything",
        "nothing",
        # request words
        "please",
        "help",
        "find",
        "show",
        "get",
        "tell",
        "give",
    }
)

# ── Spanish stop words ────────────────────────────────────────────────────────
STOP_WORDS_ES: frozenset[str] = frozenset(
    {
        "el",
        "la",
        "los",
        "las",
        "un",
        "una",
        "unos",
        "unas",
        "este",
        "esta",
        "ese",
        "esa",
        "yo",
        "me",
        "mi",
        "nosotros",
        "nosotras",
        "tu",
        "tus",
        "usted",
        "ustedes",
        "ellos",
        "ellas",
        "de",
        "del",
        "a",
        "en",
        "con",
        "por",
        "para",
        "sobre",
        "entre",
        "y",
        "o",
        "pero",
        "si",
        "porque",
        "como",
        "es",
        "son",
        "fue",
        "fueron",
        "ser",
        "estar",
        "haber",
        "tener",
        "hacer",
        "ayer",
        "hoy",
        "mañana",
        "antes",
        "despues",
        "después",
        "ahora",
        "recientemente",
        "que",
        "qué",
        "cómo",
        "cuando",
        "cuándo",
        "donde",
        "dónde",
        "porqué",
        "favor",
        "ayuda",
    }
)

# ── Portuguese stop words ─────────────────────────────────────────────────────
STOP_WORDS_PT: frozenset[str] = frozenset(
    {
        "os",
        "as",
        "um",
        "uma",
        "uns",
        "umas",
        "este",
        "esta",
        "esse",
        "essa",
        "eu",
        "me",
        "meu",
        "minha",
        "nos",
        "nós",
        "você",
        "vocês",
        "ele",
        "ela",
        "eles",
        "elas",
        "de",
        "do",
        "da",
        "em",
        "com",
        "por",
        "para",
        "sobre",
        "entre",
        "e",
        "ou",
        "mas",
        "se",
        "porque",
        "como",
        "é",
        "são",
        "foi",
        "foram",
        "ser",
        "estar",
        "ter",
        "fazer",
        "ontem",
        "hoje",
        "amanhã",
        "antes",
        "depois",
        "agora",
        "recentemente",
        "que",
        "quê",
        "quando",
        "onde",
        "porquê",
        "favor",
        "ajuda",
    }
)

# ── Arabic stop words ─────────────────────────────────────────────────────────
STOP_WORDS_AR: frozenset[str] = frozenset(
    {
        "ال",
        "و",
        "أو",
        "لكن",
        "ثم",
        "بل",
        "أنا",
        "نحن",
        "هو",
        "هي",
        "هم",
        "هذا",
        "هذه",
        "ذلك",
        "تلك",
        "هنا",
        "هناك",
        "من",
        "إلى",
        "الى",
        "في",
        "على",
        "عن",
        "مع",
        "بين",
        "ل",
        "ب",
        "ك",
        "كان",
        "كانت",
        "يكون",
        "تكون",
        "صار",
        "أصبح",
        "يمكن",
        "ممكن",
        "بالأمس",
        "امس",
        "اليوم",
        "غدا",
        "الآن",
        "قبل",
        "بعد",
        "مؤخرا",
        "لماذا",
        "كيف",
        "ماذا",
        "متى",
        "أين",
        "هل",
        "من فضلك",
        "فضلا",
        "ساعد",
    }
)

# ── Korean stop words ─────────────────────────────────────────────────────────
STOP_WORDS_KO: frozenset[str] = frozenset(
    {
        # particles
        "은",
        "는",
        "이",
        "가",
        "을",
        "를",
        "의",
        "에",
        "에서",
        "로",
        "으로",
        "와",
        "과",
        "도",
        "만",
        "까지",
        "부터",
        "한테",
        "에게",
        "께",
        "처럼",
        "같이",
        "마다",
        "밖에",
        "대로",
        # pronouns
        "나",
        "나는",
        "내가",
        "나를",
        "너",
        "우리",
        "저",
        "저희",
        "그",
        "그녀",
        "그들",
        "이것",
        "저것",
        "그것",
        "여기",
        "저기",
        "거기",
        # common verbs
        "있다",
        "없다",
        "하다",
        "되다",
        "이다",
        "아니다",
        "보다",
        "주다",
        "오다",
        "가다",
        # dependent nouns
        "것",
        "거",
        "등",
        "수",
        "때",
        "곳",
        "중",
        "분",
        # adverbs
        "잘",
        "더",
        "또",
        "매우",
        "정말",
        "아주",
        "많이",
        "너무",
        "좀",
        # conjunctions
        "그리고",
        "하지만",
        "그래서",
        "그런데",
        "그러나",
        "또는",
        "그러면",
        # question words
        "왜",
        "어떻게",
        "뭐",
        "언제",
        "어디",
        "누구",
        "무엇",
        "어떤",
        # vague time words
        "어제",
        "오늘",
        "내일",
        "최근",
        "지금",
        "아까",
        "나중",
        "전에",
        # request words
        "제발",
        "부탁",
    }
)

# Korean trailing particles sorted longest-first for greedy matching
_KO_TRAILING_PARTICLES: list[str] = sorted(
    [
        "에서",
        "으로",
        "에게",
        "한테",
        "처럼",
        "같이",
        "보다",
        "까지",
        "부터",
        "마다",
        "밖에",
        "대로",
        "은",
        "는",
        "이",
        "가",
        "을",
        "를",
        "의",
        "에",
        "로",
        "와",
        "과",
        "도",
        "만",
    ],
    key=len,
    reverse=True,
)

# ── Japanese stop words ───────────────────────────────────────────────────────
STOP_WORDS_JA: frozenset[str] = frozenset(
    {
        "これ",
        "それ",
        "あれ",
        "この",
        "その",
        "あの",
        "ここ",
        "そこ",
        "あそこ",
        "する",
        "した",
        "して",
        "です",
        "ます",
        "いる",
        "ある",
        "なる",
        "できる",
        "の",
        "こと",
        "もの",
        "ため",
        "そして",
        "しかし",
        "また",
        "でも",
        "から",
        "まで",
        "より",
        "だけ",
        "なぜ",
        "どう",
        "何",
        "いつ",
        "どこ",
        "誰",
        "どれ",
        "昨日",
        "今日",
        "明日",
        "最近",
        "今",
        "さっき",
        "前",
        "後",
    }
)

# ── Temporal keyword whitelists ────────────────────────────────────────────────
# Time-related words that carry high signal in memory search queries.
# These are kept in stop-word lists for general NLP use but can be selectively
# preserved via ``extract_keywords(preserve_temporal=True)``.

TEMPORAL_KEYWORDS_EN: frozenset[str] = frozenset(
    {
        "yesterday",
        "today",
        "tomorrow",
        "recently",
        "earlier",
        "later",
        "ago",
        "now",
        "last",
        "next",
        "morning",
        "afternoon",
        "evening",
        "week",
        "month",
        "year",
    }
)

TEMPORAL_KEYWORDS_ZH: frozenset[str] = frozenset(
    {
        "昨天",
        "今天",
        "明天",
        "最近",
        "之前",
        "以前",
        "之后",
        "以后",
        "刚才",
        "现在",
        "上周",
        "本周",
        "下周",
        "上个月",
        "这个月",
        "去年",
        "今年",
        "早上",
        "下午",
        "晚上",
    }
)

TEMPORAL_KEYWORDS_JA: frozenset[str] = frozenset(
    {
        "昨日",
        "今日",
        "明日",
        "最近",
        "今",
        "さっき",
        "前",
        "後",
    }
)

TEMPORAL_KEYWORDS_KO: frozenset[str] = frozenset(
    {
        "어제",
        "오늘",
        "내일",
        "최근",
        "지금",
        "아까",
        "나중",
        "전에",
    }
)

TEMPORAL_KEYWORDS_ES: frozenset[str] = frozenset(
    {
        "ayer",
        "hoy",
        "mañana",
        "antes",
        "despues",
        "después",
        "ahora",
        "recientemente",
    }
)

TEMPORAL_KEYWORDS_PT: frozenset[str] = frozenset(
    {
        "ontem",
        "hoje",
        "amanhã",
        "antes",
        "depois",
        "agora",
        "recentemente",
    }
)

TEMPORAL_KEYWORDS_AR: frozenset[str] = frozenset(
    {
        "بالأمس",
        "امس",
        "اليوم",
        "غدا",
        "الآن",
        "قبل",
        "بعد",
        "مؤخرا",
    }
)


def is_temporal_keyword(token: str) -> bool:
    """Return True if the token is a temporal keyword in any supported language."""
    return (
        token in TEMPORAL_KEYWORDS_EN
        or token in TEMPORAL_KEYWORDS_ZH
        or token in TEMPORAL_KEYWORDS_JA
        or token in TEMPORAL_KEYWORDS_KO
        or token in TEMPORAL_KEYWORDS_ES
        or token in TEMPORAL_KEYWORDS_PT
        or token in TEMPORAL_KEYWORDS_AR
    )


# ── Chinese stop words ────────────────────────────────────────────────────────
STOP_WORDS_ZH: frozenset[str] = frozenset(
    {
        # pronouns
        "我",
        "我们",
        "你",
        "你们",
        "他",
        "她",
        "它",
        "他们",
        "这",
        "那",
        "这个",
        "那个",
        "这些",
        "那些",
        # particles
        "的",
        "了",
        "着",
        "过",
        "得",
        "地",
        "吗",
        "呢",
        "吧",
        "啊",
        "呀",
        "嘛",
        "啦",
        # common verbs (vague)
        "是",
        "有",
        "在",
        "被",
        "把",
        "给",
        "让",
        "用",
        "到",
        "去",
        "来",
        "做",
        "说",
        "看",
        "找",
        "想",
        "要",
        "能",
        "会",
        "可以",
        # prepositions / conjunctions
        "和",
        "与",
        "或",
        "但",
        "但是",
        "因为",
        "所以",
        "如果",
        "虽然",
        "而",
        "也",
        "都",
        "就",
        "还",
        "又",
        "再",
        "才",
        "只",
        # vague time words
        "之前",
        "以前",
        "之后",
        "以后",
        "刚才",
        "现在",
        "昨天",
        "今天",
        "明天",
        "最近",
        # vague references
        "东西",
        "事情",
        "事",
        "什么",
        "哪个",
        "哪些",
        "怎么",
        "为什么",
        "多少",
        # request words
        "请",
        "帮",
        "帮忙",
        "告诉",
    }
)


def is_stop_word(token: str) -> bool:
    """Return True if the token is a stop word in any supported language."""
    return (
        token in STOP_WORDS_EN
        or token in STOP_WORDS_ES
        or token in STOP_WORDS_PT
        or token in STOP_WORDS_AR
        or token in STOP_WORDS_ZH
        or token in STOP_WORDS_KO
        or token in STOP_WORDS_JA
    )


def _strip_korean_trailing_particle(token: str) -> str | None:
    """Strip a trailing Korean particle and return the stem, or None if not applicable."""
    for particle in _KO_TRAILING_PARTICLES:
        if len(token) > len(particle) and token.endswith(particle):
            return token[: -len(particle)]
    return None


def _is_useful_korean_stem(stem: str) -> bool:
    """Return True if a Korean stem carries meaningful content."""
    if re.search(r"[\uac00-\ud7af]", stem):
        return len(stem) >= 2
    return bool(re.match(r"^[a-z0-9_]+$", stem, re.IGNORECASE))


def _is_valid_keyword(token: str) -> bool:
    """Return True if the token is a useful search keyword."""
    if not token:
        return False
    # Skip short pure-ASCII words
    if re.match(r"^[a-zA-Z]+$", token) and len(token) < 3:
        return False
    # Skip pure numbers
    if re.match(r"^\d+$", token):
        return False
    # Skip pure punctuation
    if re.match(r"^[^\w\u4e00-\u9fff\uac00-\ud7af\u3040-\u30ff]+$", token):
        return False
    # Skip single CJK characters (bigram noise; low FTS value)
    return not re.match(r"^[\u4e00-\u9fff]$", token)


def _tokenize_japanese_segment(segment: str) -> list[str]:
    """Tokenise a Japanese mixed-script segment."""
    tokens: list[str] = []
    jp_parts = re.findall(
        r"[a-z0-9_]+|[\u30a0-\u30ff]+|[\u4e00-\u9fff]+|[\u3040-\u309f]{2,}",
        segment,
    )
    for part in jp_parts:
        if re.match(r"^[\u4e00-\u9fff]+$", part):
            tokens.append(part)
            for i in range(len(part) - 1):
                tokens.append(part[i] + part[i + 1])
        else:
            tokens.append(part)
    return tokens


def _tokenize_chinese_segment(segment: str) -> list[str]:
    """Tokenise a Chinese segment into characters and bigrams."""
    chars = [c for c in segment if re.match(r"[\u4e00-\u9fff]", c)]
    tokens = list(chars)
    for i in range(len(chars) - 1):
        tokens.append(chars[i] + chars[i + 1])
    return tokens


def _tokenize_korean_segment(segment: str) -> list[str]:
    """Tokenise a Korean segment with particle stripping."""
    tokens: list[str] = []
    stem = _strip_korean_trailing_particle(segment)
    stem_is_stop = stem is not None and stem in STOP_WORDS_KO
    if segment not in STOP_WORDS_KO and not stem_is_stop:
        tokens.append(segment)
    if stem and stem not in STOP_WORDS_KO and _is_useful_korean_stem(stem):
        tokens.append(stem)
    return tokens


def _tokenize(text: str) -> list[str]:
    """Multilingual tokeniser.

    Supports: English, Chinese (character + bigram), Japanese (mixed script),
    Korean (particle stripping).
    """
    tokens: list[str] = []
    normalized = text.lower().strip()
    segments = [s for s in re.split(r"[\s\.,!?;:\"'()\[\]{}<>/@#$%^&*+=|\\~`]+", normalized) if s]

    for segment in segments:
        if re.search(r"[\u3040-\u30ff]", segment):  # Japanese
            tokens.extend(_tokenize_japanese_segment(segment))
        elif re.search(r"[\u4e00-\u9fff]", segment):  # Chinese
            tokens.extend(_tokenize_chinese_segment(segment))
        elif re.search(r"[\uac00-\ud7af\u3131-\u3163]", segment):  # Korean
            tokens.extend(_tokenize_korean_segment(segment))
        else:
            tokens.append(segment)

    return tokens


def extract_keywords(query: str, *, preserve_temporal: bool = False) -> list[str]:
    """Extract meaningful keywords from a natural-language query.

    Args:
        query: The raw query string.
        preserve_temporal: When True, temporal keywords (e.g. "yesterday",
            "昨天") bypass stop-word filtering.  Use this for memory search
            queries where time references carry high signal.

    Examples::

        "that thing we discussed about the API" -> ["discussed", "api"]
        # With preserve_temporal=True:
        "what did we discuss yesterday" -> ["discussed", "yesterday"]
    """
    raw_tokens = _tokenize(query)
    keywords: list[str] = []
    seen: set[str] = set()

    for token in raw_tokens:
        # Temporal keywords bypass stop-word filtering when requested.
        if preserve_temporal and is_temporal_keyword(token):
            if token not in seen:
                seen.add(token)
                keywords.append(token)
            continue
        if is_stop_word(token):
            continue
        if not _is_valid_keyword(token):
            continue
        if token in seen:
            continue
        seen.add(token)
        keywords.append(token)

    return keywords


def build_fts_query(raw: str) -> str | None:
    """Convert a raw query string into a SQLite FTS5 MATCH expression.

    Examples::

        'API design'  -> '"API" AND "design"'
        '  '          -> None  (no valid tokens)
    """
    tokens = re.findall(r"[\w\u4e00-\u9fff\uac00-\ud7af\u3040-\u30ff]+", raw)
    tokens = [t.strip() for t in tokens if t.strip()]
    if not tokens:
        return None
    quoted = [f'"{t.replace(chr(34), "")}"' for t in tokens]
    return " AND ".join(quoted)


def _extract_raw_segments(query: str) -> list[str]:
    """Split a query into FTS-matchable segments for trigram-indexed tables.

    For CJK text, the trigram tokenizer indexes every 3-character window.
    To match those trigrams at query time we generate overlapping 3-char and
    4-char windows from the CJK portion of the query.  This guarantees that
    any substring present in the document will be found.

    For ASCII/Latin text, we split on whitespace/punctuation and filter stop
    words as usual.

    Stop words are filtered at the ASCII level only; CJK stop-word filtering
    is intentionally skipped here because the sliding-window approach already
    produces short, specific tokens.
    """
    segments: list[str] = []
    seen: set[str] = set()

    def _add(seg: str) -> None:
        if seg and seg not in seen:
            seen.add(seg)
            segments.append(seg)

    # Split into CJK runs vs ASCII runs
    parts = re.findall(
        r"[a-zA-Z0-9][a-zA-Z0-9_\-\.]*|[\u4e00-\u9fff]+|[\uac00-\ud7af\u3131-\u3163]+|[\u3040-\u30ff]+",
        query,
    )
    for part in parts:
        if not part:
            continue

        is_cjk = bool(re.match(r"^[\u4e00-\u9fff\uac00-\ud7af\u3040-\u30ff]+$", part))

        if is_cjk:
            # Preserve short CJK temporal keywords (e.g. "昨天", 2 chars) that
            # would be lost by the trigram sliding window (minimum window = 3).
            if len(part) < 3 and is_temporal_keyword(part):
                _add(part)
            # Generate 3-char and 4-char sliding windows for trigram matching
            for n in (3, 4):
                for i in range(len(part) - n + 1):
                    _add(part[i : i + n])
            # Also add the full segment if it's short enough to be a real word
            if len(part) <= 6:
                _add(part)
        else:
            # ASCII/Latin: filter stop words and short tokens.
            # Temporal keywords are preserved — they carry high signal in
            # memory search queries (e.g. "yesterday", "recently").
            lower = part.lower()
            if lower in STOP_WORDS_EN and not is_temporal_keyword(lower):
                continue
            if not _is_valid_keyword(lower):
                continue
            _add(part)

    return segments


def expand_query_for_fts(query: str) -> str | None:
    """Expand a natural-language query into a FTS5 MATCH expression.

    Strategy: raw-segment OR expression (trigram-friendly).

    When the FTS table uses the trigram tokenizer, the tokenizer itself
    handles substring decomposition at query time — we must NOT pre-split
    CJK text into bigrams/trigrams on the Python side, because those
    sub-tokens (e.g. ``"乌龙"``) are shorter than the trigram minimum (3
    chars) and will never match.

    Instead we pass whole CJK words (e.g. ``"乌龙茶"``) and let SQLite
    trigram split them internally.  For ASCII/Latin text the behaviour is
    unchanged.

    Examples::

        '用户喜欢喝什么茶？' -> '"乌龙茶"'  (after stop-word removal)
        'Finnie 项目技术栈'  -> '"Finnie" OR "项目技术栈"'
        'API design plan'   -> '"API" OR "design" OR "plan"'
        '  '                -> None
    """
    segments = _extract_raw_segments(query)

    if not segments:
        # Last-resort: fall back to keyword extraction (handles edge cases).
        # Preserve temporal keywords so time-sensitive queries retain their
        # time dimension in FTS search.
        keywords = extract_keywords(query, preserve_temporal=True)
        if not keywords:
            return None
        quoted = [f'"{kw.replace(chr(34), "")}"' for kw in keywords]
        return " OR ".join(quoted)

    quoted = [f'"{seg.replace(chr(34), "")}"' for seg in segments]
    return " OR ".join(quoted)
