"""Distillation service: memory notes (daily + topic) -> MEMORY.md."""

from __future__ import annotations

import contextlib
import datetime
import json
import re
from collections.abc import Awaitable, Callable
from pathlib import Path

from lightclaw.agent.utils.text_sanitizer import sanitize_summary_text


class DistillationService:
    """Extract long-term insights from recent daily + topic note files."""

    # Topic files older than this (by mtime) are considered stale and skipped.
    _TOPIC_STALE_DAYS = 7
    # Maximum combined source text length (chars) before truncation.
    _MAX_SOURCE_CHARS = 60000
    # Trigger MEMORY.md semantic merge when it exceeds this size (chars).
    _MEMORY_MD_MERGE_THRESHOLD = 8000
    # Number of distillation blocks to trigger a merge.
    _MEMORY_MD_MERGE_BLOCK_COUNT = 10

    def __init__(self) -> None:
        self.interval_days = 1
        self.lookback_days = 7

    def configure(self, interval_days: int, lookback_days: int) -> None:
        self.interval_days = interval_days
        self.lookback_days = lookback_days

    def distill_stamp_path(self, working_dir: str) -> Path:
        return Path(working_dir) / ".last_distill"

    def _distill_state_path(self, working_dir: str) -> Path:
        """Return path to the incremental distillation state file."""
        return Path(working_dir) / ".distill_state.json"

    def should_distill(self, working_dir: str) -> bool:
        stamp = self.distill_stamp_path(working_dir)
        if not stamp.exists():
            return True
        try:
            last_ts = float(stamp.read_text(encoding="utf-8").strip())
            elapsed_days = (datetime.datetime.now().timestamp() - last_ts) / 86400
            return elapsed_days >= self.interval_days
        except (ValueError, OSError):
            return True

    def touch_distill_stamp(self, working_dir: str, logger) -> None:
        try:
            self.distill_stamp_path(working_dir).write_text(
                str(datetime.datetime.now().timestamp()),
                encoding="utf-8",
            )
        except OSError:
            logger.warning("Failed to update distillation timestamp")

    # ── incremental state helpers ──────────────────────────────────────

    def _load_distill_state(self, working_dir: str) -> dict[str, float]:
        """Load previously processed file mtimes from state file.

        Returns a dict mapping file path (str) -> mtime (float).
        """
        state_path = self._distill_state_path(working_dir)
        if not state_path.exists():
            return {}
        try:
            data = json.loads(state_path.read_text(encoding="utf-8"))
            return {k: float(v) for k, v in data.get("files", {}).items()}
        except (OSError, json.JSONDecodeError, ValueError):
            return {}

    def _save_distill_state(
        self,
        working_dir: str,
        processed: dict[str, float],
        logger,
    ) -> None:
        """Persist processed file mtimes to state file."""
        state_path = self._distill_state_path(working_dir)
        try:
            state_path.write_text(
                json.dumps({"files": processed}, ensure_ascii=False, indent=2),
                encoding="utf-8",
            )
        except OSError:
            logger.warning("Failed to save distillation state")

    def _filter_new_or_modified(
        self,
        all_files: list[tuple[str, Path]],
        prev_state: dict[str, float],
    ) -> list[tuple[str, Path]]:
        """Return only files that are new or have been modified since last distill."""
        result: list[tuple[str, Path]] = []
        for label, fpath in all_files:
            key = str(fpath)
            try:
                current_mtime = fpath.stat().st_mtime
            except OSError:
                continue
            prev_mtime = prev_state.get(key)
            if prev_mtime is None or current_mtime > prev_mtime:
                result.append((label, fpath))
        return result

    def _build_current_state(self, all_files: list[tuple[str, Path]]) -> dict[str, float]:
        """Build a state dict from the current file list."""
        state: dict[str, float] = {}
        for _, fpath in all_files:
            with contextlib.suppress(OSError):
                state[str(fpath)] = fpath.stat().st_mtime
        return state

    # ── MEMORY.md helpers ─────────────────────────────────────────────

    @staticmethod
    def _count_distill_blocks(memory_md_content: str) -> int:
        """Count the number of '## Distilled on' blocks in MEMORY.md."""
        return len(re.findall(r"^## Distilled on ", memory_md_content, re.MULTILINE))

    @staticmethod
    def _extract_memory_topics(memory_md_content: str, max_chars: int = 6000) -> str:
        """Extract a topic summary from MEMORY.md for LLM deduplication context.

        Extracts the first line (title) of each ``## Distilled on`` block so the
        LLM can see what topics are already covered across the *entire* file,
        rather than only the first ``max_chars`` characters.  Falls back to a
        plain character-level truncation when no structured blocks are found.

        The default ``max_chars`` is intentionally larger than the old 2000-char
        limit so that the LLM has enough context to avoid re-distilling content
        that already exists in the latter half of MEMORY.md.
        """
        if not memory_md_content:
            return ""

        # Prefer a structured summary: collect the first line of every distilled
        # block so the LLM sees the full topic landscape without the full text.
        block_headers: list[str] = []
        for line in memory_md_content.splitlines():
            stripped = line.strip()
            if stripped.startswith("## "):
                block_headers.append(stripped)

        if len(block_headers) > 3:
            # Return a compact topic index instead of raw text.
            topic_index = "\n".join(block_headers)
            # Append the raw prefix so the LLM also sees the actual content of
            # the most recent blocks (up to max_chars total).
            prefix_budget = max(0, max_chars - len(topic_index) - 2)
            prefix = memory_md_content[:prefix_budget] if prefix_budget > 0 else ""
            return (topic_index + "\n\n" + prefix).strip()

        return memory_md_content[:max_chars]

    # ── file collection helpers ────────────────────────────────────────

    @staticmethod
    def _collect_dated_files(
        memory_dir: Path,
        cutoff: datetime.datetime,
    ) -> list[tuple[str, Path]]:
        """Return dated memory files whose embedded date >= *cutoff*."""
        date_pattern = re.compile(r"(\d{4}-\d{2}-\d{2})")
        result: list[tuple[str, Path]] = []
        for md_file in sorted(memory_dir.glob("*.md")):
            match = date_pattern.search(md_file.name)
            if not match:
                continue
            try:
                file_date = datetime.datetime.strptime(match.group(1), "%Y-%m-%d")
            except ValueError:
                continue
            if file_date >= cutoff:
                result.append((match.group(1), md_file))
        return result

    def _collect_topic_files(
        self,
        memory_dir: Path,
        *,
        exclude_names: set[str],
    ) -> list[tuple[str, Path]]:
        """Return topic files (no date in name) modified within staleness window."""
        date_pattern = re.compile(r"\d{4}-\d{2}-\d{2}")
        stale_cutoff = datetime.datetime.now().timestamp() - (self._TOPIC_STALE_DAYS * 86400)
        result: list[tuple[str, Path]] = []
        for md_file in sorted(memory_dir.glob("*.md")):
            if md_file.name in exclude_names:
                continue
            if date_pattern.search(md_file.name):
                # Dated files are handled by _collect_dated_files.
                continue
            try:
                if md_file.stat().st_mtime < stale_cutoff:
                    continue
            except OSError:
                continue
            result.append((f"topic:{md_file.stem}", md_file))
        return result

    # ── source text truncation ──────────────────────────────────────────

    @staticmethod
    def _truncate_at_file_boundary(source_texts: list[str], max_chars: int) -> str:
        """Join source texts and truncate at a file boundary, not mid-document.

        Iterates through *source_texts* and stops adding files once the
        accumulated length would exceed *max_chars*.  This ensures the LLM
        always receives complete file contents rather than a truncated fragment
        of the last file, which would lead to misinterpretation.

        If a single file already exceeds *max_chars*, it is included but
        truncated at the nearest paragraph boundary to preserve readability.
        """
        parts: list[str] = []
        used = 0
        for text in source_texts:
            text_len = len(text)
            if not parts:
                # Always include at least one file; truncate at paragraph if needed.
                if text_len > max_chars:
                    # Find the last blank line before the limit.
                    cutoff = text.rfind("\n\n", 0, max_chars)
                    if cutoff == -1:
                        cutoff = max_chars
                    parts.append(text[:cutoff] + "\n\n[... truncated ...]")
                    used = cutoff
                else:
                    parts.append(text)
                    used = text_len
                continue

            # Separator between files is "\n\n" (2 chars).
            if used + 2 + text_len > max_chars:
                # This file would push us over the limit — stop here.
                break
            parts.append(text)
            used += 2 + text_len

        return "\n\n".join(parts)

    # ── MEMORY.md merge ───────────────────────────────────────────────

    async def _maybe_merge_memory_md(
        self,
        *,
        memory_md_path: Path,
        language: str,
        logger,
        invoke_llm: Callable[[str, str], Awaitable[str]],
    ) -> None:
        """Merge MEMORY.md if it has grown too large or has too many blocks."""
        if not memory_md_path.exists():
            return

        try:
            content = memory_md_path.read_text(encoding="utf-8")
        except OSError:
            return

        block_count = self._count_distill_blocks(content)
        size = len(content)

        if size < self._MEMORY_MD_MERGE_THRESHOLD and block_count < self._MEMORY_MD_MERGE_BLOCK_COUNT:
            return

        logger.info(
            "Distillation: MEMORY.md has %d chars / %d blocks, triggering LLM merge",
            size,
            block_count,
        )

        from lightclaw.agent.prompt_catalog import get_memory_md_merge_prompt

        system = get_memory_md_merge_prompt(language)

        if language == "zh":
            user_msg = f"## 当前 MEMORY.md 内容\n\n{content}"
        else:
            user_msg = f"## Current MEMORY.md content\n\n{content}"

        try:
            merged = await invoke_llm(system, user_msg)
            merged = sanitize_summary_text(merged).strip()
        except Exception:
            logger.exception("MEMORY.md merge LLM call failed")
            return

        if not merged:
            return

        today = datetime.datetime.now().strftime("%Y-%m-%d")
        new_content = f"# Long-term Memory (merged {today})\n\n{merged}\n"
        try:
            memory_md_path.write_text(new_content, encoding="utf-8")
            logger.info(
                "Distillation: MEMORY.md merged from %d to %d chars",
                size,
                len(new_content),
            )
        except OSError:
            logger.exception("Failed to write merged MEMORY.md")

    # ── main entry ─────────────────────────────────────────────────────

    async def distill_to_memory_md(
        self,
        *,
        working_dir: str,
        language: str,
        logger,
        invoke_llm: Callable[[str, str], Awaitable[str]],
        dedup_summary_against_existing: Callable[[str], Awaitable[str]],
    ) -> str:
        memory_dir = Path(working_dir) / "memory"
        if not memory_dir.exists():
            return ""

        cutoff = datetime.datetime.now() - datetime.timedelta(days=self.lookback_days)

        # 1. Collect all candidate files within lookback window.
        dated_files = self._collect_dated_files(memory_dir, cutoff)
        dated_names = {fp.name for _, fp in dated_files}
        topic_files = self._collect_topic_files(memory_dir, exclude_names=dated_names)
        all_files = dated_files + topic_files

        if not all_files:
            logger.info("Distillation: no recent daily/topic notes found")
            self.touch_distill_stamp(working_dir, logger)
            return ""

        # 2. Incremental filtering: only process new or modified files.
        prev_state = self._load_distill_state(working_dir)
        new_files = self._filter_new_or_modified(all_files, prev_state)

        if not new_files:
            logger.info("Distillation: no new or modified notes since last run")
            self.touch_distill_stamp(working_dir, logger)
            return ""

        logger.info(
            "Distillation: %d new/modified files out of %d total candidates",
            len(new_files),
            len(all_files),
        )

        # 3. Read new file contents.
        source_texts: list[str] = []
        for label, fpath in new_files:
            try:
                text = fpath.read_text(encoding="utf-8").strip()
                if text:
                    source_texts.append(f"### {label}\n{text}")
            except OSError:
                continue

        if not source_texts:
            self._save_distill_state(working_dir, self._build_current_state(all_files), logger)
            self.touch_distill_stamp(working_dir, logger)
            return ""

        # Truncate at file boundaries to avoid sending a half-cut file to the
        # LLM, which would cause it to misinterpret the last document's content.
        combined = self._truncate_at_file_boundary(source_texts, self._MAX_SOURCE_CHARS)

        memory_md_path = Path(working_dir) / "MEMORY.md"

        # 4. Read existing MEMORY.md topics as context to avoid duplication.
        existing_memory_topics = ""
        if memory_md_path.exists():
            try:
                existing_content = memory_md_path.read_text(encoding="utf-8")
                existing_memory_topics = self._extract_memory_topics(existing_content)
            except OSError:
                pass

        from lightclaw.agent.prompt_catalog import get_incremental_distillation_system_prompt

        system = get_incremental_distillation_system_prompt(language)

        # 5. Build user message with existing memory context + new notes.
        if language == "zh":
            if existing_memory_topics:
                user_msg = (
                    f"## 已有记忆主题（仅供参考，避免重复）\n\n{existing_memory_topics}\n\n"
                    f"## 新增/修改的笔记\n\n{combined}"
                )
            else:
                user_msg = f"## 新增/修改的笔记\n\n{combined}"
        else:
            if existing_memory_topics:
                user_msg = (
                    f"## Existing memory topics (for reference only, avoid duplication)\n\n"
                    f"{existing_memory_topics}\n\n"
                    f"## New/modified notes\n\n{combined}"
                )
            else:
                user_msg = f"## New/modified notes\n\n{combined}"

        try:
            result = await invoke_llm(system, user_msg)
            result = sanitize_summary_text(result).strip()
        except Exception:
            logger.exception("Distillation LLM call failed")
            return ""

        if not result or "NOTHING_TO_DISTILL" in result:
            logger.info("Distillation: nothing worth keeping from recent notes")
            self._save_distill_state(working_dir, self._build_current_state(all_files), logger)
            self.touch_distill_stamp(working_dir, logger)
            return ""

        result = await dedup_summary_against_existing(result)
        if not result.strip():
            logger.info("Distillation: all content duplicated existing memory")
            self._save_distill_state(working_dir, self._build_current_state(all_files), logger)
            self.touch_distill_stamp(working_dir, logger)
            return ""

        today = datetime.datetime.now().strftime("%Y-%m-%d")
        distill_section = f"\n\n## Distilled on {today}\n\n{result}\n"
        try:
            with open(memory_md_path, "a", encoding="utf-8") as file_obj:
                file_obj.write(distill_section)
            logger.info(
                "Distillation: appended %d chars to MEMORY.md from %d new source files",
                len(distill_section),
                len(new_files),
            )
        except OSError:
            logger.exception("Failed to append distilled content to MEMORY.md")

        # 6. Save incremental state so next run only processes truly new files.
        self._save_distill_state(working_dir, self._build_current_state(all_files), logger)
        self.touch_distill_stamp(working_dir, logger)

        # 7. Check if MEMORY.md needs semantic merge (problem 8).
        await self._maybe_merge_memory_md(
            memory_md_path=memory_md_path,
            language=language,
            logger=logger,
            invoke_llm=invoke_llm,
        )

        return result
