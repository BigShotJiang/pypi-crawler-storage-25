"""Post-compaction quality guard — audit and retry.

Validates that a compaction summary meets structural requirements
(required sections, identifier preservation, latest-ask reflection)
and retries via LLM if the audit fails.
"""

from __future__ import annotations

import logging
import re
from collections.abc import Callable, Coroutine
from typing import Any

from langchain_core.messages import BaseMessage, HumanMessage

from lightclaw.agent.memory.compaction_config import CompactionConfig

logger = logging.getLogger(__name__)

# Required sections that every safeguard summary must contain.
REQUIRED_SECTIONS: tuple[str, ...] = (
    "## Decisions",
    "## Open TODOs",
    "## Constraints/Rules",
    "## Pending user asks",
    "## Exact identifiers",
)

# Regex patterns for opaque identifiers worth preserving.
_IDENTIFIER_PATTERNS: tuple[re.Pattern[str], ...] = (
    # UUID v4
    re.compile(r"\b[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}\b", re.I),
    # URL (http/https)
    re.compile(r"https?://[^\s)<>\"']+"),
    # Unix-style file paths (at least 2 segments)
    re.compile(r"(?:/[\w.~-]+){2,}"),
    # IP:port
    re.compile(r"\b\d{1,3}(?:\.\d{1,3}){3}:\d{2,5}\b"),
    # Git short/long hashes (7-40 hex)
    re.compile(r"\b[0-9a-f]{7,40}\b"),
)

# Maximum identifiers to validate (avoid expensive scanning on huge histories).
_MAX_IDENTIFIERS_TO_CHECK = 20

# Minimum keyword overlap tokens for latest-ask check.
_MIN_ASK_KEYWORDS = 2

# Stop words excluded from keyword overlap check.
_STOP_WORDS: frozenset[str] = frozenset(
    {
        "a",
        "an",
        "the",
        "is",
        "are",
        "was",
        "were",
        "be",
        "been",
        "being",
        "have",
        "has",
        "had",
        "do",
        "does",
        "did",
        "will",
        "would",
        "could",
        "should",
        "may",
        "might",
        "shall",
        "can",
        "to",
        "of",
        "in",
        "for",
        "on",
        "with",
        "at",
        "by",
        "from",
        "it",
        "its",
        "this",
        "that",
        "and",
        "or",
        "but",
        "not",
        "no",
        "if",
        "so",
        "as",
        "than",
        "then",
        "just",
        "also",
        "very",
        "i",
        "me",
        "my",
        "we",
        "our",
        "you",
        "your",
        "he",
        "she",
        "they",
        "them",
        "what",
        "which",
        "who",
        "how",
        "when",
        "where",
        "please",
        "help",
        "thanks",
        "thank",
        "ok",
        "okay",
        # Chinese stop words
        "的",
        "了",
        "在",
        "是",
        "我",
        "有",
        "和",
        "就",
        "不",
        "人",
        "都",
        "一",
        "一个",
        "上",
        "也",
        "很",
        "到",
        "说",
        "要",
        "去",
        "你",
        "会",
        "着",
        "没有",
        "看",
        "好",
        "自己",
        "这",
        "他",
        "她",
        "吗",
        "吧",
        "呢",
        "啊",
        "哦",
        "嗯",
        "请",
        "帮",
        "可以",
    },
)


def _extract_identifiers(text: str) -> list[str]:
    """Extract unique opaque identifiers from text."""
    seen: set[str] = set()
    identifiers: list[str] = []
    for pattern in _IDENTIFIER_PATTERNS:
        for match in pattern.finditer(text):
            value = match.group(0).rstrip("/.,;:)")
            if value not in seen and len(value) >= 5:
                seen.add(value)
                identifiers.append(value)
                if len(identifiers) >= _MAX_IDENTIFIERS_TO_CHECK:
                    return identifiers
    return identifiers


def _extract_keywords(text: str) -> set[str]:
    """Extract meaningful keywords from text (excluding stop words)."""
    tokens = re.findall(r"[\w\u4e00-\u9fff]+", text.lower())
    return {t for t in tokens if t not in _STOP_WORDS and len(t) > 1}


def _check_required_sections(summary: str) -> list[str]:
    """Check whether all required sections are present in the summary."""
    issues: list[str] = []
    for section in REQUIRED_SECTIONS:
        if section not in summary:
            issues.append(f"Missing required section: {section}")
    return issues


def _check_identifier_preservation(
    summary: str,
    original_text: str,
    policy: str,
) -> list[str]:
    """Verify opaque identifiers are preserved when policy is strict."""
    if policy != "strict":
        return []

    identifiers = _extract_identifiers(original_text)
    if not identifiers:
        return []

    missing: list[str] = []
    for ident in identifiers:
        if ident not in summary:
            missing.append(ident)

    if not missing:
        return []

    # Report at most 5 missing identifiers to keep feedback concise.
    sample = missing[:5]
    suffix = f" (and {len(missing) - 5} more)" if len(missing) > 5 else ""
    return [
        f"Missing {len(missing)} identifier(s) that should be preserved (strict policy): {', '.join(sample)}{suffix}"
    ]


def _check_latest_ask(
    summary: str,
    messages: list[BaseMessage],
) -> list[str]:
    """Check whether the latest user ask is reflected in the summary."""
    # Find the last HumanMessage
    last_human: HumanMessage | None = None
    for msg in reversed(messages):
        if isinstance(msg, HumanMessage):
            last_human = msg
            break

    if last_human is None:
        return []

    content = last_human.content if isinstance(last_human.content, str) else str(last_human.content)
    if not content.strip():
        return []

    ask_keywords = _extract_keywords(content)
    if not ask_keywords:
        return []

    summary_lower = summary.lower()
    overlap = sum(1 for kw in ask_keywords if kw in summary_lower)

    if overlap >= min(_MIN_ASK_KEYWORDS, len(ask_keywords)):
        return []

    return [
        "The latest user ask does not appear to be reflected in the summary. "
        f"Keywords from the ask: {', '.join(list(ask_keywords)[:8])}"
    ]


def audit_compaction_summary(
    summary: str,
    original_messages: list[BaseMessage],
    original_text: str,
    config: CompactionConfig,
) -> tuple[bool, list[str]]:
    """Run quality checks on a compaction summary.

    Returns:
        ``(passed, issues)`` — *passed* is True when all checks succeed;
        *issues* lists human-readable descriptions of failures.
    """
    issues: list[str] = []

    # 1. Required sections
    issues.extend(_check_required_sections(summary))

    # 2. Identifier preservation
    issues.extend(
        _check_identifier_preservation(summary, original_text, config.identifier_policy),
    )

    # 3. Latest user ask
    issues.extend(_check_latest_ask(summary, original_messages))

    return (len(issues) == 0, issues)


def build_retry_feedback(issues: list[str], language: str = "zh") -> str:
    """Format audit issues into feedback for the LLM retry prompt."""
    issue_list = "\n".join(f"- {issue}" for issue in issues)

    if language == "zh":
        return (
            "你的上一次摘要存在以下问题，请修复并重新生成完整摘要：\n"
            f"{issue_list}\n\n"
            "请确保包含所有必需的 section，并保留所有重要的标识符。"
        )
    return (
        "Your previous summary had the following issues. "
        "Fix all issues and regenerate the complete summary:\n"
        f"{issue_list}\n\n"
        "Ensure every required section is present and all important identifiers are preserved."
    )


async def audit_and_retry(
    summary: str,
    original_messages: list[BaseMessage],
    original_text: str,
    config: CompactionConfig,
    invoke_llm: Callable[[str, str], Coroutine[Any, Any, str]],
    system_prompt: str,
    base_user_prompt: str,
    language: str = "zh",
) -> str:
    """Audit a compaction summary and retry if quality checks fail.

    Args:
        summary: Initial summary to audit.
        original_messages: The original messages that were summarized.
        original_text: Concatenated text of original messages.
        config: Compaction configuration.
        invoke_llm: Async callable ``(system_prompt, user_message) -> str``.
        system_prompt: System prompt used for compaction.
        base_user_prompt: Original user prompt sent to the LLM.
        language: Language for feedback messages.

    Returns:
        The final (possibly regenerated) summary.
    """
    if not config.quality_guard_enabled:
        return summary

    max_retries = config.quality_guard_max_retries
    current_summary = summary

    for attempt in range(max_retries + 1):
        passed, issues = audit_compaction_summary(
            current_summary,
            original_messages,
            original_text,
            config,
        )

        if passed:
            if attempt > 0:
                logger.info(
                    "Quality guard passed on retry attempt %d/%d",
                    attempt,
                    max_retries,
                )
            return current_summary

        logger.warning(
            "Quality guard failed (attempt %d/%d): %s",
            attempt + 1,
            max_retries + 1,
            "; ".join(issues),
        )

        # No more retries — return best effort.
        if attempt >= max_retries:
            logger.warning(
                "Quality guard exhausted retries, returning best-effort summary",
            )
            return current_summary

        # Retry with feedback.
        feedback = build_retry_feedback(issues, language=language)
        retry_prompt = f"{base_user_prompt}\n\n---\n\n{feedback}"

        try:
            current_summary = await invoke_llm(system_prompt, retry_prompt)
        except Exception:
            logger.exception("Quality guard retry LLM call failed")
            return current_summary

    return current_summary
