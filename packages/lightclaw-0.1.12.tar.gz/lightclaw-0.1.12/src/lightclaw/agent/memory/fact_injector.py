"""Retrieve and format structured facts for LLM context injection.

The :class:`FactInjector` is called by the middleware before each LLM
invocation to inject relevant user facts into the context window.  It
maintains a per-turn cache so that facts are fetched only once per
ReAct loop iteration.

Injection format::

    <structured-facts>
    ## Preferences
    - The user prefers dark mode in all IDEs [importance=0.8]
    ## Biographical
    - The user's name is Alex [importance=0.9]
    </structured-facts>
"""

from __future__ import annotations

import logging
from collections.abc import Callable, Coroutine
from typing import Any

from lightclaw.agent.memory.fact_store import FactStore
from lightclaw.constant import FACT_INJECTION_MAX_TOKENS

logger = logging.getLogger(__name__)

# Token estimation: ~4 chars per token for mixed English/Chinese text.
_CHARS_PER_TOKEN = 4

# Categories that are always included regardless of query relevance,
# because they represent core user identity or safety-critical information.
_ALWAYS_INCLUDE_CATEGORIES = frozenset({"biographical", "preference", "behavioral", "medical"})

# Display order for categories in the injection block.
_CATEGORY_ORDER = [
    "medical",
    "biographical",
    "preference",
    "behavioral",
    "project",
    "technical",
    "general",
]

# Human-readable category headers.
_CATEGORY_HEADERS = {
    "medical": "Medical",
    "preference": "Preferences",
    "biographical": "Biographical",
    "project": "Project",
    "technical": "Technical",
    "behavioral": "Behavioral",
    "general": "General",
}


class FactInjector:
    """Retrieve relevant facts and format them for LLM context injection.

    The injector uses a two-stage retrieval:
    1. **Always-include**: biographical/preference/behavioral facts (core identity)
    2. **Query-relevant**: semantic search against the latest user message

    Results are merged, deduplicated, and formatted within a token budget.
    """

    def __init__(
        self,
        fact_store: FactStore,
        embedding_fn: Callable[[list[str]], Coroutine[Any, Any, list[list[float]]]] | None = None,
        max_tokens: int | None = None,
    ) -> None:
        """Initialise the injector.

        Args:
            fact_store: The SQLite fact store to read facts from.
            embedding_fn: Optional async embedding function for semantic search.
            max_tokens: Token budget for the injected block.
        """
        self._store = fact_store
        self._embedding_fn = embedding_fn
        self._max_tokens = max_tokens or FACT_INJECTION_MAX_TOKENS

        # Per-turn cache: invalidated when facts are modified.
        self._cached_block: str | None = None
        self._cache_query_hash: int | None = None
        self._cache_modified_ms: int = 0

    def invalidate_cache(self) -> None:
        """Force cache invalidation (called after fact extraction)."""
        self._cached_block = None
        self._cache_query_hash = None

    async def get_relevant_facts_block(
        self,
        last_user_text: str = "",
        extractor_last_modified_ms: int = 0,
    ) -> str:
        """Retrieve and format relevant facts as an XML block.

        Args:
            last_user_text: The latest user message (for relevance ranking).
            extractor_last_modified_ms: Timestamp of last fact modification
                from :class:`FactExtractor`.  Used to invalidate cache.

        Returns:
            A formatted string ready for injection, or empty string if
            no facts are available.
        """
        # Cache check
        query_hash = hash(last_user_text)
        if (
            self._cached_block is not None
            and self._cache_query_hash == query_hash
            and extractor_last_modified_ms <= self._cache_modified_ms
        ):
            return self._cached_block

        try:
            block = await self._build_facts_block(last_user_text)
        except Exception:
            logger.exception("Failed to build facts block")
            block = ""

        # Update cache
        self._cached_block = block
        self._cache_query_hash = query_hash
        self._cache_modified_ms = extractor_last_modified_ms
        return block

    async def _build_facts_block(self, last_user_text: str) -> str:
        """Build the formatted facts block.

        Uses targeted SQL queries instead of a full table scan:
        - Stage 1: fetch core identity categories directly via IN clause.
        - Stage 2: semantic search for non-core categories (already scoped to
          active facts inside search_facts_by_embedding).
        """
        # Stage 1: fetch core identity facts with a targeted SQL query.
        core_facts = await self._store.get_active_facts_by_categories(list(_ALWAYS_INCLUDE_CATEGORIES))

        # Stage 2: if we have a user query, rank non-core facts by relevance.
        relevant_others: list[dict[str, Any]] = []
        if last_user_text and self._embedding_fn is not None:
            try:
                query_emb = await self._embedding_fn([last_user_text])
                if query_emb and query_emb[0]:
                    core_ids = {f["id"] for f in core_facts}
                    scored = await self._store.search_facts_by_embedding(
                        query_embedding=query_emb[0],
                        limit=10,
                        min_score=0.3,
                    )
                    # Keep only non-core results to avoid duplicating Stage 1 facts.
                    relevant_others = [f for f in scored if f["id"] not in core_ids]
            except Exception:
                logger.debug("Fact relevance ranking failed, including all")

        if not relevant_others:
            # Fallback: fetch non-core categories sorted by importance via SQL.
            non_core_categories = [c for c in _CATEGORY_ORDER if c not in _ALWAYS_INCLUDE_CATEGORIES]
            all_non_core = await self._store.get_active_facts_by_categories(non_core_categories)
            relevant_others = sorted(all_non_core, key=lambda f: f["importance"], reverse=True)

        if not core_facts and not relevant_others:
            return ""

        # Merge and deduplicate
        seen_ids: set[int] = set()
        merged_core: list[dict[str, Any]] = []
        for f in core_facts:
            if f["id"] not in seen_ids:
                seen_ids.add(f["id"])
                merged_core.append(f)

        merged_relevant: list[dict[str, Any]] = []
        for f in relevant_others:
            if f["id"] not in seen_ids:
                seen_ids.add(f["id"])
                merged_relevant.append(f)

        if not merged_core and not merged_relevant:
            return ""

        # Apply token budget with two-phase allocation to ensure query-relevant
        # facts are not completely crowded out by always-include core facts.
        char_budget = self._max_tokens * _CHARS_PER_TOKEN
        # Reserve chars for XML wrapper and headers
        overhead = 200
        available = char_budget - overhead

        def _fact_line_len(f: dict[str, Any]) -> int:
            return len(f"- {f['content']} [importance={f['importance']}]") + 1  # +1 for newline

        # Phase 1: reserve a minimum quota for query-relevant facts (up to 30% of budget
        # or 3 facts, whichever is smaller) so they are never fully squeezed out.
        relevant_quota_chars = min(available * 3 // 10, sum(_fact_line_len(f) for f in merged_relevant[:3]))

        # Phase 2: fill core facts first within (available - relevant_quota_chars).
        core_budget = available - relevant_quota_chars
        selected_core: list[dict[str, Any]] = []
        used_core = 0
        # Sort core facts by importance descending so the most critical ones survive truncation.
        for f in sorted(merged_core, key=lambda x: x["importance"], reverse=True):
            line_len = _fact_line_len(f)
            if used_core + line_len > core_budget:
                break
            selected_core.append(f)
            used_core += line_len

        # Phase 3: fill remaining budget with query-relevant facts.
        remaining_budget = available - used_core
        selected_relevant: list[dict[str, Any]] = []
        used_relevant = 0
        for f in merged_relevant:
            line_len = _fact_line_len(f)
            if used_relevant + line_len > remaining_budget:
                break
            selected_relevant.append(f)
            used_relevant += line_len

        # Restore original category order for display: core first, then relevant.
        selected = selected_core + selected_relevant

        if not selected:
            return ""

        # Track access
        try:
            await self._store.increment_access([f["id"] for f in selected])
        except Exception:
            logger.debug("Failed to increment access counts")

        # Format by category
        return _format_facts_block(selected)


def _format_facts_block(facts: list[dict[str, Any]]) -> str:
    """Format facts into the injection XML block, grouped by category."""
    by_category: dict[str, list[dict[str, Any]]] = {}
    for f in facts:
        cat = f["category"]
        if cat not in by_category:
            by_category[cat] = []
        by_category[cat].append(f)

    lines = ["<structured-facts>"]

    for cat in _CATEGORY_ORDER:
        if cat not in by_category:
            continue
        header = _CATEGORY_HEADERS.get(cat, cat.capitalize())
        lines.append(f"## {header}")
        # Sort within each category by importance descending so the most
        # critical facts appear first even when the budget truncates the list.
        for f in sorted(by_category[cat], key=lambda x: x["importance"], reverse=True):
            lines.append(f"- {f['content']} [importance={f['importance']}]")
        lines.append("")  # blank line between categories

    lines.append("</structured-facts>")
    return "\n".join(lines)
