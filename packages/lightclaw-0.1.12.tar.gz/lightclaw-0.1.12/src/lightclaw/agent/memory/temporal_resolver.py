"""Resolve natural-language temporal expressions into concrete date ranges.

Pure-function module — no LLM calls, no I/O, no external dependencies.
Latency is ~0 ms (regex + date arithmetic only).

Supported patterns (ZH + EN):
  - Relative day:   昨天 / yesterday, 前天 / day before yesterday, 今天 / today,
                    明天 / tomorrow, 后天 / day after tomorrow
  - Relative week:  上周 / last week, 本周 / this week, 下周 / next week
  - Relative month: 上个月 / last month, 这个月 / this month, 下个月 / next month
  - Relative year:  去年 / last year, 今年 / this year, 明年 / next year
  - Vague recency:  最近 / recently, 刚才 / lately  (soft — boost, not filter)
  - N days ago:     N天前 / N days ago
  - N days later:   N天后 / in N days / N days later
  - Specific date:  4月15日, 4月15号, 2026-04-15

Public API:
  - resolve_temporal_expr(query, *, reference_date=None) -> DateRange | None
        Returns the first matched expression (any kind, soft or hard).
  - resolve_first(text, ref=None, language="zh") -> DateRange | None
        Returns the first matched **non-soft** (hard) expression. Used by the
        event-time extractor to derive event anchors. Soft hints like
        "最近 / lately" are intentionally skipped here — they are handled in
        a dedicated branch by the extractor.
"""

from __future__ import annotations

import calendar
import re
from collections.abc import Callable
from dataclasses import dataclass
from datetime import date, timedelta


@dataclass(frozen=True)
class DateRange:
    """An inclusive date range resolved from a temporal expression.

    Attributes:
        start:       Inclusive start date.
        end:         Inclusive end date.
        source_expr: Original temporal expression (e.g. "昨天").
        soft:        When True the range is a hint (score boost) rather than
                     a hard filter.  Used for vague expressions like "最近".
    """

    start: date
    end: date
    source_expr: str
    soft: bool = False


# ── Helper functions ──────────────────────────────────────────────────────────


def _last_week(ref: date) -> DateRange:
    """Return Mon–Sun of the week before *ref*."""
    monday = ref - timedelta(days=ref.weekday() + 7)
    sunday = monday + timedelta(days=6)
    return DateRange(monday, sunday, "上周")


def _this_week(ref: date) -> DateRange:
    """Return Mon–Sun of the current week."""
    monday = ref - timedelta(days=ref.weekday())
    sunday = monday + timedelta(days=6)
    return DateRange(monday, sunday, "本周")


def _next_week(ref: date) -> DateRange:
    """Return Mon–Sun of the week after *ref*."""
    monday = ref + timedelta(days=7 - ref.weekday())
    sunday = monday + timedelta(days=6)
    return DateRange(monday, sunday, "下周")


def _last_month(ref: date) -> DateRange:
    """Return 1st–last day of the previous month."""
    first_of_current = ref.replace(day=1)
    last_of_prev = first_of_current - timedelta(days=1)
    first_of_prev = last_of_prev.replace(day=1)
    return DateRange(first_of_prev, last_of_prev, "上个月")


def _this_month(ref: date) -> DateRange:
    """Return 1st–last day of the current month."""
    first = ref.replace(day=1)
    last_day = calendar.monthrange(ref.year, ref.month)[1]
    last = ref.replace(day=last_day)
    return DateRange(first, last, "这个月")


def _last_year(ref: date) -> DateRange:
    """Return Jan 1 – Dec 31 of the previous year."""
    return DateRange(date(ref.year - 1, 1, 1), date(ref.year - 1, 12, 31), "去年")


def _this_year(ref: date) -> DateRange:
    """Return Jan 1 – Dec 31 of the current year."""
    return DateRange(date(ref.year, 1, 1), date(ref.year, 12, 31), "今年")


def _n_days_ago_zh(m: re.Match[str], ref: date) -> DateRange:
    """Resolve ``N天前`` pattern."""
    n = int(m.group(1))
    target = ref - timedelta(days=n)
    return DateRange(target, target, f"{n}天前")


def _n_days_ago_en(m: re.Match[str], ref: date) -> DateRange:
    """Resolve ``N days ago`` pattern."""
    n = int(m.group(1))
    target = ref - timedelta(days=n)
    return DateRange(target, target, f"{n} days ago")


def _n_days_later_zh(m: re.Match[str], ref: date) -> DateRange:
    """Resolve ``N天后`` pattern (future)."""
    n = int(m.group(1))
    target = ref + timedelta(days=n)
    return DateRange(target, target, f"{n}天后")


def _n_days_later_en(m: re.Match[str], ref: date) -> DateRange:
    """Resolve ``in N days`` / ``N days later`` pattern (future)."""
    n = int(m.group(1))
    target = ref + timedelta(days=n)
    return DateRange(target, target, f"in {n} days")


def _next_year(ref: date) -> DateRange:
    """Return Jan 1 – Dec 31 of the next year."""
    return DateRange(date(ref.year + 1, 1, 1), date(ref.year + 1, 12, 31), "明年")


def _next_month(ref: date) -> DateRange:
    """Return 1st–last day of the next month."""
    if ref.month == 12:
        first = date(ref.year + 1, 1, 1)
    else:
        first = date(ref.year, ref.month + 1, 1)
    last_day = calendar.monthrange(first.year, first.month)[1]
    last = date(first.year, first.month, last_day)
    return DateRange(first, last, "下个月")


_WEEKDAY_ZH: dict[str, int] = {
    "一": 0,
    "二": 1,
    "三": 2,
    "四": 3,
    "五": 4,
    "六": 5,
    "日": 6,
    "天": 6,
}

_WEEKDAY_EN: dict[str, int] = {
    "monday": 0,
    "tuesday": 1,
    "wednesday": 2,
    "thursday": 3,
    "friday": 4,
    "saturday": 5,
    "sunday": 6,
}


def _next_weekday_zh(m: re.Match[str], ref: date) -> DateRange:
    """Resolve ``下周 X`` (e.g. 下周一) — a single concrete next-week day."""
    wd = _WEEKDAY_ZH.get(m.group(1))
    if wd is None:
        return _next_week(ref)
    monday_next = ref + timedelta(days=7 - ref.weekday())
    target = monday_next + timedelta(days=wd)
    return DateRange(target, target, f"下周{m.group(1)}")


def _next_weekday_en(m: re.Match[str], ref: date) -> DateRange:
    """Resolve ``next Monday`` style — a single concrete next-week day."""
    name = m.group(1).lower()
    wd = _WEEKDAY_EN.get(name)
    if wd is None:
        return _next_week(ref)
    monday_next = ref + timedelta(days=7 - ref.weekday())
    target = monday_next + timedelta(days=wd)
    return DateRange(target, target, f"next {name}")


def _specific_date_zh(m: re.Match[str], ref: date) -> DateRange:
    """Resolve ``M月D日`` or ``M月D号`` pattern."""
    month = int(m.group(1))
    day = int(m.group(2))
    # Assume current year; if the date is in the future by > 6 months, use last year.
    year = ref.year
    try:
        target = date(year, month, day)
    except ValueError:
        return DateRange(ref, ref, m.group(0))
    if (target - ref).days > 180:
        year -= 1
        try:
            target = date(year, month, day)
        except ValueError:
            return DateRange(ref, ref, m.group(0))
    return DateRange(target, target, m.group(0))


def _iso_date(m: re.Match[str], ref: date) -> DateRange:
    """Resolve ``YYYY-MM-DD`` pattern."""
    year, month, day = int(m.group(1)), int(m.group(2)), int(m.group(3))
    try:
        target = date(year, month, day)
    except ValueError:
        return DateRange(ref, ref, m.group(0))
    return DateRange(target, target, m.group(0))


# ── Pattern tables ────────────────────────────────────────────────────────────
# Each entry: (compiled regex, resolver function).
# Order matters — more specific patterns must come before general ones.

_ResolverFn = Callable[[re.Match[str], date], DateRange]

_PATTERNS_ZH: list[tuple[re.Pattern[str], _ResolverFn]] = [
    # Multi-char patterns first to avoid partial matches.
    (re.compile(r"大前天"), lambda m, ref: DateRange(ref - timedelta(days=3), ref - timedelta(days=3), "大前天")),
    (re.compile(r"前天"), lambda m, ref: DateRange(ref - timedelta(days=2), ref - timedelta(days=2), "前天")),
    (re.compile(r"昨天"), lambda m, ref: DateRange(ref - timedelta(days=1), ref - timedelta(days=1), "昨天")),
    (re.compile(r"今天"), lambda m, ref: DateRange(ref, ref, "今天")),
    # Future single-day patterns: 明天 / 后天 / 大后天
    (re.compile(r"大后天"), lambda m, ref: DateRange(ref + timedelta(days=3), ref + timedelta(days=3), "大后天")),
    (re.compile(r"后天"), lambda m, ref: DateRange(ref + timedelta(days=2), ref + timedelta(days=2), "后天")),
    (re.compile(r"明天"), lambda m, ref: DateRange(ref + timedelta(days=1), ref + timedelta(days=1), "明天")),
    # Future weekday patterns must come before bare "下周" so "下周一" hits the specific-day branch.
    (re.compile(r"下周([一二三四五六日天])"), _next_weekday_zh),
    (re.compile(r"上周"), lambda m, ref: _last_week(ref)),
    (re.compile(r"本周"), lambda m, ref: _this_week(ref)),
    (re.compile(r"下周"), lambda m, ref: _next_week(ref)),
    (re.compile(r"上个月"), lambda m, ref: _last_month(ref)),
    (re.compile(r"这个月"), lambda m, ref: _this_month(ref)),
    (re.compile(r"下个月"), lambda m, ref: _next_month(ref)),
    (re.compile(r"去年"), lambda m, ref: _last_year(ref)),
    (re.compile(r"今年"), lambda m, ref: _this_year(ref)),
    (re.compile(r"明年"), lambda m, ref: _next_year(ref)),
    # Soft hints (vague recency / future) — boost only, not used as event anchors.
    (re.compile(r"最近"), lambda m, ref: DateRange(ref - timedelta(days=7), ref, "最近", soft=True)),
    (re.compile(r"这阵子"), lambda m, ref: DateRange(ref - timedelta(days=14), ref, "这阵子", soft=True)),
    (re.compile(r"近来"), lambda m, ref: DateRange(ref - timedelta(days=14), ref, "近来", soft=True)),
    (re.compile(r"近期"), lambda m, ref: DateRange(ref - timedelta(days=14), ref, "近期", soft=True)),
    (re.compile(r"刚才"), lambda m, ref: DateRange(ref, ref, "刚才", soft=True)),
    (re.compile(r"(\d+)\s*天后"), _n_days_later_zh),
    (
        re.compile(r"(\d+)\s*周后"),
        lambda m, ref: DateRange(
            ref + timedelta(weeks=int(m.group(1))),
            ref + timedelta(weeks=int(m.group(1))),
            f"{m.group(1)}周后",
        ),
    ),
    (re.compile(r"(\d+)\s*天前"), _n_days_ago_zh),
    (re.compile(r"(\d{1,2})月(\d{1,2})[日号]"), _specific_date_zh),
]

_PATTERNS_EN: list[tuple[re.Pattern[str], _ResolverFn]] = [
    # Longer phrases first to avoid partial matches.
    (
        re.compile(r"\bday\s+before\s+yesterday\b", re.IGNORECASE),
        lambda m, ref: DateRange(ref - timedelta(days=2), ref - timedelta(days=2), "day before yesterday"),
    ),
    (
        re.compile(r"\byesterday\b", re.IGNORECASE),
        lambda m, ref: DateRange(ref - timedelta(days=1), ref - timedelta(days=1), "yesterday"),
    ),
    (
        re.compile(r"\btoday\b", re.IGNORECASE),
        lambda m, ref: DateRange(ref, ref, "today"),
    ),
    (
        re.compile(r"\bday\s+after\s+tomorrow\b", re.IGNORECASE),
        lambda m, ref: DateRange(ref + timedelta(days=2), ref + timedelta(days=2), "day after tomorrow"),
    ),
    (
        re.compile(r"\btomorrow\b", re.IGNORECASE),
        lambda m, ref: DateRange(ref + timedelta(days=1), ref + timedelta(days=1), "tomorrow"),
    ),
    # Specific next weekday must come before bare "next week" so "next Monday" hits the day branch.
    (
        re.compile(r"\bnext\s+(monday|tuesday|wednesday|thursday|friday|saturday|sunday)\b", re.IGNORECASE),
        _next_weekday_en,
    ),
    (
        re.compile(r"\blast\s+week\b", re.IGNORECASE),
        lambda m, ref: _last_week(ref),
    ),
    (
        re.compile(r"\bthis\s+week\b", re.IGNORECASE),
        lambda m, ref: _this_week(ref),
    ),
    (
        re.compile(r"\bnext\s+week\b", re.IGNORECASE),
        lambda m, ref: _next_week(ref),
    ),
    (
        re.compile(r"\blast\s+month\b", re.IGNORECASE),
        lambda m, ref: _last_month(ref),
    ),
    (
        re.compile(r"\bthis\s+month\b", re.IGNORECASE),
        lambda m, ref: _this_month(ref),
    ),
    (
        re.compile(r"\bnext\s+month\b", re.IGNORECASE),
        lambda m, ref: _next_month(ref),
    ),
    (
        re.compile(r"\blast\s+year\b", re.IGNORECASE),
        lambda m, ref: _last_year(ref),
    ),
    (
        re.compile(r"\bthis\s+year\b", re.IGNORECASE),
        lambda m, ref: _this_year(ref),
    ),
    (
        re.compile(r"\bnext\s+year\b", re.IGNORECASE),
        lambda m, ref: _next_year(ref),
    ),
    # Soft hints — boost only, not used as event anchors.
    (
        re.compile(r"\brecently\b", re.IGNORECASE),
        lambda m, ref: DateRange(ref - timedelta(days=7), ref, "recently", soft=True),
    ),
    (
        re.compile(r"\blately\b", re.IGNORECASE),
        lambda m, ref: DateRange(ref - timedelta(days=7), ref, "lately", soft=True),
    ),
    (
        re.compile(r"\bthese\s+days\b", re.IGNORECASE),
        lambda m, ref: DateRange(ref - timedelta(days=14), ref, "these days", soft=True),
    ),
    (
        re.compile(r"\b(\d+)\s+days?\s+ago\b", re.IGNORECASE),
        _n_days_ago_en,
    ),
    (
        re.compile(r"\bin\s+(\d+)\s+days?\b", re.IGNORECASE),
        _n_days_later_en,
    ),
    (
        re.compile(r"\b(\d+)\s+days?\s+later\b", re.IGNORECASE),
        _n_days_later_en,
    ),
]

# ISO date pattern (language-independent).
_PATTERN_ISO_DATE: tuple[re.Pattern[str], _ResolverFn] = (
    re.compile(r"\b(\d{4})-(\d{2})-(\d{2})\b"),
    _iso_date,
)


# ── Public API ────────────────────────────────────────────────────────────────


def resolve_temporal_expr(
    query: str,
    *,
    reference_date: date | None = None,
) -> DateRange | None:
    """Extract and resolve a temporal expression from a query string.

    Scans the query for known temporal patterns (multi-language) and converts
    the first match into a concrete ``DateRange`` relative to *reference_date*
    (defaults to ``date.today()``).

    Returns ``None`` if no temporal expression is detected.

    Examples::

        resolve_temporal_expr("昨天讨论了什么")
        # → DateRange(start=date(2026,4,15), end=date(2026,4,15), source_expr="昨天")

        resolve_temporal_expr("last week's decisions")
        # → DateRange(start=date(2026,4,6), end=date(2026,4,12), source_expr="last week")

        resolve_temporal_expr("帮我写个排序算法")
        # → None  (no temporal expression)
    """
    ref = reference_date or date.today()

    # Try language-specific patterns first (ZH before EN to prioritise CJK).
    for patterns in (_PATTERNS_ZH, _PATTERNS_EN):
        for pattern, resolver in patterns:
            match = pattern.search(query)
            if match:
                return resolver(match, ref)

    # Try ISO date pattern last (language-independent).
    iso_pattern, iso_resolver = _PATTERN_ISO_DATE
    match = iso_pattern.search(query)
    if match:
        return iso_resolver(match, ref)

    return None


def resolve_first(
    text: str,
    ref: date | None = None,
    language: str = "zh",
) -> DateRange | None:
    """Return the first matched **non-soft** (hard) temporal expression.

    Used by ``event_time_extractor`` to derive an event anchor. Soft hints
    such as "最近 / lately" are intentionally skipped here — they are handled
    in a dedicated ``ongoing`` branch by the extractor.

    Scan order is leftmost-wins across all hard patterns (ZH, EN, ISO),
    so an early concrete date in the snippet wins over a later one.
    """
    ref_date = ref or date.today()
    pattern_groups: list[list[tuple[re.Pattern[str], _ResolverFn]]] = []
    if language == "en":
        pattern_groups.append(_PATTERNS_EN)
        pattern_groups.append(_PATTERNS_ZH)
    else:
        pattern_groups.append(_PATTERNS_ZH)
        pattern_groups.append(_PATTERNS_EN)

    earliest: tuple[int, DateRange] | None = None
    for patterns in pattern_groups:
        for pattern, resolver in patterns:
            match = pattern.search(text)
            if not match:
                continue
            resolved = resolver(match, ref_date)
            if resolved.soft:
                continue
            if earliest is None or match.start() < earliest[0]:
                earliest = (match.start(), resolved)

    iso_pattern, iso_resolver = _PATTERN_ISO_DATE
    iso_match = iso_pattern.search(text)
    if iso_match:
        resolved_iso = iso_resolver(iso_match, ref_date)
        if earliest is None or iso_match.start() < earliest[0]:
            earliest = (iso_match.start(), resolved_iso)

    return earliest[1] if earliest else None


# Soft-hint detection (used by event_time_extractor to mark `ongoing` events).
_SOFT_HINT_RE_ZH = re.compile(r"最近|这阵子|近来|近期|刚才")
_SOFT_HINT_RE_EN = re.compile(r"\b(?:recently|lately|these\s+days)\b", re.IGNORECASE)


def has_ongoing_hint(text: str) -> bool:
    """Return True if *text* contains a soft "ongoing" hint (最近 / lately etc.)."""
    return bool(_SOFT_HINT_RE_ZH.search(text) or _SOFT_HINT_RE_EN.search(text))
