"""Personality context injection based on MBTI type (P1 scene layer).

The :class:`PersonalityInjector` is a pure rule-engine component (zero LLM
cost) that reads the agent's MBTI type and dimension percentages from
``IDENTITY.md`` and injects scene-appropriate personality hints into the
system prompt via middleware.

Supports three levels of personality data:
- **4-letter code** — identity label (auto-derived from percentages)
- **Dimension percentages** — 0-100 continuous spectrum per dimension
- **Descriptors** — 2-4 keywords capturing personality flavor

Scene detection uses keyword matching; personality hints are selected from
a static template table indexed by ``(scene, mbti_dimension)`` and
modulated by dimension percentage strength.
"""

from __future__ import annotations

import logging
import random
import re
import time
from dataclasses import dataclass, field
from pathlib import Path

logger = logging.getLogger(__name__)

# ---------------------------------------------------------------------------
# Scene definitions — keyword-based detection
# ---------------------------------------------------------------------------

_SCENE_KEYWORDS: dict[str, list[str]] = {
    "code_review": [
        "review",
        "code review",
        "PR",
        "pull request",
        "merge request",
        "代码审查",
        "代码评审",
        "CR",
    ],
    "debug": [
        "bug",
        "error",
        "traceback",
        "exception",
        "crash",
        "segfault",
        "报错",
        "异常",
        "崩溃",
        "出错",
        "不工作",
    ],
    "planning": [
        "plan",
        "schedule",
        "roadmap",
        "sprint",
        "milestone",
        "deadline",
        "计划",
        "排期",
        "路线图",
        "里程碑",
    ],
    "brainstorm": [
        "idea",
        "brainstorm",
        "what if",
        "explore",
        "possibility",
        "想法",
        "头脑风暴",
        "如果",
        "可能性",
        "探索",
    ],
    "emotional": [
        "frustrated",
        "angry",
        "sad",
        "tired",
        "stressed",
        "happy",
        "excited",
        "烦",
        "累",
        "难过",
        "焦虑",
        "开心",
        "郁闷",
        "崩溃了",
        "好烦",
        "压力",
        "不开心",
    ],
    "casual_chat": [
        "聊聊",
        "闲聊",
        "随便说说",
        "just chatting",
        "how are you",
        "你好吗",
        "在吗",
        "无聊",
    ],
}

# Default scene when no keyword matches.
_DEFAULT_SCENE = "general"

# ---------------------------------------------------------------------------
# Personality hint templates — indexed by (scene, dimension_pole)
# ---------------------------------------------------------------------------

_PERSONALITY_HINTS: dict[str, dict[str, str]] = {
    "code_review": {
        "T": "Focus on logic, correctness, and edge cases. Be direct about issues.",
        "F": "Acknowledge good parts first, then suggest improvements constructively.",
        "J": "Provide a structured checklist of review findings.",
        "P": "Highlight areas worth exploring further; suggest alternatives.",
    },
    "debug": {
        "S": "Walk through the problem step by step; focus on concrete symptoms and logs.",
        "N": "Consider the bigger picture — could this be a systemic issue?",
        "T": "Diagnose methodically; prioritise root cause over symptoms.",
        "F": "Acknowledge the frustration, then help troubleshoot.",
    },
    "planning": {
        "J": "Propose a structured timeline with clear milestones and owners.",
        "P": "Suggest a flexible framework; leave room for pivots.",
        "E": "Proactively offer to break tasks down and discuss priorities.",
        "I": "Present the plan concisely; let the user drive the discussion.",
    },
    "brainstorm": {
        "N": "Go wide — offer unconventional angles and 'what-if' scenarios.",
        "S": "Ground ideas in practical constraints and real examples.",
        "E": "Energetically build on ideas; offer rapid-fire variations.",
        "I": "Offer a few well-thought-out ideas with depth rather than volume.",
    },
    "emotional": {
        "F": "Lead with empathy; validate feelings before offering solutions.",
        "T": "Briefly acknowledge the emotion, then pivot to actionable next steps.",
        "E": "Be warm and conversational; check in on how they're feeling.",
        "I": "Give space; offer quiet support without overwhelming.",
    },
    "casual_chat": {
        "E": "Be sociable and chatty; ask follow-up questions.",
        "I": "Keep it light but concise; don't over-extend small talk.",
        "F": "Show warmth and personal interest.",
        "T": "Be friendly but low-key; don't force emotional depth.",
    },
    "general": {
        "E": "Be proactive in offering context and next steps.",
        "I": "Be responsive; answer precisely without over-elaborating.",
        "T": "Prioritise clarity and logic.",
        "F": "Balance logic with warmth; consider how the answer lands.",
        "S": "Be concrete and specific.",
        "N": "Connect to broader patterns when helpful.",
        "J": "Wrap up with a clear action item or summary.",
        "P": "Leave space for follow-up exploration.",
    },
    "proactive_topic": {
        "N": "Guide the conversation toward a deeper idea or something worth exploring recently",
        "S": "Ask about recent concrete progress or practical matters",
        "T": "Lead with a question or insight rather than emotional framing",
        "F": "Set a caring, empathetic tone so the person feels valued",
        "E": "Be warm and natural, like a friend reaching out",
        "I": "Keep it brief but genuine; leave room for them to respond or not",
    },
    "proactive_topic_en": {
        "N": "Guide the conversation toward a deeper idea or something worth exploring recently",
        "S": "Ask about recent concrete progress or practical matters",
        "T": "Lead with a question or insight rather than emotional framing",
        "F": "Set a caring, empathetic tone so the person feels valued",
        "E": "Be warm and natural, like a friend reaching out",
        "I": "Keep it brief but genuine; leave room for them to respond or not",
    },
    "proactive_caring": {
        "E": "Reach out warmly and enthusiastically, expressing genuine care",
        "I": "Keep it short and warm; don't pressure them to reply",
        "F": "Lead with emotional connection; ask how they're feeling",
        "T": "Ask about something specific rather than a vague check-in",
    },
    "proactive_caring_en": {
        "E": "Reach out warmly and enthusiastically, expressing genuine care",
        "I": "Keep it short and warm; don't pressure them to reply",
        "F": "Lead with emotional connection; ask how they're feeling",
        "T": "Ask about something specific rather than a vague check-in",
    },
}

# Weakened hint variants for moderate tendencies (60-69%).
_WEAK_HINTS: dict[str, str] = {
    "E": "Lean slightly toward proactive engagement, but stay balanced.",
    "I": "Lean slightly toward conciseness, but stay balanced.",
    "S": "Lean slightly toward concrete details, but stay balanced.",
    "N": "Lean slightly toward big-picture thinking, but stay balanced.",
    "T": "Lean slightly toward logical framing, but stay balanced.",
    "F": "Lean slightly toward empathetic framing, but stay balanced.",
    "J": "Lean slightly toward structured closure, but stay balanced.",
    "P": "Lean slightly toward flexible exploration, but stay balanced.",
}

# All 16 MBTI types for random assignment.
_ALL_MBTI_TYPES: list[str] = [
    "INTJ",
    "INTP",
    "ENTJ",
    "ENTP",
    "INFJ",
    "INFP",
    "ENFJ",
    "ENFP",
    "ISTJ",
    "ISFJ",
    "ESTJ",
    "ESFJ",
    "ISTP",
    "ISFP",
    "ESTP",
    "ESFP",
]

# Maximum number of hints injected per turn to control token usage.
_MAX_HINTS_PER_TURN = 3

# ---------------------------------------------------------------------------
# Regex patterns for IDENTITY.md parsing
# ---------------------------------------------------------------------------

# Match MBTI type line (supports both English and Chinese labels).
_MBTI_REGEX = re.compile(r"\*\*类型[：:]\s*\*\*\s*([A-Z]{4})", re.IGNORECASE)
_MBTI_VALIDATE = re.compile(r"^[EI][SN][TF][JP]$", re.IGNORECASE)

# Match: E/I: E 65%  or  E/I: I 70%
_PERCENT_REGEX = re.compile(
    r"E/I[：:]\s*([EI])\s*(\d+)%.*?"
    r"S/N[：:]\s*([SN])\s*(\d+)%.*?"
    r"T/F[：:]\s*([TF])\s*(\d+)%.*?"
    r"J/P[：:]\s*([JP])\s*(\d+)%",
    re.IGNORECASE | re.DOTALL,
)

# Match descriptor line (supports both English and Chinese labels).
_DESCRIPTORS_REGEX = re.compile(
    r"\*\*(?:描述词|Descriptors)[：:]\s*\*\*\s*(.+)",
    re.IGNORECASE,
)

# Default percentage for legacy format (4-letter code only, no percentages).
_DEFAULT_PERCENTAGE = 70


@dataclass
class _PersonalityProfile:
    """Parsed personality data from IDENTITY.md."""

    mbti_type: str = ""
    descriptors: str = ""
    # Percentage for each dimension pole (the dominant side).
    # Key is the dominant letter, value is the percentage (50-100).
    dimensions: dict[str, int] = field(default_factory=dict)

    @property
    def is_valid(self) -> bool:
        """Return True if at least a 4-letter MBTI type is present."""
        return bool(self.mbti_type)

    def pole_for(self, axis: str) -> tuple[str, int]:
        """Return (dominant_letter, percentage) for a given axis pair.

        *axis* should be one of ``"EI"``, ``"SN"``, ``"TF"``, ``"JP"``.
        """
        for letter in axis:
            if letter in self.dimensions:
                return letter, self.dimensions[letter]
        # Fallback: derive from mbti_type with default percentage.
        for letter in axis:
            if letter.upper() in self.mbti_type.upper():
                return letter.upper(), _DEFAULT_PERCENTAGE
        return axis[0], 50  # Should not reach here.


class PersonalityInjector:
    """Rule-engine personality injector (zero LLM cost).

    Reads the MBTI type, dimension percentages, and descriptors once from
    IDENTITY.md (cached), detects the conversation scene from the latest
    user message, and returns a formatted ``<personality-context>`` block
    for middleware injection.

    Percentage-driven hint selection:
    - ≥70%: full scene-specific hint
    - 60-69%: weakened generic hint
    - <60%: no hint for that dimension (too neutral)
    """

    def __init__(self, working_dir: Path, language: str = "zh") -> None:
        self._working_dir = working_dir
        self._language = language
        self._profile: _PersonalityProfile | None = None
        self._identity_mtime: float = 0.0

    # ------------------------------------------------------------------
    # Loading & parsing
    # ------------------------------------------------------------------

    def _load_profile(self) -> _PersonalityProfile:
        """Parse personality profile from IDENTITY.md.

        If no valid type is found but the file exists, randomly assign one
        and write it back so every agent always has a personality.
        """
        identity_path = self._working_dir / "IDENTITY.md"
        if not identity_path.exists():
            logger.info("[Personality][io] op=check_identity path=%s exists=false", identity_path)
            return _PersonalityProfile()

        try:
            io_started_at = time.perf_counter()
            mtime = identity_path.stat().st_mtime
            if self._profile is not None and mtime == self._identity_mtime:
                logger.info(
                    "[Personality][io] op=stat_identity path=%s duration_ms=%.2f cache_hit=true",
                    identity_path,
                    (time.perf_counter() - io_started_at) * 1000,
                )
                return self._profile
            logger.info(
                "[Personality][io] op=stat_identity path=%s duration_ms=%.2f cache_hit=false",
                identity_path,
                (time.perf_counter() - io_started_at) * 1000,
            )

            io_started_at = time.perf_counter()
            content = identity_path.read_text(encoding="utf-8")
            logger.info(
                "[Personality][io] op=read_identity path=%s duration_ms=%.2f chars=%d",
                identity_path,
                (time.perf_counter() - io_started_at) * 1000,
                len(content),
            )
            profile = self._parse_identity(content)

            if profile.is_valid:
                self._profile = profile
                self._identity_mtime = mtime
                logger.debug(
                    "Loaded personality: %s dims=%s desc=%s",
                    profile.mbti_type,
                    profile.dimensions,
                    profile.descriptors,
                )
                return profile

            # No valid MBTI found — randomly assign one and persist.
            assigned = self._assign_random_mbti(identity_path, content)
            if assigned.is_valid:
                self._profile = assigned
                self._identity_mtime = identity_path.stat().st_mtime
                return assigned

            self._profile = _PersonalityProfile()
            self._identity_mtime = mtime
            return self._profile
        except Exception:
            logger.debug("Failed to read IDENTITY.md for personality profile")
            return _PersonalityProfile()

    @staticmethod
    def _parse_identity(content: str) -> _PersonalityProfile:
        """Extract MBTI type, percentages, and descriptors from file content."""
        profile = _PersonalityProfile()

        # 1. Parse 4-letter type.
        type_match = _MBTI_REGEX.search(content)
        if type_match:
            candidate = type_match.group(1).upper()
            if _MBTI_VALIDATE.match(candidate):
                profile.mbti_type = candidate

        if not profile.mbti_type:
            return profile

        # 2. Parse dimension percentages.
        pct_match = _PERCENT_REGEX.search(content)
        if pct_match:
            pairs = [
                (pct_match.group(1).upper(), int(pct_match.group(2))),
                (pct_match.group(3).upper(), int(pct_match.group(4))),
                (pct_match.group(5).upper(), int(pct_match.group(6))),
                (pct_match.group(7).upper(), int(pct_match.group(8))),
            ]
            for letter, pct in pairs:
                profile.dimensions[letter] = max(15, min(85, pct))
        else:
            # Legacy format: no percentages, derive from 4-letter code.
            for letter in profile.mbti_type:
                profile.dimensions[letter] = _DEFAULT_PERCENTAGE

        # 3. Parse descriptors.
        desc_match = _DESCRIPTORS_REGEX.search(content)
        if desc_match:
            raw = desc_match.group(1).strip()
            # Remove placeholder markers.
            if raw.startswith("*") and raw.endswith("*"):
                raw = raw.strip("*").strip()
            if raw and "（" not in raw and "(" not in raw:
                profile.descriptors = raw

        return profile

    def _assign_random_mbti(self, identity_path: Path, content: str) -> _PersonalityProfile:
        """Randomly pick an MBTI type and write a rich profile into IDENTITY.md.

        Uses the built-in profiles from mbti_profiles for descriptors, dimension
        percentages, and behaviour mappings so that the agent gets a complete
        personality even when randomly assigned.  Returns the assigned profile,
        or an empty profile on failure.
        """
        from lightclaw.agent.memory.mbti_profiles import (
            get_profile as get_mbti_profile,
        )
        from lightclaw.agent.memory.mbti_profiles import (
            render_identity_section,
        )

        chosen = random.choice(_ALL_MBTI_TYPES)
        logger.info("No MBTI type configured — randomly assigned: %s", chosen)

        mbti_profile = get_mbti_profile(chosen)
        if mbti_profile is None:
            # Fallback: bare code with default percentage (should not happen).
            pct = _DEFAULT_PERCENTAGE
            profile = _PersonalityProfile(mbti_type=chosen)
            for letter in chosen:
                profile.dimensions[letter] = pct
            return profile

        # Render a rich MBTI section from the built-in profile.
        section = render_identity_section(mbti_profile, self._language)

        # Replace or append the MBTI section in the file content.
        mbti_header_re = re.compile(
            r"^## MBTI[ 人格\u4eba\u683c]*.*?(?=^## |\Z)",
            re.MULTILINE | re.DOTALL,
        )
        if mbti_header_re.search(content):
            new_content = mbti_header_re.sub(section, content, count=1)
        else:
            new_content = content.rstrip() + "\n\n" + section

        try:
            io_started_at = time.perf_counter()
            identity_path.write_text(new_content, encoding="utf-8")
            logger.info(
                "[Personality][io] op=write_identity path=%s duration_ms=%.2f chars=%d reason=random_mbti_assign",
                identity_path,
                (time.perf_counter() - io_started_at) * 1000,
                len(new_content),
            )
            # Build the internal profile from the built-in data.
            profile = _PersonalityProfile(
                mbti_type=chosen,
                descriptors=(mbti_profile.descriptors_zh if self._language == "zh" else mbti_profile.descriptors_en),
            )
            for axis_attr in ("ei", "sn", "tf", "jp"):
                pole, pct = getattr(mbti_profile.dimensions, axis_attr)
                profile.dimensions[pole] = pct
            return profile
        except Exception:
            logger.warning("Failed to write random MBTI type to IDENTITY.md")
            return _PersonalityProfile()

    @staticmethod
    def _format_dimension_lines(mbti: str, pct: int) -> str:
        """Format dimension lines in percentage format."""
        axes = [("E", "I"), ("S", "N"), ("T", "F"), ("J", "P")]
        labels = {
            "E": "外向",
            "I": "内向",
            "S": "感知",
            "N": "直觉",
            "T": "思维",
            "F": "情感",
            "J": "判断",
            "P": "感知",
        }
        lines = []
        for a, b in axes:
            letter = a if a in mbti else b
            label = labels[letter]
            axis_name = f"{a}/{b}"
            lines.append(f"  - {axis_name}：{letter} {pct}%（{label}）")
        return "\n".join(lines)

    # ------------------------------------------------------------------
    # Scene detection
    # ------------------------------------------------------------------

    @staticmethod
    def _detect_scene(user_text: str) -> str:
        """Detect conversation scene from user text via keyword matching."""
        lower = user_text.lower()
        for scene, keywords in _SCENE_KEYWORDS.items():
            for kw in keywords:
                if kw.lower() in lower:
                    return scene
        return _DEFAULT_SCENE

    # ------------------------------------------------------------------
    # Public API
    # ------------------------------------------------------------------

    def detect_scene(self, user_text: str) -> str:
        """Return the detected conversation scene for the given user text.

        Delegates to the internal keyword-matching logic.  Exposed publicly
        so callers can gate on the scene before requesting a full block.
        """
        return self._detect_scene(user_text)

    def get_personality_block(self, last_user_text: str) -> str:
        """Build the ``<personality-context>`` block for middleware injection.

        Returns empty string if MBTI type is not configured or no hints
        match the current scene.

        Hint selection is percentage-driven:
        - ≥70%: inject the full scene-specific hint for that dimension
        - 60-69%: inject a weakened generic hint
        - <60%: skip (too neutral to warrant a hint)
        """
        profile = self._load_profile()
        if not profile.is_valid:
            return ""

        scene = self._detect_scene(last_user_text)
        scene_hints = _PERSONALITY_HINTS.get(scene, _PERSONALITY_HINTS["general"])

        # Select hints based on percentage strength.
        selected: list[str] = []
        for axis in ("EI", "SN", "TF", "JP"):
            pole, pct = profile.pole_for(axis)
            if pct >= 70:
                # Strong tendency — use full scene-specific hint.
                hint = scene_hints.get(pole)
                if hint:
                    selected.append(hint)
            elif pct >= 60:
                # Moderate tendency — use weakened generic hint.
                weak = _WEAK_HINTS.get(pole)
                if weak:
                    selected.append(weak)
            # <60% — skip, too neutral.

            if len(selected) >= _MAX_HINTS_PER_TURN:
                break

        # Only inject when there are concrete behavioural hints — the MBTI type
        # and descriptors are already present in the static IDENTITY.md block.
        if not selected:
            return ""

        # Build the block — scene hints only, no redundant type/descriptor echo.
        if self._language == "zh":
            header = f"<personality-context>\n当前对话场景（{scene}）下的行为提示：\n"
        else:
            header = f"<personality-context>\nBehavioural hints for the current scene ({scene}):\n"

        body = "\n".join(f"- {h}" for h in selected)
        footer = "\n</personality-context>"
        return header + body + footer

    def get_profile_tuple(self) -> tuple[str, dict[str, int]]:
        """Return (mbti_type, dimensions) for external callers.

        Reuses the cached _load_profile() result.
        Returns ("", {}) on any failure.
        """
        try:
            profile = self._load_profile()
            return profile.mbti_type, dict(profile.dimensions)
        except Exception:
            logger.debug("get_profile_tuple: failed to load profile")
            return "", {}

    def get_hints_for_scene(self, scene: str, language: str = "zh") -> list[str]:
        """Return personality hints for an explicitly named scene.

        Bypasses keyword detection — caller specifies the scene directly.
        Uses a flat 60% threshold (simpler than get_personality_block's
        70%/weak-hint two-tier system; proactive needs fewer, cleaner hints).

        Args:
            scene:    Scene name, e.g. "proactive_topic", "proactive_caring"
            language: "zh" or "en". When "en", looks up "{scene}_en" first,
                      falls back to "{scene}" if not found.

        Returns:
            List of hint strings (may be empty).
        """
        try:
            profile = self._load_profile()
            if not profile.is_valid:
                return []

            # Resolve scene key with language fallback
            scene_key = f"{scene}_en" if language == "en" else scene
            scene_hints = _PERSONALITY_HINTS.get(scene_key)
            if scene_hints is None:
                scene_hints = _PERSONALITY_HINTS.get(scene, {})
            if not scene_hints:
                return []

            selected: list[str] = []
            for axis in ("EI", "SN", "TF", "JP"):
                pole, pct = profile.pole_for(axis)
                if pct >= 60:
                    hint = scene_hints.get(pole)
                    if hint:
                        selected.append(hint)
                if len(selected) >= _MAX_HINTS_PER_TURN:
                    break

            return selected
        except Exception:
            logger.debug("get_hints_for_scene: failed for scene=%s", scene)
            return []
