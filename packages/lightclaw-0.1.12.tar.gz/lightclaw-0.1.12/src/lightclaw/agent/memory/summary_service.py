"""Summary generation and dedup services for memory notes."""

from __future__ import annotations

import logging
from collections.abc import Awaitable, Callable
from pathlib import Path
from typing import Any

from lightclaw.agent.memory.summary_blocks import split_summary_into_blocks

if False:  # pragma: no cover - typing only
    pass


class SummaryService:
    """Generate daily memory summaries and deduplicate persisted notes."""

    def summary_system_prompt(self, language: str) -> str:
        """Return a structured system prompt for long-term memory extraction."""
        from lightclaw.agent.prompt_catalog import get_summary_system_prompt

        return get_summary_system_prompt(language)

    async def dedup_summary_against_existing(
        self,
        summary_text: str,
        memory_searcher: Any,
        logger: logging.Logger,
    ) -> str:
        """Remove summary blocks that are near-duplicates of existing memory."""
        if memory_searcher is None or not summary_text.strip():
            return summary_text

        from lightclaw.agent.memory.dedup import (
            create_dedup_config_from_env,
            jaccard_similarity,
        )
        from lightclaw.agent.memory.qdrant_searcher import SearchConfig

        config = create_dedup_config_from_env()
        if not config.enabled:
            return summary_text

        blocks = split_summary_into_blocks(summary_text)
        if len(blocks) <= 1:
            return summary_text

        kept_blocks: list[str] = []
        for block in blocks:
            text = block.strip()
            if not text or text.startswith("#"):
                kept_blocks.append(block)
                continue

            if len(text) < 20:
                kept_blocks.append(block)
                continue

            try:
                cfg = SearchConfig(max_results=3, min_score=0.5)
                results = await memory_searcher.search(text, config=cfg)

                is_dup = False
                for result in results:
                    # Prefer vector score (cosine similarity) when available;
                    # fall back to Jaccard only in FTS-only mode (score == 0).
                    if result.score > 0:
                        sim = result.score
                        threshold = config.vector_skip_threshold
                        method = "vector"
                    else:
                        sim = jaccard_similarity(text, result.snippet)
                        threshold = config.jaccard_skip_threshold
                        method = "jaccard"
                    if sim >= threshold:
                        logger.info(
                            "Summary dedup: omitting block (%.3f %s with %s): %.80s",
                            sim,
                            method,
                            result.chunk_id,
                            text,
                        )
                        is_dup = True
                        break
                if not is_dup:
                    kept_blocks.append(block)
            except Exception:
                kept_blocks.append(block)

        result = "\n\n".join(kept_blocks).strip()
        if not result:
            logger.warning("Summary dedup removed ALL blocks — keeping original")
            return summary_text
        return result

    async def summary_memory(
        self,
        *,
        messages: list[Any],
        date: str,
        channel: str,
        session_id: str,
        language: str,
        working_dir: str,
        memory_searcher: Any,
        logger: logging.Logger,
        extract_message_text: Callable[[Any], str],
        invoke_llm_with_tools: Callable[[str, str], Awaitable[str]],
    ) -> str:
        """Generate and persist memory summary from conversation messages."""
        text = "\n\n".join(extract_message_text(msg) for msg in messages)
        if not text.strip():
            return ""

        meta = f"Date: {date}"
        if channel:
            meta += f" | Channel: {channel}"
        if session_id:
            meta += f" | Session: {session_id}"

        from lightclaw.agent.prompt_catalog import get_summary_user_prompt_template

        prompt = get_summary_user_prompt_template(language).format(meta=meta, text=text)

        try:
            result = await invoke_llm_with_tools(
                self.summary_system_prompt(language),
                prompt,
            )
            logger.info("Memory Summary Result:\n%s", result)

            result = await self.dedup_summary_against_existing(result, memory_searcher, logger)

            if result.strip():
                memory_dir = Path(working_dir) / "memory"
                memory_dir.mkdir(parents=True, exist_ok=True)
                filepath = memory_dir / f"{date}.md"

                meta_bits: list[str] = []
                if channel:
                    meta_bits.append(f"channel={channel}")
                if session_id:
                    meta_bits.append(f"session={session_id}")

                block_header = "## Auto Summary"
                if meta_bits:
                    block_header += f" ({', '.join(meta_bits)})"

                block = f"{block_header}\n\n{result.strip()}\n"
                if filepath.exists():
                    try:
                        existing = filepath.read_text(encoding="utf-8").strip()
                    except OSError:
                        existing = ""
                    if existing:
                        block = f"\n\n---\n\n{block}"

                with open(filepath, "a", encoding="utf-8") as file_obj:
                    file_obj.write(block)
                logger.info("Memory summary appended to %s", filepath)

            return result
        except Exception as exc:
            logger.exception("Failed to generate memory summary: %s", exc)
            return ""
