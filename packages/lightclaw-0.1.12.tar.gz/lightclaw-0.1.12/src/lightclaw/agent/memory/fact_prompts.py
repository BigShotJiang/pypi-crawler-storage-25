"""LLM prompts for structured fact extraction and conflict resolution.

Separated from the extraction logic so prompts can be tuned independently.
All prompts are bilingual (English primary, Chinese examples) because the
user base is primarily Chinese-speaking but facts should be stored in a
language-neutral way.
"""

from __future__ import annotations

from lightclaw.agent.prompt_catalog import (
    get_conflict_resolution_system_prompt_template,
    get_fact_extraction_system_prompt_template,
)

# ---------------------------------------------------------------------------
# Fact extraction — run after each conversation turn
# ---------------------------------------------------------------------------

EXTRACTION_SYSTEM_PROMPT = get_fact_extraction_system_prompt_template()

EXTRACTION_USER_TEMPLATE = """\
<conversation-turn>
<user>{user_message}</user>
<assistant>{assistant_message}</assistant>
</conversation-turn>

Extract structured facts from this turn. Return a JSON array:
```json
[
  {{"content": "fact text", "category": "category_name", "importance": 0.8}},
  ...
]
```
Return `[]` if no durable facts are present. Return ONLY the JSON array, \
no other text."""

# ---------------------------------------------------------------------------
# Conflict resolution — run for each candidate that has similar existing facts
# ---------------------------------------------------------------------------

CONFLICT_SYSTEM_PROMPT = get_conflict_resolution_system_prompt_template()

CONFLICT_USER_TEMPLATE = """\
<new-fact>
{candidate_content} (category: {candidate_category}, importance: {candidate_importance})
</new-fact>

<existing-facts>
{existing_facts_xml}
</existing-facts>

Decide the action. Return a single JSON object:
```json
{{"action": "ADD|UPDATE|DELETE|NOOP", "target_fact_id": null, \
"merged_content": "updated text if UPDATE, else null", \
"reason": "brief explanation"}}
```
- For ADD: target_fact_id=null, merged_content=null
- For UPDATE: target_fact_id=<id of fact to update>, merged_content=<new text>
- For DELETE: target_fact_id=<id of fact to delete>, merged_content=null
- For NOOP: target_fact_id=null, merged_content=null

Return ONLY the JSON object, no other text."""


def format_extraction_prompt(
    user_message: str,
    assistant_message: str,
    max_facts: int = 5,
) -> tuple[str, str]:
    """Return (system_prompt, user_prompt) for fact extraction.

    Args:
        user_message: The user's message text.
        assistant_message: The assistant's response text.
        max_facts: Maximum facts to extract per turn.

    Returns:
        A tuple of (system_prompt, user_prompt).
    """
    system = EXTRACTION_SYSTEM_PROMPT.format(max_facts=max_facts)
    user = EXTRACTION_USER_TEMPLATE.format(
        user_message=user_message,
        assistant_message=assistant_message,
    )
    return system, user


def format_conflict_prompt(
    candidate_content: str,
    candidate_category: str,
    candidate_importance: float,
    existing_facts: list[dict],
) -> tuple[str, str]:
    """Return (system_prompt, user_prompt) for conflict resolution.

    Args:
        candidate_content: The new fact candidate text.
        candidate_category: Category of the candidate.
        candidate_importance: Importance score of the candidate.
        existing_facts: List of similar existing facts (dicts with
            ``id``, ``content``, ``category``, ``importance``).

    Returns:
        A tuple of (system_prompt, user_prompt).
    """
    facts_xml_parts = []
    for f in existing_facts:
        facts_xml_parts.append(
            f'<fact id="{f["id"]}" category="{f["category"]}" importance="{f["importance"]}">{f["content"]}</fact>'
        )
    existing_xml = "\n".join(facts_xml_parts) if facts_xml_parts else "<none />"

    user = CONFLICT_USER_TEMPLATE.format(
        candidate_content=candidate_content,
        candidate_category=candidate_category,
        candidate_importance=candidate_importance,
        existing_facts_xml=existing_xml,
    )
    return CONFLICT_SYSTEM_PROMPT, user
