"""Index-time and summary-time memory deduplication utilities.

Provides dual-mode dedup: cosine similarity when Qdrant/embeddings are available,
Jaccard similarity with FTS5 fallback when running in FTS-only mode.
"""

from __future__ import annotations

import logging
import os
import re
import sqlite3
from dataclasses import dataclass
from typing import Any

logger = logging.getLogger(__name__)


# ── Configuration ────────────────────────────────────────────────────────────


@dataclass
class DedupConfig:
    """Dedup thresholds, configurable via environment variables."""

    # Cosine similarity: above this, new chunk is skipped (near-identical)
    vector_skip_threshold: float = 0.95
    # Cosine similarity: above this, log a warning (similar but not identical)
    vector_warn_threshold: float = 0.85
    # Jaccard similarity: above this, new chunk is skipped (FTS-only fallback)
    jaccard_skip_threshold: float = 0.80
    # Jaccard similarity: above this, log a warning
    jaccard_warn_threshold: float = 0.60
    # Whether index-time dedup is enabled
    enabled: bool = True
    # Max number of existing chunks to compare against (performance cap)
    max_comparisons: int = 200


def create_dedup_config_from_env() -> DedupConfig:
    """Create DedupConfig from environment variables."""
    return DedupConfig(
        enabled=os.environ.get("MEMORY_DEDUP_ENABLED", "true").lower() == "true",
        vector_skip_threshold=float(os.environ.get("MEMORY_DEDUP_VECTOR_SKIP", "0.95")),
        vector_warn_threshold=float(os.environ.get("MEMORY_DEDUP_VECTOR_WARN", "0.85")),
        jaccard_skip_threshold=float(os.environ.get("MEMORY_DEDUP_JACCARD_SKIP", "0.80")),
        jaccard_warn_threshold=float(os.environ.get("MEMORY_DEDUP_JACCARD_WARN", "0.60")),
        max_comparisons=int(os.environ.get("MEMORY_DEDUP_MAX_COMPARISONS", "200")),
    )


# ── Jaccard similarity with CJK support ─────────────────────────────────────

_CJK_RE = re.compile(r"[\u4e00-\u9fff]")
_LATIN_TOKEN_RE = re.compile(r"[a-z0-9_]+")


def _tokenize_dedup(text: str) -> frozenset[str]:
    """Tokenize text for Jaccard dedup comparison.

    Handles both Latin tokens and CJK characters (as unigrams + bigrams).
    """
    lower = text.lower()
    tokens: set[str] = set(_LATIN_TOKEN_RE.findall(lower))
    # CJK characters: add unigrams and bigrams for better granularity
    cjk_chars = _CJK_RE.findall(text)
    tokens.update(cjk_chars)
    for i in range(len(cjk_chars) - 1):
        tokens.add(cjk_chars[i] + cjk_chars[i + 1])
    return frozenset(tokens)


def jaccard_similarity(text_a: str, text_b: str) -> float:
    """Compute Jaccard similarity between two text chunks."""
    set_a = _tokenize_dedup(text_a)
    set_b = _tokenize_dedup(text_b)
    if not set_a and not set_b:
        return 1.0
    if not set_a or not set_b:
        return 0.0
    intersection = len(set_a & set_b)
    union = len(set_a | set_b)
    return intersection / union if union > 0 else 0.0


# ── FTS-based duplicate lookup ───────────────────────────────────────────────


def find_similar_fts_chunks(
    db: sqlite3.Connection,
    text: str,
    exclude_path: str,
    config: DedupConfig,
) -> list[tuple[str, str, float]]:
    """Find existing FTS chunks similar to the given text, excluding a specific file.

    Uses FTS5 BM25 to find candidates, then Jaccard to measure true similarity.

    Returns:
        List of (chunk_id, existing_text, jaccard_score) tuples,
        sorted by similarity descending.
    """
    from lightclaw.agent.memory.query_expansion import extract_keywords

    keywords = extract_keywords(text)
    if not keywords:
        # Fallback: take first several significant tokens
        keywords = [w for w in text.split()[:10] if len(w) > 1]
    if not keywords:
        return []

    # Build OR query for broad candidate retrieval
    fts_terms = []
    for kw in keywords[:15]:
        # Escape double quotes inside the keyword
        safe_kw = kw.replace('"', '""')
        fts_terms.append(f'"{safe_kw}"')
    fts_query = " OR ".join(fts_terms)

    try:
        rows = db.execute(
            """
            SELECT text, id, path
            FROM chunks_fts
            WHERE chunks_fts MATCH ? AND path != ?
            ORDER BY bm25(chunks_fts) ASC
            LIMIT ?
            """,
            (fts_query, exclude_path, config.max_comparisons),
        ).fetchall()
    except sqlite3.OperationalError:
        logger.debug("FTS dedup query failed, skipping", exc_info=True)
        return []

    results: list[tuple[str, str, float]] = []
    for row_text, chunk_id, _path in rows:
        sim = jaccard_similarity(text, row_text)
        if sim >= config.jaccard_warn_threshold:
            results.append((chunk_id, row_text, sim))

    results.sort(key=lambda x: x[2], reverse=True)
    return results


# ── Vector-based duplicate lookup ────────────────────────────────────────────


async def find_similar_vector_chunks(
    client: Any,
    collection_name: str,
    embedding: list[float],
    exclude_path: str,
    config: DedupConfig,
) -> list[tuple[str, str, float]]:
    """Find existing vector chunks similar to the given embedding.

    Queries Qdrant for nearest neighbors, excluding chunks from the same file.

    Returns:
        List of (chunk_id, snippet, cosine_score) tuples,
        sorted by similarity descending.
    """
    if not embedding:
        return []

    try:
        from qdrant_client.models import FieldCondition, Filter, MatchValue

        resp = await client.query_points(
            collection_name=collection_name,
            query=embedding,
            limit=config.max_comparisons,
            query_filter=Filter(must_not=[FieldCondition(key="path", match=MatchValue(value=exclude_path))]),
            with_payload=True,
        )
        hits = resp.points

        results: list[tuple[str, str, float]] = []
        for hit in hits:
            score = float(hit.score)
            if score >= config.vector_warn_threshold:
                payload = hit.payload or {}
                chunk_id = payload.get("chunk_id", str(hit.id))
                snippet = payload.get("snippet", "")
                results.append((chunk_id, snippet, score))

        results.sort(key=lambda x: x[2], reverse=True)
        return results

    except Exception:
        logger.debug("Vector dedup query failed, skipping", exc_info=True)
        return []


# ── Unified dedup decision ───────────────────────────────────────────────────


@dataclass
class DedupVerdict:
    """Result of checking a single chunk for duplicates."""

    action: str  # "keep", "skip", "warn"
    best_match_id: str = ""
    best_match_text: str = ""
    similarity: float = 0.0
    method: str = ""  # "vector" or "jaccard"


async def check_chunk_duplicate(
    text: str,
    embedding: list[float],
    exclude_path: str,
    fts_db: sqlite3.Connection,
    qdrant_client: Any | None,
    collection_name: str,
    config: DedupConfig,
) -> DedupVerdict:
    """Check whether a chunk is a duplicate of existing indexed content.

    Uses vector similarity when available, falls back to Jaccard on FTS.
    """
    if not config.enabled:
        return DedupVerdict(action="keep")

    # Strategy 1: Vector-based (preferred, more accurate)
    if qdrant_client is not None and embedding:
        matches = await find_similar_vector_chunks(
            qdrant_client,
            collection_name,
            embedding,
            exclude_path,
            config,
        )
        if matches:
            best_id, best_text, best_score = matches[0]
            if best_score >= config.vector_skip_threshold:
                return DedupVerdict(
                    action="skip",
                    best_match_id=best_id,
                    best_match_text=best_text,
                    similarity=best_score,
                    method="vector",
                )
            if best_score >= config.vector_warn_threshold:
                return DedupVerdict(
                    action="warn",
                    best_match_id=best_id,
                    best_match_text=best_text,
                    similarity=best_score,
                    method="vector",
                )
        return DedupVerdict(action="keep")

    # Strategy 2: Jaccard fallback (FTS-only mode)
    matches = find_similar_fts_chunks(fts_db, text, exclude_path, config)
    if matches:
        best_id, best_text, best_score = matches[0]
        if best_score >= config.jaccard_skip_threshold:
            return DedupVerdict(
                action="skip",
                best_match_id=best_id,
                best_match_text=best_text,
                similarity=best_score,
                method="jaccard",
            )
        if best_score >= config.jaccard_warn_threshold:
            return DedupVerdict(
                action="warn",
                best_match_id=best_id,
                best_match_text=best_text,
                similarity=best_score,
                method="jaccard",
            )

    return DedupVerdict(action="keep")
