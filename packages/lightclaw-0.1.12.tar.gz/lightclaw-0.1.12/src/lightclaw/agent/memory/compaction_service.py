"""Compaction pipeline service for conversation memory summaries."""

from __future__ import annotations

import logging
from collections.abc import Awaitable, Callable
from typing import Any

from langchain_core.messages import BaseMessage, ToolMessage

from lightclaw.agent.memory.compaction_config import CompactionConfig
from lightclaw.agent.prompt_catalog import get_compaction_system_prompt
from lightclaw.agent.utils.text_sanitizer import sanitize_summary_text
from lightclaw.agent.utils.token_counting import count_str_tokens
from lightclaw.config.utils import load_config

_MAX_TOOL_FAILURES = 8
_MAX_TOOL_FAILURE_CHARS = 240
_SUMMARIZATION_OVERHEAD_TOKENS = 4096


class CompactionService:
    """Build and run the full compaction/summarization safeguard pipeline."""

    def build_compaction_prompt(self, config: CompactionConfig, language: str) -> str:
        """Build a structured system prompt for compaction."""
        if config.identifier_policy == "strict":
            id_instruction = (
                "Preserve all opaque identifiers exactly as written "
                "(no shortening or reconstruction), including UUIDs, hashes, "
                "IDs, tokens, API keys, hostnames, IPs, ports, URLs, and file names."
            )
        elif config.identifier_policy == "custom" and config.identifier_instructions:
            id_instruction = config.identifier_instructions[:4000]
        else:
            id_instruction = (
                "Include identifiers only when needed for continuity; do not enforce literal-preservation rules."
            )

        custom_block = ""
        if config.custom_instructions:
            custom_block = f"\n\nADDITIONAL INSTRUCTIONS:\n{config.custom_instructions}"

        return get_compaction_system_prompt(
            language=language,
            id_instruction=id_instruction,
            custom_block=custom_block,
        )

    def collect_tool_failures(self, messages: list[Any]) -> str:
        """Extract failed tool calls and format as a summary section."""
        failures: list[str] = []
        seen_ids: set[str] = set()

        for msg in messages:
            if not isinstance(msg, ToolMessage):
                continue
            status = getattr(msg, "status", None)
            is_error = status == "error"
            if not is_error:
                additional = getattr(msg, "additional_kwargs", {}) or {}
                is_error = additional.get("isError", False)
            if not is_error:
                continue

            tool_call_id = getattr(msg, "tool_call_id", "") or ""
            if tool_call_id in seen_ids:
                continue
            if tool_call_id:
                seen_ids.add(tool_call_id)

            tool_name = getattr(msg, "name", "") or "tool"
            content = msg.content if isinstance(msg.content, str) else str(msg.content)
            content = " ".join(content.split()).strip()
            if len(content) > _MAX_TOOL_FAILURE_CHARS:
                content = content[: _MAX_TOOL_FAILURE_CHARS - 3] + "..."

            failures.append(f"- {tool_name}: {content}")
            if len(failures) >= _MAX_TOOL_FAILURES:
                break

        if not failures:
            return ""
        return "\n\n## Tool Failures\n" + "\n".join(failures)

    def compute_adaptive_chunks(
        self,
        messages: list[Any],
        context_window: int,
        config: CompactionConfig,
        extract_message_text: Callable[[Any], str],
        logger: logging.Logger,
    ) -> list[list[Any]]:
        """Split messages into adaptive-size chunks based on message complexity."""
        if not messages:
            return []

        msg_texts = [extract_message_text(msg) for msg in messages]
        msg_tokens = [count_str_tokens(text) for text in msg_texts]
        total_tokens = sum(msg_tokens)
        if total_tokens == 0:
            return [messages]

        avg_msg_tokens = total_tokens / len(messages)
        context_10pct = context_window * 0.1
        if avg_msg_tokens > context_10pct:
            ratio = max(
                config.min_chunk_ratio,
                config.base_chunk_ratio * (context_10pct / avg_msg_tokens),
            )
        else:
            ratio = config.base_chunk_ratio

        chunk_budget = int(context_window * ratio / config.safety_margin)
        chunk_budget = max(chunk_budget, _SUMMARIZATION_OVERHEAD_TOKENS * 2)

        chunks: list[list[Any]] = []
        current_chunk: list[Any] = []
        current_tokens = 0
        for msg, token_count in zip(messages, msg_tokens, strict=True):
            if current_tokens + token_count > chunk_budget and current_chunk:
                chunks.append(current_chunk)
                current_chunk = []
                current_tokens = 0
            current_chunk.append(msg)
            current_tokens += token_count
        if current_chunk:
            chunks.append(current_chunk)

        logger.info(
            "Adaptive chunking: %d messages → %d chunks (avg_msg=%d tokens, ratio=%.2f, budget=%d tokens/chunk)",
            len(messages),
            len(chunks),
            int(avg_msg_tokens),
            ratio,
            chunk_budget,
        )
        return chunks

    async def summarize_in_stages(
        self,
        *,
        chunks: list[list[Any]],
        previous_summary: str,
        system_prompt: str,
        language: str,
        extract_message_text: Callable[[Any], str],
        invoke_llm: Callable[[str, str], Awaitable[str]],
        logger: logging.Logger,
    ) -> str:
        """Summarize chunks independently, then merge partial summaries."""
        if len(chunks) == 1:
            text = "\n\n".join(extract_message_text(msg) for msg in chunks[0])
            prompt_parts: list[str] = []
            if previous_summary:
                prompt_parts.append(f"Previous summary:\n{previous_summary}")
            prompt_parts.append(f"Conversation to summarize:\n{text}")
            prompt = "\n\n".join(prompt_parts).strip()
            return await invoke_llm(system_prompt, prompt)

        partial_summaries: list[str] = []
        for idx, chunk in enumerate(chunks):
            text = "\n\n".join(extract_message_text(msg) for msg in chunk)
            chunk_prompt_parts: list[str] = []
            if idx == 0 and previous_summary:
                chunk_prompt_parts.append(f"Previous summary:\n{previous_summary}")
            chunk_prompt_parts.append(f"Conversation chunk {idx + 1}/{len(chunks)} to summarize:\n{text}")
            chunk_prompt = "\n\n".join(chunk_prompt_parts).strip()
            partial = await invoke_llm(system_prompt, chunk_prompt)
            partial_summaries.append(partial)
            logger.info("Stage %d/%d summarized (%d chars)", idx + 1, len(chunks), len(partial))

        if language == "zh":
            merge_instruction = (
                "将以下部分摘要合并为一个连贯的完整摘要。保留所有必需的 section，合并重复内容，保持时间顺序。\n\n"
            )
        else:
            merge_instruction = (
                "Merge the following partial summaries into a single cohesive summary. "
                "Preserve all required sections, deduplicate, keep chronological order.\n\n"
            )
        parts_text = "\n\n---\n\n".join(f"[Part {idx + 1}]\n{summary}" for idx, summary in enumerate(partial_summaries))
        merge_prompt = f"{merge_instruction}{parts_text}"
        return await invoke_llm(system_prompt, merge_prompt)

    async def compact_memory(
        self,
        *,
        messages_to_summarize: list[Any] | None,
        turn_prefix_messages: list[Any] | None,
        previous_summary: str,
        config: CompactionConfig | None,
        language: str,
        extract_message_text: Callable[[Any], str],
        invoke_llm: Callable[[str, str], Awaitable[str]],
        logger: logging.Logger,
    ) -> str:
        """Compact conversation messages into a structured summary."""
        config = config or CompactionConfig()
        summarize_msgs = messages_to_summarize or []
        prefix_msgs = turn_prefix_messages or []
        if not summarize_msgs and not prefix_msgs:
            return ""
        all_msgs = summarize_msgs + prefix_msgs

        system_prompt = self.build_compaction_prompt(config, language)
        context_window = load_config().agents.running.max_input_length
        chunks = self.compute_adaptive_chunks(
            summarize_msgs,
            context_window,
            config,
            extract_message_text,
            logger,
        )
        if not chunks:
            chunks = [summarize_msgs] if summarize_msgs else []

        if chunks:
            summary = await self.summarize_in_stages(
                chunks=chunks,
                previous_summary=previous_summary,
                system_prompt=system_prompt,
                language=language,
                extract_message_text=extract_message_text,
                invoke_llm=invoke_llm,
                logger=logger,
            )
        elif previous_summary:
            summary = previous_summary
        else:
            summary = ""

        if prefix_msgs and summary:
            prefix_text = "\n\n".join(extract_message_text(msg) for msg in prefix_msgs)
            if prefix_text.strip():
                if language == "zh":
                    addendum_prompt = (
                        "以下是当前摘要和最近的上下文。请将最近上下文中的关键信息整合到摘要中。\n\n"
                        f"当前摘要:\n{summary}\n\n最近上下文:\n{prefix_text}"
                    )
                else:
                    addendum_prompt = (
                        "Below is the current summary and recent context. "
                        "Integrate key information from the recent context into the summary.\n\n"
                        f"Current summary:\n{summary}\n\nRecent context:\n{prefix_text}"
                    )
                summary = await invoke_llm(system_prompt, addendum_prompt)

        tool_failures_section = self.collect_tool_failures(all_msgs)
        if tool_failures_section:
            summary = summary.rstrip() + tool_failures_section

        if config.quality_guard_enabled and summary:
            from lightclaw.agent.memory.compaction_quality_guard import audit_and_retry

            original_text = "\n\n".join(extract_message_text(msg) for msg in all_msgs)
            base_prompt_parts: list[str] = []
            if previous_summary:
                base_prompt_parts.append(f"Previous summary:\n{previous_summary}")
            base_prompt_parts.append(f"Conversation to summarize:\n{original_text}")
            base_user_prompt = "\n\n".join(base_prompt_parts).strip()

            summary = await audit_and_retry(
                summary=summary,
                original_messages=[msg for msg in all_msgs if isinstance(msg, BaseMessage)],
                original_text=original_text,
                config=config,
                invoke_llm=invoke_llm,
                system_prompt=system_prompt,
                base_user_prompt=base_user_prompt,
                language=language or "en",
            )

        return sanitize_summary_text(summary)
