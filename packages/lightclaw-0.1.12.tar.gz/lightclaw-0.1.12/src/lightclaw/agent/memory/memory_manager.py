"""Memory manager for LightClaw agent."""

from __future__ import annotations

import asyncio
import contextlib
import datetime
import logging
import os
import threading
from contextvars import ContextVar
from pathlib import Path
from typing import TYPE_CHECKING, Any

from lightclaw.agent.memory.compaction_config import CompactionConfig
from lightclaw.agent.memory.compaction_service import CompactionService
from lightclaw.agent.memory.distillation_service import DistillationService
from lightclaw.agent.memory.fact_extractor import FactExtractor
from lightclaw.agent.memory.fact_injector import FactInjector
from lightclaw.agent.memory.fact_store import FactStore
from lightclaw.agent.memory.memory_query_service import MemoryQueryService
from lightclaw.agent.memory.memory_store import MemoryBackendBootstrapper
from lightclaw.agent.memory.message_text_adapter import extract_message_text
from lightclaw.agent.memory.session_distillation_service import SessionDistillationService
from lightclaw.agent.memory.summary_service import SummaryService
from lightclaw.config.utils import load_config
from lightclaw.constant import FACT_EXTRACTION_ENABLED, MEMORY_COMPACT_RATIO

if TYPE_CHECKING:
    from langchain_core.language_models import BaseChatModel as LCBaseChatModel

    from lightclaw.agent.memory.memory_store import MemoryIndexer, MemorySearcher
    from lightclaw.agent.memory.temporal_resolver import DateRange

logger = logging.getLogger(__name__)


class MemoryManager:
    """Stateful facade for all memory-related runtime operations.

    This class keeps runtime dependencies (model, backend handles, config)
    and exposes stable APIs used by middleware/tools. Most heavy business
    logic lives in dedicated services and is delegated from here.
    """

    def __init__(
        self,
        working_dir: str,
    ):
        config = load_config()
        max_input_length = config.agents.running.max_input_length
        self._memory_compact_threshold = int(
            max_input_length * MEMORY_COMPACT_RATIO * 0.7,
        )

        (
            embedding_api_key,
            embedding_base_url,
            embedding_model_name,
            embedding_dimensions,
            embedding_cache_enabled,
            embedding_max_cache_size,
            embedding_max_input_length,
            embedding_max_batch_size,
        ) = self.get_emb_envs()

        vector_enabled = bool(embedding_api_key)
        if vector_enabled:
            logger.info("Vector search enabled.")
        else:
            logger.info(
                "Vector search disabled (keyword-only mode). Enable in Settings → Memory.",
            )

        self.working_dir = working_dir
        self.embedding_api_key = embedding_api_key
        self.embedding_base_url = embedding_base_url
        self.embedding_model_name = embedding_model_name
        self.embedding_dimensions = embedding_dimensions
        self.embedding_cache_enabled = embedding_cache_enabled
        self.embedding_max_cache_size = embedding_max_cache_size
        self.embedding_max_input_length = embedding_max_input_length
        self.embedding_max_batch_size = embedding_max_batch_size

        global_config = load_config()
        self.language = "zh" if global_config.agents.language == "zh" else ""
        self.summary_tasks: list[asyncio.Task] = []

        self.langchain_chat_model: LCBaseChatModel | None = None
        self._turn_chat_model: ContextVar[Any | None] = ContextVar(
            "memory_turn_chat_model",
            default=None,
        )

        # Memory retrieval backend adapters injected by bootstrapper
        # (may be hybrid or FTS-only).
        self._memory_indexer: MemoryIndexer | None = None
        self._memory_searcher: MemorySearcher | None = None
        self._backend_bootstrapper: MemoryBackendBootstrapper | None = None

        # Structured fact memory (Mem0-style per-turn extraction).
        self._fact_store: FactStore | None = None
        self._fact_extractor: FactExtractor | None = None
        self._fact_injector: FactInjector | None = None

        self._compaction_service = CompactionService()
        self._summary_service = SummaryService()
        self._query_service = MemoryQueryService()
        self._distillation_service = DistillationService()
        self._distillation_service.configure(
            interval_days=int(os.environ.get("LIGHTCLAW_DISTILL_INTERVAL_DAYS", "1")),
            lookback_days=int(os.environ.get("LIGHTCLAW_DISTILL_LOOKBACK_DAYS", "7")),
        )
        self._session_distillation_service = SessionDistillationService()
        self._session_distillation_service.configure(
            interval_hours=int(os.environ.get("LIGHTCLAW_SESSION_DISTILL_INTERVAL_HOURS", "6")),
            max_chars_per_run=int(os.environ.get("LIGHTCLAW_SESSION_DISTILL_MAX_CHARS", "30000")),
        )

        # ── Background action token bucketing ──────────────────────────
        # ContextVar tags the current async task with a scope name so that
        # _invoke_llm can attribute token spend to the correct bucket even
        # when multiple background actions run concurrently via
        # asyncio.gather / create_task.
        self._bg_scope: ContextVar[str | None] = ContextVar(
            "memory_bg_scope",
            default=None,
        )
        self._bg_usage: dict[str, dict[str, int]] = {}
        self._bg_usage_lock = threading.Lock()

    # ── Background scope helpers ─────────────────────────────────────

    @contextlib.asynccontextmanager
    async def background_scope(self, name: str):
        """Tag the current async context with a background action name.

        All ``_invoke_llm`` calls made within this scope will have their
        token usage accumulated into the named bucket in ``_bg_usage``.
        """
        token = self._bg_scope.set(name)
        try:
            yield
        finally:
            self._bg_scope.reset(token)

    def _record_bg_usage(self, raw_meta: Any) -> None:
        """Accumulate token usage into the current background scope bucket."""
        scope = self._bg_scope.get()
        if not scope or not raw_meta:
            return
        with self._bg_usage_lock:
            bucket = self._bg_usage.setdefault(
                scope,
                {"input_tokens": 0, "output_tokens": 0, "total_tokens": 0, "calls": 0},
            )
            bucket["input_tokens"] += int(raw_meta.get("input_tokens") or 0)
            bucket["output_tokens"] += int(raw_meta.get("output_tokens") or 0)
            bucket["total_tokens"] += int(raw_meta.get("total_tokens") or 0)
            bucket["calls"] += 1

    def get_background_usage(self) -> dict[str, dict[str, int]]:
        """Return a snapshot of per-action background token usage."""
        with self._bg_usage_lock:
            return {k: dict(v) for k, v in self._bg_usage.items()}

    def reset_background_usage(self) -> None:
        """Clear all background token usage buckets."""
        with self._bg_usage_lock:
            self._bg_usage.clear()

    def bind_turn_chat_model(self, model: LCBaseChatModel | None):
        """Bind a run-local chat model for downstream memory operations."""
        return self._turn_chat_model.set(model)

    def reset_turn_chat_model(self, token: object) -> None:
        """Reset run-local chat model binding using a token from bind_turn_chat_model."""
        self._turn_chat_model.reset(token)

    def _current_chat_model(self) -> LCBaseChatModel | None:
        """Resolve active chat model, preferring run-local binding."""
        return self._turn_chat_model.get() or self.langchain_chat_model

    @staticmethod
    def _safe_int(value: str | None, default: int) -> int:
        """Parse ``value`` as int; fall back to ``default`` on invalid input."""
        if value is None:
            return default
        try:
            return int(value)
        except ValueError:
            logger.warning("Invalid int value '%s', using default %d", value, default)
            return default

    @staticmethod
    def get_emb_envs():
        """Resolve embedding runtime settings from config and environment."""
        # Prefer config embedding settings; environment variables act as fallback.
        try:
            cfg_embedding = load_config().embedding
        except Exception:
            cfg_embedding = None

        if cfg_embedding is not None and cfg_embedding.provider == "custom":
            # Custom provider: read from config, allow env override.
            embedding_api_key = os.environ.get("EMBEDDING_API_KEY", "") or cfg_embedding.api_key
            embedding_base_url = os.environ.get("EMBEDDING_BASE_URL", "") or cfg_embedding.base_url
            embedding_model_name = os.environ.get("EMBEDDING_MODEL_NAME", "") or cfg_embedding.model_name
            default_dimensions = cfg_embedding.dimensions
        else:
            # None/local provider or config read failure: env-only fallback.
            embedding_api_key = os.environ.get("EMBEDDING_API_KEY", "")
            embedding_base_url = os.environ.get("EMBEDDING_BASE_URL", "")
            embedding_model_name = os.environ.get("EMBEDDING_MODEL_NAME", "")
            default_dimensions = 1024

        # Graceful degradation: log info instead of warnings when embedding
        # env vars are not configured — this is expected when provider="none".
        # Vector search will be disabled automatically (see __init__).
        if not embedding_base_url:
            logger.info(
                "EMBEDDING_BASE_URL not set. Memory vector search disabled. "
                "Enable in Settings → Memory to use semantic search."
            )
        if not embedding_model_name:
            logger.info("EMBEDDING_MODEL_NAME not set. Memory vector search disabled.")

        embedding_dimensions = MemoryManager._safe_int(
            os.environ.get("EMBEDDING_DIMENSIONS"),
            default_dimensions,
        )
        embedding_cache_enabled = os.environ.get("EMBEDDING_CACHE_ENABLED", "true").lower() == "true"
        embedding_max_cache_size = MemoryManager._safe_int(
            os.environ.get("EMBEDDING_MAX_CACHE_SIZE"),
            500,
        )
        embedding_max_input_length = MemoryManager._safe_int(
            os.environ.get("EMBEDDING_MAX_INPUT_LENGTH"),
            8192,
        )
        embedding_max_batch_size = MemoryManager._safe_int(
            os.environ.get("EMBEDDING_MAX_BATCH_SIZE"),
            4,
        )
        return (
            embedding_api_key,
            embedding_base_url,
            embedding_model_name,
            embedding_dimensions,
            embedding_cache_enabled,
            embedding_max_cache_size,
            embedding_max_input_length,
            embedding_max_batch_size,
        )

    def update_emb_envs(self):
        """Refresh embedding-related fields on the running manager instance."""
        (
            embedding_api_key,
            embedding_base_url,
            embedding_model_name,
            embedding_dimensions,
            embedding_cache_enabled,
            embedding_max_cache_size,
            embedding_max_input_length,
            embedding_max_batch_size,
        ) = self.get_emb_envs()

        self.embedding_api_key = embedding_api_key
        self.embedding_base_url = embedding_base_url
        self.embedding_model_name = embedding_model_name
        self.embedding_dimensions = embedding_dimensions
        self.embedding_cache_enabled = embedding_cache_enabled
        self.embedding_max_cache_size = embedding_max_cache_size
        self.embedding_max_input_length = embedding_max_input_length
        self.embedding_max_batch_size = embedding_max_batch_size

    async def start(self):
        """Start memory backend bootstrap and inject index/search adapters."""
        self._backend_bootstrapper = MemoryBackendBootstrapper(working_dir=self.working_dir)
        await self._backend_bootstrapper.start(self)

        # Initialize structured fact memory when enabled.
        if FACT_EXTRACTION_ENABLED:
            try:
                from lightclaw.agent.memory.init_memory_system import create_embedding_fn

                db_dir = str(self.working_dir) if isinstance(self.working_dir, str) else self.working_dir
                self._fact_store = FactStore(db_dir=db_dir)
                await self._fact_store.start()

                embedding_fn = create_embedding_fn(
                    api_key=self.embedding_api_key or None,
                    base_url=self.embedding_base_url or None,
                    model_name=self.embedding_model_name or None,
                    dimensions=self.embedding_dimensions,
                )
                self._fact_extractor = FactExtractor(
                    fact_store=self._fact_store,
                    embedding_fn=embedding_fn,
                    invoke_llm=self._invoke_llm,
                    invoke_llm_with_usage=self._invoke_llm_with_usage,
                )
                self._fact_injector = FactInjector(
                    fact_store=self._fact_store,
                    embedding_fn=embedding_fn,
                )
                logger.info("Structured fact memory: initialized (FactStore + FactExtractor + FactInjector)")
            except Exception:
                logger.exception("Structured fact memory: initialization failed, continuing without facts")
                self._fact_store = None
                self._fact_extractor = None
                self._fact_injector = None
        else:
            logger.info("Structured fact memory: disabled (LIGHTCLAW_FACT_EXTRACTION_ENABLED=false)")

        return None

    async def close(self):
        """Stop memory backend bootstrap and release backend resources."""
        if self._fact_store is not None:
            try:
                await self._fact_store.close()
            except Exception:
                logger.exception("FactStore close failed")
            self._fact_store = None
            self._fact_extractor = None
            self._fact_injector = None

        if self._backend_bootstrapper is not None:
            self._backend_bootstrapper.stop()
            self._backend_bootstrapper = None
        return None

    def get_fact_extractor(self) -> FactExtractor | None:
        """Return the active FactExtractor, or None if fact memory is disabled."""
        return self._fact_extractor

    def get_fact_injector(self) -> FactInjector | None:
        """Return the active FactInjector, or None if fact memory is disabled."""
        return self._fact_injector

    async def reload_backend(self) -> None:
        """Rebuild memory backend to apply runtime config changes."""
        if self._backend_bootstrapper is not None:
            self._backend_bootstrapper.stop()
        else:
            self._backend_bootstrapper = MemoryBackendBootstrapper(working_dir=self.working_dir)
        await self._backend_bootstrapper.start(self)

    async def _invoke_llm(
        self,
        system_prompt: str,
        user_message: str,
    ) -> str:
        """Run a plain LLM call for memory workflows.

        Uses ``SystemMessage`` + ``HumanMessage`` format. If no model has been
        injected yet, degrades gracefully to a truncated input echo to avoid
        hard-failing memory pipelines.

        Token usage is intentionally NOT reported anywhere here: background
        memory workflows (compaction, distillation, heartbeat, ...) must not
        contaminate per-conversation statistics. Callers that need to track
        their own usage should use :meth:`_invoke_llm_with_usage` instead.
        """
        model = self._current_chat_model()
        if model is None:
            return user_message[:3000]

        from langchain_core.messages import HumanMessage, SystemMessage

        result = await model.ainvoke(
            [
                SystemMessage(content=system_prompt),
                HumanMessage(content=user_message),
            ],
        )
        # Record token usage into the current background scope bucket (if any).
        self._record_bg_usage(getattr(result, "usage_metadata", None))
        return result.content if isinstance(result.content, str) else str(result.content)

    async def _invoke_llm_with_usage(
        self,
        system_prompt: str,
        user_message: str,
    ) -> tuple[str, dict[str, int]]:
        """Run a plain LLM call and return ``(text, usage)`` for the caller.

        Used by callers that need to attribute token spend to a specific
        scope (e.g. fact extraction merging into chat metadata) without
        relying on a shared global callback.
        """
        model = self._current_chat_model()
        if model is None:
            return user_message[:3000], {"input_tokens": 0, "output_tokens": 0, "total_tokens": 0}

        from langchain_core.messages import HumanMessage, SystemMessage

        result = await model.ainvoke(
            [
                SystemMessage(content=system_prompt),
                HumanMessage(content=user_message),
            ],
        )

        raw_meta = getattr(result, "usage_metadata", None) or {}
        usage = {
            "input_tokens": int(raw_meta.get("input_tokens") or 0),
            "output_tokens": int(raw_meta.get("output_tokens") or 0),
            "total_tokens": int(raw_meta.get("total_tokens") or 0),
        }
        text = result.content if isinstance(result.content, str) else str(result.content)
        return text, usage

    async def _invoke_llm_with_tools(
        self,
        system_prompt: str,
        user_message: str,
    ) -> str:
        """Run an LLM call with restricted file tools enabled.

        This path is used by memory summarization flows that may need to read
        existing memory markdown files for context during generation. Write
        tools are intentionally excluded: the caller (SummaryService) is
        responsible for deduplication and the final append, so allowing the
        LLM to append directly would produce duplicate entries in the daily
        memory file.
        """
        model = self._current_chat_model()
        if model is None:
            return await self._invoke_llm(system_prompt, user_message)

        from langchain.agents import create_agent
        from langchain_core.tools import tool

        from lightclaw.agent.tools.file_io import edit_file as _edit_file_impl
        from lightclaw.agent.tools.file_io import read_file as _read_file_impl

        @tool
        async def read_file(
            file_path: str,
            start_line: int | None = None,
            end_line: int | None = None,
        ) -> str:
            """Read file content from the workspace."""
            return (
                await _read_file_impl(
                    file_path=file_path,
                    start_line=start_line,
                    end_line=end_line,
                )
            ).to_str()

        @tool
        async def edit_file(
            file_path: str,
            old_text: str,
            new_text: str,
        ) -> str:
            """Find-and-replace exact text in a workspace file."""
            return (
                await _edit_file_impl(
                    file_path=file_path,
                    old_text=old_text,
                    new_text=new_text,
                )
            ).to_str()

        # Restricted tool mode for memory summarization workflows.
        # - read_file: allowed so LLM can reference existing memory for context.
        # - edit_file: allowed for precise in-place corrections to existing notes.
        # - append_file: intentionally excluded — SummaryService owns the append
        #   step after deduplication; LLM appending directly would bypass dedup
        #   and produce duplicate blocks in the daily memory file.
        # - write_file: excluded to prevent accidental full-file overwrites.
        graph = create_agent(
            model=model,
            tools=[read_file, edit_file],
            system_prompt=system_prompt,
        )
        result = await graph.ainvoke({"messages": [("user", user_message)]})
        final_msg = result["messages"][-1]
        return final_msg.content if isinstance(final_msg.content, str) else str(final_msg.content)

    # ── Compaction (safeguard pipeline) ────────────────────────────────

    def _build_compaction_prompt(self, config: CompactionConfig) -> str:
        """Facade wrapper to build compaction prompt via ``CompactionService``."""
        return self._compaction_service.build_compaction_prompt(
            config=config,
            language=self.language,
        )

    def _collect_tool_failures(self, messages: list[Any]) -> str:
        """Facade wrapper to collect failed tool calls from message history."""
        return self._compaction_service.collect_tool_failures(messages)

    def _compute_adaptive_chunks(
        self,
        messages: list[Any],
        context_window: int,
        config: CompactionConfig,
    ) -> list[list[Any]]:
        """Facade wrapper for adaptive token-aware chunking."""
        return self._compaction_service.compute_adaptive_chunks(
            messages=messages,
            context_window=context_window,
            config=config,
            extract_message_text=extract_message_text,
            logger=logger,
        )

    async def _summarize_in_stages(
        self,
        chunks: list[list[Any]],
        previous_summary: str,
        system_prompt: str,
    ) -> str:
        """Facade wrapper for staged summarization and merge."""
        return await self._compaction_service.summarize_in_stages(
            chunks=chunks,
            previous_summary=previous_summary,
            system_prompt=system_prompt,
            language=self.language,
            extract_message_text=extract_message_text,
            invoke_llm=self._invoke_llm,
            logger=logger,
        )

    def _summary_system_prompt(self) -> str:
        """Facade wrapper for long-term memory extraction prompt generation."""
        return self._summary_service.summary_system_prompt(self.language)

    async def compact_memory(
        self,
        messages_to_summarize: list[Any] | None = None,
        turn_prefix_messages: list[Any] | None = None,
        previous_summary: str = "",
        config: CompactionConfig | None = None,
    ) -> str:
        """Compact recent conversation context into a structured summary.

        Delegates to ``CompactionService`` and refreshes embedding settings
        first so backend-dependent behavior stays current with runtime config.
        """
        self.update_emb_envs()
        async with self.background_scope("compaction"):
            return await self._compaction_service.compact_memory(
                messages_to_summarize=messages_to_summarize,
                turn_prefix_messages=turn_prefix_messages,
                previous_summary=previous_summary,
                config=config,
                language=self.language,
                extract_message_text=extract_message_text,
                invoke_llm=self._invoke_llm,
                logger=logger,
            )

    def _next_version(self, memory_dir: Path, prefix: str) -> int:
        """Facade wrapper to compute next versioned memory filename suffix."""
        return self._summary_service.next_version(memory_dir, prefix)

    async def summary_memory(
        self,
        messages: list[Any],
        date: str,
        channel: str = "",
        session_id: str = "",
    ) -> str:
        """Generate and persist a daily memory note from conversation messages."""
        self.update_emb_envs()
        async with self.background_scope("summary"):
            result = await self._summary_service.summary_memory(
                messages=messages,
                date=date,
                channel=channel,
                session_id=session_id,
                language=self.language,
                working_dir=self.working_dir,
                memory_searcher=self._memory_searcher,
                logger=logger,
                extract_message_text=extract_message_text,
                invoke_llm_with_tools=self._invoke_llm_with_tools,
            )
        # After a successful summary write, advance the session distillation
        # baseline so the session distillation pipeline skips these messages
        # and avoids writing duplicate content into the daily memory file.
        if result and session_id:
            self._session_distillation_service.mark_session_summarized(
                working_dir=self.working_dir,
                session_id=session_id,
                message_count=len(messages),
                logger=logger,
            )
        return result

    async def _dedup_summary_against_existing(self, summary_text: str) -> str:
        """Remove blocks already represented in indexed memory content."""
        return await self._summary_service.dedup_summary_against_existing(
            summary_text=summary_text,
            memory_searcher=self._memory_searcher,
            logger=logger,
        )

    async def await_summary_tasks(self) -> str:
        """Await all pending summary tasks and return aggregated task outcomes."""
        result = ""
        for task in self.summary_tasks:
            if task.done():
                exc = task.exception()
                if exc is not None:
                    logger.exception("Summary task failed: %s", exc)
                    result += f"Summary task failed: {exc}\n"
                else:
                    done = task.result()
                    logger.info("Summary task completed: %s", done)
                    result += f"Summary task completed: {done}\n"
            else:
                try:
                    done = await task
                    logger.info("Summary task completed: %s", done)
                    result += f"Summary task completed: {done}\n"
                except Exception as exc:
                    logger.exception("Summary task failed: %s", exc)
                    result += f"Summary task failed: {exc}\n"

        self.summary_tasks.clear()
        return result

    def add_async_summary_task(
        self,
        messages: list[Any],
        date: str = "",
        channel: str = "",
        session_id: str = "",
    ):
        """Schedule background summary generation and clean finished tasks."""
        remaining_tasks = []
        for task in self.summary_tasks:
            if task.done():
                exc = task.exception()
                if exc is not None:
                    logger.exception("Summary task failed: %s", exc)
                else:
                    logger.info("Summary task completed: %s", task.result())
            else:
                remaining_tasks.append(task)
        self.summary_tasks = remaining_tasks

        self.summary_tasks.append(
            asyncio.create_task(
                self.summary_memory(
                    messages=messages,
                    date=date or datetime.datetime.now().strftime("%Y-%m-%d"),
                    channel=channel,
                    session_id=session_id,
                ),
            ),
        )

    def set_memory_backend(
        self,
        indexer: MemoryIndexer,
        searcher: MemorySearcher,
    ) -> None:
        """Inject memory indexer/searcher adapters after backend bootstrap."""
        self._memory_indexer = indexer
        self._memory_searcher = searcher
        logger.info("Memory backend searcher injected into MemoryManager")

    def set_qdrant_searcher(
        self,
        indexer: MemoryIndexer,
        searcher: MemorySearcher,
    ) -> None:
        """Backward-compatible alias for legacy bootstrap integration."""
        self.set_memory_backend(indexer, searcher)

    # ── Distillation: memory/*.md → MEMORY.md ────────────────────────────

    def _distill_stamp_path(self) -> Path:
        """Return path to the file tracking the last distillation timestamp."""
        return self._distillation_service.distill_stamp_path(self.working_dir)

    def should_distill(self) -> bool:
        """Return whether distillation interval requirements are satisfied."""
        return self._distillation_service.should_distill(self.working_dir)

    async def distill_to_memory_md(self) -> str:
        """Distill recent daily notes into ``MEMORY.md`` via service pipeline."""
        async with self.background_scope("distillation"):
            return await self._distillation_service.distill_to_memory_md(
                working_dir=self.working_dir,
                language=self.language,
                logger=logger,
                invoke_llm=self._invoke_llm,
                dedup_summary_against_existing=self._dedup_summary_against_existing,
            )

    # ── Session distillation: sessions/*.json → memory/YYYY-MM-DD.md ──────

    def should_distill_sessions(self) -> bool:
        """Return whether session distillation interval requirements are satisfied."""
        return self._session_distillation_service.should_distill(self.working_dir)

    async def distill_sessions_to_daily_md(self) -> str:
        """Distill incremental session deltas into today's daily memory file."""
        async with self.background_scope("session_distillation"):
            return await self._session_distillation_service.distill_sessions_to_daily_md(
                working_dir=self.working_dir,
                language=self.language,
                logger=logger,
                invoke_llm=self._invoke_llm,
                dedup_summary_against_existing=self._dedup_summary_against_existing,
            )

    def _touch_distill_stamp(self) -> None:
        """Update the 'last distill run' timestamp file."""
        self._distillation_service.touch_distill_stamp(self.working_dir, logger)

    async def memory_search(
        self,
        query: str,
        max_results: int = 5,
        min_score: float = 0.3,
        date_range: DateRange | None = None,
    ) -> str:
        """Search indexed memory and return a formatted user-facing result."""
        return await self._query_service.memory_search(
            query=query,
            max_results=max_results,
            min_score=min_score,
            memory_searcher=self._memory_searcher,
            logger=logger,
            session_distillation_service=self._session_distillation_service,
            working_dir=self.working_dir,
            date_range=date_range,
        )

    async def memory_search_indexed(
        self,
        query: str,
        max_results: int = 5,
        min_score: float = 0.3,
        date_range: DateRange | None = None,
    ) -> str:
        """Search only the indexed memory backend, excluding raw session history."""
        if self._memory_searcher is None:
            return "No memory backend available."

        return await self._query_service.backend_memory_search(
            query=query,
            max_results=max_results,
            min_score=min_score,
            memory_searcher=self._memory_searcher,
            logger=logger,
            date_range=date_range,
        )

    async def memory_get(
        self,
        path: str,
        offset: int | None = None,
        limit: int | None = None,
    ) -> str:
        """Read memory file content through the active backend indexer."""
        return await self._query_service.memory_get(
            path=path,
            offset=offset,
            limit=limit,
            memory_indexer=self._memory_indexer,
            logger=logger,
        )

    async def memory_status(self) -> dict:
        """Return memory backend health/status metrics for diagnostics/UI."""
        status = await self._query_service.memory_status(
            memory_indexer=self._memory_indexer,
            memory_searcher=self._memory_searcher,
            logger=logger,
        )
        # Surface degraded-mode flag so callers (UI, health checks) can alert users.
        if self._backend_bootstrapper is not None:
            status["degraded"] = self._backend_bootstrapper.is_degraded
        else:
            status["degraded"] = False
        return status

    # ── Memory Forget (deletion) ──────────────────────────────────────────

    async def memory_forget_by_query(
        self,
        query: str,
        max_candidates: int = 5,
        min_score: float = 0.5,
        auto_delete_threshold: float = 0.9,
    ) -> str:
        """Forget memory chunks by semantic query with safe candidate fallback."""
        return await self._query_service.memory_forget_by_query(
            query=query,
            max_candidates=max_candidates,
            min_score=min_score,
            auto_delete_threshold=auto_delete_threshold,
            memory_searcher=self._memory_searcher,
            memory_indexer=self._memory_indexer,
            logger=logger,
        )

    async def memory_forget_by_file(
        self,
        file_name: str,
    ) -> str:
        """Delete one memory file and clean corresponding vector chunks."""
        return await self._query_service.memory_forget_by_file(
            file_name=file_name,
            memory_indexer=self._memory_indexer,
        )

    async def delete_vector_chunks_for_file(self, file_name: str) -> None:
        """Delete vector/index chunks associated with a specific memory file."""
        await self._query_service.delete_vector_chunks_for_file(
            file_name=file_name,
            memory_indexer=self._memory_indexer,
        )

    async def memory_forget_by_chunk_ids(
        self,
        chunk_ids: list[str],
    ) -> str:
        """Delete explicit memory chunks by chunk IDs."""
        return await self._query_service.memory_forget_by_chunk_ids(
            chunk_ids=chunk_ids,
            memory_indexer=self._memory_indexer,
        )
