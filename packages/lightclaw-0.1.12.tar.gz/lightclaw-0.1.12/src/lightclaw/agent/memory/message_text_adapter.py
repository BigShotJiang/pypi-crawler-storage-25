"""Adapters for extracting readable text from message payloads."""

from __future__ import annotations

import json
from typing import Any

from langchain_core.messages import AIMessage, BaseMessage, ToolMessage


def extract_message_text(message: Any) -> str:
    """Extract readable text from generic or LangChain message payloads.

    Thinking/reasoning content blocks are always skipped to avoid polluting
    downstream consumers (compaction, summary, etc.) with model reasoning
    traces.
    """
    if isinstance(message, BaseMessage):
        return extract_langchain_message_text(message)

    content = getattr(message, "content", "")
    if isinstance(content, str):
        return content
    if not isinstance(content, list):
        return str(content)

    parts: list[str] = []
    for block in content:
        if not isinstance(block, dict):
            parts.append(str(block))
            continue

        block_type = block.get("type", "")
        if block_type == "text":
            parts.append(str(block.get("text", "")))
        elif block_type == "tool_use":
            name = block.get("name", "")
            tool_input = block.get("input", {})
            parts.append(f"[tool_use] {name} {json.dumps(tool_input, ensure_ascii=False)}")
        elif block_type == "tool_result":
            output = block.get("output", "")
            if isinstance(output, list | dict):
                output = json.dumps(output, ensure_ascii=False)
            parts.append(f"[tool_result] {output}")
        elif block_type in ("image", "audio", "video", "file"):
            source = block.get("source", {})
            parts.append(f"[{block_type}] {source.get('url', '')}")

    return "\n".join(part for part in parts if part)


def extract_langchain_message_text(message: BaseMessage) -> str:
    """Extract readable text from a LangChain message.

    Thinking/reasoning content is always skipped.
    """
    parts: list[str] = []

    content = getattr(message, "content", "")
    if isinstance(content, str) and content:
        parts.append(content)
    elif isinstance(content, list):
        for block in content:
            if isinstance(block, str):
                parts.append(block)
                continue
            if not isinstance(block, dict):
                parts.append(str(block))
                continue
            block_type = block.get("type", "")
            if block_type == "text":
                parts.append(str(block.get("text", "")))
            elif block_type == "image_url":
                image_url = block.get("image_url", {}).get("url", "")
                parts.append(f"[image] {image_url}")
            else:
                parts.append(str(block))

    additional_kwargs = getattr(message, "additional_kwargs", None) or {}

    if isinstance(message, AIMessage):
        for tool_call in message.tool_calls or []:
            parts.append(
                f"[tool_use] {tool_call.get('name', '')} {json.dumps(tool_call.get('args', {}), ensure_ascii=False)}"
            )
    elif isinstance(message, ToolMessage):
        tool_name = getattr(message, "name", "") or ""
        parts.append(f"[tool_result] {tool_name} {message.content}")

    for key, label in (
        ("file_blocks", "file"),
        ("audio_blocks", "audio"),
        ("video_blocks", "video"),
    ):
        for block in additional_kwargs.get(key, []) or []:
            if not isinstance(block, dict):
                continue
            source = block.get("source", {})
            if isinstance(source, dict):
                parts.append(f"[{label}] {source.get('url', '')}")

    return "\n".join(part for part in parts if part)
