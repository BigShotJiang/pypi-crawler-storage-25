"""
Rule-based importance scoring for memory chunks.

Evaluate how "important" a piece of memory is at index time, producing a
float in [0.0, 1.0].  The score influences search ranking so that core
user preferences always surface above ephemeral, time-bound notes.

Design principles:
  - Rules first, zero LLM calls  (covers ~80% of cases)
  - Deterministic & fast  (< 1 ms per chunk)
  - Graceful defaults  (unknown content -> 0.4, neutral)
"""

from __future__ import annotations

import re

# ── Keyword signal lists ─────────────────────────────────────────────────

# Signals that indicate long-term / identity-level facts.
_HIGH_IMPORTANCE_SIGNALS: tuple[str, ...] = (
    # Chinese — identity & preferences
    "偏好",
    "喜欢",
    "不喜欢",
    "讨厌",
    "习惯",
    "擅长",
    "性格",
    "身份",
    "职业",
    "家乡",
    "母语",
    "过敏",
    "禁忌",
    # Chinese — explicit importance markers
    "记住",
    "重要",
    "必须",
    "一定要",
    "关键",
    "核心",
    "决定",
    "目标",
    "原则",
    # English — identity & preferences
    "preference",
    "favorite",
    "always",
    "never",
    "identity",
    "occupation",
    "allergy",
    "important to me",
    # English — explicit importance markers
    "remember",
    "important",
    "must",
    "key",
    "note",
    "critical",
    "goal",
    "principle",
    "decision",
)

# Signals that indicate ephemeral / time-bound information.
# Note: "今天" / "today" are intentionally excluded — they can appear in
# high-importance statements like "今天我决定换工作" (decided to change jobs today).
_LOW_IMPORTANCE_SIGNALS: tuple[str, ...] = (
    # Chinese
    "明天",
    "待办",
    "会议",
    "提醒",
    "临时",
    "一次性",
    "下周",
    "本周",
    # English
    "tomorrow",
    "meeting",
    "remind",
    "temporary",
    "one-off",
    "todo",
    "next week",
    "this week",
)

# Path pattern for dated daily summaries: memory/YYYY-MM-DD.md
_DATED_MEMORY_PATH_RE = re.compile(r"(?:^|/)memory/\d{4}-\d{2}-\d{2}\.md$")


# ── Public API ───────────────────────────────────────────────────────────


def evaluate_importance(
    text: str,
    path: str,
    source: str = "memory",
) -> float:
    """Evaluate the importance of a memory chunk using rule-based heuristics.

    Args:
        text:   The chunk text content.
        path:   Relative file path (e.g. ``"MEMORY.md"``, ``"memory/2026-03-17.md"``).
        source: Data source tag (``"memory"`` | ``"sessions"``).

    Returns:
        A float in [0.0, 1.0] where higher means more important.
        - 1.0  core identity / user preferences
        - 0.9  MEMORY.md (curated long-term memory)
        - 0.7  agent-created topic files / high-signal daily content
        - 0.4  neutral / unknown
        - 0.2  ephemeral / time-bound information
    """
    normalized = path.replace("\\", "/").lstrip("./")

    # Rule 1: USER.md = user preferences, highest importance
    if normalized.upper() in ("USER.MD",):
        return 1.0

    # Rule 2: MEMORY.md / memory.md = curated long-term memory
    if normalized in ("MEMORY.md", "memory.md"):
        return 0.9

    # Rule 3: Agent-created topic files in workspace root (e.g. TOOLS.md)
    if "/" not in normalized and normalized.endswith(".md"):
        return 0.7

    # Rule 4: Topic files inside memory/ directory (non-dated, agent-created)
    # e.g. memory/TOOLS.md, memory/PROJECTS.md — treated same as root topic files
    if normalized.startswith("memory/") and normalized.endswith(".md") and not _DATED_MEMORY_PATH_RE.search(normalized):
        return 0.7

    # Rule 5: Dated daily summaries — score by content signals
    if _DATED_MEMORY_PATH_RE.search(normalized):
        return _score_by_content_signals(text)

    # Rule 6: Session-derived content
    if source == "sessions":
        return _score_by_content_signals(text)

    # Default: neutral importance
    return 0.4


def _score_by_content_signals(text: str) -> float:
    """Score text content by counting high/low importance keyword signals.

    Returns:
        0.7 if any long-term signal present (and not outweighed by ephemeral),
        0.2 if strong ephemeral signals, 0.4 otherwise (neutral).
    """
    if not text:
        return 0.4

    text_lower = text.lower()
    high_hits = sum(1 for signal in _HIGH_IMPORTANCE_SIGNALS if signal in text_lower)
    low_hits = sum(1 for signal in _LOW_IMPORTANCE_SIGNALS if signal in text_lower)

    # Any long-term signal present and not outweighed by ephemeral signals
    if high_hits >= 1 and high_hits >= low_hits:
        return 0.7

    # Long-term signals present but outnumbered by ephemeral — still lean important
    if high_hits >= 1 and low_hits > high_hits:
        return 0.5

    # Strong ephemeral signal with no long-term signal
    if low_hits >= 2 and high_hits == 0:
        return 0.2

    # Slight ephemeral signal with no long-term signal
    if low_hits >= 1 and high_hits == 0:
        return 0.3

    return 0.4
