"""Utilities for splitting markdown summaries into dedup-safe blocks."""

from __future__ import annotations

import re


def split_summary_into_blocks(text: str) -> list[str]:
    """Split summary text into logical markdown blocks for dedup.

    Strategy:
    - Split on blank lines.
    - Keep a heading and its immediate content in the same block, so dedup
      does not leave orphan headings.
    """
    raw_blocks = re.split(r"\n\n+", text)
    merged: list[str] = []
    for block in raw_blocks:
        stripped = block.strip()
        if merged and merged[-1].strip().startswith("#") and not stripped.startswith("#"):
            merged[-1] = merged[-1] + "\n\n" + block
        else:
            merged.append(block)
    return merged
