"""
Proactive outreach engine (LightClaw differentiator, not present in openclaw).

v2 architecture: Engine-Driven with Callbacks

How it works:
1. _run_loop() fires on a timer (initial sleep + check_interval)
2. evaluate_and_trigger():
   a. fetch_candidates(): Qdrant payload filter (dual-layer cooldown) + dense vector search
   b. Determine mode: "topic" (has candidates) or "caring" (no candidates)
   c. Call on_evaluate(candidates, mode) callback (implemented in proactivity.py)
   d. If dispatched: update_cooldowns() writes back to Qdrant payload

Qdrant payload fields (set by qdrant_indexer.py at write time):
  proactive_enabled: bool                    — whether proactive outreach is enabled
  proactive_time_window: str                 — outreach time window (reserved)
  proactive_priority: int                    — priority (memory=1, sessions=0)
  proactive_last_triggered_at: datetime      — chunk-level cooldown
  proactive_file_last_triggered_at: datetime — file-level cooldown
"""

from __future__ import annotations

import asyncio
import logging
import math
import os
import random
from collections.abc import Callable, Coroutine
from dataclasses import dataclass, field
from datetime import UTC, datetime, timedelta
from typing import TYPE_CHECKING, Any

if TYPE_CHECKING:
    from lightclaw.agent.memory.qdrant_indexer import QdrantMemoryIndexer

logger = logging.getLogger(__name__)

# ── Time window definitions ──────────────────────────────────────────────────
TIME_WINDOW_MORNING = "morning"  # 06:00 - 11:59
TIME_WINDOW_AFTERNOON = "afternoon"  # 12:00 - 17:59
TIME_WINDOW_EVENING = "evening"  # 18:00 - 21:59
TIME_WINDOW_NIGHT = "night"  # 22:00 - 05:59

# Payload field names
PAYLOAD_PROACTIVE_ENABLED = "proactive_enabled"
PAYLOAD_PROACTIVE_TIME_WINDOW = "proactive_time_window"
PAYLOAD_PROACTIVE_LAST_TRIGGERED_AT = "proactive_last_triggered_at"
PAYLOAD_PROACTIVE_FILE_LAST_TRIGGERED_AT = "proactive_file_last_triggered_at"
PAYLOAD_PROACTIVE_PRIORITY = "proactive_priority"
PAYLOAD_PROACTIVE_TRIGGER_COUNT = "proactive_trigger_count"

# Default cooldown durations
DEFAULT_CHUNK_COOLDOWN_HOURS = 2.0
DEFAULT_FILE_COOLDOWN_HOURS = 8.0
DEFAULT_MAX_CANDIDATES = 5

# Lazy backfill: when fetch_candidates encounters chunks lacking event_kind
# in payload (i.e. indexed before the event-time three-state landed), the
# extractor is run inline and the payload is patched fire-and-forget so the
# next call sees the upgraded chunk without the user ever running a script.
LAZY_BACKFILL_WARN_INTERVAL_SECONDS = 300.0

# ── Hybrid scoring constants ─────────────────────────────────────────────────
# Weight allocation for final_score: vector similarity vs recency
HYBRID_WEIGHT_VECTOR = 0.4
HYBRID_WEIGHT_RECENCY = 0.6
# Recency half-life in hours: score halves every N hours
RECENCY_HALF_LIFE_HOURS = 48.0
# Over-fetch multiplier: fetch more from Qdrant, then re-rank with hybrid score
OVER_FETCH_MULTIPLIER = 3
# Trigger count penalty: each previous pick reduces score by this factor
# Formula: penalty = 1 / (1 + trigger_count * TRIGGER_COUNT_PENALTY_FACTOR)
# trigger_count=0 → ×1.0, =1 → ×0.77, =2 → ×0.63, =5 → ×0.42
TRIGGER_COUNT_PENALTY_FACTOR = 0.3

# ── Event-kind aware half-life (PR-3, PROACTIVE_USE_EVENT_KIND) ──────────────
# When PROACTIVE_USE_EVENT_KIND=true, recency is bucketed by event_kind:
#   past_explicit / path_dated / unknown → 14 days, anchored on event_at/created_at
#   ongoing                              → 30 days, anchored on created_at
#   future_explicit                      →  7 days, anchored on |now - event_at|
# Each bucket is overridable via env (PROACTIVE_HALFLIFE_*_DAYS).
DEFAULT_HALFLIFE_PAST_DAYS = 14.0
DEFAULT_HALFLIFE_ONGOING_DAYS = 30.0
DEFAULT_HALFLIFE_FUTURE_DAYS = 7.0

# Future-event scheduling thresholds.
FUTURE_NEAR_BOOST_DAYS = 3  # within N days of event → +0.3 boost
FUTURE_NEAR_BOOST_VALUE = 0.3
FUTURE_RETROSPECT_WINDOW_DAYS = 7  # post-event grace where future is still kept


def _halflife_days(env_key: str, default: float) -> float:
    try:
        return float(os.environ.get(env_key, default))
    except (TypeError, ValueError):
        return default


def _use_event_kind() -> bool:
    # Default-on: rely on extractor + indexer fallback to keep behaviour safe
    # for chunks missing event_at/event_kind (they fall back to the v1 path
    # inside _compute_recency_score_event_aware).
    return os.environ.get("PROACTIVE_USE_EVENT_KIND", "true").lower() == "true"


def get_current_time_window(now: datetime | None = None) -> str:
    """Return the time window name based on current time.

    The decision is always made in the **local** timezone:
    - If ``now`` is None, use the current local time.
    - If ``now`` is timezone-aware (e.g. UTC), convert it to local first.
    - If ``now`` is naive, assume it is already local time.
    """
    if now is None:
        dt = datetime.now().astimezone()
    elif now.tzinfo is not None:
        # Normalize aware datetimes to the local timezone before taking hour.
        dt = now.astimezone()
    else:
        # Naive datetime: treat as local time as-is.
        dt = now
    hour = dt.hour
    if 6 <= hour < 12:
        return TIME_WINDOW_MORNING
    if 12 <= hour < 18:
        return TIME_WINDOW_AFTERNOON
    if 18 <= hour < 22:
        return TIME_WINDOW_EVENING
    return TIME_WINDOW_NIGHT


def get_time_window_greeting(time_window: str, language: str = "zh") -> str:
    """Return a greeting for the given time window."""
    if language == "zh":
        greetings = {
            TIME_WINDOW_MORNING: "早上好",
            TIME_WINDOW_AFTERNOON: "下午好",
            TIME_WINDOW_EVENING: "晚上好",
            TIME_WINDOW_NIGHT: "夜深了",
        }
    else:
        greetings = {
            TIME_WINDOW_MORNING: "Good morning",
            TIME_WINDOW_AFTERNOON: "Good afternoon",
            TIME_WINDOW_EVENING: "Good evening",
            TIME_WINDOW_NIGHT: "It's late",
        }
    return greetings.get(time_window, "")


def _compute_recency_score(created_at_iso: str, now: datetime) -> float:
    """Compute recency score using exponential decay.

    Returns a value in [0, 1] where 1.0 = just created, decaying with half-life.
    If created_at is missing or unparseable, returns a low default (0.1).
    """
    if not created_at_iso:
        return 0.1
    try:
        created_dt = datetime.fromisoformat(created_at_iso.replace("Z", "+00:00"))
        if created_dt.tzinfo is None:
            created_dt = created_dt.replace(tzinfo=UTC)
        age_hours = max((now - created_dt).total_seconds() / 3600.0, 0.0)
        # Exponential decay: score = 2^(-age / half_life)
        return math.pow(2.0, -age_hours / RECENCY_HALF_LIFE_HOURS)
    except (ValueError, TypeError):
        return 0.1


def _parse_iso_date(value: str) -> datetime | None:
    """Parse an ISO date or datetime string into a UTC datetime, or return None."""
    if not value:
        return None
    try:
        dt = datetime.fromisoformat(value.replace("Z", "+00:00"))
    except (ValueError, TypeError):
        return None
    if dt.tzinfo is None:
        dt = dt.replace(tzinfo=UTC)
    return dt.astimezone(UTC)


def _compute_recency_score_event_aware(
    *,
    event_at_iso: str,
    event_kind: str,
    created_at_iso: str,
    now: datetime,
) -> tuple[float, float]:
    """Event-kind aware recency score + future-event boost.

    Returns ``(recency_score, boost)`` where ``recency_score`` is in [0, 1] and
    ``boost`` is added to the final hybrid score (only non-zero for the
    "future near" window). Falls back to the legacy created-at half-life when
    ``event_kind`` / ``event_at`` are missing.
    """
    legacy = _compute_recency_score(created_at_iso, now)

    # Missing event-time fields → behave exactly like the legacy path so we
    # remain safe before backfill completes.
    event_dt = _parse_iso_date(event_at_iso)
    if event_dt is None or not event_kind:
        return legacy, 0.0

    if event_kind == "future_explicit":
        half_life_days = _halflife_days("PROACTIVE_HALFLIFE_FUTURE_DAYS", DEFAULT_HALFLIFE_FUTURE_DAYS)
        days_to_event = (event_dt - now).total_seconds() / 86400.0
        # Past the event by more than the retrospect window → behave like a
        # past_explicit ("role transition"). 14-day half-life on the event date.
        if days_to_event < -FUTURE_RETROSPECT_WINDOW_DAYS:
            half_life_days = _halflife_days("PROACTIVE_HALFLIFE_PAST_DAYS", DEFAULT_HALFLIFE_PAST_DAYS)
        score = math.pow(2.0, -abs(days_to_event) / half_life_days)
        boost = 0.0
        if 0 <= days_to_event <= FUTURE_NEAR_BOOST_DAYS:
            boost = FUTURE_NEAR_BOOST_VALUE
        return score, boost

    if event_kind == "ongoing":
        # Anchor on created_at — "ongoing" semantics fade as the note ages.
        anchor_dt = _parse_iso_date(created_at_iso) or event_dt
        half_life_days = _halflife_days("PROACTIVE_HALFLIFE_ONGOING_DAYS", DEFAULT_HALFLIFE_ONGOING_DAYS)
        age_days = max((now - anchor_dt).total_seconds() / 86400.0, 0.0)
        return math.pow(2.0, -age_days / half_life_days), 0.0

    # past_explicit / path_dated / unknown — anchor on event_at, 14-day half-life.
    half_life_days = _halflife_days("PROACTIVE_HALFLIFE_PAST_DAYS", DEFAULT_HALFLIFE_PAST_DAYS)
    age_days = max((now - event_dt).total_seconds() / 86400.0, 0.0)
    return math.pow(2.0, -age_days / half_life_days), 0.0


# ── Data types ────────────────────────────────────────────────────────────────


@dataclass
class CandidateResult:
    """Structured candidate memory chunk returned by fetch_candidates()."""

    point_id: str
    chunk_id: str
    path: str
    snippet: str
    priority: int = 0
    score: float = 0.0
    final_score: float = 0.0  # hybrid score (vector + recency + priority + trigger penalty)
    created_at: str = ""  # ISO-8601 timestamp for debugging
    trigger_count: int = 0  # how many times this chunk has been picked
    # Event-time three-state (filled when payload carries event_* fields).
    event_at: str = ""
    event_kind: str = "unknown"
    event_confidence: float = 0.0

    @property
    def is_ongoing(self) -> bool:
        return self.event_kind == "ongoing"

    @property
    def is_future(self) -> bool:
        return self.event_kind == "future_explicit"


@dataclass
class ProactiveConfig:
    """Proactive outreach engine configuration."""

    enabled: bool = False
    check_interval_seconds: float = 14400.0
    chunk_cooldown_hours: float = DEFAULT_CHUNK_COOLDOWN_HOURS
    file_cooldown_hours: float = DEFAULT_FILE_COOLDOWN_HOURS
    max_candidates: int = DEFAULT_MAX_CANDIDATES
    language: str = "zh"
    # Lazy backfill of event_at/event_kind/event_confidence on candidates
    # whose payload was indexed before the three-state landed. Default-on;
    # flip to False if the inline extractor or set_payload writes misbehave
    # in production — falling back to scripts/backfill_event_at.py.
    lazy_backfill_event_time_enabled: bool = True
    # v2 callback: on_evaluate(candidates, mode) -> bool (dispatched?)
    on_evaluate: Callable[[list[CandidateResult], str], Coroutine[Any, Any, bool]] | None = None
    # v1 legacy callback: on_trigger(message) -> None (standalone mode)
    on_trigger: Callable[[str], Coroutine[Any, Any, None]] | None = None

    # Backward compatibility: cooldown_hours maps to file_cooldown_hours
    @property
    def cooldown_hours(self) -> float:
        return self.file_cooldown_hours

    @cooldown_hours.setter
    def cooldown_hours(self, value: float) -> None:
        self.file_cooldown_hours = value


@dataclass
class ProactiveTriggerResult:
    """Proactive outreach result."""

    triggered: bool
    mode: str = ""  # "topic" | "caring"
    candidates: list[CandidateResult] = field(default_factory=list)
    time_window: str = ""


def create_proactive_config_from_env(
    on_trigger: Callable[[str], Coroutine[Any, Any, None]] | None = None,
    on_evaluate: Callable[[list[CandidateResult], str], Coroutine[Any, Any, bool]] | None = None,
) -> ProactiveConfig:
    """Create ProactiveConfig from environment variables."""
    return ProactiveConfig(
        enabled=os.environ.get("PROACTIVE_MEMORY_ENABLED", "false").lower() == "true",
        check_interval_seconds=float(os.environ.get("PROACTIVE_CHECK_INTERVAL_SECONDS", "14400")),
        chunk_cooldown_hours=float(os.environ.get("PROACTIVE_CHUNK_COOLDOWN_HOURS", str(DEFAULT_CHUNK_COOLDOWN_HOURS))),
        file_cooldown_hours=float(os.environ.get("PROACTIVE_FILE_COOLDOWN_HOURS", str(DEFAULT_FILE_COOLDOWN_HOURS))),
        max_candidates=int(os.environ.get("PROACTIVE_MAX_CANDIDATES", str(DEFAULT_MAX_CANDIDATES))),
        language=os.environ.get("PROACTIVE_LANGUAGE", "zh"),
        lazy_backfill_event_time_enabled=(
            os.environ.get("PROACTIVE_LAZY_BACKFILL_EVENT_TIME", "true").lower() == "true"
        ),
        on_trigger=on_trigger,
        on_evaluate=on_evaluate,
    )


# ── Engine ────────────────────────────────────────────────────────────────────


class ProactiveMemoryEngine:
    """
    Proactive outreach engine.

    v2 architecture: fetch_candidates() → on_evaluate callback → update_cooldowns()

    Qdrant payload filter dual-layer cooldown:
      - chunk-level: proactive_last_triggered_at (default 2h)
      - file-level: proactive_file_last_triggered_at (default 8h)
    """

    def __init__(
        self,
        indexer: QdrantMemoryIndexer,
        embedding_fn: Callable[[list[str]], Coroutine[Any, Any, list[list[float]]]] | None,
        config: ProactiveConfig,
    ) -> None:
        self.indexer = indexer
        self.embedding_fn = embedding_fn
        self.config = config
        self._task: asyncio.Task | None = None
        self._closed = False
        self._eval_lock = asyncio.Lock()
        # Throttle for lazy-backfill write-failure warnings (epoch seconds).
        self._last_lazy_backfill_warn_at: float = 0.0
        # In-memory chunk-level cooldown for FTS-only mode (no Qdrant payload writes).
        # Maps chunk_id -> last_triggered_at datetime.
        self._fts_cooldown: dict[str, datetime] = {}

    # ── Lifecycle ──────────────────────────────────────────────────────────────

    def start(self) -> None:
        """Start the periodic check task."""
        if not self.config.enabled:
            logger.info("ProactiveMemoryEngine: disabled")
            return
        if self._task is not None and not self._task.done():
            logger.debug("ProactiveMemoryEngine: already running")
            return
        self._closed = False
        self._task = asyncio.create_task(self._run_loop())
        logger.info(
            "ProactiveMemoryEngine: started (interval=%.0fs, chunk_cd=%.1fh, file_cd=%.1fh)",
            self.config.check_interval_seconds,
            self.config.chunk_cooldown_hours,
            self.config.file_cooldown_hours,
        )

    def stop(self) -> None:
        """Stop the periodic check task."""
        self._closed = True
        if self._task is not None and not self._task.done():
            self._task.cancel()
            self._task = None
        logger.info("ProactiveMemoryEngine: stopped")

    # ── Core logic ─────────────────────────────────────────────────────────────

    async def evaluate_and_trigger(
        self,
        now: datetime | None = None,
    ) -> ProactiveTriggerResult:
        """
        Evaluate and trigger proactive message.

        Flow: fetch_candidates → determine mode → call on_evaluate → update_cooldowns
        """
        # Prevent concurrent invocations (P1 dual-scheduling guard)
        if self._eval_lock.locked():
            logger.debug("ProactiveMemoryEngine: evaluate_and_trigger already running, skip")
            return ProactiveTriggerResult(triggered=False)
        async with self._eval_lock:
            return await self._evaluate_and_trigger_inner(now)

    async def _evaluate_and_trigger_inner(
        self,
        now: datetime | None = None,
    ) -> ProactiveTriggerResult:
        """Inner implementation of evaluate_and_trigger (holds _eval_lock)."""
        now_dt = now or datetime.now(UTC)
        time_window = get_current_time_window(now_dt)

        # Step 1: fetch candidates with Qdrant payload filter + vector search
        candidates = await self.fetch_candidates(
            chunk_cooldown_hours=self.config.chunk_cooldown_hours,
            file_cooldown_hours=self.config.file_cooldown_hours,
            max_results=self.config.max_candidates,
        )

        # Step 2: determine mode
        mode = "topic" if candidates else "caring"

        # Step 3: call callback
        dispatched = False
        if self.config.on_evaluate is not None:
            # v2 path: structured candidates + mode
            try:
                dispatched = await self.config.on_evaluate(candidates, mode)
            except Exception as exc:
                logger.warning("ProactiveMemoryEngine: on_evaluate failed: %s", exc)
                return ProactiveTriggerResult(
                    triggered=False, mode=mode, candidates=candidates, time_window=time_window
                )
        elif self.config.on_trigger is not None:
            # v1 legacy path: build message string for standalone mode
            if candidates:
                message = self._build_proactive_message(candidates[0], time_window)
                try:
                    await self.config.on_trigger(message)
                    dispatched = True
                except Exception as exc:
                    logger.warning("ProactiveMemoryEngine: on_trigger failed: %s", exc)
            else:
                # Caring mode for legacy callback
                try:
                    await self.config.on_trigger("")
                except Exception as exc:
                    logger.warning("ProactiveMemoryEngine: on_trigger (caring) failed: %s", exc)

        # Step 4: update cooldowns on dispatch success
        if dispatched and candidates:
            await self.update_cooldowns(candidates)

        logger.info(
            "ProactiveMemoryEngine: mode=%s, candidates=%d, dispatched=%s",
            mode,
            len(candidates),
            dispatched,
        )

        return ProactiveTriggerResult(
            triggered=dispatched,
            mode=mode,
            candidates=candidates,
            time_window=time_window,
        )

    async def fetch_candidates(
        self,
        chunk_cooldown_hours: float | None = None,
        file_cooldown_hours: float | None = None,
        max_results: int | None = None,
    ) -> list[CandidateResult]:
        """
        Fetch candidate memory chunks from Qdrant using vector search.

        When embedding_fn is available:
          Phase 1: payload filter (proactive_enabled + dual-layer cooldown)
          Phase 2: dense vector search (time-context ranking)

        When embedding_fn is None:
          Return empty list. LLM will call memory_search tool to find topics.

        Returns CandidateResult list sorted by final_score descending.
        """
        chunk_cd = chunk_cooldown_hours or self.config.chunk_cooldown_hours
        file_cd = file_cooldown_hours or self.config.file_cooldown_hours
        limit = max_results or self.config.max_candidates

        # When no embedding_fn, fall back to FTS-only candidate search.
        if self.embedding_fn is None:
            logger.info("ProactiveMemoryEngine.fetch_candidates: embedding_fn=None, using FTS fallback")
            return self._fetch_candidates_fts(
                chunk_cooldown_hours=chunk_cd,
                max_results=limit,
            )

        logger.info("ProactiveMemoryEngine.fetch_candidates: embedding_fn=available, using vector search")

        # Randomized query to increase candidate diversity across invocations
        if self.config.language == "zh":
            queries = [
                "有什么值得关注或聊的事情，最近发生了什么有趣的",
                "最近有什么重要的事情需要跟进或提醒",
                "有没有什么开心的事或者好消息可以分享",
                "最近的生活、工作、学习有什么新进展",
                "有什么计划或者安排需要关心一下",
            ]
        else:
            queries = [
                "what's worth noting or chatting about, anything interesting recently",
                "any important things to follow up on or remind about",
                "any good news or happy things to share",
                "any new progress in life, work, or study recently",
                "any plans or schedules that need attention",
            ]
        query = random.choice(queries)
        logger.debug("ProactiveMemoryEngine: selected query: %s", query[:40])

        # Vector search with embedding_fn
        try:
            embeddings = await self.embedding_fn([query])
            query_vec = embeddings[0] if embeddings else []
        except Exception as exc:
            logger.warning("ProactiveMemoryEngine: embedding failed: %s", exc)
            return []

        if not query_vec:
            return []

        # Build Qdrant payload filter: enabled + dual-layer cooldown
        now = datetime.now(UTC)
        chunk_cutoff = (now - timedelta(hours=chunk_cd)).isoformat()
        file_cutoff = (now - timedelta(hours=file_cd)).isoformat()

        try:
            from qdrant_client.models import (
                DatetimeRange,
                FieldCondition,
                Filter,
                MatchValue,
            )

            # Dual-layer cooldown filter conditions:
            # chunk_level: last_triggered_at IS NULL OR < chunk_cutoff
            # file_level: file_last_triggered_at IS NULL OR < file_cutoff
            #
            # Qdrant Filter doesn't support OR, so use must_not inversion:
            # must_not: [triggered_at >= cutoff] is equivalent to triggered_at < cutoff OR NULL
            chunk_cooldown_filter = FieldCondition(
                key=PAYLOAD_PROACTIVE_LAST_TRIGGERED_AT,
                range=DatetimeRange(gte=chunk_cutoff),
            )
            file_cooldown_filter = FieldCondition(
                key=PAYLOAD_PROACTIVE_FILE_LAST_TRIGGERED_AT,
                range=DatetimeRange(gte=file_cutoff),
            )

            query_filter = Filter(
                must_not=[
                    # Exclude explicitly disabled chunks (proactive_enabled=False)
                    # Old chunks without this field are not excluded
                    FieldCondition(
                        key=PAYLOAD_PROACTIVE_ENABLED,
                        match=MatchValue(value=False),
                    ),
                    chunk_cooldown_filter,
                    file_cooldown_filter,
                ],
            )

            # Over-fetch from Qdrant to allow hybrid re-ranking
            fetch_limit = limit * OVER_FETCH_MULTIPLIER

            response = await self.indexer.client.query_points(
                collection_name=self.indexer.collection_name,
                query=query_vec,
                query_filter=query_filter,
                limit=fetch_limit,
                with_payload=True,
                score_threshold=0.2,
            )

            logger.info(
                "ProactiveMemoryEngine: vector search returned %d points",
                len(response.points) if response.points else 0,
            )

            if not response.points:
                return []

            # Build CandidateResult list with hybrid scoring
            candidates: list[CandidateResult] = []
            use_event_kind = _use_event_kind()
            # Collect chunks needing lazy backfill so we can issue a single
            # batched set_payload after the loop (one call per distinct
            # (event_at, event_kind, confidence) triple).
            backfill_pending: list[tuple[str, str, str, float]] = []
            do_lazy_backfill = self.config.lazy_backfill_event_time_enabled
            for hit in response.points:
                payload = hit.payload or {}
                priority = int(payload.get("proactive_priority", 0))
                vector_score = float(hit.score)
                created_at_str = payload.get("created_at", "")
                trigger_count = int(payload.get("proactive_trigger_count", 0))
                event_at_str = payload.get("event_at", "") or ""
                event_kind_str = payload.get("event_kind", "") or ""
                event_confidence = float(payload.get("event_confidence", 0.0) or 0.0)

                # Lazy backfill: chunks indexed before the event-time three-state
                # have no "event_kind" key in payload at all. Distinguish that
                # from a backfilled-as-unknown chunk (which DOES have the key)
                # by checking key presence rather than truthiness.
                if do_lazy_backfill and "event_kind" not in payload:
                    extracted = self._lazy_extract_event_time(
                        snippet=payload.get("snippet", ""),
                        rel_path=payload.get("path", ""),
                        created_at_iso=created_at_str,
                    )
                    if extracted is not None:
                        event_at_str, event_kind_str, event_confidence = extracted
                        backfill_pending.append((str(hit.id), event_at_str, event_kind_str, event_confidence))

                # Compute recency score: legacy or event-kind aware (PR-3 gate).
                if use_event_kind:
                    recency_score, future_boost = _compute_recency_score_event_aware(
                        event_at_iso=event_at_str,
                        event_kind=event_kind_str,
                        created_at_iso=created_at_str,
                        now=now,
                    )
                else:
                    recency_score = _compute_recency_score(created_at_str, now)
                    future_boost = 0.0

                # Compute trigger penalty: diminishing returns for repeatedly picked chunks
                # penalty = 1 / (1 + count * factor)
                trigger_penalty = 1.0 / (1.0 + trigger_count * TRIGGER_COUNT_PENALTY_FACTOR)

                # Hybrid score: weighted combination of vector similarity and recency
                # Then apply priority boost: memory(1) gets 1.3x, sessions(0) gets 1.0x
                # Then apply trigger penalty to discourage repeated picks
                hybrid_base = HYBRID_WEIGHT_VECTOR * vector_score + HYBRID_WEIGHT_RECENCY * recency_score
                final_score = hybrid_base * (1.0 + priority * 0.3) * trigger_penalty + future_boost

                candidates.append(
                    CandidateResult(
                        point_id=str(hit.id),
                        chunk_id=payload.get("chunk_id", str(hit.id)),
                        path=payload.get("path", ""),
                        snippet=payload.get("snippet", ""),
                        priority=priority,
                        score=vector_score,
                        final_score=final_score,
                        created_at=created_at_str,
                        trigger_count=trigger_count,
                        event_at=event_at_str,
                        event_kind=event_kind_str or "unknown",
                        event_confidence=event_confidence,
                    )
                )

            # Schedule a fire-and-forget write-back for any chunks we just
            # backfilled in memory. We never await this — the current call
            # already has the upgraded values in its CandidateResult list.
            if backfill_pending:
                self._schedule_lazy_backfill_writeback(backfill_pending)

            # Sort by final_score descending, return top-N
            candidates.sort(key=lambda c: c.final_score, reverse=True)
            candidates = candidates[:limit]

            if candidates:
                logger.info(
                    "ProactiveMemoryEngine: top candidate final_score=%.3f "
                    "(vector=%.3f, recency from %s, priority=%d, trigger_count=%d)",
                    candidates[0].final_score,
                    candidates[0].score,
                    candidates[0].created_at[:10] if candidates[0].created_at else "unknown",
                    candidates[0].priority,
                    candidates[0].trigger_count,
                )
            return candidates

        except Exception as exc:
            logger.warning("ProactiveMemoryEngine: fetch_candidates failed: %s", exc)
            return []

    # ── FTS-only candidate search (no embedding fallback) ─────────────────────

    def _fetch_candidates_fts(
        self,
        chunk_cooldown_hours: float,
        max_results: int,
    ) -> list[CandidateResult]:
        """FTS-only fallback for fetch_candidates when embedding_fn is None.

        Runs a BM25 keyword search against the SQLite FTS5 index using the
        same randomised queries as the vector path.  Applies an in-memory
        chunk-level cooldown (self._fts_cooldown) so the same chunk is not
        surfaced repeatedly.  File-level deduplication is approximated by
        keeping only the first (highest-scoring) chunk per path per cycle.

        Returns a CandidateResult list sorted by BM25 score descending.
        """
        from lightclaw.agent.memory.qdrant_searcher import bm25_rank_to_score, expand_query_for_fts

        now = datetime.now(UTC)
        chunk_cutoff = now - timedelta(hours=chunk_cooldown_hours)

        if self.config.language == "zh":
            queries = [
                "有什么值得关注或聊的事情，最近发生了什么有趣的",
                "最近有什么重要的事情需要跟进或提醒",
                "有没有什么开心的事或者好消息可以分享",
                "最近的生活、工作、学习有什么新进展",
                "有什么计划或者安排需要关心一下",
            ]
        else:
            queries = [
                "what's worth noting or chatting about, anything interesting recently",
                "any important things to follow up on or remind about",
                "any good news or happy things to share",
                "any new progress in life, work, or study recently",
                "any plans or schedules that need attention",
            ]
        query = random.choice(queries)
        logger.debug("ProactiveMemoryEngine (FTS): selected query: %s", query[:40])

        fts_query = expand_query_for_fts(query)
        if not fts_query:
            logger.info("ProactiveMemoryEngine (FTS): expand_query_for_fts returned empty, no candidates")
            return []

        try:
            rows = self.indexer.fts_db.execute(
                "SELECT id, path, source, start_line, end_line, text, bm25(chunks_fts) AS rank "
                "FROM chunks_fts WHERE chunks_fts MATCH ? ORDER BY rank ASC LIMIT ?",
                (fts_query, max_results * 3),
            ).fetchall()
        except Exception as exc:
            logger.warning("ProactiveMemoryEngine (FTS): search failed: %s", exc)
            return []

        candidates: list[CandidateResult] = []
        seen_paths: set[str] = set()

        for chunk_id, path, _source, _start_line, _end_line, text, rank in rows:
            # Skip chunks still within the in-memory cooldown window.
            last_triggered = self._fts_cooldown.get(chunk_id)
            if last_triggered is not None and last_triggered > chunk_cutoff:
                continue
            # One chunk per file path per cycle (approximate file-level cooldown).
            if path in seen_paths:
                continue
            seen_paths.add(path)

            score = bm25_rank_to_score(rank)
            candidates.append(
                CandidateResult(
                    point_id=chunk_id,
                    chunk_id=chunk_id,
                    path=path,
                    snippet=text[:700],
                    score=score,
                    final_score=score,
                )
            )
            if len(candidates) >= max_results:
                break

        logger.info(
            "ProactiveMemoryEngine (FTS): returned %d candidates",
            len(candidates),
        )
        return candidates

    # ── Lazy backfill helpers ──────────────────────────────────────────────────

    @staticmethod
    def _lazy_extract_event_time(
        *,
        snippet: str,
        rel_path: str,
        created_at_iso: str,
    ) -> tuple[str, str, float] | None:
        """Run the three-state extractor inline; never raise.

        Returns ``(event_at, event_kind, confidence)`` on success, or ``None``
        if the extractor failed. Pure-function, sub-millisecond cost.
        """
        try:
            from lightclaw.agent.memory.event_time_extractor import extract_event_time

            ev = extract_event_time(
                snippet=snippet or "",
                rel_path=rel_path or "",
                created_at_iso=created_at_iso or "",
            )
        except Exception as exc:
            logger.debug("lazy backfill: extractor failed: %s", exc)
            return None
        return ev.event_at, ev.event_kind, float(ev.confidence)

    def _schedule_lazy_backfill_writeback(
        self,
        pending: list[tuple[str, str, str, float]],
    ) -> None:
        """Fire-and-forget batched ``set_payload`` for newly-extracted chunks.

        ``pending`` is ``[(point_id, event_at, event_kind, confidence), ...]``.
        Writes are grouped by identical payload triple to minimise round-trips,
        mirroring scripts/backfill_event_at.py.
        """
        if not pending:
            return
        try:
            asyncio.create_task(self._lazy_backfill_writeback(pending))
        except RuntimeError as exc:
            # No running loop — extremely unlikely in this code path; just log.
            logger.debug("lazy backfill: cannot schedule write-back: %s", exc)

    async def _lazy_backfill_writeback(
        self,
        pending: list[tuple[str, str, str, float]],
    ) -> None:
        """Batched ``set_payload`` write-back, throttled on failure."""
        try:
            from qdrant_client.models import PointIdsList

            from lightclaw.agent.memory.qdrant_schema import (
                PAYLOAD_EVENT_AT,
                PAYLOAD_EVENT_CONFIDENCE,
                PAYLOAD_EVENT_KIND,
            )
        except Exception as exc:
            logger.debug("lazy backfill: import failed: %s", exc)
            return

        # Group by (event_at, event_kind, confidence) so identical updates
        # collapse into a single call.
        grouped: dict[tuple[str, str, float], list[str]] = {}
        for point_id, event_at, event_kind, conf in pending:
            grouped.setdefault((event_at, event_kind, conf), []).append(point_id)

        try:
            for (event_at, event_kind, conf), ids in grouped.items():
                await self.indexer.client.set_payload(
                    collection_name=self.indexer.collection_name,
                    payload={
                        PAYLOAD_EVENT_AT: event_at,
                        PAYLOAD_EVENT_KIND: event_kind,
                        PAYLOAD_EVENT_CONFIDENCE: conf,
                    },
                    points=PointIdsList(points=ids),
                )
            logger.info(
                "lazy backfill: patched %d chunks across %d distinct event triples",
                sum(len(v) for v in grouped.values()),
                len(grouped),
            )
        except Exception as exc:
            now_ts = datetime.now(UTC).timestamp()
            if now_ts - self._last_lazy_backfill_warn_at >= LAZY_BACKFILL_WARN_INTERVAL_SECONDS:
                self._last_lazy_backfill_warn_at = now_ts
                logger.warning(
                    "lazy backfill: set_payload failed (further failures suppressed for %.0fs): %s",
                    LAZY_BACKFILL_WARN_INTERVAL_SECONDS,
                    exc,
                )
            else:
                logger.debug("lazy backfill: set_payload failed (suppressed): %s", exc)

    async def update_cooldowns(self, candidates: list[CandidateResult]) -> None:
        """
        Batch update cooldown fields after a successful dispatch.

        For all candidate chunks and their same-file sibling chunks, update:
        - proactive_last_triggered_at (chunk-level, all candidate chunks)
        - proactive_file_last_triggered_at (file-level, all chunks with same path)

        When embedding_fn is None (FTS-only mode), writes are stored in the
        in-memory _fts_cooldown dict instead of Qdrant payload.

        This is a coarse-grained strategy — avoids tracking which candidate the agent actually referenced.
        """
        if not candidates:
            return

        # FTS-only mode: persist cooldowns in memory instead of Qdrant.
        if self.embedding_fn is None:
            now_dt = datetime.now(UTC)
            for c in candidates:
                self._fts_cooldown[c.chunk_id] = now_dt
            logger.debug("update_cooldowns (FTS): updated %d in-memory cooldowns", len(candidates))
            return

        now_iso = datetime.now(UTC).isoformat()

        # 1. Update chunk-level cooldown for all candidate chunks
        point_ids = [c.point_id for c in candidates]
        try:
            from qdrant_client.models import PointIdsList

            await self.indexer.client.set_payload(
                collection_name=self.indexer.collection_name,
                payload={PAYLOAD_PROACTIVE_LAST_TRIGGERED_AT: now_iso},
                points=PointIdsList(points=point_ids),
            )
            logger.debug("update_cooldowns: chunk-level updated %d points", len(point_ids))
        except Exception as exc:
            logger.warning("update_cooldowns: chunk-level update failed: %s", exc)

        # 2. Increment proactive_trigger_count for all candidate chunks
        for candidate in candidates:
            try:
                from qdrant_client.models import PointIdsList as PtIds

                current_count = candidate.trigger_count
                await self.indexer.client.set_payload(
                    collection_name=self.indexer.collection_name,
                    payload={PAYLOAD_PROACTIVE_TRIGGER_COUNT: current_count + 1},
                    points=PtIds(points=[candidate.point_id]),
                )
            except Exception as exc:
                logger.warning(
                    "update_cooldowns: trigger_count increment failed for %s: %s",
                    candidate.point_id,
                    exc,
                )

        # 2. Update file-level cooldown for all candidate file paths (including sibling chunks)
        unique_paths = list({c.path for c in candidates if c.path})
        for path in unique_paths:
            try:
                from qdrant_client.models import FieldCondition, Filter, MatchValue

                await self.indexer.client.set_payload(
                    collection_name=self.indexer.collection_name,
                    payload={PAYLOAD_PROACTIVE_FILE_LAST_TRIGGERED_AT: now_iso},
                    points=Filter(must=[FieldCondition(key="path", match=MatchValue(value=path))]),
                )
                logger.debug("update_cooldowns: file-level updated path=%s", path)
            except Exception as exc:
                logger.warning("update_cooldowns: file-level update failed for %s: %s", path, exc)

    def _build_proactive_message(
        self,
        candidate: CandidateResult,
        time_window: str,
    ) -> str:
        """Build proactive message text from candidate memory (v1 legacy callback)."""
        greeting = get_time_window_greeting(time_window, self.config.language)
        snippet = candidate.snippet.strip()

        if not snippet:
            return greeting

        if self.config.language == "zh":
            return f"{greeting}！我想起了一件事：\n\n{snippet}"
        return f"{greeting}! I just remembered something:\n\n{snippet}"

    # ── Periodic loop ──────────────────────────────────────────────────────────

    async def _run_loop(self) -> None:
        """
        Periodic check loop.

        Sleeps one full interval before the first check
        to avoid triggering immediately on startup.
        """
        logger.info(
            "ProactiveMemoryEngine: loop started (interval=%.0fs)",
            self.config.check_interval_seconds,
        )
        # Initial wait
        try:
            await asyncio.sleep(self.config.check_interval_seconds)
        except asyncio.CancelledError:
            raise

        while not self._closed:
            try:
                result = await self.evaluate_and_trigger()
                if result.triggered:
                    logger.info(
                        "ProactiveMemoryEngine: triggered mode=%s window=%s",
                        result.mode,
                        result.time_window,
                    )
            except asyncio.CancelledError:
                raise
            except Exception as exc:
                logger.warning("ProactiveMemoryEngine: loop error: %s", exc)

            try:
                await asyncio.sleep(self.config.check_interval_seconds)
            except asyncio.CancelledError:
                raise

        logger.info("ProactiveMemoryEngine: loop stopped")


# ── Factory function ──────────────────────────────────────────────────────────


def create_proactive_engine(
    indexer: QdrantMemoryIndexer,
    embedding_fn: Callable[[list[str]], Coroutine[Any, Any, list[list[float]]]] | None = None,
    on_trigger: Callable[[str], Coroutine[Any, Any, None]] | None = None,
    on_evaluate: Callable[[list[CandidateResult], str], Coroutine[Any, Any, bool]] | None = None,
) -> ProactiveMemoryEngine:
    """
    Factory function: create ProactiveMemoryEngine from environment variables.

    Args:
        indexer       — QdrantMemoryIndexer instance
        embedding_fn  — Async embedding function
        on_trigger    — v1 trigger callback (receives message text)
        on_evaluate   — v2 trigger callback (receives candidate list + mode, returns whether dispatched)
    """
    config = create_proactive_config_from_env(on_trigger=on_trigger, on_evaluate=on_evaluate)
    return ProactiveMemoryEngine(
        indexer=indexer,
        embedding_fn=embedding_fn,
        config=config,
    )
