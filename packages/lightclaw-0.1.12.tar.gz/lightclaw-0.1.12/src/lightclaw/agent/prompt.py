"""System prompt building utilities.

This module provides utilities for building system prompts from
markdown configuration files in the working directory.
"""

import logging
import os
import re
import zlib
from collections import OrderedDict
from pathlib import Path
from typing import ClassVar

from lightclaw.agent.prompt_catalog import (
    get_bootstrap_guidance,
    get_default_sys_prompt,
)

logger = logging.getLogger(__name__)

# Default fallback prompt (centralized in prompt_catalog)
DEFAULT_SYS_PROMPT = get_default_sys_prompt()

# Backward compatibility alias
SYS_PROMPT = DEFAULT_SYS_PROMPT


# Regex pattern that matches inline template placeholders of the form:
#   *(any text)*   or   *（any text）*
# These indicate a file is still an unfilled template and should be skipped.
# This is more robust than a fixed string list — it survives template reformatting.
_TEMPLATE_PLACEHOLDER_RE = re.compile(r"\*[（(][^）)]+[）)]\*")
# Cache: working_dir_resolved → (file_signature, prompt_text).
# Protected by the GIL — single dict reads/writes are atomic in CPython,
# so no explicit lock is needed for this simple check-then-set pattern.
# This avoids blocking the async event loop with a threading.Lock.
# Bounded to avoid unbounded growth in multi-workspace deployments.
_PROMPT_CACHE_MAX_SIZE = int(os.environ.get("LIGHTCLAW_PROMPT_CACHE_MAX_SIZE", "16"))
_PROMPT_CACHE: OrderedDict[str, tuple[tuple[tuple[str, bool, int, int], ...], str]] = OrderedDict()


class PromptConfig:
    """Configuration for system prompt building."""

    # Define file loading order: (filename, required)
    # Order reflects priority: constitution → memory/behavior rules → tool rules → identity
    FILE_ORDER: ClassVar[list[tuple[str, bool]]] = [
        ("SOUL.md", True),
        ("AGENTS.md", True),
        ("TOOLS.md", False),
        ("USER.md", False),
        ("IDENTITY.md", False),
    ]


class PromptBuilder:
    """Builder for constructing system prompts from markdown files."""

    def __init__(self, working_dir: Path):
        """Initialize prompt builder.

        Args:
            working_dir: Directory containing markdown configuration files
        """
        self.working_dir = working_dir
        self.prompt_parts = []
        self.loaded_count = 0

    def _load_file(self, filename: str, required: bool) -> bool:
        """Load a single markdown file.

        Args:
            filename: Name of the file to load
            required: Whether the file is required

        Returns:
            True if file was loaded successfully, False otherwise
        """
        file_path = self.working_dir / filename

        if not file_path.exists():
            if required:
                logger.warning(
                    "%s not found in working directory (%s), using default prompt",
                    filename,
                    self.working_dir,
                )
                return False
            else:
                logger.debug("Optional file %s not found, skipping", filename)
                return True  # Not an error for optional files

        try:
            content = file_path.read_text(encoding="utf-8").strip()

            # Remove YAML frontmatter if present
            if content.startswith("---"):
                parts = content.split("---", 2)
                if len(parts) >= 3:
                    content = parts[2].strip()

            if content:
                # Skip unfilled template files to avoid injecting placeholder noise.
                # A file is considered an unfilled template if it still contains
                # inline placeholders of the form *(...)* or *（...）*.
                if _TEMPLATE_PLACEHOLDER_RE.search(content):
                    logger.debug("Skipped unfilled template: %s", filename)
                    return True

                if self.prompt_parts:  # Add separator if not first section
                    self.prompt_parts.append("")
                # Add section header with filename
                self.prompt_parts.append(f"# {filename}")
                self.prompt_parts.append("")
                self.prompt_parts.append(content)
                self.loaded_count += 1
                logger.debug("Loaded %s", filename)
            else:
                logger.debug("Skipped empty file: %s", filename)

            return True

        except Exception as e:
            if required:
                logger.error(
                    "Failed to read required file %s: %s",
                    filename,
                    e,
                    exc_info=True,
                )
                return False
            else:
                logger.warning(
                    "Failed to read optional file %s: %s",
                    filename,
                    e,
                )
                return True  # Not fatal for optional files

    def build(self) -> str:
        """Build the system prompt from markdown files.

        Returns:
            Constructed system prompt string
        """
        for filename, required in PromptConfig.FILE_ORDER:
            if not self._load_file(filename, required):
                # Required file failed to load
                return DEFAULT_SYS_PROMPT

        if not self.prompt_parts:
            logger.warning("No content loaded from working directory")
            return DEFAULT_SYS_PROMPT

        # Join all parts with double newlines
        final_prompt = "\n\n".join(self.prompt_parts)

        logger.debug(
            "System prompt built from %d file(s), total length: %d chars",
            self.loaded_count,
            len(final_prompt),
        )

        return final_prompt


def build_system_prompt_from_working_dir() -> str:
    """
    Build system prompt by reading markdown files from working directory.

    This function constructs the system prompt by loading markdown files from
    WORKING_DIR (~/.lightclaw/workspace by default). These files define the agent's behavior,
    personality, and operational guidelines.

    Loading order and priority:
    1. SOUL.md (required) - Constitution: core values and behavioral principles
    2. AGENTS.md (required) - Memory system + behavior rules
    3. TOOLS.md (optional) - Tool usage rules and configuration
    4. USER.md (optional) - User profile (skipped if still an unfilled template)
    5. IDENTITY.md (optional) - Agent identity (skipped if still an unfilled template)

    Returns:
        str: Constructed system prompt from markdown files.
             If required files don't exist, returns the default prompt.

    Example:
        If working_dir contains AGENTS.md, SOUL.md, USER.md and IDENTITY.md,
        they will be combined:
        "# AGENTS.md\\n\\n...\\n\\n# SOUL.md\\n\\n...\\n\\n# USER.md\\n\\n...\\n\\n# IDENTITY.md\\n\\n..."
    """
    from lightclaw.constant import WORKING_DIR

    working_dir = Path(WORKING_DIR)
    signature = _build_prompt_file_signature(working_dir)
    cache_key = str(working_dir.resolve())

    cached = _PROMPT_CACHE.get(cache_key)
    if cached is not None and cached[0] == signature:
        _PROMPT_CACHE.move_to_end(cache_key)
        logger.debug("System prompt cache hit: working_dir=%s", working_dir)
        return cached[1]

    builder = PromptBuilder(working_dir=working_dir)
    prompt = builder.build()
    _PROMPT_CACHE[cache_key] = (signature, prompt)
    if len(_PROMPT_CACHE) > _PROMPT_CACHE_MAX_SIZE:
        _PROMPT_CACHE.popitem(last=False)
    logger.debug("System prompt cache miss: working_dir=%s", working_dir)
    return prompt


def _build_prompt_file_signature(working_dir: Path) -> tuple[tuple[str, bool, int, int], ...]:
    """Return a signature tuple for ordered prompt source files.

    Uses mtime_ns + size + content checksum so that same-size same-mtime writes
    (e.g. in fast tests or high-frequency flushes) still invalidate the cache.
    """
    signature: list[tuple[str, bool, int, int]] = []
    for filename, _required in PromptConfig.FILE_ORDER:
        path = working_dir / filename
        try:
            stat = path.stat()
            content = path.read_bytes()
            checksum = zlib.adler32(content)
        except FileNotFoundError:
            signature.append((filename, False, 0, 0))
            continue
        signature.append((filename, True, int(stat.st_mtime_ns), checksum))
    return tuple(signature)


def build_bootstrap_guidance(
    language: str = "zh",
) -> str:
    """Build bootstrap guidance message for first-time setup.

    Args:
        language: Language code (en/zh)

    Returns:
        Formatted bootstrap guidance message
    """
    return get_bootstrap_guidance(language)


__all__ = [
    "DEFAULT_SYS_PROMPT",
    "SYS_PROMPT",  # Backward compatibility
    "PromptBuilder",
    "PromptConfig",
    "build_bootstrap_guidance",
    "build_system_prompt_from_working_dir",
]
