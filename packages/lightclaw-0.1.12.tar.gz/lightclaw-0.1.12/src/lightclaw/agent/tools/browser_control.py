"""Browser automation tool using Playwright.

Single tool with action-based API matching browser MCP: start, stop, open,
navigate, navigate_back, screenshot, snapshot, click, type, eval, evaluate,
resize, console_messages, handle_dialog, file_upload, upload_image, fill_form,
install, press_key, network_requests, run_code, drag, hover, select_option,
tabs, wait_for, pdf, close. Uses refs from snapshot for ref-based actions.
"""

import asyncio
import contextlib
import json
import logging
import subprocess
import sys
import time
from typing import Any

from lightclaw.agent.tools.browser.chrome_launcher import disconnect_cdp
from lightclaw.agent.tools.browser.enhancement_runtime import BrowserEnhancementRuntime
from lightclaw.agent.tools.browser.environment import detect_display_environment
from lightclaw.agent.tools.browser.loop_detector import LoopDetector
from lightclaw.agent.tools.browser.profiles import DEFAULT_PROFILE_NAME
from lightclaw.agent.tools.browser.session import BrowserSession, ControlOwner
from lightclaw.agent.tools.browser.shared import (
    get_chrome_manager,
    get_or_launch_browser,
    get_profile_manager,
    get_session_manager,
    register_agent_state,
    register_enhancement_runtime,
)
from lightclaw.agent.tools.browser.upload_pipeline import build_upload_request, execute_upload
from lightclaw.agent.tools.browser.url_access_planner import UrlAccessMode, UrlAccessPlanner, UrlAccessResult
from lightclaw.agent.tools.browser_snapshot import build_role_snapshot_from_aria
from lightclaw.agent.tools.media_output import build_local_media_urls
from lightclaw.agent.tools.result import LightClawToolResult, image_block, text_block

logger = logging.getLogger(__name__)

# Process-global browser state (one browser, multiple pages by page_id)
_state: dict[str, Any] = {
    "playwright": None,
    "browser": None,
    "context": None,
    "pages": {},
    "refs": {},  # page_id -> ref -> {role, name?, nth?}
    "refs_frame": {},  # page_id -> frame for last snapshot
    "console_logs": {},  # page_id -> list of {level, text}
    "network_requests": {},  # page_id -> list of request dicts
    "pending_dialogs": {},  # page_id -> dialog handlers
    "pending_file_choosers": {},  # page_id -> FileChooser list
    "headless": True,
    "current_page_id": None,
    "page_counter": 0,  # monotonic counter for page_N ids, avoids reuse after close
}

# Active session (still module-local as it couples to _state)
_active_session: BrowserSession | None = None
_enhancement_runtime = BrowserEnhancementRuntime()
_loop_detector = LoopDetector(
    max_repeated=6,
    max_failures=5,
    stale_timeout=120.0,
    window_size=30,
)

# Pending conversation context — set by browser_use() before calling
# _ensure_browser() / _action_start() so that create_session() can
# associate sessions with conversations.
_pending_conversation_id: str = ""
_pending_channel_source: str = "dashboard"

# Register the Agent state so that shared consumers (e.g. BrowserStreamSession)
# can read/write the page list for bidirectional tab sync.
register_agent_state(lambda: _state)
register_enhancement_runtime(lambda: _enhancement_runtime)


# Backward-compatible aliases for callers within this module
_get_profile_manager = get_profile_manager
_get_chrome_manager = get_chrome_manager
_get_session_manager = get_session_manager


# ---------------------------------------------------------------------------
# Public accessor helpers for devtools_control and other modules
# ---------------------------------------------------------------------------


def set_pending_conversation(conversation_id: str, channel_source: str) -> None:
    """Set the pending conversation context before _ensure_browser() runs.

    This lets SessionManager associate newly created BrowserSessions with
    the correct conversation.
    """
    global _pending_conversation_id, _pending_channel_source
    _pending_conversation_id = conversation_id
    _pending_channel_source = channel_source


def get_active_session() -> BrowserSession | None:
    """Return the current active BrowserSession, or None."""
    return _active_session


def clear_active_session() -> None:
    """Clear the module-level active session reference."""
    global _active_session
    _active_session = None


def _tool_response(text: str) -> LightClawToolResult:
    """Wrap text in a LightClawToolResult."""
    return LightClawToolResult(text=text)


def _ensure_playwright_async():
    """Import async_playwright; raise ImportError with hint if missing."""
    try:
        from playwright.async_api import async_playwright

        return async_playwright
    except ImportError as exc:
        raise ImportError(
            "Playwright not installed. Install with: pip install playwright && python -m playwright install",
        ) from exc


def _parse_json_param(value: str, default: Any = None):
    """Parse optional JSON string param (e.g. fields, paths, values)."""
    if not value or not isinstance(value, str):
        return default
    value = value.strip()
    if not value:
        return default
    try:
        return json.loads(value)
    except json.JSONDecodeError:
        if "," in value:
            return [x.strip() for x in value.split(",")]
        return default


def _sync_session_runtime_state() -> None:
    if _active_session is None:
        return
    _active_session.enhancement_runtime = _enhancement_runtime.snapshot()


def _with_enhancement_payload(payload: dict[str, Any]) -> LightClawToolResult:
    runtime_snapshot = _enhancement_runtime.snapshot()
    payload["enhancement_runtime"] = runtime_snapshot
    if _active_session is not None:
        payload.setdefault("session_id", _active_session.session_id)
        _sync_session_runtime_state()
    return _tool_response(
        json.dumps(payload, ensure_ascii=False, indent=2),
    )


async def browser_use(  # pylint: disable=R0911,R0912
    action: str,
    url: str = "",
    page_id: str = "default",
    selector: str = "",
    text: str = "",
    code: str = "",
    path: str = "",
    wait: int = 0,
    full_page: bool = False,
    width: int = 0,
    height: int = 0,
    level: str = "info",
    filename: str = "",
    accept: bool = True,
    prompt_text: str = "",
    ref: str = "",
    element: str = "",
    paths_json: str = "",
    fields_json: str = "",
    key: str = "",
    submit: bool = False,
    slowly: bool = False,
    include_static: bool = False,
    screenshot_type: str = "png",
    snapshot_filename: str = "",
    double_click: bool = False,
    button: str = "left",
    modifiers_json: str = "",
    start_ref: str = "",
    end_ref: str = "",
    start_selector: str = "",
    end_selector: str = "",
    start_element: str = "",
    end_element: str = "",
    values_json: str = "",
    tab_action: str = "",
    index: int = -1,
    wait_time: float = 0,
    text_gone: str = "",
    frame_selector: str = "",
    headed: bool = False,
    profile: str = "",
    base_directory: str = "",
    conversation_id: str = "",
    channel_source: str = "dashboard",
) -> LightClawToolResult:
    """Control browser (Playwright). Default is headless. Use headed=True with
    action=start to open a visible browser window. Flow: start, open(url),
    snapshot to get refs, then click/type etc. with ref or selector. Use
    page_id for multiple tabs.

    CRITICAL — Multi-step browser tasks (MANDATORY):
    When performing browser automation (e.g. filling forms, clicking through
    pages, publishing content, replying to posts), you MUST keep calling
    browser_use in a continuous loop until the entire task is FULLY complete
    and VERIFIED. After every action (click, type, navigate), you MUST
    immediately take a snapshot or screenshot to verify the result, then
    proceed with the next step.

    NEVER stop after a single action or after just taking a screenshot.
    NEVER end your turn saying you clicked something without verifying it
    actually worked. The pattern is:
      act → verify (snapshot/screenshot) → act → verify → ... → task done

    Common mistakes to avoid:
    - Taking a screenshot and then stopping — you must CHECK the screenshot
      and CONTINUE if the task is not done.
    - Saying "I clicked the reply button" without verifying the reply was
      actually sent — always verify with a snapshot after clicking.
    - Stopping mid-workflow because a single step succeeded — the TASK is
      not done until the ENTIRE workflow is complete.

    Args:
        action (str):
            Required. Action type. Values: start, stop, open, navigate,
            navigate_back, snapshot, screenshot, click, type, eval, evaluate,
            resize, console_messages, network_requests, handle_dialog,
            file_upload, upload_image, fill_form, install, press_key, run_code, drag, hover,
            select_option, tabs, wait_for, pdf, close.
        url (str):
            URL to open. Required for action=open or navigate.
        page_id (str):
            Page/tab identifier, default "default". Use different page_id for
            multiple tabs.
        selector (str):
            CSS selector to locate element for click/type/hover etc. Prefer
            ref when available.
        text (str):
            Text to type. Required for action=type.
        code (str):
            JavaScript code. Required for action=eval, evaluate, or run_code.
        path (str):
            File path for screenshot save or PDF export.
        wait (int):
            Milliseconds to wait after click. Used with action=click.
        full_page (bool):
            Whether to capture full page. Used with action=screenshot.
        width (int):
            Viewport width in pixels. Used with action=resize.
        height (int):
            Viewport height in pixels. Used with action=resize.
        level (str):
            Console log level filter, e.g. "info" or "error". Used with
            action=console_messages.
        filename (str):
            Filename for saving logs or screenshot. Used with
            console_messages, network_requests, screenshot.
        accept (bool):
            Whether to accept dialog (true) or dismiss (false). Used with
            action=handle_dialog.
        prompt_text (str):
            Input for prompt dialog. Used with action=handle_dialog when
            dialog is prompt.
        ref (str):
            Element ref from snapshot output; use for stable targeting. Prefer
            ref for click/type/hover/screenshot/evaluate/select_option.
        element (str):
            Element description for evaluate etc. Prefer ref when available.
        paths_json (str):
            JSON array string of file paths. Used with action=file_upload.
            Also used with action=upload_image (structured upload with
            server-side validation). Accepts JSON array of paths or objects
            with "path" and/or "identifier" keys.
        base_directory (str):
            Base directory for resolving relative paths or identifiers.
            Used with action=upload_image.
        fields_json (str):
            JSON object string of form field name to value. Used with
            action=fill_form.
        key (str):
            Key name, e.g. "Enter", "Control+a". Required for
            action=press_key.
        submit (bool):
            Whether to submit (press Enter) after typing. Used with
            action=type.
        slowly (bool):
            Whether to type character by character. Used with action=type.
        include_static (bool):
            Whether to include static resource requests. Used with
            action=network_requests.
        screenshot_type (str):
            Screenshot format, "png" or "jpeg". Used with action=screenshot.
        snapshot_filename (str):
            File path to save snapshot output. Used with action=snapshot.
        double_click (bool):
            Whether to double-click. Used with action=click.
        button (str):
            Mouse button: "left", "right", or "middle". Used with
            action=click.
        modifiers_json (str):
            JSON array of modifier keys, e.g. ["Shift","Control"]. Used with
            action=click.
        start_ref (str):
            Drag start element ref. Used with action=drag.
        end_ref (str):
            Drag end element ref. Used with action=drag.
        start_selector (str):
            Drag start CSS selector. Used with action=drag.
        end_selector (str):
            Drag end CSS selector. Used with action=drag.
        start_element (str):
            Drag start element description. Used with action=drag.
        end_element (str):
            Drag end element description. Used with action=drag.
        values_json (str):
            JSON of option value(s) for select. Used with
            action=select_option.
        tab_action (str):
            Tab action: list, new, close, or select. Required for
            action=tabs.
        index (int):
            Tab index for tabs select, zero-based. Used with action=tabs.
        wait_time (float):
            Seconds to wait. Used with action=wait_for.
        text_gone (str):
            Wait until this text disappears from page. Used with
            action=wait_for.
        frame_selector (str):
            iframe selector, e.g. "iframe#main". Set when operating inside
            that iframe in snapshot/click/type etc.
        headed (bool):
            When True with action=start, launch a visible browser window
            (non-headless). User can see the real browser. Default False.
        headed (bool):
            When True with action=start, launch a visible browser window
            (non-headless). User can see the real browser. Default False.
    """
    action = (action or "").strip().lower()
    if not action:
        return _tool_response(
            json.dumps(
                {"ok": False, "error": "action required"},
                ensure_ascii=False,
                indent=2,
            ),
        )

    # Store conversation context for downstream create_session calls
    global _pending_conversation_id, _pending_channel_source
    _pending_conversation_id = conversation_id
    _pending_channel_source = channel_source

    page_id = (page_id or "default").strip() or "default"
    current = _state.get("current_page_id")
    pages = _state.get("pages") or {}
    if page_id == "default" and current and current in pages:
        page_id = current

    # Check control ownership — block if user has control
    if (
        action not in ("start", "stop", "install")
        and _active_session
        and _active_session.control_owner == ControlOwner.USER
    ):
        # Non-dashboard channels (e.g. QQ Channel) get a shorter timeout
        # because the user has no way to interact with the browser.
        is_dashboard = _active_session.channel_source == "dashboard"
        timeout = 300 if is_dashboard else 180
        got_control = await _active_session.wait_for_agent_control(timeout=timeout)
        if not got_control:
            if not is_dashboard:
                # For non-dashboard channels, skip the login step and
                # hand control back to the agent so the conversation
                # can continue.
                _active_session.handoff(
                    ControlOwner.AGENT,
                    trigger_reason="non_dashboard_timeout_reclaim",
                )
                return _tool_response(
                    json.dumps(
                        {
                            "ok": False,
                            "error": (
                                "This page requires login but you are using "
                                "a channel that does not support interactive "
                                "browser control.  The login step was skipped. "
                                "Please guide the user to open the Dashboard "
                                "and retry from there."
                            ),
                            "requires_dashboard": True,
                        },
                        ensure_ascii=False,
                        indent=2,
                    ),
                )
            return _tool_response(
                json.dumps(
                    {
                        "ok": False,
                        "error": "User has browser control. Waiting timed out.",
                    },
                    ensure_ascii=False,
                    indent=2,
                ),
            )

    try:
        _enhancement_runtime.begin_action(action=action, page_id=page_id)
        logger.info("browser_use dispatching action=%s page_id=%s", action, page_id)
        if action == "start":
            result = await _action_start(headed=headed, profile=profile)
        elif action == "stop":
            result = await _action_stop()
        elif action == "open":
            result = await _action_open(url, page_id)
        elif action == "navigate":
            result = await _action_navigate(url, page_id)
        elif action == "navigate_back":
            result = await _action_navigate_back(page_id)
        elif action in ("screenshot", "take_screenshot"):
            result = await _action_screenshot(
                page_id,
                path or filename,
                full_page,
                screenshot_type,
                ref,
                element,
                frame_selector,
            )
        elif action == "snapshot":
            result = await _action_snapshot(
                page_id,
                snapshot_filename or filename,
                frame_selector,
            )
        elif action == "click":
            result = await _action_click(
                page_id,
                selector,
                ref,
                element,
                wait,
                double_click,
                button,
                modifiers_json,
                frame_selector,
            )
        elif action == "type":
            result = await _action_type(
                page_id,
                selector,
                ref,
                element,
                text,
                submit,
                slowly,
                frame_selector,
            )
        elif action == "eval":
            result = await _action_eval(page_id, code)
        elif action == "evaluate":
            result = await _action_evaluate(
                page_id,
                code,
                ref,
                element,
                frame_selector,
            )
        elif action == "resize":
            result = await _action_resize(page_id, width, height)
        elif action == "console_messages":
            result = await _action_console_messages(
                page_id,
                level,
                filename or path,
            )
        elif action == "handle_dialog":
            result = await _action_handle_dialog(page_id, accept, prompt_text)
        elif action == "file_upload":
            result = await _action_file_upload(page_id, paths_json)
        elif action == "upload_image":
            result = await _action_upload_image(page_id, paths_json, base_directory)
        elif action == "fill_form":
            result = await _action_fill_form(page_id, fields_json)
        elif action == "install":
            result = await _action_install()
        elif action == "press_key":
            result = await _action_press_key(page_id, key)
        elif action == "network_requests":
            result = await _action_network_requests(
                page_id,
                include_static,
                filename or path,
            )
        elif action == "run_code":
            result = await _action_run_code(page_id, code)
        elif action == "drag":
            result = await _action_drag(
                page_id,
                start_ref,
                end_ref,
                start_selector,
                end_selector,
                start_element,
                end_element,
                frame_selector,
            )
        elif action == "hover":
            result = await _action_hover(
                page_id,
                ref,
                element,
                selector,
                frame_selector,
            )
        elif action == "select_option":
            result = await _action_select_option(
                page_id,
                ref,
                element,
                values_json,
                frame_selector,
            )
        elif action == "tabs":
            result = await _action_tabs(page_id, tab_action, index)
        elif action == "wait_for":
            result = await _action_wait_for(page_id, wait_time, text, text_gone)
        elif action == "pdf":
            result = await _action_pdf(page_id, path)
        elif action == "close":
            result = await _action_close(page_id)
        else:
            result = _with_enhancement_payload(
                {"ok": False, "error": f"Unknown action: {action}"},
            )

        _enhancement_runtime.complete_action(action=action, page_id=page_id)
        _sync_session_runtime_state()

        # --- LoopDetector integration: record action & inject progress ---
        result = _inject_loop_detection(
            result,
            action=action,
            page_id=page_id,
            success=True,
        )
        return result
    except Exception as e:
        error_message = str(e)
        _enhancement_runtime.record_module_failure(
            "error_translation",
            f"dispatch_failed:{error_message}",
        )
        _sync_session_runtime_state()
        logger.error("Browser tool error: %s", e, exc_info=True)

        # Record failure in loop detector
        _loop_detector.record_action(
            action=action,
            page_id=page_id,
            success=False,
        )

        return _with_enhancement_payload(
            {"ok": False, "error": error_message},
        )


def _inject_loop_detection(
    result: LightClawToolResult,
    *,
    action: str,
    page_id: str,
    success: bool,
) -> LightClawToolResult:
    """Record action in LoopDetector and inject progress signals into tool output.

    This gives the LLM explicit awareness of:
    - Action history (what steps have been taken so far)
    - Loop alerts (repeated actions, consecutive failures, stale pages)
    - A progress hint reminding it to continue if the task is not complete
    """
    # Compute a simple page fingerprint from URL for stale-page detection
    page = _state["pages"].get(page_id)
    fingerprint = ""
    if page:
        with contextlib.suppress(Exception):
            fingerprint = page.url

    alert = _loop_detector.record_action(
        action=action,
        page_id=page_id,
        success=success,
        fingerprint=fingerprint,
    )

    # Build action history summary (last 10 actions)
    window = list(_loop_detector._window)
    history_summary = [{"action": r.action, "page_id": r.page_id, "ok": r.success} for r in window[-10:]]
    total_actions = len(window)

    # Parse the existing result text and inject new fields
    result_text = result.to_str()
    try:
        payload = json.loads(result_text)
    except (json.JSONDecodeError, AttributeError):
        # Result is not JSON-parseable; wrap it
        payload = {"original_result": result_text}

    # Inject action history
    payload["action_history"] = history_summary
    payload["total_actions_in_session"] = total_actions

    # Inject loop alert if detected — but as a soft nudge, never as a stop signal.
    # Borrowing from browser-use: loop detection is an awareness hint, not a termination trigger.
    if alert:
        payload["loop_alert"] = alert.to_dict()
        payload["loop_alert_message"] = (
            f"⚠️ LOOP AWARENESS: {alert.detail}. "
            "You may be repeating actions. "
            "Try a DIFFERENT approach (different selector, scroll, "
            "take a snapshot to reassess), but do NOT stop the task. "
            "The task is still NOT complete — keep working toward the goal."
        )
        logger.warning(
            "Loop alert injected into browser_use result: %s",
            alert.detail,
        )

    # ALWAYS inject progress hint for non-terminal actions,
    # even when a loop alert is present.  The loop alert says "try differently",
    # the progress hint says "keep going" — both are needed.
    #
    # snapshot/screenshot are INCLUDED because the LLM most often stops right
    # after seeing a page snapshot — it needs a strong nudge to keep going.
    non_terminal_actions = {
        "start",
        "open",
        "navigate",
        "navigate_back",
        "click",
        "type",
        "press_key",
        "fill_form",
        "select_option",
        "hover",
        "drag",
        "file_upload",
        "upload_image",
        "handle_dialog",
        "eval",
        "evaluate",
        "run_code",
        "resize",
        "wait_for",
        "snapshot",
        "screenshot",
    }

    # Build a plain-text continuation directive that sits BEFORE the JSON.
    # LLMs process tool output top-to-bottom — a leading plain-text warning
    # is far harder to ignore than a nested JSON field.
    continuation_lines: list[str] = []

    # Detect whether the action itself reported an error (ok=false in payload)
    action_failed = not payload.get("ok", True)

    if action in non_terminal_actions:
        payload["progress_hint"] = (
            f"Action '{action}' completed (step {total_actions}). "
            "This is ONE step in a multi-step workflow. "
            "You MUST continue with the next action. "
            "Do NOT stop or give a final answer until the ENTIRE task "
            "is verified complete by taking a snapshot and confirming the outcome."
        )
        if action_failed:
            continuation_lines.append(
                f"⚠️ STEP {total_actions}: '{action}' FAILED — but the task is NOT finished. "
                "This error does NOT mean the task is done. You MUST try a different "
                "approach and call browser_use again. Do NOT end your turn."
            )
        else:
            continuation_lines.append(
                f"⚠️ STEP {total_actions} COMPLETE — TASK NOT FINISHED. "
                f"You just executed '{action}'. "
                "You MUST call browser_use again to continue. "
                "Do NOT end your turn or give a final answer."
            )

    if alert:
        continuation_lines.append(f"⚠️ LOOP HINT: {alert.detail}. Try a DIFFERENT approach but do NOT stop the task.")

    json_body = json.dumps(payload, ensure_ascii=False, indent=2)

    # Assemble final output: plain-text directives on top, then JSON data
    if continuation_lines:
        text_output = "\n".join(continuation_lines) + "\n" + json_body
    else:
        text_output = json_body

    return _tool_response(text_output)


def _get_page(page_id: str):
    """Return page for page_id or None if not found."""
    return _state["pages"].get(page_id)


def _get_refs(page_id: str) -> dict[str, dict]:
    """Return refs map for page_id (ref -> {role, name?, nth?})."""
    return _state["refs"].setdefault(page_id, {})


def _get_root(page, _page_id: str, frame_selector: str = ""):
    """Return page or frame for frame_selector (ref/selector)."""
    if not (frame_selector and frame_selector.strip()):
        return page
    return page.frame_locator(frame_selector.strip())


def _get_locator_by_ref(
    page,
    page_id: str,
    ref: str,
    frame_selector: str = "",
):
    """Resolve snapshot ref to locator; frame_selector for iframe."""
    refs = _get_refs(page_id)
    info = refs.get(ref)
    if not info:
        return None
    role = info.get("role", "generic")
    name = info.get("name")
    nth = info.get("nth", 0)
    root = _get_root(page, page_id, frame_selector)
    locator = root.get_by_role(role, name=name or None)
    if nth is not None and nth > 0:
        locator = locator.nth(nth)
    return locator


def _init_page_state(page_id: str) -> None:
    """Initialise all per-page sub-dicts in ``_state`` for a new page_id.

    Centralises the five-dict setup that previously appeared verbatim in
    ``_action_start``, ``_register_existing_pages``, ``_attach_context_listeners``,
    and ``_action_tabs``.
    """
    _state["refs"].setdefault(page_id, {})
    _state["refs_frame"].setdefault(page_id, "")
    _state["console_logs"].setdefault(page_id, [])
    _state["network_requests"].setdefault(page_id, [])
    _state["pending_dialogs"].setdefault(page_id, [])
    _state["pending_file_choosers"].setdefault(page_id, [])


def _register_page(page, page_id: str, *, set_current: bool = True) -> None:
    """Register a Playwright page object under *page_id*.

    Initialises per-page state dicts, attaches event listeners, stores the
    page in ``_state["pages"]``, and optionally marks it as the active page.
    Replaces the scattered open-coded sequences throughout the module.
    """
    _init_page_state(page_id)
    _attach_page_listeners(page, page_id)
    _state["pages"][page_id] = page
    if set_current:
        _state["current_page_id"] = page_id


async def _clear_viewport_override(page) -> None:
    """Clear Playwright's viewport override so the page fills the browser window.

    When Playwright attaches to an existing Chrome context via CDP, it may
    apply a default viewport that is smaller than the maximized window.
    Sending ``Emulation.clearDeviceMetricsOverride`` via a temporary CDP
    session removes this constraint.  Only applied in headed (desktop) mode.
    """
    if _state.get("headless", True):
        return
    context = _state.get("context")
    if context is None:
        return
    try:
        cdp_session = await context.new_cdp_session(page)
        await cdp_session.send("Emulation.clearDeviceMetricsOverride")
        await cdp_session.detach()
    except Exception as exc:
        logger.debug("Failed to clear viewport override: %s", exc)


def _create_and_attach_session(
    profile_name: str,
    *,
    chrome=None,
    cdp_conn=None,
    inherit_chrome_from: object = None,
) -> object:
    """Create a BrowserSession via SessionManager and wire it to ``_active_session``.

    Handles the three-step boilerplate (create → assign chrome/cdp → snapshot
    enhancement_runtime) that was previously duplicated in ``_ensure_browser``,
    ``_action_start`` (reused path), and ``_action_start`` (fresh launch path).

    Args:
        profile_name: Browser profile name for ``SessionManager.create_session``.
        chrome: Chrome process handle (``ChromeProcess`` or ``None``).
        cdp_conn: CDP connection object (``CdpConnection`` or ``None``).
        inherit_chrome_from: Existing ``BrowserSession`` to copy chrome/cdp from
            when the browser process is being reused (mutually exclusive with
            ``chrome``/``cdp_conn``).

    Returns:
        The newly created ``BrowserSession``.
    """
    global _active_session
    sm = _get_session_manager()
    session = sm.create_session(
        profile_name,
        conversation_id=_pending_conversation_id,
        channel_source=_pending_channel_source,
    )
    if inherit_chrome_from is not None:
        session.chrome = inherit_chrome_from.chrome
        session.cdp = inherit_chrome_from.cdp
    else:
        session.chrome = chrome
        session.cdp = cdp_conn
    session.page_ids = list(_state["pages"].keys())
    session.enhancement_runtime = _enhancement_runtime.snapshot()
    _active_session = session
    _sync_session_runtime_state()
    return session


def _attach_page_listeners(page, page_id: str) -> None:
    """Attach console and request listeners for a page."""
    logs = _state["console_logs"].setdefault(page_id, [])

    def on_console(msg):
        logs.append({"level": msg.type, "text": msg.text})

    page.on("console", on_console)
    requests_list = _state["network_requests"].setdefault(page_id, [])

    def on_request(req):
        requests_list.append(
            {
                "url": req.url,
                "method": req.method,
                "resourceType": getattr(req, "resource_type", None),
            },
        )

    def on_response(res):
        for r in requests_list:
            if r.get("url") == res.url and "status" not in r:
                r["status"] = res.status
                break

    page.on("request", on_request)
    page.on("response", on_response)
    dialogs = _state["pending_dialogs"].setdefault(page_id, [])

    def on_dialog(dialog):
        dialogs.append(dialog)

    page.on("dialog", on_dialog)
    choosers = _state["pending_file_choosers"].setdefault(page_id, [])

    def on_filechooser(chooser):
        choosers.append(chooser)

    page.on("filechooser", on_filechooser)


def _next_page_id() -> str:
    """Return a unique page_id (page_N).
    Uses monotonic counter so IDs are not reused after close."""
    _state["page_counter"] = _state.get("page_counter", 0) + 1
    return f"page_{_state['page_counter']}"


def _attach_context_listeners(context) -> None:
    """When the page opens a new tab (e.g. target=_blank, window.open),
    register it and set as current."""

    def on_page(page):
        new_id = _next_page_id()
        _register_page(page, new_id)
        # Track tab under the active session
        if _active_session is not None:
            _active_session.page_ids.append(new_id)
        logger.debug(
            "New tab opened by page, registered as page_id=%s",
            new_id,
        )

    context.on("page", on_page)


def _register_existing_pages(context) -> None:
    """Register any pre-existing pages from a CDP-connected context.

    When Chrome launches it creates a default ``about:blank`` tab.  Without
    registering this page, ``_action_open`` would call ``new_page()`` and
    create a *second* tab, leaving a ghost blank tab behind.

    This function walks all pages already present in the context and adds
    them to ``_state["pages"]`` with proper listeners so they are visible
    to the rest of the browser-control machinery.
    """
    for page in context.pages:
        # Skip pages we already track
        already_tracked = any(tracked_page is page for tracked_page in _state["pages"].values())
        if already_tracked:
            continue

        new_id = _next_page_id()
        _register_page(page, new_id)
        logger.debug(
            "Registered pre-existing Chrome page as page_id=%s (url=%s)",
            new_id,
            page.url,
        )


async def _ensure_browser() -> bool:
    """Start browser if not running. Return True if ready, False on failure.

    Prefers CDP connection to an existing Chrome process managed by
    ChromeProcessManager.  Falls back to Playwright-managed Chromium.
    """
    if _state["browser"] is not None and _state["context"] is not None:
        # Verify the Playwright connection is still alive.  A previous
        # connect_over_cdp timeout or an unclean disconnect may leave a
        # stale browser object in _state — any operation on it will hang
        # indefinitely.  A quick `browser.is_connected()` check catches
        # this cheaply.
        try:
            if not _state["browser"].is_connected():
                logger.warning("Playwright browser object is disconnected — resetting state for reconnect")
                _state["browser"] = None
                _state["context"] = None
                _state["playwright"] = None
                _state["pages"].clear()
            else:
                return True
        except Exception:
            # is_connected() itself failed — treat as dead connection
            logger.warning("Playwright health check failed — resetting state")
            _state["browser"] = None
            _state["context"] = None
            _state["playwright"] = None
            _state["pages"].clear()

    global _active_session

    profile_name = DEFAULT_PROFILE_NAME

    try:
        running, cdp_conn, _profile = await get_or_launch_browser(
            profile_name,
            headless=_state["headless"],
        )

        _attach_context_listeners(cdp_conn.context)
        _state["playwright"] = cdp_conn.playwright
        _state["browser"] = cdp_conn.browser
        _state["context"] = cdp_conn.context

        # Register any pre-existing pages from the Chrome process
        _register_existing_pages(cdp_conn.context)

        # Create a session and associate all pre-existing pages
        _create_and_attach_session(profile_name, chrome=running, cdp_conn=cdp_conn)

        return True
    except Exception as exc:
        logger.error("Failed to start browser: %s", exc, exc_info=True)
        return False


async def _action_start(
    headed: bool = False,
    profile: str = "",
) -> LightClawToolResult:
    """Start browser with native Chrome + CDP (new architecture).

    Falls back to Playwright Chromium if Chrome is not available.
    """
    global _active_session

    profile_name = (profile or DEFAULT_PROFILE_NAME).strip() or DEFAULT_PROFILE_NAME

    # If browser is already running, create a new tab + session for this
    # conversation.  The old session (and its tabs) remain untouched —
    # sessions and tabs have a 1:N relationship.
    if _state["browser"] is not None:
        if headed and _state["headless"]:
            # Need to restart with headed mode
            await _action_stop()
        else:
            # Browser already running — create a fresh tab for this conversation
            env = detect_display_environment()

            try:
                # Create a new blank tab
                context = _state["context"]
                page = await context.new_page()
                await _clear_viewport_override(page)
                new_page_id = _next_page_id()
                _register_page(page, new_page_id)

                # Create a new session — old session stays alive with its tabs
                session = _create_and_attach_session(
                    profile_name,
                    inherit_chrome_from=_active_session,
                )
                session.page_ids = [new_page_id]

                # Reset loop detector for the new conversation
                _loop_detector.clear()

                logger.info(
                    "Browser reused — new tab %s and session %s created",
                    new_page_id,
                    session.session_id,
                )

                result: dict[str, Any] = {
                    "ok": True,
                    "message": f"Browser already running — new tab created (page_id={new_page_id})",
                    "page_id": new_page_id,
                    "profile": profile_name,
                    "environment": env,
                    "session_id": session.session_id,
                }
                return _with_enhancement_payload(result)
            except Exception as e:
                logger.warning(
                    "Failed to create new tab on cached browser context (likely stale): %s — resetting state and relaunching",
                    e,
                )
                # The cached browser/context is stale (e.g. Chrome crashed or CDP
                # connection dropped). Clear _state so the code below performs a
                # clean relaunch instead of returning a misleading "already running".
                _state["browser"] = None
                _state["context"] = None
                _state["playwright"] = None
                _state["pages"].clear()
                _state["refs"].clear()
                _state["refs_frame"].clear()
                _state["console_logs"].clear()
                _state["network_requests"].clear()
                _state["pending_dialogs"].clear()
                _state["pending_file_choosers"].clear()
                _state["current_page_id"] = None
                _state["page_counter"] = 0
                from lightclaw.agent.tools.browser.shared import clear_playwright_fallback

                clear_playwright_fallback()
                # Fall through to the fresh-launch path below

    # Auto-detect desktop environment: if the caller did not explicitly request
    # headless mode and we are running on a machine with a graphical display,
    # default to headed (visible-window) mode so the user can see Chrome.
    # Set LIGHTCLAW_BROWSER_HEADLESS=1 to force headless even on a desktop.
    import os as _os

    force_headless = _os.environ.get("LIGHTCLAW_BROWSER_HEADLESS", "").strip() == "1"
    if not headed and not force_headless:
        _auto_env = detect_display_environment()
        if _auto_env == "desktop":
            headed = True

    _state["headless"] = not headed

    env = detect_display_environment()

    try:
        _enhancement_runtime.ensure_initialized()
        _loop_detector.clear()  # Reset loop detector for new browser session
        running, cdp_conn, bp = await get_or_launch_browser(
            profile_name,
            headless=_state["headless"],
        )

        _attach_context_listeners(cdp_conn.context)
        _state["playwright"] = cdp_conn.playwright
        _state["browser"] = cdp_conn.browser
        _state["context"] = cdp_conn.context

        # Register any pre-existing pages from the Chrome process
        _register_existing_pages(cdp_conn.context)

        # Create session and associate all pre-existing pages
        session = _create_and_attach_session(profile_name, chrome=running, cdp_conn=cdp_conn)

        mode = "visible window" if headed else "headless"
        msg = f"Browser started ({mode}, profile={profile_name})"

        result: dict[str, Any] = {
            "ok": True,
            "message": msg,
            "profile": profile_name,
            "environment": env,
            "session_id": session.session_id,
        }
        if bp:
            result["profile_created_at"] = bp.created_at

        return _with_enhancement_payload(result)
    except Exception as e:
        _enhancement_runtime.mark_runtime_failure(f"start_failed:{e!s}")
        return _with_enhancement_payload(
            {"ok": False, "error": f"Browser start failed: {e!s}"},
        )


async def _action_stop() -> LightClawToolResult:
    """Stop browser: disconnect CDP but preserve user-data-dir for
    persistent login state.

    When attached to a user's existing Chrome (``attached=True``), only
    disconnects the CDP/Playwright connection — the Chrome process is
    left running untouched.
    """
    global _active_session

    if _state["browser"] is None:
        return _with_enhancement_payload(
            {"ok": True, "message": "Browser not running"},
        )

    sm = _get_session_manager()
    cm = _get_chrome_manager()
    profile_name = ""

    # Determine if we are in attached mode (user's Chrome)
    is_attached = False
    if _active_session and hasattr(_active_session, "chrome") and _active_session.chrome:
        is_attached = getattr(_active_session.chrome, "attached", False)

    try:
        # Disconnect CDP (keeps Chrome process and user-data-dir alive)
        if _active_session and _active_session.cdp:
            profile_name = _active_session.profile_name
            await disconnect_cdp(_active_session.cdp)
            _active_session.cdp = None
        elif _state["browser"]:
            with contextlib.suppress(Exception):
                await _state["browser"].close()
            if _state["playwright"]:
                with contextlib.suppress(Exception):
                    await _state["playwright"].stop()

        # Stop Chrome process only if NOT attached to user's browser.
        if profile_name:
            if is_attached:
                logger.info(
                    "Detaching from user's Chrome for profile '%s' (process left running)",
                    profile_name,
                )
                cm._processes.pop(profile_name, None)
            else:
                await cm.stop_chrome(profile_name)

        # Destroy session
        if _active_session:
            await sm.destroy_session(_active_session.session_id)
            _active_session = None

    except Exception as e:
        _enhancement_runtime.record_module_failure(
            "error_translation",
            f"stop_failed:{e!s}",
        )
        _sync_session_runtime_state()
        return _with_enhancement_payload(
            {"ok": False, "error": f"Browser stop failed: {e!s}"},
        )
    finally:
        _state["playwright"] = None
        _state["browser"] = None
        _state["context"] = None
        _state["pages"].clear()
        _state["refs"].clear()
        _state["refs_frame"].clear()
        _state["console_logs"].clear()
        _state["network_requests"].clear()
        _state["pending_dialogs"].clear()
        _state["pending_file_choosers"].clear()
        _state["current_page_id"] = None
        _state["page_counter"] = 0
        _state["headless"] = True
        _loop_detector.clear()  # Reset loop detector when browser stops
        # Clear Playwright-fallback cache so the next launch is fresh
        from lightclaw.agent.tools.browser.shared import clear_playwright_fallback

        clear_playwright_fallback()

    stop_msg = "Browser detached (user's Chrome still running)" if is_attached else "Browser stopped"
    return _with_enhancement_payload(
        {"ok": True, "message": stop_msg},
    )


async def _check_auth_after_navigation(
    session: BrowserSession | None,
) -> dict[str, Any] | None:
    """Run auth page detection after navigation.

    Uses the LLM-based detector for semantic analysis of the page's ARIA
    snapshot, with automatic fallback to keyword heuristics when the LLM
    is unavailable or times out.

    If an auth page (login, captcha, QR code) is detected, automatically
    switch control to the user and return detection info.
    Returns None if no auth page is detected.
    """
    if not session:
        return None
    try:
        from lightclaw.agent.tools.browser.auth_detector_llm import LLMAuthDetector

        detector = LLMAuthDetector(session)
        result = await detector.detect()
        if result.is_auth_page and result.confidence >= 0.75:
            # For non-dashboard channels, provide guidance instead of
            # waiting indefinitely for user interaction that can't happen.
            is_dashboard = session.channel_source == "dashboard"

            # Auto-handoff to user
            if session.control_owner == ControlOwner.AGENT:
                session.request_user_control(
                    reason=f"auth_detected:{result.auth_type}",
                )
            logger.info(
                "Auth page detected after navigation: type=%s, url=%s, confidence=%.2f, channel=%s",
                result.auth_type,
                result.url,
                result.confidence,
                session.channel_source,
            )

            response: dict[str, Any] = {
                "auth_detected": True,
                "auth_type": result.auth_type,
                "detail": result.detail,
                "confidence": result.confidence,
                "control_handed_to_user": True,
            }

            if not is_dashboard:
                # Add guidance for non-dashboard channels
                response["non_dashboard_guidance"] = (
                    "The user is on a channel that does not support "
                    "interactive browser control.  Please tell the user: "
                    "'This page requires login.  Please open the Finnie "
                    "Dashboard to complete authentication, or provide "
                    "your credentials so I can try to log in for you.'"
                )
                response["dashboard_url"] = "/chat"

            return response
    except Exception as exc:
        logger.debug("Auth detection after navigation failed: %s", exc)
    return None


async def _action_open(url: str, page_id: str) -> LightClawToolResult:
    logger.info("browser_use action=open url=%s page_id=%s", url, page_id)
    url = (url or "").strip()
    if not url:
        return _tool_response(
            json.dumps(
                {"ok": False, "error": "url required for open"},
                ensure_ascii=False,
                indent=2,
            ),
        )

    # --- URL Access Planner: decide direct-fetch vs browser ---------------
    try:
        planner = UrlAccessPlanner()
        plan_result: UrlAccessResult = await planner.plan(url)
        if plan_result.mode == UrlAccessMode.DIRECT and plan_result.ok:
            logger.info("_action_open: direct fetch succeeded for %s", url)
            return _tool_response(
                json.dumps(
                    plan_result.to_tool_response_dict(),
                    ensure_ascii=False,
                    indent=2,
                ),
            )
        # Otherwise continue with browser path (plan_result.mode == BROWSER)
    except Exception as exc:
        logger.warning("URL planner error, falling back to browser: %s", exc)
    # --- End URL Access Planner -------------------------------------------

    if not await _ensure_browser():
        return _tool_response(
            json.dumps(
                {"ok": False, "error": "Browser not started"},
                ensure_ascii=False,
                indent=2,
            ),
        )

    # Try to reuse an existing blank tab (about:blank or empty) instead of
    # creating a new one — this prevents the duplicate-tab problem when
    # Chrome launches with a default blank page.
    reuse_page = None
    reuse_id = None
    for pid, pg in list(_state["pages"].items()):
        try:
            pg_url = pg.url
            if pg_url in ("about:blank", "", "chrome://newtab/"):
                reuse_page = pg
                reuse_id = pid
                break
        except Exception:
            pass

    if reuse_page is not None:
        # Reuse the blank tab — keep the existing page_id or use the
        # caller's requested one.
        if page_id in _state["pages"] and page_id != reuse_id:
            page_id = reuse_id  # type: ignore[assignment]
        elif reuse_id != page_id:
            # Re-register under the requested page_id
            _state["pages"].pop(reuse_id, None)
            for key in (
                "refs",
                "refs_frame",
                "console_logs",
                "network_requests",
                "pending_dialogs",
                "pending_file_choosers",
            ):
                val = _state[key].pop(reuse_id, None)
                if val is not None:
                    _state[key][page_id] = val
            _state["pages"][page_id] = reuse_page
            if _state.get("current_page_id") == reuse_id:
                _state["current_page_id"] = page_id
        page = reuse_page
    else:
        # No blank tab to reuse — create a new one
        if page_id in _state["pages"]:
            page_id = _next_page_id()
        page = await _state["context"].new_page()
        await _clear_viewport_override(page)
        _state["refs"][page_id] = {}
        _state["console_logs"][page_id] = []
        _state["network_requests"][page_id] = []
        _state["pending_dialogs"][page_id] = []
        _state["pending_file_choosers"][page_id] = []
        _attach_page_listeners(page, page_id)
        _state["pages"][page_id] = page
        # Track new tab under the active session
        if _active_session is not None and page_id not in _active_session.page_ids:
            _active_session.page_ids.append(page_id)

    try:
        response = await page.goto(url, wait_until="domcontentloaded")
        _state["current_page_id"] = page_id

        actual_url = page.url

        # Detect navigation failure: chrome-error pages or no response
        load_failed = False
        fail_detail = ""
        if actual_url.startswith("chrome-error://"):
            load_failed = True
            fail_detail = (
                f"Page failed to load (chrome-error). "
                f"The URL '{url}' may be unreachable, have DNS issues, "
                f"or the site refused the connection. "
                f"Actual URL: {actual_url}"
            )
        elif response is not None and response.status >= 400:
            load_failed = True
            fail_detail = f"Page returned HTTP {response.status}. The server responded with an error for '{url}'."

        if load_failed:
            result: dict[str, Any] = {
                "ok": False,
                "error": fail_detail,
                "page_id": page_id,
                "actual_url": actual_url,
                "hint": (
                    "Check that the URL is correct and reachable. "
                    "Try opening a well-known site first (e.g. https://www.google.com) "
                    "to verify network connectivity."
                ),
            }
            return _tool_response(
                json.dumps(result, ensure_ascii=False, indent=2),
            )

        result: dict[str, Any] = {
            "ok": True,
            "message": f"Opened {url}",
            "page_id": page_id,
            "url": actual_url,
        }

        # Auto-detect auth pages (login, captcha, QR code)
        auth_info = await _check_auth_after_navigation(_active_session)
        if auth_info:
            result["auth"] = auth_info
            result["message"] += (
                f" — ⚠️ Authentication page detected ({auth_info['auth_type']}). "
                "Control has been handed to the user. "
                "The user can complete authentication in the browser panel on the right. "
                "You will regain control once the user is done."
            )

        return _tool_response(
            json.dumps(result, ensure_ascii=False, indent=2),
        )
    except Exception as e:
        return _tool_response(
            json.dumps(
                {"ok": False, "error": f"Open failed: {e!s}"},
                ensure_ascii=False,
                indent=2,
            ),
        )


async def _action_navigate(url: str, page_id: str) -> LightClawToolResult:
    logger.info("browser_use action=navigate url=%s page_id=%s", url, page_id)
    url = (url or "").strip()
    if not url:
        return _tool_response(
            json.dumps(
                {"ok": False, "error": "url required for navigate"},
                ensure_ascii=False,
                indent=2,
            ),
        )
    page = _get_page(page_id)
    if not page:
        return _tool_response(
            json.dumps(
                {"ok": False, "error": f"Page '{page_id}' not found"},
                ensure_ascii=False,
                indent=2,
            ),
        )

    # --- URL Access Planner: decide direct-fetch vs browser ---------------
    try:
        planner = UrlAccessPlanner()
        plan_result: UrlAccessResult = await planner.plan(url)
        if plan_result.mode == UrlAccessMode.DIRECT and plan_result.ok:
            logger.info("_action_navigate: direct fetch succeeded for %s", url)
            return _tool_response(
                json.dumps(
                    plan_result.to_tool_response_dict(),
                    ensure_ascii=False,
                    indent=2,
                ),
            )
        # Otherwise continue with browser path
    except Exception as exc:
        logger.warning("URL planner error, falling back to browser: %s", exc)
    # --- End URL Access Planner -------------------------------------------

    try:
        response = await page.goto(url, wait_until="domcontentloaded")
        _state["current_page_id"] = page_id

        actual_url = page.url

        # Detect navigation failure: chrome-error pages or HTTP errors
        load_failed = False
        fail_detail = ""
        if actual_url.startswith("chrome-error://"):
            load_failed = True
            fail_detail = (
                f"Page failed to load (chrome-error). "
                f"The URL '{url}' may be unreachable, have DNS issues, "
                f"or the site refused the connection. "
                f"Actual URL: {actual_url}"
            )
        elif response is not None and response.status >= 400:
            load_failed = True
            fail_detail = f"Page returned HTTP {response.status}. The server responded with an error for '{url}'."

        if load_failed:
            result: dict[str, Any] = {
                "ok": False,
                "error": fail_detail,
                "url": actual_url,
                "hint": (
                    "Check that the URL is correct and reachable. "
                    "Try opening a well-known site first (e.g. https://www.google.com) "
                    "to verify network connectivity."
                ),
            }
            return _tool_response(
                json.dumps(result, ensure_ascii=False, indent=2),
            )

        result: dict[str, Any] = {
            "ok": True,
            "message": f"Navigated to {url}",
            "url": actual_url,
        }

        # Auto-detect auth pages (login, captcha, QR code)
        auth_info = await _check_auth_after_navigation(_active_session)
        if auth_info:
            result["auth"] = auth_info
            result["message"] += (
                f" — ⚠️ Authentication page detected ({auth_info['auth_type']}). "
                "Control has been handed to the user. "
                "The user can complete authentication in the browser panel on the right. "
                "You will regain control once the user is done."
            )

        return _tool_response(
            json.dumps(result, ensure_ascii=False, indent=2),
        )
    except Exception as e:
        return _tool_response(
            json.dumps(
                {"ok": False, "error": f"Navigate failed: {e!s}"},
                ensure_ascii=False,
                indent=2,
            ),
        )


async def _action_screenshot(
    page_id: str,
    path: str,
    full_page: bool,
    screenshot_type: str = "png",
    ref: str = "",
    element: str = "",  # pylint: disable=unused-argument
    frame_selector: str = "",
) -> LightClawToolResult:
    logger.info("browser_use action=screenshot page_id=%s full_page=%s ref=%s", page_id, full_page, ref)
    path = (path or "").strip()
    if not path:
        ext = "jpeg" if screenshot_type == "jpeg" else "png"
        path = f"page-{int(time.time())}.{ext}"
    page = _get_page(page_id)
    if not page:
        return _tool_response(
            json.dumps(
                {"ok": False, "error": f"Page '{page_id}' not found"},
                ensure_ascii=False,
                indent=2,
            ),
        )
    try:
        if ref and ref.strip():
            locator = _get_locator_by_ref(
                page,
                page_id,
                ref.strip(),
                frame_selector,
            )
            if locator is None:
                return _tool_response(
                    json.dumps(
                        {"ok": False, "error": f"Unknown ref: {ref}"},
                        ensure_ascii=False,
                        indent=2,
                    ),
                )
            await locator.screenshot(
                path=path,
                type=screenshot_type if screenshot_type == "jpeg" else "png",
            )
        else:
            if frame_selector and frame_selector.strip():
                root = _get_root(page, page_id, frame_selector)
                locator = root.locator("body").first
                await locator.screenshot(
                    path=path,
                    type=screenshot_type if screenshot_type == "jpeg" else "png",
                )
            else:
                await page.screenshot(
                    path=path,
                    full_page=full_page,
                    type=screenshot_type if screenshot_type == "jpeg" else "png",
                )
        # Collect page context for better LLM decision-making
        page_url = ""
        page_title = ""
        try:
            page_url = page.url
            page_title = await page.title()
        except Exception:
            pass

        # Build structured image block with preview_url for inline rendering
        source, preview_url, file_id = build_local_media_urls(path)
        img_block = image_block(source)
        img_block["filename"] = path.split("/")[-1] if "/" in path else path
        if preview_url:
            img_block["preview_url"] = preview_url
        if file_id:
            img_block["file_id"] = file_id

        summary = json.dumps(
            {
                "ok": True,
                "message": f"Screenshot saved to {path}",
                "path": path,
                "page_url": page_url,
                "page_title": page_title,
                "hint": (
                    "Review the screenshot to determine if your task is complete. "
                    "If not, continue with the next action. "
                    "Do NOT stop in the middle of a multi-step browser workflow."
                ),
            },
            ensure_ascii=False,
            indent=2,
        )
        return LightClawToolResult(content=[img_block, text_block(summary)])
    except Exception as e:
        return _tool_response(
            json.dumps(
                {"ok": False, "error": f"Screenshot failed: {e!s}"},
                ensure_ascii=False,
                indent=2,
            ),
        )


async def _action_click(  # pylint: disable=too-many-branches
    page_id: str,
    selector: str,
    ref: str = "",
    element: str = "",  # pylint: disable=unused-argument
    wait: int = 0,
    double_click: bool = False,
    button: str = "left",
    modifiers_json: str = "",
    frame_selector: str = "",
) -> LightClawToolResult:
    logger.info(
        "browser_use action=click page_id=%s ref=%s selector=%s double=%s", page_id, ref, selector, double_click
    )
    ref = (ref or "").strip()
    selector = (selector or "").strip()
    if not ref and not selector:
        return _tool_response(
            json.dumps(
                {"ok": False, "error": "selector or ref required for click"},
                ensure_ascii=False,
                indent=2,
            ),
        )
    page = _get_page(page_id)
    if not page:
        return _tool_response(
            json.dumps(
                {"ok": False, "error": f"Page '{page_id}' not found"},
                ensure_ascii=False,
                indent=2,
            ),
        )
    try:
        if wait > 0:
            await asyncio.sleep(wait / 1000.0)
        mods = _parse_json_param(modifiers_json, [])
        if not isinstance(mods, list):
            mods = []
        kwargs = {
            "button": button if button in ("left", "right", "middle") else "left",
        }
        if mods:
            kwargs["modifiers"] = [m for m in mods if m in ("Alt", "Control", "ControlOrMeta", "Meta", "Shift")]
        if ref:
            locator = _get_locator_by_ref(page, page_id, ref, frame_selector)
            if locator is None:
                return _tool_response(
                    json.dumps(
                        {"ok": False, "error": f"Unknown ref: {ref}"},
                        ensure_ascii=False,
                        indent=2,
                    ),
                )
            if double_click:
                await locator.dblclick(**kwargs)
            else:
                await locator.click(**kwargs)
        else:
            root = _get_root(page, page_id, frame_selector)
            locator = root.locator(selector).first
            if double_click:
                await locator.dblclick(**kwargs)
            else:
                await locator.click(**kwargs)
        # Short stabilization wait after click so page has time to react
        await asyncio.sleep(0.5)
        # Collect page context after click for better LLM decision-making
        post_click_url = ""
        post_click_title = ""
        try:
            post_click_url = page.url
            post_click_title = await page.title()
        except Exception:
            pass
        result: dict[str, Any] = {
            "ok": True,
            "message": f"Clicked {ref or selector}",
            "page_url": post_click_url,
            "page_title": post_click_title,
            "hint": "Take a snapshot or screenshot to verify the click result before proceeding.",
        }
        return _tool_response(
            json.dumps(result, ensure_ascii=False, indent=2),
        )
    except Exception as e:
        return _tool_response(
            json.dumps(
                {"ok": False, "error": f"Click failed: {e!s}"},
                ensure_ascii=False,
                indent=2,
            ),
        )


async def _action_type(
    page_id: str,
    selector: str,
    ref: str = "",
    element: str = "",  # pylint: disable=unused-argument
    text: str = "",
    submit: bool = False,
    slowly: bool = False,
    frame_selector: str = "",
) -> LightClawToolResult:
    logger.info(
        "browser_use action=type page_id=%s ref=%s selector=%s text_len=%d submit=%s",
        page_id,
        ref,
        selector,
        len(text or ""),
        submit,
    )
    ref = (ref or "").strip()
    selector = (selector or "").strip()
    if not ref and not selector:
        return _tool_response(
            json.dumps(
                {"ok": False, "error": "selector or ref required for type"},
                ensure_ascii=False,
                indent=2,
            ),
        )
    page = _get_page(page_id)
    if not page:
        return _tool_response(
            json.dumps(
                {"ok": False, "error": f"Page '{page_id}' not found"},
                ensure_ascii=False,
                indent=2,
            ),
        )
    try:
        if ref:
            locator = _get_locator_by_ref(page, page_id, ref, frame_selector)
            if locator is None:
                return _tool_response(
                    json.dumps(
                        {"ok": False, "error": f"Unknown ref: {ref}"},
                        ensure_ascii=False,
                        indent=2,
                    ),
                )
            if slowly:
                await locator.press_sequentially(text or "")
            else:
                await locator.fill(text or "")
            if submit:
                await locator.press("Enter")
        else:
            root = _get_root(page, page_id, frame_selector)
            loc = root.locator(selector).first
            if slowly:
                await loc.press_sequentially(text or "")
            else:
                await loc.fill(text or "")
            if submit:
                await loc.press("Enter")
        # Collect page context after typing for better LLM decision-making
        post_type_url = ""
        post_type_title = ""
        try:
            post_type_url = page.url
            post_type_title = await page.title()
        except Exception:
            pass
        result_data: dict[str, Any] = {
            "ok": True,
            "message": f"Typed into {ref or selector}",
            "page_url": post_type_url,
            "page_title": post_type_title,
            "hint": "Take a snapshot or screenshot to verify the typing result before proceeding.",
        }
        return _tool_response(
            json.dumps(result_data, ensure_ascii=False, indent=2),
        )
    except Exception as e:
        return _tool_response(
            json.dumps(
                {"ok": False, "error": f"Type failed: {e!s}"},
                ensure_ascii=False,
                indent=2,
            ),
        )


async def _action_eval(page_id: str, code: str) -> LightClawToolResult:
    code = (code or "").strip()
    if not code:
        return _tool_response(
            json.dumps(
                {"ok": False, "error": "code required for eval"},
                ensure_ascii=False,
                indent=2,
            ),
        )
    page = _get_page(page_id)
    if not page:
        return _tool_response(
            json.dumps(
                {"ok": False, "error": f"Page '{page_id}' not found"},
                ensure_ascii=False,
                indent=2,
            ),
        )
    try:
        if code.strip().startswith("(") or code.strip().startswith("function"):
            result = await page.evaluate(code)
        elif _is_js_statement(code):
            result = await page.evaluate(f"() => {{ {code} }}")
        else:
            result = await page.evaluate(f"() => {{ return ({code}); }}")
        try:
            out = json.dumps(
                {"ok": True, "result": result},
                ensure_ascii=False,
                indent=2,
            )
        except TypeError:
            out = json.dumps(
                {"ok": True, "result": str(result)},
                ensure_ascii=False,
                indent=2,
            )
        return _tool_response(out)
    except Exception as e:
        return _tool_response(
            json.dumps(
                {"ok": False, "error": f"Eval failed: {e!s}"},
                ensure_ascii=False,
                indent=2,
            ),
        )


async def _action_pdf(page_id: str, path: str) -> LightClawToolResult:
    path = (path or "page.pdf").strip() or "page.pdf"
    page = _get_page(page_id)
    if not page:
        return _tool_response(
            json.dumps(
                {"ok": False, "error": f"Page '{page_id}' not found"},
                ensure_ascii=False,
                indent=2,
            ),
        )
    try:
        await page.pdf(path=path)
        return _tool_response(
            json.dumps(
                {"ok": True, "message": f"PDF saved to {path}", "path": path},
                ensure_ascii=False,
                indent=2,
            ),
        )
    except Exception as e:
        return _tool_response(
            json.dumps(
                {"ok": False, "error": f"PDF failed: {e!s}"},
                ensure_ascii=False,
                indent=2,
            ),
        )


async def _action_close(page_id: str) -> LightClawToolResult:
    page = _get_page(page_id)
    if not page:
        return _tool_response(
            json.dumps(
                {"ok": False, "error": f"Page '{page_id}' not found"},
                ensure_ascii=False,
                indent=2,
            ),
        )
    try:
        await page.close()
        del _state["pages"][page_id]
        for key in (
            "refs",
            "refs_frame",
            "console_logs",
            "network_requests",
            "pending_dialogs",
            "pending_file_choosers",
        ):
            _state[key].pop(page_id, None)
        if _state.get("current_page_id") == page_id:
            remaining = list(_state["pages"].keys())
            _state["current_page_id"] = remaining[0] if remaining else None
        # Remove closed tab from all sessions that track it
        sm = _get_session_manager()
        for sess in sm.list_sessions():
            if page_id in sess.page_ids:
                sess.page_ids.remove(page_id)
        return _tool_response(
            json.dumps(
                {"ok": True, "message": f"Closed page '{page_id}'"},
                ensure_ascii=False,
                indent=2,
            ),
        )
    except Exception as e:
        return _tool_response(
            json.dumps(
                {"ok": False, "error": f"Close failed: {e!s}"},
                ensure_ascii=False,
                indent=2,
            ),
        )


async def _action_snapshot(
    page_id: str,
    filename: str,
    frame_selector: str = "",
) -> LightClawToolResult:
    logger.info("browser_use action=snapshot page_id=%s frame_selector=%s", page_id, frame_selector)
    page = _get_page(page_id)
    if not page:
        return _tool_response(
            json.dumps(
                {"ok": False, "error": f"Page '{page_id}' not found"},
                ensure_ascii=False,
                indent=2,
            ),
        )
    try:
        root = _get_root(page, page_id, frame_selector)
        locator = root.locator(":root")
        raw = await locator.aria_snapshot()
        raw_str = str(raw) if raw is not None else ""
        snapshot, refs = build_role_snapshot_from_aria(
            raw_str,
            interactive=False,
            compact=False,
        )
        _state["refs"][page_id] = refs
        _state["refs_frame"][page_id] = frame_selector.strip() if frame_selector else ""
        out: dict[str, Any] = {
            "ok": True,
            "snapshot": snapshot,
            "refs": list(refs.keys()),
            "url": page.url,
        }
        if frame_selector and frame_selector.strip():
            out["frame_selector"] = frame_selector.strip()
        if filename and filename.strip():
            with open(filename.strip(), "w", encoding="utf-8") as f:
                f.write(snapshot)
            out["filename"] = filename.strip()

        # Auto-detect auth/captcha pages during snapshot — this is the
        # Agent's primary "observation" step and the best time to catch
        # blocking signals regardless of how the page was reached (click,
        # JS popup, redirect, etc.).
        auth_info = await _check_auth_after_navigation(_active_session)
        if auth_info:
            out["auth"] = auth_info
            out["auth_message"] = (
                f"⚠️ BLOCKING PAGE DETECTED ({auth_info['auth_type']}). "
                "A login, captcha, or verification challenge is blocking this page. "
                "Control has been handed to the user — they can complete the "
                "challenge in the browser panel. You MUST STOP performing browser "
                "actions and WAIT for the user to finish. Do NOT try to interact "
                "with the captcha or navigate away. Once the user completes the "
                "challenge and returns control, you can continue with the task."
            )

        return _tool_response(json.dumps(out, ensure_ascii=False, indent=2))
    except Exception as e:
        return _tool_response(
            json.dumps(
                {"ok": False, "error": f"Snapshot failed: {e!s}"},
                ensure_ascii=False,
                indent=2,
            ),
        )


async def _action_navigate_back(page_id: str) -> LightClawToolResult:
    page = _get_page(page_id)
    if not page:
        return _tool_response(
            json.dumps(
                {"ok": False, "error": f"Page '{page_id}' not found"},
                ensure_ascii=False,
                indent=2,
            ),
        )
    try:
        await page.go_back()
        return _tool_response(
            json.dumps(
                {"ok": True, "message": "Navigated back", "url": page.url},
                ensure_ascii=False,
                indent=2,
            ),
        )
    except Exception as e:
        return _tool_response(
            json.dumps(
                {"ok": False, "error": f"Navigate back failed: {e!s}"},
                ensure_ascii=False,
                indent=2,
            ),
        )


async def _action_evaluate(
    page_id: str,
    code: str,
    ref: str = "",
    element: str = "",  # pylint: disable=unused-argument
    frame_selector: str = "",
) -> LightClawToolResult:
    code = (code or "").strip()
    if not code:
        return _tool_response(
            json.dumps(
                {"ok": False, "error": "code required for evaluate"},
                ensure_ascii=False,
                indent=2,
            ),
        )
    page = _get_page(page_id)
    if not page:
        return _tool_response(
            json.dumps(
                {"ok": False, "error": f"Page '{page_id}' not found"},
                ensure_ascii=False,
                indent=2,
            ),
        )
    try:
        if ref and ref.strip():
            locator = _get_locator_by_ref(
                page,
                page_id,
                ref.strip(),
                frame_selector,
            )
            if locator is None:
                return _tool_response(
                    json.dumps(
                        {"ok": False, "error": f"Unknown ref: {ref}"},
                        ensure_ascii=False,
                        indent=2,
                    ),
                )
            result = await locator.evaluate(code)
        else:
            if code.strip().startswith("(") or code.strip().startswith(
                "function",
            ):
                result = await page.evaluate(code)
            elif _is_js_statement(code):
                result = await page.evaluate(f"() => {{ {code} }}")
            else:
                result = await page.evaluate(f"() => {{ return ({code}); }}")
        try:
            out = json.dumps(
                {"ok": True, "result": result},
                ensure_ascii=False,
                indent=2,
            )
        except TypeError:
            out = json.dumps(
                {"ok": True, "result": str(result)},
                ensure_ascii=False,
                indent=2,
            )
        return _tool_response(out)
    except Exception as e:
        return _tool_response(
            json.dumps(
                {"ok": False, "error": f"Evaluate failed: {e!s}"},
                ensure_ascii=False,
                indent=2,
            ),
        )


async def _action_resize(
    page_id: str,
    width: int,
    height: int,
) -> LightClawToolResult:
    if width <= 0 or height <= 0:
        return _tool_response(
            json.dumps(
                {"ok": False, "error": "width and height must be positive"},
                ensure_ascii=False,
                indent=2,
            ),
        )
    page = _get_page(page_id)
    if not page:
        return _tool_response(
            json.dumps(
                {"ok": False, "error": f"Page '{page_id}' not found"},
                ensure_ascii=False,
                indent=2,
            ),
        )
    try:
        await page.set_viewport_size({"width": width, "height": height})
        return _tool_response(
            json.dumps(
                {"ok": True, "message": f"Resized to {width}x{height}"},
                ensure_ascii=False,
                indent=2,
            ),
        )
    except Exception as e:
        return _tool_response(
            json.dumps(
                {"ok": False, "error": f"Resize failed: {e!s}"},
                ensure_ascii=False,
                indent=2,
            ),
        )


async def _action_console_messages(
    page_id: str,
    level: str,
    filename: str,
) -> LightClawToolResult:
    level = (level or "info").strip().lower()
    order = ("error", "warning", "info", "debug")
    idx = order.index(level) if level in order else 2
    page = _get_page(page_id)
    if not page:
        return _tool_response(
            json.dumps(
                {"ok": False, "error": f"Page '{page_id}' not found"},
                ensure_ascii=False,
                indent=2,
            ),
        )
    logs = _state["console_logs"].get(page_id, [])
    filtered = [m for m in logs if order.index(m["level"]) <= idx] if level in order else logs
    lines = [f"[{m['level']}] {m['text']}" for m in filtered]
    text = "\n".join(lines)
    if filename and filename.strip():
        with open(filename.strip(), "w", encoding="utf-8") as f:
            f.write(text)
        return _tool_response(
            json.dumps(
                {
                    "ok": True,
                    "message": f"Console messages saved to {filename}",
                    "filename": filename.strip(),
                },
                ensure_ascii=False,
                indent=2,
            ),
        )
    return _tool_response(
        json.dumps(
            {"ok": True, "messages": filtered, "text": text},
            ensure_ascii=False,
            indent=2,
        ),
    )


async def _action_handle_dialog(
    page_id: str,
    accept: bool,
    prompt_text: str,
) -> LightClawToolResult:
    page = _get_page(page_id)
    if not page:
        return _tool_response(
            json.dumps(
                {"ok": False, "error": f"Page '{page_id}' not found"},
                ensure_ascii=False,
                indent=2,
            ),
        )
    dialogs = _state["pending_dialogs"].get(page_id, [])
    if not dialogs:
        return _tool_response(
            json.dumps(
                {"ok": False, "error": "No pending dialog"},
                ensure_ascii=False,
                indent=2,
            ),
        )
    try:
        dialog = dialogs.pop(0)
        if accept:
            if prompt_text and hasattr(dialog, "accept"):
                await dialog.accept(prompt_text)
            else:
                await dialog.accept()
        else:
            await dialog.dismiss()
        return _tool_response(
            json.dumps(
                {"ok": True, "message": "Dialog handled"},
                ensure_ascii=False,
                indent=2,
            ),
        )
    except Exception as e:
        return _tool_response(
            json.dumps(
                {"ok": False, "error": f"Handle dialog failed: {e!s}"},
                ensure_ascii=False,
                indent=2,
            ),
        )


async def _action_file_upload(page_id: str, paths_json: str) -> LightClawToolResult:
    page = _get_page(page_id)
    if not page:
        return _tool_response(
            json.dumps(
                {"ok": False, "error": f"Page '{page_id}' not found"},
                ensure_ascii=False,
                indent=2,
            ),
        )
    paths = _parse_json_param(paths_json, [])
    if not isinstance(paths, list):
        paths = []
    try:
        choosers = _state["pending_file_choosers"].get(page_id, [])
        if not choosers:
            return _tool_response(
                json.dumps(
                    {
                        "ok": False,
                        "error": "No chooser. Click upload then file_upload.",
                    },
                    ensure_ascii=False,
                    indent=2,
                ),
            )
        chooser = choosers.pop(0)
        if paths:
            await chooser.set_files(paths)
            return _tool_response(
                json.dumps(
                    {"ok": True, "message": f"Uploaded {len(paths)} file(s)"},
                    ensure_ascii=False,
                    indent=2,
                ),
            )
        await chooser.set_files([])
        return _tool_response(
            json.dumps(
                {"ok": True, "message": "File chooser cancelled"},
                ensure_ascii=False,
                indent=2,
            ),
        )
    except Exception as e:
        return _tool_response(
            json.dumps(
                {"ok": False, "error": f"File upload failed: {e!s}"},
                ensure_ascii=False,
                indent=2,
            ),
        )


async def _action_upload_image(
    page_id: str,
    paths_json: str,
    base_directory: str = "",
) -> LightClawToolResult:
    """Structured image upload: resolve, validate, inject via FileChooser.

    Unlike the raw ``file_upload`` action, this performs server-side path
    resolution, boundary checks, MIME/size validation and returns structured
    error codes so the Agent can react appropriately.
    """
    request = build_upload_request(
        paths_json=paths_json,
        page_id=page_id,
        base_directory=base_directory,
    )
    result = await execute_upload(request, _state)
    return _tool_response(
        json.dumps(result.to_dict(), ensure_ascii=False, indent=2),
    )


async def _action_fill_form(page_id: str, fields_json: str) -> LightClawToolResult:
    page = _get_page(page_id)
    if not page:
        return _tool_response(
            json.dumps(
                {"ok": False, "error": f"Page '{page_id}' not found"},
                ensure_ascii=False,
                indent=2,
            ),
        )
    fields = _parse_json_param(fields_json, [])
    if not isinstance(fields, list) or not fields:
        return _tool_response(
            json.dumps(
                {"ok": False, "error": "fields required (JSON array)"},
                ensure_ascii=False,
                indent=2,
            ),
        )
    refs = _get_refs(page_id)
    # Use last snapshot's frame so fill_form works after iframe snapshot
    frame = _state["refs_frame"].get(page_id, "")
    try:
        for f in fields:
            ref = (f.get("ref") or "").strip()
            if not ref or ref not in refs:
                continue
            locator = _get_locator_by_ref(page, page_id, ref, frame)
            if locator is None:
                continue
            field_type = (f.get("type") or "textbox").lower()
            value = f.get("value")
            if field_type == "checkbox":
                if isinstance(value, str):
                    value = value.strip().lower() in ("true", "1", "yes")
                await locator.set_checked(bool(value))
            elif field_type == "radio":
                await locator.set_checked(True)
            elif field_type == "combobox":
                await locator.select_option(
                    label=value if isinstance(value, str) else None,
                    value=value,
                )
            elif field_type == "slider":
                await locator.fill(str(value))
            else:
                await locator.fill(str(value) if value is not None else "")
        return _tool_response(
            json.dumps(
                {"ok": True, "message": f"Filled {len(fields)} field(s)"},
                ensure_ascii=False,
                indent=2,
            ),
        )
    except Exception as e:
        return _tool_response(
            json.dumps(
                {"ok": False, "error": f"Fill form failed: {e!s}"},
                ensure_ascii=False,
                indent=2,
            ),
        )


async def _action_install() -> LightClawToolResult:
    try:
        subprocess.run(
            [sys.executable, "-m", "playwright", "install"],
            check=True,
            capture_output=True,
            text=True,
            timeout=120000,
        )
        return _tool_response(
            json.dumps(
                {"ok": True, "message": "Browser installed"},
                ensure_ascii=False,
                indent=2,
            ),
        )
    except Exception as e:
        return _tool_response(
            json.dumps(
                {"ok": False, "error": f"Install failed: {e!s}"},
                ensure_ascii=False,
                indent=2,
            ),
        )


async def _action_press_key(page_id: str, key: str) -> LightClawToolResult:
    key = (key or "").strip()
    if not key:
        return _tool_response(
            json.dumps(
                {"ok": False, "error": "key required for press_key"},
                ensure_ascii=False,
                indent=2,
            ),
        )
    page = _get_page(page_id)
    if not page:
        return _tool_response(
            json.dumps(
                {"ok": False, "error": f"Page '{page_id}' not found"},
                ensure_ascii=False,
                indent=2,
            ),
        )
    try:
        await page.keyboard.press(key)
        return _tool_response(
            json.dumps(
                {"ok": True, "message": f"Pressed key {key}"},
                ensure_ascii=False,
                indent=2,
            ),
        )
    except Exception as e:
        return _tool_response(
            json.dumps(
                {"ok": False, "error": f"Press key failed: {e!s}"},
                ensure_ascii=False,
                indent=2,
            ),
        )


async def _action_network_requests(
    page_id: str,
    include_static: bool,
    filename: str,
) -> LightClawToolResult:
    page = _get_page(page_id)
    if not page:
        return _tool_response(
            json.dumps(
                {"ok": False, "error": f"Page '{page_id}' not found"},
                ensure_ascii=False,
                indent=2,
            ),
        )
    requests = _state["network_requests"].get(page_id, [])
    if not include_static:
        static = ("image", "stylesheet", "font", "media")
        requests = [r for r in requests if r.get("resourceType") not in static]
    lines = [f"{r.get('method', '')} {r.get('url', '')} {r.get('status', '')}" for r in requests]
    text = "\n".join(lines)
    if filename and filename.strip():
        with open(filename.strip(), "w", encoding="utf-8") as f:
            f.write(text)
        return _tool_response(
            json.dumps(
                {
                    "ok": True,
                    "message": f"Network requests saved to {filename}",
                    "filename": filename.strip(),
                },
                ensure_ascii=False,
                indent=2,
            ),
        )
    return _tool_response(
        json.dumps(
            {"ok": True, "requests": requests, "text": text},
            ensure_ascii=False,
            indent=2,
        ),
    )


def _is_js_statement(code: str) -> bool:
    """Detect whether JS code contains statement keywords that cannot be wrapped in return(...)."""
    # Strip leading/trailing whitespace for detection
    stripped = code.strip()
    statement_prefixes = (
        "const ",
        "let ",
        "var ",
        "if ",
        "if(",
        "for ",
        "for(",
        "while ",
        "while(",
        "switch ",
        "switch(",
        "try ",
        "try{",
        "class ",
        "async ",
        "await ",
        "throw ",
        "return ",
        "import ",
        "export ",
    )
    return any(stripped.startswith(prefix) for prefix in statement_prefixes)


async def _action_run_code(page_id: str, code: str) -> LightClawToolResult:
    """Run JS in page (like eval). Use evaluate for element (ref)."""
    code = (code or "").strip()
    if not code:
        return _tool_response(
            json.dumps(
                {"ok": False, "error": "code required for run_code"},
                ensure_ascii=False,
                indent=2,
            ),
        )
    page = _get_page(page_id)
    if not page:
        return _tool_response(
            json.dumps(
                {"ok": False, "error": f"Page '{page_id}' not found"},
                ensure_ascii=False,
                indent=2,
            ),
        )
    try:
        if code.strip().startswith("(") or code.strip().startswith("function"):
            result = await page.evaluate(code)
        elif _is_js_statement(code):
            # Statement-based code: wrap in () => { <code> } without return()
            result = await page.evaluate(f"() => {{ {code} }}")
        else:
            result = await page.evaluate(f"() => {{ return ({code}); }}")
        try:
            out = json.dumps(
                {"ok": True, "result": result},
                ensure_ascii=False,
                indent=2,
            )
        except TypeError:
            out = json.dumps(
                {"ok": True, "result": str(result)},
                ensure_ascii=False,
                indent=2,
            )
        return _tool_response(out)
    except Exception as e:
        return _tool_response(
            json.dumps(
                {"ok": False, "error": f"Run code failed: {e!s}"},
                ensure_ascii=False,
                indent=2,
            ),
        )


async def _action_drag(
    page_id: str,
    start_ref: str,
    end_ref: str,
    start_selector: str = "",
    end_selector: str = "",
    start_element: str = "",  # pylint: disable=unused-argument
    end_element: str = "",  # pylint: disable=unused-argument
    frame_selector: str = "",
) -> LightClawToolResult:
    start_ref = (start_ref or "").strip()
    end_ref = (end_ref or "").strip()
    start_selector = (start_selector or "").strip()
    end_selector = (end_selector or "").strip()
    use_refs = bool(start_ref and end_ref)
    use_selectors = bool(start_selector and end_selector)
    if not use_refs and not use_selectors:
        return _tool_response(
            json.dumps(
                {
                    "ok": False,
                    "error": ("drag needs (start_ref,end_ref) or (start_sel,end_sel)"),
                },
                ensure_ascii=False,
                indent=2,
            ),
        )
    page = _get_page(page_id)
    if not page:
        return _tool_response(
            json.dumps(
                {"ok": False, "error": f"Page '{page_id}' not found"},
                ensure_ascii=False,
                indent=2,
            ),
        )
    try:
        root = _get_root(page, page_id, frame_selector)
        if use_refs:
            start_locator = _get_locator_by_ref(
                page,
                page_id,
                start_ref,
                frame_selector,
            )
            end_locator = _get_locator_by_ref(
                page,
                page_id,
                end_ref,
                frame_selector,
            )
            if start_locator is None or end_locator is None:
                return _tool_response(
                    json.dumps(
                        {"ok": False, "error": "Unknown ref for drag"},
                        ensure_ascii=False,
                        indent=2,
                    ),
                )
        else:
            start_locator = root.locator(start_selector).first
            end_locator = root.locator(end_selector).first
        await start_locator.drag_to(end_locator)
        return _tool_response(
            json.dumps(
                {"ok": True, "message": "Drag completed"},
                ensure_ascii=False,
                indent=2,
            ),
        )
    except Exception as e:
        return _tool_response(
            json.dumps(
                {"ok": False, "error": f"Drag failed: {e!s}"},
                ensure_ascii=False,
                indent=2,
            ),
        )


async def _action_hover(
    page_id: str,
    ref: str = "",
    element: str = "",  # pylint: disable=unused-argument
    selector: str = "",
    frame_selector: str = "",
) -> LightClawToolResult:
    ref = (ref or "").strip()
    selector = (selector or "").strip()
    if not ref and not selector:
        return _tool_response(
            json.dumps(
                {"ok": False, "error": "hover requires ref or selector"},
                ensure_ascii=False,
                indent=2,
            ),
        )
    page = _get_page(page_id)
    if not page:
        return _tool_response(
            json.dumps(
                {"ok": False, "error": f"Page '{page_id}' not found"},
                ensure_ascii=False,
                indent=2,
            ),
        )
    try:
        if ref:
            locator = _get_locator_by_ref(page, page_id, ref, frame_selector)
            if locator is None:
                return _tool_response(
                    json.dumps(
                        {"ok": False, "error": f"Unknown ref: {ref}"},
                        ensure_ascii=False,
                        indent=2,
                    ),
                )
        else:
            root = _get_root(page, page_id, frame_selector)
            locator = root.locator(selector).first
        await locator.hover()
        return _tool_response(
            json.dumps(
                {"ok": True, "message": f"Hovered {ref or selector}"},
                ensure_ascii=False,
                indent=2,
            ),
        )
    except Exception as e:
        return _tool_response(
            json.dumps(
                {"ok": False, "error": f"Hover failed: {e!s}"},
                ensure_ascii=False,
                indent=2,
            ),
        )


async def _action_select_option(
    page_id: str,
    ref: str = "",
    element: str = "",  # pylint: disable=unused-argument
    values_json: str = "",
    frame_selector: str = "",
) -> LightClawToolResult:
    ref = (ref or "").strip()
    values = _parse_json_param(values_json, [])
    if not isinstance(values, list):
        values = [values] if values is not None else []
    if not ref:
        return _tool_response(
            json.dumps(
                {"ok": False, "error": "ref required for select_option"},
                ensure_ascii=False,
                indent=2,
            ),
        )
    if not values:
        return _tool_response(
            json.dumps(
                {
                    "ok": False,
                    "error": "values required (JSON array or comma-separated)",
                },
                ensure_ascii=False,
                indent=2,
            ),
        )
    page = _get_page(page_id)
    if not page:
        return _tool_response(
            json.dumps(
                {"ok": False, "error": f"Page '{page_id}' not found"},
                ensure_ascii=False,
                indent=2,
            ),
        )
    try:
        locator = _get_locator_by_ref(page, page_id, ref, frame_selector)
        if locator is None:
            return _tool_response(
                json.dumps(
                    {"ok": False, "error": f"Unknown ref: {ref}"},
                    ensure_ascii=False,
                    indent=2,
                ),
            )
        await locator.select_option(value=values)
        return _tool_response(
            json.dumps(
                {"ok": True, "message": f"Selected {values}"},
                ensure_ascii=False,
                indent=2,
            ),
        )
    except Exception as e:
        return _tool_response(
            json.dumps(
                {"ok": False, "error": f"Select option failed: {e!s}"},
                ensure_ascii=False,
                indent=2,
            ),
        )


async def _action_tabs(  # pylint: disable=too-many-return-statements
    page_id: str,
    tab_action: str,
    index: int,
) -> LightClawToolResult:
    tab_action = (tab_action or "").strip().lower()
    if not tab_action:
        return _tool_response(
            json.dumps(
                {
                    "ok": False,
                    "error": "tab_action required (list, new, close, select)",
                },
                ensure_ascii=False,
                indent=2,
            ),
        )
    pages = _state["pages"]
    page_ids = list(pages.keys())
    if tab_action == "list":
        return _tool_response(
            json.dumps(
                {"ok": True, "tabs": page_ids, "count": len(page_ids)},
                ensure_ascii=False,
                indent=2,
            ),
        )
    if tab_action == "new":
        if not _state["context"]:
            ok = await _ensure_browser()
            if not ok:
                return _tool_response(
                    json.dumps(
                        {"ok": False, "error": "Browser not started"},
                        ensure_ascii=False,
                        indent=2,
                    ),
                )
        try:
            page = await _state["context"].new_page()
            await _clear_viewport_override(page)
            new_id = _next_page_id()
            _register_page(page, new_id)
            # Track new tab under the active session
            if _active_session is not None and new_id not in _active_session.page_ids:
                _active_session.page_ids.append(new_id)
            return _tool_response(
                json.dumps(
                    {
                        "ok": True,
                        "page_id": new_id,
                        "tabs": list(_state["pages"].keys()),
                    },
                    ensure_ascii=False,
                    indent=2,
                ),
            )
        except Exception as e:
            return _tool_response(
                json.dumps(
                    {"ok": False, "error": f"New tab failed: {e!s}"},
                    ensure_ascii=False,
                    indent=2,
                ),
            )
    if tab_action == "close":
        target_id = page_ids[index] if 0 <= index < len(page_ids) else page_id
        return await _action_close(target_id)
    if tab_action == "select":
        target_id = page_ids[index] if 0 <= index < len(page_ids) else page_id
        _state["current_page_id"] = target_id
        return _tool_response(
            json.dumps(
                {
                    "ok": True,
                    "message": f"Use page_id={target_id} for later actions",
                    "page_id": target_id,
                },
                ensure_ascii=False,
                indent=2,
            ),
        )
    return _tool_response(
        json.dumps(
            {"ok": False, "error": f"Unknown tab_action: {tab_action}"},
            ensure_ascii=False,
            indent=2,
        ),
    )


async def _action_wait_for(
    page_id: str,
    wait_time: float,
    text: str,
    text_gone: str,
) -> LightClawToolResult:
    page = _get_page(page_id)
    if not page:
        return _tool_response(
            json.dumps(
                {"ok": False, "error": f"Page '{page_id}' not found"},
                ensure_ascii=False,
                indent=2,
            ),
        )
    try:
        if wait_time and wait_time > 0:
            await asyncio.sleep(wait_time)
        text = (text or "").strip()
        text_gone = (text_gone or "").strip()
        if text:
            await page.get_by_text(text).wait_for(
                state="visible",
                timeout=30000,
            )
        if text_gone:
            await page.get_by_text(text_gone).wait_for(
                state="hidden",
                timeout=30000,
            )
        return _tool_response(
            json.dumps(
                {"ok": True, "message": "Wait completed"},
                ensure_ascii=False,
                indent=2,
            ),
        )
    except Exception as e:
        return _tool_response(
            json.dumps(
                {"ok": False, "error": f"Wait failed: {e!s}"},
                ensure_ascii=False,
                indent=2,
            ),
        )
