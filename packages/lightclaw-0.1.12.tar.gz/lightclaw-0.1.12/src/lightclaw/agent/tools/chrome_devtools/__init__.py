"""Chrome DevTools Protocol (CDP) tools for LightClaw.

Provides direct CDP access to the shared Chromium instance for DOM inspection,
JavaScript evaluation, and basic browser control. Designed to complement the
existing Playwright-based browser_use tool.
"""

from __future__ import annotations

from lightclaw.agent.tools.chrome_devtools.cdp_client import CDPClient
from lightclaw.agent.tools.chrome_devtools.devtools_control import devtools_control_impl
from lightclaw.agent.tools.chrome_devtools.session import CDPPageSession

__all__ = [
    "CDPClient",
    "CDPPageSession",
    "devtools_control_impl",
]
