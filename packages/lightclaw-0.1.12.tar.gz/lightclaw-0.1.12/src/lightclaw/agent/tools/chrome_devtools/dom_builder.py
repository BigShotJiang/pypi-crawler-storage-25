"""DOM tree builder: convert CDP DOM tree to an LLM-friendly text representation.

Fetches the full DOM tree from a :class:`CDPPageSession`, extracts interactive
and semantically interesting elements, and formats them as a concise tree string
similar to the ARIA snapshot produced by ``browser_snapshot.py``.
"""

from __future__ import annotations

import logging
from typing import Any

from lightclaw.agent.tools.chrome_devtools.session import CDPPageSession

logger = logging.getLogger(__name__)

# Tags whose text/attributes are worth surfacing to the LLM
_INTERACTIVE_TAGS = frozenset(
    {
        "a",
        "button",
        "input",
        "select",
        "textarea",
        "label",
        "form",
        "details",
        "summary",
        "option",
    }
)

# Tags to include even when they only have structural roles
_STRUCTURAL_TAGS = frozenset(
    {
        "html",
        "body",
        "header",
        "nav",
        "main",
        "footer",
        "article",
        "section",
        "aside",
        "h1",
        "h2",
        "h3",
        "h4",
        "h5",
        "h6",
        "p",
        "div",
        "span",
        "ul",
        "ol",
        "li",
        "table",
        "tr",
        "td",
        "th",
    }
)

_ALL_INCLUDED = _INTERACTIVE_TAGS | _STRUCTURAL_TAGS

# ARIA roles that indicate an interactive widget element
_INTERACTIVE_ROLES = frozenset(
    {
        "button",
        "link",
        "tab",
        "menuitem",
        "menuitemcheckbox",
        "menuitemradio",
        "option",
        "switch",
        "checkbox",
        "radio",
        "combobox",
        "searchbox",
        "slider",
        "spinbutton",
        "textbox",
        "treeitem",
    }
)

# Maximum text length to embed in the tree (keep LLM prompts manageable)
_MAX_TEXT_LEN = 120


def _is_interactive(tag: str, attrs: dict[str, str]) -> bool:
    """Check whether a DOM element should be treated as interactive.

    Beyond the hardcoded ``_INTERACTIVE_TAGS`` set, modern web apps make
    arbitrary elements interactive via ARIA *role*, *tabindex*, *onclick*,
    or *contenteditable*.  This function covers all of those signals so that
    ``dom_tree(interactive_only=True)`` returns a useful result even on
    sites that avoid native ``<button>``/``<a>`` elements.
    """
    if tag in _INTERACTIVE_TAGS:
        return True
    role = attrs.get("role", "").lower()
    if role in _INTERACTIVE_ROLES:
        return True
    # tabindex >= 0 means explicitly focusable
    tabindex = attrs.get("tabindex", "")
    if tabindex and tabindex != "-1":
        return True
    return "onclick" in attrs or "contenteditable" in attrs


def _attrs_to_dict(attrs_flat: list[str]) -> dict[str, str]:
    """Convert CDP flat attribute list to a name→value dict."""
    return {attrs_flat[i]: attrs_flat[i + 1] for i in range(0, len(attrs_flat) - 1, 2)}


def _node_label(node: dict[str, Any], attrs: dict[str, str]) -> str:
    """Build a short text label for a DOM node."""
    tag = node.get("localName", "").lower()
    parts: list[str] = [tag]

    if "id" in attrs:
        parts.append(f"#{attrs['id']}")
    cls = attrs.get("class", "").split()
    if cls:
        parts.append("." + ".".join(cls[:3]))  # limit to 3 classes

    specific: list[str] = []
    if tag == "a":
        href = attrs.get("href", "")
        text = attrs.get("_innerText", "")[:40]
        if text:
            specific.append(repr(text))
        elif href:
            specific.append(f"href={href!r}")
    elif tag == "input":
        itype = attrs.get("type", "text")
        name = attrs.get("name") or attrs.get("placeholder") or attrs.get("aria-label") or ""
        specific.append(f"type={itype!r}")
        if name:
            specific.append(repr(name[:40]))
    elif tag == "button":
        text = attrs.get("_innerText", "")[:40] or attrs.get("aria-label", "")[:40]
        if text:
            specific.append(repr(text))
    elif tag in {"h1", "h2", "h3", "h4", "h5", "h6"}:
        text = attrs.get("_innerText", "")[:60]
        if text:
            specific.append(repr(text))
    elif tag in {"select", "textarea"}:
        name = attrs.get("name") or attrs.get("aria-label") or ""
        if name:
            specific.append(repr(name[:40]))
    elif tag in {"p", "li", "td", "th", "span"}:
        text = attrs.get("_innerText", "")[:60]
        if text:
            specific.append(repr(text))

    # Append ARIA hints for any element
    role = attrs.get("role", "")
    if role:
        specific.append(f"role={role!r}")
    aria_label = attrs.get("aria-label", "")
    if aria_label:
        specific.append(f"aria-label={aria_label[:40]!r}")
    title = attrs.get("title", "")
    if title:
        specific.append(f"title={title[:40]!r}")

    # Fallback text for role-interactive non-standard elements (div/span with role)
    if not specific:
        text = attrs.get("_innerText", "")[:40]
        if text:
            specific.append(repr(text))

    if specific:
        parts.append("[" + ", ".join(specific) + "]")

    return "".join(parts)


class DOMTreeBuilder:
    """Convert a CDP DOM tree into a structured, LLM-friendly summary.

    The output mirrors the format of ARIA snapshots produced by
    ``browser_snapshot.py`` but uses actual DOM node IDs as refs, enabling
    precise element targeting in follow-up CDP calls.

    Usage::

        builder = DOMTreeBuilder()
        tree_text, refs = await builder.build(session, max_depth=8)
        # tree_text: multi-line indented text ready for LLM
        # refs: {ref_key: node_id, ...}
    """

    async def build(
        self,
        session: CDPPageSession,
        *,
        max_depth: int = 8,
        interactive_only: bool = False,
    ) -> tuple[str, dict[str, int]]:
        """Build a DOM tree summary.

        Args:
            session: CDP session to inspect.
            max_depth: Maximum DOM traversal depth.
            interactive_only: If True, include only interactive elements
                (buttons, links, inputs, etc.) rather than all nodes.

        Returns:
            Tuple of ``(tree_text, refs)`` where *refs* maps short reference
            keys (e.g. ``"button_42"``) to CDP node IDs.
        """
        try:
            root = await session.get_document(depth=max_depth)
        except Exception as exc:
            logger.warning("get_document failed: %s", exc)
            return f"Error fetching DOM: {exc}", {}

        refs: dict[str, int] = {}
        lines: list[str] = []
        self._traverse(root, depth=0, max_depth=max_depth, refs=refs, lines=lines, interactive_only=interactive_only)
        return "\n".join(lines), refs

    def _traverse(
        self,
        node: dict[str, Any],
        depth: int,
        max_depth: int,
        refs: dict[str, int],
        lines: list[str],
        interactive_only: bool,
    ) -> None:
        """Recursively traverse the DOM tree and build the output."""
        if depth > max_depth:
            return

        node_type = node.get("nodeType", 0)
        # 1 = Element, 3 = Text, 8 = Comment, 9 = Document
        if node_type == 9:
            # Document root — recurse into children directly
            for child in node.get("children", []):
                self._traverse(child, depth, max_depth, refs, lines, interactive_only)
            return

        if node_type == 3:
            # Text node — skip (text is inlined via _innerText attribute)
            return

        if node_type != 1:
            # Skip comments, processing instructions, etc.
            return

        tag = node.get("localName", "").lower()
        if not tag or tag in {"script", "style", "noscript", "meta", "link"}:
            return

        # Parse attributes and inner-text early — needed by _is_interactive()
        node_id = node.get("nodeId", 0)
        raw_attrs = node.get("attributes", [])
        attrs = _attrs_to_dict(raw_attrs) if raw_attrs else {}

        children = node.get("children", [])
        inner_texts: list[str] = []
        for ch in children:
            if ch.get("nodeType") == 3:
                t = (ch.get("nodeValue") or "").strip()
                if t:
                    inner_texts.append(t)
        inner_text = " ".join(inner_texts)[:_MAX_TEXT_LEN]
        if inner_text:
            attrs["_innerText"] = inner_text

        is_interactive = _is_interactive(tag, attrs)

        if interactive_only and not is_interactive:
            # Still traverse children to find nested interactive elements
            for child in children:
                self._traverse(child, depth, max_depth, refs, lines, interactive_only)
            return

        label = _node_label(node, attrs)
        indent = "  " * depth

        if node_id and is_interactive:
            ref_key = f"{tag}_{node_id}"
            refs[ref_key] = node_id
            lines.append(f"{indent}- [{ref_key}] {label}")
        elif node_id:
            lines.append(f"{indent}- {label}")
        else:
            lines.append(f"{indent}- {label}")

        for child in children:
            self._traverse(child, depth + 1, max_depth, refs, lines, interactive_only)
