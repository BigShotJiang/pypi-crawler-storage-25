"""CDP client that manages per-page sessions for the shared Chromium instance.

Attaches to the Playwright BrowserContext already created by the existing
``browser_control`` / ``browser.shared`` infrastructure so that all CDP
calls go through the same Chrome process (and therefore share cookies,
local storage, and authenticated sessions).
"""

from __future__ import annotations

import logging
from typing import Any

from lightclaw.agent.tools.chrome_devtools.session import CDPPageSession

logger = logging.getLogger(__name__)


class CDPClient:
    """Manage CDP sessions for all pages in a shared BrowserContext.

    The client is initialised with the Playwright ``BrowserContext`` and
    ``Browser`` objects obtained from :func:`browser.shared.get_or_create_browser`.
    It lazily creates a :class:`CDPPageSession` for each page on demand.

    Usage::

        client = CDPClient(browser=cdp_conn.browser, context=cdp_conn.context)
        session = await client.get_or_create_session("page_0", page_object)
        doc = await session.get_document(depth=3)
    """

    def __init__(self, browser: Any, context: Any) -> None:
        self._browser = browser
        self._context = context
        # page_id → CDPPageSession
        self._sessions: dict[str, CDPPageSession] = {}

    # ------------------------------------------------------------------
    # Session management
    # ------------------------------------------------------------------

    async def get_or_create_session(self, page_id: str, page: Any) -> CDPPageSession:
        """Return an existing session or create a new one for *page*.

        Args:
            page_id: Logical identifier used by ``browser_control`` (e.g.
                ``"page_0"``).
            page: Playwright ``Page`` object. If from a different Playwright
                connection, a local equivalent page will be found by URL matching.

        Returns:
            :class:`CDPPageSession` ready for use.

        Raises:
            RuntimeError: If the page is invalid or CDP session cannot be created.
        """
        existing = self._sessions.get(page_id)
        if existing and not existing._closed:
            # Verify the page is still the same object (tab may have navigated)
            if existing.page is page:
                return existing
            # Page replaced — close old session and create fresh one
            await self._close_session(page_id)

        # Verify page is still valid before attaching CDP
        if page.is_closed():
            raise RuntimeError(f"Page {page_id} is already closed. The browser tab may have been closed elsewhere.")

        # If the page is from a different Playwright connection (e.g., Agent's context
        # vs DevTools stream's context), find the local equivalent by URL matching.
        local_page = page
        try:
            page_url = page.url
            # Check if this page is in our context; if not, find by URL
            if page not in self._context.pages:
                matching_pages = [p for p in self._context.pages if getattr(p, "url", None) == page_url]
                if matching_pages:
                    local_page = matching_pages[0]
                    logger.debug(
                        "Page %r from different connection matched by URL (%s); using local page object",
                        page_id,
                        page_url,
                    )
        except Exception as exc:
            logger.debug("Could not check page URL for matching: %s; using original page", exc)

        try:
            raw_cdp = await self._context.new_cdp_session(local_page)
        except Exception as exc:
            raise RuntimeError(
                f"Could not attach CDP to page {page_id}. "
                f"The page may be invalid or the browser context is stale. "
                f"Details: {exc!s}"
            ) from exc

        sess = CDPPageSession(page_id=page_id, cdp_session=raw_cdp, playwright_page=local_page)
        self._sessions[page_id] = sess
        logger.debug("CDP session created for page_id=%r", page_id)
        return sess

    async def _close_session(self, page_id: str) -> None:
        """Close and remove the session for *page_id*."""
        sess = self._sessions.pop(page_id, None)
        if sess:
            await sess.close()

    async def close_all(self) -> None:
        """Close all managed CDP sessions."""
        for page_id in list(self._sessions):
            await self._close_session(page_id)

    def get_session(self, page_id: str) -> CDPPageSession | None:
        """Return an existing session without creating one.

        Returns:
            Session, or ``None`` if not created yet.
        """
        sess = self._sessions.get(page_id)
        return sess if (sess and not sess._closed) else None

    # ------------------------------------------------------------------
    # Convenience delegators
    # ------------------------------------------------------------------

    async def eval_js(
        self,
        page_id: str,
        expression: str,
        *,
        return_by_value: bool = True,
        await_promise: bool = False,
    ) -> dict[str, Any]:
        """Evaluate *expression* on the page identified by *page_id*.

        The session must already exist (call :meth:`get_or_create_session`
        first).

        Raises:
            KeyError: If no session exists for *page_id*.
        """
        sess = self._sessions.get(page_id)
        if not sess:
            raise KeyError(f"No CDP session for page_id={page_id!r}")
        return await sess.eval_js(expression, return_by_value=return_by_value, await_promise=await_promise)

    async def take_screenshot(
        self,
        page_id: str,
        *,
        format: str = "png",
        quality: int = 90,
    ) -> str:
        """Capture a screenshot for *page_id* and return base64 data.

        Raises:
            KeyError: If no session exists for *page_id*.
        """
        sess = self._sessions.get(page_id)
        if not sess:
            raise KeyError(f"No CDP session for page_id={page_id!r}")
        return await sess.take_screenshot(format=format, quality=quality)
