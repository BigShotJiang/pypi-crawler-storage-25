"""Main DevTools control implementation.

Provides ``devtools_control_impl`` — the async function called by the
LangChain ``@tool`` wrapper in ``builtins.py``.  All actions go through
the shared Chromium instance already managed by ``browser_control`` and
``browser.shared``, so cookies and sessions are fully shared.

Session / tab binding
---------------------
Each conversation gets its own ``BrowserSession`` with a dedicated set of
``page_ids``.  When a tool call arrives we look up (or create) the session
for the caller's ``conversation_id``, switch ``_active_session`` and
``current_page_id`` in ``browser_control``'s shared state so that
``_ensure_session`` and screenshots resolve to **this conversation's tab**
— not whichever tab was last used globally.

Supported actions
-----------------
start        — ensure CDP is attached to the shared browser
dom_tree     — return an LLM-friendly DOM tree with node refs
eval_js      — evaluate JavaScript in the page context
query_nodes  — find nodes by CSS selector
screenshot   — capture a PNG/JPEG screenshot via CDP
click        — click an element by ref, selector, or coordinates
type         — type text into the focused / specified element
navigate     — navigate to a URL
go_back      — navigate back
go_forward   — navigate forward
reload       — reload the page
scroll       — scroll the page by an amount
tabs         — list all open tabs with their page_ids
close        — detach CDP and destroy session
stop         — full browser shutdown (stop Chrome process)
file_upload  — upload files to an <input type="file"> element
"""

from __future__ import annotations

import asyncio
import base64
import json
import logging
from typing import Any

from lightclaw.agent.tools.chrome_devtools.cdp_client import CDPClient
from lightclaw.agent.tools.chrome_devtools.dom_builder import DOMTreeBuilder
from lightclaw.agent.tools.result import LightClawToolResult, text_block

logger = logging.getLogger(__name__)

# ---------------------------------------------------------------------------
# Module-level state
# ---------------------------------------------------------------------------

# Shared CDPClient instance (attached to the same browser as browser_control)
_cdp_client: CDPClient | None = None
_dom_builder = DOMTreeBuilder()


def _get_client() -> CDPClient | None:
    return _cdp_client


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def _ok(text: str) -> LightClawToolResult:
    return LightClawToolResult(text=text)


def _err(text: str) -> LightClawToolResult:
    return LightClawToolResult(text=f"Error: {text}")


async def _clear_page_viewport(context: object, page: object) -> None:
    """Clear Playwright's viewport override so the page fills the window.

    In headed mode Playwright may apply a default viewport smaller than the
    maximized Chrome window.  A CDP ``Emulation.clearDeviceMetricsOverride``
    command removes this constraint.
    """
    try:
        cdp_session = await context.new_cdp_session(page)  # type: ignore[union-attr]
        await cdp_session.send("Emulation.clearDeviceMetricsOverride")
        await cdp_session.detach()
    except Exception as exc:
        logger.debug("Failed to clear viewport override: %s", exc)


# ---------------------------------------------------------------------------
# Per-conversation session activation
# ---------------------------------------------------------------------------


async def _activate_conversation_session(
    conversation_id: str,
    channel_source: str = "dashboard",
) -> None:
    """Switch browser_control's ``_active_session`` and ``current_page_id``
    to point at the session belonging to *conversation_id*.

    This is the **core** of per-conversation tab isolation.  Without this,
    all conversations share the same ``current_page_id`` and screenshots /
    actions leak across conversations.

    If a session already exists for *conversation_id*, we restore it as the
    active session and set ``current_page_id`` to the **first** page owned
    by that session.  If no session exists yet **and the browser is already
    running**, we create a new tab + session immediately — the Agent may
    skip ``action=start`` and jump straight to ``navigate``.
    """
    if not conversation_id:
        return

    try:
        import lightclaw.agent.tools.browser_control as _bc
        from lightclaw.agent.tools.browser.profiles import DEFAULT_PROFILE_NAME
        from lightclaw.agent.tools.browser.shared import get_agent_state, get_session_manager
        from lightclaw.agent.tools.browser_control import (
            get_active_session,
            set_pending_conversation,
        )

        # Always update pending context for any downstream create_session
        set_pending_conversation(conversation_id, channel_source)

        # Check if there is already a session for this conversation
        sm = get_session_manager()
        sessions = sm.get_sessions_by_conversation(conversation_id)

        if not sessions:
            # No session yet.  If the browser is running, create a new
            # tab + session now so the subsequent action targets it.
            state = get_agent_state()
            if state and state.get("browser") and state.get("context"):
                context = state["context"]
                page = await context.new_page()
                new_page_id = _create_new_page_in_state(state, page)
                # Clear viewport override so the page fills the maximized window
                await _clear_page_viewport(context, page)

                session = sm.create_session(
                    DEFAULT_PROFILE_NAME,
                    conversation_id=conversation_id,
                    channel_source=channel_source,
                )
                session.page_ids.append(new_page_id)
                prev = get_active_session()
                if prev:
                    session.chrome = prev.chrome
                    session.cdp = prev.cdp
                _bc._active_session = session

                logger.info(
                    "Auto-created tab %s + session %s for conversation %s",
                    new_page_id,
                    session.session_id[:8],
                    conversation_id[:12],
                )
            return

        target = sessions[-1]  # Most recent session for this conversation

        # If already the active session, nothing to do
        current = get_active_session()
        if current and current.session_id == target.session_id:
            return

        # Switch _active_session in browser_control
        _bc._active_session = target

        # Switch current_page_id to this session's page
        state = get_agent_state()
        if state and target.page_ids:
            pages = state.get("pages", {})
            # Use the first valid page_id owned by this session
            for pid in target.page_ids:
                if pid in pages:
                    state["current_page_id"] = pid
                    break

        logger.debug(
            "Activated session %s for conversation %s (pages=%s)",
            target.session_id[:8],
            conversation_id[:8],
            target.page_ids,
        )
    except Exception as exc:
        logger.debug("_activate_conversation_session: %s", exc)


def _resolve_page_id_for_conversation(
    page_id: str,
    conversation_id: str,
    state: dict[str, Any],
) -> str:
    """Resolve ``"default"`` to the page belonging to *conversation_id*.

    Unlike the old ``_resolve_page_id`` which used the global
    ``current_page_id``, this looks up the conversation's BrowserSession
    and returns its first valid page_id.
    """
    if page_id != "default":
        return page_id

    pages = state.get("pages", {})

    # Try conversation-specific resolution
    if conversation_id:
        try:
            from lightclaw.agent.tools.browser.shared import get_session_manager

            sm = get_session_manager()
            sessions = sm.get_sessions_by_conversation(conversation_id)
            if sessions:
                for pid in sessions[-1].page_ids:
                    if pid in pages:
                        return pid
        except Exception:
            pass

    # Fallback: global current_page_id
    cur = state.get("current_page_id")
    if cur and cur in pages:
        return cur
    if pages:
        return next(iter(pages))
    return page_id


# ---------------------------------------------------------------------------
# Browser / CDP session bootstrap
# ---------------------------------------------------------------------------


async def _ensure_browser_ready() -> bool:
    """Ensure the browser is started and has at least one usable page.

    If the browser has no pages yet (fresh start), creates one blank page and
    registers it in the shared agent state so CDP sessions can attach to it.

    Returns True on success, False if browser could not be started.
    """
    from lightclaw.agent.tools.browser.shared import get_agent_state
    from lightclaw.agent.tools.browser_control import _ensure_browser

    state = get_agent_state()
    if state and state.get("browser") and state.get("pages"):
        return True

    # Start browser (sets browser/context in shared state, but no page yet)
    ok = await _ensure_browser()
    if not ok:
        return False

    # Check if pages were created by _ensure_browser (e.g. pre-existing Chrome tabs)
    state = get_agent_state()
    if not state:
        return False
    if state.get("pages"):
        return True

    # No pages yet — create one blank page and register it in shared state
    context = state.get("context")
    if context is None:
        return False
    try:
        page = await context.new_page()
        page_id = _create_new_page_in_state(state, page)
        await _clear_page_viewport(context, page)
        logger.debug("Created initial page %r for devtools_control", page_id)
        return True
    except Exception as exc:
        logger.warning("Failed to create initial page: %s", exc)
        return False


# Sentinel to distinguish "browser couldn't start" from "page not found"
_SESSION_RESULT = tuple[Any, Any, str]  # (client, page, actual_pid)
_SESSION_NONE: tuple[None, None, None] = (None, None, None)


async def _ensure_session(
    page_id: str,
    conversation_id: str = "",
) -> _SESSION_RESULT | tuple[None, None, None]:
    """Return (cdp_client, page, actual_pid), auto-starting browser if needed.

    Handles all of:
    - Browser not yet started → starts it via _ensure_browser()
    - page_id == "default" → resolves to this conversation's active page
    - page object from different Playwright connection → matches by URL

    Returns:
        (client, page, actual_pid) on success, (None, None, None) on failure.
    """
    global _cdp_client

    try:
        from lightclaw.agent.tools.browser.shared import get_agent_state

        # Auto-start browser + create initial page if not yet running
        state = get_agent_state()
        if not state or not state.get("browser") or not state.get("pages"):
            ok = await _ensure_browser_ready()
            if not ok:
                return _SESSION_NONE
            state = get_agent_state()

        if not state:
            return _SESSION_NONE

        # Resolve "default" → conversation-specific page_id
        actual_pid = _resolve_page_id_for_conversation(page_id, conversation_id, state)

        page = state.get("pages", {}).get(actual_pid)
        if page is None:
            return _SESSION_NONE

        context = state.get("context")
        browser = state.get("browser")
        if context is None or browser is None:
            return _SESSION_NONE

        if _cdp_client is None:
            _cdp_client = CDPClient(browser=browser, context=context)
        elif _cdp_client._context is not context:
            # Context changed (browser restart) — reset client
            await _cdp_client.close_all()
            _cdp_client = CDPClient(browser=browser, context=context)

        await _cdp_client.get_or_create_session(actual_pid, page)
        return _cdp_client, page, actual_pid

    except RuntimeError as exc:
        # Page is closed or CDP attachment failed
        logger.warning("_ensure_session failed (page/context issue): %s", exc)
        return _SESSION_NONE
    except Exception as exc:
        logger.warning("_ensure_session failed: %s", exc)
        return _SESSION_NONE


# ---------------------------------------------------------------------------
# Action implementations
# ---------------------------------------------------------------------------


def _create_new_page_in_state(state: dict[str, Any], page: object) -> str:
    """Register a new Playwright page in the shared agent state.

    Returns the new page_id.  Mirrors browser_control's page registration
    pattern so pages are visible to both tools and the browser stream.
    """
    counter = state.get("page_counter", 0) + 1
    state["page_counter"] = counter
    page_id = f"page_{counter}"
    state["pages"][page_id] = page
    state["current_page_id"] = page_id
    state.setdefault("refs", {})[page_id] = {}
    state.setdefault("console_logs", {})[page_id] = []
    state.setdefault("network_requests", {})[page_id] = []
    state.setdefault("pending_dialogs", {})[page_id] = []
    state.setdefault("pending_file_choosers", {})[page_id] = []
    return page_id


async def _action_start(
    conversation_id: str = "",
    channel_source: str = "dashboard",
) -> LightClawToolResult:
    """Attach CDP to the shared browser, starting it first if not running.

    If the browser is already running **and** this conversation doesn't have
    a session yet, create a new tab + session (matching browser_use's
    ``_action_start`` behaviour for reused browsers).
    """
    try:
        import lightclaw.agent.tools.browser_control as _bc
        from lightclaw.agent.tools.browser.profiles import DEFAULT_PROFILE_NAME
        from lightclaw.agent.tools.browser.shared import get_agent_state, get_session_manager
        from lightclaw.agent.tools.browser_control import (
            _ensure_browser,
            get_active_session,
            set_pending_conversation,
        )

        if conversation_id:
            set_pending_conversation(conversation_id, channel_source)

        state = get_agent_state()
        sm = get_session_manager()

        # --- Case 1: Browser not yet running → cold start ---
        if state is None or not state.get("browser"):
            ok = await _ensure_browser()
            if not ok:
                return _err("Could not start browser. Check Chrome/Chromium installation.")

            # _ensure_browser already created the first session + page.
            # Make sure the session has the page tracked.
            session = get_active_session()
            state = get_agent_state()
            if session and state:
                for pid in list(state.get("pages", {}).keys()):
                    if pid not in session.page_ids:
                        session.page_ids.append(pid)

            page_ids = list((state or {}).get("pages", {}).keys())
            sid = session.session_id[:8] if session else "?"
            return _ok(f"Browser started. session={sid}, pages={page_ids}")

        # --- Case 2: Browser running, check if this conversation has a session ---
        existing = sm.get_sessions_by_conversation(conversation_id) if conversation_id else []
        if existing:
            # Already has a session — just activate it
            target = existing[-1]
            _bc._active_session = target
            if target.page_ids:
                state["current_page_id"] = target.page_ids[0]
            return _ok(f"Browser already running. Reactivated session={target.session_id[:8]}, pages={target.page_ids}")

        # --- Case 3: Browser running but no session for this conversation ---
        # Create a new tab + session, just like browser_use does.
        context = state.get("context")
        if context is None:
            return _err("Browser context is not available.")

        page = await context.new_page()
        new_page_id = _create_new_page_in_state(state, page)
        await _clear_page_viewport(context, page)

        session = sm.create_session(
            DEFAULT_PROFILE_NAME,
            conversation_id=conversation_id,
            channel_source=channel_source,
        )
        session.page_ids.append(new_page_id)
        # Inherit chrome/cdp refs from current active session
        prev = get_active_session()
        if prev:
            session.chrome = prev.chrome
            session.cdp = prev.cdp
        _bc._active_session = session

        logger.info(
            "Browser reused — new tab %s and session %s for conversation %s",
            new_page_id,
            session.session_id[:8],
            conversation_id[:8] if conversation_id else "?",
        )
        return _ok(
            f"Browser already running — new tab created. session={session.session_id[:8]}, page_id={new_page_id}"
        )

    except Exception as exc:
        return _err(str(exc))


async def _action_dom_tree(
    page_id: str,
    conversation_id: str,
    max_depth: int = 8,
    interactive_only: bool = False,
) -> LightClawToolResult:
    """Return an LLM-friendly DOM tree with node refs."""
    try:
        client, _page, actual_pid = await _ensure_session(page_id, conversation_id)
        if client is None:
            return _err(
                f"No browser page available (requested page_id={page_id!r}). "
                "Try browser_control(action='tabs') or browser_control(action='start')."
            )

        sess = client.get_session(actual_pid)
        if sess is None:
            return _err(f"Could not get CDP session for page_id={actual_pid!r}")

        tree_text, refs = await _dom_builder.build(
            sess,
            max_depth=max_depth,
            interactive_only=interactive_only,
        )
        refs_summary = "\n".join(f"  {k}: nodeId={v}" for k, v in list(refs.items())[:30])
        if len(refs) > 30:
            refs_summary += f"\n  ... ({len(refs) - 30} more)"

        output = f"DOM tree for page_id={actual_pid!r}:\n{tree_text}\n\nRefs (use as 'ref' param):\n{refs_summary}"
        return _ok(output)

    except Exception as exc:
        logger.warning("dom_tree failed: %s", exc)
        return _err(str(exc))


async def _action_eval_js(
    page_id: str,
    conversation_id: str,
    code: str,
    *,
    await_promise: bool = False,
) -> LightClawToolResult:
    """Evaluate JavaScript in the page context."""
    if not code:
        return _err("'code' parameter is required for eval_js action.")

    try:
        client, _page, actual_pid = await _ensure_session(page_id, conversation_id)
        if client is None:
            return _err(
                f"No browser page available (requested page_id={page_id!r}). Try browser_control(action='start') first."
            )

        sess = client.get_session(actual_pid)
        if sess is None:
            return _err("Could not get CDP session.")

        result = await sess.eval_js(code, return_by_value=True, await_promise=await_promise)

        if "exceptionDetails" in result:
            exc_detail = result["exceptionDetails"]
            exc_text = exc_detail.get("exception", {}).get("description", str(exc_detail))
            return _ok(f"JavaScript exception:\n{exc_text}")

        remote_obj = result.get("result", {})
        obj_type = remote_obj.get("type", "")
        value = remote_obj.get("value")

        if obj_type == "undefined":
            return _ok("Result: undefined")
        if value is None and obj_type in ("object", "function"):
            desc = remote_obj.get("description", "")
            return _ok(f"Result ({obj_type}): {desc}")
        if isinstance(value, dict | list):
            return _ok(f"Result:\n{json.dumps(value, ensure_ascii=False, indent=2)}")
        return _ok(f"Result: {value!r}")

    except Exception as exc:
        logger.warning("eval_js failed: %s", exc)
        return _err(str(exc))


async def _action_query_nodes(
    page_id: str,
    conversation_id: str,
    selector: str,
) -> LightClawToolResult:
    """Find DOM nodes by CSS selector."""
    if not selector:
        return _err("'selector' parameter is required for query_nodes action.")

    try:
        client, _page, actual_pid = await _ensure_session(page_id, conversation_id)
        if client is None:
            return _err(
                f"No browser page available (requested page_id={page_id!r}). Try browser_control(action='start') first."
            )

        sess = client.get_session(actual_pid)
        if sess is None:
            return _err("Could not get CDP session.")

        root = await sess.get_document(depth=0)
        root_id = root.get("nodeId", 0)
        if not root_id:
            return _err("Could not get DOM root.")

        node_ids = await sess.query_selector_all(root_id, selector)
        if not node_ids:
            return _ok(f"No elements found matching selector: {selector!r}")

        results: list[str] = [f"Found {len(node_ids)} element(s) for {selector!r}:"]
        for nid in node_ids[:20]:
            attrs = await sess.get_attributes(nid)
            tag_info = attrs.get("_tag", "")
            id_attr = attrs.get("id", "")
            cls_attr = attrs.get("class", "")[:50]
            text_attr = attrs.get("aria-label") or attrs.get("placeholder") or attrs.get("value") or ""
            line = f"  ref=node_{nid}"
            if id_attr:
                line += f" id={id_attr!r}"
            if cls_attr:
                line += f" class={cls_attr!r}"
            if text_attr:
                line += f" label={text_attr[:40]!r}"
            if tag_info:
                line += f" tag={tag_info}"
            results.append(line)

        if len(node_ids) > 20:
            results.append(f"  ... ({len(node_ids) - 20} more)")

        return _ok("\n".join(results))

    except Exception as exc:
        logger.warning("query_nodes failed: %s", exc)
        return _err(str(exc))


async def _action_screenshot(
    page_id: str,
    conversation_id: str,
    *,
    format: str = "png",
    quality: int = 85,
) -> LightClawToolResult:
    """Capture a screenshot via CDP."""
    try:
        from lightclaw.constant import WORKING_DIR

        client, _page, actual_pid = await _ensure_session(page_id, conversation_id)
        if client is None:
            return _err(
                f"No browser page available (requested page_id={page_id!r}). Try browser_control(action='start') first."
            )

        sess = client.get_session(actual_pid)
        if sess is None:
            return _err("Could not get CDP session.")

        try:
            b64_data = await sess.take_screenshot(format=format, quality=quality)
        except Exception:
            # Session may be stale (e.g. after navigation).  Drop it and retry once.
            await client._close_session(actual_pid)
            await client.get_or_create_session(actual_pid, _page)
            sess = client.get_session(actual_pid)
            if sess is None:
                return _err("Could not re-attach CDP session for screenshot.")
            b64_data = await sess.take_screenshot(format=format, quality=quality)
        if not b64_data:
            return _err("Screenshot returned empty data.")

        img_bytes = base64.b64decode(b64_data)
        suffix = ".png" if format == "png" else ".jpg"

        # Save to workspace/temp/ per AGENTS.md convention
        temp_dir = WORKING_DIR / "temp"
        temp_dir.mkdir(parents=True, exist_ok=True)
        import time as _time

        filename = f"devtools_screenshot_{actual_pid}_{int(_time.time())}{suffix}"
        save_path = temp_dir / filename
        save_path.write_bytes(img_bytes)
        tmp_path = str(save_path)

        # Include page title + URL so the LLM knows context without dom_tree.
        try:
            page_title = await _page.title()
        except Exception:
            page_title = ""
        page_url = _page.url or ""

        summary = (
            f"Screenshot saved: {tmp_path}\n"
            f"Use file_preview(file_path={tmp_path!r}) to show it to the user.\n"
            f"page_url: {page_url}\n"
            f"page_title: {page_title}"
        )

        return LightClawToolResult(
            content=[
                text_block(summary),
            ]
        )

    except Exception as exc:
        logger.warning("screenshot failed: %s", exc)
        return _err(str(exc))


async def _action_click(
    page_id: str,
    conversation_id: str,
    selector: str = "",
    ref: str = "",
    x: float | None = None,
    y: float | None = None,
) -> LightClawToolResult:
    """Click an element via CDP Input.dispatchMouseEvent."""
    try:
        client, _page, actual_pid = await _ensure_session(page_id, conversation_id)
        if client is None:
            return _err(
                f"No browser page available (requested page_id={page_id!r}). Try browser_control(action='start') first."
            )

        sess = client.get_session(actual_pid)
        if sess is None:
            return _err("Could not get CDP session.")

        # Resolve target coordinates
        click_x, click_y = x, y

        if ref and ref.startswith("node_"):
            # Direct node ref (node_<id>)
            try:
                node_id = int(ref.split("_", 1)[1])
                box = await sess.get_box_model(node_id)
                if box:
                    content = box.get("content", [])
                    if len(content) >= 2:
                        click_x = (content[0] + content[4]) / 2
                        click_y = (content[1] + content[5]) / 2
            except (ValueError, IndexError):
                pass
        elif selector:
            root = await sess.get_document(depth=0)
            root_id = root.get("nodeId", 0)
            if root_id:
                node_id = await sess.query_selector(root_id, selector)
                if node_id:
                    box = await sess.get_box_model(node_id)
                    if box:
                        content = box.get("content", [])
                        if len(content) >= 6:
                            click_x = (content[0] + content[4]) / 2
                            click_y = (content[1] + content[5]) / 2

        if click_x is None or click_y is None:
            return _err("Could not determine click coordinates. Provide x/y, ref, or selector.")

        # Dispatch CDP mouse events
        raw_cdp = sess._cdp
        for event_type, click_count in [("mouseMoved", 0), ("mousePressed", 1), ("mouseReleased", 1)]:
            await raw_cdp.send(
                "Input.dispatchMouseEvent",
                {
                    "type": event_type,
                    "x": click_x,
                    "y": click_y,
                    "button": "left",
                    "buttons": 1 if event_type == "mousePressed" else 0,
                    "clickCount": click_count,
                },
            )

        return _ok(f"Clicked at ({click_x:.1f}, {click_y:.1f})")

    except Exception as exc:
        logger.warning("click failed: %s", exc)
        return _err(str(exc))


async def _action_type(
    page_id: str,
    conversation_id: str,
    text: str,
    selector: str = "",
) -> LightClawToolResult:
    """Type text into the focused element (or element matched by selector)."""
    if not text:
        return _err("'text' parameter is required for type action.")

    try:
        client, page, actual_pid = await _ensure_session(page_id, conversation_id)
        if client is None:
            return _err(
                f"No browser page available (requested page_id={page_id!r}). Try browser_control(action='start') first."
            )

        if selector:
            await page.focus(selector)

        sess = client.get_session(actual_pid)
        if sess is None:
            return _err("Could not get CDP session.")

        raw_cdp = sess._cdp
        for char in text:
            await raw_cdp.send(
                "Input.dispatchKeyEvent",
                {"type": "char", "text": char},
            )

        return _ok(f"Typed {len(text)} character(s).")

    except Exception as exc:
        logger.warning("type failed: %s", exc)
        return _err(str(exc))


async def _invalidate_cdp_and_describe(
    client: CDPClient,
    page: object,
    page_id: str,
    verb: str,
) -> str:
    """Drop the cached CDP session after navigation and return a status line.

    Chrome invalidates the CDP session on every cross-document navigation.
    This helper centralises the session cleanup + page-info collection that
    is repeated across navigate, go_back, go_forward, and reload.
    """
    await client._close_session(page_id)
    try:
        title = await page.title()  # type: ignore[union-attr]
    except Exception:
        title = ""
    current_url = page.url or ""  # type: ignore[union-attr]
    return (
        f"{verb}. Current page: url={current_url!r}, title={title!r}\n"
        f"Use action='dom_tree' to read page content, or action='screenshot' to see it."
    )


async def _action_navigate(
    page_id: str,
    conversation_id: str,
    url: str,
) -> LightClawToolResult:
    """Navigate the page to *url*."""
    if not url:
        return _err("'url' parameter is required for navigate action.")

    try:
        client, page, actual_pid = await _ensure_session(page_id, conversation_id)
        if client is None:
            return _err(
                f"No browser page available (requested page_id={page_id!r}). Try browser_control(action='start') first."
            )

        # Hard timeout (45s) as a safety net.  Playwright's own goto timeout
        # is 30s, but if the Playwright connection is dead/stale the internal
        # timeout never fires and the call hangs forever.
        try:
            await asyncio.wait_for(
                page.goto(url, timeout=30_000, wait_until="domcontentloaded"),
                timeout=45,
            )
        except TimeoutError:
            return _err(
                f"Navigation to {url!r} timed out after 45 seconds. "
                "The browser connection may be stale — try browser_control(action='stop') "
                "then browser_control(action='start') to reconnect."
            )
        result_text = await _invalidate_cdp_and_describe(
            client, page, actual_pid, f"Navigated to {page.url or url!r} (page_id={actual_pid!r})"
        )

        # Track this page under the conversation's session
        try:
            from lightclaw.agent.tools.browser_control import get_active_session

            session = get_active_session()
            if session and actual_pid not in session.page_ids:
                session.page_ids.append(actual_pid)
        except Exception:
            pass

        return _ok(result_text)

    except Exception as exc:
        logger.warning("navigate failed: %s", exc)
        return _err(str(exc))


async def _action_go_back(page_id: str, conversation_id: str) -> LightClawToolResult:
    """Navigate back in history."""
    try:
        client, page, _pid = await _ensure_session(page_id, conversation_id)
        if client is None:
            return _err(f"No browser page available (requested page_id={page_id!r}).")
        await page.go_back()
        return _ok(await _invalidate_cdp_and_describe(client, page, _pid, "Navigated back"))
    except Exception as exc:
        return _err(str(exc))


async def _action_go_forward(page_id: str, conversation_id: str) -> LightClawToolResult:
    """Navigate forward in history."""
    try:
        client, page, _pid = await _ensure_session(page_id, conversation_id)
        if client is None:
            return _err(f"No browser page available (requested page_id={page_id!r}).")
        await page.go_forward()
        return _ok(await _invalidate_cdp_and_describe(client, page, _pid, "Navigated forward"))
    except Exception as exc:
        return _err(str(exc))


async def _action_reload(page_id: str, conversation_id: str) -> LightClawToolResult:
    """Reload the current page."""
    try:
        client, page, _pid = await _ensure_session(page_id, conversation_id)
        if client is None:
            return _err(f"No browser page available (requested page_id={page_id!r}).")
        await page.reload()
        return _ok(await _invalidate_cdp_and_describe(client, page, _pid, "Page reloaded"))
    except Exception as exc:
        return _err(str(exc))


async def _action_scroll(
    page_id: str,
    conversation_id: str,
    x: float = 0,
    y: float = 0,
    delta_x: float = 0,
    delta_y: float = 300,
) -> LightClawToolResult:
    """Scroll the page using CDP wheel events."""
    try:
        client, _page, actual_pid = await _ensure_session(page_id, conversation_id)
        if client is None:
            return _err(f"No browser page available (requested page_id={page_id!r}).")

        sess = client.get_session(actual_pid)
        if sess is None:
            return _err("Could not get CDP session.")

        await sess._cdp.send(
            "Input.dispatchMouseEvent",
            {
                "type": "mouseWheel",
                "x": x,
                "y": y,
                "deltaX": delta_x,
                "deltaY": delta_y,
            },
        )
        return _ok(f"Scrolled by deltaY={delta_y:.0f} at ({x:.0f}, {y:.0f})")

    except Exception as exc:
        return _err(str(exc))


async def _action_tabs(conversation_id: str) -> LightClawToolResult:
    """List open tabs.  Highlights which belong to this conversation."""
    try:
        from lightclaw.agent.tools.browser.shared import get_agent_state, get_session_manager

        state = get_agent_state()
        if not state:
            return _err("Browser not started.")

        pages = state.get("pages", {})
        if not pages:
            return _ok("No open tabs.")

        # Find this conversation's page_ids
        my_pids: set[str] = set()
        if conversation_id:
            sm = get_session_manager()
            for s in sm.get_sessions_by_conversation(conversation_id):
                my_pids.update(s.page_ids)

        current = state.get("current_page_id")
        lines: list[str] = ["Open tabs:"]
        for pid, page in pages.items():
            try:
                url = page.url
            except Exception:
                url = "(unknown)"
            markers = []
            if pid == current:
                markers.append("active")
            if pid in my_pids:
                markers.append("mine")
            suffix = f" ({', '.join(markers)})" if markers else ""
            lines.append(f"  page_id={pid!r}  url={url!r}{suffix}")
        return _ok("\n".join(lines))

    except Exception as exc:
        return _err(str(exc))


async def _action_get_metrics(page_id: str, conversation_id: str) -> LightClawToolResult:
    """Return Chrome performance metrics."""
    try:
        client, _page, actual_pid = await _ensure_session(page_id, conversation_id)
        if client is None:
            return _err(f"No browser page available (requested page_id={page_id!r}).")

        sess = client.get_session(actual_pid)
        if sess is None:
            return _err("Could not get CDP session.")

        metrics = await sess.get_performance_metrics()
        if not metrics:
            return _ok("No performance metrics available.")

        lines: list[str] = [f"Performance metrics for page_id={actual_pid!r}:"]
        for m in metrics:
            lines.append(f"  {m['name']}: {m['value']:.3f}")
        return _ok("\n".join(lines))

    except Exception as exc:
        return _err(str(exc))


async def _action_close(conversation_id: str) -> LightClawToolResult:
    """Logically close this conversation's tab(s) and remove its session.

    Pages are removed from agent state but NOT physically closed via
    Playwright — that would invalidate CDP sessions of other conversations
    sharing the same browser context.  Physical cleanup happens on ``stop``.
    """
    closed_pages: list[str] = []

    try:
        from lightclaw.agent.tools.browser.shared import get_agent_state, get_session_manager

        sm = get_session_manager()
        state = get_agent_state()

        if conversation_id and state:
            sessions = sm.get_sessions_by_conversation(conversation_id)
            pages = state.get("pages", {})

            for sess in sessions:
                for pid in list(sess.page_ids):
                    # Remove from agent state (logical close)
                    pages.pop(pid, None)
                    for key in (
                        "refs",
                        "console_logs",
                        "network_requests",
                        "pending_dialogs",
                        "pending_file_choosers",
                    ):
                        state.get(key, {}).pop(pid, None)
                    closed_pages.append(pid)

                    # Detach CDP session for this page
                    if _cdp_client is not None:
                        import contextlib

                        with contextlib.suppress(Exception):
                            await _cdp_client._close_session(pid)

                await sm.destroy_session(sess.session_id)

            # Fix current_page_id if we just removed it
            if state.get("current_page_id") in closed_pages:
                remaining = list(pages.keys())
                state["current_page_id"] = remaining[0] if remaining else None

    except Exception as exc:
        logger.debug("Session cleanup on close: %s", exc)

    return _ok(f"Closed pages {closed_pages} for this conversation.")


async def _action_stop() -> LightClawToolResult:
    """Full browser shutdown — close CDP, destroy session, stop Chrome."""
    global _cdp_client

    # Close CDP sessions first
    if _cdp_client is not None:
        await _cdp_client.close_all()
        _cdp_client = None

    # Delegate the heavy lifting to browser_control's stop action
    try:
        from lightclaw.agent.tools.browser_control import _action_stop as _bc_stop

        return await _bc_stop()
    except Exception as exc:
        logger.warning("stop failed: %s", exc)
        return _err(str(exc))


# ---------------------------------------------------------------------------
# File upload via CDP
# ---------------------------------------------------------------------------


async def _action_file_upload(
    page_id: str,
    conversation_id: str,
    paths_json: str,
    selector: str = "",
    ref: str = "",
) -> LightClawToolResult:
    """Upload files to an ``<input type="file">`` element via CDP ``DOM.setFileInputFiles``.

    Resolution order for the target element:
    1. *ref* — direct ``node_<id>`` reference from a previous ``dom_tree`` call.
    2. *selector* — CSS selector (must match an ``<input type="file">``).
    3. Auto-detect — find the first ``input[type="file"]`` on the page.

    File paths are parsed and validated through the existing upload pipeline
    (``build_upload_request`` / ``FileResolver``) which enforces path-traversal
    protection, MIME-type whitelisting and size limits.
    """
    if not paths_json:
        return _err("'paths_json' is required for file_upload (JSON array of file paths).")

    try:
        client, _page, actual_pid = await _ensure_session(page_id, conversation_id)
        if client is None:
            return _err(
                f"No browser page available (requested page_id={page_id!r}). Try browser_control(action='start') first."
            )

        sess = client.get_session(actual_pid)
        if sess is None:
            return _err("Could not get CDP session.")

        # -- Resolve & validate file paths via the shared upload pipeline --
        from lightclaw.agent.tools.browser.file_resolver import FileResolver
        from lightclaw.agent.tools.browser.upload_pipeline import build_upload_request

        request = build_upload_request(paths_json=paths_json)
        resolver = FileResolver()
        result = resolver.resolve_and_validate(request.files)
        if not result.ok:
            return _err(f"File validation failed: {result.error_message}")

        resolved_paths = result.resolved_paths

        # -- Find the target <input type="file"> node --
        node_id: int | None = None

        if ref and ref.startswith("node_"):
            # Direct node ref
            try:
                node_id = int(ref.split("_", 1)[1])
            except (ValueError, IndexError):
                return _err(f"Invalid ref format: {ref!r}")
        elif selector:
            root = await sess.get_document(depth=0)
            root_id = root.get("nodeId", 0)
            if root_id:
                node_id = await sess.query_selector(root_id, selector)
            if not node_id:
                return _err(f"No element found for selector {selector!r}.")
        else:
            # Auto-detect: find first input[type="file"]
            root = await sess.get_document(depth=0)
            root_id = root.get("nodeId", 0)
            if root_id:
                node_ids = await sess.query_selector_all(root_id, 'input[type="file"]')
                if node_ids:
                    node_id = node_ids[0]
            if not node_id:
                return _err(
                    'No <input type="file"> found on the page. '
                    "Provide a 'selector' or 'ref' to target a specific element."
                )

        # -- Set files via CDP --
        raw_cdp = sess._cdp
        await raw_cdp.send(
            "DOM.setFileInputFiles",
            {"nodeId": node_id, "files": resolved_paths},
        )

        return _ok(f"Uploaded {len(resolved_paths)} file(s) to node {node_id}: {resolved_paths}")

    except Exception as exc:
        logger.warning("file_upload failed: %s", exc)
        return _err(str(exc))


# ---------------------------------------------------------------------------
# Main dispatcher
# ---------------------------------------------------------------------------


async def devtools_control_impl(
    action: str,
    page_id: str = "default",
    selector: str = "",
    ref: str = "",
    code: str = "",
    text: str = "",
    url: str = "",
    x: float | None = None,
    y: float | None = None,
    max_depth: int = 8,
    interactive_only: bool = False,
    delta_x: float = 0,
    delta_y: float = 300,
    screenshot_format: str = "png",
    screenshot_quality: int = 85,
    await_promise: bool = False,
    paths_json: str = "",
    conversation_id: str = "",
    channel_source: str = "dashboard",
) -> LightClawToolResult:
    """Dispatch a devtools_control action.

    Args:
        action: Action to perform (see module docstring for full list).
        page_id: Target page identifier (default resolves to current active page).
        selector: CSS selector for element targeting.
        ref: Element reference from dom_tree output (e.g. ``"button_42"``).
        code: JavaScript to evaluate (eval_js action).
        text: Text to type (type action).
        url: URL for navigate action.
        x: X coordinate for click/scroll (browser logical pixels).
        y: Y coordinate for click/scroll (browser logical pixels).
        max_depth: DOM tree traversal depth (dom_tree action).
        interactive_only: Show only interactive elements in dom_tree.
        delta_x: Horizontal scroll amount in pixels.
        delta_y: Vertical scroll amount in pixels.
        screenshot_format: ``"png"`` or ``"jpeg"`` (screenshot action).
        screenshot_quality: JPEG quality 1–100 (screenshot action).
        await_promise: Await a Promise result (eval_js action).
        paths_json: JSON array of file paths for file_upload action.
        conversation_id: Conversation/chat UUID (injected by builtins wrapper).
        channel_source: Channel origin, e.g. ``"dashboard"`` (injected by builtins wrapper).

    Returns:
        :class:`LightClawToolResult` with text and optional image blocks.
    """
    action = (action or "").strip().lower()

    logger.info(
        "devtools_control_impl: action=%s, conversation_id=%s, page_id=%s",
        action,
        conversation_id[:12] if conversation_id else "(empty)",
        page_id,
    )

    # --- Activate the correct session for this conversation ---
    # This switches _active_session and current_page_id BEFORE any action
    # runs, so screenshot / navigate / etc. target the right tab.
    # If no session exists yet but the browser is running, this will
    # auto-create a new tab + session for this conversation.
    if conversation_id:
        await _activate_conversation_session(conversation_id, channel_source)

    # Shorthand for conversation_id used by most actions
    cid = conversation_id

    dispatch: dict[str, Any] = {
        "start": lambda: _action_start(conversation_id=cid, channel_source=channel_source),
        "dom_tree": lambda: _action_dom_tree(page_id, cid, max_depth=max_depth, interactive_only=interactive_only),
        "eval_js": lambda: _action_eval_js(page_id, cid, code, await_promise=await_promise),
        "query_nodes": lambda: _action_query_nodes(page_id, cid, selector),
        "screenshot": lambda: _action_screenshot(page_id, cid, format=screenshot_format, quality=screenshot_quality),
        "click": lambda: _action_click(page_id, cid, selector=selector, ref=ref, x=x, y=y),
        "type": lambda: _action_type(page_id, cid, text, selector=selector),
        "navigate": lambda: _action_navigate(page_id, cid, url),
        "go_back": lambda: _action_go_back(page_id, cid),
        "go_forward": lambda: _action_go_forward(page_id, cid),
        "reload": lambda: _action_reload(page_id, cid),
        "scroll": lambda: _action_scroll(page_id, cid, x=x or 0, y=y or 0, delta_x=delta_x, delta_y=delta_y),
        "tabs": lambda: _action_tabs(cid),
        "get_metrics": lambda: _action_get_metrics(page_id, cid),
        "close": lambda: _action_close(cid),
        "stop": lambda: _action_stop(),
        "file_upload": lambda: _action_file_upload(page_id, cid, paths_json, selector=selector, ref=ref),
    }

    handler = dispatch.get(action)
    if handler is None:
        valid = ", ".join(sorted(dispatch))
        return _err(f"Unknown action {action!r}. Valid actions: {valid}")

    return await handler()
