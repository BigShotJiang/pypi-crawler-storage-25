"""Native Chrome process launcher and CDP connection manager.

Manages the lifecycle of Chrome processes launched via ``subprocess.Popen``
with ``--user-data-dir`` and ``--remote-debugging-port``, and provides
Playwright CDP attachment via ``chromium.connect_over_cdp()``.

Ported from openclaw/src/browser/chrome.ts (launchOpenClawChrome,
stopOpenClawChrome) and pw-session.ts (connectBrowser).
"""

from __future__ import annotations

import asyncio
import contextlib
import logging
import os
import signal
import subprocess
import time
from dataclasses import dataclass
from typing import Any

import httpx

from lightclaw.agent.tools.browser.environment import (
    build_chrome_flags,
    detect_display_environment,
    find_chrome_executable,
)
from lightclaw.agent.tools.browser.profiles import BrowserProfile

logger = logging.getLogger(__name__)

# ---------------------------------------------------------------------------
# Data types
# ---------------------------------------------------------------------------


@dataclass
class RunningChrome:
    """Represents a live Chrome process managed by the launcher."""

    profile_name: str
    process: subprocess.Popen[bytes] | None = None
    cdp_port: int = 9222
    pid: int | None = None
    xvfb_process: subprocess.Popen[bytes] | None = None
    # True when this handle was obtained by attaching to the user's
    # already-running Chrome (e.g. via --remote-debugging-port=9222).
    # When attached, stop_chrome() MUST NOT kill the Chrome process —
    # only disconnect the CDP connection.
    attached: bool = False


@dataclass
class CDPConnection:
    """Holds the Playwright objects attached to a Chrome via CDP."""

    playwright: Any = None  # playwright async_api Playwright instance
    browser: Any = None  # playwright Browser
    context: Any = None  # playwright BrowserContext


# ---------------------------------------------------------------------------
# Chrome process manager (singleton)
# ---------------------------------------------------------------------------


class ChromeProcessManager:
    """Manage Chrome process lifecycles across profiles.

    One Chrome process per profile; tracks ``{profile_name: RunningChrome}``.
    """

    def __init__(self) -> None:
        self._processes: dict[str, RunningChrome] = {}

    # -- launch -------------------------------------------------------------

    async def launch_chrome(
        self,
        profile: BrowserProfile,
        *,
        headed: bool = False,
        enable_xvfb: bool = False,
        explicit_executable: str | None = None,
    ) -> RunningChrome:
        """Launch a native Chrome process for *profile*.

        Args:
            profile: The browser profile configuration.
            headed: Whether to launch a visible window.
            enable_xvfb: Start Xvfb if on headless-server and *headed* is
                requested.
            explicit_executable: Override auto-detected executable path.

        Returns:
            A :class:`RunningChrome` handle.

        Raises:
            RuntimeError: If Chrome cannot be started.
        """
        # Already running (tracked by this manager)?
        existing = self._processes.get(profile.name)
        if existing and existing.process and existing.process.poll() is None:
            logger.info(
                "Chrome for profile '%s' already running (pid=%s)",
                profile.name,
                existing.pid,
            )
            return existing

        # Check for an orphaned Chrome process from a previous app run that
        # is still listening on the same CDP port.  If found, adopt it
        # instead of launching a new one (which would fail with exit code 21
        # due to port conflict).
        # Exception: if a graphical desktop is available and the existing
        # browser is headless, do NOT adopt — the caller already killed it
        # (or should have) and we need to launch a headed instance.
        if await _wait_for_cdp(profile.cdp_port, timeout=1.0):
            _should_adopt = True
            try:
                async with httpx.AsyncClient(timeout=2.0) as _probe:
                    _r = await _probe.get(f"http://127.0.0.1:{profile.cdp_port}/json/version")
                    if _r.status_code == 200:
                        _ua = _r.json().get("User-Agent", "")
                        _is_headless = "HeadlessChrome" in _ua or "headless" in _ua.lower()
                        if _is_headless and detect_display_environment() == "desktop":
                            # Headless browser on a desktop — do not adopt; the caller
                            # should have killed it, but it may still be shutting down.
                            _should_adopt = False
                            logger.warning(
                                "Port %d has a headless browser but desktop is available "
                                "— refusing to adopt; will launch a fresh headed instance",
                                profile.cdp_port,
                            )
            except Exception:
                pass

            if _should_adopt:
                logger.info(
                    "Found existing Chrome on port %d — adopting orphaned process for profile '%s'",
                    profile.cdp_port,
                    profile.name,
                )
                adopted = RunningChrome(
                    profile_name=profile.name,
                    process=None,  # we don't own the process handle
                    cdp_port=profile.cdp_port,
                    pid=None,
                )
                self._processes[profile.name] = adopted
                return adopted

        env = detect_display_environment()
        exe = find_chrome_executable(explicit_executable)
        if not exe:
            raise RuntimeError(
                "No Chrome/Chromium executable found. Install Google Chrome or set an explicit path.",
            )

        xvfb_proc: subprocess.Popen[bytes] | None = None

        # Handle headed request on headless-server
        if headed and env == "headless-server":
            if enable_xvfb:
                xvfb_proc = _start_xvfb()
                if xvfb_proc:
                    logger.info("Started Xvfb for headed mode on headless-server")
                    # Chrome will use the virtual display
                else:
                    logger.warning(
                        "Xvfb start failed; falling back to headless mode",
                    )
                    headed = False
            else:
                logger.warning(
                    "headed=True requested on headless-server without Xvfb — auto-falling back to headless mode",
                )
                headed = False

        headless = not headed
        flags = build_chrome_flags(
            headless=headless,
            environment=env,
            cdp_port=profile.cdp_port,
            user_data_dir=profile.user_data_dir,
        )

        cmd = [exe.path, *flags]
        logger.info(
            "Launching Chrome: %s (port=%d, headless=%s)",
            exe.path,
            profile.cdp_port,
            headless,
        )

        try:
            proc = subprocess.Popen(
                cmd,
                stdout=subprocess.DEVNULL,
                stderr=subprocess.PIPE,
                preexec_fn=os.setpgrp if os.name != "nt" else None,
            )
        except FileNotFoundError as exc:
            raise RuntimeError(
                f"Failed to start Chrome at {exe.path}: {exc}",
            ) from exc

        running = RunningChrome(
            profile_name=profile.name,
            process=proc,
            cdp_port=profile.cdp_port,
            pid=proc.pid,
            xvfb_process=xvfb_proc,
        )
        self._processes[profile.name] = running

        # Wait for CDP to become ready
        ready = await _wait_for_cdp(profile.cdp_port, timeout=15.0)
        if not ready:
            # Check if process died
            if proc.poll() is not None:
                stderr_output = ""
                with contextlib.suppress(Exception):
                    stderr_output = (proc.stderr.read() or b"").decode(
                        errors="replace",
                    )[:500]
                self._processes.pop(profile.name, None)
                raise RuntimeError(
                    f"Chrome exited immediately (code={proc.returncode}). stderr: {stderr_output}",
                )
            self._processes.pop(profile.name, None)
            _kill_process(proc)
            raise RuntimeError(
                f"Chrome CDP not ready on port {profile.cdp_port} after 15s",
            )

        logger.info(
            "Chrome ready for profile '%s' (pid=%d, port=%d)",
            profile.name,
            proc.pid,
            profile.cdp_port,
        )
        return running

    # -- stop ---------------------------------------------------------------

    async def stop_chrome(self, profile_name: str) -> None:
        """Stop the Chrome process for *profile_name*.

        When the process was obtained via attach mode (``attached=True``),
        we only remove our tracking handle — the user's Chrome is left
        running untouched.
        """
        running = self._processes.pop(profile_name, None)
        if not running:
            return

        if running.attached:
            logger.info(
                "Detaching from user's Chrome on port %d for profile '%s' (not killing)",
                running.cdp_port,
                profile_name,
            )
            return

        if running.process and running.process.poll() is None:
            _kill_process(running.process)
            logger.info("Stopped Chrome for profile '%s'", profile_name)
        elif running.process is None and running.cdp_port:
            # Adopted orphan process — we don't have the Popen handle,
            # so find and kill by CDP port.
            _kill_process_by_port(running.cdp_port)
            logger.info(
                "Stopped adopted Chrome on port %d for profile '%s'",
                running.cdp_port,
                profile_name,
            )
        if running.xvfb_process and running.xvfb_process.poll() is None:
            _kill_process(running.xvfb_process)
            logger.info("Stopped Xvfb for profile '%s'", profile_name)

    # -- health check -------------------------------------------------------

    def is_running(self, profile_name: str) -> bool:
        """Check if Chrome process for *profile_name* is alive."""
        running = self._processes.get(profile_name)
        if not running or not running.process:
            return False
        return running.process.poll() is None

    def get_running(self, profile_name: str) -> RunningChrome | None:
        return self._processes.get(profile_name)

    # -- cleanup ------------------------------------------------------------

    async def stop_all(self) -> None:
        """Stop all managed Chrome processes."""
        names = list(self._processes.keys())
        for name in names:
            await self.stop_chrome(name)


# ---------------------------------------------------------------------------
# CDP connection via Playwright
# ---------------------------------------------------------------------------


async def connect_via_cdp(cdp_port: int) -> CDPConnection:
    """Attach to a running Chrome via CDP using Playwright.

    Args:
        cdp_port: The Chrome DevTools Protocol port.

    Returns:
        A :class:`CDPConnection` with ``playwright``, ``browser``, and
        ``context`` objects.
    """
    from playwright.async_api import async_playwright

    pw = await async_playwright().start()
    endpoint = f"http://127.0.0.1:{cdp_port}"
    try:
        browser = await pw.chromium.connect_over_cdp(endpoint)
    except Exception as exc:
        err_msg = str(exc)
        if "setDownloadBehavior" in err_msg or "context management" in err_msg:
            # Chrome 147+ headed mode does not support Browser.setDownloadBehavior.
            # Fallback: launch a new browser context that connects via the CDP
            # page endpoints instead of the browser endpoint.
            logger.info(
                "connect_over_cdp failed (headed Chrome, setDownloadBehavior unsupported). "
                "Falling back to page-level CDP connection on port %d.",
                cdp_port,
            )
            await pw.stop()
            return await _connect_via_page_cdp(cdp_port)
        # Re-raise other errors
        await pw.stop()
        raise

    # Use first existing context or create a new one.
    # When Chrome is started with --start-maximized, set no_viewport=True
    # so Playwright does not override the maximized window with a fixed
    # viewport size.
    contexts = browser.contexts
    if contexts:
        context = contexts[0]
        # Playwright's connect_over_cdp applies a default viewport override
        # to existing contexts (typically 1280x720).  For headed Chrome with
        # --start-maximized we must clear this override so pages fill the
        # entire maximized window.
        if detect_display_environment() == "desktop":
            for page in context.pages:
                try:
                    cdp = await context.new_cdp_session(page)
                    await cdp.send("Emulation.clearDeviceMetricsOverride")
                    await cdp.detach()
                except Exception as exc:
                    logger.debug("Failed to clear viewport override for page: %s", exc)
    else:
        context = await browser.new_context(no_viewport=True)

    return CDPConnection(
        playwright=pw,
        browser=browser,
        context=context,
    )


async def _connect_via_page_cdp(cdp_port: int) -> CDPConnection:
    """Fallback CDP connection for headed Chrome (Chrome 147+).

    When ``connect_over_cdp`` fails because the headed Chrome doesn't
    support ``Browser.setDownloadBehavior``, there is no known workaround
    with Playwright 1.58+.  We raise a clear error telling the caller to
    try the user-profile-sharing approach instead.
    """
    raise RuntimeError(
        f"Cannot attach Playwright to headed Chrome on port {cdp_port}. "
        "Chrome 147+ in headed mode does not support Browser.setDownloadBehavior "
        "(required by Playwright connect_over_cdp). "
        "Workaround: LightClaw will launch its own Chrome using your profile "
        "directory so cookies and login sessions are shared."
    )


async def disconnect_cdp(conn: CDPConnection) -> None:
    """Gracefully disconnect a CDP connection (keep Chrome running).

    For persistent-context Playwright sessions (``.browser`` is ``None``),
    closes the context directly — this flushes cookies to disk.
    """
    try:
        if conn.browser:
            await conn.browser.close()
        elif conn.context:
            # Persistent context: closing the context shuts down the browser
            # and flushes state (cookies, localStorage) to user-data-dir.
            await conn.context.close()
    except Exception as exc:
        logger.debug("Error closing CDP browser/context: %s", exc)
    try:
        if conn.playwright:
            await conn.playwright.stop()
    except Exception as exc:
        logger.debug("Error stopping Playwright: %s", exc)


# ---------------------------------------------------------------------------
# Fallback: Playwright-managed Chromium
# ---------------------------------------------------------------------------

# Injected into every new page before site JS runs.
# Grants the ``local-network-access`` permission so that sites relying on
# ``navigator.permissions.query({name: "local-network-access"})`` (e.g.
# cloud.tencent.com WeChat login) work without manual browser settings.
_LOCAL_NETWORK_GRANT_SCRIPT = """
if (navigator.permissions && navigator.permissions.query) {
    const _origQuery = navigator.permissions.query.bind(navigator.permissions);
    navigator.permissions.query = function(desc) {
        if (desc && desc.name === 'local-network-access') {
            return Promise.resolve({state: 'granted', onchange: null});
        }
        return _origQuery(desc);
    };
}
"""

# Chrome flags required for stable operation in containers.
# --disable-dev-shm-usage prevents renderer crashes when /dev/shm is limited
# to 64 MB (the Docker default), which causes Chromium to exhaust shared memory
# on heavy pages.
_CONTAINER_SAFE_ARGS = [
    "--disable-web-security",
    "--allow-file-access-from-files",
    "--disable-dev-shm-usage",
    "--no-sandbox",
    "--disable-gpu",
    "--disable-software-rasterizer",
]


def _find_full_chromium_executable() -> str | None:
    """Return the path to the full Chromium binary (not headless-shell).

    The full Chromium binary supports loading extensions via ``--load-extension``.
    ``chrome-headless-shell`` does NOT support extensions regardless of flags.

    Searches the Playwright-managed download directory for the ``chromium-*``
    variant (not ``chromium_headless_shell-*``).
    """
    import platform as _platform

    try:
        from lightclaw.agent.tools.browser.playwright_install import (
            _resolve_playwright_downloads_dir,
        )

        downloads_dir = _resolve_playwright_downloads_dir()
        if downloads_dir is None or not downloads_dir.is_dir():
            return None

        exe_name = "chrome.exe" if _platform.system() == "Windows" else "chrome"
        for candidate in downloads_dir.glob("chromium-*/chrome-*/"):
            exe = candidate / exe_name
            if exe.exists() and os.access(str(exe), os.X_OK):
                return str(exe)
    except Exception:
        pass
    return None


async def launch_playwright_fallback(
    headless: bool = True,
    user_data_dir: str = "",
) -> CDPConnection:
    """Launch Playwright's bundled Chromium as a fallback.

    When *user_data_dir* is provided, uses ``launch_persistent_context``
    so that cookies, localStorage, and login state survive across
    browser restarts — matching the native Chrome behaviour.

    Automatically discovers and loads Chrome extensions installed under
    ``~/.lightclaw/extensions/`` (e.g. the opencli Browser Bridge).

    When extensions are present, uses the full Chromium binary instead of
    ``chrome-headless-shell``, because headless-shell does not support
    loading extensions regardless of flags.
    """
    from playwright.async_api import async_playwright

    from lightclaw.agent.tools.browser.environment import discover_extensions

    pw = await async_playwright().start()

    # Build args: container-safe flags + auto-discovered extensions
    args = list(_CONTAINER_SAFE_ARGS)
    ext_dirs = discover_extensions()
    if ext_dirs:
        args.append(f"--load-extension={','.join(ext_dirs)}")
        # Also whitelist these extensions so Chrome doesn't block them
        args.append(f"--disable-extensions-except={','.join(ext_dirs)}")

    # chrome-headless-shell does not support extensions. When extensions are
    # present, resolve the full Chromium binary explicitly so Playwright
    # uses it instead of the headless-shell variant.
    executable_path: str | None = None
    if ext_dirs:
        executable_path = _find_full_chromium_executable()
        if executable_path:
            logger.info(
                "Extensions detected — using full Chromium binary for extension support: %s",
                executable_path,
            )
        else:
            logger.warning(
                "Extensions detected but full Chromium binary not found; "
                "extensions may not load (chrome-headless-shell does not support them)."
            )

    # When running headed, start maximized and let Playwright follow the
    # window size rather than constraining to a fixed viewport.
    viewport_kwargs: dict[str, Any] = {}
    if not headless:
        args.append("--start-maximized")
        viewport_kwargs["no_viewport"] = True

    if user_data_dir:
        logger.info(
            "No native Chrome found — using Playwright Chromium with persistent profile: %s",
            user_data_dir,
        )
        # When loading extensions, Playwright's default --disable-extensions arg
        # would override --load-extension and prevent extensions from loading.
        # Explicitly remove it so the extension is actually loaded.
        ignore_default_args = ["--disable-extensions"] if ext_dirs else []
        context = await pw.chromium.launch_persistent_context(
            user_data_dir,
            headless=headless,
            args=args,
            executable_path=executable_path,
            ignore_default_args=ignore_default_args,
            **viewport_kwargs,
        )
        await context.add_init_script(_LOCAL_NETWORK_GRANT_SCRIPT)
        # launch_persistent_context returns a BrowserContext directly;
        # its .browser attribute may be None, but the context is fully
        # functional for page creation and CDP access.
        return CDPConnection(
            playwright=pw,
            browser=context.browser,
            context=context,
        )

    logger.warning(
        "No native Chrome found — using Playwright Chromium (ephemeral, no persistent state).",
    )
    ignore_default_args = ["--disable-extensions"] if ext_dirs else []
    browser = await pw.chromium.launch(
        headless=headless,
        args=args,
        executable_path=executable_path,
        ignore_default_args=ignore_default_args,
    )
    context = await browser.new_context(**viewport_kwargs)
    await context.add_init_script(_LOCAL_NETWORK_GRANT_SCRIPT)
    return CDPConnection(
        playwright=pw,
        browser=browser,
        context=context,
    )


# ---------------------------------------------------------------------------
# Internal helpers
# ---------------------------------------------------------------------------


def _kill_process(proc: subprocess.Popen[bytes]) -> None:
    """Gracefully kill a process (SIGTERM then SIGKILL)."""
    try:
        if os.name != "nt":
            os.killpg(os.getpgid(proc.pid), signal.SIGTERM)
        else:
            proc.terminate()
        try:
            proc.wait(timeout=5)
        except subprocess.TimeoutExpired:
            if os.name != "nt":
                os.killpg(os.getpgid(proc.pid), signal.SIGKILL)
            else:
                proc.kill()
            proc.wait(timeout=3)
    except (ProcessLookupError, OSError):
        pass


def _kill_process_by_port(port: int) -> None:
    """Find and kill the process listening on *port*.

    Used to clean up orphaned Chrome processes that were adopted without
    a ``subprocess.Popen`` handle.
    """
    import shutil as _shutil

    lsof = _shutil.which("lsof")
    if not lsof:
        logger.debug("lsof not available; cannot kill process on port %d", port)
        return

    try:
        result = subprocess.run(
            [lsof, "-ti", f":{port}"],
            capture_output=True,
            text=True,
            timeout=5,
        )
        pids = result.stdout.strip().split()
        for pid_str in pids:
            with contextlib.suppress(ValueError, ProcessLookupError, OSError):
                pid = int(pid_str)
                os.kill(pid, signal.SIGTERM)
                logger.debug("Sent SIGTERM to orphaned Chrome pid=%d on port %d", pid, port)
    except (subprocess.TimeoutExpired, FileNotFoundError):
        logger.debug("Failed to find/kill process on port %d", port)


async def _wait_for_cdp(port: int, timeout: float = 15.0) -> bool:
    """Poll ``http://127.0.0.1:{port}/json/version`` until it responds."""
    url = f"http://127.0.0.1:{port}/json/version"
    deadline = time.monotonic() + timeout
    async with httpx.AsyncClient() as client:
        while time.monotonic() < deadline:
            try:
                resp = await client.get(url, timeout=2.0)
                if resp.status_code == 200:
                    return True
            except (httpx.ConnectError, httpx.ReadTimeout, httpx.ConnectTimeout):
                pass
            await asyncio.sleep(0.5)
    return False


def _start_xvfb(display: str = ":99") -> subprocess.Popen[bytes] | None:
    """Start an Xvfb virtual display server.

    Returns the Popen handle, or ``None`` if Xvfb is not available.
    """
    import shutil as _shutil

    xvfb_path = _shutil.which("Xvfb")
    if not xvfb_path:
        logger.warning("Xvfb not found in PATH")
        return None

    try:
        proc = subprocess.Popen(
            [
                xvfb_path,
                display,
                "-screen",
                "0",
                "1920x1080x24",
                "-ac",
            ],
            stdout=subprocess.DEVNULL,
            stderr=subprocess.DEVNULL,
        )
        # Set DISPLAY for child processes
        os.environ["DISPLAY"] = display
        # Brief pause for Xvfb to initialise
        time.sleep(0.5)
        if proc.poll() is not None:
            logger.warning("Xvfb exited immediately (code=%s)", proc.returncode)
            return None
        return proc
    except FileNotFoundError:
        logger.warning("Xvfb binary not found")
        return None
