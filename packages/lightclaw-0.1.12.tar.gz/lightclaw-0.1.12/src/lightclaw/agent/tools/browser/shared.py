"""Process-level singletons for browser infrastructure.

All modules (``browser_control``, ``browser.py`` REST router,
``browser_stream.py`` WebSocket router) **must** obtain
:class:`ChromeProcessManager`, :class:`SessionManager`, and
:class:`ProfileManager` instances through this module so that a single
Chrome process is shared across the entire application.
"""

from __future__ import annotations

import asyncio
import contextlib
import logging
import os
import pathlib
import signal as _signal
from typing import Any

import httpx

from lightclaw.agent.tools.browser.chrome_launcher import (
    CDPConnection,
    ChromeProcessManager,
    RunningChrome,
    connect_via_cdp,
    launch_playwright_fallback,
)
from lightclaw.agent.tools.browser.environment import check_system_dependencies, find_chrome_executable
from lightclaw.agent.tools.browser.profiles import DEFAULT_PROFILE_NAME, BrowserProfile, ProfileManager
from lightclaw.agent.tools.browser.session import SessionManager

logger = logging.getLogger(__name__)

# ---------------------------------------------------------------------------
# Process-level singletons
# ---------------------------------------------------------------------------

_profile_manager: ProfileManager | None = None
_chrome_manager: ChromeProcessManager | None = None
_session_manager: SessionManager | None = None

# Lock to serialise browser launch/teardown across concurrent callers
_browser_lock = asyncio.Lock()

# Cached Playwright-fallback connection.  Unlike native Chrome (which can
# accept multiple independent CDP connections), a Playwright-managed browser
# has no CDP port — so we must return the *same* CDPConnection each time to
# ensure Agent pages and BrowserStream share one browser instance.
_playwright_fallback_conn: CDPConnection | None = None

# Callbacks invoked when Chrome terminates unexpectedly.
# Signature: async def callback(profile_name: str) -> None
_chrome_exit_callbacks: list[Any] = []

# Whether one-time startup checks (fonts, system deps) have been performed
_startup_checks_done: bool = False


def get_profile_manager() -> ProfileManager:
    """Return the global :class:`ProfileManager` (lazy-created)."""
    global _profile_manager
    if _profile_manager is None:
        _profile_manager = ProfileManager()
    return _profile_manager


def get_chrome_manager() -> ChromeProcessManager:
    """Return the global :class:`ChromeProcessManager` (lazy-created)."""
    global _chrome_manager
    if _chrome_manager is None:
        _chrome_manager = ChromeProcessManager()
    return _chrome_manager


def get_session_manager() -> SessionManager:
    """Return the global :class:`SessionManager` (lazy-created)."""
    global _session_manager
    if _session_manager is None:
        _session_manager = SessionManager()
    return _session_manager


# ---------------------------------------------------------------------------
# One-time startup checks (fonts, system deps)
# ---------------------------------------------------------------------------


def _run_startup_checks() -> None:
    """Perform one-time system dependency checks on the first browser launch.

    Checks for missing shared libraries and CJK fonts.  If CJK fonts are
    absent, attempts automatic installation via the same logic used by the
    Playwright installer.  Results are logged as warnings so that operators
    can fix the environment if needed.

    This function is idempotent — the actual work runs only once per
    process lifetime, controlled by the ``_startup_checks_done`` flag.
    """
    global _startup_checks_done
    if _startup_checks_done:
        return
    _startup_checks_done = True

    dep_result = check_system_dependencies()
    if dep_result.ok:
        logger.debug("System dependency check passed (including CJK fonts)")
        return

    # Log missing packages as warnings
    logger.warning(
        "Missing system dependencies: %s. Suggested fix: %s",
        ", ".join(dep_result.missing),
        dep_result.install_command,
    )

    # Attempt automatic CJK font installation if fonts are among the missing
    _cjk_font_indicators = {
        "fonts-noto-cjk",
        "google-noto-sans-cjk-ttc-fonts",
        "noto-fonts-cjk",
        "noto-sans-cjk-fonts",
    }
    missing_set = set(dep_result.missing)
    if missing_set & _cjk_font_indicators:
        logger.info("CJK fonts missing — attempting automatic installation...")
        try:
            from lightclaw.agent.tools.browser.playwright_install import _install_cjk_fonts

            _install_cjk_fonts()
        except Exception as exc:
            logger.warning("Automatic CJK font installation failed: %s", exc)


# ---------------------------------------------------------------------------
# Unified browser acquisition
# ---------------------------------------------------------------------------


async def get_or_create_browser(
    profile_name: str = DEFAULT_PROFILE_NAME,
    *,
    headless: bool = True,
) -> tuple[RunningChrome | None, CDPConnection, BrowserProfile]:
    """Ensure a Chrome process is running for *profile_name* and return a CDP connection.

    If Chrome is already running for the requested profile the existing
    process is reused; otherwise a new one is launched via
    :class:`ChromeProcessManager`.

    Returns:
        A 3-tuple ``(running_chrome, cdp_connection, browser_profile)``.
        ``running_chrome`` may be ``None`` when the Playwright fallback is
        used (no native Chrome found).

    Raises:
        RuntimeError: If the browser cannot be started.
    """
    async with _browser_lock:
        # One-time startup check for system deps / CJK fonts
        _run_startup_checks()

        pm = get_profile_manager()
        cm = get_chrome_manager()

        profile = pm.get_profile(profile_name)
        if not profile:
            profile = pm.create_profile(profile_name)

        # Already running? Just create a new CDP connection.
        if cm.is_running(profile_name):
            running = cm.get_running(profile_name)
            assert running is not None
            cdp_conn = await connect_via_cdp(running.cdp_port)
            pm.touch_used(profile_name)
            return running, cdp_conn, profile

        # Try native Chrome launch
        exe = find_chrome_executable()
        if exe:
            try:
                running = await cm.launch_chrome(profile, headed=not headless)
                cdp_conn = await connect_via_cdp(running.cdp_port)
                pm.touch_used(profile_name)
                start_chrome_exit_monitor()
                return running, cdp_conn, profile
            except RuntimeError as exc:
                # Native Chrome found but failed to start (e.g. snap chromium
                # refuses to run as root, or missing system libraries).  Log the
                # error and fall through to the Playwright-managed Chromium fallback
                # so the browser remains functional.
                logger.warning(
                    "Native Chrome launch failed (%s); falling back to Playwright Chromium",
                    exc,
                )

        # Fallback: Playwright-managed Chromium (no persistent state).
        # Cache the connection so that all callers (Agent, BrowserStream)
        # share the same browser instance — otherwise each call would
        # launch a separate Chromium with zero shared pages/cookies.
        global _playwright_fallback_conn
        if _playwright_fallback_conn is not None:
            conn = _playwright_fallback_conn
            # Check if the existing connection is still alive.
            # With launch_persistent_context, .browser may be None —
            # fall back to checking whether the context has pages.
            still_alive = False
            if conn.browser and conn.browser.is_connected():
                still_alive = True
            elif conn.context:
                try:
                    # If the context can still list pages it's alive
                    _ = conn.context.pages
                    still_alive = True
                except Exception:
                    pass

            if still_alive:
                pm.touch_used(profile_name)
                return None, conn, profile

        cdp_conn = await launch_playwright_fallback(
            headless=headless,
            user_data_dir=profile.user_data_dir,
        )
        _playwright_fallback_conn = cdp_conn
        pm.touch_used(profile_name)
        start_chrome_exit_monitor()
        return None, cdp_conn, profile


# ---------------------------------------------------------------------------
# Chrome exit monitoring
# ---------------------------------------------------------------------------


def register_chrome_exit_callback(callback: Any) -> None:
    """Register *callback* to be called when Chrome terminates unexpectedly.

    The callback signature should be
    ``async def callback(profile_name: str) -> None``.
    """
    _chrome_exit_callbacks.append(callback)


def unregister_chrome_exit_callback(callback: Any) -> None:
    """Remove a previously registered exit callback."""
    with contextlib.suppress(ValueError):
        _chrome_exit_callbacks.remove(callback)


async def _notify_chrome_exit(profile_name: str) -> None:
    """Invoke all registered exit callbacks and mark sessions as failed."""
    # Mark all sessions as FAILED so frontends are notified via WS push
    sm = get_session_manager()
    sm.mark_all_sessions_failed(reason=f"chrome_exit:{profile_name}")

    for cb in _chrome_exit_callbacks:
        try:
            await cb(profile_name)
        except Exception as exc:
            logger.warning("Chrome exit callback error: %s", exc)


_monitor_task: asyncio.Task[None] | None = None


async def _chrome_exit_monitor_loop() -> None:
    """Background task that polls all managed Chrome processes.

    When a process terminates unexpectedly, notifies registered callbacks
    so that SSE/WebSocket consumers can inform the frontend.
    """
    cm = get_chrome_manager()
    while True:
        await asyncio.sleep(2.0)
        for profile_name in list(cm._processes.keys()):
            running = cm._processes.get(profile_name)
            if not running:
                continue

            exited = False
            if running.process:
                # Managed process — check via poll()
                ret = running.process.poll()
                if ret is not None:
                    exited = True
                    logger.warning(
                        "Chrome process for profile '%s' exited unexpectedly (code=%s)",
                        profile_name,
                        ret,
                    )
            elif running.cdp_port:
                # Adopted orphan process — check via CDP port probe
                try:
                    async with httpx.AsyncClient() as client:
                        resp = await client.get(
                            f"http://127.0.0.1:{running.cdp_port}/json/version",
                            timeout=2.0,
                        )
                        if resp.status_code != 200:
                            exited = True
                except (httpx.ConnectError, httpx.ReadTimeout, httpx.ConnectTimeout):
                    exited = True

                if exited:
                    logger.warning(
                        "Adopted Chrome on port %d for profile '%s' is no longer reachable",
                        running.cdp_port,
                        profile_name,
                    )

            if exited:
                cm._processes.pop(profile_name, None)
                await _notify_chrome_exit(profile_name)


def start_chrome_exit_monitor() -> None:
    """Start the background Chrome exit monitor if not already running.

    Safe to call multiple times; only one monitor task is created.
    Should be called once during application startup.
    """
    global _monitor_task
    if _monitor_task is not None and not _monitor_task.done():
        return
    try:
        loop = asyncio.get_running_loop()
        _monitor_task = loop.create_task(_chrome_exit_monitor_loop(), name="chrome-exit-monitor")
        logger.debug("Chrome exit monitor started")
    except RuntimeError:
        logger.debug("Cannot start exit monitor — no running event loop")


# ---------------------------------------------------------------------------
# Agent state bridge — tab synchronisation
# ---------------------------------------------------------------------------
# The Agent's ``_state`` dict lives in ``browser_control.py``.  Rather than
# importing it directly (which would create a circular dependency), we
# expose accessor functions that ``browser_control`` registers at import
# time.  ``BrowserStreamSession`` can then call these to read / mutate the
# Agent's page list.

_agent_state_getter: Any = None  # Callable[[], dict[str, Any]]
_enhancement_runtime_getter: Any = None  # Callable[[], Any]


def register_agent_state(getter: Any) -> None:
    """Register the Agent's global ``_state`` accessor.

    Called once by ``browser_control`` at module load.
    ``getter`` should be a callable that returns the ``_state`` dict.
    """
    global _agent_state_getter
    _agent_state_getter = getter


def get_agent_state() -> dict[str, Any] | None:
    """Return the Agent ``_state`` dict, or ``None`` if not registered."""
    if _agent_state_getter is None:
        return None
    try:
        return _agent_state_getter()
    except Exception:
        return None


def clear_playwright_fallback() -> None:
    """Clear the cached Playwright-fallback connection.

    Must be called when the browser is stopped so the next
    ``get_or_create_browser`` call launches a fresh instance.
    """
    global _playwright_fallback_conn
    _playwright_fallback_conn = None


def register_enhancement_runtime(getter: Any) -> None:
    """Register the browser enhancement runtime accessor."""
    global _enhancement_runtime_getter
    _enhancement_runtime_getter = getter


def get_enhancement_runtime() -> Any | None:
    """Return the shared browser enhancement runtime, or ``None``."""
    if _enhancement_runtime_getter is None:
        return None
    try:
        return _enhancement_runtime_getter()
    except Exception:
        return None


# ---------------------------------------------------------------------------
# Native-TCP Chrome launch helpers
# ---------------------------------------------------------------------------


async def ensure_chrome_running(cdp_port: int) -> None:
    """Ensure a Chrome/Chromium process is listening on *cdp_port*.

    Two-step logic:
    1. If port already has a CDP listener → reuse it **unless** it is a
       headless browser and a graphical desktop is now available, in which
       case the headless instance is killed and a headed one is launched.
    2. Otherwise, launch a new browser:
       - System Chrome found → headed mode + wrapper profile (shared cookies).
       - No system Chrome → Playwright Chromium (headless).

    Raises:
        RuntimeError: If Chrome cannot be launched.
    """
    from lightclaw.agent.tools.browser.environment import (
        detect_display_environment,
        prepare_cdp_user_data_dir,
    )

    # Fast path — already up; but check whether it is headless when a desktop
    # is available (e.g. a stale headless instance from a previous run).
    try:
        url = f"http://127.0.0.1:{cdp_port}/json/version"
        async with httpx.AsyncClient(timeout=3.0) as client:
            resp = await client.get(url)
            if resp.status_code == 200:
                env = detect_display_environment()
                if env == "desktop":
                    # Inspect the User-Agent to detect headless mode.
                    try:
                        ua = resp.json().get("User-Agent", "")
                    except Exception:
                        ua = ""
                    is_headless = "HeadlessChrome" in ua or "headless" in ua.lower()
                    if is_headless:
                        # Desktop is available but the running browser is headless —
                        # kill it so we can launch a headed one below.
                        logger.info(
                            "Port %d has a headless browser but desktop is available — restarting in headed mode",
                            cdp_port,
                        )
                        # 1. Kill any process we launched via ChromeProcessManager.
                        cm = get_chrome_manager()
                        for prof_name in list(cm._processes.keys()):
                            running_proc = cm._processes.get(prof_name)
                            if running_proc and running_proc.process:
                                try:
                                    running_proc.process.terminate()
                                    running_proc.process.wait(timeout=3)
                                except Exception:
                                    with contextlib.suppress(Exception):
                                        running_proc.process.kill()
                            cm._processes.pop(prof_name, None)
                        # 2. Clear the Playwright fallback connection so the next
                        #    call will launch a fresh headed browser.
                        clear_playwright_fallback()
                        # 3. Kill every process listening on this port — including
                        #    orphaned Chromium processes not tracked by the manager.
                        #    Use SIGKILL (not SIGTERM) so the port is freed quickly.
                        #    Also attempt to kill by process group to take down
                        #    child renderers that keep the socket alive.
                        _killed_pids: list[int] = []
                        try:
                            import subprocess as _sub

                            out = _sub.check_output(
                                ["fuser", str(cdp_port) + "/tcp"],
                                stderr=_sub.DEVNULL,
                                text=True,
                            ).strip()
                            for pid_str in out.split():
                                with contextlib.suppress(Exception):
                                    pid_int = int(pid_str)
                                    _killed_pids.append(pid_int)
                                    # Try killing the entire process group first
                                    try:
                                        pgid = os.getpgid(pid_int)
                                        os.killpg(pgid, _signal.SIGKILL)
                                    except Exception:
                                        os.kill(pid_int, _signal.SIGKILL)
                        except Exception:
                            pass

                        # Also try to kill all chromium/chrome processes using
                        # the same user-data-dir (covers renderer child processes
                        # that inherit the port but aren't listed by fuser).
                        try:
                            import subprocess as _sub2

                            _pgrep = _sub2.run(
                                ["pgrep", "-f", f"remote-debugging-port={cdp_port}"],
                                capture_output=True,
                                text=True,
                            )
                            for pid_str in _pgrep.stdout.split():
                                with contextlib.suppress(Exception):
                                    pid_int = int(pid_str)
                                    if pid_int not in _killed_pids:
                                        _killed_pids.append(pid_int)
                                    os.kill(pid_int, _signal.SIGKILL)
                        except Exception:
                            pass

                        # Wait until the port is actually free (up to 8 s).
                        _port_freed = False
                        for _attempt in range(16):
                            await asyncio.sleep(0.5)
                            try:
                                async with httpx.AsyncClient(timeout=1.0) as _probe:
                                    _r = await _probe.get(f"http://127.0.0.1:{cdp_port}/json/version")
                                    if _r.status_code != 200:
                                        _port_freed = True
                                        break
                            except Exception:
                                _port_freed = True
                                break
                        if not _port_freed:
                            logger.warning(
                                "Port %d still occupied after killing stale browser — launch may fail",
                                cdp_port,
                            )
                        # Fall through to re-launch below
                    else:
                        logger.info("Chrome already running (headed) on port %d", cdp_port)
                        return
                else:
                    logger.info("Chrome already running on port %d", cdp_port)
                    return
    except Exception:
        pass

    logger.info("No browser on port %d — launching...", cdp_port)

    from lightclaw.agent.tools.browser.chrome_launcher import _find_full_chromium_executable

    pm = get_profile_manager()
    cm = get_chrome_manager()
    profile = pm.get_profile("default")
    if not profile:
        profile = pm.create_profile("default")

    # Step 1: Choose browser — system Chrome or Playwright Chromium
    exe = find_chrome_executable()
    explicit_path: str | None = None
    use_headed = False

    if exe:
        env = detect_display_environment()
        if env == "desktop":
            use_headed = True
        cdp_data_dir = prepare_cdp_user_data_dir()
        profile.user_data_dir = cdp_data_dir
        logger.info(
            "Using system Chrome (headed=%s, profile=%s)",
            use_headed,
            cdp_data_dir,
        )
    else:
        explicit_path = _find_full_chromium_executable()
        if not explicit_path:
            raise RuntimeError("No Chrome/Chromium found. Install Google Chrome or run 'playwright install chromium'.")
        # Use headed mode for Playwright Chromium too when a graphical
        # desktop is available — the user wants to see the browser.
        env = detect_display_environment()
        if env == "desktop":
            use_headed = True
        logger.info("Using Playwright Chromium (headed=%s): %s", use_headed, explicit_path)

    # Override profile cdp_port to the standard port
    profile.cdp_port = cdp_port

    # Clean up stale SingletonLock
    singleton_lock = pathlib.Path(profile.user_data_dir) / "SingletonLock"
    if singleton_lock.exists():
        try:
            target = os.readlink(str(singleton_lock))
            pid = int(target.split("-")[-1])
            try:
                os.kill(pid, _signal.SIGTERM)
                logger.info("Sent SIGTERM to Chrome pid=%d (held SingletonLock)", pid)
                for _ in range(10):
                    await asyncio.sleep(0.5)
                    try:
                        os.kill(pid, 0)
                    except ProcessLookupError:
                        break
                else:
                    with contextlib.suppress(ProcessLookupError, OSError):
                        os.kill(pid, _signal.SIGKILL)
                    await asyncio.sleep(0.5)
            except (ProcessLookupError, OSError):
                pass
        except (OSError, ValueError):
            pass
        with contextlib.suppress(OSError):
            singleton_lock.unlink()
            logger.info("Removed stale SingletonLock at %s", singleton_lock)

    # Step 2: Launch
    try:
        await cm.launch_chrome(
            profile,
            headed=use_headed,
            explicit_executable=explicit_path,
        )
        start_chrome_exit_monitor()
    except Exception as exc:
        raise RuntimeError(f"Failed to launch Chrome: {exc}") from exc


async def get_or_launch_browser(
    profile_name: str = DEFAULT_PROFILE_NAME,
    *,
    headless: bool = True,
) -> tuple[RunningChrome | None, CDPConnection, BrowserProfile]:
    """Ensure Chrome is running and return a Playwright CDP connection.

    Two-step decision:
    1. Check CDP port 9222 — if a browser is listening, attach to it.
    2. If not, launch a new browser (system Chrome headed, or Playwright
       Chromium headless) on port 9222.

    Returns:
        ``(RunningChrome | None, CDPConnection, BrowserProfile)``.
    """
    from lightclaw.agent.tools.browser.environment import LIGHTCLAW_CDP_PORT

    async with _browser_lock:
        _run_startup_checks()

        pm = get_profile_manager()
        cm = get_chrome_manager()

        profile = pm.get_profile(profile_name)
        if not profile:
            profile = pm.create_profile(profile_name)

        cdp_port = LIGHTCLAW_CDP_PORT

        # Step 1: Check if 9222 already has a browser → attach
        # Step 2: If not → launch one on 9222
        await ensure_chrome_running(cdp_port)

        # Register in ChromeProcessManager if not already tracked
        if not cm.is_running(profile_name):
            adopted = RunningChrome(
                profile_name=profile_name,
                process=None,
                cdp_port=cdp_port,
                pid=None,
                attached=True,
            )
            cm._processes[profile_name] = adopted
            start_chrome_exit_monitor()

        running = cm.get_running(profile_name)

        # Attach Playwright over TCP CDP
        cdp_conn = await connect_via_cdp(cdp_port)
        pm.touch_used(profile_name)

        return running, cdp_conn, profile
