"""Always-Browser domain registry.

Maintains a set of domains known to require a real browser (JS-heavy,
anti-scraping, SPA shells).  The ``is_always_browser`` helper extracts
the hostname from a URL and checks it against this registry using
suffix matching so that ``jd.com`` covers ``item.jd.com``, etc.

Domains can be extended at runtime via the ``FINNIE_ALWAYS_BROWSER_EXTRA``
environment variable (comma-separated list of additional domains).
"""

from __future__ import annotations

import logging
import os
from urllib.parse import urlparse

logger = logging.getLogger(__name__)

# ---------------------------------------------------------------------------
# Built-in always-browser domain list
# ---------------------------------------------------------------------------

# E-commerce platforms
_ECOMMERCE_DOMAINS: set[str] = {
    "taobao.com",
    "tmall.com",
    "jd.com",
    "pinduoduo.com",
    "pdd.com",
    "suning.com",
    "vip.com",
    "dangdang.com",
    "amazon.com",
    "amazon.cn",
    "ebay.com",
}

# Social media
_SOCIAL_DOMAINS: set[str] = {
    "weibo.com",
    "zhihu.com",
    "xiaohongshu.com",
    "douyin.com",
    "tiktok.com",
    "bilibili.com",
    "twitter.com",
    "x.com",
    "facebook.com",
    "instagram.com",
    "mp.weixin.qq.com",
}

# Document / knowledge collaboration platforms (SPA-heavy)
_DOC_DOMAINS: set[str] = {
    "yuque.com",
    "feishu.cn",
    "notion.so",
    "notion.site",
    "docs.google.com",
    "drive.google.com",
}

# Other known JS-heavy sites
_OTHER_DOMAINS: set[str] = {
    "linkedin.com",
    "reddit.com",
}

# Combined built-in set (frozen at import time)
_BUILTIN_DOMAINS: frozenset[str] = frozenset(
    _ECOMMERCE_DOMAINS | _SOCIAL_DOMAINS | _DOC_DOMAINS | _OTHER_DOMAINS,
)

# ---------------------------------------------------------------------------
# Runtime-extended domain set (includes env-var additions)
# ---------------------------------------------------------------------------

_all_domains: set[str] | None = None


def _load_domains() -> set[str]:
    """Build the full domain set (built-in + env-var extras).

    The result is cached in ``_all_domains`` so the env var is only read once.
    """
    global _all_domains
    if _all_domains is not None:
        return _all_domains

    domains = set(_BUILTIN_DOMAINS)

    extra_raw = os.environ.get("FINNIE_ALWAYS_BROWSER_EXTRA", "").strip()
    if extra_raw:
        for entry in extra_raw.split(","):
            entry = entry.strip().lower()
            if entry:
                domains.add(entry)
                logger.debug("Added extra always-browser domain: %s", entry)

    _all_domains = domains
    return _all_domains


def reload_domains() -> None:
    """Force a reload of the domain set (useful after env-var changes)."""
    global _all_domains
    _all_domains = None
    _load_domains()


# ---------------------------------------------------------------------------
# Public API
# ---------------------------------------------------------------------------


def get_always_browser_domains() -> frozenset[str]:
    """Return the current always-browser domain set (read-only view)."""
    return frozenset(_load_domains())


def is_always_browser(url: str) -> bool:
    """Check whether *url* belongs to an always-browser domain.

    Matching rules:
    - Extract the hostname from the URL.
    - Walk from the full hostname upwards (``item.jd.com`` → ``jd.com``).
    - If any suffix matches a registered domain, return ``True``.

    Entries like ``mp.weixin.qq.com`` are matched at the subdomain level,
    while ``jd.com`` matches all of its subdomains.
    """
    domains = _load_domains()

    try:
        parsed = urlparse(url if "://" in url else f"https://{url}")
        hostname = (parsed.hostname or "").lower().strip(".")
    except Exception:
        return False

    if not hostname:
        return False

    # Walk the hostname parts from most-specific to least-specific.
    # e.g. "item.jd.com" → ["item.jd.com", "jd.com", "com"]
    parts = hostname.split(".")
    for i in range(len(parts)):
        candidate = ".".join(parts[i:])
        if candidate in domains:
            return True

    return False
