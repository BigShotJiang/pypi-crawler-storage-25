"""Playwright browser auto-install helpers."""

from __future__ import annotations

import contextlib
import os
import platform
import shutil
import subprocess
import sys
from pathlib import Path

import click

# ---------------------------------------------------------------------------
# Mirror configuration
# ---------------------------------------------------------------------------

# Default mirror host for Playwright browser downloads.
# Modern Playwright downloads Chrome for Testing binaries.  The official URL
# pattern is ``cdn.playwright.dev/chrome-for-testing-public/{ver}/...``,
# and PLAYWRIGHT_DOWNLOAD_HOST replaces everything before the version path.
# npmmirror hosts these under ``/binaries/chrome-for-testing/{ver}/...``.
# Can be overridden via PLAYWRIGHT_DOWNLOAD_HOST env var.
_DEFAULT_MIRROR = "https://cdn.npmmirror.com/binaries/chrome-for-testing"

# ---------------------------------------------------------------------------
# Internal: executable detection
# ---------------------------------------------------------------------------


def _chromium_executable() -> str | None:
    """Return the Playwright-managed Chromium executable path.

    Tries three strategies in order:

    1. ``playwright show-downloads-dir`` CLI command (newer Playwright versions).
    2. Well-known cache directory (``PLAYWRIGHT_BROWSERS_PATH`` env var or
       the platform default ``~/.cache/ms-playwright``).
    3. Other users' home directories under ``/home/*/`` (handles the case
       where the service runs as root but Playwright was installed by another
       user such as ``ubuntu``).

    This avoids launching a full ``sync_playwright`` context which would
    deadlock inside an existing asyncio event loop.
    """
    downloads_dir = _resolve_playwright_downloads_dir()
    if downloads_dir is None or not downloads_dir.is_dir():
        return None

    return _find_chromium_in_dir(downloads_dir)


def _resolve_playwright_downloads_dir() -> Path | None:
    """Determine the Playwright browser download directory."""
    # Honour the explicit env var first (same var Playwright itself reads).
    env_path = os.environ.get("PLAYWRIGHT_BROWSERS_PATH")
    if env_path:
        return Path(env_path)

    # Strategy 1: ask Playwright CLI (works on newer versions).
    try:
        result = subprocess.run(
            [sys.executable, "-m", "playwright", "show-downloads-dir"],
            capture_output=True,
            text=True,
            timeout=10,
        )
        if result.returncode == 0 and result.stdout.strip():
            return Path(result.stdout.strip())
    except Exception:
        pass

    # Strategy 2: well-known default cache path per platform.
    system = platform.system()
    if system == "Windows":
        local_app = os.environ.get("LOCALAPPDATA")
        if local_app:
            return Path(local_app) / "ms-playwright"
    elif system == "Darwin":
        return Path.home() / "Library" / "Caches" / "ms-playwright"
    else:
        # Linux / other POSIX — respect XDG_CACHE_HOME if set.
        xdg = os.environ.get("XDG_CACHE_HOME")
        base = Path(xdg) if xdg else Path.home() / ".cache"
        candidate = base / "ms-playwright"
        try:
            if candidate.is_dir() and _find_chromium_in_dir(candidate):
                return candidate
        except PermissionError:
            pass

        # Strategy 3: scan other users' home directories.
        # This handles the common case where the service runs as root but
        # Playwright was installed by a non-root user (e.g. ubuntu).
        other_homes: list[Path] = []
        home_root = Path("/home")
        if home_root.is_dir():
            with contextlib.suppress(PermissionError):
                other_homes.extend(home_root.iterdir())
        # Also check /root in case it differs from Path.home()
        root_home = Path("/root")
        if root_home != Path.home() and root_home.is_dir():
            other_homes.append(root_home)

        for home in other_homes:
            p = home / ".cache" / "ms-playwright"
            try:
                if p.is_dir() and _find_chromium_in_dir(p):
                    return p
            except PermissionError:
                continue

        # Fall back to the current user's path even if Chromium isn't there
        # yet (Playwright auto-install may populate it later).
        return base / "ms-playwright"

    return None


def _find_chromium_in_dir(downloads_dir: Path) -> str | None:
    """Search *downloads_dir* for a Chromium binary installed by Playwright."""
    try:
        system = platform.system()
        exe_name = "chrome.exe" if system == "Windows" else "chrome"
        for candidate in downloads_dir.glob("chromium-*/chrome-*/"):
            exe = candidate / exe_name
            if exe.exists():
                return str(exe)
        # Fallback: headless-shell variant
        exe_name_hs = "headless_shell.exe" if system == "Windows" else "headless_shell"
        for candidate in downloads_dir.glob("chromium_headless_shell-*/chrome-*/"):
            exe = candidate / exe_name_hs
            if exe.exists():
                return str(exe)
        return None
    except Exception:
        return None


# ---------------------------------------------------------------------------
# Internal: OS-level dependency installation
# ---------------------------------------------------------------------------


def _install_system_deps(python: str) -> None:
    """Attempt to install OS-level shared libraries required by Chromium.

    Strategy per platform:
    - **Windows**: no action needed; Chromium is fully self-contained.
    - **macOS**: no action needed; deps bundled inside the .app structure.
    - **Linux (apt)**: run ``playwright install-deps chromium``.
    - **Linux (dnf/yum/pacman/zypper)**: directly install required packages.
    - **Other Linux**: print a generic guidance message.
    """
    system = platform.system()

    if system == "Windows":
        click.echo("  (Windows: no system dependencies needed)")
        return

    if system == "Darwin":
        click.echo("  (macOS: no system dependencies needed)")
        return

    if system != "Linux":
        click.echo(
            f"  (Unknown OS '{system}': skipping system deps — "
            "run 'playwright install-deps chromium' manually if needed)"
        )
        return

    # ----- Linux branch -----
    if shutil.which("apt-get") or shutil.which("apt"):
        # Debian / Ubuntu / Mint — Playwright natively supports install-deps
        click.echo("  Detected apt-based Linux — running playwright install-deps...")
        result = subprocess.run(
            [python, "-m", "playwright", "install-deps", "chromium"],
            check=False,
        )
        if result.returncode != 0:
            click.echo(
                "! Could not install system dependencies automatically.\n"
                "  Run manually: sudo playwright install-deps chromium",
                err=True,
            )
        return

    _DNF_YUM_PKGS = [
        "alsa-lib",
        "atk",
        "at-spi2-atk",
        "cups-libs",
        "libdrm",
        "libgbm",
        "libX11",
        "libXcomposite",
        "libXdamage",
        "libXext",
        "libXfixes",
        "libXrandr",
        "libxkbcommon",
        "nss",
        "pango",
    ]
    if shutil.which("dnf"):
        click.echo("  Detected dnf-based Linux (Fedora/RHEL) — installing Chromium deps...")
        result = subprocess.run(["dnf", "install", "-y", *_DNF_YUM_PKGS], check=False)
        if result.returncode != 0:
            click.echo(
                "! Could not install system dependencies automatically.\n"
                "  Run manually: sudo dnf install -y " + " ".join(_DNF_YUM_PKGS),
                err=True,
            )
        return

    if shutil.which("yum"):
        click.echo("  Detected yum-based Linux (CentOS/RHEL) — installing Chromium deps...")
        result = subprocess.run(["yum", "install", "-y", *_DNF_YUM_PKGS], check=False)
        if result.returncode != 0:
            click.echo(
                "! Could not install system dependencies automatically.\n"
                "  Run manually: sudo yum install -y " + " ".join(_DNF_YUM_PKGS),
                err=True,
            )
        return

    _PACMAN_PKGS = [
        "alsa-lib",
        "atk",
        "at-spi2-atk",
        "cups",
        "libdrm",
        "mesa",
        "libx11",
        "libxcomposite",
        "libxdamage",
        "libxext",
        "libxfixes",
        "libxrandr",
        "libxkbcommon",
        "nss",
        "pango",
    ]
    if shutil.which("pacman"):
        click.echo("  Detected pacman-based Linux (Arch/Manjaro) — installing Chromium deps...")
        result = subprocess.run(["pacman", "-S", "--noconfirm", "--needed", *_PACMAN_PKGS], check=False)
        if result.returncode != 0:
            click.echo(
                "! Could not install system dependencies automatically.\n"
                "  Run manually: sudo pacman -S --needed " + " ".join(_PACMAN_PKGS),
                err=True,
            )
        return

    _ZYPPER_PKGS = [
        "alsa",
        "libatk-1_0-0",
        "libatk-bridge-2_0-0",
        "libcups2",
        "libdrm2",
        "Mesa-libgbm1",
        "libX11-6",
        "libXcomposite1",
        "libXdamage1",
        "libXext6",
        "libXfixes3",
        "libXrandr2",
        "libxkbcommon0",
        "libnspr4",
        "libnss3",
        "libpango-1_0-0",
    ]
    if shutil.which("zypper"):
        click.echo("  Detected zypper-based Linux (openSUSE) — installing Chromium deps...")
        result = subprocess.run(["zypper", "install", "-y", *_ZYPPER_PKGS], check=False)
        if result.returncode != 0:
            click.echo(
                "! Could not install system dependencies automatically.\n"
                "  Run manually: sudo zypper in -y " + " ".join(_ZYPPER_PKGS),
                err=True,
            )
        return

    # Generic fallback for unknown Linux distros
    click.echo(
        "! Unrecognised Linux distro — skipping automatic system dependency install.\n"
        "  If Chromium fails to launch, try:\n"
        "    playwright install-deps chromium\n"
        "  or install the required shared libraries for your distro manually."
    )


# ---------------------------------------------------------------------------
# Internal: CJK font detection and installation
# ---------------------------------------------------------------------------

# Font package names per package manager
_CJK_FONT_PACKAGES: dict[str, list[str]] = {
    "apt": ["fonts-noto-cjk"],
    "dnf": ["google-noto-sans-cjk-ttc-fonts"],
    "yum": ["google-noto-sans-cjk-ttc-fonts"],
    "pacman": ["noto-fonts-cjk"],
    "zypper": ["noto-sans-cjk-fonts"],
}


# Font family name substrings that indicate high-quality CJK fonts are present.
# Noto CJK covers all common CJK characters with good rendering quality.
# WQY (Wen Quan Yi) is adequate but has narrower coverage, so we prefer Noto.
_PREFERRED_CJK_FAMILIES = (
    "noto",  # Google Noto CJK family
    "source han",  # Adobe Source Han (same glyphs, different name)
    "思源",  # Source Han Chinese name
)


def _has_cjk_fonts() -> bool:
    """Check whether the system has CJK fonts installed via fc-list."""
    fc_list = shutil.which("fc-list")
    if not fc_list:
        return True  # Cannot verify — assume OK

    try:
        result = subprocess.run(
            [fc_list, ":lang=zh"],
            capture_output=True,
            text=True,
            timeout=10,
        )
        # If fc-list returns any output, CJK fonts are present
        return bool(result.stdout.strip())
    except (subprocess.TimeoutExpired, FileNotFoundError):
        return True  # Cannot verify — assume OK


def _has_preferred_cjk_fonts() -> bool:
    """Check whether high-quality Noto/Source Han CJK fonts are installed.

    Returns ``False`` when only lower-coverage fonts (e.g. WenQuanYi) are
    present, so that the installer can supplement them with Noto CJK for
    better Chinese text rendering on web pages.
    """
    fc_list = shutil.which("fc-list")
    if not fc_list:
        return True  # Cannot verify — assume OK

    try:
        result = subprocess.run(
            [fc_list, ":lang=zh"],
            capture_output=True,
            text=True,
            timeout=10,
        )
        output_lower = result.stdout.lower()
        return any(family in output_lower for family in _PREFERRED_CJK_FAMILIES)
    except (subprocess.TimeoutExpired, FileNotFoundError):
        return True  # Cannot verify — assume OK


def _install_cjk_fonts() -> None:
    """Detect and install high-quality CJK fonts on Linux if missing.

    First checks for Noto CJK (preferred) via ``fc-list :lang=zh``.  If only
    lower-quality fonts are present (e.g. WenQuanYi), installs Noto CJK to
    ensure complete Chinese character coverage for web page rendering.
    Refreshes the font cache on success.
    """
    if platform.system() != "Linux":
        return

    if _has_preferred_cjk_fonts():
        click.echo("  ✓ Noto CJK fonts already present.")
        return

    if _has_cjk_fonts():
        click.echo("  CJK fonts present but Noto CJK not found — installing for better Chinese rendering...")
    else:
        click.echo("  CJK fonts not found — attempting to install...")

    installed = False
    pkg_manager: str | None = None
    packages: list[str] = []

    if shutil.which("apt-get") or shutil.which("apt"):
        pkg_manager = "apt"
        packages = _CJK_FONT_PACKAGES["apt"]
        result = subprocess.run(
            ["apt-get", "install", "-y", *packages],
            capture_output=True,
            text=True,
            timeout=120,
        )
        installed = result.returncode == 0
    elif shutil.which("dnf"):
        pkg_manager = "dnf"
        packages = _CJK_FONT_PACKAGES["dnf"]
        result = subprocess.run(
            ["dnf", "install", "-y", *packages],
            capture_output=True,
            text=True,
            timeout=120,
        )
        installed = result.returncode == 0
    elif shutil.which("yum"):
        pkg_manager = "yum"
        packages = _CJK_FONT_PACKAGES["yum"]
        result = subprocess.run(
            ["yum", "install", "-y", *packages],
            capture_output=True,
            text=True,
            timeout=120,
        )
        installed = result.returncode == 0
    elif shutil.which("pacman"):
        pkg_manager = "pacman"
        packages = _CJK_FONT_PACKAGES["pacman"]
        result = subprocess.run(
            ["pacman", "-S", "--noconfirm", *packages],
            capture_output=True,
            text=True,
            timeout=120,
        )
        installed = result.returncode == 0
    elif shutil.which("zypper"):
        pkg_manager = "zypper"
        packages = _CJK_FONT_PACKAGES["zypper"]
        result = subprocess.run(
            ["zypper", "install", "-y", *packages],
            capture_output=True,
            text=True,
            timeout=120,
        )
        installed = result.returncode == 0

    if installed:
        # Refresh font cache
        fc_cache = shutil.which("fc-cache")
        if fc_cache:
            subprocess.run(
                [fc_cache, "-fv"],
                capture_output=True,
                timeout=30,
            )
        click.echo(f"  ✓ CJK fonts installed via {pkg_manager}: {', '.join(packages)}")
    else:
        # Provide manual guidance
        rec = "fonts-noto-cjk (apt) or google-noto-sans-cjk-ttc-fonts (yum/dnf)"
        if pkg_manager:
            rec = ", ".join(packages)
        click.echo(
            f"  ⚠ Could not install CJK fonts automatically.\n"
            f"  Recommended package(s): {rec}\n"
            f"  Install manually to avoid Chinese text rendering as boxes.\n"
            f"  After installing, run: fc-cache -fv"
        )


# ---------------------------------------------------------------------------
# Internal: install system Chromium via package manager as last resort
# ---------------------------------------------------------------------------


def _install_system_chromium():
    """Try to install Chromium via the system package manager.

    Called when Playwright binary download fails and no system browser is found.
    Returns a ChromeExecutable-like object on success, or None on failure.
    """
    if platform.system() != "Linux":
        return None

    from lightclaw.agent.tools.browser.environment import find_chrome_executable

    # Candidate packages in preference order per package manager
    _APT_PKGS = ["chromium-browser", "chromium"]
    _DNF_PKGS = ["chromium"]
    _PACMAN_PKGS = ["chromium"]
    _ZYPPER_PKGS = ["chromium"]

    installed = False

    if shutil.which("apt-get") or shutil.which("apt"):
        click.echo("  Trying: apt install chromium-browser / chromium ...")
        # Update package lists first (ignore errors, may be outdated)
        subprocess.run(["apt-get", "update", "-qq"], check=False, capture_output=True)
        for pkg in _APT_PKGS:
            result = subprocess.run(
                ["apt-get", "install", "-y", pkg],
                check=False,
            )
            if result.returncode == 0:
                click.echo(f"  ✓ Installed system Chromium via apt ({pkg})")
                installed = True
                break

    elif shutil.which("dnf"):
        click.echo("  Trying: dnf install chromium ...")
        result = subprocess.run(
            ["dnf", "install", "-y", *_DNF_PKGS],
            check=False,
        )
        installed = result.returncode == 0
        if installed:
            click.echo("  ✓ Installed system Chromium via dnf")

    elif shutil.which("yum"):
        click.echo("  Trying: yum install chromium ...")
        result = subprocess.run(
            ["yum", "install", "-y", *_DNF_PKGS],
            check=False,
        )
        installed = result.returncode == 0
        if installed:
            click.echo("  ✓ Installed system Chromium via yum")

    elif shutil.which("pacman"):
        click.echo("  Trying: pacman -S chromium ...")
        result = subprocess.run(
            ["pacman", "-S", "--noconfirm", "--needed", *_PACMAN_PKGS],
            check=False,
        )
        installed = result.returncode == 0
        if installed:
            click.echo("  ✓ Installed system Chromium via pacman")

    elif shutil.which("zypper"):
        click.echo("  Trying: zypper install chromium ...")
        result = subprocess.run(
            ["zypper", "install", "-y", *_ZYPPER_PKGS],
            check=False,
        )
        installed = result.returncode == 0
        if installed:
            click.echo("  ✓ Installed system Chromium via zypper")

    if installed:
        return find_chrome_executable()
    return None


# ---------------------------------------------------------------------------
# Public API
# ---------------------------------------------------------------------------


def ensure_playwright_browsers(*, quiet: bool = False) -> bool:
    """Ensure Playwright Chromium binary and its system deps are present.

    Downloads the browser binary and installs OS-level libraries if missing.
    Returns ``True`` if everything is ready, ``False`` if installation failed.

    Supports Windows, macOS, and Linux (apt / dnf / pacman / zypper).

    The download mirror can be configured via the ``PLAYWRIGHT_DOWNLOAD_HOST``
    environment variable.  When the variable is not set, uses a China-friendly
    npmmirror CDN for the Chromium binary, then falls back to the official
    upstream for any remaining components (ffmpeg, headless-shell) that the
    mirror may not carry.

    If all downloads fail, falls back to detecting system-installed
    Chromium/Chrome so the browser tool remains functional.
    """
    exe = _chromium_executable()
    if exe and Path(exe).exists():
        if not quiet:
            click.echo("✓ Playwright Chromium already installed.")
        return True

    click.echo("Playwright Chromium not found — installing...")
    python = sys.executable

    caller_set_mirror = "PLAYWRIGHT_DOWNLOAD_HOST" in os.environ

    if caller_set_mirror:
        # Respect the explicit mirror — single attempt, install everything.
        click.echo(f"  Using mirror: {os.environ['PLAYWRIGHT_DOWNLOAD_HOST']}")
        result = subprocess.run(
            [python, "-m", "playwright", "install", "chromium"],
            check=False,
        )
        if result.returncode != 0:
            click.echo("✗ Failed to install Playwright Chromium binary.", err=True)
    else:
        # Phase 1: Try npmmirror CDN for the main Chromium binary.
        # This mirror hosts Chrome for Testing but may lack ffmpeg/headless-shell,
        # so a non-zero exit code here is acceptable as long as Chromium lands.
        mirror_env = os.environ.copy()
        mirror_env["PLAYWRIGHT_DOWNLOAD_HOST"] = _DEFAULT_MIRROR
        click.echo(f"  Trying download source: {_DEFAULT_MIRROR}")
        subprocess.run(
            [python, "-m", "playwright", "install", "chromium"],
            check=False,
            env=mirror_env,
        )

        # Phase 2: If Chromium was not downloaded, fall back to official upstream.
        # If it was, the official run will be a no-op for Chromium and only
        # download the missing ffmpeg / headless-shell components.
        chromium_ok = bool(_chromium_executable())
        if not chromium_ok:
            click.echo("  ⚠ Mirror incomplete, trying official upstream...")

        official_env = os.environ.copy()
        official_env.pop("PLAYWRIGHT_DOWNLOAD_HOST", None)
        subprocess.run(
            [python, "-m", "playwright", "install", "chromium"],
            check=False,
            env=official_env,
        )

    # Check if Playwright Chromium is now available
    if not _chromium_executable():
        # All Playwright downloads failed — try installing system Chromium via apt
        from lightclaw.agent.tools.browser.environment import find_chrome_executable

        system_exe = find_chrome_executable()
        if not system_exe:
            system_exe = _install_system_chromium()

        if system_exe:
            click.echo(f"\n✓ System Chromium/Chrome available: {system_exe.path}")
            click.echo("  The browser tool will use this system binary.")
        else:
            click.echo(
                "\n✗ No browser found. Try:\n"
                "  sudo apt install -y chromium-browser  (Debian/Ubuntu)\n"
                "  or: PLAYWRIGHT_DOWNLOAD_HOST=<mirror> lightclaw install-browsers",
                err=True,
            )
            return False

    # 2. Install OS-level shared libraries where applicable
    _install_system_deps(python)

    # 3. Ensure CJK fonts are available for Chinese page rendering
    _install_cjk_fonts()

    click.echo("✓ Browser setup complete.")
    return True
