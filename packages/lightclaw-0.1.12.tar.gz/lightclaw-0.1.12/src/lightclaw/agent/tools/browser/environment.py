"""Runtime environment detection, Chrome executable discovery, system
dependency checking, and Chrome launch-flag assembly.

Ported from openclaw/src/browser/chrome.executables.ts and
openclaw/sandbox-browser-entrypoint.sh to Python.
"""

from __future__ import annotations

import json
import logging
import os
import platform
import shutil
import subprocess
from dataclasses import dataclass, field
from pathlib import Path
from typing import Literal

logger = logging.getLogger(__name__)

# ---------------------------------------------------------------------------
# Type aliases
# ---------------------------------------------------------------------------
DisplayEnvironment = Literal["desktop", "headless-server"]

BrowserKind = Literal[
    "chrome",
    "brave",
    "edge",
    "chromium",
    "canary",
    "custom",
]


@dataclass
class BrowserExecutable:
    """Describes a discovered browser binary."""

    kind: BrowserKind
    path: str


@dataclass
class DependencyCheckResult:
    """Result of a system dependency check."""

    ok: bool
    missing: list[str] = field(default_factory=list)
    install_command: str = ""


# ---------------------------------------------------------------------------
# Display environment detection
# ---------------------------------------------------------------------------


def _probe_x11_display() -> str | None:
    """Probe the system for a running X11 display server.

    Two detection strategies are used in order:

    1. **Filesystem sockets** — Conventional X11 servers create a socket file
       at ``/tmp/.X11-unix/XN``.  Scanning this directory is the fast path.
    2. **Abstract sockets** — Some X servers (notably Xtigervnc / TigerVNC)
       use Linux *abstract* Unix sockets instead of (or in addition to)
       filesystem sockets.  Abstract sockets exist only in the kernel and do
       not appear as files, so the directory scan above finds nothing.  They
       are still visible in ``/proc/net/unix`` with names like
       ``@/tmp/.X11-unix/X1``.

    Returns the first discovered display string (e.g. ``":1"``), preferring
    the lowest display number, or ``None`` if nothing is found.
    """
    import re

    found: set[int] = set()

    # Strategy 1: filesystem sockets (most X11 servers)
    x11_socket_dir = Path("/tmp/.X11-unix")
    if x11_socket_dir.is_dir():
        for entry in x11_socket_dir.iterdir():
            name = entry.name
            if name.startswith("X") and name[1:].isdigit():
                found.add(int(name[1:]))

    # Strategy 2: abstract sockets in /proc/net/unix (Xtigervnc / TigerVNC)
    # Lines look like: "... @/tmp/.X11-unix/X1"
    if not found:
        proc_unix = Path("/proc/net/unix")
        if proc_unix.exists():
            try:
                _abstract_re = re.compile(r"@/tmp/\.X11-unix/X(\d+)$")
                for line in proc_unix.read_text(errors="replace").splitlines():
                    m = _abstract_re.search(line)
                    if m:
                        found.add(int(m.group(1)))
            except Exception:
                pass

    if not found:
        return None

    # Prefer the lowest display number (most likely the primary desktop).
    display = f":{min(found)}"
    logger.info("Auto-detected X11 display from socket: %s", display)
    return display


def detect_display_environment() -> DisplayEnvironment:
    """Detect whether the host has a graphical display.

    Returns ``'desktop'`` when a usable display is available (macOS, X11,
    Wayland) and ``'headless-server'`` otherwise.

    On Linux, if neither ``$DISPLAY`` nor ``$WAYLAND_DISPLAY`` is set in the
    current process environment, the function probes ``/tmp/.X11-unix/`` for
    running X11 sockets.  When a socket is found the ``DISPLAY`` environment
    variable is set automatically so that child processes (e.g. Chrome)
    inherit the correct value without requiring manual configuration.
    """
    system = platform.system()

    # macOS always has a display (even headless Macs expose quartz)
    if system == "Darwin":
        return "desktop"

    # Linux: check for active display server
    if system == "Linux":
        # Wayland
        if os.environ.get("WAYLAND_DISPLAY"):
            return "desktop"
        # X11 — env var present
        if os.environ.get("DISPLAY"):
            return "desktop"
        # X11 — env var absent but a display server may be running (e.g.
        # LightClaw started via systemd/init without inheriting the desktop
        # session environment).  Try to discover it from X sockets.
        discovered = _probe_x11_display()
        if discovered:
            os.environ["DISPLAY"] = discovered
            logger.info("Set DISPLAY=%s (auto-detected from X11 socket)", discovered)
            return "desktop"
        return "headless-server"

    # Fallback for other platforms (Windows always has a display when running)
    if system == "Windows":
        return "desktop"

    return "headless-server"


# ---------------------------------------------------------------------------
# Chrome executable discovery
# ---------------------------------------------------------------------------

# macOS candidates (priority order: Chrome > Brave > Edge > Chromium > Canary)
_MAC_CANDIDATES: list[tuple[BrowserKind, str]] = [
    ("chrome", "/Applications/Google Chrome.app/Contents/MacOS/Google Chrome"),
    (
        "chrome",
        os.path.expanduser(
            "~/Applications/Google Chrome.app/Contents/MacOS/Google Chrome",
        ),
    ),
    ("brave", "/Applications/Brave Browser.app/Contents/MacOS/Brave Browser"),
    (
        "brave",
        os.path.expanduser(
            "~/Applications/Brave Browser.app/Contents/MacOS/Brave Browser",
        ),
    ),
    ("edge", "/Applications/Microsoft Edge.app/Contents/MacOS/Microsoft Edge"),
    (
        "edge",
        os.path.expanduser(
            "~/Applications/Microsoft Edge.app/Contents/MacOS/Microsoft Edge",
        ),
    ),
    ("chromium", "/Applications/Chromium.app/Contents/MacOS/Chromium"),
    (
        "chromium",
        os.path.expanduser(
            "~/Applications/Chromium.app/Contents/MacOS/Chromium",
        ),
    ),
    ("canary", "/Applications/Google Chrome Canary.app/Contents/MacOS/Google Chrome Canary"),
    (
        "canary",
        os.path.expanduser(
            "~/Applications/Google Chrome Canary.app/Contents/MacOS/Google Chrome Canary",
        ),
    ),
]

# Linux candidates (priority order matching openclaw)
_LINUX_CANDIDATES: list[tuple[BrowserKind, str]] = [
    ("chrome", "/usr/bin/google-chrome"),
    ("chrome", "/usr/bin/google-chrome-stable"),
    ("chrome", "/usr/bin/chrome"),
    ("brave", "/usr/bin/brave-browser"),
    ("brave", "/usr/bin/brave-browser-stable"),
    ("brave", "/usr/bin/brave"),
    ("brave", "/snap/bin/brave"),
    ("edge", "/usr/bin/microsoft-edge"),
    ("edge", "/usr/bin/microsoft-edge-stable"),
    ("chromium", "/usr/bin/chromium"),
    ("chromium", "/usr/bin/chromium-browser"),
    ("chromium", "/snap/bin/chromium"),
]


def _is_snap_executable(path: str) -> bool:
    """Return True if *path* is a snap-managed binary.

    Snap packages refuse to run as root (exit code 21) on servers where
    ``/run/user/0`` is absent.  We detect snap executables by path prefix
    (``/snap/``) or by resolving symlinks that point into the snap mount.
    """
    if path.startswith("/snap/"):
        return True
    try:
        real = os.path.realpath(path)
        if real.startswith("/snap/"):
            return True
    except OSError:
        pass
    return False


def _find_first_executable(
    candidates: list[tuple[BrowserKind, str]],
    *,
    skip_snap: bool = False,
) -> BrowserExecutable | None:
    """Return the first candidate whose path exists on disk.

    Args:
        candidates: Ordered list of ``(kind, path)`` pairs to probe.
        skip_snap: When ``True``, skip snap-managed executables.  This should
            be set when running as root because snap refuses to run as root
            (exits with code 21 and a ``/run/user/0`` permission error).
    """
    for kind, path in candidates:
        if skip_snap and _is_snap_executable(path):
            logger.debug("Skipping snap executable (running as root): %s", path)
            continue
        if os.path.isfile(path) and os.access(path, os.X_OK):
            return BrowserExecutable(kind=kind, path=path)
    return None


# ---------------------------------------------------------------------------
# Detection of already-running Chrome with CDP enabled
# ---------------------------------------------------------------------------

# Standard CDP port for LightClaw.  All LightClaw-managed Chrome instances
# use this port.  If a user starts Chrome with --remote-debugging-port=9222,
# LightClaw will attach to it instead of launching a new instance.
LIGHTCLAW_CDP_PORT = 9222

# Well-known CDP ports to probe when scanning for user Chrome.
_WELL_KNOWN_CDP_PORTS = (9222,)

# Attach-mode configuration.
#   "auto"   — detect and attach if a running Chrome with CDP is found,
#              otherwise fall through to normal launch.
#   "always" — require attaching to an existing Chrome; fail if none found.
#   "never"  — skip detection entirely, always launch a fresh process.
CHROME_ATTACH_MODE = os.environ.get("LIGHTCLAW_CHROME_ATTACH_MODE", "auto").strip().lower()


@dataclass
class RunningChromeInfo:
    """Describes a running Chrome instance discovered on the host."""

    cdp_port: int
    pid: int | None = None
    source: str = ""  # "process_scan" or "port_probe"


def _scan_processes_for_cdp_port() -> list[RunningChromeInfo]:
    """Scan OS processes for Chrome instances that expose a CDP port.

    On macOS uses ``ps aux``; on Linux uses ``/proc/*/cmdline``.
    Returns a list of discovered instances (may be empty).
    """
    results: list[RunningChromeInfo] = []
    system = platform.system()

    if system == "Darwin":
        results = _scan_macos_processes()
    elif system == "Linux":
        results = _scan_linux_processes()

    return results


def _is_lightclaw_managed_process(line: str) -> bool:
    """Return True if the process line indicates a LightClaw/Playwright-managed Chrome.

    Excludes:
    - Playwright-managed Chrome for Testing (path contains ``ms-playwright``)
    - LightClaw-managed Chrome (user-data-dir contains ``lightclaw``)
    - Child processes (``--type=renderer``, ``--type=gpu-process``, etc.)
    """
    # Skip child processes — only the main browser process matters
    if "--type=" in line:
        return True
    lower = line.lower()
    if "ms-playwright" in lower:
        return True
    return "lightclaw" in lower and "--user-data-dir=" in lower


def _scan_macos_processes() -> list[RunningChromeInfo]:
    """macOS: use ``ps aux`` to find Chrome processes with --remote-debugging-port."""
    results: list[RunningChromeInfo] = []
    try:
        proc = subprocess.run(
            ["ps", "aux"],
            capture_output=True,
            text=True,
            timeout=5,
        )
        for line in proc.stdout.splitlines():
            lower = line.lower()
            if "chrome" not in lower and "chromium" not in lower:
                continue
            if "--remote-debugging-port=" not in line:
                continue
            if _is_lightclaw_managed_process(line):
                continue
            port = _extract_cdp_port(line)
            pid = _extract_pid_from_ps(line)
            if port:
                results.append(RunningChromeInfo(cdp_port=port, pid=pid, source="process_scan"))
    except (subprocess.TimeoutExpired, FileNotFoundError, OSError):
        pass
    return results


def _scan_linux_processes() -> list[RunningChromeInfo]:
    """Linux: scan ``/proc/*/cmdline`` for Chrome processes with CDP port."""
    results: list[RunningChromeInfo] = []
    proc_dir = Path("/proc")
    if not proc_dir.is_dir():
        return results

    for entry in proc_dir.iterdir():
        if not entry.name.isdigit():
            continue
        cmdline_path = entry / "cmdline"
        try:
            cmdline = cmdline_path.read_bytes().decode("utf-8", errors="replace")
            lower = cmdline.lower()
            if "chrome" not in lower and "chromium" not in lower:
                continue
            if "--remote-debugging-port=" not in cmdline:
                continue
            if _is_lightclaw_managed_process(cmdline):
                continue
            port = _extract_cdp_port(cmdline)
            if port:
                pid = int(entry.name)
                results.append(RunningChromeInfo(cdp_port=port, pid=pid, source="process_scan"))
        except (OSError, ValueError):
            continue
    return results


def _extract_cdp_port(text: str) -> int | None:
    """Extract the port number from ``--remote-debugging-port=N`` in a string."""
    import re

    match = re.search(r"--remote-debugging-port=(\d+)", text)
    if match:
        try:
            return int(match.group(1))
        except ValueError:
            pass
    return None


def _extract_pid_from_ps(line: str) -> int | None:
    """Extract PID from a ``ps aux`` output line (second column)."""
    parts = line.split()
    if len(parts) >= 2:
        try:
            return int(parts[1])
        except ValueError:
            pass
    return None


def detect_running_chrome_with_cdp() -> RunningChromeInfo | None:
    """Detect a user's Chrome browser that is running with CDP enabled.

    Strategy:
    1. Scan running processes for ``--remote-debugging-port=N``.
    2. If nothing found, probe well-known ports (9222, 9229) for a CDP
       ``/json/version`` response.

    Returns:
        A :class:`RunningChromeInfo` or ``None``.
    """
    if CHROME_ATTACH_MODE == "never":
        logger.debug("Chrome attach mode is 'never'; skipping detection")
        return None

    # Strategy 1: process command-line scan
    found = _scan_processes_for_cdp_port()
    if found:
        logger.info(
            "Detected %d Chrome instance(s) with CDP: %s",
            len(found),
            [(r.cdp_port, r.pid) for r in found],
        )
        return found[0]

    # Strategy 2: probe well-known ports.
    # Also verify the Chrome on that port is NOT managed by LightClaw/Playwright
    # by checking /json/version for "Chrome for Testing" or similar.
    for port in _WELL_KNOWN_CDP_PORTS:
        try:
            import urllib.request

            url = f"http://127.0.0.1:{port}/json/version"
            req = urllib.request.Request(url, method="GET")
            with urllib.request.urlopen(req, timeout=2) as resp:
                if resp.status == 200:
                    body = resp.read().decode("utf-8", errors="replace").lower()
                    # Skip if this is a Playwright-managed "Chrome for Testing"
                    if "chrome for testing" in body or "headless" in body:
                        logger.debug(
                            "Chrome on port %d is Playwright-managed (Chrome for Testing); skipping",
                            port,
                        )
                        continue
                    logger.info("Chrome CDP responding on well-known port %d", port)
                    return RunningChromeInfo(cdp_port=port, source="port_probe")
        except Exception:
            continue

    return None


@dataclass
class ChromeProfileInfo:
    """Describes a user's running Chrome and its profile directory."""

    user_data_dir: str
    executable_path: str = ""
    pid: int | None = None


def detect_running_chrome_profile() -> ChromeProfileInfo | None:
    """Detect a user's running Chrome and determine its profile directory.

    Unlike :func:`detect_running_chrome_with_cdp` which requires
    ``--remote-debugging-port``, this function detects **any** running
    Chrome browser and extracts (or infers) its user-data-dir.

    This enables launching a new headless Chrome that shares the user's
    cookies and login sessions, even when the user's Chrome was started
    normally (without CDP).

    Returns:
        A :class:`ChromeProfileInfo` or ``None`` if no user Chrome is found.
    """
    if CHROME_ATTACH_MODE == "never":
        return None

    system = platform.system()
    if system == "Darwin":
        return _detect_chrome_profile_macos()
    if system == "Linux":
        return _detect_chrome_profile_linux()
    return None


def _detect_chrome_profile_macos() -> ChromeProfileInfo | None:
    """macOS: detect user Chrome's profile directory."""
    import re

    try:
        proc = subprocess.run(
            ["ps", "aux"],
            capture_output=True,
            text=True,
            timeout=5,
        )
        for line in proc.stdout.splitlines():
            lower = line.lower()
            # Must be Chrome/Chromium (not Playwright or LightClaw managed)
            if "chrome" not in lower and "chromium" not in lower:
                continue
            if _is_lightclaw_managed_process(line):
                continue
            # Must be the main browser process (not renderer/gpu/utility)
            if "--type=" in line:
                continue
            # Must be from /Applications (not ms-playwright cache)
            if "/applications/" not in lower:
                continue

            pid = _extract_pid_from_ps(line)

            # Try to extract --user-data-dir from command line
            match = re.search(r"--user-data-dir=(\S+)", line)
            if match:
                user_data_dir = match.group(1)
            else:
                # Default Chrome profile on macOS
                user_data_dir = os.path.expanduser("~/Library/Application Support/Google/Chrome")

            # Extract executable path (everything from / to the first -- flag)
            exe_match = re.search(r"(/\S+/(?:Google Chrome|Chromium|Brave Browser)(?:\.app)?[^\s]*)", line)
            exe_path = exe_match.group(1) if exe_match else ""

            if os.path.isdir(user_data_dir):
                logger.info(
                    "Detected user Chrome (pid=%s, profile=%s)",
                    pid,
                    user_data_dir,
                )
                return ChromeProfileInfo(
                    user_data_dir=user_data_dir,
                    executable_path=exe_path,
                    pid=pid,
                )
    except (subprocess.TimeoutExpired, FileNotFoundError, OSError):
        pass

    # Fallback: check if default Chrome profile exists
    default_profile = os.path.expanduser("~/Library/Application Support/Google/Chrome")
    if os.path.isdir(default_profile):
        logger.info(
            "No running Chrome process found, but default profile exists: %s",
            default_profile,
        )
        return ChromeProfileInfo(user_data_dir=default_profile)

    return None


def _detect_chrome_profile_linux() -> ChromeProfileInfo | None:
    """Linux: detect user Chrome's profile directory."""
    import re

    proc_dir = Path("/proc")
    if proc_dir.is_dir():
        for entry in proc_dir.iterdir():
            if not entry.name.isdigit():
                continue
            cmdline_path = entry / "cmdline"
            try:
                cmdline = cmdline_path.read_bytes().decode("utf-8", errors="replace")
                lower = cmdline.lower()
                if "chrome" not in lower and "chromium" not in lower:
                    continue
                if _is_lightclaw_managed_process(cmdline):
                    continue
                if "--type=" in cmdline:
                    continue

                match = re.search(r"--user-data-dir=(\S+)", cmdline)
                if match:
                    user_data_dir = match.group(1)
                else:
                    user_data_dir = os.path.expanduser("~/.config/google-chrome")

                if os.path.isdir(user_data_dir):
                    pid = int(entry.name)
                    logger.info(
                        "Detected user Chrome (pid=%d, profile=%s)",
                        pid,
                        user_data_dir,
                    )
                    return ChromeProfileInfo(
                        user_data_dir=user_data_dir,
                        pid=pid,
                    )
            except (OSError, ValueError):
                continue

    # Fallback: default profile directory
    default_profile = os.path.expanduser("~/.config/google-chrome")
    if os.path.isdir(default_profile):
        return ChromeProfileInfo(user_data_dir=default_profile)

    return None


def find_chrome_executable(
    explicit_path: str | None = None,
) -> BrowserExecutable | None:
    """Discover a Chromium-based browser on the current platform.

    Args:
        explicit_path: If given, use this path directly (``custom`` kind).

    Returns:
        A :class:`BrowserExecutable` or ``None`` if nothing is found.
    """
    if explicit_path:
        if os.path.isfile(explicit_path) and os.access(explicit_path, os.X_OK):
            return BrowserExecutable(kind="custom", path=explicit_path)
        logger.warning(
            "Explicit browser path %s not found or not executable",
            explicit_path,
        )
        return None

    # Snap executables refuse to run as root on servers where /run/user/0 is
    # absent (exits immediately with code 21).  Skip them when root.
    running_as_root = os.name != "nt" and os.getuid() == 0

    # Also try the PATH as last resort via shutil.which
    system = platform.system()
    if system == "Darwin":
        result = _find_first_executable(_MAC_CANDIDATES)
        if result:
            return result
    elif system == "Linux":
        result = _find_first_executable(_LINUX_CANDIDATES, skip_snap=running_as_root)
        if result:
            return result

    # Fallback: try PATH lookup
    for name in ("google-chrome", "google-chrome-stable", "chromium-browser", "chromium"):
        found = shutil.which(name)
        if found:
            if running_as_root and _is_snap_executable(found):
                logger.debug("Skipping snap executable from PATH (running as root): %s", found)
                continue
            kind: BrowserKind = "chrome" if "chrome" in name else "chromium"
            return BrowserExecutable(kind=kind, path=found)

    return None


# ---------------------------------------------------------------------------
# System dependency checking (Linux only)
# ---------------------------------------------------------------------------

# Required shared libraries for Chrome on Ubuntu/Debian
_REQUIRED_LINUX_PACKAGES = [
    "libnss3",
    "libatk-bridge2.0-0",
    "libatk1.0-0",
    "libcups2",
    "libdrm2",
    "libxkbcommon0",
    "libxcomposite1",
    "libxdamage1",
    "libxrandr2",
    "libgbm1",
    "libpango-1.0-0",
    "libasound2",
]


def check_system_dependencies() -> DependencyCheckResult:
    """Check Chrome runtime library dependencies on Linux.

    Also verifies that CJK fonts are available for Chinese page rendering.
    On non-Linux systems, always returns ``ok=True``.
    """
    if platform.system() != "Linux":
        return DependencyCheckResult(ok=True)

    missing: list[str] = []

    # -- Shared library check (dpkg-based) ---------------------------------
    dpkg = shutil.which("dpkg")
    if dpkg:
        for pkg in _REQUIRED_LINUX_PACKAGES:
            try:
                result = subprocess.run(
                    [dpkg, "-s", pkg],
                    capture_output=True,
                    text=True,
                    timeout=5,
                )
                if result.returncode != 0:
                    missing.append(pkg)
            except (subprocess.TimeoutExpired, FileNotFoundError):
                missing.append(pkg)
    else:
        logger.debug("dpkg not found; skipping library dependency check")

    # -- CJK font check (fc-list based) ------------------------------------
    # We require Noto CJK (preferred) for complete Chinese character coverage.
    # Basic fonts like WenQuanYi are insufficient for modern web rendering.
    _preferred_cjk = ("noto", "source han", "\u601d\u6e90")
    fc_list = shutil.which("fc-list")
    if fc_list:
        try:
            result = subprocess.run(
                [fc_list, ":lang=zh"],
                capture_output=True,
                text=True,
                timeout=10,
            )
            output_lower = result.stdout.lower()
            has_preferred = any(f in output_lower for f in _preferred_cjk)
            if not has_preferred:
                # Noto CJK not found — report the recommended package
                if shutil.which("apt-get") or shutil.which("apt"):
                    missing.append("fonts-noto-cjk")
                elif shutil.which("dnf") or shutil.which("yum"):
                    missing.append("google-noto-sans-cjk-ttc-fonts")
                elif shutil.which("pacman"):
                    missing.append("noto-fonts-cjk")
                else:
                    missing.append("fonts-noto-cjk (or equivalent CJK font)")
        except (subprocess.TimeoutExpired, FileNotFoundError):
            logger.debug("fc-list check failed; skipping CJK font check")

    if not missing:
        return DependencyCheckResult(ok=True)

    install_cmd = f"sudo apt install -y {' '.join(missing)}"
    return DependencyCheckResult(
        ok=False,
        missing=missing,
        install_command=install_cmd,
    )


# ---------------------------------------------------------------------------
# Chrome launch flags
# ---------------------------------------------------------------------------

# Base flags used in all environments
_BASE_FLAGS = [
    "--disable-background-networking",
    "--disable-background-timer-throttling",
    "--disable-backgrounding-occluded-windows",
    "--disable-breakpad",
    "--disable-component-extensions-with-background-pages",
    "--disable-component-update",
    "--disable-default-apps",
    "--disable-hang-monitor",
    "--disable-ipc-flooding-protection",
    "--disable-popup-blocking",
    "--disable-prompt-on-repost",
    "--disable-renderer-backgrounding",
    "--disable-sync",
    "--disable-web-security",
    "--allow-file-access-from-files",
    "--enable-features=NetworkService,NetworkServiceInProcess",
    "--force-color-profile=srgb",
    "--metrics-recording-only",
    "--no-first-run",
    "--password-store=basic",
    "--use-mock-keychain",
]

# Extra flags for headless-server environments (Ubuntu Server, Docker, etc.)
_HEADLESS_SERVER_FLAGS = [
    "--headless=new",
    "--no-sandbox",
    "--disable-gpu",
    "--disable-dev-shm-usage",
    "--disable-software-rasterizer",
    "--no-zygote",
]

# Default extensions base directory
_EXTENSIONS_BASE_DIR = Path(os.path.expanduser("~/.lightclaw/extensions"))

# LightClaw config file path
_LIGHTCLAW_CONFIG_FILE = Path(os.path.expanduser("~/.lightclaw/lightclaw.json"))


def discover_extensions() -> list[str]:
    """Discover installed Chrome extensions under ``~/.lightclaw/extensions/``.

    Scans each sub-directory for a ``manifest.json`` file (the standard
    Chrome extension marker).  Also reads ``~/.lightclaw/lightclaw.json``
    for any explicitly configured extension directories.

    Returns:
        A list of absolute directory paths, each containing a valid
        ``manifest.json``.
    """
    found: list[str] = []

    # 1. Scan the standard extensions directory
    if _EXTENSIONS_BASE_DIR.is_dir():
        for child in _EXTENSIONS_BASE_DIR.iterdir():
            if not child.is_dir():
                continue
            # The manifest may be directly in the child dir, or one level
            # deeper (e.g. ~/.lightclaw/extensions/opencli/extension/manifest.json)
            manifest = child / "manifest.json"
            if manifest.is_file():
                found.append(str(child))
                continue
            for sub in child.iterdir():
                if sub.is_dir() and (sub / "manifest.json").is_file():
                    found.append(str(sub))
                    break

    # 2. Read lightclaw.json for explicitly configured extension dirs
    if _LIGHTCLAW_CONFIG_FILE.is_file():
        try:
            with open(_LIGHTCLAW_CONFIG_FILE, encoding="utf-8") as f:
                config = json.load(f)
            opencli_cfg = config.get("opencli", {})
            ext_dir = opencli_cfg.get("extension_dir", "")
            if ext_dir and Path(ext_dir).is_dir():
                # Find the actual manifest location
                ext_path = Path(ext_dir)
                if (ext_path / "manifest.json").is_file():
                    resolved = str(ext_path)
                    if resolved not in found:
                        found.append(resolved)
                else:
                    for sub in ext_path.iterdir():
                        if sub.is_dir() and (sub / "manifest.json").is_file():
                            resolved = str(sub)
                            if resolved not in found:
                                found.append(resolved)
                            break
        except (json.JSONDecodeError, OSError) as exc:
            logger.debug("Failed to read lightclaw.json for extensions: %s", exc)

    if found:
        logger.info("Discovered %d Chrome extension(s): %s", len(found), found)

    return found


def build_chrome_flags(
    *,
    headless: bool = True,
    environment: DisplayEnvironment | None = None,
    cdp_port: int = 9222,
    user_data_dir: str = "",
    extra_flags: list[str] | None = None,
    auto_load_extensions: bool = True,
) -> list[str]:
    """Assemble Chrome command-line flags.

    Args:
        headless: Whether to use headless mode.
        environment: Override auto-detected environment.
        cdp_port: CDP remote-debugging port.
        user_data_dir: Path for ``--user-data-dir``.
        extra_flags: Additional flags to append.
        auto_load_extensions: When ``True`` (default), automatically
            discover and load Chrome extensions installed under
            ``~/.lightclaw/extensions/``.

    Returns:
        A list of flag strings (no executable path).
    """
    env = environment or detect_display_environment()
    flags = list(_BASE_FLAGS)

    if env == "headless-server":
        # On a headless server we always add server-specific flags
        flags.extend(_HEADLESS_SERVER_FLAGS)
    elif headless:
        # Desktop environment running in headless mode.
        # Include the same memory/sandbox protective flags as headless-server to
        # prevent renderer crashes on memory-intensive pages (e.g. /dev/shm
        # exhaustion inside containers or resource-limited desktops).
        flags.extend(
            [
                "--headless=new",
                "--disable-dev-shm-usage",
                "--disable-gpu",
                "--disable-software-rasterizer",
            ]
        )

    # Chrome requires --no-sandbox when running as root on Linux.
    # On Linux in general (VNC desktops, containers, and cloud environments)
    # kernel namespace creation is often restricted, so --no-sandbox is needed.
    # On macOS (Darwin), --no-sandbox is unnecessary and causes Chrome to show
    # a distracting warning bar ("您使用的是不受支持的命令行标记").
    if platform.system() == "Linux" and "--no-sandbox" not in flags:
        flags.append("--no-sandbox")

    # In headed mode, start maximized so the user gets a full-screen
    # experience.  In headless mode, use a large fixed window size as a
    # fallback since --start-maximized has no effect without a display.
    if not headless and env == "desktop":
        flags.append("--start-maximized")
    else:
        flags.append("--window-size=1280,800")

    flags.append(f"--remote-debugging-port={cdp_port}")

    if user_data_dir:
        flags.append(f"--user-data-dir={user_data_dir}")

    # Auto-discover and load Chrome extensions (e.g. opencli Browser Bridge)
    if auto_load_extensions:
        ext_dirs = discover_extensions()
        if ext_dirs:
            flags.append(f"--load-extension={','.join(ext_dirs)}")

    if extra_flags:
        flags.extend(extra_flags)

    return flags


# ---------------------------------------------------------------------------
# CDP-compatible user-data-dir
# ---------------------------------------------------------------------------

# Chrome 147+ requires --user-data-dir to be a non-default path when
# --remote-debugging-port is used.  We use a dedicated LightClaw profile
# directory to avoid conflicts with the user's running Chrome instance.
_CDP_PROFILE_DIR = Path(os.path.expanduser("~/.lightclaw/chrome-cdp"))


def prepare_cdp_user_data_dir() -> str:
    """Prepare a user-data-dir that works with ``--remote-debugging-port``.

    Chrome 147+ rejects the default profile directory when CDP is enabled.
    This function returns a dedicated LightClaw profile directory
    (``~/.lightclaw/chrome-cdp``).  This is a separate profile from the
    user's Chrome — cookies are NOT shared, but it avoids profile lock
    conflicts when the user's Chrome is also running.

    To share cookies and login sessions, users should start Chrome with
    ``--remote-debugging-port=9222`` themselves, and LightClaw will
    attach to it instead of launching a new instance.

    Returns:
        Absolute path to a user-data-dir suitable for CDP.
    """
    _CDP_PROFILE_DIR.mkdir(parents=True, exist_ok=True)
    return str(_CDP_PROFILE_DIR)
