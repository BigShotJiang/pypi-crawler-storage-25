"""Loop detection and execution protection mechanism.

Implements requirement 5.3 and 6: detect repeated actions, consecutive
failures, and pages stuck without change; produce structured alerts.
"""

from __future__ import annotations

import logging
import time
from collections import deque
from dataclasses import dataclass, field
from enum import StrEnum
from typing import Any

logger = logging.getLogger(__name__)

# Thresholds
DEFAULT_MAX_REPEATED_ACTIONS = 5
DEFAULT_MAX_CONSECUTIVE_FAILURES = 3
DEFAULT_STALE_PAGE_TIMEOUT = 30.0  # seconds


class LoopAlertType(StrEnum):
    """Types of loop/protection alerts."""

    REPEATED_ACTIONS = "repeated_actions"
    CONSECUTIVE_FAILURES = "consecutive_failures"
    STALE_PAGE = "stale_page"
    ACTION_CYCLE = "action_cycle"


@dataclass(slots=True)
class LoopAlert:
    """A structured alert indicating a detected execution loop."""

    alert_type: LoopAlertType
    detail: str
    action_sequence: list[str] = field(default_factory=list)
    page_id: str = ""
    consecutive_count: int = 0
    suggested_action: str = "stop_retry"
    created_at: float = field(default_factory=time.time)

    def to_dict(self) -> dict[str, Any]:
        return {
            "alert_type": self.alert_type.value,
            "detail": self.detail,
            "action_sequence": self.action_sequence,
            "page_id": self.page_id,
            "consecutive_count": self.consecutive_count,
            "suggested_action": self.suggested_action,
            "created_at": self.created_at,
        }


@dataclass(slots=True)
class ActionRecord:
    """Record of a single browser action for loop detection."""

    action: str
    page_id: str
    success: bool
    fingerprint: str = ""
    timestamp: float = field(default_factory=time.time)


class LoopDetector:
    """Detects execution loops and protects against blind retries.

    Tracks a rolling window of recent actions and checks for:
    - Same action repeated too many times consecutively
    - Consecutive failures without any success
    - Page fingerprint unchanged for too long (stale page)
    - Short action cycles (e.g. A→B→A→B pattern)
    """

    def __init__(
        self,
        *,
        max_repeated: int = DEFAULT_MAX_REPEATED_ACTIONS,
        max_failures: int = DEFAULT_MAX_CONSECUTIVE_FAILURES,
        stale_timeout: float = DEFAULT_STALE_PAGE_TIMEOUT,
        window_size: int = 20,
    ) -> None:
        self._max_repeated = max_repeated
        self._max_failures = max_failures
        self._stale_timeout = stale_timeout
        self._window: deque[ActionRecord] = deque(maxlen=window_size)
        self._last_fingerprint: dict[str, str] = {}  # page_id -> fingerprint
        self._fingerprint_since: dict[str, float] = {}  # page_id -> timestamp
        self._alerts: list[LoopAlert] = []

        # Metrics
        self.total_alerts: int = 0

    def record_action(
        self,
        *,
        action: str,
        page_id: str,
        success: bool,
        fingerprint: str = "",
    ) -> LoopAlert | None:
        """Record an action and check for loops.

        Returns a :class:`LoopAlert` if a loop is detected, else ``None``.
        """
        record = ActionRecord(
            action=action,
            page_id=page_id,
            success=success,
            fingerprint=fingerprint,
        )
        self._window.append(record)
        self._update_fingerprint_tracking(page_id, fingerprint)

        # Check all detection rules
        alert = (
            self._check_repeated_actions()
            or self._check_consecutive_failures()
            or self._check_stale_page(page_id)
            or self._check_action_cycle()
        )

        if alert:
            self._alerts.append(alert)
            self.total_alerts += 1
            logger.warning(
                "Loop detected: type=%s detail=%s",
                alert.alert_type.value,
                alert.detail,
            )

        return alert

    def get_alerts(self, *, limit: int = 10) -> list[LoopAlert]:
        """Return recent alerts."""
        return list(self._alerts[-limit:])

    def clear(self) -> None:
        """Reset all tracking state."""
        self._window.clear()
        self._last_fingerprint.clear()
        self._fingerprint_since.clear()
        self._alerts.clear()

    def metrics(self) -> dict[str, Any]:
        return {
            "total_alerts": self.total_alerts,
            "window_size": len(self._window),
            "tracked_pages": len(self._last_fingerprint),
        }

    # -- internal checks ----------------------------------------------------

    def _check_repeated_actions(self) -> LoopAlert | None:
        """Detect the same action repeated too many times consecutively."""
        if len(self._window) < self._max_repeated:
            return None

        recent = list(self._window)[-self._max_repeated :]
        first_action = recent[0].action
        first_page = recent[0].page_id

        if all(r.action == first_action and r.page_id == first_page for r in recent):
            return LoopAlert(
                alert_type=LoopAlertType.REPEATED_ACTIONS,
                detail=f"Action '{first_action}' repeated {self._max_repeated} times on {first_page}",
                action_sequence=[r.action for r in recent],
                page_id=first_page,
                consecutive_count=self._max_repeated,
                suggested_action="stop_retry_try_alternative",
            )
        return None

    def _check_consecutive_failures(self) -> LoopAlert | None:
        """Detect too many consecutive failures without any success."""
        if len(self._window) < self._max_failures:
            return None

        recent = list(self._window)[-self._max_failures :]
        if all(not r.success for r in recent):
            return LoopAlert(
                alert_type=LoopAlertType.CONSECUTIVE_FAILURES,
                detail=f"{self._max_failures} consecutive failures detected",
                action_sequence=[r.action for r in recent],
                page_id=recent[-1].page_id,
                consecutive_count=self._max_failures,
                suggested_action="escalate_or_abort",
            )
        return None

    def _check_stale_page(self, page_id: str) -> LoopAlert | None:
        """Detect when a page hasn't changed for too long."""
        since = self._fingerprint_since.get(page_id)
        if since is None:
            return None

        elapsed = time.time() - since
        if elapsed > self._stale_timeout:
            return LoopAlert(
                alert_type=LoopAlertType.STALE_PAGE,
                detail=f"Page '{page_id}' unchanged for {elapsed:.1f}s",
                page_id=page_id,
                suggested_action="refresh_or_navigate",
            )
        return None

    def _check_action_cycle(self) -> LoopAlert | None:
        """Detect short action cycles (A→B→A→B)."""
        if len(self._window) < 4:
            return None

        recent = list(self._window)[-4:]
        actions = [r.action for r in recent]

        # Check for A-B-A-B pattern
        if actions[0] == actions[2] and actions[1] == actions[3] and actions[0] != actions[1]:
            return LoopAlert(
                alert_type=LoopAlertType.ACTION_CYCLE,
                detail=f"Action cycle detected: {actions[0]}→{actions[1]} repeated",
                action_sequence=actions,
                page_id=recent[-1].page_id,
                suggested_action="break_cycle_try_different_approach",
            )
        return None

    def _update_fingerprint_tracking(
        self,
        page_id: str,
        fingerprint: str,
    ) -> None:
        """Update fingerprint tracking for stale page detection."""
        if not fingerprint:
            return

        current = self._last_fingerprint.get(page_id)
        if current != fingerprint:
            self._last_fingerprint[page_id] = fingerprint
            self._fingerprint_since[page_id] = time.time()
        elif page_id not in self._fingerprint_since:
            self._fingerprint_since[page_id] = time.time()
