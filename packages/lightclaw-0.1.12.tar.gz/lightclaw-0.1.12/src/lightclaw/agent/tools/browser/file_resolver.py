"""Server-side image file resolution and security validation.

Resolves Agent-provided file references (paths, identifiers, directory
rules) into validated absolute paths that are safe to inject into the
browser FileChooser.
"""

from __future__ import annotations

import logging
import mimetypes
import os
from pathlib import Path

from lightclaw.agent.tools.browser.upload_models import UploadErrorCode, UploadFileSpec, UploadPhase, UploadResult

logger = logging.getLogger(__name__)

# ---------------------------------------------------------------------------
# Configuration
# ---------------------------------------------------------------------------

_DEFAULT_ALLOWED_DIRS: list[str] = [
    os.path.expanduser("~/lightclaw/uploads"),
    os.path.expanduser("~/lightclaw/images"),
    "/tmp/lightclaw/uploads",
]

ALLOWED_MIME_PREFIXES: tuple[str, ...] = ("image/",)

MAX_FILE_SIZE_BYTES: int = 20 * 1024 * 1024


class FileResolver:
    """Resolve and validate server-side image files for browser upload."""

    def __init__(
        self,
        allowed_dirs: list[str] | None = None,
        max_file_size: int = MAX_FILE_SIZE_BYTES,
        allowed_mime_prefixes: tuple[str, ...] = ALLOWED_MIME_PREFIXES,
    ) -> None:
        raw_dirs = allowed_dirs if allowed_dirs is not None else _DEFAULT_ALLOWED_DIRS
        self._allowed_dirs: list[Path] = [Path(d).expanduser().resolve() for d in raw_dirs]
        self._max_file_size = max_file_size
        self._allowed_mime_prefixes = allowed_mime_prefixes

    def resolve_and_validate(
        self,
        specs: list[UploadFileSpec],
        base_directory: str = "",
    ) -> UploadResult:
        """Resolve *UploadFileSpec* list into validated absolute paths."""
        if not specs:
            return UploadResult.failure(
                phase=UploadPhase.RESOLVE,
                error_code=UploadErrorCode.FILE_NOT_FOUND,
                error_message="No files specified.",
            )

        resolved: list[str] = []
        for spec in specs:
            path = self._resolve_single(spec, base_directory)
            if path is None:
                return UploadResult.failure(
                    phase=UploadPhase.RESOLVE,
                    error_code=UploadErrorCode.FILE_NOT_FOUND,
                    error_message=(f"Cannot resolve file: path={spec.path!r}, identifier={spec.identifier!r}"),
                )

            boundary_err = self._check_boundary(path)
            if boundary_err is not None:
                return boundary_err

            validation_err = self._validate_file(path)
            if validation_err is not None:
                return validation_err

            resolved.append(str(path))

        return UploadResult(
            ok=True,
            phase=UploadPhase.VALIDATE,
            resolved_paths=resolved,
            files_injected=0,
        )

    # -- Internal helpers ---------------------------------------------------

    def _resolve_single(
        self,
        spec: UploadFileSpec,
        base_directory: str,
    ) -> Path | None:
        """Return the canonical Path for a single spec, or None."""
        if spec.path:
            p = Path(spec.path).expanduser()
            if not p.is_absolute() and base_directory:
                p = Path(base_directory).expanduser() / p
            return p.resolve()

        if spec.identifier:
            candidates = self._find_by_identifier(spec.identifier, base_directory)
            if len(candidates) == 1:
                return candidates[0]
            if len(candidates) > 1:
                logger.warning(
                    "Identifier %r matched %d files — ambiguous.",
                    spec.identifier,
                    len(candidates),
                )
                return None
        return None

    def _find_by_identifier(
        self,
        identifier: str,
        base_directory: str,
    ) -> list[Path]:
        """Search allowed dirs for files whose stem matches identifier."""
        search_dirs = list(self._allowed_dirs)
        if base_directory:
            bd = Path(base_directory).expanduser().resolve()
            if bd not in search_dirs:
                search_dirs.append(bd)

        matches: list[Path] = []
        lower_id = identifier.lower()
        for d in search_dirs:
            if not d.is_dir():
                continue
            for child in d.iterdir():
                if child.is_file() and child.stem.lower() == lower_id:
                    matches.append(child.resolve())
        return matches

    def _check_boundary(self, path: Path) -> UploadResult | None:
        """Return a failure if path escapes all allowed directories."""
        resolved = path.resolve()

        if path.is_symlink():
            real = Path(os.path.realpath(path))
            if not any(self._is_under(real, ad) for ad in self._allowed_dirs):
                logger.warning("Symlink %s resolves outside allowed dirs.", path)
                return UploadResult.failure(
                    phase=UploadPhase.VALIDATE,
                    error_code=UploadErrorCode.PATH_TRAVERSAL,
                    error_message=f"Symlink target escapes allowed directories: {path}",
                )

        if not any(self._is_under(resolved, ad) for ad in self._allowed_dirs):
            return UploadResult.failure(
                phase=UploadPhase.VALIDATE,
                error_code=UploadErrorCode.PATH_NOT_ALLOWED,
                error_message=f"Path is outside allowed upload directories: {resolved}",
            )
        return None

    def _validate_file(self, path: Path) -> UploadResult | None:
        """Return a failure if file is missing, unreadable, wrong type or too large."""
        if not path.exists():
            return UploadResult.failure(
                phase=UploadPhase.VALIDATE,
                error_code=UploadErrorCode.FILE_NOT_FOUND,
                error_message=f"File does not exist: {path}",
            )

        if not path.is_file():
            return UploadResult.failure(
                phase=UploadPhase.VALIDATE,
                error_code=UploadErrorCode.FILE_NOT_FOUND,
                error_message=f"Not a regular file: {path}",
            )

        if not os.access(path, os.R_OK):
            return UploadResult.failure(
                phase=UploadPhase.VALIDATE,
                error_code=UploadErrorCode.PERMISSION_DENIED,
                error_message=f"File is not readable: {path}",
            )

        mime, _ = mimetypes.guess_type(str(path))
        if mime is None or not any(mime.startswith(prefix) for prefix in self._allowed_mime_prefixes):
            return UploadResult.failure(
                phase=UploadPhase.VALIDATE,
                error_code=UploadErrorCode.INVALID_TYPE,
                error_message=f"File type not allowed: {mime or 'unknown'} ({path.name})",
            )

        try:
            size = path.stat().st_size
        except OSError as exc:
            return UploadResult.failure(
                phase=UploadPhase.VALIDATE,
                error_code=UploadErrorCode.FILE_UNREADABLE,
                error_message=f"Cannot stat file: {exc}",
            )

        if size > self._max_file_size:
            return UploadResult.failure(
                phase=UploadPhase.VALIDATE,
                error_code=UploadErrorCode.FILE_TOO_LARGE,
                error_message=(f"File too large: {size} bytes (max {self._max_file_size} bytes)"),
            )

        return None

    @staticmethod
    def _is_under(path: Path, directory: Path) -> bool:
        """Check whether path is equal to or nested under directory."""
        try:
            path.relative_to(directory)
            return True
        except ValueError:
            return False
