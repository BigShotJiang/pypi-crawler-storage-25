"""Upload control compatibility helpers for blog-site upload widgets.

Provides strategies to detect and trigger various upload entry points:
- Native ``input[type=file]`` (visible or hidden)
- Component-wrapped uploaders (Ant Design, Element UI, etc.)
- Drag-and-drop upload areas
- Iframe-embedded upload controls

When a strategy cannot handle a particular control type it returns a
clear reason string instead of silently failing.
"""

from __future__ import annotations

import logging
from dataclasses import dataclass
from typing import Any

logger = logging.getLogger(__name__)

# ---------------------------------------------------------------------------
# Detection result
# ---------------------------------------------------------------------------


@dataclass
class UploadControlInfo:
    """Describes a detected upload control on the page."""

    strategy: str  # "native_input" | "component_button" | "dropzone" | "iframe" | "unknown"
    selector: str  # CSS selector that can trigger the upload
    is_hidden: bool = False
    is_multiple: bool = False
    accept_types: str = ""
    frame_selector: str = ""  # Non-empty when the control lives inside an iframe
    description: str = ""

    def to_dict(self) -> dict[str, Any]:
        d: dict[str, Any] = {
            "strategy": self.strategy,
            "selector": self.selector,
        }
        if self.is_hidden:
            d["is_hidden"] = True
        if self.is_multiple:
            d["is_multiple"] = True
        if self.accept_types:
            d["accept_types"] = self.accept_types
        if self.frame_selector:
            d["frame_selector"] = self.frame_selector
        if self.description:
            d["description"] = self.description
        return d


# ---------------------------------------------------------------------------
# JS snippets executed inside the page
# ---------------------------------------------------------------------------

_DETECT_UPLOAD_CONTROLS_JS = """
(() => {
    const results = [];

    // 1. Native input[type=file]
    const fileInputs = document.querySelectorAll('input[type="file"]');
    for (const el of fileInputs) {
        const rect = el.getBoundingClientRect();
        const isHidden = (
            el.offsetParent === null
            || rect.width === 0
            || rect.height === 0
            || getComputedStyle(el).display === 'none'
            || getComputedStyle(el).visibility === 'hidden'
        );
        results.push({
            strategy: 'native_input',
            selector: buildSelector(el),
            is_hidden: isHidden,
            is_multiple: el.multiple,
            accept_types: el.accept || '',
            description: isHidden
                ? 'Hidden file input (triggered by a visible button)'
                : 'Visible file input',
        });
    }

    // 2. Component-wrapped uploaders (common class names / roles)
    const uploadBtnSelectors = [
        '.ant-upload button',
        '.ant-upload .ant-btn',
        '.el-upload__input',
        '.el-upload',
        '[class*="upload"] button',
        '[class*="Upload"] button',
        'button[class*="upload"]',
        '[role="button"][class*="upload"]',
    ];
    for (const sel of uploadBtnSelectors) {
        const els = document.querySelectorAll(sel);
        for (const el of els) {
            if (el.offsetParent !== null) {
                results.push({
                    strategy: 'component_button',
                    selector: buildSelector(el),
                    is_hidden: false,
                    is_multiple: false,
                    accept_types: '',
                    description: `Component upload button: ${sel}`,
                });
            }
        }
    }

    // 3. Drag-and-drop areas
    const dropzoneSelectors = [
        '.ant-upload-drag',
        '.el-upload-dragger',
        '[class*="dropzone"]',
        '[class*="Dropzone"]',
        '[class*="drag-upload"]',
    ];
    for (const sel of dropzoneSelectors) {
        const els = document.querySelectorAll(sel);
        for (const el of els) {
            if (el.offsetParent !== null) {
                results.push({
                    strategy: 'dropzone',
                    selector: buildSelector(el),
                    is_hidden: false,
                    is_multiple: false,
                    accept_types: '',
                    description: `Drag-and-drop upload area: ${sel}`,
                });
            }
        }
    }

    return results;

    function buildSelector(el) {
        if (el.id) return '#' + el.id;
        const tag = el.tagName.toLowerCase();
        const classes = [...el.classList].slice(0, 2).join('.');
        const nth = getNthOfType(el);
        let sel = tag;
        if (classes) sel += '.' + classes;
        if (nth > 1) sel += ':nth-of-type(' + nth + ')';
        return sel;
    }

    function getNthOfType(el) {
        let idx = 1;
        let sib = el.previousElementSibling;
        while (sib) {
            if (sib.tagName === el.tagName) idx++;
            sib = sib.previousElementSibling;
        }
        return idx;
    }
})()
"""

_TRIGGER_HIDDEN_INPUT_JS = """
((selector) => {
    const el = document.querySelector(selector);
    if (!el) return { ok: false, error: 'Element not found: ' + selector };
    el.click();
    return { ok: true };
})
"""


# ---------------------------------------------------------------------------
# Public API
# ---------------------------------------------------------------------------


async def detect_upload_controls(page: Any) -> list[UploadControlInfo]:
    """Scan the page for recognisable upload controls.

    Returns a list of ``UploadControlInfo`` ordered by preference (native
    inputs first, then component buttons, then dropzones).
    """
    try:
        raw = await page.evaluate(_DETECT_UPLOAD_CONTROLS_JS)
    except Exception as exc:
        logger.warning("detect_upload_controls failed: %s", exc)
        return []

    if not isinstance(raw, list):
        return []

    controls: list[UploadControlInfo] = []
    for item in raw:
        if not isinstance(item, dict):
            continue
        controls.append(
            UploadControlInfo(
                strategy=item.get("strategy", "unknown"),
                selector=item.get("selector", ""),
                is_hidden=item.get("is_hidden", False),
                is_multiple=item.get("is_multiple", False),
                accept_types=item.get("accept_types", ""),
                description=item.get("description", ""),
            ),
        )

    # Also check for iframes that might contain upload controls.
    try:
        iframes = await page.query_selector_all("iframe")
        for iframe in iframes:
            try:
                frame = await iframe.content_frame()
                if frame is None:
                    continue
                frame_raw = await frame.evaluate(_DETECT_UPLOAD_CONTROLS_JS)
                if isinstance(frame_raw, list):
                    frame_sel = await _build_iframe_selector(page, iframe)
                    for item in frame_raw:
                        if isinstance(item, dict):
                            controls.append(
                                UploadControlInfo(
                                    strategy=item.get("strategy", "unknown"),
                                    selector=item.get("selector", ""),
                                    is_hidden=item.get("is_hidden", False),
                                    is_multiple=item.get("is_multiple", False),
                                    accept_types=item.get("accept_types", ""),
                                    frame_selector=frame_sel,
                                    description=(f"[iframe] {item.get('description', '')}"),
                                ),
                            )
            except Exception:
                continue
    except Exception:
        pass

    return controls


async def trigger_upload_control(
    page: Any,
    control: UploadControlInfo,
) -> dict[str, Any]:
    """Click / activate the detected upload control so the FileChooser fires.

    Returns ``{"ok": True}`` on success or ``{"ok": False, "error": "..."}``
    with a human-readable reason.
    """
    target = page
    if control.frame_selector:
        try:
            iframe_el = await page.query_selector(control.frame_selector)
            if iframe_el is None:
                return {
                    "ok": False,
                    "error": f"Iframe not found: {control.frame_selector}",
                }
            target = await iframe_el.content_frame()
            if target is None:
                return {"ok": False, "error": "Cannot access iframe content frame."}
        except Exception as exc:
            return {"ok": False, "error": f"Iframe access failed: {exc}"}

    if control.strategy == "native_input" and control.is_hidden:
        # For hidden inputs, directly invoke .click() via JS.
        try:
            result = await target.evaluate(
                f"({_TRIGGER_HIDDEN_INPUT_JS})('{control.selector}')",
            )
            if isinstance(result, dict) and not result.get("ok"):
                return result
            return {"ok": True}
        except Exception as exc:
            return {"ok": False, "error": f"Hidden input trigger failed: {exc}"}

    # Default: click the element via Playwright.
    try:
        await target.click(control.selector, timeout=5000)
        return {"ok": True}
    except Exception as exc:
        return {
            "ok": False,
            "error": f"Click on '{control.selector}' failed: {exc}",
        }


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


async def _build_iframe_selector(page: Any, iframe_element: Any) -> str:
    """Best-effort CSS selector for an iframe element."""
    try:
        el_id = await iframe_element.get_attribute("id")
        if el_id:
            return f"iframe#{el_id}"
        name = await iframe_element.get_attribute("name")
        if name:
            return f"iframe[name='{name}']"
        src = await iframe_element.get_attribute("src")
        if src:
            return f"iframe[src='{src}']"
    except Exception:
        pass
    return "iframe"
