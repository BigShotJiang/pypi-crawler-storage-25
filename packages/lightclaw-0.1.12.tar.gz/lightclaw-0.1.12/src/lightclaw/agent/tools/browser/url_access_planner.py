"""URL Access Planner — decides whether to fetch a URL via direct HTTP or browser.

Implements a lightweight decision layer that sits in front of the browser
stack.  For each URL it:

1. Checks the always-browser domain registry → skip directly to browser.
2. Performs a lightweight HTTP pre-fetch (via ``DirectFetcher``) → checks
   content sufficiency and blocking signals.
3. Returns a unified ``UrlAccessResult`` regardless of the chosen path.
"""

from __future__ import annotations

import logging
from dataclasses import dataclass, field
from enum import StrEnum

logger = logging.getLogger(__name__)


# ---------------------------------------------------------------------------
# Enums
# ---------------------------------------------------------------------------


class UrlAccessMode(StrEnum):
    """How the URL should be (or was) accessed."""

    DIRECT = "direct"
    BROWSER = "browser"
    AUTO = "auto"


# ---------------------------------------------------------------------------
# Unified result structure
# ---------------------------------------------------------------------------


@dataclass
class UrlAccessResult:
    """Unified result returned by the planner regardless of access path."""

    ok: bool = False
    url: str = ""
    mode: UrlAccessMode = UrlAccessMode.BROWSER
    content_type: str = ""
    text: str = ""
    html: str | None = None
    status_code: int | None = None
    decision_reason: str = ""
    blocking_signals: list[str] = field(default_factory=list)
    error: str | None = None

    def to_tool_response_dict(self) -> dict:
        """Convert to a dict compatible with ``_action_open`` / ``_action_navigate`` JSON output."""
        result: dict = {
            "ok": self.ok,
            "url": self.url,
            "access_mode": str(self.mode),
            "decision_reason": self.decision_reason,
        }
        if self.text:
            result["page_text"] = self.text
        if self.content_type:
            result["content_type"] = self.content_type
        if self.status_code is not None:
            result["status_code"] = self.status_code
        if self.blocking_signals:
            result["blocking_signals"] = self.blocking_signals
        if self.error:
            result["error"] = self.error
        if self.ok and self.mode == UrlAccessMode.DIRECT:
            result["message"] = (
                f"Page fetched via direct HTTP (reason: {self.decision_reason}). Content is available in page_text."
            )
        return result


# ---------------------------------------------------------------------------
# Planner (decision engine)
# ---------------------------------------------------------------------------


class UrlAccessPlanner:
    """Decide how to access a URL: direct HTTP or browser.

    Decision tree (AUTO mode):

    1. Domain in always-browser list → ``BROWSER``
    2. HTTP pre-fetch via ``DirectFetcher``
       a. Fetch failed (4xx/5xx/timeout) → ``BROWSER``
       b. Redirect landed on always-browser domain → ``BROWSER``
       c. Content-Type is non-HTML → ``DIRECT`` (return as-is)
       d. Visible text < threshold → ``BROWSER``
       e. Blocking keywords detected → ``BROWSER``
       f. Otherwise → ``DIRECT``
    """

    async def plan(
        self,
        url: str,
        mode: UrlAccessMode = UrlAccessMode.AUTO,
    ) -> UrlAccessResult:
        """Run the decision tree and return a unified result.

        Args:
            url: The target URL to evaluate.
            mode: ``AUTO`` (default) runs the full decision tree.
                  ``BROWSER`` skips the planner entirely.
                  ``DIRECT`` forces direct fetch without fallback.

        Returns:
            An ``UrlAccessResult`` describing the decision and (for DIRECT
            paths) the fetched content.
        """
        # -- Explicit BROWSER mode: skip planner entirely ------------------
        if mode == UrlAccessMode.BROWSER:
            reason = "explicit_browser_mode"
            logger.info("URL planner: %s → %s", url, reason)
            return UrlAccessResult(
                ok=False,
                url=url,
                mode=UrlAccessMode.BROWSER,
                decision_reason=reason,
            )

        # Lazy import to avoid circular dependencies at module level
        from lightclaw.agent.tools.browser.direct_fetcher import (
            DirectFetcher,
            check_content_sufficiency,
            scan_blocking_keywords,
        )
        from lightclaw.agent.tools.browser.domain_registry import is_always_browser

        # -- AUTO mode: step 1 — always-browser domain check --------------
        if mode == UrlAccessMode.AUTO and is_always_browser(url):
            reason = f"domain_hit:{url}→browser"
            logger.info("URL planner: %s", reason)
            return UrlAccessResult(
                ok=False,
                url=url,
                mode=UrlAccessMode.BROWSER,
                decision_reason=reason,
            )

        # -- Step 2: HTTP pre-fetch ----------------------------------------
        fetcher = DirectFetcher()
        fetch_result = await fetcher.fetch(url)

        # 2a. Redirect landed on always-browser domain
        if fetch_result.redirected_to_browser_domain:
            reason = f"redirect_to_browser_domain:{fetch_result.final_url}"
            logger.info("URL planner: %s", reason)
            return UrlAccessResult(
                ok=False,
                url=fetch_result.final_url,
                mode=UrlAccessMode.BROWSER,
                decision_reason=reason,
            )

        # 2b. Fetch failed
        if not fetch_result.ok:
            if mode == UrlAccessMode.DIRECT:
                # DIRECT mode: do NOT auto-upgrade — report failure
                reason = f"direct_fetch_failed:{fetch_result.error}"
                logger.info("URL planner (DIRECT mode): %s", reason)
                return UrlAccessResult(
                    ok=False,
                    url=fetch_result.final_url or url,
                    mode=UrlAccessMode.DIRECT,
                    status_code=fetch_result.status_code or None,
                    decision_reason=reason,
                    error=fetch_result.error,
                )
            reason = f"prefetch_failed:{fetch_result.error}→browser"
            logger.info("URL planner: %s", reason)
            return UrlAccessResult(
                ok=False,
                url=fetch_result.final_url or url,
                mode=UrlAccessMode.BROWSER,
                status_code=fetch_result.status_code or None,
                decision_reason=reason,
            )

        # 2c. Content-Type is non-HTML → always sufficient
        ct = fetch_result.content_type
        is_sufficient, visible_text = check_content_sufficiency(
            fetch_result.html,
            content_type=ct,
        )

        # 2d. Visible text below threshold
        if not is_sufficient:
            if mode == UrlAccessMode.DIRECT:
                reason = "direct_mode:text_insufficient_no_upgrade"
                logger.info("URL planner (DIRECT mode): %s", reason)
                return UrlAccessResult(
                    ok=True,
                    url=fetch_result.final_url,
                    mode=UrlAccessMode.DIRECT,
                    content_type=ct,
                    text=visible_text,
                    html=fetch_result.html,
                    status_code=fetch_result.status_code,
                    decision_reason=reason,
                )
            reason = f"text_insufficient({len(visible_text)}chars)→browser"
            logger.info("URL planner: %s", reason)
            return UrlAccessResult(
                ok=False,
                url=fetch_result.final_url,
                mode=UrlAccessMode.BROWSER,
                content_type=ct,
                status_code=fetch_result.status_code,
                decision_reason=reason,
            )

        # 2e. Blocking keyword scan (only for HTML)
        blocking: list[str] = []
        ct_lower = ct.lower().split(";")[0].strip()
        if not ct_lower or ct_lower == "text/html":
            blocking = scan_blocking_keywords(fetch_result.html)

        if blocking:
            if mode == UrlAccessMode.DIRECT:
                reason = f"direct_mode:blocking_signals({','.join(blocking)})_no_upgrade"
                logger.info("URL planner (DIRECT mode): %s", reason)
                return UrlAccessResult(
                    ok=True,
                    url=fetch_result.final_url,
                    mode=UrlAccessMode.DIRECT,
                    content_type=ct,
                    text=visible_text,
                    html=fetch_result.html,
                    status_code=fetch_result.status_code,
                    decision_reason=reason,
                    blocking_signals=blocking,
                )
            reason = f"blocking_signals({','.join(blocking)})→browser"
            logger.info("URL planner: %s", reason)
            return UrlAccessResult(
                ok=False,
                url=fetch_result.final_url,
                mode=UrlAccessMode.BROWSER,
                content_type=ct,
                status_code=fetch_result.status_code,
                decision_reason=reason,
                blocking_signals=blocking,
            )

        # 2f. All checks passed → return direct content
        reason = "prefetch_ok:text_sufficient→direct"
        logger.info("URL planner: %s", reason)
        return UrlAccessResult(
            ok=True,
            url=fetch_result.final_url,
            mode=UrlAccessMode.DIRECT,
            content_type=ct,
            text=visible_text,
            html=fetch_result.html,
            status_code=fetch_result.status_code,
            decision_reason=reason,
        )
