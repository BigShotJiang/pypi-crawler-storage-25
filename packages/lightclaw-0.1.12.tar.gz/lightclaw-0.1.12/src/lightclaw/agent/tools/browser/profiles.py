"""Named browser profile management with CRUD operations, CDP port
allocation, color assignment, and JSON-file persistence.

Ported from openclaw/src/browser/profiles.ts and profiles-service.ts.
"""

from __future__ import annotations

import contextlib
import json
import logging
import os
import re
import shutil
import socket
import time
from dataclasses import asdict, dataclass
from pathlib import Path
from typing import Any

logger = logging.getLogger(__name__)

# ---------------------------------------------------------------------------
# Constants
# ---------------------------------------------------------------------------
CDP_PORT_RANGE_START = 18800
CDP_PORT_RANGE_END = 18899

PROFILE_NAME_RE = re.compile(r"^[a-z0-9][a-z0-9-]*$")

DEFAULT_PROFILE_NAME = "default"

# Pre-defined color palette for profile visual distinction
_COLOR_PALETTE = [
    "#FF6B35",  # orange
    "#3498DB",  # blue
    "#2ECC71",  # green
    "#9B59B6",  # purple
    "#E74C3C",  # red
    "#1ABC9C",  # teal
    "#F39C12",  # yellow
    "#E91E63",  # pink
    "#00BCD4",  # cyan
    "#8BC34A",  # light-green
]


# ---------------------------------------------------------------------------
# Data model
# ---------------------------------------------------------------------------


@dataclass
class BrowserProfile:
    """A named browser profile with its own user-data-dir and CDP port."""

    name: str
    cdp_port: int
    color: str
    user_data_dir: str
    created_at: float = 0.0
    last_auth_at: float = 0.0
    last_used_at: float = 0.0

    def to_dict(self) -> dict[str, Any]:
        return asdict(self)

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> BrowserProfile:
        return cls(
            name=data["name"],
            cdp_port=data.get("cdp_port", CDP_PORT_RANGE_START),
            color=data.get("color", _COLOR_PALETTE[0]),
            user_data_dir=data.get("user_data_dir", ""),
            created_at=data.get("created_at", 0.0),
            last_auth_at=data.get("last_auth_at", 0.0),
            last_used_at=data.get("last_used_at", 0.0),
        )


# ---------------------------------------------------------------------------
# Profile manager
# ---------------------------------------------------------------------------


class ProfileManager:
    """CRUD manager for browser profiles.

    Profiles are persisted to ``~/.lightclaw/browser-profiles/profiles.json``.
    Each profile gets its own ``user-data-dir`` sub-directory and a unique
    CDP port in the 18800-18899 range.
    """

    def __init__(self, base_dir: str | None = None) -> None:
        self._base_dir = Path(
            base_dir or os.path.expanduser("~/.lightclaw/browser-profiles"),
        )
        self._profiles_file = self._base_dir / "profiles.json"
        self._profiles: dict[str, BrowserProfile] = {}
        self._load()
        self._ensure_default_profile()

    # -- persistence --------------------------------------------------------

    def _load(self) -> None:
        """Load profiles from disk."""
        if not self._profiles_file.exists():
            self._profiles = {}
            return
        try:
            with open(self._profiles_file, encoding="utf-8") as f:
                data = json.load(f)
            self._profiles = {name: BrowserProfile.from_dict(entry) for name, entry in data.items()}
            logger.debug("Loaded %d browser profile(s)", len(self._profiles))
        except (json.JSONDecodeError, KeyError, TypeError) as exc:
            logger.warning("Failed to load profiles: %s — starting fresh", exc)
            self._profiles = {}

    def _save(self) -> None:
        """Persist profiles to disk."""
        self._base_dir.mkdir(parents=True, exist_ok=True)
        data = {name: p.to_dict() for name, p in self._profiles.items()}
        tmp = self._profiles_file.with_suffix(".tmp")
        with open(tmp, "w", encoding="utf-8") as f:
            json.dump(data, f, indent=2, ensure_ascii=False)
        tmp.replace(self._profiles_file)

    # -- default profile ----------------------------------------------------

    def _ensure_default_profile(self) -> None:
        """Create the ``default`` profile if it does not exist."""
        if DEFAULT_PROFILE_NAME not in self._profiles:
            self.create_profile(DEFAULT_PROFILE_NAME)

    # -- CRUD ---------------------------------------------------------------

    def create_profile(self, name: str) -> BrowserProfile:
        """Create a new named profile.

        Raises:
            ValueError: If the name is invalid or already exists.
        """
        if not is_valid_profile_name(name):
            raise ValueError(
                f"Invalid profile name '{name}'. Must match {PROFILE_NAME_RE.pattern}",
            )
        if name in self._profiles:
            raise ValueError(f"Profile '{name}' already exists")

        cdp_port = self._allocate_cdp_port()
        color = self._allocate_color()
        user_data_dir = str(self._base_dir / name / "user-data")
        Path(user_data_dir).mkdir(parents=True, exist_ok=True)

        profile = BrowserProfile(
            name=name,
            cdp_port=cdp_port,
            color=color,
            user_data_dir=user_data_dir,
            created_at=time.time(),
        )
        self._profiles[name] = profile
        self._save()
        logger.info(
            "Created browser profile '%s' (port=%d, color=%s)",
            name,
            cdp_port,
            color,
        )
        return profile

    def get_profile(self, name: str) -> BrowserProfile | None:
        """Return a profile by name, or ``None``."""
        return self._profiles.get(name)

    def list_profiles(self) -> list[BrowserProfile]:
        """Return all profiles sorted by creation time."""
        return sorted(self._profiles.values(), key=lambda p: p.created_at)

    def delete_profile(self, name: str) -> bool:
        """Delete a profile and clean up its user-data-dir.

        Returns:
            ``True`` if the profile was found and deleted.
        """
        profile = self._profiles.pop(name, None)
        if profile is None:
            return False
        # Clean up user-data-dir
        udd = Path(profile.user_data_dir)
        if udd.exists():
            try:
                shutil.rmtree(udd)
                logger.info("Removed user-data-dir for profile '%s'", name)
            except OSError as exc:
                logger.warning(
                    "Failed to remove user-data-dir for '%s': %s",
                    name,
                    exc,
                )
        # Also remove the profile directory itself if empty
        profile_dir = self._base_dir / name
        if profile_dir.exists():
            with contextlib.suppress(OSError):  # not empty — that's fine
                profile_dir.rmdir()
        self._save()
        logger.info("Deleted browser profile '%s'", name)
        return True

    def touch_used(self, name: str) -> None:
        """Update ``last_used_at`` timestamp."""
        profile = self._profiles.get(name)
        if profile:
            profile.last_used_at = time.time()
            self._save()

    def touch_auth(self, name: str) -> None:
        """Update ``last_auth_at`` timestamp."""
        profile = self._profiles.get(name)
        if profile:
            profile.last_auth_at = time.time()
            self._save()

    # -- port and color allocation ------------------------------------------

    def _allocate_cdp_port(self) -> int:
        """Find the next available CDP port in the range 18800–18899.

        Checks both existing profile assignments and live port availability.
        """
        used_ports = {p.cdp_port for p in self._profiles.values()}
        for port in range(CDP_PORT_RANGE_START, CDP_PORT_RANGE_END + 1):
            if port in used_ports:
                continue
            if _is_port_available(port):
                return port
        raise RuntimeError(
            f"No available CDP port in range {CDP_PORT_RANGE_START}–{CDP_PORT_RANGE_END}",
        )

    def _allocate_color(self) -> str:
        """Assign the next unused color from the palette."""
        used_colors = {p.color for p in self._profiles.values()}
        for color in _COLOR_PALETTE:
            if color not in used_colors:
                return color
        # Wrap around if all colors are used
        idx = len(self._profiles) % len(_COLOR_PALETTE)
        return _COLOR_PALETTE[idx]


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def is_valid_profile_name(name: str) -> bool:
    """Return ``True`` if *name* matches ``^[a-z0-9][a-z0-9-]*$``."""
    return bool(PROFILE_NAME_RE.match(name))


def _is_port_available(port: int) -> bool:
    """Quick check whether *port* is free on localhost."""
    try:
        with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
            s.settimeout(0.2)
            s.bind(("127.0.0.1", port))
            return True
    except OSError:
        return False
