"""Screenshot streaming service and authentication page detection.

Provides:
- ``ScreenshotStreamer``: captures page screenshots at configurable intervals
  and yields base64 PNG frames for SSE streaming.
- ``AuthPageDetector``: heuristic detection of authentication pages (QR codes,
  CAPTCHA inputs, SSO redirects) with Chat notification integration.
"""

from __future__ import annotations

import asyncio
import base64
import logging
import re
import time
from collections.abc import AsyncIterator, Awaitable, Callable
from dataclasses import dataclass
from typing import Any

from lightclaw.agent.tools.browser.session import BrowserSession, ControlOwner, SessionState

logger = logging.getLogger(__name__)


# ---------------------------------------------------------------------------
# Screenshot streamer
# ---------------------------------------------------------------------------


@dataclass
class ScreenshotFrame:
    """A single screenshot frame."""

    data_b64: str
    url: str
    timestamp: float
    width: int = 0
    height: int = 0


class ScreenshotStreamer:
    """Captures periodic screenshots from a browser session.

    Usage::

        streamer = ScreenshotStreamer(session, interval=1.5)
        async for frame in streamer.stream():
            # send frame.data_b64 via SSE
            ...
    """

    def __init__(
        self,
        session: BrowserSession,
        interval: float = 1.5,
    ) -> None:
        self._session = session
        self._interval = interval
        self._running = False

    async def stream(self) -> AsyncIterator[ScreenshotFrame]:
        """Yield screenshot frames until stopped or session ends."""
        self._running = True
        while self._running:
            frame = await self._capture()
            if frame:
                yield frame
            await asyncio.sleep(self._interval)

    def stop(self) -> None:
        self._running = False

    async def _capture(self) -> ScreenshotFrame | None:
        """Take a single screenshot of the active page."""
        session = self._session
        if not session.cdp or not session.cdp.context:
            return None
        try:
            pages = session.cdp.context.pages
            if not pages:
                return None
            page = pages[0]
            session.current_url = page.url
            png_bytes = await page.screenshot(type="png")
            b64 = base64.b64encode(png_bytes).decode("ascii")
            return ScreenshotFrame(
                data_b64=b64,
                url=page.url,
                timestamp=time.time(),
            )
        except Exception as exc:
            logger.debug("Screenshot capture error: %s", exc)
            return None

    async def capture_once(self) -> ScreenshotFrame | None:
        """Public method for one-off capture."""
        return await self._capture()


# ---------------------------------------------------------------------------
# Auth page detection
# ---------------------------------------------------------------------------

# URL patterns that commonly indicate login / auth pages
_AUTH_URL_PATTERNS = re.compile(
    r"(login|signin|sign-in|auth|oauth|sso|passport|cas/login|accounts\.google|"
    r"open\.weixin\.qq|qr\.alipay|connect/authorize)",
    re.IGNORECASE,
)

# Page content heuristics
_QR_CODE_INDICATORS = [
    "qr-code",
    "qrcode",
    "scan-qr",
    "scan_qr",
    "wechat-qr",
    "扫描二维码",
    "扫码登录",
    "请使用微信扫一扫",
]

_CAPTCHA_INDICATORS = [
    "captcha",
    "recaptcha",
    "verify-code",
    "verification-code",
    "sms-code",
    "输入验证码",
    "请输入短信验证码",
    "滑动解锁",
    "滑动验证",
    "请完成安全验证",
    "slide to verify",
    "slide to unlock",
    "drag the slider",
    "please click to verify",
    "unusual traffic",
    "detected unusual traffic",
    "not a robot",
    "i'm not a robot",
    "人机验证",
    "拖动滑块",
    "请按住滑块",
    "拼图验证",
    "图形验证",
    "点击验证",
]

# Indicators that the user is already logged in.  When these are present
# in the page, the page is very likely *not* an auth page even if some
# auth-related keywords appear in hidden elements / nav bars / footers.
_LOGGED_IN_INDICATORS = [
    "个人主页",
    "退出登录",
    "我的主页",
    "我的账号",
    "sign out",
    "log out",
    "logout",
    "my account",
    "my profile",
    "个人中心",
    "我的设置",
    "发布",  # common on social media homepages when logged in
]


@dataclass
class AuthDetectionResult:
    """Result of auth page detection."""

    is_auth_page: bool = False
    auth_type: str = ""  # "qr_code" | "captcha" | "sso_redirect" | "login_form"
    confidence: float = 0.0
    url: str = ""
    detail: str = ""


class AuthPageDetector:
    """Detect authentication pages via URL + DOM heuristics."""

    def __init__(self, session: BrowserSession) -> None:
        self._session = session

    async def detect(self) -> AuthDetectionResult:
        """Analyse the current page for authentication indicators.

        Uses a two-pass approach to reduce false positives:
        1. Extract *visible text* (strip <script>, <style>, hidden elements)
           to avoid matching keywords buried in JS bundles or metadata.
        2. Check for logged-in indicators that override auth detection –
           social media homepages often contain auth-related keywords in
           hidden nav / popover templates even when the user is logged in.
        """
        session = self._session
        if not session.cdp or not session.cdp.context:
            return AuthDetectionResult()

        try:
            pages = session.cdp.context.pages
            if not pages:
                return AuthDetectionResult()
            page = pages[0]
            url = page.url
            session.current_url = url
        except Exception:
            return AuthDetectionResult()

        result = AuthDetectionResult(url=url)

        # 1. URL check
        if _AUTH_URL_PATTERNS.search(url):
            result.is_auth_page = True
            result.auth_type = "sso_redirect"
            result.confidence = 0.7
            result.detail = "URL matches auth pattern"

        # 2. DOM content check — use visible text only
        try:
            page_content = await page.content()
            # Strip <script> and <style> blocks to avoid matching JS code
            visible_text = re.sub(
                r"<(script|style|noscript)[^>]*>[\s\S]*?</\1>",
                "",
                page_content,
                flags=re.IGNORECASE,
            )
            # Also strip HTML tags to get approximate visible text
            visible_text_lower = re.sub(r"<[^>]+>", " ", visible_text).lower()

            # Check for logged-in indicators first — if found, the page
            # is almost certainly not a primary auth page.
            has_logged_in_signals = any(indicator in visible_text_lower for indicator in _LOGGED_IN_INDICATORS)

            if has_logged_in_signals and not _AUTH_URL_PATTERNS.search(url):
                # Page shows logged-in UI; auth keywords are likely
                # from hidden elements / secondary widgets.
                logger.debug(
                    "Auth keyword detection suppressed — logged-in indicators found on %s",
                    url,
                )
                result.is_auth_page = False
                result.confidence = 0.0
                return result

            # QR code detection (on visible text only)
            for indicator in _QR_CODE_INDICATORS:
                if indicator.lower() in visible_text_lower:
                    result.is_auth_page = True
                    result.auth_type = "qr_code"
                    result.confidence = max(result.confidence, 0.8)
                    result.detail = f"QR code indicator found: {indicator}"
                    break

            # CAPTCHA / verification code detection
            if not result.auth_type or result.auth_type == "sso_redirect":
                for indicator in _CAPTCHA_INDICATORS:
                    if indicator.lower() in visible_text_lower:
                        result.is_auth_page = True
                        result.auth_type = "captcha"
                        result.confidence = max(result.confidence, 0.75)
                        result.detail = f"Captcha indicator found: {indicator}"
                        break

            # Password input detection (login form)
            if not result.is_auth_page and ('type="password"' in page_content or "type='password'" in page_content):
                result.is_auth_page = True
                result.auth_type = "login_form"
                result.confidence = 0.6
                result.detail = "Password input field detected"

        except Exception as exc:
            logger.debug("DOM analysis failed: %s", exc)

        return result


# ---------------------------------------------------------------------------
# Chat notification integration
# ---------------------------------------------------------------------------

# Callback type: async function that sends a system message to chat
ChatNotifyCallback = Callable[[dict[str, Any]], Awaitable[None]]


class AuthNotifier:
    """Monitors a session for auth pages and sends Chat notifications.

    Usage::

        notifier = AuthNotifier(session, chat_callback=send_system_msg)
        asyncio.create_task(notifier.run())
    """

    def __init__(
        self,
        session: BrowserSession,
        chat_callback: ChatNotifyCallback | None = None,
        check_interval: float = 3.0,
    ) -> None:
        self._session = session
        self._callback = chat_callback
        self._interval = check_interval
        self._detector = AuthPageDetector(session)
        self._streamer = ScreenshotStreamer(session)
        self._running = False
        self._last_notified_url = ""

    async def run(self) -> None:
        """Periodically check for auth pages and send notifications."""
        self._running = True
        while self._running:
            if self._session.state in (SessionState.FAILED, SessionState.TIMEOUT):
                break

            result = await self._detector.detect()

            if result.is_auth_page and result.url != self._last_notified_url:
                self._last_notified_url = result.url
                await self._notify_auth_detected(result)

            await asyncio.sleep(self._interval)

    def stop(self) -> None:
        self._running = False

    async def _notify_auth_detected(
        self,
        detection: AuthDetectionResult,
    ) -> None:
        """Send a notification to Chat with screenshot and auth info."""
        screenshot = await self._streamer.capture_once()

        message: dict[str, Any] = {
            "type": "browser_auth_needed",
            "auth_type": detection.auth_type,
            "url": detection.url,
            "detail": detection.detail,
            "confidence": detection.confidence,
            "session_id": self._session.session_id,
            "profile_name": self._session.profile_name,
        }

        if screenshot:
            message["screenshot_b64"] = screenshot.data_b64

        logger.info(
            "Auth page detected: type=%s, url=%s, confidence=%.2f",
            detection.auth_type,
            detection.url,
            detection.confidence,
        )

        # Switch control to user
        if self._session.control_owner == ControlOwner.AGENT:
            self._session.request_user_control(reason=f"auth_detected:{detection.auth_type}")

        if self._callback:
            try:
                await self._callback(message)
            except Exception as exc:
                logger.warning("Chat notification callback failed: %s", exc)
