"""End-to-end upload pipeline: resolve -> validate -> inject -> verify.

Orchestrates the full server-side image upload flow through the browser
FileChooser, with structured results at every phase.
"""

from __future__ import annotations

import contextlib
import json
import logging
import time
from typing import Any

from lightclaw.agent.tools.browser.file_resolver import FileResolver
from lightclaw.agent.tools.browser.upload_models import (
    UploadErrorCode,
    UploadFileSpec,
    UploadPhase,
    UploadRequest,
    UploadResult,
)

logger = logging.getLogger(__name__)

# Singleton resolver
_file_resolver: FileResolver | None = None


def get_file_resolver() -> FileResolver:
    """Return the process-global FileResolver, creating one if needed."""
    global _file_resolver
    if _file_resolver is None:
        _file_resolver = FileResolver()
    return _file_resolver


def set_file_resolver(resolver: FileResolver) -> None:
    """Replace the process-global FileResolver (useful for tests)."""
    global _file_resolver
    _file_resolver = resolver


async def execute_upload(
    request: UploadRequest,
    state: dict[str, Any],
) -> UploadResult:
    """Run the full upload pipeline against the browser state dict.

    Parameters
    ----------
    request:
        What to upload and which page_id to target.
    state:
        The process-global ``_state`` dict from ``browser_control.py``.

    Returns
    -------
    UploadResult
        Structured outcome with phase, error code and resolved paths.
    """
    page_id = request.page_id
    start = time.monotonic()

    # 1. Resolve page existence.
    page = state.get("pages", {}).get(page_id)
    if page is None:
        logger.warning("Upload: page %r not found.", page_id)
        return UploadResult.failure(
            phase=UploadPhase.RESOLVE,
            error_code=UploadErrorCode.NO_ACTIVE_PAGE,
            error_message=f"Page '{page_id}' not found.",
        )

    page_context = ""
    with contextlib.suppress(Exception):
        page_context = page.url

    # 2. Resolve and validate files.
    resolver = get_file_resolver()
    resolve_result = resolver.resolve_and_validate(
        request.files,
        base_directory=request.base_directory,
    )
    if not resolve_result.ok:
        resolve_result.page_context = page_context
        logger.info(
            "Upload: file resolution failed - %s (%s)",
            resolve_result.error_code,
            resolve_result.error_message,
        )
        return resolve_result

    paths = resolve_result.resolved_paths
    logger.info("Upload: resolved %d file(s) for page %s.", len(paths), page_id)

    # 3. Acquire a pending FileChooser.
    choosers: list[Any] = state.get("pending_file_choosers", {}).get(page_id, [])
    if not choosers:
        logger.info("Upload: no pending FileChooser for page %s.", page_id)
        return UploadResult.failure(
            phase=UploadPhase.CHOOSER_WAIT,
            error_code=UploadErrorCode.NO_FILE_CHOOSER,
            error_message=(
                "No pending file chooser. Click the upload button on the page first, then call upload_image."
            ),
            page_context=page_context,
        )

    chooser = choosers.pop(0)

    # 4. Inject files into the chooser.
    try:
        await chooser.set_files(paths)
    except Exception as exc:
        error_msg = str(exc)
        if "disposed" in error_msg.lower() or "target closed" in error_msg.lower():
            code = UploadErrorCode.CHOOSER_EXPIRED
        elif "navigat" in error_msg.lower():
            code = UploadErrorCode.PAGE_NAVIGATED
        else:
            code = UploadErrorCode.UNKNOWN
        logger.error("Upload: inject failed - %s", exc, exc_info=True)
        return UploadResult.failure(
            phase=UploadPhase.INJECT,
            error_code=code,
            error_message=f"FileChooser injection failed: {error_msg}",
            page_context=page_context,
        )

    elapsed = time.monotonic() - start
    logger.info(
        "Upload: injected %d file(s) into page %s in %.2fs.",
        len(paths),
        page_id,
        elapsed,
    )

    return UploadResult.success(
        files_injected=len(paths),
        resolved_paths=paths,
        page_context=page_context,
    )


def build_upload_request(
    paths_json: str = "",
    page_id: str = "default",
    base_directory: str = "",
) -> UploadRequest:
    """Parse loose JSON/CSV parameters into an UploadRequest.

    Accepts the same paths_json format that the existing
    _action_file_upload uses, so existing Agent prompts keep working.
    """
    specs: list[UploadFileSpec] = []

    if paths_json and isinstance(paths_json, str):
        paths_json = paths_json.strip()
        if paths_json:
            try:
                parsed = json.loads(paths_json)
            except json.JSONDecodeError:
                parsed = [p.strip() for p in paths_json.split(",") if p.strip()]

            if isinstance(parsed, list):
                for item in parsed:
                    if isinstance(item, str):
                        specs.append(UploadFileSpec(path=item))
                    elif isinstance(item, dict):
                        specs.append(
                            UploadFileSpec(
                                path=item.get("path", ""),
                                identifier=item.get("identifier", ""),
                            ),
                        )
            elif isinstance(parsed, str):
                specs.append(UploadFileSpec(path=parsed))

    return UploadRequest(
        files=specs,
        page_id=page_id,
        base_directory=base_directory,
    )
