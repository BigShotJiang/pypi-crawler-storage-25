"""Lightweight HTTP direct fetcher.

Performs a single HTTP GET via ``httpx``, extracts visible text from the
HTML response, checks content sufficiency, and scans for blocking keywords
(login walls, captchas, etc.).

This module is consumed by ``UrlAccessPlanner`` and should *never* be
imported by the browser stack itself.
"""

from __future__ import annotations

import html as html_module
import logging
import os
import re
from dataclasses import dataclass

import httpx

from lightclaw.agent.tools.browser.domain_registry import is_always_browser

logger = logging.getLogger(__name__)

# ---------------------------------------------------------------------------
# Configuration (overridable via environment variables)
# ---------------------------------------------------------------------------

_DEFAULT_TIMEOUT = 8  # seconds
_DEFAULT_MIN_TEXT_LENGTH = 200

_USER_AGENT = (
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36"
)

# Maximum number of redirects to follow
_MAX_REDIRECTS = 5


def _get_timeout() -> float:
    """Read prefetch timeout from env, falling back to default."""
    raw = os.environ.get("FINNIE_PREFETCH_TIMEOUT", "")
    try:
        return float(raw) if raw else float(_DEFAULT_TIMEOUT)
    except ValueError:
        return float(_DEFAULT_TIMEOUT)


def _get_min_text_length() -> int:
    """Read minimum text length threshold from env."""
    raw = os.environ.get("FINNIE_MIN_TEXT_LENGTH", "")
    try:
        return int(raw) if raw else _DEFAULT_MIN_TEXT_LENGTH
    except ValueError:
        return _DEFAULT_MIN_TEXT_LENGTH


# ---------------------------------------------------------------------------
# Fetch result
# ---------------------------------------------------------------------------


@dataclass
class FetchResult:
    """Raw result from an HTTP direct fetch."""

    ok: bool = False
    status_code: int = 0
    final_url: str = ""
    content_type: str = ""
    html: str = ""
    error: str | None = None
    redirected_to_browser_domain: bool = False


# ---------------------------------------------------------------------------
# HTML text extraction
# ---------------------------------------------------------------------------

# Regex patterns for stripping non-visible elements
_STRIP_PATTERNS: list[re.Pattern[str]] = [
    re.compile(r"<script[\s>].*?</script>", re.DOTALL | re.IGNORECASE),
    re.compile(r"<style[\s>].*?</style>", re.DOTALL | re.IGNORECASE),
    re.compile(r"<noscript[\s>].*?</noscript>", re.DOTALL | re.IGNORECASE),
    re.compile(r"<!--.*?-->", re.DOTALL),
    re.compile(r"<head[\s>].*?</head>", re.DOTALL | re.IGNORECASE),
]

# Strip all remaining HTML tags
_TAG_RE = re.compile(r"<[^>]+>")

# Collapse whitespace
_WS_RE = re.compile(r"\s+")


def extract_visible_text(html_content: str) -> str:
    """Extract visible text from an HTML string.

    Removes ``<script>``, ``<style>``, ``<noscript>``, ``<head>`` blocks and
    HTML comments, then strips remaining tags and collapses whitespace.
    """
    text = html_content
    for pat in _STRIP_PATTERNS:
        text = pat.sub(" ", text)
    text = _TAG_RE.sub(" ", text)
    text = html_module.unescape(text)
    text = _WS_RE.sub(" ", text).strip()
    return text


def check_content_sufficiency(
    html_content: str,
    content_type: str = "text/html",
    min_length: int | None = None,
) -> tuple[bool, str]:
    """Check whether fetched content is sufficient for direct return.

    Returns:
        A ``(is_sufficient, visible_text)`` tuple.
    """
    # Non-HTML content types are always considered sufficient
    ct_lower = content_type.lower().split(";")[0].strip()
    if ct_lower and ct_lower != "text/html":
        return True, html_content

    threshold = min_length if min_length is not None else _get_min_text_length()
    visible = extract_visible_text(html_content)

    if len(visible) < threshold:
        logger.debug(
            "Content insufficient: %d chars < %d threshold",
            len(visible),
            threshold,
        )
        return False, visible

    return True, visible


# ---------------------------------------------------------------------------
# Blocking keyword scanning
# ---------------------------------------------------------------------------

# Forward-evidence keywords that suggest blocking
_BLOCKING_KEYWORDS: list[tuple[str, str]] = [
    ("captcha", "captcha"),
    ("recaptcha", "captcha"),
    ("验证码", "captcha"),
    ("滑动验证", "captcha"),
    ("login", "login_prompt"),
    ("sign-in", "login_prompt"),
    ("sign_in", "login_prompt"),
    ('type="password"', "login_prompt"),
    ("type='password'", "login_prompt"),
    ("扫码登录", "login_prompt"),
    ("请登录", "login_prompt"),
    ("paywall", "paywall"),
    ("subscribe to continue", "paywall"),
    ("付费阅读", "paywall"),
]

# Reverse-evidence keywords that reduce false positives.
# If these appear, the corresponding signal type is suppressed.
_REVERSE_EVIDENCE: dict[str, list[str]] = {
    "login_prompt": [
        "退出登录",
        "sign out",
        "sign-out",
        "logout",
        "log out",
        "log-out",
        "my account",
        "我的账户",
        "个人中心",
    ],
}


def scan_blocking_keywords(html_content: str) -> list[str]:
    """Scan HTML for blocking keywords and return detected signal types.

    Applies reverse-evidence suppression: if a signal type has matching
    reverse-evidence keywords in the same content, it is not reported.
    """
    lower = html_content.lower()

    # Collect candidate signal types
    candidates: dict[str, bool] = {}
    for keyword, signal_type in _BLOCKING_KEYWORDS:
        if keyword.lower() in lower:
            candidates[signal_type] = True

    if not candidates:
        return []

    # Apply reverse-evidence suppression
    signals: list[str] = []
    for signal_type in candidates:
        reverse_kws = _REVERSE_EVIDENCE.get(signal_type, [])
        suppressed = any(rk.lower() in lower for rk in reverse_kws)
        if suppressed:
            logger.debug(
                "Blocking signal '%s' suppressed by reverse evidence",
                signal_type,
            )
        else:
            signals.append(signal_type)

    return signals


# ---------------------------------------------------------------------------
# Direct fetcher
# ---------------------------------------------------------------------------


class DirectFetcher:
    """Lightweight async HTTP fetcher using httpx."""

    async def fetch(self, url: str) -> FetchResult:
        """Perform an HTTP GET and return the raw result.

        Follows redirects (up to ``_MAX_REDIRECTS``).  If any intermediate
        redirect target hits an always-browser domain, the fetch is aborted
        early and ``redirected_to_browser_domain`` is set.
        """
        timeout = _get_timeout()

        try:
            async with httpx.AsyncClient(
                timeout=timeout,
                follow_redirects=False,
                headers={"User-Agent": _USER_AGENT},
            ) as client:
                current_url = url
                for _ in range(_MAX_REDIRECTS):
                    resp = await client.get(current_url)

                    if resp.is_redirect:
                        location = resp.headers.get("location", "")
                        if not location:
                            break
                        # Resolve relative redirects
                        current_url = str(resp.next_request.url) if resp.next_request else location
                        if is_always_browser(current_url):
                            logger.info(
                                "Redirect target %s hits always-browser domain",
                                current_url,
                            )
                            return FetchResult(
                                ok=False,
                                status_code=resp.status_code,
                                final_url=current_url,
                                redirected_to_browser_domain=True,
                            )
                        continue

                    # Non-redirect response
                    ct = resp.headers.get("content-type", "")
                    return FetchResult(
                        ok=200 <= resp.status_code < 400,
                        status_code=resp.status_code,
                        final_url=str(resp.url),
                        content_type=ct,
                        html=resp.text,
                    )

                # Exhausted redirect limit
                return FetchResult(
                    ok=False,
                    final_url=current_url,
                    error="Too many redirects",
                )

        except httpx.TimeoutException:
            logger.info("Direct fetch timed out for %s", url)
            return FetchResult(ok=False, final_url=url, error="Timeout")
        except httpx.HTTPError as exc:
            logger.info("Direct fetch HTTP error for %s: %s", url, exc)
            return FetchResult(ok=False, final_url=url, error=str(exc))
        except Exception as exc:
            logger.warning("Direct fetch unexpected error for %s: %s", url, exc)
            return FetchResult(ok=False, final_url=url, error=str(exc))
