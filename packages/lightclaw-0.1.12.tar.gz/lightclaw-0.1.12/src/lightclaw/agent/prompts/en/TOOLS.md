# TOOLS.md - Tool Configuration & Notes

> Document tool-specific configurations, gotchas, and credentials here.

---

## Tool Usage Rules

Skills define how tools work. Check a tool's `SKILL.md` before using it. Local device config (cameras, SSH, voice preferences, etc.) goes in `MEMORY.md` "Tool Config." Identity profile lives in `IDENTITY.md`, user profile in `USER.md`.

### Web Information Retrieval Strategy

**Assess the page type first, then pick a tool — don't reach for the browser by default.**

| Type | Signals | Typical cases | Strategy |
|------|---------|---------------|----------|
| **Static content** | No JS rendering needed; no login required; content is in the raw HTML | News articles, RSS, open APIs, GitHub README, static docs, Wikipedia | `execute_shell_command` + `curl` first; fall back to `browser_use` only if it fails or content is incomplete |
| **Dynamic rendering** | Needs JS execution to show content (SPA); anti-scraping protection; login required | Zhihu, Weibo, e-commerce product pages, internal admin dashboards, auth-gated backends | `browser_use` directly (Playwright/stealth) — skip curl |

**Decision tree:**

1. URL is clearly an API (contains `/api/`, `.json`, `.xml`, `.rss`) → **curl**
2. Known dynamic site (Zhihu / Weibo / Taobao / Bilibili / Feishu Docs / internal systems) → **browser directly**
3. Regular page, unsure → try curl first; if `<body>` contains barely any text or is all `<script>` tags → switch to browser
4. Needs clicking, scrolling, form filling, or login → **browser only**

**Downgrade triggers (switch to browser if any of these occur):**
- HTTP 403 / 429 / 5xx
- `<body>` contains fewer than 200 characters
- Content is clearly a JS placeholder (e.g. `<div id="app"></div>`)
- Real content requires a Cookie / Session to access

---

### Displaying Files to Users

Use the `file_preview` tool (see system policy for full rules). `desktop_screenshot` and other tools that return media work the same way — call the tool, do not embed the returned URL in your response.

---

## Credentials Location

All credentials stored in `.credentials/` (gitignored):
- `example-api.txt` — Example API key

---
