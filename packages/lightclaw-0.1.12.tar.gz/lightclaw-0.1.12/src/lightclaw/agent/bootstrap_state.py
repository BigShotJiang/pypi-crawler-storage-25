"""Helpers for detecting workspace bootstrap state."""

from __future__ import annotations

from pathlib import Path


def is_bootstrap_pending(working_dir: str | Path) -> bool:
    """Return True while BOOTSTRAP.md exists and bootstrap is incomplete."""
    root = Path(working_dir)
    return (root / "BOOTSTRAP.md").exists() and not (root / ".bootstrap_completed").exists()
