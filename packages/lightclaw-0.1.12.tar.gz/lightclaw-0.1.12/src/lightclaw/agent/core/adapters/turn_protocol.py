"""Turn-protocol adapters around LangChain messages.

These helpers are intentionally scoped to protocol boundaries so the
LangGraph execution path can stay BaseMessage-native while the app layer
projects messages into turn DTOs only where needed.
"""

from __future__ import annotations

import re
from collections.abc import Sequence
from copy import deepcopy
from typing import Any
from uuid import uuid4

from langchain_core.messages import AIMessage, BaseMessage, ToolMessage

from lightclaw.agent.core.adapters.message_converter import (
    _additional_media_blocks,
    _append_text_or_multimodal,
    _extract_reasoning_text,
    _langchain_part_to_block,
    _langchain_role,
    _message_to_internal_kwargs,
    _strip_file_placeholder_lines,
    _strip_placeholder_blocks,
    msgs_to_langchain,
)
from lightclaw.domain import CallEntry, TurnEvent, TurnEventType

# Matches a single ``<think>...</think>`` block (DOTALL so newlines inside
# the tag are captured). Used to scrub reasoning from final AIMessage text
# since streaming has already surfaced it via REASONING deltas — keeping it
# in the completed content would cause channels (notably QQ) to deliver the
# same reasoning twice (once as "\ud83d\udcad \u601d\u8003\u8fc7\u7a0b" bubble, once as raw ``<think>`` text).
_THINK_TAG_RE = re.compile(r"<think\b[^>]*>.*?</think>", re.DOTALL | re.IGNORECASE)


def _strip_think_tags(text: str) -> str:
    """Return *text* with any ``<think>...</think>`` blocks removed.

    Leaves a no-op when the string contains no think tags. Collapses only
    leading/trailing whitespace introduced by the removal so mid-message
    spacing is preserved.
    """
    if not text or "<think" not in text.lower():
        return text
    cleaned = _THINK_TAG_RE.sub("", text)
    return cleaned.strip() if cleaned != text else text


def _scrub_think_tags_from_content(content: Any) -> Any:
    """Strip ``<think>`` blocks from string or list-of-parts message content.

    Returns a shallow-copied version when any change is made so the caller
    can safely treat the original ``message.content`` as immutable. Dict
    parts that are neither text nor known media are passed through.
    """
    if isinstance(content, str):
        return _strip_think_tags(content)
    if isinstance(content, list):
        changed = False
        new_parts: list[Any] = []
        for part in content:
            if isinstance(part, str):
                stripped = _strip_think_tags(part)
                if stripped != part:
                    changed = True
                if stripped:
                    new_parts.append(stripped)
                continue
            if isinstance(part, dict) and part.get("type") == "text":
                original = part.get("text")
                if isinstance(original, str):
                    stripped = _strip_think_tags(original)
                    if stripped != original:
                        changed = True
                        if not stripped:
                            continue
                        new_parts.append({**part, "text": stripped})
                        continue
            new_parts.append(part)
        return new_parts if changed else content
    return content


def turn_inputs_to_langchain_messages(inputs: Sequence[Any]) -> list[BaseMessage]:
    """Convert turn-protocol input DTOs to LangChain messages."""
    return msgs_to_langchain(list(inputs))


def langchain_message_to_turn_payload(message: BaseMessage) -> dict[str, Any]:
    """Project one LangChain message into turn-protocol fields."""
    role = _langchain_role(message)
    blocks: list[dict[str, Any]] = []
    extra_media_blocks = _additional_media_blocks(message)
    thinking = _extract_reasoning_text(getattr(message, "additional_kwargs", None))
    content = getattr(message, "content", None)

    # Scrub any ``<think>...</think>`` blocks from the textual content. For
    # OpenAI-compatible models such as MiniMax, the reasoning is already
    # streamed separately via REASONING deltas, so leaving the raw tags in
    # the final content would duplicate the thinking in downstream channels.
    if not isinstance(message, ToolMessage):
        content = _scrub_think_tags_from_content(content)

    if isinstance(message, ToolMessage):
        output = message.content if isinstance(message.content, str) else str(message.content)
        blocks.append(
            {
                "type": "tool_result",
                "id": message.tool_call_id or "",
                "name": getattr(message, "name", "") or "",
                "output": output,
            }
        )
        role = "tool"

    elif isinstance(message, AIMessage) and message.tool_calls:
        if content:
            _append_text_or_multimodal(
                blocks,
                content,
                strip_file_placeholders=bool(extra_media_blocks),
            )
        if thinking:
            blocks.append({"type": "thinking", "thinking": thinking})
        for tool_call in message.tool_calls:
            blocks.append(
                {
                    "type": "tool_use",
                    "id": tool_call.get("id", ""),
                    "name": tool_call.get("name", ""),
                    "input": tool_call.get("args", {}),
                }
            )
        blocks.extend(extra_media_blocks)

    else:
        if thinking:
            blocks.append({"type": "thinking", "thinking": thinking})

        if isinstance(content, str):
            text = _strip_file_placeholder_lines(content) if extra_media_blocks else content
            if text:
                blocks.append({"type": "text", "text": text})
        elif isinstance(content, list):
            for part in content:
                if isinstance(part, str):
                    text = _strip_file_placeholder_lines(part) if extra_media_blocks else part
                    if text:
                        blocks.append({"type": "text", "text": text})
                elif isinstance(part, dict):
                    _langchain_part_to_block(blocks, part)
        elif content is not None:
            blocks.append({"type": "text", "text": str(content)})

        if extra_media_blocks:
            blocks = _strip_placeholder_blocks(blocks)
            blocks.extend(extra_media_blocks)

    kwargs = _message_to_internal_kwargs(message)
    payload: dict[str, Any] = {
        "role": role,
        "content": blocks,
        "usage": kwargs.get("usage"),
        "metadata": kwargs.get("metadata"),
    }
    return payload


def langchain_message_to_turn_event(
    message: BaseMessage,
    *,
    turn_id: str,
    event_type: str = TurnEventType.ASSISTANT_COMPLETED,
    message_id: str | None = None,
    metadata: dict[str, Any] | None = None,
) -> TurnEvent:
    """Convert one LangChain message into a canonical turn event."""
    payload = langchain_message_to_turn_payload(message)
    merged_metadata = deepcopy(payload.get("metadata") or {})
    if metadata:
        merged_metadata.update(metadata)

    event_message_id = message_id or str(getattr(message, "id", "") or "") or str(uuid4())
    return TurnEvent(
        type=event_type,
        turn_id=turn_id,
        message_id=event_message_id,
        role=payload.get("role"),
        content=payload.get("content") or [],
        usage=payload.get("usage"),
        metadata=merged_metadata or None,
    )


def langchain_messages_to_call_entries(
    messages: Sequence[BaseMessage],
    *,
    entry_index_prefix: str = "history",
) -> list[CallEntry]:
    """Project LangChain history into per-call history entries.

    Each ``BaseMessage`` becomes exactly one :class:`CallEntry` — this is
    a flat per-message projection, *not* a turn-level aggregation. Entries
    that belong to the same conversational turn (e.g. the AI/tool messages
    produced by a single ReAct loop) will share the same ``message_id``
    prefix at the source but are intentionally kept as separate entries so
    the dashboard can render every model call verbatim.
    """
    entries: list[CallEntry] = []
    for index, message in enumerate(messages):
        payload = langchain_message_to_turn_payload(message)
        message_id = str(getattr(message, "id", "") or "") or f"{entry_index_prefix}:{index}"
        entries.append(
            CallEntry(
                entry_index=f"{entry_index_prefix}:{index}",
                message_id=message_id,
                role=payload.get("role"),
                content=payload.get("content") or [],
                usage=payload.get("usage"),
                metadata=payload.get("metadata"),
            )
        )
    return entries
