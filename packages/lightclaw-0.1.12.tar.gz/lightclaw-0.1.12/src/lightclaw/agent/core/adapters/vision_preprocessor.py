"""Vision sticky preprocessor (方案 A, minimax + mmx-cli only).

When the user's active primary model is MiniMax and the latest user
message carries image attachments, we:

1. Keep the active model pinned (sticky) — do NOT let modality-based
   routing swap in some other image-capable model (e.g. Qwen3-VL).
2. Rewrite each ``image`` block into a ``text`` block that contains a
   local file path / URL reference, so the text-only MiniMax model
   still sees a non-empty payload and knows where the image lives.
3. Inject a one-shot hint telling the model to call the ``mmx-cli``
   skill via ``execute_shell_command`` to read the image, instead of
   guessing the content.

The vision understanding itself is delegated to the ``mmx-cli`` skill
at runtime — this module does NOT call any hidden VL backend itself.
"""

from __future__ import annotations

import logging
import shlex
from dataclasses import dataclass
from typing import Any

from lightclaw.infra.providers.models import ProvidersData

logger = logging.getLogger(__name__)

_MMX_STICKY_PROVIDER = "minimax"
_VISION_HINT_MARKER = "[vision-tool-hint]"


@dataclass(frozen=True)
class VisionRewriteResult:
    """Outcome summary of one image-block rewrite pass."""

    had_image_blocks: bool
    rewritten_image_blocks: int
    remaining_image_blocks: int

    @property
    def fully_text(self) -> bool:
        return self.had_image_blocks and self.remaining_image_blocks == 0


# ---------------------------------------------------------------------------
# Public API (called by session_factory)
# ---------------------------------------------------------------------------


def should_sticky_for_active_provider(
    *,
    msgs: Any,
    providers_data: ProvidersData,
) -> bool:
    """Return True when the active provider is MiniMax AND latest msg has images."""
    messages = _as_list(msgs)
    if not messages:
        return False
    _target, image_blocks = _find_latest_image_blocks(messages)
    if not image_blocks:
        return False
    active_provider_id, active_model = providers_data.parse_active_llm()
    if not active_provider_id or not active_model:
        return False
    return active_provider_id.strip().lower() == _MMX_STICKY_PROVIDER


def rewrite_image_blocks_for_tool_first(
    *,
    msgs: Any,
    language: str | None = None,
) -> VisionRewriteResult:
    """Replace each image block with a text block referencing the image path."""
    messages = _as_list(msgs)
    if not messages:
        return VisionRewriteResult(False, 0, 0)
    target_message, image_blocks = _find_latest_image_blocks(messages)
    if not target_message or not image_blocks:
        return VisionRewriteResult(False, 0, 0)

    is_en = (language or "").lower().startswith("en")
    desc_by_id: dict[int, str] = {}
    for index, block in enumerate(image_blocks, start=1):
        image_ref, usable = _resolve_image_reference(block)
        desc_by_id[id(block)] = _build_rewrite_text(
            index=index, image_ref=image_ref, usable=usable, is_en=is_en
        )

    _rewrite_content(target_message, desc_by_id, is_en=is_en)
    remaining = len(_collect_image_blocks(getattr(target_message, "content", [])))
    return VisionRewriteResult(
        had_image_blocks=True,
        rewritten_image_blocks=len(desc_by_id),
        remaining_image_blocks=remaining,
    )


def inject_image_tool_hint(*, msgs: Any, language: str | None = None) -> bool:
    """Inject a one-shot system-style hint telling the model to call mmx-cli."""
    messages = _as_list(msgs)
    if not messages:
        return False
    target_message, image_blocks = _find_latest_image_blocks(messages)
    if not target_message or not image_blocks:
        return False
    content = getattr(target_message, "content", None)
    if not isinstance(content, list):
        return False
    for block in content:
        normalized = _normalize_block(block)
        if normalized is None or normalized.get("type") != "text":
            continue
        text = normalized.get("text", "")
        if isinstance(text, str) and _VISION_HINT_MARKER in text:
            return False
    if (language or "").lower().startswith("en"):
        hint = (
            f"{_VISION_HINT_MARKER} Image input detected. Before final answer, you MUST call the mmx-cli "
            "skill via `execute_shell_command` (e.g. `mmx vision describe --image <path-or-url> --output json "
            "--quiet --non-interactive`). If the command fails, explicitly state you cannot read the image; "
            "never guess."
        )
    else:
        hint = (
            f"{_VISION_HINT_MARKER} 当前输入含图片。最终回答前必须通过 `execute_shell_command` 调 mmx-cli "
            "skill（例如 `mmx vision describe --image <路径或URL> --output json --quiet --non-interactive`）。"
            "若命令失败，必须明确说明“无法读取图片内容”，严禁猜测。"
        )
    content.insert(0, {"type": "text", "text": hint})
    return True


# ---------------------------------------------------------------------------
# Internal helpers
# ---------------------------------------------------------------------------


def _as_list(msgs: Any) -> list[Any]:
    if msgs is None:
        return []
    if isinstance(msgs, list):
        return msgs
    if isinstance(msgs, tuple):
        return list(msgs)
    return [msgs]


def _find_latest_image_blocks(messages: list[Any]) -> tuple[Any | None, list[dict]]:
    for message in reversed(messages):
        role = getattr(message, "role", "")
        if role and role != "user":
            continue
        content = getattr(message, "content", None)
        if not isinstance(content, list):
            continue
        blocks = _collect_image_blocks(content)
        if blocks:
            return message, blocks
    return None, []


def _collect_image_blocks(content: list[Any]) -> list[dict]:
    result: list[dict] = []
    for block in content:
        normalized = _normalize_block(block)
        if normalized is not None and normalized.get("type") == "image":
            result.append(normalized)
    return result


def _normalize_block(block: Any) -> dict[str, Any] | None:
    if isinstance(block, dict):
        return block
    if hasattr(block, "model_dump"):
        dumped = block.model_dump(exclude_none=True)
        return dumped if isinstance(dumped, dict) else None
    if hasattr(block, "dict"):
        dumped = block.dict(exclude_none=True)
        return dumped if isinstance(dumped, dict) else None
    return None


def _raw_image_url(block: dict[str, Any]) -> str:
    source = block.get("source")
    if isinstance(source, dict):
        src_type = source.get("type", "")
        if src_type == "url":
            url = source.get("url", "")
            if isinstance(url, str):
                return url
        elif src_type == "base64":
            media_type = source.get("media_type", "application/octet-stream")
            data = source.get("data", "")
            if data:
                return f"data:{media_type};base64,{data}"
    url = block.get("image_url")
    if isinstance(url, str):
        return url
    if isinstance(url, dict):
        nested = url.get("url", "")
        if isinstance(nested, str):
            return nested
    return ""


def _resolve_image_reference(block: dict[str, Any]) -> tuple[str, bool]:
    """Return (ref, usable) where ``ref`` is suitable for ``mmx --image <ref>``."""
    raw = _raw_image_url(block).strip()
    if not raw:
        return "(unavailable)", False
    if raw.startswith("file://"):
        try:
            from urllib.parse import unquote
            from urllib.request import url2pathname

            local_path = url2pathname(unquote(raw[7:]))
            return (local_path, bool(local_path))
        except Exception:
            return (raw, False)
    if raw.startswith("/api/files/"):
        try:
            from lightclaw.infra.files.store import resolve_file_id_from_url, resolve_upload_path

            file_id = resolve_file_id_from_url(raw)
            if not file_id:
                return (raw, False)
            return (str(resolve_upload_path(file_id)), True)
        except Exception:
            return (raw, False)
    if raw.startswith(("http://", "https://", "/")):
        return (raw, True)
    if raw.startswith("data:"):
        return ("(inline data-uri image, mmx --image cannot use this form directly)", False)
    if len(raw) > 1024:
        return (raw[:320] + "...(truncated)", False)
    return (raw, True)


def _build_rewrite_text(*, index: int, image_ref: str, usable: bool, is_en: bool) -> str:
    if usable:
        shell_cmd = (
            f"mmx vision describe --image {shlex.quote(image_ref)} "
            "--output json --quiet --non-interactive"
        )
        if is_en:
            return (
                "Image input detected. REQUIRED workflow:\n"
                "1) Use `execute_shell_command` to call mmx-cli vision first:\n"
                f"{shell_cmd}\n"
                "2) Answer only from command output.\n"
                "3) If command fails, explicitly say you cannot read the image; never guess.\n"
                f"Image reference {index}: {image_ref}"
            )
        return (
            "检测到图片输入，必须按以下流程执行：\n"
            "1) 先用 `execute_shell_command` 调 mmx-cli 视觉识别：\n"
            f"{shell_cmd}\n"
            "2) 仅根据命令输出再回答。\n"
            "3) 若命令失败，必须明确说明“无法读取图片内容”，严禁猜测。\n"
            f"图片引用 {index}: {image_ref}"
        )
    if is_en:
        return (
            "Image input detected, but no executable image reference is available.\n"
            "Do not guess image content. Explicitly say you cannot read the image and ask user to re-upload.\n"
            f"Image reference {index}: {image_ref}"
        )
    return (
        "检测到图片输入，但当前没有可执行的图片引用。\n"
        "严禁猜测图片内容，必须明确说明“无法读取图片内容”，并提示用户重新上传。\n"
        f"图片引用 {index}: {image_ref}"
    )


def _rewrite_content(message: Any, desc_by_id: dict[int, str], *, is_en: bool) -> None:
    content = getattr(message, "content", None)
    if not isinstance(content, list):
        return
    new_content: list[Any] = []
    counter = 0
    total = len(desc_by_id)
    label = "Image" if is_en else "图片"
    for block in content:
        normalized = _normalize_block(block)
        is_target = (
            normalized is not None
            and normalized.get("type") == "image"
            and id(block) in desc_by_id
        )
        if is_target:
            counter += 1
            desc = desc_by_id[id(block)].strip()
            header = f"[{label} {counter}] " if total > 1 else f"[{label}] "
            new_content.append({"type": "text", "text": f"{header}{desc}"})
            continue
        new_content.append(block)
    message.content = new_content
