"""Core agent execution engine.

Engine-agnostic components live here (config, interfaces, command_handler).
Engine-specific implementations are in sub-packages:
- ``engines/langgraph/``  — LangGraph ReAct engine (swap here to change backend)
- ``adapters/``           — Format converters between LightClaw and LangChain types
"""

from lightclaw.agent.core.adapters.message_converter import (
    langchain_to_msg,
    langchain_to_msgs,
    msg_to_langchain,
    msgs_to_langchain,
)
from lightclaw.agent.core.config import AgentConfig, LightClawGraphConfig
from lightclaw.agent.core.interfaces import BaseAgentBuilder, BaseEventBridge, BaseMiddleware

__all__ = [
    # Engine-agnostic config & interfaces
    "AgentConfig",
    "BaseAgentBuilder",
    "BaseEventBridge",
    "BaseMiddleware",
    # Backward-compat alias
    "LightClawGraphConfig",
    # Adapters
    "langchain_to_msg",
    "langchain_to_msgs",
    "msg_to_langchain",
    "msgs_to_langchain",
]
