"""Backward-compatible session store import path.

Legacy code imported ``LangGraphSessionStore`` from:
    ``lightclaw.agent.core.session_store``

The implementation now lives in:
    ``lightclaw.agent.core.engines.langgraph.session_store``
"""

from __future__ import annotations

from lightclaw.agent.core.engines.langgraph.session_store import LangGraphSessionStore

__all__ = ["LangGraphSessionStore"]
