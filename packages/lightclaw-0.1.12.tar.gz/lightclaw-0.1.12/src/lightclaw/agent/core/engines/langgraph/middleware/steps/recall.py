"""Auto memory recall step — retrieve relevant memories before each LLM call."""

from __future__ import annotations

import asyncio
import logging
import re
import time
from pathlib import Path
from typing import TYPE_CHECKING

from langchain_core.messages import BaseMessage

from lightclaw.agent.bootstrap_state import is_bootstrap_pending
from lightclaw.agent.core.engines.langgraph.middleware.steps._message_utils import extract_latest_user_text

if TYPE_CHECKING:
    from lightclaw.agent.memory import MemoryManager

logger = logging.getLogger(__name__)


class AutoRecallInjector:
    """Search memory for context relevant to the current user message and inject it.

    The recall block is merged into the system prompt so that the LLM can
    reference past conversations without re-reading the full history.

    MEMORY.md (long-term memory) and DAILY_TALK.md (today's conversation
    log) are automatically loaded and injected so the agent maintains
    continuity across sessions.
    """

    def __init__(
        self,
        memory_manager: MemoryManager | None,
        language: str = "zh",
    ) -> None:
        self._memory_manager = memory_manager
        self._language = language

        from lightclaw.constant import (
            AUTO_RECALL_ENABLED,
            AUTO_RECALL_MAX_QUERY_LENGTH,
            AUTO_RECALL_MAX_RESULTS,
            AUTO_RECALL_MIN_SCORE,
            AUTO_RECALL_TIMEOUT,
            DAILY_TALK_INJECTION_ENABLED,
            DAILY_TALK_INJECTION_FILTER_ENABLED,
            DAILY_TALK_INJECTION_MAX_CHARS,
            DAILY_TALK_INJECTION_MAX_CHUNKS,
            MEMORY_MD_INJECTION_ENABLED,
            MEMORY_MD_INJECTION_MAX_CHARS,
            WORKING_DIR,
        )

        self._enabled = AUTO_RECALL_ENABLED
        self._max_results = AUTO_RECALL_MAX_RESULTS
        self._min_score = AUTO_RECALL_MIN_SCORE
        self._max_query_length = AUTO_RECALL_MAX_QUERY_LENGTH
        self._timeout = AUTO_RECALL_TIMEOUT
        self._memory_md_injection_enabled = MEMORY_MD_INJECTION_ENABLED
        self._memory_md_injection_max_chars = MEMORY_MD_INJECTION_MAX_CHARS
        self._daily_talk_injection_enabled = DAILY_TALK_INJECTION_ENABLED
        self._daily_talk_injection_max_chars = DAILY_TALK_INJECTION_MAX_CHARS
        self._daily_talk_injection_filter_enabled = DAILY_TALK_INJECTION_FILTER_ENABLED
        self._daily_talk_injection_max_chunks = DAILY_TALK_INJECTION_MAX_CHUNKS
        self._working_dir = WORKING_DIR
        self._bootstrap_pending = is_bootstrap_pending(WORKING_DIR)

    async def get_block(self, messages: list[BaseMessage]) -> str:
        """Return a recall-context block string, or empty string if not applicable."""
        parts: list[str] = []

        # --- MEMORY.md injection (replaces per-day memory with long-term memory) ---
        if self._memory_md_injection_enabled:
            io_started_at = time.perf_counter()
            memory_md_content = self._read_memory_md(
                self._working_dir,
                self._memory_md_injection_max_chars,
            )
            logger.info(
                "[Recall][io] op=read_memory_md path=%s duration_ms=%.2f chars=%d",
                self._working_dir / "MEMORY.md",
                (time.perf_counter() - io_started_at) * 1000,
                len(memory_md_content),
            )
            if memory_md_content:
                memory_md_block = self._build_memory_md_block(
                    memory_md_content,
                    self._language,
                )
                logger.info(
                    "MEMORY.md block injected into system prompt (%d chars)",
                    len(memory_md_block),
                )
                parts.append(memory_md_block)
            else:
                logger.debug("No MEMORY.md found for injection")

        # --- DAILY_TALK.md injection (today's conversation log) ---
        if self._daily_talk_injection_enabled and not self._bootstrap_pending:
            io_started_at = time.perf_counter()
            daily_talk_content = self._read_daily_talk(
                self._working_dir,
                self._daily_talk_injection_max_chars,
            )
            logger.info(
                "[Recall][io] op=read_daily_talk path=%s duration_ms=%.2f chars=%d",
                self._working_dir / "DAILY_TALK.md",
                (time.perf_counter() - io_started_at) * 1000,
                len(daily_talk_content),
            )
            if daily_talk_content:
                # Apply relevance filtering when enabled and a user query is available.
                if self._daily_talk_injection_filter_enabled:
                    user_text = extract_latest_user_text(messages)
                    if user_text and len(user_text.strip()) >= 5:
                        daily_talk_content = self._filter_daily_talk_by_relevance(
                            daily_talk_content,
                            query=user_text[: self._max_query_length],
                            max_chunks=self._daily_talk_injection_max_chunks,
                        )
                        logger.info(
                            "DAILY_TALK.md filtered to %d chars (relevance filter, max_chunks=%d)",
                            len(daily_talk_content),
                            self._daily_talk_injection_max_chunks,
                        )
                if daily_talk_content:
                    daily_talk_block = self._build_daily_talk_block(
                        daily_talk_content,
                        self._language,
                    )
                    logger.info(
                        "DAILY_TALK.md block injected into system prompt (%d chars)",
                        len(daily_talk_block),
                    )
                    parts.append(daily_talk_block)
                else:
                    logger.debug("DAILY_TALK.md filtered to empty — no relevant chunks found")
            else:
                logger.debug("No DAILY_TALK.md content found for injection")
        elif self._daily_talk_injection_enabled and self._bootstrap_pending:
            logger.debug("Skipping DAILY_TALK.md injection while bootstrap is pending")

        # --- Semantic recall (existing logic) ---
        if not self._enabled or self._memory_manager is None:
            return "\n\n".join(parts)

        # Skip if recall block already present in this turn's messages.
        for m in messages:
            if "<auto-recall-context>" in (m.content if isinstance(m.content, str) else ""):
                return "\n\n".join(parts)

        user_text = extract_latest_user_text(messages)
        if not user_text or len(user_text.strip()) < 5:
            return "\n\n".join(parts)

        query = user_text[: self._max_query_length]

        # Resolve temporal expressions (e.g. "昨天" → 2026-04-15) so the
        # search engine can filter by date.  Pure regex, ~0 ms.
        from lightclaw.agent.memory.temporal_resolver import resolve_temporal_expr

        date_range = resolve_temporal_expr(query)

        try:
            io_started_at = time.perf_counter()
            result = await asyncio.wait_for(
                self._memory_manager.memory_search(
                    query=query,
                    max_results=self._max_results,
                    min_score=self._min_score,
                    date_range=date_range,
                ),
                timeout=self._timeout,
            )
            logger.info(
                "[Recall][io] op=memory_search duration_ms=%.2f query_chars=%d result_chars=%d max_results=%d",
                (time.perf_counter() - io_started_at) * 1000,
                len(query),
                len(result or ""),
                self._max_results,
            )
        except TimeoutError:
            logger.warning(
                "Auto-recall timed out after %.1fs (elapsed=%.2fms, embedding cold-start?). "
                "Skipping recall for this turn.",
                self._timeout,
                (time.perf_counter() - io_started_at) * 1000,
            )
            return "\n\n".join(parts)
        except Exception:
            logger.debug(
                "Auto-recall search failed after %.2fms, continuing without recall",
                (time.perf_counter() - io_started_at) * 1000,
            )
            return "\n\n".join(parts)

        if (
            not result
            or result in ("No relevant memories found.", "No memory backend available.")
            or result.startswith("Error:")
        ):
            return "\n\n".join(parts)

        logger.info("Auto-recall: injected relevant memory snippets (%d chars)", len(result))
        parts.append(self._build_block(result, self._language))
        return "\n\n".join(parts)

    # --- MEMORY.md helpers ---

    @staticmethod
    def _read_memory_md(working_dir: Path, max_chars: int) -> str:
        """Read MEMORY.md from WORKING_DIR and return its content, capped at max_chars."""
        memory_md_path = working_dir / "MEMORY.md"
        if not memory_md_path.is_file():
            return ""
        try:
            text = memory_md_path.read_text(encoding="utf-8").strip()
        except OSError:
            return ""
        if not text:
            return ""
        if len(text) > max_chars:
            # Retain the most recent content (tail) rather than the oldest (head).
            return "[... truncated ...]\n\n" + text[-max_chars:]
        return text

    @staticmethod
    def _build_memory_md_block(content: str, language: str) -> str:
        from lightclaw.agent.prompt_catalog import get_memory_md_block_template

        return get_memory_md_block_template(language).format(content=content)

    # --- DAILY_TALK.md helpers ---

    @staticmethod
    def _read_daily_talk(working_dir: Path, max_chars: int) -> str:
        """Read DAILY_TALK.md from WORKING_DIR and return its body content, capped at max_chars."""
        daily_talk_path = working_dir / "DAILY_TALK.md"
        if not daily_talk_path.is_file():
            return ""
        try:
            text = daily_talk_path.read_text(encoding="utf-8").strip()
        except OSError:
            return ""
        if not text:
            return ""
        # Strip the date marker and "# DAILY_TALK" header — keep only the body.
        body = re.sub(r"<!--\s*daily_talk_date:\s*\d{4}-\d{2}-\d{2}\s*-->", "", text, count=1)
        lines = body.splitlines()
        if lines and lines[0].strip() == "# DAILY_TALK":
            lines = lines[1:]
        # Strip timestamp headers (## HH:MM:SS) — they add no semantic value for
        # the LLM and waste tokens.  Messages are separated by blank lines instead.
        lines = [ln for ln in lines if not re.match(r"^## \d{2}:\d{2}:\d{2}\s*$", ln)]
        body = "\n".join(lines).strip()
        if not body:
            return ""
        if len(body) > max_chars:
            # Retain the most recent content (tail) rather than the oldest (head).
            return "[... truncated ...]\n\n" + body[-max_chars:]
        return body

    @staticmethod
    def _filter_daily_talk_by_relevance(
        body: str,
        query: str,
        max_chunks: int,
    ) -> str:
        """Return the top-N most relevant message chunks from DAILY_TALK body.

        Splits the body on blank lines into per-message paragraphs, scores
        each paragraph by keyword overlap with the query (case-insensitive,
        CJK-aware), and returns the top ``max_chunks`` paragraphs joined by
        blank lines.  Chronological order is preserved in the output.

        Falls back to the full body when no chunks score above zero (i.e.
        the query has no extractable keywords), so the caller always gets
        something useful.
        """
        # Split into non-empty paragraphs (each paragraph = one message block).
        paragraphs = [p.strip() for p in re.split(r"\n{2,}", body) if p.strip()]
        if not paragraphs:
            return body
        if len(paragraphs) <= max_chunks:
            # Already small enough — skip scoring overhead.
            return body

        # Extract query tokens: CJK characters (each char is a token) + ASCII words.
        cjk_tokens = set(re.findall(r"[\u4e00-\u9fff\u3040-\u30ff\uac00-\ud7af]", query))
        ascii_tokens = set(w.lower() for w in re.findall(r"[a-zA-Z0-9]+", query) if len(w) >= 2)
        all_tokens = cjk_tokens | ascii_tokens

        if not all_tokens:
            # No extractable keywords — return the most recent max_chunks paragraphs.
            return "\n\n".join(paragraphs[-max_chunks:])

        def _score(para: str) -> float:
            lower = para.lower()
            return sum(1.0 for tok in all_tokens if tok in lower)

        scored = [(idx, _score(p)) for idx, p in enumerate(paragraphs)]
        # Sort by score descending, then by index descending (prefer recent on tie).
        top_indices = sorted(
            [idx for idx, sc in scored if sc > 0],
            key=lambda i: (scored[i][1], i),
            reverse=True,
        )[:max_chunks]

        if not top_indices:
            # No paragraph matched — fall back to most recent max_chunks.
            return "\n\n".join(paragraphs[-max_chunks:])

        # Restore chronological order.
        top_indices.sort()
        return "\n\n".join(paragraphs[i] for i in top_indices)

    @staticmethod
    def _build_daily_talk_block(content: str, language: str) -> str:
        from lightclaw.agent.prompt_catalog import get_daily_talk_block_template

        return get_daily_talk_block_template(language).format(content=content)

    # --- Semantic recall block builder ---

    @staticmethod
    def _build_block(snippet: str, language: str) -> str:
        from lightclaw.agent.prompt_catalog import get_auto_recall_block_template

        return get_auto_recall_block_template(language).format(snippet=snippet)
