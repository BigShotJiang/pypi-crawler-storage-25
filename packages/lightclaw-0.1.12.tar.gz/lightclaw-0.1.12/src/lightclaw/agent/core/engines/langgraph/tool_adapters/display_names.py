"""Display name registry for built-in LightClaw tools.

Provides localised labels used in channel messages and the dashboard UI.
Only built-in tools and shipped skills are registered here; MCP / custom
user skills fall back to their raw snake_case names.
"""

from __future__ import annotations

# Structure: tool_name -> {lang_code -> display_name}
# Supported lang codes mirror config.agents.language: "zh" | "en"
_NAMES: dict[str, dict[str, str]] = {
    # ── Built-in tools ────────────────────────────────────────────────────
    "execute_shell_command": {"zh": "执行命令", "en": "Execute Command"},
    "read_file": {"zh": "读取文件", "en": "Read File"},
    "write_file": {"zh": "写入文件", "en": "Write File"},
    "append_file": {"zh": "追加文件", "en": "Append File"},
    "edit_file": {"zh": "编辑文件", "en": "Edit File"},
    "grep_search": {"zh": "搜索内容", "en": "Search Content"},
    "glob_search": {"zh": "查找文件", "en": "Find Files"},
    "browser_control": {"zh": "控制浏览器", "en": "Browser Control"},
    "desktop_screenshot": {"zh": "截图", "en": "Take Screenshot"},
    "file_preview": {"zh": "预览文件", "en": "Preview File"},
    "get_current_time": {"zh": "获取时间", "en": "Get Time"},
    "set_user_timezone": {"zh": "设置时区", "en": "Set Timezone"},
    "lightclaw_search": {"zh": "AI 搜索", "en": "AI Web Search"},
    "tavily_search": {"zh": "Tavily 搜索", "en": "Tavily Search"},
    "brave_search": {"zh": "Brave 搜索", "en": "Brave Search"},
    "google_search": {"zh": "Google 搜索", "en": "Google Search"},
    "kimi_search": {"zh": "Kimi 搜索", "en": "Kimi Search"},
    "send_file_to_user": {"zh": "发送文件", "en": "Send File"},
    # ── Shipped skills ────────────────────────────────────────────────────
    # Skill runtime tool names follow the SKILL.md frontmatter `name` field
    # (normalised via _normalize_skill_tool_name). Three skills have names
    # that differ from their directory:
    #   - file-reader      → file_reader
    #   - publisher-multi-platform → wechat-publisher-personal
    #   - tencentcloud-infra → Tencent_Cloud_Infra (contains spaces)
    "cloudbase": {"zh": "云开发", "en": "CloudBase"},
    "cron": {"zh": "定时任务", "en": "Cron Tasks"},
    "cvm-ai-doctor": {"zh": "系统诊断", "en": "System Doctor"},
    "file_reader": {"zh": "读取文档", "en": "File Reader"},
    "health-check": {"zh": "健康检查", "en": "Health Check"},
    "health_check": {"zh": "健康检查", "en": "Health Check"},
    "install-skill": {"zh": "安装技能", "en": "Install Skill"},
    "lightclaw-backup": {"zh": "数据备份", "en": "Backup"},
    "mcporter": {"zh": "MCP 服务", "en": "MCP Porter"},
    "opencli": {"zh": "网页自动化", "en": "Web Automation"},
    "pdf": {"zh": "PDF 处理", "en": "PDF Toolkit"},
    "ppt-to-video": {"zh": "PPT 转视频", "en": "PPT to Video"},
    "wechat-publisher-personal": {"zh": "一文多发", "en": "Multi-Platform Publisher"},
    "searxng": {"zh": "联网搜索", "en": "Web Search"},
    "skill-creator": {"zh": "创建技能", "en": "Skill Creator"},
    "style-media-lib": {"zh": "素材库", "en": "Media Library"},
    "Tencent_Cloud_Infra": {"zh": "腾讯云运维", "en": "Tencent Cloud Infra"},
    "tencentcloud-infra": {"zh": "腾讯云运维", "en": "Tencent Cloud Infra"},
}


def get_display_name(tool_name: str, lang: str = "zh") -> str:
    """Return localised display name for a tool.

    Falls back to the raw tool_name when the name is not registered or the
    requested language is not available for that entry.

    Args:
        tool_name: Raw tool identifier (e.g. ``execute_shell_command``).
        lang: BCP-47-style language code (``"zh"`` or ``"en"``).
    """
    entry = _NAMES.get(tool_name)
    if not entry:
        return tool_name
    return entry.get(lang) or entry.get("en") or tool_name


def get_all_display_names(lang: str = "zh") -> dict[str, str]:
    """Return a flat mapping of tool_name -> display_name for the given language.

    Intended for consumption by the dashboard UI via the REST API.

    Args:
        lang: BCP-47-style language code (``"zh"`` or ``"en"``).
    """
    return {name: get_display_name(name, lang) for name in _NAMES}
