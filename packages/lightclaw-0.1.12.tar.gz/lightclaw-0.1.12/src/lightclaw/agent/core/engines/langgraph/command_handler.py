"""LangGraph implementation of the command handler.

Operates on LangChain ``BaseMessage`` lists and ``LightClawMiddleware``
state, but exposes the engine-agnostic ``BaseCommandHandler`` interface
so callers remain decoupled from LangGraph internals.
"""

from __future__ import annotations

import logging
from typing import TYPE_CHECKING

from langchain_core.messages import BaseMessage, SystemMessage

from lightclaw.agent.core.command_handler import BaseCommandHandler
from lightclaw.agent.prompt_catalog import render_slash_command_message
from lightclaw.agent.utils.token_counting import count_message_tokens, count_str_tokens
from lightclaw.app.services.providers_service import update_provider_settings
from lightclaw.domain.identity import build_canonical_user_id
from lightclaw.infra.providers import mask_api_key

if TYPE_CHECKING:
    from lightclaw.agent.core.engines.langgraph.middleware import LightClawMiddleware
    from lightclaw.agent.core.engines.langgraph.session_store import LangGraphSessionStore
    from lightclaw.agent.memory import MemoryManager

logger = logging.getLogger(__name__)


class LangGraphCommandHandler(BaseCommandHandler):
    """Handle slash commands for the LangGraph execution path.

    Operates on:
    * ``list[BaseMessage]`` — the LangGraph conversation state
    * ``LightClawMiddleware`` — for compressed summary state
    * ``LangGraphSessionStore`` — for session persistence
    """

    def __init__(
        self,
        *,
        agent_name: str = "LightClaw",
        history_messages: list[BaseMessage],
        middleware: LightClawMiddleware,
        session_store: LangGraphSessionStore,
        session_id: str,
        user_id: str | None,
        channel: str = "",
        language: str = "zh",
        memory_manager: MemoryManager | None = None,
        turn_model: object | None = None,
        chat_manager: object | None = None,
    ) -> None:
        self._agent_name = agent_name
        self._history = history_messages
        self._middleware = middleware
        self._session_store = session_store
        self._session_id = session_id
        self._user_id = user_id
        self._channel = channel
        self._language = "en" if language == "en" else "zh"
        self._memory_manager = memory_manager
        self._turn_model = turn_model
        self._chat_manager = chat_manager

    @property
    def _non_system_messages(self) -> list[BaseMessage]:
        return [m for m in self._history if not isinstance(m, SystemMessage)]

    # ------------------------------------------------------------------
    # BaseCommandHandler interface
    # ------------------------------------------------------------------

    async def handle(self, query: str) -> str:
        """Dispatch a command string to its handler, returning plain text."""
        model_token = None
        if (
            self._memory_manager is not None
            and self._turn_model is not None
            and hasattr(self._memory_manager, "bind_turn_chat_model")
        ):
            model_token = self._memory_manager.bind_turn_chat_model(self._turn_model)

        try:
            # Split into command name and optional inline argument.
            parts = query.strip().lstrip("/").split(None, 1)
            command = parts[0] if parts else ""
            arg = parts[1].strip() if len(parts) > 1 else ""
            handler = getattr(self, f"_cmd_{command}", None)
            if handler is None:
                return render_slash_command_message(
                    "unknown_command",
                    language=self._language,
                    query=query,
                )
            logger.info("LangGraph command handler: /%s", command)
            return await handler(arg)
        finally:
            if (
                self._memory_manager is not None
                and model_token is not None
                and hasattr(self._memory_manager, "reset_turn_chat_model")
            ):
                self._memory_manager.reset_turn_chat_model(model_token)

    # ------------------------------------------------------------------
    # Individual commands
    # ------------------------------------------------------------------

    async def _cmd_compact(self, _arg: str = "") -> str:
        msgs = self._non_system_messages
        if not msgs:
            return render_slash_command_message(
                "compact_no_messages",
                language=self._language,
            )
        if self._memory_manager is None:
            return render_slash_command_message(
                "compact_memory_manager_disabled",
                language=self._language,
            )

        self._memory_manager.add_async_summary_task(
            messages=msgs,
            channel=self._channel,
            session_id=self._session_id,
        )

        compact_content = await self._memory_manager.compact_memory(
            messages_to_summarize=msgs,
            previous_summary=self._middleware.compressed_summary,
        )
        self._middleware.compressed_summary = compact_content

        sys_msgs = [m for m in self._history if isinstance(m, SystemMessage)]
        self._history.clear()
        self._history.extend(sys_msgs)

        await self._session_store.asave(
            self._session_id,
            self._user_id,
            self._history,
            compressed_summary=compact_content,
            channel=self._channel,
            canonical_user_id=build_canonical_user_id(self._channel, self._user_id)
            if self._channel and self._user_id
            else "",
        )

        return render_slash_command_message(
            "compact_complete",
            language=self._language,
            message_count=len(msgs),
            summary=compact_content,
        )

    async def _cmd_new(self, _arg: str = "") -> str:
        msgs = self._non_system_messages
        if not msgs:
            self._middleware.compressed_summary = ""
            return render_slash_command_message(
                "new_no_messages",
                language=self._language,
            )

        if self._memory_manager is not None:
            self._memory_manager.add_async_summary_task(
                messages=msgs,
                channel=self._channel,
                session_id=self._session_id,
            )

        self._middleware.compressed_summary = ""

        sys_msgs = [m for m in self._history if isinstance(m, SystemMessage)]
        self._history.clear()
        self._history.extend(sys_msgs)

        # Detach the index entry so the old file is preserved and the next
        # save allocates a fresh timestamped filename for the new conversation.
        await self._session_store.adetach(
            self._session_id,
            self._user_id,
            channel=self._channel,
        )

        # ── Topic boundary: register a fresh ChatSpec for the new topic ──
        # Each ``/new`` delimits a logically separate "topic" within the
        # same IM conversation. We give the new topic its own ChatSpec so
        # that token usage, fact extraction and per-topic statistics can
        # be tracked in isolation.
        topic_hint = ""
        if self._chat_manager is not None and self._user_id:
            try:
                topic_hint = await self._register_topic_chat()
            except Exception:
                logger.exception("Failed to register topic ChatSpec on /new (non-fatal)")

        summary_hint = (
            render_slash_command_message("new_summary_hint", language=self._language)
            if self._memory_manager is not None
            else ""
        )
        return render_slash_command_message(
            "new_started",
            language=self._language,
            summary_hint=(topic_hint + summary_hint) if topic_hint else summary_hint,
        )

    async def _register_topic_chat(self) -> str:
        """Allocate a topic number and create a new ChatSpec for the new topic.

        Returns a short human-readable hint (e.g. ``"\\n\\n📌 已开启新话题 #3"``)
        suitable for prepending to the ``/new`` confirmation message.
        Returns ``""`` when ChatManager is not wired or required ids are
        missing — in that case the legacy single-chat behaviour is preserved.
        """
        cm = self._chat_manager
        if cm is None or not self._user_id:
            return ""

        canonical_user_id = build_canonical_user_id(self._channel, self._user_id) if self._channel else ""

        # Allocate a monotonic topic number (per canonical user).
        topic_number = await cm.allocate_topic_number(canonical_user_id) if canonical_user_id else 1

        # The new ChatSpec's session_id reuses the channel-level key. The
        # *active session file* changes (because adetach() ran above), but
        # multiple ChatSpecs can share the same channel-level session_id —
        # ``filter_chats`` already returns the most recent one, so inbound
        # routing stays correct.
        new_chat = await cm.create_topic_chat(
            session_id=self._session_id,
            user_id=self._user_id,
            channel=self._channel,
            canonical_user_id=canonical_user_id,
            topic_number=topic_number,
        )
        logger.info(
            "/new registered topic chat: chat_id=%s topic_number=%d",
            new_chat.id,
            topic_number,
        )

        if self._language == "en":
            return f"\n\n📌 New topic #{topic_number} started — token usage will be tracked separately.\n"
        return f"\n\n📌 已开启新话题 #{topic_number}，将独立记录 token 消耗。\n"

    async def _cmd_clear(self, _arg: str = "") -> str:
        self._history.clear()
        self._middleware.compressed_summary = ""
        await self._session_store.aclear(
            self._session_id,
            self._user_id,
            channel=self._channel,
        )
        return render_slash_command_message(
            "clear_completed",
            language=self._language,
        )

    async def _cmd_history(self, _arg: str = "") -> str:
        msgs = self._non_system_messages
        summary = self._middleware.compressed_summary or ""
        summary_tokens = count_str_tokens(summary)
        msg_tokens = count_message_tokens(msgs)
        estimated_tokens = msg_tokens + summary_tokens

        lines = []
        for i, m in enumerate(msgs, 1):
            role = type(m).__name__.replace("Message", "")
            content_preview = (
                m.content[:100] + "..." if isinstance(m.content, str) and len(m.content) > 100 else str(m.content)[:100]
            )
            lines.append(f"[{i}] **{role}**: {content_preview}")

        return render_slash_command_message(
            "history",
            language=self._language,
            message_count=len(msgs),
            estimated_tokens=estimated_tokens,
            summary_tokens=summary_tokens,
            entries="\n\n".join(lines),
        )

    async def _cmd_compact_str(self, _arg: str = "") -> str:
        summary = self._middleware.compressed_summary
        if not summary:
            return render_slash_command_message(
                "compact_summary_empty",
                language=self._language,
            )
        return render_slash_command_message(
            "compact_summary",
            language=self._language,
            summary=summary,
        )

    async def _cmd_await_summary(self, _arg: str = "") -> str:
        if self._memory_manager is None:
            return render_slash_command_message(
                "await_summary_memory_manager_disabled",
                language=self._language,
            )
        task_count = len(self._memory_manager.summary_tasks)
        if task_count == 0:
            return render_slash_command_message(
                "await_summary_no_tasks",
                language=self._language,
            )
        result = await self._memory_manager.await_summary_tasks()
        return render_slash_command_message(
            "await_summary_completed",
            language=self._language,
            task_count=task_count,
            result=result,
        )

    async def _cmd_setcodingplankey(self, arg: str = "") -> str:
        """Set Tencent Cloud Coding Plan API key directly from the command argument.

        Usage: /setcodingplankey <api_key>
        If no key is provided inline, show usage instructions.
        """
        api_key = arg.strip()
        if not api_key:
            return render_slash_command_message(
                "setcodingplankey_usage",
                language=self._language,
            )
        try:
            data = update_provider_settings(
                "tencent-coding-plan",
                api_key=api_key,
            )
            entry = data.providers.get("tencent-coding-plan")
            masked_key = mask_api_key(entry.api_key) if entry and entry.api_key else "(not set)"
            return render_slash_command_message(
                "setcodingplankey_completed",
                language=self._language,
                provider_name="Tencent Cloud Coding Plan",
                api_key_masked=masked_key,
            )
        except Exception as e:
            logger.error("Failed to set Coding Plan API key: %s", e)
            return render_slash_command_message(
                "setcodingplankey_failed",
                language=self._language,
                error=str(e),
            )

    async def _cmd_bgtokenusage(self, _arg: str = "") -> str:
        """Show per-bucket background memory task token usage since startup."""
        if self._memory_manager is None:
            return render_slash_command_message(
                "usage_memory_manager_disabled",
                language=self._language,
            )

        raw = self._memory_manager.get_background_usage()
        if not raw:
            return render_slash_command_message(
                "usage_no_data",
                language=self._language,
            )

        # Human-readable bucket labels.
        bucket_labels_zh: dict[str, str] = {
            "compaction": "上下文压缩",
            "distillation": "记忆蒸馏",
            "session_distillation": "会话蒸馏",
            "summary": "每日摘要",
            "daily_talk_condensation": "日常对话精简",
            "memory_md_compaction": "MEMORY.md 压缩",
        }
        bucket_labels_en: dict[str, str] = {
            "compaction": "Context Compaction",
            "distillation": "Memory Distillation",
            "session_distillation": "Session Distillation",
            "summary": "Daily Summary",
            "daily_talk_condensation": "Daily Talk Condensation",
            "memory_md_compaction": "MEMORY.md Compaction",
        }
        labels = bucket_labels_zh if self._language == "zh" else bucket_labels_en

        def _fmt(n: int) -> str:
            """Format token count with thousand separators."""
            return f"{n:,}"

        lines: list[str] = []
        total_input = 0
        total_output = 0
        total_tokens = 0
        total_calls = 0

        # Sort buckets by total_tokens descending.
        sorted_buckets = sorted(raw.items(), key=lambda kv: kv[1].get("total_tokens", 0), reverse=True)
        for name, bucket in sorted_buckets:
            inp = bucket.get("input_tokens", 0)
            out = bucket.get("output_tokens", 0)
            tot = bucket.get("total_tokens", 0)
            calls = bucket.get("calls", 0)
            if tot == 0:
                continue
            label = labels.get(name, name)
            lines.append(
                f"- **{label}**：{calls} 次调用 · 输入 {_fmt(inp)} · 输出 {_fmt(out)} · 总计 {_fmt(tot)}"
                if self._language == "zh"
                else f"- **{label}**: {calls} calls · Input {_fmt(inp)} · Output {_fmt(out)} · Total {_fmt(tot)}"
            )
            total_input += inp
            total_output += out
            total_tokens += tot
            total_calls += calls

        if not lines:
            return render_slash_command_message(
                "usage_no_data",
                language=self._language,
            )

        return render_slash_command_message(
            "usage_report",
            language=self._language,
            bucket_lines="\n".join(lines),
            total_calls=total_calls,
            total_input=_fmt(total_input),
            total_output=_fmt(total_output),
            total_tokens=_fmt(total_tokens),
        )

    async def _cmd_token(self, arg: str = "") -> str:
        """Show token usage statistics for the current chat or historical scopes.

        Syntax (free-form, all parts optional and order-insensitive within reason)::

            /token                       — current chat, all time
            /token today                 — current chat, today
            /token last_7d               — current chat, last 7 days
            /token all                   — all my chats, all time
            /token all 7d                — all my chats, last 7 days
            /token chats top 5 30d       — all my chats grouped by chat, top 5, last 30 days
            /token days 30d              — all my chats grouped by day, last 30 days
            /token channel weixin        — chats on channel "weixin"
            /token help                  — show this help
        """
        from lightclaw.app.usage import get_usage_query_service, render_usage_report

        parsed = _parse_token_command_args(arg)
        if parsed.get("help"):
            return _token_command_help(self._language)

        # Resolve current chat for "current_chat" scope.
        chat_id = ""
        canonical_user_id = ""
        if self._chat_manager is not None and self._session_id and self._user_id:
            try:
                chat = await self._chat_manager.get_or_create_chat(
                    session_id=self._session_id,
                    user_id=self._user_id or "",
                    channel=self._channel or "",
                )
                chat_id = getattr(chat, "id", "") or ""
                canonical_user_id = getattr(chat, "canonical_user_id", "") or ""
            except Exception:
                logger.exception("Failed to resolve current chat for /token")

        scope = parsed.get("scope") or "current_chat"
        time_window = parsed.get("time_window") or "all"
        granularity = parsed.get("granularity") or "total"
        channel_arg = parsed.get("channel") or ""
        top_n = int(parsed.get("top_n") or 10)

        service = await get_usage_query_service()
        report = await service.summarize(
            scope=scope,
            time_window=time_window,
            granularity=granularity,
            chat_id=chat_id or None,
            canonical_user_id=canonical_user_id or None,
            user_id=self._user_id or None,
            channel=channel_arg or (self._channel if scope == "channel" else None),
            top_n=top_n,
            include_ephemeral=False,
        )
        return render_usage_report(report, language=self._language)

    async def _cmd_topics(self, _arg: str = "") -> str:
        """List all topics for the current canonical user.

        Each topic is shown with its number, creation time, name, and
        cumulative token usage. Topics are ordered from newest to oldest;
        the active topic is marked with ``← 当前``.
        """
        if self._chat_manager is None or not self._user_id:
            if self._language == "en":
                return "_(no chat manager available)_"
            return "_（chat 管理器不可用）_"

        canonical_user_id = build_canonical_user_id(self._channel, self._user_id) if self._channel else ""
        if not canonical_user_id:
            return ""
        chats = await self._chat_manager.list_chats(canonical_user_id=canonical_user_id)
        if not chats:
            if self._language == "en":
                return "_(no topics yet)_"
            return "_（暂无话题）_"

        # Determine the active topic without side effects: prefer the chat
        # whose ``session_id`` matches the current run; if multiple share
        # the same triple, pick the most recently created. Never call
        # ``get_or_create_chat`` here — that would auto-create a phantom
        # ChatSpec just because the user typed ``/topics``.
        active_id = ""
        active_candidates = [
            c for c in chats if c.session_id == self._session_id and c.user_id == (self._user_id or "")
        ]
        if active_candidates:
            active_candidates.sort(key=lambda c: c.created_at, reverse=True)
            active_id = active_candidates[0].id

        # Sort newest-first by topic_number, fall back to created_at.
        chats.sort(
            key=lambda c: (
                (c.meta or {}).get("topic_number", 0),
                c.created_at,
            ),
            reverse=True,
        )

        lang = self._language
        lines: list[str] = []
        if lang == "en":
            lines.append(f"📑 **Topics** ({len(chats)} total)")
        else:
            lines.append(f"📑 **话题列表**（共 {len(chats)} 个）")
        lines.append("")

        for c in chats:
            meta = c.meta or {}
            raw_num = meta.get("topic_number")
            num: int | str = raw_num if isinstance(raw_num, int) and raw_num > 0 else "?"
            usage = meta.get("total_usage") or {}
            total = int(usage.get("total_tokens") or 0)
            runs = int(meta.get("total_runs") or 0)
            try:
                created = c.created_at.astimezone().strftime("%m-%d %H:%M")
            except Exception:
                created = ""
            name = (c.name or "").strip()
            if name == f"#{num}":
                name = ""
            mark = ""
            if c.id == active_id:
                mark = " **← 当前**" if lang == "zh" else " **← active**"

            tot_str = _fmt_compact_int(total)
            if lang == "en":
                lines.append(
                    f"- **#{num}** · {created}{(' · ' + name) if name else ''} — {tot_str} tokens, {runs} turns{mark}"
                )
            else:
                lines.append(
                    f"- **#{num}** · {created}{(' · ' + name) if name else ''} — {tot_str} token，{runs} 轮{mark}"
                )

        if lang == "en":
            lines.append("")
            lines.append("_Tip: ``/token`` for current topic; ``/new`` to start a new topic._")
        else:
            lines.append("")
            lines.append("_提示：``/token`` 查看当前话题；``/new`` 开启新话题。_")
        return "\n".join(lines)


# ---------------------------------------------------------------------------
# /token argument parsing (module-level, pure functions)
# ---------------------------------------------------------------------------

_TIME_WINDOW_ALIASES: dict[str, str] = {
    "today": "today",
    "yesterday": "yesterday",
    "yest": "yesterday",
    "7d": "last_7d",
    "last_7d": "last_7d",
    "last7d": "last_7d",
    "week": "last_7d",
    "30d": "last_30d",
    "last_30d": "last_30d",
    "last30d": "last_30d",
    "month": "last_30d",
    "this_month": "this_month",
    "thismonth": "this_month",
    "all": "all",
    "alltime": "all",
}


def _parse_token_command_args(arg: str) -> dict[str, object]:
    """Parse free-form ``/token`` arguments into a dict.

    Recognized tokens (case-insensitive, order-insensitive):

    * ``help``                                — show usage
    * ``today`` / ``yesterday`` / ``7d`` /
      ``30d`` / ``last_7d`` / ``last_30d`` /
      ``this_month`` / ``all``                — time window
    * ``all`` (without other window in same arg position) following nothing
      → user_all_chats scope
    * ``chats`` / ``by_chat`` / ``by_chats``  — granularity by_chat
    * ``days`` / ``by_day``                   — granularity by_day
    * ``channels`` / ``by_channel``           — granularity by_channel
    * ``channel <name>``                      — scope=channel, name=<name>
    * ``top <N>``                             — top_n=N
    * a bare integer (1..100)                 — top_n
    """
    result: dict[str, object] = {}
    if not arg:
        return result

    tokens = arg.strip().lower().split()
    if not tokens:
        return result

    if tokens[0] in {"help", "?", "-h", "--help"}:
        result["help"] = True
        return result

    i = 0
    saw_all_keyword = False
    while i < len(tokens):
        tok = tokens[i]

        # channel <name>
        if tok == "channel" and i + 1 < len(tokens):
            result["scope"] = "channel"
            result["channel"] = tokens[i + 1]
            i += 2
            continue

        # top <N>
        if tok == "top" and i + 1 < len(tokens):
            try:
                result["top_n"] = max(1, min(int(tokens[i + 1]), 100))
                i += 2
                continue
            except ValueError:
                i += 2
                continue

        # granularity keywords
        if tok in {"chats", "by_chat", "by_chats"}:
            result["granularity"] = "by_chat"
            i += 1
            continue
        if tok in {"days", "by_day"}:
            result["granularity"] = "by_day"
            i += 1
            continue
        if tok in {"channels", "by_channel"}:
            result["granularity"] = "by_channel"
            i += 1
            continue

        # bare "all" toggles user-wide scope unless it is the time window
        if tok == "all":
            saw_all_keyword = True
            # may also map to time_window=all if no other window seen
            i += 1
            continue

        # time window aliases
        if tok in _TIME_WINDOW_ALIASES:
            result["time_window"] = _TIME_WINDOW_ALIASES[tok]
            i += 1
            continue

        # bare integer → top_n
        try:
            n = int(tok)
            result["top_n"] = max(1, min(n, 100))
            i += 1
            continue
        except ValueError:
            pass

        # Unknown token — ignore silently to keep the UX forgiving.
        i += 1

    if saw_all_keyword and "scope" not in result:
        result["scope"] = "user_all_chats"
    if saw_all_keyword and "time_window" not in result:
        # "all" by itself == user_all_chats / all-time
        result["time_window"] = "all"

    return result


def _token_command_help(language: str) -> str:
    if language == "en":
        return (
            "**/token — token usage stats**\n\n"
            "Examples:\n"
            "  • `/token`                  current chat, all time\n"
            "  • `/token today`            current chat, today\n"
            "  • `/token last_7d`          current chat, last 7 days\n"
            "  • `/token all`              all my chats, all time\n"
            "  • `/token all 7d`           all my chats, last 7 days\n"
            "  • `/token chats top 5 30d`  top-5 chats by usage in last 30 days\n"
            "  • `/token days 30d`         per-day breakdown for last 30 days\n"
            "  • `/token channel weixin`   chats on a specific channel\n"
        )
    return (
        "**/token — Token 用量统计**\n\n"
        "示例：\n"
        "  • `/token`                   当前会话 · 全部时间\n"
        "  • `/token today`             当前会话 · 今日\n"
        "  • `/token last_7d`           当前会话 · 最近 7 天\n"
        "  • `/token all`               我所有会话 · 全部时间\n"
        "  • `/token all 7d`            我所有会话 · 最近 7 天\n"
        "  • `/token chats top 5 30d`   近 30 天 token 消耗 top 5 的会话\n"
        "  • `/token days 30d`          近 30 天按天分布\n"
        "  • `/token channel weixin`    指定渠道的累计用量\n"
    )


def _fmt_compact_int(n: int) -> str:
    """Compact human-readable token count for short labels."""
    if n is None:
        return "0"
    n = int(n)
    if n < 1000:
        return str(n)
    if n < 1_000_000:
        return f"{n / 1000:.1f}k"
    return f"{n / 1_000_000:.1f}M"
