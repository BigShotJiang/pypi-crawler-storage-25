"""Build a LangGraph ReAct agent graph from AgentConfig.

This is the single entry point for constructing the compiled graph.
It wraps ``create_agent`` from ``langchain.agents`` and applies
LightClaw-specific settings (system prompt, recursion limit, middleware).

Example:
    >>> from lightclaw.agent.core import AgentConfig
    >>> from lightclaw.agent.core.engines.langgraph import LangGraphAgentBuilder
    >>> config = AgentConfig(model=model, tools=[...])
    >>> graph = LangGraphAgentBuilder().build(config)
    >>> result = graph.invoke({"messages": [("user", "hello")]})
"""

from __future__ import annotations

from typing import TYPE_CHECKING, Any

from langchain.agents import create_agent

from lightclaw.agent.core.interfaces import BaseAgentBuilder

if TYPE_CHECKING:
    from langgraph.graph.state import CompiledStateGraph

    from lightclaw.agent.core.config import AgentConfig


class LangGraphAgentBuilder(BaseAgentBuilder):
    """Builds a compiled LangGraph ReAct agent from an ``AgentConfig``."""

    def build(self, config: AgentConfig) -> CompiledStateGraph:
        """Compile and return a runnable LangGraph agent.

        Args:
            config: Engine-agnostic config carrying model, tools, prompt,
                and optional middleware.

        Returns:
            A compiled LangGraph state graph ready for ``.astream_events()``.
        """
        return build_lightclaw_graph(config)


def build_lightclaw_graph(config: Any) -> CompiledStateGraph:
    """Build and compile a LangGraph ReAct agent.

    Args:
        config: ``AgentConfig`` containing model, tools, system prompt,
            iteration limits, and optional middleware.

    Returns:
        A compiled LangGraph state graph, ready for ``.invoke()``
        or ``.astream_events()``.
    """
    graph = create_agent(
        model=config.model,
        tools=list(config.tools),
        system_prompt=config.system_prompt or None,
        middleware=[config.middleware] if config.middleware else (),
        context_schema=config.context_schema,
        name="LightClaw",
    )
    return graph
