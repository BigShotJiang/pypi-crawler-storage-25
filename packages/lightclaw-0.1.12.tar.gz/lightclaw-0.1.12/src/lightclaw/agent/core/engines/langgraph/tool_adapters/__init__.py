"""LangChain-compatible tool wrappers for the LangGraph agent.

This package wraps LightClaw's existing tool implementations as LangChain
``BaseTool`` instances so they can be used with ``create_agent``.

Usage:
    >>> from lightclaw.agent.core.engines.langgraph.tool_adapters import load_builtin_tools
    >>> tools = load_builtin_tools()
"""

from lightclaw.agent.core.engines.langgraph.tool_adapters.builtins import (
    edit_file,
    load_builtin_tools,
    read_file,
    write_file,
)
from lightclaw.agent.core.engines.langgraph.tool_adapters.memory import create_memory_search_langchain_tool
from lightclaw.agent.core.engines.langgraph.tool_adapters.memory_forget import create_memory_forget_langchain_tool
from lightclaw.agent.core.engines.langgraph.tool_adapters.retrieve_compressed import create_retrieve_compressed_tool
from lightclaw.agent.core.engines.langgraph.tool_adapters.skills import load_active_skills_as_tools

__all__ = [
    "create_memory_forget_langchain_tool",
    "create_memory_search_langchain_tool",
    "create_retrieve_compressed_tool",
    "edit_file",
    "load_active_skills_as_tools",
    "load_builtin_tools",
    "read_file",
    "write_file",
]
