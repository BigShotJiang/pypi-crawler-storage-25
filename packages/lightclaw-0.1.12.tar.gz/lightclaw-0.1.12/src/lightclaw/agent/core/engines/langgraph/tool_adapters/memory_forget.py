"""LangChain-compatible wrapper for the memory_forget tool.

Uses the same factory pattern as memory.py: accepts a
``MemoryManager`` instance and returns a bound tool.
"""

from __future__ import annotations

from typing import TYPE_CHECKING

from langchain_core.tools import StructuredTool

if TYPE_CHECKING:
    from lightclaw.agent.memory.memory_manager import MemoryManager


def create_memory_forget_langchain_tool(
    memory_manager: MemoryManager,
) -> StructuredTool:
    """Create a LangChain tool for deleting/forgetting memories.

    Supports three modes:
    - query: Search by semantic query, auto-delete high-confidence match
             or return candidates for user selection.
    - file_name: Delete an entire daily memory file by name.
    - chunk_ids: Delete specific chunks by ID (from prior search results).

    Args:
        memory_manager: A ``MemoryManager`` instance to delegate operations to.

    Returns:
        A ``StructuredTool`` that wraps memory forget operations.
    """

    async def _arun(
        query: str = "",
        file_name: str = "",
        chunk_ids: str = "",
    ) -> str:
        """Forget (delete) memories. Use one of three modes:

        1. query mode: Provide a natural language query to find and delete
           matching memories. If one result scores very high, it is
           auto-deleted. Otherwise, candidates are listed for user selection.
        2. file mode: Provide a file_name (e.g.
           "2026-03-15_console_abc_v1.md") to delete an entire daily memory
           file. Use "MEMORY.md" to clear all long-term memory.
        3. chunk_ids mode: Provide comma-separated chunk IDs to delete
           specific chunks (from candidates returned by a prior query call).

        Args:
            query: Semantic search query to find memories to forget.
            file_name: Daily memory filename to delete entirely.
            chunk_ids: Comma-separated chunk_id values to delete.
        """
        if file_name:
            return await memory_manager.memory_forget_by_file(file_name)
        if chunk_ids:
            ids = [cid.strip() for cid in chunk_ids.split(",") if cid.strip()]
            return await memory_manager.memory_forget_by_chunk_ids(ids)
        if query:
            return await memory_manager.memory_forget_by_query(query)
        return "Error: Provide at least one of: query, file_name, or chunk_ids."

    def _run(
        query: str = "",
        file_name: str = "",
        chunk_ids: str = "",
    ) -> str:
        raise NotImplementedError("memory_forget is async-only")

    return StructuredTool.from_function(
        func=_run,
        coroutine=_arun,
        name="memory_forget",
        description=(
            "Delete or forget specific memories. Use when the user asks to "
            "forget something, correct wrong memories, or delete memory files. "
            "Three modes: (1) query — search-and-delete by semantic query, "
            "(2) file_name — delete a daily memory file or clear MEMORY.md, "
            "(3) chunk_ids — delete specific chunks by their IDs."
        ),
    )
