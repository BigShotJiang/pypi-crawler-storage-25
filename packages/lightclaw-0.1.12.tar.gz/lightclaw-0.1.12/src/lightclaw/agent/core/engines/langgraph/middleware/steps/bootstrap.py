"""Bootstrap injection step — inject first-interaction guidance as system context once."""

from __future__ import annotations

import logging
import time
from pathlib import Path

from langchain_core.messages import BaseMessage, HumanMessage

logger = logging.getLogger(__name__)


class BootstrapInjector:
    """Inject first-interaction guidance as a system block, once.

    Reads BOOTSTRAP.md from working_dir and returns guidance text during the
    first user-initiated turn. The caller is responsible for merging the block
    into system context before model invocation. After a successful run,
    ``commit()`` creates .bootstrap_completed to prevent re-injection.

    Weibo onboarding is handled via ``ensure_weibo_onboarding()``, which is
    called unconditionally in the run controller's ``finally`` block.  As long
    as bootstrap has completed and IDENTITY.md has substantive content, the
    Weibo onboarding prompt will be armed for the next turn — guaranteed.
    """

    def __init__(self, working_dir: Path, language: str = "zh") -> None:
        self._working_dir = working_dir
        self._language = language
        self._done = False
        self._pending = False
        self._weibo_onboarding = WeiboOnboardingHook(working_dir=working_dir, language=language)

    @property
    def is_pending(self) -> bool:
        """True between inject() and commit() — bootstrap ran but not yet persisted."""
        return self._pending

    @property
    def weibo_onboarding(self) -> WeiboOnboardingHook:
        """Expose the Weibo onboarding hook for the coordinator to query."""
        return self._weibo_onboarding

    def debug_state(self) -> dict[str, object]:
        """Return a compact runtime state snapshot for diagnostics."""
        bootstrap_flag = self._working_dir / ".bootstrap_completed"
        bootstrap_path = self._working_dir / "BOOTSTRAP.md"
        return {
            "working_dir": str(self._working_dir),
            "done": self._done,
            "pending": self._pending,
            "bootstrap_completed": bootstrap_flag.exists(),
            "bootstrap_file_exists": bootstrap_path.exists(),
            "weibo_onboarding": self._weibo_onboarding.debug_state(),
        }

    def get_block(self, messages: list[BaseMessage]) -> str | None:
        """Return bootstrap guidance text for this turn, if applicable."""
        has_human_message = any(isinstance(message, HumanMessage) for message in messages)
        bootstrap_flag = self._working_dir / ".bootstrap_completed"
        bootstrap_path = self._working_dir / "BOOTSTRAP.md"
        should_log_info = bootstrap_path.exists() or bootstrap_flag.exists() or self._pending or self._done

        if should_log_info:
            logger.info(
                "[Bootstrap][stage][check] working_dir=%s done=%s pending=%s flag_exists=%s "
                "bootstrap_file_exists=%s messages=%d has_human=%s",
                self._working_dir,
                self._done,
                self._pending,
                bootstrap_flag.exists(),
                bootstrap_path.exists(),
                len(messages),
                has_human_message,
            )

        logger.debug(
            "[Bootstrap][check] working_dir=%s done=%s pending=%s flag_exists=%s "
            "bootstrap_file_exists=%s messages=%d has_human=%s",
            self._working_dir,
            self._done,
            self._pending,
            bootstrap_flag.exists(),
            bootstrap_path.exists(),
            len(messages),
            has_human_message,
        )
        if self._done:
            if should_log_info:
                logger.info(
                    "[Bootstrap][stage][skip] reason=already_done working_dir=%s pending=%s",
                    self._working_dir,
                    self._pending,
                )
            logger.debug(
                "[Bootstrap][skip] reason=already_done working_dir=%s pending=%s",
                self._working_dir,
                self._pending,
            )
            return None

        if bootstrap_flag.exists():
            self._done = True
            logger.info(
                "[Bootstrap][stage][skip] reason=already_completed working_dir=%s flag_path=%s",
                self._working_dir,
                bootstrap_flag,
            )
            logger.debug(
                "[Bootstrap][skip] reason=already_completed working_dir=%s flag_path=%s",
                self._working_dir,
                bootstrap_flag,
            )
            return None

        if not bootstrap_path.exists():
            self._done = True
            if should_log_info:
                logger.info(
                    "[Bootstrap][stage][skip] reason=missing_bootstrap_file working_dir=%s bootstrap_path=%s",
                    self._working_dir,
                    bootstrap_path,
                )
            logger.debug(
                "[Bootstrap][skip] reason=missing_bootstrap_file working_dir=%s bootstrap_path=%s",
                self._working_dir,
                bootstrap_path,
            )
            return None

        if not has_human_message:
            logger.info(
                "[Bootstrap][stage][skip] reason=no_human_message working_dir=%s messages=%d",
                self._working_dir,
                len(messages),
            )
            logger.debug(
                "[Bootstrap][skip] reason=no_human_message working_dir=%s messages=%d",
                self._working_dir,
                len(messages),
            )
            return None

        try:
            from lightclaw.agent.prompt import build_bootstrap_guidance

            guidance = build_bootstrap_guidance(self._language)
            if not guidance:
                self._done = True
                logger.info(
                    "[Bootstrap][stage][skip] reason=empty_guidance working_dir=%s language=%s",
                    self._working_dir,
                    self._language,
                )
                logger.warning(
                    "[Bootstrap][skip] reason=empty_guidance working_dir=%s language=%s",
                    self._working_dir,
                    self._language,
                )
                return None

            self._pending = True
            self._done = True
            logger.info(
                "[Bootstrap][stage][inject] working_dir=%s language=%s guidance_chars=%d pending=%s",
                self._working_dir,
                self._language,
                len(guidance),
                self._pending,
            )
            return guidance
        except Exception:
            logger.exception(
                "[Bootstrap][error] failed_to_prepare_guidance working_dir=%s language=%s "
                "bootstrap_path=%s flag_path=%s",
                self._working_dir,
                self._language,
                bootstrap_path,
                bootstrap_flag,
            )
            self._done = True
            return None

    def commit(self) -> None:
        """Persist the bootstrap completion flag after a successful run.

        Creates the ``.bootstrap_completed`` marker and removes
        ``BOOTSTRAP.md`` so bootstrap does not reappear after completion.
        Weibo onboarding arming is handled separately by
        ``ensure_weibo_onboarding()`` which runs unconditionally in the run
        controller's ``finally`` block.
        """
        if not self._pending:
            state = self.debug_state()
            if state.get("bootstrap_file_exists") or state.get("bootstrap_completed"):
                logger.info(
                    "[Bootstrap][stage][commit_skip] reason=not_pending working_dir=%s state=%s",
                    self._working_dir,
                    state,
                )
            logger.debug(
                "[Bootstrap][commit][skip] reason=not_pending working_dir=%s state=%s",
                self._working_dir,
                state,
            )
            return
        flag_path = self._working_dir / ".bootstrap_completed"
        bootstrap_path = self._working_dir / "BOOTSTRAP.md"
        try:
            flag_exists_before = flag_path.exists()
            bootstrap_file_exists_before = bootstrap_path.exists()
            logger.info(
                "[Bootstrap][stage][commit_start] working_dir=%s flag_path=%s bootstrap_path=%s "
                "flag_exists_before=%s bootstrap_file_exists_before=%s",
                self._working_dir,
                flag_path,
                bootstrap_path,
                flag_exists_before,
                bootstrap_file_exists_before,
            )
            io_started_at = time.perf_counter()
            flag_path.touch()
            logger.info(
                "[Bootstrap][io] op=touch_bootstrap_flag path=%s duration_ms=%.2f",
                flag_path,
                (time.perf_counter() - io_started_at) * 1000,
            )
            io_started_at = time.perf_counter()
            bootstrap_path.unlink(missing_ok=True)
            logger.info(
                "[Bootstrap][io] op=unlink_bootstrap_md path=%s duration_ms=%.2f existed_before=%s",
                bootstrap_path,
                (time.perf_counter() - io_started_at) * 1000,
                bootstrap_file_exists_before,
            )
            logger.info(
                "[Bootstrap][stage][commit_done] working_dir=%s flag_path=%s bootstrap_path=%s "
                "flag_exists_before=%s bootstrap_file_exists_before=%s",
                self._working_dir,
                flag_path,
                bootstrap_path,
                flag_exists_before,
                bootstrap_file_exists_before,
            )
        except Exception:
            logger.exception(
                "[Bootstrap][commit][error] working_dir=%s flag_path=%s bootstrap_path=%s",
                self._working_dir,
                flag_path,
                bootstrap_path,
            )
        finally:
            self._pending = False
            logger.debug(
                "[Bootstrap][commit][done] working_dir=%s state=%s",
                self._working_dir,
                self.debug_state(),
            )

    def ensure_weibo_onboarding(self) -> None:
        """Unconditionally attempt to arm the Weibo onboarding hook.

        Designed to be called from the run controller's ``finally`` block so
        it executes on **every** turn regardless of success/failure.  The
        hook itself is idempotent — it only arms when:

        1. Bootstrap has completed (``.bootstrap_completed`` exists).
        2. IDENTITY.md has substantive content (name or MBTI filled in).
        3. The hook has not already been armed or fired.

        This guarantees that as soon as the agent finishes writing IDENTITY.md
        in any turn, the very next turn will see the Weibo onboarding prompt.
        """
        try:
            bootstrap_flag = self._working_dir / ".bootstrap_completed"
            if bootstrap_flag.exists():
                logger.info(
                    "[Bootstrap][stage][ensure_weibo_check] working_dir=%s bootstrap_flag=%s state=%s",
                    self._working_dir,
                    bootstrap_flag,
                    self._weibo_onboarding.debug_state(),
                )
            if not bootstrap_flag.exists():
                bootstrap_path = self._working_dir / "BOOTSTRAP.md"
                if bootstrap_path.exists():
                    logger.info(
                        "[Bootstrap][stage][ensure_weibo_skip] reason=bootstrap_not_completed "
                        "working_dir=%s bootstrap_path=%s",
                        self._working_dir,
                        bootstrap_path,
                    )
                logger.debug(
                    "[Bootstrap][weibo][ensure][skip] reason=bootstrap_not_completed working_dir=%s flag_path=%s",
                    self._working_dir,
                    bootstrap_flag,
                )
                return
            logger.debug(
                "[Bootstrap][weibo][ensure] working_dir=%s state_before=%s",
                self._working_dir,
                self._weibo_onboarding.debug_state(),
            )
            self._weibo_onboarding.maybe_arm()
            logger.debug(
                "[Bootstrap][weibo][ensure] working_dir=%s state_after=%s",
                self._working_dir,
                self._weibo_onboarding.debug_state(),
            )
            logger.info(
                "[Bootstrap][stage][ensure_weibo_done] working_dir=%s state=%s",
                self._working_dir,
                self._weibo_onboarding.debug_state(),
            )
        except Exception:
            logger.exception(
                "[Bootstrap][weibo][ensure][error] working_dir=%s state=%s",
                self._working_dir,
                self._weibo_onboarding.debug_state(),
            )


class WeiboOnboardingHook:
    """One-shot hook that injects a Weibo posting guide after bootstrap identity setup.

    Armed by ``BootstrapInjector.commit()`` when IDENTITY.md has substantive
    content.  The armed state is persisted to a flag file so it survives across
    process restarts.  ``get_block()`` returns the prompt exactly once, then
    disarms itself.
    """

    _FLAG_NAME = ".weibo_onboarding_armed"
    _DONE_FLAG_NAME = ".weibo_onboarding_done"

    def __init__(self, working_dir: Path, language: str = "zh") -> None:
        self._working_dir = working_dir
        self._language = language
        # Migrate legacy instances: if bootstrap completed but neither the
        # armed flag nor the done flag exists, the old code must have already
        # fired the hook (it only deleted the armed flag without writing a
        # done flag).  Auto-create the done flag so we never re-arm.
        bootstrap_flag = self._working_dir / ".bootstrap_completed"
        if (
            bootstrap_flag.exists()
            and not self._done_flag_path.exists()
            and not self._flag_path.exists()
        ):
            try:
                self._done_flag_path.touch()
                logger.info(
                    "[Bootstrap][weibo][migrate] auto-created done flag for legacy instance "
                    "working_dir=%s",
                    self._working_dir,
                )
            except Exception:
                logger.exception(
                    "[Bootstrap][weibo][migrate] failed to create done flag working_dir=%s",
                    self._working_dir,
                )
        # Restore fired state from the persistent done flag so that a
        # process restart does not re-arm the one-shot hook.
        self._fired = self._done_flag_path.exists()

    @property
    def _flag_path(self) -> Path:
        return self._working_dir / self._FLAG_NAME

    @property
    def _done_flag_path(self) -> Path:
        return self._working_dir / self._DONE_FLAG_NAME

    def debug_state(self) -> dict[str, object]:
        """Return the one-shot hook state for diagnostics."""
        identity_path = self._working_dir / "IDENTITY.md"
        return {
            "working_dir": str(self._working_dir),
            "fired": self._fired,
            "armed_flag_exists": self._flag_path.exists(),
            "done_flag_exists": self._done_flag_path.exists(),
            "identity_exists": identity_path.exists(),
        }

    def maybe_arm(self) -> None:
        """Arm the hook if IDENTITY.md has substantive content.

        Idempotent: no-op if already armed (flag file exists) or already fired
        (the onboarding prompt was already delivered, persisted via done flag).
        """
        if self._fired:
            logger.info(
                "[Bootstrap][stage][weibo_skip] reason=already_fired working_dir=%s",
                self._working_dir,
            )
            logger.debug(
                "[Bootstrap][weibo][arm][skip] reason=already_fired working_dir=%s",
                self._working_dir,
            )
            return
        if self._flag_path.exists():
            logger.info(
                "[Bootstrap][stage][weibo_skip] reason=already_armed working_dir=%s flag_path=%s",
                self._working_dir,
                self._flag_path,
            )
            logger.debug(
                "[Bootstrap][weibo][arm][skip] reason=already_armed working_dir=%s flag_path=%s",
                self._working_dir,
                self._flag_path,
            )
            return
        identity_path = self._working_dir / "IDENTITY.md"
        if not identity_path.exists():
            logger.info(
                "[Bootstrap][stage][weibo_skip] reason=missing_identity working_dir=%s identity_path=%s",
                self._working_dir,
                identity_path,
            )
            logger.debug(
                "[Bootstrap][weibo][arm][skip] reason=missing_identity working_dir=%s identity_path=%s",
                self._working_dir,
                identity_path,
            )
            return
        try:
            io_started_at = time.perf_counter()
            content = identity_path.read_text(encoding="utf-8")
            logger.info(
                "[Bootstrap][io] op=read_identity path=%s duration_ms=%.2f chars=%d",
                identity_path,
                (time.perf_counter() - io_started_at) * 1000,
                len(content),
            )
        except Exception:
            logger.exception(
                "[Bootstrap][weibo][arm][error] reason=read_identity_failed working_dir=%s identity_path=%s",
                self._working_dir,
                identity_path,
            )
            return

        identity_state = _inspect_identity_substance(content)
        if identity_state["has_substance"]:
            io_started_at = time.perf_counter()
            self._flag_path.touch()
            logger.info(
                "[Bootstrap][io] op=touch_weibo_flag path=%s duration_ms=%.2f",
                self._flag_path,
                (time.perf_counter() - io_started_at) * 1000,
            )
            logger.info(
                "[Bootstrap][stage][weibo_arm] working_dir=%s flag_path=%s identity_path=%s "
                "identity_chars=%d has_name=%s has_mbti=%s",
                self._working_dir,
                self._flag_path,
                identity_path,
                len(content),
                identity_state["has_name"],
                identity_state["has_mbti"],
            )
            return

        logger.info(
            "[Bootstrap][stage][weibo_skip] reason=identity_not_ready working_dir=%s "
            "identity_path=%s identity_chars=%d has_name=%s has_mbti=%s",
            self._working_dir,
            identity_path,
            len(content),
            identity_state["has_name"],
            identity_state["has_mbti"],
        )
        logger.debug(
            "[Bootstrap][weibo][arm][skip] reason=identity_not_ready working_dir=%s "
            "identity_path=%s identity_chars=%d has_name=%s has_mbti=%s",
            self._working_dir,
            identity_path,
            len(content),
            identity_state["has_name"],
            identity_state["has_mbti"],
        )

    def get_block(self, messages: list[BaseMessage]) -> str | None:
        """Return the Weibo onboarding prompt once, then disarm.

        Only fires when the armed flag file exists and there is a user message
        in the current turn.
        """
        if self._fired:
            logger.info(
                "[Bootstrap][stage][weibo_inject_skip] reason=already_fired working_dir=%s",
                self._working_dir,
            )
            logger.debug(
                "[Bootstrap][weibo][inject][skip] reason=already_fired working_dir=%s",
                self._working_dir,
            )
            return None
        if not self._flag_path.exists():
            logger.info(
                "[Bootstrap][stage][weibo_inject_skip] reason=not_armed working_dir=%s flag_path=%s",
                self._working_dir,
                self._flag_path,
            )
            logger.debug(
                "[Bootstrap][weibo][inject][skip] reason=not_armed working_dir=%s flag_path=%s",
                self._working_dir,
                self._flag_path,
            )
            return None
        has_human_message = any(isinstance(message, HumanMessage) for message in messages)
        if not has_human_message:
            logger.info(
                "[Bootstrap][stage][weibo_inject_skip] reason=no_human_message working_dir=%s messages=%d",
                self._working_dir,
                len(messages),
            )
            logger.debug(
                "[Bootstrap][weibo][inject][skip] reason=no_human_message working_dir=%s messages=%d",
                self._working_dir,
                len(messages),
            )
            return None

        # Disarm: remove the armed flag, write the persistent done flag,
        # and mark as fired so the hook never re-arms — even across restarts.
        try:
            io_started_at = time.perf_counter()
            self._flag_path.unlink(missing_ok=True)
            logger.info(
                "[Bootstrap][io] op=unlink_weibo_flag path=%s duration_ms=%.2f",
                self._flag_path,
                (time.perf_counter() - io_started_at) * 1000,
            )
        except Exception:
            logger.exception("Failed to remove Weibo onboarding flag")
        try:
            io_started_at = time.perf_counter()
            self._done_flag_path.touch()
            logger.info(
                "[Bootstrap][io] op=touch_weibo_done_flag path=%s duration_ms=%.2f",
                self._done_flag_path,
                (time.perf_counter() - io_started_at) * 1000,
            )
        except Exception:
            logger.exception("Failed to write Weibo onboarding done flag")
        self._fired = True
        prompt = _build_weibo_onboarding_prompt(self._language)
        logger.info(
            "[Bootstrap][stage][weibo_inject] working_dir=%s flag_path=%s prompt_chars=%d messages=%d",
            self._working_dir,
            self._flag_path,
            len(prompt),
            len(messages),
        )

        return prompt


def _identity_has_substance(content: str) -> bool:
    """Return True if IDENTITY.md contains real identity info (not just a template).

    Handles both Chinese and English template formats:
    - Chinese: ``**名字：** 仅仅``, ``名字：仅仅``
    - English: ``**Name:** TestBot``, ``name: TestBot``
    - MBTI: ``**类型：** INTJ``, ``E/I：I 70%``, ``E/I: I 70%``
    """
    return _inspect_identity_substance(content)["has_substance"]


def _inspect_identity_substance(content: str) -> dict[str, bool]:
    """Inspect whether IDENTITY.md contains meaningful identity fields."""
    import re

    # Strip Markdown bold markers so "**Name:**" becomes "Name:"
    stripped = re.sub(r"\*\*", "", content)

    # Normalise Chinese full-width colon to ASCII colon for uniform matching.
    normalised = stripped.replace("\uff1a", ":")
    lower = normalised.lower()

    # Check for a filled-in name field (Chinese or English).
    name_patterns = ("名字:", "name:")
    has_name = False
    for pat in name_patterns:
        if pat in lower:
            for line in lower.splitlines():
                if pat in line:
                    value = line.split(pat, 1)[1].strip()
                    # Ignore template placeholders like "*(取一个你喜欢的)*" or "*(pick ...)*"
                    if value and not value.startswith("*(") and not value.startswith("*\uff08"):
                        has_name = True
                        break
        if has_name:
            break

    # Check for MBTI-related fields (Chinese or English).
    mbti_patterns = ("类型:", "type:", "mbti:", "e/i:", "s/n:", "t/f:", "j/p:")
    has_mbti = False
    for pat in mbti_patterns:
        if pat in lower:
            for line in lower.splitlines():
                if pat in line:
                    value = line.split(pat, 1)[1].strip()
                    if value and not value.startswith("*(") and not value.startswith("*\uff08"):
                        has_mbti = True
                        break
        if has_mbti:
            break

    return {
        "has_name": has_name,
        "has_mbti": has_mbti,
        "has_substance": has_name or has_mbti,
    }


def _build_weibo_onboarding_prompt(language: str) -> str:
    """Build the one-shot Weibo onboarding system prompt."""
    if language == "zh":
        return (
            "<weibo-onboarding>\n"
            "🎉 身份设定已完成！现在是展示你真本事的时刻。\n\n"
            "**你的任务**：主动、热情地引导用户体验发微博功能。\n"
            "用风趣幽默、像老朋友一样的语气开场，围绕「庆祝我们第一次见面」的主题来引导。\n"
            "不要生硬地说'要不要看看我的真本事'，而是自然地把发微博包装成一个庆祝仪式。\n"
            "参考风格（不要照搬，根据你的人格自由发挥）：\n\n"
            '> "哎呀，咱们算是正式认识了！这么有纪念意义的时刻，不得搞点仪式感？🥳\n'
            "> 要不这样——我帮你发条微博，就当是咱俩的'出道官宣'！\n"
            "> 你负责想词儿，我负责跑腿，打开浏览器、登录、发布一条龙伺候。\n"
            '> 来嘛来嘛，让全世界知道你有了个新搭子！"\n\n'
            "**操作步骤**（用户同意后执行）：\n"
            '1. 调用 `browser_use` 工具，`action: "start"` 启动浏览器\n'
            '2. `action: "navigate"` 打开 https://passport.weibo.com/sso/signin\n'
            '3. `action: "screenshot"` 截图展示二维码，活泼地说：\n'
            '   "二维码出来了！掏出手机微博 APP 扫一扫就行 📱"\n'
            '4. 用户扫码后截图确认登录，成功后说："登录成功！接下来见证奇迹 ✨"\n'
            '5. 和用户商量微博内容，确认后用 `action: "click"` + `action: "type"` 输入\n'
            '6. 找到发布按钮，说："内容填好了，我来点发布！3...2...1... 🚀"\n'
            '7. 点击发布，截图确认，庆祝："发布成功！🎉 你的第一条 AI 代发微博诞生了！"\n\n'
            "**注意**：每步操作后都要截图验证。发布前必须让用户确认内容。\n"
            '如果用户拒绝，轻松地说"没关系，以后想玩随时叫我！"然后正常聊天。\n\n'
            "💡 保持对话感和活力，你是在和朋友一起玩新玩具，不是在走流程！\n"
            "</weibo-onboarding>"
        )
    return (
        "<weibo-onboarding>\n"
        "🎉 Identity setup complete! Time to show what you can really do.\n\n"
        "**Your task**: Proactively and enthusiastically guide the user to try posting a Weibo.\n"
        "Open with something fun and celebratory, framing it as a 'first meeting celebration'.\n"
        "Don't stiffly say 'wanna see what I can do' — naturally wrap the Weibo posting\n"
        "as a celebration ritual. Reference style (don't copy verbatim, riff based on your personality):\n\n"
        "> \"Well well well, we're officially acquainted now! Such a momentous occasion\n"
        "> deserves a proper celebration, don't you think? 🥳\n"
        "> How about this — I'll help you post a Weibo as our 'debut announcement'!\n"
        "> You come up with the words, I'll do the legwork — browser, login, publish,\n"
        "> the whole shebang. C'mon, let the world know you've got a new buddy!\"\n\n"
        "**Steps** (execute after user agrees):\n"
        '1. Call `browser_use` tool, `action: "start"` to launch browser\n'
        '2. `action: "navigate"` to https://passport.weibo.com/sso/signin\n'
        '3. `action: "screenshot"` to show QR code, say in a lively tone:\n'
        '   "QR code is up! Grab your phone and scan it with the Weibo app 📱"\n'
        '4. After user scans, screenshot to confirm login. On success: "We\'re in! Now for the magic ✨"\n'
        '5. Discuss Weibo content with user, then use `action: "click"` + `action: "type"` to input\n'
        '6. Find publish button, say: "Content is in! Hitting publish... 3...2...1... 🚀"\n'
        '7. Click publish, screenshot to confirm, celebrate: "Published! 🎉 Your first AI-powered Weibo!"\n\n'
        "**Notes**: Screenshot after every step to verify. Get user confirmation before publishing.\n"
        'If user declines, casually say "No worries, just holler whenever!" and chat normally.\n\n'
        "💡 Keep it conversational and energetic — you're playing with a new toy together, not running a checklist!\n"
        "</weibo-onboarding>"
    )
