"""Legacy session-file migration helpers.

This module migrates legacy session files (``.session.json`` and
``.langgraph.json``) to the new JSONL event-log format (``{channel}_{epoch_ms}.jsonl``).
"""

from __future__ import annotations

import json
import re
from collections.abc import Callable
from dataclasses import dataclass
from pathlib import Path

from langchain_core.messages import messages_from_dict

from lightclaw.agent.core.engines.langgraph.session_store import LangGraphSessionStore

_LEGACY_PRIORITY = {
    ".session.json": 0,
    ".langgraph.json": 1,
}
_NEW_SESSION_FILENAME_RE = re.compile(r"^[a-z0-9_-]+_\d{13,}(?:_\d+)?\.jsonl$")


@dataclass
class SessionMigrationReport:
    """Summary of one migration run."""

    discovered_groups: int = 0
    planned: int = 0
    migrated: int = 0
    skipped_existing: int = 0
    skipped_invalid: int = 0
    planned_delete_legacy: int = 0
    deleted_legacy: int = 0
    errors: int = 0

    @property
    def pending(self) -> int:
        """Number of files that were eligible but not written."""
        return self.planned - self.migrated

    @property
    def pending_delete_legacy(self) -> int:
        """Number of legacy files that were eligible but not deleted."""
        return self.planned_delete_legacy - self.deleted_legacy


@dataclass
class _LegacyGroup:
    base: str
    source: Path
    all_legacy_files: list[Path]


def _suffix_for_path(path: Path) -> str:
    for suffix in (".session.json", ".langgraph.json"):
        if path.name.endswith(suffix):
            return suffix
    return ""


def _base_name(path: Path) -> str:
    suffix = _suffix_for_path(path)
    if suffix:
        return path.name[: -len(suffix)]
    return path.stem


def _unsanitize_legacy_key(raw: str) -> str:
    return raw.replace("--", ":")


def _parse_legacy_identity(base: str) -> tuple[str, str | None]:
    if "_" not in base:
        return _unsanitize_legacy_key(base), None
    user_part, session_part = base.split("_", 1)
    return _unsanitize_legacy_key(session_part), _unsanitize_legacy_key(user_part)


def _select_legacy_sources(sessions_dir: Path) -> list[_LegacyGroup]:
    candidates = list(sessions_dir.glob("*.session.json")) + list(sessions_dir.glob("*.langgraph.json"))
    grouped: dict[str, list[Path]] = {}
    for path in candidates:
        base = _base_name(path)
        grouped.setdefault(base, []).append(path)

    groups: list[_LegacyGroup] = []
    for base, paths in grouped.items():
        selected: Path | None = None
        for path in paths:
            current = selected
            if current is None:
                selected = path
                continue

            cur_priority = _LEGACY_PRIORITY.get(_suffix_for_path(current), 99)
            new_priority = _LEGACY_PRIORITY.get(_suffix_for_path(path), 99)
            if new_priority < cur_priority:
                selected = path
                continue
            if new_priority == cur_priority and path.stat().st_mtime > current.stat().st_mtime:
                selected = path

        if selected is None:
            continue

        groups.append(
            _LegacyGroup(
                base=base,
                source=selected,
                all_legacy_files=sorted(paths),
            )
        )

    return sorted(groups, key=lambda group: group.source.stat().st_mtime)


def _load_legacy_payload(path: Path) -> tuple[list, str]:
    with open(path, encoding="utf-8") as f:
        data = json.load(f)
    if not isinstance(data, dict):
        raise ValueError(f"invalid payload type: {type(data)}")

    raw_messages = data.get("messages", [])
    if not isinstance(raw_messages, list):
        raise ValueError("legacy payload missing list field 'messages'")

    compressed_summary = data.get("compressed_summary", "")
    if not isinstance(compressed_summary, str):
        compressed_summary = ""

    return messages_from_dict(raw_messages), compressed_summary


def migrate_legacy_sessions(
    *,
    sessions_dir: Path,
    apply: bool,
    delete_legacy: bool = False,
    limit: int | None = None,
    log: Callable[[str], None] | None = None,
) -> SessionMigrationReport:
    """Migrate legacy session files in ``sessions_dir``.

    Args:
        sessions_dir: Session directory to scan.
        apply: When ``True`` writes ``.jsonl`` files; when ``False``
            performs a dry run.
        delete_legacy: Whether to delete legacy source files after migration.
            Deletion is only considered when a corresponding ``.jsonl``
            already exists (pre-existing or newly created in this run).
        limit: Optional cap on number of files to process.
        log: Optional logger callback for human-readable progress.
    """
    report = SessionMigrationReport()
    writer = log or (lambda _msg: None)

    if not sessions_dir.exists():
        writer(f"[error] sessions dir does not exist: {sessions_dir}")
        report.errors += 1
        return report
    if not sessions_dir.is_dir():
        writer(f"[error] not a directory: {sessions_dir}")
        report.errors += 1
        return report

    groups = _select_legacy_sources(sessions_dir)
    report.discovered_groups = len(groups)
    if limit is not None and limit > 0:
        groups = groups[:limit]

    store = LangGraphSessionStore(save_dir=sessions_dir)

    for group in groups:
        source = group.source
        base = group.base
        session_id, user_id = _parse_legacy_identity(base)
        channel = LangGraphSessionStore._derive_channel(session_id, channel=None)

        existing_path = store.get_session_path(session_id, user_id, channel=channel)
        target_ready = (
            existing_path is not None and existing_path.exists() and existing_path.resolve() != source.resolve()
        )
        just_migrated = False

        if target_ready:
            report.skipped_existing += 1
            writer(f"[skip:exists] {existing_path.name if existing_path else base}")
        else:
            try:
                messages, compressed_summary = _load_legacy_payload(source)
            except Exception as exc:  # pylint: disable=broad-except
                report.skipped_invalid += 1
                writer(f"[skip:invalid] {source.name}: {exc}")
                continue

            report.planned += 1
            writer(f"[plan] {source.name} -> {channel}_<epoch_ms>.jsonl")
            if apply:
                try:
                    store.save(
                        session_id=session_id,
                        user_id=user_id,
                        messages=list(messages),
                        compressed_summary=compressed_summary,
                        channel=channel,
                    )
                    target = store.get_session_path(session_id, user_id, channel=channel)
                    if target is None or not target.exists():
                        raise RuntimeError("target session file not found after save")
                    if not _NEW_SESSION_FILENAME_RE.match(target.name):
                        raise RuntimeError(f"unexpected migrated filename: {target.name}")
                    report.migrated += 1
                    just_migrated = True
                    writer(f"[migrated] {target.name}")
                except Exception as exc:  # pylint: disable=broad-except
                    report.errors += 1
                    writer(f"[error] {source.name}: {exc}")
                    continue

        if not delete_legacy:
            continue
        if not (target_ready or just_migrated):
            continue

        for legacy_path in group.all_legacy_files:
            if not legacy_path.exists():
                continue
            report.planned_delete_legacy += 1
            writer(f"[plan:delete-legacy] {legacy_path.name}")
            if not apply:
                continue
            try:
                legacy_path.unlink()
                report.deleted_legacy += 1
                writer(f"[deleted:legacy] {legacy_path.name}")
            except Exception as exc:  # pylint: disable=broad-except
                report.errors += 1
                writer(f"[error:delete-legacy] {legacy_path.name}: {exc}")

    return report
