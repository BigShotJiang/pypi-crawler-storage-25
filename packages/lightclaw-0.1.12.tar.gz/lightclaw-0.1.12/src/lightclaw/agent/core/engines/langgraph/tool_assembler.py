"""Tool assembly for per-run agent sessions.

Responsible for loading builtin tools, skills, MCP tools, and memory tools
into a single list ready for injection into the agent graph.
"""

from __future__ import annotations

import asyncio
import logging
import os
from collections import OrderedDict
from pathlib import Path
from typing import Any

from lightclaw.agent.core.interfaces import ToolAssemblerPort
from lightclaw.constant import is_memory_manager_enabled

logger = logging.getLogger(__name__)
# Bounded LRU cache for process-local message stores.
# In practice only one memory_dir is active, so a tiny limit is sufficient.
_RETRIEVE_STORE_CACHE_MAX_SIZE = int(os.environ.get("LIGHTCLAW_RETRIEVE_STORE_CACHE_MAX_SIZE", "4"))
_RETRIEVE_COMPRESSED_STORE_CACHE: OrderedDict[str, Any] = OrderedDict()
_RETRIEVE_COMPRESSED_STORE_LOCK = asyncio.Lock()


class ToolAssembler(ToolAssemblerPort):
    """Assembles the full tool list for a single agent run.

    Takes memory_manager and memory_dir at construction time so that each
    call to ``assemble()`` only needs the run-specific inputs (MCP clients
    and the live model instance).
    """

    def __init__(
        self,
        *,
        memory_manager: Any | None,
        memory_dir: Path,
    ) -> None:
        self._memory_manager = memory_manager
        self._memory_dir = memory_dir

    async def assemble(
        self,
        *,
        model: Any,
    ) -> list[Any]:
        """Build and return the complete tool list for the run.

        Order: builtins → active skills → memory tools.
        Each group is best-effort; failures are logged and skipped.
        """
        from lightclaw.agent.core.engines.langgraph.tool_adapters import (
            create_memory_forget_langchain_tool,
            create_memory_search_langchain_tool,
            load_active_skills_as_tools,
            load_builtin_tools,
        )

        builtin_tools = load_builtin_tools()
        skill_tools = load_active_skills_as_tools()
        tools: list = [*builtin_tools, *skill_tools]
        memory_tool_count = 0

        if is_memory_manager_enabled() and self._memory_manager is not None:
            # Keep a global fallback model so background tasks (summary,
            # distillation) that run outside a bind_turn_chat_model()
            # context still have a usable LLM instead of silently
            # degrading to truncated-text mode.
            self._memory_manager.langchain_chat_model = model
            tools.append(create_memory_search_langchain_tool(self._memory_manager))
            tools.append(create_memory_forget_langchain_tool(self._memory_manager))
            memory_tool_count += 2
            await self._register_retrieve_compressed(tools)
            memory_tool_count = len(tools) - len(builtin_tools) - len(skill_tools)

        logger.info(
            "Tool assembly complete: builtins=%d skills=%d memory_tools=%d total=%d",
            len(builtin_tools),
            len(skill_tools),
            memory_tool_count,
            len(tools),
        )

        return tools

    async def _register_retrieve_compressed(self, tools: list) -> None:
        """Add retrieve_compressed_messages tool; log and skip on failure."""
        try:
            from lightclaw.agent.core.engines.langgraph.tool_adapters.retrieve_compressed import (
                create_retrieve_compressed_tool,
            )
            from lightclaw.agent.memory.message_store import SqliteMessageStore

            msg_store = await self._get_or_create_retrieve_store(SqliteMessageStore)
            tools.append(create_retrieve_compressed_tool(msg_store))
            logger.info("Registered retrieve_compressed_messages tool")
        except Exception:
            logger.warning(
                "retrieve_compressed_messages tool unavailable — compressed history recall disabled for this run.",
                exc_info=True,
            )

    async def _get_or_create_retrieve_store(self, store_cls: type) -> Any:
        """Return a process-local cached message store for retrieve_compressed_messages."""
        key = str(self._memory_dir.resolve())
        cached = _RETRIEVE_COMPRESSED_STORE_CACHE.get(key)
        if cached is not None:
            _RETRIEVE_COMPRESSED_STORE_CACHE.move_to_end(key)
            logger.debug("retrieve_compressed_messages store cache hit: db_dir=%s", key)
            return cached

        async with _RETRIEVE_COMPRESSED_STORE_LOCK:
            cached = _RETRIEVE_COMPRESSED_STORE_CACHE.get(key)
            if cached is not None:
                _RETRIEVE_COMPRESSED_STORE_CACHE.move_to_end(key)
                logger.debug("retrieve_compressed_messages store cache hit (post-lock): db_dir=%s", key)
                return cached
            logger.debug("retrieve_compressed_messages store cache miss: db_dir=%s", key)
            msg_store = store_cls(db_dir=self._memory_dir)
            await msg_store.start()
            _RETRIEVE_COMPRESSED_STORE_CACHE[key] = msg_store
            if len(_RETRIEVE_COMPRESSED_STORE_CACHE) > _RETRIEVE_STORE_CACHE_MAX_SIZE:
                _RETRIEVE_COMPRESSED_STORE_CACHE.popitem(last=False)
            return msg_store
