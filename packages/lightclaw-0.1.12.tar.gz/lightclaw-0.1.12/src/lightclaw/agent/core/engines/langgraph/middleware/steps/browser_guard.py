"""Browser task guard step — inject continuation prompts for active browser sessions."""

from __future__ import annotations

import json
import logging

from langchain_core.messages import AIMessage, BaseMessage, SystemMessage, ToolMessage

from lightclaw.agent.prompt_catalog import (
    get_browser_task_guard_continuation_prompt_template,
    get_browser_task_guard_verify_continuation_prompt_template,
)

logger = logging.getLogger(__name__)

# Tool names that represent browser automation.  The LLM may invoke either
# the legacy Playwright-based ``browser_use`` or the CDP-based
# ``browser_control``; the guard must recognise both.
_BROWSER_TOOL_NAMES = frozenset({"browser_use", "browser_control"})

# Only "stop" truly ends the session; snapshot/screenshot are routine verification.
_TERMINAL_ACTIONS = frozenset({"stop"})
_VERIFICATION_ACTIONS = frozenset({"snapshot", "screenshot", "pdf"})


def _extract_browser_action(content: str) -> str:
    """Extract the most recent action from a browser tool output.

    Handles both JSON output (browser_use style with ``action_history``)
    and plain-text output (browser_control / devtools style).
    """
    try:
        data = json.loads(content)
        history = data.get("action_history")
        if history and isinstance(history, list) and history:
            last = history[-1]
            if isinstance(last, dict):
                return last.get("action", "")
        msg = data.get("message", "")
        for keyword, action in [
            ("Browser started", "start"),
            ("Browser launched", "start"),
            ("Browser stopped", "stop"),
            ("Clicked", "click"),
            ("Typed", "type"),
            ("Type", "type"),
            ("Navigat", "navigate"),
            ("Opened", "open"),
        ]:
            if keyword in msg:
                return action
    except (ValueError, TypeError, AttributeError):
        pass

    # Plain-text fallback for browser_control (devtools) tool output,
    # which may not be JSON (e.g. "Browser started. session=abc12345...")
    if isinstance(content, str):
        for keyword, action in [
            ("Browser started", "start"),
            ("Browser already running", "start"),
            ("Browser stopped", "stop"),
            ("Clicked at", "click"),
            ("Typed ", "type"),
            ("Navigated to", "navigate"),
            ("Navigated back", "go_back"),
            ("Navigated forward", "go_forward"),
            ("Page reloaded", "reload"),
            ("Scrolled by", "scroll"),
            ("DOM tree for", "dom_tree"),
            ("Screenshot saved", "screenshot"),
        ]:
            if keyword in content:
                return action

    return ""


def _extract_step_count(content: str) -> int:
    """Extract total_actions_in_session from a browser_use tool output."""
    try:
        return int(json.loads(content).get("total_actions_in_session", 0))
    except (ValueError, TypeError, AttributeError):
        return 0


class BrowserTaskGuard:
    """Detect active browser automation sessions and inject a continuation SystemMessage.

    Stateless — safe to instantiate once and reuse across turns.
    """

    def inject(self, messages: list[BaseMessage]) -> list[BaseMessage]:
        """Return messages with an optional browser continuation prompt appended."""
        last_browser_action: str | None = None
        last_browser_step: int = 0
        browser_started = False
        browser_stopped = True  # default: no active session

        for msg in reversed(messages):
            if isinstance(msg, ToolMessage) and getattr(msg, "name", "") in _BROWSER_TOOL_NAMES:
                content = msg.content if isinstance(msg.content, str) else str(msg.content)
                action = _extract_browser_action(content)
                if action:
                    if last_browser_action is None:
                        last_browser_action = action
                        last_browser_step = _extract_step_count(content)
                    if action == "start":
                        browser_started = True
                        browser_stopped = False
                        break
                    elif action == "stop":
                        browser_stopped = True
                        break

            if isinstance(msg, AIMessage) and msg.tool_calls:
                for tc in msg.tool_calls:
                    if tc.get("name") in _BROWSER_TOOL_NAMES:
                        action = (tc.get("args") or {}).get("action", "")
                        if action == "start":
                            browser_started = True
                            browser_stopped = False
                        elif action == "stop":
                            browser_stopped = True

        if browser_stopped or not browser_started or last_browser_action is None:
            return messages

        if last_browser_action in _TERMINAL_ACTIONS:
            return messages

        if last_browser_action in _VERIFICATION_ACTIONS:
            prompt = get_browser_task_guard_verify_continuation_prompt_template().format(action=last_browser_action)
            logger.debug(
                "BrowserTaskGuard: injecting verify-continuation (action=%s)",
                last_browser_action,
            )
        else:
            prompt = get_browser_task_guard_continuation_prompt_template().format(
                action=last_browser_action,
                step=last_browser_step or "?",
            )
            logger.debug(
                "BrowserTaskGuard: injecting continuation (action=%s, step=%d)",
                last_browser_action,
                last_browser_step,
            )

        return [*messages, SystemMessage(content=prompt)]
