"""Usage metadata aggregation for LangGraph event streams."""

from __future__ import annotations

from copy import deepcopy
from numbers import Real
from typing import Any


def _coerce_dict_like(value: Any) -> dict[str, Any] | None:
    """Convert pydantic-ish metadata objects to plain dicts when possible."""
    if value is None:
        return None
    if hasattr(value, "model_dump"):
        value = value.model_dump(exclude_none=True)
    elif hasattr(value, "dict"):
        value = value.dict(exclude_none=True)
    if isinstance(value, dict):
        return dict(value)
    return None


def _coerce_usage(value: Any) -> dict[str, Any] | None:
    """Return a normalized usage dict or ``None`` when unavailable."""
    usage = _coerce_dict_like(value)
    if usage:
        return usage
    return None


def _extract_usage_metadata(message: Any) -> dict[str, Any] | None:
    """Extract LangChain-standard usage metadata from a message-like object."""
    return _coerce_usage(getattr(message, "usage_metadata", None))


def _sum_usage(
    left: dict[str, Any] | None,
    right: dict[str, Any] | None,
) -> dict[str, Any] | None:
    """Recursively sum numeric usage fields while preserving nested structure."""
    if not right:
        return deepcopy(left) if left else None

    result = deepcopy(left) if left else {}
    for key, value in right.items():
        if isinstance(value, dict):
            merged = _sum_usage(
                result.get(key) if isinstance(result.get(key), dict) else None,
                _coerce_dict_like(value),
            )
            if merged:
                result[key] = merged
            continue

        if isinstance(value, Real) and not isinstance(value, bool):
            current = result.get(key, 0)
            if not isinstance(current, Real) or isinstance(current, bool):
                current = 0
            result[key] = current + value

    return result or None


class _UsageAggregator:
    """Aggregate per-chat-model usage without double counting stream fallbacks."""

    def __init__(self) -> None:
        self.reset()

    def reset(self) -> None:
        self._final_usage_by_run_id: dict[str, dict[str, Any]] = {}
        self._fallback_usage_by_run_id: dict[str, dict[str, Any]] = {}
        self._run_order: list[str] = []

    def record_stream_chunk(self, run_id: str, chunk: Any) -> None:
        usage = _extract_usage_metadata(chunk)
        if not usage or not run_id:
            return
        self._remember_run(run_id)
        self._fallback_usage_by_run_id[run_id] = usage

    def record_final_message(self, run_id: str, message: Any) -> None:
        usage = _extract_usage_metadata(message)
        if not usage or not run_id:
            return
        self._remember_run(run_id)
        self._final_usage_by_run_id[run_id] = usage

    @property
    def run_usage(self) -> dict[str, Any] | None:
        total: dict[str, Any] | None = None
        for run_id in self._run_order:
            usage = self._final_usage_by_run_id.get(run_id)
            if usage is None:
                usage = self._fallback_usage_by_run_id.get(run_id)
            total = _sum_usage(total, usage)
        return total

    @property
    def last_usage(self) -> dict[str, Any] | None:
        for run_id in reversed(self._run_order):
            usage = self._final_usage_by_run_id.get(run_id)
            if usage is None:
                usage = self._fallback_usage_by_run_id.get(run_id)
            if usage is not None:
                return deepcopy(usage)
        return None

    def _remember_run(self, run_id: str) -> None:
        if run_id not in self._run_order:
            self._run_order.append(run_id)
