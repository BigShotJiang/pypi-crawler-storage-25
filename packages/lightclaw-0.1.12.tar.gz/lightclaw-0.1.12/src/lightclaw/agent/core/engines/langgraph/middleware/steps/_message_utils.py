"""Shared message-inspection utilities for middleware steps."""

from __future__ import annotations

from langchain_core.messages import BaseMessage, HumanMessage


def extract_latest_user_text(messages: list[BaseMessage]) -> str:
    """Return the plain-text content of the last HumanMessage, or empty string."""
    for msg in reversed(messages):
        if not isinstance(msg, HumanMessage):
            continue
        content = msg.content
        if isinstance(content, str):
            return content
        if isinstance(content, list):
            parts: list[str] = []
            for block in content:
                if isinstance(block, str):
                    parts.append(block)
                elif isinstance(block, dict) and block.get("type") == "text":
                    parts.append(str(block.get("text", "")))
            return "\n".join(parts)
    return ""
