"""Stream processor for <think> tag buffering across LLM stream chunks."""

from __future__ import annotations

from collections.abc import AsyncIterator, Callable

from lightclaw.domain import TurnEvent, TurnEventType
from lightclaw.domain.message_types import MessageType

_OPEN_TAG = "<think>"
_CLOSE_TAG = "</think>"


class ThinkStreamProcessor:
    """Buffer and route <think> tag content across LLM stream chunks.

    Thinking tokens are streamed incrementally — content inside an unclosed
    <think> block is forwarded immediately as REASONING deltas rather than
    held until </think> arrives.  Only the minimum suffix needed to detect
    a split tag boundary is withheld per chunk.
    """

    def __init__(self, start_message_fn: Callable[[str], str]) -> None:
        self._start_message = start_message_fn
        self._buffer: str = ""
        self._in_thinking: bool = False

    def reset(self) -> None:
        self._buffer = ""
        self._in_thinking = False

    @staticmethod
    def _safe_flush_end(text: str, tag: str) -> int:
        """Return how many leading characters of *text* can be safely yielded.

        Holds back the shortest tail of *text* that could be a partial prefix
        of *tag* spanning a chunk boundary (e.g. text ends with ``"</thi"``
        and tag is ``"</think>"``).  Returns ``len(text)`` when no partial
        prefix is detected.
        """
        for length in range(len(tag) - 1, 0, -1):
            if text.endswith(tag[:length]):
                return len(text) - length
        return len(text)

    def _make_event(
        self,
        turn_id: str,
        message_type: str,
        text: str,
    ) -> TurnEvent:
        is_reasoning = message_type == MessageType.REASONING
        return TurnEvent(
            type=TurnEventType.ASSISTANT_DELTA,
            turn_id=turn_id,
            message_id=self._start_message(message_type),
            role="assistant",
            delta={"type": "text", "text": text},
            metadata={"message_type": message_type} if is_reasoning else None,
        )

    async def _process_text_mode(
        self,
        turn_id: str,
        text_buffer: list[str],
    ) -> AsyncIterator[TurnEvent]:
        """Scan buffer in text mode; yield text and switch to thinking on <think>."""
        idx = self._buffer.find(_OPEN_TAG)
        if idx == -1:
            safe = self._safe_flush_end(self._buffer, _OPEN_TAG)
            if safe > 0:
                text = self._buffer[:safe]
                self._buffer = self._buffer[safe:]
                text_buffer.append(text)
                yield self._make_event(turn_id, MessageType.MESSAGE, text)
            return
        if idx > 0:
            text = self._buffer[:idx]
            text_buffer.append(text)
            yield self._make_event(turn_id, MessageType.MESSAGE, text)
        self._buffer = self._buffer[idx + len(_OPEN_TAG) :]
        self._in_thinking = True

    async def _process_thinking_mode(
        self,
        turn_id: str,
    ) -> AsyncIterator[TurnEvent]:
        """Scan buffer in thinking mode; stream tokens and switch out on </think>."""
        idx = self._buffer.find(_CLOSE_TAG)
        if idx == -1:
            safe = self._safe_flush_end(self._buffer, _CLOSE_TAG)
            if safe > 0:
                text = self._buffer[:safe]
                self._buffer = self._buffer[safe:]
                yield self._make_event(turn_id, MessageType.REASONING, text)
            return
        if idx > 0:
            text = self._buffer[:idx]
            yield self._make_event(turn_id, MessageType.REASONING, text)
        self._buffer = self._buffer[idx + len(_CLOSE_TAG) :]
        self._in_thinking = False

    async def process(
        self,
        content: str,
        turn_id: str,
        text_buffer: list[str],
    ) -> AsyncIterator[TurnEvent]:
        """Process a streaming chunk that may contain ``<think>`` tags.

        Yields REASONING deltas for content inside ``<think>`` blocks and
        MESSAGE deltas for normal text.  Tag boundaries that split across
        chunks are handled by retaining only a short partial-tag suffix in
        the internal buffer between calls.
        """
        self._buffer += content

        while self._buffer:
            prev_len = len(self._buffer)
            if self._in_thinking:
                async for event in self._process_thinking_mode(turn_id):
                    yield event
            else:
                async for event in self._process_text_mode(turn_id, text_buffer):
                    yield event
            # Both helpers either consumed buffer or hit a safe-margin break.
            if len(self._buffer) == prev_len:
                break

    async def flush(
        self,
        turn_id: str,
        text_buffer: list[str],
    ) -> AsyncIterator[TurnEvent]:
        """Flush any remaining buffer content at end of stream.

        If the stream ended while inside a ``<think>`` block (no closing tag),
        the remaining buffer is emitted as a REASONING delta.  Any leftover
        partial tag prefix held as a safety margin is emitted as text.
        """
        if not self._buffer:
            return

        remaining = self._buffer
        self._buffer = ""

        if self._in_thinking:
            self._in_thinking = False
            if remaining:
                yield TurnEvent(
                    type=TurnEventType.ASSISTANT_DELTA,
                    turn_id=turn_id,
                    message_id=self._start_message(MessageType.REASONING),
                    role="assistant",
                    delta={"type": "text", "text": remaining},
                    metadata={"message_type": MessageType.REASONING},
                )
        else:
            # Partial <think> prefix held as safety margin — emit as text.
            text_buffer.append(remaining)
            yield TurnEvent(
                type=TurnEventType.ASSISTANT_DELTA,
                turn_id=turn_id,
                message_id=self._start_message(MessageType.MESSAGE),
                role="assistant",
                delta={"type": "text", "text": remaining},
            )
