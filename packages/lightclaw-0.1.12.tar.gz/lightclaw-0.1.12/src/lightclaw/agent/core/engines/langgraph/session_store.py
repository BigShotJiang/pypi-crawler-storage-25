"""Session persistence for LangChain messages.

This module provides session persistence semantics for LangChain
``BaseMessage`` objects.

Primary stored format per session:
``{channel}_{epoch_ms}[_{n}].jsonl`` (event log, one JSON object per line).

An index file ``session_index.json`` maps logical session identity
(``session_id``, ``user_id``, ``channel``) to physical filenames.

Async support:
``aload`` / ``asave`` / ``aclear`` wrap synchronous I/O in
``asyncio.to_thread`` so callers on the event loop never block.
"""

from __future__ import annotations

import asyncio
import json
import logging
import re
from collections.abc import Sequence
from copy import deepcopy
from datetime import UTC, datetime, timedelta, timezone
from pathlib import Path
from uuid import uuid4

from langchain_core.messages import (
    BaseMessage,
    messages_from_dict,
    messages_to_dict,
)

from lightclaw.agent.core.adapters.message_converter import langchain_to_msg
from lightclaw.agent.core.interfaces import SessionRepository

logger = logging.getLogger(__name__)

# Characters forbidden in Windows filenames
_UNSAFE_FILENAME_RE = re.compile(r'[\\/:*?"<>|]')
_CHANNEL_ROUTE_LINE_RE = re.compile(r"\[[^\n]+\]\s*to=[^\n]+\n\n")
_SESSION_TS_SUFFIX_RE = re.compile(r"(\d{13,})$")
_SESSION_INDEX_FILE = "session_index.json"

# Project-wide display timezone (UTC+8). All timestamps persisted in session
# files are rendered in this zone with an explicit ``+08:00`` suffix so the
# JSONL is immediately readable without further conversion.
_DISPLAY_TZ = timezone(timedelta(hours=8), name="CST")


def _format_display_iso(dt: datetime) -> str:
    """Render *dt* as ISO-8601 in Asia/Shanghai with millisecond precision.

    Naive datetimes are assumed to be UTC for safety; aware datetimes are
    converted to the project's display timezone.  The output always carries
    an explicit ``+08:00`` offset (no ``Z`` suffix).
    """
    if dt.tzinfo is None:
        dt = dt.replace(tzinfo=UTC)
    return dt.astimezone(_DISPLAY_TZ).isoformat(timespec="milliseconds")


def _sanitize(name: str) -> str:
    return _UNSAFE_FILENAME_RE.sub("--", name)


class LangGraphSessionStore(SessionRepository):
    """JSON/JSONL file session store for chat messages.

    Implements :class:`~lightclaw.agent.core.interfaces.SessionRepository`
    using LangChain message serialisation on the local filesystem.
    Files are stored as ``{channel}_{epoch_ms}[_{n}].jsonl``.
    Runtime reads/writes are index-driven and only target this format.
    """

    def __init__(self, save_dir: str | Path) -> None:
        self._save_dir = Path(save_dir)
        self._save_dir.mkdir(parents=True, exist_ok=True)
        self._index_path = self._save_dir / _SESSION_INDEX_FILE

    def _get_path(self, session_id: str, user_id: str | None, suffix: str = ".jsonl") -> Path:
        """Return legacy deterministic path (for migration helpers/tests only)."""
        safe_sid = _sanitize(session_id)
        safe_uid = _sanitize(user_id) if user_id else ""
        if safe_uid:
            filename = f"{safe_uid}_{safe_sid}{suffix}"
        else:
            filename = f"{safe_sid}{suffix}"
        return self._save_dir / filename

    @staticmethod
    def _normalize_channel(channel: str) -> str:
        normalized = (channel or "").strip().lower()
        return _sanitize(normalized or "unknown")

    @classmethod
    def _derive_channel(cls, session_id: str, channel: str | None = None) -> str:
        if channel:
            return cls._normalize_channel(channel)
        sid = (session_id or "").strip()
        if not sid:
            return "unknown"
        if sid.startswith("proactive_"):
            return cls._derive_channel(sid[len("proactive_") :], channel=None)
        if ":" in sid:
            return cls._normalize_channel(sid.split(":", 1)[0])
        if "-" in sid:
            head = sid.split("-", 1)[0]
            if head:
                return cls._normalize_channel(head)
        return "unknown"

    @staticmethod
    def _build_index_key(session_id: str, user_id: str | None, channel: str) -> str:
        return f"{channel}\0{session_id}\0{user_id or ''}"

    @staticmethod
    def _index_entry_updated_now() -> str:
        return _format_display_iso(datetime.now(_DISPLAY_TZ))

    def _load_index(self) -> dict[str, dict]:
        if not self._index_path.exists():
            return {}
        try:
            data = json.loads(self._index_path.read_text(encoding="utf-8"))
        except Exception:
            logger.exception("Failed to load session index from %s", self._index_path)
            return {}
        if not isinstance(data, dict):
            return {}
        entries = data.get("entries")
        if not isinstance(entries, list):
            return {}

        index: dict[str, dict] = {}
        for raw in entries:
            if not isinstance(raw, dict):
                continue
            session_id = raw.get("session_id")
            if not isinstance(session_id, str) or not session_id:
                continue
            channel = self._normalize_channel(str(raw.get("channel") or "unknown"))
            user_id = raw.get("user_id")
            user_id = user_id if isinstance(user_id, str) else ""
            filename = raw.get("filename")
            if not isinstance(filename, str) or not filename:
                continue
            index[self._build_index_key(session_id, user_id, channel)] = {
                "channel": channel,
                "session_id": session_id,
                "user_id": user_id,
                "peer_user_id": str(raw.get("peer_user_id") or ""),
                "canonical_user_id": str(raw.get("canonical_user_id") or ""),
                "filename": filename,
                "updated_at": str(raw.get("updated_at") or ""),
            }
        return index

    def _save_index(self, index: dict[str, dict]) -> None:
        payload = {
            "version": 1,
            "entries": sorted(index.values(), key=lambda item: str(item.get("updated_at") or "")),
        }
        tmp_path = self._index_path.with_suffix(self._index_path.suffix + ".tmp")
        tmp_path.write_text(
            json.dumps(payload, ensure_ascii=False, indent=2, sort_keys=True),
            encoding="utf-8",
        )
        tmp_path.replace(self._index_path)

    def _find_index_entry(
        self,
        *,
        session_id: str,
        user_id: str | None,
        channel: str,
        index: dict[str, dict],
    ) -> tuple[str | None, dict | None]:
        if user_id is not None:
            key = self._build_index_key(session_id, user_id, channel)
            entry = index.get(key)
            if entry is not None:
                return key, entry
        for candidate_key, candidate in index.items():
            if (
                candidate.get("session_id") == session_id
                and (user_id is None or str(candidate.get("user_id") or "") == user_id)
                and self._normalize_channel(str(candidate.get("channel") or "")) == channel
            ):
                return candidate_key, candidate
        for candidate_key, candidate in index.items():
            if candidate.get("session_id") == session_id and (
                user_id is None or str(candidate.get("user_id") or "") == user_id
            ):
                return candidate_key, candidate
        return None, None

    def _path_from_index_entry(self, entry: dict) -> Path:
        return self._save_dir / str(entry.get("filename") or "")

    def _allocate_timestamped_filename(self, channel: str, session_id: str, index: dict[str, dict]) -> str:
        # Strip "channel:" or "channel-" prefix to avoid repeating the channel name.
        sid = session_id.split(":", 1)[-1] if ":" in session_id else session_id
        if sid.lower().startswith(channel.lower() + "-"):
            sid = sid[len(channel) + 1 :]
        sid_safe = _sanitize(sid).strip("-").strip("_") or "session"
        # First choice: bare name without any suffix.
        base = f"{channel}-{sid_safe}"
        used = {str(item.get("filename") or "") for item in index.values()}
        candidate = f"{base}.jsonl"
        if candidate not in used and not (self._save_dir / candidate).exists():
            return candidate
        # Collision: append a YYYYMMDDHHmmss timestamp so each /new produces a
        # unique, human-readable filename rather than a confusing counter suffix.
        # Use the project display timezone (UTC+8) to match what users see.
        ts = datetime.now(_DISPLAY_TZ).strftime("%Y%m%d%H%M%S")
        candidate = f"{base}-{ts}.jsonl"
        counter = 1
        while candidate in used or (self._save_dir / candidate).exists():
            candidate = f"{base}-{ts}-{counter}.jsonl"
            counter += 1
        return candidate

    def _resolve_indexed_path(
        self,
        *,
        session_id: str,
        user_id: str | None,
        channel: str,
        index: dict[str, dict],
        clean_stale: bool,
    ) -> Path | None:
        key, entry = self._find_index_entry(
            session_id=session_id,
            user_id=user_id,
            channel=channel,
            index=index,
        )
        if entry is None:
            return None
        path = self._path_from_index_entry(entry)
        if path.exists():
            return path
        if clean_stale and key is not None:
            index.pop(key, None)
            try:
                self._save_index(index)
            except Exception:
                logger.exception("Failed to persist cleaned stale index entry for session %s", session_id)
        return None

    def get_session_path(
        self,
        session_id: str,
        user_id: str | None = None,
        *,
        channel: str | None = None,
    ) -> Path | None:
        """Resolve the on-disk path for a logical session."""
        normalized_channel = self._derive_channel(session_id, channel=channel)
        index = self._load_index()
        indexed = self._resolve_indexed_path(
            session_id=session_id,
            user_id=user_id,
            channel=normalized_channel,
            index=index,
            clean_stale=False,
        )
        if indexed is not None:
            return indexed
        return None

    def has_session_file(
        self,
        session_id: str,
        user_id: str | None = None,
        *,
        channel: str | None = None,
    ) -> bool:
        """Return True when a session file exists for the logical session."""
        return self.get_session_path(session_id, user_id, channel=channel) is not None

    # ------------------------------------------------------------------
    # Synchronous API (kept for backward compatibility & CLI usage)
    # ------------------------------------------------------------------

    def load(
        self,
        session_id: str,
        user_id: str | None = None,
        *,
        channel: str | None = None,
    ) -> tuple[list[BaseMessage], str]:
        """Load session history and compressed summary from disk.

        Returns:
            Tuple of (messages, compressed_summary).
            If no session file exists, returns ([], "").
        """
        normalized_channel = self._derive_channel(session_id, channel=channel)
        index = self._load_index()
        path = self._resolve_indexed_path(
            session_id=session_id,
            user_id=user_id,
            channel=normalized_channel,
            index=index,
            clean_stale=True,
        )
        if path is None:
            return [], ""

        if not path.name.endswith(".jsonl"):
            logger.warning("Unsupported non-jsonl session file in index: %s", path.name)
            return [], ""

        try:
            messages, compressed_summary, bad_lines, valid_events = self._load_jsonl(path)

            logger.debug(
                "Loaded %d messages from %s",
                len(messages),
                path.name,
            )

            # Self-heal: if the file had decode/parse errors but we still
            # recovered at least one valid event, rewrite the file with the
            # known-good lines so subsequent loads stay clean and silent.
            if bad_lines > 0 and valid_events:
                try:
                    self._rewrite_jsonl_from_events(path, valid_events)
                    logger.warning(
                        "Self-healed %s: dropped %d corrupt line(s), kept %d event(s)",
                        path.name,
                        bad_lines,
                        len(valid_events),
                    )
                except Exception:
                    logger.exception("Failed to self-heal session file %s", path)

            return messages, compressed_summary
        except Exception:
            logger.exception("Failed to load session from %s", path)
            return [], ""

    def save(
        self,
        session_id: str,
        user_id: str | None,
        messages: Sequence[BaseMessage],
        compressed_summary: str = "",
        *,
        channel: str | None = None,
        canonical_user_id: str = "",
        peer_user_id: str = "",
    ) -> None:
        """Persist session messages and compressed summary to disk (JSONL events)."""
        normalized_channel = self._derive_channel(session_id, channel=channel)
        index = self._load_index()
        path = self._resolve_indexed_path(
            session_id=session_id,
            user_id=user_id,
            channel=normalized_channel,
            index=index,
            clean_stale=True,
        )
        if path is None:
            filename = self._allocate_timestamped_filename(normalized_channel, session_id, index)
            path = self._save_dir / filename
        try:
            lines = self._build_jsonl_events(
                session_id=session_id,
                messages=list(messages),
                compressed_summary=compressed_summary,
            )
            if not lines:
                logger.debug("Skip session save for %s: no serializable events", path.name)
                return
            # Atomic write: write to tmp then rename
            tmp_path = path.with_suffix(path.suffix + ".tmp")
            with open(tmp_path, "w", encoding="utf-8") as f:
                for line in lines:
                    f.write(json.dumps(line, ensure_ascii=False, separators=(",", ":")))
                    f.write("\n")
            tmp_path.replace(path)
            key = self._build_index_key(session_id, user_id, normalized_channel)
            index[key] = {
                "channel": normalized_channel,
                "session_id": session_id,
                "user_id": user_id or "",
                "peer_user_id": peer_user_id or "",
                "canonical_user_id": canonical_user_id or "",
                "filename": path.name,
                "updated_at": self._index_entry_updated_now(),
            }
            self._save_index(index)
            logger.debug(
                "Saved %d messages to %s",
                len(messages),
                path.name,
            )
        except Exception:
            logger.exception("Failed to save session to %s", path)

    def clear(
        self,
        session_id: str,
        user_id: str | None = None,
        *,
        channel: str | None = None,
    ) -> None:
        """Delete the session file."""
        normalized_channel = self._derive_channel(session_id, channel=channel)
        index = self._load_index()
        removed = False
        for key, entry in list(index.items()):
            if entry.get("session_id") != session_id:
                continue
            if user_id is not None and str(entry.get("user_id") or "") != user_id:
                continue
            if channel and self._normalize_channel(str(entry.get("channel") or "")) != normalized_channel:
                continue
            path = self._save_dir / str(entry.get("filename") or "")
            if path.exists():
                path.unlink()
                logger.debug("Cleared indexed session file %s", path.name)
            index.pop(key, None)
            removed = True
        if removed:
            self._save_index(index)

    # ------------------------------------------------------------------
    # JSONL event helpers
    # ------------------------------------------------------------------

    def _load_jsonl(self, path: Path) -> tuple[list[BaseMessage], str, int, list[dict]]:
        """Parse a session JSONL file with per-line UTF-8 and JSON tolerance.

        Corrupt bytes are replaced (``errors="replace"``) so a single
        truncated line never aborts the whole load.  Each line is parsed in
        isolation; lines that fail JSON decoding are counted and skipped.

        Returns:
            Tuple of ``(messages, compressed_summary, bad_lines, valid_events)``
            where ``valid_events`` are the raw decoded event dicts in original
            order, suitable for rewriting the file as part of self-healing.
        """
        message_dicts: list[dict] = []
        compressed_summary = ""
        bad_lines = 0
        valid_events: list[dict] = []

        # ``errors="replace"`` preserves line framing even when a multi-byte
        # sequence was truncated; the offending line will then fail JSON
        # parsing below and be skipped, while the rest of the file is read.
        with open(path, encoding="utf-8", errors="replace") as f:
            for raw_line in f:
                line = raw_line.strip()
                if not line:
                    continue
                # Lines containing the Unicode replacement char came from a
                # truncated UTF-8 sequence; treat them as corrupt.
                if "\ufffd" in line:
                    bad_lines += 1
                    continue
                try:
                    event = json.loads(line)
                except json.JSONDecodeError:
                    bad_lines += 1
                    continue

                if not isinstance(event, dict):
                    bad_lines += 1
                    continue

                valid_events.append(event)

                event_type = event.get("type")
                if event_type == "message":
                    message_payload = event.get("message")
                    if not isinstance(message_payload, dict):
                        continue

                    raw_lc_message = message_payload.get("_lc")
                    if isinstance(raw_lc_message, dict):
                        message_dicts.append(raw_lc_message)
                        continue

                    converted = self._convert_message_payload_to_langchain_dict(message_payload)
                    if converted is not None:
                        message_dicts.append(converted)

                if event_type == "custom" and event.get("customType") == "compressed-summary":
                    data = event.get("data")
                    if isinstance(data, dict):
                        summary_val = data.get("value")
                        if isinstance(summary_val, str):
                            compressed_summary = summary_val

        if bad_lines > 0:
            logger.warning(
                "Recovered %s with %d corrupt line(s) skipped; %d valid event(s) kept",
                path.name,
                bad_lines,
                len(valid_events),
            )

        messages = messages_from_dict(message_dicts)
        return messages, compressed_summary, bad_lines, valid_events

    def _rewrite_jsonl_from_events(self, path: Path, events: Sequence[dict]) -> None:
        """Atomically rewrite a JSONL session file from already-parsed events.

        Used by :meth:`load` to drop corrupt lines once a recoverable subset
        of the file has been read.  Writes via a temp file then ``replace``.
        """
        tmp_path = path.with_suffix(path.suffix + ".tmp")
        with open(tmp_path, "w", encoding="utf-8") as f:
            for event in events:
                f.write(json.dumps(event, ensure_ascii=False, separators=(",", ":")))
                f.write("\n")
        tmp_path.replace(path)

    def _build_jsonl_events(
        self,
        *,
        session_id: str = "",
        messages: list[BaseMessage],
        compressed_summary: str,
    ) -> list[dict]:
        raw_messages = messages_to_dict(messages)
        now = datetime.now(_DISPLAY_TZ)
        now_ms = int(now.timestamp() * 1000)
        message_ts_base_ms = self._resolve_message_timestamp_base_ms(session_id=session_id, now_ms=now_ms)
        parent_id: str | None = None
        events: list[dict] = []

        session_event = self._new_event(
            event_type="session",
            parent_id=parent_id,
            timestamp=now,
            version=3,
            id=(session_id or str(uuid4())),
            cwd=str(Path.cwd()),
        )
        events.append(session_event)
        parent_id = session_event["id"]

        provider, model_id, model_api = self._extract_latest_model_info(raw_messages)
        thinking_level = self._infer_thinking_level(raw_messages)

        model_change_event = self._new_event(
            event_type="model_change",
            parent_id=parent_id,
            timestamp=now,
            provider=provider,
            modelId=model_id,
        )
        events.append(model_change_event)
        parent_id = model_change_event["id"]

        thinking_event = self._new_event(
            event_type="thinking_level_change",
            parent_id=parent_id,
            timestamp=now,
            thinkingLevel=thinking_level,
        )
        events.append(thinking_event)
        parent_id = thinking_event["id"]

        snapshot_event = self._new_event(
            event_type="custom",
            parent_id=parent_id,
            timestamp=now,
            customType="model-snapshot",
            data={
                "timestamp": self._iso_utc_from_epoch_ms(message_ts_base_ms),
                "provider": provider,
                "modelApi": model_api,
                "modelId": model_id,
            },
        )
        events.append(snapshot_event)
        parent_id = snapshot_event["id"]

        if compressed_summary:
            summary_event = self._new_event(
                event_type="custom",
                parent_id=parent_id,
                timestamp=now,
                customType="compressed-summary",
                data={"value": compressed_summary},
            )
            events.append(summary_event)
            parent_id = summary_event["id"]

        for idx, (msg, raw_msg) in enumerate(zip(messages, raw_messages, strict=False)):
            payload = self._build_message_payload(
                msg=msg,
                raw_msg=raw_msg,
                fallback_timestamp_ms=message_ts_base_ms + idx,
            )
            if payload is None:
                continue
            msg_event = self._new_event(
                event_type="message",
                parent_id=parent_id,
                timestamp=now,
                message=payload,
            )
            events.append(msg_event)
            parent_id = msg_event["id"]

        return events

    @staticmethod
    def _new_event(
        *,
        event_type: str,
        parent_id: str | None,
        timestamp: datetime,
        **extra: object,
    ) -> dict:
        event = {
            "type": event_type,
            "id": uuid4().hex[:8],
            "parentId": parent_id,
            "timestamp": _format_display_iso(timestamp),
        }
        event.update(extra)
        return event

    def _build_message_payload(
        self,
        *,
        msg: BaseMessage,
        raw_msg: dict,
        fallback_timestamp_ms: int,
    ) -> dict | None:
        if not isinstance(raw_msg, dict):
            return None

        raw_type = raw_msg.get("type")
        if raw_type not in {"human", "ai", "tool"}:
            return None

        role = self._role_from_raw_type(str(raw_type))
        data = raw_msg.get("data")
        if not isinstance(data, dict):
            return None

        internal = langchain_to_msg(msg)
        internal_content = (
            internal.content if isinstance(internal.content, list) else [{"type": "text", "text": internal.content}]
        )
        content = self._normalize_content_blocks_for_session(internal_content)

        payload: dict[str, object] = {
            "role": role,
            "content": content,
            "timestamp": self._iso_utc_from_epoch_ms(fallback_timestamp_ms),
            "_lc": raw_msg,
        }

        if role == "user":
            content_text = self._sanitize_persisted_user_text(self._extract_text_content(content))
            if not content_text:
                return None
            payload["content"] = [{"type": "text", "text": content_text}]
            payload["_lc"] = self._sanitize_raw_lc_user_message(raw_msg, content_text)

        metadata = internal.metadata if isinstance(internal.metadata, dict) else {}
        response_metadata = metadata.get("response_metadata") if isinstance(metadata, dict) else {}
        response_metadata = response_metadata if isinstance(response_metadata, dict) else {}
        usage = internal.usage if isinstance(internal.usage, dict) else None

        if role == "assistant":
            provider = self._first_non_empty_str(
                response_metadata.get("model_provider"), response_metadata.get("provider")
            )
            model_name = self._first_non_empty_str(response_metadata.get("model_name"), response_metadata.get("model"))
            finish_reason = self._first_non_empty_str(
                response_metadata.get("finish_reason"),
                response_metadata.get("stop_reason"),
            )
            model_api = self._first_non_empty_str(response_metadata.get("modelApi"), response_metadata.get("model_api"))

            if provider:
                payload["provider"] = provider
            if model_name:
                payload["model"] = model_name
            payload["api"] = model_api or "openai-completions"
            if finish_reason:
                payload["stopReason"] = finish_reason
            if usage is not None:
                payload["usage"] = self._normalize_usage(usage)

        if role == "toolResult":
            content_text = self._extract_text_content(data.get("content")).strip()
            payload["content"] = [{"type": "text", "text": content_text}] if content_text else []
            tool_call_id = data.get("tool_call_id")
            tool_name = data.get("name")
            if isinstance(tool_call_id, str) and tool_call_id:
                payload["toolCallId"] = tool_call_id
            if isinstance(tool_name, str) and tool_name:
                payload["toolName"] = tool_name
            status = data.get("status")
            payload["isError"] = bool(status == "error")
            details = self._try_parse_json_object(content_text)
            if details is not None:
                payload["details"] = details

        if role in {"user", "assistant", "toolResult"} and not content and not payload.get("content"):
            return None

        return payload

    @staticmethod
    def _normalize_usage(usage: dict) -> dict:
        input_tokens = int(usage.get("input_tokens") or 0)
        output_tokens = int(usage.get("output_tokens") or 0)
        total_tokens = int(usage.get("total_tokens") or (input_tokens + output_tokens))
        input_details = usage.get("input_token_details") if isinstance(usage.get("input_token_details"), dict) else {}

        cache_read = int(input_details.get("cache_read") or 0)
        cache_write = int(input_details.get("cache_write") or 0)

        return {
            "input": input_tokens,
            "output": output_tokens,
            "cacheRead": cache_read,
            "cacheWrite": cache_write,
            "totalTokens": total_tokens,
            "cost": {
                "input": 0,
                "output": 0,
                "cacheRead": 0,
                "cacheWrite": 0,
                "total": 0,
            },
        }

    @staticmethod
    def _denormalize_usage(usage: object) -> dict[str, object]:
        if not isinstance(usage, dict):
            return {}

        input_tokens = int(usage.get("input") or usage.get("input_tokens") or 0)
        output_tokens = int(usage.get("output") or usage.get("output_tokens") or 0)
        total_tokens = int(usage.get("totalTokens") or usage.get("total_tokens") or (input_tokens + output_tokens))
        cache_read = int(usage.get("cacheRead") or 0)
        cache_write = int(usage.get("cacheWrite") or 0)
        return {
            "input_tokens": input_tokens,
            "output_tokens": output_tokens,
            "total_tokens": total_tokens,
            "input_token_details": {
                "cache_read": cache_read,
                "cache_write": cache_write,
            },
        }

    @staticmethod
    def _extract_latest_model_info(raw_messages: list[dict]) -> tuple[str, str, str]:
        for msg in reversed(raw_messages):
            if not isinstance(msg, dict) or msg.get("type") != "ai":
                continue
            data = msg.get("data")
            if not isinstance(data, dict):
                continue
            response_metadata = data.get("response_metadata")
            if not isinstance(response_metadata, dict):
                continue

            provider = response_metadata.get("model_provider") or response_metadata.get("provider")
            model_id = response_metadata.get("model_name") or response_metadata.get("model")
            model_api = response_metadata.get("modelApi") or response_metadata.get("model_api") or "openai-completions"
            return (
                provider if isinstance(provider, str) else "",
                model_id if isinstance(model_id, str) else "",
                model_api if isinstance(model_api, str) else "openai-completions",
            )
        return "", "", "openai-completions"

    @staticmethod
    def _infer_thinking_level(raw_messages: list[dict]) -> str:
        for msg in reversed(raw_messages):
            if not isinstance(msg, dict) or msg.get("type") != "ai":
                continue
            data = msg.get("data")
            if not isinstance(data, dict):
                continue
            usage = data.get("usage_metadata")
            if isinstance(usage, dict):
                output_details = usage.get("output_token_details")
                if isinstance(output_details, dict):
                    reasoning_tokens = int(output_details.get("reasoning") or 0)
                    if reasoning_tokens > 0:
                        return "on"
            additional_kwargs = data.get("additional_kwargs")
            if isinstance(additional_kwargs, dict):
                thinking = additional_kwargs.get("thinking") or additional_kwargs.get("reasoning_content")
                if isinstance(thinking, str) and thinking.strip():
                    return "on"
        return "off"

    @staticmethod
    def _first_non_empty_str(*values: object) -> str:
        for value in values:
            if isinstance(value, str) and value.strip():
                return value
        return ""

    @staticmethod
    def _role_from_raw_type(raw_type: str) -> str:
        if raw_type == "human":
            return "user"
        if raw_type == "ai":
            return "assistant"
        if raw_type == "tool":
            return "toolResult"
        if raw_type == "system":
            return "system"
        return "assistant"

    @staticmethod
    def _normalize_content_blocks_for_session(content: object) -> list[dict]:
        if not isinstance(content, list):
            text = str(content) if content is not None else ""
            return [{"type": "text", "text": text}] if text else []

        blocks: list[dict] = []
        for block in content:
            if isinstance(block, str):
                if block:
                    blocks.append({"type": "text", "text": block})
                continue
            if hasattr(block, "model_dump"):
                block = block.model_dump(exclude_none=True)
            elif hasattr(block, "dict"):
                block = block.dict(exclude_none=True)
            if not isinstance(block, dict):
                continue

            block_type = str(block.get("type") or "")
            if block_type == "tool_use":
                blocks.append(
                    {
                        "type": "toolCall",
                        "id": block.get("id", ""),
                        "name": block.get("name", ""),
                        "arguments": block.get("input", {}) if isinstance(block.get("input"), dict) else {},
                    }
                )
                continue

            if block_type == "thinking":
                normalized = dict(block)
                thinking = normalized.get("thinking")
                if isinstance(thinking, str) and thinking.strip() and "thinkingSignature" not in normalized:
                    normalized["thinkingSignature"] = "reasoning_content"
                blocks.append(normalized)
                continue

            blocks.append(dict(block))
        return blocks

    @staticmethod
    def _try_parse_json_object(text: str) -> dict | None:
        if not isinstance(text, str) or not text.strip():
            return None
        try:
            parsed = json.loads(text)
        except json.JSONDecodeError:
            return None
        return parsed if isinstance(parsed, dict) else None

    @staticmethod
    def _iso_utc_from_epoch_ms(timestamp_ms: int) -> str:
        """Render epoch milliseconds as ISO-8601 string in Asia/Shanghai.

        The function name is preserved for backward compatibility; the
        formatted string now carries an explicit ``+08:00`` offset matching
        the project's display timezone.
        """
        dt = datetime.fromtimestamp(timestamp_ms / 1000, tz=_DISPLAY_TZ)
        return dt.isoformat(timespec="milliseconds")

    @staticmethod
    def _extract_epoch_ms_suffix(session_id: str) -> int | None:
        if not isinstance(session_id, str) or not session_id:
            return None
        match = _SESSION_TS_SUFFIX_RE.search(session_id)
        if match is None:
            return None
        try:
            return int(match.group(1))
        except ValueError:
            return None

    @classmethod
    def _resolve_message_timestamp_base_ms(cls, *, session_id: str, now_ms: int) -> int:
        """Compute fallback message timestamp base, avoiding session-id collisions."""
        sid_epoch_ms = cls._extract_epoch_ms_suffix(session_id)
        if sid_epoch_ms is not None and sid_epoch_ms == now_ms:
            return now_ms + 1
        return now_ms

    @staticmethod
    def _sanitize_raw_lc_user_message(raw_msg: dict, content_text: str) -> dict:
        sanitized = deepcopy(raw_msg) if isinstance(raw_msg, dict) else {}
        data = sanitized.get("data")
        if isinstance(data, dict):
            data["content"] = content_text
        return sanitized

    def _sanitize_persisted_user_text(self, text: str) -> str:
        normalized = (text or "").strip()
        if not normalized:
            return ""

        normalized = self._strip_untrusted_metadata_prefix(normalized)
        return normalized.strip()

    @staticmethod
    def _strip_untrusted_metadata_prefix(text: str) -> str:
        normalized = (text or "").strip()
        if not normalized:
            return ""

        if "untrusted metadata" not in normalized.lower():
            return normalized

        channel_line_match = _CHANNEL_ROUTE_LINE_RE.search(normalized)
        if channel_line_match is not None:
            tail = normalized[channel_line_match.end() :].strip()
            if tail:
                return tail

        parts = [part.strip() for part in re.split(r"\n\s*\n", normalized) if part.strip()]
        if parts:
            tail = parts[-1]
            if tail.lower().startswith("sender (untrusted metadata):"):
                return ""
            if tail.lower().startswith("conversation info (untrusted metadata):"):
                return ""
            return tail
        return normalized

    @staticmethod
    def _convert_message_payload_to_langchain_dict(payload: dict) -> dict | None:
        role = payload.get("role")
        if not isinstance(role, str):
            return None

        normalized_role = role.strip().lower()
        content_text = LangGraphSessionStore._extract_text_content(payload.get("content")).strip()

        if normalized_role in {"user", "human"}:
            if not content_text:
                return None
            return {
                "type": "human",
                "data": {
                    "content": content_text,
                    "additional_kwargs": {},
                    "response_metadata": {},
                    "type": "human",
                    "name": None,
                    "id": uuid4().hex,
                },
            }

        if normalized_role in {"assistant", "ai"}:
            content_blocks = payload.get("content")
            thinking_parts: list[str] = []
            tool_calls: list[dict] = []
            if isinstance(content_blocks, list):
                for block in content_blocks:
                    if not isinstance(block, dict):
                        continue
                    block_type = str(block.get("type") or "")
                    if block_type == "thinking":
                        thinking = block.get("thinking")
                        if isinstance(thinking, str) and thinking.strip():
                            thinking_parts.append(thinking)
                        continue
                    if block_type in {"toolCall", "tool_call", "tool_use"}:
                        tool_calls.append(
                            {
                                "id": str(block.get("id") or ""),
                                "name": str(block.get("name") or ""),
                                "args": block.get("arguments")
                                if isinstance(block.get("arguments"), dict)
                                else block.get("input")
                                if isinstance(block.get("input"), dict)
                                else {},
                            }
                        )

            additional_kwargs: dict[str, object] = {}
            if thinking_parts:
                additional_kwargs["thinking"] = "\n".join(thinking_parts)

            response_metadata: dict[str, object] = {}
            provider = payload.get("provider")
            model_name = payload.get("model")
            stop_reason = payload.get("stopReason")
            model_api = payload.get("api")
            if isinstance(provider, str) and provider:
                response_metadata["model_provider"] = provider
            if isinstance(model_name, str) and model_name:
                response_metadata["model_name"] = model_name
            if isinstance(stop_reason, str) and stop_reason:
                response_metadata["finish_reason"] = stop_reason
            if isinstance(model_api, str) and model_api:
                response_metadata["model_api"] = model_api

            usage_metadata = LangGraphSessionStore._denormalize_usage(payload.get("usage"))
            data: dict[str, object] = {
                "content": content_text,
                "additional_kwargs": additional_kwargs,
                "response_metadata": response_metadata,
                "type": "ai",
                "name": None,
                "id": uuid4().hex,
                "tool_calls": tool_calls,
                "invalid_tool_calls": [],
            }
            if usage_metadata:
                data["usage_metadata"] = usage_metadata
            return {"type": "ai", "data": data}

        if normalized_role in {"toolresult", "tool"}:
            if not content_text:
                content_text = str(payload.get("output") or "")
            if not content_text:
                return None
            tool_call_id = payload.get("toolCallId")
            tool_name = payload.get("toolName")
            is_error = bool(payload.get("isError"))
            return {
                "type": "tool",
                "data": {
                    "content": content_text,
                    "additional_kwargs": {},
                    "response_metadata": {},
                    "type": "tool",
                    "name": tool_name if isinstance(tool_name, str) else "",
                    "id": uuid4().hex,
                    "tool_call_id": tool_call_id if isinstance(tool_call_id, str) else "",
                    "artifact": None,
                    "status": "error" if is_error else "success",
                },
            }

        if normalized_role == "system":
            if not content_text:
                return None
            return {
                "type": "system",
                "data": {
                    "content": content_text,
                    "additional_kwargs": {},
                    "response_metadata": {},
                    "type": "system",
                    "name": None,
                    "id": uuid4().hex,
                },
            }

        return None

    def _to_compatible_raw_messages(self, raw_messages: object) -> list[dict]:
        if not isinstance(raw_messages, list):
            return []
        result: list[dict] = []
        for raw_msg in raw_messages:
            if isinstance(raw_msg, dict) and raw_msg.get("type") in {"human", "ai", "tool", "system"}:
                data = raw_msg.get("data")
                if isinstance(data, dict):
                    result.append(raw_msg)
                    continue
            if isinstance(raw_msg, dict):
                message_payload = raw_msg.get("message")
                if isinstance(message_payload, dict):
                    converted = self._convert_message_payload_to_langchain_dict(message_payload)
                    if converted is not None:
                        result.append(converted)
        return result

    @staticmethod
    def _extract_text_content(content_obj: object) -> str:
        if isinstance(content_obj, str):
            return content_obj
        if isinstance(content_obj, list):
            parts: list[str] = []
            for block in content_obj:
                if isinstance(block, str):
                    parts.append(block)
                    continue
                if not isinstance(block, dict):
                    continue
                if block.get("type") == "text":
                    text_val = block.get("text")
                    if isinstance(text_val, str):
                        parts.append(text_val)
                        continue
                text_val = block.get("text")
                if isinstance(text_val, str):
                    parts.append(text_val)
            return "\n".join(part for part in parts if part)
        return ""

    # ------------------------------------------------------------------
    # Async API — event-loop-safe wrappers (PR3 Phase 1)
    # ------------------------------------------------------------------

    async def aload(
        self,
        session_id: str,
        user_id: str | None = None,
        *,
        channel: str | None = None,
    ) -> tuple[list[BaseMessage], str]:
        """Async version of :meth:`load`.

        Delegates to ``asyncio.to_thread`` so the event loop is never
        blocked by file I/O.
        """
        return await asyncio.to_thread(self.load, session_id, user_id, channel=channel)

    async def asave(
        self,
        session_id: str,
        user_id: str | None,
        messages: Sequence[BaseMessage],
        compressed_summary: str = "",
        *,
        channel: str | None = None,
        canonical_user_id: str = "",
        peer_user_id: str = "",
    ) -> None:
        """Async version of :meth:`save`.

        Delegates to ``asyncio.to_thread`` so the event loop is never
        blocked by serialisation or file I/O.
        """
        await asyncio.to_thread(
            self.save,
            session_id,
            user_id,
            messages,
            compressed_summary,
            channel=channel,
            canonical_user_id=canonical_user_id,
            peer_user_id=peer_user_id,
        )

    async def aclear(
        self,
        session_id: str,
        user_id: str | None = None,
        *,
        channel: str | None = None,
    ) -> None:
        """Async version of :meth:`clear`.

        Delegates to ``asyncio.to_thread`` so the event loop is never
        blocked by file deletion.
        """
        await asyncio.to_thread(self.clear, session_id, user_id, channel=channel)

    def detach(
        self,
        session_id: str,
        user_id: str | None = None,
        *,
        channel: str | None = None,
    ) -> None:
        """Remove the index entry for a session without deleting the file.

        The existing JSONL file is preserved on disk so the conversation
        history remains accessible.  The next :meth:`save` call for the
        same session_id will allocate a fresh timestamped filename, effectively
        starting a new file while keeping the old one intact.
        """
        normalized_channel = self._derive_channel(session_id, channel=channel)
        index = self._load_index()
        removed = False
        for key, entry in list(index.items()):
            if entry.get("session_id") != session_id:
                continue
            if user_id is not None and str(entry.get("user_id") or "") != user_id:
                continue
            if channel and self._normalize_channel(str(entry.get("channel") or "")) != normalized_channel:
                continue
            logger.debug("Detached index entry for session %s (file kept: %s)", session_id, entry.get("filename"))
            index.pop(key, None)
            removed = True
        if removed:
            self._save_index(index)

    async def adetach(
        self,
        session_id: str,
        user_id: str | None = None,
        *,
        channel: str | None = None,
    ) -> None:
        """Async version of :meth:`detach`."""
        await asyncio.to_thread(self.detach, session_id, user_id, channel=channel)

    def rename_session_id(
        self,
        old_session_id: str,
        new_session_id: str,
        user_id: str | None = None,
        *,
        channel: str | None = None,
    ) -> bool:
        """Update the session_id in the index without touching the file.

        Used for migrating legacy session_id values (e.g. bare timestamps)
        to the canonical ``channel-userid-timestamp`` format.  The physical
        JSONL file is left untouched; only the index entry is rewritten.

        Returns True if at least one entry was updated, False otherwise.
        """
        normalized_channel = self._derive_channel(old_session_id, channel=channel)
        index = self._load_index()
        updated = False
        for key, entry in list(index.items()):
            if entry.get("session_id") != old_session_id:
                continue
            if user_id is not None and str(entry.get("user_id") or "") != user_id:
                continue
            if channel and self._normalize_channel(str(entry.get("channel") or "")) != normalized_channel:
                continue
            # Remove old key, insert under new key.
            index.pop(key, None)
            entry["session_id"] = new_session_id
            # Also rename the physical file and update the filename so it
            # matches the new session_id (channel-userid-timestamp format).
            old_filename = str(entry.get("filename") or "")
            new_filename = self._allocate_timestamped_filename(normalized_channel, new_session_id, index)
            if old_filename and old_filename != new_filename:
                old_path = self._save_dir / old_filename
                new_path = self._save_dir / new_filename
                if old_path.exists() and not new_path.exists():
                    old_path.rename(new_path)
                    logger.debug("Renamed session file: %s -> %s", old_filename, new_filename)
                entry["filename"] = new_filename
            new_key = self._build_index_key(new_session_id, entry.get("user_id") or user_id, normalized_channel)
            index[new_key] = entry
            logger.debug("Renamed session_id in index: %s -> %s", old_session_id, new_session_id)
            updated = True
        if updated:
            self._save_index(index)
        return updated

    async def arename_session_id(
        self,
        old_session_id: str,
        new_session_id: str,
        user_id: str | None = None,
        *,
        channel: str | None = None,
    ) -> bool:
        """Async version of :meth:`rename_session_id`."""
        return await asyncio.to_thread(self.rename_session_id, old_session_id, new_session_id, user_id, channel=channel)
