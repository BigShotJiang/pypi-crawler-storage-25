"""Engine implementations for the LightClaw agent core.

Each sub-package implements the interfaces defined in ``agent.core.interfaces``.
Swap the active engine by pointing imports to a different sub-package.

Available engines:
- ``langgraph/``  — LangGraph ReAct engine (current default)
"""
