"""Tool result payload extraction utilities."""

from __future__ import annotations

import json
from typing import Any

from lightclaw.agent.core.engines.langgraph.event_bridge._usage_aggregator import _coerce_dict_like


def _extract_tool_result_payload(
    value: Any,
) -> tuple[str, dict[str, Any] | None]:
    """Extract structured output and optional metadata from one tool result.

    Returns:
        A tuple (output_str, metadata):
        - output_str: plain text when blocks only contain text/data, otherwise
          a JSON array of blocks for downstream media extraction
        - metadata: Optional dict with extracted metadata (e.g., from data blocks)
    """
    raw_value = value.content if hasattr(value, "content") else value

    blocks: list[Any] | None = None
    if isinstance(raw_value, list):
        candidate_blocks = list(raw_value)
        if any(isinstance(block, dict) and isinstance(block.get("type"), str) for block in candidate_blocks):
            blocks = candidate_blocks
        else:
            return str(raw_value), None
    elif isinstance(raw_value, str):
        try:
            parsed = json.loads(raw_value)
        except (TypeError, ValueError):
            return raw_value, None
        if not (
            isinstance(parsed, list)
            and any(isinstance(block, dict) and isinstance(block.get("type"), str) for block in parsed)
        ):
            return raw_value, None
        blocks = parsed

    if blocks is None:
        return str(raw_value), None

    # Extract metadata and serialize full structured blocks
    metadata: dict[str, Any] | None = None
    text_parts: list[str] = []
    has_non_text_block = False
    for block in blocks:
        if not isinstance(block, dict):
            continue
        if metadata is None and block.get("type") == "data":
            data = _coerce_dict_like(block.get("data"))
            if data:
                metadata = data
            continue
        if block.get("type") == "text":
            text = block.get("text")
            if isinstance(text, str) and text:
                text_parts.append(text)
            continue
        has_non_text_block = True

    if text_parts and not has_non_text_block:
        return "\n".join(text_parts), metadata

    # Return structured blocks as JSON string when non-text blocks are present
    # so downstream channel renderers can still inspect media/tool payloads.
    output_json = json.dumps(blocks, ensure_ascii=False)
    return output_json, metadata
