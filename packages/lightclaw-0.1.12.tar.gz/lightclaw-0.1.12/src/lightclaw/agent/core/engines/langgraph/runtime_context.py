"""Per-turn runtime context schema for shared LangGraph graph execution."""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any


@dataclass
class LightClawRuntimeContext:
    """Mutable per-turn context passed via LangGraph ``context``.

    This object carries request-scoped state that must not live on a shared
    middleware instance when the compiled graph is reused across turns.
    """

    session_id: str = ""
    turn_id: str = ""
    channel: str = ""
    compressed_summary: str = ""
    model_call_index: int = 0
    token_log_records: list[Any] = field(default_factory=list)
    cancelled: bool = False
    compactor: Any | None = None
    # Per-turn model selected by the router (may differ from the shared graph's
    # default when the request contains images or other modality signals).
    turn_model: Any | None = None
