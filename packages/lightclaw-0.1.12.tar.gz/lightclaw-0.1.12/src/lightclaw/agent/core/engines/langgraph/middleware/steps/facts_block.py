"""Structured facts injection step — prepend Mem0-style facts into the system prompt."""

from __future__ import annotations

import logging
from typing import TYPE_CHECKING

from langchain_core.messages import BaseMessage

from lightclaw.agent.core.engines.langgraph.middleware.steps._message_utils import extract_latest_user_text

if TYPE_CHECKING:
    from lightclaw.agent.memory.fact_injector import FactInjector

logger = logging.getLogger(__name__)


class FactsBlockProvider:
    """Retrieve user-specific structured facts and inject them into the system prompt.

    Facts are cached by the FactInjector and invalidated via update_timestamp()
    whenever the background fact-extraction task writes new data.
    """

    def __init__(self, fact_injector: FactInjector | None = None) -> None:
        self._fact_injector = fact_injector
        self._last_modified_ms: int = 0

    def update_timestamp(self, last_modified_ms: int) -> None:
        """Signal that the fact store was updated — forces cache invalidation."""
        self._last_modified_ms = last_modified_ms

    async def get_block(self, messages: list[BaseMessage]) -> str:
        """Return a structured-facts block string, or empty string if not applicable."""
        if self._fact_injector is None:
            return ""

        # Skip if facts are already present to avoid duplicates.
        for m in messages:
            if "<structured-facts>" in (m.content if isinstance(m.content, str) else ""):
                return ""

        last_user_text = extract_latest_user_text(messages)
        try:
            block = await self._fact_injector.get_relevant_facts_block(
                last_user_text=last_user_text,
                extractor_last_modified_ms=self._last_modified_ms,
            )
        except Exception:
            logger.debug("Fact injection failed, continuing without facts")
            return ""

        return block or ""
