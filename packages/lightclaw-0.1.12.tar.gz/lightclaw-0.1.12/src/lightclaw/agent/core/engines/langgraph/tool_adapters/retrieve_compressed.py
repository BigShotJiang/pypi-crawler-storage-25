"""LangChain-compatible tool for retrieving original compressed messages.

Uses the same factory pattern as ``memory.py``: accepts a
:class:`SqliteMessageStore` instance and returns a bound tool that
lets the agent recall original conversation segments that were
compressed during compaction.
"""

from __future__ import annotations

import json
import logging
from typing import TYPE_CHECKING

from langchain_core.tools import StructuredTool

if TYPE_CHECKING:
    from lightclaw.agent.memory.message_store import SqliteMessageStore

logger = logging.getLogger(__name__)


def create_retrieve_compressed_tool(
    store: SqliteMessageStore,
) -> StructuredTool:
    """Create a LangChain tool for retrieving compressed original messages.

    Args:
        store: A ``SqliteMessageStore`` instance that holds the messages DB.

    Returns:
        A ``StructuredTool`` wrapping the retrieval logic.
    """

    async def _arun(
        summary_version: int | None = None,
        limit: int = 50,
    ) -> str:
        """Retrieve original conversation messages from a compressed summary.

        When conversation history is compacted, old messages are replaced by
        an LLM-generated summary.  This tool retrieves the **original**
        messages that were compressed, allowing you to review exact details
        that the summary may have omitted.

        Args:
            summary_version: Which summary version to retrieve (1, 2, 3...).
                If not provided, retrieves the latest compressed segment.
            limit: Maximum number of messages to return (default 50).
        """
        try:
            # Step 1: Find the target summary entry.
            history = await store.get_summary_history(limit=1000)
            if not history:
                return json.dumps(
                    {"status": "empty", "message": "No compression history found."},
                    ensure_ascii=False,
                )

            target: dict | None = None
            if summary_version is None:
                # Latest summary is the first entry (ordered DESC by version).
                target = history[0]
            else:
                for entry in history:
                    if entry["version"] == summary_version:
                        target = entry
                        break

            if target is None:
                available = [e["version"] for e in history]
                return json.dumps(
                    {
                        "status": "not_found",
                        "message": f"Summary version {summary_version} not found.",
                        "available_versions": available,
                    },
                    ensure_ascii=False,
                )

            summary_id: int = target["id"]
            summary_text: str = target["summary_text"]
            version: int = target["version"]
            created_at = target["created_at"]
            messages_count: int = target.get("messages_count", 0)

            # Step 2: Retrieve original messages.
            messages = await store.get_messages_for_summary_full(summary_id)

            # Apply limit.
            truncated = len(messages) > limit
            messages = messages[:limit]

            return json.dumps(
                {
                    "status": "success",
                    "summary_version": version,
                    "summary_id": summary_id,
                    "summary_text": summary_text,
                    "created_at": created_at,
                    "total_compressed_messages": messages_count,
                    "returned_count": len(messages),
                    "truncated": truncated,
                    "messages": messages,
                },
                ensure_ascii=False,
                indent=2,
            )
        except Exception as exc:
            logger.exception("Failed to retrieve compressed messages: %s", exc)
            return json.dumps(
                {"status": "error", "message": str(exc)},
                ensure_ascii=False,
            )

    def _run(
        summary_version: int | None = None,
        limit: int = 50,
    ) -> str:
        raise NotImplementedError("retrieve_compressed_messages is async-only")

    return StructuredTool.from_function(
        func=_run,
        coroutine=_arun,
        name="retrieve_compressed_messages",
        description=(
            "Retrieve the raw messages that were compressed into a specific summary version. "
            "Use ONLY when you already know which summary_version you want to inspect "
            "(e.g. the user explicitly asks to review an old conversation segment). "
            "Do NOT use this as a fallback after memory_search — it cannot search by content. "
            "Pass summary_version to retrieve a specific segment, or omit it to get the most recent one."
        ),
    )
