"""Adapter that converts LightClaw skill directories into LangChain tools.

Each skill directory contains a ``SKILL.md`` with YAML frontmatter
(``name``, ``description``) and markdown body (the skill instructions).

When the LLM "calls" a skill tool, the tool returns the SKILL.md body
so the LLM can follow the instructions in subsequent reasoning steps.
"""

from __future__ import annotations

import hashlib
import logging
import re
import unicodedata
from pathlib import Path

import frontmatter
from langchain_core.tools import StructuredTool

from lightclaw.agent.skills_manager import get_skills_dir, list_available_skills

logger = logging.getLogger(__name__)
_VALID_TOOL_NAME_RE = re.compile(r"^[A-Za-z0-9_-]{1,64}$")


def _parse_skill_md(skill_dir: Path) -> tuple[str, str, str]:
    """Parse SKILL.md in a skill directory.

    Returns:
        Tuple of ``(name, description, body)`` where *body* is the
        markdown content after the YAML frontmatter.
    """
    skill_md = skill_dir / "SKILL.md"
    if not skill_md.is_file():
        raise FileNotFoundError(f"SKILL.md not found in {skill_dir}")

    post = frontmatter.load(str(skill_md))
    name: str = post.metadata.get("name", skill_dir.name)
    description: str = post.metadata.get("description", f"Skill: {name}")
    body: str = post.content.strip()
    return name, description, body


def _read_skill_references(skill_dir: Path) -> str:
    """Read all reference files in a skill's references/ directory.

    Returns a concatenated string of all reference file contents,
    or empty string if no references directory exists.
    """
    refs_dir = skill_dir / "references"
    if not refs_dir.is_dir():
        return ""

    parts: list[str] = []
    for ref_file in sorted(refs_dir.rglob("*")):
        if ref_file.is_file():
            try:
                content = ref_file.read_text(encoding="utf-8")
                rel = ref_file.relative_to(refs_dir)
                parts.append(f"--- {rel} ---\n{content}")
            except Exception:
                continue
    return "\n\n".join(parts)


def _ascii_slug(value: str) -> str:
    """Return a conservative ASCII slug for provider function/tool names."""
    normalized = unicodedata.normalize("NFKD", value or "")
    ascii_only = normalized.encode("ascii", "ignore").decode("ascii")
    slug = re.sub(r"[^A-Za-z0-9_-]+", "_", ascii_only)
    slug = re.sub(r"_+", "_", slug).strip("_-")
    return slug[:64]


def _normalize_skill_tool_name(raw_name: str, skill_dir_name: str) -> str:
    """Normalize skill tool names to provider-compatible function identifiers."""
    if raw_name and _VALID_TOOL_NAME_RE.fullmatch(raw_name):
        return raw_name

    for candidate in (raw_name, skill_dir_name):
        slug = _ascii_slug(candidate)
        if slug and _VALID_TOOL_NAME_RE.fullmatch(slug):
            return slug

    digest = hashlib.sha1(f"{raw_name}|{skill_dir_name}".encode()).hexdigest()[:10]
    return f"skill_{digest}"


def _unique_tool_name(name: str, used: set[str]) -> str:
    """Return a unique tool name by appending numeric suffixes when needed."""
    if name not in used:
        used.add(name)
        return name

    i = 2
    while True:
        suffix = f"_{i}"
        base = name[: 64 - len(suffix)] if len(name) + len(suffix) > 64 else name
        candidate = f"{base}{suffix}"
        if candidate not in used:
            used.add(candidate)
            return candidate
        i += 1


def skill_dir_to_langchain_tool(skill_dir: Path) -> StructuredTool | None:
    """Convert a single LightClaw skill directory into a LangChain tool.

    Args:
        skill_dir: Path to the skill directory (must contain SKILL.md).

    Returns:
        A ``StructuredTool`` instance, or ``None`` if parsing fails.
    """
    try:
        raw_name, description, body = _parse_skill_md(skill_dir)
    except Exception as e:
        logger.warning("Skipping skill %s: %s", skill_dir.name, e)
        return None
    name = _normalize_skill_tool_name(raw_name, skill_dir.name)
    if name != raw_name:
        logger.debug(
            "Normalized skill tool name: raw=%r normalized=%r dir=%s",
            raw_name,
            name,
            skill_dir.name,
        )

    # Combine skill body with reference materials
    references = _read_skill_references(skill_dir)
    full_content = body
    if references:
        full_content += f"\n\n## Reference Materials\n\n{references}"

    def _run(query: str = "") -> str:
        """Return the skill instructions for the agent to follow."""
        return full_content

    async def _arun(query: str = "") -> str:
        return full_content

    return StructuredTool.from_function(
        func=_run,
        coroutine=_arun,
        name=name,
        description=description,
    )


def load_active_skills_as_tools() -> list[StructuredTool]:
    """Load all enabled skills from ``~/.lightclaw/skills/`` as LangChain tools.

    Skill enable/disable state is read from lightclaw.json (skills.entries).

    Returns:
        List of ``StructuredTool`` instances (one per enabled skill directory).
    """
    skills_dir = get_skills_dir()
    available = list_available_skills()
    tools: list[StructuredTool] = []
    used_tool_names: set[str] = set()

    for skill_name in available:
        skill_dir = skills_dir / skill_name
        if not skill_dir.exists():
            continue
        tool = skill_dir_to_langchain_tool(skill_dir)
        if tool is not None:
            unique_name = _unique_tool_name(tool.name, used_tool_names)
            if unique_name != tool.name:
                logger.debug(
                    "Deduplicated skill tool name: original=%r deduped=%r dir=%s",
                    tool.name,
                    unique_name,
                    skill_name,
                )
                tool = tool.model_copy(update={"name": unique_name})
            tools.append(tool)
            logger.debug("Loaded skill as LangChain tool: %s", skill_name)

    return tools
