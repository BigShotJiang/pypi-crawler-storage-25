"""Personality injection step — prepend MBTI-based personality context (zero LLM cost)."""

from __future__ import annotations

import logging
from pathlib import Path

from langchain_core.messages import BaseMessage

from lightclaw.agent.core.engines.langgraph.middleware.steps._message_utils import extract_latest_user_text

logger = logging.getLogger(__name__)


class PersonalityBlockProvider:
    """Wrap PersonalityInjector from the memory layer and produce a system-prompt block.

    Gracefully degrades to a no-op if the memory-layer injector is unavailable
    or if no MBTI type is configured.
    """

    def __init__(self, working_dir: Path, language: str = "zh") -> None:
        self._injector = None
        try:
            from lightclaw.agent.memory.personality_injector import PersonalityInjector

            self._injector = PersonalityInjector(
                working_dir=working_dir,
                language=language,
            )
        except Exception:
            logger.debug("PersonalityInjector unavailable, personality blocks disabled")

    def get_block(self, messages: list[BaseMessage]) -> str:
        """Return a personality-context block string, or empty string if not applicable."""
        if self._injector is None:
            return ""

        # Skip if personality context already present.
        for m in messages:
            if "<personality-context>" in (m.content if isinstance(m.content, str) else ""):
                return ""

        user_text = extract_latest_user_text(messages)
        if not user_text:
            return ""

        try:
            # Skip injection for the generic "general" scene — its hints overlap
            # heavily with the static IDENTITY.md behaviour-mapping section and
            # add noise without meaningful incremental value.
            scene = self._injector.detect_scene(user_text)
            if scene == "general":
                return ""
            return self._injector.get_personality_block(user_text)
        except Exception:
            logger.debug("Personality injection failed, continuing without it")
            return ""
