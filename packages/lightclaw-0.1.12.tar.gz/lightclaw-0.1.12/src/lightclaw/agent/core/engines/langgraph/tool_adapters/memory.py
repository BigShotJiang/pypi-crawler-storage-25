"""LangChain-compatible wrapper for the memory_search tool.

Uses the same factory pattern as the original: accepts a
``MemoryManager`` instance and returns a bound tool.
"""

from __future__ import annotations

from typing import TYPE_CHECKING

from langchain_core.tools import StructuredTool

if TYPE_CHECKING:
    from lightclaw.agent.memory.memory_manager import MemoryManager


def create_memory_search_langchain_tool(
    memory_manager: MemoryManager,
) -> StructuredTool:
    """Create a LangChain tool for semantic memory search.

    Args:
        memory_manager: A ``MemoryManager`` instance to delegate searches to.

    Returns:
        A ``StructuredTool`` that wraps ``memory_manager.memory_search()``.
    """

    async def _arun(
        query: str,
        max_results: int = 5,
        min_score: float = 0.1,
    ) -> str:
        """Search MEMORY.md and memory/*.md files semantically.

        Use this tool before answering questions about prior work, decisions,
        dates, people, preferences, or todos. Returns top relevant snippets
        with file paths and line numbers.

        Args:
            query: The semantic search query.
            max_results: Maximum number of results (default 5).
            min_score: Minimum similarity score (default 0.1).
        """
        if memory_manager is None:
            return "Error: Memory manager is not enabled."

        # Resolve temporal expressions (e.g. "昨天" → 2026-04-15) so the
        # search engine can filter by date.  Pure regex, ~0 ms.
        from lightclaw.agent.memory.temporal_resolver import resolve_temporal_expr

        date_range = resolve_temporal_expr(query)

        try:
            resp = await memory_manager.memory_search(
                query=query,
                max_results=max_results,
                min_score=min_score,
                date_range=date_range,
            )
            try:
                blocks = resp.content
                texts = [b["text"] for b in blocks if isinstance(b, dict) and "text" in b]
                if texts:
                    return "\n".join(texts)
            except (AttributeError, TypeError):
                text = str(resp)
                if text:
                    return text
        except Exception as e:
            return f"Memory file search error: {e}"

        return "No results found."

    def _run(
        query: str,
        max_results: int = 5,
        min_score: float = 0.1,
    ) -> str:
        raise NotImplementedError("memory_search is async-only")

    return StructuredTool.from_function(
        func=_run,
        coroutine=_arun,
        name="memory_search",
        description=(
            "Search MEMORY.md and memory/*.md files semantically. "
            "Use before answering questions about prior work, decisions, "
            "dates, people, preferences, or todos. "
            "If results are found, use them directly to answer — do not call retrieve_compressed_messages as a follow-up."
        ),
    )
