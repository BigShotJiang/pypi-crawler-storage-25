"""Engine-agnostic command handler interface.

Slash commands are intercepted here before reaching any LLM engine.
The concrete implementation lives in the engine-specific sub-package
(e.g. ``core/langgraph/command_handler.py``).
"""

from __future__ import annotations

from abc import ABC, abstractmethod

SYSTEM_COMMANDS = frozenset(
    {
        "compact",
        "new",
        "clear",
        "history",
        "compact_str",
        "await_summary",
        "setcodingplankey",
        "bgtokenusage",
        "token",
        "topics",
    },
)


def is_command(query: str | None) -> bool:
    """Return True when *query* is a recognised slash command.

    Supports both bare commands (``/compact``) and commands with inline
    arguments (``/setcodingplankey sk-xxxx``).
    """
    if not isinstance(query, str):
        return False
    stripped = query.strip()
    if not stripped.startswith("/"):
        return False
    # Extract the command name (first token after the leading slash).
    command_name = stripped.lstrip("/").split()[0] if stripped.lstrip("/") else ""
    return command_name in SYSTEM_COMMANDS


class BaseCommandHandler(ABC):
    """Engine-agnostic base for command handlers.

    Subclasses operate on whatever message format the engine uses
    internally, but ``handle()`` always returns plain text so callers
    stay decoupled from engine-specific message types.
    """

    @abstractmethod
    async def handle(self, query: str) -> str:
        """Dispatch a slash command and return the response as plain text."""
