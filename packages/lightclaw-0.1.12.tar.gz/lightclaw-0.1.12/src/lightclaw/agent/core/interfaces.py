"""Abstract interfaces for the agent engine.

Program against these in ``app/runner/`` so the concrete engine
(``langgraph/``, ``deepagent/``, …) can be swapped without touching
application code.

Implementations live in engine-specific sub-packages, e.g.:
    from lightclaw.agent.core.engines.langgraph import LangGraphEventBridge
"""

from __future__ import annotations

from abc import ABC, abstractmethod
from collections.abc import AsyncIterator, Sequence
from typing import TYPE_CHECKING, Any

if TYPE_CHECKING:
    from lightclaw.agent.core.command_handler import BaseCommandHandler  # noqa: F401 (re-exported for convenience)
    from lightclaw.domain import TurnEvent


class SessionRepository(ABC):
    """Abstract contract for session history persistence.

    Decouples the runner from the concrete storage format (JSON files,
    SQLite, Redis, …) and the engine (LangGraph messages vs. plain dicts).
    Implementations must be safe to call from the asyncio event loop.
    """

    @abstractmethod
    async def aload(
        self,
        session_id: str,
        user_id: str | None = None,
    ) -> tuple[list, str]:
        """Load history messages and compressed summary.

        Returns:
            (messages, compressed_summary) — empty list and empty string
            when no session data exists.
        """

    @abstractmethod
    async def asave(
        self,
        session_id: str,
        user_id: str | None,
        messages: list,
        compressed_summary: str = "",
    ) -> None:
        """Persist history messages and compressed summary."""

    @abstractmethod
    async def aclear(
        self,
        session_id: str,
        user_id: str | None = None,
    ) -> None:
        """Delete all stored data for the given session."""


class ModelRouter(ABC):
    """Abstract contract for LLM model selection.

    Separates model-routing logic from session assembly so each concern
    can be tested and swapped independently.
    """

    @abstractmethod
    def select(self, msgs: list, providers_data: Any) -> Any:
        """Select and instantiate the best chat model for the given input.

        Args:
            msgs:           Incoming conversation messages (used for routing hints).
            providers_data: Provider/model configuration from the app config.

        Returns:
            A ready-to-use chat model instance (e.g. a LangChain BaseChatModel).
        """


class ToolAssemblerPort(ABC):
    """Abstract contract for per-run tool assembly.

    Decouples the runner from the concrete tool-loading strategy so that
    tests can inject a controlled tool set without touching the filesystem
    or skill directories.
    """

    @abstractmethod
    async def assemble(self, *, model: Any) -> list:
        """Build and return the complete tool list for a single agent run.

        Args:
            model: The selected chat model instance (needed by some
                   memory tools that invoke the LLM directly).

        Returns:
            Ordered list of tool objects ready for injection into the agent.
        """


class BaseMiddleware(ABC):
    """Pre-LLM invocation hooks.

    Engines implement this to inject context (bootstrap, memory
    compaction, token budgeting) before each model call, and to
    support cooperative cancellation.
    """

    @property
    @abstractmethod
    def compressed_summary(self) -> str:
        """Current compressed conversation summary."""

    @compressed_summary.setter
    @abstractmethod
    def compressed_summary(self, value: str) -> None: ...

    @abstractmethod
    def cancel(self) -> None:
        """Signal the engine to abort the current run gracefully."""

    def commit_bootstrap_completion(self) -> None:
        """Called after a successful run to persist any pending one-time state.

        Default is a no-op; override when the engine needs post-run commits.
        """


class BaseEventBridge(ABC):
    """Translates engine-native event streams into ``TurnEvent`` objects.

    Concrete implementations subscribe to the engine's streaming API and
    yield canonical ``TurnEvent`` objects so ``run_controller`` stays
    decoupled from the engine's event format.

    Attributes:
        final_output_messages: Engine messages captured after streaming.
        run_usage:             Aggregated token usage for the full run.
        final_output_usage:    Token usage for the last output message.
    """

    final_output_messages: list
    run_usage: dict[str, Any] | None
    final_output_usage: dict[str, Any] | None

    @abstractmethod
    async def stream(
        self,
        agent: Any,
        messages: Sequence[Any],
        *,
        turn_id: str,
        config: dict | None = None,
        context: Any | None = None,
        max_iterations: int | None = None,
    ) -> AsyncIterator[TurnEvent]:
        """Stream agent execution as ``TurnEvent`` objects.

        Args:
            agent:          The compiled/ready engine object to run.
            messages:       Input messages in the engine's native format.
            turn_id:        Identifier propagated through all emitted events.
            config:         Engine-specific run configuration (thread_id, etc.).
            context:        Optional per-run engine runtime context.
            max_iterations: Maximum reasoning steps before aborting.
        """


class EngineSession(ABC):
    """Engine-agnostic handle for a single agent execution.

    Encapsulates the compiled agent graph, the event bridge, and execution
    parameters so that ``run_controller`` never needs to know which engine
    (LangGraph, DeepAgent, …) is running underneath.

    The ``stream()`` method is the sole entry point for execution.
    ``final_output_messages``, ``run_usage``, and ``final_output_usage``
    are populated after streaming completes.
    """

    @abstractmethod
    async def stream(
        self,
        messages: list,
        *,
        turn_id: str,
        run_config: dict | None = None,
        runtime_context: Any | None = None,
        callbacks: list | None = None,
    ) -> AsyncIterator[Any]:
        """Stream agent execution as ``TurnEvent`` objects.

        Args:
            messages:   Full conversation input (history + new turn).
            turn_id:    Identifier propagated through all emitted events.
            run_config: Engine-specific run configuration (thread_id, etc.).
            runtime_context: Optional per-run engine runtime context.
            callbacks:  Observability callbacks (e.g. Langfuse handler).
        """

    @property
    @abstractmethod
    def final_output_messages(self) -> list:
        """Engine messages captured after ``stream()`` completes."""

    @property
    @abstractmethod
    def run_usage(self) -> dict[str, Any] | None:
        """Aggregated token usage for the full run (populated post-stream)."""

    @property
    @abstractmethod
    def final_output_usage(self) -> dict[str, Any] | None:
        """Token usage for the last output message (populated post-stream)."""


class BaseAgentBuilder(ABC):
    """Builds a runnable agent from an ``AgentConfig``.

    Each engine sub-package provides one concrete implementation.
    """

    @abstractmethod
    def build(self, config: Any) -> Any:
        """Compile and return a runnable agent.

        Args:
            config: ``AgentConfig`` carrying model, tools, prompt, and middleware.

        Returns:
            An opaque executable agent object understood by the corresponding
            ``BaseEventBridge`` implementation.
        """
