"""Engine-agnostic agent configuration."""

from __future__ import annotations

from collections.abc import Sequence
from dataclasses import dataclass, field
from typing import TYPE_CHECKING, Any

if TYPE_CHECKING:
    from lightclaw.agent.core.interfaces import BaseMiddleware


@dataclass
class AgentConfig:
    """All parameters needed to build and run a LightClaw agent.

    Types for ``model`` and ``tools`` are intentionally ``Any`` so this
    dataclass stays independent of any specific AI framework.  The
    concrete engine builder (e.g. ``LangGraphAgentBuilder``) is
    responsible for interpreting and validating these values.

    Attributes:
        model:         Framework-specific chat model instance.
        tools:         Framework-specific tool objects.
        system_prompt: System prompt injected before the conversation.
        max_iterations: Maximum reasoning iterations (maps to the
            engine's equivalent of a recursion or step limit).
        middleware:    Optional pre-LLM hook chain.
        context_schema: Optional runtime context schema passed to the engine.
    """

    model: Any
    tools: Sequence[Any] = field(default_factory=list)
    system_prompt: str = ""
    max_iterations: int = 50
    middleware: BaseMiddleware | None = None
    context_schema: type[Any] | None = None


# Backward-compatible alias — remove once all call-sites are updated.
LightClawGraphConfig = AgentConfig
