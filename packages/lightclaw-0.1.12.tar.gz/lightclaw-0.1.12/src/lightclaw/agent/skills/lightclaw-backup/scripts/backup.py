#!/usr/bin/env python3
"""LightClaw backup and version management script.

Backs up and restores the workspace directory (``~/.lightclaw/workspace``).
All archive paths are relative to the workspace root so that restore
places files back in the correct location.

Usage:
    python backup.py create [--label LABEL] [--backup-dir DIR] [--workspace-dir DIR]
    python backup.py list   [--backup-dir DIR]
    python backup.py restore [--id ID] [--backup-dir DIR] [--workspace-dir DIR]
    python backup.py diff   --id ID [--backup-dir DIR] [--workspace-dir DIR]
    python backup.py clean  [--keep N] [--backup-dir DIR]
"""

from __future__ import annotations

import argparse
import hashlib
import json
import shutil
import sys
import tarfile
import tempfile
from datetime import UTC, datetime
from pathlib import Path

# ---------------------------------------------------------------------------
# Constants
# ---------------------------------------------------------------------------

_DEFAULT_LIGHTCLAW_DIR = Path("~/.lightclaw").expanduser()
_DEFAULT_WORKSPACE_DIR = _DEFAULT_LIGHTCLAW_DIR / "workspace"
_DEFAULT_BACKUP_DIR = _DEFAULT_LIGHTCLAW_DIR / "backups"
_SAFETY_BACKUP_NAME = "_pre_restore_safety.tar.gz"
_DEFAULT_KEEP = 7
_MANIFEST_NAME = "_backup_manifest.json"

# Directories inside workspace/ to back up recursively.
_WORKSPACE_INCLUDE_DIRS = {
    "skills",
    "memory",
    "custom_channels",
}

# Directories / patterns to always exclude.
_EXCLUDE_DIRS = {
    "models",
    "sessions",
    "uploads",
    "embedding_cache",
    "file_store",
    "logs",
    "venv",
    "bin",
    "backups",
    "__MACOSX",
    "__pycache__",
}

_EXCLUDE_EXTENSIONS = {
    ".db",
    ".sqlite",
    ".sqlite3",
    ".zip",
    ".tar.gz",
    ".tgz",
    ".log",
}


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def _ts_label() -> str:
    """Return a compact timestamp string for filenames."""
    return datetime.now(UTC).strftime("%Y%m%d_%H%M%S")


def _bytes_human(n: int) -> str:
    """Format byte count as a human-readable string."""
    for unit in ("B", "KB", "MB", "GB", "TB"):
        if abs(n) < 1024:
            return f"{n:.1f} {unit}"
        n /= 1024  # type: ignore[assignment]
    return f"{n:.1f} PB"


def _file_md5(path: Path, chunk_size: int = 8192) -> str:
    """Compute MD5 hex digest for a file."""
    h = hashlib.md5()
    with open(path, "rb") as fh:
        while True:
            chunk = fh.read(chunk_size)
            if not chunk:
                break
            h.update(chunk)
    return h.hexdigest()


def _should_exclude_entry(entry: Path, root: Path) -> bool:
    """Decide whether a file/directory should be excluded from backup."""
    name = entry.name

    # Exclude hidden OS artifacts
    if name.startswith("._") or name == ".DS_Store":
        return True

    rel = entry.relative_to(root)
    top = rel.parts[0] if rel.parts else name

    if top in _EXCLUDE_DIRS:
        return True

    if entry.is_file():
        suffix = entry.suffix.lower()
        if suffix in _EXCLUDE_EXTENSIONS:
            return True
        # Double extension check for .tar.gz
        if entry.name.endswith(".tar.gz"):
            return True

    return False


def _collect_backup_files(workspace_dir: Path) -> list[Path]:
    """Collect all files from workspace that should be included in the backup.

    Only backs up content under the workspace directory.
    Returns absolute paths.
    """
    files: list[Path] = []

    if not workspace_dir.is_dir():
        return files

    # 1. All *.md in workspace root
    for md in workspace_dir.glob("*.md"):
        if md.is_file() and not _should_exclude_entry(md, workspace_dir):
            files.append(md)

    # 2. Included subdirectories (recursive)
    for dname in _WORKSPACE_INCLUDE_DIRS:
        subdir = workspace_dir / dname
        if not subdir.is_dir():
            continue
        for fpath in subdir.rglob("*"):
            if fpath.is_file() and not _should_exclude_entry(fpath, workspace_dir):
                files.append(fpath)

    return sorted(set(files))


def _resolve_backup_dir(args: argparse.Namespace) -> Path:
    bdir = Path(args.backup_dir).expanduser().resolve()
    bdir.mkdir(parents=True, exist_ok=True)
    return bdir


def _resolve_workspace_dir(args: argparse.Namespace) -> Path:
    return Path(args.workspace_dir).expanduser().resolve()


def _list_backup_archives(backup_dir: Path) -> list[Path]:
    """Return backup .tar.gz files sorted newest-first, excluding safety backup."""
    archives = [f for f in backup_dir.glob("lightclaw-backup-*.tar.gz") if f.name != _SAFETY_BACKUP_NAME]
    return sorted(archives, key=lambda p: p.stat().st_mtime, reverse=True)


def _find_backup_by_id(backup_dir: Path, backup_id: str) -> Path | None:
    """Locate a backup archive by partial ID (timestamp) or full filename."""
    for archive in _list_backup_archives(backup_dir):
        if backup_id in archive.name or backup_id == archive.stem:
            return archive
    return None


def _read_manifest(archive_path: Path) -> dict | None:
    """Read the manifest JSON from inside a backup archive."""
    try:
        with tarfile.open(archive_path, "r:gz") as tf:
            for member in tf.getmembers():
                if member.name.endswith(_MANIFEST_NAME):
                    fobj = tf.extractfile(member)
                    if fobj:
                        return json.loads(fobj.read().decode("utf-8"))
    except Exception:
        pass
    return None


# ---------------------------------------------------------------------------
# Commands
# ---------------------------------------------------------------------------


def cmd_create(args: argparse.Namespace) -> int:
    """Create a new backup archive of the workspace directory."""
    workspace_dir = _resolve_workspace_dir(args)
    backup_dir = _resolve_backup_dir(args)

    if not workspace_dir.is_dir():
        print(f"❌ Workspace directory not found: {workspace_dir}", file=sys.stderr)
        return 1

    files = _collect_backup_files(workspace_dir)
    if not files:
        print("❌ No files found to back up.", file=sys.stderr)
        return 1

    ts = _ts_label()
    label = args.label or ""
    label_slug = label.replace(" ", "-").replace("/", "-")[:40] if label else ""
    name_parts = ["lightclaw-backup", ts]
    if label_slug:
        name_parts.append(label_slug)
    archive_name = "-".join(name_parts) + ".tar.gz"
    archive_path = backup_dir / archive_name

    # Build manifest
    manifest = {
        "version": 2,
        "created_at": datetime.now(UTC).isoformat(),
        "label": label,
        "workspace_dir": str(workspace_dir),
        "file_count": len(files),
        "files": [],
    }

    total_size = 0
    for fpath in files:
        st = fpath.stat()
        rel = fpath.relative_to(workspace_dir)
        manifest["files"].append(
            {
                "path": str(rel),
                "size": st.st_size,
                "md5": _file_md5(fpath),
            }
        )
        total_size += st.st_size

    manifest["total_size"] = total_size
    manifest["total_size_human"] = _bytes_human(total_size)

    # Write archive — all paths are relative to workspace_dir
    with tarfile.open(archive_path, "w:gz") as tf:
        for fpath in files:
            arcname = str(fpath.relative_to(workspace_dir))
            tf.add(str(fpath), arcname=arcname)

        # Embed manifest
        manifest_bytes = json.dumps(manifest, indent=2, ensure_ascii=False).encode("utf-8")
        import io
        import tarfile as _tf

        info = _tf.TarInfo(name=_MANIFEST_NAME)
        info.size = len(manifest_bytes)
        tf.addfile(info, io.BytesIO(manifest_bytes))

    archive_size = archive_path.stat().st_size
    existing = _list_backup_archives(backup_dir)

    result = {
        "success": True,
        "archive": str(archive_path),
        "archive_size": _bytes_human(archive_size),
        "files_backed_up": len(files),
        "uncompressed_size": _bytes_human(total_size),
        "label": label,
        "total_backups": len(existing),
    }
    print(json.dumps(result, indent=2, ensure_ascii=False))
    return 0


def cmd_list(args: argparse.Namespace) -> int:
    """List existing backup archives."""
    backup_dir = _resolve_backup_dir(args)
    archives = _list_backup_archives(backup_dir)

    if not archives:
        print(json.dumps({"backups": [], "total": 0}, indent=2))
        return 0

    backups = []
    for idx, archive in enumerate(archives):
        st = archive.stat()
        manifest = _read_manifest(archive)
        entry: dict = {
            "id": idx + 1,
            "filename": archive.name,
            "size": _bytes_human(st.st_size),
            "created": datetime.fromtimestamp(st.st_mtime, tz=UTC).strftime("%Y-%m-%d %H:%M:%S UTC"),
        }
        if manifest:
            entry["label"] = manifest.get("label", "")
            entry["file_count"] = manifest.get("file_count", "?")
            entry["uncompressed_size"] = manifest.get("total_size_human", "?")
        backups.append(entry)

    result = {"backups": backups, "total": len(backups), "backup_dir": str(backup_dir)}
    print(json.dumps(result, indent=2, ensure_ascii=False))
    return 0


def cmd_restore(args: argparse.Namespace) -> int:
    """Restore workspace from a backup archive."""
    workspace_dir = _resolve_workspace_dir(args)
    backup_dir = _resolve_backup_dir(args)
    archives = _list_backup_archives(backup_dir)

    if not archives:
        print("❌ No backups found.", file=sys.stderr)
        return 1

    # Resolve which archive to restore
    if args.id:
        archive = _find_backup_by_id(backup_dir, args.id)
        if not archive:
            print(f"❌ Backup not found for ID: {args.id}", file=sys.stderr)
            return 1
    else:
        archive = archives[0]  # latest

    manifest = _read_manifest(archive)
    file_count = manifest.get("file_count", "?") if manifest else "?"
    label = manifest.get("label", "") if manifest else ""

    # Create safety backup of current workspace first
    safety_path = backup_dir / _SAFETY_BACKUP_NAME
    current_files = _collect_backup_files(workspace_dir)
    if current_files:
        with tarfile.open(safety_path, "w:gz") as tf:
            for fpath in current_files:
                arcname = str(fpath.relative_to(workspace_dir))
                tf.add(str(fpath), arcname=arcname)

    # Extract archive into a temp dir, then merge into workspace_dir
    tmp_dir = None
    try:
        tmp_dir = Path(tempfile.mkdtemp(prefix="lightclaw_restore_"))
        with tarfile.open(archive, "r:gz") as tf:
            tf.extractall(tmp_dir, filter="data")

        # Merge files into workspace_dir (overwrite existing, create new)
        restored_count = 0
        for item in tmp_dir.rglob("*"):
            if item.is_file() and item.name != _MANIFEST_NAME:
                rel = item.relative_to(tmp_dir)
                dest = workspace_dir / rel
                dest.parent.mkdir(parents=True, exist_ok=True)
                shutil.copy2(item, dest)
                restored_count += 1

        result = {
            "success": True,
            "restored_from": archive.name,
            "label": label,
            "files_restored": restored_count,
            "expected_files": file_count,
            "restore_target": str(workspace_dir),
            "safety_backup": str(safety_path),
            "message": "Restore complete. Please restart LightClaw for changes to take effect.",
        }
        print(json.dumps(result, indent=2, ensure_ascii=False))
        return 0

    except Exception as exc:
        print(f"❌ Restore failed: {exc}", file=sys.stderr)
        print(
            f"⚠️  Safety backup is available at: {safety_path}",
            file=sys.stderr,
        )
        return 1
    finally:
        if tmp_dir and tmp_dir.is_dir():
            shutil.rmtree(tmp_dir, ignore_errors=True)


def cmd_diff(args: argparse.Namespace) -> int:
    """Show differences between a backup and the current workspace state."""
    workspace_dir = _resolve_workspace_dir(args)
    backup_dir = _resolve_backup_dir(args)

    if not args.id:
        print("❌ --id is required for diff.", file=sys.stderr)
        return 1

    archive = _find_backup_by_id(backup_dir, args.id)
    if not archive:
        print(f"❌ Backup not found for ID: {args.id}", file=sys.stderr)
        return 1

    manifest = _read_manifest(archive)
    if not manifest:
        print("❌ Cannot read backup manifest.", file=sys.stderr)
        return 1

    # Build lookup from manifest: path -> md5
    backup_files: dict[str, str] = {}
    for entry in manifest.get("files", []):
        backup_files[entry["path"]] = entry["md5"]

    # Build current file set
    current_files_list = _collect_backup_files(workspace_dir)
    current_files: dict[str, str] = {}
    for fpath in current_files_list:
        rel = str(fpath.relative_to(workspace_dir))
        current_files[rel] = _file_md5(fpath)

    all_paths = sorted(set(backup_files.keys()) | set(current_files.keys()))

    added: list[str] = []
    removed: list[str] = []
    modified: list[str] = []
    unchanged: list[str] = []

    for path in all_paths:
        in_backup = path in backup_files
        in_current = path in current_files
        if in_current and not in_backup:
            added.append(path)
        elif in_backup and not in_current:
            removed.append(path)
        elif backup_files[path] != current_files[path]:
            modified.append(path)
        else:
            unchanged.append(path)

    result = {
        "backup": archive.name,
        "label": manifest.get("label", ""),
        "backup_date": manifest.get("created_at", "?"),
        "summary": {
            "added": len(added),
            "removed": len(removed),
            "modified": len(modified),
            "unchanged": len(unchanged),
        },
        "added": added,
        "removed": removed,
        "modified": modified,
    }
    print(json.dumps(result, indent=2, ensure_ascii=False))
    return 0


def cmd_clean(args: argparse.Namespace) -> int:
    """Remove old backups, keeping the N most recent."""
    backup_dir = _resolve_backup_dir(args)
    keep = args.keep
    archives = _list_backup_archives(backup_dir)

    if len(archives) <= keep:
        result = {
            "cleaned": 0,
            "remaining": len(archives),
            "message": f"Nothing to clean — only {len(archives)} backup(s), keeping {keep}.",
        }
        print(json.dumps(result, indent=2, ensure_ascii=False))
        return 0

    to_remove = archives[keep:]
    removed_names: list[str] = []
    freed_bytes = 0

    for archive in to_remove:
        try:
            size = archive.stat().st_size
            archive.unlink()
            removed_names.append(archive.name)
            freed_bytes += size
        except Exception as exc:
            print(f"⚠️  Failed to remove {archive.name}: {exc}", file=sys.stderr)

    result = {
        "cleaned": len(removed_names),
        "freed": _bytes_human(freed_bytes),
        "remaining": len(archives) - len(removed_names),
        "removed": removed_names,
    }
    print(json.dumps(result, indent=2, ensure_ascii=False))
    return 0


# ---------------------------------------------------------------------------
# CLI entry point
# ---------------------------------------------------------------------------


def main() -> int:
    parser = argparse.ArgumentParser(
        description="LightClaw Backup & Version Management",
    )
    parser.add_argument(
        "--workspace-dir",
        default=str(_DEFAULT_WORKSPACE_DIR),
        help="LightClaw workspace directory (default: ~/.lightclaw/workspace)",
    )
    parser.add_argument(
        "--backup-dir",
        default=str(_DEFAULT_BACKUP_DIR),
        help="Backup storage directory (default: ~/.lightclaw/backups)",
    )

    sub = parser.add_subparsers(dest="command", help="Available commands")

    # create
    p_create = sub.add_parser("create", help="Create a new backup")
    p_create.add_argument("--label", default="", help="Human-readable label for this backup")

    # list
    sub.add_parser("list", help="List existing backups")

    # restore
    p_restore = sub.add_parser("restore", help="Restore from a backup")
    p_restore.add_argument("--id", default=None, help="Backup ID or filename to restore (default: latest)")

    # diff
    p_diff = sub.add_parser("diff", help="Show changes since a backup")
    p_diff.add_argument("--id", required=True, help="Backup ID or filename to compare")

    # clean
    p_clean = sub.add_parser("clean", help="Remove old backups")
    p_clean.add_argument(
        "--keep",
        type=int,
        default=_DEFAULT_KEEP,
        help=f"Number of recent backups to keep (default: {_DEFAULT_KEEP})",
    )

    args = parser.parse_args()

    if not args.command:
        parser.print_help()
        return 1

    handlers = {
        "create": cmd_create,
        "list": cmd_list,
        "restore": cmd_restore,
        "diff": cmd_diff,
        "clean": cmd_clean,
    }

    return handlers[args.command](args)


if __name__ == "__main__":
    sys.exit(main())
