#!/usr/bin/env python3
"""
Step 2: Process speech manuscript into structured subtitle data.

Steps:
1. Read Markdown-formatted speech manuscript.
2. Clean special characters and formatting markers.
3. Split per slide into sentence segments.
4. Output a JSON structure for TTS and subtitle generation.

Usage:
    python step2_process_speech.py --input <speech.md> --output <output.json>

Output JSON format:
{
    "slides": [
        {
            "slide_number": 1,
            "title": "Slide title",
            "sentences": [
                "First sentence of the speech.",
                "Second sentence.",
                ...
            ],
            "full_text": "All sentences joined."
        },
        ...
    ]
}
"""

import argparse
import json
import os
import re
import sys


def read_speech_file(filepath: str) -> str:
    """Read the speech markdown file."""
    with open(filepath, encoding="utf-8") as f:
        return f.read()


def clean_text(text: str) -> str:
    """
    Clean special characters from speech text.
    - Remove markdown bold/italic markers
    - Remove blockquotes
    - Remove time annotations like (约 1 分钟)
    - Remove markdown links but keep text
    - Clean up excessive whitespace
    - Keep actual punctuation for natural speech
    """
    # Remove time/duration annotations like **（约 1 分钟）** or （约 30 秒）
    text = re.sub(r"[*]*（[^）]*(?:分钟|秒|min|sec)[^）]*）[*]*", "", text)

    # Remove meta info like *总时长：约 5 分钟*
    text = re.sub(r"[*]*总时长[：:].*$", "", text, flags=re.MULTILINE)

    # Remove markdown bold markers **text** -> text
    text = re.sub(r"\*\*([^*]+)\*\*", r"\1", text)

    # Remove markdown italic markers *text* -> text
    text = re.sub(r"\*([^*]+)\*", r"\1", text)

    # Remove markdown links [text](url) -> text
    text = re.sub(r"\[([^\]]+)\]\([^)]+\)", r"\1", text)

    # Remove inline code backticks
    text = re.sub(r"`([^`]+)`", r"\1", text)

    # Remove blockquote markers
    text = re.sub(r"^>\s*", "", text, flags=re.MULTILINE)

    # Remove horizontal rules
    text = re.sub(r"^---+\s*$", "", text, flags=re.MULTILINE)

    # Remove heading markers but keep text
    text = re.sub(r"^#{1,6}\s*", "", text, flags=re.MULTILINE)

    # Clean up em-dashes and special dashes
    text = text.replace("——", "，")
    text = text.replace("—", "，")

    # Clean up multiple newlines to single space (speech is continuous)
    text = re.sub(r"\n+", " ", text)
    text = re.sub(r"[ \t]+", " ", text)

    return text.strip()


def split_into_sentences(text: str) -> list:
    """
    Split text into natural sentences for TTS.
    Split on Chinese/English sentence-ending punctuation.
    Avoid splitting at decimal points (e.g., 1.5, 3.0, 0.02).
    """
    # Split on sentence-ending punctuation, keeping the punctuation
    # Focus on Chinese punctuation; English period is tricky (decimals, abbreviations)
    # so we only split on period followed by space+uppercase or end-of-string
    sentences = re.split(r"(?<=[。！？；\!\?])\s*|(?<=\.)\s+(?=[A-Z\u4e00-\u9fff])", text)

    # Also split on long comma-separated clauses if sentence is very long
    result = []
    for sent in sentences:
        sent = sent.strip()
        if not sent:
            continue

        # If sentence is very long (>80 chars), try splitting on commas
        if len(sent) > 80:
            # Split on comma patterns but keep reasonable chunks
            parts = re.split(r"(?<=[，,])\s*", sent)
            current = ""
            for part in parts:
                if len(current) + len(part) > 60 and current:
                    result.append(current.strip())
                    current = part
                else:
                    current += part
            if current.strip():
                result.append(current.strip())
        else:
            result.append(sent)

    # Filter out empty or whitespace-only entries
    result = [s for s in result if s.strip() and len(s.strip()) > 1]

    return result


def parse_slides(content: str) -> list:
    """
    Parse the speech markdown into slide segments.
    Detects slide boundaries by ## headings with slide numbers.
    """
    slides = []

    # Split by slide headings (## 第 X 页 or ## Slide X patterns)
    slide_pattern = r"##\s*第\s*(\d+)\s*页[·\s]*(.+?)$"
    parts = re.split(slide_pattern, content, flags=re.MULTILINE)

    if len(parts) < 4:
        # Try alternative pattern: just ## headings
        slide_pattern = r"##\s+(.+?)$"
        sections = re.split(slide_pattern, content, flags=re.MULTILINE)

        # Pair up: sections[0] is preamble, then alternating title/content
        for slide_num, i in enumerate(range(1, len(sections), 2), start=1):
            title = sections[i].strip()
            body = sections[i + 1] if i + 1 < len(sections) else ""
            cleaned = clean_text(body)
            sentences = split_into_sentences(cleaned)
            if sentences:
                slides.append(
                    {
                        "slide_number": slide_num,
                        "title": clean_text(title),
                        "sentences": sentences,
                        "full_text": " ".join(sentences),
                    }
                )
    else:
        # parts[0] is preamble, then groups of (slide_num, title, content)
        for i in range(1, len(parts), 3):
            slide_num = int(parts[i])
            title = parts[i + 1].strip() if i + 1 < len(parts) else ""
            body = parts[i + 2] if i + 2 < len(parts) else ""

            cleaned = clean_text(body)
            sentences = split_into_sentences(cleaned)

            if sentences:
                slides.append(
                    {
                        "slide_number": slide_num,
                        "title": clean_text(title),
                        "sentences": sentences,
                        "full_text": " ".join(sentences),
                    }
                )

    return slides


def main():
    parser = argparse.ArgumentParser(description="Process speech manuscript into structured data")
    parser.add_argument("--input", required=True, help="Path to speech markdown file")
    parser.add_argument("--output", required=True, help="Output JSON path")
    args = parser.parse_args()

    if not os.path.isfile(args.input):
        print(f"[ERROR] Input file not found: {args.input}", file=sys.stderr)
        sys.exit(1)

    content = read_speech_file(args.input)
    slides = parse_slides(content)

    if not slides:
        print("[ERROR] No slides found in the speech file.", file=sys.stderr)
        sys.exit(1)

    output_data = {"slides": slides}

    os.makedirs(os.path.dirname(os.path.abspath(args.output)), exist_ok=True)
    with open(args.output, "w", encoding="utf-8") as f:
        json.dump(output_data, f, ensure_ascii=False, indent=2)

    # Print summary
    total_sentences = sum(len(s["sentences"]) for s in slides)
    total_chars = sum(len(s["full_text"]) for s in slides)
    print("\n[Step 2 DONE] Speech processed successfully.")
    print(f"  Total slides: {len(slides)}")
    print(f"  Total sentences: {total_sentences}")
    print(f"  Total characters: {total_chars}")
    print(f"  Output: {args.output}")

    for slide in slides:
        print(f"\n  Slide {slide['slide_number']}: {slide['title']}")
        print(f"    Sentences: {len(slide['sentences'])}")
        print(f"    Characters: {len(slide['full_text'])}")

    return output_data


if __name__ == "__main__":
    main()
