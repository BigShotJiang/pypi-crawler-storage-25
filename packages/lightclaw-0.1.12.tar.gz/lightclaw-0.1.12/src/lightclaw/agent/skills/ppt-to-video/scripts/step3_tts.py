#!/usr/bin/env python3
"""
Step 3: Generate speech audio using edge-tts.

Workflow:
1. Read the structured speech data produced by step 2
2. Synthesize audio sentence by sentence via edge-tts (Microsoft free online TTS)
3. Insert inter-sentence / inter-slide pauses
4. Concatenate into a full speech audio file and record precise timing metadata

Usage:
    python step3_tts.py \
        --speech_json <speech_data.json> \
        --output_dir <output_directory> \
        --voice "zh-CN-XiaoxiaoNeural"

Dependencies:
    pip install edge-tts
"""

import argparse
import asyncio
import contextlib
import json
import os
import re
import subprocess
import sys
import tempfile
import time
import wave

# Recommended Chinese voices for edge-tts
EDGE_VOICES = {
    "zh-CN-XiaoxiaoNeural": "晓晓（女，温暖自然）",
    "zh-CN-XiaoyiNeural": "晓伊（女，亲切活泼）",
    "zh-CN-YunjianNeural": "云健（男，沉稳大气）",
    "zh-CN-YunxiNeural": "云希（男，年轻阳光）",
    "zh-CN-YunyangNeural": "云扬（男，新闻播报）",
}

SAMPLE_RATE = 24000


def get_audio_duration(audio_path: str) -> float:
    """Return audio file duration in seconds using ffprobe."""
    try:
        result = subprocess.run(
            [
                "ffprobe",
                "-v",
                "error",
                "-show_entries",
                "format=duration",
                "-of",
                "default=noprint_wrappers=1:nokey=1",
                audio_path,
            ],
            capture_output=True,
            text=True,
        )
        return float(result.stdout.strip())
    except Exception:
        return 0.0


def synthesize(text: str, output_path: str, voice: str) -> float:
    """
    Synthesize a single sentence to audio using edge-tts.

    Returns the audio duration in seconds, or 0.0 on failure.
    """
    import edge_tts

    try:
        mp3_path = output_path.rsplit(".", 1)[0] + ".mp3"

        communicate = edge_tts.Communicate(text=text, voice=voice)
        # Prefer save_sync for compatibility; fall back to asyncio.run(save())
        if hasattr(communicate, "save_sync"):
            communicate.save_sync(mp3_path)
        else:
            asyncio.run(communicate.save(mp3_path))

        # Convert MP3 to WAV (24 kHz mono 16-bit PCM)
        cmd = ["ffmpeg", "-y", "-i", mp3_path, "-acodec", "pcm_s16le", "-ar", str(SAMPLE_RATE), "-ac", "1", output_path]
        result = subprocess.run(cmd, capture_output=True, text=True)
        if result.returncode != 0:
            print(f"[Error] MP3→WAV conversion failed: {result.stderr}", file=sys.stderr)
            return 0.0

        if os.path.exists(mp3_path):
            os.remove(mp3_path)

        return get_audio_duration(output_path)

    except Exception as e:
        print(f"[Error] edge-tts synthesis failed for '{text[:30]}...': {e}", file=sys.stderr)
        return 0.0


_silence_counter = 0


def add_silence(duration_sec: float) -> str:
    """Generate a silent WAV file of the given duration (cross-platform safe, unique path)."""
    global _silence_counter
    _silence_counter += 1
    samples = int(duration_sec * SAMPLE_RATE)
    tmp_dir = tempfile.gettempdir()
    tmp_path = os.path.join(tmp_dir, f"silence_{_silence_counter:04d}_{duration_sec:.2f}s.wav")

    with wave.open(tmp_path, "w") as wf:
        wf.setnchannels(1)
        wf.setsampwidth(2)
        wf.setframerate(SAMPLE_RATE)
        wf.writeframes(b"\x00\x00" * samples)

    return tmp_path


def concatenate_audio_files(audio_files: list, output_path: str):
    """Concatenate multiple audio files into one using FFmpeg."""
    if not audio_files:
        return

    list_path = output_path + ".filelist.txt"
    with open(list_path, "w") as f:
        for af in audio_files:
            abs_path = os.path.abspath(af)
            f.write(f"file '{abs_path}'\n")

    cmd = [
        "ffmpeg",
        "-y",
        "-f",
        "concat",
        "-safe",
        "0",
        "-i",
        list_path,
        "-acodec",
        "pcm_s16le",
        "-ar",
        str(SAMPLE_RATE),
        "-ac",
        "1",
        output_path,
    ]

    result = subprocess.run(cmd, capture_output=True, text=True)
    if result.returncode != 0:
        print(f"[Error] Audio concatenation failed: {result.stderr}", file=sys.stderr)

    if os.path.exists(list_path):
        os.remove(list_path)


def normalize_text_for_tts(text: str) -> str:
    """Pre-process text to remove special characters that cause TTS artifacts."""
    result = text
    result = re.sub(r"——", "，", result)
    result = re.sub(r"—", "，", result)
    result = re.sub(r"\s+", " ", result).strip()
    return result


def main():
    parser = argparse.ArgumentParser(description="Generate speech audio using edge-tts")
    parser.add_argument("--speech_json", required=True, help="Structured speech JSON produced by step 2")
    parser.add_argument("--output_dir", required=True, help="Output directory")
    parser.add_argument(
        "--voice",
        default="zh-CN-XiaoxiaoNeural",
        help="edge-tts voice name (default: zh-CN-XiaoxiaoNeural). Options: "
        + ", ".join(f"{k}({v})" for k, v in EDGE_VOICES.items()),
    )
    parser.add_argument(
        "--sentence_pause", type=float, default=0.4, help="Pause between sentences in seconds (default: 0.4)"
    )
    parser.add_argument("--slide_pause", type=float, default=1.0, help="Pause between slides in seconds (default: 1.0)")
    args = parser.parse_args()

    # Verify edge-tts is available
    try:
        import edge_tts  # noqa: F401
    except ImportError:
        print("[Error] edge-tts is not installed. Run: pip install edge-tts", file=sys.stderr)
        sys.exit(1)

    # Load speech data
    with open(args.speech_json, encoding="utf-8") as f:
        speech_data = json.load(f)

    slides = speech_data["slides"]
    os.makedirs(args.output_dir, exist_ok=True)

    sentences_dir = os.path.join(args.output_dir, "sentences")
    slides_audio_dir = os.path.join(args.output_dir, "slides")
    os.makedirs(sentences_dir, exist_ok=True)
    os.makedirs(slides_audio_dir, exist_ok=True)

    voice = args.voice
    print("\n[Step 3] TTS engine: edge-tts")
    print(f"[Step 3] Voice: {voice}")
    if voice in EDGE_VOICES:
        print(f"[Step 3] Description: {EDGE_VOICES[voice]}")

    # Timing metadata
    timing_data = {
        "sample_rate": SAMPLE_RATE,
        "tts_engine": "edge",
        "voice": voice,
        "slides": [],
        "total_duration": 0.0,
    }

    all_audio_files = []
    current_time = 0.0

    for slide in slides:
        slide_num = slide["slide_number"]
        slide_title = slide["title"]
        sentences = slide["sentences"]

        print(f"\n[Step 3] Processing slide {slide_num}: {slide_title}")
        print(f"  Sentences: {len(sentences)}")

        slide_start_time = current_time
        slide_audio_files = []
        sentence_timings = []

        for idx, sentence in enumerate(sentences):
            sent_file = os.path.join(sentences_dir, f"slide{slide_num}_sent{idx:03d}.wav")

            # Pre-process text before TTS synthesis
            processed = normalize_text_for_tts(sentence)
            if processed != sentence:
                print(f"  [Preprocess] {sentence[:40]} → {processed[:40]}")

            print(f"  Generating: [{idx + 1}/{len(sentences)}] {sentence[:40]}...")
            start_t = time.time()

            duration = synthesize(text=processed, output_path=sent_file, voice=voice)

            gen_time = time.time() - start_t
            print(f"    Duration: {duration:.2f}s (generated in {gen_time:.1f}s)")

            if duration > 0:
                sentence_timings.append(
                    {
                        "index": idx,
                        "text": sentence,
                        "start_time": current_time,
                        "duration": duration,
                        "end_time": current_time + duration,
                        "audio_file": sent_file,
                    }
                )
                slide_audio_files.append(sent_file)
                all_audio_files.append(sent_file)
                current_time += duration

                # Inter-sentence pause (skip after the last sentence)
                if idx < len(sentences) - 1:
                    pause_file = add_silence(args.sentence_pause)
                    slide_audio_files.append(pause_file)
                    all_audio_files.append(pause_file)
                    current_time += args.sentence_pause

        # Concatenate audio for this slide
        slide_audio_path = os.path.join(slides_audio_dir, f"slide{slide_num}_audio.wav")
        concatenate_audio_files(slide_audio_files, slide_audio_path)

        slide_end_time = current_time
        slide_duration = slide_end_time - slide_start_time

        timing_data["slides"].append(
            {
                "slide_number": slide_num,
                "title": slide_title,
                "start_time": slide_start_time,
                "end_time": slide_end_time,
                "duration": slide_duration,
                "audio_file": slide_audio_path,
                "sentences": sentence_timings,
            }
        )

        print(f"  Slide {slide_num} duration: {slide_duration:.2f}s")

        # Inter-slide pause
        if slide != slides[-1]:
            pause_file = add_silence(args.slide_pause)
            all_audio_files.append(pause_file)
            current_time += args.slide_pause

    # Concatenate all slides into the final full audio
    full_audio_path = os.path.join(args.output_dir, "full_speech.wav")
    concatenate_audio_files(all_audio_files, full_audio_path)

    # Clean up temporary silence files
    tmp_dir = tempfile.gettempdir()
    for af in all_audio_files:
        if af.startswith(tmp_dir) and "silence_" in af and os.path.exists(af):
            with contextlib.suppress(OSError):
                os.remove(af)

    timing_data["total_duration"] = current_time

    # Save timing data
    timing_path = os.path.join(args.output_dir, "timing_data.json")
    with open(timing_path, "w", encoding="utf-8") as f:
        json.dump(timing_data, f, ensure_ascii=False, indent=2)

    print("\n[Step 3 Complete] Speech synthesis done.")
    print(f"  Voice: {voice}")
    print(f"  Full audio: {full_audio_path}")
    print(f"  Total duration: {current_time:.2f}s")
    print(f"  Timing data: {timing_path}")

    return timing_data


if __name__ == "__main__":
    main()
