#!/usr/bin/env python3
"""
PPT-to-video pipeline: end-to-end fully automated pipeline.

Executes 4 steps in sequence:
1. Process speech script into structured subtitle data (step2)
2. Generate speech audio using edge-tts (step3)
3. Generate slide video from PDF using timing data (step4)
4. Merge video, audio, and subtitles (step5)

Usage:
    python run_pipeline.py \
        --speech_md <speech_script.md> \
        --slides_pdf <slides.pdf> \
        --output_dir <output_directory>
"""

import argparse
import os
import subprocess
import sys
import time

SCRIPT_DIR = os.path.dirname(os.path.abspath(__file__))


def run_step(step_num: int, script_name: str, args_list: list, description: str) -> int:
    """Run one pipeline step and report elapsed time."""
    print(f"\n{'=' * 70}")
    print(f"  Step {step_num}: {description}")
    print(f"{'=' * 70}\n")

    script_path = os.path.join(SCRIPT_DIR, script_name)
    if not os.path.isfile(script_path):
        print(f"[ERROR] Script not found: {script_path}", file=sys.stderr)
        return 1

    cmd = [sys.executable, script_path, *args_list]
    start_time = time.time()
    result = subprocess.run(cmd)
    elapsed = time.time() - start_time

    status = "SUCCESS" if result.returncode == 0 else "FAILED"
    print(f"\n[Step {step_num}] {status} (elapsed {elapsed:.1f}s)")
    return result.returncode


def main():
    parser = argparse.ArgumentParser(
        description="PPT-to-video: fully automated pipeline (edge-tts)",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
Examples:
  python run_pipeline.py \\
    --speech_md slides-speech.md \\
    --slides_pdf slides.pdf \\
    --output_dir output/presentation

  python run_pipeline.py \\
    --speech_md slides-speech.md \\
    --slides_pdf slides.pdf \\
    --output_dir output/presentation \\
    --voice "zh-CN-YunjianNeural"
        """,
    )

    parser.add_argument("--speech_md", required=True, help="Speech script Markdown file")
    parser.add_argument("--slides_pdf", required=True, help="Slides PDF file")
    parser.add_argument("--output_dir", required=True, help="Output directory for all generated files")
    parser.add_argument(
        "--voice", default="zh-CN-XiaoxiaoNeural", help="edge-tts voice name (default: zh-CN-XiaoxiaoNeural)"
    )
    parser.add_argument("--resolution", default="1920x1080", help="Video resolution (default: 1920x1080)")
    parser.add_argument("--fps", type=int, default=30, help="Video frame rate (default: 30)")
    parser.add_argument(
        "--sentence_pause", type=float, default=0.4, help="Pause between sentences in seconds (default: 0.4)"
    )
    parser.add_argument("--slide_pause", type=float, default=1.0, help="Pause between slides in seconds (default: 1.0)")
    parser.add_argument(
        "--subtitle_mode", choices=["burn", "soft", "both"], default="burn", help="Subtitle mode (default: burn)"
    )
    parser.add_argument("--font_name", default="auto", help="Subtitle font name (default: auto-detect CJK font)")
    parser.add_argument("--font_size", type=int, default=38, help="Subtitle font size (default: 38)")
    parser.add_argument(
        "--skip_steps",
        nargs="*",
        type=int,
        default=[],
        help="Step numbers to skip (e.g. --skip_steps 2 skips speech processing)",
    )
    parser.add_argument("--dpi", type=int, default=200, help="PDF rendering DPI (default: 200)")

    args = parser.parse_args()

    # Validate input files
    for path_arg, name in [(args.speech_md, "speech_md"), (args.slides_pdf, "slides_pdf")]:
        if not os.path.isfile(path_arg) and not os.path.isfile(os.path.abspath(path_arg)):
            print(f"[ERROR] File not found: {path_arg} ({name})", file=sys.stderr)
            sys.exit(1)

    # Set up directories
    os.makedirs(args.output_dir, exist_ok=True)
    step2_output = os.path.join(args.output_dir, "step2_speech_data.json")
    step3_dir = os.path.join(args.output_dir, "step3_tts")
    step4_dir = os.path.join(args.output_dir, "step4_video")
    final_output = os.path.join(args.output_dir, "final_presentation.mp4")

    pipeline_start = time.time()
    print(f"\n{'#' * 70}")
    print("  PPT-to-Video Pipeline")
    print("  TTS engine: edge-tts")
    print(f"  Voice: {args.voice}")
    print(f"  Speech script: {args.speech_md}")
    print(f"  Slides: {args.slides_pdf}")
    print(f"  Output dir: {args.output_dir}")
    print(f"{'#' * 70}")

    # Step 2: Process speech script
    if 2 not in args.skip_steps:
        rc = run_step(
            2, "step2_process_speech.py", ["--input", args.speech_md, "--output", step2_output], "Process speech script"
        )
        if rc != 0:
            print("[Pipeline] Step 2 failed, aborting.", file=sys.stderr)
            sys.exit(1)
    else:
        print(f"[Pipeline] Skipping step 2, using: {step2_output}")

    # Step 3: Text-to-speech synthesis
    if 3 not in args.skip_steps:
        rc = run_step(
            3,
            "step3_tts.py",
            [
                "--speech_json",
                step2_output,
                "--output_dir",
                step3_dir,
                "--voice",
                args.voice,
                "--sentence_pause",
                str(args.sentence_pause),
                "--slide_pause",
                str(args.slide_pause),
            ],
            "Speech synthesis (edge-tts)",
        )
        if rc != 0:
            print("[Pipeline] Step 3 failed, aborting.", file=sys.stderr)
            sys.exit(1)
    else:
        print("[Pipeline] Skipping step 3")

    timing_json = os.path.join(step3_dir, "timing_data.json")
    full_speech_audio = os.path.join(step3_dir, "full_speech.wav")

    # Step 4: Generate slide video
    if 4 not in args.skip_steps:
        rc = run_step(
            4,
            "step4_generate_video.py",
            [
                "--pdf",
                args.slides_pdf,
                "--timing_json",
                timing_json,
                "--output_dir",
                step4_dir,
                "--resolution",
                args.resolution,
                "--fps",
                str(args.fps),
                "--dpi",
                str(args.dpi),
            ],
            "Generate slide video from PDF",
        )
        if rc != 0:
            print("[Pipeline] Step 4 failed, aborting.", file=sys.stderr)
            sys.exit(1)
    else:
        print("[Pipeline] Skipping step 4")

    slides_video = os.path.join(step4_dir, "slides_video.mp4")

    # Step 5: Merge all
    if 5 not in args.skip_steps:
        rc = run_step(
            5,
            "step5_merge_all.py",
            [
                "--video",
                slides_video,
                "--audio",
                full_speech_audio,
                "--timing_json",
                timing_json,
                "--output",
                final_output,
                "--subtitle_mode",
                args.subtitle_mode,
                "--resolution",
                args.resolution,
                "--font_name",
                args.font_name,
                "--font_size",
                str(args.font_size),
            ],
            "Merge video, audio, and subtitles",
        )
        if rc != 0:
            print("[Pipeline] Step 5 failed, aborting.", file=sys.stderr)
            sys.exit(1)
    else:
        print("[Pipeline] Skipping step 5")

    # Summary
    total_time = time.time() - pipeline_start
    print(f"\n{'#' * 70}")
    print("  Pipeline complete")
    print(f"{'#' * 70}")
    print(f"  TTS engine: edge-tts ({args.voice})")
    print(f"  Total time: {total_time:.1f}s ({total_time / 60:.1f} min)")
    print(f"  Final video: {final_output}")

    if os.path.exists(final_output):
        file_size = os.path.getsize(final_output) / (1024 * 1024)
        print(f"  File size: {file_size:.1f} MB")

    print("\n  Generated files:")
    print(f"    Speech data:  {step2_output}")
    print(f"    Full audio:   {full_speech_audio}")
    print(f"    Timing data:  {timing_json}")
    print(f"    Slide video:  {slides_video}")
    print(f"    Final video:  {final_output}")
    print(f"    Subtitles (SRT): {os.path.join(os.path.dirname(final_output), 'subtitles.srt')}")
    print(f"    Subtitles (ASS): {os.path.join(os.path.dirname(final_output), 'subtitles.ass')}")
    print(f"{'#' * 70}\n")


if __name__ == "__main__":
    main()
