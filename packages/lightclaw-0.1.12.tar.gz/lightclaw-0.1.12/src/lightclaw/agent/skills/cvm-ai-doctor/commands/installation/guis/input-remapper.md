Install Intput Remapper.
