#!/usr/bin/env bash
# sync_to_finnie.sh — 将 cvm-migration-dashboard skill 同步到 finnie 工程
#
# 用法:
#   ./scripts/sync_to_finnie.sh                  # 同步到默认目标
#   ./scripts/sync_to_finnie.sh /path/to/target  # 同步到指定目标
#   ./scripts/sync_to_finnie.sh --dry-run        # 预览，不实际复制

set -euo pipefail

# ── 配置 ──────────────────────────────────────────────────────────────────────
SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"
SRC_DIR="$(cd "$SCRIPT_DIR/.." && pwd)"
DEFAULT_TARGET="$HOME/vstation/finnie/src/lightclaw/agent/skills/cvm-migration-dashboard"

# ── 参数解析 ──────────────────────────────────────────────────────────────────
DRY_RUN=false
TARGET=""

for arg in "$@"; do
    case "$arg" in
        --dry-run) DRY_RUN=true ;;
        *)         TARGET="$arg" ;;
    esac
done

TARGET="${TARGET:-$DEFAULT_TARGET}"

# ── 颜色输出 ──────────────────────────────────────────────────────────────────
RED='\033[0;31m'; GREEN='\033[0;32m'; YELLOW='\033[0;33m'; CYAN='\033[0;36m'; NC='\033[0m'
info() { printf "${CYAN}[INFO]${NC}  %s\n" "$*"; }
ok()   { printf "${GREEN}[OK]${NC}    %s\n" "$*"; }
warn() { printf "${YELLOW}[WARN]${NC}  %s\n" "$*"; }
err()  { printf "${RED}[ERR]${NC}   %s\n" "$*" >&2; }

# ── 读取版本号（来自 SKILL.md frontmatter）────────────────────────────────────
SKILL_VERSION=$(grep '^version:' "$SRC_DIR/SKILL.md" 2>/dev/null \
    | sed 's/version:[[:space:]]*//' | tr -d '"' | tr -d "'" | head -1)
SKILL_VERSION="${SKILL_VERSION:-unknown}"
SYNC_TIME=$(date '+%Y-%m-%d %H:%M:%S %z')
NEWEST_FILE=$(find "$SRC_DIR" -not -path '*/.git/*' -not -path '*/_*' \
    -name '*.py' -o -name '*.md' -o -name '*.sh' 2>/dev/null \
    | xargs ls -t 2>/dev/null | head -1)
LAST_MODIFIED=$(stat -f '%Sm' -t '%Y-%m-%d %H:%M:%S' "$NEWEST_FILE" 2>/dev/null \
    || date '+%Y-%m-%d %H:%M:%S')

# ── 打印同步摘要 ──────────────────────────────────────────────────────────────
echo ""
info "cvm-migration-dashboard skill 同步工具"
echo "  源目录:        $SRC_DIR"
echo "  目标目录:      $TARGET"
echo "  skill 版本:    $SKILL_VERSION"
echo "  最近修改:      $LAST_MODIFIED"
if $DRY_RUN; then
    warn "DRY-RUN 模式 — 仅预览，不执行复制"
fi
echo ""

# ── rsync 排除规则 ────────────────────────────────────────────────────────────
# docs/              — 开发文档，非 skill 发布物
# templates/         — 空目录，不需要同步
# migration-dashboard.html — 演示产物，非 skill 核心文件
# _*/                — 归档/备份目录
# .*/                — 隐藏文件(.git, .DS_Store 等)
# version.ini        — 目标侧生成，不从源复制
RSYNC_EXCLUDES=(
    --exclude='docs/'
    --exclude='templates/'
    --exclude='migration-dashboard.html'
    --exclude='_*/'
    --exclude='.*'
    --exclude='version.ini'
)

if $DRY_RUN; then
    info "将同步以下文件（预览）:"
    rsync -avn --delete "${RSYNC_EXCLUDES[@]}" "$SRC_DIR/" "$TARGET/" 2>/dev/null \
        | grep -v '^\.' | grep -v '^$' | grep -v 'sent\|total\|sending\|building'
    echo ""
    info "以上为预览，实际执行请去掉 --dry-run"
    exit 0
fi

# ── 目标目录不存在则提示 ──────────────────────────────────────────────────────
if [ ! -d "$(dirname "$TARGET")" ]; then
    err "目标父目录不存在: $(dirname "$TARGET")"
    err "请确认 finnie 工程路径正确，或手动指定目标: $0 /path/to/target"
    exit 1
fi

mkdir -p "$TARGET"

# ── 执行同步 ──────────────────────────────────────────────────────────────────
rsync -av --delete "${RSYNC_EXCLUDES[@]}" "$SRC_DIR/" "$TARGET/"

# ── 写入 version.ini ──────────────────────────────────────────────────────────
cat > "$TARGET/version.ini" << EOF
[version]
skill_version = $SKILL_VERSION
last_modified = $LAST_MODIFIED

[sync]
synced_at     = $SYNC_TIME
synced_from   = $SRC_DIR
EOF

echo ""
ok "同步完成!"
echo ""
info "version.ini:"
cat "$TARGET/version.ini"
echo ""
info "目标目录内容:"
ls -1 "$TARGET/"
