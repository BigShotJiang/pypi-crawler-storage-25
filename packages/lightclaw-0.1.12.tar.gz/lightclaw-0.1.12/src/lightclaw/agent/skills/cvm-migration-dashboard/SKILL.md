---
name: cvm-migration-dashboard
description: 云迁移可视化看板，将 MigraQ 迁移分析结果转化为交互式 HTML 看板。触发词：迁移看板、迁移对比、迁移可视化、migration dashboard、迁移报告美化、生成看板、看板展示、可视化对比
description_zh: 将 MigraQ 的选型推荐和 TCO 分析结果转化为交互式可视化看板，直观展示源端 vs 腾讯云资源对照、费用节省和匹配等级
description_en: Convert MigraQ migration analysis results into an interactive visual dashboard showing resource comparison, cost savings, and match grades
version: "0.2"
allowed-tools:
  - Bash
  - Read
  - Write
metadata:
  openclaw:
    emoji: 📊
    requires:
      bins:
        - python3
      env: []
    permissions:
      - fs:/tmp/
    security:
      data_handling: 本 Skill 不处理任何云凭证，不在本地持久化存储任何用户数据
    os:
      - linux
      - darwin
      - windows
  lightclaw:
    emoji: 📊
    requires:
      bins:
        - python3
      env: []
---

# CVM Migration Dashboard

**用途**: 将 MigraQ 远端 Agent 返回的迁移数据（资源扫描、选型推荐、TCO 分析）转化为高质量的交互式可视化看板。

**核心价值**: MigraQ 远端 Agent 已能产出结构化数据和基础报表，本 Skill 在其基础上提供**增强可视化**——让迁移决策更直观。

---

## 🎯 何时使用此技能

**触发关键词**: 迁移看板、迁移对比、迁移可视化、migration dashboard、迁移报告美化、生成看板、看板展示、可视化对比

**前置条件**: 需要先通过 MigraQ 技能获取迁移数据（选型推荐 JSON 或 TCO 结果）；若无数据可使用演示模式

---

## 🚀 工作流（三阶段全程驱动）

本技能**自己负责完整三阶段流程**，用户一句话触发：

### 阶段零（每次执行前）：定位并验证 MigraQ

跨技能调用的标准预检模式：先找到被调用方，再调用被调用方自己的 `check_env.py`，确保其版本最新、凭证就绪、网络可达。

**Step 1：定位 MigraQ 路径**

```bash
MIGRAQ_PATH=$(python3 {baseDir}/scripts/check_env.py --locate-migraq)
```

若退出码非 0，报错：提示用户安装 MigraQ 技能，或设置 `$MIGRAQ_SKILL_PATH` 环境变量指向 MigraQ 目录。

**MigraQ 路径解析顺序**（check_env.py 内置逻辑，无需手动维护）：
1. `$MIGRAQ_SKILL_PATH` 环境变量（最高优先级，用于非标准安装位置）
2. `~/.lightclaw/workspace/skills/MigraQ`
3. `~/.lightclaw/skills/MigraQ`
4. `~/.workbuddy/skills/MigraQ`
5. `~/.codebuddy/skills/MigraQ`
6. `~/.agents/skills/MigraQ`

**Step 2：调用 MigraQ 自身的环境检测（版本 + AK/SK + 网络）**

```bash
python3 "$MIGRAQ_PATH/scripts/check_env.py"
```

此步骤由 MigraQ 自己负责：检测 Python 版本、与远端对比版本号（确保最新）、验证 `TENCENTCLOUD_SECRET_ID` / `TENCENTCLOUD_SECRET_KEY`、检查到 CMG API 的网络连通性。根据退出码处理：详见下方"错误处理"章节。

### 阶段一：调用 MigraQ 获取迁移分析

将用户原话原样转发给 MigraQ（遵守 MigraQ 转发铁律，不改写）：

```bash
python3 "$MIGRAQ_PATH/scripts/migrateq_sse_api.py" '<用户原话>'
```

- 获取 `session_id`（后续阶段必须复用）
- 将 `data.content`（Markdown 分析报告）**完整展示给用户**

### 阶段二：同 session 追问 JSON 导出

在**同一 session** 中请求结构化导出：

```bash
python3 "$MIGRAQ_PATH/scripts/migrateq_sse_api.py" '<JSON_EXPORT_PROMPT>' '<session_id>'
```

**JSON 导出 Prompt（固定模板，必须逐字使用，不得改写）**:

```
请将上述选型推荐和TCO分析结果，按照以下 JSON schema 完整导出。只输出纯 JSON，不要包含任何说明文字或 markdown 代码块标记：

{"meta":{"source_cloud":"源云名称","target_cloud":"腾讯云","analysis_date":"YYYY-MM-DD","total_source_cost":0.0,"total_target_cost":0.0,"total_savings":0.0,"savings_pct":0.0},"resources":[{"id":1,"product":"ECS|MySQL|Redis|CDB","source_spec":"规格标识","source_cpu":4,"source_mem":16,"source_region":"地域","source_billing":"包年包月|按量付费","source_cost":0.0,"target_spec":"腾讯云规格或—","target_cpu":4,"target_mem":16,"target_region":"地域","target_cost":0.0,"tier":"A|A'|B1|B2|C|D","confidence":0.98,"match_reason":"匹配原因","status":"ok|partial|error"}]}
```

**JSON 提取规则**：
- MigraQ 返回的 `data.content` 可能包裹在 ` ```json ... ``` ` 代码块中
- 提取时**移除代码块标记**，取纯 JSON 字符串
- 用 `json.loads()` 验证合法性
- 写入 `/tmp/migraq_export_<session_id前8位>.json`

### 阶段三：生成看板

```bash
python3 {baseDir}/scripts/generate_dashboard.py \
  --input /tmp/migraq_export_<session_id前8位>.json \
  --output /tmp/migration-dashboard.html
```

- 告知用户 HTML 文件路径
- 提示用浏览器打开查看

---

## 🔧 其他使用模式

### 从已有数据文件生成看板

**单文件 JSON 输入：**
```bash
python3 {baseDir}/scripts/generate_dashboard.py --input <file.json>
```

**多目标云对比（多份 MigraQ JSON 合并）：**
```bash
# 将同一批源端资源迁移到多个目标云的对比结果合并为一张看板
python3 {baseDir}/scripts/generate_dashboard.py \
  --input tencent.json aws.json azure.json \
  --output /tmp/multi-cloud-dashboard.html
```

合并规则：相同 `(source_cloud, product, source_spec, source_billing, source_region)` 的条目会自动合并，每个文件的目标云方案作为并列列展示；最低费用目标云自动标注 🥇。

**多源云对比（不同源云迁移到腾讯云）：**
```bash
# 阿里云、AWS 同时迁移到腾讯云
python3 {baseDir}/scripts/generate_dashboard.py \
  --input from-aliyun.json from-aws.json \
  --output /tmp/multi-source-dashboard.html
```

不同 `source_cloud` 的条目直接并排展示，资源卡片 header 会显示来源云标签。

**CSV 输入：**
```bash
python3 {baseDir}/scripts/generate_dashboard.py --input <file.csv> --format csv
```

CSV 格式（首行为列头）：
```csv
product,source_spec,source_cpu,source_mem,source_region,source_billing,source_cost,target_spec,target_cpu,target_mem,target_region,target_cost,tier,confidence,match_reason,status
ECS,ecs.g8a.xlarge,4,16,上海,包年包月,468.00,SA5.XLARGE16,4,16,上海,216.53,A,0.98,精确匹配,ok
```

可在列头行前用注释行声明 meta 信息：
```csv
# source_cloud=阿里云
# target_cloud=腾讯云
# analysis_date=2026-05-08
product,source_spec,...
```

### 演示模式（内置测试数据，无需 MigraQ）

```bash
python3 {baseDir}/scripts/generate_dashboard.py --demo
```

---

## 📊 看板包含的可视化组件

### 1. 顶部仪表盘
- 总资源数 / 匹配成功率 / 总费用节省比例
- 源端月费 vs 目标端月费

### 2. 左右对照卡片（核心）
- 左侧：源端资源（云厂商、规格、CPU/内存、地域、月费）
- 右侧：腾讯云推荐（规格、CPU/内存、地域、月费）
- 中间：匹配等级标签（A/A'/B/C/D）+ 节省金额
- 颜色编码：A 绿色 / B 黄色 / C 橙色 / D 红色

### 3. 费用对比柱状图
- 每种规格的源端/目标端费用并排柱状图（同规格自动合并）

### 4. 匹配等级分布饼图
- 展示 A/B1/B2/C/D 各等级占比

---

## ⚠️ 错误处理

| 场景 | 处理方式 |
|------|---------|
| MigraQ 未安装 | 报错：提示用户安装 MigraQ 技能，或设置 `$MIGRAQ_SKILL_PATH` 环境变量（`check_env.py --locate-migraq` 返回非 0） |
| MigraQ check_env 退出码 2（AK/SK 未配置） | 报错：提示用户配置 `TENCENTCLOUD_SECRET_ID` / `TENCENTCLOUD_SECRET_KEY` 环境变量，并 source ~/.zshrc 生效 |
| MigraQ check_env 退出码 3（网络不通） | 报错：提示检查网络，确保可达 `https://cmg.ai.tencentcloudapi.com` |
| MigraQ check_env 退出码 4（版本过旧） | 报错：提示用户前往 SkillHub 更新 MigraQ 技能后重试（版本过旧时远端 API 行为可能不兼容） |
| MigraQ check_env 含 `update_available: true` | 透传提示给用户："💡 MigraQ 有新版本可用，可前往 SkillHub 更新"，不阻断流程，继续执行 |
| MigraQ 调用失败（AuthError/NetworkError） | 透传 MigraQ 错误，提示检查 AK/SK 和网络 |
| JSON 提取失败（非合法 JSON） | 报错：告知用户 MigraQ 未能输出结构化数据，建议重新发起分析或手动提供 JSON 文件 |
| `generate_dashboard.py` 失败 | 报错：显示 Python 脚本错误信息 |

---

## 🤝 技能协作关系

### 与 MigraQ 的关系
- **MigraQ**：负责数据获取——远端 Agent 调用、资源扫描、选型推荐、TCO 询价
- **本 Skill**：负责数据可视化——将 MigraQ 返回的数据渲染为交互式看板

**互调模式：脚本直调（Python-based skill 标准方式）**

本 Skill 通过以下方式调用 MigraQ：

1. **路径解析**：通过 `check_env.py --locate-migraq` 动态找到 MigraQ 安装路径，不硬编码
2. **预检验证**：调用 `$MIGRAQ_PATH/scripts/check_env.py`，让被调用方自我验证就绪（版本最新 + AK/SK + 网络），这是跨 skill 调用时保证被调用方状态的标准模式
3. **脚本调用**：直接运行 `$MIGRAQ_PATH/scripts/migrateq_sse_api.py` 发起 API 请求

这与 `{{INVOKE_SKILL:name}}` 模板机制不同——后者让 Claude 读取另一个 skill 的 SKILL.md 并执行，适合 Claude 原生 skill 组合；而脚本直调适合 Python 脚本需要跨 skill 调用底层 API 的场景。

如果 MigraQ 安装在非标准位置，设置 `$MIGRAQ_SKILL_PATH` 环境变量即可。

调用 MigraQ 时**必须遵守 MigraQ 转发铁律**：用户原话原样传入，不得改写。

### 与 cvm-ai-doctor 的关系
- **cvm-ai-doctor**：单机系统诊断
- **本 Skill**：云迁移可视化
- 未来计划：cvm-cluster-doctor 将整合两者，提供集群级健康 + 迁移态势感知

---

**最后更新**: 2026-04-28
**版本**: 0.2
**兼容性**: Linux / macOS / Windows（需要 Python 3.7+）
