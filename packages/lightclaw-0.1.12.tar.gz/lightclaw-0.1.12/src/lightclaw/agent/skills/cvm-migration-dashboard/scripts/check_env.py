#!/usr/bin/env python3
"""
Environment verification for cvm-migration-dashboard

Checks:
  1. Python version >= 3.7
  2. MigraQ skill installed (searched across known client directories)
  3. MigraQ core script exists and is executable

Return codes:
  0 = All checks passed, skill ready
  1 = Python version too low (critical, skill cannot run)
  2 = MigraQ skill not found (warning, --demo mode still works)

Usage:
  python3 check_env.py                # full check with output
  python3 check_env.py --quiet        # suppress non-error output
  python3 check_env.py --locate-migraq  # print MigraQ path and exit (0=found, 2=not found)

MigraQ path resolution order:
  1. $MIGRAQ_SKILL_PATH environment variable (explicit override)
  2. ~/.lightclaw/workspace/skills/MigraQ
  3. ~/.lightclaw/skills/MigraQ
  4. ~/.workbuddy/skills/MigraQ
  5. ~/.codebuddy/skills/MigraQ
  6. ~/.agents/skills/MigraQ
"""

import json
import os
import sys
from pathlib import Path


def check_python_version():
    """Check Python >= 3.7."""
    major, minor = sys.version_info.major, sys.version_info.minor
    if major < 3 or (major == 3 and minor < 7):
        return False, f"Python 3.7+ required, found {major}.{minor}"
    return True, f"Python {major}.{minor}"


def find_migraq():
    """Locate MigraQ skill directory.

    Resolution order:
      1. $MIGRAQ_SKILL_PATH env var (explicit override, highest priority)
      2. Standard client skill directories (workbuddy → lightclaw → codebuddy → agents)

    Returns (found: bool, path: str|None).
    """
    # 1. Explicit override
    env_path = os.environ.get("MIGRAQ_SKILL_PATH", "").strip()
    if env_path:
        p = Path(env_path)
        if p.exists():
            return True, str(p)
        # env var set but path invalid — fall through to auto-search

    # 2. Standard search order (add new clients here)
    candidates = [
        Path.home() / ".lightclaw" / "workspace" / "skills" / "MigraQ",
        Path.home() / ".lightclaw" / "skills" / "MigraQ",
        Path.home() / ".workbuddy" / "skills" / "MigraQ",
        Path.home() / ".codebuddy" / "skills" / "MigraQ",
        Path.home() / ".agents" / "skills" / "MigraQ",
    ]
    for path in candidates:
        if path.exists():
            return True, str(path)
    return False, None


def check_migraq_script(migraq_path):
    """Check that the MigraQ SSE script exists."""
    script = Path(migraq_path) / "scripts" / "migrateq_sse_api.py"
    if not script.exists():
        return False, f"MigraQ script not found: {script}"
    return True, str(script)


def main():
    quiet = "--quiet" in sys.argv

    # --- Special mode: --locate-migraq ---
    # Prints the resolved MigraQ path (or nothing) then exits.
    # Exit 0 = found, exit 2 = not found.
    if "--locate-migraq" in sys.argv:
        found, migraq_path = find_migraq()
        if found:
            print(migraq_path)
            sys.exit(0)
        else:
            sys.exit(2)

    issues_critical = []
    issues_warning = []
    info = {}

    # --- Check 1: Python version ---
    ok, msg = check_python_version()
    if ok:
        info["python"] = msg
    else:
        issues_critical.append(msg)

    # --- Check 2: MigraQ installation ---
    found, migraq_path = find_migraq()
    if found:
        info["migraq_path"] = migraq_path
        # --- Check 3: MigraQ core script ---
        ok, msg = check_migraq_script(migraq_path)
        if ok:
            info["migraq_script"] = msg
        else:
            issues_warning.append(msg)
    else:
        issues_warning.append(
            "MigraQ skill not found in any known location "
            "(searched: ~/.lightclaw/workspace/skills/MigraQ, ~/.lightclaw/skills/MigraQ, "
            "~/.workbuddy/skills/MigraQ, ~/.codebuddy/skills/MigraQ, ~/.agents/skills/MigraQ). "
            "Set $MIGRAQ_SKILL_PATH to override. Linked mode unavailable; --demo mode still works."
        )

    # --- Build summary ---
    if issues_critical:
        summary = {
            "status": "error",
            "issues": issues_critical,
        }
        if not quiet:
            for issue in issues_critical:
                print(f"[ERROR] {issue}", file=sys.stderr)
        print(json.dumps(summary))
        sys.exit(1)

    if issues_warning:
        summary = {
            "status": "ready",
            "warnings": issues_warning,
        }
        if not quiet:
            for w in issues_warning:
                print(f"[WARN] {w}", file=sys.stderr)
        print(json.dumps(summary))
        sys.exit(2)

    summary = {"status": "ready"}
    if not quiet:
        for key, val in info.items():
            print(f"[OK] {key}: {val}")
    print(json.dumps(summary))
    sys.exit(0)


if __name__ == "__main__":
    main()
