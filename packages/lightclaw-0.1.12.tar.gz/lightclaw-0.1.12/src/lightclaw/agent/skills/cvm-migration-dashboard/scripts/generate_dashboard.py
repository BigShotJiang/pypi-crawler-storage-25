#!/usr/bin/env python3
"""
CVM Migration Dashboard Generator

将 MigraQ 的迁移数据转化为交互式可视化看板。
支持：内置演示数据 / JSON 文件输入 / CSV 文件输入 / 多文件合并（多云对比）

用法:
    python3 generate_dashboard.py --demo                             # 演示模式（双目标云）
    python3 generate_dashboard.py --input data.json                  # 单 JSON 输入
    python3 generate_dashboard.py --input data.csv --format csv      # CSV 输入
    python3 generate_dashboard.py --input tc.json aws.json           # 多文件合并（多目标云对比）

输出:
    migration-dashboard.html（当前目录）
"""

import argparse
import csv
import json
import os
import sys
from datetime import datetime
from pathlib import Path

# ============== 固定色板 ==============
# 各云厂商品牌色（柱状图 / 卡片列 header 背景色）
CLOUD_COLORS = {
    "腾讯云":       "#0052d9",  # 腾讯蓝
    "AWS":          "#FF9900",  # Amazon 官方橙黄
    "Azure":        "#0078D4",  # 微软 Azure 蓝
    "GCP":          "#4285F4",  # Google 蓝
    "Google Cloud": "#4285F4",  # 别名
    "华为云":       "#CF0A2C",  # 华为红
    "阿里云":       "#FF6A00",  # 阿里云橙
}
# 未知云厂商统一使用灰色
_FALLBACK_COLOR = "#94a3b8"

# ============== 内置演示数据（双目标云：腾讯云 + AWS）==============

# Demo 场景：阿里云 + AWS 同时迁移到腾讯云
# 每条资源只有一个 target（腾讯云），source_cloud 不同表示来自不同源端
DEMO_DATA = {
    "meta": {
        "source_clouds": ["阿里云", "AWS"],
        "target_cloud": "腾讯云",
        "target_clouds": ["腾讯云"],
        "analysis_date": "2026-05-08",
        "total_source_cost": 0.0,      # 运行时计算
        "total_target_cost": 0.0,
        "total_savings": 0.0,
        "savings_pct": 0.0,
        "cloud_totals": {},
    },
    "resources": [
        # ── 来自阿里云的资源 ──────────────────────────────
        {
            "id": 1, "source_cloud": "阿里云",
            "product": "ECS", "source_spec": "ecs.g8a.xlarge",
            "source_cpu": 4, "source_mem": 16, "source_region": "上海",
            "source_billing": "包年包月", "source_cost": 468.00,
            "targets": [
                {"cloud": "腾讯云", "spec": "SA5.XLARGE16", "cpu": 4, "mem": 16,
                 "region": "上海", "cost": 216.53, "tier": "A", "confidence": 0.98,
                 "match_reason": "精确匹配", "status": "ok"},
            ]
        },
        {
            "id": 2, "source_cloud": "阿里云",
            "product": "ECS", "source_spec": "ecs.g8a.4xlarge",
            "source_cpu": 16, "source_mem": 64, "source_region": "上海",
            "source_billing": "包年包月", "source_cost": 1872.00,
            "targets": [
                {"cloud": "腾讯云", "spec": "SA5.4XLARGE64", "cpu": 16, "mem": 64,
                 "region": "上海", "cost": 866.13, "tier": "A", "confidence": 0.98,
                 "match_reason": "精确匹配", "status": "ok"},
            ]
        },
        {
            "id": 3, "source_cloud": "阿里云",
            "product": "ECS", "source_spec": "ecs.c8a.4xlarge",
            "source_cpu": 16, "source_mem": 32, "source_region": "深圳",
            "source_billing": "包年包月", "source_cost": 1248.00,
            "targets": [
                {"cloud": "腾讯云", "spec": "SA5.4XLARGE32", "cpu": 16, "mem": 32,
                 "region": "广州", "cost": 612.27, "tier": "A", "confidence": 0.95,
                 "match_reason": "精确匹配（深圳→广州）", "status": "ok"},
            ]
        },
        {
            "id": 4, "source_cloud": "阿里云",
            "product": "ECS", "source_spec": "ecs.r8a.2xlarge",
            "source_cpu": 8, "source_mem": 64, "source_region": "北京",
            "source_billing": "按量付费", "source_cost": 1560.00,
            "targets": [
                {"cloud": "腾讯云", "spec": "—", "cpu": 0, "mem": 0,
                 "region": "北京", "cost": 0, "tier": "D", "confidence": 0,
                 "match_reason": "目标端询价失败（内存型按量暂无对应）", "status": "error"},
            ]
        },
        {
            "id": 5, "source_cloud": "阿里云",
            "product": "ECS", "source_spec": "ecs.g8a.2xlarge",
            "source_cpu": 8, "source_mem": 32, "source_region": "新加坡",
            "source_billing": "包年包月", "source_cost": 1092.00,
            "targets": [
                {"cloud": "腾讯云", "spec": "SA5.2XLARGE32", "cpu": 8, "mem": 32,
                 "region": "新加坡", "cost": 520.47, "tier": "A", "confidence": 0.96,
                 "match_reason": "精确匹配", "status": "ok"},
            ]
        },
        {
            "id": 6, "source_cloud": "阿里云",
            "product": "MySQL", "source_spec": "mysql.n4.2xlarge.2c",
            "source_cpu": 8, "source_mem": 32, "source_region": "上海",
            "source_billing": "包年包月", "source_cost": 960.00,
            "targets": [
                {"cloud": "腾讯云", "spec": "CDB 8C32G", "cpu": 8, "mem": 32,
                 "region": "上海", "cost": 0, "tier": "B1", "confidence": 0.80,
                 "match_reason": "规格匹配，询价暂未覆盖", "status": "partial"},
            ]
        },
        {
            "id": 7, "source_cloud": "阿里云",
            "product": "MySQL", "source_spec": "mysql.n2.xlarge.1",
            "source_cpu": 4, "source_mem": 8, "source_region": "深圳",
            "source_billing": "包年包月", "source_cost": 380.90,
            "targets": [
                {"cloud": "腾讯云", "spec": "CDB 4C8G", "cpu": 4, "mem": 8,
                 "region": "广州", "cost": 0, "tier": "B1", "confidence": 0.80,
                 "match_reason": "规格匹配，询价暂未覆盖", "status": "partial"},
            ]
        },
        {
            "id": 8, "source_cloud": "阿里云",
            "product": "Redis", "source_spec": "redis.master.4xlarge",
            "source_cpu": 0, "source_mem": 32, "source_region": "上海",
            "source_billing": "包年包月", "source_cost": 686.00,
            "targets": [
                {"cloud": "腾讯云", "spec": "—", "cpu": 0, "mem": 32,
                 "region": "上海", "cost": 0, "tier": "D", "confidence": 0,
                 "match_reason": "目标端询价失败", "status": "error"},
            ]
        },
        # ── 来自 AWS 的资源 ───────────────────────────────
        {
            "id": 9, "source_cloud": "AWS",
            "product": "ECS", "source_spec": "m6a.2xlarge",
            "source_cpu": 8, "source_mem": 32, "source_region": "ap-east-1",
            "source_billing": "按量付费", "source_cost": 571.20,
            "targets": [
                {"cloud": "腾讯云", "spec": "SA5.2XLARGE32", "cpu": 8, "mem": 32,
                 "region": "上海", "cost": 433.07, "tier": "A", "confidence": 0.96,
                 "match_reason": "精确匹配", "status": "ok"},
            ]
        },
        {
            "id": 10, "source_cloud": "AWS",
            "product": "ECS", "source_spec": "c6a.4xlarge",
            "source_cpu": 16, "source_mem": 32, "source_region": "ap-east-1",
            "source_billing": "按量付费", "source_cost": 820.00,
            "targets": [
                {"cloud": "腾讯云", "spec": "SA5.4XLARGE32", "cpu": 16, "mem": 32,
                 "region": "上海", "cost": 612.27, "tier": "A", "confidence": 0.95,
                 "match_reason": "精确匹配", "status": "ok"},
            ]
        },
        {
            "id": 11, "source_cloud": "AWS",
            "product": "MySQL", "source_spec": "db.m6g.2xlarge",
            "source_cpu": 8, "source_mem": 32, "source_region": "ap-east-1",
            "source_billing": "按量付费", "source_cost": 820.00,
            "targets": [
                {"cloud": "腾讯云", "spec": "CDB 8C32G", "cpu": 8, "mem": 32,
                 "region": "上海", "cost": 0, "tier": "B1", "confidence": 0.82,
                 "match_reason": "规格匹配，询价暂未覆盖", "status": "partial"},
            ]
        },
        {
            "id": 12, "source_cloud": "AWS",
            "product": "Redis", "source_spec": "cache.r6g.xlarge",
            "source_cpu": 0, "source_mem": 32, "source_region": "ap-east-1",
            "source_billing": "按量付费", "source_cost": 390.00,
            "targets": [
                {"cloud": "腾讯云", "spec": "Redis 32G 主从版", "cpu": 0, "mem": 32,
                 "region": "上海", "cost": 286.00, "tier": "A", "confidence": 0.91,
                 "match_reason": "内存匹配", "status": "ok"},
            ]
        },
    ],
}

# 计算 demo meta 汇总
def _calc_demo_meta():
    resources = DEMO_DATA["resources"]
    total_source = sum(r["source_cost"] for r in resources)
    DEMO_DATA["meta"]["total_source_cost"] = total_source

    cloud_totals = {}
    for r in resources:
        for t in r["targets"]:
            cloud = t["cloud"]
            if cloud not in cloud_totals:
                cloud_totals[cloud] = {"total_cost": 0.0, "savings": 0.0}
            cloud_totals[cloud]["total_cost"] += t["cost"]
            cloud_totals[cloud]["savings"] += r["source_cost"] - t["cost"]

    for cloud, ct in cloud_totals.items():
        ct["savings_pct"] = round(ct["savings"] / total_source * 100, 1) if total_source > 0 else 0.0

    DEMO_DATA["meta"]["cloud_totals"] = cloud_totals
    best_cloud = min(cloud_totals, key=lambda c: cloud_totals[c]["total_cost"])
    best = cloud_totals[best_cloud]
    DEMO_DATA["meta"]["total_target_cost"] = best["total_cost"]
    DEMO_DATA["meta"]["total_savings"] = best["savings"]
    DEMO_DATA["meta"]["savings_pct"] = best["savings_pct"]

_calc_demo_meta()


# ============== 向下兼容：老格式转换 ==============

def _normalize_resource(r: dict, source_cloud: str, target_cloud: str) -> dict:
    """将老格式（target_spec/target_cost/... 平铺）转为新格式（targets[]）。
    若已是新格式则补充 source_cloud 后直接返回。
    """
    r = dict(r)  # 浅拷贝，不修改原始数据
    if "targets" in r:
        if "source_cloud" not in r:
            r["source_cloud"] = source_cloud
        return r
    # 老格式 → 新格式
    r["source_cloud"] = r.get("source_cloud", source_cloud)
    r["targets"] = [{
        "cloud":        target_cloud,
        "spec":         r.pop("target_spec", "—"),
        "cpu":          r.pop("target_cpu", 0),
        "mem":          r.pop("target_mem", 0),
        "region":       r.pop("target_region", ""),
        "cost":         r.pop("target_cost", 0.0),
        "tier":         r.pop("tier", "D"),
        "confidence":   r.pop("confidence", 0.0),
        "match_reason": r.pop("match_reason", ""),
        "status":       r.pop("status", "error"),
    }]
    return r


# ============== 数据加载 ==============

def _load_single_json(path: Path) -> dict:
    with open(path, "r", encoding="utf-8") as f:
        return json.load(f)


def _load_csv(path: Path) -> dict:
    """从 CSV 文件加载迁移数据（老格式，单目标云）。

    CSV 格式（首行为列头）：
      product, source_spec, source_cpu, source_mem, source_region, source_billing,
      source_cost, target_spec, target_cpu, target_mem, target_region, target_cost,
      tier, confidence, match_reason, status

    可选的 meta 信息通过注释行（以 # 开头）声明，例如：
      # source_cloud=阿里云
      # target_cloud=腾讯云
      # analysis_date=2026-05-08
    注释行必须在列头行之前。
    """
    meta_overrides = {}
    header_line = None
    data_lines = []

    with open(path, "r", encoding="utf-8") as f:
        for line in f:
            stripped = line.strip()
            if not stripped:
                continue
            if stripped.startswith("#"):
                comment = stripped.lstrip("#").strip()
                if "=" in comment:
                    k, _, v = comment.partition("=")
                    meta_overrides[k.strip()] = v.strip()
            elif header_line is None:
                header_line = stripped
            else:
                data_lines.append(stripped)

    if header_line is None:
        print("[ERROR] CSV 文件为空或缺少列头行", file=sys.stderr)
        sys.exit(1)

    reader = csv.DictReader([header_line] + data_lines)
    resources = []
    for i, row in enumerate(reader, start=1):
        try:
            resource = {
                "id": i,
                "product": row.get("product", "ECS").strip(),
                "source_spec": row.get("source_spec", "").strip(),
                "source_cpu": int(row.get("source_cpu", 0) or 0),
                "source_mem": int(row.get("source_mem", 0) or 0),
                "source_region": row.get("source_region", "").strip(),
                "source_billing": row.get("source_billing", "").strip(),
                "source_cost": float(row.get("source_cost", 0) or 0),
                "target_spec": row.get("target_spec", "—").strip() or "—",
                "target_cpu": int(row.get("target_cpu", 0) or 0),
                "target_mem": int(row.get("target_mem", 0) or 0),
                "target_region": row.get("target_region", "").strip(),
                "target_cost": float(row.get("target_cost", 0) or 0),
                "tier": row.get("tier", "D").strip(),
                "confidence": float(row.get("confidence", 0) or 0),
                "match_reason": row.get("match_reason", "").strip(),
                "status": row.get("status", "error").strip(),
            }
        except (ValueError, KeyError) as e:
            print(f"[ERROR] CSV 第 {i + 1} 行数据异常: {e}", file=sys.stderr)
            sys.exit(1)
        resources.append(resource)

    if not resources:
        print("[ERROR] CSV 文件中没有有效数据行", file=sys.stderr)
        sys.exit(1)

    total_source = sum(r["source_cost"] for r in resources)
    total_target = sum(r["target_cost"] for r in resources)
    total_savings = total_source - total_target
    savings_pct = round(total_savings / total_source * 100, 1) if total_source > 0 else 0.0

    from datetime import date
    meta = {
        "source_cloud": meta_overrides.get("source_cloud", "源云"),
        "target_cloud": meta_overrides.get("target_cloud", "腾讯云"),
        "analysis_date": meta_overrides.get("analysis_date", date.today().isoformat()),
        "total_source_cost": total_source,
        "total_target_cost": total_target,
        "total_savings": total_savings,
        "savings_pct": savings_pct,
    }
    return {"meta": meta, "resources": resources}


def _merge_inputs(files: list, fmt: str) -> dict:
    """加载并合并多个输入文件。

    多目标云合并逻辑：
      - 相同 source_cloud 的文件：按 (source_cloud, product, source_spec, source_billing, source_region)
        匹配，将各文件的 targets 合并到同一资源条目中。
    多源云逻辑：
      - 不同 source_cloud 的文件：直接拼接，各资源保留各自的 source_cloud 标签。
    """
    all_data = []
    for f in files:
        p = Path(f)
        if not p.exists():
            print(f"[ERROR] 文件不存在: {f}", file=sys.stderr)
            sys.exit(1)
        raw = _load_single_json(p) if fmt == "json" else _load_csv(p)
        all_data.append(raw)

    if len(all_data) == 1:
        # 单文件：只做格式归一化
        d = all_data[0]
        meta = d["meta"]
        sc = meta.get("source_cloud", "源云")
        tc = meta.get("target_cloud", "腾讯云")
        d["resources"] = [_normalize_resource(r, sc, tc) for r in d["resources"]]
        _enrich_meta(d)
        return d

    # 多文件合并
    # key → merged resource dict
    merged_map: dict = {}
    # 维护出现顺序
    merged_order: list = []

    total_source_global = None  # 用第一个文件的源端费用

    for idx, d in enumerate(all_data):
        meta = d["meta"]
        sc = meta.get("source_cloud", "源云")
        tc = meta.get("target_cloud", "腾讯云")
        for r in d["resources"]:
            r = _normalize_resource(r, sc, tc)
            key = (r["source_cloud"], r["product"], r["source_spec"],
                   r["source_billing"], r["source_region"])
            if key not in merged_map:
                merged_map[key] = dict(r)
                merged_order.append(key)
                if total_source_global is None:
                    pass  # 每个资源单独计算
            else:
                # 追加 targets（跳过已有相同 cloud 的 target）
                existing_clouds = {t["cloud"] for t in merged_map[key]["targets"]}
                for t in r["targets"]:
                    if t["cloud"] not in existing_clouds:
                        merged_map[key]["targets"].append(t)
                        existing_clouds.add(t["cloud"])

    resources = [merged_map[k] for k in merged_order]

    # 重新 ID
    for i, r in enumerate(resources, start=1):
        r["id"] = i

    # 合并 meta（取第一个文件的 source_cloud / analysis_date）
    first_meta = all_data[0]["meta"]
    all_source_clouds = list(dict.fromkeys(
        d["meta"].get("source_cloud", "源云") for d in all_data
    ))
    all_target_clouds = list(dict.fromkeys(
        t["cloud"]
        for r in resources
        for t in r["targets"]
    ))

    combined = {
        "source_cloud": all_source_clouds[0] if len(all_source_clouds) == 1 else " / ".join(all_source_clouds),
        "source_clouds": all_source_clouds,
        "target_cloud": all_target_clouds[0] if len(all_target_clouds) == 1 else " / ".join(all_target_clouds),
        "target_clouds": all_target_clouds,
        "analysis_date": first_meta.get("analysis_date", datetime.now().strftime("%Y-%m-%d")),
        "total_source_cost": 0.0,
        "total_target_cost": 0.0,
        "total_savings": 0.0,
        "savings_pct": 0.0,
        "cloud_totals": {},
    }
    data = {"meta": combined, "resources": resources}
    _enrich_meta(data)
    return data


def _enrich_meta(data: dict):
    """根据 resources 重新计算 meta 汇总字段（cloud_totals、total_* 等）。"""
    meta = data["meta"]
    resources = data["resources"]

    total_source = sum(r["source_cost"] for r in resources)
    meta["total_source_cost"] = total_source

    cloud_totals: dict = {}
    for r in resources:
        for t in r["targets"]:
            cloud = t["cloud"]
            if cloud not in cloud_totals:
                cloud_totals[cloud] = {"total_cost": 0.0, "savings": 0.0, "a_count": 0, "total_count": 0}
            ct = cloud_totals[cloud]
            ct["total_cost"] += t["cost"]
            ct["savings"] += r["source_cost"] - t["cost"]
            ct["total_count"] += 1
            if t.get("tier", "D") in ("A", "A'"):
                ct["a_count"] += 1

    for ct in cloud_totals.values():
        ct["savings_pct"] = round(ct["savings"] / total_source * 100, 1) if total_source > 0 else 0.0
        ct["a_rate"] = round(ct["a_count"] / ct["total_count"] * 100) if ct["total_count"] > 0 else 0

    meta["cloud_totals"] = cloud_totals

    # total_target_cost / savings 取费用最低的目标云（单云时就是它自己）
    if cloud_totals:
        best = min(cloud_totals, key=lambda c: cloud_totals[c]["total_cost"])
        meta["total_target_cost"] = cloud_totals[best]["total_cost"]
        meta["total_savings"] = cloud_totals[best]["savings"]
        meta["savings_pct"] = cloud_totals[best]["savings_pct"]

    # 确保 source_clouds / target_clouds 字段存在
    if "source_clouds" not in meta:
        meta["source_clouds"] = [meta.get("source_cloud", "源云")]
    if "target_clouds" not in meta:
        meta["target_clouds"] = list(cloud_totals.keys())


def load_data(input_paths=None, fmt="json"):
    """加载迁移数据。input_paths 可为 None（demo）、str（单文件）或 list（多文件）。"""
    if input_paths is None:
        return DEMO_DATA
    if isinstance(input_paths, str):
        input_paths = [input_paths]
    return _merge_inputs(input_paths, fmt)


# ============== 渲染辅助 ==============

def _cloud_color(cloud: str, color_index: int = 0) -> str:
    """返回云厂商对应的品牌色，未知云统一使用灰色。"""
    return CLOUD_COLORS.get(cloud, _FALLBACK_COLOR)


def merge_resources(resources):
    """将同规格资源合并。合并键 = source_cloud + product + source_spec + source_billing + tier(首个)。"""
    groups = {}
    order = []
    for r in resources:
        first_tier = r["targets"][0]["tier"] if r.get("targets") else r.get("tier", "D")
        key = (r.get("source_cloud", ""), r["product"], r["source_spec"], r["source_billing"], first_tier)
        sc = r.get("source_cloud", "")
        if key not in groups:
            groups[key] = {
                **r,
                "count": 1,
                "total_source_cost": r["source_cost"],
                "regions": [r["source_region"]],
                "ids": [r["id"]],
                # targets 保留原列表结构；按 cloud 累计 total_target_cost
                "targets_total": {t["cloud"]: t["cost"] for t in r.get("targets", [])},
                # 按源云分别统计源端费用（用于堆叠柱状图）
                "source_cost_by_cloud": {sc: r["source_cost"]},
            }
            order.append(key)
        else:
            g = groups[key]
            g["count"] += 1
            g["total_source_cost"] += r["source_cost"]
            g["ids"].append(r["id"])
            if r["source_region"] not in g["regions"]:
                g["regions"].append(r["source_region"])
            for t in r.get("targets", []):
                g["targets_total"][t["cloud"]] = g["targets_total"].get(t["cloud"], 0) + t["cost"]
            g["source_cost_by_cloud"][sc] = g["source_cost_by_cloud"].get(sc, 0) + r["source_cost"]
    return [groups[k] for k in order]


# ============== HTML 生成 ==============

def generate_html(data: dict, output_path: str = "migration-dashboard.html"):
    """生成交互式 HTML 看板（支持多云对比）。"""
    meta = data["meta"]
    resources = data["resources"]

    # 确保 meta 汇总字段完整
    _enrich_meta(data)

    merged = merge_resources(resources)
    total = len(resources)
    merged_count = len(merged)

    target_clouds = meta.get("target_clouds", [meta.get("target_cloud", "腾讯云")])
    source_clouds = meta.get("source_clouds", [meta.get("source_cloud", "源云")])
    is_multi_cloud = len(target_clouds) > 1
    is_multi_source = len(source_clouds) > 1
    cloud_totals = meta.get("cloud_totals", {})

    # 云 → 颜色映射（按 target_clouds 顺序建立）
    cloud_color_map = {c: _cloud_color(c, i) for i, c in enumerate(target_clouds)}
    # 源端色：多源云时用中性灰，单源云时用该云品牌色
    source_color = "#94a3b8" if is_multi_source else CLOUD_COLORS.get(meta.get("source_cloud", ""), "#94a3b8")

    # 匹配等级统计（按原始台数，取每个资源第一个 target 的 tier）
    tier_colors = {"A": "#10b981", "A'": "#34d399", "B1": "#f59e0b", "B2": "#f97316", "C": "#ef4444", "D": "#6b7280"}
    tier_bg = {"A": "#ecfdf5", "A'": "#ecfdf5", "B1": "#fffbeb", "B2": "#fff7ed", "C": "#fef2f2", "D": "#f3f4f6"}
    product_icons = {"ECS": "🖥️", "MySQL": "🗄️", "Redis": "⚡", "CVM": "🖥️"}

    # Tier 统计（多云时按各云分别统计）
    tier_by_cloud: dict = {c: {} for c in target_clouds}
    for r in resources:
        for t in r.get("targets", []):
            cloud = t["cloud"]
            if cloud not in tier_by_cloud:
                tier_by_cloud[cloud] = {}
            tier = t.get("tier", "D")
            tier_by_cloud[cloud][tier] = tier_by_cloud[cloud].get(tier, 0) + 1

    # 产品分布
    product_counts: dict = {}
    for r in resources:
        p = r["product"]
        product_counts[p] = product_counts.get(p, 0) + 1

    prod_desc = " / ".join([f"{k} {v}台" for k, v in product_counts.items()])

    # ============== 资源卡片 ==============
    cards_html = ""
    for g in merged:
        count = g["count"]
        targets = g.get("targets", [])
        regions_str = " / ".join(g["regions"])
        source_cloud_label = g.get("source_cloud", meta.get("source_cloud", ""))
        icon = product_icons.get(g["product"], "📦")

        # 找最便宜的目标云（cost > 0）
        cheapest_cloud = None
        min_cost = float("inf")
        for t in targets:
            if t["cost"] > 0 and t["cost"] < min_cost:
                min_cost = t["cost"]
                cheapest_cloud = t["cloud"]

        # 用第一个 target 的 tier 决定卡片整体颜色
        first_tier = targets[0]["tier"] if targets else "D"
        tier_color = tier_colors.get(first_tier, "#6b7280")
        tier_background = tier_bg.get(first_tier, "#f3f4f6")

        # 数量角标
        if count > 1:
            count_badge = f'<span style="background:linear-gradient(135deg,#0052d9,#00a3ff);color:#fff;padding:4px 14px;border-radius:14px;font-size:14px;font-weight:800;letter-spacing:0.5px;box-shadow:0 2px 6px rgba(0,82,217,0.3);">{count} 台</span>'
        else:
            count_badge = '<span style="background:#e2e8f0;color:#64748b;padding:4px 14px;border-radius:14px;font-size:14px;font-weight:800;">1 台</span>'

        # 源端标签（多源云时显示）
        source_label_html = ""
        if is_multi_source and source_cloud_label:
            sc_color = CLOUD_COLORS.get(source_cloud_label, "#64748b")
            source_label_html = f'<span style="background:{sc_color}20;color:{sc_color};padding:2px 8px;border-radius:10px;font-size:11px;border:1px solid {sc_color}40;">{source_cloud_label}</span>'

        # 卡片 header 右侧 tier（取第一个 target 的 tier，多云时不展示单一 tier）
        tier_display = ""
        if not is_multi_cloud:
            tier_display = f'''
              <span style="background:{tier_background};color:{tier_color};padding:3px 10px;border-radius:6px;font-weight:700;font-size:13px;border:1px solid {tier_color}30;">
                Tier {first_tier}
              </span>
              {"" if (targets and targets[0].get("confidence", 0) == 0) else f'<span style="font-size:11px;color:#999;">置信度 {targets[0].get("confidence", 0):.0%}</span>'}
            '''

        # 源端列
        source_col = f'''
          <div style="text-align:center;padding:0 16px;min-width:160px;">
            <div style="font-size:11px;color:#999;text-transform:uppercase;letter-spacing:1px;margin-bottom:8px;">
              ☁️ {source_cloud_label or meta.get("source_cloud", "源云")}
            </div>
            <div style="font-size:17px;font-weight:700;color:#333;">{g["source_spec"]}</div>
            <div style="margin-top:6px;color:#555;">
              {"" if g["source_cpu"] == 0 else f'{g["source_cpu"]}C'}{g["source_mem"]}G &nbsp;·&nbsp; {regions_str}
            </div>
            <div style="margin-top:4px;font-size:11px;color:#999;">{g["source_billing"]}</div>
            {"" if count <= 1 else f'<div style="margin-top:8px;background:#f1f5f9;border-radius:8px;padding:6px 12px;display:inline-block;"><span style="font-size:20px;font-weight:800;color:#0052d9;">{count}</span><span style="font-size:12px;color:#64748b;"> 台同规格</span></div>'}
            <div style="margin-top:10px;">
              <span style="font-size:14px;color:#999;">单台</span>
              <span style="font-size:20px;font-weight:700;color:{source_color};"> ¥{g["source_cost"]:,.2f}</span>
              <span style="font-size:12px;color:#999;">/月</span>
            </div>
            {"" if count <= 1 else f'<div style="margin-top:4px;font-size:13px;color:{source_color};font-weight:600;">合计 ¥{g["total_source_cost"]:,.2f}/月</div>'}
          </div>
        '''

        # 箭头列
        arrow_col = f'''
          <div style="display:flex;flex-direction:column;align-items:center;justify-content:center;
               padding:0 10px;border-left:1px dashed #e5e7eb;border-right:1px dashed #e5e7eb;min-width:36px;">
            <div style="font-size:24px;color:#cbd5e1;">→</div>
          </div>
        '''

        # 各目标云列
        target_cols_html = ""
        for t in targets:
            cloud = t["cloud"]
            col_color = cloud_color_map.get(cloud, "#0052d9")
            is_best = (cloud == cheapest_cloud)
            best_badge = ' 🥇' if is_best else ''
            total_target_cost = g["targets_total"].get(cloud, 0)
            total_savings = g["total_source_cost"] - total_target_cost if total_target_cost > 0 else 0
            unit_savings = g["source_cost"] - t["cost"] if t["cost"] > 0 else 0
            savings_pct = (total_savings / g["total_source_cost"] * 100) if g["total_source_cost"] > 0 and total_savings > 0 else 0

            tier_badge = f'<span style="background:{tier_bg.get(t["tier"],"#f3f4f6")};color:{tier_colors.get(t["tier"],"#6b7280")};padding:2px 6px;border-radius:4px;font-size:11px;font-weight:700;">T{t["tier"]}</span>'

            if t["status"] == "ok":
                cpu_label = f'{t["cpu"]}C' if t["cpu"] != 0 else ""
                subtotal_html = f'<div style="font-size:12px;color:{col_color};margin-top:3px;">合计 ¥{total_target_cost:,.2f}/月</div>' if count > 1 else ""
                savings_html = (f'<div style="background:#ecfdf5;border-radius:6px;padding:5px 8px;margin-top:6px;">'
                                f'<span style="font-size:11px;color:#059669;">节省 ¥{total_savings:,.0f} ({savings_pct:.0f}%)</span></div>'
                                if total_savings > 0 else "")
                conf_html = (f'<span style="font-size:10px;color:#999;">{t["confidence"]:.0%}</span>'
                             if t.get("confidence", 0) != 0 else "")
                target_content = f'''
                  <div style="font-size:16px;font-weight:700;color:{col_color};">{t["spec"]}</div>
                  <div style="margin-top:5px;color:#555;font-size:13px;">
                    {cpu_label}{t["mem"]}G &nbsp;·&nbsp; {t["region"]}
                  </div>
                  <div style="margin-top:8px;">
                    <span style="font-size:13px;color:#999;">单台</span>
                    <span style="font-size:18px;font-weight:700;color:{col_color};"> ¥{t["cost"]:,.2f}</span>
                    <span style="font-size:11px;color:#999;">/月</span>
                  </div>
                  {subtotal_html}
                  {savings_html}
                  <div style="margin-top:6px;">{tier_badge} {conf_html}</div>
                '''
            elif t["status"] == "partial":
                target_content = f'''
                  <div style="font-size:16px;font-weight:700;color:#d97706;">{t["spec"]}</div>
                  <div style="margin-top:5px;color:#555;font-size:13px;">
                    {"" if t["cpu"] == 0 else f'{t["cpu"]}C'}{t["mem"]}G &nbsp;·&nbsp; {t["region"]}
                  </div>
                  <div style="margin-top:8px;font-size:13px;color:#d97706;">询价暂未覆盖</div>
                  <div style="margin-top:6px;">{tier_badge}</div>
                '''
            else:
                target_content = f'''
                  <div style="font-size:14px;color:#999;margin-top:12px;">暂无匹配</div>
                  <div style="margin-top:6px;font-size:11px;color:#bbb;">{t.get("match_reason","")[:30]}</div>
                  <div style="margin-top:6px;">{tier_badge}</div>
                '''

            border_style = f"border:2px solid {col_color}40;" if is_best else "border:1px solid #f1f5f9;"
            target_cols_html += f'''
              <div style="text-align:center;padding:0 14px;min-width:150px;border-radius:10px;{border_style}">
                <div style="font-size:11px;font-weight:600;color:{col_color};text-transform:uppercase;
                     letter-spacing:1px;margin-bottom:8px;padding-bottom:6px;border-bottom:2px solid {col_color}20;">
                  🔵 {cloud}{best_badge}
                </div>
                {target_content}
              </div>
            '''

        # 拼装卡片
        n_targets = len(targets)
        grid_cols = f"1fr auto {'1fr ' * n_targets}".strip()
        cards_html += f'''
        <div style="background:#fff;border-radius:16px;box-shadow:0 2px 12px rgba(0,0,0,0.06);
             margin-bottom:20px;overflow:hidden;border:1px solid #e5e7eb;">
          <!-- 卡片头部 -->
          <div style="display:flex;justify-content:space-between;align-items:center;
               padding:12px 20px;background:linear-gradient(135deg,#f8fafc,#f1f5f9);border-bottom:1px solid #e5e7eb;">
            <div style="display:flex;align-items:center;gap:8px;">
              <span style="font-size:20px;">{icon}</span>
              <span style="font-weight:600;color:#1e293b;">{g["product"]}</span>
              {count_badge}
              {source_label_html}
            </div>
            <div style="display:flex;align-items:center;gap:6px;">
              {tier_display}
            </div>
          </div>
          <!-- 卡片主体 -->
          <div style="display:grid;grid-template-columns:{grid_cols};gap:0;padding:20px;align-items:start;">
            {source_col}
            {arrow_col}
            {target_cols_html}
          </div>
        </div>
        '''

    # ============== 图表数据 ==============
    bar_labels = json.dumps(
        [f"{g['product']} {g['source_spec'][:12]}{'×'+str(g['count']) if g['count']>1 else ''}" for g in merged],
        ensure_ascii=False
    )
    bar_source_data = json.dumps([g["total_source_cost"] for g in merged])

    # ============== 柱状图 datasets（堆叠模式）==============
    # 多源云：源端按云分拆，各自堆叠；目标云单独一组
    # 单源云：源端一个 dataset，目标云一个 dataset（退化为并排）
    bar_datasets_list = []

    if is_multi_source:
        # 源端：每个源云一个 dataset，stack="source"
        for sc in source_clouds:
            col = CLOUD_COLORS.get(sc, _FALLBACK_COLOR)
            sc_data = json.dumps([g["source_cost_by_cloud"].get(sc, 0) for g in merged])
            bar_datasets_list.append(
                f'{{ label: "{sc}（源）", data: {sc_data}, '
                f'backgroundColor: "{col}BF", stack: "source", borderRadius: 3 }}'
            )
        # 目标云：每个目标云单独 dataset，stack="target-<cloud>"
        for cloud in target_clouds:
            col = cloud_color_map.get(cloud, "#0052d9")
            cloud_bar_data = json.dumps([g["targets_total"].get(cloud, 0) for g in merged])
            bar_datasets_list.append(
                f'{{ label: "{cloud}（目标）", data: {cloud_bar_data}, '
                f'backgroundColor: "{col}BF", stack: "target_{cloud}", borderRadius: 3 }}'
            )
    else:
        # 单源云：源端 + 目标云并排（不堆叠）
        bar_datasets_list.append(
            f'{{ label: "{meta.get("source_cloud","源云")}", data: {bar_source_data}, '
            f'backgroundColor: "{source_color}BF", borderRadius: 4 }}'
        )
        for cloud in target_clouds:
            col = cloud_color_map.get(cloud, "#0052d9")
            cloud_bar_data = json.dumps([g["targets_total"].get(cloud, 0) for g in merged])
            bar_datasets_list.append(
                f'{{ label: "{cloud}", data: {cloud_bar_data}, '
                f'backgroundColor: "{col}BF", borderRadius: 4 }}'
            )

    bar_datasets = "[" + ",\n      ".join(bar_datasets_list) + "]"
    bar_stacked_opt = "true" if is_multi_source else "false"

    # Tier 饼图（多云时取第一个目标云）
    first_cloud = target_clouds[0] if target_clouds else list(tier_by_cloud.keys())[0] if tier_by_cloud else "腾讯云"
    tier_counts_first = tier_by_cloud.get(first_cloud, {})
    pie_labels = json.dumps(list(tier_counts_first.keys()))
    pie_values = json.dumps(list(tier_counts_first.values()))
    pie_colors = json.dumps([tier_colors.get(t, "#999") for t in tier_counts_first.keys()])

    # 多云 tier 数据（JS 对象，用于切换）
    tier_all_js_entries = []
    for cloud, tc_map in tier_by_cloud.items():
        labels_j = json.dumps(list(tc_map.keys()))
        values_j = json.dumps(list(tc_map.values()))
        colors_j = json.dumps([tier_colors.get(t, "#999") for t in tc_map.keys()])
        col = cloud_color_map.get(cloud, "#0052d9")
        tier_all_js_entries.append(
            f'  "{cloud}": {{ labels: {labels_j}, values: {values_j}, colors: {colors_j}, color: "{col}" }}'
        )
    tier_all_js = "{\n" + ",\n".join(tier_all_js_entries) + "\n}"

    # 产品分布饼图
    prod_labels = json.dumps(list(product_counts.keys()))
    prod_values = json.dumps(list(product_counts.values()))
    prod_colors_map = {"ECS": "#3b82f6", "MySQL": "#8b5cf6", "Redis": "#ef4444", "CVM": "#0ea5e9"}
    prod_colors = json.dumps([prod_colors_map.get(p, "#999") for p in product_counts.keys()])

    # ============== 顶部统计区 ==============
    if is_multi_cloud:
        # 多云：显示对比汇总表
        rows_html = ""
        for cloud in target_clouds:
            ct = cloud_totals.get(cloud, {})
            col = cloud_color_map.get(cloud, "#0052d9")
            rows_html += f'''
              <tr>
                <td style="padding:10px 16px;font-weight:600;color:{col};">🔵 {cloud}</td>
                <td style="padding:10px 16px;text-align:right;font-weight:700;">¥{ct.get("total_cost",0):,.0f}</td>
                <td style="padding:10px 16px;text-align:right;color:#059669;font-weight:700;">¥{ct.get("savings",0):,.0f}</td>
                <td style="padding:10px 16px;text-align:right;color:#059669;font-weight:700;">{ct.get("savings_pct",0)}%</td>
                <td style="padding:10px 16px;text-align:right;">{ct.get("a_rate",0)}%</td>
              </tr>
            '''
        stats_section = f'''
          <div style="background:#fff;border-radius:12px;padding:20px;margin-bottom:28px;
               box-shadow:0 1px 6px rgba(0,0,0,0.05);overflow-x:auto;">
            <div style="font-size:13px;color:#999;margin-bottom:10px;">
              源端月费合计：<span style="font-weight:700;color:{source_color};">¥{meta["total_source_cost"]:,.0f}</span>
              &nbsp;·&nbsp; 共 {total} 台资源 / {merged_count} 种规格 &nbsp;·&nbsp; {prod_desc}
            </div>
            <table style="width:100%;border-collapse:collapse;">
              <thead>
                <tr style="border-bottom:2px solid #e5e7eb;">
                  <th style="padding:8px 16px;text-align:left;font-size:12px;color:#999;">目标云</th>
                  <th style="padding:8px 16px;text-align:right;font-size:12px;color:#999;">目标月费</th>
                  <th style="padding:8px 16px;text-align:right;font-size:12px;color:#999;">月节省</th>
                  <th style="padding:8px 16px;text-align:right;font-size:12px;color:#999;">节省率</th>
                  <th style="padding:8px 16px;text-align:right;font-size:12px;color:#999;">A 级匹配率</th>
                </tr>
              </thead>
              <tbody>{rows_html}</tbody>
            </table>
          </div>
        '''
    else:
        # 单云：原来的 5 列卡片
        ok_count = sum(
            1 for r in resources
            if any(t.get("status") == "ok" for t in r.get("targets", []))
        )
        stats_section = f'''
          <div class="stats-grid">
            <div class="stat-card">
              <div class="label">总资源</div>
              <div class="value" style="color:#1e293b;">{total}<span style="font-size:14px;color:#999;"> 台</span></div>
              <div class="sub">{merged_count} 种规格</div>
            </div>
            <div class="stat-card">
              <div class="label">源端月费</div>
              <div class="value" style="color:{source_color};">¥{meta["total_source_cost"]:,.0f}</div>
              <div class="sub">{meta.get("source_cloud","源云")}</div>
            </div>
            <div class="stat-card">
              <div class="label">目标端月费</div>
              <div class="value" style="color:#0052d9;">¥{meta["total_target_cost"]:,.0f}</div>
              <div class="sub">{meta.get("target_cloud","腾讯云")}</div>
            </div>
            <div class="stat-card">
              <div class="label">月节省</div>
              <div class="value" style="color:#059669;">¥{meta["total_savings"]:,.0f}</div>
              <div class="sub">年省 ¥{meta["total_savings"] * 12:,.0f}</div>
            </div>
            <div class="stat-card">
              <div class="label">节省比例</div>
              <div class="value" style="color:#059669;">{meta["savings_pct"]}%</div>
              <div class="sub">匹配 {ok_count}/{total}</div>
            </div>
          </div>
        '''

    # 多云时，Tier 饼图上方加云选择器
    tier_chart_header = '<h3>🎯 匹配等级</h3>'
    if is_multi_cloud:
        options_html = "".join(
            f'<option value="{c}">{c}</option>' for c in target_clouds
        )
        tier_chart_header = f'''
          <div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:8px;">
            <h3 style="margin:0;">🎯 匹配等级</h3>
            <select id="tierCloudSelect" onchange="updateTierChart(this.value)"
              style="font-size:12px;border:1px solid #e5e7eb;border-radius:6px;padding:3px 8px;color:#333;cursor:pointer;">
              {options_html}
            </select>
          </div>
        '''

    title_line = f"{meta.get('source_cloud','源云')} → {' / '.join(target_clouds)}"

    # ============== 最终 HTML ==============
    html = f'''<!DOCTYPE html>
<html lang="zh-CN">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>云迁移对比看板 — {title_line}</title>
<script src="https://cdn.jsdelivr.net/npm/chart.js@4.4.4/dist/chart.umd.min.js"></script>
<style>
  * {{ margin: 0; padding: 0; box-sizing: border-box; }}
  body {{ font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif; background: #f0f2f5; color: #1e293b; }}
  .container {{ max-width: 1100px; margin: 0 auto; padding: 24px 16px; }}
  .header {{ text-align: center; margin-bottom: 32px; }}
  .header h1 {{ font-size: 28px; font-weight: 800; background: linear-gradient(135deg, #0052d9, #00a3ff); -webkit-background-clip: text; -webkit-text-fill-color: transparent; }}
  .header .subtitle {{ color: #999; font-size: 14px; margin-top: 6px; }}
  .header .merge-info {{ color: #64748b; font-size: 13px; margin-top: 4px; background: #f1f5f9; display: inline-block; padding: 4px 14px; border-radius: 20px; }}
  .stats-grid {{ display: grid; grid-template-columns: repeat(5, 1fr); gap: 12px; margin-bottom: 28px; }}
  .stat-card {{ background: #fff; border-radius: 12px; padding: 16px; text-align: center; box-shadow: 0 1px 6px rgba(0,0,0,0.05); }}
  .stat-card .label {{ font-size: 12px; color: #999; margin-bottom: 6px; }}
  .stat-card .value {{ font-size: 24px; font-weight: 800; }}
  .stat-card .sub {{ font-size: 11px; color: #999; margin-top: 4px; }}
  .section-title {{ font-size: 18px; font-weight: 700; margin: 28px 0 16px; padding-left: 12px; border-left: 4px solid #0052d9; }}
  .charts-grid {{ display: grid; grid-template-columns: 5fr 3fr 3fr; gap: 16px; margin-bottom: 28px; }}
  .chart-card {{ background: #fff; border-radius: 12px; padding: 20px; box-shadow: 0 1px 6px rgba(0,0,0,0.05); }}
  .chart-card h3 {{ font-size: 14px; color: #666; margin-bottom: 12px; }}
  @media (max-width: 768px) {{
    .stats-grid {{ grid-template-columns: repeat(2, 1fr); }}
    .charts-grid {{ grid-template-columns: 1fr; }}
  }}
  .footer {{ text-align: center; color: #ccc; font-size: 11px; margin-top: 40px; padding: 20px 0; }}
</style>
</head>
<body>
<div class="container">
  <div class="header">
    <h1>☁️ 云迁移对比看板</h1>
    <div class="subtitle">{title_line} &nbsp;|&nbsp; 分析日期: {meta.get("analysis_date","")}</div>
    <div class="merge-info">共 {total} 台资源 → 合并为 {merged_count} 种规格 &nbsp;·&nbsp; {prod_desc}</div>
  </div>

  {stats_section}

  <div class="charts-grid">
    <div class="chart-card">
      <h3>📊 规格费用对比（同规格已合并）</h3>
      <canvas id="barChart" height="220"></canvas>
    </div>
    <div class="chart-card">
      {tier_chart_header}
      <canvas id="pieChart" height="220"></canvas>
    </div>
    <div class="chart-card">
      <h3>📦 产品分布</h3>
      <canvas id="prodChart" height="220"></canvas>
    </div>
  </div>

  <div class="section-title">🔄 规格迁移对照（同规格已合并）</div>
  {cards_html}

  <div class="footer">
    CVM Migration Dashboard v0.3 &nbsp;·&nbsp; Powered by MigraQ &nbsp;·&nbsp; {datetime.now().strftime("%Y-%m-%d %H:%M")}
  </div>
</div>

<script>
// 柱状图
new Chart(document.getElementById("barChart"), {{
  type: "bar",
  data: {{
    labels: {bar_labels},
    datasets: {bar_datasets}
  }},
  options: {{
    responsive: true,
    plugins: {{ legend: {{ position: "top" }} }},
    scales: {{
      x: {{ stacked: {bar_stacked_opt} }},
      y: {{ stacked: {bar_stacked_opt}, beginAtZero: true, ticks: {{ callback: v => "¥" + v.toLocaleString() }} }}
    }}
  }}
}});

// 匹配等级饼图（可切换云）
const tierAllData = {tier_all_js};
let pieChart = new Chart(document.getElementById("pieChart"), {{
  type: "doughnut",
  data: {{
    labels: {pie_labels},
    datasets: [{{ data: {pie_values}, backgroundColor: {pie_colors}, borderWidth: 2, borderColor: "#fff" }}]
  }},
  options: {{
    responsive: true,
    plugins: {{
      legend: {{ position: "bottom" }},
      tooltip: {{ callbacks: {{ label: ctx => ctx.label + ": " + ctx.parsed + " 台" }} }}
    }}
  }}
}});

function updateTierChart(cloud) {{
  const d = tierAllData[cloud];
  if (!d) return;
  pieChart.data.labels = d.labels;
  pieChart.data.datasets[0].data = d.values;
  pieChart.data.datasets[0].backgroundColor = d.colors;
  pieChart.update();
}}

// 产品分布饼图
new Chart(document.getElementById("prodChart"), {{
  type: "doughnut",
  data: {{
    labels: {prod_labels},
    datasets: [{{ data: {prod_values}, backgroundColor: {prod_colors}, borderWidth: 2, borderColor: "#fff" }}]
  }},
  options: {{
    responsive: true,
    plugins: {{
      legend: {{ position: "bottom" }},
      tooltip: {{ callbacks: {{ label: ctx => ctx.label + ": " + ctx.parsed + " 台" }} }}
    }}
  }}
}});
</script>
</body>
</html>'''

    output = Path(output_path)
    output.write_text(html, encoding="utf-8")
    print(f"[OK] 看板已生成: {output.resolve()}")
    return str(output.resolve())


def main():
    parser = argparse.ArgumentParser(description="CVM Migration Dashboard Generator")
    parser.add_argument("--demo", action="store_true", help="使用内置演示数据（双目标云）")
    parser.add_argument("--input", nargs="+", help="输入数据文件路径（支持多个文件合并）")
    parser.add_argument("--format", default="json", choices=["json", "csv"], help="输入格式（json 或 csv）")
    parser.add_argument("--output", default="migration-dashboard.html", help="输出文件路径")
    args = parser.parse_args()

    if not args.demo and not args.input:
        print("[INFO] 未指定输入，使用 --demo 演示模式")
        args.demo = True

    data = load_data(None if args.demo else args.input, args.format)
    output_path = generate_html(data, args.output)
    print(json.dumps({"success": True, "output": output_path}))


if __name__ == "__main__":
    main()
