#!/usr/bin/env python3
"""
Setup script for OpenCLI integration into LightClaw.

Installs:
1. OpenCLI CLI tool via npm
2. Chrome extension for browser automation
3. Configuration in ~/.lightclaw/lightclaw.json

Usage:
    python ~/.lightclaw/workspace/skills/opencli/scripts/setup_opencli.py
"""

import json
import subprocess
import sys
import urllib.request
import zipfile
from pathlib import Path


class OpenCLISetup:
    def __init__(self):
        self.home_dir = Path.home()
        self.lightclaw_dir = self.home_dir / ".lightclaw"
        self.extensions_dir = self.lightclaw_dir / "extensions" / "opencli"
        self.config_file = self.lightclaw_dir / "lightclaw.json"
        self.is_windows = sys.platform == "win32"

    def print_step(self, step_num: int, title: str):
        """Print a formatted step title."""
        print(f"\n{'=' * 60}")
        print(f"  Step {step_num}: {title}")
        print(f"{'=' * 60}\n")

    def print_success(self, msg: str):
        """Print success message."""
        print(f"✅ {msg}")

    def print_warning(self, msg: str):
        """Print warning message."""
        print(f"⚠️  {msg}")

    def print_error(self, msg: str):
        """Print error message."""
        print(f"❌ {msg}")

    def check_prerequisites(self) -> bool:
        """Check if Node.js and npm are installed."""
        self.print_step(1, "Checking Prerequisites")

        # Check Node.js
        try:
            result = subprocess.run(
                ["node", "--version"],
                capture_output=True,
                text=True,
                check=True,
            )
            node_version = result.stdout.strip()
            self.print_success(f"Node.js is installed: {node_version}")
        except (subprocess.CalledProcessError, FileNotFoundError):
            self.print_error("Node.js is not installed")
            print("\n   Please install Node.js from: https://nodejs.org/")
            return False

        # Check npm
        try:
            result = subprocess.run(
                ["npm", "--version"],
                capture_output=True,
                text=True,
                check=True,
            )
            npm_version = result.stdout.strip()
            self.print_success(f"npm is installed: {npm_version}")
        except (subprocess.CalledProcessError, FileNotFoundError):
            self.print_error("npm is not installed")
            return False

        # Check Chrome/Chromium
        chrome_paths = [
            "/usr/bin/google-chrome",  # Linux
            "/usr/bin/chromium",  # Linux
            "/Applications/Google Chrome.app/Contents/MacOS/Google Chrome",  # macOS
            "C:\\Program Files\\Google\\Chrome\\Application\\chrome.exe",  # Windows
            "C:\\Program Files (x86)\\Google\\Chrome\\Application\\chrome.exe",  # Windows 32-bit
        ]

        chrome_found = False
        for chrome_path in chrome_paths:
            if Path(chrome_path).exists():
                self.print_success(f"Chrome/Chromium found: {chrome_path}")
                chrome_found = True
                break

        if not chrome_found:
            self.print_warning("Chrome/Chromium not found in standard locations")
            print("   Make sure Chrome is installed or specify CHROME_PATH environment variable")

        return True

    def install_opencli_cli(self) -> bool:
        """Install OpenCLI CLI tool via npm."""
        self.print_step(2, "Installing OpenCLI CLI Tool")

        try:
            print("   Running: npm install -g @jackwener/opencli")
            result = subprocess.run(
                ["npm", "install", "-g", "@jackwener/opencli"],
                capture_output=True,
                text=True,
                timeout=300,  # 5 minutes timeout
            )

            if result.returncode != 0:
                self.print_error(f"npm install failed: {result.stderr}")
                return False

            self.print_success("OpenCLI CLI installed globally")

            # Verify installation
            try:
                result = subprocess.run(
                    ["opencli", "--version"],
                    capture_output=True,
                    text=True,
                    check=True,
                )
                version = result.stdout.strip()
                self.print_success(f"Verified: {version}")
                return True
            except subprocess.CalledProcessError:
                self.print_warning("Could not verify OpenCLI version")
                return True  # Installation likely succeeded anyway

        except subprocess.TimeoutExpired:
            self.print_error("Installation timed out (took too long)")
            return False
        except Exception as e:
            self.print_error(f"Unexpected error: {e}")
            return False

    def install_chrome_extension(self) -> bool:
        """Download and install Chrome extension."""
        self.print_step(3, "Installing Chrome Extension")

        # Create extensions directory
        self.extensions_dir.mkdir(parents=True, exist_ok=True)
        self.print_success(f"Extensions directory ready: {self.extensions_dir}")

        # Try to get extension from npm package
        try:
            print("   Attempting to download extension from @jackwener/opencli package...")

            # Get npm package info
            result = subprocess.run(
                ["npm", "info", "@jackwener/opencli", "--json"],
                capture_output=True,
                text=True,
                check=True,
            )

            pkg_info = json.loads(result.stdout)
            repo_url = pkg_info.get("repository", {}).get("url", "")

            if not repo_url:
                self.print_warning("Could not find repository URL in package info")
                # Fall back to manual installation
                self._print_extension_manual_install()
                return True

            # Clean up git+https:// prefix if present
            if repo_url.startswith("git+"):
                repo_url = repo_url[4:]
            if repo_url.endswith(".git"):
                repo_url = repo_url[:-4]

            print(f"   Repository: {repo_url}")

            # Download extension from GitHub releases
            github_api = repo_url.replace("https://github.com/", "").replace("github.com/", "")
            owner, repo = github_api.split("/")

            # Get latest release
            releases_url = f"https://api.github.com/repos/{owner}/{repo}/releases/latest"
            print(f"   Checking releases at: {releases_url}")

            with urllib.request.urlopen(releases_url) as response:
                release_data = json.loads(response.read().decode("utf-8"))
                assets = release_data.get("assets", [])

                extension_asset = None
                for asset in assets:
                    if "extension" in asset["name"].lower() or "chrome" in asset["name"].lower():
                        extension_asset = asset
                        break

                if not extension_asset:
                    self.print_warning("No extension asset found in releases")
                    self._print_extension_manual_install()
                    return True

                download_url = extension_asset["browser_download_url"]
                print(f"   Downloading from: {download_url}")

                # Download and extract
                zip_path = self.extensions_dir / "extension.zip"
                urllib.request.urlretrieve(download_url, zip_path)

                with zipfile.ZipFile(zip_path, "r") as zip_ref:
                    zip_ref.extractall(self.extensions_dir)

                zip_path.unlink()  # Remove zip file
                self.print_success("Chrome extension installed")
                return True

        except Exception as e:
            self.print_warning(f"Could not auto-download extension: {e}")
            self._print_extension_manual_install()
            return True

    def _print_extension_manual_install(self):
        """Print instructions for manual extension installation."""
        print("\n" + "=" * 60)
        print("  Manual Extension Installation Required")
        print("=" * 60)
        print("""
To manually install the OpenCLI Chrome extension:

1. Visit: https://github.com/jackwener/opencli/releases
2. Download the latest 'extension' or 'chrome' package
3. Extract it to: ~/.lightclaw/extensions/opencli/
4. Open Chrome and go to: chrome://extensions/
5. Enable "Developer mode" (top right)
6. Click "Load unpacked" and select: ~/.lightclaw/extensions/opencli/

The extension path will be configured automatically in lightclaw.json
        """)

    def configure_lightclaw(self) -> bool:
        """Add OpenCLI configuration to lightclaw.json."""
        self.print_step(4, "Configuring LightClaw")

        # Read existing config or create new
        if self.config_file.exists():
            try:
                with open(self.config_file) as f:
                    config = json.load(f)
                print(f"   Found existing config: {self.config_file}")
            except json.JSONDecodeError:
                self.print_warning("Config file is invalid JSON, creating new one")
                config = {}
        else:
            config = {}
            self.config_file.parent.mkdir(parents=True, exist_ok=True)
            print(f"   Creating new config: {self.config_file}")

        # Add OpenCLI configuration
        config.setdefault("opencli", {})
        config["opencli"].update(
            {
                "enabled": True,
                "extension_dir": str(self.extensions_dir),
                "chrome_args": [
                    f"--load-extension={self.extensions_dir}",
                    "--disable-blink-features=AutomationControlled",
                ],
                "timeout": 30,
                "version": "1.6.7",
            }
        )

        # Write config back
        try:
            with open(self.config_file, "w") as f:
                json.dump(config, f, indent=2)
            self.print_success(f"Configuration saved to {self.config_file}")
            return True
        except Exception as e:
            self.print_error(f"Failed to write config: {e}")
            return False

    def run_verification(self) -> bool:
        """Run OpenCLI doctor command to verify setup."""
        self.print_step(5, "Verifying Installation")

        try:
            print("   Running: opencli doctor")
            result = subprocess.run(
                ["opencli", "doctor"],
                capture_output=True,
                text=True,
                timeout=30,
            )
            print(result.stdout)

            if result.returncode == 0:
                self.print_success("All checks passed!")
                return True
            else:
                self.print_warning("Some checks failed (see output above)")
                return True  # Don't fail the whole setup
        except subprocess.TimeoutExpired:
            self.print_warning("Verification timed out")
            return True
        except FileNotFoundError:
            self.print_warning("opencli command not found in PATH")
            print("   Try: npm install -g @jackwener/opencli")
            return True
        except Exception as e:
            self.print_warning(f"Could not run verification: {e}")
            return True

    def print_summary(self):
        """Print setup summary and next steps."""
        print("\n" + "=" * 60)
        print("  🎉 OpenCLI Setup Complete!")
        print("=" * 60)
        print(f"""
Configuration saved to: {self.config_file}

Next steps:

1. Verify the Chrome extension:
   • Open Chrome → chrome://extensions/
   • If not shown, manually load from: {self.extensions_dir}

2. Test OpenCLI:
   $ opencli list              # See all supported platforms
   $ opencli doctor            # Run diagnostics

3. Use in LightClaw:
   • The opencli skill is now available
   • Start with: bash ~/.lightclaw/workspace/skills/opencli/scripts/opencli_state.sh <URL>
   • See SKILL.md for detailed usage examples

4. Documentation:
   • Full guide: ~/.lightclaw/workspace/skills/opencli/SKILL.md
   • Examples: ~/.lightclaw/workspace/skills/opencli/references/

For issues or feedback, visit: https://github.com/jackwener/opencli/issues
        """)

    def run(self) -> int:
        """Execute the full setup process."""
        print("""
╔══════════════════════════════════════════════════════════════╗
║          OpenCLI ↔ LightClaw Integration Setup              ║
║                                                              ║
║  This script will:                                           ║
║  1. Install OpenCLI CLI tool (via npm)                       ║
║  2. Download Chrome browser extension                        ║
║  3. Configure LightClaw to use OpenCLI                       ║
║                                                              ║
║  Prerequisites: Node.js, npm, Chrome/Chromium               ║
╚══════════════════════════════════════════════════════════════╝
        """)

        steps = [
            ("Prerequisites", self.check_prerequisites),
            ("OpenCLI CLI", self.install_opencli_cli),
            ("Chrome Extension", self.install_chrome_extension),
            ("LightClaw Config", self.configure_lightclaw),
            ("Verification", self.run_verification),
        ]

        for step_name, step_func in steps:
            try:
                if not step_func():
                    self.print_error(f"{step_name} failed")
                    return 1
            except KeyboardInterrupt:
                print("\n\n⚠️  Setup interrupted by user")
                return 130
            except Exception as e:
                self.print_error(f"Unexpected error in {step_name}: {e}")
                return 1

        self.print_summary()
        return 0


def main():
    setup = OpenCLISetup()
    exit_code = setup.run()
    sys.exit(exit_code)


if __name__ == "__main__":
    main()
