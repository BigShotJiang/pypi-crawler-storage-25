#!/usr/bin/env python3
"""
自动下载并安装 OpenCLI Chrome 扩展

这个脚本：
1. 检查 LightClaw 的 Playwright 管理的 Chromium 位置
2. 优先从 GitHub releases 下载最新的 opencli-extension.zip，
   若 GitHub 不可达则自动回退到 COS 镜像
3. 解压到 ~/.lightclaw/extensions/opencli/
4. LightClaw 会在下次启动 Chrome 时自动通过 --load-extension 加载

注意：LightClaw 已支持自动加载 ~/.lightclaw/extensions/ 下的扩展，
安装后重启 Chrome 即可生效，无需手动操作。
"""

import json
import os
import subprocess
import sys
import urllib.request
import zipfile
from pathlib import Path
from urllib.error import URLError

# COS 镜像：GitHub 不可达时的备用下载地址
_MIRROR_EXTENSION_URL = "https://finnie-1258344699.cos.ap-guangzhou.myqcloud.com/opencli-extension.zip"


class ExtensionInstaller:
    def __init__(self):
        self.home_dir = Path.home()
        self.lightclaw_dir = self.home_dir / ".lightclaw"
        self.extensions_dir = self.lightclaw_dir / "extensions" / "opencli"
        self.github_repo = "jackwener/opencli"
        self.github_api = f"https://api.github.com/repos/{self.github_repo}/releases"

    def print_step(self, title: str):
        print(f"\n{'=' * 70}")
        print(f"  {title}")
        print(f"{'=' * 70}\n")

    def print_success(self, msg: str):
        print(f"✅ {msg}")

    def print_error(self, msg: str):
        print(f"❌ {msg}")

    def print_info(self, msg: str):
        print(f"ℹ️  {msg}")

    def download_extension(self) -> bool:
        """下载 opencli-extension.zip。

        优先从 GitHub releases 下载最新版；若 GitHub 不可达（网络超时、
        限流、无匹配资源等），自动回退到 COS 镜像。
        """
        self.print_step("下载 OpenCLI 浏览器扩展")

        if self._download_from_github():
            return True

        self.print_info("尝试镜像下载 (COS)...")
        return self._download_from_url(_MIRROR_EXTENSION_URL)

    def _download_from_github(self) -> bool:
        """从 GitHub releases 下载扩展包，失败返回 False。"""
        try:
            self.print_info("查询 GitHub releases...")
            req = urllib.request.Request(
                f"{self.github_api}/latest",
                headers={"Accept": "application/vnd.github.v3+json"},
            )
            with urllib.request.urlopen(req, timeout=10) as response:
                release_data = json.loads(response.read().decode("utf-8"))

            release_tag = release_data.get("tag_name", "unknown")
            assets = release_data.get("assets", [])
            self.print_info(f"最新版本: {release_tag}")

            extension_asset = None
            for asset in assets:
                name = asset["name"].lower()
                if ("extension" in name or "chrome" in name or "bridge" in name) and name.endswith(".zip"):
                    extension_asset = asset
                    break

            if not extension_asset:
                self.print_error("未在 GitHub release 中找到扩展包")
                return False

            download_url = extension_asset["browser_download_url"]
            file_name = extension_asset["name"]
            file_size = extension_asset.get("size", 0) / (1024 * 1024)
            self.print_info(f"找到扩展包: {file_name} ({file_size:.1f} MB)")

            return self._download_from_url(download_url)

        except URLError as e:
            self.print_error(f"GitHub 网络错误: {e}")
            return False
        except (json.JSONDecodeError, KeyError) as e:
            self.print_error(f"GitHub 响应解析失败: {e}")
            return False

    def _download_from_url(self, url: str) -> bool:
        """从指定 URL 下载 zip 并解压到扩展目录。"""
        try:
            self.print_info(f"下载中: {url}")
            self.extensions_dir.mkdir(parents=True, exist_ok=True)
            zip_path = self.extensions_dir / "extension.zip"

            urllib.request.urlretrieve(url, zip_path)
            self.print_success(f"下载完成: {zip_path}")

            self.print_info("解压中...")
            with zipfile.ZipFile(zip_path, "r") as zip_ref:
                zip_ref.extractall(self.extensions_dir)

            zip_path.unlink(missing_ok=True)
            self.print_success("扩展已解压")
            return True

        except URLError as e:
            self.print_error(f"下载失败: {e}")
            return False
        except zipfile.BadZipFile as e:
            self.print_error(f"无效的 zip 文件: {e}")
            (self.extensions_dir / "extension.zip").unlink(missing_ok=True)
            return False
        except Exception as e:
            self.print_error(f"安装失败: {e}")
            return False

    def _print_manual_download_instruction(self):
        """打印手动下载指令"""
        print("\n" + "=" * 70)
        print("  手动下载扩展")
        print("=" * 70)
        print(f"""
如果自动下载失败，请手动下载：

方式一：COS 镜像（国内推荐）
  wget {_MIRROR_EXTENSION_URL}

方式二：GitHub releases
  访问 https://github.com/jackwener/opencli/releases
  找到最新的 Release，下载 "opencli-extension.zip"

下载后解压到:
  ~/.lightclaw/extensions/opencli/

然后重启 LightClaw 即可自动加载扩展。
        """)

    def verify_extension_structure(self) -> bool:
        """验证扩展结构"""
        self.print_step("验证扩展结构")

        # 查找 manifest.json
        manifest_path = None
        for root, _dirs, files in os.walk(self.extensions_dir):
            if "manifest.json" in files:
                manifest_path = Path(root) / "manifest.json"
                break

        if not manifest_path:
            self.print_error("未找到 manifest.json，扩展结构可能不完整")
            return False

        self.print_success(f"找到 manifest.json: {manifest_path.parent}")

        # 读取并显示版本
        try:
            with open(manifest_path) as f:
                manifest = json.load(f)
            version = manifest.get("version", "unknown")
            name = manifest.get("name", "OpenCLI Extension")
            self.print_info(f"扩展名: {name}")
            self.print_info(f"版本: {version}")
            return True
        except Exception as e:
            self.print_error(f"无法读取 manifest.json: {e}")
            return False

    def find_playwright_chromium(self) -> str | None:
        """查找 LightClaw 通过 Playwright 安装的 Chromium"""

        # 检查 Playwright 的默认缓存目录
        cache_dirs = [
            Path.home() / ".cache" / "ms-playwright",
        ]
        env_path = os.environ.get("PLAYWRIGHT_BROWSERS_PATH")
        if env_path:
            cache_dirs.insert(0, Path(env_path))

        for cache_dir in cache_dirs:
            if not cache_dir.is_dir():
                continue
            # 查找 chromium-*/chrome-linux64/chrome 或 chromium-*/chrome-*/chrome
            for pattern in ["chromium-*/chrome-linux64/chrome", "chromium-*/chrome-*/chrome"]:
                matches = list(cache_dir.glob(pattern))
                for m in matches:
                    if m.exists() and os.access(str(m), os.X_OK):
                        return str(m)

        # 尝试通过 Playwright CLI 查询
        try:
            result = subprocess.run(
                [sys.executable, "-m", "playwright", "show-downloads-dir"], capture_output=True, text=True, timeout=5
            )
            if result.returncode == 0 and result.stdout.strip():
                dl_dir = Path(result.stdout.strip())
                for pattern in ["chromium-*/chrome-linux64/chrome", "chromium-*/chrome-*/chrome"]:
                    matches = list(dl_dir.glob(pattern))
                    for m in matches:
                        if m.exists() and os.access(str(m), os.X_OK):
                            return str(m)
        except Exception:
            pass

        return None

    def check_chromium_installed(self) -> tuple[bool, str]:
        """检查 Chromium 是否安装（优先检查 LightClaw 的 Playwright Chromium）"""
        self.print_step("检查 Chromium/Chrome 安装情况")

        # 1. 优先查找 LightClaw 通过 Playwright 安装的 Chromium
        pw_chrome = self.find_playwright_chromium()
        if pw_chrome:
            self.print_success(f"找到 LightClaw Playwright Chromium: {pw_chrome}")
            self.print_info("LightClaw 会自动加载 ~/.lightclaw/extensions/ 下的扩展")
            return True, pw_chrome

        # 2. 检查系统常见路径
        chromium_paths = [
            "/usr/bin/chromium",
            "/usr/bin/chromium-browser",
            "/usr/bin/google-chrome",
            "/usr/bin/google-chrome-stable",
            "/snap/bin/chromium",
            "/Applications/Chromium.app/Contents/MacOS/Chromium",
            "/Applications/Google Chrome.app/Contents/MacOS/Google Chrome",
            "C:\\Program Files\\Google\\Chrome\\Application\\chrome.exe",
            "C:\\Program Files (x86)\\Google\\Chrome\\Application\\chrome.exe",
        ]

        for path in chromium_paths:
            if Path(path).exists():
                self.print_success(f"找到系统 Chrome: {path}")
                return True, path

        self.print_error("未找到 Chromium/Chrome（包括 LightClaw 的 Playwright Chromium）")
        self.print_info("请先运行: lightclaw install-browsers")
        return False, ""

    def print_load_extension_steps(self, chromium_path: str):
        """打印配置方式说明：CDP 直连（推荐）或手动加载扩展（备用）"""
        self.print_step("配置方式选择")

        extension_path = self.extensions_dir
        for root, _dirs, files in os.walk(self.extensions_dir):
            if "manifest.json" in files:
                extension_path = Path(root)
                break

        print(f"""
✅ 扩展已安装
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

LightClaw 会在启动 Chrome 时自动从 ~/.lightclaw/extensions/ 加载扩展。
扩展通过 --load-extension 参数注入，无需手动操作。

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

⚡ 使用方式：

  1. 重启 LightClaw（让 Chrome 以新参数重新启动）
  2. 扩展会被自动加载，opencli 可直接使用：

     opencli operate state

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

ℹ️  备选方案：CDP 直连（无需扩展）

  export OPENCLI_CDP_ENDPOINT=http://127.0.0.1:18800
  opencli operate state

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

扩展文件位置: {extension_path}
LightClaw CDP 端口: http://127.0.0.1:18800
        """)

    def run_opencli_doctor(self) -> bool:
        """运行 opencli doctor 检查"""
        self.print_step("验证安装 (opencli doctor)")

        try:
            result = subprocess.run(["opencli", "doctor"], capture_output=True, text=True, timeout=10)
            print(result.stdout)

            if "Extension: connected" in result.stdout or "[OK]" in result.stdout:
                self.print_success("扩展已连接!")
                return True
            else:
                self.print_error("扩展未连接")
                return False

        except FileNotFoundError:
            self.print_error("opencli 命令未找到")
            return False
        except Exception as e:
            self.print_error(f"检查失败: {e}")
            return False

    def print_troubleshooting(self):
        """打印故障排除步骤"""
        self.print_step("故障排除")

        print("""
如果扩展仍未连接，请尝试以下步骤：

1️⃣  确认扩展已启用
   chrome://extensions/ → 检查 OpenCLI 扩展的切换开关是否为 ON

2️⃣  重启 Chromium
   完全关闭所有 Chromium 窗口，重新打开

3️⃣  检查端口
   Daemon 应该在 19825 端口运行：
     netstat -tlnp | grep 19825

4️⃣  查看 Daemon 日志
   opencli daemon status

5️⃣  重启 Daemon
   opencli daemon stop
   sleep 2
   opencli doctor

6️⃣  检查 Chrome 扩展权限
   chrome://extensions/ → OpenCLI 详情
   确保有以下权限：
     - debugger
     - tabs
     - cookies
     - activeTab

7️⃣  尝试从源码加载扩展
   访问 https://github.com/jackwener/opencli
   下载源码后，加载 extension/ 文件夹

8️⃣  查看官方文档
   https://github.com/jackwener/opencli#browser-bridge-extension-configuration
        """)

    def run(self) -> int:
        """执行完整流程"""
        print("""
╔══════════════════════════════════════════════════════════════════════════╗
║                                                                          ║
║           OpenCLI Chrome/Chromium 扩展自动安装脚本                       ║
║                                                                          ║
║  这个脚本将：                                                            ║
║  1. 优先从 GitHub 下载最新的 opencli-extension.zip                       ║
║     (GitHub 不可达时自动回退到 COS 镜像)                                 ║
║  2. 解压到 ~/.lightclaw/extensions/opencli/                              ║
║  3. 提供在 Chromium 中手动加载的步骤                                     ║
║  4. 验证连接                                                            ║
║                                                                          ║
╚══════════════════════════════════════════════════════════════════════════╝
        """)

        # 检查前置条件
        chromium_ok, chromium_path = self.check_chromium_installed()

        # 下载扩展
        if not self.download_extension():
            self.print_error("下载失败")
            return 1

        # 验证扩展结构
        if not self.verify_extension_structure():
            self.print_error("扩展验证失败")
            return 1

        # 打印加载步骤
        if chromium_ok:
            self.print_load_extension_steps(chromium_path)
        else:
            self.print_info("请先安装 Chromium 或 Chrome")
            return 1

        # 尝试验证（需要用户已手动加载）
        print("\n" + "=" * 70)
        response = input("已在 Chromium 中加载扩展? (y/n): ").strip().lower()

        if response == "y":
            if self.run_opencli_doctor():
                print("\n" + "=" * 70)
                print("🎉 安装完成！扩展已成功加载并连接。")
                print("=" * 70)
                return 0
            else:
                self.print_troubleshooting()
                return 1
        else:
            print("\n请按照上面的步骤在 Chromium 中加载扩展，然后再运行此脚本。")
            self.print_troubleshooting()
            return 0


def main():
    installer = ExtensionInstaller()
    exit_code = installer.run()
    sys.exit(exit_code)


if __name__ == "__main__":
    main()
