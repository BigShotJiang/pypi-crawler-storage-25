# OpenCLI Commands Reference

## 完整命令参考

### 导航和状态

| 命令 | 描述 | 示例 |
|------|------|------|
| `open URL` | 打开 URL | `opencli operate open "https://example.com"` |
| `state` | 获取页面状态 | `opencli operate state --format json` |
| `back` | 返回上一页 | `opencli operate back` |
| `forward` | 前进到下一页 | `opencli operate forward` |
| `reload` | 刷新页面 | `opencli operate reload` |

### 交互操作

| 命令 | 描述 | 参数 | 示例 |
|------|------|------|------|
| `click` | 点击元素 | 元素 ID | `opencli operate click 0` |
| `type` | 输入文本 | 元素 ID, 文本 | `opencli operate type 5 "hello"` |
| `select` | 选择下拉框 | 元素 ID, 值 | `opencli operate select 3 "option1"` |
| `pressKey` | 按键 | 键名 | `opencli operate pressKey Enter` |
| `scroll` | 滚动页面 | 方向, 距离 | `opencli operate scroll down 500` |

### 数据获取和提取

| 命令 | 描述 | 参数 | 示例 |
|------|------|------|------|
| `eval` | 执行 JavaScript | 代码 | `opencli operate eval 'document.title'` |
| `get` | 获取属性值 | 属性名 | `opencli operate get title` |
| `screenshot` | 截图 | 可选：格式 | `opencli operate screenshot` |
| `snapshot` | 完整快照 | 可选：格式 | `opencli operate snapshot` |

### 等待和同步

| 命令 | 描述 | 参数 | 示例 |
|------|------|------|------|
| `wait` | 等待元素 | 选择器 | `opencli operate wait ".loading"` |
| `waitFor` | 等待条件 | 条件 | `opencli operate waitFor "2000"` |

### 标签页管理

| 命令 | 描述 | 参数 | 示例 |
|------|------|------|------|
| `tabs` | 列出所有标签页 | 无 | `opencli operate tabs` |
| `selectTab` | 切换标签页 | 标签页索引 | `opencli operate selectTab 1` |
| `newTab` | 新建标签页 | URL (可选) | `opencli operate newTab` |
| `closeTab` | 关闭标签页 | 索引 (可选) | `opencli operate closeTab 0` |

### 网络和 Cookie

| 命令 | 描述 | 参数 | 示例 |
|------|------|------|------|
| `getCookies` | 获取 Cookies | 可选：URL | `opencli operate getCookies` |
| `setCookie` | 设置 Cookie | 名称, 值 | `opencli operate setCookie "session" "abc123"` |
| `networkRequests` | 获取请求日志 | 可选：过滤 | `opencli operate networkRequests` |

### 表单操作

| 命令 | 描述 | 参数 | 示例 |
|------|------|------|------|
| `getFormState` | 获取表单状态 | 无 | `opencli operate getFormState` |
| `fillForm` | 填充表单 | JSON 对象 | `opencli operate fillForm '{"name":"John"}'` |

### 浏览器控制

| 命令 | 描述 | 参数 | 示例 |
|------|------|------|------|
| `goto` | 导航到 URL | URL | `opencli operate goto "https://example.com"` |
| `waitForNavigation` | 等待导航 | 超时 (ms) | `opencli operate waitForNavigation 5000` |
| `close` | 关闭浏览器 | 无 | `opencli operate close` |

## 获取帮助

```bash
# 查看所有可用命令
opencli list

# 查看特定适配器的帮助
opencli --help

# 查看诊断信息
opencli doctor

# 查看配置
opencli config
```

## 输出格式选项

支持的输出格式：
- `json` - JSON 格式（推荐用于脚本）
- `table` - 表格格式（人类可读）
- `yaml` - YAML 格式
- `csv` - CSV 格式
- `markdown` - Markdown 表格

示例：
```bash
opencli operate state --format json
opencli list --format table
```

## 错误代码

| 代码 | 含义 | 说明 |
|------|------|------|
| 0 | 成功 | 命令执行成功 |
| 1 | 通用错误 | 未指定的错误 |
| 2 | 使用错误 | 命令参数不正确 |
| 66 | 空结果 | 没有返回数据 |
| 69 | 服务不可用 | 浏览器或服务不可用 |
| 77 | 需要身份验证 | 需要登录 |
| 78 | 配置错误 | 配置文件有问题 |

## 常用组合

### 搜索流程
```bash
# 1. 打开搜索引擎
opencli operate open "https://google.com"

# 2. 等待页面加载
opencli operate wait "input[name=q]"

# 3. 获取状态（找到搜索框的 ID）
opencli operate state --format json

# 4. 输入搜索词（假设 ID=2）
opencli operate type 2 "machine learning"

# 5. 获取状态（找到搜索按钮）
opencli operate state --format json

# 6. 点击搜索（假设 ID=5）
opencli operate click 5

# 7. 等待结果
opencli operate wait ".g"

# 8. 获取结果
opencli operate state --format json
```

### 登录流程
```bash
# 1. 打开网站
opencli operate open "https://example.com"

# 2. 点击登录（假设 ID=0）
opencli operate click 0

# 3. 等待表单
opencli operate wait "form"

# 4. 填充表单
opencli operate type 10 "username"      # 用户名输入框
opencli operate type 11 "password"      # 密码输入框
opencli operate click 12                # 提交按钮

# 5. 等待登录完成
opencli operate wait ".logged-in"

# 6. 验证成功
opencli operate state --format json
```

### 数据提取
```bash
# 提取所有链接
opencli operate eval 'Array.from(document.querySelectorAll("a")).map(a => ({
  text: a.textContent.trim(),
  href: a.href
}))'

# 提取表格数据
opencli operate eval 'Array.from(document.querySelectorAll("table tr")).map(row =>
  Array.from(row.querySelectorAll("td,th")).map(cell => cell.textContent.trim())
)'

# 提取指定选择器的文本
opencli operate eval 'document.querySelector(".result")?.textContent.trim()'
```

## 环境变量

```bash
# 指定 Chrome 可执行文件路径
export CHROME_PATH="/usr/bin/google-chrome"

# 指定浏览器窗口大小
export BROWSER_WIDTH=1280
export BROWSER_HEIGHT=720

# 指定超时（毫秒）
export TIMEOUT=30000

# 启用调试日志
export DEBUG=*
```

## 高级特性

### 拦截网络请求

```bash
# 拦截特定模式的请求
opencli operate installInterceptor "api/v1/users"

# 获取拦截的请求
opencli operate networkRequests
```

### 原始 CDP 命令

```bash
# 发送原始 Chrome DevTools Protocol 命令
opencli operate cdp '{"method":"Runtime.evaluate","params":{"expression":"1+1"}}'
```

### 页面评估上下文

```bash
# 在特定上下文中执行 JavaScript
opencli operate eval --context "iframe#content" 'document.body.innerHTML'
```
