# OpenCLI Skill 快速参考卡片

## 安装（一次性）
```bash
python ~/.lightclaw/workspace/skills/opencli/scripts/setup_opencli.py
opencli doctor
```

## 三个核心命令

### 1. 获取页面状态（零成本）
```bash
bash ~/.lightclaw/workspace/skills/opencli/scripts/opencli_state.sh [URL]
```
**返回**：结构化 DOM，包含所有可交互元素的 ID

### 2. 执行操作
```bash
# 点击元素
bash ~/.lightclaw/workspace/skills/opencli/scripts/opencli_operate.sh \
  --operation click --element-id 0

# 输入文本
bash ~/.lightclaw/workspace/skills/opencli/scripts/opencli_operate.sh \
  --operation type --element-id 5 --value "text"

# 运行 JavaScript
bash ~/.lightclaw/workspace/skills/opencli/scripts/opencli_operate.sh \
  --operation eval --script 'document.title'

# 等待元素
bash ~/.lightclaw/workspace/skills/opencli/scripts/opencli_operate.sh \
  --operation wait --selector ".loaded"

# 截图（谨慎使用，消耗 Token）
bash ~/.lightclaw/workspace/skills/opencli/scripts/opencli_operate.sh \
  --operation screenshot
```

### 3. 支持的操作
- `click` - 点击元素
- `type` - 输入文本
- `select` - 选择下拉框
- `eval` - JavaScript 执行
- `screenshot` - 截图
- `wait` - 等待元素

## 工作流模板

```bash
#!/bin/bash

# 1. 打开页面
opencli operate open "https://example.com"

# 2. 等待加载
bash opencli_operate.sh --operation wait --selector ".content"

# 3. 获取状态（查看有哪些元素）
bash opencli_state.sh

# 4. 执行操作
bash opencli_operate.sh --operation click --element-id 5
bash opencli_operate.sh --operation type --element-id 10 --value "search"

# 5. 提取数据
bash opencli_operate.sh --operation eval --script '
  Array.from(document.querySelectorAll(".item")).map(el => ({
    title: el.querySelector(".title")?.textContent,
    link: el.querySelector("a")?.href
  }))
'
```

## 常见问题解决

| 问题 | 解决方案 |
|------|--------|
| 元素 ID 找不到 | 页面变化了，重新 `state` |
| 等待超时 | 增加超时，或检查选择器 |
| CAPTCHA | 截图手动完成 |
| 需要登录 | 先登录，登录信息会保留 |

## 关键性能优化

✅ **总是先 state** - 查看页面结构，了解元素 ID  
✅ **用 eval 批量提取** - 比多次 state 快  
✅ **避免频繁截图** - 消耗 Vision Token  
✅ **批量操作** - 多个操作后再 state

## 文档导航

| 文档 | 内容 |
|------|------|
| `SKILL.md` | 完整指南，工作流，场景示例 |
| `quickstart.md` | 5 分钟快速上手 |
| `opencli_commands.md` | 完整命令参考 |
| `advanced_patterns.md` | 高级用法（分页、无限滚动等） |
| `javascript_api.md` | JavaScript API 参考 |

## 支持的平台（79+）

Bilibili • 小红书 • YouTube • Amazon • GitHub • Twitter/X • 
Reddit • ChatGPT • Notion • Discord • Docker • Vercel...

完整列表：`opencli list`

## 快速链接

- **OpenCLI 官方**：https://github.com/jackwener/opencli
- **问题报告**：https://github.com/jackwener/opencli/issues
- **本地文档**：~/.lightclaw/workspace/skills/opencli/
