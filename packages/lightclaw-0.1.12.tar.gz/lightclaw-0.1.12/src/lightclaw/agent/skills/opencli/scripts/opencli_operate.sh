#!/bin/bash
# OpenCLI operate script
# Execute browser operations (click, type, select, eval, screenshot, wait)
#
# Usage:
#   bash opencli_operate.sh --operation OPERATION [--element-id ID] [--value VALUE] [--selector SELECTOR] [--script SCRIPT]
#
# Operations:
#   click              - Click an element by ID
#   type               - Type text into an input field
#   select             - Select dropdown option
#   eval               - Execute JavaScript
#   screenshot         - Take page screenshot
#   wait               - Wait for element to appear
#
# Examples:
#   bash opencli_operate.sh --operation click --element-id 0
#   bash opencli_operate.sh --operation type --element-id 5 --value "search term"
#   bash opencli_operate.sh --operation eval --script 'document.title'
#   bash opencli_operate.sh --operation screenshot
#   bash opencli_operate.sh --operation wait --selector ".loading"

set -e

# 优先使用 LightClaw 自己管理的 Chrome CDP 端口（18800）
# LightClaw 自动加载 ~/.lightclaw/extensions/ 下的扩展；CDP 直连作为备选
if [ -z "$OPENCLI_CDP_ENDPOINT" ]; then
    LIGHTCLAW_CDP_PORT="${LIGHTCLAW_CDP_PORT:-18800}"
    if curl -s "http://127.0.0.1:${LIGHTCLAW_CDP_PORT}/json/version" >/dev/null 2>&1; then
        export OPENCLI_CDP_ENDPOINT="http://127.0.0.1:${LIGHTCLAW_CDP_PORT}"
    fi
fi

OPERATION=""
ELEMENT_ID=""
VALUE=""
SELECTOR=""
SCRIPT=""

# Parse arguments
while [[ $# -gt 0 ]]; do
    case $1 in
        --operation)
            OPERATION="$2"
            shift 2
            ;;
        --element-id)
            ELEMENT_ID="$2"
            shift 2
            ;;
        --value)
            VALUE="$2"
            shift 2
            ;;
        --selector)
            SELECTOR="$2"
            shift 2
            ;;
        --script)
            SCRIPT="$2"
            shift 2
            ;;
        *)
            echo "Unknown option: $1"
            exit 1
            ;;
    esac
done

if [ -z "$OPERATION" ]; then
    echo "Error: --operation is required"
    exit 1
fi

# Execute operation
case "$OPERATION" in
    click)
        if [ -z "$ELEMENT_ID" ]; then
            echo "Error: --element-id required for click operation"
            exit 1
        fi
        opencli operate click "$ELEMENT_ID"
        ;;
    type)
        if [ -z "$ELEMENT_ID" ] || [ -z "$VALUE" ]; then
            echo "Error: --element-id and --value required for type operation"
            exit 1
        fi
        opencli operate type "$ELEMENT_ID" "$VALUE"
        ;;
    select)
        if [ -z "$ELEMENT_ID" ] || [ -z "$VALUE" ]; then
            echo "Error: --element-id and --value required for select operation"
            exit 1
        fi
        opencli operate select "$ELEMENT_ID" "$VALUE"
        ;;
    eval)
        if [ -z "$SCRIPT" ]; then
            echo "Error: --script required for eval operation"
            exit 1
        fi
        opencli operate eval "$SCRIPT"
        ;;
    screenshot)
        opencli operate screenshot
        ;;
    wait)
        if [ -z "$SELECTOR" ]; then
            echo "Error: --selector required for wait operation"
            exit 1
        fi
        opencli operate wait "$SELECTOR"
        ;;
    open)
        if [ -z "$VALUE" ]; then
            echo "Error: --value (URL) required for open operation"
            exit 1
        fi
        opencli operate open "$VALUE"
        ;;
    *)
        echo "Unknown operation: $OPERATION"
        echo "Supported: click, type, select, eval, screenshot, wait, open"
        exit 1
        ;;
esac
