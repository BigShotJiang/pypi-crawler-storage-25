#!/bin/bash
# 一键安装 OpenCLI 完整环境（包括浏览器扩展）

set -e

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"

echo "╔════════════════════════════════════════════════════════════════╗"
echo "║          OpenCLI 完整环装置装安装                             ║"
echo "╠════════════════════════════════════════════════════════════════╣"
echo "║  这个脚本会：                                                 ║"
echo "║  1. 安装 OpenCLI CLI 和依赖                                   ║"
echo "║  2. 下载并安装 Chrome 浏览器扩展                              ║"
echo "║  3. 指导在 Chromium 中手动加载扩展                            ║"
echo "║  4. 验证整个设置                                             ║"
echo "╚════════════════════════════════════════════════════════════════╝"

echo ""
echo "步骤 1/2: 安装 OpenCLI CLI..."
python "$SCRIPT_DIR/scripts/setup_opencli.py"

if [ $? -ne 0 ]; then
    echo ""
    echo "❌ OpenCLI CLI 安装失败"
    exit 1
fi

echo ""
echo "步骤 2/2: 下载浏览器扩展..."
python "$SCRIPT_DIR/scripts/install_extension.py"

if [ $? -eq 0 ]; then
    echo ""
    echo "╔════════════════════════════════════════════════════════════════╗"
    echo "║  ✅ 安装完成！                                                ║"
    echo "╠════════════════════════════════════════════════════════════════╣"
    echo "║                                                                ║"
    echo "║  请按照上面的步骤操作：                                       ║"
    echo "║  1. 打开 Chromium/Chrome                                      ║"
    echo "║  2. 访问 chrome://extensions/                                 ║"
    echo "║  3. 启用 \"开发者模式\"                                       ║"
    echo "║  4. 点击 \"加载已解压的扩展程序\"                             ║"
    echo "║  5. 选择 ~/.lightclaw/extensions/opencli/                     ║"
    echo "║                                                                ║"
    echo "║  然后验证：                                                   ║"
    echo "║    opencli doctor                                             ║"
    echo "║                                                                ║"
    echo "║  更多帮助：                                                   ║"
    echo "║    cat $SCRIPT_DIR/EXTENSION_INSTALL.md                    ║"
    echo "║                                                                ║"
    echo "╚════════════════════════════════════════════════════════════════╝"
fi
