#!/bin/bash
# OpenCLI state query script
# 获取当前页面的结构化 DOM（零成本、秒级响应）
#
# 通过 OPENCLI_CDP_ENDPOINT 直连 LightClaw 管理的 Chrome（端口 18800）
# LightClaw 自动加载 ~/.lightclaw/extensions/ 下的扩展（含 opencli Browser Bridge）
#
# Usage:
#   bash opencli_state.sh [URL]
#
# Examples:
#   bash opencli_state.sh "https://example.com"
#   bash opencli_state.sh                          # Uses current page

set -e

# 优先使用 LightClaw 自己管理的 Chrome CDP 端口（18800）
# 如果环境变量未设置，自动探测 LightClaw 的 CDP 端口
if [ -z "$OPENCLI_CDP_ENDPOINT" ]; then
    # LightClaw 默认 CDP 端口
    LIGHTCLAW_CDP_PORT="${LIGHTCLAW_CDP_PORT:-18800}"
    if curl -s "http://127.0.0.1:${LIGHTCLAW_CDP_PORT}/json/version" >/dev/null 2>&1; then
        export OPENCLI_CDP_ENDPOINT="http://127.0.0.1:${LIGHTCLAW_CDP_PORT}"
    fi
fi

URL="${1:-}"

if [ -z "$URL" ]; then
    # Get current page state (no URL needed if browser already on a page)
    opencli operate state --format json 2>/dev/null || opencli operate state
else
    # Navigate to URL and get state
    opencli operate open "$URL" > /dev/null 2>&1 || true
    opencli operate state --format json 2>/dev/null || opencli operate state
fi
