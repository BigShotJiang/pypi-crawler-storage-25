#!/usr/bin/env python3
"""LightClaw health-check scorer — computes scores from health_check.py JSON output.

Reads JSON data from stdin, applies scoring rules, and prints per-dimension
scores and a total score.

Usage:
    python health_check.py | python report_scorer.py
    python report_scorer.py < health_data.json
"""

from __future__ import annotations

import contextlib
import json
import sys
from typing import Any

DIMENSION_WEIGHTS = {
    "process": 20,
    "logs": 15,
    "auth_security": 15,
    "network": 15,
    "storage": 10,
    "host_environment": 10,
    "lightclaw_config": 10,
    "dependencies": 5,
}

DIMENSION_LABELS = {
    "process": "🫀 Process Vitals",
    "logs": "🧠 Log Observability",
    "auth_security": "🔐 Auth & Key Security",
    "network": "🌐 Network Security",
    "storage": "💾 Storage & Data Security",
    "host_environment": "🖥️ Host Environment Security",
    "lightclaw_config": "⚙️ LightClaw Config Health",
    "dependencies": "🛡️ Dependency & Supply-Chain Security",
}

RATINGS = [
    (90, "S", "🏆 Impenetrable — flawless"),
    (80, "A", "🛡️ Rock solid — trustworthy"),
    (70, "B", "👍 Good shape — minor issues"),
    (60, "C", "⚠️ Suboptimal — needs attention"),
    (40, "D", "🚨 Frequent issues — fix urgently"),
    (0, "F", "💀 Critical — emergency intervention needed"),
]


def _clamp(value: float, lo: float = 0, hi: float = 100) -> float:
    return max(lo, min(hi, value))


def score_process(data: dict[str, Any]) -> tuple[float, list[dict]]:
    """Score process health (max 100, then scaled by weight)."""
    score = 100.0
    findings: list[dict] = []

    if not data.get("lightclaw_running"):
        return 0, [{"severity": "critical", "item": "LightClaw process is not running", "deduction": 100}]

    cpu = data.get("cpu_percent")
    if cpu is not None:
        if cpu > 80:
            d = 40
            findings.append({"severity": "high", "item": f"CPU usage too high: {cpu}%", "deduction": d})
            score -= d
        elif cpu > 60:
            d = 25
            findings.append(
                {
                    "severity": "medium",
                    "item": f"CPU usage elevated: {cpu}%",
                    "deduction": d,
                }
            )
            score -= d
        elif cpu > 30:
            d = 15
            findings.append({"severity": "low", "item": f"CPU usage slightly high: {cpu}%", "deduction": d})
            score -= d

    mem = data.get("memory_mb")
    if mem is not None:
        if mem > 1024:
            d = 25
            findings.append(
                {
                    "severity": "medium",
                    "item": f"High memory usage: {mem:.0f}MB",
                    "deduction": d,
                }
            )
            score -= d
        elif mem > 500:
            d = 10
            findings.append(
                {
                    "severity": "low",
                    "item": f"Memory usage elevated: {mem:.0f}MB",
                    "deduction": d,
                }
            )
            score -= d

    threads = data.get("threads")
    if threads is not None:
        if threads > 200:
            d = 20
            findings.append({"severity": "medium", "item": f"Too many threads: {threads}", "deduction": d})
            score -= d
        elif threads > 100:
            d = 10
            findings.append({"severity": "low", "item": f"Thread count elevated: {threads}", "deduction": d})
            score -= d

    return _clamp(score), findings


def score_logs(data: dict[str, Any]) -> tuple[float, list[dict]]:
    score = 100.0
    findings: list[dict] = []

    if not data.get("logs_dir_exists"):
        return 50, [{"severity": "medium", "item": "Log directory does not exist", "deduction": 50}]

    if not data.get("logs_dir_writable"):
        d = 25
        findings.append({"severity": "medium", "item": "Log directory is not writable", "deduction": d})
        score -= d

    errors = data.get("error_count_24h", 0)
    if errors > 20:
        d = 40
        findings.append({"severity": "high", "item": f"Too many ERROR log entries: {errors}", "deduction": d})
        score -= d
    elif errors > 5:
        d = 25
        findings.append(
            {
                "severity": "medium",
                "item": f"Elevated ERROR log count: {errors}",
                "deduction": d,
            }
        )
        score -= d
    elif errors > 0:
        d = 10
        findings.append({"severity": "low", "item": f"Some ERROR entries present: {errors}", "deduction": d})
        score -= d

    warnings = data.get("warning_count_24h", 0)
    if warnings > 20:
        d = 20
        findings.append(
            {
                "severity": "medium",
                "item": f"Many WARNING entries: {warnings}",
                "deduction": d,
            }
        )
        score -= d
    elif warnings > 5:
        d = 10
        findings.append({"severity": "low", "item": f"Elevated WARNING count: {warnings}", "deduction": d})
        score -= d

    panics = data.get("panic_traceback_count", 0)
    if panics > 0:
        d = 25
        findings.append(
            {
                "severity": "high",
                "item": f"Traceback/panic found: {panics} occurrence(s)",
                "deduction": d,
            }
        )
        score -= d

    log_size = data.get("latest_log_size_bytes", 0)
    if log_size > 500 * 1024 * 1024:
        d = 30
        findings.append(
            {
                "severity": "high",
                "item": f"Log file too large: {log_size / 1024 / 1024:.0f}MB",
                "deduction": d,
            }
        )
        score -= d
    elif log_size > 100 * 1024 * 1024:
        d = 15
        findings.append(
            {
                "severity": "medium",
                "item": f"Log file large: {log_size / 1024 / 1024:.0f}MB",
                "deduction": d,
            }
        )
        score -= d

    return _clamp(score), findings


def score_auth_security(data: dict[str, Any]) -> tuple[float, list[dict]]:
    score = 100.0
    findings: list[dict] = []

    if data.get("api_key_in_logs"):
        d = 50
        findings.append(
            {
                "severity": "critical",
                "item": "API key may be exposed in logs!",
                "deduction": d,
            }
        )
        score -= d

    for sf in data.get("sensitive_files", []):
        if sf.get("status") == "too_permissive":
            d = 25
            findings.append(
                {
                    "severity": "high",
                    "item": f"Sensitive file permissions too open: {sf.get('path')} ({sf.get('permissions')})",
                    "deduction": d,
                }
            )
            score -= d

    return _clamp(score), findings


def score_network(data: dict[str, Any]) -> tuple[float, list[dict]]:
    score = 100.0
    findings: list[dict] = []

    if not data.get("dns_resolution"):
        d = 25
        findings.append({"severity": "medium", "item": "DNS resolution failure", "deduction": d})
        score -= d

    if data.get("firewall_enabled") is False:
        d = 15
        findings.append({"severity": "low", "item": "Firewall not enabled", "deduction": d})
        score -= d

    # Check for 0.0.0.0 bindings
    for port_line in data.get("listening_ports", []):
        if "0.0.0.0" in port_line or "*:" in port_line:
            d = 10
            findings.append(
                {
                    "severity": "low",
                    "item": f"Service listening on all interfaces: {port_line[:80]}",
                    "deduction": d,
                }
            )
            score -= d
            break  # only deduct once

    return _clamp(score), findings


def score_storage(data: dict[str, Any]) -> tuple[float, list[dict]]:
    score = 100.0
    findings: list[dict] = []

    free_pct = data.get("disk_free_percent")
    if free_pct is not None:
        if free_pct < 10:
            d = 40
            findings.append(
                {
                    "severity": "critical",
                    "item": f"Disk space critically low: only {free_pct}% remaining",
                    "deduction": d,
                }
            )
            score -= d
        elif free_pct < 20:
            d = 15
            findings.append(
                {
                    "severity": "medium",
                    "item": f"Disk space low: {free_pct}% remaining",
                    "deduction": d,
                }
            )
            score -= d

    lc_size = data.get("lightclaw_dir_size_bytes", 0)
    if lc_size > 5 * 1024**3:
        d = 25
        findings.append(
            {
                "severity": "medium",
                "item": f"LightClaw data directory too large: {data.get('lightclaw_dir_size')}",
                "deduction": d,
            }
        )
        score -= d
    elif lc_size > 1024**3:
        d = 10
        findings.append(
            {
                "severity": "low",
                "item": f"LightClaw data directory large: {data.get('lightclaw_dir_size')}",
                "deduction": d,
            }
        )
        score -= d

    return _clamp(score), findings


def score_host_environment(data: dict[str, Any]) -> tuple[float, list[dict]]:
    score = 100.0
    findings: list[dict] = []

    if data.get("running_as_root"):
        d = 25
        findings.append({"severity": "high", "item": "LightClaw running as root", "deduction": d})
        score -= d

    py_ver = data.get("python_version", "0.0.0")
    major, minor = 0, 0
    try:
        parts = py_ver.split(".")
        major, minor = int(parts[0]), int(parts[1])
    except (ValueError, IndexError):
        pass
    if major == 3 and minor < 10:
        d = 15 if minor < 8 else 10
        findings.append({"severity": "medium", "item": f"Python version outdated: {py_ver}", "deduction": d})
        score -= d

    uptime = data.get("uptime_seconds")
    if uptime and uptime > 365 * 86400:
        d = 10
        findings.append(
            {
                "severity": "low",
                "item": f"System has not rebooted in over a year: {data.get('uptime_human')}",
                "deduction": d,
            }
        )
        score -= d

    if data.get("ssh_password_auth") == "yes":
        d = 15
        findings.append({"severity": "medium", "item": "SSH password authentication enabled", "deduction": d})
        score -= d

    if data.get("ssh_root_login") == "yes":
        d = 15
        findings.append({"severity": "medium", "item": "SSH root login permitted", "deduction": d})
        score -= d

    return _clamp(score), findings


def score_lightclaw_config(data: dict[str, Any]) -> tuple[float, list[dict]]:
    score = 100.0
    findings: list[dict] = []

    if not data.get("config_parseable"):
        return 0, [
            {
                "severity": "critical",
                "item": f"Config file could not be parsed: {data.get('error')}",
                "deduction": 100,
            }
        ]

    if not data.get("has_providers"):
        d = 25
        findings.append({"severity": "medium", "item": "No providers configured", "deduction": d})
        score -= d

    if not data.get("has_skills"):
        d = 10
        findings.append({"severity": "low", "item": "No skills enabled", "deduction": d})
        score -= d

    interval = data.get("heartbeat_interval")
    if interval and isinstance(interval, str):
        # Parse interval like "5m", "1h"
        match_m = None
        if interval.endswith("m"):
            with contextlib.suppress(ValueError):
                match_m = int(interval[:-1])
        if match_m is not None and match_m < 5:
            d = 10
            findings.append(
                {
                    "severity": "low",
                    "item": f"Heartbeat interval too short: {interval}",
                    "deduction": d,
                }
            )
            score -= d

    return _clamp(score), findings


def score_dependencies(data: dict[str, Any]) -> tuple[float, list[dict]]:
    score = 100.0
    findings: list[dict] = []

    vulns = data.get("known_vulnerabilities", 0)
    if vulns > 0:
        d = min(50, vulns * 15)
        findings.append({"severity": "high", "item": f"{vulns} known vulnerabilities found", "deduction": d})
        score -= d

    pip_source = data.get("pip_source", "")
    if (
        pip_source
        and "pypi.org" not in pip_source
        and "tuna" not in pip_source
        and "aliyun" not in pip_source
        and "default" not in pip_source.lower()
    ):
        d = 10
        findings.append(
            {
                "severity": "low",
                "item": f"Non-standard pip source in use: {pip_source}",
                "deduction": d,
            }
        )
        score -= d

    return _clamp(score), findings


SCORERS = {
    "process": score_process,
    "logs": score_logs,
    "auth_security": score_auth_security,
    "network": score_network,
    "storage": score_storage,
    "host_environment": score_host_environment,
    "lightclaw_config": score_lightclaw_config,
    "dependencies": score_dependencies,
}


def compute_scores(report_data: dict[str, Any]) -> dict[str, Any]:
    checks = report_data.get("checks", {})
    results: dict[str, Any] = {
        "dimensions": {},
        "total_score": 0,
        "rating": "",
        "rating_title": "",
        "all_findings": [],
    }

    weighted_sum = 0.0
    for dim_key, weight in DIMENSION_WEIGHTS.items():
        dim_data = checks.get(dim_key, {})
        scorer = SCORERS.get(dim_key)
        if scorer:
            raw_score, findings = scorer(dim_data)
        else:
            raw_score, findings = 100.0, []

        # Weighted contribution
        weighted = raw_score * weight / 100
        weighted_sum += weighted

        results["dimensions"][dim_key] = {
            "label": DIMENSION_LABELS.get(dim_key, dim_key),
            "weight": weight,
            "raw_score": round(raw_score, 1),
            "weighted_score": round(weighted, 1),
            "max_weighted_score": weight,
            "findings": findings,
        }
        for f in findings:
            f["dimension"] = DIMENSION_LABELS.get(dim_key, dim_key)
            results["all_findings"].append(f)

    results["total_score"] = round(weighted_sum, 1)

    # Rating
    for threshold, grade, title in RATINGS:
        if results["total_score"] >= threshold:
            results["rating"] = grade
            results["rating_title"] = title
            break

    # Sort findings by severity
    severity_order = {"critical": 0, "high": 1, "medium": 2, "low": 3}
    results["all_findings"].sort(key=lambda x: severity_order.get(x.get("severity", "low"), 9))

    return results


def main() -> None:
    raw = sys.stdin.read()
    report_data = json.loads(raw)
    scores = compute_scores(report_data)

    # Merge scores into report
    output = {
        "raw_data": report_data,
        "scores": scores,
    }
    print(json.dumps(output, indent=2, ensure_ascii=False, default=str))


if __name__ == "__main__":
    main()
