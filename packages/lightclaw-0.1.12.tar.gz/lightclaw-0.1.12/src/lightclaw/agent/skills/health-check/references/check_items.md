# 手动检查命令参考

当自检脚本无法运行时，可按以下命令逐项手动收集数据。

> 注意：以下命令需要根据操作系统调整。标注了 `[macOS]` 或 `[Linux]` 的为特定平台命令。

---

## 🫀 维度一：进程生命体征

```bash
# 查找 LightClaw 进程
ps aux | grep -i lightclaw | grep -v grep

# 查看进程详情 (替换 <PID>)
ps -p <PID> -o pid,%cpu,%mem,rss,vsz,etime,command

# [macOS] 查看线程数
ps -M -p <PID> | wc -l

# [Linux] 查看线程数
ls /proc/<PID>/task | wc -l

# 查看进程打开的文件数
lsof -p <PID> | wc -l
```

## 🧠 维度二：日志观测

```bash
# 日志目录
ls -la ~/.lightclaw/logs/

# 最近日志大小
du -sh ~/.lightclaw/logs/*

# ERROR 统计
grep -c "ERROR" ~/.lightclaw/logs/lightclaw.log*

# WARNING 统计
grep -c "WARNING" ~/.lightclaw/logs/lightclaw.log*

# 最近错误
grep "ERROR" ~/.lightclaw/logs/lightclaw.log | tail -20

# Traceback 统计
grep -c "Traceback" ~/.lightclaw/logs/lightclaw.log*
```

## 🔐 维度三：认证与密钥安全

```bash
# 检查配置文件权限
ls -la ~/.lightclaw/lightclaw.json
ls -la ~/.lightclaw/providers.json
ls -la ~/.lightclaw/.env 2>/dev/null

# 检查日志中是否有 API Key 泄露
grep -rn "sk-" ~/.lightclaw/logs/ 2>/dev/null | head -5
grep -rn "api_key" ~/.lightclaw/logs/ 2>/dev/null | head -5
```

## 🌐 维度四：网络安全

```bash
# [macOS] 查看监听端口
lsof -iTCP -sTCP:LISTEN -nP

# [Linux] 查看监听端口
ss -tlnp

# DNS 解析测试
nslookup api.openai.com

# 防火墙状态
# [macOS]
/usr/libexec/ApplicationFirewall/socketfilterfw --getglobalstate
# [Linux]
ufw status 2>/dev/null || firewall-cmd --state 2>/dev/null

# 活跃连接
# [macOS]
lsof -i -nP | grep ESTABLISHED | head -20
# [Linux]
ss -tnp | grep ESTAB | head -20
```

## 💾 维度五：存储与数据安全

```bash
# 磁盘总体使用率
df -h /

# LightClaw 数据目录大小
du -sh ~/.lightclaw/

# 各子目录大小
du -sh ~/.lightclaw/workspace/skills/
du -sh ~/.lightclaw/workspace/memory/
du -sh ~/.lightclaw/workspace/uploads/
du -sh ~/.lightclaw/logs/

# /tmp 中的 LightClaw 临时文件
ls /tmp/*lightclaw* 2>/dev/null | wc -l
```

## 🖥️ 维度六：宿主环境安全

```bash
# 操作系统信息
uname -a

# Python 版本
python3 --version

# 当前用户
whoami

# 系统运行时间
uptime

# [Linux] SSH 配置
grep -i "PasswordAuthentication\|PermitRootLogin" /etc/ssh/sshd_config 2>/dev/null

# [macOS] 安全更新
softwareupdate -l 2>&1

# [Linux] 安全更新
apt list --upgradable 2>/dev/null | grep -i security
```

## ⚙️ 维度七：LightClaw 配置健康

```bash
# 验证配置文件 JSON 格式
python3 -m json.tool ~/.lightclaw/lightclaw.json > /dev/null && echo "JSON OK" || echo "JSON INVALID"

# 查看配置结构 (不泄露敏感信息)
python3 -c "
import json
with open('$HOME/.lightclaw/lightclaw.json') as f:
    c = json.load(f)
print('Top keys:', list(c.keys()))
skills = c.get('skills', {}).get('entries', {})
enabled = [k for k, v in skills.items() if v.get('enabled')]
print('Enabled skills:', enabled)
"

# 检查 Provider 配置
python3 -c "
import json
with open('$HOME/.lightclaw/providers.json') as f:
    p = json.load(f)
if isinstance(p, list):
    print(f'Providers: {len(p)}')
    for x in p:
        print(f'  - {x.get(\"name\", \"unknown\")}')
"
```

## 🛡️ 维度八：依赖与供应链安全

```bash
# pip 源
pip config get global.index-url 2>/dev/null || echo "using default pypi"

# LightClaw 版本
pip show lightclaw 2>/dev/null | grep Version

# 关键依赖版本
pip show fastapi uvicorn langchain-core pydantic httpx 2>/dev/null | grep -E "^(Name|Version)"

# 安全审计 (需要安装 pip-audit)
pip audit 2>/dev/null || echo "pip-audit not installed"
```
