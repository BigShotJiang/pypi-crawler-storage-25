"""Allow running LightClaw via ``python -m lightclaw``."""

from lightclaw.cli.main import cli

if __name__ == "__main__":
    cli()  # pylint: disable=no-value-for-parameter
