import logging
import os
import time
from importlib.metadata import version

from lightclaw.constant import LOG_LEVEL_ENV
from lightclaw.utils.logging import setup_logger

__version__ = version("lightclaw")

_t0 = time.perf_counter()
setup_logger(os.environ.get(LOG_LEVEL_ENV, "info"))
logging.getLogger(__name__).debug(
    "%.3fs package init",
    time.perf_counter() - _t0,
)
