# turkman_ocr

**Turkmen language LSTM model for Tesseract OCR**

O'zbek tilida: Tesseract OCR uchun Turkman tili LSTM modeli.

## O'rnatish

```bash
pip install turkman_ocr
```

## Ishlatish

### 1. Model faylini tessdata papkasiga o'rnatish

```python
import turkman_ocr

# Avtomatik topib o'rnatadi
turkman_ocr.install()

# Yoki yo'lni o'zingiz ko'rsating:
turkman_ocr.install(tessdata_dir=r"C:\Program Files\Tesseract-OCR\tessdata")
```

### 2. Model faylining yo'lini olish

```python
import turkman_ocr

path = turkman_ocr.get_model_path()
print(path)  # .../site-packages/turkman_ocr/data/turkman_ocr.lstm
```

### 3. Package ma'lumotlari

```python
import turkman_ocr
import pprint

pprint.pprint(turkman_ocr.info())
# {
#   'package': 'turkman_ocr',
#   'version': '0.1.0',
#   'model_size_mb': 3.12,
#   'language': 'Turkmen (tuk)',
#   'engine': 'Tesseract LSTM',
#   'tessdata_dir': 'C:\\Program Files\\Tesseract-OCR\\tessdata',
#   'model_installed': True,
#   ...
# }
```

### 4. Tesseract bilan OCR qilish

```python
import turkman_ocr
import pytesseract
from PIL import Image

# Avval o'rnating
turkman_ocr.install()

# Keyin ishlatish
img = Image.open("rasm.png")
text = pytesseract.image_to_string(img, lang="turkman_ocr")
print(text)
```

### 5. O'chirish

```python
import turkman_ocr
turkman_ocr.uninstall()
```

## Talablar

- Python 3.7+
- [Tesseract OCR](https://github.com/UB-Mannheim/tesseract/wiki) o'rnatilgan bo'lishi kerak

## Litsenziya

MIT License
