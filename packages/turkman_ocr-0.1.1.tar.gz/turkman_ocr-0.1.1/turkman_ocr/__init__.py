"""
turkman_ocr — Turkmen language LSTM model for Tesseract OCR.

Quick start:
    import turkman_ocr

    # Model faylining yo'lini olish
    path = turkman_ocr.get_model_path()

    # Tesseract tessdata papkasiga o'rnatish
    turkman_ocr.install()

    # O'rnatilgan yo'lni tekshirish
    turkman_ocr.info()
"""

import os
import shutil
import pathlib

__version__ = "0.1.1"
__author__  = "turkman-ocr"
__license__ = "MIT"

# Package ichidagi data papkasi
_DATA_DIR  = pathlib.Path(__file__).parent / "data"
_MODEL_FILE = _DATA_DIR / "tuk.traineddata"


def get_model_path() -> pathlib.Path:
    """
    Package ichidagi LSTM model faylining to'liq yo'lini qaytaradi.

    Returns:
        pathlib.Path: tuk.traineddata faylining yo'li

    Example:
        >>> import turkman_ocr
        >>> print(turkman_ocr.get_model_path())
    """
    if not _MODEL_FILE.exists():
        raise FileNotFoundError(
            f"LSTM model topilmadi: {_MODEL_FILE}\n"
            "Qayta o'rnating: pip install --force-reinstall turkman_ocr"
        )
    return _MODEL_FILE


def get_tessdata_dir() -> pathlib.Path | None:
    """
    Tizimda Tesseract tessdata papkasini avtomatik topadi.

    Returns:
        pathlib.Path | None: Topilsa yo'l, topilmasa None

    Example:
        >>> import turkman_ocr
        >>> print(turkman_ocr.get_tessdata_dir())
    """
    # 1) Muhit o'zgaruvchisi
    env = os.environ.get("TESSDATA_PREFIX")
    if env and pathlib.Path(env).is_dir():
        return pathlib.Path(env)

    # 2) Windows standart yo'llar
    win_paths = [
        pathlib.Path(r"C:\Program Files\Tesseract-OCR\tessdata"),
        pathlib.Path(r"C:\Program Files (x86)\Tesseract-OCR\tessdata"),
    ]
    for p in win_paths:
        if p.is_dir():
            return p

    # 3) Linux/macOS standart yo'llar
    unix_paths = [
        pathlib.Path("/usr/share/tesseract-ocr/4.00/tessdata"),
        pathlib.Path("/usr/share/tesseract-ocr/5/tessdata"),
        pathlib.Path("/usr/local/share/tessdata"),
        pathlib.Path("/opt/homebrew/share/tessdata"),
    ]
    for p in unix_paths:
        if p.is_dir():
            return p

    return None


def install(tessdata_dir: str | pathlib.Path | None = None) -> pathlib.Path:
    """
    LSTM model faylini Tesseract tessdata papkasiga ko'chiradi.

    Args:
        tessdata_dir: Tesseract tessdata papkasi yo'li.
                      None bo'lsa avtomatik topadi.

    Returns:
        pathlib.Path: Nusxa olingan faylning yo'li

    Raises:
        FileNotFoundError: tessdata papkasi topilmasa
        PermissionError: Write huquqi yo'q bo'lsa

    Example:
        >>> import turkman_ocr
        >>> dest = turkman_ocr.install()
        >>> print(f"O'rnatildi: {dest}")
    """
    if tessdata_dir is None:
        tessdata_dir = get_tessdata_dir()
        if tessdata_dir is None:
            raise FileNotFoundError(
                "Tesseract tessdata papkasi topilmadi!\n"
                "Masalan: turkman_ocr.install(tessdata_dir=r'C:\\Program Files\\Tesseract-OCR\\tessdata')"
            )

    tessdata_dir = pathlib.Path(tessdata_dir)
    if not tessdata_dir.is_dir():
        raise FileNotFoundError(f"Ko'rsatilgan papka mavjud emas: {tessdata_dir}")

    src  = get_model_path()
    dest = tessdata_dir / "tuk.traineddata"

    shutil.copy2(src, dest)
    print(f"✅ Model muvaffaqiyatli o'rnatildi: {dest}")
    return dest


def uninstall(tessdata_dir: str | pathlib.Path | None = None) -> bool:
    """
    O'rnatilgan LSTM model faylini tessdata papkasidan o'chiradi.

    Args:
        tessdata_dir: Tesseract tessdata papkasi yo'li.
                      None bo'lsa avtomatik topadi.

    Returns:
        bool: O'chirilsa True, fayl topilmasa False

    Example:
        >>> import turkman_ocr
        >>> turkman_ocr.uninstall()
    """
    if tessdata_dir is None:
        tessdata_dir = get_tessdata_dir()
        if tessdata_dir is None:
            print("tessdata papkasi topilmadi.")
            return False

    dest = pathlib.Path(tessdata_dir) / "tuk.traineddata"
    if dest.exists():
        dest.unlink()
        print(f"🗑️  O'chirildi: {dest}")
        return True
    else:
        print(f"Fayl topilmadi: {dest}")
        return False


def info() -> dict:
    """
    Package va model haqida to'liq ma'lumot qaytaradi.

    Returns:
        dict: Version, model hajmi, tessdata yo'li va h.k.

    Example:
        >>> import turkman_ocr
        >>> import pprint
        >>> pprint.pprint(turkman_ocr.info())
    """
    model = get_model_path()
    tessdata = get_tessdata_dir()
    installed_path = (pathlib.Path(tessdata) / "tuk.traineddata") if tessdata else None
    is_installed = installed_path is not None and installed_path.exists()

    return {
        "package"           : "turkman_ocr",
        "version"           : __version__,
        "model_file"        : str(model),
        "model_size_mb"     : round(model.stat().st_size / 1_048_576, 2),
        "language"          : "Turkmen (tuk)",
        "engine"            : "Tesseract LSTM",
        "tessdata_dir"      : str(tessdata) if tessdata else "Topilmadi",
        "model_installed"   : is_installed,
        "installed_path"    : str(installed_path) if is_installed else "O'rnatilmagan",
    }
