from types import EllipsisType
from typing import Any

import numpy as np
import numpy.typing as npt
import pytest

from tests.numpy.common import IsEvenValidator
from valarray.core.data_structures import AxisNameAndIdx, FieldNameAndIdx
from valarray.core.errors_exceptions import IncorrectAxSizesError, ValidationErrorList
from valarray.core.validation_functions import validate_array as core_validate_array
from valarray.core.validation_functions import (
    validate_array_values as core_validate_array_values,
)
from valarray.core.validation_functions import validate_dtype as core_validate_dtype
from valarray.core.validation_functions import (
    validate_field_values as core_validate_field_values,
)
from valarray.core.validators import ComparisonValidator
from valarray.numpy import Field, NumpyComparisons, NumpyValidator
from valarray.numpy.array_type_adapter import NumpyArrayTypeAdapter
from valarray.numpy.axes_and_fields import AxesTuple
from valarray.numpy.errors_exceptions import (
    NumpyIncorrectDTypeError,
    NumpyInvalidArrayValuesError,
    NumpyInvalidFieldValuesError,
)
from valarray.numpy.validation_functions import (
    validate_array,
    validate_array_values,
    validate_dtype,
    validate_field_values,
)


@pytest.mark.parametrize(
    "expected_dtypelike, expected_errs",
    [
        (..., []),
        (np.float32, []),
        (
            np.float64,
            [
                NumpyIncorrectDTypeError(
                    np.dtype(np.float32), np.dtype(np.float64), np.float64
                )
            ],
        ),
    ],
)
def test_validate_numpy_dtype(
    expected_dtypelike: npt.DTypeLike | EllipsisType,
    expected_errs: ValidationErrorList[NumpyIncorrectDTypeError],
):
    arr = np.array([1, 2, 3], dtype=np.float32)

    errs = core_validate_dtype(arr, expected_dtypelike, NumpyArrayTypeAdapter())

    assert errs == expected_errs, "actual/expected values for 'errs' are not equal"

    errs = validate_dtype(arr, expected_dtypelike)

    assert errs == expected_errs, "actual/expected values for 'errs' are not equal"


ARR = np.array([[1, 2, 3, 4], [5, 6, 7, 8]], dtype=np.uint8)

INDICES_BOOL = np.array([[1, 0, 1, 0], [1, 0, 1, 0]], dtype=np.bool_)
INDICES_TUPLE = (np.array([0, 0, 1, 1]), np.array([0, 2, 0, 2]))

INVALID_VALS = [1, 3, 5, 7]

ERRS_BOOL = ValidationErrorList(
    [
        NumpyInvalidArrayValuesError(
            IsEvenValidator("bool"),
            invalid_values=INVALID_VALS,
            invalid_indices=INDICES_BOOL,
        )
    ]
)

ERRS_TUPLE = ValidationErrorList(
    [
        NumpyInvalidArrayValuesError(
            IsEvenValidator("tuple"),
            invalid_values=INVALID_VALS,
            invalid_indices=INDICES_TUPLE,
        )
    ]
)


@pytest.mark.parametrize(
    "arr, validator, expected_errs",
    [
        (ARR, IsEvenValidator("bool"), ERRS_BOOL),
        (ARR, IsEvenValidator("tuple"), ERRS_TUPLE),
    ],
)
def test_validate_array_values(
    arr: npt.NDArray[np.uint8],
    validator: NumpyValidator,
    expected_errs: ValidationErrorList[NumpyInvalidArrayValuesError],
):
    errs = core_validate_array_values(arr, [validator], NumpyArrayTypeAdapter())

    assert errs == expected_errs, "actual/expected values for 'errs' are not equal"

    errs = validate_array_values(arr, [validator])

    assert errs == expected_errs, "actual/expected values for 'errs' are not equal"


ARR2 = np.array([[1, 2, 3, 4], [2, 3, 4, 5]], dtype=np.uint8)
ARR3 = np.array([[1, 2, 3, 4, 5], [2, 3, 4, 5, 6]], dtype=np.uint8)

SCHEMA = (
    2,
    (
        Field("a", validators=(IsEvenValidator("bool"),)),
        "b",
        "c",
        Field("d", validators=(IsEvenValidator("tuple"),)),
    ),
)


ERRS_FIELD = [
    NumpyInvalidFieldValuesError(
        validator=IsEvenValidator("bool"),
        invalid_values={AxisNameAndIdx(1, "_sized_4"): {FieldNameAndIdx(0, "a"): [1]}},
    ),
    NumpyInvalidFieldValuesError(
        validator=IsEvenValidator("tuple"),
        invalid_values={AxisNameAndIdx(1, "_sized_4"): {FieldNameAndIdx(3, "d"): [5]}},
    ),
]

ERRS_SHAPE = [IncorrectAxSizesError((2, 5), (2, 4), [1])]


@pytest.mark.parametrize(
    "arr, schema, check_shape, expected_errs",
    [
        (ARR2, SCHEMA, False, ERRS_FIELD),
        (ARR3, SCHEMA, True, ERRS_SHAPE),
    ],
)
def test_validate_field_values(
    arr: npt.NDArray[np.uint8],
    schema: AxesTuple,
    check_shape: bool,
    expected_errs: ValidationErrorList[NumpyInvalidFieldValuesError],
):
    errs = core_validate_field_values(arr, schema, NumpyArrayTypeAdapter(), check_shape)

    assert errs == expected_errs, "actual/expected values for 'errs' are not equal"

    errs = validate_field_values(arr, schema, check_shape)

    assert errs == expected_errs, "actual/expected values for 'errs' are not equal"


DTYPE = "uint8"
SCHEMA = (2, 2, (Field("first", ge=5), "second"))
VAL = ComparisonValidator("lt", 20, NumpyComparisons())
VALIDATORS = [VAL]

ARR_OK = np.array(
    [
        [
            [10, 10],
            [10, 10],
        ],
        [
            [10, 10],
            [10, 10],
        ],
    ],
    dtype=np.uint8,
)

ARR_WRONG_SHAPE_DTYPE = np.array(
    [
        [
            [10, 10],
        ],
        [
            [10, 10],
        ],
    ],
    dtype=np.float32,
)

ARR_WRONG_FIELD_ARRAY_VAL = np.array(
    [
        [
            [3, 10],
            [10, 10],
        ],
        [
            [10, 5],
            [10, 30],
        ],
    ],
    dtype=np.uint8,
)

ERRS_WRONG_SHAPE_DTYPE = ValidationErrorList(
    [
        NumpyIncorrectDTypeError(np.dtype(np.float32), np.dtype(np.uint8), "uint8"),
        IncorrectAxSizesError((2, 1, 2), (2, 2, 2), [1]),
    ]
)
ERRS_WRONG_FIELD_ARRAY_VAL = ValidationErrorList(
    [
        NumpyInvalidArrayValuesError(
            VAL, [30], (np.array(1), np.array(1), np.array(1))
        ),
        NumpyInvalidFieldValuesError(
            ComparisonValidator("ge", 5, NumpyComparisons()),
            {AxisNameAndIdx(2, "_sized_2"): {FieldNameAndIdx(0, "first"): [3]}},
        ),
    ]
)


@pytest.mark.parametrize(
    "arr, expected_errs",
    [
        (ARR_OK, []),
        (ARR_WRONG_SHAPE_DTYPE, ERRS_WRONG_SHAPE_DTYPE),
        (ARR_WRONG_FIELD_ARRAY_VAL, ERRS_WRONG_FIELD_ARRAY_VAL),
    ],
)
def test_validate_array(arr: npt.NDArray[Any], expected_errs: ValidationErrorList):
    errs = core_validate_array(arr, DTYPE, SCHEMA, VALIDATORS, NumpyArrayTypeAdapter())

    assert errs == expected_errs, "actual/expected values for 'errs' are not equal"

    errs = validate_array(arr, DTYPE, SCHEMA, VALIDATORS)

    assert errs == expected_errs, "actual/expected values for 'errs' are not equal"
