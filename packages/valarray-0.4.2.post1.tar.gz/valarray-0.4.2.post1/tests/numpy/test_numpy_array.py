from contextlib import nullcontext as does_not_raise

import numpy as np
import pytest

from tests.numpy.common import IsEvenValidator
from valarray.core.errors_exceptions import ValidationException
from valarray.numpy import Field, ValidatedNumpyArray


class TestValidatedNumpyArray(ValidatedNumpyArray[np.float32]):
    dtype = np.float32
    schema = (3,)


DATA = [1, 2, 3]
WRONG_SHAPE_DATA = [1, 2]

ARR_CORRECT_DTYPE = np.array(DATA, dtype=np.float32)
ARR_WRONG_DTYPE = np.array(DATA, dtype=np.uint8)
ARR_CORRECT_DTYPE_WRONG_SHAPE = np.array(WRONG_SHAPE_DATA, dtype=np.float32)
ARR_WRONG_DTYPE_WRONG_SHAPE = np.array(WRONG_SHAPE_DATA, dtype=np.uint8)


def test_array():
    TestValidatedNumpyArray(ARR_CORRECT_DTYPE)
    TestValidatedNumpyArray.wrap(ARR_CORRECT_DTYPE)
    TestValidatedNumpyArray.validate(ARR_CORRECT_DTYPE)


@pytest.mark.parametrize(
    "v_arr, is_considered_validated, expectation",
    [
        (TestValidatedNumpyArray.wrap(ARR_CORRECT_DTYPE), True, does_not_raise()),
        (TestValidatedNumpyArray.wrap(ARR_CORRECT_DTYPE), False, does_not_raise()),
        (TestValidatedNumpyArray.wrap(ARR_WRONG_DTYPE), True, does_not_raise()),
        (
            TestValidatedNumpyArray.wrap(ARR_WRONG_DTYPE),
            False,
            pytest.raises(ValidationException),
        ),
        (
            TestValidatedNumpyArray.wrap(ARR_CORRECT_DTYPE_WRONG_SHAPE),
            False,
            pytest.raises(ValidationException),
        ),
        (
            TestValidatedNumpyArray.wrap(ARR_WRONG_DTYPE_WRONG_SHAPE),
            False,
            pytest.raises(ValidationException),
        ),
    ],
)
def test_validate_array(
    v_arr: TestValidatedNumpyArray,
    is_considered_validated: bool,
    expectation: does_not_raise | pytest.RaisesExc[Exception],
):
    v_arr.is_validated = is_considered_validated

    with expectation:
        v_arr.validate_array()

    if not isinstance(expectation, does_not_raise):
        return

    assert v_arr.is_validated


def test_array_access():
    expected_arr = ARR_CORRECT_DTYPE

    v_arr = TestValidatedNumpyArray(ARR_CORRECT_DTYPE)

    arr = v_arr.array

    np.testing.assert_array_equal(
        arr, expected_arr, err_msg="actual/expected values in array 'arr' are not equal"
    )

    arr = v_arr.a_

    np.testing.assert_array_equal(
        arr, expected_arr, err_msg="actual/expected values in array 'arr' are not equal"
    )


class ExampleNumpyArray(ValidatedNumpyArray):
    dtype = int
    schema = (2, 2, (Field("first", ge=5), "second"))
    lt = 20
    validators = (IsEvenValidator("tuple"),)


STR = """ExampleNumpyArray (type: 'numpy')
  data type: '<class 'int'>' (int64)
  schema:
    Axis < 0 >
    Axis < 1 >
    Axis < 2 >
      Field < 0 > : 'first'
        Constraints: >= 5
      Field < 1 > : 'second'
  Constraints: < 20
  Validators:
    IsEvenValidator(indices_type='tuple')
  values:
    [[[10 10]
  [10 10]]

 [[10 10]
  [10 10]]]"""


def test_numpy_array_string():
    expected_string = STR
    string = str(
        ExampleNumpyArray(
            [
                [
                    [10, 10],
                    [10, 10],
                ],
                [
                    [10, 10],
                    [10, 10],
                ],
            ],
        )
    )

    assert (
        string == expected_string
    ), "actual/expected values for 'string' are not equal"
