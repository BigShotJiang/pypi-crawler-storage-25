from dataclasses import dataclass
from typing import Literal

import numpy as np

from valarray.core.validators import ValidationResult
from valarray.numpy import NumpyValidator
from valarray.numpy.types import AdvancedIndex


def coords_to_indices(coords_tuple: tuple[tuple[int, ...], ...]) -> AdvancedIndex:
    n_axes = len(coords_tuple[0])

    lst = [[] for _ in range(n_axes)]

    for coords in coords_tuple:
        for i, c in enumerate(coords):
            lst[i].append(c)

    return tuple(np.array(l, dtype=int) for l in lst)


@dataclass
class IsEvenValidator(NumpyValidator[np.uint8]):
    indices_type: Literal["bool", "tuple"]

    def validate(self, arr):
        even = arr % 2 == 0

        all_even = np.all(even)

        if all_even:
            return ValidationResult("OK")

        indices = ~even if self.indices_type == "bool" else np.where(~even)

        return ValidationResult("FAIL", indices)
