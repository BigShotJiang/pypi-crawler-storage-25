from contextlib import nullcontext as does_not_raise
from dataclasses import dataclass
from types import EllipsisType
from typing import Any, Optional

import numpy as np
import numpy.typing as npt
import pytest

from tests.numpy.common import coords_to_indices
from valarray.core.axes_and_fields import AxesTuple
from valarray.core.data_structures import AxisNameAndIdx, FieldNameAndIdx
from valarray.core.errors_exceptions import CoerceDTypeException, CreateArrayException
from valarray.core.types import AxSizes
from valarray.core.utils import setup_array
from valarray.numpy.array_type_adapter import NumpyArrayTypeAdapter
from valarray.numpy.types import AdvancedIndex

DATA = [1, 2, 3]
DATA_STR = ["a", "b"]

ARR_INT64 = np.array(DATA, dtype=np.int64)
ARR_FLOAT32 = np.array(DATA, dtype=np.float32)
ARR_STR = np.array(DATA_STR, dtype=np.str_)

EMPTY_ARR_WITH_SHAPE = np.empty(shape=(0, 2), dtype=np.float32)
EMPTY_ARR_WO_SHAPE = np.empty(shape=tuple(), dtype=np.float32)


@dataclass
class TestSupportsArray:
    data: list[Any]

    def __array__(self, dtype=None, copy=False):
        del copy
        return np.array(DATA, dtype)


@pytest.mark.parametrize(
    "dtypelike, obj, expected_array",
    [
        (np.float32, DATA, ARR_FLOAT32),
        (np.float32, TestSupportsArray(DATA), ARR_FLOAT32),
        (..., DATA, ARR_INT64),
        (..., TestSupportsArray(DATA), ARR_INT64),
    ],
)
def test_create_array(
    dtypelike: npt.DTypeLike | EllipsisType,
    obj: Any,
    expected_array: npt.NDArray[Any],
):
    array = NumpyArrayTypeAdapter().create_array(obj, dtypelike)

    np.testing.assert_array_equal(
        array,
        expected_array,
        err_msg="actual/expected values in array 'array' are not equal",
    )

    dtype = array.dtype
    expected_dtype = expected_array.dtype

    assert dtype == expected_dtype, "actual/expected values for 'dtype' are not equal"


@pytest.mark.parametrize(
    "ax_sizes, dtypelike, expected_shape, expected_dtype",
    [
        (tuple(), "float32", tuple(), np.float32),
        ((1, 2, None, 4), "float32", (0, 2, 0, 4), np.float32),
        ((None, 2, 3), "float32", (0, 2, 3), np.float32),
        ((1, 2), ..., (0, 2), np.float64),
    ],
)
def test_create_empty_array(
    ax_sizes: AxSizes,
    dtypelike: npt.DTypeLike | EllipsisType,
    expected_shape: tuple[int, ...],
    expected_dtype: np.dtype,
):
    array = NumpyArrayTypeAdapter().create_empty_array(ax_sizes, dtypelike)

    shape = array.shape
    dtype = array.dtype

    assert shape == expected_shape, "actual/expected values for 'shape' are not equal"
    assert dtype == expected_dtype, "actual/expected values for 'dtype' are not equal"


def test_is_empty_array():
    assert NumpyArrayTypeAdapter().is_array_empty(np.array([]))
    assert NumpyArrayTypeAdapter().is_array_empty(np.empty(shape=(0, 2, 2)))
    assert not NumpyArrayTypeAdapter().is_array_empty(np.array([1, 2, 3]))


@pytest.mark.parametrize(
    "dtypelike, obj, expected_array, coerce_dtype, schema, expectation",
    [
        (np.float32, ARR_INT64, ARR_INT64, False, ..., does_not_raise()),
        (np.float32, ARR_INT64, ARR_FLOAT32, True, ..., does_not_raise()),
        (np.float32, DATA, ARR_FLOAT32, None, ..., does_not_raise()),
        (np.float32, DATA_STR, ..., None, ..., pytest.raises(CreateArrayException)),
        (np.float32, ARR_STR, ARR_STR, False, ..., does_not_raise()),
        (np.float32, ARR_STR, ..., True, ..., pytest.raises(CoerceDTypeException)),
        (np.float32, None, EMPTY_ARR_WITH_SHAPE, None, (1, 2), does_not_raise()),
        (np.float32, None, EMPTY_ARR_WO_SHAPE, None, ..., does_not_raise()),
        (..., ARR_INT64, ARR_INT64, False, ..., does_not_raise()),
        (..., ARR_INT64, ARR_INT64, True, ..., does_not_raise()),
        (..., DATA, ARR_INT64, None, ..., does_not_raise()),
    ],
)
def test_setup_array(
    dtypelike: npt.DTypeLike | EllipsisType,
    obj: Any,
    expected_array: npt.NDArray[Any],
    coerce_dtype: Optional[bool],
    schema: AxesTuple | EllipsisType,
    expectation: does_not_raise | pytest.RaisesExc[CreateArrayException],
):
    with expectation:
        array = setup_array(
            obj, dtypelike, coerce_dtype, schema, NumpyArrayTypeAdapter(), "dummy"
        )

    if not isinstance(expectation, does_not_raise):
        return

    # HACK: In this case the arr values are non deterministic, so skip
    skip_arr_comp = obj is None and schema == ...

    if not skip_arr_comp:
        np.testing.assert_array_equal(
            array,
            expected_array,
            err_msg="actual/expected values in array 'array' are not equal",
        )

    dtype = array.dtype
    expected_dtype = expected_array.dtype

    assert dtype == expected_dtype, "actual/expected values for 'dtype' are not equal"

    shape = array.shape
    expected_shape = expected_array.shape

    assert shape == expected_shape, "actual/expected values for 'shape' are not equal"


FLOAT_2D_STUFF = [
    [1, 2, 3],
    [4, 5, 6],
    [7, 8, 9],
]

# fmt: off
IND_FLOAT_2D_STUFF_VALID = ((1, 0), (2, 2), )
IND_FLOAT_2D_STUFF_INVALID = ((1, 0), (3, 4), )
# fmt:on

IND_FLOAT_2D_STUFF_VALID_BOOL = np.array(
    [
        [False, False, False],
        [True, False, False],
        [False, False, True],
    ]
)

IND_FLOAT_2D_STUFF_INVALID_BOOL = np.array(
    [
        [False, False, False],
        [True, False, False],
        [False, False, True],
        [False, False, True],
    ]
)

IND_FLOAT_2D_STUFF_INVALID_STR = "fail"


@pytest.mark.parametrize(
    "stuff, indices, expected_vals",
    [
        (FLOAT_2D_STUFF, None, None),
        (FLOAT_2D_STUFF, coords_to_indices(IND_FLOAT_2D_STUFF_VALID), [4, 9]),
        (FLOAT_2D_STUFF, coords_to_indices(IND_FLOAT_2D_STUFF_INVALID), None),
        (FLOAT_2D_STUFF, IND_FLOAT_2D_STUFF_VALID_BOOL, [4, 9]),
        (FLOAT_2D_STUFF, IND_FLOAT_2D_STUFF_INVALID_BOOL, None),
        (FLOAT_2D_STUFF, IND_FLOAT_2D_STUFF_INVALID_STR, None),
    ],
)
def test_get_values(
    stuff: Any, indices: Optional[AdvancedIndex], expected_vals: Optional[list[Any]]
):
    arr = np.array(stuff)

    vals = NumpyArrayTypeAdapter().get_values(arr, indices)

    assert vals == expected_vals, "actual/expected values for 'vals' are not equal"


def test_select_subset():
    arr = np.array(
        [
            [[0, 1, 0, 1], [0, 1, 0, 1]],
            [[0, 1, 0, 1], [0, 1, 0, 1]],
            [[0, 1, 0, 1], [0, 1, 0, 1]],
        ]
    )

    expected_subset = np.array([[[1, 1], [1, 1]], [[1, 1], [1, 1]], [[1, 1], [1, 1]]])

    ax = AxisNameAndIdx(2)

    fields = [FieldNameAndIdx(1), FieldNameAndIdx(3)]

    subset = NumpyArrayTypeAdapter().select_subset(arr, ax, fields)

    np.testing.assert_array_equal(
        subset,
        expected_subset,
        err_msg="actual/expected values in array 'subset' are not equal",
    )


INDICES_BOOL = np.array(
    [
        [[0, 1, 0, 0], [0, 0, 0, 1]],
        [[0, 0, 0, 0], [0, 1, 0, 0]],
        [[1, 0, 0, 0], [0, 0, 0, 0]],
    ],
    dtype=np.bool_,
)

INDICES_TUPLE = (
    np.array([0, 0, 1, 2], dtype=np.int64),
    np.array([0, 1, 1, 0], dtype=np.int64),
    np.array([1, 3, 1, 0], dtype=np.int64),
)

EXPECTED_VALS = {
    FieldNameAndIdx(0): [1],
    FieldNameAndIdx(1): [1, 1],
}


@pytest.mark.parametrize(
    "indices, expected_vals",
    [
        (None, None),
        (INDICES_BOOL, EXPECTED_VALS),
        (INDICES_TUPLE, EXPECTED_VALS),
    ],
)
def test_get_values_from_subset(
    indices: AdvancedIndex | None, expected_vals: dict[FieldNameAndIdx, Any] | None
):
    arr = np.array(
        [
            [[0, 1, 0, 0], [0, 0, 0, 1]],
            [[0, 0, 0, 0], [0, 1, 0, 0]],
            [[1, 0, 0, 0], [0, 0, 0, 0]],
        ]
    )

    ata = NumpyArrayTypeAdapter()

    ax = AxisNameAndIdx(2)

    fields = [
        FieldNameAndIdx(0),
        FieldNameAndIdx(1),
        FieldNameAndIdx(3),
    ]

    vals = ata.get_values_from_subset(arr, indices, ax, fields)

    assert vals == expected_vals, "actual/expected values for 'vals' are not equal"
