import numpy as np
import pytest
from common import IsEvenValidator

from valarray.numpy.errors_exceptions import NumpyInvalidArrayValuesError

# NOTE: Cool, numpy does some optimization thing, where:
# a = b = np.array(<xyz>)
# => you can just use a == b
# but
# a = np.array(<xyz>)
# b = np.array(<xyz>)
# you need to use np.all(a == b)

INDICES_ARR1 = np.array([[1, 1, 0], [1, 0, 1]], dtype=np.bool_)
INDICES_ARR1B = np.array([[1, 1, 0], [1, 0, 1]], dtype=np.bool_)
INDICES_ARR2 = np.array([[0, 1, 1], [1, 1, 0]], dtype=np.bool_)

INDICES_TUPLE1 = (np.array([0, 1]), np.array([2, 1]))
INDICES_TUPLE1B = (np.array([0, 1]), np.array([2, 1]))

INDICES_TUPLE2 = (np.array([0, 1]), np.array([0, 2]))

ERR_BOOL1 = NumpyInvalidArrayValuesError(
    validator=IsEvenValidator("bool"), invalid_values=[1], invalid_indices=INDICES_ARR1
)
ERR_BOOL1B = NumpyInvalidArrayValuesError(
    validator=IsEvenValidator("bool"), invalid_values=[1], invalid_indices=INDICES_ARR1
)


ERR_BOOL2 = NumpyInvalidArrayValuesError(
    validator=IsEvenValidator("bool"), invalid_values=[1], invalid_indices=INDICES_ARR2
)

ERR_BOOL3 = NumpyInvalidArrayValuesError(
    validator=IsEvenValidator("bool"), invalid_values=[6], invalid_indices=INDICES_ARR1
)

ERR_TUPLE1 = NumpyInvalidArrayValuesError(
    validator=IsEvenValidator("tuple"),
    invalid_values=[1],
    invalid_indices=INDICES_TUPLE1,
)

ERR_TUPLE1B = NumpyInvalidArrayValuesError(
    validator=IsEvenValidator("tuple"),
    invalid_values=[1],
    invalid_indices=INDICES_TUPLE1B,
)

ERR_TUPLE2 = NumpyInvalidArrayValuesError(
    validator=IsEvenValidator("tuple"),
    invalid_values=[6],
    invalid_indices=INDICES_TUPLE2,
)


@pytest.mark.parametrize(
    "err, other_err, expected_truth_value",
    [
        (ERR_BOOL1, ERR_BOOL1, True),  # same (bool indices)
        (ERR_TUPLE1, ERR_TUPLE1, True),  # same (tuple indices)
        (ERR_BOOL1, ERR_BOOL1B, True),  # same (bool indices, different variables)
        (ERR_TUPLE1, ERR_TUPLE1B, True),  # same (tuple indices, different variables)
        (ERR_BOOL1, ERR_BOOL2, False),  # same validator, different indices (bool)
        (ERR_TUPLE1, ERR_TUPLE2, False),  # same validator, different indices (tuple)
        (ERR_BOOL1, ERR_TUPLE1, False),  # different validator (equivalent indices)
        (ERR_BOOL1, ERR_TUPLE2, False),  # different validator (non equivalent indices)
        (ERR_BOOL1, ERR_BOOL3, False),  # same indices, different invalid_values
        (ERR_BOOL1, ERR_TUPLE2, False),  # different everything
    ],
)
def test_numpy_invalid_array_values_error_equality(
    err: NumpyInvalidArrayValuesError,
    other_err: NumpyInvalidArrayValuesError,
    expected_truth_value: bool,
):
    res = err == other_err

    assert res is expected_truth_value
