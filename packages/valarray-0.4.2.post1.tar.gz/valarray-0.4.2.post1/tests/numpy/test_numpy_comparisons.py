from typing import Any, Literal, Optional

import numpy as np
import pytest

from tests.numpy.common import coords_to_indices
from valarray.core.types import ComparisonOperator
from valarray.core.validators import ComparisonValidator
from valarray.numpy import NumpyComparisons
from valarray.numpy.types import AdvancedIndex

FLOAT_2D_STUFF = [
    [-4, -3, -2],
    [-1, 0, 1],
    [2, 3, 4],
]

# fmt: off
IND_FLOAT_2D_STUFF_GE_0 = ((0,0),(0,1),(0,2),(1,0),)
IND_FLOAT_2D_STUFF_GT_0 = ((0,0),(0,1),(0,2),(1,0),(1,1),)
IND_FLOAT_2D_STUFF_GT_NEG4 = ((0,0),)
IND_FLOAT_2D_STUFF_LE_0 = ((1,2),(2,0),(2,1),(2,2),)
IND_FLOAT_2D_STUFF_LT_0 = ((1,1),(1,2),(2,0),(2,1),(2,2),)
IND_FLOAT_2D_STUFF_LT_4 = ((2,2),)
# fmt:on


FLOAT_2D_GT0_STUFF = [
    [0, 0, 0],
    [0, -1, 0],
    [0, 0, 0],
]


FLOAT_2D_EQ0_STUFF = [
    [0, 0, 0],
    [0, 0, 0],
    [0, 0, 0],
]


FLOAT_2D_LT0_STUFF = [
    [0, 0, 0],
    [0, 1, 0],
    [0, 0, 0],
]

IND_FLOAT_2D_LT0_GT0 = ((1, 1),)

EMPTY_STUFF = []


@pytest.mark.parametrize(
    "stuff, val, operator, expected_status, expected_indices",
    [
        (FLOAT_2D_STUFF, 0, "ge", "FAIL", coords_to_indices(IND_FLOAT_2D_STUFF_GE_0)),
        (FLOAT_2D_STUFF, -4, "ge", "OK", None),
        (FLOAT_2D_STUFF, 0, "gt", "FAIL", coords_to_indices(IND_FLOAT_2D_STUFF_GT_0)),
        (
            FLOAT_2D_STUFF,
            -4,
            "gt",
            "FAIL",
            coords_to_indices(IND_FLOAT_2D_STUFF_GT_NEG4),
        ),
        (FLOAT_2D_STUFF, -5, "gt", "OK", None),
        (FLOAT_2D_STUFF, 0, "le", "FAIL", coords_to_indices(IND_FLOAT_2D_STUFF_LE_0)),
        (FLOAT_2D_STUFF, 4, "le", "OK", None),
        (FLOAT_2D_STUFF, 0, "lt", "FAIL", coords_to_indices(IND_FLOAT_2D_STUFF_LT_0)),
        (FLOAT_2D_STUFF, 4, "lt", "FAIL", coords_to_indices(IND_FLOAT_2D_STUFF_LT_4)),
        (FLOAT_2D_STUFF, 5, "lt", "OK", None),
        (FLOAT_2D_GT0_STUFF, 0, "eq", "FAIL", coords_to_indices(IND_FLOAT_2D_LT0_GT0)),
        (FLOAT_2D_EQ0_STUFF, 0, "eq", "OK", None),
        (FLOAT_2D_LT0_STUFF, 0, "eq", "FAIL", coords_to_indices(IND_FLOAT_2D_LT0_GT0)),
        (EMPTY_STUFF, 0, "eq", "OK", None),
        (EMPTY_STUFF, 0, "gt", "OK", None),
        (EMPTY_STUFF, 0, "lt", "OK", None),
    ],
)
def test_comparison_validator(
    stuff: Any,
    val: Any,
    operator: ComparisonOperator,
    expected_status: Literal["OK", "FAIL"],
    expected_indices: Optional[AdvancedIndex],
):
    arr = np.array(stuff)

    validator = ComparisonValidator(operator, val, NumpyComparisons())

    res = validator.validate(arr)

    assert (
        res.status == expected_status
    ), "actual/expected values for 'res.status' are not equal"
    np.testing.assert_array_equal(
        res.indices_invalid,
        expected_indices,
        err_msg="actual/expected values in array 'res.indices_invalid' are not equal",
    )


# fmt: off
IND_2D = ((0, 0),(0, 1),(0, 2),(1, 0),)
IND_3D = ((0, 0, 1),(0, 1, 1),(0, 2, 1),(1, 0, 1),)
# fmt: on

BOOL_EMPTY_ARR = np.empty(shape=(0, 5), dtype=np.bool_)
BOOL_ARR = np.array(
    [
        [False, False, False],
        [True, False, False],
        [False, False, True],
    ]
)


@pytest.mark.parametrize(
    "indices, expected_n_ind",
    [
        (tuple(), 0),
        ((np.array([1, 6, 8]),), 3),
        (coords_to_indices(IND_2D), 4),
        (coords_to_indices(IND_3D), 4),
        (BOOL_EMPTY_ARR, 0),
        (BOOL_ARR, 2),
    ],
)
def test_n_indices(indices: AdvancedIndex, expected_n_ind: int):
    n_ind = NumpyComparisons().n_indices(indices)

    assert n_ind == expected_n_ind, "actual/expected values for 'n_ind' are not equal"
