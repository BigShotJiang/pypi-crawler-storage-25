from collections.abc import Sequence
from types import EllipsisType
from typing import Any, Optional

import pytest

from test_data.core.string_utils import (
    ARRAY_HAL,
    ARRAY_NAME_AND_TYPE_STR,
    CONSTRAINTS_STR_LT1,
    CONSTRAINTS_STR_LT1_GE_NEG_5,
    FIELD_HAL_IDX_NAME,
    FIELD_HAL_IDX_NAME_CONSTRAINTS_VALIDATORS,
    FIELD_HAL_IDX_NO_NAME,
    FIELD_HAL_NO_IDX_NAME,
    FIELD_HAL_NO_IDX_NO_NAME,
    SCHEMA,
    SCHEMA_HAL,
    VALIDATOR_HAL_DUMMY,
)
from tests.core.test_validators import TestWithDescriptionDummyValidator
from tests.core.validation_functions.test_val_array import DTYPE
from valarray.core.axes_and_fields import AxesTuple
from valarray.core.data_structures import HeadingAndLines
from valarray.core.string_utils import (
    constraints_string,
    field_heading_and_lines,
    offset_lines,
    schema_heading_and_lines,
    validators_heading_and_lines,
)
from valarray.core.string_utils.array import validated_array_heading_and_lines
from valarray.core.validators import Validator


@pytest.mark.parametrize(
    "lt, le, ge, gt, eq, expected_string",
    [
        (None, None, None, None, None, None),
        (1, None, None, None, None, CONSTRAINTS_STR_LT1),
        (1, None, -5, None, None, CONSTRAINTS_STR_LT1_GE_NEG_5),
    ],
)
def test_constraints_string(
    lt: Optional[Any],
    le: Optional[Any],
    ge: Optional[Any],
    gt: Optional[Any],
    eq: Optional[Any],
    expected_string: Optional[str],
):
    string = constraints_string(lt, le, ge, gt, eq)

    assert (
        string == expected_string
    ), "actual/expected values for 'string' are not equal"


@pytest.mark.parametrize(
    "validators, expected_heading_and_lines",
    [
        (tuple(), None),
        (
            (TestWithDescriptionDummyValidator(),),
            VALIDATOR_HAL_DUMMY,
        ),
    ],
)
def test_validators_heading_and_lines(
    validators: Sequence[Validator[Any, Any]],
    expected_heading_and_lines: Optional[HeadingAndLines],
):
    heading_and_lines = validators_heading_and_lines(validators)

    assert (
        heading_and_lines == expected_heading_and_lines
    ), "actual/expected values for 'heading_and_lines' are not equal"


@pytest.mark.parametrize(
    "name, constraints_str, validators_hal, idx, expected_heading_and_lines",
    [
        (None, None, None, None, FIELD_HAL_NO_IDX_NO_NAME),
        ("name", None, None, None, FIELD_HAL_NO_IDX_NAME),
        (None, None, None, 0, FIELD_HAL_IDX_NO_NAME),
        ("name", None, None, 0, FIELD_HAL_IDX_NAME),
        (
            "name",
            "Constraints: < 1",
            VALIDATOR_HAL_DUMMY,
            0,
            FIELD_HAL_IDX_NAME_CONSTRAINTS_VALIDATORS,
        ),
    ],
)
def test_field_heading_and_lines(
    name: Optional[str],
    constraints_str: Optional[str],
    validators_hal: Optional[HeadingAndLines],
    idx: Optional[int],
    expected_heading_and_lines: HeadingAndLines,
):
    heading_and_lines = field_heading_and_lines(
        name, constraints_str, validators_hal, idx
    )

    assert (
        heading_and_lines == expected_heading_and_lines
    ), "actual/expected values for 'heading_and_lines' are not equal"


@pytest.mark.parametrize(
    "schema, expected_heading_and_lines",
    [
        (..., None),
        (
            SCHEMA,
            SCHEMA_HAL,
        ),
    ],
)
def test_schema_heading_and_lines(
    schema: AxesTuple[Any, Any, Any] | EllipsisType,
    expected_heading_and_lines: Optional[HeadingAndLines],
):
    heading_and_lines = schema_heading_and_lines(schema)

    assert (
        heading_and_lines == expected_heading_and_lines
    ), "actual/expected values for 'heading_and_lines' are not equal"


@pytest.mark.parametrize(
    "array_name_and_type_string, dtype_string, schema_hal, constraints_str, validators_hal, array_hal, expected_array_hal",
    [
        (
            ARRAY_NAME_AND_TYPE_STR,
            DTYPE,
            SCHEMA_HAL,
            CONSTRAINTS_STR_LT1,
            VALIDATOR_HAL_DUMMY,
            ARRAY_HAL,
            HeadingAndLines(
                ARRAY_NAME_AND_TYPE_STR,
                (
                    DTYPE,
                    SCHEMA_HAL,
                    CONSTRAINTS_STR_LT1,
                    VALIDATOR_HAL_DUMMY,
                    ARRAY_HAL,
                ),
            ),
        ),
        (
            ARRAY_NAME_AND_TYPE_STR,
            None,
            None,
            None,
            None,
            ARRAY_HAL,
            HeadingAndLines(
                ARRAY_NAME_AND_TYPE_STR,
                (ARRAY_HAL,),
            ),
        ),
    ],
)
def test_validated_array_heading_and_lines(
    array_name_and_type_string: str,
    dtype_string: str,
    schema_hal: Optional[HeadingAndLines],
    constraints_str: Optional[str],
    validators_hal: Optional[HeadingAndLines],
    expected_array_hal: HeadingAndLines,
    array_hal: HeadingAndLines,
):
    array_hal = validated_array_heading_and_lines(
        array_name_and_type_string,
        dtype_string,
        schema_hal,
        constraints_str,
        validators_hal,
        array_hal,
    )

    assert (
        array_hal == expected_array_hal
    ), "actual/expected values for 'array_hal' are not equal"


@pytest.mark.parametrize(
    "source_lines, expected_lines",
    [
        (tuple(), []),
        (("1", "2"), ["1", "2"]),
        (HeadingAndLines("1", ("1.1", "1.2")), ["1", "  1.1", "  1.2"]),
        (
            (
                "1",
                "2",
                HeadingAndLines("3", ("3.1", "3.2")),
                HeadingAndLines(
                    "4", ("4.1", HeadingAndLines("4.2", ("4.2.1", "4.2.2")))
                ),
            ),
            [
                "1",
                "2",
                "3",
                "  3.1",
                "  3.2",
                "4",
                "  4.1",
                "  4.2",
                "    4.2.1",
                "    4.2.2",
            ],
        ),
    ],
)
def test_offset_lines(
    source_lines: tuple[str | HeadingAndLines, ...], expected_lines: list[str]
):
    lines = offset_lines(source_lines)

    assert lines == expected_lines, "actual/expected values for 'lines' are not equal"
