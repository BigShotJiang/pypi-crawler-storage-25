from contextlib import nullcontext as does_not_raise
from types import EllipsisType

import pytest

from tests.core.classes_for_testing import (
    TestArray,
    TestArrayTypeAdapter,
    TestComparisons,
    TestDummyValidator,
)
from tests.core.classes_for_testing.errors_exceptions import TestInvalidFieldValuesError
from valarray.core.axes_and_fields import AxesTuple, Field
from valarray.core.data_structures import AxisNameAndIdx, FieldNameAndIdx
from valarray.core.errors_exceptions import (
    IncorrectAxSizesError,
    InvalidFieldValuesError,
)
from valarray.core.validation_functions import validate_field_values
from valarray.core.validators import ComparisonValidator

ARR = TestArray(val=[0, 0, 0, 0, 0, 0], shap=(6,))
ARR_INCORRECT_SHAPE_BIGGER = TestArray(val=[0, 0, 0, 0, 0, 0, 0, 0, 0, 0], shap=(10,))
ARR_INCORRECT_SHAPE_SMALLER = TestArray(val=[0, 0, 0, 0], shap=(4,))

SCHEMA = (
    (
        Field(ge=-10),
        Field(ge=10),
        Field(ge=-10),
        Field(lt=-5),
        Field(ge=10),
        Field(validators=(TestDummyValidator(valid=False),)),
    ),
)

ERR_GE_10 = TestInvalidFieldValuesError(
    validator=ComparisonValidator("ge", 10, TestComparisons()),
    # invalid_indices=[1, 4],
    invalid_values={
        AxisNameAndIdx(0, "_sized_6"): {
            FieldNameAndIdx(1): [0],
            FieldNameAndIdx(4): [0],
        }
    },
)

ERR_LT_NEG_5 = TestInvalidFieldValuesError(
    validator=ComparisonValidator("lt", -5, TestComparisons()),
    # invalid_indices=[1, 4],
    invalid_values={
        AxisNameAndIdx(0, "_sized_6"): {
            FieldNameAndIdx(3): [0],
        }
    },
)

ERR_DUMMY = TestInvalidFieldValuesError(
    validator=TestDummyValidator(valid=False),
    # invalid_indices=[1, 4],
)

ERR_SHAPE_BIGGER = IncorrectAxSizesError((10,), (6,), [0])
ERR_SHAPE_SMALLER = IncorrectAxSizesError((4,), (6,), [0])


@pytest.mark.parametrize(
    "arr, array_schema, check_shape, expected_errs, expectation",
    [
        (ARR, ..., False, [], does_not_raise()),
        (ARR, ..., True, [], does_not_raise()),
        (ARR, SCHEMA, False, [ERR_GE_10, ERR_LT_NEG_5, ERR_DUMMY], does_not_raise()),
        (ARR, SCHEMA, True, [ERR_GE_10, ERR_LT_NEG_5, ERR_DUMMY], does_not_raise()),
        (
            ARR_INCORRECT_SHAPE_BIGGER,
            SCHEMA,
            False,
            [ERR_GE_10, ERR_LT_NEG_5, ERR_DUMMY],
            does_not_raise(),
        ),
        (
            ARR_INCORRECT_SHAPE_BIGGER,
            SCHEMA,
            True,
            [ERR_SHAPE_BIGGER],
            does_not_raise(),
        ),
        (ARR_INCORRECT_SHAPE_SMALLER, SCHEMA, False, ..., pytest.raises(IndexError)),
        (
            ARR_INCORRECT_SHAPE_SMALLER,
            SCHEMA,
            True,
            [ERR_SHAPE_SMALLER],
            does_not_raise(),
        ),
    ],
)
def test_validate_field_values(
    arr: TestArray,
    array_schema: AxesTuple | EllipsisType,
    check_shape: bool,
    expected_errs: list[InvalidFieldValuesError],
    expectation: does_not_raise | pytest.RaisesExc[Exception],
):
    with expectation:
        errs = validate_field_values(
            arr, array_schema, TestArrayTypeAdapter(), check_shape
        )

    if not isinstance(expectation, does_not_raise):
        return

    assert errs == expected_errs, "actual/expected values for 'errs' are not equal"
