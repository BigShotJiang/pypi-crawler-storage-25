from dataclasses import dataclass

import pytest

from tests.core.classes_for_testing.validators import TestValidator
from valarray.core.data_structures import AxisNameAndIdx, FieldNameAndIdx
from valarray.core.validation_functions.field_values.types_and_data_structures import (
    _ResolvedAx,
    _ResolvedField,
)

F = FieldNameAndIdx(1)
FN = FieldNameAndIdx(1, "example")


@dataclass
class TestStrValidator(TestValidator):
    text: str

    def validate(self, arr):
        return True

    def __str__(self) -> str:
        return f"validator_string_{self.text}"

    def __repr__(self) -> str:
        return f'TestStrValidator("{self.text}")'


@pytest.mark.parametrize(
    "rf, expected_string",
    [
        (_ResolvedField(F, tuple()), "Field < 1 > -> NA"),
        (_ResolvedField(FN, tuple()), "Field < 1 >: 'example' -> NA"),
        (
            _ResolvedField(FN, (TestStrValidator("a"),)),
            "Field < 1 >: 'example'\n-> 'validator_string_a': TestStrValidator(\"a\")",
        ),
    ],
)
def test_resolved_field_str(rf: _ResolvedField, expected_string: str):
    string = str(rf)

    assert (
        string == expected_string
    ), "actual/expected values for 'string' are not equal"


AXIS0 = AxisNameAndIdx(0, "first_axis")

AXIS0_F0 = FieldNameAndIdx(0, "first_field")
AXIS0_F1 = FieldNameAndIdx(1, "second_field")

STR = """Axis < 0 >: 'first_axis'

Field < 0 >: 'first_field'
-> 'validator_string_a': TestStrValidator(\"a\")
-> 'validator_string_b': TestStrValidator(\"b\")
Field < 1 >: 'second_field' -> NA"""


@pytest.mark.parametrize(
    "ra, expected_string",
    [
        (_ResolvedAx(AXIS0, tuple()), "Axis < 0 >: 'first_axis' -> NA"),
        (
            _ResolvedAx(
                AXIS0,
                (
                    _ResolvedField(
                        AXIS0_F0,
                        (
                            TestStrValidator("a"),
                            TestStrValidator("b"),
                        ),
                    ),
                    _ResolvedField(AXIS0_F1, tuple()),
                ),
            ),
            STR,
        ),
    ],
)
def test_resolved_ax_str(ra: _ResolvedAx, expected_string: str):
    string = str(ra)

    assert (
        string == expected_string
    ), "actual/expected values for 'string' are not equal"
