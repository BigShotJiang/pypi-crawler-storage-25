import pytest

from tests.core.classes_for_testing import (
    TestArray,
    TestArrayTypeAdapter,
    TestBoolValidator,
    TestComparisons,
    TestInvalidArrayValuesError,
    TestValueErrorValidator,
)
from valarray.core.errors_exceptions import ValidationErrorList
from valarray.core.validation_functions import validate_array_values
from valarray.core.validators import ComparisonValidator, ValidatorOrValidatorSequence

COMP_VAL = ComparisonValidator("gt", 0, TestComparisons())


@pytest.mark.parametrize(
    "arr, validator, expected_errs",
    [
        (TestArray(val=[1, 2, 3]), [COMP_VAL], []),
        (TestArray(val=[1, 2, 3]), COMP_VAL, []),
        (
            TestArray(val=[1, 1, 0]),
            COMP_VAL,
            [TestInvalidArrayValuesError(COMP_VAL, [0], [2])],
        ),
        (
            TestArray(val=[0]),
            TestBoolValidator(),
            [TestInvalidArrayValuesError(TestBoolValidator())],
        ),
        (
            TestArray(val=[0]),
            TestValueErrorValidator(),
            [
                TestInvalidArrayValuesError(
                    TestValueErrorValidator(), result_msg="value_error"
                )
            ],
        ),
    ],
)
def test_validate_array_values(
    arr: TestArray,
    validator: ValidatorOrValidatorSequence,
    expected_errs: ValidationErrorList[TestInvalidArrayValuesError],
):

    errs = validate_array_values(arr, validator, TestArrayTypeAdapter())

    assert errs == expected_errs, "actual/expected values for 'errs' are not equal"
