from types import EllipsisType

import pytest

from tests.core.classes_for_testing import (
    TestArray,
    TestArrayTypeAdapter,
    TestDtype,
    TestDtypeLike,
    TestIncorrectDTypeError,
)
from valarray.core.validation_functions import validate_dtype


@pytest.mark.parametrize(
    "arr, expected_dtypelike, expected_errs",
    [
        (TestArray(), ..., []),
        (TestArray(), TestDtype(0), []),
        (
            TestArray(),
            TestDtype(1),
            [TestIncorrectDTypeError(TestDtype(0), TestDtype(1), TestDtype(1))],
        ),
        (
            TestArray(),
            "one",
            [TestIncorrectDTypeError(TestDtype(0), TestDtype(1), "one")],
        ),
    ],
)
def test_validate_dtype(
    arr: TestArray,
    expected_dtypelike: TestDtypeLike | EllipsisType,
    expected_errs: list[TestIncorrectDTypeError],
):
    errs = validate_dtype(arr, expected_dtypelike, TestArrayTypeAdapter())

    assert errs == expected_errs, "actual/expected values for 'errs' are not equal"
