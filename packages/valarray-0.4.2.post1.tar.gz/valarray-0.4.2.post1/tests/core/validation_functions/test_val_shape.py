from types import EllipsisType

import pytest

from tests.core.classes_for_testing import TestArray
from valarray.core.axes_and_fields import AxesTuple
from valarray.core.errors_exceptions import (
    IncorrectAxNumberError,
    IncorrectAxSizesError,
)
from valarray.core.validation_functions import validate_shape


@pytest.mark.parametrize(
    "arr, expected_shape, expected_errs",
    [
        (TestArray(shap=(1, 2, 3)), ..., []),
        (TestArray(shap=(0, 2, 0, 4)), (1, 2, 3, 4), []),
        (TestArray(shap=(1, 2, 3)), (1, 2), [IncorrectAxNumberError(3, 2)]),
        (TestArray(shap=(1, 2, 3)), (1, 2, 3, 4), [IncorrectAxNumberError(3, 4)]),
        (
            TestArray(shap=(1, 2, 3, 4)),
            ("x", 1, "y", 2),
            [IncorrectAxSizesError((1, 2, 3, 4), (None, 1, None, 2), [1, 3])],
        ),
        (
            TestArray(shap=(1, 3, 3)),
            (1, 2, 3, 4),
            [
                IncorrectAxNumberError(3, 4),
                IncorrectAxSizesError((1, 3, 3), (1, 2, 3, 4), [1]),
            ],
        ),
    ],
)
def test_validate_shape(
    arr: TestArray,
    expected_shape: AxesTuple | EllipsisType,
    expected_errs: list[IncorrectAxNumberError | IncorrectAxSizesError],
):
    errs = validate_shape(arr, expected_shape)

    assert errs == expected_errs, "actual/expected values for 'errs' are not equal"
