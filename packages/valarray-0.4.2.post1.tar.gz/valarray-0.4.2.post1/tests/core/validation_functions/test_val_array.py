import pytest

from tests.core.classes_for_testing import (
    TestArray,
    TestArrayTypeAdapter,
    TestComparisons,
    TestDtype,
    TestIncorrectDTypeError,
    TestInvalidArrayValuesError,
)
from tests.core.classes_for_testing.errors_exceptions import TestInvalidFieldValuesError
from valarray.core.axes_and_fields import Field
from valarray.core.data_structures import AxisNameAndIdx, FieldNameAndIdx
from valarray.core.errors_exceptions import IncorrectAxSizesError, ValidationErrorList
from valarray.core.validation_functions import validate_array
from valarray.core.validators import ComparisonValidator

DTYPE = "one"
SCHEMA = ((Field(ge=-10), Field(ge=10), Field(ge=-10), Field(lt=-5), Field(ge=10)),)
VAL = ComparisonValidator("lt", 20, TestComparisons())
VALIDATORS = [VAL]

ARR_OK = TestArray(val=[0, 15, 0, -10, 15], shap=(5,), dtyp=TestDtype(1))
ARR_WRONG_DTYPE = TestArray(val=[-20, 15, 0, -10, 30], shap=(5,), dtyp=TestDtype(0))
ARR_WRONG_SHAPE = TestArray(val=[-20, 15, 0, -10, 30, 10], shap=(6,), dtyp=TestDtype(1))
ARR_WRONG_DTYPE_SHAPE = TestArray(
    val=[-20, 15, 0, -10, 30, 10], shap=(6,), dtyp=TestDtype(0)
)
ARR_WRONG_FIELD_VALUES = TestArray(
    val=[-20, 15, 0, -10, 15], shap=(5,), dtyp=TestDtype(1)
)
ARR_WRONG_ARRAY_VALUES = TestArray(
    val=[0, 15, 0, -10, 30], shap=(5,), dtyp=TestDtype(1)
)
ARR_WRONG_FIELD_ARRAY_VALUES = TestArray(
    val=[-20, 15, 0, -10, 30], shap=(5,), dtyp=TestDtype(1)
)

ERR_DTYPE = TestIncorrectDTypeError(TestDtype(0), TestDtype(1), "one")
ERR_SHAPE = IncorrectAxSizesError((6,), (5,), [0])
ERR_FIELD_VAL = TestInvalidFieldValuesError(
    ComparisonValidator("ge", -10, TestComparisons()),
    {AxisNameAndIdx(0, name="_sized_5"): {FieldNameAndIdx(0): [-20]}},
)
ERR_ARRAY_VAL = TestInvalidArrayValuesError(VAL, [30], [4])

ERRS_WRONG_DTYPE = ValidationErrorList([ERR_DTYPE])
ERRS_WRONG_SHAPE = ValidationErrorList([ERR_SHAPE])
ERRS_WRONG_DTYPE_SHAPE = ValidationErrorList([ERR_DTYPE, ERR_SHAPE])
ERRS_WRONG_FIELD_VALUES = ValidationErrorList([ERR_FIELD_VAL])
ERRS_WRONG_ARRAY_VALUES = ValidationErrorList([ERR_ARRAY_VAL])
ERRS_WRONG_FIELD_ARRAY_VALUES = ValidationErrorList(
    [
        ERR_ARRAY_VAL,
        ERR_FIELD_VAL,
    ]
)


@pytest.mark.parametrize(
    "arr, expected_errs",
    [
        (ARR_OK, []),  # OK
        (ARR_WRONG_DTYPE, ERRS_WRONG_DTYPE),  # wrong dtype
        (ARR_WRONG_SHAPE, ERRS_WRONG_SHAPE),  # wrong shape
        (ARR_WRONG_DTYPE_SHAPE, ERRS_WRONG_DTYPE_SHAPE),  # wrong dtype and shape
        (ARR_WRONG_FIELD_VALUES, ERRS_WRONG_FIELD_VALUES),  # wrong field values
        (ARR_WRONG_ARRAY_VALUES, ERRS_WRONG_ARRAY_VALUES),  # wrong array values
        (
            ARR_WRONG_FIELD_ARRAY_VALUES,
            ERRS_WRONG_FIELD_ARRAY_VALUES,
        ),  # wrong array and field values
    ],
)
def test_validate_array(
    arr: TestArray,
    expected_errs: ValidationErrorList,
):

    errs = validate_array(arr, DTYPE, SCHEMA, VALIDATORS, TestArrayTypeAdapter())

    assert errs == expected_errs, "actual/expected values for 'errs' are not equal"
