from tests.core.test_validators import TestWithDescriptionDummyValidator
from valarray.core.axes_and_fields import Field


def test_field_string():
    fld = Field(
        name="example_field",
        ge=-5,
        lt=1,
        validators=(TestWithDescriptionDummyValidator(),),
    )

    expected_string = """Field < ? > : 'example_field'
  Constraints: < 1, >= -5
  Validators:
    Dummy: description"""

    string = str(fld)

    assert (
        string == expected_string
    ), "actual/expected values for 'string' are not equal"
