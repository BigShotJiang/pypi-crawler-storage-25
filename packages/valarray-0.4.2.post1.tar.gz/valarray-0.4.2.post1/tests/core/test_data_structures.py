import pytest

from valarray.core.data_structures import AxisNameAndIdx, FieldNameAndIdx


@pytest.mark.parametrize(
    "name_and_index, expected_string",
    [
        (AxisNameAndIdx(0, "example_axis"), "Axis < 0 >: 'example_axis'"),
        (AxisNameAndIdx(0), "Axis < 0 >"),
        (FieldNameAndIdx(1, "example_field"), "Field < 1 >: 'example_field'"),
        (FieldNameAndIdx(1), "Field < 1 >"),
    ],
)
def test_name_and_index_str(
    name_and_index: AxisNameAndIdx | FieldNameAndIdx, expected_string: str
):
    string = str(name_and_index)

    assert (
        string == expected_string
    ), "actual/expected values for 'string' are not equal"
