from dataclasses import dataclass

from valarray.core.array_type_adapter import GenericErrors
from valarray.core.errors_exceptions import (
    CannotCoerceDTypeError,
    IncorrectDTypeError,
    InvalidArrayValuesError,
    InvalidFieldValuesError,
)

from .array_and_dtype import TestArray, TestDtype, TestDtypeLike


class TestIncorrectDTypeError(IncorrectDTypeError[TestDtypeLike, TestDtype]): ...


class TestCannotCoerceDTypeError(CannotCoerceDTypeError[TestDtypeLike, TestDtype]): ...


class TestInvalidArrayValuesError(InvalidArrayValuesError[TestArray, list[int], int]):
    """Blank"""


class TestInvalidFieldValuesError(
    InvalidFieldValuesError[TestArray, list[int], int]
): ...


@dataclass
class TestErrors(GenericErrors[TestArray, TestDtypeLike, TestDtype, list[int], int]):
    incorrect_dtype: type[TestIncorrectDTypeError] = TestIncorrectDTypeError
    cannot_coerce_dtype: type[TestCannotCoerceDTypeError] = TestCannotCoerceDTypeError
    invalid_array_values: type[TestInvalidArrayValuesError] = (
        TestInvalidArrayValuesError
    )
    invalid_field_values: type[TestInvalidFieldValuesError] = (
        TestInvalidFieldValuesError
    )
