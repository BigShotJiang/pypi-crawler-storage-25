from dataclasses import dataclass, field
from typing import Literal, TypeAlias


@dataclass
class TestDtype:
    dtype_val: Literal[0, 1, 2]

    def __str__(self) -> str:
        return f"DType{self.dtype_val}"


TestDtypeLike: TypeAlias = TestDtype | str


def _default_dtype():
    return TestDtype(0)


@dataclass
class TestArray:
    # TODO: rewrite so 'shap' field is not necessary
    # (legacy from before val could be a list, from which to get shape)
    dtyp: TestDtype = field(default_factory=_default_dtype)
    is_empty: bool = False
    shap: tuple[int, ...] = ()
    val: list[int] = field(default_factory=list)

    @property
    def dtype(self) -> TestDtype:
        return self.dtyp

    @property
    def shape(self) -> tuple[int, ...]:
        return self.shap

    def astype(self, dtype: TestDtype):
        self.dtyp = dtype

        return self

    def __len__(self) -> int:
        return len(self.val)

    def __repr__(self) -> str:
        return f"{self.__class__.__name__}()"

    def __str__(self) -> str:
        return str(self.val)
