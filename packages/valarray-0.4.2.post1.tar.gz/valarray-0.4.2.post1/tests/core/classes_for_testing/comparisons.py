from tests.core.classes_for_testing.array_and_dtype import TestArray
from valarray.core.array_type_adapter import Comparisons


class TestComparisons(Comparisons[TestArray, list[int], int]):
    def where_not_lt(self, arr, value):
        return [i for i, val in enumerate(arr.val) if not val < value]

    def where_not_le(self, arr, value):
        return [i for i, val in enumerate(arr.val) if not val <= value]

    def where_not_ge(self, arr, value):
        return [i for i, val in enumerate(arr.val) if not val >= value]

    def where_not_gt(self, arr, value):
        return [i for i, val in enumerate(arr.val) if not val > value]

    def where_not_eq(self, arr, value):
        return [i for i, val in enumerate(arr.val) if not val == value]

    def n_indices(self, indices):
        return len(indices)
