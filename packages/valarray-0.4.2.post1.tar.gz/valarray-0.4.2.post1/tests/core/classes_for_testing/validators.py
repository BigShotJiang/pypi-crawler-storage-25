from dataclasses import dataclass
from typing import Any

from tests.core.classes_for_testing import TestArray
from valarray.core.validators import ValidationResult, Validator


class TestValidator(Validator[TestArray, Any]): ...


@dataclass
class TestDummyValidator(TestValidator):
    valid: bool = True

    def validate(self, arr):
        return self.valid


@dataclass
class TestBoolValidator(TestValidator):
    val: int = 1

    def validate(self, arr) -> bool:
        if arr.val[0] < self.val:
            return False

        return True


@dataclass
class TestResultValidator(TestValidator):
    val: int = 1

    def validate(self, arr) -> ValidationResult:
        if arr.val[0] < self.val:
            return ValidationResult(status="FAIL", msg="result")

        return ValidationResult(status="OK")


@dataclass
class TestValueErrorValidator(TestValidator):
    val: int = 1

    def validate(self, arr):
        if arr.val[0] < self.val:
            raise ValueError("value_error")


@dataclass
class TestWithDescriptionDummyValidator(TestValidator):
    def validate(self, arr):
        return True

    @property
    def description(self) -> str:
        return "Dummy: description"


class TestWitoutDescriptionAndReprDummyValidator(TestValidator):
    def __init__(self, valid: bool = True):
        self.valid = valid

    def validate(self, arr):
        return self.valid
