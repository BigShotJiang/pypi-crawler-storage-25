from valarray.core import ValidatedArray

from .array_and_dtype import TestArray, TestDtype, TestDtypeLike
from .array_type_adapter import TestArrayTypeAdapter


class TestValidatedArray(
    ValidatedArray[TestArray, TestDtypeLike, TestDtype, list[int], int]
):
    @property
    def ata(self):
        return TestArrayTypeAdapter()

    @property
    def array(self) -> TestArray:
        return self._array
