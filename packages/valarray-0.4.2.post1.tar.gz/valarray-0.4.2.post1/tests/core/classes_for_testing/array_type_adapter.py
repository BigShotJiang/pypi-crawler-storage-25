from types import EllipsisType

from valarray.core.array_type_adapter import ArrayTypeAdapter
from valarray.core.types import AxSizes

from .array_and_dtype import TestArray, TestDtype, TestDtypeLike
from .comparisons import TestComparisons
from .errors_exceptions import TestErrors


class TestArrayTypeAdapter(
    ArrayTypeAdapter[TestArray, TestDtypeLike, TestDtype, list[int], int]
):
    @property
    def type_name(self):
        return "test"

    @property
    def errors(self):
        return TestErrors()

    @property
    def array_type(self):
        return TestArray

    @property
    def comparisons(self):
        return TestComparisons()

    def create_array(self, obj, dtypelike):
        if obj == "fail":
            raise ValueError(obj)

        return TestArray()

    def create_empty_array(
        self, ax_sizes: AxSizes, dtypelike: TestDtypeLike | EllipsisType
    ) -> TestArray:
        return TestArray(is_empty=True, shap=(0,))

    def is_array_empty(self, arr: TestArray) -> bool:
        return arr.is_empty

    def change_dtype(self, arr: TestArray, dtypelike: TestDtypeLike) -> TestArray:
        return arr.astype(self.dtype_from_dtypelike(dtypelike))

    def dtype_from_dtypelike(self, dtypelike: TestDtype | str) -> TestDtype:
        if isinstance(dtypelike, TestDtype):
            return dtypelike

        match dtypelike:
            case "one":
                return TestDtype(1)
            case "two":
                return TestDtype(2)
            case _:
                return TestDtype(0)

    def dtypes_equal(self, actual_dtype: TestDtype, expected_dtype: TestDtype) -> bool:
        return actual_dtype == expected_dtype

    def get_values(self, arr, indices):
        if indices is not None:
            vals = [arr.val[i] for i in indices]
        else:
            vals = None

        return vals

    def select_subset(self, arr, ax, fields):
        return TestArray(dtyp=arr.dtyp, val=[arr.val[f.idx] for f in fields])

    def get_values_from_subset(
        self,
        arr,
        indices,
        ax,
        fields,
    ):
        if indices is None:
            return None

        dic = {}

        for i, (fld, val) in enumerate(zip(fields, arr.val)):
            if i in indices:
                dic[fld] = [val]

        return dic
