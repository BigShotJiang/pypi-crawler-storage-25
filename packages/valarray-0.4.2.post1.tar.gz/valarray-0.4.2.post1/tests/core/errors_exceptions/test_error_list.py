from contextlib import nullcontext as does_not_raise

import pytest

from tests.core.classes_for_testing import TestDtype, TestIncorrectDTypeError
from valarray.core.errors_exceptions import (
    IncorrectAxSizesError,
    InvalidArrayValuesError,
    InvalidFieldValuesError,
    ValidationError,
    ValidationException,
)
from valarray.core.errors_exceptions.error_list import ValidationErrorList

AX_ERR = IncorrectAxSizesError((1, 4), [2, None], [0])
AX_ERR2 = IncorrectAxSizesError((4, 2), [2, 4], [0, 1])
DT_ERR = TestIncorrectDTypeError(TestDtype(1), TestDtype(2), "two")


EMPTY_ERRS = ValidationErrorList([])


@pytest.mark.parametrize(
    "errs, expectation",
    [
        (EMPTY_ERRS, does_not_raise()),
        (
            ValidationErrorList([AX_ERR]),
            pytest.raises(ValidationException),
        ),
    ],
)
def test_raise(
    errs: ValidationErrorList,
    expectation: does_not_raise | pytest.RaisesExc[Exception],
):
    with expectation:
        errs.raise_()
        errs.raise_on_errors()


@pytest.mark.parametrize(
    "errs, i, expected_items",
    [
        # integer
        (
            ValidationErrorList([AX_ERR, DT_ERR]),
            0,
            AX_ERR,
        ),
        # slice
        (
            ValidationErrorList([AX_ERR, DT_ERR, AX_ERR2]),
            slice(0, 2, 1),
            ValidationErrorList([AX_ERR, DT_ERR]),
        ),
        # type
        (EMPTY_ERRS, IncorrectAxSizesError, EMPTY_ERRS),
        (
            ValidationErrorList([AX_ERR, DT_ERR]),
            IncorrectAxSizesError,
            ValidationErrorList([AX_ERR]),
        ),
        (
            ValidationErrorList([AX_ERR, DT_ERR, AX_ERR2]),
            IncorrectAxSizesError,
            ValidationErrorList([AX_ERR, AX_ERR2]),
        ),
        (
            ValidationErrorList([AX_ERR, DT_ERR]),
            InvalidArrayValuesError,
            EMPTY_ERRS,
        ),
        # tuple of types
        (EMPTY_ERRS, (IncorrectAxSizesError, TestIncorrectDTypeError), EMPTY_ERRS),
        (
            ValidationErrorList([AX_ERR, DT_ERR]),
            (IncorrectAxSizesError, TestIncorrectDTypeError),
            ValidationErrorList([AX_ERR, DT_ERR]),
        ),
        (
            ValidationErrorList([AX_ERR, DT_ERR]),
            (IncorrectAxSizesError, InvalidArrayValuesError),
            ValidationErrorList([AX_ERR]),
        ),
        (
            ValidationErrorList([AX_ERR, DT_ERR, AX_ERR2]),
            (IncorrectAxSizesError, InvalidArrayValuesError),
            ValidationErrorList([AX_ERR, AX_ERR2]),
        ),
        (
            ValidationErrorList([AX_ERR, DT_ERR]),
            (InvalidFieldValuesError, InvalidArrayValuesError),
            EMPTY_ERRS,
        ),
        (
            ValidationErrorList([AX_ERR, DT_ERR]),
            tuple(),
            EMPTY_ERRS,
        ),
    ],
)
def test_get_item(
    errs: ValidationErrorList,
    i: int | slice | type[ValidationError] | tuple[type[ValidationError], ...],
    expected_items: ValidationErrorList | ValidationError,
):
    items = errs[i]

    assert items == expected_items, "actual/expected values for 'items' are not equal"
