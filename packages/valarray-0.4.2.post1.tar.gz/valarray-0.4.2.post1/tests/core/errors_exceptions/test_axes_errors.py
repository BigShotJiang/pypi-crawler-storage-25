import pytest

from valarray.core.errors_exceptions import (
    IncorrectAxNumberError,
    IncorrectAxSizesError,
)


@pytest.mark.parametrize(
    "err, expected_msg",
    [
        (IncorrectAxNumberError(2, 1), "Incorrect number of axes: 2, expected 1."),
        (
            IncorrectAxSizesError(
                (1, 2, 3, 4), [2, None, 1, 4], incorrect_size_indices=[0, 2]
            ),
            "Incorrect axis sizes: (*1*, 2, *3*, 4), expected (2, any, 1, 4).",
        ),
    ],
)
def test_axes_error_msg(
    err: IncorrectAxNumberError | IncorrectAxSizesError, expected_msg: str
):
    msg = err.msg

    assert msg == expected_msg, "actual/expected values for 'msg' are not equal"
