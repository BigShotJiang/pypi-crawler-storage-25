import pytest

from tests.core.classes_for_testing import TestDtype
from valarray.core.errors_exceptions import CannotCoerceDTypeError, IncorrectDTypeError


@pytest.mark.parametrize(
    "err, expected_msg",
    [
        (
            IncorrectDTypeError(TestDtype(1), TestDtype(2), TestDtype(2)),
            "Incorrect DType: 'DType1', expected 'DType2'.",
        ),
        (
            IncorrectDTypeError(TestDtype(1), TestDtype(2), "two"),
            "Incorrect DType: 'DType1', expected 'two (DType2)'.",
        ),
        (
            CannotCoerceDTypeError(TestDtype(1), TestDtype(2), TestDtype(2)),
            "Cannot coerce data type from: 'DType1' to 'DType2'.",
        ),
        (
            CannotCoerceDTypeError(TestDtype(1), TestDtype(2), "two"),
            "Cannot coerce data type from: 'DType1' to 'two (DType2)'.",
        ),
    ],
)
def test_dtype_error_msg(
    err: CannotCoerceDTypeError | IncorrectDTypeError, expected_msg: str
):
    msg = err.msg

    assert msg == expected_msg, "actual/expected values for 'msg' are not equal"
