from typing import Optional

import pytest

from valarray.core.errors_exceptions import (
    CreateArrayException,
    ValidationError,
    ValidationErrorList,
    ValidationException,
)


class TestValidationError(ValidationError):
    @property
    def msg(self):
        return "test"


@pytest.mark.parametrize(
    "cls_name, expected_message",
    [
        (None, "validation failed:\ntest"),
        ("Test", "'Test' validation failed:\ntest"),
    ],
)
def test_validation_exception(cls_name: Optional[str], expected_message: str):
    try:
        raise ValidationException(
            cls_name=cls_name, errs=ValidationErrorList([TestValidationError()])
        )
    except ValidationException as exc:
        message = str(exc)

        assert (
            message == expected_message
        ), "actual/expected values for 'message' are not equal"


def test_create_array_exception():
    try:
        raise CreateArrayException(cls_name="Test")
    except ValidationException as exc:
        message = str(exc)

        assert message == "'Test' validation failed:\nCannot create array."
