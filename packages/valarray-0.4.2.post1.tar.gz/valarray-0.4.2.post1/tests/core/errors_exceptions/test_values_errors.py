import pytest

from tests.core.classes_for_testing import TestComparisons, TestDummyValidator
from valarray.core.data_structures import AxisNameAndIdx, FieldNameAndIdx
from valarray.core.errors_exceptions import (
    InvalidArrayValuesError,
    InvalidFieldValuesError,
)
from valarray.core.validators import ComparisonValidator

FIELD_VAL_ERR_1 = InvalidFieldValuesError(validator=TestDummyValidator(valid=False))

FIELD_VAL_ERR_MSG_1 = "Invalid Field Values (TestDummyValidator)."

FIELD_VAL_ERR_2 = InvalidFieldValuesError(
    validator=ComparisonValidator("ge", 10, TestComparisons()),
    # invalid_indices=[1, 4],
    invalid_values={
        AxisNameAndIdx(0, "_sized_6"): {
            FieldNameAndIdx(1, "example_field"): [0],
            FieldNameAndIdx(4): [0],
        },
        AxisNameAndIdx(1): {
            FieldNameAndIdx(0): [0, 2],
        },
    },
)

FIELD_VAL_ERR_MSG_2 = (
    "Invalid Field Values (< 10):\n"
    + "\tAxis < 0 >: '_sized_6'\n"
    + "\t\tField < 1 >: 'example_field': [0]\n"
    + "\t\tField < 4 >: [0]\n"
    + "\tAxis < 1 >\n"
    + "\t\tField < 0 >: [0, 2]"
)


@pytest.mark.parametrize(
    "err, expected_msg",
    [
        (
            InvalidArrayValuesError(TestDummyValidator()),
            "Invalid Array Values (TestDummyValidator).",
        ),
        (
            InvalidArrayValuesError(TestDummyValidator(), invalid_values=[1, 2, 3]),
            "Invalid Array Values (TestDummyValidator):\n\t[1, 2, 3]",
        ),
        (
            InvalidArrayValuesError(TestDummyValidator(), result_msg="dummy"),
            "Invalid Array Values (TestDummyValidator):\n\tdummy",
        ),
        (
            InvalidArrayValuesError(
                TestDummyValidator(), invalid_values=[1, 2, 3], result_msg="dummy"
            ),
            "Invalid Array Values (TestDummyValidator):\n\t[1, 2, 3]\n\tdummy",
        ),
        (
            FIELD_VAL_ERR_1,
            FIELD_VAL_ERR_MSG_1,
        ),
        (
            FIELD_VAL_ERR_2,
            FIELD_VAL_ERR_MSG_2,
        ),
    ],
)
def test_value_error_msg(
    err: InvalidArrayValuesError | InvalidFieldValuesError, expected_msg: str
):
    msg = err.msg

    assert msg == expected_msg, "actual/expected values for 'msg' are not equal"
