from contextlib import nullcontext as does_not_raise
from typing import Any

import pytest
from classes_for_testing import TestArray, TestDtype, TestValidatedArray

from tests.core.test_validators import TestWithDescriptionDummyValidator
from valarray.core.errors_exceptions import ValidationException


@pytest.mark.parametrize(
    "obj, validate, expected_is_validated, expectation",
    [
        (TestArray(), True, True, does_not_raise()),
        (TestArray(), False, False, does_not_raise()),
        ("dummy", False, False, does_not_raise()),
        ("dummy", True, True, does_not_raise()),
        ("fail", None, None, pytest.raises(ValidationException)),
    ],
)
def test_init(
    obj: Any,
    validate: bool,
    expected_is_validated: bool,
    expectation: does_not_raise | pytest.RaisesExc[Exception],
):
    with expectation:
        arr = TestValidatedArray(obj, validate)

    if not isinstance(expectation, does_not_raise):
        return

    assert arr.is_validated == expected_is_validated
    assert isinstance(arr.array, TestArray)


def test_wrap():
    arr = TestValidatedArray.wrap(TestArray())

    assert not arr.is_validated
    assert isinstance(arr.array, TestArray)


def test_validate():
    arr = TestValidatedArray.validate(TestArray())

    assert arr.is_validated
    assert isinstance(arr.array, TestArray)


def test_empty():
    arr = TestValidatedArray.empty()

    assert arr.is_validated
    assert arr.array.is_empty
    assert isinstance(arr.array, TestArray)


def test_repr():
    arr = TestValidatedArray(TestArray())

    assert repr(arr) == "TestValidatedArray(TestArray())"

    arr = TestValidatedArray(TestArray(is_empty=True))

    assert repr(arr) == "TestValidatedArray.empty()"


class TestTestValidatedArray(TestValidatedArray):
    schema = ("n",)


@pytest.mark.parametrize(
    "v_arr, expected_length",
    [
        (TestTestValidatedArray.empty(), 0),
        (TestTestValidatedArray(TestArray(val=[1, 2, 3], shap=(3,))), 3),
    ],
)
def test_len(v_arr: TestValidatedArray, expected_length: int):
    length = len(v_arr)

    assert (
        length == expected_length
    ), "actual/expected values for 'length' are not equal"


class ExampleTestArray(TestValidatedArray):
    dtype = "one"
    schema = (4,)
    validators = (TestWithDescriptionDummyValidator(),)
    lt = 5
    ge = 0


STR = """ExampleTestArray (type: 'test')
  data type: 'one' (DType1)
  schema:
    Axis < 0 >
  Constraints: < 5, >= 0
  Validators:
    Dummy: description
  values:
    [1, 2, 3, 4]"""


def test_array_string():
    expected_string = STR
    string = str(
        ExampleTestArray(TestArray(dtyp=TestDtype(1), shap=(4,), val=[1, 2, 3, 4]))
    )

    assert (
        string == expected_string
    ), "actual/expected values for 'string' are not equal"
