from dataclasses import dataclass
from typing import Any

import pytest

from tests.core.classes_for_testing import TestComparisons
from valarray.core.array_type_adapter import Comparisons


class TestDifferentComparisons(Comparisons[Any, list[int], int]):
    def where_not_lt(self, arr, value):
        return [1, 2, 3]

    def where_not_le(self, arr, value):
        return [1, 2, 3]

    def where_not_ge(self, arr, value):
        return [1, 2, 3]

    def where_not_gt(self, arr, value):
        return [1, 2, 3]

    def where_not_eq(self, arr, value):
        return [1, 2, 3]

    def n_indices(self, indices):
        return 1


@dataclass
class Unhashable:
    x: int = 1

    def temp(self):
        pass


@pytest.mark.parametrize(
    "comp, other, expected_res",
    [
        (TestComparisons(), TestComparisons(), True),
        (TestComparisons(), TestDifferentComparisons(), False),
        (TestComparisons(), Unhashable(), False),
    ],
)
def test_comparison_equality(comp: Comparisons, other: Any, expected_res: bool):
    res = comp == other

    assert res == expected_res, "actual/expected values for 'res' are not equal"
