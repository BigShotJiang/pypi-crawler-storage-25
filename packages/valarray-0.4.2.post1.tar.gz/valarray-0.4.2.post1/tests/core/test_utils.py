from typing import Optional

import pytest

from tests.core.classes_for_testing import TestComparisons
from valarray.core.axes_and_fields import AxesTuple
from valarray.core.types import ArrayIndicesT, ArrayT, AxSizes
from valarray.core.utils import ax_sizes_from_schema, constraints_to_validators
from valarray.core.validators import ComparisonValidator


@pytest.mark.parametrize(
    "schema, expected_sizes",
    [(tuple(), tuple()), (("str", 3, ("a", "b", "c")), (None, 3, 3))],
)
def test_ax_sizes_from_schema(schema: AxesTuple, expected_sizes: AxSizes):
    sizes = ax_sizes_from_schema(schema)

    assert sizes == expected_sizes, "actual/expected values for 'sizes' are not equal"


TC = TestComparisons()


@pytest.mark.parametrize(
    "lt, le, ge, gt, eq, expected_validators",
    [
        (None, None, None, None, None, []),
        (1, None, None, None, None, [ComparisonValidator("lt", 1, TC)]),
        (
            1,
            2,
            3,
            4,
            5,
            [
                ComparisonValidator("lt", 1, TC),
                ComparisonValidator("le", 2, TC),
                ComparisonValidator("ge", 3, TC),
                ComparisonValidator("gt", 4, TC),
                ComparisonValidator("eq", 5, TC),
            ],
        ),
    ],
)
def test_constraints_to_validators(
    lt: Optional[int],
    le: Optional[int],
    ge: Optional[int],
    gt: Optional[int],
    eq: Optional[int],
    expected_validators: list[ComparisonValidator[ArrayT, ArrayIndicesT, int]],
):
    validators = constraints_to_validators(lt, le, ge, gt, eq, TC)

    assert (
        validators == expected_validators
    ), "actual/expected values for 'validators' are not equal"
