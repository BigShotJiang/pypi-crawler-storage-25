# pylint: disable=C0103:invalid-name
"""Settings for the whole module.
- function_cache_size: cache size for selected cached functions
"""

# NOTE: I don't know how to test this properly, but *should be* working OK.
import os

function_cache_size = int(os.environ.get("VALARRAY_FUNCTION_CACHE_SIZE", 512))
"""Set cache size for functions (default **512**): 
- `valarray.core.utils.ax_sizes_from_schema`
- `valarray.core.utils.constraints_to_validators`
- `valarray.core.string_utils.constraints_string`
- `valarray.core.string_utils.validators_heading_and_lines`
- `valarray.core.string_utils.field_heading_and_lines`
- `valarray.core.string_utils.array_name_and_type_string`
- `valarray.core.string_utils.dtype_string`
- `valarray.core.string_utils.schema_heading_and_lines`
- `valarray.core.string_utils.validated_array_heading_and_lines`
- `valarray.core.string_utils.offset_lines`
- `valarray.core.validation_functions.field_values.utils.resolve_schema`
- `valarray.core.validation_functions.field_values.utils.gather_validators`
"""
