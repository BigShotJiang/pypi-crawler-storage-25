"""
`.core` ***module*** - Core classes, functions
    on which concrete implemetations for specific array types are based upon.

`.numpy` ***module*** - Validating numpy arrays.
"""
