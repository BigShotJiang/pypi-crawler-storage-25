"""
*import* `AxesTuple` **TypeAlias** - defines axes of schema

*import* `FieldsTuple` **TypeAlias** - defines fields of schema axis

*import* `Field` **valarray.core.Field** - defines constraints on field
"""

from dataclasses import dataclass
from typing import Generic, TypeAlias

import numpy.typing as npt

import valarray.core
from valarray.numpy.types import AdvancedIndex, NumpyDTypeT

# NOTE: Need to specialize Field, FieldsTuple and AxesTuple,
# because Field with no set validators is not specialized with respect to array type (ArrayT).
# (Essentially trying to assign:
# Field[ArrayP, Any, Any] -> Field[npt.NDArray[Any], AdvancedIndex, object])


@dataclass(unsafe_hash=True)
class Field(
    valarray.core.Field[npt.NDArray[NumpyDTypeT], AdvancedIndex, object],
    Generic[NumpyDTypeT],
):
    """Field of an array axis.

    Arguments:
        name (Optional[str]): Optional descriptive name of field. Defaults to `None`.
        validators (tuple[Validator[npt.NDArray[NumpyDTypeT], AdvancedIndex], ...]):
            optional list of validators applied to field values
        lt (Optional[Any]):
            Optional constraint -> field values less than. Defaults to None.
        le (Optional[Any]):
            Optional constraint -> field values less or equal than. Defaults to None.
        ge (Optional[Any]):
            Optional constraint -> field values greater than. Defaults to None.
        gt (Optional[Any]):
            Optional constraint -> field values greater or equal than. Defaults to None.
        eq (Optional[Any]):
            Optional constraint -> field values equal to. Defaults to None.

    (introduced ***v0.4***, last_modified ***v0.4.1***)

    Examples:
    ```
    from typing import Any

    from valarray.numpy import Field, NumpyValidator

    class ExampleNumpyValidator(NumpyValidator[Any]):
        def validate(self, arr):
            return True

    f1 = Field("example_named_field", ge=0)
    f2 = Field(gt=10, validators=(ExampleNumpyValidator(),))

    ```
    """


FieldsTuple: TypeAlias = tuple[str | Field[NumpyDTypeT], ...]
"""Tuple of numpy array fields.

(introduced ***v0.4***)
"""

AxesTuple: TypeAlias = tuple[str | int | FieldsTuple[NumpyDTypeT], ...]
"""Tuple of numpy array axes. Can be either name, size or a tuple of fields.
```
import valarray.numpy

axes = (
    16,
    "items",
    ("x", "y", "length", valarray.numpy.Field()),
)
```

(introduced ***v0.4***)
"""
