from typing import Any

import numpy as np
import numpy.typing as npt

from valarray.core.array_type_adapter import Comparisons
from valarray.numpy.types import AdvancedIndex


class NumpyComparisons(Comparisons[npt.NDArray[Any], AdvancedIndex, Any]):
    """(introduced ***v0.3***)"""

    def where_not_lt(self, arr, value):
        """Returns indices of values which are ***not* less than** value.

        Indices are tuple of integer arrays of length equal to number of array axes

        -> `(np.array([idx0_axis0, idx1_axis0, ...]), np.array([idx0_axis1, idx1_axis1, ...]), ...)`

        ### Example:
        ``` # *not* less than 0
        arr = np.array(
            [
                [-1 ,0],
                [0, 1],
            ]
        )
        indices = (np.array([0, 1, 1]), np.array([1, 0, 1]))
        ```

        (introduced ***v0.3***)
        """
        return np.where(~(arr < value))

    def where_not_le(self, arr, value):
        """Returns indices of values which are ***not* less than or equal** value.

        Indices are tuple of integer arrays of length equal to number of array axes

        -> `(np.array([idx0_axis0, idx1_axis0, ...]), np.array([idx0_axis1, idx1_axis1, ...]), ...)`

        ### Example:
        ``` # *not*  less than or equal 0
        arr = np.array(
            [
                [-1 ,0],
                [0, 1],
            ]
        )
        indices = (np.array([0, 1, 1]), np.array([1, 0, 1]))
        ```

        (introduced ***v0.3***)
        """
        return np.where(~(arr <= value))

    def where_not_ge(self, arr, value):
        """Returns indices of values which are ***not* greater than or equal** value.

        Indices are tuple of integer arrays of length equal to number of array axes

        -> `(np.array([idx0_axis0, idx1_axis0, ...]), np.array([idx0_axis1, idx1_axis1, ...]), ...)`

        ### Example:
        ``` # *not*  greater than or equal 0
        arr = np.array(
            [
                [-1 ,0],
                [0, 1],
            ]
        )
        indices = (np.array([0, 1, 1]), np.array([1, 0, 1]))
        ```

        (introduced ***v0.3***)
        """
        return np.where(~(arr >= value))

    def where_not_gt(self, arr, value):
        """Returns indices of values which are ***not* greater than** value.

        Indices are tuple of integer arrays of length equal to number of array axes

        -> `(np.array([idx0_axis0, idx1_axis0, ...]), np.array([idx0_axis1, idx1_axis1, ...]), ...)`

        ### Example:
        ``` # *not*  greater than 0
        arr = np.array(
            [
                [-1 ,0],
                [0, 1],
            ]
        )
        indices = (np.array([0, 1, 1]), np.array([1, 0, 1]))
        ```

        (introduced ***v0.3***)
        """
        return np.where(~(arr > value))

    def where_not_eq(self, arr, value):
        """Returns indices of values which are ***not* equal** value.

        Indices are tuple of integer arrays of length equal to number of array axes

        -> `(np.array([idx0_axis0, idx1_axis0, ...]), np.array([idx0_axis1, idx1_axis1, ...]), ...)`

        ### Example:
        ``` # *not*  equal 0
        arr = np.array(
            [
                [-1 ,0],
                [0, 1],
            ]
        )
        indices = (np.array([0, 1, 1]), np.array([1, 0, 1]))
        ```

        (introduced ***v0.3***)
        """
        return np.where(~(arr == value))

    def n_indices(self, indices):
        """Counts the number of indices.

        (introduced ***v0.3***)
        """
        if isinstance(indices, np.ndarray) and indices.dtype == np.bool_:
            n = int(indices.sum())
        elif len(indices) == 0:
            n = 0
        else:
            n = len(indices[0])

        return n
