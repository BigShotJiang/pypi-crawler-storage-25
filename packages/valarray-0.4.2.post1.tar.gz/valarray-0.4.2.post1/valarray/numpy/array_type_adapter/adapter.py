from typing import Any

import numpy as np
import numpy.typing as npt

from valarray.core.array_type_adapter import ArrayTypeAdapter
from valarray.core.data_structures import FieldNameAndIdx
from valarray.numpy.types import AdvancedIndex

from .comparisons import NumpyComparisons
from .errors import NumpyErrors


class NumpyArrayTypeAdapter(
    ArrayTypeAdapter[
        npt.NDArray[Any],
        npt.DTypeLike,
        np.dtype[Any],
        AdvancedIndex,
        Any,
    ]
):
    """Adapter for numpy arrays.

    (introduced ***v0.1***, last_modified ***v0.4.1***)
    """

    @property
    def type_name(self):
        return "numpy"

    @property
    def errors(self):
        return NumpyErrors()

    @property
    def array_type(self):
        """(introduced ***v0.1***)"""
        return np.ndarray

    @property
    def comparisons(self) -> NumpyComparisons:
        """(introduced ***v0.3***)"""
        return NumpyComparisons()

    def change_dtype(self, arr, dtypelike):
        """(introduced ***v0.1***)"""
        return arr.astype(dtypelike)

    def create_array(self, obj, dtypelike):
        """(introduced ***v0.1***)"""
        if dtypelike == ...:
            arr = np.asarray(obj, None)
        else:
            arr = np.array(obj, dtypelike)

        return arr

    def is_array_empty(self, arr) -> bool:
        """(introduced ***v0.2.2***)"""
        return arr.size < 1

    def create_empty_array(self, ax_sizes, dtypelike):
        """(introduced ***v0.1.1***)"""
        dt = None if dtypelike == ... else dtypelike

        # Replace first and all unknown sizes with 0
        # (3,2, None, 1) => (0,2,0,1)
        shape = [0 if s is None else s for s in ax_sizes]
        if len(shape) > 0:
            shape[0] = 0

        return np.empty(shape, dt)

    def dtype_from_dtypelike(self, dtypelike):
        """(introduced ***v0.1***)"""
        return np.dtype(dtypelike)

    def dtypes_equal(self, actual_dtype, expected_dtype) -> bool:
        """(introduced ***v0.1***)"""
        return actual_dtype == expected_dtype

    def get_values(self, arr, indices):
        """Returns array values from indices defined by a boolean array
        or a tuple of integer arrays.

        (introduced ***v0.3***)"""
        if indices is None:
            return None

        try:
            vals = arr[indices].tolist()
        except IndexError:
            # TODO: add logger and warning
            vals = None

        return vals

    def select_subset(self, arr, ax, fields):
        selection = []
        for ax_i in range(len(arr.shape)):
            if ax_i == ax.idx:
                s = tuple(f.idx for f in fields)
            else:
                s = slice(None, None)

            selection.append(s)

        return arr[*selection]

    def get_values_from_subset(
        self,
        arr,
        indices,
        ax,
        fields,
    ):
        if indices is None:
            return None

        dic: dict[FieldNameAndIdx, list[Any]] = {}

        indices_tuple = indices if isinstance(indices, tuple) else np.where(indices)

        val_arr = arr[indices_tuple]

        field_idx_arr = indices_tuple[ax.idx]

        for i, f in enumerate(fields):
            vals = val_arr[field_idx_arr == i]

            if len(vals) < 1:
                continue

            dic[f] = vals.tolist()

        return dic
