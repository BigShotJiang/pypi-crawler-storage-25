from abc import abstractmethod
from typing import Any, Generic, Optional

import numpy.typing as npt

from valarray.core.validators import ComparisonValidator, ValidationResult, Validator

from .types import AdvancedIndex, NumpyDTypeT


class NumpyValidator(
    Validator[npt.NDArray[NumpyDTypeT], AdvancedIndex], Generic[NumpyDTypeT]
):
    """Base class for numpy array Validators.

    Type variables:
    - `NumpyDTypeT` - data type of array to be validated.

    Subclasses need to implement:
        **abstract method**
        - `validate` -
            Method to validate an array.

    Subclasses can optionally implement:
        **abstract method**
        - `__str__` -
            String representation of validator used in error messages.
            If not implemented defalts to class name.

    (introduced ***v0.3***)"""

    @abstractmethod
    def validate(
        self, arr: npt.NDArray[NumpyDTypeT]
    ) -> Optional[bool | ValidationResult[AdvancedIndex]]: ...


NumpyValidatorOrComparisonValidator = (
    NumpyValidator[NumpyDTypeT]
    | ComparisonValidator[npt.NDArray[NumpyDTypeT], AdvancedIndex, Any]
)


NumpyValidatorOrValidators = (
    NumpyValidatorOrComparisonValidator[NumpyDTypeT]
    | tuple[
        NumpyValidatorOrComparisonValidator[NumpyDTypeT],
        ...,
    ]
)
"""NumpyValidator (or a `ComparisonValidator`) or a tuple thereof."""
