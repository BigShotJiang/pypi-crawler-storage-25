"""
*import* `NumpyDTypeT` **TypeVar**

*import* `AdvancedIndex` **type**
"""

from typing import TypeVar

import numpy as np
import numpy.typing as npt

NumpyDTypeT = TypeVar("NumpyDTypeT", bound=np.generic)

type AdvancedIndex = npt.NDArray[np.bool_] | tuple[npt.NDArray[np.integer], ...]
"""Advanced numpy index using:
- a boolean array 
- tuple of integer arrays (length == nuber of array axes)

### Examples:
```
indices = np.array(
    [
        [False, False, False],
        [True, False, False],
        [False, False, True],
    ]
)

indices = (np.array([0, 1, 1]), np.array([1, 0, 1]))
```
(introduced ***v0.3***)
"""
