from __future__ import annotations

from functools import lru_cache
from typing import TYPE_CHECKING, Any, Optional

from valarray import settings
from valarray.core.data_structures import HeadingAndLines

from .headings import CONSTRAINTS_HEADING, VALIDATOR_HEADING

if TYPE_CHECKING:
    from valarray.core.validators import Validator


@lru_cache(settings.function_cache_size)
def constraints_string(
    lt: Optional[Any],
    le: Optional[Any],
    ge: Optional[Any],
    gt: Optional[Any],
    eq: Optional[Any],
) -> Optional[str]:
    """String representation of constraints used in `__str__` method of `ValidatedArrray` or `Field`
    or `None`  if all constraints are `None`.

    (introduced ***v0.4.1***)"""
    strings = []

    for val, operator in zip((lt, le, ge, gt, eq), ("<", "<=", ">=", ">", "==")):
        if val is not None:
            strings.append(f"{operator} {val}")

    full_string = CONSTRAINTS_HEADING + " " + ", ".join(strings) if strings else None

    return full_string


@lru_cache(settings.function_cache_size)
def validators_heading_and_lines(
    validators: tuple[Validator[Any, Any], ...],
) -> Optional[HeadingAndLines]:
    """String representation used in `__str__` method of `ValidatedArrray` or `Field`.
    Returned as a heading and list of lines of validator descriptions or `None` if no validators.

    (introduced ***v0.4.1***)"""
    if len(validators) < 1:
        return None

    return HeadingAndLines(
        VALIDATOR_HEADING, tuple(val.description for val in validators)
    )


@lru_cache(settings.function_cache_size)
def offset_lines(
    lines: tuple[str | HeadingAndLines, ...] | HeadingAndLines, depth: int = 0
) -> list[str]:
    """Recursively offsets a tuple of lines or headings and lines.

    (introduced ***v0.4.1***)"""
    tab = "  "

    lines_tuple = (lines,) if isinstance(lines, HeadingAndLines) else lines

    processed_lines: list[str] = []
    for line in lines_tuple:
        if isinstance(line, HeadingAndLines):
            processed_lines.append(tab * depth + line.heading)
            processed_lines.extend(offset_lines(line.lines, depth + 1))
            continue

        processed_lines.append(tab * depth + line)

    return processed_lines
