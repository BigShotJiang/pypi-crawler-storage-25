from __future__ import annotations

from functools import lru_cache
from types import EllipsisType
from typing import TYPE_CHECKING, Any, Optional

from valarray import settings
from valarray.core.data_structures import HeadingAndLines
from valarray.core.string_utils.headings import (
    DATA_TYPE_HEADING,
    SCHEMA_HEADING,
    VALUES_HEADING,
)
from valarray.core.types import ArrayP, DTypeLikeT

from .field import field_heading_and_lines
from .general import constraints_string, validators_heading_and_lines

if TYPE_CHECKING:
    from valarray.core import ArrayTypeAdapter
    from valarray.core.axes_and_fields import AxesTuple, FieldsTuple


@lru_cache(settings.function_cache_size)
def _process_axis_with_fields(
    fields: FieldsTuple[Any, Any, Any],
) -> tuple[str | HeadingAndLines, ...]:
    lines: list[str | HeadingAndLines] = []

    for fld_idx, fld in enumerate(iterable=fields):
        if isinstance(fld, str):
            lines.append(f"Field < {fld_idx} > : '{fld}'")
        else:
            lines.append(
                field_heading_and_lines(
                    fld.name,
                    constraints_string(fld.lt, fld.le, fld.ge, fld.gt, fld.eq),
                    validators_heading_and_lines(fld.validators),
                    fld_idx,
                )
            )

    return tuple(lines)


@lru_cache(settings.function_cache_size)
def schema_heading_and_lines(
    schema: AxesTuple[Any, Any, Any] | EllipsisType,
) -> Optional[HeadingAndLines]:
    """String representation used in `__str__` method of `ValidatedArrray`.
    Returned as a heading and list of lines or `None` if no schema is defined.

    (introduced ***v0.4.1***)"""
    if schema == ...:
        return None

    lines: list[str | HeadingAndLines] = []

    for ax_idx, ax in enumerate(schema):
        base_ax_str = f"Axis < {ax_idx} >"

        if isinstance(ax, int):
            lines.append(base_ax_str)
        elif isinstance(ax, str):
            ax_name_str = f" : '{ax}'"
            lines.append(base_ax_str + ax_name_str)
        else:
            lines.append(HeadingAndLines(base_ax_str, _process_axis_with_fields(ax)))

    return HeadingAndLines(SCHEMA_HEADING, tuple(lines))


@lru_cache(settings.function_cache_size)
def array_name_and_type_string(
    name: str, ata: ArrayTypeAdapter[Any, Any, Any, Any, Any]
) -> str:
    return f"{name} (type: '{ata.type_name}')"


@lru_cache(settings.function_cache_size)
def dtype_string(
    dtypelike: DTypeLikeT | EllipsisType,
    ata: ArrayTypeAdapter[Any, DTypeLikeT, Any, Any, Any],
) -> Optional[str]:
    return (
        f"{DATA_TYPE_HEADING} '{dtypelike}' ({ata.dtype_from_dtypelike(dtypelike)})"
        if dtypelike != ...
        else None
    )


# NOTE: no cache here, because array values are unhashable
def array_values_hal(array: ArrayP) -> HeadingAndLines:
    return HeadingAndLines(VALUES_HEADING, (str(array),))


@lru_cache(settings.function_cache_size)
def validated_array_heading_and_lines(
    array_name_and_type_str: str,
    dtype_str: Optional[str],
    schema_hal: Optional[HeadingAndLines],
    constraints_str: Optional[str],
    validators_hal: Optional[HeadingAndLines],
    array_hal: HeadingAndLines,
) -> HeadingAndLines:
    lines = tuple(
        l
        for l in (dtype_str, schema_hal, constraints_str, validators_hal, array_hal)
        if l is not None
    )

    return HeadingAndLines(array_name_and_type_str, lines)
