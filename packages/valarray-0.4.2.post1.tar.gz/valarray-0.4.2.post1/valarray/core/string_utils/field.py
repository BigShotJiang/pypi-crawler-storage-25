from __future__ import annotations

from functools import lru_cache
from typing import Optional

from valarray import settings
from valarray.core.data_structures import HeadingAndLines


@lru_cache(settings.function_cache_size)
def field_heading_and_lines(
    name: Optional[str],
    constraints_str: Optional[str],
    validators_hal: Optional[HeadingAndLines],
    idx: Optional[int] = None,
) -> HeadingAndLines:
    """String representation used in `__str__` method of `ValidatedArrray` or `Field`.
    Returned as a heading and list of lines.

    (introduced ***v0.4.1***)"""

    lines: list[str | HeadingAndLines] = []

    idx_str = str(idx) if idx is not None else "?"

    name_str = f" : '{name}'" if name is not None else ""

    fld_str = f"Field < {idx_str} >{name_str}"

    if constraints_str is not None:
        lines.append(constraints_str)

    if validators_hal is not None:
        lines.append(validators_hal)

    return HeadingAndLines(fld_str, tuple(lines))
