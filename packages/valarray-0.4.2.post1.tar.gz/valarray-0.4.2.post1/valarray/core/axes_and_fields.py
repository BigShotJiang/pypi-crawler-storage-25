"""
*import* `AxesTuple` **TypeAlias** - defines axes of schema

*import* `FieldsTuple` **TypeAlias** - defines fields of schema axis

*import* `Field` **dataclass** - defines constraints on field
"""

from dataclasses import dataclass
from typing import Generic, Optional, TypeAlias

from valarray.core.string_utils import (
    constraints_string,
    field_heading_and_lines,
    offset_lines,
    validators_heading_and_lines,
)
from valarray.core.validators import ValidatorOrValidatorTuple

from .types.generics import ArrayIndicesT, ArrayT, ComparableValueT


@dataclass(unsafe_hash=True)
class Field(Generic[ArrayT, ArrayIndicesT, ComparableValueT]):
    """Field of an array axis.

    Arguments:
        name (Optional[str]): Optional descriptive name of field. Defaults to `None`.
        validators (ValidatorOrValidators[ArrayT, ArrayIndicesT, ComparableValueT]):
            optional validator or validators applied to field values
        lt (Optional[ComparableValueT]):
            Optional constraint -> field values less than. Defaults to None.
        le (Optional[ComparableValueT]):
            Optional constraint -> field values less or equal than. Defaults to None.
        ge (Optional[ComparableValueT]):
            Optional constraint -> field values greater than. Defaults to None.
        gt (Optional[ComparableValueT]):
            Optional constraint -> field values greater or equal than. Defaults to None.
        eq (Optional[ComparableValueT]):
            Optional constraint -> field values equal to. Defaults to None.

    (introduced ***v0.4***, last_modified ***v0.4.1***)
    """

    name: Optional[str] = None
    validators: ValidatorOrValidatorTuple[ArrayT, ArrayIndicesT, ComparableValueT] = (
        tuple()
    )

    lt: Optional[ComparableValueT] = None
    le: Optional[ComparableValueT] = None
    ge: Optional[ComparableValueT] = None
    gt: Optional[ComparableValueT] = None
    eq: Optional[ComparableValueT] = None

    def __str__(self) -> str:
        """(introduced ***v0.4.1***)"""
        lines = field_heading_and_lines(
            self.name,
            constraints_string(self.lt, self.le, self.ge, self.gt, self.eq),
            validators_heading_and_lines(self.validators),
        )
        processed_lines = offset_lines(lines)
        return "\n".join(processed_lines)


FieldsTuple: TypeAlias = tuple[
    str | Field[ArrayT, ArrayIndicesT, ComparableValueT], ...
]
"""Tuple of array fields.

(introduced ***v0.1.1***, last_modified ***v0.4***)
"""

AxesTuple: TypeAlias = tuple[
    str | int | FieldsTuple[ArrayT, ArrayIndicesT, ComparableValueT], ...
]
"""Tuple of array axes. Can be either name, size or a tuple of fields.
```
import valarray.core

axes = (
    16,
    'items',
    ('x','y', valarray.core.Field()),
)
```

(introduced ***v0.1.1***, last_modified ***v0.4***)
"""
