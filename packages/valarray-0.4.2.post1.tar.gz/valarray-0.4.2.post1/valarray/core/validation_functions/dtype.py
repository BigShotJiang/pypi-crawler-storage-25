from types import EllipsisType
from typing import Any

from valarray.core.array_type_adapter import ArrayTypeAdapter
from valarray.core.errors_exceptions import IncorrectDTypeError, ValidationErrorList
from valarray.core.types import ArrayT, DTypeLikeT, DTypeT


def validate_dtype(
    arr: ArrayT,
    dtypelike: DTypeLikeT | EllipsisType,
    ata: ArrayTypeAdapter[ArrayT, DTypeLikeT, DTypeT, Any, Any],
) -> ValidationErrorList[IncorrectDTypeError[DTypeLikeT, DTypeT]]:
    """Validate that array has the correct dtype.

    Args:
        arr (ArrayT): Array to be validated.
        dtypelike (DTypeLikeT | EllipsisType): Expected datatype (if `...` , do not validate).
        ata (ArrayTypeAdapter[ArrayT, DTypeLikeT, DTypeT, ...]): Adapter for specific array type.

    Returns:
        errs (ValidationErrorList[IncorrectDTypeError]):
            list containing a single dtype error or an empty list.

    (introduced ***v0.1***, last_modified ***v0.4***)
    """
    errs: ValidationErrorList[IncorrectDTypeError[DTypeLikeT, DTypeT]] = (
        ValidationErrorList([])
    )

    if dtypelike == ...:
        return errs

    expected_dtype = ata.dtype_from_dtypelike(dtypelike)
    if not ata.dtypes_equal(arr.dtype, expected_dtype):
        errs.append(
            ata.errors.incorrect_dtype(
                actual_dtype=arr.dtype,
                expected_dtype=expected_dtype,
                expected_dtypelike=dtypelike,
            )
        )

    return errs
