from types import EllipsisType
from typing import Any

from valarray.core.array_type_adapter import ArrayTypeAdapter
from valarray.core.axes_and_fields import AxesTuple
from valarray.core.errors_exceptions import (
    IncorrectAxNumberError,
    IncorrectAxSizesError,
    IncorrectDTypeError,
    InvalidArrayValuesError,
    InvalidFieldValuesError,
    ValidationErrorList,
)
from valarray.core.types import (
    ArrayIndicesT,
    ArrayT,
    ComparableValueT,
    DTypeLikeT,
    DTypeT,
)
from valarray.core.validators import ValidatorOrValidatorSequence

from .array_values import validate_array_values
from .dtype import validate_dtype
from .field_values.core import validate_field_values
from .shape import validate_shape


def validate_array(
    arr: ArrayT,
    dtypelike: DTypeLikeT | EllipsisType,
    schema: AxesTuple[Any, Any, Any] | EllipsisType,
    validators: ValidatorOrValidatorSequence[ArrayT, ArrayIndicesT, ComparableValueT],
    ata: ArrayTypeAdapter[ArrayT, DTypeLikeT, DTypeT, ArrayIndicesT, ComparableValueT],
) -> ValidationErrorList[
    IncorrectAxNumberError
    | IncorrectAxSizesError
    | IncorrectDTypeError[DTypeLikeT, DTypeT]
    | InvalidArrayValuesError[ArrayT, ArrayIndicesT, ComparableValueT]
    | InvalidFieldValuesError[ArrayT, ArrayIndicesT, ComparableValueT]
]:
    """Validate array:
    - data type
    - shape (based on array schema)
    - array values (using a sequence of validators)
    - field values (based on validators defined in array schema)

    First validate data type and shape. If those are correct, validate field and array values.

    Args:
        arr (ArrayT): Array to be validated.
        dtypelike (DTypeLikeT | EllipsisType): Expected datatype (if `...` , do not validate).
        schema (AxesTuple | EllipsisType): Expected array schema (if `...` , do not validate).
        validators (ValidatorOrValidatorSequence[ArrayT, ArrayIndicesT, ComparableValueT]):
            Validator(s) to apply.
        ata (ArrayTypeAdapter[ArrayT, DTypeLikeT, DTypeT, ArrayIndicesT, ComparableValueT]):
            Adapter for specific array type.

    Returns:
        ValidationErrorList[ValidationError]: Validation errors.

    (introduced ***v0.4***)
    """
    errs: ValidationErrorList[
        IncorrectAxNumberError
        | IncorrectAxSizesError
        | IncorrectDTypeError[DTypeLikeT, DTypeT]
        | InvalidArrayValuesError[ArrayT, ArrayIndicesT, ComparableValueT]
        | InvalidFieldValuesError[ArrayT, ArrayIndicesT, ComparableValueT]
    ] = ValidationErrorList([])

    errs += validate_dtype(arr, dtypelike, ata)
    errs += validate_shape(arr, schema)

    if errs:
        return errs

    errs += validate_array_values(arr, validators, ata)
    errs += validate_field_values(arr, schema, ata)

    return errs
