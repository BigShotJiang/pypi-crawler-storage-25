from dataclasses import dataclass
from types import EllipsisType
from typing import Any, Optional

from valarray.core.axes_and_fields import AxesTuple
from valarray.core.errors_exceptions import (
    IncorrectAxNumberError,
    IncorrectAxSizesError,
    ValidationErrorList,
)
from valarray.core.types import ArrayP
from valarray.core.utils import ax_sizes_from_schema


@dataclass
class _AxComp:
    actual: int
    expected: Optional[int]


def validate_shape(
    arr: ArrayP,
    schema: AxesTuple[Any, Any, Any] | EllipsisType,
) -> ValidationErrorList[IncorrectAxNumberError | IncorrectAxSizesError]:
    """Validate that array has the correct shape.

    Args:
        arr (ArrayT): Array to be validated.
        schema (AxesTuple | EllipsisType):
            Expected array schema (if `...` , do not validate).

    Returns:
        errs (ValidationErrorList[IncorrectAxNumberError | IncorrectAxSizesError]):
            incorrect ax number error and/or incorrect ax sizes error

    (introduced ***v0.2***, last_modified ***v0.4***)
    """
    errs: ValidationErrorList[IncorrectAxNumberError | IncorrectAxSizesError] = (
        ValidationErrorList([])
    )

    if schema == ...:
        return errs

    ax_sizes = ax_sizes_from_schema(schema)

    n_ax_actual = len(arr.shape)
    n_ax_expected = len(ax_sizes)
    if n_ax_actual != n_ax_expected:
        errs.append(IncorrectAxNumberError(n_ax_actual, n_ax_expected))

    min_n_ax = min(n_ax_actual, n_ax_expected)

    incorrect_indices: list[int] = []
    for i, ax in enumerate(
        [_AxComp(a, e) for a, e in zip(arr.shape[:min_n_ax], ax_sizes[:min_n_ax])]
    ):
        if ax.expected is None:
            continue

        if ax.actual not in (ax.expected, 0):
            incorrect_indices.append(i)

    if incorrect_indices:
        errs.append(IncorrectAxSizesError(arr.shape, ax_sizes, incorrect_indices))

    return errs
