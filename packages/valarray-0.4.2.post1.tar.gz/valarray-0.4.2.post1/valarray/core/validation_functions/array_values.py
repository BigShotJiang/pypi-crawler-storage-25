from typing import Any

from valarray.core.array_type_adapter import ArrayTypeAdapter
from valarray.core.errors_exceptions import InvalidArrayValuesError, ValidationErrorList
from valarray.core.types import ArrayIndicesT, ArrayT, ComparableValueT
from valarray.core.validation_functions.utils import apply_validator
from valarray.core.validators import ValidatorOrValidatorSequence


def validate_array_values(
    arr: ArrayT,
    validators: ValidatorOrValidatorSequence[ArrayT, ArrayIndicesT, ComparableValueT],
    ata: ArrayTypeAdapter[ArrayT, Any, Any, ArrayIndicesT, Any],
) -> ValidationErrorList[
    InvalidArrayValuesError[ArrayT, ArrayIndicesT, ComparableValueT]
]:
    """Validate array with a sequence of validators applied to the whole array
    and return potential errors.

    Args:
        arr (ArrayT): Array to be validated.
        validators (ValidatorOrValidatorSequence[ArrayT, ArrayIndicesT, ComparableValueT]): Validator(s) to apply.
        ata (ArrayTypeAdapter[ArrayT, Any, Any, ArrayIndicesT, Any]):
            Adapter for specific array type.

    Returns:
        errs (ValidationErrorList[InvalidArrayValuesError[ArrayT, ArrayIndicesT, ComparableValueT]]):
            List containing at most 1 error per validator.

    (introduced ***v0.3***, last_modified ***v0.4***)
    """
    errs: ValidationErrorList[
        InvalidArrayValuesError[ArrayT, ArrayIndicesT, ComparableValueT]
    ] = ValidationErrorList([])

    for validator in validators:
        res = apply_validator(validator, arr)

        if res.status == "FAIL":
            invalid_values = ata.get_values(arr, res.indices_invalid)

            errs.append(
                ata.errors.invalid_array_values(
                    validator, invalid_values, res.indices_invalid, res.msg
                )
            )

    return errs
