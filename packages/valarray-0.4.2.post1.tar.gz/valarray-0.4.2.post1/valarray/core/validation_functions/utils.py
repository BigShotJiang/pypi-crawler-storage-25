from valarray.core.types import ArrayIndicesT, ArrayT
from valarray.core.validators.base import ValidationResult, Validator


def apply_validator(
    validator: Validator[ArrayT, ArrayIndicesT], arr: ArrayT
) -> ValidationResult[ArrayIndicesT]:
    """Call `validator.validate()` method on array, catch `ValueError` and return `ValidationResult`

    (introduced ***v0.3***)
    """
    try:
        res_or_bool_or_none = validator.validate(arr)

        if isinstance(res_or_bool_or_none, ValidationResult):
            res = res_or_bool_or_none
        elif res_or_bool_or_none in (None, True):
            res = ValidationResult("OK")
        else:
            res = ValidationResult("FAIL")
    except ValueError as val_err:
        res = ValidationResult("FAIL", msg=str(val_err))

    return res
