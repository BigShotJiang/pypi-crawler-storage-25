from types import EllipsisType
from typing import Any, Literal, overload

from valarray.core.array_type_adapter import ArrayTypeAdapter
from valarray.core.axes_and_fields import AxesTuple
from valarray.core.data_structures import AxisNameAndIdx, FieldNameAndIdx
from valarray.core.errors_exceptions import (
    IncorrectAxNumberError,
    IncorrectAxSizesError,
    InvalidFieldValuesError,
    ValidationErrorList,
)
from valarray.core.types import ArrayIndicesT, ArrayT, ComparableValueT
from valarray.core.validation_functions.shape import validate_shape

from .types_and_data_structures import _FieldValidatorDict
from .utils import gather_validators, process_axis, resolve_schema


@overload
def validate_field_values(
    arr: ArrayT,
    schema: AxesTuple[ArrayT, ArrayIndicesT, ComparableValueT] | EllipsisType,
    ata: ArrayTypeAdapter[ArrayT, Any, Any, ArrayIndicesT, ComparableValueT],
    check_shape: Literal[False] = False,
) -> ValidationErrorList[
    InvalidFieldValuesError[ArrayT, ArrayIndicesT, ComparableValueT]
]: ...


@overload
def validate_field_values(
    arr: ArrayT,
    schema: AxesTuple[ArrayT, ArrayIndicesT, ComparableValueT] | EllipsisType,
    ata: ArrayTypeAdapter[ArrayT, Any, Any, ArrayIndicesT, ComparableValueT],
    check_shape: Literal[True] = True,
) -> (
    ValidationErrorList[
        InvalidFieldValuesError[ArrayT, ArrayIndicesT, ComparableValueT]
    ]
    | ValidationErrorList[IncorrectAxNumberError | IncorrectAxSizesError]
): ...


def validate_field_values(
    arr: ArrayT,
    schema: AxesTuple[ArrayT, ArrayIndicesT, ComparableValueT] | EllipsisType,
    ata: ArrayTypeAdapter[ArrayT, Any, Any, ArrayIndicesT, ComparableValueT],
    check_shape: bool = False,
) -> (
    ValidationErrorList[
        InvalidFieldValuesError[ArrayT, ArrayIndicesT, ComparableValueT]
    ]
    | ValidationErrorList[IncorrectAxNumberError | IncorrectAxSizesError]
):
    """Validate array fields with validators defined in schema and return potential errors.

    Args:
        arr (ArrayT): Array to be validated.
        schema (AxesTuple | EllipsisType):
            Array schema (if `...` , do not validate).
        ata (ArrayTypeAdapter[ArrayT, Any, Any, ArrayIndicesT, Any]):
            Adapter for specific array type.
        check_shape (bool, optional): If `True`, check shape with `validate_shape()` first.
            Defaults to False.

    Returns:
        errs (ValidationErrorList[InvalidFieldValuesError[ArrayT, ArrayIndicesT, ComparableValueT]]):
            List containing at most 1 error per validator
            (including built-in field value comparisons like `gt`, `lt` etc.).

    (introduced ***v0.4***)
    """

    if check_shape:
        shape_errs = validate_shape(arr, schema)
        if shape_errs:
            return shape_errs

    errs: ValidationErrorList[
        InvalidFieldValuesError[ArrayT, ArrayIndicesT, ComparableValueT]
    ] = ValidationErrorList([])

    if schema == ...:
        return errs

    resolved_schema = resolve_schema(schema, ata.comparisons)

    # NOTE: lru_cache does not play nice with generics,
    # putting type here explicitly so pyright doesn't yell at me
    val_dict: _FieldValidatorDict[ArrayT, ArrayIndicesT, ComparableValueT] = (
        gather_validators(resolved_schema)
    )

    for validator, axes_and_fields in val_dict.items():
        invalid_values_dict: dict[AxisNameAndIdx, dict[FieldNameAndIdx, Any]] = {}
        is_fail = False

        # TODO: add indices of invalid values to error

        for ax, fields in axes_and_fields.items():
            status, invalid_values = process_axis(arr, validator, ax, fields, ata)

            if status == "FAIL":
                is_fail = True

                if invalid_values is not None:
                    invalid_values_dict[ax] = invalid_values

        if is_fail:
            invalid_vals = (
                invalid_values_dict if len(invalid_values_dict.items()) > 0 else None
            )
            errs.append(
                ata.errors.invalid_field_values(validator, invalid_values=invalid_vals)
            )

    return errs
