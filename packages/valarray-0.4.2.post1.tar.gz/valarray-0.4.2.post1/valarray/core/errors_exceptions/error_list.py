from __future__ import annotations

from collections import UserList
from typing import Generic, Sequence, overload

from .validation_errors.base import SelectedValidationErrorT, ValidationErrorT

_ErrorTypes = (
    type[SelectedValidationErrorT] | tuple[type[SelectedValidationErrorT], ...]
)
"""Error type or a tuple of error types. 
For example `IncorrectAxSizesError` or `(IncorrectAxSizesError, IncorrectDTypeError)`"""


class ValidationErrorList(UserList[ValidationErrorT], Generic[ValidationErrorT]):
    """List of `ValidationError` objects.

    Compared to built-in list, implements two methods:
        - `raise_`/`raise_on_errors` - raises `ValidationException` if not empty.
        - `__getitem__` - in addition to indexing by integer or slice can be filtered by type
            or tuple of types of `ValidationError`

            ### Examples:
            ```
            errs = ValidationErrorList(
                [IncorrectAxSizesError(...), IncorrectDTypeError(...), InvalidFieldValuesError(...)]
                )

            err = errs[0]
            >>> IncorrectAxSizesError(...)

            sliced_errs = errs[:2]
            >>> [IncorrectAxSizesError(...), IncorrectDTypeError(...)]

            filtered_errs_type = errs[IncorrectAxSizesError]
            >>> [IncorrectAxSizesError(...)]

            filtered_errs_tuple = errs[(IncorrectAxSizesError, InvalidFieldValuesError)]
            >>> [IncorrectAxSizesError(...), InvalidFieldValuesError(...)]
            ```
    """

    def __init__(self, errs: Sequence[ValidationErrorT]):
        super().__init__(errs)

    def raise_(self):
        """Raises `ValidationException` if there are errors."""
        # NOTE: scoped import to prevent circular import
        # ValidationException -> ValidationErrorList -> ValidationException
        from .exceptions import ValidationException

        if self.data:
            raise ValidationException(None, ValidationErrorList(self.data))

    raise_on_errors = raise_

    @overload
    def __getitem__(self, i: int) -> ValidationErrorT: ...

    @overload
    def __getitem__(self, i: slice) -> ValidationErrorList[ValidationErrorT]: ...

    @overload
    def __getitem__(
        self,
        i: _ErrorTypes[SelectedValidationErrorT],
    ) -> ValidationErrorList[SelectedValidationErrorT]: ...

    def __getitem__(
        self,
        i: int | slice | _ErrorTypes[SelectedValidationErrorT],
    ) -> (
        ValidationErrorList[SelectedValidationErrorT]
        | ValidationErrorList[ValidationErrorT]
        | ValidationErrorT
    ):
        if isinstance(i, (type, tuple)):
            filtered_errs: list[SelectedValidationErrorT] = [
                err for err in self.data if isinstance(err, i)
            ]  # pyright: ignore[reportAssignmentType] | I don't know why pyright complains
            items = ValidationErrorList(filtered_errs)
        elif isinstance(i, slice):
            items = type(self)(self.data[i])
        else:
            items = self.data[i]

        return items
