from .base import ValidationError


# [?] What information should this error contain, if any?
class CannotCreateArrayError(ValidationError):
    """Error caused by array type adapter not being able to create an array of specified data type
    from supplied object.

    (introduced ***v0.1***)
    """

    @property
    def msg(self) -> str:
        return "Cannot create array."
