from dataclasses import dataclass
from typing import Any, Generic, Optional

from valarray.core.data_structures import AxisNameAndIdx, FieldNameAndIdx
from valarray.core.types import ArrayIndicesT, ArrayT, ComparableValueT
from valarray.core.validators import ValidatorOrComparisonValidator

from .base import ValidationError


@dataclass
class _InvalidValuesError(
    ValidationError, Generic[ArrayT, ArrayIndicesT, ComparableValueT]
):
    validator: ValidatorOrComparisonValidator[ArrayT, ArrayIndicesT, ComparableValueT]
    # TODO: add extra


@dataclass
class InvalidArrayValuesError(
    _InvalidValuesError[ArrayT, ArrayIndicesT, ComparableValueT]
):
    """***ValidationError:*** Array has wrong values.

    Attributes:
        validator: (rayT, ArrayIndicesT, ComparableValueT]): Validator applied to the whole array.
        invalid_values (Optional[list[Any]]):
            Values causing the validation to fail. Defaults to None.
        invalid_indices (Optional[ArrayIndicesT]): Indices of invalid values.
        result_msg (Optional[str]): Optional message returned by validator.

    (introduced ***v0.3***, last_modified ***v0.4***)
    """

    invalid_values: Optional[list[Any]] = None
    invalid_indices: Optional[ArrayIndicesT] = None
    result_msg: Optional[str] = None

    @property
    def msg(self) -> str:
        validator_desc = self.validator.error_string

        header = f"Invalid Array Values ({validator_desc})"

        if self.invalid_values is None and self.result_msg is None:
            return f"{header}."

        lines = []

        if self.invalid_values is not None:
            lines.append(f"\t{self.invalid_values}")

        if self.result_msg is not None:
            lines.append(f"\t{self.result_msg}")

        return header + ":\n" + "\n".join(lines)


type InvalidFieldValues = dict[AxisNameAndIdx, dict[FieldNameAndIdx, Any]]


def _invalid_field_values_to_lines(ifv: InvalidFieldValues) -> list[str]:
    lines: list[str] = []
    for ax, fld_dict in ifv.items():
        ax_name_str = f": '{ax.name}'" if ax.name is not None else ""

        lines.append(f"\tAxis < {ax.idx} >{ax_name_str}")

        for fld, invalid_values in fld_dict.items():
            fld_name_str = f": '{fld.name}'" if fld.name is not None else ""
            lines.append(f"\t\tField < {fld.idx} >{fld_name_str}: {invalid_values}")

    return lines


@dataclass
class InvalidFieldValuesError(
    _InvalidValuesError[ArrayT, ArrayIndicesT, ComparableValueT]
):
    """***ValidationError:*** Field or fields have wrong values.

    Attributes:
        validator: (rayT, ArrayIndicesT, ComparableValueT]): Validator applied to array field(s).
        invalid_values (Optional[InvalidFieldValues]):
            Values causing the validation to fail, organized by axis and field. Defaults to None.

    (introduced ***v0.4***)
    """

    invalid_values: Optional[InvalidFieldValues] = None

    @property
    def msg(self) -> str:
        validator_desc = self.validator.error_string

        header = f"Invalid Field Values ({validator_desc})"

        if self.invalid_values is None:
            return f"{header}."

        lines = []

        lines.extend(_invalid_field_values_to_lines(self.invalid_values))

        return header + ":\n" + "\n".join(lines)
