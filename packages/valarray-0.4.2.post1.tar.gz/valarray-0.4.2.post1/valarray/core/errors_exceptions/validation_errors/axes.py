from dataclasses import dataclass

from valarray.core.types import AxSizes

from .base import ValidationError


@dataclass
class IncorrectAxNumberError(ValidationError):
    """***Validation error:*** Array has incorrect number of axes.

    Attributes:
        actual_axis_number (int): Number of axes of the actual array.
        expected_axis_number (int): Number of axes inferred from schema.

    (introduced ***v0.2***)
    """

    actual_axis_number: int
    expected_axis_number: int

    @property
    def msg(self) -> str:
        act = self.actual_axis_number
        exp = self.expected_axis_number
        return f"Incorrect number of axes: {act}, expected {exp}."


@dataclass
class IncorrectAxSizesError(ValidationError):
    """***Validation error:*** Array has ax(es) with incorrect size(s).

    Attributes:
        actual_sizes (tuple[int, ...]): Ax sizes of the actual array.
        expected_sizes (AxSizes):
            Expected ax sizes (or None for variable sized axis) inferred from schema.
        incorrect_size_indices (list[int]): Indices of which axes have incorrect sizes.

    Examples:
    ```
    err = IncorrectAxSizesError(
        (1, 2, 3, 4), [2, None, 1, 4], incorrect_size_indices=[0, 2]
    ),
    print(err.msg)
    >>> "Incorrect axis sizes: (*1*, 2, *3*, 4), expected (2, any, 1, 4)."
    ```

    (introduced ***v0.2***, last_modified ***v0.3***)
    """

    actual_sizes: tuple[int, ...]
    expected_sizes: AxSizes
    incorrect_size_indices: list[int]

    @property
    def msg(self) -> str:
        act_sizes_str_list = [
            f"*{s}*" if i in self.incorrect_size_indices else str(s)
            for i, s in enumerate(self.actual_sizes)
        ]
        act_size_str = "(" + ", ".join(act_sizes_str_list) + ")"

        exp_sizes_str_list = [
            str(a) if a is not None else "any" for a in self.expected_sizes
        ]
        exp_size_str = "(" + ", ".join(exp_sizes_str_list) + ")"

        return f"Incorrect axis sizes: {act_size_str}, expected {exp_size_str}."
