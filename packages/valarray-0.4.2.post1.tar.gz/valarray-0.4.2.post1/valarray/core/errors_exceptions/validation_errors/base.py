from abc import ABC, abstractmethod
from typing import TypeVar


class ValidationError(ABC):
    """Base validation error. Subclasses need to implement:

    **abstract property**
    - `msg` -
        Human readeble description of error.

    (introduced ***v0.1***)
    """

    @property
    @abstractmethod
    def msg(self) -> str: ...


ValidationErrorT = TypeVar("ValidationErrorT", bound=ValidationError)
"""Validation error types contained in the error list.
(introduced ***v0.4***)"""

SelectedValidationErrorT = TypeVar("SelectedValidationErrorT", bound=ValidationError)
"""Validation error types to be selected from the error list.
(introduced ***v0.4***)"""
