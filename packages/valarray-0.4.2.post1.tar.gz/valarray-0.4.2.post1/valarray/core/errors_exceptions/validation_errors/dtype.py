from dataclasses import dataclass
from typing import Generic

from valarray.core.types import DTypeLikeT, DTypeT

from .base import ValidationError


def _dtype_str(dtype, dtypelike):
    """`"dtype"`` OR `"dtypelike (dtype)"``"""
    return str(dtype) if dtype == dtypelike else f"{dtypelike} ({dtype})"


@dataclass
class IncorrectDTypeError(ValidationError, Generic[DTypeLikeT, DTypeT]):
    """***Validation error:*** Array has the wrong data type.

    Attributes:
        actual_dtype (DTypeT): Data type of the actual array.
        expected_dtype (DTypeT): Expected data type (as a data type object).
        expected_dtypelike (DTypeLikeT):
            Expected data type specification from `ValidatedArray.dtype`.

    (introduced ***v0.1***, last_modified ***v0.2.4***)
    """

    actual_dtype: DTypeT
    expected_dtype: DTypeT
    expected_dtypelike: DTypeLikeT

    @property
    def msg(self) -> str:
        e = _dtype_str(self.expected_dtype, self.expected_dtypelike)

        return f"Incorrect DType: '{self.actual_dtype}', expected '{e}'."


@dataclass
class CannotCoerceDTypeError(ValidationError, Generic[DTypeLikeT, DTypeT]):
    """***Validation error:*** Array type adapter is not able to convert an existing array
    to specified data type when creating an instance of ValidatedArray.

    Attributes:
        actual_dtype (DTypeT): Data type of array passed to `ValidatedArray.__init__`.
        target_dtype (DTypeT): Data type to convert to (as a data type object).
        target_dtypelike (DTypeLikeT):
            Expected data type specification from `ValidatedArray.dtype`.

    (introduced ***v0.1***, last_modified ***v0.2.4***)
    """

    actual_dtype: DTypeT
    target_dtype: DTypeT
    target_dtypelike: DTypeLikeT

    @property
    def msg(self) -> str:
        e = _dtype_str(self.target_dtype, self.target_dtypelike)

        return f"Cannot coerce data type from: '{self.actual_dtype}' to '{e}'."
