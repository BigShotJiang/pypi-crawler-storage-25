from abc import ABC, abstractmethod
from types import EllipsisType
from typing import Any, Final, Generic, Optional, Self

from valarray.core.axes_and_fields import AxesTuple
from valarray.core.string_utils import (
    array_name_and_type_string,
    constraints_string,
    dtype_string,
    offset_lines,
    schema_heading_and_lines,
    validated_array_heading_and_lines,
    validators_heading_and_lines,
)
from valarray.core.string_utils.array import array_values_hal

from .array_type_adapter import ArrayTypeAdapter
from .axes_and_fields import AxesTuple
from .errors_exceptions import ValidationException
from .types import ArrayIndicesT, ArrayT, ComparableValueT, DTypeLikeT, DTypeT
from .utils import constraints_to_validators, setup_array
from .validation_functions import validate_array
from .validators import ValidatorOrValidatorTuple


class ValidatedArray(
    ABC, Generic[ArrayT, DTypeLikeT, DTypeT, ArrayIndicesT, ComparableValueT]
):
    """Abstract base class for Validated Array implementations.
    Subclasses need to implement:

    **abstract property**
    - `ata` -> returns a subclass of `ArrayTypeAdapter`

    You should also specify generic type variables:
    - `ArrayT` - type of array object
    - `DTypeLikeT` - data type specification
    - `DTypeT` - data type object
    - `ArrayIndexT` - object(s) that can select values from array using `__getitem__` method.
    - `ComparableValueT` - type of object an array can be compared with.

    (introduced ***v0.1***, last_modified ***v0.4.1***)
    """

    dtype: DTypeLikeT | EllipsisType = ...
    schema: AxesTuple[ArrayT, ArrayIndicesT, ComparableValueT] | EllipsisType = ...
    validators: ValidatorOrValidatorTuple[ArrayT, ArrayIndicesT, ComparableValueT] = ()

    lt: Optional[ComparableValueT] = None
    le: Optional[ComparableValueT] = None
    ge: Optional[ComparableValueT] = None
    gt: Optional[ComparableValueT] = None
    eq: Optional[ComparableValueT] = None

    @property
    @abstractmethod
    def ata(
        self,
    ) -> ArrayTypeAdapter[ArrayT, DTypeLikeT, DTypeT, ArrayIndicesT, ComparableValueT]:
        """Interface for operations that have different implementations for each array type."""

    def __init__(self, obj: Any, validate=True, coerce_dtype=False) -> None:
        self.is_validated = False

        self._array: Final[ArrayT] = setup_array(
            obj,
            self.dtype,
            coerce_dtype,
            self.schema,
            self.ata,
            self.__class__.__name__,
        )  # [!] CreateArrayException, CoerceDTypeException

        if validate:
            self.validate_array()

    @classmethod
    def wrap(cls, array: ArrayT) -> Self:
        """Creates `ValidatedArray` without validation.

        (introduced ***v0.1***, last_modified ***v0.1.1***)
        """
        return cls(array, validate=False)

    @classmethod
    def validate(cls, array: ArrayT) -> Self:
        """Creates `ValidatedArray` by validating an existing array.

        (introduced ***v0.1***, last_modified ***v0.1.1***)
        """
        return cls(array, validate=True)

    @classmethod
    def empty(cls) -> Self:
        """Creates empty `ValidatedArray` by validating an existing array.

        (introduced ***v0.1.1***)
        """
        return cls(None)

    def validate_array(self):
        """Validate array if it isn't already validated.

        (introduced ***v0.1***, last_modified ***v.0.4***)"""
        if self.is_validated:
            return

        # TODO: do not validate dtype if not necessary

        validators = constraints_to_validators(
            self.lt, self.le, self.ge, self.gt, self.eq, self.ata.comparisons
        ) + list(self.validators)

        errs = validate_array(
            self._array, self.dtype, self.schema, validators, self.ata
        )

        if errs:
            # T!: need to refactor exceptions
            # so ValidationException only accepts a list of errors returned by validation functions.
            raise ValidationException(
                self.__class__.__name__, errs  # pyright: ignore[reportArgumentType]
            )

        self.is_validated = True

    def __repr__(self) -> str:
        """(introduced ***v0.1***, last_modified ***v0.2.2***)"""
        cls_name = self.__class__.__name__

        if self.ata.is_array_empty((self._array)):
            rep = f"{cls_name}.empty()"
        else:
            rep = f"{cls_name}({repr(self._array)})"
        return rep

    def __len__(self) -> int:
        """(introduced ***v0.4.1***)"""

        return len(self._array)

    def __str__(self) -> str:
        """(introduced ***v0.4.1***)"""

        lines = validated_array_heading_and_lines(
            array_name_and_type_string(self.__class__.__name__, self.ata),
            dtype_string(self.dtype, self.ata),
            schema_heading_and_lines(self.schema),
            constraints_string(self.lt, self.le, self.ge, self.gt, self.eq),
            validators_heading_and_lines(self.validators),
            array_values_hal(self._array),
        )
        processed_lines = offset_lines(lines)
        return "\n".join(processed_lines)
