from dataclasses import dataclass
from typing import Generic

from valarray.core.array_type_adapter import Comparisons
from valarray.core.types import (
    ArrayIndicesT,
    ArrayT,
    ComparableValueT,
    ComparisonOperator,
)

from .base import ValidationResult, Validator


def _get_comparison(
    operator: ComparisonOperator,
    comparisons: Comparisons[ArrayT, ArrayIndicesT, ComparableValueT],
):
    lookup = {
        "lt": comparisons.where_not_lt,
        "le": comparisons.where_not_le,
        "ge": comparisons.where_not_ge,
        "gt": comparisons.where_not_gt,
        "eq": comparisons.where_not_eq,
    }

    op = lookup.get(operator)

    if op is None:
        raise NotImplementedError

    return op


# NOTE: One day I will learn why pylance yells at me if
# ArrayT, ArrayIndicesT are not in both Validator AND Generic
@dataclass
class ComparisonValidator(
    Validator[ArrayT, ArrayIndicesT], Generic[ArrayT, ArrayIndicesT, ComparableValueT]
):
    """Validator that compares array with a value

    Attributes:
        operator (ComparisonOperator): ***"lt"***/***"le"***/***"ge"***/***"gt"***/***"eq"***/
        value (ComparableValueT): Value to compare with. Dependent on array type.
        comparisons (Comparisons[ArrayT, ArrayIndicesT, ComparableValueT]):
            Array type implementation of `Comparisons()` object.

    (introduced ***v0.3***)"""

    operator: ComparisonOperator
    value: ComparableValueT
    comparisons: Comparisons[ArrayT, ArrayIndicesT, ComparableValueT]

    def validate(self, arr) -> ValidationResult[ArrayIndicesT]:
        """Validate that array values conform to specified constraints.

        Args:
            arr (ArrayT): Array to validate.

        Returns:
            ValidationResult[ArrayIndicesT]: Result of validation,
                plus indices of invalid values if validation is unsuccessfull.

        (introduced ***v0.3***)
        """
        comp = _get_comparison(self.operator, self.comparisons)

        indices_invalid = comp(arr, self.value)

        n_invalid = self.comparisons.n_indices(indices_invalid)

        return ValidationResult(
            status=("FAIL" if n_invalid > 0 else "OK"),
            indices_invalid=indices_invalid if n_invalid > 0 else None,
        )

    @property
    def error_string(self) -> str:
        """String representation of validator used in error messages.

        ### Examples:
        ```
        comp_val = ComparisonValidator(operator="gt", value=3, ...)
        >>> comp_val.error_string
        >>> '<= 3'

        comp_val = ComparisonValidator(operator="eq", value=2.4, ...)
        >>> comp_val.error_string
        >>> '!= 2.4'
        ```

        (introduced ***v0.4.1***)
        """
        # NOTE: opposite operator, because the message makes more sense to me:
        # eg: Invalid * values (<= 0): [-1, -2]
        # instead of: Invalid * values (> 0): [-1, -2]
        lookup: dict[ComparisonOperator, str] = {
            "lt": ">=",
            "le": ">",
            "ge": "<",
            "gt": "<=",
            "eq": "!=",
        }

        op = lookup[self.operator]

        return f"{op} {self.value}"
