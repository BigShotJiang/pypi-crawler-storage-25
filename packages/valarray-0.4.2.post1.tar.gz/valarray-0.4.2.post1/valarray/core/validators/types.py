from typing import Sequence

from valarray.core.types import ArrayIndicesT, ArrayT, ComparableValueT

from .base import Validator
from .value_comparisons import ComparisonValidator

ValidatorOrComparisonValidator = (
    Validator[ArrayT, ArrayIndicesT]
    | ComparisonValidator[ArrayT, ArrayIndicesT, ComparableValueT]
)

# NOTE: need to differentiate between tuple and sequence, because Field and ValidatedArray need a hashable sequence,
# while validation functions do not.

ValidatorOrValidatorTuple = (
    ValidatorOrComparisonValidator[ArrayT, ArrayIndicesT, ComparableValueT]
    | tuple[
        ValidatorOrComparisonValidator[ArrayT, ArrayIndicesT, ComparableValueT], ...
    ]
)
"""Validator (including `ComparisonValidator`) or a tuple thereof."""


ValidatorOrValidatorSequence = (
    ValidatorOrComparisonValidator[ArrayT, ArrayIndicesT, ComparableValueT]
    | Sequence[ValidatorOrComparisonValidator[ArrayT, ArrayIndicesT, ComparableValueT]]
)
"""Validator (including `ComparisonValidator`) or a sequence thereof."""
