"""
*import* `setup_array` **function**

*import* `ax_sizes_from_schema` **function**

*import* `constraints_to_validators` **function**
"""

from functools import lru_cache
from types import EllipsisType
from typing import Any, Optional

from valarray import settings

from .array_type_adapter import ArrayTypeAdapter, Comparisons
from .axes_and_fields import AxesTuple
from .errors_exceptions import CoerceDTypeException, CreateArrayException
from .types import ArrayIndicesT, ArrayT, AxSizes, ComparableValueT, DTypeLikeT
from .validators import ComparisonValidator


@lru_cache(settings.function_cache_size)
def ax_sizes_from_schema(schema: AxesTuple[Any, Any, Any]) -> AxSizes:
    """(introduced ***v0.1.1***)"""
    sizes: AxSizes = []

    for ax in schema:
        if isinstance(ax, int):
            sizes.append(ax)
        elif isinstance(ax, str):
            sizes.append(None)
        else:
            sizes.append(len(ax))

    return tuple(sizes)


@lru_cache(settings.function_cache_size)
def constraints_to_validators(
    lt: Optional[ComparableValueT],
    le: Optional[ComparableValueT],
    ge: Optional[ComparableValueT],
    gt: Optional[ComparableValueT],
    eq: Optional[ComparableValueT],
    comparisons: Comparisons[ArrayT, ArrayIndicesT, ComparableValueT],
) -> list[ComparisonValidator[ArrayT, ArrayIndicesT, ComparableValueT]]:
    """(introduced ***v0.3***)"""
    validators = []

    for val, operator in zip((lt, le, ge, gt, eq), ("lt", "le", "ge", "gt", "eq")):
        if val is not None:
            validators.append(ComparisonValidator(operator, val, comparisons))

    return validators


def setup_array(
    obj: Any,
    dtypelike: DTypeLikeT | EllipsisType,
    coerce_dtype: Optional[bool],
    schema: AxesTuple[Any, Any, Any] | EllipsisType,
    ata: ArrayTypeAdapter[ArrayT, DTypeLikeT, Any, Any, Any],
    cls_name: str,
) -> ArrayT:
    """Creates array if it already doesn't exist. Specifically if:
    - `obj` is an array AND
        - `coerce_dtype` is `False` OR `dtypelike == ...` -> return `obj`
        - `coerce_dtype` is `True` -> try to convert dtype,
            throw `CannotCoerceDTypeException` on fail.
    - `obj` is `None` -> create an empty array
    - `obj` is any other object -> try to create array, throw `CreateArrayException` on fail.

    (introduced ***v0.1***, last_modified ***v0.2.4***)
    """
    if isinstance(obj, ata.array_type):
        if coerce_dtype is False or dtypelike == ...:
            arr = obj
        else:
            try:
                arr = ata.change_dtype(obj, dtypelike)
            except Exception as exc:
                raise CoerceDTypeException(
                    cls_name,
                    ata.errors.cannot_coerce_dtype(
                        obj.dtype, ata.dtype_from_dtypelike(dtypelike), dtypelike
                    ),
                ) from exc
    elif obj is None:
        ax_sizes = ax_sizes_from_schema(schema if schema != ... else tuple())
        arr = ata.create_empty_array(ax_sizes, dtypelike)
    else:
        try:
            arr = ata.create_array(obj, dtypelike)
        except Exception as exc:
            raise CreateArrayException(cls_name) from exc

    return arr
