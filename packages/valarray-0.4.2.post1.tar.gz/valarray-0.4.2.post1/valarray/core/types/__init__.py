"""
## Generics
*import* `DTypeLikeT` **TypeVar**

*import* `DTypeT` **TypeVar**

*import* `ArrayT` **TypeVar**

*import* `ArrayIndicesT` **TypeVar**

*import* `ComparableValueT` **TypeVar**

## Other
*import* `ArrayP` **Protocol**

*import* `ComparisonOperator` **type**

*import* `AxSizes` **type**
"""

from .generics import ArrayIndicesT, ArrayT, ComparableValueT, DTypeLikeT, DTypeT
from .other import ArrayP, AxSizes, ComparisonOperator

# pyright: reportUnusedImport=false
