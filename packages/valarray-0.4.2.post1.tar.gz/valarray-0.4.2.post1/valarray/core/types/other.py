from collections.abc import Sequence
from typing import Any, Literal, Protocol


class ArrayP(Protocol):
    """(introduced ***v0.1***, last_modified ***v0.4.1***)"""

    @property
    def dtype(self) -> Any: ...

    @property
    def shape(self) -> tuple[int, ...]: ...

    def __len__(self) -> int: ...


type ComparisonOperator = Literal["lt", "le", "ge", "gt", "eq"]
"""(introduced ***v0.3***)"""


type AxSizes = Sequence[int | None]
"""Array sizes from schema or 'None' if unknown.

(introduced ***v0.1.1***, last_modified ***v0.4***)
"""
