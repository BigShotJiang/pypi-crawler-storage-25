from typing import TypeVar

from .other import ArrayP

# NOTE: using old-school generics because I'm not familiar with the new syntax
# and I don't know how to customize syntax highligting for it in VSCode.


DTypeLikeT = TypeVar("DTypeLikeT")
"""Data type object or object that can be used to construct a data type object.
```
dtypelike = "float32"
dtypelike = float
dtypelike = Float32()

dt = dtype(dtypelike)
dt == Float32()
>>> True
```

(introduced ***v0.1***)
"""

DTypeT = TypeVar("DTypeT")
"""(introduced ***v0.1***)"""


ArrayT = TypeVar("ArrayT", bound=ArrayP)
"""Generic array object conforming to `ArrayP` protocol.
(introduced ***v0.1***)"""

ArrayIndicesT = TypeVar("ArrayIndicesT")
"""Object that can select values from array using `__getitem__` method.
(introduced ***v0.3***)
"""

ComparableValueT = TypeVar("ComparableValueT")
"""Value or object an array can be compared with using `<`, `<=`, `==`, `=>`, `>` operators.
(introduced ***v0.3***)
"""
