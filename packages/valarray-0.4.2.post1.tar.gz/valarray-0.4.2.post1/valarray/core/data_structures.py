from dataclasses import dataclass
from typing import ClassVar, Optional, Self


@dataclass(unsafe_hash=True)
class _NameAndIdx:
    _specifier: ClassVar[str] = "Field/Axis"
    idx: int
    name: Optional[str] = None

    def __str__(self) -> str:
        name_str = f": '{self.name}'" if self.name is not None else ""
        return f"{self._specifier} < {self.idx} >{name_str}"


@dataclass(unsafe_hash=True)
class AxisNameAndIdx(_NameAndIdx):
    """Name and index of axis.

    Example:
    ```
    a_named = AxisNameAndIdx(name="example_axis", idx=3)
    a = AxisNameAndIdx(idx=3)

    print(a_named)
    >>> Axis < 3 >: 'example_axis'

    print(a)
    >>> Axis < 3 >
    ```

    (introduced ***v0.4***)
    """

    _specifier: ClassVar[str] = "Axis"


@dataclass(unsafe_hash=True)
class FieldNameAndIdx(_NameAndIdx):
    """Name and index of field.

    Example:
    ```
    f_named = FieldNameAndIdx(name="example_field", idx=3)
    f = FieldNameAndIdx(idx=3)

    print(f_named)
    >>> Field < 3 >: 'example_field'

    print(f)
    >>> Field < 3 >
    ```

    (introduced ***v0.4***)
    """

    _specifier: ClassVar[str] = "Field"


@dataclass(unsafe_hash=True)
class HeadingAndLines:
    """(introduced ***v0.4.1***)"""

    heading: str
    lines: tuple[str | Self, ...]
