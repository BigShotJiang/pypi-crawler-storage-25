from abc import ABC, abstractmethod
from typing import Any, Generic

from valarray.core.types import ArrayIndicesT, ArrayT, ComparableValueT


class Comparisons(ABC, Generic[ArrayT, ArrayIndicesT, ComparableValueT]):
    """Generic comparison functions.

    Type variables:
        - `ArrayT` - type of array object
        - `ArrayIndexT` - object(s) that can select values from array using `__getitem__` method.
        - `ComparableValueT` - value array can be compared with
        using `<`, `<=`, `==`, `=>`, `>` operators

    Subclasses need to implement:
        **abstract method**
        - `where_not_lt` -
            Returns indices of values which are not less than value.
        - `where_not_le` -
            Returns indices of values which are not less than or equal value.
        - `where_not_ge` -
            Returns indices of values which are not greater than or equal value.
        - `where_not_gt` -
            Returns indices of values which are not greater than value.
        - `where_not_eq` -
            Returns indices of values which are not equal value.
        - `n_indices` -
            Returns number of indices.


    (introduced ***v0.3***, last_modified ***v0.4***)
    """

    @abstractmethod
    def where_not_lt(self, arr: ArrayT, value: ComparableValueT) -> ArrayIndicesT:
        """(introduced ***v0.3***)"""

    @abstractmethod
    def where_not_le(self, arr: ArrayT, value: ComparableValueT) -> ArrayIndicesT:
        """(introduced ***v0.3***)"""

    @abstractmethod
    def where_not_ge(self, arr: ArrayT, value: ComparableValueT) -> ArrayIndicesT:
        """(introduced ***v0.3***)"""

    @abstractmethod
    def where_not_gt(self, arr: ArrayT, value: ComparableValueT) -> ArrayIndicesT:
        """(introduced ***v0.3***)"""

    @abstractmethod
    def where_not_eq(self, arr: ArrayT, value: ComparableValueT) -> ArrayIndicesT:
        """(introduced ***v0.3***)"""

    @abstractmethod
    def n_indices(self, indices: ArrayIndicesT) -> int:
        """(introduced ***v0.3***)"""

    def __hash__(self) -> int:
        # HACK: For ComparisonValidator to be hashable, *Comparisons must be hashable.
        # Because all instances of each type of *Comparisons class are the same
        # I just convert class name into integer and use it as a hash
        # using: https://stackoverflow.com/questions/61848516/convert-whole-ascii-string-into-a-int
        cls_name = self.__class__.__name__
        return int.from_bytes(cls_name.encode("utf-8"), byteorder="big", signed=False)

    def __eq__(self, other: Any) -> bool:
        try:
            return hash(self) == hash(other)
        except TypeError:
            return False

    def __repr__(self):
        return f"{self.__class__.__name__}()"
