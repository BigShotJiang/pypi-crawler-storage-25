from __future__ import annotations

from abc import ABC
from dataclasses import dataclass
from typing import TYPE_CHECKING, Generic

from valarray.core.types import (
    ArrayIndicesT,
    ArrayT,
    ComparableValueT,
    DTypeLikeT,
    DTypeT,
)

if TYPE_CHECKING:
    from valarray.core.errors_exceptions import (
        CannotCoerceDTypeError,
        IncorrectDTypeError,
        InvalidArrayValuesError,
        InvalidFieldValuesError,
    )


@dataclass
class GenericErrors(
    ABC, Generic[ArrayT, DTypeLikeT, DTypeT, ArrayIndicesT, ComparableValueT]
):
    """Generic `ValidationError` classes to be used in `ArrayTypeAdapter`.
    Subclass these for each array type with specific types and assign them to
    a 'GenericErrors' subclass.

    ## Example:
    ```
    class ChildIncorrectDTypeError(IncorrectDTypeError[DTypeLike, Dtype]): ...

    @dataclass
    class ChildErrors(GenericErrors[DTypeLike, Dtype]):
        incorrect_dtype: type[ChildIncorrectDTypeError] = ChildIncorrectDTypeError

    ```

    Necessary for correct type inference of errors accessed through a raised `ValidationException`.

    ### Good:
    ```
    try:
        ...
    except ValidationException as exc:
        for err in exc.errs:
            if isinstance(err, ChildIncorrectDTypeError):
                # dtypes => Dtype, DTypeLike
                print(err.actual_dtype, err.expected_dtypelike)
    ```

    ### Bad:
    ```
    try:
        ...
    except ValidationException as exc:
        for err in exc.errs:
            if isinstance(err, IncorrectDTypeError):
                # dtypes => Unknown
                print(err.actual_dtype, err.expected_dtypelike)
    ```

    (introduced ***v0.2.4***)
    """

    incorrect_dtype: type[IncorrectDTypeError[DTypeLikeT, DTypeT]]
    cannot_coerce_dtype: type[CannotCoerceDTypeError[DTypeLikeT, DTypeT]]
    invalid_array_values: type[
        InvalidArrayValuesError[ArrayT, ArrayIndicesT, ComparableValueT]
    ]
    invalid_field_values: type[
        InvalidFieldValuesError[ArrayT, ArrayIndicesT, ComparableValueT]
    ]
