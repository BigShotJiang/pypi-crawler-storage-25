from __future__ import annotations

from abc import ABC, abstractmethod
from collections.abc import Sequence
from types import EllipsisType
from typing import TYPE_CHECKING, Any, Generic, Optional

from valarray.core.types import (
    ArrayIndicesT,
    ArrayT,
    AxSizes,
    ComparableValueT,
    DTypeLikeT,
    DTypeT,
)

if TYPE_CHECKING:
    from valarray.core.data_structures import AxisNameAndIdx, FieldNameAndIdx

    from .comparisons import Comparisons
    from .errors import GenericErrors


class ArrayTypeAdapter(
    ABC, Generic[ArrayT, DTypeLikeT, DTypeT, ArrayIndicesT, ComparableValueT]
):
    """Generic base array type adapter.

    Type variables:
        - `ArrayT` - type of array object
        - `DTypeLikeT` - data type specification
        - `DTypeT` - data type object
        - `ArrayIndexT` - object(s) that can select values from array using `__getitem__` method.
        - `ComparableValueT` - value array can be compared with
        using `<`, `<=`, `==`, `=>`, `>` operators

    Subclasses need to implement:
        **abstract property**
        - `type_name` -
            Name of array type, for example `numpy`.
        - `errors` -
            Subtypes of generic `ValidationError` classes.
        - `array_type` -
            Array type (to be used in `isinstance(obj, adapter.array_type)` check)
        - `comparisons` -
            Subtype of generic `Comparisons` class.

        **abstract method**
        - `create_array` -
            Create an array object from data with specified dtype(like).
        - `create_empty_array` -
            Create an empty array object with specified dtype(like).
        - `is_array_empty` -
            Check if array is empty.
        - `change_dtype` -
            Change array data type.
        - `dtype_from_dtypelike` -
            Create dtype object from dtypelike.
        - `dtypes_equal` -
            Check if dtypes are equal
        - `get_values` -
            Get a list of values from array

    (`dtypes_equal` and `get_values` are neccessary because `__eq__` and `__getitem__`
    methods respectively can have different parameter names)

    (introduced ***v0.1***, last_modified ***v0.4.1***)
    """

    @property
    @abstractmethod
    def type_name(self) -> str: ...

    @property
    @abstractmethod
    def errors(
        self,
    ) -> GenericErrors[ArrayT, DTypeLikeT, DTypeT, ArrayIndicesT, ComparableValueT]: ...

    @property
    @abstractmethod
    def array_type(self) -> type[ArrayT]: ...

    @property
    @abstractmethod
    def comparisons(self) -> Comparisons[ArrayT, ArrayIndicesT, ComparableValueT]:
        """Methods used by `ComparisonValidator`"""

    @abstractmethod
    def change_dtype(self, arr: ArrayT, dtypelike: DTypeLikeT) -> ArrayT: ...

    @abstractmethod
    def create_array(
        self, obj: Any, dtypelike: DTypeLikeT | EllipsisType
    ) -> ArrayT: ...

    @abstractmethod
    def is_array_empty(self, arr: ArrayT) -> bool: ...

    @abstractmethod
    def create_empty_array(
        self, ax_sizes: AxSizes, dtypelike: DTypeLikeT | EllipsisType
    ) -> ArrayT: ...

    @abstractmethod
    def dtype_from_dtypelike(self, dtypelike: DTypeLikeT) -> DTypeT: ...

    @abstractmethod
    def dtypes_equal(self, actual_dtype: DTypeT, expected_dtype: DTypeT) -> bool: ...

    @abstractmethod
    def get_values(
        self, arr: ArrayT, indices: Optional[ArrayIndicesT]
    ) -> Optional[list[Any]]: ...

    @abstractmethod
    def select_subset(
        self, arr: ArrayT, ax: AxisNameAndIdx, fields: Sequence[FieldNameAndIdx]
    ) -> ArrayT: ...

    @abstractmethod
    def get_values_from_subset(
        self,
        arr: ArrayT,
        indices: Optional[ArrayIndicesT],
        ax: AxisNameAndIdx,
        fields: Sequence[FieldNameAndIdx],
    ) -> Optional[dict[FieldNameAndIdx, Any]]: ...
