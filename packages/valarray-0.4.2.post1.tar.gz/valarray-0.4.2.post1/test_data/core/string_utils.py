from valarray.core import Field
from valarray.core.data_structures import HeadingAndLines

CONSTRAINTS_STR_LT1 = "Constraints: < 1"
CONSTRAINTS_STR_LT1_GE_NEG_5 = "Constraints: < 1, >= -5"

VALIDATOR_HAL_DUMMY = HeadingAndLines("Validators:", ("Dummy: description",))

FIELD_HAL_NO_IDX_NO_NAME = HeadingAndLines("Field < ? >", tuple())
FIELD_HAL_NO_IDX_NAME = HeadingAndLines("Field < ? > : 'name'", tuple())
FIELD_HAL_IDX_NO_NAME = HeadingAndLines("Field < 0 >", tuple())
FIELD_HAL_IDX_NAME = HeadingAndLines("Field < 0 > : 'name'", tuple())

FIELD_HAL_IDX_NAME_CONSTRAINTS_VALIDATORS = HeadingAndLines(
    "Field < 0 > : 'name'",
    (
        "Constraints: < 1",
        VALIDATOR_HAL_DUMMY,
    ),
)

FIELD_STR = "Field < 0 > : 'first_field'"
FIELD_HAL = HeadingAndLines("Field < 1 > : 'second_field'", ("Constraints: >= 0",))


SCHEMA = (
    12,
    "second_axis",
    (
        "first_field",
        Field("second_field", ge=0),
    ),
)
SCHEMA_HAL = HeadingAndLines(
    "schema:",
    (
        "Axis < 0 >",
        "Axis < 1 > : 'second_axis'",
        HeadingAndLines(
            "Axis < 2 >",
            (
                FIELD_STR,
                FIELD_HAL,
            ),
        ),
    ),
)

ARRAY_NAME_AND_TYPE_STR = "TestValidatedArray (type: 'test')"
DTYPE_STR = "data type: 'one' (DType1)"


ARRAY = [1, 2, 3, 4]
ARRAY_HAL = HeadingAndLines("values:", ("[1, 2, 3, 4]",))
