def issue2_problem():
    import numpy as np
    import numpy.typing as npt

    def cut_patches(
        img: npt.NDArray[np.uint8], boxes: npt.NDArray[np.int64]
    ) -> list[npt.NDArray[np.uint8]]:
        patches = []
        for box in boxes:
            patch = img[box[0] : box[2], box[1] : box[3], :]
            patches.append(patch)

        return patches

    img_random = np.random.random((400, 400, 3)).astype(np.uint8) * 255

    boxes_xyxy = np.array([[0, 100, 200, 200], [150, 50, 200, 250]], dtype=int)

    boxes_xywh = np.array([[100, 150, 200, 100], [175, 50, 50, 250]], dtype=int)

    patches = cut_patches(img_random, boxes_xyxy)  # type checkers do not complain

    print("Valid")
    for patch in patches:
        print(patch.shape)

    patches_inv = cut_patches(img_random, boxes_xywh)  # type checkers do not complain

    print("Invalid")
    for patch in patches_inv:
        print(patch.shape)
