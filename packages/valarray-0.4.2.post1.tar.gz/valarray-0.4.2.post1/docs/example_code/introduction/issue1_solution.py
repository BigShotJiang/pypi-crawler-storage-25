def issue1_solution():
    import numpy as np
    import numpy.typing as npt

    from valarray.core.errors_exceptions import ValidationException
    from valarray.numpy import Field
    from valarray.numpy.array import ValidatedNumpyArray

    class BoxesXYXY(ValidatedNumpyArray[np.int64]):
        dtype = int
        schema = (
            "n",
            (
                Field(ge=0),
                Field(ge=0),
                Field(ge=0),
                Field(ge=0),
            ),
        )

    def cut_patches(
        img: npt.NDArray[np.uint8], boxes: npt.NDArray[np.int64]
    ) -> list[npt.NDArray[np.uint8]]:
        patches = []
        for box in boxes:
            patch = img[box[0] : box[2], box[1] : box[3], :]
            patches.append(patch)

        return patches

    try:
        img_random = np.random.random((400, 400, 3)).astype(np.uint8) * 255

        boxes_xyxy_invalid = BoxesXYXY.validate(
            np.array([[-10, 100, 200, 200], [150, 50, 200, 250]], dtype=int)
        )

        patches = cut_patches(img_random, boxes_xyxy_invalid.array)

        for patch in patches:
            print(patch.shape)
    except ValidationException as exc:
        for err in exc.errs:
            print(err.msg)
