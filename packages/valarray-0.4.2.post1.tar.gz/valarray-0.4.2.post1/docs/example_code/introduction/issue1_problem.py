def issue1_problem():
    import numpy as np
    import numpy.typing as npt

    def cut_patches(
        img: npt.NDArray[np.uint8], boxes: npt.NDArray[np.int64]
    ) -> list[npt.NDArray[np.uint8]]:
        patches = []
        for box in boxes:
            patch = img[box[0] : box[2], box[1] : box[3], :]
            patches.append(patch)

        return patches

    img_random = np.random.random((400, 400, 3)).astype(np.uint8) * 255

    boxes_xyxy_invalid = np.array(
        [[-10, 100, 200, 200], [150, 50, 200, 250]], dtype=int
    )

    patches = cut_patches(img_random, boxes_xyxy_invalid)

    for patch in patches:
        print(patch.shape)
