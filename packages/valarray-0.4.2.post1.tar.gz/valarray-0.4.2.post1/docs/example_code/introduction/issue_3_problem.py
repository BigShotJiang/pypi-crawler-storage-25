def issue3_problem():
    import numpy as np
    import numpy.typing as npt

    def cut_patches(
        img: npt.NDArray[np.uint8], boxes: npt.NDArray[np.int64]
    ) -> list[npt.NDArray[np.uint8]]:
        """Cuts patches from an image.

        Args:
            img (npt.NDArray[np.uint8]): Source image
            boxes (npt.NDArray[np.int64]): Boxes to cut patches with.
                Array of N boxes `xmin, ymin, xmax, ymax` in pixels.

        Returns:
            list[npt.NDArray[np.uint8]]: List of patches.
        """
        patches = []
        for box in boxes:
            patch = img[box[0] : box[2], box[1] : box[3], :]
            patches.append(patch)

        return patches

    del cut_patches
