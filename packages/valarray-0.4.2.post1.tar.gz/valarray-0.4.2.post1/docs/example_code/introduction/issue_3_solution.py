def issue3_problem():
    import numpy as np
    import numpy.typing as npt

    from valarray.numpy import Field
    from valarray.numpy.array import ValidatedNumpyArray

    class BoxesXYXY(ValidatedNumpyArray[np.int64]):
        """Array of N `xyxy` boxes in pixels."""

        dtype = int
        schema = (
            "n",
            (
                Field("xmin_px", ge=0),
                Field("ymin_px", ge=0),
                Field("xmax_px", ge=0),
                Field("ymax_px", ge=0),
            ),
        )

    def cut_patches(
        img: npt.NDArray[np.uint8], boxes: BoxesXYXY
    ) -> list[npt.NDArray[np.uint8]]:
        """Cuts patches from an image.

        Args:
            img (npt.NDArray[np.uint8]): Source image
            boxes (BoxesXYXY): Boxes to cut patches with.

        Returns:
            list[npt.NDArray[np.uint8]]: List of patches.
        """
        patches = []
        for box in boxes.array:
            patch = img[box[0] : box[2], box[1] : box[3], :]
            patches.append(patch)

        return patches

    del cut_patches
