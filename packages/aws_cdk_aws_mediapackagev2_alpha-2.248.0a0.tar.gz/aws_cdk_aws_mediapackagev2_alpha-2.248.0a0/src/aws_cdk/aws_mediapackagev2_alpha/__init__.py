r'''
# AWS::MediaPackageV2 Construct Library

<!--BEGIN STABILITY BANNER-->---


![cdk-constructs: Experimental](https://img.shields.io/badge/cdk--constructs-experimental-important.svg?style=for-the-badge)

> The APIs of higher level constructs in this module are experimental and under active development.
> They are subject to non-backward compatible changes or removal in any future version. These are
> not subject to the [Semantic Versioning](https://semver.org/) model and breaking changes will be
> announced in the release notes. This means that while you may use them, you may need to update
> your source code when upgrading to a newer version of this package.

---
<!--END STABILITY BANNER-->

## AWS Elemental MediaPackage V2

MediaPackage delivers high-quality video without concern for capacity and makes it easier to implement popular DVR features such as start over, pause, and rewind. Your content will be protected with comprehensive support for DRM. The service seamlessly integrates with other AWS media services as a complete set of tools for cloud-based video processing and delivery.

This package contains constructs for working with AWS Elemental MediaPackage V2. Allowing you to define AWS Elemental MediaPackage V2 Channel Groups, Channels, Origin Endpoints, Channel Policies and Origin Endpoint Policies.

For further information on AWS Elemental MediaPackage V2, see [the documentation](https://aws.amazon.com/mediapackage/).

The following example creates an AWS Elemental MediaPackage V2 Channel Group, Channel and Origin Endpoint:

```python
# stack: Stack

group = ChannelGroup(stack, "MyChannelGroup",
    channel_group_name="my-test-channel-group"
)

channel = Channel(stack, "MyChannel",
    channel_group=group,
    channel_name="my-testchannel",
    input=InputConfiguration.cmaf()
)

endpoint = OriginEndpoint(stack, "MyOriginEndpoint",
    channel=channel,
    origin_endpoint_name="my-test-endpoint",
    segment=Segment.cmaf(),
    manifests=[Manifest.hls(
        manifest_name="index"
    )]
)
```

## Using Factory Methods

```python
# stack: Stack


# Create a channel group
group = ChannelGroup(stack, "MyChannelGroup",
    channel_group_name="my-channel-group"
)

# Add a channel using the factory method
channel = group.add_channel("MyChannel",
    channel_name="my-channel",
    input=InputConfiguration.cmaf()
)

# Add an origin endpoint using the factory method
endpoint = channel.add_origin_endpoint("MyEndpoint",
    origin_endpoint_name="my-endpoint",
    segment=Segment.cmaf(),
    manifests=[Manifest.hls(manifest_name="index")]
)
```

## Channel Group

A channel group is the top-level resource that consists of channels and origin endpoints associated with it.

The following code creates a Channel Group:

```python
# stack: Stack

group = ChannelGroup(stack, "MyChannelGroup",
    channel_group_name="my-test-channel-group"
)
```

The following code imports an existing channel group using the name attribute:

```python
# stack: Stack

channel_group = ChannelGroup.from_channel_group_attributes(stack, "ImportedChannelGroup",
    channel_group_name="MyChannelGroup"
)
```

## Channel

A channel is part of a channel group and represents the entry point for a content stream into MediaPackage.

### Input Configuration

Channels support two input types: HLS and CMAF.

```python
from aws_cdk.aws_mediapackagev2_alpha import InputSwitchConfiguration
# stack: Stack
# group: ChannelGroup


hls_channel = Channel(stack, "HlsChannel",
    channel_group=group,
    input=InputConfiguration.hls()
)

cmaf_channel = Channel(stack, "CmafChannel",
    channel_group=group,
    input=InputConfiguration.cmaf(
        input_switch_configuration=InputSwitchConfiguration(
            mqcs_input_switching=True
        ),
        output_headers=[HeadersCMSD.MQCS]
    )
)

simple_cmaf_channel = Channel(stack, "SimpleCmafChannel",
    channel_group=group,
    input=InputConfiguration.cmaf(
        output_headers=[HeadersCMSD.MQCS]
    )
)
```

### Importing an Existing Channel

The following code imports an existing channel using the name attributes:

```python
# stack: Stack

channel = Channel.from_channel_attributes(stack, "ImportedChannel",
    channel_name="MyChannel",
    channel_group_name="MyChannelGroup"
)
```

### Channel Resource Policy

The following code creates a resource policy directly on the channel. This
will automatically create a policy on the first call:

```python
# channel: Channel

channel.add_to_resource_policy(PolicyStatement(
    sid="AllowMediaLiveRoleToAccessEmpChannel",
    principals=[ArnPrincipal("arn:aws:iam::AccountID:role/MediaLiveAccessRole")],
    effect=Effect.ALLOW,
    actions=["mediapackagev2:PutObject"],
    resources=[channel.channel_arn]
))
```

## Origin Endpoint

```python
# stack: Stack
# channel: Channel

OriginEndpoint(stack, "myendpoint",
    channel=channel,
    origin_endpoint_name="my-test-endpoint",
    segment=Segment.cmaf(),
    manifests=[
        Manifest.hls(
            manifest_name="index"
        )
    ]
)
```

The following code imports an existing origin endpoint using the name attributes:

```python
# stack: Stack

origin_endpoint = OriginEndpoint.from_origin_endpoint_attributes(stack, "ImportedOriginEndpoint",
    channel_group_name="MyChannelGroup",
    channel_name="MyChannel",
    origin_endpoint_name="MyExampleOriginEndpoint"
)
```

The following code creates a resource policy on the origin endpoint. This
will automatically create a policy on the first call:

```python
# origin: OriginEndpoint


origin.add_to_resource_policy(PolicyStatement(
    sid="AllowRequestsFromCloudFront",
    principals=[ServicePrincipal("cloudfront.amazonaws.com")],
    effect=Effect.ALLOW,
    actions=["mediapackagev2:GetHeadObject", "mediapackagev2:GetObject"],
    resources=[origin.origin_endpoint_arn],
    conditions={
        "StringEquals": {
            "aws:SourceArn": "arn:aws:cloudfront::123456789012:distribution/AAAAAAAAA"
        }
    }
))
```

## Granting Permissions

### Granting Ingest Access to MediaLive

To allow AWS Elemental MediaLive to ingest content into a MediaPackage channel, use the `grants.ingest()` method:

```python
# channel: Channel
# media_live_role: iam.IRole


# Grant MediaLive permission to ingest content
channel.grants.ingest(media_live_role)
```

### CloudFront Integration

MediaPackage origin endpoints are designed to be used with Content Delivery Network (CDN) like Amazon CloudFront distributions. CloudFront provides caching, DDoS protection, and global content delivery for your streaming content.

To allow a CloudFront distribution to access a MediaPackage origin endpoint, add a resource policy with the CloudFront service principal:

```python
# origin_endpoint: OriginEndpoint
# distribution: cloudfront.Distribution


origin_endpoint.add_to_resource_policy(iam.PolicyStatement(
    sid="AllowCloudFrontServicePrincipal",
    principals=[iam.ServicePrincipal("cloudfront.amazonaws.com")],
    effect=iam.Effect.ALLOW,
    actions=["mediapackagev2:GetObject", "mediapackagev2:GetHeadObject"],
    resources=[origin_endpoint.origin_endpoint_arn],
    conditions={
        "StringEquals": {
            "aws:SourceArn": distribution.distribution_arn
        }
    }
))
```

You can complete the confirmation with an OAC (Origin Access Control) Policy on the CloudFront Distribution.

## Manifest Configuration

MediaPackage V2 supports multiple manifest formats: HLS, Low-Latency HLS (LL-HLS), DASH, and Microsoft Smooth Streaming (MSS).

### HLS Manifests

```python
# channel: Channel


OriginEndpoint(self, "Endpoint",
    channel=channel,
    segment=Segment.cmaf(),
    manifests=[
        Manifest.hls(
            manifest_name="index",
            manifest_window=Duration.seconds(60),
            program_date_time_interval=Duration.seconds(60),
            scte_ad_marker_hls=AdMarkerHls.DATERANGE
        )
    ]
)
```

### Low-Latency HLS Manifests

```python
# channel: Channel


OriginEndpoint(self, "Endpoint",
    channel=channel,
    segment=Segment.cmaf(),
    manifests=[
        Manifest.low_latency_hLS(
            manifest_name="index",
            manifest_window=Duration.seconds(30),
            program_date_time_interval=Duration.seconds(5),
            child_manifest_name="child"
        )
    ]
)
```

### DASH Manifests

```python
# channel: Channel


OriginEndpoint(self, "Endpoint",
    channel=channel,
    segment=Segment.cmaf(),
    manifests=[
        Manifest.dash(
            manifest_name="index",
            manifest_window=Duration.seconds(60),
            min_buffer_time=Duration.seconds(30),
            min_update_period=Duration.seconds(10),
            segment_template_format=SegmentTemplateFormat.NUMBER_WITH_TIMELINE,
            period_triggers=[DashPeriodTriggers.AVAILS, DashPeriodTriggers.DRM_KEY_ROTATION
            ]
        )
    ]
)
```

### MSS Manifests

```python
# channel: Channel


OriginEndpoint(self, "Endpoint",
    channel=channel,
    segment=Segment.ism(),
    manifests=[
        Manifest.mss(
            manifest_name="index",
            manifest_window=Duration.seconds(60),
            manifest_layout=MssManifestLayout.COMPACT
        )
    ]
)
```

### Multiple Manifests

You can configure multiple manifest formats for a single origin endpoint:

```python
# channel: Channel


OriginEndpoint(self, "Endpoint",
    channel=channel,
    segment=Segment.cmaf(),
    manifests=[
        Manifest.hls(manifest_name="hls"),
        Manifest.dash(manifest_name="dash")
    ]
)
```

| Segment type | Supported manifests |
|--------|--------|
| Segment.cmaf() | HLS, LL-HLS, DASH |
| Segment.ts() | HLS, LL-HLS |
| Segment.ism() | MSS |

Each origin endpoint has a single segment configuration. If you need segments with different configurations, use multiple origin endpoints on the same channel.

@see https://docs.aws.amazon.com/mediapackage/latest/userguide/endpoints-create.html

## Manifest Filtering

Manifest filters control which variants are included in the manifest. Filters are type-safe and validated against the [MediaPackage manifest filtering rules](https://docs.aws.amazon.com/mediapackage/latest/userguide/manifest-filter-query-parameters.html).

| Filter | Method |
|--------|--------|
| Audio / video bitrate | `bitrate()`, `bitrateRange()`, `bitrateCombo()` |
| Audio channels, sample rate, video height, framerate, trickplay height | `numeric()`, `numericList()`, `numericRange()`, `numericCombo()` |
| Audio codec | `audioCodec()`, `audioCodecList()` |
| Video codec | `videoCodec()`, `videoCodecList()` |
| Video dynamic range | `videoDynamicRange()`, `videoDynamicRangeList()` |
| Trickplay type | `trickplayType()`, `trickplayTypeList()` |
| Audio / subtitle language | `text()`, `textList()` |
| Advanced patterns | `custom()` |

The following example creates an HD streaming endpoint that serves only H.264/H.265 content between 1–5 Mbps with stereo audio in English or French:

```python
from aws_cdk.aws_mediapackagev2_alpha import FilterConfiguration
# channel: Channel


OriginEndpoint(self, "Endpoint",
    channel=channel,
    segment=Segment.cmaf(),
    manifests=[
        Manifest.hls(
            manifest_name="index",
            filter_configuration=FilterConfiguration(
                manifest_filter=[
                    ManifestFilter.bitrate_range(BitrateFilterKey.VIDEO_BITRATE, Bitrate.mbps(1), Bitrate.mbps(5)),
                    ManifestFilter.numeric_range(NumericFilterKey.VIDEO_HEIGHT, 720, 1080),
                    ManifestFilter.video_codec_list([VideoCodec.H264, VideoCodec.H265]),
                    ManifestFilter.numeric(NumericFilterKey.AUDIO_CHANNELS, 2),
                    ManifestFilter.text_list(TextFilterKey.AUDIO_LANGUAGE, ["en-US", "fr"])
                ],
                time_delay=Duration.seconds(30)
            )
        )
    ]
)
```

For advanced patterns that combine ranges and single values, use `numericCombo()` or `bitrateCombo()`:

```python
from aws_cdk.aws_mediapackagev2_alpha import FilterConfiguration
# channel: Channel


OriginEndpoint(self, "Endpoint",
    channel=channel,
    segment=Segment.cmaf(),
    manifests=[
        Manifest.hls(
            manifest_name="index",
            filter_configuration=FilterConfiguration(
                manifest_filter=[
                    # video_height:240-360,720-1080,1440
                    ManifestFilter.numeric_combo(NumericFilterKey.VIDEO_HEIGHT, [
                        NumericExpression.range(240, 360),
                        NumericExpression.range(720, 1080),
                        NumericExpression.value(1440)
                    ])
                ]
            )
        )
    ]
)
```

### DRM Settings

You can exclude session keys from HLS and LL-HLS multivariant playlists using the `drmSettings` filter configuration. This improves compatibility with legacy HLS clients and provides more granular access control:

```python
from aws_cdk.aws_mediapackagev2_alpha import FilterConfiguration
# channel: Channel


OriginEndpoint(self, "Endpoint",
    channel=channel,
    segment=Segment.cmaf(),
    manifests=[
        Manifest.hls(
            manifest_name="index",
            filter_configuration=FilterConfiguration(
                drm_settings=[DrmSettingsKey.EXCLUDE_SESSION_KEYS]
            )
        )
    ]
)
```

## Start Tag Configuration

Configure where playback should start in HLS and LL-HLS manifests using the EXT-X-START tag:

```python
# channel: Channel


OriginEndpoint(self, "Endpoint",
    channel=channel,
    segment=Segment.cmaf(),
    manifests=[
        Manifest.hls(
            manifest_name="index",
            start_tag=StartTag.of(10)
        )
    ]
)
```

## Segment Configuration

Configure segment settings for your origin endpoint.

```python
# channel: Channel


OriginEndpoint(self, "TsEndpoint",
    channel=channel,
    segment=Segment.ts(
        duration=Duration.seconds(6),
        name="segment",
        include_dvb_subtitles=True,
        use_audio_rendition_group=True,
        include_iframe_only_streams=False,
        scte_filter=[ScteMessageType.BREAK, ScteMessageType.DISTRIBUTOR_ADVERTISEMENT
        ]
    ),
    manifests=[Manifest.hls(manifest_name="index")]
)

OriginEndpoint(self, "CmafEndpoint",
    channel=channel,
    segment=Segment.cmaf(
        duration=Duration.seconds(6),
        name="segment",
        include_iframe_only_streams=True,
        scte_filter=[ScteMessageType.DISTRIBUTOR_ADVERTISEMENT]
    ),
    manifests=[Manifest.hls(manifest_name="index")]
)

OriginEndpoint(self, "Endpoint",
    channel=channel,
    segment=Segment.cmaf(),
    manifests=[Manifest.hls(manifest_name="index")]
)
```

## Encryption and DRM

Protect your content with encryption using SPEKE (Secure Packager and Encoder Key Exchange). Each container type has its own encryption class with type-safe options:

### CMAF Encryption

```python
# channel: Channel
# speke_role: iam.IRole


OriginEndpoint(self, "Endpoint",
    channel=channel,
    segment=Segment.cmaf(
        encryption=CmafEncryption.speke(
            method=CmafEncryptionMethod.CBCS,
            drm_systems=[CmafDrmSystem.FAIRPLAY, CmafDrmSystem.WIDEVINE],
            resource_id="my-content-id",
            url="https://example.com/speke",
            role=speke_role,
            key_rotation_interval=Duration.seconds(300),
            audio_preset=PresetSpeke20Audio.PRESET_AUDIO_2,
            video_preset=PresetSpeke20Video.PRESET_VIDEO_2
        )
    ),
    manifests=[Manifest.hls(manifest_name="index")]
)
```

### TS Encryption

```python
# channel: Channel
# speke_role: iam.IRole


OriginEndpoint(self, "TsEndpoint",
    channel=channel,
    segment=Segment.ts(
        encryption=TsEncryption.speke(
            method=TsEncryptionMethod.SAMPLE_AES,
            resource_id="my-content-id",
            url="https://example.com/speke",
            role=speke_role
        )
    ),
    manifests=[Manifest.hls(manifest_name="index")]
)
```

TS encryption defaults the DRM system based on the method: FairPlay for `SAMPLE_AES`, Clear Key AES 128 for `AES_128`. You can override this with the `drmSystems` property using `TsDrmSystem`.

### Content Key Encryption

You can add content key encryption by providing a certificate imported into AWS Certificate Manager. Your DRM key provider must support content key encryption for this to work:

```python
# channel: Channel
# speke_role: iam.IRole
# certificate: certificatemanager.ICertificate


OriginEndpoint(self, "Endpoint",
    channel=channel,
    segment=Segment.cmaf(
        encryption=CmafEncryption.speke(
            method=CmafEncryptionMethod.CBCS,
            drm_systems=[CmafDrmSystem.FAIRPLAY],
            resource_id="my-content-id",
            url="https://example.com/speke",
            role=speke_role,
            certificate=certificate
        )
    ),
    manifests=[Manifest.hls(manifest_name="index")]
)
```

### Excluding Segment DRM Metadata

For CMAF content, you can exclude DRM metadata from segments:

```python
# channel: Channel
# speke_role: iam.IRole


OriginEndpoint(self, "Endpoint",
    channel=channel,
    segment=Segment.cmaf(
        encryption=CmafEncryption.speke(
            method=CmafEncryptionMethod.CBCS,
            drm_systems=[CmafDrmSystem.FAIRPLAY],
            resource_id="my-content-id",
            url="https://example.com/speke",
            role=speke_role,
            exclude_segment_drm_metadata=True
        )
    ),
    manifests=[Manifest.hls(manifest_name="index")]
)
```

### ISM (Smooth Streaming) Encryption

ISM endpoints use CENC encryption with PlayReady. Audio and video presets are always `SHARED`, and key rotation is not supported. The DRM system defaults to PlayReady:

```python
# channel: Channel
# speke_role: iam.IRole


OriginEndpoint(self, "IsmEndpoint",
    channel=channel,
    segment=Segment.ism(
        encryption=IsmEncryption.speke(
            resource_id="my-content-id",
            url="https://example.com/speke",
            role=speke_role
        )
    ),
    manifests=[Manifest.mss(manifest_name="index")]
)
```

## CloudWatch Metrics

MediaPackage V2 resources expose CloudWatch metrics for monitoring. You can create alarms and dashboards using these metrics:

```python
# channel_group: ChannelGroup
# channel: Channel
# endpoint: OriginEndpoint


# Create a CloudWatch alarm on channel group egress bytes
alarm = channel_group.metric_egress_bytes().create_alarm(self, "HighEgress",
    threshold=1000,
    evaluation_periods=1
)

# Monitor channel ingress response time
channel.metric_ingress_response_time().create_alarm(self, "SlowIngress",
    threshold=1000,
    evaluation_periods=2
)

# Track origin endpoint request count
request_metric = endpoint.metric_egress_request_count(
    statistic="sum",
    period=Duration.minutes(5)
)
```

Available metrics include:

* `metricIngressBytes()` - Bytes ingested
* `metricEgressBytes()` - Bytes delivered
* `metricIngressResponseTime()` - Ingress response time (average)
* `metricEgressResponseTime()` - Egress response time (average)
* `metricIngressRequestCount()` - Number of ingress requests
* `metricEgressRequestCount()` - Number of egress requests

All metrics support standard CloudWatch metric options for customizing period, statistic, and dimensions.
'''
from pkgutil import extend_path
__path__ = extend_path(__path__, __name__)

import abc
import builtins
import datetime
import enum
import typing

import jsii
import publication
import typing_extensions

import typeguard
from importlib.metadata import version as _metadata_package_version
TYPEGUARD_MAJOR_VERSION = int(_metadata_package_version('typeguard').split('.')[0])

def check_type(argname: str, value: object, expected_type: typing.Any) -> typing.Any:
    if TYPEGUARD_MAJOR_VERSION <= 2:
        return typeguard.check_type(argname=argname, value=value, expected_type=expected_type) # type:ignore
    else:
        if isinstance(value, jsii._reference_map.InterfaceDynamicProxy): # pyright: ignore [reportAttributeAccessIssue]
           pass
        else:
            if TYPEGUARD_MAJOR_VERSION == 3:
                typeguard.config.collection_check_strategy = typeguard.CollectionCheckStrategy.ALL_ITEMS # type:ignore
                typeguard.check_type(value=value, expected_type=expected_type) # type:ignore
            else:
                typeguard.check_type(value=value, expected_type=expected_type, collection_check_strategy=typeguard.CollectionCheckStrategy.ALL_ITEMS) # type:ignore

from ._jsii import *

import aws_cdk as _aws_cdk_ceddda9d
import aws_cdk.aws_certificatemanager as _aws_cdk_aws_certificatemanager_ceddda9d
import aws_cdk.aws_cloudwatch as _aws_cdk_aws_cloudwatch_ceddda9d
import aws_cdk.aws_iam as _aws_cdk_aws_iam_ceddda9d
import aws_cdk.aws_mediapackagev2 as _aws_cdk_aws_mediapackagev2_ceddda9d
import aws_cdk.aws_secretsmanager as _aws_cdk_aws_secretsmanager_ceddda9d
import aws_cdk.interfaces.aws_mediapackagev2 as _aws_cdk_interfaces_aws_mediapackagev2_ceddda9d
import constructs as _constructs_77d1e7e8


@jsii.enum(jsii_type="@aws-cdk/aws-mediapackagev2-alpha.AdMarkerDash")
class AdMarkerDash(enum.Enum):
    '''(experimental) Choose how ad markers are included in the packaged content.

    :stability: experimental
    '''

    BINARY = "BINARY"
    '''(experimental) Option for BINARY - The SCTE-35 marker is expressed as a hex-string (Base64 string) rather than full XML.

    :stability: experimental
    '''
    XML = "XML"
    '''(experimental) Option for XML - The SCTE marker is expressed fully in XML.

    :stability: experimental
    '''


@jsii.enum(jsii_type="@aws-cdk/aws-mediapackagev2-alpha.AdMarkerHls")
class AdMarkerHls(enum.Enum):
    '''(experimental) Choose how SCTE-35 ad markers are included in HLS and LL-HLS manifests.

    :stability: experimental
    :exampleMetadata: infused

    Example::

        # channel: Channel
        
        
        OriginEndpoint(self, "Endpoint",
            channel=channel,
            segment=Segment.cmaf(),
            manifests=[
                Manifest.hls(
                    manifest_name="index",
                    manifest_window=Duration.seconds(60),
                    program_date_time_interval=Duration.seconds(60),
                    scte_ad_marker_hls=AdMarkerHls.DATERANGE
                )
            ]
        )
    '''

    DATERANGE = "DATERANGE"
    '''(experimental) Insert EXT-X-DATERANGE tags to signal ad content.

    :stability: experimental
    '''
    SCTE35_ENHANCED = "SCTE35_ENHANCED"
    '''(experimental) Insert enhanced SCTE-35 tags for ad content.

    :stability: experimental
    '''


@jsii.enum(jsii_type="@aws-cdk/aws-mediapackagev2-alpha.AudioCodec")
class AudioCodec(enum.Enum):
    '''(experimental) Accepted audio codec values for manifest filtering.

    :see: https://docs.aws.amazon.com/mediapackage/latest/userguide/manifest-filter-query-parameters.html
    :stability: experimental
    '''

    AACL = "AACL"
    '''(experimental) AAC-LC audio codec.

    :stability: experimental
    '''
    AACH = "AACH"
    '''(experimental) HE-AAC audio codec.

    :stability: experimental
    '''
    AC_3 = "AC_3"
    '''(experimental) Dolby Digital audio codec (include the hyphen).

    :stability: experimental
    '''
    EC_3 = "EC_3"
    '''(experimental) Dolby Digital Plus audio codec (include the hyphen).

    :stability: experimental
    '''


class BitrateExpression(
    metaclass=jsii.JSIIMeta,
    jsii_type="@aws-cdk/aws-mediapackagev2-alpha.BitrateExpression",
):
    '''(experimental) Represents a bitrate filter expression segment — either a single value or a range.

    Use with ``ManifestFilter.bitrateCombo()`` to build filters that combine
    ranges and individual bitrate values.

    :stability: experimental
    :exampleMetadata: fixture=_generated

    Example::

        # The code below shows an example of how to instantiate this type.
        # The values are placeholders you should change.
        import aws_cdk.aws_mediapackagev2_alpha as mediapackagev2_alpha
        import aws_cdk as cdk
        
        # bitrate: cdk.Bitrate
        
        bitrate_expression = mediapackagev2_alpha.BitrateExpression.range(bitrate, bitrate)
    '''

    def __init__(
        self,
        _expression: builtins.str,
        _values: typing.Sequence[jsii.Number],
    ) -> None:
        '''
        :param _expression: 
        :param _values: 

        :stability: experimental
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__cef0b173a39ebd214b9387ff35a69c9b290daf234b204ecb673e0dea4e33566b)
            check_type(argname="argument _expression", value=_expression, expected_type=type_hints["_expression"])
            check_type(argname="argument _values", value=_values, expected_type=type_hints["_values"])
        jsii.create(self.__class__, self, [_expression, _values])

    @jsii.member(jsii_name="range")
    @builtins.classmethod
    def range(
        cls,
        start: "_aws_cdk_ceddda9d.Bitrate",
        end: "_aws_cdk_ceddda9d.Bitrate",
    ) -> "BitrateExpression":
        '''(experimental) An inclusive bitrate range.

        :param start: -
        :param end: -

        :stability: experimental
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__370333bb7a2bd0ae7f2d85516be277afe72880357ca0d8529eb724672961c006)
            check_type(argname="argument start", value=start, expected_type=type_hints["start"])
            check_type(argname="argument end", value=end, expected_type=type_hints["end"])
        return typing.cast("BitrateExpression", jsii.sinvoke(cls, "range", [start, end]))

    @jsii.member(jsii_name="value")
    @builtins.classmethod
    def value(cls, v: "_aws_cdk_ceddda9d.Bitrate") -> "BitrateExpression":
        '''(experimental) A single bitrate value.

        :param v: -

        :stability: experimental
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__5b2323b47b60307668354092741947bbedf35f9eb07182e37555571e9a45f37e)
            check_type(argname="argument v", value=v, expected_type=type_hints["v"])
        return typing.cast("BitrateExpression", jsii.sinvoke(cls, "value", [v]))


@jsii.enum(jsii_type="@aws-cdk/aws-mediapackagev2-alpha.BitrateFilterKey")
class BitrateFilterKey(enum.Enum):
    '''(experimental) Bitrate manifest filter keys.

    Use with ``ManifestFilter.bitrate()`` and ``ManifestFilter.bitrateRange()``.

    :see: https://docs.aws.amazon.com/mediapackage/latest/userguide/manifest-filter-query-parameters.html
    :stability: experimental
    :exampleMetadata: infused

    Example::

        from aws_cdk.aws_mediapackagev2_alpha import FilterConfiguration
        # channel: Channel
        
        
        OriginEndpoint(self, "Endpoint",
            channel=channel,
            segment=Segment.cmaf(),
            manifests=[
                Manifest.hls(
                    manifest_name="index",
                    filter_configuration=FilterConfiguration(
                        manifest_filter=[
                            ManifestFilter.bitrate_range(BitrateFilterKey.VIDEO_BITRATE, Bitrate.mbps(1), Bitrate.mbps(5)),
                            ManifestFilter.numeric_range(NumericFilterKey.VIDEO_HEIGHT, 720, 1080),
                            ManifestFilter.video_codec_list([VideoCodec.H264, VideoCodec.H265]),
                            ManifestFilter.numeric(NumericFilterKey.AUDIO_CHANNELS, 2),
                            ManifestFilter.text_list(TextFilterKey.AUDIO_LANGUAGE, ["en-US", "fr"])
                        ],
                        time_delay=Duration.seconds(30)
                    )
                )
            ]
        )
    '''

    AUDIO_BITRATE = "AUDIO_BITRATE"
    '''(experimental) The audio bitrate in bits per second.

    Accepted values: range 0–2147483647, or individual integers.

    :stability: experimental
    '''
    VIDEO_BITRATE = "VIDEO_BITRATE"
    '''(experimental) The video bitrate in bits per second.

    We recommend using only this filter parameter to set the video bitrate.
    Do not also set the minimum and maximum video bitrate via the MediaPackage
    console or AWS CLI, as your output might be skewed.

    This parameter cannot be used with trick-play streams.

    Accepted values: range 0–2147483647, or individual integers.

    :stability: experimental
    '''


@jsii.data_type(
    jsii_type="@aws-cdk/aws-mediapackagev2-alpha.CdnAuthConfiguration",
    jsii_struct_bases=[],
    name_mapping={"secrets": "secrets", "role": "role"},
)
class CdnAuthConfiguration:
    def __init__(
        self,
        *,
        secrets: typing.Sequence["_aws_cdk_aws_secretsmanager_ceddda9d.ISecret"],
        role: typing.Optional["_aws_cdk_aws_iam_ceddda9d.IRole"] = None,
    ) -> None:
        '''(experimental) Options for configuring CDN Authorization Configuration.

        :param secrets: (experimental) Secrets to use for CDN authorization.
        :param role: (experimental) Role to use for reading the secrets. If not provided, a role will be created automatically with the required permissions (secretsmanager:GetSecretValue, secretsmanager:DescribeSecret, secretsmanager:BatchGetSecretValue, and kms:Decrypt if the secret uses a customer-managed KMS key). Default: - a new role is created

        :see: https://docs.aws.amazon.com/mediapackage/latest/userguide/cdn-auth.html
        :stability: experimental
        :exampleMetadata: fixture=_generated

        Example::

            # The code below shows an example of how to instantiate this type.
            # The values are placeholders you should change.
            import aws_cdk.aws_mediapackagev2_alpha as mediapackagev2_alpha
            from aws_cdk import aws_iam as iam
            from aws_cdk import aws_secretsmanager as secretsmanager
            
            # role: iam.Role
            # secret: secretsmanager.Secret
            
            cdn_auth_configuration = mediapackagev2_alpha.CdnAuthConfiguration(
                secrets=[secret],
            
                # the properties below are optional
                role=role
            )
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__7a973b8df45c6d0c16e41ce2441038d66992f05c57f9613d6c2b7ac43e3b5589)
            check_type(argname="argument secrets", value=secrets, expected_type=type_hints["secrets"])
            check_type(argname="argument role", value=role, expected_type=type_hints["role"])
        self._values: typing.Dict[builtins.str, typing.Any] = {
            "secrets": secrets,
        }
        if role is not None:
            self._values["role"] = role

    @builtins.property
    def secrets(self) -> typing.List["_aws_cdk_aws_secretsmanager_ceddda9d.ISecret"]:
        '''(experimental) Secrets to use for CDN authorization.

        :stability: experimental
        '''
        result = self._values.get("secrets")
        assert result is not None, "Required property 'secrets' is missing"
        return typing.cast(typing.List["_aws_cdk_aws_secretsmanager_ceddda9d.ISecret"], result)

    @builtins.property
    def role(self) -> typing.Optional["_aws_cdk_aws_iam_ceddda9d.IRole"]:
        '''(experimental) Role to use for reading the secrets.

        If not provided, a role will be created automatically with the required permissions
        (secretsmanager:GetSecretValue, secretsmanager:DescribeSecret, secretsmanager:BatchGetSecretValue,
        and kms:Decrypt if the secret uses a customer-managed KMS key).

        :default: - a new role is created

        :stability: experimental
        '''
        result = self._values.get("role")
        return typing.cast(typing.Optional["_aws_cdk_aws_iam_ceddda9d.IRole"], result)

    def __eq__(self, rhs: typing.Any) -> builtins.bool:
        return isinstance(rhs, self.__class__) and rhs._values == self._values

    def __ne__(self, rhs: typing.Any) -> builtins.bool:
        return not (rhs == self)

    def __repr__(self) -> str:
        return "CdnAuthConfiguration(%s)" % ", ".join(
            k + "=" + repr(v) for k, v in self._values.items()
        )


@jsii.data_type(
    jsii_type="@aws-cdk/aws-mediapackagev2-alpha.ChannelAttributes",
    jsii_struct_bases=[],
    name_mapping={
        "channel_group_name": "channelGroupName",
        "channel_name": "channelName",
    },
)
class ChannelAttributes:
    def __init__(
        self,
        *,
        channel_group_name: builtins.str,
        channel_name: builtins.str,
    ) -> None:
        '''(experimental) Represents a Channel defined outside of this stack.

        :param channel_group_name: (experimental) The name that describes the channel group.
        :param channel_name: (experimental) The name that describes the channel.

        :stability: experimental
        :exampleMetadata: infused

        Example::

            # stack: Stack
            
            channel = Channel.from_channel_attributes(stack, "ImportedChannel",
                channel_name="MyChannel",
                channel_group_name="MyChannelGroup"
            )
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__3dbf726152c5231e0c115b080a55ba81739fccba33c8ae926556c21cd7c547e9)
            check_type(argname="argument channel_group_name", value=channel_group_name, expected_type=type_hints["channel_group_name"])
            check_type(argname="argument channel_name", value=channel_name, expected_type=type_hints["channel_name"])
        self._values: typing.Dict[builtins.str, typing.Any] = {
            "channel_group_name": channel_group_name,
            "channel_name": channel_name,
        }

    @builtins.property
    def channel_group_name(self) -> builtins.str:
        '''(experimental) The name that describes the channel group.

        :stability: experimental
        :attribute: true
        '''
        result = self._values.get("channel_group_name")
        assert result is not None, "Required property 'channel_group_name' is missing"
        return typing.cast(builtins.str, result)

    @builtins.property
    def channel_name(self) -> builtins.str:
        '''(experimental) The name that describes the channel.

        :stability: experimental
        :attribute: true
        '''
        result = self._values.get("channel_name")
        assert result is not None, "Required property 'channel_name' is missing"
        return typing.cast(builtins.str, result)

    def __eq__(self, rhs: typing.Any) -> builtins.bool:
        return isinstance(rhs, self.__class__) and rhs._values == self._values

    def __ne__(self, rhs: typing.Any) -> builtins.bool:
        return not (rhs == self)

    def __repr__(self) -> str:
        return "ChannelAttributes(%s)" % ", ".join(
            k + "=" + repr(v) for k, v in self._values.items()
        )


class ChannelGrants(
    metaclass=jsii.JSIIMeta,
    jsii_type="@aws-cdk/aws-mediapackagev2-alpha.ChannelGrants",
):
    '''(experimental) Collection of grant methods for a IChannelRef.

    :stability: experimental
    :exampleMetadata: fixture=_generated

    Example::

        # The code below shows an example of how to instantiate this type.
        # The values are placeholders you should change.
        import aws_cdk.aws_mediapackagev2_alpha as mediapackagev2_alpha
        from aws_cdk.interfaces import aws_mediapackagev2 as interfaces_mediapackagev2
        
        # channel_ref: interfaces_mediapackagev2.IChannelRef
        
        channel_grants = mediapackagev2_alpha.ChannelGrants.from_channel(channel_ref)
    '''

    @jsii.member(jsii_name="fromChannel")
    @builtins.classmethod
    def from_channel(
        cls,
        resource: "_aws_cdk_interfaces_aws_mediapackagev2_ceddda9d.IChannelRef",
    ) -> "ChannelGrants":
        '''(experimental) Creates grants for ChannelGrants.

        :param resource: -

        :stability: experimental
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__e3f462b7a5994b24147e5f7dbc9ac847dca8bd17cd5e008a02ccd0676c7c8da2)
            check_type(argname="argument resource", value=resource, expected_type=type_hints["resource"])
        return typing.cast("ChannelGrants", jsii.sinvoke(cls, "fromChannel", [resource]))

    @jsii.member(jsii_name="actions")
    def actions(
        self,
        grantee: "_aws_cdk_aws_iam_ceddda9d.IGrantable",
        actions: typing.Sequence[builtins.str],
        *,
        resource_arns: typing.Optional[typing.Sequence[builtins.str]] = None,
    ) -> "_aws_cdk_aws_iam_ceddda9d.Grant":
        '''(experimental) Grant the given identity custom permissions.

        :param grantee: -
        :param actions: -
        :param resource_arns: The ARNs of the resources to grant permissions on. Default: - The ARN of the resource associated with the grant is used.

        :stability: experimental
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__7d3f4e9c211af7198d28c57f43a4d2c905ca4c6498cd44f1c9ba95b59a046099)
            check_type(argname="argument grantee", value=grantee, expected_type=type_hints["grantee"])
            check_type(argname="argument actions", value=actions, expected_type=type_hints["actions"])
        options = _aws_cdk_ceddda9d.PermissionsOptions(resource_arns=resource_arns)

        return typing.cast("_aws_cdk_aws_iam_ceddda9d.Grant", jsii.invoke(self, "actions", [grantee, actions, options]))

    @jsii.member(jsii_name="ingest")
    def ingest(
        self,
        grantee: "_aws_cdk_aws_iam_ceddda9d.IGrantable",
    ) -> "_aws_cdk_aws_iam_ceddda9d.Grant":
        '''(experimental) Grant permissions to ingest content into this channel.

        :param grantee: -

        :stability: experimental
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__1d84b5c81a3dbac6c488a15e8bbb4a6b4e67363b40923afc31a6ad1438149d83)
            check_type(argname="argument grantee", value=grantee, expected_type=type_hints["grantee"])
        return typing.cast("_aws_cdk_aws_iam_ceddda9d.Grant", jsii.invoke(self, "ingest", [grantee]))

    @builtins.property
    @jsii.member(jsii_name="resource")
    def _resource(
        self,
    ) -> "_aws_cdk_interfaces_aws_mediapackagev2_ceddda9d.IChannelRef":
        '''
        :stability: experimental
        '''
        return typing.cast("_aws_cdk_interfaces_aws_mediapackagev2_ceddda9d.IChannelRef", jsii.get(self, "resource"))

    @builtins.property
    @jsii.member(jsii_name="policyResource")
    def _policy_resource(
        self,
    ) -> typing.Optional["_aws_cdk_aws_iam_ceddda9d.IResourceWithPolicyV2"]:
        '''
        :stability: experimental
        '''
        return typing.cast(typing.Optional["_aws_cdk_aws_iam_ceddda9d.IResourceWithPolicyV2"], jsii.get(self, "policyResource"))


@jsii.data_type(
    jsii_type="@aws-cdk/aws-mediapackagev2-alpha.ChannelGroupAttributes",
    jsii_struct_bases=[],
    name_mapping={
        "channel_group_name": "channelGroupName",
        "egress_domain": "egressDomain",
    },
)
class ChannelGroupAttributes:
    def __init__(
        self,
        *,
        channel_group_name: builtins.str,
        egress_domain: typing.Optional[builtins.str] = None,
    ) -> None:
        '''(experimental) Attributes to enable import of a Channel Group, which in turn can be used to create a Channel and OriginEndpoint).

        :param channel_group_name: (experimental) Channel Group Name.
        :param egress_domain: (experimental) The egress domain where packaged content is available. Use this as the origin domain when configuring a CDN such as Amazon CloudFront. Default: - not available on imported channel groups

        :stability: experimental
        :exampleMetadata: infused

        Example::

            # stack: Stack
            
            channel_group = ChannelGroup.from_channel_group_attributes(stack, "ImportedChannelGroup",
                channel_group_name="MyChannelGroup"
            )
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__18915e4ef54cf118705a88eeec8edcbdd15cacdd7eabcb196bcc4d8296d61bf2)
            check_type(argname="argument channel_group_name", value=channel_group_name, expected_type=type_hints["channel_group_name"])
            check_type(argname="argument egress_domain", value=egress_domain, expected_type=type_hints["egress_domain"])
        self._values: typing.Dict[builtins.str, typing.Any] = {
            "channel_group_name": channel_group_name,
        }
        if egress_domain is not None:
            self._values["egress_domain"] = egress_domain

    @builtins.property
    def channel_group_name(self) -> builtins.str:
        '''(experimental) Channel Group Name.

        :stability: experimental
        '''
        result = self._values.get("channel_group_name")
        assert result is not None, "Required property 'channel_group_name' is missing"
        return typing.cast(builtins.str, result)

    @builtins.property
    def egress_domain(self) -> typing.Optional[builtins.str]:
        '''(experimental) The egress domain where packaged content is available.

        Use this as the origin domain when configuring a CDN such as Amazon CloudFront.

        :default: - not available on imported channel groups

        :stability: experimental
        '''
        result = self._values.get("egress_domain")
        return typing.cast(typing.Optional[builtins.str], result)

    def __eq__(self, rhs: typing.Any) -> builtins.bool:
        return isinstance(rhs, self.__class__) and rhs._values == self._values

    def __ne__(self, rhs: typing.Any) -> builtins.bool:
        return not (rhs == self)

    def __repr__(self) -> str:
        return "ChannelGroupAttributes(%s)" % ", ".join(
            k + "=" + repr(v) for k, v in self._values.items()
        )


@jsii.data_type(
    jsii_type="@aws-cdk/aws-mediapackagev2-alpha.ChannelGroupProps",
    jsii_struct_bases=[],
    name_mapping={
        "channel_group_name": "channelGroupName",
        "description": "description",
        "removal_policy": "removalPolicy",
        "tags": "tags",
    },
)
class ChannelGroupProps:
    def __init__(
        self,
        *,
        channel_group_name: typing.Optional[builtins.str] = None,
        description: typing.Optional[builtins.str] = None,
        removal_policy: typing.Optional["_aws_cdk_ceddda9d.RemovalPolicy"] = None,
        tags: typing.Optional[typing.Mapping[builtins.str, builtins.str]] = None,
    ) -> None:
        '''(experimental) Properties for the Channel Group.

        :param channel_group_name: (experimental) The name that describes the channel group. The name is the primary identifier for the channel group, and must be unique for your account in the AWS Region. Default: autogenerated
        :param description: (experimental) The description for your channel group. Default: - no description
        :param removal_policy: (experimental) Policy to apply when the channel group is removed from the stack. Even though MediaPackage ChannelGroups, Channels and OriginEndpoints are technically stateful, their contents are transient and it is common to add and remove these while rearchitecting your application. The default is therefore ``DESTROY``. Change it to ``RETAIN`` if the content (in a lookback window) are so valuable that accidentally losing it would be unacceptable. Default: RemovalPolicy.DESTROY
        :param tags: (experimental) Tags to add to the Channel Group. Default: - No tagging

        :stability: experimental
        :exampleMetadata: infused

        Example::

            # stack: Stack
            
            
            # Create a channel group
            group = ChannelGroup(stack, "MyChannelGroup",
                channel_group_name="my-channel-group"
            )
            
            # Add a channel using the factory method
            channel = group.add_channel("MyChannel",
                channel_name="my-channel",
                input=InputConfiguration.cmaf()
            )
            
            # Add an origin endpoint using the factory method
            endpoint = channel.add_origin_endpoint("MyEndpoint",
                origin_endpoint_name="my-endpoint",
                segment=Segment.cmaf(),
                manifests=[Manifest.hls(manifest_name="index")]
            )
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__b661b89526bafe2c5b5acded16dac17256117c013a1f41e8670fdd6e70802914)
            check_type(argname="argument channel_group_name", value=channel_group_name, expected_type=type_hints["channel_group_name"])
            check_type(argname="argument description", value=description, expected_type=type_hints["description"])
            check_type(argname="argument removal_policy", value=removal_policy, expected_type=type_hints["removal_policy"])
            check_type(argname="argument tags", value=tags, expected_type=type_hints["tags"])
        self._values: typing.Dict[builtins.str, typing.Any] = {}
        if channel_group_name is not None:
            self._values["channel_group_name"] = channel_group_name
        if description is not None:
            self._values["description"] = description
        if removal_policy is not None:
            self._values["removal_policy"] = removal_policy
        if tags is not None:
            self._values["tags"] = tags

    @builtins.property
    def channel_group_name(self) -> typing.Optional[builtins.str]:
        '''(experimental) The name that describes the channel group.

        The name is the primary identifier for the channel group, and must be unique for your account in the AWS Region.

        :default: autogenerated

        :stability: experimental
        '''
        result = self._values.get("channel_group_name")
        return typing.cast(typing.Optional[builtins.str], result)

    @builtins.property
    def description(self) -> typing.Optional[builtins.str]:
        '''(experimental) The description for your channel group.

        :default: - no description

        :stability: experimental
        '''
        result = self._values.get("description")
        return typing.cast(typing.Optional[builtins.str], result)

    @builtins.property
    def removal_policy(self) -> typing.Optional["_aws_cdk_ceddda9d.RemovalPolicy"]:
        '''(experimental) Policy to apply when the channel group is removed from the stack.

        Even though MediaPackage ChannelGroups, Channels and OriginEndpoints are technically stateful,
        their contents are transient and it is common to add and remove these while rearchitecting your application.
        The default is therefore ``DESTROY``. Change it to ``RETAIN`` if the content (in a lookback window) are so
        valuable that accidentally losing it would be unacceptable.

        :default: RemovalPolicy.DESTROY

        :stability: experimental
        '''
        result = self._values.get("removal_policy")
        return typing.cast(typing.Optional["_aws_cdk_ceddda9d.RemovalPolicy"], result)

    @builtins.property
    def tags(self) -> typing.Optional[typing.Mapping[builtins.str, builtins.str]]:
        '''(experimental) Tags to add to the Channel Group.

        :default: - No tagging

        :stability: experimental
        '''
        result = self._values.get("tags")
        return typing.cast(typing.Optional[typing.Mapping[builtins.str, builtins.str]], result)

    def __eq__(self, rhs: typing.Any) -> builtins.bool:
        return isinstance(rhs, self.__class__) and rhs._values == self._values

    def __ne__(self, rhs: typing.Any) -> builtins.bool:
        return not (rhs == self)

    def __repr__(self) -> str:
        return "ChannelGroupProps(%s)" % ", ".join(
            k + "=" + repr(v) for k, v in self._values.items()
        )


@jsii.data_type(
    jsii_type="@aws-cdk/aws-mediapackagev2-alpha.ChannelOptions",
    jsii_struct_bases=[],
    name_mapping={
        "channel_name": "channelName",
        "description": "description",
        "input": "input",
        "removal_policy": "removalPolicy",
        "tags": "tags",
    },
)
class ChannelOptions:
    def __init__(
        self,
        *,
        channel_name: typing.Optional[builtins.str] = None,
        description: typing.Optional[builtins.str] = None,
        input: typing.Optional["InputConfiguration"] = None,
        removal_policy: typing.Optional["_aws_cdk_ceddda9d.RemovalPolicy"] = None,
        tags: typing.Optional[typing.Mapping[builtins.str, builtins.str]] = None,
    ) -> None:
        '''(experimental) Configuration options for an AWS Elemental MediaPackage V2 Channel.

        Used when creating a channel via ``ChannelGroup.addChannel()``.

        :param channel_name: (experimental) The name that describes the channel. The name is the primary identifier for the channel, and must be unique for your account in the AWS Region and channel group. Default: autogenerated
        :param description: (experimental) Enter any descriptive text that helps you to identify the channel. Default: no description
        :param input: (experimental) Input configuration for the channel. Use InputConfiguration.hls() or InputConfiguration.cmaf() to create the configuration. Default: InputConfiguration.cmaf()
        :param removal_policy: (experimental) Policy to apply when the channel is removed from the stack. Even though MediaPackage ChannelGroups, Channels and OriginEndpoints are technically stateful, their contents are transient and it is common to add and remove these while rearchitecting your application. The default is therefore ``DESTROY``. Change it to ``RETAIN`` if the content (in a lookback window) are so valuable that accidentally losing it would be unacceptable. Default: RemovalPolicy.DESTROY
        :param tags: (experimental) Tags to add to the Channel. Default: No tagging

        :stability: experimental
        :exampleMetadata: infused

        Example::

            # stack: Stack
            
            
            # Create a channel group
            group = ChannelGroup(stack, "MyChannelGroup",
                channel_group_name="my-channel-group"
            )
            
            # Add a channel using the factory method
            channel = group.add_channel("MyChannel",
                channel_name="my-channel",
                input=InputConfiguration.cmaf()
            )
            
            # Add an origin endpoint using the factory method
            endpoint = channel.add_origin_endpoint("MyEndpoint",
                origin_endpoint_name="my-endpoint",
                segment=Segment.cmaf(),
                manifests=[Manifest.hls(manifest_name="index")]
            )
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__58c9af0b7061b152c26ed32505c5e17f4aab847ef25106b67860deda20e6889d)
            check_type(argname="argument channel_name", value=channel_name, expected_type=type_hints["channel_name"])
            check_type(argname="argument description", value=description, expected_type=type_hints["description"])
            check_type(argname="argument input", value=input, expected_type=type_hints["input"])
            check_type(argname="argument removal_policy", value=removal_policy, expected_type=type_hints["removal_policy"])
            check_type(argname="argument tags", value=tags, expected_type=type_hints["tags"])
        self._values: typing.Dict[builtins.str, typing.Any] = {}
        if channel_name is not None:
            self._values["channel_name"] = channel_name
        if description is not None:
            self._values["description"] = description
        if input is not None:
            self._values["input"] = input
        if removal_policy is not None:
            self._values["removal_policy"] = removal_policy
        if tags is not None:
            self._values["tags"] = tags

    @builtins.property
    def channel_name(self) -> typing.Optional[builtins.str]:
        '''(experimental) The name that describes the channel.

        The name is the primary identifier for the channel, and must be unique for your account in the AWS Region and channel group.

        :default: autogenerated

        :stability: experimental
        '''
        result = self._values.get("channel_name")
        return typing.cast(typing.Optional[builtins.str], result)

    @builtins.property
    def description(self) -> typing.Optional[builtins.str]:
        '''(experimental) Enter any descriptive text that helps you to identify the channel.

        :default: no description

        :stability: experimental
        '''
        result = self._values.get("description")
        return typing.cast(typing.Optional[builtins.str], result)

    @builtins.property
    def input(self) -> typing.Optional["InputConfiguration"]:
        '''(experimental) Input configuration for the channel.

        Use InputConfiguration.hls() or InputConfiguration.cmaf() to create the configuration.

        :default: InputConfiguration.cmaf()

        :stability: experimental
        '''
        result = self._values.get("input")
        return typing.cast(typing.Optional["InputConfiguration"], result)

    @builtins.property
    def removal_policy(self) -> typing.Optional["_aws_cdk_ceddda9d.RemovalPolicy"]:
        '''(experimental) Policy to apply when the channel is removed from the stack.

        Even though MediaPackage ChannelGroups, Channels and OriginEndpoints are technically stateful,
        their contents are transient and it is common to add and remove these while rearchitecting your application.
        The default is therefore ``DESTROY``. Change it to ``RETAIN`` if the content (in a lookback window) are so
        valuable that accidentally losing it would be unacceptable.

        :default: RemovalPolicy.DESTROY

        :stability: experimental
        '''
        result = self._values.get("removal_policy")
        return typing.cast(typing.Optional["_aws_cdk_ceddda9d.RemovalPolicy"], result)

    @builtins.property
    def tags(self) -> typing.Optional[typing.Mapping[builtins.str, builtins.str]]:
        '''(experimental) Tags to add to the Channel.

        :default: No tagging

        :stability: experimental
        '''
        result = self._values.get("tags")
        return typing.cast(typing.Optional[typing.Mapping[builtins.str, builtins.str]], result)

    def __eq__(self, rhs: typing.Any) -> builtins.bool:
        return isinstance(rhs, self.__class__) and rhs._values == self._values

    def __ne__(self, rhs: typing.Any) -> builtins.bool:
        return not (rhs == self)

    def __repr__(self) -> str:
        return "ChannelOptions(%s)" % ", ".join(
            k + "=" + repr(v) for k, v in self._values.items()
        )


class ChannelPolicy(
    _aws_cdk_ceddda9d.Resource,
    metaclass=jsii.JSIIMeta,
    jsii_type="@aws-cdk/aws-mediapackagev2-alpha.ChannelPolicy",
):
    '''(experimental) The channel policy for an AWS Elemental MediaPackage V2 channel.

    Policies define the operations that are allowed on this resource.

    You almost never need to define this construct directly.

    All AWS resources that support resource policies have a method called
    ``addToResourcePolicy()``, which will automatically create a new resource
    policy if one doesn't exist yet, otherwise it will add to the existing
    policy.

    The channel policy method is implemented differently than ``addToResourcePolicy()``
    as ``ChannelPolicy`` creates a new policy without knowing one earlier existed.
    This will cause a resource conflict if both are invoked (or even multiple channel
    policies are defined), so care is to be taken to ensure only 1 channel policy
    is created per channel.

    Hence it's strongly recommended to use ``addToResourcePolicy()``.

    :stability: experimental
    :exampleMetadata: fixture=_generated

    Example::

        # The code below shows an example of how to instantiate this type.
        # The values are placeholders you should change.
        import aws_cdk.aws_mediapackagev2_alpha as mediapackagev2_alpha
        from aws_cdk import aws_iam as iam
        
        # channel: mediapackagev2_alpha.Channel
        # policy_document: iam.PolicyDocument
        
        channel_policy = mediapackagev2_alpha.ChannelPolicy(self, "MyChannelPolicy",
            channel=channel,
        
            # the properties below are optional
            policy_document=policy_document
        )
    '''

    def __init__(
        self,
        scope: "_constructs_77d1e7e8.Construct",
        id: builtins.str,
        *,
        channel: "IChannel",
        policy_document: typing.Optional["_aws_cdk_aws_iam_ceddda9d.PolicyDocument"] = None,
    ) -> None:
        '''
        :param scope: -
        :param id: -
        :param channel: (experimental) Channel to apply the Channel Policy to.
        :param policy_document: (experimental) Initial policy document to apply. Default: - empty policy document

        :stability: experimental
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__254aa3d7fb168fa977a8082f25556744916bdad988a167a6456e12b7b1b01e5f)
            check_type(argname="argument scope", value=scope, expected_type=type_hints["scope"])
            check_type(argname="argument id", value=id, expected_type=type_hints["id"])
        props = ChannelPolicyProps(channel=channel, policy_document=policy_document)

        jsii.create(self.__class__, self, [scope, id, props])

    @jsii.python.classproperty
    @jsii.member(jsii_name="PROPERTY_INJECTION_ID")
    def PROPERTY_INJECTION_ID(cls) -> builtins.str:
        '''(experimental) Uniquely identifies this class.

        :stability: experimental
        '''
        return typing.cast(builtins.str, jsii.sget(cls, "PROPERTY_INJECTION_ID"))

    @builtins.property
    @jsii.member(jsii_name="document")
    def document(self) -> "_aws_cdk_aws_iam_ceddda9d.PolicyDocument":
        '''(experimental) A policy document containing permissions to add to the specified channel.

        :stability: experimental
        '''
        return typing.cast("_aws_cdk_aws_iam_ceddda9d.PolicyDocument", jsii.get(self, "document"))


@jsii.data_type(
    jsii_type="@aws-cdk/aws-mediapackagev2-alpha.ChannelPolicyProps",
    jsii_struct_bases=[],
    name_mapping={"channel": "channel", "policy_document": "policyDocument"},
)
class ChannelPolicyProps:
    def __init__(
        self,
        *,
        channel: "IChannel",
        policy_document: typing.Optional["_aws_cdk_aws_iam_ceddda9d.PolicyDocument"] = None,
    ) -> None:
        '''(experimental) Properties for the Channel Policy.

        :param channel: (experimental) Channel to apply the Channel Policy to.
        :param policy_document: (experimental) Initial policy document to apply. Default: - empty policy document

        :stability: experimental
        :exampleMetadata: fixture=_generated

        Example::

            # The code below shows an example of how to instantiate this type.
            # The values are placeholders you should change.
            import aws_cdk.aws_mediapackagev2_alpha as mediapackagev2_alpha
            from aws_cdk import aws_iam as iam
            
            # channel: mediapackagev2_alpha.Channel
            # policy_document: iam.PolicyDocument
            
            channel_policy_props = mediapackagev2_alpha.ChannelPolicyProps(
                channel=channel,
            
                # the properties below are optional
                policy_document=policy_document
            )
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__1c9900c4dd3a19f21f5a8f9e05ab82ecf487a4d9b41deaaae63685ae66220ffc)
            check_type(argname="argument channel", value=channel, expected_type=type_hints["channel"])
            check_type(argname="argument policy_document", value=policy_document, expected_type=type_hints["policy_document"])
        self._values: typing.Dict[builtins.str, typing.Any] = {
            "channel": channel,
        }
        if policy_document is not None:
            self._values["policy_document"] = policy_document

    @builtins.property
    def channel(self) -> "IChannel":
        '''(experimental) Channel to apply the Channel Policy to.

        :stability: experimental
        '''
        result = self._values.get("channel")
        assert result is not None, "Required property 'channel' is missing"
        return typing.cast("IChannel", result)

    @builtins.property
    def policy_document(
        self,
    ) -> typing.Optional["_aws_cdk_aws_iam_ceddda9d.PolicyDocument"]:
        '''(experimental) Initial policy document to apply.

        :default: - empty policy document

        :stability: experimental
        '''
        result = self._values.get("policy_document")
        return typing.cast(typing.Optional["_aws_cdk_aws_iam_ceddda9d.PolicyDocument"], result)

    def __eq__(self, rhs: typing.Any) -> builtins.bool:
        return isinstance(rhs, self.__class__) and rhs._values == self._values

    def __ne__(self, rhs: typing.Any) -> builtins.bool:
        return not (rhs == self)

    def __repr__(self) -> str:
        return "ChannelPolicyProps(%s)" % ", ".join(
            k + "=" + repr(v) for k, v in self._values.items()
        )


@jsii.data_type(
    jsii_type="@aws-cdk/aws-mediapackagev2-alpha.ChannelProps",
    jsii_struct_bases=[ChannelOptions],
    name_mapping={
        "channel_name": "channelName",
        "description": "description",
        "input": "input",
        "removal_policy": "removalPolicy",
        "tags": "tags",
        "channel_group": "channelGroup",
    },
)
class ChannelProps(ChannelOptions):
    def __init__(
        self,
        *,
        channel_name: typing.Optional[builtins.str] = None,
        description: typing.Optional[builtins.str] = None,
        input: typing.Optional["InputConfiguration"] = None,
        removal_policy: typing.Optional["_aws_cdk_ceddda9d.RemovalPolicy"] = None,
        tags: typing.Optional[typing.Mapping[builtins.str, builtins.str]] = None,
        channel_group: "IChannelGroup",
    ) -> None:
        '''(experimental) Properties to set on a Channel.

        :param channel_name: (experimental) The name that describes the channel. The name is the primary identifier for the channel, and must be unique for your account in the AWS Region and channel group. Default: autogenerated
        :param description: (experimental) Enter any descriptive text that helps you to identify the channel. Default: no description
        :param input: (experimental) Input configuration for the channel. Use InputConfiguration.hls() or InputConfiguration.cmaf() to create the configuration. Default: InputConfiguration.cmaf()
        :param removal_policy: (experimental) Policy to apply when the channel is removed from the stack. Even though MediaPackage ChannelGroups, Channels and OriginEndpoints are technically stateful, their contents are transient and it is common to add and remove these while rearchitecting your application. The default is therefore ``DESTROY``. Change it to ``RETAIN`` if the content (in a lookback window) are so valuable that accidentally losing it would be unacceptable. Default: RemovalPolicy.DESTROY
        :param tags: (experimental) Tags to add to the Channel. Default: No tagging
        :param channel_group: (experimental) Channel Group to add this Channel to.

        :stability: experimental
        :exampleMetadata: infused

        Example::

            # stack: Stack
            
            group = ChannelGroup(stack, "MyChannelGroup",
                channel_group_name="my-test-channel-group"
            )
            
            channel = Channel(stack, "MyChannel",
                channel_group=group,
                channel_name="my-testchannel",
                input=InputConfiguration.cmaf()
            )
            
            endpoint = OriginEndpoint(stack, "MyOriginEndpoint",
                channel=channel,
                origin_endpoint_name="my-test-endpoint",
                segment=Segment.cmaf(),
                manifests=[Manifest.hls(
                    manifest_name="index"
                )]
            )
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__adf088508014b31b36bd72748a7a4e7c13de583dfbcb8750a94f7133b29d0c8b)
            check_type(argname="argument channel_name", value=channel_name, expected_type=type_hints["channel_name"])
            check_type(argname="argument description", value=description, expected_type=type_hints["description"])
            check_type(argname="argument input", value=input, expected_type=type_hints["input"])
            check_type(argname="argument removal_policy", value=removal_policy, expected_type=type_hints["removal_policy"])
            check_type(argname="argument tags", value=tags, expected_type=type_hints["tags"])
            check_type(argname="argument channel_group", value=channel_group, expected_type=type_hints["channel_group"])
        self._values: typing.Dict[builtins.str, typing.Any] = {
            "channel_group": channel_group,
        }
        if channel_name is not None:
            self._values["channel_name"] = channel_name
        if description is not None:
            self._values["description"] = description
        if input is not None:
            self._values["input"] = input
        if removal_policy is not None:
            self._values["removal_policy"] = removal_policy
        if tags is not None:
            self._values["tags"] = tags

    @builtins.property
    def channel_name(self) -> typing.Optional[builtins.str]:
        '''(experimental) The name that describes the channel.

        The name is the primary identifier for the channel, and must be unique for your account in the AWS Region and channel group.

        :default: autogenerated

        :stability: experimental
        '''
        result = self._values.get("channel_name")
        return typing.cast(typing.Optional[builtins.str], result)

    @builtins.property
    def description(self) -> typing.Optional[builtins.str]:
        '''(experimental) Enter any descriptive text that helps you to identify the channel.

        :default: no description

        :stability: experimental
        '''
        result = self._values.get("description")
        return typing.cast(typing.Optional[builtins.str], result)

    @builtins.property
    def input(self) -> typing.Optional["InputConfiguration"]:
        '''(experimental) Input configuration for the channel.

        Use InputConfiguration.hls() or InputConfiguration.cmaf() to create the configuration.

        :default: InputConfiguration.cmaf()

        :stability: experimental
        '''
        result = self._values.get("input")
        return typing.cast(typing.Optional["InputConfiguration"], result)

    @builtins.property
    def removal_policy(self) -> typing.Optional["_aws_cdk_ceddda9d.RemovalPolicy"]:
        '''(experimental) Policy to apply when the channel is removed from the stack.

        Even though MediaPackage ChannelGroups, Channels and OriginEndpoints are technically stateful,
        their contents are transient and it is common to add and remove these while rearchitecting your application.
        The default is therefore ``DESTROY``. Change it to ``RETAIN`` if the content (in a lookback window) are so
        valuable that accidentally losing it would be unacceptable.

        :default: RemovalPolicy.DESTROY

        :stability: experimental
        '''
        result = self._values.get("removal_policy")
        return typing.cast(typing.Optional["_aws_cdk_ceddda9d.RemovalPolicy"], result)

    @builtins.property
    def tags(self) -> typing.Optional[typing.Mapping[builtins.str, builtins.str]]:
        '''(experimental) Tags to add to the Channel.

        :default: No tagging

        :stability: experimental
        '''
        result = self._values.get("tags")
        return typing.cast(typing.Optional[typing.Mapping[builtins.str, builtins.str]], result)

    @builtins.property
    def channel_group(self) -> "IChannelGroup":
        '''(experimental) Channel Group to add this Channel to.

        :stability: experimental
        '''
        result = self._values.get("channel_group")
        assert result is not None, "Required property 'channel_group' is missing"
        return typing.cast("IChannelGroup", result)

    def __eq__(self, rhs: typing.Any) -> builtins.bool:
        return isinstance(rhs, self.__class__) and rhs._values == self._values

    def __ne__(self, rhs: typing.Any) -> builtins.bool:
        return not (rhs == self)

    def __repr__(self) -> str:
        return "ChannelProps(%s)" % ", ".join(
            k + "=" + repr(v) for k, v in self._values.items()
        )


@jsii.enum(jsii_type="@aws-cdk/aws-mediapackagev2-alpha.CmafDrmSystem")
class CmafDrmSystem(enum.Enum):
    '''(experimental) DRM systems available for CMAF encryption.

    CENC supports PlayReady, Widevine, and Irdeto.
    CBCS supports PlayReady, Widevine, and FairPlay.

    :stability: experimental
    '''

    FAIRPLAY = "FAIRPLAY"
    '''(experimental) FairPlay DRM - used with CBCS encryption.

    :stability: experimental
    '''
    PLAYREADY = "PLAYREADY"
    '''(experimental) PlayReady DRM - used with CENC and CBCS encryption.

    :stability: experimental
    '''
    WIDEVINE = "WIDEVINE"
    '''(experimental) Widevine DRM - used with CENC and CBCS encryption.

    :stability: experimental
    '''
    IRDETO = "IRDETO"
    '''(experimental) Irdeto DRM - used with CENC encryption.

    :stability: experimental
    '''


@jsii.enum(jsii_type="@aws-cdk/aws-mediapackagev2-alpha.CmafEncryptionMethod")
class CmafEncryptionMethod(enum.Enum):
    '''(experimental) Encryption methods for CMAF container type.

    :stability: experimental
    :exampleMetadata: infused

    Example::

        # channel: Channel
        # speke_role: iam.IRole
        # certificate: certificatemanager.ICertificate
        
        
        OriginEndpoint(self, "Endpoint",
            channel=channel,
            segment=Segment.cmaf(
                encryption=CmafEncryption.speke(
                    method=CmafEncryptionMethod.CBCS,
                    drm_systems=[CmafDrmSystem.FAIRPLAY],
                    resource_id="my-content-id",
                    url="https://example.com/speke",
                    role=speke_role,
                    certificate=certificate
                )
            ),
            manifests=[Manifest.hls(manifest_name="index")]
        )
    '''

    CENC = "CENC"
    '''(experimental) Common Encryption Scheme (CENC) - compatible with PlayReady, Widevine, and Irdeto DRM systems.

    :stability: experimental
    '''
    CBCS = "CBCS"
    '''(experimental) Common Encryption Scheme with CBCS mode - compatible with PlayReady, Widevine, and FairPlay DRM systems.

    :stability: experimental
    '''


@jsii.data_type(
    jsii_type="@aws-cdk/aws-mediapackagev2-alpha.CmafInputProps",
    jsii_struct_bases=[],
    name_mapping={
        "input_switch_configuration": "inputSwitchConfiguration",
        "output_headers": "outputHeaders",
    },
)
class CmafInputProps:
    def __init__(
        self,
        *,
        input_switch_configuration: typing.Optional[typing.Union["InputSwitchConfiguration", typing.Dict[builtins.str, typing.Any]]] = None,
        output_headers: typing.Optional[typing.Sequence["HeadersCMSD"]] = None,
    ) -> None:
        '''(experimental) Properties for CMAF input configuration.

        :param input_switch_configuration: (experimental) The configuration for input switching based on the media quality confidence score (MQCS) as provided from AWS Elemental MediaLive. Default: No customized input switch configuration added
        :param output_headers: (experimental) The settings for what common media server data (CMSD) headers AWS Elemental MediaPackage includes in responses to the CDN. Default: none

        :stability: experimental
        :exampleMetadata: infused

        Example::

            from aws_cdk.aws_mediapackagev2_alpha import InputSwitchConfiguration
            # stack: Stack
            # group: ChannelGroup
            
            
            hls_channel = Channel(stack, "HlsChannel",
                channel_group=group,
                input=InputConfiguration.hls()
            )
            
            cmaf_channel = Channel(stack, "CmafChannel",
                channel_group=group,
                input=InputConfiguration.cmaf(
                    input_switch_configuration=InputSwitchConfiguration(
                        mqcs_input_switching=True
                    ),
                    output_headers=[HeadersCMSD.MQCS]
                )
            )
            
            simple_cmaf_channel = Channel(stack, "SimpleCmafChannel",
                channel_group=group,
                input=InputConfiguration.cmaf(
                    output_headers=[HeadersCMSD.MQCS]
                )
            )
        '''
        if isinstance(input_switch_configuration, dict):
            input_switch_configuration = InputSwitchConfiguration(**input_switch_configuration)
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__2a272d1cd2a0c4d33ce97c6ff17c5aa4ef5dd9282731e89954ffbe2648aa304a)
            check_type(argname="argument input_switch_configuration", value=input_switch_configuration, expected_type=type_hints["input_switch_configuration"])
            check_type(argname="argument output_headers", value=output_headers, expected_type=type_hints["output_headers"])
        self._values: typing.Dict[builtins.str, typing.Any] = {}
        if input_switch_configuration is not None:
            self._values["input_switch_configuration"] = input_switch_configuration
        if output_headers is not None:
            self._values["output_headers"] = output_headers

    @builtins.property
    def input_switch_configuration(self) -> typing.Optional["InputSwitchConfiguration"]:
        '''(experimental) The configuration for input switching based on the media quality confidence score (MQCS) as provided from AWS Elemental MediaLive.

        :default: No customized input switch configuration added

        :stability: experimental
        '''
        result = self._values.get("input_switch_configuration")
        return typing.cast(typing.Optional["InputSwitchConfiguration"], result)

    @builtins.property
    def output_headers(self) -> typing.Optional[typing.List["HeadersCMSD"]]:
        '''(experimental) The settings for what common media server data (CMSD) headers AWS Elemental MediaPackage includes in responses to the CDN.

        :default: none

        :stability: experimental
        '''
        result = self._values.get("output_headers")
        return typing.cast(typing.Optional[typing.List["HeadersCMSD"]], result)

    def __eq__(self, rhs: typing.Any) -> builtins.bool:
        return isinstance(rhs, self.__class__) and rhs._values == self._values

    def __ne__(self, rhs: typing.Any) -> builtins.bool:
        return not (rhs == self)

    def __repr__(self) -> str:
        return "CmafInputProps(%s)" % ", ".join(
            k + "=" + repr(v) for k, v in self._values.items()
        )


@jsii.data_type(
    jsii_type="@aws-cdk/aws-mediapackagev2-alpha.CmafSpekeEncryptionProps",
    jsii_struct_bases=[],
    name_mapping={
        "drm_systems": "drmSystems",
        "method": "method",
        "resource_id": "resourceId",
        "role": "role",
        "url": "url",
        "audio_preset": "audioPreset",
        "certificate": "certificate",
        "constant_initialization_vector": "constantInitializationVector",
        "exclude_segment_drm_metadata": "excludeSegmentDrmMetadata",
        "key_rotation_interval": "keyRotationInterval",
        "video_preset": "videoPreset",
    },
)
class CmafSpekeEncryptionProps:
    def __init__(
        self,
        *,
        drm_systems: typing.Sequence["CmafDrmSystem"],
        method: "CmafEncryptionMethod",
        resource_id: builtins.str,
        role: "_aws_cdk_aws_iam_ceddda9d.IRole",
        url: builtins.str,
        audio_preset: typing.Optional["PresetSpeke20Audio"] = None,
        certificate: typing.Optional["_aws_cdk_aws_certificatemanager_ceddda9d.ICertificate"] = None,
        constant_initialization_vector: typing.Optional[builtins.str] = None,
        exclude_segment_drm_metadata: typing.Optional[builtins.bool] = None,
        key_rotation_interval: typing.Optional["_aws_cdk_ceddda9d.Duration"] = None,
        video_preset: typing.Optional["PresetSpeke20Video"] = None,
    ) -> None:
        '''(experimental) Properties for CMAF SPEKE encryption configuration.

        :param drm_systems: (experimental) The DRM systems to use for content protection. CENC supports PlayReady, Widevine, and Irdeto. CBCS supports PlayReady, Widevine, and FairPlay.
        :param method: (experimental) The encryption method to use.
        :param resource_id: (experimental) The unique identifier for the content. The service sends this identifier to the key server to identify the current endpoint. How unique you make this identifier depends on how fine-grained you want access controls to be. The service does not permit you to use the same ID for two simultaneous encryption processes.
        :param role: (experimental) IAM role for accessing the key provider API. This role must have a trust policy that allows MediaPackage to assume the role, and it must have sufficient permissions to access the key retrieval URL.
        :param url: (experimental) URL of the SPEKE key provider.
        :param audio_preset: (experimental) Audio encryption preset. Default: PresetSpeke20Audio.PRESET_AUDIO_1
        :param certificate: (experimental) The ARN of the certificate that you imported to AWS Certificate Manager to add content key encryption to this endpoint. For this feature to work, your DRM key provider must support content key encryption. Default: - no content key encryption
        :param constant_initialization_vector: (experimental) Constant initialization vector (32-character hex string). A 128-bit, 16-byte hex value represented by a 32-character string, used in conjunction with the key for encrypting content. Default: - MediaPackage generates the IV
        :param exclude_segment_drm_metadata: (experimental) When enabled, DRM metadata is excluded from CMAF segments. Default: false
        :param key_rotation_interval: (experimental) Key rotation interval. Default: - no rotation
        :param video_preset: (experimental) Video encryption preset. Default: PresetSpeke20Video.PRESET_VIDEO_1

        :stability: experimental
        :exampleMetadata: infused

        Example::

            # channel: Channel
            # speke_role: iam.IRole
            # certificate: certificatemanager.ICertificate
            
            
            OriginEndpoint(self, "Endpoint",
                channel=channel,
                segment=Segment.cmaf(
                    encryption=CmafEncryption.speke(
                        method=CmafEncryptionMethod.CBCS,
                        drm_systems=[CmafDrmSystem.FAIRPLAY],
                        resource_id="my-content-id",
                        url="https://example.com/speke",
                        role=speke_role,
                        certificate=certificate
                    )
                ),
                manifests=[Manifest.hls(manifest_name="index")]
            )
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__afb64bc3c9b007944e121c7e242753845cd8a76d1861921290670294ea747dcd)
            check_type(argname="argument drm_systems", value=drm_systems, expected_type=type_hints["drm_systems"])
            check_type(argname="argument method", value=method, expected_type=type_hints["method"])
            check_type(argname="argument resource_id", value=resource_id, expected_type=type_hints["resource_id"])
            check_type(argname="argument role", value=role, expected_type=type_hints["role"])
            check_type(argname="argument url", value=url, expected_type=type_hints["url"])
            check_type(argname="argument audio_preset", value=audio_preset, expected_type=type_hints["audio_preset"])
            check_type(argname="argument certificate", value=certificate, expected_type=type_hints["certificate"])
            check_type(argname="argument constant_initialization_vector", value=constant_initialization_vector, expected_type=type_hints["constant_initialization_vector"])
            check_type(argname="argument exclude_segment_drm_metadata", value=exclude_segment_drm_metadata, expected_type=type_hints["exclude_segment_drm_metadata"])
            check_type(argname="argument key_rotation_interval", value=key_rotation_interval, expected_type=type_hints["key_rotation_interval"])
            check_type(argname="argument video_preset", value=video_preset, expected_type=type_hints["video_preset"])
        self._values: typing.Dict[builtins.str, typing.Any] = {
            "drm_systems": drm_systems,
            "method": method,
            "resource_id": resource_id,
            "role": role,
            "url": url,
        }
        if audio_preset is not None:
            self._values["audio_preset"] = audio_preset
        if certificate is not None:
            self._values["certificate"] = certificate
        if constant_initialization_vector is not None:
            self._values["constant_initialization_vector"] = constant_initialization_vector
        if exclude_segment_drm_metadata is not None:
            self._values["exclude_segment_drm_metadata"] = exclude_segment_drm_metadata
        if key_rotation_interval is not None:
            self._values["key_rotation_interval"] = key_rotation_interval
        if video_preset is not None:
            self._values["video_preset"] = video_preset

    @builtins.property
    def drm_systems(self) -> typing.List["CmafDrmSystem"]:
        '''(experimental) The DRM systems to use for content protection.

        CENC supports PlayReady, Widevine, and Irdeto.
        CBCS supports PlayReady, Widevine, and FairPlay.

        :stability: experimental
        '''
        result = self._values.get("drm_systems")
        assert result is not None, "Required property 'drm_systems' is missing"
        return typing.cast(typing.List["CmafDrmSystem"], result)

    @builtins.property
    def method(self) -> "CmafEncryptionMethod":
        '''(experimental) The encryption method to use.

        :stability: experimental
        '''
        result = self._values.get("method")
        assert result is not None, "Required property 'method' is missing"
        return typing.cast("CmafEncryptionMethod", result)

    @builtins.property
    def resource_id(self) -> builtins.str:
        '''(experimental) The unique identifier for the content.

        The service sends this identifier to the key server to identify the current endpoint.
        How unique you make this identifier depends on how fine-grained you want access controls to be.
        The service does not permit you to use the same ID for two simultaneous encryption processes.

        :stability: experimental
        '''
        result = self._values.get("resource_id")
        assert result is not None, "Required property 'resource_id' is missing"
        return typing.cast(builtins.str, result)

    @builtins.property
    def role(self) -> "_aws_cdk_aws_iam_ceddda9d.IRole":
        '''(experimental) IAM role for accessing the key provider API.

        This role must have a trust policy that allows MediaPackage to assume the role,
        and it must have sufficient permissions to access the key retrieval URL.

        :stability: experimental
        '''
        result = self._values.get("role")
        assert result is not None, "Required property 'role' is missing"
        return typing.cast("_aws_cdk_aws_iam_ceddda9d.IRole", result)

    @builtins.property
    def url(self) -> builtins.str:
        '''(experimental) URL of the SPEKE key provider.

        :stability: experimental
        '''
        result = self._values.get("url")
        assert result is not None, "Required property 'url' is missing"
        return typing.cast(builtins.str, result)

    @builtins.property
    def audio_preset(self) -> typing.Optional["PresetSpeke20Audio"]:
        '''(experimental) Audio encryption preset.

        :default: PresetSpeke20Audio.PRESET_AUDIO_1

        :stability: experimental
        '''
        result = self._values.get("audio_preset")
        return typing.cast(typing.Optional["PresetSpeke20Audio"], result)

    @builtins.property
    def certificate(
        self,
    ) -> typing.Optional["_aws_cdk_aws_certificatemanager_ceddda9d.ICertificate"]:
        '''(experimental) The ARN of the certificate that you imported to AWS Certificate Manager to add content key encryption to this endpoint.

        For this feature to work, your DRM key provider must support content key encryption.

        :default: - no content key encryption

        :stability: experimental
        '''
        result = self._values.get("certificate")
        return typing.cast(typing.Optional["_aws_cdk_aws_certificatemanager_ceddda9d.ICertificate"], result)

    @builtins.property
    def constant_initialization_vector(self) -> typing.Optional[builtins.str]:
        '''(experimental) Constant initialization vector (32-character hex string).

        A 128-bit, 16-byte hex value represented by a 32-character string,
        used in conjunction with the key for encrypting content.

        :default: - MediaPackage generates the IV

        :stability: experimental
        '''
        result = self._values.get("constant_initialization_vector")
        return typing.cast(typing.Optional[builtins.str], result)

    @builtins.property
    def exclude_segment_drm_metadata(self) -> typing.Optional[builtins.bool]:
        '''(experimental) When enabled, DRM metadata is excluded from CMAF segments.

        :default: false

        :stability: experimental
        '''
        result = self._values.get("exclude_segment_drm_metadata")
        return typing.cast(typing.Optional[builtins.bool], result)

    @builtins.property
    def key_rotation_interval(self) -> typing.Optional["_aws_cdk_ceddda9d.Duration"]:
        '''(experimental) Key rotation interval.

        :default: - no rotation

        :stability: experimental
        '''
        result = self._values.get("key_rotation_interval")
        return typing.cast(typing.Optional["_aws_cdk_ceddda9d.Duration"], result)

    @builtins.property
    def video_preset(self) -> typing.Optional["PresetSpeke20Video"]:
        '''(experimental) Video encryption preset.

        :default: PresetSpeke20Video.PRESET_VIDEO_1

        :stability: experimental
        '''
        result = self._values.get("video_preset")
        return typing.cast(typing.Optional["PresetSpeke20Video"], result)

    def __eq__(self, rhs: typing.Any) -> builtins.bool:
        return isinstance(rhs, self.__class__) and rhs._values == self._values

    def __ne__(self, rhs: typing.Any) -> builtins.bool:
        return not (rhs == self)

    def __repr__(self) -> str:
        return "CmafSpekeEncryptionProps(%s)" % ", ".join(
            k + "=" + repr(v) for k, v in self._values.items()
        )


@jsii.enum(jsii_type="@aws-cdk/aws-mediapackagev2-alpha.ContainerType")
class ContainerType(enum.Enum):
    '''(experimental) The type of container to attach to this origin endpoint.

    A container type is a file format that encapsulates one or more media streams, such as audio and video, into a single file. You can't change the container type after you create the endpoint.

    :stability: experimental
    '''

    TS = "TS"
    '''(experimental) TS Container Type.

    :stability: experimental
    '''
    CMAF = "CMAF"
    '''(experimental) CMAF Container Type.

    :stability: experimental
    '''
    ISM = "ISM"
    '''(experimental) ISM Container Type (Microsoft Smooth Streaming).

    :stability: experimental
    '''


@jsii.data_type(
    jsii_type="@aws-cdk/aws-mediapackagev2-alpha.DashBaseUrlProperty",
    jsii_struct_bases=[],
    name_mapping={
        "url": "url",
        "dvb_priority": "dvbPriority",
        "dvb_weight": "dvbWeight",
        "service_location": "serviceLocation",
    },
)
class DashBaseUrlProperty:
    def __init__(
        self,
        *,
        url: builtins.str,
        dvb_priority: typing.Optional[jsii.Number] = None,
        dvb_weight: typing.Optional[jsii.Number] = None,
        service_location: typing.Optional[builtins.str] = None,
    ) -> None:
        '''(experimental) The base URLs to use for retrieving segments.

        You can specify multiple locations and indicate the
        priority and weight for when each should be used, for use in multi-CDN workflows.

        :param url: (experimental) A source location for segments.
        :param dvb_priority: (experimental) For use with DVB-DASH profiles only. The priority of this location for serving segments. The lower the number, the higher the priority. Default: - No priority specified
        :param dvb_weight: (experimental) For use with DVB-DASH profiles only. The weighting for source locations that have the same priority. Default: - No weight specified
        :param service_location: (experimental) The name of the source location. Default: - No service location specified

        :stability: experimental
        :exampleMetadata: fixture=_generated

        Example::

            # The code below shows an example of how to instantiate this type.
            # The values are placeholders you should change.
            import aws_cdk.aws_mediapackagev2_alpha as mediapackagev2_alpha
            
            dash_base_url_property = mediapackagev2_alpha.DashBaseUrlProperty(
                url="url",
            
                # the properties below are optional
                dvb_priority=123,
                dvb_weight=123,
                service_location="serviceLocation"
            )
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__d69902f67d72b90ff1e2a8bc1c45e19b801c769512caab71f0ae8880e9c69959)
            check_type(argname="argument url", value=url, expected_type=type_hints["url"])
            check_type(argname="argument dvb_priority", value=dvb_priority, expected_type=type_hints["dvb_priority"])
            check_type(argname="argument dvb_weight", value=dvb_weight, expected_type=type_hints["dvb_weight"])
            check_type(argname="argument service_location", value=service_location, expected_type=type_hints["service_location"])
        self._values: typing.Dict[builtins.str, typing.Any] = {
            "url": url,
        }
        if dvb_priority is not None:
            self._values["dvb_priority"] = dvb_priority
        if dvb_weight is not None:
            self._values["dvb_weight"] = dvb_weight
        if service_location is not None:
            self._values["service_location"] = service_location

    @builtins.property
    def url(self) -> builtins.str:
        '''(experimental) A source location for segments.

        :stability: experimental
        '''
        result = self._values.get("url")
        assert result is not None, "Required property 'url' is missing"
        return typing.cast(builtins.str, result)

    @builtins.property
    def dvb_priority(self) -> typing.Optional[jsii.Number]:
        '''(experimental) For use with DVB-DASH profiles only.

        The priority of this location for serving segments. The lower the number, the higher the priority.

        :default: - No priority specified

        :stability: experimental
        '''
        result = self._values.get("dvb_priority")
        return typing.cast(typing.Optional[jsii.Number], result)

    @builtins.property
    def dvb_weight(self) -> typing.Optional[jsii.Number]:
        '''(experimental) For use with DVB-DASH profiles only.

        The weighting for source locations that have the same priority.

        :default: - No weight specified

        :stability: experimental
        '''
        result = self._values.get("dvb_weight")
        return typing.cast(typing.Optional[jsii.Number], result)

    @builtins.property
    def service_location(self) -> typing.Optional[builtins.str]:
        '''(experimental) The name of the source location.

        :default: - No service location specified

        :stability: experimental
        '''
        result = self._values.get("service_location")
        return typing.cast(typing.Optional[builtins.str], result)

    def __eq__(self, rhs: typing.Any) -> builtins.bool:
        return isinstance(rhs, self.__class__) and rhs._values == self._values

    def __ne__(self, rhs: typing.Any) -> builtins.bool:
        return not (rhs == self)

    def __repr__(self) -> str:
        return "DashBaseUrlProperty(%s)" % ", ".join(
            k + "=" + repr(v) for k, v in self._values.items()
        )


@jsii.data_type(
    jsii_type="@aws-cdk/aws-mediapackagev2-alpha.DashDvbFontDownload",
    jsii_struct_bases=[],
    name_mapping={"font_family": "fontFamily", "mime_type": "mimeType", "url": "url"},
)
class DashDvbFontDownload:
    def __init__(
        self,
        *,
        font_family: typing.Optional[builtins.str] = None,
        mime_type: typing.Optional[builtins.str] = None,
        url: typing.Optional[builtins.str] = None,
    ) -> None:
        '''(experimental) For use with DVB-DASH profiles only.

        The settings for font downloads that you want AWS Elemental MediaPackage to pass through to the manifest.

        :param font_family: (experimental) The fontFamily name for subtitles, as described in EBU-TT-D Subtitling Distribution Format. Default: - No font family specified
        :param mime_type: (experimental) The mimeType of the resource that's at the font download URL. For information about font MIME types, see the MPEG-DASH Profile for Transport of ISO BMFF Based DVB Services over IP Based Networks document. Default: - No MIME type specified
        :param url: (experimental) The URL for downloading fonts for subtitles. Default: - No font download URL specified

        :stability: experimental
        :exampleMetadata: fixture=_generated

        Example::

            # The code below shows an example of how to instantiate this type.
            # The values are placeholders you should change.
            import aws_cdk.aws_mediapackagev2_alpha as mediapackagev2_alpha
            
            dash_dvb_font_download = mediapackagev2_alpha.DashDvbFontDownload(
                font_family="fontFamily",
                mime_type="mimeType",
                url="url"
            )
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__4902792404c08d765cbdd683174e2e5354bb7e6ac3caa5962e07d99362ef381b)
            check_type(argname="argument font_family", value=font_family, expected_type=type_hints["font_family"])
            check_type(argname="argument mime_type", value=mime_type, expected_type=type_hints["mime_type"])
            check_type(argname="argument url", value=url, expected_type=type_hints["url"])
        self._values: typing.Dict[builtins.str, typing.Any] = {}
        if font_family is not None:
            self._values["font_family"] = font_family
        if mime_type is not None:
            self._values["mime_type"] = mime_type
        if url is not None:
            self._values["url"] = url

    @builtins.property
    def font_family(self) -> typing.Optional[builtins.str]:
        '''(experimental) The fontFamily name for subtitles, as described in EBU-TT-D Subtitling Distribution Format.

        :default: - No font family specified

        :stability: experimental
        :external: https://tech.ebu.ch/publications/tech3380
        '''
        result = self._values.get("font_family")
        return typing.cast(typing.Optional[builtins.str], result)

    @builtins.property
    def mime_type(self) -> typing.Optional[builtins.str]:
        '''(experimental) The mimeType of the resource that's at the font download URL.

        For information about font MIME types, see the MPEG-DASH Profile for Transport of ISO BMFF Based DVB Services over IP Based Networks document.

        :default: - No MIME type specified

        :stability: experimental
        :external: https://dvb.org/wp-content/uploads/2021/06/A168r4_MPEG-DASH-Profile-for-Transport-of-ISO-BMFF-Based-DVB-Services_Draft-ts_103-285-v140_November_2021.pdf
        '''
        result = self._values.get("mime_type")
        return typing.cast(typing.Optional[builtins.str], result)

    @builtins.property
    def url(self) -> typing.Optional[builtins.str]:
        '''(experimental) The URL for downloading fonts for subtitles.

        :default: - No font download URL specified

        :stability: experimental
        '''
        result = self._values.get("url")
        return typing.cast(typing.Optional[builtins.str], result)

    def __eq__(self, rhs: typing.Any) -> builtins.bool:
        return isinstance(rhs, self.__class__) and rhs._values == self._values

    def __ne__(self, rhs: typing.Any) -> builtins.bool:
        return not (rhs == self)

    def __repr__(self) -> str:
        return "DashDvbFontDownload(%s)" % ", ".join(
            k + "=" + repr(v) for k, v in self._values.items()
        )


@jsii.data_type(
    jsii_type="@aws-cdk/aws-mediapackagev2-alpha.DashDvbMetricsReporting",
    jsii_struct_bases=[],
    name_mapping={"reporting_url": "reportingUrl", "probability": "probability"},
)
class DashDvbMetricsReporting:
    def __init__(
        self,
        *,
        reporting_url: builtins.str,
        probability: typing.Optional[jsii.Number] = None,
    ) -> None:
        '''(experimental) For use with DVB-DASH profiles only.

        The settings for error reporting from the playback device
        that you want AWS Elemental MediaPackage to pass through to the manifest.

        :param reporting_url: (experimental) The URL where playback devices send error reports.
        :param probability: (experimental) The number of playback devices per 1000 that will send error reports to the reporting URL. This represents the probability that a playback device will be a reporting player for this session. Default: - No probability specified

        :stability: experimental
        :exampleMetadata: fixture=_generated

        Example::

            # The code below shows an example of how to instantiate this type.
            # The values are placeholders you should change.
            import aws_cdk.aws_mediapackagev2_alpha as mediapackagev2_alpha
            
            dash_dvb_metrics_reporting = mediapackagev2_alpha.DashDvbMetricsReporting(
                reporting_url="reportingUrl",
            
                # the properties below are optional
                probability=123
            )
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__93abcf86ab112966176778b60cd77dddc0ce7bebf298937991207cc8a91b8a4f)
            check_type(argname="argument reporting_url", value=reporting_url, expected_type=type_hints["reporting_url"])
            check_type(argname="argument probability", value=probability, expected_type=type_hints["probability"])
        self._values: typing.Dict[builtins.str, typing.Any] = {
            "reporting_url": reporting_url,
        }
        if probability is not None:
            self._values["probability"] = probability

    @builtins.property
    def reporting_url(self) -> builtins.str:
        '''(experimental) The URL where playback devices send error reports.

        :stability: experimental
        '''
        result = self._values.get("reporting_url")
        assert result is not None, "Required property 'reporting_url' is missing"
        return typing.cast(builtins.str, result)

    @builtins.property
    def probability(self) -> typing.Optional[jsii.Number]:
        '''(experimental) The number of playback devices per 1000 that will send error reports to the reporting URL.

        This represents the probability that a playback device will be a reporting player for this session.

        :default: - No probability specified

        :stability: experimental
        '''
        result = self._values.get("probability")
        return typing.cast(typing.Optional[jsii.Number], result)

    def __eq__(self, rhs: typing.Any) -> builtins.bool:
        return isinstance(rhs, self.__class__) and rhs._values == self._values

    def __ne__(self, rhs: typing.Any) -> builtins.bool:
        return not (rhs == self)

    def __repr__(self) -> str:
        return "DashDvbMetricsReporting(%s)" % ", ".join(
            k + "=" + repr(v) for k, v in self._values.items()
        )


@jsii.data_type(
    jsii_type="@aws-cdk/aws-mediapackagev2-alpha.DashDvbSettings",
    jsii_struct_bases=[],
    name_mapping={"error_metrics": "errorMetrics", "font_download": "fontDownload"},
)
class DashDvbSettings:
    def __init__(
        self,
        *,
        error_metrics: typing.Optional[typing.Sequence[typing.Union["DashDvbMetricsReporting", typing.Dict[builtins.str, typing.Any]]]] = None,
        font_download: typing.Optional[typing.Union["DashDvbFontDownload", typing.Dict[builtins.str, typing.Any]]] = None,
    ) -> None:
        '''(experimental) The font download and error reporting information that you want MediaPackage to pass through to the manifest.

        :param error_metrics: (experimental) Playback device error reporting settings. Default: - No error metrics configured
        :param font_download: (experimental) Subtitle font settings. Default: - No font download configured

        :stability: experimental
        :exampleMetadata: fixture=_generated

        Example::

            # The code below shows an example of how to instantiate this type.
            # The values are placeholders you should change.
            import aws_cdk.aws_mediapackagev2_alpha as mediapackagev2_alpha
            
            dash_dvb_settings = mediapackagev2_alpha.DashDvbSettings(
                error_metrics=[mediapackagev2_alpha.DashDvbMetricsReporting(
                    reporting_url="reportingUrl",
            
                    # the properties below are optional
                    probability=123
                )],
                font_download=mediapackagev2_alpha.DashDvbFontDownload(
                    font_family="fontFamily",
                    mime_type="mimeType",
                    url="url"
                )
            )
        '''
        if isinstance(font_download, dict):
            font_download = DashDvbFontDownload(**font_download)
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__6bcd887c45dafe0b485ae1896e59921eab98690114f1f5b45431149620fbb444)
            check_type(argname="argument error_metrics", value=error_metrics, expected_type=type_hints["error_metrics"])
            check_type(argname="argument font_download", value=font_download, expected_type=type_hints["font_download"])
        self._values: typing.Dict[builtins.str, typing.Any] = {}
        if error_metrics is not None:
            self._values["error_metrics"] = error_metrics
        if font_download is not None:
            self._values["font_download"] = font_download

    @builtins.property
    def error_metrics(self) -> typing.Optional[typing.List["DashDvbMetricsReporting"]]:
        '''(experimental) Playback device error reporting settings.

        :default: - No error metrics configured

        :stability: experimental
        '''
        result = self._values.get("error_metrics")
        return typing.cast(typing.Optional[typing.List["DashDvbMetricsReporting"]], result)

    @builtins.property
    def font_download(self) -> typing.Optional["DashDvbFontDownload"]:
        '''(experimental) Subtitle font settings.

        :default: - No font download configured

        :stability: experimental
        '''
        result = self._values.get("font_download")
        return typing.cast(typing.Optional["DashDvbFontDownload"], result)

    def __eq__(self, rhs: typing.Any) -> builtins.bool:
        return isinstance(rhs, self.__class__) and rhs._values == self._values

    def __ne__(self, rhs: typing.Any) -> builtins.bool:
        return not (rhs == self)

    def __repr__(self) -> str:
        return "DashDvbSettings(%s)" % ", ".join(
            k + "=" + repr(v) for k, v in self._values.items()
        )


@jsii.enum(jsii_type="@aws-cdk/aws-mediapackagev2-alpha.DashManifestCompactness")
class DashManifestCompactness(enum.Enum):
    '''(experimental) STANDARD indicates a default manifest, which is compacted.

    NONE indicates a full manifest.

    :stability: experimental
    '''

    STANDARD = "STANDARD"
    '''(experimental) STANDARD.

    :stability: experimental
    '''
    NONE = "NONE"
    '''(experimental) NONE.

    :stability: experimental
    '''


@jsii.data_type(
    jsii_type="@aws-cdk/aws-mediapackagev2-alpha.DashManifestConfiguration",
    jsii_struct_bases=[],
    name_mapping={
        "manifest_name": "manifestName",
        "base_urls": "baseUrls",
        "compactness": "compactness",
        "drm_signalling": "drmSignalling",
        "dvb_settings": "dvbSettings",
        "filter_configuration": "filterConfiguration",
        "manifest_window": "manifestWindow",
        "min_buffer_time": "minBufferTime",
        "min_update_period": "minUpdatePeriod",
        "period_triggers": "periodTriggers",
        "profiles": "profiles",
        "program_information": "programInformation",
        "scte_dash_ad_marker": "scteDashAdMarker",
        "segment_template_format": "segmentTemplateFormat",
        "subtitle_configuration": "subtitleConfiguration",
        "suggested_presentation_delay": "suggestedPresentationDelay",
        "utc_timing_mode": "utcTimingMode",
        "utc_timing_source": "utcTimingSource",
    },
)
class DashManifestConfiguration:
    def __init__(
        self,
        *,
        manifest_name: builtins.str,
        base_urls: typing.Optional[typing.Sequence[typing.Union["DashBaseUrlProperty", typing.Dict[builtins.str, typing.Any]]]] = None,
        compactness: typing.Optional["DashManifestCompactness"] = None,
        drm_signalling: typing.Optional["DrmSignalling"] = None,
        dvb_settings: typing.Optional[typing.Union["DashDvbSettings", typing.Dict[builtins.str, typing.Any]]] = None,
        filter_configuration: typing.Optional[typing.Union["FilterConfiguration", typing.Dict[builtins.str, typing.Any]]] = None,
        manifest_window: typing.Optional["_aws_cdk_ceddda9d.Duration"] = None,
        min_buffer_time: typing.Optional["_aws_cdk_ceddda9d.Duration"] = None,
        min_update_period: typing.Optional["_aws_cdk_ceddda9d.Duration"] = None,
        period_triggers: typing.Optional[typing.Sequence["DashPeriodTriggers"]] = None,
        profiles: typing.Optional[typing.Sequence[builtins.str]] = None,
        program_information: typing.Optional[typing.Union["DashProgramInformation", typing.Dict[builtins.str, typing.Any]]] = None,
        scte_dash_ad_marker: typing.Optional["AdMarkerDash"] = None,
        segment_template_format: typing.Optional["SegmentTemplateFormat"] = None,
        subtitle_configuration: typing.Optional[typing.Union["DashSubtitleConfiguration", typing.Dict[builtins.str, typing.Any]]] = None,
        suggested_presentation_delay: typing.Optional["_aws_cdk_ceddda9d.Duration"] = None,
        utc_timing_mode: typing.Optional["DashUtcTimingMode"] = None,
        utc_timing_source: typing.Optional[builtins.str] = None,
    ) -> None:
        '''(experimental) The DASH manifest configuration associated with the origin endpoint.

        :param manifest_name: (experimental) The name of the manifest associated with the DASH manifest configuration.
        :param base_urls: (experimental) The base URLs to use for retrieving segments. Default: - No base URLs specified
        :param compactness: (experimental) The layout of the DASH manifest that MediaPackage produces. Default: DashManifestCompactness.STANDARD
        :param drm_signalling: (experimental) DRM signaling determines the way DASH manifest signals the DRM content. Default: - No DRM signaling specified
        :param dvb_settings: (experimental) For endpoints that use the DVB-DASH profile only. Default: - No DVB settings
        :param filter_configuration: (experimental) Filter configuration includes settings for manifest filtering, start and end times, and time delay that apply to all of your egress requests for this manifest. https://docs.aws.amazon.com/mediapackage/latest/userguide/manifest-filter-query-parameters.html Default: - No filter configuration
        :param manifest_window: (experimental) The total duration (in seconds) of the manifest's content. Default: 60
        :param min_buffer_time: (experimental) The minimum amount of content that the player must keep available in the buffer. Default: 5
        :param min_update_period: (experimental) The minimum amount of time for the player to wait before requesting an updated manifest. Default: 2
        :param period_triggers: (experimental) Specify what triggers cause AWS Elemental MediaPackage to create media presentation description (MPD) periods in the output manifest. Default: [DashPeriodTriggers.AVAILS, DashPeriodTriggers.DRM_KEY_ROTATION, DashPeriodTriggers.SOURCE_CHANGES, DashPeriodTriggers.SOURCE_DISRUPTIONS]
        :param profiles: (experimental) The profile that the output is compliant with. Default: - No profiles specified
        :param program_information: (experimental) Details about the content that you want MediaPackage to pass through in the manifest to the playback device. Default: - No program information
        :param scte_dash_ad_marker: (experimental) Choose how ad markers are included in the packaged content. If you include ad markers in the content stream in your upstream encoders, then you need to inform MediaPackage what to do with the ad markers in the output. To choose this option STCE filtering needs to be enabled. Default: AdMarkerDash.XML
        :param segment_template_format: (experimental) The type of variable that MediaPackage uses in the media attribute of the SegmentTemplate tag. Default: SegmentTemplateFormat.NUMBER_WITH_TIMELINE
        :param subtitle_configuration: (experimental) The configuration for DASH subtitles. Default: - No subtitle configuration
        :param suggested_presentation_delay: (experimental) The amount of time that the player should be from the end of the manifest. Default: 10
        :param utc_timing_mode: (experimental) The UTC timing mode. Default: DashUtcTimingMode.UTC_DIRECT
        :param utc_timing_source: (experimental) The method that the player uses to synchronize to coordinated universal time (UTC) wall clock time. Default: undefined - No value is specified

        :stability: experimental
        :exampleMetadata: infused

        Example::

            # channel: Channel
            
            
            OriginEndpoint(self, "Endpoint",
                channel=channel,
                segment=Segment.cmaf(),
                manifests=[
                    Manifest.dash(
                        manifest_name="index",
                        manifest_window=Duration.seconds(60),
                        min_buffer_time=Duration.seconds(30),
                        min_update_period=Duration.seconds(10),
                        segment_template_format=SegmentTemplateFormat.NUMBER_WITH_TIMELINE,
                        period_triggers=[DashPeriodTriggers.AVAILS, DashPeriodTriggers.DRM_KEY_ROTATION
                        ]
                    )
                ]
            )
        '''
        if isinstance(dvb_settings, dict):
            dvb_settings = DashDvbSettings(**dvb_settings)
        if isinstance(filter_configuration, dict):
            filter_configuration = FilterConfiguration(**filter_configuration)
        if isinstance(program_information, dict):
            program_information = DashProgramInformation(**program_information)
        if isinstance(subtitle_configuration, dict):
            subtitle_configuration = DashSubtitleConfiguration(**subtitle_configuration)
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__59c9ba2facf8e573eada8862e4949af76c325c7a39c154870da8b761c4b8e572)
            check_type(argname="argument manifest_name", value=manifest_name, expected_type=type_hints["manifest_name"])
            check_type(argname="argument base_urls", value=base_urls, expected_type=type_hints["base_urls"])
            check_type(argname="argument compactness", value=compactness, expected_type=type_hints["compactness"])
            check_type(argname="argument drm_signalling", value=drm_signalling, expected_type=type_hints["drm_signalling"])
            check_type(argname="argument dvb_settings", value=dvb_settings, expected_type=type_hints["dvb_settings"])
            check_type(argname="argument filter_configuration", value=filter_configuration, expected_type=type_hints["filter_configuration"])
            check_type(argname="argument manifest_window", value=manifest_window, expected_type=type_hints["manifest_window"])
            check_type(argname="argument min_buffer_time", value=min_buffer_time, expected_type=type_hints["min_buffer_time"])
            check_type(argname="argument min_update_period", value=min_update_period, expected_type=type_hints["min_update_period"])
            check_type(argname="argument period_triggers", value=period_triggers, expected_type=type_hints["period_triggers"])
            check_type(argname="argument profiles", value=profiles, expected_type=type_hints["profiles"])
            check_type(argname="argument program_information", value=program_information, expected_type=type_hints["program_information"])
            check_type(argname="argument scte_dash_ad_marker", value=scte_dash_ad_marker, expected_type=type_hints["scte_dash_ad_marker"])
            check_type(argname="argument segment_template_format", value=segment_template_format, expected_type=type_hints["segment_template_format"])
            check_type(argname="argument subtitle_configuration", value=subtitle_configuration, expected_type=type_hints["subtitle_configuration"])
            check_type(argname="argument suggested_presentation_delay", value=suggested_presentation_delay, expected_type=type_hints["suggested_presentation_delay"])
            check_type(argname="argument utc_timing_mode", value=utc_timing_mode, expected_type=type_hints["utc_timing_mode"])
            check_type(argname="argument utc_timing_source", value=utc_timing_source, expected_type=type_hints["utc_timing_source"])
        self._values: typing.Dict[builtins.str, typing.Any] = {
            "manifest_name": manifest_name,
        }
        if base_urls is not None:
            self._values["base_urls"] = base_urls
        if compactness is not None:
            self._values["compactness"] = compactness
        if drm_signalling is not None:
            self._values["drm_signalling"] = drm_signalling
        if dvb_settings is not None:
            self._values["dvb_settings"] = dvb_settings
        if filter_configuration is not None:
            self._values["filter_configuration"] = filter_configuration
        if manifest_window is not None:
            self._values["manifest_window"] = manifest_window
        if min_buffer_time is not None:
            self._values["min_buffer_time"] = min_buffer_time
        if min_update_period is not None:
            self._values["min_update_period"] = min_update_period
        if period_triggers is not None:
            self._values["period_triggers"] = period_triggers
        if profiles is not None:
            self._values["profiles"] = profiles
        if program_information is not None:
            self._values["program_information"] = program_information
        if scte_dash_ad_marker is not None:
            self._values["scte_dash_ad_marker"] = scte_dash_ad_marker
        if segment_template_format is not None:
            self._values["segment_template_format"] = segment_template_format
        if subtitle_configuration is not None:
            self._values["subtitle_configuration"] = subtitle_configuration
        if suggested_presentation_delay is not None:
            self._values["suggested_presentation_delay"] = suggested_presentation_delay
        if utc_timing_mode is not None:
            self._values["utc_timing_mode"] = utc_timing_mode
        if utc_timing_source is not None:
            self._values["utc_timing_source"] = utc_timing_source

    @builtins.property
    def manifest_name(self) -> builtins.str:
        '''(experimental) The name of the manifest associated with the DASH manifest configuration.

        :stability: experimental
        '''
        result = self._values.get("manifest_name")
        assert result is not None, "Required property 'manifest_name' is missing"
        return typing.cast(builtins.str, result)

    @builtins.property
    def base_urls(self) -> typing.Optional[typing.List["DashBaseUrlProperty"]]:
        '''(experimental) The base URLs to use for retrieving segments.

        :default: - No base URLs specified

        :stability: experimental
        '''
        result = self._values.get("base_urls")
        return typing.cast(typing.Optional[typing.List["DashBaseUrlProperty"]], result)

    @builtins.property
    def compactness(self) -> typing.Optional["DashManifestCompactness"]:
        '''(experimental) The layout of the DASH manifest that MediaPackage produces.

        :default: DashManifestCompactness.STANDARD

        :stability: experimental
        '''
        result = self._values.get("compactness")
        return typing.cast(typing.Optional["DashManifestCompactness"], result)

    @builtins.property
    def drm_signalling(self) -> typing.Optional["DrmSignalling"]:
        '''(experimental) DRM signaling determines the way DASH manifest signals the DRM content.

        :default: - No DRM signaling specified

        :stability: experimental
        '''
        result = self._values.get("drm_signalling")
        return typing.cast(typing.Optional["DrmSignalling"], result)

    @builtins.property
    def dvb_settings(self) -> typing.Optional["DashDvbSettings"]:
        '''(experimental) For endpoints that use the DVB-DASH profile only.

        :default: - No DVB settings

        :stability: experimental
        '''
        result = self._values.get("dvb_settings")
        return typing.cast(typing.Optional["DashDvbSettings"], result)

    @builtins.property
    def filter_configuration(self) -> typing.Optional["FilterConfiguration"]:
        '''(experimental) Filter configuration includes settings for manifest filtering, start and end times, and time delay that apply to all of your egress requests for this manifest.

        https://docs.aws.amazon.com/mediapackage/latest/userguide/manifest-filter-query-parameters.html

        :default: - No filter configuration

        :stability: experimental
        '''
        result = self._values.get("filter_configuration")
        return typing.cast(typing.Optional["FilterConfiguration"], result)

    @builtins.property
    def manifest_window(self) -> typing.Optional["_aws_cdk_ceddda9d.Duration"]:
        '''(experimental) The total duration (in seconds) of the manifest's content.

        :default: 60

        :stability: experimental
        '''
        result = self._values.get("manifest_window")
        return typing.cast(typing.Optional["_aws_cdk_ceddda9d.Duration"], result)

    @builtins.property
    def min_buffer_time(self) -> typing.Optional["_aws_cdk_ceddda9d.Duration"]:
        '''(experimental) The minimum amount of content that the player must keep available in the buffer.

        :default: 5

        :stability: experimental
        '''
        result = self._values.get("min_buffer_time")
        return typing.cast(typing.Optional["_aws_cdk_ceddda9d.Duration"], result)

    @builtins.property
    def min_update_period(self) -> typing.Optional["_aws_cdk_ceddda9d.Duration"]:
        '''(experimental) The minimum amount of time for the player to wait before requesting an updated manifest.

        :default: 2

        :stability: experimental
        '''
        result = self._values.get("min_update_period")
        return typing.cast(typing.Optional["_aws_cdk_ceddda9d.Duration"], result)

    @builtins.property
    def period_triggers(self) -> typing.Optional[typing.List["DashPeriodTriggers"]]:
        '''(experimental) Specify what triggers cause AWS Elemental MediaPackage to create media presentation description (MPD) periods in the output manifest.

        :default: [DashPeriodTriggers.AVAILS, DashPeriodTriggers.DRM_KEY_ROTATION, DashPeriodTriggers.SOURCE_CHANGES, DashPeriodTriggers.SOURCE_DISRUPTIONS]

        :stability: experimental
        '''
        result = self._values.get("period_triggers")
        return typing.cast(typing.Optional[typing.List["DashPeriodTriggers"]], result)

    @builtins.property
    def profiles(self) -> typing.Optional[typing.List[builtins.str]]:
        '''(experimental) The profile that the output is compliant with.

        :default: - No profiles specified

        :stability: experimental
        '''
        result = self._values.get("profiles")
        return typing.cast(typing.Optional[typing.List[builtins.str]], result)

    @builtins.property
    def program_information(self) -> typing.Optional["DashProgramInformation"]:
        '''(experimental) Details about the content that you want MediaPackage to pass through in the manifest to the playback device.

        :default: - No program information

        :stability: experimental
        '''
        result = self._values.get("program_information")
        return typing.cast(typing.Optional["DashProgramInformation"], result)

    @builtins.property
    def scte_dash_ad_marker(self) -> typing.Optional["AdMarkerDash"]:
        '''(experimental) Choose how ad markers are included in the packaged content.

        If you include ad markers in the content stream in your upstream encoders,
        then you need to inform MediaPackage what to do with the ad markers in the output.

        To choose this option STCE filtering needs to be enabled.

        :default: AdMarkerDash.XML

        :stability: experimental
        '''
        result = self._values.get("scte_dash_ad_marker")
        return typing.cast(typing.Optional["AdMarkerDash"], result)

    @builtins.property
    def segment_template_format(self) -> typing.Optional["SegmentTemplateFormat"]:
        '''(experimental) The type of variable that MediaPackage uses in the media attribute of the SegmentTemplate tag.

        :default: SegmentTemplateFormat.NUMBER_WITH_TIMELINE

        :stability: experimental
        '''
        result = self._values.get("segment_template_format")
        return typing.cast(typing.Optional["SegmentTemplateFormat"], result)

    @builtins.property
    def subtitle_configuration(self) -> typing.Optional["DashSubtitleConfiguration"]:
        '''(experimental) The configuration for DASH subtitles.

        :default: - No subtitle configuration

        :stability: experimental
        '''
        result = self._values.get("subtitle_configuration")
        return typing.cast(typing.Optional["DashSubtitleConfiguration"], result)

    @builtins.property
    def suggested_presentation_delay(
        self,
    ) -> typing.Optional["_aws_cdk_ceddda9d.Duration"]:
        '''(experimental) The amount of time that the player should be from the end of the manifest.

        :default: 10

        :stability: experimental
        '''
        result = self._values.get("suggested_presentation_delay")
        return typing.cast(typing.Optional["_aws_cdk_ceddda9d.Duration"], result)

    @builtins.property
    def utc_timing_mode(self) -> typing.Optional["DashUtcTimingMode"]:
        '''(experimental) The UTC timing mode.

        :default: DashUtcTimingMode.UTC_DIRECT

        :stability: experimental
        '''
        result = self._values.get("utc_timing_mode")
        return typing.cast(typing.Optional["DashUtcTimingMode"], result)

    @builtins.property
    def utc_timing_source(self) -> typing.Optional[builtins.str]:
        '''(experimental) The method that the player uses to synchronize to coordinated universal time (UTC) wall clock time.

        :default: undefined - No value is specified

        :stability: experimental
        '''
        result = self._values.get("utc_timing_source")
        return typing.cast(typing.Optional[builtins.str], result)

    def __eq__(self, rhs: typing.Any) -> builtins.bool:
        return isinstance(rhs, self.__class__) and rhs._values == self._values

    def __ne__(self, rhs: typing.Any) -> builtins.bool:
        return not (rhs == self)

    def __repr__(self) -> str:
        return "DashManifestConfiguration(%s)" % ", ".join(
            k + "=" + repr(v) for k, v in self._values.items()
        )


@jsii.enum(jsii_type="@aws-cdk/aws-mediapackagev2-alpha.DashPeriodTriggers")
class DashPeriodTriggers(enum.Enum):
    '''(experimental) Options for triggers which cause AWS Elemental MediaPackage to create media presentation description (MPD) periods in the output manifest.

    :stability: experimental
    '''

    AVAILS = "AVAILS"
    '''(experimental) Option for AVAILS.

    :stability: experimental
    '''
    DRM_KEY_ROTATION = "DRM_KEY_ROTATION"
    '''(experimental) Option for DRM_KEY_ROTATION.

    :stability: experimental
    '''
    SOURCE_CHANGES = "SOURCE_CHANGES"
    '''(experimental) Option for SOURCE_CHANGES.

    :stability: experimental
    '''
    SOURCE_DISRUPTIONS = "SOURCE_DISRUPTIONS"
    '''(experimental) Option for SOURCE_DISRUPTIONS.

    :stability: experimental
    '''
    NONE = "NONE"
    '''(experimental) Option for NONE.

    :stability: experimental
    '''


@jsii.data_type(
    jsii_type="@aws-cdk/aws-mediapackagev2-alpha.DashProgramInformation",
    jsii_struct_bases=[],
    name_mapping={
        "copyright": "copyright",
        "language_code": "languageCode",
        "more_information_url": "moreInformationUrl",
        "source": "source",
        "title": "title",
    },
)
class DashProgramInformation:
    def __init__(
        self,
        *,
        copyright: typing.Optional[builtins.str] = None,
        language_code: typing.Optional[builtins.str] = None,
        more_information_url: typing.Optional[builtins.str] = None,
        source: typing.Optional[builtins.str] = None,
        title: typing.Optional[builtins.str] = None,
    ) -> None:
        '''(experimental) Details about the content that you want MediaPackage to pass through in the manifest to the playback device.

        :param copyright: (experimental) A copyright statement about the content. Default: - No copyright information
        :param language_code: (experimental) The language code for this manifest. Default: - No language code specified
        :param more_information_url: (experimental) An absolute URL that contains more information about this content. Default: - No additional information URL
        :param source: (experimental) Information about the content provider. Default: - No source information
        :param title: (experimental) The title for the manifest. Default: - No title specified

        :stability: experimental
        :exampleMetadata: fixture=_generated

        Example::

            # The code below shows an example of how to instantiate this type.
            # The values are placeholders you should change.
            import aws_cdk.aws_mediapackagev2_alpha as mediapackagev2_alpha
            
            dash_program_information = mediapackagev2_alpha.DashProgramInformation(
                copyright="copyright",
                language_code="languageCode",
                more_information_url="moreInformationUrl",
                source="source",
                title="title"
            )
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__c5649f47fbe8678636fdb729138cb6364f9cb05a64a5340b58fe1a651c6add54)
            check_type(argname="argument copyright", value=copyright, expected_type=type_hints["copyright"])
            check_type(argname="argument language_code", value=language_code, expected_type=type_hints["language_code"])
            check_type(argname="argument more_information_url", value=more_information_url, expected_type=type_hints["more_information_url"])
            check_type(argname="argument source", value=source, expected_type=type_hints["source"])
            check_type(argname="argument title", value=title, expected_type=type_hints["title"])
        self._values: typing.Dict[builtins.str, typing.Any] = {}
        if copyright is not None:
            self._values["copyright"] = copyright
        if language_code is not None:
            self._values["language_code"] = language_code
        if more_information_url is not None:
            self._values["more_information_url"] = more_information_url
        if source is not None:
            self._values["source"] = source
        if title is not None:
            self._values["title"] = title

    @builtins.property
    def copyright(self) -> typing.Optional[builtins.str]:
        '''(experimental) A copyright statement about the content.

        :default: - No copyright information

        :stability: experimental
        '''
        result = self._values.get("copyright")
        return typing.cast(typing.Optional[builtins.str], result)

    @builtins.property
    def language_code(self) -> typing.Optional[builtins.str]:
        '''(experimental) The language code for this manifest.

        :default: - No language code specified

        :stability: experimental
        '''
        result = self._values.get("language_code")
        return typing.cast(typing.Optional[builtins.str], result)

    @builtins.property
    def more_information_url(self) -> typing.Optional[builtins.str]:
        '''(experimental) An absolute URL that contains more information about this content.

        :default: - No additional information URL

        :stability: experimental
        '''
        result = self._values.get("more_information_url")
        return typing.cast(typing.Optional[builtins.str], result)

    @builtins.property
    def source(self) -> typing.Optional[builtins.str]:
        '''(experimental) Information about the content provider.

        :default: - No source information

        :stability: experimental
        '''
        result = self._values.get("source")
        return typing.cast(typing.Optional[builtins.str], result)

    @builtins.property
    def title(self) -> typing.Optional[builtins.str]:
        '''(experimental) The title for the manifest.

        :default: - No title specified

        :stability: experimental
        '''
        result = self._values.get("title")
        return typing.cast(typing.Optional[builtins.str], result)

    def __eq__(self, rhs: typing.Any) -> builtins.bool:
        return isinstance(rhs, self.__class__) and rhs._values == self._values

    def __ne__(self, rhs: typing.Any) -> builtins.bool:
        return not (rhs == self)

    def __repr__(self) -> str:
        return "DashProgramInformation(%s)" % ", ".join(
            k + "=" + repr(v) for k, v in self._values.items()
        )


@jsii.data_type(
    jsii_type="@aws-cdk/aws-mediapackagev2-alpha.DashSubtitleConfiguration",
    jsii_struct_bases=[],
    name_mapping={"ttml_configuration": "ttmlConfiguration"},
)
class DashSubtitleConfiguration:
    def __init__(
        self,
        *,
        ttml_configuration: typing.Optional[typing.Union["DashTtmlConfiguration", typing.Dict[builtins.str, typing.Any]]] = None,
    ) -> None:
        '''(experimental) Configuration for subtitles in DASH manifests.

        :param ttml_configuration: (experimental) Settings for TTML subtitles. Default: - No TTML configuration

        :stability: experimental
        :exampleMetadata: fixture=_generated

        Example::

            # The code below shows an example of how to instantiate this type.
            # The values are placeholders you should change.
            import aws_cdk.aws_mediapackagev2_alpha as mediapackagev2_alpha
            
            dash_subtitle_configuration = mediapackagev2_alpha.DashSubtitleConfiguration(
                ttml_configuration=mediapackagev2_alpha.DashTtmlConfiguration(
                    ttml_profile=mediapackagev2_alpha.TtmlProfile.IMSC_1
                )
            )
        '''
        if isinstance(ttml_configuration, dict):
            ttml_configuration = DashTtmlConfiguration(**ttml_configuration)
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__d0f34b7baf12431bdd44ba4ac86b0beef88e32083554c1173c8dffe98c857f42)
            check_type(argname="argument ttml_configuration", value=ttml_configuration, expected_type=type_hints["ttml_configuration"])
        self._values: typing.Dict[builtins.str, typing.Any] = {}
        if ttml_configuration is not None:
            self._values["ttml_configuration"] = ttml_configuration

    @builtins.property
    def ttml_configuration(self) -> typing.Optional["DashTtmlConfiguration"]:
        '''(experimental) Settings for TTML subtitles.

        :default: - No TTML configuration

        :stability: experimental
        '''
        result = self._values.get("ttml_configuration")
        return typing.cast(typing.Optional["DashTtmlConfiguration"], result)

    def __eq__(self, rhs: typing.Any) -> builtins.bool:
        return isinstance(rhs, self.__class__) and rhs._values == self._values

    def __ne__(self, rhs: typing.Any) -> builtins.bool:
        return not (rhs == self)

    def __repr__(self) -> str:
        return "DashSubtitleConfiguration(%s)" % ", ".join(
            k + "=" + repr(v) for k, v in self._values.items()
        )


@jsii.data_type(
    jsii_type="@aws-cdk/aws-mediapackagev2-alpha.DashTtmlConfiguration",
    jsii_struct_bases=[],
    name_mapping={"ttml_profile": "ttmlProfile"},
)
class DashTtmlConfiguration:
    def __init__(self, *, ttml_profile: "TtmlProfile") -> None:
        '''(experimental) Configuration for TTML subtitles in DASH manifests.

        :param ttml_profile: (experimental) The profile that MediaPackage uses when signaling subtitles in the manifest. IMSC is the default profile. EBU-TT-D produces subtitles that are compliant with the EBU-TT-D TTML profile. MediaPackage passes through subtitle styles to the manifest. For more information about EBU-TT-D subtitles, see EBU-TT-D Subtitling Distribution Format.

        :stability: experimental
        :exampleMetadata: fixture=_generated

        Example::

            # The code below shows an example of how to instantiate this type.
            # The values are placeholders you should change.
            import aws_cdk.aws_mediapackagev2_alpha as mediapackagev2_alpha
            
            dash_ttml_configuration = mediapackagev2_alpha.DashTtmlConfiguration(
                ttml_profile=mediapackagev2_alpha.TtmlProfile.IMSC_1
            )
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__cec83b9ced564350a41b7e960ca63a7318ebd4cded1ac3d2642b2e18eef0aa8a)
            check_type(argname="argument ttml_profile", value=ttml_profile, expected_type=type_hints["ttml_profile"])
        self._values: typing.Dict[builtins.str, typing.Any] = {
            "ttml_profile": ttml_profile,
        }

    @builtins.property
    def ttml_profile(self) -> "TtmlProfile":
        '''(experimental) The profile that MediaPackage uses when signaling subtitles in the manifest.

        IMSC is the default profile. EBU-TT-D produces subtitles that are compliant with the EBU-TT-D TTML profile. MediaPackage passes through subtitle styles to the manifest.
        For more information about EBU-TT-D subtitles, see EBU-TT-D Subtitling Distribution Format.

        :stability: experimental
        :external: https://tech.ebu.ch/publications/tech3380
        '''
        result = self._values.get("ttml_profile")
        assert result is not None, "Required property 'ttml_profile' is missing"
        return typing.cast("TtmlProfile", result)

    def __eq__(self, rhs: typing.Any) -> builtins.bool:
        return isinstance(rhs, self.__class__) and rhs._values == self._values

    def __ne__(self, rhs: typing.Any) -> builtins.bool:
        return not (rhs == self)

    def __repr__(self) -> str:
        return "DashTtmlConfiguration(%s)" % ", ".join(
            k + "=" + repr(v) for k, v in self._values.items()
        )


@jsii.enum(jsii_type="@aws-cdk/aws-mediapackagev2-alpha.DashUtcTimingMode")
class DashUtcTimingMode(enum.Enum):
    '''(experimental) The UTC timing mode for DASH.

    :stability: experimental
    '''

    HTTP_HEAD = "HTTP_HEAD"
    '''(experimental) Option for HTTP_HEAD.

    :stability: experimental
    '''
    HTTP_ISO = "HTTP_ISO"
    '''(experimental) Option for HTTP_ISO.

    :stability: experimental
    '''
    HTTP_XSDATE = "HTTP_XSDATE"
    '''(experimental) Option for HTTP_XSDATE.

    :stability: experimental
    '''
    UTC_DIRECT = "UTC_DIRECT"
    '''(experimental) Option for UTC_DIRECT.

    :stability: experimental
    '''


@jsii.enum(jsii_type="@aws-cdk/aws-mediapackagev2-alpha.DrmSettingsKey")
class DrmSettingsKey(enum.Enum):
    '''(experimental) DRM settings keys for manifest filter configuration.

    :stability: experimental
    '''

    EXCLUDE_SESSION_KEYS = "EXCLUDE_SESSION_KEYS"
    '''(experimental) Exclude EXT-X-SESSION-KEY tags from HLS and LL-HLS multivariant playlists.

    This can improve compatibility with legacy HLS clients that have issues
    processing session keys, or provide more granular access control when
    using manifest filtering.

    :stability: experimental
    '''


@jsii.enum(jsii_type="@aws-cdk/aws-mediapackagev2-alpha.DrmSignalling")
class DrmSignalling(enum.Enum):
    '''(experimental) DRM signaling determines the way DASH manifest signals the DRM content.

    :stability: experimental
    '''

    INDIVIDUAL = "INDIVIDUAL"
    '''(experimental) Option for INDIVIDUAL.

    :stability: experimental
    '''
    REFERENCED = "REFERENCED"
    '''(experimental) Option for REFERENCED.

    :stability: experimental
    '''


class EncryptionConfiguration(
    metaclass=jsii.JSIIAbstractClass,
    jsii_type="@aws-cdk/aws-mediapackagev2-alpha.EncryptionConfiguration",
):
    '''(experimental) Base class for encryption configurations.

    Use ``CmafEncryption.speke()``, ``TsEncryption.speke()``, or ``IsmEncryption.speke()`` to create instances.

    :stability: experimental
    '''

    def __init__(self) -> None:
        '''
        :stability: experimental
        '''
        jsii.create(self.__class__, self, [])


class _EncryptionConfigurationProxy(EncryptionConfiguration):
    pass

# Adding a "__jsii_proxy_class__(): typing.Type" function to the abstract class
typing.cast(typing.Any, EncryptionConfiguration).__jsii_proxy_class__ = lambda : _EncryptionConfigurationProxy


@jsii.enum(jsii_type="@aws-cdk/aws-mediapackagev2-alpha.EndpointErrorConfiguration")
class EndpointErrorConfiguration(enum.Enum):
    '''(experimental) Endpoint error configuration options.

    :stability: experimental
    '''

    STALE_MANIFEST = "STALE_MANIFEST"
    '''(experimental) The manifest stalled and there are no new segments or parts.

    :stability: experimental
    '''
    INCOMPLETE_MANIFEST = "INCOMPLETE_MANIFEST"
    '''(experimental) There is a gap in the manifest.

    :stability: experimental
    '''
    MISSING_DRM_KEY = "MISSING_DRM_KEY"
    '''(experimental) Key rotation is enabled but we're unable to fetch the key for the current key period.

    :stability: experimental
    '''
    SLATE_INPUT = "SLATE_INPUT"
    '''(experimental) The segments which contain slate content are considered to be missing content.

    :stability: experimental
    '''


@jsii.data_type(
    jsii_type="@aws-cdk/aws-mediapackagev2-alpha.FilterConfiguration",
    jsii_struct_bases=[],
    name_mapping={
        "clip_start_time": "clipStartTime",
        "drm_settings": "drmSettings",
        "end": "end",
        "manifest_filter": "manifestFilter",
        "start": "start",
        "time_delay": "timeDelay",
    },
)
class FilterConfiguration:
    def __init__(
        self,
        *,
        clip_start_time: typing.Optional[datetime.datetime] = None,
        drm_settings: typing.Optional[typing.Sequence["DrmSettingsKey"]] = None,
        end: typing.Optional[datetime.datetime] = None,
        manifest_filter: typing.Optional[typing.Sequence["ManifestFilter"]] = None,
        start: typing.Optional[datetime.datetime] = None,
        time_delay: typing.Optional["_aws_cdk_ceddda9d.Duration"] = None,
    ) -> None:
        '''(experimental) Filter configuration includes settings for manifest filtering, start and end times, and time delay that apply to all of your egress requests for this manifest.

        :param clip_start_time: (experimental) Optionally specify the clip start time for all of your manifest egress requests. When you include clip start time, note that you cannot use clip start time query parameters for this manifest's endpoint URL. This will be converted to a UTC timestamp. Default: - No clip start time
        :param drm_settings: (experimental) DRM settings for manifest egress requests. When you include a DRM setting, note that you cannot use an identical DRM setting query parameter for this manifest's endpoint URL. Default: - No DRM settings
        :param end: (experimental) Optionally specify the end time for all of your manifest egress requests. When you include end time, note that you cannot use end time query parameters for this manifest's endpoint URL. This will be converted to a UTC timestamp. Default: - No end time
        :param manifest_filter: (experimental) Optionally specify one or more manifest filters for all of your manifest egress requests. When you include a manifest filter, note that you cannot use an identical manifest filter query parameter for this manifest's endpoint URL. Default: - No manifest filters
        :param start: (experimental) Optionally specify the start time for all of your manifest egress requests. When you include start time, note that you cannot use start time query parameters for this manifest's endpoint URL. This will be converted to a UTC timestamp. Default: - No start time
        :param time_delay: (experimental) Optionally specify the time delay for all of your manifest egress requests. Enter a value that is smaller than your endpoint's startover window. When you include time delay, note that you cannot use time delay query parameters for this manifest's endpoint URL. Default: - No time delay

        :stability: experimental
        :exampleMetadata: infused

        Example::

            from aws_cdk.aws_mediapackagev2_alpha import FilterConfiguration
            # channel: Channel
            
            
            OriginEndpoint(self, "Endpoint",
                channel=channel,
                segment=Segment.cmaf(),
                manifests=[
                    Manifest.hls(
                        manifest_name="index",
                        filter_configuration=FilterConfiguration(
                            manifest_filter=[
                                # video_height:240-360,720-1080,1440
                                ManifestFilter.numeric_combo(NumericFilterKey.VIDEO_HEIGHT, [
                                    NumericExpression.range(240, 360),
                                    NumericExpression.range(720, 1080),
                                    NumericExpression.value(1440)
                                ])
                            ]
                        )
                    )
                ]
            )
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__ec69b5371101ae530c3f09c16702d509409b048b3a187223d73ee793ed6437ec)
            check_type(argname="argument clip_start_time", value=clip_start_time, expected_type=type_hints["clip_start_time"])
            check_type(argname="argument drm_settings", value=drm_settings, expected_type=type_hints["drm_settings"])
            check_type(argname="argument end", value=end, expected_type=type_hints["end"])
            check_type(argname="argument manifest_filter", value=manifest_filter, expected_type=type_hints["manifest_filter"])
            check_type(argname="argument start", value=start, expected_type=type_hints["start"])
            check_type(argname="argument time_delay", value=time_delay, expected_type=type_hints["time_delay"])
        self._values: typing.Dict[builtins.str, typing.Any] = {}
        if clip_start_time is not None:
            self._values["clip_start_time"] = clip_start_time
        if drm_settings is not None:
            self._values["drm_settings"] = drm_settings
        if end is not None:
            self._values["end"] = end
        if manifest_filter is not None:
            self._values["manifest_filter"] = manifest_filter
        if start is not None:
            self._values["start"] = start
        if time_delay is not None:
            self._values["time_delay"] = time_delay

    @builtins.property
    def clip_start_time(self) -> typing.Optional[datetime.datetime]:
        '''(experimental) Optionally specify the clip start time for all of your manifest egress requests.

        When you include clip start time, note that you cannot use clip start time query parameters for this manifest's endpoint URL.

        This will be converted to a UTC timestamp.

        :default: - No clip start time

        :stability: experimental
        '''
        result = self._values.get("clip_start_time")
        return typing.cast(typing.Optional[datetime.datetime], result)

    @builtins.property
    def drm_settings(self) -> typing.Optional[typing.List["DrmSettingsKey"]]:
        '''(experimental) DRM settings for manifest egress requests.

        When you include a DRM setting, note that you cannot use an identical
        DRM setting query parameter for this manifest's endpoint URL.

        :default: - No DRM settings

        :stability: experimental
        '''
        result = self._values.get("drm_settings")
        return typing.cast(typing.Optional[typing.List["DrmSettingsKey"]], result)

    @builtins.property
    def end(self) -> typing.Optional[datetime.datetime]:
        '''(experimental) Optionally specify the end time for all of your manifest egress requests.

        When you include end time, note that you cannot use end time query parameters for this manifest's endpoint URL.

        This will be converted to a UTC timestamp.

        :default: - No end time

        :stability: experimental
        '''
        result = self._values.get("end")
        return typing.cast(typing.Optional[datetime.datetime], result)

    @builtins.property
    def manifest_filter(self) -> typing.Optional[typing.List["ManifestFilter"]]:
        '''(experimental) Optionally specify one or more manifest filters for all of your manifest egress requests.

        When you include a manifest filter, note that you cannot use an identical manifest filter query parameter for this manifest's endpoint URL.

        :default: - No manifest filters

        :stability: experimental
        '''
        result = self._values.get("manifest_filter")
        return typing.cast(typing.Optional[typing.List["ManifestFilter"]], result)

    @builtins.property
    def start(self) -> typing.Optional[datetime.datetime]:
        '''(experimental) Optionally specify the start time for all of your manifest egress requests.

        When you include start time, note that you cannot use start time query parameters for this manifest's endpoint URL.

        This will be converted to a UTC timestamp.

        :default: - No start time

        :stability: experimental
        '''
        result = self._values.get("start")
        return typing.cast(typing.Optional[datetime.datetime], result)

    @builtins.property
    def time_delay(self) -> typing.Optional["_aws_cdk_ceddda9d.Duration"]:
        '''(experimental) Optionally specify the time delay for all of your manifest egress requests.

        Enter a value that is smaller than your endpoint's startover window.
        When you include time delay, note that you cannot use time delay query parameters for this manifest's endpoint URL.

        :default: - No time delay

        :stability: experimental
        '''
        result = self._values.get("time_delay")
        return typing.cast(typing.Optional["_aws_cdk_ceddda9d.Duration"], result)

    def __eq__(self, rhs: typing.Any) -> builtins.bool:
        return isinstance(rhs, self.__class__) and rhs._values == self._values

    def __ne__(self, rhs: typing.Any) -> builtins.bool:
        return not (rhs == self)

    def __repr__(self) -> str:
        return "FilterConfiguration(%s)" % ", ".join(
            k + "=" + repr(v) for k, v in self._values.items()
        )


class HeadersCMSD(
    metaclass=jsii.JSIIMeta,
    jsii_type="@aws-cdk/aws-mediapackagev2-alpha.HeadersCMSD",
):
    '''(experimental) The settings for what common media server data (CMSD) headers AWS Elemental MediaPackage includes in responses to the CDN.

    :stability: experimental
    :exampleMetadata: fixture=_generated

    Example::

        # The code below shows an example of how to instantiate this type.
        # The values are placeholders you should change.
        import aws_cdk.aws_mediapackagev2_alpha as mediapackagev2_alpha
        
        headers_cMSD = mediapackagev2_alpha.HeadersCMSD.of("value")
    '''

    @jsii.member(jsii_name="of")
    @builtins.classmethod
    def of(cls, value: builtins.str) -> "HeadersCMSD":
        '''(experimental) Escape hatch for new CMSD headers not yet supported by the construct.

        :param value: -

        :stability: experimental
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__246b895f1b9c79fb75ffeafae18291e95e1df0d509fb3fda34bfb81d75b8b2b1)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        return typing.cast("HeadersCMSD", jsii.sinvoke(cls, "of", [value]))

    @jsii.python.classproperty
    @jsii.member(jsii_name="MQCS")
    def MQCS(cls) -> "HeadersCMSD":
        '''(experimental) Media Quality Confidence Score.

        :stability: experimental
        '''
        return typing.cast("HeadersCMSD", jsii.sget(cls, "MQCS"))

    @builtins.property
    @jsii.member(jsii_name="value")
    def value(self) -> builtins.str:
        '''(experimental) The string value of the CMSD header.

        :stability: experimental
        '''
        return typing.cast(builtins.str, jsii.get(self, "value"))


@jsii.data_type(
    jsii_type="@aws-cdk/aws-mediapackagev2-alpha.HlsManifestConfiguration",
    jsii_struct_bases=[],
    name_mapping={
        "manifest_name": "manifestName",
        "child_manifest_name": "childManifestName",
        "filter_configuration": "filterConfiguration",
        "manifest_window": "manifestWindow",
        "program_date_time_interval": "programDateTimeInterval",
        "scte_ad_marker_hls": "scteAdMarkerHls",
        "start_tag": "startTag",
        "url_encode_child_manifest": "urlEncodeChildManifest",
    },
)
class HlsManifestConfiguration:
    def __init__(
        self,
        *,
        manifest_name: builtins.str,
        child_manifest_name: typing.Optional[builtins.str] = None,
        filter_configuration: typing.Optional[typing.Union["FilterConfiguration", typing.Dict[builtins.str, typing.Any]]] = None,
        manifest_window: typing.Optional["_aws_cdk_ceddda9d.Duration"] = None,
        program_date_time_interval: typing.Optional["_aws_cdk_ceddda9d.Duration"] = None,
        scte_ad_marker_hls: typing.Optional["AdMarkerHls"] = None,
        start_tag: typing.Optional["StartTag"] = None,
        url_encode_child_manifest: typing.Optional[builtins.bool] = None,
    ) -> None:
        '''(experimental) The HLS manifest configuration associated with the origin endpoint.

        :param manifest_name: (experimental) The name of the manifest associated with the HLS manifest configuration.
        :param child_manifest_name: (experimental) The name of the child manifest associated with the HLS manifest configuration. Default: - No child manifest name specified
        :param filter_configuration: (experimental) Filter configuration includes settings for manifest filtering, start and end times, and time delay that apply to all of your egress requests for this manifest. https://docs.aws.amazon.com/mediapackage/latest/userguide/manifest-filter-query-parameters.html Default: - No filter configuration
        :param manifest_window: (experimental) The total duration (in seconds) of the manifest's content. Default: 60
        :param program_date_time_interval: (experimental) Inserts EXT-X-PROGRAM-DATE-TIME tags in the output manifest at the interval that you specify. If you don't enter an interval, EXT-X-PROGRAM-DATE-TIME tags aren't included in the manifest. The tags sync the stream to the wall clock so that viewers can seek to a specific time in the playback timeline on the player. Default: - No program date time interval
        :param scte_ad_marker_hls: (experimental) The SCTE-35 HLS configuration associated with the HLS manifest configuration of the origin endpoint. Default: - No SCTE ad marker configuration
        :param start_tag: (experimental) Insert EXT-X-START tag in the manifest with the configured settings. Default: - No start tag
        :param url_encode_child_manifest: (experimental) When enabled, MediaPackage URL-encodes the query string for API requests for HLS child manifests to comply with AWS Signature Version 4 (SigV4) signature signing protocol. For more information, see AWS Signature Version 4 for API requests in AWS Identity and Access Management User Guide. Default: false

        :stability: experimental
        :exampleMetadata: infused

        Example::

            # channel: Channel
            # speke_role: iam.IRole
            
            
            OriginEndpoint(self, "TsEndpoint",
                channel=channel,
                segment=Segment.ts(
                    encryption=TsEncryption.speke(
                        method=TsEncryptionMethod.SAMPLE_AES,
                        resource_id="my-content-id",
                        url="https://example.com/speke",
                        role=speke_role
                    )
                ),
                manifests=[Manifest.hls(manifest_name="index")]
            )
        '''
        if isinstance(filter_configuration, dict):
            filter_configuration = FilterConfiguration(**filter_configuration)
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__f660ebc93317dcda78a955d0ad53e4997889f9e7a370db36a40d0470fdead946)
            check_type(argname="argument manifest_name", value=manifest_name, expected_type=type_hints["manifest_name"])
            check_type(argname="argument child_manifest_name", value=child_manifest_name, expected_type=type_hints["child_manifest_name"])
            check_type(argname="argument filter_configuration", value=filter_configuration, expected_type=type_hints["filter_configuration"])
            check_type(argname="argument manifest_window", value=manifest_window, expected_type=type_hints["manifest_window"])
            check_type(argname="argument program_date_time_interval", value=program_date_time_interval, expected_type=type_hints["program_date_time_interval"])
            check_type(argname="argument scte_ad_marker_hls", value=scte_ad_marker_hls, expected_type=type_hints["scte_ad_marker_hls"])
            check_type(argname="argument start_tag", value=start_tag, expected_type=type_hints["start_tag"])
            check_type(argname="argument url_encode_child_manifest", value=url_encode_child_manifest, expected_type=type_hints["url_encode_child_manifest"])
        self._values: typing.Dict[builtins.str, typing.Any] = {
            "manifest_name": manifest_name,
        }
        if child_manifest_name is not None:
            self._values["child_manifest_name"] = child_manifest_name
        if filter_configuration is not None:
            self._values["filter_configuration"] = filter_configuration
        if manifest_window is not None:
            self._values["manifest_window"] = manifest_window
        if program_date_time_interval is not None:
            self._values["program_date_time_interval"] = program_date_time_interval
        if scte_ad_marker_hls is not None:
            self._values["scte_ad_marker_hls"] = scte_ad_marker_hls
        if start_tag is not None:
            self._values["start_tag"] = start_tag
        if url_encode_child_manifest is not None:
            self._values["url_encode_child_manifest"] = url_encode_child_manifest

    @builtins.property
    def manifest_name(self) -> builtins.str:
        '''(experimental) The name of the manifest associated with the HLS manifest configuration.

        :stability: experimental
        '''
        result = self._values.get("manifest_name")
        assert result is not None, "Required property 'manifest_name' is missing"
        return typing.cast(builtins.str, result)

    @builtins.property
    def child_manifest_name(self) -> typing.Optional[builtins.str]:
        '''(experimental) The name of the child manifest associated with the HLS manifest configuration.

        :default: - No child manifest name specified

        :stability: experimental
        '''
        result = self._values.get("child_manifest_name")
        return typing.cast(typing.Optional[builtins.str], result)

    @builtins.property
    def filter_configuration(self) -> typing.Optional["FilterConfiguration"]:
        '''(experimental) Filter configuration includes settings for manifest filtering, start and end times, and time delay that apply to all of your egress requests for this manifest.

        https://docs.aws.amazon.com/mediapackage/latest/userguide/manifest-filter-query-parameters.html

        :default: - No filter configuration

        :stability: experimental
        '''
        result = self._values.get("filter_configuration")
        return typing.cast(typing.Optional["FilterConfiguration"], result)

    @builtins.property
    def manifest_window(self) -> typing.Optional["_aws_cdk_ceddda9d.Duration"]:
        '''(experimental) The total duration (in seconds) of the manifest's content.

        :default: 60

        :stability: experimental
        '''
        result = self._values.get("manifest_window")
        return typing.cast(typing.Optional["_aws_cdk_ceddda9d.Duration"], result)

    @builtins.property
    def program_date_time_interval(
        self,
    ) -> typing.Optional["_aws_cdk_ceddda9d.Duration"]:
        '''(experimental) Inserts EXT-X-PROGRAM-DATE-TIME tags in the output manifest at the interval that you specify.

        If you don't enter an interval, EXT-X-PROGRAM-DATE-TIME tags aren't included in the manifest.
        The tags sync the stream to the wall clock so that viewers can seek to a specific time in the playback timeline on the player.

        :default: - No program date time interval

        :stability: experimental
        '''
        result = self._values.get("program_date_time_interval")
        return typing.cast(typing.Optional["_aws_cdk_ceddda9d.Duration"], result)

    @builtins.property
    def scte_ad_marker_hls(self) -> typing.Optional["AdMarkerHls"]:
        '''(experimental) The SCTE-35 HLS configuration associated with the HLS manifest configuration of the origin endpoint.

        :default: - No SCTE ad marker configuration

        :stability: experimental
        '''
        result = self._values.get("scte_ad_marker_hls")
        return typing.cast(typing.Optional["AdMarkerHls"], result)

    @builtins.property
    def start_tag(self) -> typing.Optional["StartTag"]:
        '''(experimental) Insert EXT-X-START tag in the manifest with the configured settings.

        :default: - No start tag

        :stability: experimental
        '''
        result = self._values.get("start_tag")
        return typing.cast(typing.Optional["StartTag"], result)

    @builtins.property
    def url_encode_child_manifest(self) -> typing.Optional[builtins.bool]:
        '''(experimental) When enabled, MediaPackage URL-encodes the query string for API requests for HLS child manifests to comply with AWS Signature Version 4 (SigV4) signature signing protocol.

        For more information, see AWS Signature Version 4 for API requests in AWS Identity and Access Management User Guide.

        :default: false

        :stability: experimental
        :external: https://docs.aws.amazon.com/IAM/latest/UserGuide/reference_sigv.html
        '''
        result = self._values.get("url_encode_child_manifest")
        return typing.cast(typing.Optional[builtins.bool], result)

    def __eq__(self, rhs: typing.Any) -> builtins.bool:
        return isinstance(rhs, self.__class__) and rhs._values == self._values

    def __ne__(self, rhs: typing.Any) -> builtins.bool:
        return not (rhs == self)

    def __repr__(self) -> str:
        return "HlsManifestConfiguration(%s)" % ", ".join(
            k + "=" + repr(v) for k, v in self._values.items()
        )


@jsii.interface(jsii_type="@aws-cdk/aws-mediapackagev2-alpha.IChannel")
class IChannel(
    _aws_cdk_ceddda9d.IResource,
    _aws_cdk_interfaces_aws_mediapackagev2_ceddda9d.IChannelRef,
    typing_extensions.Protocol,
):
    '''(experimental) Represents a MediaPackage V2 Channel.

    :stability: experimental
    '''

    @builtins.property
    @jsii.member(jsii_name="channelArn")
    def channel_arn(self) -> builtins.str:
        '''(experimental) The Amazon Resource Name (ARN) associated with the resource.

        :stability: experimental
        :attribute: true
        '''
        ...

    @builtins.property
    @jsii.member(jsii_name="channelGroupName")
    def channel_group_name(self) -> builtins.str:
        '''(experimental) The name that describes the channel group.

        The name is the primary identifier for the channel group.

        :stability: experimental
        :attribute: true
        '''
        ...

    @builtins.property
    @jsii.member(jsii_name="channelName")
    def channel_name(self) -> builtins.str:
        '''(experimental) The name that describes the channel.

        The name is the primary identifier for the channel.

        :stability: experimental
        :attribute: true
        '''
        ...

    @builtins.property
    @jsii.member(jsii_name="grants")
    def grants(self) -> "ChannelGrants":
        '''(experimental) Grants IAM resource policy to the role used to write to MediaPackage V2 Channel.

        :stability: experimental
        '''
        ...

    @builtins.property
    @jsii.member(jsii_name="ingestEndpointUrls")
    def ingest_endpoint_urls(self) -> typing.List[builtins.str]:
        '''(experimental) The ingest endpoint URLs for the channel.

        :stability: experimental
        :attribute: true
        '''
        ...

    @builtins.property
    @jsii.member(jsii_name="channelGroup")
    def channel_group(self) -> typing.Optional["IChannelGroup"]:
        '''(experimental) The channel group this channel belongs to.

        Only available when the channel was created in the same stack.
        Undefined for imported channels.

        :stability: experimental
        :attribute: true
        '''
        ...

    @builtins.property
    @jsii.member(jsii_name="createdAt")
    def created_at(self) -> typing.Optional[builtins.str]:
        '''(experimental) The date and time the channel was created.

        :stability: experimental
        :attribute: true
        '''
        ...

    @builtins.property
    @jsii.member(jsii_name="modifiedAt")
    def modified_at(self) -> typing.Optional[builtins.str]:
        '''(experimental) The date and time the channel was modified.

        :stability: experimental
        :attribute: true
        '''
        ...

    @jsii.member(jsii_name="addOriginEndpoint")
    def add_origin_endpoint(
        self,
        id: builtins.str,
        *,
        manifests: typing.Sequence["Manifest"],
        segment: typing.Union["SegmentConfiguration", typing.Dict[builtins.str, typing.Any]],
        cdn_auth: typing.Optional[typing.Union["CdnAuthConfiguration", typing.Dict[builtins.str, typing.Any]]] = None,
        description: typing.Optional[builtins.str] = None,
        force_endpoint_configuration_conditions: typing.Optional[typing.Sequence["EndpointErrorConfiguration"]] = None,
        origin_endpoint_name: typing.Optional[builtins.str] = None,
        removal_policy: typing.Optional["_aws_cdk_ceddda9d.RemovalPolicy"] = None,
        startover_window: typing.Optional["_aws_cdk_ceddda9d.Duration"] = None,
        tags: typing.Optional[typing.Mapping[builtins.str, builtins.str]] = None,
    ) -> "OriginEndpoint":
        '''(experimental) Add Origin Endpoint for this Channel.

        :param id: -
        :param manifests: (experimental) Manifests configuration for HLS, Low Latency HLS and DASH.
        :param segment: (experimental) The segment associated with the origin endpoint. Inside the segment configuration you can define options such as encryption, SPEKE parameters and other general segment configurations. Use Segment.ts() or Segment.cmaf() to create the configuration.
        :param cdn_auth: (experimental) Provide access to MediaPackage V2 Origin Endpoint via secret header. Default: undefined - Not configured on endpoint
        :param description: (experimental) The description associated with the origin endpoint. Default: undefined - No description is added to Origin Endpoint
        :param force_endpoint_configuration_conditions: (experimental) The failover settings for the endpoint. Default: undefined - No force endpoint configuration is configured
        :param origin_endpoint_name: (experimental) The name of the origin endpoint associated with the origin endpoint configuration. Default: autogenerated
        :param removal_policy: (experimental) Policy to apply when the origin endpoint is removed from the stack. Even though MediaPackage ChannelGroups, Channels and OriginEndpoints are technically stateful, their contents are transient and it is common to add and remove these while rearchitecting your application. The default is therefore ``DESTROY``. Change it to ``RETAIN`` if the content (in a lookback window) are so valuable that accidentally losing it would be unacceptable. Default: RemovalPolicy.DESTROY
        :param startover_window: (experimental) The size of the window to specify a window of the live stream that's available for on-demand viewing. Viewers can start-over or catch-up on content that falls within the window. Default: 900
        :param tags: (experimental) The tags associated with the origin endpoint. Default: - No tagging

        :stability: experimental
        '''
        ...

    @jsii.member(jsii_name="addToResourcePolicy")
    def add_to_resource_policy(
        self,
        statement: "_aws_cdk_aws_iam_ceddda9d.PolicyStatement",
    ) -> "_aws_cdk_aws_iam_ceddda9d.AddToResourcePolicyResult":
        '''(experimental) Configure channel policy.

        You can only add 1 ChannelPolicy to a Channel.
        If you have already defined one, function will append the policy already created.

        :param statement: -

        :stability: experimental
        '''
        ...

    @jsii.member(jsii_name="metric")
    def metric(
        self,
        metric_name: builtins.str,
        *,
        account: typing.Optional[builtins.str] = None,
        color: typing.Optional[builtins.str] = None,
        dimensions_map: typing.Optional[typing.Mapping[builtins.str, builtins.str]] = None,
        id: typing.Optional[builtins.str] = None,
        label: typing.Optional[builtins.str] = None,
        period: typing.Optional["_aws_cdk_ceddda9d.Duration"] = None,
        region: typing.Optional[builtins.str] = None,
        stack_account: typing.Optional[builtins.str] = None,
        stack_region: typing.Optional[builtins.str] = None,
        statistic: typing.Optional[builtins.str] = None,
        unit: typing.Optional["_aws_cdk_aws_cloudwatch_ceddda9d.Unit"] = None,
        visible: typing.Optional[builtins.bool] = None,
    ) -> "_aws_cdk_aws_cloudwatch_ceddda9d.Metric":
        '''(experimental) Create a CloudWatch metric.

        :param metric_name: name of the metric.
        :param account: Account which this metric comes from. Default: - Deployment account.
        :param color: The hex color code, prefixed with '#' (e.g. '#00ff00'), to use when this metric is rendered on a graph. The ``Color`` class has a set of standard colors that can be used here. Default: - Automatic color
        :param dimensions_map: Dimensions of the metric. Default: - No dimensions.
        :param id: Unique identifier for this metric when used in dashboard widgets. The id can be used as a variable to represent this metric in math expressions. Valid characters are letters, numbers, and underscore. The first character must be a lowercase letter. Default: - No ID
        :param label: Label for this metric when added to a Graph in a Dashboard. You can use `dynamic labels <https://docs.aws.amazon.com/AmazonCloudWatch/latest/monitoring/graph-dynamic-labels.html>`_ to show summary information about the entire displayed time series in the legend. For example, if you use:: [max: ${MAX}] MyMetric As the metric label, the maximum value in the visible range will be shown next to the time series name in the graph's legend. Default: - No label
        :param period: The period over which the specified statistic is applied. Default: Duration.minutes(5)
        :param region: Region which this metric comes from. Default: - Deployment region.
        :param stack_account: Account of the stack this metric is attached to. Default: - Deployment account.
        :param stack_region: Region of the stack this metric is attached to. Default: - Deployment region.
        :param statistic: What function to use for aggregating. Use the ``aws_cloudwatch.Stats`` helper class to construct valid input strings. Can be one of the following: - "Minimum" | "min" - "Maximum" | "max" - "Average" | "avg" - "Sum" | "sum" - "SampleCount | "n" - "pNN.NN" - "tmNN.NN" | "tm(NN.NN%:NN.NN%)" - "iqm" - "wmNN.NN" | "wm(NN.NN%:NN.NN%)" - "tcNN.NN" | "tc(NN.NN%:NN.NN%)" - "tsNN.NN" | "ts(NN.NN%:NN.NN%)" Default: Average
        :param unit: Unit used to filter the metric stream. Only refer to datums emitted to the metric stream with the given unit and ignore all others. Only useful when datums are being emitted to the same metric stream under different units. The default is to use all matric datums in the stream, regardless of unit, which is recommended in nearly all cases. CloudWatch does not honor this property for graphs. Default: - All metric datums in the given metric stream
        :param visible: Whether this metric should be visible in dashboard graphs. Setting this to false is useful when you want to hide raw metrics that are used in math expressions, and show only the expression results. Default: true

        :stability: experimental
        '''
        ...

    @jsii.member(jsii_name="metricEgressBytes")
    def metric_egress_bytes(
        self,
        *,
        account: typing.Optional[builtins.str] = None,
        color: typing.Optional[builtins.str] = None,
        dimensions_map: typing.Optional[typing.Mapping[builtins.str, builtins.str]] = None,
        id: typing.Optional[builtins.str] = None,
        label: typing.Optional[builtins.str] = None,
        period: typing.Optional["_aws_cdk_ceddda9d.Duration"] = None,
        region: typing.Optional[builtins.str] = None,
        stack_account: typing.Optional[builtins.str] = None,
        stack_region: typing.Optional[builtins.str] = None,
        statistic: typing.Optional[builtins.str] = None,
        unit: typing.Optional["_aws_cdk_aws_cloudwatch_ceddda9d.Unit"] = None,
        visible: typing.Optional[builtins.bool] = None,
    ) -> "_aws_cdk_aws_cloudwatch_ceddda9d.Metric":
        '''(experimental) Returns Metric for Egress Bytes.

        :param account: Account which this metric comes from. Default: - Deployment account.
        :param color: The hex color code, prefixed with '#' (e.g. '#00ff00'), to use when this metric is rendered on a graph. The ``Color`` class has a set of standard colors that can be used here. Default: - Automatic color
        :param dimensions_map: Dimensions of the metric. Default: - No dimensions.
        :param id: Unique identifier for this metric when used in dashboard widgets. The id can be used as a variable to represent this metric in math expressions. Valid characters are letters, numbers, and underscore. The first character must be a lowercase letter. Default: - No ID
        :param label: Label for this metric when added to a Graph in a Dashboard. You can use `dynamic labels <https://docs.aws.amazon.com/AmazonCloudWatch/latest/monitoring/graph-dynamic-labels.html>`_ to show summary information about the entire displayed time series in the legend. For example, if you use:: [max: ${MAX}] MyMetric As the metric label, the maximum value in the visible range will be shown next to the time series name in the graph's legend. Default: - No label
        :param period: The period over which the specified statistic is applied. Default: Duration.minutes(5)
        :param region: Region which this metric comes from. Default: - Deployment region.
        :param stack_account: Account of the stack this metric is attached to. Default: - Deployment account.
        :param stack_region: Region of the stack this metric is attached to. Default: - Deployment region.
        :param statistic: What function to use for aggregating. Use the ``aws_cloudwatch.Stats`` helper class to construct valid input strings. Can be one of the following: - "Minimum" | "min" - "Maximum" | "max" - "Average" | "avg" - "Sum" | "sum" - "SampleCount | "n" - "pNN.NN" - "tmNN.NN" | "tm(NN.NN%:NN.NN%)" - "iqm" - "wmNN.NN" | "wm(NN.NN%:NN.NN%)" - "tcNN.NN" | "tc(NN.NN%:NN.NN%)" - "tsNN.NN" | "ts(NN.NN%:NN.NN%)" Default: Average
        :param unit: Unit used to filter the metric stream. Only refer to datums emitted to the metric stream with the given unit and ignore all others. Only useful when datums are being emitted to the same metric stream under different units. The default is to use all matric datums in the stream, regardless of unit, which is recommended in nearly all cases. CloudWatch does not honor this property for graphs. Default: - All metric datums in the given metric stream
        :param visible: Whether this metric should be visible in dashboard graphs. Setting this to false is useful when you want to hide raw metrics that are used in math expressions, and show only the expression results. Default: true

        :default: - sum over 60 seconds

        :stability: experimental
        '''
        ...

    @jsii.member(jsii_name="metricEgressRequestCount")
    def metric_egress_request_count(
        self,
        *,
        account: typing.Optional[builtins.str] = None,
        color: typing.Optional[builtins.str] = None,
        dimensions_map: typing.Optional[typing.Mapping[builtins.str, builtins.str]] = None,
        id: typing.Optional[builtins.str] = None,
        label: typing.Optional[builtins.str] = None,
        period: typing.Optional["_aws_cdk_ceddda9d.Duration"] = None,
        region: typing.Optional[builtins.str] = None,
        stack_account: typing.Optional[builtins.str] = None,
        stack_region: typing.Optional[builtins.str] = None,
        statistic: typing.Optional[builtins.str] = None,
        unit: typing.Optional["_aws_cdk_aws_cloudwatch_ceddda9d.Unit"] = None,
        visible: typing.Optional[builtins.bool] = None,
    ) -> "_aws_cdk_aws_cloudwatch_ceddda9d.Metric":
        '''(experimental) Returns Metric for Egress Request Count.

        :param account: Account which this metric comes from. Default: - Deployment account.
        :param color: The hex color code, prefixed with '#' (e.g. '#00ff00'), to use when this metric is rendered on a graph. The ``Color`` class has a set of standard colors that can be used here. Default: - Automatic color
        :param dimensions_map: Dimensions of the metric. Default: - No dimensions.
        :param id: Unique identifier for this metric when used in dashboard widgets. The id can be used as a variable to represent this metric in math expressions. Valid characters are letters, numbers, and underscore. The first character must be a lowercase letter. Default: - No ID
        :param label: Label for this metric when added to a Graph in a Dashboard. You can use `dynamic labels <https://docs.aws.amazon.com/AmazonCloudWatch/latest/monitoring/graph-dynamic-labels.html>`_ to show summary information about the entire displayed time series in the legend. For example, if you use:: [max: ${MAX}] MyMetric As the metric label, the maximum value in the visible range will be shown next to the time series name in the graph's legend. Default: - No label
        :param period: The period over which the specified statistic is applied. Default: Duration.minutes(5)
        :param region: Region which this metric comes from. Default: - Deployment region.
        :param stack_account: Account of the stack this metric is attached to. Default: - Deployment account.
        :param stack_region: Region of the stack this metric is attached to. Default: - Deployment region.
        :param statistic: What function to use for aggregating. Use the ``aws_cloudwatch.Stats`` helper class to construct valid input strings. Can be one of the following: - "Minimum" | "min" - "Maximum" | "max" - "Average" | "avg" - "Sum" | "sum" - "SampleCount | "n" - "pNN.NN" - "tmNN.NN" | "tm(NN.NN%:NN.NN%)" - "iqm" - "wmNN.NN" | "wm(NN.NN%:NN.NN%)" - "tcNN.NN" | "tc(NN.NN%:NN.NN%)" - "tsNN.NN" | "ts(NN.NN%:NN.NN%)" Default: Average
        :param unit: Unit used to filter the metric stream. Only refer to datums emitted to the metric stream with the given unit and ignore all others. Only useful when datums are being emitted to the same metric stream under different units. The default is to use all matric datums in the stream, regardless of unit, which is recommended in nearly all cases. CloudWatch does not honor this property for graphs. Default: - All metric datums in the given metric stream
        :param visible: Whether this metric should be visible in dashboard graphs. Setting this to false is useful when you want to hide raw metrics that are used in math expressions, and show only the expression results. Default: true

        :default: - sum over 60 seconds

        :stability: experimental
        '''
        ...

    @jsii.member(jsii_name="metricEgressResponseTime")
    def metric_egress_response_time(
        self,
        *,
        account: typing.Optional[builtins.str] = None,
        color: typing.Optional[builtins.str] = None,
        dimensions_map: typing.Optional[typing.Mapping[builtins.str, builtins.str]] = None,
        id: typing.Optional[builtins.str] = None,
        label: typing.Optional[builtins.str] = None,
        period: typing.Optional["_aws_cdk_ceddda9d.Duration"] = None,
        region: typing.Optional[builtins.str] = None,
        stack_account: typing.Optional[builtins.str] = None,
        stack_region: typing.Optional[builtins.str] = None,
        statistic: typing.Optional[builtins.str] = None,
        unit: typing.Optional["_aws_cdk_aws_cloudwatch_ceddda9d.Unit"] = None,
        visible: typing.Optional[builtins.bool] = None,
    ) -> "_aws_cdk_aws_cloudwatch_ceddda9d.Metric":
        '''(experimental) Returns Metric for Egress Response time.

        :param account: Account which this metric comes from. Default: - Deployment account.
        :param color: The hex color code, prefixed with '#' (e.g. '#00ff00'), to use when this metric is rendered on a graph. The ``Color`` class has a set of standard colors that can be used here. Default: - Automatic color
        :param dimensions_map: Dimensions of the metric. Default: - No dimensions.
        :param id: Unique identifier for this metric when used in dashboard widgets. The id can be used as a variable to represent this metric in math expressions. Valid characters are letters, numbers, and underscore. The first character must be a lowercase letter. Default: - No ID
        :param label: Label for this metric when added to a Graph in a Dashboard. You can use `dynamic labels <https://docs.aws.amazon.com/AmazonCloudWatch/latest/monitoring/graph-dynamic-labels.html>`_ to show summary information about the entire displayed time series in the legend. For example, if you use:: [max: ${MAX}] MyMetric As the metric label, the maximum value in the visible range will be shown next to the time series name in the graph's legend. Default: - No label
        :param period: The period over which the specified statistic is applied. Default: Duration.minutes(5)
        :param region: Region which this metric comes from. Default: - Deployment region.
        :param stack_account: Account of the stack this metric is attached to. Default: - Deployment account.
        :param stack_region: Region of the stack this metric is attached to. Default: - Deployment region.
        :param statistic: What function to use for aggregating. Use the ``aws_cloudwatch.Stats`` helper class to construct valid input strings. Can be one of the following: - "Minimum" | "min" - "Maximum" | "max" - "Average" | "avg" - "Sum" | "sum" - "SampleCount | "n" - "pNN.NN" - "tmNN.NN" | "tm(NN.NN%:NN.NN%)" - "iqm" - "wmNN.NN" | "wm(NN.NN%:NN.NN%)" - "tcNN.NN" | "tc(NN.NN%:NN.NN%)" - "tsNN.NN" | "ts(NN.NN%:NN.NN%)" Default: Average
        :param unit: Unit used to filter the metric stream. Only refer to datums emitted to the metric stream with the given unit and ignore all others. Only useful when datums are being emitted to the same metric stream under different units. The default is to use all matric datums in the stream, regardless of unit, which is recommended in nearly all cases. CloudWatch does not honor this property for graphs. Default: - All metric datums in the given metric stream
        :param visible: Whether this metric should be visible in dashboard graphs. Setting this to false is useful when you want to hide raw metrics that are used in math expressions, and show only the expression results. Default: true

        :default: - average over 60 seconds

        :stability: experimental
        '''
        ...

    @jsii.member(jsii_name="metricIngressBytes")
    def metric_ingress_bytes(
        self,
        *,
        account: typing.Optional[builtins.str] = None,
        color: typing.Optional[builtins.str] = None,
        dimensions_map: typing.Optional[typing.Mapping[builtins.str, builtins.str]] = None,
        id: typing.Optional[builtins.str] = None,
        label: typing.Optional[builtins.str] = None,
        period: typing.Optional["_aws_cdk_ceddda9d.Duration"] = None,
        region: typing.Optional[builtins.str] = None,
        stack_account: typing.Optional[builtins.str] = None,
        stack_region: typing.Optional[builtins.str] = None,
        statistic: typing.Optional[builtins.str] = None,
        unit: typing.Optional["_aws_cdk_aws_cloudwatch_ceddda9d.Unit"] = None,
        visible: typing.Optional[builtins.bool] = None,
    ) -> "_aws_cdk_aws_cloudwatch_ceddda9d.Metric":
        '''(experimental) Returns Metric for Ingress Bytes.

        :param account: Account which this metric comes from. Default: - Deployment account.
        :param color: The hex color code, prefixed with '#' (e.g. '#00ff00'), to use when this metric is rendered on a graph. The ``Color`` class has a set of standard colors that can be used here. Default: - Automatic color
        :param dimensions_map: Dimensions of the metric. Default: - No dimensions.
        :param id: Unique identifier for this metric when used in dashboard widgets. The id can be used as a variable to represent this metric in math expressions. Valid characters are letters, numbers, and underscore. The first character must be a lowercase letter. Default: - No ID
        :param label: Label for this metric when added to a Graph in a Dashboard. You can use `dynamic labels <https://docs.aws.amazon.com/AmazonCloudWatch/latest/monitoring/graph-dynamic-labels.html>`_ to show summary information about the entire displayed time series in the legend. For example, if you use:: [max: ${MAX}] MyMetric As the metric label, the maximum value in the visible range will be shown next to the time series name in the graph's legend. Default: - No label
        :param period: The period over which the specified statistic is applied. Default: Duration.minutes(5)
        :param region: Region which this metric comes from. Default: - Deployment region.
        :param stack_account: Account of the stack this metric is attached to. Default: - Deployment account.
        :param stack_region: Region of the stack this metric is attached to. Default: - Deployment region.
        :param statistic: What function to use for aggregating. Use the ``aws_cloudwatch.Stats`` helper class to construct valid input strings. Can be one of the following: - "Minimum" | "min" - "Maximum" | "max" - "Average" | "avg" - "Sum" | "sum" - "SampleCount | "n" - "pNN.NN" - "tmNN.NN" | "tm(NN.NN%:NN.NN%)" - "iqm" - "wmNN.NN" | "wm(NN.NN%:NN.NN%)" - "tcNN.NN" | "tc(NN.NN%:NN.NN%)" - "tsNN.NN" | "ts(NN.NN%:NN.NN%)" Default: Average
        :param unit: Unit used to filter the metric stream. Only refer to datums emitted to the metric stream with the given unit and ignore all others. Only useful when datums are being emitted to the same metric stream under different units. The default is to use all matric datums in the stream, regardless of unit, which is recommended in nearly all cases. CloudWatch does not honor this property for graphs. Default: - All metric datums in the given metric stream
        :param visible: Whether this metric should be visible in dashboard graphs. Setting this to false is useful when you want to hide raw metrics that are used in math expressions, and show only the expression results. Default: true

        :default: - sum over 60 seconds

        :stability: experimental
        '''
        ...

    @jsii.member(jsii_name="metricIngressRequestCount")
    def metric_ingress_request_count(
        self,
        *,
        account: typing.Optional[builtins.str] = None,
        color: typing.Optional[builtins.str] = None,
        dimensions_map: typing.Optional[typing.Mapping[builtins.str, builtins.str]] = None,
        id: typing.Optional[builtins.str] = None,
        label: typing.Optional[builtins.str] = None,
        period: typing.Optional["_aws_cdk_ceddda9d.Duration"] = None,
        region: typing.Optional[builtins.str] = None,
        stack_account: typing.Optional[builtins.str] = None,
        stack_region: typing.Optional[builtins.str] = None,
        statistic: typing.Optional[builtins.str] = None,
        unit: typing.Optional["_aws_cdk_aws_cloudwatch_ceddda9d.Unit"] = None,
        visible: typing.Optional[builtins.bool] = None,
    ) -> "_aws_cdk_aws_cloudwatch_ceddda9d.Metric":
        '''(experimental) Returns Metric for Ingress Request Count.

        :param account: Account which this metric comes from. Default: - Deployment account.
        :param color: The hex color code, prefixed with '#' (e.g. '#00ff00'), to use when this metric is rendered on a graph. The ``Color`` class has a set of standard colors that can be used here. Default: - Automatic color
        :param dimensions_map: Dimensions of the metric. Default: - No dimensions.
        :param id: Unique identifier for this metric when used in dashboard widgets. The id can be used as a variable to represent this metric in math expressions. Valid characters are letters, numbers, and underscore. The first character must be a lowercase letter. Default: - No ID
        :param label: Label for this metric when added to a Graph in a Dashboard. You can use `dynamic labels <https://docs.aws.amazon.com/AmazonCloudWatch/latest/monitoring/graph-dynamic-labels.html>`_ to show summary information about the entire displayed time series in the legend. For example, if you use:: [max: ${MAX}] MyMetric As the metric label, the maximum value in the visible range will be shown next to the time series name in the graph's legend. Default: - No label
        :param period: The period over which the specified statistic is applied. Default: Duration.minutes(5)
        :param region: Region which this metric comes from. Default: - Deployment region.
        :param stack_account: Account of the stack this metric is attached to. Default: - Deployment account.
        :param stack_region: Region of the stack this metric is attached to. Default: - Deployment region.
        :param statistic: What function to use for aggregating. Use the ``aws_cloudwatch.Stats`` helper class to construct valid input strings. Can be one of the following: - "Minimum" | "min" - "Maximum" | "max" - "Average" | "avg" - "Sum" | "sum" - "SampleCount | "n" - "pNN.NN" - "tmNN.NN" | "tm(NN.NN%:NN.NN%)" - "iqm" - "wmNN.NN" | "wm(NN.NN%:NN.NN%)" - "tcNN.NN" | "tc(NN.NN%:NN.NN%)" - "tsNN.NN" | "ts(NN.NN%:NN.NN%)" Default: Average
        :param unit: Unit used to filter the metric stream. Only refer to datums emitted to the metric stream with the given unit and ignore all others. Only useful when datums are being emitted to the same metric stream under different units. The default is to use all matric datums in the stream, regardless of unit, which is recommended in nearly all cases. CloudWatch does not honor this property for graphs. Default: - All metric datums in the given metric stream
        :param visible: Whether this metric should be visible in dashboard graphs. Setting this to false is useful when you want to hide raw metrics that are used in math expressions, and show only the expression results. Default: true

        :default: - sum over 60 seconds

        :stability: experimental
        '''
        ...

    @jsii.member(jsii_name="metricIngressResponseTime")
    def metric_ingress_response_time(
        self,
        *,
        account: typing.Optional[builtins.str] = None,
        color: typing.Optional[builtins.str] = None,
        dimensions_map: typing.Optional[typing.Mapping[builtins.str, builtins.str]] = None,
        id: typing.Optional[builtins.str] = None,
        label: typing.Optional[builtins.str] = None,
        period: typing.Optional["_aws_cdk_ceddda9d.Duration"] = None,
        region: typing.Optional[builtins.str] = None,
        stack_account: typing.Optional[builtins.str] = None,
        stack_region: typing.Optional[builtins.str] = None,
        statistic: typing.Optional[builtins.str] = None,
        unit: typing.Optional["_aws_cdk_aws_cloudwatch_ceddda9d.Unit"] = None,
        visible: typing.Optional[builtins.bool] = None,
    ) -> "_aws_cdk_aws_cloudwatch_ceddda9d.Metric":
        '''(experimental) Returns Metric for Ingress response time.

        :param account: Account which this metric comes from. Default: - Deployment account.
        :param color: The hex color code, prefixed with '#' (e.g. '#00ff00'), to use when this metric is rendered on a graph. The ``Color`` class has a set of standard colors that can be used here. Default: - Automatic color
        :param dimensions_map: Dimensions of the metric. Default: - No dimensions.
        :param id: Unique identifier for this metric when used in dashboard widgets. The id can be used as a variable to represent this metric in math expressions. Valid characters are letters, numbers, and underscore. The first character must be a lowercase letter. Default: - No ID
        :param label: Label for this metric when added to a Graph in a Dashboard. You can use `dynamic labels <https://docs.aws.amazon.com/AmazonCloudWatch/latest/monitoring/graph-dynamic-labels.html>`_ to show summary information about the entire displayed time series in the legend. For example, if you use:: [max: ${MAX}] MyMetric As the metric label, the maximum value in the visible range will be shown next to the time series name in the graph's legend. Default: - No label
        :param period: The period over which the specified statistic is applied. Default: Duration.minutes(5)
        :param region: Region which this metric comes from. Default: - Deployment region.
        :param stack_account: Account of the stack this metric is attached to. Default: - Deployment account.
        :param stack_region: Region of the stack this metric is attached to. Default: - Deployment region.
        :param statistic: What function to use for aggregating. Use the ``aws_cloudwatch.Stats`` helper class to construct valid input strings. Can be one of the following: - "Minimum" | "min" - "Maximum" | "max" - "Average" | "avg" - "Sum" | "sum" - "SampleCount | "n" - "pNN.NN" - "tmNN.NN" | "tm(NN.NN%:NN.NN%)" - "iqm" - "wmNN.NN" | "wm(NN.NN%:NN.NN%)" - "tcNN.NN" | "tc(NN.NN%:NN.NN%)" - "tsNN.NN" | "ts(NN.NN%:NN.NN%)" Default: Average
        :param unit: Unit used to filter the metric stream. Only refer to datums emitted to the metric stream with the given unit and ignore all others. Only useful when datums are being emitted to the same metric stream under different units. The default is to use all matric datums in the stream, regardless of unit, which is recommended in nearly all cases. CloudWatch does not honor this property for graphs. Default: - All metric datums in the given metric stream
        :param visible: Whether this metric should be visible in dashboard graphs. Setting this to false is useful when you want to hide raw metrics that are used in math expressions, and show only the expression results. Default: true

        :default: - average over 60 seconds

        :stability: experimental
        '''
        ...


class _IChannelProxy(
    jsii.proxy_for(_aws_cdk_ceddda9d.IResource), # type: ignore[misc]
    jsii.proxy_for(_aws_cdk_interfaces_aws_mediapackagev2_ceddda9d.IChannelRef), # type: ignore[misc]
):
    '''(experimental) Represents a MediaPackage V2 Channel.

    :stability: experimental
    '''

    __jsii_type__: typing.ClassVar[str] = "@aws-cdk/aws-mediapackagev2-alpha.IChannel"

    @builtins.property
    @jsii.member(jsii_name="channelArn")
    def channel_arn(self) -> builtins.str:
        '''(experimental) The Amazon Resource Name (ARN) associated with the resource.

        :stability: experimental
        :attribute: true
        '''
        return typing.cast(builtins.str, jsii.get(self, "channelArn"))

    @builtins.property
    @jsii.member(jsii_name="channelGroupName")
    def channel_group_name(self) -> builtins.str:
        '''(experimental) The name that describes the channel group.

        The name is the primary identifier for the channel group.

        :stability: experimental
        :attribute: true
        '''
        return typing.cast(builtins.str, jsii.get(self, "channelGroupName"))

    @builtins.property
    @jsii.member(jsii_name="channelName")
    def channel_name(self) -> builtins.str:
        '''(experimental) The name that describes the channel.

        The name is the primary identifier for the channel.

        :stability: experimental
        :attribute: true
        '''
        return typing.cast(builtins.str, jsii.get(self, "channelName"))

    @builtins.property
    @jsii.member(jsii_name="grants")
    def grants(self) -> "ChannelGrants":
        '''(experimental) Grants IAM resource policy to the role used to write to MediaPackage V2 Channel.

        :stability: experimental
        '''
        return typing.cast("ChannelGrants", jsii.get(self, "grants"))

    @builtins.property
    @jsii.member(jsii_name="ingestEndpointUrls")
    def ingest_endpoint_urls(self) -> typing.List[builtins.str]:
        '''(experimental) The ingest endpoint URLs for the channel.

        :stability: experimental
        :attribute: true
        '''
        return typing.cast(typing.List[builtins.str], jsii.get(self, "ingestEndpointUrls"))

    @builtins.property
    @jsii.member(jsii_name="channelGroup")
    def channel_group(self) -> typing.Optional["IChannelGroup"]:
        '''(experimental) The channel group this channel belongs to.

        Only available when the channel was created in the same stack.
        Undefined for imported channels.

        :stability: experimental
        :attribute: true
        '''
        return typing.cast(typing.Optional["IChannelGroup"], jsii.get(self, "channelGroup"))

    @builtins.property
    @jsii.member(jsii_name="createdAt")
    def created_at(self) -> typing.Optional[builtins.str]:
        '''(experimental) The date and time the channel was created.

        :stability: experimental
        :attribute: true
        '''
        return typing.cast(typing.Optional[builtins.str], jsii.get(self, "createdAt"))

    @builtins.property
    @jsii.member(jsii_name="modifiedAt")
    def modified_at(self) -> typing.Optional[builtins.str]:
        '''(experimental) The date and time the channel was modified.

        :stability: experimental
        :attribute: true
        '''
        return typing.cast(typing.Optional[builtins.str], jsii.get(self, "modifiedAt"))

    @jsii.member(jsii_name="addOriginEndpoint")
    def add_origin_endpoint(
        self,
        id: builtins.str,
        *,
        manifests: typing.Sequence["Manifest"],
        segment: typing.Union["SegmentConfiguration", typing.Dict[builtins.str, typing.Any]],
        cdn_auth: typing.Optional[typing.Union["CdnAuthConfiguration", typing.Dict[builtins.str, typing.Any]]] = None,
        description: typing.Optional[builtins.str] = None,
        force_endpoint_configuration_conditions: typing.Optional[typing.Sequence["EndpointErrorConfiguration"]] = None,
        origin_endpoint_name: typing.Optional[builtins.str] = None,
        removal_policy: typing.Optional["_aws_cdk_ceddda9d.RemovalPolicy"] = None,
        startover_window: typing.Optional["_aws_cdk_ceddda9d.Duration"] = None,
        tags: typing.Optional[typing.Mapping[builtins.str, builtins.str]] = None,
    ) -> "OriginEndpoint":
        '''(experimental) Add Origin Endpoint for this Channel.

        :param id: -
        :param manifests: (experimental) Manifests configuration for HLS, Low Latency HLS and DASH.
        :param segment: (experimental) The segment associated with the origin endpoint. Inside the segment configuration you can define options such as encryption, SPEKE parameters and other general segment configurations. Use Segment.ts() or Segment.cmaf() to create the configuration.
        :param cdn_auth: (experimental) Provide access to MediaPackage V2 Origin Endpoint via secret header. Default: undefined - Not configured on endpoint
        :param description: (experimental) The description associated with the origin endpoint. Default: undefined - No description is added to Origin Endpoint
        :param force_endpoint_configuration_conditions: (experimental) The failover settings for the endpoint. Default: undefined - No force endpoint configuration is configured
        :param origin_endpoint_name: (experimental) The name of the origin endpoint associated with the origin endpoint configuration. Default: autogenerated
        :param removal_policy: (experimental) Policy to apply when the origin endpoint is removed from the stack. Even though MediaPackage ChannelGroups, Channels and OriginEndpoints are technically stateful, their contents are transient and it is common to add and remove these while rearchitecting your application. The default is therefore ``DESTROY``. Change it to ``RETAIN`` if the content (in a lookback window) are so valuable that accidentally losing it would be unacceptable. Default: RemovalPolicy.DESTROY
        :param startover_window: (experimental) The size of the window to specify a window of the live stream that's available for on-demand viewing. Viewers can start-over or catch-up on content that falls within the window. Default: 900
        :param tags: (experimental) The tags associated with the origin endpoint. Default: - No tagging

        :stability: experimental
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__fb8c13565abc2f222cc515be2ddabba55559efbdec003f4f8f37f0fb9bcf5210)
            check_type(argname="argument id", value=id, expected_type=type_hints["id"])
        options = OriginEndpointOptions(
            manifests=manifests,
            segment=segment,
            cdn_auth=cdn_auth,
            description=description,
            force_endpoint_configuration_conditions=force_endpoint_configuration_conditions,
            origin_endpoint_name=origin_endpoint_name,
            removal_policy=removal_policy,
            startover_window=startover_window,
            tags=tags,
        )

        return typing.cast("OriginEndpoint", jsii.invoke(self, "addOriginEndpoint", [id, options]))

    @jsii.member(jsii_name="addToResourcePolicy")
    def add_to_resource_policy(
        self,
        statement: "_aws_cdk_aws_iam_ceddda9d.PolicyStatement",
    ) -> "_aws_cdk_aws_iam_ceddda9d.AddToResourcePolicyResult":
        '''(experimental) Configure channel policy.

        You can only add 1 ChannelPolicy to a Channel.
        If you have already defined one, function will append the policy already created.

        :param statement: -

        :stability: experimental
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__9112ca5adc347c8eccc09cf2de882adfea68c6995274ee205cb0c1d16f5b62c3)
            check_type(argname="argument statement", value=statement, expected_type=type_hints["statement"])
        return typing.cast("_aws_cdk_aws_iam_ceddda9d.AddToResourcePolicyResult", jsii.invoke(self, "addToResourcePolicy", [statement]))

    @jsii.member(jsii_name="metric")
    def metric(
        self,
        metric_name: builtins.str,
        *,
        account: typing.Optional[builtins.str] = None,
        color: typing.Optional[builtins.str] = None,
        dimensions_map: typing.Optional[typing.Mapping[builtins.str, builtins.str]] = None,
        id: typing.Optional[builtins.str] = None,
        label: typing.Optional[builtins.str] = None,
        period: typing.Optional["_aws_cdk_ceddda9d.Duration"] = None,
        region: typing.Optional[builtins.str] = None,
        stack_account: typing.Optional[builtins.str] = None,
        stack_region: typing.Optional[builtins.str] = None,
        statistic: typing.Optional[builtins.str] = None,
        unit: typing.Optional["_aws_cdk_aws_cloudwatch_ceddda9d.Unit"] = None,
        visible: typing.Optional[builtins.bool] = None,
    ) -> "_aws_cdk_aws_cloudwatch_ceddda9d.Metric":
        '''(experimental) Create a CloudWatch metric.

        :param metric_name: name of the metric.
        :param account: Account which this metric comes from. Default: - Deployment account.
        :param color: The hex color code, prefixed with '#' (e.g. '#00ff00'), to use when this metric is rendered on a graph. The ``Color`` class has a set of standard colors that can be used here. Default: - Automatic color
        :param dimensions_map: Dimensions of the metric. Default: - No dimensions.
        :param id: Unique identifier for this metric when used in dashboard widgets. The id can be used as a variable to represent this metric in math expressions. Valid characters are letters, numbers, and underscore. The first character must be a lowercase letter. Default: - No ID
        :param label: Label for this metric when added to a Graph in a Dashboard. You can use `dynamic labels <https://docs.aws.amazon.com/AmazonCloudWatch/latest/monitoring/graph-dynamic-labels.html>`_ to show summary information about the entire displayed time series in the legend. For example, if you use:: [max: ${MAX}] MyMetric As the metric label, the maximum value in the visible range will be shown next to the time series name in the graph's legend. Default: - No label
        :param period: The period over which the specified statistic is applied. Default: Duration.minutes(5)
        :param region: Region which this metric comes from. Default: - Deployment region.
        :param stack_account: Account of the stack this metric is attached to. Default: - Deployment account.
        :param stack_region: Region of the stack this metric is attached to. Default: - Deployment region.
        :param statistic: What function to use for aggregating. Use the ``aws_cloudwatch.Stats`` helper class to construct valid input strings. Can be one of the following: - "Minimum" | "min" - "Maximum" | "max" - "Average" | "avg" - "Sum" | "sum" - "SampleCount | "n" - "pNN.NN" - "tmNN.NN" | "tm(NN.NN%:NN.NN%)" - "iqm" - "wmNN.NN" | "wm(NN.NN%:NN.NN%)" - "tcNN.NN" | "tc(NN.NN%:NN.NN%)" - "tsNN.NN" | "ts(NN.NN%:NN.NN%)" Default: Average
        :param unit: Unit used to filter the metric stream. Only refer to datums emitted to the metric stream with the given unit and ignore all others. Only useful when datums are being emitted to the same metric stream under different units. The default is to use all matric datums in the stream, regardless of unit, which is recommended in nearly all cases. CloudWatch does not honor this property for graphs. Default: - All metric datums in the given metric stream
        :param visible: Whether this metric should be visible in dashboard graphs. Setting this to false is useful when you want to hide raw metrics that are used in math expressions, and show only the expression results. Default: true

        :stability: experimental
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__e19c3affc8fee9a2c8113936b0b23abdfc45c550cb864c9d1ebcb7a869e46a7b)
            check_type(argname="argument metric_name", value=metric_name, expected_type=type_hints["metric_name"])
        props = _aws_cdk_aws_cloudwatch_ceddda9d.MetricOptions(
            account=account,
            color=color,
            dimensions_map=dimensions_map,
            id=id,
            label=label,
            period=period,
            region=region,
            stack_account=stack_account,
            stack_region=stack_region,
            statistic=statistic,
            unit=unit,
            visible=visible,
        )

        return typing.cast("_aws_cdk_aws_cloudwatch_ceddda9d.Metric", jsii.invoke(self, "metric", [metric_name, props]))

    @jsii.member(jsii_name="metricEgressBytes")
    def metric_egress_bytes(
        self,
        *,
        account: typing.Optional[builtins.str] = None,
        color: typing.Optional[builtins.str] = None,
        dimensions_map: typing.Optional[typing.Mapping[builtins.str, builtins.str]] = None,
        id: typing.Optional[builtins.str] = None,
        label: typing.Optional[builtins.str] = None,
        period: typing.Optional["_aws_cdk_ceddda9d.Duration"] = None,
        region: typing.Optional[builtins.str] = None,
        stack_account: typing.Optional[builtins.str] = None,
        stack_region: typing.Optional[builtins.str] = None,
        statistic: typing.Optional[builtins.str] = None,
        unit: typing.Optional["_aws_cdk_aws_cloudwatch_ceddda9d.Unit"] = None,
        visible: typing.Optional[builtins.bool] = None,
    ) -> "_aws_cdk_aws_cloudwatch_ceddda9d.Metric":
        '''(experimental) Returns Metric for Egress Bytes.

        :param account: Account which this metric comes from. Default: - Deployment account.
        :param color: The hex color code, prefixed with '#' (e.g. '#00ff00'), to use when this metric is rendered on a graph. The ``Color`` class has a set of standard colors that can be used here. Default: - Automatic color
        :param dimensions_map: Dimensions of the metric. Default: - No dimensions.
        :param id: Unique identifier for this metric when used in dashboard widgets. The id can be used as a variable to represent this metric in math expressions. Valid characters are letters, numbers, and underscore. The first character must be a lowercase letter. Default: - No ID
        :param label: Label for this metric when added to a Graph in a Dashboard. You can use `dynamic labels <https://docs.aws.amazon.com/AmazonCloudWatch/latest/monitoring/graph-dynamic-labels.html>`_ to show summary information about the entire displayed time series in the legend. For example, if you use:: [max: ${MAX}] MyMetric As the metric label, the maximum value in the visible range will be shown next to the time series name in the graph's legend. Default: - No label
        :param period: The period over which the specified statistic is applied. Default: Duration.minutes(5)
        :param region: Region which this metric comes from. Default: - Deployment region.
        :param stack_account: Account of the stack this metric is attached to. Default: - Deployment account.
        :param stack_region: Region of the stack this metric is attached to. Default: - Deployment region.
        :param statistic: What function to use for aggregating. Use the ``aws_cloudwatch.Stats`` helper class to construct valid input strings. Can be one of the following: - "Minimum" | "min" - "Maximum" | "max" - "Average" | "avg" - "Sum" | "sum" - "SampleCount | "n" - "pNN.NN" - "tmNN.NN" | "tm(NN.NN%:NN.NN%)" - "iqm" - "wmNN.NN" | "wm(NN.NN%:NN.NN%)" - "tcNN.NN" | "tc(NN.NN%:NN.NN%)" - "tsNN.NN" | "ts(NN.NN%:NN.NN%)" Default: Average
        :param unit: Unit used to filter the metric stream. Only refer to datums emitted to the metric stream with the given unit and ignore all others. Only useful when datums are being emitted to the same metric stream under different units. The default is to use all matric datums in the stream, regardless of unit, which is recommended in nearly all cases. CloudWatch does not honor this property for graphs. Default: - All metric datums in the given metric stream
        :param visible: Whether this metric should be visible in dashboard graphs. Setting this to false is useful when you want to hide raw metrics that are used in math expressions, and show only the expression results. Default: true

        :default: - sum over 60 seconds

        :stability: experimental
        '''
        options = _aws_cdk_aws_cloudwatch_ceddda9d.MetricOptions(
            account=account,
            color=color,
            dimensions_map=dimensions_map,
            id=id,
            label=label,
            period=period,
            region=region,
            stack_account=stack_account,
            stack_region=stack_region,
            statistic=statistic,
            unit=unit,
            visible=visible,
        )

        return typing.cast("_aws_cdk_aws_cloudwatch_ceddda9d.Metric", jsii.invoke(self, "metricEgressBytes", [options]))

    @jsii.member(jsii_name="metricEgressRequestCount")
    def metric_egress_request_count(
        self,
        *,
        account: typing.Optional[builtins.str] = None,
        color: typing.Optional[builtins.str] = None,
        dimensions_map: typing.Optional[typing.Mapping[builtins.str, builtins.str]] = None,
        id: typing.Optional[builtins.str] = None,
        label: typing.Optional[builtins.str] = None,
        period: typing.Optional["_aws_cdk_ceddda9d.Duration"] = None,
        region: typing.Optional[builtins.str] = None,
        stack_account: typing.Optional[builtins.str] = None,
        stack_region: typing.Optional[builtins.str] = None,
        statistic: typing.Optional[builtins.str] = None,
        unit: typing.Optional["_aws_cdk_aws_cloudwatch_ceddda9d.Unit"] = None,
        visible: typing.Optional[builtins.bool] = None,
    ) -> "_aws_cdk_aws_cloudwatch_ceddda9d.Metric":
        '''(experimental) Returns Metric for Egress Request Count.

        :param account: Account which this metric comes from. Default: - Deployment account.
        :param color: The hex color code, prefixed with '#' (e.g. '#00ff00'), to use when this metric is rendered on a graph. The ``Color`` class has a set of standard colors that can be used here. Default: - Automatic color
        :param dimensions_map: Dimensions of the metric. Default: - No dimensions.
        :param id: Unique identifier for this metric when used in dashboard widgets. The id can be used as a variable to represent this metric in math expressions. Valid characters are letters, numbers, and underscore. The first character must be a lowercase letter. Default: - No ID
        :param label: Label for this metric when added to a Graph in a Dashboard. You can use `dynamic labels <https://docs.aws.amazon.com/AmazonCloudWatch/latest/monitoring/graph-dynamic-labels.html>`_ to show summary information about the entire displayed time series in the legend. For example, if you use:: [max: ${MAX}] MyMetric As the metric label, the maximum value in the visible range will be shown next to the time series name in the graph's legend. Default: - No label
        :param period: The period over which the specified statistic is applied. Default: Duration.minutes(5)
        :param region: Region which this metric comes from. Default: - Deployment region.
        :param stack_account: Account of the stack this metric is attached to. Default: - Deployment account.
        :param stack_region: Region of the stack this metric is attached to. Default: - Deployment region.
        :param statistic: What function to use for aggregating. Use the ``aws_cloudwatch.Stats`` helper class to construct valid input strings. Can be one of the following: - "Minimum" | "min" - "Maximum" | "max" - "Average" | "avg" - "Sum" | "sum" - "SampleCount | "n" - "pNN.NN" - "tmNN.NN" | "tm(NN.NN%:NN.NN%)" - "iqm" - "wmNN.NN" | "wm(NN.NN%:NN.NN%)" - "tcNN.NN" | "tc(NN.NN%:NN.NN%)" - "tsNN.NN" | "ts(NN.NN%:NN.NN%)" Default: Average
        :param unit: Unit used to filter the metric stream. Only refer to datums emitted to the metric stream with the given unit and ignore all others. Only useful when datums are being emitted to the same metric stream under different units. The default is to use all matric datums in the stream, regardless of unit, which is recommended in nearly all cases. CloudWatch does not honor this property for graphs. Default: - All metric datums in the given metric stream
        :param visible: Whether this metric should be visible in dashboard graphs. Setting this to false is useful when you want to hide raw metrics that are used in math expressions, and show only the expression results. Default: true

        :default: - sum over 60 seconds

        :stability: experimental
        '''
        options = _aws_cdk_aws_cloudwatch_ceddda9d.MetricOptions(
            account=account,
            color=color,
            dimensions_map=dimensions_map,
            id=id,
            label=label,
            period=period,
            region=region,
            stack_account=stack_account,
            stack_region=stack_region,
            statistic=statistic,
            unit=unit,
            visible=visible,
        )

        return typing.cast("_aws_cdk_aws_cloudwatch_ceddda9d.Metric", jsii.invoke(self, "metricEgressRequestCount", [options]))

    @jsii.member(jsii_name="metricEgressResponseTime")
    def metric_egress_response_time(
        self,
        *,
        account: typing.Optional[builtins.str] = None,
        color: typing.Optional[builtins.str] = None,
        dimensions_map: typing.Optional[typing.Mapping[builtins.str, builtins.str]] = None,
        id: typing.Optional[builtins.str] = None,
        label: typing.Optional[builtins.str] = None,
        period: typing.Optional["_aws_cdk_ceddda9d.Duration"] = None,
        region: typing.Optional[builtins.str] = None,
        stack_account: typing.Optional[builtins.str] = None,
        stack_region: typing.Optional[builtins.str] = None,
        statistic: typing.Optional[builtins.str] = None,
        unit: typing.Optional["_aws_cdk_aws_cloudwatch_ceddda9d.Unit"] = None,
        visible: typing.Optional[builtins.bool] = None,
    ) -> "_aws_cdk_aws_cloudwatch_ceddda9d.Metric":
        '''(experimental) Returns Metric for Egress Response time.

        :param account: Account which this metric comes from. Default: - Deployment account.
        :param color: The hex color code, prefixed with '#' (e.g. '#00ff00'), to use when this metric is rendered on a graph. The ``Color`` class has a set of standard colors that can be used here. Default: - Automatic color
        :param dimensions_map: Dimensions of the metric. Default: - No dimensions.
        :param id: Unique identifier for this metric when used in dashboard widgets. The id can be used as a variable to represent this metric in math expressions. Valid characters are letters, numbers, and underscore. The first character must be a lowercase letter. Default: - No ID
        :param label: Label for this metric when added to a Graph in a Dashboard. You can use `dynamic labels <https://docs.aws.amazon.com/AmazonCloudWatch/latest/monitoring/graph-dynamic-labels.html>`_ to show summary information about the entire displayed time series in the legend. For example, if you use:: [max: ${MAX}] MyMetric As the metric label, the maximum value in the visible range will be shown next to the time series name in the graph's legend. Default: - No label
        :param period: The period over which the specified statistic is applied. Default: Duration.minutes(5)
        :param region: Region which this metric comes from. Default: - Deployment region.
        :param stack_account: Account of the stack this metric is attached to. Default: - Deployment account.
        :param stack_region: Region of the stack this metric is attached to. Default: - Deployment region.
        :param statistic: What function to use for aggregating. Use the ``aws_cloudwatch.Stats`` helper class to construct valid input strings. Can be one of the following: - "Minimum" | "min" - "Maximum" | "max" - "Average" | "avg" - "Sum" | "sum" - "SampleCount | "n" - "pNN.NN" - "tmNN.NN" | "tm(NN.NN%:NN.NN%)" - "iqm" - "wmNN.NN" | "wm(NN.NN%:NN.NN%)" - "tcNN.NN" | "tc(NN.NN%:NN.NN%)" - "tsNN.NN" | "ts(NN.NN%:NN.NN%)" Default: Average
        :param unit: Unit used to filter the metric stream. Only refer to datums emitted to the metric stream with the given unit and ignore all others. Only useful when datums are being emitted to the same metric stream under different units. The default is to use all matric datums in the stream, regardless of unit, which is recommended in nearly all cases. CloudWatch does not honor this property for graphs. Default: - All metric datums in the given metric stream
        :param visible: Whether this metric should be visible in dashboard graphs. Setting this to false is useful when you want to hide raw metrics that are used in math expressions, and show only the expression results. Default: true

        :default: - average over 60 seconds

        :stability: experimental
        '''
        options = _aws_cdk_aws_cloudwatch_ceddda9d.MetricOptions(
            account=account,
            color=color,
            dimensions_map=dimensions_map,
            id=id,
            label=label,
            period=period,
            region=region,
            stack_account=stack_account,
            stack_region=stack_region,
            statistic=statistic,
            unit=unit,
            visible=visible,
        )

        return typing.cast("_aws_cdk_aws_cloudwatch_ceddda9d.Metric", jsii.invoke(self, "metricEgressResponseTime", [options]))

    @jsii.member(jsii_name="metricIngressBytes")
    def metric_ingress_bytes(
        self,
        *,
        account: typing.Optional[builtins.str] = None,
        color: typing.Optional[builtins.str] = None,
        dimensions_map: typing.Optional[typing.Mapping[builtins.str, builtins.str]] = None,
        id: typing.Optional[builtins.str] = None,
        label: typing.Optional[builtins.str] = None,
        period: typing.Optional["_aws_cdk_ceddda9d.Duration"] = None,
        region: typing.Optional[builtins.str] = None,
        stack_account: typing.Optional[builtins.str] = None,
        stack_region: typing.Optional[builtins.str] = None,
        statistic: typing.Optional[builtins.str] = None,
        unit: typing.Optional["_aws_cdk_aws_cloudwatch_ceddda9d.Unit"] = None,
        visible: typing.Optional[builtins.bool] = None,
    ) -> "_aws_cdk_aws_cloudwatch_ceddda9d.Metric":
        '''(experimental) Returns Metric for Ingress Bytes.

        :param account: Account which this metric comes from. Default: - Deployment account.
        :param color: The hex color code, prefixed with '#' (e.g. '#00ff00'), to use when this metric is rendered on a graph. The ``Color`` class has a set of standard colors that can be used here. Default: - Automatic color
        :param dimensions_map: Dimensions of the metric. Default: - No dimensions.
        :param id: Unique identifier for this metric when used in dashboard widgets. The id can be used as a variable to represent this metric in math expressions. Valid characters are letters, numbers, and underscore. The first character must be a lowercase letter. Default: - No ID
        :param label: Label for this metric when added to a Graph in a Dashboard. You can use `dynamic labels <https://docs.aws.amazon.com/AmazonCloudWatch/latest/monitoring/graph-dynamic-labels.html>`_ to show summary information about the entire displayed time series in the legend. For example, if you use:: [max: ${MAX}] MyMetric As the metric label, the maximum value in the visible range will be shown next to the time series name in the graph's legend. Default: - No label
        :param period: The period over which the specified statistic is applied. Default: Duration.minutes(5)
        :param region: Region which this metric comes from. Default: - Deployment region.
        :param stack_account: Account of the stack this metric is attached to. Default: - Deployment account.
        :param stack_region: Region of the stack this metric is attached to. Default: - Deployment region.
        :param statistic: What function to use for aggregating. Use the ``aws_cloudwatch.Stats`` helper class to construct valid input strings. Can be one of the following: - "Minimum" | "min" - "Maximum" | "max" - "Average" | "avg" - "Sum" | "sum" - "SampleCount | "n" - "pNN.NN" - "tmNN.NN" | "tm(NN.NN%:NN.NN%)" - "iqm" - "wmNN.NN" | "wm(NN.NN%:NN.NN%)" - "tcNN.NN" | "tc(NN.NN%:NN.NN%)" - "tsNN.NN" | "ts(NN.NN%:NN.NN%)" Default: Average
        :param unit: Unit used to filter the metric stream. Only refer to datums emitted to the metric stream with the given unit and ignore all others. Only useful when datums are being emitted to the same metric stream under different units. The default is to use all matric datums in the stream, regardless of unit, which is recommended in nearly all cases. CloudWatch does not honor this property for graphs. Default: - All metric datums in the given metric stream
        :param visible: Whether this metric should be visible in dashboard graphs. Setting this to false is useful when you want to hide raw metrics that are used in math expressions, and show only the expression results. Default: true

        :default: - sum over 60 seconds

        :stability: experimental
        '''
        options = _aws_cdk_aws_cloudwatch_ceddda9d.MetricOptions(
            account=account,
            color=color,
            dimensions_map=dimensions_map,
            id=id,
            label=label,
            period=period,
            region=region,
            stack_account=stack_account,
            stack_region=stack_region,
            statistic=statistic,
            unit=unit,
            visible=visible,
        )

        return typing.cast("_aws_cdk_aws_cloudwatch_ceddda9d.Metric", jsii.invoke(self, "metricIngressBytes", [options]))

    @jsii.member(jsii_name="metricIngressRequestCount")
    def metric_ingress_request_count(
        self,
        *,
        account: typing.Optional[builtins.str] = None,
        color: typing.Optional[builtins.str] = None,
        dimensions_map: typing.Optional[typing.Mapping[builtins.str, builtins.str]] = None,
        id: typing.Optional[builtins.str] = None,
        label: typing.Optional[builtins.str] = None,
        period: typing.Optional["_aws_cdk_ceddda9d.Duration"] = None,
        region: typing.Optional[builtins.str] = None,
        stack_account: typing.Optional[builtins.str] = None,
        stack_region: typing.Optional[builtins.str] = None,
        statistic: typing.Optional[builtins.str] = None,
        unit: typing.Optional["_aws_cdk_aws_cloudwatch_ceddda9d.Unit"] = None,
        visible: typing.Optional[builtins.bool] = None,
    ) -> "_aws_cdk_aws_cloudwatch_ceddda9d.Metric":
        '''(experimental) Returns Metric for Ingress Request Count.

        :param account: Account which this metric comes from. Default: - Deployment account.
        :param color: The hex color code, prefixed with '#' (e.g. '#00ff00'), to use when this metric is rendered on a graph. The ``Color`` class has a set of standard colors that can be used here. Default: - Automatic color
        :param dimensions_map: Dimensions of the metric. Default: - No dimensions.
        :param id: Unique identifier for this metric when used in dashboard widgets. The id can be used as a variable to represent this metric in math expressions. Valid characters are letters, numbers, and underscore. The first character must be a lowercase letter. Default: - No ID
        :param label: Label for this metric when added to a Graph in a Dashboard. You can use `dynamic labels <https://docs.aws.amazon.com/AmazonCloudWatch/latest/monitoring/graph-dynamic-labels.html>`_ to show summary information about the entire displayed time series in the legend. For example, if you use:: [max: ${MAX}] MyMetric As the metric label, the maximum value in the visible range will be shown next to the time series name in the graph's legend. Default: - No label
        :param period: The period over which the specified statistic is applied. Default: Duration.minutes(5)
        :param region: Region which this metric comes from. Default: - Deployment region.
        :param stack_account: Account of the stack this metric is attached to. Default: - Deployment account.
        :param stack_region: Region of the stack this metric is attached to. Default: - Deployment region.
        :param statistic: What function to use for aggregating. Use the ``aws_cloudwatch.Stats`` helper class to construct valid input strings. Can be one of the following: - "Minimum" | "min" - "Maximum" | "max" - "Average" | "avg" - "Sum" | "sum" - "SampleCount | "n" - "pNN.NN" - "tmNN.NN" | "tm(NN.NN%:NN.NN%)" - "iqm" - "wmNN.NN" | "wm(NN.NN%:NN.NN%)" - "tcNN.NN" | "tc(NN.NN%:NN.NN%)" - "tsNN.NN" | "ts(NN.NN%:NN.NN%)" Default: Average
        :param unit: Unit used to filter the metric stream. Only refer to datums emitted to the metric stream with the given unit and ignore all others. Only useful when datums are being emitted to the same metric stream under different units. The default is to use all matric datums in the stream, regardless of unit, which is recommended in nearly all cases. CloudWatch does not honor this property for graphs. Default: - All metric datums in the given metric stream
        :param visible: Whether this metric should be visible in dashboard graphs. Setting this to false is useful when you want to hide raw metrics that are used in math expressions, and show only the expression results. Default: true

        :default: - sum over 60 seconds

        :stability: experimental
        '''
        options = _aws_cdk_aws_cloudwatch_ceddda9d.MetricOptions(
            account=account,
            color=color,
            dimensions_map=dimensions_map,
            id=id,
            label=label,
            period=period,
            region=region,
            stack_account=stack_account,
            stack_region=stack_region,
            statistic=statistic,
            unit=unit,
            visible=visible,
        )

        return typing.cast("_aws_cdk_aws_cloudwatch_ceddda9d.Metric", jsii.invoke(self, "metricIngressRequestCount", [options]))

    @jsii.member(jsii_name="metricIngressResponseTime")
    def metric_ingress_response_time(
        self,
        *,
        account: typing.Optional[builtins.str] = None,
        color: typing.Optional[builtins.str] = None,
        dimensions_map: typing.Optional[typing.Mapping[builtins.str, builtins.str]] = None,
        id: typing.Optional[builtins.str] = None,
        label: typing.Optional[builtins.str] = None,
        period: typing.Optional["_aws_cdk_ceddda9d.Duration"] = None,
        region: typing.Optional[builtins.str] = None,
        stack_account: typing.Optional[builtins.str] = None,
        stack_region: typing.Optional[builtins.str] = None,
        statistic: typing.Optional[builtins.str] = None,
        unit: typing.Optional["_aws_cdk_aws_cloudwatch_ceddda9d.Unit"] = None,
        visible: typing.Optional[builtins.bool] = None,
    ) -> "_aws_cdk_aws_cloudwatch_ceddda9d.Metric":
        '''(experimental) Returns Metric for Ingress response time.

        :param account: Account which this metric comes from. Default: - Deployment account.
        :param color: The hex color code, prefixed with '#' (e.g. '#00ff00'), to use when this metric is rendered on a graph. The ``Color`` class has a set of standard colors that can be used here. Default: - Automatic color
        :param dimensions_map: Dimensions of the metric. Default: - No dimensions.
        :param id: Unique identifier for this metric when used in dashboard widgets. The id can be used as a variable to represent this metric in math expressions. Valid characters are letters, numbers, and underscore. The first character must be a lowercase letter. Default: - No ID
        :param label: Label for this metric when added to a Graph in a Dashboard. You can use `dynamic labels <https://docs.aws.amazon.com/AmazonCloudWatch/latest/monitoring/graph-dynamic-labels.html>`_ to show summary information about the entire displayed time series in the legend. For example, if you use:: [max: ${MAX}] MyMetric As the metric label, the maximum value in the visible range will be shown next to the time series name in the graph's legend. Default: - No label
        :param period: The period over which the specified statistic is applied. Default: Duration.minutes(5)
        :param region: Region which this metric comes from. Default: - Deployment region.
        :param stack_account: Account of the stack this metric is attached to. Default: - Deployment account.
        :param stack_region: Region of the stack this metric is attached to. Default: - Deployment region.
        :param statistic: What function to use for aggregating. Use the ``aws_cloudwatch.Stats`` helper class to construct valid input strings. Can be one of the following: - "Minimum" | "min" - "Maximum" | "max" - "Average" | "avg" - "Sum" | "sum" - "SampleCount | "n" - "pNN.NN" - "tmNN.NN" | "tm(NN.NN%:NN.NN%)" - "iqm" - "wmNN.NN" | "wm(NN.NN%:NN.NN%)" - "tcNN.NN" | "tc(NN.NN%:NN.NN%)" - "tsNN.NN" | "ts(NN.NN%:NN.NN%)" Default: Average
        :param unit: Unit used to filter the metric stream. Only refer to datums emitted to the metric stream with the given unit and ignore all others. Only useful when datums are being emitted to the same metric stream under different units. The default is to use all matric datums in the stream, regardless of unit, which is recommended in nearly all cases. CloudWatch does not honor this property for graphs. Default: - All metric datums in the given metric stream
        :param visible: Whether this metric should be visible in dashboard graphs. Setting this to false is useful when you want to hide raw metrics that are used in math expressions, and show only the expression results. Default: true

        :default: - average over 60 seconds

        :stability: experimental
        '''
        options = _aws_cdk_aws_cloudwatch_ceddda9d.MetricOptions(
            account=account,
            color=color,
            dimensions_map=dimensions_map,
            id=id,
            label=label,
            period=period,
            region=region,
            stack_account=stack_account,
            stack_region=stack_region,
            statistic=statistic,
            unit=unit,
            visible=visible,
        )

        return typing.cast("_aws_cdk_aws_cloudwatch_ceddda9d.Metric", jsii.invoke(self, "metricIngressResponseTime", [options]))

# Adding a "__jsii_proxy_class__(): typing.Type" function to the interface
typing.cast(typing.Any, IChannel).__jsii_proxy_class__ = lambda : _IChannelProxy


@jsii.interface(jsii_type="@aws-cdk/aws-mediapackagev2-alpha.IChannelGroup")
class IChannelGroup(
    _aws_cdk_ceddda9d.IResource,
    _aws_cdk_interfaces_aws_mediapackagev2_ceddda9d.IChannelGroupRef,
    typing_extensions.Protocol,
):
    '''(experimental) Interface for AWS Elemental MediaPackage V2 Channel Group.

    :stability: experimental
    '''

    @builtins.property
    @jsii.member(jsii_name="channelGroupArn")
    def channel_group_arn(self) -> builtins.str:
        '''(experimental) The Amazon Resource Name (ARN) associated with the resource.

        :stability: experimental
        :attribute: true
        '''
        ...

    @builtins.property
    @jsii.member(jsii_name="channelGroupName")
    def channel_group_name(self) -> builtins.str:
        '''(experimental) The name that describes the channel group.

        The name is the primary identifier for the channel group.

        :stability: experimental
        :attribute: true
        '''
        ...

    @builtins.property
    @jsii.member(jsii_name="egressDomain")
    def egress_domain(self) -> builtins.str:
        '''(experimental) The egress domain where packaged content is available.

        Use this as the origin domain when configuring a CDN such as Amazon CloudFront.

        :stability: experimental
        :attribute: true
        '''
        ...

    @builtins.property
    @jsii.member(jsii_name="createdAt")
    def created_at(self) -> typing.Optional[builtins.str]:
        '''(experimental) The date and time the channel group was created.

        :stability: experimental
        :attribute: true
        '''
        ...

    @builtins.property
    @jsii.member(jsii_name="modifiedAt")
    def modified_at(self) -> typing.Optional[builtins.str]:
        '''(experimental) The date and time the channel group was modified.

        :stability: experimental
        :attribute: true
        '''
        ...

    @jsii.member(jsii_name="addChannel")
    def add_channel(
        self,
        id: builtins.str,
        *,
        channel_name: typing.Optional[builtins.str] = None,
        description: typing.Optional[builtins.str] = None,
        input: typing.Optional["InputConfiguration"] = None,
        removal_policy: typing.Optional["_aws_cdk_ceddda9d.RemovalPolicy"] = None,
        tags: typing.Optional[typing.Mapping[builtins.str, builtins.str]] = None,
    ) -> "Channel":
        '''(experimental) Add Channel for this Channel Group.

        :param id: -
        :param channel_name: (experimental) The name that describes the channel. The name is the primary identifier for the channel, and must be unique for your account in the AWS Region and channel group. Default: autogenerated
        :param description: (experimental) Enter any descriptive text that helps you to identify the channel. Default: no description
        :param input: (experimental) Input configuration for the channel. Use InputConfiguration.hls() or InputConfiguration.cmaf() to create the configuration. Default: InputConfiguration.cmaf()
        :param removal_policy: (experimental) Policy to apply when the channel is removed from the stack. Even though MediaPackage ChannelGroups, Channels and OriginEndpoints are technically stateful, their contents are transient and it is common to add and remove these while rearchitecting your application. The default is therefore ``DESTROY``. Change it to ``RETAIN`` if the content (in a lookback window) are so valuable that accidentally losing it would be unacceptable. Default: RemovalPolicy.DESTROY
        :param tags: (experimental) Tags to add to the Channel. Default: No tagging

        :stability: experimental
        '''
        ...

    @jsii.member(jsii_name="metric")
    def metric(
        self,
        metric_name: builtins.str,
        *,
        account: typing.Optional[builtins.str] = None,
        color: typing.Optional[builtins.str] = None,
        dimensions_map: typing.Optional[typing.Mapping[builtins.str, builtins.str]] = None,
        id: typing.Optional[builtins.str] = None,
        label: typing.Optional[builtins.str] = None,
        period: typing.Optional["_aws_cdk_ceddda9d.Duration"] = None,
        region: typing.Optional[builtins.str] = None,
        stack_account: typing.Optional[builtins.str] = None,
        stack_region: typing.Optional[builtins.str] = None,
        statistic: typing.Optional[builtins.str] = None,
        unit: typing.Optional["_aws_cdk_aws_cloudwatch_ceddda9d.Unit"] = None,
        visible: typing.Optional[builtins.bool] = None,
    ) -> "_aws_cdk_aws_cloudwatch_ceddda9d.Metric":
        '''(experimental) Create a CloudWatch metric.

        :param metric_name: name of the metric.
        :param account: Account which this metric comes from. Default: - Deployment account.
        :param color: The hex color code, prefixed with '#' (e.g. '#00ff00'), to use when this metric is rendered on a graph. The ``Color`` class has a set of standard colors that can be used here. Default: - Automatic color
        :param dimensions_map: Dimensions of the metric. Default: - No dimensions.
        :param id: Unique identifier for this metric when used in dashboard widgets. The id can be used as a variable to represent this metric in math expressions. Valid characters are letters, numbers, and underscore. The first character must be a lowercase letter. Default: - No ID
        :param label: Label for this metric when added to a Graph in a Dashboard. You can use `dynamic labels <https://docs.aws.amazon.com/AmazonCloudWatch/latest/monitoring/graph-dynamic-labels.html>`_ to show summary information about the entire displayed time series in the legend. For example, if you use:: [max: ${MAX}] MyMetric As the metric label, the maximum value in the visible range will be shown next to the time series name in the graph's legend. Default: - No label
        :param period: The period over which the specified statistic is applied. Default: Duration.minutes(5)
        :param region: Region which this metric comes from. Default: - Deployment region.
        :param stack_account: Account of the stack this metric is attached to. Default: - Deployment account.
        :param stack_region: Region of the stack this metric is attached to. Default: - Deployment region.
        :param statistic: What function to use for aggregating. Use the ``aws_cloudwatch.Stats`` helper class to construct valid input strings. Can be one of the following: - "Minimum" | "min" - "Maximum" | "max" - "Average" | "avg" - "Sum" | "sum" - "SampleCount | "n" - "pNN.NN" - "tmNN.NN" | "tm(NN.NN%:NN.NN%)" - "iqm" - "wmNN.NN" | "wm(NN.NN%:NN.NN%)" - "tcNN.NN" | "tc(NN.NN%:NN.NN%)" - "tsNN.NN" | "ts(NN.NN%:NN.NN%)" Default: Average
        :param unit: Unit used to filter the metric stream. Only refer to datums emitted to the metric stream with the given unit and ignore all others. Only useful when datums are being emitted to the same metric stream under different units. The default is to use all matric datums in the stream, regardless of unit, which is recommended in nearly all cases. CloudWatch does not honor this property for graphs. Default: - All metric datums in the given metric stream
        :param visible: Whether this metric should be visible in dashboard graphs. Setting this to false is useful when you want to hide raw metrics that are used in math expressions, and show only the expression results. Default: true

        :stability: experimental
        '''
        ...

    @jsii.member(jsii_name="metricEgressBytes")
    def metric_egress_bytes(
        self,
        *,
        account: typing.Optional[builtins.str] = None,
        color: typing.Optional[builtins.str] = None,
        dimensions_map: typing.Optional[typing.Mapping[builtins.str, builtins.str]] = None,
        id: typing.Optional[builtins.str] = None,
        label: typing.Optional[builtins.str] = None,
        period: typing.Optional["_aws_cdk_ceddda9d.Duration"] = None,
        region: typing.Optional[builtins.str] = None,
        stack_account: typing.Optional[builtins.str] = None,
        stack_region: typing.Optional[builtins.str] = None,
        statistic: typing.Optional[builtins.str] = None,
        unit: typing.Optional["_aws_cdk_aws_cloudwatch_ceddda9d.Unit"] = None,
        visible: typing.Optional[builtins.bool] = None,
    ) -> "_aws_cdk_aws_cloudwatch_ceddda9d.Metric":
        '''(experimental) Returns Metric for Egress Bytes.

        :param account: Account which this metric comes from. Default: - Deployment account.
        :param color: The hex color code, prefixed with '#' (e.g. '#00ff00'), to use when this metric is rendered on a graph. The ``Color`` class has a set of standard colors that can be used here. Default: - Automatic color
        :param dimensions_map: Dimensions of the metric. Default: - No dimensions.
        :param id: Unique identifier for this metric when used in dashboard widgets. The id can be used as a variable to represent this metric in math expressions. Valid characters are letters, numbers, and underscore. The first character must be a lowercase letter. Default: - No ID
        :param label: Label for this metric when added to a Graph in a Dashboard. You can use `dynamic labels <https://docs.aws.amazon.com/AmazonCloudWatch/latest/monitoring/graph-dynamic-labels.html>`_ to show summary information about the entire displayed time series in the legend. For example, if you use:: [max: ${MAX}] MyMetric As the metric label, the maximum value in the visible range will be shown next to the time series name in the graph's legend. Default: - No label
        :param period: The period over which the specified statistic is applied. Default: Duration.minutes(5)
        :param region: Region which this metric comes from. Default: - Deployment region.
        :param stack_account: Account of the stack this metric is attached to. Default: - Deployment account.
        :param stack_region: Region of the stack this metric is attached to. Default: - Deployment region.
        :param statistic: What function to use for aggregating. Use the ``aws_cloudwatch.Stats`` helper class to construct valid input strings. Can be one of the following: - "Minimum" | "min" - "Maximum" | "max" - "Average" | "avg" - "Sum" | "sum" - "SampleCount | "n" - "pNN.NN" - "tmNN.NN" | "tm(NN.NN%:NN.NN%)" - "iqm" - "wmNN.NN" | "wm(NN.NN%:NN.NN%)" - "tcNN.NN" | "tc(NN.NN%:NN.NN%)" - "tsNN.NN" | "ts(NN.NN%:NN.NN%)" Default: Average
        :param unit: Unit used to filter the metric stream. Only refer to datums emitted to the metric stream with the given unit and ignore all others. Only useful when datums are being emitted to the same metric stream under different units. The default is to use all matric datums in the stream, regardless of unit, which is recommended in nearly all cases. CloudWatch does not honor this property for graphs. Default: - All metric datums in the given metric stream
        :param visible: Whether this metric should be visible in dashboard graphs. Setting this to false is useful when you want to hide raw metrics that are used in math expressions, and show only the expression results. Default: true

        :default: - sum over 60 seconds

        :stability: experimental
        '''
        ...

    @jsii.member(jsii_name="metricEgressRequestCount")
    def metric_egress_request_count(
        self,
        *,
        account: typing.Optional[builtins.str] = None,
        color: typing.Optional[builtins.str] = None,
        dimensions_map: typing.Optional[typing.Mapping[builtins.str, builtins.str]] = None,
        id: typing.Optional[builtins.str] = None,
        label: typing.Optional[builtins.str] = None,
        period: typing.Optional["_aws_cdk_ceddda9d.Duration"] = None,
        region: typing.Optional[builtins.str] = None,
        stack_account: typing.Optional[builtins.str] = None,
        stack_region: typing.Optional[builtins.str] = None,
        statistic: typing.Optional[builtins.str] = None,
        unit: typing.Optional["_aws_cdk_aws_cloudwatch_ceddda9d.Unit"] = None,
        visible: typing.Optional[builtins.bool] = None,
    ) -> "_aws_cdk_aws_cloudwatch_ceddda9d.Metric":
        '''(experimental) Returns Metric for Egress Request Count.

        :param account: Account which this metric comes from. Default: - Deployment account.
        :param color: The hex color code, prefixed with '#' (e.g. '#00ff00'), to use when this metric is rendered on a graph. The ``Color`` class has a set of standard colors that can be used here. Default: - Automatic color
        :param dimensions_map: Dimensions of the metric. Default: - No dimensions.
        :param id: Unique identifier for this metric when used in dashboard widgets. The id can be used as a variable to represent this metric in math expressions. Valid characters are letters, numbers, and underscore. The first character must be a lowercase letter. Default: - No ID
        :param label: Label for this metric when added to a Graph in a Dashboard. You can use `dynamic labels <https://docs.aws.amazon.com/AmazonCloudWatch/latest/monitoring/graph-dynamic-labels.html>`_ to show summary information about the entire displayed time series in the legend. For example, if you use:: [max: ${MAX}] MyMetric As the metric label, the maximum value in the visible range will be shown next to the time series name in the graph's legend. Default: - No label
        :param period: The period over which the specified statistic is applied. Default: Duration.minutes(5)
        :param region: Region which this metric comes from. Default: - Deployment region.
        :param stack_account: Account of the stack this metric is attached to. Default: - Deployment account.
        :param stack_region: Region of the stack this metric is attached to. Default: - Deployment region.
        :param statistic: What function to use for aggregating. Use the ``aws_cloudwatch.Stats`` helper class to construct valid input strings. Can be one of the following: - "Minimum" | "min" - "Maximum" | "max" - "Average" | "avg" - "Sum" | "sum" - "SampleCount | "n" - "pNN.NN" - "tmNN.NN" | "tm(NN.NN%:NN.NN%)" - "iqm" - "wmNN.NN" | "wm(NN.NN%:NN.NN%)" - "tcNN.NN" | "tc(NN.NN%:NN.NN%)" - "tsNN.NN" | "ts(NN.NN%:NN.NN%)" Default: Average
        :param unit: Unit used to filter the metric stream. Only refer to datums emitted to the metric stream with the given unit and ignore all others. Only useful when datums are being emitted to the same metric stream under different units. The default is to use all matric datums in the stream, regardless of unit, which is recommended in nearly all cases. CloudWatch does not honor this property for graphs. Default: - All metric datums in the given metric stream
        :param visible: Whether this metric should be visible in dashboard graphs. Setting this to false is useful when you want to hide raw metrics that are used in math expressions, and show only the expression results. Default: true

        :default: - sum over 60 seconds

        :stability: experimental
        '''
        ...

    @jsii.member(jsii_name="metricEgressResponseTime")
    def metric_egress_response_time(
        self,
        *,
        account: typing.Optional[builtins.str] = None,
        color: typing.Optional[builtins.str] = None,
        dimensions_map: typing.Optional[typing.Mapping[builtins.str, builtins.str]] = None,
        id: typing.Optional[builtins.str] = None,
        label: typing.Optional[builtins.str] = None,
        period: typing.Optional["_aws_cdk_ceddda9d.Duration"] = None,
        region: typing.Optional[builtins.str] = None,
        stack_account: typing.Optional[builtins.str] = None,
        stack_region: typing.Optional[builtins.str] = None,
        statistic: typing.Optional[builtins.str] = None,
        unit: typing.Optional["_aws_cdk_aws_cloudwatch_ceddda9d.Unit"] = None,
        visible: typing.Optional[builtins.bool] = None,
    ) -> "_aws_cdk_aws_cloudwatch_ceddda9d.Metric":
        '''(experimental) Returns Metric for Egress Response time.

        :param account: Account which this metric comes from. Default: - Deployment account.
        :param color: The hex color code, prefixed with '#' (e.g. '#00ff00'), to use when this metric is rendered on a graph. The ``Color`` class has a set of standard colors that can be used here. Default: - Automatic color
        :param dimensions_map: Dimensions of the metric. Default: - No dimensions.
        :param id: Unique identifier for this metric when used in dashboard widgets. The id can be used as a variable to represent this metric in math expressions. Valid characters are letters, numbers, and underscore. The first character must be a lowercase letter. Default: - No ID
        :param label: Label for this metric when added to a Graph in a Dashboard. You can use `dynamic labels <https://docs.aws.amazon.com/AmazonCloudWatch/latest/monitoring/graph-dynamic-labels.html>`_ to show summary information about the entire displayed time series in the legend. For example, if you use:: [max: ${MAX}] MyMetric As the metric label, the maximum value in the visible range will be shown next to the time series name in the graph's legend. Default: - No label
        :param period: The period over which the specified statistic is applied. Default: Duration.minutes(5)
        :param region: Region which this metric comes from. Default: - Deployment region.
        :param stack_account: Account of the stack this metric is attached to. Default: - Deployment account.
        :param stack_region: Region of the stack this metric is attached to. Default: - Deployment region.
        :param statistic: What function to use for aggregating. Use the ``aws_cloudwatch.Stats`` helper class to construct valid input strings. Can be one of the following: - "Minimum" | "min" - "Maximum" | "max" - "Average" | "avg" - "Sum" | "sum" - "SampleCount | "n" - "pNN.NN" - "tmNN.NN" | "tm(NN.NN%:NN.NN%)" - "iqm" - "wmNN.NN" | "wm(NN.NN%:NN.NN%)" - "tcNN.NN" | "tc(NN.NN%:NN.NN%)" - "tsNN.NN" | "ts(NN.NN%:NN.NN%)" Default: Average
        :param unit: Unit used to filter the metric stream. Only refer to datums emitted to the metric stream with the given unit and ignore all others. Only useful when datums are being emitted to the same metric stream under different units. The default is to use all matric datums in the stream, regardless of unit, which is recommended in nearly all cases. CloudWatch does not honor this property for graphs. Default: - All metric datums in the given metric stream
        :param visible: Whether this metric should be visible in dashboard graphs. Setting this to false is useful when you want to hide raw metrics that are used in math expressions, and show only the expression results. Default: true

        :default: - average over 60 seconds

        :stability: experimental
        '''
        ...

    @jsii.member(jsii_name="metricIngressBytes")
    def metric_ingress_bytes(
        self,
        *,
        account: typing.Optional[builtins.str] = None,
        color: typing.Optional[builtins.str] = None,
        dimensions_map: typing.Optional[typing.Mapping[builtins.str, builtins.str]] = None,
        id: typing.Optional[builtins.str] = None,
        label: typing.Optional[builtins.str] = None,
        period: typing.Optional["_aws_cdk_ceddda9d.Duration"] = None,
        region: typing.Optional[builtins.str] = None,
        stack_account: typing.Optional[builtins.str] = None,
        stack_region: typing.Optional[builtins.str] = None,
        statistic: typing.Optional[builtins.str] = None,
        unit: typing.Optional["_aws_cdk_aws_cloudwatch_ceddda9d.Unit"] = None,
        visible: typing.Optional[builtins.bool] = None,
    ) -> "_aws_cdk_aws_cloudwatch_ceddda9d.Metric":
        '''(experimental) Returns Metric for Ingress Bytes.

        :param account: Account which this metric comes from. Default: - Deployment account.
        :param color: The hex color code, prefixed with '#' (e.g. '#00ff00'), to use when this metric is rendered on a graph. The ``Color`` class has a set of standard colors that can be used here. Default: - Automatic color
        :param dimensions_map: Dimensions of the metric. Default: - No dimensions.
        :param id: Unique identifier for this metric when used in dashboard widgets. The id can be used as a variable to represent this metric in math expressions. Valid characters are letters, numbers, and underscore. The first character must be a lowercase letter. Default: - No ID
        :param label: Label for this metric when added to a Graph in a Dashboard. You can use `dynamic labels <https://docs.aws.amazon.com/AmazonCloudWatch/latest/monitoring/graph-dynamic-labels.html>`_ to show summary information about the entire displayed time series in the legend. For example, if you use:: [max: ${MAX}] MyMetric As the metric label, the maximum value in the visible range will be shown next to the time series name in the graph's legend. Default: - No label
        :param period: The period over which the specified statistic is applied. Default: Duration.minutes(5)
        :param region: Region which this metric comes from. Default: - Deployment region.
        :param stack_account: Account of the stack this metric is attached to. Default: - Deployment account.
        :param stack_region: Region of the stack this metric is attached to. Default: - Deployment region.
        :param statistic: What function to use for aggregating. Use the ``aws_cloudwatch.Stats`` helper class to construct valid input strings. Can be one of the following: - "Minimum" | "min" - "Maximum" | "max" - "Average" | "avg" - "Sum" | "sum" - "SampleCount | "n" - "pNN.NN" - "tmNN.NN" | "tm(NN.NN%:NN.NN%)" - "iqm" - "wmNN.NN" | "wm(NN.NN%:NN.NN%)" - "tcNN.NN" | "tc(NN.NN%:NN.NN%)" - "tsNN.NN" | "ts(NN.NN%:NN.NN%)" Default: Average
        :param unit: Unit used to filter the metric stream. Only refer to datums emitted to the metric stream with the given unit and ignore all others. Only useful when datums are being emitted to the same metric stream under different units. The default is to use all matric datums in the stream, regardless of unit, which is recommended in nearly all cases. CloudWatch does not honor this property for graphs. Default: - All metric datums in the given metric stream
        :param visible: Whether this metric should be visible in dashboard graphs. Setting this to false is useful when you want to hide raw metrics that are used in math expressions, and show only the expression results. Default: true

        :default: - sum over 60 seconds

        :stability: experimental
        '''
        ...

    @jsii.member(jsii_name="metricIngressRequestCount")
    def metric_ingress_request_count(
        self,
        *,
        account: typing.Optional[builtins.str] = None,
        color: typing.Optional[builtins.str] = None,
        dimensions_map: typing.Optional[typing.Mapping[builtins.str, builtins.str]] = None,
        id: typing.Optional[builtins.str] = None,
        label: typing.Optional[builtins.str] = None,
        period: typing.Optional["_aws_cdk_ceddda9d.Duration"] = None,
        region: typing.Optional[builtins.str] = None,
        stack_account: typing.Optional[builtins.str] = None,
        stack_region: typing.Optional[builtins.str] = None,
        statistic: typing.Optional[builtins.str] = None,
        unit: typing.Optional["_aws_cdk_aws_cloudwatch_ceddda9d.Unit"] = None,
        visible: typing.Optional[builtins.bool] = None,
    ) -> "_aws_cdk_aws_cloudwatch_ceddda9d.Metric":
        '''(experimental) Returns Metric for Ingress Request Count.

        :param account: Account which this metric comes from. Default: - Deployment account.
        :param color: The hex color code, prefixed with '#' (e.g. '#00ff00'), to use when this metric is rendered on a graph. The ``Color`` class has a set of standard colors that can be used here. Default: - Automatic color
        :param dimensions_map: Dimensions of the metric. Default: - No dimensions.
        :param id: Unique identifier for this metric when used in dashboard widgets. The id can be used as a variable to represent this metric in math expressions. Valid characters are letters, numbers, and underscore. The first character must be a lowercase letter. Default: - No ID
        :param label: Label for this metric when added to a Graph in a Dashboard. You can use `dynamic labels <https://docs.aws.amazon.com/AmazonCloudWatch/latest/monitoring/graph-dynamic-labels.html>`_ to show summary information about the entire displayed time series in the legend. For example, if you use:: [max: ${MAX}] MyMetric As the metric label, the maximum value in the visible range will be shown next to the time series name in the graph's legend. Default: - No label
        :param period: The period over which the specified statistic is applied. Default: Duration.minutes(5)
        :param region: Region which this metric comes from. Default: - Deployment region.
        :param stack_account: Account of the stack this metric is attached to. Default: - Deployment account.
        :param stack_region: Region of the stack this metric is attached to. Default: - Deployment region.
        :param statistic: What function to use for aggregating. Use the ``aws_cloudwatch.Stats`` helper class to construct valid input strings. Can be one of the following: - "Minimum" | "min" - "Maximum" | "max" - "Average" | "avg" - "Sum" | "sum" - "SampleCount | "n" - "pNN.NN" - "tmNN.NN" | "tm(NN.NN%:NN.NN%)" - "iqm" - "wmNN.NN" | "wm(NN.NN%:NN.NN%)" - "tcNN.NN" | "tc(NN.NN%:NN.NN%)" - "tsNN.NN" | "ts(NN.NN%:NN.NN%)" Default: Average
        :param unit: Unit used to filter the metric stream. Only refer to datums emitted to the metric stream with the given unit and ignore all others. Only useful when datums are being emitted to the same metric stream under different units. The default is to use all matric datums in the stream, regardless of unit, which is recommended in nearly all cases. CloudWatch does not honor this property for graphs. Default: - All metric datums in the given metric stream
        :param visible: Whether this metric should be visible in dashboard graphs. Setting this to false is useful when you want to hide raw metrics that are used in math expressions, and show only the expression results. Default: true

        :default: - sum over 60 seconds

        :stability: experimental
        '''
        ...

    @jsii.member(jsii_name="metricIngressResponseTime")
    def metric_ingress_response_time(
        self,
        *,
        account: typing.Optional[builtins.str] = None,
        color: typing.Optional[builtins.str] = None,
        dimensions_map: typing.Optional[typing.Mapping[builtins.str, builtins.str]] = None,
        id: typing.Optional[builtins.str] = None,
        label: typing.Optional[builtins.str] = None,
        period: typing.Optional["_aws_cdk_ceddda9d.Duration"] = None,
        region: typing.Optional[builtins.str] = None,
        stack_account: typing.Optional[builtins.str] = None,
        stack_region: typing.Optional[builtins.str] = None,
        statistic: typing.Optional[builtins.str] = None,
        unit: typing.Optional["_aws_cdk_aws_cloudwatch_ceddda9d.Unit"] = None,
        visible: typing.Optional[builtins.bool] = None,
    ) -> "_aws_cdk_aws_cloudwatch_ceddda9d.Metric":
        '''(experimental) Returns Metric for Ingress response time.

        :param account: Account which this metric comes from. Default: - Deployment account.
        :param color: The hex color code, prefixed with '#' (e.g. '#00ff00'), to use when this metric is rendered on a graph. The ``Color`` class has a set of standard colors that can be used here. Default: - Automatic color
        :param dimensions_map: Dimensions of the metric. Default: - No dimensions.
        :param id: Unique identifier for this metric when used in dashboard widgets. The id can be used as a variable to represent this metric in math expressions. Valid characters are letters, numbers, and underscore. The first character must be a lowercase letter. Default: - No ID
        :param label: Label for this metric when added to a Graph in a Dashboard. You can use `dynamic labels <https://docs.aws.amazon.com/AmazonCloudWatch/latest/monitoring/graph-dynamic-labels.html>`_ to show summary information about the entire displayed time series in the legend. For example, if you use:: [max: ${MAX}] MyMetric As the metric label, the maximum value in the visible range will be shown next to the time series name in the graph's legend. Default: - No label
        :param period: The period over which the specified statistic is applied. Default: Duration.minutes(5)
        :param region: Region which this metric comes from. Default: - Deployment region.
        :param stack_account: Account of the stack this metric is attached to. Default: - Deployment account.
        :param stack_region: Region of the stack this metric is attached to. Default: - Deployment region.
        :param statistic: What function to use for aggregating. Use the ``aws_cloudwatch.Stats`` helper class to construct valid input strings. Can be one of the following: - "Minimum" | "min" - "Maximum" | "max" - "Average" | "avg" - "Sum" | "sum" - "SampleCount | "n" - "pNN.NN" - "tmNN.NN" | "tm(NN.NN%:NN.NN%)" - "iqm" - "wmNN.NN" | "wm(NN.NN%:NN.NN%)" - "tcNN.NN" | "tc(NN.NN%:NN.NN%)" - "tsNN.NN" | "ts(NN.NN%:NN.NN%)" Default: Average
        :param unit: Unit used to filter the metric stream. Only refer to datums emitted to the metric stream with the given unit and ignore all others. Only useful when datums are being emitted to the same metric stream under different units. The default is to use all matric datums in the stream, regardless of unit, which is recommended in nearly all cases. CloudWatch does not honor this property for graphs. Default: - All metric datums in the given metric stream
        :param visible: Whether this metric should be visible in dashboard graphs. Setting this to false is useful when you want to hide raw metrics that are used in math expressions, and show only the expression results. Default: true

        :default: - average over 60 seconds

        :stability: experimental
        '''
        ...


class _IChannelGroupProxy(
    jsii.proxy_for(_aws_cdk_ceddda9d.IResource), # type: ignore[misc]
    jsii.proxy_for(_aws_cdk_interfaces_aws_mediapackagev2_ceddda9d.IChannelGroupRef), # type: ignore[misc]
):
    '''(experimental) Interface for AWS Elemental MediaPackage V2 Channel Group.

    :stability: experimental
    '''

    __jsii_type__: typing.ClassVar[str] = "@aws-cdk/aws-mediapackagev2-alpha.IChannelGroup"

    @builtins.property
    @jsii.member(jsii_name="channelGroupArn")
    def channel_group_arn(self) -> builtins.str:
        '''(experimental) The Amazon Resource Name (ARN) associated with the resource.

        :stability: experimental
        :attribute: true
        '''
        return typing.cast(builtins.str, jsii.get(self, "channelGroupArn"))

    @builtins.property
    @jsii.member(jsii_name="channelGroupName")
    def channel_group_name(self) -> builtins.str:
        '''(experimental) The name that describes the channel group.

        The name is the primary identifier for the channel group.

        :stability: experimental
        :attribute: true
        '''
        return typing.cast(builtins.str, jsii.get(self, "channelGroupName"))

    @builtins.property
    @jsii.member(jsii_name="egressDomain")
    def egress_domain(self) -> builtins.str:
        '''(experimental) The egress domain where packaged content is available.

        Use this as the origin domain when configuring a CDN such as Amazon CloudFront.

        :stability: experimental
        :attribute: true
        '''
        return typing.cast(builtins.str, jsii.get(self, "egressDomain"))

    @builtins.property
    @jsii.member(jsii_name="createdAt")
    def created_at(self) -> typing.Optional[builtins.str]:
        '''(experimental) The date and time the channel group was created.

        :stability: experimental
        :attribute: true
        '''
        return typing.cast(typing.Optional[builtins.str], jsii.get(self, "createdAt"))

    @builtins.property
    @jsii.member(jsii_name="modifiedAt")
    def modified_at(self) -> typing.Optional[builtins.str]:
        '''(experimental) The date and time the channel group was modified.

        :stability: experimental
        :attribute: true
        '''
        return typing.cast(typing.Optional[builtins.str], jsii.get(self, "modifiedAt"))

    @jsii.member(jsii_name="addChannel")
    def add_channel(
        self,
        id: builtins.str,
        *,
        channel_name: typing.Optional[builtins.str] = None,
        description: typing.Optional[builtins.str] = None,
        input: typing.Optional["InputConfiguration"] = None,
        removal_policy: typing.Optional["_aws_cdk_ceddda9d.RemovalPolicy"] = None,
        tags: typing.Optional[typing.Mapping[builtins.str, builtins.str]] = None,
    ) -> "Channel":
        '''(experimental) Add Channel for this Channel Group.

        :param id: -
        :param channel_name: (experimental) The name that describes the channel. The name is the primary identifier for the channel, and must be unique for your account in the AWS Region and channel group. Default: autogenerated
        :param description: (experimental) Enter any descriptive text that helps you to identify the channel. Default: no description
        :param input: (experimental) Input configuration for the channel. Use InputConfiguration.hls() or InputConfiguration.cmaf() to create the configuration. Default: InputConfiguration.cmaf()
        :param removal_policy: (experimental) Policy to apply when the channel is removed from the stack. Even though MediaPackage ChannelGroups, Channels and OriginEndpoints are technically stateful, their contents are transient and it is common to add and remove these while rearchitecting your application. The default is therefore ``DESTROY``. Change it to ``RETAIN`` if the content (in a lookback window) are so valuable that accidentally losing it would be unacceptable. Default: RemovalPolicy.DESTROY
        :param tags: (experimental) Tags to add to the Channel. Default: No tagging

        :stability: experimental
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__885b68da4b21c227213a6ace76c95dd1b36c90d5978e525b5064a6ee11e9b7d4)
            check_type(argname="argument id", value=id, expected_type=type_hints["id"])
        options = ChannelOptions(
            channel_name=channel_name,
            description=description,
            input=input,
            removal_policy=removal_policy,
            tags=tags,
        )

        return typing.cast("Channel", jsii.invoke(self, "addChannel", [id, options]))

    @jsii.member(jsii_name="metric")
    def metric(
        self,
        metric_name: builtins.str,
        *,
        account: typing.Optional[builtins.str] = None,
        color: typing.Optional[builtins.str] = None,
        dimensions_map: typing.Optional[typing.Mapping[builtins.str, builtins.str]] = None,
        id: typing.Optional[builtins.str] = None,
        label: typing.Optional[builtins.str] = None,
        period: typing.Optional["_aws_cdk_ceddda9d.Duration"] = None,
        region: typing.Optional[builtins.str] = None,
        stack_account: typing.Optional[builtins.str] = None,
        stack_region: typing.Optional[builtins.str] = None,
        statistic: typing.Optional[builtins.str] = None,
        unit: typing.Optional["_aws_cdk_aws_cloudwatch_ceddda9d.Unit"] = None,
        visible: typing.Optional[builtins.bool] = None,
    ) -> "_aws_cdk_aws_cloudwatch_ceddda9d.Metric":
        '''(experimental) Create a CloudWatch metric.

        :param metric_name: name of the metric.
        :param account: Account which this metric comes from. Default: - Deployment account.
        :param color: The hex color code, prefixed with '#' (e.g. '#00ff00'), to use when this metric is rendered on a graph. The ``Color`` class has a set of standard colors that can be used here. Default: - Automatic color
        :param dimensions_map: Dimensions of the metric. Default: - No dimensions.
        :param id: Unique identifier for this metric when used in dashboard widgets. The id can be used as a variable to represent this metric in math expressions. Valid characters are letters, numbers, and underscore. The first character must be a lowercase letter. Default: - No ID
        :param label: Label for this metric when added to a Graph in a Dashboard. You can use `dynamic labels <https://docs.aws.amazon.com/AmazonCloudWatch/latest/monitoring/graph-dynamic-labels.html>`_ to show summary information about the entire displayed time series in the legend. For example, if you use:: [max: ${MAX}] MyMetric As the metric label, the maximum value in the visible range will be shown next to the time series name in the graph's legend. Default: - No label
        :param period: The period over which the specified statistic is applied. Default: Duration.minutes(5)
        :param region: Region which this metric comes from. Default: - Deployment region.
        :param stack_account: Account of the stack this metric is attached to. Default: - Deployment account.
        :param stack_region: Region of the stack this metric is attached to. Default: - Deployment region.
        :param statistic: What function to use for aggregating. Use the ``aws_cloudwatch.Stats`` helper class to construct valid input strings. Can be one of the following: - "Minimum" | "min" - "Maximum" | "max" - "Average" | "avg" - "Sum" | "sum" - "SampleCount | "n" - "pNN.NN" - "tmNN.NN" | "tm(NN.NN%:NN.NN%)" - "iqm" - "wmNN.NN" | "wm(NN.NN%:NN.NN%)" - "tcNN.NN" | "tc(NN.NN%:NN.NN%)" - "tsNN.NN" | "ts(NN.NN%:NN.NN%)" Default: Average
        :param unit: Unit used to filter the metric stream. Only refer to datums emitted to the metric stream with the given unit and ignore all others. Only useful when datums are being emitted to the same metric stream under different units. The default is to use all matric datums in the stream, regardless of unit, which is recommended in nearly all cases. CloudWatch does not honor this property for graphs. Default: - All metric datums in the given metric stream
        :param visible: Whether this metric should be visible in dashboard graphs. Setting this to false is useful when you want to hide raw metrics that are used in math expressions, and show only the expression results. Default: true

        :stability: experimental
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__a846e8d44f001945a2a3b7021711dfdac251684800be2c5f3e56b0ec1697f235)
            check_type(argname="argument metric_name", value=metric_name, expected_type=type_hints["metric_name"])
        props = _aws_cdk_aws_cloudwatch_ceddda9d.MetricOptions(
            account=account,
            color=color,
            dimensions_map=dimensions_map,
            id=id,
            label=label,
            period=period,
            region=region,
            stack_account=stack_account,
            stack_region=stack_region,
            statistic=statistic,
            unit=unit,
            visible=visible,
        )

        return typing.cast("_aws_cdk_aws_cloudwatch_ceddda9d.Metric", jsii.invoke(self, "metric", [metric_name, props]))

    @jsii.member(jsii_name="metricEgressBytes")
    def metric_egress_bytes(
        self,
        *,
        account: typing.Optional[builtins.str] = None,
        color: typing.Optional[builtins.str] = None,
        dimensions_map: typing.Optional[typing.Mapping[builtins.str, builtins.str]] = None,
        id: typing.Optional[builtins.str] = None,
        label: typing.Optional[builtins.str] = None,
        period: typing.Optional["_aws_cdk_ceddda9d.Duration"] = None,
        region: typing.Optional[builtins.str] = None,
        stack_account: typing.Optional[builtins.str] = None,
        stack_region: typing.Optional[builtins.str] = None,
        statistic: typing.Optional[builtins.str] = None,
        unit: typing.Optional["_aws_cdk_aws_cloudwatch_ceddda9d.Unit"] = None,
        visible: typing.Optional[builtins.bool] = None,
    ) -> "_aws_cdk_aws_cloudwatch_ceddda9d.Metric":
        '''(experimental) Returns Metric for Egress Bytes.

        :param account: Account which this metric comes from. Default: - Deployment account.
        :param color: The hex color code, prefixed with '#' (e.g. '#00ff00'), to use when this metric is rendered on a graph. The ``Color`` class has a set of standard colors that can be used here. Default: - Automatic color
        :param dimensions_map: Dimensions of the metric. Default: - No dimensions.
        :param id: Unique identifier for this metric when used in dashboard widgets. The id can be used as a variable to represent this metric in math expressions. Valid characters are letters, numbers, and underscore. The first character must be a lowercase letter. Default: - No ID
        :param label: Label for this metric when added to a Graph in a Dashboard. You can use `dynamic labels <https://docs.aws.amazon.com/AmazonCloudWatch/latest/monitoring/graph-dynamic-labels.html>`_ to show summary information about the entire displayed time series in the legend. For example, if you use:: [max: ${MAX}] MyMetric As the metric label, the maximum value in the visible range will be shown next to the time series name in the graph's legend. Default: - No label
        :param period: The period over which the specified statistic is applied. Default: Duration.minutes(5)
        :param region: Region which this metric comes from. Default: - Deployment region.
        :param stack_account: Account of the stack this metric is attached to. Default: - Deployment account.
        :param stack_region: Region of the stack this metric is attached to. Default: - Deployment region.
        :param statistic: What function to use for aggregating. Use the ``aws_cloudwatch.Stats`` helper class to construct valid input strings. Can be one of the following: - "Minimum" | "min" - "Maximum" | "max" - "Average" | "avg" - "Sum" | "sum" - "SampleCount | "n" - "pNN.NN" - "tmNN.NN" | "tm(NN.NN%:NN.NN%)" - "iqm" - "wmNN.NN" | "wm(NN.NN%:NN.NN%)" - "tcNN.NN" | "tc(NN.NN%:NN.NN%)" - "tsNN.NN" | "ts(NN.NN%:NN.NN%)" Default: Average
        :param unit: Unit used to filter the metric stream. Only refer to datums emitted to the metric stream with the given unit and ignore all others. Only useful when datums are being emitted to the same metric stream under different units. The default is to use all matric datums in the stream, regardless of unit, which is recommended in nearly all cases. CloudWatch does not honor this property for graphs. Default: - All metric datums in the given metric stream
        :param visible: Whether this metric should be visible in dashboard graphs. Setting this to false is useful when you want to hide raw metrics that are used in math expressions, and show only the expression results. Default: true

        :default: - sum over 60 seconds

        :stability: experimental
        '''
        props = _aws_cdk_aws_cloudwatch_ceddda9d.MetricOptions(
            account=account,
            color=color,
            dimensions_map=dimensions_map,
            id=id,
            label=label,
            period=period,
            region=region,
            stack_account=stack_account,
            stack_region=stack_region,
            statistic=statistic,
            unit=unit,
            visible=visible,
        )

        return typing.cast("_aws_cdk_aws_cloudwatch_ceddda9d.Metric", jsii.invoke(self, "metricEgressBytes", [props]))

    @jsii.member(jsii_name="metricEgressRequestCount")
    def metric_egress_request_count(
        self,
        *,
        account: typing.Optional[builtins.str] = None,
        color: typing.Optional[builtins.str] = None,
        dimensions_map: typing.Optional[typing.Mapping[builtins.str, builtins.str]] = None,
        id: typing.Optional[builtins.str] = None,
        label: typing.Optional[builtins.str] = None,
        period: typing.Optional["_aws_cdk_ceddda9d.Duration"] = None,
        region: typing.Optional[builtins.str] = None,
        stack_account: typing.Optional[builtins.str] = None,
        stack_region: typing.Optional[builtins.str] = None,
        statistic: typing.Optional[builtins.str] = None,
        unit: typing.Optional["_aws_cdk_aws_cloudwatch_ceddda9d.Unit"] = None,
        visible: typing.Optional[builtins.bool] = None,
    ) -> "_aws_cdk_aws_cloudwatch_ceddda9d.Metric":
        '''(experimental) Returns Metric for Egress Request Count.

        :param account: Account which this metric comes from. Default: - Deployment account.
        :param color: The hex color code, prefixed with '#' (e.g. '#00ff00'), to use when this metric is rendered on a graph. The ``Color`` class has a set of standard colors that can be used here. Default: - Automatic color
        :param dimensions_map: Dimensions of the metric. Default: - No dimensions.
        :param id: Unique identifier for this metric when used in dashboard widgets. The id can be used as a variable to represent this metric in math expressions. Valid characters are letters, numbers, and underscore. The first character must be a lowercase letter. Default: - No ID
        :param label: Label for this metric when added to a Graph in a Dashboard. You can use `dynamic labels <https://docs.aws.amazon.com/AmazonCloudWatch/latest/monitoring/graph-dynamic-labels.html>`_ to show summary information about the entire displayed time series in the legend. For example, if you use:: [max: ${MAX}] MyMetric As the metric label, the maximum value in the visible range will be shown next to the time series name in the graph's legend. Default: - No label
        :param period: The period over which the specified statistic is applied. Default: Duration.minutes(5)
        :param region: Region which this metric comes from. Default: - Deployment region.
        :param stack_account: Account of the stack this metric is attached to. Default: - Deployment account.
        :param stack_region: Region of the stack this metric is attached to. Default: - Deployment region.
        :param statistic: What function to use for aggregating. Use the ``aws_cloudwatch.Stats`` helper class to construct valid input strings. Can be one of the following: - "Minimum" | "min" - "Maximum" | "max" - "Average" | "avg" - "Sum" | "sum" - "SampleCount | "n" - "pNN.NN" - "tmNN.NN" | "tm(NN.NN%:NN.NN%)" - "iqm" - "wmNN.NN" | "wm(NN.NN%:NN.NN%)" - "tcNN.NN" | "tc(NN.NN%:NN.NN%)" - "tsNN.NN" | "ts(NN.NN%:NN.NN%)" Default: Average
        :param unit: Unit used to filter the metric stream. Only refer to datums emitted to the metric stream with the given unit and ignore all others. Only useful when datums are being emitted to the same metric stream under different units. The default is to use all matric datums in the stream, regardless of unit, which is recommended in nearly all cases. CloudWatch does not honor this property for graphs. Default: - All metric datums in the given metric stream
        :param visible: Whether this metric should be visible in dashboard graphs. Setting this to false is useful when you want to hide raw metrics that are used in math expressions, and show only the expression results. Default: true

        :default: - sum over 60 seconds

        :stability: experimental
        '''
        props = _aws_cdk_aws_cloudwatch_ceddda9d.MetricOptions(
            account=account,
            color=color,
            dimensions_map=dimensions_map,
            id=id,
            label=label,
            period=period,
            region=region,
            stack_account=stack_account,
            stack_region=stack_region,
            statistic=statistic,
            unit=unit,
            visible=visible,
        )

        return typing.cast("_aws_cdk_aws_cloudwatch_ceddda9d.Metric", jsii.invoke(self, "metricEgressRequestCount", [props]))

    @jsii.member(jsii_name="metricEgressResponseTime")
    def metric_egress_response_time(
        self,
        *,
        account: typing.Optional[builtins.str] = None,
        color: typing.Optional[builtins.str] = None,
        dimensions_map: typing.Optional[typing.Mapping[builtins.str, builtins.str]] = None,
        id: typing.Optional[builtins.str] = None,
        label: typing.Optional[builtins.str] = None,
        period: typing.Optional["_aws_cdk_ceddda9d.Duration"] = None,
        region: typing.Optional[builtins.str] = None,
        stack_account: typing.Optional[builtins.str] = None,
        stack_region: typing.Optional[builtins.str] = None,
        statistic: typing.Optional[builtins.str] = None,
        unit: typing.Optional["_aws_cdk_aws_cloudwatch_ceddda9d.Unit"] = None,
        visible: typing.Optional[builtins.bool] = None,
    ) -> "_aws_cdk_aws_cloudwatch_ceddda9d.Metric":
        '''(experimental) Returns Metric for Egress Response time.

        :param account: Account which this metric comes from. Default: - Deployment account.
        :param color: The hex color code, prefixed with '#' (e.g. '#00ff00'), to use when this metric is rendered on a graph. The ``Color`` class has a set of standard colors that can be used here. Default: - Automatic color
        :param dimensions_map: Dimensions of the metric. Default: - No dimensions.
        :param id: Unique identifier for this metric when used in dashboard widgets. The id can be used as a variable to represent this metric in math expressions. Valid characters are letters, numbers, and underscore. The first character must be a lowercase letter. Default: - No ID
        :param label: Label for this metric when added to a Graph in a Dashboard. You can use `dynamic labels <https://docs.aws.amazon.com/AmazonCloudWatch/latest/monitoring/graph-dynamic-labels.html>`_ to show summary information about the entire displayed time series in the legend. For example, if you use:: [max: ${MAX}] MyMetric As the metric label, the maximum value in the visible range will be shown next to the time series name in the graph's legend. Default: - No label
        :param period: The period over which the specified statistic is applied. Default: Duration.minutes(5)
        :param region: Region which this metric comes from. Default: - Deployment region.
        :param stack_account: Account of the stack this metric is attached to. Default: - Deployment account.
        :param stack_region: Region of the stack this metric is attached to. Default: - Deployment region.
        :param statistic: What function to use for aggregating. Use the ``aws_cloudwatch.Stats`` helper class to construct valid input strings. Can be one of the following: - "Minimum" | "min" - "Maximum" | "max" - "Average" | "avg" - "Sum" | "sum" - "SampleCount | "n" - "pNN.NN" - "tmNN.NN" | "tm(NN.NN%:NN.NN%)" - "iqm" - "wmNN.NN" | "wm(NN.NN%:NN.NN%)" - "tcNN.NN" | "tc(NN.NN%:NN.NN%)" - "tsNN.NN" | "ts(NN.NN%:NN.NN%)" Default: Average
        :param unit: Unit used to filter the metric stream. Only refer to datums emitted to the metric stream with the given unit and ignore all others. Only useful when datums are being emitted to the same metric stream under different units. The default is to use all matric datums in the stream, regardless of unit, which is recommended in nearly all cases. CloudWatch does not honor this property for graphs. Default: - All metric datums in the given metric stream
        :param visible: Whether this metric should be visible in dashboard graphs. Setting this to false is useful when you want to hide raw metrics that are used in math expressions, and show only the expression results. Default: true

        :default: - average over 60 seconds

        :stability: experimental
        '''
        props = _aws_cdk_aws_cloudwatch_ceddda9d.MetricOptions(
            account=account,
            color=color,
            dimensions_map=dimensions_map,
            id=id,
            label=label,
            period=period,
            region=region,
            stack_account=stack_account,
            stack_region=stack_region,
            statistic=statistic,
            unit=unit,
            visible=visible,
        )

        return typing.cast("_aws_cdk_aws_cloudwatch_ceddda9d.Metric", jsii.invoke(self, "metricEgressResponseTime", [props]))

    @jsii.member(jsii_name="metricIngressBytes")
    def metric_ingress_bytes(
        self,
        *,
        account: typing.Optional[builtins.str] = None,
        color: typing.Optional[builtins.str] = None,
        dimensions_map: typing.Optional[typing.Mapping[builtins.str, builtins.str]] = None,
        id: typing.Optional[builtins.str] = None,
        label: typing.Optional[builtins.str] = None,
        period: typing.Optional["_aws_cdk_ceddda9d.Duration"] = None,
        region: typing.Optional[builtins.str] = None,
        stack_account: typing.Optional[builtins.str] = None,
        stack_region: typing.Optional[builtins.str] = None,
        statistic: typing.Optional[builtins.str] = None,
        unit: typing.Optional["_aws_cdk_aws_cloudwatch_ceddda9d.Unit"] = None,
        visible: typing.Optional[builtins.bool] = None,
    ) -> "_aws_cdk_aws_cloudwatch_ceddda9d.Metric":
        '''(experimental) Returns Metric for Ingress Bytes.

        :param account: Account which this metric comes from. Default: - Deployment account.
        :param color: The hex color code, prefixed with '#' (e.g. '#00ff00'), to use when this metric is rendered on a graph. The ``Color`` class has a set of standard colors that can be used here. Default: - Automatic color
        :param dimensions_map: Dimensions of the metric. Default: - No dimensions.
        :param id: Unique identifier for this metric when used in dashboard widgets. The id can be used as a variable to represent this metric in math expressions. Valid characters are letters, numbers, and underscore. The first character must be a lowercase letter. Default: - No ID
        :param label: Label for this metric when added to a Graph in a Dashboard. You can use `dynamic labels <https://docs.aws.amazon.com/AmazonCloudWatch/latest/monitoring/graph-dynamic-labels.html>`_ to show summary information about the entire displayed time series in the legend. For example, if you use:: [max: ${MAX}] MyMetric As the metric label, the maximum value in the visible range will be shown next to the time series name in the graph's legend. Default: - No label
        :param period: The period over which the specified statistic is applied. Default: Duration.minutes(5)
        :param region: Region which this metric comes from. Default: - Deployment region.
        :param stack_account: Account of the stack this metric is attached to. Default: - Deployment account.
        :param stack_region: Region of the stack this metric is attached to. Default: - Deployment region.
        :param statistic: What function to use for aggregating. Use the ``aws_cloudwatch.Stats`` helper class to construct valid input strings. Can be one of the following: - "Minimum" | "min" - "Maximum" | "max" - "Average" | "avg" - "Sum" | "sum" - "SampleCount | "n" - "pNN.NN" - "tmNN.NN" | "tm(NN.NN%:NN.NN%)" - "iqm" - "wmNN.NN" | "wm(NN.NN%:NN.NN%)" - "tcNN.NN" | "tc(NN.NN%:NN.NN%)" - "tsNN.NN" | "ts(NN.NN%:NN.NN%)" Default: Average
        :param unit: Unit used to filter the metric stream. Only refer to datums emitted to the metric stream with the given unit and ignore all others. Only useful when datums are being emitted to the same metric stream under different units. The default is to use all matric datums in the stream, regardless of unit, which is recommended in nearly all cases. CloudWatch does not honor this property for graphs. Default: - All metric datums in the given metric stream
        :param visible: Whether this metric should be visible in dashboard graphs. Setting this to false is useful when you want to hide raw metrics that are used in math expressions, and show only the expression results. Default: true

        :default: - sum over 60 seconds

        :stability: experimental
        '''
        options = _aws_cdk_aws_cloudwatch_ceddda9d.MetricOptions(
            account=account,
            color=color,
            dimensions_map=dimensions_map,
            id=id,
            label=label,
            period=period,
            region=region,
            stack_account=stack_account,
            stack_region=stack_region,
            statistic=statistic,
            unit=unit,
            visible=visible,
        )

        return typing.cast("_aws_cdk_aws_cloudwatch_ceddda9d.Metric", jsii.invoke(self, "metricIngressBytes", [options]))

    @jsii.member(jsii_name="metricIngressRequestCount")
    def metric_ingress_request_count(
        self,
        *,
        account: typing.Optional[builtins.str] = None,
        color: typing.Optional[builtins.str] = None,
        dimensions_map: typing.Optional[typing.Mapping[builtins.str, builtins.str]] = None,
        id: typing.Optional[builtins.str] = None,
        label: typing.Optional[builtins.str] = None,
        period: typing.Optional["_aws_cdk_ceddda9d.Duration"] = None,
        region: typing.Optional[builtins.str] = None,
        stack_account: typing.Optional[builtins.str] = None,
        stack_region: typing.Optional[builtins.str] = None,
        statistic: typing.Optional[builtins.str] = None,
        unit: typing.Optional["_aws_cdk_aws_cloudwatch_ceddda9d.Unit"] = None,
        visible: typing.Optional[builtins.bool] = None,
    ) -> "_aws_cdk_aws_cloudwatch_ceddda9d.Metric":
        '''(experimental) Returns Metric for Ingress Request Count.

        :param account: Account which this metric comes from. Default: - Deployment account.
        :param color: The hex color code, prefixed with '#' (e.g. '#00ff00'), to use when this metric is rendered on a graph. The ``Color`` class has a set of standard colors that can be used here. Default: - Automatic color
        :param dimensions_map: Dimensions of the metric. Default: - No dimensions.
        :param id: Unique identifier for this metric when used in dashboard widgets. The id can be used as a variable to represent this metric in math expressions. Valid characters are letters, numbers, and underscore. The first character must be a lowercase letter. Default: - No ID
        :param label: Label for this metric when added to a Graph in a Dashboard. You can use `dynamic labels <https://docs.aws.amazon.com/AmazonCloudWatch/latest/monitoring/graph-dynamic-labels.html>`_ to show summary information about the entire displayed time series in the legend. For example, if you use:: [max: ${MAX}] MyMetric As the metric label, the maximum value in the visible range will be shown next to the time series name in the graph's legend. Default: - No label
        :param period: The period over which the specified statistic is applied. Default: Duration.minutes(5)
        :param region: Region which this metric comes from. Default: - Deployment region.
        :param stack_account: Account of the stack this metric is attached to. Default: - Deployment account.
        :param stack_region: Region of the stack this metric is attached to. Default: - Deployment region.
        :param statistic: What function to use for aggregating. Use the ``aws_cloudwatch.Stats`` helper class to construct valid input strings. Can be one of the following: - "Minimum" | "min" - "Maximum" | "max" - "Average" | "avg" - "Sum" | "sum" - "SampleCount | "n" - "pNN.NN" - "tmNN.NN" | "tm(NN.NN%:NN.NN%)" - "iqm" - "wmNN.NN" | "wm(NN.NN%:NN.NN%)" - "tcNN.NN" | "tc(NN.NN%:NN.NN%)" - "tsNN.NN" | "ts(NN.NN%:NN.NN%)" Default: Average
        :param unit: Unit used to filter the metric stream. Only refer to datums emitted to the metric stream with the given unit and ignore all others. Only useful when datums are being emitted to the same metric stream under different units. The default is to use all matric datums in the stream, regardless of unit, which is recommended in nearly all cases. CloudWatch does not honor this property for graphs. Default: - All metric datums in the given metric stream
        :param visible: Whether this metric should be visible in dashboard graphs. Setting this to false is useful when you want to hide raw metrics that are used in math expressions, and show only the expression results. Default: true

        :default: - sum over 60 seconds

        :stability: experimental
        '''
        props = _aws_cdk_aws_cloudwatch_ceddda9d.MetricOptions(
            account=account,
            color=color,
            dimensions_map=dimensions_map,
            id=id,
            label=label,
            period=period,
            region=region,
            stack_account=stack_account,
            stack_region=stack_region,
            statistic=statistic,
            unit=unit,
            visible=visible,
        )

        return typing.cast("_aws_cdk_aws_cloudwatch_ceddda9d.Metric", jsii.invoke(self, "metricIngressRequestCount", [props]))

    @jsii.member(jsii_name="metricIngressResponseTime")
    def metric_ingress_response_time(
        self,
        *,
        account: typing.Optional[builtins.str] = None,
        color: typing.Optional[builtins.str] = None,
        dimensions_map: typing.Optional[typing.Mapping[builtins.str, builtins.str]] = None,
        id: typing.Optional[builtins.str] = None,
        label: typing.Optional[builtins.str] = None,
        period: typing.Optional["_aws_cdk_ceddda9d.Duration"] = None,
        region: typing.Optional[builtins.str] = None,
        stack_account: typing.Optional[builtins.str] = None,
        stack_region: typing.Optional[builtins.str] = None,
        statistic: typing.Optional[builtins.str] = None,
        unit: typing.Optional["_aws_cdk_aws_cloudwatch_ceddda9d.Unit"] = None,
        visible: typing.Optional[builtins.bool] = None,
    ) -> "_aws_cdk_aws_cloudwatch_ceddda9d.Metric":
        '''(experimental) Returns Metric for Ingress response time.

        :param account: Account which this metric comes from. Default: - Deployment account.
        :param color: The hex color code, prefixed with '#' (e.g. '#00ff00'), to use when this metric is rendered on a graph. The ``Color`` class has a set of standard colors that can be used here. Default: - Automatic color
        :param dimensions_map: Dimensions of the metric. Default: - No dimensions.
        :param id: Unique identifier for this metric when used in dashboard widgets. The id can be used as a variable to represent this metric in math expressions. Valid characters are letters, numbers, and underscore. The first character must be a lowercase letter. Default: - No ID
        :param label: Label for this metric when added to a Graph in a Dashboard. You can use `dynamic labels <https://docs.aws.amazon.com/AmazonCloudWatch/latest/monitoring/graph-dynamic-labels.html>`_ to show summary information about the entire displayed time series in the legend. For example, if you use:: [max: ${MAX}] MyMetric As the metric label, the maximum value in the visible range will be shown next to the time series name in the graph's legend. Default: - No label
        :param period: The period over which the specified statistic is applied. Default: Duration.minutes(5)
        :param region: Region which this metric comes from. Default: - Deployment region.
        :param stack_account: Account of the stack this metric is attached to. Default: - Deployment account.
        :param stack_region: Region of the stack this metric is attached to. Default: - Deployment region.
        :param statistic: What function to use for aggregating. Use the ``aws_cloudwatch.Stats`` helper class to construct valid input strings. Can be one of the following: - "Minimum" | "min" - "Maximum" | "max" - "Average" | "avg" - "Sum" | "sum" - "SampleCount | "n" - "pNN.NN" - "tmNN.NN" | "tm(NN.NN%:NN.NN%)" - "iqm" - "wmNN.NN" | "wm(NN.NN%:NN.NN%)" - "tcNN.NN" | "tc(NN.NN%:NN.NN%)" - "tsNN.NN" | "ts(NN.NN%:NN.NN%)" Default: Average
        :param unit: Unit used to filter the metric stream. Only refer to datums emitted to the metric stream with the given unit and ignore all others. Only useful when datums are being emitted to the same metric stream under different units. The default is to use all matric datums in the stream, regardless of unit, which is recommended in nearly all cases. CloudWatch does not honor this property for graphs. Default: - All metric datums in the given metric stream
        :param visible: Whether this metric should be visible in dashboard graphs. Setting this to false is useful when you want to hide raw metrics that are used in math expressions, and show only the expression results. Default: true

        :default: - average over 60 seconds

        :stability: experimental
        '''
        props = _aws_cdk_aws_cloudwatch_ceddda9d.MetricOptions(
            account=account,
            color=color,
            dimensions_map=dimensions_map,
            id=id,
            label=label,
            period=period,
            region=region,
            stack_account=stack_account,
            stack_region=stack_region,
            statistic=statistic,
            unit=unit,
            visible=visible,
        )

        return typing.cast("_aws_cdk_aws_cloudwatch_ceddda9d.Metric", jsii.invoke(self, "metricIngressResponseTime", [props]))

# Adding a "__jsii_proxy_class__(): typing.Type" function to the interface
typing.cast(typing.Any, IChannelGroup).__jsii_proxy_class__ = lambda : _IChannelGroupProxy


@jsii.interface(jsii_type="@aws-cdk/aws-mediapackagev2-alpha.IOriginEndpoint")
class IOriginEndpoint(
    _aws_cdk_ceddda9d.IResource,
    _aws_cdk_interfaces_aws_mediapackagev2_ceddda9d.IOriginEndpointRef,
    typing_extensions.Protocol,
):
    '''(experimental) Origin Endpoint interface.

    :stability: experimental
    '''

    @builtins.property
    @jsii.member(jsii_name="channelGroupName")
    def channel_group_name(self) -> builtins.str:
        '''(experimental) The name of the channel group associated with the origin endpoint configuration.

        :stability: experimental
        :attribute: true
        '''
        ...

    @builtins.property
    @jsii.member(jsii_name="channelName")
    def channel_name(self) -> builtins.str:
        '''(experimental) The channel name associated with the origin endpoint.

        :stability: experimental
        :attribute: true
        '''
        ...

    @builtins.property
    @jsii.member(jsii_name="originEndpointArn")
    def origin_endpoint_arn(self) -> builtins.str:
        '''(experimental) The Amazon Resource Name (ARN) of the origin endpoint.

        :stability: experimental
        :attribute: true
        '''
        ...

    @builtins.property
    @jsii.member(jsii_name="originEndpointName")
    def origin_endpoint_name(self) -> builtins.str:
        '''(experimental) The name of the origin endpoint associated with the origin endpoint configuration.

        :stability: experimental
        :attribute: true
        '''
        ...

    @builtins.property
    @jsii.member(jsii_name="createdAt")
    def created_at(self) -> typing.Optional[builtins.str]:
        '''(experimental) The date and time the origin endpoint was created.

        :stability: experimental
        :attribute: true
        '''
        ...

    @builtins.property
    @jsii.member(jsii_name="dashManifestUrls")
    def dash_manifest_urls(self) -> typing.Optional[typing.List[builtins.str]]:
        '''(experimental) The DASH manifest URLs for the origin endpoint.

        :stability: experimental
        :attribute: true
        '''
        ...

    @builtins.property
    @jsii.member(jsii_name="hlsManifestUrls")
    def hls_manifest_urls(self) -> typing.Optional[typing.List[builtins.str]]:
        '''(experimental) The HLS manifest URLs for the origin endpoint.

        :stability: experimental
        :attribute: true
        '''
        ...

    @builtins.property
    @jsii.member(jsii_name="lowLatencyHlsManifestUrls")
    def low_latency_hls_manifest_urls(
        self,
    ) -> typing.Optional[typing.List[builtins.str]]:
        '''(experimental) The Low Latency HLS manifest URLs for the origin endpoint.

        :stability: experimental
        :attribute: true
        '''
        ...

    @builtins.property
    @jsii.member(jsii_name="modifiedAt")
    def modified_at(self) -> typing.Optional[builtins.str]:
        '''(experimental) The date and time the origin endpoint was modified.

        :stability: experimental
        :attribute: true
        '''
        ...

    @builtins.property
    @jsii.member(jsii_name="mssManifestUrls")
    def mss_manifest_urls(self) -> typing.Optional[typing.List[builtins.str]]:
        '''(experimental) The MSS manifest URLs for the origin endpoint.

        :stability: experimental
        :attribute: true
        '''
        ...

    @jsii.member(jsii_name="addToResourcePolicy")
    def add_to_resource_policy(
        self,
        statement: "_aws_cdk_aws_iam_ceddda9d.PolicyStatement",
        *,
        secrets: typing.Sequence["_aws_cdk_aws_secretsmanager_ceddda9d.ISecret"],
        role: typing.Optional["_aws_cdk_aws_iam_ceddda9d.IRole"] = None,
    ) -> "_aws_cdk_aws_iam_ceddda9d.AddToResourcePolicyResult":
        '''(experimental) Configure origin endpoint policy.

        You can only add 1 OriginEndpointPolicy to an OriginEndpoint.
        If you have already defined one, it will append to the policy already created.

        :param statement: - The policy statement to add.
        :param secrets: (experimental) Secrets to use for CDN authorization.
        :param role: (experimental) Role to use for reading the secrets. If not provided, a role will be created automatically with the required permissions (secretsmanager:GetSecretValue, secretsmanager:DescribeSecret, secretsmanager:BatchGetSecretValue, and kms:Decrypt if the secret uses a customer-managed KMS key). Default: - a new role is created

        :stability: experimental
        '''
        ...

    @jsii.member(jsii_name="metric")
    def metric(
        self,
        metric_name: builtins.str,
        *,
        account: typing.Optional[builtins.str] = None,
        color: typing.Optional[builtins.str] = None,
        dimensions_map: typing.Optional[typing.Mapping[builtins.str, builtins.str]] = None,
        id: typing.Optional[builtins.str] = None,
        label: typing.Optional[builtins.str] = None,
        period: typing.Optional["_aws_cdk_ceddda9d.Duration"] = None,
        region: typing.Optional[builtins.str] = None,
        stack_account: typing.Optional[builtins.str] = None,
        stack_region: typing.Optional[builtins.str] = None,
        statistic: typing.Optional[builtins.str] = None,
        unit: typing.Optional["_aws_cdk_aws_cloudwatch_ceddda9d.Unit"] = None,
        visible: typing.Optional[builtins.bool] = None,
    ) -> "_aws_cdk_aws_cloudwatch_ceddda9d.Metric":
        '''(experimental) Create a CloudWatch metric.

        :param metric_name: name of the metric.
        :param account: Account which this metric comes from. Default: - Deployment account.
        :param color: The hex color code, prefixed with '#' (e.g. '#00ff00'), to use when this metric is rendered on a graph. The ``Color`` class has a set of standard colors that can be used here. Default: - Automatic color
        :param dimensions_map: Dimensions of the metric. Default: - No dimensions.
        :param id: Unique identifier for this metric when used in dashboard widgets. The id can be used as a variable to represent this metric in math expressions. Valid characters are letters, numbers, and underscore. The first character must be a lowercase letter. Default: - No ID
        :param label: Label for this metric when added to a Graph in a Dashboard. You can use `dynamic labels <https://docs.aws.amazon.com/AmazonCloudWatch/latest/monitoring/graph-dynamic-labels.html>`_ to show summary information about the entire displayed time series in the legend. For example, if you use:: [max: ${MAX}] MyMetric As the metric label, the maximum value in the visible range will be shown next to the time series name in the graph's legend. Default: - No label
        :param period: The period over which the specified statistic is applied. Default: Duration.minutes(5)
        :param region: Region which this metric comes from. Default: - Deployment region.
        :param stack_account: Account of the stack this metric is attached to. Default: - Deployment account.
        :param stack_region: Region of the stack this metric is attached to. Default: - Deployment region.
        :param statistic: What function to use for aggregating. Use the ``aws_cloudwatch.Stats`` helper class to construct valid input strings. Can be one of the following: - "Minimum" | "min" - "Maximum" | "max" - "Average" | "avg" - "Sum" | "sum" - "SampleCount | "n" - "pNN.NN" - "tmNN.NN" | "tm(NN.NN%:NN.NN%)" - "iqm" - "wmNN.NN" | "wm(NN.NN%:NN.NN%)" - "tcNN.NN" | "tc(NN.NN%:NN.NN%)" - "tsNN.NN" | "ts(NN.NN%:NN.NN%)" Default: Average
        :param unit: Unit used to filter the metric stream. Only refer to datums emitted to the metric stream with the given unit and ignore all others. Only useful when datums are being emitted to the same metric stream under different units. The default is to use all matric datums in the stream, regardless of unit, which is recommended in nearly all cases. CloudWatch does not honor this property for graphs. Default: - All metric datums in the given metric stream
        :param visible: Whether this metric should be visible in dashboard graphs. Setting this to false is useful when you want to hide raw metrics that are used in math expressions, and show only the expression results. Default: true

        :stability: experimental
        '''
        ...

    @jsii.member(jsii_name="metricEgressBytes")
    def metric_egress_bytes(
        self,
        *,
        account: typing.Optional[builtins.str] = None,
        color: typing.Optional[builtins.str] = None,
        dimensions_map: typing.Optional[typing.Mapping[builtins.str, builtins.str]] = None,
        id: typing.Optional[builtins.str] = None,
        label: typing.Optional[builtins.str] = None,
        period: typing.Optional["_aws_cdk_ceddda9d.Duration"] = None,
        region: typing.Optional[builtins.str] = None,
        stack_account: typing.Optional[builtins.str] = None,
        stack_region: typing.Optional[builtins.str] = None,
        statistic: typing.Optional[builtins.str] = None,
        unit: typing.Optional["_aws_cdk_aws_cloudwatch_ceddda9d.Unit"] = None,
        visible: typing.Optional[builtins.bool] = None,
    ) -> "_aws_cdk_aws_cloudwatch_ceddda9d.Metric":
        '''(experimental) Returns Metric for Egress Bytes.

        :param account: Account which this metric comes from. Default: - Deployment account.
        :param color: The hex color code, prefixed with '#' (e.g. '#00ff00'), to use when this metric is rendered on a graph. The ``Color`` class has a set of standard colors that can be used here. Default: - Automatic color
        :param dimensions_map: Dimensions of the metric. Default: - No dimensions.
        :param id: Unique identifier for this metric when used in dashboard widgets. The id can be used as a variable to represent this metric in math expressions. Valid characters are letters, numbers, and underscore. The first character must be a lowercase letter. Default: - No ID
        :param label: Label for this metric when added to a Graph in a Dashboard. You can use `dynamic labels <https://docs.aws.amazon.com/AmazonCloudWatch/latest/monitoring/graph-dynamic-labels.html>`_ to show summary information about the entire displayed time series in the legend. For example, if you use:: [max: ${MAX}] MyMetric As the metric label, the maximum value in the visible range will be shown next to the time series name in the graph's legend. Default: - No label
        :param period: The period over which the specified statistic is applied. Default: Duration.minutes(5)
        :param region: Region which this metric comes from. Default: - Deployment region.
        :param stack_account: Account of the stack this metric is attached to. Default: - Deployment account.
        :param stack_region: Region of the stack this metric is attached to. Default: - Deployment region.
        :param statistic: What function to use for aggregating. Use the ``aws_cloudwatch.Stats`` helper class to construct valid input strings. Can be one of the following: - "Minimum" | "min" - "Maximum" | "max" - "Average" | "avg" - "Sum" | "sum" - "SampleCount | "n" - "pNN.NN" - "tmNN.NN" | "tm(NN.NN%:NN.NN%)" - "iqm" - "wmNN.NN" | "wm(NN.NN%:NN.NN%)" - "tcNN.NN" | "tc(NN.NN%:NN.NN%)" - "tsNN.NN" | "ts(NN.NN%:NN.NN%)" Default: Average
        :param unit: Unit used to filter the metric stream. Only refer to datums emitted to the metric stream with the given unit and ignore all others. Only useful when datums are being emitted to the same metric stream under different units. The default is to use all matric datums in the stream, regardless of unit, which is recommended in nearly all cases. CloudWatch does not honor this property for graphs. Default: - All metric datums in the given metric stream
        :param visible: Whether this metric should be visible in dashboard graphs. Setting this to false is useful when you want to hide raw metrics that are used in math expressions, and show only the expression results. Default: true

        :default: - sum over 60 seconds

        :stability: experimental
        '''
        ...

    @jsii.member(jsii_name="metricEgressRequestCount")
    def metric_egress_request_count(
        self,
        *,
        account: typing.Optional[builtins.str] = None,
        color: typing.Optional[builtins.str] = None,
        dimensions_map: typing.Optional[typing.Mapping[builtins.str, builtins.str]] = None,
        id: typing.Optional[builtins.str] = None,
        label: typing.Optional[builtins.str] = None,
        period: typing.Optional["_aws_cdk_ceddda9d.Duration"] = None,
        region: typing.Optional[builtins.str] = None,
        stack_account: typing.Optional[builtins.str] = None,
        stack_region: typing.Optional[builtins.str] = None,
        statistic: typing.Optional[builtins.str] = None,
        unit: typing.Optional["_aws_cdk_aws_cloudwatch_ceddda9d.Unit"] = None,
        visible: typing.Optional[builtins.bool] = None,
    ) -> "_aws_cdk_aws_cloudwatch_ceddda9d.Metric":
        '''(experimental) Returns Metric for Egress Request Count.

        :param account: Account which this metric comes from. Default: - Deployment account.
        :param color: The hex color code, prefixed with '#' (e.g. '#00ff00'), to use when this metric is rendered on a graph. The ``Color`` class has a set of standard colors that can be used here. Default: - Automatic color
        :param dimensions_map: Dimensions of the metric. Default: - No dimensions.
        :param id: Unique identifier for this metric when used in dashboard widgets. The id can be used as a variable to represent this metric in math expressions. Valid characters are letters, numbers, and underscore. The first character must be a lowercase letter. Default: - No ID
        :param label: Label for this metric when added to a Graph in a Dashboard. You can use `dynamic labels <https://docs.aws.amazon.com/AmazonCloudWatch/latest/monitoring/graph-dynamic-labels.html>`_ to show summary information about the entire displayed time series in the legend. For example, if you use:: [max: ${MAX}] MyMetric As the metric label, the maximum value in the visible range will be shown next to the time series name in the graph's legend. Default: - No label
        :param period: The period over which the specified statistic is applied. Default: Duration.minutes(5)
        :param region: Region which this metric comes from. Default: - Deployment region.
        :param stack_account: Account of the stack this metric is attached to. Default: - Deployment account.
        :param stack_region: Region of the stack this metric is attached to. Default: - Deployment region.
        :param statistic: What function to use for aggregating. Use the ``aws_cloudwatch.Stats`` helper class to construct valid input strings. Can be one of the following: - "Minimum" | "min" - "Maximum" | "max" - "Average" | "avg" - "Sum" | "sum" - "SampleCount | "n" - "pNN.NN" - "tmNN.NN" | "tm(NN.NN%:NN.NN%)" - "iqm" - "wmNN.NN" | "wm(NN.NN%:NN.NN%)" - "tcNN.NN" | "tc(NN.NN%:NN.NN%)" - "tsNN.NN" | "ts(NN.NN%:NN.NN%)" Default: Average
        :param unit: Unit used to filter the metric stream. Only refer to datums emitted to the metric stream with the given unit and ignore all others. Only useful when datums are being emitted to the same metric stream under different units. The default is to use all matric datums in the stream, regardless of unit, which is recommended in nearly all cases. CloudWatch does not honor this property for graphs. Default: - All metric datums in the given metric stream
        :param visible: Whether this metric should be visible in dashboard graphs. Setting this to false is useful when you want to hide raw metrics that are used in math expressions, and show only the expression results. Default: true

        :default: - sum over 60 seconds

        :stability: experimental
        '''
        ...

    @jsii.member(jsii_name="metricEgressResponseTime")
    def metric_egress_response_time(
        self,
        *,
        account: typing.Optional[builtins.str] = None,
        color: typing.Optional[builtins.str] = None,
        dimensions_map: typing.Optional[typing.Mapping[builtins.str, builtins.str]] = None,
        id: typing.Optional[builtins.str] = None,
        label: typing.Optional[builtins.str] = None,
        period: typing.Optional["_aws_cdk_ceddda9d.Duration"] = None,
        region: typing.Optional[builtins.str] = None,
        stack_account: typing.Optional[builtins.str] = None,
        stack_region: typing.Optional[builtins.str] = None,
        statistic: typing.Optional[builtins.str] = None,
        unit: typing.Optional["_aws_cdk_aws_cloudwatch_ceddda9d.Unit"] = None,
        visible: typing.Optional[builtins.bool] = None,
    ) -> "_aws_cdk_aws_cloudwatch_ceddda9d.Metric":
        '''(experimental) Returns Metric for Egress Response time.

        :param account: Account which this metric comes from. Default: - Deployment account.
        :param color: The hex color code, prefixed with '#' (e.g. '#00ff00'), to use when this metric is rendered on a graph. The ``Color`` class has a set of standard colors that can be used here. Default: - Automatic color
        :param dimensions_map: Dimensions of the metric. Default: - No dimensions.
        :param id: Unique identifier for this metric when used in dashboard widgets. The id can be used as a variable to represent this metric in math expressions. Valid characters are letters, numbers, and underscore. The first character must be a lowercase letter. Default: - No ID
        :param label: Label for this metric when added to a Graph in a Dashboard. You can use `dynamic labels <https://docs.aws.amazon.com/AmazonCloudWatch/latest/monitoring/graph-dynamic-labels.html>`_ to show summary information about the entire displayed time series in the legend. For example, if you use:: [max: ${MAX}] MyMetric As the metric label, the maximum value in the visible range will be shown next to the time series name in the graph's legend. Default: - No label
        :param period: The period over which the specified statistic is applied. Default: Duration.minutes(5)
        :param region: Region which this metric comes from. Default: - Deployment region.
        :param stack_account: Account of the stack this metric is attached to. Default: - Deployment account.
        :param stack_region: Region of the stack this metric is attached to. Default: - Deployment region.
        :param statistic: What function to use for aggregating. Use the ``aws_cloudwatch.Stats`` helper class to construct valid input strings. Can be one of the following: - "Minimum" | "min" - "Maximum" | "max" - "Average" | "avg" - "Sum" | "sum" - "SampleCount | "n" - "pNN.NN" - "tmNN.NN" | "tm(NN.NN%:NN.NN%)" - "iqm" - "wmNN.NN" | "wm(NN.NN%:NN.NN%)" - "tcNN.NN" | "tc(NN.NN%:NN.NN%)" - "tsNN.NN" | "ts(NN.NN%:NN.NN%)" Default: Average
        :param unit: Unit used to filter the metric stream. Only refer to datums emitted to the metric stream with the given unit and ignore all others. Only useful when datums are being emitted to the same metric stream under different units. The default is to use all matric datums in the stream, regardless of unit, which is recommended in nearly all cases. CloudWatch does not honor this property for graphs. Default: - All metric datums in the given metric stream
        :param visible: Whether this metric should be visible in dashboard graphs. Setting this to false is useful when you want to hide raw metrics that are used in math expressions, and show only the expression results. Default: true

        :default: - average over 60 seconds

        :stability: experimental
        '''
        ...

    @jsii.member(jsii_name="metricIngressBytes")
    def metric_ingress_bytes(
        self,
        *,
        account: typing.Optional[builtins.str] = None,
        color: typing.Optional[builtins.str] = None,
        dimensions_map: typing.Optional[typing.Mapping[builtins.str, builtins.str]] = None,
        id: typing.Optional[builtins.str] = None,
        label: typing.Optional[builtins.str] = None,
        period: typing.Optional["_aws_cdk_ceddda9d.Duration"] = None,
        region: typing.Optional[builtins.str] = None,
        stack_account: typing.Optional[builtins.str] = None,
        stack_region: typing.Optional[builtins.str] = None,
        statistic: typing.Optional[builtins.str] = None,
        unit: typing.Optional["_aws_cdk_aws_cloudwatch_ceddda9d.Unit"] = None,
        visible: typing.Optional[builtins.bool] = None,
    ) -> "_aws_cdk_aws_cloudwatch_ceddda9d.Metric":
        '''(experimental) Returns Metric for Ingress Bytes.

        :param account: Account which this metric comes from. Default: - Deployment account.
        :param color: The hex color code, prefixed with '#' (e.g. '#00ff00'), to use when this metric is rendered on a graph. The ``Color`` class has a set of standard colors that can be used here. Default: - Automatic color
        :param dimensions_map: Dimensions of the metric. Default: - No dimensions.
        :param id: Unique identifier for this metric when used in dashboard widgets. The id can be used as a variable to represent this metric in math expressions. Valid characters are letters, numbers, and underscore. The first character must be a lowercase letter. Default: - No ID
        :param label: Label for this metric when added to a Graph in a Dashboard. You can use `dynamic labels <https://docs.aws.amazon.com/AmazonCloudWatch/latest/monitoring/graph-dynamic-labels.html>`_ to show summary information about the entire displayed time series in the legend. For example, if you use:: [max: ${MAX}] MyMetric As the metric label, the maximum value in the visible range will be shown next to the time series name in the graph's legend. Default: - No label
        :param period: The period over which the specified statistic is applied. Default: Duration.minutes(5)
        :param region: Region which this metric comes from. Default: - Deployment region.
        :param stack_account: Account of the stack this metric is attached to. Default: - Deployment account.
        :param stack_region: Region of the stack this metric is attached to. Default: - Deployment region.
        :param statistic: What function to use for aggregating. Use the ``aws_cloudwatch.Stats`` helper class to construct valid input strings. Can be one of the following: - "Minimum" | "min" - "Maximum" | "max" - "Average" | "avg" - "Sum" | "sum" - "SampleCount | "n" - "pNN.NN" - "tmNN.NN" | "tm(NN.NN%:NN.NN%)" - "iqm" - "wmNN.NN" | "wm(NN.NN%:NN.NN%)" - "tcNN.NN" | "tc(NN.NN%:NN.NN%)" - "tsNN.NN" | "ts(NN.NN%:NN.NN%)" Default: Average
        :param unit: Unit used to filter the metric stream. Only refer to datums emitted to the metric stream with the given unit and ignore all others. Only useful when datums are being emitted to the same metric stream under different units. The default is to use all matric datums in the stream, regardless of unit, which is recommended in nearly all cases. CloudWatch does not honor this property for graphs. Default: - All metric datums in the given metric stream
        :param visible: Whether this metric should be visible in dashboard graphs. Setting this to false is useful when you want to hide raw metrics that are used in math expressions, and show only the expression results. Default: true

        :default: - sum over 60 seconds

        :stability: experimental
        '''
        ...

    @jsii.member(jsii_name="metricIngressRequestCount")
    def metric_ingress_request_count(
        self,
        *,
        account: typing.Optional[builtins.str] = None,
        color: typing.Optional[builtins.str] = None,
        dimensions_map: typing.Optional[typing.Mapping[builtins.str, builtins.str]] = None,
        id: typing.Optional[builtins.str] = None,
        label: typing.Optional[builtins.str] = None,
        period: typing.Optional["_aws_cdk_ceddda9d.Duration"] = None,
        region: typing.Optional[builtins.str] = None,
        stack_account: typing.Optional[builtins.str] = None,
        stack_region: typing.Optional[builtins.str] = None,
        statistic: typing.Optional[builtins.str] = None,
        unit: typing.Optional["_aws_cdk_aws_cloudwatch_ceddda9d.Unit"] = None,
        visible: typing.Optional[builtins.bool] = None,
    ) -> "_aws_cdk_aws_cloudwatch_ceddda9d.Metric":
        '''(experimental) Returns Metric for Ingress Request Count.

        :param account: Account which this metric comes from. Default: - Deployment account.
        :param color: The hex color code, prefixed with '#' (e.g. '#00ff00'), to use when this metric is rendered on a graph. The ``Color`` class has a set of standard colors that can be used here. Default: - Automatic color
        :param dimensions_map: Dimensions of the metric. Default: - No dimensions.
        :param id: Unique identifier for this metric when used in dashboard widgets. The id can be used as a variable to represent this metric in math expressions. Valid characters are letters, numbers, and underscore. The first character must be a lowercase letter. Default: - No ID
        :param label: Label for this metric when added to a Graph in a Dashboard. You can use `dynamic labels <https://docs.aws.amazon.com/AmazonCloudWatch/latest/monitoring/graph-dynamic-labels.html>`_ to show summary information about the entire displayed time series in the legend. For example, if you use:: [max: ${MAX}] MyMetric As the metric label, the maximum value in the visible range will be shown next to the time series name in the graph's legend. Default: - No label
        :param period: The period over which the specified statistic is applied. Default: Duration.minutes(5)
        :param region: Region which this metric comes from. Default: - Deployment region.
        :param stack_account: Account of the stack this metric is attached to. Default: - Deployment account.
        :param stack_region: Region of the stack this metric is attached to. Default: - Deployment region.
        :param statistic: What function to use for aggregating. Use the ``aws_cloudwatch.Stats`` helper class to construct valid input strings. Can be one of the following: - "Minimum" | "min" - "Maximum" | "max" - "Average" | "avg" - "Sum" | "sum" - "SampleCount | "n" - "pNN.NN" - "tmNN.NN" | "tm(NN.NN%:NN.NN%)" - "iqm" - "wmNN.NN" | "wm(NN.NN%:NN.NN%)" - "tcNN.NN" | "tc(NN.NN%:NN.NN%)" - "tsNN.NN" | "ts(NN.NN%:NN.NN%)" Default: Average
        :param unit: Unit used to filter the metric stream. Only refer to datums emitted to the metric stream with the given unit and ignore all others. Only useful when datums are being emitted to the same metric stream under different units. The default is to use all matric datums in the stream, regardless of unit, which is recommended in nearly all cases. CloudWatch does not honor this property for graphs. Default: - All metric datums in the given metric stream
        :param visible: Whether this metric should be visible in dashboard graphs. Setting this to false is useful when you want to hide raw metrics that are used in math expressions, and show only the expression results. Default: true

        :default: - sum over 60 seconds

        :stability: experimental
        '''
        ...

    @jsii.member(jsii_name="metricIngressResponseTime")
    def metric_ingress_response_time(
        self,
        *,
        account: typing.Optional[builtins.str] = None,
        color: typing.Optional[builtins.str] = None,
        dimensions_map: typing.Optional[typing.Mapping[builtins.str, builtins.str]] = None,
        id: typing.Optional[builtins.str] = None,
        label: typing.Optional[builtins.str] = None,
        period: typing.Optional["_aws_cdk_ceddda9d.Duration"] = None,
        region: typing.Optional[builtins.str] = None,
        stack_account: typing.Optional[builtins.str] = None,
        stack_region: typing.Optional[builtins.str] = None,
        statistic: typing.Optional[builtins.str] = None,
        unit: typing.Optional["_aws_cdk_aws_cloudwatch_ceddda9d.Unit"] = None,
        visible: typing.Optional[builtins.bool] = None,
    ) -> "_aws_cdk_aws_cloudwatch_ceddda9d.Metric":
        '''(experimental) Returns Metric for Ingress response time.

        :param account: Account which this metric comes from. Default: - Deployment account.
        :param color: The hex color code, prefixed with '#' (e.g. '#00ff00'), to use when this metric is rendered on a graph. The ``Color`` class has a set of standard colors that can be used here. Default: - Automatic color
        :param dimensions_map: Dimensions of the metric. Default: - No dimensions.
        :param id: Unique identifier for this metric when used in dashboard widgets. The id can be used as a variable to represent this metric in math expressions. Valid characters are letters, numbers, and underscore. The first character must be a lowercase letter. Default: - No ID
        :param label: Label for this metric when added to a Graph in a Dashboard. You can use `dynamic labels <https://docs.aws.amazon.com/AmazonCloudWatch/latest/monitoring/graph-dynamic-labels.html>`_ to show summary information about the entire displayed time series in the legend. For example, if you use:: [max: ${MAX}] MyMetric As the metric label, the maximum value in the visible range will be shown next to the time series name in the graph's legend. Default: - No label
        :param period: The period over which the specified statistic is applied. Default: Duration.minutes(5)
        :param region: Region which this metric comes from. Default: - Deployment region.
        :param stack_account: Account of the stack this metric is attached to. Default: - Deployment account.
        :param stack_region: Region of the stack this metric is attached to. Default: - Deployment region.
        :param statistic: What function to use for aggregating. Use the ``aws_cloudwatch.Stats`` helper class to construct valid input strings. Can be one of the following: - "Minimum" | "min" - "Maximum" | "max" - "Average" | "avg" - "Sum" | "sum" - "SampleCount | "n" - "pNN.NN" - "tmNN.NN" | "tm(NN.NN%:NN.NN%)" - "iqm" - "wmNN.NN" | "wm(NN.NN%:NN.NN%)" - "tcNN.NN" | "tc(NN.NN%:NN.NN%)" - "tsNN.NN" | "ts(NN.NN%:NN.NN%)" Default: Average
        :param unit: Unit used to filter the metric stream. Only refer to datums emitted to the metric stream with the given unit and ignore all others. Only useful when datums are being emitted to the same metric stream under different units. The default is to use all matric datums in the stream, regardless of unit, which is recommended in nearly all cases. CloudWatch does not honor this property for graphs. Default: - All metric datums in the given metric stream
        :param visible: Whether this metric should be visible in dashboard graphs. Setting this to false is useful when you want to hide raw metrics that are used in math expressions, and show only the expression results. Default: true

        :default: - average over 60 seconds

        :stability: experimental
        '''
        ...


class _IOriginEndpointProxy(
    jsii.proxy_for(_aws_cdk_ceddda9d.IResource), # type: ignore[misc]
    jsii.proxy_for(_aws_cdk_interfaces_aws_mediapackagev2_ceddda9d.IOriginEndpointRef), # type: ignore[misc]
):
    '''(experimental) Origin Endpoint interface.

    :stability: experimental
    '''

    __jsii_type__: typing.ClassVar[str] = "@aws-cdk/aws-mediapackagev2-alpha.IOriginEndpoint"

    @builtins.property
    @jsii.member(jsii_name="channelGroupName")
    def channel_group_name(self) -> builtins.str:
        '''(experimental) The name of the channel group associated with the origin endpoint configuration.

        :stability: experimental
        :attribute: true
        '''
        return typing.cast(builtins.str, jsii.get(self, "channelGroupName"))

    @builtins.property
    @jsii.member(jsii_name="channelName")
    def channel_name(self) -> builtins.str:
        '''(experimental) The channel name associated with the origin endpoint.

        :stability: experimental
        :attribute: true
        '''
        return typing.cast(builtins.str, jsii.get(self, "channelName"))

    @builtins.property
    @jsii.member(jsii_name="originEndpointArn")
    def origin_endpoint_arn(self) -> builtins.str:
        '''(experimental) The Amazon Resource Name (ARN) of the origin endpoint.

        :stability: experimental
        :attribute: true
        '''
        return typing.cast(builtins.str, jsii.get(self, "originEndpointArn"))

    @builtins.property
    @jsii.member(jsii_name="originEndpointName")
    def origin_endpoint_name(self) -> builtins.str:
        '''(experimental) The name of the origin endpoint associated with the origin endpoint configuration.

        :stability: experimental
        :attribute: true
        '''
        return typing.cast(builtins.str, jsii.get(self, "originEndpointName"))

    @builtins.property
    @jsii.member(jsii_name="createdAt")
    def created_at(self) -> typing.Optional[builtins.str]:
        '''(experimental) The date and time the origin endpoint was created.

        :stability: experimental
        :attribute: true
        '''
        return typing.cast(typing.Optional[builtins.str], jsii.get(self, "createdAt"))

    @builtins.property
    @jsii.member(jsii_name="dashManifestUrls")
    def dash_manifest_urls(self) -> typing.Optional[typing.List[builtins.str]]:
        '''(experimental) The DASH manifest URLs for the origin endpoint.

        :stability: experimental
        :attribute: true
        '''
        return typing.cast(typing.Optional[typing.List[builtins.str]], jsii.get(self, "dashManifestUrls"))

    @builtins.property
    @jsii.member(jsii_name="hlsManifestUrls")
    def hls_manifest_urls(self) -> typing.Optional[typing.List[builtins.str]]:
        '''(experimental) The HLS manifest URLs for the origin endpoint.

        :stability: experimental
        :attribute: true
        '''
        return typing.cast(typing.Optional[typing.List[builtins.str]], jsii.get(self, "hlsManifestUrls"))

    @builtins.property
    @jsii.member(jsii_name="lowLatencyHlsManifestUrls")
    def low_latency_hls_manifest_urls(
        self,
    ) -> typing.Optional[typing.List[builtins.str]]:
        '''(experimental) The Low Latency HLS manifest URLs for the origin endpoint.

        :stability: experimental
        :attribute: true
        '''
        return typing.cast(typing.Optional[typing.List[builtins.str]], jsii.get(self, "lowLatencyHlsManifestUrls"))

    @builtins.property
    @jsii.member(jsii_name="modifiedAt")
    def modified_at(self) -> typing.Optional[builtins.str]:
        '''(experimental) The date and time the origin endpoint was modified.

        :stability: experimental
        :attribute: true
        '''
        return typing.cast(typing.Optional[builtins.str], jsii.get(self, "modifiedAt"))

    @builtins.property
    @jsii.member(jsii_name="mssManifestUrls")
    def mss_manifest_urls(self) -> typing.Optional[typing.List[builtins.str]]:
        '''(experimental) The MSS manifest URLs for the origin endpoint.

        :stability: experimental
        :attribute: true
        '''
        return typing.cast(typing.Optional[typing.List[builtins.str]], jsii.get(self, "mssManifestUrls"))

    @jsii.member(jsii_name="addToResourcePolicy")
    def add_to_resource_policy(
        self,
        statement: "_aws_cdk_aws_iam_ceddda9d.PolicyStatement",
        *,
        secrets: typing.Sequence["_aws_cdk_aws_secretsmanager_ceddda9d.ISecret"],
        role: typing.Optional["_aws_cdk_aws_iam_ceddda9d.IRole"] = None,
    ) -> "_aws_cdk_aws_iam_ceddda9d.AddToResourcePolicyResult":
        '''(experimental) Configure origin endpoint policy.

        You can only add 1 OriginEndpointPolicy to an OriginEndpoint.
        If you have already defined one, it will append to the policy already created.

        :param statement: - The policy statement to add.
        :param secrets: (experimental) Secrets to use for CDN authorization.
        :param role: (experimental) Role to use for reading the secrets. If not provided, a role will be created automatically with the required permissions (secretsmanager:GetSecretValue, secretsmanager:DescribeSecret, secretsmanager:BatchGetSecretValue, and kms:Decrypt if the secret uses a customer-managed KMS key). Default: - a new role is created

        :stability: experimental
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__796ce7b0a89e7a57938308fa6e3a5b9a7c64c6ba67f7c57782c4b03b8573ba4c)
            check_type(argname="argument statement", value=statement, expected_type=type_hints["statement"])
        cdn_auth = CdnAuthConfiguration(secrets=secrets, role=role)

        return typing.cast("_aws_cdk_aws_iam_ceddda9d.AddToResourcePolicyResult", jsii.invoke(self, "addToResourcePolicy", [statement, cdn_auth]))

    @jsii.member(jsii_name="metric")
    def metric(
        self,
        metric_name: builtins.str,
        *,
        account: typing.Optional[builtins.str] = None,
        color: typing.Optional[builtins.str] = None,
        dimensions_map: typing.Optional[typing.Mapping[builtins.str, builtins.str]] = None,
        id: typing.Optional[builtins.str] = None,
        label: typing.Optional[builtins.str] = None,
        period: typing.Optional["_aws_cdk_ceddda9d.Duration"] = None,
        region: typing.Optional[builtins.str] = None,
        stack_account: typing.Optional[builtins.str] = None,
        stack_region: typing.Optional[builtins.str] = None,
        statistic: typing.Optional[builtins.str] = None,
        unit: typing.Optional["_aws_cdk_aws_cloudwatch_ceddda9d.Unit"] = None,
        visible: typing.Optional[builtins.bool] = None,
    ) -> "_aws_cdk_aws_cloudwatch_ceddda9d.Metric":
        '''(experimental) Create a CloudWatch metric.

        :param metric_name: name of the metric.
        :param account: Account which this metric comes from. Default: - Deployment account.
        :param color: The hex color code, prefixed with '#' (e.g. '#00ff00'), to use when this metric is rendered on a graph. The ``Color`` class has a set of standard colors that can be used here. Default: - Automatic color
        :param dimensions_map: Dimensions of the metric. Default: - No dimensions.
        :param id: Unique identifier for this metric when used in dashboard widgets. The id can be used as a variable to represent this metric in math expressions. Valid characters are letters, numbers, and underscore. The first character must be a lowercase letter. Default: - No ID
        :param label: Label for this metric when added to a Graph in a Dashboard. You can use `dynamic labels <https://docs.aws.amazon.com/AmazonCloudWatch/latest/monitoring/graph-dynamic-labels.html>`_ to show summary information about the entire displayed time series in the legend. For example, if you use:: [max: ${MAX}] MyMetric As the metric label, the maximum value in the visible range will be shown next to the time series name in the graph's legend. Default: - No label
        :param period: The period over which the specified statistic is applied. Default: Duration.minutes(5)
        :param region: Region which this metric comes from. Default: - Deployment region.
        :param stack_account: Account of the stack this metric is attached to. Default: - Deployment account.
        :param stack_region: Region of the stack this metric is attached to. Default: - Deployment region.
        :param statistic: What function to use for aggregating. Use the ``aws_cloudwatch.Stats`` helper class to construct valid input strings. Can be one of the following: - "Minimum" | "min" - "Maximum" | "max" - "Average" | "avg" - "Sum" | "sum" - "SampleCount | "n" - "pNN.NN" - "tmNN.NN" | "tm(NN.NN%:NN.NN%)" - "iqm" - "wmNN.NN" | "wm(NN.NN%:NN.NN%)" - "tcNN.NN" | "tc(NN.NN%:NN.NN%)" - "tsNN.NN" | "ts(NN.NN%:NN.NN%)" Default: Average
        :param unit: Unit used to filter the metric stream. Only refer to datums emitted to the metric stream with the given unit and ignore all others. Only useful when datums are being emitted to the same metric stream under different units. The default is to use all matric datums in the stream, regardless of unit, which is recommended in nearly all cases. CloudWatch does not honor this property for graphs. Default: - All metric datums in the given metric stream
        :param visible: Whether this metric should be visible in dashboard graphs. Setting this to false is useful when you want to hide raw metrics that are used in math expressions, and show only the expression results. Default: true

        :stability: experimental
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__98994e12767ad68f909cd493f951fde744ca3181a8848b587f62dbe99c2ae901)
            check_type(argname="argument metric_name", value=metric_name, expected_type=type_hints["metric_name"])
        props = _aws_cdk_aws_cloudwatch_ceddda9d.MetricOptions(
            account=account,
            color=color,
            dimensions_map=dimensions_map,
            id=id,
            label=label,
            period=period,
            region=region,
            stack_account=stack_account,
            stack_region=stack_region,
            statistic=statistic,
            unit=unit,
            visible=visible,
        )

        return typing.cast("_aws_cdk_aws_cloudwatch_ceddda9d.Metric", jsii.invoke(self, "metric", [metric_name, props]))

    @jsii.member(jsii_name="metricEgressBytes")
    def metric_egress_bytes(
        self,
        *,
        account: typing.Optional[builtins.str] = None,
        color: typing.Optional[builtins.str] = None,
        dimensions_map: typing.Optional[typing.Mapping[builtins.str, builtins.str]] = None,
        id: typing.Optional[builtins.str] = None,
        label: typing.Optional[builtins.str] = None,
        period: typing.Optional["_aws_cdk_ceddda9d.Duration"] = None,
        region: typing.Optional[builtins.str] = None,
        stack_account: typing.Optional[builtins.str] = None,
        stack_region: typing.Optional[builtins.str] = None,
        statistic: typing.Optional[builtins.str] = None,
        unit: typing.Optional["_aws_cdk_aws_cloudwatch_ceddda9d.Unit"] = None,
        visible: typing.Optional[builtins.bool] = None,
    ) -> "_aws_cdk_aws_cloudwatch_ceddda9d.Metric":
        '''(experimental) Returns Metric for Egress Bytes.

        :param account: Account which this metric comes from. Default: - Deployment account.
        :param color: The hex color code, prefixed with '#' (e.g. '#00ff00'), to use when this metric is rendered on a graph. The ``Color`` class has a set of standard colors that can be used here. Default: - Automatic color
        :param dimensions_map: Dimensions of the metric. Default: - No dimensions.
        :param id: Unique identifier for this metric when used in dashboard widgets. The id can be used as a variable to represent this metric in math expressions. Valid characters are letters, numbers, and underscore. The first character must be a lowercase letter. Default: - No ID
        :param label: Label for this metric when added to a Graph in a Dashboard. You can use `dynamic labels <https://docs.aws.amazon.com/AmazonCloudWatch/latest/monitoring/graph-dynamic-labels.html>`_ to show summary information about the entire displayed time series in the legend. For example, if you use:: [max: ${MAX}] MyMetric As the metric label, the maximum value in the visible range will be shown next to the time series name in the graph's legend. Default: - No label
        :param period: The period over which the specified statistic is applied. Default: Duration.minutes(5)
        :param region: Region which this metric comes from. Default: - Deployment region.
        :param stack_account: Account of the stack this metric is attached to. Default: - Deployment account.
        :param stack_region: Region of the stack this metric is attached to. Default: - Deployment region.
        :param statistic: What function to use for aggregating. Use the ``aws_cloudwatch.Stats`` helper class to construct valid input strings. Can be one of the following: - "Minimum" | "min" - "Maximum" | "max" - "Average" | "avg" - "Sum" | "sum" - "SampleCount | "n" - "pNN.NN" - "tmNN.NN" | "tm(NN.NN%:NN.NN%)" - "iqm" - "wmNN.NN" | "wm(NN.NN%:NN.NN%)" - "tcNN.NN" | "tc(NN.NN%:NN.NN%)" - "tsNN.NN" | "ts(NN.NN%:NN.NN%)" Default: Average
        :param unit: Unit used to filter the metric stream. Only refer to datums emitted to the metric stream with the given unit and ignore all others. Only useful when datums are being emitted to the same metric stream under different units. The default is to use all matric datums in the stream, regardless of unit, which is recommended in nearly all cases. CloudWatch does not honor this property for graphs. Default: - All metric datums in the given metric stream
        :param visible: Whether this metric should be visible in dashboard graphs. Setting this to false is useful when you want to hide raw metrics that are used in math expressions, and show only the expression results. Default: true

        :default: - sum over 60 seconds

        :stability: experimental
        '''
        props = _aws_cdk_aws_cloudwatch_ceddda9d.MetricOptions(
            account=account,
            color=color,
            dimensions_map=dimensions_map,
            id=id,
            label=label,
            period=period,
            region=region,
            stack_account=stack_account,
            stack_region=stack_region,
            statistic=statistic,
            unit=unit,
            visible=visible,
        )

        return typing.cast("_aws_cdk_aws_cloudwatch_ceddda9d.Metric", jsii.invoke(self, "metricEgressBytes", [props]))

    @jsii.member(jsii_name="metricEgressRequestCount")
    def metric_egress_request_count(
        self,
        *,
        account: typing.Optional[builtins.str] = None,
        color: typing.Optional[builtins.str] = None,
        dimensions_map: typing.Optional[typing.Mapping[builtins.str, builtins.str]] = None,
        id: typing.Optional[builtins.str] = None,
        label: typing.Optional[builtins.str] = None,
        period: typing.Optional["_aws_cdk_ceddda9d.Duration"] = None,
        region: typing.Optional[builtins.str] = None,
        stack_account: typing.Optional[builtins.str] = None,
        stack_region: typing.Optional[builtins.str] = None,
        statistic: typing.Optional[builtins.str] = None,
        unit: typing.Optional["_aws_cdk_aws_cloudwatch_ceddda9d.Unit"] = None,
        visible: typing.Optional[builtins.bool] = None,
    ) -> "_aws_cdk_aws_cloudwatch_ceddda9d.Metric":
        '''(experimental) Returns Metric for Egress Request Count.

        :param account: Account which this metric comes from. Default: - Deployment account.
        :param color: The hex color code, prefixed with '#' (e.g. '#00ff00'), to use when this metric is rendered on a graph. The ``Color`` class has a set of standard colors that can be used here. Default: - Automatic color
        :param dimensions_map: Dimensions of the metric. Default: - No dimensions.
        :param id: Unique identifier for this metric when used in dashboard widgets. The id can be used as a variable to represent this metric in math expressions. Valid characters are letters, numbers, and underscore. The first character must be a lowercase letter. Default: - No ID
        :param label: Label for this metric when added to a Graph in a Dashboard. You can use `dynamic labels <https://docs.aws.amazon.com/AmazonCloudWatch/latest/monitoring/graph-dynamic-labels.html>`_ to show summary information about the entire displayed time series in the legend. For example, if you use:: [max: ${MAX}] MyMetric As the metric label, the maximum value in the visible range will be shown next to the time series name in the graph's legend. Default: - No label
        :param period: The period over which the specified statistic is applied. Default: Duration.minutes(5)
        :param region: Region which this metric comes from. Default: - Deployment region.
        :param stack_account: Account of the stack this metric is attached to. Default: - Deployment account.
        :param stack_region: Region of the stack this metric is attached to. Default: - Deployment region.
        :param statistic: What function to use for aggregating. Use the ``aws_cloudwatch.Stats`` helper class to construct valid input strings. Can be one of the following: - "Minimum" | "min" - "Maximum" | "max" - "Average" | "avg" - "Sum" | "sum" - "SampleCount | "n" - "pNN.NN" - "tmNN.NN" | "tm(NN.NN%:NN.NN%)" - "iqm" - "wmNN.NN" | "wm(NN.NN%:NN.NN%)" - "tcNN.NN" | "tc(NN.NN%:NN.NN%)" - "tsNN.NN" | "ts(NN.NN%:NN.NN%)" Default: Average
        :param unit: Unit used to filter the metric stream. Only refer to datums emitted to the metric stream with the given unit and ignore all others. Only useful when datums are being emitted to the same metric stream under different units. The default is to use all matric datums in the stream, regardless of unit, which is recommended in nearly all cases. CloudWatch does not honor this property for graphs. Default: - All metric datums in the given metric stream
        :param visible: Whether this metric should be visible in dashboard graphs. Setting this to false is useful when you want to hide raw metrics that are used in math expressions, and show only the expression results. Default: true

        :default: - sum over 60 seconds

        :stability: experimental
        '''
        props = _aws_cdk_aws_cloudwatch_ceddda9d.MetricOptions(
            account=account,
            color=color,
            dimensions_map=dimensions_map,
            id=id,
            label=label,
            period=period,
            region=region,
            stack_account=stack_account,
            stack_region=stack_region,
            statistic=statistic,
            unit=unit,
            visible=visible,
        )

        return typing.cast("_aws_cdk_aws_cloudwatch_ceddda9d.Metric", jsii.invoke(self, "metricEgressRequestCount", [props]))

    @jsii.member(jsii_name="metricEgressResponseTime")
    def metric_egress_response_time(
        self,
        *,
        account: typing.Optional[builtins.str] = None,
        color: typing.Optional[builtins.str] = None,
        dimensions_map: typing.Optional[typing.Mapping[builtins.str, builtins.str]] = None,
        id: typing.Optional[builtins.str] = None,
        label: typing.Optional[builtins.str] = None,
        period: typing.Optional["_aws_cdk_ceddda9d.Duration"] = None,
        region: typing.Optional[builtins.str] = None,
        stack_account: typing.Optional[builtins.str] = None,
        stack_region: typing.Optional[builtins.str] = None,
        statistic: typing.Optional[builtins.str] = None,
        unit: typing.Optional["_aws_cdk_aws_cloudwatch_ceddda9d.Unit"] = None,
        visible: typing.Optional[builtins.bool] = None,
    ) -> "_aws_cdk_aws_cloudwatch_ceddda9d.Metric":
        '''(experimental) Returns Metric for Egress Response time.

        :param account: Account which this metric comes from. Default: - Deployment account.
        :param color: The hex color code, prefixed with '#' (e.g. '#00ff00'), to use when this metric is rendered on a graph. The ``Color`` class has a set of standard colors that can be used here. Default: - Automatic color
        :param dimensions_map: Dimensions of the metric. Default: - No dimensions.
        :param id: Unique identifier for this metric when used in dashboard widgets. The id can be used as a variable to represent this metric in math expressions. Valid characters are letters, numbers, and underscore. The first character must be a lowercase letter. Default: - No ID
        :param label: Label for this metric when added to a Graph in a Dashboard. You can use `dynamic labels <https://docs.aws.amazon.com/AmazonCloudWatch/latest/monitoring/graph-dynamic-labels.html>`_ to show summary information about the entire displayed time series in the legend. For example, if you use:: [max: ${MAX}] MyMetric As the metric label, the maximum value in the visible range will be shown next to the time series name in the graph's legend. Default: - No label
        :param period: The period over which the specified statistic is applied. Default: Duration.minutes(5)
        :param region: Region which this metric comes from. Default: - Deployment region.
        :param stack_account: Account of the stack this metric is attached to. Default: - Deployment account.
        :param stack_region: Region of the stack this metric is attached to. Default: - Deployment region.
        :param statistic: What function to use for aggregating. Use the ``aws_cloudwatch.Stats`` helper class to construct valid input strings. Can be one of the following: - "Minimum" | "min" - "Maximum" | "max" - "Average" | "avg" - "Sum" | "sum" - "SampleCount | "n" - "pNN.NN" - "tmNN.NN" | "tm(NN.NN%:NN.NN%)" - "iqm" - "wmNN.NN" | "wm(NN.NN%:NN.NN%)" - "tcNN.NN" | "tc(NN.NN%:NN.NN%)" - "tsNN.NN" | "ts(NN.NN%:NN.NN%)" Default: Average
        :param unit: Unit used to filter the metric stream. Only refer to datums emitted to the metric stream with the given unit and ignore all others. Only useful when datums are being emitted to the same metric stream under different units. The default is to use all matric datums in the stream, regardless of unit, which is recommended in nearly all cases. CloudWatch does not honor this property for graphs. Default: - All metric datums in the given metric stream
        :param visible: Whether this metric should be visible in dashboard graphs. Setting this to false is useful when you want to hide raw metrics that are used in math expressions, and show only the expression results. Default: true

        :default: - average over 60 seconds

        :stability: experimental
        '''
        props = _aws_cdk_aws_cloudwatch_ceddda9d.MetricOptions(
            account=account,
            color=color,
            dimensions_map=dimensions_map,
            id=id,
            label=label,
            period=period,
            region=region,
            stack_account=stack_account,
            stack_region=stack_region,
            statistic=statistic,
            unit=unit,
            visible=visible,
        )

        return typing.cast("_aws_cdk_aws_cloudwatch_ceddda9d.Metric", jsii.invoke(self, "metricEgressResponseTime", [props]))

    @jsii.member(jsii_name="metricIngressBytes")
    def metric_ingress_bytes(
        self,
        *,
        account: typing.Optional[builtins.str] = None,
        color: typing.Optional[builtins.str] = None,
        dimensions_map: typing.Optional[typing.Mapping[builtins.str, builtins.str]] = None,
        id: typing.Optional[builtins.str] = None,
        label: typing.Optional[builtins.str] = None,
        period: typing.Optional["_aws_cdk_ceddda9d.Duration"] = None,
        region: typing.Optional[builtins.str] = None,
        stack_account: typing.Optional[builtins.str] = None,
        stack_region: typing.Optional[builtins.str] = None,
        statistic: typing.Optional[builtins.str] = None,
        unit: typing.Optional["_aws_cdk_aws_cloudwatch_ceddda9d.Unit"] = None,
        visible: typing.Optional[builtins.bool] = None,
    ) -> "_aws_cdk_aws_cloudwatch_ceddda9d.Metric":
        '''(experimental) Returns Metric for Ingress Bytes.

        :param account: Account which this metric comes from. Default: - Deployment account.
        :param color: The hex color code, prefixed with '#' (e.g. '#00ff00'), to use when this metric is rendered on a graph. The ``Color`` class has a set of standard colors that can be used here. Default: - Automatic color
        :param dimensions_map: Dimensions of the metric. Default: - No dimensions.
        :param id: Unique identifier for this metric when used in dashboard widgets. The id can be used as a variable to represent this metric in math expressions. Valid characters are letters, numbers, and underscore. The first character must be a lowercase letter. Default: - No ID
        :param label: Label for this metric when added to a Graph in a Dashboard. You can use `dynamic labels <https://docs.aws.amazon.com/AmazonCloudWatch/latest/monitoring/graph-dynamic-labels.html>`_ to show summary information about the entire displayed time series in the legend. For example, if you use:: [max: ${MAX}] MyMetric As the metric label, the maximum value in the visible range will be shown next to the time series name in the graph's legend. Default: - No label
        :param period: The period over which the specified statistic is applied. Default: Duration.minutes(5)
        :param region: Region which this metric comes from. Default: - Deployment region.
        :param stack_account: Account of the stack this metric is attached to. Default: - Deployment account.
        :param stack_region: Region of the stack this metric is attached to. Default: - Deployment region.
        :param statistic: What function to use for aggregating. Use the ``aws_cloudwatch.Stats`` helper class to construct valid input strings. Can be one of the following: - "Minimum" | "min" - "Maximum" | "max" - "Average" | "avg" - "Sum" | "sum" - "SampleCount | "n" - "pNN.NN" - "tmNN.NN" | "tm(NN.NN%:NN.NN%)" - "iqm" - "wmNN.NN" | "wm(NN.NN%:NN.NN%)" - "tcNN.NN" | "tc(NN.NN%:NN.NN%)" - "tsNN.NN" | "ts(NN.NN%:NN.NN%)" Default: Average
        :param unit: Unit used to filter the metric stream. Only refer to datums emitted to the metric stream with the given unit and ignore all others. Only useful when datums are being emitted to the same metric stream under different units. The default is to use all matric datums in the stream, regardless of unit, which is recommended in nearly all cases. CloudWatch does not honor this property for graphs. Default: - All metric datums in the given metric stream
        :param visible: Whether this metric should be visible in dashboard graphs. Setting this to false is useful when you want to hide raw metrics that are used in math expressions, and show only the expression results. Default: true

        :default: - sum over 60 seconds

        :stability: experimental
        '''
        options = _aws_cdk_aws_cloudwatch_ceddda9d.MetricOptions(
            account=account,
            color=color,
            dimensions_map=dimensions_map,
            id=id,
            label=label,
            period=period,
            region=region,
            stack_account=stack_account,
            stack_region=stack_region,
            statistic=statistic,
            unit=unit,
            visible=visible,
        )

        return typing.cast("_aws_cdk_aws_cloudwatch_ceddda9d.Metric", jsii.invoke(self, "metricIngressBytes", [options]))

    @jsii.member(jsii_name="metricIngressRequestCount")
    def metric_ingress_request_count(
        self,
        *,
        account: typing.Optional[builtins.str] = None,
        color: typing.Optional[builtins.str] = None,
        dimensions_map: typing.Optional[typing.Mapping[builtins.str, builtins.str]] = None,
        id: typing.Optional[builtins.str] = None,
        label: typing.Optional[builtins.str] = None,
        period: typing.Optional["_aws_cdk_ceddda9d.Duration"] = None,
        region: typing.Optional[builtins.str] = None,
        stack_account: typing.Optional[builtins.str] = None,
        stack_region: typing.Optional[builtins.str] = None,
        statistic: typing.Optional[builtins.str] = None,
        unit: typing.Optional["_aws_cdk_aws_cloudwatch_ceddda9d.Unit"] = None,
        visible: typing.Optional[builtins.bool] = None,
    ) -> "_aws_cdk_aws_cloudwatch_ceddda9d.Metric":
        '''(experimental) Returns Metric for Ingress Request Count.

        :param account: Account which this metric comes from. Default: - Deployment account.
        :param color: The hex color code, prefixed with '#' (e.g. '#00ff00'), to use when this metric is rendered on a graph. The ``Color`` class has a set of standard colors that can be used here. Default: - Automatic color
        :param dimensions_map: Dimensions of the metric. Default: - No dimensions.
        :param id: Unique identifier for this metric when used in dashboard widgets. The id can be used as a variable to represent this metric in math expressions. Valid characters are letters, numbers, and underscore. The first character must be a lowercase letter. Default: - No ID
        :param label: Label for this metric when added to a Graph in a Dashboard. You can use `dynamic labels <https://docs.aws.amazon.com/AmazonCloudWatch/latest/monitoring/graph-dynamic-labels.html>`_ to show summary information about the entire displayed time series in the legend. For example, if you use:: [max: ${MAX}] MyMetric As the metric label, the maximum value in the visible range will be shown next to the time series name in the graph's legend. Default: - No label
        :param period: The period over which the specified statistic is applied. Default: Duration.minutes(5)
        :param region: Region which this metric comes from. Default: - Deployment region.
        :param stack_account: Account of the stack this metric is attached to. Default: - Deployment account.
        :param stack_region: Region of the stack this metric is attached to. Default: - Deployment region.
        :param statistic: What function to use for aggregating. Use the ``aws_cloudwatch.Stats`` helper class to construct valid input strings. Can be one of the following: - "Minimum" | "min" - "Maximum" | "max" - "Average" | "avg" - "Sum" | "sum" - "SampleCount | "n" - "pNN.NN" - "tmNN.NN" | "tm(NN.NN%:NN.NN%)" - "iqm" - "wmNN.NN" | "wm(NN.NN%:NN.NN%)" - "tcNN.NN" | "tc(NN.NN%:NN.NN%)" - "tsNN.NN" | "ts(NN.NN%:NN.NN%)" Default: Average
        :param unit: Unit used to filter the metric stream. Only refer to datums emitted to the metric stream with the given unit and ignore all others. Only useful when datums are being emitted to the same metric stream under different units. The default is to use all matric datums in the stream, regardless of unit, which is recommended in nearly all cases. CloudWatch does not honor this property for graphs. Default: - All metric datums in the given metric stream
        :param visible: Whether this metric should be visible in dashboard graphs. Setting this to false is useful when you want to hide raw metrics that are used in math expressions, and show only the expression results. Default: true

        :default: - sum over 60 seconds

        :stability: experimental
        '''
        props = _aws_cdk_aws_cloudwatch_ceddda9d.MetricOptions(
            account=account,
            color=color,
            dimensions_map=dimensions_map,
            id=id,
            label=label,
            period=period,
            region=region,
            stack_account=stack_account,
            stack_region=stack_region,
            statistic=statistic,
            unit=unit,
            visible=visible,
        )

        return typing.cast("_aws_cdk_aws_cloudwatch_ceddda9d.Metric", jsii.invoke(self, "metricIngressRequestCount", [props]))

    @jsii.member(jsii_name="metricIngressResponseTime")
    def metric_ingress_response_time(
        self,
        *,
        account: typing.Optional[builtins.str] = None,
        color: typing.Optional[builtins.str] = None,
        dimensions_map: typing.Optional[typing.Mapping[builtins.str, builtins.str]] = None,
        id: typing.Optional[builtins.str] = None,
        label: typing.Optional[builtins.str] = None,
        period: typing.Optional["_aws_cdk_ceddda9d.Duration"] = None,
        region: typing.Optional[builtins.str] = None,
        stack_account: typing.Optional[builtins.str] = None,
        stack_region: typing.Optional[builtins.str] = None,
        statistic: typing.Optional[builtins.str] = None,
        unit: typing.Optional["_aws_cdk_aws_cloudwatch_ceddda9d.Unit"] = None,
        visible: typing.Optional[builtins.bool] = None,
    ) -> "_aws_cdk_aws_cloudwatch_ceddda9d.Metric":
        '''(experimental) Returns Metric for Ingress response time.

        :param account: Account which this metric comes from. Default: - Deployment account.
        :param color: The hex color code, prefixed with '#' (e.g. '#00ff00'), to use when this metric is rendered on a graph. The ``Color`` class has a set of standard colors that can be used here. Default: - Automatic color
        :param dimensions_map: Dimensions of the metric. Default: - No dimensions.
        :param id: Unique identifier for this metric when used in dashboard widgets. The id can be used as a variable to represent this metric in math expressions. Valid characters are letters, numbers, and underscore. The first character must be a lowercase letter. Default: - No ID
        :param label: Label for this metric when added to a Graph in a Dashboard. You can use `dynamic labels <https://docs.aws.amazon.com/AmazonCloudWatch/latest/monitoring/graph-dynamic-labels.html>`_ to show summary information about the entire displayed time series in the legend. For example, if you use:: [max: ${MAX}] MyMetric As the metric label, the maximum value in the visible range will be shown next to the time series name in the graph's legend. Default: - No label
        :param period: The period over which the specified statistic is applied. Default: Duration.minutes(5)
        :param region: Region which this metric comes from. Default: - Deployment region.
        :param stack_account: Account of the stack this metric is attached to. Default: - Deployment account.
        :param stack_region: Region of the stack this metric is attached to. Default: - Deployment region.
        :param statistic: What function to use for aggregating. Use the ``aws_cloudwatch.Stats`` helper class to construct valid input strings. Can be one of the following: - "Minimum" | "min" - "Maximum" | "max" - "Average" | "avg" - "Sum" | "sum" - "SampleCount | "n" - "pNN.NN" - "tmNN.NN" | "tm(NN.NN%:NN.NN%)" - "iqm" - "wmNN.NN" | "wm(NN.NN%:NN.NN%)" - "tcNN.NN" | "tc(NN.NN%:NN.NN%)" - "tsNN.NN" | "ts(NN.NN%:NN.NN%)" Default: Average
        :param unit: Unit used to filter the metric stream. Only refer to datums emitted to the metric stream with the given unit and ignore all others. Only useful when datums are being emitted to the same metric stream under different units. The default is to use all matric datums in the stream, regardless of unit, which is recommended in nearly all cases. CloudWatch does not honor this property for graphs. Default: - All metric datums in the given metric stream
        :param visible: Whether this metric should be visible in dashboard graphs. Setting this to false is useful when you want to hide raw metrics that are used in math expressions, and show only the expression results. Default: true

        :default: - average over 60 seconds

        :stability: experimental
        '''
        props = _aws_cdk_aws_cloudwatch_ceddda9d.MetricOptions(
            account=account,
            color=color,
            dimensions_map=dimensions_map,
            id=id,
            label=label,
            period=period,
            region=region,
            stack_account=stack_account,
            stack_region=stack_region,
            statistic=statistic,
            unit=unit,
            visible=visible,
        )

        return typing.cast("_aws_cdk_aws_cloudwatch_ceddda9d.Metric", jsii.invoke(self, "metricIngressResponseTime", [props]))

# Adding a "__jsii_proxy_class__(): typing.Type" function to the interface
typing.cast(typing.Any, IOriginEndpoint).__jsii_proxy_class__ = lambda : _IOriginEndpointProxy


@jsii.enum(jsii_type="@aws-cdk/aws-mediapackagev2-alpha.IngestEndpoint")
class IngestEndpoint(enum.Enum):
    '''(experimental) Ingest Endpoint options.

    :stability: experimental
    '''

    ENDPOINT_1 = "ENDPOINT_1"
    '''(experimental) First ingest endpoint.

    :stability: experimental
    '''
    ENDPOINT_2 = "ENDPOINT_2"
    '''(experimental) Second ingest endpoint.

    :stability: experimental
    '''


class InputConfiguration(
    metaclass=jsii.JSIIMeta,
    jsii_type="@aws-cdk/aws-mediapackagev2-alpha.InputConfiguration",
):
    '''(experimental) Input configuration for a MediaPackage V2 Channel.

    Use the static factory methods to create instances:

    - InputConfiguration.hls() for HLS input
    - InputConfiguration.cmaf() for CMAF input with optional CMAF-specific features

    :stability: experimental
    :exampleMetadata: infused

    Example::

        # stack: Stack
        
        group = ChannelGroup(stack, "MyChannelGroup",
            channel_group_name="my-test-channel-group"
        )
        
        channel = Channel(stack, "MyChannel",
            channel_group=group,
            channel_name="my-testchannel",
            input=InputConfiguration.cmaf()
        )
        
        endpoint = OriginEndpoint(stack, "MyOriginEndpoint",
            channel=channel,
            origin_endpoint_name="my-test-endpoint",
            segment=Segment.cmaf(),
            manifests=[Manifest.hls(
                manifest_name="index"
            )]
        )
    '''

    @jsii.member(jsii_name="cmaf")
    @builtins.classmethod
    def cmaf(
        cls,
        *,
        input_switch_configuration: typing.Optional[typing.Union["InputSwitchConfiguration", typing.Dict[builtins.str, typing.Any]]] = None,
        output_headers: typing.Optional[typing.Sequence["HeadersCMSD"]] = None,
    ) -> "InputConfiguration":
        '''(experimental) Create a CMAF input configuration.

        :param input_switch_configuration: (experimental) The configuration for input switching based on the media quality confidence score (MQCS) as provided from AWS Elemental MediaLive. Default: No customized input switch configuration added
        :param output_headers: (experimental) The settings for what common media server data (CMSD) headers AWS Elemental MediaPackage includes in responses to the CDN. Default: none

        :stability: experimental
        '''
        props = CmafInputProps(
            input_switch_configuration=input_switch_configuration,
            output_headers=output_headers,
        )

        return typing.cast("InputConfiguration", jsii.sinvoke(cls, "cmaf", [props]))

    @jsii.member(jsii_name="hls")
    @builtins.classmethod
    def hls(cls) -> "InputConfiguration":
        '''(experimental) Create an HLS input configuration.

        :stability: experimental
        '''
        return typing.cast("InputConfiguration", jsii.sinvoke(cls, "hls", []))

    @builtins.property
    @jsii.member(jsii_name="inputType")
    def input_type(self) -> "InputType":
        '''(experimental) The input type (HLS or CMAF).

        :stability: experimental
        '''
        return typing.cast("InputType", jsii.get(self, "inputType"))

    @builtins.property
    @jsii.member(jsii_name="inputSwitchConfiguration")
    def input_switch_configuration(self) -> typing.Optional["InputSwitchConfiguration"]:
        '''(experimental) Input switch configuration (CMAF only).

        :stability: experimental
        '''
        return typing.cast(typing.Optional["InputSwitchConfiguration"], jsii.get(self, "inputSwitchConfiguration"))

    @builtins.property
    @jsii.member(jsii_name="outputHeaders")
    def output_headers(self) -> typing.Optional[typing.List["HeadersCMSD"]]:
        '''(experimental) Output headers configuration (CMAF only).

        :stability: experimental
        '''
        return typing.cast(typing.Optional[typing.List["HeadersCMSD"]], jsii.get(self, "outputHeaders"))


@jsii.data_type(
    jsii_type="@aws-cdk/aws-mediapackagev2-alpha.InputSwitchConfiguration",
    jsii_struct_bases=[],
    name_mapping={
        "mqcs_input_switching": "mqcsInputSwitching",
        "preferred_input": "preferredInput",
    },
)
class InputSwitchConfiguration:
    def __init__(
        self,
        *,
        mqcs_input_switching: typing.Optional[builtins.bool] = None,
        preferred_input: typing.Optional["IngestEndpoint"] = None,
    ) -> None:
        '''(experimental) Input Switch Configuration.

        :param mqcs_input_switching: (experimental) When true, AWS Elemental MediaPackage performs input switching based on the MQCS. This setting is valid only when InputType is CMAF. Default: false
        :param preferred_input: (experimental) For CMAF inputs, indicates which input MediaPackage should prefer when both inputs have equal MQCS scores. Select 1 to prefer the first ingest endpoint, or 2 to prefer the second ingest endpoint. If you don't specify a preferred input, MediaPackage uses its default switching behavior when MQCS scores are equal. Default: - MediaPackage uses its default switching behavior

        :stability: experimental
        :exampleMetadata: infused

        Example::

            from aws_cdk.aws_mediapackagev2_alpha import InputSwitchConfiguration
            # stack: Stack
            # group: ChannelGroup
            
            
            hls_channel = Channel(stack, "HlsChannel",
                channel_group=group,
                input=InputConfiguration.hls()
            )
            
            cmaf_channel = Channel(stack, "CmafChannel",
                channel_group=group,
                input=InputConfiguration.cmaf(
                    input_switch_configuration=InputSwitchConfiguration(
                        mqcs_input_switching=True
                    ),
                    output_headers=[HeadersCMSD.MQCS]
                )
            )
            
            simple_cmaf_channel = Channel(stack, "SimpleCmafChannel",
                channel_group=group,
                input=InputConfiguration.cmaf(
                    output_headers=[HeadersCMSD.MQCS]
                )
            )
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__0322b745dfe2f5ce9bdcbef49a8387589b631010553669609836dd3b45dcb07b)
            check_type(argname="argument mqcs_input_switching", value=mqcs_input_switching, expected_type=type_hints["mqcs_input_switching"])
            check_type(argname="argument preferred_input", value=preferred_input, expected_type=type_hints["preferred_input"])
        self._values: typing.Dict[builtins.str, typing.Any] = {}
        if mqcs_input_switching is not None:
            self._values["mqcs_input_switching"] = mqcs_input_switching
        if preferred_input is not None:
            self._values["preferred_input"] = preferred_input

    @builtins.property
    def mqcs_input_switching(self) -> typing.Optional[builtins.bool]:
        '''(experimental) When true, AWS Elemental MediaPackage performs input switching based on the MQCS.

        This setting is valid only when InputType is CMAF.

        :default: false

        :stability: experimental
        '''
        result = self._values.get("mqcs_input_switching")
        return typing.cast(typing.Optional[builtins.bool], result)

    @builtins.property
    def preferred_input(self) -> typing.Optional["IngestEndpoint"]:
        '''(experimental) For CMAF inputs, indicates which input MediaPackage should prefer when both inputs have equal MQCS scores.

        Select 1 to prefer the first ingest endpoint, or 2 to prefer the second ingest endpoint.
        If you don't specify a preferred input, MediaPackage uses its default switching behavior when MQCS scores are equal.

        :default: - MediaPackage uses its default switching behavior

        :stability: experimental
        '''
        result = self._values.get("preferred_input")
        return typing.cast(typing.Optional["IngestEndpoint"], result)

    def __eq__(self, rhs: typing.Any) -> builtins.bool:
        return isinstance(rhs, self.__class__) and rhs._values == self._values

    def __ne__(self, rhs: typing.Any) -> builtins.bool:
        return not (rhs == self)

    def __repr__(self) -> str:
        return "InputSwitchConfiguration(%s)" % ", ".join(
            k + "=" + repr(v) for k, v in self._values.items()
        )


@jsii.enum(jsii_type="@aws-cdk/aws-mediapackagev2-alpha.InputType")
class InputType(enum.Enum):
    '''(experimental) The input type will be an immutable field which will be used to define whether the channel will allow CMAF ingest or HLS ingest.

    :stability: experimental
    '''

    CMAF = "CMAF"
    '''(experimental) The DASH-IF CMAF Ingest specification (which defines CMAF segments with optional DASH manifests).

    :stability: experimental
    '''
    HLS = "HLS"
    '''(experimental) The HLS streaming specification (which defines M3U8 manifests and TS segments).

    :stability: experimental
    '''


@jsii.enum(jsii_type="@aws-cdk/aws-mediapackagev2-alpha.IsmDrmSystem")
class IsmDrmSystem(enum.Enum):
    '''(experimental) DRM systems available for ISM encryption.

    ISM only supports PlayReady with CENC.

    :stability: experimental
    '''

    PLAYREADY = "PLAYREADY"
    '''(experimental) PlayReady DRM.

    :stability: experimental
    '''


class IsmEncryption(
    EncryptionConfiguration,
    metaclass=jsii.JSIIMeta,
    jsii_type="@aws-cdk/aws-mediapackagev2-alpha.IsmEncryption",
):
    '''(experimental) Encryption configuration for ISM (Microsoft Smooth Streaming) segments.

    ISM only supports CENC encryption with PlayReady DRM.
    Audio and video presets are always SHARED.

    Use ``IsmEncryption.speke()`` to create an instance.

    :stability: experimental
    :exampleMetadata: infused

    Example::

        # channel: Channel
        # speke_role: iam.IRole
        
        
        OriginEndpoint(self, "IsmEndpoint",
            channel=channel,
            segment=Segment.ism(
                encryption=IsmEncryption.speke(
                    resource_id="my-content-id",
                    url="https://example.com/speke",
                    role=speke_role
                )
            ),
            manifests=[Manifest.mss(manifest_name="index")]
        )
    '''

    @jsii.member(jsii_name="speke")
    @builtins.classmethod
    def speke(
        cls,
        *,
        resource_id: builtins.str,
        role: "_aws_cdk_aws_iam_ceddda9d.IRole",
        url: builtins.str,
        certificate: typing.Optional["_aws_cdk_aws_certificatemanager_ceddda9d.ICertificate"] = None,
        drm_systems: typing.Optional[typing.Sequence["IsmDrmSystem"]] = None,
    ) -> "IsmEncryption":
        '''(experimental) Create a SPEKE-based encryption configuration for ISM segments.

        :param resource_id: (experimental) The unique identifier for the content.
        :param role: (experimental) IAM role for accessing the key provider API.
        :param url: (experimental) URL of the SPEKE key provider.
        :param certificate: (experimental) The ARN of the certificate that you imported to AWS Certificate Manager to add content key encryption to this endpoint. Default: - no content key encryption
        :param drm_systems: (experimental) The DRM systems to use for content protection. Default: - [IsmDrmSystem.PLAYREADY]

        :stability: experimental
        '''
        props = IsmSpekeEncryptionProps(
            resource_id=resource_id,
            role=role,
            url=url,
            certificate=certificate,
            drm_systems=drm_systems,
        )

        return typing.cast("IsmEncryption", jsii.sinvoke(cls, "speke", [props]))


@jsii.data_type(
    jsii_type="@aws-cdk/aws-mediapackagev2-alpha.IsmSpekeEncryptionProps",
    jsii_struct_bases=[],
    name_mapping={
        "resource_id": "resourceId",
        "role": "role",
        "url": "url",
        "certificate": "certificate",
        "drm_systems": "drmSystems",
    },
)
class IsmSpekeEncryptionProps:
    def __init__(
        self,
        *,
        resource_id: builtins.str,
        role: "_aws_cdk_aws_iam_ceddda9d.IRole",
        url: builtins.str,
        certificate: typing.Optional["_aws_cdk_aws_certificatemanager_ceddda9d.ICertificate"] = None,
        drm_systems: typing.Optional[typing.Sequence["IsmDrmSystem"]] = None,
    ) -> None:
        '''(experimental) Properties for ISM SPEKE encryption configuration.

        ISM only supports CENC encryption with PlayReady DRM.
        Key rotation and constant initialization vectors are not supported.
        Audio and video presets default to SHARED.

        :param resource_id: (experimental) The unique identifier for the content.
        :param role: (experimental) IAM role for accessing the key provider API.
        :param url: (experimental) URL of the SPEKE key provider.
        :param certificate: (experimental) The ARN of the certificate that you imported to AWS Certificate Manager to add content key encryption to this endpoint. Default: - no content key encryption
        :param drm_systems: (experimental) The DRM systems to use for content protection. Default: - [IsmDrmSystem.PLAYREADY]

        :stability: experimental
        :exampleMetadata: infused

        Example::

            # channel: Channel
            # speke_role: iam.IRole
            
            
            OriginEndpoint(self, "IsmEndpoint",
                channel=channel,
                segment=Segment.ism(
                    encryption=IsmEncryption.speke(
                        resource_id="my-content-id",
                        url="https://example.com/speke",
                        role=speke_role
                    )
                ),
                manifests=[Manifest.mss(manifest_name="index")]
            )
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__207e848bdbbf90ebf47dd35e4f5e8c66b32906305da08676b3d3117f9ff9a040)
            check_type(argname="argument resource_id", value=resource_id, expected_type=type_hints["resource_id"])
            check_type(argname="argument role", value=role, expected_type=type_hints["role"])
            check_type(argname="argument url", value=url, expected_type=type_hints["url"])
            check_type(argname="argument certificate", value=certificate, expected_type=type_hints["certificate"])
            check_type(argname="argument drm_systems", value=drm_systems, expected_type=type_hints["drm_systems"])
        self._values: typing.Dict[builtins.str, typing.Any] = {
            "resource_id": resource_id,
            "role": role,
            "url": url,
        }
        if certificate is not None:
            self._values["certificate"] = certificate
        if drm_systems is not None:
            self._values["drm_systems"] = drm_systems

    @builtins.property
    def resource_id(self) -> builtins.str:
        '''(experimental) The unique identifier for the content.

        :stability: experimental
        '''
        result = self._values.get("resource_id")
        assert result is not None, "Required property 'resource_id' is missing"
        return typing.cast(builtins.str, result)

    @builtins.property
    def role(self) -> "_aws_cdk_aws_iam_ceddda9d.IRole":
        '''(experimental) IAM role for accessing the key provider API.

        :stability: experimental
        '''
        result = self._values.get("role")
        assert result is not None, "Required property 'role' is missing"
        return typing.cast("_aws_cdk_aws_iam_ceddda9d.IRole", result)

    @builtins.property
    def url(self) -> builtins.str:
        '''(experimental) URL of the SPEKE key provider.

        :stability: experimental
        '''
        result = self._values.get("url")
        assert result is not None, "Required property 'url' is missing"
        return typing.cast(builtins.str, result)

    @builtins.property
    def certificate(
        self,
    ) -> typing.Optional["_aws_cdk_aws_certificatemanager_ceddda9d.ICertificate"]:
        '''(experimental) The ARN of the certificate that you imported to AWS Certificate Manager to add content key encryption to this endpoint.

        :default: - no content key encryption

        :stability: experimental
        '''
        result = self._values.get("certificate")
        return typing.cast(typing.Optional["_aws_cdk_aws_certificatemanager_ceddda9d.ICertificate"], result)

    @builtins.property
    def drm_systems(self) -> typing.Optional[typing.List["IsmDrmSystem"]]:
        '''(experimental) The DRM systems to use for content protection.

        :default: - [IsmDrmSystem.PLAYREADY]

        :stability: experimental
        '''
        result = self._values.get("drm_systems")
        return typing.cast(typing.Optional[typing.List["IsmDrmSystem"]], result)

    def __eq__(self, rhs: typing.Any) -> builtins.bool:
        return isinstance(rhs, self.__class__) and rhs._values == self._values

    def __ne__(self, rhs: typing.Any) -> builtins.bool:
        return not (rhs == self)

    def __repr__(self) -> str:
        return "IsmSpekeEncryptionProps(%s)" % ", ".join(
            k + "=" + repr(v) for k, v in self._values.items()
        )


@jsii.data_type(
    jsii_type="@aws-cdk/aws-mediapackagev2-alpha.LowLatencyHlsManifestConfiguration",
    jsii_struct_bases=[],
    name_mapping={
        "manifest_name": "manifestName",
        "child_manifest_name": "childManifestName",
        "filter_configuration": "filterConfiguration",
        "manifest_window": "manifestWindow",
        "program_date_time_interval": "programDateTimeInterval",
        "scte_ad_marker_hls": "scteAdMarkerHls",
        "start_tag": "startTag",
        "url_encode_child_manifest": "urlEncodeChildManifest",
    },
)
class LowLatencyHlsManifestConfiguration:
    def __init__(
        self,
        *,
        manifest_name: builtins.str,
        child_manifest_name: typing.Optional[builtins.str] = None,
        filter_configuration: typing.Optional[typing.Union["FilterConfiguration", typing.Dict[builtins.str, typing.Any]]] = None,
        manifest_window: typing.Optional["_aws_cdk_ceddda9d.Duration"] = None,
        program_date_time_interval: typing.Optional["_aws_cdk_ceddda9d.Duration"] = None,
        scte_ad_marker_hls: typing.Optional["AdMarkerHls"] = None,
        start_tag: typing.Optional["StartTag"] = None,
        url_encode_child_manifest: typing.Optional[builtins.bool] = None,
    ) -> None:
        '''(experimental) Specify a low-latency HTTP live streaming (LL-HLS) manifest configuration.

        :param manifest_name: (experimental) A short string that's appended to the endpoint URL. The manifest name creates a unique path to this endpoint. If you don't enter a value, MediaPackage uses the default manifest name, index. MediaPackage automatically inserts the format extension, such as .m3u8. You can't use the same manifest name if you use HLS manifest and low-latency HLS manifest. The manifestName on the HLSManifest object overrides the manifestName you provided on the originEndpoint object.
        :param child_manifest_name: (experimental) The name of the child manifest associated with the low-latency HLS (LL-HLS) manifest configuration of the origin endpoint. Default: - No child manifest name specified
        :param filter_configuration: (experimental) Filter configuration includes settings for manifest filtering, start and end times, and time delay that apply to all of your egress requests for this manifest. https://docs.aws.amazon.com/mediapackage/latest/userguide/manifest-filter-query-parameters.html Default: - No filter configuration
        :param manifest_window: (experimental) The total duration (in seconds) of the manifest's content. Default: 60
        :param program_date_time_interval: (experimental) Inserts EXT-X-PROGRAM-DATE-TIME tags in the output manifest at the interval that you specify. If you don't enter an interval, EXT-X-PROGRAM-DATE-TIME tags aren't included in the manifest. The tags sync the stream to the wall clock so that viewers can seek to a specific time in the playback timeline on the player. Default: - No program date time interval
        :param scte_ad_marker_hls: (experimental) The SCTE-35 HLS configuration associated with the low-latency HLS (LL-HLS) manifest configuration of the origin endpoint. Default: - No SCTE ad marker configuration
        :param start_tag: (experimental) Insert EXT-X-START tag in the manifest with the configured settings. Default: - No start tag
        :param url_encode_child_manifest: (experimental) When enabled, MediaPackage URL-encodes the query string for API requests for LL-HLS child manifests to comply with AWS Signature Version 4 (SigV4) signature signing protocol. For more information, see AWS Signature Version 4 for API requests in AWS Identity and Access Management User Guide. Default: false

        :stability: experimental
        :exampleMetadata: infused

        Example::

            # channel: Channel
            
            
            OriginEndpoint(self, "Endpoint",
                channel=channel,
                segment=Segment.cmaf(),
                manifests=[
                    Manifest.low_latency_hLS(
                        manifest_name="index",
                        manifest_window=Duration.seconds(30),
                        program_date_time_interval=Duration.seconds(5),
                        child_manifest_name="child"
                    )
                ]
            )
        '''
        if isinstance(filter_configuration, dict):
            filter_configuration = FilterConfiguration(**filter_configuration)
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__3b6843d9b56b39bf8da90289f17ac6d175903cffcf96c562ad4bf7494549cd06)
            check_type(argname="argument manifest_name", value=manifest_name, expected_type=type_hints["manifest_name"])
            check_type(argname="argument child_manifest_name", value=child_manifest_name, expected_type=type_hints["child_manifest_name"])
            check_type(argname="argument filter_configuration", value=filter_configuration, expected_type=type_hints["filter_configuration"])
            check_type(argname="argument manifest_window", value=manifest_window, expected_type=type_hints["manifest_window"])
            check_type(argname="argument program_date_time_interval", value=program_date_time_interval, expected_type=type_hints["program_date_time_interval"])
            check_type(argname="argument scte_ad_marker_hls", value=scte_ad_marker_hls, expected_type=type_hints["scte_ad_marker_hls"])
            check_type(argname="argument start_tag", value=start_tag, expected_type=type_hints["start_tag"])
            check_type(argname="argument url_encode_child_manifest", value=url_encode_child_manifest, expected_type=type_hints["url_encode_child_manifest"])
        self._values: typing.Dict[builtins.str, typing.Any] = {
            "manifest_name": manifest_name,
        }
        if child_manifest_name is not None:
            self._values["child_manifest_name"] = child_manifest_name
        if filter_configuration is not None:
            self._values["filter_configuration"] = filter_configuration
        if manifest_window is not None:
            self._values["manifest_window"] = manifest_window
        if program_date_time_interval is not None:
            self._values["program_date_time_interval"] = program_date_time_interval
        if scte_ad_marker_hls is not None:
            self._values["scte_ad_marker_hls"] = scte_ad_marker_hls
        if start_tag is not None:
            self._values["start_tag"] = start_tag
        if url_encode_child_manifest is not None:
            self._values["url_encode_child_manifest"] = url_encode_child_manifest

    @builtins.property
    def manifest_name(self) -> builtins.str:
        '''(experimental) A short string that's appended to the endpoint URL.

        The manifest name creates a unique path to this endpoint.
        If you don't enter a value, MediaPackage uses the default manifest name, index. MediaPackage automatically inserts the format extension, such as .m3u8.
        You can't use the same manifest name if you use HLS manifest and low-latency HLS manifest.
        The manifestName on the HLSManifest object overrides the manifestName you provided on the originEndpoint object.

        :stability: experimental
        '''
        result = self._values.get("manifest_name")
        assert result is not None, "Required property 'manifest_name' is missing"
        return typing.cast(builtins.str, result)

    @builtins.property
    def child_manifest_name(self) -> typing.Optional[builtins.str]:
        '''(experimental) The name of the child manifest associated with the low-latency HLS (LL-HLS) manifest configuration of the origin endpoint.

        :default: - No child manifest name specified

        :stability: experimental
        '''
        result = self._values.get("child_manifest_name")
        return typing.cast(typing.Optional[builtins.str], result)

    @builtins.property
    def filter_configuration(self) -> typing.Optional["FilterConfiguration"]:
        '''(experimental) Filter configuration includes settings for manifest filtering, start and end times, and time delay that apply to all of your egress requests for this manifest.

        https://docs.aws.amazon.com/mediapackage/latest/userguide/manifest-filter-query-parameters.html

        :default: - No filter configuration

        :stability: experimental
        '''
        result = self._values.get("filter_configuration")
        return typing.cast(typing.Optional["FilterConfiguration"], result)

    @builtins.property
    def manifest_window(self) -> typing.Optional["_aws_cdk_ceddda9d.Duration"]:
        '''(experimental) The total duration (in seconds) of the manifest's content.

        :default: 60

        :stability: experimental
        '''
        result = self._values.get("manifest_window")
        return typing.cast(typing.Optional["_aws_cdk_ceddda9d.Duration"], result)

    @builtins.property
    def program_date_time_interval(
        self,
    ) -> typing.Optional["_aws_cdk_ceddda9d.Duration"]:
        '''(experimental) Inserts EXT-X-PROGRAM-DATE-TIME tags in the output manifest at the interval that you specify.

        If you don't enter an interval, EXT-X-PROGRAM-DATE-TIME tags aren't included in the manifest.
        The tags sync the stream to the wall clock so that viewers can seek to a specific time in the playback timeline on the player.

        :default: - No program date time interval

        :stability: experimental
        '''
        result = self._values.get("program_date_time_interval")
        return typing.cast(typing.Optional["_aws_cdk_ceddda9d.Duration"], result)

    @builtins.property
    def scte_ad_marker_hls(self) -> typing.Optional["AdMarkerHls"]:
        '''(experimental) The SCTE-35 HLS configuration associated with the low-latency HLS (LL-HLS) manifest configuration of the origin endpoint.

        :default: - No SCTE ad marker configuration

        :stability: experimental
        '''
        result = self._values.get("scte_ad_marker_hls")
        return typing.cast(typing.Optional["AdMarkerHls"], result)

    @builtins.property
    def start_tag(self) -> typing.Optional["StartTag"]:
        '''(experimental) Insert EXT-X-START tag in the manifest with the configured settings.

        :default: - No start tag

        :stability: experimental
        '''
        result = self._values.get("start_tag")
        return typing.cast(typing.Optional["StartTag"], result)

    @builtins.property
    def url_encode_child_manifest(self) -> typing.Optional[builtins.bool]:
        '''(experimental) When enabled, MediaPackage URL-encodes the query string for API requests for LL-HLS child manifests to comply with AWS Signature Version 4 (SigV4) signature signing protocol.

        For more information, see AWS Signature Version 4 for API requests in AWS Identity and Access Management User Guide.

        :default: false

        :stability: experimental
        :external: https://docs.aws.amazon.com/IAM/latest/UserGuide/reference_sigv.html
        '''
        result = self._values.get("url_encode_child_manifest")
        return typing.cast(typing.Optional[builtins.bool], result)

    def __eq__(self, rhs: typing.Any) -> builtins.bool:
        return isinstance(rhs, self.__class__) and rhs._values == self._values

    def __ne__(self, rhs: typing.Any) -> builtins.bool:
        return not (rhs == self)

    def __repr__(self) -> str:
        return "LowLatencyHlsManifestConfiguration(%s)" % ", ".join(
            k + "=" + repr(v) for k, v in self._values.items()
        )


class Manifest(
    metaclass=jsii.JSIIAbstractClass,
    jsii_type="@aws-cdk/aws-mediapackagev2-alpha.Manifest",
):
    '''(experimental) Manifest to add to Origin Endpoint.

    :stability: experimental
    :exampleMetadata: fixture=_generated

    Example::

        # The code below shows an example of how to instantiate this type.
        # The values are placeholders you should change.
        import aws_cdk.aws_mediapackagev2_alpha as mediapackagev2_alpha
        import aws_cdk as cdk
        
        # manifest_filter: mediapackagev2_alpha.ManifestFilter
        
        manifest = mediapackagev2_alpha.Manifest.dash(
            manifest_name="manifestName",
        
            # the properties below are optional
            base_urls=[mediapackagev2_alpha.DashBaseUrlProperty(
                url="url",
        
                # the properties below are optional
                dvb_priority=123,
                dvb_weight=123,
                service_location="serviceLocation"
            )],
            compactness=mediapackagev2_alpha.DashManifestCompactness.STANDARD,
            drm_signalling=mediapackagev2_alpha.DrmSignalling.INDIVIDUAL,
            dvb_settings=mediapackagev2_alpha.DashDvbSettings(
                error_metrics=[mediapackagev2_alpha.DashDvbMetricsReporting(
                    reporting_url="reportingUrl",
        
                    # the properties below are optional
                    probability=123
                )],
                font_download=mediapackagev2_alpha.DashDvbFontDownload(
                    font_family="fontFamily",
                    mime_type="mimeType",
                    url="url"
                )
            ),
            filter_configuration=mediapackagev2_alpha.FilterConfiguration(
                clip_start_time=Date(),
                drm_settings=[mediapackagev2_alpha.DrmSettingsKey.EXCLUDE_SESSION_KEYS],
                end=Date(),
                manifest_filter=[manifest_filter],
                start=Date(),
                time_delay=cdk.Duration.minutes(30)
            ),
            manifest_window=cdk.Duration.minutes(30),
            min_buffer_time=cdk.Duration.minutes(30),
            min_update_period=cdk.Duration.minutes(30),
            period_triggers=[mediapackagev2_alpha.DashPeriodTriggers.AVAILS],
            profiles=["profiles"],
            program_information=mediapackagev2_alpha.DashProgramInformation(
                copyright="copyright",
                language_code="languageCode",
                more_information_url="moreInformationUrl",
                source="source",
                title="title"
            ),
            scte_dash_ad_marker=mediapackagev2_alpha.AdMarkerDash.BINARY,
            segment_template_format=mediapackagev2_alpha.SegmentTemplateFormat.NUMBER_WITH_TIMELINE,
            subtitle_configuration=mediapackagev2_alpha.DashSubtitleConfiguration(
                ttml_configuration=mediapackagev2_alpha.DashTtmlConfiguration(
                    ttml_profile=mediapackagev2_alpha.TtmlProfile.IMSC_1
                )
            ),
            suggested_presentation_delay=cdk.Duration.minutes(30),
            utc_timing_mode=mediapackagev2_alpha.DashUtcTimingMode.HTTP_HEAD,
            utc_timing_source="utcTimingSource"
        )
    '''

    def __init__(self) -> None:
        '''
        :stability: experimental
        '''
        jsii.create(self.__class__, self, [])

    @jsii.member(jsii_name="dash")
    @builtins.classmethod
    def dash(
        cls,
        *,
        manifest_name: builtins.str,
        base_urls: typing.Optional[typing.Sequence[typing.Union["DashBaseUrlProperty", typing.Dict[builtins.str, typing.Any]]]] = None,
        compactness: typing.Optional["DashManifestCompactness"] = None,
        drm_signalling: typing.Optional["DrmSignalling"] = None,
        dvb_settings: typing.Optional[typing.Union["DashDvbSettings", typing.Dict[builtins.str, typing.Any]]] = None,
        filter_configuration: typing.Optional[typing.Union["FilterConfiguration", typing.Dict[builtins.str, typing.Any]]] = None,
        manifest_window: typing.Optional["_aws_cdk_ceddda9d.Duration"] = None,
        min_buffer_time: typing.Optional["_aws_cdk_ceddda9d.Duration"] = None,
        min_update_period: typing.Optional["_aws_cdk_ceddda9d.Duration"] = None,
        period_triggers: typing.Optional[typing.Sequence["DashPeriodTriggers"]] = None,
        profiles: typing.Optional[typing.Sequence[builtins.str]] = None,
        program_information: typing.Optional[typing.Union["DashProgramInformation", typing.Dict[builtins.str, typing.Any]]] = None,
        scte_dash_ad_marker: typing.Optional["AdMarkerDash"] = None,
        segment_template_format: typing.Optional["SegmentTemplateFormat"] = None,
        subtitle_configuration: typing.Optional[typing.Union["DashSubtitleConfiguration", typing.Dict[builtins.str, typing.Any]]] = None,
        suggested_presentation_delay: typing.Optional["_aws_cdk_ceddda9d.Duration"] = None,
        utc_timing_mode: typing.Optional["DashUtcTimingMode"] = None,
        utc_timing_source: typing.Optional[builtins.str] = None,
    ) -> "Manifest":
        '''(experimental) Specify a manifest configuration for DASH.

        **Note:** DASH manifests require CMAF container type.
        Use with ``Segment.cmaf()``.

        :param manifest_name: (experimental) The name of the manifest associated with the DASH manifest configuration.
        :param base_urls: (experimental) The base URLs to use for retrieving segments. Default: - No base URLs specified
        :param compactness: (experimental) The layout of the DASH manifest that MediaPackage produces. Default: DashManifestCompactness.STANDARD
        :param drm_signalling: (experimental) DRM signaling determines the way DASH manifest signals the DRM content. Default: - No DRM signaling specified
        :param dvb_settings: (experimental) For endpoints that use the DVB-DASH profile only. Default: - No DVB settings
        :param filter_configuration: (experimental) Filter configuration includes settings for manifest filtering, start and end times, and time delay that apply to all of your egress requests for this manifest. https://docs.aws.amazon.com/mediapackage/latest/userguide/manifest-filter-query-parameters.html Default: - No filter configuration
        :param manifest_window: (experimental) The total duration (in seconds) of the manifest's content. Default: 60
        :param min_buffer_time: (experimental) The minimum amount of content that the player must keep available in the buffer. Default: 5
        :param min_update_period: (experimental) The minimum amount of time for the player to wait before requesting an updated manifest. Default: 2
        :param period_triggers: (experimental) Specify what triggers cause AWS Elemental MediaPackage to create media presentation description (MPD) periods in the output manifest. Default: [DashPeriodTriggers.AVAILS, DashPeriodTriggers.DRM_KEY_ROTATION, DashPeriodTriggers.SOURCE_CHANGES, DashPeriodTriggers.SOURCE_DISRUPTIONS]
        :param profiles: (experimental) The profile that the output is compliant with. Default: - No profiles specified
        :param program_information: (experimental) Details about the content that you want MediaPackage to pass through in the manifest to the playback device. Default: - No program information
        :param scte_dash_ad_marker: (experimental) Choose how ad markers are included in the packaged content. If you include ad markers in the content stream in your upstream encoders, then you need to inform MediaPackage what to do with the ad markers in the output. To choose this option STCE filtering needs to be enabled. Default: AdMarkerDash.XML
        :param segment_template_format: (experimental) The type of variable that MediaPackage uses in the media attribute of the SegmentTemplate tag. Default: SegmentTemplateFormat.NUMBER_WITH_TIMELINE
        :param subtitle_configuration: (experimental) The configuration for DASH subtitles. Default: - No subtitle configuration
        :param suggested_presentation_delay: (experimental) The amount of time that the player should be from the end of the manifest. Default: 10
        :param utc_timing_mode: (experimental) The UTC timing mode. Default: DashUtcTimingMode.UTC_DIRECT
        :param utc_timing_source: (experimental) The method that the player uses to synchronize to coordinated universal time (UTC) wall clock time. Default: undefined - No value is specified

        :stability: experimental
        '''
        manifest = DashManifestConfiguration(
            manifest_name=manifest_name,
            base_urls=base_urls,
            compactness=compactness,
            drm_signalling=drm_signalling,
            dvb_settings=dvb_settings,
            filter_configuration=filter_configuration,
            manifest_window=manifest_window,
            min_buffer_time=min_buffer_time,
            min_update_period=min_update_period,
            period_triggers=period_triggers,
            profiles=profiles,
            program_information=program_information,
            scte_dash_ad_marker=scte_dash_ad_marker,
            segment_template_format=segment_template_format,
            subtitle_configuration=subtitle_configuration,
            suggested_presentation_delay=suggested_presentation_delay,
            utc_timing_mode=utc_timing_mode,
            utc_timing_source=utc_timing_source,
        )

        return typing.cast("Manifest", jsii.sinvoke(cls, "dash", [manifest]))

    @jsii.member(jsii_name="hls")
    @builtins.classmethod
    def hls(
        cls,
        *,
        manifest_name: builtins.str,
        child_manifest_name: typing.Optional[builtins.str] = None,
        filter_configuration: typing.Optional[typing.Union["FilterConfiguration", typing.Dict[builtins.str, typing.Any]]] = None,
        manifest_window: typing.Optional["_aws_cdk_ceddda9d.Duration"] = None,
        program_date_time_interval: typing.Optional["_aws_cdk_ceddda9d.Duration"] = None,
        scte_ad_marker_hls: typing.Optional["AdMarkerHls"] = None,
        start_tag: typing.Optional["StartTag"] = None,
        url_encode_child_manifest: typing.Optional[builtins.bool] = None,
    ) -> "Manifest":
        '''(experimental) Specify a manifest configuration for HLS.

        **Note:** HLS manifests require TS or CMAF container type.
        Use with ``Segment.ts()`` or ``Segment.cmaf()``.

        :param manifest_name: (experimental) The name of the manifest associated with the HLS manifest configuration.
        :param child_manifest_name: (experimental) The name of the child manifest associated with the HLS manifest configuration. Default: - No child manifest name specified
        :param filter_configuration: (experimental) Filter configuration includes settings for manifest filtering, start and end times, and time delay that apply to all of your egress requests for this manifest. https://docs.aws.amazon.com/mediapackage/latest/userguide/manifest-filter-query-parameters.html Default: - No filter configuration
        :param manifest_window: (experimental) The total duration (in seconds) of the manifest's content. Default: 60
        :param program_date_time_interval: (experimental) Inserts EXT-X-PROGRAM-DATE-TIME tags in the output manifest at the interval that you specify. If you don't enter an interval, EXT-X-PROGRAM-DATE-TIME tags aren't included in the manifest. The tags sync the stream to the wall clock so that viewers can seek to a specific time in the playback timeline on the player. Default: - No program date time interval
        :param scte_ad_marker_hls: (experimental) The SCTE-35 HLS configuration associated with the HLS manifest configuration of the origin endpoint. Default: - No SCTE ad marker configuration
        :param start_tag: (experimental) Insert EXT-X-START tag in the manifest with the configured settings. Default: - No start tag
        :param url_encode_child_manifest: (experimental) When enabled, MediaPackage URL-encodes the query string for API requests for HLS child manifests to comply with AWS Signature Version 4 (SigV4) signature signing protocol. For more information, see AWS Signature Version 4 for API requests in AWS Identity and Access Management User Guide. Default: false

        :stability: experimental
        '''
        manifest = HlsManifestConfiguration(
            manifest_name=manifest_name,
            child_manifest_name=child_manifest_name,
            filter_configuration=filter_configuration,
            manifest_window=manifest_window,
            program_date_time_interval=program_date_time_interval,
            scte_ad_marker_hls=scte_ad_marker_hls,
            start_tag=start_tag,
            url_encode_child_manifest=url_encode_child_manifest,
        )

        return typing.cast("Manifest", jsii.sinvoke(cls, "hls", [manifest]))

    @jsii.member(jsii_name="lowLatencyHLS")
    @builtins.classmethod
    def low_latency_hls(
        cls,
        *,
        manifest_name: builtins.str,
        child_manifest_name: typing.Optional[builtins.str] = None,
        filter_configuration: typing.Optional[typing.Union["FilterConfiguration", typing.Dict[builtins.str, typing.Any]]] = None,
        manifest_window: typing.Optional["_aws_cdk_ceddda9d.Duration"] = None,
        program_date_time_interval: typing.Optional["_aws_cdk_ceddda9d.Duration"] = None,
        scte_ad_marker_hls: typing.Optional["AdMarkerHls"] = None,
        start_tag: typing.Optional["StartTag"] = None,
        url_encode_child_manifest: typing.Optional[builtins.bool] = None,
    ) -> "Manifest":
        '''(experimental) Specify a manifest configuration for Low Latency HLS.

        **Note:** Low Latency HLS manifests require TS or CMAF container type.
        Use with ``Segment.ts()`` or ``Segment.cmaf()``.

        :param manifest_name: (experimental) A short string that's appended to the endpoint URL. The manifest name creates a unique path to this endpoint. If you don't enter a value, MediaPackage uses the default manifest name, index. MediaPackage automatically inserts the format extension, such as .m3u8. You can't use the same manifest name if you use HLS manifest and low-latency HLS manifest. The manifestName on the HLSManifest object overrides the manifestName you provided on the originEndpoint object.
        :param child_manifest_name: (experimental) The name of the child manifest associated with the low-latency HLS (LL-HLS) manifest configuration of the origin endpoint. Default: - No child manifest name specified
        :param filter_configuration: (experimental) Filter configuration includes settings for manifest filtering, start and end times, and time delay that apply to all of your egress requests for this manifest. https://docs.aws.amazon.com/mediapackage/latest/userguide/manifest-filter-query-parameters.html Default: - No filter configuration
        :param manifest_window: (experimental) The total duration (in seconds) of the manifest's content. Default: 60
        :param program_date_time_interval: (experimental) Inserts EXT-X-PROGRAM-DATE-TIME tags in the output manifest at the interval that you specify. If you don't enter an interval, EXT-X-PROGRAM-DATE-TIME tags aren't included in the manifest. The tags sync the stream to the wall clock so that viewers can seek to a specific time in the playback timeline on the player. Default: - No program date time interval
        :param scte_ad_marker_hls: (experimental) The SCTE-35 HLS configuration associated with the low-latency HLS (LL-HLS) manifest configuration of the origin endpoint. Default: - No SCTE ad marker configuration
        :param start_tag: (experimental) Insert EXT-X-START tag in the manifest with the configured settings. Default: - No start tag
        :param url_encode_child_manifest: (experimental) When enabled, MediaPackage URL-encodes the query string for API requests for LL-HLS child manifests to comply with AWS Signature Version 4 (SigV4) signature signing protocol. For more information, see AWS Signature Version 4 for API requests in AWS Identity and Access Management User Guide. Default: false

        :stability: experimental
        '''
        manifest = LowLatencyHlsManifestConfiguration(
            manifest_name=manifest_name,
            child_manifest_name=child_manifest_name,
            filter_configuration=filter_configuration,
            manifest_window=manifest_window,
            program_date_time_interval=program_date_time_interval,
            scte_ad_marker_hls=scte_ad_marker_hls,
            start_tag=start_tag,
            url_encode_child_manifest=url_encode_child_manifest,
        )

        return typing.cast("Manifest", jsii.sinvoke(cls, "lowLatencyHLS", [manifest]))

    @jsii.member(jsii_name="mss")
    @builtins.classmethod
    def mss(
        cls,
        *,
        manifest_name: builtins.str,
        filter_configuration: typing.Optional[typing.Union["FilterConfiguration", typing.Dict[builtins.str, typing.Any]]] = None,
        manifest_layout: typing.Optional["MssManifestLayout"] = None,
        manifest_window: typing.Optional["_aws_cdk_ceddda9d.Duration"] = None,
    ) -> "Manifest":
        '''(experimental) Specify a manifest configuration for MSS.

        **Note:** MSS manifests require ISM container type.
        Use with ``Segment.ism()``.

        :param manifest_name: (experimental) The name of the manifest associated with the MSS manifest configuration.
        :param filter_configuration: (experimental) Filter configuration includes settings for manifest filtering, start and end times, and time delay that apply to all of your egress requests for this manifest. https://docs.aws.amazon.com/mediapackage/latest/userguide/manifest-filter-query-parameters.html Default: - No filter configuration
        :param manifest_layout: (experimental) The layout of the MSS manifest. Default: MssManifestLayout.FULL
        :param manifest_window: (experimental) The total duration (in seconds) of the manifest's content. Default: 60

        :stability: experimental
        '''
        manifest = MssManifestConfiguration(
            manifest_name=manifest_name,
            filter_configuration=filter_configuration,
            manifest_layout=manifest_layout,
            manifest_window=manifest_window,
        )

        return typing.cast("Manifest", jsii.sinvoke(cls, "mss", [manifest]))


class _ManifestProxy(Manifest):
    pass

# Adding a "__jsii_proxy_class__(): typing.Type" function to the abstract class
typing.cast(typing.Any, Manifest).__jsii_proxy_class__ = lambda : _ManifestProxy


class ManifestFilter(
    metaclass=jsii.JSIIMeta,
    jsii_type="@aws-cdk/aws-mediapackagev2-alpha.ManifestFilter",
):
    '''(experimental) Enables you to create filters for your Origin Endpoint.

    :see: https://docs.aws.amazon.com/mediapackage/latest/userguide/manifest-filtering.html
    :stability: experimental
    :exampleMetadata: fixture=_generated

    Example::

        # The code below shows an example of how to instantiate this type.
        # The values are placeholders you should change.
        import aws_cdk.aws_mediapackagev2_alpha as mediapackagev2_alpha
        
        manifest_filter = mediapackagev2_alpha.ManifestFilter.audio_codec(mediapackagev2_alpha.AudioCodec.AACL)
    '''

    def __init__(self, filter_string: builtins.str) -> None:
        '''
        :param filter_string: Normalised manifest filter string.

        :stability: experimental
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__9825d21f69fabb4cec87019ce84bc63ed79b035871d8b693552decd8a1bd5e63)
            check_type(argname="argument filter_string", value=filter_string, expected_type=type_hints["filter_string"])
        jsii.create(self.__class__, self, [filter_string])

    @jsii.member(jsii_name="audioCodec")
    @builtins.classmethod
    def audio_codec(cls, value: "AudioCodec") -> "ManifestFilter":
        '''(experimental) Filter by a single audio codec.

        :param value: -

        :stability: experimental
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__b6270414059c407cdd2b50e5a7ab9be08cffc062093a8fae130143973e79a99c)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        return typing.cast("ManifestFilter", jsii.sinvoke(cls, "audioCodec", [value]))

    @jsii.member(jsii_name="audioCodecList")
    @builtins.classmethod
    def audio_codec_list(
        cls,
        values: typing.Sequence["AudioCodec"],
    ) -> "ManifestFilter":
        '''(experimental) Filter by multiple audio codecs.

        :param values: -

        :stability: experimental
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__4da8bd2766cad77f0dea5e023286f68642ffe78457fe39ae4918f9ca1aa73c5c)
            check_type(argname="argument values", value=values, expected_type=type_hints["values"])
        return typing.cast("ManifestFilter", jsii.sinvoke(cls, "audioCodecList", [values]))

    @jsii.member(jsii_name="bitrate")
    @builtins.classmethod
    def bitrate(
        cls,
        key: "BitrateFilterKey",
        value: "_aws_cdk_ceddda9d.Bitrate",
    ) -> "ManifestFilter":
        '''(experimental) Filter by a single bitrate value.

        :param key: -
        :param value: -

        :stability: experimental
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__eccd222c793a79ed2e2b6087c379441c1e6e87f2bea169d99bb075a6556f4671)
            check_type(argname="argument key", value=key, expected_type=type_hints["key"])
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        return typing.cast("ManifestFilter", jsii.sinvoke(cls, "bitrate", [key, value]))

    @jsii.member(jsii_name="bitrateCombo")
    @builtins.classmethod
    def bitrate_combo(
        cls,
        key: "BitrateFilterKey",
        expressions: typing.Sequence["BitrateExpression"],
    ) -> "ManifestFilter":
        '''(experimental) Filter by a combination of bitrate ranges and individual values.

        :param key: -
        :param expressions: -

        :stability: experimental

        Example::

            ManifestFilter.bitrate_combo(BitrateFilterKey.VIDEO_BITRATE, [
                BitrateExpression.range(Bitrate.mbps(1), Bitrate.mbps(3)),
                BitrateExpression.value(Bitrate.mbps(5))
            ])
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__62fe494c007c76c81d7ecdf66d4777f830a615793745f7838c58fcb34b92aa01)
            check_type(argname="argument key", value=key, expected_type=type_hints["key"])
            check_type(argname="argument expressions", value=expressions, expected_type=type_hints["expressions"])
        return typing.cast("ManifestFilter", jsii.sinvoke(cls, "bitrateCombo", [key, expressions]))

    @jsii.member(jsii_name="bitrateRange")
    @builtins.classmethod
    def bitrate_range(
        cls,
        key: "BitrateFilterKey",
        start: "_aws_cdk_ceddda9d.Bitrate",
        end: "_aws_cdk_ceddda9d.Bitrate",
    ) -> "ManifestFilter":
        '''(experimental) Filter by a bitrate range (inclusive).

        :param key: -
        :param start: -
        :param end: -

        :stability: experimental
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__24b8dffd92844ad1235488ca97b83b7526f70c9b0b08a5f0edc58bc1010ce6a5)
            check_type(argname="argument key", value=key, expected_type=type_hints["key"])
            check_type(argname="argument start", value=start, expected_type=type_hints["start"])
            check_type(argname="argument end", value=end, expected_type=type_hints["end"])
        return typing.cast("ManifestFilter", jsii.sinvoke(cls, "bitrateRange", [key, start, end]))

    @jsii.member(jsii_name="custom")
    @builtins.classmethod
    def custom(cls, custom: builtins.str) -> "ManifestFilter":
        '''(experimental) Specify a custom manifest filter string.

        :param custom: -

        :stability: experimental
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__f9967f92c2353efa3d34354b108f2af19e715419347edb0a052907620aafd9b6)
            check_type(argname="argument custom", value=custom, expected_type=type_hints["custom"])
        return typing.cast("ManifestFilter", jsii.sinvoke(cls, "custom", [custom]))

    @jsii.member(jsii_name="numeric")
    @builtins.classmethod
    def numeric(cls, key: "NumericFilterKey", value: jsii.Number) -> "ManifestFilter":
        '''(experimental) Specify a single numeric filter value.

        :param key: -
        :param value: -

        :stability: experimental
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__4d0a8dd380f286730cd486679707664425d5457ad36985679d380638cffd9e7d)
            check_type(argname="argument key", value=key, expected_type=type_hints["key"])
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        return typing.cast("ManifestFilter", jsii.sinvoke(cls, "numeric", [key, value]))

    @jsii.member(jsii_name="numericCombo")
    @builtins.classmethod
    def numeric_combo(
        cls,
        key: "NumericFilterKey",
        expressions: typing.Sequence["NumericExpression"],
    ) -> "ManifestFilter":
        '''(experimental) Filter by a combination of numeric ranges and individual values.

        Use this for advanced patterns like ``video_height:240-360,720-1080,1440``.

        :param key: -
        :param expressions: -

        :stability: experimental

        Example::

            ManifestFilter.numeric_combo(NumericFilterKey.VIDEO_HEIGHT, [
                NumericExpression.range(240, 360),
                NumericExpression.range(720, 1080),
                NumericExpression.value(1440)
            ])
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__6f805d86d5124f55bd9e1850f9eb8b61df99ea9fde48023180229150d903e7bb)
            check_type(argname="argument key", value=key, expected_type=type_hints["key"])
            check_type(argname="argument expressions", value=expressions, expected_type=type_hints["expressions"])
        return typing.cast("ManifestFilter", jsii.sinvoke(cls, "numericCombo", [key, expressions]))

    @jsii.member(jsii_name="numericList")
    @builtins.classmethod
    def numeric_list(
        cls,
        key: "NumericFilterKey",
        values: typing.Sequence[jsii.Number],
    ) -> "ManifestFilter":
        '''(experimental) Specify multiple numeric filter values.

        :param key: -
        :param values: -

        :stability: experimental
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__ca5c4dd8d6c6b3324af3b690df18a06b5766af5002c7fb6c109e5c6d12687416)
            check_type(argname="argument key", value=key, expected_type=type_hints["key"])
            check_type(argname="argument values", value=values, expected_type=type_hints["values"])
        return typing.cast("ManifestFilter", jsii.sinvoke(cls, "numericList", [key, values]))

    @jsii.member(jsii_name="numericRange")
    @builtins.classmethod
    def numeric_range(
        cls,
        key: "NumericFilterKey",
        start: jsii.Number,
        end: jsii.Number,
    ) -> "ManifestFilter":
        '''(experimental) Specify a numeric filter range (inclusive).

        :param key: -
        :param start: -
        :param end: -

        :stability: experimental
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__8c6c9b64e68e31399b4d690d62093560525f8da3ab8784bf1618de87ceceb015)
            check_type(argname="argument key", value=key, expected_type=type_hints["key"])
            check_type(argname="argument start", value=start, expected_type=type_hints["start"])
            check_type(argname="argument end", value=end, expected_type=type_hints["end"])
        return typing.cast("ManifestFilter", jsii.sinvoke(cls, "numericRange", [key, start, end]))

    @jsii.member(jsii_name="text")
    @builtins.classmethod
    def text(cls, key: "TextFilterKey", value: builtins.str) -> "ManifestFilter":
        '''(experimental) Specify a free-form text filter value (for language keys).

        :param key: -
        :param value: -

        :stability: experimental
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__e9a95432fade1331da6dfcaf2997fa1a93b67691a6e262adc275c47cee0be589)
            check_type(argname="argument key", value=key, expected_type=type_hints["key"])
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        return typing.cast("ManifestFilter", jsii.sinvoke(cls, "text", [key, value]))

    @jsii.member(jsii_name="textList")
    @builtins.classmethod
    def text_list(
        cls,
        key: "TextFilterKey",
        values: typing.Sequence[builtins.str],
    ) -> "ManifestFilter":
        '''(experimental) Specify multiple free-form text filter values (for language keys).

        :param key: -
        :param values: -

        :stability: experimental
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__f855a7a6062acdeddc45ec68ce7819baee54e82a53267b1a7c31e98cf0a0f612)
            check_type(argname="argument key", value=key, expected_type=type_hints["key"])
            check_type(argname="argument values", value=values, expected_type=type_hints["values"])
        return typing.cast("ManifestFilter", jsii.sinvoke(cls, "textList", [key, values]))

    @jsii.member(jsii_name="trickplayType")
    @builtins.classmethod
    def trickplay_type(cls, value: "TrickplayType") -> "ManifestFilter":
        '''(experimental) Filter by a single trickplay type.

        :param value: -

        :stability: experimental
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__818f63b4445f749b764ec916c619b494da512e38a5013d7f6208b05dc10a7a53)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        return typing.cast("ManifestFilter", jsii.sinvoke(cls, "trickplayType", [value]))

    @jsii.member(jsii_name="trickplayTypeList")
    @builtins.classmethod
    def trickplay_type_list(
        cls,
        values: typing.Sequence["TrickplayType"],
    ) -> "ManifestFilter":
        '''(experimental) Filter by multiple trickplay types.

        :param values: -

        :stability: experimental
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__5d8d6f8b2aa02e67fd5fe2a21c0836f30ed78c229c86e70483859f27efec40ae)
            check_type(argname="argument values", value=values, expected_type=type_hints["values"])
        return typing.cast("ManifestFilter", jsii.sinvoke(cls, "trickplayTypeList", [values]))

    @jsii.member(jsii_name="videoCodec")
    @builtins.classmethod
    def video_codec(cls, value: "VideoCodec") -> "ManifestFilter":
        '''(experimental) Filter by a single video codec.

        :param value: -

        :stability: experimental
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__9e5976d7c112a7fc453c17920fc25bfd4579a19c014bc6a2938895fbf88acd81)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        return typing.cast("ManifestFilter", jsii.sinvoke(cls, "videoCodec", [value]))

    @jsii.member(jsii_name="videoCodecList")
    @builtins.classmethod
    def video_codec_list(
        cls,
        values: typing.Sequence["VideoCodec"],
    ) -> "ManifestFilter":
        '''(experimental) Filter by multiple video codecs.

        :param values: -

        :stability: experimental
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__0034d4b0d5bafef541077e86052a4d3cd8b37ef3978eafb000a6ba0a92cbd88e)
            check_type(argname="argument values", value=values, expected_type=type_hints["values"])
        return typing.cast("ManifestFilter", jsii.sinvoke(cls, "videoCodecList", [values]))

    @jsii.member(jsii_name="videoDynamicRange")
    @builtins.classmethod
    def video_dynamic_range(cls, value: "VideoDynamicRange") -> "ManifestFilter":
        '''(experimental) Filter by a single video dynamic range.

        :param value: -

        :stability: experimental
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__0036fd0d969a84cebf3fe1e55be95b1a9ab2889e77b2081b71ea5eda8de9cab4)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        return typing.cast("ManifestFilter", jsii.sinvoke(cls, "videoDynamicRange", [value]))

    @jsii.member(jsii_name="videoDynamicRangeList")
    @builtins.classmethod
    def video_dynamic_range_list(
        cls,
        values: typing.Sequence["VideoDynamicRange"],
    ) -> "ManifestFilter":
        '''(experimental) Filter by multiple video dynamic ranges.

        :param values: -

        :stability: experimental
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__9a36914b492312df842a3a9fd7b2665f42b65c1ddbf423631438b959cce0a1a3)
            check_type(argname="argument values", value=values, expected_type=type_hints["values"])
        return typing.cast("ManifestFilter", jsii.sinvoke(cls, "videoDynamicRangeList", [values]))

    @builtins.property
    @jsii.member(jsii_name="filterString")
    def filter_string(self) -> builtins.str:
        '''(experimental) Normalised manifest filter string.

        :stability: experimental
        '''
        return typing.cast(builtins.str, jsii.get(self, "filterString"))


@jsii.data_type(
    jsii_type="@aws-cdk/aws-mediapackagev2-alpha.MssManifestConfiguration",
    jsii_struct_bases=[],
    name_mapping={
        "manifest_name": "manifestName",
        "filter_configuration": "filterConfiguration",
        "manifest_layout": "manifestLayout",
        "manifest_window": "manifestWindow",
    },
)
class MssManifestConfiguration:
    def __init__(
        self,
        *,
        manifest_name: builtins.str,
        filter_configuration: typing.Optional[typing.Union["FilterConfiguration", typing.Dict[builtins.str, typing.Any]]] = None,
        manifest_layout: typing.Optional["MssManifestLayout"] = None,
        manifest_window: typing.Optional["_aws_cdk_ceddda9d.Duration"] = None,
    ) -> None:
        '''(experimental) The MSS manifest configuration associated with the origin endpoint.

        :param manifest_name: (experimental) The name of the manifest associated with the MSS manifest configuration.
        :param filter_configuration: (experimental) Filter configuration includes settings for manifest filtering, start and end times, and time delay that apply to all of your egress requests for this manifest. https://docs.aws.amazon.com/mediapackage/latest/userguide/manifest-filter-query-parameters.html Default: - No filter configuration
        :param manifest_layout: (experimental) The layout of the MSS manifest. Default: MssManifestLayout.FULL
        :param manifest_window: (experimental) The total duration (in seconds) of the manifest's content. Default: 60

        :stability: experimental
        :exampleMetadata: infused

        Example::

            # channel: Channel
            
            
            OriginEndpoint(self, "Endpoint",
                channel=channel,
                segment=Segment.ism(),
                manifests=[
                    Manifest.mss(
                        manifest_name="index",
                        manifest_window=Duration.seconds(60),
                        manifest_layout=MssManifestLayout.COMPACT
                    )
                ]
            )
        '''
        if isinstance(filter_configuration, dict):
            filter_configuration = FilterConfiguration(**filter_configuration)
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__bd1ffa43ee487e6baff6fc48d73ba83d9f802907c33c72e4b90a0990a5a5c67b)
            check_type(argname="argument manifest_name", value=manifest_name, expected_type=type_hints["manifest_name"])
            check_type(argname="argument filter_configuration", value=filter_configuration, expected_type=type_hints["filter_configuration"])
            check_type(argname="argument manifest_layout", value=manifest_layout, expected_type=type_hints["manifest_layout"])
            check_type(argname="argument manifest_window", value=manifest_window, expected_type=type_hints["manifest_window"])
        self._values: typing.Dict[builtins.str, typing.Any] = {
            "manifest_name": manifest_name,
        }
        if filter_configuration is not None:
            self._values["filter_configuration"] = filter_configuration
        if manifest_layout is not None:
            self._values["manifest_layout"] = manifest_layout
        if manifest_window is not None:
            self._values["manifest_window"] = manifest_window

    @builtins.property
    def manifest_name(self) -> builtins.str:
        '''(experimental) The name of the manifest associated with the MSS manifest configuration.

        :stability: experimental
        '''
        result = self._values.get("manifest_name")
        assert result is not None, "Required property 'manifest_name' is missing"
        return typing.cast(builtins.str, result)

    @builtins.property
    def filter_configuration(self) -> typing.Optional["FilterConfiguration"]:
        '''(experimental) Filter configuration includes settings for manifest filtering, start and end times, and time delay that apply to all of your egress requests for this manifest.

        https://docs.aws.amazon.com/mediapackage/latest/userguide/manifest-filter-query-parameters.html

        :default: - No filter configuration

        :stability: experimental
        '''
        result = self._values.get("filter_configuration")
        return typing.cast(typing.Optional["FilterConfiguration"], result)

    @builtins.property
    def manifest_layout(self) -> typing.Optional["MssManifestLayout"]:
        '''(experimental) The layout of the MSS manifest.

        :default: MssManifestLayout.FULL

        :stability: experimental
        '''
        result = self._values.get("manifest_layout")
        return typing.cast(typing.Optional["MssManifestLayout"], result)

    @builtins.property
    def manifest_window(self) -> typing.Optional["_aws_cdk_ceddda9d.Duration"]:
        '''(experimental) The total duration (in seconds) of the manifest's content.

        :default: 60

        :stability: experimental
        '''
        result = self._values.get("manifest_window")
        return typing.cast(typing.Optional["_aws_cdk_ceddda9d.Duration"], result)

    def __eq__(self, rhs: typing.Any) -> builtins.bool:
        return isinstance(rhs, self.__class__) and rhs._values == self._values

    def __ne__(self, rhs: typing.Any) -> builtins.bool:
        return not (rhs == self)

    def __repr__(self) -> str:
        return "MssManifestConfiguration(%s)" % ", ".join(
            k + "=" + repr(v) for k, v in self._values.items()
        )


@jsii.enum(jsii_type="@aws-cdk/aws-mediapackagev2-alpha.MssManifestLayout")
class MssManifestLayout(enum.Enum):
    '''(experimental) The layout of the MSS manifest.

    :stability: experimental
    :exampleMetadata: infused

    Example::

        # channel: Channel
        
        
        OriginEndpoint(self, "Endpoint",
            channel=channel,
            segment=Segment.ism(),
            manifests=[
                Manifest.mss(
                    manifest_name="index",
                    manifest_window=Duration.seconds(60),
                    manifest_layout=MssManifestLayout.COMPACT
                )
            ]
        )
    '''

    FULL = "FULL"
    '''(experimental) Full manifest layout.

    :stability: experimental
    '''
    COMPACT = "COMPACT"
    '''(experimental) Compact manifest layout.

    :stability: experimental
    '''


class NumericExpression(
    metaclass=jsii.JSIIMeta,
    jsii_type="@aws-cdk/aws-mediapackagev2-alpha.NumericExpression",
):
    '''(experimental) Represents a numeric filter expression segment — either a single value or a range.

    Use with ``ManifestFilter.numericCombo()`` to build filters that combine
    ranges and individual values (e.g. ``video_height:240-360,720-1080,1440``).

    :stability: experimental
    :exampleMetadata: fixture=_generated

    Example::

        # The code below shows an example of how to instantiate this type.
        # The values are placeholders you should change.
        import aws_cdk.aws_mediapackagev2_alpha as mediapackagev2_alpha
        
        numeric_expression = mediapackagev2_alpha.NumericExpression.range(123, 123)
    '''

    def __init__(
        self,
        _expression: builtins.str,
        _values: typing.Sequence[jsii.Number],
    ) -> None:
        '''
        :param _expression: 
        :param _values: 

        :stability: experimental
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__91ec48f608c030b98f198e3d6b9ce6feebec494c04d6cecba578af86ee144bde)
            check_type(argname="argument _expression", value=_expression, expected_type=type_hints["_expression"])
            check_type(argname="argument _values", value=_values, expected_type=type_hints["_values"])
        jsii.create(self.__class__, self, [_expression, _values])

    @jsii.member(jsii_name="range")
    @builtins.classmethod
    def range(cls, start: jsii.Number, end: jsii.Number) -> "NumericExpression":
        '''(experimental) An inclusive numeric range.

        :param start: -
        :param end: -

        :stability: experimental
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__667160b8a039452ef047a9629f8a55f36ac350557a7cfbe5a933b4c13de23fec)
            check_type(argname="argument start", value=start, expected_type=type_hints["start"])
            check_type(argname="argument end", value=end, expected_type=type_hints["end"])
        return typing.cast("NumericExpression", jsii.sinvoke(cls, "range", [start, end]))

    @jsii.member(jsii_name="value")
    @builtins.classmethod
    def value(cls, v: jsii.Number) -> "NumericExpression":
        '''(experimental) A single numeric value.

        :param v: -

        :stability: experimental
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__ff7e97f856edd07cbabfc6db4ac3bab38f056284f3cacdb5758e5a5ed3409f58)
            check_type(argname="argument v", value=v, expected_type=type_hints["v"])
        return typing.cast("NumericExpression", jsii.sinvoke(cls, "value", [v]))


@jsii.enum(jsii_type="@aws-cdk/aws-mediapackagev2-alpha.NumericFilterKey")
class NumericFilterKey(enum.Enum):
    '''(experimental) Numeric manifest filter keys.

    Use with ``ManifestFilter.numeric()``, ``ManifestFilter.numericList()``, and ``ManifestFilter.numericRange()``.

    Audio and video bitrate filters are not included here because they use the
    ``Bitrate`` class directly via dedicated methods on ``ManifestFilter``.

    :see: https://docs.aws.amazon.com/mediapackage/latest/userguide/manifest-filter-query-parameters.html
    :stability: experimental
    :exampleMetadata: infused

    Example::

        from aws_cdk.aws_mediapackagev2_alpha import FilterConfiguration
        # channel: Channel
        
        
        OriginEndpoint(self, "Endpoint",
            channel=channel,
            segment=Segment.cmaf(),
            manifests=[
                Manifest.hls(
                    manifest_name="index",
                    filter_configuration=FilterConfiguration(
                        manifest_filter=[
                            # video_height:240-360,720-1080,1440
                            ManifestFilter.numeric_combo(NumericFilterKey.VIDEO_HEIGHT, [
                                NumericExpression.range(240, 360),
                                NumericExpression.range(720, 1080),
                                NumericExpression.value(1440)
                            ])
                        ]
                    )
                )
            ]
        )
    '''

    AUDIO_CHANNELS = "AUDIO_CHANNELS"
    '''(experimental) The number of audio channels.

    Accepted values: range 1–32767, or individual integers.

    :stability: experimental
    '''
    AUDIO_SAMPLE_RATE = "AUDIO_SAMPLE_RATE"
    '''(experimental) The audio sample rate in Hz.

    Accepted values: range 0–2147483647, or individual integers.

    :stability: experimental
    '''
    TRICKPLAY_HEIGHT = "TRICKPLAY_HEIGHT"
    '''(experimental) The height of the trick-play image in pixels (I-frame and image-based trick-play).

    If using with I-frame only trick-play, ``TRICKPLAY_HEIGHT`` and ``VIDEO_HEIGHT``
    should have similar values. If they differ, I-frame only tracks might be
    removed from the manifest.

    Accepted values: range 1–2147483647, or individual integers.

    :stability: experimental
    '''
    VIDEO_FRAMERATE = "VIDEO_FRAMERATE"
    '''(experimental) The video frame rate range in NTSC format.

    When filtering for a single value, MediaPackage uses an approximate equals
    comparison with an epsilon tolerance of 0.0005.

    Accepted values: range 1–999.999 (up to three decimal places), or individual values.

    :stability: experimental
    '''
    VIDEO_HEIGHT = "VIDEO_HEIGHT"
    '''(experimental) The height of the video in pixels.

    If using with I-frame only trick-play, ``TRICKPLAY_HEIGHT`` and ``VIDEO_HEIGHT``
    should have similar values. If they differ, I-frame only tracks might be
    removed from the manifest.

    Accepted values: range 1–32767, or individual integers.

    :stability: experimental
    '''


@jsii.implements(IOriginEndpoint)
class OriginEndpoint(
    _aws_cdk_ceddda9d.Resource,
    metaclass=jsii.JSIIMeta,
    jsii_type="@aws-cdk/aws-mediapackagev2-alpha.OriginEndpoint",
):
    '''(experimental) Defines an AWS Elemental MediaPackage V2 Origin Endpoint.

    :stability: experimental
    :exampleMetadata: infused

    Example::

        # channel: Channel
        # speke_role: iam.IRole
        
        
        OriginEndpoint(self, "TsEndpoint",
            channel=channel,
            segment=Segment.ts(
                encryption=TsEncryption.speke(
                    method=TsEncryptionMethod.SAMPLE_AES,
                    resource_id="my-content-id",
                    url="https://example.com/speke",
                    role=speke_role
                )
            ),
            manifests=[Manifest.hls(manifest_name="index")]
        )
    '''

    def __init__(
        self,
        scope: "_constructs_77d1e7e8.Construct",
        id: builtins.str,
        *,
        channel: "IChannel",
        manifests: typing.Sequence["Manifest"],
        segment: typing.Union["SegmentConfiguration", typing.Dict[builtins.str, typing.Any]],
        cdn_auth: typing.Optional[typing.Union["CdnAuthConfiguration", typing.Dict[builtins.str, typing.Any]]] = None,
        description: typing.Optional[builtins.str] = None,
        force_endpoint_configuration_conditions: typing.Optional[typing.Sequence["EndpointErrorConfiguration"]] = None,
        origin_endpoint_name: typing.Optional[builtins.str] = None,
        removal_policy: typing.Optional["_aws_cdk_ceddda9d.RemovalPolicy"] = None,
        startover_window: typing.Optional["_aws_cdk_ceddda9d.Duration"] = None,
        tags: typing.Optional[typing.Mapping[builtins.str, builtins.str]] = None,
    ) -> None:
        '''
        :param scope: -
        :param id: -
        :param channel: (experimental) The channel associated with the origin endpoint.
        :param manifests: (experimental) Manifests configuration for HLS, Low Latency HLS and DASH.
        :param segment: (experimental) The segment associated with the origin endpoint. Inside the segment configuration you can define options such as encryption, SPEKE parameters and other general segment configurations. Use Segment.ts() or Segment.cmaf() to create the configuration.
        :param cdn_auth: (experimental) Provide access to MediaPackage V2 Origin Endpoint via secret header. Default: undefined - Not configured on endpoint
        :param description: (experimental) The description associated with the origin endpoint. Default: undefined - No description is added to Origin Endpoint
        :param force_endpoint_configuration_conditions: (experimental) The failover settings for the endpoint. Default: undefined - No force endpoint configuration is configured
        :param origin_endpoint_name: (experimental) The name of the origin endpoint associated with the origin endpoint configuration. Default: autogenerated
        :param removal_policy: (experimental) Policy to apply when the origin endpoint is removed from the stack. Even though MediaPackage ChannelGroups, Channels and OriginEndpoints are technically stateful, their contents are transient and it is common to add and remove these while rearchitecting your application. The default is therefore ``DESTROY``. Change it to ``RETAIN`` if the content (in a lookback window) are so valuable that accidentally losing it would be unacceptable. Default: RemovalPolicy.DESTROY
        :param startover_window: (experimental) The size of the window to specify a window of the live stream that's available for on-demand viewing. Viewers can start-over or catch-up on content that falls within the window. Default: 900
        :param tags: (experimental) The tags associated with the origin endpoint. Default: - No tagging

        :stability: experimental
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__bebcb7d2659b0bd6e9f9e1898d5650db070e4aa180d87cc5c208d5623c31921b)
            check_type(argname="argument scope", value=scope, expected_type=type_hints["scope"])
            check_type(argname="argument id", value=id, expected_type=type_hints["id"])
        props = OriginEndpointProps(
            channel=channel,
            manifests=manifests,
            segment=segment,
            cdn_auth=cdn_auth,
            description=description,
            force_endpoint_configuration_conditions=force_endpoint_configuration_conditions,
            origin_endpoint_name=origin_endpoint_name,
            removal_policy=removal_policy,
            startover_window=startover_window,
            tags=tags,
        )

        jsii.create(self.__class__, self, [scope, id, props])

    @jsii.member(jsii_name="fromOriginEndpointAttributes")
    @builtins.classmethod
    def from_origin_endpoint_attributes(
        cls,
        scope: "_constructs_77d1e7e8.Construct",
        id: builtins.str,
        *,
        channel_group_name: builtins.str,
        channel_name: builtins.str,
        origin_endpoint_name: builtins.str,
    ) -> "IOriginEndpoint":
        '''(experimental) Creates an OriginEndpoint construct that represents an external (imported) Origin Endpoint.

        :param scope: -
        :param id: -
        :param channel_group_name: (experimental) The name that describes the channel group. The name is the primary identifier for the channel group.
        :param channel_name: (experimental) The name that describes the channel. The name is the primary identifier for the channel.
        :param origin_endpoint_name: (experimental) The name that describes the origin endpoint.

        :stability: experimental
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__08c1b6698153d058e059c9a5869a6e97f4e3b8a73584db23b2dd860b683a75cd)
            check_type(argname="argument scope", value=scope, expected_type=type_hints["scope"])
            check_type(argname="argument id", value=id, expected_type=type_hints["id"])
        attrs = OriginEndpointAttributes(
            channel_group_name=channel_group_name,
            channel_name=channel_name,
            origin_endpoint_name=origin_endpoint_name,
        )

        return typing.cast("IOriginEndpoint", jsii.sinvoke(cls, "fromOriginEndpointAttributes", [scope, id, attrs]))

    @jsii.member(jsii_name="addToResourcePolicy")
    def add_to_resource_policy(
        self,
        statement: "_aws_cdk_aws_iam_ceddda9d.PolicyStatement",
        *,
        secrets: typing.Sequence["_aws_cdk_aws_secretsmanager_ceddda9d.ISecret"],
        role: typing.Optional["_aws_cdk_aws_iam_ceddda9d.IRole"] = None,
    ) -> "_aws_cdk_aws_iam_ceddda9d.AddToResourcePolicyResult":
        '''(experimental) Configure origin endpoint policy.

        You can only add 1 OriginEndpointPolicy to an OriginEndpoint.
        If you have already defined one, it will append to the policy already created.

        :param statement: - The policy statement to add.
        :param secrets: (experimental) Secrets to use for CDN authorization.
        :param role: (experimental) Role to use for reading the secrets. If not provided, a role will be created automatically with the required permissions (secretsmanager:GetSecretValue, secretsmanager:DescribeSecret, secretsmanager:BatchGetSecretValue, and kms:Decrypt if the secret uses a customer-managed KMS key). Default: - a new role is created

        :stability: experimental
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__b6270cd12d501c0354caf98dd06608a78c2fa1fce2a764e16bed67b71032605b)
            check_type(argname="argument statement", value=statement, expected_type=type_hints["statement"])
        cdn_auth = CdnAuthConfiguration(secrets=secrets, role=role)

        return typing.cast("_aws_cdk_aws_iam_ceddda9d.AddToResourcePolicyResult", jsii.invoke(self, "addToResourcePolicy", [statement, cdn_auth]))

    @jsii.member(jsii_name="metric")
    def metric(
        self,
        metric_name: builtins.str,
        *,
        account: typing.Optional[builtins.str] = None,
        color: typing.Optional[builtins.str] = None,
        dimensions_map: typing.Optional[typing.Mapping[builtins.str, builtins.str]] = None,
        id: typing.Optional[builtins.str] = None,
        label: typing.Optional[builtins.str] = None,
        period: typing.Optional["_aws_cdk_ceddda9d.Duration"] = None,
        region: typing.Optional[builtins.str] = None,
        stack_account: typing.Optional[builtins.str] = None,
        stack_region: typing.Optional[builtins.str] = None,
        statistic: typing.Optional[builtins.str] = None,
        unit: typing.Optional["_aws_cdk_aws_cloudwatch_ceddda9d.Unit"] = None,
        visible: typing.Optional[builtins.bool] = None,
    ) -> "_aws_cdk_aws_cloudwatch_ceddda9d.Metric":
        '''(experimental) Create a CloudWatch metric.

        :param metric_name: name of the metric.
        :param account: Account which this metric comes from. Default: - Deployment account.
        :param color: The hex color code, prefixed with '#' (e.g. '#00ff00'), to use when this metric is rendered on a graph. The ``Color`` class has a set of standard colors that can be used here. Default: - Automatic color
        :param dimensions_map: Dimensions of the metric. Default: - No dimensions.
        :param id: Unique identifier for this metric when used in dashboard widgets. The id can be used as a variable to represent this metric in math expressions. Valid characters are letters, numbers, and underscore. The first character must be a lowercase letter. Default: - No ID
        :param label: Label for this metric when added to a Graph in a Dashboard. You can use `dynamic labels <https://docs.aws.amazon.com/AmazonCloudWatch/latest/monitoring/graph-dynamic-labels.html>`_ to show summary information about the entire displayed time series in the legend. For example, if you use:: [max: ${MAX}] MyMetric As the metric label, the maximum value in the visible range will be shown next to the time series name in the graph's legend. Default: - No label
        :param period: The period over which the specified statistic is applied. Default: Duration.minutes(5)
        :param region: Region which this metric comes from. Default: - Deployment region.
        :param stack_account: Account of the stack this metric is attached to. Default: - Deployment account.
        :param stack_region: Region of the stack this metric is attached to. Default: - Deployment region.
        :param statistic: What function to use for aggregating. Use the ``aws_cloudwatch.Stats`` helper class to construct valid input strings. Can be one of the following: - "Minimum" | "min" - "Maximum" | "max" - "Average" | "avg" - "Sum" | "sum" - "SampleCount | "n" - "pNN.NN" - "tmNN.NN" | "tm(NN.NN%:NN.NN%)" - "iqm" - "wmNN.NN" | "wm(NN.NN%:NN.NN%)" - "tcNN.NN" | "tc(NN.NN%:NN.NN%)" - "tsNN.NN" | "ts(NN.NN%:NN.NN%)" Default: Average
        :param unit: Unit used to filter the metric stream. Only refer to datums emitted to the metric stream with the given unit and ignore all others. Only useful when datums are being emitted to the same metric stream under different units. The default is to use all matric datums in the stream, regardless of unit, which is recommended in nearly all cases. CloudWatch does not honor this property for graphs. Default: - All metric datums in the given metric stream
        :param visible: Whether this metric should be visible in dashboard graphs. Setting this to false is useful when you want to hide raw metrics that are used in math expressions, and show only the expression results. Default: true

        :stability: experimental
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__93ec0aae1665f4ca315dc11b1ba73b7c507a182c3dbd99782987f958b51072c6)
            check_type(argname="argument metric_name", value=metric_name, expected_type=type_hints["metric_name"])
        props = _aws_cdk_aws_cloudwatch_ceddda9d.MetricOptions(
            account=account,
            color=color,
            dimensions_map=dimensions_map,
            id=id,
            label=label,
            period=period,
            region=region,
            stack_account=stack_account,
            stack_region=stack_region,
            statistic=statistic,
            unit=unit,
            visible=visible,
        )

        return typing.cast("_aws_cdk_aws_cloudwatch_ceddda9d.Metric", jsii.invoke(self, "metric", [metric_name, props]))

    @jsii.member(jsii_name="metricEgressBytes")
    def metric_egress_bytes(
        self,
        *,
        account: typing.Optional[builtins.str] = None,
        color: typing.Optional[builtins.str] = None,
        dimensions_map: typing.Optional[typing.Mapping[builtins.str, builtins.str]] = None,
        id: typing.Optional[builtins.str] = None,
        label: typing.Optional[builtins.str] = None,
        period: typing.Optional["_aws_cdk_ceddda9d.Duration"] = None,
        region: typing.Optional[builtins.str] = None,
        stack_account: typing.Optional[builtins.str] = None,
        stack_region: typing.Optional[builtins.str] = None,
        statistic: typing.Optional[builtins.str] = None,
        unit: typing.Optional["_aws_cdk_aws_cloudwatch_ceddda9d.Unit"] = None,
        visible: typing.Optional[builtins.bool] = None,
    ) -> "_aws_cdk_aws_cloudwatch_ceddda9d.Metric":
        '''(experimental) Returns Metric for Egress Bytes.

        :param account: Account which this metric comes from. Default: - Deployment account.
        :param color: The hex color code, prefixed with '#' (e.g. '#00ff00'), to use when this metric is rendered on a graph. The ``Color`` class has a set of standard colors that can be used here. Default: - Automatic color
        :param dimensions_map: Dimensions of the metric. Default: - No dimensions.
        :param id: Unique identifier for this metric when used in dashboard widgets. The id can be used as a variable to represent this metric in math expressions. Valid characters are letters, numbers, and underscore. The first character must be a lowercase letter. Default: - No ID
        :param label: Label for this metric when added to a Graph in a Dashboard. You can use `dynamic labels <https://docs.aws.amazon.com/AmazonCloudWatch/latest/monitoring/graph-dynamic-labels.html>`_ to show summary information about the entire displayed time series in the legend. For example, if you use:: [max: ${MAX}] MyMetric As the metric label, the maximum value in the visible range will be shown next to the time series name in the graph's legend. Default: - No label
        :param period: The period over which the specified statistic is applied. Default: Duration.minutes(5)
        :param region: Region which this metric comes from. Default: - Deployment region.
        :param stack_account: Account of the stack this metric is attached to. Default: - Deployment account.
        :param stack_region: Region of the stack this metric is attached to. Default: - Deployment region.
        :param statistic: What function to use for aggregating. Use the ``aws_cloudwatch.Stats`` helper class to construct valid input strings. Can be one of the following: - "Minimum" | "min" - "Maximum" | "max" - "Average" | "avg" - "Sum" | "sum" - "SampleCount | "n" - "pNN.NN" - "tmNN.NN" | "tm(NN.NN%:NN.NN%)" - "iqm" - "wmNN.NN" | "wm(NN.NN%:NN.NN%)" - "tcNN.NN" | "tc(NN.NN%:NN.NN%)" - "tsNN.NN" | "ts(NN.NN%:NN.NN%)" Default: Average
        :param unit: Unit used to filter the metric stream. Only refer to datums emitted to the metric stream with the given unit and ignore all others. Only useful when datums are being emitted to the same metric stream under different units. The default is to use all matric datums in the stream, regardless of unit, which is recommended in nearly all cases. CloudWatch does not honor this property for graphs. Default: - All metric datums in the given metric stream
        :param visible: Whether this metric should be visible in dashboard graphs. Setting this to false is useful when you want to hide raw metrics that are used in math expressions, and show only the expression results. Default: true

        :default: - sum over 60 seconds

        :stability: experimental
        '''
        props = _aws_cdk_aws_cloudwatch_ceddda9d.MetricOptions(
            account=account,
            color=color,
            dimensions_map=dimensions_map,
            id=id,
            label=label,
            period=period,
            region=region,
            stack_account=stack_account,
            stack_region=stack_region,
            statistic=statistic,
            unit=unit,
            visible=visible,
        )

        return typing.cast("_aws_cdk_aws_cloudwatch_ceddda9d.Metric", jsii.invoke(self, "metricEgressBytes", [props]))

    @jsii.member(jsii_name="metricEgressRequestCount")
    def metric_egress_request_count(
        self,
        *,
        account: typing.Optional[builtins.str] = None,
        color: typing.Optional[builtins.str] = None,
        dimensions_map: typing.Optional[typing.Mapping[builtins.str, builtins.str]] = None,
        id: typing.Optional[builtins.str] = None,
        label: typing.Optional[builtins.str] = None,
        period: typing.Optional["_aws_cdk_ceddda9d.Duration"] = None,
        region: typing.Optional[builtins.str] = None,
        stack_account: typing.Optional[builtins.str] = None,
        stack_region: typing.Optional[builtins.str] = None,
        statistic: typing.Optional[builtins.str] = None,
        unit: typing.Optional["_aws_cdk_aws_cloudwatch_ceddda9d.Unit"] = None,
        visible: typing.Optional[builtins.bool] = None,
    ) -> "_aws_cdk_aws_cloudwatch_ceddda9d.Metric":
        '''(experimental) Returns Metric for Egress Request Count.

        :param account: Account which this metric comes from. Default: - Deployment account.
        :param color: The hex color code, prefixed with '#' (e.g. '#00ff00'), to use when this metric is rendered on a graph. The ``Color`` class has a set of standard colors that can be used here. Default: - Automatic color
        :param dimensions_map: Dimensions of the metric. Default: - No dimensions.
        :param id: Unique identifier for this metric when used in dashboard widgets. The id can be used as a variable to represent this metric in math expressions. Valid characters are letters, numbers, and underscore. The first character must be a lowercase letter. Default: - No ID
        :param label: Label for this metric when added to a Graph in a Dashboard. You can use `dynamic labels <https://docs.aws.amazon.com/AmazonCloudWatch/latest/monitoring/graph-dynamic-labels.html>`_ to show summary information about the entire displayed time series in the legend. For example, if you use:: [max: ${MAX}] MyMetric As the metric label, the maximum value in the visible range will be shown next to the time series name in the graph's legend. Default: - No label
        :param period: The period over which the specified statistic is applied. Default: Duration.minutes(5)
        :param region: Region which this metric comes from. Default: - Deployment region.
        :param stack_account: Account of the stack this metric is attached to. Default: - Deployment account.
        :param stack_region: Region of the stack this metric is attached to. Default: - Deployment region.
        :param statistic: What function to use for aggregating. Use the ``aws_cloudwatch.Stats`` helper class to construct valid input strings. Can be one of the following: - "Minimum" | "min" - "Maximum" | "max" - "Average" | "avg" - "Sum" | "sum" - "SampleCount | "n" - "pNN.NN" - "tmNN.NN" | "tm(NN.NN%:NN.NN%)" - "iqm" - "wmNN.NN" | "wm(NN.NN%:NN.NN%)" - "tcNN.NN" | "tc(NN.NN%:NN.NN%)" - "tsNN.NN" | "ts(NN.NN%:NN.NN%)" Default: Average
        :param unit: Unit used to filter the metric stream. Only refer to datums emitted to the metric stream with the given unit and ignore all others. Only useful when datums are being emitted to the same metric stream under different units. The default is to use all matric datums in the stream, regardless of unit, which is recommended in nearly all cases. CloudWatch does not honor this property for graphs. Default: - All metric datums in the given metric stream
        :param visible: Whether this metric should be visible in dashboard graphs. Setting this to false is useful when you want to hide raw metrics that are used in math expressions, and show only the expression results. Default: true

        :default: - sum over 60 seconds

        :stability: experimental
        '''
        props = _aws_cdk_aws_cloudwatch_ceddda9d.MetricOptions(
            account=account,
            color=color,
            dimensions_map=dimensions_map,
            id=id,
            label=label,
            period=period,
            region=region,
            stack_account=stack_account,
            stack_region=stack_region,
            statistic=statistic,
            unit=unit,
            visible=visible,
        )

        return typing.cast("_aws_cdk_aws_cloudwatch_ceddda9d.Metric", jsii.invoke(self, "metricEgressRequestCount", [props]))

    @jsii.member(jsii_name="metricEgressResponseTime")
    def metric_egress_response_time(
        self,
        *,
        account: typing.Optional[builtins.str] = None,
        color: typing.Optional[builtins.str] = None,
        dimensions_map: typing.Optional[typing.Mapping[builtins.str, builtins.str]] = None,
        id: typing.Optional[builtins.str] = None,
        label: typing.Optional[builtins.str] = None,
        period: typing.Optional["_aws_cdk_ceddda9d.Duration"] = None,
        region: typing.Optional[builtins.str] = None,
        stack_account: typing.Optional[builtins.str] = None,
        stack_region: typing.Optional[builtins.str] = None,
        statistic: typing.Optional[builtins.str] = None,
        unit: typing.Optional["_aws_cdk_aws_cloudwatch_ceddda9d.Unit"] = None,
        visible: typing.Optional[builtins.bool] = None,
    ) -> "_aws_cdk_aws_cloudwatch_ceddda9d.Metric":
        '''(experimental) Returns Metric for Egress Response time.

        :param account: Account which this metric comes from. Default: - Deployment account.
        :param color: The hex color code, prefixed with '#' (e.g. '#00ff00'), to use when this metric is rendered on a graph. The ``Color`` class has a set of standard colors that can be used here. Default: - Automatic color
        :param dimensions_map: Dimensions of the metric. Default: - No dimensions.
        :param id: Unique identifier for this metric when used in dashboard widgets. The id can be used as a variable to represent this metric in math expressions. Valid characters are letters, numbers, and underscore. The first character must be a lowercase letter. Default: - No ID
        :param label: Label for this metric when added to a Graph in a Dashboard. You can use `dynamic labels <https://docs.aws.amazon.com/AmazonCloudWatch/latest/monitoring/graph-dynamic-labels.html>`_ to show summary information about the entire displayed time series in the legend. For example, if you use:: [max: ${MAX}] MyMetric As the metric label, the maximum value in the visible range will be shown next to the time series name in the graph's legend. Default: - No label
        :param period: The period over which the specified statistic is applied. Default: Duration.minutes(5)
        :param region: Region which this metric comes from. Default: - Deployment region.
        :param stack_account: Account of the stack this metric is attached to. Default: - Deployment account.
        :param stack_region: Region of the stack this metric is attached to. Default: - Deployment region.
        :param statistic: What function to use for aggregating. Use the ``aws_cloudwatch.Stats`` helper class to construct valid input strings. Can be one of the following: - "Minimum" | "min" - "Maximum" | "max" - "Average" | "avg" - "Sum" | "sum" - "SampleCount | "n" - "pNN.NN" - "tmNN.NN" | "tm(NN.NN%:NN.NN%)" - "iqm" - "wmNN.NN" | "wm(NN.NN%:NN.NN%)" - "tcNN.NN" | "tc(NN.NN%:NN.NN%)" - "tsNN.NN" | "ts(NN.NN%:NN.NN%)" Default: Average
        :param unit: Unit used to filter the metric stream. Only refer to datums emitted to the metric stream with the given unit and ignore all others. Only useful when datums are being emitted to the same metric stream under different units. The default is to use all matric datums in the stream, regardless of unit, which is recommended in nearly all cases. CloudWatch does not honor this property for graphs. Default: - All metric datums in the given metric stream
        :param visible: Whether this metric should be visible in dashboard graphs. Setting this to false is useful when you want to hide raw metrics that are used in math expressions, and show only the expression results. Default: true

        :default: - average over 60 seconds

        :stability: experimental
        '''
        props = _aws_cdk_aws_cloudwatch_ceddda9d.MetricOptions(
            account=account,
            color=color,
            dimensions_map=dimensions_map,
            id=id,
            label=label,
            period=period,
            region=region,
            stack_account=stack_account,
            stack_region=stack_region,
            statistic=statistic,
            unit=unit,
            visible=visible,
        )

        return typing.cast("_aws_cdk_aws_cloudwatch_ceddda9d.Metric", jsii.invoke(self, "metricEgressResponseTime", [props]))

    @jsii.member(jsii_name="metricIngressBytes")
    def metric_ingress_bytes(
        self,
        *,
        account: typing.Optional[builtins.str] = None,
        color: typing.Optional[builtins.str] = None,
        dimensions_map: typing.Optional[typing.Mapping[builtins.str, builtins.str]] = None,
        id: typing.Optional[builtins.str] = None,
        label: typing.Optional[builtins.str] = None,
        period: typing.Optional["_aws_cdk_ceddda9d.Duration"] = None,
        region: typing.Optional[builtins.str] = None,
        stack_account: typing.Optional[builtins.str] = None,
        stack_region: typing.Optional[builtins.str] = None,
        statistic: typing.Optional[builtins.str] = None,
        unit: typing.Optional["_aws_cdk_aws_cloudwatch_ceddda9d.Unit"] = None,
        visible: typing.Optional[builtins.bool] = None,
    ) -> "_aws_cdk_aws_cloudwatch_ceddda9d.Metric":
        '''(experimental) Returns Metric for Ingress Bytes.

        :param account: Account which this metric comes from. Default: - Deployment account.
        :param color: The hex color code, prefixed with '#' (e.g. '#00ff00'), to use when this metric is rendered on a graph. The ``Color`` class has a set of standard colors that can be used here. Default: - Automatic color
        :param dimensions_map: Dimensions of the metric. Default: - No dimensions.
        :param id: Unique identifier for this metric when used in dashboard widgets. The id can be used as a variable to represent this metric in math expressions. Valid characters are letters, numbers, and underscore. The first character must be a lowercase letter. Default: - No ID
        :param label: Label for this metric when added to a Graph in a Dashboard. You can use `dynamic labels <https://docs.aws.amazon.com/AmazonCloudWatch/latest/monitoring/graph-dynamic-labels.html>`_ to show summary information about the entire displayed time series in the legend. For example, if you use:: [max: ${MAX}] MyMetric As the metric label, the maximum value in the visible range will be shown next to the time series name in the graph's legend. Default: - No label
        :param period: The period over which the specified statistic is applied. Default: Duration.minutes(5)
        :param region: Region which this metric comes from. Default: - Deployment region.
        :param stack_account: Account of the stack this metric is attached to. Default: - Deployment account.
        :param stack_region: Region of the stack this metric is attached to. Default: - Deployment region.
        :param statistic: What function to use for aggregating. Use the ``aws_cloudwatch.Stats`` helper class to construct valid input strings. Can be one of the following: - "Minimum" | "min" - "Maximum" | "max" - "Average" | "avg" - "Sum" | "sum" - "SampleCount | "n" - "pNN.NN" - "tmNN.NN" | "tm(NN.NN%:NN.NN%)" - "iqm" - "wmNN.NN" | "wm(NN.NN%:NN.NN%)" - "tcNN.NN" | "tc(NN.NN%:NN.NN%)" - "tsNN.NN" | "ts(NN.NN%:NN.NN%)" Default: Average
        :param unit: Unit used to filter the metric stream. Only refer to datums emitted to the metric stream with the given unit and ignore all others. Only useful when datums are being emitted to the same metric stream under different units. The default is to use all matric datums in the stream, regardless of unit, which is recommended in nearly all cases. CloudWatch does not honor this property for graphs. Default: - All metric datums in the given metric stream
        :param visible: Whether this metric should be visible in dashboard graphs. Setting this to false is useful when you want to hide raw metrics that are used in math expressions, and show only the expression results. Default: true

        :default: - sum over 60 seconds

        :stability: experimental
        '''
        props = _aws_cdk_aws_cloudwatch_ceddda9d.MetricOptions(
            account=account,
            color=color,
            dimensions_map=dimensions_map,
            id=id,
            label=label,
            period=period,
            region=region,
            stack_account=stack_account,
            stack_region=stack_region,
            statistic=statistic,
            unit=unit,
            visible=visible,
        )

        return typing.cast("_aws_cdk_aws_cloudwatch_ceddda9d.Metric", jsii.invoke(self, "metricIngressBytes", [props]))

    @jsii.member(jsii_name="metricIngressRequestCount")
    def metric_ingress_request_count(
        self,
        *,
        account: typing.Optional[builtins.str] = None,
        color: typing.Optional[builtins.str] = None,
        dimensions_map: typing.Optional[typing.Mapping[builtins.str, builtins.str]] = None,
        id: typing.Optional[builtins.str] = None,
        label: typing.Optional[builtins.str] = None,
        period: typing.Optional["_aws_cdk_ceddda9d.Duration"] = None,
        region: typing.Optional[builtins.str] = None,
        stack_account: typing.Optional[builtins.str] = None,
        stack_region: typing.Optional[builtins.str] = None,
        statistic: typing.Optional[builtins.str] = None,
        unit: typing.Optional["_aws_cdk_aws_cloudwatch_ceddda9d.Unit"] = None,
        visible: typing.Optional[builtins.bool] = None,
    ) -> "_aws_cdk_aws_cloudwatch_ceddda9d.Metric":
        '''(experimental) Returns Metric for Ingress Request Count.

        :param account: Account which this metric comes from. Default: - Deployment account.
        :param color: The hex color code, prefixed with '#' (e.g. '#00ff00'), to use when this metric is rendered on a graph. The ``Color`` class has a set of standard colors that can be used here. Default: - Automatic color
        :param dimensions_map: Dimensions of the metric. Default: - No dimensions.
        :param id: Unique identifier for this metric when used in dashboard widgets. The id can be used as a variable to represent this metric in math expressions. Valid characters are letters, numbers, and underscore. The first character must be a lowercase letter. Default: - No ID
        :param label: Label for this metric when added to a Graph in a Dashboard. You can use `dynamic labels <https://docs.aws.amazon.com/AmazonCloudWatch/latest/monitoring/graph-dynamic-labels.html>`_ to show summary information about the entire displayed time series in the legend. For example, if you use:: [max: ${MAX}] MyMetric As the metric label, the maximum value in the visible range will be shown next to the time series name in the graph's legend. Default: - No label
        :param period: The period over which the specified statistic is applied. Default: Duration.minutes(5)
        :param region: Region which this metric comes from. Default: - Deployment region.
        :param stack_account: Account of the stack this metric is attached to. Default: - Deployment account.
        :param stack_region: Region of the stack this metric is attached to. Default: - Deployment region.
        :param statistic: What function to use for aggregating. Use the ``aws_cloudwatch.Stats`` helper class to construct valid input strings. Can be one of the following: - "Minimum" | "min" - "Maximum" | "max" - "Average" | "avg" - "Sum" | "sum" - "SampleCount | "n" - "pNN.NN" - "tmNN.NN" | "tm(NN.NN%:NN.NN%)" - "iqm" - "wmNN.NN" | "wm(NN.NN%:NN.NN%)" - "tcNN.NN" | "tc(NN.NN%:NN.NN%)" - "tsNN.NN" | "ts(NN.NN%:NN.NN%)" Default: Average
        :param unit: Unit used to filter the metric stream. Only refer to datums emitted to the metric stream with the given unit and ignore all others. Only useful when datums are being emitted to the same metric stream under different units. The default is to use all matric datums in the stream, regardless of unit, which is recommended in nearly all cases. CloudWatch does not honor this property for graphs. Default: - All metric datums in the given metric stream
        :param visible: Whether this metric should be visible in dashboard graphs. Setting this to false is useful when you want to hide raw metrics that are used in math expressions, and show only the expression results. Default: true

        :default: - sum over 60 seconds

        :stability: experimental
        '''
        props = _aws_cdk_aws_cloudwatch_ceddda9d.MetricOptions(
            account=account,
            color=color,
            dimensions_map=dimensions_map,
            id=id,
            label=label,
            period=period,
            region=region,
            stack_account=stack_account,
            stack_region=stack_region,
            statistic=statistic,
            unit=unit,
            visible=visible,
        )

        return typing.cast("_aws_cdk_aws_cloudwatch_ceddda9d.Metric", jsii.invoke(self, "metricIngressRequestCount", [props]))

    @jsii.member(jsii_name="metricIngressResponseTime")
    def metric_ingress_response_time(
        self,
        *,
        account: typing.Optional[builtins.str] = None,
        color: typing.Optional[builtins.str] = None,
        dimensions_map: typing.Optional[typing.Mapping[builtins.str, builtins.str]] = None,
        id: typing.Optional[builtins.str] = None,
        label: typing.Optional[builtins.str] = None,
        period: typing.Optional["_aws_cdk_ceddda9d.Duration"] = None,
        region: typing.Optional[builtins.str] = None,
        stack_account: typing.Optional[builtins.str] = None,
        stack_region: typing.Optional[builtins.str] = None,
        statistic: typing.Optional[builtins.str] = None,
        unit: typing.Optional["_aws_cdk_aws_cloudwatch_ceddda9d.Unit"] = None,
        visible: typing.Optional[builtins.bool] = None,
    ) -> "_aws_cdk_aws_cloudwatch_ceddda9d.Metric":
        '''(experimental) Returns Metric for Ingress response time.

        :param account: Account which this metric comes from. Default: - Deployment account.
        :param color: The hex color code, prefixed with '#' (e.g. '#00ff00'), to use when this metric is rendered on a graph. The ``Color`` class has a set of standard colors that can be used here. Default: - Automatic color
        :param dimensions_map: Dimensions of the metric. Default: - No dimensions.
        :param id: Unique identifier for this metric when used in dashboard widgets. The id can be used as a variable to represent this metric in math expressions. Valid characters are letters, numbers, and underscore. The first character must be a lowercase letter. Default: - No ID
        :param label: Label for this metric when added to a Graph in a Dashboard. You can use `dynamic labels <https://docs.aws.amazon.com/AmazonCloudWatch/latest/monitoring/graph-dynamic-labels.html>`_ to show summary information about the entire displayed time series in the legend. For example, if you use:: [max: ${MAX}] MyMetric As the metric label, the maximum value in the visible range will be shown next to the time series name in the graph's legend. Default: - No label
        :param period: The period over which the specified statistic is applied. Default: Duration.minutes(5)
        :param region: Region which this metric comes from. Default: - Deployment region.
        :param stack_account: Account of the stack this metric is attached to. Default: - Deployment account.
        :param stack_region: Region of the stack this metric is attached to. Default: - Deployment region.
        :param statistic: What function to use for aggregating. Use the ``aws_cloudwatch.Stats`` helper class to construct valid input strings. Can be one of the following: - "Minimum" | "min" - "Maximum" | "max" - "Average" | "avg" - "Sum" | "sum" - "SampleCount | "n" - "pNN.NN" - "tmNN.NN" | "tm(NN.NN%:NN.NN%)" - "iqm" - "wmNN.NN" | "wm(NN.NN%:NN.NN%)" - "tcNN.NN" | "tc(NN.NN%:NN.NN%)" - "tsNN.NN" | "ts(NN.NN%:NN.NN%)" Default: Average
        :param unit: Unit used to filter the metric stream. Only refer to datums emitted to the metric stream with the given unit and ignore all others. Only useful when datums are being emitted to the same metric stream under different units. The default is to use all matric datums in the stream, regardless of unit, which is recommended in nearly all cases. CloudWatch does not honor this property for graphs. Default: - All metric datums in the given metric stream
        :param visible: Whether this metric should be visible in dashboard graphs. Setting this to false is useful when you want to hide raw metrics that are used in math expressions, and show only the expression results. Default: true

        :default: - average over 60 seconds

        :stability: experimental
        '''
        props = _aws_cdk_aws_cloudwatch_ceddda9d.MetricOptions(
            account=account,
            color=color,
            dimensions_map=dimensions_map,
            id=id,
            label=label,
            period=period,
            region=region,
            stack_account=stack_account,
            stack_region=stack_region,
            statistic=statistic,
            unit=unit,
            visible=visible,
        )

        return typing.cast("_aws_cdk_aws_cloudwatch_ceddda9d.Metric", jsii.invoke(self, "metricIngressResponseTime", [props]))

    @jsii.member(jsii_name="segmentValidation")
    def _segment_validation(
        self,
        segment_container_type: "ContainerType",
        *,
        container_type: "ContainerType",
        encryption: typing.Optional["EncryptionConfiguration"] = None,
        include_iframe_only_streams: typing.Optional[builtins.bool] = None,
        scte_filter: typing.Optional[typing.Sequence["ScteMessageType"]] = None,
        scte_in_segments: typing.Optional["ScteInSegments"] = None,
        segment_duration: typing.Optional["_aws_cdk_ceddda9d.Duration"] = None,
        segment_name: typing.Optional[builtins.str] = None,
        ts_include_dvb_subtitles: typing.Optional[builtins.bool] = None,
        ts_use_audio_rendition_group: typing.Optional[builtins.bool] = None,
    ) -> typing.Optional["_aws_cdk_aws_mediapackagev2_ceddda9d.CfnOriginEndpoint.SegmentProperty"]:
        '''(experimental) Validate and modify Segment configuration for endpoint.

        :param segment_container_type: -
        :param container_type: (experimental) The container type for this segment (TS or CMAF).
        :param encryption: (experimental) Encryption configuration for the segment. Default: - No encryption
        :param include_iframe_only_streams: (experimental) Whether the segment includes I-frame-only streams. Default: undefined - Not specified.
        :param scte_filter: (experimental) The SCTE-35 configuration associated with the segment. The SCTE-35 message types that you want to be treated as ad markers in the output. Default: - No SCTE filtering
        :param scte_in_segments: (experimental) Controls whether SCTE-35 messages are included in segment files. Default: - SCTE-35 messages are not included in segments
        :param segment_duration: (experimental) The duration of the segments. Default: 6
        :param segment_name: (experimental) The name of the segment associated with the origin endpoint. Default: segment
        :param ts_include_dvb_subtitles: (experimental) Whether the segment includes DVB subtitles. Default: false
        :param ts_use_audio_rendition_group: (experimental) Whether the segment is an audio rendition group. Default: false

        :stability: experimental
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__061e94b85e68e127a16f7f5fc125f59b3967d5466271bacd9ace89e57a782f65)
            check_type(argname="argument segment_container_type", value=segment_container_type, expected_type=type_hints["segment_container_type"])
        segment = SegmentConfiguration(
            container_type=container_type,
            encryption=encryption,
            include_iframe_only_streams=include_iframe_only_streams,
            scte_filter=scte_filter,
            scte_in_segments=scte_in_segments,
            segment_duration=segment_duration,
            segment_name=segment_name,
            ts_include_dvb_subtitles=ts_include_dvb_subtitles,
            ts_use_audio_rendition_group=ts_use_audio_rendition_group,
        )

        return typing.cast(typing.Optional["_aws_cdk_aws_mediapackagev2_ceddda9d.CfnOriginEndpoint.SegmentProperty"], jsii.invoke(self, "segmentValidation", [segment_container_type, segment]))

    @jsii.python.classproperty
    @jsii.member(jsii_name="PROPERTY_INJECTION_ID")
    def PROPERTY_INJECTION_ID(cls) -> builtins.str:
        '''(experimental) Uniquely identifies this class.

        :stability: experimental
        '''
        return typing.cast(builtins.str, jsii.sget(cls, "PROPERTY_INJECTION_ID"))

    @builtins.property
    @jsii.member(jsii_name="channelGroupName")
    def channel_group_name(self) -> builtins.str:
        '''(experimental) The name of the channel group associated with the origin endpoint configuration.

        :stability: experimental
        '''
        return typing.cast(builtins.str, jsii.get(self, "channelGroupName"))

    @builtins.property
    @jsii.member(jsii_name="channelName")
    def channel_name(self) -> builtins.str:
        '''(experimental) The channel name associated with the origin endpoint.

        :stability: experimental
        '''
        return typing.cast(builtins.str, jsii.get(self, "channelName"))

    @builtins.property
    @jsii.member(jsii_name="originEndpointArn")
    def origin_endpoint_arn(self) -> builtins.str:
        '''(experimental) The Amazon Resource Name (ARN) of the origin endpoint.

        :stability: experimental
        '''
        return typing.cast(builtins.str, jsii.get(self, "originEndpointArn"))

    @builtins.property
    @jsii.member(jsii_name="originEndpointName")
    def origin_endpoint_name(self) -> builtins.str:
        '''(experimental) The name of the origin endpoint associated with the origin endpoint configuration.

        :stability: experimental
        '''
        return typing.cast(builtins.str, jsii.get(self, "originEndpointName"))

    @builtins.property
    @jsii.member(jsii_name="originEndpointRef")
    def origin_endpoint_ref(
        self,
    ) -> "_aws_cdk_interfaces_aws_mediapackagev2_ceddda9d.OriginEndpointReference":
        '''(experimental) A reference to this Origin Endpoint resource.

        Required by the auto-generated IOriginEndpointRef interface.

        :stability: experimental
        '''
        return typing.cast("_aws_cdk_interfaces_aws_mediapackagev2_ceddda9d.OriginEndpointReference", jsii.get(self, "originEndpointRef"))

    @builtins.property
    @jsii.member(jsii_name="createdAt")
    def created_at(self) -> typing.Optional[builtins.str]:
        '''(experimental) The timestamp of the creation of the origin endpoint.

        :stability: experimental
        '''
        return typing.cast(typing.Optional[builtins.str], jsii.get(self, "createdAt"))

    @builtins.property
    @jsii.member(jsii_name="dashManifestUrls")
    def dash_manifest_urls(self) -> typing.Optional[typing.List[builtins.str]]:
        '''(experimental) Array containing DASH Manifests created by the OriginEndpoint.

        :stability: experimental
        '''
        return typing.cast(typing.Optional[typing.List[builtins.str]], jsii.get(self, "dashManifestUrls"))

    @builtins.property
    @jsii.member(jsii_name="hlsManifestUrls")
    def hls_manifest_urls(self) -> typing.Optional[typing.List[builtins.str]]:
        '''(experimental) Array containing HLS Manifests created by the OriginEndpoint.

        :stability: experimental
        '''
        return typing.cast(typing.Optional[typing.List[builtins.str]], jsii.get(self, "hlsManifestUrls"))

    @builtins.property
    @jsii.member(jsii_name="lowLatencyHlsManifestUrls")
    def low_latency_hls_manifest_urls(
        self,
    ) -> typing.Optional[typing.List[builtins.str]]:
        '''(experimental) Array containing Low Latency HLS Manifests created by the OriginEndpoint.

        :stability: experimental
        '''
        return typing.cast(typing.Optional[typing.List[builtins.str]], jsii.get(self, "lowLatencyHlsManifestUrls"))

    @builtins.property
    @jsii.member(jsii_name="modifiedAt")
    def modified_at(self) -> typing.Optional[builtins.str]:
        '''(experimental) The timestamp of the modification of the origin endpoint.

        :stability: experimental
        '''
        return typing.cast(typing.Optional[builtins.str], jsii.get(self, "modifiedAt"))

    @builtins.property
    @jsii.member(jsii_name="mssManifestUrls")
    def mss_manifest_urls(self) -> typing.Optional[typing.List[builtins.str]]:
        '''(experimental) Array containing MSS Manifests created by the OriginEndpoint.

        :stability: experimental
        '''
        return typing.cast(typing.Optional[typing.List[builtins.str]], jsii.get(self, "mssManifestUrls"))

    @builtins.property
    @jsii.member(jsii_name="autoCreatePolicy")
    def _auto_create_policy(self) -> builtins.bool:
        '''(experimental) Indicates if an origin endpoint resource policy should automatically be created upon the first call to ``addToResourcePolicy``.

        :stability: experimental
        '''
        return typing.cast(builtins.bool, jsii.get(self, "autoCreatePolicy"))

    @_auto_create_policy.setter
    def _auto_create_policy(self, value: builtins.bool) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__4cbbc133811be2981f90a7c2fdf05e55dd7290c7aea33f5d2493e5abe037fa7b)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "autoCreatePolicy", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="dashManifests")
    def _dash_manifests(
        self,
    ) -> typing.List["_aws_cdk_aws_mediapackagev2_ceddda9d.CfnOriginEndpoint.DashManifestConfigurationProperty"]:
        '''
        :stability: experimental
        '''
        return typing.cast(typing.List["_aws_cdk_aws_mediapackagev2_ceddda9d.CfnOriginEndpoint.DashManifestConfigurationProperty"], jsii.get(self, "dashManifests"))

    @_dash_manifests.setter
    def _dash_manifests(
        self,
        value: typing.List["_aws_cdk_aws_mediapackagev2_ceddda9d.CfnOriginEndpoint.DashManifestConfigurationProperty"],
    ) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__f2e4cb9776dab0ec1380129079f1889d4f79817b010054c0ee1f996af3b26e2a)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "dashManifests", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="hlsManifests")
    def _hls_manifests(
        self,
    ) -> typing.List["_aws_cdk_aws_mediapackagev2_ceddda9d.CfnOriginEndpoint.HlsManifestConfigurationProperty"]:
        '''
        :stability: experimental
        '''
        return typing.cast(typing.List["_aws_cdk_aws_mediapackagev2_ceddda9d.CfnOriginEndpoint.HlsManifestConfigurationProperty"], jsii.get(self, "hlsManifests"))

    @_hls_manifests.setter
    def _hls_manifests(
        self,
        value: typing.List["_aws_cdk_aws_mediapackagev2_ceddda9d.CfnOriginEndpoint.HlsManifestConfigurationProperty"],
    ) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__d6dcc55b52e525151aee13cd8aebddad06a6324db85110100aa6f23f2cfbad30)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "hlsManifests", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="llHlsManifests")
    def _ll_hls_manifests(
        self,
    ) -> typing.List["_aws_cdk_aws_mediapackagev2_ceddda9d.CfnOriginEndpoint.LowLatencyHlsManifestConfigurationProperty"]:
        '''
        :stability: experimental
        '''
        return typing.cast(typing.List["_aws_cdk_aws_mediapackagev2_ceddda9d.CfnOriginEndpoint.LowLatencyHlsManifestConfigurationProperty"], jsii.get(self, "llHlsManifests"))

    @_ll_hls_manifests.setter
    def _ll_hls_manifests(
        self,
        value: typing.List["_aws_cdk_aws_mediapackagev2_ceddda9d.CfnOriginEndpoint.LowLatencyHlsManifestConfigurationProperty"],
    ) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__e2f4a8794fb6b9cc51f35ea907ad16eefe139461b148cd4643770b911b8aecb8)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "llHlsManifests", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="mssManifests")
    def _mss_manifests(
        self,
    ) -> typing.List["_aws_cdk_aws_mediapackagev2_ceddda9d.CfnOriginEndpoint.MssManifestConfigurationProperty"]:
        '''
        :stability: experimental
        '''
        return typing.cast(typing.List["_aws_cdk_aws_mediapackagev2_ceddda9d.CfnOriginEndpoint.MssManifestConfigurationProperty"], jsii.get(self, "mssManifests"))

    @_mss_manifests.setter
    def _mss_manifests(
        self,
        value: typing.List["_aws_cdk_aws_mediapackagev2_ceddda9d.CfnOriginEndpoint.MssManifestConfigurationProperty"],
    ) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__9f6bac8fbfa86e7f0ef9e6266027805f94f19475c8dae8bb042141b5ce3253bc)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "mssManifests", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="policy")
    def policy(self) -> typing.Optional["OriginEndpointPolicy"]:
        '''(experimental) The resource policy associated with this origin endpoint.

        If ``autoCreatePolicy`` is true, an ``OriginEndpointPolicy`` will be created upon the
        first call to addToResourcePolicy(s).

        :stability: experimental
        '''
        return typing.cast(typing.Optional["OriginEndpointPolicy"], jsii.get(self, "policy"))

    @policy.setter
    def policy(self, value: typing.Optional["OriginEndpointPolicy"]) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__e4e4649175a02c973b89236092da8be59780eaf123a53929ed54cddff93c7e08)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "policy", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="segment")
    def _segment(self) -> typing.Optional["SegmentConfiguration"]:
        '''
        :stability: experimental
        '''
        return typing.cast(typing.Optional["SegmentConfiguration"], jsii.get(self, "segment"))

    @_segment.setter
    def _segment(self, value: typing.Optional["SegmentConfiguration"]) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__238aaf06141faf383d1401eedbdde221eaef2c6a5e89cf06c3400160d18889fe)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "segment", value) # pyright: ignore[reportArgumentType]


@jsii.data_type(
    jsii_type="@aws-cdk/aws-mediapackagev2-alpha.OriginEndpointAttributes",
    jsii_struct_bases=[],
    name_mapping={
        "channel_group_name": "channelGroupName",
        "channel_name": "channelName",
        "origin_endpoint_name": "originEndpointName",
    },
)
class OriginEndpointAttributes:
    def __init__(
        self,
        *,
        channel_group_name: builtins.str,
        channel_name: builtins.str,
        origin_endpoint_name: builtins.str,
    ) -> None:
        '''(experimental) Represents an Origin Endpoint defined outside of this stack.

        :param channel_group_name: (experimental) The name that describes the channel group. The name is the primary identifier for the channel group.
        :param channel_name: (experimental) The name that describes the channel. The name is the primary identifier for the channel.
        :param origin_endpoint_name: (experimental) The name that describes the origin endpoint.

        :stability: experimental
        :exampleMetadata: infused

        Example::

            # stack: Stack
            
            origin_endpoint = OriginEndpoint.from_origin_endpoint_attributes(stack, "ImportedOriginEndpoint",
                channel_group_name="MyChannelGroup",
                channel_name="MyChannel",
                origin_endpoint_name="MyExampleOriginEndpoint"
            )
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__8f2307f56de43bc78c8a719a388a9301c9c01e44923052dd18882bb2621384c0)
            check_type(argname="argument channel_group_name", value=channel_group_name, expected_type=type_hints["channel_group_name"])
            check_type(argname="argument channel_name", value=channel_name, expected_type=type_hints["channel_name"])
            check_type(argname="argument origin_endpoint_name", value=origin_endpoint_name, expected_type=type_hints["origin_endpoint_name"])
        self._values: typing.Dict[builtins.str, typing.Any] = {
            "channel_group_name": channel_group_name,
            "channel_name": channel_name,
            "origin_endpoint_name": origin_endpoint_name,
        }

    @builtins.property
    def channel_group_name(self) -> builtins.str:
        '''(experimental) The name that describes the channel group.

        The name is the primary identifier for the channel group.

        :stability: experimental
        :attribute: true
        '''
        result = self._values.get("channel_group_name")
        assert result is not None, "Required property 'channel_group_name' is missing"
        return typing.cast(builtins.str, result)

    @builtins.property
    def channel_name(self) -> builtins.str:
        '''(experimental) The name that describes the channel.

        The name is the primary identifier for the channel.

        :stability: experimental
        :attribute: true
        '''
        result = self._values.get("channel_name")
        assert result is not None, "Required property 'channel_name' is missing"
        return typing.cast(builtins.str, result)

    @builtins.property
    def origin_endpoint_name(self) -> builtins.str:
        '''(experimental) The name that describes the origin endpoint.

        :stability: experimental
        :attribute: true
        '''
        result = self._values.get("origin_endpoint_name")
        assert result is not None, "Required property 'origin_endpoint_name' is missing"
        return typing.cast(builtins.str, result)

    def __eq__(self, rhs: typing.Any) -> builtins.bool:
        return isinstance(rhs, self.__class__) and rhs._values == self._values

    def __ne__(self, rhs: typing.Any) -> builtins.bool:
        return not (rhs == self)

    def __repr__(self) -> str:
        return "OriginEndpointAttributes(%s)" % ", ".join(
            k + "=" + repr(v) for k, v in self._values.items()
        )


@jsii.data_type(
    jsii_type="@aws-cdk/aws-mediapackagev2-alpha.OriginEndpointOptions",
    jsii_struct_bases=[],
    name_mapping={
        "manifests": "manifests",
        "segment": "segment",
        "cdn_auth": "cdnAuth",
        "description": "description",
        "force_endpoint_configuration_conditions": "forceEndpointConfigurationConditions",
        "origin_endpoint_name": "originEndpointName",
        "removal_policy": "removalPolicy",
        "startover_window": "startoverWindow",
        "tags": "tags",
    },
)
class OriginEndpointOptions:
    def __init__(
        self,
        *,
        manifests: typing.Sequence["Manifest"],
        segment: typing.Union["SegmentConfiguration", typing.Dict[builtins.str, typing.Any]],
        cdn_auth: typing.Optional[typing.Union["CdnAuthConfiguration", typing.Dict[builtins.str, typing.Any]]] = None,
        description: typing.Optional[builtins.str] = None,
        force_endpoint_configuration_conditions: typing.Optional[typing.Sequence["EndpointErrorConfiguration"]] = None,
        origin_endpoint_name: typing.Optional[builtins.str] = None,
        removal_policy: typing.Optional["_aws_cdk_ceddda9d.RemovalPolicy"] = None,
        startover_window: typing.Optional["_aws_cdk_ceddda9d.Duration"] = None,
        tags: typing.Optional[typing.Mapping[builtins.str, builtins.str]] = None,
    ) -> None:
        '''(experimental) Configuration parameters for an AWS Elemental MediaPackage V2 Origin Endpoint.

        :param manifests: (experimental) Manifests configuration for HLS, Low Latency HLS and DASH.
        :param segment: (experimental) The segment associated with the origin endpoint. Inside the segment configuration you can define options such as encryption, SPEKE parameters and other general segment configurations. Use Segment.ts() or Segment.cmaf() to create the configuration.
        :param cdn_auth: (experimental) Provide access to MediaPackage V2 Origin Endpoint via secret header. Default: undefined - Not configured on endpoint
        :param description: (experimental) The description associated with the origin endpoint. Default: undefined - No description is added to Origin Endpoint
        :param force_endpoint_configuration_conditions: (experimental) The failover settings for the endpoint. Default: undefined - No force endpoint configuration is configured
        :param origin_endpoint_name: (experimental) The name of the origin endpoint associated with the origin endpoint configuration. Default: autogenerated
        :param removal_policy: (experimental) Policy to apply when the origin endpoint is removed from the stack. Even though MediaPackage ChannelGroups, Channels and OriginEndpoints are technically stateful, their contents are transient and it is common to add and remove these while rearchitecting your application. The default is therefore ``DESTROY``. Change it to ``RETAIN`` if the content (in a lookback window) are so valuable that accidentally losing it would be unacceptable. Default: RemovalPolicy.DESTROY
        :param startover_window: (experimental) The size of the window to specify a window of the live stream that's available for on-demand viewing. Viewers can start-over or catch-up on content that falls within the window. Default: 900
        :param tags: (experimental) The tags associated with the origin endpoint. Default: - No tagging

        :stability: experimental
        :exampleMetadata: infused

        Example::

            # stack: Stack
            
            
            # Create a channel group
            group = ChannelGroup(stack, "MyChannelGroup",
                channel_group_name="my-channel-group"
            )
            
            # Add a channel using the factory method
            channel = group.add_channel("MyChannel",
                channel_name="my-channel",
                input=InputConfiguration.cmaf()
            )
            
            # Add an origin endpoint using the factory method
            endpoint = channel.add_origin_endpoint("MyEndpoint",
                origin_endpoint_name="my-endpoint",
                segment=Segment.cmaf(),
                manifests=[Manifest.hls(manifest_name="index")]
            )
        '''
        if isinstance(segment, dict):
            segment = SegmentConfiguration(**segment)
        if isinstance(cdn_auth, dict):
            cdn_auth = CdnAuthConfiguration(**cdn_auth)
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__d605ec53aa81b54b1dea33423c87e458f6d97e120ac2889498e4712de5c080c4)
            check_type(argname="argument manifests", value=manifests, expected_type=type_hints["manifests"])
            check_type(argname="argument segment", value=segment, expected_type=type_hints["segment"])
            check_type(argname="argument cdn_auth", value=cdn_auth, expected_type=type_hints["cdn_auth"])
            check_type(argname="argument description", value=description, expected_type=type_hints["description"])
            check_type(argname="argument force_endpoint_configuration_conditions", value=force_endpoint_configuration_conditions, expected_type=type_hints["force_endpoint_configuration_conditions"])
            check_type(argname="argument origin_endpoint_name", value=origin_endpoint_name, expected_type=type_hints["origin_endpoint_name"])
            check_type(argname="argument removal_policy", value=removal_policy, expected_type=type_hints["removal_policy"])
            check_type(argname="argument startover_window", value=startover_window, expected_type=type_hints["startover_window"])
            check_type(argname="argument tags", value=tags, expected_type=type_hints["tags"])
        self._values: typing.Dict[builtins.str, typing.Any] = {
            "manifests": manifests,
            "segment": segment,
        }
        if cdn_auth is not None:
            self._values["cdn_auth"] = cdn_auth
        if description is not None:
            self._values["description"] = description
        if force_endpoint_configuration_conditions is not None:
            self._values["force_endpoint_configuration_conditions"] = force_endpoint_configuration_conditions
        if origin_endpoint_name is not None:
            self._values["origin_endpoint_name"] = origin_endpoint_name
        if removal_policy is not None:
            self._values["removal_policy"] = removal_policy
        if startover_window is not None:
            self._values["startover_window"] = startover_window
        if tags is not None:
            self._values["tags"] = tags

    @builtins.property
    def manifests(self) -> typing.List["Manifest"]:
        '''(experimental) Manifests configuration for HLS, Low Latency HLS and DASH.

        :stability: experimental
        '''
        result = self._values.get("manifests")
        assert result is not None, "Required property 'manifests' is missing"
        return typing.cast(typing.List["Manifest"], result)

    @builtins.property
    def segment(self) -> "SegmentConfiguration":
        '''(experimental) The segment associated with the origin endpoint.

        Inside the segment configuration you can define options such as encryption, SPEKE parameters and other
        general segment configurations.

        Use Segment.ts() or Segment.cmaf() to create the configuration.

        :stability: experimental
        '''
        result = self._values.get("segment")
        assert result is not None, "Required property 'segment' is missing"
        return typing.cast("SegmentConfiguration", result)

    @builtins.property
    def cdn_auth(self) -> typing.Optional["CdnAuthConfiguration"]:
        '''(experimental) Provide access to MediaPackage V2 Origin Endpoint via secret header.

        :default: undefined - Not configured on endpoint

        :stability: experimental
        '''
        result = self._values.get("cdn_auth")
        return typing.cast(typing.Optional["CdnAuthConfiguration"], result)

    @builtins.property
    def description(self) -> typing.Optional[builtins.str]:
        '''(experimental) The description associated with the origin endpoint.

        :default: undefined - No description is added to Origin Endpoint

        :stability: experimental
        '''
        result = self._values.get("description")
        return typing.cast(typing.Optional[builtins.str], result)

    @builtins.property
    def force_endpoint_configuration_conditions(
        self,
    ) -> typing.Optional[typing.List["EndpointErrorConfiguration"]]:
        '''(experimental) The failover settings for the endpoint.

        :default: undefined - No force endpoint configuration is configured

        :stability: experimental
        '''
        result = self._values.get("force_endpoint_configuration_conditions")
        return typing.cast(typing.Optional[typing.List["EndpointErrorConfiguration"]], result)

    @builtins.property
    def origin_endpoint_name(self) -> typing.Optional[builtins.str]:
        '''(experimental) The name of the origin endpoint associated with the origin endpoint configuration.

        :default: autogenerated

        :stability: experimental
        '''
        result = self._values.get("origin_endpoint_name")
        return typing.cast(typing.Optional[builtins.str], result)

    @builtins.property
    def removal_policy(self) -> typing.Optional["_aws_cdk_ceddda9d.RemovalPolicy"]:
        '''(experimental) Policy to apply when the origin endpoint is removed from the stack.

        Even though MediaPackage ChannelGroups, Channels and OriginEndpoints are technically stateful,
        their contents are transient and it is common to add and remove these while rearchitecting your application.
        The default is therefore ``DESTROY``. Change it to ``RETAIN`` if the content (in a lookback window) are so
        valuable that accidentally losing it would be unacceptable.

        :default: RemovalPolicy.DESTROY

        :stability: experimental
        '''
        result = self._values.get("removal_policy")
        return typing.cast(typing.Optional["_aws_cdk_ceddda9d.RemovalPolicy"], result)

    @builtins.property
    def startover_window(self) -> typing.Optional["_aws_cdk_ceddda9d.Duration"]:
        '''(experimental) The size of the window to specify a window of the live stream that's available for on-demand viewing.

        Viewers can start-over or catch-up on content that falls within the window.

        :default: 900

        :stability: experimental
        '''
        result = self._values.get("startover_window")
        return typing.cast(typing.Optional["_aws_cdk_ceddda9d.Duration"], result)

    @builtins.property
    def tags(self) -> typing.Optional[typing.Mapping[builtins.str, builtins.str]]:
        '''(experimental) The tags associated with the origin endpoint.

        :default: - No tagging

        :stability: experimental
        '''
        result = self._values.get("tags")
        return typing.cast(typing.Optional[typing.Mapping[builtins.str, builtins.str]], result)

    def __eq__(self, rhs: typing.Any) -> builtins.bool:
        return isinstance(rhs, self.__class__) and rhs._values == self._values

    def __ne__(self, rhs: typing.Any) -> builtins.bool:
        return not (rhs == self)

    def __repr__(self) -> str:
        return "OriginEndpointOptions(%s)" % ", ".join(
            k + "=" + repr(v) for k, v in self._values.items()
        )


class OriginEndpointPolicy(
    _aws_cdk_ceddda9d.Resource,
    metaclass=jsii.JSIIMeta,
    jsii_type="@aws-cdk/aws-mediapackagev2-alpha.OriginEndpointPolicy",
):
    '''(experimental) The origin endpoint policy for an AWS Elemental MediaPackage V2 Origin Endpoint.

    Policies define the operations that are allowed on this resource.

    You almost never need to define this construct directly.

    All AWS resources that support resource policies have a method called
    ``addToResourcePolicy()``, which will automatically create a new resource
    policy if one doesn't exist yet, otherwise it will add to the existing
    policy.

    The origin endpoint policy method is implemented differently than ``addToResourcePolicy()``
    as ``OriginEndpointPolicy`` creates a new policy without knowing one earlier existed.
    This will cause a resource conflict if both are invoked (or even multiple origin endpoint
    policies are defined), so care is to be taken to ensure only 1 policy
    is created per origin endpoint.

    Hence it's strongly recommended to use ``addToResourcePolicy()``.

    :stability: experimental
    :exampleMetadata: fixture=_generated

    Example::

        # The code below shows an example of how to instantiate this type.
        # The values are placeholders you should change.
        import aws_cdk.aws_mediapackagev2_alpha as mediapackagev2_alpha
        from aws_cdk import aws_iam as iam
        from aws_cdk import aws_secretsmanager as secretsmanager
        
        # origin_endpoint: mediapackagev2_alpha.OriginEndpoint
        # policy_document: iam.PolicyDocument
        # role: iam.Role
        # secret: secretsmanager.Secret
        
        origin_endpoint_policy = mediapackagev2_alpha.OriginEndpointPolicy(self, "MyOriginEndpointPolicy",
            origin_endpoint=origin_endpoint,
        
            # the properties below are optional
            cdn_auth=mediapackagev2_alpha.CdnAuthConfiguration(
                secrets=[secret],
        
                # the properties below are optional
                role=role
            ),
            policy_document=policy_document
        )
    '''

    def __init__(
        self,
        scope: "_constructs_77d1e7e8.Construct",
        id: builtins.str,
        *,
        origin_endpoint: "IOriginEndpoint",
        cdn_auth: typing.Optional[typing.Union["CdnAuthConfiguration", typing.Dict[builtins.str, typing.Any]]] = None,
        policy_document: typing.Optional["_aws_cdk_aws_iam_ceddda9d.PolicyDocument"] = None,
    ) -> None:
        '''
        :param scope: -
        :param id: -
        :param origin_endpoint: (experimental) ``OriginEndpoint`` to apply the Origin Endpoint Policy to.
        :param cdn_auth: (experimental) Optional CDN Authorization configuration. Default: - No header based CDN authorization
        :param policy_document: (experimental) Initial policy document to apply. Default: - empty policy document

        :stability: experimental
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__0ce86cd12d9e5aace3901a14e591645d36c1341e652de8208a5a5dc173ce574c)
            check_type(argname="argument scope", value=scope, expected_type=type_hints["scope"])
            check_type(argname="argument id", value=id, expected_type=type_hints["id"])
        props = OriginEndpointPolicyProps(
            origin_endpoint=origin_endpoint,
            cdn_auth=cdn_auth,
            policy_document=policy_document,
        )

        jsii.create(self.__class__, self, [scope, id, props])

    @jsii.python.classproperty
    @jsii.member(jsii_name="PROPERTY_INJECTION_ID")
    def PROPERTY_INJECTION_ID(cls) -> builtins.str:
        '''(experimental) Uniquely identifies this class.

        :stability: experimental
        '''
        return typing.cast(builtins.str, jsii.sget(cls, "PROPERTY_INJECTION_ID"))

    @builtins.property
    @jsii.member(jsii_name="document")
    def document(self) -> "_aws_cdk_aws_iam_ceddda9d.PolicyDocument":
        '''(experimental) A policy document containing permissions to add to the specified Origin Endpoint.

        :stability: experimental
        '''
        return typing.cast("_aws_cdk_aws_iam_ceddda9d.PolicyDocument", jsii.get(self, "document"))


@jsii.data_type(
    jsii_type="@aws-cdk/aws-mediapackagev2-alpha.OriginEndpointPolicyProps",
    jsii_struct_bases=[],
    name_mapping={
        "origin_endpoint": "originEndpoint",
        "cdn_auth": "cdnAuth",
        "policy_document": "policyDocument",
    },
)
class OriginEndpointPolicyProps:
    def __init__(
        self,
        *,
        origin_endpoint: "IOriginEndpoint",
        cdn_auth: typing.Optional[typing.Union["CdnAuthConfiguration", typing.Dict[builtins.str, typing.Any]]] = None,
        policy_document: typing.Optional["_aws_cdk_aws_iam_ceddda9d.PolicyDocument"] = None,
    ) -> None:
        '''(experimental) Properties for Origin Endpoint policy.

        :param origin_endpoint: (experimental) ``OriginEndpoint`` to apply the Origin Endpoint Policy to.
        :param cdn_auth: (experimental) Optional CDN Authorization configuration. Default: - No header based CDN authorization
        :param policy_document: (experimental) Initial policy document to apply. Default: - empty policy document

        :stability: experimental
        :exampleMetadata: fixture=_generated

        Example::

            # The code below shows an example of how to instantiate this type.
            # The values are placeholders you should change.
            import aws_cdk.aws_mediapackagev2_alpha as mediapackagev2_alpha
            from aws_cdk import aws_iam as iam
            from aws_cdk import aws_secretsmanager as secretsmanager
            
            # origin_endpoint: mediapackagev2_alpha.OriginEndpoint
            # policy_document: iam.PolicyDocument
            # role: iam.Role
            # secret: secretsmanager.Secret
            
            origin_endpoint_policy_props = mediapackagev2_alpha.OriginEndpointPolicyProps(
                origin_endpoint=origin_endpoint,
            
                # the properties below are optional
                cdn_auth=mediapackagev2_alpha.CdnAuthConfiguration(
                    secrets=[secret],
            
                    # the properties below are optional
                    role=role
                ),
                policy_document=policy_document
            )
        '''
        if isinstance(cdn_auth, dict):
            cdn_auth = CdnAuthConfiguration(**cdn_auth)
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__c51380fe991c69a64bec8dd6ad6c056712f2c67066c31c9ad74a15a4f9eee4e2)
            check_type(argname="argument origin_endpoint", value=origin_endpoint, expected_type=type_hints["origin_endpoint"])
            check_type(argname="argument cdn_auth", value=cdn_auth, expected_type=type_hints["cdn_auth"])
            check_type(argname="argument policy_document", value=policy_document, expected_type=type_hints["policy_document"])
        self._values: typing.Dict[builtins.str, typing.Any] = {
            "origin_endpoint": origin_endpoint,
        }
        if cdn_auth is not None:
            self._values["cdn_auth"] = cdn_auth
        if policy_document is not None:
            self._values["policy_document"] = policy_document

    @builtins.property
    def origin_endpoint(self) -> "IOriginEndpoint":
        '''(experimental) ``OriginEndpoint`` to apply the Origin Endpoint Policy to.

        :stability: experimental
        '''
        result = self._values.get("origin_endpoint")
        assert result is not None, "Required property 'origin_endpoint' is missing"
        return typing.cast("IOriginEndpoint", result)

    @builtins.property
    def cdn_auth(self) -> typing.Optional["CdnAuthConfiguration"]:
        '''(experimental) Optional CDN Authorization configuration.

        :default: - No header based CDN authorization

        :stability: experimental
        '''
        result = self._values.get("cdn_auth")
        return typing.cast(typing.Optional["CdnAuthConfiguration"], result)

    @builtins.property
    def policy_document(
        self,
    ) -> typing.Optional["_aws_cdk_aws_iam_ceddda9d.PolicyDocument"]:
        '''(experimental) Initial policy document to apply.

        :default: - empty policy document

        :stability: experimental
        '''
        result = self._values.get("policy_document")
        return typing.cast(typing.Optional["_aws_cdk_aws_iam_ceddda9d.PolicyDocument"], result)

    def __eq__(self, rhs: typing.Any) -> builtins.bool:
        return isinstance(rhs, self.__class__) and rhs._values == self._values

    def __ne__(self, rhs: typing.Any) -> builtins.bool:
        return not (rhs == self)

    def __repr__(self) -> str:
        return "OriginEndpointPolicyProps(%s)" % ", ".join(
            k + "=" + repr(v) for k, v in self._values.items()
        )


@jsii.data_type(
    jsii_type="@aws-cdk/aws-mediapackagev2-alpha.OriginEndpointProps",
    jsii_struct_bases=[OriginEndpointOptions],
    name_mapping={
        "manifests": "manifests",
        "segment": "segment",
        "cdn_auth": "cdnAuth",
        "description": "description",
        "force_endpoint_configuration_conditions": "forceEndpointConfigurationConditions",
        "origin_endpoint_name": "originEndpointName",
        "removal_policy": "removalPolicy",
        "startover_window": "startoverWindow",
        "tags": "tags",
        "channel": "channel",
    },
)
class OriginEndpointProps(OriginEndpointOptions):
    def __init__(
        self,
        *,
        manifests: typing.Sequence["Manifest"],
        segment: typing.Union["SegmentConfiguration", typing.Dict[builtins.str, typing.Any]],
        cdn_auth: typing.Optional[typing.Union["CdnAuthConfiguration", typing.Dict[builtins.str, typing.Any]]] = None,
        description: typing.Optional[builtins.str] = None,
        force_endpoint_configuration_conditions: typing.Optional[typing.Sequence["EndpointErrorConfiguration"]] = None,
        origin_endpoint_name: typing.Optional[builtins.str] = None,
        removal_policy: typing.Optional["_aws_cdk_ceddda9d.RemovalPolicy"] = None,
        startover_window: typing.Optional["_aws_cdk_ceddda9d.Duration"] = None,
        tags: typing.Optional[typing.Mapping[builtins.str, builtins.str]] = None,
        channel: "IChannel",
    ) -> None:
        '''(experimental) Properties to set on an Origin Endpoint.

        :param manifests: (experimental) Manifests configuration for HLS, Low Latency HLS and DASH.
        :param segment: (experimental) The segment associated with the origin endpoint. Inside the segment configuration you can define options such as encryption, SPEKE parameters and other general segment configurations. Use Segment.ts() or Segment.cmaf() to create the configuration.
        :param cdn_auth: (experimental) Provide access to MediaPackage V2 Origin Endpoint via secret header. Default: undefined - Not configured on endpoint
        :param description: (experimental) The description associated with the origin endpoint. Default: undefined - No description is added to Origin Endpoint
        :param force_endpoint_configuration_conditions: (experimental) The failover settings for the endpoint. Default: undefined - No force endpoint configuration is configured
        :param origin_endpoint_name: (experimental) The name of the origin endpoint associated with the origin endpoint configuration. Default: autogenerated
        :param removal_policy: (experimental) Policy to apply when the origin endpoint is removed from the stack. Even though MediaPackage ChannelGroups, Channels and OriginEndpoints are technically stateful, their contents are transient and it is common to add and remove these while rearchitecting your application. The default is therefore ``DESTROY``. Change it to ``RETAIN`` if the content (in a lookback window) are so valuable that accidentally losing it would be unacceptable. Default: RemovalPolicy.DESTROY
        :param startover_window: (experimental) The size of the window to specify a window of the live stream that's available for on-demand viewing. Viewers can start-over or catch-up on content that falls within the window. Default: 900
        :param tags: (experimental) The tags associated with the origin endpoint. Default: - No tagging
        :param channel: (experimental) The channel associated with the origin endpoint.

        :stability: experimental
        :exampleMetadata: infused

        Example::

            # channel: Channel
            # speke_role: iam.IRole
            
            
            OriginEndpoint(self, "TsEndpoint",
                channel=channel,
                segment=Segment.ts(
                    encryption=TsEncryption.speke(
                        method=TsEncryptionMethod.SAMPLE_AES,
                        resource_id="my-content-id",
                        url="https://example.com/speke",
                        role=speke_role
                    )
                ),
                manifests=[Manifest.hls(manifest_name="index")]
            )
        '''
        if isinstance(segment, dict):
            segment = SegmentConfiguration(**segment)
        if isinstance(cdn_auth, dict):
            cdn_auth = CdnAuthConfiguration(**cdn_auth)
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__d2915b00ce306ab1a736d81ac5321db4415588817aa6eeb282de84e4b12bbef2)
            check_type(argname="argument manifests", value=manifests, expected_type=type_hints["manifests"])
            check_type(argname="argument segment", value=segment, expected_type=type_hints["segment"])
            check_type(argname="argument cdn_auth", value=cdn_auth, expected_type=type_hints["cdn_auth"])
            check_type(argname="argument description", value=description, expected_type=type_hints["description"])
            check_type(argname="argument force_endpoint_configuration_conditions", value=force_endpoint_configuration_conditions, expected_type=type_hints["force_endpoint_configuration_conditions"])
            check_type(argname="argument origin_endpoint_name", value=origin_endpoint_name, expected_type=type_hints["origin_endpoint_name"])
            check_type(argname="argument removal_policy", value=removal_policy, expected_type=type_hints["removal_policy"])
            check_type(argname="argument startover_window", value=startover_window, expected_type=type_hints["startover_window"])
            check_type(argname="argument tags", value=tags, expected_type=type_hints["tags"])
            check_type(argname="argument channel", value=channel, expected_type=type_hints["channel"])
        self._values: typing.Dict[builtins.str, typing.Any] = {
            "manifests": manifests,
            "segment": segment,
            "channel": channel,
        }
        if cdn_auth is not None:
            self._values["cdn_auth"] = cdn_auth
        if description is not None:
            self._values["description"] = description
        if force_endpoint_configuration_conditions is not None:
            self._values["force_endpoint_configuration_conditions"] = force_endpoint_configuration_conditions
        if origin_endpoint_name is not None:
            self._values["origin_endpoint_name"] = origin_endpoint_name
        if removal_policy is not None:
            self._values["removal_policy"] = removal_policy
        if startover_window is not None:
            self._values["startover_window"] = startover_window
        if tags is not None:
            self._values["tags"] = tags

    @builtins.property
    def manifests(self) -> typing.List["Manifest"]:
        '''(experimental) Manifests configuration for HLS, Low Latency HLS and DASH.

        :stability: experimental
        '''
        result = self._values.get("manifests")
        assert result is not None, "Required property 'manifests' is missing"
        return typing.cast(typing.List["Manifest"], result)

    @builtins.property
    def segment(self) -> "SegmentConfiguration":
        '''(experimental) The segment associated with the origin endpoint.

        Inside the segment configuration you can define options such as encryption, SPEKE parameters and other
        general segment configurations.

        Use Segment.ts() or Segment.cmaf() to create the configuration.

        :stability: experimental
        '''
        result = self._values.get("segment")
        assert result is not None, "Required property 'segment' is missing"
        return typing.cast("SegmentConfiguration", result)

    @builtins.property
    def cdn_auth(self) -> typing.Optional["CdnAuthConfiguration"]:
        '''(experimental) Provide access to MediaPackage V2 Origin Endpoint via secret header.

        :default: undefined - Not configured on endpoint

        :stability: experimental
        '''
        result = self._values.get("cdn_auth")
        return typing.cast(typing.Optional["CdnAuthConfiguration"], result)

    @builtins.property
    def description(self) -> typing.Optional[builtins.str]:
        '''(experimental) The description associated with the origin endpoint.

        :default: undefined - No description is added to Origin Endpoint

        :stability: experimental
        '''
        result = self._values.get("description")
        return typing.cast(typing.Optional[builtins.str], result)

    @builtins.property
    def force_endpoint_configuration_conditions(
        self,
    ) -> typing.Optional[typing.List["EndpointErrorConfiguration"]]:
        '''(experimental) The failover settings for the endpoint.

        :default: undefined - No force endpoint configuration is configured

        :stability: experimental
        '''
        result = self._values.get("force_endpoint_configuration_conditions")
        return typing.cast(typing.Optional[typing.List["EndpointErrorConfiguration"]], result)

    @builtins.property
    def origin_endpoint_name(self) -> typing.Optional[builtins.str]:
        '''(experimental) The name of the origin endpoint associated with the origin endpoint configuration.

        :default: autogenerated

        :stability: experimental
        '''
        result = self._values.get("origin_endpoint_name")
        return typing.cast(typing.Optional[builtins.str], result)

    @builtins.property
    def removal_policy(self) -> typing.Optional["_aws_cdk_ceddda9d.RemovalPolicy"]:
        '''(experimental) Policy to apply when the origin endpoint is removed from the stack.

        Even though MediaPackage ChannelGroups, Channels and OriginEndpoints are technically stateful,
        their contents are transient and it is common to add and remove these while rearchitecting your application.
        The default is therefore ``DESTROY``. Change it to ``RETAIN`` if the content (in a lookback window) are so
        valuable that accidentally losing it would be unacceptable.

        :default: RemovalPolicy.DESTROY

        :stability: experimental
        '''
        result = self._values.get("removal_policy")
        return typing.cast(typing.Optional["_aws_cdk_ceddda9d.RemovalPolicy"], result)

    @builtins.property
    def startover_window(self) -> typing.Optional["_aws_cdk_ceddda9d.Duration"]:
        '''(experimental) The size of the window to specify a window of the live stream that's available for on-demand viewing.

        Viewers can start-over or catch-up on content that falls within the window.

        :default: 900

        :stability: experimental
        '''
        result = self._values.get("startover_window")
        return typing.cast(typing.Optional["_aws_cdk_ceddda9d.Duration"], result)

    @builtins.property
    def tags(self) -> typing.Optional[typing.Mapping[builtins.str, builtins.str]]:
        '''(experimental) The tags associated with the origin endpoint.

        :default: - No tagging

        :stability: experimental
        '''
        result = self._values.get("tags")
        return typing.cast(typing.Optional[typing.Mapping[builtins.str, builtins.str]], result)

    @builtins.property
    def channel(self) -> "IChannel":
        '''(experimental) The channel associated with the origin endpoint.

        :stability: experimental
        '''
        result = self._values.get("channel")
        assert result is not None, "Required property 'channel' is missing"
        return typing.cast("IChannel", result)

    def __eq__(self, rhs: typing.Any) -> builtins.bool:
        return isinstance(rhs, self.__class__) and rhs._values == self._values

    def __ne__(self, rhs: typing.Any) -> builtins.bool:
        return not (rhs == self)

    def __repr__(self) -> str:
        return "OriginEndpointProps(%s)" % ", ".join(
            k + "=" + repr(v) for k, v in self._values.items()
        )


@jsii.enum(jsii_type="@aws-cdk/aws-mediapackagev2-alpha.PresetSpeke20Audio")
class PresetSpeke20Audio(enum.Enum):
    '''(experimental) A collection of audio encryption presets.

    :stability: experimental
    :exampleMetadata: infused

    Example::

        # channel: Channel
        # speke_role: iam.IRole
        
        
        OriginEndpoint(self, "Endpoint",
            channel=channel,
            segment=Segment.cmaf(
                encryption=CmafEncryption.speke(
                    method=CmafEncryptionMethod.CBCS,
                    drm_systems=[CmafDrmSystem.FAIRPLAY, CmafDrmSystem.WIDEVINE],
                    resource_id="my-content-id",
                    url="https://example.com/speke",
                    role=speke_role,
                    key_rotation_interval=Duration.seconds(300),
                    audio_preset=PresetSpeke20Audio.PRESET_AUDIO_2,
                    video_preset=PresetSpeke20Video.PRESET_VIDEO_2
                )
            ),
            manifests=[Manifest.hls(manifest_name="index")]
        )
    '''

    PRESET_AUDIO_1 = "PRESET_AUDIO_1"
    '''(experimental) Use one content key to encrypt all of the audio tracks in your stream.

    :stability: experimental
    '''
    PRESET_AUDIO_2 = "PRESET_AUDIO_2"
    '''(experimental) Use one content key to encrypt all of the stereo audio tracks and one content key to encrypt all of the multichannel audio tracks.

    :stability: experimental
    '''
    PRESET_AUDIO_3 = "PRESET_AUDIO_3"
    '''(experimental) Use one content key to encrypt all of the stereo audio tracks, one content key to encrypt all of the multichannel audio tracks with 3 to 6 channels, and one content key to encrypt all of the multichannel audio tracks with more than 6 channels.

    :stability: experimental
    '''
    SHARED = "SHARED"
    '''(experimental) Use the same content key for all of the audio and video tracks in your stream.

    :stability: experimental
    '''
    UNENCRYPTED = "UNENCRYPTED"
    '''(experimental) Don't encrypt any of the audio tracks in your stream.

    :stability: experimental
    '''


@jsii.enum(jsii_type="@aws-cdk/aws-mediapackagev2-alpha.PresetSpeke20Video")
class PresetSpeke20Video(enum.Enum):
    '''(experimental) The SPEKE Version 2.0 preset video associated with the encryption contract configuration of the origin endpoint.

    A collection of video encryption presets.

    :stability: experimental
    :exampleMetadata: infused

    Example::

        # channel: Channel
        # speke_role: iam.IRole
        
        
        OriginEndpoint(self, "Endpoint",
            channel=channel,
            segment=Segment.cmaf(
                encryption=CmafEncryption.speke(
                    method=CmafEncryptionMethod.CBCS,
                    drm_systems=[CmafDrmSystem.FAIRPLAY, CmafDrmSystem.WIDEVINE],
                    resource_id="my-content-id",
                    url="https://example.com/speke",
                    role=speke_role,
                    key_rotation_interval=Duration.seconds(300),
                    audio_preset=PresetSpeke20Audio.PRESET_AUDIO_2,
                    video_preset=PresetSpeke20Video.PRESET_VIDEO_2
                )
            ),
            manifests=[Manifest.hls(manifest_name="index")]
        )
    '''

    PRESET_VIDEO_1 = "PRESET_VIDEO_1"
    '''(experimental) Use one content key to encrypt all of the video tracks in your stream.

    :stability: experimental
    '''
    PRESET_VIDEO_2 = "PRESET_VIDEO_2"
    '''(experimental) Use one content key to encrypt all of the SD video tracks and one content key for all HD and higher resolutions video tracks.

    :stability: experimental
    '''
    PRESET_VIDEO_3 = "PRESET_VIDEO_3"
    '''(experimental) Use one content key to encrypt all of the SD video tracks, one content key for HD video tracks and one content key for all UHD video tracks.

    :stability: experimental
    '''
    PRESET_VIDEO_4 = "PRESET_VIDEO_4"
    '''(experimental) Use one content key to encrypt all of the SD video tracks, one content key for HD video tracks, one content key for all UHD1 video tracks and one content key for all UHD2 video tracks.

    :stability: experimental
    '''
    PRESET_VIDEO_5 = "PRESET_VIDEO_5"
    '''(experimental) Use one content key to encrypt all of the SD video tracks, one content key for HD1 video tracks, one content key for HD2 video tracks, one content key for all UHD1 video tracks and one content key for all UHD2 video tracks.

    :stability: experimental
    '''
    PRESET_VIDEO_6 = "PRESET_VIDEO_6"
    '''(experimental) Use one content key to encrypt all of the SD video tracks, one content key for HD1 video tracks, one content key for HD2 video tracks and one content key for all UHD video tracks.

    :stability: experimental
    '''
    PRESET_VIDEO_7 = "PRESET_VIDEO_7"
    '''(experimental) Use one content key to encrypt all of the SD+HD1 video tracks, one content key for HD2 video tracks and one content key for all UHD video tracks.

    :stability: experimental
    '''
    PRESET_VIDEO_8 = "PRESET_VIDEO_8"
    '''(experimental) Use one content key to encrypt all of the SD+HD1 video tracks, one content key for HD2 video tracks, one content key for all UHD1 video tracks and one content key for all UHD2 video tracks.

    :stability: experimental
    '''
    SHARED = "SHARED"
    '''(experimental) Use the same content key for all of the video and audio tracks in your stream.

    :stability: experimental
    '''
    UNENCRYPTED = "UNENCRYPTED"
    '''(experimental) Don't encrypt any of the video tracks in your stream.

    :stability: experimental
    '''


@jsii.enum(jsii_type="@aws-cdk/aws-mediapackagev2-alpha.ScteInSegments")
class ScteInSegments(enum.Enum):
    '''(experimental) Controls whether SCTE-35 messages are included in segment files.

    :stability: experimental
    '''

    NONE = "NONE"
    '''(experimental) SCTE-35 messages are not included in segments.

    :stability: experimental
    '''
    ALL = "ALL"
    '''(experimental) SCTE-35 messages are embedded in segment data.

    For DASH manifests, when set to ALL, an InbandEventStream tag signals
    that SCTE messages are present in segments.

    :stability: experimental
    '''


@jsii.enum(jsii_type="@aws-cdk/aws-mediapackagev2-alpha.ScteMessageType")
class ScteMessageType(enum.Enum):
    '''(experimental) SCTE-35 message type options available.

    :stability: experimental
    '''

    SPLICE_INSERT = "SPLICE_INSERT"
    '''(experimental) Option for SPLICE_INSERT.

    :stability: experimental
    '''
    BREAK = "BREAK"
    '''(experimental) Option for BREAK.

    :stability: experimental
    '''
    PROVIDER_ADVERTISEMENT = "PROVIDER_ADVERTISEMENT"
    '''(experimental) Option for PROVIDER_ADVERTISEMENT.

    :stability: experimental
    '''
    DISTRIBUTOR_ADVERTISEMENT = "DISTRIBUTOR_ADVERTISEMENT"
    '''(experimental) Option for DISTRIBUTOR_ADVERTISEMENT.

    :stability: experimental
    '''
    PROVIDER_PLACEMENT_OPPORTUNITY = "PROVIDER_PLACEMENT_OPPORTUNITY"
    '''(experimental) Option for PROVIDER_PLACEMENT_OPPORTUNITY.

    :stability: experimental
    '''
    DISTRIBUTOR_PLACEMENT_OPPORTUNITY = "DISTRIBUTOR_PLACEMENT_OPPORTUNITY"
    '''(experimental) Option for DISTRIBUTOR_PLACEMENT_OPPORTUNITY.

    :stability: experimental
    '''
    PROVIDER_OVERLAY_PLACEMENT_OPPORTUNITY = "PROVIDER_OVERLAY_PLACEMENT_OPPORTUNITY"
    '''(experimental) Option for PROVIDER_OVERLAY_PLACEMENT_OPPORTUNITY.

    :stability: experimental
    '''
    DISTRIBUTOR_OVERLAY_PLACEMENT_OPPORTUNITY = "DISTRIBUTOR_OVERLAY_PLACEMENT_OPPORTUNITY"
    '''(experimental) Option for DISTRIBUTOR_OVERLAY_PLACEMENT_OPPORTUNITY.

    :stability: experimental
    '''
    PROGRAM = "PROGRAM"
    '''(experimental) Option for PROGRAM.

    :stability: experimental
    '''


class Segment(
    metaclass=jsii.JSIIMeta,
    jsii_type="@aws-cdk/aws-mediapackagev2-alpha.Segment",
):
    '''(experimental) Helper class for creating segment configurations.

    :stability: experimental
    :exampleMetadata: fixture=_generated

    Example::

        # The code below shows an example of how to instantiate this type.
        # The values are placeholders you should change.
        import aws_cdk.aws_mediapackagev2_alpha as mediapackagev2_alpha
        
        segment = mediapackagev2_alpha.Segment()
    '''

    def __init__(self) -> None:
        '''
        :stability: experimental
        '''
        jsii.create(self.__class__, self, [])

    @jsii.member(jsii_name="cmaf")
    @builtins.classmethod
    def cmaf(
        cls,
        *,
        encryption: typing.Optional["CmafEncryption"] = None,
        scte_filter: typing.Optional[typing.Sequence["ScteMessageType"]] = None,
        scte_in_segments: typing.Optional["ScteInSegments"] = None,
        duration: typing.Optional["_aws_cdk_ceddda9d.Duration"] = None,
        include_iframe_only_streams: typing.Optional[builtins.bool] = None,
        name: typing.Optional[builtins.str] = None,
    ) -> "SegmentConfiguration":
        '''(experimental) Create a CMAF segment configuration.

        Use this for endpoints with ContainerType.CMAF.

        :param encryption: (experimental) Encryption configuration for the CMAF segment. Use ``CmafEncryption.speke()`` to create the configuration. Default: - No encryption
        :param scte_filter: (experimental) SCTE-35 message types to treat as ad markers. Default: - no filtering
        :param scte_in_segments: (experimental) Controls whether SCTE-35 messages are included in segment files. Default: - SCTE-35 messages are not included in segments
        :param duration: (experimental) Duration of each segment. Default: Duration.seconds(6)
        :param include_iframe_only_streams: (experimental) Whether to include I-frame-only streams. Default: false
        :param name: (experimental) Name of the segment. Default: 'segment'

        :stability: experimental
        '''
        props = CmafSegmentProps(
            encryption=encryption,
            scte_filter=scte_filter,
            scte_in_segments=scte_in_segments,
            duration=duration,
            include_iframe_only_streams=include_iframe_only_streams,
            name=name,
        )

        return typing.cast("SegmentConfiguration", jsii.sinvoke(cls, "cmaf", [props]))

    @jsii.member(jsii_name="ism")
    @builtins.classmethod
    def ism(
        cls,
        *,
        encryption: typing.Optional["IsmEncryption"] = None,
        duration: typing.Optional["_aws_cdk_ceddda9d.Duration"] = None,
        include_iframe_only_streams: typing.Optional[builtins.bool] = None,
        name: typing.Optional[builtins.str] = None,
    ) -> "SegmentConfiguration":
        '''(experimental) Create an ISM (Microsoft Smooth Streaming) segment configuration.

        Use this for endpoints with ContainerType.ISM.

        :param encryption: (experimental) Encryption configuration for the ISM segment. Use ``IsmEncryption.speke()`` to create the configuration. Default: - No encryption
        :param duration: (experimental) Duration of each segment. Default: Duration.seconds(6)
        :param include_iframe_only_streams: (experimental) Whether to include I-frame-only streams. Default: false
        :param name: (experimental) Name of the segment. Default: 'segment'

        :stability: experimental
        '''
        props = IsmSegmentProps(
            encryption=encryption,
            duration=duration,
            include_iframe_only_streams=include_iframe_only_streams,
            name=name,
        )

        return typing.cast("SegmentConfiguration", jsii.sinvoke(cls, "ism", [props]))

    @jsii.member(jsii_name="ts")
    @builtins.classmethod
    def ts(
        cls,
        *,
        encryption: typing.Optional["TsEncryption"] = None,
        include_dvb_subtitles: typing.Optional[builtins.bool] = None,
        scte_filter: typing.Optional[typing.Sequence["ScteMessageType"]] = None,
        scte_in_segments: typing.Optional["ScteInSegments"] = None,
        use_audio_rendition_group: typing.Optional[builtins.bool] = None,
        duration: typing.Optional["_aws_cdk_ceddda9d.Duration"] = None,
        include_iframe_only_streams: typing.Optional[builtins.bool] = None,
        name: typing.Optional[builtins.str] = None,
    ) -> "SegmentConfiguration":
        '''(experimental) Create a TS (Transport Stream) segment configuration.

        Use this for endpoints with ContainerType.TS.

        :param encryption: (experimental) Encryption configuration for the TS segment. Use ``TsEncryption.speke()`` to create the configuration. Default: - No encryption
        :param include_dvb_subtitles: (experimental) Whether to include DVB subtitles. Default: false
        :param scte_filter: (experimental) SCTE-35 message types to treat as ad markers. Default: - no filtering
        :param scte_in_segments: (experimental) Controls whether SCTE-35 messages are included in segment files. Default: - SCTE-35 messages are not included in segments
        :param use_audio_rendition_group: (experimental) Whether to use audio rendition groups. Default: false
        :param duration: (experimental) Duration of each segment. Default: Duration.seconds(6)
        :param include_iframe_only_streams: (experimental) Whether to include I-frame-only streams. Default: false
        :param name: (experimental) Name of the segment. Default: 'segment'

        :stability: experimental
        '''
        props = TsSegmentProps(
            encryption=encryption,
            include_dvb_subtitles=include_dvb_subtitles,
            scte_filter=scte_filter,
            scte_in_segments=scte_in_segments,
            use_audio_rendition_group=use_audio_rendition_group,
            duration=duration,
            include_iframe_only_streams=include_iframe_only_streams,
            name=name,
        )

        return typing.cast("SegmentConfiguration", jsii.sinvoke(cls, "ts", [props]))


@jsii.data_type(
    jsii_type="@aws-cdk/aws-mediapackagev2-alpha.SegmentConfiguration",
    jsii_struct_bases=[],
    name_mapping={
        "container_type": "containerType",
        "encryption": "encryption",
        "include_iframe_only_streams": "includeIframeOnlyStreams",
        "scte_filter": "scteFilter",
        "scte_in_segments": "scteInSegments",
        "segment_duration": "segmentDuration",
        "segment_name": "segmentName",
        "ts_include_dvb_subtitles": "tsIncludeDvbSubtitles",
        "ts_use_audio_rendition_group": "tsUseAudioRenditionGroup",
    },
)
class SegmentConfiguration:
    def __init__(
        self,
        *,
        container_type: "ContainerType",
        encryption: typing.Optional["EncryptionConfiguration"] = None,
        include_iframe_only_streams: typing.Optional[builtins.bool] = None,
        scte_filter: typing.Optional[typing.Sequence["ScteMessageType"]] = None,
        scte_in_segments: typing.Optional["ScteInSegments"] = None,
        segment_duration: typing.Optional["_aws_cdk_ceddda9d.Duration"] = None,
        segment_name: typing.Optional[builtins.str] = None,
        ts_include_dvb_subtitles: typing.Optional[builtins.bool] = None,
        ts_use_audio_rendition_group: typing.Optional[builtins.bool] = None,
    ) -> None:
        '''(experimental) The segment configuration, including the segment name, duration, and other configuration values.

        :param container_type: (experimental) The container type for this segment (TS or CMAF).
        :param encryption: (experimental) Encryption configuration for the segment. Default: - No encryption
        :param include_iframe_only_streams: (experimental) Whether the segment includes I-frame-only streams. Default: undefined - Not specified.
        :param scte_filter: (experimental) The SCTE-35 configuration associated with the segment. The SCTE-35 message types that you want to be treated as ad markers in the output. Default: - No SCTE filtering
        :param scte_in_segments: (experimental) Controls whether SCTE-35 messages are included in segment files. Default: - SCTE-35 messages are not included in segments
        :param segment_duration: (experimental) The duration of the segments. Default: 6
        :param segment_name: (experimental) The name of the segment associated with the origin endpoint. Default: segment
        :param ts_include_dvb_subtitles: (experimental) Whether the segment includes DVB subtitles. Default: false
        :param ts_use_audio_rendition_group: (experimental) Whether the segment is an audio rendition group. Default: false

        :stability: experimental
        :exampleMetadata: infused

        Example::

            # channel: Channel
            # speke_role: iam.IRole
            
            
            OriginEndpoint(self, "TsEndpoint",
                channel=channel,
                segment=Segment.ts(
                    encryption=TsEncryption.speke(
                        method=TsEncryptionMethod.SAMPLE_AES,
                        resource_id="my-content-id",
                        url="https://example.com/speke",
                        role=speke_role
                    )
                ),
                manifests=[Manifest.hls(manifest_name="index")]
            )
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__7eaed8a99aa8e7c44936e12e26744614fc5c273b127d32ad8dee9525fd05bbc4)
            check_type(argname="argument container_type", value=container_type, expected_type=type_hints["container_type"])
            check_type(argname="argument encryption", value=encryption, expected_type=type_hints["encryption"])
            check_type(argname="argument include_iframe_only_streams", value=include_iframe_only_streams, expected_type=type_hints["include_iframe_only_streams"])
            check_type(argname="argument scte_filter", value=scte_filter, expected_type=type_hints["scte_filter"])
            check_type(argname="argument scte_in_segments", value=scte_in_segments, expected_type=type_hints["scte_in_segments"])
            check_type(argname="argument segment_duration", value=segment_duration, expected_type=type_hints["segment_duration"])
            check_type(argname="argument segment_name", value=segment_name, expected_type=type_hints["segment_name"])
            check_type(argname="argument ts_include_dvb_subtitles", value=ts_include_dvb_subtitles, expected_type=type_hints["ts_include_dvb_subtitles"])
            check_type(argname="argument ts_use_audio_rendition_group", value=ts_use_audio_rendition_group, expected_type=type_hints["ts_use_audio_rendition_group"])
        self._values: typing.Dict[builtins.str, typing.Any] = {
            "container_type": container_type,
        }
        if encryption is not None:
            self._values["encryption"] = encryption
        if include_iframe_only_streams is not None:
            self._values["include_iframe_only_streams"] = include_iframe_only_streams
        if scte_filter is not None:
            self._values["scte_filter"] = scte_filter
        if scte_in_segments is not None:
            self._values["scte_in_segments"] = scte_in_segments
        if segment_duration is not None:
            self._values["segment_duration"] = segment_duration
        if segment_name is not None:
            self._values["segment_name"] = segment_name
        if ts_include_dvb_subtitles is not None:
            self._values["ts_include_dvb_subtitles"] = ts_include_dvb_subtitles
        if ts_use_audio_rendition_group is not None:
            self._values["ts_use_audio_rendition_group"] = ts_use_audio_rendition_group

    @builtins.property
    def container_type(self) -> "ContainerType":
        '''(experimental) The container type for this segment (TS or CMAF).

        :stability: experimental
        '''
        result = self._values.get("container_type")
        assert result is not None, "Required property 'container_type' is missing"
        return typing.cast("ContainerType", result)

    @builtins.property
    def encryption(self) -> typing.Optional["EncryptionConfiguration"]:
        '''(experimental) Encryption configuration for the segment.

        :default: - No encryption

        :stability: experimental
        '''
        result = self._values.get("encryption")
        return typing.cast(typing.Optional["EncryptionConfiguration"], result)

    @builtins.property
    def include_iframe_only_streams(self) -> typing.Optional[builtins.bool]:
        '''(experimental) Whether the segment includes I-frame-only streams.

        :default: undefined - Not specified.

        :stability: experimental
        '''
        result = self._values.get("include_iframe_only_streams")
        return typing.cast(typing.Optional[builtins.bool], result)

    @builtins.property
    def scte_filter(self) -> typing.Optional[typing.List["ScteMessageType"]]:
        '''(experimental) The SCTE-35 configuration associated with the segment.

        The SCTE-35 message types that you want to be treated as ad markers in the output.

        :default: - No SCTE filtering

        :stability: experimental
        '''
        result = self._values.get("scte_filter")
        return typing.cast(typing.Optional[typing.List["ScteMessageType"]], result)

    @builtins.property
    def scte_in_segments(self) -> typing.Optional["ScteInSegments"]:
        '''(experimental) Controls whether SCTE-35 messages are included in segment files.

        :default: - SCTE-35 messages are not included in segments

        :stability: experimental
        '''
        result = self._values.get("scte_in_segments")
        return typing.cast(typing.Optional["ScteInSegments"], result)

    @builtins.property
    def segment_duration(self) -> typing.Optional["_aws_cdk_ceddda9d.Duration"]:
        '''(experimental) The duration of the segments.

        :default: 6

        :stability: experimental
        '''
        result = self._values.get("segment_duration")
        return typing.cast(typing.Optional["_aws_cdk_ceddda9d.Duration"], result)

    @builtins.property
    def segment_name(self) -> typing.Optional[builtins.str]:
        '''(experimental) The name of the segment associated with the origin endpoint.

        :default: segment

        :stability: experimental
        '''
        result = self._values.get("segment_name")
        return typing.cast(typing.Optional[builtins.str], result)

    @builtins.property
    def ts_include_dvb_subtitles(self) -> typing.Optional[builtins.bool]:
        '''(experimental) Whether the segment includes DVB subtitles.

        :default: false

        :stability: experimental
        '''
        result = self._values.get("ts_include_dvb_subtitles")
        return typing.cast(typing.Optional[builtins.bool], result)

    @builtins.property
    def ts_use_audio_rendition_group(self) -> typing.Optional[builtins.bool]:
        '''(experimental) Whether the segment is an audio rendition group.

        :default: false

        :stability: experimental
        '''
        result = self._values.get("ts_use_audio_rendition_group")
        return typing.cast(typing.Optional[builtins.bool], result)

    def __eq__(self, rhs: typing.Any) -> builtins.bool:
        return isinstance(rhs, self.__class__) and rhs._values == self._values

    def __ne__(self, rhs: typing.Any) -> builtins.bool:
        return not (rhs == self)

    def __repr__(self) -> str:
        return "SegmentConfiguration(%s)" % ", ".join(
            k + "=" + repr(v) for k, v in self._values.items()
        )


@jsii.data_type(
    jsii_type="@aws-cdk/aws-mediapackagev2-alpha.SegmentPropsBase",
    jsii_struct_bases=[],
    name_mapping={
        "duration": "duration",
        "include_iframe_only_streams": "includeIframeOnlyStreams",
        "name": "name",
    },
)
class SegmentPropsBase:
    def __init__(
        self,
        *,
        duration: typing.Optional["_aws_cdk_ceddda9d.Duration"] = None,
        include_iframe_only_streams: typing.Optional[builtins.bool] = None,
        name: typing.Optional[builtins.str] = None,
    ) -> None:
        '''(experimental) Base properties common to all segment configurations.

        :param duration: (experimental) Duration of each segment. Default: Duration.seconds(6)
        :param include_iframe_only_streams: (experimental) Whether to include I-frame-only streams. Default: false
        :param name: (experimental) Name of the segment. Default: 'segment'

        :stability: experimental
        :exampleMetadata: fixture=_generated

        Example::

            # The code below shows an example of how to instantiate this type.
            # The values are placeholders you should change.
            import aws_cdk.aws_mediapackagev2_alpha as mediapackagev2_alpha
            import aws_cdk as cdk
            
            segment_props_base = mediapackagev2_alpha.SegmentPropsBase(
                duration=cdk.Duration.minutes(30),
                include_iframe_only_streams=False,
                name="name"
            )
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__b315f2b8942cdb1d172d97e7c05c86c67d4253ca3382b5dbe1013e00886bb3c8)
            check_type(argname="argument duration", value=duration, expected_type=type_hints["duration"])
            check_type(argname="argument include_iframe_only_streams", value=include_iframe_only_streams, expected_type=type_hints["include_iframe_only_streams"])
            check_type(argname="argument name", value=name, expected_type=type_hints["name"])
        self._values: typing.Dict[builtins.str, typing.Any] = {}
        if duration is not None:
            self._values["duration"] = duration
        if include_iframe_only_streams is not None:
            self._values["include_iframe_only_streams"] = include_iframe_only_streams
        if name is not None:
            self._values["name"] = name

    @builtins.property
    def duration(self) -> typing.Optional["_aws_cdk_ceddda9d.Duration"]:
        '''(experimental) Duration of each segment.

        :default: Duration.seconds(6)

        :stability: experimental
        '''
        result = self._values.get("duration")
        return typing.cast(typing.Optional["_aws_cdk_ceddda9d.Duration"], result)

    @builtins.property
    def include_iframe_only_streams(self) -> typing.Optional[builtins.bool]:
        '''(experimental) Whether to include I-frame-only streams.

        :default: false

        :stability: experimental
        '''
        result = self._values.get("include_iframe_only_streams")
        return typing.cast(typing.Optional[builtins.bool], result)

    @builtins.property
    def name(self) -> typing.Optional[builtins.str]:
        '''(experimental) Name of the segment.

        :default: 'segment'

        :stability: experimental
        '''
        result = self._values.get("name")
        return typing.cast(typing.Optional[builtins.str], result)

    def __eq__(self, rhs: typing.Any) -> builtins.bool:
        return isinstance(rhs, self.__class__) and rhs._values == self._values

    def __ne__(self, rhs: typing.Any) -> builtins.bool:
        return not (rhs == self)

    def __repr__(self) -> str:
        return "SegmentPropsBase(%s)" % ", ".join(
            k + "=" + repr(v) for k, v in self._values.items()
        )


@jsii.enum(jsii_type="@aws-cdk/aws-mediapackagev2-alpha.SegmentTemplateFormat")
class SegmentTemplateFormat(enum.Enum):
    '''(experimental) The type of variable that MediaPackage uses in the media attribute of the SegmentTemplate tag.

    :stability: experimental
    '''

    NUMBER_WITH_TIMELINE = "NUMBER_WITH_TIMELINE"
    '''(experimental) Option for number with timeline.

    :stability: experimental
    '''


class StartTag(
    metaclass=jsii.JSIIMeta,
    jsii_type="@aws-cdk/aws-mediapackagev2-alpha.StartTag",
):
    '''(experimental) Helper class for creating EXT-X-START tags in HLS playlists.

    The EXT-X-START tag indicates a preferred point at which to start playing a playlist.
    Configuration for EXT-X-START tag in HLS playlists.

    Use the ``StartTag`` helper class to create instances with validation.

    :stability: experimental
    :exampleMetadata: infused

    Example::

        # channel: Channel
        
        
        OriginEndpoint(self, "Endpoint",
            channel=channel,
            segment=Segment.cmaf(),
            manifests=[
                Manifest.hls(
                    manifest_name="index",
                    start_tag=StartTag.of(10)
                )
            ]
        )
    '''

    def __init__(self) -> None:
        '''
        :stability: experimental
        '''
        jsii.create(self.__class__, self, [])

    @jsii.member(jsii_name="of")
    @builtins.classmethod
    def of(
        cls,
        time_offset: jsii.Number,
        *,
        precise: typing.Optional[builtins.bool] = None,
    ) -> "StartTag":
        '''(experimental) Create a start tag with a time offset.

        :param time_offset: The time offset in seconds. Can be positive (forward from start) or negative (back from live edge). - If positive: must be less than (manifest duration - 3 × segment duration) - If negative: absolute value must be greater than (3 × segment duration) and less than manifest duration
        :param precise: (experimental) Specify the value for PRECISE within your EXT-X-START tag. Leave blank, or choose false, to use the default value NO. Choose true to use the value YES. Default: false

        :stability: experimental
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__671cbba9971ee8689fdab0a27400f47b37f58fb32bacd2f590ca3b3becbdcdfd)
            check_type(argname="argument time_offset", value=time_offset, expected_type=type_hints["time_offset"])
        options = StartTagOptions(precise=precise)

        return typing.cast("StartTag", jsii.sinvoke(cls, "of", [time_offset, options]))

    @jsii.member(jsii_name="withPrecise")
    @builtins.classmethod
    def with_precise(cls, time_offset: jsii.Number) -> "StartTag":
        '''(experimental) Create a start tag with precise positioning enabled (PRECISE=YES).

        :param time_offset: The time offset in seconds (positive or negative).

        :stability: experimental
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__771c9d5f2b7c378d5e03fb8bd0293797340fd071345fc538136379399ab40dbe)
            check_type(argname="argument time_offset", value=time_offset, expected_type=type_hints["time_offset"])
        return typing.cast("StartTag", jsii.sinvoke(cls, "withPrecise", [time_offset]))

    @builtins.property
    @jsii.member(jsii_name="timeOffset")
    def time_offset(self) -> jsii.Number:
        '''(experimental) Specify the value for TIME-OFFSET within your EXT-X-START tag.

        Enter a signed floating point value which, if positive, must be less than the configured
        manifest duration minus three times the configured segment target duration. If negative,
        the absolute value must be larger than three times the configured segment target duration,
        and the absolute value must be smaller than the configured manifest duration.

        :stability: experimental
        '''
        return typing.cast(jsii.Number, jsii.get(self, "timeOffset"))

    @builtins.property
    @jsii.member(jsii_name="precise")
    def precise(self) -> typing.Optional[builtins.bool]:
        '''(experimental) Specify the value for PRECISE within your EXT-X-START tag.

        Leave blank, or choose false, to use the default value NO. Choose true to use the value YES.

        :stability: experimental
        '''
        return typing.cast(typing.Optional[builtins.bool], jsii.get(self, "precise"))


@jsii.data_type(
    jsii_type="@aws-cdk/aws-mediapackagev2-alpha.StartTagOptions",
    jsii_struct_bases=[],
    name_mapping={"precise": "precise"},
)
class StartTagOptions:
    def __init__(self, *, precise: typing.Optional[builtins.bool] = None) -> None:
        '''(experimental) Options for configuring a StartTag.

        :param precise: (experimental) Specify the value for PRECISE within your EXT-X-START tag. Leave blank, or choose false, to use the default value NO. Choose true to use the value YES. Default: false

        :stability: experimental
        :exampleMetadata: fixture=_generated

        Example::

            # The code below shows an example of how to instantiate this type.
            # The values are placeholders you should change.
            import aws_cdk.aws_mediapackagev2_alpha as mediapackagev2_alpha
            
            start_tag_options = mediapackagev2_alpha.StartTagOptions(
                precise=False
            )
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__387f489898d9fa51d35a51b8e69abef87601862628c11c5b78d2d9481e273552)
            check_type(argname="argument precise", value=precise, expected_type=type_hints["precise"])
        self._values: typing.Dict[builtins.str, typing.Any] = {}
        if precise is not None:
            self._values["precise"] = precise

    @builtins.property
    def precise(self) -> typing.Optional[builtins.bool]:
        '''(experimental) Specify the value for PRECISE within your EXT-X-START tag.

        Leave blank, or choose false, to use the default value NO. Choose true to use the value YES.

        :default: false

        :stability: experimental
        '''
        result = self._values.get("precise")
        return typing.cast(typing.Optional[builtins.bool], result)

    def __eq__(self, rhs: typing.Any) -> builtins.bool:
        return isinstance(rhs, self.__class__) and rhs._values == self._values

    def __ne__(self, rhs: typing.Any) -> builtins.bool:
        return not (rhs == self)

    def __repr__(self) -> str:
        return "StartTagOptions(%s)" % ", ".join(
            k + "=" + repr(v) for k, v in self._values.items()
        )


@jsii.enum(jsii_type="@aws-cdk/aws-mediapackagev2-alpha.TextFilterKey")
class TextFilterKey(enum.Enum):
    '''(experimental) Text manifest filter keys for free-form string values.

    Use with ``ManifestFilter.text()`` and ``ManifestFilter.textList()``.

    For keys with fixed accepted values, use the dedicated methods on ``ManifestFilter`` instead:

    - Audio codec: ``ManifestFilter.audioCodec()`` / ``ManifestFilter.audioCodecList()``
    - Video codec: ``ManifestFilter.videoCodec()`` / ``ManifestFilter.videoCodecList()``
    - Video dynamic range: ``ManifestFilter.videoDynamicRange()`` / ``ManifestFilter.videoDynamicRangeList()``
    - Trickplay type: ``ManifestFilter.trickplayType()`` / ``ManifestFilter.trickplayTypeList()``

    :see: https://docs.aws.amazon.com/mediapackage/latest/userguide/manifest-filter-query-parameters.html
    :stability: experimental
    :exampleMetadata: infused

    Example::

        from aws_cdk.aws_mediapackagev2_alpha import FilterConfiguration
        # channel: Channel
        
        
        OriginEndpoint(self, "Endpoint",
            channel=channel,
            segment=Segment.cmaf(),
            manifests=[
                Manifest.hls(
                    manifest_name="index",
                    filter_configuration=FilterConfiguration(
                        manifest_filter=[
                            ManifestFilter.bitrate_range(BitrateFilterKey.VIDEO_BITRATE, Bitrate.mbps(1), Bitrate.mbps(5)),
                            ManifestFilter.numeric_range(NumericFilterKey.VIDEO_HEIGHT, 720, 1080),
                            ManifestFilter.video_codec_list([VideoCodec.H264, VideoCodec.H265]),
                            ManifestFilter.numeric(NumericFilterKey.AUDIO_CHANNELS, 2),
                            ManifestFilter.text_list(TextFilterKey.AUDIO_LANGUAGE, ["en-US", "fr"])
                        ],
                        time_delay=Duration.seconds(30)
                    )
                )
            ]
        )
    '''

    AUDIO_LANGUAGE = "AUDIO_LANGUAGE"
    '''(experimental) Audio languages or functional codes derived from encoder passthrough.

    Accepted values: arbitrary strings such as ISO-639-1 language codes (not case-sensitive).

    :stability: experimental
    '''
    SUBTITLE_LANGUAGE = "SUBTITLE_LANGUAGE"
    '''(experimental) The subtitle language or functional codes derived from encoder passthrough.

    Accepted values: arbitrary strings such as ISO-639-1 language codes (not case-sensitive).

    :stability: experimental
    '''


@jsii.enum(jsii_type="@aws-cdk/aws-mediapackagev2-alpha.TrickplayType")
class TrickplayType(enum.Enum):
    '''(experimental) Accepted trickplay type values for manifest filtering.

    :see: https://docs.aws.amazon.com/mediapackage/latest/userguide/manifest-filter-query-parameters.html
    :stability: experimental
    '''

    IFRAME = "IFRAME"
    '''(experimental) I-frame only trick-play.

    :stability: experimental
    '''
    IMAGE = "IMAGE"
    '''(experimental) Image-based trick-play.

    :stability: experimental
    '''
    NONE = "NONE"
    '''(experimental) No trick-play.

    :stability: experimental
    '''


@jsii.enum(jsii_type="@aws-cdk/aws-mediapackagev2-alpha.TsDrmSystem")
class TsDrmSystem(enum.Enum):
    '''(experimental) DRM systems available for TS encryption.

    SAMPLE_AES uses FairPlay, AES_128 uses Clear Key AES 128.

    :stability: experimental
    '''

    FAIRPLAY = "FAIRPLAY"
    '''(experimental) FairPlay DRM - used with SAMPLE_AES encryption.

    :stability: experimental
    '''
    CLEAR_KEY_AES_128 = "CLEAR_KEY_AES_128"
    '''(experimental) Clear Key AES 128 - used with AES_128 encryption.

    :stability: experimental
    '''


class TsEncryption(
    EncryptionConfiguration,
    metaclass=jsii.JSIIMeta,
    jsii_type="@aws-cdk/aws-mediapackagev2-alpha.TsEncryption",
):
    '''(experimental) Encryption configuration for TS segments.

    Use ``TsEncryption.speke()`` to create an instance.

    :stability: experimental
    :exampleMetadata: infused

    Example::

        # channel: Channel
        # speke_role: iam.IRole
        
        
        OriginEndpoint(self, "TsEndpoint",
            channel=channel,
            segment=Segment.ts(
                encryption=TsEncryption.speke(
                    method=TsEncryptionMethod.SAMPLE_AES,
                    resource_id="my-content-id",
                    url="https://example.com/speke",
                    role=speke_role
                )
            ),
            manifests=[Manifest.hls(manifest_name="index")]
        )
    '''

    @jsii.member(jsii_name="speke")
    @builtins.classmethod
    def speke(
        cls,
        *,
        method: "TsEncryptionMethod",
        resource_id: builtins.str,
        role: "_aws_cdk_aws_iam_ceddda9d.IRole",
        url: builtins.str,
        audio_preset: typing.Optional["PresetSpeke20Audio"] = None,
        certificate: typing.Optional["_aws_cdk_aws_certificatemanager_ceddda9d.ICertificate"] = None,
        constant_initialization_vector: typing.Optional[builtins.str] = None,
        drm_systems: typing.Optional[typing.Sequence["TsDrmSystem"]] = None,
        key_rotation_interval: typing.Optional["_aws_cdk_ceddda9d.Duration"] = None,
        video_preset: typing.Optional["PresetSpeke20Video"] = None,
    ) -> "TsEncryption":
        '''(experimental) Create a SPEKE-based encryption configuration for TS segments.

        :param method: (experimental) The encryption method to use.
        :param resource_id: (experimental) The unique identifier for the content. The service sends this identifier to the key server to identify the current endpoint. How unique you make this identifier depends on how fine-grained you want access controls to be. The service does not permit you to use the same ID for two simultaneous encryption processes.
        :param role: (experimental) IAM role for accessing the key provider API. This role must have a trust policy that allows MediaPackage to assume the role, and it must have sufficient permissions to access the key retrieval URL.
        :param url: (experimental) URL of the SPEKE key provider.
        :param audio_preset: (experimental) Audio encryption preset. Default: PresetSpeke20Audio.PRESET_AUDIO_1
        :param certificate: (experimental) The ARN of the certificate that you imported to AWS Certificate Manager to add content key encryption to this endpoint. For this feature to work, your DRM key provider must support content key encryption. Default: - no content key encryption
        :param constant_initialization_vector: (experimental) Constant initialization vector (32-character hex string). A 128-bit, 16-byte hex value represented by a 32-character string, used in conjunction with the key for encrypting content. Default: - MediaPackage generates the IV
        :param drm_systems: (experimental) The DRM systems to use for content protection. Default: - FairPlay for SAMPLE_AES, Clear Key AES 128 for AES_128
        :param key_rotation_interval: (experimental) Key rotation interval. Default: - no rotation
        :param video_preset: (experimental) Video encryption preset. Default: PresetSpeke20Video.PRESET_VIDEO_1

        :stability: experimental
        '''
        props = TsSpekeEncryptionProps(
            method=method,
            resource_id=resource_id,
            role=role,
            url=url,
            audio_preset=audio_preset,
            certificate=certificate,
            constant_initialization_vector=constant_initialization_vector,
            drm_systems=drm_systems,
            key_rotation_interval=key_rotation_interval,
            video_preset=video_preset,
        )

        return typing.cast("TsEncryption", jsii.sinvoke(cls, "speke", [props]))


@jsii.enum(jsii_type="@aws-cdk/aws-mediapackagev2-alpha.TsEncryptionMethod")
class TsEncryptionMethod(enum.Enum):
    '''(experimental) Encryption methods for TS container type.

    :stability: experimental
    :exampleMetadata: infused

    Example::

        # channel: Channel
        # speke_role: iam.IRole
        
        
        OriginEndpoint(self, "TsEndpoint",
            channel=channel,
            segment=Segment.ts(
                encryption=TsEncryption.speke(
                    method=TsEncryptionMethod.SAMPLE_AES,
                    resource_id="my-content-id",
                    url="https://example.com/speke",
                    role=speke_role
                )
            ),
            manifests=[Manifest.hls(manifest_name="index")]
        )
    '''

    AES_128 = "AES_128"
    '''(experimental) AES-128 encryption - requires Clear Key AES 128 DRM system.

    :stability: experimental
    '''
    SAMPLE_AES = "SAMPLE_AES"
    '''(experimental) Sample-level AES encryption - requires FairPlay DRM system.

    :stability: experimental
    '''


@jsii.data_type(
    jsii_type="@aws-cdk/aws-mediapackagev2-alpha.TsSegmentProps",
    jsii_struct_bases=[SegmentPropsBase],
    name_mapping={
        "duration": "duration",
        "include_iframe_only_streams": "includeIframeOnlyStreams",
        "name": "name",
        "encryption": "encryption",
        "include_dvb_subtitles": "includeDvbSubtitles",
        "scte_filter": "scteFilter",
        "scte_in_segments": "scteInSegments",
        "use_audio_rendition_group": "useAudioRenditionGroup",
    },
)
class TsSegmentProps(SegmentPropsBase):
    def __init__(
        self,
        *,
        duration: typing.Optional["_aws_cdk_ceddda9d.Duration"] = None,
        include_iframe_only_streams: typing.Optional[builtins.bool] = None,
        name: typing.Optional[builtins.str] = None,
        encryption: typing.Optional["TsEncryption"] = None,
        include_dvb_subtitles: typing.Optional[builtins.bool] = None,
        scte_filter: typing.Optional[typing.Sequence["ScteMessageType"]] = None,
        scte_in_segments: typing.Optional["ScteInSegments"] = None,
        use_audio_rendition_group: typing.Optional[builtins.bool] = None,
    ) -> None:
        '''(experimental) Properties for TS (Transport Stream) segment configuration.

        :param duration: (experimental) Duration of each segment. Default: Duration.seconds(6)
        :param include_iframe_only_streams: (experimental) Whether to include I-frame-only streams. Default: false
        :param name: (experimental) Name of the segment. Default: 'segment'
        :param encryption: (experimental) Encryption configuration for the TS segment. Use ``TsEncryption.speke()`` to create the configuration. Default: - No encryption
        :param include_dvb_subtitles: (experimental) Whether to include DVB subtitles. Default: false
        :param scte_filter: (experimental) SCTE-35 message types to treat as ad markers. Default: - no filtering
        :param scte_in_segments: (experimental) Controls whether SCTE-35 messages are included in segment files. Default: - SCTE-35 messages are not included in segments
        :param use_audio_rendition_group: (experimental) Whether to use audio rendition groups. Default: false

        :stability: experimental
        :exampleMetadata: infused

        Example::

            # channel: Channel
            
            
            OriginEndpoint(self, "TsEndpoint",
                channel=channel,
                segment=Segment.ts(
                    duration=Duration.seconds(6),
                    name="segment",
                    include_dvb_subtitles=True,
                    use_audio_rendition_group=True,
                    include_iframe_only_streams=False,
                    scte_filter=[ScteMessageType.BREAK, ScteMessageType.DISTRIBUTOR_ADVERTISEMENT
                    ]
                ),
                manifests=[Manifest.hls(manifest_name="index")]
            )
            
            OriginEndpoint(self, "CmafEndpoint",
                channel=channel,
                segment=Segment.cmaf(
                    duration=Duration.seconds(6),
                    name="segment",
                    include_iframe_only_streams=True,
                    scte_filter=[ScteMessageType.DISTRIBUTOR_ADVERTISEMENT]
                ),
                manifests=[Manifest.hls(manifest_name="index")]
            )
            
            OriginEndpoint(self, "Endpoint",
                channel=channel,
                segment=Segment.cmaf(),
                manifests=[Manifest.hls(manifest_name="index")]
            )
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__3cc04934c526853727862fc18b8646e58adf04f42ca30004bf72bd58e22bb9ba)
            check_type(argname="argument duration", value=duration, expected_type=type_hints["duration"])
            check_type(argname="argument include_iframe_only_streams", value=include_iframe_only_streams, expected_type=type_hints["include_iframe_only_streams"])
            check_type(argname="argument name", value=name, expected_type=type_hints["name"])
            check_type(argname="argument encryption", value=encryption, expected_type=type_hints["encryption"])
            check_type(argname="argument include_dvb_subtitles", value=include_dvb_subtitles, expected_type=type_hints["include_dvb_subtitles"])
            check_type(argname="argument scte_filter", value=scte_filter, expected_type=type_hints["scte_filter"])
            check_type(argname="argument scte_in_segments", value=scte_in_segments, expected_type=type_hints["scte_in_segments"])
            check_type(argname="argument use_audio_rendition_group", value=use_audio_rendition_group, expected_type=type_hints["use_audio_rendition_group"])
        self._values: typing.Dict[builtins.str, typing.Any] = {}
        if duration is not None:
            self._values["duration"] = duration
        if include_iframe_only_streams is not None:
            self._values["include_iframe_only_streams"] = include_iframe_only_streams
        if name is not None:
            self._values["name"] = name
        if encryption is not None:
            self._values["encryption"] = encryption
        if include_dvb_subtitles is not None:
            self._values["include_dvb_subtitles"] = include_dvb_subtitles
        if scte_filter is not None:
            self._values["scte_filter"] = scte_filter
        if scte_in_segments is not None:
            self._values["scte_in_segments"] = scte_in_segments
        if use_audio_rendition_group is not None:
            self._values["use_audio_rendition_group"] = use_audio_rendition_group

    @builtins.property
    def duration(self) -> typing.Optional["_aws_cdk_ceddda9d.Duration"]:
        '''(experimental) Duration of each segment.

        :default: Duration.seconds(6)

        :stability: experimental
        '''
        result = self._values.get("duration")
        return typing.cast(typing.Optional["_aws_cdk_ceddda9d.Duration"], result)

    @builtins.property
    def include_iframe_only_streams(self) -> typing.Optional[builtins.bool]:
        '''(experimental) Whether to include I-frame-only streams.

        :default: false

        :stability: experimental
        '''
        result = self._values.get("include_iframe_only_streams")
        return typing.cast(typing.Optional[builtins.bool], result)

    @builtins.property
    def name(self) -> typing.Optional[builtins.str]:
        '''(experimental) Name of the segment.

        :default: 'segment'

        :stability: experimental
        '''
        result = self._values.get("name")
        return typing.cast(typing.Optional[builtins.str], result)

    @builtins.property
    def encryption(self) -> typing.Optional["TsEncryption"]:
        '''(experimental) Encryption configuration for the TS segment.

        Use ``TsEncryption.speke()`` to create the configuration.

        :default: - No encryption

        :stability: experimental
        '''
        result = self._values.get("encryption")
        return typing.cast(typing.Optional["TsEncryption"], result)

    @builtins.property
    def include_dvb_subtitles(self) -> typing.Optional[builtins.bool]:
        '''(experimental) Whether to include DVB subtitles.

        :default: false

        :stability: experimental
        '''
        result = self._values.get("include_dvb_subtitles")
        return typing.cast(typing.Optional[builtins.bool], result)

    @builtins.property
    def scte_filter(self) -> typing.Optional[typing.List["ScteMessageType"]]:
        '''(experimental) SCTE-35 message types to treat as ad markers.

        :default: - no filtering

        :stability: experimental
        '''
        result = self._values.get("scte_filter")
        return typing.cast(typing.Optional[typing.List["ScteMessageType"]], result)

    @builtins.property
    def scte_in_segments(self) -> typing.Optional["ScteInSegments"]:
        '''(experimental) Controls whether SCTE-35 messages are included in segment files.

        :default: - SCTE-35 messages are not included in segments

        :stability: experimental
        '''
        result = self._values.get("scte_in_segments")
        return typing.cast(typing.Optional["ScteInSegments"], result)

    @builtins.property
    def use_audio_rendition_group(self) -> typing.Optional[builtins.bool]:
        '''(experimental) Whether to use audio rendition groups.

        :default: false

        :stability: experimental
        '''
        result = self._values.get("use_audio_rendition_group")
        return typing.cast(typing.Optional[builtins.bool], result)

    def __eq__(self, rhs: typing.Any) -> builtins.bool:
        return isinstance(rhs, self.__class__) and rhs._values == self._values

    def __ne__(self, rhs: typing.Any) -> builtins.bool:
        return not (rhs == self)

    def __repr__(self) -> str:
        return "TsSegmentProps(%s)" % ", ".join(
            k + "=" + repr(v) for k, v in self._values.items()
        )


@jsii.data_type(
    jsii_type="@aws-cdk/aws-mediapackagev2-alpha.TsSpekeEncryptionProps",
    jsii_struct_bases=[],
    name_mapping={
        "method": "method",
        "resource_id": "resourceId",
        "role": "role",
        "url": "url",
        "audio_preset": "audioPreset",
        "certificate": "certificate",
        "constant_initialization_vector": "constantInitializationVector",
        "drm_systems": "drmSystems",
        "key_rotation_interval": "keyRotationInterval",
        "video_preset": "videoPreset",
    },
)
class TsSpekeEncryptionProps:
    def __init__(
        self,
        *,
        method: "TsEncryptionMethod",
        resource_id: builtins.str,
        role: "_aws_cdk_aws_iam_ceddda9d.IRole",
        url: builtins.str,
        audio_preset: typing.Optional["PresetSpeke20Audio"] = None,
        certificate: typing.Optional["_aws_cdk_aws_certificatemanager_ceddda9d.ICertificate"] = None,
        constant_initialization_vector: typing.Optional[builtins.str] = None,
        drm_systems: typing.Optional[typing.Sequence["TsDrmSystem"]] = None,
        key_rotation_interval: typing.Optional["_aws_cdk_ceddda9d.Duration"] = None,
        video_preset: typing.Optional["PresetSpeke20Video"] = None,
    ) -> None:
        '''(experimental) Properties for TS SPEKE encryption configuration.

        :param method: (experimental) The encryption method to use.
        :param resource_id: (experimental) The unique identifier for the content. The service sends this identifier to the key server to identify the current endpoint. How unique you make this identifier depends on how fine-grained you want access controls to be. The service does not permit you to use the same ID for two simultaneous encryption processes.
        :param role: (experimental) IAM role for accessing the key provider API. This role must have a trust policy that allows MediaPackage to assume the role, and it must have sufficient permissions to access the key retrieval URL.
        :param url: (experimental) URL of the SPEKE key provider.
        :param audio_preset: (experimental) Audio encryption preset. Default: PresetSpeke20Audio.PRESET_AUDIO_1
        :param certificate: (experimental) The ARN of the certificate that you imported to AWS Certificate Manager to add content key encryption to this endpoint. For this feature to work, your DRM key provider must support content key encryption. Default: - no content key encryption
        :param constant_initialization_vector: (experimental) Constant initialization vector (32-character hex string). A 128-bit, 16-byte hex value represented by a 32-character string, used in conjunction with the key for encrypting content. Default: - MediaPackage generates the IV
        :param drm_systems: (experimental) The DRM systems to use for content protection. Default: - FairPlay for SAMPLE_AES, Clear Key AES 128 for AES_128
        :param key_rotation_interval: (experimental) Key rotation interval. Default: - no rotation
        :param video_preset: (experimental) Video encryption preset. Default: PresetSpeke20Video.PRESET_VIDEO_1

        :stability: experimental
        :exampleMetadata: infused

        Example::

            # channel: Channel
            # speke_role: iam.IRole
            
            
            OriginEndpoint(self, "TsEndpoint",
                channel=channel,
                segment=Segment.ts(
                    encryption=TsEncryption.speke(
                        method=TsEncryptionMethod.SAMPLE_AES,
                        resource_id="my-content-id",
                        url="https://example.com/speke",
                        role=speke_role
                    )
                ),
                manifests=[Manifest.hls(manifest_name="index")]
            )
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__b04324e17ebadcdfaea8e3a1eccad55437e3526f06a1f5746a01e27c59c61084)
            check_type(argname="argument method", value=method, expected_type=type_hints["method"])
            check_type(argname="argument resource_id", value=resource_id, expected_type=type_hints["resource_id"])
            check_type(argname="argument role", value=role, expected_type=type_hints["role"])
            check_type(argname="argument url", value=url, expected_type=type_hints["url"])
            check_type(argname="argument audio_preset", value=audio_preset, expected_type=type_hints["audio_preset"])
            check_type(argname="argument certificate", value=certificate, expected_type=type_hints["certificate"])
            check_type(argname="argument constant_initialization_vector", value=constant_initialization_vector, expected_type=type_hints["constant_initialization_vector"])
            check_type(argname="argument drm_systems", value=drm_systems, expected_type=type_hints["drm_systems"])
            check_type(argname="argument key_rotation_interval", value=key_rotation_interval, expected_type=type_hints["key_rotation_interval"])
            check_type(argname="argument video_preset", value=video_preset, expected_type=type_hints["video_preset"])
        self._values: typing.Dict[builtins.str, typing.Any] = {
            "method": method,
            "resource_id": resource_id,
            "role": role,
            "url": url,
        }
        if audio_preset is not None:
            self._values["audio_preset"] = audio_preset
        if certificate is not None:
            self._values["certificate"] = certificate
        if constant_initialization_vector is not None:
            self._values["constant_initialization_vector"] = constant_initialization_vector
        if drm_systems is not None:
            self._values["drm_systems"] = drm_systems
        if key_rotation_interval is not None:
            self._values["key_rotation_interval"] = key_rotation_interval
        if video_preset is not None:
            self._values["video_preset"] = video_preset

    @builtins.property
    def method(self) -> "TsEncryptionMethod":
        '''(experimental) The encryption method to use.

        :stability: experimental
        '''
        result = self._values.get("method")
        assert result is not None, "Required property 'method' is missing"
        return typing.cast("TsEncryptionMethod", result)

    @builtins.property
    def resource_id(self) -> builtins.str:
        '''(experimental) The unique identifier for the content.

        The service sends this identifier to the key server to identify the current endpoint.
        How unique you make this identifier depends on how fine-grained you want access controls to be.
        The service does not permit you to use the same ID for two simultaneous encryption processes.

        :stability: experimental
        '''
        result = self._values.get("resource_id")
        assert result is not None, "Required property 'resource_id' is missing"
        return typing.cast(builtins.str, result)

    @builtins.property
    def role(self) -> "_aws_cdk_aws_iam_ceddda9d.IRole":
        '''(experimental) IAM role for accessing the key provider API.

        This role must have a trust policy that allows MediaPackage to assume the role,
        and it must have sufficient permissions to access the key retrieval URL.

        :stability: experimental
        '''
        result = self._values.get("role")
        assert result is not None, "Required property 'role' is missing"
        return typing.cast("_aws_cdk_aws_iam_ceddda9d.IRole", result)

    @builtins.property
    def url(self) -> builtins.str:
        '''(experimental) URL of the SPEKE key provider.

        :stability: experimental
        '''
        result = self._values.get("url")
        assert result is not None, "Required property 'url' is missing"
        return typing.cast(builtins.str, result)

    @builtins.property
    def audio_preset(self) -> typing.Optional["PresetSpeke20Audio"]:
        '''(experimental) Audio encryption preset.

        :default: PresetSpeke20Audio.PRESET_AUDIO_1

        :stability: experimental
        '''
        result = self._values.get("audio_preset")
        return typing.cast(typing.Optional["PresetSpeke20Audio"], result)

    @builtins.property
    def certificate(
        self,
    ) -> typing.Optional["_aws_cdk_aws_certificatemanager_ceddda9d.ICertificate"]:
        '''(experimental) The ARN of the certificate that you imported to AWS Certificate Manager to add content key encryption to this endpoint.

        For this feature to work, your DRM key provider must support content key encryption.

        :default: - no content key encryption

        :stability: experimental
        '''
        result = self._values.get("certificate")
        return typing.cast(typing.Optional["_aws_cdk_aws_certificatemanager_ceddda9d.ICertificate"], result)

    @builtins.property
    def constant_initialization_vector(self) -> typing.Optional[builtins.str]:
        '''(experimental) Constant initialization vector (32-character hex string).

        A 128-bit, 16-byte hex value represented by a 32-character string,
        used in conjunction with the key for encrypting content.

        :default: - MediaPackage generates the IV

        :stability: experimental
        '''
        result = self._values.get("constant_initialization_vector")
        return typing.cast(typing.Optional[builtins.str], result)

    @builtins.property
    def drm_systems(self) -> typing.Optional[typing.List["TsDrmSystem"]]:
        '''(experimental) The DRM systems to use for content protection.

        :default: - FairPlay for SAMPLE_AES, Clear Key AES 128 for AES_128

        :stability: experimental
        '''
        result = self._values.get("drm_systems")
        return typing.cast(typing.Optional[typing.List["TsDrmSystem"]], result)

    @builtins.property
    def key_rotation_interval(self) -> typing.Optional["_aws_cdk_ceddda9d.Duration"]:
        '''(experimental) Key rotation interval.

        :default: - no rotation

        :stability: experimental
        '''
        result = self._values.get("key_rotation_interval")
        return typing.cast(typing.Optional["_aws_cdk_ceddda9d.Duration"], result)

    @builtins.property
    def video_preset(self) -> typing.Optional["PresetSpeke20Video"]:
        '''(experimental) Video encryption preset.

        :default: PresetSpeke20Video.PRESET_VIDEO_1

        :stability: experimental
        '''
        result = self._values.get("video_preset")
        return typing.cast(typing.Optional["PresetSpeke20Video"], result)

    def __eq__(self, rhs: typing.Any) -> builtins.bool:
        return isinstance(rhs, self.__class__) and rhs._values == self._values

    def __ne__(self, rhs: typing.Any) -> builtins.bool:
        return not (rhs == self)

    def __repr__(self) -> str:
        return "TsSpekeEncryptionProps(%s)" % ", ".join(
            k + "=" + repr(v) for k, v in self._values.items()
        )


@jsii.enum(jsii_type="@aws-cdk/aws-mediapackagev2-alpha.TtmlProfile")
class TtmlProfile(enum.Enum):
    '''(experimental) Options for TTML Profile.

    :stability: experimental
    '''

    IMSC_1 = "IMSC_1"
    '''(experimental) IMSC_1.

    :stability: experimental
    '''
    EBU_TT_D_101 = "EBU_TT_D_101"
    '''(experimental) EBU_TT_D_101.

    :stability: experimental
    '''


@jsii.enum(jsii_type="@aws-cdk/aws-mediapackagev2-alpha.VideoCodec")
class VideoCodec(enum.Enum):
    '''(experimental) Accepted video codec values for manifest filtering.

    :see: https://docs.aws.amazon.com/mediapackage/latest/userguide/manifest-filter-query-parameters.html
    :stability: experimental
    '''

    H264 = "H264"
    '''(experimental) H.264/AVC.

    :stability: experimental
    '''
    H265 = "H265"
    '''(experimental) H.265/HEVC.

    :stability: experimental
    '''
    AV1 = "AV1"
    '''(experimental) AV1.

    :stability: experimental
    '''


@jsii.enum(jsii_type="@aws-cdk/aws-mediapackagev2-alpha.VideoDynamicRange")
class VideoDynamicRange(enum.Enum):
    '''(experimental) Accepted video dynamic range values for manifest filtering.

    :see: https://docs.aws.amazon.com/mediapackage/latest/userguide/manifest-filter-query-parameters.html
    :stability: experimental
    '''

    DV = "DV"
    '''(experimental) Dolby Vision.

    :stability: experimental
    '''
    HDR10 = "HDR10"
    '''(experimental) HDR10.

    :stability: experimental
    '''
    HLG = "HLG"
    '''(experimental) Hybrid Log-Gamma.

    :stability: experimental
    '''
    SDR = "SDR"
    '''(experimental) Standard Dynamic Range.

    :stability: experimental
    '''


@jsii.implements(IChannel)
class Channel(
    _aws_cdk_ceddda9d.Resource,
    metaclass=jsii.JSIIMeta,
    jsii_type="@aws-cdk/aws-mediapackagev2-alpha.Channel",
):
    '''(experimental) Defines an AWS Elemental MediaPackage V2 Channel.

    :stability: experimental
    :exampleMetadata: infused

    Example::

        # stack: Stack
        
        group = ChannelGroup(stack, "MyChannelGroup",
            channel_group_name="my-test-channel-group"
        )
        
        channel = Channel(stack, "MyChannel",
            channel_group=group,
            channel_name="my-testchannel",
            input=InputConfiguration.cmaf()
        )
        
        endpoint = OriginEndpoint(stack, "MyOriginEndpoint",
            channel=channel,
            origin_endpoint_name="my-test-endpoint",
            segment=Segment.cmaf(),
            manifests=[Manifest.hls(
                manifest_name="index"
            )]
        )
    '''

    def __init__(
        self,
        scope: "_constructs_77d1e7e8.Construct",
        id: builtins.str,
        *,
        channel_group: "IChannelGroup",
        channel_name: typing.Optional[builtins.str] = None,
        description: typing.Optional[builtins.str] = None,
        input: typing.Optional["InputConfiguration"] = None,
        removal_policy: typing.Optional["_aws_cdk_ceddda9d.RemovalPolicy"] = None,
        tags: typing.Optional[typing.Mapping[builtins.str, builtins.str]] = None,
    ) -> None:
        '''
        :param scope: -
        :param id: -
        :param channel_group: (experimental) Channel Group to add this Channel to.
        :param channel_name: (experimental) The name that describes the channel. The name is the primary identifier for the channel, and must be unique for your account in the AWS Region and channel group. Default: autogenerated
        :param description: (experimental) Enter any descriptive text that helps you to identify the channel. Default: no description
        :param input: (experimental) Input configuration for the channel. Use InputConfiguration.hls() or InputConfiguration.cmaf() to create the configuration. Default: InputConfiguration.cmaf()
        :param removal_policy: (experimental) Policy to apply when the channel is removed from the stack. Even though MediaPackage ChannelGroups, Channels and OriginEndpoints are technically stateful, their contents are transient and it is common to add and remove these while rearchitecting your application. The default is therefore ``DESTROY``. Change it to ``RETAIN`` if the content (in a lookback window) are so valuable that accidentally losing it would be unacceptable. Default: RemovalPolicy.DESTROY
        :param tags: (experimental) Tags to add to the Channel. Default: No tagging

        :stability: experimental
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__e97930301d3a05b49d8965b18baf102128ed5083396ddf568115a87aa3c19cf0)
            check_type(argname="argument scope", value=scope, expected_type=type_hints["scope"])
            check_type(argname="argument id", value=id, expected_type=type_hints["id"])
        props = ChannelProps(
            channel_group=channel_group,
            channel_name=channel_name,
            description=description,
            input=input,
            removal_policy=removal_policy,
            tags=tags,
        )

        jsii.create(self.__class__, self, [scope, id, props])

    @jsii.member(jsii_name="fromChannelAttributes")
    @builtins.classmethod
    def from_channel_attributes(
        cls,
        scope: "_constructs_77d1e7e8.Construct",
        id: builtins.str,
        *,
        channel_group_name: builtins.str,
        channel_name: builtins.str,
    ) -> "IChannel":
        '''(experimental) Creates a Channel construct that represents an external (imported) Channel.

        :param scope: -
        :param id: -
        :param channel_group_name: (experimental) The name that describes the channel group.
        :param channel_name: (experimental) The name that describes the channel.

        :stability: experimental
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__2a6c2d90a33f6cd3293e16e95225b645ef5cdd382ca625942dbdea43236c489a)
            check_type(argname="argument scope", value=scope, expected_type=type_hints["scope"])
            check_type(argname="argument id", value=id, expected_type=type_hints["id"])
        attrs = ChannelAttributes(
            channel_group_name=channel_group_name, channel_name=channel_name
        )

        return typing.cast("IChannel", jsii.sinvoke(cls, "fromChannelAttributes", [scope, id, attrs]))

    @jsii.member(jsii_name="addOriginEndpoint")
    def add_origin_endpoint(
        self,
        id: builtins.str,
        *,
        manifests: typing.Sequence["Manifest"],
        segment: typing.Union["SegmentConfiguration", typing.Dict[builtins.str, typing.Any]],
        cdn_auth: typing.Optional[typing.Union["CdnAuthConfiguration", typing.Dict[builtins.str, typing.Any]]] = None,
        description: typing.Optional[builtins.str] = None,
        force_endpoint_configuration_conditions: typing.Optional[typing.Sequence["EndpointErrorConfiguration"]] = None,
        origin_endpoint_name: typing.Optional[builtins.str] = None,
        removal_policy: typing.Optional["_aws_cdk_ceddda9d.RemovalPolicy"] = None,
        startover_window: typing.Optional["_aws_cdk_ceddda9d.Duration"] = None,
        tags: typing.Optional[typing.Mapping[builtins.str, builtins.str]] = None,
    ) -> "OriginEndpoint":
        '''(experimental) Add Origin Endpoint for this Channel.

        :param id: -
        :param manifests: (experimental) Manifests configuration for HLS, Low Latency HLS and DASH.
        :param segment: (experimental) The segment associated with the origin endpoint. Inside the segment configuration you can define options such as encryption, SPEKE parameters and other general segment configurations. Use Segment.ts() or Segment.cmaf() to create the configuration.
        :param cdn_auth: (experimental) Provide access to MediaPackage V2 Origin Endpoint via secret header. Default: undefined - Not configured on endpoint
        :param description: (experimental) The description associated with the origin endpoint. Default: undefined - No description is added to Origin Endpoint
        :param force_endpoint_configuration_conditions: (experimental) The failover settings for the endpoint. Default: undefined - No force endpoint configuration is configured
        :param origin_endpoint_name: (experimental) The name of the origin endpoint associated with the origin endpoint configuration. Default: autogenerated
        :param removal_policy: (experimental) Policy to apply when the origin endpoint is removed from the stack. Even though MediaPackage ChannelGroups, Channels and OriginEndpoints are technically stateful, their contents are transient and it is common to add and remove these while rearchitecting your application. The default is therefore ``DESTROY``. Change it to ``RETAIN`` if the content (in a lookback window) are so valuable that accidentally losing it would be unacceptable. Default: RemovalPolicy.DESTROY
        :param startover_window: (experimental) The size of the window to specify a window of the live stream that's available for on-demand viewing. Viewers can start-over or catch-up on content that falls within the window. Default: 900
        :param tags: (experimental) The tags associated with the origin endpoint. Default: - No tagging

        :stability: experimental
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__d54a8801ed11b95de27ff35870f70803f222c8a39177ba6693742f428b05234c)
            check_type(argname="argument id", value=id, expected_type=type_hints["id"])
        options = OriginEndpointOptions(
            manifests=manifests,
            segment=segment,
            cdn_auth=cdn_auth,
            description=description,
            force_endpoint_configuration_conditions=force_endpoint_configuration_conditions,
            origin_endpoint_name=origin_endpoint_name,
            removal_policy=removal_policy,
            startover_window=startover_window,
            tags=tags,
        )

        return typing.cast("OriginEndpoint", jsii.invoke(self, "addOriginEndpoint", [id, options]))

    @jsii.member(jsii_name="addToResourcePolicy")
    def add_to_resource_policy(
        self,
        statement: "_aws_cdk_aws_iam_ceddda9d.PolicyStatement",
    ) -> "_aws_cdk_aws_iam_ceddda9d.AddToResourcePolicyResult":
        '''(experimental) Configure channel policy.

        You can only add 1 ChannelPolicy to a Channel.
        If you have already defined one, function will append the policy already created.

        :param statement: -

        :stability: experimental
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__53ea6ee834bec3996dc93e56c76a3dc4c06332c523577d6e599827d11c607d54)
            check_type(argname="argument statement", value=statement, expected_type=type_hints["statement"])
        return typing.cast("_aws_cdk_aws_iam_ceddda9d.AddToResourcePolicyResult", jsii.invoke(self, "addToResourcePolicy", [statement]))

    @jsii.member(jsii_name="metric")
    def metric(
        self,
        metric_name: builtins.str,
        *,
        account: typing.Optional[builtins.str] = None,
        color: typing.Optional[builtins.str] = None,
        dimensions_map: typing.Optional[typing.Mapping[builtins.str, builtins.str]] = None,
        id: typing.Optional[builtins.str] = None,
        label: typing.Optional[builtins.str] = None,
        period: typing.Optional["_aws_cdk_ceddda9d.Duration"] = None,
        region: typing.Optional[builtins.str] = None,
        stack_account: typing.Optional[builtins.str] = None,
        stack_region: typing.Optional[builtins.str] = None,
        statistic: typing.Optional[builtins.str] = None,
        unit: typing.Optional["_aws_cdk_aws_cloudwatch_ceddda9d.Unit"] = None,
        visible: typing.Optional[builtins.bool] = None,
    ) -> "_aws_cdk_aws_cloudwatch_ceddda9d.Metric":
        '''(experimental) Create a CloudWatch metric.

        :param metric_name: name of the metric.
        :param account: Account which this metric comes from. Default: - Deployment account.
        :param color: The hex color code, prefixed with '#' (e.g. '#00ff00'), to use when this metric is rendered on a graph. The ``Color`` class has a set of standard colors that can be used here. Default: - Automatic color
        :param dimensions_map: Dimensions of the metric. Default: - No dimensions.
        :param id: Unique identifier for this metric when used in dashboard widgets. The id can be used as a variable to represent this metric in math expressions. Valid characters are letters, numbers, and underscore. The first character must be a lowercase letter. Default: - No ID
        :param label: Label for this metric when added to a Graph in a Dashboard. You can use `dynamic labels <https://docs.aws.amazon.com/AmazonCloudWatch/latest/monitoring/graph-dynamic-labels.html>`_ to show summary information about the entire displayed time series in the legend. For example, if you use:: [max: ${MAX}] MyMetric As the metric label, the maximum value in the visible range will be shown next to the time series name in the graph's legend. Default: - No label
        :param period: The period over which the specified statistic is applied. Default: Duration.minutes(5)
        :param region: Region which this metric comes from. Default: - Deployment region.
        :param stack_account: Account of the stack this metric is attached to. Default: - Deployment account.
        :param stack_region: Region of the stack this metric is attached to. Default: - Deployment region.
        :param statistic: What function to use for aggregating. Use the ``aws_cloudwatch.Stats`` helper class to construct valid input strings. Can be one of the following: - "Minimum" | "min" - "Maximum" | "max" - "Average" | "avg" - "Sum" | "sum" - "SampleCount | "n" - "pNN.NN" - "tmNN.NN" | "tm(NN.NN%:NN.NN%)" - "iqm" - "wmNN.NN" | "wm(NN.NN%:NN.NN%)" - "tcNN.NN" | "tc(NN.NN%:NN.NN%)" - "tsNN.NN" | "ts(NN.NN%:NN.NN%)" Default: Average
        :param unit: Unit used to filter the metric stream. Only refer to datums emitted to the metric stream with the given unit and ignore all others. Only useful when datums are being emitted to the same metric stream under different units. The default is to use all matric datums in the stream, regardless of unit, which is recommended in nearly all cases. CloudWatch does not honor this property for graphs. Default: - All metric datums in the given metric stream
        :param visible: Whether this metric should be visible in dashboard graphs. Setting this to false is useful when you want to hide raw metrics that are used in math expressions, and show only the expression results. Default: true

        :stability: experimental
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__c3fadc96f0188e24b9399874ae898f21357c07a50dbaf4dcc1d9d1fabcd34ab3)
            check_type(argname="argument metric_name", value=metric_name, expected_type=type_hints["metric_name"])
        options = _aws_cdk_aws_cloudwatch_ceddda9d.MetricOptions(
            account=account,
            color=color,
            dimensions_map=dimensions_map,
            id=id,
            label=label,
            period=period,
            region=region,
            stack_account=stack_account,
            stack_region=stack_region,
            statistic=statistic,
            unit=unit,
            visible=visible,
        )

        return typing.cast("_aws_cdk_aws_cloudwatch_ceddda9d.Metric", jsii.invoke(self, "metric", [metric_name, options]))

    @jsii.member(jsii_name="metricEgressBytes")
    def metric_egress_bytes(
        self,
        *,
        account: typing.Optional[builtins.str] = None,
        color: typing.Optional[builtins.str] = None,
        dimensions_map: typing.Optional[typing.Mapping[builtins.str, builtins.str]] = None,
        id: typing.Optional[builtins.str] = None,
        label: typing.Optional[builtins.str] = None,
        period: typing.Optional["_aws_cdk_ceddda9d.Duration"] = None,
        region: typing.Optional[builtins.str] = None,
        stack_account: typing.Optional[builtins.str] = None,
        stack_region: typing.Optional[builtins.str] = None,
        statistic: typing.Optional[builtins.str] = None,
        unit: typing.Optional["_aws_cdk_aws_cloudwatch_ceddda9d.Unit"] = None,
        visible: typing.Optional[builtins.bool] = None,
    ) -> "_aws_cdk_aws_cloudwatch_ceddda9d.Metric":
        '''(experimental) Returns Metric for Egress Bytes.

        :param account: Account which this metric comes from. Default: - Deployment account.
        :param color: The hex color code, prefixed with '#' (e.g. '#00ff00'), to use when this metric is rendered on a graph. The ``Color`` class has a set of standard colors that can be used here. Default: - Automatic color
        :param dimensions_map: Dimensions of the metric. Default: - No dimensions.
        :param id: Unique identifier for this metric when used in dashboard widgets. The id can be used as a variable to represent this metric in math expressions. Valid characters are letters, numbers, and underscore. The first character must be a lowercase letter. Default: - No ID
        :param label: Label for this metric when added to a Graph in a Dashboard. You can use `dynamic labels <https://docs.aws.amazon.com/AmazonCloudWatch/latest/monitoring/graph-dynamic-labels.html>`_ to show summary information about the entire displayed time series in the legend. For example, if you use:: [max: ${MAX}] MyMetric As the metric label, the maximum value in the visible range will be shown next to the time series name in the graph's legend. Default: - No label
        :param period: The period over which the specified statistic is applied. Default: Duration.minutes(5)
        :param region: Region which this metric comes from. Default: - Deployment region.
        :param stack_account: Account of the stack this metric is attached to. Default: - Deployment account.
        :param stack_region: Region of the stack this metric is attached to. Default: - Deployment region.
        :param statistic: What function to use for aggregating. Use the ``aws_cloudwatch.Stats`` helper class to construct valid input strings. Can be one of the following: - "Minimum" | "min" - "Maximum" | "max" - "Average" | "avg" - "Sum" | "sum" - "SampleCount | "n" - "pNN.NN" - "tmNN.NN" | "tm(NN.NN%:NN.NN%)" - "iqm" - "wmNN.NN" | "wm(NN.NN%:NN.NN%)" - "tcNN.NN" | "tc(NN.NN%:NN.NN%)" - "tsNN.NN" | "ts(NN.NN%:NN.NN%)" Default: Average
        :param unit: Unit used to filter the metric stream. Only refer to datums emitted to the metric stream with the given unit and ignore all others. Only useful when datums are being emitted to the same metric stream under different units. The default is to use all matric datums in the stream, regardless of unit, which is recommended in nearly all cases. CloudWatch does not honor this property for graphs. Default: - All metric datums in the given metric stream
        :param visible: Whether this metric should be visible in dashboard graphs. Setting this to false is useful when you want to hide raw metrics that are used in math expressions, and show only the expression results. Default: true

        :default: - sum over 60 seconds

        :stability: experimental
        '''
        options = _aws_cdk_aws_cloudwatch_ceddda9d.MetricOptions(
            account=account,
            color=color,
            dimensions_map=dimensions_map,
            id=id,
            label=label,
            period=period,
            region=region,
            stack_account=stack_account,
            stack_region=stack_region,
            statistic=statistic,
            unit=unit,
            visible=visible,
        )

        return typing.cast("_aws_cdk_aws_cloudwatch_ceddda9d.Metric", jsii.invoke(self, "metricEgressBytes", [options]))

    @jsii.member(jsii_name="metricEgressRequestCount")
    def metric_egress_request_count(
        self,
        *,
        account: typing.Optional[builtins.str] = None,
        color: typing.Optional[builtins.str] = None,
        dimensions_map: typing.Optional[typing.Mapping[builtins.str, builtins.str]] = None,
        id: typing.Optional[builtins.str] = None,
        label: typing.Optional[builtins.str] = None,
        period: typing.Optional["_aws_cdk_ceddda9d.Duration"] = None,
        region: typing.Optional[builtins.str] = None,
        stack_account: typing.Optional[builtins.str] = None,
        stack_region: typing.Optional[builtins.str] = None,
        statistic: typing.Optional[builtins.str] = None,
        unit: typing.Optional["_aws_cdk_aws_cloudwatch_ceddda9d.Unit"] = None,
        visible: typing.Optional[builtins.bool] = None,
    ) -> "_aws_cdk_aws_cloudwatch_ceddda9d.Metric":
        '''(experimental) Returns Metric for Egress Request Count.

        :param account: Account which this metric comes from. Default: - Deployment account.
        :param color: The hex color code, prefixed with '#' (e.g. '#00ff00'), to use when this metric is rendered on a graph. The ``Color`` class has a set of standard colors that can be used here. Default: - Automatic color
        :param dimensions_map: Dimensions of the metric. Default: - No dimensions.
        :param id: Unique identifier for this metric when used in dashboard widgets. The id can be used as a variable to represent this metric in math expressions. Valid characters are letters, numbers, and underscore. The first character must be a lowercase letter. Default: - No ID
        :param label: Label for this metric when added to a Graph in a Dashboard. You can use `dynamic labels <https://docs.aws.amazon.com/AmazonCloudWatch/latest/monitoring/graph-dynamic-labels.html>`_ to show summary information about the entire displayed time series in the legend. For example, if you use:: [max: ${MAX}] MyMetric As the metric label, the maximum value in the visible range will be shown next to the time series name in the graph's legend. Default: - No label
        :param period: The period over which the specified statistic is applied. Default: Duration.minutes(5)
        :param region: Region which this metric comes from. Default: - Deployment region.
        :param stack_account: Account of the stack this metric is attached to. Default: - Deployment account.
        :param stack_region: Region of the stack this metric is attached to. Default: - Deployment region.
        :param statistic: What function to use for aggregating. Use the ``aws_cloudwatch.Stats`` helper class to construct valid input strings. Can be one of the following: - "Minimum" | "min" - "Maximum" | "max" - "Average" | "avg" - "Sum" | "sum" - "SampleCount | "n" - "pNN.NN" - "tmNN.NN" | "tm(NN.NN%:NN.NN%)" - "iqm" - "wmNN.NN" | "wm(NN.NN%:NN.NN%)" - "tcNN.NN" | "tc(NN.NN%:NN.NN%)" - "tsNN.NN" | "ts(NN.NN%:NN.NN%)" Default: Average
        :param unit: Unit used to filter the metric stream. Only refer to datums emitted to the metric stream with the given unit and ignore all others. Only useful when datums are being emitted to the same metric stream under different units. The default is to use all matric datums in the stream, regardless of unit, which is recommended in nearly all cases. CloudWatch does not honor this property for graphs. Default: - All metric datums in the given metric stream
        :param visible: Whether this metric should be visible in dashboard graphs. Setting this to false is useful when you want to hide raw metrics that are used in math expressions, and show only the expression results. Default: true

        :default: - sum over 60 seconds

        :stability: experimental
        '''
        options = _aws_cdk_aws_cloudwatch_ceddda9d.MetricOptions(
            account=account,
            color=color,
            dimensions_map=dimensions_map,
            id=id,
            label=label,
            period=period,
            region=region,
            stack_account=stack_account,
            stack_region=stack_region,
            statistic=statistic,
            unit=unit,
            visible=visible,
        )

        return typing.cast("_aws_cdk_aws_cloudwatch_ceddda9d.Metric", jsii.invoke(self, "metricEgressRequestCount", [options]))

    @jsii.member(jsii_name="metricEgressResponseTime")
    def metric_egress_response_time(
        self,
        *,
        account: typing.Optional[builtins.str] = None,
        color: typing.Optional[builtins.str] = None,
        dimensions_map: typing.Optional[typing.Mapping[builtins.str, builtins.str]] = None,
        id: typing.Optional[builtins.str] = None,
        label: typing.Optional[builtins.str] = None,
        period: typing.Optional["_aws_cdk_ceddda9d.Duration"] = None,
        region: typing.Optional[builtins.str] = None,
        stack_account: typing.Optional[builtins.str] = None,
        stack_region: typing.Optional[builtins.str] = None,
        statistic: typing.Optional[builtins.str] = None,
        unit: typing.Optional["_aws_cdk_aws_cloudwatch_ceddda9d.Unit"] = None,
        visible: typing.Optional[builtins.bool] = None,
    ) -> "_aws_cdk_aws_cloudwatch_ceddda9d.Metric":
        '''(experimental) Returns Metric for Egress Response time.

        :param account: Account which this metric comes from. Default: - Deployment account.
        :param color: The hex color code, prefixed with '#' (e.g. '#00ff00'), to use when this metric is rendered on a graph. The ``Color`` class has a set of standard colors that can be used here. Default: - Automatic color
        :param dimensions_map: Dimensions of the metric. Default: - No dimensions.
        :param id: Unique identifier for this metric when used in dashboard widgets. The id can be used as a variable to represent this metric in math expressions. Valid characters are letters, numbers, and underscore. The first character must be a lowercase letter. Default: - No ID
        :param label: Label for this metric when added to a Graph in a Dashboard. You can use `dynamic labels <https://docs.aws.amazon.com/AmazonCloudWatch/latest/monitoring/graph-dynamic-labels.html>`_ to show summary information about the entire displayed time series in the legend. For example, if you use:: [max: ${MAX}] MyMetric As the metric label, the maximum value in the visible range will be shown next to the time series name in the graph's legend. Default: - No label
        :param period: The period over which the specified statistic is applied. Default: Duration.minutes(5)
        :param region: Region which this metric comes from. Default: - Deployment region.
        :param stack_account: Account of the stack this metric is attached to. Default: - Deployment account.
        :param stack_region: Region of the stack this metric is attached to. Default: - Deployment region.
        :param statistic: What function to use for aggregating. Use the ``aws_cloudwatch.Stats`` helper class to construct valid input strings. Can be one of the following: - "Minimum" | "min" - "Maximum" | "max" - "Average" | "avg" - "Sum" | "sum" - "SampleCount | "n" - "pNN.NN" - "tmNN.NN" | "tm(NN.NN%:NN.NN%)" - "iqm" - "wmNN.NN" | "wm(NN.NN%:NN.NN%)" - "tcNN.NN" | "tc(NN.NN%:NN.NN%)" - "tsNN.NN" | "ts(NN.NN%:NN.NN%)" Default: Average
        :param unit: Unit used to filter the metric stream. Only refer to datums emitted to the metric stream with the given unit and ignore all others. Only useful when datums are being emitted to the same metric stream under different units. The default is to use all matric datums in the stream, regardless of unit, which is recommended in nearly all cases. CloudWatch does not honor this property for graphs. Default: - All metric datums in the given metric stream
        :param visible: Whether this metric should be visible in dashboard graphs. Setting this to false is useful when you want to hide raw metrics that are used in math expressions, and show only the expression results. Default: true

        :default: - average over 60 seconds

        :stability: experimental
        '''
        options = _aws_cdk_aws_cloudwatch_ceddda9d.MetricOptions(
            account=account,
            color=color,
            dimensions_map=dimensions_map,
            id=id,
            label=label,
            period=period,
            region=region,
            stack_account=stack_account,
            stack_region=stack_region,
            statistic=statistic,
            unit=unit,
            visible=visible,
        )

        return typing.cast("_aws_cdk_aws_cloudwatch_ceddda9d.Metric", jsii.invoke(self, "metricEgressResponseTime", [options]))

    @jsii.member(jsii_name="metricIngressBytes")
    def metric_ingress_bytes(
        self,
        *,
        account: typing.Optional[builtins.str] = None,
        color: typing.Optional[builtins.str] = None,
        dimensions_map: typing.Optional[typing.Mapping[builtins.str, builtins.str]] = None,
        id: typing.Optional[builtins.str] = None,
        label: typing.Optional[builtins.str] = None,
        period: typing.Optional["_aws_cdk_ceddda9d.Duration"] = None,
        region: typing.Optional[builtins.str] = None,
        stack_account: typing.Optional[builtins.str] = None,
        stack_region: typing.Optional[builtins.str] = None,
        statistic: typing.Optional[builtins.str] = None,
        unit: typing.Optional["_aws_cdk_aws_cloudwatch_ceddda9d.Unit"] = None,
        visible: typing.Optional[builtins.bool] = None,
    ) -> "_aws_cdk_aws_cloudwatch_ceddda9d.Metric":
        '''(experimental) Returns Metric for Ingress Bytes.

        :param account: Account which this metric comes from. Default: - Deployment account.
        :param color: The hex color code, prefixed with '#' (e.g. '#00ff00'), to use when this metric is rendered on a graph. The ``Color`` class has a set of standard colors that can be used here. Default: - Automatic color
        :param dimensions_map: Dimensions of the metric. Default: - No dimensions.
        :param id: Unique identifier for this metric when used in dashboard widgets. The id can be used as a variable to represent this metric in math expressions. Valid characters are letters, numbers, and underscore. The first character must be a lowercase letter. Default: - No ID
        :param label: Label for this metric when added to a Graph in a Dashboard. You can use `dynamic labels <https://docs.aws.amazon.com/AmazonCloudWatch/latest/monitoring/graph-dynamic-labels.html>`_ to show summary information about the entire displayed time series in the legend. For example, if you use:: [max: ${MAX}] MyMetric As the metric label, the maximum value in the visible range will be shown next to the time series name in the graph's legend. Default: - No label
        :param period: The period over which the specified statistic is applied. Default: Duration.minutes(5)
        :param region: Region which this metric comes from. Default: - Deployment region.
        :param stack_account: Account of the stack this metric is attached to. Default: - Deployment account.
        :param stack_region: Region of the stack this metric is attached to. Default: - Deployment region.
        :param statistic: What function to use for aggregating. Use the ``aws_cloudwatch.Stats`` helper class to construct valid input strings. Can be one of the following: - "Minimum" | "min" - "Maximum" | "max" - "Average" | "avg" - "Sum" | "sum" - "SampleCount | "n" - "pNN.NN" - "tmNN.NN" | "tm(NN.NN%:NN.NN%)" - "iqm" - "wmNN.NN" | "wm(NN.NN%:NN.NN%)" - "tcNN.NN" | "tc(NN.NN%:NN.NN%)" - "tsNN.NN" | "ts(NN.NN%:NN.NN%)" Default: Average
        :param unit: Unit used to filter the metric stream. Only refer to datums emitted to the metric stream with the given unit and ignore all others. Only useful when datums are being emitted to the same metric stream under different units. The default is to use all matric datums in the stream, regardless of unit, which is recommended in nearly all cases. CloudWatch does not honor this property for graphs. Default: - All metric datums in the given metric stream
        :param visible: Whether this metric should be visible in dashboard graphs. Setting this to false is useful when you want to hide raw metrics that are used in math expressions, and show only the expression results. Default: true

        :default: - sum over 60 seconds

        :stability: experimental
        '''
        options = _aws_cdk_aws_cloudwatch_ceddda9d.MetricOptions(
            account=account,
            color=color,
            dimensions_map=dimensions_map,
            id=id,
            label=label,
            period=period,
            region=region,
            stack_account=stack_account,
            stack_region=stack_region,
            statistic=statistic,
            unit=unit,
            visible=visible,
        )

        return typing.cast("_aws_cdk_aws_cloudwatch_ceddda9d.Metric", jsii.invoke(self, "metricIngressBytes", [options]))

    @jsii.member(jsii_name="metricIngressRequestCount")
    def metric_ingress_request_count(
        self,
        *,
        account: typing.Optional[builtins.str] = None,
        color: typing.Optional[builtins.str] = None,
        dimensions_map: typing.Optional[typing.Mapping[builtins.str, builtins.str]] = None,
        id: typing.Optional[builtins.str] = None,
        label: typing.Optional[builtins.str] = None,
        period: typing.Optional["_aws_cdk_ceddda9d.Duration"] = None,
        region: typing.Optional[builtins.str] = None,
        stack_account: typing.Optional[builtins.str] = None,
        stack_region: typing.Optional[builtins.str] = None,
        statistic: typing.Optional[builtins.str] = None,
        unit: typing.Optional["_aws_cdk_aws_cloudwatch_ceddda9d.Unit"] = None,
        visible: typing.Optional[builtins.bool] = None,
    ) -> "_aws_cdk_aws_cloudwatch_ceddda9d.Metric":
        '''(experimental) Returns Metric for Ingress Request Count.

        :param account: Account which this metric comes from. Default: - Deployment account.
        :param color: The hex color code, prefixed with '#' (e.g. '#00ff00'), to use when this metric is rendered on a graph. The ``Color`` class has a set of standard colors that can be used here. Default: - Automatic color
        :param dimensions_map: Dimensions of the metric. Default: - No dimensions.
        :param id: Unique identifier for this metric when used in dashboard widgets. The id can be used as a variable to represent this metric in math expressions. Valid characters are letters, numbers, and underscore. The first character must be a lowercase letter. Default: - No ID
        :param label: Label for this metric when added to a Graph in a Dashboard. You can use `dynamic labels <https://docs.aws.amazon.com/AmazonCloudWatch/latest/monitoring/graph-dynamic-labels.html>`_ to show summary information about the entire displayed time series in the legend. For example, if you use:: [max: ${MAX}] MyMetric As the metric label, the maximum value in the visible range will be shown next to the time series name in the graph's legend. Default: - No label
        :param period: The period over which the specified statistic is applied. Default: Duration.minutes(5)
        :param region: Region which this metric comes from. Default: - Deployment region.
        :param stack_account: Account of the stack this metric is attached to. Default: - Deployment account.
        :param stack_region: Region of the stack this metric is attached to. Default: - Deployment region.
        :param statistic: What function to use for aggregating. Use the ``aws_cloudwatch.Stats`` helper class to construct valid input strings. Can be one of the following: - "Minimum" | "min" - "Maximum" | "max" - "Average" | "avg" - "Sum" | "sum" - "SampleCount | "n" - "pNN.NN" - "tmNN.NN" | "tm(NN.NN%:NN.NN%)" - "iqm" - "wmNN.NN" | "wm(NN.NN%:NN.NN%)" - "tcNN.NN" | "tc(NN.NN%:NN.NN%)" - "tsNN.NN" | "ts(NN.NN%:NN.NN%)" Default: Average
        :param unit: Unit used to filter the metric stream. Only refer to datums emitted to the metric stream with the given unit and ignore all others. Only useful when datums are being emitted to the same metric stream under different units. The default is to use all matric datums in the stream, regardless of unit, which is recommended in nearly all cases. CloudWatch does not honor this property for graphs. Default: - All metric datums in the given metric stream
        :param visible: Whether this metric should be visible in dashboard graphs. Setting this to false is useful when you want to hide raw metrics that are used in math expressions, and show only the expression results. Default: true

        :default: - sum over 60 seconds

        :stability: experimental
        '''
        options = _aws_cdk_aws_cloudwatch_ceddda9d.MetricOptions(
            account=account,
            color=color,
            dimensions_map=dimensions_map,
            id=id,
            label=label,
            period=period,
            region=region,
            stack_account=stack_account,
            stack_region=stack_region,
            statistic=statistic,
            unit=unit,
            visible=visible,
        )

        return typing.cast("_aws_cdk_aws_cloudwatch_ceddda9d.Metric", jsii.invoke(self, "metricIngressRequestCount", [options]))

    @jsii.member(jsii_name="metricIngressResponseTime")
    def metric_ingress_response_time(
        self,
        *,
        account: typing.Optional[builtins.str] = None,
        color: typing.Optional[builtins.str] = None,
        dimensions_map: typing.Optional[typing.Mapping[builtins.str, builtins.str]] = None,
        id: typing.Optional[builtins.str] = None,
        label: typing.Optional[builtins.str] = None,
        period: typing.Optional["_aws_cdk_ceddda9d.Duration"] = None,
        region: typing.Optional[builtins.str] = None,
        stack_account: typing.Optional[builtins.str] = None,
        stack_region: typing.Optional[builtins.str] = None,
        statistic: typing.Optional[builtins.str] = None,
        unit: typing.Optional["_aws_cdk_aws_cloudwatch_ceddda9d.Unit"] = None,
        visible: typing.Optional[builtins.bool] = None,
    ) -> "_aws_cdk_aws_cloudwatch_ceddda9d.Metric":
        '''(experimental) Returns Metric for Ingress response time.

        :param account: Account which this metric comes from. Default: - Deployment account.
        :param color: The hex color code, prefixed with '#' (e.g. '#00ff00'), to use when this metric is rendered on a graph. The ``Color`` class has a set of standard colors that can be used here. Default: - Automatic color
        :param dimensions_map: Dimensions of the metric. Default: - No dimensions.
        :param id: Unique identifier for this metric when used in dashboard widgets. The id can be used as a variable to represent this metric in math expressions. Valid characters are letters, numbers, and underscore. The first character must be a lowercase letter. Default: - No ID
        :param label: Label for this metric when added to a Graph in a Dashboard. You can use `dynamic labels <https://docs.aws.amazon.com/AmazonCloudWatch/latest/monitoring/graph-dynamic-labels.html>`_ to show summary information about the entire displayed time series in the legend. For example, if you use:: [max: ${MAX}] MyMetric As the metric label, the maximum value in the visible range will be shown next to the time series name in the graph's legend. Default: - No label
        :param period: The period over which the specified statistic is applied. Default: Duration.minutes(5)
        :param region: Region which this metric comes from. Default: - Deployment region.
        :param stack_account: Account of the stack this metric is attached to. Default: - Deployment account.
        :param stack_region: Region of the stack this metric is attached to. Default: - Deployment region.
        :param statistic: What function to use for aggregating. Use the ``aws_cloudwatch.Stats`` helper class to construct valid input strings. Can be one of the following: - "Minimum" | "min" - "Maximum" | "max" - "Average" | "avg" - "Sum" | "sum" - "SampleCount | "n" - "pNN.NN" - "tmNN.NN" | "tm(NN.NN%:NN.NN%)" - "iqm" - "wmNN.NN" | "wm(NN.NN%:NN.NN%)" - "tcNN.NN" | "tc(NN.NN%:NN.NN%)" - "tsNN.NN" | "ts(NN.NN%:NN.NN%)" Default: Average
        :param unit: Unit used to filter the metric stream. Only refer to datums emitted to the metric stream with the given unit and ignore all others. Only useful when datums are being emitted to the same metric stream under different units. The default is to use all matric datums in the stream, regardless of unit, which is recommended in nearly all cases. CloudWatch does not honor this property for graphs. Default: - All metric datums in the given metric stream
        :param visible: Whether this metric should be visible in dashboard graphs. Setting this to false is useful when you want to hide raw metrics that are used in math expressions, and show only the expression results. Default: true

        :default: - average over 60 seconds

        :stability: experimental
        '''
        options = _aws_cdk_aws_cloudwatch_ceddda9d.MetricOptions(
            account=account,
            color=color,
            dimensions_map=dimensions_map,
            id=id,
            label=label,
            period=period,
            region=region,
            stack_account=stack_account,
            stack_region=stack_region,
            statistic=statistic,
            unit=unit,
            visible=visible,
        )

        return typing.cast("_aws_cdk_aws_cloudwatch_ceddda9d.Metric", jsii.invoke(self, "metricIngressResponseTime", [options]))

    @jsii.python.classproperty
    @jsii.member(jsii_name="PROPERTY_INJECTION_ID")
    def PROPERTY_INJECTION_ID(cls) -> builtins.str:
        '''(experimental) Uniquely identifies this class.

        :stability: experimental
        '''
        return typing.cast(builtins.str, jsii.sget(cls, "PROPERTY_INJECTION_ID"))

    @builtins.property
    @jsii.member(jsii_name="channelArn")
    def channel_arn(self) -> builtins.str:
        '''(experimental) The Amazon Resource Name (ARN) associated with the resource.

        :stability: experimental
        '''
        return typing.cast(builtins.str, jsii.get(self, "channelArn"))

    @builtins.property
    @jsii.member(jsii_name="channelGroupName")
    def channel_group_name(self) -> builtins.str:
        '''(experimental) The name that describes the channel group.

        The name is the primary identifier for the channel group.

        :stability: experimental
        '''
        return typing.cast(builtins.str, jsii.get(self, "channelGroupName"))

    @builtins.property
    @jsii.member(jsii_name="channelName")
    def channel_name(self) -> builtins.str:
        '''(experimental) The name that describes the channel.

        The name is the primary identifier for the channel.

        :stability: experimental
        '''
        return typing.cast(builtins.str, jsii.get(self, "channelName"))

    @builtins.property
    @jsii.member(jsii_name="channelRef")
    def channel_ref(
        self,
    ) -> "_aws_cdk_interfaces_aws_mediapackagev2_ceddda9d.ChannelReference":
        '''(experimental) A reference to this Channel resource.

        :stability: experimental
        '''
        return typing.cast("_aws_cdk_interfaces_aws_mediapackagev2_ceddda9d.ChannelReference", jsii.get(self, "channelRef"))

    @builtins.property
    @jsii.member(jsii_name="grants")
    def grants(self) -> "ChannelGrants":
        '''(experimental) Collection of grant methods for this channel.

        :stability: experimental
        '''
        return typing.cast("ChannelGrants", jsii.get(self, "grants"))

    @builtins.property
    @jsii.member(jsii_name="ingestEndpointUrls")
    def ingest_endpoint_urls(self) -> typing.List[builtins.str]:
        '''(experimental) The list of ingest endpoints.

        :stability: experimental
        '''
        return typing.cast(typing.List[builtins.str], jsii.get(self, "ingestEndpointUrls"))

    @builtins.property
    @jsii.member(jsii_name="channelGroup")
    def channel_group(self) -> typing.Optional["IChannelGroup"]:
        '''(experimental) The channel group this channel belongs to.

        Only available when the channel was created in the same stack.
        Undefined for imported channels.

        :stability: experimental
        '''
        return typing.cast(typing.Optional["IChannelGroup"], jsii.get(self, "channelGroup"))

    @builtins.property
    @jsii.member(jsii_name="createdAt")
    def created_at(self) -> typing.Optional[builtins.str]:
        '''(experimental) The date and time the channel was created.

        :stability: experimental
        '''
        return typing.cast(typing.Optional[builtins.str], jsii.get(self, "createdAt"))

    @builtins.property
    @jsii.member(jsii_name="modifiedAt")
    def modified_at(self) -> typing.Optional[builtins.str]:
        '''(experimental) The date and time the channel was modified.

        :stability: experimental
        '''
        return typing.cast(typing.Optional[builtins.str], jsii.get(self, "modifiedAt"))

    @builtins.property
    @jsii.member(jsii_name="autoCreatePolicy")
    def _auto_create_policy(self) -> builtins.bool:
        '''(experimental) Indicates if a channel resource policy should automatically created upon the first call to ``addToResourcePolicy``.

        :stability: experimental
        '''
        return typing.cast(builtins.bool, jsii.get(self, "autoCreatePolicy"))

    @_auto_create_policy.setter
    def _auto_create_policy(self, value: builtins.bool) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__782a319e3ac45be18df6931193de7bfc51750ef7011325bef5945849b3579765)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "autoCreatePolicy", value) # pyright: ignore[reportArgumentType]

    @builtins.property
    @jsii.member(jsii_name="policy")
    def policy(self) -> typing.Optional["ChannelPolicy"]:
        '''(experimental) The resource policy associated with this channel.

        If ``autoCreatePolicy`` is true, a ``ChannelPolicy`` will be created upon the
        first call to addToResourcePolicy(s).

        :stability: experimental
        '''
        return typing.cast(typing.Optional["ChannelPolicy"], jsii.get(self, "policy"))

    @policy.setter
    def policy(self, value: typing.Optional["ChannelPolicy"]) -> None:
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__df2dd2cf51203a9e93bdc5f272a1b441505f2ed355507111239ce162d539b551)
            check_type(argname="argument value", value=value, expected_type=type_hints["value"])
        jsii.set(self, "policy", value) # pyright: ignore[reportArgumentType]


@jsii.implements(IChannelGroup)
class ChannelGroup(
    _aws_cdk_ceddda9d.Resource,
    metaclass=jsii.JSIIMeta,
    jsii_type="@aws-cdk/aws-mediapackagev2-alpha.ChannelGroup",
):
    '''(experimental) Defines an AWS Elemental MediaPackage V2 Channel Group.

    :stability: experimental
    :exampleMetadata: infused

    Example::

        # stack: Stack
        
        
        # Create a channel group
        group = ChannelGroup(stack, "MyChannelGroup",
            channel_group_name="my-channel-group"
        )
        
        # Add a channel using the factory method
        channel = group.add_channel("MyChannel",
            channel_name="my-channel",
            input=InputConfiguration.cmaf()
        )
        
        # Add an origin endpoint using the factory method
        endpoint = channel.add_origin_endpoint("MyEndpoint",
            origin_endpoint_name="my-endpoint",
            segment=Segment.cmaf(),
            manifests=[Manifest.hls(manifest_name="index")]
        )
    '''

    def __init__(
        self,
        scope: "_constructs_77d1e7e8.Construct",
        id: builtins.str,
        *,
        channel_group_name: typing.Optional[builtins.str] = None,
        description: typing.Optional[builtins.str] = None,
        removal_policy: typing.Optional["_aws_cdk_ceddda9d.RemovalPolicy"] = None,
        tags: typing.Optional[typing.Mapping[builtins.str, builtins.str]] = None,
    ) -> None:
        '''
        :param scope: -
        :param id: -
        :param channel_group_name: (experimental) The name that describes the channel group. The name is the primary identifier for the channel group, and must be unique for your account in the AWS Region. Default: autogenerated
        :param description: (experimental) The description for your channel group. Default: - no description
        :param removal_policy: (experimental) Policy to apply when the channel group is removed from the stack. Even though MediaPackage ChannelGroups, Channels and OriginEndpoints are technically stateful, their contents are transient and it is common to add and remove these while rearchitecting your application. The default is therefore ``DESTROY``. Change it to ``RETAIN`` if the content (in a lookback window) are so valuable that accidentally losing it would be unacceptable. Default: RemovalPolicy.DESTROY
        :param tags: (experimental) Tags to add to the Channel Group. Default: - No tagging

        :stability: experimental
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__19e9d2bb024b9ab11829e175ffc5b47fd6d7bab91a3d0e7287ef19e92182afc5)
            check_type(argname="argument scope", value=scope, expected_type=type_hints["scope"])
            check_type(argname="argument id", value=id, expected_type=type_hints["id"])
        props = ChannelGroupProps(
            channel_group_name=channel_group_name,
            description=description,
            removal_policy=removal_policy,
            tags=tags,
        )

        jsii.create(self.__class__, self, [scope, id, props])

    @jsii.member(jsii_name="fromChannelGroupAttributes")
    @builtins.classmethod
    def from_channel_group_attributes(
        cls,
        scope: "_constructs_77d1e7e8.Construct",
        id: builtins.str,
        *,
        channel_group_name: builtins.str,
        egress_domain: typing.Optional[builtins.str] = None,
    ) -> "IChannelGroup":
        '''(experimental) Creates a Channel Group construct that represents an external (imported) Channel Group.

        :param scope: -
        :param id: -
        :param channel_group_name: (experimental) Channel Group Name.
        :param egress_domain: (experimental) The egress domain where packaged content is available. Use this as the origin domain when configuring a CDN such as Amazon CloudFront. Default: - not available on imported channel groups

        :stability: experimental
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__9eb3995d0248aa58244f93bbd57aac471311799bee6f81632c351bf5e5d7766c)
            check_type(argname="argument scope", value=scope, expected_type=type_hints["scope"])
            check_type(argname="argument id", value=id, expected_type=type_hints["id"])
        attrs = ChannelGroupAttributes(
            channel_group_name=channel_group_name, egress_domain=egress_domain
        )

        return typing.cast("IChannelGroup", jsii.sinvoke(cls, "fromChannelGroupAttributes", [scope, id, attrs]))

    @jsii.member(jsii_name="addChannel")
    def add_channel(
        self,
        id: builtins.str,
        *,
        channel_name: typing.Optional[builtins.str] = None,
        description: typing.Optional[builtins.str] = None,
        input: typing.Optional["InputConfiguration"] = None,
        removal_policy: typing.Optional["_aws_cdk_ceddda9d.RemovalPolicy"] = None,
        tags: typing.Optional[typing.Mapping[builtins.str, builtins.str]] = None,
    ) -> "Channel":
        '''(experimental) Add Channel for this Channel Group.

        :param id: -
        :param channel_name: (experimental) The name that describes the channel. The name is the primary identifier for the channel, and must be unique for your account in the AWS Region and channel group. Default: autogenerated
        :param description: (experimental) Enter any descriptive text that helps you to identify the channel. Default: no description
        :param input: (experimental) Input configuration for the channel. Use InputConfiguration.hls() or InputConfiguration.cmaf() to create the configuration. Default: InputConfiguration.cmaf()
        :param removal_policy: (experimental) Policy to apply when the channel is removed from the stack. Even though MediaPackage ChannelGroups, Channels and OriginEndpoints are technically stateful, their contents are transient and it is common to add and remove these while rearchitecting your application. The default is therefore ``DESTROY``. Change it to ``RETAIN`` if the content (in a lookback window) are so valuable that accidentally losing it would be unacceptable. Default: RemovalPolicy.DESTROY
        :param tags: (experimental) Tags to add to the Channel. Default: No tagging

        :stability: experimental
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__a557ba064f0ffc77f9a13ae4880a2072cdd2669de085450567023de420714de5)
            check_type(argname="argument id", value=id, expected_type=type_hints["id"])
        options = ChannelOptions(
            channel_name=channel_name,
            description=description,
            input=input,
            removal_policy=removal_policy,
            tags=tags,
        )

        return typing.cast("Channel", jsii.invoke(self, "addChannel", [id, options]))

    @jsii.member(jsii_name="metric")
    def metric(
        self,
        metric_name: builtins.str,
        *,
        account: typing.Optional[builtins.str] = None,
        color: typing.Optional[builtins.str] = None,
        dimensions_map: typing.Optional[typing.Mapping[builtins.str, builtins.str]] = None,
        id: typing.Optional[builtins.str] = None,
        label: typing.Optional[builtins.str] = None,
        period: typing.Optional["_aws_cdk_ceddda9d.Duration"] = None,
        region: typing.Optional[builtins.str] = None,
        stack_account: typing.Optional[builtins.str] = None,
        stack_region: typing.Optional[builtins.str] = None,
        statistic: typing.Optional[builtins.str] = None,
        unit: typing.Optional["_aws_cdk_aws_cloudwatch_ceddda9d.Unit"] = None,
        visible: typing.Optional[builtins.bool] = None,
    ) -> "_aws_cdk_aws_cloudwatch_ceddda9d.Metric":
        '''(experimental) Create a CloudWatch metric.

        :param metric_name: name of the metric.
        :param account: Account which this metric comes from. Default: - Deployment account.
        :param color: The hex color code, prefixed with '#' (e.g. '#00ff00'), to use when this metric is rendered on a graph. The ``Color`` class has a set of standard colors that can be used here. Default: - Automatic color
        :param dimensions_map: Dimensions of the metric. Default: - No dimensions.
        :param id: Unique identifier for this metric when used in dashboard widgets. The id can be used as a variable to represent this metric in math expressions. Valid characters are letters, numbers, and underscore. The first character must be a lowercase letter. Default: - No ID
        :param label: Label for this metric when added to a Graph in a Dashboard. You can use `dynamic labels <https://docs.aws.amazon.com/AmazonCloudWatch/latest/monitoring/graph-dynamic-labels.html>`_ to show summary information about the entire displayed time series in the legend. For example, if you use:: [max: ${MAX}] MyMetric As the metric label, the maximum value in the visible range will be shown next to the time series name in the graph's legend. Default: - No label
        :param period: The period over which the specified statistic is applied. Default: Duration.minutes(5)
        :param region: Region which this metric comes from. Default: - Deployment region.
        :param stack_account: Account of the stack this metric is attached to. Default: - Deployment account.
        :param stack_region: Region of the stack this metric is attached to. Default: - Deployment region.
        :param statistic: What function to use for aggregating. Use the ``aws_cloudwatch.Stats`` helper class to construct valid input strings. Can be one of the following: - "Minimum" | "min" - "Maximum" | "max" - "Average" | "avg" - "Sum" | "sum" - "SampleCount | "n" - "pNN.NN" - "tmNN.NN" | "tm(NN.NN%:NN.NN%)" - "iqm" - "wmNN.NN" | "wm(NN.NN%:NN.NN%)" - "tcNN.NN" | "tc(NN.NN%:NN.NN%)" - "tsNN.NN" | "ts(NN.NN%:NN.NN%)" Default: Average
        :param unit: Unit used to filter the metric stream. Only refer to datums emitted to the metric stream with the given unit and ignore all others. Only useful when datums are being emitted to the same metric stream under different units. The default is to use all matric datums in the stream, regardless of unit, which is recommended in nearly all cases. CloudWatch does not honor this property for graphs. Default: - All metric datums in the given metric stream
        :param visible: Whether this metric should be visible in dashboard graphs. Setting this to false is useful when you want to hide raw metrics that are used in math expressions, and show only the expression results. Default: true

        :stability: experimental
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__97d61bbd3e10d180ca57698ab342cad843bea1e5bf76f29d82342460e4da1aab)
            check_type(argname="argument metric_name", value=metric_name, expected_type=type_hints["metric_name"])
        props = _aws_cdk_aws_cloudwatch_ceddda9d.MetricOptions(
            account=account,
            color=color,
            dimensions_map=dimensions_map,
            id=id,
            label=label,
            period=period,
            region=region,
            stack_account=stack_account,
            stack_region=stack_region,
            statistic=statistic,
            unit=unit,
            visible=visible,
        )

        return typing.cast("_aws_cdk_aws_cloudwatch_ceddda9d.Metric", jsii.invoke(self, "metric", [metric_name, props]))

    @jsii.member(jsii_name="metricEgressBytes")
    def metric_egress_bytes(
        self,
        *,
        account: typing.Optional[builtins.str] = None,
        color: typing.Optional[builtins.str] = None,
        dimensions_map: typing.Optional[typing.Mapping[builtins.str, builtins.str]] = None,
        id: typing.Optional[builtins.str] = None,
        label: typing.Optional[builtins.str] = None,
        period: typing.Optional["_aws_cdk_ceddda9d.Duration"] = None,
        region: typing.Optional[builtins.str] = None,
        stack_account: typing.Optional[builtins.str] = None,
        stack_region: typing.Optional[builtins.str] = None,
        statistic: typing.Optional[builtins.str] = None,
        unit: typing.Optional["_aws_cdk_aws_cloudwatch_ceddda9d.Unit"] = None,
        visible: typing.Optional[builtins.bool] = None,
    ) -> "_aws_cdk_aws_cloudwatch_ceddda9d.Metric":
        '''(experimental) Returns Metric for Egress Bytes.

        :param account: Account which this metric comes from. Default: - Deployment account.
        :param color: The hex color code, prefixed with '#' (e.g. '#00ff00'), to use when this metric is rendered on a graph. The ``Color`` class has a set of standard colors that can be used here. Default: - Automatic color
        :param dimensions_map: Dimensions of the metric. Default: - No dimensions.
        :param id: Unique identifier for this metric when used in dashboard widgets. The id can be used as a variable to represent this metric in math expressions. Valid characters are letters, numbers, and underscore. The first character must be a lowercase letter. Default: - No ID
        :param label: Label for this metric when added to a Graph in a Dashboard. You can use `dynamic labels <https://docs.aws.amazon.com/AmazonCloudWatch/latest/monitoring/graph-dynamic-labels.html>`_ to show summary information about the entire displayed time series in the legend. For example, if you use:: [max: ${MAX}] MyMetric As the metric label, the maximum value in the visible range will be shown next to the time series name in the graph's legend. Default: - No label
        :param period: The period over which the specified statistic is applied. Default: Duration.minutes(5)
        :param region: Region which this metric comes from. Default: - Deployment region.
        :param stack_account: Account of the stack this metric is attached to. Default: - Deployment account.
        :param stack_region: Region of the stack this metric is attached to. Default: - Deployment region.
        :param statistic: What function to use for aggregating. Use the ``aws_cloudwatch.Stats`` helper class to construct valid input strings. Can be one of the following: - "Minimum" | "min" - "Maximum" | "max" - "Average" | "avg" - "Sum" | "sum" - "SampleCount | "n" - "pNN.NN" - "tmNN.NN" | "tm(NN.NN%:NN.NN%)" - "iqm" - "wmNN.NN" | "wm(NN.NN%:NN.NN%)" - "tcNN.NN" | "tc(NN.NN%:NN.NN%)" - "tsNN.NN" | "ts(NN.NN%:NN.NN%)" Default: Average
        :param unit: Unit used to filter the metric stream. Only refer to datums emitted to the metric stream with the given unit and ignore all others. Only useful when datums are being emitted to the same metric stream under different units. The default is to use all matric datums in the stream, regardless of unit, which is recommended in nearly all cases. CloudWatch does not honor this property for graphs. Default: - All metric datums in the given metric stream
        :param visible: Whether this metric should be visible in dashboard graphs. Setting this to false is useful when you want to hide raw metrics that are used in math expressions, and show only the expression results. Default: true

        :default: - sum over 60 seconds

        :stability: experimental
        '''
        props = _aws_cdk_aws_cloudwatch_ceddda9d.MetricOptions(
            account=account,
            color=color,
            dimensions_map=dimensions_map,
            id=id,
            label=label,
            period=period,
            region=region,
            stack_account=stack_account,
            stack_region=stack_region,
            statistic=statistic,
            unit=unit,
            visible=visible,
        )

        return typing.cast("_aws_cdk_aws_cloudwatch_ceddda9d.Metric", jsii.invoke(self, "metricEgressBytes", [props]))

    @jsii.member(jsii_name="metricEgressRequestCount")
    def metric_egress_request_count(
        self,
        *,
        account: typing.Optional[builtins.str] = None,
        color: typing.Optional[builtins.str] = None,
        dimensions_map: typing.Optional[typing.Mapping[builtins.str, builtins.str]] = None,
        id: typing.Optional[builtins.str] = None,
        label: typing.Optional[builtins.str] = None,
        period: typing.Optional["_aws_cdk_ceddda9d.Duration"] = None,
        region: typing.Optional[builtins.str] = None,
        stack_account: typing.Optional[builtins.str] = None,
        stack_region: typing.Optional[builtins.str] = None,
        statistic: typing.Optional[builtins.str] = None,
        unit: typing.Optional["_aws_cdk_aws_cloudwatch_ceddda9d.Unit"] = None,
        visible: typing.Optional[builtins.bool] = None,
    ) -> "_aws_cdk_aws_cloudwatch_ceddda9d.Metric":
        '''(experimental) Returns Metric for Egress Request Count.

        :param account: Account which this metric comes from. Default: - Deployment account.
        :param color: The hex color code, prefixed with '#' (e.g. '#00ff00'), to use when this metric is rendered on a graph. The ``Color`` class has a set of standard colors that can be used here. Default: - Automatic color
        :param dimensions_map: Dimensions of the metric. Default: - No dimensions.
        :param id: Unique identifier for this metric when used in dashboard widgets. The id can be used as a variable to represent this metric in math expressions. Valid characters are letters, numbers, and underscore. The first character must be a lowercase letter. Default: - No ID
        :param label: Label for this metric when added to a Graph in a Dashboard. You can use `dynamic labels <https://docs.aws.amazon.com/AmazonCloudWatch/latest/monitoring/graph-dynamic-labels.html>`_ to show summary information about the entire displayed time series in the legend. For example, if you use:: [max: ${MAX}] MyMetric As the metric label, the maximum value in the visible range will be shown next to the time series name in the graph's legend. Default: - No label
        :param period: The period over which the specified statistic is applied. Default: Duration.minutes(5)
        :param region: Region which this metric comes from. Default: - Deployment region.
        :param stack_account: Account of the stack this metric is attached to. Default: - Deployment account.
        :param stack_region: Region of the stack this metric is attached to. Default: - Deployment region.
        :param statistic: What function to use for aggregating. Use the ``aws_cloudwatch.Stats`` helper class to construct valid input strings. Can be one of the following: - "Minimum" | "min" - "Maximum" | "max" - "Average" | "avg" - "Sum" | "sum" - "SampleCount | "n" - "pNN.NN" - "tmNN.NN" | "tm(NN.NN%:NN.NN%)" - "iqm" - "wmNN.NN" | "wm(NN.NN%:NN.NN%)" - "tcNN.NN" | "tc(NN.NN%:NN.NN%)" - "tsNN.NN" | "ts(NN.NN%:NN.NN%)" Default: Average
        :param unit: Unit used to filter the metric stream. Only refer to datums emitted to the metric stream with the given unit and ignore all others. Only useful when datums are being emitted to the same metric stream under different units. The default is to use all matric datums in the stream, regardless of unit, which is recommended in nearly all cases. CloudWatch does not honor this property for graphs. Default: - All metric datums in the given metric stream
        :param visible: Whether this metric should be visible in dashboard graphs. Setting this to false is useful when you want to hide raw metrics that are used in math expressions, and show only the expression results. Default: true

        :default: - sum over 60 seconds

        :stability: experimental
        '''
        props = _aws_cdk_aws_cloudwatch_ceddda9d.MetricOptions(
            account=account,
            color=color,
            dimensions_map=dimensions_map,
            id=id,
            label=label,
            period=period,
            region=region,
            stack_account=stack_account,
            stack_region=stack_region,
            statistic=statistic,
            unit=unit,
            visible=visible,
        )

        return typing.cast("_aws_cdk_aws_cloudwatch_ceddda9d.Metric", jsii.invoke(self, "metricEgressRequestCount", [props]))

    @jsii.member(jsii_name="metricEgressResponseTime")
    def metric_egress_response_time(
        self,
        *,
        account: typing.Optional[builtins.str] = None,
        color: typing.Optional[builtins.str] = None,
        dimensions_map: typing.Optional[typing.Mapping[builtins.str, builtins.str]] = None,
        id: typing.Optional[builtins.str] = None,
        label: typing.Optional[builtins.str] = None,
        period: typing.Optional["_aws_cdk_ceddda9d.Duration"] = None,
        region: typing.Optional[builtins.str] = None,
        stack_account: typing.Optional[builtins.str] = None,
        stack_region: typing.Optional[builtins.str] = None,
        statistic: typing.Optional[builtins.str] = None,
        unit: typing.Optional["_aws_cdk_aws_cloudwatch_ceddda9d.Unit"] = None,
        visible: typing.Optional[builtins.bool] = None,
    ) -> "_aws_cdk_aws_cloudwatch_ceddda9d.Metric":
        '''(experimental) Returns Metric for Egress Response time.

        :param account: Account which this metric comes from. Default: - Deployment account.
        :param color: The hex color code, prefixed with '#' (e.g. '#00ff00'), to use when this metric is rendered on a graph. The ``Color`` class has a set of standard colors that can be used here. Default: - Automatic color
        :param dimensions_map: Dimensions of the metric. Default: - No dimensions.
        :param id: Unique identifier for this metric when used in dashboard widgets. The id can be used as a variable to represent this metric in math expressions. Valid characters are letters, numbers, and underscore. The first character must be a lowercase letter. Default: - No ID
        :param label: Label for this metric when added to a Graph in a Dashboard. You can use `dynamic labels <https://docs.aws.amazon.com/AmazonCloudWatch/latest/monitoring/graph-dynamic-labels.html>`_ to show summary information about the entire displayed time series in the legend. For example, if you use:: [max: ${MAX}] MyMetric As the metric label, the maximum value in the visible range will be shown next to the time series name in the graph's legend. Default: - No label
        :param period: The period over which the specified statistic is applied. Default: Duration.minutes(5)
        :param region: Region which this metric comes from. Default: - Deployment region.
        :param stack_account: Account of the stack this metric is attached to. Default: - Deployment account.
        :param stack_region: Region of the stack this metric is attached to. Default: - Deployment region.
        :param statistic: What function to use for aggregating. Use the ``aws_cloudwatch.Stats`` helper class to construct valid input strings. Can be one of the following: - "Minimum" | "min" - "Maximum" | "max" - "Average" | "avg" - "Sum" | "sum" - "SampleCount | "n" - "pNN.NN" - "tmNN.NN" | "tm(NN.NN%:NN.NN%)" - "iqm" - "wmNN.NN" | "wm(NN.NN%:NN.NN%)" - "tcNN.NN" | "tc(NN.NN%:NN.NN%)" - "tsNN.NN" | "ts(NN.NN%:NN.NN%)" Default: Average
        :param unit: Unit used to filter the metric stream. Only refer to datums emitted to the metric stream with the given unit and ignore all others. Only useful when datums are being emitted to the same metric stream under different units. The default is to use all matric datums in the stream, regardless of unit, which is recommended in nearly all cases. CloudWatch does not honor this property for graphs. Default: - All metric datums in the given metric stream
        :param visible: Whether this metric should be visible in dashboard graphs. Setting this to false is useful when you want to hide raw metrics that are used in math expressions, and show only the expression results. Default: true

        :default: - average over 60 seconds

        :stability: experimental
        '''
        props = _aws_cdk_aws_cloudwatch_ceddda9d.MetricOptions(
            account=account,
            color=color,
            dimensions_map=dimensions_map,
            id=id,
            label=label,
            period=period,
            region=region,
            stack_account=stack_account,
            stack_region=stack_region,
            statistic=statistic,
            unit=unit,
            visible=visible,
        )

        return typing.cast("_aws_cdk_aws_cloudwatch_ceddda9d.Metric", jsii.invoke(self, "metricEgressResponseTime", [props]))

    @jsii.member(jsii_name="metricIngressBytes")
    def metric_ingress_bytes(
        self,
        *,
        account: typing.Optional[builtins.str] = None,
        color: typing.Optional[builtins.str] = None,
        dimensions_map: typing.Optional[typing.Mapping[builtins.str, builtins.str]] = None,
        id: typing.Optional[builtins.str] = None,
        label: typing.Optional[builtins.str] = None,
        period: typing.Optional["_aws_cdk_ceddda9d.Duration"] = None,
        region: typing.Optional[builtins.str] = None,
        stack_account: typing.Optional[builtins.str] = None,
        stack_region: typing.Optional[builtins.str] = None,
        statistic: typing.Optional[builtins.str] = None,
        unit: typing.Optional["_aws_cdk_aws_cloudwatch_ceddda9d.Unit"] = None,
        visible: typing.Optional[builtins.bool] = None,
    ) -> "_aws_cdk_aws_cloudwatch_ceddda9d.Metric":
        '''(experimental) Returns Metric for Ingress Bytes.

        :param account: Account which this metric comes from. Default: - Deployment account.
        :param color: The hex color code, prefixed with '#' (e.g. '#00ff00'), to use when this metric is rendered on a graph. The ``Color`` class has a set of standard colors that can be used here. Default: - Automatic color
        :param dimensions_map: Dimensions of the metric. Default: - No dimensions.
        :param id: Unique identifier for this metric when used in dashboard widgets. The id can be used as a variable to represent this metric in math expressions. Valid characters are letters, numbers, and underscore. The first character must be a lowercase letter. Default: - No ID
        :param label: Label for this metric when added to a Graph in a Dashboard. You can use `dynamic labels <https://docs.aws.amazon.com/AmazonCloudWatch/latest/monitoring/graph-dynamic-labels.html>`_ to show summary information about the entire displayed time series in the legend. For example, if you use:: [max: ${MAX}] MyMetric As the metric label, the maximum value in the visible range will be shown next to the time series name in the graph's legend. Default: - No label
        :param period: The period over which the specified statistic is applied. Default: Duration.minutes(5)
        :param region: Region which this metric comes from. Default: - Deployment region.
        :param stack_account: Account of the stack this metric is attached to. Default: - Deployment account.
        :param stack_region: Region of the stack this metric is attached to. Default: - Deployment region.
        :param statistic: What function to use for aggregating. Use the ``aws_cloudwatch.Stats`` helper class to construct valid input strings. Can be one of the following: - "Minimum" | "min" - "Maximum" | "max" - "Average" | "avg" - "Sum" | "sum" - "SampleCount | "n" - "pNN.NN" - "tmNN.NN" | "tm(NN.NN%:NN.NN%)" - "iqm" - "wmNN.NN" | "wm(NN.NN%:NN.NN%)" - "tcNN.NN" | "tc(NN.NN%:NN.NN%)" - "tsNN.NN" | "ts(NN.NN%:NN.NN%)" Default: Average
        :param unit: Unit used to filter the metric stream. Only refer to datums emitted to the metric stream with the given unit and ignore all others. Only useful when datums are being emitted to the same metric stream under different units. The default is to use all matric datums in the stream, regardless of unit, which is recommended in nearly all cases. CloudWatch does not honor this property for graphs. Default: - All metric datums in the given metric stream
        :param visible: Whether this metric should be visible in dashboard graphs. Setting this to false is useful when you want to hide raw metrics that are used in math expressions, and show only the expression results. Default: true

        :default: - sum over 60 seconds

        :stability: experimental
        '''
        props = _aws_cdk_aws_cloudwatch_ceddda9d.MetricOptions(
            account=account,
            color=color,
            dimensions_map=dimensions_map,
            id=id,
            label=label,
            period=period,
            region=region,
            stack_account=stack_account,
            stack_region=stack_region,
            statistic=statistic,
            unit=unit,
            visible=visible,
        )

        return typing.cast("_aws_cdk_aws_cloudwatch_ceddda9d.Metric", jsii.invoke(self, "metricIngressBytes", [props]))

    @jsii.member(jsii_name="metricIngressRequestCount")
    def metric_ingress_request_count(
        self,
        *,
        account: typing.Optional[builtins.str] = None,
        color: typing.Optional[builtins.str] = None,
        dimensions_map: typing.Optional[typing.Mapping[builtins.str, builtins.str]] = None,
        id: typing.Optional[builtins.str] = None,
        label: typing.Optional[builtins.str] = None,
        period: typing.Optional["_aws_cdk_ceddda9d.Duration"] = None,
        region: typing.Optional[builtins.str] = None,
        stack_account: typing.Optional[builtins.str] = None,
        stack_region: typing.Optional[builtins.str] = None,
        statistic: typing.Optional[builtins.str] = None,
        unit: typing.Optional["_aws_cdk_aws_cloudwatch_ceddda9d.Unit"] = None,
        visible: typing.Optional[builtins.bool] = None,
    ) -> "_aws_cdk_aws_cloudwatch_ceddda9d.Metric":
        '''(experimental) Returns Metric for Ingress Request Count.

        :param account: Account which this metric comes from. Default: - Deployment account.
        :param color: The hex color code, prefixed with '#' (e.g. '#00ff00'), to use when this metric is rendered on a graph. The ``Color`` class has a set of standard colors that can be used here. Default: - Automatic color
        :param dimensions_map: Dimensions of the metric. Default: - No dimensions.
        :param id: Unique identifier for this metric when used in dashboard widgets. The id can be used as a variable to represent this metric in math expressions. Valid characters are letters, numbers, and underscore. The first character must be a lowercase letter. Default: - No ID
        :param label: Label for this metric when added to a Graph in a Dashboard. You can use `dynamic labels <https://docs.aws.amazon.com/AmazonCloudWatch/latest/monitoring/graph-dynamic-labels.html>`_ to show summary information about the entire displayed time series in the legend. For example, if you use:: [max: ${MAX}] MyMetric As the metric label, the maximum value in the visible range will be shown next to the time series name in the graph's legend. Default: - No label
        :param period: The period over which the specified statistic is applied. Default: Duration.minutes(5)
        :param region: Region which this metric comes from. Default: - Deployment region.
        :param stack_account: Account of the stack this metric is attached to. Default: - Deployment account.
        :param stack_region: Region of the stack this metric is attached to. Default: - Deployment region.
        :param statistic: What function to use for aggregating. Use the ``aws_cloudwatch.Stats`` helper class to construct valid input strings. Can be one of the following: - "Minimum" | "min" - "Maximum" | "max" - "Average" | "avg" - "Sum" | "sum" - "SampleCount | "n" - "pNN.NN" - "tmNN.NN" | "tm(NN.NN%:NN.NN%)" - "iqm" - "wmNN.NN" | "wm(NN.NN%:NN.NN%)" - "tcNN.NN" | "tc(NN.NN%:NN.NN%)" - "tsNN.NN" | "ts(NN.NN%:NN.NN%)" Default: Average
        :param unit: Unit used to filter the metric stream. Only refer to datums emitted to the metric stream with the given unit and ignore all others. Only useful when datums are being emitted to the same metric stream under different units. The default is to use all matric datums in the stream, regardless of unit, which is recommended in nearly all cases. CloudWatch does not honor this property for graphs. Default: - All metric datums in the given metric stream
        :param visible: Whether this metric should be visible in dashboard graphs. Setting this to false is useful when you want to hide raw metrics that are used in math expressions, and show only the expression results. Default: true

        :default: - sum over 60 seconds

        :stability: experimental
        '''
        props = _aws_cdk_aws_cloudwatch_ceddda9d.MetricOptions(
            account=account,
            color=color,
            dimensions_map=dimensions_map,
            id=id,
            label=label,
            period=period,
            region=region,
            stack_account=stack_account,
            stack_region=stack_region,
            statistic=statistic,
            unit=unit,
            visible=visible,
        )

        return typing.cast("_aws_cdk_aws_cloudwatch_ceddda9d.Metric", jsii.invoke(self, "metricIngressRequestCount", [props]))

    @jsii.member(jsii_name="metricIngressResponseTime")
    def metric_ingress_response_time(
        self,
        *,
        account: typing.Optional[builtins.str] = None,
        color: typing.Optional[builtins.str] = None,
        dimensions_map: typing.Optional[typing.Mapping[builtins.str, builtins.str]] = None,
        id: typing.Optional[builtins.str] = None,
        label: typing.Optional[builtins.str] = None,
        period: typing.Optional["_aws_cdk_ceddda9d.Duration"] = None,
        region: typing.Optional[builtins.str] = None,
        stack_account: typing.Optional[builtins.str] = None,
        stack_region: typing.Optional[builtins.str] = None,
        statistic: typing.Optional[builtins.str] = None,
        unit: typing.Optional["_aws_cdk_aws_cloudwatch_ceddda9d.Unit"] = None,
        visible: typing.Optional[builtins.bool] = None,
    ) -> "_aws_cdk_aws_cloudwatch_ceddda9d.Metric":
        '''(experimental) Returns Metric for Ingress response time.

        :param account: Account which this metric comes from. Default: - Deployment account.
        :param color: The hex color code, prefixed with '#' (e.g. '#00ff00'), to use when this metric is rendered on a graph. The ``Color`` class has a set of standard colors that can be used here. Default: - Automatic color
        :param dimensions_map: Dimensions of the metric. Default: - No dimensions.
        :param id: Unique identifier for this metric when used in dashboard widgets. The id can be used as a variable to represent this metric in math expressions. Valid characters are letters, numbers, and underscore. The first character must be a lowercase letter. Default: - No ID
        :param label: Label for this metric when added to a Graph in a Dashboard. You can use `dynamic labels <https://docs.aws.amazon.com/AmazonCloudWatch/latest/monitoring/graph-dynamic-labels.html>`_ to show summary information about the entire displayed time series in the legend. For example, if you use:: [max: ${MAX}] MyMetric As the metric label, the maximum value in the visible range will be shown next to the time series name in the graph's legend. Default: - No label
        :param period: The period over which the specified statistic is applied. Default: Duration.minutes(5)
        :param region: Region which this metric comes from. Default: - Deployment region.
        :param stack_account: Account of the stack this metric is attached to. Default: - Deployment account.
        :param stack_region: Region of the stack this metric is attached to. Default: - Deployment region.
        :param statistic: What function to use for aggregating. Use the ``aws_cloudwatch.Stats`` helper class to construct valid input strings. Can be one of the following: - "Minimum" | "min" - "Maximum" | "max" - "Average" | "avg" - "Sum" | "sum" - "SampleCount | "n" - "pNN.NN" - "tmNN.NN" | "tm(NN.NN%:NN.NN%)" - "iqm" - "wmNN.NN" | "wm(NN.NN%:NN.NN%)" - "tcNN.NN" | "tc(NN.NN%:NN.NN%)" - "tsNN.NN" | "ts(NN.NN%:NN.NN%)" Default: Average
        :param unit: Unit used to filter the metric stream. Only refer to datums emitted to the metric stream with the given unit and ignore all others. Only useful when datums are being emitted to the same metric stream under different units. The default is to use all matric datums in the stream, regardless of unit, which is recommended in nearly all cases. CloudWatch does not honor this property for graphs. Default: - All metric datums in the given metric stream
        :param visible: Whether this metric should be visible in dashboard graphs. Setting this to false is useful when you want to hide raw metrics that are used in math expressions, and show only the expression results. Default: true

        :default: - average over 60 seconds

        :stability: experimental
        '''
        props = _aws_cdk_aws_cloudwatch_ceddda9d.MetricOptions(
            account=account,
            color=color,
            dimensions_map=dimensions_map,
            id=id,
            label=label,
            period=period,
            region=region,
            stack_account=stack_account,
            stack_region=stack_region,
            statistic=statistic,
            unit=unit,
            visible=visible,
        )

        return typing.cast("_aws_cdk_aws_cloudwatch_ceddda9d.Metric", jsii.invoke(self, "metricIngressResponseTime", [props]))

    @jsii.python.classproperty
    @jsii.member(jsii_name="PROPERTY_INJECTION_ID")
    def PROPERTY_INJECTION_ID(cls) -> builtins.str:
        '''(experimental) Uniquely identifies this class.

        :stability: experimental
        '''
        return typing.cast(builtins.str, jsii.sget(cls, "PROPERTY_INJECTION_ID"))

    @builtins.property
    @jsii.member(jsii_name="channelGroupArn")
    def channel_group_arn(self) -> builtins.str:
        '''(experimental) The Amazon Resource Name (ARN) associated with the resource.

        :stability: experimental
        '''
        return typing.cast(builtins.str, jsii.get(self, "channelGroupArn"))

    @builtins.property
    @jsii.member(jsii_name="channelGroupName")
    def channel_group_name(self) -> builtins.str:
        '''(experimental) The name that describes the channel group.

        The name is the primary identifier for the channel group, and must be unique for your account in the AWS Region.

        :stability: experimental
        '''
        return typing.cast(builtins.str, jsii.get(self, "channelGroupName"))

    @builtins.property
    @jsii.member(jsii_name="channelGroupRef")
    def channel_group_ref(
        self,
    ) -> "_aws_cdk_interfaces_aws_mediapackagev2_ceddda9d.ChannelGroupReference":
        '''(experimental) A reference to this Channel Group resource.

        Required by the auto-generated IChannelGroupRef interface.

        :stability: experimental
        '''
        return typing.cast("_aws_cdk_interfaces_aws_mediapackagev2_ceddda9d.ChannelGroupReference", jsii.get(self, "channelGroupRef"))

    @builtins.property
    @jsii.member(jsii_name="egressDomain")
    def egress_domain(self) -> builtins.str:
        '''(experimental) The egress domain where packaged content is available.

        Use this as the origin domain when configuring a CDN such as Amazon CloudFront.

        :stability: experimental
        '''
        return typing.cast(builtins.str, jsii.get(self, "egressDomain"))

    @builtins.property
    @jsii.member(jsii_name="createdAt")
    def created_at(self) -> typing.Optional[builtins.str]:
        '''(experimental) The date and time the channel group was created.

        :stability: experimental
        '''
        return typing.cast(typing.Optional[builtins.str], jsii.get(self, "createdAt"))

    @builtins.property
    @jsii.member(jsii_name="modifiedAt")
    def modified_at(self) -> typing.Optional[builtins.str]:
        '''(experimental) The date and time the channel group was modified.

        :stability: experimental
        '''
        return typing.cast(typing.Optional[builtins.str], jsii.get(self, "modifiedAt"))


class CmafEncryption(
    EncryptionConfiguration,
    metaclass=jsii.JSIIMeta,
    jsii_type="@aws-cdk/aws-mediapackagev2-alpha.CmafEncryption",
):
    '''(experimental) Encryption configuration for CMAF segments.

    Use ``CmafEncryption.speke()`` to create an instance.

    :stability: experimental
    :exampleMetadata: infused

    Example::

        # channel: Channel
        # speke_role: iam.IRole
        # certificate: certificatemanager.ICertificate
        
        
        OriginEndpoint(self, "Endpoint",
            channel=channel,
            segment=Segment.cmaf(
                encryption=CmafEncryption.speke(
                    method=CmafEncryptionMethod.CBCS,
                    drm_systems=[CmafDrmSystem.FAIRPLAY],
                    resource_id="my-content-id",
                    url="https://example.com/speke",
                    role=speke_role,
                    certificate=certificate
                )
            ),
            manifests=[Manifest.hls(manifest_name="index")]
        )
    '''

    @jsii.member(jsii_name="speke")
    @builtins.classmethod
    def speke(
        cls,
        *,
        drm_systems: typing.Sequence["CmafDrmSystem"],
        method: "CmafEncryptionMethod",
        resource_id: builtins.str,
        role: "_aws_cdk_aws_iam_ceddda9d.IRole",
        url: builtins.str,
        audio_preset: typing.Optional["PresetSpeke20Audio"] = None,
        certificate: typing.Optional["_aws_cdk_aws_certificatemanager_ceddda9d.ICertificate"] = None,
        constant_initialization_vector: typing.Optional[builtins.str] = None,
        exclude_segment_drm_metadata: typing.Optional[builtins.bool] = None,
        key_rotation_interval: typing.Optional["_aws_cdk_ceddda9d.Duration"] = None,
        video_preset: typing.Optional["PresetSpeke20Video"] = None,
    ) -> "CmafEncryption":
        '''(experimental) Create a SPEKE-based encryption configuration for CMAF segments.

        :param drm_systems: (experimental) The DRM systems to use for content protection. CENC supports PlayReady, Widevine, and Irdeto. CBCS supports PlayReady, Widevine, and FairPlay.
        :param method: (experimental) The encryption method to use.
        :param resource_id: (experimental) The unique identifier for the content. The service sends this identifier to the key server to identify the current endpoint. How unique you make this identifier depends on how fine-grained you want access controls to be. The service does not permit you to use the same ID for two simultaneous encryption processes.
        :param role: (experimental) IAM role for accessing the key provider API. This role must have a trust policy that allows MediaPackage to assume the role, and it must have sufficient permissions to access the key retrieval URL.
        :param url: (experimental) URL of the SPEKE key provider.
        :param audio_preset: (experimental) Audio encryption preset. Default: PresetSpeke20Audio.PRESET_AUDIO_1
        :param certificate: (experimental) The ARN of the certificate that you imported to AWS Certificate Manager to add content key encryption to this endpoint. For this feature to work, your DRM key provider must support content key encryption. Default: - no content key encryption
        :param constant_initialization_vector: (experimental) Constant initialization vector (32-character hex string). A 128-bit, 16-byte hex value represented by a 32-character string, used in conjunction with the key for encrypting content. Default: - MediaPackage generates the IV
        :param exclude_segment_drm_metadata: (experimental) When enabled, DRM metadata is excluded from CMAF segments. Default: false
        :param key_rotation_interval: (experimental) Key rotation interval. Default: - no rotation
        :param video_preset: (experimental) Video encryption preset. Default: PresetSpeke20Video.PRESET_VIDEO_1

        :stability: experimental
        '''
        props = CmafSpekeEncryptionProps(
            drm_systems=drm_systems,
            method=method,
            resource_id=resource_id,
            role=role,
            url=url,
            audio_preset=audio_preset,
            certificate=certificate,
            constant_initialization_vector=constant_initialization_vector,
            exclude_segment_drm_metadata=exclude_segment_drm_metadata,
            key_rotation_interval=key_rotation_interval,
            video_preset=video_preset,
        )

        return typing.cast("CmafEncryption", jsii.sinvoke(cls, "speke", [props]))


@jsii.data_type(
    jsii_type="@aws-cdk/aws-mediapackagev2-alpha.CmafSegmentProps",
    jsii_struct_bases=[SegmentPropsBase],
    name_mapping={
        "duration": "duration",
        "include_iframe_only_streams": "includeIframeOnlyStreams",
        "name": "name",
        "encryption": "encryption",
        "scte_filter": "scteFilter",
        "scte_in_segments": "scteInSegments",
    },
)
class CmafSegmentProps(SegmentPropsBase):
    def __init__(
        self,
        *,
        duration: typing.Optional["_aws_cdk_ceddda9d.Duration"] = None,
        include_iframe_only_streams: typing.Optional[builtins.bool] = None,
        name: typing.Optional[builtins.str] = None,
        encryption: typing.Optional["CmafEncryption"] = None,
        scte_filter: typing.Optional[typing.Sequence["ScteMessageType"]] = None,
        scte_in_segments: typing.Optional["ScteInSegments"] = None,
    ) -> None:
        '''(experimental) Properties for CMAF segment configuration.

        :param duration: (experimental) Duration of each segment. Default: Duration.seconds(6)
        :param include_iframe_only_streams: (experimental) Whether to include I-frame-only streams. Default: false
        :param name: (experimental) Name of the segment. Default: 'segment'
        :param encryption: (experimental) Encryption configuration for the CMAF segment. Use ``CmafEncryption.speke()`` to create the configuration. Default: - No encryption
        :param scte_filter: (experimental) SCTE-35 message types to treat as ad markers. Default: - no filtering
        :param scte_in_segments: (experimental) Controls whether SCTE-35 messages are included in segment files. Default: - SCTE-35 messages are not included in segments

        :stability: experimental
        :exampleMetadata: infused

        Example::

            # channel: Channel
            # speke_role: iam.IRole
            
            
            OriginEndpoint(self, "Endpoint",
                channel=channel,
                segment=Segment.cmaf(
                    encryption=CmafEncryption.speke(
                        method=CmafEncryptionMethod.CBCS,
                        drm_systems=[CmafDrmSystem.FAIRPLAY, CmafDrmSystem.WIDEVINE],
                        resource_id="my-content-id",
                        url="https://example.com/speke",
                        role=speke_role,
                        key_rotation_interval=Duration.seconds(300),
                        audio_preset=PresetSpeke20Audio.PRESET_AUDIO_2,
                        video_preset=PresetSpeke20Video.PRESET_VIDEO_2
                    )
                ),
                manifests=[Manifest.hls(manifest_name="index")]
            )
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__3b689767144ebb36d3dabfe350d46307408ca4a837f34777ba45ddbced9bb217)
            check_type(argname="argument duration", value=duration, expected_type=type_hints["duration"])
            check_type(argname="argument include_iframe_only_streams", value=include_iframe_only_streams, expected_type=type_hints["include_iframe_only_streams"])
            check_type(argname="argument name", value=name, expected_type=type_hints["name"])
            check_type(argname="argument encryption", value=encryption, expected_type=type_hints["encryption"])
            check_type(argname="argument scte_filter", value=scte_filter, expected_type=type_hints["scte_filter"])
            check_type(argname="argument scte_in_segments", value=scte_in_segments, expected_type=type_hints["scte_in_segments"])
        self._values: typing.Dict[builtins.str, typing.Any] = {}
        if duration is not None:
            self._values["duration"] = duration
        if include_iframe_only_streams is not None:
            self._values["include_iframe_only_streams"] = include_iframe_only_streams
        if name is not None:
            self._values["name"] = name
        if encryption is not None:
            self._values["encryption"] = encryption
        if scte_filter is not None:
            self._values["scte_filter"] = scte_filter
        if scte_in_segments is not None:
            self._values["scte_in_segments"] = scte_in_segments

    @builtins.property
    def duration(self) -> typing.Optional["_aws_cdk_ceddda9d.Duration"]:
        '''(experimental) Duration of each segment.

        :default: Duration.seconds(6)

        :stability: experimental
        '''
        result = self._values.get("duration")
        return typing.cast(typing.Optional["_aws_cdk_ceddda9d.Duration"], result)

    @builtins.property
    def include_iframe_only_streams(self) -> typing.Optional[builtins.bool]:
        '''(experimental) Whether to include I-frame-only streams.

        :default: false

        :stability: experimental
        '''
        result = self._values.get("include_iframe_only_streams")
        return typing.cast(typing.Optional[builtins.bool], result)

    @builtins.property
    def name(self) -> typing.Optional[builtins.str]:
        '''(experimental) Name of the segment.

        :default: 'segment'

        :stability: experimental
        '''
        result = self._values.get("name")
        return typing.cast(typing.Optional[builtins.str], result)

    @builtins.property
    def encryption(self) -> typing.Optional["CmafEncryption"]:
        '''(experimental) Encryption configuration for the CMAF segment.

        Use ``CmafEncryption.speke()`` to create the configuration.

        :default: - No encryption

        :stability: experimental
        '''
        result = self._values.get("encryption")
        return typing.cast(typing.Optional["CmafEncryption"], result)

    @builtins.property
    def scte_filter(self) -> typing.Optional[typing.List["ScteMessageType"]]:
        '''(experimental) SCTE-35 message types to treat as ad markers.

        :default: - no filtering

        :stability: experimental
        '''
        result = self._values.get("scte_filter")
        return typing.cast(typing.Optional[typing.List["ScteMessageType"]], result)

    @builtins.property
    def scte_in_segments(self) -> typing.Optional["ScteInSegments"]:
        '''(experimental) Controls whether SCTE-35 messages are included in segment files.

        :default: - SCTE-35 messages are not included in segments

        :stability: experimental
        '''
        result = self._values.get("scte_in_segments")
        return typing.cast(typing.Optional["ScteInSegments"], result)

    def __eq__(self, rhs: typing.Any) -> builtins.bool:
        return isinstance(rhs, self.__class__) and rhs._values == self._values

    def __ne__(self, rhs: typing.Any) -> builtins.bool:
        return not (rhs == self)

    def __repr__(self) -> str:
        return "CmafSegmentProps(%s)" % ", ".join(
            k + "=" + repr(v) for k, v in self._values.items()
        )


@jsii.data_type(
    jsii_type="@aws-cdk/aws-mediapackagev2-alpha.IsmSegmentProps",
    jsii_struct_bases=[SegmentPropsBase],
    name_mapping={
        "duration": "duration",
        "include_iframe_only_streams": "includeIframeOnlyStreams",
        "name": "name",
        "encryption": "encryption",
    },
)
class IsmSegmentProps(SegmentPropsBase):
    def __init__(
        self,
        *,
        duration: typing.Optional["_aws_cdk_ceddda9d.Duration"] = None,
        include_iframe_only_streams: typing.Optional[builtins.bool] = None,
        name: typing.Optional[builtins.str] = None,
        encryption: typing.Optional["IsmEncryption"] = None,
    ) -> None:
        '''(experimental) Properties for ISM (Microsoft Smooth Streaming) segment configuration.

        :param duration: (experimental) Duration of each segment. Default: Duration.seconds(6)
        :param include_iframe_only_streams: (experimental) Whether to include I-frame-only streams. Default: false
        :param name: (experimental) Name of the segment. Default: 'segment'
        :param encryption: (experimental) Encryption configuration for the ISM segment. Use ``IsmEncryption.speke()`` to create the configuration. Default: - No encryption

        :stability: experimental
        :exampleMetadata: infused

        Example::

            # channel: Channel
            # speke_role: iam.IRole
            
            
            OriginEndpoint(self, "IsmEndpoint",
                channel=channel,
                segment=Segment.ism(
                    encryption=IsmEncryption.speke(
                        resource_id="my-content-id",
                        url="https://example.com/speke",
                        role=speke_role
                    )
                ),
                manifests=[Manifest.mss(manifest_name="index")]
            )
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__3ea2a765c00eb6acabb175babac0ef479d6a05bf312884c2e9391fa2fe3bceed)
            check_type(argname="argument duration", value=duration, expected_type=type_hints["duration"])
            check_type(argname="argument include_iframe_only_streams", value=include_iframe_only_streams, expected_type=type_hints["include_iframe_only_streams"])
            check_type(argname="argument name", value=name, expected_type=type_hints["name"])
            check_type(argname="argument encryption", value=encryption, expected_type=type_hints["encryption"])
        self._values: typing.Dict[builtins.str, typing.Any] = {}
        if duration is not None:
            self._values["duration"] = duration
        if include_iframe_only_streams is not None:
            self._values["include_iframe_only_streams"] = include_iframe_only_streams
        if name is not None:
            self._values["name"] = name
        if encryption is not None:
            self._values["encryption"] = encryption

    @builtins.property
    def duration(self) -> typing.Optional["_aws_cdk_ceddda9d.Duration"]:
        '''(experimental) Duration of each segment.

        :default: Duration.seconds(6)

        :stability: experimental
        '''
        result = self._values.get("duration")
        return typing.cast(typing.Optional["_aws_cdk_ceddda9d.Duration"], result)

    @builtins.property
    def include_iframe_only_streams(self) -> typing.Optional[builtins.bool]:
        '''(experimental) Whether to include I-frame-only streams.

        :default: false

        :stability: experimental
        '''
        result = self._values.get("include_iframe_only_streams")
        return typing.cast(typing.Optional[builtins.bool], result)

    @builtins.property
    def name(self) -> typing.Optional[builtins.str]:
        '''(experimental) Name of the segment.

        :default: 'segment'

        :stability: experimental
        '''
        result = self._values.get("name")
        return typing.cast(typing.Optional[builtins.str], result)

    @builtins.property
    def encryption(self) -> typing.Optional["IsmEncryption"]:
        '''(experimental) Encryption configuration for the ISM segment.

        Use ``IsmEncryption.speke()`` to create the configuration.

        :default: - No encryption

        :stability: experimental
        '''
        result = self._values.get("encryption")
        return typing.cast(typing.Optional["IsmEncryption"], result)

    def __eq__(self, rhs: typing.Any) -> builtins.bool:
        return isinstance(rhs, self.__class__) and rhs._values == self._values

    def __ne__(self, rhs: typing.Any) -> builtins.bool:
        return not (rhs == self)

    def __repr__(self) -> str:
        return "IsmSegmentProps(%s)" % ", ".join(
            k + "=" + repr(v) for k, v in self._values.items()
        )


__all__ = [
    "AdMarkerDash",
    "AdMarkerHls",
    "AudioCodec",
    "BitrateExpression",
    "BitrateFilterKey",
    "CdnAuthConfiguration",
    "Channel",
    "ChannelAttributes",
    "ChannelGrants",
    "ChannelGroup",
    "ChannelGroupAttributes",
    "ChannelGroupProps",
    "ChannelOptions",
    "ChannelPolicy",
    "ChannelPolicyProps",
    "ChannelProps",
    "CmafDrmSystem",
    "CmafEncryption",
    "CmafEncryptionMethod",
    "CmafInputProps",
    "CmafSegmentProps",
    "CmafSpekeEncryptionProps",
    "ContainerType",
    "DashBaseUrlProperty",
    "DashDvbFontDownload",
    "DashDvbMetricsReporting",
    "DashDvbSettings",
    "DashManifestCompactness",
    "DashManifestConfiguration",
    "DashPeriodTriggers",
    "DashProgramInformation",
    "DashSubtitleConfiguration",
    "DashTtmlConfiguration",
    "DashUtcTimingMode",
    "DrmSettingsKey",
    "DrmSignalling",
    "EncryptionConfiguration",
    "EndpointErrorConfiguration",
    "FilterConfiguration",
    "HeadersCMSD",
    "HlsManifestConfiguration",
    "IChannel",
    "IChannelGroup",
    "IOriginEndpoint",
    "IngestEndpoint",
    "InputConfiguration",
    "InputSwitchConfiguration",
    "InputType",
    "IsmDrmSystem",
    "IsmEncryption",
    "IsmSegmentProps",
    "IsmSpekeEncryptionProps",
    "LowLatencyHlsManifestConfiguration",
    "Manifest",
    "ManifestFilter",
    "MssManifestConfiguration",
    "MssManifestLayout",
    "NumericExpression",
    "NumericFilterKey",
    "OriginEndpoint",
    "OriginEndpointAttributes",
    "OriginEndpointOptions",
    "OriginEndpointPolicy",
    "OriginEndpointPolicyProps",
    "OriginEndpointProps",
    "PresetSpeke20Audio",
    "PresetSpeke20Video",
    "ScteInSegments",
    "ScteMessageType",
    "Segment",
    "SegmentConfiguration",
    "SegmentPropsBase",
    "SegmentTemplateFormat",
    "StartTag",
    "StartTagOptions",
    "TextFilterKey",
    "TrickplayType",
    "TsDrmSystem",
    "TsEncryption",
    "TsEncryptionMethod",
    "TsSegmentProps",
    "TsSpekeEncryptionProps",
    "TtmlProfile",
    "VideoCodec",
    "VideoDynamicRange",
]

publication.publish()

def _typecheckingstub__cef0b173a39ebd214b9387ff35a69c9b290daf234b204ecb673e0dea4e33566b(
    _expression: builtins.str,
    _values: typing.Sequence[jsii.Number],
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__370333bb7a2bd0ae7f2d85516be277afe72880357ca0d8529eb724672961c006(
    start: _aws_cdk_ceddda9d.Bitrate,
    end: _aws_cdk_ceddda9d.Bitrate,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__5b2323b47b60307668354092741947bbedf35f9eb07182e37555571e9a45f37e(
    v: _aws_cdk_ceddda9d.Bitrate,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__7a973b8df45c6d0c16e41ce2441038d66992f05c57f9613d6c2b7ac43e3b5589(
    *,
    secrets: typing.Sequence[_aws_cdk_aws_secretsmanager_ceddda9d.ISecret],
    role: typing.Optional[_aws_cdk_aws_iam_ceddda9d.IRole] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__3dbf726152c5231e0c115b080a55ba81739fccba33c8ae926556c21cd7c547e9(
    *,
    channel_group_name: builtins.str,
    channel_name: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__e3f462b7a5994b24147e5f7dbc9ac847dca8bd17cd5e008a02ccd0676c7c8da2(
    resource: _aws_cdk_interfaces_aws_mediapackagev2_ceddda9d.IChannelRef,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__7d3f4e9c211af7198d28c57f43a4d2c905ca4c6498cd44f1c9ba95b59a046099(
    grantee: _aws_cdk_aws_iam_ceddda9d.IGrantable,
    actions: typing.Sequence[builtins.str],
    *,
    resource_arns: typing.Optional[typing.Sequence[builtins.str]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__1d84b5c81a3dbac6c488a15e8bbb4a6b4e67363b40923afc31a6ad1438149d83(
    grantee: _aws_cdk_aws_iam_ceddda9d.IGrantable,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__18915e4ef54cf118705a88eeec8edcbdd15cacdd7eabcb196bcc4d8296d61bf2(
    *,
    channel_group_name: builtins.str,
    egress_domain: typing.Optional[builtins.str] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__b661b89526bafe2c5b5acded16dac17256117c013a1f41e8670fdd6e70802914(
    *,
    channel_group_name: typing.Optional[builtins.str] = None,
    description: typing.Optional[builtins.str] = None,
    removal_policy: typing.Optional[_aws_cdk_ceddda9d.RemovalPolicy] = None,
    tags: typing.Optional[typing.Mapping[builtins.str, builtins.str]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__58c9af0b7061b152c26ed32505c5e17f4aab847ef25106b67860deda20e6889d(
    *,
    channel_name: typing.Optional[builtins.str] = None,
    description: typing.Optional[builtins.str] = None,
    input: typing.Optional[InputConfiguration] = None,
    removal_policy: typing.Optional[_aws_cdk_ceddda9d.RemovalPolicy] = None,
    tags: typing.Optional[typing.Mapping[builtins.str, builtins.str]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__254aa3d7fb168fa977a8082f25556744916bdad988a167a6456e12b7b1b01e5f(
    scope: _constructs_77d1e7e8.Construct,
    id: builtins.str,
    *,
    channel: IChannel,
    policy_document: typing.Optional[_aws_cdk_aws_iam_ceddda9d.PolicyDocument] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__1c9900c4dd3a19f21f5a8f9e05ab82ecf487a4d9b41deaaae63685ae66220ffc(
    *,
    channel: IChannel,
    policy_document: typing.Optional[_aws_cdk_aws_iam_ceddda9d.PolicyDocument] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__adf088508014b31b36bd72748a7a4e7c13de583dfbcb8750a94f7133b29d0c8b(
    *,
    channel_name: typing.Optional[builtins.str] = None,
    description: typing.Optional[builtins.str] = None,
    input: typing.Optional[InputConfiguration] = None,
    removal_policy: typing.Optional[_aws_cdk_ceddda9d.RemovalPolicy] = None,
    tags: typing.Optional[typing.Mapping[builtins.str, builtins.str]] = None,
    channel_group: IChannelGroup,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__2a272d1cd2a0c4d33ce97c6ff17c5aa4ef5dd9282731e89954ffbe2648aa304a(
    *,
    input_switch_configuration: typing.Optional[typing.Union[InputSwitchConfiguration, typing.Dict[builtins.str, typing.Any]]] = None,
    output_headers: typing.Optional[typing.Sequence[HeadersCMSD]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__afb64bc3c9b007944e121c7e242753845cd8a76d1861921290670294ea747dcd(
    *,
    drm_systems: typing.Sequence[CmafDrmSystem],
    method: CmafEncryptionMethod,
    resource_id: builtins.str,
    role: _aws_cdk_aws_iam_ceddda9d.IRole,
    url: builtins.str,
    audio_preset: typing.Optional[PresetSpeke20Audio] = None,
    certificate: typing.Optional[_aws_cdk_aws_certificatemanager_ceddda9d.ICertificate] = None,
    constant_initialization_vector: typing.Optional[builtins.str] = None,
    exclude_segment_drm_metadata: typing.Optional[builtins.bool] = None,
    key_rotation_interval: typing.Optional[_aws_cdk_ceddda9d.Duration] = None,
    video_preset: typing.Optional[PresetSpeke20Video] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__d69902f67d72b90ff1e2a8bc1c45e19b801c769512caab71f0ae8880e9c69959(
    *,
    url: builtins.str,
    dvb_priority: typing.Optional[jsii.Number] = None,
    dvb_weight: typing.Optional[jsii.Number] = None,
    service_location: typing.Optional[builtins.str] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__4902792404c08d765cbdd683174e2e5354bb7e6ac3caa5962e07d99362ef381b(
    *,
    font_family: typing.Optional[builtins.str] = None,
    mime_type: typing.Optional[builtins.str] = None,
    url: typing.Optional[builtins.str] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__93abcf86ab112966176778b60cd77dddc0ce7bebf298937991207cc8a91b8a4f(
    *,
    reporting_url: builtins.str,
    probability: typing.Optional[jsii.Number] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__6bcd887c45dafe0b485ae1896e59921eab98690114f1f5b45431149620fbb444(
    *,
    error_metrics: typing.Optional[typing.Sequence[typing.Union[DashDvbMetricsReporting, typing.Dict[builtins.str, typing.Any]]]] = None,
    font_download: typing.Optional[typing.Union[DashDvbFontDownload, typing.Dict[builtins.str, typing.Any]]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__59c9ba2facf8e573eada8862e4949af76c325c7a39c154870da8b761c4b8e572(
    *,
    manifest_name: builtins.str,
    base_urls: typing.Optional[typing.Sequence[typing.Union[DashBaseUrlProperty, typing.Dict[builtins.str, typing.Any]]]] = None,
    compactness: typing.Optional[DashManifestCompactness] = None,
    drm_signalling: typing.Optional[DrmSignalling] = None,
    dvb_settings: typing.Optional[typing.Union[DashDvbSettings, typing.Dict[builtins.str, typing.Any]]] = None,
    filter_configuration: typing.Optional[typing.Union[FilterConfiguration, typing.Dict[builtins.str, typing.Any]]] = None,
    manifest_window: typing.Optional[_aws_cdk_ceddda9d.Duration] = None,
    min_buffer_time: typing.Optional[_aws_cdk_ceddda9d.Duration] = None,
    min_update_period: typing.Optional[_aws_cdk_ceddda9d.Duration] = None,
    period_triggers: typing.Optional[typing.Sequence[DashPeriodTriggers]] = None,
    profiles: typing.Optional[typing.Sequence[builtins.str]] = None,
    program_information: typing.Optional[typing.Union[DashProgramInformation, typing.Dict[builtins.str, typing.Any]]] = None,
    scte_dash_ad_marker: typing.Optional[AdMarkerDash] = None,
    segment_template_format: typing.Optional[SegmentTemplateFormat] = None,
    subtitle_configuration: typing.Optional[typing.Union[DashSubtitleConfiguration, typing.Dict[builtins.str, typing.Any]]] = None,
    suggested_presentation_delay: typing.Optional[_aws_cdk_ceddda9d.Duration] = None,
    utc_timing_mode: typing.Optional[DashUtcTimingMode] = None,
    utc_timing_source: typing.Optional[builtins.str] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__c5649f47fbe8678636fdb729138cb6364f9cb05a64a5340b58fe1a651c6add54(
    *,
    copyright: typing.Optional[builtins.str] = None,
    language_code: typing.Optional[builtins.str] = None,
    more_information_url: typing.Optional[builtins.str] = None,
    source: typing.Optional[builtins.str] = None,
    title: typing.Optional[builtins.str] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__d0f34b7baf12431bdd44ba4ac86b0beef88e32083554c1173c8dffe98c857f42(
    *,
    ttml_configuration: typing.Optional[typing.Union[DashTtmlConfiguration, typing.Dict[builtins.str, typing.Any]]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__cec83b9ced564350a41b7e960ca63a7318ebd4cded1ac3d2642b2e18eef0aa8a(
    *,
    ttml_profile: TtmlProfile,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__ec69b5371101ae530c3f09c16702d509409b048b3a187223d73ee793ed6437ec(
    *,
    clip_start_time: typing.Optional[datetime.datetime] = None,
    drm_settings: typing.Optional[typing.Sequence[DrmSettingsKey]] = None,
    end: typing.Optional[datetime.datetime] = None,
    manifest_filter: typing.Optional[typing.Sequence[ManifestFilter]] = None,
    start: typing.Optional[datetime.datetime] = None,
    time_delay: typing.Optional[_aws_cdk_ceddda9d.Duration] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__246b895f1b9c79fb75ffeafae18291e95e1df0d509fb3fda34bfb81d75b8b2b1(
    value: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__f660ebc93317dcda78a955d0ad53e4997889f9e7a370db36a40d0470fdead946(
    *,
    manifest_name: builtins.str,
    child_manifest_name: typing.Optional[builtins.str] = None,
    filter_configuration: typing.Optional[typing.Union[FilterConfiguration, typing.Dict[builtins.str, typing.Any]]] = None,
    manifest_window: typing.Optional[_aws_cdk_ceddda9d.Duration] = None,
    program_date_time_interval: typing.Optional[_aws_cdk_ceddda9d.Duration] = None,
    scte_ad_marker_hls: typing.Optional[AdMarkerHls] = None,
    start_tag: typing.Optional[StartTag] = None,
    url_encode_child_manifest: typing.Optional[builtins.bool] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__fb8c13565abc2f222cc515be2ddabba55559efbdec003f4f8f37f0fb9bcf5210(
    id: builtins.str,
    *,
    manifests: typing.Sequence[Manifest],
    segment: typing.Union[SegmentConfiguration, typing.Dict[builtins.str, typing.Any]],
    cdn_auth: typing.Optional[typing.Union[CdnAuthConfiguration, typing.Dict[builtins.str, typing.Any]]] = None,
    description: typing.Optional[builtins.str] = None,
    force_endpoint_configuration_conditions: typing.Optional[typing.Sequence[EndpointErrorConfiguration]] = None,
    origin_endpoint_name: typing.Optional[builtins.str] = None,
    removal_policy: typing.Optional[_aws_cdk_ceddda9d.RemovalPolicy] = None,
    startover_window: typing.Optional[_aws_cdk_ceddda9d.Duration] = None,
    tags: typing.Optional[typing.Mapping[builtins.str, builtins.str]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__9112ca5adc347c8eccc09cf2de882adfea68c6995274ee205cb0c1d16f5b62c3(
    statement: _aws_cdk_aws_iam_ceddda9d.PolicyStatement,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__e19c3affc8fee9a2c8113936b0b23abdfc45c550cb864c9d1ebcb7a869e46a7b(
    metric_name: builtins.str,
    *,
    account: typing.Optional[builtins.str] = None,
    color: typing.Optional[builtins.str] = None,
    dimensions_map: typing.Optional[typing.Mapping[builtins.str, builtins.str]] = None,
    id: typing.Optional[builtins.str] = None,
    label: typing.Optional[builtins.str] = None,
    period: typing.Optional[_aws_cdk_ceddda9d.Duration] = None,
    region: typing.Optional[builtins.str] = None,
    stack_account: typing.Optional[builtins.str] = None,
    stack_region: typing.Optional[builtins.str] = None,
    statistic: typing.Optional[builtins.str] = None,
    unit: typing.Optional[_aws_cdk_aws_cloudwatch_ceddda9d.Unit] = None,
    visible: typing.Optional[builtins.bool] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__885b68da4b21c227213a6ace76c95dd1b36c90d5978e525b5064a6ee11e9b7d4(
    id: builtins.str,
    *,
    channel_name: typing.Optional[builtins.str] = None,
    description: typing.Optional[builtins.str] = None,
    input: typing.Optional[InputConfiguration] = None,
    removal_policy: typing.Optional[_aws_cdk_ceddda9d.RemovalPolicy] = None,
    tags: typing.Optional[typing.Mapping[builtins.str, builtins.str]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__a846e8d44f001945a2a3b7021711dfdac251684800be2c5f3e56b0ec1697f235(
    metric_name: builtins.str,
    *,
    account: typing.Optional[builtins.str] = None,
    color: typing.Optional[builtins.str] = None,
    dimensions_map: typing.Optional[typing.Mapping[builtins.str, builtins.str]] = None,
    id: typing.Optional[builtins.str] = None,
    label: typing.Optional[builtins.str] = None,
    period: typing.Optional[_aws_cdk_ceddda9d.Duration] = None,
    region: typing.Optional[builtins.str] = None,
    stack_account: typing.Optional[builtins.str] = None,
    stack_region: typing.Optional[builtins.str] = None,
    statistic: typing.Optional[builtins.str] = None,
    unit: typing.Optional[_aws_cdk_aws_cloudwatch_ceddda9d.Unit] = None,
    visible: typing.Optional[builtins.bool] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__796ce7b0a89e7a57938308fa6e3a5b9a7c64c6ba67f7c57782c4b03b8573ba4c(
    statement: _aws_cdk_aws_iam_ceddda9d.PolicyStatement,
    *,
    secrets: typing.Sequence[_aws_cdk_aws_secretsmanager_ceddda9d.ISecret],
    role: typing.Optional[_aws_cdk_aws_iam_ceddda9d.IRole] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__98994e12767ad68f909cd493f951fde744ca3181a8848b587f62dbe99c2ae901(
    metric_name: builtins.str,
    *,
    account: typing.Optional[builtins.str] = None,
    color: typing.Optional[builtins.str] = None,
    dimensions_map: typing.Optional[typing.Mapping[builtins.str, builtins.str]] = None,
    id: typing.Optional[builtins.str] = None,
    label: typing.Optional[builtins.str] = None,
    period: typing.Optional[_aws_cdk_ceddda9d.Duration] = None,
    region: typing.Optional[builtins.str] = None,
    stack_account: typing.Optional[builtins.str] = None,
    stack_region: typing.Optional[builtins.str] = None,
    statistic: typing.Optional[builtins.str] = None,
    unit: typing.Optional[_aws_cdk_aws_cloudwatch_ceddda9d.Unit] = None,
    visible: typing.Optional[builtins.bool] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__0322b745dfe2f5ce9bdcbef49a8387589b631010553669609836dd3b45dcb07b(
    *,
    mqcs_input_switching: typing.Optional[builtins.bool] = None,
    preferred_input: typing.Optional[IngestEndpoint] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__207e848bdbbf90ebf47dd35e4f5e8c66b32906305da08676b3d3117f9ff9a040(
    *,
    resource_id: builtins.str,
    role: _aws_cdk_aws_iam_ceddda9d.IRole,
    url: builtins.str,
    certificate: typing.Optional[_aws_cdk_aws_certificatemanager_ceddda9d.ICertificate] = None,
    drm_systems: typing.Optional[typing.Sequence[IsmDrmSystem]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__3b6843d9b56b39bf8da90289f17ac6d175903cffcf96c562ad4bf7494549cd06(
    *,
    manifest_name: builtins.str,
    child_manifest_name: typing.Optional[builtins.str] = None,
    filter_configuration: typing.Optional[typing.Union[FilterConfiguration, typing.Dict[builtins.str, typing.Any]]] = None,
    manifest_window: typing.Optional[_aws_cdk_ceddda9d.Duration] = None,
    program_date_time_interval: typing.Optional[_aws_cdk_ceddda9d.Duration] = None,
    scte_ad_marker_hls: typing.Optional[AdMarkerHls] = None,
    start_tag: typing.Optional[StartTag] = None,
    url_encode_child_manifest: typing.Optional[builtins.bool] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__9825d21f69fabb4cec87019ce84bc63ed79b035871d8b693552decd8a1bd5e63(
    filter_string: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__b6270414059c407cdd2b50e5a7ab9be08cffc062093a8fae130143973e79a99c(
    value: AudioCodec,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__4da8bd2766cad77f0dea5e023286f68642ffe78457fe39ae4918f9ca1aa73c5c(
    values: typing.Sequence[AudioCodec],
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__eccd222c793a79ed2e2b6087c379441c1e6e87f2bea169d99bb075a6556f4671(
    key: BitrateFilterKey,
    value: _aws_cdk_ceddda9d.Bitrate,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__62fe494c007c76c81d7ecdf66d4777f830a615793745f7838c58fcb34b92aa01(
    key: BitrateFilterKey,
    expressions: typing.Sequence[BitrateExpression],
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__24b8dffd92844ad1235488ca97b83b7526f70c9b0b08a5f0edc58bc1010ce6a5(
    key: BitrateFilterKey,
    start: _aws_cdk_ceddda9d.Bitrate,
    end: _aws_cdk_ceddda9d.Bitrate,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__f9967f92c2353efa3d34354b108f2af19e715419347edb0a052907620aafd9b6(
    custom: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__4d0a8dd380f286730cd486679707664425d5457ad36985679d380638cffd9e7d(
    key: NumericFilterKey,
    value: jsii.Number,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__6f805d86d5124f55bd9e1850f9eb8b61df99ea9fde48023180229150d903e7bb(
    key: NumericFilterKey,
    expressions: typing.Sequence[NumericExpression],
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__ca5c4dd8d6c6b3324af3b690df18a06b5766af5002c7fb6c109e5c6d12687416(
    key: NumericFilterKey,
    values: typing.Sequence[jsii.Number],
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__8c6c9b64e68e31399b4d690d62093560525f8da3ab8784bf1618de87ceceb015(
    key: NumericFilterKey,
    start: jsii.Number,
    end: jsii.Number,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__e9a95432fade1331da6dfcaf2997fa1a93b67691a6e262adc275c47cee0be589(
    key: TextFilterKey,
    value: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__f855a7a6062acdeddc45ec68ce7819baee54e82a53267b1a7c31e98cf0a0f612(
    key: TextFilterKey,
    values: typing.Sequence[builtins.str],
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__818f63b4445f749b764ec916c619b494da512e38a5013d7f6208b05dc10a7a53(
    value: TrickplayType,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__5d8d6f8b2aa02e67fd5fe2a21c0836f30ed78c229c86e70483859f27efec40ae(
    values: typing.Sequence[TrickplayType],
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__9e5976d7c112a7fc453c17920fc25bfd4579a19c014bc6a2938895fbf88acd81(
    value: VideoCodec,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__0034d4b0d5bafef541077e86052a4d3cd8b37ef3978eafb000a6ba0a92cbd88e(
    values: typing.Sequence[VideoCodec],
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__0036fd0d969a84cebf3fe1e55be95b1a9ab2889e77b2081b71ea5eda8de9cab4(
    value: VideoDynamicRange,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__9a36914b492312df842a3a9fd7b2665f42b65c1ddbf423631438b959cce0a1a3(
    values: typing.Sequence[VideoDynamicRange],
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__bd1ffa43ee487e6baff6fc48d73ba83d9f802907c33c72e4b90a0990a5a5c67b(
    *,
    manifest_name: builtins.str,
    filter_configuration: typing.Optional[typing.Union[FilterConfiguration, typing.Dict[builtins.str, typing.Any]]] = None,
    manifest_layout: typing.Optional[MssManifestLayout] = None,
    manifest_window: typing.Optional[_aws_cdk_ceddda9d.Duration] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__91ec48f608c030b98f198e3d6b9ce6feebec494c04d6cecba578af86ee144bde(
    _expression: builtins.str,
    _values: typing.Sequence[jsii.Number],
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__667160b8a039452ef047a9629f8a55f36ac350557a7cfbe5a933b4c13de23fec(
    start: jsii.Number,
    end: jsii.Number,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__ff7e97f856edd07cbabfc6db4ac3bab38f056284f3cacdb5758e5a5ed3409f58(
    v: jsii.Number,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__bebcb7d2659b0bd6e9f9e1898d5650db070e4aa180d87cc5c208d5623c31921b(
    scope: _constructs_77d1e7e8.Construct,
    id: builtins.str,
    *,
    channel: IChannel,
    manifests: typing.Sequence[Manifest],
    segment: typing.Union[SegmentConfiguration, typing.Dict[builtins.str, typing.Any]],
    cdn_auth: typing.Optional[typing.Union[CdnAuthConfiguration, typing.Dict[builtins.str, typing.Any]]] = None,
    description: typing.Optional[builtins.str] = None,
    force_endpoint_configuration_conditions: typing.Optional[typing.Sequence[EndpointErrorConfiguration]] = None,
    origin_endpoint_name: typing.Optional[builtins.str] = None,
    removal_policy: typing.Optional[_aws_cdk_ceddda9d.RemovalPolicy] = None,
    startover_window: typing.Optional[_aws_cdk_ceddda9d.Duration] = None,
    tags: typing.Optional[typing.Mapping[builtins.str, builtins.str]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__08c1b6698153d058e059c9a5869a6e97f4e3b8a73584db23b2dd860b683a75cd(
    scope: _constructs_77d1e7e8.Construct,
    id: builtins.str,
    *,
    channel_group_name: builtins.str,
    channel_name: builtins.str,
    origin_endpoint_name: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__b6270cd12d501c0354caf98dd06608a78c2fa1fce2a764e16bed67b71032605b(
    statement: _aws_cdk_aws_iam_ceddda9d.PolicyStatement,
    *,
    secrets: typing.Sequence[_aws_cdk_aws_secretsmanager_ceddda9d.ISecret],
    role: typing.Optional[_aws_cdk_aws_iam_ceddda9d.IRole] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__93ec0aae1665f4ca315dc11b1ba73b7c507a182c3dbd99782987f958b51072c6(
    metric_name: builtins.str,
    *,
    account: typing.Optional[builtins.str] = None,
    color: typing.Optional[builtins.str] = None,
    dimensions_map: typing.Optional[typing.Mapping[builtins.str, builtins.str]] = None,
    id: typing.Optional[builtins.str] = None,
    label: typing.Optional[builtins.str] = None,
    period: typing.Optional[_aws_cdk_ceddda9d.Duration] = None,
    region: typing.Optional[builtins.str] = None,
    stack_account: typing.Optional[builtins.str] = None,
    stack_region: typing.Optional[builtins.str] = None,
    statistic: typing.Optional[builtins.str] = None,
    unit: typing.Optional[_aws_cdk_aws_cloudwatch_ceddda9d.Unit] = None,
    visible: typing.Optional[builtins.bool] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__061e94b85e68e127a16f7f5fc125f59b3967d5466271bacd9ace89e57a782f65(
    segment_container_type: ContainerType,
    *,
    container_type: ContainerType,
    encryption: typing.Optional[EncryptionConfiguration] = None,
    include_iframe_only_streams: typing.Optional[builtins.bool] = None,
    scte_filter: typing.Optional[typing.Sequence[ScteMessageType]] = None,
    scte_in_segments: typing.Optional[ScteInSegments] = None,
    segment_duration: typing.Optional[_aws_cdk_ceddda9d.Duration] = None,
    segment_name: typing.Optional[builtins.str] = None,
    ts_include_dvb_subtitles: typing.Optional[builtins.bool] = None,
    ts_use_audio_rendition_group: typing.Optional[builtins.bool] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__4cbbc133811be2981f90a7c2fdf05e55dd7290c7aea33f5d2493e5abe037fa7b(
    value: builtins.bool,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__f2e4cb9776dab0ec1380129079f1889d4f79817b010054c0ee1f996af3b26e2a(
    value: typing.List[_aws_cdk_aws_mediapackagev2_ceddda9d.CfnOriginEndpoint.DashManifestConfigurationProperty],
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__d6dcc55b52e525151aee13cd8aebddad06a6324db85110100aa6f23f2cfbad30(
    value: typing.List[_aws_cdk_aws_mediapackagev2_ceddda9d.CfnOriginEndpoint.HlsManifestConfigurationProperty],
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__e2f4a8794fb6b9cc51f35ea907ad16eefe139461b148cd4643770b911b8aecb8(
    value: typing.List[_aws_cdk_aws_mediapackagev2_ceddda9d.CfnOriginEndpoint.LowLatencyHlsManifestConfigurationProperty],
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__9f6bac8fbfa86e7f0ef9e6266027805f94f19475c8dae8bb042141b5ce3253bc(
    value: typing.List[_aws_cdk_aws_mediapackagev2_ceddda9d.CfnOriginEndpoint.MssManifestConfigurationProperty],
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__e4e4649175a02c973b89236092da8be59780eaf123a53929ed54cddff93c7e08(
    value: typing.Optional[OriginEndpointPolicy],
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__238aaf06141faf383d1401eedbdde221eaef2c6a5e89cf06c3400160d18889fe(
    value: typing.Optional[SegmentConfiguration],
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__8f2307f56de43bc78c8a719a388a9301c9c01e44923052dd18882bb2621384c0(
    *,
    channel_group_name: builtins.str,
    channel_name: builtins.str,
    origin_endpoint_name: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__d605ec53aa81b54b1dea33423c87e458f6d97e120ac2889498e4712de5c080c4(
    *,
    manifests: typing.Sequence[Manifest],
    segment: typing.Union[SegmentConfiguration, typing.Dict[builtins.str, typing.Any]],
    cdn_auth: typing.Optional[typing.Union[CdnAuthConfiguration, typing.Dict[builtins.str, typing.Any]]] = None,
    description: typing.Optional[builtins.str] = None,
    force_endpoint_configuration_conditions: typing.Optional[typing.Sequence[EndpointErrorConfiguration]] = None,
    origin_endpoint_name: typing.Optional[builtins.str] = None,
    removal_policy: typing.Optional[_aws_cdk_ceddda9d.RemovalPolicy] = None,
    startover_window: typing.Optional[_aws_cdk_ceddda9d.Duration] = None,
    tags: typing.Optional[typing.Mapping[builtins.str, builtins.str]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__0ce86cd12d9e5aace3901a14e591645d36c1341e652de8208a5a5dc173ce574c(
    scope: _constructs_77d1e7e8.Construct,
    id: builtins.str,
    *,
    origin_endpoint: IOriginEndpoint,
    cdn_auth: typing.Optional[typing.Union[CdnAuthConfiguration, typing.Dict[builtins.str, typing.Any]]] = None,
    policy_document: typing.Optional[_aws_cdk_aws_iam_ceddda9d.PolicyDocument] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__c51380fe991c69a64bec8dd6ad6c056712f2c67066c31c9ad74a15a4f9eee4e2(
    *,
    origin_endpoint: IOriginEndpoint,
    cdn_auth: typing.Optional[typing.Union[CdnAuthConfiguration, typing.Dict[builtins.str, typing.Any]]] = None,
    policy_document: typing.Optional[_aws_cdk_aws_iam_ceddda9d.PolicyDocument] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__d2915b00ce306ab1a736d81ac5321db4415588817aa6eeb282de84e4b12bbef2(
    *,
    manifests: typing.Sequence[Manifest],
    segment: typing.Union[SegmentConfiguration, typing.Dict[builtins.str, typing.Any]],
    cdn_auth: typing.Optional[typing.Union[CdnAuthConfiguration, typing.Dict[builtins.str, typing.Any]]] = None,
    description: typing.Optional[builtins.str] = None,
    force_endpoint_configuration_conditions: typing.Optional[typing.Sequence[EndpointErrorConfiguration]] = None,
    origin_endpoint_name: typing.Optional[builtins.str] = None,
    removal_policy: typing.Optional[_aws_cdk_ceddda9d.RemovalPolicy] = None,
    startover_window: typing.Optional[_aws_cdk_ceddda9d.Duration] = None,
    tags: typing.Optional[typing.Mapping[builtins.str, builtins.str]] = None,
    channel: IChannel,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__7eaed8a99aa8e7c44936e12e26744614fc5c273b127d32ad8dee9525fd05bbc4(
    *,
    container_type: ContainerType,
    encryption: typing.Optional[EncryptionConfiguration] = None,
    include_iframe_only_streams: typing.Optional[builtins.bool] = None,
    scte_filter: typing.Optional[typing.Sequence[ScteMessageType]] = None,
    scte_in_segments: typing.Optional[ScteInSegments] = None,
    segment_duration: typing.Optional[_aws_cdk_ceddda9d.Duration] = None,
    segment_name: typing.Optional[builtins.str] = None,
    ts_include_dvb_subtitles: typing.Optional[builtins.bool] = None,
    ts_use_audio_rendition_group: typing.Optional[builtins.bool] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__b315f2b8942cdb1d172d97e7c05c86c67d4253ca3382b5dbe1013e00886bb3c8(
    *,
    duration: typing.Optional[_aws_cdk_ceddda9d.Duration] = None,
    include_iframe_only_streams: typing.Optional[builtins.bool] = None,
    name: typing.Optional[builtins.str] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__671cbba9971ee8689fdab0a27400f47b37f58fb32bacd2f590ca3b3becbdcdfd(
    time_offset: jsii.Number,
    *,
    precise: typing.Optional[builtins.bool] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__771c9d5f2b7c378d5e03fb8bd0293797340fd071345fc538136379399ab40dbe(
    time_offset: jsii.Number,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__387f489898d9fa51d35a51b8e69abef87601862628c11c5b78d2d9481e273552(
    *,
    precise: typing.Optional[builtins.bool] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__3cc04934c526853727862fc18b8646e58adf04f42ca30004bf72bd58e22bb9ba(
    *,
    duration: typing.Optional[_aws_cdk_ceddda9d.Duration] = None,
    include_iframe_only_streams: typing.Optional[builtins.bool] = None,
    name: typing.Optional[builtins.str] = None,
    encryption: typing.Optional[TsEncryption] = None,
    include_dvb_subtitles: typing.Optional[builtins.bool] = None,
    scte_filter: typing.Optional[typing.Sequence[ScteMessageType]] = None,
    scte_in_segments: typing.Optional[ScteInSegments] = None,
    use_audio_rendition_group: typing.Optional[builtins.bool] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__b04324e17ebadcdfaea8e3a1eccad55437e3526f06a1f5746a01e27c59c61084(
    *,
    method: TsEncryptionMethod,
    resource_id: builtins.str,
    role: _aws_cdk_aws_iam_ceddda9d.IRole,
    url: builtins.str,
    audio_preset: typing.Optional[PresetSpeke20Audio] = None,
    certificate: typing.Optional[_aws_cdk_aws_certificatemanager_ceddda9d.ICertificate] = None,
    constant_initialization_vector: typing.Optional[builtins.str] = None,
    drm_systems: typing.Optional[typing.Sequence[TsDrmSystem]] = None,
    key_rotation_interval: typing.Optional[_aws_cdk_ceddda9d.Duration] = None,
    video_preset: typing.Optional[PresetSpeke20Video] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__e97930301d3a05b49d8965b18baf102128ed5083396ddf568115a87aa3c19cf0(
    scope: _constructs_77d1e7e8.Construct,
    id: builtins.str,
    *,
    channel_group: IChannelGroup,
    channel_name: typing.Optional[builtins.str] = None,
    description: typing.Optional[builtins.str] = None,
    input: typing.Optional[InputConfiguration] = None,
    removal_policy: typing.Optional[_aws_cdk_ceddda9d.RemovalPolicy] = None,
    tags: typing.Optional[typing.Mapping[builtins.str, builtins.str]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__2a6c2d90a33f6cd3293e16e95225b645ef5cdd382ca625942dbdea43236c489a(
    scope: _constructs_77d1e7e8.Construct,
    id: builtins.str,
    *,
    channel_group_name: builtins.str,
    channel_name: builtins.str,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__d54a8801ed11b95de27ff35870f70803f222c8a39177ba6693742f428b05234c(
    id: builtins.str,
    *,
    manifests: typing.Sequence[Manifest],
    segment: typing.Union[SegmentConfiguration, typing.Dict[builtins.str, typing.Any]],
    cdn_auth: typing.Optional[typing.Union[CdnAuthConfiguration, typing.Dict[builtins.str, typing.Any]]] = None,
    description: typing.Optional[builtins.str] = None,
    force_endpoint_configuration_conditions: typing.Optional[typing.Sequence[EndpointErrorConfiguration]] = None,
    origin_endpoint_name: typing.Optional[builtins.str] = None,
    removal_policy: typing.Optional[_aws_cdk_ceddda9d.RemovalPolicy] = None,
    startover_window: typing.Optional[_aws_cdk_ceddda9d.Duration] = None,
    tags: typing.Optional[typing.Mapping[builtins.str, builtins.str]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__53ea6ee834bec3996dc93e56c76a3dc4c06332c523577d6e599827d11c607d54(
    statement: _aws_cdk_aws_iam_ceddda9d.PolicyStatement,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__c3fadc96f0188e24b9399874ae898f21357c07a50dbaf4dcc1d9d1fabcd34ab3(
    metric_name: builtins.str,
    *,
    account: typing.Optional[builtins.str] = None,
    color: typing.Optional[builtins.str] = None,
    dimensions_map: typing.Optional[typing.Mapping[builtins.str, builtins.str]] = None,
    id: typing.Optional[builtins.str] = None,
    label: typing.Optional[builtins.str] = None,
    period: typing.Optional[_aws_cdk_ceddda9d.Duration] = None,
    region: typing.Optional[builtins.str] = None,
    stack_account: typing.Optional[builtins.str] = None,
    stack_region: typing.Optional[builtins.str] = None,
    statistic: typing.Optional[builtins.str] = None,
    unit: typing.Optional[_aws_cdk_aws_cloudwatch_ceddda9d.Unit] = None,
    visible: typing.Optional[builtins.bool] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__782a319e3ac45be18df6931193de7bfc51750ef7011325bef5945849b3579765(
    value: builtins.bool,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__df2dd2cf51203a9e93bdc5f272a1b441505f2ed355507111239ce162d539b551(
    value: typing.Optional[ChannelPolicy],
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__19e9d2bb024b9ab11829e175ffc5b47fd6d7bab91a3d0e7287ef19e92182afc5(
    scope: _constructs_77d1e7e8.Construct,
    id: builtins.str,
    *,
    channel_group_name: typing.Optional[builtins.str] = None,
    description: typing.Optional[builtins.str] = None,
    removal_policy: typing.Optional[_aws_cdk_ceddda9d.RemovalPolicy] = None,
    tags: typing.Optional[typing.Mapping[builtins.str, builtins.str]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__9eb3995d0248aa58244f93bbd57aac471311799bee6f81632c351bf5e5d7766c(
    scope: _constructs_77d1e7e8.Construct,
    id: builtins.str,
    *,
    channel_group_name: builtins.str,
    egress_domain: typing.Optional[builtins.str] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__a557ba064f0ffc77f9a13ae4880a2072cdd2669de085450567023de420714de5(
    id: builtins.str,
    *,
    channel_name: typing.Optional[builtins.str] = None,
    description: typing.Optional[builtins.str] = None,
    input: typing.Optional[InputConfiguration] = None,
    removal_policy: typing.Optional[_aws_cdk_ceddda9d.RemovalPolicy] = None,
    tags: typing.Optional[typing.Mapping[builtins.str, builtins.str]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__97d61bbd3e10d180ca57698ab342cad843bea1e5bf76f29d82342460e4da1aab(
    metric_name: builtins.str,
    *,
    account: typing.Optional[builtins.str] = None,
    color: typing.Optional[builtins.str] = None,
    dimensions_map: typing.Optional[typing.Mapping[builtins.str, builtins.str]] = None,
    id: typing.Optional[builtins.str] = None,
    label: typing.Optional[builtins.str] = None,
    period: typing.Optional[_aws_cdk_ceddda9d.Duration] = None,
    region: typing.Optional[builtins.str] = None,
    stack_account: typing.Optional[builtins.str] = None,
    stack_region: typing.Optional[builtins.str] = None,
    statistic: typing.Optional[builtins.str] = None,
    unit: typing.Optional[_aws_cdk_aws_cloudwatch_ceddda9d.Unit] = None,
    visible: typing.Optional[builtins.bool] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__3b689767144ebb36d3dabfe350d46307408ca4a837f34777ba45ddbced9bb217(
    *,
    duration: typing.Optional[_aws_cdk_ceddda9d.Duration] = None,
    include_iframe_only_streams: typing.Optional[builtins.bool] = None,
    name: typing.Optional[builtins.str] = None,
    encryption: typing.Optional[CmafEncryption] = None,
    scte_filter: typing.Optional[typing.Sequence[ScteMessageType]] = None,
    scte_in_segments: typing.Optional[ScteInSegments] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__3ea2a765c00eb6acabb175babac0ef479d6a05bf312884c2e9391fa2fe3bceed(
    *,
    duration: typing.Optional[_aws_cdk_ceddda9d.Duration] = None,
    include_iframe_only_streams: typing.Optional[builtins.bool] = None,
    name: typing.Optional[builtins.str] = None,
    encryption: typing.Optional[IsmEncryption] = None,
) -> None:
    """Type checking stubs"""
    pass

for cls in [IChannel, IChannelGroup, IOriginEndpoint]:
    typing.cast(typing.Any, cls).__protocol_attrs__ = typing.cast(typing.Any, cls).__protocol_attrs__ - set(['__jsii_proxy_class__', '__jsii_type__'])
