"""Atomic effects (put, go, …)."""
