### THIS FILE WAS AUTO-GENERATED ###
from __future__ import annotations

import typing
from xml.etree import ElementTree as ET

from ..utils.model import BaseModel
from ..utils.errors import SDFError


import math

def _parse_int32(raw: str) -> int | SDFError:
    try:
        v = int(raw)
        if not (-2147483648 <= v <= 2147483647):
            return SDFError(f"int32 out of range: {v}")
        return v
    except ValueError:
        return SDFError(f"Invalid int32: {raw}")


def _parse_uint32(raw: str) -> int | SDFError:
    try:
        v = int(raw)
        if not (0 <= v <= 4294967295):
            return SDFError(f"uint32 out of range: {v}")
        return v
    except ValueError:
        return SDFError(f"Invalid uint32: {raw}")


def _parse_double(raw: str) -> float | SDFError:
    try:
        v = float(raw)
        if not math.isfinite(v) or abs(v) > math.inf:
            return SDFError(f"double out of range: {raw}")
        return v
    except ValueError:
        return SDFError(f"Invalid double: {raw}")



class Capsule(BaseModel):
    class Radius(BaseModel):
        def __init__(self, sdf_version: str | None = None, radius: float = 0.5):
            self.__version__ = sdf_version
            self.radius = radius

        def to_version(self, target_version: str) -> "Radius":
            kwargs = {"sdf_version": target_version}
            kwargs["radius"] = self.radius
            new_obj = self.__class__(**kwargs)
            return new_obj

        def to_sdf(self, version: str | None = None) -> ET.Element:
            if self.__version__ is None and version is not None:
                self.__version__ = version
            elif version is not None and version != self.__version__:
                return self.to_version(version).to_sdf()
            version = self.__version__ or version
            el = ET.Element("radius")
            if self.radius is not None:
                el.text = str(self.radius)
            return el

        @classmethod
        def _from_sdf(cls, el: ET.Element, version: str):
            _text = el.text or 0.5
            _radius = _parse_double(_text)
            if isinstance(_radius, SDFError):
                return _radius
            return cls(sdf_version=version, radius=_radius)

    class Length(BaseModel):
        def __init__(self, sdf_version: str | None = None, length: float = 1):
            self.__version__ = sdf_version
            self.length = length

        def to_version(self, target_version: str) -> "Length":
            kwargs = {"sdf_version": target_version}
            kwargs["length"] = self.length
            new_obj = self.__class__(**kwargs)
            return new_obj

        def to_sdf(self, version: str | None = None) -> ET.Element:
            if self.__version__ is None and version is not None:
                self.__version__ = version
            elif version is not None and version != self.__version__:
                return self.to_version(version).to_sdf()
            version = self.__version__ or version
            el = ET.Element("length")
            if self.length is not None:
                el.text = str(self.length)
            return el

        @classmethod
        def _from_sdf(cls, el: ET.Element, version: str):
            _text = el.text or 1
            _length = _parse_double(_text)
            if isinstance(_length, SDFError):
                return _length
            return cls(sdf_version=version, length=_length)

    def __init__(
        self,
        sdf_version: str | None = None,
        length: "Capsule.Length" = None,
        radius: "Capsule.Radius" = None
    ):
        self.__version__ = sdf_version
        self.length = length
        self.radius = radius
        if self.length is not None:
            if getattr(self.length, '__version__', None) is None:
                self.length.__version__ = self.__version__
            elif getattr(self.length, '__version__', None) != self.__version__ and self.__version__ is not None:
                self.length = self.length.to_version(self.__version__)
        if self.radius is not None:
            if getattr(self.radius, '__version__', None) is None:
                self.radius.__version__ = self.__version__
            elif getattr(self.radius, '__version__', None) != self.__version__ and self.__version__ is not None:
                self.radius = self.radius.to_version(self.__version__)

    def to_version(self, target_version: str) -> "Capsule":
        kwargs = {"sdf_version": target_version}
        kwargs["length"] = self.length.to_version(target_version) if self.length is not None else None
        kwargs["radius"] = self.radius.to_version(target_version) if self.radius is not None else None
        new_obj = self.__class__(**kwargs)
        return new_obj

    def to_sdf(self, version: str | None = None) -> ET.Element:
        if self.__version__ is None and version is not None:
            self.__version__ = version
        elif version is not None and version != self.__version__:
            return self.to_version(version).to_sdf()
        version = self.__version__ or version
        el = ET.Element("capsule")
        if self.length is not None:
            el.append(self.length.to_sdf(version))
        if self.radius is not None:
            el.append(self.radius.to_sdf(version))
        return el

    @classmethod
    def _from_sdf(cls, el: ET.Element, version: str):
        _c_length = el.find("length")
        if _c_length is not None:
            _res = Capsule.Length._from_sdf(_c_length, version)
            if isinstance(_res, SDFError):
                return _res.extend("length")
            _length = _res
        else:
            _length = None
        _c_radius = el.find("radius")
        if _c_radius is not None:
            _res = Capsule.Radius._from_sdf(_c_radius, version)
            if isinstance(_res, SDFError):
                return _res.extend("radius")
            _radius = _res
        else:
            _radius = None
        return cls(sdf_version=version, length=_length, radius=_radius)
