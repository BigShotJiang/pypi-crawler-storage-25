### THIS FILE WAS AUTO-GENERATED ###
from __future__ import annotations

import typing
from xml.etree import ElementTree as ET

from ..utils.model import BaseModel
from ..utils.errors import SDFError


import math

def _parse_int32(raw: str) -> int | SDFError:
    try:
        v = int(raw)
        if not (-2147483648 <= v <= 2147483647):
            return SDFError(f"int32 out of range: {v}")
        return v
    except ValueError:
        return SDFError(f"Invalid int32: {raw}")


def _parse_uint32(raw: str) -> int | SDFError:
    try:
        v = int(raw)
        if not (0 <= v <= 4294967295):
            return SDFError(f"uint32 out of range: {v}")
        return v
    except ValueError:
        return SDFError(f"Invalid uint32: {raw}")


def _parse_double(raw: str) -> float | SDFError:
    try:
        v = float(raw)
        if not math.isfinite(v) or abs(v) > math.inf:
            return SDFError(f"double out of range: {raw}")
        return v
    except ValueError:
        return SDFError(f"Invalid double: {raw}")



class LogicalCamera(BaseModel):
    class Near(BaseModel):
        def __init__(self, sdf_version: str | None = None, near: float = 0):
            self.__version__ = sdf_version
            self.near = near

        def to_version(self, target_version: str) -> "Near":
            kwargs = {"sdf_version": target_version}
            kwargs["near"] = self.near
            new_obj = self.__class__(**kwargs)
            return new_obj

        def to_sdf(self, version: str | None = None) -> ET.Element:
            if self.__version__ is None and version is not None:
                self.__version__ = version
            elif version is not None and version != self.__version__:
                return self.to_version(version).to_sdf()
            version = self.__version__ or version
            el = ET.Element("near")
            if self.near is not None:
                el.text = str(self.near)
            return el

        @classmethod
        def _from_sdf(cls, el: ET.Element, version: str):
            _text = el.text or 0
            _near = _parse_double(_text)
            if isinstance(_near, SDFError):
                return _near
            return cls(sdf_version=version, near=_near)

    class Far(BaseModel):
        def __init__(self, sdf_version: str | None = None, far: float = 1):
            self.__version__ = sdf_version
            self.far = far

        def to_version(self, target_version: str) -> "Far":
            kwargs = {"sdf_version": target_version}
            kwargs["far"] = self.far
            new_obj = self.__class__(**kwargs)
            return new_obj

        def to_sdf(self, version: str | None = None) -> ET.Element:
            if self.__version__ is None and version is not None:
                self.__version__ = version
            elif version is not None and version != self.__version__:
                return self.to_version(version).to_sdf()
            version = self.__version__ or version
            el = ET.Element("far")
            if self.far is not None:
                el.text = str(self.far)
            return el

        @classmethod
        def _from_sdf(cls, el: ET.Element, version: str):
            _text = el.text or 1
            _far = _parse_double(_text)
            if isinstance(_far, SDFError):
                return _far
            return cls(sdf_version=version, far=_far)

    class AspectRatio(BaseModel):
        def __init__(self, sdf_version: str | None = None, aspect_ratio: float = 1):
            self.__version__ = sdf_version
            self.aspect_ratio = aspect_ratio

        def to_version(self, target_version: str) -> "AspectRatio":
            kwargs = {"sdf_version": target_version}
            kwargs["aspect_ratio"] = self.aspect_ratio
            new_obj = self.__class__(**kwargs)
            return new_obj

        def to_sdf(self, version: str | None = None) -> ET.Element:
            if self.__version__ is None and version is not None:
                self.__version__ = version
            elif version is not None and version != self.__version__:
                return self.to_version(version).to_sdf()
            version = self.__version__ or version
            el = ET.Element("aspect_ratio")
            if self.aspect_ratio is not None:
                el.text = str(self.aspect_ratio)
            return el

        @classmethod
        def _from_sdf(cls, el: ET.Element, version: str):
            _text = el.text or 1
            _aspect_ratio = _parse_double(_text)
            if isinstance(_aspect_ratio, SDFError):
                return _aspect_ratio
            return cls(sdf_version=version, aspect_ratio=_aspect_ratio)

    class HorizontalFov(BaseModel):
        def __init__(self, sdf_version: str | None = None, horizontal_fov: float = 1):
            self.__version__ = sdf_version
            self.horizontal_fov = horizontal_fov

        def to_version(self, target_version: str) -> "HorizontalFov":
            kwargs = {"sdf_version": target_version}
            kwargs["horizontal_fov"] = self.horizontal_fov
            new_obj = self.__class__(**kwargs)
            return new_obj

        def to_sdf(self, version: str | None = None) -> ET.Element:
            if self.__version__ is None and version is not None:
                self.__version__ = version
            elif version is not None and version != self.__version__:
                return self.to_version(version).to_sdf()
            version = self.__version__ or version
            el = ET.Element("horizontal_fov")
            if self.horizontal_fov is not None:
                el.text = str(self.horizontal_fov)
            return el

        @classmethod
        def _from_sdf(cls, el: ET.Element, version: str):
            _text = el.text or 1
            _horizontal_fov = _parse_double(_text)
            if isinstance(_horizontal_fov, SDFError):
                return _horizontal_fov
            return cls(sdf_version=version, horizontal_fov=_horizontal_fov)

    def __init__(
        self,
        sdf_version: str | None = None,
        aspect_ratio: "LogicalCamera.AspectRatio" = None,
        far: "LogicalCamera.Far" = None,
        horizontal_fov: "LogicalCamera.HorizontalFov" = None,
        near: "LogicalCamera.Near" = None
    ):
        self.__version__ = sdf_version
        self.aspect_ratio = aspect_ratio
        self.far = far
        self.horizontal_fov = horizontal_fov
        self.near = near
        if self.aspect_ratio is not None:
            if getattr(self.aspect_ratio, '__version__', None) is None:
                self.aspect_ratio.__version__ = self.__version__
            elif getattr(self.aspect_ratio, '__version__', None) != self.__version__ and self.__version__ is not None:
                self.aspect_ratio = self.aspect_ratio.to_version(self.__version__)
        if self.far is not None:
            if getattr(self.far, '__version__', None) is None:
                self.far.__version__ = self.__version__
            elif getattr(self.far, '__version__', None) != self.__version__ and self.__version__ is not None:
                self.far = self.far.to_version(self.__version__)
        if self.horizontal_fov is not None:
            if getattr(self.horizontal_fov, '__version__', None) is None:
                self.horizontal_fov.__version__ = self.__version__
            elif getattr(self.horizontal_fov, '__version__', None) != self.__version__ and self.__version__ is not None:
                self.horizontal_fov = self.horizontal_fov.to_version(self.__version__)
        if self.near is not None:
            if getattr(self.near, '__version__', None) is None:
                self.near.__version__ = self.__version__
            elif getattr(self.near, '__version__', None) != self.__version__ and self.__version__ is not None:
                self.near = self.near.to_version(self.__version__)

    def to_version(self, target_version: str) -> "LogicalCamera":
        kwargs = {"sdf_version": target_version}
        kwargs["aspect_ratio"] = self.aspect_ratio.to_version(target_version) if self.aspect_ratio is not None else None
        kwargs["far"] = self.far.to_version(target_version) if self.far is not None else None
        kwargs["horizontal_fov"] = self.horizontal_fov.to_version(target_version) if self.horizontal_fov is not None else None
        kwargs["near"] = self.near.to_version(target_version) if self.near is not None else None
        new_obj = self.__class__(**kwargs)
        return new_obj

    def to_sdf(self, version: str | None = None) -> ET.Element:
        if self.__version__ is None and version is not None:
            self.__version__ = version
        elif version is not None and version != self.__version__:
            return self.to_version(version).to_sdf()
        version = self.__version__ or version
        el = ET.Element("logical_camera")
        if self.aspect_ratio is not None:
            el.append(self.aspect_ratio.to_sdf(version))
        if self.far is not None:
            el.append(self.far.to_sdf(version))
        if self.horizontal_fov is not None:
            el.append(self.horizontal_fov.to_sdf(version))
        if self.near is not None:
            el.append(self.near.to_sdf(version))
        return el

    @classmethod
    def _from_sdf(cls, el: ET.Element, version: str):
        _c_aspect_ratio = el.find("aspect_ratio")
        if _c_aspect_ratio is not None:
            _res = LogicalCamera.AspectRatio._from_sdf(_c_aspect_ratio, version)
            if isinstance(_res, SDFError):
                return _res.extend("aspect_ratio")
            _aspect_ratio = _res
        else:
            _aspect_ratio = None
        _c_far = el.find("far")
        if _c_far is not None:
            _res = LogicalCamera.Far._from_sdf(_c_far, version)
            if isinstance(_res, SDFError):
                return _res.extend("far")
            _far = _res
        else:
            _far = None
        _c_horizontal_fov = el.find("horizontal_fov")
        if _c_horizontal_fov is not None:
            _res = LogicalCamera.HorizontalFov._from_sdf(_c_horizontal_fov, version)
            if isinstance(_res, SDFError):
                return _res.extend("horizontal_fov")
            _horizontal_fov = _res
        else:
            _horizontal_fov = None
        _c_near = el.find("near")
        if _c_near is not None:
            _res = LogicalCamera.Near._from_sdf(_c_near, version)
            if isinstance(_res, SDFError):
                return _res.extend("near")
            _near = _res
        else:
            _near = None
        return cls(sdf_version=version, aspect_ratio=_aspect_ratio, far=_far, horizontal_fov=_horizontal_fov, near=_near)
