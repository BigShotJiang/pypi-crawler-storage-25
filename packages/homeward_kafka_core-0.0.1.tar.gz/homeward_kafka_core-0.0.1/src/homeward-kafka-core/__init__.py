raise ImportError(
    "homeward-kafka-core is an internal Homeward Health package. "
    "Do not install from public PyPI."
)
