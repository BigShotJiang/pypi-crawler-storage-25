"""Structured logging configuration for MCP Brain.

All modules import log from here for consistent, correlation-ID-tagged output.
"""

import sys
import uuid
import structlog
from contextvars import ContextVar

# Context variable for request correlation ID (propagates across async tasks)
_correlation_id: ContextVar[str] = ContextVar("correlation_id", default="")

def get_correlation_id() -> str:
    """Get the current correlation ID, generating one if not set."""
    return _correlation_id.get()

def set_correlation_id(cid: str) -> None:
    """Set the correlation ID for the current context."""
    _correlation_id.set(cid)

def new_correlation_id() -> str:
    """Generate and set a new correlation ID, returning it."""
    cid = uuid.uuid4().hex[:12]
    _correlation_id.set(cid)
    return cid

def bind_correlation_id(cid: str):
    """Bind a correlation ID to the logger context."""
    return log.bind(correlation_id=cid)

# ── Configure structlog ───────────────────────────────────────────────────────

def _add_correlation_id(logger, method_name, event_dict):
    """Processor: add correlation_id from context var to every log entry."""
    event_dict["correlation_id"] = get_correlation_id()
    return event_dict

def _add_log_level(logger, method_name, event_dict):
    """Processor: add log level to every event."""
    event_dict["level"] = method_name
    return event_dict

_LOG_CONFIGURED = False

def configure_logging(log_level: str = "INFO") -> None:
    """Call once at startup to configure structured logging. Idempotent."""
    global _LOG_CONFIGURED
    if _LOG_CONFIGURED:
        return
    import logging
    level = getattr(logging, log_level.upper(), logging.INFO)
    _LOG_CONFIGURED = True
    structlog.configure(
        processors=[
            structlog.contextvars.merge_contextvars,
            _add_correlation_id,
            structlog.processors.TimeStamper(fmt="iso"),
            structlog.processors.StackInfoRenderer(),
            structlog.processors.format_exc_info,
            structlog.processors.JSONRenderer()
            if not sys.stdout.isatty()
            else structlog.dev.ConsoleRenderer(colors=True),
        ],
        wrapper_class=structlog.make_filtering_bound_logger(level),
        context_class=dict,
        logger_factory=structlog.PrintLoggerFactory(file=sys.stdout),
        cache_logger_on_first_use=True,
    )


# The shared logger instance — deferred until first use after configure_logging():
#     from mcpbrain.logging_config import log
def _get_log():
    """Lazy logger — ensures configure_logging() has run before first use."""
    return structlog.get_logger()

log = structlog.get_logger()  # fallback; configure_logging() guards with _LOG_CONFIGURED
