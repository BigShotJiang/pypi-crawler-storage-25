# -*- coding: utf-8 -*-
"""
Radix Tree (基数树) 实现，用于高效的 IP 地址归属地查询。

作为数据平面，提供微秒级的 IP 查询性能。
支持 IPv4/IPv6，自动处理网段覆盖问题（大网段为背景，小网段为细节）。
"""

from typing import Optional, Dict, List, Tuple, Any, Union
from .ipv4 import IPv4Address, IPv4Network
from .ipv6 import IPv6Address, IPv6Network

# 哨兵值，用于区分"未设置值"和"值为 None"
_UNSET = object()

# IP 版本枚举
IPV4 = 4
IPV6 = 6


class RadixNode:
    """Radix Tree 节点"""

    __slots__ = ("children", "value", "prefix", "ip_version")

    def __init__(self, prefix: str = "", ip_version: int = IPV4):
        self.children: Dict[str, 'RadixNode'] = {}
        self.value: Any = _UNSET  # 使用哨兵值表示未设置
        self.prefix: str = prefix
        self.ip_version: int = ip_version  # 记录 IP 版本

    def __repr__(self):
        if self.value is _UNSET:
            return f"RadixNode(prefix='{self.prefix}', value=<UNSET>)"
        return f"RadixNode(prefix='{self.prefix}', value={self.value})"


class RadixTree:
    """
    Radix Tree 实现，用于高效的 IP 前缀匹配。

    特性：
    - 支持 IPv4/IPv6 CIDR 插入
    - search_best 返回最长前缀匹配（解决网段覆盖问题）
    - O(k) 时间复杂度，k 为 IP 地址位数
    - 适合大规模 IP 归属地查询场景

    注意：
    - IPv4 和 IPv6 网段可以混合存储，但建议分开使用以获得最佳性能
    """

    # 最大前缀长度
    MAX_PREFIX_LEN = {IPV4: 32, IPV6: 128}

    def __init__(self):
        self.root = RadixNode()
        self._count = 0

    def add(self, network: str, value: Any = None) -> bool:
        """
        添加一个 CIDR 网段到 Radix Tree。

        Args:
            network: CIDR 格式字符串，如 "192.168.1.0/24"
            value: 与该网段关联的值（如归属地信息）

        Returns:
            是否为新添加的网段（True=新添加，False=更新已有网段）

        Raises:
            ValueError: 网段格式无效或前缀长度超出范围
        """
        if '/' in network:
            ip_str, prefix_len_str = network.split('/')
            try:
                prefix_len = int(prefix_len_str)
            except ValueError:
                raise ValueError(f"无效的前缀长度: {prefix_len_str}")
        else:
            # 单个 IP，视为 /32 或 /128
            if ':' in network:
                prefix_len = 128
            else:
                prefix_len = 32
            ip_str = network

        # 转换为二进制字符串并验证
        if ':' in ip_str:
            ip_version = IPV6
            try:
                ip = IPv6Address(ip_str)
            except Exception as e:
                raise ValueError(f"无效的 IPv6 地址: {ip_str}") from e
            binary = self._ipv6_to_binary(ip)
            max_prefix_len = 128
        else:
            ip_version = IPV4
            try:
                ip = IPv4Address(ip_str)
            except Exception as e:
                raise ValueError(f"无效的 IPv4 地址: {ip_str}") from e
            binary = self._ipv4_to_binary(ip)
            max_prefix_len = 32

        # 验证前缀长度
        if not (0 <= prefix_len <= max_prefix_len):
            raise ValueError(
                f"前缀长度 {prefix_len} 超出有效范围 (0-{max_prefix_len})"
            )

        # 截取前缀长度
        binary = binary[:prefix_len]

        # 插入到 Radix Tree
        node = self.root

        # 特殊处理前缀长度为 0 的情况（匹配所有 IP）
        if prefix_len == 0:
            is_new = node.value is _UNSET
            if is_new:
                self._count += 1
            node.value = value
            node.ip_version = ip_version
            return is_new

        for bit in binary:
            if bit not in node.children:
                # 创建新节点，继承 IP 版本
                new_node = RadixNode(prefix=node.prefix + bit, ip_version=ip_version)
                node.children[bit] = new_node
                node = new_node
            else:
                node = node.children[bit]

        # 在前缀结束位置设置值
        is_new = node.value is _UNSET
        if is_new:
            self._count += 1
        node.value = value
        node.ip_version = ip_version  # 更新 IP 版本

        return is_new

    def search_best(self, ip: str) -> Optional[Tuple[str, Any]]:
        """
        查找 IP 地址的最长前缀匹配。

        这是解决网段覆盖问题的关键：大网段是"背景"，小网段是"细节"，
        Radix Tree 会自动选出最细节（最长前缀）的匹配。

        Args:
            ip: IP 地址字符串

        Returns:
            (matched_network, value) 元组，如果没有匹配则返回 None
        """
        # 转换为二进制字符串
        if ':' in ip:
            try:
                binary = self._ipv6_to_binary(IPv6Address(ip))
            except Exception:
                return None
        else:
            try:
                binary = self._ipv4_to_binary(IPv4Address(ip))
            except Exception:
                return None

        node = self.root
        best_match = None
        best_value = None
        best_prefix = ""
        best_ip_version = IPV4

        # 检查根节点是否有值（前缀长度为 0 的情况）
        if node.value is not _UNSET:
            best_match = ""
            best_value = node.value
            best_ip_version = node.ip_version

        for bit in binary:
            if bit in node.children:
                node = node.children[bit]
                best_prefix = node.prefix
                if node.value is not _UNSET:
                    best_match = best_prefix
                    best_value = node.value
                    best_ip_version = node.ip_version
            else:
                break

        if best_match is not None:
            # 将二进制前缀转换回 CIDR 格式
            prefix_len = len(best_match)
            if best_ip_version == IPV6:
                network = self._binary_to_ipv6(best_match, prefix_len)
            else:
                network = self._binary_to_ipv4(best_match, prefix_len)
            return (network, best_value)

        return None

    def search_exact(self, network: str) -> Optional[Any]:
        """
        精确匹配查找指定网段的值。

        Args:
            network: CIDR 格式字符串

        Returns:
            关联的值，如果不存在则返回 None
        """
        if '/' in network:
            ip_str, prefix_len_str = network.split('/')
            try:
                prefix_len = int(prefix_len_str)
            except ValueError:
                return None
        else:
            if ':' in network:
                prefix_len = 128
            else:
                prefix_len = 32
            ip_str = network

        if ':' in ip_str:
            try:
                binary = self._ipv6_to_binary(IPv6Address(ip_str))
            except Exception:
                return None
        else:
            try:
                binary = self._ipv4_to_binary(IPv4Address(ip_str))
            except Exception:
                return None

        binary = binary[:prefix_len]

        node = self.root
        for bit in binary:
            if bit not in node.children:
                return None
            node = node.children[bit]

        return node.value if node.value is not _UNSET else None

    def search(self, ip: str) -> Optional[Tuple[str, Any]]:
        """
        查找 IP 地址的最长前缀匹配（search_best 的别名）。

        Args:
            ip: IP 地址字符串

        Returns:
            (matched_network, value) 元组，如果没有匹配则返回 None
        """
        return self.search_best(ip)

    def remove(self, network: str) -> bool:
        """
        从 Radix Tree 中移除一个 CIDR 网段。

        Args:
            network: CIDR 格式字符串

        Returns:
            是否成功移除
        """
        if '/' in network:
            ip_str, prefix_len_str = network.split('/')
            try:
                prefix_len = int(prefix_len_str)
            except ValueError:
                return False
        else:
            if ':' in network:
                prefix_len = 128
            else:
                prefix_len = 32
            ip_str = network

        # 转换为二进制字符串
        if ':' in ip_str:
            try:
                binary = self._ipv6_to_binary(IPv6Address(ip_str))
            except Exception:
                return False
        else:
            try:
                binary = self._ipv4_to_binary(IPv4Address(ip_str))
            except Exception:
                return False

        binary = binary[:prefix_len]

        # 特殊处理前缀长度为 0 的情况
        if prefix_len == 0:
            if self.root.value is not _UNSET:
                self.root.value = _UNSET
                self._count -= 1
                return True
            return False

        # 查找节点
        node = self.root
        path = [node]
        for bit in binary:
            if bit in node.children:
                node = node.children[bit]
                path.append(node)
            else:
                return False

        # 清除值
        if node.value is not _UNSET:
            node.value = _UNSET
            self._count -= 1

            # 清理无用的节点（没有值且没有子节点）
            for i in range(len(path) - 2, 0, -1):
                parent = path[i]
                current = path[i + 1]
                if current.value is _UNSET and len(current.children) == 0:
                    del parent.children[current.prefix[-1]]
                else:
                    break

            return True

        return False

    def clear(self) -> None:
        """清空 Radix Tree"""
        self.root = RadixNode()
        self._count = 0

    def __len__(self) -> int:
        """返回树中网段数量"""
        return self._count

    def __contains__(self, ip: str) -> bool:
        """检查 IP 是否在任意网段中"""
        return self.search_best(ip) is not None

    def _ipv4_to_binary(self, ip: IPv4Address) -> str:
        """将 IPv4 地址转换为 32 位二进制字符串"""
        return format(int(ip), '032b')

    def _binary_to_ipv4(self, binary: str, prefix_len: int) -> str:
        """将二进制字符串转换为 IPv4 CIDR"""
        # 补全到 32 位
        binary = binary.ljust(32, '0')
        ip_int = int(binary, 2)
        ip = IPv4Address(ip_int)
        return f"{ip}/{prefix_len}"

    def _ipv6_to_binary(self, ip: IPv6Address) -> str:
        """将 IPv6 地址转换为 128 位二进制字符串"""
        return format(int(ip), '0128b')

    def _binary_to_ipv6(self, binary: str, prefix_len: int) -> str:
        """将二进制字符串转换为 IPv6 CIDR"""
        # 补全到 128 位
        binary = binary.ljust(128, '0')
        ip_int = int(binary, 2)
        ip = IPv6Address(ip_int)
        return f"{ip}/{prefix_len}"

    def get_all_networks(self) -> List[Tuple[str, Any]]:
        """
        获取树中所有网段及其关联值。

        Returns:
            [(network, value), ...] 列表
        """
        results = []

        def traverse(node: RadixNode):
            if node.value is not _UNSET:
                # 使用节点记录的 IP 版本
                prefix_len = len(node.prefix)
                if node.ip_version == IPV6:
                    network = self._binary_to_ipv6(node.prefix, prefix_len)
                else:
                    network = self._binary_to_ipv4(node.prefix, prefix_len)
                results.append((network, node.value))

            for child in node.children.values():
                traverse(child)

        traverse(self.root)
        return results

    def __repr__(self):
        return f"RadixTree(count={self._count})"
