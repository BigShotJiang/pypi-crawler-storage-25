# -*- coding: utf-8 -*-
"""
控制平面与数据平面集成模块。

提供从 ippool 控制平面生成快照并热加载到 Radix Tree 数据平面的功能。
"""

from typing import List, Dict, Any, Optional, Union, Tuple
from .ippool import IPv4Pool, IPv6Pool
from .radix_tree import RadixTree


class IPPoolDataPlane:
    """
    IP 池数据平面管理器。

    架构：
    - 控制平面：ippool 负责网段分配、重叠检测、合并等逻辑
    - 数据平面：Radix Tree 负责微秒级 IP 查询

    工作流程：
    1. 在 ippool 中管理网段（控制平面）
    2. 生成快照（导出所有 CIDR）
    3. 热加载到 Radix Tree（数据平面）
    4. 查询服务直接使用 Radix Tree

    注意：
    - 当 check_overlap=True 时，控制平面的自动合并可能导致重叠检测不准确
    - 建议在需要精确重叠检测的场景使用 check_overlap=False 并自行管理
    """

    def __init__(self, ip_version: int = 4):
        """
        初始化数据平面管理器。

        Args:
            ip_version: IP 版本，4 或 6

        Raises:
            ValueError: ip_version 不是 4 或 6
        """
        if ip_version not in (4, 6):
            raise ValueError(f"ip_version 必须是 4 或 6，Got: {ip_version}")

        self.ip_version = ip_version
        self.control_plane = IPv4Pool() if ip_version == 4 else IPv6Pool()
        self.data_plane = RadixTree()
        self._metadata: Dict[str, Any] = {}
        # 存储原始网段到值的映射，用于解决控制平面合并后值丢失问题
        self._network_values: Dict[str, Any] = {}

    def add_network(self, network: str, value: Any = None,
                    check_overlap: bool = True) -> bool:
        """
        添加网段到控制平面和数据平面。

        Args:
            network: CIDR 格式字符串
            value: 与网段关联的值（如归属地信息）
            check_overlap: 是否检查重叠

        Returns:
            是否添加成功

        Raises:
            ValueError: 网段重叠且 check_overlap=True，或网段格式无效
        """
        if check_overlap:
            # 使用数据平面检测重叠（更准确）
            result = self.data_plane.search_best(network.split('/')[0])
            if result is not None:
                raise ValueError(
                    f"网段 {network} 与现有网段重叠: {result[0]}"
                )

        # 添加到控制平面
        self.control_plane.add(network)

        # 添加到数据平面
        self.data_plane.add(network, value)

        # 存储原始网段的值
        self._network_values[network] = value

        return True

    def remove_network(self, network: str) -> bool:
        """
        从控制平面和数据平面移除网段。

        Args:
            network: CIDR 格式字符串

        Returns:
            是否成功移除
        """
        # 先尝试从数据平面移除（更快）
        if not self.data_plane.remove(network):
            return False

        # 从控制平面移除
        try:
            self.control_plane.remove(network)
        except ValueError:
            # 控制平面移除失败，需要回滚数据平面
            value = self._network_values.get(network)
            self.data_plane.add(network, value)
            return False

        # 清理值映射
        self._network_values.pop(network, None)

        return True

    def query_ip(self, ip: str) -> Optional[Tuple[str, Any]]:
        """
        查询 IP 地址的归属信息（使用数据平面）。

        Args:
            ip: IP 地址字符串

        Returns:
            (matched_network, value) 元组，如果没有匹配则返回 None
        """
        return self.data_plane.search_best(ip)

    def generate_snapshot(self) -> List[Dict[str, Any]]:
        """
        从数据平面生成快照。

        Returns:
            网段列表，每个元素包含 network 和 value
        """
        networks = []
        for net, value in self.data_plane.get_all_networks():
            networks.append({
                'network': net,
                'value': value
            })
        return networks

    def load_snapshot(self, snapshot: List[Dict[str, Any]],
                      clear_existing: bool = True) -> None:
        """
        从快照热加载到数据平面。

        Args:
            snapshot: 网段快照列表
            clear_existing: 是否清空现有数据
        """
        if clear_existing:
            self.data_plane.clear()
            self.control_plane = IPv4Pool() if self.ip_version == 4 else IPv6Pool()
            self._network_values.clear()

        for item in snapshot:
            network = item['network']
            value = item.get('value')
            self.control_plane.add(network)
            self.data_plane.add(network, value)
            self._network_values[network] = value

    def reload_from_control_plane(self) -> None:
        """
        从控制平面重新加载数据到数据平面。

        用于数据平面与控制平面同步。
        注意：这会丢失所有关联值，因为控制平面不存储值。
        """
        # 保存现有的值映射
        value_map = dict(self._network_values)

        # 清空数据平面
        self.data_plane.clear()
        self._network_values.clear()

        # 重新添加所有网段
        for net in self.control_plane.networks:
            network_str = str(net)
            # 如果网段在值映射中存在，使用对应的值；否则使用 None
            value = value_map.get(network_str)
            self.data_plane.add(network_str, value)
            self._network_values[network_str] = value

    def get_statistics(self) -> Dict[str, Any]:
        """
        获取统计信息。

        Returns:
            包含各种统计指标的字典
        """
        return {
            'ip_version': self.ip_version,
            'control_plane_networks': len(self.control_plane.networks),
            'control_plane_addresses': self.control_plane.num_addresses,
            'data_plane_networks': len(self.data_plane),
            'metadata': self._metadata
        }

    def set_metadata(self, key: str, value: Any) -> None:
        """设置元数据"""
        self._metadata[key] = value

    def get_metadata(self, key: str) -> Optional[Any]:
        """获取元数据"""
        return self._metadata.get(key)

    def export_to_dict(self) -> Dict[str, Any]:
        """
        导出为字典格式（用于序列化）。

        Returns:
            包含所有数据的字典
        """
        return {
            'ip_version': self.ip_version,
            'snapshot': self.generate_snapshot(),
            'metadata': self._metadata
        }

    @classmethod
    def import_from_dict(cls, data: Dict[str, Any]) -> 'IPPoolDataPlane':
        """
        从字典导入（用于反序列化）。

        Args:
            data: 包含数据的字典

        Returns:
            IPPoolDataPlane 实例

        Raises:
            ValueError: 数据格式无效
        """
        if 'ip_version' not in data:
            raise ValueError("缺少 ip_version 字段")
        if 'snapshot' not in data:
            raise ValueError("缺少 snapshot 字段")

        instance = cls(ip_version=data['ip_version'])
        instance.load_snapshot(data['snapshot'])
        instance._metadata = data.get('metadata', {})
        return instance

    def __len__(self) -> int:
        """返回网段数量"""
        return len(self.data_plane)

    def __contains__(self, ip: str) -> bool:
        """检查 IP 是否在任意网段中"""
        return ip in self.data_plane

    def __repr__(self):
        return (f"IPPoolDataPlane(ip_version={self.ip_version}, "
                f"networks={len(self.data_plane)})")


class IPPoolDataPlaneManager:
    """
    数据平面管理器，支持多个 IP 池的管理。

    适用场景：
    - 多个业务线各自管理 IP 池
    - 需要统一查询接口
    - 支持动态添加/删除 IP 池
    """

    def __init__(self):
        self.pools: Dict[str, IPPoolDataPlane] = {}

    def create_pool(self, pool_id: str, ip_version: int = 4) -> IPPoolDataPlane:
        """
        创建新的 IP 池。

        Args:
            pool_id: 池 ID
            ip_version: IP 版本

        Returns:
            IPPoolDataPlane 实例

        Raises:
            ValueError: 池 ID 已存在或 ip_version 无效
        """
        if pool_id in self.pools:
            raise ValueError(f"Pool '{pool_id}' already exists")

        pool = IPPoolDataPlane(ip_version=ip_version)
        self.pools[pool_id] = pool
        return pool

    def get_pool(self, pool_id: str) -> Optional[IPPoolDataPlane]:
        """获取 IP 池"""
        return self.pools.get(pool_id)

    def remove_pool(self, pool_id: str) -> bool:
        """移除 IP 池"""
        if pool_id in self.pools:
            del self.pools[pool_id]
            return True
        return False

    def query_ip(self, ip: str, pool_id: Optional[str] = None) -> Optional[Tuple[str, str, Any]]:
        """
        查询 IP 地址的归属信息。

        Args:
            ip: IP 地址字符串
            pool_id: 指定池 ID，如果为 None 则查询所有池

        Returns:
            (pool_id, matched_network, value) 元组，如果没有匹配则返回 None
        """
        if pool_id:
            pool = self.pools.get(pool_id)
            if pool:
                result = pool.query_ip(ip)
                if result:
                    network, value = result
                    return (pool_id, network, value)
        else:
            # 查询所有池，返回第一个匹配
            for pid, pool in self.pools.items():
                result = pool.query_ip(ip)
                if result:
                    network, value = result
                    return (pid, network, value)

        return None

    def query_ip_all_pools(self, ip: str) -> List[Tuple[str, str, Any]]:
        """
        查询 IP 地址在所有池中的归属信息。

        Args:
            ip: IP 地址字符串

        Returns:
            [(pool_id, matched_network, value), ...] 列表
        """
        results = []
        for pid, pool in self.pools.items():
            result = pool.query_ip(ip)
            if result:
                network, value = result
                results.append((pid, network, value))
        return results

    def get_all_statistics(self) -> Dict[str, Dict[str, Any]]:
        """获取所有池的统计信息"""
        return {
            pool_id: pool.get_statistics()
            for pool_id, pool in self.pools.items()
        }

    def __len__(self) -> int:
        """返回池数量"""
        return len(self.pools)

    def __repr__(self):
        return f"IPPoolDataPlaneManager(pools={len(self.pools)})"
