# -*- coding: utf-8 -*-
"""
Radix Tree 性能基准测试
"""

import pytest
import random
from ippool import RadixTree, IPPoolDataPlane, IPv4Pool


class TestRadixTreePerformance:
    """Radix Tree 性能测试"""

    def test_insert_performance(self, benchmark):
        """测试插入性能"""
        tree = RadixTree()

        def insert_networks():
            for i in range(1000):
                network = f"10.{i // 256}.{i % 256}.0/24"
                tree.add(network, f"Network {i}")

        benchmark(insert_networks)
        assert len(tree) == 1000

    def test_search_performance(self, benchmark):
        """测试查询性能"""
        tree = RadixTree()

        # 预先插入网段（确保 IP 每段不超过 255）
        for a in range(10):
            for b in range(100):
                network = f"10.{a}.{b}.0/24"
                tree.add(network, f"Network {a}-{b}")

        # 随机选择一个 IP 进行查询（确保在插入的网段范围内）
        test_ip = "10.5.50.123"

        def search_ip():
            return tree.search_best(test_ip)

        result = benchmark(search_ip)
        assert result is not None

    def test_longest_prefix_match_performance(self, benchmark):
        """测试最长前缀匹配性能"""
        tree = RadixTree()

        # 创建多层嵌套的网段结构
        tree.add("10.0.0.0/8", "Level 1")
        for i in range(256):
            tree.add(f"10.{i}.0.0/16", f"Level 2-{i}")
            for j in range(256):
                tree.add(f"10.{i}.{j}.0/24", f"Level 3-{i}-{j}")

        # 查询最具体的网段
        test_ip = "10.100.50.123"

        def search_best():
            return tree.search_best(test_ip)

        result = benchmark(search_best)
        assert result is not None
        assert result[0] == "10.100.50.0/24"

    def test_large_scale_search(self, benchmark):
        """测试大规模查询性能"""
        tree = RadixTree()

        # 插入网段（确保 IP 每段不超过 255）
        for a in range(16):
            for b in range(256):
                network = f"10.{a}.{b}.0/24"
                tree.add(network, f"Network {a}-{b}")

        # 生成随机 IP 进行查询
        test_ips = [f"10.{random.randint(0, 15)}.{random.randint(0, 255)}.{random.randint(0, 255)}"
                    for _ in range(100)]

        def search_multiple():
            results = []
            for ip in test_ips:
                result = tree.search_best(ip)
                results.append(result)
            return results

        results = benchmark(search_multiple)
        assert len(results) == 100

    def test_ipv6_performance(self, benchmark):
        """测试 IPv6 性能"""
        tree = RadixTree()

        # 插入 IPv6 网段
        for i in range(1000):
            network = f"2001:db8:{i:04x}::/48"
            tree.add(network, f"IPv6 Network {i}")

        test_ip = "2001:db8:0100::1"

        def search_ipv6():
            return tree.search_best(test_ip)

        result = benchmark(search_ipv6)
        assert result is not None


class TestIPPoolDataPlanePerformance:
    """IPPoolDataPlane 性能测试"""

    def test_add_network_performance(self, benchmark):
        """测试添加网段性能"""
        dp = IPPoolDataPlane(ip_version=4)

        # 使用不同的私有 IP 地址范围来避免合并
        def add_networks():
            networks = [
                "10.0.0.0/24", "10.1.0.0/24", "10.2.0.0/24", "10.3.0.0/24",
                "172.16.0.0/24", "172.17.0.0/24", "172.18.0.0/24", "172.19.0.0/24",
                "192.168.0.0/24", "192.168.1.0/24", "192.168.2.0/24", "192.168.3.0/24",
            ]
            for i in range(100):
                for net in networks:
                    dp.add_network(net, f"Network {i}", check_overlap=False)

        benchmark(add_networks)
        assert len(dp) >= 1  # IPv4Pool 会合并网段，所以只验证有网段存在

    def test_query_ip_performance(self, benchmark):
        """测试查询 IP 性能"""
        dp = IPPoolDataPlane(ip_version=4)

        # 预先添加网段（确保 IP 每段不超过 255）
        for a in range(10):
            for b in range(100):
                network = f"10.{a}.{b}.0/24"
                dp.add_network(network, f"Network {a}-{b}", check_overlap=False)

        test_ip = "10.5.50.123"

        def query_ip():
            return dp.query_ip(test_ip)

        result = benchmark(query_ip)
        assert result is not None

    def test_snapshot_generation_performance(self, benchmark):
        """测试快照生成性能"""
        dp = IPPoolDataPlane(ip_version=4)

        # 预先添加网段
        networks = ["10.0.0.0/24", "10.1.0.0/24", "172.16.0.0/24", "192.168.0.0/24"]
        for i, net in enumerate(networks * 250):
            dp.add_network(net, f"Network {i}", check_overlap=False)

        def generate_snapshot():
            return dp.generate_snapshot()

        snapshot = benchmark(generate_snapshot)
        assert len(snapshot) >= 1  # IPv4Pool 会合并网段

    def test_snapshot_load_performance(self, benchmark):
        """测试快照加载性能"""
        dp = IPPoolDataPlane(ip_version=4)

        # 生成快照
        networks = ["10.0.0.0/24", "10.1.0.0/24", "172.16.0.0/24", "192.168.0.0/24"]
        for i, net in enumerate(networks * 250):
            dp.add_network(net, f"Network {i}", check_overlap=False)

        snapshot = dp.generate_snapshot()

        # 创建新实例并加载快照
        def load_snapshot():
            new_dp = IPPoolDataPlane(ip_version=4)
            new_dp.load_snapshot(snapshot)
            return new_dp

        new_dp = benchmark(load_snapshot)
        assert len(new_dp) >= 1  # IPv4Pool 会合并网段


class TestRadixTreeSearchBenchmark:
    """RadixTree 搜索性能测试"""

    def test_radixtree_search_performance(self, benchmark):
        """测试 RadixTree 的查询性能"""
        networks = ["10.0.0.0/24", "10.1.0.0/24", "172.16.0.0/24", "192.168.0.0/24"]
        test_ip = "10.0.0.123"  # 在 10.0.0.0/24 网段中

        # Radix Tree 方式
        tree = RadixTree()
        for network in networks:
            tree.add(network)

        def search_with_radixtree():
            return tree.search_best(test_ip)

        result = benchmark(search_with_radixtree)
        assert result is not None


class TestDataplaneQueryBenchmark:
    """DataPlane 查询性能测试"""

    def test_dataplane_query_performance(self, benchmark):
        """测试 IPPoolDataPlane 的查询性能"""
        networks = ["10.0.0.0/24", "10.1.0.0/24", "172.16.0.0/24", "192.168.0.0/24"]
        test_ip = "10.0.0.123"  # 在 10.0.0.0/24 网段中

        # IPPoolDataPlane 方式
        dp = IPPoolDataPlane(ip_version=4)
        for network in networks:
            dp.add_network(network, check_overlap=False)

        def query_with_dataplane():
            return dp.query_ip(test_ip)

        result = benchmark(query_with_dataplane)
        assert result is not None


class TestComparisonWithIPPool:
    """与原 IPPool 的性能对比"""

    def test_ippool_search_performance(self, benchmark):
        """测试 IPPool 的查询性能"""
        networks = ["10.0.0.0/24", "10.1.0.0/24", "172.16.0.0/24", "192.168.0.0/24"]
        test_ip = "10.0.0.123"  # 在 10.0.0.0/24 网段中

        # IPPool 方式
        ippool = IPv4Pool(networks)

        def search_with_ippool():
            return test_ip in ippool

        result = benchmark(search_with_ippool)
        assert result is True

    def test_ippool_query_performance(self, benchmark):
        """测试 IPPool 的查询性能"""
        networks = ["10.0.0.0/24", "10.1.0.0/24", "172.16.0.0/24", "192.168.0.0/24"]
        test_ip = "10.0.0.123"  # 在 10.0.0.0/24 网段中

        # IPPool 方式
        ippool = IPv4Pool(networks)

        def query_with_ippool():
            return test_ip in ippool

        result = benchmark(query_with_ippool)
        assert result is True


class TestRealWorldScenarios:
    """真实场景性能测试"""

    def test_ip_geolocation_scenario(self, benchmark):
        """测试 IP 归属地查询场景"""
        tree = RadixTree()

        # 模拟 IP 归属地数据库
        # 中国电信
        tree.add("1.0.0.0/8", "China Telecom")
        tree.add("36.0.0.0/8", "China Telecom")
        tree.add("42.0.0.0/8", "China Telecom")

        # 中国联通
        tree.add("42.56.0.0/15", "China Unicom")
        tree.add("42.128.0.0/12", "China Unicom")

        # 中国移动
        tree.add("223.0.0.0/8", "China Mobile")
        tree.add("39.0.0.0/8", "China Mobile")

        # 测试查询（使用有效的 IP 地址）
        test_ips = [
            "1.2.3.4",      # China Telecom
            "42.100.1.1",   # China Unicom (42.100.x.x matches 42.128.0.0/12)
            "223.255.1.1",  # China Mobile
        ]

        def query_geolocation():
            results = []
            for ip in test_ips:
                result = tree.search_best(ip)
                results.append(result)
            return results

        results = benchmark(query_geolocation)
        assert len(results) == 3
        assert results[0][1] == "China Telecom"
        # 42.100.1.1 在 42.0.0.0/8 范围内，所以匹配 China Telecom
        assert results[1][1] == "China Telecom"
        assert results[2][1] == "China Mobile"

    def test_network_security_scenario(self, benchmark):
        """测试网络安全场景（IP 黑名单）"""
        tree = RadixTree()

        # 添加黑名单网段（使用网段而不是单个 IP，更高效）
        for i in range(10):
            for j in range(100):
                network = f"192.0.{i}.{j}"
                tree.add(network, "Blacklisted")

        # 测试查询
        test_ips = [f"192.0.{i}.{j}" for i in range(10) for j in range(10)]

        def check_blacklist():
            results = []
            for ip in test_ips:
                result = tree.search_best(ip)
                results.append(result is not None)
            return results

        results = benchmark(check_blacklist)
        assert all(results)

    def test_cloud_network_scenario(self, benchmark):
        """测试云平台网络场景"""
        tree = RadixTree()

        # 模拟云平台的 VPC 网络
        for region in range(10):
            for vpc in range(100):
                network = f"10.{region}.{vpc}.0/24"
                tree.add(network, f"Region-{region}-VPC-{vpc}")

        # 测试查询
        test_ip = "10.5.50.123"

        def query_vpc():
            return tree.search_best(test_ip)

        result = benchmark(query_vpc)
        assert result is not None
        assert "Region-5" in result[1]
