# -*- coding: utf-8 -*-
"""
Radix Tree 和数据平面的单元测试
"""

import pytest
from ippool import RadixTree, IPPoolDataPlane, IPPoolDataPlaneManager, IPv4Pool


class TestRadixTree:
    """Radix Tree 基础功能测试"""

    def test_add_and_search_ipv4(self):
        """测试 IPv4 网段的添加和查询"""
        tree = RadixTree()

        # 添加网段
        tree.add("192.168.1.0/24", "Network A")
        tree.add("10.0.0.0/8", "Network B")
        tree.add("172.16.0.0/12", "Network C")

        # 查询
        result = tree.search_best("192.168.1.100")
        assert result is not None
        assert result[1] == "Network A"

        result = tree.search_best("10.1.2.3")
        assert result is not None
        assert result[1] == "Network B"

        result = tree.search_best("172.20.1.1")
        assert result is not None
        assert result[1] == "Network C"

        # 不在网段中的 IP
        result = tree.search_best("8.8.8.8")
        assert result is None

    def test_add_returns_bool(self):
        """测试 add 方法返回值"""
        tree = RadixTree()

        # 新添加返回 True
        assert tree.add("192.168.1.0/24", "Network A") is True
        # 更新已有网段返回 False
        assert tree.add("192.168.1.0/24", "Network B") is False
        # 验证值已更新
        result = tree.search_best("192.168.1.100")
        assert result[1] == "Network B"

    def test_invalid_network_format(self):
        """测试无效网段格式"""
        tree = RadixTree()

        # 无效的前缀长度
        with pytest.raises(ValueError, match="前缀长度"):
            tree.add("192.168.1.0/33")

        with pytest.raises(ValueError, match="前缀长度"):
            tree.add("192.168.1.0/-1")

        # 无效的 IP 地址
        with pytest.raises(ValueError, match="无效的 IPv4 地址"):
            tree.add("256.168.1.0/24")

        # 无效的前缀长度格式
        with pytest.raises(ValueError, match="无效的前缀长度"):
            tree.add("192.168.1.0/abc")

    def test_search_exact(self):
        """测试精确匹配"""
        tree = RadixTree()

        tree.add("192.168.1.0/24", "Network A")
        tree.add("192.168.1.0/25", "Network B")

        # 精确匹配
        assert tree.search_exact("192.168.1.0/24") == "Network A"
        assert tree.search_exact("192.168.1.0/25") == "Network B"
        # 不存在的网段
        assert tree.search_exact("192.168.1.0/26") is None
        # 无效格式返回 None
        assert tree.search_exact("invalid/24") is None

    def test_search_with_invalid_ip(self):
        """测试无效 IP 查询"""
        tree = RadixTree()
        tree.add("192.168.1.0/24", "Network A")

        # 无效 IP 返回 None
        assert tree.search_best("invalid.ip.address") is None
        assert tree.search_best("256.256.256.256") is None

    def test_longest_prefix_match(self):
        """测试最长前缀匹配（解决网段覆盖问题）"""
        tree = RadixTree()

        # 添加重叠网段：大网段是"背景"，小网段是"细节"
        tree.add("192.168.0.0/16", "Large Network")
        tree.add("192.168.1.0/24", "Medium Network")
        tree.add("192.168.1.100/32", "Specific IP")

        # 查询应该返回最长前缀匹配
        result = tree.search_best("192.168.1.100")
        assert result is not None
        assert result[1] == "Specific IP"
        assert result[0] == "192.168.1.100/32"

        result = tree.search_best("192.168.1.50")
        assert result is not None
        assert result[1] == "Medium Network"
        assert result[0] == "192.168.1.0/24"

        result = tree.search_best("192.168.2.1")
        assert result is not None
        assert result[1] == "Large Network"
        assert result[0] == "192.168.0.0/16"

    def test_remove_network(self):
        """测试移除网段"""
        tree = RadixTree()

        tree.add("192.168.1.0/24", "Network A")
        tree.add("10.0.0.0/8", "Network B")

        # 移除网段
        assert tree.remove("192.168.1.0/24") is True
        assert tree.search_best("192.168.1.100") is None
        assert tree.search_best("10.0.0.1") is not None

        # 移除不存在的网段
        assert tree.remove("172.16.0.0/12") is False

    def test_clear_and_count(self):
        """测试清空和计数"""
        tree = RadixTree()

        tree.add("192.168.1.0/24")
        tree.add("10.0.0.0/8")
        assert len(tree) == 2

        tree.clear()
        assert len(tree) == 0
        assert tree.search_best("192.168.1.1") is None

    def test_contains_operator(self):
        """测试 in 操作符"""
        tree = RadixTree()

        tree.add("192.168.1.0/24", "Network A")
        tree.add("10.0.0.0/8", "Network B")

        assert "192.168.1.100" in tree
        assert "10.1.2.3" in tree
        assert "8.8.8.8" not in tree

    def test_get_all_networks(self):
        """测试获取所有网段"""
        tree = RadixTree()

        tree.add("192.168.1.0/24", "Network A")
        tree.add("10.0.0.0/8", "Network B")

        networks = tree.get_all_networks()
        assert len(networks) == 2

        network_dict = {net: value for net, value in networks}
        assert "192.168.1.0/24" in network_dict
        assert "10.0.0.0/8" in network_dict
        assert network_dict["192.168.1.0/24"] == "Network A"

    def test_ipv6_support(self):
        """测试 IPv6 支持"""
        tree = RadixTree()

        tree.add("2001:db8::/32", "IPv6 Network A")
        tree.add("2001:db8:1::/48", "IPv6 Network B")

        result = tree.search_best("2001:db8::1")
        assert result is not None
        assert result[1] == "IPv6 Network A"

        result = tree.search_best("2001:db8:1::100")
        assert result is not None
        assert result[1] == "IPv6 Network B"

    def test_single_ip_as_network(self):
        """测试单个 IP 作为网段"""
        tree = RadixTree()

        # 不带 /32 的单个 IP
        tree.add("192.168.1.100", "Specific IP")

        result = tree.search_best("192.168.1.100")
        assert result is not None
        assert result[0] == "192.168.1.100/32"

        result = tree.search_best("192.168.1.101")
        assert result is None


class TestIPPoolDataPlane:
    """IPPoolDataPlane 集成测试"""

    def test_basic_operations(self):
        """测试基本操作"""
        dp = IPPoolDataPlane(ip_version=4)

        # 添加网段
        dp.add_network("192.168.1.0/24", "Network A")
        dp.add_network("10.0.0.0/8", "Network B")

        # 查询
        result = dp.query_ip("192.168.1.100")
        assert result is not None
        assert result[1] == "Network A"

        # 统计信息
        stats = dp.get_statistics()
        assert stats['control_plane_networks'] == 2
        assert stats['data_plane_networks'] == 2

    def test_overlap_detection(self):
        """测试重叠检测"""
        dp = IPPoolDataPlane(ip_version=4)

        dp.add_network("192.168.0.0/16", "Large Network")

        # 添加重叠网段应该抛出异常
        with pytest.raises(ValueError, match="网段.*与现有网段重叠"):
            dp.add_network("192.168.1.0/24", "Overlap Network")

        # 不检查重叠可以添加
        dp.add_network("192.168.1.0/24", "Overlap Network", check_overlap=False)

    def test_remove_network(self):
        """测试移除网段"""
        dp = IPPoolDataPlane(ip_version=4)

        dp.add_network("192.168.1.0/24", "Network A")
        dp.add_network("10.0.0.0/8", "Network B")

        assert dp.remove_network("192.168.1.0/24") is True
        assert dp.query_ip("192.168.1.100") is None
        assert dp.query_ip("10.0.0.1") is not None

    def test_snapshot_operations(self):
        """测试快照操作"""
        dp = IPPoolDataPlane(ip_version=4)

        dp.add_network("192.168.1.0/24", "Network A")
        dp.add_network("10.0.0.0/8", "Network B")

        # 生成快照
        snapshot = dp.generate_snapshot()
        assert len(snapshot) == 2

        # 创建新实例并加载快照
        dp2 = IPPoolDataPlane(ip_version=4)
        dp2.load_snapshot(snapshot)

        # 验证数据
        result = dp2.query_ip("192.168.1.100")
        assert result is not None
        assert result[1] == "Network A"

    def test_reload_from_control_plane(self):
        """测试从控制平面重新加载"""
        dp = IPPoolDataPlane(ip_version=4)

        dp.add_network("192.168.1.0/24", "Network A")

        # 直接修改控制平面（模拟外部修改）
        dp.control_plane.add("10.0.0.0/8")

        # 重新加载
        dp.reload_from_control_plane()

        # 验证数据平面已同步
        # 注意：新添加的网段没有关联值，所以查询可能返回 None
        # 但网段应该已经被添加到数据平面
        assert len(dp.data_plane) == 2
        assert dp.query_ip("192.168.1.100") is not None

    def test_metadata_operations(self):
        """测试元数据操作"""
        dp = IPPoolDataPlane(ip_version=4)

        dp.set_metadata("version", "1.0")
        dp.set_metadata("owner", "team-a")

        assert dp.get_metadata("version") == "1.0"
        assert dp.get_metadata("owner") == "team-a"
        assert dp.get_metadata("nonexistent") is None

    def test_export_import_dict(self):
        """测试导出和导入字典"""
        dp = IPPoolDataPlane(ip_version=4)

        dp.add_network("192.168.1.0/24", "Network A")
        dp.set_metadata("version", "1.0")

        # 导出
        data = dp.export_to_dict()
        assert data['ip_version'] == 4
        assert len(data['snapshot']) == 1
        assert data['metadata']['version'] == "1.0"

        # 导入
        dp2 = IPPoolDataPlane.import_from_dict(data)
        result = dp2.query_ip("192.168.1.100")
        assert result is not None
        assert result[1] == "Network A"

    def test_contains_operator(self):
        """测试 in 操作符"""
        dp = IPPoolDataPlane(ip_version=4)

        dp.add_network("192.168.1.0/24", "Network A")

        assert "192.168.1.100" in dp
        assert "10.0.0.1" not in dp


class TestIPPoolDataPlaneManager:
    """IPPoolDataPlaneManager 测试"""

    def test_create_and_get_pool(self):
        """测试创建和获取池"""
        manager = IPPoolDataPlaneManager()

        pool1 = manager.create_pool("pool-1", ip_version=4)
        assert pool1 is not None
        assert pool1.ip_version == 4

        pool2 = manager.get_pool("pool-1")
        assert pool2 is pool1

        pool3 = manager.get_pool("nonexistent")
        assert pool3 is None

    def test_duplicate_pool(self):
        """测试重复创建池"""
        manager = IPPoolDataPlaneManager()

        manager.create_pool("pool-1")

        with pytest.raises(ValueError, match="Pool.*already exists"):
            manager.create_pool("pool-1")

    def test_remove_pool(self):
        """测试移除池"""
        manager = IPPoolDataPlaneManager()

        manager.create_pool("pool-1")
        assert manager.remove_pool("pool-1") is True
        assert manager.get_pool("pool-1") is None

        assert manager.remove_pool("nonexistent") is False

    def test_query_ip_specific_pool(self):
        """测试查询指定池"""
        manager = IPPoolDataPlaneManager()

        pool1 = manager.create_pool("pool-1", ip_version=4)
        pool1.add_network("192.168.1.0/24", "Network A")

        pool2 = manager.create_pool("pool-2", ip_version=4)
        pool2.add_network("10.0.0.0/8", "Network B")

        # 查询指定池
        result = manager.query_ip("192.168.1.100", pool_id="pool-1")
        assert result is not None
        assert result[0] == "pool-1"
        assert result[2] == "Network A"

        result = manager.query_ip("192.168.1.100", pool_id="pool-2")
        assert result is None

    def test_query_ip_all_pools(self):
        """测试查询所有池"""
        manager = IPPoolDataPlaneManager()

        pool1 = manager.create_pool("pool-1", ip_version=4)
        pool1.add_network("192.168.1.0/24", "Network A")

        pool2 = manager.create_pool("pool-2", ip_version=4)
        pool2.add_network("10.0.0.0/8", "Network B")

        # 查询所有池
        result = manager.query_ip("192.168.1.100")
        assert result is not None
        assert result[0] == "pool-1"

        result = manager.query_ip("10.0.0.1")
        assert result is not None
        assert result[0] == "pool-2"

        result = manager.query_ip("8.8.8.8")
        assert result is None

    def test_get_all_statistics(self):
        """测试获取所有统计信息"""
        manager = IPPoolDataPlaneManager()

        pool1 = manager.create_pool("pool-1", ip_version=4)
        pool1.add_network("192.168.1.0/24")

        pool2 = manager.create_pool("pool-2", ip_version=4)
        pool2.add_network("10.0.0.0/8")

        stats = manager.get_all_statistics()
        assert len(stats) == 2
        assert "pool-1" in stats
        assert "pool-2" in stats
        assert stats["pool-1"]["control_plane_networks"] == 1

    def test_len_and_repr(self):
        """测试长度和表示"""
        manager = IPPoolDataPlaneManager()

        assert len(manager) == 0

        manager.create_pool("pool-1")
        manager.create_pool("pool-2")

        assert len(manager) == 2
        assert "pools=2" in repr(manager)


class TestIntegrationScenarios:
    """集成场景测试"""

    def test_network_overlap_scenario(self):
        """测试网段重叠场景"""
        dp = IPPoolDataPlane(ip_version=4)

        # 模拟真实场景：大网段分配给部门，小网段分配给项目
        dp.add_network("10.0.0.0/8", "Company Network", check_overlap=False)
        dp.add_network("10.1.0.0/16", "Department A", check_overlap=False)
        dp.add_network("10.1.1.0/24", "Project X", check_overlap=False)
        dp.add_network("10.1.1.100/32", "Server Y", check_overlap=False)

        # 查询应该返回最具体的匹配
        result = dp.query_ip("10.1.1.100")
        assert result[1] == "Server Y"

        result = dp.query_ip("10.1.1.50")
        assert result[1] == "Project X"

        result = dp.query_ip("10.1.2.1")
        assert result[1] == "Department A"

        result = dp.query_ip("10.2.0.1")
        assert result[1] == "Company Network"

    def test_multi_pool_scenario(self):
        """测试多池场景"""
        manager = IPPoolDataPlaneManager()

        # 不同业务线的 IP 池
        pool_prod = manager.create_pool("production", ip_version=4)
        pool_prod.add_network("10.0.0.0/8", "Production")

        pool_test = manager.create_pool("testing", ip_version=4)
        pool_test.add_network("172.16.0.0/12", "Testing")

        pool_dev = manager.create_pool("development", ip_version=4)
        pool_dev.add_network("192.168.0.0/16", "Development")

        # 统一查询接口
        result = manager.query_ip("10.1.2.3")
        assert result[0] == "production"

        result = manager.query_ip("172.20.1.1")
        assert result[0] == "testing"

        result = manager.query_ip("192.168.1.100")
        assert result[0] == "development"

    def test_snapshot_and_reload_scenario(self):
        """测试快照和重新加载场景"""
        dp = IPPoolDataPlane(ip_version=4)

        # 初始数据
        dp.add_network("192.168.1.0/24", "Network A")
        dp.add_network("10.0.0.0/8", "Network B")

        # 生成快照
        snapshot = dp.generate_snapshot()

        # 模拟数据平面故障，重新加载
        dp.data_plane.clear()
        assert dp.query_ip("192.168.1.100") is None

        # 从快照恢复
        dp.load_snapshot(snapshot)
        assert dp.query_ip("192.168.1.100") is not None
        assert dp.query_ip("10.0.0.1") is not None


class TestEdgeCases:
    """边界情况测试"""

    def test_ip_version_validation(self):
        """测试 IP 版本验证"""
        # 有效版本
        dp4 = IPPoolDataPlane(ip_version=4)
        assert dp4.ip_version == 4

        dp6 = IPPoolDataPlane(ip_version=6)
        assert dp6.ip_version == 6

        # 无效版本
        with pytest.raises(ValueError, match="ip_version 必须是 4 或 6"):
            IPPoolDataPlane(ip_version=5)

        with pytest.raises(ValueError, match="ip_version 必须是 4 或 6"):
            IPPoolDataPlane(ip_version="4")

    def test_empty_tree_operations(self):
        """测试空树操作"""
        tree = RadixTree()

        assert len(tree) == 0
        assert tree.search_best("192.168.1.1") is None
        assert "192.168.1.1" not in tree
        assert tree.get_all_networks() == []
        assert tree.remove("192.168.1.0/24") is False

    def test_zero_prefix_length(self):
        """测试 0 前缀长度（匹配所有 IP）"""
        tree = RadixTree()

        # IPv4 0.0.0.0/0 匹配所有 IPv4
        tree.add("0.0.0.0/0", "All IPv4")

        assert tree.search_best("192.168.1.1") is not None
        assert tree.search_best("8.8.8.8") is not None
        assert tree.search_best("0.0.0.0") is not None

    def test_max_prefix_length(self):
        """测试最大前缀长度"""
        tree = RadixTree()

        # /32 和 /128
        tree.add("192.168.1.1/32", "Single IPv4")
        tree.add("::1/128", "Single IPv6")

        assert tree.search_best("192.168.1.1") is not None
        assert tree.search_best("192.168.1.2") is None
        assert tree.search_best("::1") is not None
        assert tree.search_best("::2") is None

    def test_value_can_be_none(self):
        """测试值可以是 None"""
        tree = RadixTree()

        tree.add("192.168.1.0/24", None)

        result = tree.search_best("192.168.1.1")
        assert result is not None
        assert result[0] == "192.168.1.0/24"
        assert result[1] is None

    def test_value_can_be_complex(self):
        """测试值可以是复杂对象"""
        tree = RadixTree()

        # 字典作为值
        tree.add("192.168.1.0/24", {"name": "Network A", "owner": "Team 1"})

        result = tree.search_best("192.168.1.1")
        assert result[1]["name"] == "Network A"

        # 列表作为值
        tree.add("10.0.0.0/8", ["tag1", "tag2"])

        result = tree.search_best("10.0.0.1")
        assert result[1] == ["tag1", "tag2"]

    def test_mixed_ipv4_ipv6(self):
        """测试混合 IPv4 和 IPv6"""
        tree = RadixTree()

        tree.add("192.168.1.0/24", "IPv4 Network")
        tree.add("2001:db8::/32", "IPv6 Network")

        # IPv4 查询
        result = tree.search_best("192.168.1.1")
        assert result is not None
        assert result[1] == "IPv4 Network"

        # IPv6 查询
        result = tree.search_best("2001:db8::1")
        assert result is not None
        assert result[1] == "IPv6 Network"

        # IPv4 IP 不匹配 IPv6 网段
        result = tree.search_best("10.0.0.1")
        assert result is None

    def test_import_from_invalid_dict(self):
        """测试从无效字典导入"""
        # 缺少 ip_version
        with pytest.raises(ValueError, match="缺少 ip_version"):
            IPPoolDataPlane.import_from_dict({'snapshot': []})

        # 缺少 snapshot
        with pytest.raises(ValueError, match="缺少 snapshot"):
            IPPoolDataPlane.import_from_dict({'ip_version': 4})

    def test_manager_query_ip_all_pools(self):
        """测试查询所有池"""
        manager = IPPoolDataPlaneManager()

        pool1 = manager.create_pool("pool-1")
        pool1.add_network("192.168.1.0/24", "Network A")

        pool2 = manager.create_pool("pool-2")
        pool2.add_network("192.168.1.0/24", "Network B")

        # 查询所有池应该返回所有匹配
        results = manager.query_ip_all_pools("192.168.1.1")
        assert len(results) == 2

        pool_ids = [r[0] for r in results]
        assert "pool-1" in pool_ids
        assert "pool-2" in pool_ids

    def test_manager_empty_pools(self):
        """测试空管理器"""
        manager = IPPoolDataPlaneManager()

        assert len(manager) == 0
        assert manager.get_pool("nonexistent") is None
        assert manager.query_ip("192.168.1.1") is None
        assert manager.query_ip_all_pools("192.168.1.1") == []
        assert manager.remove_pool("nonexistent") is False

    def test_dataplane_len_uses_data_plane(self):
        """测试 __len__ 使用数据平面的计数"""
        dp = IPPoolDataPlane(ip_version=4)

        # 添加重叠网段（不检查重叠）
        dp.add_network("192.168.1.0/24", "Network A", check_overlap=False)
        dp.add_network("192.168.1.0/25", "Network B", check_overlap=False)

        # 数据平面应该有 2 个网段
        assert len(dp) == 2

    def test_multiple_remove_same_network(self):
        """测试多次删除同一网段"""
        tree = RadixTree()

        tree.add("192.168.1.0/24", "Network A")

        assert tree.remove("192.168.1.0/24") is True
        assert tree.remove("192.168.1.0/24") is False
        assert len(tree) == 0

    def test_network_value_tracking(self):
        """测试网段值追踪"""
        dp = IPPoolDataPlane(ip_version=4)

        dp.add_network("192.168.1.0/24", "Network A")

        # 重新加载后值应该保留
        dp.reload_from_control_plane()

        result = dp.query_ip("192.168.1.1")
        assert result is not None
        assert result[1] == "Network A"

