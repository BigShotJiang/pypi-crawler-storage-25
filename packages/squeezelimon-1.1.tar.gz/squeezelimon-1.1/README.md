```
print("🍋🍋🍋🍋🍋🍋🍋🍋🍋🍋🍋🍋🍋🍋🍋🍋🍋🍋🍋🍋🍋🍋🍋🍋🍋🍋🍋🍋🍋🍋🍋🍋🍋🍋🍋🍋🍋🍋🍋🍋")
print("Welcome to the 🍋🍋🍋Squeezelimon🍋🍋🍋 Lipid Topology File Downloader!")
print("This tool is derived from the Limonada database and allows you to query and download lipid topology files based on various criteria.")
print("It is for educational and research purposes only. Please ensure you have the necessary permissions to download and use the files.")
print("Author: Zhouji WU, University Paris-Saclay, France")
print("Version: 1.0 (2024-04-16)")
print("The author is not responsible for any misuse of this tool or the downloaded files. Always respect intellectual property rights and use the files in accordance with their licenses.")

print("🍋🍋🍋🍋🍋🍋🍋🍋🍋🍋🍋🍋🍋🍋🍋🍋🍋🍋🍋🍋🍋🍋🍋🍋🍋🍋🍋🍋🍋🍋🍋🍋🍋🍋🍋🍋🍋🍋🍋🍋")
print("We Sincerely thank the Limonada team at University of Reims Champagne-Ardenne for maintaining this valuable resource.")
print("For more information, please refer to: https://limonada.univ-reims.fr/")
print("🍋🍋🍋🍋🍋🍋🍋🍋🍋🍋🍋🍋🍋🍋🍋🍋🍋🍋🍋🍋🍋🍋🍋🍋🍋🍋🍋🍋🍋🍋🍋🍋🍋🍋🍋🍋🍋🍋🍋🍋")
```