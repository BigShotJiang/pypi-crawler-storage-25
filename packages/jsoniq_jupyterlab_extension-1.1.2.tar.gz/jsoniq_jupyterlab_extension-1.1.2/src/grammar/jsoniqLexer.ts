
import * as antlr from "antlr4ng";
import { Token } from "antlr4ng";


export class jsoniqLexer extends antlr.Lexer {
    public static readonly Ksemicolon = 1;
    public static readonly Kmodule = 2;
    public static readonly Kequal = 3;
    public static readonly Kdollar = 4;
    public static readonly Kassign = 5;
    public static readonly Klbrace = 6;
    public static readonly Krbrace = 7;
    public static readonly Klparen = 8;
    public static readonly Krparen = 9;
    public static readonly Kasterisk = 10;
    public static readonly Kpipe = 11;
    public static readonly Kannotation = 12;
    public static readonly Kcomma = 13;
    public static readonly Kbase_uri = 14;
    public static readonly Kordering = 15;
    public static readonly Kordered = 16;
    public static readonly Kdecimal_format = 17;
    public static readonly Kcolon = 18;
    public static readonly Kdecimal_separator = 19;
    public static readonly Kgrouping_separator = 20;
    public static readonly Kinfinity = 21;
    public static readonly Kminus_sign = 22;
    public static readonly Knan = 23;
    public static readonly Kpercent = 24;
    public static readonly Kper_mille = 25;
    public static readonly Kzero_digit = 26;
    public static readonly Kdigit = 27;
    public static readonly Kpattern_separator = 28;
    public static readonly Kexternal = 29;
    public static readonly Kfunction = 30;
    public static readonly Kjsound = 31;
    public static readonly Kcompact = 32;
    public static readonly Kverbose = 33;
    public static readonly Keq = 34;
    public static readonly Kne = 35;
    public static readonly Klt = 36;
    public static readonly Kle = 37;
    public static readonly Kgt = 38;
    public static readonly Kge = 39;
    public static readonly Knot_equal = 40;
    public static readonly Kless = 41;
    public static readonly Kless_or_equal = 42;
    public static readonly Kgreater = 43;
    public static readonly Kgreater_or_equal = 44;
    public static readonly Kconcat = 45;
    public static readonly Kplus = 46;
    public static readonly Kminus = 47;
    public static readonly Kdiv = 48;
    public static readonly Kidiv = 49;
    public static readonly Kmod = 50;
    public static readonly Kbang = 51;
    public static readonly Klbracket = 52;
    public static readonly Krbracket = 53;
    public static readonly Kdot = 54;
    public static readonly Kcontext_item = 55;
    public static readonly Khash = 56;
    public static readonly Kdotdot = 57;
    public static readonly Kobject_start = 58;
    public static readonly Kobject_end = 59;
    public static readonly Kfor = 60;
    public static readonly Klet = 61;
    public static readonly Kwhere = 62;
    public static readonly Kgroup = 63;
    public static readonly Kby = 64;
    public static readonly Korder = 65;
    public static readonly Kreturn = 66;
    public static readonly Kif = 67;
    public static readonly Kin = 68;
    public static readonly Kas = 69;
    public static readonly Kat = 70;
    public static readonly Kallowing = 71;
    public static readonly Kempty = 72;
    public static readonly Kcount = 73;
    public static readonly Kstable = 74;
    public static readonly Kascending = 75;
    public static readonly Kdescending = 76;
    public static readonly Ksome = 77;
    public static readonly Kevery = 78;
    public static readonly Ksatisfies = 79;
    public static readonly Kcollation = 80;
    public static readonly Kgreatest = 81;
    public static readonly Kleast = 82;
    public static readonly Kswitch = 83;
    public static readonly Kcase = 84;
    public static readonly Ktry = 85;
    public static readonly Kcatch = 86;
    public static readonly Kdefault = 87;
    public static readonly Kthen = 88;
    public static readonly Kelse = 89;
    public static readonly Ktypeswitch = 90;
    public static readonly Kor = 91;
    public static readonly Kand = 92;
    public static readonly Knot = 93;
    public static readonly Kto = 94;
    public static readonly Kinstance = 95;
    public static readonly Kof = 96;
    public static readonly Kstatically = 97;
    public static readonly Kis = 98;
    public static readonly Ktreat = 99;
    public static readonly Kcast = 100;
    public static readonly Kcastable = 101;
    public static readonly Kversion = 102;
    public static readonly Kjsoniq = 103;
    public static readonly Kunordered = 104;
    public static readonly Ktrue = 105;
    public static readonly Kfalse = 106;
    public static readonly Ktype = 107;
    public static readonly Kvalidate = 108;
    public static readonly Kannotate = 109;
    public static readonly Kdeclare = 110;
    public static readonly Kcontext = 111;
    public static readonly Kitem = 112;
    public static readonly Kvariable = 113;
    public static readonly Kinsert = 114;
    public static readonly Kdelete = 115;
    public static readonly Krename = 116;
    public static readonly Kreplace = 117;
    public static readonly Kcopy = 118;
    public static readonly Kmodify = 119;
    public static readonly Kappend = 120;
    public static readonly Kinto = 121;
    public static readonly Kvalue = 122;
    public static readonly Kwith = 123;
    public static readonly Kposition = 124;
    public static readonly Kjson = 125;
    public static readonly Kupdating = 126;
    public static readonly Kcreate = 127;
    public static readonly Kcollection = 128;
    public static readonly Ktable = 129;
    public static readonly Kdeltafile = 130;
    public static readonly Kicebergtable = 131;
    public static readonly Ktruncate = 132;
    public static readonly Kfirst = 133;
    public static readonly Klast = 134;
    public static readonly Kfrom = 135;
    public static readonly Kedit = 136;
    public static readonly Kafter = 137;
    public static readonly Kbefore = 138;
    public static readonly Kimport = 139;
    public static readonly Kschema = 140;
    public static readonly Knamespace = 141;
    public static readonly Kelement = 142;
    public static readonly Kslash = 143;
    public static readonly Kdslash = 144;
    public static readonly Kat_symbol = 145;
    public static readonly Kchild = 146;
    public static readonly Kdescendant = 147;
    public static readonly Kattribute = 148;
    public static readonly Kself = 149;
    public static readonly Kdescendant_or_self = 150;
    public static readonly Kfollowing_sibling = 151;
    public static readonly Kfollowing = 152;
    public static readonly Kparent = 153;
    public static readonly Kancestor = 154;
    public static readonly Kpreceding_sibling = 155;
    public static readonly Kpreceding = 156;
    public static readonly Kancestor_or_self = 157;
    public static readonly Knode = 158;
    public static readonly Kbinary = 159;
    public static readonly Kdocument = 160;
    public static readonly Kdocument_node = 161;
    public static readonly Ktext = 162;
    public static readonly Kpi = 163;
    public static readonly Knamespace_node = 164;
    public static readonly Kschema_attribute = 165;
    public static readonly Kschema_element = 166;
    public static readonly Karray_node = 167;
    public static readonly Kboolean_node = 168;
    public static readonly Knull_node = 169;
    public static readonly Knumber_node = 170;
    public static readonly Kobject_node = 171;
    public static readonly Kcomment = 172;
    public static readonly Kbreak = 173;
    public static readonly Kloop = 174;
    public static readonly Kcontinue = 175;
    public static readonly Kexit = 176;
    public static readonly Kreturning = 177;
    public static readonly Kwhile = 178;
    public static readonly STRING = 179;
    public static readonly ArgumentPlaceholder = 180;
    public static readonly NullLiteral = 181;
    public static readonly Literal = 182;
    public static readonly NumericLiteral = 183;
    public static readonly IntegerLiteral = 184;
    public static readonly DecimalLiteral = 185;
    public static readonly DoubleLiteral = 186;
    public static readonly WS = 187;
    public static readonly NCName = 188;
    public static readonly XQComment = 189;
    public static readonly ContentChar = 190;

    public static readonly channelNames = [
        "DEFAULT_TOKEN_CHANNEL", "HIDDEN"
    ];

    public static readonly literalNames = [
        null, "';'", "'module'", "'='", "'$'", "':='", "'{'", "'}'", "'('", 
        "')'", "'*'", "'|'", "'%'", "','", "'base-uri'", "'ordering'", "'ordered'", 
        "'decimal-format'", "':'", "'decimal-separator'", "'grouping-separator'", 
        "'infinity'", "'minus-sign'", "'NaN'", "'percent'", "'per-mille'", 
        "'zero-digit'", "'digit'", "'pattern-separator'", "'external'", 
        "'function'", "'jsound'", "'compact'", "'verbose'", "'eq'", "'ne'", 
        "'lt'", "'le'", "'gt'", "'ge'", "'!='", "'<'", "'<='", "'>'", "'>='", 
        "'||'", "'+'", "'-'", "'div'", "'idiv'", "'mod'", "'!'", "'['", 
        "']'", "'.'", "'$$'", "'#'", "'..'", "'{|'", "'|}'", "'for'", "'let'", 
        "'where'", "'group'", "'by'", "'order'", "'return'", "'if'", "'in'", 
        "'as'", "'at'", "'allowing'", "'empty'", "'count'", "'stable'", 
        "'ascending'", "'descending'", "'some'", "'every'", "'satisfies'", 
        "'collation'", "'greatest'", "'least'", "'switch'", "'case'", "'try'", 
        "'catch'", "'default'", "'then'", "'else'", "'typeswitch'", "'or'", 
        "'and'", "'not'", "'to'", "'instance'", "'of'", "'statically'", 
        "'is'", "'treat'", "'cast'", "'castable'", "'version'", "'jsoniq'", 
        "'unordered'", "'true'", "'false'", "'type'", "'validate'", "'annotate'", 
        "'declare'", "'context'", "'item'", "'variable'", "'insert'", "'delete'", 
        "'rename'", "'replace'", "'copy'", "'modify'", "'append'", "'into'", 
        "'value'", "'with'", "'position'", "'json'", "'updating'", "'create'", 
        "'collection'", "'table'", "'delta-file'", "'iceberg-table'", "'truncate'", 
        "'first'", "'last'", "'from'", "'edit'", "'after'", "'before'", 
        "'import'", "'schema'", "'namespace'", "'element'", "'/'", "'//'", 
        "'@'", "'child'", "'descendant'", "'attribute'", "'self'", "'descendant-or-self'", 
        "'following-sibling'", "'following'", "'parent'", "'ancestor'", 
        "'preceding-sibling'", "'preceding'", "'ancestor-or-self'", "'node'", 
        "'binary'", "'document'", "'document-node'", "'text'", "'processing-instruction'", 
        "'namespace-node'", "'schema-attribute'", "'schema-element'", "'array-node'", 
        "'boolean-node'", "'null-node'", "'number-node'", "'object-node'", 
        "'comment'", "'break'", "'loop'", "'continue'", "'exit'", "'returning'", 
        "'while'", null, "'?'", "'null'"
    ];

    public static readonly symbolicNames = [
        null, "Ksemicolon", "Kmodule", "Kequal", "Kdollar", "Kassign", "Klbrace", 
        "Krbrace", "Klparen", "Krparen", "Kasterisk", "Kpipe", "Kannotation", 
        "Kcomma", "Kbase_uri", "Kordering", "Kordered", "Kdecimal_format", 
        "Kcolon", "Kdecimal_separator", "Kgrouping_separator", "Kinfinity", 
        "Kminus_sign", "Knan", "Kpercent", "Kper_mille", "Kzero_digit", 
        "Kdigit", "Kpattern_separator", "Kexternal", "Kfunction", "Kjsound", 
        "Kcompact", "Kverbose", "Keq", "Kne", "Klt", "Kle", "Kgt", "Kge", 
        "Knot_equal", "Kless", "Kless_or_equal", "Kgreater", "Kgreater_or_equal", 
        "Kconcat", "Kplus", "Kminus", "Kdiv", "Kidiv", "Kmod", "Kbang", 
        "Klbracket", "Krbracket", "Kdot", "Kcontext_item", "Khash", "Kdotdot", 
        "Kobject_start", "Kobject_end", "Kfor", "Klet", "Kwhere", "Kgroup", 
        "Kby", "Korder", "Kreturn", "Kif", "Kin", "Kas", "Kat", "Kallowing", 
        "Kempty", "Kcount", "Kstable", "Kascending", "Kdescending", "Ksome", 
        "Kevery", "Ksatisfies", "Kcollation", "Kgreatest", "Kleast", "Kswitch", 
        "Kcase", "Ktry", "Kcatch", "Kdefault", "Kthen", "Kelse", "Ktypeswitch", 
        "Kor", "Kand", "Knot", "Kto", "Kinstance", "Kof", "Kstatically", 
        "Kis", "Ktreat", "Kcast", "Kcastable", "Kversion", "Kjsoniq", "Kunordered", 
        "Ktrue", "Kfalse", "Ktype", "Kvalidate", "Kannotate", "Kdeclare", 
        "Kcontext", "Kitem", "Kvariable", "Kinsert", "Kdelete", "Krename", 
        "Kreplace", "Kcopy", "Kmodify", "Kappend", "Kinto", "Kvalue", "Kwith", 
        "Kposition", "Kjson", "Kupdating", "Kcreate", "Kcollection", "Ktable", 
        "Kdeltafile", "Kicebergtable", "Ktruncate", "Kfirst", "Klast", "Kfrom", 
        "Kedit", "Kafter", "Kbefore", "Kimport", "Kschema", "Knamespace", 
        "Kelement", "Kslash", "Kdslash", "Kat_symbol", "Kchild", "Kdescendant", 
        "Kattribute", "Kself", "Kdescendant_or_self", "Kfollowing_sibling", 
        "Kfollowing", "Kparent", "Kancestor", "Kpreceding_sibling", "Kpreceding", 
        "Kancestor_or_self", "Knode", "Kbinary", "Kdocument", "Kdocument_node", 
        "Ktext", "Kpi", "Knamespace_node", "Kschema_attribute", "Kschema_element", 
        "Karray_node", "Kboolean_node", "Knull_node", "Knumber_node", "Kobject_node", 
        "Kcomment", "Kbreak", "Kloop", "Kcontinue", "Kexit", "Kreturning", 
        "Kwhile", "STRING", "ArgumentPlaceholder", "NullLiteral", "Literal", 
        "NumericLiteral", "IntegerLiteral", "DecimalLiteral", "DoubleLiteral", 
        "WS", "NCName", "XQComment", "ContentChar"
    ];

    public static readonly modeNames = [
        "DEFAULT_MODE",
    ];

    public static readonly ruleNames = [
        "Ksemicolon", "Kmodule", "Kequal", "Kdollar", "Kassign", "Klbrace", 
        "Krbrace", "Klparen", "Krparen", "Kasterisk", "Kpipe", "Kannotation", 
        "Kcomma", "Kbase_uri", "Kordering", "Kordered", "Kdecimal_format", 
        "Kcolon", "Kdecimal_separator", "Kgrouping_separator", "Kinfinity", 
        "Kminus_sign", "Knan", "Kpercent", "Kper_mille", "Kzero_digit", 
        "Kdigit", "Kpattern_separator", "Kexternal", "Kfunction", "Kjsound", 
        "Kcompact", "Kverbose", "Keq", "Kne", "Klt", "Kle", "Kgt", "Kge", 
        "Knot_equal", "Kless", "Kless_or_equal", "Kgreater", "Kgreater_or_equal", 
        "Kconcat", "Kplus", "Kminus", "Kdiv", "Kidiv", "Kmod", "Kbang", 
        "Klbracket", "Krbracket", "Kdot", "Kcontext_item", "Khash", "Kdotdot", 
        "Kobject_start", "Kobject_end", "Kfor", "Klet", "Kwhere", "Kgroup", 
        "Kby", "Korder", "Kreturn", "Kif", "Kin", "Kas", "Kat", "Kallowing", 
        "Kempty", "Kcount", "Kstable", "Kascending", "Kdescending", "Ksome", 
        "Kevery", "Ksatisfies", "Kcollation", "Kgreatest", "Kleast", "Kswitch", 
        "Kcase", "Ktry", "Kcatch", "Kdefault", "Kthen", "Kelse", "Ktypeswitch", 
        "Kor", "Kand", "Knot", "Kto", "Kinstance", "Kof", "Kstatically", 
        "Kis", "Ktreat", "Kcast", "Kcastable", "Kversion", "Kjsoniq", "Kunordered", 
        "Ktrue", "Kfalse", "Ktype", "Kvalidate", "Kannotate", "Kdeclare", 
        "Kcontext", "Kitem", "Kvariable", "Kinsert", "Kdelete", "Krename", 
        "Kreplace", "Kcopy", "Kmodify", "Kappend", "Kinto", "Kvalue", "Kwith", 
        "Kposition", "Kjson", "Kupdating", "Kcreate", "Kcollection", "Ktable", 
        "Kdeltafile", "Kicebergtable", "Ktruncate", "Kfirst", "Klast", "Kfrom", 
        "Kedit", "Kafter", "Kbefore", "Kimport", "Kschema", "Knamespace", 
        "Kelement", "Kslash", "Kdslash", "Kat_symbol", "Kchild", "Kdescendant", 
        "Kattribute", "Kself", "Kdescendant_or_self", "Kfollowing_sibling", 
        "Kfollowing", "Kparent", "Kancestor", "Kpreceding_sibling", "Kpreceding", 
        "Kancestor_or_self", "Knode", "Kbinary", "Kdocument", "Kdocument_node", 
        "Ktext", "Kpi", "Knamespace_node", "Kschema_attribute", "Kschema_element", 
        "Karray_node", "Kboolean_node", "Knull_node", "Knumber_node", "Kobject_node", 
        "Kcomment", "Kbreak", "Kloop", "Kcontinue", "Kexit", "Kreturning", 
        "Kwhile", "STRING", "ESC", "ESCapos", "UNICODE", "HEX", "ArgumentPlaceholder", 
        "NullLiteral", "Literal", "NumericLiteral", "IntegerLiteral", "DecimalLiteral", 
        "DoubleLiteral", "Digits", "WS", "NCName", "NameStartChar", "NameChar", 
        "XQComment", "ContentChar",
    ];


    public constructor(input: antlr.CharStream) {
        super(input);
        this.interpreter = new antlr.LexerATNSimulator(this, jsoniqLexer._ATN, jsoniqLexer.decisionsToDFA, new antlr.PredictionContextCache());
    }

    public get grammarFileName(): string { return "jsoniq.g4"; }

    public get literalNames(): (string | null)[] { return jsoniqLexer.literalNames; }
    public get symbolicNames(): (string | null)[] { return jsoniqLexer.symbolicNames; }
    public get ruleNames(): string[] { return jsoniqLexer.ruleNames; }

    public get serializedATN(): number[] { return jsoniqLexer._serializedATN; }

    public get channelNames(): string[] { return jsoniqLexer.channelNames; }

    public get modeNames(): string[] { return jsoniqLexer.modeNames; }

    public static readonly _serializedATN: number[] = [
        4,0,190,1749,6,-1,2,0,7,0,2,1,7,1,2,2,7,2,2,3,7,3,2,4,7,4,2,5,7,
        5,2,6,7,6,2,7,7,7,2,8,7,8,2,9,7,9,2,10,7,10,2,11,7,11,2,12,7,12,
        2,13,7,13,2,14,7,14,2,15,7,15,2,16,7,16,2,17,7,17,2,18,7,18,2,19,
        7,19,2,20,7,20,2,21,7,21,2,22,7,22,2,23,7,23,2,24,7,24,2,25,7,25,
        2,26,7,26,2,27,7,27,2,28,7,28,2,29,7,29,2,30,7,30,2,31,7,31,2,32,
        7,32,2,33,7,33,2,34,7,34,2,35,7,35,2,36,7,36,2,37,7,37,2,38,7,38,
        2,39,7,39,2,40,7,40,2,41,7,41,2,42,7,42,2,43,7,43,2,44,7,44,2,45,
        7,45,2,46,7,46,2,47,7,47,2,48,7,48,2,49,7,49,2,50,7,50,2,51,7,51,
        2,52,7,52,2,53,7,53,2,54,7,54,2,55,7,55,2,56,7,56,2,57,7,57,2,58,
        7,58,2,59,7,59,2,60,7,60,2,61,7,61,2,62,7,62,2,63,7,63,2,64,7,64,
        2,65,7,65,2,66,7,66,2,67,7,67,2,68,7,68,2,69,7,69,2,70,7,70,2,71,
        7,71,2,72,7,72,2,73,7,73,2,74,7,74,2,75,7,75,2,76,7,76,2,77,7,77,
        2,78,7,78,2,79,7,79,2,80,7,80,2,81,7,81,2,82,7,82,2,83,7,83,2,84,
        7,84,2,85,7,85,2,86,7,86,2,87,7,87,2,88,7,88,2,89,7,89,2,90,7,90,
        2,91,7,91,2,92,7,92,2,93,7,93,2,94,7,94,2,95,7,95,2,96,7,96,2,97,
        7,97,2,98,7,98,2,99,7,99,2,100,7,100,2,101,7,101,2,102,7,102,2,103,
        7,103,2,104,7,104,2,105,7,105,2,106,7,106,2,107,7,107,2,108,7,108,
        2,109,7,109,2,110,7,110,2,111,7,111,2,112,7,112,2,113,7,113,2,114,
        7,114,2,115,7,115,2,116,7,116,2,117,7,117,2,118,7,118,2,119,7,119,
        2,120,7,120,2,121,7,121,2,122,7,122,2,123,7,123,2,124,7,124,2,125,
        7,125,2,126,7,126,2,127,7,127,2,128,7,128,2,129,7,129,2,130,7,130,
        2,131,7,131,2,132,7,132,2,133,7,133,2,134,7,134,2,135,7,135,2,136,
        7,136,2,137,7,137,2,138,7,138,2,139,7,139,2,140,7,140,2,141,7,141,
        2,142,7,142,2,143,7,143,2,144,7,144,2,145,7,145,2,146,7,146,2,147,
        7,147,2,148,7,148,2,149,7,149,2,150,7,150,2,151,7,151,2,152,7,152,
        2,153,7,153,2,154,7,154,2,155,7,155,2,156,7,156,2,157,7,157,2,158,
        7,158,2,159,7,159,2,160,7,160,2,161,7,161,2,162,7,162,2,163,7,163,
        2,164,7,164,2,165,7,165,2,166,7,166,2,167,7,167,2,168,7,168,2,169,
        7,169,2,170,7,170,2,171,7,171,2,172,7,172,2,173,7,173,2,174,7,174,
        2,175,7,175,2,176,7,176,2,177,7,177,2,178,7,178,2,179,7,179,2,180,
        7,180,2,181,7,181,2,182,7,182,2,183,7,183,2,184,7,184,2,185,7,185,
        2,186,7,186,2,187,7,187,2,188,7,188,2,189,7,189,2,190,7,190,2,191,
        7,191,2,192,7,192,2,193,7,193,2,194,7,194,2,195,7,195,2,196,7,196,
        1,0,1,0,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,2,1,2,1,3,1,3,1,4,1,4,1,4,
        1,5,1,5,1,6,1,6,1,7,1,7,1,8,1,8,1,9,1,9,1,10,1,10,1,11,1,11,1,12,
        1,12,1,13,1,13,1,13,1,13,1,13,1,13,1,13,1,13,1,13,1,14,1,14,1,14,
        1,14,1,14,1,14,1,14,1,14,1,14,1,15,1,15,1,15,1,15,1,15,1,15,1,15,
        1,15,1,16,1,16,1,16,1,16,1,16,1,16,1,16,1,16,1,16,1,16,1,16,1,16,
        1,16,1,16,1,16,1,17,1,17,1,18,1,18,1,18,1,18,1,18,1,18,1,18,1,18,
        1,18,1,18,1,18,1,18,1,18,1,18,1,18,1,18,1,18,1,18,1,19,1,19,1,19,
        1,19,1,19,1,19,1,19,1,19,1,19,1,19,1,19,1,19,1,19,1,19,1,19,1,19,
        1,19,1,19,1,19,1,20,1,20,1,20,1,20,1,20,1,20,1,20,1,20,1,20,1,21,
        1,21,1,21,1,21,1,21,1,21,1,21,1,21,1,21,1,21,1,21,1,22,1,22,1,22,
        1,22,1,23,1,23,1,23,1,23,1,23,1,23,1,23,1,23,1,24,1,24,1,24,1,24,
        1,24,1,24,1,24,1,24,1,24,1,24,1,25,1,25,1,25,1,25,1,25,1,25,1,25,
        1,25,1,25,1,25,1,25,1,26,1,26,1,26,1,26,1,26,1,26,1,27,1,27,1,27,
        1,27,1,27,1,27,1,27,1,27,1,27,1,27,1,27,1,27,1,27,1,27,1,27,1,27,
        1,27,1,27,1,28,1,28,1,28,1,28,1,28,1,28,1,28,1,28,1,28,1,29,1,29,
        1,29,1,29,1,29,1,29,1,29,1,29,1,29,1,30,1,30,1,30,1,30,1,30,1,30,
        1,30,1,31,1,31,1,31,1,31,1,31,1,31,1,31,1,31,1,32,1,32,1,32,1,32,
        1,32,1,32,1,32,1,32,1,33,1,33,1,33,1,34,1,34,1,34,1,35,1,35,1,35,
        1,36,1,36,1,36,1,37,1,37,1,37,1,38,1,38,1,38,1,39,1,39,1,39,1,40,
        1,40,1,41,1,41,1,41,1,42,1,42,1,43,1,43,1,43,1,44,1,44,1,44,1,45,
        1,45,1,46,1,46,1,47,1,47,1,47,1,47,1,48,1,48,1,48,1,48,1,48,1,49,
        1,49,1,49,1,49,1,50,1,50,1,51,1,51,1,52,1,52,1,53,1,53,1,54,1,54,
        1,54,1,55,1,55,1,56,1,56,1,56,1,57,1,57,1,57,1,58,1,58,1,58,1,59,
        1,59,1,59,1,59,1,60,1,60,1,60,1,60,1,61,1,61,1,61,1,61,1,61,1,61,
        1,62,1,62,1,62,1,62,1,62,1,62,1,63,1,63,1,63,1,64,1,64,1,64,1,64,
        1,64,1,64,1,65,1,65,1,65,1,65,1,65,1,65,1,65,1,66,1,66,1,66,1,67,
        1,67,1,67,1,68,1,68,1,68,1,69,1,69,1,69,1,70,1,70,1,70,1,70,1,70,
        1,70,1,70,1,70,1,70,1,71,1,71,1,71,1,71,1,71,1,71,1,72,1,72,1,72,
        1,72,1,72,1,72,1,73,1,73,1,73,1,73,1,73,1,73,1,73,1,74,1,74,1,74,
        1,74,1,74,1,74,1,74,1,74,1,74,1,74,1,75,1,75,1,75,1,75,1,75,1,75,
        1,75,1,75,1,75,1,75,1,75,1,76,1,76,1,76,1,76,1,76,1,77,1,77,1,77,
        1,77,1,77,1,77,1,78,1,78,1,78,1,78,1,78,1,78,1,78,1,78,1,78,1,78,
        1,79,1,79,1,79,1,79,1,79,1,79,1,79,1,79,1,79,1,79,1,80,1,80,1,80,
        1,80,1,80,1,80,1,80,1,80,1,80,1,81,1,81,1,81,1,81,1,81,1,81,1,82,
        1,82,1,82,1,82,1,82,1,82,1,82,1,83,1,83,1,83,1,83,1,83,1,84,1,84,
        1,84,1,84,1,85,1,85,1,85,1,85,1,85,1,85,1,86,1,86,1,86,1,86,1,86,
        1,86,1,86,1,86,1,87,1,87,1,87,1,87,1,87,1,88,1,88,1,88,1,88,1,88,
        1,89,1,89,1,89,1,89,1,89,1,89,1,89,1,89,1,89,1,89,1,89,1,90,1,90,
        1,90,1,91,1,91,1,91,1,91,1,92,1,92,1,92,1,92,1,93,1,93,1,93,1,94,
        1,94,1,94,1,94,1,94,1,94,1,94,1,94,1,94,1,95,1,95,1,95,1,96,1,96,
        1,96,1,96,1,96,1,96,1,96,1,96,1,96,1,96,1,96,1,97,1,97,1,97,1,98,
        1,98,1,98,1,98,1,98,1,98,1,99,1,99,1,99,1,99,1,99,1,100,1,100,1,
        100,1,100,1,100,1,100,1,100,1,100,1,100,1,101,1,101,1,101,1,101,
        1,101,1,101,1,101,1,101,1,102,1,102,1,102,1,102,1,102,1,102,1,102,
        1,103,1,103,1,103,1,103,1,103,1,103,1,103,1,103,1,103,1,103,1,104,
        1,104,1,104,1,104,1,104,1,105,1,105,1,105,1,105,1,105,1,105,1,106,
        1,106,1,106,1,106,1,106,1,107,1,107,1,107,1,107,1,107,1,107,1,107,
        1,107,1,107,1,108,1,108,1,108,1,108,1,108,1,108,1,108,1,108,1,108,
        1,109,1,109,1,109,1,109,1,109,1,109,1,109,1,109,1,110,1,110,1,110,
        1,110,1,110,1,110,1,110,1,110,1,111,1,111,1,111,1,111,1,111,1,112,
        1,112,1,112,1,112,1,112,1,112,1,112,1,112,1,112,1,113,1,113,1,113,
        1,113,1,113,1,113,1,113,1,114,1,114,1,114,1,114,1,114,1,114,1,114,
        1,115,1,115,1,115,1,115,1,115,1,115,1,115,1,116,1,116,1,116,1,116,
        1,116,1,116,1,116,1,116,1,117,1,117,1,117,1,117,1,117,1,118,1,118,
        1,118,1,118,1,118,1,118,1,118,1,119,1,119,1,119,1,119,1,119,1,119,
        1,119,1,120,1,120,1,120,1,120,1,120,1,121,1,121,1,121,1,121,1,121,
        1,121,1,122,1,122,1,122,1,122,1,122,1,123,1,123,1,123,1,123,1,123,
        1,123,1,123,1,123,1,123,1,124,1,124,1,124,1,124,1,124,1,125,1,125,
        1,125,1,125,1,125,1,125,1,125,1,125,1,125,1,126,1,126,1,126,1,126,
        1,126,1,126,1,126,1,127,1,127,1,127,1,127,1,127,1,127,1,127,1,127,
        1,127,1,127,1,127,1,128,1,128,1,128,1,128,1,128,1,128,1,129,1,129,
        1,129,1,129,1,129,1,129,1,129,1,129,1,129,1,129,1,129,1,130,1,130,
        1,130,1,130,1,130,1,130,1,130,1,130,1,130,1,130,1,130,1,130,1,130,
        1,130,1,131,1,131,1,131,1,131,1,131,1,131,1,131,1,131,1,131,1,132,
        1,132,1,132,1,132,1,132,1,132,1,133,1,133,1,133,1,133,1,133,1,134,
        1,134,1,134,1,134,1,134,1,135,1,135,1,135,1,135,1,135,1,136,1,136,
        1,136,1,136,1,136,1,136,1,137,1,137,1,137,1,137,1,137,1,137,1,137,
        1,138,1,138,1,138,1,138,1,138,1,138,1,138,1,139,1,139,1,139,1,139,
        1,139,1,139,1,139,1,140,1,140,1,140,1,140,1,140,1,140,1,140,1,140,
        1,140,1,140,1,141,1,141,1,141,1,141,1,141,1,141,1,141,1,141,1,142,
        1,142,1,143,1,143,1,143,1,144,1,144,1,145,1,145,1,145,1,145,1,145,
        1,145,1,146,1,146,1,146,1,146,1,146,1,146,1,146,1,146,1,146,1,146,
        1,146,1,147,1,147,1,147,1,147,1,147,1,147,1,147,1,147,1,147,1,147,
        1,148,1,148,1,148,1,148,1,148,1,149,1,149,1,149,1,149,1,149,1,149,
        1,149,1,149,1,149,1,149,1,149,1,149,1,149,1,149,1,149,1,149,1,149,
        1,149,1,149,1,150,1,150,1,150,1,150,1,150,1,150,1,150,1,150,1,150,
        1,150,1,150,1,150,1,150,1,150,1,150,1,150,1,150,1,150,1,151,1,151,
        1,151,1,151,1,151,1,151,1,151,1,151,1,151,1,151,1,152,1,152,1,152,
        1,152,1,152,1,152,1,152,1,153,1,153,1,153,1,153,1,153,1,153,1,153,
        1,153,1,153,1,154,1,154,1,154,1,154,1,154,1,154,1,154,1,154,1,154,
        1,154,1,154,1,154,1,154,1,154,1,154,1,154,1,154,1,154,1,155,1,155,
        1,155,1,155,1,155,1,155,1,155,1,155,1,155,1,155,1,156,1,156,1,156,
        1,156,1,156,1,156,1,156,1,156,1,156,1,156,1,156,1,156,1,156,1,156,
        1,156,1,156,1,156,1,157,1,157,1,157,1,157,1,157,1,158,1,158,1,158,
        1,158,1,158,1,158,1,158,1,159,1,159,1,159,1,159,1,159,1,159,1,159,
        1,159,1,159,1,160,1,160,1,160,1,160,1,160,1,160,1,160,1,160,1,160,
        1,160,1,160,1,160,1,160,1,160,1,161,1,161,1,161,1,161,1,161,1,162,
        1,162,1,162,1,162,1,162,1,162,1,162,1,162,1,162,1,162,1,162,1,162,
        1,162,1,162,1,162,1,162,1,162,1,162,1,162,1,162,1,162,1,162,1,162,
        1,163,1,163,1,163,1,163,1,163,1,163,1,163,1,163,1,163,1,163,1,163,
        1,163,1,163,1,163,1,163,1,164,1,164,1,164,1,164,1,164,1,164,1,164,
        1,164,1,164,1,164,1,164,1,164,1,164,1,164,1,164,1,164,1,164,1,165,
        1,165,1,165,1,165,1,165,1,165,1,165,1,165,1,165,1,165,1,165,1,165,
        1,165,1,165,1,165,1,166,1,166,1,166,1,166,1,166,1,166,1,166,1,166,
        1,166,1,166,1,166,1,167,1,167,1,167,1,167,1,167,1,167,1,167,1,167,
        1,167,1,167,1,167,1,167,1,167,1,168,1,168,1,168,1,168,1,168,1,168,
        1,168,1,168,1,168,1,168,1,169,1,169,1,169,1,169,1,169,1,169,1,169,
        1,169,1,169,1,169,1,169,1,169,1,170,1,170,1,170,1,170,1,170,1,170,
        1,170,1,170,1,170,1,170,1,170,1,170,1,171,1,171,1,171,1,171,1,171,
        1,171,1,171,1,171,1,172,1,172,1,172,1,172,1,172,1,172,1,173,1,173,
        1,173,1,173,1,173,1,174,1,174,1,174,1,174,1,174,1,174,1,174,1,174,
        1,174,1,175,1,175,1,175,1,175,1,175,1,176,1,176,1,176,1,176,1,176,
        1,176,1,176,1,176,1,176,1,176,1,177,1,177,1,177,1,177,1,177,1,177,
        1,178,1,178,1,178,5,178,1620,8,178,10,178,12,178,1623,9,178,1,178,
        1,178,1,178,1,178,5,178,1629,8,178,10,178,12,178,1632,9,178,1,178,
        3,178,1635,8,178,1,179,1,179,1,179,3,179,1640,8,179,1,180,1,180,
        1,180,3,180,1645,8,180,1,181,1,181,1,181,1,181,1,181,1,181,1,182,
        1,182,1,183,1,183,1,184,1,184,1,184,1,184,1,184,1,185,1,185,1,186,
        1,186,1,186,3,186,1667,8,186,1,187,1,187,1,188,1,188,1,188,1,188,
        1,188,5,188,1676,8,188,10,188,12,188,1679,9,188,3,188,1681,8,188,
        1,189,1,189,1,189,1,189,1,189,5,189,1688,8,189,10,189,12,189,1691,
        9,189,3,189,1693,8,189,3,189,1695,8,189,1,189,1,189,3,189,1699,8,
        189,1,189,1,189,1,190,4,190,1704,8,190,11,190,12,190,1705,1,191,
        1,191,1,191,1,191,1,192,1,192,5,192,1714,8,192,10,192,12,192,1717,
        9,192,1,193,3,193,1720,8,193,1,194,1,194,3,194,1724,8,194,1,195,
        1,195,1,195,1,195,1,195,1,195,1,195,1,195,5,195,1734,8,195,10,195,
        12,195,1737,9,195,1,195,4,195,1740,8,195,11,195,12,195,1741,1,195,
        1,195,1,195,1,195,1,196,1,196,0,0,197,1,1,3,2,5,3,7,4,9,5,11,6,13,
        7,15,8,17,9,19,10,21,11,23,12,25,13,27,14,29,15,31,16,33,17,35,18,
        37,19,39,20,41,21,43,22,45,23,47,24,49,25,51,26,53,27,55,28,57,29,
        59,30,61,31,63,32,65,33,67,34,69,35,71,36,73,37,75,38,77,39,79,40,
        81,41,83,42,85,43,87,44,89,45,91,46,93,47,95,48,97,49,99,50,101,
        51,103,52,105,53,107,54,109,55,111,56,113,57,115,58,117,59,119,60,
        121,61,123,62,125,63,127,64,129,65,131,66,133,67,135,68,137,69,139,
        70,141,71,143,72,145,73,147,74,149,75,151,76,153,77,155,78,157,79,
        159,80,161,81,163,82,165,83,167,84,169,85,171,86,173,87,175,88,177,
        89,179,90,181,91,183,92,185,93,187,94,189,95,191,96,193,97,195,98,
        197,99,199,100,201,101,203,102,205,103,207,104,209,105,211,106,213,
        107,215,108,217,109,219,110,221,111,223,112,225,113,227,114,229,
        115,231,116,233,117,235,118,237,119,239,120,241,121,243,122,245,
        123,247,124,249,125,251,126,253,127,255,128,257,129,259,130,261,
        131,263,132,265,133,267,134,269,135,271,136,273,137,275,138,277,
        139,279,140,281,141,283,142,285,143,287,144,289,145,291,146,293,
        147,295,148,297,149,299,150,301,151,303,152,305,153,307,154,309,
        155,311,156,313,157,315,158,317,159,319,160,321,161,323,162,325,
        163,327,164,329,165,331,166,333,167,335,168,337,169,339,170,341,
        171,343,172,345,173,347,174,349,175,351,176,353,177,355,178,357,
        179,359,0,361,0,363,0,365,0,367,180,369,181,371,182,373,183,375,
        184,377,185,379,186,381,0,383,187,385,188,387,0,389,0,391,189,393,
        190,1,0,15,2,0,34,34,92,92,2,0,39,39,92,92,8,0,34,34,47,47,92,92,
        98,98,102,102,110,110,114,114,116,116,8,0,39,39,47,47,92,92,98,98,
        102,102,110,110,114,114,116,116,3,0,48,57,65,70,97,102,1,0,48,57,
        2,0,69,69,101,101,2,0,43,43,45,45,3,0,9,10,13,13,32,32,14,0,65,90,
        95,95,97,122,192,214,216,246,248,767,880,893,895,8191,8204,8205,
        8304,8591,11264,12271,12289,55295,63744,64975,65008,65533,5,0,45,
        45,48,57,183,183,768,879,8255,8256,1,0,58,58,1,0,41,41,2,0,40,40,
        58,58,5,0,34,34,38,39,60,60,123,123,125,125,1764,0,1,1,0,0,0,0,3,
        1,0,0,0,0,5,1,0,0,0,0,7,1,0,0,0,0,9,1,0,0,0,0,11,1,0,0,0,0,13,1,
        0,0,0,0,15,1,0,0,0,0,17,1,0,0,0,0,19,1,0,0,0,0,21,1,0,0,0,0,23,1,
        0,0,0,0,25,1,0,0,0,0,27,1,0,0,0,0,29,1,0,0,0,0,31,1,0,0,0,0,33,1,
        0,0,0,0,35,1,0,0,0,0,37,1,0,0,0,0,39,1,0,0,0,0,41,1,0,0,0,0,43,1,
        0,0,0,0,45,1,0,0,0,0,47,1,0,0,0,0,49,1,0,0,0,0,51,1,0,0,0,0,53,1,
        0,0,0,0,55,1,0,0,0,0,57,1,0,0,0,0,59,1,0,0,0,0,61,1,0,0,0,0,63,1,
        0,0,0,0,65,1,0,0,0,0,67,1,0,0,0,0,69,1,0,0,0,0,71,1,0,0,0,0,73,1,
        0,0,0,0,75,1,0,0,0,0,77,1,0,0,0,0,79,1,0,0,0,0,81,1,0,0,0,0,83,1,
        0,0,0,0,85,1,0,0,0,0,87,1,0,0,0,0,89,1,0,0,0,0,91,1,0,0,0,0,93,1,
        0,0,0,0,95,1,0,0,0,0,97,1,0,0,0,0,99,1,0,0,0,0,101,1,0,0,0,0,103,
        1,0,0,0,0,105,1,0,0,0,0,107,1,0,0,0,0,109,1,0,0,0,0,111,1,0,0,0,
        0,113,1,0,0,0,0,115,1,0,0,0,0,117,1,0,0,0,0,119,1,0,0,0,0,121,1,
        0,0,0,0,123,1,0,0,0,0,125,1,0,0,0,0,127,1,0,0,0,0,129,1,0,0,0,0,
        131,1,0,0,0,0,133,1,0,0,0,0,135,1,0,0,0,0,137,1,0,0,0,0,139,1,0,
        0,0,0,141,1,0,0,0,0,143,1,0,0,0,0,145,1,0,0,0,0,147,1,0,0,0,0,149,
        1,0,0,0,0,151,1,0,0,0,0,153,1,0,0,0,0,155,1,0,0,0,0,157,1,0,0,0,
        0,159,1,0,0,0,0,161,1,0,0,0,0,163,1,0,0,0,0,165,1,0,0,0,0,167,1,
        0,0,0,0,169,1,0,0,0,0,171,1,0,0,0,0,173,1,0,0,0,0,175,1,0,0,0,0,
        177,1,0,0,0,0,179,1,0,0,0,0,181,1,0,0,0,0,183,1,0,0,0,0,185,1,0,
        0,0,0,187,1,0,0,0,0,189,1,0,0,0,0,191,1,0,0,0,0,193,1,0,0,0,0,195,
        1,0,0,0,0,197,1,0,0,0,0,199,1,0,0,0,0,201,1,0,0,0,0,203,1,0,0,0,
        0,205,1,0,0,0,0,207,1,0,0,0,0,209,1,0,0,0,0,211,1,0,0,0,0,213,1,
        0,0,0,0,215,1,0,0,0,0,217,1,0,0,0,0,219,1,0,0,0,0,221,1,0,0,0,0,
        223,1,0,0,0,0,225,1,0,0,0,0,227,1,0,0,0,0,229,1,0,0,0,0,231,1,0,
        0,0,0,233,1,0,0,0,0,235,1,0,0,0,0,237,1,0,0,0,0,239,1,0,0,0,0,241,
        1,0,0,0,0,243,1,0,0,0,0,245,1,0,0,0,0,247,1,0,0,0,0,249,1,0,0,0,
        0,251,1,0,0,0,0,253,1,0,0,0,0,255,1,0,0,0,0,257,1,0,0,0,0,259,1,
        0,0,0,0,261,1,0,0,0,0,263,1,0,0,0,0,265,1,0,0,0,0,267,1,0,0,0,0,
        269,1,0,0,0,0,271,1,0,0,0,0,273,1,0,0,0,0,275,1,0,0,0,0,277,1,0,
        0,0,0,279,1,0,0,0,0,281,1,0,0,0,0,283,1,0,0,0,0,285,1,0,0,0,0,287,
        1,0,0,0,0,289,1,0,0,0,0,291,1,0,0,0,0,293,1,0,0,0,0,295,1,0,0,0,
        0,297,1,0,0,0,0,299,1,0,0,0,0,301,1,0,0,0,0,303,1,0,0,0,0,305,1,
        0,0,0,0,307,1,0,0,0,0,309,1,0,0,0,0,311,1,0,0,0,0,313,1,0,0,0,0,
        315,1,0,0,0,0,317,1,0,0,0,0,319,1,0,0,0,0,321,1,0,0,0,0,323,1,0,
        0,0,0,325,1,0,0,0,0,327,1,0,0,0,0,329,1,0,0,0,0,331,1,0,0,0,0,333,
        1,0,0,0,0,335,1,0,0,0,0,337,1,0,0,0,0,339,1,0,0,0,0,341,1,0,0,0,
        0,343,1,0,0,0,0,345,1,0,0,0,0,347,1,0,0,0,0,349,1,0,0,0,0,351,1,
        0,0,0,0,353,1,0,0,0,0,355,1,0,0,0,0,357,1,0,0,0,0,367,1,0,0,0,0,
        369,1,0,0,0,0,371,1,0,0,0,0,373,1,0,0,0,0,375,1,0,0,0,0,377,1,0,
        0,0,0,379,1,0,0,0,0,383,1,0,0,0,0,385,1,0,0,0,0,391,1,0,0,0,0,393,
        1,0,0,0,1,395,1,0,0,0,3,397,1,0,0,0,5,404,1,0,0,0,7,406,1,0,0,0,
        9,408,1,0,0,0,11,411,1,0,0,0,13,413,1,0,0,0,15,415,1,0,0,0,17,417,
        1,0,0,0,19,419,1,0,0,0,21,421,1,0,0,0,23,423,1,0,0,0,25,425,1,0,
        0,0,27,427,1,0,0,0,29,436,1,0,0,0,31,445,1,0,0,0,33,453,1,0,0,0,
        35,468,1,0,0,0,37,470,1,0,0,0,39,488,1,0,0,0,41,507,1,0,0,0,43,516,
        1,0,0,0,45,527,1,0,0,0,47,531,1,0,0,0,49,539,1,0,0,0,51,549,1,0,
        0,0,53,560,1,0,0,0,55,566,1,0,0,0,57,584,1,0,0,0,59,593,1,0,0,0,
        61,602,1,0,0,0,63,609,1,0,0,0,65,617,1,0,0,0,67,625,1,0,0,0,69,628,
        1,0,0,0,71,631,1,0,0,0,73,634,1,0,0,0,75,637,1,0,0,0,77,640,1,0,
        0,0,79,643,1,0,0,0,81,646,1,0,0,0,83,648,1,0,0,0,85,651,1,0,0,0,
        87,653,1,0,0,0,89,656,1,0,0,0,91,659,1,0,0,0,93,661,1,0,0,0,95,663,
        1,0,0,0,97,667,1,0,0,0,99,672,1,0,0,0,101,676,1,0,0,0,103,678,1,
        0,0,0,105,680,1,0,0,0,107,682,1,0,0,0,109,684,1,0,0,0,111,687,1,
        0,0,0,113,689,1,0,0,0,115,692,1,0,0,0,117,695,1,0,0,0,119,698,1,
        0,0,0,121,702,1,0,0,0,123,706,1,0,0,0,125,712,1,0,0,0,127,718,1,
        0,0,0,129,721,1,0,0,0,131,727,1,0,0,0,133,734,1,0,0,0,135,737,1,
        0,0,0,137,740,1,0,0,0,139,743,1,0,0,0,141,746,1,0,0,0,143,755,1,
        0,0,0,145,761,1,0,0,0,147,767,1,0,0,0,149,774,1,0,0,0,151,784,1,
        0,0,0,153,795,1,0,0,0,155,800,1,0,0,0,157,806,1,0,0,0,159,816,1,
        0,0,0,161,826,1,0,0,0,163,835,1,0,0,0,165,841,1,0,0,0,167,848,1,
        0,0,0,169,853,1,0,0,0,171,857,1,0,0,0,173,863,1,0,0,0,175,871,1,
        0,0,0,177,876,1,0,0,0,179,881,1,0,0,0,181,892,1,0,0,0,183,895,1,
        0,0,0,185,899,1,0,0,0,187,903,1,0,0,0,189,906,1,0,0,0,191,915,1,
        0,0,0,193,918,1,0,0,0,195,929,1,0,0,0,197,932,1,0,0,0,199,938,1,
        0,0,0,201,943,1,0,0,0,203,952,1,0,0,0,205,960,1,0,0,0,207,967,1,
        0,0,0,209,977,1,0,0,0,211,982,1,0,0,0,213,988,1,0,0,0,215,993,1,
        0,0,0,217,1002,1,0,0,0,219,1011,1,0,0,0,221,1019,1,0,0,0,223,1027,
        1,0,0,0,225,1032,1,0,0,0,227,1041,1,0,0,0,229,1048,1,0,0,0,231,1055,
        1,0,0,0,233,1062,1,0,0,0,235,1070,1,0,0,0,237,1075,1,0,0,0,239,1082,
        1,0,0,0,241,1089,1,0,0,0,243,1094,1,0,0,0,245,1100,1,0,0,0,247,1105,
        1,0,0,0,249,1114,1,0,0,0,251,1119,1,0,0,0,253,1128,1,0,0,0,255,1135,
        1,0,0,0,257,1146,1,0,0,0,259,1152,1,0,0,0,261,1163,1,0,0,0,263,1177,
        1,0,0,0,265,1186,1,0,0,0,267,1192,1,0,0,0,269,1197,1,0,0,0,271,1202,
        1,0,0,0,273,1207,1,0,0,0,275,1213,1,0,0,0,277,1220,1,0,0,0,279,1227,
        1,0,0,0,281,1234,1,0,0,0,283,1244,1,0,0,0,285,1252,1,0,0,0,287,1254,
        1,0,0,0,289,1257,1,0,0,0,291,1259,1,0,0,0,293,1265,1,0,0,0,295,1276,
        1,0,0,0,297,1286,1,0,0,0,299,1291,1,0,0,0,301,1310,1,0,0,0,303,1328,
        1,0,0,0,305,1338,1,0,0,0,307,1345,1,0,0,0,309,1354,1,0,0,0,311,1372,
        1,0,0,0,313,1382,1,0,0,0,315,1399,1,0,0,0,317,1404,1,0,0,0,319,1411,
        1,0,0,0,321,1420,1,0,0,0,323,1434,1,0,0,0,325,1439,1,0,0,0,327,1462,
        1,0,0,0,329,1477,1,0,0,0,331,1494,1,0,0,0,333,1509,1,0,0,0,335,1520,
        1,0,0,0,337,1533,1,0,0,0,339,1543,1,0,0,0,341,1555,1,0,0,0,343,1567,
        1,0,0,0,345,1575,1,0,0,0,347,1581,1,0,0,0,349,1586,1,0,0,0,351,1595,
        1,0,0,0,353,1600,1,0,0,0,355,1610,1,0,0,0,357,1634,1,0,0,0,359,1636,
        1,0,0,0,361,1641,1,0,0,0,363,1646,1,0,0,0,365,1652,1,0,0,0,367,1654,
        1,0,0,0,369,1656,1,0,0,0,371,1661,1,0,0,0,373,1666,1,0,0,0,375,1668,
        1,0,0,0,377,1680,1,0,0,0,379,1694,1,0,0,0,381,1703,1,0,0,0,383,1707,
        1,0,0,0,385,1711,1,0,0,0,387,1719,1,0,0,0,389,1723,1,0,0,0,391,1725,
        1,0,0,0,393,1747,1,0,0,0,395,396,5,59,0,0,396,2,1,0,0,0,397,398,
        5,109,0,0,398,399,5,111,0,0,399,400,5,100,0,0,400,401,5,117,0,0,
        401,402,5,108,0,0,402,403,5,101,0,0,403,4,1,0,0,0,404,405,5,61,0,
        0,405,6,1,0,0,0,406,407,5,36,0,0,407,8,1,0,0,0,408,409,5,58,0,0,
        409,410,5,61,0,0,410,10,1,0,0,0,411,412,5,123,0,0,412,12,1,0,0,0,
        413,414,5,125,0,0,414,14,1,0,0,0,415,416,5,40,0,0,416,16,1,0,0,0,
        417,418,5,41,0,0,418,18,1,0,0,0,419,420,5,42,0,0,420,20,1,0,0,0,
        421,422,5,124,0,0,422,22,1,0,0,0,423,424,5,37,0,0,424,24,1,0,0,0,
        425,426,5,44,0,0,426,26,1,0,0,0,427,428,5,98,0,0,428,429,5,97,0,
        0,429,430,5,115,0,0,430,431,5,101,0,0,431,432,5,45,0,0,432,433,5,
        117,0,0,433,434,5,114,0,0,434,435,5,105,0,0,435,28,1,0,0,0,436,437,
        5,111,0,0,437,438,5,114,0,0,438,439,5,100,0,0,439,440,5,101,0,0,
        440,441,5,114,0,0,441,442,5,105,0,0,442,443,5,110,0,0,443,444,5,
        103,0,0,444,30,1,0,0,0,445,446,5,111,0,0,446,447,5,114,0,0,447,448,
        5,100,0,0,448,449,5,101,0,0,449,450,5,114,0,0,450,451,5,101,0,0,
        451,452,5,100,0,0,452,32,1,0,0,0,453,454,5,100,0,0,454,455,5,101,
        0,0,455,456,5,99,0,0,456,457,5,105,0,0,457,458,5,109,0,0,458,459,
        5,97,0,0,459,460,5,108,0,0,460,461,5,45,0,0,461,462,5,102,0,0,462,
        463,5,111,0,0,463,464,5,114,0,0,464,465,5,109,0,0,465,466,5,97,0,
        0,466,467,5,116,0,0,467,34,1,0,0,0,468,469,5,58,0,0,469,36,1,0,0,
        0,470,471,5,100,0,0,471,472,5,101,0,0,472,473,5,99,0,0,473,474,5,
        105,0,0,474,475,5,109,0,0,475,476,5,97,0,0,476,477,5,108,0,0,477,
        478,5,45,0,0,478,479,5,115,0,0,479,480,5,101,0,0,480,481,5,112,0,
        0,481,482,5,97,0,0,482,483,5,114,0,0,483,484,5,97,0,0,484,485,5,
        116,0,0,485,486,5,111,0,0,486,487,5,114,0,0,487,38,1,0,0,0,488,489,
        5,103,0,0,489,490,5,114,0,0,490,491,5,111,0,0,491,492,5,117,0,0,
        492,493,5,112,0,0,493,494,5,105,0,0,494,495,5,110,0,0,495,496,5,
        103,0,0,496,497,5,45,0,0,497,498,5,115,0,0,498,499,5,101,0,0,499,
        500,5,112,0,0,500,501,5,97,0,0,501,502,5,114,0,0,502,503,5,97,0,
        0,503,504,5,116,0,0,504,505,5,111,0,0,505,506,5,114,0,0,506,40,1,
        0,0,0,507,508,5,105,0,0,508,509,5,110,0,0,509,510,5,102,0,0,510,
        511,5,105,0,0,511,512,5,110,0,0,512,513,5,105,0,0,513,514,5,116,
        0,0,514,515,5,121,0,0,515,42,1,0,0,0,516,517,5,109,0,0,517,518,5,
        105,0,0,518,519,5,110,0,0,519,520,5,117,0,0,520,521,5,115,0,0,521,
        522,5,45,0,0,522,523,5,115,0,0,523,524,5,105,0,0,524,525,5,103,0,
        0,525,526,5,110,0,0,526,44,1,0,0,0,527,528,5,78,0,0,528,529,5,97,
        0,0,529,530,5,78,0,0,530,46,1,0,0,0,531,532,5,112,0,0,532,533,5,
        101,0,0,533,534,5,114,0,0,534,535,5,99,0,0,535,536,5,101,0,0,536,
        537,5,110,0,0,537,538,5,116,0,0,538,48,1,0,0,0,539,540,5,112,0,0,
        540,541,5,101,0,0,541,542,5,114,0,0,542,543,5,45,0,0,543,544,5,109,
        0,0,544,545,5,105,0,0,545,546,5,108,0,0,546,547,5,108,0,0,547,548,
        5,101,0,0,548,50,1,0,0,0,549,550,5,122,0,0,550,551,5,101,0,0,551,
        552,5,114,0,0,552,553,5,111,0,0,553,554,5,45,0,0,554,555,5,100,0,
        0,555,556,5,105,0,0,556,557,5,103,0,0,557,558,5,105,0,0,558,559,
        5,116,0,0,559,52,1,0,0,0,560,561,5,100,0,0,561,562,5,105,0,0,562,
        563,5,103,0,0,563,564,5,105,0,0,564,565,5,116,0,0,565,54,1,0,0,0,
        566,567,5,112,0,0,567,568,5,97,0,0,568,569,5,116,0,0,569,570,5,116,
        0,0,570,571,5,101,0,0,571,572,5,114,0,0,572,573,5,110,0,0,573,574,
        5,45,0,0,574,575,5,115,0,0,575,576,5,101,0,0,576,577,5,112,0,0,577,
        578,5,97,0,0,578,579,5,114,0,0,579,580,5,97,0,0,580,581,5,116,0,
        0,581,582,5,111,0,0,582,583,5,114,0,0,583,56,1,0,0,0,584,585,5,101,
        0,0,585,586,5,120,0,0,586,587,5,116,0,0,587,588,5,101,0,0,588,589,
        5,114,0,0,589,590,5,110,0,0,590,591,5,97,0,0,591,592,5,108,0,0,592,
        58,1,0,0,0,593,594,5,102,0,0,594,595,5,117,0,0,595,596,5,110,0,0,
        596,597,5,99,0,0,597,598,5,116,0,0,598,599,5,105,0,0,599,600,5,111,
        0,0,600,601,5,110,0,0,601,60,1,0,0,0,602,603,5,106,0,0,603,604,5,
        115,0,0,604,605,5,111,0,0,605,606,5,117,0,0,606,607,5,110,0,0,607,
        608,5,100,0,0,608,62,1,0,0,0,609,610,5,99,0,0,610,611,5,111,0,0,
        611,612,5,109,0,0,612,613,5,112,0,0,613,614,5,97,0,0,614,615,5,99,
        0,0,615,616,5,116,0,0,616,64,1,0,0,0,617,618,5,118,0,0,618,619,5,
        101,0,0,619,620,5,114,0,0,620,621,5,98,0,0,621,622,5,111,0,0,622,
        623,5,115,0,0,623,624,5,101,0,0,624,66,1,0,0,0,625,626,5,101,0,0,
        626,627,5,113,0,0,627,68,1,0,0,0,628,629,5,110,0,0,629,630,5,101,
        0,0,630,70,1,0,0,0,631,632,5,108,0,0,632,633,5,116,0,0,633,72,1,
        0,0,0,634,635,5,108,0,0,635,636,5,101,0,0,636,74,1,0,0,0,637,638,
        5,103,0,0,638,639,5,116,0,0,639,76,1,0,0,0,640,641,5,103,0,0,641,
        642,5,101,0,0,642,78,1,0,0,0,643,644,5,33,0,0,644,645,5,61,0,0,645,
        80,1,0,0,0,646,647,5,60,0,0,647,82,1,0,0,0,648,649,5,60,0,0,649,
        650,5,61,0,0,650,84,1,0,0,0,651,652,5,62,0,0,652,86,1,0,0,0,653,
        654,5,62,0,0,654,655,5,61,0,0,655,88,1,0,0,0,656,657,5,124,0,0,657,
        658,5,124,0,0,658,90,1,0,0,0,659,660,5,43,0,0,660,92,1,0,0,0,661,
        662,5,45,0,0,662,94,1,0,0,0,663,664,5,100,0,0,664,665,5,105,0,0,
        665,666,5,118,0,0,666,96,1,0,0,0,667,668,5,105,0,0,668,669,5,100,
        0,0,669,670,5,105,0,0,670,671,5,118,0,0,671,98,1,0,0,0,672,673,5,
        109,0,0,673,674,5,111,0,0,674,675,5,100,0,0,675,100,1,0,0,0,676,
        677,5,33,0,0,677,102,1,0,0,0,678,679,5,91,0,0,679,104,1,0,0,0,680,
        681,5,93,0,0,681,106,1,0,0,0,682,683,5,46,0,0,683,108,1,0,0,0,684,
        685,5,36,0,0,685,686,5,36,0,0,686,110,1,0,0,0,687,688,5,35,0,0,688,
        112,1,0,0,0,689,690,5,46,0,0,690,691,5,46,0,0,691,114,1,0,0,0,692,
        693,5,123,0,0,693,694,5,124,0,0,694,116,1,0,0,0,695,696,5,124,0,
        0,696,697,5,125,0,0,697,118,1,0,0,0,698,699,5,102,0,0,699,700,5,
        111,0,0,700,701,5,114,0,0,701,120,1,0,0,0,702,703,5,108,0,0,703,
        704,5,101,0,0,704,705,5,116,0,0,705,122,1,0,0,0,706,707,5,119,0,
        0,707,708,5,104,0,0,708,709,5,101,0,0,709,710,5,114,0,0,710,711,
        5,101,0,0,711,124,1,0,0,0,712,713,5,103,0,0,713,714,5,114,0,0,714,
        715,5,111,0,0,715,716,5,117,0,0,716,717,5,112,0,0,717,126,1,0,0,
        0,718,719,5,98,0,0,719,720,5,121,0,0,720,128,1,0,0,0,721,722,5,111,
        0,0,722,723,5,114,0,0,723,724,5,100,0,0,724,725,5,101,0,0,725,726,
        5,114,0,0,726,130,1,0,0,0,727,728,5,114,0,0,728,729,5,101,0,0,729,
        730,5,116,0,0,730,731,5,117,0,0,731,732,5,114,0,0,732,733,5,110,
        0,0,733,132,1,0,0,0,734,735,5,105,0,0,735,736,5,102,0,0,736,134,
        1,0,0,0,737,738,5,105,0,0,738,739,5,110,0,0,739,136,1,0,0,0,740,
        741,5,97,0,0,741,742,5,115,0,0,742,138,1,0,0,0,743,744,5,97,0,0,
        744,745,5,116,0,0,745,140,1,0,0,0,746,747,5,97,0,0,747,748,5,108,
        0,0,748,749,5,108,0,0,749,750,5,111,0,0,750,751,5,119,0,0,751,752,
        5,105,0,0,752,753,5,110,0,0,753,754,5,103,0,0,754,142,1,0,0,0,755,
        756,5,101,0,0,756,757,5,109,0,0,757,758,5,112,0,0,758,759,5,116,
        0,0,759,760,5,121,0,0,760,144,1,0,0,0,761,762,5,99,0,0,762,763,5,
        111,0,0,763,764,5,117,0,0,764,765,5,110,0,0,765,766,5,116,0,0,766,
        146,1,0,0,0,767,768,5,115,0,0,768,769,5,116,0,0,769,770,5,97,0,0,
        770,771,5,98,0,0,771,772,5,108,0,0,772,773,5,101,0,0,773,148,1,0,
        0,0,774,775,5,97,0,0,775,776,5,115,0,0,776,777,5,99,0,0,777,778,
        5,101,0,0,778,779,5,110,0,0,779,780,5,100,0,0,780,781,5,105,0,0,
        781,782,5,110,0,0,782,783,5,103,0,0,783,150,1,0,0,0,784,785,5,100,
        0,0,785,786,5,101,0,0,786,787,5,115,0,0,787,788,5,99,0,0,788,789,
        5,101,0,0,789,790,5,110,0,0,790,791,5,100,0,0,791,792,5,105,0,0,
        792,793,5,110,0,0,793,794,5,103,0,0,794,152,1,0,0,0,795,796,5,115,
        0,0,796,797,5,111,0,0,797,798,5,109,0,0,798,799,5,101,0,0,799,154,
        1,0,0,0,800,801,5,101,0,0,801,802,5,118,0,0,802,803,5,101,0,0,803,
        804,5,114,0,0,804,805,5,121,0,0,805,156,1,0,0,0,806,807,5,115,0,
        0,807,808,5,97,0,0,808,809,5,116,0,0,809,810,5,105,0,0,810,811,5,
        115,0,0,811,812,5,102,0,0,812,813,5,105,0,0,813,814,5,101,0,0,814,
        815,5,115,0,0,815,158,1,0,0,0,816,817,5,99,0,0,817,818,5,111,0,0,
        818,819,5,108,0,0,819,820,5,108,0,0,820,821,5,97,0,0,821,822,5,116,
        0,0,822,823,5,105,0,0,823,824,5,111,0,0,824,825,5,110,0,0,825,160,
        1,0,0,0,826,827,5,103,0,0,827,828,5,114,0,0,828,829,5,101,0,0,829,
        830,5,97,0,0,830,831,5,116,0,0,831,832,5,101,0,0,832,833,5,115,0,
        0,833,834,5,116,0,0,834,162,1,0,0,0,835,836,5,108,0,0,836,837,5,
        101,0,0,837,838,5,97,0,0,838,839,5,115,0,0,839,840,5,116,0,0,840,
        164,1,0,0,0,841,842,5,115,0,0,842,843,5,119,0,0,843,844,5,105,0,
        0,844,845,5,116,0,0,845,846,5,99,0,0,846,847,5,104,0,0,847,166,1,
        0,0,0,848,849,5,99,0,0,849,850,5,97,0,0,850,851,5,115,0,0,851,852,
        5,101,0,0,852,168,1,0,0,0,853,854,5,116,0,0,854,855,5,114,0,0,855,
        856,5,121,0,0,856,170,1,0,0,0,857,858,5,99,0,0,858,859,5,97,0,0,
        859,860,5,116,0,0,860,861,5,99,0,0,861,862,5,104,0,0,862,172,1,0,
        0,0,863,864,5,100,0,0,864,865,5,101,0,0,865,866,5,102,0,0,866,867,
        5,97,0,0,867,868,5,117,0,0,868,869,5,108,0,0,869,870,5,116,0,0,870,
        174,1,0,0,0,871,872,5,116,0,0,872,873,5,104,0,0,873,874,5,101,0,
        0,874,875,5,110,0,0,875,176,1,0,0,0,876,877,5,101,0,0,877,878,5,
        108,0,0,878,879,5,115,0,0,879,880,5,101,0,0,880,178,1,0,0,0,881,
        882,5,116,0,0,882,883,5,121,0,0,883,884,5,112,0,0,884,885,5,101,
        0,0,885,886,5,115,0,0,886,887,5,119,0,0,887,888,5,105,0,0,888,889,
        5,116,0,0,889,890,5,99,0,0,890,891,5,104,0,0,891,180,1,0,0,0,892,
        893,5,111,0,0,893,894,5,114,0,0,894,182,1,0,0,0,895,896,5,97,0,0,
        896,897,5,110,0,0,897,898,5,100,0,0,898,184,1,0,0,0,899,900,5,110,
        0,0,900,901,5,111,0,0,901,902,5,116,0,0,902,186,1,0,0,0,903,904,
        5,116,0,0,904,905,5,111,0,0,905,188,1,0,0,0,906,907,5,105,0,0,907,
        908,5,110,0,0,908,909,5,115,0,0,909,910,5,116,0,0,910,911,5,97,0,
        0,911,912,5,110,0,0,912,913,5,99,0,0,913,914,5,101,0,0,914,190,1,
        0,0,0,915,916,5,111,0,0,916,917,5,102,0,0,917,192,1,0,0,0,918,919,
        5,115,0,0,919,920,5,116,0,0,920,921,5,97,0,0,921,922,5,116,0,0,922,
        923,5,105,0,0,923,924,5,99,0,0,924,925,5,97,0,0,925,926,5,108,0,
        0,926,927,5,108,0,0,927,928,5,121,0,0,928,194,1,0,0,0,929,930,5,
        105,0,0,930,931,5,115,0,0,931,196,1,0,0,0,932,933,5,116,0,0,933,
        934,5,114,0,0,934,935,5,101,0,0,935,936,5,97,0,0,936,937,5,116,0,
        0,937,198,1,0,0,0,938,939,5,99,0,0,939,940,5,97,0,0,940,941,5,115,
        0,0,941,942,5,116,0,0,942,200,1,0,0,0,943,944,5,99,0,0,944,945,5,
        97,0,0,945,946,5,115,0,0,946,947,5,116,0,0,947,948,5,97,0,0,948,
        949,5,98,0,0,949,950,5,108,0,0,950,951,5,101,0,0,951,202,1,0,0,0,
        952,953,5,118,0,0,953,954,5,101,0,0,954,955,5,114,0,0,955,956,5,
        115,0,0,956,957,5,105,0,0,957,958,5,111,0,0,958,959,5,110,0,0,959,
        204,1,0,0,0,960,961,5,106,0,0,961,962,5,115,0,0,962,963,5,111,0,
        0,963,964,5,110,0,0,964,965,5,105,0,0,965,966,5,113,0,0,966,206,
        1,0,0,0,967,968,5,117,0,0,968,969,5,110,0,0,969,970,5,111,0,0,970,
        971,5,114,0,0,971,972,5,100,0,0,972,973,5,101,0,0,973,974,5,114,
        0,0,974,975,5,101,0,0,975,976,5,100,0,0,976,208,1,0,0,0,977,978,
        5,116,0,0,978,979,5,114,0,0,979,980,5,117,0,0,980,981,5,101,0,0,
        981,210,1,0,0,0,982,983,5,102,0,0,983,984,5,97,0,0,984,985,5,108,
        0,0,985,986,5,115,0,0,986,987,5,101,0,0,987,212,1,0,0,0,988,989,
        5,116,0,0,989,990,5,121,0,0,990,991,5,112,0,0,991,992,5,101,0,0,
        992,214,1,0,0,0,993,994,5,118,0,0,994,995,5,97,0,0,995,996,5,108,
        0,0,996,997,5,105,0,0,997,998,5,100,0,0,998,999,5,97,0,0,999,1000,
        5,116,0,0,1000,1001,5,101,0,0,1001,216,1,0,0,0,1002,1003,5,97,0,
        0,1003,1004,5,110,0,0,1004,1005,5,110,0,0,1005,1006,5,111,0,0,1006,
        1007,5,116,0,0,1007,1008,5,97,0,0,1008,1009,5,116,0,0,1009,1010,
        5,101,0,0,1010,218,1,0,0,0,1011,1012,5,100,0,0,1012,1013,5,101,0,
        0,1013,1014,5,99,0,0,1014,1015,5,108,0,0,1015,1016,5,97,0,0,1016,
        1017,5,114,0,0,1017,1018,5,101,0,0,1018,220,1,0,0,0,1019,1020,5,
        99,0,0,1020,1021,5,111,0,0,1021,1022,5,110,0,0,1022,1023,5,116,0,
        0,1023,1024,5,101,0,0,1024,1025,5,120,0,0,1025,1026,5,116,0,0,1026,
        222,1,0,0,0,1027,1028,5,105,0,0,1028,1029,5,116,0,0,1029,1030,5,
        101,0,0,1030,1031,5,109,0,0,1031,224,1,0,0,0,1032,1033,5,118,0,0,
        1033,1034,5,97,0,0,1034,1035,5,114,0,0,1035,1036,5,105,0,0,1036,
        1037,5,97,0,0,1037,1038,5,98,0,0,1038,1039,5,108,0,0,1039,1040,5,
        101,0,0,1040,226,1,0,0,0,1041,1042,5,105,0,0,1042,1043,5,110,0,0,
        1043,1044,5,115,0,0,1044,1045,5,101,0,0,1045,1046,5,114,0,0,1046,
        1047,5,116,0,0,1047,228,1,0,0,0,1048,1049,5,100,0,0,1049,1050,5,
        101,0,0,1050,1051,5,108,0,0,1051,1052,5,101,0,0,1052,1053,5,116,
        0,0,1053,1054,5,101,0,0,1054,230,1,0,0,0,1055,1056,5,114,0,0,1056,
        1057,5,101,0,0,1057,1058,5,110,0,0,1058,1059,5,97,0,0,1059,1060,
        5,109,0,0,1060,1061,5,101,0,0,1061,232,1,0,0,0,1062,1063,5,114,0,
        0,1063,1064,5,101,0,0,1064,1065,5,112,0,0,1065,1066,5,108,0,0,1066,
        1067,5,97,0,0,1067,1068,5,99,0,0,1068,1069,5,101,0,0,1069,234,1,
        0,0,0,1070,1071,5,99,0,0,1071,1072,5,111,0,0,1072,1073,5,112,0,0,
        1073,1074,5,121,0,0,1074,236,1,0,0,0,1075,1076,5,109,0,0,1076,1077,
        5,111,0,0,1077,1078,5,100,0,0,1078,1079,5,105,0,0,1079,1080,5,102,
        0,0,1080,1081,5,121,0,0,1081,238,1,0,0,0,1082,1083,5,97,0,0,1083,
        1084,5,112,0,0,1084,1085,5,112,0,0,1085,1086,5,101,0,0,1086,1087,
        5,110,0,0,1087,1088,5,100,0,0,1088,240,1,0,0,0,1089,1090,5,105,0,
        0,1090,1091,5,110,0,0,1091,1092,5,116,0,0,1092,1093,5,111,0,0,1093,
        242,1,0,0,0,1094,1095,5,118,0,0,1095,1096,5,97,0,0,1096,1097,5,108,
        0,0,1097,1098,5,117,0,0,1098,1099,5,101,0,0,1099,244,1,0,0,0,1100,
        1101,5,119,0,0,1101,1102,5,105,0,0,1102,1103,5,116,0,0,1103,1104,
        5,104,0,0,1104,246,1,0,0,0,1105,1106,5,112,0,0,1106,1107,5,111,0,
        0,1107,1108,5,115,0,0,1108,1109,5,105,0,0,1109,1110,5,116,0,0,1110,
        1111,5,105,0,0,1111,1112,5,111,0,0,1112,1113,5,110,0,0,1113,248,
        1,0,0,0,1114,1115,5,106,0,0,1115,1116,5,115,0,0,1116,1117,5,111,
        0,0,1117,1118,5,110,0,0,1118,250,1,0,0,0,1119,1120,5,117,0,0,1120,
        1121,5,112,0,0,1121,1122,5,100,0,0,1122,1123,5,97,0,0,1123,1124,
        5,116,0,0,1124,1125,5,105,0,0,1125,1126,5,110,0,0,1126,1127,5,103,
        0,0,1127,252,1,0,0,0,1128,1129,5,99,0,0,1129,1130,5,114,0,0,1130,
        1131,5,101,0,0,1131,1132,5,97,0,0,1132,1133,5,116,0,0,1133,1134,
        5,101,0,0,1134,254,1,0,0,0,1135,1136,5,99,0,0,1136,1137,5,111,0,
        0,1137,1138,5,108,0,0,1138,1139,5,108,0,0,1139,1140,5,101,0,0,1140,
        1141,5,99,0,0,1141,1142,5,116,0,0,1142,1143,5,105,0,0,1143,1144,
        5,111,0,0,1144,1145,5,110,0,0,1145,256,1,0,0,0,1146,1147,5,116,0,
        0,1147,1148,5,97,0,0,1148,1149,5,98,0,0,1149,1150,5,108,0,0,1150,
        1151,5,101,0,0,1151,258,1,0,0,0,1152,1153,5,100,0,0,1153,1154,5,
        101,0,0,1154,1155,5,108,0,0,1155,1156,5,116,0,0,1156,1157,5,97,0,
        0,1157,1158,5,45,0,0,1158,1159,5,102,0,0,1159,1160,5,105,0,0,1160,
        1161,5,108,0,0,1161,1162,5,101,0,0,1162,260,1,0,0,0,1163,1164,5,
        105,0,0,1164,1165,5,99,0,0,1165,1166,5,101,0,0,1166,1167,5,98,0,
        0,1167,1168,5,101,0,0,1168,1169,5,114,0,0,1169,1170,5,103,0,0,1170,
        1171,5,45,0,0,1171,1172,5,116,0,0,1172,1173,5,97,0,0,1173,1174,5,
        98,0,0,1174,1175,5,108,0,0,1175,1176,5,101,0,0,1176,262,1,0,0,0,
        1177,1178,5,116,0,0,1178,1179,5,114,0,0,1179,1180,5,117,0,0,1180,
        1181,5,110,0,0,1181,1182,5,99,0,0,1182,1183,5,97,0,0,1183,1184,5,
        116,0,0,1184,1185,5,101,0,0,1185,264,1,0,0,0,1186,1187,5,102,0,0,
        1187,1188,5,105,0,0,1188,1189,5,114,0,0,1189,1190,5,115,0,0,1190,
        1191,5,116,0,0,1191,266,1,0,0,0,1192,1193,5,108,0,0,1193,1194,5,
        97,0,0,1194,1195,5,115,0,0,1195,1196,5,116,0,0,1196,268,1,0,0,0,
        1197,1198,5,102,0,0,1198,1199,5,114,0,0,1199,1200,5,111,0,0,1200,
        1201,5,109,0,0,1201,270,1,0,0,0,1202,1203,5,101,0,0,1203,1204,5,
        100,0,0,1204,1205,5,105,0,0,1205,1206,5,116,0,0,1206,272,1,0,0,0,
        1207,1208,5,97,0,0,1208,1209,5,102,0,0,1209,1210,5,116,0,0,1210,
        1211,5,101,0,0,1211,1212,5,114,0,0,1212,274,1,0,0,0,1213,1214,5,
        98,0,0,1214,1215,5,101,0,0,1215,1216,5,102,0,0,1216,1217,5,111,0,
        0,1217,1218,5,114,0,0,1218,1219,5,101,0,0,1219,276,1,0,0,0,1220,
        1221,5,105,0,0,1221,1222,5,109,0,0,1222,1223,5,112,0,0,1223,1224,
        5,111,0,0,1224,1225,5,114,0,0,1225,1226,5,116,0,0,1226,278,1,0,0,
        0,1227,1228,5,115,0,0,1228,1229,5,99,0,0,1229,1230,5,104,0,0,1230,
        1231,5,101,0,0,1231,1232,5,109,0,0,1232,1233,5,97,0,0,1233,280,1,
        0,0,0,1234,1235,5,110,0,0,1235,1236,5,97,0,0,1236,1237,5,109,0,0,
        1237,1238,5,101,0,0,1238,1239,5,115,0,0,1239,1240,5,112,0,0,1240,
        1241,5,97,0,0,1241,1242,5,99,0,0,1242,1243,5,101,0,0,1243,282,1,
        0,0,0,1244,1245,5,101,0,0,1245,1246,5,108,0,0,1246,1247,5,101,0,
        0,1247,1248,5,109,0,0,1248,1249,5,101,0,0,1249,1250,5,110,0,0,1250,
        1251,5,116,0,0,1251,284,1,0,0,0,1252,1253,5,47,0,0,1253,286,1,0,
        0,0,1254,1255,5,47,0,0,1255,1256,5,47,0,0,1256,288,1,0,0,0,1257,
        1258,5,64,0,0,1258,290,1,0,0,0,1259,1260,5,99,0,0,1260,1261,5,104,
        0,0,1261,1262,5,105,0,0,1262,1263,5,108,0,0,1263,1264,5,100,0,0,
        1264,292,1,0,0,0,1265,1266,5,100,0,0,1266,1267,5,101,0,0,1267,1268,
        5,115,0,0,1268,1269,5,99,0,0,1269,1270,5,101,0,0,1270,1271,5,110,
        0,0,1271,1272,5,100,0,0,1272,1273,5,97,0,0,1273,1274,5,110,0,0,1274,
        1275,5,116,0,0,1275,294,1,0,0,0,1276,1277,5,97,0,0,1277,1278,5,116,
        0,0,1278,1279,5,116,0,0,1279,1280,5,114,0,0,1280,1281,5,105,0,0,
        1281,1282,5,98,0,0,1282,1283,5,117,0,0,1283,1284,5,116,0,0,1284,
        1285,5,101,0,0,1285,296,1,0,0,0,1286,1287,5,115,0,0,1287,1288,5,
        101,0,0,1288,1289,5,108,0,0,1289,1290,5,102,0,0,1290,298,1,0,0,0,
        1291,1292,5,100,0,0,1292,1293,5,101,0,0,1293,1294,5,115,0,0,1294,
        1295,5,99,0,0,1295,1296,5,101,0,0,1296,1297,5,110,0,0,1297,1298,
        5,100,0,0,1298,1299,5,97,0,0,1299,1300,5,110,0,0,1300,1301,5,116,
        0,0,1301,1302,5,45,0,0,1302,1303,5,111,0,0,1303,1304,5,114,0,0,1304,
        1305,5,45,0,0,1305,1306,5,115,0,0,1306,1307,5,101,0,0,1307,1308,
        5,108,0,0,1308,1309,5,102,0,0,1309,300,1,0,0,0,1310,1311,5,102,0,
        0,1311,1312,5,111,0,0,1312,1313,5,108,0,0,1313,1314,5,108,0,0,1314,
        1315,5,111,0,0,1315,1316,5,119,0,0,1316,1317,5,105,0,0,1317,1318,
        5,110,0,0,1318,1319,5,103,0,0,1319,1320,5,45,0,0,1320,1321,5,115,
        0,0,1321,1322,5,105,0,0,1322,1323,5,98,0,0,1323,1324,5,108,0,0,1324,
        1325,5,105,0,0,1325,1326,5,110,0,0,1326,1327,5,103,0,0,1327,302,
        1,0,0,0,1328,1329,5,102,0,0,1329,1330,5,111,0,0,1330,1331,5,108,
        0,0,1331,1332,5,108,0,0,1332,1333,5,111,0,0,1333,1334,5,119,0,0,
        1334,1335,5,105,0,0,1335,1336,5,110,0,0,1336,1337,5,103,0,0,1337,
        304,1,0,0,0,1338,1339,5,112,0,0,1339,1340,5,97,0,0,1340,1341,5,114,
        0,0,1341,1342,5,101,0,0,1342,1343,5,110,0,0,1343,1344,5,116,0,0,
        1344,306,1,0,0,0,1345,1346,5,97,0,0,1346,1347,5,110,0,0,1347,1348,
        5,99,0,0,1348,1349,5,101,0,0,1349,1350,5,115,0,0,1350,1351,5,116,
        0,0,1351,1352,5,111,0,0,1352,1353,5,114,0,0,1353,308,1,0,0,0,1354,
        1355,5,112,0,0,1355,1356,5,114,0,0,1356,1357,5,101,0,0,1357,1358,
        5,99,0,0,1358,1359,5,101,0,0,1359,1360,5,100,0,0,1360,1361,5,105,
        0,0,1361,1362,5,110,0,0,1362,1363,5,103,0,0,1363,1364,5,45,0,0,1364,
        1365,5,115,0,0,1365,1366,5,105,0,0,1366,1367,5,98,0,0,1367,1368,
        5,108,0,0,1368,1369,5,105,0,0,1369,1370,5,110,0,0,1370,1371,5,103,
        0,0,1371,310,1,0,0,0,1372,1373,5,112,0,0,1373,1374,5,114,0,0,1374,
        1375,5,101,0,0,1375,1376,5,99,0,0,1376,1377,5,101,0,0,1377,1378,
        5,100,0,0,1378,1379,5,105,0,0,1379,1380,5,110,0,0,1380,1381,5,103,
        0,0,1381,312,1,0,0,0,1382,1383,5,97,0,0,1383,1384,5,110,0,0,1384,
        1385,5,99,0,0,1385,1386,5,101,0,0,1386,1387,5,115,0,0,1387,1388,
        5,116,0,0,1388,1389,5,111,0,0,1389,1390,5,114,0,0,1390,1391,5,45,
        0,0,1391,1392,5,111,0,0,1392,1393,5,114,0,0,1393,1394,5,45,0,0,1394,
        1395,5,115,0,0,1395,1396,5,101,0,0,1396,1397,5,108,0,0,1397,1398,
        5,102,0,0,1398,314,1,0,0,0,1399,1400,5,110,0,0,1400,1401,5,111,0,
        0,1401,1402,5,100,0,0,1402,1403,5,101,0,0,1403,316,1,0,0,0,1404,
        1405,5,98,0,0,1405,1406,5,105,0,0,1406,1407,5,110,0,0,1407,1408,
        5,97,0,0,1408,1409,5,114,0,0,1409,1410,5,121,0,0,1410,318,1,0,0,
        0,1411,1412,5,100,0,0,1412,1413,5,111,0,0,1413,1414,5,99,0,0,1414,
        1415,5,117,0,0,1415,1416,5,109,0,0,1416,1417,5,101,0,0,1417,1418,
        5,110,0,0,1418,1419,5,116,0,0,1419,320,1,0,0,0,1420,1421,5,100,0,
        0,1421,1422,5,111,0,0,1422,1423,5,99,0,0,1423,1424,5,117,0,0,1424,
        1425,5,109,0,0,1425,1426,5,101,0,0,1426,1427,5,110,0,0,1427,1428,
        5,116,0,0,1428,1429,5,45,0,0,1429,1430,5,110,0,0,1430,1431,5,111,
        0,0,1431,1432,5,100,0,0,1432,1433,5,101,0,0,1433,322,1,0,0,0,1434,
        1435,5,116,0,0,1435,1436,5,101,0,0,1436,1437,5,120,0,0,1437,1438,
        5,116,0,0,1438,324,1,0,0,0,1439,1440,5,112,0,0,1440,1441,5,114,0,
        0,1441,1442,5,111,0,0,1442,1443,5,99,0,0,1443,1444,5,101,0,0,1444,
        1445,5,115,0,0,1445,1446,5,115,0,0,1446,1447,5,105,0,0,1447,1448,
        5,110,0,0,1448,1449,5,103,0,0,1449,1450,5,45,0,0,1450,1451,5,105,
        0,0,1451,1452,5,110,0,0,1452,1453,5,115,0,0,1453,1454,5,116,0,0,
        1454,1455,5,114,0,0,1455,1456,5,117,0,0,1456,1457,5,99,0,0,1457,
        1458,5,116,0,0,1458,1459,5,105,0,0,1459,1460,5,111,0,0,1460,1461,
        5,110,0,0,1461,326,1,0,0,0,1462,1463,5,110,0,0,1463,1464,5,97,0,
        0,1464,1465,5,109,0,0,1465,1466,5,101,0,0,1466,1467,5,115,0,0,1467,
        1468,5,112,0,0,1468,1469,5,97,0,0,1469,1470,5,99,0,0,1470,1471,5,
        101,0,0,1471,1472,5,45,0,0,1472,1473,5,110,0,0,1473,1474,5,111,0,
        0,1474,1475,5,100,0,0,1475,1476,5,101,0,0,1476,328,1,0,0,0,1477,
        1478,5,115,0,0,1478,1479,5,99,0,0,1479,1480,5,104,0,0,1480,1481,
        5,101,0,0,1481,1482,5,109,0,0,1482,1483,5,97,0,0,1483,1484,5,45,
        0,0,1484,1485,5,97,0,0,1485,1486,5,116,0,0,1486,1487,5,116,0,0,1487,
        1488,5,114,0,0,1488,1489,5,105,0,0,1489,1490,5,98,0,0,1490,1491,
        5,117,0,0,1491,1492,5,116,0,0,1492,1493,5,101,0,0,1493,330,1,0,0,
        0,1494,1495,5,115,0,0,1495,1496,5,99,0,0,1496,1497,5,104,0,0,1497,
        1498,5,101,0,0,1498,1499,5,109,0,0,1499,1500,5,97,0,0,1500,1501,
        5,45,0,0,1501,1502,5,101,0,0,1502,1503,5,108,0,0,1503,1504,5,101,
        0,0,1504,1505,5,109,0,0,1505,1506,5,101,0,0,1506,1507,5,110,0,0,
        1507,1508,5,116,0,0,1508,332,1,0,0,0,1509,1510,5,97,0,0,1510,1511,
        5,114,0,0,1511,1512,5,114,0,0,1512,1513,5,97,0,0,1513,1514,5,121,
        0,0,1514,1515,5,45,0,0,1515,1516,5,110,0,0,1516,1517,5,111,0,0,1517,
        1518,5,100,0,0,1518,1519,5,101,0,0,1519,334,1,0,0,0,1520,1521,5,
        98,0,0,1521,1522,5,111,0,0,1522,1523,5,111,0,0,1523,1524,5,108,0,
        0,1524,1525,5,101,0,0,1525,1526,5,97,0,0,1526,1527,5,110,0,0,1527,
        1528,5,45,0,0,1528,1529,5,110,0,0,1529,1530,5,111,0,0,1530,1531,
        5,100,0,0,1531,1532,5,101,0,0,1532,336,1,0,0,0,1533,1534,5,110,0,
        0,1534,1535,5,117,0,0,1535,1536,5,108,0,0,1536,1537,5,108,0,0,1537,
        1538,5,45,0,0,1538,1539,5,110,0,0,1539,1540,5,111,0,0,1540,1541,
        5,100,0,0,1541,1542,5,101,0,0,1542,338,1,0,0,0,1543,1544,5,110,0,
        0,1544,1545,5,117,0,0,1545,1546,5,109,0,0,1546,1547,5,98,0,0,1547,
        1548,5,101,0,0,1548,1549,5,114,0,0,1549,1550,5,45,0,0,1550,1551,
        5,110,0,0,1551,1552,5,111,0,0,1552,1553,5,100,0,0,1553,1554,5,101,
        0,0,1554,340,1,0,0,0,1555,1556,5,111,0,0,1556,1557,5,98,0,0,1557,
        1558,5,106,0,0,1558,1559,5,101,0,0,1559,1560,5,99,0,0,1560,1561,
        5,116,0,0,1561,1562,5,45,0,0,1562,1563,5,110,0,0,1563,1564,5,111,
        0,0,1564,1565,5,100,0,0,1565,1566,5,101,0,0,1566,342,1,0,0,0,1567,
        1568,5,99,0,0,1568,1569,5,111,0,0,1569,1570,5,109,0,0,1570,1571,
        5,109,0,0,1571,1572,5,101,0,0,1572,1573,5,110,0,0,1573,1574,5,116,
        0,0,1574,344,1,0,0,0,1575,1576,5,98,0,0,1576,1577,5,114,0,0,1577,
        1578,5,101,0,0,1578,1579,5,97,0,0,1579,1580,5,107,0,0,1580,346,1,
        0,0,0,1581,1582,5,108,0,0,1582,1583,5,111,0,0,1583,1584,5,111,0,
        0,1584,1585,5,112,0,0,1585,348,1,0,0,0,1586,1587,5,99,0,0,1587,1588,
        5,111,0,0,1588,1589,5,110,0,0,1589,1590,5,116,0,0,1590,1591,5,105,
        0,0,1591,1592,5,110,0,0,1592,1593,5,117,0,0,1593,1594,5,101,0,0,
        1594,350,1,0,0,0,1595,1596,5,101,0,0,1596,1597,5,120,0,0,1597,1598,
        5,105,0,0,1598,1599,5,116,0,0,1599,352,1,0,0,0,1600,1601,5,114,0,
        0,1601,1602,5,101,0,0,1602,1603,5,116,0,0,1603,1604,5,117,0,0,1604,
        1605,5,114,0,0,1605,1606,5,110,0,0,1606,1607,5,105,0,0,1607,1608,
        5,110,0,0,1608,1609,5,103,0,0,1609,354,1,0,0,0,1610,1611,5,119,0,
        0,1611,1612,5,104,0,0,1612,1613,5,105,0,0,1613,1614,5,108,0,0,1614,
        1615,5,101,0,0,1615,356,1,0,0,0,1616,1621,5,34,0,0,1617,1620,3,359,
        179,0,1618,1620,8,0,0,0,1619,1617,1,0,0,0,1619,1618,1,0,0,0,1620,
        1623,1,0,0,0,1621,1619,1,0,0,0,1621,1622,1,0,0,0,1622,1624,1,0,0,
        0,1623,1621,1,0,0,0,1624,1635,5,34,0,0,1625,1630,5,39,0,0,1626,1629,
        3,361,180,0,1627,1629,8,1,0,0,1628,1626,1,0,0,0,1628,1627,1,0,0,
        0,1629,1632,1,0,0,0,1630,1628,1,0,0,0,1630,1631,1,0,0,0,1631,1633,
        1,0,0,0,1632,1630,1,0,0,0,1633,1635,5,39,0,0,1634,1616,1,0,0,0,1634,
        1625,1,0,0,0,1635,358,1,0,0,0,1636,1639,5,92,0,0,1637,1640,7,2,0,
        0,1638,1640,3,363,181,0,1639,1637,1,0,0,0,1639,1638,1,0,0,0,1640,
        360,1,0,0,0,1641,1644,5,92,0,0,1642,1645,7,3,0,0,1643,1645,3,363,
        181,0,1644,1642,1,0,0,0,1644,1643,1,0,0,0,1645,362,1,0,0,0,1646,
        1647,5,117,0,0,1647,1648,3,365,182,0,1648,1649,3,365,182,0,1649,
        1650,3,365,182,0,1650,1651,3,365,182,0,1651,364,1,0,0,0,1652,1653,
        7,4,0,0,1653,366,1,0,0,0,1654,1655,5,63,0,0,1655,368,1,0,0,0,1656,
        1657,5,110,0,0,1657,1658,5,117,0,0,1658,1659,5,108,0,0,1659,1660,
        5,108,0,0,1660,370,1,0,0,0,1661,1662,3,373,186,0,1662,372,1,0,0,
        0,1663,1667,3,375,187,0,1664,1667,3,377,188,0,1665,1667,3,379,189,
        0,1666,1663,1,0,0,0,1666,1664,1,0,0,0,1666,1665,1,0,0,0,1667,374,
        1,0,0,0,1668,1669,3,381,190,0,1669,376,1,0,0,0,1670,1671,5,46,0,
        0,1671,1681,3,381,190,0,1672,1673,3,381,190,0,1673,1677,5,46,0,0,
        1674,1676,7,5,0,0,1675,1674,1,0,0,0,1676,1679,1,0,0,0,1677,1675,
        1,0,0,0,1677,1678,1,0,0,0,1678,1681,1,0,0,0,1679,1677,1,0,0,0,1680,
        1670,1,0,0,0,1680,1672,1,0,0,0,1681,378,1,0,0,0,1682,1683,5,46,0,
        0,1683,1695,3,381,190,0,1684,1692,3,381,190,0,1685,1689,5,46,0,0,
        1686,1688,7,5,0,0,1687,1686,1,0,0,0,1688,1691,1,0,0,0,1689,1687,
        1,0,0,0,1689,1690,1,0,0,0,1690,1693,1,0,0,0,1691,1689,1,0,0,0,1692,
        1685,1,0,0,0,1692,1693,1,0,0,0,1693,1695,1,0,0,0,1694,1682,1,0,0,
        0,1694,1684,1,0,0,0,1695,1696,1,0,0,0,1696,1698,7,6,0,0,1697,1699,
        7,7,0,0,1698,1697,1,0,0,0,1698,1699,1,0,0,0,1699,1700,1,0,0,0,1700,
        1701,3,381,190,0,1701,380,1,0,0,0,1702,1704,7,5,0,0,1703,1702,1,
        0,0,0,1704,1705,1,0,0,0,1705,1703,1,0,0,0,1705,1706,1,0,0,0,1706,
        382,1,0,0,0,1707,1708,7,8,0,0,1708,1709,1,0,0,0,1709,1710,6,191,
        0,0,1710,384,1,0,0,0,1711,1715,3,387,193,0,1712,1714,3,389,194,0,
        1713,1712,1,0,0,0,1714,1717,1,0,0,0,1715,1713,1,0,0,0,1715,1716,
        1,0,0,0,1716,386,1,0,0,0,1717,1715,1,0,0,0,1718,1720,7,9,0,0,1719,
        1718,1,0,0,0,1720,388,1,0,0,0,1721,1724,3,387,193,0,1722,1724,7,
        10,0,0,1723,1721,1,0,0,0,1723,1722,1,0,0,0,1724,390,1,0,0,0,1725,
        1726,5,40,0,0,1726,1735,5,58,0,0,1727,1734,3,391,195,0,1728,1729,
        5,40,0,0,1729,1734,8,11,0,0,1730,1731,5,58,0,0,1731,1734,8,12,0,
        0,1732,1734,8,13,0,0,1733,1727,1,0,0,0,1733,1728,1,0,0,0,1733,1730,
        1,0,0,0,1733,1732,1,0,0,0,1734,1737,1,0,0,0,1735,1733,1,0,0,0,1735,
        1736,1,0,0,0,1736,1739,1,0,0,0,1737,1735,1,0,0,0,1738,1740,5,58,
        0,0,1739,1738,1,0,0,0,1740,1741,1,0,0,0,1741,1739,1,0,0,0,1741,1742,
        1,0,0,0,1742,1743,1,0,0,0,1743,1744,5,41,0,0,1744,1745,1,0,0,0,1745,
        1746,6,195,0,0,1746,392,1,0,0,0,1747,1748,8,14,0,0,1748,394,1,0,
        0,0,22,0,1619,1621,1628,1630,1634,1639,1644,1666,1677,1680,1689,
        1692,1694,1698,1705,1715,1719,1723,1733,1735,1741,1,0,1,0
    ];

    private static __ATN: antlr.ATN;
    public static get _ATN(): antlr.ATN {
        if (!jsoniqLexer.__ATN) {
            jsoniqLexer.__ATN = new antlr.ATNDeserializer().deserialize(jsoniqLexer._serializedATN);
        }

        return jsoniqLexer.__ATN;
    }


    private static readonly vocabulary = new antlr.Vocabulary(jsoniqLexer.literalNames, jsoniqLexer.symbolicNames, []);

    public override get vocabulary(): antlr.Vocabulary {
        return jsoniqLexer.vocabulary;
    }

    private static readonly decisionsToDFA = jsoniqLexer._ATN.decisionToState.map( (ds: antlr.DecisionState, index: number) => new antlr.DFA(ds, index) );
}