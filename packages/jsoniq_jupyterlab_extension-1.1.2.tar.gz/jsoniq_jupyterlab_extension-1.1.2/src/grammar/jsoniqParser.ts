
import * as antlr from "antlr4ng";
import { Token } from "antlr4ng";

import { jsoniqListener } from "./jsoniqListener.js";
// for running tests with parameters, TODO: discuss strategy for typed parameters in CI
// eslint-disable-next-line no-unused-vars
type int = number;


export class jsoniqParser extends antlr.Parser {
    public static readonly Ksemicolon = 1;
    public static readonly Kmodule = 2;
    public static readonly Kequal = 3;
    public static readonly Kdollar = 4;
    public static readonly Kassign = 5;
    public static readonly Klbrace = 6;
    public static readonly Krbrace = 7;
    public static readonly Klparen = 8;
    public static readonly Krparen = 9;
    public static readonly Kasterisk = 10;
    public static readonly Kpipe = 11;
    public static readonly Kannotation = 12;
    public static readonly Kcomma = 13;
    public static readonly Kbase_uri = 14;
    public static readonly Kordering = 15;
    public static readonly Kordered = 16;
    public static readonly Kdecimal_format = 17;
    public static readonly Kcolon = 18;
    public static readonly Kdecimal_separator = 19;
    public static readonly Kgrouping_separator = 20;
    public static readonly Kinfinity = 21;
    public static readonly Kminus_sign = 22;
    public static readonly Knan = 23;
    public static readonly Kpercent = 24;
    public static readonly Kper_mille = 25;
    public static readonly Kzero_digit = 26;
    public static readonly Kdigit = 27;
    public static readonly Kpattern_separator = 28;
    public static readonly Kexternal = 29;
    public static readonly Kfunction = 30;
    public static readonly Kjsound = 31;
    public static readonly Kcompact = 32;
    public static readonly Kverbose = 33;
    public static readonly Keq = 34;
    public static readonly Kne = 35;
    public static readonly Klt = 36;
    public static readonly Kle = 37;
    public static readonly Kgt = 38;
    public static readonly Kge = 39;
    public static readonly Knot_equal = 40;
    public static readonly Kless = 41;
    public static readonly Kless_or_equal = 42;
    public static readonly Kgreater = 43;
    public static readonly Kgreater_or_equal = 44;
    public static readonly Kconcat = 45;
    public static readonly Kplus = 46;
    public static readonly Kminus = 47;
    public static readonly Kdiv = 48;
    public static readonly Kidiv = 49;
    public static readonly Kmod = 50;
    public static readonly Kbang = 51;
    public static readonly Klbracket = 52;
    public static readonly Krbracket = 53;
    public static readonly Kdot = 54;
    public static readonly Kcontext_item = 55;
    public static readonly Khash = 56;
    public static readonly Kdotdot = 57;
    public static readonly Kobject_start = 58;
    public static readonly Kobject_end = 59;
    public static readonly Kfor = 60;
    public static readonly Klet = 61;
    public static readonly Kwhere = 62;
    public static readonly Kgroup = 63;
    public static readonly Kby = 64;
    public static readonly Korder = 65;
    public static readonly Kreturn = 66;
    public static readonly Kif = 67;
    public static readonly Kin = 68;
    public static readonly Kas = 69;
    public static readonly Kat = 70;
    public static readonly Kallowing = 71;
    public static readonly Kempty = 72;
    public static readonly Kcount = 73;
    public static readonly Kstable = 74;
    public static readonly Kascending = 75;
    public static readonly Kdescending = 76;
    public static readonly Ksome = 77;
    public static readonly Kevery = 78;
    public static readonly Ksatisfies = 79;
    public static readonly Kcollation = 80;
    public static readonly Kgreatest = 81;
    public static readonly Kleast = 82;
    public static readonly Kswitch = 83;
    public static readonly Kcase = 84;
    public static readonly Ktry = 85;
    public static readonly Kcatch = 86;
    public static readonly Kdefault = 87;
    public static readonly Kthen = 88;
    public static readonly Kelse = 89;
    public static readonly Ktypeswitch = 90;
    public static readonly Kor = 91;
    public static readonly Kand = 92;
    public static readonly Knot = 93;
    public static readonly Kto = 94;
    public static readonly Kinstance = 95;
    public static readonly Kof = 96;
    public static readonly Kstatically = 97;
    public static readonly Kis = 98;
    public static readonly Ktreat = 99;
    public static readonly Kcast = 100;
    public static readonly Kcastable = 101;
    public static readonly Kversion = 102;
    public static readonly Kjsoniq = 103;
    public static readonly Kunordered = 104;
    public static readonly Ktrue = 105;
    public static readonly Kfalse = 106;
    public static readonly Ktype = 107;
    public static readonly Kvalidate = 108;
    public static readonly Kannotate = 109;
    public static readonly Kdeclare = 110;
    public static readonly Kcontext = 111;
    public static readonly Kitem = 112;
    public static readonly Kvariable = 113;
    public static readonly Kinsert = 114;
    public static readonly Kdelete = 115;
    public static readonly Krename = 116;
    public static readonly Kreplace = 117;
    public static readonly Kcopy = 118;
    public static readonly Kmodify = 119;
    public static readonly Kappend = 120;
    public static readonly Kinto = 121;
    public static readonly Kvalue = 122;
    public static readonly Kwith = 123;
    public static readonly Kposition = 124;
    public static readonly Kjson = 125;
    public static readonly Kupdating = 126;
    public static readonly Kcreate = 127;
    public static readonly Kcollection = 128;
    public static readonly Ktable = 129;
    public static readonly Kdeltafile = 130;
    public static readonly Kicebergtable = 131;
    public static readonly Ktruncate = 132;
    public static readonly Kfirst = 133;
    public static readonly Klast = 134;
    public static readonly Kfrom = 135;
    public static readonly Kedit = 136;
    public static readonly Kafter = 137;
    public static readonly Kbefore = 138;
    public static readonly Kimport = 139;
    public static readonly Kschema = 140;
    public static readonly Knamespace = 141;
    public static readonly Kelement = 142;
    public static readonly Kslash = 143;
    public static readonly Kdslash = 144;
    public static readonly Kat_symbol = 145;
    public static readonly Kchild = 146;
    public static readonly Kdescendant = 147;
    public static readonly Kattribute = 148;
    public static readonly Kself = 149;
    public static readonly Kdescendant_or_self = 150;
    public static readonly Kfollowing_sibling = 151;
    public static readonly Kfollowing = 152;
    public static readonly Kparent = 153;
    public static readonly Kancestor = 154;
    public static readonly Kpreceding_sibling = 155;
    public static readonly Kpreceding = 156;
    public static readonly Kancestor_or_self = 157;
    public static readonly Knode = 158;
    public static readonly Kbinary = 159;
    public static readonly Kdocument = 160;
    public static readonly Kdocument_node = 161;
    public static readonly Ktext = 162;
    public static readonly Kpi = 163;
    public static readonly Knamespace_node = 164;
    public static readonly Kschema_attribute = 165;
    public static readonly Kschema_element = 166;
    public static readonly Karray_node = 167;
    public static readonly Kboolean_node = 168;
    public static readonly Knull_node = 169;
    public static readonly Knumber_node = 170;
    public static readonly Kobject_node = 171;
    public static readonly Kcomment = 172;
    public static readonly Kbreak = 173;
    public static readonly Kloop = 174;
    public static readonly Kcontinue = 175;
    public static readonly Kexit = 176;
    public static readonly Kreturning = 177;
    public static readonly Kwhile = 178;
    public static readonly STRING = 179;
    public static readonly ArgumentPlaceholder = 180;
    public static readonly NullLiteral = 181;
    public static readonly Literal = 182;
    public static readonly NumericLiteral = 183;
    public static readonly IntegerLiteral = 184;
    public static readonly DecimalLiteral = 185;
    public static readonly DoubleLiteral = 186;
    public static readonly WS = 187;
    public static readonly NCName = 188;
    public static readonly XQComment = 189;
    public static readonly ContentChar = 190;
    public static readonly RULE_moduleAndThisIsIt = 0;
    public static readonly RULE_module = 1;
    public static readonly RULE_mainModule = 2;
    public static readonly RULE_libraryModule = 3;
    public static readonly RULE_prolog = 4;
    public static readonly RULE_program = 5;
    public static readonly RULE_statements = 6;
    public static readonly RULE_statementsAndExpr = 7;
    public static readonly RULE_statementsAndOptionalExpr = 8;
    public static readonly RULE_statement = 9;
    public static readonly RULE_applyStatement = 10;
    public static readonly RULE_assignStatement = 11;
    public static readonly RULE_blockStatement = 12;
    public static readonly RULE_breakStatement = 13;
    public static readonly RULE_continueStatement = 14;
    public static readonly RULE_exitStatement = 15;
    public static readonly RULE_flowrStatement = 16;
    public static readonly RULE_ifStatement = 17;
    public static readonly RULE_switchStatement = 18;
    public static readonly RULE_switchCaseStatement = 19;
    public static readonly RULE_tryCatchStatement = 20;
    public static readonly RULE_catchCaseStatement = 21;
    public static readonly RULE_typeSwitchStatement = 22;
    public static readonly RULE_caseStatement = 23;
    public static readonly RULE_annotation = 24;
    public static readonly RULE_annotations = 25;
    public static readonly RULE_varDeclStatement = 26;
    public static readonly RULE_varDeclForStatement = 27;
    public static readonly RULE_whileStatement = 28;
    public static readonly RULE_setter = 29;
    public static readonly RULE_namespaceDecl = 30;
    public static readonly RULE_annotatedDecl = 31;
    public static readonly RULE_defaultCollationDecl = 32;
    public static readonly RULE_baseURIDecl = 33;
    public static readonly RULE_orderingModeDecl = 34;
    public static readonly RULE_emptyOrderDecl = 35;
    public static readonly RULE_decimalFormatDecl = 36;
    public static readonly RULE_qname = 37;
    public static readonly RULE_dfPropertyName = 38;
    public static readonly RULE_moduleImport = 39;
    public static readonly RULE_varDecl = 40;
    public static readonly RULE_contextItemDecl = 41;
    public static readonly RULE_functionDecl = 42;
    public static readonly RULE_typeDecl = 43;
    public static readonly RULE_schemaLanguage = 44;
    public static readonly RULE_paramList = 45;
    public static readonly RULE_param = 46;
    public static readonly RULE_expr = 47;
    public static readonly RULE_exprSingle = 48;
    public static readonly RULE_exprSimple = 49;
    public static readonly RULE_flowrExpr = 50;
    public static readonly RULE_forClause = 51;
    public static readonly RULE_forVar = 52;
    public static readonly RULE_letClause = 53;
    public static readonly RULE_letVar = 54;
    public static readonly RULE_whereClause = 55;
    public static readonly RULE_groupByClause = 56;
    public static readonly RULE_groupByVar = 57;
    public static readonly RULE_orderByClause = 58;
    public static readonly RULE_orderByExpr = 59;
    public static readonly RULE_countClause = 60;
    public static readonly RULE_quantifiedExpr = 61;
    public static readonly RULE_quantifiedExprVar = 62;
    public static readonly RULE_switchExpr = 63;
    public static readonly RULE_switchCaseClause = 64;
    public static readonly RULE_typeSwitchExpr = 65;
    public static readonly RULE_caseClause = 66;
    public static readonly RULE_ifExpr = 67;
    public static readonly RULE_tryCatchExpr = 68;
    public static readonly RULE_catchClause = 69;
    public static readonly RULE_orExpr = 70;
    public static readonly RULE_andExpr = 71;
    public static readonly RULE_notExpr = 72;
    public static readonly RULE_comparisonExpr = 73;
    public static readonly RULE_stringConcatExpr = 74;
    public static readonly RULE_rangeExpr = 75;
    public static readonly RULE_additiveExpr = 76;
    public static readonly RULE_multiplicativeExpr = 77;
    public static readonly RULE_instanceOfExpr = 78;
    public static readonly RULE_isStaticallyExpr = 79;
    public static readonly RULE_treatExpr = 80;
    public static readonly RULE_castableExpr = 81;
    public static readonly RULE_castExpr = 82;
    public static readonly RULE_arrowExpr = 83;
    public static readonly RULE_arrowFunctionSpecifier = 84;
    public static readonly RULE_unaryExpr = 85;
    public static readonly RULE_valueExpr = 86;
    public static readonly RULE_validateExpr = 87;
    public static readonly RULE_annotateExpr = 88;
    public static readonly RULE_simpleMapExpr = 89;
    public static readonly RULE_postFixExpr = 90;
    public static readonly RULE_arrayLookup = 91;
    public static readonly RULE_arrayUnboxing = 92;
    public static readonly RULE_predicate = 93;
    public static readonly RULE_objectLookup = 94;
    public static readonly RULE_primaryExpr = 95;
    public static readonly RULE_blockExpr = 96;
    public static readonly RULE_varRef = 97;
    public static readonly RULE_parenthesizedExpr = 98;
    public static readonly RULE_contextItemExpr = 99;
    public static readonly RULE_orderedExpr = 100;
    public static readonly RULE_unorderedExpr = 101;
    public static readonly RULE_functionCall = 102;
    public static readonly RULE_argumentList = 103;
    public static readonly RULE_argument = 104;
    public static readonly RULE_functionItemExpr = 105;
    public static readonly RULE_namedFunctionRef = 106;
    public static readonly RULE_inlineFunctionExpr = 107;
    public static readonly RULE_insertExpr = 108;
    public static readonly RULE_deleteExpr = 109;
    public static readonly RULE_renameExpr = 110;
    public static readonly RULE_replaceExpr = 111;
    public static readonly RULE_transformExpr = 112;
    public static readonly RULE_appendExpr = 113;
    public static readonly RULE_updateLocator = 114;
    public static readonly RULE_copyDecl = 115;
    public static readonly RULE_createCollectionExpr = 116;
    public static readonly RULE_deleteIndexExpr = 117;
    public static readonly RULE_deleteSearchExpr = 118;
    public static readonly RULE_insertIndexExpr = 119;
    public static readonly RULE_insertSearchExpr = 120;
    public static readonly RULE_truncateCollectionExpr = 121;
    public static readonly RULE_editCollectionExpr = 122;
    public static readonly RULE_pathExpr = 123;
    public static readonly RULE_relativePathExpr = 124;
    public static readonly RULE_stepExpr = 125;
    public static readonly RULE_axisStep = 126;
    public static readonly RULE_forwardStep = 127;
    public static readonly RULE_forwardAxis = 128;
    public static readonly RULE_abbrevForwardStep = 129;
    public static readonly RULE_reverseStep = 130;
    public static readonly RULE_reverseAxis = 131;
    public static readonly RULE_abbrevReverseStep = 132;
    public static readonly RULE_nodeTest = 133;
    public static readonly RULE_nameTest = 134;
    public static readonly RULE_wildcard = 135;
    public static readonly RULE_nCNameWithLocalWildcard = 136;
    public static readonly RULE_nCNameWithPrefixWildcard = 137;
    public static readonly RULE_predicateList = 138;
    public static readonly RULE_kindTest = 139;
    public static readonly RULE_anyKindTest = 140;
    public static readonly RULE_binaryNodeTest = 141;
    public static readonly RULE_documentTest = 142;
    public static readonly RULE_textTest = 143;
    public static readonly RULE_commentTest = 144;
    public static readonly RULE_namespaceNodeTest = 145;
    public static readonly RULE_piTest = 146;
    public static readonly RULE_attributeTest = 147;
    public static readonly RULE_attributeNameOrWildcard = 148;
    public static readonly RULE_schemaAttributeTest = 149;
    public static readonly RULE_attributeDeclaration = 150;
    public static readonly RULE_elementTest = 151;
    public static readonly RULE_elementNameOrWildcard = 152;
    public static readonly RULE_schemaElementTest = 153;
    public static readonly RULE_elementDeclaration = 154;
    public static readonly RULE_attributeName = 155;
    public static readonly RULE_elementName = 156;
    public static readonly RULE_simpleTypeName = 157;
    public static readonly RULE_typeName = 158;
    public static readonly RULE_sequenceType = 159;
    public static readonly RULE_objectConstructor = 160;
    public static readonly RULE_itemType = 161;
    public static readonly RULE_functionTest = 162;
    public static readonly RULE_anyFunctionTest = 163;
    public static readonly RULE_typedFunctionTest = 164;
    public static readonly RULE_singleType = 165;
    public static readonly RULE_pairConstructor = 166;
    public static readonly RULE_arrayConstructor = 167;
    public static readonly RULE_uriLiteral = 168;
    public static readonly RULE_stringLiteral = 169;
    public static readonly RULE_keyWords = 170;

    public static readonly literalNames = [
        null, "';'", "'module'", "'='", "'$'", "':='", "'{'", "'}'", "'('", 
        "')'", "'*'", "'|'", "'%'", "','", "'base-uri'", "'ordering'", "'ordered'", 
        "'decimal-format'", "':'", "'decimal-separator'", "'grouping-separator'", 
        "'infinity'", "'minus-sign'", "'NaN'", "'percent'", "'per-mille'", 
        "'zero-digit'", "'digit'", "'pattern-separator'", "'external'", 
        "'function'", "'jsound'", "'compact'", "'verbose'", "'eq'", "'ne'", 
        "'lt'", "'le'", "'gt'", "'ge'", "'!='", "'<'", "'<='", "'>'", "'>='", 
        "'||'", "'+'", "'-'", "'div'", "'idiv'", "'mod'", "'!'", "'['", 
        "']'", "'.'", "'$$'", "'#'", "'..'", "'{|'", "'|}'", "'for'", "'let'", 
        "'where'", "'group'", "'by'", "'order'", "'return'", "'if'", "'in'", 
        "'as'", "'at'", "'allowing'", "'empty'", "'count'", "'stable'", 
        "'ascending'", "'descending'", "'some'", "'every'", "'satisfies'", 
        "'collation'", "'greatest'", "'least'", "'switch'", "'case'", "'try'", 
        "'catch'", "'default'", "'then'", "'else'", "'typeswitch'", "'or'", 
        "'and'", "'not'", "'to'", "'instance'", "'of'", "'statically'", 
        "'is'", "'treat'", "'cast'", "'castable'", "'version'", "'jsoniq'", 
        "'unordered'", "'true'", "'false'", "'type'", "'validate'", "'annotate'", 
        "'declare'", "'context'", "'item'", "'variable'", "'insert'", "'delete'", 
        "'rename'", "'replace'", "'copy'", "'modify'", "'append'", "'into'", 
        "'value'", "'with'", "'position'", "'json'", "'updating'", "'create'", 
        "'collection'", "'table'", "'delta-file'", "'iceberg-table'", "'truncate'", 
        "'first'", "'last'", "'from'", "'edit'", "'after'", "'before'", 
        "'import'", "'schema'", "'namespace'", "'element'", "'/'", "'//'", 
        "'@'", "'child'", "'descendant'", "'attribute'", "'self'", "'descendant-or-self'", 
        "'following-sibling'", "'following'", "'parent'", "'ancestor'", 
        "'preceding-sibling'", "'preceding'", "'ancestor-or-self'", "'node'", 
        "'binary'", "'document'", "'document-node'", "'text'", "'processing-instruction'", 
        "'namespace-node'", "'schema-attribute'", "'schema-element'", "'array-node'", 
        "'boolean-node'", "'null-node'", "'number-node'", "'object-node'", 
        "'comment'", "'break'", "'loop'", "'continue'", "'exit'", "'returning'", 
        "'while'", null, "'?'", "'null'"
    ];

    public static readonly symbolicNames = [
        null, "Ksemicolon", "Kmodule", "Kequal", "Kdollar", "Kassign", "Klbrace", 
        "Krbrace", "Klparen", "Krparen", "Kasterisk", "Kpipe", "Kannotation", 
        "Kcomma", "Kbase_uri", "Kordering", "Kordered", "Kdecimal_format", 
        "Kcolon", "Kdecimal_separator", "Kgrouping_separator", "Kinfinity", 
        "Kminus_sign", "Knan", "Kpercent", "Kper_mille", "Kzero_digit", 
        "Kdigit", "Kpattern_separator", "Kexternal", "Kfunction", "Kjsound", 
        "Kcompact", "Kverbose", "Keq", "Kne", "Klt", "Kle", "Kgt", "Kge", 
        "Knot_equal", "Kless", "Kless_or_equal", "Kgreater", "Kgreater_or_equal", 
        "Kconcat", "Kplus", "Kminus", "Kdiv", "Kidiv", "Kmod", "Kbang", 
        "Klbracket", "Krbracket", "Kdot", "Kcontext_item", "Khash", "Kdotdot", 
        "Kobject_start", "Kobject_end", "Kfor", "Klet", "Kwhere", "Kgroup", 
        "Kby", "Korder", "Kreturn", "Kif", "Kin", "Kas", "Kat", "Kallowing", 
        "Kempty", "Kcount", "Kstable", "Kascending", "Kdescending", "Ksome", 
        "Kevery", "Ksatisfies", "Kcollation", "Kgreatest", "Kleast", "Kswitch", 
        "Kcase", "Ktry", "Kcatch", "Kdefault", "Kthen", "Kelse", "Ktypeswitch", 
        "Kor", "Kand", "Knot", "Kto", "Kinstance", "Kof", "Kstatically", 
        "Kis", "Ktreat", "Kcast", "Kcastable", "Kversion", "Kjsoniq", "Kunordered", 
        "Ktrue", "Kfalse", "Ktype", "Kvalidate", "Kannotate", "Kdeclare", 
        "Kcontext", "Kitem", "Kvariable", "Kinsert", "Kdelete", "Krename", 
        "Kreplace", "Kcopy", "Kmodify", "Kappend", "Kinto", "Kvalue", "Kwith", 
        "Kposition", "Kjson", "Kupdating", "Kcreate", "Kcollection", "Ktable", 
        "Kdeltafile", "Kicebergtable", "Ktruncate", "Kfirst", "Klast", "Kfrom", 
        "Kedit", "Kafter", "Kbefore", "Kimport", "Kschema", "Knamespace", 
        "Kelement", "Kslash", "Kdslash", "Kat_symbol", "Kchild", "Kdescendant", 
        "Kattribute", "Kself", "Kdescendant_or_self", "Kfollowing_sibling", 
        "Kfollowing", "Kparent", "Kancestor", "Kpreceding_sibling", "Kpreceding", 
        "Kancestor_or_self", "Knode", "Kbinary", "Kdocument", "Kdocument_node", 
        "Ktext", "Kpi", "Knamespace_node", "Kschema_attribute", "Kschema_element", 
        "Karray_node", "Kboolean_node", "Knull_node", "Knumber_node", "Kobject_node", 
        "Kcomment", "Kbreak", "Kloop", "Kcontinue", "Kexit", "Kreturning", 
        "Kwhile", "STRING", "ArgumentPlaceholder", "NullLiteral", "Literal", 
        "NumericLiteral", "IntegerLiteral", "DecimalLiteral", "DoubleLiteral", 
        "WS", "NCName", "XQComment", "ContentChar"
    ];
    public static readonly ruleNames = [
        "moduleAndThisIsIt", "module", "mainModule", "libraryModule", "prolog", 
        "program", "statements", "statementsAndExpr", "statementsAndOptionalExpr", 
        "statement", "applyStatement", "assignStatement", "blockStatement", 
        "breakStatement", "continueStatement", "exitStatement", "flowrStatement", 
        "ifStatement", "switchStatement", "switchCaseStatement", "tryCatchStatement", 
        "catchCaseStatement", "typeSwitchStatement", "caseStatement", "annotation", 
        "annotations", "varDeclStatement", "varDeclForStatement", "whileStatement", 
        "setter", "namespaceDecl", "annotatedDecl", "defaultCollationDecl", 
        "baseURIDecl", "orderingModeDecl", "emptyOrderDecl", "decimalFormatDecl", 
        "qname", "dfPropertyName", "moduleImport", "varDecl", "contextItemDecl", 
        "functionDecl", "typeDecl", "schemaLanguage", "paramList", "param", 
        "expr", "exprSingle", "exprSimple", "flowrExpr", "forClause", "forVar", 
        "letClause", "letVar", "whereClause", "groupByClause", "groupByVar", 
        "orderByClause", "orderByExpr", "countClause", "quantifiedExpr", 
        "quantifiedExprVar", "switchExpr", "switchCaseClause", "typeSwitchExpr", 
        "caseClause", "ifExpr", "tryCatchExpr", "catchClause", "orExpr", 
        "andExpr", "notExpr", "comparisonExpr", "stringConcatExpr", "rangeExpr", 
        "additiveExpr", "multiplicativeExpr", "instanceOfExpr", "isStaticallyExpr", 
        "treatExpr", "castableExpr", "castExpr", "arrowExpr", "arrowFunctionSpecifier", 
        "unaryExpr", "valueExpr", "validateExpr", "annotateExpr", "simpleMapExpr", 
        "postFixExpr", "arrayLookup", "arrayUnboxing", "predicate", "objectLookup", 
        "primaryExpr", "blockExpr", "varRef", "parenthesizedExpr", "contextItemExpr", 
        "orderedExpr", "unorderedExpr", "functionCall", "argumentList", 
        "argument", "functionItemExpr", "namedFunctionRef", "inlineFunctionExpr", 
        "insertExpr", "deleteExpr", "renameExpr", "replaceExpr", "transformExpr", 
        "appendExpr", "updateLocator", "copyDecl", "createCollectionExpr", 
        "deleteIndexExpr", "deleteSearchExpr", "insertIndexExpr", "insertSearchExpr", 
        "truncateCollectionExpr", "editCollectionExpr", "pathExpr", "relativePathExpr", 
        "stepExpr", "axisStep", "forwardStep", "forwardAxis", "abbrevForwardStep", 
        "reverseStep", "reverseAxis", "abbrevReverseStep", "nodeTest", "nameTest", 
        "wildcard", "nCNameWithLocalWildcard", "nCNameWithPrefixWildcard", 
        "predicateList", "kindTest", "anyKindTest", "binaryNodeTest", "documentTest", 
        "textTest", "commentTest", "namespaceNodeTest", "piTest", "attributeTest", 
        "attributeNameOrWildcard", "schemaAttributeTest", "attributeDeclaration", 
        "elementTest", "elementNameOrWildcard", "schemaElementTest", "elementDeclaration", 
        "attributeName", "elementName", "simpleTypeName", "typeName", "sequenceType", 
        "objectConstructor", "itemType", "functionTest", "anyFunctionTest", 
        "typedFunctionTest", "singleType", "pairConstructor", "arrayConstructor", 
        "uriLiteral", "stringLiteral", "keyWords",
    ];

    public get grammarFileName(): string { return "jsoniq.g4"; }
    public get literalNames(): (string | null)[] { return jsoniqParser.literalNames; }
    public get symbolicNames(): (string | null)[] { return jsoniqParser.symbolicNames; }
    public get ruleNames(): string[] { return jsoniqParser.ruleNames; }
    public get serializedATN(): number[] { return jsoniqParser._serializedATN; }

    protected createFailedPredicateException(predicate?: string, message?: string): antlr.FailedPredicateException {
        return new antlr.FailedPredicateException(this, predicate, message);
    }

    public constructor(input: antlr.TokenStream) {
        super(input);
        this.interpreter = new antlr.ParserATNSimulator(this, jsoniqParser._ATN, jsoniqParser.decisionsToDFA, new antlr.PredictionContextCache());
    }
    public moduleAndThisIsIt(): ModuleAndThisIsItContext {
        let localContext = new ModuleAndThisIsItContext(this.context, this.state);
        this.enterRule(localContext, 0, jsoniqParser.RULE_moduleAndThisIsIt);
        try {
            this.enterOuterAlt(localContext, 1);
            {
            this.state = 342;
            this.module_();
            this.state = 343;
            this.match(jsoniqParser.EOF);
            }
        }
        catch (re) {
            if (re instanceof antlr.RecognitionException) {
                this.errorHandler.reportError(this, re);
                this.errorHandler.recover(this, re);
            } else {
                throw re;
            }
        }
        finally {
            this.exitRule();
        }
        return localContext;
    }
    public module_(): ModuleContext {
        let localContext = new ModuleContext(this.context, this.state);
        this.enterRule(localContext, 2, jsoniqParser.RULE_module);
        try {
            this.enterOuterAlt(localContext, 1);
            {
            this.state = 350;
            this.errorHandler.sync(this);
            switch (this.interpreter.adaptivePredict(this.tokenStream, 0, this.context) ) {
            case 1:
                {
                this.state = 345;
                this.match(jsoniqParser.Kjsoniq);
                this.state = 346;
                this.match(jsoniqParser.Kversion);
                this.state = 347;
                localContext._vers = this.stringLiteral();
                this.state = 348;
                this.match(jsoniqParser.Ksemicolon);
                }
                break;
            }
            this.state = 354;
            this.errorHandler.sync(this);
            switch (this.tokenStream.LA(1)) {
            case jsoniqParser.Kmodule:
                {
                this.state = 352;
                this.libraryModule();
                }
                break;
            case jsoniqParser.EOF:
            case jsoniqParser.Kdollar:
            case jsoniqParser.Klbrace:
            case jsoniqParser.Klparen:
            case jsoniqParser.Kasterisk:
            case jsoniqParser.Kannotation:
            case jsoniqParser.Kordered:
            case jsoniqParser.Kfunction:
            case jsoniqParser.Kplus:
            case jsoniqParser.Kminus:
            case jsoniqParser.Klbracket:
            case jsoniqParser.Kcontext_item:
            case jsoniqParser.Kdotdot:
            case jsoniqParser.Kobject_start:
            case jsoniqParser.Kfor:
            case jsoniqParser.Klet:
            case jsoniqParser.Kwhere:
            case jsoniqParser.Kgroup:
            case jsoniqParser.Kby:
            case jsoniqParser.Korder:
            case jsoniqParser.Kreturn:
            case jsoniqParser.Kif:
            case jsoniqParser.Kin:
            case jsoniqParser.Kas:
            case jsoniqParser.Kat:
            case jsoniqParser.Kallowing:
            case jsoniqParser.Kempty:
            case jsoniqParser.Kcount:
            case jsoniqParser.Kstable:
            case jsoniqParser.Kascending:
            case jsoniqParser.Kdescending:
            case jsoniqParser.Ksome:
            case jsoniqParser.Kevery:
            case jsoniqParser.Ksatisfies:
            case jsoniqParser.Kcollation:
            case jsoniqParser.Kgreatest:
            case jsoniqParser.Kleast:
            case jsoniqParser.Kswitch:
            case jsoniqParser.Kcase:
            case jsoniqParser.Ktry:
            case jsoniqParser.Kcatch:
            case jsoniqParser.Kdefault:
            case jsoniqParser.Kthen:
            case jsoniqParser.Kelse:
            case jsoniqParser.Ktypeswitch:
            case jsoniqParser.Kor:
            case jsoniqParser.Kand:
            case jsoniqParser.Knot:
            case jsoniqParser.Kto:
            case jsoniqParser.Kinstance:
            case jsoniqParser.Kof:
            case jsoniqParser.Kstatically:
            case jsoniqParser.Kis:
            case jsoniqParser.Ktreat:
            case jsoniqParser.Kcast:
            case jsoniqParser.Kcastable:
            case jsoniqParser.Kversion:
            case jsoniqParser.Kjsoniq:
            case jsoniqParser.Kunordered:
            case jsoniqParser.Ktrue:
            case jsoniqParser.Kfalse:
            case jsoniqParser.Ktype:
            case jsoniqParser.Kvalidate:
            case jsoniqParser.Kannotate:
            case jsoniqParser.Kdeclare:
            case jsoniqParser.Kcontext:
            case jsoniqParser.Kitem:
            case jsoniqParser.Kvariable:
            case jsoniqParser.Kinsert:
            case jsoniqParser.Kdelete:
            case jsoniqParser.Krename:
            case jsoniqParser.Kreplace:
            case jsoniqParser.Kcopy:
            case jsoniqParser.Kmodify:
            case jsoniqParser.Kappend:
            case jsoniqParser.Kinto:
            case jsoniqParser.Kvalue:
            case jsoniqParser.Kwith:
            case jsoniqParser.Kposition:
            case jsoniqParser.Kjson:
            case jsoniqParser.Kupdating:
            case jsoniqParser.Kcreate:
            case jsoniqParser.Kcollection:
            case jsoniqParser.Ktable:
            case jsoniqParser.Kdeltafile:
            case jsoniqParser.Kicebergtable:
            case jsoniqParser.Ktruncate:
            case jsoniqParser.Kfirst:
            case jsoniqParser.Klast:
            case jsoniqParser.Kfrom:
            case jsoniqParser.Kedit:
            case jsoniqParser.Kafter:
            case jsoniqParser.Kbefore:
            case jsoniqParser.Kimport:
            case jsoniqParser.Kschema:
            case jsoniqParser.Knamespace:
            case jsoniqParser.Kelement:
            case jsoniqParser.Kslash:
            case jsoniqParser.Kdslash:
            case jsoniqParser.Kat_symbol:
            case jsoniqParser.Kchild:
            case jsoniqParser.Kdescendant:
            case jsoniqParser.Kattribute:
            case jsoniqParser.Kself:
            case jsoniqParser.Kdescendant_or_self:
            case jsoniqParser.Kfollowing_sibling:
            case jsoniqParser.Kfollowing:
            case jsoniqParser.Kparent:
            case jsoniqParser.Kancestor:
            case jsoniqParser.Kpreceding_sibling:
            case jsoniqParser.Kpreceding:
            case jsoniqParser.Kancestor_or_self:
            case jsoniqParser.Knode:
            case jsoniqParser.Kbinary:
            case jsoniqParser.Kdocument:
            case jsoniqParser.Kdocument_node:
            case jsoniqParser.Ktext:
            case jsoniqParser.Kpi:
            case jsoniqParser.Knamespace_node:
            case jsoniqParser.Kschema_attribute:
            case jsoniqParser.Kschema_element:
            case jsoniqParser.Karray_node:
            case jsoniqParser.Kboolean_node:
            case jsoniqParser.Knull_node:
            case jsoniqParser.Knumber_node:
            case jsoniqParser.Kobject_node:
            case jsoniqParser.Kcomment:
            case jsoniqParser.Kbreak:
            case jsoniqParser.Kloop:
            case jsoniqParser.Kcontinue:
            case jsoniqParser.Kexit:
            case jsoniqParser.Kreturning:
            case jsoniqParser.Kwhile:
            case jsoniqParser.STRING:
            case jsoniqParser.NullLiteral:
            case jsoniqParser.Literal:
            case jsoniqParser.NCName:
                {
                this.state = 353;
                localContext._main = this.mainModule();
                }
                break;
            default:
                throw new antlr.NoViableAltException(this);
            }
            }
        }
        catch (re) {
            if (re instanceof antlr.RecognitionException) {
                this.errorHandler.reportError(this, re);
                this.errorHandler.recover(this, re);
            } else {
                throw re;
            }
        }
        finally {
            this.exitRule();
        }
        return localContext;
    }
    public mainModule(): MainModuleContext {
        let localContext = new MainModuleContext(this.context, this.state);
        this.enterRule(localContext, 4, jsoniqParser.RULE_mainModule);
        try {
            this.enterOuterAlt(localContext, 1);
            {
            this.state = 356;
            this.prolog();
            this.state = 357;
            this.program();
            }
        }
        catch (re) {
            if (re instanceof antlr.RecognitionException) {
                this.errorHandler.reportError(this, re);
                this.errorHandler.recover(this, re);
            } else {
                throw re;
            }
        }
        finally {
            this.exitRule();
        }
        return localContext;
    }
    public libraryModule(): LibraryModuleContext {
        let localContext = new LibraryModuleContext(this.context, this.state);
        this.enterRule(localContext, 6, jsoniqParser.RULE_libraryModule);
        try {
            this.enterOuterAlt(localContext, 1);
            {
            this.state = 359;
            this.match(jsoniqParser.Kmodule);
            this.state = 360;
            this.match(jsoniqParser.Knamespace);
            this.state = 361;
            this.match(jsoniqParser.NCName);
            this.state = 362;
            this.match(jsoniqParser.Kequal);
            this.state = 363;
            this.uriLiteral();
            this.state = 364;
            this.match(jsoniqParser.Ksemicolon);
            this.state = 365;
            this.prolog();
            }
        }
        catch (re) {
            if (re instanceof antlr.RecognitionException) {
                this.errorHandler.reportError(this, re);
                this.errorHandler.recover(this, re);
            } else {
                throw re;
            }
        }
        finally {
            this.exitRule();
        }
        return localContext;
    }
    public prolog(): PrologContext {
        let localContext = new PrologContext(this.context, this.state);
        this.enterRule(localContext, 8, jsoniqParser.RULE_prolog);
        try {
            let alternative: number;
            this.enterOuterAlt(localContext, 1);
            {
            this.state = 376;
            this.errorHandler.sync(this);
            alternative = this.interpreter.adaptivePredict(this.tokenStream, 3, this.context);
            while (alternative !== 2 && alternative !== antlr.ATN.INVALID_ALT_NUMBER) {
                if (alternative === 1) {
                    {
                    {
                    this.state = 370;
                    this.errorHandler.sync(this);
                    switch (this.interpreter.adaptivePredict(this.tokenStream, 2, this.context) ) {
                    case 1:
                        {
                        this.state = 367;
                        this.setter();
                        }
                        break;
                    case 2:
                        {
                        this.state = 368;
                        this.namespaceDecl();
                        }
                        break;
                    case 3:
                        {
                        this.state = 369;
                        this.moduleImport();
                        }
                        break;
                    }
                    this.state = 372;
                    this.match(jsoniqParser.Ksemicolon);
                    }
                    }
                }
                this.state = 378;
                this.errorHandler.sync(this);
                alternative = this.interpreter.adaptivePredict(this.tokenStream, 3, this.context);
            }
            this.state = 384;
            this.errorHandler.sync(this);
            alternative = this.interpreter.adaptivePredict(this.tokenStream, 4, this.context);
            while (alternative !== 2 && alternative !== antlr.ATN.INVALID_ALT_NUMBER) {
                if (alternative === 1) {
                    {
                    {
                    this.state = 379;
                    this.annotatedDecl();
                    this.state = 380;
                    this.match(jsoniqParser.Ksemicolon);
                    }
                    }
                }
                this.state = 386;
                this.errorHandler.sync(this);
                alternative = this.interpreter.adaptivePredict(this.tokenStream, 4, this.context);
            }
            }
        }
        catch (re) {
            if (re instanceof antlr.RecognitionException) {
                this.errorHandler.reportError(this, re);
                this.errorHandler.recover(this, re);
            } else {
                throw re;
            }
        }
        finally {
            this.exitRule();
        }
        return localContext;
    }
    public program(): ProgramContext {
        let localContext = new ProgramContext(this.context, this.state);
        this.enterRule(localContext, 10, jsoniqParser.RULE_program);
        try {
            this.enterOuterAlt(localContext, 1);
            {
            this.state = 387;
            this.statementsAndOptionalExpr();
            }
        }
        catch (re) {
            if (re instanceof antlr.RecognitionException) {
                this.errorHandler.reportError(this, re);
                this.errorHandler.recover(this, re);
            } else {
                throw re;
            }
        }
        finally {
            this.exitRule();
        }
        return localContext;
    }
    public statements(): StatementsContext {
        let localContext = new StatementsContext(this.context, this.state);
        this.enterRule(localContext, 12, jsoniqParser.RULE_statements);
        try {
            let alternative: number;
            this.enterOuterAlt(localContext, 1);
            {
            this.state = 392;
            this.errorHandler.sync(this);
            alternative = this.interpreter.adaptivePredict(this.tokenStream, 5, this.context);
            while (alternative !== 2 && alternative !== antlr.ATN.INVALID_ALT_NUMBER) {
                if (alternative === 1) {
                    {
                    {
                    this.state = 389;
                    this.statement();
                    }
                    }
                }
                this.state = 394;
                this.errorHandler.sync(this);
                alternative = this.interpreter.adaptivePredict(this.tokenStream, 5, this.context);
            }
            }
        }
        catch (re) {
            if (re instanceof antlr.RecognitionException) {
                this.errorHandler.reportError(this, re);
                this.errorHandler.recover(this, re);
            } else {
                throw re;
            }
        }
        finally {
            this.exitRule();
        }
        return localContext;
    }
    public statementsAndExpr(): StatementsAndExprContext {
        let localContext = new StatementsAndExprContext(this.context, this.state);
        this.enterRule(localContext, 14, jsoniqParser.RULE_statementsAndExpr);
        try {
            this.enterOuterAlt(localContext, 1);
            {
            this.state = 395;
            this.statements();
            this.state = 396;
            this.expr();
            }
        }
        catch (re) {
            if (re instanceof antlr.RecognitionException) {
                this.errorHandler.reportError(this, re);
                this.errorHandler.recover(this, re);
            } else {
                throw re;
            }
        }
        finally {
            this.exitRule();
        }
        return localContext;
    }
    public statementsAndOptionalExpr(): StatementsAndOptionalExprContext {
        let localContext = new StatementsAndOptionalExprContext(this.context, this.state);
        this.enterRule(localContext, 16, jsoniqParser.RULE_statementsAndOptionalExpr);
        let _la: number;
        try {
            this.enterOuterAlt(localContext, 1);
            {
            this.state = 398;
            this.statements();
            this.state = 400;
            this.errorHandler.sync(this);
            _la = this.tokenStream.LA(1);
            if ((((_la) & ~0x1F) === 0 && ((1 << _la) & 1073812816) !== 0) || ((((_la - 46)) & ~0x1F) === 0 && ((1 << (_la - 46)) & 4294957635) !== 0) || ((((_la - 78)) & ~0x1F) === 0 && ((1 << (_la - 78)) & 4294967295) !== 0) || ((((_la - 110)) & ~0x1F) === 0 && ((1 << (_la - 110)) & 4294967295) !== 0) || ((((_la - 142)) & ~0x1F) === 0 && ((1 << (_la - 142)) & 4294967295) !== 0) || ((((_la - 174)) & ~0x1F) === 0 && ((1 << (_la - 174)) & 16831) !== 0)) {
                {
                this.state = 399;
                this.expr();
                }
            }

            }
        }
        catch (re) {
            if (re instanceof antlr.RecognitionException) {
                this.errorHandler.reportError(this, re);
                this.errorHandler.recover(this, re);
            } else {
                throw re;
            }
        }
        finally {
            this.exitRule();
        }
        return localContext;
    }
    public statement(): StatementContext {
        let localContext = new StatementContext(this.context, this.state);
        this.enterRule(localContext, 18, jsoniqParser.RULE_statement);
        try {
            this.state = 415;
            this.errorHandler.sync(this);
            switch (this.interpreter.adaptivePredict(this.tokenStream, 7, this.context) ) {
            case 1:
                this.enterOuterAlt(localContext, 1);
                {
                this.state = 402;
                this.applyStatement();
                }
                break;
            case 2:
                this.enterOuterAlt(localContext, 2);
                {
                this.state = 403;
                this.assignStatement();
                }
                break;
            case 3:
                this.enterOuterAlt(localContext, 3);
                {
                this.state = 404;
                this.blockStatement();
                }
                break;
            case 4:
                this.enterOuterAlt(localContext, 4);
                {
                this.state = 405;
                this.breakStatement();
                }
                break;
            case 5:
                this.enterOuterAlt(localContext, 5);
                {
                this.state = 406;
                this.continueStatement();
                }
                break;
            case 6:
                this.enterOuterAlt(localContext, 6);
                {
                this.state = 407;
                this.exitStatement();
                }
                break;
            case 7:
                this.enterOuterAlt(localContext, 7);
                {
                this.state = 408;
                this.flowrStatement();
                }
                break;
            case 8:
                this.enterOuterAlt(localContext, 8);
                {
                this.state = 409;
                this.ifStatement();
                }
                break;
            case 9:
                this.enterOuterAlt(localContext, 9);
                {
                this.state = 410;
                this.switchStatement();
                }
                break;
            case 10:
                this.enterOuterAlt(localContext, 10);
                {
                this.state = 411;
                this.tryCatchStatement();
                }
                break;
            case 11:
                this.enterOuterAlt(localContext, 11);
                {
                this.state = 412;
                this.typeSwitchStatement();
                }
                break;
            case 12:
                this.enterOuterAlt(localContext, 12);
                {
                this.state = 413;
                this.varDeclStatement();
                }
                break;
            case 13:
                this.enterOuterAlt(localContext, 13);
                {
                this.state = 414;
                this.whileStatement();
                }
                break;
            }
        }
        catch (re) {
            if (re instanceof antlr.RecognitionException) {
                this.errorHandler.reportError(this, re);
                this.errorHandler.recover(this, re);
            } else {
                throw re;
            }
        }
        finally {
            this.exitRule();
        }
        return localContext;
    }
    public applyStatement(): ApplyStatementContext {
        let localContext = new ApplyStatementContext(this.context, this.state);
        this.enterRule(localContext, 20, jsoniqParser.RULE_applyStatement);
        try {
            this.enterOuterAlt(localContext, 1);
            {
            this.state = 417;
            this.exprSimple();
            this.state = 418;
            this.match(jsoniqParser.Ksemicolon);
            }
        }
        catch (re) {
            if (re instanceof antlr.RecognitionException) {
                this.errorHandler.reportError(this, re);
                this.errorHandler.recover(this, re);
            } else {
                throw re;
            }
        }
        finally {
            this.exitRule();
        }
        return localContext;
    }
    public assignStatement(): AssignStatementContext {
        let localContext = new AssignStatementContext(this.context, this.state);
        this.enterRule(localContext, 22, jsoniqParser.RULE_assignStatement);
        try {
            this.enterOuterAlt(localContext, 1);
            {
            this.state = 420;
            this.match(jsoniqParser.Kdollar);
            this.state = 421;
            this.qname();
            this.state = 422;
            this.match(jsoniqParser.Kassign);
            this.state = 423;
            this.exprSingle();
            this.state = 424;
            this.match(jsoniqParser.Ksemicolon);
            }
        }
        catch (re) {
            if (re instanceof antlr.RecognitionException) {
                this.errorHandler.reportError(this, re);
                this.errorHandler.recover(this, re);
            } else {
                throw re;
            }
        }
        finally {
            this.exitRule();
        }
        return localContext;
    }
    public blockStatement(): BlockStatementContext {
        let localContext = new BlockStatementContext(this.context, this.state);
        this.enterRule(localContext, 24, jsoniqParser.RULE_blockStatement);
        try {
            this.enterOuterAlt(localContext, 1);
            {
            this.state = 426;
            this.match(jsoniqParser.Klbrace);
            this.state = 427;
            this.statements();
            this.state = 428;
            this.match(jsoniqParser.Krbrace);
            }
        }
        catch (re) {
            if (re instanceof antlr.RecognitionException) {
                this.errorHandler.reportError(this, re);
                this.errorHandler.recover(this, re);
            } else {
                throw re;
            }
        }
        finally {
            this.exitRule();
        }
        return localContext;
    }
    public breakStatement(): BreakStatementContext {
        let localContext = new BreakStatementContext(this.context, this.state);
        this.enterRule(localContext, 26, jsoniqParser.RULE_breakStatement);
        try {
            this.enterOuterAlt(localContext, 1);
            {
            this.state = 430;
            this.match(jsoniqParser.Kbreak);
            this.state = 431;
            this.match(jsoniqParser.Kloop);
            this.state = 432;
            this.match(jsoniqParser.Ksemicolon);
            }
        }
        catch (re) {
            if (re instanceof antlr.RecognitionException) {
                this.errorHandler.reportError(this, re);
                this.errorHandler.recover(this, re);
            } else {
                throw re;
            }
        }
        finally {
            this.exitRule();
        }
        return localContext;
    }
    public continueStatement(): ContinueStatementContext {
        let localContext = new ContinueStatementContext(this.context, this.state);
        this.enterRule(localContext, 28, jsoniqParser.RULE_continueStatement);
        try {
            this.enterOuterAlt(localContext, 1);
            {
            this.state = 434;
            this.match(jsoniqParser.Kcontinue);
            this.state = 435;
            this.match(jsoniqParser.Kloop);
            this.state = 436;
            this.match(jsoniqParser.Ksemicolon);
            }
        }
        catch (re) {
            if (re instanceof antlr.RecognitionException) {
                this.errorHandler.reportError(this, re);
                this.errorHandler.recover(this, re);
            } else {
                throw re;
            }
        }
        finally {
            this.exitRule();
        }
        return localContext;
    }
    public exitStatement(): ExitStatementContext {
        let localContext = new ExitStatementContext(this.context, this.state);
        this.enterRule(localContext, 30, jsoniqParser.RULE_exitStatement);
        try {
            this.enterOuterAlt(localContext, 1);
            {
            this.state = 438;
            this.match(jsoniqParser.Kexit);
            this.state = 439;
            this.match(jsoniqParser.Kreturning);
            this.state = 440;
            this.exprSingle();
            this.state = 441;
            this.match(jsoniqParser.Ksemicolon);
            }
        }
        catch (re) {
            if (re instanceof antlr.RecognitionException) {
                this.errorHandler.reportError(this, re);
                this.errorHandler.recover(this, re);
            } else {
                throw re;
            }
        }
        finally {
            this.exitRule();
        }
        return localContext;
    }
    public flowrStatement(): FlowrStatementContext {
        let localContext = new FlowrStatementContext(this.context, this.state);
        this.enterRule(localContext, 32, jsoniqParser.RULE_flowrStatement);
        let _la: number;
        try {
            this.enterOuterAlt(localContext, 1);
            {
            this.state = 445;
            this.errorHandler.sync(this);
            switch (this.tokenStream.LA(1)) {
            case jsoniqParser.Kfor:
                {
                this.state = 443;
                localContext._start_for = this.forClause();
                }
                break;
            case jsoniqParser.Klet:
                {
                this.state = 444;
                localContext._start_let = this.letClause();
                }
                break;
            default:
                throw new antlr.NoViableAltException(this);
            }
            this.state = 455;
            this.errorHandler.sync(this);
            _la = this.tokenStream.LA(1);
            while (((((_la - 60)) & ~0x1F) === 0 && ((1 << (_la - 60)) & 24623) !== 0)) {
                {
                this.state = 453;
                this.errorHandler.sync(this);
                switch (this.tokenStream.LA(1)) {
                case jsoniqParser.Kfor:
                    {
                    this.state = 447;
                    this.forClause();
                    }
                    break;
                case jsoniqParser.Klet:
                    {
                    this.state = 448;
                    this.letClause();
                    }
                    break;
                case jsoniqParser.Kwhere:
                    {
                    this.state = 449;
                    this.whereClause();
                    }
                    break;
                case jsoniqParser.Kgroup:
                    {
                    this.state = 450;
                    this.groupByClause();
                    }
                    break;
                case jsoniqParser.Korder:
                case jsoniqParser.Kstable:
                    {
                    this.state = 451;
                    this.orderByClause();
                    }
                    break;
                case jsoniqParser.Kcount:
                    {
                    this.state = 452;
                    this.countClause();
                    }
                    break;
                default:
                    throw new antlr.NoViableAltException(this);
                }
                }
                this.state = 457;
                this.errorHandler.sync(this);
                _la = this.tokenStream.LA(1);
            }
            this.state = 458;
            this.match(jsoniqParser.Kreturn);
            this.state = 459;
            localContext._returnStmt = this.statement();
            }
        }
        catch (re) {
            if (re instanceof antlr.RecognitionException) {
                this.errorHandler.reportError(this, re);
                this.errorHandler.recover(this, re);
            } else {
                throw re;
            }
        }
        finally {
            this.exitRule();
        }
        return localContext;
    }
    public ifStatement(): IfStatementContext {
        let localContext = new IfStatementContext(this.context, this.state);
        this.enterRule(localContext, 34, jsoniqParser.RULE_ifStatement);
        try {
            this.enterOuterAlt(localContext, 1);
            {
            this.state = 461;
            this.match(jsoniqParser.Kif);
            this.state = 462;
            this.match(jsoniqParser.Klparen);
            this.state = 463;
            localContext._test_expr = this.expr();
            this.state = 464;
            this.match(jsoniqParser.Krparen);
            this.state = 465;
            this.match(jsoniqParser.Kthen);
            this.state = 466;
            localContext._branch = this.statement();
            this.state = 467;
            this.match(jsoniqParser.Kelse);
            this.state = 468;
            localContext._else_branch = this.statement();
            }
        }
        catch (re) {
            if (re instanceof antlr.RecognitionException) {
                this.errorHandler.reportError(this, re);
                this.errorHandler.recover(this, re);
            } else {
                throw re;
            }
        }
        finally {
            this.exitRule();
        }
        return localContext;
    }
    public switchStatement(): SwitchStatementContext {
        let localContext = new SwitchStatementContext(this.context, this.state);
        this.enterRule(localContext, 36, jsoniqParser.RULE_switchStatement);
        let _la: number;
        try {
            this.enterOuterAlt(localContext, 1);
            {
            this.state = 470;
            this.match(jsoniqParser.Kswitch);
            this.state = 471;
            this.match(jsoniqParser.Klparen);
            this.state = 472;
            localContext._condExpr = this.expr();
            this.state = 473;
            this.match(jsoniqParser.Krparen);
            this.state = 475;
            this.errorHandler.sync(this);
            _la = this.tokenStream.LA(1);
            do {
                {
                {
                this.state = 474;
                localContext._switchCaseStatement = this.switchCaseStatement();
                localContext._cases.push(localContext._switchCaseStatement!);
                }
                }
                this.state = 477;
                this.errorHandler.sync(this);
                _la = this.tokenStream.LA(1);
            } while (_la === 84);
            this.state = 479;
            this.match(jsoniqParser.Kdefault);
            this.state = 480;
            this.match(jsoniqParser.Kreturn);
            this.state = 481;
            localContext._def = this.statement();
            }
        }
        catch (re) {
            if (re instanceof antlr.RecognitionException) {
                this.errorHandler.reportError(this, re);
                this.errorHandler.recover(this, re);
            } else {
                throw re;
            }
        }
        finally {
            this.exitRule();
        }
        return localContext;
    }
    public switchCaseStatement(): SwitchCaseStatementContext {
        let localContext = new SwitchCaseStatementContext(this.context, this.state);
        this.enterRule(localContext, 38, jsoniqParser.RULE_switchCaseStatement);
        let _la: number;
        try {
            this.enterOuterAlt(localContext, 1);
            {
            this.state = 485;
            this.errorHandler.sync(this);
            _la = this.tokenStream.LA(1);
            do {
                {
                {
                this.state = 483;
                this.match(jsoniqParser.Kcase);
                this.state = 484;
                localContext._exprSingle = this.exprSingle();
                localContext._cond.push(localContext._exprSingle!);
                }
                }
                this.state = 487;
                this.errorHandler.sync(this);
                _la = this.tokenStream.LA(1);
            } while (_la === 84);
            this.state = 489;
            this.match(jsoniqParser.Kreturn);
            this.state = 490;
            localContext._ret = this.statement();
            }
        }
        catch (re) {
            if (re instanceof antlr.RecognitionException) {
                this.errorHandler.reportError(this, re);
                this.errorHandler.recover(this, re);
            } else {
                throw re;
            }
        }
        finally {
            this.exitRule();
        }
        return localContext;
    }
    public tryCatchStatement(): TryCatchStatementContext {
        let localContext = new TryCatchStatementContext(this.context, this.state);
        this.enterRule(localContext, 40, jsoniqParser.RULE_tryCatchStatement);
        try {
            let alternative: number;
            this.enterOuterAlt(localContext, 1);
            {
            this.state = 492;
            this.match(jsoniqParser.Ktry);
            this.state = 493;
            localContext._try_block = this.blockStatement();
            this.state = 495;
            this.errorHandler.sync(this);
            alternative = 1;
            do {
                switch (alternative) {
                case 1:
                    {
                    {
                    this.state = 494;
                    localContext._catchCaseStatement = this.catchCaseStatement();
                    localContext._catches.push(localContext._catchCaseStatement!);
                    }
                    }
                    break;
                default:
                    throw new antlr.NoViableAltException(this);
                }
                this.state = 497;
                this.errorHandler.sync(this);
                alternative = this.interpreter.adaptivePredict(this.tokenStream, 13, this.context);
            } while (alternative !== 2 && alternative !== antlr.ATN.INVALID_ALT_NUMBER);
            }
        }
        catch (re) {
            if (re instanceof antlr.RecognitionException) {
                this.errorHandler.reportError(this, re);
                this.errorHandler.recover(this, re);
            } else {
                throw re;
            }
        }
        finally {
            this.exitRule();
        }
        return localContext;
    }
    public catchCaseStatement(): CatchCaseStatementContext {
        let localContext = new CatchCaseStatementContext(this.context, this.state);
        this.enterRule(localContext, 42, jsoniqParser.RULE_catchCaseStatement);
        let _la: number;
        try {
            this.enterOuterAlt(localContext, 1);
            {
            this.state = 499;
            this.match(jsoniqParser.Kcatch);
            this.state = 502;
            this.errorHandler.sync(this);
            switch (this.tokenStream.LA(1)) {
            case jsoniqParser.Kasterisk:
                {
                this.state = 500;
                localContext._s10 = this.match(jsoniqParser.Kasterisk);
                localContext._jokers.push(localContext._s10!);
                }
                break;
            case jsoniqParser.Kfor:
            case jsoniqParser.Klet:
            case jsoniqParser.Kwhere:
            case jsoniqParser.Kgroup:
            case jsoniqParser.Kby:
            case jsoniqParser.Korder:
            case jsoniqParser.Kreturn:
            case jsoniqParser.Kif:
            case jsoniqParser.Kin:
            case jsoniqParser.Kas:
            case jsoniqParser.Kat:
            case jsoniqParser.Kallowing:
            case jsoniqParser.Kempty:
            case jsoniqParser.Kcount:
            case jsoniqParser.Kstable:
            case jsoniqParser.Kascending:
            case jsoniqParser.Kdescending:
            case jsoniqParser.Ksome:
            case jsoniqParser.Kevery:
            case jsoniqParser.Ksatisfies:
            case jsoniqParser.Kcollation:
            case jsoniqParser.Kgreatest:
            case jsoniqParser.Kleast:
            case jsoniqParser.Kswitch:
            case jsoniqParser.Kcase:
            case jsoniqParser.Ktry:
            case jsoniqParser.Kcatch:
            case jsoniqParser.Kdefault:
            case jsoniqParser.Kthen:
            case jsoniqParser.Kelse:
            case jsoniqParser.Ktypeswitch:
            case jsoniqParser.Kor:
            case jsoniqParser.Kand:
            case jsoniqParser.Knot:
            case jsoniqParser.Kto:
            case jsoniqParser.Kinstance:
            case jsoniqParser.Kof:
            case jsoniqParser.Kstatically:
            case jsoniqParser.Kis:
            case jsoniqParser.Ktreat:
            case jsoniqParser.Kcast:
            case jsoniqParser.Kcastable:
            case jsoniqParser.Kversion:
            case jsoniqParser.Kjsoniq:
            case jsoniqParser.Kunordered:
            case jsoniqParser.Ktrue:
            case jsoniqParser.Kfalse:
            case jsoniqParser.Ktype:
            case jsoniqParser.Kvalidate:
            case jsoniqParser.Kannotate:
            case jsoniqParser.Kdeclare:
            case jsoniqParser.Kcontext:
            case jsoniqParser.Kitem:
            case jsoniqParser.Kvariable:
            case jsoniqParser.Kinsert:
            case jsoniqParser.Kdelete:
            case jsoniqParser.Krename:
            case jsoniqParser.Kreplace:
            case jsoniqParser.Kcopy:
            case jsoniqParser.Kmodify:
            case jsoniqParser.Kappend:
            case jsoniqParser.Kinto:
            case jsoniqParser.Kvalue:
            case jsoniqParser.Kwith:
            case jsoniqParser.Kposition:
            case jsoniqParser.Kjson:
            case jsoniqParser.Kupdating:
            case jsoniqParser.Kcreate:
            case jsoniqParser.Kcollection:
            case jsoniqParser.Ktable:
            case jsoniqParser.Kdeltafile:
            case jsoniqParser.Kicebergtable:
            case jsoniqParser.Ktruncate:
            case jsoniqParser.Kfirst:
            case jsoniqParser.Klast:
            case jsoniqParser.Kfrom:
            case jsoniqParser.Kedit:
            case jsoniqParser.Kafter:
            case jsoniqParser.Kbefore:
            case jsoniqParser.Kimport:
            case jsoniqParser.Kschema:
            case jsoniqParser.Knamespace:
            case jsoniqParser.Kelement:
            case jsoniqParser.Kslash:
            case jsoniqParser.Kdslash:
            case jsoniqParser.Kat_symbol:
            case jsoniqParser.Kchild:
            case jsoniqParser.Kdescendant:
            case jsoniqParser.Kattribute:
            case jsoniqParser.Kself:
            case jsoniqParser.Kdescendant_or_self:
            case jsoniqParser.Kfollowing_sibling:
            case jsoniqParser.Kfollowing:
            case jsoniqParser.Kparent:
            case jsoniqParser.Kancestor:
            case jsoniqParser.Kpreceding_sibling:
            case jsoniqParser.Kpreceding:
            case jsoniqParser.Kancestor_or_self:
            case jsoniqParser.Knode:
            case jsoniqParser.Kbinary:
            case jsoniqParser.Kdocument:
            case jsoniqParser.Kdocument_node:
            case jsoniqParser.Ktext:
            case jsoniqParser.Kpi:
            case jsoniqParser.Knamespace_node:
            case jsoniqParser.Kschema_attribute:
            case jsoniqParser.Kschema_element:
            case jsoniqParser.Karray_node:
            case jsoniqParser.Kboolean_node:
            case jsoniqParser.Knull_node:
            case jsoniqParser.Knumber_node:
            case jsoniqParser.Kobject_node:
            case jsoniqParser.Kcomment:
            case jsoniqParser.Kbreak:
            case jsoniqParser.Kloop:
            case jsoniqParser.Kcontinue:
            case jsoniqParser.Kexit:
            case jsoniqParser.Kreturning:
            case jsoniqParser.Kwhile:
            case jsoniqParser.NullLiteral:
            case jsoniqParser.NCName:
                {
                this.state = 501;
                localContext._qname = this.qname();
                localContext._errors.push(localContext._qname!);
                }
                break;
            default:
                throw new antlr.NoViableAltException(this);
            }
            this.state = 511;
            this.errorHandler.sync(this);
            _la = this.tokenStream.LA(1);
            while (_la === 11) {
                {
                {
                this.state = 504;
                this.match(jsoniqParser.Kpipe);
                this.state = 507;
                this.errorHandler.sync(this);
                switch (this.tokenStream.LA(1)) {
                case jsoniqParser.Kasterisk:
                    {
                    this.state = 505;
                    localContext._s10 = this.match(jsoniqParser.Kasterisk);
                    localContext._jokers.push(localContext._s10!);
                    }
                    break;
                case jsoniqParser.Kfor:
                case jsoniqParser.Klet:
                case jsoniqParser.Kwhere:
                case jsoniqParser.Kgroup:
                case jsoniqParser.Kby:
                case jsoniqParser.Korder:
                case jsoniqParser.Kreturn:
                case jsoniqParser.Kif:
                case jsoniqParser.Kin:
                case jsoniqParser.Kas:
                case jsoniqParser.Kat:
                case jsoniqParser.Kallowing:
                case jsoniqParser.Kempty:
                case jsoniqParser.Kcount:
                case jsoniqParser.Kstable:
                case jsoniqParser.Kascending:
                case jsoniqParser.Kdescending:
                case jsoniqParser.Ksome:
                case jsoniqParser.Kevery:
                case jsoniqParser.Ksatisfies:
                case jsoniqParser.Kcollation:
                case jsoniqParser.Kgreatest:
                case jsoniqParser.Kleast:
                case jsoniqParser.Kswitch:
                case jsoniqParser.Kcase:
                case jsoniqParser.Ktry:
                case jsoniqParser.Kcatch:
                case jsoniqParser.Kdefault:
                case jsoniqParser.Kthen:
                case jsoniqParser.Kelse:
                case jsoniqParser.Ktypeswitch:
                case jsoniqParser.Kor:
                case jsoniqParser.Kand:
                case jsoniqParser.Knot:
                case jsoniqParser.Kto:
                case jsoniqParser.Kinstance:
                case jsoniqParser.Kof:
                case jsoniqParser.Kstatically:
                case jsoniqParser.Kis:
                case jsoniqParser.Ktreat:
                case jsoniqParser.Kcast:
                case jsoniqParser.Kcastable:
                case jsoniqParser.Kversion:
                case jsoniqParser.Kjsoniq:
                case jsoniqParser.Kunordered:
                case jsoniqParser.Ktrue:
                case jsoniqParser.Kfalse:
                case jsoniqParser.Ktype:
                case jsoniqParser.Kvalidate:
                case jsoniqParser.Kannotate:
                case jsoniqParser.Kdeclare:
                case jsoniqParser.Kcontext:
                case jsoniqParser.Kitem:
                case jsoniqParser.Kvariable:
                case jsoniqParser.Kinsert:
                case jsoniqParser.Kdelete:
                case jsoniqParser.Krename:
                case jsoniqParser.Kreplace:
                case jsoniqParser.Kcopy:
                case jsoniqParser.Kmodify:
                case jsoniqParser.Kappend:
                case jsoniqParser.Kinto:
                case jsoniqParser.Kvalue:
                case jsoniqParser.Kwith:
                case jsoniqParser.Kposition:
                case jsoniqParser.Kjson:
                case jsoniqParser.Kupdating:
                case jsoniqParser.Kcreate:
                case jsoniqParser.Kcollection:
                case jsoniqParser.Ktable:
                case jsoniqParser.Kdeltafile:
                case jsoniqParser.Kicebergtable:
                case jsoniqParser.Ktruncate:
                case jsoniqParser.Kfirst:
                case jsoniqParser.Klast:
                case jsoniqParser.Kfrom:
                case jsoniqParser.Kedit:
                case jsoniqParser.Kafter:
                case jsoniqParser.Kbefore:
                case jsoniqParser.Kimport:
                case jsoniqParser.Kschema:
                case jsoniqParser.Knamespace:
                case jsoniqParser.Kelement:
                case jsoniqParser.Kslash:
                case jsoniqParser.Kdslash:
                case jsoniqParser.Kat_symbol:
                case jsoniqParser.Kchild:
                case jsoniqParser.Kdescendant:
                case jsoniqParser.Kattribute:
                case jsoniqParser.Kself:
                case jsoniqParser.Kdescendant_or_self:
                case jsoniqParser.Kfollowing_sibling:
                case jsoniqParser.Kfollowing:
                case jsoniqParser.Kparent:
                case jsoniqParser.Kancestor:
                case jsoniqParser.Kpreceding_sibling:
                case jsoniqParser.Kpreceding:
                case jsoniqParser.Kancestor_or_self:
                case jsoniqParser.Knode:
                case jsoniqParser.Kbinary:
                case jsoniqParser.Kdocument:
                case jsoniqParser.Kdocument_node:
                case jsoniqParser.Ktext:
                case jsoniqParser.Kpi:
                case jsoniqParser.Knamespace_node:
                case jsoniqParser.Kschema_attribute:
                case jsoniqParser.Kschema_element:
                case jsoniqParser.Karray_node:
                case jsoniqParser.Kboolean_node:
                case jsoniqParser.Knull_node:
                case jsoniqParser.Knumber_node:
                case jsoniqParser.Kobject_node:
                case jsoniqParser.Kcomment:
                case jsoniqParser.Kbreak:
                case jsoniqParser.Kloop:
                case jsoniqParser.Kcontinue:
                case jsoniqParser.Kexit:
                case jsoniqParser.Kreturning:
                case jsoniqParser.Kwhile:
                case jsoniqParser.NullLiteral:
                case jsoniqParser.NCName:
                    {
                    this.state = 506;
                    localContext._qname = this.qname();
                    localContext._errors.push(localContext._qname!);
                    }
                    break;
                default:
                    throw new antlr.NoViableAltException(this);
                }
                }
                }
                this.state = 513;
                this.errorHandler.sync(this);
                _la = this.tokenStream.LA(1);
            }
            this.state = 514;
            localContext._catch_block = this.blockStatement();
            }
        }
        catch (re) {
            if (re instanceof antlr.RecognitionException) {
                this.errorHandler.reportError(this, re);
                this.errorHandler.recover(this, re);
            } else {
                throw re;
            }
        }
        finally {
            this.exitRule();
        }
        return localContext;
    }
    public typeSwitchStatement(): TypeSwitchStatementContext {
        let localContext = new TypeSwitchStatementContext(this.context, this.state);
        this.enterRule(localContext, 44, jsoniqParser.RULE_typeSwitchStatement);
        let _la: number;
        try {
            this.enterOuterAlt(localContext, 1);
            {
            this.state = 516;
            this.match(jsoniqParser.Ktypeswitch);
            this.state = 517;
            this.match(jsoniqParser.Klparen);
            this.state = 518;
            localContext._cond = this.expr();
            this.state = 519;
            this.match(jsoniqParser.Krparen);
            this.state = 521;
            this.errorHandler.sync(this);
            _la = this.tokenStream.LA(1);
            do {
                {
                {
                this.state = 520;
                localContext._caseStatement = this.caseStatement();
                localContext._cases.push(localContext._caseStatement!);
                }
                }
                this.state = 523;
                this.errorHandler.sync(this);
                _la = this.tokenStream.LA(1);
            } while (_la === 84);
            this.state = 525;
            this.match(jsoniqParser.Kdefault);
            this.state = 527;
            this.errorHandler.sync(this);
            _la = this.tokenStream.LA(1);
            if (_la === 4) {
                {
                this.state = 526;
                localContext._var_ref = this.varRef();
                }
            }

            this.state = 529;
            this.match(jsoniqParser.Kreturn);
            this.state = 530;
            localContext._def = this.statement();
            }
        }
        catch (re) {
            if (re instanceof antlr.RecognitionException) {
                this.errorHandler.reportError(this, re);
                this.errorHandler.recover(this, re);
            } else {
                throw re;
            }
        }
        finally {
            this.exitRule();
        }
        return localContext;
    }
    public caseStatement(): CaseStatementContext {
        let localContext = new CaseStatementContext(this.context, this.state);
        this.enterRule(localContext, 46, jsoniqParser.RULE_caseStatement);
        let _la: number;
        try {
            this.enterOuterAlt(localContext, 1);
            {
            this.state = 532;
            this.match(jsoniqParser.Kcase);
            this.state = 536;
            this.errorHandler.sync(this);
            _la = this.tokenStream.LA(1);
            if (_la === 4) {
                {
                this.state = 533;
                localContext._var_ref = this.varRef();
                this.state = 534;
                this.match(jsoniqParser.Kas);
                }
            }

            this.state = 538;
            localContext._sequenceType = this.sequenceType();
            localContext._union.push(localContext._sequenceType!);
            this.state = 543;
            this.errorHandler.sync(this);
            _la = this.tokenStream.LA(1);
            while (_la === 11) {
                {
                {
                this.state = 539;
                this.match(jsoniqParser.Kpipe);
                this.state = 540;
                localContext._sequenceType = this.sequenceType();
                localContext._union.push(localContext._sequenceType!);
                }
                }
                this.state = 545;
                this.errorHandler.sync(this);
                _la = this.tokenStream.LA(1);
            }
            this.state = 546;
            this.match(jsoniqParser.Kreturn);
            this.state = 547;
            localContext._ret = this.statement();
            }
        }
        catch (re) {
            if (re instanceof antlr.RecognitionException) {
                this.errorHandler.reportError(this, re);
                this.errorHandler.recover(this, re);
            } else {
                throw re;
            }
        }
        finally {
            this.exitRule();
        }
        return localContext;
    }
    public annotation(): AnnotationContext {
        let localContext = new AnnotationContext(this.context, this.state);
        this.enterRule(localContext, 48, jsoniqParser.RULE_annotation);
        let _la: number;
        try {
            this.enterOuterAlt(localContext, 1);
            {
            this.state = 564;
            this.errorHandler.sync(this);
            switch (this.tokenStream.LA(1)) {
            case jsoniqParser.Kannotation:
                {
                this.state = 549;
                this.match(jsoniqParser.Kannotation);
                this.state = 550;
                localContext._name = this.qname();
                this.state = 561;
                this.errorHandler.sync(this);
                _la = this.tokenStream.LA(1);
                if (_la === 8) {
                    {
                    this.state = 551;
                    this.match(jsoniqParser.Klparen);
                    this.state = 552;
                    this.match(jsoniqParser.Literal);
                    this.state = 557;
                    this.errorHandler.sync(this);
                    _la = this.tokenStream.LA(1);
                    while (_la === 13) {
                        {
                        {
                        this.state = 553;
                        this.match(jsoniqParser.Kcomma);
                        this.state = 554;
                        this.match(jsoniqParser.Literal);
                        }
                        }
                        this.state = 559;
                        this.errorHandler.sync(this);
                        _la = this.tokenStream.LA(1);
                    }
                    this.state = 560;
                    this.match(jsoniqParser.Krparen);
                    }
                }

                }
                break;
            case jsoniqParser.Kupdating:
                {
                this.state = 563;
                localContext._updating = this.match(jsoniqParser.Kupdating);
                }
                break;
            default:
                throw new antlr.NoViableAltException(this);
            }
            }
        }
        catch (re) {
            if (re instanceof antlr.RecognitionException) {
                this.errorHandler.reportError(this, re);
                this.errorHandler.recover(this, re);
            } else {
                throw re;
            }
        }
        finally {
            this.exitRule();
        }
        return localContext;
    }
    public annotations(): AnnotationsContext {
        let localContext = new AnnotationsContext(this.context, this.state);
        this.enterRule(localContext, 50, jsoniqParser.RULE_annotations);
        let _la: number;
        try {
            this.enterOuterAlt(localContext, 1);
            {
            this.state = 569;
            this.errorHandler.sync(this);
            _la = this.tokenStream.LA(1);
            while (_la === 12 || _la === 126) {
                {
                {
                this.state = 566;
                this.annotation();
                }
                }
                this.state = 571;
                this.errorHandler.sync(this);
                _la = this.tokenStream.LA(1);
            }
            }
        }
        catch (re) {
            if (re instanceof antlr.RecognitionException) {
                this.errorHandler.reportError(this, re);
                this.errorHandler.recover(this, re);
            } else {
                throw re;
            }
        }
        finally {
            this.exitRule();
        }
        return localContext;
    }
    public varDeclStatement(): VarDeclStatementContext {
        let localContext = new VarDeclStatementContext(this.context, this.state);
        this.enterRule(localContext, 52, jsoniqParser.RULE_varDeclStatement);
        let _la: number;
        try {
            this.enterOuterAlt(localContext, 1);
            {
            this.state = 572;
            this.annotations();
            this.state = 573;
            this.match(jsoniqParser.Kvariable);
            this.state = 574;
            this.varDeclForStatement();
            this.state = 579;
            this.errorHandler.sync(this);
            _la = this.tokenStream.LA(1);
            while (_la === 13) {
                {
                {
                this.state = 575;
                this.match(jsoniqParser.Kcomma);
                this.state = 576;
                this.varDeclForStatement();
                }
                }
                this.state = 581;
                this.errorHandler.sync(this);
                _la = this.tokenStream.LA(1);
            }
            this.state = 582;
            this.match(jsoniqParser.Ksemicolon);
            }
        }
        catch (re) {
            if (re instanceof antlr.RecognitionException) {
                this.errorHandler.reportError(this, re);
                this.errorHandler.recover(this, re);
            } else {
                throw re;
            }
        }
        finally {
            this.exitRule();
        }
        return localContext;
    }
    public varDeclForStatement(): VarDeclForStatementContext {
        let localContext = new VarDeclForStatementContext(this.context, this.state);
        this.enterRule(localContext, 54, jsoniqParser.RULE_varDeclForStatement);
        let _la: number;
        try {
            this.enterOuterAlt(localContext, 1);
            {
            this.state = 584;
            localContext._var_ref = this.varRef();
            this.state = 587;
            this.errorHandler.sync(this);
            _la = this.tokenStream.LA(1);
            if (_la === 69) {
                {
                this.state = 585;
                this.match(jsoniqParser.Kas);
                this.state = 586;
                this.sequenceType();
                }
            }

            this.state = 591;
            this.errorHandler.sync(this);
            _la = this.tokenStream.LA(1);
            if (_la === 5) {
                {
                this.state = 589;
                this.match(jsoniqParser.Kassign);
                this.state = 590;
                localContext._exprSingle = this.exprSingle();
                localContext._expr_vals.push(localContext._exprSingle!);
                }
            }

            }
        }
        catch (re) {
            if (re instanceof antlr.RecognitionException) {
                this.errorHandler.reportError(this, re);
                this.errorHandler.recover(this, re);
            } else {
                throw re;
            }
        }
        finally {
            this.exitRule();
        }
        return localContext;
    }
    public whileStatement(): WhileStatementContext {
        let localContext = new WhileStatementContext(this.context, this.state);
        this.enterRule(localContext, 56, jsoniqParser.RULE_whileStatement);
        try {
            this.enterOuterAlt(localContext, 1);
            {
            this.state = 593;
            this.match(jsoniqParser.Kwhile);
            this.state = 594;
            this.match(jsoniqParser.Klparen);
            this.state = 595;
            localContext._test_expr = this.expr();
            this.state = 596;
            this.match(jsoniqParser.Krparen);
            this.state = 597;
            localContext._stmt = this.statement();
            }
        }
        catch (re) {
            if (re instanceof antlr.RecognitionException) {
                this.errorHandler.reportError(this, re);
                this.errorHandler.recover(this, re);
            } else {
                throw re;
            }
        }
        finally {
            this.exitRule();
        }
        return localContext;
    }
    public setter(): SetterContext {
        let localContext = new SetterContext(this.context, this.state);
        this.enterRule(localContext, 58, jsoniqParser.RULE_setter);
        try {
            this.state = 604;
            this.errorHandler.sync(this);
            switch (this.interpreter.adaptivePredict(this.tokenStream, 28, this.context) ) {
            case 1:
                this.enterOuterAlt(localContext, 1);
                {
                this.state = 599;
                this.defaultCollationDecl();
                }
                break;
            case 2:
                this.enterOuterAlt(localContext, 2);
                {
                this.state = 600;
                this.baseURIDecl();
                }
                break;
            case 3:
                this.enterOuterAlt(localContext, 3);
                {
                this.state = 601;
                this.orderingModeDecl();
                }
                break;
            case 4:
                this.enterOuterAlt(localContext, 4);
                {
                this.state = 602;
                this.emptyOrderDecl();
                }
                break;
            case 5:
                this.enterOuterAlt(localContext, 5);
                {
                this.state = 603;
                this.decimalFormatDecl();
                }
                break;
            }
        }
        catch (re) {
            if (re instanceof antlr.RecognitionException) {
                this.errorHandler.reportError(this, re);
                this.errorHandler.recover(this, re);
            } else {
                throw re;
            }
        }
        finally {
            this.exitRule();
        }
        return localContext;
    }
    public namespaceDecl(): NamespaceDeclContext {
        let localContext = new NamespaceDeclContext(this.context, this.state);
        this.enterRule(localContext, 60, jsoniqParser.RULE_namespaceDecl);
        try {
            this.enterOuterAlt(localContext, 1);
            {
            this.state = 606;
            this.match(jsoniqParser.Kdeclare);
            this.state = 607;
            this.match(jsoniqParser.Knamespace);
            this.state = 608;
            this.match(jsoniqParser.NCName);
            this.state = 609;
            this.match(jsoniqParser.Kequal);
            this.state = 610;
            this.uriLiteral();
            }
        }
        catch (re) {
            if (re instanceof antlr.RecognitionException) {
                this.errorHandler.reportError(this, re);
                this.errorHandler.recover(this, re);
            } else {
                throw re;
            }
        }
        finally {
            this.exitRule();
        }
        return localContext;
    }
    public annotatedDecl(): AnnotatedDeclContext {
        let localContext = new AnnotatedDeclContext(this.context, this.state);
        this.enterRule(localContext, 62, jsoniqParser.RULE_annotatedDecl);
        try {
            this.state = 616;
            this.errorHandler.sync(this);
            switch (this.interpreter.adaptivePredict(this.tokenStream, 29, this.context) ) {
            case 1:
                this.enterOuterAlt(localContext, 1);
                {
                this.state = 612;
                this.functionDecl();
                }
                break;
            case 2:
                this.enterOuterAlt(localContext, 2);
                {
                this.state = 613;
                this.varDecl();
                }
                break;
            case 3:
                this.enterOuterAlt(localContext, 3);
                {
                this.state = 614;
                this.typeDecl();
                }
                break;
            case 4:
                this.enterOuterAlt(localContext, 4);
                {
                this.state = 615;
                this.contextItemDecl();
                }
                break;
            }
        }
        catch (re) {
            if (re instanceof antlr.RecognitionException) {
                this.errorHandler.reportError(this, re);
                this.errorHandler.recover(this, re);
            } else {
                throw re;
            }
        }
        finally {
            this.exitRule();
        }
        return localContext;
    }
    public defaultCollationDecl(): DefaultCollationDeclContext {
        let localContext = new DefaultCollationDeclContext(this.context, this.state);
        this.enterRule(localContext, 64, jsoniqParser.RULE_defaultCollationDecl);
        try {
            this.enterOuterAlt(localContext, 1);
            {
            this.state = 618;
            this.match(jsoniqParser.Kdeclare);
            this.state = 619;
            this.match(jsoniqParser.Kdefault);
            this.state = 620;
            this.match(jsoniqParser.Kcollation);
            this.state = 621;
            this.uriLiteral();
            }
        }
        catch (re) {
            if (re instanceof antlr.RecognitionException) {
                this.errorHandler.reportError(this, re);
                this.errorHandler.recover(this, re);
            } else {
                throw re;
            }
        }
        finally {
            this.exitRule();
        }
        return localContext;
    }
    public baseURIDecl(): BaseURIDeclContext {
        let localContext = new BaseURIDeclContext(this.context, this.state);
        this.enterRule(localContext, 66, jsoniqParser.RULE_baseURIDecl);
        try {
            this.enterOuterAlt(localContext, 1);
            {
            this.state = 623;
            this.match(jsoniqParser.Kdeclare);
            this.state = 624;
            this.match(jsoniqParser.Kbase_uri);
            this.state = 625;
            this.uriLiteral();
            }
        }
        catch (re) {
            if (re instanceof antlr.RecognitionException) {
                this.errorHandler.reportError(this, re);
                this.errorHandler.recover(this, re);
            } else {
                throw re;
            }
        }
        finally {
            this.exitRule();
        }
        return localContext;
    }
    public orderingModeDecl(): OrderingModeDeclContext {
        let localContext = new OrderingModeDeclContext(this.context, this.state);
        this.enterRule(localContext, 68, jsoniqParser.RULE_orderingModeDecl);
        let _la: number;
        try {
            this.enterOuterAlt(localContext, 1);
            {
            this.state = 627;
            this.match(jsoniqParser.Kdeclare);
            this.state = 628;
            this.match(jsoniqParser.Kordering);
            this.state = 629;
            _la = this.tokenStream.LA(1);
            if(!(_la === 16 || _la === 104)) {
            this.errorHandler.recoverInline(this);
            }
            else {
                this.errorHandler.reportMatch(this);
                this.consume();
            }
            }
        }
        catch (re) {
            if (re instanceof antlr.RecognitionException) {
                this.errorHandler.reportError(this, re);
                this.errorHandler.recover(this, re);
            } else {
                throw re;
            }
        }
        finally {
            this.exitRule();
        }
        return localContext;
    }
    public emptyOrderDecl(): EmptyOrderDeclContext {
        let localContext = new EmptyOrderDeclContext(this.context, this.state);
        this.enterRule(localContext, 70, jsoniqParser.RULE_emptyOrderDecl);
        let _la: number;
        try {
            this.enterOuterAlt(localContext, 1);
            {
            this.state = 631;
            this.match(jsoniqParser.Kdeclare);
            this.state = 632;
            this.match(jsoniqParser.Kdefault);
            this.state = 633;
            this.match(jsoniqParser.Korder);
            this.state = 634;
            this.match(jsoniqParser.Kempty);
            {
            this.state = 635;
            localContext._emptySequenceOrder = this.tokenStream.LT(1);
            _la = this.tokenStream.LA(1);
            if(!(_la === 81 || _la === 82)) {
                localContext._emptySequenceOrder = this.errorHandler.recoverInline(this);
            }
            else {
                this.errorHandler.reportMatch(this);
                this.consume();
            }
            }
            }
        }
        catch (re) {
            if (re instanceof antlr.RecognitionException) {
                this.errorHandler.reportError(this, re);
                this.errorHandler.recover(this, re);
            } else {
                throw re;
            }
        }
        finally {
            this.exitRule();
        }
        return localContext;
    }
    public decimalFormatDecl(): DecimalFormatDeclContext {
        let localContext = new DecimalFormatDeclContext(this.context, this.state);
        this.enterRule(localContext, 72, jsoniqParser.RULE_decimalFormatDecl);
        let _la: number;
        try {
            this.enterOuterAlt(localContext, 1);
            {
            this.state = 637;
            this.match(jsoniqParser.Kdeclare);
            this.state = 642;
            this.errorHandler.sync(this);
            switch (this.tokenStream.LA(1)) {
            case jsoniqParser.Kdecimal_format:
                {
                {
                this.state = 638;
                this.match(jsoniqParser.Kdecimal_format);
                this.state = 639;
                this.qname();
                }
                }
                break;
            case jsoniqParser.Kdefault:
                {
                {
                this.state = 640;
                this.match(jsoniqParser.Kdefault);
                this.state = 641;
                this.match(jsoniqParser.Kdecimal_format);
                }
                }
                break;
            default:
                throw new antlr.NoViableAltException(this);
            }
            this.state = 650;
            this.errorHandler.sync(this);
            _la = this.tokenStream.LA(1);
            while ((((_la) & ~0x1F) === 0 && ((1 << _la) & 536346624) !== 0)) {
                {
                {
                this.state = 644;
                this.dfPropertyName();
                this.state = 645;
                this.match(jsoniqParser.Kequal);
                this.state = 646;
                this.stringLiteral();
                }
                }
                this.state = 652;
                this.errorHandler.sync(this);
                _la = this.tokenStream.LA(1);
            }
            }
        }
        catch (re) {
            if (re instanceof antlr.RecognitionException) {
                this.errorHandler.reportError(this, re);
                this.errorHandler.recover(this, re);
            } else {
                throw re;
            }
        }
        finally {
            this.exitRule();
        }
        return localContext;
    }
    public qname(): QnameContext {
        let localContext = new QnameContext(this.context, this.state);
        this.enterRule(localContext, 74, jsoniqParser.RULE_qname);
        try {
            this.enterOuterAlt(localContext, 1);
            {
            this.state = 658;
            this.errorHandler.sync(this);
            switch (this.interpreter.adaptivePredict(this.tokenStream, 33, this.context) ) {
            case 1:
                {
                this.state = 655;
                this.errorHandler.sync(this);
                switch (this.tokenStream.LA(1)) {
                case jsoniqParser.NCName:
                    {
                    this.state = 653;
                    localContext._ns = this.match(jsoniqParser.NCName);
                    }
                    break;
                case jsoniqParser.Kfor:
                case jsoniqParser.Klet:
                case jsoniqParser.Kwhere:
                case jsoniqParser.Kgroup:
                case jsoniqParser.Kby:
                case jsoniqParser.Korder:
                case jsoniqParser.Kreturn:
                case jsoniqParser.Kif:
                case jsoniqParser.Kin:
                case jsoniqParser.Kas:
                case jsoniqParser.Kat:
                case jsoniqParser.Kallowing:
                case jsoniqParser.Kempty:
                case jsoniqParser.Kcount:
                case jsoniqParser.Kstable:
                case jsoniqParser.Kascending:
                case jsoniqParser.Kdescending:
                case jsoniqParser.Ksome:
                case jsoniqParser.Kevery:
                case jsoniqParser.Ksatisfies:
                case jsoniqParser.Kcollation:
                case jsoniqParser.Kgreatest:
                case jsoniqParser.Kleast:
                case jsoniqParser.Kswitch:
                case jsoniqParser.Kcase:
                case jsoniqParser.Ktry:
                case jsoniqParser.Kcatch:
                case jsoniqParser.Kdefault:
                case jsoniqParser.Kthen:
                case jsoniqParser.Kelse:
                case jsoniqParser.Ktypeswitch:
                case jsoniqParser.Kor:
                case jsoniqParser.Kand:
                case jsoniqParser.Knot:
                case jsoniqParser.Kto:
                case jsoniqParser.Kinstance:
                case jsoniqParser.Kof:
                case jsoniqParser.Kstatically:
                case jsoniqParser.Kis:
                case jsoniqParser.Ktreat:
                case jsoniqParser.Kcast:
                case jsoniqParser.Kcastable:
                case jsoniqParser.Kversion:
                case jsoniqParser.Kjsoniq:
                case jsoniqParser.Kunordered:
                case jsoniqParser.Ktrue:
                case jsoniqParser.Kfalse:
                case jsoniqParser.Ktype:
                case jsoniqParser.Kvalidate:
                case jsoniqParser.Kannotate:
                case jsoniqParser.Kdeclare:
                case jsoniqParser.Kcontext:
                case jsoniqParser.Kitem:
                case jsoniqParser.Kvariable:
                case jsoniqParser.Kinsert:
                case jsoniqParser.Kdelete:
                case jsoniqParser.Krename:
                case jsoniqParser.Kreplace:
                case jsoniqParser.Kcopy:
                case jsoniqParser.Kmodify:
                case jsoniqParser.Kappend:
                case jsoniqParser.Kinto:
                case jsoniqParser.Kvalue:
                case jsoniqParser.Kwith:
                case jsoniqParser.Kposition:
                case jsoniqParser.Kjson:
                case jsoniqParser.Kupdating:
                case jsoniqParser.Kcreate:
                case jsoniqParser.Kcollection:
                case jsoniqParser.Ktable:
                case jsoniqParser.Kdeltafile:
                case jsoniqParser.Kicebergtable:
                case jsoniqParser.Ktruncate:
                case jsoniqParser.Kfirst:
                case jsoniqParser.Klast:
                case jsoniqParser.Kfrom:
                case jsoniqParser.Kedit:
                case jsoniqParser.Kafter:
                case jsoniqParser.Kbefore:
                case jsoniqParser.Kimport:
                case jsoniqParser.Kschema:
                case jsoniqParser.Knamespace:
                case jsoniqParser.Kelement:
                case jsoniqParser.Kslash:
                case jsoniqParser.Kdslash:
                case jsoniqParser.Kat_symbol:
                case jsoniqParser.Kchild:
                case jsoniqParser.Kdescendant:
                case jsoniqParser.Kattribute:
                case jsoniqParser.Kself:
                case jsoniqParser.Kdescendant_or_self:
                case jsoniqParser.Kfollowing_sibling:
                case jsoniqParser.Kfollowing:
                case jsoniqParser.Kparent:
                case jsoniqParser.Kancestor:
                case jsoniqParser.Kpreceding_sibling:
                case jsoniqParser.Kpreceding:
                case jsoniqParser.Kancestor_or_self:
                case jsoniqParser.Knode:
                case jsoniqParser.Kbinary:
                case jsoniqParser.Kdocument:
                case jsoniqParser.Kdocument_node:
                case jsoniqParser.Ktext:
                case jsoniqParser.Kpi:
                case jsoniqParser.Knamespace_node:
                case jsoniqParser.Kschema_attribute:
                case jsoniqParser.Kschema_element:
                case jsoniqParser.Karray_node:
                case jsoniqParser.Kboolean_node:
                case jsoniqParser.Knull_node:
                case jsoniqParser.Knumber_node:
                case jsoniqParser.Kobject_node:
                case jsoniqParser.Kcomment:
                case jsoniqParser.Kbreak:
                case jsoniqParser.Kloop:
                case jsoniqParser.Kcontinue:
                case jsoniqParser.Kexit:
                case jsoniqParser.Kreturning:
                case jsoniqParser.Kwhile:
                case jsoniqParser.NullLiteral:
                    {
                    this.state = 654;
                    localContext._nskw = this.keyWords();
                    }
                    break;
                default:
                    throw new antlr.NoViableAltException(this);
                }
                this.state = 657;
                this.match(jsoniqParser.Kcolon);
                }
                break;
            }
            this.state = 662;
            this.errorHandler.sync(this);
            switch (this.tokenStream.LA(1)) {
            case jsoniqParser.NCName:
                {
                this.state = 660;
                localContext._local_name = this.match(jsoniqParser.NCName);
                }
                break;
            case jsoniqParser.Kfor:
            case jsoniqParser.Klet:
            case jsoniqParser.Kwhere:
            case jsoniqParser.Kgroup:
            case jsoniqParser.Kby:
            case jsoniqParser.Korder:
            case jsoniqParser.Kreturn:
            case jsoniqParser.Kif:
            case jsoniqParser.Kin:
            case jsoniqParser.Kas:
            case jsoniqParser.Kat:
            case jsoniqParser.Kallowing:
            case jsoniqParser.Kempty:
            case jsoniqParser.Kcount:
            case jsoniqParser.Kstable:
            case jsoniqParser.Kascending:
            case jsoniqParser.Kdescending:
            case jsoniqParser.Ksome:
            case jsoniqParser.Kevery:
            case jsoniqParser.Ksatisfies:
            case jsoniqParser.Kcollation:
            case jsoniqParser.Kgreatest:
            case jsoniqParser.Kleast:
            case jsoniqParser.Kswitch:
            case jsoniqParser.Kcase:
            case jsoniqParser.Ktry:
            case jsoniqParser.Kcatch:
            case jsoniqParser.Kdefault:
            case jsoniqParser.Kthen:
            case jsoniqParser.Kelse:
            case jsoniqParser.Ktypeswitch:
            case jsoniqParser.Kor:
            case jsoniqParser.Kand:
            case jsoniqParser.Knot:
            case jsoniqParser.Kto:
            case jsoniqParser.Kinstance:
            case jsoniqParser.Kof:
            case jsoniqParser.Kstatically:
            case jsoniqParser.Kis:
            case jsoniqParser.Ktreat:
            case jsoniqParser.Kcast:
            case jsoniqParser.Kcastable:
            case jsoniqParser.Kversion:
            case jsoniqParser.Kjsoniq:
            case jsoniqParser.Kunordered:
            case jsoniqParser.Ktrue:
            case jsoniqParser.Kfalse:
            case jsoniqParser.Ktype:
            case jsoniqParser.Kvalidate:
            case jsoniqParser.Kannotate:
            case jsoniqParser.Kdeclare:
            case jsoniqParser.Kcontext:
            case jsoniqParser.Kitem:
            case jsoniqParser.Kvariable:
            case jsoniqParser.Kinsert:
            case jsoniqParser.Kdelete:
            case jsoniqParser.Krename:
            case jsoniqParser.Kreplace:
            case jsoniqParser.Kcopy:
            case jsoniqParser.Kmodify:
            case jsoniqParser.Kappend:
            case jsoniqParser.Kinto:
            case jsoniqParser.Kvalue:
            case jsoniqParser.Kwith:
            case jsoniqParser.Kposition:
            case jsoniqParser.Kjson:
            case jsoniqParser.Kupdating:
            case jsoniqParser.Kcreate:
            case jsoniqParser.Kcollection:
            case jsoniqParser.Ktable:
            case jsoniqParser.Kdeltafile:
            case jsoniqParser.Kicebergtable:
            case jsoniqParser.Ktruncate:
            case jsoniqParser.Kfirst:
            case jsoniqParser.Klast:
            case jsoniqParser.Kfrom:
            case jsoniqParser.Kedit:
            case jsoniqParser.Kafter:
            case jsoniqParser.Kbefore:
            case jsoniqParser.Kimport:
            case jsoniqParser.Kschema:
            case jsoniqParser.Knamespace:
            case jsoniqParser.Kelement:
            case jsoniqParser.Kslash:
            case jsoniqParser.Kdslash:
            case jsoniqParser.Kat_symbol:
            case jsoniqParser.Kchild:
            case jsoniqParser.Kdescendant:
            case jsoniqParser.Kattribute:
            case jsoniqParser.Kself:
            case jsoniqParser.Kdescendant_or_self:
            case jsoniqParser.Kfollowing_sibling:
            case jsoniqParser.Kfollowing:
            case jsoniqParser.Kparent:
            case jsoniqParser.Kancestor:
            case jsoniqParser.Kpreceding_sibling:
            case jsoniqParser.Kpreceding:
            case jsoniqParser.Kancestor_or_self:
            case jsoniqParser.Knode:
            case jsoniqParser.Kbinary:
            case jsoniqParser.Kdocument:
            case jsoniqParser.Kdocument_node:
            case jsoniqParser.Ktext:
            case jsoniqParser.Kpi:
            case jsoniqParser.Knamespace_node:
            case jsoniqParser.Kschema_attribute:
            case jsoniqParser.Kschema_element:
            case jsoniqParser.Karray_node:
            case jsoniqParser.Kboolean_node:
            case jsoniqParser.Knull_node:
            case jsoniqParser.Knumber_node:
            case jsoniqParser.Kobject_node:
            case jsoniqParser.Kcomment:
            case jsoniqParser.Kbreak:
            case jsoniqParser.Kloop:
            case jsoniqParser.Kcontinue:
            case jsoniqParser.Kexit:
            case jsoniqParser.Kreturning:
            case jsoniqParser.Kwhile:
            case jsoniqParser.NullLiteral:
                {
                this.state = 661;
                localContext._local_namekw = this.keyWords();
                }
                break;
            default:
                throw new antlr.NoViableAltException(this);
            }
            }
        }
        catch (re) {
            if (re instanceof antlr.RecognitionException) {
                this.errorHandler.reportError(this, re);
                this.errorHandler.recover(this, re);
            } else {
                throw re;
            }
        }
        finally {
            this.exitRule();
        }
        return localContext;
    }
    public dfPropertyName(): DfPropertyNameContext {
        let localContext = new DfPropertyNameContext(this.context, this.state);
        this.enterRule(localContext, 76, jsoniqParser.RULE_dfPropertyName);
        let _la: number;
        try {
            this.enterOuterAlt(localContext, 1);
            {
            this.state = 664;
            _la = this.tokenStream.LA(1);
            if(!((((_la) & ~0x1F) === 0 && ((1 << _la) & 536346624) !== 0))) {
            this.errorHandler.recoverInline(this);
            }
            else {
                this.errorHandler.reportMatch(this);
                this.consume();
            }
            }
        }
        catch (re) {
            if (re instanceof antlr.RecognitionException) {
                this.errorHandler.reportError(this, re);
                this.errorHandler.recover(this, re);
            } else {
                throw re;
            }
        }
        finally {
            this.exitRule();
        }
        return localContext;
    }
    public moduleImport(): ModuleImportContext {
        let localContext = new ModuleImportContext(this.context, this.state);
        this.enterRule(localContext, 78, jsoniqParser.RULE_moduleImport);
        let _la: number;
        try {
            this.enterOuterAlt(localContext, 1);
            {
            this.state = 666;
            this.match(jsoniqParser.Kimport);
            this.state = 667;
            this.match(jsoniqParser.Kmodule);
            this.state = 671;
            this.errorHandler.sync(this);
            _la = this.tokenStream.LA(1);
            if (_la === 141) {
                {
                this.state = 668;
                this.match(jsoniqParser.Knamespace);
                this.state = 669;
                localContext._prefix = this.match(jsoniqParser.NCName);
                this.state = 670;
                this.match(jsoniqParser.Kequal);
                }
            }

            this.state = 673;
            localContext._targetNamespace = this.uriLiteral();
            this.state = 683;
            this.errorHandler.sync(this);
            _la = this.tokenStream.LA(1);
            if (_la === 70) {
                {
                this.state = 674;
                this.match(jsoniqParser.Kat);
                this.state = 675;
                this.uriLiteral();
                this.state = 680;
                this.errorHandler.sync(this);
                _la = this.tokenStream.LA(1);
                while (_la === 13) {
                    {
                    {
                    this.state = 676;
                    this.match(jsoniqParser.Kcomma);
                    this.state = 677;
                    this.uriLiteral();
                    }
                    }
                    this.state = 682;
                    this.errorHandler.sync(this);
                    _la = this.tokenStream.LA(1);
                }
                }
            }

            }
        }
        catch (re) {
            if (re instanceof antlr.RecognitionException) {
                this.errorHandler.reportError(this, re);
                this.errorHandler.recover(this, re);
            } else {
                throw re;
            }
        }
        finally {
            this.exitRule();
        }
        return localContext;
    }
    public varDecl(): VarDeclContext {
        let localContext = new VarDeclContext(this.context, this.state);
        this.enterRule(localContext, 80, jsoniqParser.RULE_varDecl);
        let _la: number;
        try {
            this.enterOuterAlt(localContext, 1);
            {
            this.state = 685;
            this.match(jsoniqParser.Kdeclare);
            this.state = 686;
            this.annotations();
            this.state = 687;
            this.match(jsoniqParser.Kvariable);
            this.state = 688;
            this.varRef();
            this.state = 691;
            this.errorHandler.sync(this);
            _la = this.tokenStream.LA(1);
            if (_la === 69) {
                {
                this.state = 689;
                this.match(jsoniqParser.Kas);
                this.state = 690;
                this.sequenceType();
                }
            }

            this.state = 700;
            this.errorHandler.sync(this);
            switch (this.tokenStream.LA(1)) {
            case jsoniqParser.Kassign:
                {
                {
                this.state = 693;
                this.match(jsoniqParser.Kassign);
                this.state = 694;
                this.exprSingle();
                }
                }
                break;
            case jsoniqParser.Kexternal:
                {
                {
                this.state = 695;
                localContext._external = this.match(jsoniqParser.Kexternal);
                this.state = 698;
                this.errorHandler.sync(this);
                _la = this.tokenStream.LA(1);
                if (_la === 5) {
                    {
                    this.state = 696;
                    this.match(jsoniqParser.Kassign);
                    this.state = 697;
                    this.exprSingle();
                    }
                }

                }
                }
                break;
            default:
                throw new antlr.NoViableAltException(this);
            }
            }
        }
        catch (re) {
            if (re instanceof antlr.RecognitionException) {
                this.errorHandler.reportError(this, re);
                this.errorHandler.recover(this, re);
            } else {
                throw re;
            }
        }
        finally {
            this.exitRule();
        }
        return localContext;
    }
    public contextItemDecl(): ContextItemDeclContext {
        let localContext = new ContextItemDeclContext(this.context, this.state);
        this.enterRule(localContext, 82, jsoniqParser.RULE_contextItemDecl);
        let _la: number;
        try {
            this.enterOuterAlt(localContext, 1);
            {
            this.state = 702;
            this.match(jsoniqParser.Kdeclare);
            this.state = 703;
            this.match(jsoniqParser.Kcontext);
            this.state = 704;
            this.match(jsoniqParser.Kitem);
            this.state = 707;
            this.errorHandler.sync(this);
            _la = this.tokenStream.LA(1);
            if (_la === 69) {
                {
                this.state = 705;
                this.match(jsoniqParser.Kas);
                this.state = 706;
                this.sequenceType();
                }
            }

            this.state = 716;
            this.errorHandler.sync(this);
            switch (this.tokenStream.LA(1)) {
            case jsoniqParser.Kassign:
                {
                {
                this.state = 709;
                this.match(jsoniqParser.Kassign);
                this.state = 710;
                this.exprSingle();
                }
                }
                break;
            case jsoniqParser.Kexternal:
                {
                {
                this.state = 711;
                localContext._external = this.match(jsoniqParser.Kexternal);
                this.state = 714;
                this.errorHandler.sync(this);
                _la = this.tokenStream.LA(1);
                if (_la === 5) {
                    {
                    this.state = 712;
                    this.match(jsoniqParser.Kassign);
                    this.state = 713;
                    this.exprSingle();
                    }
                }

                }
                }
                break;
            default:
                throw new antlr.NoViableAltException(this);
            }
            }
        }
        catch (re) {
            if (re instanceof antlr.RecognitionException) {
                this.errorHandler.reportError(this, re);
                this.errorHandler.recover(this, re);
            } else {
                throw re;
            }
        }
        finally {
            this.exitRule();
        }
        return localContext;
    }
    public functionDecl(): FunctionDeclContext {
        let localContext = new FunctionDeclContext(this.context, this.state);
        this.enterRule(localContext, 84, jsoniqParser.RULE_functionDecl);
        let _la: number;
        try {
            this.enterOuterAlt(localContext, 1);
            {
            this.state = 718;
            this.match(jsoniqParser.Kdeclare);
            this.state = 719;
            this.annotations();
            this.state = 720;
            this.match(jsoniqParser.Kfunction);
            this.state = 721;
            localContext._fn_name = this.qname();
            this.state = 722;
            this.match(jsoniqParser.Klparen);
            this.state = 724;
            this.errorHandler.sync(this);
            _la = this.tokenStream.LA(1);
            if (_la === 4) {
                {
                this.state = 723;
                this.paramList();
                }
            }

            this.state = 726;
            this.match(jsoniqParser.Krparen);
            this.state = 729;
            this.errorHandler.sync(this);
            _la = this.tokenStream.LA(1);
            if (_la === 69) {
                {
                this.state = 727;
                this.match(jsoniqParser.Kas);
                this.state = 728;
                localContext._return_type = this.sequenceType();
                }
            }

            this.state = 736;
            this.errorHandler.sync(this);
            switch (this.tokenStream.LA(1)) {
            case jsoniqParser.Klbrace:
                {
                this.state = 731;
                this.match(jsoniqParser.Klbrace);
                {
                this.state = 732;
                localContext._fn_body = this.statementsAndOptionalExpr();
                }
                this.state = 733;
                this.match(jsoniqParser.Krbrace);
                }
                break;
            case jsoniqParser.Kexternal:
                {
                this.state = 735;
                localContext._is_external = this.match(jsoniqParser.Kexternal);
                }
                break;
            default:
                throw new antlr.NoViableAltException(this);
            }
            }
        }
        catch (re) {
            if (re instanceof antlr.RecognitionException) {
                this.errorHandler.reportError(this, re);
                this.errorHandler.recover(this, re);
            } else {
                throw re;
            }
        }
        finally {
            this.exitRule();
        }
        return localContext;
    }
    public typeDecl(): TypeDeclContext {
        let localContext = new TypeDeclContext(this.context, this.state);
        this.enterRule(localContext, 86, jsoniqParser.RULE_typeDecl);
        try {
            this.enterOuterAlt(localContext, 1);
            {
            this.state = 738;
            this.match(jsoniqParser.Kdeclare);
            this.state = 739;
            this.match(jsoniqParser.Ktype);
            this.state = 740;
            localContext._type_name = this.qname();
            this.state = 741;
            this.match(jsoniqParser.Kas);
            this.state = 743;
            this.errorHandler.sync(this);
            switch (this.interpreter.adaptivePredict(this.tokenStream, 47, this.context) ) {
            case 1:
                {
                this.state = 742;
                localContext._schema = this.schemaLanguage();
                }
                break;
            }
            this.state = 745;
            localContext._type_definition = this.exprSingle();
            }
        }
        catch (re) {
            if (re instanceof antlr.RecognitionException) {
                this.errorHandler.reportError(this, re);
                this.errorHandler.recover(this, re);
            } else {
                throw re;
            }
        }
        finally {
            this.exitRule();
        }
        return localContext;
    }
    public schemaLanguage(): SchemaLanguageContext {
        let localContext = new SchemaLanguageContext(this.context, this.state);
        this.enterRule(localContext, 88, jsoniqParser.RULE_schemaLanguage);
        try {
            this.state = 753;
            this.errorHandler.sync(this);
            switch (this.interpreter.adaptivePredict(this.tokenStream, 48, this.context) ) {
            case 1:
                this.enterOuterAlt(localContext, 1);
                {
                this.state = 747;
                this.match(jsoniqParser.Kjsound);
                this.state = 748;
                this.match(jsoniqParser.Kcompact);
                }
                break;
            case 2:
                this.enterOuterAlt(localContext, 2);
                {
                this.state = 749;
                this.match(jsoniqParser.Kjsound);
                this.state = 750;
                this.match(jsoniqParser.Kverbose);
                }
                break;
            case 3:
                this.enterOuterAlt(localContext, 3);
                {
                this.state = 751;
                this.match(jsoniqParser.Kjson);
                this.state = 752;
                this.match(jsoniqParser.Kschema);
                }
                break;
            }
        }
        catch (re) {
            if (re instanceof antlr.RecognitionException) {
                this.errorHandler.reportError(this, re);
                this.errorHandler.recover(this, re);
            } else {
                throw re;
            }
        }
        finally {
            this.exitRule();
        }
        return localContext;
    }
    public paramList(): ParamListContext {
        let localContext = new ParamListContext(this.context, this.state);
        this.enterRule(localContext, 90, jsoniqParser.RULE_paramList);
        let _la: number;
        try {
            this.enterOuterAlt(localContext, 1);
            {
            this.state = 755;
            this.param();
            this.state = 760;
            this.errorHandler.sync(this);
            _la = this.tokenStream.LA(1);
            while (_la === 13) {
                {
                {
                this.state = 756;
                this.match(jsoniqParser.Kcomma);
                this.state = 757;
                this.param();
                }
                }
                this.state = 762;
                this.errorHandler.sync(this);
                _la = this.tokenStream.LA(1);
            }
            }
        }
        catch (re) {
            if (re instanceof antlr.RecognitionException) {
                this.errorHandler.reportError(this, re);
                this.errorHandler.recover(this, re);
            } else {
                throw re;
            }
        }
        finally {
            this.exitRule();
        }
        return localContext;
    }
    public param(): ParamContext {
        let localContext = new ParamContext(this.context, this.state);
        this.enterRule(localContext, 92, jsoniqParser.RULE_param);
        let _la: number;
        try {
            this.enterOuterAlt(localContext, 1);
            {
            this.state = 763;
            this.match(jsoniqParser.Kdollar);
            this.state = 764;
            this.qname();
            this.state = 767;
            this.errorHandler.sync(this);
            _la = this.tokenStream.LA(1);
            if (_la === 69) {
                {
                this.state = 765;
                this.match(jsoniqParser.Kas);
                this.state = 766;
                this.sequenceType();
                }
            }

            }
        }
        catch (re) {
            if (re instanceof antlr.RecognitionException) {
                this.errorHandler.reportError(this, re);
                this.errorHandler.recover(this, re);
            } else {
                throw re;
            }
        }
        finally {
            this.exitRule();
        }
        return localContext;
    }
    public expr(): ExprContext {
        let localContext = new ExprContext(this.context, this.state);
        this.enterRule(localContext, 94, jsoniqParser.RULE_expr);
        let _la: number;
        try {
            this.enterOuterAlt(localContext, 1);
            {
            this.state = 769;
            this.exprSingle();
            this.state = 774;
            this.errorHandler.sync(this);
            _la = this.tokenStream.LA(1);
            while (_la === 13) {
                {
                {
                this.state = 770;
                this.match(jsoniqParser.Kcomma);
                this.state = 771;
                this.exprSingle();
                }
                }
                this.state = 776;
                this.errorHandler.sync(this);
                _la = this.tokenStream.LA(1);
            }
            }
        }
        catch (re) {
            if (re instanceof antlr.RecognitionException) {
                this.errorHandler.reportError(this, re);
                this.errorHandler.recover(this, re);
            } else {
                throw re;
            }
        }
        finally {
            this.exitRule();
        }
        return localContext;
    }
    public exprSingle(): ExprSingleContext {
        let localContext = new ExprSingleContext(this.context, this.state);
        this.enterRule(localContext, 96, jsoniqParser.RULE_exprSingle);
        try {
            this.state = 783;
            this.errorHandler.sync(this);
            switch (this.interpreter.adaptivePredict(this.tokenStream, 52, this.context) ) {
            case 1:
                this.enterOuterAlt(localContext, 1);
                {
                this.state = 777;
                this.exprSimple();
                }
                break;
            case 2:
                this.enterOuterAlt(localContext, 2);
                {
                this.state = 778;
                this.flowrExpr();
                }
                break;
            case 3:
                this.enterOuterAlt(localContext, 3);
                {
                this.state = 779;
                this.switchExpr();
                }
                break;
            case 4:
                this.enterOuterAlt(localContext, 4);
                {
                this.state = 780;
                this.typeSwitchExpr();
                }
                break;
            case 5:
                this.enterOuterAlt(localContext, 5);
                {
                this.state = 781;
                this.ifExpr();
                }
                break;
            case 6:
                this.enterOuterAlt(localContext, 6);
                {
                this.state = 782;
                this.tryCatchExpr();
                }
                break;
            }
        }
        catch (re) {
            if (re instanceof antlr.RecognitionException) {
                this.errorHandler.reportError(this, re);
                this.errorHandler.recover(this, re);
            } else {
                throw re;
            }
        }
        finally {
            this.exitRule();
        }
        return localContext;
    }
    public exprSimple(): ExprSimpleContext {
        let localContext = new ExprSimpleContext(this.context, this.state);
        this.enterRule(localContext, 98, jsoniqParser.RULE_exprSimple);
        try {
            this.state = 800;
            this.errorHandler.sync(this);
            switch (this.interpreter.adaptivePredict(this.tokenStream, 53, this.context) ) {
            case 1:
                this.enterOuterAlt(localContext, 1);
                {
                this.state = 785;
                this.quantifiedExpr();
                }
                break;
            case 2:
                this.enterOuterAlt(localContext, 2);
                {
                this.state = 786;
                this.orExpr();
                }
                break;
            case 3:
                this.enterOuterAlt(localContext, 3);
                {
                this.state = 787;
                this.insertExpr();
                }
                break;
            case 4:
                this.enterOuterAlt(localContext, 4);
                {
                this.state = 788;
                this.deleteExpr();
                }
                break;
            case 5:
                this.enterOuterAlt(localContext, 5);
                {
                this.state = 789;
                this.renameExpr();
                }
                break;
            case 6:
                this.enterOuterAlt(localContext, 6);
                {
                this.state = 790;
                this.replaceExpr();
                }
                break;
            case 7:
                this.enterOuterAlt(localContext, 7);
                {
                this.state = 791;
                this.transformExpr();
                }
                break;
            case 8:
                this.enterOuterAlt(localContext, 8);
                {
                this.state = 792;
                this.appendExpr();
                }
                break;
            case 9:
                this.enterOuterAlt(localContext, 9);
                {
                this.state = 793;
                this.createCollectionExpr();
                }
                break;
            case 10:
                this.enterOuterAlt(localContext, 10);
                {
                this.state = 794;
                this.truncateCollectionExpr();
                }
                break;
            case 11:
                this.enterOuterAlt(localContext, 11);
                {
                this.state = 795;
                this.deleteIndexExpr();
                }
                break;
            case 12:
                this.enterOuterAlt(localContext, 12);
                {
                this.state = 796;
                this.deleteSearchExpr();
                }
                break;
            case 13:
                this.enterOuterAlt(localContext, 13);
                {
                this.state = 797;
                this.editCollectionExpr();
                }
                break;
            case 14:
                this.enterOuterAlt(localContext, 14);
                {
                this.state = 798;
                this.insertIndexExpr();
                }
                break;
            case 15:
                this.enterOuterAlt(localContext, 15);
                {
                this.state = 799;
                this.insertSearchExpr();
                }
                break;
            }
        }
        catch (re) {
            if (re instanceof antlr.RecognitionException) {
                this.errorHandler.reportError(this, re);
                this.errorHandler.recover(this, re);
            } else {
                throw re;
            }
        }
        finally {
            this.exitRule();
        }
        return localContext;
    }
    public flowrExpr(): FlowrExprContext {
        let localContext = new FlowrExprContext(this.context, this.state);
        this.enterRule(localContext, 100, jsoniqParser.RULE_flowrExpr);
        let _la: number;
        try {
            this.enterOuterAlt(localContext, 1);
            {
            this.state = 804;
            this.errorHandler.sync(this);
            switch (this.tokenStream.LA(1)) {
            case jsoniqParser.Kfor:
                {
                this.state = 802;
                localContext._start_for = this.forClause();
                }
                break;
            case jsoniqParser.Klet:
                {
                this.state = 803;
                localContext._start_let = this.letClause();
                }
                break;
            default:
                throw new antlr.NoViableAltException(this);
            }
            this.state = 814;
            this.errorHandler.sync(this);
            _la = this.tokenStream.LA(1);
            while (((((_la - 60)) & ~0x1F) === 0 && ((1 << (_la - 60)) & 24623) !== 0)) {
                {
                this.state = 812;
                this.errorHandler.sync(this);
                switch (this.tokenStream.LA(1)) {
                case jsoniqParser.Kfor:
                    {
                    this.state = 806;
                    this.forClause();
                    }
                    break;
                case jsoniqParser.Klet:
                    {
                    this.state = 807;
                    this.letClause();
                    }
                    break;
                case jsoniqParser.Kwhere:
                    {
                    this.state = 808;
                    this.whereClause();
                    }
                    break;
                case jsoniqParser.Kgroup:
                    {
                    this.state = 809;
                    this.groupByClause();
                    }
                    break;
                case jsoniqParser.Korder:
                case jsoniqParser.Kstable:
                    {
                    this.state = 810;
                    this.orderByClause();
                    }
                    break;
                case jsoniqParser.Kcount:
                    {
                    this.state = 811;
                    this.countClause();
                    }
                    break;
                default:
                    throw new antlr.NoViableAltException(this);
                }
                }
                this.state = 816;
                this.errorHandler.sync(this);
                _la = this.tokenStream.LA(1);
            }
            this.state = 817;
            this.match(jsoniqParser.Kreturn);
            this.state = 818;
            localContext._return_expr = this.exprSingle();
            }
        }
        catch (re) {
            if (re instanceof antlr.RecognitionException) {
                this.errorHandler.reportError(this, re);
                this.errorHandler.recover(this, re);
            } else {
                throw re;
            }
        }
        finally {
            this.exitRule();
        }
        return localContext;
    }
    public forClause(): ForClauseContext {
        let localContext = new ForClauseContext(this.context, this.state);
        this.enterRule(localContext, 102, jsoniqParser.RULE_forClause);
        let _la: number;
        try {
            this.enterOuterAlt(localContext, 1);
            {
            this.state = 820;
            this.match(jsoniqParser.Kfor);
            this.state = 821;
            localContext._forVar = this.forVar();
            localContext._vars.push(localContext._forVar!);
            this.state = 826;
            this.errorHandler.sync(this);
            _la = this.tokenStream.LA(1);
            while (_la === 13) {
                {
                {
                this.state = 822;
                this.match(jsoniqParser.Kcomma);
                this.state = 823;
                localContext._forVar = this.forVar();
                localContext._vars.push(localContext._forVar!);
                }
                }
                this.state = 828;
                this.errorHandler.sync(this);
                _la = this.tokenStream.LA(1);
            }
            }
        }
        catch (re) {
            if (re instanceof antlr.RecognitionException) {
                this.errorHandler.reportError(this, re);
                this.errorHandler.recover(this, re);
            } else {
                throw re;
            }
        }
        finally {
            this.exitRule();
        }
        return localContext;
    }
    public forVar(): ForVarContext {
        let localContext = new ForVarContext(this.context, this.state);
        this.enterRule(localContext, 104, jsoniqParser.RULE_forVar);
        let _la: number;
        try {
            this.enterOuterAlt(localContext, 1);
            {
            this.state = 829;
            localContext._var_ref = this.varRef();
            this.state = 832;
            this.errorHandler.sync(this);
            _la = this.tokenStream.LA(1);
            if (_la === 69) {
                {
                this.state = 830;
                this.match(jsoniqParser.Kas);
                this.state = 831;
                localContext._seq = this.sequenceType();
                }
            }

            this.state = 836;
            this.errorHandler.sync(this);
            _la = this.tokenStream.LA(1);
            if (_la === 71) {
                {
                this.state = 834;
                localContext._flag = this.match(jsoniqParser.Kallowing);
                this.state = 835;
                this.match(jsoniqParser.Kempty);
                }
            }

            this.state = 840;
            this.errorHandler.sync(this);
            _la = this.tokenStream.LA(1);
            if (_la === 70) {
                {
                this.state = 838;
                this.match(jsoniqParser.Kat);
                this.state = 839;
                localContext._at = this.varRef();
                }
            }

            this.state = 842;
            this.match(jsoniqParser.Kin);
            this.state = 843;
            localContext._ex = this.exprSingle();
            }
        }
        catch (re) {
            if (re instanceof antlr.RecognitionException) {
                this.errorHandler.reportError(this, re);
                this.errorHandler.recover(this, re);
            } else {
                throw re;
            }
        }
        finally {
            this.exitRule();
        }
        return localContext;
    }
    public letClause(): LetClauseContext {
        let localContext = new LetClauseContext(this.context, this.state);
        this.enterRule(localContext, 106, jsoniqParser.RULE_letClause);
        let _la: number;
        try {
            this.enterOuterAlt(localContext, 1);
            {
            this.state = 845;
            this.match(jsoniqParser.Klet);
            this.state = 846;
            localContext._letVar = this.letVar();
            localContext._vars.push(localContext._letVar!);
            this.state = 851;
            this.errorHandler.sync(this);
            _la = this.tokenStream.LA(1);
            while (_la === 13) {
                {
                {
                this.state = 847;
                this.match(jsoniqParser.Kcomma);
                this.state = 848;
                localContext._letVar = this.letVar();
                localContext._vars.push(localContext._letVar!);
                }
                }
                this.state = 853;
                this.errorHandler.sync(this);
                _la = this.tokenStream.LA(1);
            }
            }
        }
        catch (re) {
            if (re instanceof antlr.RecognitionException) {
                this.errorHandler.reportError(this, re);
                this.errorHandler.recover(this, re);
            } else {
                throw re;
            }
        }
        finally {
            this.exitRule();
        }
        return localContext;
    }
    public letVar(): LetVarContext {
        let localContext = new LetVarContext(this.context, this.state);
        this.enterRule(localContext, 108, jsoniqParser.RULE_letVar);
        let _la: number;
        try {
            this.enterOuterAlt(localContext, 1);
            {
            this.state = 854;
            localContext._var_ref = this.varRef();
            this.state = 857;
            this.errorHandler.sync(this);
            _la = this.tokenStream.LA(1);
            if (_la === 69) {
                {
                this.state = 855;
                this.match(jsoniqParser.Kas);
                this.state = 856;
                localContext._seq = this.sequenceType();
                }
            }

            this.state = 859;
            this.match(jsoniqParser.Kassign);
            this.state = 860;
            localContext._ex = this.exprSingle();
            }
        }
        catch (re) {
            if (re instanceof antlr.RecognitionException) {
                this.errorHandler.reportError(this, re);
                this.errorHandler.recover(this, re);
            } else {
                throw re;
            }
        }
        finally {
            this.exitRule();
        }
        return localContext;
    }
    public whereClause(): WhereClauseContext {
        let localContext = new WhereClauseContext(this.context, this.state);
        this.enterRule(localContext, 110, jsoniqParser.RULE_whereClause);
        try {
            this.enterOuterAlt(localContext, 1);
            {
            this.state = 862;
            this.match(jsoniqParser.Kwhere);
            this.state = 863;
            this.exprSingle();
            }
        }
        catch (re) {
            if (re instanceof antlr.RecognitionException) {
                this.errorHandler.reportError(this, re);
                this.errorHandler.recover(this, re);
            } else {
                throw re;
            }
        }
        finally {
            this.exitRule();
        }
        return localContext;
    }
    public groupByClause(): GroupByClauseContext {
        let localContext = new GroupByClauseContext(this.context, this.state);
        this.enterRule(localContext, 112, jsoniqParser.RULE_groupByClause);
        let _la: number;
        try {
            this.enterOuterAlt(localContext, 1);
            {
            this.state = 865;
            this.match(jsoniqParser.Kgroup);
            this.state = 866;
            this.match(jsoniqParser.Kby);
            this.state = 867;
            localContext._groupByVar = this.groupByVar();
            localContext._vars.push(localContext._groupByVar!);
            this.state = 872;
            this.errorHandler.sync(this);
            _la = this.tokenStream.LA(1);
            while (_la === 13) {
                {
                {
                this.state = 868;
                this.match(jsoniqParser.Kcomma);
                this.state = 869;
                localContext._groupByVar = this.groupByVar();
                localContext._vars.push(localContext._groupByVar!);
                }
                }
                this.state = 874;
                this.errorHandler.sync(this);
                _la = this.tokenStream.LA(1);
            }
            }
        }
        catch (re) {
            if (re instanceof antlr.RecognitionException) {
                this.errorHandler.reportError(this, re);
                this.errorHandler.recover(this, re);
            } else {
                throw re;
            }
        }
        finally {
            this.exitRule();
        }
        return localContext;
    }
    public groupByVar(): GroupByVarContext {
        let localContext = new GroupByVarContext(this.context, this.state);
        this.enterRule(localContext, 114, jsoniqParser.RULE_groupByVar);
        let _la: number;
        try {
            this.enterOuterAlt(localContext, 1);
            {
            this.state = 875;
            localContext._var_ref = this.varRef();
            this.state = 882;
            this.errorHandler.sync(this);
            _la = this.tokenStream.LA(1);
            if (_la === 5 || _la === 69) {
                {
                this.state = 878;
                this.errorHandler.sync(this);
                _la = this.tokenStream.LA(1);
                if (_la === 69) {
                    {
                    this.state = 876;
                    this.match(jsoniqParser.Kas);
                    this.state = 877;
                    localContext._seq = this.sequenceType();
                    }
                }

                this.state = 880;
                localContext._decl = this.match(jsoniqParser.Kassign);
                this.state = 881;
                localContext._ex = this.exprSingle();
                }
            }

            this.state = 886;
            this.errorHandler.sync(this);
            _la = this.tokenStream.LA(1);
            if (_la === 80) {
                {
                this.state = 884;
                this.match(jsoniqParser.Kcollation);
                this.state = 885;
                localContext._uri = this.uriLiteral();
                }
            }

            }
        }
        catch (re) {
            if (re instanceof antlr.RecognitionException) {
                this.errorHandler.reportError(this, re);
                this.errorHandler.recover(this, re);
            } else {
                throw re;
            }
        }
        finally {
            this.exitRule();
        }
        return localContext;
    }
    public orderByClause(): OrderByClauseContext {
        let localContext = new OrderByClauseContext(this.context, this.state);
        this.enterRule(localContext, 116, jsoniqParser.RULE_orderByClause);
        let _la: number;
        try {
            this.enterOuterAlt(localContext, 1);
            {
            this.state = 893;
            this.errorHandler.sync(this);
            switch (this.tokenStream.LA(1)) {
            case jsoniqParser.Korder:
                {
                {
                this.state = 888;
                this.match(jsoniqParser.Korder);
                this.state = 889;
                this.match(jsoniqParser.Kby);
                }
                }
                break;
            case jsoniqParser.Kstable:
                {
                {
                this.state = 890;
                localContext._stb = this.match(jsoniqParser.Kstable);
                this.state = 891;
                this.match(jsoniqParser.Korder);
                this.state = 892;
                this.match(jsoniqParser.Kby);
                }
                }
                break;
            default:
                throw new antlr.NoViableAltException(this);
            }
            this.state = 895;
            this.orderByExpr();
            this.state = 900;
            this.errorHandler.sync(this);
            _la = this.tokenStream.LA(1);
            while (_la === 13) {
                {
                {
                this.state = 896;
                this.match(jsoniqParser.Kcomma);
                this.state = 897;
                this.orderByExpr();
                }
                }
                this.state = 902;
                this.errorHandler.sync(this);
                _la = this.tokenStream.LA(1);
            }
            }
        }
        catch (re) {
            if (re instanceof antlr.RecognitionException) {
                this.errorHandler.reportError(this, re);
                this.errorHandler.recover(this, re);
            } else {
                throw re;
            }
        }
        finally {
            this.exitRule();
        }
        return localContext;
    }
    public orderByExpr(): OrderByExprContext {
        let localContext = new OrderByExprContext(this.context, this.state);
        this.enterRule(localContext, 118, jsoniqParser.RULE_orderByExpr);
        let _la: number;
        try {
            this.enterOuterAlt(localContext, 1);
            {
            this.state = 903;
            localContext._ex = this.exprSingle();
            this.state = 906;
            this.errorHandler.sync(this);
            switch (this.tokenStream.LA(1)) {
            case jsoniqParser.Kascending:
                {
                this.state = 904;
                this.match(jsoniqParser.Kascending);
                }
                break;
            case jsoniqParser.Kdescending:
                {
                this.state = 905;
                localContext._desc = this.match(jsoniqParser.Kdescending);
                }
                break;
            case jsoniqParser.Kcomma:
            case jsoniqParser.Kfor:
            case jsoniqParser.Klet:
            case jsoniqParser.Kwhere:
            case jsoniqParser.Kgroup:
            case jsoniqParser.Korder:
            case jsoniqParser.Kreturn:
            case jsoniqParser.Kempty:
            case jsoniqParser.Kcount:
            case jsoniqParser.Kstable:
            case jsoniqParser.Kcollation:
                break;
            default:
                break;
            }
            this.state = 913;
            this.errorHandler.sync(this);
            _la = this.tokenStream.LA(1);
            if (_la === 72) {
                {
                this.state = 908;
                this.match(jsoniqParser.Kempty);
                this.state = 911;
                this.errorHandler.sync(this);
                switch (this.tokenStream.LA(1)) {
                case jsoniqParser.Kgreatest:
                    {
                    this.state = 909;
                    localContext._gr = this.match(jsoniqParser.Kgreatest);
                    }
                    break;
                case jsoniqParser.Kleast:
                    {
                    this.state = 910;
                    localContext._ls = this.match(jsoniqParser.Kleast);
                    }
                    break;
                default:
                    throw new antlr.NoViableAltException(this);
                }
                }
            }

            this.state = 917;
            this.errorHandler.sync(this);
            _la = this.tokenStream.LA(1);
            if (_la === 80) {
                {
                this.state = 915;
                this.match(jsoniqParser.Kcollation);
                this.state = 916;
                localContext._uril = this.uriLiteral();
                }
            }

            }
        }
        catch (re) {
            if (re instanceof antlr.RecognitionException) {
                this.errorHandler.reportError(this, re);
                this.errorHandler.recover(this, re);
            } else {
                throw re;
            }
        }
        finally {
            this.exitRule();
        }
        return localContext;
    }
    public countClause(): CountClauseContext {
        let localContext = new CountClauseContext(this.context, this.state);
        this.enterRule(localContext, 120, jsoniqParser.RULE_countClause);
        try {
            this.enterOuterAlt(localContext, 1);
            {
            this.state = 919;
            this.match(jsoniqParser.Kcount);
            this.state = 920;
            this.varRef();
            }
        }
        catch (re) {
            if (re instanceof antlr.RecognitionException) {
                this.errorHandler.reportError(this, re);
                this.errorHandler.recover(this, re);
            } else {
                throw re;
            }
        }
        finally {
            this.exitRule();
        }
        return localContext;
    }
    public quantifiedExpr(): QuantifiedExprContext {
        let localContext = new QuantifiedExprContext(this.context, this.state);
        this.enterRule(localContext, 122, jsoniqParser.RULE_quantifiedExpr);
        let _la: number;
        try {
            this.enterOuterAlt(localContext, 1);
            {
            this.state = 924;
            this.errorHandler.sync(this);
            switch (this.tokenStream.LA(1)) {
            case jsoniqParser.Ksome:
                {
                this.state = 922;
                localContext._so = this.match(jsoniqParser.Ksome);
                }
                break;
            case jsoniqParser.Kevery:
                {
                this.state = 923;
                localContext._ev = this.match(jsoniqParser.Kevery);
                }
                break;
            default:
                throw new antlr.NoViableAltException(this);
            }
            this.state = 926;
            localContext._quantifiedExprVar = this.quantifiedExprVar();
            localContext._vars.push(localContext._quantifiedExprVar!);
            this.state = 931;
            this.errorHandler.sync(this);
            _la = this.tokenStream.LA(1);
            while (_la === 13) {
                {
                {
                this.state = 927;
                this.match(jsoniqParser.Kcomma);
                this.state = 928;
                localContext._quantifiedExprVar = this.quantifiedExprVar();
                localContext._vars.push(localContext._quantifiedExprVar!);
                }
                }
                this.state = 933;
                this.errorHandler.sync(this);
                _la = this.tokenStream.LA(1);
            }
            this.state = 934;
            this.match(jsoniqParser.Ksatisfies);
            this.state = 935;
            this.exprSingle();
            }
        }
        catch (re) {
            if (re instanceof antlr.RecognitionException) {
                this.errorHandler.reportError(this, re);
                this.errorHandler.recover(this, re);
            } else {
                throw re;
            }
        }
        finally {
            this.exitRule();
        }
        return localContext;
    }
    public quantifiedExprVar(): QuantifiedExprVarContext {
        let localContext = new QuantifiedExprVarContext(this.context, this.state);
        this.enterRule(localContext, 124, jsoniqParser.RULE_quantifiedExprVar);
        let _la: number;
        try {
            this.enterOuterAlt(localContext, 1);
            {
            this.state = 937;
            this.varRef();
            this.state = 940;
            this.errorHandler.sync(this);
            _la = this.tokenStream.LA(1);
            if (_la === 69) {
                {
                this.state = 938;
                this.match(jsoniqParser.Kas);
                this.state = 939;
                this.sequenceType();
                }
            }

            this.state = 942;
            this.match(jsoniqParser.Kin);
            this.state = 943;
            this.exprSingle();
            }
        }
        catch (re) {
            if (re instanceof antlr.RecognitionException) {
                this.errorHandler.reportError(this, re);
                this.errorHandler.recover(this, re);
            } else {
                throw re;
            }
        }
        finally {
            this.exitRule();
        }
        return localContext;
    }
    public switchExpr(): SwitchExprContext {
        let localContext = new SwitchExprContext(this.context, this.state);
        this.enterRule(localContext, 126, jsoniqParser.RULE_switchExpr);
        let _la: number;
        try {
            this.enterOuterAlt(localContext, 1);
            {
            this.state = 945;
            this.match(jsoniqParser.Kswitch);
            this.state = 946;
            this.match(jsoniqParser.Klparen);
            this.state = 947;
            localContext._cond = this.expr();
            this.state = 948;
            this.match(jsoniqParser.Krparen);
            this.state = 950;
            this.errorHandler.sync(this);
            _la = this.tokenStream.LA(1);
            do {
                {
                {
                this.state = 949;
                localContext._switchCaseClause = this.switchCaseClause();
                localContext._cases.push(localContext._switchCaseClause!);
                }
                }
                this.state = 952;
                this.errorHandler.sync(this);
                _la = this.tokenStream.LA(1);
            } while (_la === 84);
            this.state = 954;
            this.match(jsoniqParser.Kdefault);
            this.state = 955;
            this.match(jsoniqParser.Kreturn);
            this.state = 956;
            localContext._def = this.exprSingle();
            }
        }
        catch (re) {
            if (re instanceof antlr.RecognitionException) {
                this.errorHandler.reportError(this, re);
                this.errorHandler.recover(this, re);
            } else {
                throw re;
            }
        }
        finally {
            this.exitRule();
        }
        return localContext;
    }
    public switchCaseClause(): SwitchCaseClauseContext {
        let localContext = new SwitchCaseClauseContext(this.context, this.state);
        this.enterRule(localContext, 128, jsoniqParser.RULE_switchCaseClause);
        let _la: number;
        try {
            this.enterOuterAlt(localContext, 1);
            {
            this.state = 960;
            this.errorHandler.sync(this);
            _la = this.tokenStream.LA(1);
            do {
                {
                {
                this.state = 958;
                this.match(jsoniqParser.Kcase);
                this.state = 959;
                localContext._exprSingle = this.exprSingle();
                localContext._cond.push(localContext._exprSingle!);
                }
                }
                this.state = 962;
                this.errorHandler.sync(this);
                _la = this.tokenStream.LA(1);
            } while (_la === 84);
            this.state = 964;
            this.match(jsoniqParser.Kreturn);
            this.state = 965;
            localContext._ret = this.exprSingle();
            }
        }
        catch (re) {
            if (re instanceof antlr.RecognitionException) {
                this.errorHandler.reportError(this, re);
                this.errorHandler.recover(this, re);
            } else {
                throw re;
            }
        }
        finally {
            this.exitRule();
        }
        return localContext;
    }
    public typeSwitchExpr(): TypeSwitchExprContext {
        let localContext = new TypeSwitchExprContext(this.context, this.state);
        this.enterRule(localContext, 130, jsoniqParser.RULE_typeSwitchExpr);
        let _la: number;
        try {
            this.enterOuterAlt(localContext, 1);
            {
            this.state = 967;
            this.match(jsoniqParser.Ktypeswitch);
            this.state = 968;
            this.match(jsoniqParser.Klparen);
            this.state = 969;
            localContext._cond = this.expr();
            this.state = 970;
            this.match(jsoniqParser.Krparen);
            this.state = 972;
            this.errorHandler.sync(this);
            _la = this.tokenStream.LA(1);
            do {
                {
                {
                this.state = 971;
                localContext._caseClause = this.caseClause();
                localContext._cses.push(localContext._caseClause!);
                }
                }
                this.state = 974;
                this.errorHandler.sync(this);
                _la = this.tokenStream.LA(1);
            } while (_la === 84);
            this.state = 976;
            this.match(jsoniqParser.Kdefault);
            this.state = 978;
            this.errorHandler.sync(this);
            _la = this.tokenStream.LA(1);
            if (_la === 4) {
                {
                this.state = 977;
                localContext._var_ref = this.varRef();
                }
            }

            this.state = 980;
            this.match(jsoniqParser.Kreturn);
            this.state = 981;
            localContext._def = this.exprSingle();
            }
        }
        catch (re) {
            if (re instanceof antlr.RecognitionException) {
                this.errorHandler.reportError(this, re);
                this.errorHandler.recover(this, re);
            } else {
                throw re;
            }
        }
        finally {
            this.exitRule();
        }
        return localContext;
    }
    public caseClause(): CaseClauseContext {
        let localContext = new CaseClauseContext(this.context, this.state);
        this.enterRule(localContext, 132, jsoniqParser.RULE_caseClause);
        let _la: number;
        try {
            this.enterOuterAlt(localContext, 1);
            {
            this.state = 983;
            this.match(jsoniqParser.Kcase);
            this.state = 987;
            this.errorHandler.sync(this);
            _la = this.tokenStream.LA(1);
            if (_la === 4) {
                {
                this.state = 984;
                localContext._var_ref = this.varRef();
                this.state = 985;
                this.match(jsoniqParser.Kas);
                }
            }

            this.state = 989;
            localContext._sequenceType = this.sequenceType();
            localContext._union.push(localContext._sequenceType!);
            this.state = 994;
            this.errorHandler.sync(this);
            _la = this.tokenStream.LA(1);
            while (_la === 11) {
                {
                {
                this.state = 990;
                this.match(jsoniqParser.Kpipe);
                this.state = 991;
                localContext._sequenceType = this.sequenceType();
                localContext._union.push(localContext._sequenceType!);
                }
                }
                this.state = 996;
                this.errorHandler.sync(this);
                _la = this.tokenStream.LA(1);
            }
            this.state = 997;
            this.match(jsoniqParser.Kreturn);
            this.state = 998;
            localContext._ret = this.exprSingle();
            }
        }
        catch (re) {
            if (re instanceof antlr.RecognitionException) {
                this.errorHandler.reportError(this, re);
                this.errorHandler.recover(this, re);
            } else {
                throw re;
            }
        }
        finally {
            this.exitRule();
        }
        return localContext;
    }
    public ifExpr(): IfExprContext {
        let localContext = new IfExprContext(this.context, this.state);
        this.enterRule(localContext, 134, jsoniqParser.RULE_ifExpr);
        try {
            this.enterOuterAlt(localContext, 1);
            {
            this.state = 1000;
            this.match(jsoniqParser.Kif);
            this.state = 1001;
            this.match(jsoniqParser.Klparen);
            this.state = 1002;
            localContext._test_condition = this.expr();
            this.state = 1003;
            this.match(jsoniqParser.Krparen);
            this.state = 1004;
            this.match(jsoniqParser.Kthen);
            this.state = 1005;
            localContext._branch = this.exprSingle();
            this.state = 1006;
            this.match(jsoniqParser.Kelse);
            this.state = 1007;
            localContext._else_branch = this.exprSingle();
            }
        }
        catch (re) {
            if (re instanceof antlr.RecognitionException) {
                this.errorHandler.reportError(this, re);
                this.errorHandler.recover(this, re);
            } else {
                throw re;
            }
        }
        finally {
            this.exitRule();
        }
        return localContext;
    }
    public tryCatchExpr(): TryCatchExprContext {
        let localContext = new TryCatchExprContext(this.context, this.state);
        this.enterRule(localContext, 136, jsoniqParser.RULE_tryCatchExpr);
        let _la: number;
        try {
            this.enterOuterAlt(localContext, 1);
            {
            this.state = 1009;
            this.match(jsoniqParser.Ktry);
            this.state = 1010;
            this.match(jsoniqParser.Klbrace);
            this.state = 1011;
            localContext._try_expression = this.expr();
            this.state = 1012;
            this.match(jsoniqParser.Krbrace);
            this.state = 1014;
            this.errorHandler.sync(this);
            _la = this.tokenStream.LA(1);
            do {
                {
                {
                this.state = 1013;
                localContext._catchClause = this.catchClause();
                localContext._catches.push(localContext._catchClause!);
                }
                }
                this.state = 1016;
                this.errorHandler.sync(this);
                _la = this.tokenStream.LA(1);
            } while (_la === 86);
            }
        }
        catch (re) {
            if (re instanceof antlr.RecognitionException) {
                this.errorHandler.reportError(this, re);
                this.errorHandler.recover(this, re);
            } else {
                throw re;
            }
        }
        finally {
            this.exitRule();
        }
        return localContext;
    }
    public catchClause(): CatchClauseContext {
        let localContext = new CatchClauseContext(this.context, this.state);
        this.enterRule(localContext, 138, jsoniqParser.RULE_catchClause);
        let _la: number;
        try {
            this.enterOuterAlt(localContext, 1);
            {
            this.state = 1018;
            this.match(jsoniqParser.Kcatch);
            this.state = 1021;
            this.errorHandler.sync(this);
            switch (this.tokenStream.LA(1)) {
            case jsoniqParser.Kasterisk:
                {
                this.state = 1019;
                localContext._s10 = this.match(jsoniqParser.Kasterisk);
                localContext._jokers.push(localContext._s10!);
                }
                break;
            case jsoniqParser.Kfor:
            case jsoniqParser.Klet:
            case jsoniqParser.Kwhere:
            case jsoniqParser.Kgroup:
            case jsoniqParser.Kby:
            case jsoniqParser.Korder:
            case jsoniqParser.Kreturn:
            case jsoniqParser.Kif:
            case jsoniqParser.Kin:
            case jsoniqParser.Kas:
            case jsoniqParser.Kat:
            case jsoniqParser.Kallowing:
            case jsoniqParser.Kempty:
            case jsoniqParser.Kcount:
            case jsoniqParser.Kstable:
            case jsoniqParser.Kascending:
            case jsoniqParser.Kdescending:
            case jsoniqParser.Ksome:
            case jsoniqParser.Kevery:
            case jsoniqParser.Ksatisfies:
            case jsoniqParser.Kcollation:
            case jsoniqParser.Kgreatest:
            case jsoniqParser.Kleast:
            case jsoniqParser.Kswitch:
            case jsoniqParser.Kcase:
            case jsoniqParser.Ktry:
            case jsoniqParser.Kcatch:
            case jsoniqParser.Kdefault:
            case jsoniqParser.Kthen:
            case jsoniqParser.Kelse:
            case jsoniqParser.Ktypeswitch:
            case jsoniqParser.Kor:
            case jsoniqParser.Kand:
            case jsoniqParser.Knot:
            case jsoniqParser.Kto:
            case jsoniqParser.Kinstance:
            case jsoniqParser.Kof:
            case jsoniqParser.Kstatically:
            case jsoniqParser.Kis:
            case jsoniqParser.Ktreat:
            case jsoniqParser.Kcast:
            case jsoniqParser.Kcastable:
            case jsoniqParser.Kversion:
            case jsoniqParser.Kjsoniq:
            case jsoniqParser.Kunordered:
            case jsoniqParser.Ktrue:
            case jsoniqParser.Kfalse:
            case jsoniqParser.Ktype:
            case jsoniqParser.Kvalidate:
            case jsoniqParser.Kannotate:
            case jsoniqParser.Kdeclare:
            case jsoniqParser.Kcontext:
            case jsoniqParser.Kitem:
            case jsoniqParser.Kvariable:
            case jsoniqParser.Kinsert:
            case jsoniqParser.Kdelete:
            case jsoniqParser.Krename:
            case jsoniqParser.Kreplace:
            case jsoniqParser.Kcopy:
            case jsoniqParser.Kmodify:
            case jsoniqParser.Kappend:
            case jsoniqParser.Kinto:
            case jsoniqParser.Kvalue:
            case jsoniqParser.Kwith:
            case jsoniqParser.Kposition:
            case jsoniqParser.Kjson:
            case jsoniqParser.Kupdating:
            case jsoniqParser.Kcreate:
            case jsoniqParser.Kcollection:
            case jsoniqParser.Ktable:
            case jsoniqParser.Kdeltafile:
            case jsoniqParser.Kicebergtable:
            case jsoniqParser.Ktruncate:
            case jsoniqParser.Kfirst:
            case jsoniqParser.Klast:
            case jsoniqParser.Kfrom:
            case jsoniqParser.Kedit:
            case jsoniqParser.Kafter:
            case jsoniqParser.Kbefore:
            case jsoniqParser.Kimport:
            case jsoniqParser.Kschema:
            case jsoniqParser.Knamespace:
            case jsoniqParser.Kelement:
            case jsoniqParser.Kslash:
            case jsoniqParser.Kdslash:
            case jsoniqParser.Kat_symbol:
            case jsoniqParser.Kchild:
            case jsoniqParser.Kdescendant:
            case jsoniqParser.Kattribute:
            case jsoniqParser.Kself:
            case jsoniqParser.Kdescendant_or_self:
            case jsoniqParser.Kfollowing_sibling:
            case jsoniqParser.Kfollowing:
            case jsoniqParser.Kparent:
            case jsoniqParser.Kancestor:
            case jsoniqParser.Kpreceding_sibling:
            case jsoniqParser.Kpreceding:
            case jsoniqParser.Kancestor_or_self:
            case jsoniqParser.Knode:
            case jsoniqParser.Kbinary:
            case jsoniqParser.Kdocument:
            case jsoniqParser.Kdocument_node:
            case jsoniqParser.Ktext:
            case jsoniqParser.Kpi:
            case jsoniqParser.Knamespace_node:
            case jsoniqParser.Kschema_attribute:
            case jsoniqParser.Kschema_element:
            case jsoniqParser.Karray_node:
            case jsoniqParser.Kboolean_node:
            case jsoniqParser.Knull_node:
            case jsoniqParser.Knumber_node:
            case jsoniqParser.Kobject_node:
            case jsoniqParser.Kcomment:
            case jsoniqParser.Kbreak:
            case jsoniqParser.Kloop:
            case jsoniqParser.Kcontinue:
            case jsoniqParser.Kexit:
            case jsoniqParser.Kreturning:
            case jsoniqParser.Kwhile:
            case jsoniqParser.NullLiteral:
            case jsoniqParser.NCName:
                {
                this.state = 1020;
                localContext._qname = this.qname();
                localContext._errors.push(localContext._qname!);
                }
                break;
            default:
                throw new antlr.NoViableAltException(this);
            }
            this.state = 1030;
            this.errorHandler.sync(this);
            _la = this.tokenStream.LA(1);
            while (_la === 11) {
                {
                {
                this.state = 1023;
                this.match(jsoniqParser.Kpipe);
                this.state = 1026;
                this.errorHandler.sync(this);
                switch (this.tokenStream.LA(1)) {
                case jsoniqParser.Kasterisk:
                    {
                    this.state = 1024;
                    localContext._s10 = this.match(jsoniqParser.Kasterisk);
                    localContext._jokers.push(localContext._s10!);
                    }
                    break;
                case jsoniqParser.Kfor:
                case jsoniqParser.Klet:
                case jsoniqParser.Kwhere:
                case jsoniqParser.Kgroup:
                case jsoniqParser.Kby:
                case jsoniqParser.Korder:
                case jsoniqParser.Kreturn:
                case jsoniqParser.Kif:
                case jsoniqParser.Kin:
                case jsoniqParser.Kas:
                case jsoniqParser.Kat:
                case jsoniqParser.Kallowing:
                case jsoniqParser.Kempty:
                case jsoniqParser.Kcount:
                case jsoniqParser.Kstable:
                case jsoniqParser.Kascending:
                case jsoniqParser.Kdescending:
                case jsoniqParser.Ksome:
                case jsoniqParser.Kevery:
                case jsoniqParser.Ksatisfies:
                case jsoniqParser.Kcollation:
                case jsoniqParser.Kgreatest:
                case jsoniqParser.Kleast:
                case jsoniqParser.Kswitch:
                case jsoniqParser.Kcase:
                case jsoniqParser.Ktry:
                case jsoniqParser.Kcatch:
                case jsoniqParser.Kdefault:
                case jsoniqParser.Kthen:
                case jsoniqParser.Kelse:
                case jsoniqParser.Ktypeswitch:
                case jsoniqParser.Kor:
                case jsoniqParser.Kand:
                case jsoniqParser.Knot:
                case jsoniqParser.Kto:
                case jsoniqParser.Kinstance:
                case jsoniqParser.Kof:
                case jsoniqParser.Kstatically:
                case jsoniqParser.Kis:
                case jsoniqParser.Ktreat:
                case jsoniqParser.Kcast:
                case jsoniqParser.Kcastable:
                case jsoniqParser.Kversion:
                case jsoniqParser.Kjsoniq:
                case jsoniqParser.Kunordered:
                case jsoniqParser.Ktrue:
                case jsoniqParser.Kfalse:
                case jsoniqParser.Ktype:
                case jsoniqParser.Kvalidate:
                case jsoniqParser.Kannotate:
                case jsoniqParser.Kdeclare:
                case jsoniqParser.Kcontext:
                case jsoniqParser.Kitem:
                case jsoniqParser.Kvariable:
                case jsoniqParser.Kinsert:
                case jsoniqParser.Kdelete:
                case jsoniqParser.Krename:
                case jsoniqParser.Kreplace:
                case jsoniqParser.Kcopy:
                case jsoniqParser.Kmodify:
                case jsoniqParser.Kappend:
                case jsoniqParser.Kinto:
                case jsoniqParser.Kvalue:
                case jsoniqParser.Kwith:
                case jsoniqParser.Kposition:
                case jsoniqParser.Kjson:
                case jsoniqParser.Kupdating:
                case jsoniqParser.Kcreate:
                case jsoniqParser.Kcollection:
                case jsoniqParser.Ktable:
                case jsoniqParser.Kdeltafile:
                case jsoniqParser.Kicebergtable:
                case jsoniqParser.Ktruncate:
                case jsoniqParser.Kfirst:
                case jsoniqParser.Klast:
                case jsoniqParser.Kfrom:
                case jsoniqParser.Kedit:
                case jsoniqParser.Kafter:
                case jsoniqParser.Kbefore:
                case jsoniqParser.Kimport:
                case jsoniqParser.Kschema:
                case jsoniqParser.Knamespace:
                case jsoniqParser.Kelement:
                case jsoniqParser.Kslash:
                case jsoniqParser.Kdslash:
                case jsoniqParser.Kat_symbol:
                case jsoniqParser.Kchild:
                case jsoniqParser.Kdescendant:
                case jsoniqParser.Kattribute:
                case jsoniqParser.Kself:
                case jsoniqParser.Kdescendant_or_self:
                case jsoniqParser.Kfollowing_sibling:
                case jsoniqParser.Kfollowing:
                case jsoniqParser.Kparent:
                case jsoniqParser.Kancestor:
                case jsoniqParser.Kpreceding_sibling:
                case jsoniqParser.Kpreceding:
                case jsoniqParser.Kancestor_or_self:
                case jsoniqParser.Knode:
                case jsoniqParser.Kbinary:
                case jsoniqParser.Kdocument:
                case jsoniqParser.Kdocument_node:
                case jsoniqParser.Ktext:
                case jsoniqParser.Kpi:
                case jsoniqParser.Knamespace_node:
                case jsoniqParser.Kschema_attribute:
                case jsoniqParser.Kschema_element:
                case jsoniqParser.Karray_node:
                case jsoniqParser.Kboolean_node:
                case jsoniqParser.Knull_node:
                case jsoniqParser.Knumber_node:
                case jsoniqParser.Kobject_node:
                case jsoniqParser.Kcomment:
                case jsoniqParser.Kbreak:
                case jsoniqParser.Kloop:
                case jsoniqParser.Kcontinue:
                case jsoniqParser.Kexit:
                case jsoniqParser.Kreturning:
                case jsoniqParser.Kwhile:
                case jsoniqParser.NullLiteral:
                case jsoniqParser.NCName:
                    {
                    this.state = 1025;
                    localContext._qname = this.qname();
                    localContext._errors.push(localContext._qname!);
                    }
                    break;
                default:
                    throw new antlr.NoViableAltException(this);
                }
                }
                }
                this.state = 1032;
                this.errorHandler.sync(this);
                _la = this.tokenStream.LA(1);
            }
            this.state = 1033;
            this.match(jsoniqParser.Klbrace);
            this.state = 1034;
            localContext._catch_expression = this.expr();
            this.state = 1035;
            this.match(jsoniqParser.Krbrace);
            }
        }
        catch (re) {
            if (re instanceof antlr.RecognitionException) {
                this.errorHandler.reportError(this, re);
                this.errorHandler.recover(this, re);
            } else {
                throw re;
            }
        }
        finally {
            this.exitRule();
        }
        return localContext;
    }
    public orExpr(): OrExprContext {
        let localContext = new OrExprContext(this.context, this.state);
        this.enterRule(localContext, 140, jsoniqParser.RULE_orExpr);
        let _la: number;
        try {
            this.enterOuterAlt(localContext, 1);
            {
            this.state = 1037;
            localContext._main_expr = this.andExpr();
            this.state = 1042;
            this.errorHandler.sync(this);
            _la = this.tokenStream.LA(1);
            while (_la === 91) {
                {
                {
                this.state = 1038;
                this.match(jsoniqParser.Kor);
                this.state = 1039;
                localContext._andExpr = this.andExpr();
                localContext._rhs.push(localContext._andExpr!);
                }
                }
                this.state = 1044;
                this.errorHandler.sync(this);
                _la = this.tokenStream.LA(1);
            }
            }
        }
        catch (re) {
            if (re instanceof antlr.RecognitionException) {
                this.errorHandler.reportError(this, re);
                this.errorHandler.recover(this, re);
            } else {
                throw re;
            }
        }
        finally {
            this.exitRule();
        }
        return localContext;
    }
    public andExpr(): AndExprContext {
        let localContext = new AndExprContext(this.context, this.state);
        this.enterRule(localContext, 142, jsoniqParser.RULE_andExpr);
        let _la: number;
        try {
            this.enterOuterAlt(localContext, 1);
            {
            this.state = 1045;
            localContext._main_expr = this.notExpr();
            this.state = 1050;
            this.errorHandler.sync(this);
            _la = this.tokenStream.LA(1);
            while (_la === 92) {
                {
                {
                this.state = 1046;
                this.match(jsoniqParser.Kand);
                this.state = 1047;
                localContext._notExpr = this.notExpr();
                localContext._rhs.push(localContext._notExpr!);
                }
                }
                this.state = 1052;
                this.errorHandler.sync(this);
                _la = this.tokenStream.LA(1);
            }
            }
        }
        catch (re) {
            if (re instanceof antlr.RecognitionException) {
                this.errorHandler.reportError(this, re);
                this.errorHandler.recover(this, re);
            } else {
                throw re;
            }
        }
        finally {
            this.exitRule();
        }
        return localContext;
    }
    public notExpr(): NotExprContext {
        let localContext = new NotExprContext(this.context, this.state);
        this.enterRule(localContext, 144, jsoniqParser.RULE_notExpr);
        try {
            this.enterOuterAlt(localContext, 1);
            {
            this.state = 1054;
            this.errorHandler.sync(this);
            switch (this.interpreter.adaptivePredict(this.tokenStream, 88, this.context) ) {
            case 1:
                {
                this.state = 1053;
                localContext._Knot = this.match(jsoniqParser.Knot);
                localContext._op.push(localContext._Knot!);
                }
                break;
            }
            this.state = 1056;
            localContext._main_expr = this.comparisonExpr();
            }
        }
        catch (re) {
            if (re instanceof antlr.RecognitionException) {
                this.errorHandler.reportError(this, re);
                this.errorHandler.recover(this, re);
            } else {
                throw re;
            }
        }
        finally {
            this.exitRule();
        }
        return localContext;
    }
    public comparisonExpr(): ComparisonExprContext {
        let localContext = new ComparisonExprContext(this.context, this.state);
        this.enterRule(localContext, 146, jsoniqParser.RULE_comparisonExpr);
        let _la: number;
        try {
            this.enterOuterAlt(localContext, 1);
            {
            this.state = 1058;
            localContext._main_expr = this.stringConcatExpr();
            this.state = 1061;
            this.errorHandler.sync(this);
            _la = this.tokenStream.LA(1);
            if (_la === 3 || ((((_la - 34)) & ~0x1F) === 0 && ((1 << (_la - 34)) & 2047) !== 0)) {
                {
                this.state = 1059;
                localContext.__tset1877 = this.tokenStream.LT(1);
                _la = this.tokenStream.LA(1);
                if(!(_la === 3 || ((((_la - 34)) & ~0x1F) === 0 && ((1 << (_la - 34)) & 2047) !== 0))) {
                    localContext.__tset1877 = this.errorHandler.recoverInline(this);
                }
                else {
                    this.errorHandler.reportMatch(this);
                    this.consume();
                }
                localContext._op.push(localContext.__tset1877!);
                this.state = 1060;
                localContext._stringConcatExpr = this.stringConcatExpr();
                localContext._rhs.push(localContext._stringConcatExpr!);
                }
            }

            }
        }
        catch (re) {
            if (re instanceof antlr.RecognitionException) {
                this.errorHandler.reportError(this, re);
                this.errorHandler.recover(this, re);
            } else {
                throw re;
            }
        }
        finally {
            this.exitRule();
        }
        return localContext;
    }
    public stringConcatExpr(): StringConcatExprContext {
        let localContext = new StringConcatExprContext(this.context, this.state);
        this.enterRule(localContext, 148, jsoniqParser.RULE_stringConcatExpr);
        let _la: number;
        try {
            this.enterOuterAlt(localContext, 1);
            {
            this.state = 1063;
            localContext._main_expr = this.rangeExpr();
            this.state = 1068;
            this.errorHandler.sync(this);
            _la = this.tokenStream.LA(1);
            while (_la === 45) {
                {
                {
                this.state = 1064;
                this.match(jsoniqParser.Kconcat);
                this.state = 1065;
                localContext._rangeExpr = this.rangeExpr();
                localContext._rhs.push(localContext._rangeExpr!);
                }
                }
                this.state = 1070;
                this.errorHandler.sync(this);
                _la = this.tokenStream.LA(1);
            }
            }
        }
        catch (re) {
            if (re instanceof antlr.RecognitionException) {
                this.errorHandler.reportError(this, re);
                this.errorHandler.recover(this, re);
            } else {
                throw re;
            }
        }
        finally {
            this.exitRule();
        }
        return localContext;
    }
    public rangeExpr(): RangeExprContext {
        let localContext = new RangeExprContext(this.context, this.state);
        this.enterRule(localContext, 150, jsoniqParser.RULE_rangeExpr);
        let _la: number;
        try {
            this.enterOuterAlt(localContext, 1);
            {
            this.state = 1071;
            localContext._main_expr = this.additiveExpr();
            this.state = 1074;
            this.errorHandler.sync(this);
            _la = this.tokenStream.LA(1);
            if (_la === 94) {
                {
                this.state = 1072;
                this.match(jsoniqParser.Kto);
                this.state = 1073;
                localContext._additiveExpr = this.additiveExpr();
                localContext._rhs.push(localContext._additiveExpr!);
                }
            }

            }
        }
        catch (re) {
            if (re instanceof antlr.RecognitionException) {
                this.errorHandler.reportError(this, re);
                this.errorHandler.recover(this, re);
            } else {
                throw re;
            }
        }
        finally {
            this.exitRule();
        }
        return localContext;
    }
    public additiveExpr(): AdditiveExprContext {
        let localContext = new AdditiveExprContext(this.context, this.state);
        this.enterRule(localContext, 152, jsoniqParser.RULE_additiveExpr);
        let _la: number;
        try {
            this.enterOuterAlt(localContext, 1);
            {
            this.state = 1076;
            localContext._main_expr = this.multiplicativeExpr();
            this.state = 1081;
            this.errorHandler.sync(this);
            _la = this.tokenStream.LA(1);
            while (_la === 46 || _la === 47) {
                {
                {
                this.state = 1077;
                localContext.__tset1986 = this.tokenStream.LT(1);
                _la = this.tokenStream.LA(1);
                if(!(_la === 46 || _la === 47)) {
                    localContext.__tset1986 = this.errorHandler.recoverInline(this);
                }
                else {
                    this.errorHandler.reportMatch(this);
                    this.consume();
                }
                localContext._op.push(localContext.__tset1986!);
                this.state = 1078;
                localContext._multiplicativeExpr = this.multiplicativeExpr();
                localContext._rhs.push(localContext._multiplicativeExpr!);
                }
                }
                this.state = 1083;
                this.errorHandler.sync(this);
                _la = this.tokenStream.LA(1);
            }
            }
        }
        catch (re) {
            if (re instanceof antlr.RecognitionException) {
                this.errorHandler.reportError(this, re);
                this.errorHandler.recover(this, re);
            } else {
                throw re;
            }
        }
        finally {
            this.exitRule();
        }
        return localContext;
    }
    public multiplicativeExpr(): MultiplicativeExprContext {
        let localContext = new MultiplicativeExprContext(this.context, this.state);
        this.enterRule(localContext, 154, jsoniqParser.RULE_multiplicativeExpr);
        let _la: number;
        try {
            this.enterOuterAlt(localContext, 1);
            {
            this.state = 1084;
            localContext._main_expr = this.instanceOfExpr();
            this.state = 1089;
            this.errorHandler.sync(this);
            _la = this.tokenStream.LA(1);
            while (_la === 10 || ((((_la - 48)) & ~0x1F) === 0 && ((1 << (_la - 48)) & 7) !== 0)) {
                {
                {
                this.state = 1085;
                localContext.__tset2014 = this.tokenStream.LT(1);
                _la = this.tokenStream.LA(1);
                if(!(_la === 10 || ((((_la - 48)) & ~0x1F) === 0 && ((1 << (_la - 48)) & 7) !== 0))) {
                    localContext.__tset2014 = this.errorHandler.recoverInline(this);
                }
                else {
                    this.errorHandler.reportMatch(this);
                    this.consume();
                }
                localContext._op.push(localContext.__tset2014!);
                this.state = 1086;
                localContext._instanceOfExpr = this.instanceOfExpr();
                localContext._rhs.push(localContext._instanceOfExpr!);
                }
                }
                this.state = 1091;
                this.errorHandler.sync(this);
                _la = this.tokenStream.LA(1);
            }
            }
        }
        catch (re) {
            if (re instanceof antlr.RecognitionException) {
                this.errorHandler.reportError(this, re);
                this.errorHandler.recover(this, re);
            } else {
                throw re;
            }
        }
        finally {
            this.exitRule();
        }
        return localContext;
    }
    public instanceOfExpr(): InstanceOfExprContext {
        let localContext = new InstanceOfExprContext(this.context, this.state);
        this.enterRule(localContext, 156, jsoniqParser.RULE_instanceOfExpr);
        let _la: number;
        try {
            this.enterOuterAlt(localContext, 1);
            {
            this.state = 1092;
            localContext._main_expr = this.isStaticallyExpr();
            this.state = 1096;
            this.errorHandler.sync(this);
            _la = this.tokenStream.LA(1);
            if (_la === 95) {
                {
                this.state = 1093;
                this.match(jsoniqParser.Kinstance);
                this.state = 1094;
                this.match(jsoniqParser.Kof);
                this.state = 1095;
                localContext._seq = this.sequenceType();
                }
            }

            }
        }
        catch (re) {
            if (re instanceof antlr.RecognitionException) {
                this.errorHandler.reportError(this, re);
                this.errorHandler.recover(this, re);
            } else {
                throw re;
            }
        }
        finally {
            this.exitRule();
        }
        return localContext;
    }
    public isStaticallyExpr(): IsStaticallyExprContext {
        let localContext = new IsStaticallyExprContext(this.context, this.state);
        this.enterRule(localContext, 158, jsoniqParser.RULE_isStaticallyExpr);
        let _la: number;
        try {
            this.enterOuterAlt(localContext, 1);
            {
            this.state = 1098;
            localContext._main_expr = this.treatExpr();
            this.state = 1102;
            this.errorHandler.sync(this);
            _la = this.tokenStream.LA(1);
            if (_la === 98) {
                {
                this.state = 1099;
                this.match(jsoniqParser.Kis);
                this.state = 1100;
                this.match(jsoniqParser.Kstatically);
                this.state = 1101;
                localContext._seq = this.sequenceType();
                }
            }

            }
        }
        catch (re) {
            if (re instanceof antlr.RecognitionException) {
                this.errorHandler.reportError(this, re);
                this.errorHandler.recover(this, re);
            } else {
                throw re;
            }
        }
        finally {
            this.exitRule();
        }
        return localContext;
    }
    public treatExpr(): TreatExprContext {
        let localContext = new TreatExprContext(this.context, this.state);
        this.enterRule(localContext, 160, jsoniqParser.RULE_treatExpr);
        let _la: number;
        try {
            this.enterOuterAlt(localContext, 1);
            {
            this.state = 1104;
            localContext._main_expr = this.castableExpr();
            this.state = 1108;
            this.errorHandler.sync(this);
            _la = this.tokenStream.LA(1);
            if (_la === 99) {
                {
                this.state = 1105;
                this.match(jsoniqParser.Ktreat);
                this.state = 1106;
                this.match(jsoniqParser.Kas);
                this.state = 1107;
                localContext._seq = this.sequenceType();
                }
            }

            }
        }
        catch (re) {
            if (re instanceof antlr.RecognitionException) {
                this.errorHandler.reportError(this, re);
                this.errorHandler.recover(this, re);
            } else {
                throw re;
            }
        }
        finally {
            this.exitRule();
        }
        return localContext;
    }
    public castableExpr(): CastableExprContext {
        let localContext = new CastableExprContext(this.context, this.state);
        this.enterRule(localContext, 162, jsoniqParser.RULE_castableExpr);
        let _la: number;
        try {
            this.enterOuterAlt(localContext, 1);
            {
            this.state = 1110;
            localContext._main_expr = this.castExpr();
            this.state = 1114;
            this.errorHandler.sync(this);
            _la = this.tokenStream.LA(1);
            if (_la === 101) {
                {
                this.state = 1111;
                this.match(jsoniqParser.Kcastable);
                this.state = 1112;
                this.match(jsoniqParser.Kas);
                this.state = 1113;
                localContext._single = this.singleType();
                }
            }

            }
        }
        catch (re) {
            if (re instanceof antlr.RecognitionException) {
                this.errorHandler.reportError(this, re);
                this.errorHandler.recover(this, re);
            } else {
                throw re;
            }
        }
        finally {
            this.exitRule();
        }
        return localContext;
    }
    public castExpr(): CastExprContext {
        let localContext = new CastExprContext(this.context, this.state);
        this.enterRule(localContext, 164, jsoniqParser.RULE_castExpr);
        let _la: number;
        try {
            this.enterOuterAlt(localContext, 1);
            {
            this.state = 1116;
            localContext._main_expr = this.arrowExpr();
            this.state = 1120;
            this.errorHandler.sync(this);
            _la = this.tokenStream.LA(1);
            if (_la === 100) {
                {
                this.state = 1117;
                this.match(jsoniqParser.Kcast);
                this.state = 1118;
                this.match(jsoniqParser.Kas);
                this.state = 1119;
                localContext._single = this.singleType();
                }
            }

            }
        }
        catch (re) {
            if (re instanceof antlr.RecognitionException) {
                this.errorHandler.reportError(this, re);
                this.errorHandler.recover(this, re);
            } else {
                throw re;
            }
        }
        finally {
            this.exitRule();
        }
        return localContext;
    }
    public arrowExpr(): ArrowExprContext {
        let localContext = new ArrowExprContext(this.context, this.state);
        this.enterRule(localContext, 166, jsoniqParser.RULE_arrowExpr);
        try {
            let alternative: number;
            this.enterOuterAlt(localContext, 1);
            {
            this.state = 1122;
            localContext._main_expr = this.unaryExpr();
            this.state = 1131;
            this.errorHandler.sync(this);
            alternative = this.interpreter.adaptivePredict(this.tokenStream, 99, this.context);
            while (alternative !== 2 && alternative !== antlr.ATN.INVALID_ALT_NUMBER) {
                if (alternative === 1) {
                    {
                    {
                    {
                    this.state = 1123;
                    this.match(jsoniqParser.Kequal);
                    this.state = 1124;
                    this.match(jsoniqParser.Kgreater);
                    }
                    this.state = 1126;
                    localContext._arrowFunctionSpecifier = this.arrowFunctionSpecifier();
                    localContext._function_.push(localContext._arrowFunctionSpecifier!);
                    this.state = 1127;
                    localContext._argumentList = this.argumentList();
                    localContext._arguments.push(localContext._argumentList!);
                    }
                    }
                }
                this.state = 1133;
                this.errorHandler.sync(this);
                alternative = this.interpreter.adaptivePredict(this.tokenStream, 99, this.context);
            }
            }
        }
        catch (re) {
            if (re instanceof antlr.RecognitionException) {
                this.errorHandler.reportError(this, re);
                this.errorHandler.recover(this, re);
            } else {
                throw re;
            }
        }
        finally {
            this.exitRule();
        }
        return localContext;
    }
    public arrowFunctionSpecifier(): ArrowFunctionSpecifierContext {
        let localContext = new ArrowFunctionSpecifierContext(this.context, this.state);
        this.enterRule(localContext, 168, jsoniqParser.RULE_arrowFunctionSpecifier);
        try {
            this.state = 1137;
            this.errorHandler.sync(this);
            switch (this.tokenStream.LA(1)) {
            case jsoniqParser.Kfor:
            case jsoniqParser.Klet:
            case jsoniqParser.Kwhere:
            case jsoniqParser.Kgroup:
            case jsoniqParser.Kby:
            case jsoniqParser.Korder:
            case jsoniqParser.Kreturn:
            case jsoniqParser.Kif:
            case jsoniqParser.Kin:
            case jsoniqParser.Kas:
            case jsoniqParser.Kat:
            case jsoniqParser.Kallowing:
            case jsoniqParser.Kempty:
            case jsoniqParser.Kcount:
            case jsoniqParser.Kstable:
            case jsoniqParser.Kascending:
            case jsoniqParser.Kdescending:
            case jsoniqParser.Ksome:
            case jsoniqParser.Kevery:
            case jsoniqParser.Ksatisfies:
            case jsoniqParser.Kcollation:
            case jsoniqParser.Kgreatest:
            case jsoniqParser.Kleast:
            case jsoniqParser.Kswitch:
            case jsoniqParser.Kcase:
            case jsoniqParser.Ktry:
            case jsoniqParser.Kcatch:
            case jsoniqParser.Kdefault:
            case jsoniqParser.Kthen:
            case jsoniqParser.Kelse:
            case jsoniqParser.Ktypeswitch:
            case jsoniqParser.Kor:
            case jsoniqParser.Kand:
            case jsoniqParser.Knot:
            case jsoniqParser.Kto:
            case jsoniqParser.Kinstance:
            case jsoniqParser.Kof:
            case jsoniqParser.Kstatically:
            case jsoniqParser.Kis:
            case jsoniqParser.Ktreat:
            case jsoniqParser.Kcast:
            case jsoniqParser.Kcastable:
            case jsoniqParser.Kversion:
            case jsoniqParser.Kjsoniq:
            case jsoniqParser.Kunordered:
            case jsoniqParser.Ktrue:
            case jsoniqParser.Kfalse:
            case jsoniqParser.Ktype:
            case jsoniqParser.Kvalidate:
            case jsoniqParser.Kannotate:
            case jsoniqParser.Kdeclare:
            case jsoniqParser.Kcontext:
            case jsoniqParser.Kitem:
            case jsoniqParser.Kvariable:
            case jsoniqParser.Kinsert:
            case jsoniqParser.Kdelete:
            case jsoniqParser.Krename:
            case jsoniqParser.Kreplace:
            case jsoniqParser.Kcopy:
            case jsoniqParser.Kmodify:
            case jsoniqParser.Kappend:
            case jsoniqParser.Kinto:
            case jsoniqParser.Kvalue:
            case jsoniqParser.Kwith:
            case jsoniqParser.Kposition:
            case jsoniqParser.Kjson:
            case jsoniqParser.Kupdating:
            case jsoniqParser.Kcreate:
            case jsoniqParser.Kcollection:
            case jsoniqParser.Ktable:
            case jsoniqParser.Kdeltafile:
            case jsoniqParser.Kicebergtable:
            case jsoniqParser.Ktruncate:
            case jsoniqParser.Kfirst:
            case jsoniqParser.Klast:
            case jsoniqParser.Kfrom:
            case jsoniqParser.Kedit:
            case jsoniqParser.Kafter:
            case jsoniqParser.Kbefore:
            case jsoniqParser.Kimport:
            case jsoniqParser.Kschema:
            case jsoniqParser.Knamespace:
            case jsoniqParser.Kelement:
            case jsoniqParser.Kslash:
            case jsoniqParser.Kdslash:
            case jsoniqParser.Kat_symbol:
            case jsoniqParser.Kchild:
            case jsoniqParser.Kdescendant:
            case jsoniqParser.Kattribute:
            case jsoniqParser.Kself:
            case jsoniqParser.Kdescendant_or_self:
            case jsoniqParser.Kfollowing_sibling:
            case jsoniqParser.Kfollowing:
            case jsoniqParser.Kparent:
            case jsoniqParser.Kancestor:
            case jsoniqParser.Kpreceding_sibling:
            case jsoniqParser.Kpreceding:
            case jsoniqParser.Kancestor_or_self:
            case jsoniqParser.Knode:
            case jsoniqParser.Kbinary:
            case jsoniqParser.Kdocument:
            case jsoniqParser.Kdocument_node:
            case jsoniqParser.Ktext:
            case jsoniqParser.Kpi:
            case jsoniqParser.Knamespace_node:
            case jsoniqParser.Kschema_attribute:
            case jsoniqParser.Kschema_element:
            case jsoniqParser.Karray_node:
            case jsoniqParser.Kboolean_node:
            case jsoniqParser.Knull_node:
            case jsoniqParser.Knumber_node:
            case jsoniqParser.Kobject_node:
            case jsoniqParser.Kcomment:
            case jsoniqParser.Kbreak:
            case jsoniqParser.Kloop:
            case jsoniqParser.Kcontinue:
            case jsoniqParser.Kexit:
            case jsoniqParser.Kreturning:
            case jsoniqParser.Kwhile:
            case jsoniqParser.NullLiteral:
            case jsoniqParser.NCName:
                this.enterOuterAlt(localContext, 1);
                {
                this.state = 1134;
                this.qname();
                }
                break;
            case jsoniqParser.Kdollar:
                this.enterOuterAlt(localContext, 2);
                {
                this.state = 1135;
                this.varRef();
                }
                break;
            case jsoniqParser.Klparen:
                this.enterOuterAlt(localContext, 3);
                {
                this.state = 1136;
                this.parenthesizedExpr();
                }
                break;
            default:
                throw new antlr.NoViableAltException(this);
            }
        }
        catch (re) {
            if (re instanceof antlr.RecognitionException) {
                this.errorHandler.reportError(this, re);
                this.errorHandler.recover(this, re);
            } else {
                throw re;
            }
        }
        finally {
            this.exitRule();
        }
        return localContext;
    }
    public unaryExpr(): UnaryExprContext {
        let localContext = new UnaryExprContext(this.context, this.state);
        this.enterRule(localContext, 170, jsoniqParser.RULE_unaryExpr);
        let _la: number;
        try {
            this.enterOuterAlt(localContext, 1);
            {
            this.state = 1142;
            this.errorHandler.sync(this);
            _la = this.tokenStream.LA(1);
            while (_la === 46 || _la === 47) {
                {
                {
                this.state = 1139;
                localContext.__tset2193 = this.tokenStream.LT(1);
                _la = this.tokenStream.LA(1);
                if(!(_la === 46 || _la === 47)) {
                    localContext.__tset2193 = this.errorHandler.recoverInline(this);
                }
                else {
                    this.errorHandler.reportMatch(this);
                    this.consume();
                }
                localContext._op.push(localContext.__tset2193!);
                }
                }
                this.state = 1144;
                this.errorHandler.sync(this);
                _la = this.tokenStream.LA(1);
            }
            this.state = 1145;
            localContext._main_expr = this.valueExpr();
            }
        }
        catch (re) {
            if (re instanceof antlr.RecognitionException) {
                this.errorHandler.reportError(this, re);
                this.errorHandler.recover(this, re);
            } else {
                throw re;
            }
        }
        finally {
            this.exitRule();
        }
        return localContext;
    }
    public valueExpr(): ValueExprContext {
        let localContext = new ValueExprContext(this.context, this.state);
        this.enterRule(localContext, 172, jsoniqParser.RULE_valueExpr);
        try {
            this.state = 1150;
            this.errorHandler.sync(this);
            switch (this.interpreter.adaptivePredict(this.tokenStream, 102, this.context) ) {
            case 1:
                this.enterOuterAlt(localContext, 1);
                {
                this.state = 1147;
                localContext._simpleMap_expr = this.simpleMapExpr();
                }
                break;
            case 2:
                this.enterOuterAlt(localContext, 2);
                {
                this.state = 1148;
                localContext._validate_expr = this.validateExpr();
                }
                break;
            case 3:
                this.enterOuterAlt(localContext, 3);
                {
                this.state = 1149;
                localContext._annotate_expr = this.annotateExpr();
                }
                break;
            }
        }
        catch (re) {
            if (re instanceof antlr.RecognitionException) {
                this.errorHandler.reportError(this, re);
                this.errorHandler.recover(this, re);
            } else {
                throw re;
            }
        }
        finally {
            this.exitRule();
        }
        return localContext;
    }
    public validateExpr(): ValidateExprContext {
        let localContext = new ValidateExprContext(this.context, this.state);
        this.enterRule(localContext, 174, jsoniqParser.RULE_validateExpr);
        try {
            this.enterOuterAlt(localContext, 1);
            {
            this.state = 1152;
            this.match(jsoniqParser.Kvalidate);
            this.state = 1153;
            this.match(jsoniqParser.Ktype);
            this.state = 1154;
            this.sequenceType();
            this.state = 1155;
            this.match(jsoniqParser.Klbrace);
            this.state = 1156;
            this.expr();
            this.state = 1157;
            this.match(jsoniqParser.Krbrace);
            }
        }
        catch (re) {
            if (re instanceof antlr.RecognitionException) {
                this.errorHandler.reportError(this, re);
                this.errorHandler.recover(this, re);
            } else {
                throw re;
            }
        }
        finally {
            this.exitRule();
        }
        return localContext;
    }
    public annotateExpr(): AnnotateExprContext {
        let localContext = new AnnotateExprContext(this.context, this.state);
        this.enterRule(localContext, 176, jsoniqParser.RULE_annotateExpr);
        try {
            this.enterOuterAlt(localContext, 1);
            {
            this.state = 1159;
            this.match(jsoniqParser.Kannotate);
            this.state = 1160;
            this.match(jsoniqParser.Ktype);
            this.state = 1161;
            this.sequenceType();
            this.state = 1162;
            this.match(jsoniqParser.Klbrace);
            this.state = 1163;
            this.expr();
            this.state = 1164;
            this.match(jsoniqParser.Krbrace);
            }
        }
        catch (re) {
            if (re instanceof antlr.RecognitionException) {
                this.errorHandler.reportError(this, re);
                this.errorHandler.recover(this, re);
            } else {
                throw re;
            }
        }
        finally {
            this.exitRule();
        }
        return localContext;
    }
    public simpleMapExpr(): SimpleMapExprContext {
        let localContext = new SimpleMapExprContext(this.context, this.state);
        this.enterRule(localContext, 178, jsoniqParser.RULE_simpleMapExpr);
        let _la: number;
        try {
            this.enterOuterAlt(localContext, 1);
            {
            this.state = 1166;
            localContext._main_expr = this.pathExpr();
            this.state = 1171;
            this.errorHandler.sync(this);
            _la = this.tokenStream.LA(1);
            while (_la === 51) {
                {
                {
                this.state = 1167;
                this.match(jsoniqParser.Kbang);
                this.state = 1168;
                localContext._pathExpr = this.pathExpr();
                localContext._map_expr.push(localContext._pathExpr!);
                }
                }
                this.state = 1173;
                this.errorHandler.sync(this);
                _la = this.tokenStream.LA(1);
            }
            }
        }
        catch (re) {
            if (re instanceof antlr.RecognitionException) {
                this.errorHandler.reportError(this, re);
                this.errorHandler.recover(this, re);
            } else {
                throw re;
            }
        }
        finally {
            this.exitRule();
        }
        return localContext;
    }
    public postFixExpr(): PostFixExprContext {
        let localContext = new PostFixExprContext(this.context, this.state);
        this.enterRule(localContext, 180, jsoniqParser.RULE_postFixExpr);
        let _la: number;
        try {
            this.enterOuterAlt(localContext, 1);
            {
            this.state = 1174;
            localContext._main_expr = this.primaryExpr();
            this.state = 1182;
            this.errorHandler.sync(this);
            _la = this.tokenStream.LA(1);
            while (_la === 8 || _la === 52 || _la === 54) {
                {
                this.state = 1180;
                this.errorHandler.sync(this);
                switch (this.interpreter.adaptivePredict(this.tokenStream, 104, this.context) ) {
                case 1:
                    {
                    this.state = 1175;
                    this.arrayLookup();
                    }
                    break;
                case 2:
                    {
                    this.state = 1176;
                    this.predicate();
                    }
                    break;
                case 3:
                    {
                    this.state = 1177;
                    this.objectLookup();
                    }
                    break;
                case 4:
                    {
                    this.state = 1178;
                    this.arrayUnboxing();
                    }
                    break;
                case 5:
                    {
                    this.state = 1179;
                    this.argumentList();
                    }
                    break;
                }
                }
                this.state = 1184;
                this.errorHandler.sync(this);
                _la = this.tokenStream.LA(1);
            }
            }
        }
        catch (re) {
            if (re instanceof antlr.RecognitionException) {
                this.errorHandler.reportError(this, re);
                this.errorHandler.recover(this, re);
            } else {
                throw re;
            }
        }
        finally {
            this.exitRule();
        }
        return localContext;
    }
    public arrayLookup(): ArrayLookupContext {
        let localContext = new ArrayLookupContext(this.context, this.state);
        this.enterRule(localContext, 182, jsoniqParser.RULE_arrayLookup);
        try {
            this.enterOuterAlt(localContext, 1);
            {
            this.state = 1185;
            this.match(jsoniqParser.Klbracket);
            this.state = 1186;
            this.match(jsoniqParser.Klbracket);
            this.state = 1187;
            this.expr();
            this.state = 1188;
            this.match(jsoniqParser.Krbracket);
            this.state = 1189;
            this.match(jsoniqParser.Krbracket);
            }
        }
        catch (re) {
            if (re instanceof antlr.RecognitionException) {
                this.errorHandler.reportError(this, re);
                this.errorHandler.recover(this, re);
            } else {
                throw re;
            }
        }
        finally {
            this.exitRule();
        }
        return localContext;
    }
    public arrayUnboxing(): ArrayUnboxingContext {
        let localContext = new ArrayUnboxingContext(this.context, this.state);
        this.enterRule(localContext, 184, jsoniqParser.RULE_arrayUnboxing);
        try {
            this.enterOuterAlt(localContext, 1);
            {
            this.state = 1191;
            this.match(jsoniqParser.Klbracket);
            this.state = 1192;
            this.match(jsoniqParser.Krbracket);
            }
        }
        catch (re) {
            if (re instanceof antlr.RecognitionException) {
                this.errorHandler.reportError(this, re);
                this.errorHandler.recover(this, re);
            } else {
                throw re;
            }
        }
        finally {
            this.exitRule();
        }
        return localContext;
    }
    public predicate(): PredicateContext {
        let localContext = new PredicateContext(this.context, this.state);
        this.enterRule(localContext, 186, jsoniqParser.RULE_predicate);
        try {
            this.enterOuterAlt(localContext, 1);
            {
            this.state = 1194;
            this.match(jsoniqParser.Klbracket);
            this.state = 1195;
            this.expr();
            this.state = 1196;
            this.match(jsoniqParser.Krbracket);
            }
        }
        catch (re) {
            if (re instanceof antlr.RecognitionException) {
                this.errorHandler.reportError(this, re);
                this.errorHandler.recover(this, re);
            } else {
                throw re;
            }
        }
        finally {
            this.exitRule();
        }
        return localContext;
    }
    public objectLookup(): ObjectLookupContext {
        let localContext = new ObjectLookupContext(this.context, this.state);
        this.enterRule(localContext, 188, jsoniqParser.RULE_objectLookup);
        try {
            this.enterOuterAlt(localContext, 1);
            {
            this.state = 1198;
            this.match(jsoniqParser.Kdot);
            this.state = 1205;
            this.errorHandler.sync(this);
            switch (this.tokenStream.LA(1)) {
            case jsoniqParser.Kfor:
            case jsoniqParser.Klet:
            case jsoniqParser.Kwhere:
            case jsoniqParser.Kgroup:
            case jsoniqParser.Kby:
            case jsoniqParser.Korder:
            case jsoniqParser.Kreturn:
            case jsoniqParser.Kif:
            case jsoniqParser.Kin:
            case jsoniqParser.Kas:
            case jsoniqParser.Kat:
            case jsoniqParser.Kallowing:
            case jsoniqParser.Kempty:
            case jsoniqParser.Kcount:
            case jsoniqParser.Kstable:
            case jsoniqParser.Kascending:
            case jsoniqParser.Kdescending:
            case jsoniqParser.Ksome:
            case jsoniqParser.Kevery:
            case jsoniqParser.Ksatisfies:
            case jsoniqParser.Kcollation:
            case jsoniqParser.Kgreatest:
            case jsoniqParser.Kleast:
            case jsoniqParser.Kswitch:
            case jsoniqParser.Kcase:
            case jsoniqParser.Ktry:
            case jsoniqParser.Kcatch:
            case jsoniqParser.Kdefault:
            case jsoniqParser.Kthen:
            case jsoniqParser.Kelse:
            case jsoniqParser.Ktypeswitch:
            case jsoniqParser.Kor:
            case jsoniqParser.Kand:
            case jsoniqParser.Knot:
            case jsoniqParser.Kto:
            case jsoniqParser.Kinstance:
            case jsoniqParser.Kof:
            case jsoniqParser.Kstatically:
            case jsoniqParser.Kis:
            case jsoniqParser.Ktreat:
            case jsoniqParser.Kcast:
            case jsoniqParser.Kcastable:
            case jsoniqParser.Kversion:
            case jsoniqParser.Kjsoniq:
            case jsoniqParser.Kunordered:
            case jsoniqParser.Ktrue:
            case jsoniqParser.Kfalse:
            case jsoniqParser.Ktype:
            case jsoniqParser.Kvalidate:
            case jsoniqParser.Kannotate:
            case jsoniqParser.Kdeclare:
            case jsoniqParser.Kcontext:
            case jsoniqParser.Kitem:
            case jsoniqParser.Kvariable:
            case jsoniqParser.Kinsert:
            case jsoniqParser.Kdelete:
            case jsoniqParser.Krename:
            case jsoniqParser.Kreplace:
            case jsoniqParser.Kcopy:
            case jsoniqParser.Kmodify:
            case jsoniqParser.Kappend:
            case jsoniqParser.Kinto:
            case jsoniqParser.Kvalue:
            case jsoniqParser.Kwith:
            case jsoniqParser.Kposition:
            case jsoniqParser.Kjson:
            case jsoniqParser.Kupdating:
            case jsoniqParser.Kcreate:
            case jsoniqParser.Kcollection:
            case jsoniqParser.Ktable:
            case jsoniqParser.Kdeltafile:
            case jsoniqParser.Kicebergtable:
            case jsoniqParser.Ktruncate:
            case jsoniqParser.Kfirst:
            case jsoniqParser.Klast:
            case jsoniqParser.Kfrom:
            case jsoniqParser.Kedit:
            case jsoniqParser.Kafter:
            case jsoniqParser.Kbefore:
            case jsoniqParser.Kimport:
            case jsoniqParser.Kschema:
            case jsoniqParser.Knamespace:
            case jsoniqParser.Kelement:
            case jsoniqParser.Kslash:
            case jsoniqParser.Kdslash:
            case jsoniqParser.Kat_symbol:
            case jsoniqParser.Kchild:
            case jsoniqParser.Kdescendant:
            case jsoniqParser.Kattribute:
            case jsoniqParser.Kself:
            case jsoniqParser.Kdescendant_or_self:
            case jsoniqParser.Kfollowing_sibling:
            case jsoniqParser.Kfollowing:
            case jsoniqParser.Kparent:
            case jsoniqParser.Kancestor:
            case jsoniqParser.Kpreceding_sibling:
            case jsoniqParser.Kpreceding:
            case jsoniqParser.Kancestor_or_self:
            case jsoniqParser.Knode:
            case jsoniqParser.Kbinary:
            case jsoniqParser.Kdocument:
            case jsoniqParser.Kdocument_node:
            case jsoniqParser.Ktext:
            case jsoniqParser.Kpi:
            case jsoniqParser.Knamespace_node:
            case jsoniqParser.Kschema_attribute:
            case jsoniqParser.Kschema_element:
            case jsoniqParser.Karray_node:
            case jsoniqParser.Kboolean_node:
            case jsoniqParser.Knull_node:
            case jsoniqParser.Knumber_node:
            case jsoniqParser.Kobject_node:
            case jsoniqParser.Kcomment:
            case jsoniqParser.Kbreak:
            case jsoniqParser.Kloop:
            case jsoniqParser.Kcontinue:
            case jsoniqParser.Kexit:
            case jsoniqParser.Kreturning:
            case jsoniqParser.Kwhile:
            case jsoniqParser.NullLiteral:
                {
                this.state = 1199;
                localContext._kw = this.keyWords();
                }
                break;
            case jsoniqParser.STRING:
                {
                this.state = 1200;
                localContext._lt = this.stringLiteral();
                }
                break;
            case jsoniqParser.NCName:
                {
                this.state = 1201;
                localContext._nc = this.match(jsoniqParser.NCName);
                }
                break;
            case jsoniqParser.Klparen:
                {
                this.state = 1202;
                localContext._pe = this.parenthesizedExpr();
                }
                break;
            case jsoniqParser.Kdollar:
                {
                this.state = 1203;
                localContext._vr = this.varRef();
                }
                break;
            case jsoniqParser.Kcontext_item:
                {
                this.state = 1204;
                localContext._ci = this.contextItemExpr();
                }
                break;
            default:
                throw new antlr.NoViableAltException(this);
            }
            }
        }
        catch (re) {
            if (re instanceof antlr.RecognitionException) {
                this.errorHandler.reportError(this, re);
                this.errorHandler.recover(this, re);
            } else {
                throw re;
            }
        }
        finally {
            this.exitRule();
        }
        return localContext;
    }
    public primaryExpr(): PrimaryExprContext {
        let localContext = new PrimaryExprContext(this.context, this.state);
        this.enterRule(localContext, 190, jsoniqParser.RULE_primaryExpr);
        try {
            this.state = 1222;
            this.errorHandler.sync(this);
            switch (this.interpreter.adaptivePredict(this.tokenStream, 107, this.context) ) {
            case 1:
                this.enterOuterAlt(localContext, 1);
                {
                this.state = 1207;
                this.match(jsoniqParser.NullLiteral);
                }
                break;
            case 2:
                this.enterOuterAlt(localContext, 2);
                {
                this.state = 1208;
                this.match(jsoniqParser.Ktrue);
                }
                break;
            case 3:
                this.enterOuterAlt(localContext, 3);
                {
                this.state = 1209;
                this.match(jsoniqParser.Kfalse);
                }
                break;
            case 4:
                this.enterOuterAlt(localContext, 4);
                {
                this.state = 1210;
                this.match(jsoniqParser.Literal);
                }
                break;
            case 5:
                this.enterOuterAlt(localContext, 5);
                {
                this.state = 1211;
                this.stringLiteral();
                }
                break;
            case 6:
                this.enterOuterAlt(localContext, 6);
                {
                this.state = 1212;
                this.varRef();
                }
                break;
            case 7:
                this.enterOuterAlt(localContext, 7);
                {
                this.state = 1213;
                this.parenthesizedExpr();
                }
                break;
            case 8:
                this.enterOuterAlt(localContext, 8);
                {
                this.state = 1214;
                this.contextItemExpr();
                }
                break;
            case 9:
                this.enterOuterAlt(localContext, 9);
                {
                this.state = 1215;
                this.objectConstructor();
                }
                break;
            case 10:
                this.enterOuterAlt(localContext, 10);
                {
                this.state = 1216;
                this.functionCall();
                }
                break;
            case 11:
                this.enterOuterAlt(localContext, 11);
                {
                this.state = 1217;
                this.orderedExpr();
                }
                break;
            case 12:
                this.enterOuterAlt(localContext, 12);
                {
                this.state = 1218;
                this.unorderedExpr();
                }
                break;
            case 13:
                this.enterOuterAlt(localContext, 13);
                {
                this.state = 1219;
                this.arrayConstructor();
                }
                break;
            case 14:
                this.enterOuterAlt(localContext, 14);
                {
                this.state = 1220;
                this.functionItemExpr();
                }
                break;
            case 15:
                this.enterOuterAlt(localContext, 15);
                {
                this.state = 1221;
                this.blockExpr();
                }
                break;
            }
        }
        catch (re) {
            if (re instanceof antlr.RecognitionException) {
                this.errorHandler.reportError(this, re);
                this.errorHandler.recover(this, re);
            } else {
                throw re;
            }
        }
        finally {
            this.exitRule();
        }
        return localContext;
    }
    public blockExpr(): BlockExprContext {
        let localContext = new BlockExprContext(this.context, this.state);
        this.enterRule(localContext, 192, jsoniqParser.RULE_blockExpr);
        try {
            this.enterOuterAlt(localContext, 1);
            {
            this.state = 1224;
            this.match(jsoniqParser.Klbrace);
            this.state = 1225;
            this.statementsAndExpr();
            this.state = 1226;
            this.match(jsoniqParser.Krbrace);
            }
        }
        catch (re) {
            if (re instanceof antlr.RecognitionException) {
                this.errorHandler.reportError(this, re);
                this.errorHandler.recover(this, re);
            } else {
                throw re;
            }
        }
        finally {
            this.exitRule();
        }
        return localContext;
    }
    public varRef(): VarRefContext {
        let localContext = new VarRefContext(this.context, this.state);
        this.enterRule(localContext, 194, jsoniqParser.RULE_varRef);
        try {
            this.enterOuterAlt(localContext, 1);
            {
            this.state = 1228;
            this.match(jsoniqParser.Kdollar);
            this.state = 1229;
            localContext._var_name = this.qname();
            }
        }
        catch (re) {
            if (re instanceof antlr.RecognitionException) {
                this.errorHandler.reportError(this, re);
                this.errorHandler.recover(this, re);
            } else {
                throw re;
            }
        }
        finally {
            this.exitRule();
        }
        return localContext;
    }
    public parenthesizedExpr(): ParenthesizedExprContext {
        let localContext = new ParenthesizedExprContext(this.context, this.state);
        this.enterRule(localContext, 196, jsoniqParser.RULE_parenthesizedExpr);
        let _la: number;
        try {
            this.enterOuterAlt(localContext, 1);
            {
            this.state = 1231;
            this.match(jsoniqParser.Klparen);
            this.state = 1233;
            this.errorHandler.sync(this);
            _la = this.tokenStream.LA(1);
            if ((((_la) & ~0x1F) === 0 && ((1 << _la) & 1073812816) !== 0) || ((((_la - 46)) & ~0x1F) === 0 && ((1 << (_la - 46)) & 4294957635) !== 0) || ((((_la - 78)) & ~0x1F) === 0 && ((1 << (_la - 78)) & 4294967295) !== 0) || ((((_la - 110)) & ~0x1F) === 0 && ((1 << (_la - 110)) & 4294967295) !== 0) || ((((_la - 142)) & ~0x1F) === 0 && ((1 << (_la - 142)) & 4294967295) !== 0) || ((((_la - 174)) & ~0x1F) === 0 && ((1 << (_la - 174)) & 16831) !== 0)) {
                {
                this.state = 1232;
                this.expr();
                }
            }

            this.state = 1235;
            this.match(jsoniqParser.Krparen);
            }
        }
        catch (re) {
            if (re instanceof antlr.RecognitionException) {
                this.errorHandler.reportError(this, re);
                this.errorHandler.recover(this, re);
            } else {
                throw re;
            }
        }
        finally {
            this.exitRule();
        }
        return localContext;
    }
    public contextItemExpr(): ContextItemExprContext {
        let localContext = new ContextItemExprContext(this.context, this.state);
        this.enterRule(localContext, 198, jsoniqParser.RULE_contextItemExpr);
        try {
            this.enterOuterAlt(localContext, 1);
            {
            this.state = 1237;
            this.match(jsoniqParser.Kcontext_item);
            }
        }
        catch (re) {
            if (re instanceof antlr.RecognitionException) {
                this.errorHandler.reportError(this, re);
                this.errorHandler.recover(this, re);
            } else {
                throw re;
            }
        }
        finally {
            this.exitRule();
        }
        return localContext;
    }
    public orderedExpr(): OrderedExprContext {
        let localContext = new OrderedExprContext(this.context, this.state);
        this.enterRule(localContext, 200, jsoniqParser.RULE_orderedExpr);
        try {
            this.enterOuterAlt(localContext, 1);
            {
            this.state = 1239;
            this.match(jsoniqParser.Kordered);
            this.state = 1240;
            this.match(jsoniqParser.Klbrace);
            this.state = 1241;
            this.expr();
            this.state = 1242;
            this.match(jsoniqParser.Krbrace);
            }
        }
        catch (re) {
            if (re instanceof antlr.RecognitionException) {
                this.errorHandler.reportError(this, re);
                this.errorHandler.recover(this, re);
            } else {
                throw re;
            }
        }
        finally {
            this.exitRule();
        }
        return localContext;
    }
    public unorderedExpr(): UnorderedExprContext {
        let localContext = new UnorderedExprContext(this.context, this.state);
        this.enterRule(localContext, 202, jsoniqParser.RULE_unorderedExpr);
        try {
            this.enterOuterAlt(localContext, 1);
            {
            this.state = 1244;
            this.match(jsoniqParser.Kunordered);
            this.state = 1245;
            this.match(jsoniqParser.Klbrace);
            this.state = 1246;
            this.expr();
            this.state = 1247;
            this.match(jsoniqParser.Krbrace);
            }
        }
        catch (re) {
            if (re instanceof antlr.RecognitionException) {
                this.errorHandler.reportError(this, re);
                this.errorHandler.recover(this, re);
            } else {
                throw re;
            }
        }
        finally {
            this.exitRule();
        }
        return localContext;
    }
    public functionCall(): FunctionCallContext {
        let localContext = new FunctionCallContext(this.context, this.state);
        this.enterRule(localContext, 204, jsoniqParser.RULE_functionCall);
        try {
            this.enterOuterAlt(localContext, 1);
            {
            this.state = 1249;
            localContext._fn_name = this.qname();
            this.state = 1250;
            this.argumentList();
            }
        }
        catch (re) {
            if (re instanceof antlr.RecognitionException) {
                this.errorHandler.reportError(this, re);
                this.errorHandler.recover(this, re);
            } else {
                throw re;
            }
        }
        finally {
            this.exitRule();
        }
        return localContext;
    }
    public argumentList(): ArgumentListContext {
        let localContext = new ArgumentListContext(this.context, this.state);
        this.enterRule(localContext, 206, jsoniqParser.RULE_argumentList);
        let _la: number;
        try {
            this.enterOuterAlt(localContext, 1);
            {
            this.state = 1252;
            this.match(jsoniqParser.Klparen);
            this.state = 1261;
            this.errorHandler.sync(this);
            _la = this.tokenStream.LA(1);
            if ((((_la) & ~0x1F) === 0 && ((1 << _la) & 1073812816) !== 0) || ((((_la - 46)) & ~0x1F) === 0 && ((1 << (_la - 46)) & 4294957635) !== 0) || ((((_la - 78)) & ~0x1F) === 0 && ((1 << (_la - 78)) & 4294967295) !== 0) || ((((_la - 110)) & ~0x1F) === 0 && ((1 << (_la - 110)) & 4294967295) !== 0) || ((((_la - 142)) & ~0x1F) === 0 && ((1 << (_la - 142)) & 4294967295) !== 0) || ((((_la - 174)) & ~0x1F) === 0 && ((1 << (_la - 174)) & 16895) !== 0)) {
                {
                this.state = 1253;
                localContext._argument = this.argument();
                localContext._args.push(localContext._argument!);
                this.state = 1258;
                this.errorHandler.sync(this);
                _la = this.tokenStream.LA(1);
                while (_la === 13) {
                    {
                    {
                    this.state = 1254;
                    this.match(jsoniqParser.Kcomma);
                    this.state = 1255;
                    localContext._argument = this.argument();
                    localContext._args.push(localContext._argument!);
                    }
                    }
                    this.state = 1260;
                    this.errorHandler.sync(this);
                    _la = this.tokenStream.LA(1);
                }
                }
            }

            this.state = 1263;
            this.match(jsoniqParser.Krparen);
            }
        }
        catch (re) {
            if (re instanceof antlr.RecognitionException) {
                this.errorHandler.reportError(this, re);
                this.errorHandler.recover(this, re);
            } else {
                throw re;
            }
        }
        finally {
            this.exitRule();
        }
        return localContext;
    }
    public argument(): ArgumentContext {
        let localContext = new ArgumentContext(this.context, this.state);
        this.enterRule(localContext, 208, jsoniqParser.RULE_argument);
        try {
            this.state = 1267;
            this.errorHandler.sync(this);
            switch (this.tokenStream.LA(1)) {
            case jsoniqParser.Kdollar:
            case jsoniqParser.Klbrace:
            case jsoniqParser.Klparen:
            case jsoniqParser.Kasterisk:
            case jsoniqParser.Kannotation:
            case jsoniqParser.Kordered:
            case jsoniqParser.Kfunction:
            case jsoniqParser.Kplus:
            case jsoniqParser.Kminus:
            case jsoniqParser.Klbracket:
            case jsoniqParser.Kcontext_item:
            case jsoniqParser.Kdotdot:
            case jsoniqParser.Kobject_start:
            case jsoniqParser.Kfor:
            case jsoniqParser.Klet:
            case jsoniqParser.Kwhere:
            case jsoniqParser.Kgroup:
            case jsoniqParser.Kby:
            case jsoniqParser.Korder:
            case jsoniqParser.Kreturn:
            case jsoniqParser.Kif:
            case jsoniqParser.Kin:
            case jsoniqParser.Kas:
            case jsoniqParser.Kat:
            case jsoniqParser.Kallowing:
            case jsoniqParser.Kempty:
            case jsoniqParser.Kcount:
            case jsoniqParser.Kstable:
            case jsoniqParser.Kascending:
            case jsoniqParser.Kdescending:
            case jsoniqParser.Ksome:
            case jsoniqParser.Kevery:
            case jsoniqParser.Ksatisfies:
            case jsoniqParser.Kcollation:
            case jsoniqParser.Kgreatest:
            case jsoniqParser.Kleast:
            case jsoniqParser.Kswitch:
            case jsoniqParser.Kcase:
            case jsoniqParser.Ktry:
            case jsoniqParser.Kcatch:
            case jsoniqParser.Kdefault:
            case jsoniqParser.Kthen:
            case jsoniqParser.Kelse:
            case jsoniqParser.Ktypeswitch:
            case jsoniqParser.Kor:
            case jsoniqParser.Kand:
            case jsoniqParser.Knot:
            case jsoniqParser.Kto:
            case jsoniqParser.Kinstance:
            case jsoniqParser.Kof:
            case jsoniqParser.Kstatically:
            case jsoniqParser.Kis:
            case jsoniqParser.Ktreat:
            case jsoniqParser.Kcast:
            case jsoniqParser.Kcastable:
            case jsoniqParser.Kversion:
            case jsoniqParser.Kjsoniq:
            case jsoniqParser.Kunordered:
            case jsoniqParser.Ktrue:
            case jsoniqParser.Kfalse:
            case jsoniqParser.Ktype:
            case jsoniqParser.Kvalidate:
            case jsoniqParser.Kannotate:
            case jsoniqParser.Kdeclare:
            case jsoniqParser.Kcontext:
            case jsoniqParser.Kitem:
            case jsoniqParser.Kvariable:
            case jsoniqParser.Kinsert:
            case jsoniqParser.Kdelete:
            case jsoniqParser.Krename:
            case jsoniqParser.Kreplace:
            case jsoniqParser.Kcopy:
            case jsoniqParser.Kmodify:
            case jsoniqParser.Kappend:
            case jsoniqParser.Kinto:
            case jsoniqParser.Kvalue:
            case jsoniqParser.Kwith:
            case jsoniqParser.Kposition:
            case jsoniqParser.Kjson:
            case jsoniqParser.Kupdating:
            case jsoniqParser.Kcreate:
            case jsoniqParser.Kcollection:
            case jsoniqParser.Ktable:
            case jsoniqParser.Kdeltafile:
            case jsoniqParser.Kicebergtable:
            case jsoniqParser.Ktruncate:
            case jsoniqParser.Kfirst:
            case jsoniqParser.Klast:
            case jsoniqParser.Kfrom:
            case jsoniqParser.Kedit:
            case jsoniqParser.Kafter:
            case jsoniqParser.Kbefore:
            case jsoniqParser.Kimport:
            case jsoniqParser.Kschema:
            case jsoniqParser.Knamespace:
            case jsoniqParser.Kelement:
            case jsoniqParser.Kslash:
            case jsoniqParser.Kdslash:
            case jsoniqParser.Kat_symbol:
            case jsoniqParser.Kchild:
            case jsoniqParser.Kdescendant:
            case jsoniqParser.Kattribute:
            case jsoniqParser.Kself:
            case jsoniqParser.Kdescendant_or_self:
            case jsoniqParser.Kfollowing_sibling:
            case jsoniqParser.Kfollowing:
            case jsoniqParser.Kparent:
            case jsoniqParser.Kancestor:
            case jsoniqParser.Kpreceding_sibling:
            case jsoniqParser.Kpreceding:
            case jsoniqParser.Kancestor_or_self:
            case jsoniqParser.Knode:
            case jsoniqParser.Kbinary:
            case jsoniqParser.Kdocument:
            case jsoniqParser.Kdocument_node:
            case jsoniqParser.Ktext:
            case jsoniqParser.Kpi:
            case jsoniqParser.Knamespace_node:
            case jsoniqParser.Kschema_attribute:
            case jsoniqParser.Kschema_element:
            case jsoniqParser.Karray_node:
            case jsoniqParser.Kboolean_node:
            case jsoniqParser.Knull_node:
            case jsoniqParser.Knumber_node:
            case jsoniqParser.Kobject_node:
            case jsoniqParser.Kcomment:
            case jsoniqParser.Kbreak:
            case jsoniqParser.Kloop:
            case jsoniqParser.Kcontinue:
            case jsoniqParser.Kexit:
            case jsoniqParser.Kreturning:
            case jsoniqParser.Kwhile:
            case jsoniqParser.STRING:
            case jsoniqParser.NullLiteral:
            case jsoniqParser.Literal:
            case jsoniqParser.NCName:
                this.enterOuterAlt(localContext, 1);
                {
                this.state = 1265;
                this.exprSingle();
                }
                break;
            case jsoniqParser.ArgumentPlaceholder:
                this.enterOuterAlt(localContext, 2);
                {
                this.state = 1266;
                this.match(jsoniqParser.ArgumentPlaceholder);
                }
                break;
            default:
                throw new antlr.NoViableAltException(this);
            }
        }
        catch (re) {
            if (re instanceof antlr.RecognitionException) {
                this.errorHandler.reportError(this, re);
                this.errorHandler.recover(this, re);
            } else {
                throw re;
            }
        }
        finally {
            this.exitRule();
        }
        return localContext;
    }
    public functionItemExpr(): FunctionItemExprContext {
        let localContext = new FunctionItemExprContext(this.context, this.state);
        this.enterRule(localContext, 210, jsoniqParser.RULE_functionItemExpr);
        try {
            this.state = 1271;
            this.errorHandler.sync(this);
            switch (this.interpreter.adaptivePredict(this.tokenStream, 112, this.context) ) {
            case 1:
                this.enterOuterAlt(localContext, 1);
                {
                this.state = 1269;
                this.namedFunctionRef();
                }
                break;
            case 2:
                this.enterOuterAlt(localContext, 2);
                {
                this.state = 1270;
                this.inlineFunctionExpr();
                }
                break;
            }
        }
        catch (re) {
            if (re instanceof antlr.RecognitionException) {
                this.errorHandler.reportError(this, re);
                this.errorHandler.recover(this, re);
            } else {
                throw re;
            }
        }
        finally {
            this.exitRule();
        }
        return localContext;
    }
    public namedFunctionRef(): NamedFunctionRefContext {
        let localContext = new NamedFunctionRefContext(this.context, this.state);
        this.enterRule(localContext, 212, jsoniqParser.RULE_namedFunctionRef);
        try {
            this.enterOuterAlt(localContext, 1);
            {
            this.state = 1273;
            localContext._fn_name = this.qname();
            this.state = 1274;
            this.match(jsoniqParser.Khash);
            this.state = 1275;
            localContext._arity = this.match(jsoniqParser.Literal);
            }
        }
        catch (re) {
            if (re instanceof antlr.RecognitionException) {
                this.errorHandler.reportError(this, re);
                this.errorHandler.recover(this, re);
            } else {
                throw re;
            }
        }
        finally {
            this.exitRule();
        }
        return localContext;
    }
    public inlineFunctionExpr(): InlineFunctionExprContext {
        let localContext = new InlineFunctionExprContext(this.context, this.state);
        this.enterRule(localContext, 214, jsoniqParser.RULE_inlineFunctionExpr);
        let _la: number;
        try {
            this.enterOuterAlt(localContext, 1);
            {
            this.state = 1277;
            this.annotations();
            this.state = 1278;
            this.match(jsoniqParser.Kfunction);
            this.state = 1279;
            this.match(jsoniqParser.Klparen);
            this.state = 1281;
            this.errorHandler.sync(this);
            _la = this.tokenStream.LA(1);
            if (_la === 4) {
                {
                this.state = 1280;
                this.paramList();
                }
            }

            this.state = 1283;
            this.match(jsoniqParser.Krparen);
            this.state = 1286;
            this.errorHandler.sync(this);
            _la = this.tokenStream.LA(1);
            if (_la === 69) {
                {
                this.state = 1284;
                this.match(jsoniqParser.Kas);
                this.state = 1285;
                localContext._return_type = this.sequenceType();
                }
            }

            {
            this.state = 1288;
            this.match(jsoniqParser.Klbrace);
            {
            this.state = 1289;
            localContext._fn_body = this.statementsAndOptionalExpr();
            }
            this.state = 1290;
            this.match(jsoniqParser.Krbrace);
            }
            }
        }
        catch (re) {
            if (re instanceof antlr.RecognitionException) {
                this.errorHandler.reportError(this, re);
                this.errorHandler.recover(this, re);
            } else {
                throw re;
            }
        }
        finally {
            this.exitRule();
        }
        return localContext;
    }
    public insertExpr(): InsertExprContext {
        let localContext = new InsertExprContext(this.context, this.state);
        this.enterRule(localContext, 216, jsoniqParser.RULE_insertExpr);
        let _la: number;
        try {
            this.state = 1315;
            this.errorHandler.sync(this);
            switch (this.interpreter.adaptivePredict(this.tokenStream, 117, this.context) ) {
            case 1:
                this.enterOuterAlt(localContext, 1);
                {
                this.state = 1292;
                this.match(jsoniqParser.Kinsert);
                this.state = 1293;
                this.match(jsoniqParser.Kjson);
                this.state = 1294;
                localContext._to_insert_expr = this.exprSingle();
                this.state = 1295;
                this.match(jsoniqParser.Kinto);
                this.state = 1296;
                localContext._main_expr = this.exprSingle();
                this.state = 1300;
                this.errorHandler.sync(this);
                switch (this.interpreter.adaptivePredict(this.tokenStream, 115, this.context) ) {
                case 1:
                    {
                    this.state = 1297;
                    this.match(jsoniqParser.Kat);
                    this.state = 1298;
                    this.match(jsoniqParser.Kposition);
                    this.state = 1299;
                    localContext._pos_expr = this.exprSingle();
                    }
                    break;
                }
                }
                break;
            case 2:
                this.enterOuterAlt(localContext, 2);
                {
                this.state = 1302;
                this.match(jsoniqParser.Kinsert);
                this.state = 1303;
                this.match(jsoniqParser.Kjson);
                this.state = 1304;
                this.pairConstructor();
                this.state = 1309;
                this.errorHandler.sync(this);
                _la = this.tokenStream.LA(1);
                while (_la === 13) {
                    {
                    {
                    this.state = 1305;
                    this.match(jsoniqParser.Kcomma);
                    this.state = 1306;
                    this.pairConstructor();
                    }
                    }
                    this.state = 1311;
                    this.errorHandler.sync(this);
                    _la = this.tokenStream.LA(1);
                }
                this.state = 1312;
                this.match(jsoniqParser.Kinto);
                this.state = 1313;
                localContext._main_expr = this.exprSingle();
                }
                break;
            }
        }
        catch (re) {
            if (re instanceof antlr.RecognitionException) {
                this.errorHandler.reportError(this, re);
                this.errorHandler.recover(this, re);
            } else {
                throw re;
            }
        }
        finally {
            this.exitRule();
        }
        return localContext;
    }
    public deleteExpr(): DeleteExprContext {
        let localContext = new DeleteExprContext(this.context, this.state);
        this.enterRule(localContext, 218, jsoniqParser.RULE_deleteExpr);
        try {
            this.enterOuterAlt(localContext, 1);
            {
            this.state = 1317;
            this.match(jsoniqParser.Kdelete);
            this.state = 1318;
            this.match(jsoniqParser.Kjson);
            this.state = 1319;
            this.updateLocator();
            }
        }
        catch (re) {
            if (re instanceof antlr.RecognitionException) {
                this.errorHandler.reportError(this, re);
                this.errorHandler.recover(this, re);
            } else {
                throw re;
            }
        }
        finally {
            this.exitRule();
        }
        return localContext;
    }
    public renameExpr(): RenameExprContext {
        let localContext = new RenameExprContext(this.context, this.state);
        this.enterRule(localContext, 220, jsoniqParser.RULE_renameExpr);
        try {
            this.enterOuterAlt(localContext, 1);
            {
            this.state = 1321;
            this.match(jsoniqParser.Krename);
            this.state = 1322;
            this.match(jsoniqParser.Kjson);
            this.state = 1323;
            this.updateLocator();
            this.state = 1324;
            this.match(jsoniqParser.Kas);
            this.state = 1325;
            localContext._name_expr = this.exprSingle();
            }
        }
        catch (re) {
            if (re instanceof antlr.RecognitionException) {
                this.errorHandler.reportError(this, re);
                this.errorHandler.recover(this, re);
            } else {
                throw re;
            }
        }
        finally {
            this.exitRule();
        }
        return localContext;
    }
    public replaceExpr(): ReplaceExprContext {
        let localContext = new ReplaceExprContext(this.context, this.state);
        this.enterRule(localContext, 222, jsoniqParser.RULE_replaceExpr);
        try {
            this.enterOuterAlt(localContext, 1);
            {
            this.state = 1327;
            this.match(jsoniqParser.Kreplace);
            this.state = 1328;
            this.match(jsoniqParser.Kvalue);
            this.state = 1329;
            this.match(jsoniqParser.Kof);
            this.state = 1330;
            this.match(jsoniqParser.Kjson);
            this.state = 1331;
            this.updateLocator();
            this.state = 1332;
            this.match(jsoniqParser.Kwith);
            this.state = 1333;
            localContext._replacer_expr = this.exprSingle();
            }
        }
        catch (re) {
            if (re instanceof antlr.RecognitionException) {
                this.errorHandler.reportError(this, re);
                this.errorHandler.recover(this, re);
            } else {
                throw re;
            }
        }
        finally {
            this.exitRule();
        }
        return localContext;
    }
    public transformExpr(): TransformExprContext {
        let localContext = new TransformExprContext(this.context, this.state);
        this.enterRule(localContext, 224, jsoniqParser.RULE_transformExpr);
        let _la: number;
        try {
            this.enterOuterAlt(localContext, 1);
            {
            this.state = 1335;
            this.match(jsoniqParser.Kcopy);
            this.state = 1336;
            this.copyDecl();
            this.state = 1341;
            this.errorHandler.sync(this);
            _la = this.tokenStream.LA(1);
            while (_la === 13) {
                {
                {
                this.state = 1337;
                this.match(jsoniqParser.Kcomma);
                this.state = 1338;
                this.copyDecl();
                }
                }
                this.state = 1343;
                this.errorHandler.sync(this);
                _la = this.tokenStream.LA(1);
            }
            this.state = 1344;
            this.match(jsoniqParser.Kmodify);
            this.state = 1345;
            localContext._mod_expr = this.exprSingle();
            this.state = 1346;
            this.match(jsoniqParser.Kreturn);
            this.state = 1347;
            localContext._ret_expr = this.exprSingle();
            }
        }
        catch (re) {
            if (re instanceof antlr.RecognitionException) {
                this.errorHandler.reportError(this, re);
                this.errorHandler.recover(this, re);
            } else {
                throw re;
            }
        }
        finally {
            this.exitRule();
        }
        return localContext;
    }
    public appendExpr(): AppendExprContext {
        let localContext = new AppendExprContext(this.context, this.state);
        this.enterRule(localContext, 226, jsoniqParser.RULE_appendExpr);
        try {
            this.enterOuterAlt(localContext, 1);
            {
            this.state = 1349;
            this.match(jsoniqParser.Kappend);
            this.state = 1350;
            this.match(jsoniqParser.Kjson);
            this.state = 1351;
            localContext._to_append_expr = this.exprSingle();
            this.state = 1352;
            this.match(jsoniqParser.Kinto);
            this.state = 1353;
            localContext._array_expr = this.exprSingle();
            }
        }
        catch (re) {
            if (re instanceof antlr.RecognitionException) {
                this.errorHandler.reportError(this, re);
                this.errorHandler.recover(this, re);
            } else {
                throw re;
            }
        }
        finally {
            this.exitRule();
        }
        return localContext;
    }
    public updateLocator(): UpdateLocatorContext {
        let localContext = new UpdateLocatorContext(this.context, this.state);
        this.enterRule(localContext, 228, jsoniqParser.RULE_updateLocator);
        try {
            this.enterOuterAlt(localContext, 1);
            {
            this.state = 1355;
            localContext._main_expr = this.postFixExpr();
            }
        }
        catch (re) {
            if (re instanceof antlr.RecognitionException) {
                this.errorHandler.reportError(this, re);
                this.errorHandler.recover(this, re);
            } else {
                throw re;
            }
        }
        finally {
            this.exitRule();
        }
        return localContext;
    }
    public copyDecl(): CopyDeclContext {
        let localContext = new CopyDeclContext(this.context, this.state);
        this.enterRule(localContext, 230, jsoniqParser.RULE_copyDecl);
        try {
            this.enterOuterAlt(localContext, 1);
            {
            this.state = 1357;
            localContext._var_ref = this.varRef();
            this.state = 1358;
            this.match(jsoniqParser.Kassign);
            this.state = 1359;
            localContext._src_expr = this.exprSingle();
            }
        }
        catch (re) {
            if (re instanceof antlr.RecognitionException) {
                this.errorHandler.reportError(this, re);
                this.errorHandler.recover(this, re);
            } else {
                throw re;
            }
        }
        finally {
            this.exitRule();
        }
        return localContext;
    }
    public createCollectionExpr(): CreateCollectionExprContext {
        let localContext = new CreateCollectionExprContext(this.context, this.state);
        this.enterRule(localContext, 232, jsoniqParser.RULE_createCollectionExpr);
        let _la: number;
        try {
            this.enterOuterAlt(localContext, 1);
            {
            this.state = 1361;
            this.match(jsoniqParser.Kcreate);
            this.state = 1362;
            this.match(jsoniqParser.Kcollection);
            this.state = 1363;
            localContext._collectionMode = this.tokenStream.LT(1);
            _la = this.tokenStream.LA(1);
            if(!(((((_la - 129)) & ~0x1F) === 0 && ((1 << (_la - 129)) & 7) !== 0))) {
                localContext._collectionMode = this.errorHandler.recoverInline(this);
            }
            else {
                this.errorHandler.reportMatch(this);
                this.consume();
            }
            this.state = 1364;
            this.match(jsoniqParser.Klparen);
            this.state = 1365;
            localContext._collection_name = this.exprSimple();
            this.state = 1366;
            this.match(jsoniqParser.Krparen);
            this.state = 1369;
            this.errorHandler.sync(this);
            _la = this.tokenStream.LA(1);
            if (_la === 123) {
                {
                this.state = 1367;
                this.match(jsoniqParser.Kwith);
                this.state = 1368;
                localContext._content = this.exprSingle();
                }
            }

            }
        }
        catch (re) {
            if (re instanceof antlr.RecognitionException) {
                this.errorHandler.reportError(this, re);
                this.errorHandler.recover(this, re);
            } else {
                throw re;
            }
        }
        finally {
            this.exitRule();
        }
        return localContext;
    }
    public deleteIndexExpr(): DeleteIndexExprContext {
        let localContext = new DeleteIndexExprContext(this.context, this.state);
        this.enterRule(localContext, 234, jsoniqParser.RULE_deleteIndexExpr);
        let _la: number;
        try {
            this.enterOuterAlt(localContext, 1);
            {
            this.state = 1371;
            this.match(jsoniqParser.Kdelete);
            {
            this.state = 1374;
            this.errorHandler.sync(this);
            switch (this.tokenStream.LA(1)) {
            case jsoniqParser.Kfirst:
                {
                this.state = 1372;
                localContext._first = this.match(jsoniqParser.Kfirst);
                }
                break;
            case jsoniqParser.Klast:
                {
                this.state = 1373;
                localContext._last = this.match(jsoniqParser.Klast);
                }
                break;
            default:
                throw new antlr.NoViableAltException(this);
            }
            this.state = 1377;
            this.errorHandler.sync(this);
            switch (this.interpreter.adaptivePredict(this.tokenStream, 121, this.context) ) {
            case 1:
                {
                this.state = 1376;
                localContext._num = this.exprSingle();
                }
                break;
            }
            }
            this.state = 1379;
            this.match(jsoniqParser.Kfrom);
            this.state = 1380;
            this.match(jsoniqParser.Kcollection);
            this.state = 1381;
            localContext._collectionMode = this.tokenStream.LT(1);
            _la = this.tokenStream.LA(1);
            if(!(((((_la - 129)) & ~0x1F) === 0 && ((1 << (_la - 129)) & 7) !== 0))) {
                localContext._collectionMode = this.errorHandler.recoverInline(this);
            }
            else {
                this.errorHandler.reportMatch(this);
                this.consume();
            }
            this.state = 1382;
            this.match(jsoniqParser.Klparen);
            this.state = 1383;
            localContext._collection_name = this.exprSimple();
            this.state = 1384;
            this.match(jsoniqParser.Krparen);
            }
        }
        catch (re) {
            if (re instanceof antlr.RecognitionException) {
                this.errorHandler.reportError(this, re);
                this.errorHandler.recover(this, re);
            } else {
                throw re;
            }
        }
        finally {
            this.exitRule();
        }
        return localContext;
    }
    public deleteSearchExpr(): DeleteSearchExprContext {
        let localContext = new DeleteSearchExprContext(this.context, this.state);
        this.enterRule(localContext, 236, jsoniqParser.RULE_deleteSearchExpr);
        try {
            this.enterOuterAlt(localContext, 1);
            {
            this.state = 1386;
            this.match(jsoniqParser.Kdelete);
            this.state = 1387;
            localContext._content = this.exprSingle();
            this.state = 1388;
            this.match(jsoniqParser.Kfrom);
            this.state = 1389;
            this.match(jsoniqParser.Kcollection);
            }
        }
        catch (re) {
            if (re instanceof antlr.RecognitionException) {
                this.errorHandler.reportError(this, re);
                this.errorHandler.recover(this, re);
            } else {
                throw re;
            }
        }
        finally {
            this.exitRule();
        }
        return localContext;
    }
    public insertIndexExpr(): InsertIndexExprContext {
        let localContext = new InsertIndexExprContext(this.context, this.state);
        this.enterRule(localContext, 238, jsoniqParser.RULE_insertIndexExpr);
        let _la: number;
        try {
            this.enterOuterAlt(localContext, 1);
            {
            this.state = 1391;
            this.match(jsoniqParser.Kinsert);
            this.state = 1392;
            localContext._content = this.exprSingle();
            this.state = 1397;
            this.errorHandler.sync(this);
            switch (this.tokenStream.LA(1)) {
            case jsoniqParser.Kat:
                {
                {
                this.state = 1393;
                this.match(jsoniqParser.Kat);
                this.state = 1394;
                localContext._pos = this.exprSingle();
                }
                }
                break;
            case jsoniqParser.Kfirst:
                {
                this.state = 1395;
                localContext._first = this.match(jsoniqParser.Kfirst);
                }
                break;
            case jsoniqParser.Klast:
                {
                this.state = 1396;
                localContext._last = this.match(jsoniqParser.Klast);
                }
                break;
            default:
                throw new antlr.NoViableAltException(this);
            }
            this.state = 1399;
            this.match(jsoniqParser.Kinto);
            this.state = 1400;
            this.match(jsoniqParser.Kcollection);
            this.state = 1401;
            localContext._collectionMode = this.tokenStream.LT(1);
            _la = this.tokenStream.LA(1);
            if(!(((((_la - 129)) & ~0x1F) === 0 && ((1 << (_la - 129)) & 7) !== 0))) {
                localContext._collectionMode = this.errorHandler.recoverInline(this);
            }
            else {
                this.errorHandler.reportMatch(this);
                this.consume();
            }
            this.state = 1402;
            this.match(jsoniqParser.Klparen);
            this.state = 1403;
            localContext._collection_name = this.exprSimple();
            this.state = 1404;
            this.match(jsoniqParser.Krparen);
            }
        }
        catch (re) {
            if (re instanceof antlr.RecognitionException) {
                this.errorHandler.reportError(this, re);
                this.errorHandler.recover(this, re);
            } else {
                throw re;
            }
        }
        finally {
            this.exitRule();
        }
        return localContext;
    }
    public insertSearchExpr(): InsertSearchExprContext {
        let localContext = new InsertSearchExprContext(this.context, this.state);
        this.enterRule(localContext, 240, jsoniqParser.RULE_insertSearchExpr);
        try {
            this.enterOuterAlt(localContext, 1);
            {
            this.state = 1406;
            this.match(jsoniqParser.Kinsert);
            this.state = 1407;
            localContext._content = this.exprSingle();
            this.state = 1410;
            this.errorHandler.sync(this);
            switch (this.tokenStream.LA(1)) {
            case jsoniqParser.Kbefore:
                {
                this.state = 1408;
                localContext._before = this.match(jsoniqParser.Kbefore);
                }
                break;
            case jsoniqParser.Kafter:
                {
                this.state = 1409;
                localContext._after = this.match(jsoniqParser.Kafter);
                }
                break;
            default:
                throw new antlr.NoViableAltException(this);
            }
            this.state = 1412;
            localContext._target = this.exprSingle();
            this.state = 1413;
            this.match(jsoniqParser.Kinto);
            this.state = 1414;
            this.match(jsoniqParser.Kcollection);
            }
        }
        catch (re) {
            if (re instanceof antlr.RecognitionException) {
                this.errorHandler.reportError(this, re);
                this.errorHandler.recover(this, re);
            } else {
                throw re;
            }
        }
        finally {
            this.exitRule();
        }
        return localContext;
    }
    public truncateCollectionExpr(): TruncateCollectionExprContext {
        let localContext = new TruncateCollectionExprContext(this.context, this.state);
        this.enterRule(localContext, 242, jsoniqParser.RULE_truncateCollectionExpr);
        let _la: number;
        try {
            this.enterOuterAlt(localContext, 1);
            {
            this.state = 1416;
            _la = this.tokenStream.LA(1);
            if(!(_la === 115 || _la === 132)) {
            this.errorHandler.recoverInline(this);
            }
            else {
                this.errorHandler.reportMatch(this);
                this.consume();
            }
            this.state = 1417;
            this.match(jsoniqParser.Kcollection);
            this.state = 1418;
            localContext._collectionMode = this.tokenStream.LT(1);
            _la = this.tokenStream.LA(1);
            if(!(((((_la - 129)) & ~0x1F) === 0 && ((1 << (_la - 129)) & 7) !== 0))) {
                localContext._collectionMode = this.errorHandler.recoverInline(this);
            }
            else {
                this.errorHandler.reportMatch(this);
                this.consume();
            }
            this.state = 1419;
            this.match(jsoniqParser.Klparen);
            this.state = 1420;
            localContext._collection_name = this.exprSimple();
            this.state = 1421;
            this.match(jsoniqParser.Krparen);
            }
        }
        catch (re) {
            if (re instanceof antlr.RecognitionException) {
                this.errorHandler.reportError(this, re);
                this.errorHandler.recover(this, re);
            } else {
                throw re;
            }
        }
        finally {
            this.exitRule();
        }
        return localContext;
    }
    public editCollectionExpr(): EditCollectionExprContext {
        let localContext = new EditCollectionExprContext(this.context, this.state);
        this.enterRule(localContext, 244, jsoniqParser.RULE_editCollectionExpr);
        try {
            this.enterOuterAlt(localContext, 1);
            {
            this.state = 1423;
            this.match(jsoniqParser.Kedit);
            this.state = 1424;
            localContext._target = this.exprSingle();
            this.state = 1425;
            this.match(jsoniqParser.Kinto);
            this.state = 1426;
            localContext._content = this.exprSingle();
            this.state = 1427;
            this.match(jsoniqParser.Kin);
            this.state = 1428;
            this.match(jsoniqParser.Kcollection);
            }
        }
        catch (re) {
            if (re instanceof antlr.RecognitionException) {
                this.errorHandler.reportError(this, re);
                this.errorHandler.recover(this, re);
            } else {
                throw re;
            }
        }
        finally {
            this.exitRule();
        }
        return localContext;
    }
    public pathExpr(): PathExprContext {
        let localContext = new PathExprContext(this.context, this.state);
        this.enterRule(localContext, 246, jsoniqParser.RULE_pathExpr);
        try {
            this.state = 1437;
            this.errorHandler.sync(this);
            switch (this.interpreter.adaptivePredict(this.tokenStream, 125, this.context) ) {
            case 1:
                this.enterOuterAlt(localContext, 1);
                {
                {
                this.state = 1430;
                this.match(jsoniqParser.Kslash);
                this.state = 1432;
                this.errorHandler.sync(this);
                switch (this.interpreter.adaptivePredict(this.tokenStream, 124, this.context) ) {
                case 1:
                    {
                    this.state = 1431;
                    localContext._singleslash = this.relativePathExpr();
                    }
                    break;
                }
                }
                }
                break;
            case 2:
                this.enterOuterAlt(localContext, 2);
                {
                {
                this.state = 1434;
                this.match(jsoniqParser.Kdslash);
                this.state = 1435;
                localContext._doubleslash = this.relativePathExpr();
                }
                }
                break;
            case 3:
                this.enterOuterAlt(localContext, 3);
                {
                this.state = 1436;
                localContext._relative = this.relativePathExpr();
                }
                break;
            }
        }
        catch (re) {
            if (re instanceof antlr.RecognitionException) {
                this.errorHandler.reportError(this, re);
                this.errorHandler.recover(this, re);
            } else {
                throw re;
            }
        }
        finally {
            this.exitRule();
        }
        return localContext;
    }
    public relativePathExpr(): RelativePathExprContext {
        let localContext = new RelativePathExprContext(this.context, this.state);
        this.enterRule(localContext, 248, jsoniqParser.RULE_relativePathExpr);
        let _la: number;
        try {
            this.enterOuterAlt(localContext, 1);
            {
            this.state = 1439;
            this.stepExpr();
            this.state = 1444;
            this.errorHandler.sync(this);
            _la = this.tokenStream.LA(1);
            while (_la === 143 || _la === 144) {
                {
                {
                this.state = 1440;
                localContext.__tset3113 = this.tokenStream.LT(1);
                _la = this.tokenStream.LA(1);
                if(!(_la === 143 || _la === 144)) {
                    localContext.__tset3113 = this.errorHandler.recoverInline(this);
                }
                else {
                    this.errorHandler.reportMatch(this);
                    this.consume();
                }
                localContext._sep.push(localContext.__tset3113!);
                this.state = 1441;
                this.stepExpr();
                }
                }
                this.state = 1446;
                this.errorHandler.sync(this);
                _la = this.tokenStream.LA(1);
            }
            }
        }
        catch (re) {
            if (re instanceof antlr.RecognitionException) {
                this.errorHandler.reportError(this, re);
                this.errorHandler.recover(this, re);
            } else {
                throw re;
            }
        }
        finally {
            this.exitRule();
        }
        return localContext;
    }
    public stepExpr(): StepExprContext {
        let localContext = new StepExprContext(this.context, this.state);
        this.enterRule(localContext, 250, jsoniqParser.RULE_stepExpr);
        try {
            this.state = 1449;
            this.errorHandler.sync(this);
            switch (this.interpreter.adaptivePredict(this.tokenStream, 127, this.context) ) {
            case 1:
                this.enterOuterAlt(localContext, 1);
                {
                this.state = 1447;
                this.postFixExpr();
                }
                break;
            case 2:
                this.enterOuterAlt(localContext, 2);
                {
                this.state = 1448;
                this.axisStep();
                }
                break;
            }
        }
        catch (re) {
            if (re instanceof antlr.RecognitionException) {
                this.errorHandler.reportError(this, re);
                this.errorHandler.recover(this, re);
            } else {
                throw re;
            }
        }
        finally {
            this.exitRule();
        }
        return localContext;
    }
    public axisStep(): AxisStepContext {
        let localContext = new AxisStepContext(this.context, this.state);
        this.enterRule(localContext, 252, jsoniqParser.RULE_axisStep);
        try {
            this.enterOuterAlt(localContext, 1);
            {
            this.state = 1453;
            this.errorHandler.sync(this);
            switch (this.interpreter.adaptivePredict(this.tokenStream, 128, this.context) ) {
            case 1:
                {
                this.state = 1451;
                this.reverseStep();
                }
                break;
            case 2:
                {
                this.state = 1452;
                this.forwardStep();
                }
                break;
            }
            this.state = 1455;
            this.predicateList();
            }
        }
        catch (re) {
            if (re instanceof antlr.RecognitionException) {
                this.errorHandler.reportError(this, re);
                this.errorHandler.recover(this, re);
            } else {
                throw re;
            }
        }
        finally {
            this.exitRule();
        }
        return localContext;
    }
    public forwardStep(): ForwardStepContext {
        let localContext = new ForwardStepContext(this.context, this.state);
        this.enterRule(localContext, 254, jsoniqParser.RULE_forwardStep);
        try {
            this.state = 1461;
            this.errorHandler.sync(this);
            switch (this.interpreter.adaptivePredict(this.tokenStream, 129, this.context) ) {
            case 1:
                this.enterOuterAlt(localContext, 1);
                {
                {
                this.state = 1457;
                this.forwardAxis();
                this.state = 1458;
                this.nodeTest();
                }
                }
                break;
            case 2:
                this.enterOuterAlt(localContext, 2);
                {
                this.state = 1460;
                this.abbrevForwardStep();
                }
                break;
            }
        }
        catch (re) {
            if (re instanceof antlr.RecognitionException) {
                this.errorHandler.reportError(this, re);
                this.errorHandler.recover(this, re);
            } else {
                throw re;
            }
        }
        finally {
            this.exitRule();
        }
        return localContext;
    }
    public forwardAxis(): ForwardAxisContext {
        let localContext = new ForwardAxisContext(this.context, this.state);
        this.enterRule(localContext, 256, jsoniqParser.RULE_forwardAxis);
        let _la: number;
        try {
            this.enterOuterAlt(localContext, 1);
            {
            this.state = 1463;
            _la = this.tokenStream.LA(1);
            if(!(((((_la - 146)) & ~0x1F) === 0 && ((1 << (_la - 146)) & 127) !== 0))) {
            this.errorHandler.recoverInline(this);
            }
            else {
                this.errorHandler.reportMatch(this);
                this.consume();
            }
            this.state = 1464;
            this.match(jsoniqParser.Kcolon);
            this.state = 1465;
            this.match(jsoniqParser.Kcolon);
            }
        }
        catch (re) {
            if (re instanceof antlr.RecognitionException) {
                this.errorHandler.reportError(this, re);
                this.errorHandler.recover(this, re);
            } else {
                throw re;
            }
        }
        finally {
            this.exitRule();
        }
        return localContext;
    }
    public abbrevForwardStep(): AbbrevForwardStepContext {
        let localContext = new AbbrevForwardStepContext(this.context, this.state);
        this.enterRule(localContext, 258, jsoniqParser.RULE_abbrevForwardStep);
        try {
            this.enterOuterAlt(localContext, 1);
            {
            this.state = 1468;
            this.errorHandler.sync(this);
            switch (this.interpreter.adaptivePredict(this.tokenStream, 130, this.context) ) {
            case 1:
                {
                this.state = 1467;
                this.match(jsoniqParser.Kat_symbol);
                }
                break;
            }
            this.state = 1470;
            this.nodeTest();
            }
        }
        catch (re) {
            if (re instanceof antlr.RecognitionException) {
                this.errorHandler.reportError(this, re);
                this.errorHandler.recover(this, re);
            } else {
                throw re;
            }
        }
        finally {
            this.exitRule();
        }
        return localContext;
    }
    public reverseStep(): ReverseStepContext {
        let localContext = new ReverseStepContext(this.context, this.state);
        this.enterRule(localContext, 260, jsoniqParser.RULE_reverseStep);
        try {
            this.state = 1476;
            this.errorHandler.sync(this);
            switch (this.tokenStream.LA(1)) {
            case jsoniqParser.Kparent:
            case jsoniqParser.Kancestor:
            case jsoniqParser.Kpreceding_sibling:
            case jsoniqParser.Kpreceding:
            case jsoniqParser.Kancestor_or_self:
                this.enterOuterAlt(localContext, 1);
                {
                {
                this.state = 1472;
                this.reverseAxis();
                this.state = 1473;
                this.nodeTest();
                }
                }
                break;
            case jsoniqParser.Kdotdot:
                this.enterOuterAlt(localContext, 2);
                {
                this.state = 1475;
                this.abbrevReverseStep();
                }
                break;
            default:
                throw new antlr.NoViableAltException(this);
            }
        }
        catch (re) {
            if (re instanceof antlr.RecognitionException) {
                this.errorHandler.reportError(this, re);
                this.errorHandler.recover(this, re);
            } else {
                throw re;
            }
        }
        finally {
            this.exitRule();
        }
        return localContext;
    }
    public reverseAxis(): ReverseAxisContext {
        let localContext = new ReverseAxisContext(this.context, this.state);
        this.enterRule(localContext, 262, jsoniqParser.RULE_reverseAxis);
        let _la: number;
        try {
            this.enterOuterAlt(localContext, 1);
            {
            this.state = 1478;
            _la = this.tokenStream.LA(1);
            if(!(((((_la - 153)) & ~0x1F) === 0 && ((1 << (_la - 153)) & 31) !== 0))) {
            this.errorHandler.recoverInline(this);
            }
            else {
                this.errorHandler.reportMatch(this);
                this.consume();
            }
            this.state = 1479;
            this.match(jsoniqParser.Kcolon);
            this.state = 1480;
            this.match(jsoniqParser.Kcolon);
            }
        }
        catch (re) {
            if (re instanceof antlr.RecognitionException) {
                this.errorHandler.reportError(this, re);
                this.errorHandler.recover(this, re);
            } else {
                throw re;
            }
        }
        finally {
            this.exitRule();
        }
        return localContext;
    }
    public abbrevReverseStep(): AbbrevReverseStepContext {
        let localContext = new AbbrevReverseStepContext(this.context, this.state);
        this.enterRule(localContext, 264, jsoniqParser.RULE_abbrevReverseStep);
        try {
            this.enterOuterAlt(localContext, 1);
            {
            this.state = 1482;
            this.match(jsoniqParser.Kdotdot);
            }
        }
        catch (re) {
            if (re instanceof antlr.RecognitionException) {
                this.errorHandler.reportError(this, re);
                this.errorHandler.recover(this, re);
            } else {
                throw re;
            }
        }
        finally {
            this.exitRule();
        }
        return localContext;
    }
    public nodeTest(): NodeTestContext {
        let localContext = new NodeTestContext(this.context, this.state);
        this.enterRule(localContext, 266, jsoniqParser.RULE_nodeTest);
        try {
            this.state = 1486;
            this.errorHandler.sync(this);
            switch (this.interpreter.adaptivePredict(this.tokenStream, 132, this.context) ) {
            case 1:
                this.enterOuterAlt(localContext, 1);
                {
                this.state = 1484;
                this.nameTest();
                }
                break;
            case 2:
                this.enterOuterAlt(localContext, 2);
                {
                this.state = 1485;
                this.kindTest();
                }
                break;
            }
        }
        catch (re) {
            if (re instanceof antlr.RecognitionException) {
                this.errorHandler.reportError(this, re);
                this.errorHandler.recover(this, re);
            } else {
                throw re;
            }
        }
        finally {
            this.exitRule();
        }
        return localContext;
    }
    public nameTest(): NameTestContext {
        let localContext = new NameTestContext(this.context, this.state);
        this.enterRule(localContext, 268, jsoniqParser.RULE_nameTest);
        try {
            this.state = 1490;
            this.errorHandler.sync(this);
            switch (this.interpreter.adaptivePredict(this.tokenStream, 133, this.context) ) {
            case 1:
                this.enterOuterAlt(localContext, 1);
                {
                this.state = 1488;
                this.qname();
                }
                break;
            case 2:
                this.enterOuterAlt(localContext, 2);
                {
                this.state = 1489;
                this.wildcard();
                }
                break;
            }
        }
        catch (re) {
            if (re instanceof antlr.RecognitionException) {
                this.errorHandler.reportError(this, re);
                this.errorHandler.recover(this, re);
            } else {
                throw re;
            }
        }
        finally {
            this.exitRule();
        }
        return localContext;
    }
    public wildcard(): WildcardContext {
        let localContext = new WildcardContext(this.context, this.state);
        this.enterRule(localContext, 270, jsoniqParser.RULE_wildcard);
        try {
            this.state = 1495;
            this.errorHandler.sync(this);
            switch (this.interpreter.adaptivePredict(this.tokenStream, 134, this.context) ) {
            case 1:
                localContext = new AllNamesContext(localContext);
                this.enterOuterAlt(localContext, 1);
                {
                this.state = 1492;
                this.match(jsoniqParser.Kasterisk);
                }
                break;
            case 2:
                localContext = new AllWithNSContext(localContext);
                this.enterOuterAlt(localContext, 2);
                {
                this.state = 1493;
                this.nCNameWithLocalWildcard();
                }
                break;
            case 3:
                localContext = new AllWithLocalContext(localContext);
                this.enterOuterAlt(localContext, 3);
                {
                this.state = 1494;
                this.nCNameWithPrefixWildcard();
                }
                break;
            }
        }
        catch (re) {
            if (re instanceof antlr.RecognitionException) {
                this.errorHandler.reportError(this, re);
                this.errorHandler.recover(this, re);
            } else {
                throw re;
            }
        }
        finally {
            this.exitRule();
        }
        return localContext;
    }
    public nCNameWithLocalWildcard(): NCNameWithLocalWildcardContext {
        let localContext = new NCNameWithLocalWildcardContext(this.context, this.state);
        this.enterRule(localContext, 272, jsoniqParser.RULE_nCNameWithLocalWildcard);
        try {
            this.enterOuterAlt(localContext, 1);
            {
            this.state = 1497;
            this.match(jsoniqParser.NCName);
            this.state = 1498;
            this.match(jsoniqParser.Kcolon);
            this.state = 1499;
            this.match(jsoniqParser.Kasterisk);
            }
        }
        catch (re) {
            if (re instanceof antlr.RecognitionException) {
                this.errorHandler.reportError(this, re);
                this.errorHandler.recover(this, re);
            } else {
                throw re;
            }
        }
        finally {
            this.exitRule();
        }
        return localContext;
    }
    public nCNameWithPrefixWildcard(): NCNameWithPrefixWildcardContext {
        let localContext = new NCNameWithPrefixWildcardContext(this.context, this.state);
        this.enterRule(localContext, 274, jsoniqParser.RULE_nCNameWithPrefixWildcard);
        try {
            this.enterOuterAlt(localContext, 1);
            {
            this.state = 1501;
            this.match(jsoniqParser.Kasterisk);
            this.state = 1502;
            this.match(jsoniqParser.Kcolon);
            this.state = 1503;
            this.match(jsoniqParser.NCName);
            }
        }
        catch (re) {
            if (re instanceof antlr.RecognitionException) {
                this.errorHandler.reportError(this, re);
                this.errorHandler.recover(this, re);
            } else {
                throw re;
            }
        }
        finally {
            this.exitRule();
        }
        return localContext;
    }
    public predicateList(): PredicateListContext {
        let localContext = new PredicateListContext(this.context, this.state);
        this.enterRule(localContext, 276, jsoniqParser.RULE_predicateList);
        let _la: number;
        try {
            this.enterOuterAlt(localContext, 1);
            {
            this.state = 1508;
            this.errorHandler.sync(this);
            _la = this.tokenStream.LA(1);
            while (_la === 52) {
                {
                {
                this.state = 1505;
                this.predicate();
                }
                }
                this.state = 1510;
                this.errorHandler.sync(this);
                _la = this.tokenStream.LA(1);
            }
            }
        }
        catch (re) {
            if (re instanceof antlr.RecognitionException) {
                this.errorHandler.reportError(this, re);
                this.errorHandler.recover(this, re);
            } else {
                throw re;
            }
        }
        finally {
            this.exitRule();
        }
        return localContext;
    }
    public kindTest(): KindTestContext {
        let localContext = new KindTestContext(this.context, this.state);
        this.enterRule(localContext, 278, jsoniqParser.RULE_kindTest);
        try {
            this.state = 1522;
            this.errorHandler.sync(this);
            switch (this.tokenStream.LA(1)) {
            case jsoniqParser.Kdocument_node:
                this.enterOuterAlt(localContext, 1);
                {
                this.state = 1511;
                this.documentTest();
                }
                break;
            case jsoniqParser.Kelement:
                this.enterOuterAlt(localContext, 2);
                {
                this.state = 1512;
                this.elementTest();
                }
                break;
            case jsoniqParser.Kattribute:
                this.enterOuterAlt(localContext, 3);
                {
                this.state = 1513;
                this.attributeTest();
                }
                break;
            case jsoniqParser.Kschema_element:
                this.enterOuterAlt(localContext, 4);
                {
                this.state = 1514;
                this.schemaElementTest();
                }
                break;
            case jsoniqParser.Kschema_attribute:
                this.enterOuterAlt(localContext, 5);
                {
                this.state = 1515;
                this.schemaAttributeTest();
                }
                break;
            case jsoniqParser.Kpi:
                this.enterOuterAlt(localContext, 6);
                {
                this.state = 1516;
                this.piTest();
                }
                break;
            case jsoniqParser.Kcomment:
                this.enterOuterAlt(localContext, 7);
                {
                this.state = 1517;
                this.commentTest();
                }
                break;
            case jsoniqParser.Ktext:
                this.enterOuterAlt(localContext, 8);
                {
                this.state = 1518;
                this.textTest();
                }
                break;
            case jsoniqParser.Knamespace_node:
                this.enterOuterAlt(localContext, 9);
                {
                this.state = 1519;
                this.namespaceNodeTest();
                }
                break;
            case jsoniqParser.Kbinary:
                this.enterOuterAlt(localContext, 10);
                {
                this.state = 1520;
                this.binaryNodeTest();
                }
                break;
            case jsoniqParser.Knode:
                this.enterOuterAlt(localContext, 11);
                {
                this.state = 1521;
                this.anyKindTest();
                }
                break;
            default:
                throw new antlr.NoViableAltException(this);
            }
        }
        catch (re) {
            if (re instanceof antlr.RecognitionException) {
                this.errorHandler.reportError(this, re);
                this.errorHandler.recover(this, re);
            } else {
                throw re;
            }
        }
        finally {
            this.exitRule();
        }
        return localContext;
    }
    public anyKindTest(): AnyKindTestContext {
        let localContext = new AnyKindTestContext(this.context, this.state);
        this.enterRule(localContext, 280, jsoniqParser.RULE_anyKindTest);
        try {
            this.enterOuterAlt(localContext, 1);
            {
            this.state = 1524;
            this.match(jsoniqParser.Knode);
            this.state = 1525;
            this.match(jsoniqParser.Klparen);
            this.state = 1526;
            this.match(jsoniqParser.Krparen);
            }
        }
        catch (re) {
            if (re instanceof antlr.RecognitionException) {
                this.errorHandler.reportError(this, re);
                this.errorHandler.recover(this, re);
            } else {
                throw re;
            }
        }
        finally {
            this.exitRule();
        }
        return localContext;
    }
    public binaryNodeTest(): BinaryNodeTestContext {
        let localContext = new BinaryNodeTestContext(this.context, this.state);
        this.enterRule(localContext, 282, jsoniqParser.RULE_binaryNodeTest);
        try {
            this.enterOuterAlt(localContext, 1);
            {
            this.state = 1528;
            this.match(jsoniqParser.Kbinary);
            this.state = 1529;
            this.match(jsoniqParser.Klparen);
            this.state = 1530;
            this.match(jsoniqParser.Krparen);
            }
        }
        catch (re) {
            if (re instanceof antlr.RecognitionException) {
                this.errorHandler.reportError(this, re);
                this.errorHandler.recover(this, re);
            } else {
                throw re;
            }
        }
        finally {
            this.exitRule();
        }
        return localContext;
    }
    public documentTest(): DocumentTestContext {
        let localContext = new DocumentTestContext(this.context, this.state);
        this.enterRule(localContext, 284, jsoniqParser.RULE_documentTest);
        try {
            this.enterOuterAlt(localContext, 1);
            {
            this.state = 1532;
            this.match(jsoniqParser.Kdocument_node);
            this.state = 1533;
            this.match(jsoniqParser.Klparen);
            this.state = 1536;
            this.errorHandler.sync(this);
            switch (this.tokenStream.LA(1)) {
            case jsoniqParser.Kelement:
                {
                this.state = 1534;
                this.elementTest();
                }
                break;
            case jsoniqParser.Kschema_element:
                {
                this.state = 1535;
                this.schemaElementTest();
                }
                break;
            case jsoniqParser.Krparen:
                break;
            default:
                break;
            }
            this.state = 1538;
            this.match(jsoniqParser.Krparen);
            }
        }
        catch (re) {
            if (re instanceof antlr.RecognitionException) {
                this.errorHandler.reportError(this, re);
                this.errorHandler.recover(this, re);
            } else {
                throw re;
            }
        }
        finally {
            this.exitRule();
        }
        return localContext;
    }
    public textTest(): TextTestContext {
        let localContext = new TextTestContext(this.context, this.state);
        this.enterRule(localContext, 286, jsoniqParser.RULE_textTest);
        try {
            this.enterOuterAlt(localContext, 1);
            {
            this.state = 1540;
            this.match(jsoniqParser.Ktext);
            this.state = 1541;
            this.match(jsoniqParser.Klparen);
            this.state = 1542;
            this.match(jsoniqParser.Krparen);
            }
        }
        catch (re) {
            if (re instanceof antlr.RecognitionException) {
                this.errorHandler.reportError(this, re);
                this.errorHandler.recover(this, re);
            } else {
                throw re;
            }
        }
        finally {
            this.exitRule();
        }
        return localContext;
    }
    public commentTest(): CommentTestContext {
        let localContext = new CommentTestContext(this.context, this.state);
        this.enterRule(localContext, 288, jsoniqParser.RULE_commentTest);
        try {
            this.enterOuterAlt(localContext, 1);
            {
            this.state = 1544;
            this.match(jsoniqParser.Kcomment);
            this.state = 1545;
            this.match(jsoniqParser.Klparen);
            this.state = 1546;
            this.match(jsoniqParser.Krparen);
            }
        }
        catch (re) {
            if (re instanceof antlr.RecognitionException) {
                this.errorHandler.reportError(this, re);
                this.errorHandler.recover(this, re);
            } else {
                throw re;
            }
        }
        finally {
            this.exitRule();
        }
        return localContext;
    }
    public namespaceNodeTest(): NamespaceNodeTestContext {
        let localContext = new NamespaceNodeTestContext(this.context, this.state);
        this.enterRule(localContext, 290, jsoniqParser.RULE_namespaceNodeTest);
        try {
            this.enterOuterAlt(localContext, 1);
            {
            this.state = 1548;
            this.match(jsoniqParser.Knamespace_node);
            this.state = 1549;
            this.match(jsoniqParser.Klparen);
            this.state = 1550;
            this.match(jsoniqParser.Krparen);
            }
        }
        catch (re) {
            if (re instanceof antlr.RecognitionException) {
                this.errorHandler.reportError(this, re);
                this.errorHandler.recover(this, re);
            } else {
                throw re;
            }
        }
        finally {
            this.exitRule();
        }
        return localContext;
    }
    public piTest(): PiTestContext {
        let localContext = new PiTestContext(this.context, this.state);
        this.enterRule(localContext, 292, jsoniqParser.RULE_piTest);
        try {
            this.enterOuterAlt(localContext, 1);
            {
            this.state = 1552;
            this.match(jsoniqParser.Kpi);
            this.state = 1553;
            this.match(jsoniqParser.Klparen);
            this.state = 1556;
            this.errorHandler.sync(this);
            switch (this.tokenStream.LA(1)) {
            case jsoniqParser.NCName:
                {
                this.state = 1554;
                this.match(jsoniqParser.NCName);
                }
                break;
            case jsoniqParser.STRING:
                {
                this.state = 1555;
                this.stringLiteral();
                }
                break;
            case jsoniqParser.Krparen:
                break;
            default:
                break;
            }
            this.state = 1558;
            this.match(jsoniqParser.Krparen);
            }
        }
        catch (re) {
            if (re instanceof antlr.RecognitionException) {
                this.errorHandler.reportError(this, re);
                this.errorHandler.recover(this, re);
            } else {
                throw re;
            }
        }
        finally {
            this.exitRule();
        }
        return localContext;
    }
    public attributeTest(): AttributeTestContext {
        let localContext = new AttributeTestContext(this.context, this.state);
        this.enterRule(localContext, 294, jsoniqParser.RULE_attributeTest);
        let _la: number;
        try {
            this.enterOuterAlt(localContext, 1);
            {
            this.state = 1560;
            this.match(jsoniqParser.Kattribute);
            this.state = 1561;
            this.match(jsoniqParser.Klparen);
            this.state = 1567;
            this.errorHandler.sync(this);
            _la = this.tokenStream.LA(1);
            if (_la === 10 || ((((_la - 60)) & ~0x1F) === 0 && ((1 << (_la - 60)) & 4294967295) !== 0) || ((((_la - 92)) & ~0x1F) === 0 && ((1 << (_la - 92)) & 4294967295) !== 0) || ((((_la - 124)) & ~0x1F) === 0 && ((1 << (_la - 124)) & 4294967295) !== 0) || ((((_la - 156)) & ~0x1F) === 0 && ((1 << (_la - 156)) & 41943039) !== 0) || _la === 188) {
                {
                this.state = 1562;
                this.attributeNameOrWildcard();
                this.state = 1565;
                this.errorHandler.sync(this);
                _la = this.tokenStream.LA(1);
                if (_la === 13) {
                    {
                    this.state = 1563;
                    this.match(jsoniqParser.Kcomma);
                    this.state = 1564;
                    localContext._type_ = this.typeName();
                    }
                }

                }
            }

            this.state = 1569;
            this.match(jsoniqParser.Krparen);
            }
        }
        catch (re) {
            if (re instanceof antlr.RecognitionException) {
                this.errorHandler.reportError(this, re);
                this.errorHandler.recover(this, re);
            } else {
                throw re;
            }
        }
        finally {
            this.exitRule();
        }
        return localContext;
    }
    public attributeNameOrWildcard(): AttributeNameOrWildcardContext {
        let localContext = new AttributeNameOrWildcardContext(this.context, this.state);
        this.enterRule(localContext, 296, jsoniqParser.RULE_attributeNameOrWildcard);
        try {
            this.state = 1573;
            this.errorHandler.sync(this);
            switch (this.tokenStream.LA(1)) {
            case jsoniqParser.Kfor:
            case jsoniqParser.Klet:
            case jsoniqParser.Kwhere:
            case jsoniqParser.Kgroup:
            case jsoniqParser.Kby:
            case jsoniqParser.Korder:
            case jsoniqParser.Kreturn:
            case jsoniqParser.Kif:
            case jsoniqParser.Kin:
            case jsoniqParser.Kas:
            case jsoniqParser.Kat:
            case jsoniqParser.Kallowing:
            case jsoniqParser.Kempty:
            case jsoniqParser.Kcount:
            case jsoniqParser.Kstable:
            case jsoniqParser.Kascending:
            case jsoniqParser.Kdescending:
            case jsoniqParser.Ksome:
            case jsoniqParser.Kevery:
            case jsoniqParser.Ksatisfies:
            case jsoniqParser.Kcollation:
            case jsoniqParser.Kgreatest:
            case jsoniqParser.Kleast:
            case jsoniqParser.Kswitch:
            case jsoniqParser.Kcase:
            case jsoniqParser.Ktry:
            case jsoniqParser.Kcatch:
            case jsoniqParser.Kdefault:
            case jsoniqParser.Kthen:
            case jsoniqParser.Kelse:
            case jsoniqParser.Ktypeswitch:
            case jsoniqParser.Kor:
            case jsoniqParser.Kand:
            case jsoniqParser.Knot:
            case jsoniqParser.Kto:
            case jsoniqParser.Kinstance:
            case jsoniqParser.Kof:
            case jsoniqParser.Kstatically:
            case jsoniqParser.Kis:
            case jsoniqParser.Ktreat:
            case jsoniqParser.Kcast:
            case jsoniqParser.Kcastable:
            case jsoniqParser.Kversion:
            case jsoniqParser.Kjsoniq:
            case jsoniqParser.Kunordered:
            case jsoniqParser.Ktrue:
            case jsoniqParser.Kfalse:
            case jsoniqParser.Ktype:
            case jsoniqParser.Kvalidate:
            case jsoniqParser.Kannotate:
            case jsoniqParser.Kdeclare:
            case jsoniqParser.Kcontext:
            case jsoniqParser.Kitem:
            case jsoniqParser.Kvariable:
            case jsoniqParser.Kinsert:
            case jsoniqParser.Kdelete:
            case jsoniqParser.Krename:
            case jsoniqParser.Kreplace:
            case jsoniqParser.Kcopy:
            case jsoniqParser.Kmodify:
            case jsoniqParser.Kappend:
            case jsoniqParser.Kinto:
            case jsoniqParser.Kvalue:
            case jsoniqParser.Kwith:
            case jsoniqParser.Kposition:
            case jsoniqParser.Kjson:
            case jsoniqParser.Kupdating:
            case jsoniqParser.Kcreate:
            case jsoniqParser.Kcollection:
            case jsoniqParser.Ktable:
            case jsoniqParser.Kdeltafile:
            case jsoniqParser.Kicebergtable:
            case jsoniqParser.Ktruncate:
            case jsoniqParser.Kfirst:
            case jsoniqParser.Klast:
            case jsoniqParser.Kfrom:
            case jsoniqParser.Kedit:
            case jsoniqParser.Kafter:
            case jsoniqParser.Kbefore:
            case jsoniqParser.Kimport:
            case jsoniqParser.Kschema:
            case jsoniqParser.Knamespace:
            case jsoniqParser.Kelement:
            case jsoniqParser.Kslash:
            case jsoniqParser.Kdslash:
            case jsoniqParser.Kat_symbol:
            case jsoniqParser.Kchild:
            case jsoniqParser.Kdescendant:
            case jsoniqParser.Kattribute:
            case jsoniqParser.Kself:
            case jsoniqParser.Kdescendant_or_self:
            case jsoniqParser.Kfollowing_sibling:
            case jsoniqParser.Kfollowing:
            case jsoniqParser.Kparent:
            case jsoniqParser.Kancestor:
            case jsoniqParser.Kpreceding_sibling:
            case jsoniqParser.Kpreceding:
            case jsoniqParser.Kancestor_or_self:
            case jsoniqParser.Knode:
            case jsoniqParser.Kbinary:
            case jsoniqParser.Kdocument:
            case jsoniqParser.Kdocument_node:
            case jsoniqParser.Ktext:
            case jsoniqParser.Kpi:
            case jsoniqParser.Knamespace_node:
            case jsoniqParser.Kschema_attribute:
            case jsoniqParser.Kschema_element:
            case jsoniqParser.Karray_node:
            case jsoniqParser.Kboolean_node:
            case jsoniqParser.Knull_node:
            case jsoniqParser.Knumber_node:
            case jsoniqParser.Kobject_node:
            case jsoniqParser.Kcomment:
            case jsoniqParser.Kbreak:
            case jsoniqParser.Kloop:
            case jsoniqParser.Kcontinue:
            case jsoniqParser.Kexit:
            case jsoniqParser.Kreturning:
            case jsoniqParser.Kwhile:
            case jsoniqParser.NullLiteral:
            case jsoniqParser.NCName:
                this.enterOuterAlt(localContext, 1);
                {
                this.state = 1571;
                this.attributeName();
                }
                break;
            case jsoniqParser.Kasterisk:
                this.enterOuterAlt(localContext, 2);
                {
                this.state = 1572;
                this.match(jsoniqParser.Kasterisk);
                }
                break;
            default:
                throw new antlr.NoViableAltException(this);
            }
        }
        catch (re) {
            if (re instanceof antlr.RecognitionException) {
                this.errorHandler.reportError(this, re);
                this.errorHandler.recover(this, re);
            } else {
                throw re;
            }
        }
        finally {
            this.exitRule();
        }
        return localContext;
    }
    public schemaAttributeTest(): SchemaAttributeTestContext {
        let localContext = new SchemaAttributeTestContext(this.context, this.state);
        this.enterRule(localContext, 298, jsoniqParser.RULE_schemaAttributeTest);
        try {
            this.enterOuterAlt(localContext, 1);
            {
            this.state = 1575;
            this.match(jsoniqParser.Kschema_attribute);
            this.state = 1576;
            this.match(jsoniqParser.Klparen);
            this.state = 1577;
            this.attributeDeclaration();
            this.state = 1578;
            this.match(jsoniqParser.Krparen);
            }
        }
        catch (re) {
            if (re instanceof antlr.RecognitionException) {
                this.errorHandler.reportError(this, re);
                this.errorHandler.recover(this, re);
            } else {
                throw re;
            }
        }
        finally {
            this.exitRule();
        }
        return localContext;
    }
    public attributeDeclaration(): AttributeDeclarationContext {
        let localContext = new AttributeDeclarationContext(this.context, this.state);
        this.enterRule(localContext, 300, jsoniqParser.RULE_attributeDeclaration);
        try {
            this.enterOuterAlt(localContext, 1);
            {
            this.state = 1580;
            this.attributeName();
            }
        }
        catch (re) {
            if (re instanceof antlr.RecognitionException) {
                this.errorHandler.reportError(this, re);
                this.errorHandler.recover(this, re);
            } else {
                throw re;
            }
        }
        finally {
            this.exitRule();
        }
        return localContext;
    }
    public elementTest(): ElementTestContext {
        let localContext = new ElementTestContext(this.context, this.state);
        this.enterRule(localContext, 302, jsoniqParser.RULE_elementTest);
        let _la: number;
        try {
            this.enterOuterAlt(localContext, 1);
            {
            this.state = 1582;
            this.match(jsoniqParser.Kelement);
            this.state = 1583;
            this.match(jsoniqParser.Klparen);
            this.state = 1592;
            this.errorHandler.sync(this);
            _la = this.tokenStream.LA(1);
            if (_la === 10 || ((((_la - 60)) & ~0x1F) === 0 && ((1 << (_la - 60)) & 4294967295) !== 0) || ((((_la - 92)) & ~0x1F) === 0 && ((1 << (_la - 92)) & 4294967295) !== 0) || ((((_la - 124)) & ~0x1F) === 0 && ((1 << (_la - 124)) & 4294967295) !== 0) || ((((_la - 156)) & ~0x1F) === 0 && ((1 << (_la - 156)) & 41943039) !== 0) || _la === 188) {
                {
                this.state = 1584;
                this.elementNameOrWildcard();
                this.state = 1590;
                this.errorHandler.sync(this);
                _la = this.tokenStream.LA(1);
                if (_la === 13) {
                    {
                    this.state = 1585;
                    this.match(jsoniqParser.Kcomma);
                    this.state = 1586;
                    localContext._type_ = this.typeName();
                    this.state = 1588;
                    this.errorHandler.sync(this);
                    _la = this.tokenStream.LA(1);
                    if (_la === 180) {
                        {
                        this.state = 1587;
                        localContext._optional = this.match(jsoniqParser.ArgumentPlaceholder);
                        }
                    }

                    }
                }

                }
            }

            this.state = 1594;
            this.match(jsoniqParser.Krparen);
            }
        }
        catch (re) {
            if (re instanceof antlr.RecognitionException) {
                this.errorHandler.reportError(this, re);
                this.errorHandler.recover(this, re);
            } else {
                throw re;
            }
        }
        finally {
            this.exitRule();
        }
        return localContext;
    }
    public elementNameOrWildcard(): ElementNameOrWildcardContext {
        let localContext = new ElementNameOrWildcardContext(this.context, this.state);
        this.enterRule(localContext, 304, jsoniqParser.RULE_elementNameOrWildcard);
        try {
            this.state = 1598;
            this.errorHandler.sync(this);
            switch (this.tokenStream.LA(1)) {
            case jsoniqParser.Kfor:
            case jsoniqParser.Klet:
            case jsoniqParser.Kwhere:
            case jsoniqParser.Kgroup:
            case jsoniqParser.Kby:
            case jsoniqParser.Korder:
            case jsoniqParser.Kreturn:
            case jsoniqParser.Kif:
            case jsoniqParser.Kin:
            case jsoniqParser.Kas:
            case jsoniqParser.Kat:
            case jsoniqParser.Kallowing:
            case jsoniqParser.Kempty:
            case jsoniqParser.Kcount:
            case jsoniqParser.Kstable:
            case jsoniqParser.Kascending:
            case jsoniqParser.Kdescending:
            case jsoniqParser.Ksome:
            case jsoniqParser.Kevery:
            case jsoniqParser.Ksatisfies:
            case jsoniqParser.Kcollation:
            case jsoniqParser.Kgreatest:
            case jsoniqParser.Kleast:
            case jsoniqParser.Kswitch:
            case jsoniqParser.Kcase:
            case jsoniqParser.Ktry:
            case jsoniqParser.Kcatch:
            case jsoniqParser.Kdefault:
            case jsoniqParser.Kthen:
            case jsoniqParser.Kelse:
            case jsoniqParser.Ktypeswitch:
            case jsoniqParser.Kor:
            case jsoniqParser.Kand:
            case jsoniqParser.Knot:
            case jsoniqParser.Kto:
            case jsoniqParser.Kinstance:
            case jsoniqParser.Kof:
            case jsoniqParser.Kstatically:
            case jsoniqParser.Kis:
            case jsoniqParser.Ktreat:
            case jsoniqParser.Kcast:
            case jsoniqParser.Kcastable:
            case jsoniqParser.Kversion:
            case jsoniqParser.Kjsoniq:
            case jsoniqParser.Kunordered:
            case jsoniqParser.Ktrue:
            case jsoniqParser.Kfalse:
            case jsoniqParser.Ktype:
            case jsoniqParser.Kvalidate:
            case jsoniqParser.Kannotate:
            case jsoniqParser.Kdeclare:
            case jsoniqParser.Kcontext:
            case jsoniqParser.Kitem:
            case jsoniqParser.Kvariable:
            case jsoniqParser.Kinsert:
            case jsoniqParser.Kdelete:
            case jsoniqParser.Krename:
            case jsoniqParser.Kreplace:
            case jsoniqParser.Kcopy:
            case jsoniqParser.Kmodify:
            case jsoniqParser.Kappend:
            case jsoniqParser.Kinto:
            case jsoniqParser.Kvalue:
            case jsoniqParser.Kwith:
            case jsoniqParser.Kposition:
            case jsoniqParser.Kjson:
            case jsoniqParser.Kupdating:
            case jsoniqParser.Kcreate:
            case jsoniqParser.Kcollection:
            case jsoniqParser.Ktable:
            case jsoniqParser.Kdeltafile:
            case jsoniqParser.Kicebergtable:
            case jsoniqParser.Ktruncate:
            case jsoniqParser.Kfirst:
            case jsoniqParser.Klast:
            case jsoniqParser.Kfrom:
            case jsoniqParser.Kedit:
            case jsoniqParser.Kafter:
            case jsoniqParser.Kbefore:
            case jsoniqParser.Kimport:
            case jsoniqParser.Kschema:
            case jsoniqParser.Knamespace:
            case jsoniqParser.Kelement:
            case jsoniqParser.Kslash:
            case jsoniqParser.Kdslash:
            case jsoniqParser.Kat_symbol:
            case jsoniqParser.Kchild:
            case jsoniqParser.Kdescendant:
            case jsoniqParser.Kattribute:
            case jsoniqParser.Kself:
            case jsoniqParser.Kdescendant_or_self:
            case jsoniqParser.Kfollowing_sibling:
            case jsoniqParser.Kfollowing:
            case jsoniqParser.Kparent:
            case jsoniqParser.Kancestor:
            case jsoniqParser.Kpreceding_sibling:
            case jsoniqParser.Kpreceding:
            case jsoniqParser.Kancestor_or_self:
            case jsoniqParser.Knode:
            case jsoniqParser.Kbinary:
            case jsoniqParser.Kdocument:
            case jsoniqParser.Kdocument_node:
            case jsoniqParser.Ktext:
            case jsoniqParser.Kpi:
            case jsoniqParser.Knamespace_node:
            case jsoniqParser.Kschema_attribute:
            case jsoniqParser.Kschema_element:
            case jsoniqParser.Karray_node:
            case jsoniqParser.Kboolean_node:
            case jsoniqParser.Knull_node:
            case jsoniqParser.Knumber_node:
            case jsoniqParser.Kobject_node:
            case jsoniqParser.Kcomment:
            case jsoniqParser.Kbreak:
            case jsoniqParser.Kloop:
            case jsoniqParser.Kcontinue:
            case jsoniqParser.Kexit:
            case jsoniqParser.Kreturning:
            case jsoniqParser.Kwhile:
            case jsoniqParser.NullLiteral:
            case jsoniqParser.NCName:
                this.enterOuterAlt(localContext, 1);
                {
                this.state = 1596;
                this.elementName();
                }
                break;
            case jsoniqParser.Kasterisk:
                this.enterOuterAlt(localContext, 2);
                {
                this.state = 1597;
                this.match(jsoniqParser.Kasterisk);
                }
                break;
            default:
                throw new antlr.NoViableAltException(this);
            }
        }
        catch (re) {
            if (re instanceof antlr.RecognitionException) {
                this.errorHandler.reportError(this, re);
                this.errorHandler.recover(this, re);
            } else {
                throw re;
            }
        }
        finally {
            this.exitRule();
        }
        return localContext;
    }
    public schemaElementTest(): SchemaElementTestContext {
        let localContext = new SchemaElementTestContext(this.context, this.state);
        this.enterRule(localContext, 306, jsoniqParser.RULE_schemaElementTest);
        try {
            this.enterOuterAlt(localContext, 1);
            {
            this.state = 1600;
            this.match(jsoniqParser.Kschema_element);
            this.state = 1601;
            this.match(jsoniqParser.Klparen);
            this.state = 1602;
            this.elementDeclaration();
            this.state = 1603;
            this.match(jsoniqParser.Krparen);
            }
        }
        catch (re) {
            if (re instanceof antlr.RecognitionException) {
                this.errorHandler.reportError(this, re);
                this.errorHandler.recover(this, re);
            } else {
                throw re;
            }
        }
        finally {
            this.exitRule();
        }
        return localContext;
    }
    public elementDeclaration(): ElementDeclarationContext {
        let localContext = new ElementDeclarationContext(this.context, this.state);
        this.enterRule(localContext, 308, jsoniqParser.RULE_elementDeclaration);
        try {
            this.enterOuterAlt(localContext, 1);
            {
            this.state = 1605;
            this.elementName();
            }
        }
        catch (re) {
            if (re instanceof antlr.RecognitionException) {
                this.errorHandler.reportError(this, re);
                this.errorHandler.recover(this, re);
            } else {
                throw re;
            }
        }
        finally {
            this.exitRule();
        }
        return localContext;
    }
    public attributeName(): AttributeNameContext {
        let localContext = new AttributeNameContext(this.context, this.state);
        this.enterRule(localContext, 310, jsoniqParser.RULE_attributeName);
        try {
            this.enterOuterAlt(localContext, 1);
            {
            this.state = 1607;
            this.qname();
            }
        }
        catch (re) {
            if (re instanceof antlr.RecognitionException) {
                this.errorHandler.reportError(this, re);
                this.errorHandler.recover(this, re);
            } else {
                throw re;
            }
        }
        finally {
            this.exitRule();
        }
        return localContext;
    }
    public elementName(): ElementNameContext {
        let localContext = new ElementNameContext(this.context, this.state);
        this.enterRule(localContext, 312, jsoniqParser.RULE_elementName);
        try {
            this.enterOuterAlt(localContext, 1);
            {
            this.state = 1609;
            this.qname();
            }
        }
        catch (re) {
            if (re instanceof antlr.RecognitionException) {
                this.errorHandler.reportError(this, re);
                this.errorHandler.recover(this, re);
            } else {
                throw re;
            }
        }
        finally {
            this.exitRule();
        }
        return localContext;
    }
    public simpleTypeName(): SimpleTypeNameContext {
        let localContext = new SimpleTypeNameContext(this.context, this.state);
        this.enterRule(localContext, 314, jsoniqParser.RULE_simpleTypeName);
        try {
            this.enterOuterAlt(localContext, 1);
            {
            this.state = 1611;
            this.typeName();
            }
        }
        catch (re) {
            if (re instanceof antlr.RecognitionException) {
                this.errorHandler.reportError(this, re);
                this.errorHandler.recover(this, re);
            } else {
                throw re;
            }
        }
        finally {
            this.exitRule();
        }
        return localContext;
    }
    public typeName(): TypeNameContext {
        let localContext = new TypeNameContext(this.context, this.state);
        this.enterRule(localContext, 316, jsoniqParser.RULE_typeName);
        try {
            this.enterOuterAlt(localContext, 1);
            {
            this.state = 1613;
            this.qname();
            }
        }
        catch (re) {
            if (re instanceof antlr.RecognitionException) {
                this.errorHandler.reportError(this, re);
                this.errorHandler.recover(this, re);
            } else {
                throw re;
            }
        }
        finally {
            this.exitRule();
        }
        return localContext;
    }
    public sequenceType(): SequenceTypeContext {
        let localContext = new SequenceTypeContext(this.context, this.state);
        this.enterRule(localContext, 318, jsoniqParser.RULE_sequenceType);
        try {
            this.state = 1623;
            this.errorHandler.sync(this);
            switch (this.tokenStream.LA(1)) {
            case jsoniqParser.Klparen:
                this.enterOuterAlt(localContext, 1);
                {
                this.state = 1615;
                this.match(jsoniqParser.Klparen);
                this.state = 1616;
                this.match(jsoniqParser.Krparen);
                }
                break;
            case jsoniqParser.Kfunction:
            case jsoniqParser.Kfor:
            case jsoniqParser.Klet:
            case jsoniqParser.Kwhere:
            case jsoniqParser.Kgroup:
            case jsoniqParser.Kby:
            case jsoniqParser.Korder:
            case jsoniqParser.Kreturn:
            case jsoniqParser.Kif:
            case jsoniqParser.Kin:
            case jsoniqParser.Kas:
            case jsoniqParser.Kat:
            case jsoniqParser.Kallowing:
            case jsoniqParser.Kempty:
            case jsoniqParser.Kcount:
            case jsoniqParser.Kstable:
            case jsoniqParser.Kascending:
            case jsoniqParser.Kdescending:
            case jsoniqParser.Ksome:
            case jsoniqParser.Kevery:
            case jsoniqParser.Ksatisfies:
            case jsoniqParser.Kcollation:
            case jsoniqParser.Kgreatest:
            case jsoniqParser.Kleast:
            case jsoniqParser.Kswitch:
            case jsoniqParser.Kcase:
            case jsoniqParser.Ktry:
            case jsoniqParser.Kcatch:
            case jsoniqParser.Kdefault:
            case jsoniqParser.Kthen:
            case jsoniqParser.Kelse:
            case jsoniqParser.Ktypeswitch:
            case jsoniqParser.Kor:
            case jsoniqParser.Kand:
            case jsoniqParser.Knot:
            case jsoniqParser.Kto:
            case jsoniqParser.Kinstance:
            case jsoniqParser.Kof:
            case jsoniqParser.Kstatically:
            case jsoniqParser.Kis:
            case jsoniqParser.Ktreat:
            case jsoniqParser.Kcast:
            case jsoniqParser.Kcastable:
            case jsoniqParser.Kversion:
            case jsoniqParser.Kjsoniq:
            case jsoniqParser.Kunordered:
            case jsoniqParser.Ktrue:
            case jsoniqParser.Kfalse:
            case jsoniqParser.Ktype:
            case jsoniqParser.Kvalidate:
            case jsoniqParser.Kannotate:
            case jsoniqParser.Kdeclare:
            case jsoniqParser.Kcontext:
            case jsoniqParser.Kitem:
            case jsoniqParser.Kvariable:
            case jsoniqParser.Kinsert:
            case jsoniqParser.Kdelete:
            case jsoniqParser.Krename:
            case jsoniqParser.Kreplace:
            case jsoniqParser.Kcopy:
            case jsoniqParser.Kmodify:
            case jsoniqParser.Kappend:
            case jsoniqParser.Kinto:
            case jsoniqParser.Kvalue:
            case jsoniqParser.Kwith:
            case jsoniqParser.Kposition:
            case jsoniqParser.Kjson:
            case jsoniqParser.Kupdating:
            case jsoniqParser.Kcreate:
            case jsoniqParser.Kcollection:
            case jsoniqParser.Ktable:
            case jsoniqParser.Kdeltafile:
            case jsoniqParser.Kicebergtable:
            case jsoniqParser.Ktruncate:
            case jsoniqParser.Kfirst:
            case jsoniqParser.Klast:
            case jsoniqParser.Kfrom:
            case jsoniqParser.Kedit:
            case jsoniqParser.Kafter:
            case jsoniqParser.Kbefore:
            case jsoniqParser.Kimport:
            case jsoniqParser.Kschema:
            case jsoniqParser.Knamespace:
            case jsoniqParser.Kelement:
            case jsoniqParser.Kslash:
            case jsoniqParser.Kdslash:
            case jsoniqParser.Kat_symbol:
            case jsoniqParser.Kchild:
            case jsoniqParser.Kdescendant:
            case jsoniqParser.Kattribute:
            case jsoniqParser.Kself:
            case jsoniqParser.Kdescendant_or_self:
            case jsoniqParser.Kfollowing_sibling:
            case jsoniqParser.Kfollowing:
            case jsoniqParser.Kparent:
            case jsoniqParser.Kancestor:
            case jsoniqParser.Kpreceding_sibling:
            case jsoniqParser.Kpreceding:
            case jsoniqParser.Kancestor_or_self:
            case jsoniqParser.Knode:
            case jsoniqParser.Kbinary:
            case jsoniqParser.Kdocument:
            case jsoniqParser.Kdocument_node:
            case jsoniqParser.Ktext:
            case jsoniqParser.Kpi:
            case jsoniqParser.Knamespace_node:
            case jsoniqParser.Kschema_attribute:
            case jsoniqParser.Kschema_element:
            case jsoniqParser.Karray_node:
            case jsoniqParser.Kboolean_node:
            case jsoniqParser.Knull_node:
            case jsoniqParser.Knumber_node:
            case jsoniqParser.Kobject_node:
            case jsoniqParser.Kcomment:
            case jsoniqParser.Kbreak:
            case jsoniqParser.Kloop:
            case jsoniqParser.Kcontinue:
            case jsoniqParser.Kexit:
            case jsoniqParser.Kreturning:
            case jsoniqParser.Kwhile:
            case jsoniqParser.NullLiteral:
            case jsoniqParser.NCName:
                this.enterOuterAlt(localContext, 2);
                {
                this.state = 1617;
                localContext._item = this.itemType();
                this.state = 1621;
                this.errorHandler.sync(this);
                switch (this.interpreter.adaptivePredict(this.tokenStream, 146, this.context) ) {
                case 1:
                    {
                    this.state = 1618;
                    localContext._s180 = this.match(jsoniqParser.ArgumentPlaceholder);
                    localContext._question.push(localContext._s180!);
                    }
                    break;
                case 2:
                    {
                    this.state = 1619;
                    localContext._s10 = this.match(jsoniqParser.Kasterisk);
                    localContext._star.push(localContext._s10!);
                    }
                    break;
                case 3:
                    {
                    this.state = 1620;
                    localContext._s46 = this.match(jsoniqParser.Kplus);
                    localContext._plus.push(localContext._s46!);
                    }
                    break;
                }
                }
                break;
            default:
                throw new antlr.NoViableAltException(this);
            }
        }
        catch (re) {
            if (re instanceof antlr.RecognitionException) {
                this.errorHandler.reportError(this, re);
                this.errorHandler.recover(this, re);
            } else {
                throw re;
            }
        }
        finally {
            this.exitRule();
        }
        return localContext;
    }
    public objectConstructor(): ObjectConstructorContext {
        let localContext = new ObjectConstructorContext(this.context, this.state);
        this.enterRule(localContext, 320, jsoniqParser.RULE_objectConstructor);
        let _la: number;
        try {
            this.state = 1641;
            this.errorHandler.sync(this);
            switch (this.tokenStream.LA(1)) {
            case jsoniqParser.Klbrace:
                this.enterOuterAlt(localContext, 1);
                {
                this.state = 1625;
                this.match(jsoniqParser.Klbrace);
                this.state = 1634;
                this.errorHandler.sync(this);
                _la = this.tokenStream.LA(1);
                if ((((_la) & ~0x1F) === 0 && ((1 << _la) & 1073812816) !== 0) || ((((_la - 46)) & ~0x1F) === 0 && ((1 << (_la - 46)) & 4294957635) !== 0) || ((((_la - 78)) & ~0x1F) === 0 && ((1 << (_la - 78)) & 4294967295) !== 0) || ((((_la - 110)) & ~0x1F) === 0 && ((1 << (_la - 110)) & 4294967295) !== 0) || ((((_la - 142)) & ~0x1F) === 0 && ((1 << (_la - 142)) & 4294967295) !== 0) || ((((_la - 174)) & ~0x1F) === 0 && ((1 << (_la - 174)) & 16831) !== 0)) {
                    {
                    this.state = 1626;
                    this.pairConstructor();
                    this.state = 1631;
                    this.errorHandler.sync(this);
                    _la = this.tokenStream.LA(1);
                    while (_la === 13) {
                        {
                        {
                        this.state = 1627;
                        this.match(jsoniqParser.Kcomma);
                        this.state = 1628;
                        this.pairConstructor();
                        }
                        }
                        this.state = 1633;
                        this.errorHandler.sync(this);
                        _la = this.tokenStream.LA(1);
                    }
                    }
                }

                this.state = 1636;
                this.match(jsoniqParser.Krbrace);
                }
                break;
            case jsoniqParser.Kobject_start:
                this.enterOuterAlt(localContext, 2);
                {
                this.state = 1637;
                localContext._s58 = this.match(jsoniqParser.Kobject_start);
                localContext._merge_operator.push(localContext._s58!);
                this.state = 1638;
                this.expr();
                this.state = 1639;
                this.match(jsoniqParser.Kobject_end);
                }
                break;
            default:
                throw new antlr.NoViableAltException(this);
            }
        }
        catch (re) {
            if (re instanceof antlr.RecognitionException) {
                this.errorHandler.reportError(this, re);
                this.errorHandler.recover(this, re);
            } else {
                throw re;
            }
        }
        finally {
            this.exitRule();
        }
        return localContext;
    }
    public itemType(): ItemTypeContext {
        let localContext = new ItemTypeContext(this.context, this.state);
        this.enterRule(localContext, 322, jsoniqParser.RULE_itemType);
        try {
            this.state = 1646;
            this.errorHandler.sync(this);
            switch (this.interpreter.adaptivePredict(this.tokenStream, 151, this.context) ) {
            case 1:
                this.enterOuterAlt(localContext, 1);
                {
                this.state = 1643;
                this.qname();
                }
                break;
            case 2:
                this.enterOuterAlt(localContext, 2);
                {
                this.state = 1644;
                this.match(jsoniqParser.NullLiteral);
                }
                break;
            case 3:
                this.enterOuterAlt(localContext, 3);
                {
                this.state = 1645;
                this.functionTest();
                }
                break;
            }
        }
        catch (re) {
            if (re instanceof antlr.RecognitionException) {
                this.errorHandler.reportError(this, re);
                this.errorHandler.recover(this, re);
            } else {
                throw re;
            }
        }
        finally {
            this.exitRule();
        }
        return localContext;
    }
    public functionTest(): FunctionTestContext {
        let localContext = new FunctionTestContext(this.context, this.state);
        this.enterRule(localContext, 324, jsoniqParser.RULE_functionTest);
        try {
            this.enterOuterAlt(localContext, 1);
            {
            this.state = 1650;
            this.errorHandler.sync(this);
            switch (this.interpreter.adaptivePredict(this.tokenStream, 152, this.context) ) {
            case 1:
                {
                this.state = 1648;
                this.anyFunctionTest();
                }
                break;
            case 2:
                {
                this.state = 1649;
                this.typedFunctionTest();
                }
                break;
            }
            }
        }
        catch (re) {
            if (re instanceof antlr.RecognitionException) {
                this.errorHandler.reportError(this, re);
                this.errorHandler.recover(this, re);
            } else {
                throw re;
            }
        }
        finally {
            this.exitRule();
        }
        return localContext;
    }
    public anyFunctionTest(): AnyFunctionTestContext {
        let localContext = new AnyFunctionTestContext(this.context, this.state);
        this.enterRule(localContext, 326, jsoniqParser.RULE_anyFunctionTest);
        try {
            this.enterOuterAlt(localContext, 1);
            {
            this.state = 1652;
            this.match(jsoniqParser.Kfunction);
            this.state = 1653;
            this.match(jsoniqParser.Klparen);
            this.state = 1654;
            this.match(jsoniqParser.Kasterisk);
            this.state = 1655;
            this.match(jsoniqParser.Krparen);
            }
        }
        catch (re) {
            if (re instanceof antlr.RecognitionException) {
                this.errorHandler.reportError(this, re);
                this.errorHandler.recover(this, re);
            } else {
                throw re;
            }
        }
        finally {
            this.exitRule();
        }
        return localContext;
    }
    public typedFunctionTest(): TypedFunctionTestContext {
        let localContext = new TypedFunctionTestContext(this.context, this.state);
        this.enterRule(localContext, 328, jsoniqParser.RULE_typedFunctionTest);
        let _la: number;
        try {
            this.enterOuterAlt(localContext, 1);
            {
            this.state = 1657;
            this.match(jsoniqParser.Kfunction);
            this.state = 1658;
            this.match(jsoniqParser.Klparen);
            this.state = 1667;
            this.errorHandler.sync(this);
            _la = this.tokenStream.LA(1);
            if (_la === 8 || _la === 30 || ((((_la - 60)) & ~0x1F) === 0 && ((1 << (_la - 60)) & 4294967295) !== 0) || ((((_la - 92)) & ~0x1F) === 0 && ((1 << (_la - 92)) & 4294967295) !== 0) || ((((_la - 124)) & ~0x1F) === 0 && ((1 << (_la - 124)) & 4294967295) !== 0) || ((((_la - 156)) & ~0x1F) === 0 && ((1 << (_la - 156)) & 41943039) !== 0) || _la === 188) {
                {
                this.state = 1659;
                localContext._sequenceType = this.sequenceType();
                localContext._st.push(localContext._sequenceType!);
                this.state = 1664;
                this.errorHandler.sync(this);
                _la = this.tokenStream.LA(1);
                while (_la === 13) {
                    {
                    {
                    this.state = 1660;
                    this.match(jsoniqParser.Kcomma);
                    this.state = 1661;
                    localContext._sequenceType = this.sequenceType();
                    localContext._st.push(localContext._sequenceType!);
                    }
                    }
                    this.state = 1666;
                    this.errorHandler.sync(this);
                    _la = this.tokenStream.LA(1);
                }
                }
            }

            this.state = 1669;
            this.match(jsoniqParser.Krparen);
            this.state = 1670;
            this.match(jsoniqParser.Kas);
            this.state = 1671;
            localContext._rt = this.sequenceType();
            }
        }
        catch (re) {
            if (re instanceof antlr.RecognitionException) {
                this.errorHandler.reportError(this, re);
                this.errorHandler.recover(this, re);
            } else {
                throw re;
            }
        }
        finally {
            this.exitRule();
        }
        return localContext;
    }
    public singleType(): SingleTypeContext {
        let localContext = new SingleTypeContext(this.context, this.state);
        this.enterRule(localContext, 330, jsoniqParser.RULE_singleType);
        try {
            this.enterOuterAlt(localContext, 1);
            {
            this.state = 1673;
            localContext._item = this.itemType();
            this.state = 1675;
            this.errorHandler.sync(this);
            switch (this.interpreter.adaptivePredict(this.tokenStream, 155, this.context) ) {
            case 1:
                {
                this.state = 1674;
                localContext._s180 = this.match(jsoniqParser.ArgumentPlaceholder);
                localContext._question.push(localContext._s180!);
                }
                break;
            }
            }
        }
        catch (re) {
            if (re instanceof antlr.RecognitionException) {
                this.errorHandler.reportError(this, re);
                this.errorHandler.recover(this, re);
            } else {
                throw re;
            }
        }
        finally {
            this.exitRule();
        }
        return localContext;
    }
    public pairConstructor(): PairConstructorContext {
        let localContext = new PairConstructorContext(this.context, this.state);
        this.enterRule(localContext, 332, jsoniqParser.RULE_pairConstructor);
        let _la: number;
        try {
            this.enterOuterAlt(localContext, 1);
            {
            {
            this.state = 1677;
            localContext._lhs = this.exprSingle();
            }
            this.state = 1678;
            _la = this.tokenStream.LA(1);
            if(!(_la === 18 || _la === 180)) {
            this.errorHandler.recoverInline(this);
            }
            else {
                this.errorHandler.reportMatch(this);
                this.consume();
            }
            this.state = 1679;
            localContext._rhs = this.exprSingle();
            }
        }
        catch (re) {
            if (re instanceof antlr.RecognitionException) {
                this.errorHandler.reportError(this, re);
                this.errorHandler.recover(this, re);
            } else {
                throw re;
            }
        }
        finally {
            this.exitRule();
        }
        return localContext;
    }
    public arrayConstructor(): ArrayConstructorContext {
        let localContext = new ArrayConstructorContext(this.context, this.state);
        this.enterRule(localContext, 334, jsoniqParser.RULE_arrayConstructor);
        let _la: number;
        try {
            this.enterOuterAlt(localContext, 1);
            {
            this.state = 1681;
            this.match(jsoniqParser.Klbracket);
            this.state = 1683;
            this.errorHandler.sync(this);
            _la = this.tokenStream.LA(1);
            if ((((_la) & ~0x1F) === 0 && ((1 << _la) & 1073812816) !== 0) || ((((_la - 46)) & ~0x1F) === 0 && ((1 << (_la - 46)) & 4294957635) !== 0) || ((((_la - 78)) & ~0x1F) === 0 && ((1 << (_la - 78)) & 4294967295) !== 0) || ((((_la - 110)) & ~0x1F) === 0 && ((1 << (_la - 110)) & 4294967295) !== 0) || ((((_la - 142)) & ~0x1F) === 0 && ((1 << (_la - 142)) & 4294967295) !== 0) || ((((_la - 174)) & ~0x1F) === 0 && ((1 << (_la - 174)) & 16831) !== 0)) {
                {
                this.state = 1682;
                this.expr();
                }
            }

            this.state = 1685;
            this.match(jsoniqParser.Krbracket);
            }
        }
        catch (re) {
            if (re instanceof antlr.RecognitionException) {
                this.errorHandler.reportError(this, re);
                this.errorHandler.recover(this, re);
            } else {
                throw re;
            }
        }
        finally {
            this.exitRule();
        }
        return localContext;
    }
    public uriLiteral(): UriLiteralContext {
        let localContext = new UriLiteralContext(this.context, this.state);
        this.enterRule(localContext, 336, jsoniqParser.RULE_uriLiteral);
        try {
            this.enterOuterAlt(localContext, 1);
            {
            this.state = 1687;
            this.stringLiteral();
            }
        }
        catch (re) {
            if (re instanceof antlr.RecognitionException) {
                this.errorHandler.reportError(this, re);
                this.errorHandler.recover(this, re);
            } else {
                throw re;
            }
        }
        finally {
            this.exitRule();
        }
        return localContext;
    }
    public stringLiteral(): StringLiteralContext {
        let localContext = new StringLiteralContext(this.context, this.state);
        this.enterRule(localContext, 338, jsoniqParser.RULE_stringLiteral);
        try {
            this.enterOuterAlt(localContext, 1);
            {
            this.state = 1689;
            this.match(jsoniqParser.STRING);
            }
        }
        catch (re) {
            if (re instanceof antlr.RecognitionException) {
                this.errorHandler.reportError(this, re);
                this.errorHandler.recover(this, re);
            } else {
                throw re;
            }
        }
        finally {
            this.exitRule();
        }
        return localContext;
    }
    public keyWords(): KeyWordsContext {
        let localContext = new KeyWordsContext(this.context, this.state);
        this.enterRule(localContext, 340, jsoniqParser.RULE_keyWords);
        let _la: number;
        try {
            this.enterOuterAlt(localContext, 1);
            {
            this.state = 1691;
            _la = this.tokenStream.LA(1);
            if(!(((((_la - 60)) & ~0x1F) === 0 && ((1 << (_la - 60)) & 4294967295) !== 0) || ((((_la - 92)) & ~0x1F) === 0 && ((1 << (_la - 92)) & 4294967295) !== 0) || ((((_la - 124)) & ~0x1F) === 0 && ((1 << (_la - 124)) & 4294967295) !== 0) || ((((_la - 156)) & ~0x1F) === 0 && ((1 << (_la - 156)) & 41943039) !== 0))) {
            this.errorHandler.recoverInline(this);
            }
            else {
                this.errorHandler.reportMatch(this);
                this.consume();
            }
            }
        }
        catch (re) {
            if (re instanceof antlr.RecognitionException) {
                this.errorHandler.reportError(this, re);
                this.errorHandler.recover(this, re);
            } else {
                throw re;
            }
        }
        finally {
            this.exitRule();
        }
        return localContext;
    }

    public static readonly _serializedATN: number[] = [
        4,1,190,1694,2,0,7,0,2,1,7,1,2,2,7,2,2,3,7,3,2,4,7,4,2,5,7,5,2,6,
        7,6,2,7,7,7,2,8,7,8,2,9,7,9,2,10,7,10,2,11,7,11,2,12,7,12,2,13,7,
        13,2,14,7,14,2,15,7,15,2,16,7,16,2,17,7,17,2,18,7,18,2,19,7,19,2,
        20,7,20,2,21,7,21,2,22,7,22,2,23,7,23,2,24,7,24,2,25,7,25,2,26,7,
        26,2,27,7,27,2,28,7,28,2,29,7,29,2,30,7,30,2,31,7,31,2,32,7,32,2,
        33,7,33,2,34,7,34,2,35,7,35,2,36,7,36,2,37,7,37,2,38,7,38,2,39,7,
        39,2,40,7,40,2,41,7,41,2,42,7,42,2,43,7,43,2,44,7,44,2,45,7,45,2,
        46,7,46,2,47,7,47,2,48,7,48,2,49,7,49,2,50,7,50,2,51,7,51,2,52,7,
        52,2,53,7,53,2,54,7,54,2,55,7,55,2,56,7,56,2,57,7,57,2,58,7,58,2,
        59,7,59,2,60,7,60,2,61,7,61,2,62,7,62,2,63,7,63,2,64,7,64,2,65,7,
        65,2,66,7,66,2,67,7,67,2,68,7,68,2,69,7,69,2,70,7,70,2,71,7,71,2,
        72,7,72,2,73,7,73,2,74,7,74,2,75,7,75,2,76,7,76,2,77,7,77,2,78,7,
        78,2,79,7,79,2,80,7,80,2,81,7,81,2,82,7,82,2,83,7,83,2,84,7,84,2,
        85,7,85,2,86,7,86,2,87,7,87,2,88,7,88,2,89,7,89,2,90,7,90,2,91,7,
        91,2,92,7,92,2,93,7,93,2,94,7,94,2,95,7,95,2,96,7,96,2,97,7,97,2,
        98,7,98,2,99,7,99,2,100,7,100,2,101,7,101,2,102,7,102,2,103,7,103,
        2,104,7,104,2,105,7,105,2,106,7,106,2,107,7,107,2,108,7,108,2,109,
        7,109,2,110,7,110,2,111,7,111,2,112,7,112,2,113,7,113,2,114,7,114,
        2,115,7,115,2,116,7,116,2,117,7,117,2,118,7,118,2,119,7,119,2,120,
        7,120,2,121,7,121,2,122,7,122,2,123,7,123,2,124,7,124,2,125,7,125,
        2,126,7,126,2,127,7,127,2,128,7,128,2,129,7,129,2,130,7,130,2,131,
        7,131,2,132,7,132,2,133,7,133,2,134,7,134,2,135,7,135,2,136,7,136,
        2,137,7,137,2,138,7,138,2,139,7,139,2,140,7,140,2,141,7,141,2,142,
        7,142,2,143,7,143,2,144,7,144,2,145,7,145,2,146,7,146,2,147,7,147,
        2,148,7,148,2,149,7,149,2,150,7,150,2,151,7,151,2,152,7,152,2,153,
        7,153,2,154,7,154,2,155,7,155,2,156,7,156,2,157,7,157,2,158,7,158,
        2,159,7,159,2,160,7,160,2,161,7,161,2,162,7,162,2,163,7,163,2,164,
        7,164,2,165,7,165,2,166,7,166,2,167,7,167,2,168,7,168,2,169,7,169,
        2,170,7,170,1,0,1,0,1,0,1,1,1,1,1,1,1,1,1,1,3,1,351,8,1,1,1,1,1,
        3,1,355,8,1,1,2,1,2,1,2,1,3,1,3,1,3,1,3,1,3,1,3,1,3,1,3,1,4,1,4,
        1,4,3,4,371,8,4,1,4,1,4,5,4,375,8,4,10,4,12,4,378,9,4,1,4,1,4,1,
        4,5,4,383,8,4,10,4,12,4,386,9,4,1,5,1,5,1,6,5,6,391,8,6,10,6,12,
        6,394,9,6,1,7,1,7,1,7,1,8,1,8,3,8,401,8,8,1,9,1,9,1,9,1,9,1,9,1,
        9,1,9,1,9,1,9,1,9,1,9,1,9,1,9,3,9,416,8,9,1,10,1,10,1,10,1,11,1,
        11,1,11,1,11,1,11,1,11,1,12,1,12,1,12,1,12,1,13,1,13,1,13,1,13,1,
        14,1,14,1,14,1,14,1,15,1,15,1,15,1,15,1,15,1,16,1,16,3,16,446,8,
        16,1,16,1,16,1,16,1,16,1,16,1,16,5,16,454,8,16,10,16,12,16,457,9,
        16,1,16,1,16,1,16,1,17,1,17,1,17,1,17,1,17,1,17,1,17,1,17,1,17,1,
        18,1,18,1,18,1,18,1,18,4,18,476,8,18,11,18,12,18,477,1,18,1,18,1,
        18,1,18,1,19,1,19,4,19,486,8,19,11,19,12,19,487,1,19,1,19,1,19,1,
        20,1,20,1,20,4,20,496,8,20,11,20,12,20,497,1,21,1,21,1,21,3,21,503,
        8,21,1,21,1,21,1,21,3,21,508,8,21,5,21,510,8,21,10,21,12,21,513,
        9,21,1,21,1,21,1,22,1,22,1,22,1,22,1,22,4,22,522,8,22,11,22,12,22,
        523,1,22,1,22,3,22,528,8,22,1,22,1,22,1,22,1,23,1,23,1,23,1,23,3,
        23,537,8,23,1,23,1,23,1,23,5,23,542,8,23,10,23,12,23,545,9,23,1,
        23,1,23,1,23,1,24,1,24,1,24,1,24,1,24,1,24,5,24,556,8,24,10,24,12,
        24,559,9,24,1,24,3,24,562,8,24,1,24,3,24,565,8,24,1,25,5,25,568,
        8,25,10,25,12,25,571,9,25,1,26,1,26,1,26,1,26,1,26,5,26,578,8,26,
        10,26,12,26,581,9,26,1,26,1,26,1,27,1,27,1,27,3,27,588,8,27,1,27,
        1,27,3,27,592,8,27,1,28,1,28,1,28,1,28,1,28,1,28,1,29,1,29,1,29,
        1,29,1,29,3,29,605,8,29,1,30,1,30,1,30,1,30,1,30,1,30,1,31,1,31,
        1,31,1,31,3,31,617,8,31,1,32,1,32,1,32,1,32,1,32,1,33,1,33,1,33,
        1,33,1,34,1,34,1,34,1,34,1,35,1,35,1,35,1,35,1,35,1,35,1,36,1,36,
        1,36,1,36,1,36,3,36,643,8,36,1,36,1,36,1,36,1,36,5,36,649,8,36,10,
        36,12,36,652,9,36,1,37,1,37,3,37,656,8,37,1,37,3,37,659,8,37,1,37,
        1,37,3,37,663,8,37,1,38,1,38,1,39,1,39,1,39,1,39,1,39,3,39,672,8,
        39,1,39,1,39,1,39,1,39,1,39,5,39,679,8,39,10,39,12,39,682,9,39,3,
        39,684,8,39,1,40,1,40,1,40,1,40,1,40,1,40,3,40,692,8,40,1,40,1,40,
        1,40,1,40,1,40,3,40,699,8,40,3,40,701,8,40,1,41,1,41,1,41,1,41,1,
        41,3,41,708,8,41,1,41,1,41,1,41,1,41,1,41,3,41,715,8,41,3,41,717,
        8,41,1,42,1,42,1,42,1,42,1,42,1,42,3,42,725,8,42,1,42,1,42,1,42,
        3,42,730,8,42,1,42,1,42,1,42,1,42,1,42,3,42,737,8,42,1,43,1,43,1,
        43,1,43,1,43,3,43,744,8,43,1,43,1,43,1,44,1,44,1,44,1,44,1,44,1,
        44,3,44,754,8,44,1,45,1,45,1,45,5,45,759,8,45,10,45,12,45,762,9,
        45,1,46,1,46,1,46,1,46,3,46,768,8,46,1,47,1,47,1,47,5,47,773,8,47,
        10,47,12,47,776,9,47,1,48,1,48,1,48,1,48,1,48,1,48,3,48,784,8,48,
        1,49,1,49,1,49,1,49,1,49,1,49,1,49,1,49,1,49,1,49,1,49,1,49,1,49,
        1,49,1,49,3,49,801,8,49,1,50,1,50,3,50,805,8,50,1,50,1,50,1,50,1,
        50,1,50,1,50,5,50,813,8,50,10,50,12,50,816,9,50,1,50,1,50,1,50,1,
        51,1,51,1,51,1,51,5,51,825,8,51,10,51,12,51,828,9,51,1,52,1,52,1,
        52,3,52,833,8,52,1,52,1,52,3,52,837,8,52,1,52,1,52,3,52,841,8,52,
        1,52,1,52,1,52,1,53,1,53,1,53,1,53,5,53,850,8,53,10,53,12,53,853,
        9,53,1,54,1,54,1,54,3,54,858,8,54,1,54,1,54,1,54,1,55,1,55,1,55,
        1,56,1,56,1,56,1,56,1,56,5,56,871,8,56,10,56,12,56,874,9,56,1,57,
        1,57,1,57,3,57,879,8,57,1,57,1,57,3,57,883,8,57,1,57,1,57,3,57,887,
        8,57,1,58,1,58,1,58,1,58,1,58,3,58,894,8,58,1,58,1,58,1,58,5,58,
        899,8,58,10,58,12,58,902,9,58,1,59,1,59,1,59,3,59,907,8,59,1,59,
        1,59,1,59,3,59,912,8,59,3,59,914,8,59,1,59,1,59,3,59,918,8,59,1,
        60,1,60,1,60,1,61,1,61,3,61,925,8,61,1,61,1,61,1,61,5,61,930,8,61,
        10,61,12,61,933,9,61,1,61,1,61,1,61,1,62,1,62,1,62,3,62,941,8,62,
        1,62,1,62,1,62,1,63,1,63,1,63,1,63,1,63,4,63,951,8,63,11,63,12,63,
        952,1,63,1,63,1,63,1,63,1,64,1,64,4,64,961,8,64,11,64,12,64,962,
        1,64,1,64,1,64,1,65,1,65,1,65,1,65,1,65,4,65,973,8,65,11,65,12,65,
        974,1,65,1,65,3,65,979,8,65,1,65,1,65,1,65,1,66,1,66,1,66,1,66,3,
        66,988,8,66,1,66,1,66,1,66,5,66,993,8,66,10,66,12,66,996,9,66,1,
        66,1,66,1,66,1,67,1,67,1,67,1,67,1,67,1,67,1,67,1,67,1,67,1,68,1,
        68,1,68,1,68,1,68,4,68,1015,8,68,11,68,12,68,1016,1,69,1,69,1,69,
        3,69,1022,8,69,1,69,1,69,1,69,3,69,1027,8,69,5,69,1029,8,69,10,69,
        12,69,1032,9,69,1,69,1,69,1,69,1,69,1,70,1,70,1,70,5,70,1041,8,70,
        10,70,12,70,1044,9,70,1,71,1,71,1,71,5,71,1049,8,71,10,71,12,71,
        1052,9,71,1,72,3,72,1055,8,72,1,72,1,72,1,73,1,73,1,73,3,73,1062,
        8,73,1,74,1,74,1,74,5,74,1067,8,74,10,74,12,74,1070,9,74,1,75,1,
        75,1,75,3,75,1075,8,75,1,76,1,76,1,76,5,76,1080,8,76,10,76,12,76,
        1083,9,76,1,77,1,77,1,77,5,77,1088,8,77,10,77,12,77,1091,9,77,1,
        78,1,78,1,78,1,78,3,78,1097,8,78,1,79,1,79,1,79,1,79,3,79,1103,8,
        79,1,80,1,80,1,80,1,80,3,80,1109,8,80,1,81,1,81,1,81,1,81,3,81,1115,
        8,81,1,82,1,82,1,82,1,82,3,82,1121,8,82,1,83,1,83,1,83,1,83,1,83,
        1,83,1,83,5,83,1130,8,83,10,83,12,83,1133,9,83,1,84,1,84,1,84,3,
        84,1138,8,84,1,85,5,85,1141,8,85,10,85,12,85,1144,9,85,1,85,1,85,
        1,86,1,86,1,86,3,86,1151,8,86,1,87,1,87,1,87,1,87,1,87,1,87,1,87,
        1,88,1,88,1,88,1,88,1,88,1,88,1,88,1,89,1,89,1,89,5,89,1170,8,89,
        10,89,12,89,1173,9,89,1,90,1,90,1,90,1,90,1,90,1,90,5,90,1181,8,
        90,10,90,12,90,1184,9,90,1,91,1,91,1,91,1,91,1,91,1,91,1,92,1,92,
        1,92,1,93,1,93,1,93,1,93,1,94,1,94,1,94,1,94,1,94,1,94,1,94,3,94,
        1206,8,94,1,95,1,95,1,95,1,95,1,95,1,95,1,95,1,95,1,95,1,95,1,95,
        1,95,1,95,1,95,1,95,3,95,1223,8,95,1,96,1,96,1,96,1,96,1,97,1,97,
        1,97,1,98,1,98,3,98,1234,8,98,1,98,1,98,1,99,1,99,1,100,1,100,1,
        100,1,100,1,100,1,101,1,101,1,101,1,101,1,101,1,102,1,102,1,102,
        1,103,1,103,1,103,1,103,5,103,1257,8,103,10,103,12,103,1260,9,103,
        3,103,1262,8,103,1,103,1,103,1,104,1,104,3,104,1268,8,104,1,105,
        1,105,3,105,1272,8,105,1,106,1,106,1,106,1,106,1,107,1,107,1,107,
        1,107,3,107,1282,8,107,1,107,1,107,1,107,3,107,1287,8,107,1,107,
        1,107,1,107,1,107,1,108,1,108,1,108,1,108,1,108,1,108,1,108,1,108,
        3,108,1301,8,108,1,108,1,108,1,108,1,108,1,108,5,108,1308,8,108,
        10,108,12,108,1311,9,108,1,108,1,108,1,108,3,108,1316,8,108,1,109,
        1,109,1,109,1,109,1,110,1,110,1,110,1,110,1,110,1,110,1,111,1,111,
        1,111,1,111,1,111,1,111,1,111,1,111,1,112,1,112,1,112,1,112,5,112,
        1340,8,112,10,112,12,112,1343,9,112,1,112,1,112,1,112,1,112,1,112,
        1,113,1,113,1,113,1,113,1,113,1,113,1,114,1,114,1,115,1,115,1,115,
        1,115,1,116,1,116,1,116,1,116,1,116,1,116,1,116,1,116,3,116,1370,
        8,116,1,117,1,117,1,117,3,117,1375,8,117,1,117,3,117,1378,8,117,
        1,117,1,117,1,117,1,117,1,117,1,117,1,117,1,118,1,118,1,118,1,118,
        1,118,1,119,1,119,1,119,1,119,1,119,1,119,3,119,1398,8,119,1,119,
        1,119,1,119,1,119,1,119,1,119,1,119,1,120,1,120,1,120,1,120,3,120,
        1411,8,120,1,120,1,120,1,120,1,120,1,121,1,121,1,121,1,121,1,121,
        1,121,1,121,1,122,1,122,1,122,1,122,1,122,1,122,1,122,1,123,1,123,
        3,123,1433,8,123,1,123,1,123,1,123,3,123,1438,8,123,1,124,1,124,
        1,124,5,124,1443,8,124,10,124,12,124,1446,9,124,1,125,1,125,3,125,
        1450,8,125,1,126,1,126,3,126,1454,8,126,1,126,1,126,1,127,1,127,
        1,127,1,127,3,127,1462,8,127,1,128,1,128,1,128,1,128,1,129,3,129,
        1469,8,129,1,129,1,129,1,130,1,130,1,130,1,130,3,130,1477,8,130,
        1,131,1,131,1,131,1,131,1,132,1,132,1,133,1,133,3,133,1487,8,133,
        1,134,1,134,3,134,1491,8,134,1,135,1,135,1,135,3,135,1496,8,135,
        1,136,1,136,1,136,1,136,1,137,1,137,1,137,1,137,1,138,5,138,1507,
        8,138,10,138,12,138,1510,9,138,1,139,1,139,1,139,1,139,1,139,1,139,
        1,139,1,139,1,139,1,139,1,139,3,139,1523,8,139,1,140,1,140,1,140,
        1,140,1,141,1,141,1,141,1,141,1,142,1,142,1,142,1,142,3,142,1537,
        8,142,1,142,1,142,1,143,1,143,1,143,1,143,1,144,1,144,1,144,1,144,
        1,145,1,145,1,145,1,145,1,146,1,146,1,146,1,146,3,146,1557,8,146,
        1,146,1,146,1,147,1,147,1,147,1,147,1,147,3,147,1566,8,147,3,147,
        1568,8,147,1,147,1,147,1,148,1,148,3,148,1574,8,148,1,149,1,149,
        1,149,1,149,1,149,1,150,1,150,1,151,1,151,1,151,1,151,1,151,1,151,
        3,151,1589,8,151,3,151,1591,8,151,3,151,1593,8,151,1,151,1,151,1,
        152,1,152,3,152,1599,8,152,1,153,1,153,1,153,1,153,1,153,1,154,1,
        154,1,155,1,155,1,156,1,156,1,157,1,157,1,158,1,158,1,159,1,159,
        1,159,1,159,1,159,1,159,3,159,1622,8,159,3,159,1624,8,159,1,160,
        1,160,1,160,1,160,5,160,1630,8,160,10,160,12,160,1633,9,160,3,160,
        1635,8,160,1,160,1,160,1,160,1,160,1,160,3,160,1642,8,160,1,161,
        1,161,1,161,3,161,1647,8,161,1,162,1,162,3,162,1651,8,162,1,163,
        1,163,1,163,1,163,1,163,1,164,1,164,1,164,1,164,1,164,5,164,1663,
        8,164,10,164,12,164,1666,9,164,3,164,1668,8,164,1,164,1,164,1,164,
        1,164,1,165,1,165,3,165,1676,8,165,1,166,1,166,1,166,1,166,1,167,
        1,167,3,167,1684,8,167,1,167,1,167,1,168,1,168,1,169,1,169,1,170,
        1,170,1,170,0,0,171,0,2,4,6,8,10,12,14,16,18,20,22,24,26,28,30,32,
        34,36,38,40,42,44,46,48,50,52,54,56,58,60,62,64,66,68,70,72,74,76,
        78,80,82,84,86,88,90,92,94,96,98,100,102,104,106,108,110,112,114,
        116,118,120,122,124,126,128,130,132,134,136,138,140,142,144,146,
        148,150,152,154,156,158,160,162,164,166,168,170,172,174,176,178,
        180,182,184,186,188,190,192,194,196,198,200,202,204,206,208,210,
        212,214,216,218,220,222,224,226,228,230,232,234,236,238,240,242,
        244,246,248,250,252,254,256,258,260,262,264,266,268,270,272,274,
        276,278,280,282,284,286,288,290,292,294,296,298,300,302,304,306,
        308,310,312,314,316,318,320,322,324,326,328,330,332,334,336,338,
        340,0,13,2,0,16,16,104,104,1,0,81,82,1,0,19,28,2,0,3,3,34,44,1,0,
        46,47,2,0,10,10,48,50,1,0,129,131,2,0,115,115,132,132,1,0,143,144,
        1,0,146,152,1,0,153,157,2,0,18,18,180,180,2,0,60,178,181,181,1762,
        0,342,1,0,0,0,2,350,1,0,0,0,4,356,1,0,0,0,6,359,1,0,0,0,8,376,1,
        0,0,0,10,387,1,0,0,0,12,392,1,0,0,0,14,395,1,0,0,0,16,398,1,0,0,
        0,18,415,1,0,0,0,20,417,1,0,0,0,22,420,1,0,0,0,24,426,1,0,0,0,26,
        430,1,0,0,0,28,434,1,0,0,0,30,438,1,0,0,0,32,445,1,0,0,0,34,461,
        1,0,0,0,36,470,1,0,0,0,38,485,1,0,0,0,40,492,1,0,0,0,42,499,1,0,
        0,0,44,516,1,0,0,0,46,532,1,0,0,0,48,564,1,0,0,0,50,569,1,0,0,0,
        52,572,1,0,0,0,54,584,1,0,0,0,56,593,1,0,0,0,58,604,1,0,0,0,60,606,
        1,0,0,0,62,616,1,0,0,0,64,618,1,0,0,0,66,623,1,0,0,0,68,627,1,0,
        0,0,70,631,1,0,0,0,72,637,1,0,0,0,74,658,1,0,0,0,76,664,1,0,0,0,
        78,666,1,0,0,0,80,685,1,0,0,0,82,702,1,0,0,0,84,718,1,0,0,0,86,738,
        1,0,0,0,88,753,1,0,0,0,90,755,1,0,0,0,92,763,1,0,0,0,94,769,1,0,
        0,0,96,783,1,0,0,0,98,800,1,0,0,0,100,804,1,0,0,0,102,820,1,0,0,
        0,104,829,1,0,0,0,106,845,1,0,0,0,108,854,1,0,0,0,110,862,1,0,0,
        0,112,865,1,0,0,0,114,875,1,0,0,0,116,893,1,0,0,0,118,903,1,0,0,
        0,120,919,1,0,0,0,122,924,1,0,0,0,124,937,1,0,0,0,126,945,1,0,0,
        0,128,960,1,0,0,0,130,967,1,0,0,0,132,983,1,0,0,0,134,1000,1,0,0,
        0,136,1009,1,0,0,0,138,1018,1,0,0,0,140,1037,1,0,0,0,142,1045,1,
        0,0,0,144,1054,1,0,0,0,146,1058,1,0,0,0,148,1063,1,0,0,0,150,1071,
        1,0,0,0,152,1076,1,0,0,0,154,1084,1,0,0,0,156,1092,1,0,0,0,158,1098,
        1,0,0,0,160,1104,1,0,0,0,162,1110,1,0,0,0,164,1116,1,0,0,0,166,1122,
        1,0,0,0,168,1137,1,0,0,0,170,1142,1,0,0,0,172,1150,1,0,0,0,174,1152,
        1,0,0,0,176,1159,1,0,0,0,178,1166,1,0,0,0,180,1174,1,0,0,0,182,1185,
        1,0,0,0,184,1191,1,0,0,0,186,1194,1,0,0,0,188,1198,1,0,0,0,190,1222,
        1,0,0,0,192,1224,1,0,0,0,194,1228,1,0,0,0,196,1231,1,0,0,0,198,1237,
        1,0,0,0,200,1239,1,0,0,0,202,1244,1,0,0,0,204,1249,1,0,0,0,206,1252,
        1,0,0,0,208,1267,1,0,0,0,210,1271,1,0,0,0,212,1273,1,0,0,0,214,1277,
        1,0,0,0,216,1315,1,0,0,0,218,1317,1,0,0,0,220,1321,1,0,0,0,222,1327,
        1,0,0,0,224,1335,1,0,0,0,226,1349,1,0,0,0,228,1355,1,0,0,0,230,1357,
        1,0,0,0,232,1361,1,0,0,0,234,1371,1,0,0,0,236,1386,1,0,0,0,238,1391,
        1,0,0,0,240,1406,1,0,0,0,242,1416,1,0,0,0,244,1423,1,0,0,0,246,1437,
        1,0,0,0,248,1439,1,0,0,0,250,1449,1,0,0,0,252,1453,1,0,0,0,254,1461,
        1,0,0,0,256,1463,1,0,0,0,258,1468,1,0,0,0,260,1476,1,0,0,0,262,1478,
        1,0,0,0,264,1482,1,0,0,0,266,1486,1,0,0,0,268,1490,1,0,0,0,270,1495,
        1,0,0,0,272,1497,1,0,0,0,274,1501,1,0,0,0,276,1508,1,0,0,0,278,1522,
        1,0,0,0,280,1524,1,0,0,0,282,1528,1,0,0,0,284,1532,1,0,0,0,286,1540,
        1,0,0,0,288,1544,1,0,0,0,290,1548,1,0,0,0,292,1552,1,0,0,0,294,1560,
        1,0,0,0,296,1573,1,0,0,0,298,1575,1,0,0,0,300,1580,1,0,0,0,302,1582,
        1,0,0,0,304,1598,1,0,0,0,306,1600,1,0,0,0,308,1605,1,0,0,0,310,1607,
        1,0,0,0,312,1609,1,0,0,0,314,1611,1,0,0,0,316,1613,1,0,0,0,318,1623,
        1,0,0,0,320,1641,1,0,0,0,322,1646,1,0,0,0,324,1650,1,0,0,0,326,1652,
        1,0,0,0,328,1657,1,0,0,0,330,1673,1,0,0,0,332,1677,1,0,0,0,334,1681,
        1,0,0,0,336,1687,1,0,0,0,338,1689,1,0,0,0,340,1691,1,0,0,0,342,343,
        3,2,1,0,343,344,5,0,0,1,344,1,1,0,0,0,345,346,5,103,0,0,346,347,
        5,102,0,0,347,348,3,338,169,0,348,349,5,1,0,0,349,351,1,0,0,0,350,
        345,1,0,0,0,350,351,1,0,0,0,351,354,1,0,0,0,352,355,3,6,3,0,353,
        355,3,4,2,0,354,352,1,0,0,0,354,353,1,0,0,0,355,3,1,0,0,0,356,357,
        3,8,4,0,357,358,3,10,5,0,358,5,1,0,0,0,359,360,5,2,0,0,360,361,5,
        141,0,0,361,362,5,188,0,0,362,363,5,3,0,0,363,364,3,336,168,0,364,
        365,5,1,0,0,365,366,3,8,4,0,366,7,1,0,0,0,367,371,3,58,29,0,368,
        371,3,60,30,0,369,371,3,78,39,0,370,367,1,0,0,0,370,368,1,0,0,0,
        370,369,1,0,0,0,371,372,1,0,0,0,372,373,5,1,0,0,373,375,1,0,0,0,
        374,370,1,0,0,0,375,378,1,0,0,0,376,374,1,0,0,0,376,377,1,0,0,0,
        377,384,1,0,0,0,378,376,1,0,0,0,379,380,3,62,31,0,380,381,5,1,0,
        0,381,383,1,0,0,0,382,379,1,0,0,0,383,386,1,0,0,0,384,382,1,0,0,
        0,384,385,1,0,0,0,385,9,1,0,0,0,386,384,1,0,0,0,387,388,3,16,8,0,
        388,11,1,0,0,0,389,391,3,18,9,0,390,389,1,0,0,0,391,394,1,0,0,0,
        392,390,1,0,0,0,392,393,1,0,0,0,393,13,1,0,0,0,394,392,1,0,0,0,395,
        396,3,12,6,0,396,397,3,94,47,0,397,15,1,0,0,0,398,400,3,12,6,0,399,
        401,3,94,47,0,400,399,1,0,0,0,400,401,1,0,0,0,401,17,1,0,0,0,402,
        416,3,20,10,0,403,416,3,22,11,0,404,416,3,24,12,0,405,416,3,26,13,
        0,406,416,3,28,14,0,407,416,3,30,15,0,408,416,3,32,16,0,409,416,
        3,34,17,0,410,416,3,36,18,0,411,416,3,40,20,0,412,416,3,44,22,0,
        413,416,3,52,26,0,414,416,3,56,28,0,415,402,1,0,0,0,415,403,1,0,
        0,0,415,404,1,0,0,0,415,405,1,0,0,0,415,406,1,0,0,0,415,407,1,0,
        0,0,415,408,1,0,0,0,415,409,1,0,0,0,415,410,1,0,0,0,415,411,1,0,
        0,0,415,412,1,0,0,0,415,413,1,0,0,0,415,414,1,0,0,0,416,19,1,0,0,
        0,417,418,3,98,49,0,418,419,5,1,0,0,419,21,1,0,0,0,420,421,5,4,0,
        0,421,422,3,74,37,0,422,423,5,5,0,0,423,424,3,96,48,0,424,425,5,
        1,0,0,425,23,1,0,0,0,426,427,5,6,0,0,427,428,3,12,6,0,428,429,5,
        7,0,0,429,25,1,0,0,0,430,431,5,173,0,0,431,432,5,174,0,0,432,433,
        5,1,0,0,433,27,1,0,0,0,434,435,5,175,0,0,435,436,5,174,0,0,436,437,
        5,1,0,0,437,29,1,0,0,0,438,439,5,176,0,0,439,440,5,177,0,0,440,441,
        3,96,48,0,441,442,5,1,0,0,442,31,1,0,0,0,443,446,3,102,51,0,444,
        446,3,106,53,0,445,443,1,0,0,0,445,444,1,0,0,0,446,455,1,0,0,0,447,
        454,3,102,51,0,448,454,3,106,53,0,449,454,3,110,55,0,450,454,3,112,
        56,0,451,454,3,116,58,0,452,454,3,120,60,0,453,447,1,0,0,0,453,448,
        1,0,0,0,453,449,1,0,0,0,453,450,1,0,0,0,453,451,1,0,0,0,453,452,
        1,0,0,0,454,457,1,0,0,0,455,453,1,0,0,0,455,456,1,0,0,0,456,458,
        1,0,0,0,457,455,1,0,0,0,458,459,5,66,0,0,459,460,3,18,9,0,460,33,
        1,0,0,0,461,462,5,67,0,0,462,463,5,8,0,0,463,464,3,94,47,0,464,465,
        5,9,0,0,465,466,5,88,0,0,466,467,3,18,9,0,467,468,5,89,0,0,468,469,
        3,18,9,0,469,35,1,0,0,0,470,471,5,83,0,0,471,472,5,8,0,0,472,473,
        3,94,47,0,473,475,5,9,0,0,474,476,3,38,19,0,475,474,1,0,0,0,476,
        477,1,0,0,0,477,475,1,0,0,0,477,478,1,0,0,0,478,479,1,0,0,0,479,
        480,5,87,0,0,480,481,5,66,0,0,481,482,3,18,9,0,482,37,1,0,0,0,483,
        484,5,84,0,0,484,486,3,96,48,0,485,483,1,0,0,0,486,487,1,0,0,0,487,
        485,1,0,0,0,487,488,1,0,0,0,488,489,1,0,0,0,489,490,5,66,0,0,490,
        491,3,18,9,0,491,39,1,0,0,0,492,493,5,85,0,0,493,495,3,24,12,0,494,
        496,3,42,21,0,495,494,1,0,0,0,496,497,1,0,0,0,497,495,1,0,0,0,497,
        498,1,0,0,0,498,41,1,0,0,0,499,502,5,86,0,0,500,503,5,10,0,0,501,
        503,3,74,37,0,502,500,1,0,0,0,502,501,1,0,0,0,503,511,1,0,0,0,504,
        507,5,11,0,0,505,508,5,10,0,0,506,508,3,74,37,0,507,505,1,0,0,0,
        507,506,1,0,0,0,508,510,1,0,0,0,509,504,1,0,0,0,510,513,1,0,0,0,
        511,509,1,0,0,0,511,512,1,0,0,0,512,514,1,0,0,0,513,511,1,0,0,0,
        514,515,3,24,12,0,515,43,1,0,0,0,516,517,5,90,0,0,517,518,5,8,0,
        0,518,519,3,94,47,0,519,521,5,9,0,0,520,522,3,46,23,0,521,520,1,
        0,0,0,522,523,1,0,0,0,523,521,1,0,0,0,523,524,1,0,0,0,524,525,1,
        0,0,0,525,527,5,87,0,0,526,528,3,194,97,0,527,526,1,0,0,0,527,528,
        1,0,0,0,528,529,1,0,0,0,529,530,5,66,0,0,530,531,3,18,9,0,531,45,
        1,0,0,0,532,536,5,84,0,0,533,534,3,194,97,0,534,535,5,69,0,0,535,
        537,1,0,0,0,536,533,1,0,0,0,536,537,1,0,0,0,537,538,1,0,0,0,538,
        543,3,318,159,0,539,540,5,11,0,0,540,542,3,318,159,0,541,539,1,0,
        0,0,542,545,1,0,0,0,543,541,1,0,0,0,543,544,1,0,0,0,544,546,1,0,
        0,0,545,543,1,0,0,0,546,547,5,66,0,0,547,548,3,18,9,0,548,47,1,0,
        0,0,549,550,5,12,0,0,550,561,3,74,37,0,551,552,5,8,0,0,552,557,5,
        182,0,0,553,554,5,13,0,0,554,556,5,182,0,0,555,553,1,0,0,0,556,559,
        1,0,0,0,557,555,1,0,0,0,557,558,1,0,0,0,558,560,1,0,0,0,559,557,
        1,0,0,0,560,562,5,9,0,0,561,551,1,0,0,0,561,562,1,0,0,0,562,565,
        1,0,0,0,563,565,5,126,0,0,564,549,1,0,0,0,564,563,1,0,0,0,565,49,
        1,0,0,0,566,568,3,48,24,0,567,566,1,0,0,0,568,571,1,0,0,0,569,567,
        1,0,0,0,569,570,1,0,0,0,570,51,1,0,0,0,571,569,1,0,0,0,572,573,3,
        50,25,0,573,574,5,113,0,0,574,579,3,54,27,0,575,576,5,13,0,0,576,
        578,3,54,27,0,577,575,1,0,0,0,578,581,1,0,0,0,579,577,1,0,0,0,579,
        580,1,0,0,0,580,582,1,0,0,0,581,579,1,0,0,0,582,583,5,1,0,0,583,
        53,1,0,0,0,584,587,3,194,97,0,585,586,5,69,0,0,586,588,3,318,159,
        0,587,585,1,0,0,0,587,588,1,0,0,0,588,591,1,0,0,0,589,590,5,5,0,
        0,590,592,3,96,48,0,591,589,1,0,0,0,591,592,1,0,0,0,592,55,1,0,0,
        0,593,594,5,178,0,0,594,595,5,8,0,0,595,596,3,94,47,0,596,597,5,
        9,0,0,597,598,3,18,9,0,598,57,1,0,0,0,599,605,3,64,32,0,600,605,
        3,66,33,0,601,605,3,68,34,0,602,605,3,70,35,0,603,605,3,72,36,0,
        604,599,1,0,0,0,604,600,1,0,0,0,604,601,1,0,0,0,604,602,1,0,0,0,
        604,603,1,0,0,0,605,59,1,0,0,0,606,607,5,110,0,0,607,608,5,141,0,
        0,608,609,5,188,0,0,609,610,5,3,0,0,610,611,3,336,168,0,611,61,1,
        0,0,0,612,617,3,84,42,0,613,617,3,80,40,0,614,617,3,86,43,0,615,
        617,3,82,41,0,616,612,1,0,0,0,616,613,1,0,0,0,616,614,1,0,0,0,616,
        615,1,0,0,0,617,63,1,0,0,0,618,619,5,110,0,0,619,620,5,87,0,0,620,
        621,5,80,0,0,621,622,3,336,168,0,622,65,1,0,0,0,623,624,5,110,0,
        0,624,625,5,14,0,0,625,626,3,336,168,0,626,67,1,0,0,0,627,628,5,
        110,0,0,628,629,5,15,0,0,629,630,7,0,0,0,630,69,1,0,0,0,631,632,
        5,110,0,0,632,633,5,87,0,0,633,634,5,65,0,0,634,635,5,72,0,0,635,
        636,7,1,0,0,636,71,1,0,0,0,637,642,5,110,0,0,638,639,5,17,0,0,639,
        643,3,74,37,0,640,641,5,87,0,0,641,643,5,17,0,0,642,638,1,0,0,0,
        642,640,1,0,0,0,643,650,1,0,0,0,644,645,3,76,38,0,645,646,5,3,0,
        0,646,647,3,338,169,0,647,649,1,0,0,0,648,644,1,0,0,0,649,652,1,
        0,0,0,650,648,1,0,0,0,650,651,1,0,0,0,651,73,1,0,0,0,652,650,1,0,
        0,0,653,656,5,188,0,0,654,656,3,340,170,0,655,653,1,0,0,0,655,654,
        1,0,0,0,656,657,1,0,0,0,657,659,5,18,0,0,658,655,1,0,0,0,658,659,
        1,0,0,0,659,662,1,0,0,0,660,663,5,188,0,0,661,663,3,340,170,0,662,
        660,1,0,0,0,662,661,1,0,0,0,663,75,1,0,0,0,664,665,7,2,0,0,665,77,
        1,0,0,0,666,667,5,139,0,0,667,671,5,2,0,0,668,669,5,141,0,0,669,
        670,5,188,0,0,670,672,5,3,0,0,671,668,1,0,0,0,671,672,1,0,0,0,672,
        673,1,0,0,0,673,683,3,336,168,0,674,675,5,70,0,0,675,680,3,336,168,
        0,676,677,5,13,0,0,677,679,3,336,168,0,678,676,1,0,0,0,679,682,1,
        0,0,0,680,678,1,0,0,0,680,681,1,0,0,0,681,684,1,0,0,0,682,680,1,
        0,0,0,683,674,1,0,0,0,683,684,1,0,0,0,684,79,1,0,0,0,685,686,5,110,
        0,0,686,687,3,50,25,0,687,688,5,113,0,0,688,691,3,194,97,0,689,690,
        5,69,0,0,690,692,3,318,159,0,691,689,1,0,0,0,691,692,1,0,0,0,692,
        700,1,0,0,0,693,694,5,5,0,0,694,701,3,96,48,0,695,698,5,29,0,0,696,
        697,5,5,0,0,697,699,3,96,48,0,698,696,1,0,0,0,698,699,1,0,0,0,699,
        701,1,0,0,0,700,693,1,0,0,0,700,695,1,0,0,0,701,81,1,0,0,0,702,703,
        5,110,0,0,703,704,5,111,0,0,704,707,5,112,0,0,705,706,5,69,0,0,706,
        708,3,318,159,0,707,705,1,0,0,0,707,708,1,0,0,0,708,716,1,0,0,0,
        709,710,5,5,0,0,710,717,3,96,48,0,711,714,5,29,0,0,712,713,5,5,0,
        0,713,715,3,96,48,0,714,712,1,0,0,0,714,715,1,0,0,0,715,717,1,0,
        0,0,716,709,1,0,0,0,716,711,1,0,0,0,717,83,1,0,0,0,718,719,5,110,
        0,0,719,720,3,50,25,0,720,721,5,30,0,0,721,722,3,74,37,0,722,724,
        5,8,0,0,723,725,3,90,45,0,724,723,1,0,0,0,724,725,1,0,0,0,725,726,
        1,0,0,0,726,729,5,9,0,0,727,728,5,69,0,0,728,730,3,318,159,0,729,
        727,1,0,0,0,729,730,1,0,0,0,730,736,1,0,0,0,731,732,5,6,0,0,732,
        733,3,16,8,0,733,734,5,7,0,0,734,737,1,0,0,0,735,737,5,29,0,0,736,
        731,1,0,0,0,736,735,1,0,0,0,737,85,1,0,0,0,738,739,5,110,0,0,739,
        740,5,107,0,0,740,741,3,74,37,0,741,743,5,69,0,0,742,744,3,88,44,
        0,743,742,1,0,0,0,743,744,1,0,0,0,744,745,1,0,0,0,745,746,3,96,48,
        0,746,87,1,0,0,0,747,748,5,31,0,0,748,754,5,32,0,0,749,750,5,31,
        0,0,750,754,5,33,0,0,751,752,5,125,0,0,752,754,5,140,0,0,753,747,
        1,0,0,0,753,749,1,0,0,0,753,751,1,0,0,0,754,89,1,0,0,0,755,760,3,
        92,46,0,756,757,5,13,0,0,757,759,3,92,46,0,758,756,1,0,0,0,759,762,
        1,0,0,0,760,758,1,0,0,0,760,761,1,0,0,0,761,91,1,0,0,0,762,760,1,
        0,0,0,763,764,5,4,0,0,764,767,3,74,37,0,765,766,5,69,0,0,766,768,
        3,318,159,0,767,765,1,0,0,0,767,768,1,0,0,0,768,93,1,0,0,0,769,774,
        3,96,48,0,770,771,5,13,0,0,771,773,3,96,48,0,772,770,1,0,0,0,773,
        776,1,0,0,0,774,772,1,0,0,0,774,775,1,0,0,0,775,95,1,0,0,0,776,774,
        1,0,0,0,777,784,3,98,49,0,778,784,3,100,50,0,779,784,3,126,63,0,
        780,784,3,130,65,0,781,784,3,134,67,0,782,784,3,136,68,0,783,777,
        1,0,0,0,783,778,1,0,0,0,783,779,1,0,0,0,783,780,1,0,0,0,783,781,
        1,0,0,0,783,782,1,0,0,0,784,97,1,0,0,0,785,801,3,122,61,0,786,801,
        3,140,70,0,787,801,3,216,108,0,788,801,3,218,109,0,789,801,3,220,
        110,0,790,801,3,222,111,0,791,801,3,224,112,0,792,801,3,226,113,
        0,793,801,3,232,116,0,794,801,3,242,121,0,795,801,3,234,117,0,796,
        801,3,236,118,0,797,801,3,244,122,0,798,801,3,238,119,0,799,801,
        3,240,120,0,800,785,1,0,0,0,800,786,1,0,0,0,800,787,1,0,0,0,800,
        788,1,0,0,0,800,789,1,0,0,0,800,790,1,0,0,0,800,791,1,0,0,0,800,
        792,1,0,0,0,800,793,1,0,0,0,800,794,1,0,0,0,800,795,1,0,0,0,800,
        796,1,0,0,0,800,797,1,0,0,0,800,798,1,0,0,0,800,799,1,0,0,0,801,
        99,1,0,0,0,802,805,3,102,51,0,803,805,3,106,53,0,804,802,1,0,0,0,
        804,803,1,0,0,0,805,814,1,0,0,0,806,813,3,102,51,0,807,813,3,106,
        53,0,808,813,3,110,55,0,809,813,3,112,56,0,810,813,3,116,58,0,811,
        813,3,120,60,0,812,806,1,0,0,0,812,807,1,0,0,0,812,808,1,0,0,0,812,
        809,1,0,0,0,812,810,1,0,0,0,812,811,1,0,0,0,813,816,1,0,0,0,814,
        812,1,0,0,0,814,815,1,0,0,0,815,817,1,0,0,0,816,814,1,0,0,0,817,
        818,5,66,0,0,818,819,3,96,48,0,819,101,1,0,0,0,820,821,5,60,0,0,
        821,826,3,104,52,0,822,823,5,13,0,0,823,825,3,104,52,0,824,822,1,
        0,0,0,825,828,1,0,0,0,826,824,1,0,0,0,826,827,1,0,0,0,827,103,1,
        0,0,0,828,826,1,0,0,0,829,832,3,194,97,0,830,831,5,69,0,0,831,833,
        3,318,159,0,832,830,1,0,0,0,832,833,1,0,0,0,833,836,1,0,0,0,834,
        835,5,71,0,0,835,837,5,72,0,0,836,834,1,0,0,0,836,837,1,0,0,0,837,
        840,1,0,0,0,838,839,5,70,0,0,839,841,3,194,97,0,840,838,1,0,0,0,
        840,841,1,0,0,0,841,842,1,0,0,0,842,843,5,68,0,0,843,844,3,96,48,
        0,844,105,1,0,0,0,845,846,5,61,0,0,846,851,3,108,54,0,847,848,5,
        13,0,0,848,850,3,108,54,0,849,847,1,0,0,0,850,853,1,0,0,0,851,849,
        1,0,0,0,851,852,1,0,0,0,852,107,1,0,0,0,853,851,1,0,0,0,854,857,
        3,194,97,0,855,856,5,69,0,0,856,858,3,318,159,0,857,855,1,0,0,0,
        857,858,1,0,0,0,858,859,1,0,0,0,859,860,5,5,0,0,860,861,3,96,48,
        0,861,109,1,0,0,0,862,863,5,62,0,0,863,864,3,96,48,0,864,111,1,0,
        0,0,865,866,5,63,0,0,866,867,5,64,0,0,867,872,3,114,57,0,868,869,
        5,13,0,0,869,871,3,114,57,0,870,868,1,0,0,0,871,874,1,0,0,0,872,
        870,1,0,0,0,872,873,1,0,0,0,873,113,1,0,0,0,874,872,1,0,0,0,875,
        882,3,194,97,0,876,877,5,69,0,0,877,879,3,318,159,0,878,876,1,0,
        0,0,878,879,1,0,0,0,879,880,1,0,0,0,880,881,5,5,0,0,881,883,3,96,
        48,0,882,878,1,0,0,0,882,883,1,0,0,0,883,886,1,0,0,0,884,885,5,80,
        0,0,885,887,3,336,168,0,886,884,1,0,0,0,886,887,1,0,0,0,887,115,
        1,0,0,0,888,889,5,65,0,0,889,894,5,64,0,0,890,891,5,74,0,0,891,892,
        5,65,0,0,892,894,5,64,0,0,893,888,1,0,0,0,893,890,1,0,0,0,894,895,
        1,0,0,0,895,900,3,118,59,0,896,897,5,13,0,0,897,899,3,118,59,0,898,
        896,1,0,0,0,899,902,1,0,0,0,900,898,1,0,0,0,900,901,1,0,0,0,901,
        117,1,0,0,0,902,900,1,0,0,0,903,906,3,96,48,0,904,907,5,75,0,0,905,
        907,5,76,0,0,906,904,1,0,0,0,906,905,1,0,0,0,906,907,1,0,0,0,907,
        913,1,0,0,0,908,911,5,72,0,0,909,912,5,81,0,0,910,912,5,82,0,0,911,
        909,1,0,0,0,911,910,1,0,0,0,912,914,1,0,0,0,913,908,1,0,0,0,913,
        914,1,0,0,0,914,917,1,0,0,0,915,916,5,80,0,0,916,918,3,336,168,0,
        917,915,1,0,0,0,917,918,1,0,0,0,918,119,1,0,0,0,919,920,5,73,0,0,
        920,921,3,194,97,0,921,121,1,0,0,0,922,925,5,77,0,0,923,925,5,78,
        0,0,924,922,1,0,0,0,924,923,1,0,0,0,925,926,1,0,0,0,926,931,3,124,
        62,0,927,928,5,13,0,0,928,930,3,124,62,0,929,927,1,0,0,0,930,933,
        1,0,0,0,931,929,1,0,0,0,931,932,1,0,0,0,932,934,1,0,0,0,933,931,
        1,0,0,0,934,935,5,79,0,0,935,936,3,96,48,0,936,123,1,0,0,0,937,940,
        3,194,97,0,938,939,5,69,0,0,939,941,3,318,159,0,940,938,1,0,0,0,
        940,941,1,0,0,0,941,942,1,0,0,0,942,943,5,68,0,0,943,944,3,96,48,
        0,944,125,1,0,0,0,945,946,5,83,0,0,946,947,5,8,0,0,947,948,3,94,
        47,0,948,950,5,9,0,0,949,951,3,128,64,0,950,949,1,0,0,0,951,952,
        1,0,0,0,952,950,1,0,0,0,952,953,1,0,0,0,953,954,1,0,0,0,954,955,
        5,87,0,0,955,956,5,66,0,0,956,957,3,96,48,0,957,127,1,0,0,0,958,
        959,5,84,0,0,959,961,3,96,48,0,960,958,1,0,0,0,961,962,1,0,0,0,962,
        960,1,0,0,0,962,963,1,0,0,0,963,964,1,0,0,0,964,965,5,66,0,0,965,
        966,3,96,48,0,966,129,1,0,0,0,967,968,5,90,0,0,968,969,5,8,0,0,969,
        970,3,94,47,0,970,972,5,9,0,0,971,973,3,132,66,0,972,971,1,0,0,0,
        973,974,1,0,0,0,974,972,1,0,0,0,974,975,1,0,0,0,975,976,1,0,0,0,
        976,978,5,87,0,0,977,979,3,194,97,0,978,977,1,0,0,0,978,979,1,0,
        0,0,979,980,1,0,0,0,980,981,5,66,0,0,981,982,3,96,48,0,982,131,1,
        0,0,0,983,987,5,84,0,0,984,985,3,194,97,0,985,986,5,69,0,0,986,988,
        1,0,0,0,987,984,1,0,0,0,987,988,1,0,0,0,988,989,1,0,0,0,989,994,
        3,318,159,0,990,991,5,11,0,0,991,993,3,318,159,0,992,990,1,0,0,0,
        993,996,1,0,0,0,994,992,1,0,0,0,994,995,1,0,0,0,995,997,1,0,0,0,
        996,994,1,0,0,0,997,998,5,66,0,0,998,999,3,96,48,0,999,133,1,0,0,
        0,1000,1001,5,67,0,0,1001,1002,5,8,0,0,1002,1003,3,94,47,0,1003,
        1004,5,9,0,0,1004,1005,5,88,0,0,1005,1006,3,96,48,0,1006,1007,5,
        89,0,0,1007,1008,3,96,48,0,1008,135,1,0,0,0,1009,1010,5,85,0,0,1010,
        1011,5,6,0,0,1011,1012,3,94,47,0,1012,1014,5,7,0,0,1013,1015,3,138,
        69,0,1014,1013,1,0,0,0,1015,1016,1,0,0,0,1016,1014,1,0,0,0,1016,
        1017,1,0,0,0,1017,137,1,0,0,0,1018,1021,5,86,0,0,1019,1022,5,10,
        0,0,1020,1022,3,74,37,0,1021,1019,1,0,0,0,1021,1020,1,0,0,0,1022,
        1030,1,0,0,0,1023,1026,5,11,0,0,1024,1027,5,10,0,0,1025,1027,3,74,
        37,0,1026,1024,1,0,0,0,1026,1025,1,0,0,0,1027,1029,1,0,0,0,1028,
        1023,1,0,0,0,1029,1032,1,0,0,0,1030,1028,1,0,0,0,1030,1031,1,0,0,
        0,1031,1033,1,0,0,0,1032,1030,1,0,0,0,1033,1034,5,6,0,0,1034,1035,
        3,94,47,0,1035,1036,5,7,0,0,1036,139,1,0,0,0,1037,1042,3,142,71,
        0,1038,1039,5,91,0,0,1039,1041,3,142,71,0,1040,1038,1,0,0,0,1041,
        1044,1,0,0,0,1042,1040,1,0,0,0,1042,1043,1,0,0,0,1043,141,1,0,0,
        0,1044,1042,1,0,0,0,1045,1050,3,144,72,0,1046,1047,5,92,0,0,1047,
        1049,3,144,72,0,1048,1046,1,0,0,0,1049,1052,1,0,0,0,1050,1048,1,
        0,0,0,1050,1051,1,0,0,0,1051,143,1,0,0,0,1052,1050,1,0,0,0,1053,
        1055,5,93,0,0,1054,1053,1,0,0,0,1054,1055,1,0,0,0,1055,1056,1,0,
        0,0,1056,1057,3,146,73,0,1057,145,1,0,0,0,1058,1061,3,148,74,0,1059,
        1060,7,3,0,0,1060,1062,3,148,74,0,1061,1059,1,0,0,0,1061,1062,1,
        0,0,0,1062,147,1,0,0,0,1063,1068,3,150,75,0,1064,1065,5,45,0,0,1065,
        1067,3,150,75,0,1066,1064,1,0,0,0,1067,1070,1,0,0,0,1068,1066,1,
        0,0,0,1068,1069,1,0,0,0,1069,149,1,0,0,0,1070,1068,1,0,0,0,1071,
        1074,3,152,76,0,1072,1073,5,94,0,0,1073,1075,3,152,76,0,1074,1072,
        1,0,0,0,1074,1075,1,0,0,0,1075,151,1,0,0,0,1076,1081,3,154,77,0,
        1077,1078,7,4,0,0,1078,1080,3,154,77,0,1079,1077,1,0,0,0,1080,1083,
        1,0,0,0,1081,1079,1,0,0,0,1081,1082,1,0,0,0,1082,153,1,0,0,0,1083,
        1081,1,0,0,0,1084,1089,3,156,78,0,1085,1086,7,5,0,0,1086,1088,3,
        156,78,0,1087,1085,1,0,0,0,1088,1091,1,0,0,0,1089,1087,1,0,0,0,1089,
        1090,1,0,0,0,1090,155,1,0,0,0,1091,1089,1,0,0,0,1092,1096,3,158,
        79,0,1093,1094,5,95,0,0,1094,1095,5,96,0,0,1095,1097,3,318,159,0,
        1096,1093,1,0,0,0,1096,1097,1,0,0,0,1097,157,1,0,0,0,1098,1102,3,
        160,80,0,1099,1100,5,98,0,0,1100,1101,5,97,0,0,1101,1103,3,318,159,
        0,1102,1099,1,0,0,0,1102,1103,1,0,0,0,1103,159,1,0,0,0,1104,1108,
        3,162,81,0,1105,1106,5,99,0,0,1106,1107,5,69,0,0,1107,1109,3,318,
        159,0,1108,1105,1,0,0,0,1108,1109,1,0,0,0,1109,161,1,0,0,0,1110,
        1114,3,164,82,0,1111,1112,5,101,0,0,1112,1113,5,69,0,0,1113,1115,
        3,330,165,0,1114,1111,1,0,0,0,1114,1115,1,0,0,0,1115,163,1,0,0,0,
        1116,1120,3,166,83,0,1117,1118,5,100,0,0,1118,1119,5,69,0,0,1119,
        1121,3,330,165,0,1120,1117,1,0,0,0,1120,1121,1,0,0,0,1121,165,1,
        0,0,0,1122,1131,3,170,85,0,1123,1124,5,3,0,0,1124,1125,5,43,0,0,
        1125,1126,1,0,0,0,1126,1127,3,168,84,0,1127,1128,3,206,103,0,1128,
        1130,1,0,0,0,1129,1123,1,0,0,0,1130,1133,1,0,0,0,1131,1129,1,0,0,
        0,1131,1132,1,0,0,0,1132,167,1,0,0,0,1133,1131,1,0,0,0,1134,1138,
        3,74,37,0,1135,1138,3,194,97,0,1136,1138,3,196,98,0,1137,1134,1,
        0,0,0,1137,1135,1,0,0,0,1137,1136,1,0,0,0,1138,169,1,0,0,0,1139,
        1141,7,4,0,0,1140,1139,1,0,0,0,1141,1144,1,0,0,0,1142,1140,1,0,0,
        0,1142,1143,1,0,0,0,1143,1145,1,0,0,0,1144,1142,1,0,0,0,1145,1146,
        3,172,86,0,1146,171,1,0,0,0,1147,1151,3,178,89,0,1148,1151,3,174,
        87,0,1149,1151,3,176,88,0,1150,1147,1,0,0,0,1150,1148,1,0,0,0,1150,
        1149,1,0,0,0,1151,173,1,0,0,0,1152,1153,5,108,0,0,1153,1154,5,107,
        0,0,1154,1155,3,318,159,0,1155,1156,5,6,0,0,1156,1157,3,94,47,0,
        1157,1158,5,7,0,0,1158,175,1,0,0,0,1159,1160,5,109,0,0,1160,1161,
        5,107,0,0,1161,1162,3,318,159,0,1162,1163,5,6,0,0,1163,1164,3,94,
        47,0,1164,1165,5,7,0,0,1165,177,1,0,0,0,1166,1171,3,246,123,0,1167,
        1168,5,51,0,0,1168,1170,3,246,123,0,1169,1167,1,0,0,0,1170,1173,
        1,0,0,0,1171,1169,1,0,0,0,1171,1172,1,0,0,0,1172,179,1,0,0,0,1173,
        1171,1,0,0,0,1174,1182,3,190,95,0,1175,1181,3,182,91,0,1176,1181,
        3,186,93,0,1177,1181,3,188,94,0,1178,1181,3,184,92,0,1179,1181,3,
        206,103,0,1180,1175,1,0,0,0,1180,1176,1,0,0,0,1180,1177,1,0,0,0,
        1180,1178,1,0,0,0,1180,1179,1,0,0,0,1181,1184,1,0,0,0,1182,1180,
        1,0,0,0,1182,1183,1,0,0,0,1183,181,1,0,0,0,1184,1182,1,0,0,0,1185,
        1186,5,52,0,0,1186,1187,5,52,0,0,1187,1188,3,94,47,0,1188,1189,5,
        53,0,0,1189,1190,5,53,0,0,1190,183,1,0,0,0,1191,1192,5,52,0,0,1192,
        1193,5,53,0,0,1193,185,1,0,0,0,1194,1195,5,52,0,0,1195,1196,3,94,
        47,0,1196,1197,5,53,0,0,1197,187,1,0,0,0,1198,1205,5,54,0,0,1199,
        1206,3,340,170,0,1200,1206,3,338,169,0,1201,1206,5,188,0,0,1202,
        1206,3,196,98,0,1203,1206,3,194,97,0,1204,1206,3,198,99,0,1205,1199,
        1,0,0,0,1205,1200,1,0,0,0,1205,1201,1,0,0,0,1205,1202,1,0,0,0,1205,
        1203,1,0,0,0,1205,1204,1,0,0,0,1206,189,1,0,0,0,1207,1223,5,181,
        0,0,1208,1223,5,105,0,0,1209,1223,5,106,0,0,1210,1223,5,182,0,0,
        1211,1223,3,338,169,0,1212,1223,3,194,97,0,1213,1223,3,196,98,0,
        1214,1223,3,198,99,0,1215,1223,3,320,160,0,1216,1223,3,204,102,0,
        1217,1223,3,200,100,0,1218,1223,3,202,101,0,1219,1223,3,334,167,
        0,1220,1223,3,210,105,0,1221,1223,3,192,96,0,1222,1207,1,0,0,0,1222,
        1208,1,0,0,0,1222,1209,1,0,0,0,1222,1210,1,0,0,0,1222,1211,1,0,0,
        0,1222,1212,1,0,0,0,1222,1213,1,0,0,0,1222,1214,1,0,0,0,1222,1215,
        1,0,0,0,1222,1216,1,0,0,0,1222,1217,1,0,0,0,1222,1218,1,0,0,0,1222,
        1219,1,0,0,0,1222,1220,1,0,0,0,1222,1221,1,0,0,0,1223,191,1,0,0,
        0,1224,1225,5,6,0,0,1225,1226,3,14,7,0,1226,1227,5,7,0,0,1227,193,
        1,0,0,0,1228,1229,5,4,0,0,1229,1230,3,74,37,0,1230,195,1,0,0,0,1231,
        1233,5,8,0,0,1232,1234,3,94,47,0,1233,1232,1,0,0,0,1233,1234,1,0,
        0,0,1234,1235,1,0,0,0,1235,1236,5,9,0,0,1236,197,1,0,0,0,1237,1238,
        5,55,0,0,1238,199,1,0,0,0,1239,1240,5,16,0,0,1240,1241,5,6,0,0,1241,
        1242,3,94,47,0,1242,1243,5,7,0,0,1243,201,1,0,0,0,1244,1245,5,104,
        0,0,1245,1246,5,6,0,0,1246,1247,3,94,47,0,1247,1248,5,7,0,0,1248,
        203,1,0,0,0,1249,1250,3,74,37,0,1250,1251,3,206,103,0,1251,205,1,
        0,0,0,1252,1261,5,8,0,0,1253,1258,3,208,104,0,1254,1255,5,13,0,0,
        1255,1257,3,208,104,0,1256,1254,1,0,0,0,1257,1260,1,0,0,0,1258,1256,
        1,0,0,0,1258,1259,1,0,0,0,1259,1262,1,0,0,0,1260,1258,1,0,0,0,1261,
        1253,1,0,0,0,1261,1262,1,0,0,0,1262,1263,1,0,0,0,1263,1264,5,9,0,
        0,1264,207,1,0,0,0,1265,1268,3,96,48,0,1266,1268,5,180,0,0,1267,
        1265,1,0,0,0,1267,1266,1,0,0,0,1268,209,1,0,0,0,1269,1272,3,212,
        106,0,1270,1272,3,214,107,0,1271,1269,1,0,0,0,1271,1270,1,0,0,0,
        1272,211,1,0,0,0,1273,1274,3,74,37,0,1274,1275,5,56,0,0,1275,1276,
        5,182,0,0,1276,213,1,0,0,0,1277,1278,3,50,25,0,1278,1279,5,30,0,
        0,1279,1281,5,8,0,0,1280,1282,3,90,45,0,1281,1280,1,0,0,0,1281,1282,
        1,0,0,0,1282,1283,1,0,0,0,1283,1286,5,9,0,0,1284,1285,5,69,0,0,1285,
        1287,3,318,159,0,1286,1284,1,0,0,0,1286,1287,1,0,0,0,1287,1288,1,
        0,0,0,1288,1289,5,6,0,0,1289,1290,3,16,8,0,1290,1291,5,7,0,0,1291,
        215,1,0,0,0,1292,1293,5,114,0,0,1293,1294,5,125,0,0,1294,1295,3,
        96,48,0,1295,1296,5,121,0,0,1296,1300,3,96,48,0,1297,1298,5,70,0,
        0,1298,1299,5,124,0,0,1299,1301,3,96,48,0,1300,1297,1,0,0,0,1300,
        1301,1,0,0,0,1301,1316,1,0,0,0,1302,1303,5,114,0,0,1303,1304,5,125,
        0,0,1304,1309,3,332,166,0,1305,1306,5,13,0,0,1306,1308,3,332,166,
        0,1307,1305,1,0,0,0,1308,1311,1,0,0,0,1309,1307,1,0,0,0,1309,1310,
        1,0,0,0,1310,1312,1,0,0,0,1311,1309,1,0,0,0,1312,1313,5,121,0,0,
        1313,1314,3,96,48,0,1314,1316,1,0,0,0,1315,1292,1,0,0,0,1315,1302,
        1,0,0,0,1316,217,1,0,0,0,1317,1318,5,115,0,0,1318,1319,5,125,0,0,
        1319,1320,3,228,114,0,1320,219,1,0,0,0,1321,1322,5,116,0,0,1322,
        1323,5,125,0,0,1323,1324,3,228,114,0,1324,1325,5,69,0,0,1325,1326,
        3,96,48,0,1326,221,1,0,0,0,1327,1328,5,117,0,0,1328,1329,5,122,0,
        0,1329,1330,5,96,0,0,1330,1331,5,125,0,0,1331,1332,3,228,114,0,1332,
        1333,5,123,0,0,1333,1334,3,96,48,0,1334,223,1,0,0,0,1335,1336,5,
        118,0,0,1336,1341,3,230,115,0,1337,1338,5,13,0,0,1338,1340,3,230,
        115,0,1339,1337,1,0,0,0,1340,1343,1,0,0,0,1341,1339,1,0,0,0,1341,
        1342,1,0,0,0,1342,1344,1,0,0,0,1343,1341,1,0,0,0,1344,1345,5,119,
        0,0,1345,1346,3,96,48,0,1346,1347,5,66,0,0,1347,1348,3,96,48,0,1348,
        225,1,0,0,0,1349,1350,5,120,0,0,1350,1351,5,125,0,0,1351,1352,3,
        96,48,0,1352,1353,5,121,0,0,1353,1354,3,96,48,0,1354,227,1,0,0,0,
        1355,1356,3,180,90,0,1356,229,1,0,0,0,1357,1358,3,194,97,0,1358,
        1359,5,5,0,0,1359,1360,3,96,48,0,1360,231,1,0,0,0,1361,1362,5,127,
        0,0,1362,1363,5,128,0,0,1363,1364,7,6,0,0,1364,1365,5,8,0,0,1365,
        1366,3,98,49,0,1366,1369,5,9,0,0,1367,1368,5,123,0,0,1368,1370,3,
        96,48,0,1369,1367,1,0,0,0,1369,1370,1,0,0,0,1370,233,1,0,0,0,1371,
        1374,5,115,0,0,1372,1375,5,133,0,0,1373,1375,5,134,0,0,1374,1372,
        1,0,0,0,1374,1373,1,0,0,0,1375,1377,1,0,0,0,1376,1378,3,96,48,0,
        1377,1376,1,0,0,0,1377,1378,1,0,0,0,1378,1379,1,0,0,0,1379,1380,
        5,135,0,0,1380,1381,5,128,0,0,1381,1382,7,6,0,0,1382,1383,5,8,0,
        0,1383,1384,3,98,49,0,1384,1385,5,9,0,0,1385,235,1,0,0,0,1386,1387,
        5,115,0,0,1387,1388,3,96,48,0,1388,1389,5,135,0,0,1389,1390,5,128,
        0,0,1390,237,1,0,0,0,1391,1392,5,114,0,0,1392,1397,3,96,48,0,1393,
        1394,5,70,0,0,1394,1398,3,96,48,0,1395,1398,5,133,0,0,1396,1398,
        5,134,0,0,1397,1393,1,0,0,0,1397,1395,1,0,0,0,1397,1396,1,0,0,0,
        1398,1399,1,0,0,0,1399,1400,5,121,0,0,1400,1401,5,128,0,0,1401,1402,
        7,6,0,0,1402,1403,5,8,0,0,1403,1404,3,98,49,0,1404,1405,5,9,0,0,
        1405,239,1,0,0,0,1406,1407,5,114,0,0,1407,1410,3,96,48,0,1408,1411,
        5,138,0,0,1409,1411,5,137,0,0,1410,1408,1,0,0,0,1410,1409,1,0,0,
        0,1411,1412,1,0,0,0,1412,1413,3,96,48,0,1413,1414,5,121,0,0,1414,
        1415,5,128,0,0,1415,241,1,0,0,0,1416,1417,7,7,0,0,1417,1418,5,128,
        0,0,1418,1419,7,6,0,0,1419,1420,5,8,0,0,1420,1421,3,98,49,0,1421,
        1422,5,9,0,0,1422,243,1,0,0,0,1423,1424,5,136,0,0,1424,1425,3,96,
        48,0,1425,1426,5,121,0,0,1426,1427,3,96,48,0,1427,1428,5,68,0,0,
        1428,1429,5,128,0,0,1429,245,1,0,0,0,1430,1432,5,143,0,0,1431,1433,
        3,248,124,0,1432,1431,1,0,0,0,1432,1433,1,0,0,0,1433,1438,1,0,0,
        0,1434,1435,5,144,0,0,1435,1438,3,248,124,0,1436,1438,3,248,124,
        0,1437,1430,1,0,0,0,1437,1434,1,0,0,0,1437,1436,1,0,0,0,1438,247,
        1,0,0,0,1439,1444,3,250,125,0,1440,1441,7,8,0,0,1441,1443,3,250,
        125,0,1442,1440,1,0,0,0,1443,1446,1,0,0,0,1444,1442,1,0,0,0,1444,
        1445,1,0,0,0,1445,249,1,0,0,0,1446,1444,1,0,0,0,1447,1450,3,180,
        90,0,1448,1450,3,252,126,0,1449,1447,1,0,0,0,1449,1448,1,0,0,0,1450,
        251,1,0,0,0,1451,1454,3,260,130,0,1452,1454,3,254,127,0,1453,1451,
        1,0,0,0,1453,1452,1,0,0,0,1454,1455,1,0,0,0,1455,1456,3,276,138,
        0,1456,253,1,0,0,0,1457,1458,3,256,128,0,1458,1459,3,266,133,0,1459,
        1462,1,0,0,0,1460,1462,3,258,129,0,1461,1457,1,0,0,0,1461,1460,1,
        0,0,0,1462,255,1,0,0,0,1463,1464,7,9,0,0,1464,1465,5,18,0,0,1465,
        1466,5,18,0,0,1466,257,1,0,0,0,1467,1469,5,145,0,0,1468,1467,1,0,
        0,0,1468,1469,1,0,0,0,1469,1470,1,0,0,0,1470,1471,3,266,133,0,1471,
        259,1,0,0,0,1472,1473,3,262,131,0,1473,1474,3,266,133,0,1474,1477,
        1,0,0,0,1475,1477,3,264,132,0,1476,1472,1,0,0,0,1476,1475,1,0,0,
        0,1477,261,1,0,0,0,1478,1479,7,10,0,0,1479,1480,5,18,0,0,1480,1481,
        5,18,0,0,1481,263,1,0,0,0,1482,1483,5,57,0,0,1483,265,1,0,0,0,1484,
        1487,3,268,134,0,1485,1487,3,278,139,0,1486,1484,1,0,0,0,1486,1485,
        1,0,0,0,1487,267,1,0,0,0,1488,1491,3,74,37,0,1489,1491,3,270,135,
        0,1490,1488,1,0,0,0,1490,1489,1,0,0,0,1491,269,1,0,0,0,1492,1496,
        5,10,0,0,1493,1496,3,272,136,0,1494,1496,3,274,137,0,1495,1492,1,
        0,0,0,1495,1493,1,0,0,0,1495,1494,1,0,0,0,1496,271,1,0,0,0,1497,
        1498,5,188,0,0,1498,1499,5,18,0,0,1499,1500,5,10,0,0,1500,273,1,
        0,0,0,1501,1502,5,10,0,0,1502,1503,5,18,0,0,1503,1504,5,188,0,0,
        1504,275,1,0,0,0,1505,1507,3,186,93,0,1506,1505,1,0,0,0,1507,1510,
        1,0,0,0,1508,1506,1,0,0,0,1508,1509,1,0,0,0,1509,277,1,0,0,0,1510,
        1508,1,0,0,0,1511,1523,3,284,142,0,1512,1523,3,302,151,0,1513,1523,
        3,294,147,0,1514,1523,3,306,153,0,1515,1523,3,298,149,0,1516,1523,
        3,292,146,0,1517,1523,3,288,144,0,1518,1523,3,286,143,0,1519,1523,
        3,290,145,0,1520,1523,3,282,141,0,1521,1523,3,280,140,0,1522,1511,
        1,0,0,0,1522,1512,1,0,0,0,1522,1513,1,0,0,0,1522,1514,1,0,0,0,1522,
        1515,1,0,0,0,1522,1516,1,0,0,0,1522,1517,1,0,0,0,1522,1518,1,0,0,
        0,1522,1519,1,0,0,0,1522,1520,1,0,0,0,1522,1521,1,0,0,0,1523,279,
        1,0,0,0,1524,1525,5,158,0,0,1525,1526,5,8,0,0,1526,1527,5,9,0,0,
        1527,281,1,0,0,0,1528,1529,5,159,0,0,1529,1530,5,8,0,0,1530,1531,
        5,9,0,0,1531,283,1,0,0,0,1532,1533,5,161,0,0,1533,1536,5,8,0,0,1534,
        1537,3,302,151,0,1535,1537,3,306,153,0,1536,1534,1,0,0,0,1536,1535,
        1,0,0,0,1536,1537,1,0,0,0,1537,1538,1,0,0,0,1538,1539,5,9,0,0,1539,
        285,1,0,0,0,1540,1541,5,162,0,0,1541,1542,5,8,0,0,1542,1543,5,9,
        0,0,1543,287,1,0,0,0,1544,1545,5,172,0,0,1545,1546,5,8,0,0,1546,
        1547,5,9,0,0,1547,289,1,0,0,0,1548,1549,5,164,0,0,1549,1550,5,8,
        0,0,1550,1551,5,9,0,0,1551,291,1,0,0,0,1552,1553,5,163,0,0,1553,
        1556,5,8,0,0,1554,1557,5,188,0,0,1555,1557,3,338,169,0,1556,1554,
        1,0,0,0,1556,1555,1,0,0,0,1556,1557,1,0,0,0,1557,1558,1,0,0,0,1558,
        1559,5,9,0,0,1559,293,1,0,0,0,1560,1561,5,148,0,0,1561,1567,5,8,
        0,0,1562,1565,3,296,148,0,1563,1564,5,13,0,0,1564,1566,3,316,158,
        0,1565,1563,1,0,0,0,1565,1566,1,0,0,0,1566,1568,1,0,0,0,1567,1562,
        1,0,0,0,1567,1568,1,0,0,0,1568,1569,1,0,0,0,1569,1570,5,9,0,0,1570,
        295,1,0,0,0,1571,1574,3,310,155,0,1572,1574,5,10,0,0,1573,1571,1,
        0,0,0,1573,1572,1,0,0,0,1574,297,1,0,0,0,1575,1576,5,165,0,0,1576,
        1577,5,8,0,0,1577,1578,3,300,150,0,1578,1579,5,9,0,0,1579,299,1,
        0,0,0,1580,1581,3,310,155,0,1581,301,1,0,0,0,1582,1583,5,142,0,0,
        1583,1592,5,8,0,0,1584,1590,3,304,152,0,1585,1586,5,13,0,0,1586,
        1588,3,316,158,0,1587,1589,5,180,0,0,1588,1587,1,0,0,0,1588,1589,
        1,0,0,0,1589,1591,1,0,0,0,1590,1585,1,0,0,0,1590,1591,1,0,0,0,1591,
        1593,1,0,0,0,1592,1584,1,0,0,0,1592,1593,1,0,0,0,1593,1594,1,0,0,
        0,1594,1595,5,9,0,0,1595,303,1,0,0,0,1596,1599,3,312,156,0,1597,
        1599,5,10,0,0,1598,1596,1,0,0,0,1598,1597,1,0,0,0,1599,305,1,0,0,
        0,1600,1601,5,166,0,0,1601,1602,5,8,0,0,1602,1603,3,308,154,0,1603,
        1604,5,9,0,0,1604,307,1,0,0,0,1605,1606,3,312,156,0,1606,309,1,0,
        0,0,1607,1608,3,74,37,0,1608,311,1,0,0,0,1609,1610,3,74,37,0,1610,
        313,1,0,0,0,1611,1612,3,316,158,0,1612,315,1,0,0,0,1613,1614,3,74,
        37,0,1614,317,1,0,0,0,1615,1616,5,8,0,0,1616,1624,5,9,0,0,1617,1621,
        3,322,161,0,1618,1622,5,180,0,0,1619,1622,5,10,0,0,1620,1622,5,46,
        0,0,1621,1618,1,0,0,0,1621,1619,1,0,0,0,1621,1620,1,0,0,0,1621,1622,
        1,0,0,0,1622,1624,1,0,0,0,1623,1615,1,0,0,0,1623,1617,1,0,0,0,1624,
        319,1,0,0,0,1625,1634,5,6,0,0,1626,1631,3,332,166,0,1627,1628,5,
        13,0,0,1628,1630,3,332,166,0,1629,1627,1,0,0,0,1630,1633,1,0,0,0,
        1631,1629,1,0,0,0,1631,1632,1,0,0,0,1632,1635,1,0,0,0,1633,1631,
        1,0,0,0,1634,1626,1,0,0,0,1634,1635,1,0,0,0,1635,1636,1,0,0,0,1636,
        1642,5,7,0,0,1637,1638,5,58,0,0,1638,1639,3,94,47,0,1639,1640,5,
        59,0,0,1640,1642,1,0,0,0,1641,1625,1,0,0,0,1641,1637,1,0,0,0,1642,
        321,1,0,0,0,1643,1647,3,74,37,0,1644,1647,5,181,0,0,1645,1647,3,
        324,162,0,1646,1643,1,0,0,0,1646,1644,1,0,0,0,1646,1645,1,0,0,0,
        1647,323,1,0,0,0,1648,1651,3,326,163,0,1649,1651,3,328,164,0,1650,
        1648,1,0,0,0,1650,1649,1,0,0,0,1651,325,1,0,0,0,1652,1653,5,30,0,
        0,1653,1654,5,8,0,0,1654,1655,5,10,0,0,1655,1656,5,9,0,0,1656,327,
        1,0,0,0,1657,1658,5,30,0,0,1658,1667,5,8,0,0,1659,1664,3,318,159,
        0,1660,1661,5,13,0,0,1661,1663,3,318,159,0,1662,1660,1,0,0,0,1663,
        1666,1,0,0,0,1664,1662,1,0,0,0,1664,1665,1,0,0,0,1665,1668,1,0,0,
        0,1666,1664,1,0,0,0,1667,1659,1,0,0,0,1667,1668,1,0,0,0,1668,1669,
        1,0,0,0,1669,1670,5,9,0,0,1670,1671,5,69,0,0,1671,1672,3,318,159,
        0,1672,329,1,0,0,0,1673,1675,3,322,161,0,1674,1676,5,180,0,0,1675,
        1674,1,0,0,0,1675,1676,1,0,0,0,1676,331,1,0,0,0,1677,1678,3,96,48,
        0,1678,1679,7,11,0,0,1679,1680,3,96,48,0,1680,333,1,0,0,0,1681,1683,
        5,52,0,0,1682,1684,3,94,47,0,1683,1682,1,0,0,0,1683,1684,1,0,0,0,
        1684,1685,1,0,0,0,1685,1686,5,53,0,0,1686,335,1,0,0,0,1687,1688,
        3,338,169,0,1688,337,1,0,0,0,1689,1690,5,179,0,0,1690,339,1,0,0,
        0,1691,1692,7,12,0,0,1692,341,1,0,0,0,157,350,354,370,376,384,392,
        400,415,445,453,455,477,487,497,502,507,511,523,527,536,543,557,
        561,564,569,579,587,591,604,616,642,650,655,658,662,671,680,683,
        691,698,700,707,714,716,724,729,736,743,753,760,767,774,783,800,
        804,812,814,826,832,836,840,851,857,872,878,882,886,893,900,906,
        911,913,917,924,931,940,952,962,974,978,987,994,1016,1021,1026,1030,
        1042,1050,1054,1061,1068,1074,1081,1089,1096,1102,1108,1114,1120,
        1131,1137,1142,1150,1171,1180,1182,1205,1222,1233,1258,1261,1267,
        1271,1281,1286,1300,1309,1315,1341,1369,1374,1377,1397,1410,1432,
        1437,1444,1449,1453,1461,1468,1476,1486,1490,1495,1508,1522,1536,
        1556,1565,1567,1573,1588,1590,1592,1598,1621,1623,1631,1634,1641,
        1646,1650,1664,1667,1675,1683
    ];

    private static __ATN: antlr.ATN;
    public static get _ATN(): antlr.ATN {
        if (!jsoniqParser.__ATN) {
            jsoniqParser.__ATN = new antlr.ATNDeserializer().deserialize(jsoniqParser._serializedATN);
        }

        return jsoniqParser.__ATN;
    }


    private static readonly vocabulary = new antlr.Vocabulary(jsoniqParser.literalNames, jsoniqParser.symbolicNames, []);

    public override get vocabulary(): antlr.Vocabulary {
        return jsoniqParser.vocabulary;
    }

    private static readonly decisionsToDFA = jsoniqParser._ATN.decisionToState.map( (ds: antlr.DecisionState, index: number) => new antlr.DFA(ds, index) );
}

export class ModuleAndThisIsItContext extends antlr.ParserRuleContext {
    public constructor(parent: antlr.ParserRuleContext | null, invokingState: number) {
        super(parent, invokingState);
    }
    public module(): ModuleContext {
        return this.getRuleContext(0, ModuleContext)!;
    }
    public EOF(): antlr.TerminalNode {
        return this.getToken(jsoniqParser.EOF, 0)!;
    }
    public override get ruleIndex(): number {
        return jsoniqParser.RULE_moduleAndThisIsIt;
    }
    public override enterRule(listener: jsoniqListener): void {
        if(listener.enterModuleAndThisIsIt) {
             listener.enterModuleAndThisIsIt(this);
        }
    }
    public override exitRule(listener: jsoniqListener): void {
        if(listener.exitModuleAndThisIsIt) {
             listener.exitModuleAndThisIsIt(this);
        }
    }
}


export class ModuleContext extends antlr.ParserRuleContext {
    public _vers?: StringLiteralContext;
    public _main?: MainModuleContext;
    public constructor(parent: antlr.ParserRuleContext | null, invokingState: number) {
        super(parent, invokingState);
    }
    public libraryModule(): LibraryModuleContext | null {
        return this.getRuleContext(0, LibraryModuleContext);
    }
    public Kjsoniq(): antlr.TerminalNode | null {
        return this.getToken(jsoniqParser.Kjsoniq, 0);
    }
    public Kversion(): antlr.TerminalNode | null {
        return this.getToken(jsoniqParser.Kversion, 0);
    }
    public Ksemicolon(): antlr.TerminalNode | null {
        return this.getToken(jsoniqParser.Ksemicolon, 0);
    }
    public mainModule(): MainModuleContext | null {
        return this.getRuleContext(0, MainModuleContext);
    }
    public stringLiteral(): StringLiteralContext | null {
        return this.getRuleContext(0, StringLiteralContext);
    }
    public override get ruleIndex(): number {
        return jsoniqParser.RULE_module;
    }
    public override enterRule(listener: jsoniqListener): void {
        if(listener.enterModule) {
             listener.enterModule(this);
        }
    }
    public override exitRule(listener: jsoniqListener): void {
        if(listener.exitModule) {
             listener.exitModule(this);
        }
    }
}


export class MainModuleContext extends antlr.ParserRuleContext {
    public constructor(parent: antlr.ParserRuleContext | null, invokingState: number) {
        super(parent, invokingState);
    }
    public prolog(): PrologContext {
        return this.getRuleContext(0, PrologContext)!;
    }
    public program(): ProgramContext {
        return this.getRuleContext(0, ProgramContext)!;
    }
    public override get ruleIndex(): number {
        return jsoniqParser.RULE_mainModule;
    }
    public override enterRule(listener: jsoniqListener): void {
        if(listener.enterMainModule) {
             listener.enterMainModule(this);
        }
    }
    public override exitRule(listener: jsoniqListener): void {
        if(listener.exitMainModule) {
             listener.exitMainModule(this);
        }
    }
}


export class LibraryModuleContext extends antlr.ParserRuleContext {
    public constructor(parent: antlr.ParserRuleContext | null, invokingState: number) {
        super(parent, invokingState);
    }
    public Kmodule(): antlr.TerminalNode {
        return this.getToken(jsoniqParser.Kmodule, 0)!;
    }
    public Knamespace(): antlr.TerminalNode {
        return this.getToken(jsoniqParser.Knamespace, 0)!;
    }
    public NCName(): antlr.TerminalNode {
        return this.getToken(jsoniqParser.NCName, 0)!;
    }
    public Kequal(): antlr.TerminalNode {
        return this.getToken(jsoniqParser.Kequal, 0)!;
    }
    public uriLiteral(): UriLiteralContext {
        return this.getRuleContext(0, UriLiteralContext)!;
    }
    public Ksemicolon(): antlr.TerminalNode {
        return this.getToken(jsoniqParser.Ksemicolon, 0)!;
    }
    public prolog(): PrologContext {
        return this.getRuleContext(0, PrologContext)!;
    }
    public override get ruleIndex(): number {
        return jsoniqParser.RULE_libraryModule;
    }
    public override enterRule(listener: jsoniqListener): void {
        if(listener.enterLibraryModule) {
             listener.enterLibraryModule(this);
        }
    }
    public override exitRule(listener: jsoniqListener): void {
        if(listener.exitLibraryModule) {
             listener.exitLibraryModule(this);
        }
    }
}


export class PrologContext extends antlr.ParserRuleContext {
    public constructor(parent: antlr.ParserRuleContext | null, invokingState: number) {
        super(parent, invokingState);
    }
    public Ksemicolon(): antlr.TerminalNode[];
    public Ksemicolon(i: number): antlr.TerminalNode | null;
    public Ksemicolon(i?: number): antlr.TerminalNode | null | antlr.TerminalNode[] {
    	if (i === undefined) {
    		return this.getTokens(jsoniqParser.Ksemicolon);
    	} else {
    		return this.getToken(jsoniqParser.Ksemicolon, i);
    	}
    }
    public annotatedDecl(): AnnotatedDeclContext[];
    public annotatedDecl(i: number): AnnotatedDeclContext | null;
    public annotatedDecl(i?: number): AnnotatedDeclContext[] | AnnotatedDeclContext | null {
        if (i === undefined) {
            return this.getRuleContexts(AnnotatedDeclContext);
        }

        return this.getRuleContext(i, AnnotatedDeclContext);
    }
    public setter(): SetterContext[];
    public setter(i: number): SetterContext | null;
    public setter(i?: number): SetterContext[] | SetterContext | null {
        if (i === undefined) {
            return this.getRuleContexts(SetterContext);
        }

        return this.getRuleContext(i, SetterContext);
    }
    public namespaceDecl(): NamespaceDeclContext[];
    public namespaceDecl(i: number): NamespaceDeclContext | null;
    public namespaceDecl(i?: number): NamespaceDeclContext[] | NamespaceDeclContext | null {
        if (i === undefined) {
            return this.getRuleContexts(NamespaceDeclContext);
        }

        return this.getRuleContext(i, NamespaceDeclContext);
    }
    public moduleImport(): ModuleImportContext[];
    public moduleImport(i: number): ModuleImportContext | null;
    public moduleImport(i?: number): ModuleImportContext[] | ModuleImportContext | null {
        if (i === undefined) {
            return this.getRuleContexts(ModuleImportContext);
        }

        return this.getRuleContext(i, ModuleImportContext);
    }
    public override get ruleIndex(): number {
        return jsoniqParser.RULE_prolog;
    }
    public override enterRule(listener: jsoniqListener): void {
        if(listener.enterProlog) {
             listener.enterProlog(this);
        }
    }
    public override exitRule(listener: jsoniqListener): void {
        if(listener.exitProlog) {
             listener.exitProlog(this);
        }
    }
}


export class ProgramContext extends antlr.ParserRuleContext {
    public constructor(parent: antlr.ParserRuleContext | null, invokingState: number) {
        super(parent, invokingState);
    }
    public statementsAndOptionalExpr(): StatementsAndOptionalExprContext {
        return this.getRuleContext(0, StatementsAndOptionalExprContext)!;
    }
    public override get ruleIndex(): number {
        return jsoniqParser.RULE_program;
    }
    public override enterRule(listener: jsoniqListener): void {
        if(listener.enterProgram) {
             listener.enterProgram(this);
        }
    }
    public override exitRule(listener: jsoniqListener): void {
        if(listener.exitProgram) {
             listener.exitProgram(this);
        }
    }
}


export class StatementsContext extends antlr.ParserRuleContext {
    public constructor(parent: antlr.ParserRuleContext | null, invokingState: number) {
        super(parent, invokingState);
    }
    public statement(): StatementContext[];
    public statement(i: number): StatementContext | null;
    public statement(i?: number): StatementContext[] | StatementContext | null {
        if (i === undefined) {
            return this.getRuleContexts(StatementContext);
        }

        return this.getRuleContext(i, StatementContext);
    }
    public override get ruleIndex(): number {
        return jsoniqParser.RULE_statements;
    }
    public override enterRule(listener: jsoniqListener): void {
        if(listener.enterStatements) {
             listener.enterStatements(this);
        }
    }
    public override exitRule(listener: jsoniqListener): void {
        if(listener.exitStatements) {
             listener.exitStatements(this);
        }
    }
}


export class StatementsAndExprContext extends antlr.ParserRuleContext {
    public constructor(parent: antlr.ParserRuleContext | null, invokingState: number) {
        super(parent, invokingState);
    }
    public statements(): StatementsContext {
        return this.getRuleContext(0, StatementsContext)!;
    }
    public expr(): ExprContext {
        return this.getRuleContext(0, ExprContext)!;
    }
    public override get ruleIndex(): number {
        return jsoniqParser.RULE_statementsAndExpr;
    }
    public override enterRule(listener: jsoniqListener): void {
        if(listener.enterStatementsAndExpr) {
             listener.enterStatementsAndExpr(this);
        }
    }
    public override exitRule(listener: jsoniqListener): void {
        if(listener.exitStatementsAndExpr) {
             listener.exitStatementsAndExpr(this);
        }
    }
}


export class StatementsAndOptionalExprContext extends antlr.ParserRuleContext {
    public constructor(parent: antlr.ParserRuleContext | null, invokingState: number) {
        super(parent, invokingState);
    }
    public statements(): StatementsContext {
        return this.getRuleContext(0, StatementsContext)!;
    }
    public expr(): ExprContext | null {
        return this.getRuleContext(0, ExprContext);
    }
    public override get ruleIndex(): number {
        return jsoniqParser.RULE_statementsAndOptionalExpr;
    }
    public override enterRule(listener: jsoniqListener): void {
        if(listener.enterStatementsAndOptionalExpr) {
             listener.enterStatementsAndOptionalExpr(this);
        }
    }
    public override exitRule(listener: jsoniqListener): void {
        if(listener.exitStatementsAndOptionalExpr) {
             listener.exitStatementsAndOptionalExpr(this);
        }
    }
}


export class StatementContext extends antlr.ParserRuleContext {
    public constructor(parent: antlr.ParserRuleContext | null, invokingState: number) {
        super(parent, invokingState);
    }
    public applyStatement(): ApplyStatementContext | null {
        return this.getRuleContext(0, ApplyStatementContext);
    }
    public assignStatement(): AssignStatementContext | null {
        return this.getRuleContext(0, AssignStatementContext);
    }
    public blockStatement(): BlockStatementContext | null {
        return this.getRuleContext(0, BlockStatementContext);
    }
    public breakStatement(): BreakStatementContext | null {
        return this.getRuleContext(0, BreakStatementContext);
    }
    public continueStatement(): ContinueStatementContext | null {
        return this.getRuleContext(0, ContinueStatementContext);
    }
    public exitStatement(): ExitStatementContext | null {
        return this.getRuleContext(0, ExitStatementContext);
    }
    public flowrStatement(): FlowrStatementContext | null {
        return this.getRuleContext(0, FlowrStatementContext);
    }
    public ifStatement(): IfStatementContext | null {
        return this.getRuleContext(0, IfStatementContext);
    }
    public switchStatement(): SwitchStatementContext | null {
        return this.getRuleContext(0, SwitchStatementContext);
    }
    public tryCatchStatement(): TryCatchStatementContext | null {
        return this.getRuleContext(0, TryCatchStatementContext);
    }
    public typeSwitchStatement(): TypeSwitchStatementContext | null {
        return this.getRuleContext(0, TypeSwitchStatementContext);
    }
    public varDeclStatement(): VarDeclStatementContext | null {
        return this.getRuleContext(0, VarDeclStatementContext);
    }
    public whileStatement(): WhileStatementContext | null {
        return this.getRuleContext(0, WhileStatementContext);
    }
    public override get ruleIndex(): number {
        return jsoniqParser.RULE_statement;
    }
    public override enterRule(listener: jsoniqListener): void {
        if(listener.enterStatement) {
             listener.enterStatement(this);
        }
    }
    public override exitRule(listener: jsoniqListener): void {
        if(listener.exitStatement) {
             listener.exitStatement(this);
        }
    }
}


export class ApplyStatementContext extends antlr.ParserRuleContext {
    public constructor(parent: antlr.ParserRuleContext | null, invokingState: number) {
        super(parent, invokingState);
    }
    public exprSimple(): ExprSimpleContext {
        return this.getRuleContext(0, ExprSimpleContext)!;
    }
    public Ksemicolon(): antlr.TerminalNode {
        return this.getToken(jsoniqParser.Ksemicolon, 0)!;
    }
    public override get ruleIndex(): number {
        return jsoniqParser.RULE_applyStatement;
    }
    public override enterRule(listener: jsoniqListener): void {
        if(listener.enterApplyStatement) {
             listener.enterApplyStatement(this);
        }
    }
    public override exitRule(listener: jsoniqListener): void {
        if(listener.exitApplyStatement) {
             listener.exitApplyStatement(this);
        }
    }
}


export class AssignStatementContext extends antlr.ParserRuleContext {
    public constructor(parent: antlr.ParserRuleContext | null, invokingState: number) {
        super(parent, invokingState);
    }
    public Kdollar(): antlr.TerminalNode {
        return this.getToken(jsoniqParser.Kdollar, 0)!;
    }
    public qname(): QnameContext {
        return this.getRuleContext(0, QnameContext)!;
    }
    public Kassign(): antlr.TerminalNode {
        return this.getToken(jsoniqParser.Kassign, 0)!;
    }
    public exprSingle(): ExprSingleContext {
        return this.getRuleContext(0, ExprSingleContext)!;
    }
    public Ksemicolon(): antlr.TerminalNode {
        return this.getToken(jsoniqParser.Ksemicolon, 0)!;
    }
    public override get ruleIndex(): number {
        return jsoniqParser.RULE_assignStatement;
    }
    public override enterRule(listener: jsoniqListener): void {
        if(listener.enterAssignStatement) {
             listener.enterAssignStatement(this);
        }
    }
    public override exitRule(listener: jsoniqListener): void {
        if(listener.exitAssignStatement) {
             listener.exitAssignStatement(this);
        }
    }
}


export class BlockStatementContext extends antlr.ParserRuleContext {
    public constructor(parent: antlr.ParserRuleContext | null, invokingState: number) {
        super(parent, invokingState);
    }
    public Klbrace(): antlr.TerminalNode {
        return this.getToken(jsoniqParser.Klbrace, 0)!;
    }
    public statements(): StatementsContext {
        return this.getRuleContext(0, StatementsContext)!;
    }
    public Krbrace(): antlr.TerminalNode {
        return this.getToken(jsoniqParser.Krbrace, 0)!;
    }
    public override get ruleIndex(): number {
        return jsoniqParser.RULE_blockStatement;
    }
    public override enterRule(listener: jsoniqListener): void {
        if(listener.enterBlockStatement) {
             listener.enterBlockStatement(this);
        }
    }
    public override exitRule(listener: jsoniqListener): void {
        if(listener.exitBlockStatement) {
             listener.exitBlockStatement(this);
        }
    }
}


export class BreakStatementContext extends antlr.ParserRuleContext {
    public constructor(parent: antlr.ParserRuleContext | null, invokingState: number) {
        super(parent, invokingState);
    }
    public Kbreak(): antlr.TerminalNode {
        return this.getToken(jsoniqParser.Kbreak, 0)!;
    }
    public Kloop(): antlr.TerminalNode {
        return this.getToken(jsoniqParser.Kloop, 0)!;
    }
    public Ksemicolon(): antlr.TerminalNode {
        return this.getToken(jsoniqParser.Ksemicolon, 0)!;
    }
    public override get ruleIndex(): number {
        return jsoniqParser.RULE_breakStatement;
    }
    public override enterRule(listener: jsoniqListener): void {
        if(listener.enterBreakStatement) {
             listener.enterBreakStatement(this);
        }
    }
    public override exitRule(listener: jsoniqListener): void {
        if(listener.exitBreakStatement) {
             listener.exitBreakStatement(this);
        }
    }
}


export class ContinueStatementContext extends antlr.ParserRuleContext {
    public constructor(parent: antlr.ParserRuleContext | null, invokingState: number) {
        super(parent, invokingState);
    }
    public Kcontinue(): antlr.TerminalNode {
        return this.getToken(jsoniqParser.Kcontinue, 0)!;
    }
    public Kloop(): antlr.TerminalNode {
        return this.getToken(jsoniqParser.Kloop, 0)!;
    }
    public Ksemicolon(): antlr.TerminalNode {
        return this.getToken(jsoniqParser.Ksemicolon, 0)!;
    }
    public override get ruleIndex(): number {
        return jsoniqParser.RULE_continueStatement;
    }
    public override enterRule(listener: jsoniqListener): void {
        if(listener.enterContinueStatement) {
             listener.enterContinueStatement(this);
        }
    }
    public override exitRule(listener: jsoniqListener): void {
        if(listener.exitContinueStatement) {
             listener.exitContinueStatement(this);
        }
    }
}


export class ExitStatementContext extends antlr.ParserRuleContext {
    public constructor(parent: antlr.ParserRuleContext | null, invokingState: number) {
        super(parent, invokingState);
    }
    public Kexit(): antlr.TerminalNode {
        return this.getToken(jsoniqParser.Kexit, 0)!;
    }
    public Kreturning(): antlr.TerminalNode {
        return this.getToken(jsoniqParser.Kreturning, 0)!;
    }
    public exprSingle(): ExprSingleContext {
        return this.getRuleContext(0, ExprSingleContext)!;
    }
    public Ksemicolon(): antlr.TerminalNode {
        return this.getToken(jsoniqParser.Ksemicolon, 0)!;
    }
    public override get ruleIndex(): number {
        return jsoniqParser.RULE_exitStatement;
    }
    public override enterRule(listener: jsoniqListener): void {
        if(listener.enterExitStatement) {
             listener.enterExitStatement(this);
        }
    }
    public override exitRule(listener: jsoniqListener): void {
        if(listener.exitExitStatement) {
             listener.exitExitStatement(this);
        }
    }
}


export class FlowrStatementContext extends antlr.ParserRuleContext {
    public _start_for?: ForClauseContext;
    public _start_let?: LetClauseContext;
    public _returnStmt?: StatementContext;
    public constructor(parent: antlr.ParserRuleContext | null, invokingState: number) {
        super(parent, invokingState);
    }
    public Kreturn(): antlr.TerminalNode {
        return this.getToken(jsoniqParser.Kreturn, 0)!;
    }
    public statement(): StatementContext {
        return this.getRuleContext(0, StatementContext)!;
    }
    public forClause(): ForClauseContext[];
    public forClause(i: number): ForClauseContext | null;
    public forClause(i?: number): ForClauseContext[] | ForClauseContext | null {
        if (i === undefined) {
            return this.getRuleContexts(ForClauseContext);
        }

        return this.getRuleContext(i, ForClauseContext);
    }
    public letClause(): LetClauseContext[];
    public letClause(i: number): LetClauseContext | null;
    public letClause(i?: number): LetClauseContext[] | LetClauseContext | null {
        if (i === undefined) {
            return this.getRuleContexts(LetClauseContext);
        }

        return this.getRuleContext(i, LetClauseContext);
    }
    public whereClause(): WhereClauseContext[];
    public whereClause(i: number): WhereClauseContext | null;
    public whereClause(i?: number): WhereClauseContext[] | WhereClauseContext | null {
        if (i === undefined) {
            return this.getRuleContexts(WhereClauseContext);
        }

        return this.getRuleContext(i, WhereClauseContext);
    }
    public groupByClause(): GroupByClauseContext[];
    public groupByClause(i: number): GroupByClauseContext | null;
    public groupByClause(i?: number): GroupByClauseContext[] | GroupByClauseContext | null {
        if (i === undefined) {
            return this.getRuleContexts(GroupByClauseContext);
        }

        return this.getRuleContext(i, GroupByClauseContext);
    }
    public orderByClause(): OrderByClauseContext[];
    public orderByClause(i: number): OrderByClauseContext | null;
    public orderByClause(i?: number): OrderByClauseContext[] | OrderByClauseContext | null {
        if (i === undefined) {
            return this.getRuleContexts(OrderByClauseContext);
        }

        return this.getRuleContext(i, OrderByClauseContext);
    }
    public countClause(): CountClauseContext[];
    public countClause(i: number): CountClauseContext | null;
    public countClause(i?: number): CountClauseContext[] | CountClauseContext | null {
        if (i === undefined) {
            return this.getRuleContexts(CountClauseContext);
        }

        return this.getRuleContext(i, CountClauseContext);
    }
    public override get ruleIndex(): number {
        return jsoniqParser.RULE_flowrStatement;
    }
    public override enterRule(listener: jsoniqListener): void {
        if(listener.enterFlowrStatement) {
             listener.enterFlowrStatement(this);
        }
    }
    public override exitRule(listener: jsoniqListener): void {
        if(listener.exitFlowrStatement) {
             listener.exitFlowrStatement(this);
        }
    }
}


export class IfStatementContext extends antlr.ParserRuleContext {
    public _test_expr?: ExprContext;
    public _branch?: StatementContext;
    public _else_branch?: StatementContext;
    public constructor(parent: antlr.ParserRuleContext | null, invokingState: number) {
        super(parent, invokingState);
    }
    public Kif(): antlr.TerminalNode {
        return this.getToken(jsoniqParser.Kif, 0)!;
    }
    public Klparen(): antlr.TerminalNode {
        return this.getToken(jsoniqParser.Klparen, 0)!;
    }
    public Krparen(): antlr.TerminalNode {
        return this.getToken(jsoniqParser.Krparen, 0)!;
    }
    public Kthen(): antlr.TerminalNode {
        return this.getToken(jsoniqParser.Kthen, 0)!;
    }
    public Kelse(): antlr.TerminalNode {
        return this.getToken(jsoniqParser.Kelse, 0)!;
    }
    public expr(): ExprContext {
        return this.getRuleContext(0, ExprContext)!;
    }
    public statement(): StatementContext[];
    public statement(i: number): StatementContext | null;
    public statement(i?: number): StatementContext[] | StatementContext | null {
        if (i === undefined) {
            return this.getRuleContexts(StatementContext);
        }

        return this.getRuleContext(i, StatementContext);
    }
    public override get ruleIndex(): number {
        return jsoniqParser.RULE_ifStatement;
    }
    public override enterRule(listener: jsoniqListener): void {
        if(listener.enterIfStatement) {
             listener.enterIfStatement(this);
        }
    }
    public override exitRule(listener: jsoniqListener): void {
        if(listener.exitIfStatement) {
             listener.exitIfStatement(this);
        }
    }
}


export class SwitchStatementContext extends antlr.ParserRuleContext {
    public _condExpr?: ExprContext;
    public _switchCaseStatement?: SwitchCaseStatementContext;
    public _cases: SwitchCaseStatementContext[] = [];
    public _def?: StatementContext;
    public constructor(parent: antlr.ParserRuleContext | null, invokingState: number) {
        super(parent, invokingState);
    }
    public Kswitch(): antlr.TerminalNode {
        return this.getToken(jsoniqParser.Kswitch, 0)!;
    }
    public Klparen(): antlr.TerminalNode {
        return this.getToken(jsoniqParser.Klparen, 0)!;
    }
    public Krparen(): antlr.TerminalNode {
        return this.getToken(jsoniqParser.Krparen, 0)!;
    }
    public Kdefault(): antlr.TerminalNode {
        return this.getToken(jsoniqParser.Kdefault, 0)!;
    }
    public Kreturn(): antlr.TerminalNode {
        return this.getToken(jsoniqParser.Kreturn, 0)!;
    }
    public expr(): ExprContext {
        return this.getRuleContext(0, ExprContext)!;
    }
    public statement(): StatementContext {
        return this.getRuleContext(0, StatementContext)!;
    }
    public switchCaseStatement(): SwitchCaseStatementContext[];
    public switchCaseStatement(i: number): SwitchCaseStatementContext | null;
    public switchCaseStatement(i?: number): SwitchCaseStatementContext[] | SwitchCaseStatementContext | null {
        if (i === undefined) {
            return this.getRuleContexts(SwitchCaseStatementContext);
        }

        return this.getRuleContext(i, SwitchCaseStatementContext);
    }
    public override get ruleIndex(): number {
        return jsoniqParser.RULE_switchStatement;
    }
    public override enterRule(listener: jsoniqListener): void {
        if(listener.enterSwitchStatement) {
             listener.enterSwitchStatement(this);
        }
    }
    public override exitRule(listener: jsoniqListener): void {
        if(listener.exitSwitchStatement) {
             listener.exitSwitchStatement(this);
        }
    }
}


export class SwitchCaseStatementContext extends antlr.ParserRuleContext {
    public _exprSingle?: ExprSingleContext;
    public _cond: ExprSingleContext[] = [];
    public _ret?: StatementContext;
    public constructor(parent: antlr.ParserRuleContext | null, invokingState: number) {
        super(parent, invokingState);
    }
    public Kreturn(): antlr.TerminalNode {
        return this.getToken(jsoniqParser.Kreturn, 0)!;
    }
    public statement(): StatementContext {
        return this.getRuleContext(0, StatementContext)!;
    }
    public Kcase(): antlr.TerminalNode[];
    public Kcase(i: number): antlr.TerminalNode | null;
    public Kcase(i?: number): antlr.TerminalNode | null | antlr.TerminalNode[] {
    	if (i === undefined) {
    		return this.getTokens(jsoniqParser.Kcase);
    	} else {
    		return this.getToken(jsoniqParser.Kcase, i);
    	}
    }
    public exprSingle(): ExprSingleContext[];
    public exprSingle(i: number): ExprSingleContext | null;
    public exprSingle(i?: number): ExprSingleContext[] | ExprSingleContext | null {
        if (i === undefined) {
            return this.getRuleContexts(ExprSingleContext);
        }

        return this.getRuleContext(i, ExprSingleContext);
    }
    public override get ruleIndex(): number {
        return jsoniqParser.RULE_switchCaseStatement;
    }
    public override enterRule(listener: jsoniqListener): void {
        if(listener.enterSwitchCaseStatement) {
             listener.enterSwitchCaseStatement(this);
        }
    }
    public override exitRule(listener: jsoniqListener): void {
        if(listener.exitSwitchCaseStatement) {
             listener.exitSwitchCaseStatement(this);
        }
    }
}


export class TryCatchStatementContext extends antlr.ParserRuleContext {
    public _try_block?: BlockStatementContext;
    public _catchCaseStatement?: CatchCaseStatementContext;
    public _catches: CatchCaseStatementContext[] = [];
    public constructor(parent: antlr.ParserRuleContext | null, invokingState: number) {
        super(parent, invokingState);
    }
    public Ktry(): antlr.TerminalNode {
        return this.getToken(jsoniqParser.Ktry, 0)!;
    }
    public blockStatement(): BlockStatementContext {
        return this.getRuleContext(0, BlockStatementContext)!;
    }
    public catchCaseStatement(): CatchCaseStatementContext[];
    public catchCaseStatement(i: number): CatchCaseStatementContext | null;
    public catchCaseStatement(i?: number): CatchCaseStatementContext[] | CatchCaseStatementContext | null {
        if (i === undefined) {
            return this.getRuleContexts(CatchCaseStatementContext);
        }

        return this.getRuleContext(i, CatchCaseStatementContext);
    }
    public override get ruleIndex(): number {
        return jsoniqParser.RULE_tryCatchStatement;
    }
    public override enterRule(listener: jsoniqListener): void {
        if(listener.enterTryCatchStatement) {
             listener.enterTryCatchStatement(this);
        }
    }
    public override exitRule(listener: jsoniqListener): void {
        if(listener.exitTryCatchStatement) {
             listener.exitTryCatchStatement(this);
        }
    }
}


export class CatchCaseStatementContext extends antlr.ParserRuleContext {
    public _s10?: Token | null;
    public _jokers: antlr.Token[] = [];
    public _qname?: QnameContext;
    public _errors: QnameContext[] = [];
    public _catch_block?: BlockStatementContext;
    public constructor(parent: antlr.ParserRuleContext | null, invokingState: number) {
        super(parent, invokingState);
    }
    public Kcatch(): antlr.TerminalNode {
        return this.getToken(jsoniqParser.Kcatch, 0)!;
    }
    public blockStatement(): BlockStatementContext {
        return this.getRuleContext(0, BlockStatementContext)!;
    }
    public Kasterisk(): antlr.TerminalNode[];
    public Kasterisk(i: number): antlr.TerminalNode | null;
    public Kasterisk(i?: number): antlr.TerminalNode | null | antlr.TerminalNode[] {
    	if (i === undefined) {
    		return this.getTokens(jsoniqParser.Kasterisk);
    	} else {
    		return this.getToken(jsoniqParser.Kasterisk, i);
    	}
    }
    public qname(): QnameContext[];
    public qname(i: number): QnameContext | null;
    public qname(i?: number): QnameContext[] | QnameContext | null {
        if (i === undefined) {
            return this.getRuleContexts(QnameContext);
        }

        return this.getRuleContext(i, QnameContext);
    }
    public Kpipe(): antlr.TerminalNode[];
    public Kpipe(i: number): antlr.TerminalNode | null;
    public Kpipe(i?: number): antlr.TerminalNode | null | antlr.TerminalNode[] {
    	if (i === undefined) {
    		return this.getTokens(jsoniqParser.Kpipe);
    	} else {
    		return this.getToken(jsoniqParser.Kpipe, i);
    	}
    }
    public override get ruleIndex(): number {
        return jsoniqParser.RULE_catchCaseStatement;
    }
    public override enterRule(listener: jsoniqListener): void {
        if(listener.enterCatchCaseStatement) {
             listener.enterCatchCaseStatement(this);
        }
    }
    public override exitRule(listener: jsoniqListener): void {
        if(listener.exitCatchCaseStatement) {
             listener.exitCatchCaseStatement(this);
        }
    }
}


export class TypeSwitchStatementContext extends antlr.ParserRuleContext {
    public _cond?: ExprContext;
    public _caseStatement?: CaseStatementContext;
    public _cases: CaseStatementContext[] = [];
    public _var_ref?: VarRefContext;
    public _def?: StatementContext;
    public constructor(parent: antlr.ParserRuleContext | null, invokingState: number) {
        super(parent, invokingState);
    }
    public Ktypeswitch(): antlr.TerminalNode {
        return this.getToken(jsoniqParser.Ktypeswitch, 0)!;
    }
    public Klparen(): antlr.TerminalNode {
        return this.getToken(jsoniqParser.Klparen, 0)!;
    }
    public Krparen(): antlr.TerminalNode {
        return this.getToken(jsoniqParser.Krparen, 0)!;
    }
    public Kdefault(): antlr.TerminalNode {
        return this.getToken(jsoniqParser.Kdefault, 0)!;
    }
    public Kreturn(): antlr.TerminalNode {
        return this.getToken(jsoniqParser.Kreturn, 0)!;
    }
    public expr(): ExprContext {
        return this.getRuleContext(0, ExprContext)!;
    }
    public statement(): StatementContext {
        return this.getRuleContext(0, StatementContext)!;
    }
    public caseStatement(): CaseStatementContext[];
    public caseStatement(i: number): CaseStatementContext | null;
    public caseStatement(i?: number): CaseStatementContext[] | CaseStatementContext | null {
        if (i === undefined) {
            return this.getRuleContexts(CaseStatementContext);
        }

        return this.getRuleContext(i, CaseStatementContext);
    }
    public varRef(): VarRefContext | null {
        return this.getRuleContext(0, VarRefContext);
    }
    public override get ruleIndex(): number {
        return jsoniqParser.RULE_typeSwitchStatement;
    }
    public override enterRule(listener: jsoniqListener): void {
        if(listener.enterTypeSwitchStatement) {
             listener.enterTypeSwitchStatement(this);
        }
    }
    public override exitRule(listener: jsoniqListener): void {
        if(listener.exitTypeSwitchStatement) {
             listener.exitTypeSwitchStatement(this);
        }
    }
}


export class CaseStatementContext extends antlr.ParserRuleContext {
    public _var_ref?: VarRefContext;
    public _sequenceType?: SequenceTypeContext;
    public _union: SequenceTypeContext[] = [];
    public _ret?: StatementContext;
    public constructor(parent: antlr.ParserRuleContext | null, invokingState: number) {
        super(parent, invokingState);
    }
    public Kcase(): antlr.TerminalNode {
        return this.getToken(jsoniqParser.Kcase, 0)!;
    }
    public Kreturn(): antlr.TerminalNode {
        return this.getToken(jsoniqParser.Kreturn, 0)!;
    }
    public sequenceType(): SequenceTypeContext[];
    public sequenceType(i: number): SequenceTypeContext | null;
    public sequenceType(i?: number): SequenceTypeContext[] | SequenceTypeContext | null {
        if (i === undefined) {
            return this.getRuleContexts(SequenceTypeContext);
        }

        return this.getRuleContext(i, SequenceTypeContext);
    }
    public statement(): StatementContext {
        return this.getRuleContext(0, StatementContext)!;
    }
    public Kas(): antlr.TerminalNode | null {
        return this.getToken(jsoniqParser.Kas, 0);
    }
    public Kpipe(): antlr.TerminalNode[];
    public Kpipe(i: number): antlr.TerminalNode | null;
    public Kpipe(i?: number): antlr.TerminalNode | null | antlr.TerminalNode[] {
    	if (i === undefined) {
    		return this.getTokens(jsoniqParser.Kpipe);
    	} else {
    		return this.getToken(jsoniqParser.Kpipe, i);
    	}
    }
    public varRef(): VarRefContext | null {
        return this.getRuleContext(0, VarRefContext);
    }
    public override get ruleIndex(): number {
        return jsoniqParser.RULE_caseStatement;
    }
    public override enterRule(listener: jsoniqListener): void {
        if(listener.enterCaseStatement) {
             listener.enterCaseStatement(this);
        }
    }
    public override exitRule(listener: jsoniqListener): void {
        if(listener.exitCaseStatement) {
             listener.exitCaseStatement(this);
        }
    }
}


export class AnnotationContext extends antlr.ParserRuleContext {
    public _name?: QnameContext;
    public _updating?: Token | null;
    public constructor(parent: antlr.ParserRuleContext | null, invokingState: number) {
        super(parent, invokingState);
    }
    public Kannotation(): antlr.TerminalNode | null {
        return this.getToken(jsoniqParser.Kannotation, 0);
    }
    public qname(): QnameContext | null {
        return this.getRuleContext(0, QnameContext);
    }
    public Kupdating(): antlr.TerminalNode | null {
        return this.getToken(jsoniqParser.Kupdating, 0);
    }
    public Klparen(): antlr.TerminalNode | null {
        return this.getToken(jsoniqParser.Klparen, 0);
    }
    public Literal(): antlr.TerminalNode[];
    public Literal(i: number): antlr.TerminalNode | null;
    public Literal(i?: number): antlr.TerminalNode | null | antlr.TerminalNode[] {
    	if (i === undefined) {
    		return this.getTokens(jsoniqParser.Literal);
    	} else {
    		return this.getToken(jsoniqParser.Literal, i);
    	}
    }
    public Krparen(): antlr.TerminalNode | null {
        return this.getToken(jsoniqParser.Krparen, 0);
    }
    public Kcomma(): antlr.TerminalNode[];
    public Kcomma(i: number): antlr.TerminalNode | null;
    public Kcomma(i?: number): antlr.TerminalNode | null | antlr.TerminalNode[] {
    	if (i === undefined) {
    		return this.getTokens(jsoniqParser.Kcomma);
    	} else {
    		return this.getToken(jsoniqParser.Kcomma, i);
    	}
    }
    public override get ruleIndex(): number {
        return jsoniqParser.RULE_annotation;
    }
    public override enterRule(listener: jsoniqListener): void {
        if(listener.enterAnnotation) {
             listener.enterAnnotation(this);
        }
    }
    public override exitRule(listener: jsoniqListener): void {
        if(listener.exitAnnotation) {
             listener.exitAnnotation(this);
        }
    }
}


export class AnnotationsContext extends antlr.ParserRuleContext {
    public constructor(parent: antlr.ParserRuleContext | null, invokingState: number) {
        super(parent, invokingState);
    }
    public annotation(): AnnotationContext[];
    public annotation(i: number): AnnotationContext | null;
    public annotation(i?: number): AnnotationContext[] | AnnotationContext | null {
        if (i === undefined) {
            return this.getRuleContexts(AnnotationContext);
        }

        return this.getRuleContext(i, AnnotationContext);
    }
    public override get ruleIndex(): number {
        return jsoniqParser.RULE_annotations;
    }
    public override enterRule(listener: jsoniqListener): void {
        if(listener.enterAnnotations) {
             listener.enterAnnotations(this);
        }
    }
    public override exitRule(listener: jsoniqListener): void {
        if(listener.exitAnnotations) {
             listener.exitAnnotations(this);
        }
    }
}


export class VarDeclStatementContext extends antlr.ParserRuleContext {
    public constructor(parent: antlr.ParserRuleContext | null, invokingState: number) {
        super(parent, invokingState);
    }
    public annotations(): AnnotationsContext {
        return this.getRuleContext(0, AnnotationsContext)!;
    }
    public Kvariable(): antlr.TerminalNode {
        return this.getToken(jsoniqParser.Kvariable, 0)!;
    }
    public varDeclForStatement(): VarDeclForStatementContext[];
    public varDeclForStatement(i: number): VarDeclForStatementContext | null;
    public varDeclForStatement(i?: number): VarDeclForStatementContext[] | VarDeclForStatementContext | null {
        if (i === undefined) {
            return this.getRuleContexts(VarDeclForStatementContext);
        }

        return this.getRuleContext(i, VarDeclForStatementContext);
    }
    public Ksemicolon(): antlr.TerminalNode {
        return this.getToken(jsoniqParser.Ksemicolon, 0)!;
    }
    public Kcomma(): antlr.TerminalNode[];
    public Kcomma(i: number): antlr.TerminalNode | null;
    public Kcomma(i?: number): antlr.TerminalNode | null | antlr.TerminalNode[] {
    	if (i === undefined) {
    		return this.getTokens(jsoniqParser.Kcomma);
    	} else {
    		return this.getToken(jsoniqParser.Kcomma, i);
    	}
    }
    public override get ruleIndex(): number {
        return jsoniqParser.RULE_varDeclStatement;
    }
    public override enterRule(listener: jsoniqListener): void {
        if(listener.enterVarDeclStatement) {
             listener.enterVarDeclStatement(this);
        }
    }
    public override exitRule(listener: jsoniqListener): void {
        if(listener.exitVarDeclStatement) {
             listener.exitVarDeclStatement(this);
        }
    }
}


export class VarDeclForStatementContext extends antlr.ParserRuleContext {
    public _var_ref?: VarRefContext;
    public _exprSingle?: ExprSingleContext;
    public _expr_vals: ExprSingleContext[] = [];
    public constructor(parent: antlr.ParserRuleContext | null, invokingState: number) {
        super(parent, invokingState);
    }
    public varRef(): VarRefContext {
        return this.getRuleContext(0, VarRefContext)!;
    }
    public Kas(): antlr.TerminalNode | null {
        return this.getToken(jsoniqParser.Kas, 0);
    }
    public sequenceType(): SequenceTypeContext | null {
        return this.getRuleContext(0, SequenceTypeContext);
    }
    public Kassign(): antlr.TerminalNode | null {
        return this.getToken(jsoniqParser.Kassign, 0);
    }
    public exprSingle(): ExprSingleContext | null {
        return this.getRuleContext(0, ExprSingleContext);
    }
    public override get ruleIndex(): number {
        return jsoniqParser.RULE_varDeclForStatement;
    }
    public override enterRule(listener: jsoniqListener): void {
        if(listener.enterVarDeclForStatement) {
             listener.enterVarDeclForStatement(this);
        }
    }
    public override exitRule(listener: jsoniqListener): void {
        if(listener.exitVarDeclForStatement) {
             listener.exitVarDeclForStatement(this);
        }
    }
}


export class WhileStatementContext extends antlr.ParserRuleContext {
    public _test_expr?: ExprContext;
    public _stmt?: StatementContext;
    public constructor(parent: antlr.ParserRuleContext | null, invokingState: number) {
        super(parent, invokingState);
    }
    public Kwhile(): antlr.TerminalNode {
        return this.getToken(jsoniqParser.Kwhile, 0)!;
    }
    public Klparen(): antlr.TerminalNode {
        return this.getToken(jsoniqParser.Klparen, 0)!;
    }
    public Krparen(): antlr.TerminalNode {
        return this.getToken(jsoniqParser.Krparen, 0)!;
    }
    public expr(): ExprContext {
        return this.getRuleContext(0, ExprContext)!;
    }
    public statement(): StatementContext {
        return this.getRuleContext(0, StatementContext)!;
    }
    public override get ruleIndex(): number {
        return jsoniqParser.RULE_whileStatement;
    }
    public override enterRule(listener: jsoniqListener): void {
        if(listener.enterWhileStatement) {
             listener.enterWhileStatement(this);
        }
    }
    public override exitRule(listener: jsoniqListener): void {
        if(listener.exitWhileStatement) {
             listener.exitWhileStatement(this);
        }
    }
}


export class SetterContext extends antlr.ParserRuleContext {
    public constructor(parent: antlr.ParserRuleContext | null, invokingState: number) {
        super(parent, invokingState);
    }
    public defaultCollationDecl(): DefaultCollationDeclContext | null {
        return this.getRuleContext(0, DefaultCollationDeclContext);
    }
    public baseURIDecl(): BaseURIDeclContext | null {
        return this.getRuleContext(0, BaseURIDeclContext);
    }
    public orderingModeDecl(): OrderingModeDeclContext | null {
        return this.getRuleContext(0, OrderingModeDeclContext);
    }
    public emptyOrderDecl(): EmptyOrderDeclContext | null {
        return this.getRuleContext(0, EmptyOrderDeclContext);
    }
    public decimalFormatDecl(): DecimalFormatDeclContext | null {
        return this.getRuleContext(0, DecimalFormatDeclContext);
    }
    public override get ruleIndex(): number {
        return jsoniqParser.RULE_setter;
    }
    public override enterRule(listener: jsoniqListener): void {
        if(listener.enterSetter) {
             listener.enterSetter(this);
        }
    }
    public override exitRule(listener: jsoniqListener): void {
        if(listener.exitSetter) {
             listener.exitSetter(this);
        }
    }
}


export class NamespaceDeclContext extends antlr.ParserRuleContext {
    public constructor(parent: antlr.ParserRuleContext | null, invokingState: number) {
        super(parent, invokingState);
    }
    public Kdeclare(): antlr.TerminalNode {
        return this.getToken(jsoniqParser.Kdeclare, 0)!;
    }
    public Knamespace(): antlr.TerminalNode {
        return this.getToken(jsoniqParser.Knamespace, 0)!;
    }
    public NCName(): antlr.TerminalNode {
        return this.getToken(jsoniqParser.NCName, 0)!;
    }
    public Kequal(): antlr.TerminalNode {
        return this.getToken(jsoniqParser.Kequal, 0)!;
    }
    public uriLiteral(): UriLiteralContext {
        return this.getRuleContext(0, UriLiteralContext)!;
    }
    public override get ruleIndex(): number {
        return jsoniqParser.RULE_namespaceDecl;
    }
    public override enterRule(listener: jsoniqListener): void {
        if(listener.enterNamespaceDecl) {
             listener.enterNamespaceDecl(this);
        }
    }
    public override exitRule(listener: jsoniqListener): void {
        if(listener.exitNamespaceDecl) {
             listener.exitNamespaceDecl(this);
        }
    }
}


export class AnnotatedDeclContext extends antlr.ParserRuleContext {
    public constructor(parent: antlr.ParserRuleContext | null, invokingState: number) {
        super(parent, invokingState);
    }
    public functionDecl(): FunctionDeclContext | null {
        return this.getRuleContext(0, FunctionDeclContext);
    }
    public varDecl(): VarDeclContext | null {
        return this.getRuleContext(0, VarDeclContext);
    }
    public typeDecl(): TypeDeclContext | null {
        return this.getRuleContext(0, TypeDeclContext);
    }
    public contextItemDecl(): ContextItemDeclContext | null {
        return this.getRuleContext(0, ContextItemDeclContext);
    }
    public override get ruleIndex(): number {
        return jsoniqParser.RULE_annotatedDecl;
    }
    public override enterRule(listener: jsoniqListener): void {
        if(listener.enterAnnotatedDecl) {
             listener.enterAnnotatedDecl(this);
        }
    }
    public override exitRule(listener: jsoniqListener): void {
        if(listener.exitAnnotatedDecl) {
             listener.exitAnnotatedDecl(this);
        }
    }
}


export class DefaultCollationDeclContext extends antlr.ParserRuleContext {
    public constructor(parent: antlr.ParserRuleContext | null, invokingState: number) {
        super(parent, invokingState);
    }
    public Kdeclare(): antlr.TerminalNode {
        return this.getToken(jsoniqParser.Kdeclare, 0)!;
    }
    public Kdefault(): antlr.TerminalNode {
        return this.getToken(jsoniqParser.Kdefault, 0)!;
    }
    public Kcollation(): antlr.TerminalNode {
        return this.getToken(jsoniqParser.Kcollation, 0)!;
    }
    public uriLiteral(): UriLiteralContext {
        return this.getRuleContext(0, UriLiteralContext)!;
    }
    public override get ruleIndex(): number {
        return jsoniqParser.RULE_defaultCollationDecl;
    }
    public override enterRule(listener: jsoniqListener): void {
        if(listener.enterDefaultCollationDecl) {
             listener.enterDefaultCollationDecl(this);
        }
    }
    public override exitRule(listener: jsoniqListener): void {
        if(listener.exitDefaultCollationDecl) {
             listener.exitDefaultCollationDecl(this);
        }
    }
}


export class BaseURIDeclContext extends antlr.ParserRuleContext {
    public constructor(parent: antlr.ParserRuleContext | null, invokingState: number) {
        super(parent, invokingState);
    }
    public Kdeclare(): antlr.TerminalNode {
        return this.getToken(jsoniqParser.Kdeclare, 0)!;
    }
    public Kbase_uri(): antlr.TerminalNode {
        return this.getToken(jsoniqParser.Kbase_uri, 0)!;
    }
    public uriLiteral(): UriLiteralContext {
        return this.getRuleContext(0, UriLiteralContext)!;
    }
    public override get ruleIndex(): number {
        return jsoniqParser.RULE_baseURIDecl;
    }
    public override enterRule(listener: jsoniqListener): void {
        if(listener.enterBaseURIDecl) {
             listener.enterBaseURIDecl(this);
        }
    }
    public override exitRule(listener: jsoniqListener): void {
        if(listener.exitBaseURIDecl) {
             listener.exitBaseURIDecl(this);
        }
    }
}


export class OrderingModeDeclContext extends antlr.ParserRuleContext {
    public constructor(parent: antlr.ParserRuleContext | null, invokingState: number) {
        super(parent, invokingState);
    }
    public Kdeclare(): antlr.TerminalNode {
        return this.getToken(jsoniqParser.Kdeclare, 0)!;
    }
    public Kordering(): antlr.TerminalNode {
        return this.getToken(jsoniqParser.Kordering, 0)!;
    }
    public Kordered(): antlr.TerminalNode | null {
        return this.getToken(jsoniqParser.Kordered, 0);
    }
    public Kunordered(): antlr.TerminalNode | null {
        return this.getToken(jsoniqParser.Kunordered, 0);
    }
    public override get ruleIndex(): number {
        return jsoniqParser.RULE_orderingModeDecl;
    }
    public override enterRule(listener: jsoniqListener): void {
        if(listener.enterOrderingModeDecl) {
             listener.enterOrderingModeDecl(this);
        }
    }
    public override exitRule(listener: jsoniqListener): void {
        if(listener.exitOrderingModeDecl) {
             listener.exitOrderingModeDecl(this);
        }
    }
}


export class EmptyOrderDeclContext extends antlr.ParserRuleContext {
    public _emptySequenceOrder?: Token | null;
    public constructor(parent: antlr.ParserRuleContext | null, invokingState: number) {
        super(parent, invokingState);
    }
    public Kdeclare(): antlr.TerminalNode {
        return this.getToken(jsoniqParser.Kdeclare, 0)!;
    }
    public Kdefault(): antlr.TerminalNode {
        return this.getToken(jsoniqParser.Kdefault, 0)!;
    }
    public Korder(): antlr.TerminalNode {
        return this.getToken(jsoniqParser.Korder, 0)!;
    }
    public Kempty(): antlr.TerminalNode {
        return this.getToken(jsoniqParser.Kempty, 0)!;
    }
    public Kgreatest(): antlr.TerminalNode | null {
        return this.getToken(jsoniqParser.Kgreatest, 0);
    }
    public Kleast(): antlr.TerminalNode | null {
        return this.getToken(jsoniqParser.Kleast, 0);
    }
    public override get ruleIndex(): number {
        return jsoniqParser.RULE_emptyOrderDecl;
    }
    public override enterRule(listener: jsoniqListener): void {
        if(listener.enterEmptyOrderDecl) {
             listener.enterEmptyOrderDecl(this);
        }
    }
    public override exitRule(listener: jsoniqListener): void {
        if(listener.exitEmptyOrderDecl) {
             listener.exitEmptyOrderDecl(this);
        }
    }
}


export class DecimalFormatDeclContext extends antlr.ParserRuleContext {
    public constructor(parent: antlr.ParserRuleContext | null, invokingState: number) {
        super(parent, invokingState);
    }
    public Kdeclare(): antlr.TerminalNode {
        return this.getToken(jsoniqParser.Kdeclare, 0)!;
    }
    public dfPropertyName(): DfPropertyNameContext[];
    public dfPropertyName(i: number): DfPropertyNameContext | null;
    public dfPropertyName(i?: number): DfPropertyNameContext[] | DfPropertyNameContext | null {
        if (i === undefined) {
            return this.getRuleContexts(DfPropertyNameContext);
        }

        return this.getRuleContext(i, DfPropertyNameContext);
    }
    public Kequal(): antlr.TerminalNode[];
    public Kequal(i: number): antlr.TerminalNode | null;
    public Kequal(i?: number): antlr.TerminalNode | null | antlr.TerminalNode[] {
    	if (i === undefined) {
    		return this.getTokens(jsoniqParser.Kequal);
    	} else {
    		return this.getToken(jsoniqParser.Kequal, i);
    	}
    }
    public stringLiteral(): StringLiteralContext[];
    public stringLiteral(i: number): StringLiteralContext | null;
    public stringLiteral(i?: number): StringLiteralContext[] | StringLiteralContext | null {
        if (i === undefined) {
            return this.getRuleContexts(StringLiteralContext);
        }

        return this.getRuleContext(i, StringLiteralContext);
    }
    public Kdecimal_format(): antlr.TerminalNode | null {
        return this.getToken(jsoniqParser.Kdecimal_format, 0);
    }
    public qname(): QnameContext | null {
        return this.getRuleContext(0, QnameContext);
    }
    public Kdefault(): antlr.TerminalNode | null {
        return this.getToken(jsoniqParser.Kdefault, 0);
    }
    public override get ruleIndex(): number {
        return jsoniqParser.RULE_decimalFormatDecl;
    }
    public override enterRule(listener: jsoniqListener): void {
        if(listener.enterDecimalFormatDecl) {
             listener.enterDecimalFormatDecl(this);
        }
    }
    public override exitRule(listener: jsoniqListener): void {
        if(listener.exitDecimalFormatDecl) {
             listener.exitDecimalFormatDecl(this);
        }
    }
}


export class QnameContext extends antlr.ParserRuleContext {
    public _ns?: Token | null;
    public _nskw?: KeyWordsContext;
    public _local_name?: Token | null;
    public _local_namekw?: KeyWordsContext;
    public constructor(parent: antlr.ParserRuleContext | null, invokingState: number) {
        super(parent, invokingState);
    }
    public Kcolon(): antlr.TerminalNode | null {
        return this.getToken(jsoniqParser.Kcolon, 0);
    }
    public NCName(): antlr.TerminalNode[];
    public NCName(i: number): antlr.TerminalNode | null;
    public NCName(i?: number): antlr.TerminalNode | null | antlr.TerminalNode[] {
    	if (i === undefined) {
    		return this.getTokens(jsoniqParser.NCName);
    	} else {
    		return this.getToken(jsoniqParser.NCName, i);
    	}
    }
    public keyWords(): KeyWordsContext[];
    public keyWords(i: number): KeyWordsContext | null;
    public keyWords(i?: number): KeyWordsContext[] | KeyWordsContext | null {
        if (i === undefined) {
            return this.getRuleContexts(KeyWordsContext);
        }

        return this.getRuleContext(i, KeyWordsContext);
    }
    public override get ruleIndex(): number {
        return jsoniqParser.RULE_qname;
    }
    public override enterRule(listener: jsoniqListener): void {
        if(listener.enterQname) {
             listener.enterQname(this);
        }
    }
    public override exitRule(listener: jsoniqListener): void {
        if(listener.exitQname) {
             listener.exitQname(this);
        }
    }
}


export class DfPropertyNameContext extends antlr.ParserRuleContext {
    public constructor(parent: antlr.ParserRuleContext | null, invokingState: number) {
        super(parent, invokingState);
    }
    public Kdecimal_separator(): antlr.TerminalNode | null {
        return this.getToken(jsoniqParser.Kdecimal_separator, 0);
    }
    public Kgrouping_separator(): antlr.TerminalNode | null {
        return this.getToken(jsoniqParser.Kgrouping_separator, 0);
    }
    public Kinfinity(): antlr.TerminalNode | null {
        return this.getToken(jsoniqParser.Kinfinity, 0);
    }
    public Kminus_sign(): antlr.TerminalNode | null {
        return this.getToken(jsoniqParser.Kminus_sign, 0);
    }
    public Knan(): antlr.TerminalNode | null {
        return this.getToken(jsoniqParser.Knan, 0);
    }
    public Kpercent(): antlr.TerminalNode | null {
        return this.getToken(jsoniqParser.Kpercent, 0);
    }
    public Kper_mille(): antlr.TerminalNode | null {
        return this.getToken(jsoniqParser.Kper_mille, 0);
    }
    public Kzero_digit(): antlr.TerminalNode | null {
        return this.getToken(jsoniqParser.Kzero_digit, 0);
    }
    public Kdigit(): antlr.TerminalNode | null {
        return this.getToken(jsoniqParser.Kdigit, 0);
    }
    public Kpattern_separator(): antlr.TerminalNode | null {
        return this.getToken(jsoniqParser.Kpattern_separator, 0);
    }
    public override get ruleIndex(): number {
        return jsoniqParser.RULE_dfPropertyName;
    }
    public override enterRule(listener: jsoniqListener): void {
        if(listener.enterDfPropertyName) {
             listener.enterDfPropertyName(this);
        }
    }
    public override exitRule(listener: jsoniqListener): void {
        if(listener.exitDfPropertyName) {
             listener.exitDfPropertyName(this);
        }
    }
}


export class ModuleImportContext extends antlr.ParserRuleContext {
    public _prefix?: Token | null;
    public _targetNamespace?: UriLiteralContext;
    public constructor(parent: antlr.ParserRuleContext | null, invokingState: number) {
        super(parent, invokingState);
    }
    public Kimport(): antlr.TerminalNode {
        return this.getToken(jsoniqParser.Kimport, 0)!;
    }
    public Kmodule(): antlr.TerminalNode {
        return this.getToken(jsoniqParser.Kmodule, 0)!;
    }
    public uriLiteral(): UriLiteralContext[];
    public uriLiteral(i: number): UriLiteralContext | null;
    public uriLiteral(i?: number): UriLiteralContext[] | UriLiteralContext | null {
        if (i === undefined) {
            return this.getRuleContexts(UriLiteralContext);
        }

        return this.getRuleContext(i, UriLiteralContext);
    }
    public Knamespace(): antlr.TerminalNode | null {
        return this.getToken(jsoniqParser.Knamespace, 0);
    }
    public Kequal(): antlr.TerminalNode | null {
        return this.getToken(jsoniqParser.Kequal, 0);
    }
    public Kat(): antlr.TerminalNode | null {
        return this.getToken(jsoniqParser.Kat, 0);
    }
    public NCName(): antlr.TerminalNode | null {
        return this.getToken(jsoniqParser.NCName, 0);
    }
    public Kcomma(): antlr.TerminalNode[];
    public Kcomma(i: number): antlr.TerminalNode | null;
    public Kcomma(i?: number): antlr.TerminalNode | null | antlr.TerminalNode[] {
    	if (i === undefined) {
    		return this.getTokens(jsoniqParser.Kcomma);
    	} else {
    		return this.getToken(jsoniqParser.Kcomma, i);
    	}
    }
    public override get ruleIndex(): number {
        return jsoniqParser.RULE_moduleImport;
    }
    public override enterRule(listener: jsoniqListener): void {
        if(listener.enterModuleImport) {
             listener.enterModuleImport(this);
        }
    }
    public override exitRule(listener: jsoniqListener): void {
        if(listener.exitModuleImport) {
             listener.exitModuleImport(this);
        }
    }
}


export class VarDeclContext extends antlr.ParserRuleContext {
    public _external?: Token | null;
    public constructor(parent: antlr.ParserRuleContext | null, invokingState: number) {
        super(parent, invokingState);
    }
    public Kdeclare(): antlr.TerminalNode {
        return this.getToken(jsoniqParser.Kdeclare, 0)!;
    }
    public annotations(): AnnotationsContext {
        return this.getRuleContext(0, AnnotationsContext)!;
    }
    public Kvariable(): antlr.TerminalNode {
        return this.getToken(jsoniqParser.Kvariable, 0)!;
    }
    public varRef(): VarRefContext {
        return this.getRuleContext(0, VarRefContext)!;
    }
    public Kas(): antlr.TerminalNode | null {
        return this.getToken(jsoniqParser.Kas, 0);
    }
    public sequenceType(): SequenceTypeContext | null {
        return this.getRuleContext(0, SequenceTypeContext);
    }
    public Kassign(): antlr.TerminalNode | null {
        return this.getToken(jsoniqParser.Kassign, 0);
    }
    public exprSingle(): ExprSingleContext | null {
        return this.getRuleContext(0, ExprSingleContext);
    }
    public Kexternal(): antlr.TerminalNode | null {
        return this.getToken(jsoniqParser.Kexternal, 0);
    }
    public override get ruleIndex(): number {
        return jsoniqParser.RULE_varDecl;
    }
    public override enterRule(listener: jsoniqListener): void {
        if(listener.enterVarDecl) {
             listener.enterVarDecl(this);
        }
    }
    public override exitRule(listener: jsoniqListener): void {
        if(listener.exitVarDecl) {
             listener.exitVarDecl(this);
        }
    }
}


export class ContextItemDeclContext extends antlr.ParserRuleContext {
    public _external?: Token | null;
    public constructor(parent: antlr.ParserRuleContext | null, invokingState: number) {
        super(parent, invokingState);
    }
    public Kdeclare(): antlr.TerminalNode {
        return this.getToken(jsoniqParser.Kdeclare, 0)!;
    }
    public Kcontext(): antlr.TerminalNode {
        return this.getToken(jsoniqParser.Kcontext, 0)!;
    }
    public Kitem(): antlr.TerminalNode {
        return this.getToken(jsoniqParser.Kitem, 0)!;
    }
    public Kas(): antlr.TerminalNode | null {
        return this.getToken(jsoniqParser.Kas, 0);
    }
    public sequenceType(): SequenceTypeContext | null {
        return this.getRuleContext(0, SequenceTypeContext);
    }
    public Kassign(): antlr.TerminalNode | null {
        return this.getToken(jsoniqParser.Kassign, 0);
    }
    public exprSingle(): ExprSingleContext | null {
        return this.getRuleContext(0, ExprSingleContext);
    }
    public Kexternal(): antlr.TerminalNode | null {
        return this.getToken(jsoniqParser.Kexternal, 0);
    }
    public override get ruleIndex(): number {
        return jsoniqParser.RULE_contextItemDecl;
    }
    public override enterRule(listener: jsoniqListener): void {
        if(listener.enterContextItemDecl) {
             listener.enterContextItemDecl(this);
        }
    }
    public override exitRule(listener: jsoniqListener): void {
        if(listener.exitContextItemDecl) {
             listener.exitContextItemDecl(this);
        }
    }
}


export class FunctionDeclContext extends antlr.ParserRuleContext {
    public _fn_name?: QnameContext;
    public _return_type?: SequenceTypeContext;
    public _fn_body?: StatementsAndOptionalExprContext;
    public _is_external?: Token | null;
    public constructor(parent: antlr.ParserRuleContext | null, invokingState: number) {
        super(parent, invokingState);
    }
    public Kdeclare(): antlr.TerminalNode {
        return this.getToken(jsoniqParser.Kdeclare, 0)!;
    }
    public annotations(): AnnotationsContext {
        return this.getRuleContext(0, AnnotationsContext)!;
    }
    public Kfunction(): antlr.TerminalNode {
        return this.getToken(jsoniqParser.Kfunction, 0)!;
    }
    public Klparen(): antlr.TerminalNode {
        return this.getToken(jsoniqParser.Klparen, 0)!;
    }
    public Krparen(): antlr.TerminalNode {
        return this.getToken(jsoniqParser.Krparen, 0)!;
    }
    public qname(): QnameContext {
        return this.getRuleContext(0, QnameContext)!;
    }
    public Klbrace(): antlr.TerminalNode | null {
        return this.getToken(jsoniqParser.Klbrace, 0);
    }
    public Krbrace(): antlr.TerminalNode | null {
        return this.getToken(jsoniqParser.Krbrace, 0);
    }
    public paramList(): ParamListContext | null {
        return this.getRuleContext(0, ParamListContext);
    }
    public Kas(): antlr.TerminalNode | null {
        return this.getToken(jsoniqParser.Kas, 0);
    }
    public Kexternal(): antlr.TerminalNode | null {
        return this.getToken(jsoniqParser.Kexternal, 0);
    }
    public sequenceType(): SequenceTypeContext | null {
        return this.getRuleContext(0, SequenceTypeContext);
    }
    public statementsAndOptionalExpr(): StatementsAndOptionalExprContext | null {
        return this.getRuleContext(0, StatementsAndOptionalExprContext);
    }
    public override get ruleIndex(): number {
        return jsoniqParser.RULE_functionDecl;
    }
    public override enterRule(listener: jsoniqListener): void {
        if(listener.enterFunctionDecl) {
             listener.enterFunctionDecl(this);
        }
    }
    public override exitRule(listener: jsoniqListener): void {
        if(listener.exitFunctionDecl) {
             listener.exitFunctionDecl(this);
        }
    }
}


export class TypeDeclContext extends antlr.ParserRuleContext {
    public _type_name?: QnameContext;
    public _schema?: SchemaLanguageContext;
    public _type_definition?: ExprSingleContext;
    public constructor(parent: antlr.ParserRuleContext | null, invokingState: number) {
        super(parent, invokingState);
    }
    public Kdeclare(): antlr.TerminalNode {
        return this.getToken(jsoniqParser.Kdeclare, 0)!;
    }
    public Ktype(): antlr.TerminalNode {
        return this.getToken(jsoniqParser.Ktype, 0)!;
    }
    public Kas(): antlr.TerminalNode {
        return this.getToken(jsoniqParser.Kas, 0)!;
    }
    public qname(): QnameContext {
        return this.getRuleContext(0, QnameContext)!;
    }
    public exprSingle(): ExprSingleContext {
        return this.getRuleContext(0, ExprSingleContext)!;
    }
    public schemaLanguage(): SchemaLanguageContext | null {
        return this.getRuleContext(0, SchemaLanguageContext);
    }
    public override get ruleIndex(): number {
        return jsoniqParser.RULE_typeDecl;
    }
    public override enterRule(listener: jsoniqListener): void {
        if(listener.enterTypeDecl) {
             listener.enterTypeDecl(this);
        }
    }
    public override exitRule(listener: jsoniqListener): void {
        if(listener.exitTypeDecl) {
             listener.exitTypeDecl(this);
        }
    }
}


export class SchemaLanguageContext extends antlr.ParserRuleContext {
    public constructor(parent: antlr.ParserRuleContext | null, invokingState: number) {
        super(parent, invokingState);
    }
    public Kjsound(): antlr.TerminalNode | null {
        return this.getToken(jsoniqParser.Kjsound, 0);
    }
    public Kcompact(): antlr.TerminalNode | null {
        return this.getToken(jsoniqParser.Kcompact, 0);
    }
    public Kverbose(): antlr.TerminalNode | null {
        return this.getToken(jsoniqParser.Kverbose, 0);
    }
    public Kjson(): antlr.TerminalNode | null {
        return this.getToken(jsoniqParser.Kjson, 0);
    }
    public Kschema(): antlr.TerminalNode | null {
        return this.getToken(jsoniqParser.Kschema, 0);
    }
    public override get ruleIndex(): number {
        return jsoniqParser.RULE_schemaLanguage;
    }
    public override enterRule(listener: jsoniqListener): void {
        if(listener.enterSchemaLanguage) {
             listener.enterSchemaLanguage(this);
        }
    }
    public override exitRule(listener: jsoniqListener): void {
        if(listener.exitSchemaLanguage) {
             listener.exitSchemaLanguage(this);
        }
    }
}


export class ParamListContext extends antlr.ParserRuleContext {
    public constructor(parent: antlr.ParserRuleContext | null, invokingState: number) {
        super(parent, invokingState);
    }
    public param(): ParamContext[];
    public param(i: number): ParamContext | null;
    public param(i?: number): ParamContext[] | ParamContext | null {
        if (i === undefined) {
            return this.getRuleContexts(ParamContext);
        }

        return this.getRuleContext(i, ParamContext);
    }
    public Kcomma(): antlr.TerminalNode[];
    public Kcomma(i: number): antlr.TerminalNode | null;
    public Kcomma(i?: number): antlr.TerminalNode | null | antlr.TerminalNode[] {
    	if (i === undefined) {
    		return this.getTokens(jsoniqParser.Kcomma);
    	} else {
    		return this.getToken(jsoniqParser.Kcomma, i);
    	}
    }
    public override get ruleIndex(): number {
        return jsoniqParser.RULE_paramList;
    }
    public override enterRule(listener: jsoniqListener): void {
        if(listener.enterParamList) {
             listener.enterParamList(this);
        }
    }
    public override exitRule(listener: jsoniqListener): void {
        if(listener.exitParamList) {
             listener.exitParamList(this);
        }
    }
}


export class ParamContext extends antlr.ParserRuleContext {
    public constructor(parent: antlr.ParserRuleContext | null, invokingState: number) {
        super(parent, invokingState);
    }
    public Kdollar(): antlr.TerminalNode {
        return this.getToken(jsoniqParser.Kdollar, 0)!;
    }
    public qname(): QnameContext {
        return this.getRuleContext(0, QnameContext)!;
    }
    public Kas(): antlr.TerminalNode | null {
        return this.getToken(jsoniqParser.Kas, 0);
    }
    public sequenceType(): SequenceTypeContext | null {
        return this.getRuleContext(0, SequenceTypeContext);
    }
    public override get ruleIndex(): number {
        return jsoniqParser.RULE_param;
    }
    public override enterRule(listener: jsoniqListener): void {
        if(listener.enterParam) {
             listener.enterParam(this);
        }
    }
    public override exitRule(listener: jsoniqListener): void {
        if(listener.exitParam) {
             listener.exitParam(this);
        }
    }
}


export class ExprContext extends antlr.ParserRuleContext {
    public constructor(parent: antlr.ParserRuleContext | null, invokingState: number) {
        super(parent, invokingState);
    }
    public exprSingle(): ExprSingleContext[];
    public exprSingle(i: number): ExprSingleContext | null;
    public exprSingle(i?: number): ExprSingleContext[] | ExprSingleContext | null {
        if (i === undefined) {
            return this.getRuleContexts(ExprSingleContext);
        }

        return this.getRuleContext(i, ExprSingleContext);
    }
    public Kcomma(): antlr.TerminalNode[];
    public Kcomma(i: number): antlr.TerminalNode | null;
    public Kcomma(i?: number): antlr.TerminalNode | null | antlr.TerminalNode[] {
    	if (i === undefined) {
    		return this.getTokens(jsoniqParser.Kcomma);
    	} else {
    		return this.getToken(jsoniqParser.Kcomma, i);
    	}
    }
    public override get ruleIndex(): number {
        return jsoniqParser.RULE_expr;
    }
    public override enterRule(listener: jsoniqListener): void {
        if(listener.enterExpr) {
             listener.enterExpr(this);
        }
    }
    public override exitRule(listener: jsoniqListener): void {
        if(listener.exitExpr) {
             listener.exitExpr(this);
        }
    }
}


export class ExprSingleContext extends antlr.ParserRuleContext {
    public constructor(parent: antlr.ParserRuleContext | null, invokingState: number) {
        super(parent, invokingState);
    }
    public exprSimple(): ExprSimpleContext | null {
        return this.getRuleContext(0, ExprSimpleContext);
    }
    public flowrExpr(): FlowrExprContext | null {
        return this.getRuleContext(0, FlowrExprContext);
    }
    public switchExpr(): SwitchExprContext | null {
        return this.getRuleContext(0, SwitchExprContext);
    }
    public typeSwitchExpr(): TypeSwitchExprContext | null {
        return this.getRuleContext(0, TypeSwitchExprContext);
    }
    public ifExpr(): IfExprContext | null {
        return this.getRuleContext(0, IfExprContext);
    }
    public tryCatchExpr(): TryCatchExprContext | null {
        return this.getRuleContext(0, TryCatchExprContext);
    }
    public override get ruleIndex(): number {
        return jsoniqParser.RULE_exprSingle;
    }
    public override enterRule(listener: jsoniqListener): void {
        if(listener.enterExprSingle) {
             listener.enterExprSingle(this);
        }
    }
    public override exitRule(listener: jsoniqListener): void {
        if(listener.exitExprSingle) {
             listener.exitExprSingle(this);
        }
    }
}


export class ExprSimpleContext extends antlr.ParserRuleContext {
    public constructor(parent: antlr.ParserRuleContext | null, invokingState: number) {
        super(parent, invokingState);
    }
    public quantifiedExpr(): QuantifiedExprContext | null {
        return this.getRuleContext(0, QuantifiedExprContext);
    }
    public orExpr(): OrExprContext | null {
        return this.getRuleContext(0, OrExprContext);
    }
    public insertExpr(): InsertExprContext | null {
        return this.getRuleContext(0, InsertExprContext);
    }
    public deleteExpr(): DeleteExprContext | null {
        return this.getRuleContext(0, DeleteExprContext);
    }
    public renameExpr(): RenameExprContext | null {
        return this.getRuleContext(0, RenameExprContext);
    }
    public replaceExpr(): ReplaceExprContext | null {
        return this.getRuleContext(0, ReplaceExprContext);
    }
    public transformExpr(): TransformExprContext | null {
        return this.getRuleContext(0, TransformExprContext);
    }
    public appendExpr(): AppendExprContext | null {
        return this.getRuleContext(0, AppendExprContext);
    }
    public createCollectionExpr(): CreateCollectionExprContext | null {
        return this.getRuleContext(0, CreateCollectionExprContext);
    }
    public truncateCollectionExpr(): TruncateCollectionExprContext | null {
        return this.getRuleContext(0, TruncateCollectionExprContext);
    }
    public deleteIndexExpr(): DeleteIndexExprContext | null {
        return this.getRuleContext(0, DeleteIndexExprContext);
    }
    public deleteSearchExpr(): DeleteSearchExprContext | null {
        return this.getRuleContext(0, DeleteSearchExprContext);
    }
    public editCollectionExpr(): EditCollectionExprContext | null {
        return this.getRuleContext(0, EditCollectionExprContext);
    }
    public insertIndexExpr(): InsertIndexExprContext | null {
        return this.getRuleContext(0, InsertIndexExprContext);
    }
    public insertSearchExpr(): InsertSearchExprContext | null {
        return this.getRuleContext(0, InsertSearchExprContext);
    }
    public override get ruleIndex(): number {
        return jsoniqParser.RULE_exprSimple;
    }
    public override enterRule(listener: jsoniqListener): void {
        if(listener.enterExprSimple) {
             listener.enterExprSimple(this);
        }
    }
    public override exitRule(listener: jsoniqListener): void {
        if(listener.exitExprSimple) {
             listener.exitExprSimple(this);
        }
    }
}


export class FlowrExprContext extends antlr.ParserRuleContext {
    public _start_for?: ForClauseContext;
    public _start_let?: LetClauseContext;
    public _return_expr?: ExprSingleContext;
    public constructor(parent: antlr.ParserRuleContext | null, invokingState: number) {
        super(parent, invokingState);
    }
    public Kreturn(): antlr.TerminalNode {
        return this.getToken(jsoniqParser.Kreturn, 0)!;
    }
    public exprSingle(): ExprSingleContext {
        return this.getRuleContext(0, ExprSingleContext)!;
    }
    public forClause(): ForClauseContext[];
    public forClause(i: number): ForClauseContext | null;
    public forClause(i?: number): ForClauseContext[] | ForClauseContext | null {
        if (i === undefined) {
            return this.getRuleContexts(ForClauseContext);
        }

        return this.getRuleContext(i, ForClauseContext);
    }
    public letClause(): LetClauseContext[];
    public letClause(i: number): LetClauseContext | null;
    public letClause(i?: number): LetClauseContext[] | LetClauseContext | null {
        if (i === undefined) {
            return this.getRuleContexts(LetClauseContext);
        }

        return this.getRuleContext(i, LetClauseContext);
    }
    public whereClause(): WhereClauseContext[];
    public whereClause(i: number): WhereClauseContext | null;
    public whereClause(i?: number): WhereClauseContext[] | WhereClauseContext | null {
        if (i === undefined) {
            return this.getRuleContexts(WhereClauseContext);
        }

        return this.getRuleContext(i, WhereClauseContext);
    }
    public groupByClause(): GroupByClauseContext[];
    public groupByClause(i: number): GroupByClauseContext | null;
    public groupByClause(i?: number): GroupByClauseContext[] | GroupByClauseContext | null {
        if (i === undefined) {
            return this.getRuleContexts(GroupByClauseContext);
        }

        return this.getRuleContext(i, GroupByClauseContext);
    }
    public orderByClause(): OrderByClauseContext[];
    public orderByClause(i: number): OrderByClauseContext | null;
    public orderByClause(i?: number): OrderByClauseContext[] | OrderByClauseContext | null {
        if (i === undefined) {
            return this.getRuleContexts(OrderByClauseContext);
        }

        return this.getRuleContext(i, OrderByClauseContext);
    }
    public countClause(): CountClauseContext[];
    public countClause(i: number): CountClauseContext | null;
    public countClause(i?: number): CountClauseContext[] | CountClauseContext | null {
        if (i === undefined) {
            return this.getRuleContexts(CountClauseContext);
        }

        return this.getRuleContext(i, CountClauseContext);
    }
    public override get ruleIndex(): number {
        return jsoniqParser.RULE_flowrExpr;
    }
    public override enterRule(listener: jsoniqListener): void {
        if(listener.enterFlowrExpr) {
             listener.enterFlowrExpr(this);
        }
    }
    public override exitRule(listener: jsoniqListener): void {
        if(listener.exitFlowrExpr) {
             listener.exitFlowrExpr(this);
        }
    }
}


export class ForClauseContext extends antlr.ParserRuleContext {
    public _forVar?: ForVarContext;
    public _vars: ForVarContext[] = [];
    public constructor(parent: antlr.ParserRuleContext | null, invokingState: number) {
        super(parent, invokingState);
    }
    public Kfor(): antlr.TerminalNode {
        return this.getToken(jsoniqParser.Kfor, 0)!;
    }
    public forVar(): ForVarContext[];
    public forVar(i: number): ForVarContext | null;
    public forVar(i?: number): ForVarContext[] | ForVarContext | null {
        if (i === undefined) {
            return this.getRuleContexts(ForVarContext);
        }

        return this.getRuleContext(i, ForVarContext);
    }
    public Kcomma(): antlr.TerminalNode[];
    public Kcomma(i: number): antlr.TerminalNode | null;
    public Kcomma(i?: number): antlr.TerminalNode | null | antlr.TerminalNode[] {
    	if (i === undefined) {
    		return this.getTokens(jsoniqParser.Kcomma);
    	} else {
    		return this.getToken(jsoniqParser.Kcomma, i);
    	}
    }
    public override get ruleIndex(): number {
        return jsoniqParser.RULE_forClause;
    }
    public override enterRule(listener: jsoniqListener): void {
        if(listener.enterForClause) {
             listener.enterForClause(this);
        }
    }
    public override exitRule(listener: jsoniqListener): void {
        if(listener.exitForClause) {
             listener.exitForClause(this);
        }
    }
}


export class ForVarContext extends antlr.ParserRuleContext {
    public _var_ref?: VarRefContext;
    public _seq?: SequenceTypeContext;
    public _flag?: Token | null;
    public _at?: VarRefContext;
    public _ex?: ExprSingleContext;
    public constructor(parent: antlr.ParserRuleContext | null, invokingState: number) {
        super(parent, invokingState);
    }
    public Kin(): antlr.TerminalNode {
        return this.getToken(jsoniqParser.Kin, 0)!;
    }
    public varRef(): VarRefContext[];
    public varRef(i: number): VarRefContext | null;
    public varRef(i?: number): VarRefContext[] | VarRefContext | null {
        if (i === undefined) {
            return this.getRuleContexts(VarRefContext);
        }

        return this.getRuleContext(i, VarRefContext);
    }
    public exprSingle(): ExprSingleContext {
        return this.getRuleContext(0, ExprSingleContext)!;
    }
    public Kas(): antlr.TerminalNode | null {
        return this.getToken(jsoniqParser.Kas, 0);
    }
    public Kempty(): antlr.TerminalNode | null {
        return this.getToken(jsoniqParser.Kempty, 0);
    }
    public Kat(): antlr.TerminalNode | null {
        return this.getToken(jsoniqParser.Kat, 0);
    }
    public sequenceType(): SequenceTypeContext | null {
        return this.getRuleContext(0, SequenceTypeContext);
    }
    public Kallowing(): antlr.TerminalNode | null {
        return this.getToken(jsoniqParser.Kallowing, 0);
    }
    public override get ruleIndex(): number {
        return jsoniqParser.RULE_forVar;
    }
    public override enterRule(listener: jsoniqListener): void {
        if(listener.enterForVar) {
             listener.enterForVar(this);
        }
    }
    public override exitRule(listener: jsoniqListener): void {
        if(listener.exitForVar) {
             listener.exitForVar(this);
        }
    }
}


export class LetClauseContext extends antlr.ParserRuleContext {
    public _letVar?: LetVarContext;
    public _vars: LetVarContext[] = [];
    public constructor(parent: antlr.ParserRuleContext | null, invokingState: number) {
        super(parent, invokingState);
    }
    public Klet(): antlr.TerminalNode {
        return this.getToken(jsoniqParser.Klet, 0)!;
    }
    public letVar(): LetVarContext[];
    public letVar(i: number): LetVarContext | null;
    public letVar(i?: number): LetVarContext[] | LetVarContext | null {
        if (i === undefined) {
            return this.getRuleContexts(LetVarContext);
        }

        return this.getRuleContext(i, LetVarContext);
    }
    public Kcomma(): antlr.TerminalNode[];
    public Kcomma(i: number): antlr.TerminalNode | null;
    public Kcomma(i?: number): antlr.TerminalNode | null | antlr.TerminalNode[] {
    	if (i === undefined) {
    		return this.getTokens(jsoniqParser.Kcomma);
    	} else {
    		return this.getToken(jsoniqParser.Kcomma, i);
    	}
    }
    public override get ruleIndex(): number {
        return jsoniqParser.RULE_letClause;
    }
    public override enterRule(listener: jsoniqListener): void {
        if(listener.enterLetClause) {
             listener.enterLetClause(this);
        }
    }
    public override exitRule(listener: jsoniqListener): void {
        if(listener.exitLetClause) {
             listener.exitLetClause(this);
        }
    }
}


export class LetVarContext extends antlr.ParserRuleContext {
    public _var_ref?: VarRefContext;
    public _seq?: SequenceTypeContext;
    public _ex?: ExprSingleContext;
    public constructor(parent: antlr.ParserRuleContext | null, invokingState: number) {
        super(parent, invokingState);
    }
    public Kassign(): antlr.TerminalNode {
        return this.getToken(jsoniqParser.Kassign, 0)!;
    }
    public varRef(): VarRefContext {
        return this.getRuleContext(0, VarRefContext)!;
    }
    public exprSingle(): ExprSingleContext {
        return this.getRuleContext(0, ExprSingleContext)!;
    }
    public Kas(): antlr.TerminalNode | null {
        return this.getToken(jsoniqParser.Kas, 0);
    }
    public sequenceType(): SequenceTypeContext | null {
        return this.getRuleContext(0, SequenceTypeContext);
    }
    public override get ruleIndex(): number {
        return jsoniqParser.RULE_letVar;
    }
    public override enterRule(listener: jsoniqListener): void {
        if(listener.enterLetVar) {
             listener.enterLetVar(this);
        }
    }
    public override exitRule(listener: jsoniqListener): void {
        if(listener.exitLetVar) {
             listener.exitLetVar(this);
        }
    }
}


export class WhereClauseContext extends antlr.ParserRuleContext {
    public constructor(parent: antlr.ParserRuleContext | null, invokingState: number) {
        super(parent, invokingState);
    }
    public Kwhere(): antlr.TerminalNode {
        return this.getToken(jsoniqParser.Kwhere, 0)!;
    }
    public exprSingle(): ExprSingleContext {
        return this.getRuleContext(0, ExprSingleContext)!;
    }
    public override get ruleIndex(): number {
        return jsoniqParser.RULE_whereClause;
    }
    public override enterRule(listener: jsoniqListener): void {
        if(listener.enterWhereClause) {
             listener.enterWhereClause(this);
        }
    }
    public override exitRule(listener: jsoniqListener): void {
        if(listener.exitWhereClause) {
             listener.exitWhereClause(this);
        }
    }
}


export class GroupByClauseContext extends antlr.ParserRuleContext {
    public _groupByVar?: GroupByVarContext;
    public _vars: GroupByVarContext[] = [];
    public constructor(parent: antlr.ParserRuleContext | null, invokingState: number) {
        super(parent, invokingState);
    }
    public Kgroup(): antlr.TerminalNode {
        return this.getToken(jsoniqParser.Kgroup, 0)!;
    }
    public Kby(): antlr.TerminalNode {
        return this.getToken(jsoniqParser.Kby, 0)!;
    }
    public groupByVar(): GroupByVarContext[];
    public groupByVar(i: number): GroupByVarContext | null;
    public groupByVar(i?: number): GroupByVarContext[] | GroupByVarContext | null {
        if (i === undefined) {
            return this.getRuleContexts(GroupByVarContext);
        }

        return this.getRuleContext(i, GroupByVarContext);
    }
    public Kcomma(): antlr.TerminalNode[];
    public Kcomma(i: number): antlr.TerminalNode | null;
    public Kcomma(i?: number): antlr.TerminalNode | null | antlr.TerminalNode[] {
    	if (i === undefined) {
    		return this.getTokens(jsoniqParser.Kcomma);
    	} else {
    		return this.getToken(jsoniqParser.Kcomma, i);
    	}
    }
    public override get ruleIndex(): number {
        return jsoniqParser.RULE_groupByClause;
    }
    public override enterRule(listener: jsoniqListener): void {
        if(listener.enterGroupByClause) {
             listener.enterGroupByClause(this);
        }
    }
    public override exitRule(listener: jsoniqListener): void {
        if(listener.exitGroupByClause) {
             listener.exitGroupByClause(this);
        }
    }
}


export class GroupByVarContext extends antlr.ParserRuleContext {
    public _var_ref?: VarRefContext;
    public _seq?: SequenceTypeContext;
    public _decl?: Token | null;
    public _ex?: ExprSingleContext;
    public _uri?: UriLiteralContext;
    public constructor(parent: antlr.ParserRuleContext | null, invokingState: number) {
        super(parent, invokingState);
    }
    public varRef(): VarRefContext {
        return this.getRuleContext(0, VarRefContext)!;
    }
    public Kcollation(): antlr.TerminalNode | null {
        return this.getToken(jsoniqParser.Kcollation, 0);
    }
    public Kassign(): antlr.TerminalNode | null {
        return this.getToken(jsoniqParser.Kassign, 0);
    }
    public exprSingle(): ExprSingleContext | null {
        return this.getRuleContext(0, ExprSingleContext);
    }
    public uriLiteral(): UriLiteralContext | null {
        return this.getRuleContext(0, UriLiteralContext);
    }
    public Kas(): antlr.TerminalNode | null {
        return this.getToken(jsoniqParser.Kas, 0);
    }
    public sequenceType(): SequenceTypeContext | null {
        return this.getRuleContext(0, SequenceTypeContext);
    }
    public override get ruleIndex(): number {
        return jsoniqParser.RULE_groupByVar;
    }
    public override enterRule(listener: jsoniqListener): void {
        if(listener.enterGroupByVar) {
             listener.enterGroupByVar(this);
        }
    }
    public override exitRule(listener: jsoniqListener): void {
        if(listener.exitGroupByVar) {
             listener.exitGroupByVar(this);
        }
    }
}


export class OrderByClauseContext extends antlr.ParserRuleContext {
    public _stb?: Token | null;
    public constructor(parent: antlr.ParserRuleContext | null, invokingState: number) {
        super(parent, invokingState);
    }
    public orderByExpr(): OrderByExprContext[];
    public orderByExpr(i: number): OrderByExprContext | null;
    public orderByExpr(i?: number): OrderByExprContext[] | OrderByExprContext | null {
        if (i === undefined) {
            return this.getRuleContexts(OrderByExprContext);
        }

        return this.getRuleContext(i, OrderByExprContext);
    }
    public Kcomma(): antlr.TerminalNode[];
    public Kcomma(i: number): antlr.TerminalNode | null;
    public Kcomma(i?: number): antlr.TerminalNode | null | antlr.TerminalNode[] {
    	if (i === undefined) {
    		return this.getTokens(jsoniqParser.Kcomma);
    	} else {
    		return this.getToken(jsoniqParser.Kcomma, i);
    	}
    }
    public Korder(): antlr.TerminalNode | null {
        return this.getToken(jsoniqParser.Korder, 0);
    }
    public Kby(): antlr.TerminalNode | null {
        return this.getToken(jsoniqParser.Kby, 0);
    }
    public Kstable(): antlr.TerminalNode | null {
        return this.getToken(jsoniqParser.Kstable, 0);
    }
    public override get ruleIndex(): number {
        return jsoniqParser.RULE_orderByClause;
    }
    public override enterRule(listener: jsoniqListener): void {
        if(listener.enterOrderByClause) {
             listener.enterOrderByClause(this);
        }
    }
    public override exitRule(listener: jsoniqListener): void {
        if(listener.exitOrderByClause) {
             listener.exitOrderByClause(this);
        }
    }
}


export class OrderByExprContext extends antlr.ParserRuleContext {
    public _ex?: ExprSingleContext;
    public _desc?: Token | null;
    public _gr?: Token | null;
    public _ls?: Token | null;
    public _uril?: UriLiteralContext;
    public constructor(parent: antlr.ParserRuleContext | null, invokingState: number) {
        super(parent, invokingState);
    }
    public exprSingle(): ExprSingleContext {
        return this.getRuleContext(0, ExprSingleContext)!;
    }
    public Kascending(): antlr.TerminalNode | null {
        return this.getToken(jsoniqParser.Kascending, 0);
    }
    public Kempty(): antlr.TerminalNode | null {
        return this.getToken(jsoniqParser.Kempty, 0);
    }
    public Kcollation(): antlr.TerminalNode | null {
        return this.getToken(jsoniqParser.Kcollation, 0);
    }
    public Kdescending(): antlr.TerminalNode | null {
        return this.getToken(jsoniqParser.Kdescending, 0);
    }
    public uriLiteral(): UriLiteralContext | null {
        return this.getRuleContext(0, UriLiteralContext);
    }
    public Kgreatest(): antlr.TerminalNode | null {
        return this.getToken(jsoniqParser.Kgreatest, 0);
    }
    public Kleast(): antlr.TerminalNode | null {
        return this.getToken(jsoniqParser.Kleast, 0);
    }
    public override get ruleIndex(): number {
        return jsoniqParser.RULE_orderByExpr;
    }
    public override enterRule(listener: jsoniqListener): void {
        if(listener.enterOrderByExpr) {
             listener.enterOrderByExpr(this);
        }
    }
    public override exitRule(listener: jsoniqListener): void {
        if(listener.exitOrderByExpr) {
             listener.exitOrderByExpr(this);
        }
    }
}


export class CountClauseContext extends antlr.ParserRuleContext {
    public constructor(parent: antlr.ParserRuleContext | null, invokingState: number) {
        super(parent, invokingState);
    }
    public Kcount(): antlr.TerminalNode {
        return this.getToken(jsoniqParser.Kcount, 0)!;
    }
    public varRef(): VarRefContext {
        return this.getRuleContext(0, VarRefContext)!;
    }
    public override get ruleIndex(): number {
        return jsoniqParser.RULE_countClause;
    }
    public override enterRule(listener: jsoniqListener): void {
        if(listener.enterCountClause) {
             listener.enterCountClause(this);
        }
    }
    public override exitRule(listener: jsoniqListener): void {
        if(listener.exitCountClause) {
             listener.exitCountClause(this);
        }
    }
}


export class QuantifiedExprContext extends antlr.ParserRuleContext {
    public _so?: Token | null;
    public _ev?: Token | null;
    public _quantifiedExprVar?: QuantifiedExprVarContext;
    public _vars: QuantifiedExprVarContext[] = [];
    public constructor(parent: antlr.ParserRuleContext | null, invokingState: number) {
        super(parent, invokingState);
    }
    public Ksatisfies(): antlr.TerminalNode {
        return this.getToken(jsoniqParser.Ksatisfies, 0)!;
    }
    public exprSingle(): ExprSingleContext {
        return this.getRuleContext(0, ExprSingleContext)!;
    }
    public quantifiedExprVar(): QuantifiedExprVarContext[];
    public quantifiedExprVar(i: number): QuantifiedExprVarContext | null;
    public quantifiedExprVar(i?: number): QuantifiedExprVarContext[] | QuantifiedExprVarContext | null {
        if (i === undefined) {
            return this.getRuleContexts(QuantifiedExprVarContext);
        }

        return this.getRuleContext(i, QuantifiedExprVarContext);
    }
    public Ksome(): antlr.TerminalNode | null {
        return this.getToken(jsoniqParser.Ksome, 0);
    }
    public Kevery(): antlr.TerminalNode | null {
        return this.getToken(jsoniqParser.Kevery, 0);
    }
    public Kcomma(): antlr.TerminalNode[];
    public Kcomma(i: number): antlr.TerminalNode | null;
    public Kcomma(i?: number): antlr.TerminalNode | null | antlr.TerminalNode[] {
    	if (i === undefined) {
    		return this.getTokens(jsoniqParser.Kcomma);
    	} else {
    		return this.getToken(jsoniqParser.Kcomma, i);
    	}
    }
    public override get ruleIndex(): number {
        return jsoniqParser.RULE_quantifiedExpr;
    }
    public override enterRule(listener: jsoniqListener): void {
        if(listener.enterQuantifiedExpr) {
             listener.enterQuantifiedExpr(this);
        }
    }
    public override exitRule(listener: jsoniqListener): void {
        if(listener.exitQuantifiedExpr) {
             listener.exitQuantifiedExpr(this);
        }
    }
}


export class QuantifiedExprVarContext extends antlr.ParserRuleContext {
    public constructor(parent: antlr.ParserRuleContext | null, invokingState: number) {
        super(parent, invokingState);
    }
    public varRef(): VarRefContext {
        return this.getRuleContext(0, VarRefContext)!;
    }
    public Kin(): antlr.TerminalNode {
        return this.getToken(jsoniqParser.Kin, 0)!;
    }
    public exprSingle(): ExprSingleContext {
        return this.getRuleContext(0, ExprSingleContext)!;
    }
    public Kas(): antlr.TerminalNode | null {
        return this.getToken(jsoniqParser.Kas, 0);
    }
    public sequenceType(): SequenceTypeContext | null {
        return this.getRuleContext(0, SequenceTypeContext);
    }
    public override get ruleIndex(): number {
        return jsoniqParser.RULE_quantifiedExprVar;
    }
    public override enterRule(listener: jsoniqListener): void {
        if(listener.enterQuantifiedExprVar) {
             listener.enterQuantifiedExprVar(this);
        }
    }
    public override exitRule(listener: jsoniqListener): void {
        if(listener.exitQuantifiedExprVar) {
             listener.exitQuantifiedExprVar(this);
        }
    }
}


export class SwitchExprContext extends antlr.ParserRuleContext {
    public _cond?: ExprContext;
    public _switchCaseClause?: SwitchCaseClauseContext;
    public _cases: SwitchCaseClauseContext[] = [];
    public _def?: ExprSingleContext;
    public constructor(parent: antlr.ParserRuleContext | null, invokingState: number) {
        super(parent, invokingState);
    }
    public Kswitch(): antlr.TerminalNode {
        return this.getToken(jsoniqParser.Kswitch, 0)!;
    }
    public Klparen(): antlr.TerminalNode {
        return this.getToken(jsoniqParser.Klparen, 0)!;
    }
    public Krparen(): antlr.TerminalNode {
        return this.getToken(jsoniqParser.Krparen, 0)!;
    }
    public Kdefault(): antlr.TerminalNode {
        return this.getToken(jsoniqParser.Kdefault, 0)!;
    }
    public Kreturn(): antlr.TerminalNode {
        return this.getToken(jsoniqParser.Kreturn, 0)!;
    }
    public expr(): ExprContext {
        return this.getRuleContext(0, ExprContext)!;
    }
    public exprSingle(): ExprSingleContext {
        return this.getRuleContext(0, ExprSingleContext)!;
    }
    public switchCaseClause(): SwitchCaseClauseContext[];
    public switchCaseClause(i: number): SwitchCaseClauseContext | null;
    public switchCaseClause(i?: number): SwitchCaseClauseContext[] | SwitchCaseClauseContext | null {
        if (i === undefined) {
            return this.getRuleContexts(SwitchCaseClauseContext);
        }

        return this.getRuleContext(i, SwitchCaseClauseContext);
    }
    public override get ruleIndex(): number {
        return jsoniqParser.RULE_switchExpr;
    }
    public override enterRule(listener: jsoniqListener): void {
        if(listener.enterSwitchExpr) {
             listener.enterSwitchExpr(this);
        }
    }
    public override exitRule(listener: jsoniqListener): void {
        if(listener.exitSwitchExpr) {
             listener.exitSwitchExpr(this);
        }
    }
}


export class SwitchCaseClauseContext extends antlr.ParserRuleContext {
    public _exprSingle?: ExprSingleContext;
    public _cond: ExprSingleContext[] = [];
    public _ret?: ExprSingleContext;
    public constructor(parent: antlr.ParserRuleContext | null, invokingState: number) {
        super(parent, invokingState);
    }
    public Kreturn(): antlr.TerminalNode {
        return this.getToken(jsoniqParser.Kreturn, 0)!;
    }
    public exprSingle(): ExprSingleContext[];
    public exprSingle(i: number): ExprSingleContext | null;
    public exprSingle(i?: number): ExprSingleContext[] | ExprSingleContext | null {
        if (i === undefined) {
            return this.getRuleContexts(ExprSingleContext);
        }

        return this.getRuleContext(i, ExprSingleContext);
    }
    public Kcase(): antlr.TerminalNode[];
    public Kcase(i: number): antlr.TerminalNode | null;
    public Kcase(i?: number): antlr.TerminalNode | null | antlr.TerminalNode[] {
    	if (i === undefined) {
    		return this.getTokens(jsoniqParser.Kcase);
    	} else {
    		return this.getToken(jsoniqParser.Kcase, i);
    	}
    }
    public override get ruleIndex(): number {
        return jsoniqParser.RULE_switchCaseClause;
    }
    public override enterRule(listener: jsoniqListener): void {
        if(listener.enterSwitchCaseClause) {
             listener.enterSwitchCaseClause(this);
        }
    }
    public override exitRule(listener: jsoniqListener): void {
        if(listener.exitSwitchCaseClause) {
             listener.exitSwitchCaseClause(this);
        }
    }
}


export class TypeSwitchExprContext extends antlr.ParserRuleContext {
    public _cond?: ExprContext;
    public _caseClause?: CaseClauseContext;
    public _cses: CaseClauseContext[] = [];
    public _var_ref?: VarRefContext;
    public _def?: ExprSingleContext;
    public constructor(parent: antlr.ParserRuleContext | null, invokingState: number) {
        super(parent, invokingState);
    }
    public Ktypeswitch(): antlr.TerminalNode {
        return this.getToken(jsoniqParser.Ktypeswitch, 0)!;
    }
    public Klparen(): antlr.TerminalNode {
        return this.getToken(jsoniqParser.Klparen, 0)!;
    }
    public Krparen(): antlr.TerminalNode {
        return this.getToken(jsoniqParser.Krparen, 0)!;
    }
    public Kdefault(): antlr.TerminalNode {
        return this.getToken(jsoniqParser.Kdefault, 0)!;
    }
    public Kreturn(): antlr.TerminalNode {
        return this.getToken(jsoniqParser.Kreturn, 0)!;
    }
    public expr(): ExprContext {
        return this.getRuleContext(0, ExprContext)!;
    }
    public exprSingle(): ExprSingleContext {
        return this.getRuleContext(0, ExprSingleContext)!;
    }
    public caseClause(): CaseClauseContext[];
    public caseClause(i: number): CaseClauseContext | null;
    public caseClause(i?: number): CaseClauseContext[] | CaseClauseContext | null {
        if (i === undefined) {
            return this.getRuleContexts(CaseClauseContext);
        }

        return this.getRuleContext(i, CaseClauseContext);
    }
    public varRef(): VarRefContext | null {
        return this.getRuleContext(0, VarRefContext);
    }
    public override get ruleIndex(): number {
        return jsoniqParser.RULE_typeSwitchExpr;
    }
    public override enterRule(listener: jsoniqListener): void {
        if(listener.enterTypeSwitchExpr) {
             listener.enterTypeSwitchExpr(this);
        }
    }
    public override exitRule(listener: jsoniqListener): void {
        if(listener.exitTypeSwitchExpr) {
             listener.exitTypeSwitchExpr(this);
        }
    }
}


export class CaseClauseContext extends antlr.ParserRuleContext {
    public _var_ref?: VarRefContext;
    public _sequenceType?: SequenceTypeContext;
    public _union: SequenceTypeContext[] = [];
    public _ret?: ExprSingleContext;
    public constructor(parent: antlr.ParserRuleContext | null, invokingState: number) {
        super(parent, invokingState);
    }
    public Kcase(): antlr.TerminalNode {
        return this.getToken(jsoniqParser.Kcase, 0)!;
    }
    public Kreturn(): antlr.TerminalNode {
        return this.getToken(jsoniqParser.Kreturn, 0)!;
    }
    public sequenceType(): SequenceTypeContext[];
    public sequenceType(i: number): SequenceTypeContext | null;
    public sequenceType(i?: number): SequenceTypeContext[] | SequenceTypeContext | null {
        if (i === undefined) {
            return this.getRuleContexts(SequenceTypeContext);
        }

        return this.getRuleContext(i, SequenceTypeContext);
    }
    public exprSingle(): ExprSingleContext {
        return this.getRuleContext(0, ExprSingleContext)!;
    }
    public Kas(): antlr.TerminalNode | null {
        return this.getToken(jsoniqParser.Kas, 0);
    }
    public Kpipe(): antlr.TerminalNode[];
    public Kpipe(i: number): antlr.TerminalNode | null;
    public Kpipe(i?: number): antlr.TerminalNode | null | antlr.TerminalNode[] {
    	if (i === undefined) {
    		return this.getTokens(jsoniqParser.Kpipe);
    	} else {
    		return this.getToken(jsoniqParser.Kpipe, i);
    	}
    }
    public varRef(): VarRefContext | null {
        return this.getRuleContext(0, VarRefContext);
    }
    public override get ruleIndex(): number {
        return jsoniqParser.RULE_caseClause;
    }
    public override enterRule(listener: jsoniqListener): void {
        if(listener.enterCaseClause) {
             listener.enterCaseClause(this);
        }
    }
    public override exitRule(listener: jsoniqListener): void {
        if(listener.exitCaseClause) {
             listener.exitCaseClause(this);
        }
    }
}


export class IfExprContext extends antlr.ParserRuleContext {
    public _test_condition?: ExprContext;
    public _branch?: ExprSingleContext;
    public _else_branch?: ExprSingleContext;
    public constructor(parent: antlr.ParserRuleContext | null, invokingState: number) {
        super(parent, invokingState);
    }
    public Kif(): antlr.TerminalNode {
        return this.getToken(jsoniqParser.Kif, 0)!;
    }
    public Klparen(): antlr.TerminalNode {
        return this.getToken(jsoniqParser.Klparen, 0)!;
    }
    public Krparen(): antlr.TerminalNode {
        return this.getToken(jsoniqParser.Krparen, 0)!;
    }
    public Kthen(): antlr.TerminalNode {
        return this.getToken(jsoniqParser.Kthen, 0)!;
    }
    public Kelse(): antlr.TerminalNode {
        return this.getToken(jsoniqParser.Kelse, 0)!;
    }
    public expr(): ExprContext {
        return this.getRuleContext(0, ExprContext)!;
    }
    public exprSingle(): ExprSingleContext[];
    public exprSingle(i: number): ExprSingleContext | null;
    public exprSingle(i?: number): ExprSingleContext[] | ExprSingleContext | null {
        if (i === undefined) {
            return this.getRuleContexts(ExprSingleContext);
        }

        return this.getRuleContext(i, ExprSingleContext);
    }
    public override get ruleIndex(): number {
        return jsoniqParser.RULE_ifExpr;
    }
    public override enterRule(listener: jsoniqListener): void {
        if(listener.enterIfExpr) {
             listener.enterIfExpr(this);
        }
    }
    public override exitRule(listener: jsoniqListener): void {
        if(listener.exitIfExpr) {
             listener.exitIfExpr(this);
        }
    }
}


export class TryCatchExprContext extends antlr.ParserRuleContext {
    public _try_expression?: ExprContext;
    public _catchClause?: CatchClauseContext;
    public _catches: CatchClauseContext[] = [];
    public constructor(parent: antlr.ParserRuleContext | null, invokingState: number) {
        super(parent, invokingState);
    }
    public Ktry(): antlr.TerminalNode {
        return this.getToken(jsoniqParser.Ktry, 0)!;
    }
    public Klbrace(): antlr.TerminalNode {
        return this.getToken(jsoniqParser.Klbrace, 0)!;
    }
    public Krbrace(): antlr.TerminalNode {
        return this.getToken(jsoniqParser.Krbrace, 0)!;
    }
    public expr(): ExprContext {
        return this.getRuleContext(0, ExprContext)!;
    }
    public catchClause(): CatchClauseContext[];
    public catchClause(i: number): CatchClauseContext | null;
    public catchClause(i?: number): CatchClauseContext[] | CatchClauseContext | null {
        if (i === undefined) {
            return this.getRuleContexts(CatchClauseContext);
        }

        return this.getRuleContext(i, CatchClauseContext);
    }
    public override get ruleIndex(): number {
        return jsoniqParser.RULE_tryCatchExpr;
    }
    public override enterRule(listener: jsoniqListener): void {
        if(listener.enterTryCatchExpr) {
             listener.enterTryCatchExpr(this);
        }
    }
    public override exitRule(listener: jsoniqListener): void {
        if(listener.exitTryCatchExpr) {
             listener.exitTryCatchExpr(this);
        }
    }
}


export class CatchClauseContext extends antlr.ParserRuleContext {
    public _s10?: Token | null;
    public _jokers: antlr.Token[] = [];
    public _qname?: QnameContext;
    public _errors: QnameContext[] = [];
    public _catch_expression?: ExprContext;
    public constructor(parent: antlr.ParserRuleContext | null, invokingState: number) {
        super(parent, invokingState);
    }
    public Kcatch(): antlr.TerminalNode {
        return this.getToken(jsoniqParser.Kcatch, 0)!;
    }
    public Klbrace(): antlr.TerminalNode {
        return this.getToken(jsoniqParser.Klbrace, 0)!;
    }
    public Krbrace(): antlr.TerminalNode {
        return this.getToken(jsoniqParser.Krbrace, 0)!;
    }
    public expr(): ExprContext {
        return this.getRuleContext(0, ExprContext)!;
    }
    public Kasterisk(): antlr.TerminalNode[];
    public Kasterisk(i: number): antlr.TerminalNode | null;
    public Kasterisk(i?: number): antlr.TerminalNode | null | antlr.TerminalNode[] {
    	if (i === undefined) {
    		return this.getTokens(jsoniqParser.Kasterisk);
    	} else {
    		return this.getToken(jsoniqParser.Kasterisk, i);
    	}
    }
    public qname(): QnameContext[];
    public qname(i: number): QnameContext | null;
    public qname(i?: number): QnameContext[] | QnameContext | null {
        if (i === undefined) {
            return this.getRuleContexts(QnameContext);
        }

        return this.getRuleContext(i, QnameContext);
    }
    public Kpipe(): antlr.TerminalNode[];
    public Kpipe(i: number): antlr.TerminalNode | null;
    public Kpipe(i?: number): antlr.TerminalNode | null | antlr.TerminalNode[] {
    	if (i === undefined) {
    		return this.getTokens(jsoniqParser.Kpipe);
    	} else {
    		return this.getToken(jsoniqParser.Kpipe, i);
    	}
    }
    public override get ruleIndex(): number {
        return jsoniqParser.RULE_catchClause;
    }
    public override enterRule(listener: jsoniqListener): void {
        if(listener.enterCatchClause) {
             listener.enterCatchClause(this);
        }
    }
    public override exitRule(listener: jsoniqListener): void {
        if(listener.exitCatchClause) {
             listener.exitCatchClause(this);
        }
    }
}


export class OrExprContext extends antlr.ParserRuleContext {
    public _main_expr?: AndExprContext;
    public _andExpr?: AndExprContext;
    public _rhs: AndExprContext[] = [];
    public constructor(parent: antlr.ParserRuleContext | null, invokingState: number) {
        super(parent, invokingState);
    }
    public andExpr(): AndExprContext[];
    public andExpr(i: number): AndExprContext | null;
    public andExpr(i?: number): AndExprContext[] | AndExprContext | null {
        if (i === undefined) {
            return this.getRuleContexts(AndExprContext);
        }

        return this.getRuleContext(i, AndExprContext);
    }
    public Kor(): antlr.TerminalNode[];
    public Kor(i: number): antlr.TerminalNode | null;
    public Kor(i?: number): antlr.TerminalNode | null | antlr.TerminalNode[] {
    	if (i === undefined) {
    		return this.getTokens(jsoniqParser.Kor);
    	} else {
    		return this.getToken(jsoniqParser.Kor, i);
    	}
    }
    public override get ruleIndex(): number {
        return jsoniqParser.RULE_orExpr;
    }
    public override enterRule(listener: jsoniqListener): void {
        if(listener.enterOrExpr) {
             listener.enterOrExpr(this);
        }
    }
    public override exitRule(listener: jsoniqListener): void {
        if(listener.exitOrExpr) {
             listener.exitOrExpr(this);
        }
    }
}


export class AndExprContext extends antlr.ParserRuleContext {
    public _main_expr?: NotExprContext;
    public _notExpr?: NotExprContext;
    public _rhs: NotExprContext[] = [];
    public constructor(parent: antlr.ParserRuleContext | null, invokingState: number) {
        super(parent, invokingState);
    }
    public notExpr(): NotExprContext[];
    public notExpr(i: number): NotExprContext | null;
    public notExpr(i?: number): NotExprContext[] | NotExprContext | null {
        if (i === undefined) {
            return this.getRuleContexts(NotExprContext);
        }

        return this.getRuleContext(i, NotExprContext);
    }
    public Kand(): antlr.TerminalNode[];
    public Kand(i: number): antlr.TerminalNode | null;
    public Kand(i?: number): antlr.TerminalNode | null | antlr.TerminalNode[] {
    	if (i === undefined) {
    		return this.getTokens(jsoniqParser.Kand);
    	} else {
    		return this.getToken(jsoniqParser.Kand, i);
    	}
    }
    public override get ruleIndex(): number {
        return jsoniqParser.RULE_andExpr;
    }
    public override enterRule(listener: jsoniqListener): void {
        if(listener.enterAndExpr) {
             listener.enterAndExpr(this);
        }
    }
    public override exitRule(listener: jsoniqListener): void {
        if(listener.exitAndExpr) {
             listener.exitAndExpr(this);
        }
    }
}


export class NotExprContext extends antlr.ParserRuleContext {
    public _Knot?: Token | null;
    public _op: antlr.Token[] = [];
    public _main_expr?: ComparisonExprContext;
    public constructor(parent: antlr.ParserRuleContext | null, invokingState: number) {
        super(parent, invokingState);
    }
    public comparisonExpr(): ComparisonExprContext {
        return this.getRuleContext(0, ComparisonExprContext)!;
    }
    public Knot(): antlr.TerminalNode | null {
        return this.getToken(jsoniqParser.Knot, 0);
    }
    public override get ruleIndex(): number {
        return jsoniqParser.RULE_notExpr;
    }
    public override enterRule(listener: jsoniqListener): void {
        if(listener.enterNotExpr) {
             listener.enterNotExpr(this);
        }
    }
    public override exitRule(listener: jsoniqListener): void {
        if(listener.exitNotExpr) {
             listener.exitNotExpr(this);
        }
    }
}


export class ComparisonExprContext extends antlr.ParserRuleContext {
    public _main_expr?: StringConcatExprContext;
    public _s34?: Token | null;
    public _op: antlr.Token[] = [];
    public _s35?: Token | null;
    public _s36?: Token | null;
    public _s37?: Token | null;
    public _s38?: Token | null;
    public _s39?: Token | null;
    public _s3?: Token | null;
    public _s40?: Token | null;
    public _s41?: Token | null;
    public _s42?: Token | null;
    public _s43?: Token | null;
    public _s44?: Token | null;
    public __tset1877?: Token | null;
    public _stringConcatExpr?: StringConcatExprContext;
    public _rhs: StringConcatExprContext[] = [];
    public constructor(parent: antlr.ParserRuleContext | null, invokingState: number) {
        super(parent, invokingState);
    }
    public stringConcatExpr(): StringConcatExprContext[];
    public stringConcatExpr(i: number): StringConcatExprContext | null;
    public stringConcatExpr(i?: number): StringConcatExprContext[] | StringConcatExprContext | null {
        if (i === undefined) {
            return this.getRuleContexts(StringConcatExprContext);
        }

        return this.getRuleContext(i, StringConcatExprContext);
    }
    public Keq(): antlr.TerminalNode | null {
        return this.getToken(jsoniqParser.Keq, 0);
    }
    public Kne(): antlr.TerminalNode | null {
        return this.getToken(jsoniqParser.Kne, 0);
    }
    public Klt(): antlr.TerminalNode | null {
        return this.getToken(jsoniqParser.Klt, 0);
    }
    public Kle(): antlr.TerminalNode | null {
        return this.getToken(jsoniqParser.Kle, 0);
    }
    public Kgt(): antlr.TerminalNode | null {
        return this.getToken(jsoniqParser.Kgt, 0);
    }
    public Kge(): antlr.TerminalNode | null {
        return this.getToken(jsoniqParser.Kge, 0);
    }
    public Kequal(): antlr.TerminalNode | null {
        return this.getToken(jsoniqParser.Kequal, 0);
    }
    public Knot_equal(): antlr.TerminalNode | null {
        return this.getToken(jsoniqParser.Knot_equal, 0);
    }
    public Kless(): antlr.TerminalNode | null {
        return this.getToken(jsoniqParser.Kless, 0);
    }
    public Kless_or_equal(): antlr.TerminalNode | null {
        return this.getToken(jsoniqParser.Kless_or_equal, 0);
    }
    public Kgreater(): antlr.TerminalNode | null {
        return this.getToken(jsoniqParser.Kgreater, 0);
    }
    public Kgreater_or_equal(): antlr.TerminalNode | null {
        return this.getToken(jsoniqParser.Kgreater_or_equal, 0);
    }
    public override get ruleIndex(): number {
        return jsoniqParser.RULE_comparisonExpr;
    }
    public override enterRule(listener: jsoniqListener): void {
        if(listener.enterComparisonExpr) {
             listener.enterComparisonExpr(this);
        }
    }
    public override exitRule(listener: jsoniqListener): void {
        if(listener.exitComparisonExpr) {
             listener.exitComparisonExpr(this);
        }
    }
}


export class StringConcatExprContext extends antlr.ParserRuleContext {
    public _main_expr?: RangeExprContext;
    public _rangeExpr?: RangeExprContext;
    public _rhs: RangeExprContext[] = [];
    public constructor(parent: antlr.ParserRuleContext | null, invokingState: number) {
        super(parent, invokingState);
    }
    public rangeExpr(): RangeExprContext[];
    public rangeExpr(i: number): RangeExprContext | null;
    public rangeExpr(i?: number): RangeExprContext[] | RangeExprContext | null {
        if (i === undefined) {
            return this.getRuleContexts(RangeExprContext);
        }

        return this.getRuleContext(i, RangeExprContext);
    }
    public Kconcat(): antlr.TerminalNode[];
    public Kconcat(i: number): antlr.TerminalNode | null;
    public Kconcat(i?: number): antlr.TerminalNode | null | antlr.TerminalNode[] {
    	if (i === undefined) {
    		return this.getTokens(jsoniqParser.Kconcat);
    	} else {
    		return this.getToken(jsoniqParser.Kconcat, i);
    	}
    }
    public override get ruleIndex(): number {
        return jsoniqParser.RULE_stringConcatExpr;
    }
    public override enterRule(listener: jsoniqListener): void {
        if(listener.enterStringConcatExpr) {
             listener.enterStringConcatExpr(this);
        }
    }
    public override exitRule(listener: jsoniqListener): void {
        if(listener.exitStringConcatExpr) {
             listener.exitStringConcatExpr(this);
        }
    }
}


export class RangeExprContext extends antlr.ParserRuleContext {
    public _main_expr?: AdditiveExprContext;
    public _additiveExpr?: AdditiveExprContext;
    public _rhs: AdditiveExprContext[] = [];
    public constructor(parent: antlr.ParserRuleContext | null, invokingState: number) {
        super(parent, invokingState);
    }
    public additiveExpr(): AdditiveExprContext[];
    public additiveExpr(i: number): AdditiveExprContext | null;
    public additiveExpr(i?: number): AdditiveExprContext[] | AdditiveExprContext | null {
        if (i === undefined) {
            return this.getRuleContexts(AdditiveExprContext);
        }

        return this.getRuleContext(i, AdditiveExprContext);
    }
    public Kto(): antlr.TerminalNode | null {
        return this.getToken(jsoniqParser.Kto, 0);
    }
    public override get ruleIndex(): number {
        return jsoniqParser.RULE_rangeExpr;
    }
    public override enterRule(listener: jsoniqListener): void {
        if(listener.enterRangeExpr) {
             listener.enterRangeExpr(this);
        }
    }
    public override exitRule(listener: jsoniqListener): void {
        if(listener.exitRangeExpr) {
             listener.exitRangeExpr(this);
        }
    }
}


export class AdditiveExprContext extends antlr.ParserRuleContext {
    public _main_expr?: MultiplicativeExprContext;
    public _s46?: Token | null;
    public _op: antlr.Token[] = [];
    public _s47?: Token | null;
    public __tset1986?: Token | null;
    public _multiplicativeExpr?: MultiplicativeExprContext;
    public _rhs: MultiplicativeExprContext[] = [];
    public constructor(parent: antlr.ParserRuleContext | null, invokingState: number) {
        super(parent, invokingState);
    }
    public multiplicativeExpr(): MultiplicativeExprContext[];
    public multiplicativeExpr(i: number): MultiplicativeExprContext | null;
    public multiplicativeExpr(i?: number): MultiplicativeExprContext[] | MultiplicativeExprContext | null {
        if (i === undefined) {
            return this.getRuleContexts(MultiplicativeExprContext);
        }

        return this.getRuleContext(i, MultiplicativeExprContext);
    }
    public Kplus(): antlr.TerminalNode[];
    public Kplus(i: number): antlr.TerminalNode | null;
    public Kplus(i?: number): antlr.TerminalNode | null | antlr.TerminalNode[] {
    	if (i === undefined) {
    		return this.getTokens(jsoniqParser.Kplus);
    	} else {
    		return this.getToken(jsoniqParser.Kplus, i);
    	}
    }
    public Kminus(): antlr.TerminalNode[];
    public Kminus(i: number): antlr.TerminalNode | null;
    public Kminus(i?: number): antlr.TerminalNode | null | antlr.TerminalNode[] {
    	if (i === undefined) {
    		return this.getTokens(jsoniqParser.Kminus);
    	} else {
    		return this.getToken(jsoniqParser.Kminus, i);
    	}
    }
    public override get ruleIndex(): number {
        return jsoniqParser.RULE_additiveExpr;
    }
    public override enterRule(listener: jsoniqListener): void {
        if(listener.enterAdditiveExpr) {
             listener.enterAdditiveExpr(this);
        }
    }
    public override exitRule(listener: jsoniqListener): void {
        if(listener.exitAdditiveExpr) {
             listener.exitAdditiveExpr(this);
        }
    }
}


export class MultiplicativeExprContext extends antlr.ParserRuleContext {
    public _main_expr?: InstanceOfExprContext;
    public _s10?: Token | null;
    public _op: antlr.Token[] = [];
    public _s48?: Token | null;
    public _s49?: Token | null;
    public _s50?: Token | null;
    public __tset2014?: Token | null;
    public _instanceOfExpr?: InstanceOfExprContext;
    public _rhs: InstanceOfExprContext[] = [];
    public constructor(parent: antlr.ParserRuleContext | null, invokingState: number) {
        super(parent, invokingState);
    }
    public instanceOfExpr(): InstanceOfExprContext[];
    public instanceOfExpr(i: number): InstanceOfExprContext | null;
    public instanceOfExpr(i?: number): InstanceOfExprContext[] | InstanceOfExprContext | null {
        if (i === undefined) {
            return this.getRuleContexts(InstanceOfExprContext);
        }

        return this.getRuleContext(i, InstanceOfExprContext);
    }
    public Kasterisk(): antlr.TerminalNode[];
    public Kasterisk(i: number): antlr.TerminalNode | null;
    public Kasterisk(i?: number): antlr.TerminalNode | null | antlr.TerminalNode[] {
    	if (i === undefined) {
    		return this.getTokens(jsoniqParser.Kasterisk);
    	} else {
    		return this.getToken(jsoniqParser.Kasterisk, i);
    	}
    }
    public Kdiv(): antlr.TerminalNode[];
    public Kdiv(i: number): antlr.TerminalNode | null;
    public Kdiv(i?: number): antlr.TerminalNode | null | antlr.TerminalNode[] {
    	if (i === undefined) {
    		return this.getTokens(jsoniqParser.Kdiv);
    	} else {
    		return this.getToken(jsoniqParser.Kdiv, i);
    	}
    }
    public Kidiv(): antlr.TerminalNode[];
    public Kidiv(i: number): antlr.TerminalNode | null;
    public Kidiv(i?: number): antlr.TerminalNode | null | antlr.TerminalNode[] {
    	if (i === undefined) {
    		return this.getTokens(jsoniqParser.Kidiv);
    	} else {
    		return this.getToken(jsoniqParser.Kidiv, i);
    	}
    }
    public Kmod(): antlr.TerminalNode[];
    public Kmod(i: number): antlr.TerminalNode | null;
    public Kmod(i?: number): antlr.TerminalNode | null | antlr.TerminalNode[] {
    	if (i === undefined) {
    		return this.getTokens(jsoniqParser.Kmod);
    	} else {
    		return this.getToken(jsoniqParser.Kmod, i);
    	}
    }
    public override get ruleIndex(): number {
        return jsoniqParser.RULE_multiplicativeExpr;
    }
    public override enterRule(listener: jsoniqListener): void {
        if(listener.enterMultiplicativeExpr) {
             listener.enterMultiplicativeExpr(this);
        }
    }
    public override exitRule(listener: jsoniqListener): void {
        if(listener.exitMultiplicativeExpr) {
             listener.exitMultiplicativeExpr(this);
        }
    }
}


export class InstanceOfExprContext extends antlr.ParserRuleContext {
    public _main_expr?: IsStaticallyExprContext;
    public _seq?: SequenceTypeContext;
    public constructor(parent: antlr.ParserRuleContext | null, invokingState: number) {
        super(parent, invokingState);
    }
    public isStaticallyExpr(): IsStaticallyExprContext {
        return this.getRuleContext(0, IsStaticallyExprContext)!;
    }
    public Kinstance(): antlr.TerminalNode | null {
        return this.getToken(jsoniqParser.Kinstance, 0);
    }
    public Kof(): antlr.TerminalNode | null {
        return this.getToken(jsoniqParser.Kof, 0);
    }
    public sequenceType(): SequenceTypeContext | null {
        return this.getRuleContext(0, SequenceTypeContext);
    }
    public override get ruleIndex(): number {
        return jsoniqParser.RULE_instanceOfExpr;
    }
    public override enterRule(listener: jsoniqListener): void {
        if(listener.enterInstanceOfExpr) {
             listener.enterInstanceOfExpr(this);
        }
    }
    public override exitRule(listener: jsoniqListener): void {
        if(listener.exitInstanceOfExpr) {
             listener.exitInstanceOfExpr(this);
        }
    }
}


export class IsStaticallyExprContext extends antlr.ParserRuleContext {
    public _main_expr?: TreatExprContext;
    public _seq?: SequenceTypeContext;
    public constructor(parent: antlr.ParserRuleContext | null, invokingState: number) {
        super(parent, invokingState);
    }
    public treatExpr(): TreatExprContext {
        return this.getRuleContext(0, TreatExprContext)!;
    }
    public Kis(): antlr.TerminalNode | null {
        return this.getToken(jsoniqParser.Kis, 0);
    }
    public Kstatically(): antlr.TerminalNode | null {
        return this.getToken(jsoniqParser.Kstatically, 0);
    }
    public sequenceType(): SequenceTypeContext | null {
        return this.getRuleContext(0, SequenceTypeContext);
    }
    public override get ruleIndex(): number {
        return jsoniqParser.RULE_isStaticallyExpr;
    }
    public override enterRule(listener: jsoniqListener): void {
        if(listener.enterIsStaticallyExpr) {
             listener.enterIsStaticallyExpr(this);
        }
    }
    public override exitRule(listener: jsoniqListener): void {
        if(listener.exitIsStaticallyExpr) {
             listener.exitIsStaticallyExpr(this);
        }
    }
}


export class TreatExprContext extends antlr.ParserRuleContext {
    public _main_expr?: CastableExprContext;
    public _seq?: SequenceTypeContext;
    public constructor(parent: antlr.ParserRuleContext | null, invokingState: number) {
        super(parent, invokingState);
    }
    public castableExpr(): CastableExprContext {
        return this.getRuleContext(0, CastableExprContext)!;
    }
    public Ktreat(): antlr.TerminalNode | null {
        return this.getToken(jsoniqParser.Ktreat, 0);
    }
    public Kas(): antlr.TerminalNode | null {
        return this.getToken(jsoniqParser.Kas, 0);
    }
    public sequenceType(): SequenceTypeContext | null {
        return this.getRuleContext(0, SequenceTypeContext);
    }
    public override get ruleIndex(): number {
        return jsoniqParser.RULE_treatExpr;
    }
    public override enterRule(listener: jsoniqListener): void {
        if(listener.enterTreatExpr) {
             listener.enterTreatExpr(this);
        }
    }
    public override exitRule(listener: jsoniqListener): void {
        if(listener.exitTreatExpr) {
             listener.exitTreatExpr(this);
        }
    }
}


export class CastableExprContext extends antlr.ParserRuleContext {
    public _main_expr?: CastExprContext;
    public _single?: SingleTypeContext;
    public constructor(parent: antlr.ParserRuleContext | null, invokingState: number) {
        super(parent, invokingState);
    }
    public castExpr(): CastExprContext {
        return this.getRuleContext(0, CastExprContext)!;
    }
    public Kcastable(): antlr.TerminalNode | null {
        return this.getToken(jsoniqParser.Kcastable, 0);
    }
    public Kas(): antlr.TerminalNode | null {
        return this.getToken(jsoniqParser.Kas, 0);
    }
    public singleType(): SingleTypeContext | null {
        return this.getRuleContext(0, SingleTypeContext);
    }
    public override get ruleIndex(): number {
        return jsoniqParser.RULE_castableExpr;
    }
    public override enterRule(listener: jsoniqListener): void {
        if(listener.enterCastableExpr) {
             listener.enterCastableExpr(this);
        }
    }
    public override exitRule(listener: jsoniqListener): void {
        if(listener.exitCastableExpr) {
             listener.exitCastableExpr(this);
        }
    }
}


export class CastExprContext extends antlr.ParserRuleContext {
    public _main_expr?: ArrowExprContext;
    public _single?: SingleTypeContext;
    public constructor(parent: antlr.ParserRuleContext | null, invokingState: number) {
        super(parent, invokingState);
    }
    public arrowExpr(): ArrowExprContext {
        return this.getRuleContext(0, ArrowExprContext)!;
    }
    public Kcast(): antlr.TerminalNode | null {
        return this.getToken(jsoniqParser.Kcast, 0);
    }
    public Kas(): antlr.TerminalNode | null {
        return this.getToken(jsoniqParser.Kas, 0);
    }
    public singleType(): SingleTypeContext | null {
        return this.getRuleContext(0, SingleTypeContext);
    }
    public override get ruleIndex(): number {
        return jsoniqParser.RULE_castExpr;
    }
    public override enterRule(listener: jsoniqListener): void {
        if(listener.enterCastExpr) {
             listener.enterCastExpr(this);
        }
    }
    public override exitRule(listener: jsoniqListener): void {
        if(listener.exitCastExpr) {
             listener.exitCastExpr(this);
        }
    }
}


export class ArrowExprContext extends antlr.ParserRuleContext {
    public _main_expr?: UnaryExprContext;
    public _arrowFunctionSpecifier?: ArrowFunctionSpecifierContext;
    public _function_: ArrowFunctionSpecifierContext[] = [];
    public _argumentList?: ArgumentListContext;
    public _arguments: ArgumentListContext[] = [];
    public constructor(parent: antlr.ParserRuleContext | null, invokingState: number) {
        super(parent, invokingState);
    }
    public unaryExpr(): UnaryExprContext {
        return this.getRuleContext(0, UnaryExprContext)!;
    }
    public arrowFunctionSpecifier(): ArrowFunctionSpecifierContext[];
    public arrowFunctionSpecifier(i: number): ArrowFunctionSpecifierContext | null;
    public arrowFunctionSpecifier(i?: number): ArrowFunctionSpecifierContext[] | ArrowFunctionSpecifierContext | null {
        if (i === undefined) {
            return this.getRuleContexts(ArrowFunctionSpecifierContext);
        }

        return this.getRuleContext(i, ArrowFunctionSpecifierContext);
    }
    public argumentList(): ArgumentListContext[];
    public argumentList(i: number): ArgumentListContext | null;
    public argumentList(i?: number): ArgumentListContext[] | ArgumentListContext | null {
        if (i === undefined) {
            return this.getRuleContexts(ArgumentListContext);
        }

        return this.getRuleContext(i, ArgumentListContext);
    }
    public Kequal(): antlr.TerminalNode[];
    public Kequal(i: number): antlr.TerminalNode | null;
    public Kequal(i?: number): antlr.TerminalNode | null | antlr.TerminalNode[] {
    	if (i === undefined) {
    		return this.getTokens(jsoniqParser.Kequal);
    	} else {
    		return this.getToken(jsoniqParser.Kequal, i);
    	}
    }
    public Kgreater(): antlr.TerminalNode[];
    public Kgreater(i: number): antlr.TerminalNode | null;
    public Kgreater(i?: number): antlr.TerminalNode | null | antlr.TerminalNode[] {
    	if (i === undefined) {
    		return this.getTokens(jsoniqParser.Kgreater);
    	} else {
    		return this.getToken(jsoniqParser.Kgreater, i);
    	}
    }
    public override get ruleIndex(): number {
        return jsoniqParser.RULE_arrowExpr;
    }
    public override enterRule(listener: jsoniqListener): void {
        if(listener.enterArrowExpr) {
             listener.enterArrowExpr(this);
        }
    }
    public override exitRule(listener: jsoniqListener): void {
        if(listener.exitArrowExpr) {
             listener.exitArrowExpr(this);
        }
    }
}


export class ArrowFunctionSpecifierContext extends antlr.ParserRuleContext {
    public constructor(parent: antlr.ParserRuleContext | null, invokingState: number) {
        super(parent, invokingState);
    }
    public qname(): QnameContext | null {
        return this.getRuleContext(0, QnameContext);
    }
    public varRef(): VarRefContext | null {
        return this.getRuleContext(0, VarRefContext);
    }
    public parenthesizedExpr(): ParenthesizedExprContext | null {
        return this.getRuleContext(0, ParenthesizedExprContext);
    }
    public override get ruleIndex(): number {
        return jsoniqParser.RULE_arrowFunctionSpecifier;
    }
    public override enterRule(listener: jsoniqListener): void {
        if(listener.enterArrowFunctionSpecifier) {
             listener.enterArrowFunctionSpecifier(this);
        }
    }
    public override exitRule(listener: jsoniqListener): void {
        if(listener.exitArrowFunctionSpecifier) {
             listener.exitArrowFunctionSpecifier(this);
        }
    }
}


export class UnaryExprContext extends antlr.ParserRuleContext {
    public _s47?: Token | null;
    public _op: antlr.Token[] = [];
    public _s46?: Token | null;
    public __tset2193?: Token | null;
    public _main_expr?: ValueExprContext;
    public constructor(parent: antlr.ParserRuleContext | null, invokingState: number) {
        super(parent, invokingState);
    }
    public valueExpr(): ValueExprContext {
        return this.getRuleContext(0, ValueExprContext)!;
    }
    public Kminus(): antlr.TerminalNode[];
    public Kminus(i: number): antlr.TerminalNode | null;
    public Kminus(i?: number): antlr.TerminalNode | null | antlr.TerminalNode[] {
    	if (i === undefined) {
    		return this.getTokens(jsoniqParser.Kminus);
    	} else {
    		return this.getToken(jsoniqParser.Kminus, i);
    	}
    }
    public Kplus(): antlr.TerminalNode[];
    public Kplus(i: number): antlr.TerminalNode | null;
    public Kplus(i?: number): antlr.TerminalNode | null | antlr.TerminalNode[] {
    	if (i === undefined) {
    		return this.getTokens(jsoniqParser.Kplus);
    	} else {
    		return this.getToken(jsoniqParser.Kplus, i);
    	}
    }
    public override get ruleIndex(): number {
        return jsoniqParser.RULE_unaryExpr;
    }
    public override enterRule(listener: jsoniqListener): void {
        if(listener.enterUnaryExpr) {
             listener.enterUnaryExpr(this);
        }
    }
    public override exitRule(listener: jsoniqListener): void {
        if(listener.exitUnaryExpr) {
             listener.exitUnaryExpr(this);
        }
    }
}


export class ValueExprContext extends antlr.ParserRuleContext {
    public _simpleMap_expr?: SimpleMapExprContext;
    public _validate_expr?: ValidateExprContext;
    public _annotate_expr?: AnnotateExprContext;
    public constructor(parent: antlr.ParserRuleContext | null, invokingState: number) {
        super(parent, invokingState);
    }
    public simpleMapExpr(): SimpleMapExprContext | null {
        return this.getRuleContext(0, SimpleMapExprContext);
    }
    public validateExpr(): ValidateExprContext | null {
        return this.getRuleContext(0, ValidateExprContext);
    }
    public annotateExpr(): AnnotateExprContext | null {
        return this.getRuleContext(0, AnnotateExprContext);
    }
    public override get ruleIndex(): number {
        return jsoniqParser.RULE_valueExpr;
    }
    public override enterRule(listener: jsoniqListener): void {
        if(listener.enterValueExpr) {
             listener.enterValueExpr(this);
        }
    }
    public override exitRule(listener: jsoniqListener): void {
        if(listener.exitValueExpr) {
             listener.exitValueExpr(this);
        }
    }
}


export class ValidateExprContext extends antlr.ParserRuleContext {
    public constructor(parent: antlr.ParserRuleContext | null, invokingState: number) {
        super(parent, invokingState);
    }
    public Kvalidate(): antlr.TerminalNode {
        return this.getToken(jsoniqParser.Kvalidate, 0)!;
    }
    public Ktype(): antlr.TerminalNode {
        return this.getToken(jsoniqParser.Ktype, 0)!;
    }
    public sequenceType(): SequenceTypeContext {
        return this.getRuleContext(0, SequenceTypeContext)!;
    }
    public Klbrace(): antlr.TerminalNode {
        return this.getToken(jsoniqParser.Klbrace, 0)!;
    }
    public expr(): ExprContext {
        return this.getRuleContext(0, ExprContext)!;
    }
    public Krbrace(): antlr.TerminalNode {
        return this.getToken(jsoniqParser.Krbrace, 0)!;
    }
    public override get ruleIndex(): number {
        return jsoniqParser.RULE_validateExpr;
    }
    public override enterRule(listener: jsoniqListener): void {
        if(listener.enterValidateExpr) {
             listener.enterValidateExpr(this);
        }
    }
    public override exitRule(listener: jsoniqListener): void {
        if(listener.exitValidateExpr) {
             listener.exitValidateExpr(this);
        }
    }
}


export class AnnotateExprContext extends antlr.ParserRuleContext {
    public constructor(parent: antlr.ParserRuleContext | null, invokingState: number) {
        super(parent, invokingState);
    }
    public Kannotate(): antlr.TerminalNode {
        return this.getToken(jsoniqParser.Kannotate, 0)!;
    }
    public Ktype(): antlr.TerminalNode {
        return this.getToken(jsoniqParser.Ktype, 0)!;
    }
    public sequenceType(): SequenceTypeContext {
        return this.getRuleContext(0, SequenceTypeContext)!;
    }
    public Klbrace(): antlr.TerminalNode {
        return this.getToken(jsoniqParser.Klbrace, 0)!;
    }
    public expr(): ExprContext {
        return this.getRuleContext(0, ExprContext)!;
    }
    public Krbrace(): antlr.TerminalNode {
        return this.getToken(jsoniqParser.Krbrace, 0)!;
    }
    public override get ruleIndex(): number {
        return jsoniqParser.RULE_annotateExpr;
    }
    public override enterRule(listener: jsoniqListener): void {
        if(listener.enterAnnotateExpr) {
             listener.enterAnnotateExpr(this);
        }
    }
    public override exitRule(listener: jsoniqListener): void {
        if(listener.exitAnnotateExpr) {
             listener.exitAnnotateExpr(this);
        }
    }
}


export class SimpleMapExprContext extends antlr.ParserRuleContext {
    public _main_expr?: PathExprContext;
    public _pathExpr?: PathExprContext;
    public _map_expr: PathExprContext[] = [];
    public constructor(parent: antlr.ParserRuleContext | null, invokingState: number) {
        super(parent, invokingState);
    }
    public pathExpr(): PathExprContext[];
    public pathExpr(i: number): PathExprContext | null;
    public pathExpr(i?: number): PathExprContext[] | PathExprContext | null {
        if (i === undefined) {
            return this.getRuleContexts(PathExprContext);
        }

        return this.getRuleContext(i, PathExprContext);
    }
    public Kbang(): antlr.TerminalNode[];
    public Kbang(i: number): antlr.TerminalNode | null;
    public Kbang(i?: number): antlr.TerminalNode | null | antlr.TerminalNode[] {
    	if (i === undefined) {
    		return this.getTokens(jsoniqParser.Kbang);
    	} else {
    		return this.getToken(jsoniqParser.Kbang, i);
    	}
    }
    public override get ruleIndex(): number {
        return jsoniqParser.RULE_simpleMapExpr;
    }
    public override enterRule(listener: jsoniqListener): void {
        if(listener.enterSimpleMapExpr) {
             listener.enterSimpleMapExpr(this);
        }
    }
    public override exitRule(listener: jsoniqListener): void {
        if(listener.exitSimpleMapExpr) {
             listener.exitSimpleMapExpr(this);
        }
    }
}


export class PostFixExprContext extends antlr.ParserRuleContext {
    public _main_expr?: PrimaryExprContext;
    public constructor(parent: antlr.ParserRuleContext | null, invokingState: number) {
        super(parent, invokingState);
    }
    public primaryExpr(): PrimaryExprContext {
        return this.getRuleContext(0, PrimaryExprContext)!;
    }
    public arrayLookup(): ArrayLookupContext[];
    public arrayLookup(i: number): ArrayLookupContext | null;
    public arrayLookup(i?: number): ArrayLookupContext[] | ArrayLookupContext | null {
        if (i === undefined) {
            return this.getRuleContexts(ArrayLookupContext);
        }

        return this.getRuleContext(i, ArrayLookupContext);
    }
    public predicate(): PredicateContext[];
    public predicate(i: number): PredicateContext | null;
    public predicate(i?: number): PredicateContext[] | PredicateContext | null {
        if (i === undefined) {
            return this.getRuleContexts(PredicateContext);
        }

        return this.getRuleContext(i, PredicateContext);
    }
    public objectLookup(): ObjectLookupContext[];
    public objectLookup(i: number): ObjectLookupContext | null;
    public objectLookup(i?: number): ObjectLookupContext[] | ObjectLookupContext | null {
        if (i === undefined) {
            return this.getRuleContexts(ObjectLookupContext);
        }

        return this.getRuleContext(i, ObjectLookupContext);
    }
    public arrayUnboxing(): ArrayUnboxingContext[];
    public arrayUnboxing(i: number): ArrayUnboxingContext | null;
    public arrayUnboxing(i?: number): ArrayUnboxingContext[] | ArrayUnboxingContext | null {
        if (i === undefined) {
            return this.getRuleContexts(ArrayUnboxingContext);
        }

        return this.getRuleContext(i, ArrayUnboxingContext);
    }
    public argumentList(): ArgumentListContext[];
    public argumentList(i: number): ArgumentListContext | null;
    public argumentList(i?: number): ArgumentListContext[] | ArgumentListContext | null {
        if (i === undefined) {
            return this.getRuleContexts(ArgumentListContext);
        }

        return this.getRuleContext(i, ArgumentListContext);
    }
    public override get ruleIndex(): number {
        return jsoniqParser.RULE_postFixExpr;
    }
    public override enterRule(listener: jsoniqListener): void {
        if(listener.enterPostFixExpr) {
             listener.enterPostFixExpr(this);
        }
    }
    public override exitRule(listener: jsoniqListener): void {
        if(listener.exitPostFixExpr) {
             listener.exitPostFixExpr(this);
        }
    }
}


export class ArrayLookupContext extends antlr.ParserRuleContext {
    public constructor(parent: antlr.ParserRuleContext | null, invokingState: number) {
        super(parent, invokingState);
    }
    public Klbracket(): antlr.TerminalNode[];
    public Klbracket(i: number): antlr.TerminalNode | null;
    public Klbracket(i?: number): antlr.TerminalNode | null | antlr.TerminalNode[] {
    	if (i === undefined) {
    		return this.getTokens(jsoniqParser.Klbracket);
    	} else {
    		return this.getToken(jsoniqParser.Klbracket, i);
    	}
    }
    public expr(): ExprContext {
        return this.getRuleContext(0, ExprContext)!;
    }
    public Krbracket(): antlr.TerminalNode[];
    public Krbracket(i: number): antlr.TerminalNode | null;
    public Krbracket(i?: number): antlr.TerminalNode | null | antlr.TerminalNode[] {
    	if (i === undefined) {
    		return this.getTokens(jsoniqParser.Krbracket);
    	} else {
    		return this.getToken(jsoniqParser.Krbracket, i);
    	}
    }
    public override get ruleIndex(): number {
        return jsoniqParser.RULE_arrayLookup;
    }
    public override enterRule(listener: jsoniqListener): void {
        if(listener.enterArrayLookup) {
             listener.enterArrayLookup(this);
        }
    }
    public override exitRule(listener: jsoniqListener): void {
        if(listener.exitArrayLookup) {
             listener.exitArrayLookup(this);
        }
    }
}


export class ArrayUnboxingContext extends antlr.ParserRuleContext {
    public constructor(parent: antlr.ParserRuleContext | null, invokingState: number) {
        super(parent, invokingState);
    }
    public Klbracket(): antlr.TerminalNode {
        return this.getToken(jsoniqParser.Klbracket, 0)!;
    }
    public Krbracket(): antlr.TerminalNode {
        return this.getToken(jsoniqParser.Krbracket, 0)!;
    }
    public override get ruleIndex(): number {
        return jsoniqParser.RULE_arrayUnboxing;
    }
    public override enterRule(listener: jsoniqListener): void {
        if(listener.enterArrayUnboxing) {
             listener.enterArrayUnboxing(this);
        }
    }
    public override exitRule(listener: jsoniqListener): void {
        if(listener.exitArrayUnboxing) {
             listener.exitArrayUnboxing(this);
        }
    }
}


export class PredicateContext extends antlr.ParserRuleContext {
    public constructor(parent: antlr.ParserRuleContext | null, invokingState: number) {
        super(parent, invokingState);
    }
    public Klbracket(): antlr.TerminalNode {
        return this.getToken(jsoniqParser.Klbracket, 0)!;
    }
    public expr(): ExprContext {
        return this.getRuleContext(0, ExprContext)!;
    }
    public Krbracket(): antlr.TerminalNode {
        return this.getToken(jsoniqParser.Krbracket, 0)!;
    }
    public override get ruleIndex(): number {
        return jsoniqParser.RULE_predicate;
    }
    public override enterRule(listener: jsoniqListener): void {
        if(listener.enterPredicate) {
             listener.enterPredicate(this);
        }
    }
    public override exitRule(listener: jsoniqListener): void {
        if(listener.exitPredicate) {
             listener.exitPredicate(this);
        }
    }
}


export class ObjectLookupContext extends antlr.ParserRuleContext {
    public _kw?: KeyWordsContext;
    public _lt?: StringLiteralContext;
    public _nc?: Token | null;
    public _pe?: ParenthesizedExprContext;
    public _vr?: VarRefContext;
    public _ci?: ContextItemExprContext;
    public constructor(parent: antlr.ParserRuleContext | null, invokingState: number) {
        super(parent, invokingState);
    }
    public Kdot(): antlr.TerminalNode {
        return this.getToken(jsoniqParser.Kdot, 0)!;
    }
    public keyWords(): KeyWordsContext | null {
        return this.getRuleContext(0, KeyWordsContext);
    }
    public stringLiteral(): StringLiteralContext | null {
        return this.getRuleContext(0, StringLiteralContext);
    }
    public NCName(): antlr.TerminalNode | null {
        return this.getToken(jsoniqParser.NCName, 0);
    }
    public parenthesizedExpr(): ParenthesizedExprContext | null {
        return this.getRuleContext(0, ParenthesizedExprContext);
    }
    public varRef(): VarRefContext | null {
        return this.getRuleContext(0, VarRefContext);
    }
    public contextItemExpr(): ContextItemExprContext | null {
        return this.getRuleContext(0, ContextItemExprContext);
    }
    public override get ruleIndex(): number {
        return jsoniqParser.RULE_objectLookup;
    }
    public override enterRule(listener: jsoniqListener): void {
        if(listener.enterObjectLookup) {
             listener.enterObjectLookup(this);
        }
    }
    public override exitRule(listener: jsoniqListener): void {
        if(listener.exitObjectLookup) {
             listener.exitObjectLookup(this);
        }
    }
}


export class PrimaryExprContext extends antlr.ParserRuleContext {
    public constructor(parent: antlr.ParserRuleContext | null, invokingState: number) {
        super(parent, invokingState);
    }
    public NullLiteral(): antlr.TerminalNode | null {
        return this.getToken(jsoniqParser.NullLiteral, 0);
    }
    public Ktrue(): antlr.TerminalNode | null {
        return this.getToken(jsoniqParser.Ktrue, 0);
    }
    public Kfalse(): antlr.TerminalNode | null {
        return this.getToken(jsoniqParser.Kfalse, 0);
    }
    public Literal(): antlr.TerminalNode | null {
        return this.getToken(jsoniqParser.Literal, 0);
    }
    public stringLiteral(): StringLiteralContext | null {
        return this.getRuleContext(0, StringLiteralContext);
    }
    public varRef(): VarRefContext | null {
        return this.getRuleContext(0, VarRefContext);
    }
    public parenthesizedExpr(): ParenthesizedExprContext | null {
        return this.getRuleContext(0, ParenthesizedExprContext);
    }
    public contextItemExpr(): ContextItemExprContext | null {
        return this.getRuleContext(0, ContextItemExprContext);
    }
    public objectConstructor(): ObjectConstructorContext | null {
        return this.getRuleContext(0, ObjectConstructorContext);
    }
    public functionCall(): FunctionCallContext | null {
        return this.getRuleContext(0, FunctionCallContext);
    }
    public orderedExpr(): OrderedExprContext | null {
        return this.getRuleContext(0, OrderedExprContext);
    }
    public unorderedExpr(): UnorderedExprContext | null {
        return this.getRuleContext(0, UnorderedExprContext);
    }
    public arrayConstructor(): ArrayConstructorContext | null {
        return this.getRuleContext(0, ArrayConstructorContext);
    }
    public functionItemExpr(): FunctionItemExprContext | null {
        return this.getRuleContext(0, FunctionItemExprContext);
    }
    public blockExpr(): BlockExprContext | null {
        return this.getRuleContext(0, BlockExprContext);
    }
    public override get ruleIndex(): number {
        return jsoniqParser.RULE_primaryExpr;
    }
    public override enterRule(listener: jsoniqListener): void {
        if(listener.enterPrimaryExpr) {
             listener.enterPrimaryExpr(this);
        }
    }
    public override exitRule(listener: jsoniqListener): void {
        if(listener.exitPrimaryExpr) {
             listener.exitPrimaryExpr(this);
        }
    }
}


export class BlockExprContext extends antlr.ParserRuleContext {
    public constructor(parent: antlr.ParserRuleContext | null, invokingState: number) {
        super(parent, invokingState);
    }
    public Klbrace(): antlr.TerminalNode {
        return this.getToken(jsoniqParser.Klbrace, 0)!;
    }
    public statementsAndExpr(): StatementsAndExprContext {
        return this.getRuleContext(0, StatementsAndExprContext)!;
    }
    public Krbrace(): antlr.TerminalNode {
        return this.getToken(jsoniqParser.Krbrace, 0)!;
    }
    public override get ruleIndex(): number {
        return jsoniqParser.RULE_blockExpr;
    }
    public override enterRule(listener: jsoniqListener): void {
        if(listener.enterBlockExpr) {
             listener.enterBlockExpr(this);
        }
    }
    public override exitRule(listener: jsoniqListener): void {
        if(listener.exitBlockExpr) {
             listener.exitBlockExpr(this);
        }
    }
}


export class VarRefContext extends antlr.ParserRuleContext {
    public _var_name?: QnameContext;
    public constructor(parent: antlr.ParserRuleContext | null, invokingState: number) {
        super(parent, invokingState);
    }
    public Kdollar(): antlr.TerminalNode {
        return this.getToken(jsoniqParser.Kdollar, 0)!;
    }
    public qname(): QnameContext {
        return this.getRuleContext(0, QnameContext)!;
    }
    public override get ruleIndex(): number {
        return jsoniqParser.RULE_varRef;
    }
    public override enterRule(listener: jsoniqListener): void {
        if(listener.enterVarRef) {
             listener.enterVarRef(this);
        }
    }
    public override exitRule(listener: jsoniqListener): void {
        if(listener.exitVarRef) {
             listener.exitVarRef(this);
        }
    }
}


export class ParenthesizedExprContext extends antlr.ParserRuleContext {
    public constructor(parent: antlr.ParserRuleContext | null, invokingState: number) {
        super(parent, invokingState);
    }
    public Klparen(): antlr.TerminalNode {
        return this.getToken(jsoniqParser.Klparen, 0)!;
    }
    public Krparen(): antlr.TerminalNode {
        return this.getToken(jsoniqParser.Krparen, 0)!;
    }
    public expr(): ExprContext | null {
        return this.getRuleContext(0, ExprContext);
    }
    public override get ruleIndex(): number {
        return jsoniqParser.RULE_parenthesizedExpr;
    }
    public override enterRule(listener: jsoniqListener): void {
        if(listener.enterParenthesizedExpr) {
             listener.enterParenthesizedExpr(this);
        }
    }
    public override exitRule(listener: jsoniqListener): void {
        if(listener.exitParenthesizedExpr) {
             listener.exitParenthesizedExpr(this);
        }
    }
}


export class ContextItemExprContext extends antlr.ParserRuleContext {
    public constructor(parent: antlr.ParserRuleContext | null, invokingState: number) {
        super(parent, invokingState);
    }
    public Kcontext_item(): antlr.TerminalNode {
        return this.getToken(jsoniqParser.Kcontext_item, 0)!;
    }
    public override get ruleIndex(): number {
        return jsoniqParser.RULE_contextItemExpr;
    }
    public override enterRule(listener: jsoniqListener): void {
        if(listener.enterContextItemExpr) {
             listener.enterContextItemExpr(this);
        }
    }
    public override exitRule(listener: jsoniqListener): void {
        if(listener.exitContextItemExpr) {
             listener.exitContextItemExpr(this);
        }
    }
}


export class OrderedExprContext extends antlr.ParserRuleContext {
    public constructor(parent: antlr.ParserRuleContext | null, invokingState: number) {
        super(parent, invokingState);
    }
    public Kordered(): antlr.TerminalNode {
        return this.getToken(jsoniqParser.Kordered, 0)!;
    }
    public Klbrace(): antlr.TerminalNode {
        return this.getToken(jsoniqParser.Klbrace, 0)!;
    }
    public expr(): ExprContext {
        return this.getRuleContext(0, ExprContext)!;
    }
    public Krbrace(): antlr.TerminalNode {
        return this.getToken(jsoniqParser.Krbrace, 0)!;
    }
    public override get ruleIndex(): number {
        return jsoniqParser.RULE_orderedExpr;
    }
    public override enterRule(listener: jsoniqListener): void {
        if(listener.enterOrderedExpr) {
             listener.enterOrderedExpr(this);
        }
    }
    public override exitRule(listener: jsoniqListener): void {
        if(listener.exitOrderedExpr) {
             listener.exitOrderedExpr(this);
        }
    }
}


export class UnorderedExprContext extends antlr.ParserRuleContext {
    public constructor(parent: antlr.ParserRuleContext | null, invokingState: number) {
        super(parent, invokingState);
    }
    public Kunordered(): antlr.TerminalNode {
        return this.getToken(jsoniqParser.Kunordered, 0)!;
    }
    public Klbrace(): antlr.TerminalNode {
        return this.getToken(jsoniqParser.Klbrace, 0)!;
    }
    public expr(): ExprContext {
        return this.getRuleContext(0, ExprContext)!;
    }
    public Krbrace(): antlr.TerminalNode {
        return this.getToken(jsoniqParser.Krbrace, 0)!;
    }
    public override get ruleIndex(): number {
        return jsoniqParser.RULE_unorderedExpr;
    }
    public override enterRule(listener: jsoniqListener): void {
        if(listener.enterUnorderedExpr) {
             listener.enterUnorderedExpr(this);
        }
    }
    public override exitRule(listener: jsoniqListener): void {
        if(listener.exitUnorderedExpr) {
             listener.exitUnorderedExpr(this);
        }
    }
}


export class FunctionCallContext extends antlr.ParserRuleContext {
    public _fn_name?: QnameContext;
    public constructor(parent: antlr.ParserRuleContext | null, invokingState: number) {
        super(parent, invokingState);
    }
    public argumentList(): ArgumentListContext {
        return this.getRuleContext(0, ArgumentListContext)!;
    }
    public qname(): QnameContext {
        return this.getRuleContext(0, QnameContext)!;
    }
    public override get ruleIndex(): number {
        return jsoniqParser.RULE_functionCall;
    }
    public override enterRule(listener: jsoniqListener): void {
        if(listener.enterFunctionCall) {
             listener.enterFunctionCall(this);
        }
    }
    public override exitRule(listener: jsoniqListener): void {
        if(listener.exitFunctionCall) {
             listener.exitFunctionCall(this);
        }
    }
}


export class ArgumentListContext extends antlr.ParserRuleContext {
    public _argument?: ArgumentContext;
    public _args: ArgumentContext[] = [];
    public constructor(parent: antlr.ParserRuleContext | null, invokingState: number) {
        super(parent, invokingState);
    }
    public Klparen(): antlr.TerminalNode {
        return this.getToken(jsoniqParser.Klparen, 0)!;
    }
    public Krparen(): antlr.TerminalNode {
        return this.getToken(jsoniqParser.Krparen, 0)!;
    }
    public argument(): ArgumentContext[];
    public argument(i: number): ArgumentContext | null;
    public argument(i?: number): ArgumentContext[] | ArgumentContext | null {
        if (i === undefined) {
            return this.getRuleContexts(ArgumentContext);
        }

        return this.getRuleContext(i, ArgumentContext);
    }
    public Kcomma(): antlr.TerminalNode[];
    public Kcomma(i: number): antlr.TerminalNode | null;
    public Kcomma(i?: number): antlr.TerminalNode | null | antlr.TerminalNode[] {
    	if (i === undefined) {
    		return this.getTokens(jsoniqParser.Kcomma);
    	} else {
    		return this.getToken(jsoniqParser.Kcomma, i);
    	}
    }
    public override get ruleIndex(): number {
        return jsoniqParser.RULE_argumentList;
    }
    public override enterRule(listener: jsoniqListener): void {
        if(listener.enterArgumentList) {
             listener.enterArgumentList(this);
        }
    }
    public override exitRule(listener: jsoniqListener): void {
        if(listener.exitArgumentList) {
             listener.exitArgumentList(this);
        }
    }
}


export class ArgumentContext extends antlr.ParserRuleContext {
    public constructor(parent: antlr.ParserRuleContext | null, invokingState: number) {
        super(parent, invokingState);
    }
    public exprSingle(): ExprSingleContext | null {
        return this.getRuleContext(0, ExprSingleContext);
    }
    public ArgumentPlaceholder(): antlr.TerminalNode | null {
        return this.getToken(jsoniqParser.ArgumentPlaceholder, 0);
    }
    public override get ruleIndex(): number {
        return jsoniqParser.RULE_argument;
    }
    public override enterRule(listener: jsoniqListener): void {
        if(listener.enterArgument) {
             listener.enterArgument(this);
        }
    }
    public override exitRule(listener: jsoniqListener): void {
        if(listener.exitArgument) {
             listener.exitArgument(this);
        }
    }
}


export class FunctionItemExprContext extends antlr.ParserRuleContext {
    public constructor(parent: antlr.ParserRuleContext | null, invokingState: number) {
        super(parent, invokingState);
    }
    public namedFunctionRef(): NamedFunctionRefContext | null {
        return this.getRuleContext(0, NamedFunctionRefContext);
    }
    public inlineFunctionExpr(): InlineFunctionExprContext | null {
        return this.getRuleContext(0, InlineFunctionExprContext);
    }
    public override get ruleIndex(): number {
        return jsoniqParser.RULE_functionItemExpr;
    }
    public override enterRule(listener: jsoniqListener): void {
        if(listener.enterFunctionItemExpr) {
             listener.enterFunctionItemExpr(this);
        }
    }
    public override exitRule(listener: jsoniqListener): void {
        if(listener.exitFunctionItemExpr) {
             listener.exitFunctionItemExpr(this);
        }
    }
}


export class NamedFunctionRefContext extends antlr.ParserRuleContext {
    public _fn_name?: QnameContext;
    public _arity?: Token | null;
    public constructor(parent: antlr.ParserRuleContext | null, invokingState: number) {
        super(parent, invokingState);
    }
    public Khash(): antlr.TerminalNode {
        return this.getToken(jsoniqParser.Khash, 0)!;
    }
    public qname(): QnameContext {
        return this.getRuleContext(0, QnameContext)!;
    }
    public Literal(): antlr.TerminalNode {
        return this.getToken(jsoniqParser.Literal, 0)!;
    }
    public override get ruleIndex(): number {
        return jsoniqParser.RULE_namedFunctionRef;
    }
    public override enterRule(listener: jsoniqListener): void {
        if(listener.enterNamedFunctionRef) {
             listener.enterNamedFunctionRef(this);
        }
    }
    public override exitRule(listener: jsoniqListener): void {
        if(listener.exitNamedFunctionRef) {
             listener.exitNamedFunctionRef(this);
        }
    }
}


export class InlineFunctionExprContext extends antlr.ParserRuleContext {
    public _return_type?: SequenceTypeContext;
    public _fn_body?: StatementsAndOptionalExprContext;
    public constructor(parent: antlr.ParserRuleContext | null, invokingState: number) {
        super(parent, invokingState);
    }
    public annotations(): AnnotationsContext {
        return this.getRuleContext(0, AnnotationsContext)!;
    }
    public Kfunction(): antlr.TerminalNode {
        return this.getToken(jsoniqParser.Kfunction, 0)!;
    }
    public Klparen(): antlr.TerminalNode {
        return this.getToken(jsoniqParser.Klparen, 0)!;
    }
    public Krparen(): antlr.TerminalNode {
        return this.getToken(jsoniqParser.Krparen, 0)!;
    }
    public Klbrace(): antlr.TerminalNode | null {
        return this.getToken(jsoniqParser.Klbrace, 0);
    }
    public Krbrace(): antlr.TerminalNode | null {
        return this.getToken(jsoniqParser.Krbrace, 0);
    }
    public paramList(): ParamListContext | null {
        return this.getRuleContext(0, ParamListContext);
    }
    public Kas(): antlr.TerminalNode | null {
        return this.getToken(jsoniqParser.Kas, 0);
    }
    public sequenceType(): SequenceTypeContext | null {
        return this.getRuleContext(0, SequenceTypeContext);
    }
    public statementsAndOptionalExpr(): StatementsAndOptionalExprContext | null {
        return this.getRuleContext(0, StatementsAndOptionalExprContext);
    }
    public override get ruleIndex(): number {
        return jsoniqParser.RULE_inlineFunctionExpr;
    }
    public override enterRule(listener: jsoniqListener): void {
        if(listener.enterInlineFunctionExpr) {
             listener.enterInlineFunctionExpr(this);
        }
    }
    public override exitRule(listener: jsoniqListener): void {
        if(listener.exitInlineFunctionExpr) {
             listener.exitInlineFunctionExpr(this);
        }
    }
}


export class InsertExprContext extends antlr.ParserRuleContext {
    public _to_insert_expr?: ExprSingleContext;
    public _main_expr?: ExprSingleContext;
    public _pos_expr?: ExprSingleContext;
    public constructor(parent: antlr.ParserRuleContext | null, invokingState: number) {
        super(parent, invokingState);
    }
    public Kinsert(): antlr.TerminalNode {
        return this.getToken(jsoniqParser.Kinsert, 0)!;
    }
    public Kjson(): antlr.TerminalNode {
        return this.getToken(jsoniqParser.Kjson, 0)!;
    }
    public Kinto(): antlr.TerminalNode {
        return this.getToken(jsoniqParser.Kinto, 0)!;
    }
    public exprSingle(): ExprSingleContext[];
    public exprSingle(i: number): ExprSingleContext | null;
    public exprSingle(i?: number): ExprSingleContext[] | ExprSingleContext | null {
        if (i === undefined) {
            return this.getRuleContexts(ExprSingleContext);
        }

        return this.getRuleContext(i, ExprSingleContext);
    }
    public Kat(): antlr.TerminalNode | null {
        return this.getToken(jsoniqParser.Kat, 0);
    }
    public Kposition(): antlr.TerminalNode | null {
        return this.getToken(jsoniqParser.Kposition, 0);
    }
    public pairConstructor(): PairConstructorContext[];
    public pairConstructor(i: number): PairConstructorContext | null;
    public pairConstructor(i?: number): PairConstructorContext[] | PairConstructorContext | null {
        if (i === undefined) {
            return this.getRuleContexts(PairConstructorContext);
        }

        return this.getRuleContext(i, PairConstructorContext);
    }
    public Kcomma(): antlr.TerminalNode[];
    public Kcomma(i: number): antlr.TerminalNode | null;
    public Kcomma(i?: number): antlr.TerminalNode | null | antlr.TerminalNode[] {
    	if (i === undefined) {
    		return this.getTokens(jsoniqParser.Kcomma);
    	} else {
    		return this.getToken(jsoniqParser.Kcomma, i);
    	}
    }
    public override get ruleIndex(): number {
        return jsoniqParser.RULE_insertExpr;
    }
    public override enterRule(listener: jsoniqListener): void {
        if(listener.enterInsertExpr) {
             listener.enterInsertExpr(this);
        }
    }
    public override exitRule(listener: jsoniqListener): void {
        if(listener.exitInsertExpr) {
             listener.exitInsertExpr(this);
        }
    }
}


export class DeleteExprContext extends antlr.ParserRuleContext {
    public constructor(parent: antlr.ParserRuleContext | null, invokingState: number) {
        super(parent, invokingState);
    }
    public Kdelete(): antlr.TerminalNode {
        return this.getToken(jsoniqParser.Kdelete, 0)!;
    }
    public Kjson(): antlr.TerminalNode {
        return this.getToken(jsoniqParser.Kjson, 0)!;
    }
    public updateLocator(): UpdateLocatorContext {
        return this.getRuleContext(0, UpdateLocatorContext)!;
    }
    public override get ruleIndex(): number {
        return jsoniqParser.RULE_deleteExpr;
    }
    public override enterRule(listener: jsoniqListener): void {
        if(listener.enterDeleteExpr) {
             listener.enterDeleteExpr(this);
        }
    }
    public override exitRule(listener: jsoniqListener): void {
        if(listener.exitDeleteExpr) {
             listener.exitDeleteExpr(this);
        }
    }
}


export class RenameExprContext extends antlr.ParserRuleContext {
    public _name_expr?: ExprSingleContext;
    public constructor(parent: antlr.ParserRuleContext | null, invokingState: number) {
        super(parent, invokingState);
    }
    public Krename(): antlr.TerminalNode {
        return this.getToken(jsoniqParser.Krename, 0)!;
    }
    public Kjson(): antlr.TerminalNode {
        return this.getToken(jsoniqParser.Kjson, 0)!;
    }
    public updateLocator(): UpdateLocatorContext {
        return this.getRuleContext(0, UpdateLocatorContext)!;
    }
    public Kas(): antlr.TerminalNode {
        return this.getToken(jsoniqParser.Kas, 0)!;
    }
    public exprSingle(): ExprSingleContext {
        return this.getRuleContext(0, ExprSingleContext)!;
    }
    public override get ruleIndex(): number {
        return jsoniqParser.RULE_renameExpr;
    }
    public override enterRule(listener: jsoniqListener): void {
        if(listener.enterRenameExpr) {
             listener.enterRenameExpr(this);
        }
    }
    public override exitRule(listener: jsoniqListener): void {
        if(listener.exitRenameExpr) {
             listener.exitRenameExpr(this);
        }
    }
}


export class ReplaceExprContext extends antlr.ParserRuleContext {
    public _replacer_expr?: ExprSingleContext;
    public constructor(parent: antlr.ParserRuleContext | null, invokingState: number) {
        super(parent, invokingState);
    }
    public Kreplace(): antlr.TerminalNode {
        return this.getToken(jsoniqParser.Kreplace, 0)!;
    }
    public Kvalue(): antlr.TerminalNode {
        return this.getToken(jsoniqParser.Kvalue, 0)!;
    }
    public Kof(): antlr.TerminalNode {
        return this.getToken(jsoniqParser.Kof, 0)!;
    }
    public Kjson(): antlr.TerminalNode {
        return this.getToken(jsoniqParser.Kjson, 0)!;
    }
    public updateLocator(): UpdateLocatorContext {
        return this.getRuleContext(0, UpdateLocatorContext)!;
    }
    public Kwith(): antlr.TerminalNode {
        return this.getToken(jsoniqParser.Kwith, 0)!;
    }
    public exprSingle(): ExprSingleContext {
        return this.getRuleContext(0, ExprSingleContext)!;
    }
    public override get ruleIndex(): number {
        return jsoniqParser.RULE_replaceExpr;
    }
    public override enterRule(listener: jsoniqListener): void {
        if(listener.enterReplaceExpr) {
             listener.enterReplaceExpr(this);
        }
    }
    public override exitRule(listener: jsoniqListener): void {
        if(listener.exitReplaceExpr) {
             listener.exitReplaceExpr(this);
        }
    }
}


export class TransformExprContext extends antlr.ParserRuleContext {
    public _mod_expr?: ExprSingleContext;
    public _ret_expr?: ExprSingleContext;
    public constructor(parent: antlr.ParserRuleContext | null, invokingState: number) {
        super(parent, invokingState);
    }
    public Kcopy(): antlr.TerminalNode {
        return this.getToken(jsoniqParser.Kcopy, 0)!;
    }
    public copyDecl(): CopyDeclContext[];
    public copyDecl(i: number): CopyDeclContext | null;
    public copyDecl(i?: number): CopyDeclContext[] | CopyDeclContext | null {
        if (i === undefined) {
            return this.getRuleContexts(CopyDeclContext);
        }

        return this.getRuleContext(i, CopyDeclContext);
    }
    public Kmodify(): antlr.TerminalNode {
        return this.getToken(jsoniqParser.Kmodify, 0)!;
    }
    public Kreturn(): antlr.TerminalNode {
        return this.getToken(jsoniqParser.Kreturn, 0)!;
    }
    public exprSingle(): ExprSingleContext[];
    public exprSingle(i: number): ExprSingleContext | null;
    public exprSingle(i?: number): ExprSingleContext[] | ExprSingleContext | null {
        if (i === undefined) {
            return this.getRuleContexts(ExprSingleContext);
        }

        return this.getRuleContext(i, ExprSingleContext);
    }
    public Kcomma(): antlr.TerminalNode[];
    public Kcomma(i: number): antlr.TerminalNode | null;
    public Kcomma(i?: number): antlr.TerminalNode | null | antlr.TerminalNode[] {
    	if (i === undefined) {
    		return this.getTokens(jsoniqParser.Kcomma);
    	} else {
    		return this.getToken(jsoniqParser.Kcomma, i);
    	}
    }
    public override get ruleIndex(): number {
        return jsoniqParser.RULE_transformExpr;
    }
    public override enterRule(listener: jsoniqListener): void {
        if(listener.enterTransformExpr) {
             listener.enterTransformExpr(this);
        }
    }
    public override exitRule(listener: jsoniqListener): void {
        if(listener.exitTransformExpr) {
             listener.exitTransformExpr(this);
        }
    }
}


export class AppendExprContext extends antlr.ParserRuleContext {
    public _to_append_expr?: ExprSingleContext;
    public _array_expr?: ExprSingleContext;
    public constructor(parent: antlr.ParserRuleContext | null, invokingState: number) {
        super(parent, invokingState);
    }
    public Kappend(): antlr.TerminalNode {
        return this.getToken(jsoniqParser.Kappend, 0)!;
    }
    public Kjson(): antlr.TerminalNode {
        return this.getToken(jsoniqParser.Kjson, 0)!;
    }
    public Kinto(): antlr.TerminalNode {
        return this.getToken(jsoniqParser.Kinto, 0)!;
    }
    public exprSingle(): ExprSingleContext[];
    public exprSingle(i: number): ExprSingleContext | null;
    public exprSingle(i?: number): ExprSingleContext[] | ExprSingleContext | null {
        if (i === undefined) {
            return this.getRuleContexts(ExprSingleContext);
        }

        return this.getRuleContext(i, ExprSingleContext);
    }
    public override get ruleIndex(): number {
        return jsoniqParser.RULE_appendExpr;
    }
    public override enterRule(listener: jsoniqListener): void {
        if(listener.enterAppendExpr) {
             listener.enterAppendExpr(this);
        }
    }
    public override exitRule(listener: jsoniqListener): void {
        if(listener.exitAppendExpr) {
             listener.exitAppendExpr(this);
        }
    }
}


export class UpdateLocatorContext extends antlr.ParserRuleContext {
    public _main_expr?: PostFixExprContext;
    public constructor(parent: antlr.ParserRuleContext | null, invokingState: number) {
        super(parent, invokingState);
    }
    public postFixExpr(): PostFixExprContext {
        return this.getRuleContext(0, PostFixExprContext)!;
    }
    public override get ruleIndex(): number {
        return jsoniqParser.RULE_updateLocator;
    }
    public override enterRule(listener: jsoniqListener): void {
        if(listener.enterUpdateLocator) {
             listener.enterUpdateLocator(this);
        }
    }
    public override exitRule(listener: jsoniqListener): void {
        if(listener.exitUpdateLocator) {
             listener.exitUpdateLocator(this);
        }
    }
}


export class CopyDeclContext extends antlr.ParserRuleContext {
    public _var_ref?: VarRefContext;
    public _src_expr?: ExprSingleContext;
    public constructor(parent: antlr.ParserRuleContext | null, invokingState: number) {
        super(parent, invokingState);
    }
    public Kassign(): antlr.TerminalNode {
        return this.getToken(jsoniqParser.Kassign, 0)!;
    }
    public varRef(): VarRefContext {
        return this.getRuleContext(0, VarRefContext)!;
    }
    public exprSingle(): ExprSingleContext {
        return this.getRuleContext(0, ExprSingleContext)!;
    }
    public override get ruleIndex(): number {
        return jsoniqParser.RULE_copyDecl;
    }
    public override enterRule(listener: jsoniqListener): void {
        if(listener.enterCopyDecl) {
             listener.enterCopyDecl(this);
        }
    }
    public override exitRule(listener: jsoniqListener): void {
        if(listener.exitCopyDecl) {
             listener.exitCopyDecl(this);
        }
    }
}


export class CreateCollectionExprContext extends antlr.ParserRuleContext {
    public _collectionMode?: Token | null;
    public _collection_name?: ExprSimpleContext;
    public _content?: ExprSingleContext;
    public constructor(parent: antlr.ParserRuleContext | null, invokingState: number) {
        super(parent, invokingState);
    }
    public Kcreate(): antlr.TerminalNode {
        return this.getToken(jsoniqParser.Kcreate, 0)!;
    }
    public Kcollection(): antlr.TerminalNode {
        return this.getToken(jsoniqParser.Kcollection, 0)!;
    }
    public Klparen(): antlr.TerminalNode {
        return this.getToken(jsoniqParser.Klparen, 0)!;
    }
    public Krparen(): antlr.TerminalNode {
        return this.getToken(jsoniqParser.Krparen, 0)!;
    }
    public exprSimple(): ExprSimpleContext {
        return this.getRuleContext(0, ExprSimpleContext)!;
    }
    public Ktable(): antlr.TerminalNode | null {
        return this.getToken(jsoniqParser.Ktable, 0);
    }
    public Kdeltafile(): antlr.TerminalNode | null {
        return this.getToken(jsoniqParser.Kdeltafile, 0);
    }
    public Kicebergtable(): antlr.TerminalNode | null {
        return this.getToken(jsoniqParser.Kicebergtable, 0);
    }
    public Kwith(): antlr.TerminalNode | null {
        return this.getToken(jsoniqParser.Kwith, 0);
    }
    public exprSingle(): ExprSingleContext | null {
        return this.getRuleContext(0, ExprSingleContext);
    }
    public override get ruleIndex(): number {
        return jsoniqParser.RULE_createCollectionExpr;
    }
    public override enterRule(listener: jsoniqListener): void {
        if(listener.enterCreateCollectionExpr) {
             listener.enterCreateCollectionExpr(this);
        }
    }
    public override exitRule(listener: jsoniqListener): void {
        if(listener.exitCreateCollectionExpr) {
             listener.exitCreateCollectionExpr(this);
        }
    }
}


export class DeleteIndexExprContext extends antlr.ParserRuleContext {
    public _first?: Token | null;
    public _last?: Token | null;
    public _num?: ExprSingleContext;
    public _collectionMode?: Token | null;
    public _collection_name?: ExprSimpleContext;
    public constructor(parent: antlr.ParserRuleContext | null, invokingState: number) {
        super(parent, invokingState);
    }
    public Kdelete(): antlr.TerminalNode {
        return this.getToken(jsoniqParser.Kdelete, 0)!;
    }
    public Kfrom(): antlr.TerminalNode {
        return this.getToken(jsoniqParser.Kfrom, 0)!;
    }
    public Kcollection(): antlr.TerminalNode {
        return this.getToken(jsoniqParser.Kcollection, 0)!;
    }
    public Klparen(): antlr.TerminalNode {
        return this.getToken(jsoniqParser.Klparen, 0)!;
    }
    public Krparen(): antlr.TerminalNode {
        return this.getToken(jsoniqParser.Krparen, 0)!;
    }
    public exprSimple(): ExprSimpleContext {
        return this.getRuleContext(0, ExprSimpleContext)!;
    }
    public Ktable(): antlr.TerminalNode | null {
        return this.getToken(jsoniqParser.Ktable, 0);
    }
    public Kdeltafile(): antlr.TerminalNode | null {
        return this.getToken(jsoniqParser.Kdeltafile, 0);
    }
    public Kicebergtable(): antlr.TerminalNode | null {
        return this.getToken(jsoniqParser.Kicebergtable, 0);
    }
    public Kfirst(): antlr.TerminalNode | null {
        return this.getToken(jsoniqParser.Kfirst, 0);
    }
    public Klast(): antlr.TerminalNode | null {
        return this.getToken(jsoniqParser.Klast, 0);
    }
    public exprSingle(): ExprSingleContext | null {
        return this.getRuleContext(0, ExprSingleContext);
    }
    public override get ruleIndex(): number {
        return jsoniqParser.RULE_deleteIndexExpr;
    }
    public override enterRule(listener: jsoniqListener): void {
        if(listener.enterDeleteIndexExpr) {
             listener.enterDeleteIndexExpr(this);
        }
    }
    public override exitRule(listener: jsoniqListener): void {
        if(listener.exitDeleteIndexExpr) {
             listener.exitDeleteIndexExpr(this);
        }
    }
}


export class DeleteSearchExprContext extends antlr.ParserRuleContext {
    public _content?: ExprSingleContext;
    public constructor(parent: antlr.ParserRuleContext | null, invokingState: number) {
        super(parent, invokingState);
    }
    public Kdelete(): antlr.TerminalNode {
        return this.getToken(jsoniqParser.Kdelete, 0)!;
    }
    public Kfrom(): antlr.TerminalNode {
        return this.getToken(jsoniqParser.Kfrom, 0)!;
    }
    public Kcollection(): antlr.TerminalNode {
        return this.getToken(jsoniqParser.Kcollection, 0)!;
    }
    public exprSingle(): ExprSingleContext {
        return this.getRuleContext(0, ExprSingleContext)!;
    }
    public override get ruleIndex(): number {
        return jsoniqParser.RULE_deleteSearchExpr;
    }
    public override enterRule(listener: jsoniqListener): void {
        if(listener.enterDeleteSearchExpr) {
             listener.enterDeleteSearchExpr(this);
        }
    }
    public override exitRule(listener: jsoniqListener): void {
        if(listener.exitDeleteSearchExpr) {
             listener.exitDeleteSearchExpr(this);
        }
    }
}


export class InsertIndexExprContext extends antlr.ParserRuleContext {
    public _content?: ExprSingleContext;
    public _pos?: ExprSingleContext;
    public _first?: Token | null;
    public _last?: Token | null;
    public _collectionMode?: Token | null;
    public _collection_name?: ExprSimpleContext;
    public constructor(parent: antlr.ParserRuleContext | null, invokingState: number) {
        super(parent, invokingState);
    }
    public Kinsert(): antlr.TerminalNode {
        return this.getToken(jsoniqParser.Kinsert, 0)!;
    }
    public Kinto(): antlr.TerminalNode {
        return this.getToken(jsoniqParser.Kinto, 0)!;
    }
    public Kcollection(): antlr.TerminalNode {
        return this.getToken(jsoniqParser.Kcollection, 0)!;
    }
    public Klparen(): antlr.TerminalNode {
        return this.getToken(jsoniqParser.Klparen, 0)!;
    }
    public Krparen(): antlr.TerminalNode {
        return this.getToken(jsoniqParser.Krparen, 0)!;
    }
    public exprSingle(): ExprSingleContext[];
    public exprSingle(i: number): ExprSingleContext | null;
    public exprSingle(i?: number): ExprSingleContext[] | ExprSingleContext | null {
        if (i === undefined) {
            return this.getRuleContexts(ExprSingleContext);
        }

        return this.getRuleContext(i, ExprSingleContext);
    }
    public exprSimple(): ExprSimpleContext {
        return this.getRuleContext(0, ExprSimpleContext)!;
    }
    public Ktable(): antlr.TerminalNode | null {
        return this.getToken(jsoniqParser.Ktable, 0);
    }
    public Kdeltafile(): antlr.TerminalNode | null {
        return this.getToken(jsoniqParser.Kdeltafile, 0);
    }
    public Kicebergtable(): antlr.TerminalNode | null {
        return this.getToken(jsoniqParser.Kicebergtable, 0);
    }
    public Kfirst(): antlr.TerminalNode | null {
        return this.getToken(jsoniqParser.Kfirst, 0);
    }
    public Klast(): antlr.TerminalNode | null {
        return this.getToken(jsoniqParser.Klast, 0);
    }
    public Kat(): antlr.TerminalNode | null {
        return this.getToken(jsoniqParser.Kat, 0);
    }
    public override get ruleIndex(): number {
        return jsoniqParser.RULE_insertIndexExpr;
    }
    public override enterRule(listener: jsoniqListener): void {
        if(listener.enterInsertIndexExpr) {
             listener.enterInsertIndexExpr(this);
        }
    }
    public override exitRule(listener: jsoniqListener): void {
        if(listener.exitInsertIndexExpr) {
             listener.exitInsertIndexExpr(this);
        }
    }
}


export class InsertSearchExprContext extends antlr.ParserRuleContext {
    public _content?: ExprSingleContext;
    public _before?: Token | null;
    public _after?: Token | null;
    public _target?: ExprSingleContext;
    public constructor(parent: antlr.ParserRuleContext | null, invokingState: number) {
        super(parent, invokingState);
    }
    public Kinsert(): antlr.TerminalNode {
        return this.getToken(jsoniqParser.Kinsert, 0)!;
    }
    public Kinto(): antlr.TerminalNode {
        return this.getToken(jsoniqParser.Kinto, 0)!;
    }
    public Kcollection(): antlr.TerminalNode {
        return this.getToken(jsoniqParser.Kcollection, 0)!;
    }
    public exprSingle(): ExprSingleContext[];
    public exprSingle(i: number): ExprSingleContext | null;
    public exprSingle(i?: number): ExprSingleContext[] | ExprSingleContext | null {
        if (i === undefined) {
            return this.getRuleContexts(ExprSingleContext);
        }

        return this.getRuleContext(i, ExprSingleContext);
    }
    public Kbefore(): antlr.TerminalNode | null {
        return this.getToken(jsoniqParser.Kbefore, 0);
    }
    public Kafter(): antlr.TerminalNode | null {
        return this.getToken(jsoniqParser.Kafter, 0);
    }
    public override get ruleIndex(): number {
        return jsoniqParser.RULE_insertSearchExpr;
    }
    public override enterRule(listener: jsoniqListener): void {
        if(listener.enterInsertSearchExpr) {
             listener.enterInsertSearchExpr(this);
        }
    }
    public override exitRule(listener: jsoniqListener): void {
        if(listener.exitInsertSearchExpr) {
             listener.exitInsertSearchExpr(this);
        }
    }
}


export class TruncateCollectionExprContext extends antlr.ParserRuleContext {
    public _collectionMode?: Token | null;
    public _collection_name?: ExprSimpleContext;
    public constructor(parent: antlr.ParserRuleContext | null, invokingState: number) {
        super(parent, invokingState);
    }
    public Kcollection(): antlr.TerminalNode {
        return this.getToken(jsoniqParser.Kcollection, 0)!;
    }
    public Klparen(): antlr.TerminalNode {
        return this.getToken(jsoniqParser.Klparen, 0)!;
    }
    public Krparen(): antlr.TerminalNode {
        return this.getToken(jsoniqParser.Krparen, 0)!;
    }
    public Kdelete(): antlr.TerminalNode | null {
        return this.getToken(jsoniqParser.Kdelete, 0);
    }
    public Ktruncate(): antlr.TerminalNode | null {
        return this.getToken(jsoniqParser.Ktruncate, 0);
    }
    public exprSimple(): ExprSimpleContext {
        return this.getRuleContext(0, ExprSimpleContext)!;
    }
    public Ktable(): antlr.TerminalNode | null {
        return this.getToken(jsoniqParser.Ktable, 0);
    }
    public Kdeltafile(): antlr.TerminalNode | null {
        return this.getToken(jsoniqParser.Kdeltafile, 0);
    }
    public Kicebergtable(): antlr.TerminalNode | null {
        return this.getToken(jsoniqParser.Kicebergtable, 0);
    }
    public override get ruleIndex(): number {
        return jsoniqParser.RULE_truncateCollectionExpr;
    }
    public override enterRule(listener: jsoniqListener): void {
        if(listener.enterTruncateCollectionExpr) {
             listener.enterTruncateCollectionExpr(this);
        }
    }
    public override exitRule(listener: jsoniqListener): void {
        if(listener.exitTruncateCollectionExpr) {
             listener.exitTruncateCollectionExpr(this);
        }
    }
}


export class EditCollectionExprContext extends antlr.ParserRuleContext {
    public _target?: ExprSingleContext;
    public _content?: ExprSingleContext;
    public constructor(parent: antlr.ParserRuleContext | null, invokingState: number) {
        super(parent, invokingState);
    }
    public Kedit(): antlr.TerminalNode {
        return this.getToken(jsoniqParser.Kedit, 0)!;
    }
    public Kinto(): antlr.TerminalNode {
        return this.getToken(jsoniqParser.Kinto, 0)!;
    }
    public Kin(): antlr.TerminalNode {
        return this.getToken(jsoniqParser.Kin, 0)!;
    }
    public Kcollection(): antlr.TerminalNode {
        return this.getToken(jsoniqParser.Kcollection, 0)!;
    }
    public exprSingle(): ExprSingleContext[];
    public exprSingle(i: number): ExprSingleContext | null;
    public exprSingle(i?: number): ExprSingleContext[] | ExprSingleContext | null {
        if (i === undefined) {
            return this.getRuleContexts(ExprSingleContext);
        }

        return this.getRuleContext(i, ExprSingleContext);
    }
    public override get ruleIndex(): number {
        return jsoniqParser.RULE_editCollectionExpr;
    }
    public override enterRule(listener: jsoniqListener): void {
        if(listener.enterEditCollectionExpr) {
             listener.enterEditCollectionExpr(this);
        }
    }
    public override exitRule(listener: jsoniqListener): void {
        if(listener.exitEditCollectionExpr) {
             listener.exitEditCollectionExpr(this);
        }
    }
}


export class PathExprContext extends antlr.ParserRuleContext {
    public _singleslash?: RelativePathExprContext;
    public _doubleslash?: RelativePathExprContext;
    public _relative?: RelativePathExprContext;
    public constructor(parent: antlr.ParserRuleContext | null, invokingState: number) {
        super(parent, invokingState);
    }
    public Kslash(): antlr.TerminalNode | null {
        return this.getToken(jsoniqParser.Kslash, 0);
    }
    public relativePathExpr(): RelativePathExprContext | null {
        return this.getRuleContext(0, RelativePathExprContext);
    }
    public Kdslash(): antlr.TerminalNode | null {
        return this.getToken(jsoniqParser.Kdslash, 0);
    }
    public override get ruleIndex(): number {
        return jsoniqParser.RULE_pathExpr;
    }
    public override enterRule(listener: jsoniqListener): void {
        if(listener.enterPathExpr) {
             listener.enterPathExpr(this);
        }
    }
    public override exitRule(listener: jsoniqListener): void {
        if(listener.exitPathExpr) {
             listener.exitPathExpr(this);
        }
    }
}


export class RelativePathExprContext extends antlr.ParserRuleContext {
    public _Kslash?: Token | null;
    public _sep: antlr.Token[] = [];
    public _Kdslash?: Token | null;
    public __tset3113?: Token | null;
    public constructor(parent: antlr.ParserRuleContext | null, invokingState: number) {
        super(parent, invokingState);
    }
    public stepExpr(): StepExprContext[];
    public stepExpr(i: number): StepExprContext | null;
    public stepExpr(i?: number): StepExprContext[] | StepExprContext | null {
        if (i === undefined) {
            return this.getRuleContexts(StepExprContext);
        }

        return this.getRuleContext(i, StepExprContext);
    }
    public Kslash(): antlr.TerminalNode[];
    public Kslash(i: number): antlr.TerminalNode | null;
    public Kslash(i?: number): antlr.TerminalNode | null | antlr.TerminalNode[] {
    	if (i === undefined) {
    		return this.getTokens(jsoniqParser.Kslash);
    	} else {
    		return this.getToken(jsoniqParser.Kslash, i);
    	}
    }
    public Kdslash(): antlr.TerminalNode[];
    public Kdslash(i: number): antlr.TerminalNode | null;
    public Kdslash(i?: number): antlr.TerminalNode | null | antlr.TerminalNode[] {
    	if (i === undefined) {
    		return this.getTokens(jsoniqParser.Kdslash);
    	} else {
    		return this.getToken(jsoniqParser.Kdslash, i);
    	}
    }
    public override get ruleIndex(): number {
        return jsoniqParser.RULE_relativePathExpr;
    }
    public override enterRule(listener: jsoniqListener): void {
        if(listener.enterRelativePathExpr) {
             listener.enterRelativePathExpr(this);
        }
    }
    public override exitRule(listener: jsoniqListener): void {
        if(listener.exitRelativePathExpr) {
             listener.exitRelativePathExpr(this);
        }
    }
}


export class StepExprContext extends antlr.ParserRuleContext {
    public constructor(parent: antlr.ParserRuleContext | null, invokingState: number) {
        super(parent, invokingState);
    }
    public postFixExpr(): PostFixExprContext | null {
        return this.getRuleContext(0, PostFixExprContext);
    }
    public axisStep(): AxisStepContext | null {
        return this.getRuleContext(0, AxisStepContext);
    }
    public override get ruleIndex(): number {
        return jsoniqParser.RULE_stepExpr;
    }
    public override enterRule(listener: jsoniqListener): void {
        if(listener.enterStepExpr) {
             listener.enterStepExpr(this);
        }
    }
    public override exitRule(listener: jsoniqListener): void {
        if(listener.exitStepExpr) {
             listener.exitStepExpr(this);
        }
    }
}


export class AxisStepContext extends antlr.ParserRuleContext {
    public constructor(parent: antlr.ParserRuleContext | null, invokingState: number) {
        super(parent, invokingState);
    }
    public predicateList(): PredicateListContext {
        return this.getRuleContext(0, PredicateListContext)!;
    }
    public reverseStep(): ReverseStepContext | null {
        return this.getRuleContext(0, ReverseStepContext);
    }
    public forwardStep(): ForwardStepContext | null {
        return this.getRuleContext(0, ForwardStepContext);
    }
    public override get ruleIndex(): number {
        return jsoniqParser.RULE_axisStep;
    }
    public override enterRule(listener: jsoniqListener): void {
        if(listener.enterAxisStep) {
             listener.enterAxisStep(this);
        }
    }
    public override exitRule(listener: jsoniqListener): void {
        if(listener.exitAxisStep) {
             listener.exitAxisStep(this);
        }
    }
}


export class ForwardStepContext extends antlr.ParserRuleContext {
    public constructor(parent: antlr.ParserRuleContext | null, invokingState: number) {
        super(parent, invokingState);
    }
    public forwardAxis(): ForwardAxisContext | null {
        return this.getRuleContext(0, ForwardAxisContext);
    }
    public nodeTest(): NodeTestContext | null {
        return this.getRuleContext(0, NodeTestContext);
    }
    public abbrevForwardStep(): AbbrevForwardStepContext | null {
        return this.getRuleContext(0, AbbrevForwardStepContext);
    }
    public override get ruleIndex(): number {
        return jsoniqParser.RULE_forwardStep;
    }
    public override enterRule(listener: jsoniqListener): void {
        if(listener.enterForwardStep) {
             listener.enterForwardStep(this);
        }
    }
    public override exitRule(listener: jsoniqListener): void {
        if(listener.exitForwardStep) {
             listener.exitForwardStep(this);
        }
    }
}


export class ForwardAxisContext extends antlr.ParserRuleContext {
    public constructor(parent: antlr.ParserRuleContext | null, invokingState: number) {
        super(parent, invokingState);
    }
    public Kcolon(): antlr.TerminalNode[];
    public Kcolon(i: number): antlr.TerminalNode | null;
    public Kcolon(i?: number): antlr.TerminalNode | null | antlr.TerminalNode[] {
    	if (i === undefined) {
    		return this.getTokens(jsoniqParser.Kcolon);
    	} else {
    		return this.getToken(jsoniqParser.Kcolon, i);
    	}
    }
    public Kchild(): antlr.TerminalNode | null {
        return this.getToken(jsoniqParser.Kchild, 0);
    }
    public Kdescendant(): antlr.TerminalNode | null {
        return this.getToken(jsoniqParser.Kdescendant, 0);
    }
    public Kattribute(): antlr.TerminalNode | null {
        return this.getToken(jsoniqParser.Kattribute, 0);
    }
    public Kself(): antlr.TerminalNode | null {
        return this.getToken(jsoniqParser.Kself, 0);
    }
    public Kdescendant_or_self(): antlr.TerminalNode | null {
        return this.getToken(jsoniqParser.Kdescendant_or_self, 0);
    }
    public Kfollowing_sibling(): antlr.TerminalNode | null {
        return this.getToken(jsoniqParser.Kfollowing_sibling, 0);
    }
    public Kfollowing(): antlr.TerminalNode | null {
        return this.getToken(jsoniqParser.Kfollowing, 0);
    }
    public override get ruleIndex(): number {
        return jsoniqParser.RULE_forwardAxis;
    }
    public override enterRule(listener: jsoniqListener): void {
        if(listener.enterForwardAxis) {
             listener.enterForwardAxis(this);
        }
    }
    public override exitRule(listener: jsoniqListener): void {
        if(listener.exitForwardAxis) {
             listener.exitForwardAxis(this);
        }
    }
}


export class AbbrevForwardStepContext extends antlr.ParserRuleContext {
    public constructor(parent: antlr.ParserRuleContext | null, invokingState: number) {
        super(parent, invokingState);
    }
    public nodeTest(): NodeTestContext {
        return this.getRuleContext(0, NodeTestContext)!;
    }
    public Kat_symbol(): antlr.TerminalNode | null {
        return this.getToken(jsoniqParser.Kat_symbol, 0);
    }
    public override get ruleIndex(): number {
        return jsoniqParser.RULE_abbrevForwardStep;
    }
    public override enterRule(listener: jsoniqListener): void {
        if(listener.enterAbbrevForwardStep) {
             listener.enterAbbrevForwardStep(this);
        }
    }
    public override exitRule(listener: jsoniqListener): void {
        if(listener.exitAbbrevForwardStep) {
             listener.exitAbbrevForwardStep(this);
        }
    }
}


export class ReverseStepContext extends antlr.ParserRuleContext {
    public constructor(parent: antlr.ParserRuleContext | null, invokingState: number) {
        super(parent, invokingState);
    }
    public reverseAxis(): ReverseAxisContext | null {
        return this.getRuleContext(0, ReverseAxisContext);
    }
    public nodeTest(): NodeTestContext | null {
        return this.getRuleContext(0, NodeTestContext);
    }
    public abbrevReverseStep(): AbbrevReverseStepContext | null {
        return this.getRuleContext(0, AbbrevReverseStepContext);
    }
    public override get ruleIndex(): number {
        return jsoniqParser.RULE_reverseStep;
    }
    public override enterRule(listener: jsoniqListener): void {
        if(listener.enterReverseStep) {
             listener.enterReverseStep(this);
        }
    }
    public override exitRule(listener: jsoniqListener): void {
        if(listener.exitReverseStep) {
             listener.exitReverseStep(this);
        }
    }
}


export class ReverseAxisContext extends antlr.ParserRuleContext {
    public constructor(parent: antlr.ParserRuleContext | null, invokingState: number) {
        super(parent, invokingState);
    }
    public Kcolon(): antlr.TerminalNode[];
    public Kcolon(i: number): antlr.TerminalNode | null;
    public Kcolon(i?: number): antlr.TerminalNode | null | antlr.TerminalNode[] {
    	if (i === undefined) {
    		return this.getTokens(jsoniqParser.Kcolon);
    	} else {
    		return this.getToken(jsoniqParser.Kcolon, i);
    	}
    }
    public Kparent(): antlr.TerminalNode | null {
        return this.getToken(jsoniqParser.Kparent, 0);
    }
    public Kancestor(): antlr.TerminalNode | null {
        return this.getToken(jsoniqParser.Kancestor, 0);
    }
    public Kpreceding_sibling(): antlr.TerminalNode | null {
        return this.getToken(jsoniqParser.Kpreceding_sibling, 0);
    }
    public Kpreceding(): antlr.TerminalNode | null {
        return this.getToken(jsoniqParser.Kpreceding, 0);
    }
    public Kancestor_or_self(): antlr.TerminalNode | null {
        return this.getToken(jsoniqParser.Kancestor_or_self, 0);
    }
    public override get ruleIndex(): number {
        return jsoniqParser.RULE_reverseAxis;
    }
    public override enterRule(listener: jsoniqListener): void {
        if(listener.enterReverseAxis) {
             listener.enterReverseAxis(this);
        }
    }
    public override exitRule(listener: jsoniqListener): void {
        if(listener.exitReverseAxis) {
             listener.exitReverseAxis(this);
        }
    }
}


export class AbbrevReverseStepContext extends antlr.ParserRuleContext {
    public constructor(parent: antlr.ParserRuleContext | null, invokingState: number) {
        super(parent, invokingState);
    }
    public Kdotdot(): antlr.TerminalNode {
        return this.getToken(jsoniqParser.Kdotdot, 0)!;
    }
    public override get ruleIndex(): number {
        return jsoniqParser.RULE_abbrevReverseStep;
    }
    public override enterRule(listener: jsoniqListener): void {
        if(listener.enterAbbrevReverseStep) {
             listener.enterAbbrevReverseStep(this);
        }
    }
    public override exitRule(listener: jsoniqListener): void {
        if(listener.exitAbbrevReverseStep) {
             listener.exitAbbrevReverseStep(this);
        }
    }
}


export class NodeTestContext extends antlr.ParserRuleContext {
    public constructor(parent: antlr.ParserRuleContext | null, invokingState: number) {
        super(parent, invokingState);
    }
    public nameTest(): NameTestContext | null {
        return this.getRuleContext(0, NameTestContext);
    }
    public kindTest(): KindTestContext | null {
        return this.getRuleContext(0, KindTestContext);
    }
    public override get ruleIndex(): number {
        return jsoniqParser.RULE_nodeTest;
    }
    public override enterRule(listener: jsoniqListener): void {
        if(listener.enterNodeTest) {
             listener.enterNodeTest(this);
        }
    }
    public override exitRule(listener: jsoniqListener): void {
        if(listener.exitNodeTest) {
             listener.exitNodeTest(this);
        }
    }
}


export class NameTestContext extends antlr.ParserRuleContext {
    public constructor(parent: antlr.ParserRuleContext | null, invokingState: number) {
        super(parent, invokingState);
    }
    public qname(): QnameContext | null {
        return this.getRuleContext(0, QnameContext);
    }
    public wildcard(): WildcardContext | null {
        return this.getRuleContext(0, WildcardContext);
    }
    public override get ruleIndex(): number {
        return jsoniqParser.RULE_nameTest;
    }
    public override enterRule(listener: jsoniqListener): void {
        if(listener.enterNameTest) {
             listener.enterNameTest(this);
        }
    }
    public override exitRule(listener: jsoniqListener): void {
        if(listener.exitNameTest) {
             listener.exitNameTest(this);
        }
    }
}


export class WildcardContext extends antlr.ParserRuleContext {
    public constructor(parent: antlr.ParserRuleContext | null, invokingState: number) {
        super(parent, invokingState);
    }
    public override get ruleIndex(): number {
        return jsoniqParser.RULE_wildcard;
    }
    public override copyFrom(ctx: WildcardContext): void {
        super.copyFrom(ctx);
    }
}
export class AllNamesContext extends WildcardContext {
    public constructor(ctx: WildcardContext) {
        super(ctx.parent, ctx.invokingState);
        super.copyFrom(ctx);
    }
    public Kasterisk(): antlr.TerminalNode {
        return this.getToken(jsoniqParser.Kasterisk, 0)!;
    }
    public override enterRule(listener: jsoniqListener): void {
        if(listener.enterAllNames) {
             listener.enterAllNames(this);
        }
    }
    public override exitRule(listener: jsoniqListener): void {
        if(listener.exitAllNames) {
             listener.exitAllNames(this);
        }
    }
}
export class AllWithNSContext extends WildcardContext {
    public constructor(ctx: WildcardContext) {
        super(ctx.parent, ctx.invokingState);
        super.copyFrom(ctx);
    }
    public nCNameWithLocalWildcard(): NCNameWithLocalWildcardContext {
        return this.getRuleContext(0, NCNameWithLocalWildcardContext)!;
    }
    public override enterRule(listener: jsoniqListener): void {
        if(listener.enterAllWithNS) {
             listener.enterAllWithNS(this);
        }
    }
    public override exitRule(listener: jsoniqListener): void {
        if(listener.exitAllWithNS) {
             listener.exitAllWithNS(this);
        }
    }
}
export class AllWithLocalContext extends WildcardContext {
    public constructor(ctx: WildcardContext) {
        super(ctx.parent, ctx.invokingState);
        super.copyFrom(ctx);
    }
    public nCNameWithPrefixWildcard(): NCNameWithPrefixWildcardContext {
        return this.getRuleContext(0, NCNameWithPrefixWildcardContext)!;
    }
    public override enterRule(listener: jsoniqListener): void {
        if(listener.enterAllWithLocal) {
             listener.enterAllWithLocal(this);
        }
    }
    public override exitRule(listener: jsoniqListener): void {
        if(listener.exitAllWithLocal) {
             listener.exitAllWithLocal(this);
        }
    }
}


export class NCNameWithLocalWildcardContext extends antlr.ParserRuleContext {
    public constructor(parent: antlr.ParserRuleContext | null, invokingState: number) {
        super(parent, invokingState);
    }
    public NCName(): antlr.TerminalNode {
        return this.getToken(jsoniqParser.NCName, 0)!;
    }
    public Kcolon(): antlr.TerminalNode {
        return this.getToken(jsoniqParser.Kcolon, 0)!;
    }
    public Kasterisk(): antlr.TerminalNode {
        return this.getToken(jsoniqParser.Kasterisk, 0)!;
    }
    public override get ruleIndex(): number {
        return jsoniqParser.RULE_nCNameWithLocalWildcard;
    }
    public override enterRule(listener: jsoniqListener): void {
        if(listener.enterNCNameWithLocalWildcard) {
             listener.enterNCNameWithLocalWildcard(this);
        }
    }
    public override exitRule(listener: jsoniqListener): void {
        if(listener.exitNCNameWithLocalWildcard) {
             listener.exitNCNameWithLocalWildcard(this);
        }
    }
}


export class NCNameWithPrefixWildcardContext extends antlr.ParserRuleContext {
    public constructor(parent: antlr.ParserRuleContext | null, invokingState: number) {
        super(parent, invokingState);
    }
    public Kasterisk(): antlr.TerminalNode {
        return this.getToken(jsoniqParser.Kasterisk, 0)!;
    }
    public Kcolon(): antlr.TerminalNode {
        return this.getToken(jsoniqParser.Kcolon, 0)!;
    }
    public NCName(): antlr.TerminalNode {
        return this.getToken(jsoniqParser.NCName, 0)!;
    }
    public override get ruleIndex(): number {
        return jsoniqParser.RULE_nCNameWithPrefixWildcard;
    }
    public override enterRule(listener: jsoniqListener): void {
        if(listener.enterNCNameWithPrefixWildcard) {
             listener.enterNCNameWithPrefixWildcard(this);
        }
    }
    public override exitRule(listener: jsoniqListener): void {
        if(listener.exitNCNameWithPrefixWildcard) {
             listener.exitNCNameWithPrefixWildcard(this);
        }
    }
}


export class PredicateListContext extends antlr.ParserRuleContext {
    public constructor(parent: antlr.ParserRuleContext | null, invokingState: number) {
        super(parent, invokingState);
    }
    public predicate(): PredicateContext[];
    public predicate(i: number): PredicateContext | null;
    public predicate(i?: number): PredicateContext[] | PredicateContext | null {
        if (i === undefined) {
            return this.getRuleContexts(PredicateContext);
        }

        return this.getRuleContext(i, PredicateContext);
    }
    public override get ruleIndex(): number {
        return jsoniqParser.RULE_predicateList;
    }
    public override enterRule(listener: jsoniqListener): void {
        if(listener.enterPredicateList) {
             listener.enterPredicateList(this);
        }
    }
    public override exitRule(listener: jsoniqListener): void {
        if(listener.exitPredicateList) {
             listener.exitPredicateList(this);
        }
    }
}


export class KindTestContext extends antlr.ParserRuleContext {
    public constructor(parent: antlr.ParserRuleContext | null, invokingState: number) {
        super(parent, invokingState);
    }
    public documentTest(): DocumentTestContext | null {
        return this.getRuleContext(0, DocumentTestContext);
    }
    public elementTest(): ElementTestContext | null {
        return this.getRuleContext(0, ElementTestContext);
    }
    public attributeTest(): AttributeTestContext | null {
        return this.getRuleContext(0, AttributeTestContext);
    }
    public schemaElementTest(): SchemaElementTestContext | null {
        return this.getRuleContext(0, SchemaElementTestContext);
    }
    public schemaAttributeTest(): SchemaAttributeTestContext | null {
        return this.getRuleContext(0, SchemaAttributeTestContext);
    }
    public piTest(): PiTestContext | null {
        return this.getRuleContext(0, PiTestContext);
    }
    public commentTest(): CommentTestContext | null {
        return this.getRuleContext(0, CommentTestContext);
    }
    public textTest(): TextTestContext | null {
        return this.getRuleContext(0, TextTestContext);
    }
    public namespaceNodeTest(): NamespaceNodeTestContext | null {
        return this.getRuleContext(0, NamespaceNodeTestContext);
    }
    public binaryNodeTest(): BinaryNodeTestContext | null {
        return this.getRuleContext(0, BinaryNodeTestContext);
    }
    public anyKindTest(): AnyKindTestContext | null {
        return this.getRuleContext(0, AnyKindTestContext);
    }
    public override get ruleIndex(): number {
        return jsoniqParser.RULE_kindTest;
    }
    public override enterRule(listener: jsoniqListener): void {
        if(listener.enterKindTest) {
             listener.enterKindTest(this);
        }
    }
    public override exitRule(listener: jsoniqListener): void {
        if(listener.exitKindTest) {
             listener.exitKindTest(this);
        }
    }
}


export class AnyKindTestContext extends antlr.ParserRuleContext {
    public constructor(parent: antlr.ParserRuleContext | null, invokingState: number) {
        super(parent, invokingState);
    }
    public Knode(): antlr.TerminalNode {
        return this.getToken(jsoniqParser.Knode, 0)!;
    }
    public Klparen(): antlr.TerminalNode {
        return this.getToken(jsoniqParser.Klparen, 0)!;
    }
    public Krparen(): antlr.TerminalNode {
        return this.getToken(jsoniqParser.Krparen, 0)!;
    }
    public override get ruleIndex(): number {
        return jsoniqParser.RULE_anyKindTest;
    }
    public override enterRule(listener: jsoniqListener): void {
        if(listener.enterAnyKindTest) {
             listener.enterAnyKindTest(this);
        }
    }
    public override exitRule(listener: jsoniqListener): void {
        if(listener.exitAnyKindTest) {
             listener.exitAnyKindTest(this);
        }
    }
}


export class BinaryNodeTestContext extends antlr.ParserRuleContext {
    public constructor(parent: antlr.ParserRuleContext | null, invokingState: number) {
        super(parent, invokingState);
    }
    public Kbinary(): antlr.TerminalNode {
        return this.getToken(jsoniqParser.Kbinary, 0)!;
    }
    public Klparen(): antlr.TerminalNode {
        return this.getToken(jsoniqParser.Klparen, 0)!;
    }
    public Krparen(): antlr.TerminalNode {
        return this.getToken(jsoniqParser.Krparen, 0)!;
    }
    public override get ruleIndex(): number {
        return jsoniqParser.RULE_binaryNodeTest;
    }
    public override enterRule(listener: jsoniqListener): void {
        if(listener.enterBinaryNodeTest) {
             listener.enterBinaryNodeTest(this);
        }
    }
    public override exitRule(listener: jsoniqListener): void {
        if(listener.exitBinaryNodeTest) {
             listener.exitBinaryNodeTest(this);
        }
    }
}


export class DocumentTestContext extends antlr.ParserRuleContext {
    public constructor(parent: antlr.ParserRuleContext | null, invokingState: number) {
        super(parent, invokingState);
    }
    public Kdocument_node(): antlr.TerminalNode {
        return this.getToken(jsoniqParser.Kdocument_node, 0)!;
    }
    public Klparen(): antlr.TerminalNode {
        return this.getToken(jsoniqParser.Klparen, 0)!;
    }
    public Krparen(): antlr.TerminalNode {
        return this.getToken(jsoniqParser.Krparen, 0)!;
    }
    public elementTest(): ElementTestContext | null {
        return this.getRuleContext(0, ElementTestContext);
    }
    public schemaElementTest(): SchemaElementTestContext | null {
        return this.getRuleContext(0, SchemaElementTestContext);
    }
    public override get ruleIndex(): number {
        return jsoniqParser.RULE_documentTest;
    }
    public override enterRule(listener: jsoniqListener): void {
        if(listener.enterDocumentTest) {
             listener.enterDocumentTest(this);
        }
    }
    public override exitRule(listener: jsoniqListener): void {
        if(listener.exitDocumentTest) {
             listener.exitDocumentTest(this);
        }
    }
}


export class TextTestContext extends antlr.ParserRuleContext {
    public constructor(parent: antlr.ParserRuleContext | null, invokingState: number) {
        super(parent, invokingState);
    }
    public Ktext(): antlr.TerminalNode {
        return this.getToken(jsoniqParser.Ktext, 0)!;
    }
    public Klparen(): antlr.TerminalNode {
        return this.getToken(jsoniqParser.Klparen, 0)!;
    }
    public Krparen(): antlr.TerminalNode {
        return this.getToken(jsoniqParser.Krparen, 0)!;
    }
    public override get ruleIndex(): number {
        return jsoniqParser.RULE_textTest;
    }
    public override enterRule(listener: jsoniqListener): void {
        if(listener.enterTextTest) {
             listener.enterTextTest(this);
        }
    }
    public override exitRule(listener: jsoniqListener): void {
        if(listener.exitTextTest) {
             listener.exitTextTest(this);
        }
    }
}


export class CommentTestContext extends antlr.ParserRuleContext {
    public constructor(parent: antlr.ParserRuleContext | null, invokingState: number) {
        super(parent, invokingState);
    }
    public Kcomment(): antlr.TerminalNode {
        return this.getToken(jsoniqParser.Kcomment, 0)!;
    }
    public Klparen(): antlr.TerminalNode {
        return this.getToken(jsoniqParser.Klparen, 0)!;
    }
    public Krparen(): antlr.TerminalNode {
        return this.getToken(jsoniqParser.Krparen, 0)!;
    }
    public override get ruleIndex(): number {
        return jsoniqParser.RULE_commentTest;
    }
    public override enterRule(listener: jsoniqListener): void {
        if(listener.enterCommentTest) {
             listener.enterCommentTest(this);
        }
    }
    public override exitRule(listener: jsoniqListener): void {
        if(listener.exitCommentTest) {
             listener.exitCommentTest(this);
        }
    }
}


export class NamespaceNodeTestContext extends antlr.ParserRuleContext {
    public constructor(parent: antlr.ParserRuleContext | null, invokingState: number) {
        super(parent, invokingState);
    }
    public Knamespace_node(): antlr.TerminalNode {
        return this.getToken(jsoniqParser.Knamespace_node, 0)!;
    }
    public Klparen(): antlr.TerminalNode {
        return this.getToken(jsoniqParser.Klparen, 0)!;
    }
    public Krparen(): antlr.TerminalNode {
        return this.getToken(jsoniqParser.Krparen, 0)!;
    }
    public override get ruleIndex(): number {
        return jsoniqParser.RULE_namespaceNodeTest;
    }
    public override enterRule(listener: jsoniqListener): void {
        if(listener.enterNamespaceNodeTest) {
             listener.enterNamespaceNodeTest(this);
        }
    }
    public override exitRule(listener: jsoniqListener): void {
        if(listener.exitNamespaceNodeTest) {
             listener.exitNamespaceNodeTest(this);
        }
    }
}


export class PiTestContext extends antlr.ParserRuleContext {
    public constructor(parent: antlr.ParserRuleContext | null, invokingState: number) {
        super(parent, invokingState);
    }
    public Kpi(): antlr.TerminalNode {
        return this.getToken(jsoniqParser.Kpi, 0)!;
    }
    public Klparen(): antlr.TerminalNode {
        return this.getToken(jsoniqParser.Klparen, 0)!;
    }
    public Krparen(): antlr.TerminalNode {
        return this.getToken(jsoniqParser.Krparen, 0)!;
    }
    public NCName(): antlr.TerminalNode | null {
        return this.getToken(jsoniqParser.NCName, 0);
    }
    public stringLiteral(): StringLiteralContext | null {
        return this.getRuleContext(0, StringLiteralContext);
    }
    public override get ruleIndex(): number {
        return jsoniqParser.RULE_piTest;
    }
    public override enterRule(listener: jsoniqListener): void {
        if(listener.enterPiTest) {
             listener.enterPiTest(this);
        }
    }
    public override exitRule(listener: jsoniqListener): void {
        if(listener.exitPiTest) {
             listener.exitPiTest(this);
        }
    }
}


export class AttributeTestContext extends antlr.ParserRuleContext {
    public _type_?: TypeNameContext;
    public constructor(parent: antlr.ParserRuleContext | null, invokingState: number) {
        super(parent, invokingState);
    }
    public Kattribute(): antlr.TerminalNode {
        return this.getToken(jsoniqParser.Kattribute, 0)!;
    }
    public Klparen(): antlr.TerminalNode {
        return this.getToken(jsoniqParser.Klparen, 0)!;
    }
    public Krparen(): antlr.TerminalNode {
        return this.getToken(jsoniqParser.Krparen, 0)!;
    }
    public attributeNameOrWildcard(): AttributeNameOrWildcardContext | null {
        return this.getRuleContext(0, AttributeNameOrWildcardContext);
    }
    public Kcomma(): antlr.TerminalNode | null {
        return this.getToken(jsoniqParser.Kcomma, 0);
    }
    public typeName(): TypeNameContext | null {
        return this.getRuleContext(0, TypeNameContext);
    }
    public override get ruleIndex(): number {
        return jsoniqParser.RULE_attributeTest;
    }
    public override enterRule(listener: jsoniqListener): void {
        if(listener.enterAttributeTest) {
             listener.enterAttributeTest(this);
        }
    }
    public override exitRule(listener: jsoniqListener): void {
        if(listener.exitAttributeTest) {
             listener.exitAttributeTest(this);
        }
    }
}


export class AttributeNameOrWildcardContext extends antlr.ParserRuleContext {
    public constructor(parent: antlr.ParserRuleContext | null, invokingState: number) {
        super(parent, invokingState);
    }
    public attributeName(): AttributeNameContext | null {
        return this.getRuleContext(0, AttributeNameContext);
    }
    public Kasterisk(): antlr.TerminalNode | null {
        return this.getToken(jsoniqParser.Kasterisk, 0);
    }
    public override get ruleIndex(): number {
        return jsoniqParser.RULE_attributeNameOrWildcard;
    }
    public override enterRule(listener: jsoniqListener): void {
        if(listener.enterAttributeNameOrWildcard) {
             listener.enterAttributeNameOrWildcard(this);
        }
    }
    public override exitRule(listener: jsoniqListener): void {
        if(listener.exitAttributeNameOrWildcard) {
             listener.exitAttributeNameOrWildcard(this);
        }
    }
}


export class SchemaAttributeTestContext extends antlr.ParserRuleContext {
    public constructor(parent: antlr.ParserRuleContext | null, invokingState: number) {
        super(parent, invokingState);
    }
    public Kschema_attribute(): antlr.TerminalNode {
        return this.getToken(jsoniqParser.Kschema_attribute, 0)!;
    }
    public Klparen(): antlr.TerminalNode {
        return this.getToken(jsoniqParser.Klparen, 0)!;
    }
    public attributeDeclaration(): AttributeDeclarationContext {
        return this.getRuleContext(0, AttributeDeclarationContext)!;
    }
    public Krparen(): antlr.TerminalNode {
        return this.getToken(jsoniqParser.Krparen, 0)!;
    }
    public override get ruleIndex(): number {
        return jsoniqParser.RULE_schemaAttributeTest;
    }
    public override enterRule(listener: jsoniqListener): void {
        if(listener.enterSchemaAttributeTest) {
             listener.enterSchemaAttributeTest(this);
        }
    }
    public override exitRule(listener: jsoniqListener): void {
        if(listener.exitSchemaAttributeTest) {
             listener.exitSchemaAttributeTest(this);
        }
    }
}


export class AttributeDeclarationContext extends antlr.ParserRuleContext {
    public constructor(parent: antlr.ParserRuleContext | null, invokingState: number) {
        super(parent, invokingState);
    }
    public attributeName(): AttributeNameContext {
        return this.getRuleContext(0, AttributeNameContext)!;
    }
    public override get ruleIndex(): number {
        return jsoniqParser.RULE_attributeDeclaration;
    }
    public override enterRule(listener: jsoniqListener): void {
        if(listener.enterAttributeDeclaration) {
             listener.enterAttributeDeclaration(this);
        }
    }
    public override exitRule(listener: jsoniqListener): void {
        if(listener.exitAttributeDeclaration) {
             listener.exitAttributeDeclaration(this);
        }
    }
}


export class ElementTestContext extends antlr.ParserRuleContext {
    public _type_?: TypeNameContext;
    public _optional?: Token | null;
    public constructor(parent: antlr.ParserRuleContext | null, invokingState: number) {
        super(parent, invokingState);
    }
    public Kelement(): antlr.TerminalNode {
        return this.getToken(jsoniqParser.Kelement, 0)!;
    }
    public Klparen(): antlr.TerminalNode {
        return this.getToken(jsoniqParser.Klparen, 0)!;
    }
    public Krparen(): antlr.TerminalNode {
        return this.getToken(jsoniqParser.Krparen, 0)!;
    }
    public elementNameOrWildcard(): ElementNameOrWildcardContext | null {
        return this.getRuleContext(0, ElementNameOrWildcardContext);
    }
    public Kcomma(): antlr.TerminalNode | null {
        return this.getToken(jsoniqParser.Kcomma, 0);
    }
    public typeName(): TypeNameContext | null {
        return this.getRuleContext(0, TypeNameContext);
    }
    public ArgumentPlaceholder(): antlr.TerminalNode | null {
        return this.getToken(jsoniqParser.ArgumentPlaceholder, 0);
    }
    public override get ruleIndex(): number {
        return jsoniqParser.RULE_elementTest;
    }
    public override enterRule(listener: jsoniqListener): void {
        if(listener.enterElementTest) {
             listener.enterElementTest(this);
        }
    }
    public override exitRule(listener: jsoniqListener): void {
        if(listener.exitElementTest) {
             listener.exitElementTest(this);
        }
    }
}


export class ElementNameOrWildcardContext extends antlr.ParserRuleContext {
    public constructor(parent: antlr.ParserRuleContext | null, invokingState: number) {
        super(parent, invokingState);
    }
    public elementName(): ElementNameContext | null {
        return this.getRuleContext(0, ElementNameContext);
    }
    public Kasterisk(): antlr.TerminalNode | null {
        return this.getToken(jsoniqParser.Kasterisk, 0);
    }
    public override get ruleIndex(): number {
        return jsoniqParser.RULE_elementNameOrWildcard;
    }
    public override enterRule(listener: jsoniqListener): void {
        if(listener.enterElementNameOrWildcard) {
             listener.enterElementNameOrWildcard(this);
        }
    }
    public override exitRule(listener: jsoniqListener): void {
        if(listener.exitElementNameOrWildcard) {
             listener.exitElementNameOrWildcard(this);
        }
    }
}


export class SchemaElementTestContext extends antlr.ParserRuleContext {
    public constructor(parent: antlr.ParserRuleContext | null, invokingState: number) {
        super(parent, invokingState);
    }
    public Kschema_element(): antlr.TerminalNode {
        return this.getToken(jsoniqParser.Kschema_element, 0)!;
    }
    public Klparen(): antlr.TerminalNode {
        return this.getToken(jsoniqParser.Klparen, 0)!;
    }
    public elementDeclaration(): ElementDeclarationContext {
        return this.getRuleContext(0, ElementDeclarationContext)!;
    }
    public Krparen(): antlr.TerminalNode {
        return this.getToken(jsoniqParser.Krparen, 0)!;
    }
    public override get ruleIndex(): number {
        return jsoniqParser.RULE_schemaElementTest;
    }
    public override enterRule(listener: jsoniqListener): void {
        if(listener.enterSchemaElementTest) {
             listener.enterSchemaElementTest(this);
        }
    }
    public override exitRule(listener: jsoniqListener): void {
        if(listener.exitSchemaElementTest) {
             listener.exitSchemaElementTest(this);
        }
    }
}


export class ElementDeclarationContext extends antlr.ParserRuleContext {
    public constructor(parent: antlr.ParserRuleContext | null, invokingState: number) {
        super(parent, invokingState);
    }
    public elementName(): ElementNameContext {
        return this.getRuleContext(0, ElementNameContext)!;
    }
    public override get ruleIndex(): number {
        return jsoniqParser.RULE_elementDeclaration;
    }
    public override enterRule(listener: jsoniqListener): void {
        if(listener.enterElementDeclaration) {
             listener.enterElementDeclaration(this);
        }
    }
    public override exitRule(listener: jsoniqListener): void {
        if(listener.exitElementDeclaration) {
             listener.exitElementDeclaration(this);
        }
    }
}


export class AttributeNameContext extends antlr.ParserRuleContext {
    public constructor(parent: antlr.ParserRuleContext | null, invokingState: number) {
        super(parent, invokingState);
    }
    public qname(): QnameContext {
        return this.getRuleContext(0, QnameContext)!;
    }
    public override get ruleIndex(): number {
        return jsoniqParser.RULE_attributeName;
    }
    public override enterRule(listener: jsoniqListener): void {
        if(listener.enterAttributeName) {
             listener.enterAttributeName(this);
        }
    }
    public override exitRule(listener: jsoniqListener): void {
        if(listener.exitAttributeName) {
             listener.exitAttributeName(this);
        }
    }
}


export class ElementNameContext extends antlr.ParserRuleContext {
    public constructor(parent: antlr.ParserRuleContext | null, invokingState: number) {
        super(parent, invokingState);
    }
    public qname(): QnameContext {
        return this.getRuleContext(0, QnameContext)!;
    }
    public override get ruleIndex(): number {
        return jsoniqParser.RULE_elementName;
    }
    public override enterRule(listener: jsoniqListener): void {
        if(listener.enterElementName) {
             listener.enterElementName(this);
        }
    }
    public override exitRule(listener: jsoniqListener): void {
        if(listener.exitElementName) {
             listener.exitElementName(this);
        }
    }
}


export class SimpleTypeNameContext extends antlr.ParserRuleContext {
    public constructor(parent: antlr.ParserRuleContext | null, invokingState: number) {
        super(parent, invokingState);
    }
    public typeName(): TypeNameContext {
        return this.getRuleContext(0, TypeNameContext)!;
    }
    public override get ruleIndex(): number {
        return jsoniqParser.RULE_simpleTypeName;
    }
    public override enterRule(listener: jsoniqListener): void {
        if(listener.enterSimpleTypeName) {
             listener.enterSimpleTypeName(this);
        }
    }
    public override exitRule(listener: jsoniqListener): void {
        if(listener.exitSimpleTypeName) {
             listener.exitSimpleTypeName(this);
        }
    }
}


export class TypeNameContext extends antlr.ParserRuleContext {
    public constructor(parent: antlr.ParserRuleContext | null, invokingState: number) {
        super(parent, invokingState);
    }
    public qname(): QnameContext {
        return this.getRuleContext(0, QnameContext)!;
    }
    public override get ruleIndex(): number {
        return jsoniqParser.RULE_typeName;
    }
    public override enterRule(listener: jsoniqListener): void {
        if(listener.enterTypeName) {
             listener.enterTypeName(this);
        }
    }
    public override exitRule(listener: jsoniqListener): void {
        if(listener.exitTypeName) {
             listener.exitTypeName(this);
        }
    }
}


export class SequenceTypeContext extends antlr.ParserRuleContext {
    public _item?: ItemTypeContext;
    public _s180?: Token | null;
    public _question: antlr.Token[] = [];
    public _s10?: Token | null;
    public _star: antlr.Token[] = [];
    public _s46?: Token | null;
    public _plus: antlr.Token[] = [];
    public constructor(parent: antlr.ParserRuleContext | null, invokingState: number) {
        super(parent, invokingState);
    }
    public Klparen(): antlr.TerminalNode | null {
        return this.getToken(jsoniqParser.Klparen, 0);
    }
    public Krparen(): antlr.TerminalNode | null {
        return this.getToken(jsoniqParser.Krparen, 0);
    }
    public itemType(): ItemTypeContext | null {
        return this.getRuleContext(0, ItemTypeContext);
    }
    public ArgumentPlaceholder(): antlr.TerminalNode | null {
        return this.getToken(jsoniqParser.ArgumentPlaceholder, 0);
    }
    public Kasterisk(): antlr.TerminalNode | null {
        return this.getToken(jsoniqParser.Kasterisk, 0);
    }
    public Kplus(): antlr.TerminalNode | null {
        return this.getToken(jsoniqParser.Kplus, 0);
    }
    public override get ruleIndex(): number {
        return jsoniqParser.RULE_sequenceType;
    }
    public override enterRule(listener: jsoniqListener): void {
        if(listener.enterSequenceType) {
             listener.enterSequenceType(this);
        }
    }
    public override exitRule(listener: jsoniqListener): void {
        if(listener.exitSequenceType) {
             listener.exitSequenceType(this);
        }
    }
}


export class ObjectConstructorContext extends antlr.ParserRuleContext {
    public _s58?: Token | null;
    public _merge_operator: antlr.Token[] = [];
    public constructor(parent: antlr.ParserRuleContext | null, invokingState: number) {
        super(parent, invokingState);
    }
    public Klbrace(): antlr.TerminalNode | null {
        return this.getToken(jsoniqParser.Klbrace, 0);
    }
    public Krbrace(): antlr.TerminalNode | null {
        return this.getToken(jsoniqParser.Krbrace, 0);
    }
    public pairConstructor(): PairConstructorContext[];
    public pairConstructor(i: number): PairConstructorContext | null;
    public pairConstructor(i?: number): PairConstructorContext[] | PairConstructorContext | null {
        if (i === undefined) {
            return this.getRuleContexts(PairConstructorContext);
        }

        return this.getRuleContext(i, PairConstructorContext);
    }
    public Kcomma(): antlr.TerminalNode[];
    public Kcomma(i: number): antlr.TerminalNode | null;
    public Kcomma(i?: number): antlr.TerminalNode | null | antlr.TerminalNode[] {
    	if (i === undefined) {
    		return this.getTokens(jsoniqParser.Kcomma);
    	} else {
    		return this.getToken(jsoniqParser.Kcomma, i);
    	}
    }
    public expr(): ExprContext | null {
        return this.getRuleContext(0, ExprContext);
    }
    public Kobject_end(): antlr.TerminalNode | null {
        return this.getToken(jsoniqParser.Kobject_end, 0);
    }
    public Kobject_start(): antlr.TerminalNode | null {
        return this.getToken(jsoniqParser.Kobject_start, 0);
    }
    public override get ruleIndex(): number {
        return jsoniqParser.RULE_objectConstructor;
    }
    public override enterRule(listener: jsoniqListener): void {
        if(listener.enterObjectConstructor) {
             listener.enterObjectConstructor(this);
        }
    }
    public override exitRule(listener: jsoniqListener): void {
        if(listener.exitObjectConstructor) {
             listener.exitObjectConstructor(this);
        }
    }
}


export class ItemTypeContext extends antlr.ParserRuleContext {
    public constructor(parent: antlr.ParserRuleContext | null, invokingState: number) {
        super(parent, invokingState);
    }
    public qname(): QnameContext | null {
        return this.getRuleContext(0, QnameContext);
    }
    public NullLiteral(): antlr.TerminalNode | null {
        return this.getToken(jsoniqParser.NullLiteral, 0);
    }
    public functionTest(): FunctionTestContext | null {
        return this.getRuleContext(0, FunctionTestContext);
    }
    public override get ruleIndex(): number {
        return jsoniqParser.RULE_itemType;
    }
    public override enterRule(listener: jsoniqListener): void {
        if(listener.enterItemType) {
             listener.enterItemType(this);
        }
    }
    public override exitRule(listener: jsoniqListener): void {
        if(listener.exitItemType) {
             listener.exitItemType(this);
        }
    }
}


export class FunctionTestContext extends antlr.ParserRuleContext {
    public constructor(parent: antlr.ParserRuleContext | null, invokingState: number) {
        super(parent, invokingState);
    }
    public anyFunctionTest(): AnyFunctionTestContext | null {
        return this.getRuleContext(0, AnyFunctionTestContext);
    }
    public typedFunctionTest(): TypedFunctionTestContext | null {
        return this.getRuleContext(0, TypedFunctionTestContext);
    }
    public override get ruleIndex(): number {
        return jsoniqParser.RULE_functionTest;
    }
    public override enterRule(listener: jsoniqListener): void {
        if(listener.enterFunctionTest) {
             listener.enterFunctionTest(this);
        }
    }
    public override exitRule(listener: jsoniqListener): void {
        if(listener.exitFunctionTest) {
             listener.exitFunctionTest(this);
        }
    }
}


export class AnyFunctionTestContext extends antlr.ParserRuleContext {
    public constructor(parent: antlr.ParserRuleContext | null, invokingState: number) {
        super(parent, invokingState);
    }
    public Kfunction(): antlr.TerminalNode {
        return this.getToken(jsoniqParser.Kfunction, 0)!;
    }
    public Klparen(): antlr.TerminalNode {
        return this.getToken(jsoniqParser.Klparen, 0)!;
    }
    public Kasterisk(): antlr.TerminalNode {
        return this.getToken(jsoniqParser.Kasterisk, 0)!;
    }
    public Krparen(): antlr.TerminalNode {
        return this.getToken(jsoniqParser.Krparen, 0)!;
    }
    public override get ruleIndex(): number {
        return jsoniqParser.RULE_anyFunctionTest;
    }
    public override enterRule(listener: jsoniqListener): void {
        if(listener.enterAnyFunctionTest) {
             listener.enterAnyFunctionTest(this);
        }
    }
    public override exitRule(listener: jsoniqListener): void {
        if(listener.exitAnyFunctionTest) {
             listener.exitAnyFunctionTest(this);
        }
    }
}


export class TypedFunctionTestContext extends antlr.ParserRuleContext {
    public _sequenceType?: SequenceTypeContext;
    public _st: SequenceTypeContext[] = [];
    public _rt?: SequenceTypeContext;
    public constructor(parent: antlr.ParserRuleContext | null, invokingState: number) {
        super(parent, invokingState);
    }
    public Kfunction(): antlr.TerminalNode {
        return this.getToken(jsoniqParser.Kfunction, 0)!;
    }
    public Klparen(): antlr.TerminalNode {
        return this.getToken(jsoniqParser.Klparen, 0)!;
    }
    public Krparen(): antlr.TerminalNode {
        return this.getToken(jsoniqParser.Krparen, 0)!;
    }
    public Kas(): antlr.TerminalNode {
        return this.getToken(jsoniqParser.Kas, 0)!;
    }
    public sequenceType(): SequenceTypeContext[];
    public sequenceType(i: number): SequenceTypeContext | null;
    public sequenceType(i?: number): SequenceTypeContext[] | SequenceTypeContext | null {
        if (i === undefined) {
            return this.getRuleContexts(SequenceTypeContext);
        }

        return this.getRuleContext(i, SequenceTypeContext);
    }
    public Kcomma(): antlr.TerminalNode[];
    public Kcomma(i: number): antlr.TerminalNode | null;
    public Kcomma(i?: number): antlr.TerminalNode | null | antlr.TerminalNode[] {
    	if (i === undefined) {
    		return this.getTokens(jsoniqParser.Kcomma);
    	} else {
    		return this.getToken(jsoniqParser.Kcomma, i);
    	}
    }
    public override get ruleIndex(): number {
        return jsoniqParser.RULE_typedFunctionTest;
    }
    public override enterRule(listener: jsoniqListener): void {
        if(listener.enterTypedFunctionTest) {
             listener.enterTypedFunctionTest(this);
        }
    }
    public override exitRule(listener: jsoniqListener): void {
        if(listener.exitTypedFunctionTest) {
             listener.exitTypedFunctionTest(this);
        }
    }
}


export class SingleTypeContext extends antlr.ParserRuleContext {
    public _item?: ItemTypeContext;
    public _s180?: Token | null;
    public _question: antlr.Token[] = [];
    public constructor(parent: antlr.ParserRuleContext | null, invokingState: number) {
        super(parent, invokingState);
    }
    public itemType(): ItemTypeContext {
        return this.getRuleContext(0, ItemTypeContext)!;
    }
    public ArgumentPlaceholder(): antlr.TerminalNode | null {
        return this.getToken(jsoniqParser.ArgumentPlaceholder, 0);
    }
    public override get ruleIndex(): number {
        return jsoniqParser.RULE_singleType;
    }
    public override enterRule(listener: jsoniqListener): void {
        if(listener.enterSingleType) {
             listener.enterSingleType(this);
        }
    }
    public override exitRule(listener: jsoniqListener): void {
        if(listener.exitSingleType) {
             listener.exitSingleType(this);
        }
    }
}


export class PairConstructorContext extends antlr.ParserRuleContext {
    public _lhs?: ExprSingleContext;
    public _rhs?: ExprSingleContext;
    public constructor(parent: antlr.ParserRuleContext | null, invokingState: number) {
        super(parent, invokingState);
    }
    public Kcolon(): antlr.TerminalNode | null {
        return this.getToken(jsoniqParser.Kcolon, 0);
    }
    public ArgumentPlaceholder(): antlr.TerminalNode | null {
        return this.getToken(jsoniqParser.ArgumentPlaceholder, 0);
    }
    public exprSingle(): ExprSingleContext[];
    public exprSingle(i: number): ExprSingleContext | null;
    public exprSingle(i?: number): ExprSingleContext[] | ExprSingleContext | null {
        if (i === undefined) {
            return this.getRuleContexts(ExprSingleContext);
        }

        return this.getRuleContext(i, ExprSingleContext);
    }
    public override get ruleIndex(): number {
        return jsoniqParser.RULE_pairConstructor;
    }
    public override enterRule(listener: jsoniqListener): void {
        if(listener.enterPairConstructor) {
             listener.enterPairConstructor(this);
        }
    }
    public override exitRule(listener: jsoniqListener): void {
        if(listener.exitPairConstructor) {
             listener.exitPairConstructor(this);
        }
    }
}


export class ArrayConstructorContext extends antlr.ParserRuleContext {
    public constructor(parent: antlr.ParserRuleContext | null, invokingState: number) {
        super(parent, invokingState);
    }
    public Klbracket(): antlr.TerminalNode {
        return this.getToken(jsoniqParser.Klbracket, 0)!;
    }
    public Krbracket(): antlr.TerminalNode {
        return this.getToken(jsoniqParser.Krbracket, 0)!;
    }
    public expr(): ExprContext | null {
        return this.getRuleContext(0, ExprContext);
    }
    public override get ruleIndex(): number {
        return jsoniqParser.RULE_arrayConstructor;
    }
    public override enterRule(listener: jsoniqListener): void {
        if(listener.enterArrayConstructor) {
             listener.enterArrayConstructor(this);
        }
    }
    public override exitRule(listener: jsoniqListener): void {
        if(listener.exitArrayConstructor) {
             listener.exitArrayConstructor(this);
        }
    }
}


export class UriLiteralContext extends antlr.ParserRuleContext {
    public constructor(parent: antlr.ParserRuleContext | null, invokingState: number) {
        super(parent, invokingState);
    }
    public stringLiteral(): StringLiteralContext {
        return this.getRuleContext(0, StringLiteralContext)!;
    }
    public override get ruleIndex(): number {
        return jsoniqParser.RULE_uriLiteral;
    }
    public override enterRule(listener: jsoniqListener): void {
        if(listener.enterUriLiteral) {
             listener.enterUriLiteral(this);
        }
    }
    public override exitRule(listener: jsoniqListener): void {
        if(listener.exitUriLiteral) {
             listener.exitUriLiteral(this);
        }
    }
}


export class StringLiteralContext extends antlr.ParserRuleContext {
    public constructor(parent: antlr.ParserRuleContext | null, invokingState: number) {
        super(parent, invokingState);
    }
    public STRING(): antlr.TerminalNode {
        return this.getToken(jsoniqParser.STRING, 0)!;
    }
    public override get ruleIndex(): number {
        return jsoniqParser.RULE_stringLiteral;
    }
    public override enterRule(listener: jsoniqListener): void {
        if(listener.enterStringLiteral) {
             listener.enterStringLiteral(this);
        }
    }
    public override exitRule(listener: jsoniqListener): void {
        if(listener.exitStringLiteral) {
             listener.exitStringLiteral(this);
        }
    }
}


export class KeyWordsContext extends antlr.ParserRuleContext {
    public constructor(parent: antlr.ParserRuleContext | null, invokingState: number) {
        super(parent, invokingState);
    }
    public Kjsoniq(): antlr.TerminalNode | null {
        return this.getToken(jsoniqParser.Kjsoniq, 0);
    }
    public Kand(): antlr.TerminalNode | null {
        return this.getToken(jsoniqParser.Kand, 0);
    }
    public Kcast(): antlr.TerminalNode | null {
        return this.getToken(jsoniqParser.Kcast, 0);
    }
    public Kcastable(): antlr.TerminalNode | null {
        return this.getToken(jsoniqParser.Kcastable, 0);
    }
    public Kcollation(): antlr.TerminalNode | null {
        return this.getToken(jsoniqParser.Kcollation, 0);
    }
    public Kcontext(): antlr.TerminalNode | null {
        return this.getToken(jsoniqParser.Kcontext, 0);
    }
    public Kdeclare(): antlr.TerminalNode | null {
        return this.getToken(jsoniqParser.Kdeclare, 0);
    }
    public Kdefault(): antlr.TerminalNode | null {
        return this.getToken(jsoniqParser.Kdefault, 0);
    }
    public Kelse(): antlr.TerminalNode | null {
        return this.getToken(jsoniqParser.Kelse, 0);
    }
    public Kgreatest(): antlr.TerminalNode | null {
        return this.getToken(jsoniqParser.Kgreatest, 0);
    }
    public Kinstance(): antlr.TerminalNode | null {
        return this.getToken(jsoniqParser.Kinstance, 0);
    }
    public Kstatically(): antlr.TerminalNode | null {
        return this.getToken(jsoniqParser.Kstatically, 0);
    }
    public Kis(): antlr.TerminalNode | null {
        return this.getToken(jsoniqParser.Kis, 0);
    }
    public Kitem(): antlr.TerminalNode | null {
        return this.getToken(jsoniqParser.Kitem, 0);
    }
    public Kleast(): antlr.TerminalNode | null {
        return this.getToken(jsoniqParser.Kleast, 0);
    }
    public Knot(): antlr.TerminalNode | null {
        return this.getToken(jsoniqParser.Knot, 0);
    }
    public NullLiteral(): antlr.TerminalNode | null {
        return this.getToken(jsoniqParser.NullLiteral, 0);
    }
    public Kof(): antlr.TerminalNode | null {
        return this.getToken(jsoniqParser.Kof, 0);
    }
    public Kor(): antlr.TerminalNode | null {
        return this.getToken(jsoniqParser.Kor, 0);
    }
    public Kthen(): antlr.TerminalNode | null {
        return this.getToken(jsoniqParser.Kthen, 0);
    }
    public Kto(): antlr.TerminalNode | null {
        return this.getToken(jsoniqParser.Kto, 0);
    }
    public Ktreat(): antlr.TerminalNode | null {
        return this.getToken(jsoniqParser.Ktreat, 0);
    }
    public Ktypeswitch(): antlr.TerminalNode | null {
        return this.getToken(jsoniqParser.Ktypeswitch, 0);
    }
    public Kversion(): antlr.TerminalNode | null {
        return this.getToken(jsoniqParser.Kversion, 0);
    }
    public Kswitch(): antlr.TerminalNode | null {
        return this.getToken(jsoniqParser.Kswitch, 0);
    }
    public Kcase(): antlr.TerminalNode | null {
        return this.getToken(jsoniqParser.Kcase, 0);
    }
    public Ktry(): antlr.TerminalNode | null {
        return this.getToken(jsoniqParser.Ktry, 0);
    }
    public Kcatch(): antlr.TerminalNode | null {
        return this.getToken(jsoniqParser.Kcatch, 0);
    }
    public Ksome(): antlr.TerminalNode | null {
        return this.getToken(jsoniqParser.Ksome, 0);
    }
    public Kevery(): antlr.TerminalNode | null {
        return this.getToken(jsoniqParser.Kevery, 0);
    }
    public Ksatisfies(): antlr.TerminalNode | null {
        return this.getToken(jsoniqParser.Ksatisfies, 0);
    }
    public Kstable(): antlr.TerminalNode | null {
        return this.getToken(jsoniqParser.Kstable, 0);
    }
    public Kvariable(): antlr.TerminalNode | null {
        return this.getToken(jsoniqParser.Kvariable, 0);
    }
    public Kascending(): antlr.TerminalNode | null {
        return this.getToken(jsoniqParser.Kascending, 0);
    }
    public Kdescending(): antlr.TerminalNode | null {
        return this.getToken(jsoniqParser.Kdescending, 0);
    }
    public Kempty(): antlr.TerminalNode | null {
        return this.getToken(jsoniqParser.Kempty, 0);
    }
    public Kallowing(): antlr.TerminalNode | null {
        return this.getToken(jsoniqParser.Kallowing, 0);
    }
    public Kas(): antlr.TerminalNode | null {
        return this.getToken(jsoniqParser.Kas, 0);
    }
    public Kat(): antlr.TerminalNode | null {
        return this.getToken(jsoniqParser.Kat, 0);
    }
    public Kin(): antlr.TerminalNode | null {
        return this.getToken(jsoniqParser.Kin, 0);
    }
    public Kif(): antlr.TerminalNode | null {
        return this.getToken(jsoniqParser.Kif, 0);
    }
    public Kfor(): antlr.TerminalNode | null {
        return this.getToken(jsoniqParser.Kfor, 0);
    }
    public Klet(): antlr.TerminalNode | null {
        return this.getToken(jsoniqParser.Klet, 0);
    }
    public Kwhere(): antlr.TerminalNode | null {
        return this.getToken(jsoniqParser.Kwhere, 0);
    }
    public Kgroup(): antlr.TerminalNode | null {
        return this.getToken(jsoniqParser.Kgroup, 0);
    }
    public Kby(): antlr.TerminalNode | null {
        return this.getToken(jsoniqParser.Kby, 0);
    }
    public Korder(): antlr.TerminalNode | null {
        return this.getToken(jsoniqParser.Korder, 0);
    }
    public Kcount(): antlr.TerminalNode | null {
        return this.getToken(jsoniqParser.Kcount, 0);
    }
    public Kreturn(): antlr.TerminalNode | null {
        return this.getToken(jsoniqParser.Kreturn, 0);
    }
    public Kunordered(): antlr.TerminalNode | null {
        return this.getToken(jsoniqParser.Kunordered, 0);
    }
    public Ktrue(): antlr.TerminalNode | null {
        return this.getToken(jsoniqParser.Ktrue, 0);
    }
    public Kfalse(): antlr.TerminalNode | null {
        return this.getToken(jsoniqParser.Kfalse, 0);
    }
    public Ktype(): antlr.TerminalNode | null {
        return this.getToken(jsoniqParser.Ktype, 0);
    }
    public Kinsert(): antlr.TerminalNode | null {
        return this.getToken(jsoniqParser.Kinsert, 0);
    }
    public Kdelete(): antlr.TerminalNode | null {
        return this.getToken(jsoniqParser.Kdelete, 0);
    }
    public Krename(): antlr.TerminalNode | null {
        return this.getToken(jsoniqParser.Krename, 0);
    }
    public Kreplace(): antlr.TerminalNode | null {
        return this.getToken(jsoniqParser.Kreplace, 0);
    }
    public Kappend(): antlr.TerminalNode | null {
        return this.getToken(jsoniqParser.Kappend, 0);
    }
    public Kcopy(): antlr.TerminalNode | null {
        return this.getToken(jsoniqParser.Kcopy, 0);
    }
    public Kmodify(): antlr.TerminalNode | null {
        return this.getToken(jsoniqParser.Kmodify, 0);
    }
    public Kinto(): antlr.TerminalNode | null {
        return this.getToken(jsoniqParser.Kinto, 0);
    }
    public Kvalue(): antlr.TerminalNode | null {
        return this.getToken(jsoniqParser.Kvalue, 0);
    }
    public Kwith(): antlr.TerminalNode | null {
        return this.getToken(jsoniqParser.Kwith, 0);
    }
    public Kposition(): antlr.TerminalNode | null {
        return this.getToken(jsoniqParser.Kposition, 0);
    }
    public Kvalidate(): antlr.TerminalNode | null {
        return this.getToken(jsoniqParser.Kvalidate, 0);
    }
    public Kannotate(): antlr.TerminalNode | null {
        return this.getToken(jsoniqParser.Kannotate, 0);
    }
    public Kbreak(): antlr.TerminalNode | null {
        return this.getToken(jsoniqParser.Kbreak, 0);
    }
    public Kloop(): antlr.TerminalNode | null {
        return this.getToken(jsoniqParser.Kloop, 0);
    }
    public Kcontinue(): antlr.TerminalNode | null {
        return this.getToken(jsoniqParser.Kcontinue, 0);
    }
    public Kexit(): antlr.TerminalNode | null {
        return this.getToken(jsoniqParser.Kexit, 0);
    }
    public Kreturning(): antlr.TerminalNode | null {
        return this.getToken(jsoniqParser.Kreturning, 0);
    }
    public Kwhile(): antlr.TerminalNode | null {
        return this.getToken(jsoniqParser.Kwhile, 0);
    }
    public Kjson(): antlr.TerminalNode | null {
        return this.getToken(jsoniqParser.Kjson, 0);
    }
    public Ktext(): antlr.TerminalNode | null {
        return this.getToken(jsoniqParser.Ktext, 0);
    }
    public Kupdating(): antlr.TerminalNode | null {
        return this.getToken(jsoniqParser.Kupdating, 0);
    }
    public Kcreate(): antlr.TerminalNode | null {
        return this.getToken(jsoniqParser.Kcreate, 0);
    }
    public Kcollection(): antlr.TerminalNode | null {
        return this.getToken(jsoniqParser.Kcollection, 0);
    }
    public Ktable(): antlr.TerminalNode | null {
        return this.getToken(jsoniqParser.Ktable, 0);
    }
    public Kdeltafile(): antlr.TerminalNode | null {
        return this.getToken(jsoniqParser.Kdeltafile, 0);
    }
    public Kicebergtable(): antlr.TerminalNode | null {
        return this.getToken(jsoniqParser.Kicebergtable, 0);
    }
    public Ktruncate(): antlr.TerminalNode | null {
        return this.getToken(jsoniqParser.Ktruncate, 0);
    }
    public Kfirst(): antlr.TerminalNode | null {
        return this.getToken(jsoniqParser.Kfirst, 0);
    }
    public Klast(): antlr.TerminalNode | null {
        return this.getToken(jsoniqParser.Klast, 0);
    }
    public Kfrom(): antlr.TerminalNode | null {
        return this.getToken(jsoniqParser.Kfrom, 0);
    }
    public Kedit(): antlr.TerminalNode | null {
        return this.getToken(jsoniqParser.Kedit, 0);
    }
    public Kbefore(): antlr.TerminalNode | null {
        return this.getToken(jsoniqParser.Kbefore, 0);
    }
    public Kafter(): antlr.TerminalNode | null {
        return this.getToken(jsoniqParser.Kafter, 0);
    }
    public Kimport(): antlr.TerminalNode | null {
        return this.getToken(jsoniqParser.Kimport, 0);
    }
    public Kschema(): antlr.TerminalNode | null {
        return this.getToken(jsoniqParser.Kschema, 0);
    }
    public Knamespace(): antlr.TerminalNode | null {
        return this.getToken(jsoniqParser.Knamespace, 0);
    }
    public Kelement(): antlr.TerminalNode | null {
        return this.getToken(jsoniqParser.Kelement, 0);
    }
    public Kslash(): antlr.TerminalNode | null {
        return this.getToken(jsoniqParser.Kslash, 0);
    }
    public Kdslash(): antlr.TerminalNode | null {
        return this.getToken(jsoniqParser.Kdslash, 0);
    }
    public Kat_symbol(): antlr.TerminalNode | null {
        return this.getToken(jsoniqParser.Kat_symbol, 0);
    }
    public Kchild(): antlr.TerminalNode | null {
        return this.getToken(jsoniqParser.Kchild, 0);
    }
    public Kdescendant(): antlr.TerminalNode | null {
        return this.getToken(jsoniqParser.Kdescendant, 0);
    }
    public Kattribute(): antlr.TerminalNode | null {
        return this.getToken(jsoniqParser.Kattribute, 0);
    }
    public Kself(): antlr.TerminalNode | null {
        return this.getToken(jsoniqParser.Kself, 0);
    }
    public Kdescendant_or_self(): antlr.TerminalNode | null {
        return this.getToken(jsoniqParser.Kdescendant_or_self, 0);
    }
    public Kfollowing_sibling(): antlr.TerminalNode | null {
        return this.getToken(jsoniqParser.Kfollowing_sibling, 0);
    }
    public Kfollowing(): antlr.TerminalNode | null {
        return this.getToken(jsoniqParser.Kfollowing, 0);
    }
    public Kparent(): antlr.TerminalNode | null {
        return this.getToken(jsoniqParser.Kparent, 0);
    }
    public Kancestor(): antlr.TerminalNode | null {
        return this.getToken(jsoniqParser.Kancestor, 0);
    }
    public Kpreceding_sibling(): antlr.TerminalNode | null {
        return this.getToken(jsoniqParser.Kpreceding_sibling, 0);
    }
    public Kpreceding(): antlr.TerminalNode | null {
        return this.getToken(jsoniqParser.Kpreceding, 0);
    }
    public Kancestor_or_self(): antlr.TerminalNode | null {
        return this.getToken(jsoniqParser.Kancestor_or_self, 0);
    }
    public Knode(): antlr.TerminalNode | null {
        return this.getToken(jsoniqParser.Knode, 0);
    }
    public Kbinary(): antlr.TerminalNode | null {
        return this.getToken(jsoniqParser.Kbinary, 0);
    }
    public Kdocument(): antlr.TerminalNode | null {
        return this.getToken(jsoniqParser.Kdocument, 0);
    }
    public Kdocument_node(): antlr.TerminalNode | null {
        return this.getToken(jsoniqParser.Kdocument_node, 0);
    }
    public Kpi(): antlr.TerminalNode | null {
        return this.getToken(jsoniqParser.Kpi, 0);
    }
    public Knamespace_node(): antlr.TerminalNode | null {
        return this.getToken(jsoniqParser.Knamespace_node, 0);
    }
    public Kschema_attribute(): antlr.TerminalNode | null {
        return this.getToken(jsoniqParser.Kschema_attribute, 0);
    }
    public Kschema_element(): antlr.TerminalNode | null {
        return this.getToken(jsoniqParser.Kschema_element, 0);
    }
    public Karray_node(): antlr.TerminalNode | null {
        return this.getToken(jsoniqParser.Karray_node, 0);
    }
    public Kboolean_node(): antlr.TerminalNode | null {
        return this.getToken(jsoniqParser.Kboolean_node, 0);
    }
    public Knull_node(): antlr.TerminalNode | null {
        return this.getToken(jsoniqParser.Knull_node, 0);
    }
    public Knumber_node(): antlr.TerminalNode | null {
        return this.getToken(jsoniqParser.Knumber_node, 0);
    }
    public Kobject_node(): antlr.TerminalNode | null {
        return this.getToken(jsoniqParser.Kobject_node, 0);
    }
    public Kcomment(): antlr.TerminalNode | null {
        return this.getToken(jsoniqParser.Kcomment, 0);
    }
    public override get ruleIndex(): number {
        return jsoniqParser.RULE_keyWords;
    }
    public override enterRule(listener: jsoniqListener): void {
        if(listener.enterKeyWords) {
             listener.enterKeyWords(this);
        }
    }
    public override exitRule(listener: jsoniqListener): void {
        if(listener.exitKeyWords) {
             listener.exitKeyWords(this);
        }
    }
}
