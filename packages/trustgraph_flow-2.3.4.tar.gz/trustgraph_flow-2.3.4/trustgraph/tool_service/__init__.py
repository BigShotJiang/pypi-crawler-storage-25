# Tool service implementations
