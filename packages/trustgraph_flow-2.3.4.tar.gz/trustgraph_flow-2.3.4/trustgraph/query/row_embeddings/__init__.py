"""
Row embeddings query modules.
"""
