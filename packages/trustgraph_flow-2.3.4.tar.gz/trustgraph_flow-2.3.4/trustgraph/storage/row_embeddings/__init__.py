"""
Row embeddings storage modules.
"""
