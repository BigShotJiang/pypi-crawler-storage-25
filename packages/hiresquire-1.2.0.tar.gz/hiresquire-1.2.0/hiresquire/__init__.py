"""
HireSquire - AI-Powered Candidate Screening SDK
================================================

This package provides tools and SDK for integrating HireSquire's
candidate screening API into AI agents, workflows, and applications.

Optional LangChain integration available as extra dependency.

Installation:
    pip install hiresquire

Quick Start:
    from hiresquire import create_screening_job, get_screening_status
    
    # Submit a job
    result = create_screening_job(
        title="Senior Developer",
        description="Looking for Python developer...",
        resumes=[{"filename": "john.pdf", "content": "John Doe\n5 years Python..."}]
    )
    
    # Check status
    status = get_screening_status(job_id=result["job_id"])

Environment Variables:
    HIRESQUIRE_API_TOKEN: Your API token from hiresquire dashboard
    HIRESQUIRE_BASE_URL: API base URL (default: https://api.hiresquireai.com/api/v1)
"""

from .tools import (
    create_screening_job,
    get_screening_status,
    get_screening_results,
    wait_for_screening_completion,
    generate_candidate_email,
    get_candidates_by_score,
    get_hiresquire_tools,
    read_resume_from_file,
    compare_candidates,
    get_credit_balance,
    estimate_screening_cost,
    list_credit_packs,
)
import os
from typing import Optional, List, Dict, Any

__version__ = "1.2.0"


class HireSquire:
    """
    HireSquire SDK client.
    
    Example:
        client = HireSquire("YOUR_API_TOKEN")
        job = client.screen("Job title", "Job description", ["resume1.txt", "resume2.txt"])
        results = client.wait_for_completion(job["job_id"])
    """
    
    def __init__(self, api_token: str, base_url: Optional[str] = None):
        self.api_token = api_token
        self.base_url = base_url or os.environ.get("HIRESQUIRE_BASE_URL", "https://api.hiresquireai.com/api/v1")
        
        # Set environment variables for the tools
        os.environ["HIRESQUIRE_API_TOKEN"] = api_token
        if base_url:
            os.environ["HIRESQUIRE_BASE_URL"] = base_url
    
    def screen(self, title: str, description: str, resumes: List[str], **kwargs) -> Dict[str, Any]:
        """Submit a screening job. Resumes can be file paths or list of content dicts."""
        resume_objects = []
        
        for resume in resumes:
            if isinstance(resume, str) and os.path.exists(resume):
                resume_objects.append(read_resume_from_file(resume))
            elif isinstance(resume, dict) and "filename" in resume and "content" in resume:
                resume_objects.append(resume)
            else:
                raise ValueError(f"Invalid resume: {resume}. Must be file path or dict with filename and content.")
        
        return create_screening_job(title, description, resume_objects, **kwargs)
    
    def wait_for_completion(self, job_id: int, **kwargs) -> Dict[str, Any]:
        """Wait for screening job to complete and return results."""
        return wait_for_screening_completion(job_id, **kwargs)
    
    def get_results(self, job_id: int, **kwargs) -> Dict[str, Any]:
        """Get results for a completed job."""
        return get_screening_results(job_id, **kwargs)
    
    def get_status(self, job_id: int) -> Dict[str, Any]:
        """Get status of a job."""
        return get_screening_status(job_id)
    
    def generate_email(self, job_id: int, candidate_id: int, **kwargs) -> Dict[str, Any]:
        """Generate email for a candidate."""
        return generate_candidate_email(job_id, candidate_id, **kwargs)
    
    def get_credit_balance(self) -> Dict[str, Any]:
        """Get current credit balance."""
        return get_credit_balance()


__all__ = [
    "__version__",
    "HireSquire",
    "create_screening_job",
    "get_screening_status",
    "get_screening_results",
    "wait_for_screening_completion",
    "generate_candidate_email",
    "get_candidates_by_score",
    "get_hiresquire_tools",
    "read_resume_from_file",
    "compare_candidates",
    "get_credit_balance",
    "estimate_screening_cost",
    "list_credit_packs",
]
