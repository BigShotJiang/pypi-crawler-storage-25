# HireSquire Python SDK

[![PyPI Version](https://img.shields.io/pypi/v/hiresquire.svg)](https://pypi.org/project/hiresquire/)
[![Python Versions](https://img.shields.io/pypi/pyversions/hiresquire.svg)](https://pypi.org/project/hiresquire/)
[![License](https://img.shields.io/pypi/l/hiresquire.svg)](https://pypi.org/project/hiresquire/)

LangChain tools for HireSquire's AI-powered candidate screening API.

## Installation

```bash
pip install hiresquire
```

## Quick Start

### Option 1: Client Class (Recommended)
```python
from hiresquire import HireSquire

client = HireSquire("YOUR_API_TOKEN")

# Submit and wait automatically
job = client.screen(
    title="Senior Python Developer", 
    description="Looking for experienced Python developer with Django experience...",
    resumes=["./resumes/john_doe.pdf", "./resumes/jane_smith.pdf"]
)

# Get results when complete
results = client.wait_for_completion(job["job_id"])

for candidate in results["candidates"]:
    print(f"{candidate['name']}: {candidate['score']}/100")
```

### Option 2: Direct Function Calls
```python
from hiresquire import create_screening_job, get_screening_status, get_screening_results

# Submit a screening job
result = create_screening_job(
    title="Senior Python Developer",
    description="Looking for experienced Python developer with Django experience...",
    resumes=[
        {"filename": "john_doe.pdf", "content": "John Doe\n5 years Python experience..."}
    ]
)
job_id = result["job_id"]

# Poll for completion
status = get_screening_status(job_id=job_id)
while status["status"] == "processing":
    time.sleep(3)
    status = get_screening_status(job_id=job_id)

# Get results
results = get_screening_results(job_id=job_id)
for candidate in results["candidates"]:
    print(f"{candidate['name']}: {candidate['score']}/100")
```

## Environment Variables

Set these before using the SDK:

```bash
export HIRESQUIRE_API_TOKEN="your_api_token_here"
export HIRESQUIRE_BASE_URL="https://api.hiresquireai.com/api/v1"  # optional
```

## LangChain Integration

```python
from langchain.agents import AgentExecutor, create_openai_functions_agent
from langchain_openai import ChatOpenAI
from hiresquire import get_hiresquire_tools

llm = ChatOpenAI(temperature=0)
tools = get_hiresquire_tools()

agent = create_openai_functions_agent(llm, tools)
executor = AgentExecutor(agent=agent, tools=tools, verbose=True)

# Use in an agent
result = executor.invoke({
    "input": "Submit a screening job for a Python developer and find candidates with score > 80"
})
```

## Available Tools

| Tool | Description |
|------|-------------|
| `create_screening_job` | Submit a new screening job |
| `get_screening_status` | Check job status |
| `get_screening_results` | Get completed job results |
| `wait_for_screening_completion` | Poll until job completes |
| `generate_candidate_email` | Generate outreach email |
| `get_candidates_by_score` | Filter candidates by score |
| `enable_auto_reload` | Enable automatic credit reloading |
| `disable_auto_reload` | Disable automatic credit reloading |
| `get_credit_balance` | Check current credit balance |
| `estimate_screening_cost` | Estimate cost for N candidates |

## API Documentation

Full API documentation available at: https://hiresquireai.com/docs/api

## License

MIT License - see LICENSE file for details.
