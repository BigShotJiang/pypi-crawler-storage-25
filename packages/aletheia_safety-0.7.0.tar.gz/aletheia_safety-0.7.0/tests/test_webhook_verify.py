"""
ALETHEIA SDK — Webhook Signature Verification Tests
Run: python3 -m pytest sdk/python/tests/test_webhook_verify.py
"""

import hashlib
import hmac
import time

import pytest

from aletheia_safety import Aletheia, AletheiaError


SECRET = "whsec_test_secret_1234567890"
PAYLOAD = '{"event":"compound.risk_changed","compound_id":"hq-c-org-000001"}'


def make_signature(payload, secret, timestamp=None):
    ts = timestamp or int(time.time())
    if isinstance(secret, str):
        secret = secret.encode("utf-8")
    msg = f"{ts}.{payload}".encode("utf-8")
    sig = hmac.new(secret, msg, hashlib.sha256).hexdigest()
    return f"t={ts},sha256={sig}", ts


class TestVerifyWebhookSignature:
    def test_valid_signature(self):
        header, ts = make_signature(PAYLOAD, SECRET)
        result = Aletheia.verify_webhook_signature(PAYLOAD, header, SECRET)
        assert result["valid"] is True
        assert result["timestamp"] == ts

    def test_rejects_wrong_secret(self):
        header, _ = make_signature(PAYLOAD, "wrong_secret")
        with pytest.raises(AletheiaError) as exc_info:
            Aletheia.verify_webhook_signature(PAYLOAD, header, SECRET)
        assert exc_info.value.status == 400
        assert "verification failed" in str(exc_info.value).lower()

    def test_rejects_tampered_payload(self):
        header, _ = make_signature(PAYLOAD, SECRET)
        with pytest.raises(AletheiaError) as exc_info:
            Aletheia.verify_webhook_signature('{"tampered":true}', header, SECRET)
        assert "verification failed" in str(exc_info.value).lower()

    def test_rejects_expired_signature(self):
        old_ts = int(time.time()) - 600  # 10 min ago
        header, _ = make_signature(PAYLOAD, SECRET, old_ts)
        with pytest.raises(AletheiaError) as exc_info:
            Aletheia.verify_webhook_signature(PAYLOAD, header, SECRET)
        assert "expired" in str(exc_info.value).lower()

    def test_custom_tolerance(self):
        old_ts = int(time.time()) - 600
        header, _ = make_signature(PAYLOAD, SECRET, old_ts)
        result = Aletheia.verify_webhook_signature(PAYLOAD, header, SECRET, tolerance=900)
        assert result["valid"] is True

    def test_rejects_empty_header(self):
        with pytest.raises(AletheiaError) as exc_info:
            Aletheia.verify_webhook_signature(PAYLOAD, "", SECRET)
        assert exc_info.value.status == 400

    def test_rejects_none_header(self):
        with pytest.raises(AletheiaError):
            Aletheia.verify_webhook_signature(PAYLOAD, None, SECRET)

    def test_rejects_missing_secret(self):
        header, _ = make_signature(PAYLOAD, SECRET)
        with pytest.raises(AletheiaError) as exc_info:
            Aletheia.verify_webhook_signature(PAYLOAD, header, "")
        assert "secret" in str(exc_info.value).lower()

    def test_rejects_malformed_no_sha256(self):
        with pytest.raises(AletheiaError) as exc_info:
            Aletheia.verify_webhook_signature(PAYLOAD, "t=12345", SECRET)
        assert "malformed" in str(exc_info.value).lower()

    def test_rejects_malformed_no_timestamp(self):
        with pytest.raises(AletheiaError) as exc_info:
            Aletheia.verify_webhook_signature(PAYLOAD, "sha256=abcdef", SECRET)
        assert "malformed" in str(exc_info.value).lower()

    def test_accepts_bytes_payload(self):
        header, ts = make_signature(PAYLOAD, SECRET)
        result = Aletheia.verify_webhook_signature(PAYLOAD.encode("utf-8"), header, SECRET)
        assert result["valid"] is True
        assert result["timestamp"] == ts
