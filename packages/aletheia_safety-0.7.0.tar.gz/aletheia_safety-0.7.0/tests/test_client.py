"""
ALETHEIA Python SDK Tests

Unit tests with mocked HTTP — no live API dependency.

Run: python -m pytest sdk/python/tests/test_client.py
 or: python -m unittest sdk.python.tests.test_client
"""

import json
import unittest
from unittest.mock import patch, MagicMock
from http.client import HTTPResponse
from io import BytesIO
import urllib.error

import sys, os
sys.path.insert(0, os.path.join(os.path.dirname(__file__), '..'))

from aletheia_safety import Aletheia, AletheiaError, RateLimitError, Compound


def mock_response(body, status=200):
    """Create a mock urllib response."""
    data = json.dumps(body).encode()
    resp = MagicMock()
    resp.read.return_value = data
    resp.__enter__ = MagicMock(return_value=resp)
    resp.__exit__ = MagicMock(return_value=False)
    return resp


def mock_http_error(status, body=None):
    """Create a urllib.error.HTTPError."""
    body_bytes = json.dumps(body or {}).encode()
    err = urllib.error.HTTPError(
        url='http://test.com',
        code=status,
        msg='Error',
        hdrs=MagicMock(get=lambda k, d=None: d),
        fp=BytesIO(body_bytes),
    )
    return err


class TestConstructor(unittest.TestCase):
    def test_defaults(self):
        client = Aletheia()
        self.assertIsNone(client.api_key)
        self.assertEqual(client.base_url, 'https://api.aletheia.holisticquality.io/api')
        self.assertEqual(client.timeout, 30)

    def test_with_api_key(self):
        client = Aletheia(api_key='test-key')
        self.assertEqual(client.api_key, 'test-key')

    def test_custom_base_url_strips_trailing_slash(self):
        client = Aletheia(base_url='https://custom.api.com/api/')
        self.assertEqual(client.base_url, 'https://custom.api.com/api')

    def test_custom_timeout(self):
        client = Aletheia(timeout=5)
        self.assertEqual(client.timeout, 5)


class TestURLBuilding(unittest.TestCase):
    @patch('urllib.request.urlopen')
    def test_simple_path(self, mock_urlopen):
        mock_urlopen.return_value = mock_response({'hq_id': 'test'})
        client = Aletheia()
        client.compound('hq-c-org-000001')

        called_req = mock_urlopen.call_args[0][0]
        self.assertIn('/compound/hq-c-org-000001', called_req.full_url)

    @patch('urllib.request.urlopen')
    def test_params_appended(self, mock_urlopen):
        mock_urlopen.return_value = mock_response({'results': []})
        client = Aletheia()
        client.search('sodium', type='compound')

        called_req = mock_urlopen.call_args[0][0]
        self.assertIn('q=sodium', called_req.full_url)
        self.assertIn('type=compound', called_req.full_url)

    @patch('urllib.request.urlopen')
    def test_none_params_filtered(self, mock_urlopen):
        mock_urlopen.return_value = mock_response({'results': []})
        client = Aletheia()
        client.search('sodium', type=None, limit=None)

        called_req = mock_urlopen.call_args[0][0]
        self.assertIn('q=sodium', called_req.full_url)
        self.assertNotIn('type=', called_req.full_url)
        self.assertNotIn('limit=', called_req.full_url)


class TestHeaders(unittest.TestCase):
    @patch('urllib.request.urlopen')
    def test_user_agent_set(self, mock_urlopen):
        mock_urlopen.return_value = mock_response({})
        client = Aletheia()
        client.compound('test')

        called_req = mock_urlopen.call_args[0][0]
        self.assertIn('aletheia-safety-python', called_req.get_header('User-agent'))

    @patch('urllib.request.urlopen')
    def test_no_api_key_header_when_not_set(self, mock_urlopen):
        mock_urlopen.return_value = mock_response({})
        client = Aletheia()
        client.compound('test')

        called_req = mock_urlopen.call_args[0][0]
        self.assertIsNone(called_req.get_header('X-api-key'))

    @patch('urllib.request.urlopen')
    def test_api_key_header_when_set(self, mock_urlopen):
        mock_urlopen.return_value = mock_response({})
        client = Aletheia(api_key='my-key')
        client.compound('test')

        called_req = mock_urlopen.call_args[0][0]
        self.assertEqual(called_req.get_header('X-api-key'), 'my-key')


class TestResponseHandling(unittest.TestCase):
    @patch('urllib.request.urlopen')
    def test_200_returns_parsed_json(self, mock_urlopen):
        mock_urlopen.return_value = mock_response({'hq_id': 'hq-c-org-000001', 'name': 'Glyphosate'})
        client = Aletheia()
        result = client.compound('hq-c-org-000001')

        self.assertEqual(result['hq_id'], 'hq-c-org-000001')
        self.assertEqual(result['name'], 'Glyphosate')

    @patch('urllib.request.urlopen')
    def test_404_raises_aletheia_error(self, mock_urlopen):
        mock_urlopen.side_effect = mock_http_error(404, {'error': 'Not found', 'message': 'No compound'})
        client = Aletheia()

        with self.assertRaises(AletheiaError) as ctx:
            client.compound('hq-c-org-999999')
        self.assertEqual(ctx.exception.status, 404)

    @patch('urllib.request.urlopen')
    def test_500_raises_aletheia_error(self, mock_urlopen):
        mock_urlopen.side_effect = mock_http_error(500, {'error': 'Internal', 'message': 'Server error'})
        client = Aletheia()

        with self.assertRaises(AletheiaError) as ctx:
            client.compound('test')
        self.assertEqual(ctx.exception.status, 500)

    @patch('urllib.request.urlopen')
    @patch('time.sleep')
    def test_429_raises_rate_limit_error_after_retries(self, mock_sleep, mock_urlopen):
        mock_urlopen.side_effect = mock_http_error(429, {'error': 'Rate limit', 'message': 'Too many'})
        client = Aletheia()

        with self.assertRaises(RateLimitError) as ctx:
            client.compound('test')
        self.assertEqual(ctx.exception.status, 429)
        # Should have retried twice (3 attempts total)
        self.assertEqual(mock_sleep.call_count, 2)

    @patch('urllib.request.urlopen')
    def test_rate_limit_error_is_aletheia_error(self, mock_urlopen):
        mock_urlopen.side_effect = mock_http_error(429, {'error': 'Rate limit', 'message': 'Too many'})
        client = Aletheia()

        with self.assertRaises(AletheiaError):
            client.compound('test')


class TestTypeParsing(unittest.TestCase):
    def test_compound_from_dict(self):
        sample = {
            'hq_id': 'hq-c-org-000001',
            'name': 'Glyphosate',
            'risk_level': 'moderate',
            'context': 'human_adult',
        }
        compound = Compound.from_dict(sample)
        self.assertEqual(compound.hq_id, 'hq-c-org-000001')
        self.assertEqual(compound.name, 'Glyphosate')
        self.assertEqual(compound.risk_level, 'moderate')


class TestErrorProperties(unittest.TestCase):
    def test_aletheia_error_properties(self):
        err = AletheiaError(403, 'Forbidden', 'Access denied')
        self.assertEqual(err.status, 403)
        self.assertEqual(err.error, 'Forbidden')
        self.assertIn('403', str(err))
        self.assertIn('Forbidden', str(err))

    def test_rate_limit_error_is_subclass(self):
        err = RateLimitError(429, 'Rate limit', 'Too many')
        self.assertIsInstance(err, AletheiaError)
        self.assertIsInstance(err, Exception)


class TestV040Endpoints(unittest.TestCase):
    """Tests for new v0.4.0 SDK methods."""

    def setUp(self):
        self.client = Aletheia(api_key='aletheia_live_test', base_url='http://localhost/api')

    @patch('urllib.request.urlopen')
    def test_watchlist_get(self, mock_urlopen):
        mock_urlopen.return_value = mock_response({'compounds': [], 'count': 0})
        result = self.client.watchlist()
        self.assertEqual(result['count'], 0)
        call_url = mock_urlopen.call_args[0][0].full_url
        self.assertIn('/watchlist', call_url)

    @patch('urllib.request.urlopen')
    def test_watchlist_add_single(self, mock_urlopen):
        mock_urlopen.return_value = mock_response({'added': ['hq-c-org-000001']})
        result = self.client.watchlist_add('hq-c-org-000001')
        self.assertEqual(result['added'], ['hq-c-org-000001'])
        req = mock_urlopen.call_args[0][0]
        body = json.loads(req.data)
        self.assertEqual(body['compounds'], ['hq-c-org-000001'])

    @patch('urllib.request.urlopen')
    def test_watchlist_add_list(self, mock_urlopen):
        ids = ['hq-c-org-000001', 'hq-c-org-000002']
        mock_urlopen.return_value = mock_response({'added': ids})
        result = self.client.watchlist_add(ids)
        req = mock_urlopen.call_args[0][0]
        body = json.loads(req.data)
        self.assertEqual(body['compounds'], ids)

    @patch('urllib.request.urlopen')
    def test_watchlist_remove(self, mock_urlopen):
        mock_urlopen.return_value = mock_response({'removed': 'hq-c-org-000001'})
        result = self.client.watchlist_remove('hq-c-org-000001')
        req = mock_urlopen.call_args[0][0]
        self.assertEqual(req.get_method(), 'DELETE')
        self.assertIn('/watchlist/hq-c-org-000001', req.full_url)

    @patch('urllib.request.urlopen')
    def test_changelog(self, mock_urlopen):
        mock_urlopen.return_value = mock_response({'changes': [], 'total': 0})
        result = self.client.changelog(since='2026-01-01', limit=10)
        call_url = mock_urlopen.call_args[0][0].full_url
        self.assertIn('/changelog', call_url)
        self.assertIn('since=2026-01-01', call_url)

    @patch('urllib.request.urlopen')
    def test_key_rotate_updates_api_key(self, mock_urlopen):
        mock_urlopen.return_value = mock_response({'key': 'aletheia_live_newkey123'})
        result = self.client.key_rotate()
        self.assertEqual(self.client.api_key, 'aletheia_live_newkey123')
        self.assertEqual(result['key'], 'aletheia_live_newkey123')

    @patch('urllib.request.urlopen')
    def test_key_usage(self, mock_urlopen):
        mock_urlopen.return_value = mock_response({'days': 7, 'usage': []})
        result = self.client.key_usage(days=14)
        call_url = mock_urlopen.call_args[0][0].full_url
        self.assertIn('days=14', call_url)

    @patch('urllib.request.urlopen')
    def test_compound_raw(self, mock_urlopen):
        mock_urlopen.return_value = mock_response({'hq_id': 'hq-c-org-000001', 'raw': True})
        result = self.client.compound_raw('hq-c-org-000001')
        call_url = mock_urlopen.call_args[0][0].full_url
        self.assertIn('/compound/hq-c-org-000001/raw', call_url)

    @patch('urllib.request.urlopen')
    def test_product_raw(self, mock_urlopen):
        mock_urlopen.return_value = mock_response({'hq_id': 'hq-p-hom-000001', 'raw': True})
        result = self.client.product_raw('hq-p-hom-000001')
        call_url = mock_urlopen.call_args[0][0].full_url
        self.assertIn('/product/hq-p-hom-000001/raw', call_url)

    @patch('urllib.request.urlopen')
    def test_delete_helper_used_by_webhook_delete(self, mock_urlopen):
        mock_urlopen.return_value = mock_response({'deleted': True})
        result = self.client.webhook_delete('wh_abc123')
        req = mock_urlopen.call_args[0][0]
        self.assertEqual(req.get_method(), 'DELETE')


    @patch('urllib.request.urlopen')
    def test_watchlist_check_sends_post_with_compounds(self, mock_urlopen):
        mock_urlopen.return_value = mock_response({
            'matches': [{'compound_id': 'hq-c-ino-000001', 'on_watchlist': True}]
        })
        result = self.client.watchlist_check(['hq-c-ino-000001', 'hq-c-org-000002'])
        req = mock_urlopen.call_args[0][0]
        self.assertEqual(req.get_method(), 'POST')
        self.assertIn('/watchlist/check', req.full_url)
        body = json.loads(req.data)
        self.assertEqual(body['compounds'], ['hq-c-ino-000001', 'hq-c-org-000002'])


if __name__ == '__main__':
    unittest.main()
