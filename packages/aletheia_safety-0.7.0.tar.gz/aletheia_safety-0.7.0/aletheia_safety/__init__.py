"""
ALETHEIA Safety Database — Python SDK

Usage:
    from aletheia_safety import Aletheia

    client = Aletheia()                          # free tier (500 req/day)
    client = Aletheia(api_key="aletheia_live_…") # paid tier

    # Look up a compound
    compound = client.compound("hq-c-org-000001")
    compound = client.compound_by_cas("1071-83-6")

    # Search across all entity types
    results = client.search("sodium", type="compound", limit=10)

    # Compare compounds side-by-side
    comparison = client.compare(["hq-c-org-000001", "hq-c-org-000005"], context="human_adult")

    # Filter by risk level
    high_risk = client.filter(risk="high", context="food_contact")

    # Explore relationships
    graph = client.graph("hq-c-org-000001", depth=2)
"""

__version__ = "0.7.0"

# Type definitions for structured responses (v0.3.0+)
from .types import Compound, Product, Material  # noqa: F401, E402

import urllib.request
import urllib.error
import urllib.parse
import json
import time
import socket


BASE_URL = "https://api.aletheia.holisticquality.io/api"


def _safe_id(value):
    """Validate that an ID is safe for URL path interpolation (no traversal)."""
    s = str(value)
    if "/" in s or "\\" in s or ".." in s or "\x00" in s:
        raise ValueError(f"Invalid ID: contains path separator or traversal sequence: {s!r}")
    return s


class AletheiaError(Exception):
    """Base exception for ALETHEIA API errors."""
    def __init__(self, status, error, message):
        self.status = status
        self.error = error
        super().__init__(f"[{status}] {error}: {message}")


class RateLimitError(AletheiaError):
    """Raised when rate limit is exceeded (HTTP 429)."""
    pass


class Aletheia:
    """Client for the ALETHEIA Safety Database API."""

    def __init__(self, api_key=None, base_url=None, timeout=30):
        """
        Initialize the ALETHEIA client.

        Args:
            api_key: API key for paid tiers (Developer/Pro/Enterprise).
                     Omit for free public tier (500 req/day per IP).
            base_url: Override the API base URL (default: production).
            timeout: Request timeout in seconds (default: 30).
        """
        self.api_key = api_key
        self.base_url = (base_url or BASE_URL).rstrip("/")
        self.timeout = timeout

    def _request(self, path, params=None):
        """Make a GET request to the API. Retries on 429 and timeout (up to 3 attempts)."""
        url = f"{self.base_url}{path}"
        if params:
            filtered = {k: v for k, v in params.items() if v is not None}
            if filtered:
                url += "?" + urllib.parse.urlencode(filtered)

        last_error = None
        for attempt in range(3):
            req = urllib.request.Request(url)
            req.add_header("User-Agent", f"aletheia-safety-python/{__version__}")
            if self.api_key:
                req.add_header("X-API-Key", self.api_key)

            try:
                with urllib.request.urlopen(req, timeout=self.timeout) as resp:
                    return json.loads(resp.read())
            except urllib.error.HTTPError as e:
                body = {}
                try:
                    body = json.loads(e.read())
                except Exception:
                    pass
                error = body.get("error", f"HTTP {e.code}")
                message = body.get("message", e.reason)
                if e.code == 429 and attempt < 2:
                    delay = int(e.headers.get("Retry-After", 1 + attempt))
                    time.sleep(delay)
                    last_error = RateLimitError(429, error, message)
                    continue
                if e.code == 429:
                    raise RateLimitError(429, error, message)
                raise AletheiaError(e.code, error, message)
            except socket.timeout:
                if attempt < 2:
                    time.sleep(1)
                    continue
                raise AletheiaError(0, "Timeout", f"Request timed out after {self.timeout}s")

        raise last_error or AletheiaError(0, "Error", "Request failed after 3 attempts")

    def _post(self, path, data):
        """Make a POST request to the API."""
        url = f"{self.base_url}{path}"
        payload = json.dumps(data).encode()

        req = urllib.request.Request(url, data=payload, method="POST")
        req.add_header("Content-Type", "application/json")
        req.add_header("User-Agent", f"aletheia-safety-python/{__version__}")
        if self.api_key:
            req.add_header("X-API-Key", self.api_key)

        try:
            with urllib.request.urlopen(req, timeout=self.timeout) as resp:
                return json.loads(resp.read())
        except urllib.error.HTTPError as e:
            body = {}
            try:
                body = json.loads(e.read())
            except Exception:
                pass
            raise AletheiaError(e.code, body.get("error", f"HTTP {e.code}"), body.get("message", e.reason))

    def _delete(self, path, params=None):
        """Make a DELETE request to the API."""
        url = f"{self.base_url}{path}"
        if params:
            filtered = {k: v for k, v in params.items() if v is not None}
            if filtered:
                url += "?" + urllib.parse.urlencode(filtered)

        req = urllib.request.Request(url, method="DELETE")
        req.add_header("User-Agent", f"aletheia-safety-python/{__version__}")
        if self.api_key:
            req.add_header("X-API-Key", self.api_key)
        try:
            with urllib.request.urlopen(req, timeout=self.timeout) as resp:
                return json.loads(resp.read())
        except urllib.error.HTTPError as e:
            body = {}
            try:
                body = json.loads(e.read())
            except Exception:
                pass
            raise AletheiaError(e.code, body.get("error", f"HTTP {e.code}"), body.get("message", e.reason))

    # ── Compounds ─────────────────────────────────────────────────

    def compound(self, id, context=None):
        """
        Get a single compound by HQ ID.

        Args:
            id: Compound ID (e.g., "hq-c-org-000001")
            context: Safety context (e.g., "human_adult", "dog", "cat")

        Returns:
            dict with compound data including safety profile
        """
        return self._request(f"/compound/{_safe_id(id)}", {"context": context})

    def compound_by_cas(self, cas):
        """
        Look up a compound by CAS number.

        Args:
            cas: CAS registry number (e.g., "1071-83-6")

        Returns:
            dict with compound data
        """
        return self._request(f"/compound/cas/{_safe_id(cas)}")

    def compounds(self, limit=20, offset=0, search=None):
        """
        List compounds with pagination. Requires Developer+ tier.

        Args:
            limit: Results per page (max 200)
            offset: Pagination offset
            search: Optional search filter

        Returns:
            dict with results array and pagination info
        """
        return self._request("/compounds", {"limit": limit, "offset": offset, "search": search})

    def batch(self, ids, context=None, synthesize=None, detail=None, method=None):
        """
        Look up multiple compounds at once. Max IDs per request depends on tier (20 Developer, 50 Pro, 100 Enterprise).

        Args:
            ids: List of compound IDs
            context: Safety context (e.g., "human_adult")
            synthesize: Include risk synthesis (requires Developer+)
            detail: "full" for expanded data (Pro+)
            method: "GET" (default) or "POST" for large queries

        Returns:
            dict with results for each ID
        """
        if method == "POST" or len(ids) > 10:
            data = {"ids": ids}
            if context:
                data["context"] = context
            if synthesize is not None:
                data["synthesize"] = synthesize
            if detail:
                data["detail"] = detail
            return self._post("/compounds/batch", data)
        return self._request("/compounds/batch", {
            "ids": ",".join(ids), "context": context,
            "synthesize": synthesize, "detail": detail,
        })

    def compare(self, ids, context=None):
        """
        Compare 2-5 compounds side-by-side. Requires Developer+ tier.

        Args:
            ids: List of 2-5 compound IDs
            context: Safety context for comparison

        Returns:
            dict with comparison data and differentials
        """
        return self._request("/compounds/compare", {"ids": ",".join(ids), "context": context})

    # ── Search & Filter ───────────────────────────────────────────

    def search(self, query, type=None, limit=20, offset=0):
        """
        Full-text search across compounds, products, and materials.

        Args:
            query: Search term (min 2 characters)
            type: Filter by entity type ("compound", "product", "material")
            limit: Results per page (max 100)
            offset: Pagination offset

        Returns:
            dict with scored results and pagination
        """
        return self._request("/search", {"q": query, "type": type, "limit": limit, "offset": offset})

    def filter(self, risk=None, context=None, type=None, agency=None,
               hazard=None, cas_prefix=None, exposure=None,
               functional_use=None, year=None, year_min=None, year_max=None,
               limit=20, offset=0):
        """
        Filter compounds by risk level, context, regulatory agency, and more.

        Args:
            risk: Risk level ("high", "moderate", "low", "minimal")
            context: Safety context (e.g., "food_contact")
            type: Compound type (e.g., "preservative")
            agency: Regulatory agency (e.g., "EPA", "EFSA")
            hazard: Hazard classification
            cas_prefix: CAS number prefix
            exposure: Found-in category
            functional_use: EPA functional use category
            year: Year reviewed (exact)
            year_min: Year reviewed minimum
            year_max: Year reviewed maximum
            limit: Results per page
            offset: Pagination offset

        Returns:
            dict with filtered results
        """
        return self._request("/filter", {
            "risk": risk, "context": context, "type": type, "agency": agency,
            "hazard": hazard, "cas_prefix": cas_prefix, "exposure": exposure,
            "functional_use": functional_use, "year": year,
            "year_min": year_min, "year_max": year_max,
            "limit": limit, "offset": offset,
        })

    # ── Relationships & Graph ─────────────────────────────────────

    def relationships(self, id):
        """
        Get direct relationships for an entity.

        Args:
            id: Entity ID (compound, material, or product)

        Returns:
            dict with related entities
        """
        return self._request(f"/relationships/{_safe_id(id)}")

    def graph(self, id, depth=1):
        """
        Multi-hop graph traversal from an entity.

        Args:
            id: Starting entity ID
            depth: Traversal depth (1-3)

        Returns:
            dict with nodes and edges
        """
        return self._request(f"/relationships/{_safe_id(id)}/graph", {"depth": depth})

    def relationship_stats(self):
        """Get overall relationship graph statistics."""
        return self._request("/relationships/stats")

    # ── Regulatory ────────────────────────────────────────────────

    def regulatory(self, id):
        """
        Get regulatory classifications for a compound. Requires Developer+ tier.

        Args:
            id: Compound ID

        Returns:
            dict with regulatory data by agency
        """
        return self._request(f"/regulatory/{_safe_id(id)}")

    def regulatory_agencies(self):
        """List all regulatory agencies with compound counts. Requires Developer+ tier."""
        return self._request("/regulatory/agencies")

    def regulatory_by_agency(self, agency):
        """
        Get all compounds classified by a specific agency. Requires Developer+ tier.

        Args:
            agency: Agency name (e.g., "EPA", "IARC", "EFSA")
        """
        return self._request(f"/regulatory/by-agency/{urllib.parse.quote(agency)}")

    # ── Found In (Exposure Sources) ───────────────────────────────

    def found_in(self, id):
        """
        Get exposure sources for a compound. Requires Developer+ tier.

        Args:
            id: Compound ID

        Returns:
            dict with categorized exposure sources
        """
        return self._request(f"/found-in/{_safe_id(id)}")

    def found_in_categories(self):
        """List all exposure source categories. Requires Developer+ tier."""
        return self._request("/found-in/categories")

    def found_in_by_category(self, category):
        """
        Get compounds found in a specific category. Requires Developer+ tier.

        Args:
            category: Category name (e.g., "Food", "Cosmetics")
        """
        return self._request(f"/found-in/by-category/{urllib.parse.quote(category)}")

    # ── Materials & Products ──────────────────────────────────────

    def materials(self, limit=20, offset=0, search=None):
        """List materials. Requires Developer+ tier."""
        return self._request("/materials", {"limit": limit, "offset": offset, "search": search})

    def material(self, id):
        """Get a single material by ID."""
        return self._request(f"/material/{_safe_id(id)}")

    def products(self, limit=20, offset=0, search=None):
        """List products. Requires Developer+ tier."""
        return self._request("/products", {"limit": limit, "offset": offset, "search": search})

    def product(self, id):
        """Get a single product by ID."""
        return self._request(f"/product/{_safe_id(id)}")

    # ── Fragrance ─────────────────────────────────────────────────

    def fragrance(self, limit=20, offset=0):
        """List fragrance ingredients."""
        return self._request("/fragrance", {"limit": limit, "offset": offset})

    def fragrance_classes(self):
        """List fragrance ingredient classes."""
        return self._request("/fragrance/classes")

    def fragrance_search(self, query):
        """Search fragrance ingredients."""
        return self._request("/fragrance/search", {"q": query})

    # ── Reference ─────────────────────────────────────────────────

    def contexts(self):
        """List all 19 safety/exposure contexts with descriptions."""
        return self._request("/contexts")

    def badge_url(self, id):
        """
        Get the URL for an embeddable SVG safety badge.

        Args:
            id: Compound ID

        Returns:
            str: Badge URL (use in <img> tags)
        """
        return f"{self.base_url}/badge/{_safe_id(id)}"

    # ── Export ─────────────────────────────────────────────────────

    def export(self, type="compounds", format="json", detail=None, search=None, risk=None, context=None):
        """
        Bulk export data. Requires Developer+ tier. Counts as 10 requests.

        Args:
            type: "compounds", "materials", or "products"
            format: "json" or "csv"
            detail: "full" for expanded columns (Pro+ only, compounds only)
            search: Filter by name/CAS search term
            risk: Filter by risk level (e.g., "high")
            context: Filter by safety context
        """
        return self._request("/export", {
            "type": type, "format": format, "detail": detail,
            "search": search, "risk": risk, "context": context,
        })

    # ── Webhooks ──────────────────────────────────────────────────

    def webhook_register(self, url, events=None, compounds=None, format="json", signing_secret=None):
        """
        Register a webhook for regulatory change notifications. Requires Developer+ tier.

        Args:
            url: HTTPS URL to receive POST notifications
            events: List of event types (default: ["compound.updated", "compound.risk_changed"])
            compounds: List of compound IDs to watch, or ["*"] for all (default: all)
            format: "json" or "slack" (Slack Block Kit format)
            signing_secret: Custom HMAC signing secret for payload verification

        Returns:
            dict with webhook ID, configuration, and signing_secret
        """
        data = {"url": url, "format": format}
        if events:
            data["events"] = events
        if compounds:
            data["compounds"] = compounds
        if signing_secret:
            data["signing_secret"] = signing_secret
        return self._post("/webhooks", data)

    def webhook_list(self):
        """List your registered webhooks. Requires Developer+ tier."""
        return self._request("/webhooks")

    def webhook_delete(self, webhook_id):
        """
        Delete a webhook. Requires Developer+ tier.

        Args:
            webhook_id: Webhook ID (e.g., "wh_abc123...")
        """
        return self._delete(f"/webhooks/{_safe_id(webhook_id)}")

    def webhook_test(self, webhook_id):
        """
        Send a test payload to a webhook. Requires Developer+ tier.

        Args:
            webhook_id: Webhook ID to test
        """
        return self._post(f"/webhooks/test/{_safe_id(webhook_id)}", {})

    def webhook_deliveries(self, webhook_id, offset=0, limit=20):
        """
        Get delivery log for a webhook. Requires Developer+ tier.

        Args:
            webhook_id: Webhook ID (e.g., "wh_abc123...")
            offset: Pagination offset (default 0)
            limit: Number of records, max 50 (default 20)
        """
        return self._request(f"/webhooks?action=deliveries&webhook_id={_safe_id(webhook_id)}&offset={offset}&limit={limit}")

    # ── Key Management ────────────────────────────────────────────

    def key_status(self):
        """Check your API key status, tier, and usage. Requires api_key to be set."""
        return self._request("/keys/status")

    def key_recover(self, email):
        """
        Request API key recovery email.

        Args:
            email: Email address associated with the key
        """
        return self._post("/keys/recover", {"email": email})

    def key_rotate(self):
        """
        Rotate your API key. Returns new key and updates the client. Requires Developer+ tier.

        Returns:
            dict with new key, old key preview, and expiration
        """
        result = self._post("/keys/rotate", {})
        if result.get("key"):
            self.api_key = result["key"]
        return result

    def key_usage(self, days=7):
        """
        Get daily usage history. Requires Developer+ tier.

        Args:
            days: Number of days of history (default: 7, max: 30)
        """
        return self._request("/keys/usage", {"days": days})

    # ── Watchlist ─────────────────────────────────────────────────

    def watchlist(self, limit=50, offset=0):
        """List compounds on your watchlist with enrichment. Requires Developer+ tier."""
        return self._request("/watchlist", {"limit": limit, "offset": offset})

    def watchlist_add(self, compound_ids):
        """
        Add compounds to your watchlist. Requires Developer+ tier.

        Args:
            compound_ids: Single compound ID string or list of IDs
        """
        if isinstance(compound_ids, str):
            compound_ids = [compound_ids]
        return self._post("/watchlist", {"compounds": compound_ids})

    def watchlist_check(self, compound_ids):
        """
        Check which compounds are on your watchlist. Requires Developer+ tier.

        Args:
            compound_ids: List of compound IDs to check (max 100)

        Returns:
            dict with per-compound on_watchlist status
        """
        if isinstance(compound_ids, str):
            compound_ids = [compound_ids]
        return self._post("/watchlist/check", {"compounds": compound_ids})

    def watchlist_remove(self, compound_id):
        """
        Remove a compound from your watchlist. Requires Developer+ tier.

        Args:
            compound_id: Compound ID to remove
        """
        return self._delete(f"/watchlist/{_safe_id(compound_id)}")

    # ── Changelog ─────────────────────────────────────────────────

    def changelog(self, since=None, compound_id=None, type=None, summary=None, limit=50, offset=0):
        """
        Get regulatory/data change feed. Requires Developer+ tier.

        Args:
            since: ISO date string to filter changes after (e.g., "2026-01-01")
            compound_id: Filter to specific compound
            type: Filter by change type
            summary: If True, return compact summary (useful for polling)
            limit: Results per page (default: 50)
            offset: Pagination offset
        """
        return self._request("/changelog", {
            "since": since, "compound_id": compound_id,
            "type": type, "summary": summary,
            "limit": limit, "offset": offset,
        })

    # ── Raw Data ──────────────────────────────────────────────────

    def alternatives(self, id):
        """
        Get safer alternatives for a compound.

        Free tier: basic list (name + effectiveness).
        Developer+: full data (tradeoffs, cost, regulatory status, linked IDs).

        Args:
            id: Compound ID
        """
        return self._request(f"/compound/{_safe_id(id)}/alternatives")

    def compound_raw(self, id):
        """Get raw compound JSON. Requires Developer+ tier."""
        return self._request(f"/compound/{_safe_id(id)}/raw")

    def product_raw(self, id):
        """Get raw product JSON. Requires Developer+ tier."""
        return self._request(f"/product/{_safe_id(id)}/raw")

    # ── Trial & Erasure ────────────────────────────────────────────

    def key_trial(self, email):
        """
        Start a free 7-day Developer trial. No API key required.

        Args:
            email: Email address to send the trial key to

        Returns:
            dict with trial key, tier, expiry date
        """
        return self._post("/keys/trial", {"email": email})

    def key_resend(self, email):
        """
        Retry email delivery for keys flagged email_pending.

        Args:
            email: Email address associated with the key
        """
        return self._post("/keys/resend", {"email": email})

    def key_erasure(self, email, code=None):
        """
        Request data erasure (GDPR Art. 17). Two-step flow:
        1. Call with email only → verification code sent to email
        2. Call with email + code → all personal data permanently deleted

        Args:
            email: Email address associated with your API key(s)
            code: 6-digit verification code (step 2 only)
        """
        data = {"email": email}
        if code is not None:
            data["code"] = str(code)
        return self._post("/keys/erasure", data)

    # ── Health ────────────────────────────────────────────────────

    def health(self):
        """Check API health status."""
        return self._request("/health")

    # ── Webhook Signature Verification ────────────────────────

    @staticmethod
    def verify_webhook_signature(payload, signature_header, secret, tolerance=300):
        """
        Verify an incoming webhook signature. Use this in your webhook handler
        to confirm the payload was sent by ALETHEIA and hasn't been tampered with.

        Args:
            payload: Raw request body (str or bytes, not parsed JSON)
            signature_header: Value of the X-Aletheia-Signature header
            secret: Your webhook signing secret
            tolerance: Max age in seconds (default 300 = 5 minutes)

        Returns:
            dict with ``{"valid": True, "timestamp": int}``

        Raises:
            AletheiaError: if signature is invalid, expired, or malformed

        Example::

            @app.route("/webhook", methods=["POST"])
            def handle_webhook():
                result = Aletheia.verify_webhook_signature(
                    request.get_data(as_text=True),
                    request.headers.get("X-Aletheia-Signature"),
                    os.environ["ALETHEIA_WEBHOOK_SECRET"],
                )
                # result["valid"] is True, result["timestamp"] is unix seconds
        """
        import hmac
        import hashlib
        import time

        if not signature_header or not isinstance(signature_header, str):
            raise AletheiaError(400, "invalid_signature", "Missing or empty X-Aletheia-Signature header")
        if not secret:
            raise AletheiaError(400, "invalid_secret", "Signing secret is required")

        # Parse header: t=1234567890,sha256=abcdef...
        parts = {}
        for part in signature_header.split(","):
            key, _, value = part.partition("=")
            parts[key] = value

        try:
            timestamp = int(parts.get("t", ""))
        except (ValueError, TypeError):
            raise AletheiaError(400, "invalid_signature", "Malformed signature header — expected t=...,sha256=...")
        received_sig = parts.get("sha256", "")
        if not received_sig:
            raise AletheiaError(400, "invalid_signature", "Malformed signature header — expected t=...,sha256=...")

        # Check timestamp freshness
        age = int(time.time()) - timestamp
        if age > tolerance:
            raise AletheiaError(400, "expired_signature", f"Signature expired: {age}s old (tolerance: {tolerance}s)")

        # Compute expected signature: HMAC-SHA256('{timestamp}.{payload}', secret)
        if isinstance(payload, bytes):
            payload = payload.decode("utf-8")
        if isinstance(secret, str):
            secret = secret.encode("utf-8")
        message = f"{timestamp}.{payload}".encode("utf-8")
        expected = hmac.new(secret, message, hashlib.sha256).hexdigest()

        # Timing-safe comparison
        if not hmac.compare_digest(expected, received_sig):
            raise AletheiaError(400, "invalid_signature", "Signature verification failed")

        return {"valid": True, "timestamp": timestamp}
