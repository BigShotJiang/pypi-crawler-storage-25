from setuptools import setup, find_packages

with open("README.md", "r", encoding="utf-8") as fh:
    long_description = fh.read()

setup(
    name="py-mtproxy-lib",
    version="0.0.4",
    author="AneK",
    author_email="tashova28@gmail.com",
    description="Production-ready MTProto proxy server library with multi-secret support, statistics, and daemon mode",
    long_description=long_description,
    long_description_content_type="text/markdown",
    url="https://github.com/twosleepynights0x1/py-mtproxy-lib",
    packages=find_packages(),
    classifiers=[
        "Development Status :: 5 - Production/Stable",
        "Intended Audience :: System Administrators",
        "Topic :: Internet :: Proxy Servers",
        "Programming Language :: Python :: 3",
        "Programming Language :: Python :: 3.7",
        "Programming Language :: Python :: 3.8",
        "Programming Language :: Python :: 3.9",
        "Programming Language :: Python :: 3.10",
        "Programming Language :: Python :: 3.11",
        "License :: OSI Approved :: MIT License",
        "Operating System :: POSIX",
        "Operating System :: Unix",
    ],
    python_requires=">=3.7",
    install_requires=[
        "pycryptodome>=3.10.0",
    ],
    extras_require={
        "dev": [
            "pytest>=6.0",
            "pytest-asyncio>=0.21.0",
            "black>=22.0",
            "flake8>=4.0",
        ],
        "docker": [
            "docker>=6.0",
        ],
    },
    entry_points={
        "console_scripts": [
            "mtproxy=mtproxy.cli:main",
        ],
    },
    package_data={
        "mtproxy": ["py.typed"],
    },
    include_package_data=True,
    keywords="mtproto telegram proxy vpn daemon docker",
    project_urls={
        "Bug Reports": "https://github.com/twosleepynights0x1/py-mtproxy-lib",
    },
)