"""Модуль для запуска как системный демон"""

import os
import sys
import atexit
import signal
import time
from typing import Optional, Callable


class Daemon:
    """
    Класс для управления демоном
    
    Пример использования:
        daemon = Daemon(pidfile='/var/run/mtproxy.pid')
        daemon.start(run_function)
    """
    
    def __init__(self, pidfile: str, stdin: str = '/dev/null',
                 stdout: str = '/dev/null', stderr: str = '/dev/null'):
        """
        Инициализация демона
        
        Args:
            pidfile: Путь к файлу PID
            stdin: Перенаправление stdin
            stdout: Перенаправление stdout
            stderr: Перенаправление stderr
        """
        self.pidfile = pidfile
        self.stdin = stdin
        self.stdout = stdout
        self.stderr = stderr
        self._running = False
    
    def _daemonize(self) -> None:
        """Демонизация процесса (двойной fork)"""
        try:
            pid = os.fork()
            if pid > 0:
                sys.exit(0)
        except OSError as e:
            sys.stderr.write(f"Fork #1 failed: {e}\n")
            sys.exit(1)
        
        # Отсоединение от терминала
        os.setsid()
        os.umask(0)
        
        try:
            pid = os.fork()
            if pid > 0:
                sys.exit(0)
        except OSError as e:
            sys.stderr.write(f"Fork #2 failed: {e}\n")
            sys.exit(1)
        
        # Перенаправление файловых дескрипторов
        sys.stdout.flush()
        sys.stderr.flush()
        
        with open(self.stdin, 'r') as si:
            os.dup2(si.fileno(), sys.stdin.fileno())
        with open(self.stdout, 'a+') as so:
            os.dup2(so.fileno(), sys.stdout.fileno())
        with open(self.stderr, 'a+') as se:
            os.dup2(se.fileno(), sys.stderr.fileno())
        
        # Запись PID
        self._write_pidfile()
        
        # Регистрация удаления PID файла при выходе
        atexit.register(self._remove_pidfile)
        
        # Обработка сигналов
        signal.signal(signal.SIGTERM, self._signal_handler)
        signal.signal(signal.SIGINT, self._signal_handler)
    
    def _write_pidfile(self) -> None:
        """Запись PID в файл"""
        with open(self.pidfile, 'w') as f:
            f.write(str(os.getpid()))
    
    def _remove_pidfile(self) -> None:
        """Удаление PID файла"""
        if os.path.exists(self.pidfile):
            os.remove(self.pidfile)
    
    def _signal_handler(self, signum, frame) -> None:
        """Обработчик сигналов"""
        self._running = False
    
    def _get_pid(self) -> Optional[int]:
        """Получение PID из файла"""
        try:
            with open(self.pidfile, 'r') as f:
                return int(f.read().strip())
        except (IOError, ValueError):
            return None
    
    def start(self, run_func: Callable, *args, **kwargs) -> int:
        """
        Запуск демона
        
        Args:
            run_func: Функция для запуска
            *args, **kwargs: Аргументы для функции
        
        Returns:
            int: 0 при успехе, 1 при ошибке
        """
        pid = self._get_pid()
        
        if pid:
            # Проверка, работает ли процесс
            try:
                os.kill(pid, 0)
                sys.stderr.write(f"Daemon already running with PID {pid}\n")
                return 1
            except OSError:
                # Процесс не работает, удаляем старый PID файл
                self._remove_pidfile()
        
        # Демонизация
        self._daemonize()
        
        # Запуск основной функции
        self._running = True
        try:
            run_func(*args, **kwargs)
        except KeyboardInterrupt:
            pass
        except Exception as e:
            sys.stderr.write(f"Error in daemon: {e}\n")
            return 1
        
        return 0
    
    def stop(self) -> int:
        """Остановка демона"""
        pid = self._get_pid()
        
        if not pid:
            sys.stderr.write("Daemon not running\n")
            return 1
        
        try:
            os.kill(pid, signal.SIGTERM)
            
            # Ожидание завершения
            timeout = 10
            while timeout > 0:
                try:
                    os.kill(pid, 0)
                    time.sleep(0.5)
                    timeout -= 0.5
                except OSError:
                    break
            
            # Принудительное завершение
            try:
                os.kill(pid, 0)
                os.kill(pid, signal.SIGKILL)
            except OSError:
                pass
            
            self._remove_pidfile()
            
        except OSError as e:
            sys.stderr.write(f"Error stopping daemon: {e}\n")
            return 1
        
        return 0
    
    def restart(self, run_func: Callable, *args, **kwargs) -> int:
        """Перезапуск демона"""
        self.stop()
        return self.start(run_func, *args, **kwargs)
    
    def status(self) -> str:
        """Проверка статуса демона"""
        pid = self._get_pid()
        
        if not pid:
            return "stopped"
        
        try:
            os.kill(pid, 0)
            return f"running (PID: {pid})"
        except OSError:
            return "stopped (stale PID file)"