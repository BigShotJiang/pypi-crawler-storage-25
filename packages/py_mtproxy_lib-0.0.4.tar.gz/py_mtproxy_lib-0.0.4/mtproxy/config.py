"""Конфигурация с поддержкой нескольких секретов"""

import json
import os
from dataclasses import dataclass, field
from typing import Dict, List, Optional, Tuple
from .utils import generate_secret, verify_fake_tls_handshake


@dataclass
class ProxyConfig:
    """
    Конфигурация прокси сервера с поддержкой нескольких секретов
    
    Attributes:
        secrets (Dict[str, str]): Словарь {secret: tag}
        port (int): Порт для прослушивания
        enable_fake_tls (bool): Включить Fake TLS маскировку
        handshake_timeout (int): Таймаут handshake в секундах
        stats_interval (int): Интервал вывода статистики (сек)
        log_level (str): Уровень логирования
        log_file (Optional[str]): Файл лога
        pid_file (Optional[str]): Файл PID
    """
    
    secrets: Dict[str, str] = field(default_factory=dict)
    port: int = 443
    enable_fake_tls: bool = True
    handshake_timeout: int = 10
    stats_interval: int = 60
    log_level: str = "INFO"
    log_file: Optional[str] = None
    pid_file: Optional[str] = None
    
    @classmethod
    def from_dict(cls, data: dict) -> 'ProxyConfig':
        """Создание конфигурации из словаря"""
        secrets = {}
        
        # Поддержка разных форматов
        if 'secrets' in data:
            if isinstance(data['secrets'], list):
                for item in data['secrets']:
                    if isinstance(item, str):
                        secrets[item] = ""
                    elif isinstance(item, dict):
                        secrets[item.get('secret', '')] = item.get('tag', '')
            elif isinstance(data['secrets'], dict):
                secrets = data['secrets']
        
        return cls(
            secrets=secrets,
            port=data.get('port', 443),
            enable_fake_tls=data.get('enable_fake_tls', True),
            handshake_timeout=data.get('handshake_timeout', 10),
            stats_interval=data.get('stats_interval', 60),
            log_level=data.get('log_level', 'INFO'),
            log_file=data.get('log_file'),
            pid_file=data.get('pid_file')
        )
    
    @classmethod
    def from_file(cls, path: str) -> 'ProxyConfig':
        """Загрузка конфигурации из файла"""
        if not os.path.exists(path):
            raise FileNotFoundError(f"Config file not found: {path}")
        
        with open(path, 'r') as f:
            if path.endswith('.json'):
                data = json.load(f)
            else:
                # INI-like format
                data = cls._parse_ini(f.read())
        
        return cls.from_dict(data)
    
    @classmethod
    def _parse_ini(cls, content: str) -> dict:
        """Парсинг INI-подобного формата"""
        data = {'secrets': {}}
        
        for line in content.split('\n'):
            line = line.strip()
            if not line or line.startswith('#'):
                continue
            
            if '=' in line:
                key, value = line.split('=', 1)
                key = key.strip()
                value = value.strip()
                
                if key == 'secret':
                    # Простой формат: secret=xxx
                    data['secrets'][value] = ""
                elif key.startswith('secret_'):
                    # Формат: secret_name=xxx
                    tag = key.replace('secret_', '')
                    data['secrets'][value] = tag
                else:
                    # Другие параметры
                    data[key] = value
        
        return data
    
    def save(self, path: str) -> None:
        """Сохранение конфигурации в файл"""
        data = {
            'port': self.port,
            'enable_fake_tls': self.enable_fake_tls,
            'handshake_timeout': self.handshake_timeout,
            'stats_interval': self.stats_interval,
            'log_level': self.log_level,
            'secrets': self.secrets
        }
        
        with open(path, 'w') as f:
            json.dump(data, f, indent=2)
    
    def add_secret(self, secret: Optional[str] = None, tag: str = "") -> str:
        """Добавление нового секрета"""
        if not secret:
            secret = generate_secret()
        
        self.secrets[secret] = tag
        return secret
    
    def remove_secret(self, secret: str) -> bool:
        """Удаление секрета"""
        if secret in self.secrets:
            del self.secrets[secret]
            return True
        return False
    
    def verify_secret(self, data: bytes) -> Tuple[bool, Optional[str]]:
        """
        Проверка handshake и определение использованного секрета
        
        Returns:
            Tuple[bool, Optional[str]]: (успех, секрет)
        """
        for secret_hex, tag in self.secrets.items():
            secret = bytes.fromhex(secret_hex)
            if verify_fake_tls_handshake(data, secret):
                return True, secret_hex
        
        return False, None
    
    def get_connection_links(self, base_ip: Optional[str] = None) -> Dict[str, str]:
        """Получение ссылок для всех секретов"""
        from .utils import get_external_ip
        
        ip = base_ip or get_external_ip() or "YOUR_SERVER_IP"
        links = {}
        
        for secret, tag in self.secrets.items():
            link = f"tg://proxy?server={ip}&port={self.port}&secret={secret}"
            if tag:
                link += f"&tag={tag}"
            links[secret[:16] + ("..." if len(secret) > 16 else "")] = link
        
        return links