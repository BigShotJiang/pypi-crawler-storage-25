import asyncio
import uuid
import signal
import time
from typing import Optional, Dict
from .config import ProxyConfig
from .stats import ProxyStats
from .logger import get_logger
from .utils import get_external_ip, get_public_ip


class MTProxyServer:
    
    def __init__(self, config: ProxyConfig):
        self.config = config
        self.logger = get_logger()
        self.stats = ProxyStats()
        self.server: Optional[asyncio.Server] = None
        self._running = False
        self._tasks: Dict[str, asyncio.Task] = {}
        self._conn_counter = 0
    
    def _get_conn_id(self) -> str:
        self._conn_counter += 1
        return f"{self._conn_counter}_{uuid.uuid4().hex[:8]}"
    
    def get_connection_link(self, custom_ip: str = None) -> str:
        ip = custom_ip or get_public_ip() or get_external_ip() or "YOUR_SERVER_IP"
        secret = list(self.config.secrets.keys())[0] if self.config.secrets else ""
        return f"tg://proxy?server={ip}&port={self.config.port}&secret={secret}"
    
    def get_all_links(self, custom_ip: str = None) -> Dict[str, str]:
        ip = custom_ip or get_public_ip() or get_external_ip() or "YOUR_SERVER_IP"
        links = {}
        for secret, tag in self.config.secrets.items():
            link = f"tg://proxy?server={ip}&port={self.config.port}&secret={secret}"
            if tag:
                link += f"&tag={tag}"
            links[secret[:16] + ("..." if len(secret) > 16 else "")] = link
        return links
    
    async def _handle_connection(self, reader: asyncio.StreamReader, writer: asyncio.StreamWriter):
        conn_id = self._get_conn_id()
        client_addr = writer.get_extra_info('peername')
        client_ip = client_addr[0] if client_addr else "unknown"
        
        try:
            handshake = await asyncio.wait_for(
                reader.read(1024),
                timeout=self.config.handshake_timeout
            )
            
            if not handshake:
                writer.close()
                return
            
            if self.config.enable_fake_tls and handshake[0] == 0x16:
                from .utils import verify_fake_tls_handshake
                success, secret = False, None
                for secret_hex, tag in self.config.secrets.items():
                    secret_bytes = bytes.fromhex(secret_hex)
                    if verify_fake_tls_handshake(handshake, secret_bytes):
                        success = True
                        secret = secret_hex
                        break
                if not success:
                    self.logger.warning(f"Auth failed from {client_ip}")
                    writer.close()
                    return
            else:
                if len(handshake) < 4 or handshake[:4] != b'\xef\xef\xef\xef':
                    self.logger.warning(f"Invalid protocol from {client_ip}")
                    writer.close()
                    return
                secret = list(self.config.secrets.keys())[0] if self.config.secrets else None
                if not secret:
                    writer.close()
                    return
            
            self.logger.info(f"Client connected: {client_ip} (secret: {secret[:16]}...)")
            self.stats.connection_started(conn_id, client_ip, secret)
            
            tg_ips = ['149.154.167.50', '149.154.167.51', '149.154.175.100']
            tg_reader, tg_writer = await asyncio.open_connection(
                tg_ips[hash(secret) % len(tg_ips)],
                443
            )
            
            task_client = asyncio.create_task(
                self._forward(reader, tg_writer, conn_id, sent=True)
            )
            task_server = asyncio.create_task(
                self._forward(tg_reader, writer, conn_id, received=True)
            )
            
            self._tasks[conn_id] = task_client
            self._tasks[f"{conn_id}_server"] = task_server
            
            await asyncio.gather(task_client, task_server)
            
        except asyncio.TimeoutError:
            self.logger.debug(f"Handshake timeout from {client_ip}")
        except ConnectionRefusedError:
            self.logger.error(f"Connection refused to Telegram from {client_ip}")
        except Exception as e:
            self.logger.error(f"Error handling connection from {client_ip}: {e}")
        finally:
            self.stats.connection_ended(conn_id)
            
            for task_id in [conn_id, f"{conn_id}_server"]:
                if task_id in self._tasks:
                    self._tasks[task_id].cancel()
                    del self._tasks[task_id]
            
            writer.close()
            await writer.wait_closed()
            self.logger.debug(f"Connection closed: {client_ip}")
    
    async def _forward(self, reader: asyncio.StreamReader, writer: asyncio.StreamWriter,
                       conn_id: str, sent: bool = False, received: bool = False):
        try:
            while True:
                data = await reader.read(8192)
                if not data:
                    break
                
                writer.write(data)
                await writer.drain()
                
                if sent:
                    self.stats.update_bytes(conn_id, sent=len(data))
                if received:
                    self.stats.update_bytes(conn_id, received=len(data))
                    
        except (asyncio.CancelledError, ConnectionError):
            pass
        except Exception as e:
            self.logger.debug(f"Forward error: {e}")
        finally:
            writer.close()
    
    async def _stats_reporter(self):
        while self._running:
            await asyncio.sleep(self.config.stats_interval)
            self.logger.info("\n" + self.stats.format_summary())
    
    def start(self):
        loop = asyncio.new_event_loop()
        asyncio.set_event_loop(loop)
        
        self._running = True
        
        try:
            self.server = loop.run_until_complete(
                asyncio.start_server(
                    self._handle_connection,
                    '0.0.0.0',
                    self.config.port
                )
            )
            
            stats_task = loop.create_task(self._stats_reporter())
            
            print("=" * 60)
            print("🚀 MTProxy Server Started")
            print("=" * 60)
            print(f"📡 Port: {self.config.port}")
            print(f"🔐 Fake TLS: {self.config.enable_fake_tls}")
            print(f"🔑 Secrets count: {len(self.config.secrets)}")
            print(f"📊 Stats interval: {self.config.stats_interval}s")
            print("-" * 60)
            print("Connection links:")
            
            links = self.get_all_links()
            for name, link in links.items():
                print(f"  {link}")
            
            print("=" * 60)
            print("Press Ctrl+C to stop")
            print("=" * 60)
            
            for sig in (signal.SIGINT, signal.SIGTERM):
                loop.add_signal_handler(sig, lambda: asyncio.create_task(self.stop()))
            
            loop.run_forever()
            
        except KeyboardInterrupt:
            pass
        except Exception as e:
            self.logger.error(f"Server error: {e}")
        finally:
            stats_task.cancel()
            self._running = False
            if self.server:
                self.server.close()
            loop.close()
    
    async def stop(self):
        self.logger.info("Shutting down...")
        self._running = False
        
        for task in self._tasks.values():
            task.cancel()
        
        if self.server:
            self.server.close()
            await self.server.wait_closed()
        
        self.logger.info("Server stopped")