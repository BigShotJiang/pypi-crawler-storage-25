"""
py-mtproxy-lib - Python библиотека для запуска MTProto прокси
"""

from .server import MTProxyServer
from .utils import generate_secret
from .stats import ProxyStats, ConnectionStats
from .logger import setup_logger
from .config import ProxyConfig
from .daemon import Daemon
from .cli import main

__version__ = "2.0.0"
__all__ = [
    'MTProxyServer',
    'generate_secret',
    'ProxyStats',
    'ConnectionStats',
    'setup_logger',
    'ProxyConfig',
    'Daemon',
    'main'
]