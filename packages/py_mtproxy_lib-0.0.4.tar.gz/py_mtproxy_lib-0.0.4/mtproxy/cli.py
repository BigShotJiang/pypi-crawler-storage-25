import argparse
import sys
import os
from .config import ProxyConfig
from .server import MTProxyServer
from .utils import generate_secret, find_free_port, get_public_ip, get_common_ports
from .daemon import Daemon
from .logger import setup_logger


def start_server(config: ProxyConfig, foreground: bool = False):
    logger = setup_logger(
        level=config.log_level,
        log_file=config.log_file
    )
    
    server = MTProxyServer(config)
    
    if foreground:
        server.start()
    else:
        daemon = Daemon(
            pidfile=config.pid_file or '/var/run/mtproxy.pid',
            stdout=config.log_file or '/dev/null',
            stderr=config.log_file or '/dev/null'
        )
        daemon.start(server.start)


def main():
    parser = argparse.ArgumentParser(
        description="MTProto Proxy Server",
        prog="mtproxy"
    )
    
    parser.add_argument(
        "-c", "--config",
        help="Config file path",
        type=str,
        default="mtproxy.conf"
    )
    
    parser.add_argument(
        "-s", "--secret",
        help="Add secret (can be used multiple times)",
        action="append"
    )
    
    parser.add_argument(
        "-p", "--port",
        help="Port to listen on (auto-find if not specified)",
        type=int
    )
    
    parser.add_argument(
        "--auto-port",
        help="Automatically find free port",
        action="store_true"
    )
    
    parser.add_argument(
        "--no-fake-tls",
        help="Disable Fake TLS masking",
        action="store_true"
    )
    
    parser.add_argument(
        "-d", "--daemon",
        help="Run as daemon",
        action="store_true"
    )
    
    parser.add_argument(
        "--pid-file",
        help="PID file path",
        type=str
    )
    
    parser.add_argument(
        "--log-file",
        help="Log file path",
        type=str
    )
    
    parser.add_argument(
        "--log-level",
        help="Log level",
        choices=['DEBUG', 'INFO', 'WARNING', 'ERROR'],
        default='INFO'
    )
    
    parser.add_argument(
        "--stats-interval",
        help="Statistics output interval (seconds)",
        type=int
    )
    
    parser.add_argument(
        "--generate-secret",
        help="Generate random secret and exit",
        action="store_true"
    )
    
    parser.add_argument(
        "--show-links",
        help="Show connection links",
        action="store_true"
    )
    
    parser.add_argument(
        "--show-ip",
        help="Show public IP address",
        action="store_true"
    )
    
    parser.add_argument(
        "--find-port",
        help="Find free port in range",
        type=str,
        nargs='?',
        const="5000-10000"
    )
    
    subparsers = parser.add_subparsers(dest="command", help="Daemon commands")
    subparsers.add_parser("start", help="Start daemon")
    subparsers.add_parser("stop", help="Stop daemon")
    subparsers.add_parser("restart", help="Restart daemon")
    subparsers.add_parser("status", help="Check daemon status")
    
    args = parser.parse_args()
    
    if args.generate_secret:
        print(generate_secret())
        sys.exit(0)
    
    if args.show_ip:
        ip = get_public_ip()
        print(ip if ip else "Could not detect public IP")
        sys.exit(0)
    
    if args.find_port:
        try:
            if '-' in args.find_port:
                start, end = map(int, args.find_port.split('-'))
            else:
                start, end = 5000, 10000
            port = find_free_port(start, end)
            print(f"Free port found: {port}")
        except Exception as e:
            print(f"Error: {e}")
        sys.exit(0)
    
    config = None
    if os.path.exists(args.config):
        try:
            config = ProxyConfig.from_file(args.config)
        except Exception as e:
            print(f"Error loading config: {e}", file=sys.stderr)
    
    if not config:
        config = ProxyConfig()
    
    if args.port:
        config.port = args.port
    elif args.auto_port or not config.port:
        try:
            config.port = find_free_port(5000, 10000, get_common_ports())
            print(f"Auto-selected free port: {config.port}")
        except Exception as e:
            print(f"Error finding free port: {e}", file=sys.stderr)
            sys.exit(1)
    
    if args.no_fake_tls:
        config.enable_fake_tls = False
    if args.pid_file:
        config.pid_file = args.pid_file
    if args.log_file:
        config.log_file = args.log_file
    if args.log_level:
        config.log_level = args.log_level
    if args.stats_interval:
        config.stats_interval = args.stats_interval
    
    if args.secret:
        for secret in args.secret:
            config.add_secret(secret)
    
    if not config.secrets:
        config.add_secret()
        print(f"Generated default secret: {list(config.secrets.keys())[0]}")
    
    if args.show_links:
        from .utils import get_public_ip
        ip = get_public_ip() or "YOUR_SERVER_IP"
        print(f"Server IP: {ip}")
        print(f"Port: {config.port}")
        print("Connection links:")
        for secret, tag in config.secrets.items():
            link = f"tg://proxy?server={ip}&port={config.port}&secret={secret}"
            if tag:
                link += f"&tag={tag}"
            print(f"  {link}")
        sys.exit(0)
    
    daemon = Daemon(
        pidfile=config.pid_file or '/var/run/mtproxy.pid',
        stdout=config.log_file or '/dev/null',
        stderr=config.log_file or '/dev/null'
    )
    
    if args.command == "start":
        sys.exit(daemon.start(start_server, config))
    elif args.command == "stop":
        sys.exit(daemon.stop())
    elif args.command == "restart":
        sys.exit(daemon.restart(start_server, config))
    elif args.command == "status":
        print(daemon.status())
        sys.exit(0)
    
    if args.daemon:
        daemon.start(start_server, config)
    else:
        start_server(config, foreground=True)


if __name__ == "__main__":
    main()