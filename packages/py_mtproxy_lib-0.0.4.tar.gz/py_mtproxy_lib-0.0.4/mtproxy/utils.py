"""Вспомогательные функции"""

import secrets
import hashlib
import hmac
from typing import Optional, List
import urllib.request
import socket


def generate_secret() -> str:
    return secrets.token_hex(16)


def verify_fake_tls_handshake(data: bytes, secret: bytes) -> bool:
    if not data or len(data) < 51 or data[0] != 0x16:
        return False
    
    digest = data[11:43]
    timestamp = data[43:51]
    expected = hmac.new(secret, timestamp, hashlib.sha256).digest()[:32]
    
    return hmac.compare_digest(digest, expected)


def get_external_ip() -> Optional[str]:
    try:
        with urllib.request.urlopen('https://ifconfig.me', timeout=5) as response:
            return response.read().decode('utf-8').strip()
    except Exception:
        return None


def find_free_port(start_port: int = 5000, end_port: int = 10000, exclude_ports: List[int] = None) -> int:
    if exclude_ports is None:
        exclude_ports = []
    
    for port in range(start_port, end_port + 1):
        if port in exclude_ports:
            continue
            
        sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        sock.settimeout(1)
        result = sock.connect_ex(('127.0.0.1', port))
        sock.close()
        
        if result != 0:
            return port
    
    raise RuntimeError(f"No free port found in range {start_port}-{end_port}")


def get_public_ip() -> Optional[str]:
    services = [
        'https://ifconfig.me',
        'https://api.ipify.org',
        'https://icanhazip.com',
        'https://checkip.amazonaws.com'
    ]
    
    for service in services:
        try:
            with urllib.request.urlopen(service, timeout=5) as response:
                ip = response.read().decode('utf-8').strip()
                if ip:
                    return ip
        except Exception:
            continue
    
    return None


def get_local_ip() -> str:
    try:
        s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        s.connect(('8.8.8.8', 80))
        ip = s.getsockname()[0]
        s.close()
        return ip
    except Exception:
        return '127.0.0.1'


def check_port_available(port: int, host: str = '0.0.0.0') -> bool:
    try:
        sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        sock.settimeout(1)
        result = sock.connect_ex((host, port))
        sock.close()
        return result != 0
    except Exception:
        return False


def get_common_ports() -> List[int]:
    return [443, 8443, 8080, 5001, 5047, 5050, 8081, 9443, 2053, 2096, 2087, 2083]