"""Модуль статистики"""

import time
import threading
from dataclasses import dataclass, field
from typing import Dict, Optional
from collections import defaultdict
from datetime import datetime


@dataclass
class ConnectionStats:
    """Статистика по одному соединению"""
    client_ip: str
    secret_key: str
    start_time: float
    bytes_sent: int = 0
    bytes_received: int = 0
    end_time: Optional[float] = None
    
    @property
    def duration(self) -> float:
        """Длительность соединения в секундах"""
        end = self.end_time or time.time()
        return end - self.start_time
    
    @property
    def total_bytes(self) -> int:
        """Общее количество байт"""
        return self.bytes_sent + self.bytes_received


class ProxyStats:
    """
    Сбор статистики прокси сервера
    
    Attributes:
        total_connections (int): Всего подключений
        active_connections (int): Активных подключений
        total_bytes_sent (int): Всего отправлено байт
        total_bytes_received (int): Всего получено байт
        connections_per_secret (dict): Статистика по секретам
        connections_per_ip (dict): Статистика по IP
    """
    
    def __init__(self):
        self._lock = threading.Lock()
        self._connections: Dict[str, ConnectionStats] = {}
        self._start_time = time.time()
        
        # Общая статистика
        self.total_connections = 0
        self.active_connections = 0
        self.total_bytes_sent = 0
        self.total_bytes_received = 0
        
        # Детальная статистика
        self.connections_per_secret: Dict[str, int] = defaultdict(int)
        self.connections_per_ip: Dict[str, int] = defaultdict(int)
        self.bytes_per_secret: Dict[str, Dict[str, int]] = defaultdict(
            lambda: {'sent': 0, 'received': 0}
        )
    
    def connection_started(self, conn_id: str, client_ip: str, secret_key: str) -> None:
        """Начало соединения"""
        with self._lock:
            self._connections[conn_id] = ConnectionStats(
                client_ip=client_ip,
                secret_key=secret_key,
                start_time=time.time()
            )
            self.total_connections += 1
            self.active_connections += 1
            self.connections_per_secret[secret_key] += 1
            self.connections_per_ip[client_ip] += 1
    
    def connection_ended(self, conn_id: str) -> Optional[ConnectionStats]:
        """Завершение соединения"""
        with self._lock:
            if conn_id not in self._connections:
                return None
            
            conn = self._connections[conn_id]
            conn.end_time = time.time()
            
            self.active_connections -= 1
            self.total_bytes_sent += conn.bytes_sent
            self.total_bytes_received += conn.bytes_received
            
            # Обновление статистики по секрету
            self.bytes_per_secret[conn.secret_key]['sent'] += conn.bytes_sent
            self.bytes_per_secret[conn.secret_key]['received'] += conn.bytes_received
            
            return self._connections.pop(conn_id, None)
    
    def update_bytes(self, conn_id: str, sent: int = 0, received: int = 0) -> None:
        """Обновление счетчиков байт"""
        with self._lock:
            if conn_id in self._connections:
                self._connections[conn_id].bytes_sent += sent
                self._connections[conn_id].bytes_received += received
    
    def get_summary(self) -> dict:
        """Получение сводной статистики"""
        with self._lock:
            uptime = time.time() - self._start_time
            
            return {
                'uptime_seconds': uptime,
                'total_connections': self.total_connections,
                'active_connections': self.active_connections,
                'total_bytes_sent': self.total_bytes_sent,
                'total_bytes_received': self.total_bytes_received,
                'total_bytes': self.total_bytes_sent + self.total_bytes_received,
                'connections_per_second': self.total_connections / uptime if uptime > 0 else 0,
                'bytes_per_second': (self.total_bytes_sent + self.total_bytes_received) / uptime if uptime > 0 else 0,
                'secrets': dict(self.connections_per_secret),
                'bytes_per_secret': dict(self.bytes_per_secret),
                'top_ips': sorted(
                    self.connections_per_ip.items(),
                    key=lambda x: x[1],
                    reverse=True
                )[:10]
            }
    
    def format_summary(self) -> str:
        """Форматирование сводки для вывода"""
        stats = self.get_summary()
        
        def format_bytes(b: int) -> str:
            for unit in ['B', 'KB', 'MB', 'GB']:
                if b < 1024:
                    return f"{b:.2f} {unit}"
                b /= 1024
            return f"{b:.2f} TB"
        
        lines = [
            "=" * 50,
            "MTProxy Statistics",
            "=" * 50,
            f"Uptime: {stats['uptime_seconds']:.0f} seconds",
            f"Total connections: {stats['total_connections']}",
            f"Active connections: {stats['active_connections']}",
            f"Total traffic: {format_bytes(stats['total_bytes'])}",
            f"  - Sent: {format_bytes(stats['total_bytes_sent'])}",
            f"  - Received: {format_bytes(stats['total_bytes_received'])}",
            f"Connections/sec: {stats['connections_per_second']:.2f}",
            f"Traffic/sec: {format_bytes(stats['bytes_per_second'])}",
            "-" * 50,
            "Statistics by secret:",
        ]
        
        for secret, count in stats['secrets'].items():
            bytes_stats = stats['bytes_per_secret'].get(secret, {'sent': 0, 'received': 0})
            total = bytes_stats['sent'] + bytes_stats['received']
            lines.append(
                f"  {secret[:16]}...: {count} connections, {format_bytes(total)}"
            )
        
        if stats['top_ips']:
            lines.append("-" * 50)
            lines.append("Top 10 IPs:")
            for ip, count in stats['top_ips']:
                lines.append(f"  {ip}: {count} connections")
        
        lines.append("=" * 50)
        return "\n".join(lines)