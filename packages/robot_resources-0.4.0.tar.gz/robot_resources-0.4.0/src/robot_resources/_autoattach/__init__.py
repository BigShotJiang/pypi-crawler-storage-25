"""
Robot Resources auto-attach for Python agents.

Loaded automatically on every Python interpreter startup via ``robot-resources.pth``
(installed at the top of ``site-packages`` by hatchling, same mechanism
``coverage`` and ``ddtrace`` use).

Phases shipped:
    - Phase 2 (PyPI 0.2.0): Anthropic
    - Phase 4 (PyPI 0.3.0): OpenAI + Google

Each adapter monkey-patches its SDK's primary completion method (sync +
async) at class level. On each call, fetches a routing decision from
``POST /v1/route`` (cloud) and swaps the model id. The user's API key
flows straight to the upstream lab's API via the SDK — we never see the
request body or the response.

Why method-wrapping not env-var-override: Python agents commonly run in
environments where binding a local HTTP port is restrictive (Lambda,
Cloud Run, hardened containers). Method wrapping is pure HTTP-out, no
inbound listener required.

Lifecycle: the patches live for the lifetime of the Python interpreter —
same pattern as the OC plugin (in-process, dies with the host). No
daemon, no service registration.

Safety properties:
    - Singleton-guarded: multiple loads (subinterpreters, multiprocessing
      forks) early-return.
    - Respects per-instance user overrides (Anthropic + OpenAI: client
      ``base_url`` pointing somewhere non-default; Google: ``client_options.
      api_endpoint``).
    - Each adapter independently no-ops if its SDK isn't installed.
    - One adapter failing doesn't block the others — each attach() is
      isolated in a try/except.
    - Errors swallowed by default. ``RR_AUTOATTACH_DEBUG=1`` surfaces them
      on stderr.
    - ``RR_AUTOATTACH_DRY_RUN=1`` skips actual SDK patching (used by tests).
"""

from __future__ import annotations

import os
import sys

# Phase 7: opt-out, not opt-in. Default behavior is ON. Users who explicitly
# want to bypass the patch (e.g. one-shot scripts that need the raw SDK)
# set RR_AUTOATTACH=0 in that one process's env.
#
# Shipped as opt-in in Phase 2 while we verified the architecture. Phase 7
# lifts the gate after wizard-success funnel completions confirmed
# everything works. Users keep the kill-switch.
if os.environ.get("RR_AUTOATTACH") == "0":
    pass  # explicit opt-out
else:
    # Singleton — guard against subinterpreters, importlib.reload, etc.
    _sentinel = "__rr_autoattach_loaded__"
    if not getattr(sys, _sentinel, False):
        setattr(sys, _sentinel, True)

        if os.environ.get("RR_AUTOATTACH_DRY_RUN") != "1":
            # Each adapter is independent: a failure in one must NOT block
            # the others. Wrap each attach() in its own try/except so one
            # SDK with a breaking API change doesn't disable the rest.
            for _name, _modpath in (
                ("anthropic", "robot_resources._autoattach.anthropic_patch"),
                ("openai", "robot_resources._autoattach.openai_patch"),
                ("google", "robot_resources._autoattach.google_patch"),
            ):
                try:
                    _mod = __import__(_modpath, fromlist=["attach"])
                    _mod.attach()
                except Exception as _err:  # noqa: BLE001
                    if os.environ.get("RR_AUTOATTACH_DEBUG") == "1":
                        print(
                            f"[robot-resources/autoattach] {_name} adapter attach failed: {_err}",
                            file=sys.stderr,
                        )
