"""
Tests for robot_resources.router. Uses pytest-httpx to mock the platform
without a live Worker. Mirrors the platform test patterns.
"""

from __future__ import annotations

import pytest

from robot_resources import __version__
from robot_resources.router import (
    AuthenticationError,
    RateLimitError,
    RouterClient,
    RouterError,
    ServerError,
    route,
)

DECISION = {
    "selected_model": "claude-haiku-4-5",
    "provider": "anthropic",
    "cost_per_1k_input": 0.0008,
    "cost_per_1k_output": 0.004,
    "baseline_model": "gpt-5.4",
    "baseline_cost": 0.0025,
    "savings_percent": 68.0,
    "task_type": "coding",
    "capability_score": 0.86,
    "classifier_used": "keyword",
    "reasoning": "Selected claude-haiku-4-5 ...",
}


def _ok(payload=DECISION):
    return {"success": True, "data": payload}


def test_version_is_pinned():
    assert __version__ == "0.4.0"


def test_route_happy_path(httpx_mock):
    httpx_mock.add_response(
        url="https://api.robotresources.ai/v1/route",
        method="POST",
        json=_ok(),
    )
    decision = route("write a python function")
    assert decision["selected_model"] == "claude-haiku-4-5"
    assert decision["provider"] == "anthropic"
    assert decision["task_type"] == "coding"


def test_route_passes_available_providers(httpx_mock):
    httpx_mock.add_response(json=_ok())
    route("write a function", available_providers=["anthropic", "openai"])
    body = httpx_mock.get_requests()[0].read().decode()
    assert "anthropic" in body
    assert "openai" in body


def test_route_passes_available_models(httpx_mock):
    httpx_mock.add_response(json=_ok())
    route("hello", available_models=["claude-haiku-4-5", "gemini-1.5-flash"])
    body = httpx_mock.get_requests()[0].read().decode()
    assert "claude-haiku-4-5" in body
    assert "gemini-1.5-flash" in body


def test_route_uses_api_key_from_kwarg(httpx_mock):
    httpx_mock.add_response(json=_ok())
    route("hello", api_key="rr_live_test_key_123")
    headers = httpx_mock.get_requests()[0].headers
    assert headers["Authorization"] == "Bearer rr_live_test_key_123"


def test_route_uses_api_key_from_env(httpx_mock, monkeypatch):
    monkeypatch.setenv("RR_API_KEY", "rr_env_key_456")
    httpx_mock.add_response(json=_ok())
    route("hello")
    headers = httpx_mock.get_requests()[0].headers
    assert headers["Authorization"] == "Bearer rr_env_key_456"


def test_route_omits_auth_when_no_api_key(httpx_mock, monkeypatch):
    monkeypatch.delenv("RR_API_KEY", raising=False)
    httpx_mock.add_response(json=_ok())
    route("hello")
    headers = httpx_mock.get_requests()[0].headers
    assert "Authorization" not in headers


def test_route_endpoint_override(httpx_mock):
    httpx_mock.add_response(url="http://localhost:8787/v1/route", json=_ok())
    route("hello", endpoint="http://localhost:8787/v1/route")
    assert len(httpx_mock.get_requests()) == 1


def test_route_endpoint_appended_when_root_url_passed(httpx_mock):
    httpx_mock.add_response(url="http://localhost:8787/v1/route", json=_ok())
    route("hello", endpoint="http://localhost:8787")
    assert len(httpx_mock.get_requests()) == 1


def test_route_endpoint_from_env(httpx_mock, monkeypatch):
    monkeypatch.setenv("RR_PLATFORM_URL", "https://staging.robotresources.ai")
    httpx_mock.add_response(url="https://staging.robotresources.ai/v1/route", json=_ok())
    route("hello")
    assert len(httpx_mock.get_requests()) == 1


def test_route_raises_authentication_error_on_401(httpx_mock):
    httpx_mock.add_response(status_code=401, json={"success": False, "error": {"code": "UNAUTHORIZED"}})
    with pytest.raises(AuthenticationError):
        route("hello")


def test_route_raises_rate_limit_error_on_429(httpx_mock):
    httpx_mock.add_response(status_code=429, json={"success": False, "error": {"code": "RATE_LIMITED"}})
    with pytest.raises(RateLimitError):
        route("hello")


def test_route_retries_on_503_then_succeeds(httpx_mock):
    httpx_mock.add_response(status_code=503, text="bad gateway")
    httpx_mock.add_response(json=_ok())
    decision = route("hello")
    assert decision["selected_model"] == "claude-haiku-4-5"
    assert len(httpx_mock.get_requests()) == 2


def test_route_retries_on_500_3_attempts_then_raises(httpx_mock):
    for _ in range(4):  # 1 initial + 3 retries
        httpx_mock.add_response(status_code=500, text="oops")
    with pytest.raises(ServerError):
        route("hello")
    assert len(httpx_mock.get_requests()) == 4


def test_route_validation_rejects_empty_prompt():
    with pytest.raises(ValueError):
        route("")


def test_route_validation_rejects_whitespace_only_prompt():
    with pytest.raises(ValueError):
        route("   \n\t  ")


def test_route_validation_rejects_non_string_prompt():
    with pytest.raises(ValueError):
        route(123)  # type: ignore[arg-type]


def test_route_raises_router_error_on_400(httpx_mock):
    httpx_mock.add_response(status_code=400, text="bad request")
    with pytest.raises(RouterError):
        route("hello")


def test_route_raises_when_payload_indicates_failure(httpx_mock):
    httpx_mock.add_response(
        json={"success": False, "error": {"code": "NO_AVAILABLE_MODELS", "message": "filter empty"}},
    )
    with pytest.raises(RouterError) as exc_info:
        route("hello", available_providers=["nonexistent"])
    assert "NO_AVAILABLE_MODELS" in str(exc_info.value)


def test_router_client_can_be_reused_across_calls(httpx_mock):
    httpx_mock.add_response(json=_ok())
    httpx_mock.add_response(json=_ok())
    with RouterClient() as client:
        client.route("first prompt")
        client.route("second prompt")
    assert len(httpx_mock.get_requests()) == 2


def test_router_client_close_is_idempotent():
    client = RouterClient()
    client.close()
    client.close()
