import torch
import torch.nn as nn
import torch.nn.functional as F

class DemoTorchLeNet5(nn.Module):
    r"""
    A simple implementation of the LeNet-5 architecture.

    This model follows the classic architecture: two convolutional layers
    followed by max pooling, and three fully connected layers.

    .. note::
        This implementation expects the input image size to be strictly
        :math:`(32, 32)` due to the hardcoded input features of the first
        linear layer (``16 * 5 * 5``).

    Args:
        num_classes (int): Number of classes for classification. Default: ``10``.
        input_channels (int): Number of channels in the input image. Default: ``1``.

    Shape:
        - Input: :math:`(N, C_{in}, 32, 32)` where :math:`C_{in} = \text{input\_channels}`.
        - Output: :math:`(N, C_{out})` where :math:`C_{out} = \text{num\_classes}`.

    Attributes:
        conv1 (nn.Conv2d): First convolutional layer.
        pool (nn.MaxPool2d): Max pooling layer.
        conv2 (nn.Conv2d): Second convolutional layer.
        fc1 (nn.Linear): First fully connected layer.
        fc2 (nn.Linear): Second fully connected layer.
        fc3 (nn.Linear): Output layer.

    Examples::

        >>> # Initialize model
        >>> model = DemoTorchLeNet5(num_classes=10, input_channels=1)
        >>> # Create a dummy input (batch_size=1, channels=1, height=32, width=32)
        >>> x = torch.randn(1, 1, 32, 32)
        >>> # Forward pass
        >>> output = model(x)
        >>> print(output.shape)
        torch.Size([1, 10])
    """

    def __init__(self, num_classes: int = 10, input_channels: int = 1) -> None:
        super().__init__()
        self.conv1 = nn.Conv2d(input_channels, 6, kernel_size=5)
        self.pool = nn.MaxPool2d(kernel_size=2, stride=2)
        self.conv2 = nn.Conv2d(6, 16, kernel_size=5)

        # The input size to fc1 is calculated as:
        # 32 -> conv1(5x5) -> 28 -> pool(2x2) -> 14
        # 14 -> conv2(5x5) -> 10 -> pool(2x2) -> 5
        # Output depth is 16, so flattened size is 16 * 5 * 5
        self.fc1 = nn.Linear(16 * 5 * 5, 120)
        self.fc2 = nn.Linear(120, 84)
        self.fc3 = nn.Linear(84, num_classes)

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        """
        Defines the computation performed at every call.

        Args:
            x (torch.Tensor): The input data tensor.

        Returns:
            torch.Tensor: The raw classification logits (before Softmax).
        """
        x = self.pool(F.relu(self.conv1(x)))
        x = self.pool(F.relu(self.conv2(x)))

        # Flatten: (N, 16, 5, 5) -> (N, 400)
        x = x.view(-1, 16 * 5 * 5)

        x = F.relu(self.fc1(x))
        x = F.relu(self.fc2(x))
        x = self.fc3(x)
        return x