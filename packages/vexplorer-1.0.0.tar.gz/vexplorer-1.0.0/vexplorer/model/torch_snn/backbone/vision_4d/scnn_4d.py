import torch
import torch.nn as nn
import torch.nn.functional as F

thresh = 0.5  # neuronal threshold
lens = 0.5  # hyper-parameters of approximate function
decay = 0.2  # decay constants

class SurrGradSpike(torch.autograd.Function):
    scale = 100.0  # controls steepness of surrogate gradient

    @staticmethod
    def forward(ctx, input):
        ctx.save_for_backward(input)
        out = torch.zeros_like(input)
        out[input > 0] = 1.0
        return out

    @staticmethod
    def backward(ctx, grad_output):
        input, = ctx.saved_tensors
        grad_input = grad_output.clone()
        grad = grad_input / (SurrGradSpike.scale * torch.abs(input) + 1.0) ** 2
        return grad

spike_fn = SurrGradSpike.apply

class ActFun(torch.autograd.Function):
    @staticmethod
    def forward(ctx, input):
        ctx.save_for_backward(input)
        return input.gt(thresh).float()

    @staticmethod
    def backward(ctx, grad_output):
        input, = ctx.saved_tensors
        grad_input = grad_output.clone()
        temp = abs(input - thresh) < lens
        return grad_input * temp.float()

act_fun = ActFun.apply

class LIFConv3D(nn.Module):
    def __init__(self, in_planes, out_planes, kernel_size, stride, padding, decay=0.2):
        super().__init__()
        self.conv = nn.Conv3d(in_planes, out_planes, kernel_size=kernel_size, stride=stride, padding=padding)
        self.decay = decay

    def forward(self, x, state=None):
        x = self.conv(x)
        if state is None:
            mem = torch.zeros_like(x, device=x.device)
            spike = torch.zeros_like(x, device=x.device)
        else:
            mem, spike = state

        new_mem = mem * self.decay * (1. - spike) + x
        new_spike = act_fun(new_mem)

        return new_spike, (new_mem, new_spike)

class LIFLinear(nn.Module):
    def __init__(self, in_planes, out_planes, decay=0.2, last_layer=False):
        super().__init__()
        self.fc = nn.Linear(in_planes, out_planes)
        self.decay = decay
        self.last_layer = last_layer

    def forward(self, x, state=None):
        x = self.fc(x)
        if state is None:
            mem = torch.zeros_like(x, device=x.device)
            spike = torch.zeros_like(x, device=x.device)
        else:
            mem, spike = state

        if self.last_layer:
            new_mem = mem + x
            new_spike = new_mem
        else:
            new_mem = mem * self.decay * (1. - spike) + x
            new_spike = act_fun(new_mem)

        return new_spike, (new_mem, new_spike)

class SCNN4D(nn.Module):
    """
    4D Spiking Convolutional Neural Network for spatiotemporal data.

    **Input Format:**
    - **Mainstream format (batch-first)**: (B, T, C, D, H, W)
      - B: Batch size
      - T: Time steps
      - C: Input channels (typically 2 for DVS events)
      - D, H, W: Spatial dimensions (Depth, Height, Width)

    **Output Format:**
    - (B, num_classes): Classification logits averaged over time

    **Performance Notes:**
    - This version supports dynamic input sizes (no fixed D/H/W in __init__)
    - Uses adaptive pooling to handle varying spatial dimensions
    - Faster computation with fewer hardcoded size checks
    """
    def __init__(self, output_class, input_channel=2, need_last_layer=True, **kwargs):
        super(SCNN4D, self).__init__()
        # Remove fixed D, H, W parameters - now supports dynamic input sizes
        self.conv1 = LIFConv3D(in_planes=input_channel, out_planes=15, kernel_size=3, stride=1, padding=1)
        self.conv2 = LIFConv3D(in_planes=15, out_planes=40, kernel_size=3, stride=1, padding=1)

        # Use adaptive pooling to get fixed feature size regardless of input dimensions
        # After conv1 + pool + conv2 + pool, we use adaptive pooling to get 4x4x4 features
        self.adaptive_pool = nn.AdaptiveAvgPool3d((4, 4, 4))

        # Fixed feature size after adaptive pooling
        self.fc1_in_features = 40 * 4 * 4 * 4  # 40 channels * 4 * 4 * 4 = 2560
        self.fc1 = LIFLinear(in_planes=self.fc1_in_features, out_planes=300)
        self.fc2 = LIFLinear(in_planes=300, out_planes=output_class, decay=0.2, last_layer=need_last_layer)
        self.need_last_layer = need_last_layer

    def forward(self, input):
        """
        Forward pass with dynamic input size support.

        Args:
            input: Shape (B, T, C, D, H, W) - Batch, Time, Channel, Depth, Height, Width

        Returns:
            outputs: Shape (B, num_classes) - Classification logits
        """
        conv1_state, conv2_state, fc1_state, fc2_state = None, None, None, None
        total_mem = 0

        for step in range(input.shape[1]):
            x = input[:, step].float()

            # 卷积层1 + 池化
            x, conv1_state = self.conv1(x, conv1_state)
            x = F.avg_pool3d(x, 2)

            # 卷积层2 + 池化
            x, conv2_state = self.conv2(x, conv2_state)
            x = F.avg_pool3d(x, 2)

            # 使用自适应池化以支持任意输入尺寸
            x = self.adaptive_pool(x)

            # 展平
            x = x.view(input.shape[0], -1)

            # 全连接层1
            x, fc1_state = self.fc1(x, fc1_state)

            # 全连接层2
            x, fc2_state = self.fc2(x, fc2_state)

            # 累加膜电位
            if self.need_last_layer:
                total_mem += fc2_state[0]  # 使用膜电位
            else:
                total_mem += x  # 使用输出

        # 计算平均膜电位
        outputs = total_mem / input.shape[1]
        return outputs


# ============================================================================
# Model Size Configurations
# ============================================================================

MODEL_SIZES = {
    'small': {
        'output_class': 10,
        'input_channel': 2,
        'need_last_layer': True,
    },
    'medium': {
        'output_class': 10,
        'input_channel': 2,
        'need_last_layer': True,
    },
    'large': {
        'output_class': 10,
        'input_channel': 2,
        'need_last_layer': True,
    }
}


def build_model(size='medium', **kwargs):
    """
    Build SCNN 4D model with specified size configuration.

    Note: All sizes use the same architecture. Size parameter is provided
    for API consistency with other models.

    Args:
        size: Model size ('small', 'medium', 'large') - all use same architecture
        **kwargs: Additional parameters that override the size configuration

    Returns:
        Initialized model

    Examples:
        >>> # Build medium model
        >>> model = build_model(size='medium', output_class=10)

        >>> # Build with custom parameters
        >>> model = build_model(size='large', output_class=100, input_channel=3)
    """
    if size not in MODEL_SIZES:
        raise ValueError(f"Size must be 'small', 'medium', or 'large', got '{size}'")

    config = MODEL_SIZES[size].copy()
    config.update(kwargs)

    return SCNN4D(**config)


