# HouyiB 4D — Physics-Aware SNN for Solar Flare Forecasting
#
# Three architectural innovations over standard Spikformer3D:
#   1. PLIFNode  – Parametric LIF with learnable time constant τ (multi-scale temporal)
#   2. PhysicsAwareSepConv – Anisotropic conv decomposed into XY (photosphere) + Z (height)
#   3. Z-Positional Encoding – Absolute position encoding for solar atmosphere height axis
#
# Input:  (B, T, C, H, W, D)   – B=batch, T=SNN time steps, C=channels, H,W=spatial, D=height
# Output: (B, num_classes)

import math
import torch
import torch.nn as nn
from timm.models.layers import to_2tuple, trunc_normal_, DropPath
from timm.models.registry import register_model
from timm.models.vision_transformer import _cfg
import torch.nn.functional as F
from braincog.model_zoo.base_module import BaseModule
from braincog.base.node.node import *
from braincog.base.connection.layer import *
from braincog.base.strategy.surrogate import *
from einops import rearrange
from torch.nn.attention import SDPBackend, sdpa_kernel

__all__ = ['HouyiB4D']


# ============================================================================
# Neuron Nodes
# ============================================================================

class MyBaseNode(BaseNode):
    """Base neuron node with rearrangement support for 6-D spatial-temporal data."""

    def __init__(self, threshold=0.5, step=4, layer_by_layer=False, mem_detach=False):
        super().__init__(
            threshold=threshold, step=step,
            layer_by_layer=layer_by_layer, mem_detach=mem_detach,
        )

    def rearrange2node(self, inputs):
        if self.groups != 1:
            if len(inputs.shape) == 6:
                outputs = rearrange(inputs, 'b (c t) h w d -> t b c h w d', t=self.step)
            elif len(inputs.shape) == 4:
                outputs = rearrange(inputs, 'b (c t) h w -> t b c h w', t=self.step)
            elif len(inputs.shape) == 2:
                outputs = rearrange(inputs, 'b (c t) -> t b c', t=self.step)
            else:
                raise NotImplementedError(f"Unsupported shape: {inputs.shape}")
        elif self.layer_by_layer:
            if len(inputs.shape) == 6:
                outputs = rearrange(inputs, '(t b) c h w d -> t b c h w d', t=self.step)
            elif len(inputs.shape) == 4:
                outputs = rearrange(inputs, '(t b) n c -> t b n c', t=self.step)
            elif len(inputs.shape) == 3:
                outputs = rearrange(inputs, '(t b) n c -> t b n c', t=self.step)
            elif len(inputs.shape) == 2:
                outputs = rearrange(inputs, '(t b) c -> t b c', t=self.step)
            else:
                raise NotImplementedError(f"Unsupported shape: {inputs.shape}")
        else:
            outputs = inputs
        return outputs

    def rearrange2op(self, inputs):
        if self.groups != 1:
            if len(inputs.shape) == 7:
                outputs = rearrange(inputs, 't b c h w d -> b (c t) h w d')
            elif len(inputs.shape) == 5:
                outputs = rearrange(inputs, 't b c h w -> b (c t) h w')
            elif len(inputs.shape) == 3:
                outputs = rearrange(inputs, 't b c -> b (c t)')
            else:
                raise NotImplementedError(f"Unsupported shape: {inputs.shape}")
        elif self.layer_by_layer:
            if len(inputs.shape) == 7:
                outputs = rearrange(inputs, 't b c h w d -> (t b) c h w d')
            elif len(inputs.shape) == 4:
                outputs = rearrange(inputs, 't b n c -> (t b) n c')
            elif len(inputs.shape) == 3:
                outputs = rearrange(inputs, 't b c -> (t b) c')
            else:
                raise NotImplementedError(f"Unsupported shape: {inputs.shape}")
        else:
            outputs = inputs
        return outputs


class MyGrad(SurrogateFunctionBase):
    """Surrogate gradient: sigmoid approximation."""
    def __init__(self, alpha=4., requires_grad=False):
        super().__init__(alpha, requires_grad)

    @staticmethod
    def act_fun(x, alpha):
        return sigmoid.apply(x, alpha)


# ============================================================================
# 创新点一: PLIFNode — Parametric LIF with learnable time constant τ
# ============================================================================

class PLIFNode(MyBaseNode):
    """
    Parametric LIF (PLIF) neuron — Time-Adaptive SNN.

    The time constant τ is parameterized as a learnable weight, allowing the
    network to adaptively capture both slow flux emergence (days) and fast
    magnetic reconnection (minutes) in solar dynamics.

    τ_actual = sigmoid(w_tau) * tau_range + tau_min

    This ensures τ stays in a physically meaningful range [tau_min, tau_min+tau_range].
    """

    def __init__(self, threshold=1., step=4, layer_by_layer=True,
                 init_tau=2.0, tau_min=1.1, tau_range=10.0,
                 act_fun=MyGrad, mem_detach=True, *args, **kwargs):
        super().__init__(
            threshold=threshold, step=step,
            layer_by_layer=layer_by_layer, mem_detach=mem_detach,
        )
        if isinstance(act_fun, str):
            act_fun = eval(act_fun)
        self.act_fun = act_fun(alpha=4., requires_grad=True)
        self.threshold_param = nn.Parameter(torch.tensor(float(threshold)))

        # Learnable τ: parameterized via log-sigmoid for stable training
        self.tau_min = tau_min
        self.tau_range = tau_range
        init_w = math.log((init_tau - tau_min) / (tau_range - (init_tau - tau_min)) + 1e-8) \
            if tau_min < init_tau < tau_min + tau_range else 0.0
        self.w_tau = nn.Parameter(torch.tensor(init_w))

    def integral(self, inputs):
        tau_actual = torch.sigmoid(self.w_tau) * self.tau_range + self.tau_min
        self.mem = self.mem + (inputs - self.mem) / tau_actual

    def calc_spike(self):
        self.spike = self.act_fun(self.mem - self.threshold_param)
        self.mem = self.mem * (1 - self.spike.detach())


# ============================================================================
# 创新点二: PhysicsAwareSepConv — Anisotropic convolution (XY + Z decomposition)
# ============================================================================

class BNAndPadLayer3d(nn.Module):
    """BatchNorm3d followed by symmetric zero-padding."""
    def __init__(self, pad_pixels, num_features,
                 eps=1e-5, momentum=0.1, affine=True, track_running_stats=True):
        super().__init__()
        self.bn = nn.BatchNorm3d(num_features, eps, momentum, affine, track_running_stats)
        self.pad_pixels = pad_pixels

    def forward(self, x):
        x = self.bn(x)
        if self.pad_pixels > 0:
            x = F.pad(x, [self.pad_pixels] * 6)
        return x

    @property
    def weight(self):          return self.bn.weight
    @property
    def bias(self):            return self.bn.bias
    @property
    def running_mean(self):    return self.bn.running_mean
    @property
    def running_var(self):     return self.bn.running_var
    @property
    def eps(self):             return self.bn.eps


class RepConv3d(nn.Module):
    """Reparameterised 3-D convolution."""
    def __init__(self, in_channels: int, out_channels: int, bias: bool = False):
        super().__init__()
        self.body = nn.Sequential(
            nn.Conv3d(in_channels, in_channels, 1, 1, 0, bias=False, groups=1),
            BNAndPadLayer3d(pad_pixels=1, num_features=in_channels),
            nn.Conv3d(in_channels, in_channels, 3, 1, 0, groups=in_channels, bias=False),
            nn.Conv3d(in_channels, out_channels, 1, 1, 0, groups=1, bias=False),
            nn.BatchNorm3d(out_channels),
        )

    def forward(self, x):
        return self.body(x)


class PhysicsAwareSepConv(BaseModule):
    """
    Physics-aware anisotropic separable 3D convolution.

    Decomposes standard 3D convolution into:
      1. XY-plane convolution (photosphere surface features, kernel 7×7×1)
      2. Z-axis convolution (solar atmosphere height features, kernel 1×1×Kz)

    This matches the physical anisotropy of the solar atmosphere where
    horizontal (photosphere) and vertical (chromosphere→corona) physics differ.

    Input / output: (T, B, C, H, W, D)
    """

    def __init__(self, dim: int, step: int = 8, encode_type: str = 'direct',
                 expansion_ratio: int = 2, bias: bool = False,
                 kernel_xy: int = 7, kernel_z: int = 7):
        super().__init__(step=step, encode_type=encode_type)
        med = int(expansion_ratio * dim)
        pad_xy = kernel_xy // 2
        pad_z = kernel_z // 2

        self.lif1    = PLIFNode(step=step, init_tau=2.0)
        self.pwconv1 = nn.Conv3d(dim, med, 1, bias=bias)
        self.bn1     = nn.BatchNorm3d(med)
        self.lif2    = PLIFNode(step=step, init_tau=2.0)

        # Anisotropic decomposition:
        # XY-plane: photosphere surface features
        self.dwconv_xy = nn.Conv3d(
            med, med, kernel_size=(kernel_xy, kernel_xy, 1),
            padding=(pad_xy, pad_xy, 0), groups=med, bias=bias
        )
        # Z-axis: solar atmosphere height stratification
        self.dwconv_z = nn.Conv3d(
            med, med, kernel_size=(1, 1, kernel_z),
            padding=(0, 0, pad_z), groups=med, bias=bias
        )

        self.pwconv2 = nn.Conv3d(med, dim, 1, bias=bias)
        self.bn2     = nn.BatchNorm3d(dim)

    def forward(self, x):
        """x: (T, B, C, H, W, D)"""
        self.reset()
        T, B, C, H, W, D = x.shape

        x = self.lif1(x.flatten(0, 1)).reshape(T, B, C, H, W, D).contiguous()
        x = self.bn1(self.pwconv1(x.flatten(0, 1))).reshape(T, B, -1, H, W, D)
        x = self.lif2(x.flatten(0, 1)).reshape(T, B, -1, H, W, D).contiguous()

        # Sequential anisotropic filtering
        x_flat = x.flatten(0, 1)
        x_flat = self.dwconv_z(self.dwconv_xy(x_flat))

        x = self.bn2(self.pwconv2(x_flat)).reshape(T, B, -1, H, W, D)
        return x


# ============================================================================
# MLP (vectorised via Conv3d)
# ============================================================================

class MLP(BaseModule):
    """Point-wise MLP via Conv3d(1×1×1). Input / output: (T, B, C, H, W, D)"""

    def __init__(self, in_features: int, step: int = 10, encode_type: str = 'direct',
                 hidden_features: int | None = None, out_features: int | None = None,
                 drop: float = 0.):
        super().__init__(step=step, encode_type=encode_type)
        hidden_features = hidden_features or in_features
        out_features = out_features or in_features

        self.fc1_conv = nn.Conv3d(in_features, hidden_features, kernel_size=1)
        self.fc1_bn   = nn.BatchNorm3d(hidden_features)
        self.fc1_lif  = PLIFNode(step=step, init_tau=2.0)

        self.fc2_conv = nn.Conv3d(hidden_features, out_features, kernel_size=1)
        self.fc2_bn   = nn.BatchNorm3d(out_features)
        self.fc2_lif  = PLIFNode(step=step, init_tau=2.0)

        self.c_hidden = hidden_features
        self.c_output = out_features

    def forward(self, x):
        """x: (T, B, C, H, W, D)"""
        self.reset()
        T, B, C, H, W, D = x.shape

        x = self.fc1_lif(x.flatten(0, 1))
        x = self.fc1_bn(self.fc1_conv(x)).reshape(T, B, self.c_hidden, H, W, D).contiguous()

        x = self.fc2_lif(x.flatten(0, 1))
        x = self.fc2_bn(self.fc2_conv(x)).reshape(T, B, self.c_output, H, W, D).contiguous()
        return x


# ============================================================================
# Attention Modules
# ============================================================================

class SSAttention3D(BaseModule):
    """Spiking Self-Attention with Conv3d projections + BatchNorm3d (PLIF variant)."""

    def __init__(self, dim: int, step: int = 10, encode_type: str = 'direct',
                 num_heads: int = 16, qkv_bias: bool = False, qk_scale=None,
                 attn_drop: float = 0., proj_drop: float = 0., sr_ratio: int = 1):
        super().__init__(step=step, encode_type=encode_type)
        assert dim % num_heads == 0

        self.dim = dim
        self.num_heads = num_heads
        self.head_dim = dim // num_heads
        self.scale = qk_scale if qk_scale is not None else 0.125

        self.qkv_conv = nn.Conv3d(dim, dim * 3, kernel_size=1, bias=qkv_bias)
        self.qkv_bn = nn.BatchNorm3d(dim * 3)

        self.q_lif = PLIFNode(step=step, init_tau=2.0)
        self.k_lif = PLIFNode(step=step, init_tau=2.0)
        self.v_lif = PLIFNode(step=step, init_tau=2.0)
        self.attn_lif = PLIFNode(step=step, init_tau=2.0, threshold=0.5)

        self.attn_drop = nn.Dropout(attn_drop)
        self.proj_conv = nn.Conv3d(dim, dim, kernel_size=1, bias=False)
        self.proj_bn = nn.BatchNorm3d(dim)
        self.proj_drop = nn.Dropout(proj_drop)

    def forward(self, x):
        """x: (T, B, C, H, W, D)"""
        self.reset()
        T, B, C, H, W, D = x.shape

        qkv = self.qkv_bn(self.qkv_conv(x.flatten(0, 1)))
        qkv = rearrange(qkv, '(T B) C H W D -> T B C H W D', T=T, B=B)

        q_proj, k_proj, v_proj = qkv.chunk(3, dim=2)

        q = self.q_lif(q_proj.flatten(0, 1))
        k = self.k_lif(k_proj.flatten(0, 1))
        v = self.v_lif(v_proj.flatten(0, 1))

        q = rearrange(q, '(T B) (Nh Ch) H W D -> T B Nh (H W D) Ch',
                      T=T, B=B, Nh=self.num_heads, Ch=self.head_dim).contiguous()
        k = rearrange(k, '(T B) (Nh Ch) H W D -> T B Nh (H W D) Ch',
                      T=T, B=B, Nh=self.num_heads, Ch=self.head_dim).contiguous()
        v = rearrange(v, '(T B) (Nh Ch) H W D -> T B Nh (H W D) Ch',
                      T=T, B=B, Nh=self.num_heads, Ch=self.head_dim).contiguous()

        # Linear attention: Q @ (K^T @ V)
        kv = (k.transpose(-2, -1) @ v) * self.scale
        x_attn = q @ kv
        x_attn = self.attn_drop(x_attn)

        x_attn = rearrange(x_attn, 'T B Nh (H W D) Ch -> (T B) (Nh Ch) H W D',
                           T=T, B=B, H=H, W=W, D=D).contiguous()

        x_attn = self.attn_lif(x_attn)
        x = self.proj_drop(self.proj_bn(self.proj_conv(x_attn)))
        return rearrange(x, '(T B) C H W D -> T B C H W D', T=T, B=B).contiguous()


class SDSAttention3D(BaseModule):
    """Spike-Driven Self-Attention with RepConv3d projections (PLIF variant)."""

    def __init__(self, dim: int, step: int = 10, encode_type: str = 'direct',
                 num_heads: int = 16, qkv_bias: bool = False, qk_scale=None,
                 attn_drop: float = 0.2, proj_drop: float = 0.,
                 sr_ratio: int = 1, attn_type: str = 'sdsa2'):
        super().__init__(step=step, encode_type=encode_type)
        assert dim % num_heads == 0
        assert attn_type in ('sdsa', 'sdsa2')

        self.dim = dim
        self.num_heads = num_heads
        self.head_dim = dim // num_heads
        self.scale = qk_scale if qk_scale is not None else 0.125
        self.attn_type = attn_type

        self.head_lif = PLIFNode(step=step, init_tau=2.0)

        self.q_conv = RepConv3d(dim, dim, bias=qkv_bias)
        self.q_bn = nn.BatchNorm3d(dim)
        self.q_lif = PLIFNode(step=step, init_tau=2.0)

        self.k_conv = RepConv3d(dim, dim, bias=qkv_bias)
        self.k_bn = nn.BatchNorm3d(dim)
        self.k_lif = PLIFNode(step=step, init_tau=2.0)

        self.v_conv = RepConv3d(dim, dim, bias=qkv_bias)
        self.v_bn = nn.BatchNorm3d(dim)
        self.v_lif = PLIFNode(step=step, init_tau=2.0)

        self.attn_drop = nn.Dropout(attn_drop)
        self.attn_lif = PLIFNode(step=step, init_tau=2.0, threshold=0.5)

        self.proj_conv = RepConv3d(dim, dim, bias=False)
        self.proj_bn = nn.BatchNorm3d(dim)
        self.proj_drop = nn.Dropout(proj_drop)

    def _project(self, x_tb, conv, bn, lif, T, B, C, H, W, D):
        out = rearrange(
            lif(bn(conv(x_tb))),
            '(T B) (Nh Ch) H W D -> T B Nh (H W D) Ch',
            T=T, B=B, Nh=self.num_heads, Ch=self.head_dim,
        )
        return out.contiguous()

    def forward(self, x):
        """x: (T, B, C, H, W, D)"""
        self.reset()
        T, B, C, H, W, D = x.shape

        x = rearrange(self.head_lif(x.flatten(0, 1)),
                      '(T B) C H W D -> T B C H W D', T=T, B=B).contiguous()
        x_tb = x.flatten(0, 1)

        q = self._project(x_tb, self.q_conv, self.q_bn, self.q_lif, T, B, C, H, W, D)
        k = self._project(x_tb, self.k_conv, self.k_bn, self.k_lif, T, B, C, H, W, D)
        v = self._project(x_tb, self.v_conv, self.v_bn, self.v_lif, T, B, C, H, W, D)

        if self.attn_type == 'sdsa':
            x_attn = (q @ k.transpose(-2, -1)) * self.scale @ v
        else:
            x_attn = q @ ((k.transpose(-2, -1) @ v) * self.scale)

        x_attn = self.attn_drop(x_attn)

        x_attn = rearrange(x_attn, 'T B Nh (H W D) Ch -> (T B) (Nh Ch) H W D',
                           H=H, W=W, D=D).contiguous()

        x_attn = self.attn_lif(x_attn).reshape(T, B, C, H, W, D)
        x = self.proj_drop(self.proj_bn(self.proj_conv(x_attn.flatten(0, 1))))
        return rearrange(x, '(T B) C H W D -> T B C H W D', T=T, B=B).contiguous()


class ANNFlashAttention3D(nn.Module):
    """Pure-ANN Flash Attention backed by PyTorch SDPA."""

    def __init__(self, dim: int, num_heads: int = 16, qkv_bias: bool = False,
                 attn_drop: float = 0., proj_drop: float = 0.,
                 enable_flash: bool = True, enable_mem_efficient: bool = True,
                 enable_math: bool = True, enable_cudnn: bool = True):
        super().__init__()
        assert dim % num_heads == 0
        self.num_heads = num_heads
        self.head_dim = dim // num_heads

        self.qkv_conv = nn.Conv3d(dim, dim * 3, kernel_size=1, bias=qkv_bias)
        self.qkv_bn = nn.BatchNorm3d(dim * 3)
        self.attn_drop = nn.Dropout(attn_drop)
        self.proj_conv = nn.Conv3d(dim, dim, kernel_size=1)
        self.proj_bn = nn.BatchNorm3d(dim)
        self.proj_drop = nn.Dropout(proj_drop)

        backends = []
        if enable_flash:          backends.append(SDPBackend.FLASH_ATTENTION)
        if enable_mem_efficient:  backends.append(SDPBackend.EFFICIENT_ATTENTION)
        if enable_math:           backends.append(SDPBackend.MATH)
        if enable_cudnn:          backends.append(SDPBackend.CUDNN_ATTENTION)
        self.backends = backends

    def forward(self, x):
        T, B, C, H, W, D = x.shape
        x_flat = x.flatten(0, 1)
        qkv = self.qkv_bn(self.qkv_conv(x_flat))

        qkv_flat = rearrange(qkv, '(T B) (three C) H W D -> (T B) (H W D) (three C)',
                             T=T, B=B, three=3, C=C)
        q, k, v = qkv_flat.chunk(3, dim=-1)

        q = rearrange(q, '(T B) N (Nh Ch) -> (T B) Nh N Ch',
                      T=T, B=B, Nh=self.num_heads, Ch=self.head_dim).contiguous()
        k = rearrange(k, '(T B) N (Nh Ch) -> (T B) Nh N Ch',
                      T=T, B=B, Nh=self.num_heads, Ch=self.head_dim).contiguous()
        v = rearrange(v, '(T B) N (Nh Ch) -> (T B) Nh N Ch',
                      T=T, B=B, Nh=self.num_heads, Ch=self.head_dim).contiguous()

        with sdpa_kernel(backends=self.backends):
            x_attn = F.scaled_dot_product_attention(
                q, k, v, attn_mask=None,
                dropout_p=self.attn_drop.p if self.training else 0.0,
                is_causal=False,
            )

        x_attn = rearrange(x_attn, '(T B) Nh N Ch -> (T B) (H W D) (Nh Ch)',
                           T=T, B=B, H=H, W=W, D=D).contiguous()
        x_attn = rearrange(x_attn, '(T B) (H W D) C -> (T B) C H W D',
                           T=T, B=B, H=H, W=W, D=D).contiguous()

        x_attn = self.proj_drop(self.proj_bn(self.proj_conv(x_attn)))
        return rearrange(x_attn, '(T B) C H W D -> T B C H W D', T=T, B=B).contiguous()


# ============================================================================
# Transformer Block
# ============================================================================

class Block(nn.Module):
    """Transformer block with attention + MLP + residual (PLIF variant)."""

    _SNN_TYPES = frozenset({'sdsa', 'sdsa2', 'ssa'})

    def __init__(self, dim: int, num_heads: int, step: int = 10,
                 mlp_ratio: float = 4., qkv_bias: bool = False, qk_scale=None,
                 drop: float = 0., attn_drop: float = 0., drop_path: float = 0.,
                 norm_layer=nn.LayerNorm, sr_ratio: int = 1,
                 attn_type: str = 'sdsa2'):
        super().__init__()

        self.attn_type = attn_type
        self.is_snn = attn_type in self._SNN_TYPES

        if attn_type in ('sdsa', 'sdsa2'):
            self.attn = SDSAttention3D(
                dim, step=step, num_heads=num_heads,
                qkv_bias=qkv_bias, qk_scale=qk_scale,
                attn_drop=attn_drop, proj_drop=drop,
                sr_ratio=sr_ratio, attn_type=attn_type,
            )
        elif attn_type == 'ssa':
            self.attn = SSAttention3D(
                dim, step=step, num_heads=num_heads,
                qkv_bias=qkv_bias, qk_scale=qk_scale,
                attn_drop=attn_drop, proj_drop=drop,
            )
        elif attn_type == 'annfa':
            self.attn = ANNFlashAttention3D(
                dim, num_heads=num_heads,
                qkv_bias=qkv_bias, attn_drop=attn_drop, proj_drop=drop,
            )
            self.norm1 = norm_layer(dim)
            self.norm2 = norm_layer(dim)
        else:
            raise ValueError(f"attn_type must be 'sdsa'|'sdsa2'|'ssa'|'annfa', got '{attn_type}'")

        mlp_hidden = int(dim * mlp_ratio)
        self.mlp = MLP(step=step, in_features=dim, hidden_features=mlp_hidden, drop=drop)
        self.drop_path = DropPath(drop_path) if drop_path > 0. else nn.Identity()

    def _forward_snn(self, x):
        x = x + self.drop_path(self.attn(x))
        x = x + self.drop_path(self.mlp(x))
        return x

    def _forward_ann(self, x):
        T, B, C, H, W, D = x.shape

        def _norm(m, y):
            y = rearrange(y, 'T B C H W D -> (T B) (H W D) C').contiguous()
            y = m(y)
            return rearrange(y, '(T B) (H W D) C -> T B C H W D',
                             T=T, B=B, H=H, W=W, D=D).contiguous()

        x = x + self.drop_path(self.attn(_norm(self.norm1, x)))
        x = x + self.drop_path(self.mlp(_norm(self.norm2, x)))
        return x

    def forward(self, x):
        return self._forward_snn(x) if self.is_snn else self._forward_ann(x)


# ============================================================================
# Down-sampling & ConvBlock (using PLIF + AnisotropicConv)
# ============================================================================

class DownSampling(BaseModule):
    """Strided Conv3d down-sampling with optional PLIF pre-activation."""

    def __init__(self, step: int = 10, encode_type: str = 'direct',
                 in_channels: int = 2, embed_dims: int = 256,
                 kernel_size: int = 3, stride: int = 2, padding: int = 1,
                 first_layer: bool = True):
        super().__init__(step=step, encode_type=encode_type)
        self.encode_conv = nn.Conv3d(in_channels, embed_dims,
                                     kernel_size=kernel_size, stride=stride, padding=padding)
        self.encode_bn = nn.BatchNorm3d(embed_dims)
        if not first_layer:
            self.encode_lif = PLIFNode(init_tau=2.0, step=step)

    def forward(self, x):
        self.reset()
        T, B, C, H, W, D = x.shape
        if hasattr(self, 'encode_lif'):
            x = self.encode_lif(x.flatten(0, 1)).reshape(T, B, C, H, W, D).contiguous()
        x = self.encode_conv(x.flatten(0, 1))
        _, C_out, H_out, W_out, D_out = x.shape
        x = self.encode_bn(x).reshape(T, B, C_out, H_out, W_out, D_out).contiguous()
        return x


class ConvBlock(BaseModule):
    """3-D conv block using PhysicsAwareSepConv + PLIF residual."""

    def __init__(self, dim: int, step: int = 10, encode_type: str = 'direct',
                 mlp_ratio: float = 4.0, kernel_xy: int = 7, kernel_z: int = 7):
        super().__init__(step=step, encode_type=encode_type)
        self.mlp_ratio = mlp_ratio
        exp = int(dim * mlp_ratio)

        # Innovation 2: Use physics-aware anisotropic conv
        self.Conv = PhysicsAwareSepConv(step=step, dim=dim, kernel_xy=kernel_xy, kernel_z=kernel_z)
        self.lif1 = PLIFNode(step=step, init_tau=2.0)
        self.conv1 = nn.Conv3d(dim, exp, 3, padding=1, bias=False)
        self.bn1 = nn.BatchNorm3d(exp)
        self.lif2 = PLIFNode(step=step, init_tau=2.0)
        self.conv2 = nn.Conv3d(exp, dim, 3, padding=1, bias=False)
        self.bn2 = nn.BatchNorm3d(dim)

    def forward(self, x):
        self.reset()
        T, B, C, H, W, D = x.shape
        exp = int(C * self.mlp_ratio)

        x = self.Conv(x) + x
        residual = x

        x = self.bn1(self.conv1(self.lif1(x.flatten(0, 1)))).reshape(T, B, exp, H, W, D).contiguous()
        x = self.bn2(self.conv2(self.lif2(x.flatten(0, 1)))).reshape(T, B, C, H, W, D).contiguous()
        return residual + x


# ============================================================================
# Main Model: HouyiB 4D
# ============================================================================

class HouyiB4D(BaseModule):
    """
    HouyiB 4D — Physics-Aware SNN for Solar 3D Magnetic Field Analysis.

    Three key innovations over standard Spikformer3D:
      1. PLIFNode: Parametric LIF with learnable τ for multi-scale temporal adaptation
      2. PhysicsAwareSepConv: Anisotropic convolution decomposed into XY + Z
      3. Z-Positional Encoding: Height-aware encoding for solar atmosphere stratification

    Input  (standard): (B, T, C, H, W, D)
    Output:            (B, num_classes)

    Architecture (4-stage encoder):
      Stage 1 – DownSampling×2  + ConvBlock×2    (stride 2 each)
      Stage 2 – DownSampling    + ConvBlock×2     (stride 2)
      Stage 3 – DownSampling    + Z-PosEnc + Block×(block3_depths) (stride 2)
      Stage 4 – DownSampling    + Block×(depths-1)                 (stride 1)
      Head    – global avg-pool → PLIF → Linear → mean(T)
    """

    def __init__(self,
                 step: int = 10,
                 encode_type: str = 'direct',
                 patch_size: int = 4,
                 in_channels: int = 2,
                 num_classes: int = 10,
                 embed_dims: int = 256,
                 num_heads: int = 16,
                 mlp_ratios: float = 4.,
                 qkv_bias: bool = False,
                 qk_scale=None,
                 drop_rate: float = 0.,
                 attn_drop_rate: float = 0.,
                 drop_path_rate: float = 0.,
                 norm_layer=nn.LayerNorm,
                 depths: int = 2,
                 sr_ratios: int = 4,
                 kd: bool = False,
                 attn_type: str = 'sdsa2',
                 z_pos_depth: int = 8,
                 kernel_xy: int = 7,
                 kernel_z: int = 7,
                 **kwargs):
        super().__init__(step=step, encode_type=encode_type)

        self.step = step
        self.num_classes = num_classes
        self.depths = depths
        self.attn_type = attn_type
        self.block3_depths = 1

        dpr = [x.item() for x in torch.linspace(0, drop_path_rate, depths)]

        # ---- Stage 1 --------------------------------------------------------
        self.downsample1_1 = DownSampling(
            step=step, in_channels=in_channels, embed_dims=embed_dims // 16,
            kernel_size=7, stride=2, padding=3, first_layer=True)
        self.ConvBlock1_1 = nn.ModuleList([
            ConvBlock(step=step, dim=embed_dims // 16, mlp_ratio=mlp_ratios,
                      kernel_xy=kernel_xy, kernel_z=kernel_z)])

        self.downsample1_2 = DownSampling(
            step=step, in_channels=embed_dims // 16, embed_dims=embed_dims // 8,
            kernel_size=3, stride=2, padding=1, first_layer=False)
        self.ConvBlock1_2 = nn.ModuleList([
            ConvBlock(step=step, dim=embed_dims // 8, mlp_ratio=mlp_ratios,
                      kernel_xy=kernel_xy, kernel_z=kernel_z)])

        # ---- Stage 2 --------------------------------------------------------
        self.downsample2 = DownSampling(
            step=step, in_channels=embed_dims // 8, embed_dims=embed_dims // 4,
            kernel_size=3, stride=2, padding=1, first_layer=False)
        self.ConvBlock2_1 = nn.ModuleList([
            ConvBlock(step=step, dim=embed_dims // 4, mlp_ratio=mlp_ratios,
                      kernel_xy=kernel_xy, kernel_z=kernel_z)])
        self.ConvBlock2_2 = nn.ModuleList([
            ConvBlock(step=step, dim=embed_dims // 4, mlp_ratio=mlp_ratios,
                      kernel_xy=kernel_xy, kernel_z=kernel_z)])

        # ---- Stage 3 (attention + Z-PosEnc) ---------------------------------
        self.downsample3 = DownSampling(
            step=step, in_channels=embed_dims // 4, embed_dims=embed_dims // 2,
            kernel_size=3, stride=2, padding=1, first_layer=False)

        # Innovation 3: Z-axis positional encoding for solar atmosphere height
        self.z_pos_embed = nn.Parameter(torch.zeros(1, embed_dims // 2, 1, 1, z_pos_depth))
        trunc_normal_(self.z_pos_embed, std=.02)

        self.block3 = nn.ModuleList([
            Block(step=step, dim=embed_dims // 2, num_heads=num_heads,
                  mlp_ratio=mlp_ratios, qkv_bias=qkv_bias, qk_scale=qk_scale,
                  drop=drop_rate, attn_drop=attn_drop_rate,
                  norm_layer=norm_layer, sr_ratio=sr_ratios, attn_type=attn_type)
            for _ in range(self.block3_depths)
        ])

        # ---- Stage 4 (attention) --------------------------------------------
        self.downsample4 = DownSampling(
            step=step, in_channels=embed_dims // 2, embed_dims=embed_dims,
            kernel_size=3, stride=1, padding=1, first_layer=False)

        # Z-pos encoding for stage 4 (embed_dims channels)
        self.z_pos_embed_4 = nn.Parameter(torch.zeros(1, embed_dims, 1, 1, z_pos_depth))
        trunc_normal_(self.z_pos_embed_4, std=.02)

        self.block4 = nn.ModuleList([
            Block(step=step, dim=embed_dims, num_heads=num_heads,
                  mlp_ratio=mlp_ratios, qkv_bias=qkv_bias, qk_scale=qk_scale,
                  drop=drop_rate, attn_drop=attn_drop_rate, drop_path=dpr[j],
                  norm_layer=norm_layer, sr_ratio=sr_ratios, attn_type=attn_type)
            for j in range(self.depths - self.block3_depths)
        ])

        # ---- Classification head -------------------------------------------
        self.final_lif = PLIFNode(step=step, init_tau=2.0, mem_detach=True)
        self.head = nn.Linear(embed_dims, num_classes) if num_classes > 0 else nn.Identity()

        self.kd = kd
        if self.kd:
            self.head_kd = nn.Linear(embed_dims, num_classes) if num_classes > 0 else nn.Identity()

        self.apply(self._init_weights)

    # ------------------------------------------------------------------
    @staticmethod
    def _init_weights(m):
        if isinstance(m, nn.Linear):
            trunc_normal_(m.weight, std=.02)
            if m.bias is not None:
                nn.init.constant_(m.bias, 0)
        elif isinstance(m, nn.LayerNorm):
            nn.init.constant_(m.bias, 0)
            nn.init.constant_(m.weight, 1.0)

    def _interpolate_z_pos(self, z_embed: torch.Tensor, D_target: int) -> torch.Tensor:
        """Interpolate Z positional encoding to match actual depth dimension."""
        D_src = z_embed.size(-1)
        if D_src == D_target:
            return z_embed
        # (1, C, 1, 1, D_src) → (1, C, D_src) → interpolate → (1, C, 1, 1, D_target)
        z_flat = z_embed.squeeze(2).squeeze(2)  # (1, C, D_src)
        z_interp = F.interpolate(z_flat, size=D_target, mode='linear', align_corners=True)
        return z_interp.unsqueeze(2).unsqueeze(3)  # (1, C, 1, 1, D_target)

    # ------------------------------------------------------------------
    def forward_features(self, x: torch.Tensor) -> torch.Tensor:
        """x: (T, B, C, H, W, D) → (T, B, embed_dims, H', W', D')"""
        x = self.downsample1_1(x)
        for blk in self.ConvBlock1_1:
            x = blk(x)
        x = self.downsample1_2(x)
        for blk in self.ConvBlock1_2:
            x = blk(x)

        x = self.downsample2(x)
        for blk in self.ConvBlock2_1:
            x = blk(x)
        for blk in self.ConvBlock2_2:
            x = blk(x)

        x = self.downsample3(x)

        # Innovation 3: Add Z-positional encoding before attention
        D_actual = x.size(5)
        z_pos = self._interpolate_z_pos(self.z_pos_embed, D_actual)
        x = x + z_pos.unsqueeze(0)  # broadcast over T, B, H, W

        for blk in self.block3:
            x = blk(x)

        x = self.downsample4(x)

        # Z-pos encoding for stage 4
        D_actual_4 = x.size(5)
        z_pos_4 = self._interpolate_z_pos(self.z_pos_embed_4, D_actual_4)
        x = x + z_pos_4.unsqueeze(0)

        for blk in self.block4:
            x = blk(x)

        return x

    # ------------------------------------------------------------------
    def forward(self, x: torch.Tensor) -> torch.Tensor:
        """
        Args:
            x: (B, T, C, H, W, D) – standard DataLoader output
        Returns:
            (B, num_classes)
        """
        x = x.float()
        self.reset()

        # (B, T, C, H, W, D) → (T, B, C, H, W, D)
        x = x.permute(1, 0, 2, 3, 4, 5).contiguous()

        x = self.forward_features(x)       # T B C H' W' D'
        x = x.flatten(3).mean(3)           # T B C (global avg over H'W'D')

        T, B, _ = x.shape
        x_lif = self.final_lif(x.flatten(0, 1)).reshape(T, B, -1)
        out = self.head(x_lif).mean(0)     # (B, num_classes)

        if self.kd:
            out_kd = self.head_kd(x_lif).mean(0)
            if self.training:
                return out, out_kd
            return (out + out_kd) / 2

        return out


# ============================================================================
# Pre-defined size configurations & factory
# ============================================================================

MODEL_SIZES = {
    'small': dict(
        step=8, patch_size=4, embed_dims=128, num_heads=8,
        mlp_ratios=4, in_channels=6, num_classes=4,
        qkv_bias=False, depths=2, sr_ratios=4,
        attn_type='sdsa2', z_pos_depth=8,
        kernel_xy=7, kernel_z=5,
    ),
    'medium': dict(
        step=8, patch_size=4, embed_dims=256, num_heads=16,
        mlp_ratios=4, in_channels=6, num_classes=4,
        qkv_bias=False, depths=2, sr_ratios=4,
        attn_type='sdsa2', z_pos_depth=8,
        kernel_xy=7, kernel_z=5,
    ),
    'large': dict(
        step=8, patch_size=4, embed_dims=512, num_heads=16,
        mlp_ratios=4, in_channels=6, num_classes=4,
        qkv_bias=False, depths=4, sr_ratios=4,
        attn_type='sdsa2', z_pos_depth=8,
        kernel_xy=7, kernel_z=7,
    ),
}


def build_model(size: str = 'medium', **kwargs) -> HouyiB4D:
    """
    Build a pre-configured HouyiB4D.

    Args:
        size:     'small' | 'medium' | 'large'
        **kwargs: Override any configuration key.

    Examples::

        # Default temporal-diff (6ch)
        model = build_model('medium', in_channels=6, num_classes=4)

        # PIEE (12ch)
        model = build_model('medium', in_channels=12, num_classes=4)
    """
    if size not in MODEL_SIZES:
        raise ValueError(f"size must be one of {list(MODEL_SIZES)}, got '{size}'")
    cfg = {**MODEL_SIZES[size], **kwargs}
    return HouyiB4D(**cfg)
