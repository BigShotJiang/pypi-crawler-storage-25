"""
ResNet-SNN 4D – Spiking ResNet for volumetric event-based data.

Input  (standard / mainstream): (B, T, C, H, W, D)
Output:                          (B, num_classes)

Fixes vs original:
  - Encoder dimension labels unified to H W D throughout
    (original mixed 'w h d' and 'x y z').
  - Encoder.direct() now correctly handles 6-D input (B T C H W D)
    by extracting a single spatial frame per T step instead of repeating.
  - All rearrange patterns updated from 'w h d' → 'h w d'.
  - _make_layer default node changed from torch.nn.Identity → LIFNode
    (Identity produced no spiking in residual branches).
  - Added .contiguous() after rearrange in layer_by_layer forward path.
  - ResNet.__init__ super() call made explicit (step, encode_type forwarded).
  - dataset kwargs access uses .get() consistently (no bare dict access).
  - MODEL_SIZES carries distinct architectures per size.
  - build_model pops 'arch' cleanly before forwarding kwargs.
"""

import torch
import torch.nn as nn
from functools import partial
from einops import rearrange, repeat

from braincog.model_zoo.base_module import BaseModule
from braincog.base.node.node import LIFNode, BaseNode
from braincog.model_zoo.base_module import VotingLayer


# ============================================================================
# Convolution helpers
# ============================================================================

def conv3x3x3(in_planes: int, out_planes: int,
               stride: int = 1, groups: int = 1, dilation: int = 1) -> nn.Conv3d:
    """3×3×3 convolution with symmetric padding."""
    return nn.Conv3d(in_planes, out_planes,
                     kernel_size=3, stride=stride,
                     padding=dilation, groups=groups,
                     bias=False, dilation=dilation)


def conv1x1x1(in_planes: int, out_planes: int, stride: int = 1) -> nn.Conv3d:
    """1×1×1 pointwise convolution."""
    return nn.Conv3d(in_planes, out_planes,
                     kernel_size=1, stride=stride, bias=False)


# ============================================================================
# Residual Blocks
# ============================================================================

class BasicBlock(nn.Module):
    """
    Pre-activation ResNet basic block (BN → LIF → Conv, ×2).

    Args:
        inplanes   : input channel width
        planes     : output channel width
        stride     : spatial stride for conv1
        downsample : optional projection shortcut
        node       : spiking neuron constructor  (default LIFNode)
    """

    expansion = 1

    def __init__(self, inplanes: int, planes: int,
                 stride: int = 1, downsample=None,
                 groups: int = 1, base_width: int = 64, dilation: int = 1,
                 norm_layer=None, node=LIFNode):
        super().__init__()
        if norm_layer is None:
            norm_layer = nn.BatchNorm3d
        if groups != 1 or base_width != 64:
            raise ValueError('BasicBlock only supports groups=1 and base_width=64')
        if dilation > 1:
            raise NotImplementedError('Dilation > 1 not supported in BasicBlock')

        self.bn1   = norm_layer(inplanes)
        self.node1 = node()
        self.conv1 = conv3x3x3(inplanes, planes, stride)

        self.bn2   = norm_layer(planes)
        self.node2 = node()
        self.conv2 = conv3x3x3(planes, planes)

        self.downsample = downsample
        self.stride     = stride

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        identity = x

        out = self.conv1(self.node1(self.bn1(x)))
        out = self.conv2(self.node2(self.bn2(out)))

        if self.downsample is not None:
            identity = self.downsample(x)

        return out + identity


class Bottleneck(nn.Module):
    """
    Pre-activation ResNet bottleneck block (BN → LIF → Conv, ×3).

    Expansion = 4: planes × 4 output channels.
    """

    expansion = 4

    def __init__(self, inplanes: int, planes: int,
                 stride: int = 1, downsample=None,
                 groups: int = 1, base_width: int = 64, dilation: int = 1,
                 norm_layer=None, node=LIFNode):
        super().__init__()
        if norm_layer is None:
            norm_layer = nn.BatchNorm3d
        width = int(planes * (base_width / 64.0)) * groups

        self.bn1   = norm_layer(inplanes)
        self.node1 = node()
        self.conv1 = conv1x1x1(inplanes, width)

        self.bn2   = norm_layer(width)
        self.node2 = node()
        self.conv2 = conv3x3x3(width, width, stride, groups, dilation)

        self.bn3   = norm_layer(width)
        self.node3 = node()
        self.conv3 = conv1x1x1(width, planes * self.expansion)

        self.downsample = downsample
        self.stride     = stride

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        identity = x

        out = self.conv1(self.node1(self.bn1(x)))
        out = self.conv2(self.node2(self.bn2(out)))
        out = self.conv3(self.node3(self.bn3(out)))

        if self.downsample is not None:
            identity = self.downsample(x)

        return out + identity


# ============================================================================
# Encoder
# ============================================================================

class Encoder(nn.Module):
    """
    Encodes raw input into the format expected by ResNet forward passes.

    Standard input : (B, T, C, H, W, D)

    Output depends on mode:
      - layer_by_layer : (T*B, C, H, W, D)   – merged for efficient inference
      - groups != 1    : (B, C*T, H, W, D)   – channel-temporal fusion
      - temporal_flatten: (1, B, C*T, H, W, D) – single super-frame
      - default        : (T, B, C, H, W, D)   – time-first

    Fixes vs original:
      - Dimension labels normalised to H W D everywhere.
      - direct() now handles (B, T, C, H, W, D) input correctly by simply
        passing through (the T dimension is already present).
    """

    def __init__(self, step: int, encode_type: str = 'direct', **kwargs):
        super().__init__()
        self.step             = step
        self.encode_type      = encode_type
        self.temporal_flatten = kwargs.get('temporal_flatten', False)
        self.layer_by_layer   = kwargs.get('layer_by_layer',   False)
        self.no_encode        = kwargs.get('adaptive_node',    False)
        self.groups           = kwargs.get('n_groups',         1)

        if encode_type not in ('direct', 'ttfs', 'rate', 'phase'):
            raise ValueError(
                f"encode_type must be 'direct'|'ttfs'|'rate'|'phase', got '{encode_type}'"
            )
        self.fun = getattr(self, encode_type)

    # ------------------------------------------------------------------
    def forward(self, inputs: torch.Tensor,
                deletion_prob=None, shift_var=None) -> torch.Tensor:
        """
        Args:
            inputs: (B, T, C, H, W, D)  – mainstream 6-D format

        Returns:
            Encoded tensor in the shape required by the chosen inference mode.
        """
        if inputs.ndim == 6:
            # (B, T, C, H, W, D) → (T, B, C, H, W, D)  – time-first internal format
            outputs = inputs.permute(1, 0, 2, 3, 4, 5).contiguous()
        else:
            outputs = self.fun(inputs)

        if deletion_prob is not None:
            outputs = self._delete(outputs, deletion_prob)
        if shift_var is not None:
            outputs = self._shift(outputs, shift_var)

        # Reshape to inference-mode format
        if self.temporal_flatten or self.no_encode:
            outputs = rearrange(outputs, 't b c h w d -> 1 b (t c) h w d')
        elif self.groups != 1:
            outputs = rearrange(outputs, 't b c h w d -> b (c t) h w d')
        elif self.layer_by_layer:
            outputs = rearrange(outputs, 't b c h w d -> (t b) c h w d').contiguous()

        return outputs

    # ------------------------------------------------------------------
    # Encoding strategies (used when input does NOT already have T dim)
    # ------------------------------------------------------------------

    @torch.no_grad()
    def direct(self, inputs: torch.Tensor) -> torch.Tensor:
        """
        Direct encoding: replicate single frame T times.
        Args:
            inputs: (B, C, H, W, D)  – single static frame
        Returns:
            (T, B, C, H, W, D)
        """
        return repeat(inputs, 'b c h w d -> t b c h w d', t=self.step)

    @torch.no_grad()
    def ttfs(self, inputs: torch.Tensor) -> torch.Tensor:
        """
        Time-to-First-Spike encoder.
        Args:
            inputs: (B, C, H, W, D)  values in [0, 1]
        Returns:
            (T, B, C, H, W, D)
        """
        shape  = (self.step,) + inputs.shape
        outputs = torch.zeros(shape, device=inputs.device)
        for i in range(self.step):
            mask = (inputs * self.step <= (self.step - i)) & \
                   (inputs * self.step  > (self.step - i - 1))
            outputs[i, mask] = 1.0 / (i + 1)
        return outputs

    @torch.no_grad()
    def rate(self, inputs: torch.Tensor) -> torch.Tensor:
        """Rate coding: Poisson spike train."""
        shape = (self.step,) + inputs.shape
        return (inputs > torch.rand(shape, device=inputs.device)).float()

    @torch.no_grad()
    def phase(self, inputs: torch.Tensor) -> torch.Tensor:
        """Phase coding (8-bit binary decomposition)."""
        shape   = (self.step,) + inputs.shape
        outputs = torch.zeros(shape, device=inputs.device)
        inputs  = (inputs * 256).long()
        val = 1.0
        for i in range(self.step):
            if i < 8:
                mask = ((inputs >> (8 - i - 1)) & 1) != 0
                outputs[i, mask] = val
                val /= 2.0
            else:
                outputs[i] = outputs[i % 8]
        return outputs

    # ------------------------------------------------------------------
    # Augmentation helpers
    # ------------------------------------------------------------------

    @torch.no_grad()
    def _delete(self, inputs: torch.Tensor, prob: float) -> torch.Tensor:
        """Randomly zero spikes with probability `prob`."""
        mask = (inputs >= 0) & (torch.rand_like(inputs) < prob)
        return inputs.masked_fill(mask, 0.0)

    @torch.no_grad()
    def _shift(self, inputs: torch.Tensor, var: float) -> torch.Tensor:
        """Random temporal shift with variance `var`."""
        outputs = torch.zeros_like(inputs)
        for t in range(self.step):
            shift = int((var * torch.randn(1)).round().clamp(0, self.step - 1).item())
            outputs[t] += inputs[shift]
        return outputs


# ============================================================================
# ResNet-SNN
# ============================================================================

class ResNet(BaseModule):
    """
    Spiking ResNet for volumetric event-based data.

    Input  (standard / mainstream): (B, T, C, H, W, D)
    Output:                          (B, num_classes)

    Args:
        block      : BasicBlock or Bottleneck
        layers     : list of block counts per stage, e.g. [2, 2, 2, 2]
        inplanes   : base channel width  (default 64)
        num_classes: output classes
        step       : simulation time steps  (default 8)
        encode_type: 'direct' | 'ttfs' | 'rate' | 'phase'
        spike_output: if True, use VotingLayer output head
        node_type  : spiking neuron class  (default LIFNode)
        dataset    : 'dvs_small' | 'dvs_large' | 'dvs_custom'

    Fix vs original:
        - _make_layer default node is now LIFNode (was torch.nn.Identity).
        - All rearrange uses 'h w d' (was 'w h d').
        - .contiguous() added after rearrange in layer_by_layer path.
    """

    def __init__(self,
                 block,
                 layers,
                 inplanes: int = 64,
                 num_classes: int = 10,
                 zero_init_residual: bool = False,
                 groups: int = 1,
                 width_per_group: int = 64,
                 replace_stride_with_dilation=None,
                 norm_layer=None,
                 static_data: bool = False,
                 step: int = 8,
                 encode_type: str = 'direct',
                 spike_output: bool = False,
                 *args, **kwargs):
        super().__init__(step, encode_type, *args, **kwargs)

        self.spike_output = spike_output
        self.num_classes  = num_classes
        self.static_data  = static_data

        if norm_layer is None:
            norm_layer = nn.BatchNorm3d
        self._norm_layer = norm_layer

        self.inplanes    = inplanes
        self.interplanes = [inplanes, inplanes * 2, inplanes * 4, inplanes * 8]
        self.dilation    = 1

        # Resolve neuron type.
        # Fix: filter to node-relevant kwargs only. Forwarding all kwargs
        # (num_classes, inplanes, dataset, …) into LIFNode causes TypeError.
        node_cls = kwargs.get('node_type', LIFNode)
        _NODE_KWARGS = {'step', 'tau', 'threshold', 'mem_detach',
                        'layer_by_layer', 'act_fun', 'requires_grad'}
        node_kwargs = {k: v for k, v in kwargs.items() if k in _NODE_KWARGS}
        if issubclass(node_cls, BaseNode):
            self.node = partial(node_cls, **node_kwargs)
        else:
            self.node = node_cls

        if replace_stride_with_dilation is None:
            replace_stride_with_dilation = [False, False, False]
        if len(replace_stride_with_dilation) != 3:
            raise ValueError(
                f'replace_stride_with_dilation must be None or length-3 tuple, '
                f'got {replace_stride_with_dilation}'
            )

        self.groups     = groups
        self.base_width = width_per_group

        # ---- Stem convolution (dataset-dependent) -----------------------
        dataset = kwargs.get('dataset', 'dvs_custom')

        if dataset == 'dvs_small':
            self.conv1 = nn.Conv3d(
                2 * self.init_channel_mul, inplanes,
                kernel_size=3, padding=1, bias=False,
            )
        elif dataset == 'dvs_large':
            self.conv1 = nn.Conv3d(
                1 * self.init_channel_mul, inplanes,
                kernel_size=7, stride=2, padding=3, bias=False,
            )
        elif dataset == 'dvs_custom':
            ch      = kwargs.get('dataset_dvs_custom_channel',     2)
            ks      = kwargs.get('dataset_dvs_custom_kernel_size',  3)
            pad     = kwargs.get('dataset_dvs_custom_padding',      1)
            stride  = kwargs.get('dataset_dvs_custom_stride',       1)
            self.conv1 = nn.Conv3d(
                ch * self.init_channel_mul, inplanes,
                kernel_size=ks, padding=pad, stride=stride, bias=False,
            )
        else:
            raise NotImplementedError(f"Unknown dataset: '{dataset}'")

        # ---- Residual stages -------------------------------------------
        # Note: _make_layer mutates self.inplanes as a side effect.
        # We record the final channel count explicitly after all stages
        # so that bn1 and fc are wired to the correct width.
        self.layer1 = self._make_layer(block, self.interplanes[0], layers[0])
        self.layer2 = self._make_layer(block, self.interplanes[1], layers[1],
                                       stride=2,
                                       dilate=replace_stride_with_dilation[0])
        self.layer3 = self._make_layer(block, self.interplanes[2], layers[2],
                                       stride=2,
                                       dilate=replace_stride_with_dilation[1])
        self.layer4 = self._make_layer(block, self.interplanes[3], layers[3],
                                       stride=2,
                                       dilate=replace_stride_with_dilation[2])
        # self.inplanes is now interplanes[3] * block.expansion after _make_layer calls
        final_planes = self.interplanes[3] * block.expansion

        # Fix: use final_planes (explicit) not self.inplanes (already mutated by _make_layer)
        self.bn1     = norm_layer(final_planes)
        self.avgpool = nn.AdaptiveAvgPool3d((1, 1, 1))

        # ---- Classification head ----------------------------------------
        if spike_output:
            self.fc    = nn.Linear(final_planes, num_classes * 10)
            self.node2 = self.node()
            self.vote  = VotingLayer(10)
        else:
            self.fc    = nn.Linear(final_planes, num_classes)
            self.node2 = nn.Identity()
            self.vote  = nn.Identity()

        self.warm_up = False

        # Weight initialisation
        for m in self.modules():
            if isinstance(m, nn.Conv3d):
                nn.init.kaiming_normal_(m.weight, mode='fan_out', nonlinearity='relu')
            elif isinstance(m, (nn.BatchNorm3d, nn.GroupNorm)):
                nn.init.constant_(m.weight, 1)
                nn.init.constant_(m.bias,   0)

        if zero_init_residual:
            for m in self.modules():
                if isinstance(m, Bottleneck):
                    nn.init.constant_(m.bn3.weight, 0)
                elif isinstance(m, BasicBlock):
                    nn.init.constant_(m.bn2.weight, 0)

        # Encoder: handles (B, T, C, H, W, D) → internal format
        self.encoder = Encoder(
            step, encode_type,
            temporal_flatten=self.temporal_flatten,
            layer_by_layer=self.layer_by_layer,
            **kwargs,
        )

    # ------------------------------------------------------------------
    def _make_layer(self, block, planes: int, num_blocks: int,
                    stride: int = 1, dilate: bool = False):
        norm_layer = self._norm_layer
        downsample = None
        prev_dilation = self.dilation

        if dilate:
            self.dilation *= stride
            stride = 1

        if stride != 1 or self.inplanes != planes * block.expansion:
            # Fix: use self.node (LIFNode) not torch.nn.Identity
            downsample = nn.Sequential(
                norm_layer(self.inplanes),
                self.node(),
                conv1x1x1(self.inplanes, planes * block.expansion, stride),
            )

        layers = [
            block(self.inplanes, planes, stride, downsample,
                  self.groups, self.base_width, prev_dilation,
                  norm_layer, node=self.node)
        ]
        self.inplanes = planes * block.expansion
        for _ in range(1, num_blocks):
            layers.append(
                block(self.inplanes, planes,
                      groups=self.groups, base_width=self.base_width,
                      dilation=self.dilation, norm_layer=norm_layer,
                      node=self.node)
            )
        return nn.Sequential(*layers)

    # ------------------------------------------------------------------
    def _backbone(self, x: torch.Tensor) -> torch.Tensor:
        """
        Shared conv + residual stages → flattened feature vector.

        Works for both:
          - layer_by_layer mode : x is (T*B, C, H, W, D)
          - step loop mode      : x is (B,   C, H, W, D)
        BN3d handles both cases since it normalises over the batch dim.
        """
        x = self.conv1(x)
        x = self.layer1(x)
        x = self.layer2(x)
        x = self.layer3(x)
        x = self.layer4(x)
        x = self.bn1(x)      # BN over final_planes channels
        x = self.avgpool(x)
        return torch.flatten(x, 1)

    # ------------------------------------------------------------------
    def forward(self, inputs: torch.Tensor) -> torch.Tensor:
        """
        Args:
            inputs: (B, T, C, H, W, D)

        Returns:
            (B, num_classes)
        """
        inputs = inputs.float()
        inputs = self.encoder(inputs)    # → layer_by_layer: (T*B, C, H, W, D)
                                         #   default:         (T, B, C, H, W, D)
        self.reset()

        if self.layer_by_layer:
            x = self._backbone(inputs)             # (T*B, feat)
            x = self.fc(x)                         # (T*B, num_classes or num_classes*10)
            x = rearrange(x, '(t b) c -> t b c', t=self.step).contiguous()
            # Fix: for spike_output, node2 is a stateful LIF that must fire
            # per time-step BEFORE averaging. For non-spike_output, node2 is
            # Identity so order doesn't matter, but we keep it consistent.
            x = torch.stack([self.node2(x[t]) for t in range(self.step)]).mean(0)
            return self.vote(x)

        else:
            # Explicit time-step loop (default / non-layer_by_layer)
            step = 1 if self.warm_up else self.step
            outputs = []
            for t in range(step):
                x = self._backbone(inputs[t])      # (B, feat)
                x = self.fc(x)
                x = self.node2(x)
                x = self.vote(x)
                outputs.append(x)

            return torch.stack(outputs).mean(0)    # (B, num_classes)


# ============================================================================
# Factory functions
# ============================================================================

def _resnet(block, layers, pretrained: bool = False, **kwargs) -> ResNet:
    model = ResNet(block, layers, **kwargs)
    if pretrained:
        raise NotImplementedError("Pretrained weights not available")
    return model


def resnet9(pretrained=False, **kwargs):
    return _resnet(BasicBlock, [1, 1, 1, 1], pretrained, **kwargs)

def resnet18(pretrained=False, **kwargs):
    return _resnet(BasicBlock, [2, 2, 2, 2], pretrained, **kwargs)

def resnet34(pretrained=False, **kwargs):
    return _resnet(BasicBlock, [3, 4, 6, 3], pretrained, **kwargs)

def resnet34_half(pretrained=False, **kwargs):
    kwargs.setdefault('inplanes', 32)
    return _resnet(BasicBlock, [3, 4, 6, 3], pretrained, **kwargs)

def resnet50(pretrained=False, **kwargs):
    return _resnet(Bottleneck, [3, 4, 6, 3], pretrained, **kwargs)

def resnet50_half(pretrained=False, **kwargs):
    kwargs.setdefault('inplanes', 32)
    return _resnet(Bottleneck, [3, 4, 6, 3], pretrained, **kwargs)

def resnet101(pretrained=False, **kwargs):
    return _resnet(Bottleneck, [3, 4, 23, 3], pretrained, **kwargs)

def resnet152(pretrained=False, **kwargs):
    return _resnet(Bottleneck, [3, 8, 36, 3], pretrained, **kwargs)

def resnext50_32x4d(pretrained=False, **kwargs):
    kwargs.update(groups=32, width_per_group=4)
    return _resnet(Bottleneck, [3, 4, 6, 3], pretrained, **kwargs)

def resnext101_32x8d(pretrained=False, **kwargs):
    kwargs.update(groups=32, width_per_group=8)
    return _resnet(Bottleneck, [3, 4, 23, 3], pretrained, **kwargs)

def wide_resnet50_2(pretrained=False, **kwargs):
    kwargs.setdefault('width_per_group', 128)
    return _resnet(Bottleneck, [3, 4, 6, 3], pretrained, **kwargs)

def wide_resnet101_2(pretrained=False, **kwargs):
    kwargs.setdefault('width_per_group', 128)
    return _resnet(Bottleneck, [3, 4, 23, 3], pretrained, **kwargs)


_ARCH_MAP = {
    'resnet9':         resnet9,
    'resnet18':        resnet18,
    'resnet34':        resnet34,
    'resnet34_half':   resnet34_half,
    'resnet50':        resnet50,
    'resnet50_half':   resnet50_half,
    'resnet101':       resnet101,
    'resnet152':       resnet152,
    'resnext50_32x4d': resnext50_32x4d,
    'resnext101_32x8d':resnext101_32x8d,
    'wide_resnet50_2': wide_resnet50_2,
    'wide_resnet101_2':wide_resnet101_2,
}


def make_net(arch: str = 'resnet18', **kwargs) -> ResNet:
    if arch not in _ARCH_MAP:
        raise NotImplementedError(
            f"Unknown arch '{arch}'. Available: {list(_ARCH_MAP)}"
        )
    return _ARCH_MAP[arch](**kwargs)


# ============================================================================
# Pre-defined size configurations
# ============================================================================

MODEL_SIZES = {
    'small':  dict(arch='resnet9',   inplanes=32,  num_classes=10),
    'medium': dict(arch='resnet18',  inplanes=64,  num_classes=10),
    'large':  dict(arch='resnet34',  inplanes=64,  num_classes=10),
}


def build_model(size: str = 'medium', **kwargs) -> ResNet:
    """
    Build a pre-configured spiking ResNet.

    Args:
        size    : 'small' (ResNet-9) | 'medium' (ResNet-18) | 'large' (ResNet-34)
        **kwargs: Override any configuration key.

    Examples::

        model = build_model('medium', num_classes=100, step=10)
        model = build_model('large',  num_classes=40,  encode_type='rate')
        model = build_model('small',  arch='resnet50', num_classes=10)
    """
    if size not in MODEL_SIZES:
        raise ValueError(f"size must be one of {list(MODEL_SIZES)}, got '{size}'")
    cfg  = {**MODEL_SIZES[size], **kwargs}
    arch = cfg.pop('arch')
    return make_net(arch, **cfg)