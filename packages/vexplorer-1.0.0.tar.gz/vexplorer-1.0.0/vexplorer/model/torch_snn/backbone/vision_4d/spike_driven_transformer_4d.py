# https://github.com/BrainCog-X/Brain-Cog/blob/main/examples/Spiking-Transformers/models/spike_driven_transformer_v2_dvs.py
# Extended to 4D (3D spatial + temporal) for volumetric event data
# Optimized: standard input B T C H W D, fixed SimpleLIF state leak, vectorized MLP,
#            removed unused res_lif, fixed Block norm, fixed hardcoded mlp_ratio

import torch
import torch.nn as nn
from timm.models.layers import to_2tuple, trunc_normal_, DropPath
from timm.models.registry import register_model
from timm.models.vision_transformer import _cfg
import torch.nn.functional as F
from braincog.model_zoo.base_module import BaseModule
from braincog.base.node.node import *
from braincog.base.connection.layer import *
from braincog.base.strategy.surrogate import *
from functools import partial
from einops import rearrange

__all__ = ['SDTransformer4D']

'''
4D Spike-Driven Transformer for volumetric event data

Input Format (Standard / Mainstream):
    - Shape: (B, T, C, H, W, D)
    - B: Batch size
    - T: Time steps
    - C: Input channels (e.g., 2 for DVS polarity)
    - H: Height (spatial dimension)
    - W: Width  (spatial dimension)
    - D: Depth  (spatial dimension)

Internal Format (Time-First for efficient temporal processing):
    - Shape: (T, B, C, H, W, D)

Output:
    - Shape: (B, num_classes)
'''


# ============================================================================
# Neuron Nodes
# ============================================================================

class MyBaseNode(BaseNode):
    """Base neuron node with rearrangement support for 6-D spatial-temporal data."""

    def __init__(self, threshold=0.5, step=4, layer_by_layer=False, mem_detach=False):
        super().__init__(
            threshold=threshold, step=step,
            layer_by_layer=layer_by_layer, mem_detach=mem_detach,
        )

    def rearrange2node(self, inputs):
        if self.groups != 1:
            if len(inputs.shape) == 6:      # B (C T) H W D
                outputs = rearrange(inputs, 'b (c t) h w d -> t b c h w d', t=self.step)
            elif len(inputs.shape) == 4:    # B (C T) H W  (2-D fallback)
                outputs = rearrange(inputs, 'b (c t) h w -> t b c h w', t=self.step)
            elif len(inputs.shape) == 2:
                outputs = rearrange(inputs, 'b (c t) -> t b c', t=self.step)
            else:
                raise NotImplementedError(f"Unsupported shape: {inputs.shape}")

        elif self.layer_by_layer:
            if len(inputs.shape) == 6:      # (T B) C H W D
                outputs = rearrange(inputs, '(t b) c h w d -> t b c h w d', t=self.step)
            elif len(inputs.shape) == 4:    # (T B) N C  (transformer tokens)
                outputs = rearrange(inputs, '(t b) n c -> t b n c', t=self.step)
            elif len(inputs.shape) == 3:
                if inputs.shape[1] > inputs.shape[2]:
                    outputs = rearrange(inputs, '(t b) n c -> t b n c', t=self.step)
                else:
                    outputs = rearrange(inputs, '(t b) c n -> t b c n', t=self.step)
            elif len(inputs.shape) == 2:
                outputs = rearrange(inputs, '(t b) c -> t b c', t=self.step)
            else:
                raise NotImplementedError(f"Unsupported shape: {inputs.shape}")
        else:
            outputs = inputs

        return outputs

    def rearrange2op(self, inputs):
        if self.groups != 1:
            if len(inputs.shape) == 7:      # T B C H W D
                outputs = rearrange(inputs, 't b c h w d -> b (c t) h w d')
            elif len(inputs.shape) == 5:    # T B C H W  (2-D fallback)
                outputs = rearrange(inputs, 't b c h w -> b (c t) h w')
            elif len(inputs.shape) == 3:
                outputs = rearrange(inputs, 't b c -> b (c t)')
            else:
                raise NotImplementedError(f"Unsupported shape: {inputs.shape}")

        elif self.layer_by_layer:
            if len(inputs.shape) == 7:      # T B C H W D
                outputs = rearrange(inputs, 't b c h w d -> (t b) c h w d')
            elif len(inputs.shape) == 4:    # T B N C
                outputs = rearrange(inputs, 't b n c -> (t b) n c')
            elif len(inputs.shape) == 3:
                outputs = rearrange(inputs, 't b c -> (t b) c')
            else:
                raise NotImplementedError(f"Unsupported shape: {inputs.shape}")
        else:
            outputs = inputs

        return outputs


class MyGrad(SurrogateFunctionBase):
    """Surrogate gradient: sigmoid approximation."""

    def __init__(self, alpha=4., requires_grad=False):
        super().__init__(alpha, requires_grad)

    @staticmethod
    def act_fun(x, alpha):
        return sigmoid.apply(x, alpha)


class MyNode(MyBaseNode):
    """LIF neuron with learnable threshold and surrogate gradient."""

    def __init__(self, threshold=1., step=4, layer_by_layer=True,
                 tau=2., act_fun=MyGrad, mem_detach=True, *args, **kwargs):
        super().__init__(
            threshold=threshold, step=step,
            layer_by_layer=layer_by_layer, mem_detach=mem_detach,
        )
        self.tau = tau
        if isinstance(act_fun, str):
            act_fun = eval(act_fun)
        self.act_fun = act_fun(alpha=4., requires_grad=False)

    def integral(self, inputs):
        self.mem = self.mem + (inputs - self.mem) / self.tau

    def calc_spike(self):
        self.spike = self.act_fun(self.mem - self.threshold)
        self.mem = self.mem * (1 - self.spike.detach())


class SimpleLIF(nn.Module):
    """
    Lightweight LIF neuron without BrainCog dependency.

    Fix vs original:
      - Re-initialises membrane only when shape changes (prevents stale state
        across batches of different sizes / first call after reset()).
    """

    def __init__(self, tau: float = 2.0, threshold: float = 1.0):
        super().__init__()
        self.tau = tau
        self.threshold = threshold
        self.mem: torch.Tensor | None = None

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        # Re-init membrane if uninitialised or shape changed (e.g. batch size differs)
        if self.mem is None or self.mem.shape != x.shape:
            self.mem = torch.zeros_like(x)

        self.mem = self.mem + (x - self.mem) / self.tau
        spike = (self.mem > self.threshold).float()
        self.mem = self.mem * (1.0 - spike)
        return spike

    def reset(self):
        self.mem = None


# ============================================================================
# Convolutional building blocks  (3-D)
# ============================================================================

class BNAndPadLayer3D(nn.Module):
    """BatchNorm3d followed by symmetric zero-padding."""

    def __init__(self, pad_pixels, num_features,
                 eps=1e-5, momentum=0.1, affine=True, track_running_stats=True):
        super().__init__()
        self.bn = nn.BatchNorm3d(num_features, eps, momentum, affine, track_running_stats)
        self.pad_pixels = pad_pixels

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        x = self.bn(x)
        if self.pad_pixels > 0:
            x = F.pad(x, [self.pad_pixels] * 6)
        return x

    # Expose BN statistics for potential reparameterisation
    @property
    def weight(self):          return self.bn.weight
    @property
    def bias(self):            return self.bn.bias
    @property
    def running_mean(self):    return self.bn.running_mean
    @property
    def running_var(self):     return self.bn.running_var
    @property
    def eps(self):             return self.bn.eps


class RepConv3D(nn.Module):
    """
    Reparameterised 3-D convolution:
      1×1×1 conv  →  BN+pad  →  depthwise 3×3×3  →  pointwise 1×1×1  →  BN
    """

    def __init__(self, in_channels: int, out_channels: int, bias: bool = False):
        super().__init__()
        self.body = nn.Sequential(
            nn.Conv3d(in_channels, in_channels, 1, 1, 0, bias=False, groups=1),
            BNAndPadLayer3D(pad_pixels=1, num_features=in_channels),
            nn.Conv3d(in_channels, in_channels, 3, 1, 0, groups=in_channels, bias=False),
            nn.Conv3d(in_channels, out_channels, 1, 1, 0, groups=1, bias=False),
            nn.BatchNorm3d(out_channels),
        )

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        return self.body(x)


class SepConv3D(BaseModule):
    """
    Inverted separable 3-D convolution (MobileNetV2-style).
    Input / output shape: (T, B, C, H, W, D)
    """

    def __init__(self, dim: int, step: int = 8, encode_type: str = 'direct',
                 expansion_ratio: int = 2, bias: bool = False,
                 kernel_size: int = 3, padding: int = 1):
        super().__init__(step=step, encode_type=encode_type)
        med = int(expansion_ratio * dim)
        self.lif1    = SimpleLIF(tau=2.0)
        self.pwconv1 = nn.Conv3d(dim, med, 1, bias=bias)
        self.bn1     = nn.BatchNorm3d(med)
        self.lif2    = SimpleLIF(tau=2.0)
        self.dwconv  = nn.Conv3d(med, med, kernel_size, padding=padding, groups=med, bias=bias)
        self.pwconv2 = nn.Conv3d(med, dim, 1, bias=bias)
        self.bn2     = nn.BatchNorm3d(dim)

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        """x: (T, B, C, H, W, D)"""
        self.lif1.reset()
        self.lif2.reset()

        T, B, C, H, W, D = x.shape
        tb = T * B

        x = self.lif1(x.flatten(0, 1)).reshape(T, B, C, H, W, D)
        x = self.bn1(self.pwconv1(x.flatten(0, 1))).reshape(T, B, -1, H, W, D)
        x = self.lif2(x.flatten(0, 1)).reshape(T, B, -1, H, W, D)
        x = self.dwconv(x.flatten(0, 1))
        x = self.bn2(self.pwconv2(x)).reshape(T, B, -1, H, W, D)
        return x


# ============================================================================
# MLP  (vectorised – no explicit T-loop)
# ============================================================================

class MLP(nn.Module):
    """
    Point-wise MLP via Conv3d(1×1×1) – processes all time steps in one call.
    Input / output shape: (T, B, C, H, W, D)

    Fix vs original:
      - Replaced Conv1d + explicit T-loop with Conv3d(kernel=1) batch call.
      - BatchNorm3d instead of BatchNorm1d for spatial consistency.
    """

    def __init__(self, in_features: int, step: int = 10, encode_type: str = 'direct',
                 hidden_features: int | None = None, out_features: int | None = None,
                 drop: float = 0.):
        super().__init__()
        hidden_features = hidden_features or in_features
        out_features    = out_features    or in_features

        self.fc1_conv = nn.Conv3d(in_features, hidden_features, kernel_size=1)
        self.fc1_bn   = nn.BatchNorm3d(hidden_features)
        self.fc1_lif  = SimpleLIF(tau=2.0)

        self.fc2_conv = nn.Conv3d(hidden_features, out_features, kernel_size=1)
        self.fc2_bn   = nn.BatchNorm3d(out_features)
        self.fc2_lif  = SimpleLIF(tau=2.0)

        self.c_hidden = hidden_features
        self.c_output = out_features

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        """x: (T, B, C, H, W, D)"""
        self.fc1_lif.reset()
        self.fc2_lif.reset()

        T, B, C, H, W, D = x.shape

        # Merge T and B into the batch dimension → (T*B, C, H, W, D)
        x = self.fc1_lif(x.flatten(0, 1))
        x = self.fc1_bn(self.fc1_conv(x))            # (TB, C_h, H, W, D)
        x = self.fc2_lif(x)
        x = self.fc2_bn(self.fc2_conv(x))            # (TB, C_out, H, W, D)

        return x.reshape(T, B, self.c_output, H, W, D)


# ============================================================================
# Spike-Driven Self-Attention  (3-D spatial)
# ============================================================================

class SDSA3D(BaseModule):
    """
    Spike-Driven Self-Attention operating over flattened 3-D spatial tokens.
    Input / output shape: (T, B, C, H, W, D)

    Fixes vs original:
      - Removed unused self.res_lif.
      - Consistent tensor layout throughout (T B H_heads N C_head).
    """

    def __init__(self, dim: int, step: int = 10, encode_type: str = 'direct',
                 num_heads: int = 16, qkv_bias: bool = False, qk_scale=None,
                 attn_drop: float = 0., proj_drop: float = 0., sr_ratio: int = 1):
        super().__init__(step=step, encode_type=encode_type)
        assert dim % num_heads == 0, f"dim {dim} must be divisible by num_heads {num_heads}"

        self.dim       = dim
        self.num_heads = num_heads
        self.scale     = qk_scale if qk_scale is not None else 0.125

        self.head_lif = SimpleLIF(tau=2.0)

        self.q_conv = RepConv3D(dim, dim, bias=qkv_bias)
        self.q_bn   = nn.BatchNorm3d(dim)
        self.q_lif  = SimpleLIF(tau=2.0)

        self.k_conv = RepConv3D(dim, dim, bias=qkv_bias)
        self.k_bn   = nn.BatchNorm3d(dim)
        self.k_lif  = SimpleLIF(tau=2.0)

        self.v_conv = RepConv3D(dim, dim, bias=qkv_bias)
        self.v_bn   = nn.BatchNorm3d(dim)
        self.v_lif  = SimpleLIF(tau=2.0)

        self.attn_drop = nn.Dropout(attn_drop)
        self.attn_lif  = SimpleLIF(tau=2.0, threshold=0.5)

        self.proj_conv = RepConv3D(dim, dim, bias=False)
        self.proj_bn   = nn.BatchNorm3d(dim)

    # ------------------------------------------------------------------
    def _project(self, x_tb, conv, bn, lif, T, B, C, H, W, D):
        """Shared Q/K/V projection path."""
        out = bn(conv(x_tb))                          # (TB, C, H, W, D)
        out = lif(out).reshape(T, B, C, H, W, D)
        # T B C H W D  →  T B H_heads N C_head
        N = H * W * D
        out = out.reshape(T, B, N, self.num_heads, C // self.num_heads)
        return out.permute(0, 1, 3, 2, 4)             # T B H_heads N C_head

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        """x: (T, B, C, H, W, D)"""
        self.head_lif.reset()
        self.q_lif.reset(); self.k_lif.reset(); self.v_lif.reset()
        self.attn_lif.reset()

        T, B, C, H, W, D = x.shape

        x     = self.head_lif(x.flatten(0, 1)).reshape(T, B, C, H, W, D)
        x_tb  = x.flatten(0, 1)                       # (TB, C, H, W, D)

        q = self._project(x_tb, self.q_conv, self.q_bn, self.q_lif, T, B, C, H, W, D)
        k = self._project(x_tb, self.k_conv, self.k_bn, self.k_lif, T, B, C, H, W, D)
        v = self._project(x_tb, self.v_conv, self.v_bn, self.v_lif, T, B, C, H, W, D)

        # Spike-driven linear attention: Q @ (K^T @ V)  –  O(N·C²) not O(N²·C)
        kv = k.transpose(-2, -1) @ v                  # T B H_heads C_head C_head
        x  = (q @ kv) * self.scale                    # T B H_heads N C_head

        # Merge heads  →  (TB, C, H, W, D)
        N = H * W * D
        x = x.permute(0, 1, 3, 2, 4).reshape(T, B, N, C)
        x = x.transpose(-1, -2).reshape(T, B, C, H, W, D)

        x = self.attn_lif(x.flatten(0, 1)).reshape(T, B, C, H, W, D)
        x = self.proj_bn(self.proj_conv(x.flatten(0, 1))).reshape(T, B, C, H, W, D)
        return x


# ============================================================================
# Transformer Block
# ============================================================================

class Block(nn.Module):
    """
    Transformer block: SDSA3D + MLP with residual connections.

    Fix vs original:
      - LayerNorm is applied correctly (reshape to token sequence, norm, reshape back).
      - norm is only created when actually used (SNN blocks don't need external LN).
    """

    def __init__(self, dim: int, num_heads: int, step: int = 10,
                 mlp_ratio: float = 4., qkv_bias: bool = False, qk_scale=None,
                 drop: float = 0., attn_drop: float = 0., drop_path: float = 0.,
                 norm_layer=nn.LayerNorm, sr_ratio: int = 1):
        super().__init__()

        # SDSA is spike-driven (has internal LIF) → no external LayerNorm needed.
        self.attn = SDSA3D(dim, step=step, num_heads=num_heads,
                           qkv_bias=qkv_bias, qk_scale=qk_scale,
                           attn_drop=attn_drop, proj_drop=drop, sr_ratio=sr_ratio)

        mlp_hidden = int(dim * mlp_ratio)
        self.mlp = MLP(step=step, in_features=dim, hidden_features=mlp_hidden, drop=drop)

        self.drop_path = DropPath(drop_path) if drop_path > 0. else nn.Identity()

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        """x: (T, B, C, H, W, D)"""
        x = x + self.drop_path(self.attn(x))
        x = x + self.drop_path(self.mlp(x))
        return x


# ============================================================================
# Down-sampling & ConvBlock
# ============================================================================

class DownSampling3D(BaseModule):
    """Strided Conv3d down-sampling with optional LIF pre-activation."""

    def __init__(self, step: int = 10, encode_type: str = 'direct',
                 in_channels: int = 2, embed_dims: int = 256,
                 kernel_size: int = 3, stride: int = 2, padding: int = 1,
                 first_layer: bool = True):
        super().__init__(step=step, encode_type=encode_type)
        self.encode_conv = nn.Conv3d(in_channels, embed_dims,
                                     kernel_size=kernel_size, stride=stride, padding=padding)
        self.encode_bn   = nn.BatchNorm3d(embed_dims)
        if not first_layer:
            self.encode_lif = SimpleLIF(tau=2.0)

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        """x: (T, B, C, H, W, D)"""
        if hasattr(self, 'encode_lif'):
            self.encode_lif.reset()

        T, B, C, H, W, D = x.shape

        if hasattr(self, 'encode_lif'):
            x = self.encode_lif(x.flatten(0, 1)).reshape(T, B, C, H, W, D)

        x = self.encode_conv(x.flatten(0, 1))        # (TB, C', H', W', D')
        _, C_out, H_out, W_out, D_out = x.shape
        x = self.encode_bn(x).reshape(T, B, C_out, H_out, W_out, D_out)
        return x


class ConvBlock3D(BaseModule):
    """
    3-D conv block with residual:  SepConv3D  +  LIF→Conv3d→BN  ×2

    Fix vs original:
      - mlp_ratio is used from constructor arg (was hard-coded to 4).
    """

    def __init__(self, dim: int, step: int = 10, encode_type: str = 'direct',
                 mlp_ratio: float = 4.0):
        super().__init__(step=step, encode_type=encode_type)
        self.mlp_ratio = mlp_ratio
        exp = int(dim * mlp_ratio)

        self.sep_conv = SepConv3D(step=step, dim=dim)
        self.lif1  = SimpleLIF(tau=2.0)
        self.conv1 = nn.Conv3d(dim, exp, 3, padding=1, bias=False)
        self.bn1   = nn.BatchNorm3d(exp)
        self.lif2  = SimpleLIF(tau=2.0)
        self.conv2 = nn.Conv3d(exp, dim, 3, padding=1, bias=False)
        self.bn2   = nn.BatchNorm3d(dim)

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        """x: (T, B, C, H, W, D)"""
        self.lif1.reset()
        self.lif2.reset()

        T, B, C, H, W, D = x.shape
        exp = int(self.mlp_ratio * C)

        x = self.sep_conv(x) + x
        residual = x

        x = self.bn1(self.conv1(self.lif1(x.flatten(0, 1)))).reshape(T, B, exp, H, W, D)
        x = self.bn2(self.conv2(self.lif2(x.flatten(0, 1)))).reshape(T, B, C, H, W, D)
        return residual + x


# ============================================================================
# Main Model
# ============================================================================

class SDTransformer4D(BaseModule):
    """
    4D Spike-Driven Transformer for volumetric event data.

    Input  (standard / mainstream): (B, T, C, H, W, D)
    Output:                         (B, num_classes)

    Architecture  (4-stage encoder):
      Stage 1 – two strided ConvBlocks                   (½ → ¼ spatial)
      Stage 2 – two ConvBlocks                            (⅛ spatial)
      Stage 3 – SDSA Transformer blocks                  (1/16 spatial)
      Stage 4 – SDSA Transformer blocks (stride-1 conv)  (1/16 spatial)
      Head    – global avg-pool → LIF → Linear → mean(T)
    """

    def __init__(self,
                 step: int = 10,
                 encode_type: str = 'direct',
                 patch_size: int = 4,
                 in_channels: int = 2,
                 num_classes: int = 10,
                 embed_dims: int = 256,
                 num_heads: int = 16,
                 mlp_ratios: float = 4.,
                 qkv_bias: bool = False,
                 qk_scale=None,
                 drop_rate: float = 0.,
                 attn_drop_rate: float = 0.,
                 drop_path_rate: float = 0.,
                 norm_layer=nn.LayerNorm,
                 depths: int = 2,
                 sr_ratios: int = 4,
                 kd: bool = False):
        super().__init__(step=step, encode_type=encode_type)

        self.step        = step
        self.num_classes = num_classes
        self.depths      = depths
        self.block3_depths = 1

        dpr = [x.item() for x in torch.linspace(0, drop_path_rate, depths)]

        # ---- Stage 1 --------------------------------------------------------
        self.downsample1_1 = DownSampling3D(
            step=step, in_channels=in_channels, embed_dims=embed_dims // 16,
            kernel_size=3, stride=2, padding=1, first_layer=True)
        self.ConvBlock1_1 = nn.ModuleList([
            ConvBlock3D(step=step, dim=embed_dims // 16, mlp_ratio=mlp_ratios)])

        self.downsample1_2 = DownSampling3D(
            step=step, in_channels=embed_dims // 16, embed_dims=embed_dims // 8,
            kernel_size=3, stride=2, padding=1, first_layer=False)
        self.ConvBlock1_2 = nn.ModuleList([
            ConvBlock3D(step=step, dim=embed_dims // 8, mlp_ratio=mlp_ratios)])

        # ---- Stage 2 --------------------------------------------------------
        self.downsample2 = DownSampling3D(
            step=step, in_channels=embed_dims // 8, embed_dims=embed_dims // 4,
            kernel_size=3, stride=2, padding=1, first_layer=False)
        self.ConvBlock2_1 = nn.ModuleList([
            ConvBlock3D(step=step, dim=embed_dims // 4, mlp_ratio=mlp_ratios)])
        self.ConvBlock2_2 = nn.ModuleList([
            ConvBlock3D(step=step, dim=embed_dims // 4, mlp_ratio=mlp_ratios)])

        # ---- Stage 3 (attention) --------------------------------------------
        self.downsample3 = DownSampling3D(
            step=step, in_channels=embed_dims // 4, embed_dims=embed_dims // 2,
            kernel_size=3, stride=2, padding=1, first_layer=False)
        self.block3 = nn.ModuleList([
            Block(step=step, dim=embed_dims // 2, num_heads=num_heads,
                  mlp_ratio=mlp_ratios, qkv_bias=qkv_bias, qk_scale=qk_scale,
                  drop=drop_rate, attn_drop=attn_drop_rate, norm_layer=norm_layer,
                  sr_ratio=sr_ratios)
            for _ in range(self.block3_depths)
        ])

        # ---- Stage 4 (attention) --------------------------------------------
        self.downsample4 = DownSampling3D(
            step=step, in_channels=embed_dims // 2, embed_dims=embed_dims,
            kernel_size=3, stride=1, padding=1, first_layer=False)
        self.block4 = nn.ModuleList([
            Block(step=step, dim=embed_dims, num_heads=num_heads,
                  mlp_ratio=mlp_ratios, qkv_bias=qkv_bias, qk_scale=qk_scale,
                  drop=drop_rate, attn_drop=attn_drop_rate, drop_path=dpr[j],
                  norm_layer=norm_layer, sr_ratio=sr_ratios)
            for j in range(self.depths - self.block3_depths)
        ])

        # ---- Classification head -------------------------------------------
        self.lif  = SimpleLIF(tau=2.0)
        self.head = nn.Linear(embed_dims, num_classes) if num_classes > 0 else nn.Identity()

        self.kd = kd
        if self.kd:
            self.head_kd = nn.Linear(embed_dims, num_classes) if num_classes > 0 else nn.Identity()

        self.apply(self._init_weights)

    # ------------------------------------------------------------------
    @staticmethod
    def _init_weights(m):
        if isinstance(m, nn.Linear):
            trunc_normal_(m.weight, std=.02)
            if m.bias is not None:
                nn.init.constant_(m.bias, 0)
        elif isinstance(m, nn.LayerNorm):
            nn.init.constant_(m.bias, 0)
            nn.init.constant_(m.weight, 1.0)

    # ------------------------------------------------------------------
    def forward_features(self, x: torch.Tensor) -> torch.Tensor:
        """
        x: (T, B, C, H, W, D)
        returns: (T, B, embed_dims)
        """
        # Stage 1
        x = self.downsample1_1(x)
        for blk in self.ConvBlock1_1:
            x = blk(x)
        x = self.downsample1_2(x)
        for blk in self.ConvBlock1_2:
            x = blk(x)

        # Stage 2
        x = self.downsample2(x)
        for blk in self.ConvBlock2_1:
            x = blk(x)
        for blk in self.ConvBlock2_2:
            x = blk(x)

        # Stage 3
        x = self.downsample3(x)
        for blk in self.block3:
            x = blk(x)

        # Stage 4
        x = self.downsample4(x)
        for blk in self.block4:
            x = blk(x)

        # Global average pool over H W D  →  (T, B, C)
        x = x.flatten(3).mean(3)
        return x

    # ------------------------------------------------------------------
    def forward(self, x: torch.Tensor) -> torch.Tensor:
        """
        Args:
            x: (B, T, C, H, W, D)  – standard mainstream input order
        Returns:
            (B, num_classes)
        """
        self.lif.reset()

        # (B, T, C, H, W, D) → (T, B, C, H, W, D)
        x = x.permute(1, 0, 2, 3, 4, 5).contiguous()

        x = self.forward_features(x)    # T B embed_dims
        T, B, _ = x.shape

        x_lif = self.lif(x.flatten(0, 1)).reshape(T, B, -1)
        out   = self.head(x_lif).mean(0)   # average over T  →  (B, num_classes)

        if self.kd:
            out_kd = self.head_kd(x_lif).mean(0)
            if self.training:
                return out, out_kd
            return (out + out_kd) / 2

        return out


# ============================================================================
# Registry & factory
# ============================================================================

@register_model
def sd_transformer_4d(pretrained: bool = False, **kwargs):
    """
    Create a 4D Spike-Driven Transformer.

    Example::

        model = sd_transformer_4d(
            step=8, in_channels=2, num_classes=10,
            embed_dims=256, num_heads=16, mlp_ratios=4, depths=2,
        )
        # Input: (B, T, C, H, W, D)
        x = torch.randn(4, 8, 2, 32, 32, 32)
        out = model(x)   # (4, 10)
    """
    model = SDTransformer4D(
        step            = kwargs.pop('step',            8),
        patch_size      = kwargs.pop('patch_size',      4),
        embed_dims      = kwargs.pop('embed_dims',    256),
        num_heads       = kwargs.pop('num_heads',      16),
        mlp_ratios      = kwargs.pop('mlp_ratios',      4),
        in_channels     = kwargs.pop('in_channels',     2),
        num_classes     = kwargs.pop('num_classes',    10),
        qkv_bias        = kwargs.pop('qkv_bias',    False),
        depths          = kwargs.pop('depths',          2),
        sr_ratios       = kwargs.pop('sr_ratios',       1),
        encode_type     = kwargs.pop('encode_type', 'direct'),
        drop_rate       = kwargs.pop('drop_rate',     0.),
        attn_drop_rate  = kwargs.pop('attn_drop_rate', 0.),
        drop_path_rate  = kwargs.pop('drop_path_rate', 0.),
        kd              = kwargs.pop('kd',          False),
        **kwargs,
    )
    model.default_cfg = _cfg()
    return model


# ============================================================================
# Pre-defined size configurations
# ============================================================================

MODEL_SIZES = {
    'small': dict(
        step=8, patch_size=4, embed_dims=128, num_heads=8,
        mlp_ratios=4, in_channels=2, num_classes=10,
        qkv_bias=False, depths=2, sr_ratios=1,
    ),
    'medium': dict(
        step=8, patch_size=4, embed_dims=256, num_heads=16,
        mlp_ratios=4, in_channels=2, num_classes=10,
        qkv_bias=False, depths=2, sr_ratios=1,
    ),
    'large': dict(
        step=8, patch_size=4, embed_dims=512, num_heads=16,
        mlp_ratios=4, in_channels=2, num_classes=10,
        qkv_bias=False, depths=4, sr_ratios=1,
    ),
}


def build_model(size: str = 'medium', **kwargs) -> SDTransformer4D:
    """
    Build a pre-configured SDTransformer4D.

    Args:
        size:     'small' | 'medium' | 'large'
        **kwargs: Override any config key.

    Examples::

        model = build_model('medium', num_classes=100)
        model = build_model('large',  embed_dims=384, num_classes=40)
    """
    if size not in MODEL_SIZES:
        raise ValueError(f"size must be one of {list(MODEL_SIZES)}, got '{size}'")
    cfg = {**MODEL_SIZES[size], **kwargs}
    return sd_transformer_4d(**cfg)