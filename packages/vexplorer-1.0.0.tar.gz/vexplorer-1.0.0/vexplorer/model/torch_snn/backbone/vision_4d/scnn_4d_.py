"""
SCNN4D – 4-D Spiking Convolutional Neural Network for volumetric event data.

Input  (standard / mainstream): (B, T, C, H, W, D)
Output:                          (B, num_classes)

Fixes vs original:
  - Global mutable `thresh`, `lens`, `decay` replaced with per-instance parameters.
  - `ActFun` threshold now comes from the enclosing module (no global state).
  - `SurrGradSpike` and `ActFun` unified into a single configurable class.
  - `LIFConv3D` / `LIFLinear` expose `reset()` for clean episode boundaries.
  - Added `contiguous()` after every reshape to avoid non-contiguous tensor errors.
  - `MODEL_SIZES` now carries meaningfully different architectures.
  - `SCNN4D.forward` uses named dims instead of `input.shape[0/1]`.
  - Minor: `device` argument removed from `torch.zeros_like` (redundant).
"""

import torch
import torch.nn as nn
import torch.nn.functional as F
from typing import Optional, Tuple


# ============================================================================
# Surrogate Gradient Functions
# ============================================================================

class _RectangularSurrogate(torch.autograd.Function):
    """
    Rectangular / box-car surrogate gradient.
    Forward : Heaviside  (spike if x > threshold)
    Backward: 1 / (2*lens)  when |x - threshold| < lens, else 0
    """
    @staticmethod
    def forward(ctx, x: torch.Tensor, threshold: float, lens: float):
        ctx.save_for_backward(x)
        ctx.threshold = threshold
        ctx.lens = lens
        return (x > threshold).float()

    @staticmethod
    def backward(ctx, grad_output: torch.Tensor):
        (x,) = ctx.saved_tensors
        mask = (x - ctx.threshold).abs() < ctx.lens
        return grad_output * mask.float() / (2.0 * ctx.lens), None, None


class _SigmoidSurrogate(torch.autograd.Function):
    """
    Sigmoid / inverse-square surrogate gradient.
    Forward : Heaviside  (spike if x > 0, threshold already subtracted)
    Backward: grad / (scale * |x| + 1)^2
    """
    @staticmethod
    def forward(ctx, x: torch.Tensor, scale: float):
        ctx.save_for_backward(x)
        ctx.scale = scale
        return (x > 0).float()

    @staticmethod
    def backward(ctx, grad_output: torch.Tensor):
        (x,) = ctx.saved_tensors
        return grad_output / (ctx.scale * x.abs() + 1.0) ** 2, None


class SpikeFunction(nn.Module):
    """
    Configurable spiking activation with surrogate gradient.

    Args:
        threshold : firing threshold  (default 0.5)
        lens      : half-width of rectangular surrogate window  (default 0.5)
        surrogate : 'rect' (rectangular) or 'sigmoid'  (default 'rect')
        scale     : steepness for sigmoid surrogate  (default 100.0)
    """

    def __init__(self, threshold: float = 0.5, lens: float = 0.5,
                 surrogate: str = 'rect', scale: float = 100.0):
        super().__init__()
        self.threshold  = threshold
        self.lens       = lens
        self.surrogate  = surrogate
        self.scale      = scale

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        if self.surrogate == 'rect':
            return _RectangularSurrogate.apply(x, self.threshold, self.lens)
        elif self.surrogate == 'sigmoid':
            return _SigmoidSurrogate.apply(x - self.threshold, self.scale)
        else:
            raise ValueError(f"surrogate must be 'rect' or 'sigmoid', got '{self.surrogate}'")

    def extra_repr(self) -> str:
        return (f"threshold={self.threshold}, lens={self.lens}, "
                f"surrogate='{self.surrogate}'")


# ============================================================================
# LIF Layers
# ============================================================================

# Type alias for LIF state: (membrane_potential, last_spike)
LIFState = Tuple[torch.Tensor, torch.Tensor]


class LIFConv3D(nn.Module):
    """
    3-D convolutional LIF layer with explicit state management.

    Args:
        in_planes, out_planes : channel dimensions
        kernel_size, stride, padding : conv geometry
        decay     : leak factor  (default 0.2)
        threshold : firing threshold  (default 0.5)
        lens      : surrogate window half-width  (default 0.5)
        surrogate : 'rect' or 'sigmoid'
    """

    def __init__(self, in_planes: int, out_planes: int,
                 kernel_size: int = 3, stride: int = 1, padding: int = 1,
                 decay: float = 0.2, threshold: float = 0.5, lens: float = 0.5,
                 surrogate: str = 'rect'):
        super().__init__()
        self.conv      = nn.Conv3d(in_planes, out_planes,
                                   kernel_size=kernel_size,
                                   stride=stride, padding=padding)
        self.decay     = decay
        self.spike_fn  = SpikeFunction(threshold=threshold, lens=lens,
                                       surrogate=surrogate)
        self._state: Optional[LIFState] = None

    # ------------------------------------------------------------------
    def reset(self):
        """Clear membrane state (call at the start of each sequence)."""
        self._state = None

    def forward(self, x: torch.Tensor,
                state: Optional[LIFState] = None) -> Tuple[torch.Tensor, LIFState]:
        """
        Args:
            x    : (B, C_in, H, W, D) – single time-step input
            state: optional (mem, spike) from previous step; uses internal
                   state if None and self._state is set

        Returns:
            spike: (B, C_out, H, W, D)
            state: updated (mem, spike)
        """
        x = self.conv(x)

        # Resolve state priority: explicit arg > internal > zeros
        if state is None:
            state = self._state
        if state is None:
            mem   = torch.zeros_like(x)
            spike = torch.zeros_like(x)
        else:
            mem, spike = state

        new_mem   = mem * self.decay * (1.0 - spike) + x
        new_spike = self.spike_fn(new_mem)

        self._state = (new_mem, new_spike)
        return new_spike, (new_mem, new_spike)


class LIFLinear(nn.Module):
    """
    Fully-connected LIF layer with explicit state management.

    Args:
        in_planes, out_planes : feature dimensions
        decay      : leak factor  (default 0.2)
        threshold  : firing threshold  (default 0.5)
        lens       : surrogate window half-width  (default 0.5)
        surrogate  : 'rect' or 'sigmoid'
        last_layer : if True, output raw membrane (no spiking) for
                     readout / rate-coding classification head
    """

    def __init__(self, in_planes: int, out_planes: int,
                 decay: float = 0.2, threshold: float = 0.5, lens: float = 0.5,
                 surrogate: str = 'rect', last_layer: bool = False):
        super().__init__()
        self.fc         = nn.Linear(in_planes, out_planes)
        self.decay      = decay
        self.last_layer = last_layer
        self.spike_fn   = SpikeFunction(threshold=threshold, lens=lens,
                                        surrogate=surrogate)
        self._state: Optional[LIFState] = None

    # ------------------------------------------------------------------
    def reset(self):
        """Clear membrane state."""
        self._state = None

    def forward(self, x: torch.Tensor,
                state: Optional[LIFState] = None) -> Tuple[torch.Tensor, LIFState]:
        """
        Args:
            x    : (B, in_planes)
            state: optional (mem, spike) from previous step

        Returns:
            output: spike tensor or membrane potential (last_layer=True)
            state : updated (mem, spike)
        """
        x = self.fc(x)

        if state is None:
            state = self._state
        if state is None:
            mem   = torch.zeros_like(x)
            spike = torch.zeros_like(x)
        else:
            mem, spike = state

        if self.last_layer:
            # Integrate-and-hold: accumulate membrane for readout
            new_mem   = mem + x
            new_spike = new_mem          # pass-through (no spiking)
        else:
            new_mem   = mem * self.decay * (1.0 - spike) + x
            new_spike = self.spike_fn(new_mem)

        self._state = (new_mem, new_spike)
        return new_spike, (new_mem, new_spike)


# ============================================================================
# Main Model
# ============================================================================

class SCNN4D(nn.Module):
    """
    4-D Spiking CNN for volumetric event-based data.

    Input  (standard / mainstream): (B, T, C, H, W, D)
      B : batch size
      T : time steps
      C : input channels  (typically 2 for DVS polarity)
      H, W, D : spatial dimensions

    Output: (B, num_classes) – membrane potential averaged over T

    Architecture:
      LIFConv3D(C→c1) → AvgPool3d(2) →
      LIFConv3D(c1→c2) → AvgPool3d(2) →
      AdaptiveAvgPool3d(pool_size³) →
      Flatten →
      LIFLinear(c2·pool_size³ → fc_hidden) →
      LIFLinear(fc_hidden → num_classes, last_layer=True)

    Args:
        num_classes   : number of output classes
        input_channel : number of input channels  (default 2)
        c1, c2        : conv channel widths  (default 15, 40)
        fc_hidden     : hidden FC width  (default 300)
        pool_size     : adaptive pool target side length  (default 4)
        decay         : LIF leak factor  (default 0.2)
        threshold     : LIF firing threshold  (default 0.5)
        lens          : surrogate half-width  (default 0.5)
        surrogate     : 'rect' or 'sigmoid'  (default 'rect')
        need_last_layer: use membrane readout at output  (default True)
    """

    def __init__(self,
                 num_classes: int = 10,
                 input_channel: int = 2,
                 c1: int = 15,
                 c2: int = 40,
                 fc_hidden: int = 300,
                 pool_size: int = 4,
                 decay: float = 0.2,
                 threshold: float = 0.5,
                 lens: float = 0.5,
                 surrogate: str = 'rect',
                 need_last_layer: bool = True,
                 **kwargs):
        super().__init__()

        self.need_last_layer = need_last_layer
        self.pool_size       = pool_size

        lif_kw = dict(decay=decay, threshold=threshold, lens=lens, surrogate=surrogate)

        self.conv1         = LIFConv3D(input_channel, c1, kernel_size=3, stride=1, padding=1, **lif_kw)
        self.conv2         = LIFConv3D(c1, c2,         kernel_size=3, stride=1, padding=1, **lif_kw)
        self.adaptive_pool = nn.AdaptiveAvgPool3d((pool_size, pool_size, pool_size))

        fc1_in = c2 * pool_size * pool_size * pool_size
        self.fc1 = LIFLinear(fc1_in,    fc_hidden,   last_layer=False, **lif_kw)
        self.fc2 = LIFLinear(fc_hidden, num_classes, last_layer=need_last_layer, **lif_kw)

    # ------------------------------------------------------------------
    def reset(self):
        """Reset all LIF states – call before processing a new sequence."""
        self.conv1.reset()
        self.conv2.reset()
        self.fc1.reset()
        self.fc2.reset()

    # ------------------------------------------------------------------
    def forward(self, x: torch.Tensor) -> torch.Tensor:
        """
        Args:
            x: (B, T, C, H, W, D)

        Returns:
            (B, num_classes) – time-averaged membrane / spike output
        """
        self.reset()

        B, T, C, H, W, D = x.shape
        total = x.new_zeros(B, self.fc2.fc.out_features)

        for t in range(T):
            xt = x[:, t].float().contiguous()          # (B, C, H, W, D)

            xt, _ = self.conv1(xt)                     # (B, c1, H, W, D)
            xt    = F.avg_pool3d(xt, 2)                # (B, c1, H/2, W/2, D/2)

            xt, _ = self.conv2(xt)                     # (B, c2, ...)
            xt    = F.avg_pool3d(xt, 2)                # (B, c2, H/4, ...)

            xt = self.adaptive_pool(xt)                # (B, c2, pool, pool, pool)
            xt = xt.flatten(1).contiguous()            # (B, c2*pool³)

            xt, _        = self.fc1(xt)                # (B, fc_hidden)
            out, (mem, _) = self.fc2(xt)               # (B, num_classes)

            # need_last_layer=True : accumulate membrane potential (rate readout)
            # need_last_layer=False: accumulate spikes
            total = total + (mem if self.need_last_layer else out)

        return total / T


# ============================================================================
# Pre-defined size configurations
# ============================================================================

MODEL_SIZES = {
    # Tiny network – fast experiments
    'small': dict(
        c1=8, c2=16, fc_hidden=128, pool_size=4,
    ),
    # Default balanced network
    'medium': dict(
        c1=15, c2=40, fc_hidden=300, pool_size=4,
    ),
    # Wider network – more capacity
    'large': dict(
        c1=32, c2=96, fc_hidden=512, pool_size=4,
    ),
}


def build_model(size: str = 'medium', **kwargs) -> SCNN4D:
    """
    Build a pre-configured SCNN4D.

    Args:
        size    : 'small' | 'medium' | 'large'
        **kwargs: Override any constructor argument, e.g.
                  num_classes, input_channel, decay, surrogate, …

    Examples::

        model = build_model('medium', num_classes=100)
        model = build_model('small',  surrogate='sigmoid', decay=0.5)
        model = build_model('large',  num_classes=40, input_channel=1)
    """
    if size not in MODEL_SIZES:
        raise ValueError(f"size must be one of {list(MODEL_SIZES)}, got '{size}'")
    cfg = {**MODEL_SIZES[size], **kwargs}
    return SCNN4D(**cfg)