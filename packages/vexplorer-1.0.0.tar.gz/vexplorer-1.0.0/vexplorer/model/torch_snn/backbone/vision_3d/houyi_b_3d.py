# HouyiB 3D — Physics-Aware SNN for Solar Flare Forecasting (2D Spatial)
#
# Innovation over standard Spikformer:
#   1. PLIFNode – Parametric LIF with learnable time constant τ
#      (multi-scale temporal: slow flux emergence + fast reconnection)
#
# For 2D spatial data (H, W) — no Z axis, so innovations 2 & 3 (anisotropic
# conv / Z-pos encoding) are not applicable here. Use SolarSpikformer4D for
# volumetric data with all three innovations.
#
# Input:  (B, T, C, H, W)   – B=batch, T=SNN time steps, C=channels, H,W=spatial
# Output: (B, num_classes)

import math
import torch
import torch.nn as nn
from timm.models.layers import to_2tuple, trunc_normal_, DropPath
from timm.models.registry import register_model
from timm.models.vision_transformer import _cfg
import torch.nn.functional as F
from braincog.model_zoo.base_module import BaseModule
from braincog.base.node.node import *
from braincog.base.connection.layer import *
from braincog.base.strategy.surrogate import *
from einops import rearrange
from functools import partial

__all__ = ['HouyiB3D']


# ============================================================================
# Neuron Nodes
# ============================================================================

class MyBaseNode(BaseNode):
    """Base neuron node for 2D spatial-temporal data."""
    def __init__(self, threshold=0.5, step=4, layer_by_layer=False, mem_detach=False):
        super().__init__(threshold=threshold, step=step,
                         layer_by_layer=layer_by_layer, mem_detach=mem_detach)

    def rearrange2node(self, inputs):
        if self.groups != 1:
            if len(inputs.shape) == 4:
                outputs = rearrange(inputs, 'b (c t) w h -> t b c w h', t=self.step)
            elif len(inputs.shape) == 2:
                outputs = rearrange(inputs, 'b (c t) -> t b c', t=self.step)
            else:
                raise NotImplementedError
        elif self.layer_by_layer:
            if len(inputs.shape) == 4:
                outputs = rearrange(inputs, '(t b) c w h -> t b c w h', t=self.step)
            elif len(inputs.shape) == 3:
                outputs = rearrange(inputs, '(t b) n c -> t b n c', t=self.step)
            elif len(inputs.shape) == 2:
                outputs = rearrange(inputs, '(t b) c -> t b c', t=self.step)
            else:
                raise NotImplementedError
        else:
            outputs = inputs
        return outputs

    def rearrange2op(self, inputs):
        if self.groups != 1:
            if len(inputs.shape) == 5:
                outputs = rearrange(inputs, 't b c w h -> b (c t) w h')
            elif len(inputs.shape) == 3:
                outputs = rearrange(inputs, 't b c -> b (c t)')
            else:
                raise NotImplementedError
        elif self.layer_by_layer:
            if len(inputs.shape) == 5:
                outputs = rearrange(inputs, 't b c w h -> (t b) c w h')
            elif len(inputs.shape) == 4:
                outputs = rearrange(inputs, 't b n c -> (t b) n c')
            elif len(inputs.shape) == 3:
                outputs = rearrange(inputs, 't b c -> (t b) c')
            else:
                raise NotImplementedError
        else:
            outputs = inputs
        return outputs


class MyGrad(SurrogateFunctionBase):
    """Surrogate gradient: sigmoid approximation."""
    def __init__(self, alpha=4., requires_grad=False):
        super().__init__(alpha, requires_grad)

    @staticmethod
    def act_fun(x, alpha):
        return sigmoid.apply(x, alpha)


# ============================================================================
# 创新点一: PLIFNode — Parametric LIF with learnable time constant τ
# ============================================================================

class PLIFNode(MyBaseNode):
    """
    Parametric LIF (PLIF) neuron — Time-Adaptive SNN.

    The time constant τ is parameterized as a learnable weight, enabling
    adaptive capture of both slow flux emergence and fast magnetic reconnection.

    τ_actual = sigmoid(w_tau) * tau_range + tau_min
    """
    def __init__(self, threshold=1., step=4, layer_by_layer=True,
                 init_tau=2.0, tau_min=1.1, tau_range=10.0,
                 act_fun=MyGrad, mem_detach=True, *args, **kwargs):
        super().__init__(
            threshold=threshold, step=step,
            layer_by_layer=layer_by_layer, mem_detach=mem_detach,
        )
        if isinstance(act_fun, str):
            act_fun = eval(act_fun)
        self.act_fun = act_fun(alpha=4., requires_grad=True)
        self.threshold_param = nn.Parameter(torch.tensor(float(threshold)))

        self.tau_min = tau_min
        self.tau_range = tau_range
        init_w = math.log((init_tau - tau_min) / (tau_range - (init_tau - tau_min)) + 1e-8) \
            if tau_min < init_tau < tau_min + tau_range else 0.0
        self.w_tau = nn.Parameter(torch.tensor(init_w))

    def integral(self, inputs):
        tau_actual = torch.sigmoid(self.w_tau) * self.tau_range + self.tau_min
        self.mem = self.mem + (inputs - self.mem) / tau_actual

    def calc_spike(self):
        self.spike = self.act_fun(self.mem - self.threshold_param)
        self.mem = self.mem * (1 - self.spike.detach())


# ============================================================================
# MLP (Conv1d-based, tokens = flattened spatial)
# ============================================================================

class MLP(BaseModule):
    """Conv1d-based MLP with PLIF neurons. Input/output: (T, B, C, N)."""

    def __init__(self, in_features, step=10, encode_type='direct',
                 hidden_features=None, out_features=None, drop=0.):
        super().__init__(step=step, encode_type=encode_type)
        out_features = out_features or in_features
        hidden_features = hidden_features or in_features

        self.fc1_conv = nn.Conv1d(in_features, hidden_features, kernel_size=1, stride=1)
        self.fc1_bn = nn.BatchNorm1d(hidden_features)
        self.fc1_lif = PLIFNode(step=step, init_tau=2.0)

        self.fc2_conv = nn.Conv1d(hidden_features, out_features, kernel_size=1, stride=1)
        self.fc2_bn = nn.BatchNorm1d(out_features)
        self.fc2_lif = PLIFNode(step=step, init_tau=2.0)

        self.c_hidden = hidden_features
        self.c_output = out_features

    def forward(self, x):
        self.reset()
        T, B, C, N = x.shape

        x = self.fc1_conv(x.flatten(0, 1))
        x = self.fc1_bn(x).reshape(T, B, self.c_hidden, N).contiguous()
        x = self.fc1_lif(x.flatten(0, 1)).reshape(T, B, self.c_hidden, N).contiguous()

        x = self.fc2_conv(x.flatten(0, 1))
        x = self.fc2_bn(x).reshape(T, B, C, N).contiguous()
        x = self.fc2_lif(x.flatten(0, 1)).reshape(T, B, C, N).contiguous()
        return x


# ============================================================================
# Spiking Self-Attention (PLIF variant)
# ============================================================================

class SSA(BaseModule):
    """Spiking Self-Attention with PLIFNode. Input/output: (T, B, C, N)."""

    def __init__(self, dim, step=10, encode_type='direct', num_heads=16,
                 qkv_bias=False, qk_scale=None, attn_drop=0.,
                 proj_drop=0., sr_ratio=1):
        super().__init__(step=step, encode_type=encode_type)
        assert dim % num_heads == 0
        self.dim = dim
        self.num_heads = num_heads
        self.scale = 0.25

        self.q_conv = nn.Conv1d(dim, dim, kernel_size=1, stride=1, bias=False)
        self.q_bn = nn.BatchNorm1d(dim)
        self.q_lif = PLIFNode(step=step, init_tau=2.0)

        self.k_conv = nn.Conv1d(dim, dim, kernel_size=1, stride=1, bias=False)
        self.k_bn = nn.BatchNorm1d(dim)
        self.k_lif = PLIFNode(step=step, init_tau=2.0)

        self.v_conv = nn.Conv1d(dim, dim, kernel_size=1, stride=1, bias=False)
        self.v_bn = nn.BatchNorm1d(dim)
        self.v_lif = PLIFNode(step=step, init_tau=2.0)

        self.attn_drop = nn.Dropout(0.2)
        self.attn_lif = PLIFNode(step=step, init_tau=2.0, threshold=0.5)

        self.proj_conv = nn.Conv1d(dim, dim, kernel_size=1, stride=1, bias=False)
        self.proj_bn = nn.BatchNorm1d(dim)
        self.proj_lif = PLIFNode(step=step, init_tau=2.0)

    def forward(self, x):
        self.reset()
        T, B, C, N = x.shape

        x_for_qkv = x.flatten(0, 1)  # TB, C, N

        q = self.q_lif(
            self.q_bn(self.q_conv(x_for_qkv)).reshape(T, B, C, N).contiguous().flatten(0, 1)
        ).reshape(T, B, C, N)
        q = q.reshape(T, B, N, self.num_heads, C // self.num_heads).permute(0, 1, 3, 2, 4).contiguous()

        k = self.k_lif(
            self.k_bn(self.k_conv(x_for_qkv)).reshape(T, B, C, N).contiguous().flatten(0, 1)
        ).reshape(T, B, C, N)
        k = k.reshape(T, B, N, self.num_heads, C // self.num_heads).permute(0, 1, 3, 2, 4).contiguous()

        v = self.v_lif(
            self.v_bn(self.v_conv(x_for_qkv)).reshape(T, B, C, N).contiguous().flatten(0, 1)
        ).reshape(T, B, C, N)
        v = v.reshape(T, B, N, self.num_heads, C // self.num_heads).permute(0, 1, 3, 2, 4).contiguous()

        attn = (q @ k.transpose(-2, -1))
        x = (attn @ v) * self.scale

        x = x.transpose(3, 4).reshape(T, B, C, N).contiguous()
        x = self.attn_lif(x.flatten(0, 1))
        x = self.proj_lif(self.proj_bn(self.proj_conv(x))).reshape(T, B, C, N)

        return x


# ============================================================================
# Encoder Block
# ============================================================================

class Block(nn.Module):
    """Transformer block: SSA + MLP with residual connections."""

    def __init__(self, dim, num_heads, step=10, mlp_ratio=4., qkv_bias=False,
                 qk_scale=None, drop=0., attn_drop=0., drop_path=0.,
                 norm_layer=nn.LayerNorm, sr_ratio=1):
        super().__init__()
        self.norm1 = norm_layer(dim)
        self.attn = SSA(dim, step=step, num_heads=num_heads, qkv_bias=qkv_bias,
                        qk_scale=qk_scale, attn_drop=attn_drop, proj_drop=drop,
                        sr_ratio=sr_ratio)
        self.norm2 = norm_layer(dim)
        mlp_hidden_dim = int(dim * mlp_ratio)
        self.mlp = MLP(step=step, in_features=dim, hidden_features=mlp_hidden_dim, drop=drop)

    def forward(self, x):
        x = x + self.attn(x)
        x = x + self.mlp(x)
        return x


# ============================================================================
# Spiking Patch Embedding (with PLIF)
# ============================================================================

class SPS(BaseModule):
    """Spiking Patch Splitting with progressive spatial reduction and PLIF neurons."""

    def __init__(self, step=10, encode_type='direct', patch_size=4,
                 in_channels=2, embed_dims=256):
        super().__init__(step=step, encode_type=encode_type)
        patch_size = to_2tuple(patch_size)
        self.patch_size = patch_size
        self.C = in_channels

        self.proj_conv = nn.Conv2d(in_channels, embed_dims // 8, kernel_size=3, stride=1, padding=1, bias=False)
        self.proj_bn = nn.BatchNorm2d(embed_dims // 8)
        self.proj_lif = PLIFNode(step=step, init_tau=2.0)
        self.maxpool = nn.MaxPool2d(kernel_size=3, stride=2, padding=1, dilation=1, ceil_mode=False)

        self.proj_conv1 = nn.Conv2d(embed_dims // 8, embed_dims // 4, kernel_size=3, stride=1, padding=1, bias=False)
        self.proj_bn1 = nn.BatchNorm2d(embed_dims // 4)
        self.proj_lif1 = PLIFNode(step=step, init_tau=2.0)
        self.maxpool1 = nn.MaxPool2d(kernel_size=3, stride=2, padding=1, dilation=1, ceil_mode=False)

        self.proj_conv2 = nn.Conv2d(embed_dims // 4, embed_dims // 2, kernel_size=3, stride=1, padding=1, bias=False)
        self.proj_bn2 = nn.BatchNorm2d(embed_dims // 2)
        self.proj_lif2 = PLIFNode(step=step, init_tau=2.0)
        self.maxpool2 = nn.MaxPool2d(kernel_size=3, stride=2, padding=1, dilation=1, ceil_mode=False)

        self.proj_conv3 = nn.Conv2d(embed_dims // 2, embed_dims, kernel_size=3, stride=1, padding=1, bias=False)
        self.proj_bn3 = nn.BatchNorm2d(embed_dims)
        self.proj_lif3 = PLIFNode(step=step, init_tau=2.0)
        self.maxpool3 = nn.MaxPool2d(kernel_size=3, stride=2, padding=1, dilation=1, ceil_mode=False)

        self.rpe_conv = nn.Conv2d(embed_dims, embed_dims, kernel_size=3, stride=1, padding=1, bias=False)
        self.rpe_bn = nn.BatchNorm2d(embed_dims)
        self.rpe_lif = PLIFNode(step=step, init_tau=2.0)

    def forward(self, x):
        self.reset()
        T, B, C, H, W = x.shape

        x = self.proj_conv(x.flatten(0, 1))
        x = self.proj_bn(x).reshape(T, B, -1, H, W).contiguous()
        x = self.proj_lif(x.flatten(0, 1)).contiguous()
        x = self.maxpool(x)

        x = self.proj_conv1(x)
        x = self.proj_bn1(x).reshape(T, B, -1, H // 2, W // 2).contiguous()
        x = self.proj_lif1(x.flatten(0, 1)).contiguous()
        x = self.maxpool1(x)

        x = self.proj_conv2(x)
        x = self.proj_bn2(x).reshape(T, B, -1, H // 4, W // 4).contiguous()
        x = self.proj_lif2(x.flatten(0, 1)).contiguous()
        x = self.maxpool2(x)

        x = self.proj_conv3(x)
        x = self.proj_bn3(x).reshape(T, B, -1, H // 8, W // 8).contiguous()
        x = self.proj_lif3(x.flatten(0, 1)).contiguous()
        x = self.maxpool3(x)

        x_rpe = self.rpe_bn(self.rpe_conv(x)).reshape(T, B, -1, H // 16, W // 16).contiguous()
        x_rpe = self.rpe_lif(x_rpe.flatten(0, 1)).contiguous()
        x = x + x_rpe
        x = x.reshape(T, B, -1, (H // 16) * (W // 16)).contiguous()

        return x  # T B C N


# ============================================================================
# Main Model: HouyiB 3D
# ============================================================================

class HouyiB3D(nn.Module):
    """
    HouyiB 3D — Physics-Aware SNN for Solar Flare Forecasting (2D Spatial).

    Key innovation: PLIFNode with learnable time constant τ for multi-scale
    temporal adaptation to both slow flux emergence and fast reconnection.

    Input:  (B, T, C, H, W)   – DataLoader batch-first format
    Output: (B, num_classes)
    """

    def __init__(self, step=10,
                 patch_size=4, in_channels=2, num_classes=10,
                 embed_dims=256, num_heads=16, mlp_ratios=4,
                 qkv_bias=False, qk_scale=None,
                 drop_rate=0., attn_drop_rate=0., drop_path_rate=0.,
                 norm_layer=nn.LayerNorm, depths=2, sr_ratios=4,
                 **kwargs):
        super().__init__()
        self.step = step
        self.num_classes = num_classes
        self.depths = depths

        dpr = [x.item() for x in torch.linspace(0, drop_path_rate, depths)]

        self.patch_embed = SPS(
            step=step, patch_size=patch_size,
            in_channels=in_channels, embed_dims=embed_dims,
        )

        self.block = nn.ModuleList([
            Block(step=step, dim=embed_dims, num_heads=num_heads,
                  mlp_ratio=mlp_ratios, qkv_bias=qkv_bias, qk_scale=qk_scale,
                  drop=drop_rate, attn_drop=attn_drop_rate, drop_path=dpr[j],
                  norm_layer=norm_layer, sr_ratio=sr_ratios)
            for j in range(depths)
        ])

        self.head = nn.Linear(embed_dims, num_classes) if num_classes > 0 else nn.Identity()
        self.apply(self._init_weights)

    @staticmethod
    def _init_weights(m):
        if isinstance(m, nn.Linear):
            trunc_normal_(m.weight, std=.02)
            if m.bias is not None:
                nn.init.constant_(m.bias, 0)
        elif isinstance(m, nn.LayerNorm):
            nn.init.constant_(m.bias, 0)
            nn.init.constant_(m.weight, 1.0)

    def forward_features(self, x):
        """x: (T, B, C, H, W) → (T, B, embed_dims)"""
        x = self.patch_embed(x)        # T B C N
        for blk in self.block:
            x = blk(x)
        return x.mean(3)               # T B C

    def forward(self, x):
        """
        Args:
            x: (B, T, C, H, W) – DataLoader batch-first
        Returns:
            (B, num_classes)
        """
        x = x.float()
        # (B, T, C, H, W) → (T, B, C, H, W)
        x = x.permute(1, 0, 2, 3, 4).contiguous()
        x = self.forward_features(x)
        x = self.head(x.mean(0))       # (B, num_classes)
        return x


# ============================================================================
# Pre-defined size configurations & factory
# ============================================================================

MODEL_SIZES = {
    'small': dict(
        step=8, patch_size=4, embed_dims=128, num_heads=8,
        mlp_ratios=4, in_channels=6, num_classes=4,
        qkv_bias=False, depths=2, sr_ratios=1,
    ),
    'medium': dict(
        step=8, patch_size=4, embed_dims=256, num_heads=16,
        mlp_ratios=4, in_channels=6, num_classes=4,
        qkv_bias=False, depths=2, sr_ratios=1,
    ),
    'large': dict(
        step=8, patch_size=4, embed_dims=512, num_heads=16,
        mlp_ratios=4, in_channels=6, num_classes=4,
        qkv_bias=False, depths=4, sr_ratios=1,
    ),
}


def build_model(size: str = 'medium', **kwargs) -> HouyiB3D:
    """
    Build a pre-configured HouyiB3D.

    Args:
        size:     'small' | 'medium' | 'large'
        **kwargs: Override any configuration key.

    Examples::

        # Default temporal-diff (6ch)
        model = build_model('medium', in_channels=6, num_classes=4)

        # PIEE (12ch)
        model = build_model('medium', in_channels=12, num_classes=4)
    """
    if size not in MODEL_SIZES:
        raise ValueError(f"size must be one of {list(MODEL_SIZES)}, got '{size}'")
    cfg = {**MODEL_SIZES[size], **kwargs}
    return HouyiB3D(**cfg)
