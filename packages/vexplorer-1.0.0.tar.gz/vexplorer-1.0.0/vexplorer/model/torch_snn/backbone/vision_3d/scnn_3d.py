# https://github.com/Brain-Cog-Lab/N-Omniglot/blob/main/examples/CSNN/learner.py


import torch
import torch.nn as nn
import torch.nn.functional as F


thresh = 0.5  # neuronal threshold
lens = 0.5  # hyper-parameters of approximate function
decay = 0.2  # decay constants


class SurrGradSpike(torch.autograd.Function):
    """
    Here we implement our spiking nonlinearity which also implements
    the surrogate gradient. By subclassing torch.autograd.Function,
    we will be able to use all of PyTorch's autograd functionality.
    Here we use the normalized negative part of a fast sigmoid
    as this was done in Zenke & Ganguli (2018).
    """

    scale = 100.0  # controls steepness of surrogate gradient

    @staticmethod
    def forward(ctx, input):
        """
        In the forward pass we compute a step function of the input Tensor
        and return it. ctx is a context object that we use to stash information which
        we need to later backpropagate our error signals. To achieve this we use the
        ctx.save_for_backward method.
        """
        ctx.save_for_backward(input)
        out = torch.zeros_like(input)
        out[input > 0] = 1.0
        return out

    @staticmethod
    def backward(ctx, grad_output):
        """
        In the backward pass we receive a Tensor we need to compute the
        surrogate gradient of the loss with respect to the input.
        Here we use the normalized negative part of a fast sigmoid
        as this was done in Zenke & Ganguli (2018).
        """
        input, = ctx.saved_tensors
        grad_input = grad_output.clone()
        grad = grad_input / (SurrGradSpike.scale * torch.abs(input) + 1.0) ** 2
        return grad


# here we overwrite our naive spike function by the "SurrGradSpike" nonlinearity which implements a surrogate gradient
spike_fn = SurrGradSpike.apply


# define approximate firing function
class ActFun(torch.autograd.Function):

    @staticmethod
    def forward(ctx, input):
        ctx.save_for_backward(input)
        return input.gt(thresh).float()

    @staticmethod
    def backward(ctx, grad_output):
        input, = ctx.saved_tensors
        grad_input = grad_output.clone()
        temp = abs(input - thresh) < lens
        return grad_input * temp.float()


act_fun = ActFun.apply


# membrane potential update

# Dacay learning_rate
def lr_scheduler(optimizer, epoch, init_lr=0.1, lr_decay_epoch=50):
    """Decay learning rate by a factor of 0.1 every lr_decay_epoch epochs."""
    if epoch % lr_decay_epoch == 0 and epoch > 1:
        for param_group in optimizer.param_groups:
            param_group['lr'] = param_group['lr'] * 0.1
    return optimizer


class LIFConv(nn.Module):
    def __init__(self,
                 in_planes,
                 out_planes,
                 kernel_size,
                 stride,
                 padding,
                 decay=0.2

                 ):
        super().__init__()
        self.conv = nn.Conv2d(in_planes, out_planes, kernel_size=kernel_size, stride=stride, padding=padding)
        self.mem = self.spike = None
        self.decay = decay

    def mem_update(self, x):
        if self.mem is None:
            self.mem = torch.zeros_like(x, device=x.device)
            self.spike = torch.zeros_like(x, device=x.device)

        self.mem = self.mem * self.decay * (1. - self.spike) + x
        self.spike = act_fun(self.mem)  # act_fun : approximation firing function
        return self.spike

    def forward(self, x):
        x = self.conv(x)
        x = self.mem_update(x)
        return x

    def reset(self):
        self.mem = self.spike = None


class LIFLinear(nn.Module):
    def __init__(self, in_planes, out_planes, decay=0.2, last_layer=False):
        super().__init__()
        self.fc = nn.Linear(in_planes, out_planes)
        self.mem = self.spike = None
        self.decay = decay
        self.last_layer = last_layer

    def mem_update(self, x):
        if self.mem is None:
            self.mem = torch.zeros_like(x, device=x.device)
            self.spike = torch.zeros_like(x, device=x.device)
        if self.last_layer:
            self.mem = self.mem + x
        else:
            self.mem = self.mem * self.decay * (1. - self.spike) + x
            self.spike = act_fun(self.mem)  # act_fun : approximation firing function
        return self.spike

    def forward(self, x):
        x = self.fc(x)
        x = self.mem_update(x)
        return x

    def reset(self):
        self.mem = self.spike = None


class SCNN3D(nn.Module):
    """
    3D Spiking Convolutional Neural Network for spatiotemporal data.

    **Input Format:**
    - **Mainstream format (batch-first)**: (B, T, C, H, W)
      - B: Batch size
      - T: Time steps
      - C: Input channels (typically 2 for DVS events)
      - H, W: Height, Width

    **Design Notes on pool_size selection:**
    After two Conv(5x5) + AvgPool(2x2), the spatial size becomes approximately:
        out_size ≈ (H - 8) // 4   [since each conv reduces by 4, then /2 twice]

    For common input sizes, we recommend:
        - H=W=32~64   → pool_size=(4,4)
        - H=W=64~256  → pool_size=(8,8)  ← DEFAULT (covers N-Omniglot, DVS128, etc.)
        - H=W>256     → pool_size=(10,10) or (12,12)

    **Output Format:**
    - (B, num_classes): Classification logits averaged over time

    **Performance Notes:**
    - This version supports dynamic input sizes (no fixed H/W in __init__)
    - Uses adaptive pooling to handle varying spatial dimensions
    - Faster computation with fewer hardcoded size checks
    """
    def __init__(
            self,
            output_class,
            input_channel=2,
            need_last_layer=True,
            pool_size=(8, 8),
            fc1_hidden=300,
            **kwargs):
        super(SCNN3D, self).__init__()
        # Remove fixed H, W parameters - now supports dynamic input sizes
        self.conv1 = LIFConv(in_planes=input_channel, out_planes=15, kernel_size=5, stride=1, padding=0)
        self.conv2 = LIFConv(in_planes=15, out_planes=40, kernel_size=5, stride=1, padding=0)

        # Use adaptive pooling to get fixed feature size regardless of input dimensions
        # After conv1 + pool + conv2 + pool, we use adaptive pooling to get 8x8 features
        # self.adaptive_pool = nn.AdaptiveAvgPool2d((8, 8))
        # Adaptive pooling: enables support for arbitrary input resolutions
        self.adaptive_pool = nn.AdaptiveAvgPool2d(pool_size)

        # Fixed feature size after adaptive pooling
        # self.fc1_in_features = 40 * 8 * 8  # 40 channels * 8 * 8 = 2560

        # Compute flattened feature dimension after adaptive pooling
        if isinstance(pool_size, int):
            h_pool = w_pool = pool_size
        else:
            h_pool, w_pool = pool_size
        self.fc1_in_features = 40 * h_pool * w_pool  # e.g., 40*8*8 = 2560

        self.fc1 = LIFLinear(in_planes=self.fc1_in_features, out_planes=fc1_hidden)
        self.fc2 = LIFLinear(in_planes=fc1_hidden, out_planes=output_class, decay=0.2, last_layer=need_last_layer)
        self.need_last_layer = need_last_layer


    def forward(self, input):
        """
        Forward pass with dynamic input size support.

        Args:
            input: Shape (B, T, C, H, W) - Batch, Time, Channel, Height, Width

        Returns:
            outputs: Shape (B, num_classes) - Classification logits
        """
        for step in range(input.shape[1]):  # simulation time steps
            x = input[:, step]
            x = self.conv1(x.float())
            x = F.avg_pool2d(x, 2)

            x = self.conv2(x)
            x = F.avg_pool2d(x, 2)

            # Use adaptive pooling to support any input size
            x = self.adaptive_pool(x)

            x = x.view(input.shape[0], -1)
            x = self.fc1(x)
            x = self.fc2(x)

        # Average membrane potential across time steps
        if self.need_last_layer:
            outputs = self.fc2.mem / input.shape[1]
        else:
            outputs = x

        self.reset()
        return outputs

    def reset(self):
        for i in self.children():
            if hasattr(i, 'reset'):
                i.reset()


# ============================================================================
# Model Size Configurations
# ============================================================================

MODEL_SIZES = {
    'small': {
        'output_class': 10,
        'input_channel': 2,
        'need_last_layer': True,
    },
    'medium': {
        'output_class': 10,
        'input_channel': 2,
        'need_last_layer': True,
    },
    'large': {
        'output_class': 10,
        'input_channel': 2,
        'need_last_layer': True,
    }
}


def build_model(size='medium', **kwargs):
    """
    Build SCNN 3D model with specified size configuration.

    Note: All sizes use the same architecture. Size parameter is provided
    for API consistency with other models.

    Args:
        size: Model size ('small', 'medium', 'large') - all use same architecture
        **kwargs: Additional parameters that override the size configuration

    Returns:
        Initialized model

    Examples:
        >>> # Build medium model
        >>> model = build_model(size='medium', output_class=10)

        >>> # Build with custom parameters
        >>> model = build_model(size='large', output_class=100, input_channel=3)
    """
    if size not in MODEL_SIZES:
        raise ValueError(f"Size must be 'small', 'medium', or 'large', got '{size}'")

    config = MODEL_SIZES[size].copy()
    config.update(kwargs)

    return SCNN3D(**config)


