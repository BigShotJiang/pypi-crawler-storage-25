# -*- coding: utf-8 -*-
import shutil
import logging
import json
import time
import os
from pathlib import Path
from typing import Any, Union, Literal, Optional, List
import yaml

from ..base import BaseTrainerCallback

logger = logging.getLogger(__name__)

class CodeBackup(BaseTrainerCallback):
    """
    Backs up the codebase and training configurations at specific training stages.

    This callback ensures that the exact state of the code and configuration used for a
    specific run is preserved. It supports dynamic hook binding, allowing users to
    trigger backups at any valid trainer lifecycle event (e.g., 'on_begin').

    Args:
        code_raw_dir (str or Path, optional): Path to the source code to be backed up.
        code_backup_dir (str or Path, optional): Base directory where code backups will be stored.
        config_backup_dir (str or Path, optional): Base directory where config files will be stored.
        config_backup_type (str, optional): Format of the config backup.
            Options: "yaml", "json", "txt". Defaults to "yaml".
        backup_time (str, optional): The trainer hook that triggers the backup.
            Defaults to "on_begin".
        use_timestamp (bool, optional): Whether to append a timestamp to backup folders/files.
            Defaults to True.
        file_mode (str, optional): File opening mode for config backup.
            "w" to overwrite, "a+" to append. Defaults to "w".
        ignore_patterns (List[str], optional): List of glob-style patterns to ignore
            during code backup. Defaults to standard Python/Git ignore patterns.

    Examples:
        >>> callback = CodeBackup(
        ...     code_raw_dir="./src",
        ...     code_backup_dir="./backups/code",
        ...     config_backup_dir="./backups/config",
        ...     backup_time="on_begin"
        ... )
    """

    def __init__(self,
                 code_raw_dir: Optional[Union[str, Path]] = None,
                 code_backup_dir: Optional[Union[str, Path]] = None,
                 config_backup_dir: Optional[Union[str, Path]] = None,
                 config_backup_type: Literal["yaml", "json", "txt"] = "yaml",
                 backup_time: str = "on_begin",
                 use_timestamp: bool = True,
                 file_mode: Literal["w", "a+"] = "w",
                 ignore_patterns: Optional[List[str]] = None,
                 **kwargs):
        super().__init__(**kwargs)

        # Initialize basic attributes
        self.use_timestamp = use_timestamp
        self.file_mode = file_mode
        self.config_backup_type = config_backup_type.lower()

        # Path processing
        self.code_raw_dir = Path(code_raw_dir) if code_raw_dir else None
        self.base_code_backup_dir = Path(code_backup_dir) if code_backup_dir else None
        self.base_config_backup_dir = Path(config_backup_dir) if config_backup_dir else None

        # Setup ignore patterns for shutil.copytree
        self.ignore_patterns = ignore_patterns or [ "__pycache__", "*.pyc", ".git", ".ipynb_checkpoints", "*.log" ]

        # --- Validation ---
        if self.code_raw_dir and not self.code_raw_dir.exists():
            raise FileNotFoundError(f"Source code directory '{self.code_raw_dir}' does not exist.")

        # Pre-create base directories to ensure runtime stability
        for d in [self.base_code_backup_dir, self.base_config_backup_dir]:
            if d:
                d.mkdir(parents=True, exist_ok=True)

        # --- Dynamic Hook Binding ---
        # We bind the '_run_backup' logic to the hook specified by 'backup_time'.
        # This allows the Manager to detect the implementation via getattr(instance, hook).
        if hasattr(self, backup_time):
            setattr(self, backup_time, self._run_backup)
            logger.info(f"Initialized CodeBackup: Hook '{backup_time}' will trigger the backup.")
        else:
            logger.warning(f"Specified backup_time '{backup_time}' is not a valid hook in this trainer.")

    def _run_backup(self, run_context: Any) -> None:
        """
        Internal execution logic. This is dynamically bound to a specific hook.

        Args:
            run_context: An object representing the current state of the trainer,
                        expected to have 'original_args().config'.
        """
        # Generate a synchronized timestamp for this backup event
        ts = f"_{time.strftime('%Y%m%d_%H%M%S')}" if self.use_timestamp else ""

        try:
            # 1. Execute Configuration Backup
            if self.base_config_backup_dir:
                cfg_filename = f"backup_config{ts}.{self.config_backup_type}"
                self._save_config(run_context, self.base_config_backup_dir / cfg_filename)

            # 2. Execute Source Code Backup
            if self.code_raw_dir and self.base_code_backup_dir:
                # Target: backup_dir/backup_srcName_timestamp
                folder_name = f"backup_{self.code_raw_dir.name}{ts}"
                self._copy_code(self.base_code_backup_dir / folder_name)

        except Exception as e:
            logger.error(f"Failed to execute CodeBackup: {str(e)}", exc_info=True)

    def _save_config(self, run_context: Any, save_path: Path) -> None:
        """
        Serializes and writes the config object to the specified path.
        """
        # Attempt to retrieve config from the trainer's context
        args_func = getattr(run_context, "original_args", None)
        args = args_func() if args_func else None
        config_obj = getattr(args, "config", None) if args else None

        if config_obj is None:
            logger.debug("No configuration object found in run_context; skipping config backup.")
            return

        # Write config based on the specified format and mode
        with open(save_path, self.file_mode, encoding="utf-8") as f:
            if self.config_backup_type == "json":
                data = config_obj if isinstance(config_obj, dict) else vars(config_obj)
                json.dump(data, f, indent=4, ensure_all_ascii=False)
            elif self.config_backup_type == "yaml":
                try:
                    data = config_obj if isinstance(config_obj, dict) else vars(config_obj)
                    yaml.dump(data, f, allow_unicode=True, sort_keys=False, default_style='"', default_flow_style=False)
                except ImportError:
                    # Fallback to text if PyYAML is missing
                    f.write(str(config_obj))
            else:
                f.write(str(config_obj))

        logger.info(f"Config backup saved to: {save_path} (mode: {self.file_mode})")

    def _copy_code(self, target_path: Path) -> None:
        """
        Recursively copies the source code directory, skipping ignored patterns.
        """
        # shutil.copytree performs the copy; dirs_exist_ok=True allows overwriting
        # if the same directory is targeted multiple times.
        shutil.copytree(
            self.code_raw_dir,
            target_path,
            ignore=shutil.ignore_patterns(*self.ignore_patterns),
            dirs_exist_ok=True
        )
        logger.info(f"Codebase backup completed: {target_path}")



