# -*- coding: utf-8 -*-
import time
import logging
import os
from pathlib import Path
from typing import Any, Union

from ..base import BaseTrainerCallback

logger = logging.getLogger(__name__)


class FileFlagWatch(BaseTrainerCallback):
    """Callback that monitors a specific file to control the training lifecycle.

    This callback creates a flag file at the start of training. It checks for the
    existence of this file at the end of every epoch. If the file is deleted
    externally (e.g., by a user or a scheduler script), the training will be
    requested to stop gracefully.

    This is particularly useful for manually stopping long-running training jobs
    on clusters without forcefully killing the process (which might corrupt checkpoints).

    Args:
        flag_path (str | Path): The path to the flag file. The parent directory 
            will be created automatically if it does not exist.
        **kwargs: Additional arguments passed to the base Callback.

    Example:
        >>> # In your config or code
        >>> callback = FileFlagWatch(flag_path="work_dirs/exp_001/running.flag")
        >>> # To stop training gracefully, run in shell:
        >>> # rm work_dirs/exp_001/running.flag
    """

    def __init__(self, flag_path: Union[str, Path],end_remove=False, **kwargs):
        super().__init__(**kwargs)
        self.flag_path = Path(flag_path)
        self.end_remove = end_remove

    def _initialize_flag(self) -> None:
        """Creates or overwrites the flag file with a startup message."""
        try:
            # Ensure the parent directory exists
            if not self.flag_path.parent.exists():
                self.flag_path.parent.mkdir(parents=True, exist_ok=True)

            current_time = time.strftime("%Y-%m-%d %H:%M:%S", time.localtime())
            content = (
                f"Training Started: {current_time}\n"
                f"Process ID: {os.getpid()}\n"
                "Action: Remove this file to trigger a graceful stop at the end of the current epoch."
            )

            with open(self.flag_path, "a+", encoding="utf-8") as f:
                f.write(content)

            logger.info(f"[FileFlagWatch] Flag file created at: {self.flag_path}")
            logger.info("[FileFlagWatch] Delete this file to stop training gracefully.")

        except OSError as e:
            logger.error(f"[FileFlagWatch] Failed to create flag file at {self.flag_path}. Error: {e}")
            raise e

    def on_begin(self, run_context: Any) -> None:
        if os.path.exists(self.flag_path):
            logger.info(f"[FileFlagWatch] Flag file {self.flag_path} already exists.")
        else:
            logger.info(f"[FileFlagWatch] Creating flag file {self.flag_path}.")
            self._initialize_flag()

    def on_end(self, run_context: Any) -> None:
        if os.path.exists(self.flag_path):
            try:

                content = (
                    f"\nTraining Finished: {time.strftime('%Y-%m-%d %H:%M:%S', time.localtime())}\n"
                    f"Process ID: {os.getpid()}\n"
                )
                with open(self.flag_path, "a+", encoding="utf-8") as f:
                    f.write(content)
                if self.end_remove:
                    os.remove(self.flag_path)
            except OSError as e:
                logger.warning(f"[FileFlagWatch] Failed to edit or remove flag file {self.flag_path}. Error: {e}")
        else:
            logger.info(f"[FileFlagWatch] Creating flag file {self.flag_path}.")
            self._initialize_flag()

    def on_train_epoch_end(self, run_context: Any) -> None:
        """Checks if the flag file exists at the end of an epoch.

        Args:
            run_context (Runner): The runner context providing access to training state
                and the `request_stop` method.

        """

        if not self.flag_path.exists():
            logger.warning(
                f"[FileFlagWatch] Flag file missing: {self.flag_path}. "
                "Requesting training stop..."
            )
            # if hasattr(run_context, 'original_args'):
            #     _ = run_context.original_args()
            run_context.request_stop()
        else:
            logger.debug(f"[FileFlagWatch] Flag file exists. Training continues.")







