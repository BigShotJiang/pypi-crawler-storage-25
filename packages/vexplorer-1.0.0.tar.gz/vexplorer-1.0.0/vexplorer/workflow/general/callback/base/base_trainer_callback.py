

# from typing import Any as RunContext

from ...run.context.base import  BaseRunContext as RunContext


class BaseTrainerCallback:
    r"""
    Base class for all callbacks.

    A callback is a self-contained program that can be reused across projects.
    It has access to the training state via :class:`RunContext` and can intervene 
    at specific points (hooks) during the training or evaluation execution.

    To create a custom callback, subclass this class and override any of the 
    methods below.

    Args:
        run_context (RunContext): The context object containing the current 
            state of the trainer (model, optimizer, epoch, batch data, etc.).

    Examples::

        >>> class PrintEpochCallback(BaseTrainerCallback):
        ...     def on_train_epoch_begin(self, run_context):
        ...         print(f"Starting epoch {run_context.cur_epoch_num}")
        ...
        ...     def on_train_epoch_end(self, run_context):
        ...         print(f"Finished epoch {run_context.cur_epoch_num}")

    .. note::
        All methods in this base class are no-ops (they do nothing) and are 
        meant to be overridden.
    """

    def on_begin(self, run_context: RunContext) -> None:
        """
        Called at the very beginning of the all process.

        This hook is triggered before the main run, usually use for
        setup and initialization.

        Args:
            run_context (RunContext): The current training context.
        """
        pass

    def on_end(self, run_context: RunContext) -> None:
        """
        Called at the very end of the all process.

        This hook is triggered before the exit run, usually use for
        finish checking or clean up.

        Args:
            run_context (RunContext): The current training context.
        """
        pass

    # --------------------------------------------------------------------------
    # Training Hooks
    # --------------------------------------------------------------------------

    def on_train_begin(self, run_context: RunContext) -> None:
        """
        Called at the very beginning of the training process.

        This hook is triggered before the training loop starts, usually after 
        setup and initialization.

        Args:
            run_context (RunContext): The current training context.
        """
        pass

    def on_train_end(self, run_context: RunContext) -> None:
        """
        Called at the very end of the training process.

        This hook is triggered after all epochs and steps are completed, 
        or after an early stop interruption.

        Args:
            run_context (RunContext): The current training context.
        """
        pass

    def on_train_epoch_begin(self, run_context: RunContext) -> None:
        """
        Called at the beginning of each training epoch.

        Args:
            run_context (RunContext): The current training context.
        """
        pass

    def on_train_epoch_end(self, run_context: RunContext) -> None:
        """
        Called at the end of each training epoch.

        This is a good place to aggregate epoch-level metrics or save checkpoints.

        Args:
            run_context (RunContext): The current training context.
        """
        pass

    def on_train_step_begin(self, run_context: RunContext) -> None:
        """
        Called at the beginning of each training step (batch).

        Args:
            run_context (RunContext): The current training context.
        """
        pass

    def on_train_step_end(self, run_context: RunContext) -> None:
        """
        Called at the end of each training step (batch).

        This is typically triggered after the forward pass, backward pass, 
        and optimizer step.

        Args:
            run_context (RunContext): The current training context.
        """
        pass

    # --------------------------------------------------------------------------
    # Evaluation Hooks
    # --------------------------------------------------------------------------

    def on_eval_begin(self, run_context: RunContext) -> None:
        """
        Called at the beginning of the evaluation (validation/test) process.

        Args:
            run_context (RunContext): The current training context.
        """
        pass

    def on_eval_end(self, run_context: RunContext) -> None:
        """
        Called at the end of the evaluation (validation/test) process.

        Args:
            run_context (RunContext): The current training context.
        """
        pass

    def on_eval_epoch_begin(self, run_context: RunContext) -> None:
        """
        Called at the beginning of an evaluation epoch.
        
        Note:
            Even if evaluation typically runs for a single 'pass' (one epoch),
            this hook preserves consistency with the training loop structure.

        Args:
            run_context (RunContext): The current training context.
        """
        pass

    def on_eval_epoch_end(self, run_context: RunContext) -> None:
        """
        Called at the end of an evaluation epoch.

        Args:
            run_context (RunContext): The current training context.
        """
        pass

    def on_eval_step_begin(self, run_context: RunContext) -> None:
        """
        Called at the beginning of each evaluation step (batch).

        Args:
            run_context (RunContext): The current training context.
        """
        pass

    def on_eval_step_end(self, run_context: RunContext) -> None:
        """
        Called at the end of each evaluation step (batch).

        Args:
            run_context (RunContext): The current training context.
        """
        pass