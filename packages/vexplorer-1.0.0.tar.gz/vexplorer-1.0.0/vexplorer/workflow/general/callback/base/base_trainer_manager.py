# -*- coding: utf-8 -*-
import logging
from collections import defaultdict
from typing import List, Optional, Any, Dict

from .base_trainer_callback import BaseTrainerCallback

logger = logging.getLogger(__name__)

class BaseTrainerCallbackManager(BaseTrainerCallback):
    """
    [Core] A high-performance manager that orchestrates the execution of multiple callbacks.

    This class acts as a proxy that delegates hook calls to a list of registered callbacks.

    **Optimization Strategy:**
    Instead of iterating through all callbacks for every hook (which is slow if callbacks
    only implement a few methods), this manager analyzes the callback classes at
    initialization time. It builds an ``_execution_plan`` mapping each hook name to
    the subset of callbacks that actually override that method.

    This results in **zero-overhead** calls for empty base methods during tight loops
    (e.g., ``on_train_step_end``).

    Args:
        callbacks (List[BaseTrainerCallback], optional): Initial list of callbacks to register.
            Defaults to None.

    Attributes:
        callbacks (List[BaseTrainerCallback]): The list of currently registered callbacks.

    Example:
        >>> # Define a custom callback
        >>> class MyLogger(BaseTrainerCallback):
        ...     def on_train_begin(self, rc):
        ...         print("Training started!")
        ...
        >>> # Initialize manager
        >>> manager = BaseTrainerCallbackManager(callbacks=[MyLogger()])
        >>> # Trigger hook (rc is the RunContext/State object)
        >>> manager.on_train_begin(rc={"epoch": 0})
        Training started!
    """

    # Registry of supported hook names
    _HOOK_NAMES: List[str] = [
        'on_begin', 'on_end',
        'on_train_begin', 'on_train_end',
        'on_train_epoch_begin', 'on_train_epoch_end',
        'on_train_step_begin', 'on_train_step_end',
        'on_eval_begin', 'on_eval_end',
        'on_eval_epoch_begin', 'on_eval_epoch_end',
        'on_eval_step_begin', 'on_eval_step_end'
    ]

    def __init__(self, callbacks: Optional[List[BaseTrainerCallback]] = None) -> None:
        self.callbacks: List[BaseTrainerCallback] = []
        # Mapping from hook_name to list of callbacks that actually implement it
        self._execution_plan: Dict[str, List[BaseTrainerCallback]] = defaultdict(list)

        if callbacks:
            self.register_callbacks(callbacks, append=True)

    def add_callback(self,name, callback: BaseTrainerCallback, build = False) -> None:
        if not isinstance(callback, BaseTrainerCallback):
            raise TypeError(f"Callback {name}: {callback} must be a subclass of BaseTrainerCallback")
        self.callbacks.append(callback)
        if build:
            self._build_plan()

    def build(self):
        self._build_plan()

    def register_callbacks(self, callbacks: List[BaseTrainerCallback], append: bool = True) -> None:
        """
        Dynamically registers new callbacks and rebuilds the execution plan.

        Args:
            callbacks (List[BaseTrainerCallback]): List of callback instances to register.
            append (bool): If ``True``, appends new callbacks to the existing list.
                If ``False``, replaces the existing list entirely.

        Raises:
            TypeError: If any item in ``callbacks`` is not an instance of :class:`BaseTrainerCallback`.
        """
        # Validate types strict
        for i, cb in enumerate(callbacks):
            if not isinstance(cb, BaseTrainerCallback):
                raise TypeError(f"Expected instance of BaseTrainerCallback at index {i}, got {type(cb).__name__}")

        if append:
            self.callbacks.extend(callbacks)
        else:
            self.callbacks = callbacks

        # Rebuild the optimization plan whenever the list changes
        self._build_plan()
        logger.debug(f"[BaseTrainerCallbackManager] Plan rebuilt with {len(self.callbacks)} callbacks.")

    def _build_plan_only_static(self) -> None:
        """
        Analyzes registered callbacks to create an optimized execution plan.

        Reflection Logic:
            Check which methods are overridden in the subclass vs the base BaseTrainerCallback class.
            Only overridden methods are added to the execution plan list for that hook.
        """
        self._execution_plan.clear()

        for hook in self._HOOK_NAMES:
            for cb in self.callbacks:
                # Get the method from the instance's class (Subclass)
                cb_method = getattr(type(cb), hook)
                # Get the default method from the base BaseTrainerCallback class (Base)
                base_method = getattr(BaseTrainerCallback, hook)

                # If the function objects are different, the subclass has overridden it.
                if cb_method is not base_method:
                    self._execution_plan[hook].append(cb)

    def _build_plan(self) -> None:
        """
        Analyzes registered callbacks to create an optimized execution plan.

        Refined logic:
        1. Checks if the instance (cb) has an implementation different from the base class.
        2. Handles both class-level overrides and instance-level dynamic binding (setattr).
        """
        self._execution_plan.clear()

        # 预先获取基类的原始方法引用，避免在循环中重复调用
        base_class_methods = {
            hook: getattr(BaseTrainerCallback, hook)
            for hook in self._HOOK_NAMES
        }

        for hook in self._HOOK_NAMES:
            base_method = base_class_methods[hook]

            for cb in self.callbacks:
                # 1. 从实例获取当前方法实现
                current_method = getattr(cb, hook, None)

                if current_method is None:
                    continue

                # 2. 提取底层函数对象
                # 如果是 bound method (实例方法)，获取其 __func__
                # 如果是普通的 function 或已经动态绑定的 function，直接使用
                actual_func = getattr(current_method, "__func__", current_method)

                # 3. 比较底层函数对象的内存地址
                # 如果地址不同，说明该方法被重写或被 setattr 覆盖了
                if actual_func is not base_method:
                    self._execution_plan[hook].append(cb)

        # 调试日志：可以看到哪些回调被分配到了哪些钩子
        for hook, cbs in self._execution_plan.items():
            logger.debug(f"Hook '{hook}' plan: {[type(cb).__name__ for cb in cbs]}")

    # =========================================================================
    # Proxy Methods (Fast Dispatch)
    # =========================================================================
    # Note: We use list comprehensions for speed in tight loops, as they compile
    # to optimized bytecode compared to standard for-loops in CPython.

    def on_begin(self, rc: Any) -> None:
        """Called at the beginning of the all process."""
        [cb.on_begin(rc) for cb in self._execution_plan['on_begin']]

    def on_end(self, rc: Any) -> None:
        """Called at the end of the all process."""
        [cb.on_end(rc) for cb in self._execution_plan['on_end']]

    def on_train_begin(self, rc: Any) -> None:
        """Called at the beginning of the training process."""
        [cb.on_train_begin(rc) for cb in self._execution_plan['on_train_begin']]

    def on_train_end(self, rc: Any) -> None:
        """Called at the end of the training process."""
        [cb.on_train_end(rc) for cb in self._execution_plan['on_train_end']]

    def on_train_epoch_begin(self, rc: Any) -> None:
        """Called at the beginning of each training epoch."""
        [cb.on_train_epoch_begin(rc) for cb in self._execution_plan['on_train_epoch_begin']]

    def on_train_epoch_end(self, rc: Any) -> None:
        """Called at the end of each training epoch."""
        [cb.on_train_epoch_end(rc) for cb in self._execution_plan['on_train_epoch_end']]

    def on_train_step_begin(self, rc: Any) -> None:
        """Called at the beginning of each training step."""
        [cb.on_train_step_begin(rc) for cb in self._execution_plan['on_train_step_begin']]

    def on_train_step_end(self, rc: Any) -> None:
        """Called at the end of each training step."""
        [cb.on_train_step_end(rc) for cb in self._execution_plan['on_train_step_end']]

    def on_eval_begin(self, rc: Any) -> None:
        """Called at the beginning of the evaluation process."""
        [cb.on_eval_begin(rc) for cb in self._execution_plan['on_eval_begin']]

    def on_eval_end(self, rc: Any) -> None:
        """Called at the end of the evaluation process."""
        [cb.on_eval_end(rc) for cb in self._execution_plan['on_eval_end']]

    def on_eval_epoch_begin(self, rc: Any) -> None:
        """Called at the beginning of each evaluation epoch."""
        [cb.on_eval_epoch_begin(rc) for cb in self._execution_plan['on_eval_epoch_begin']]

    def on_eval_epoch_end(self, rc: Any) -> None:
        """Called at the end of each evaluation epoch."""
        [cb.on_eval_epoch_end(rc) for cb in self._execution_plan['on_eval_epoch_end']]

    def on_eval_step_begin(self, rc: Any) -> None:
        """Called at the beginning of each evaluation step."""
        [cb.on_eval_step_begin(rc) for cb in self._execution_plan['on_eval_step_begin']]

    def on_eval_step_end(self, rc: Any) -> None:
        """Called at the end of each evaluation step."""
        [cb.on_eval_step_end(rc) for cb in self._execution_plan['on_eval_step_end']]


