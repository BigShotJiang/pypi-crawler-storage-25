# -*- coding: utf-8 -*-


from typing import Dict, Any, Optional, List, Union
from dataclasses import dataclass, field, asdict


@dataclass
class BaseRunArgs:
    """
    Container for training/evaluation state and hyperparameters.
    
    This class acts as a central registry for all variables accessible within 
    Callbacks. It separates static configuration from dynamic runtime state.

    """

    # ==========================================
    # 1. Static Configuration
    # ==========================================
    network: Any = None
    """The base neural network model."""

    engine: Any = None
    """The engine to use for training or evaluation."""

    train_network: Any = None
    """Network wrapped with Loss/Optimizer (if applicable)."""

    eval_network: Any = None
    """Network used for evaluation."""

    optimizer: Any = None
    """The optimizer instance."""

    loss_fn: Any = None
    """The loss function."""

    train_dataset: Any = None
    """The training dataloader or iterator."""

    valid_dataset: Any = None
    """The validation dataloader or iterator."""

    list_callback: List[Any] = field(default_factory=list)
    """List of active callbacks."""

    # ==========================================
    # 2. Hyperparameters & Environment
    # ==========================================
    mode: str = "train"
    """Current running mode ("train" or "eval")."""

    epoch_num: int = 0
    """Total number of epochs to run."""

    batch_num: int = 0
    """Total batches per training epoch."""

    batch_num_of_eval: int = 0
    """Total batches per evaluation epoch."""

    parallel_mode: str = "stand_alone"
    """Parallel mode configuration (e.g., 'stand_alone', 'data_parallel')."""

    device_number: int = 1
    """Number of devices (GPUs) used."""

    dataset_sink_mode: bool = False
    """Whether to use dataset sink mode (if supported by backend)."""

    # ==========================================
    # 3. Dynamic Runtime Status
    # ==========================================
    cur_epoch_num: int = 0
    """Current epoch index (1-based usually)."""

    cur_epoch_num_of_eval: int = 0
    """Current evaluation epoch index."""

    cur_step_num: int = 0
    """Current global step index."""

    cur_step_num_of_eval: int = 0
    """Current global evaluation step index."""

    # Current Data/Outputs
    train_dataset_element: Any = None
    """Input data of the current step (e.g., (x, y))."""

    eval_dataset_element: Any = None
    """Input data of the current evaluation step."""

    net_outputs: Any = None
    """Raw output from the network for the current step."""

    # Loss & Metrics
    train_loss: Any = None
    """Loss value of the current step."""

    eval_loss: Any = None
    """Loss value of the current evaluation step."""

    train_metrics: Dict[str, Any] = field(default_factory=dict)
    """Accumulated training metrics."""

    eval_metrics: Dict[str, Any] = field(default_factory=dict)
    """Accumulated evaluation metrics."""

    # ==========================================
    # 4. Checkpoint Management
    # ==========================================
    last_save_ckpt_step: int = 0
    """The step number when the last checkpoint was saved."""

    latest_ckpt_file: str = ""
    """The file path of the latest saved checkpoint."""

    # ==========================================
    # 5. Dynamic Extensions
    # ==========================================
    extras: Dict[str, Any] = field(default_factory=dict)
    """A reserved dictionary for user-defined dynamic variables."""

    def to_dict(self, safe: bool = True) -> Dict[str, Any]:
        """Converts the state to a dictionary.

        Args:
            safe (bool): If True, removes non-serializable or heavy objects
                (like nn.Module, Optimizer, Datasets) to allow for safe logging
                or printing. Defaults to True.

        Returns:
            Dict[str, Any]: A dictionary representation of the state.
        """
        data = asdict(self)
        if safe:
            # Filter out heavy objects that pollute logs
            keys_to_exclude = {
                'network', 'train_network', 'eval_network',
                'optimizer', 'loss_fn', 'train_dataset', 'valid_dataset',
                'list_callback', 'train_dataset_element', 'eval_dataset_element',
                'net_outputs'
            }
            return {k: v for k, v in data.items() if k not in keys_to_exclude}
        return data


class BaseRunContext:
    """
    Context manager that wraps `RunArgs` and provides flow control interfaces.

    It serves as the bridge between the training loop and callbacks. Callbacks
    receive this context to read state (`original_args`) or modify flow (`request_stop`).

    Args:
        original_args (RunArgs): The underlying state container.

    Example:
        >>> args = BaseRunArgs(epoch_num=10)
        >>> ctx = BaseRunContext(args)
        >>> ctx.request_stop()
        >>> print(ctx.get_stop_requested())
        True
    """
    def __init__(self, original_args: BaseRunArgs):
        self._original_args = original_args
        self._stop_requested = False

    def original_args(self) -> BaseRunArgs:
        """Returns the underlying state container.

        Returns:
            RunArgs: The mutable arguments object.
        """
        return self._original_args

    def request_stop(self) -> None:
        """Signals the training loop to stop execution at the next safe point."""
        self._stop_requested = True

    def get_stop_requested(self) -> bool:
        """Checks if a stop signal has been issued.

        Returns:
            bool: True if stop requested, False otherwise.
        """
        return self._stop_requested


