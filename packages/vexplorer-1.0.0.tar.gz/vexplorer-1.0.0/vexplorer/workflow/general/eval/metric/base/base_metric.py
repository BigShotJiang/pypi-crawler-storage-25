# -*- coding: utf-8 -*-
import numpy as np
from abc import ABC, abstractmethod
from typing import Dict, List, Tuple, Any, Union, Optional, Sequence, TypeVar

T = TypeVar("T", bound="BaseMetric")


class BaseMetric(ABC):
    """
    Base class for all metrics with flexible data routing and safe execution.

    This class defines the standard interface for metric computation (:meth:`clear`,
    :meth:`update`, :meth:`eval`). It implements a "middleware" mechanism in
    :meth:`update_with_indexes` to route specific data from complex model outputs
    directly to the metric's logic.

    The design is inspired by PyTorch Ignite and Catalyst, allowing decoupling of
    model output structure from metric calculation logic.

    Args:
        indexes (List[Union[int, str]], optional): Configured indexes or keys to extract
            data from the input.
            - If **int**: Extracts from a list/tuple by position.
            - If **str**: Extracts from a dict by key.
            Defaults to ``None``.
        auto_unpack (bool, optional): Controls input unpacking behavior.
            If ``True``, and the input to :meth:`update_with_indexes` is a single
            list, tuple, or dict, it will be unpacked before processing.
            Defaults to ``True``.
        **kwargs: Additional keyword arguments for future compatibility.

    Examples:
        **1. Basic Usage (Auto-unpacking)**

        >>> class Accuracy(BaseMetric):
        ...     def clear(self): pass
        ...     def eval(self): pass
        ...     def update(self, preds, target):
        ...         print(f"Preds: {preds}, Target: {target}")
        ...
        >>> metric = Accuracy()
        >>> # Automatically unpacks the list into preds and target
        >>> metric.update_with_indexes([1, 0])
        Preds: 1, Target: 0

        **2. Advanced Usage (Data Routing)**

        >>> # Scenario: Model returns a dict {'logits': ..., 'loss': ..., 'labels': ...}
        >>> # We only want 'logits' and 'labels' for the metric.
        >>> metric = Accuracy(indexes=['logits', 'labels'])
        >>> output = {'logits': 0.9, 'loss': 0.1, 'labels': 1}
        >>> metric.update_with_indexes(output)
        Preds: 0.9, Target: 1

    .. note::
        If ``indexes`` is ``None`` and the input is a dictionary, the dictionary
        keys must match the argument names of the subclass's :meth:`update` method
        exactly (via ``**kwargs`` unpacking).
    """

    def __init__(
            self,
            indexes: Optional[List[Union[int, str]]] = None,
            auto_unpack: bool = True,
            **kwargs: Any
    ) -> None:
        self._validate_indexes(indexes)
        # _indexes (List[Union[int, str]]): Internal storage for routing indexes.
        # _auto_unpack (bool): Internal flag for auto-unpacking.
        self._indexes = indexes
        self._auto_unpack = auto_unpack

    def _validate_indexes(self, indexes: Any) -> None:
        """
        Validates the type of indexes to prevent runtime extraction errors.
        """
        if indexes is not None:
            if not isinstance(indexes, (list, tuple)):
                raise TypeError(
                    f"`indexes` must be a list or tuple of ints/strs, "
                    f"got {type(indexes).__name__} instead."
                )

    @property
    def indexes(self) -> Optional[List[Union[int, str]]]:
        """
        Returns the configured indexes for data routing.

        Returns:
            Optional[List[Union[int, str]]]: The list of configured indexes.
        """
        return self._indexes

    def set_indexes(self: T, indexes: Optional[List[Union[int, str]]]) -> T:
        """
        Sets or updates the indexes for data routing (Chainable).

        Args:
            indexes (Optional[List[Union[int, str]]]): A list of integers (for sequence inputs)
                or strings (for dictionary inputs). Pass ``None`` to disable routing.

        Returns:
            T: Returns self (the specific subclass instance) to allow method chaining.

        Example:
            >>> metric = Accuracy().set_indexes(['pred', 'target'])
        """
        self._validate_indexes(indexes)
        self._indexes = indexes
        return self

    @abstractmethod
    def clear(self) -> None:
        """
        Resets the internal state of the metric.

        This should be called at the start of each epoch.
        """
        raise NotImplementedError

    def update_with_indexes(self, *args: Any, **kwargs: Any) -> None:
        """
        Smartly updates the metric by extracting arguments based on ``self.indexes``.

        This method acts as a middleware pipeline:

        1. **Check**: Ensures no mixing of ``*args`` and ``**kwargs``.
        2. **Normalize**: Unpacks single-item containers if ``auto_unpack`` is True.
        3. **Route**:

            - If ``indexes`` are set: Extracts specific values.
            - If ``indexes`` are None: Passes data through directly.
        4. **Execute**: Calls user-defined :meth:`update`.

        Args:
            *args: Positional arguments (or a single list/tuple/dict wrapper).
            **kwargs: Keyword arguments (treated as a dictionary container).

        Raises:
            ValueError: If args and kwargs are mixed.
            ValueError: If data extraction fails (e.g., missing key, index out of range).
        """
        # --- Phase 1: Input Normalization ---
        if args and kwargs:
            raise ValueError("Metric update does not support mixing *args and **kwargs.")

        container: Union[Sequence, Dict]

        if kwargs:
            container = kwargs
        elif args:
            container = args
            # Handle auto-unpacking for single container inputs
            if self._auto_unpack and len(args) == 1 and isinstance(args[0], (list, tuple, dict)):
                container = args[0]
        else:
            # No data provided, skip update
            return

        # --- Phase 2: Data Routing ---

        # Scenario A: No indexes configured (Pass-through mode)
        if self._indexes is None:
            if isinstance(container, (list, tuple)):
                self.update(*container)
            elif isinstance(container, dict):
                # Warning: Keys must match update() signature exactly here
                self.update(**container)
            else:
                # Single value input (e.g., update(1))
                self.update(container)
            return

        # Scenario B: Indexes configured (Extraction mode)
        try:
            # We explicitly define extraction logic to separate it from update logic errors
            inputs = [container[k] for k in self._indexes]
        except (IndexError, KeyError, TypeError) as e:
            # Catch only extraction errors.
            # TypeError catches cases like using string index on a list container.
            raise ValueError(
                f"Metric '{self.__class__.__name__}' data extraction failed.\n"
                f"Configured indexes: {self._indexes}\n"
                f"Input container type: {type(container).__name__}\n"
                f"Input container: {container}\n"
                f"Error detail: {e}"
            ) from e

        # --- Phase 3: Execution ---
        # Call update with extracted inputs.
        # Any error inside self.update will NOT be caught here, allowing easier debugging.
        self.update(*inputs)

    @abstractmethod
    def update(self, *args: Any, **kwargs: Any) -> None:
        """
        Updates the metric state with new data.

        Subclasses must implement this method.

        Args:
            *args: Variable length argument list containing predictions and targets.
            **kwargs: Arbitrary keyword arguments (only used if passed directly).
        """
        raise NotImplementedError

    @abstractmethod
    def eval(self) -> Any:
        """
        Computes and returns the final metric value.

        Returns:
            Any: The computed metric value (usually float or dict).
        """
        raise NotImplementedError


