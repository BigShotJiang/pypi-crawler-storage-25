# -*- coding: utf-8 -*-
import numpy as np
from typing import Any, Union, List, Optional

from ..base import BaseMetric


class MeanSquaredError(BaseMetric):
    r"""
    Computes the Mean Squared Error (MSE).

    The metric is calculated as follows:

    .. math::

        \text{MSE} = \frac{1}{N} \sum_{i=1}^{N} (y_{\text{pred}, i} - y_{\text{true}, i})^2

    where :math:`N` is the total number of elements in the input tensors.

    Args:
        indexes (Optional[List[Union[int, str]]]): Configured indexes for data routing.
            Useful when the model output is a complex dictionary or tuple.
        **kwargs: Additional arguments for the base class.

    Example:
        >>> # 1. Simple 1D Example
        >>> metric = MeanSquaredError()
        >>> y_pred = np.array([3.0, 5.0])
        >>> y_true = np.array([2.5, 5.0])
        >>> metric.update(y_pred, y_true)
        >>> # ((3.0-2.5)^2 + (5.0-5.0)^2) / 2 = (0.25 + 0) / 2 = 0.125
        >>> metric.eval()
        0.125

        >>> # 2. Batch/Multi-dim Example (Accumulation)
        >>> metric.clear()
        >>> # Batch size 2, 2 outputs per sample
        >>> y_pred_batch = np.array([[1.0, 2.0], [3.0, 4.0]])
        >>> y_true_batch = np.array([[1.0, 1.0], [3.0, 6.0]])
        >>> metric.update(y_pred_batch, y_true_batch)
        >>> # diffs: [[0, 1], [0, -2]] 
        >>> # squared: [[0, 1], [0, 4]] -> sum: 5.0
        >>> # total elements: 4
        >>> metric.eval()
        1.25
    """

    def __init__(self, *args: Any, **kwargs: Any) -> None:
        super().__init__(*args, **kwargs)
        self.clear()

    def clear(self) -> None:
        """
        Resets the internal state of the metric.
        """
        # _sq_diff_sum (float): Accumulator for the sum of squared differences.
        # _total_elements (int): Accumulator for the total number of elements seen.
        self._sq_diff_sum = 0.0
        self._total_elements = 0

    def update(
            self,
            preds: Union[np.ndarray, List[Any]],
            target: Union[np.ndarray, List[Any]]
    ) -> None:
        """
        Updates the metric state with new predictions and targets.

        Args:
            preds (Union[np.ndarray, List[Any]]): Model predictions.
            target (Union[np.ndarray, List[Any]]): Ground truth values.
        
        Raises:
            ValueError: If the shapes of preds and target do not match.
        """
        # 使用 asarray 避免不必要的内存拷贝，同时兼容 list/tuple 输入
        y_pred = np.asarray(preds)
        y_true = np.asarray(target)

        # 检查形状是否一致
        if y_pred.shape != y_true.shape:
            raise ValueError(f"Shape mismatch: preds {y_pred.shape} vs target {y_true.shape}")

        # 计算平方误差和
        # update state
        self._sq_diff_sum += np.sum(np.square(y_pred - y_true))

        # 使用 size (元素总数) 确保能够正确处理任意维度 (Batch, Channel, H, W)
        self._total_elements += y_pred.size

    def eval(self) -> float:
        """
        Computes the final MSE value.

        Returns:
            float: The mean squared error over all samples seen.
        """
        if self._total_elements == 0:
            return 0.0
        return self._sq_diff_sum / self._total_elements