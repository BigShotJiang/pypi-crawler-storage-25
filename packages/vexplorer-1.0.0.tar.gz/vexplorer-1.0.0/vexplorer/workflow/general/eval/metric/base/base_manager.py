# -*- coding: utf-8 -*-
from abc import ABC, abstractmethod
from typing import Dict, Any, Optional, Union, List

from ..base import BaseMetric


class BaseMetricManager(BaseMetric):
    """
    Abstract base class for metric managers.

    This class acts as a container for multiple metrics, allowing them to be
    updated, cleared, and evaluated in batch. It inherits from :class:`BaseMetric`
    to maintain interface compatibility (polymorphism), but disables specific
    routing configurations (like `indexes`) as those should be configured on
    the individual metrics, not the manager.

    Args:
        metrics (Optional[Dict[str, BaseMetric]]): A dictionary mapping metric names
            to Metric instances. Defaults to None (initializes empty).
        **kwargs: Additional keyword arguments passed to the base class.
    """

    def __init__(self, metrics: Optional[Dict[str, BaseMetric]] = None, **kwargs: Any):
        # Manager itself does not support 'indexes', so we force it to None.
        # We pass kwargs to allow for potential future extensions, but filter logic is disabled.
        super().__init__(indexes=None, **kwargs)
        self._metrics: Dict[str, BaseMetric] = metrics if metrics is not None else {}

    @property
    def metrics(self) -> Dict[str, BaseMetric]:
        """Access the underlying metrics dictionary."""
        return self._metrics

    def add_metric(self, name: str, metric: BaseMetric) -> None:
        """
        Dynamically adds a metric to the manager.

        Args:
            name (str): The name of the metric (e.g., 'acc').
            metric (BaseMetric): The metric instance.
        """
        self._metrics[name] = metric

    def remove_metric(self, name: str) -> None:
        """Removes a metric by name."""
        if name in self._metrics:
            del self._metrics[name]

    def clear(self) -> None:
        """Clears the history of all managed metrics."""
        for metric in self._metrics.values():
            metric.clear()

    def eval(self) -> Dict[str, Any]:
        """
        Calculates and returns the results of all metrics.

        Returns:
            Dict[str, Any]: A dictionary containing evaluation results {name: score}.
        """
        results = {}
        for name, metric in self._metrics.items():
            results[name] = metric.eval()
        return results

    @abstractmethod
    def update(self, *args: Any, **kwargs: Any) -> None:
        """
        Updates metrics with new data batches.

        Raises:
            NotImplementedError: Must be implemented by subclasses.
        """
        raise NotImplementedError

    def update_with_indexes(self, *args: Any, **kwargs: Any) -> None:
        """
        Overridden to bypass the base class's extraction logic.

        A Manager acts as a broadcaster. It receives the raw input (container)
        and passes it directly to the :meth:`update` method (which then distributes
        it to children). It should NOT perform extraction itself.
        """
        self.update(*args, **kwargs)

    # --- Banned Methods (Interface Segregation) ---

    @property
    def indexes(self) -> None:
        """
        [Disabled] Metric Managers do not support global indexes.

        Please configure `indexes` on the individual metrics added to this manager.

        Raises:
            AttributeError: Always raised when accessing this property.
        """
        raise AttributeError(
            "MetricManager does not support 'indexes'. "
            "Please set indexes on the individual metrics inside the manager."
        )

    def set_indexes(self, indexes: Any) -> None:
        """
        [Disabled] Metric Managers do not support global indexes.

        Raises:
            AttributeError: Always raised when calling this method.
        """
        raise AttributeError(
            "MetricManager does not support 'set_indexes'. "
            "Please set indexes on the individual metrics inside the manager."
        )


class SmartMetricManager(BaseMetricManager):
    """
    A smart metric manager that leverages the routing capabilities of individual metrics.

    This manager acts as a broadcaster. It accepts raw inputs (lists, tuples, or dicts)
    and passes them to every managed metric. Each metric then uses its own
    :meth:`update_with_indexes` method to extract the specific data it needs.

    This design decouples the manager from the specific data requirements of its metrics.

    Args:
        metrics (Optional[Dict[str, BaseMetric]]): A dictionary mapping metric names
            to Metric instances. Defaults to None.

    Example:
        >>> # Setup: Define metrics with their own routing logic
        >>> acc = Accuracy(indexes=['pred', 'target'])
        >>> loss = Loss(indexes=['loss'])
        >>> manager = SmartMetricManager({'acc': acc, 'loss': loss})

        >>> # Update with a combined output dictionary
        >>> output = {'pred': 0.8, 'target': 1, 'loss': 0.5}

        >>> # Manager broadcasts 'output' to both.
        >>> # 'acc' extracts pred/target; 'loss' extracts loss.
        >>> manager.update(output)
    """

    def update(self, *args: Any, **kwargs: Any) -> None:
        """
        Broadcasts the update call to all managed metrics.

        The arguments are passed directly to each metric's :meth:`update_with_indexes`.

        Args:
            *args: Positional arguments (or a single list/tuple/dict container).
            **kwargs: Keyword arguments (treated as a dictionary container).
        """
        for name, metric in self._metrics.items():
            try:
                # Delegate to the metric's own smart routing logic
                metric.update_with_indexes(*args, **kwargs)
            except Exception as e:
                # Catching generic Exception is intended here to identify which metric failed
                # without crashing the whole loop immediately, but we re-raise to fail fast.
                raise RuntimeError(
                    f"MetricManager failed to update metric '{name}'. "
                    f"Input args type: {[type(a) for a in args]}, kwargs keys: {list(kwargs.keys())}.\n"
                    f"Error detail: {e}"
                ) from e



