# -*- coding: utf-8 -*-
import numpy as np
from typing import Any, Union, List, Optional

from ..base import BaseMetric


class MeanAbsoluteError(BaseMetric):
    r"""
    Computes the Mean Absolute Error (MAE).

    The metric is calculated as follows:

    .. math::

        \text{MAE} = \frac{1}{N} \sum_{i=1}^{N} |y_{\text{pred}, i} - y_{\text{true}, i}|

    where :math:`N` is the total number of elements in the input tensors.

    Args:
        indexes (Optional[List[Union[int, str]]]): Configured indexes for data routing.
            Useful when the model output is a complex dictionary or tuple.
        **kwargs: Additional arguments for the base class.

    Example:
        >>> # 1. Simple 1D Example
        >>> metric = MeanAbsoluteError()
        >>> y_pred = np.array([3.0, 5.0, 2.5, 7.0])
        >>> y_true = np.array([2.5, 5.0, 4.0, 8.0])
        >>> metric.update(y_pred, y_true)
        >>> metric.eval()
        0.75

        >>> # 2. Batch/Multi-dim Example
        >>> metric.clear()
        >>> # Batch size 2, 2 outputs per sample
        >>> y_pred_batch = np.array([[3.0, 5.0], [1.0, 1.0]])
        >>> y_true_batch = np.array([[2.0, 6.0], [1.0, 2.0]])
        >>> metric.update(y_pred_batch, y_true_batch)
        >>> # |3-2| + |5-6| + |1-1| + |1-2| = 1 + 1 + 0 + 1 = 3.0
        >>> # Total elements = 4
        >>> metric.eval()
        0.75
    """

    def __init__(self, *args: Any, **kwargs: Any) -> None:
        super().__init__(*args, **kwargs)
        self.clear()

    def clear(self) -> None:
        """
        Resets the internal state of the metric.
        """
        # _abs_diff_sum (float): Accumulator for the sum of absolute differences.
        # _total_elements (int): Accumulator for the total number of elements seen.
        self._abs_diff_sum = 0.0
        self._total_elements = 0

    def update(
            self,
            preds: Union[np.ndarray, List[Any]],
            target: Union[np.ndarray, List[Any]]
    ) -> None:
        """
        Updates the metric state with new predictions and targets.

        Args:
            preds (Union[np.ndarray, List[Any]]): Model predictions.
            target (Union[np.ndarray, List[Any]]): Ground truth values.

        Raises:
            ValueError: If the shapes of preds and target do not match.
        """
        # 使用 asarray 避免不必要的内存拷贝（如果输入已经是 array），同时兼容 list/tuple 输入
        y_pred = np.asarray(preds)
        y_true = np.asarray(target)

        # 检查形状是否一致
        if y_pred.shape != y_true.shape:
            raise ValueError(f"Shape mismatch: preds {y_pred.shape} vs target {y_true.shape}")

        # 计算绝对误差和
        # np.abs returns float type array, safe to accumulate
        self._abs_diff_sum += np.sum(np.abs(y_pred - y_true))

        # 使用 size 而不是 len，确保多维输出（如 (Batch, Channels)）计算的是所有元素的平均值
        self._total_elements += y_pred.size

    def eval(self) -> float:
        """
        Computes the final MAE value.

        Returns:
            float: The mean absolute error over all samples seen.
        """
        if self._total_elements == 0:
            return 0.0
        return self._abs_diff_sum / self._total_elements