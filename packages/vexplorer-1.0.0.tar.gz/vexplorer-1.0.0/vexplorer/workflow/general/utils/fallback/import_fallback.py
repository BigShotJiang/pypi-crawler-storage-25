# -*- coding: utf-8 -*-
import logging
from typing import Any, Optional

logger = logging.getLogger(__name__)

_DEFAULT_SENTINEL = object()

class TraceableFallback:
    """A dynamic placeholder class that traces attribute access and method calls.

    It is designed to prevent crashes when optional dependencies are missing.
    Key Feature: It supports **method chaining** (e.g., ``obj().method()``) by default.

    Args:
        path (str, optional): The initial name or path of the object. Defaults to "".
        verbose (bool): If True, logs a warning when the object is called. Defaults to True.
        return_value (Any, optional): The value to return when this object is called.
            If not provided (default), calling this object returns a new
            ``TraceableFallback`` instance to support chaining.

    Example:
        >>> # Scenario: 'tensorboard' is missing
        >>> SummaryWriter = TraceableFallback("SummaryWriter")
        >>> writer = SummaryWriter(log_dir="./logs") # Returns a new Fallback object
        >>> writer.add_scalar("loss", 0.5)           # Works! (Logs warning)
    """

    def __init__(self,
                 path: str = "",
                 verbose: bool = True,
                 return_value: Any = _DEFAULT_SENTINEL):
        self._path = path
        self._verbose = verbose
        self._return_value = return_value

    def __set_name__(self, owner: Any, name: str):
        """Descriptor protocol: Auto-captures the variable name."""
        if not self._path:
            self._path = name

    def __getattr__(self, item: str) -> "TraceableFallback":
        """Recursively builds the access path."""
        new_path = f"{self._path}.{item}" if self._path else item
        return TraceableFallback(
            path=new_path,
            verbose=self._verbose,
            return_value=self._return_value
        )

    def __call__(self, *args: Any, **kwargs: Any) -> Any:
        """Executes the fallback logic."""
        if self._verbose:
            logger.warning(
                f"[TraceableFallback] Executing fallback path: '{self._path}'\n"
                f"    -> Args: {args}\n"
                f"    -> Kwargs: {kwargs}"
            )

        # [FIX]: Support method chaining by default
        if self._return_value is _DEFAULT_SENTINEL:
            # Return a new Fallback object representing the result of this call
            return TraceableFallback(
                path=f"{self._path}()",
                verbose=self._verbose
            )

        return self._return_value

    def __repr__(self) -> str:
        return f"<TraceableFallback path='{self._path}'>"

    def __bool__(self) -> bool:
        """
        Always False.
        This allows checks like `if module: module.run()` to safely skip execution.
        """
        return False