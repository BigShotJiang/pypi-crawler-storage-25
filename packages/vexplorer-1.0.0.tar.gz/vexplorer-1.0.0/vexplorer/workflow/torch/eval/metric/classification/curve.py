# -*- coding: utf-8 -*-


import torch
import torch.nn.functional as F
from torch import Tensor
from typing import Dict, List, Optional, Union, Any, Literal

from ..base import BaseTorchMetric
from ..utils.decorator import auto_update, auto_compute
from ..utils.enums import DistributedReduceOp, ClassificationAverageMethod
from .curve_core import (
    compute_roc_curve,
    compute_pr_curve,
    compute_log_roc_curve,
    compute_confusion_matrix_at_thresholds,
    find_optimal_threshold, 
    find_all_optimal_thresholds
)
from .confusion_matrix_core import compute_metrics_from_confusion_matrix

__all__ = [
    "BinaryCurve", "MulticlassCurve", "MultilabelCurve",
    "ValueMapBinaryCurve", "ValueMapMulticlassCurve", "ValueMapMultilabelCurve",
    "GroupValueMapMulticlassCurve", "GroupValueMapMultilabelCurve",
]


class BaseComplexCurveMetric(BaseTorchMetric):
    """
    Base class for complex curve metrics with optimal & fixed threshold support.

    Features:
    - Curves: ROC, PR, LogROC
    - Auto Thresholds: max_youdenj, max_f1, min_distance, etc.
    - Fixed Thresholds: User-defined thresholds via `threshold_given` (registered as buffers).
    - Output: Flexible flat or nested dicts.

    Args:
        curve_types: List of curves ['roc', 'pr', 'log_roc']. Default: ['roc', 'pr']
        threshold_methods: List of auto methods ['max_youdenj', 'max_f1'] or 'all'.
        threshold_metrics: List of metrics to compute at each threshold ['accuracy', 'f1'] or 'all'.
        threshold_given: Dict of fixed thresholds to evaluate {name: value}.
                         Binary: {'custom': 0.5}
                         Multiclass/Label: {'custom': [0.5, 0.6, ...]}
        flatten_output: Whether to flatten nested dict keys (e.g. 'roc_auc').
        separator: Separator for flattened keys.
        memory_mode: 'vectorized', 'chunked', or 'loop'. Controls memory usage during CM computation.
                     Default: 'chunked'.
        **kwargs: BaseTorchMetric args.
    """

    def __init__(
            self,
            curve_types: List[str] = ['roc', 'pr'],
            threshold_methods: Union[str, List[str]] = 'all',
            threshold_metrics: Union[str, List[str]] = 'all',
            threshold_given: Optional[Dict[str, Union[float, List[float], Tensor]]] = None,
            flatten_output: bool = True,
            separator: str = '_',
            memory_mode: Literal['vectorized', 'chunked', 'loop'] = 'chunked',
            **kwargs
    ):
        super().__init__(**kwargs)
        self.curve_types = curve_types
        self.threshold_methods = threshold_methods
        self.threshold_metrics = threshold_metrics
        self.flatten_output = flatten_output
        self.separator = separator
        self.memory_mode = memory_mode

        # Internal list to track registered buffer names for iteration
        self._threshold_given_keys = []

        # Register initial thresholds as buffers
        if threshold_given:
            self.set_threshold_given(threshold_given)

        # State management for predictions and targets
        self.add_state("preds", [], dist_reduce_fx=DistributedReduceOp.CAT)
        self.add_state("target", [], dist_reduce_fx=DistributedReduceOp.CAT)

    def set_threshold_given(self, thresholds: Dict[str, Union[float, List[float], Tensor]]) -> None:
        """
        Register or update fixed thresholds as persistent buffers.

        This ensures thresholds are automatically moved to the correct device (CPU/GPU)
        along with the metric.

        Args:
            thresholds: Dict mapping name to threshold value(s).
                        Example: {'high_recall': 0.2, 'balanced': 0.5}
        """
        for name, val in thresholds.items():
            # Convert to tensor if needed
            if isinstance(val, Tensor):
                t_val = val.float() # Ensure float for thresholds
            else:
                t_val = torch.tensor(val, dtype=torch.float)

            # Ensure scalar thresholds are 1D (size 1) for consistent processing
            if t_val.ndim == 0:
                t_val = t_val.unsqueeze(0)

            # Define internal buffer name
            buffer_name = f"_thresh_buffer_{name}"

            # Register buffer (handles device movement automatically)
            # If it already exists (updating), we overwrite the data
            if hasattr(self, buffer_name):
                # We must cast to the current device of the existing buffer
                current_buffer = getattr(self, buffer_name)
                setattr(self, buffer_name, t_val.to(current_buffer.device))
            else:
                self.register_buffer(buffer_name, t_val)
                self._threshold_given_keys.append(name)

    @auto_update
    def update(self, preds: Tensor, target: Tensor) -> None:
        """
        Update state with new predictions and targets.

        Args:
            preds: Predictions tensor (probabilities, logits, or continuous).
            target: Ground truth tensor.
        """
        self.preds.append(preds.detach())
        self.target.append(target.detach())

    def _compute_metrics_at_specific_thresholds(
            self,
            preds: Tensor,
            target: Tensor,
            thresholds: Tensor,
            threshold_name: str
    ) -> Dict[str, Any]:
        """Compute metrics for a specific set of fixed thresholds."""
        # Compute CM at these specific thresholds using configured memory mode
        cm = compute_confusion_matrix_at_thresholds(
            preds, target, thresholds, memory_mode=self.memory_mode
        )

        results = {}
        num_points = thresholds.numel()

        for i in range(num_points):
            tp, fp = cm['tp'][i], cm['fp'][i]
            tn, fn = cm['tn'][i], cm['fn'][i]

            point_metrics = compute_metrics_from_confusion_matrix(
                tp, fp, fn, tn, metrics=self.threshold_metrics
            )

            # Key naming: name or name_index
            suffix = "" if num_points == 1 else f"_{i}"

            results[f"{threshold_name}{suffix}"] = {
                'threshold': thresholds[i],
                **point_metrics
            }

        return results

    def _compute_single_curve_with_thresholds(
            self,
            preds: Tensor,
            target: Tensor,
            curve_type: str,
            fpr_epsilon: float = 1e-10
    ) -> Dict[str, Any]:
        """Compute a single curve (ROC/PR/LogROC) and its optimal thresholds."""

        # 1. 定义曲线与寻优方法的强制绑定关系
        # 只有出现在列表中的方法才会在对应的曲线类型下执行
        BINDING_MAP = {
            'roc': ['max_youdenj', 'min_distance', 'max_tss', 'max_accuracy'],
            'pr': ['max_f1', 'max_f_beta', 'max_precision', 'max_recall'],
            'log_roc': ['max_youdenj']
        }

        # 2. 基础曲线计算
        if curve_type == 'roc':
            res = compute_roc_curve(preds, target)
        elif curve_type == 'pr':
            res = compute_pr_curve(preds, target)
        elif curve_type == 'log_roc':
            res = compute_log_roc_curve(preds, target, fpr_epsilon=fpr_epsilon)
        else:
            raise ValueError(f"Unknown curve type: {curve_type}")

        results = res.copy()
        curve_threshs = res['thresholds']

        # 3. 自动寻优阈值计算
        if self.threshold_methods:
            # 计算该曲线所有阈值点对应的混淆矩阵 (使用 chunked 模式防止显存溢出)
            cm = compute_confusion_matrix_at_thresholds(
                preds, target, curve_threshs, memory_mode=self.memory_mode
            )

            # 获取当前曲线允许的方法
            allowed_methods = BINDING_MAP.get(curve_type, [])

            # 过滤出用户请求且合法的寻优方法
            if self.threshold_methods == 'all':
                active_methods = allowed_methods
            else:
                requested = [self.threshold_methods] if isinstance(self.threshold_methods, str) else self.threshold_methods
                active_methods = [m for m in requested if m in allowed_methods]

            for method in active_methods:
                # 调用寻优函数 (注意：内部已改为支持 max_youdenj)
                opt_res = find_optimal_threshold(
                    cm['tp'], cm['fp'], cm['tn'], cm['fn'],
                    curve_threshs,
                    method=method
                )

                # --- 核心改进：限制指标数量，防止 SQLite 崩溃 ---
                # 无论 self.threshold_metrics 是什么，这里只记录最关键的指标
                idx = opt_res['index']
                core_metrics = compute_metrics_from_confusion_matrix(
                    cm['tp'][idx], cm['fp'][idx], cm['fn'][idx], cm['tn'][idx],
                    metrics=['accuracy', 'precision', 'recall', 'f1', 'tss', 'mcc']
                )

                # 合并寻优结果和核心指标
                opt_res.update(core_metrics)
                results[method] = opt_res

        return results

    def _compute_single_curve_with_thresholds_v1(
            self,
            preds: Tensor,
            target: Tensor,
            curve_type: str,
            fpr_epsilon: float = 1e-10
    ) -> Dict[str, Any]:
        """Compute curve, optimal thresholds, and fixed thresholds."""

        # 1. Base Curve
        if curve_type == 'roc':
            res = compute_roc_curve(preds, target)
        elif curve_type == 'pr':
            res = compute_pr_curve(preds, target)
        elif curve_type == 'log_roc':
            res = compute_log_roc_curve(preds, target, fpr_epsilon=fpr_epsilon)
        else:
            raise ValueError(f"Unknown curve type: {curve_type}")

        results = res.copy()

        # 2. Optimal Thresholds (Auto)
        if self.threshold_methods:
            curve_threshs = res['thresholds']
            # Use configured memory mode
            cm = compute_confusion_matrix_at_thresholds(
                preds, target, curve_threshs, memory_mode=self.memory_mode
            )
            tp, fp, tn, fn = cm['tp'], cm['fp'], cm['tn'], cm['fn']

            opt_results = {}
            if self.threshold_methods == 'all':
                opt_results = find_all_optimal_thresholds(tp, fp, tn, fn, curve_threshs)
            else:
                methods = [self.threshold_methods] if isinstance(self.threshold_methods, str) else self.threshold_methods
                for m in methods:
                    opt_results[m] = find_optimal_threshold(tp, fp, tn, fn, curve_threshs, method=m)

            # Compute full metrics for optimal points
            for m_name, m_data in opt_results.items():
                idx = m_data['index']
                point_metrics = compute_metrics_from_confusion_matrix(
                    tp[idx], fp[idx], fn[idx], tn[idx], metrics=self.threshold_metrics
                )
                m_data.update(point_metrics)

            results.update(opt_results)

        # 3. Fixed Thresholds (User Provided)
        # Iterate over registered keys to access buffers
        for name in self._threshold_given_keys:
            buffer_name = f"_thresh_buffer_{name}"
            # Access buffer (it will be on the correct device)
            t_val = getattr(self, buffer_name)

            fixed_res = self._compute_metrics_at_specific_thresholds(
                preds, target, t_val, name
            )
            results.update(fixed_res)

        return results

    def _format_and_flatten(self, raw_results: Dict[str, Any]) -> Dict[str, Any]:
        """Flatten nested dictionary keys with separator."""
        if not self.flatten_output:
            return raw_results

        flat = {}
        sep = self.separator

        for context, data in raw_results.items():
            # context is usually curve_name (roc) or per_class index
            for key, val in data.items():
                if isinstance(val, dict):
                    # Sub-dictionary (e.g. max_youdenj -> {f1: 0.9, ...})
                    for sub_k, sub_v in val.items():
                        flat[f"{context}{sep}{key}{sep}{sub_k}"] = sub_v
                else:
                    # Direct scalar (e.g. auc)
                    flat[f"{context}{sep}{key}"] = val
        return flat


# =============================================================================
# Standard Curves (Wrappers)
# =============================================================================

class BinaryCurve(BaseComplexCurveMetric):
    """
    Standard Binary Classification Curve.

    Examples:
        >>> metric = BinaryCurve(threshold_given={'fixed': 0.5})
        >>> metric.update(preds, target)
        >>> metric.compute()
    """

    def __init__(self, fpr_epsilon: float = 1e-10, **kwargs):
        super().__init__(**kwargs)
        self.fpr_epsilon = fpr_epsilon

    @auto_compute
    def compute(self) -> Dict[str, Any]:
        if not self.preds: return {}
        preds = torch.cat(self.preds, dim=0)
        target = torch.cat(self.target, dim=0)

        results = {}
        for c_type in self.curve_types:
            results[c_type] = self._compute_single_curve_with_thresholds(
                preds, target, c_type, self.fpr_epsilon
            )
        return self._format_and_flatten(results)


class MulticlassCurve(BaseComplexCurveMetric):
    """
    Standard Multiclass Curve (One-vs-Rest).

    Args:
        num_classes: Number of classes.
        average: 'macro', 'weighted', or 'none'.
    """

    def __init__(
            self, num_classes: int,
            average: str = 'macro',
            fpr_epsilon: float = 1e-10,
            class_names: Optional[List[str]] = None,
            **kwargs
    ):
        super().__init__(**kwargs)
        self.num_classes = num_classes
        self._check_average_method(average)
        self.average = ClassificationAverageMethod(average) if isinstance(average, str) else average
        self.fpr_epsilon = fpr_epsilon
        if class_names is not None and len(class_names) != num_classes:
            raise ValueError(f"class_names 的长度 ({len(class_names)}) 必须等于 num_classes ({num_classes})")
        self.class_names = class_names

    def _check_average_method(self, average: str):
        valid = ['macro', 'weighted', 'none']
        # 'micro' and 'samples' not typically used for simple multiclass ROC curve aggregation
        # in the same way, but can be added if logic supports it.
        # Here we follow the logic implemented below.
        if average not in valid and not isinstance(average, ClassificationAverageMethod):
            raise ValueError(f"average '{average}' not supported for MulticlassCurve. Choose from {valid}")

    @auto_compute
    def compute(self) -> Dict[str, Any]:
        if not self.preds: return {}
        preds = torch.cat(self.preds, dim=0)
        target = torch.cat(self.target, dim=0)

        # Per-class calculation
        per_class_res = []
        for i in range(self.num_classes):
            c_preds = preds[:, i] if preds.dim() > 1 else preds
            c_target = (target == i).long()

            c_res = {}
            for c_type in self.curve_types:
                c_res[c_type] = self._compute_single_curve_with_thresholds(
                    c_preds, c_target, c_type, self.fpr_epsilon
                )
            per_class_res.append(c_res)

        if self.average == ClassificationAverageMethod.NONE:
            # return {'per_class': [self._format_and_flatten(r) for r in per_class_res]}
            if self.flatten_output:
                # 扁平化模式：直接输出带类名的键，如 'C_class_roc_auc': 0.9
                flat_res = {}
                for i, r in enumerate(per_class_res):
                    prefix = self.class_names[i] if self.class_names else f"class_{i}"
                    flat_r = self._format_and_flatten(r)
                    for k, v in flat_r.items():
                        flat_res[f"{prefix}{self.separator}{k}"] = v
                return flat_res
            else:
                # 嵌套字典模式：返回 {'per_class': {'C_class': {...}, 'M_class': {...}}}
                res_dict = {}
                for i, r in enumerate(per_class_res):
                    name = self.class_names[i] if self.class_names else f"class_{i}"
                    res_dict[name] = self._format_and_flatten(r)
                return {'per_class': res_dict}

        # Aggregation
        weights = self._get_weights(target, preds.device)
        agg_res = self._aggregate_results(per_class_res, weights)
        return self._format_and_flatten(agg_res)

    def _get_weights(self, target: Tensor, device: torch.device) -> Tensor:
        if self.average == ClassificationAverageMethod.MACRO:
            return torch.ones(self.num_classes, device=device) / self.num_classes
        counts = torch.bincount(target.long(), minlength=self.num_classes).float()
        return counts / counts.sum().clamp(min=1e-8)

    def _aggregate_results(self, per_class_res: List[Dict], weights: Tensor) -> Dict:
        """Aggregate nested results using weighted average."""
        agg = {}
        ref = per_class_res[0]

        for root_k in ref.keys(): # curve_type
            agg[root_k] = {}
            for sub_k, sub_v in ref[root_k].items(): # metric or method
                if isinstance(sub_v, dict): # method dict
                    agg[root_k][sub_k] = {}
                    for m_k in sub_v.keys(): # specific metric
                        vals = torch.stack([r[root_k][sub_k][m_k] for r in per_class_res])
                        agg[root_k][sub_k][m_k] = (vals * weights).sum()
                elif isinstance(sub_v, Tensor) and sub_v.numel() == 1: # scalar
                    vals = torch.stack([r[root_k][sub_k] for r in per_class_res])
                    agg[root_k][sub_k] = (vals * weights).sum()
        return agg


class MultilabelCurve(BaseComplexCurveMetric):
    """
    Standard Multilabel Curve.

    Args:
        num_labels: Number of labels.
        average: 'macro', 'weighted', 'micro', 'none'.
    """

    def __init__(
            self, num_labels: int,
            average: str = 'macro',
            fpr_epsilon: float = 1e-10,
            label_names: Optional[List[str]] = None,
            **kwargs
    ):
        super().__init__(**kwargs)
        self.num_labels = num_labels
        self._check_average_method(average)
        self.average = ClassificationAverageMethod(average) if isinstance(average, str) else average
        self.fpr_epsilon = fpr_epsilon
        if label_names is not None and len(label_names) != num_labels:
            raise ValueError(f"label_names len ({len(label_names)})  != num_labels ({num_labels})")
        self.label_names = label_names

    def _check_average_method(self, average: str):
        valid = ['macro', 'weighted', 'micro', 'none']
        if average not in valid and not isinstance(average, ClassificationAverageMethod):
            raise ValueError(f"average '{average}' not supported for MultilabelCurve. Choose from {valid}")

    @auto_compute
    def compute(self) -> Dict[str, Any]:
        if not self.preds: return {}
        preds = torch.cat(self.preds, dim=0)
        target = torch.cat(self.target, dim=0)

        # Micro Average
        if self.average == ClassificationAverageMethod.MICRO:
            res = {}
            for c_type in self.curve_types:
                res[c_type] = self._compute_single_curve_with_thresholds(
                    preds.flatten(), target.flatten(), c_type, self.fpr_epsilon
                )
            return self._format_and_flatten(res)

        # Per-Label
        per_label_res = []
        for i in range(self.num_labels):
            c_res = {}
            for c_type in self.curve_types:
                c_res[c_type] = self._compute_single_curve_with_thresholds(
                    preds[:, i], target[:, i], c_type, self.fpr_epsilon
                )
            per_label_res.append(c_res)

        if self.average == ClassificationAverageMethod.NONE:
            # return {'per_label': [self._format_and_flatten(r) for r in per_label_res]}
            if self.flatten_output:
                # 扁平化模式：直接输出带标签名的键，如 'C_class_roc_auc': 0.9
                flat_res = {}
                for i, r in enumerate(per_label_res):
                    prefix = self.label_names[i] if self.label_names else f"label_{i}"
                    flat_r = self._format_and_flatten(r)
                    for k, v in flat_r.items():
                        flat_res[f"{prefix}{self.separator}{k}"] = v
                return flat_res
            else:
                # 嵌套字典模式：返回 {'per_label': {'C_class': {...}, 'M_class': {...}}}
                res_dict = {}
                for i, r in enumerate(per_label_res):
                    name = self.label_names[i] if self.label_names else f"label_{i}"
                    res_dict[name] = self._format_and_flatten(r)
                return {'per_label': res_dict}

        # Aggregation
        if self.average == ClassificationAverageMethod.MACRO:
            weights = torch.ones(self.num_labels, device=preds.device) / self.num_labels
        else:
            counts = target.sum(dim=0).float()
            weights = counts / counts.sum().clamp(min=1e-8)

        # Re-use aggregation logic from Multiclass
        agg = {}
        ref = per_label_res[0]
        for root_k in ref.keys():
            agg[root_k] = {}
            for sub_k, sub_v in ref[root_k].items():
                if isinstance(sub_v, dict):
                    agg[root_k][sub_k] = {}
                    for m_k in sub_v.keys():
                        vals = torch.stack([r[root_k][sub_k][m_k] for r in per_label_res])
                        agg[root_k][sub_k][m_k] = (vals * weights).sum()
                elif isinstance(sub_v, Tensor) and sub_v.numel() == 1:
                    vals = torch.stack([r[root_k][sub_k] for r in per_label_res])
                    agg[root_k][sub_k] = (vals * weights).sum()
        return self._format_and_flatten(agg)


# =============================================================================
# ValueMap Helpers & Classes
# =============================================================================

def _apply_label_map(
        target: Tensor,
        label_type: str,
        thresholds: Optional[Union[float, List[float], Tensor]] = None,
        mode: str = 'binary'
) -> Tensor:
    """
    Transform continuous/raw targets into classification labels.

    Args:
        target: Input target tensor.
        label_type: 'raw', 'one_hot', or 'continuous'.
        thresholds: Thresholds for 'continuous' mapping.
        mode: 'binary', 'multiclass', or 'multilabel'.
    """
    if label_type == 'one_hot':
        return target.argmax(dim=-1) if mode == 'multiclass' else target
    elif label_type == 'raw':
        return target
    elif label_type == 'continuous':
        if thresholds is None:
            raise ValueError("label_thresholds must be provided for label_type='continuous'")

        # Ensure thresholds are on same device
        device = target.device
        if isinstance(thresholds, Tensor):
            t = thresholds.to(device)
        else:
            t = torch.tensor(thresholds, device=device)

        if mode == 'binary':
            # (-inf, T) -> 0, [T, inf) -> 1
            return (target >= t).long()

        elif mode == 'multiclass':
            # Buckets: (-inf, T1) -> 0, [T1, T2) -> 1, ...
            # bucketize with right=False: target < t[i] -> i
            return torch.bucketize(target, t, right=False)

        elif mode == 'multilabel':
            # Cumulative Thresholds (Solar Flare style)
            # Target [N], Thresholds [L]. Result [N, L]
            # Is Flux > C? Is Flux > M?
            if target.ndim == 1 and t.ndim == 1:
                return (target.unsqueeze(1) >= t.unsqueeze(0)).long()
            # Per-channel thresholding
            else:
                return (target >= t).long()

    return target


class ValueMapBinaryCurve(BinaryCurve):
    """
    Binary Curve allowing continuous targets mapped to 0/1.

    Args:
        label_type: 'raw', 'one_hot', or 'continuous'.
        label_thresholds: Scalar threshold. Values < T -> 0, Values >= T -> 1.
                          Registered as buffer if provided.
    """
    def __init__(
            self,
            label_type: str = 'raw',
            label_thresholds: Optional[Union[float, List[float]]] = None,
            **kwargs
    ):
        super().__init__(**kwargs)
        self.label_type = label_type
        # Register label_thresholds as a buffer so it moves to device
        if label_thresholds is not None:
            if not isinstance(label_thresholds, Tensor):
                t_val = torch.tensor(label_thresholds).float()
            else:
                t_val = label_thresholds.float()
            self.register_buffer('label_thresholds_buffer', t_val)
        else:
            self.register_buffer('label_thresholds_buffer', None)

    @auto_update
    def update(self, preds: Tensor, target: Tensor) -> None:
        """
        Args:
            preds: [N] scores (logits, probs, or raw flux).
            target: [N] labels (continuous flux or binary).
        """
        # Access the buffer
        threshs = getattr(self, 'label_thresholds_buffer', None)
        processed_target = _apply_label_map(
            target, self.label_type, threshs, mode='binary'
        )
        super().update(preds, processed_target)


class ValueMapMulticlassCurve(MulticlassCurve):
    """
    Multiclass Curve allowing continuous targets and predictions.

    Args:
        label_type: 'raw', 'one_hot', or 'continuous'.
        label_thresholds: List of split points [T1, T2...].
                          (-inf, T1) -> Class 0, [T1, T2) -> Class 1 ...
    """
    def __init__(
            self,
            label_type: str = 'raw',
            label_thresholds: Optional[List[float]] = None,
            **kwargs
    ):
        super().__init__(**kwargs)
        self.label_type = label_type
        # Register label_thresholds as buffer
        if label_thresholds is not None:
            if not isinstance(label_thresholds, Tensor):
                t_val = torch.tensor(label_thresholds).float()
            else:
                t_val = label_thresholds.float()
            self.register_buffer('label_thresholds_buffer', t_val)
        else:
            self.register_buffer('label_thresholds_buffer', None)

    @auto_update
    def update(self, preds: Tensor, target: Tensor) -> None:
        """
        Args:
            preds: [N, C] logits OR [N] continuous flux.
                   If [N], values are bucketized into one-hot hard predictions based on label_thresholds.
            target: [N] continuous values OR [N] indices OR [N, C] one-hot.
        """
        threshs = getattr(self, 'label_thresholds_buffer', None)

        # 1. Process Target
        processed_target = _apply_label_map(
            target, self.label_type, threshs, mode='multiclass'
        )

        # TODO 兼容模式
        # 2. Process Preds
        # If preds are [N] (continuous flux), we must map them to scores.
        # For Multiclass, scalar -> class is a hard mapping.
        if preds.ndim == 1 and self.label_type == 'continuous':
            if threshs is None:
                raise ValueError("preds are continuous [N] but no label_thresholds provided.")

            # Bucketize to get class indices
            pred_indices = torch.bucketize(preds, threshs, right=False)

            # Convert to One-Hot (Hard prediction scores: 0.0 or 1.0)
            # Clip indices to ensure valid range [0, num_classes-1]
            pred_indices = pred_indices.clamp(0, self.num_classes - 1)
            processed_preds = F.one_hot(pred_indices, num_classes=self.num_classes).float()
        else:
            processed_preds = preds

        super().update(processed_preds, processed_target)


class ValueMapMultilabelCurve(MultilabelCurve):
    """
    Multilabel Curve allowing continuous targets and predictions (Cumulative Logic).

    In cumulative mode (e.g. Solar Flare), target is a scalar ``[N]`` (Flux),
    thresholds ``[T1, T2]`` produce multilabel targets (Is Flux > T1?
    Is Flux > T2?), and if preds is ``[N]``, it is expanded to ``[N, L]``
    as scores for all levels.

    Args:
        label_type: 'raw', 'one_hot', or 'continuous'.
        label_thresholds: List of thresholds.
    """
    def __init__(
            self,
            label_type: str = 'raw',
            label_thresholds: Optional[List[float]] = None,
            **kwargs
    ):
        super().__init__(**kwargs)
        self.label_type = label_type
        # Register label_thresholds as buffer
        if label_thresholds is not None:
            if not isinstance(label_thresholds, Tensor):
                t_val = torch.tensor(label_thresholds).float()
            else:
                t_val = label_thresholds.float()
            self.register_buffer('label_thresholds_buffer', t_val)
        else:
            self.register_buffer('label_thresholds_buffer', None)

    @auto_update
    def update(self, preds: Tensor, target: Tensor) -> None:
        """
        Args:
            preds: [N, L] logits OR [N] continuous flux.
            target: [N, L] binary OR [N] continuous flux.
        """
        threshs = getattr(self, 'label_thresholds_buffer', None)

        # 1. Process Target
        processed_target = _apply_label_map(
            target, self.label_type, threshs, mode='multilabel'
        )

        # 2. Process Preds
        # If preds are [N] (Flux) and we have [L] labels derived from cumulative thresholds:
        # The Flux value itself IS the score for all labels.
        if preds.ndim == 1 and self.num_labels > 1:
            # Expand: [N] -> [N, L]
            processed_preds = preds.unsqueeze(1).expand(-1, self.num_labels)
        else:
            processed_preds = preds

        super().update(processed_preds, processed_target)


class GroupValueMapMultilabelCurve(BaseTorchMetric):
    """
    A unified wrapper metric for evaluating continuous or multilabel predictions
    across multiple groups (horizons like '12h', '24h', '48h').

    It uses explicit dimension routing (`preds_type`, `target_type`) to safely
    extract the correct slice of data for each group, avoiding ambiguous shape guessing.

    Args:
        group_names (List[str]): Names of the prediction groups (e.g., ['12h', '24h', '48h']).
        num_labels (int): The number of generated labels (L).
        label_thresholds (Optional[List[float]]): Boundaries used to binarize continuous values.
        label_names (Optional[List[str]]): Human-readable names for the thresholds.
        label_type (str): 'continuous', 'raw', or 'one_hot'.
        preds_type (str): Expected shape of predictions.
                          Supported: 'NG', 'NGL', 'N' (if G=1), 'NL' (if G=1).
        target_type (str): Expected shape of targets.
                            Supported: 'NG', 'NGL', 'N' (if G=1), 'NL' (if G=1).
        flatten_output (bool): If True, returns a single flat dictionary with group prefixes.
        separator (str): The string used to join nested keys. Defaults to "_".
        **kwargs: Additional arguments passed to the underlying metric.
    """

    def __init__(
            self,
            group_names: List[str],
            num_labels: int,
            label_thresholds: Optional[List[float]] = None,
            label_names: Optional[List[str]] = None,
            label_type: str = 'continuous',
            preds_type: str = 'NG',     # <--- EXPLICIT ROUTING
            target_type: str = 'NG',   # <--- EXPLICIT ROUTING
            flatten_output: bool = True,
            separator: str = "_",
            **kwargs
    ):
        super().__init__()

        self.group_names = group_names
        self.flatten_output = flatten_output
        self.separator = separator
        self.num_groups = len(group_names)
        self.num_labels = num_labels

        self.preds_type = preds_type.upper()
        self.target_type = target_type.upper()
        self._valid_types = ['N', 'NG', 'NL', 'NGL']

        # ---------------------------------------------------------------------
        # Parameter Validation
        # ---------------------------------------------------------------------
        if label_thresholds is not None and len(label_thresholds) != num_labels:
            raise ValueError(f"num_labels ({num_labels}) must equal len(label_thresholds).")
        if label_names is not None and len(label_names) != num_labels:
            raise ValueError(f"len(label_names) ({len(label_names)}) must equal num_labels.")

        if self.preds_type not in self._valid_types:
            raise ValueError(f"preds_type must be one of {self._valid_types}, got {self.preds_type}.")
        if self.target_type not in self._valid_types:
            raise ValueError(f"target_type must be one of {self._valid_types}, got {self.target_type}.")

        # ---------------------------------------------------------------------
        # Sub-Metric Initialization
        # ---------------------------------------------------------------------
        self.metrics = torch.nn.ModuleDict({
            name: ValueMapMultilabelCurve(
                label_type=label_type,
                label_thresholds=label_thresholds,
                num_labels=num_labels,
                label_names=label_names,
                flatten_output=self.flatten_output,
                separator=self.separator,
                **kwargs
            ) for name in self.group_names
        })

    def _extract_group_data(self, x: Tensor, x_type: str, group_idx: int, name: str) -> Tensor:
        """
        Safely slices the tensor based on explicit type declarations, bypassing `ndim` ambiguity.
        """
        if x_type == 'N':
            if self.num_groups != 1:
                raise ValueError(f"Type '{x_type}' for {name} is only valid when num_groups == 1.")
            if x.ndim != 1:
                raise ValueError(f"Expected 1D tensor [N] for {name}_type 'N', got {x.ndim}D.")
            return x  # Pass the whole 1D tensor to the child (child sees [N])

        elif x_type == 'NL':
            if self.num_groups != 1:
                raise ValueError(f"Type '{x_type}' for {name} is only valid when num_groups == 1.")
            if x.ndim != 2:
                raise ValueError(f"Expected 2D tensor [N, L] for {name}_type 'NL', got {x.ndim}D.")
            return x  # Pass the whole 2D tensor to the child (child sees [N, L])

        elif x_type == 'NG':
            if x.ndim != 2:
                raise ValueError(f"Expected 2D tensor [N, G] for {name}_type 'NG', got {x.ndim}D.")
            if x.shape[1] != self.num_groups:
                raise ValueError(f"{name} sequence length ({x.shape[1]}) != num_groups ({self.num_groups}).")
            return x[:, group_idx]  # Slice group, child sees [N]

        elif x_type == 'NGL':
            if x.ndim != 3:
                raise ValueError(f"Expected 3D tensor [N, G, L] for {name}_type 'NGL', got {x.ndim}D.")
            if x.shape[1] != self.num_groups:
                raise ValueError(f"{name} sequence length ({x.shape[1]}) != num_groups ({self.num_groups}).")
            return x[:, group_idx, :]  # Slice group, child sees [N, L]

    def update(self, preds: Tensor, target: Tensor) -> None:
        """Routes the batch data to the appropriate group metric using explicit types."""
        for i, name in enumerate(self.group_names):
            group_preds = self._extract_group_data(preds, self.preds_type, i, 'preds')
            group_target = self._extract_group_data(target, self.target_type, i, 'targets')

            self.metrics[name].update(group_preds, group_target)

    def compute(self) -> Dict[str, Any]:
        results = {}
        for name in self.group_names:
            group_res = self.metrics[name].compute()
            if self.flatten_output:
                for k, v in group_res.items():
                    results[f"{name}{self.separator}{k}"] = v
            else:
                results[name] = group_res
        return results


class GroupValueMapMulticlassCurve(BaseTorchMetric):
    """
    A unified wrapper metric for evaluating multiclass predictions across multiple groups.

    It uses explicit dimension routing (`preds_type`, `target_type`) to safely
    extract the correct slice of data for each group, avoiding ambiguous shape guessing.

    Args:
        group_names (List[str]): Names of the prediction groups (e.g., ['12h', '24h', '48h']).
        num_classes (int): Total number of mutually exclusive classes (C).
        label_thresholds (Optional[List[float]]): Boundaries used to bucket continuous values.
        class_names (Optional[List[str]]): Human-readable names for the classes.
        label_type (str): 'continuous', 'raw', or 'one_hot'.
        preds_type (str): Expected shape of predictions.
                          Supported: 'NG', 'NGC', 'N' (if G=1), 'NC' (if G=1).
        target_type (str): Expected shape of targets.
                            Supported: 'NG', 'NGC', 'N' (if G=1), 'NC' (if G=1).
        flatten_output (bool): If True, returns a single flat dictionary.
        separator (str): The string used to join nested keys. Defaults to "_".
        **kwargs: Additional arguments passed to the underlying metric.
    """

    def __init__(
            self,
            group_names: List[str],
            num_classes: int,
            label_thresholds: Optional[List[float]] = None,
            class_names: Optional[List[str]] = None,
            label_type: str = 'continuous',
            preds_type: str = 'NG',     # <--- EXPLICIT ROUTING
            target_type: str = 'NG',   # <--- EXPLICIT ROUTING
            flatten_output: bool = True,
            separator: str = "_",
            **kwargs
    ):
        super().__init__()

        self.group_names = group_names
        self.num_classes = num_classes
        self.flatten_output = flatten_output
        self.separator = separator
        self.num_groups = len(group_names)

        self.preds_type = preds_type.upper()
        self.target_type = target_type.upper()
        self._valid_types = ['N', 'NG', 'NC', 'NGC']

        # ---------------------------------------------------------------------
        # Parameter Validation
        # ---------------------------------------------------------------------
        if class_names is not None and len(class_names) != num_classes:
            raise ValueError(f"len(class_names) ({len(class_names)}) must equal num_classes.")

        if label_thresholds is not None and num_classes != len(label_thresholds) + 1:
            raise ValueError(f"When using thresholds, len(label_thresholds)+1 ({len(label_thresholds)}+1) must equal num_classes ({num_classes}).")

        if self.preds_type not in self._valid_types:
            raise ValueError(f"preds_type must be one of {self._valid_types}, got {self.preds_type}.")
        if self.target_type not in self._valid_types:
            raise ValueError(f"target_type must be one of {self._valid_types}, got {self.target_type}.")

        # ---------------------------------------------------------------------
        # Sub-Metric Initialization
        # ---------------------------------------------------------------------
        self.metrics = torch.nn.ModuleDict({
            name: ValueMapMulticlassCurve(
                num_classes=num_classes,
                label_type=label_type,
                label_thresholds=label_thresholds,
                class_names=class_names,
                flatten_output=self.flatten_output,
                separator=self.separator,
                **kwargs
            ) for name in self.group_names
        })

    def _extract_group_data(self, x: Tensor, x_type: str, group_idx: int, name: str) -> Tensor:
        """
        Safely slices the tensor based on explicit type declarations, bypassing `ndim` ambiguity.
        """
        if x_type == 'N':
            if self.num_groups != 1:
                raise ValueError(f"Type '{x_type}' for {name} is only valid when num_groups == 1.")
            if x.ndim != 1:
                raise ValueError(f"Expected 1D tensor [N] for {name}_type 'N', got {x.ndim}D.")
            return x  # Child sees [N]

        elif x_type == 'NC':
            if self.num_groups != 1:
                raise ValueError(f"Type '{x_type}' for {name} is only valid when num_groups == 1.")
            if x.ndim != 2:
                raise ValueError(f"Expected 2D tensor [N, C] for {name}_type 'NC', got {x.ndim}D.")
            return x  # Child sees [N, C]

        elif x_type == 'NG':
            if x.ndim != 2:
                raise ValueError(f"Expected 2D tensor [N, G] for {name}_type 'NG', got {x.ndim}D.")
            if x.shape[1] != self.num_groups:
                raise ValueError(f"{name} sequence length ({x.shape[1]}) != num_groups ({self.num_groups}).")
            return x[:, group_idx]  # Slice group, child sees [N]

        elif x_type == 'NGC':
            if x.ndim != 3:
                raise ValueError(f"Expected 3D tensor [N, G, C] for {name}_type 'NGC', got {x.ndim}D.")
            if x.shape[1] != self.num_groups:
                raise ValueError(f"{name} sequence length ({x.shape[1]}) != num_groups ({self.num_groups}).")
            return x[:, group_idx, :]  # Slice group, child sees [N, C]

    def update(self, preds: Tensor, target: Tensor) -> None:
        """Routes the batch data to the appropriate group metric using explicit types."""
        for i, name in enumerate(self.group_names):
            group_preds = self._extract_group_data(preds, self.preds_type, i, 'preds')
            group_target = self._extract_group_data(target, self.target_type, i, 'targets')

            self.metrics[name].update(group_preds, group_target)

    def compute(self) -> Dict[str, Any]:
        results = {}
        for name in self.group_names:
            group_res = self.metrics[name].compute()
            if self.flatten_output:
                for k, v in group_res.items():
                    results[f"{name}{self.separator}{k}"] = v
            else:
                results[name] = group_res
        return results


