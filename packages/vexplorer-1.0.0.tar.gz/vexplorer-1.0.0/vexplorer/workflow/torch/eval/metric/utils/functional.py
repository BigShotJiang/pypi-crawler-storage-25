
import torch
from torch import Tensor
from typing import Tuple, Optional


def safe_divide(
    numerator: Tensor,
    denominator: Tensor,
    epsilon: float = 1e-7,
    zero_division: float = 0.0
) -> Tensor:
    """
    Safely divide two tensors, handling zero denominators.

    When denominator is zero (or very close to zero), returns zero_division value
    instead of NaN or Inf.

    Args:
        numerator: Numerator tensor
            Shape: Any shape

        denominator: Denominator tensor
            Shape: Must be broadcastable with numerator

        epsilon: Small value threshold for detecting zero
            Default: 1e-7

        zero_division: Value to return when denominator is zero
            Default: 0.0

    Returns:
        Result of division with zero-safe handling
        Shape: Broadcast shape of numerator and denominator

    Examples:
        >>> # Normal division
        >>> safe_divide(torch.tensor([10.0, 20.0]), torch.tensor([2.0, 4.0]))
        tensor([5.0, 5.0])

        >>> # Zero denominator - returns zero_division value
        >>> safe_divide(torch.tensor([10.0]), torch.tensor([0.0]))
        tensor([0.0])

    Notes:
        - Returns zero_division when denominator is near zero
        - Preserves gradient flow (differentiable)
        - Works with any tensor shape through broadcasting
    """
    # Ensure floating point
    numerator = numerator if numerator.is_floating_point() else numerator.float()
    denominator = denominator if denominator.is_floating_point() else denominator.float()

    # Use torch.where for safe division
    zero_val = torch.tensor(zero_division, dtype=numerator.dtype, device=numerator.device)
    return torch.where(
        torch.abs(denominator) > epsilon,
        numerator / denominator,
        zero_val
    )


def check_same_shape(
    tensor1: Tensor,
    tensor2: Tensor,
    name1: str = "tensor1",
    name2: str = "tensor2"
) -> None:
    """
    Verify two tensors have identical shapes.
    
    Raises ValueError with descriptive message if shapes don't match.
    Useful for validating predictions and targets before metric computation.
    
    Args:
        tensor1: First tensor
        tensor2: Second tensor
        name1: Name of first tensor for error message
        name2: Name of second tensor for error message
    
    Raises:
        ValueError: If shapes don't match
    
    Examples:
        >>> preds = torch.randn(100, 10)
        >>> target = torch.randint(0, 10, (100,))
        >>> check_same_shape(preds, target, "predictions", "targets")
        ValueError: Shape mismatch: predictions has shape [100, 10] 
                   but targets has shape [100]
        
        >>> # Correct usage
        >>> preds = torch.randn(100)
        >>> target = torch.randn(100)
        >>> check_same_shape(preds, target)  # No error
    
    Notes:
        - Use before element-wise operations
        - Provides clear error messages for debugging
        - Zero-cost when shapes match (no computation)
    """
    if tensor1.shape != tensor2.shape:
        raise ValueError(
            f"Shape mismatch: {name1} has shape {list(tensor1.shape)} "
            f"but {name2} has shape {list(tensor2.shape)}"
        )


def to_onehot(
    indices: Tensor,
    num_classes: int,
    device: Optional[torch.device] = None
) -> Tensor:
    """
    Convert class indices to one-hot encoded tensor.
    
    Transforms integer class labels into binary matrix representation
    where each row has a single 1 in the position of the true class.
    
    Args:
        indices: Class indices
            Shape: [N] or [N, ...]
            Values: Integers in range [0, num_classes-1]
            
        num_classes: Total number of classes
            Must be > max(indices)
            
        device: Target device for output tensor
            If None, uses same device as indices
    
    Returns:
        One-hot encoded tensor
        Shape: [..., num_classes]
        Last dimension is one-hot encoding
    
    Examples:
        >>> # Simple case
        >>> indices = torch.tensor([0, 2, 1])
        >>> to_onehot(indices, num_classes=3)
        tensor([[1, 0, 0],
                [0, 0, 1],
                [0, 1, 0]])
        
        >>> # 2D indices
        >>> indices = torch.tensor([[0, 1], [2, 0]])
        >>> to_onehot(indices, num_classes=3)
        tensor([[[1, 0, 0], [0, 1, 0]],
                [[0, 0, 1], [1, 0, 0]]])
    
    Notes:
        - Efficient GPU implementation using scatter
        - Handles arbitrary input dimensions
        - Output dtype matches PyTorch default (float32)
    """
    if device is None:
        device = indices.device
    
    # Flatten indices for processing
    original_shape = indices.shape
    indices_flat = indices.flatten()
    
    # Create one-hot encoding
    onehot = torch.zeros(
        indices_flat.shape[0],
        num_classes,
        device=device,
        dtype=torch.float32
    )
    onehot.scatter_(1, indices_flat.unsqueeze(1), 1)
    
    # Reshape to original dimensions + num_classes
    output_shape = list(original_shape) + [num_classes]
    return onehot.view(output_shape)


def apply_threshold(
    predictions: Tensor,
    threshold: float = 0.5
) -> Tensor:
    """
    Apply threshold to convert continuous predictions to binary.
    
    Args:
        predictions: Continuous predictions
            Shape: Any shape
            Values: Any range (commonly [0,1] or logits)
            
        threshold: Decision threshold
            Default: 0.5
            Predictions >= threshold → 1
            Predictions < threshold → 0
    
    Returns:
        Binary predictions (0 or 1)
        Shape: Same as input
        Dtype: Long (int64)
    
    Examples:
        >>> preds = torch.tensor([0.2, 0.5, 0.7, 0.9])
        >>> apply_threshold(preds, threshold=0.5)
        tensor([0, 1, 1, 1])
        
        >>> # Works with any range
        >>> logits = torch.tensor([-2, 0, 2, 4])
        >>> apply_threshold(logits, threshold=0.0)
        tensor([0, 1, 1, 1])
    
    Notes:
        - Threshold is inclusive: >= threshold → 1
        - Returns long tensor for indexing operations
        - No sigmoid applied - use raw predictions
    """
    return (predictions >= threshold).long()


def tensor_to_python_scalar(tensor: Tensor) -> float:
    """
    Safely convert a tensor to Python scalar.
    
    Handles both scalar tensors and single-element tensors.
    Useful for comparisons and printing.
    
    Args:
        tensor: Input tensor
            Must have exactly one element
    
    Returns:
        Python float value
    
    Raises:
        ValueError: If tensor has more than one element
    
    Examples:
        >>> # Scalar tensor
        >>> t = torch.tensor(3.14)
        >>> tensor_to_python_scalar(t)
        3.14
        
        >>> # Single-element tensor
        >>> t = torch.tensor([42.0])
        >>> tensor_to_python_scalar(t)
        42.0
        
        >>> # Multi-element tensor - error
        >>> t = torch.tensor([1, 2, 3])
        >>> tensor_to_python_scalar(t)
        ValueError: Cannot convert tensor with 3 elements to scalar
    
    Notes:
        - Use this for tensor comparisons with Python values
        - Avoids "Tensor and Python number" comparison warnings
        - More explicit than tensor == 0 (which works but warns)
    """
    if tensor.numel() != 1:
        raise ValueError(
            f"Cannot convert tensor with {tensor.numel()} elements to scalar. "
            f"Expected single-element tensor."
        )
    return tensor.item()


def is_tensor_zero(tensor: Tensor, epsilon: float = 1e-9) -> bool:
    """
    Check if a tensor is (approximately) zero.
    
    For scalar or single-element tensors, checks if value is
    within epsilon of zero. More robust than direct comparison.
    
    Args:
        tensor: Tensor to check
            Should be scalar or single-element
            
        epsilon: Tolerance for "close to zero"
            Default: 1e-9
    
    Returns:
        True if tensor value is within epsilon of zero
    
    Examples:
        >>> is_tensor_zero(torch.tensor(0.0))
        True
        
        >>> is_tensor_zero(torch.tensor(1e-10))
        True  # Within default epsilon
        
        >>> is_tensor_zero(torch.tensor(0.001))
        False
        
        >>> # Correct way to check tensor values
        >>> count = torch.tensor(0)
        >>> if is_tensor_zero(count):  # Good
        ...     print("No samples")
        >>> if count == 0:  # Avoid - may cause warnings
        ...     print("No samples")
    
    Notes:
        - Preferred over: if tensor == 0
        - Handles floating point imprecision
        - Works on CPU and GPU tensors
    """
    if tensor.numel() != 1:
        raise ValueError(
            f"is_tensor_zero expects scalar tensor, got shape {tensor.shape}"
        )
    return abs(tensor_to_python_scalar(tensor)) < epsilon


def broadcast_shapes(*shapes: Tuple[int, ...]) -> Tuple[int, ...]:
    """
    Compute broadcast shape for multiple tensor shapes.
    
    Follows NumPy/PyTorch broadcasting rules to find the output
    shape when tensors are broadcast together.
    
    Args:
        *shapes: Variable number of shape tuples
    
    Returns:
        Broadcast output shape
    
    Raises:
        ValueError: If shapes are not broadcast-compatible
    
    Examples:
        >>> broadcast_shapes((3, 1), (1, 4))
        (3, 4)
        
        >>> broadcast_shapes((5, 1, 3), (1, 4, 3))
        (5, 4, 3)
        
        >>> # Incompatible
        >>> broadcast_shapes((3, 4), (4, 5))
        ValueError: Shapes (3, 4) and (4, 5) cannot be broadcast
    
    Notes:
        - Useful for validating operations before execution
        - Implements PyTorch broadcasting semantics
        - Aligns shapes from the right
    """
    if not shapes:
        return ()
    
    # Find maximum number of dimensions
    max_dims = max(len(s) for s in shapes)
    
    # Pad all shapes to same length (from left)
    padded = [
        (1,) * (max_dims - len(s)) + s
        for s in shapes
    ]
    
    # Compute broadcast result dimension by dimension
    result = []
    for dims in zip(*padded):
        # All must be 1 or same value
        non_one_dims = [d for d in dims if d != 1]
        if not non_one_dims:
            result.append(1)
        elif all(d == non_one_dims[0] for d in non_one_dims):
            result.append(non_one_dims[0])
        else:
            raise ValueError(
                f"Shapes {shapes} cannot be broadcast together. "
                f"Dimension mismatch: {dims}"
            )
    
    return tuple(result)
