from typing import Any, Optional, Union
import torch
from torch import Tensor

from .enums import DistributedReduceOp


def _get_nccl_device() -> torch.device:
    """
    Get a CUDA or NPU device for collective operations.

    When the NCCL/HCCL backend is in use, all tensors must reside on CUDA/NPU.
    This helper returns the current device so that CPU tensors
    can be temporarily moved there before a collective call.

    Returns:
        torch.device for the current CUDA/NPU device, or cpu if unavailable.
    """
    if torch.cuda.is_available():
        return torch.device('cuda', torch.cuda.current_device())
    if hasattr(torch, 'npu') and torch.npu.is_available():
        return torch.device('npu', torch.npu.current_device())
    return torch.device('cpu')


def _is_nccl_backend(group: Optional[Any] = None) -> bool:
    """Check whether the process group uses the NCCL or HCCL backend."""
    try:
        backend = torch.distributed.get_backend(group)
        return backend in ('nccl', 'hccl')
    except Exception:
        return False


def is_distributed() -> bool:
    """
    Check if running in distributed mode.
    
    Returns:
        True if distributed training is enabled, False otherwise
    """
    return torch.distributed.is_available() and torch.distributed.is_initialized()


def get_world_size() -> int:
    """
    Get the number of processes in distributed training.
    
    Returns:
        Number of processes (world size), 1 if not distributed
    """
    if is_distributed():
        return torch.distributed.get_world_size()
    return 1


def get_rank() -> int:
    """
    Get current process rank in distributed training.
    
    Returns:
        Process rank (0-indexed), 0 if not distributed
    """
    if is_distributed():
        return torch.distributed.get_rank()
    return 0


def distributed_reduce(
    tensor: Tensor,
    reduce_op: Union[DistributedReduceOp, str] = DistributedReduceOp.SUM,
    group: Optional[Any] = None,
) -> Tensor:
    """
    Reduce tensor across all processes in distributed training.
    
    Supports all reduction operations:
    - SUM: Sum values across all processes
    - MEAN: Average values across all processes
    - MAX: Maximum value across all processes
    - MIN: Minimum value across all processes
    - PROD: Product of values across all processes
    - CAT: Concatenate tensors across all processes (along dim 0)
    
    Args:
        tensor: Tensor to reduce
        reduce_op: Reduction operation to perform
        group: Process group (None for default group)
        
    Returns:
        Reduced tensor
        
    Example::

        # Sum gradients across all GPUs
        reduced = distributed_reduce(grads, DistributedReduceOp.SUM)

        # Get maximum loss across all processes
        max_loss = distributed_reduce(loss, DistributedReduceOp.MAX)

        # Gather all predictions
        all_preds = distributed_reduce(preds, DistributedReduceOp.CAT)
    """
    if not is_distributed():
        return tensor
    
    # Convert string to enum
    if isinstance(reduce_op, str):
        reduce_op = DistributedReduceOp(reduce_op)
    
    # Handle concatenation separately
    if reduce_op == DistributedReduceOp.CAT:
        return _distributed_cat(tensor, group)
    
    # Map our enum to PyTorch reduce ops
    op_mapping = {
        DistributedReduceOp.SUM: torch.distributed.ReduceOp.SUM,
        DistributedReduceOp.MAX: torch.distributed.ReduceOp.MAX,
        DistributedReduceOp.MIN: torch.distributed.ReduceOp.MIN,
        DistributedReduceOp.PROD: torch.distributed.ReduceOp.PRODUCT,
    }
    
    # NCCL backend requires CUDA tensors; move CPU tensors temporarily
    original_device = tensor.device
    if original_device.type == 'cpu' and _is_nccl_backend(group):
        tensor = tensor.to(_get_nccl_device())

    if reduce_op == DistributedReduceOp.MEAN:
        # MEAN: sum then divide by world size
        output = tensor.clone()
        torch.distributed.all_reduce(output, op=torch.distributed.ReduceOp.SUM, group=group)
        output = output / get_world_size()
        return output.to(original_device)

    # Standard reduce operations
    if reduce_op in op_mapping:
        output = tensor.clone()
        torch.distributed.all_reduce(output, op=op_mapping[reduce_op], group=group)
        return output.to(original_device)
    
    raise ValueError(f"Unsupported reduce operation: {reduce_op}")


def _distributed_cat(tensor: Tensor, group: Optional[Any] = None) -> Tensor:
    """
    Concatenate tensors across all processes.
    
    Args:
        tensor: Tensor to concatenate
        group: Process group
        
    Returns:
        Concatenated tensor from all processes
    """
    if not is_distributed():
        return tensor

    world_size = get_world_size()

    # NCCL backend requires CUDA tensors; move CPU tensors temporarily
    original_device = tensor.device
    if original_device.type == 'cpu' and _is_nccl_backend(group):
        tensor = tensor.to(_get_nccl_device())

    # Gather tensor sizes from all processes
    local_size = torch.tensor([tensor.shape[0]], device=tensor.device)
    size_list = [torch.zeros_like(local_size) for _ in range(world_size)]
    torch.distributed.all_gather(size_list, local_size, group=group)

    # Get max size for padding
    max_size = max(s.item() for s in size_list)

    # Pad tensor if needed
    if tensor.shape[0] < max_size:
        pad_size = max_size - tensor.shape[0]
        padding = torch.zeros(
            (pad_size,) + tensor.shape[1:],
            dtype=tensor.dtype,
            device=tensor.device
        )
        padded_tensor = torch.cat([tensor, padding], dim=0)
    else:
        padded_tensor = tensor

    # Gather all tensors
    gathered_tensors = [
        torch.zeros_like(padded_tensor) for _ in range(world_size)
    ]
    torch.distributed.all_gather(gathered_tensors, padded_tensor, group=group)

    # Remove padding and concatenate
    result_list = []
    for i, gathered in enumerate(gathered_tensors):
        actual_size = size_list[i].item()
        result_list.append(gathered[:actual_size])

    result = torch.cat(result_list, dim=0)

    # Move back to original device if we migrated from CPU
    return result.to(original_device)


def sync_devices(tensor: Tensor) -> Tensor:
    """
    Synchronize tensor across all devices.
    
    This ensures all processes wait for tensor operations to complete
    before proceeding. Useful for barriers and synchronization points.
    
    Args:
        tensor: Tensor to synchronize
        
    Returns:
        Same tensor after synchronization
    """
    if is_distributed():
        torch.distributed.barrier()
    return tensor


def broadcast_tensor(
    tensor: Tensor,
    src: int = 0,
    group: Optional[Any] = None
) -> Tensor:
    """
    Broadcast tensor from source process to all processes.
    
    Args:
        tensor: Tensor to broadcast (only value from src matters)
        src: Source process rank
        group: Process group
        
    Returns:
        Broadcasted tensor (same value on all processes)
    """
    if not is_distributed():
        return tensor
    
    output = tensor.clone()
    torch.distributed.broadcast(output, src=src, group=group)
    return output


class DistributedMetricState:
    """
    Container for distributed metric state with automatic reduction.
    
    This class manages metric state variables and handles distributed
    reduction automatically when compute() is called.
    
    Attributes:
        reduce_op: Reduction operation to apply
        value: Current state value
        
    Example::

        # In metric __init__
        self.total = DistributedMetricState(
            reduce_op=DistributedReduceOp.SUM,
            value=torch.tensor(0.0)
        )

        # In update()
        self.total.value += batch_size

        # In compute() - automatic reduction
        total = self.total.reduce()
    """
    
    def __init__(
        self,
        reduce_op: Union[DistributedReduceOp, str] = DistributedReduceOp.SUM,
        value: Optional[Tensor] = None
    ):
        """
        Initialize distributed metric state.
        
        Args:
            reduce_op: Reduction operation for distributed training
            value: Initial value (optional)
        """
        self.reduce_op = reduce_op
        self.value = value if value is not None else torch.tensor(0.0)
        self._reduced = False
    
    def reduce(self, group: Optional[Any] = None) -> Tensor:
        """
        Apply distributed reduction.
        
        Args:
            group: Process group
            
        Returns:
            Reduced value
        """
        if not self._reduced and is_distributed():
            self.value = distributed_reduce(self.value, self.reduce_op, group)
            self._reduced = True
        return self.value
    
    def reset(self) -> None:
        """Reset state for new epoch."""
        self.value = torch.zeros_like(self.value)
        self._reduced = False
