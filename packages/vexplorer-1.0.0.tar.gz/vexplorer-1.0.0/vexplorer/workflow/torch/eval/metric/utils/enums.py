

from enum import Enum


class DistributedReduceOp(str, Enum):
    """Distributed reduction operations."""
    SUM = "sum"
    MEAN = "mean"
    MAX = "max"
    MIN = "min"
    PROD = "prod"
    CAT = "cat"


class AverageMethod(str, Enum):
    """Averaging methods for classification metrics."""
    MICRO = "micro"
    MACRO = "macro"
    WEIGHTED = "weighted"
    SAMPLES = "samples"
    NONE = "none"


# Alias for backward compatibility
ClassificationAverageMethod = AverageMethod


class RegressionAggregationMethod(str, Enum):
    """Aggregation methods for regression metrics."""
    ELEMENTWISE = "elementwise"
    SAMPLEWISE = "samplewise"


class ThresholdSelectionMethod(str, Enum):
    """Methods for selecting optimal classification thresholds."""
    MAX_YOUDENJ = "max_youdenj"
    MIN_DISTANCE = "min_distance"
    MAX_F1 = "max_f1"
    MAX_TSS = "max_tss"
    MAX_F_BETA = "max_f_beta"
    MAX_ACCURACY = "max_accuracy"
    MAX_PRECISION = "max_precision"
    MAX_RECALL = "max_recall"
    MIN_COST = "min_cost"
    SENSITIVITY_CONSTRAINT = "sensitivity_constraint"
    SPECIFICITY_CONSTRAINT = "specificity_constraint"
    PRECISION_CONSTRAINT = "precision_constraint"


# Alias for backward compatibility
ThresholdMethod = ThresholdSelectionMethod


class ClassificationCurveType(str, Enum):
    """Types of classification curves."""
    ROC = "roc"
    PRECISION_RECALL = "precision_recall"
    LOG_ROC = "log_roc"
    CUSTOM = "custom"


# Alias for backward compatibility
CurveType = ClassificationCurveType


class TaskType(str, Enum):
    """Machine learning task types."""
    BINARY = "binary"
    MULTICLASS = "multiclass"
    MULTILABEL = "multilabel"
    REGRESSION = "regression"


class DeviceType(str, Enum):
    """Supported device types."""
    CPU = "cpu"
    CUDA = "cuda"
    NPU = "npu"
    TPU = "tpu"
    MPS = "mps"
    AUTO = "auto"
