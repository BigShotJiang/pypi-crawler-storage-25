

from collections import OrderedDict
from dataclasses import dataclass, field
from typing import Any, Callable, Dict, List, Optional, Union

import torch

from ..base import BaseTorchMetric, BaseTorchManager


@dataclass
class DirectMetricWrapper:
    """
    Configuration wrapper for metrics managed by DirectMetricManager.

    Controls priority ordering and optional input transformations for each metric.
    All metrics receive the same args and kwargs directly (broadcast mode).

    Parameters
    ----------
    priority : int
        Computation priority. Lower values are computed first.
        Metrics with the same priority are ordered alphabetically by name.
        Default: 0.
    input_transform : Dict[str, Callable]
        Dictionary mapping kwarg keys to callable transform.
        Transforms are applied to kwargs before passing to the metric.
        Keys are the kwarg names in manager.update().
        Default: empty dict (no transform).
    arg_transform : Dict[int, Callable]
        Dictionary mapping positional argument indices to callable transform.
        Transforms are applied to args before passing to the metric.
        Keys are the argument indices.
        Default: empty dict (no transform).

    Examples
    --------
    >>> # Simple wrapper with priority
    >>> wrapper = DirectMetricWrapper(priority=1)
    >>>
    >>> # Wrapper with transform on specific kwarg
    >>> wrapper = DirectMetricWrapper(
    ...     priority=0,
    ...     input_transform={'preds': lambda x: torch.sigmoid(x)}
    ... )
    >>>
    >>> # Wrapper with both arg and kwarg transform
    >>> wrapper = DirectMetricWrapper(
    ...     priority=0,
    ...     arg_transform={0: lambda x: x.sigmoid()},
    ...     input_transform={'target': lambda x: x.float()}
    ... )

    Notes
    -----
    - All metrics receive the same arguments (broadcast mode)
    - Transforms are applied per-metric, allowing different views of same data
    - Priority controls computation order for consistency
    """
    priority: int = 0
    input_transform: Dict[str, Callable] = field(default_factory=dict)
    arg_transform: Dict[int, Callable] = field(default_factory=dict)

    def __post_init__(self):
        if self.arg_transform is None:
            self.arg_transform = {}
        if self.input_transform is None:
            self.input_transform = {}




class DirectMetricManager(BaseTorchManager):
    """
    Direct metric manager for managing multiple metrics with direct argument passing.

    DirectMetricManager passes all arguments directly to each metric without
    any routing or remapping. This manager allows all metrics to see the same
    inputs (optionally with per-metric transform), with priority-based ordering.

    Key differences from other managers:
    - **Direct**: All metrics get all args/kwargs (broadcast mode)
    - **List**: Metrics can select specific args by index
    - **Dict**: Metrics can remap kwargs by key

    Parameters
    ----------
    detach : bool
        Whether to detach tensors before passing to metrics.
        Default: True.
    clone : bool
        Whether to clone tensors before passing to metrics.
        Default: False.

    Attributes
    ----------
    _metrics : OrderedDict[str, BaseTorchMetric]
        Ordered dictionary mapping metric names to metric instances.
    _wrappers : Dict[str, Optional[DirectMetricWrapper]]
        Dictionary mapping metric names to wrappers.
    _sorted_names : List[str]
        Cached list of metric names sorted by priority.

    Examples
    --------
    >>> from metrics.regression.mae import MeanAbsoluteError
    >>> from metrics.regression.mse import MeanSquaredError
    >>>
    >>> manager = DirectMetricManager()
    >>>
    >>> # Simple usage: multiple metrics receiving same inputs
    >>> manager.add_metric('mae', MeanAbsoluteError())
    >>> manager.add_metric('mse', MeanSquaredError())
    >>> manager.update(preds, target)
    >>> results = manager.compute()
    >>> # results = {'mae': tensor(...), 'mse': tensor(...)}
    >>>
    >>> # With priority ordering
    >>> wrapper1 = DirectMetricWrapper(priority=0)
    >>> wrapper2 = DirectMetricWrapper(priority=1)
    >>> manager.add_metric('metric_a', metric_a, wrapper=wrapper1)
    >>> manager.add_metric('metric_b', metric_b, wrapper=wrapper2)
    >>> # metric_a computed first, then metric_b
    >>>
    >>> # With transform (different views of same input)
    >>> wrapper_sigmoid = DirectMetricWrapper(
    ...     input_transform={'preds': lambda x: torch.sigmoid(x)}
    ... )
    >>> manager.add_metric('mae_sigmoid', MeanAbsoluteError(), wrapper=wrapper_sigmoid)
    >>> manager.add_metric('mae_raw', MeanAbsoluteError())
    >>> manager.update(preds=logits, target=targets)
    >>> # mae_sigmoid sees sigmoid(logits), mae_raw sees raw logits

    Notes
    -----
    - All metrics receive the same arguments (broadcast)
    - Metrics are updated and computed in priority order (lowest first)
    - Transforms allow different metrics to see different views of same input
    - Simplest manager for combining multiple metrics on same data
    """

    def __init__(
        self,
        detach: bool = True,
        clone: bool = False,
        **kwargs,
    ):
        """
        Initialize DirectMetricManager.

        Parameters
        ----------
        detach : bool
            Whether to detach tensors.
        clone : bool
            Whether to clone tensors.
        """
        super().__init__(detach=detach, clone=clone, **kwargs)
        self._metrics: OrderedDict[str, BaseTorchMetric] = OrderedDict()
        self._wrappers: Dict[str, Optional[DirectMetricWrapper]] = {}
        self._sorted_names: List[str] = []

    def _rebuild_sorted_names(self) -> None:
        """
        Rebuild the priority-sorted list of metric names.

        Sorting rules:
        1. Primary: ascending by wrapper.priority (lower = higher priority)
        2. Secondary: ascending by name (alphabetical)
        """
        self._sorted_names = sorted(
            self._metrics.keys(),
            key=lambda name: (
                self._wrappers[name].priority if self._wrappers[name] is not None else 0,
                name
            ),
        )

    def add_metric(
        self,
        name: str,
        metric: BaseTorchMetric,
        wrapper: Optional[DirectMetricWrapper] = None,
        build = False,
    ) -> None:
        """
        Add a metric to the manager.

        Parameters
        ----------
        name : str
            Unique name identifier for the metric.
        metric : BaseTorchMetric
            The metric to add.
        wrapper : Optional[DirectMetricWrapper]
            Configuration wrapper for priority and transform. Default: None.

        Raises
        ------
        ValueError
            If the name is already registered.
        TypeError
            If wrapper is not a DirectMetricWrapper instance.

        Examples
        --------
        >>> manager = DirectMetricManager()
        >>>
        >>> # Add metric without wrapper
        >>> manager.add_metric('mae', MeanAbsoluteError())
        >>>
        >>> # Add metric with priority and transform
        >>> wrapper = DirectMetricWrapper(
        ...     priority=1,
        ...     input_transform={'preds': torch.sigmoid}
        ... )
        >>> manager.add_metric('mae_sigmoid', MeanAbsoluteError(), wrapper=wrapper)
        """
        if name in self._metrics:
            raise ValueError(f"Metric '{name}' already exists in DirectMetricManager")

        if wrapper is not None and not isinstance(wrapper, DirectMetricWrapper):
            raise TypeError(
                f"wrapper must be a DirectMetricWrapper instance, "
                f"got {type(wrapper).__name__}."
            )

        self._metrics[name] = metric
        self._wrappers[name] = wrapper
        if build:
            self.build()

    def build(self):
        self._rebuild_sorted_names()

    def update(self, *args, **kwargs) -> None:
        """
        Update all metrics with the same inputs.

        All metrics receive the same arguments (optionally transformed per-metric).

        Parameters
        ----------
        *args
            Positional arguments passed to all metrics.
        **kwargs
            Keyword arguments passed to all metrics.

        Examples
        --------
        >>> manager = DirectMetricManager()
        >>> manager.add_metric('mae', MeanAbsoluteError())
        >>> manager.add_metric('mse', MeanSquaredError())
        >>>
        >>> preds = torch.randn(10, 5)
        >>> target = torch.randn(10, 5)
        >>>
        >>> # Both metrics receive same arguments
        >>> manager.update(preds, target)
        >>> # Or with kwargs:
        >>> manager.update(preds=preds, target=target)
        """
        # Prepare inputs
        args = self._prepare_args(args)
        kwargs = self._prepare_kwargs(kwargs)

        # Update metrics in priority order
        for name in self._sorted_names:
            metric = self._metrics[name]
            wrapper = self._wrappers[name]

            # Prepare metric-specific args and kwargs (apply transform)
            metric_args = args
            metric_kwargs = kwargs.copy()

            if wrapper is not None:
                # Apply argument transform
                if wrapper.arg_transform:
                    metric_args = tuple(
                        wrapper.arg_transform.get(i, lambda x: x)(arg)
                        for i, arg in enumerate(metric_args)
                    )

                # Apply kwarg transform
                if wrapper.input_transform:
                    metric_kwargs = {
                        k: wrapper.input_transform.get(k, lambda x: x)(v)
                        for k, v in metric_kwargs.items()
                    }

            # Update metric
            metric.update(*metric_args, **metric_kwargs)

    # def to(self, device: Union[str, torch.device]) -> 'DirectMetricManager':
    #     """
    #     Move all metrics to the specified device.
    #
    #     Parameters
    #     ----------
    #     device : Union[str, torch.device]
    #         Target device.
    #
    #     Returns
    #     -------
    #     DirectMetricManager
    #         Self for method chaining.
    #     """
    #     if isinstance(device, str):
    #         device = torch.device(device)
    #
    #     for metric in self._metrics.values():
    #         metric.to(device)
    #
    #     super().to(device)
    #     return self

    def to(self, device: Union[str, torch.device]) -> 'DirectMetricManager':
        """
        Move all metrics and supported transforms to the specified device.

        Parameters
        ----------
        device : Union[str, torch.device]
            Target device.

        Returns
        -------
        DirectMetricManager
            Self for method chaining.
        """
        if isinstance(device, str):
            device = torch.device(device)

        # 1. 移动所有的 Metric
        for metric in self._metrics.values():
            metric.to(device)

        # 2. 遍历所有的 Wrapper，处理可能的 transform
        for wrapper in self._wrappers.values():
            if wrapper is not None:
                # 处理针对 kwargs 的 input_transform
                for transform_func in wrapper.input_transform.values():
                    if hasattr(transform_func, 'to') and callable(transform_func.to):
                        transform_func.to(device)

                # 处理针对 args 的 arg_transform
                for transform_func in wrapper.arg_transform.values():
                    if hasattr(transform_func, 'to') and callable(transform_func.to):
                        transform_func.to(device)

        # 3. 调用父类的 to 方法
        super().to(device)
        return self

    def compute(self) -> Dict[str, Any]:
        """
        Compute all metrics and return results as a flat dictionary.

        Returns
        -------
        Dict[str, Any]
            {metric_name: metric_result} for all managed metrics, in priority order.

        Examples
        --------
        >>> results = manager.compute()
        >>> # {'mae': tensor(0.5), 'mse': tensor(0.25)}
        """
        results = {}
        for name in self._sorted_names:
            results[name] = self._metrics[name].compute()
        return results

    def reset(self) -> None:
        """
        Reset all managed metrics to prepare for the next epoch.

        Examples
        --------
        >>> for epoch in range(num_epochs):
        ...     manager.reset()
        ...     for batch in loader:
        ...         manager.update(preds, target)
        ...     print(manager.compute())
        """
        for metric in self._metrics.values():
            metric.reset()

    def del_metric(self, name: str) -> None:
        """
        Remove a metric from the manager by name.

        Parameters
        ----------
        name : str
            Name of the metric to remove.

        Raises
        ------
        KeyError
            If the name is not found.

        Examples
        --------
        >>> manager.del_metric('mae')
        """
        if name not in self._metrics:
            raise KeyError(
                f"Metric '{name}' not found in the manager. "
                f"Available metrics: {list(self._metrics.keys())}"
            )
        del self._metrics[name]
        del self._wrappers[name]
        self._rebuild_sorted_names()


# Backward compatibility alias
DirectManager = DirectMetricManager
