# -*- coding: utf-8 -*-

import torch
from torch import Tensor
from typing import Optional
from ..base import BaseTorchMetric
from ..utils.decorator import auto_update, auto_compute
from ..utils.enums import DistributedReduceOp, RegressionAggregationMethod
from ..utils.functional import tensor_to_python_scalar

__all__ = [
    "PeakSignalNoiseRatio",
    "PSNR",
]

# Supported input_format strings and their expected ndim
_INPUT_FORMAT_NDIM = {
    'HW': 2,       # Single grayscale image [H, W]
    'CHW': 3,      # Single image with channels [C, H, W]
    'NHW': 3,      # Batch of grayscale [N, H, W]
    'NCHW': 4,     # Batch of 2D images [N, C, H, W] (default)
    'NCDHW': 5,    # Batch of 3D volumes [N, C, D, H, W]
}


class PeakSignalNoiseRatio(BaseTorchMetric):
    """Peak Signal-to-Noise Ratio (PSNR) for image quality assessment.

    Full name: PeakSignalNoiseRatio
    Alias: PSNR

    Formula:
        PSNR = 10 * log10((data_range^2) / MSE)

    Can accept MSE from manager pipeline or compute directly from images.

    Args:
        data_range (Optional[float]): Maximum pixel value range.
            - None: Inferred from data (max - min)
            - Common: 1.0 (normalized), 255.0 (8-bit), 65535.0 (16-bit)
        input_format: Specifies the dimension layout of the input images.
            Supported formats:
            - 'NCHW': [N, C, H, W] batch of 2D images (default)
            - 'NCDHW': [N, C, D, H, W] batch of 3D volumes
            - 'NHW': [N, H, W] batch of grayscale images (no channel dim)
            - 'CHW': [C, H, W] single image with channels
            - 'HW': [H, W] single grayscale image
            This avoids ambiguity when ndim=3 (is it NHW or CHW?).
        aggregation: 'elementwise' or 'samplewise'
        accept_mse_from_pipeline: If True, can accept pre-computed MSE
        epsilon: Small value to avoid division by zero
        **kwargs: Additional arguments for BaseTorchMetric

    Input Shapes:
        **Option 1: From images**
        - preds: Shape matching input_format
        - target: Same shape as preds
        - mask: Optional, same shape as preds, dtype=torch.bool

        **Option 2: From pipeline**
        - mse: Scalar pre-computed MSE
        - preds: Optional (for data_range inference)

    Output:
        Tensor: PSNR in dB (scalar)

    Examples:
        >>> from torchmetrics_v4 import PSNR
        >>>
        >>> # 2D images [N, C, H, W]
        >>> psnr = PSNR(data_range=1.0, input_format='NCHW')
        >>> preds = torch.rand(8, 3, 256, 256)
        >>> targets = torch.rand(8, 3, 256, 256)
        >>> result = psnr(preds, targets)
        >>>
        >>> # 3D volumes [N, C, D, H, W]
        >>> psnr_3d = PSNR(data_range=1.0, input_format='NCDHW')
        >>> preds_3d = torch.rand(4, 1, 64, 128, 128)
        >>> result = psnr_3d(preds_3d, targets_3d)
        >>>
        >>> # Grayscale batch [N, H, W]
        >>> psnr_gray = PSNR(data_range=255.0, input_format='NHW')
        >>> preds_gray = torch.rand(8, 256, 256) * 255
        >>> result = psnr_gray(preds_gray, targets_gray)
    """

    def __init__(
        self,
        data_range: Optional[float] = None,
        input_format: str = 'NCHW',
        aggregation: RegressionAggregationMethod = RegressionAggregationMethod.SAMPLEWISE,
        accept_mse_from_pipeline: bool = True,
        epsilon: float = 1e-10,
        **kwargs
    ):
        super().__init__(**kwargs)

        input_format = input_format.upper()
        if input_format not in _INPUT_FORMAT_NDIM:
            raise ValueError(
                f"Unsupported input_format '{input_format}'. "
                f"Supported formats: {list(_INPUT_FORMAT_NDIM.keys())}"
            )

        if isinstance(aggregation, str):
            aggregation = RegressionAggregationMethod(aggregation.lower())

        self.data_range = data_range
        self.input_format = input_format
        self.aggregation = aggregation
        self.accept_mse_from_pipeline = accept_mse_from_pipeline
        self.epsilon = epsilon

        if aggregation == RegressionAggregationMethod.ELEMENTWISE:
            self.add_state("sum_squared_error", default=torch.tensor(0.0), dist_reduce_fx=DistributedReduceOp.SUM)
            self.add_state("total_elements", default=torch.tensor(0), dist_reduce_fx=DistributedReduceOp.SUM)
        else:
            self.add_state("sample_psnr_values", default=[], dist_reduce_fx=DistributedReduceOp.CAT)

        self.add_state("data_range_inferred", default=torch.tensor(0.0), dist_reduce_fx=DistributedReduceOp.MAX)

    def _normalize_to_batch(
        self,
        preds: Tensor,
        target: Tensor,
        mask: Optional[Tensor],
    ) -> tuple:
        """
        Normalize inputs to have a batch dimension at dim=0 based on input_format.

        Adds batch and/or channel dimensions as needed so that downstream
        samplewise computation always indexes batch at dim=0.

        Returns:
            Tuple of (preds, target, mask) with batch dimension guaranteed.

        Raises:
            ValueError: If input ndim does not match input_format.
        """
        fmt = self.input_format
        expected_ndim = _INPUT_FORMAT_NDIM[fmt]

        if preds.ndim != expected_ndim:
            raise ValueError(
                f"input_format='{fmt}' expects {expected_ndim}D input, "
                f"but got preds with ndim={preds.ndim} (shape {list(preds.shape)})"
            )

        if fmt == 'HW':
            # [H, W] -> [1, 1, H, W]
            preds = preds.unsqueeze(0).unsqueeze(0)
            target = target.unsqueeze(0).unsqueeze(0)
            if mask is not None:
                mask = mask.unsqueeze(0).unsqueeze(0)

        elif fmt == 'CHW':
            # [C, H, W] -> [1, C, H, W]
            preds = preds.unsqueeze(0)
            target = target.unsqueeze(0)
            if mask is not None:
                mask = mask.unsqueeze(0)

        elif fmt == 'NHW':
            # [N, H, W] -> [N, 1, H, W]
            preds = preds.unsqueeze(1)
            target = target.unsqueeze(1)
            if mask is not None:
                mask = mask.unsqueeze(1)

        # NCHW and NCDHW already have batch+channel dims, no change needed

        return preds, target, mask

    @auto_update
    def update(
        self,
        preds: Optional[Tensor] = None,
        target: Optional[Tensor] = None,
        mask: Optional[Tensor] = None,
        mse: Optional[Tensor] = None,
    ) -> None:

        # Mode 1: MSE from pipeline
        if mse is not None and self.accept_mse_from_pipeline:
            if self.data_range is None and preds is not None:
                inferred_range = preds.max() - preds.min()
                self.data_range_inferred = torch.max(
                    self.data_range_inferred,
                    inferred_range.detach().to(self.data_range_inferred.device),
                )

            data_range_value = self.data_range if self.data_range is not None else self.data_range_inferred
            psnr_value = 10 * torch.log10((data_range_value ** 2) / (mse + self.epsilon))

            if self.aggregation == RegressionAggregationMethod.SAMPLEWISE:
                self.sample_psnr_values.append(psnr_value.detach().cpu())
            else:
                raise NotImplementedError("ELEMENTWISE with pipeline MSE not supported")

        # Mode 2: Compute from images
        else:
            if preds is None or target is None:
                raise ValueError(
                    "preds and target must be provided when not using pipeline MSE mode."
                )
            if preds.shape != target.shape:
                raise ValueError(
                    f"Shape mismatch: preds has shape {list(preds.shape)} "
                    f"but target has shape {list(target.shape)}"
                )
            if mask is not None:
                if mask.shape != preds.shape or mask.dtype != torch.bool:
                    raise ValueError(
                        f"mask must have same shape as preds {list(preds.shape)} and dtype=torch.bool, "
                        f"got shape {list(mask.shape)} and dtype={mask.dtype}"
                    )

            # Normalize dimensions based on input_format
            preds, target, mask = self._normalize_to_batch(preds, target, mask)

            # Infer data range
            if self.data_range is None:
                inferred_range = torch.max(preds.max() - preds.min(), target.max() - target.min())
                self.data_range_inferred = torch.max(
                    self.data_range_inferred,
                    inferred_range.detach().to(self.data_range_inferred.device),
                )

            squared_errors = (preds - target) ** 2

            if mask is not None:
                squared_errors = squared_errors * mask

            if self.aggregation == RegressionAggregationMethod.ELEMENTWISE:
                self.sum_squared_error += squared_errors.sum()
                self.total_elements += mask.sum() if mask is not None else squared_errors.numel()
            else:
                batch_size = preds.shape[0]
                data_range_value = self.data_range if self.data_range is not None else self.data_range_inferred

                for i in range(batch_size):
                    sample_errors = squared_errors[i]

                    if mask is not None:
                        sample_mask = mask[i]
                        num_valid = sample_mask.sum()
                        if num_valid > 0:
                            sample_mse = sample_errors.sum() / num_valid
                        else:
                            sample_mse = torch.tensor(0.0, device=preds.device)
                    else:
                        sample_mse = sample_errors.mean()

                    sample_psnr = 10 * torch.log10((data_range_value ** 2) / (sample_mse + self.epsilon))
                    self.sample_psnr_values.append(sample_psnr.cpu())

    @auto_compute
    def compute(self) -> Tensor:

        data_range_value = self.data_range if self.data_range is not None else self.data_range_inferred

        if data_range_value == 0:
            return torch.tensor(float('nan'), device=self.device)

        if self.aggregation == RegressionAggregationMethod.ELEMENTWISE:
            total_val = tensor_to_python_scalar(self.total_elements)
            if total_val == 0:
                return torch.tensor(float('nan'), device=self.device)

            mse = self.sum_squared_error.float() / self.total_elements.float()
            psnr = 10 * torch.log10((data_range_value ** 2) / (mse + self.epsilon))
            return psnr
        else:
            if not self.sample_psnr_values:
                return torch.tensor(float('nan'), device=self.device)

            all_values = torch.stack([v.to(self.device) for v in self.sample_psnr_values])
            return all_values.mean()


# Alias
PSNR = PeakSignalNoiseRatio
