# -*- coding: utf-8 -*-


import torch
from torch import Tensor
from typing import Dict, List, Union, Optional
from ..base import BaseTorchMetric
from ..utils.decorator import auto_update, auto_compute
from ..utils.enums import DistributedReduceOp, ClassificationAverageMethod
from .curve_core import select_thresholds, compute_confusion_matrix_at_thresholds
from .confusion_matrix_core import compute_metrics_from_confusion_matrix

__all__ = [
    "BinaryConfusionMatrix",
    "MulticlassConfusionMatrix",
    "MultilabelConfusionMatrix",
]


class BinaryConfusionMatrix(BaseTorchMetric):
    """Binary Confusion Matrix Metric.
    
    Computes confusion matrix and derived metrics for binary classification.
    
    Args:
        num_thresholds: Number of uniformly spaced thresholds
        thresholds: Explicit threshold values
        metrics: Which metrics to compute ('all', 'common', or list of names)
        epsilon: Small value for safe division
        **kwargs: Additional arguments for BaseTorchMetric
        
    Input:
        preds: [N] probabilities
        target: [N] binary labels {0, 1}
        
    Output:
        Dict with confusion matrix and metrics at all thresholds
        
    Example:
        >>> from torchmetrics_v4 import BinaryConfusionMatrix
        >>> cm = BinaryConfusionMatrix(num_thresholds=100, metrics='common')
        >>> preds = torch.rand(1000)
        >>> targets = torch.randint(0, 2, (1000,))
        >>> result = cm(preds, targets)
        >>> print(result['accuracy'])  # Accuracy at each threshold
        >>> print(result['f1'])  # F1 at each threshold
    """
    
    def __init__(
        self,
        num_thresholds: Optional[int] = None,
        thresholds: Optional[Tensor] = None,
        metrics: Union[str, List[str]] = 'all',
        epsilon: float = 1e-7,
        **kwargs
    ):
        super().__init__(**kwargs)
        self.num_thresholds = num_thresholds
        self.thresholds = thresholds
        self.metrics = metrics
        self.epsilon = epsilon
        
        self.add_state("preds", [], dist_reduce_fx=DistributedReduceOp.CAT)
        self.add_state("targets", [], dist_reduce_fx=DistributedReduceOp.CAT)
    
    @auto_update
    def update(self, preds: Tensor, target: Tensor) -> None:
        self.preds.append(preds.detach().cpu())
        self.targets.append(target.detach().cpu())
    
    @auto_compute
    def compute(self) -> Dict[str, Tensor]:
        if not self.preds:
            return {}
        
        preds = torch.cat(self.preds, dim=0)
        targets = torch.cat(self.targets, dim=0)
        
        threshs = select_thresholds(preds, self.num_thresholds, self.thresholds)
        cm = compute_confusion_matrix_at_thresholds(preds, targets, threshs)
        
        # Compute metrics from confusion matrix
        metrics_result = compute_metrics_from_confusion_matrix(
            cm['tp'], cm['fp'], cm['fn'], cm['tn'],
            metrics=self.metrics,
            epsilon=self.epsilon,
        )
        
        # Add confusion matrix elements
        metrics_result['tp'] = cm['tp']
        metrics_result['fp'] = cm['fp']
        metrics_result['fn'] = cm['fn']
        metrics_result['tn'] = cm['tn']
        metrics_result['thresholds'] = cm['thresholds']
        
        return metrics_result


class MulticlassConfusionMatrix(BaseTorchMetric):
    """Multiclass Confusion Matrix Metric.
    
    Args:
        num_classes: Number of classes
        average: Averaging method ('micro', 'macro', 'weighted', 'none')
        num_thresholds: Number of thresholds
        thresholds: Explicit thresholds
        metrics: Which metrics to compute
        epsilon: Small value for safe division
        **kwargs: Additional arguments
        
    Input:
        preds: [N, num_classes] probabilities
        target: [N] class indices
        
    Output:
        Dict with confusion matrix metrics
        
    Example:
        >>> from torchmetrics_v4 import MulticlassConfusionMatrix
        >>> cm = MulticlassConfusionMatrix(num_classes=3, average='macro')
        >>> preds = torch.softmax(torch.randn(100, 3), dim=1)
        >>> targets = torch.randint(0, 3, (100,))
        >>> result = cm(preds, targets)
    """
    
    def __init__(
        self,
        num_classes: int,
        average: Union[str, ClassificationAverageMethod] = 'macro',
        num_thresholds: Optional[int] = None,
        thresholds: Optional[Tensor] = None,
        metrics: Union[str, List[str]] = 'all',
        epsilon: float = 1e-7,
        **kwargs
    ):
        super().__init__(**kwargs)
        self.num_classes = num_classes
        if isinstance(average, str):
            average = ClassificationAverageMethod(average)
        self.average = average
        self.num_thresholds = num_thresholds
        self.thresholds = thresholds
        self.metrics = metrics
        self.epsilon = epsilon
        
        self.add_state("preds", [], dist_reduce_fx=DistributedReduceOp.CAT)
        self.add_state("targets", [], dist_reduce_fx=DistributedReduceOp.CAT)
    
    @auto_update
    def update(self, preds: Tensor, target: Tensor) -> None:
        self.preds.append(preds.detach().cpu())
        self.targets.append(target.detach().cpu())
    
    @auto_compute
    def compute(self) -> Dict:
        if not self.preds:
            return {}
        
        preds = torch.cat(self.preds, dim=0)
        targets = torch.cat(self.targets, dim=0)
        
        if self.average == ClassificationAverageMethod.MICRO:
            # Micro: flatten all
            preds_flat = preds.reshape(-1)
            targets_onehot = torch.nn.functional.one_hot(targets, self.num_classes)
            targets_flat = targets_onehot.reshape(-1)
            
            threshs = select_thresholds(preds_flat, self.num_thresholds, self.thresholds)
            cm = compute_confusion_matrix_at_thresholds(preds_flat, targets_flat, threshs)
            
            metrics_result = compute_metrics_from_confusion_matrix(
                cm['tp'], cm['fp'], cm['fn'], cm['tn'],
                metrics=self.metrics,
                epsilon=self.epsilon,
            )
            
            metrics_result.update(cm)
            return metrics_result
        
        # Per-class computation
        per_class_results = []
        for i in range(self.num_classes):
            class_preds = preds[:, i]
            class_targets = (targets == i).long()
            
            threshs = select_thresholds(class_preds, self.num_thresholds, self.thresholds)
            cm = compute_confusion_matrix_at_thresholds(class_preds, class_targets, threshs)
            
            metrics_result = compute_metrics_from_confusion_matrix(
                cm['tp'], cm['fp'], cm['fn'], cm['tn'],
                metrics=self.metrics,
                epsilon=self.epsilon,
            )
            metrics_result.update(cm)
            per_class_results.append(metrics_result)
        
        if self.average == ClassificationAverageMethod.NONE:
            # Return per-class
            result = {}
            for key in per_class_results[0].keys():
                result[key] = [r[key] for r in per_class_results]
            return result
        
        # Averaging
        if self.average == ClassificationAverageMethod.MACRO:
            weights = torch.ones(self.num_classes) / self.num_classes
        else:  # WEIGHTED
            class_counts = torch.bincount(targets, minlength=self.num_classes).float()
            weights = class_counts / class_counts.sum()
        
        # Average metrics
        result = {}
        for key in per_class_results[0].keys():
            if key == 'thresholds':
                result[key] = per_class_results[0][key]
            else:
                values = torch.stack([r[key] * weights[i] for i, r in enumerate(per_class_results)])
                result[key] = values.sum(dim=0)
        
        return result


class MultilabelConfusionMatrix(BaseTorchMetric):
    """Multilabel Confusion Matrix Metric.
    
    Args:
        num_labels: Number of labels
        average: Averaging method ('micro', 'macro', 'weighted', 'samples', 'none')
        num_thresholds: Number of thresholds
        thresholds: Explicit thresholds
        metrics: Which metrics to compute
        epsilon: Small value for safe division
        **kwargs: Additional arguments
        
    Input:
        preds: [N, num_labels] probabilities
        target: [N, num_labels] binary labels
        
    Output:
        Dict with confusion matrix metrics
        
    Example:
        >>> from torchmetrics_v4 import MultilabelConfusionMatrix
        >>> cm = MultilabelConfusionMatrix(num_labels=5, average='micro')
        >>> preds = torch.sigmoid(torch.randn(100, 5))
        >>> targets = torch.randint(0, 2, (100, 5))
        >>> result = cm(preds, targets)
    """
    
    def __init__(
        self,
        num_labels: int,
        average: Union[str, ClassificationAverageMethod] = 'macro',
        num_thresholds: Optional[int] = None,
        thresholds: Optional[Tensor] = None,
        metrics: Union[str, List[str]] = 'all',
        epsilon: float = 1e-7,
        **kwargs
    ):
        super().__init__(**kwargs)
        self.num_labels = num_labels
        if isinstance(average, str):
            average = ClassificationAverageMethod(average)
        self.average = average
        self.num_thresholds = num_thresholds
        self.thresholds = thresholds
        self.metrics = metrics
        self.epsilon = epsilon
        
        self.add_state("preds", [], dist_reduce_fx=DistributedReduceOp.CAT)
        self.add_state("targets", [], dist_reduce_fx=DistributedReduceOp.CAT)
    
    @auto_update
    def update(self, preds: Tensor, target: Tensor) -> None:
        self.preds.append(preds.detach().cpu())
        self.targets.append(target.detach().cpu())
    
    @auto_compute
    def compute(self) -> Dict:
        if not self.preds:
            return {}
        
        preds = torch.cat(self.preds, dim=0)
        targets = torch.cat(self.targets, dim=0)
        
        if self.average == ClassificationAverageMethod.MICRO:
            # Micro: flatten all labels
            preds_flat = preds.reshape(-1)
            targets_flat = targets.reshape(-1)
            
            threshs = select_thresholds(preds_flat, self.num_thresholds, self.thresholds)
            cm = compute_confusion_matrix_at_thresholds(preds_flat, targets_flat, threshs)
            
            metrics_result = compute_metrics_from_confusion_matrix(
                cm['tp'], cm['fp'], cm['fn'], cm['tn'],
                metrics=self.metrics,
                epsilon=self.epsilon,
            )
            
            metrics_result.update(cm)
            return metrics_result
        
        # Per-label computation
        per_label_results = []
        for i in range(self.num_labels):
            label_preds = preds[:, i]
            label_targets = targets[:, i]
            
            threshs = select_thresholds(label_preds, self.num_thresholds, self.thresholds)
            cm = compute_confusion_matrix_at_thresholds(label_preds, label_targets, threshs)
            
            metrics_result = compute_metrics_from_confusion_matrix(
                cm['tp'], cm['fp'], cm['fn'], cm['tn'],
                metrics=self.metrics,
                epsilon=self.epsilon,
            )
            metrics_result.update(cm)
            per_label_results.append(metrics_result)
        
        if self.average == ClassificationAverageMethod.NONE:
            result = {}
            for key in per_label_results[0].keys():
                result[key] = [r[key] for r in per_label_results]
            return result
        
        # Averaging
        if self.average == ClassificationAverageMethod.MACRO:
            weights = torch.ones(self.num_labels) / self.num_labels
        else:  # WEIGHTED or SAMPLES
            label_counts = targets.sum(dim=0).float()
            weights = label_counts / label_counts.sum()
        
        result = {}
        for key in per_label_results[0].keys():
            if key == 'thresholds':
                result[key] = per_label_results[0][key]
            else:
                values = torch.stack([r[key] * weights[i] for i, r in enumerate(per_label_results)])
                result[key] = values.sum(dim=0)
        
        return result
