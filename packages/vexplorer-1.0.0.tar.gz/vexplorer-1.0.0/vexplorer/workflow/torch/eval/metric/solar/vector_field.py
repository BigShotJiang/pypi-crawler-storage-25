# -*- coding: utf-8 -*-
"""
PyTorch metric classes for evaluating solar vector magnetic field reconstructions.

Metric classes
--------------
Comparison metrics (require *preds* **and** *target*):

  * :class:`VectorCorrelation`    — Cv, global normalised dot-product similarity
  * :class:`CauchySchwarz`        — Cs, mean per-voxel cosine similarity
  * :class:`MeanVectorError`      — En, normalised L1 difference
  * :class:`MeanAngularError`     — ⟨sin θ⟩, mean angular deviation
  * :class:`EnergyRatio`          — ε = E_pred / E_target
  * :class:`ComponentMAE`         — MAE per field component (Bx, By, Bz)
  * :class:`ComponentRMSE`        — RMSE per field component (Bx, By, Bz)

Physics-only metrics (require only *preds*):

  * :class:`MagneticEnergy`       — E = (dx³/8π) Σ|B|²
  * :class:`NormalizedDivergence` — ⟨|∇·B| / (6|B|/dx)⟩, solenoidal quality
  * :class:`CurrentWeightedSine`  — CWsin = Σ(|J|·sin θ) / Σ|J|, force-free quality

Combined metrics:

  * :class:`VectorFieldMetric`    — all comparison **and** physics metrics in one pass,
                                    sharing intermediates (dot, norms, diff, cross,
                                    gradients) to eliminate redundant computation.
                                    Also supports **physics-only mode** (no target required)
                                    by disabling all comparison flags and passing no target.

All classes:
  * Follow the ``BaseTorchMetric`` / ``auto_update`` / ``auto_compute`` contract.
  * Support optional denormalisation via ``mean`` / ``std`` buffers.
  * Support distributed training via ``DistributedReduceOp.SUM`` states.
  * Accept an optional boolean ``mask`` of shape ``(batch, D, H, W, T)``.

Input tensor shape
------------------
  preds / target : ``(batch, 3, D, H, W, T)``  — Bx, By, Bz channels
  mask           : ``(batch, D, H, W, T)``      — optional spatial mask

References
----------
Schrijver, C. J. et al. (2006), Sol. Phys., 235, 161–190.
Metcalf, T. R. et al. (2008), Sol. Phys., 247, 269–299.
"""

from __future__ import annotations

from typing import Dict, Optional, Sequence

import torch
from torch import Tensor

from ..base import BaseTorchMetric
from ..utils.decorator import auto_update, auto_compute
from ..utils.enums import DistributedReduceOp
from ..utils.functional import tensor_to_python_scalar
from .vector_field_core import (
    # Validation
    validate_vector_field,
    validate_mask,
    # Physics stat accumulators
    compute_normalized_divergence_stats,
    compute_current_weighted_sine_stats,
    compute_physics_stats,
    # Comparison stat accumulators — individual
    compute_vector_correlation_stats,
    compute_cauchy_schwarz_stats,
    compute_mean_vector_error_stats,
    compute_mean_angular_error_stats,
    compute_energy_ratio_stats,
    compute_component_mae_stats,
    compute_component_rmse_stats,
    compute_magnetic_energy_stats,
    # Comparison stat accumulator — combined single-pass
    compute_all_comparison_stats,
    # Finalisers
    vector_correlation_from_stats,
    cauchy_schwarz_from_stats,
    mean_vector_error_from_stats,
    mean_angular_error_from_stats,
    energy_ratio_from_stats,
    component_mae_from_stats,
    component_rmse_from_stats,
    magnetic_energy_from_stats,
    normalized_divergence_from_stats,
    current_weighted_sine_from_stats,
)

__all__ = [
    # Comparison metrics
    "VectorCorrelation",
    "CauchySchwarz",
    "MeanVectorError",
    "MeanAngularError",
    "EnergyRatio",
    "ComponentMAE",
    "ComponentRMSE",
    # Physics-only metrics
    "MagneticEnergy",
    "NormalizedDivergence",
    "CurrentWeightedSine",
    # Combined metric
    "VectorFieldMetric",
]


# =============================================================================
# Shared mixin: denormalisation + shape validation
# =============================================================================

class _VectorFieldBase(BaseTorchMetric):
    """
    Base class providing flexible denormalization and input validation for B-field metrics.

    Supports three denormalization strategies (in order of priority):
    1. Custom Transform: A callable/nn.Module passed via `denorm_module`.
    2. Min-Max: Uses `min` and `max` buffers.
    3. Z-Score: Uses `mean` and `std` buffers.

    Parameters
    ----------
    dx : float
        Isotropic grid spacing in physical units (default 0.36 Mm).
    eps : float
        Numerical stability constant (default 1e-8).
    denorm_module : torch.nn.Module, optional
        A custom module that takes a tensor and returns the denormalized version.
    min : sequence of float, optional
        Per-channel minimum values [min_x, min_y, min_z] for Min-Max scaling.
    max : sequence of float, optional
        Per-channel maximum values [max_x, max_y, max_z] for Min-Max scaling.
    mean : sequence of float, optional
        Per-channel mean [μ_x, μ_y, μ_z] for Z-score scaling.
    std : sequence of float, optional
        Per-channel std [σ_x, σ_y, σ_z] for Z-score scaling.
    **kwargs
        Forwarded to ``BaseTorchMetric``.
    """

    def __init__(
            self,
            dx: float = 0.36,
            eps: float = 1e-8,
            denorm_module: Optional[torch.nn.Module] = None,
            min: Optional[Sequence[float]] = None,
            max: Optional[Sequence[float]] = None,
            mean: Optional[Sequence[float]] = None,
            std: Optional[Sequence[float]] = None,
            **kwargs,
    ) -> None:
        super().__init__(**kwargs)
        self.dx = dx
        self.eps = eps

        # Priority 1: Custom Denormalization Module
        self.denorm_module = denorm_module

        # Priority 2: Min-Max Buffers
        if min is not None and max is not None:
            self._use_minmax = True
            self.register_buffer(
                "_min", torch.tensor(min, dtype=torch.float32).view(1, -1, 1, 1, 1, 1)
            )
            self.register_buffer(
                "_max", torch.tensor(max, dtype=torch.float32).view(1, -1, 1, 1, 1, 1)
            )
        else:
            self._use_minmax = False

        # Priority 3: Mean-Std (Z-Score) Buffers
        if mean is not None and std is not None:
            self._use_zscore = True
            self.register_buffer(
                "_mean", torch.tensor(mean, dtype=torch.float32).view(1, -1, 1, 1, 1, 1)
            )
            self.register_buffer(
                "_std", torch.tensor(std, dtype=torch.float32).view(1, -1, 1, 1, 1, 1)
            )
        else:
            self._use_zscore = False

    def _denormalize(self, x: Tensor) -> Tensor:
        """
        Applies denormalization based on priority:
        Module > Min-Max > Z-Score > None.
        """
        # 1. Try Custom Module
        if self.denorm_module is not None:
            return self.denorm_module(x)

        # 2. Try Min-Max: x_orig = x_norm * (max - min) + min
        if self._use_minmax:
            return x * (self._max - self._min) + self._min

        # 3. Try Z-Score: x_orig = x_norm * std + mean
        if self._use_zscore:
            return x * self._std + self._mean

        # 4. No denormalization info provided
        return x

    def _prepare(
            self,
            preds: Tensor,
            target: Optional[Tensor],
            mask: Optional[Tensor],
    ):
        """
        Entry point for data preparation. Denormalizes the fields and
        validates the geometric shapes before metric computation.
        """
        # Ensure float32 for calculations
        # B_pred = self._denormalize(preds.float())
        B_pred = self._denormalize(preds)
        validate_vector_field(B_pred, "preds")

        B_target = None
        if target is not None:
            # B_target = self._denormalize(target.float())
            B_target = self._denormalize(target)
            validate_vector_field(B_target, "target")

        if mask is not None:
            validate_mask(mask, B_pred[:, 0].shape)

        return B_pred, B_target, mask

# =============================================================================
# 1. Vector Correlation  Cv
# =============================================================================

class VectorCorrelation(_VectorFieldBase):
    """Vector Correlation (Cv) — Schrijver et al. (2006).

    .. math::

        C_v = \\frac{\\sum_i \\mathbf{B}_i \\cdot \\mathbf{B}'_i}
                    {\\sqrt{\\sum_i |\\mathbf{B}_i|^2 \\;
                            \\sum_i |\\mathbf{B}'_i|^2}}

    Global normalised inner-product similarity.
    Perfect reconstruction gives :math:`C_v = 1`.  Range: [-1, 1].

    Examples
    --------
    >>> metric = VectorCorrelation()
    >>> metric.update(preds, target)
    >>> print(metric.compute())   # tensor(0.9871)
    """

    def __init__(self, **kwargs) -> None:
        super().__init__(**kwargs)
        self.add_state("dot_sum",       default=torch.tensor(0.0), dist_reduce_fx=DistributedReduceOp.SUM)
        self.add_state("pred_sq_sum",   default=torch.tensor(0.0), dist_reduce_fx=DistributedReduceOp.SUM)
        self.add_state("target_sq_sum", default=torch.tensor(0.0), dist_reduce_fx=DistributedReduceOp.SUM)

    @auto_update
    def update(self, preds: Tensor, target: Tensor, mask: Optional[Tensor] = None) -> None:
        B_pred, B_target, mask = self._prepare(preds, target, mask)
        dot_s, pred_s, tgt_s  = compute_vector_correlation_stats(B_pred, B_target, mask)
        self.dot_sum       += dot_s
        self.pred_sq_sum   += pred_s
        self.target_sq_sum += tgt_s

    @auto_compute
    def compute(self) -> Tensor:
        return vector_correlation_from_stats(
            self.dot_sum, self.pred_sq_sum, self.target_sq_sum, self.eps
        )


# =============================================================================
# 2. Cauchy-Schwarz Metric  Cs
# =============================================================================

class CauchySchwarz(_VectorFieldBase):
    """Cauchy-Schwarz Metric (Cs) — Schrijver et al. (2006).

    .. math::

        C_s = \\frac{1}{N} \\sum_i
              \\frac{\\mathbf{B}_i \\cdot \\mathbf{B}'_i}
                   {|\\mathbf{B}_i|\\,|\\mathbf{B}'_i|}

    Mean per-voxel cosine similarity.
    Perfect reconstruction gives :math:`C_s = 1`.  Range: [-1, 1].

    Examples
    --------
    >>> metric = CauchySchwarz()
    >>> metric.update(preds, target)
    >>> print(metric.compute())   # tensor(0.9953)
    """

    def __init__(self, **kwargs) -> None:
        super().__init__(**kwargs)
        self.add_state("cs_sum", default=torch.tensor(0.0), dist_reduce_fx=DistributedReduceOp.SUM)
        self.add_state("count",  default=torch.tensor(0.0), dist_reduce_fx=DistributedReduceOp.SUM)

    @auto_update
    def update(self, preds: Tensor, target: Tensor, mask: Optional[Tensor] = None) -> None:
        B_pred, B_target, mask = self._prepare(preds, target, mask)
        cs_s, cnt = compute_cauchy_schwarz_stats(B_pred, B_target, mask, self.eps)
        self.cs_sum += cs_s
        self.count  += cnt

    @auto_compute
    def compute(self) -> Tensor:
        return cauchy_schwarz_from_stats(self.cs_sum, self.count, self.eps)


# =============================================================================
# 3. Mean Vector Error  En
# =============================================================================

class MeanVectorError(_VectorFieldBase):
    """Mean Vector Error (En) — Schrijver et al. (2006).

    .. math::

        E_n = \\frac{\\sum_i |\\mathbf{B}_i - \\mathbf{B}'_i|}
                    {\\sum_i |\\mathbf{B}'_i|}

    Normalised L1 difference.
    Perfect reconstruction gives :math:`E_n = 0`.

    Examples
    --------
    >>> metric = MeanVectorError()
    >>> metric.update(preds, target)
    >>> print(metric.compute())   # tensor(0.0312)
    """

    def __init__(self, **kwargs) -> None:
        super().__init__(**kwargs)
        self.add_state("error_norm_sum", default=torch.tensor(0.0), dist_reduce_fx=DistributedReduceOp.SUM)
        self.add_state("ref_norm_sum",   default=torch.tensor(0.0), dist_reduce_fx=DistributedReduceOp.SUM)

    @auto_update
    def update(self, preds: Tensor, target: Tensor, mask: Optional[Tensor] = None) -> None:
        B_pred, B_target, mask = self._prepare(preds, target, mask)
        err_s, ref_s = compute_mean_vector_error_stats(B_pred, B_target, mask)
        self.error_norm_sum += err_s
        self.ref_norm_sum   += ref_s

    @auto_compute
    def compute(self) -> Tensor:
        return mean_vector_error_from_stats(self.error_norm_sum, self.ref_norm_sum, self.eps)


# =============================================================================
# 4. Mean Angular Error  ⟨sin θ⟩
# =============================================================================

class MeanAngularError(_VectorFieldBase):
    """Mean Angular Error ⟨sin θ⟩ — Schrijver et al. (2006).

    .. math::

        \\langle \\sin\\theta \\rangle =
        \\frac{1}{N} \\sum_i
        \\frac{|\\mathbf{B}_i \\times \\mathbf{B}'_i|}
             {|\\mathbf{B}_i|\\,|\\mathbf{B}'_i|}

    Mean sine of the angle between predicted and reference vectors.
    Perfect reconstruction gives :math:`\\langle \\sin\\theta \\rangle = 0`.
    Range: [0, 1].

    Examples
    --------
    >>> metric = MeanAngularError()
    >>> metric.update(preds, target)
    >>> print(metric.compute())   # tensor(0.0271)
    """

    def __init__(self, **kwargs) -> None:
        super().__init__(**kwargs)
        self.add_state("sin_sum", default=torch.tensor(0.0), dist_reduce_fx=DistributedReduceOp.SUM)
        self.add_state("count",   default=torch.tensor(0.0), dist_reduce_fx=DistributedReduceOp.SUM)

    @auto_update
    def update(self, preds: Tensor, target: Tensor, mask: Optional[Tensor] = None) -> None:
        B_pred, B_target, mask = self._prepare(preds, target, mask)
        sin_s, cnt = compute_mean_angular_error_stats(B_pred, B_target, mask, self.eps)
        self.sin_sum += sin_s
        self.count   += cnt

    @auto_compute
    def compute(self) -> Tensor:
        return mean_angular_error_from_stats(self.sin_sum, self.count, self.eps)


# =============================================================================
# 5. Energy Ratio  ε
# =============================================================================

class EnergyRatio(_VectorFieldBase):
    """Energy Ratio (ε) — Schrijver et al. (2006).

    .. math::

        \\varepsilon = \\frac{\\sum_i |\\mathbf{B}_i|^2}
                            {\\sum_i |\\mathbf{B}'_i|^2}

    Ratio of predicted to reference magnetic energy.
    Perfect reconstruction gives :math:`\\varepsilon = 1`.

    Examples
    --------
    >>> metric = EnergyRatio()
    >>> metric.update(preds, target)
    >>> print(metric.compute())   # tensor(0.9841)
    """

    def __init__(self, **kwargs) -> None:
        super().__init__(**kwargs)
        self.add_state("pred_energy",   default=torch.tensor(0.0), dist_reduce_fx=DistributedReduceOp.SUM)
        self.add_state("target_energy", default=torch.tensor(0.0), dist_reduce_fx=DistributedReduceOp.SUM)

    @auto_update
    def update(self, preds: Tensor, target: Tensor, mask: Optional[Tensor] = None) -> None:
        B_pred, B_target, mask = self._prepare(preds, target, mask)
        pred_e, tgt_e = compute_energy_ratio_stats(B_pred, B_target, mask)
        self.pred_energy   += pred_e
        self.target_energy += tgt_e

    @auto_compute
    def compute(self) -> Tensor:
        return energy_ratio_from_stats(self.pred_energy, self.target_energy, self.eps)


# =============================================================================
# 6. Component MAE
# =============================================================================

class ComponentMAE(_VectorFieldBase):
    """Per-component Mean Absolute Error.

    .. math::

        \\text{MAE}_c = \\frac{1}{N}\\sum_i |B^c_i - B'^c_i|,
        \\quad c \\in \\{x, y, z\\}

    Returns
    -------
    Tensor
        Shape ``(3,)`` — [MAE_Bx, MAE_By, MAE_Bz].

    Examples
    --------
    >>> metric = ComponentMAE()
    >>> metric.update(preds, target)
    >>> mae = metric.compute()   # tensor([0.021, 0.019, 0.024])
    """

    def __init__(self, **kwargs) -> None:
        super().__init__(**kwargs)
        self.add_state("abs_error_sum", default=torch.zeros(3), dist_reduce_fx=DistributedReduceOp.SUM)
        self.add_state("count",         default=torch.tensor(0.0), dist_reduce_fx=DistributedReduceOp.SUM)

    @auto_update
    def update(self, preds: Tensor, target: Tensor, mask: Optional[Tensor] = None) -> None:
        B_pred, B_target, mask = self._prepare(preds, target, mask)
        abs_s, cnt = compute_component_mae_stats(B_pred, B_target, mask)
        self.abs_error_sum += abs_s
        self.count         += cnt

    @auto_compute
    def compute(self) -> Tensor:
        return component_mae_from_stats(self.abs_error_sum, self.count, self.eps)


# =============================================================================
# 7. Component RMSE
# =============================================================================

class ComponentRMSE(_VectorFieldBase):
    """Per-component Root Mean Squared Error.

    .. math::

        \\text{RMSE}_c = \\sqrt{\\frac{1}{N}\\sum_i (B^c_i - B'^c_i)^2},
        \\quad c \\in \\{x, y, z\\}

    Returns
    -------
    Tensor
        Shape ``(3,)`` — [RMSE_Bx, RMSE_By, RMSE_Bz].
    """

    def __init__(self, **kwargs) -> None:
        super().__init__(**kwargs)
        self.add_state("sq_error_sum", default=torch.zeros(3), dist_reduce_fx=DistributedReduceOp.SUM)
        self.add_state("count",        default=torch.tensor(0.0), dist_reduce_fx=DistributedReduceOp.SUM)

    @auto_update
    def update(self, preds: Tensor, target: Tensor, mask: Optional[Tensor] = None) -> None:
        B_pred, B_target, mask = self._prepare(preds, target, mask)
        sq_s, cnt = compute_component_rmse_stats(B_pred, B_target, mask)
        self.sq_error_sum += sq_s
        self.count        += cnt

    @auto_compute
    def compute(self) -> Tensor:
        return component_rmse_from_stats(self.sq_error_sum, self.count, self.eps)


# =============================================================================
# 8. Magnetic Energy  (physics-only)
# =============================================================================

class MagneticEnergy(_VectorFieldBase):
    """Total magnetic energy in the reconstructed volume.

    .. math::

        E = \\frac{dx^3}{8\\pi} \\sum_i |\\mathbf{B}_i|^2

    Physics-only metric — does not require a reference field.

    Parameters
    ----------
    dx : float
        Isotropic grid spacing in physical units (default 0.36 Mm).

    Examples
    --------
    >>> metric = MagneticEnergy(dx=0.36)
    >>> metric.update(preds)   # target not required
    >>> print(metric.compute())
    """

    def __init__(self, **kwargs) -> None:
        super().__init__(**kwargs)
        self.add_state("energy_sum", default=torch.tensor(0.0), dist_reduce_fx=DistributedReduceOp.SUM)

    @auto_update
    def update(
        self,
        preds: Tensor,
        target: Optional[Tensor] = None,
        mask: Optional[Tensor] = None,
    ) -> None:
        B_pred, _, mask = self._prepare(preds, target, mask)
        self.energy_sum += compute_magnetic_energy_stats(B_pred, self.dx, mask)

    @auto_compute
    def compute(self) -> Tensor:
        return magnetic_energy_from_stats(self.energy_sum)


# =============================================================================
# 9. Normalized Divergence  (physics-only)
# =============================================================================

class NormalizedDivergence(_VectorFieldBase):
    """Normalised divergence — solenoidal quality of the reconstructed field.

    .. math::

        \\langle f \\rangle = \\left\\langle
            \\frac{|\\nabla\\cdot\\mathbf{B}|}{6|\\mathbf{B}|/dx}
        \\right\\rangle

    Physics-only metric — does not require a reference field.
    Lower is better.  A perfectly divergence-free field gives 0.

    Parameters
    ----------
    dx : float
        Isotropic grid spacing (default 0.36 Mm).  Requires spatial dims ≥ 3.

    Examples
    --------
    >>> metric = NormalizedDivergence(dx=0.36)
    >>> metric.update(preds)
    >>> print(metric.compute())
    """

    def __init__(self, **kwargs) -> None:
        super().__init__(**kwargs)
        self.add_state("div_sum",   default=torch.tensor(0.0), dist_reduce_fx=DistributedReduceOp.SUM)
        self.add_state("div_count", default=torch.tensor(0.0), dist_reduce_fx=DistributedReduceOp.SUM)

    @auto_update
    def update(
        self,
        preds: Tensor,
        target: Optional[Tensor] = None,
        mask: Optional[Tensor] = None,
    ) -> None:
        B_pred, _, mask = self._prepare(preds, target, mask)
        div_s, cnt = compute_normalized_divergence_stats(B_pred, self.dx, mask, self.eps)
        self.div_sum   += div_s
        self.div_count += cnt

    @auto_compute
    def compute(self) -> Tensor:
        return normalized_divergence_from_stats(self.div_sum, self.div_count, self.eps)


# =============================================================================
# 10. Current-Weighted Sine  (physics-only)
# =============================================================================

class CurrentWeightedSine(_VectorFieldBase):
    """Current-weighted mean sine — force-free quality of the reconstructed field.

    .. math::

        \\text{CWsin} =
        \\frac{\\sum_i |\\mathbf{J}_i|\\,\\sin\\theta_i}
              {\\sum_i |\\mathbf{J}_i|}

    where :math:`\\mathbf{J} = \\nabla\\times\\mathbf{B}` and
    :math:`\\theta_i` is the angle between **J** and **B** at voxel *i*.

    Physics-only metric — does not require a reference field.
    Lower is better.  A perfectly force-free field gives 0.

    Parameters
    ----------
    dx : float
        Isotropic grid spacing (default 0.36 Mm).  Requires spatial dims ≥ 3.

    Examples
    --------
    >>> metric = CurrentWeightedSine(dx=0.36)
    >>> metric.update(preds)
    >>> print(metric.compute())
    """

    def __init__(self, **kwargs) -> None:
        super().__init__(**kwargs)
        self.add_state("cwsin_num", default=torch.tensor(0.0), dist_reduce_fx=DistributedReduceOp.SUM)
        self.add_state("cwsin_den", default=torch.tensor(0.0), dist_reduce_fx=DistributedReduceOp.SUM)

    @auto_update
    def update(
        self,
        preds: Tensor,
        target: Optional[Tensor] = None,
        mask: Optional[Tensor] = None,
    ) -> None:
        B_pred, _, mask = self._prepare(preds, target, mask)
        num, den = compute_current_weighted_sine_stats(B_pred, self.dx, mask, self.eps)
        self.cwsin_num += num
        self.cwsin_den += den

    @auto_compute
    def compute(self) -> Tensor:
        return current_weighted_sine_from_stats(self.cwsin_num, self.cwsin_den, self.eps)


# =============================================================================
# 11. VectorFieldMetric — all metrics in one pass
# =============================================================================

class VectorFieldMetric(_VectorFieldBase):
    """All vector field metrics in a **single shared forward pass**.

    Computes a configurable subset of comparison and physics metrics by
    sharing all intermediate tensors across enabled metrics:

    * **Comparison pass** — dot products, field norms, cross products, and
      field differences are each computed at most once and reused across all
      enabled comparison metrics.

    * **Physics pass** — :func:`~.vector_field_core.compute_spatial_gradients`
      and :func:`~.vector_field_core.field_norm` are each called once (via
      :func:`~.vector_field_core.compute_physics_stats`), and the resulting
      ``|B_pred|`` is forwarded to the comparison pass so it is never
      recomputed.

    Returns a dictionary::

        {
            "vc":                    <Cv>,       # Vector Correlation
            "cs":                    <Cs>,       # Cauchy-Schwarz
            "en":                    <En>,       # Mean Vector Error
            "ang":                   <⟨sinθ⟩>,  # Mean Angular Error
            "er":                    <ε>,        # Energy Ratio
            "mae_bx/by/bz":          <MAE>,      # Component MAE
            "rmse_bx/by/bz":         <RMSE>,     # Component RMSE
            "cwsin":                 <CWsin>,    # Current-Weighted Sine
            "normalized_divergence": <⟨f⟩>,     # Normalised Divergence
        }

    Only keys for enabled metrics are present.

    **Physics-only mode** — disable all comparison flags and omit *target*
    to evaluate only the physics metrics without a reference field::

        metric = VectorFieldMetric(
            compute_vc=False, compute_cs=False, compute_en=False,
            compute_ang=False, compute_er=False,
            compute_comp_mae=False, compute_comp_rmse=False,
        )
        metric.update(preds)  # no target required

    This replaces the former ``CWsinMetric`` convenience class.

    Parameters
    ----------
    compute_vc, compute_cs, compute_en, compute_ang, compute_er : bool
        Enable comparison metrics (all default True).
        Require *target* to be provided in :meth:`update`.
    compute_comp_mae, compute_comp_rmse : bool
        Enable per-component error metrics (both default True).
        Require *target* to be provided in :meth:`update`.
    compute_cwsin, compute_div : bool
        Enable physics metrics on *preds* (both default True).
        Require spatial dims D, H, W ≥ 3.
    dx, eps, mean, std, **kwargs : see :class:`_VectorFieldBase`.

    Examples
    --------
    >>> metric = VectorFieldMetric(compute_comp_rmse=False)
    >>> for preds, target, mask in dataloader:
    ...     metric.update(preds, target, mask)
    >>> results = metric.compute()
    >>> print(results["vc"], results["en"])
    """

    def __init__(
        self,
        compute_vc: bool = True,
        compute_cs: bool = True,
        compute_en: bool = True,
        compute_ang: bool = True,
        compute_er: bool = True,
        compute_comp_mae: bool = True,
        compute_comp_rmse: bool = True,
        compute_cwsin: bool = True,
        compute_div: bool = True,
        **kwargs,
    ) -> None:
        super().__init__(**kwargs)

        self._compute_vc        = compute_vc
        self._compute_cs        = compute_cs
        self._compute_en        = compute_en
        self._compute_ang       = compute_ang
        self._compute_er        = compute_er
        self._compute_comp_mae  = compute_comp_mae
        self._compute_comp_rmse = compute_comp_rmse
        self._compute_cwsin     = compute_cwsin
        self._compute_div       = compute_div

        # ---- Register states for enabled metrics ----

        # Cv / Er share pred_sq_sum + target_sq_sum
        if compute_vc or compute_er:
            self.add_state("pred_sq_sum",   default=torch.tensor(0.0), dist_reduce_fx=DistributedReduceOp.SUM)
            self.add_state("target_sq_sum", default=torch.tensor(0.0), dist_reduce_fx=DistributedReduceOp.SUM)
        if compute_vc:
            self.add_state("dot_sum",       default=torch.tensor(0.0), dist_reduce_fx=DistributedReduceOp.SUM)

        # Cs
        if compute_cs:
            self.add_state("cs_sum",        default=torch.tensor(0.0), dist_reduce_fx=DistributedReduceOp.SUM)

        # En
        if compute_en:
            self.add_state("error_norm_sum", default=torch.tensor(0.0), dist_reduce_fx=DistributedReduceOp.SUM)
            self.add_state("ref_norm_sum",   default=torch.tensor(0.0), dist_reduce_fx=DistributedReduceOp.SUM)

        # Angular
        if compute_ang:
            self.add_state("sin_sum",       default=torch.tensor(0.0), dist_reduce_fx=DistributedReduceOp.SUM)

        # Component MAE / RMSE
        if compute_comp_mae:
            self.add_state("comp_abs_sum",  default=torch.zeros(3), dist_reduce_fx=DistributedReduceOp.SUM)
        if compute_comp_rmse:
            self.add_state("comp_sq_sum",   default=torch.zeros(3), dist_reduce_fx=DistributedReduceOp.SUM)

        # Unified voxel count — Cs, angular, component MAE, component RMSE all
        # share the same denominator (number of valid voxels), so one state suffices.
        if compute_cs or compute_ang or compute_comp_mae or compute_comp_rmse:
            self.add_state("voxel_count",   default=torch.tensor(0.0), dist_reduce_fx=DistributedReduceOp.SUM)

        # Physics: CWsin
        if compute_cwsin:
            self.add_state("cwsin_num",     default=torch.tensor(0.0), dist_reduce_fx=DistributedReduceOp.SUM)
            self.add_state("cwsin_den",     default=torch.tensor(0.0), dist_reduce_fx=DistributedReduceOp.SUM)

        # Physics: Normalised Divergence
        if compute_div:
            self.add_state("div_sum",       default=torch.tensor(0.0), dist_reduce_fx=DistributedReduceOp.SUM)
            self.add_state("div_count",     default=torch.tensor(0.0), dist_reduce_fx=DistributedReduceOp.SUM)

    @auto_update
    def update(
        self,
        preds: Tensor,
        target: Optional[Tensor] = None,
        mask: Optional[Tensor] = None,
    ) -> None:
        """Accumulate metric states for one batch.

        Parameters
        ----------
        preds : Tensor, shape ``(batch, 3, D, H, W, T)``
        target : Tensor or None, same shape.
            Required when any comparison metric is enabled
            (``compute_vc``, ``compute_cs``, ``compute_en``, ``compute_ang``,
            ``compute_er``, ``compute_comp_mae``, ``compute_comp_rmse``).
            May be ``None`` for physics-only evaluation.
        mask : Tensor or None, shape ``(batch, D, H, W, T)``

        Raises
        ------
        ValueError
            If *target* is ``None`` but a comparison metric is enabled.
        """
        _needs_target = (
            self._compute_vc or self._compute_cs or self._compute_en
            or self._compute_ang or self._compute_er
            or self._compute_comp_mae or self._compute_comp_rmse
        )
        if target is None and _needs_target:
            raise ValueError(
                "target must be provided when comparison metrics are enabled "
                "(compute_vc, compute_cs, compute_en, compute_ang, compute_er, "
                "compute_comp_mae, compute_comp_rmse)."
            )

        B_pred, B_target, mask = self._prepare(preds, target, mask)

        # ------------------------------------------------------------------
        # Physics pass: compute_spatial_gradients + field_norm once, shared
        # across NormalizedDivergence, CWsin, and the comparison pass below.
        # ------------------------------------------------------------------
        B_norm_p: Optional[Tensor] = None
        if self._compute_cwsin or self._compute_div:
            phys = compute_physics_stats(
                B_pred, dx=self.dx, mask=mask, eps=self.eps,
                compute_norm_div=self._compute_div,
                compute_cwsin=self._compute_cwsin,
            )
            B_norm_p = phys["B_norm"]          # reused by comparison pass below

            if self._compute_div:
                self.div_sum   += phys["div_sum"]
                self.div_count += phys["div_count"]
            if self._compute_cwsin:
                self.cwsin_num += phys["cwsin_num"]
                self.cwsin_den += phys["cwsin_den"]

        # ------------------------------------------------------------------
        # Comparison pass: all comparison metrics in one shared forward pass.
        # Skipped entirely when target is None (physics-only mode).
        # B_norm_p is forwarded so field_norm(B_pred) is never recomputed.
        # ------------------------------------------------------------------
        if _needs_target:
            stats = compute_all_comparison_stats(
                B_pred, B_target,
                mask              = mask,
                eps               = self.eps,
                B_pred_norm       = B_norm_p,
                compute_vc        = self._compute_vc,
                compute_cs        = self._compute_cs,
                compute_en        = self._compute_en,
                compute_ang       = self._compute_ang,
                compute_er        = self._compute_er,
                compute_comp_mae  = self._compute_comp_mae,
                compute_comp_rmse = self._compute_comp_rmse,
            )

            if self._compute_vc or self._compute_er:
                self.pred_sq_sum   += stats["pred_sq_sum"]
                self.target_sq_sum += stats["target_sq_sum"]
            if self._compute_vc:
                self.dot_sum        += stats["dot_sum"]
            if self._compute_cs:
                self.cs_sum         += stats["cs_sum"]
            if self._compute_en:
                self.error_norm_sum += stats["error_norm_sum"]
                self.ref_norm_sum   += stats["ref_norm_sum"]
            if self._compute_ang:
                self.sin_sum        += stats["sin_sum"]
            if self._compute_comp_mae:
                self.comp_abs_sum   += stats["comp_abs_sum"]
            if self._compute_comp_rmse:
                self.comp_sq_sum    += stats["comp_sq_sum"]
            # Unified count: Cs / angular / comp-MAE / comp-RMSE all equal
            if self._compute_cs or self._compute_ang or self._compute_comp_mae or self._compute_comp_rmse:
                self.voxel_count    += stats["count"]

    @auto_compute
    def compute(self) -> Dict[str, Tensor]:
        """Compute all enabled metrics and return as a dictionary.

        Returns
        -------
        dict of str → Tensor
            Only keys for enabled metrics are present.
        """
        results: Dict[str, Tensor] = {}
        nan = torch.tensor(float("nan"), device=self.device)

        if self._compute_vc:
            results["vc"] = (
                nan if tensor_to_python_scalar(self.pred_sq_sum) == 0
                else vector_correlation_from_stats(
                    self.dot_sum, self.pred_sq_sum, self.target_sq_sum, self.eps
                )
            )

        if self._compute_cs:
            cnt = tensor_to_python_scalar(self.voxel_count)
            results["cs"] = (
                nan if cnt == 0
                else cauchy_schwarz_from_stats(self.cs_sum, self.voxel_count, self.eps)
            )

        if self._compute_en:
            results["en"] = (
                nan if tensor_to_python_scalar(self.ref_norm_sum) == 0
                else mean_vector_error_from_stats(
                    self.error_norm_sum, self.ref_norm_sum, self.eps
                )
            )

        if self._compute_ang:
            cnt = tensor_to_python_scalar(self.voxel_count)
            results["ang"] = (
                nan if cnt == 0
                else mean_angular_error_from_stats(self.sin_sum, self.voxel_count, self.eps)
            )

        if self._compute_er:
            results["er"] = (
                nan if tensor_to_python_scalar(self.target_sq_sum) == 0
                else energy_ratio_from_stats(
                    self.pred_sq_sum, self.target_sq_sum, self.eps
                )
            )

        if self._compute_comp_mae or self._compute_comp_rmse:
            comp_cnt = tensor_to_python_scalar(self.voxel_count)

        if self._compute_comp_mae:
            if comp_cnt == 0:
                results["mae_bx"] = results["mae_by"] = results["mae_bz"] = nan
            else:
                mae = component_mae_from_stats(self.comp_abs_sum, self.voxel_count, self.eps)
                results["mae_bx"], results["mae_by"], results["mae_bz"] = mae[0], mae[1], mae[2]

        if self._compute_comp_rmse:
            if comp_cnt == 0:
                results["rmse_bx"] = results["rmse_by"] = results["rmse_bz"] = nan
            else:
                rmse = component_rmse_from_stats(self.comp_sq_sum, self.voxel_count, self.eps)
                results["rmse_bx"], results["rmse_by"], results["rmse_bz"] = rmse[0], rmse[1], rmse[2]

        if self._compute_cwsin:
            results["cwsin"] = (
                nan if tensor_to_python_scalar(self.cwsin_den) == 0
                else current_weighted_sine_from_stats(self.cwsin_num, self.cwsin_den, self.eps)
            )

        if self._compute_div:
            results["normalized_divergence"] = (
                nan if tensor_to_python_scalar(self.div_count) == 0
                else normalized_divergence_from_stats(self.div_sum, self.div_count, self.eps)
            )

        return results
