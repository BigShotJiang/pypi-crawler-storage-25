# -*- coding: utf-8 -*-

import torch.nn.functional as F
from typing import Tuple, Literal
import torch
from torch import Tensor
from typing import Dict, Optional
from ..utils.enums import ThresholdSelectionMethod
from .confusion_matrix_core import compute_metrics_from_confusion_matrix


__all__ = [
    "binary_clf_curve",
    "binary_roc_compute",
    "binary_precision_recall_curve_compute",
    "compute_auc",
    "safe_divide",
    "compute_roc_curve",
    "compute_pr_curve",
    "compute_log_roc_curve",
    "compute_confusion_matrix_at_thresholds",
    "find_optimal_threshold", 
    "find_all_optimal_thresholds",
]


def safe_divide(
    num: Tensor,
    denom: Tensor,
    zero_division: float = 0.0,
) -> Tensor:
    """Safe division preventing division by zero.

    Based on torchmetrics._safe_divide
    """
    num = num if num.is_floating_point() else num.float()
    denom = denom if denom.is_floating_point() else denom.float()
    zero_division_tensor = torch.tensor(zero_division, dtype=num.dtype, device=num.device)
    return torch.where(denom != 0, num / denom, zero_division_tensor)


def binary_clf_curve(
    preds: Tensor,
    target: Tensor,
    sample_weights: Optional[Tensor] = None,
    pos_label: int = 1,
) -> Tuple[Tensor, Tensor, Tensor]:
    """Calculate TPs and FPs for all unique thresholds.

    Adapted from torchmetrics and sklearn:
    https://github.com/Lightning-AI/torchmetrics
    https://github.com/scikit-learn/scikit-learn/blob/main/sklearn/metrics/_ranking.py

    Args:
        preds: 1d tensor with predictions (can be logits or probabilities)
        target: 1d tensor with true values
        sample_weights: optional 1d tensor with weights
        pos_label: positive class label

    Returns:
        fps: false positives at each threshold (descending threshold order)
        tps: true positives at each threshold (descending threshold order)
        thresholds: unique thresholds (descending order)
    """
    # Ensure correct types
    preds = preds.flatten()
    target = target.flatten()

    if preds.numel() == 0:
        return (
            torch.tensor([], device=preds.device),
            torch.tensor([], device=preds.device),
            torch.tensor([], device=preds.device),
        )

    # Handle sample weights
    if sample_weights is not None:
        if not isinstance(sample_weights, Tensor):
            sample_weights = torch.tensor(sample_weights, device=preds.device, dtype=torch.float)
        sample_weights = sample_weights.flatten()

    # Sort by prediction scores (descending)
    desc_score_indices = torch.argsort(preds, descending=True)
    preds = preds[desc_score_indices]
    target = target[desc_score_indices]

    if sample_weights is not None:
        weight = sample_weights[desc_score_indices]
    else:
        weight = 1.0

    # Find indices of distinct values
    # preds[1:] - preds[:-1] gives non-zero where values differ
    distinct_value_indices = torch.where(preds[1:] - preds[:-1])[0]

    # Add the last index
    threshold_idxs = F.pad(distinct_value_indices, [0, 1], value=target.size(0) - 1)

    # Convert target to binary
    target = (target == pos_label).long()

    # Compute cumulative sums
    tps = torch.cumsum(target * weight, dim=0)[threshold_idxs]

    if sample_weights is not None:
        fps = torch.cumsum((1 - target) * weight, dim=0)[threshold_idxs]
    else:
        # More efficient: fps = total_predicted_positive - tps
        fps = (1 + threshold_idxs - tps).float()

    return fps, tps, preds[threshold_idxs]


def binary_roc_compute(
    preds: Tensor,
    target: Tensor,
    sample_weights: Optional[Tensor] = None,
    pos_label: int = 1,
) -> Tuple[Tensor, Tensor, Tensor]:
    """Compute ROC curve (FPR, TPR, thresholds).

    Based on torchmetrics._binary_roc_compute

    FIX: Uses max(preds)+epsilon as first threshold instead of 1.0
    This handles logits correctly.

    Returns:
        fpr: False Positive Rate (ascending, starting from 0)
        tpr: True Positive Rate (ascending, starting from 0)
        thresholds: thresholds used (descending, starting from max+eps)
    """
    fps, tps, thresholds = binary_clf_curve(preds, target, sample_weights, pos_label)

    if len(thresholds) == 0:
        return (
            torch.tensor([0.0, 1.0], device=preds.device),
            torch.tensor([0.0, 1.0], device=preds.device),
            torch.tensor([float('inf'), float('-inf')], device=preds.device),
        )

    # FIX: Use max(preds) + small epsilon as first threshold
    # This ensures threshold > all predictions, giving (FPR=0, TPR=0)
    # first_threshold = thresholds[0] + 1.0  # Or use float('inf')

    # 修改后 (更鲁棒)
    # import math
    # first_threshold = torch.tensor(float('inf'), dtype=thresholds.dtype, device=thresholds.device)
    # 或者如果担心 inf 在某些后处理报错，至少判断一下
    if not torch.isinf(thresholds[0]):
        first_threshold = thresholds[0] + 1.0
    else:
        first_threshold = thresholds[0]

    # Prepend zero point (threshold > all preds -> no predictions positive)
    fps = torch.cat([torch.zeros(1, dtype=fps.dtype, device=fps.device), fps])
    tps = torch.cat([torch.zeros(1, dtype=tps.dtype, device=tps.device), tps])
    thresholds = torch.cat([
        torch.tensor([first_threshold], dtype=thresholds.dtype, device=thresholds.device),
        thresholds
    ])

    # Compute rates
    total_neg = fps[-1]
    total_pos = tps[-1]

    if total_neg <= 0:
        fpr = torch.zeros_like(fps)
    else:
        fpr = fps / total_neg

    if total_pos <= 0:
        tpr = torch.zeros_like(tps)
    else:
        tpr = tps / total_pos

    return fpr, tpr, thresholds


def binary_precision_recall_curve_compute(
    preds: Tensor,
    target: Tensor,
    sample_weights: Optional[Tensor] = None,
    pos_label: int = 1,
) -> Tuple[Tensor, Tensor, Tensor]:
    """Compute Precision-Recall curve.

    FIX: Prepends (Precision=1, Recall=0) to HEAD, not tail.
    This ensures the curve is correctly ordered (from high threshold to low).

    Returns:
        precision: Precision values (starts with 1.0 at recall=0)
        recall: Recall values (starts with 0.0)
        thresholds: thresholds used (descending, starts with max+eps)
    """
    fps, tps, thresholds = binary_clf_curve(preds, target, sample_weights, pos_label)

    if len(thresholds) == 0:
        return (
            torch.tensor([1.0, 0.0], device=preds.device),
            torch.tensor([0.0, 1.0], device=preds.device),
            torch.tensor([float('inf')], device=preds.device),
        )

    # Precision = TP / (TP + FP)
    precision = safe_divide(tps, tps + fps)

    # Recall = TP / total_positives
    total_positive = tps[-1] if len(tps) > 0 else torch.tensor(0.0, device=preds.device)
    recall = safe_divide(tps, total_positive)

    # FIX: PREPEND (P=1, R=0) to HEAD (highest threshold)
    # At threshold > max(preds), no predictions are positive
    # Precision is defined as 1.0 (no false positives), Recall is 0 (no true positives)
    first_threshold = thresholds[0] + 1.0

    precision = torch.cat([
        torch.ones(1, dtype=precision.dtype, device=precision.device),
        precision
    ])
    recall = torch.cat([
        torch.zeros(1, dtype=recall.dtype, device=recall.device),
        recall
    ])
    thresholds = torch.cat([
        torch.tensor([first_threshold], dtype=thresholds.dtype, device=thresholds.device),
        thresholds
    ])

    return precision, recall, thresholds


def compute_auc(x: Tensor, y: Tensor, reorder: bool = False) -> Tensor:
    """Compute Area Under Curve using trapezoidal rule.

    Args:
        x: x-coordinates
        y: y-coordinates
        reorder: if True, sort by x first

    Returns:
        AUC value
    """
    if x.numel() < 2:
        return torch.tensor(0.0, device=x.device)

    if reorder:
        order = torch.argsort(x)
        x = x[order]
        y = y[order]

    # Trapezoidal rule
    dx = x[1:] - x[:-1]

    # Handle decreasing x (like in ROC where we go from high threshold to low)
    if (dx < 0).any():
        # Flip to ensure x is increasing
        x = x.flip(0)
        y = y.flip(0)
        dx = x[1:] - x[:-1]

    return torch.abs(torch.sum(dx * (y[1:] + y[:-1]) / 2))


# =============================================================================
# High-level compute functions (for compatibility with curves.py)
# =============================================================================

def compute_roc_curve(
    predictions: Tensor,
    targets: Tensor,
    thresholds: Optional[Tensor] = None,
    sample_weights: Optional[Tensor] = None,
    max_thresholds: int = 1000,
) -> Dict[str, Tensor]:
    """Compute ROC curve with AUC.

    Args:
        predictions: prediction scores (probabilities or logits)
        targets: binary labels
        thresholds: ignored (kept for API compatibility)
        sample_weights: optional sample weights
        max_thresholds: ignored (kept for API compatibility)

    Returns:
        Dict with 'fpr', 'tpr', 'thresholds', 'auc'
    """
    fpr, tpr, thresh = binary_roc_compute(predictions, targets, sample_weights)
    auc = compute_auc(fpr, tpr)

    return {
        'fpr': fpr,
        'tpr': tpr,
        'thresholds': thresh,
        'auc': auc.clamp(0, 1),
    }


def compute_pr_curve(
    predictions: Tensor,
    targets: Tensor,
    thresholds: Optional[Tensor] = None,
    sample_weights: Optional[Tensor] = None,
    max_thresholds: int = 1000,
) -> Dict[str, Tensor]:
    """Compute Precision-Recall curve with AUC.

    Returns:
        Dict with 'precision', 'recall', 'thresholds', 'auc'
    """
    precision, recall, thresh = binary_precision_recall_curve_compute(
        predictions, targets, sample_weights
    )

    # AUC for PR curve (need to sort by recall)
    auc = compute_auc(recall, precision, reorder=True)

    return {
        'precision': precision,
        'recall': recall,
        'thresholds': thresh,
        'auc': auc.clamp(0, 1),
    }


def compute_log_roc_curve(
    predictions: Tensor,
    targets: Tensor,
    thresholds: Optional[Tensor] = None,
    sample_weights: Optional[Tensor] = None,
    fpr_epsilon: float = 1e-10,
    max_thresholds: int = 1000,
) -> Dict[str, Tensor]:
    """Compute Log-ROC curve.

    Returns:
        Dict with 'log_fpr', 'tpr', 'fpr', 'thresholds', 'auc'
    """
    roc_result = compute_roc_curve(predictions, targets, thresholds, sample_weights)

    fpr = roc_result['fpr']
    tpr = roc_result['tpr']

    log_fpr = torch.log10(fpr + fpr_epsilon)
    auc = compute_auc(log_fpr, tpr)

    return {
        'log_fpr': log_fpr,
        'tpr': tpr,
        'fpr': fpr,
        'thresholds': roc_result['thresholds'],
        'auc': auc,
    }


def select_thresholds(
    predictions: Tensor,
    num_thresholds: Optional[int] = None,
    thresholds: Optional[Tensor] = None,
    max_thresholds: int = 1000,
) -> Tensor:
    """Select thresholds for curve computation.

    Kept for backward compatibility.
    """
    if thresholds is not None:
        return thresholds
    if num_thresholds is not None:
        return torch.linspace(0, 1, num_thresholds, device=predictions.device)

    # Auto: use unique predictions
    unique = torch.unique(predictions)
    if len(unique) > max_thresholds:
        indices = torch.linspace(0, len(unique) - 1, max_thresholds).long()
        unique = unique[indices]
    return unique


def compute_confusion_matrix_at_thresholds(
    predictions: Tensor,
    targets: Tensor,
    thresholds: Tensor,
    memory_mode: Literal['vectorized', 'chunked', 'loop'] = 'vectorized',
    chunk_size: int = 100,
) -> Dict[str, Tensor]:
    """Compute confusion matrix at given thresholds.

    For optimal threshold finding.

    Args:
        predictions: prediction scores [N]
        targets: binary labels [N]
        thresholds: thresholds to evaluate [T]
        memory_mode: Memory strategy:
            - 'vectorized': Fast but uses O(T*N) memory (default)
            - 'chunked': Process thresholds in chunks (balanced)
            - 'loop': Process one threshold at a time (slow but memory-safe)
        chunk_size: Number of thresholds per chunk when memory_mode='chunked'

    WARNING (memory_mode='vectorized'):
        Creates [T, N] matrix. For 1000 thresholds and 1M samples,
        this uses ~4GB memory (float32). Use 'chunked' or 'loop' for large data.

    Returns:
        Dict with 'tp', 'fp', 'fn', 'tn', 'thresholds' (each [T])
    """
    predictions = predictions.flatten()
    targets = targets.flatten()
    thresholds = thresholds.flatten()
    device = predictions.device

    num_pos = (targets == 1).sum().float()
    num_neg = (targets == 0).sum().float()
    n_thresh = len(thresholds)

    if memory_mode == 'vectorized':
        # Fast but memory-intensive: O(T * N) memory
        # WARNING: For 1000 thresholds and 1M samples = 4GB memory!
        pred_positive = predictions.unsqueeze(0) >= thresholds.unsqueeze(1)
        is_pos = (targets == 1).unsqueeze(0)
        is_neg = (targets == 0).unsqueeze(0)

        tps = (pred_positive & is_pos).sum(dim=1).float()
        fps = (pred_positive & is_neg).sum(dim=1).float()

    elif memory_mode == 'chunked':
        # Balanced: process in chunks
        tps = torch.zeros(n_thresh, device=device)
        fps = torch.zeros(n_thresh, device=device)
        is_pos = (targets == 1)
        is_neg = (targets == 0)

        for i in range(0, n_thresh, chunk_size):
            end = min(i + chunk_size, n_thresh)
            chunk_thresholds = thresholds[i:end]
            pred_positive = predictions.unsqueeze(0) >= chunk_thresholds.unsqueeze(1)
            tps[i:end] = (pred_positive & is_pos.unsqueeze(0)).sum(dim=1).float()
            fps[i:end] = (pred_positive & is_neg.unsqueeze(0)).sum(dim=1).float()

    else:  # 'loop'
        # Memory-safe but slow: O(N) memory
        tps = torch.zeros(n_thresh, device=device)
        fps = torch.zeros(n_thresh, device=device)
        is_pos = (targets == 1)
        is_neg = (targets == 0)

        for i, thresh in enumerate(thresholds):
            pred_positive = predictions >= thresh
            tps[i] = (pred_positive & is_pos).sum().float()
            fps[i] = (pred_positive & is_neg).sum().float()

    fns = num_pos - tps
    tns = num_neg - fps

    return {
        'tp': tps,
        'fp': fps,
        'fn': fns,
        'tn': tns,
        'thresholds': thresholds,
    }


# Aliases for backward compatibility
def compute_auc_trapezoid(x: Tensor, y: Tensor, reorder: bool = False) -> Tensor:
    """Alias for compute_auc."""
    return compute_auc(x, y, reorder)


def binary_clf_curve_fast(*args, **kwargs):
    """Alias for binary_clf_curve."""
    return binary_clf_curve(*args, **kwargs)


def find_optimal_threshold(
        tp: Tensor,
        fp: Tensor,
        tn: Tensor,
        fn: Tensor,
        thresholds: Tensor,
        method: str = 'max_f1',
        **kwargs
) -> Dict[str, Tensor]:
    """Find optimal threshold using specified method.

    Args:
        tp, fp, tn, fn: Confusion matrix elements at each threshold, shape (T,)
        thresholds: Threshold values, shape (T,)
        method: Optimization method (e.g., 'max_f1', 'max_youdenj', 'max_tss')
        **kwargs: Method-specific parameters (beta, costs, constraints)

    Returns:
        Dictionary with:
            - 'threshold': Optimal threshold value
            - 'index': Index of optimal threshold
            - Method-specific score (e.g., 'max_youdenj', 'f1')
    """
    # 统一处理方法名，支持 Enum 或 字符串
    if hasattr(method, 'value'):
        method_name = method.value.lower()
    else:
        method_name = str(method).lower()

    # 兼容性处理：映射旧名称到新名称
    # if method_name in ['youden_j', 'youdenj']:
    #     method_name = 'max_youdenj'

    # --- ROC 空间寻优方法 ---

    if method_name == 'max_youdenj':
        # J = TPR - FPR = Recall + Specificity - 1
        P, N = tp + fn, tn + fp
        tpr = safe_divide(tp, P)
        fpr = safe_divide(fp, N)
        J = tpr - fpr
        idx = J.argmax()
        return {'threshold': thresholds[idx], 'index': idx, 'max_youdenj': J[idx]}

    elif method_name == 'max_tss':
        # TSS (True Skill Statistic) 在数学上等同于 Youden's J
        P, N = tp + fn, tn + fp
        tpr = safe_divide(tp, P)
        fpr = safe_divide(fp, N)
        tss = tpr - fpr
        idx = tpr.argmax() # 习惯上选取第一个最大值索引
        idx = tss.argmax()
        return {'threshold': thresholds[idx], 'index': idx, 'max_tss': tss[idx]}

    elif method_name == 'min_distance':
        # d = sqrt((1-TPR)^2 + FPR^2) -> 距离 ROC 左上角完美点 (0,1) 最近的点
        P, N = tp + fn, tn + fp
        tpr = safe_divide(tp, P)
        fpr = safe_divide(fp, N)
        dist = torch.sqrt((1 - tpr)**2 + fpr**2)
        idx = dist.argmin()
        return {'threshold': thresholds[idx], 'index': idx, 'distance': dist[idx]}

    # --- PR 空间寻优方法 ---

    elif method_name == 'max_f1':
        metrics = compute_metrics_from_confusion_matrix(tp, fp, fn, tn, metrics=['f1'])
        f1 = metrics['f1']
        idx = f1.argmax()
        return {'threshold': thresholds[idx], 'index': idx, 'f1': f1[idx]}

    elif method_name == 'max_f_beta':
        beta = kwargs.get('beta', 1.0)
        metrics = compute_metrics_from_confusion_matrix(tp, fp, fn, tn, metrics=['precision', 'recall'])
        prec, rec = metrics['precision'], metrics['recall']
        beta_sq = beta**2
        f_beta = (1 + beta_sq) * safe_divide(prec * rec, (beta_sq * prec) + rec)
        idx = f_beta.argmax()
        return {'threshold': thresholds[idx], 'index': idx, 'f_beta': f_beta[idx]}

    # --- 通用或其他寻优方法 ---

    elif method_name == 'max_accuracy':
        acc = safe_divide(tp + tn, tp + tn + fp + fn)
        idx = acc.argmax()
        return {'threshold': thresholds[idx], 'index': idx, 'accuracy': acc[idx]}

    elif method_name == 'max_precision':
        prec = safe_divide(tp, tp + fp)
        idx = prec.argmax()
        return {'threshold': thresholds[idx], 'index': idx, 'precision': prec[idx]}

    elif method_name == 'max_recall':
        rec = safe_divide(tp, tp + fn)
        idx = rec.argmax()
        return {'threshold': thresholds[idx], 'index': idx, 'recall': rec[idx]}

    elif method_name == 'min_cost':
        fp_cost = kwargs.get('fp_cost', 1.0)
        fn_cost = kwargs.get('fn_cost', 1.0)
        cost = fp * fp_cost + fn * fn_cost
        idx = cost.argmin()
        return {'threshold': thresholds[idx], 'index': idx, 'cost': cost[idx]}

    # --- 约束性寻优 ---

    elif method_name == 'sensitivity_constraint':
        min_sens = kwargs.get('min_sensitivity', 0.9)
        tpr = safe_divide(tp, tp + fn)
        tnr = safe_divide(tn, tn + fp)
        valid = tpr >= min_sens
        if not valid.any():
            idx = tpr.argmax()
        else:
            tnr_valid = tnr.clone()
            tnr_valid[~valid] = -1.0
            idx = tnr_valid.argmax()
        return {'threshold': thresholds[idx], 'index': idx, 'specificity': tnr[idx]}

    elif method_name == 'precision_constraint':
        min_prec = kwargs.get('min_precision', 0.9)
        prec = safe_divide(tp, tp + fp)
        rec = safe_divide(tp, tp + fn)
        valid = prec >= min_prec
        if not valid.any():
            idx = prec.argmax()
        else:
            rec_valid = rec.clone()
            rec_valid[~valid] = -1.0
            idx = rec_valid.argmax()
        return {'threshold': thresholds[idx], 'index': idx, 'recall': rec[idx]}

    else:
        raise ValueError(f"Unknown optimization method: {method_name}")


def find_optimal_threshold_v1(
    tp: Tensor,
    fp: Tensor,
    tn: Tensor,
    fn: Tensor,
    thresholds: Tensor,
    method: str = 'max_f1',
    **kwargs
) -> Dict[str, Tensor]:
    """Find optimal threshold using specified method.
    
    Args:
        tp, fp, tn, fn: Confusion matrix elements at each threshold, shape (T,)
        thresholds: Threshold values, shape (T,)
        method: Optimization method (see ThresholdSelectionMethod)
        **kwargs: Method-specific parameters (beta, costs, constraints)
    
    Returns:
        Dictionary with:
            - 'threshold': Optimal threshold value
            - 'index': Index of optimal threshold
            - Additional method-specific metrics
    
    Example:
        >>> optimal = find_optimal_threshold(tp, fp, tn, fn, thresholds, method='max_f1')
        >>> threshold = optimal['threshold']
        >>> f1_score = optimal['f1']
    """
    if isinstance(method, str):
        method = ThresholdSelectionMethod(method.lower())
    
    if method == ThresholdSelectionMethod.MAX_YOUDENJ:
        # J = TPR - FPR
        P, N = tp + fn, tn + fp
        tpr = tp.float() / P
        fpr = fp.float() / N
        J = tpr - fpr
        idx = J.argmax()
        return {'threshold': thresholds[idx], 'index': idx, 'youdenj': J[idx]}

    elif method == ThresholdSelectionMethod.MAX_TSS:
        P, N = tp + fn, tn + fp
        tpr = safe_divide(tp, P)
        fpr = safe_divide(fp, N)
        tss = tpr - fpr
        idx = tss.argmax()
        return {'threshold': thresholds[idx], 'index': idx, 'tss': tss[idx]}
    
    elif method == ThresholdSelectionMethod.MIN_DISTANCE:
        # d = sqrt((1-TPR)^2 + FPR^2)
        P, N = tp + fn, tn + fp
        tpr = tp.float() / P
        fpr = fp.float() / N
        dist = torch.sqrt((1 - tpr)**2 + fpr**2)
        idx = dist.argmin()
        return {'threshold': thresholds[idx], 'index': idx, 'distance': dist[idx]}
    
    elif method == ThresholdSelectionMethod.MAX_F1:
        metrics = compute_metrics_from_confusion_matrix(tp, fp, tn, fn, metrics=['f1'])
        f1 = metrics['f1']
        idx = f1.argmax()
        return {'threshold': thresholds[idx], 'index': idx, 'f1': f1[idx]}
    
    elif method == ThresholdSelectionMethod.MAX_F_BETA:
        beta = kwargs.get('beta', 1.0)
        prec = tp.float() / (tp + fp)
        rec = tp.float() / (tp + fn)
        f_beta = (1 + beta**2) * prec * rec / (beta**2 * prec + rec + 1e-10)
        idx = f_beta.argmax()
        return {'threshold': thresholds[idx], 'index': idx, 'f_beta': f_beta[idx]}
        beta = kwargs.get('beta', 1.0)
        metrics = compute_metrics_from_confusion_matrix(tp, fp, fn, tn, metrics=['precision', 'recall'])
        prec, rec = metrics['precision'], metrics['recall']
        beta_sq = beta**2
        f_beta = (1 + beta_sq) * safe_divide(prec * rec, (beta_sq * prec) + rec)
        idx = f_beta.argmax()
        return {'threshold': thresholds[idx], 'index': idx, 'f_beta': f_beta[idx]}
    
    elif method == ThresholdSelectionMethod.MAX_ACCURACY:
        acc = (tp + tn).float() / (tp + tn + fp + fn)
        idx = acc.argmax()
        return {'threshold': thresholds[idx], 'index': idx, 'accuracy': acc[idx]}
    
    elif method == ThresholdSelectionMethod.MAX_PRECISION:
        prec = tp.float() / (tp + fp + 1e-10)
        idx = prec.argmax()
        return {'threshold': thresholds[idx], 'index': idx, 'precision': prec[idx]}
    
    elif method == ThresholdSelectionMethod.MAX_RECALL:
        rec = tp.float() / (tp + fn + 1e-10)
        idx = rec.argmax()
        return {'threshold': thresholds[idx], 'index': idx, 'recall': rec[idx]}
    
    elif method == ThresholdSelectionMethod.MIN_COST:
        fp_cost = kwargs.get('fp_cost', 1.0)
        fn_cost = kwargs.get('fn_cost', 1.0)
        cost = fp * fp_cost + fn * fn_cost
        idx = cost.argmin()
        return {'threshold': thresholds[idx], 'index': idx, 'cost': cost[idx]}
    
    elif method == ThresholdSelectionMethod.SENSITIVITY_CONSTRAINT:
        min_sens = kwargs.get('min_sensitivity', 0.9)
        P, N = tp + fn, tn + fp
        tpr = tp.float() / P
        tnr = tn.float() / N
        valid = tpr >= min_sens
        if not valid.any():
            idx = tpr.argmax()
        else:
            tnr_valid = tnr.clone()
            tnr_valid[~valid] = -1
            idx = tnr_valid.argmax()
        return {'threshold': thresholds[idx], 'index': idx, 'specificity': tnr[idx]}
    
    elif method == ThresholdSelectionMethod.SPECIFICITY_CONSTRAINT:
        min_spec = kwargs.get('min_specificity', 0.9)
        P, N = tp + fn, tn + fp
        tpr = tp.float() / P
        tnr = tn.float() / N
        valid = tnr >= min_spec
        if not valid.any():
            idx = tnr.argmax()
        else:
            tpr_valid = tpr.clone()
            tpr_valid[~valid] = -1
            idx = tpr_valid.argmax()
        return {'threshold': thresholds[idx], 'index': idx, 'sensitivity': tpr[idx]}
    
    elif method == ThresholdSelectionMethod.PRECISION_CONSTRAINT:
        min_prec = kwargs.get('min_precision', 0.9)
        prec = tp.float() / (tp + fp + 1e-10)
        rec = tp.float() / (tp + fn + 1e-10)
        valid = prec >= min_prec
        if not valid.any():
            idx = prec.argmax()
        else:
            rec_valid = rec.clone()
            rec_valid[~valid] = -1
            idx = rec_valid.argmax()
        return {'threshold': thresholds[idx], 'index': idx, 'recall': rec[idx]}

def find_all_optimal_thresholds(
    tp: Tensor,
    fp: Tensor,
    tn: Tensor,
    fn: Tensor,
    thresholds: Tensor
) -> Dict[str, Dict[str, Tensor]]:
    """Find optimal thresholds using all common methods.
    
    Returns:
        Dictionary mapping method names to their results
    
    Example:
        >>> all_optimal = find_all_optimal_thresholds(tp, fp, tn, fn, thresholds)
        >>> f1_threshold = all_optimal['max_f1']['threshold']
        >>> youden_threshold = all_optimal['max_youdenj']['threshold']
    """
    methods = ['max_youdenj', 'min_distance', 'max_f1', 'max_accuracy']
    results = {}
    for method in methods:
        results[method] = find_optimal_threshold(tp, fp, tn, fn, thresholds, method=method)
    return results


