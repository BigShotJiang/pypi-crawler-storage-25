
import torch
from torch import Tensor
from typing import Dict, List, Union
from ..utils.functional import safe_divide

__all__ = [
    "compute_metrics_from_confusion_matrix",
    "ALL_CONFUSION_METRICS",
    "COMMON_CONFUSION_METRICS",
]

# Complete list of all available metrics
ALL_CONFUSION_METRICS = [
    'accuracy', 'error_rate', 'precision', 'recall', 'specificity', 'npv',
    'fpr', 'fnr', 'fdr', 'for_', 'f1', 'f2', 'f_half',
    'tss', 'hss', 'mcc', 'informedness', 'markedness',
    'balanced_accuracy', 'fowlkes_mallows', 'cohens_kappa',
    'prevalence', 'detection_rate', 'detection_prevalence',
    'positive_likelihood_ratio', 'negative_likelihood_ratio',
    'diagnostic_odds_ratio',
]

# Common subset of frequently used metrics
COMMON_CONFUSION_METRICS = [
    'accuracy', 'precision', 'recall', 'specificity',
    'f1', 'tss', 'hss', 'mcc',
]


def compute_metrics_from_confusion_matrix(
    tp: Tensor,
    fp: Tensor,
    fn: Tensor,
    tn: Tensor,
    metrics: Union[str, List[str]] = 'all',
    epsilon: float = 1e-7,
) -> Dict[str, Tensor]:
    """Compute metrics from confusion matrix elements.
    
    All division operations use safe_divide with epsilon to handle zero denominators.
    
    Args:
        tp: True Positives, shape [..., T] where T is number of thresholds
        fp: False Positives, shape [..., T]
        fn: False Negatives, shape [..., T]
        tn: True Negatives, shape [..., T]
        metrics: Which metrics to compute
            - 'all': Compute all 30+ metrics
            - 'common': Compute 8 common metrics
            - List[str]: Specific metrics to compute
        epsilon: Small value to add to denominators to avoid division by zero
        
    Returns:
        Dict[str, Tensor]: Computed metrics
        
    Example:
        >>> tp = torch.tensor([90, 80, 70])
        >>> fp = torch.tensor([10, 20, 30])
        >>> fn = torch.tensor([10, 20, 30])
        >>> tn = torch.tensor([90, 80, 70])
        >>> metrics = compute_metrics_from_confusion_matrix(tp, fp, fn, tn)
        >>> print(metrics['accuracy'])
        >>> print(metrics['f1'])
    
    Notes:
        - All metrics handle zero denominators gracefully using epsilon
        - When denominator is zero, metric value will be 0.0
        - For proper handling, check if denominator is actually zero before using
    """
    # Determine which metrics to compute
    if metrics == 'all':
        metrics_to_compute = ALL_CONFUSION_METRICS
    elif metrics == 'common':
        metrics_to_compute = COMMON_CONFUSION_METRICS
    else:
        metrics_to_compute = metrics if isinstance(metrics, list) else [metrics]
    
    results = {}
    
    # Convert to float for division
    tp = tp.float()
    fp = fp.float()
    fn = fn.float()
    tn = tn.float()
    
    # Totals
    total = tp + fp + fn + tn
    p = tp + fn  # Total positives
    n = fp + tn  # Total negatives
    
    # Basic metrics
    if 'accuracy' in metrics_to_compute:
        # Accuracy = (TP + TN) / Total
        results['accuracy'] = safe_divide(tp + tn, total, epsilon)
    
    if 'error_rate' in metrics_to_compute:
        # Error Rate = (FP + FN) / Total
        results['error_rate'] = safe_divide(fp + fn, total, epsilon)
    
    if 'precision' in metrics_to_compute:
        # Precision = TP / (TP + FP)
        results['precision'] = safe_divide(tp, tp + fp, epsilon)
    
    if 'recall' in metrics_to_compute:
        # Recall = TP / (TP + FN) = TPR = Sensitivity
        results['recall'] = safe_divide(tp, tp + fn, epsilon)
    
    if 'specificity' in metrics_to_compute:
        # Specificity = TN / (TN + FP) = TNR
        results['specificity'] = safe_divide(tn, tn + fp, epsilon)
    
    if 'npv' in metrics_to_compute:
        # Negative Predictive Value = TN / (TN + FN)
        results['npv'] = safe_divide(tn, tn + fn, epsilon)
    
    if 'fpr' in metrics_to_compute:
        # False Positive Rate = FP / (FP + TN)
        results['fpr'] = safe_divide(fp, fp + tn, epsilon)
    
    if 'fnr' in metrics_to_compute:
        # False Negative Rate = FN / (FN + TP)
        results['fnr'] = safe_divide(fn, fn + tp, epsilon)
    
    if 'fdr' in metrics_to_compute:
        # False Discovery Rate = FP / (FP + TP)
        results['fdr'] = safe_divide(fp, fp + tp, epsilon)
    
    if 'for_' in metrics_to_compute:
        # False Omission Rate = FN / (FN + TN)
        results['for_'] = safe_divide(fn, fn + tn, epsilon)
    
    # F-scores
    if 'f1' in metrics_to_compute or 'f2' in metrics_to_compute or 'f_half' in metrics_to_compute:
        precision = safe_divide(tp, tp + fp, epsilon)
        recall = safe_divide(tp, tp + fn, epsilon)
        
        if 'f1' in metrics_to_compute:
            # F1 = 2 * Precision * Recall / (Precision + Recall)
            results['f1'] = safe_divide(2 * precision * recall, precision + recall, epsilon)
        
        if 'f2' in metrics_to_compute:
            # F2 = 5 * Precision * Recall / (4 * Precision + Recall)
            results['f2'] = safe_divide(5 * precision * recall, 4 * precision + recall, epsilon)
        
        if 'f_half' in metrics_to_compute:
            # F0.5 = 1.25 * Precision * Recall / (0.25 * Precision + Recall)
            results['f_half'] = safe_divide(1.25 * precision * recall, 0.25 * precision + recall, epsilon)
    
    # Skill scores
    if 'tss' in metrics_to_compute:
        # True Skill Statistic = TPR - FPR = Sensitivity + Specificity - 1
        tpr = safe_divide(tp, tp + fn, epsilon)
        fpr = safe_divide(fp, fp + tn, epsilon)
        results['tss'] = tpr - fpr
    
    if 'hss' in metrics_to_compute:
        # Heidke Skill Score = 2(TP*TN - FP*FN) / ((TP+FN)(FN+TN) + (TP+FP)(FP+TN))
        numerator = 2 * (tp * tn - fp * fn)
        denominator = (tp + fn) * (fn + tn) + (tp + fp) * (fp + tn)
        results['hss'] = safe_divide(numerator, denominator, epsilon)
    
    if 'mcc' in metrics_to_compute:
        # Matthews Correlation Coefficient
        numerator = tp * tn - fp * fn
        denominator = torch.sqrt((tp + fp) * (tp + fn) * (tn + fp) * (tn + fn))
        results['mcc'] = safe_divide(numerator, denominator, epsilon)
    
    if 'informedness' in metrics_to_compute:
        # Informedness = TPR + TNR - 1
        tpr = safe_divide(tp, tp + fn, epsilon)
        tnr = safe_divide(tn, tn + fp, epsilon)
        results['informedness'] = tpr + tnr - 1
    
    if 'markedness' in metrics_to_compute:
        # Markedness = Precision + NPV - 1
        precision = safe_divide(tp, tp + fp, epsilon)
        npv = safe_divide(tn, tn + fn, epsilon)
        results['markedness'] = precision + npv - 1
    
    if 'balanced_accuracy' in metrics_to_compute:
        # Balanced Accuracy = (TPR + TNR) / 2
        tpr = safe_divide(tp, tp + fn, epsilon)
        tnr = safe_divide(tn, tn + fp, epsilon)
        results['balanced_accuracy'] = (tpr + tnr) / 2
    
    if 'fowlkes_mallows' in metrics_to_compute:
        # Fowlkes-Mallows = sqrt(Precision * Recall)
        precision = safe_divide(tp, tp + fp, epsilon)
        recall = safe_divide(tp, tp + fn, epsilon)
        results['fowlkes_mallows'] = torch.sqrt(precision * recall)
    
    if 'cohens_kappa' in metrics_to_compute:
        # Cohen's Kappa
        po = safe_divide(tp + tn, total, epsilon)  # Observed agreement
        pe = safe_divide((tp + fp) * (tp + fn) + (fn + tn) * (fp + tn), total * total, epsilon)  # Expected agreement
        results['cohens_kappa'] = safe_divide(po - pe, 1 - pe, epsilon)
    
    if 'prevalence' in metrics_to_compute:
        # Prevalence = (TP + FN) / Total
        results['prevalence'] = safe_divide(tp + fn, total, epsilon)
    
    if 'detection_rate' in metrics_to_compute:
        # Detection Rate = TP / Total
        results['detection_rate'] = safe_divide(tp, total, epsilon)
    
    if 'detection_prevalence' in metrics_to_compute:
        # Detection Prevalence = (TP + FP) / Total
        results['detection_prevalence'] = safe_divide(tp + fp, total, epsilon)
    
    if 'positive_likelihood_ratio' in metrics_to_compute:
        # Positive Likelihood Ratio = TPR / FPR
        tpr = safe_divide(tp, tp + fn, epsilon)
        fpr = safe_divide(fp, fp + tn, epsilon)
        results['positive_likelihood_ratio'] = safe_divide(tpr, fpr, epsilon)
    
    if 'negative_likelihood_ratio' in metrics_to_compute:
        # Negative Likelihood Ratio = FNR / TNR
        fnr = safe_divide(fn, fn + tp, epsilon)
        tnr = safe_divide(tn, tn + fp, epsilon)
        results['negative_likelihood_ratio'] = safe_divide(fnr, tnr, epsilon)
    
    if 'diagnostic_odds_ratio' in metrics_to_compute:
        # Diagnostic Odds Ratio = (TP * TN) / (FP * FN)
        results['diagnostic_odds_ratio'] = safe_divide(tp * tn, fp * fn, epsilon)
    
    return results
