
from functools import wraps
from typing import Callable, Any


def auto_update(func: Callable) -> Callable:
    """
    Decorator that tracks update calls for the decorated update method.

    This decorator is applied to metric update() methods to track updates
    and mark the metric as needing recomputation.

    Args:
        func: The update method to decorate

    Returns:
        Wrapped update method

    Example::

        class MyMetric(BaseTorchMetric):
            @auto_update
            def update(self, preds, target):
                self.preds.append(preds)
                self.target.append(target)
    """
    @wraps(func)
    def wrapper(self, *args, **kwargs):
        # Track update and mark as not computed
        self._update_count = getattr(self, '_update_count', 0) + 1
        self._computed = False
        # Call the actual update method
        return func(self, *args, **kwargs)
    return wrapper


def auto_compute(func: Callable) -> Callable:
    """
    Decorator that automatically calls _apply_reduction() before the decorated compute method.

    This decorator is applied to metric compute() methods to ensure distributed
    reduction is performed before computing final results. It eliminates the need
    to manually call self._apply_reduction() in every metric class.

    Args:
        func: The compute method to decorate

    Returns:
        Wrapped compute method that calls _apply_reduction() automatically

    Example::

        class MyMetric(BaseTorchMetric):
            @auto_compute
            def compute(self):
                # self._apply_reduction() is called automatically
                preds = torch.cat(self.preds)
                target = torch.cat(self.target)
                return compute_accuracy(preds, target)
    """
    @wraps(func)
    def wrapper(self, *args, **kwargs):
        # Check if auto_reduction is enabled (default True)
        # Only call _apply_reduction if the object has it (BaseTorchMetric subclasses)
        if getattr(self, '_auto_reduction', True) and hasattr(self, '_apply_reduction'):
            self._apply_reduction()
        # Call the actual compute method
        return func(self, *args, **kwargs)
    return wrapper


def multi_device_transfer(func: Callable) -> Callable:
    """
    Decorator that automatically handles tensor device transfer.
    
    This decorator ensures all tensor arguments are moved to the metric's device
    before processing. Useful for update() methods that receive external tensors.
    
    Args:
        func: The method to decorate
        
    Returns:
        Wrapped method that transfers tensors to correct device
        
    Example::

        class MyMetric(BaseTorchMetric):
            @multi_device_transfer
            def update(self, preds, target):
                # preds and target are automatically on self.device
                self.preds.append(preds)
    """
    @wraps(func)
    def wrapper(self, *args, **kwargs):
        import torch
        
        # Get metric device
        device = getattr(self, 'device', None)
        if device is None:
            return func(self, *args, **kwargs)
        
        # Transfer tensor args to device
        new_args = []
        for arg in args:
            if isinstance(arg, torch.Tensor):
                new_args.append(arg.to(device))
            else:
                new_args.append(arg)
        
        # Transfer tensor kwargs to device
        new_kwargs = {}
        for key, value in kwargs.items():
            if isinstance(value, torch.Tensor):
                new_kwargs[key] = value.to(device)
            else:
                new_kwargs[key] = value
        
        return func(self, *new_args, **new_kwargs)
    return wrapper


def validate_inputs(func: Callable) -> Callable:
    """
    Decorator that validates input shapes and types.
    
    This decorator performs basic validation on inputs to update() methods,
    checking for tensor types and compatible shapes.
    
    Args:
        func: The update method to decorate
        
    Returns:
        Wrapped update method with input validation
    """
    @wraps(func)
    def wrapper(self, preds, target, *args, **kwargs):
        import torch
        
        # Check tensor types
        if not isinstance(preds, torch.Tensor):
            raise TypeError(f"preds must be a torch.Tensor, got {type(preds)}")
        if not isinstance(target, torch.Tensor):
            raise TypeError(f"target must be a torch.Tensor, got {type(target)}")
        
        # Check shapes are compatible (same batch dimension)
        if preds.shape[0] != target.shape[0]:
            raise ValueError(
                f"Batch size mismatch: preds has {preds.shape[0]} samples, "
                f"target has {target.shape[0]} samples"
            )
        
        return func(self, preds, target, *args, **kwargs)
    return wrapper
