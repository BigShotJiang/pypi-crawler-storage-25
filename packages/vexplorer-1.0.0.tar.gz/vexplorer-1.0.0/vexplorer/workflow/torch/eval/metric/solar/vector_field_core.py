# -*- coding: utf-8 -*-
"""
Pure-functional core computations for solar vector magnetic field metrics.

Design
------
The module is organised in five layers:

1. **Differential operators** — :func:`compute_spatial_gradients`,
   :func:`divergence_from_gradients`, :func:`curl_from_gradients`,
   :func:`field_norm`.  These are the composable building blocks.  When
   divergence *and* curl are both needed, call
   :func:`compute_spatial_gradients` once and derive both from the result to
   avoid repeating the three ``torch.gradient`` evaluations.  Convenience
   wrappers :func:`compute_divergence` and :func:`compute_curl` are provided
   for the single-metric case.

2. **Physics building blocks** — :func:`normalized_divergence_field` and
   :func:`weighted_sine_terms`.  These produce per-voxel values from
   pre-computed gradients / norms so that the caller controls reuse.

3. **Physics stat accumulators** — :func:`compute_normalized_divergence_stats`,
   :func:`compute_current_weighted_sine_stats`, and the combined
   :func:`compute_physics_stats` which shares gradients and |B| across both
   physics metrics and returns ``B_norm`` for downstream reuse.

4. **Comparison stat accumulators** — one function per metric plus
   :func:`compute_all_comparison_stats`, which computes all shared
   intermediates (dot, pred_sq, pred_norm, diff, cross) exactly once.

5. **Finalisers** — ``*_from_stats`` functions that convert accumulated
   tensors into final scalar metrics.

Tensor convention
-----------------
  B    : ``(batch, 3, D, H, W, T)`` — channels are [Bx, By, Bz]
  mask : ``(batch, D, H, W, T)``    — optional bool mask over valid voxels

References
----------
Schrijver, C. J. et al. (2006), Sol. Phys., 235, 161–190.
Metcalf, T. R. et al. (2008), Sol. Phys., 247, 269–299.
"""

from __future__ import annotations

import math
from typing import Dict, Optional, Tuple

import torch
from torch import Tensor

# Per-component gradient 3-tuple: (∂B/∂x, ∂B/∂y, ∂B/∂z)
_GradTriple = Tuple[Tensor, Tensor, Tensor]
# All 9 spatial partial derivatives: (grads_Bx, grads_By, grads_Bz)
SpatialGradients = Tuple[_GradTriple, _GradTriple, _GradTriple]

_8PI = 8.0 * math.pi

__all__ = [
    # Validation
    "validate_vector_field",
    "validate_mask",
    # --- Layer 1: Differential operators ---
    "compute_spatial_gradients",    # all 9 ∂B/∂xi  (shared basis for div + curl)
    "divergence_from_gradients",    # ∇·B  from pre-computed gradients
    "curl_from_gradients",          # ∇×B  from pre-computed gradients
    "field_norm",                   # |B|  per voxel
    "compute_divergence",           # convenience: ∇·B directly from B
    "compute_curl",                 # convenience: ∇×B directly from B
    # --- Layer 2: Physics building blocks (per-voxel, no accumulation) ---
    "normalized_divergence_field",  # |∇·B| / (6|B|/dx + ε) per voxel
    "weighted_sine_terms",          # (|J|·sin θ,  |J|) per voxel  → CWsin
    # --- Layer 3: Physics stat accumulators ---
    "compute_normalized_divergence_stats",
    "compute_current_weighted_sine_stats",
    "compute_physics_stats",        # combined: shared grads + norm across both
    # --- Layer 4: Comparison stat accumulators (individual) ---
    "compute_vector_correlation_stats",
    "compute_cauchy_schwarz_stats",
    "compute_mean_vector_error_stats",
    "compute_mean_angular_error_stats",
    "compute_energy_ratio_stats",
    "compute_component_error_stats",    # MAE + RMSE in one diff pass
    "compute_component_mae_stats",      # MAE only (thin wrapper)
    "compute_component_rmse_stats",     # RMSE only (thin wrapper)
    "compute_magnetic_energy_stats",
    # --- Layer 4: Comparison stat accumulator (combined single-pass) ---
    "compute_all_comparison_stats",
    # --- Layer 5: Finalisers ---
    "vector_correlation_from_stats",
    "cauchy_schwarz_from_stats",
    "mean_vector_error_from_stats",
    "mean_angular_error_from_stats",
    "energy_ratio_from_stats",
    "component_mae_from_stats",
    "component_rmse_from_stats",
    "component_errors_from_stats",      # combined MAE + RMSE finaliser
    "magnetic_energy_from_stats",
    "normalized_divergence_from_stats",
    "current_weighted_sine_from_stats",
]


# =============================================================================
# Validation
# =============================================================================

def validate_vector_field(B: Tensor, name: str = "B") -> None:
    """Assert *B* is a 6-D field with exactly 3 channels.

    Parameters
    ----------
    B : Tensor
        Expected shape ``(batch, 3, D, H, W, T)``.
    name : str
        Variable name used in error messages.

    Raises
    ------
    ValueError
        If ``B.ndim != 6`` or ``B.shape[1] != 3``.
    """
    if B.ndim != 6:
        raise ValueError(
            f"{name} must be 6-D (batch, 3, D, H, W, T), got shape {list(B.shape)}"
        )
    if B.shape[1] != 3:
        raise ValueError(
            f"{name} channel dim must be 3 (Bx, By, Bz), got {B.shape[1]}"
        )


def validate_mask(mask: Tensor, expected_shape: Tuple[int, ...]) -> None:
    """Assert *mask* has dtype ``torch.bool`` and the expected shape.

    Parameters
    ----------
    mask : Tensor
        Boolean mask, shape ``(batch, D, H, W, T)``.
    expected_shape : tuple of int
        Expected mask shape ``(batch, D, H, W, T)``.

    Raises
    ------
    ValueError
        If dtype is not ``torch.bool`` or shape does not match.
    """
    if mask.dtype != torch.bool:
        raise ValueError(f"mask dtype must be torch.bool, got {mask.dtype}")
    if mask.shape != expected_shape:
        raise ValueError(
            f"mask shape {list(mask.shape)} does not match expected {list(expected_shape)}"
        )


# =============================================================================
# Internal helpers
# =============================================================================

def _spatial_sum(x: Tensor, mask: Optional[Tensor]) -> Tensor:
    """Masked or global sum over all voxels of a spatial field ``(batch, D, H, W, T)``."""
    return (x * mask).sum() if mask is not None else x.sum()


def _n_voxels(mask: Optional[Tensor], B: Tensor) -> Tensor:
    """Number of valid voxels as a float32 scalar tensor.

    Uses *mask* if provided; falls back to the full spatial volume of *B*.
    """
    if mask is not None:
        return mask.sum().float()
    n = B.shape[0] * B.shape[2] * B.shape[3] * B.shape[4] * B.shape[5]
    return torch.tensor(n, dtype=torch.float32, device=B.device)


# =============================================================================
# Layer 1 — Differential operators
# =============================================================================

def compute_spatial_gradients(B: Tensor, dx: float = 0.36) -> SpatialGradients:
    """Compute all 9 first-order spatial partial derivatives of **B**.

    Uses ``torch.gradient`` (``edge_order=2``) over the three spatial
    dimensions (D, H, W), leaving the time axis T untouched.

    Parameters
    ----------
    B : Tensor
        Magnetic field, shape ``(batch, 3, D, H, W, T)``.
    dx : float
        Isotropic grid spacing in physical units (default 0.36 Mm, downsample 1 times, 0.36*2, 2 times was 0.36*4).

    Returns
    -------
    grads_Bx, grads_By, grads_Bz : each a 3-tuple ``(∂B/∂x, ∂B/∂y, ∂B/∂z)``
        of tensors shaped ``(batch, D, H, W, T)``.

    Notes
    -----
    **Shared basis for divergence and curl.**  When both are needed, call
    this function once and pass the result to :func:`divergence_from_gradients`
    *and* :func:`curl_from_gradients` to avoid repeating three
    ``torch.gradient`` calls::

        grads = compute_spatial_gradients(B, dx)
        div_B = divergence_from_gradients(*grads)   # ∇·B
        J     = curl_from_gradients(*grads)          # ∇×B

    The returned ``grads`` can also be held alongside :func:`field_norm` to
    feed all physics and comparison metrics in one combined pass.

    Raises
    ------
    ValueError
        If ``B.shape[1] != 3`` or any spatial dimension is < 3.
    """
    if B.shape[1] != 3:
        raise ValueError(f"Channel dim must be 3 (Bx, By, Bz), got {B.shape[1]}")
    D, H, W = B.shape[2], B.shape[3], B.shape[4]
    if min(D, H, W) < 3:
        raise ValueError(
            f"torch.gradient(edge_order=2) requires spatial dims >= 3, "
            f"got D={D}, H={H}, W={W}."
        )

    Bx, By, Bz = B[:, 0], B[:, 1], B[:, 2]   # each (batch, D, H, W, T)
    dims    = (1, 2, 3)                         # spatial axes in (batch, D, H, W, T)
    spacing = (dx, dx, dx)

    grads_Bx = torch.gradient(Bx, spacing=spacing, dim=dims, edge_order=2)
    grads_By = torch.gradient(By, spacing=spacing, dim=dims, edge_order=2)
    grads_Bz = torch.gradient(Bz, spacing=spacing, dim=dims, edge_order=2)

    return grads_Bx, grads_By, grads_Bz


def divergence_from_gradients(
    grads_Bx: _GradTriple,
    grads_By: _GradTriple,
    grads_Bz: _GradTriple,
) -> Tensor:
    """Compute ∇·B from pre-computed spatial gradients.

    .. math::

        \\nabla \\cdot \\mathbf{B} =
        \\frac{\\partial B_x}{\\partial x} +
        \\frac{\\partial B_y}{\\partial y} +
        \\frac{\\partial B_z}{\\partial z}

    Parameters
    ----------
    grads_Bx, grads_By, grads_Bz
        Output of :func:`compute_spatial_gradients`.

    Returns
    -------
    div_B : Tensor, shape ``(batch, D, H, W, T)``
    """
    return grads_Bx[0] + grads_By[1] + grads_Bz[2]


def curl_from_gradients(
    grads_Bx: _GradTriple,
    grads_By: _GradTriple,
    grads_Bz: _GradTriple,
) -> Tensor:
    """Compute ∇×B (current density **J**) from pre-computed spatial gradients.

    .. math::

        \\nabla \\times \\mathbf{B} = \\begin{pmatrix}
            \\partial_y B_z - \\partial_z B_y \\\\
            \\partial_z B_x - \\partial_x B_z \\\\
            \\partial_x B_y - \\partial_y B_x
        \\end{pmatrix}

    Parameters
    ----------
    grads_Bx, grads_By, grads_Bz
        Output of :func:`compute_spatial_gradients`.

    Returns
    -------
    J : Tensor, shape ``(batch, 3, D, H, W, T)``
    """
    Jx = grads_Bz[1] - grads_By[2]
    Jy = grads_Bx[2] - grads_Bz[0]
    Jz = grads_By[0] - grads_Bx[1]
    return torch.stack([Jx, Jy, Jz], dim=1)


def field_norm(B: Tensor) -> Tensor:
    """Per-voxel field magnitude :math:`|\\mathbf{B}| = \\sqrt{B_x^2+B_y^2+B_z^2}`.

    Parameters
    ----------
    B : Tensor, shape ``(batch, 3, D, H, W, T)``

    Returns
    -------
    norm : Tensor, shape ``(batch, D, H, W, T)``

    Notes
    -----
    The result equals the ``pred_norm`` computed internally by
    :func:`compute_all_comparison_stats` and can be supplied as
    *B_pred_norm* to skip recomputation there.
    """
    return torch.linalg.vector_norm(B, ord=2, dim=1)


def compute_divergence(B: Tensor, dx: float = 0.36) -> Tensor:
    """Compute ∇·B directly from **B** (single-metric convenience wrapper).

    When curl is also needed, prefer :func:`compute_spatial_gradients` once
    followed by both ``*_from_gradients`` functions to avoid redundant
    ``torch.gradient`` calls.

    Returns
    -------
    div_B : Tensor, shape ``(batch, D, H, W, T)``
    """
    return divergence_from_gradients(*compute_spatial_gradients(B, dx))


def compute_curl(B: Tensor, dx: float = 0.36) -> Tensor:
    """Compute ∇×B (current density J) directly from **B** (single-metric convenience wrapper).

    When divergence is also needed, prefer :func:`compute_spatial_gradients`
    once followed by both ``*_from_gradients`` functions.

    Returns
    -------
    J : Tensor, shape ``(batch, 3, D, H, W, T)``
    """
    return curl_from_gradients(*compute_spatial_gradients(B, dx))


# =============================================================================
# Layer 2 — Physics metric building blocks (per-voxel, no accumulation)
# =============================================================================

def normalized_divergence_field(
    div_B: Tensor,
    B_norm: Tensor,
    dx: float,
    eps: float = 1e-8,
) -> Tensor:
    """Per-voxel normalised divergence: :math:`f_i = |\\nabla\\cdot\\mathbf{B}| / (6|\\mathbf{B}|/dx + \\varepsilon)`.

    The spatial mean ⟨f⟩ is the NormalizedDivergence metric.

    Parameters
    ----------
    div_B : Tensor, shape ``(batch, D, H, W, T)``
        Output of :func:`divergence_from_gradients`.
    B_norm : Tensor, shape ``(batch, D, H, W, T)``
        Output of :func:`field_norm`.
    dx : float
        Isotropic grid spacing.
    eps : float
        Numerical stability.

    Returns
    -------
    f : Tensor, shape ``(batch, D, H, W, T)``
    """
    return div_B.abs() / (6.0 * B_norm / dx + eps)


def weighted_sine_terms(
    J: Tensor,
    B: Tensor,
    B_norm: Tensor,
    eps: float = 1e-8,
) -> Tuple[Tensor, Tensor]:
    """Per-voxel numerator and denominator for Current-Weighted Sine (CWsin).

    .. math::

        \\text{CWsin} =
        \\frac{\\sum_i |\\mathbf{J}_i|\\,\\sin\\theta_i}
              {\\sum_i |\\mathbf{J}_i|}

    where :math:`\\sin\\theta_i =
    |\\mathbf{J}_i\\times\\mathbf{B}_i|\\,/\\,(|\\mathbf{J}_i||\\mathbf{B}_i|)`.

    Parameters
    ----------
    J : Tensor
        Current density ∇×B, shape ``(batch, 3, D, H, W, T)``.
    B : Tensor
        Magnetic field, shape ``(batch, 3, D, H, W, T)``.
    B_norm : Tensor
        Field magnitude |B|, shape ``(batch, D, H, W, T)``.
    eps : float
        Numerical stability (added to |J| before division).

    Returns
    -------
    J_sin : Tensor, shape ``(batch, D, H, W, T)``
        :math:`|\\mathbf{J}|\\sin\\theta` per voxel — accumulate as numerator.
    J_norm : Tensor, shape ``(batch, D, H, W, T)``
        :math:`|\\mathbf{J}|` (eps-stabilised) per voxel — accumulate as denominator.

    Notes
    -----
    Both outputs share the same |J| computation.  Accumulate::

        cwsin_num += _spatial_sum(J_sin,  mask)
        cwsin_den += _spatial_sum(J_norm, mask)

    and finalise with :func:`current_weighted_sine_from_stats`.
    """
    J_norm    = field_norm(J) + eps                          # |J| + ε, stabilised
    cross     = torch.linalg.cross(J, B, dim=1)             # J × B, (batch, 3, D, H, W, T)
    sin_theta = field_norm(cross) / (J_norm * B_norm + eps)  # sin θ per voxel
    return J_norm * sin_theta, J_norm                        # (|J|·sinθ, |J|)


# =============================================================================
# Layer 3 — Physics stat accumulators
# =============================================================================

def compute_normalized_divergence_stats(
    B: Tensor,
    dx: float = 0.36,
    mask: Optional[Tensor] = None,
    eps: float = 1e-8,
    B_norm: Optional[Tensor] = None,
) -> Tuple[Tensor, Tensor]:
    """Accumulate statistics for the Normalised Divergence metric.

    Parameters
    ----------
    B : Tensor, shape ``(batch, 3, D, H, W, T)``
    dx : float — grid spacing
    mask : Tensor or None — boolean voxel mask
    eps : float — numerical stability
    B_norm : Tensor or None
        Pre-computed :func:`field_norm` output; pass to skip recomputation.

    Returns
    -------
    div_sum, count : Tensor
        Pass to :func:`normalized_divergence_from_stats`.
    """
    grads = compute_spatial_gradients(B, dx)
    div_B = divergence_from_gradients(*grads)
    if B_norm is None:
        B_norm = field_norm(B)
    f = normalized_divergence_field(div_B, B_norm, dx, eps)
    return _spatial_sum(f, mask), _n_voxels(mask, B)


def compute_current_weighted_sine_stats(
    B: Tensor,
    dx: float = 0.36,
    mask: Optional[Tensor] = None,
    eps: float = 1e-8,
    B_norm: Optional[Tensor] = None,
) -> Tuple[Tensor, Tensor]:
    """Accumulate statistics for the Current-Weighted Sine metric.

    Parameters
    ----------
    B : Tensor, shape ``(batch, 3, D, H, W, T)``
    dx, mask, eps : see :func:`compute_normalized_divergence_stats`
    B_norm : Tensor or None — pre-computed |B|; pass to skip recomputation.

    Returns
    -------
    cwsin_num, cwsin_den : Tensor
        Pass to :func:`current_weighted_sine_from_stats`.
    """
    grads = compute_spatial_gradients(B, dx)
    J     = curl_from_gradients(*grads)
    if B_norm is None:
        B_norm = field_norm(B)
    J_sin, J_norm_f = weighted_sine_terms(J, B, B_norm, eps)
    return _spatial_sum(J_sin, mask), _spatial_sum(J_norm_f, mask)


def compute_physics_stats(
    B: Tensor,
    dx: float = 0.36,
    mask: Optional[Tensor] = None,
    eps: float = 1e-8,
    compute_norm_div: bool = True,
    compute_cwsin: bool = True,
) -> Dict[str, Tensor]:
    """Compute physics metric statistics sharing spatial gradients and field norm.

    When both NormalizedDivergence and CWsin are needed, use this function so
    that :func:`compute_spatial_gradients` and :func:`field_norm` are each
    called exactly once.

    Parameters
    ----------
    B : Tensor, shape ``(batch, 3, D, H, W, T)``
    dx : float — grid spacing
    mask : Tensor or None — boolean voxel mask
    eps : float — numerical stability
    compute_norm_div : bool — accumulate NormalizedDivergence stats
    compute_cwsin : bool — accumulate CWsin stats

    Returns
    -------
    stats : dict
        Keys present depending on flags:

        * ``"div_sum"``, ``"div_count"``   — if *compute_norm_div*
        * ``"cwsin_num"``, ``"cwsin_den"`` — if *compute_cwsin*
        * ``"B_norm"``                     — always; reuse as *B_pred_norm*
          in :func:`compute_all_comparison_stats` to skip a redundant
          :func:`field_norm` call.
    """
    grads  = compute_spatial_gradients(B, dx)
    B_norm = field_norm(B)

    stats: Dict[str, Tensor] = {"B_norm": B_norm}

    if compute_norm_div:
        div_B = divergence_from_gradients(*grads)
        f     = normalized_divergence_field(div_B, B_norm, dx, eps)
        stats["div_sum"]   = _spatial_sum(f, mask)
        stats["div_count"] = _n_voxels(mask, B)

    if compute_cwsin:
        J              = curl_from_gradients(*grads)
        J_sin, J_norm_f = weighted_sine_terms(J, B, B_norm, eps)
        stats["cwsin_num"] = _spatial_sum(J_sin,    mask)
        stats["cwsin_den"] = _spatial_sum(J_norm_f, mask)

    return stats


# =============================================================================
# Layer 4 — Comparison metric stat accumulators
# =============================================================================

# --- 1. Vector Correlation  Cv --------------------------------------------

def compute_vector_correlation_stats(
    B_pred: Tensor,
    B_target: Tensor,
    mask: Optional[Tensor] = None,
) -> Tuple[Tensor, Tensor, Tensor]:
    """Accumulate statistics for Vector Correlation (Cv).

    .. math::

        C_v = \\frac{\\sum_i \\mathbf{B}_i \\cdot \\mathbf{B}'_i}
                    {\\sqrt{\\sum_i |\\mathbf{B}_i|^2
                            \\sum_i |\\mathbf{B}'_i|^2}}

    Perfect reconstruction gives :math:`C_v = 1`.  Range: [-1, 1].

    Returns
    -------
    dot_sum, pred_sq_sum, target_sq_sum : Tensor
        Pass to :func:`vector_correlation_from_stats`.
    """
    dot       = (B_pred * B_target).sum(dim=1)
    pred_sq   = (B_pred   * B_pred).sum(dim=1)
    target_sq = (B_target * B_target).sum(dim=1)
    return (
        _spatial_sum(dot,       mask),
        _spatial_sum(pred_sq,   mask),
        _spatial_sum(target_sq, mask),
    )


# --- 2. Cauchy-Schwarz Metric  Cs -----------------------------------------

def compute_cauchy_schwarz_stats(
    B_pred: Tensor,
    B_target: Tensor,
    mask: Optional[Tensor] = None,
    eps: float = 1e-8,
) -> Tuple[Tensor, Tensor]:
    """Accumulate statistics for the Cauchy-Schwarz Metric (Cs).

    .. math::

        C_s = \\frac{1}{N} \\sum_i
              \\frac{\\mathbf{B}_i \\cdot \\mathbf{B}'_i}
                   {|\\mathbf{B}_i|\\,|\\mathbf{B}'_i|}

    Mean per-voxel cosine similarity.
    Perfect reconstruction gives :math:`C_s = 1`.  Range: [-1, 1].

    Returns
    -------
    cos_sum, count : Tensor
        Pass to :func:`cauchy_schwarz_from_stats`.
    """
    dot     = (B_pred * B_target).sum(dim=1)
    cos_sim = dot / (field_norm(B_pred) * field_norm(B_target) + eps)
    return _spatial_sum(cos_sim, mask), _n_voxels(mask, B_pred)


# --- 3. Mean Vector Error  En ---------------------------------------------

def compute_mean_vector_error_stats(
    B_pred: Tensor,
    B_target: Tensor,
    mask: Optional[Tensor] = None,
) -> Tuple[Tensor, Tensor]:
    """Accumulate statistics for Mean Vector Error (En).

    .. math::

        E_n = \\frac{\\sum_i |\\mathbf{B}_i - \\mathbf{B}'_i|}
                    {\\sum_i |\\mathbf{B}'_i|}

    Perfect reconstruction gives :math:`E_n = 0`.

    Returns
    -------
    error_norm_sum, ref_norm_sum : Tensor
        Pass to :func:`mean_vector_error_from_stats`.
    """
    diff = B_pred - B_target
    return _spatial_sum(field_norm(diff), mask), _spatial_sum(field_norm(B_target), mask)


# --- 4. Mean Angular Error  ⟨sin θ⟩ ----------------------------------------

def compute_mean_angular_error_stats(
    B_pred: Tensor,
    B_target: Tensor,
    mask: Optional[Tensor] = None,
    eps: float = 1e-8,
) -> Tuple[Tensor, Tensor]:
    """Accumulate statistics for Mean Angular Error ⟨sin θ⟩.

    .. math::

        \\langle \\sin\\theta \\rangle =
        \\frac{1}{N} \\sum_i
        \\frac{|\\mathbf{B}_i \\times \\mathbf{B}'_i|}
             {|\\mathbf{B}_i|\\,|\\mathbf{B}'_i|}

    Perfect reconstruction gives :math:`\\langle \\sin\\theta \\rangle = 0`.
    Range: [0, 1].

    Returns
    -------
    sin_sum, count : Tensor
        Pass to :func:`mean_angular_error_from_stats`.
    """
    cross     = torch.linalg.cross(B_pred, B_target, dim=1)
    sin_theta = field_norm(cross) / (field_norm(B_pred) * field_norm(B_target) + eps)
    return _spatial_sum(sin_theta, mask), _n_voxels(mask, B_pred)


# --- 5. Energy Ratio  ε ---------------------------------------------------

def compute_energy_ratio_stats(
    B_pred: Tensor,
    B_target: Tensor,
    mask: Optional[Tensor] = None,
) -> Tuple[Tensor, Tensor]:
    """Accumulate statistics for Energy Ratio (ε).

    .. math::

        \\varepsilon = \\frac{\\sum_i |\\mathbf{B}_i|^2}
                            {\\sum_i |\\mathbf{B}'_i|^2}

    Perfect reconstruction gives :math:`\\varepsilon = 1`.

    Returns
    -------
    pred_energy, target_energy : Tensor
        Pass to :func:`energy_ratio_from_stats`.
    """
    return (
        _spatial_sum((B_pred   * B_pred).sum(dim=1),   mask),
        _spatial_sum((B_target * B_target).sum(dim=1), mask),
    )


# --- 6. Component errors — MAE and RMSE per channel (Bx, By, Bz) ----------

def compute_component_error_stats(
    B_pred: Tensor,
    B_target: Tensor,
    mask: Optional[Tensor] = None,
) -> Tuple[Tensor, Tensor, Tensor]:
    """Accumulate per-component MAE **and** RMSE statistics in one pass.

    Computes ``B_pred − B_target`` once and derives both absolute and
    squared error sums, avoiding redundant subtraction when both metrics
    are needed.

    Returns
    -------
    abs_sum : Tensor, shape ``(3,)``
        :math:`\\sum_i |\\text{error}|` per channel.
    sq_sum : Tensor, shape ``(3,)``
        :math:`\\sum_i \\text{error}^2` per channel.
    count : Tensor
        Float32 scalar — number of valid voxels (same for all channels).
    """
    diff     = B_pred - B_target                             # (B, 3, D, H, W, T)
    abs_diff = diff.abs()
    sq_diff  = diff * diff                                   # faster than diff**2
    rdims    = [0, 2, 3, 4, 5]                               # batch + spatial + time

    if mask is not None:
        m       = mask.unsqueeze(1)                          # (B, 1, D, H, W, T)
        abs_sum = (abs_diff * m).sum(dim=rdims)
        sq_sum  = (sq_diff  * m).sum(dim=rdims)
        count   = mask.sum().float()
    else:
        abs_sum = abs_diff.sum(dim=rdims)
        sq_sum  = sq_diff.sum(dim=rdims)
        n       = diff.shape[0] * diff.shape[2] * diff.shape[3] * diff.shape[4] * diff.shape[5]
        count   = torch.tensor(n, dtype=torch.float32, device=B_pred.device)

    return abs_sum, sq_sum, count


def compute_component_mae_stats(
    B_pred: Tensor,
    B_target: Tensor,
    mask: Optional[Tensor] = None,
) -> Tuple[Tensor, Tensor]:
    """Per-component MAE statistics only.

    Prefer :func:`compute_component_error_stats` when RMSE is also needed.

    Returns abs_sum ``(3,)``, count (scalar float32).
    """
    abs_sum, _, count = compute_component_error_stats(B_pred, B_target, mask)
    return abs_sum, count


def compute_component_rmse_stats(
    B_pred: Tensor,
    B_target: Tensor,
    mask: Optional[Tensor] = None,
) -> Tuple[Tensor, Tensor]:
    """Per-component RMSE statistics only.

    Prefer :func:`compute_component_error_stats` when MAE is also needed.

    Returns sq_sum ``(3,)``, count (scalar float32).
    """
    _, sq_sum, count = compute_component_error_stats(B_pred, B_target, mask)
    return sq_sum, count


# --- 7. Magnetic Energy  E ------------------------------------------------

def compute_magnetic_energy_stats(
    B: Tensor,
    dx: float = 0.36,
    mask: Optional[Tensor] = None,
) -> Tensor:
    """Accumulate total magnetic energy in physical units.

    .. math::

        E = \\frac{dx^3}{8\\pi} \\sum_i |\\mathbf{B}_i|^2

    Returns
    -------
    energy_sum : Tensor (scalar)
        Pass to :func:`magnetic_energy_from_stats`.
    """
    return _spatial_sum((B * B).sum(dim=1), mask) * ((dx ** 3) / _8PI)


# --- 8. Combined: all comparison metrics, single shared forward pass ------

def compute_all_comparison_stats(
    B_pred: Tensor,
    B_target: Tensor,
    mask: Optional[Tensor] = None,
    eps: float = 1e-8,
    B_pred_norm: Optional[Tensor] = None,
    compute_vc: bool = True,
    compute_cs: bool = True,
    compute_en: bool = True,
    compute_ang: bool = True,
    compute_er: bool = True,
    compute_comp_mae: bool = True,
    compute_comp_rmse: bool = True,
) -> Dict[str, Tensor]:
    """Compute all comparison-metric statistics in a **single shared forward pass**.

    Shared intermediates are computed at most once and reused across metrics:

    * ``dot``       — used by Cv, Cs
    * ``pred_sq``   — used by Cv, ε; its sqrt gives ``pred_norm``
    * ``target_sq`` — used by Cv, ε; its sqrt gives ``targ_norm``
    * ``pred_norm`` — used by Cs, En, angular; supply via *B_pred_norm*
                      (e.g. from :func:`compute_physics_stats`) to skip
                      recomputation when physics metrics ran first
    * ``targ_norm`` — used by Cs, En, angular
    * ``diff``      — used by En, component MAE/RMSE

    Parameters
    ----------
    B_pred, B_target : Tensor, shape ``(batch, 3, D, H, W, T)``
    mask : optional boolean mask ``(batch, D, H, W, T)``
    eps : numerical stability constant
    B_pred_norm : pre-computed :func:`field_norm` (B_pred); when provided the
        function skips the internal ``pred_norm`` computation.  Typically
        the ``"B_norm"`` value returned by :func:`compute_physics_stats`.
    compute_vc, compute_cs, compute_en, compute_ang, compute_er,
    compute_comp_mae, compute_comp_rmse : bool
        Enable individual metric groups.

    Returns
    -------
    stats : dict
        A unified ``"count"`` key is shared by Cs, angular, and all
        component metrics (they always have the same denominator).
    """
    validate_vector_field(B_pred,   "B_pred")
    validate_vector_field(B_target, "B_target")
    if mask is not None:
        validate_mask(mask, B_pred[:, 0].shape)

    stats: Dict[str, Tensor] = {}

    # --- Determine which intermediates are needed ---
    need_dot       = compute_vc or compute_cs
    need_pred_sq   = compute_vc or compute_er
    need_target_sq = compute_vc or compute_er
    need_pred_norm = (compute_cs or compute_ang) and (B_pred_norm is None)
    need_targ_norm = compute_cs or compute_en or compute_ang
    need_diff      = compute_en or compute_comp_mae or compute_comp_rmse
    need_cross     = compute_ang

    # --- Compute shared intermediates (lazily) ---
    dot:       Optional[Tensor] = None
    pred_sq:   Optional[Tensor] = None
    target_sq: Optional[Tensor] = None
    pred_norm: Optional[Tensor] = B_pred_norm   # may already be supplied
    targ_norm: Optional[Tensor] = None
    diff:      Optional[Tensor] = None
    cross:     Optional[Tensor] = None

    if need_dot:
        dot = (B_pred * B_target).sum(dim=1)

    if need_pred_sq:
        pred_sq = (B_pred * B_pred).sum(dim=1)

    if need_target_sq:
        target_sq = (B_target * B_target).sum(dim=1)

    if need_pred_norm:
        # Reuse pred_sq.sqrt() if already computed, otherwise call field_norm
        pred_norm = (
            pred_sq.sqrt() if pred_sq is not None
            else field_norm(B_pred)
        )

    if need_targ_norm:
        targ_norm = (
            target_sq.sqrt() if target_sq is not None
            else field_norm(B_target)
        )

    if need_diff:
        diff = B_pred - B_target

    if need_cross:
        cross = torch.linalg.cross(B_pred, B_target, dim=1)

    # Unified count (float32 scalar) — Cs, angular, and component metrics share it
    count: Optional[Tensor] = None
    if compute_cs or compute_ang or compute_comp_mae or compute_comp_rmse:
        count = _n_voxels(mask, B_pred)

    # --- Accumulate per-metric statistics ---

    if compute_vc or compute_er:
        stats["pred_sq_sum"]   = _spatial_sum(pred_sq,   mask)
        stats["target_sq_sum"] = _spatial_sum(target_sq, mask)
    if compute_vc:
        stats["dot_sum"] = _spatial_sum(dot, mask)

    if compute_cs:
        cos_sim = dot / (pred_norm * targ_norm + eps)
        stats["cs_sum"] = _spatial_sum(cos_sim, mask)

    if compute_en:
        stats["error_norm_sum"] = _spatial_sum(field_norm(diff), mask)
        stats["ref_norm_sum"]   = _spatial_sum(targ_norm,        mask)

    if compute_ang:
        sin_theta = field_norm(cross) / (pred_norm * targ_norm + eps)
        stats["sin_sum"] = _spatial_sum(sin_theta, mask)

    if compute_comp_mae or compute_comp_rmse:
        m_ch    = mask.unsqueeze(1) if mask is not None else None  # (B, 1, D, H, W, T)
        rdims   = [0, 2, 3, 4, 5]
        abs_diff = diff.abs()
        sq_diff  = diff * diff
        if compute_comp_mae:
            stats["comp_abs_sum"] = (
                (abs_diff * m_ch).sum(dim=rdims) if m_ch is not None
                else abs_diff.sum(dim=rdims)
            )
        if compute_comp_rmse:
            stats["comp_sq_sum"] = (
                (sq_diff * m_ch).sum(dim=rdims) if m_ch is not None
                else sq_diff.sum(dim=rdims)
            )

    if count is not None:
        stats["count"] = count

    return stats


# =============================================================================
# Layer 5 — Finalisers: accumulated stats → scalar metric
# =============================================================================

def vector_correlation_from_stats(
    dot_sum: Tensor,
    pred_sq_sum: Tensor,
    target_sq_sum: Tensor,
    eps: float = 1e-8,
) -> Tensor:
    """Compute Cv from accumulated stats.  Range: [-1, 1]."""
    denom = (pred_sq_sum * target_sq_sum).clamp(min=0.0).sqrt() + eps
    return dot_sum / denom


def cauchy_schwarz_from_stats(
    cos_sum: Tensor, count: Tensor, eps: float = 1e-8
) -> Tensor:
    """Compute Cs from accumulated stats.  Range: [-1, 1]."""
    return cos_sum / (count + eps)


def mean_vector_error_from_stats(
    error_norm_sum: Tensor,
    ref_norm_sum: Tensor,
    eps: float = 1e-8,
) -> Tensor:
    """Compute En from accumulated stats.  Range: [0, ∞)."""
    return error_norm_sum / (ref_norm_sum + eps)


def mean_angular_error_from_stats(
    sin_sum: Tensor, count: Tensor, eps: float = 1e-8
) -> Tensor:
    """Compute ⟨sin θ⟩ from accumulated stats.  Range: [0, 1]."""
    return sin_sum / (count + eps)


def energy_ratio_from_stats(
    pred_energy: Tensor,
    target_energy: Tensor,
    eps: float = 1e-8,
) -> Tensor:
    """Compute ε from accumulated stats.  Range: [0, ∞)."""
    return pred_energy / (target_energy + eps)


def component_mae_from_stats(
    abs_sum: Tensor, count: Tensor, eps: float = 1e-8
) -> Tensor:
    """Compute per-component MAE.  Returns shape ``(3,)``."""
    return abs_sum / (count + eps)


def component_rmse_from_stats(
    sq_sum: Tensor, count: Tensor, eps: float = 1e-8
) -> Tensor:
    """Compute per-component RMSE.  Returns shape ``(3,)``."""
    return (sq_sum / (count + eps)).sqrt()


def component_errors_from_stats(
    abs_sum: Tensor,
    sq_sum: Tensor,
    count: Tensor,
    eps: float = 1e-8,
) -> Tuple[Tensor, Tensor]:
    """Compute per-component MAE and RMSE together.

    Returns
    -------
    mae : Tensor, shape ``(3,)``
    rmse : Tensor, shape ``(3,)``
    """
    n = count + eps
    return abs_sum / n, (sq_sum / n).sqrt()


def magnetic_energy_from_stats(energy_sum: Tensor) -> Tensor:
    """Return *energy_sum* unchanged (provided for API uniformity)."""
    return energy_sum


def normalized_divergence_from_stats(
    div_sum: Tensor, count: Tensor, eps: float = 1e-8
) -> Tensor:
    """Compute mean normalised divergence ⟨f⟩ from accumulated stats."""
    return div_sum / (count + eps)


def current_weighted_sine_from_stats(
    cwsin_num: Tensor, cwsin_den: Tensor, eps: float = 1e-8
) -> Tensor:
    """Compute CWsin = Σ(|J|·sin θ) / Σ|J| from accumulated stats."""
    return cwsin_num / (cwsin_den + eps)
