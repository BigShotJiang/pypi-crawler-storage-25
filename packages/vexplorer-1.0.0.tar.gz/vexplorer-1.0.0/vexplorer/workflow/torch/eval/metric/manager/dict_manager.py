

from collections import OrderedDict, defaultdict
from dataclasses import dataclass, field
from typing import Any, Callable, Dict, List, Optional, Union

import torch
from torch import Tensor

from ..base import BaseTorchMetric, BaseTorchManager


@dataclass
class DictMetricWrapper:
    """
    Configuration wrapper for metrics managed by DictManager.

    Controls how each metric receives keyword-based inputs from the manager's
    update(), supports per-key transform, priority ordering, and deferred
    (accumulated) vs. instant update modes.

    Args:
        priority: Computation priority. Lower values are computed first.
            Metrics with the same priority are ordered alphabetically by name.
            Default: 0

        input_map: Dictionary mapping manager update() kwarg keys to metric
            update() kwarg keys. Keys are the names used in manager.update(),
            values are the names used in metric.update().
            Example: {'predictions': 'preds', 'labels': 'target'}
            means manager.update(predictions=..., labels=...) maps to
            metric.update(preds=..., target=...).

        input_transform: Dictionary mapping metric update() kwarg keys to
            callable transform. Each transform is applied to the value
            after key remapping via input_map.
            Keys are the metric-side keys (values of input_map).
            Default: empty dict (no transform).
            Example: {'preds': lambda x: x.sigmoid()} applies sigmoid to
            the value that will be passed as 'preds' to metric.update().

        is_instant_update: Whether to update the metric immediately on each
            manager.update() call.  If True, metric.update() is called
            immediately each step.  If False, inputs are accumulated in the
            manager and the metric is updated once at compute() time (after
            concatenation).  Default: True

    Example:
        >>> # Instant update with input remapping
        >>> wrapper = DictMetricWrapper(
        ...     input_map={'predictions': 'preds', 'labels': 'target'},
        ...     is_instant_update=True,
        ... )
        >>>
        >>> # Deferred update with transform
        >>> wrapper = DictMetricWrapper(
        ...     input_map={'raw_pred': 'preds', 'labels': 'target'},
        ...     input_transform={'preds': lambda x: x.sigmoid()},
        ...     is_instant_update=False,
        ... )
        >>>
        >>> # Two metrics using the same manager key with different transform
        >>> wrapper_a = DictMetricWrapper(
        ...     input_map={'output': 'preds', 'labels': 'target'},
        ...     input_transform={'preds': lambda x: x.argmax(dim=-1)},
        ... )
        >>> wrapper_b = DictMetricWrapper(
        ...     input_map={'output': 'preds', 'labels': 'target'},
        ...     input_transform={'preds': lambda x: x.softmax(dim=-1)},
        ... )

    Notes:
        - input_map keys are the manager-side kwarg names.
        - input_map values are the metric-side kwarg names.
        - input_transform keys must be metric-side names (values of input_map).
        - When is_instant_update=False, the manager accumulates raw values
          (before transform) keyed by manager-side names. At compute() time,
          accumulated values are concatenated, then remapped and transformed
          before a single metric.update() call. This avoids redundant storage
          when multiple metrics share the same manager-side input key.
    """
    priority: int = 0
    input_map: Dict[str, str] = field(default_factory=dict)
    input_transform: Dict[str, Callable] = field(default_factory=dict)
    is_instant_update: bool = True

    def __post_init__(self):
        if self.input_map is None:
            self.input_map = {}
        if self.input_transform is None:
            self.input_transform = {}




class DictMetricManager(BaseTorchManager):
    """
    Dict-based metric manager with key remapping, transform, and deferred updates.

    DictMetricManager provides the most flexible input routing:

    - Each metric declares an input_map to remap manager kwargs to metric kwargs
    - Per-key transform allow different metrics to see different views of the
      same input
    - Deferred (non-instant) metrics accumulate inputs and update once at compute()
    - Priority ordering controls update and compute sequence

    The deferred accumulation is managed at the manager level: raw values are
    collected by their manager-side keys (shared across metrics), then at
    compute() time they are concatenated, remapped, transformed, and forwarded
    to each deferred metric in a single update() call.

    Args:
        detach: Whether to detach tensors before passing to metrics.
            Default: True

        clone: Whether to clone tensors before passing to metrics.
            Default: False

        collect_to_cpu: Whether to move accumulated (deferred) tensors to CPU
            during collection. Useful for saving GPU memory when accumulating
            large amounts of data for deferred metrics.
            Default: False

        **kwargs: Additional keyword arguments passed to BaseTorchManager.__init__().

    Attributes:
        _metrics: OrderedDict mapping metric names to metric instances.
        _wrappers: Dict mapping metric names to DictMetricWrapper instances.
        _collect_to_cpu: Flag for CPU collection of accumulated data.
        _accumulator: Dict mapping manager-side keys to lists of accumulated tensors.
        _accumulator_keys: Set of manager-side keys that need accumulation.

    Example:
        >>> from metrics.regression.mae import MeanAbsoluteError
        >>> from metrics.image.psnr import PeakSignalNoiseRatio
        >>>
        >>> manager = DictManager(detach=True, collect_to_cpu=True)
        >>>
        >>> # MAE: instant update, simple key remapping
        >>> manager.add_metric('mae', MeanAbsoluteError(), DictMetricWrapper(
        ...     input_map={'predictions': 'preds', 'labels': 'target'},
        ...     is_instant_update=True,
        ... ))
        >>>
        >>> # PSNR: deferred update, accumulate all data then compute once
        >>> manager.add_metric('psnr', PeakSignalNoiseRatio(), DictMetricWrapper(
        ...     input_map={'predictions': 'preds', 'labels': 'target'},
        ...     is_instant_update=False,
        ... ))
        >>>
        >>> for batch in loader:
        ...     manager.update(predictions=preds, labels=target)
        >>> results = manager.compute()  # PSNR updated here with all data

    Notes:
        - manager.update() only accepts keyword arguments (no positional args).
        - Deferred metrics share accumulated storage by manager-side key to
          avoid redundant memory usage.
        - At compute(), deferred data is concatenated along dim=0, then each
          deferred metric receives its remapped and transformed inputs.
        - After compute(), the accumulator is NOT automatically cleared.
          Call reset() to clear both metrics and the accumulator.
    """

    def __init__(
        self,
        detach: bool = True,
        clone: bool = False,
        collect_to_cpu: bool = False,
        **kwargs,
    ):
        """Initialize DictManager."""
        super().__init__(detach=detach, clone=clone, **kwargs)
        self._metrics: OrderedDict[str, BaseTorchMetric] = OrderedDict()
        self._wrappers: Dict[str, DictMetricWrapper] = {}
        self._collect_to_cpu = collect_to_cpu
        self._accumulator: Dict[str, List[Tensor]] = defaultdict(list)
        self._accumulator_keys: set = set()
        self._sorted_names: List[str] = []

    def _rebuild_sorted_names(self) -> None:
        """
        Rebuild the priority-sorted list of metric names.

        Sorting rules:
        1. Primary: ascending by wrapper.priority
        2. Secondary: ascending by name (alphabetical)
        """
        self._sorted_names = sorted(
            self._metrics.keys(),
            key=lambda name: (self._wrappers[name].priority, name),
        )

    def _rebuild_accumulator_keys(self) -> None:
        """
        Rebuild the set of manager-side keys that need accumulation.

        Scans all deferred metrics' input_maps to determine which
        manager-side kwargs should be accumulated.
        """
        self._accumulator_keys = set()
        for name, wrapper in self._wrappers.items():
            if not wrapper.is_instant_update:
                for manager_key in wrapper.input_map.keys():
                    self._accumulator_keys.add(manager_key)

    def add_metric(
        self,
        name: str,
        metric: BaseTorchMetric,
        wrapper: Optional[DictMetricWrapper] = None,
        build=False
    ) -> None:
        """
        Add a metric with a DictMetricWrapper configuration.

        Args:
            name: Unique name identifier for the metric.
            metric: A BaseTorchMetric instance to manage.
            wrapper: DictMetricWrapper configuring input mapping, transform,
                priority, and update mode. If None, a default DictMetricWrapper()
                is used (instant update, empty input_map, no transform).

        Raises:
            ValueError: If name is already registered.
            TypeError: If wrapper is not a DictMetricWrapper instance.

        Example:
            >>> manager.add_metric('mae', MeanAbsoluteError(), DictMetricWrapper(
            ...     input_map={'predictions': 'preds', 'labels': 'target'},
            ... ))
        """
        if name in self._metrics:
            raise ValueError(
                f"Metric with name '{name}' already exists in the manager."
            )
        if wrapper is None:
            wrapper = DictMetricWrapper()
        if not isinstance(wrapper, DictMetricWrapper):
            raise TypeError(
                f"wrapper must be a DictMetricWrapper instance, "
                f"got {type(wrapper).__name__}."
            )

        self._metrics[name] = metric
        self._wrappers[name] = wrapper
        if build:
            self.build()


    def build(self) -> None:
        self._rebuild_sorted_names()
        self._rebuild_accumulator_keys()

    def _remap_and_transform(
        self,
        wrapper: DictMetricWrapper,
        source_kwargs: dict,
    ) -> dict:
        """
        Apply input_map remapping and input_transform to source kwargs.

        Steps:
        1. For each (manager_key -> metric_key) in input_map, extract the
           value from source_kwargs using manager_key.
        2. If metric_key has an entry in input_transform, apply the transform.
        3. Return a new dict with metric-side keys and (possibly transformed) values.

        Args:
            wrapper: The DictMetricWrapper with input_map and input_transform.
            source_kwargs: The source keyword arguments (from update or accumulator).

        Returns:
            Dict with metric-side keys ready for metric.update(**result).
        """
        metric_kwargs = {}
        for manager_key, metric_key in wrapper.input_map.items():
            if manager_key not in source_kwargs:
                raise KeyError(
                    f"Manager-side key '{manager_key}' not found in update() kwargs. "
                    f"Available keys: {list(source_kwargs.keys())}"
                )
            value = source_kwargs[manager_key]

            # Apply transform if defined for this metric-side key
            if metric_key in wrapper.input_transform:
                value = wrapper.input_transform[metric_key](value)

            metric_kwargs[metric_key] = value

        return metric_kwargs

    def update(self, **kwargs) -> None:
        """
        Update instant metrics and accumulate inputs for deferred metrics.

        For instant metrics (is_instant_update=True):
            - Input is remapped via input_map, transformed via input_transform,
              and immediately passed to metric.update().

        For deferred metrics (is_instant_update=False):
            - Raw values for required manager-side keys are accumulated in the
              manager's internal accumulator (shared across metrics by key).
            - The actual metric.update() is deferred to compute() time.

        Args:
            **kwargs: Keyword arguments. Keys are manager-side names as
                declared in each metric's DictMetricWrapper.input_map.

        Example:
            >>> manager.update(predictions=preds, labels=target)

        Notes:
            - Only keyword arguments are accepted (no positional args).
            - detach/clone transformations are applied before any processing.
            - Accumulated values are optionally moved to CPU if collect_to_cpu=True.
        """
        kwargs = self._prepare_kwargs(kwargs)

        # Accumulate raw values for deferred metrics (shared by manager-side key)
        for manager_key in self._accumulator_keys:
            if manager_key in kwargs:
                value = kwargs[manager_key]
                if self._collect_to_cpu and isinstance(value, Tensor):
                    value = value.cpu()
                self._accumulator[manager_key].append(value)

        # Update instant metrics in priority order
        for name in self._sorted_names:
            wrapper = self._wrappers[name]
            if wrapper.is_instant_update:
                metric_kwargs = self._remap_and_transform(wrapper, kwargs)
                self._metrics[name].update(**metric_kwargs)

    def _concatenate_accumulator(self) -> Dict[str, Tensor]:
        """
        Concatenate all accumulated values by manager-side key.

        Returns:
            Dict mapping manager-side keys to concatenated tensors (dim=0).

        Notes:
            - Only processes keys that have accumulated data.
            - Non-tensor values are returned as-is (last value).
        """
        concatenated = {}
        for key, value_list in self._accumulator.items():
            if len(value_list) == 0:
                continue
            if all(isinstance(v, Tensor) for v in value_list):
                concatenated[key] = torch.cat(value_list, dim=0)
            else:
                # Fallback: use the list as-is (non-tensor accumulation)
                concatenated[key] = value_list
        return concatenated

    def compute(self) -> Dict[str, Any]:
        """
        Compute all metrics in priority order.

        For deferred metrics:
        1. Concatenate accumulated data by manager-side key
        2. For each deferred metric, remap and transform the concatenated data
        3. Call metric.update() once with the full accumulated data
        Then compute all metrics in priority order.

        Returns:
            Dict[str, Any]: {metric_name: metric_result} ordered by priority.

        Example:
            >>> results = manager.compute()
            >>> # {'mae': tensor(0.5), 'psnr': tensor(28.3)}
        """
        # Step 1: Process deferred metrics - concatenate and update
        concatenated = self._concatenate_accumulator()

        if concatenated:
            for name in self._sorted_names:
                wrapper = self._wrappers[name]
                if not wrapper.is_instant_update:
                    metric_kwargs = self._remap_and_transform(
                        wrapper, concatenated
                    )
                    self._metrics[name].update(**metric_kwargs)

        # Step 2: Compute all metrics in priority order
        results = {}
        for name in self._sorted_names:
            results[name] = self._metrics[name].compute()
        return results

    # def to(self, device: Union[str, torch.device]) -> 'DictMetricManager':
    #     """
    #     Move all metrics to the specified device.
    #
    #     Args:
    #         device: Target device ('cpu', 'cuda', 'cuda:0', etc.).
    #
    #     Returns:
    #         Self for method chaining.
    #     """
    #     if isinstance(device, str):
    #         device = torch.device(device)
    #
    #     for metric in self._metrics.values():
    #         metric.to(device)
    #
    #     super().to(device)
    #     return self

    def to(self, device: Union[str, torch.device]) -> 'DictMetricManager':
        """
        Move all metrics and supported input transforms to the specified device.

        Args:
            device: Target device ('cpu', 'cuda', 'cuda:0', etc.).

        Returns:
            Self for method chaining.
        """
        if isinstance(device, str):
            device = torch.device(device)

        # 1. 移动所有的 Metric
        for metric in self._metrics.values():
            metric.to(device)

        # 2. 遍历所有的 Wrapper，如果 transform 支持 .to() 方法（比如 nn.Module），也将其移动
        for wrapper in self._wrappers.values():
            for transform_func in wrapper.input_transform.values():
                # 判断该 Callable 是否有 to 方法 (排除了普通的 lambda 表达式或普通 Python 函数)
                if hasattr(transform_func, 'to') and callable(transform_func.to):
                    transform_func.to(device)

        # 3. 调用父类的 to 方法
        super().to(device)
        return self

    def reset(self) -> None:
        """
        Reset all managed metrics and clear the accumulator.

        This prepares the manager for the next epoch by:
        1. Resetting every managed metric's internal state.
        2. Clearing all accumulated data for deferred metrics.
        """
        for metric in self._metrics.values():
            metric.reset()

        # Clear accumulated data
        self._accumulator.clear()

    def del_metric(self, name: str) -> None:
        """
        Remove a metric from the manager by name.

        Also removes its wrapper and rebuilds internal indices.

        Args:
            name: Name of the metric to remove.

        Raises:
            KeyError: If the name is not found.
        """
        if name not in self._metrics:
            raise KeyError(
                f"Metric '{name}' not found in the manager. "
                f"Available metrics: {list(self._metrics.keys())}"
            )
        del self._metrics[name]
        del self._wrappers[name]
        self._rebuild_sorted_names()
        self._rebuild_accumulator_keys()

# Backward compatibility alias
DictManager = DictMetricManager
