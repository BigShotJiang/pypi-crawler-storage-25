

from collections import OrderedDict
from dataclasses import dataclass, field
from typing import Any, Callable, Dict, List, Optional, Sequence, Tuple, Union

import torch

from ..base import BaseTorchMetric, BaseTorchManager


@dataclass
class ListMetricWrapper:
    """
    Configuration wrapper for metrics managed by ListMetricManager.

    Controls how each metric receives inputs from the manager's update()
    and in what priority order metrics are computed.

    Args:
        priority: Computation priority. Lower values are computed first.
            Metrics with the same priority are ordered alphabetically by name.
            Default: 0

        input_need: Specifies which inputs from the manager's update() call
            should be forwarded to this metric. Each element selects one
            argument from the manager's update():
            - int: Index into ``*args`` (positional arguments)
            - str: Key from ``**kwargs`` (keyword arguments)
            The selected values are collected into a list and unpacked as
            positional arguments to metric.update().
            Default: (0, 1)

        extracted_transform: Dict[int, Callable]
            Dictionary mapping extracted value indices to callable transform.
            Transforms are applied to extracted values before passing to the metric.
            Keys are the indices in the extracted list (after input_need extraction).
            Default: empty dict (no transform).
            Example: {0: lambda x: torch.sigmoid(x)} applies sigmoid to the
            first extracted value.

    Example:
        >>> # Default: pass args[0] and args[1] to metric
        >>> wrapper = ListMetricWrapper()
        >>>
        >>> # Custom: pass args[2] and kwargs['weight']
        >>> wrapper = ListMetricWrapper(priority=1, input_need=(2, 'weight'))
        >>>
        >>> # High priority, use first arg and 'target' kwarg
        >>> wrapper = ListMetricWrapper(priority=-1, input_need=(0, 'target'))
        >>>
        >>> # With transform on extracted values
        >>> wrapper = ListMetricWrapper(
        ...     input_need=(0, 'target'),
        ...     extracted_transform={0: lambda x: torch.sigmoid(x)}
        ... )
        >>> # Extracts args[0] and kwargs['target'], applies sigmoid to first,
        >>> # then calls metric.update(sigmoid(args[0]), kwargs['target'])

    Notes:
        - input_need elements are extracted in order from the manager's
          update(``*args``, ``**kwargs``).
        - int indices select from args, str keys select from kwargs.
        - extracted_transform is applied to the extracted values list.
        - The transformed values are unpacked as positional args to metric.update().
    """
    priority: int = 0
    input_need: Sequence[Union[int, str]] = (0, 1)
    extracted_transform: Dict[int, Callable] = field(default_factory=dict)

    def __post_init__(self):
        if self.extracted_transform is None:
            self.extracted_transform = {}


class ListMetricManager(BaseTorchManager):
    """
    List-based metric manager with priority ordering, flexible input routing, and transform.

    ListMetricManager allows each metric to specify:

    - A priority level controlling update and compute order
    - An input_need list that selects which arguments from update() are
      forwarded to each individual metric
    - Transforms to apply to extracted values before passing to metrics

    Args:
        detach: Whether to detach tensors before passing to metrics.
            Default: True

        clone: Whether to clone tensors before passing to metrics.
            Default: False

        **kwargs: Additional keyword arguments passed to BaseTorchManager.__init__().

    Attributes:
        _metrics: OrderedDict mapping metric names to metric instances.
        _wrappers: Dict mapping metric names to ListMetricWrapper instances.

    Example:
        >>> from metrics.regression.mae import MeanAbsoluteError
        >>> from metrics.regression.mse import MeanSquaredError
        >>>
        >>> manager = ListMetricManager(detach=True)
        >>>
        >>> # MAE uses default wrapper: priority=0, input_need=(0, 1)
        >>> manager.add_metric('mae', MeanAbsoluteError())
        >>>
        >>> # MSE with lower priority and custom input selection
        >>> wrapper = ListMetricWrapper(priority=1, input_need=(0, 1))
        >>> manager.add_metric('mse', MeanSquaredError(), wrapper=wrapper)
        >>>
        >>> # Metric with transform
        >>> wrapper_sigmoid = ListMetricWrapper(
        ...     input_need=(0, 1),
        ...     extracted_transform={0: lambda x: torch.sigmoid(x)}
        ... )
        >>> manager.add_metric('mae_sigmoid', MeanAbsoluteError(), wrapper=wrapper_sigmoid)
        >>>
        >>> manager.update(preds, target)
        >>> results = manager.compute()
        >>> # {'mae': tensor(...), 'mse': tensor(...), 'mae_sigmoid': tensor(...)}

    Notes:
        - Metrics are updated and computed in priority order (ascending).
        - Within the same priority, metrics are ordered by name (alphabetical).
        - If no wrapper is provided, a default ListMetricWrapper() is used.
        - extracted_transform applies transform to the extracted values.
    """

    def __init__(
        self,
        detach: bool = True,
        clone: bool = False,
        **kwargs,
    ):
        """Initialize ListMetricManager."""
        super().__init__(detach=detach, clone=clone, **kwargs)
        self._metrics: OrderedDict[str, BaseTorchMetric] = OrderedDict()
        self._wrappers: Dict[str, ListMetricWrapper] = {}
        self._sorted_names: List[str] = []

    def _rebuild_sorted_names(self) -> None:
        """
        Rebuild the priority-sorted list of metric names.

        Sorting rules:
        1. Primary: ascending by wrapper.priority (lower = higher priority)
        2. Secondary: ascending by name (alphabetical)
        """
        self._sorted_names = sorted(
            self._metrics.keys(),
            key=lambda name: (self._wrappers[name].priority, name),
        )

    def add_metric(
        self,
        name: str,
        metric: BaseTorchMetric,
        wrapper: Optional[ListMetricWrapper] = None,
        build = False,
    ) -> None:
        """
        Add a metric with an optional ListMetricWrapper configuration.

        Args:
            name: Unique name identifier for the metric.
            metric: A BaseTorchMetric instance to manage.
            wrapper: Optional ListMetricWrapper configuring priority, input
                routing, and transform. If None, a default ListMetricWrapper() is used.

        Raises:
            ValueError: If name is already registered.
            TypeError: If wrapper is not a ListMetricWrapper instance.

        Example:
            >>> manager.add_metric('mae', MeanAbsoluteError())
            >>> manager.add_metric(
            ...     'mse',
            ...     MeanSquaredError(),
            ...     wrapper=ListMetricWrapper(priority=1, input_need=(0, 1)),
            ... )
        """
        if name in self._metrics:
            raise ValueError(
                f"Metric with name '{name}' already exists in the manager."
            )
        if wrapper is None:
            wrapper = ListMetricWrapper()
        if not isinstance(wrapper, ListMetricWrapper):
            raise TypeError(
                f"wrapper must be a ListMetricWrapper instance, "
                f"got {type(wrapper).__name__}."
            )

        self._metrics[name] = metric
        self._wrappers[name] = wrapper
        if build:
            self.build()

    def build(self):
        self._rebuild_sorted_names()

    def _extract_inputs(
        self,
        input_need: Sequence[Union[int, str]],
        args: tuple,
        kwargs: dict,
    ) -> list:
        """
        Extract inputs from args/kwargs according to input_need specification.

        Args:
            input_need: Sequence of int (index into args) or str (key in kwargs).
            args: Positional arguments from manager.update().
            kwargs: Keyword arguments from manager.update().

        Returns:
            List of extracted values in the order specified by input_need.

        Raises:
            IndexError: If an int index is out of range for args.
            KeyError: If a str key is not found in kwargs.

        Example:
            >>> # input_need=(0, 'target') with args=(preds,), kwargs={'target': t}
            >>> extracted = manager._extract_inputs((0, 'target'), (preds,), {'target': t})
            >>> # extracted = [preds, t]
        """
        extracted = []
        for need in input_need:
            if isinstance(need, int):
                if need >= len(args):
                    raise IndexError(
                        f"input_need index {need} is out of range. "
                        f"update() received {len(args)} positional arguments."
                    )
                extracted.append(args[need])
            elif isinstance(need, str):
                if need not in kwargs:
                    raise KeyError(
                        f"input_need key '{need}' not found in update() kwargs. "
                        f"Available keys: {list(kwargs.keys())}"
                    )
                extracted.append(kwargs[need])
            else:
                raise TypeError(
                    f"input_need elements must be int or str, "
                    f"got {type(need).__name__}: {need!r}"
                )
        return extracted

    def update(self, *args, **kwargs) -> None:
        """
        Update all metrics in priority order with extracted inputs.

        For each metric (in priority order):
        1. Extract inputs according to its wrapper's input_need
        2. Apply transform from extracted_transform
        3. Unpack transformed values as positional arguments to metric.update()

        Args:
            *args: Positional arguments. Elements are selected by int indices
                in input_need.
            **kwargs: Keyword arguments. Elements are selected by str keys
                in input_need.

        Example:
            >>> # With input_need=(0, 1): metric.update(args[0], args[1])
            >>> # With input_need=(0, 'target'): metric.update(args[0], kwargs['target'])
            >>> # With extracted_transform={0: sigmoid}: metric.update(sigmoid(args[0]), args[1])
            >>> manager.update(preds, target)
        """
        args = self._prepare_args(args)
        kwargs = self._prepare_kwargs(kwargs)

        for name in self._sorted_names:
            metric = self._metrics[name]
            wrapper = self._wrappers[name]
            extracted = self._extract_inputs(wrapper.input_need, args, kwargs)

            # Apply transform to extracted values
            if wrapper.extracted_transform:
                extracted = [
                    wrapper.extracted_transform.get(i, lambda x: x)(value)
                    for i, value in enumerate(extracted)
                ]

            metric.update(*extracted)

    # def to(self, device: Union[str, torch.device]) -> 'ListMetricManager':
    #     """
    #     Move all metrics to the specified device.
    #
    #     Args:
    #         device: Target device ('cpu', 'cuda', 'cuda:0', etc.).
    #
    #     Returns:
    #         Self for method chaining.
    #     """
    #     if isinstance(device, str):
    #         device = torch.device(device)
    #
    #     for metric in self._metrics.values():
    #         metric.to(device)
    #
    #     super().to(device)
    #     return self

    def to(self, device: Union[str, torch.device]) -> 'ListMetricManager':
        """
        Move all metrics and supported transforms to the specified device.

        Args:
            device: Target device ('cpu', 'cuda', 'cuda:0', etc.).

        Returns:
            Self for method chaining.
        """
        if isinstance(device, str):
            device = torch.device(device)

        # 1. 移动所有的 Metric
        for metric in self._metrics.values():
            metric.to(device)

        # 2. 遍历所有的 Wrapper，处理 extracted_transform 中的 PyTorch 模块
        for wrapper in self._wrappers.values():
            if wrapper is not None and wrapper.extracted_transform:
                for transform_func in wrapper.extracted_transform.values():
                    # 检查是否为 PyTorch 的 Module 或有 to 方法的张量类对象
                    if hasattr(transform_func, 'to') and callable(transform_func.to):
                        transform_func.to(device)

        # 3. 调用父类的 to 方法
        super().to(device)
        return self

    def compute(self) -> Dict[str, Any]:
        """
        Compute all metrics in priority order and return results.

        Returns:
            Dict[str, Any]: {metric_name: metric_result} ordered by priority.

        Example:
            >>> results = manager.compute()
            >>> # {'mae': tensor(0.5), 'mse': tensor(0.25)}
        """
        results = {}
        for name in self._sorted_names:
            results[name] = self._metrics[name].compute()
        return results

    def reset(self) -> None:
        """
        Reset all managed metrics to prepare for the next epoch.
        """
        for metric in self._metrics.values():
            metric.reset()

    def del_metric(self, name: str) -> None:
        """
        Remove a metric from the manager by name.

        Args:
            name: Name of the metric to remove.

        Raises:
            KeyError: If the name is not found.
        """
        if name not in self._metrics:
            raise KeyError(
                f"Metric '{name}' not found in the manager. "
                f"Available metrics: {list(self._metrics.keys())}"
            )
        del self._metrics[name]
        del self._wrappers[name]
        self._rebuild_sorted_names()


# Backward compatibility alias
ListManager = ListMetricManager
