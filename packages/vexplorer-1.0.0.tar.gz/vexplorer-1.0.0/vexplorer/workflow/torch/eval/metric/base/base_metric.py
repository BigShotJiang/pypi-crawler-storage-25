from abc import ABC, abstractmethod
from typing import Any, Dict, List, Optional, Union
import torch
from torch import Tensor
import torch.nn as nn

from ..utils.enums import DistributedReduceOp, DeviceType
from ..utils.distributed import distributed_reduce, is_distributed


class BaseTorchMetric(nn.Module, ABC):
    """
    Base class for all TorchMetrics with comprehensive features.
    
    This class provides the foundation for creating custom metrics with:
    - Automatic device management (CPU/CUDA/NPU/TPU/MPS/Auto)
    - Distributed training support (all reduce ops: SUM/MEAN/MAX/MIN/PROD/CAT)
    - State variable management with automatic reduction
    - Decorator-based automatic super() and _apply_reduction() calls
    - Reset functionality for new epochs
    
    Args:
        device: Compute device for metric
            Options: 'cpu', 'cuda', 'cuda:0', 'npu', 'tpu', 'mps', 'auto'
            'auto' selects best available: CUDA > MPS > CPU
            Default: 'auto'

        auto_reduction: Enable automatic _apply_reduction() calls via @auto_compute
            When True, @auto_compute decorator calls _apply_reduction() automatically
            When False, must call _apply_reduction() manually
            Default: True
            
        dist_sync_on_step: Synchronize states across processes on each update()
            When True, applies distributed reduction after every update()
            When False, only reduces on compute() (more efficient)
            Default: False (recommended)
            
        process_group: Process group for distributed training
            None uses default process group
            Set to specific group for custom distributed setups
            Default: None
    
    Attributes:
        device: Current device for metric computation
        _auto_reduction: Flag for automatic _apply_reduction() calls
        _state_vars: Dict of state variables with reduce operations
        _update_count: Number of times update() has been called
        _computed: Whether _apply_reduction() has been called
    
    Example - Basic Usage:
        >>> from metrics.base import BaseTorchMetric, auto_update, auto_compute
        >>> from metrics.base import DistributedReduceOp
        >>> 
        >>> class MyAccuracy(BaseTorchMetric):
        ...     def __init__(self, device='auto', **kwargs):
        ...         super().__init__(device=device, **kwargs)
        ...         
        ...         # Add state variables with reduce operations
        ...         self.add_state('correct', torch.tensor(0), DistributedReduceOp.SUM)
        ...         self.add_state('total', torch.tensor(0), DistributedReduceOp.SUM)
        ...     
        ...     @auto_update  # Automatically calls super().update()
        ...     def update(self, preds, target):
        ...         self.correct += (preds == target).sum()
        ...         self.total += target.numel()
        ...     
        ...     @auto_compute  # Automatically calls _apply_reduction()
        ...     def compute(self):
        ...         # Access scalar value safely
        ...         total_val = tensor_to_python_scalar(self.total)
        ...         if total_val == 0:
        ...             return torch.tensor(0.0, device=self.device)
        ...         return self.correct.float() / self.total
        >>> 
        >>> # Usage
        >>> metric = MyAccuracy(device='cuda')
        >>> metric.update(preds, targets)
        >>> accuracy = metric.compute()
    
    Example - Device Management:
        >>> # Auto-detect best device
        >>> metric = MyMetric(device='auto')
        >>> 
        >>> # Explicit device
        >>> metric = MyMetric(device='cuda:1')
        >>> metric = MyMetric(device='npu')
        >>> 
        >>> # Move after creation
        >>> metric.to('cuda')
        >>> metric.cpu()
    
    Example - Distributed Training:
        >>> # Different reduce operations for different states
        >>> self.add_state('sum', torch.tensor(0.0), DistributedReduceOp.SUM)
        >>> self.add_state('max', torch.tensor(0.0), DistributedReduceOp.MAX)
        >>> self.add_state('preds', [], DistributedReduceOp.CAT)
    
    Notes:
        - All state variables are automatically moved to metric's device
        - Distributed reduction only happens once (cached until reset)
        - Use @auto_update and @auto_compute decorators for cleaner code
        - Override update() and compute() in subclasses
        - Call reset() between epochs to clear accumulated state
    """
    
    def __init__(
        self,
        device: Union[str, torch.device, DeviceType] = DeviceType.AUTO,
        auto_reduction: bool = True,
        dist_sync_on_step: bool = False,
        process_group: Optional[Any] = None,
    ):
        """Initialize base metric with device and configuration."""
        super().__init__()

        # Device management
        self.device = self._resolve_device(device)

        # Decorator control flag (used by @auto_compute)
        self._auto_reduction = auto_reduction
        
        # Distributed training configuration
        self.dist_sync_on_step = dist_sync_on_step
        self.process_group = process_group
        
        # State management
        self._state_vars: Dict[str, Dict[str, Any]] = {}
        self._update_count = 0
        self._computed = False
    
    def _resolve_device(
        self,
        device: Union[str, torch.device, DeviceType]
    ) -> torch.device:
        """
        Resolve device specification to torch.device.
        
        Handles string, enum, and torch.device inputs.
        Auto-detection logic: CUDA > MPS > CPU
        
        Args:
            device: Device specification
        
        Returns:
            Resolved torch.device object
        
        Example:
            >>> metric._resolve_device('auto')
            device(type='cuda', index=0)  # If CUDA available
            
            >>> metric._resolve_device('npu')
            device(type='npu')
        """
        # Already a torch.device
        if isinstance(device, torch.device):
            return device
        
        # Convert enum to string
        if isinstance(device, DeviceType):
            device = device.value
        
        # Auto-detection logic
        if device == 'auto':
            # Priority 1: CUDA (NVIDIA GPU)
            if torch.cuda.is_available():
                is_distributed = torch.distributed.is_initialized()
                # 获取当前进程对应的 GPU ID
                local_rank = torch.distributed.get_rank() if is_distributed else 0
                device = torch.device(f"cuda:{local_rank}")
                return device
                # return torch.device('cuda')
            
            # Priority 2: NPU (Huawei GPU)
            if hasattr(torch, 'npu') and torch.npu.is_available():
                is_distributed = torch.distributed.is_initialized()
                local_rank = torch.distributed.get_rank() if is_distributed else 0
                device = torch.device(f"npu:{local_rank}")
                return device
            
            # Priority 3: MPS (Apple Silicon)
            if hasattr(torch.backends, 'mps') and torch.backends.mps.is_available():
                return torch.device('mps')
            
            # Fallback: CPU
            # Note: NPU and TPU require explicit specification and
            # platform-specific PyTorch builds
            return torch.device('cpu')

        #     TODO
        
        # Direct device specification
        return torch.device(device)
    
    def to(self, device: Union[str, torch.device]) -> 'BaseTorchMetric':
        """
        Move metric and all state variables to specified device.
        
        This method:
        1. Updates self.device
        2. Moves all state variable tensors to new device
        3. Calls nn.Module.to() for any registered parameters
        
        Args:
            device: Target device ('cpu', 'cuda', 'cuda:1', etc.)
        
        Returns:
            Self for method chaining
        
        Example:
            >>> metric = MyMetric(device='cpu')
            >>> metric.to('cuda')  # Move to GPU
            >>> metric.to('cuda:1')  # Move to second GPU
            >>> metric.to(torch.device('npu'))  # Move to NPU
        
        Notes:
            - All state tensors are moved automatically
            - Lists of tensors are moved element-wise
            - Non-tensor values are unchanged
            - Can be chained with other methods
        """
        # Convert string to torch.device
        if isinstance(device, str):
            device = torch.device(device)
        
        # Update device
        self.device = device
        
        # Move all state variables to new device
        # IMPORTANT: Read from attribute (getattr) not state_dict, because
        # tensor states may have been reassigned and broken the reference.
        for name, state_dict in self._state_vars.items():
            value = getattr(self, name)

            if isinstance(value, Tensor):
                # Single tensor - move directly
                new_val = value.to(device)
                state_dict['value'] = new_val
                setattr(self, name, new_val)

            elif isinstance(value, list):
                # List of tensors - move each tensor
                new_list = [
                    v.to(device) if isinstance(v, Tensor) else v
                    for v in value
                ]
                state_dict['value'] = new_list
                setattr(self, name, new_list)
        
        # Call parent to() for nn.Module parameters (if any)
        super().to(device)
        
        return self
    
    def cuda(self, device: Optional[int] = None) -> 'BaseTorchMetric':
        """
        Move metric to CUDA device (GPU).
        
        Convenience method equivalent to .to('cuda') or .to(f'cuda:{device}')
        
        Args:
            device: GPU index (0, 1, 2, ...) or None for default GPU
        
        Returns:
            Self for method chaining
        
        Example:
            >>> metric.cuda()      # Move to default GPU (cuda:0)
            >>> metric.cuda(1)     # Move to second GPU (cuda:1)
        """
        if device is None:
            return self.to('cuda')
        return self.to(f'cuda:{device}')
    
    def cpu(self) -> 'BaseTorchMetric':
        """
        Move metric to CPU.
        
        Convenience method equivalent to .to('cpu')
        
        Returns:
            Self for method chaining
        
        Example:
            >>> metric.cpu()  # Move to CPU
        """
        return self.to('cpu')
    
    def add_state(
        self,
        name: str,
        default: Union[Tensor, List],
        dist_reduce_fx: Union[DistributedReduceOp, str] = DistributedReduceOp.SUM,
    ) -> None:
        """
        Register a state variable for the metric.
        
        State variables are:
        - Automatically moved to metric's device
        - Reduced across processes in distributed training
        - Reset when reset() is called
        - Accessible as instance attributes (self.{name})
        
        Args:
            name: Name of state variable
                Will be accessible as self.{name}
                Should be descriptive (e.g., 'total_correct', 'predictions')
                
            default: Initial value
                Tensor: Single accumulator (e.g., torch.tensor(0.0))
                List: Collection of tensors (e.g., [] for predictions)
                
            dist_reduce_fx: Reduction operation for distributed training
                SUM: Sum values across all processes (default)
                MEAN: Average values
                MAX: Maximum value
                MIN: Minimum value
                PROD: Product of values
                CAT: Concatenate tensors
        
        Example:
            >>> # Accumulator for summation
            >>> self.add_state('total', torch.tensor(0.0), DistributedReduceOp.SUM)
            >>> 
            >>> # Track maximum score
            >>> self.add_state('max_score', torch.tensor(0.0), DistributedReduceOp.MAX)
            >>> 
            >>> # Collect all predictions
            >>> self.add_state('preds', [], DistributedReduceOp.CAT)
            >>> 
            >>> # Usage in update()
            >>> self.total += batch_size
            >>> self.max_score = torch.maximum(self.max_score, score)
            >>> self.preds.append(batch_preds)
        
        Notes:
            - State variables persist across update() calls
            - Cleared only by reset()
            - Automatically participate in distributed reduction
            - Default tensors are moved to metric's device
        """
        # Convert string to enum
        if isinstance(dist_reduce_fx, str):
            dist_reduce_fx = DistributedReduceOp(dist_reduce_fx)
        
        # Move default value to device
        if isinstance(default, Tensor):
            default = default.to(self.device)
        elif isinstance(default, list):
            default = [
                t.to(self.device) if isinstance(t, Tensor) else t
                for t in default
            ]
        
        # Store state variable metadata
        self._state_vars[name] = {
            'value': default,
            'reduce_fx': dist_reduce_fx,
        }
        
        # Set as instance attribute for easy access
        setattr(self, name, default)
    
    def update(self, *args, **kwargs) -> None:
        """
        Update metric state. Should be overridden by subclasses.

        Subclasses should add @auto_update decorator:

        Example:
            >>> @auto_update
            >>> def update(self, preds, target):
            ...     self.correct += (preds == target).sum()
            ...     self.total += target.numel()

        Notes:
            - @auto_update decorator tracks update count automatically
            - Override this in subclasses with actual update logic
        """
        pass
    
    @abstractmethod
    def compute(self) -> Union[Tensor, Dict[str, Tensor]]:
        """
        Compute final metric value from accumulated state.
        
        This method must be implemented by subclasses.
        Should add @auto_compute decorator for automatic reduction.
        
        Returns:
            Tensor: Single metric value
            Dict[str, Tensor]: Multiple metric values
        
        Example:
            >>> @auto_compute
            >>> def compute(self):
            ...     # self._apply_reduction() called automatically
            ...     
            ...     # Safe scalar access
            ...     total_val = tensor_to_python_scalar(self.total)
            ...     if total_val == 0:
            ...         return torch.tensor(0.0, device=self.device)
            ...     
            ...     return self.correct.float() / self.total
        
        Notes:
            - Do NOT call self._apply_reduction() manually if using @auto_compute
            - Use tensor_to_python_scalar() for safe tensor comparisons
            - Return torch.tensor on same device as metric
            - Handle edge cases (empty data, zero denominators, etc.)
        """
        pass
    
    def _apply_reduction(self) -> None:
        """
        Apply distributed reduction to all state variables.
        
        This method:
        1. Checks if already computed (idempotent)
        2. Reduces each state variable according to its reduce_fx
        3. Updates instance attributes with reduced values
        4. Marks as computed to prevent redundant reduction
        
        Called automatically by @auto_compute decorator or manually
        if auto_reduction=False.
        
        Examples:
            >>> # Automatic (recommended)
            >>> @auto_compute
            >>> def compute(self):
            ...     # _apply_reduction() called automatically
            ...     return self.total / self.count
            >>> 
            >>> # Manual (if auto_reduction=False)
            >>> def compute(self):
            ...     self._apply_reduction()  # Explicit call
            ...     return self.total / self.count
        
        Notes:
            - Only reduces once per compute cycle
            - Resets on next update()
            - No-op in single-process training
            - Handles both tensor and list states
        """
        # Skip if not distributed or already computed
        if not is_distributed() or self._computed:
            return

        # Reduce each state variable
        for name, state_dict in self._state_vars.items():
            # IMPORTANT: Read the CURRENT attribute value, not state_dict['value'].
            # Tensor states may have been reassigned (e.g. self.x = torch.max(self.x, y))
            # which creates a new tensor object and breaks the reference in state_dict.
            value = getattr(self, name)
            reduce_fx = state_dict['reduce_fx']
            
            if isinstance(value, Tensor):
                # Single tensor - reduce directly
                reduced = distributed_reduce(value, reduce_fx, self.process_group)
                state_dict['value'] = reduced
                setattr(self, name, reduced)
            
            elif isinstance(value, list) and len(value) > 0:
                # List of tensors
                if reduce_fx == DistributedReduceOp.CAT:
                    # Concatenate all tensors in list, then gather across processes
                    if all(isinstance(t, Tensor) for t in value):
                        # Handle 0-d scalar tensors (e.g. per-sample PSNR/MAE values)
                        # by unsqueezing to 1-d before cat; already >=1-d tensors pass through
                        value_to_cat = [
                            t.unsqueeze(0) if t.dim() == 0 else t for t in value
                        ]
                        concatenated = torch.cat(value_to_cat, dim=0)
                        reduced = distributed_reduce(
                            concatenated, reduce_fx, self.process_group
                        )
                        state_dict['value'] = [reduced]
                        setattr(self, name, [reduced])
                else:
                    # Reduce each tensor in list
                    reduced_list = []
                    for item in value:
                        if isinstance(item, Tensor):
                            reduced_item = distributed_reduce(
                                item, reduce_fx, self.process_group
                            )
                            reduced_list.append(reduced_item)
                        else:
                            reduced_list.append(item)
                    
                    state_dict['value'] = reduced_list
                    setattr(self, name, reduced_list)
        
        # Mark as computed to prevent redundant reduction
        self._computed = True
    
    def reset(self) -> None:
        """
        Reset all state variables to their default values.
        
        This should be called:
        - Between training epochs
        - Before validation/testing
        - Whenever starting fresh accumulation
        
        Resets:
        - All state variable values
        - Update counter
        - Computed flag
        
        Example:
            >>> metric = MyMetric()
            >>> for epoch in range(num_epochs):
            ...     metric.reset()  # Start fresh each epoch
            ...     for batch in train_loader:
            ...         metric.update(preds, targets)
            ...     print(f"Epoch {epoch}: {metric.compute()}")
        
        Notes:
            - Tensors reset to zero-like values
            - Lists reset to empty []
            - Device remains unchanged
            - Distributed state cleared
        """
        for name, state_dict in self._state_vars.items():
            # Read current attribute to get correct device/dtype even if
            # the tensor was reassigned during update().
            current = getattr(self, name)

            if isinstance(current, Tensor):
                # Reset tensor to zeros with same dtype and device
                new_val = torch.zeros_like(current)
            elif isinstance(current, list):
                # Reset list to empty
                new_val = []
            else:
                # Keep other types as-is
                new_val = current

            state_dict['value'] = new_val
            setattr(self, name, new_val)
        
        # Reset tracking variables
        self._update_count = 0
        self._computed = False
    
    def __call__(self, *args, **kwargs) -> Union[Tensor, Dict[str, Tensor]]:
        """
        Convenience method: update() then compute().
        
        Allows single-line metric calculation:
        
        Example:
            >>> metric = MyMetric()
            >>> result = metric(preds, targets)  # update + compute
            >>> 
            >>> # Equivalent to:
            >>> metric.update(preds, targets)
            >>> result = metric.compute()
        
        Returns:
            Computed metric value(s)
        """
        self.update(*args, **kwargs)
        return self.compute()
    
    def forward(self, *args, **kwargs) -> Union[Tensor, Dict[str, Tensor]]:
        """
        Forward pass (same as __call__).
        
        Enables metric to be used as nn.Module in pipelines.
        """
        return self(*args, **kwargs)

