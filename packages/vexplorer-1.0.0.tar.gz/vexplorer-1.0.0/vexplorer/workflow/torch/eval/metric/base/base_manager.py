

from abc import abstractmethod
from typing import Any, Dict, Optional, Union

import torch
from torch import Tensor

from .base_metric import BaseTorchMetric


class BaseTorchManager(BaseTorchMetric):
    """
    Abstract base class for managing multiple metrics simultaneously.

    BaseTorchManager inherits from BaseTorchMetric and provides a unified interface
    for adding, updating, computing, resetting, and removing multiple metrics.
    Subclasses must implement all abstract methods to define specific management
    strategies (e.g., direct forwarding, list-based, dict-based).

    Args:
        detach: Whether to detach tensors before passing to metrics in update().
            When True, all tensor inputs are detached from the computation graph
            before being forwarded to sub-metrics. Useful for evaluation metrics
            that should not contribute to gradient computation.
            Default: True

        clone: Whether to clone tensors before passing to metrics in update().
            When True, all tensor inputs are cloned before being forwarded,
            preventing in-place modifications from affecting the original tensors.
            Default: False

        **kwargs: Additional keyword arguments passed to BaseTorchMetric.__init__(),
            including device, auto_super, auto_reduction, dist_sync_on_step, etc.

    Attributes:
        _detach: Flag controlling tensor detach behavior.
        _clone: Flag controlling tensor clone behavior.

    Example:
        >>> class MyManager(BaseTorchManager):
        ...     def __init__(self, **kwargs):
        ...         super().__init__(**kwargs)
        ...         self._metrics = {}
        ...
        ...     def add_metric(self, name, metric, wrapper=None):
        ...         self._metrics[name] = metric
        ...
        ...     def update(self, *args, **kwargs):
        ...         for metric in self._metrics.values():
        ...             metric.update(*args, **kwargs)
        ...
        ...     # ... implement other abstract methods

    Notes:
        - All sub-metrics are managed independently of BaseTorchMetric's own state.
        - The detach/clone options apply to tensor arguments in update() only.
        - Subclasses should use _prepare_args() and _prepare_kwargs() to apply
          detach/clone transformations consistently.
    """

    def __init__(
        self,
        detach: bool = True,
        clone: bool = False,
        **kwargs,
    ):
        """Initialize BaseTorchManager with detach/clone configuration."""
        super().__init__(**kwargs)
        self._detach = detach
        self._clone = clone

    def _prepare_tensor(self, value: Any) -> Any:
        """
        Apply detach and clone transformations to a single value if it is a Tensor.

        Args:
            value: Any input value. Only Tensors are transformed.

        Returns:
            Transformed tensor or original value if not a Tensor.

        Example:
            >>> manager = MyManager(detach=True, clone=True)
            >>> prepared = manager._prepare_tensor(some_tensor)
            >>> # prepared is detached and cloned
        """
        if isinstance(value, Tensor):
            if self._detach:
                value = value.detach()
            if self._clone:
                value = value.clone()
        return value

    def _prepare_args(self, args: tuple) -> tuple:
        """
        Apply detach/clone transformations to all positional arguments.

        Args:
            args: Tuple of positional arguments.

        Returns:
            Tuple with tensors prepared according to detach/clone settings.
        """
        return tuple(self._prepare_tensor(a) for a in args)

    def _prepare_kwargs(self, kwargs: dict) -> dict:
        """
        Apply detach/clone transformations to all keyword arguments.

        Args:
            kwargs: Dictionary of keyword arguments.

        Returns:
            Dictionary with tensor values prepared according to detach/clone settings.
        """
        return {k: self._prepare_tensor(v) for k, v in kwargs.items()}

    @abstractmethod
    def add_metric(
        self,
        name: str,
        metric: BaseTorchMetric,
        wrapper: Optional[Any] = None,
        build = False
    ) -> None:
        """
        Add a metric to the manager.

        Subclasses must implement this method to register a metric with an
        optional wrapper that configures how inputs are routed and processed.

        Args:
            name: Unique name identifier for the metric.
            metric: A BaseTorchMetric instance to manage.
            wrapper: Optional configuration wrapper (type depends on subclass).

        Raises:
            ValueError: If the name is already registered or wrapper is invalid.
        """
        pass

    def build(self):
        pass

    @abstractmethod
    def update(self, *args, **kwargs) -> None:
        """
        Update all managed metrics with the given inputs.

        Subclasses must implement this to define how inputs are distributed
        to each managed metric (e.g., broadcast all, select by index, map by key).

        Args:
            *args: Positional arguments for metric updates.
            **kwargs: Keyword arguments for metric updates.
        """
        pass

    @abstractmethod
    def to(self, device: Union[str, torch.device]) -> 'BaseTorchManager':
        """
        Move all managed metrics to the specified device.

        Subclasses must implement this to ensure all sub-metrics and their
        states are transferred to the target device.

        Args:
            device: Target device ('cpu', 'cuda', 'cuda:0', etc.).

        Returns:
            Self for method chaining.
        """
        pass

    @abstractmethod
    def compute(self) -> Dict[str, Any]:
        """
        Compute all managed metrics and return results.

        Subclasses must implement this to define computation order and
        result aggregation strategy.

        Returns:
            Dict[str, Any]: Dictionary mapping metric names to their computed results.
        """
        pass

    @abstractmethod
    def reset(self) -> None:
        """
        Reset all managed metrics to prepare for the next epoch.

        Subclasses must implement this to clear all accumulated state
        in every managed metric.
        """
        pass

    @abstractmethod
    def del_metric(self, name: str) -> None:
        """
        Remove a metric from the manager by name.

        Subclasses must implement this to cleanly remove the metric
        and any associated wrapper or cached data.

        Args:
            name: Name of the metric to remove.

        Raises:
            KeyError: If the name is not found in the manager.
        """
        pass
