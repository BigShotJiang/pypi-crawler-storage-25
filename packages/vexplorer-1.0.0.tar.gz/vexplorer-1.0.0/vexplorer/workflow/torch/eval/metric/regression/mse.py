# -*- coding: utf-8 -*-


import torch
from torch import Tensor
from typing import Optional
from ..base import BaseTorchMetric
from ..utils.decorator import auto_update, auto_compute
from ..utils.enums import DistributedReduceOp, RegressionAggregationMethod
from ..utils.functional import tensor_to_python_scalar

__all__ = [
    "MeanSquaredError", "MSE",
    "RootMeanSquaredError", "RMSE",
]


class MeanSquaredError(BaseTorchMetric):
    """Mean Squared Error (MSE) metric.
    
    Full name: MeanSquaredError
    Alias: MSE
    
    Formula:
        Elementwise: MSE = sum((pred - target)²) / total_valid_elements
        Samplewise: MSE = mean([MSE_sample_0, MSE_sample_1, ...])
    
    Args:
        aggregation: Aggregation method ('elementwise' or 'samplewise')
        squared: If True returns MSE, if False returns RMSE
        **kwargs: Additional arguments for BaseTorchMetric
        
    Input:
        preds: [N, ...] predictions
        target: [N, ...] targets (same shape as preds)
        mask: [N, ...] optional boolean mask (True = valid)
        
    Output:
        Tensor: Scalar MSE or RMSE value
        
    Example:
        >>> from torchmetrics_v4 import MSE
        >>> mse = MSE()
        >>> preds = torch.randn(100, 10)
        >>> targets = torch.randn(100, 10)
        >>> result = mse(preds, targets)
    """
    
    def __init__(
        self,
        aggregation: RegressionAggregationMethod = RegressionAggregationMethod.ELEMENTWISE,
        squared: bool = True,
        **kwargs
    ):
        super().__init__(**kwargs)
        
        if isinstance(aggregation, str):
            aggregation = RegressionAggregationMethod(aggregation.lower())
        
        self.aggregation = aggregation
        self.squared = squared
        
        if aggregation == RegressionAggregationMethod.ELEMENTWISE:
            self.add_state("sum_squared_error", default=torch.tensor(0.0), dist_reduce_fx=DistributedReduceOp.SUM)
            self.add_state("total_elements", default=torch.tensor(0), dist_reduce_fx=DistributedReduceOp.SUM)
        else:
            self.add_state("sample_mse_values", default=[], dist_reduce_fx=DistributedReduceOp.CAT)
    
    @auto_update
    def update(self, preds: Tensor, target: Tensor, mask: Optional[Tensor] = None) -> None:

        if preds.shape != target.shape:
            raise ValueError(
                f"Shape mismatch: preds has shape {list(preds.shape)} "
                f"but target has shape {list(target.shape)}"
            )
        if mask is not None:
            if mask.shape != preds.shape or mask.dtype != torch.bool:
                raise ValueError(
                    f"mask must have same shape as preds {list(preds.shape)} and dtype=torch.bool, "
                    f"got shape {list(mask.shape)} and dtype={mask.dtype}"
                )

        squared_errors = (preds - target) ** 2
        
        if mask is not None:
            squared_errors = squared_errors * mask
        
        if self.aggregation == RegressionAggregationMethod.ELEMENTWISE:
            self.sum_squared_error += squared_errors.sum()
            self.total_elements += mask.sum() if mask is not None else squared_errors.numel()
        else:
            batch_size = preds.shape[0]
            for i in range(batch_size):
                sample_errors = squared_errors[i]
                if mask is not None:
                    sample_mask = mask[i]
                    num_valid = sample_mask.sum()
                    if num_valid > 0:
                        sample_mse = sample_errors.sum() / num_valid
                    else:
                        sample_mse = torch.tensor(0.0, device=preds.device)
                else:
                    sample_mse = sample_errors.mean()
                self.sample_mse_values.append(sample_mse.cpu())
    
    @auto_compute
    def compute(self) -> Tensor:
        
        
        if self.aggregation == RegressionAggregationMethod.ELEMENTWISE:
            total_val = tensor_to_python_scalar(self.total_elements)
            if total_val == 0:
                mse = torch.tensor(float('nan'), device=self.device)
            else:
                mse = self.sum_squared_error.float() / self.total_elements.float()
        else:
            if not self.sample_mse_values:
                mse = torch.tensor(float('nan'), device=self.device)
            else:
                all_values = torch.stack([v.to(self.device) for v in self.sample_mse_values])
                mse = all_values.mean()
        
        return mse if self.squared else torch.sqrt(mse)


class RootMeanSquaredError(MeanSquaredError):
    """Root Mean Squared Error (RMSE).
    
    Full name: RootMeanSquaredError
    Alias: RMSE
    
    Convenience wrapper around MSE with squared=False.
    """
    
    def __init__(self, aggregation=RegressionAggregationMethod.ELEMENTWISE, **kwargs):
        super().__init__(aggregation=aggregation, squared=False, **kwargs)


# Aliases
MSE = MeanSquaredError
RMSE = RootMeanSquaredError



