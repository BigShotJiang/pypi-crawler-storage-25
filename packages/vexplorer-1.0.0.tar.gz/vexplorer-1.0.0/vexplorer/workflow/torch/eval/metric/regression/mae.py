# -*- coding: utf-8 -*-


import torch
from torch import Tensor
from typing import Optional
from ..base import BaseTorchMetric
from ..utils.decorator import auto_update, auto_compute
from ..utils.enums import DistributedReduceOp, RegressionAggregationMethod
from ..utils.functional import tensor_to_python_scalar

__all__ = [

    "MeanAbsoluteError", "MAE",
]



class MeanAbsoluteError(BaseTorchMetric):
    """Mean Absolute Error (MAE) metric.

    Full name: MeanAbsoluteError
    Alias: MAE

    Formula:
        Elementwise: MAE = sum(abs(pred - target)) / total_valid_elements
        Samplewise: MAE = mean([MAE_sample_0, MAE_sample_1, ...])

    Args:
        aggregation: Aggregation method ('elementwise' or 'samplewise')
        **kwargs: Additional arguments for BaseTorchMetric

    Example:
        >>> from torchmetrics_v4 import MAE
        >>> mae = MAE()
        >>> result = mae(preds, targets)
    """

    def __init__(self, aggregation=RegressionAggregationMethod.ELEMENTWISE, **kwargs):
        super().__init__(**kwargs)

        if isinstance(aggregation, str):
            aggregation = RegressionAggregationMethod(aggregation.lower())

        self.aggregation = aggregation

        if aggregation == RegressionAggregationMethod.ELEMENTWISE:
            self.add_state("sum_absolute_error", default=torch.tensor(0.0), dist_reduce_fx=DistributedReduceOp.SUM)
            self.add_state("total_elements", default=torch.tensor(0), dist_reduce_fx=DistributedReduceOp.SUM)
        else:
            self.add_state("sample_mae_values", default=[], dist_reduce_fx=DistributedReduceOp.CAT)

    @auto_update
    def update(self, preds: Tensor, target: Tensor, mask: Optional[Tensor] = None) -> None:

        if preds.shape != target.shape:
            raise ValueError(
                f"Shape mismatch: preds has shape {list(preds.shape)} "
                f"but target has shape {list(target.shape)}"
            )
        if mask is not None:
            if mask.shape != preds.shape or mask.dtype != torch.bool:
                raise ValueError(
                    f"mask must have same shape as preds {list(preds.shape)} and dtype=torch.bool, "
                    f"got shape {list(mask.shape)} and dtype={mask.dtype}"
                )

        absolute_errors = torch.abs(preds - target)

        if mask is not None:
            absolute_errors = absolute_errors * mask

        if self.aggregation == RegressionAggregationMethod.ELEMENTWISE:
            self.sum_absolute_error += absolute_errors.sum()
            self.total_elements += mask.sum() if mask is not None else absolute_errors.numel()
        else:
            batch_size = preds.shape[0]
            for i in range(batch_size):
                sample_errors = absolute_errors[i]
                if mask is not None:
                    sample_mask = mask[i]
                    num_valid = sample_mask.sum()
                    if num_valid > 0:
                        sample_mae = sample_errors.sum() / num_valid
                    else:
                        sample_mae = torch.tensor(0.0, device=preds.device)
                else:
                    sample_mae = sample_errors.mean()
                self.sample_mae_values.append(sample_mae.cpu())

    @auto_compute
    def compute(self) -> Tensor:

        if self.aggregation == RegressionAggregationMethod.ELEMENTWISE:
            total_val = tensor_to_python_scalar(self.total_elements)
            if total_val == 0:
                return torch.tensor(float('nan'), device=self.device)
            return self.sum_absolute_error.float() / self.total_elements.float()
        else:
            if not self.sample_mae_values:
                return torch.tensor(float('nan'), device=self.device)
            all_values = torch.stack([v.to(self.device) for v in self.sample_mae_values])
            return all_values.mean()


# Aliases
MAE = MeanAbsoluteError
