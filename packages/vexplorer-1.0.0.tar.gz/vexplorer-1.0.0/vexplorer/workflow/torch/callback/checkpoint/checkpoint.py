# -*- coding: utf-8 -*-
"""
Checkpointing and Early Stopping Callbacks.

This module provides callback classes for saving model checkpoints based on intervals
or metric improvements, as well as early stopping functionality. It is designed to
be compatible with distributed training environments.
"""

import os
import shutil
import logging
import torch
import torch.distributed as dist
from pathlib import Path
from typing import Dict, Any, Optional, List, Union

from ...run.context.trainer import  BaseRunContext as RunContext
from ..base import BaseTrainerCallback
from ..utils.mixin.metric_mixin import MetricMonitorMixin

logger = logging.getLogger(__name__)


class BaseCheckpointCallback(BaseTrainerCallback):
    """
    Base class providing atomic save operations and checkpoint management.

    This class handles the core logic of creating directories, synchronizing processes,
    dispatching save operations based on mode (dict/state/model), and managing
    the maximum number of kept checkpoints.

    Args:
        save_dir (Path): Directory where checkpoints will be saved.
        save_mode (str, optional): The saving mechanism. Defaults to "model".
            - "dict": Saves a dictionary containing state_dict, epoch, etc. (Always .pth)
            - "state": Calls engine.save_state() (Often for DeepSpeed/Megatron).
            - "model": Calls engine.save_model() (For raw model serialization).
        max_keep (int, optional): Maximum number of recent checkpoints to keep.
            Older checkpoints are deleted. Defaults to 5.
    """

    def __init__(self,
                 save_dir: Union[str, Path],
                 save_mode: str = "model",
                 max_keep: int = 5,
                 **kwargs):
        self.save_dir = Path(save_dir)
        self.save_mode = save_mode
        self.max_keep = max_keep

        # Stores the exact paths (including suffixes) of saved checkpoints
        self.recent_checkpoints: List[Path] = []

        valid_modes = ["dict", "state", "model"]
        if self.save_mode not in valid_modes:
            raise ValueError(f"Invalid save_mode: {save_mode}. Must be one of {valid_modes}")

    def on_begin(self, run_context: RunContext) -> None:
        self._ensure_dir()

    def _ensure_dir(self) -> None:
        """Ensures the save directory exists."""
        if not self.save_dir.exists():
            try:
                self.save_dir.mkdir(parents=True, exist_ok=True)
            except FileExistsError:
                # Race condition in multi-process is acceptable
                pass

    def _save_checkpoint(self,
                         run_context: Any,
                         name_suffix: str,
                         meta_extra: Optional[Dict] = None) -> None:
        """
        Executes the saving logic.

        Args:
            run_context (Any): Context object containing args, engine, and model.
            name_suffix (str): The filename suffix (e.g., 'epoch_1', 'best').
            meta_extra (Dict, optional): Extra metadata to save in 'dict' mode.
        """
        args = run_context.original_args()
        engine = args.engine

        # 1. Synchronization (ensure all ranks are ready)
        if hasattr(engine, "wait_for_everyone"):
            engine.wait_for_everyone()
        elif dist.is_initialized():
            dist.barrier()

        # 2. Determine Path & Normalize Extension
        # Logic: If mode is 'dict', we force .pth. Otherwise (state/model),
        # we rely on the engine or assume directory/file based on user naming.
        filename = f"{name_suffix}"
        if self.save_mode == "dict":
            # Ensure it ends with .pth if in dict mode
            if not filename.endswith(".pth"):
                filename += ".pth"

        file_path = self.save_dir.joinpath(filename)

        # 3. Execute Save (Only Main Process performs actual IO usually,
        # but engines like DeepSpeed might need all ranks to call save)
        try:
            # Note: Specific implementations should handle "is_main" check if needed,
            # or the engine handles it.
            if self.save_mode == "dict":
                self._save_dict_mode(args, file_path, meta_extra)
            elif self.save_mode == "state":
                self._save_state_mode(args, file_path)
            elif self.save_mode == "model":
                self._save_model_mode(args, file_path)

            # 4. Logging & Cleanup (Strictly Main Process)
            is_main = getattr(engine, "is_main", True)
            if is_main:
                logger.info(f"[Checkpoint] Saved ({self.save_mode}) to {file_path}")
                self._update_recent_checkpoints(file_path)

        except Exception as e:
            logger.error(f"[Checkpoint] Failed to save {file_path}: {e}", exc_info=True)
            # We raise the error to prevent silent failures in training
            raise e

    def _update_recent_checkpoints(self, file_path: Path) -> None:
        """Updates the list of recent checkpoints and handles max_keep."""
        # If overwriting an existing checkpoint (e.g., 'best.pth'), remove old record first
        if file_path in self.recent_checkpoints:
            self.recent_checkpoints.remove(file_path)

        self.recent_checkpoints.append(file_path)
        self._manage_max_keep()

    # --- Internal Save Implementations ---

    def _save_dict_mode(self, args: Any, file_path: Path, meta_extra: Optional[Dict]) -> None:
        """Saves a standard PyTorch dictionary."""
        model = args.network
        engine = args.engine

        # Unwrap DDP/ModelWrapper if necessary
        if hasattr(engine, "get_state_dict"):
            state_dict = engine.get_state_dict(model)
        else:
            state_dict = model.state_dict()

        save_dict = {
            'epoch': getattr(args, 'cur_epoch_num', 0),
            'step': getattr(args, 'cur_step_num', 0),
            'state_dict': state_dict,
            'meta': getattr(args, 'extras', {}).copy()
        }
        if meta_extra:
            save_dict['meta'].update(meta_extra)

        # # Cleanup internal keys
        # if 'accelerator' in save_dict['meta']:
        #     del save_dict['meta']['accelerator']

        # Use engine's save if available (e.g. for async IO), else torch.save
        if hasattr(engine, "save"):
            engine.save(save_dict, str(file_path))
        else:
            # Only rank 0 usually saves in standard DDP, ensure this check exists
            if getattr(engine, "is_main", True):
                torch.save(save_dict, file_path)

    def _save_state_mode(self, args: Any, file_path: Path) -> None:
        """Delegates to engine.save_state (e.g. for DeepSpeed)."""
        engine = args.engine
        if hasattr(engine, "save_state"):
            engine.save_state(str(file_path))
        else:
            logger.warning("Engine does not support save_state. Fallback to dict mode.")
            # Fallback: force .pth extension if not present
            fallback_path = file_path.with_suffix(".pth")
            self._save_dict_mode(args, fallback_path, {})
            # Important: Update the path variable if we want correct tracking,
            # but _save_checkpoint caller uses the original file_path.
            # In a strict system, we might need to return the actual path used.

    def _save_model_mode(self, args: Any, file_path: Path) -> None:
        """Delegates to engine.save_model."""
        engine = args.engine
        model = args.network
        if hasattr(engine, "save_model"):
            engine.save_model(model, str(file_path))
        else:
            logger.warning("Engine does not support save_model. Fallback to dict mode.")
            fallback_path = file_path.with_suffix(".pth")
            self._save_dict_mode(args, fallback_path, {})

    def _manage_max_keep(self) -> None:
        """Deletes old checkpoints to respect max_keep."""
        if self.max_keep <= 0:
            return

        while len(self.recent_checkpoints) > self.max_keep:
            path_to_remove = self.recent_checkpoints.pop(0)

            # Because of potential fallbacks (state -> dict), the file might contain .pth
            # even if the original request didn't. We check both.
            candidates = [path_to_remove, path_to_remove.with_suffix(".pth")]

            removed_flag = False
            for p in candidates:
                if p.exists():
                    try:
                        if p.is_dir():
                            shutil.rmtree(p)
                        else:
                            p.unlink()
                        logger.debug(f"[Checkpoint] Removed old checkpoint: {p}")
                        removed_flag = True
                        break # Successfully removed one representation
                    except OSError as e:
                        logger.warning(f"[Checkpoint] Failed to remove {p}: {e}")

            if not removed_flag:
                logger.debug(f"[Checkpoint] Could not find file to remove for: {path_to_remove}")


class IntervalCheckpointCallback(BaseCheckpointCallback):
    """
    Saves checkpoints at fixed epoch or step intervals.

    Args:
        save_dir (str): Directory to save checkpoints.
        save_epoch_interval (int, optional): Save every N epochs. Defaults to 1.
        save_step_interval (int, optional): Save every N steps. Defaults to None.
        **kwargs: Arguments passed to BaseCheckpointCallback.

    Example:
        >>> callback = IntervalCheckpointCallback(save_dir="ckpt", save_epoch_interval=2)
    """

    def __init__(self,
                 save_dir: str,
                 save_epoch_interval: int = 1,
                 save_step_interval: Optional[int] = None,
                 **kwargs):
        super().__init__(save_dir, **kwargs)
        self.save_epoch_interval = save_epoch_interval
        self.save_step_interval = save_step_interval

    def on_train_epoch_end(self, run_context: Any) -> None:
        args = run_context.original_args()
        epoch = args.cur_epoch_num
        if self.save_epoch_interval and epoch % self.save_epoch_interval == 0:
            self._save_checkpoint(run_context, f"epoch_{epoch}")

    def on_train_step_end(self, run_context: Any) -> None:
        args = run_context.original_args()
        step = args.cur_step_num
        if self.save_step_interval and step % self.save_step_interval == 0:
            self._save_checkpoint(run_context, f"step_{step}")


class BestCheckpointCallback(BaseCheckpointCallback, MetricMonitorMixin):
    """
    Saves the 'best' model based on a monitored metric.

    Args:
        save_dir (str): Directory to save checkpoints.
        monitor (str): Metric name to monitor (e.g., 'val_acc').
        mode (str, optional): 'min' (for loss) or 'max' (for accuracy). Defaults to "min".
        **kwargs: Arguments passed to BaseCheckpointCallback.

    Example:
        >>> callback = BestCheckpointCallback("ckpt", monitor="val_acc", mode="max")
    """

    def __init__(self, save_dir: str, monitor: str, mode: str = "min", **kwargs):
        # Enforce max_keep=1 for best checkpoint to avoid clutter
        super().__init__(save_dir, max_keep=1, **kwargs)
        self.monitor = monitor
        self.mode = mode
        self.best_score = float('inf') if mode == 'min' else float('-inf')

    def on_eval_epoch_end(self, run_context: Any) -> None:
        current_score = self.get_synced_metric(run_context, self.monitor)
        # 必须所有卡都运行，否则分布式可能卡死

        if current_score is not None:
            is_better = (current_score < self.best_score) if self.mode == "min" else (current_score > self.best_score)

            if is_better:
                # engine = run_context.original_args().engine
                # if getattr(engine, "is_main", True):
                #     logger.info(f"[BestCheckpoint] New best {self.monitor}: {current_score:.4f} (Previous: {self.best_score:.4f})")

                self.best_score = current_score
                # Save as "best.pth" or "best" directory
                self._save_checkpoint(run_context, "best", meta_extra={"score": self.best_score})




