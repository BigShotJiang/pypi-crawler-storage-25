# -*- coding: utf-8 -*-
import os
import queue
import threading
import logging
import time
from typing import List, Dict, Any, Optional, Union
from collections import defaultdict
import numpy as np
import pandas as pd
import torch
import re


from ..base import BaseTrainerCallback

logger = logging.getLogger(__name__)

# ==============================================================================
# Optional Dependencies (Soft Imports)
# ==============================================================================
try:
    from sqlalchemy import create_engine
    from sqlalchemy.engine import Engine
except ImportError:
    create_engine = None
    Engine = None
    logger.warning("Module 'sqlalchemy' not found. SQLBackend will be disabled.")

try:
    import psycopg2
except ImportError:
    psycopg2 = None
    logger.warning("Module 'psycopg2' not found. PostgresBackend will be disabled.")


try:
    from torch.utils.tensorboard import SummaryWriter
except ImportError:
    SummaryWriter = None
    logger.warning("Module 'tensorboard' not found. TensorBoardBackend will be disabled.")

try:
    from accelerate.tracking import GeneralTracker
except ImportError:
    GeneralTracker = None
    logger.warning("Module 'accelerate.tracking' not found. Accelerate log will be disabled.")



# ==============================================================================
# 1. Utils
# ==============================================================================

def flatten_dict(d: dict, parent_key: str = '', sep: str = '_') -> dict:
    items = {}
    for k, v in d.items():

        clean_k = re.sub(r'[/.\s\-]', sep, str(k))

        new_key = f"{parent_key}{sep}{clean_k}" if parent_key else clean_k
        if isinstance(v, dict):
            items.update(flatten_dict(v, new_key, sep))
        else:
            items[new_key] = v
    return items


def extract_scalars(data: Dict[str, Any], flatten_dict_key=True) -> Dict[str, Union[float, int]]:
    """Helper to extract scalar values from a dictionary containing mixed types.
    
    Handles:
    - Native int/float
    - 0-dim PyTorch Tensors (converted to python scalar)
    - 0-dim Numpy Arrays (converted to python scalar)

    Args:
        data (Dict[str, Any]): Input dictionary.

    Returns:
        Dict[str, Union[float, int]]: Dictionary containing only scalar values.
    """
    if flatten_dict_key:
        data = flatten_dict(data)
    clean_data = {}
    for k, v in data.items():
        if isinstance(v, (int, float)):
            clean_data[k] = v
        elif isinstance(v, torch.Tensor):
            if v.numel() == 1:
                clean_data[k] = v.item()
        elif isinstance(v, (np.ndarray, np.generic)):
            if v.size == 1:
                clean_data[k] = float(v)
    return clean_data


# ==============================================================================
# 2. Base Backend Interface
# ==============================================================================

class AsyncBackend:
    """Abstract base class for logging backends.
    
    All methods in this class are executed in a separate consumer thread.
    """
    def init(self):
        """Called once when the consumer thread starts."""
        pass

    def write(self, record: Dict[str, Any], table_name: str):
        """Process a single record.

        Args:
            record (Dict): The data dictionary to log.
            table_name (str): The category/table name (e.g., 'train', 'val').
        """
        raise NotImplementedError

    def close(self):
        """Called when the logger is shutting down."""
        pass


# ==============================================================================
# 3. Concrete Backends
# ==============================================================================

class TabularBackend(AsyncBackend):
    """Base class for backends that write tabular data (rows/columns).
    
    Implements buffering to reduce I/O frequency.
    
    Args:
        buffer_size (int): Number of records to accumulate before flushing.
    """
    def __init__(self, buffer_size: int = 50, flatten_dict_key = True):
        self.buffers = defaultdict(list)
        self.buffer_size = buffer_size
        self.flatten_dict_key = flatten_dict_key

    def write(self, record: Dict[str, Any], table_name: str):
        row = extract_scalars(record,self.flatten_dict_key)

        # Ensure 'step' exists for time-series alignment
        if 'step' in record and 'step' not in row:
            row['step'] = record['step']

        if row:
            self.buffers[table_name].append(row)

        if len(self.buffers[table_name]) >= self.buffer_size:
            self._flush(table_name)

    def _flush(self, table_name: str):
        data = self.buffers[table_name]
        if not data: return

        try:
            df = pd.DataFrame(data)
            self.flush_df(df, table_name)
        except Exception as e:
            logger.error(f"[{self.__class__.__name__}] Flush failed for table '{table_name}': {e}")
        finally:
            self.buffers[table_name] = [] # Clear buffer even if flush failed

    def close(self):
        """Flush remaining data on close."""
        for t in list(self.buffers.keys()):
            self._flush(t)

    def flush_df(self, df: pd.DataFrame, table_name: str):
        """Abstract method to handle the DataFrame write operation."""
        raise NotImplementedError


class CsvBackend(TabularBackend):
    """Backend that writes logs to CSV files.
    
    Args:
        save_dir (str): Directory where CSV files will be saved.
    """
    def __init__(self, save_dir: str):
        super().__init__()
        self.save_dir = save_dir
        self.existing_files = set()

    def init(self):
        os.makedirs(self.save_dir, exist_ok=True)

    def flush_df(self, df: pd.DataFrame, table_name: str):
        path = os.path.join(self.save_dir, f"{table_name}.csv")

        # Determine if we need to write the header
        write_header = False
        if path not in self.existing_files:
            if not os.path.exists(path):
                write_header = True
            self.existing_files.add(path)

        df.to_csv(path, mode='a', index=False, header=write_header)


class SQLBackend(TabularBackend):
    """Backend that writes logs to SQL databases (SQLite/PostgreSQL).
    
    Args:
        db_url (str): SQLAlchemy connection string (e.g., 'sqlite:///log.db').
    """
    def __init__(self, db_url: str):
        super().__init__()
        self.db_url = db_url
        self.engine = None

    def init(self):
        if not create_engine:
            logger.error("SQLBackend ignored: sqlalchemy not installed.")
            return

        # PostgreSQL driver check
        if self.db_url.startswith("postgresql") and psycopg2 is None:
            logger.warning("psycopg2 not found. PostgreSQL connection might fail.")

        # SQLite directory check
        if self.db_url.startswith("sqlite:///"):
            path = self.db_url.replace("sqlite:///", "")
            if path != ":memory:":
                abs_path = os.path.abspath(path)
                os.makedirs(os.path.dirname(abs_path), exist_ok=True)
                # Normalize path
                self.db_url = f"sqlite:///{abs_path}"

        try:
            self.engine = create_engine(self.db_url)
        except Exception as e:
            logger.error(f"SQLBackend Init failed (url={self.db_url}): {e}")

    def flush_df(self, df: pd.DataFrame, table_name: str):
        if self.engine:
            # Use 'begin' for transaction context
            with self.engine.begin() as conn:
                df.to_sql(table_name, con=conn, if_exists='append', index=False)


class TensorBoardBackend(AsyncBackend):
    """Backend that logs scalars and histograms to TensorBoard.
    
    Args:
        log_dir (str): Directory for TensorBoard event files.
    """
    def __init__(self, log_dir: str, flatten_dict_key = True):
        self.log_dir = log_dir
        self.writer = None
        self.flatten_dict_key = flatten_dict_key

    def init(self):
        if SummaryWriter:
            self.writer = SummaryWriter(log_dir=self.log_dir)

    def write(self, record: Dict[str, Any], table_name: str):
        if not self.writer: return

        step = record.get('step', None)
        scalars = extract_scalars(record,self.flatten_dict_key)

        # Remove step from scalars to avoid redundant plotting
        scalars.pop('step', None)

        # 1. Log Scalars
        if scalars and step is not None:
            for k, v in scalars.items():
                self.writer.add_scalar(f"{table_name}/{k}", v, global_step=step)

        # 2. Log Histograms (for Tensors/Arrays)
        for k, v in record.items():
            if isinstance(v, (np.ndarray, torch.Tensor)):
                # Check dim > 0 to differentiate from scalars
                if getattr(v, 'ndim', 0) > 0:
                    self.writer.add_histogram(f"{table_name}/{k}", v, global_step=step)

    def close(self):
        if self.writer:
            self.writer.close()


class ArtifactBackend(AsyncBackend):
    """Backend that saves heavy artifacts (Tensors, Numpy Arrays) as files.
    
    Args:
        save_dir (str): Root directory for artifacts.
    """
    def __init__(self, save_dir: str):
        self.save_dir = save_dir

    def write(self, record: Dict[str, Any], table_name: str):
        step = record.get('step', 0)
        # Create a subdirectory for the specific table/metric group
        table_dir = os.path.join(self.save_dir, table_name, str(step))

        for key, value in record.items():
            # Filter logic: Only save multi-dimensional arrays
            is_tensor_like = isinstance(value, (torch.Tensor, np.ndarray))
            has_dims = (getattr(value, 'ndim', 0) > 0 or getattr(value, 'size', 0) > 1)

            if is_tensor_like and has_dims:
                try:
                    os.makedirs(table_dir, exist_ok=True)
                    safe_key = key.replace('/', '_')

                    if isinstance(value, torch.Tensor):
                        # Use .clone().detach() to ensure safety, though usually value is already detached
                        filename = os.path.join(table_dir, f"{step:06d}_{safe_key}.pt")
                        torch.save(value.cpu(), filename)
                    elif isinstance(value, np.ndarray):
                        filename = os.path.join(table_dir, f"{step:06d}_{safe_key}.npy")
                        np.save(filename, value)
                    else:
                        logger.warning(f"Can't save {key} to {table_dir}")
                except Exception as e:
                    logger.error(f"[ArtifactBackend] Save failed for {key}: {e}")


# ==============================================================================
# 4. Async Dispatcher
# ==============================================================================

class AsyncDispatcher:
    """Manages a background thread to process logs asynchronously.
    
    This ensures that file I/O or network operations do not block the 
    training loop.

    Args:
        backends (List[AsyncBackend]): List of backend instances.
    """
    def __init__(self, backends: List[AsyncBackend]):
        self.backends = backends
        self._queue = queue.Queue()
        self._stop_event = threading.Event()

        # Daemon thread ensures it dies if the main process crashes
        self._thread = threading.Thread(target=self._worker, daemon=True, name="LogRecorderWorker")
        self._thread.start()

    def log(self, data: Dict[str, Any], table_name: str):
        """Enqueue a log record."""
        self._queue.put((data, table_name))

    def _worker(self):
        """Consumer loop running in background thread."""
        # Initialize backends
        for b in self.backends:
            try:
                b.init()
            except Exception as e:
                logger.error(f"Backend init failed ({type(b).__name__}): {e}")

        # Main Loop
        while not self._stop_event.is_set() or not self._queue.empty():
            try:
                # Use timeout to allow checking stop_event periodically
                item = self._queue.get(timeout=0.05)
                data, table_name = item

                for b in self.backends:
                    try:
                        b.write(data, table_name)
                    except Exception as e:
                        logger.error(f"Backend write error ({type(b).__name__}): {e}")

                self._queue.task_done()
            except queue.Empty:
                continue

        # Cleanup backends
        for b in self.backends:
            try:
                b.close()
            except Exception as e:
                logger.error(f"Backend close error ({type(b).__name__}): {e}")

    def close(self):
        """Signal the worker to stop and wait for it to finish."""
        self._stop_event.set()
        self._thread.join()


class AccelerateLogAdapter(GeneralTracker):
    """
    A custom Tracker for HuggingFace Accelerate that bridges to AsyncDispatcher.

    This allows Accelerate to log metrics (via `accelerator.log()`) directly into
    our unified logging system (CSV, SQL, etc.).

    Args:
        dispatcher (AsyncDispatcher): The existing dispatcher instance from LogRecorder.
        run_name (str): Name of the run (required by GeneralTracker base).
    """
    # Name of the tracker (used by Accelerate to identify it)
    name = "vexplorer"

    # We don't need a third-party library, so this is None
    requires_logging_directory = False

    def __init__(self, dispatcher: AsyncDispatcher, run_name: str = "exp"):
        super().__init__(run_name)
        self.dispatcher = dispatcher
        self.run_name = run_name

    @property
    def tracker(self):
        """Returns the underlying object (the dispatcher in this case)."""
        return self.dispatcher

    def store_init_configuration(self, values: dict):
        """
        Logs initialization configuration (hyperparameters).
        Accelerate calls this automatically.
        """
        # We log this as a special "config" table or just log it once
        # Add a dummy step 0 for consistency
        values['step'] = 0
        self.dispatcher.log(values, table_name="config")
        logger.info("[AccelerateLogAdapter] Stored init configuration.")

    def log(self, values: dict, step: Optional[int], **kwargs):
        """
        Logs metrics.
        Accelerate calls this via `accelerator.log()`.
        """
        if step is not None:
            values['step'] = step

        # Determine table name based on keys or default to 'accelerate_metrics'
        # Since Accelerate mixes everything, we use a generic name
        self.dispatcher.log(values, table_name="accelerate_metrics")

    def finish(self):
        """
        Called when training finishes.
        Note: We DO NOT close the dispatcher here, because LogRecorder manages its lifecycle.
        """
        pass


# ==============================================================================
# 5. LogRecorder (Main Callback)
# ==============================================================================

class LogRecorder(BaseTrainerCallback):
    """Callback to record training/evaluation metrics asynchronously.

    It collects data from the `RunContext` at specific intervals and dispatches
    it to the configured backends (CSV, SQL, TensorBoard, etc.).

    Args:
        backends (List[AsyncBackend]): List of configured backends.
        is_main (bool): If False, logging is disabled (for DDP).
        interval (int): How often (in steps) to log training metrics.
        callback_save (bool): If True, automatically hooks into `on_train_step_end`
            and other lifecycle methods. If False, the user must call `log()` manually.
        accelerate_adapter_name (str): Name for the Accelerate tracker, set None will not set Accelerate tracker.

    Example:
        >>> # 0. Base use
        >>> recorder = build_log_recorder(csv_save_dir="./logs")
        >>> recorder.log({"loss": 0.5, "step": 10}, table_name="train")
        >>>
        >>> # 1. Create Recorder
        >>> recorder = build_log_recorder(csv_save_dir="./logs",accelerate_adapter_name="acc")
        >>>
        >>> # 2. Get Tracker for Accelerate
        >>> tracker = recorder.get_tracker()
        >>> accelerator = Accelerator(log_with=tracker)
    """
    def __init__(self,
                 backends: List[AsyncBackend],
                 is_main: bool = True,
                 interval: int = 1,
                 callback_save: bool = True,
                 accelerate_adapter_name: str = None,
                 ):
        super().__init__()

        # Create Dispatcher (Shared Engine)
        self.dispatcher = AsyncDispatcher(backends)

        # Env
        self.is_main = is_main
        self.interval = interval
        self.callback_save = callback_save

        # Create the Adapter Tracker (Lazy init or immediate)
        self._accelerate_tracker = None
        if self.is_main and accelerate_adapter_name is not None:
            self._accelerate_tracker = AccelerateLogAdapter(self.dispatcher, run_name=accelerate_adapter_name)
        else:
            self._accelerate_tracker = None

        # Hook standard lifecycle methods only if requested
        if self.is_main and self.callback_save:
            # Overwrite instance methods with implementation
            self.on_train_step_end = self._on_train_step_end
            self.on_eval_step_end = self._on_eval_step_end
            self.on_train_epoch_end = self._on_train_epoch_end
            self.on_eval_epoch_end = self._on_eval_epoch_end
            self.on_end = self._on_end

    def get_tracker(self) -> Optional[GeneralTracker]:
        """
        Returns the Accelerate-compatible Tracker object.
        Pass this to `Accelerator(log_with=tracker)`.
        """
        return self._accelerate_tracker

    def log(self, data: Dict[str, Any], table_name: str = "default"):
        """Manual logging interface.

        Args:
            data (Dict): Dictionary of metrics.
            table_name (str): Category name.
        """
        if self.is_main:
            self.dispatcher.log(data, table_name)

    def close(self):
        """Gracefully stop the background logger."""
        if self.is_main:
            self.dispatcher.close()

    # ---

    def _on_end(self, run_context):
        self.close()

    # Support context manager usage
    def __enter__(self): return self
    # def __exit__(self, exc_type, exc_val, exc_tb): self.close()

    # --- Internal Lifecycle Hooks ---

    def _on_train_step_end(self, run_context):
        args = run_context.original_args()
        if args.cur_step_num % self.interval == 0:
            data = {
                "step": args.cur_step_num,
                "epoch": args.cur_epoch_num,
                "loss": getattr(args, 'train_loss', 0.0)
            }
            self.log(data, table_name="train_loss")

            train_raw_losses = getattr(args, 'train_raw_losses', {})
            train_raw_losses.update(data)
            self.log( train_raw_losses, table_name="train_raw_losses")

    def _on_eval_step_end(self, run_context):
        args = run_context.original_args()
        if args.cur_step_num_of_eval % self.interval == 0:
            data = {
                "step": args.cur_step_num_of_eval,
                "epoch": args.cur_epoch_num_of_eval,
                "loss": getattr(args, 'eval_loss', 0.0)
            }
            self.log(data, table_name="eval_loss")

            eval_raw_losses = getattr(args, 'eval_raw_losses', {})
            eval_raw_losses.update(data)
            self.log(eval_raw_losses, table_name="eval_raw_losses")

    def _on_eval_epoch_end(self, run_context):
        args = run_context.original_args()
        data = {
            "step": args.cur_step_num_of_eval,
            "epoch": args.cur_epoch_num_of_eval,
        }
        eval_metrics = getattr(args, 'eval_metrics', {})
        eval_metrics.update(data)
        self.log(eval_metrics, table_name="eval_metrics")

    def _on_train_epoch_end(self, run_context):
        args = run_context.original_args()
        data = {
            "step": args.cur_step_num,
            "epoch": args.cur_epoch_num,
        }

        # # 2. Extract Learning Rates
        # optimizer = getattr(args, 'optimizer', None)
        # if optimizer:
        #     for i, pg in enumerate(optimizer.param_groups):
        #         data[f"lr/g{i}"] = pg.get("lr", 0.0)
        #
        # # 3. Artifacts (e.g. model outputs for visualization)
        # outputs = getattr(args, 'net_outputs', None)
        # if outputs is not None:
        #     if isinstance(outputs, torch.Tensor):
        #         data["net_outputs"] = outputs.detach().cpu()

        train_metrics = getattr(args, 'train_metrics', {})
        train_metrics.update(data)
        self.log( train_metrics, table_name="train_metrics")


# ==============================================================================
# 6. Factory Method
# ==============================================================================

def build_log_recorder(
        csv_save_dir: Optional[str] = None,
        sqlite_db_url: Optional[str] = None,
        postgres_db_url: Optional[str] = None,
        db_url_list: Optional[List[str]] = None,
        tensorboard_log_dir: Optional[str] = None,
        artifact_save_dir: Optional[str] = None,
        **kwargs
) -> LogRecorder:
    """Factory function to instantiate LogRecorder with specific backends.

    Args:
        csv_save_dir (str, optional): Path to save CSV logs.
        sqlite_db_url (str, optional): SQLite connection string.
        postgres_db_url (str, optional): PostgreSQL connection string.
        db_url_list (List[str], optional): List of generic DB connection strings.
        tensorboard_log_dir (str, optional): Path for TensorBoard logs.
        artifact_save_dir (str, optional): Path to save heavy artifacts (pt/npy).
        **kwargs: Arguments passed to LogRecorder init (e.g., interval).

    Returns:
        LogRecorder: Configured callback instance.
    """
    backends = []

    if csv_save_dir:
        backends.append(CsvBackend(csv_save_dir))

    if postgres_db_url:
        backends.append(SQLBackend(postgres_db_url))
    elif sqlite_db_url:
        backends.append(SQLBackend(sqlite_db_url))

    if db_url_list:
        for db_url in db_url_list:
            backends.append(SQLBackend(db_url))

    if tensorboard_log_dir:
        backends.append(TensorBoardBackend(tensorboard_log_dir))

    if artifact_save_dir:
        backends.append(ArtifactBackend(artifact_save_dir))

    if not backends:
        raise ValueError("LogRecorder requires at least one backend configuration.")
    obj = LogRecorder(
        backends,
        **kwargs)
    return obj



