from typing import Any, Optional, List
import torch
import torch.distributed as dist


class MetricMonitorMixin:
    """
    Mixin class to retrieve and synchronize metrics across distributed processes.
    This class provides utilities to fetch nested dictionary values and ensure
    consistency across all distributed ranks.
    """

    def get_dictvalue_from_listpath(self, dict_data: dict, path_list: List[str]) -> Any:
        """
        Recursively retrieves a value from a nested dictionary using a list of keys.

        Args:
            dict_data (dict): The dictionary to search.
            path_list (List[str]): List of keys representing the path (e.g., ['eval', 'acc']).

        Returns:
            Any: The found value or None if any key in the path does not exist.
        """
        if not path_list:
            return None

        current_key = path_list[0]
        if len(path_list) == 1:
            return dict_data.get(current_key)

        # Recursive step: drill down if the current key exists and leads to another dict
        next_node = dict_data.get(current_key)
        if isinstance(next_node, dict):
            return self.get_dictvalue_from_listpath(next_node, path_list[1:])
        return None

    def get_synced_metric(self, run_context: Any, monitor_key: str, split_by: str = ".") -> Optional[float]:
        """
        Retrieves a metric value and synchronizes it across all distributed ranks
        using a single broadcast operation to minimize latency.

        Args:
            run_context (Any): Context containing args and engine.
            monitor_key (str): Dot-separated key string (e.g., 'eval_metrics.val_acc').
            split_by (str): Delimiter used to parse the monitor_key.

        Returns:
            Optional[float]: The synchronized metric value from Rank 0, or None if not found.
        """
        # 所有卡都运行，但是是卡1广播给其他卡

        # 1. Extract local value (primarily relevant for Rank 0)
        args = run_context.original_args()
        engine = args.engine

        # Parse the key path
        key_parts = monitor_key.split(split_by)
        # Assume the first part is an attribute of 'args' (e.g., args.eval_metrics)
        root_attr = getattr(args, key_parts[0], {})
        raw_val = self.get_dictvalue_from_listpath(root_attr, key_parts[1:])

        # Convert to float if exists
        local_val = float(raw_val) if raw_val is not None else None

        # 2. Prepare for Synchronization
        # We use Rank 0 as the source of truth.
        device = getattr(engine, "device", torch.device("cpu"))

        # Optimization: Pack both 'exists_flag' and 'value' into a single tensor [2,]
        # Index 0: 1.0 if value exists, 0.0 otherwise.
        # Index 1: The actual metric value (or 0.0 placeholder).
        sync_buffer = torch.tensor(
            [
                1.0 if local_val is not None else 0.0,
                local_val if local_val is not None else 0.0
            ],
            device=device,
            dtype=torch.float32
        )

        # 3. Single Broadcast Operation
        # This synchronizes the buffer from Rank 0 to all other ranks.
        if dist.is_initialized():
            dist.broadcast(sync_buffer, src=0)

        # 4. Parse Results
        # Check the existence flag (Index 0)
        if sync_buffer[0].item() == 0.0:
            return None

        # Return the synchronized value (Index 1)
        return sync_buffer[1].item()



