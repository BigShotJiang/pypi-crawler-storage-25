# -*- coding: utf-8 -*-
import logging
import torch.distributed as dist
from typing import Any

from ..base import BaseTrainerCallback

logger = logging.getLogger(__name__)


class DistributedCleaner(BaseTrainerCallback):
    """Callback that gracefully cleans up distributed training resources.

    This callback hooks into the end of the training lifecycle (`on_end`).
    It ensures that all processes are synchronized and that both Accelerate's
    engine trackers and PyTorch's native distributed process groups are
    properly destroyed, preventing memory leaks and zombie processes.

    Args:
        **kwargs: Additional arguments passed to the base Callback.

    Example:
        >>> # In your config or code
        >>> callback = DistributedCleaner()
    """

    def __init__(self, **kwargs):
        super().__init__(**kwargs)

    def on_end(self, run_context: Any) -> None:
        """Cleans up distributed environments at the end of the run.

        Args:
            run_context: The runner context providing access to training state
                and the original arguments (where the accelerate engine resides).
        """
        logger.info("[DistributedCleaner] Starting cleanup of distributed resources...")

        # ==========================================
        # 1. Cleanup Accelerate Engine (if available)
        # ==========================================
        try:
            if hasattr(run_context, 'original_args'):
                args = run_context.original_args()
                if hasattr(args, 'engine'):
                    engine = args.engine

                    # Ensure all processes have reached the end before shutting down
                    if hasattr(engine, "wait_for_everyone"):
                        engine.wait_for_everyone()
                        logger.debug("[DistributedCleaner] Synced all processes via Accelerate wait_for_everyone().")

                    # Safely close trackers (TensorBoard, WandB, etc.) and internal states
                    if hasattr(engine, "end_training"):
                        engine.end_training()
                        logger.info("[DistributedCleaner] Accelerate engine trackers closed successfully.")
        except Exception as e:
            logger.warning(f"[DistributedCleaner] Encountered an issue during Accelerate cleanup: {e}")

        # ==========================================
        # 2. Cleanup Native PyTorch Distributed (Double Insurance)
        # ==========================================
        try:
            # Check if distributed is available and the process group is still active
            if dist.is_available() and dist.is_initialized():
                dist.destroy_process_group()
                logger.info("[DistributedCleaner] Native torch.distributed process group destroyed.")
            else:
                logger.debug("[DistributedCleaner] Native torch.distributed is not initialized or already destroyed.")
        except Exception as e:
            logger.warning(f"[DistributedCleaner] Failed to destroy torch.distributed process group: {e}")

        logger.info("[DistributedCleaner] Cleanup finished.")