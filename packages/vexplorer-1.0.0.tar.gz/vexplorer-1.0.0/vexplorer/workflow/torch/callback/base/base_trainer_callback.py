

# from typing import Any as RunContext

from ....general.callback.base import BaseTrainerCallback as GeneralBaseTrainerCallback

from ...run.context.trainer import  BaseRunContext as RunContext


class BaseTrainerCallback(GeneralBaseTrainerCallback):
    r"""
    Base class for all callbacks.

    A callback is a self-contained program that can be reused across projects.
    It has access to the training state via :class:`RunContext` and can intervene 
    at specific points (hooks) during the training or evaluation execution.

    To create a custom callback, subclass this class and override any of the 
    methods below.

    Args:
        run_context (RunContext): The context object containing the current 
            state of the trainer (model, optimizer, epoch, batch data, etc.).

    Examples::

        >>> class PrintEpochCallback(BaseTrainerCallback):
        ...     def on_train_epoch_begin(self, run_context):
        ...         print(f"Starting epoch {run_context.cur_epoch_num}")
        ...
        ...     def on_train_epoch_end(self, run_context):
        ...         print(f"Finished epoch {run_context.cur_epoch_num}")

    .. note::
        All methods in this base class are no-ops (they do nothing) and are 
        meant to be overridden.
    """



