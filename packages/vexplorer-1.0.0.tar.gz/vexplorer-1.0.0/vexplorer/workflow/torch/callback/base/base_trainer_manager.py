# -*- coding: utf-8 -*-
import logging
from collections import defaultdict
from typing import List, Optional, Any, Dict
import torch.distributed as dist

from .base_trainer_callback import BaseTrainerCallback

logger = logging.getLogger(__name__)

from ....general.callback.base import BaseTrainerCallbackManager as GeneralBaseTrainerCallbackManager
from ....general.callback.base import BaseTrainerCallback as GeneralBaseTrainerCallback


class BaseTrainerCallbackManager(GeneralBaseTrainerCallbackManager):
    """
    [Core] A high-performance manager that orchestrates the execution of multiple callbacks.

    This class acts as a proxy that delegates hook calls to a list of registered callbacks.

    **Optimization Strategy:**
    Instead of iterating through all callbacks for every hook (which is slow if callbacks
    only implement a few methods), this manager analyzes the callback classes at
    initialization time. It builds an ``_execution_plan`` mapping each hook name to
    the subset of callbacks that actually override that method.

    This results in **zero-overhead** calls for empty base methods during tight loops
    (e.g., ``on_train_step_end``).

    Args:
        callbacks (List[BaseTrainerCallback], optional): Initial list of callbacks to register.
            Defaults to None.

    Attributes:
        callbacks (List[BaseTrainerCallback]): The list of currently registered callbacks.

    Example:
        >>> # Define a custom callback
        >>> class MyLogger(BaseTrainerCallback):
        ...     def on_train_begin(self, rc):
        ...         print("Training started!")
        ...
        >>> # Initialize manager
        >>> manager = BaseTrainerCallbackManager(callbacks=[MyLogger()])
        >>> # Trigger hook (rc is the RunContext/State object)
        >>> manager.on_train_begin(rc={"epoch": 0})
        Training started!
    """

    # Registry of supported hook names
    _HOOK_NAMES: List[str] = [
        'on_begin', 'on_end',
        'on_train_begin', 'on_train_end',
        'on_train_epoch_begin', 'on_train_epoch_end',
        'on_train_step_begin', 'on_train_step_end',
        'on_eval_begin', 'on_eval_end',
        'on_eval_epoch_begin', 'on_eval_epoch_end',
        'on_eval_step_begin', 'on_eval_step_end'
    ]

    def __init__(self,
                 callbacks: Optional[List[BaseTrainerCallback]] = None,
                 only_main_callback: Optional[list[str]] = None,
                 is_main: Optional[bool] = None,
                 ) -> None:
        super().__init__(callbacks=callbacks)

        if is_main is not None:
            self.is_main = is_main
        else:
            self.is_main = True
            if dist.is_initialized():
                rank = dist.get_rank()
                if rank != 0:
                    self.is_main = False
                logger.debug(f"Detected distributed rank: {rank}, is_main: {self.is_main}")
            else:
                logger.debug("Distributed not initialized during CallbackManager init.")

        self.only_main_callback = only_main_callback if only_main_callback else []
        logger.info(f'Initializing BaseTrainerCallbackManager with only_main_callback: {self.only_main_callback}')


    def add_callback(self,name, callback: BaseTrainerCallback, build = False) -> None:
        if not self.is_main and name in self.only_main_callback:
            logger.info(f'Skipping callback {name} because it is already a main callback')
            return
        if not isinstance(callback, BaseTrainerCallback) and not isinstance(callback, GeneralBaseTrainerCallback):
            raise TypeError(f"Callback {name}: {callback} must be a subclass of BaseTrainerCallback[general/torch]")
        self.callbacks.append(callback)
        if build:
            self._build_plan()



