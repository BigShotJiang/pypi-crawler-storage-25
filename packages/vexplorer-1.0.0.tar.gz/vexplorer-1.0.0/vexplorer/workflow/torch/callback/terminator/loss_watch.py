# -*- coding: utf-8 -*-
import math
import logging
import torch
from typing import List, Callable, Optional, Union, Any

from ..base import BaseTrainerCallback

logger = logging.getLogger(__name__)


class LossWatch(BaseTrainerCallback):
    """Callback to monitor training loss and stop training on anomalies or thresholds.

    This callback performs highly efficient, zero-overhead checks on the training loss
    at the end of every step. It uses closure-based checkers to avoid redundant
    conditional jumps during iteration.

    Supported checks:
    - NaN/Inf detection (enabled by default).
    - Upper/Lower bound thresholds (Greater, Greater-Equal, Less, Less-Equal).

    Args:
        g (float, optional): "Greater than" threshold. Stop if loss > g.
        ge (float, optional): "Greater than or equal" threshold. Stop if loss >= ge.
        l (float, optional): "Less than" threshold. Stop if loss < l.
            (Useful for detecting collapse or suspiciously low loss).
        le (float, optional): "Less than or equal" threshold. Stop if loss <= le.
        is_nan (bool): Whether to check for NaN values. Defaults to True.
        is_inf (bool): Whether to check for Infinite values. Defaults to True.
        **kwargs: Additional arguments passed to the base Callback.

    Example:
        >>> # Stop if loss explodes (NaN/Inf) or goes above 100.0
        >>> callback = LossWatch(g=100.0)
        >>> 
        >>> # Stop if loss vanishes below 1e-6 (Model collapse)
        >>> callback = LossWatch(l=1e-6)
    """

    def __init__(self,
                 g: Optional[float] = None,
                 ge: Optional[float] = None,
                 l: Optional[float] = None,
                 le: Optional[float] = None,
                 is_nan: bool = True,
                 is_inf: bool = True,
                 loss_name = "train_loss",
                 **kwargs):
        super().__init__(**kwargs)

        # List of checking functions. Only active checks are added here.
        self.checkers: List[Callable[[float], Optional[str]]] = []
        self.loss_name = loss_name

        # --- 1. NaN/Inf Checkers ---
        if is_nan:
            def _check_nan(val: float) -> Optional[str]:
                return "Loss is NaN" if math.isnan(val) else None
            self.checkers.append(_check_nan)

        if is_inf:
            def _check_inf(val: float) -> Optional[str]:
                return "Loss is Inf" if math.isinf(val) else None
            self.checkers.append(_check_inf)

        # --- 2. Threshold Checkers (Closure Capture) ---
        # The values (l, le, g, ge) are captured inside the closure,
        # avoiding attribute lookups (self.l) during the hot training loop.

        if l is not None:
            def _check_l(val: float) -> Optional[str]:
                return f"Loss {val:.6g} < {l} (limit 'l')" if val < l else None
            self.checkers.append(_check_l)

        if le is not None:
            def _check_le(val: float) -> Optional[str]:
                return f"Loss {val:.6g} <= {le} (limit 'le')" if val <= le else None
            self.checkers.append(_check_le)

        if g is not None:
            def _check_g(val: float) -> Optional[str]:
                return f"Loss {val:.6g} > {g} (limit 'g')" if val > g else None
            self.checkers.append(_check_g)

        if ge is not None:
            def _check_ge(val: float) -> Optional[str]:
                return f"Loss {val:.6g} >= {ge} (limit 'ge')" if val >= ge else None
            self.checkers.append(_check_ge)

        logger.info(f"[LossWatch] Initialized with {len(self.checkers)} active checkers.")


    def on_train_step_end(self, run_context: Any) -> None:
        """Checks the loss at the end of a training step.

        Args:
            run_context (Runner): Context object containing training state.
                Must provide `original_args()` which returns an object with loss_name default `train_loss`.
        """
        # 1. Retrieve raw loss
        # Assuming run_context matches your specific framework API
        args = run_context.original_args()
        raw_loss = getattr(args, self.loss_name, None)

        if raw_loss is None:
            return

        # 2. Convert to python float efficiently
        try:
            # loss = float(raw_loss)
            if isinstance(raw_loss, torch.Tensor):
                # .item() is faster and safer for tensors than float()
                loss = raw_loss.item()
            else:
                loss = float(raw_loss)
        except (ValueError, TypeError):
            # Fail silently on non-numeric types (e.g., None, String)
            return

        # 3. Fast Iteration
        # Only iterates through the configured checks (Complexity: O(num_active_checks))
        for check_fn in self.checkers:
            error_msg = check_fn(loss)
            if error_msg:
                logger.error(f"[LossWatch] Anomalous loss detected: {error_msg}")
                logger.warning("[LossWatch] Requesting training stop...")
                run_context.request_stop()
                break



