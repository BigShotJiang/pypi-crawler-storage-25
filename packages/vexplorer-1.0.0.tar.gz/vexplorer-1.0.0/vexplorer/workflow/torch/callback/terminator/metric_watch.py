import logging
from typing import Any

from ..utils.mixin.metric_mixin import MetricMonitorMixin
from ..base import BaseTrainerCallback

logger = logging.getLogger(__name__)


class MetricWatch(BaseTrainerCallback, MetricMonitorMixin):
    """
    Stops training when a monitored metric has stopped improving.

    Args:
        monitor (str): Metric name to monitor.
        patience (int): Number of checks with no improvement after which training will be stopped.
        mode (str): 'min' or 'max'.
        min_delta (float): Minimum change in the monitored quantity to qualify as an improvement.

    Example:
        >>> callback = MetricWatch(monitor="val_loss", patience=3, min_delta=1e-4)
    """

    def __init__(self,
                 monitor: str,
                 patience: int = 5,
                 mode: str = "min",
                 min_delta: float = 0.0):
        self.monitor = monitor
        self.patience = patience
        self.mode = mode
        self.min_delta = min_delta

        self.best_score = float('inf') if mode == 'min' else float('-inf')
        self.wait_count = 0

    def on_eval_epoch_end(self, run_context: Any) -> None:
        current_score = self.get_synced_metric(run_context, self.monitor)

        # If metric is missing, do nothing (do not increment wait_count)
        if current_score is None:
            return

        is_improvement = False
        if self.mode == "min":
            if current_score < (self.best_score - self.min_delta):
                is_improvement = True
        else:
            if current_score > (self.best_score + self.min_delta):
                is_improvement = True

        # engine = run_context.original_args().engine
        # is_main = getattr(engine, "is_main", True)

        if is_improvement:
            self.best_score = current_score
            self.wait_count = 0
            # if is_main:
            #     logger.debug(f"[EarlyStopping] Improvement found: {current_score:.4f}. Reset patience.")
        else:
            self.wait_count += 1
            # if is_main:
            #     logger.info(f"[EarlyStopping] No improvement. Patience: {self.wait_count}/{self.patience}. Best: {self.best_score:.4f}")

        if self.wait_count >= self.patience:
            # if is_main:
            #     logger.warning(f"[EarlyStopping] Patience limit reached ({self.patience}). Requesting stop.")

            # Ensure request_stop exists
            if hasattr(run_context, "request_stop"):
                run_context.request_stop()
            else:
                logger.error("run_context does not have 'request_stop' method.")



