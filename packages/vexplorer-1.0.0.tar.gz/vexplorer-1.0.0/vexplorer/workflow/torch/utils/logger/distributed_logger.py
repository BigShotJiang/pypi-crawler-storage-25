# -*- coding: utf-8 -*-
r"""
Distributed Logging Utility
===========================

This module provides a unified interface for configuring logging in distributed
environments (e.g., DDP, Accelerate). It supports automatic rank detection,
colorful console output, and optional file logging.

The logging levels can be specified using either standard integer constants
(e.g., ``logging.INFO``) or case-insensitive strings (e.g., ``"info"``, ``"DEBUG"``).

Example:
    .. code-block:: python

        import setup_distributed_logging
        import logging

        # 1. Using Integer Constants
        logger = setup_distributed_logging(main_process_level=logging.INFO)

        # 2. Using Strings (Case-insensitive)
        logger = setup_distributed_logging(
            main_process_level="debug",
            worker_process_level="error"
        )

        # 3. Advanced usage (Stdout + File)
        logger = setup_distributed_logging(
            output_file="logs/experiment_v1.log",
            color_console=True
        )

        logger.info("Training started...")
"""

import logging
import os
import sys
from pathlib import Path
from typing import Optional, Union, Dict, Tuple

__all__ = ["DistributedFormatter", "setup_distributed_logging", "LOG_LEVEL_MAP"]

# Mapping string representations to logging constants
LOG_LEVEL_MAP: Dict[str, int] = {
    "debug": logging.DEBUG,
    "info": logging.INFO,
    "warning": logging.WARNING,
    "warn": logging.WARNING,  # Common alias
    "error": logging.ERROR,
    "critical": logging.CRITICAL,
    "fatal": logging.CRITICAL,  # Common alias
}


class DistributedFormatter(logging.Formatter):
    r"""A logging formatter that handles distributed rank info and ANSI colors.

    This formatter automatically injects the distributed rank into the log message
    and optionally applies ANSI color codes based on the log severity level.

    Args:
        use_color (bool): If ``True``, applies ANSI colors to the log lines.
            Usually set to ``True`` for console handlers and ``False`` for file handlers.
            Default: ``True``.


    """

    # ANSI Escape Codes
    _GREY = "\x1b[38;20m"
    _GREEN = "\x1b[32;20m"
    _YELLOW = "\x1b[33;20m"
    _RED = "\x1b[31;20m"
    _BOLD_RED = "\x1b[31;1m"
    _RESET = "\x1b[0m"

    FORMATS: Dict[int, str] = {
        logging.DEBUG: _GREY,
        logging.INFO: _GREEN,
        logging.WARNING: _YELLOW,
        logging.ERROR: _RED,
        logging.CRITICAL: _BOLD_RED
    }
    """
    FORMATS (Dict[int, str]): Mapping of log levels to ANSI color codes.
    """

    def __init__(self, use_color: bool = True):
        super().__init__()
        self.use_color = use_color

    def format(self, record: logging.LogRecord) -> str:
        r"""Formats the specified record as text.

        The format includes timestamp, rank (if distributed), level, logger name,
        and the message.

        Args:
            record (logging.LogRecord): The log record to format.

        Returns:
            str: The formatted log string.
        """
        # 1. Detect Rank explicitly at runtime
        # We fetch this every time to ensure it works even if env vars change
        # (though they rarely do during runtime).
        rank = os.environ.get("RANK", "0")

        # 2. Define the base format structure
        # Syntax: Time | [Rank] | Level (aligned) | Name: Message
        log_fmt = f"%(asctime)s | [Rank {rank}] | %(levelname)-8s | %(name)s: %(message)s"
        date_fmt = "%Y-%m-%d %H:%M:%S"

        # 3. Apply Color if requested
        if self.use_color:
            color_code = self.FORMATS.get(record.levelno, self._RESET)
            # Wrap the entire format string in color codes
            format_str = f"{color_code}{log_fmt}{self._RESET}"
        else:
            format_str = log_fmt

        # 4. Use the parent class's logic to create the final string
        # We instantiate a temporary standard Formatter to handle the standard % substitutions
        formatter = logging.Formatter(format_str, datefmt=date_fmt)
        return formatter.format(record)


def _to_level(level: Union[int, str]) -> int:
    """Helper to convert string level to logging integer constant."""
    if isinstance(level, int):
        return level
    if isinstance(level, str):
        return LOG_LEVEL_MAP.get(level.lower(), logging.INFO)
    return logging.INFO


def setup_distributed_logging(
        main_process_level: Union[int, str] = logging.INFO,
        worker_process_level: Union[int, str] = logging.WARNING,
        output_file: Optional[Union[str, Path]] = None,
        color_console: bool = True
) -> Tuple[logging.Logger, int]:
    r"""Configures the global logging system for the application.

    This function sets up the root logger with appropriate handlers. It is designed
    to be robust in distributed settings (DDP), ensuring that non-main processes
    do not flood the output.

    Flow:
        1. Determines execution rank from environment variables.
        2. Sets the Root Logger level based on rank (Master=INFO, Worker=WARNING).
        3. Clears any existing handlers to prevent duplicate logs.
        4. Attaches a **StreamHandler** (Stdout) with optional color.
        5. Optionally attaches a **FileHandler** (if ``output_file`` is provided) without color.

    Args:
        main_process_level (int or str): Logging level for the main process (Rank 0).
            Accepts integer constants (e.g., ``logging.INFO``) or case-insensitive
            strings (e.g., ``"debug"``, ``"INFO"``).
            Default: ``logging.INFO``.
        worker_process_level (int or str): Logging level for non-main processes (Rank > 0).
            Accepts integer constants or strings.
            Default: ``logging.WARNING``.
        output_file (str or Path, optional): If provided, logs will also be written
            to this file. The directory will be created if it does not exist.
            **Note**: File logs always strip ANSI colors for readability.
            Default: ``None``.
        color_console (bool): Whether to enable ANSI coloring for the console output.
            Default: ``True``.

    Returns:
        logging.Logger: The configured root logger instance.
        int: The root logger level.

    Example:
        >>> # Use strings for convenience
        >>> logger, logger_level = setup_distributed_logging(main_process_level="debug", output_file="logs/train.log")
    """
    # 1. Detect Rank
    rank = int(os.environ.get("RANK", "0"))

    # 2. Determine Global Level (Convert string to int if necessary)
    target_level = main_process_level if rank == 0 else worker_process_level
    current_level = _to_level(target_level)

    # 3. Configure Root Logger
    root_logger = logging.getLogger()
    root_logger.setLevel(current_level)

    # Clean existing handlers (important for notebook restarts or duplicate calls)
    if root_logger.hasHandlers():
        root_logger.handlers.clear()

    # ------------------------------------------------------------------
    # Handler 1: Console (Stdout)
    # ------------------------------------------------------------------
    console_handler = logging.StreamHandler(sys.stdout)
    console_handler.setLevel(current_level)

    # Use our custom formatter, enabling color based on user preference
    console_formatter = DistributedFormatter(use_color=color_console)
    console_handler.setFormatter(console_formatter)

    root_logger.addHandler(console_handler)

    # ------------------------------------------------------------------
    # Handler 2: File (Optional)
    # ------------------------------------------------------------------
    if output_file is not None and rank == 0:
        # Only Rank 0 usually writes to file to avoid write contention/corruption
        # Unless you specifically want separate log files per rank (advanced case)
        output_path = Path(output_file)

        # Ensure directory exists
        try:
            output_path.parent.mkdir(parents=True, exist_ok=True)
        except OSError as e:
            print(f"Warning: Could not create log directory {output_path.parent}. File logging disabled. Error: {e}")
        else:
            file_handler = logging.FileHandler(output_path, mode='a', encoding='utf-8')
            file_handler.setLevel(current_level)

            # File logs should NEVER have color codes (they look like garbage text)
            file_formatter = DistributedFormatter(use_color=False)
            file_handler.setFormatter(file_formatter)

            root_logger.addHandler(file_handler)

    # ------------------------------------------------------------------
    # 3rd Party Library Noise Control
    # ------------------------------------------------------------------
    # Silence chatty libraries
    # current_level = logging.WARNING
    logging.getLogger("PIL").setLevel(current_level)
    logging.getLogger("matplotlib").setLevel(current_level)
    logging.getLogger("urllib3").setLevel(current_level)

    return root_logger, current_level

class DistributedLoggerManager():

    def __init__(self,
             main_process_level: Union[int, str] = logging.INFO,
             worker_process_level: Union[int, str] = logging.WARNING,
             output_file: Optional[Union[str, Path]] = None,
             color_console: bool = True
        ):
        self.root_logger, self.current_level = setup_distributed_logging(
            main_process_level=main_process_level,
            worker_process_level=worker_process_level,
            output_file=output_file,
            color_console=color_console
        )

    def get_current_log_level(self):
        return self.current_level

