# -*- coding: utf-8 -*-

import logging
import torch

try:
    import torch_npu
except ImportError:
    pass

from typing import Optional, Union, Dict, Any
from .torch_seeder import seed_base_everything

logger = logging.getLogger(__name__)


NPU_CONFIGS: Dict[str, Any] = {
    # allow_internal_format SHOULD GENERALLY BE TRUE.
    # Setting it to False forces NPU to constantly convert between PyTorch ND format and
    # NPU's native NZ block-sparse formats for every Conv/Linear layer, causing ~400s step times.
    # While False temporarily circumvents FSDP's parameter flattening bugs, it makes the NPU 
    # astronomically slow. We must find another way to fix FSDP, or just use DDP instead.
    "fastest_dynamic": {"allow_internal_format": True, "jit_compile": False},
    # torchair: For use with torch.compile(backend=torchair.get_npu_backend()).
    # Uses GE graph engine for static/dynamic shape compilation with full
    # backward support (AOTAutograd).  Confirmed supported for training.
    "torchair":        {"allow_internal_format": True, "jit_compile": False},
    # DEPRECATED on NPU: jit_compile=True triggers Conv3D depthwise tiling bugs
    # and SDPA format-casting errors.  Keep for CUDA compatibility only.
    "fastest_fixed":   {"allow_internal_format": True, "jit_compile": True},
    "reproducible":    {"allow_internal_format": True, "jit_compile": False},
    "debug":           {"allow_internal_format": True, "jit_compile": False},
    "default":         {"allow_internal_format": True, "jit_compile": False},
}


def apply_npu_config(mode: str = "default") -> str:
    """Apply NPU backend flags equivalent to apply_cudnn_config for CUDA.

    Args:
        mode: One of 'fastest_dynamic', 'fastest_fixed', 'reproducible',
              'debug', 'default'.

    Returns:
        The resolved mode string.
    """
    if not (hasattr(torch, 'npu') and torch.npu.is_available()):
        logger.debug("[NPU] NPU not available, skipping NPU config.")
        return mode

    if mode not in NPU_CONFIGS:
        logger.warning(
            "[apply_npu_config] Unknown mode '%s', using 'default'.", mode
        )
        mode = "default"

    cfg = NPU_CONFIGS[mode]

    try:
        # Allow NPU-internal NZ tensor format for faster matmul/conv kernels.
        torch.npu.config.allow_internal_format = cfg["allow_internal_format"]
    except AttributeError:
        logger.debug("[NPU] allow_internal_format not supported on this version.")

    try:
        # Controls whether op kernels are JIT-compiled on first use.
        torch_npu.npu.set_compile_mode(jit_compile=cfg["jit_compile"])
    except Exception:
        logger.debug("[NPU] set_compile_mode not supported on this version.")

    logger.info(
        "[NPU] mode='%s' | allow_internal_format=%s | jit_compile=%s",
        mode, cfg["allow_internal_format"], cfg["jit_compile"],
    )
    return mode


def seed_npu_everything(seed: Optional[Union[int, str]] = 42) -> int:
    """Sets the seed for all random number generators (Python, NumPy, PyTorch).

    Args:
        seed (int | str | None): The seed value. Defaults to 42.

    Returns:
        int: The actual integer seed used.
    """

    safe_seed = seed_base_everything(seed)

    if hasattr(torch, 'npu') and torch.npu.is_available():
        torch.npu.manual_seed(safe_seed)
        torch.npu.manual_seed_all(safe_seed)
    else:
        logger.warning(f"[seed_npu_everything] No npu available in {safe_seed}")

    logger.info(f"[seed_npu_everything] Global seed locked at {safe_seed}")
    return safe_seed



