# -*- coding: utf-8 -*-
import os
import random
import time
import hashlib
import numbers
import logging
import numpy as np
import torch
from typing import Optional, Union, Dict, Any

logger = logging.getLogger(__name__)

try:
    from .....core.general.constant.numeric import MAX_SAFE_INT
except:
    MAX_SAFE_INT: int = 2**31 - 1
    r"""The maximum safe integer ensuring 32-bit compatibility.
    
    Value is :math:`2^{31} - 1` (2147483647).
    This constant is used for random seeds to ensure compatibility across both
    signed and unsigned 32-bit environments.
    """


def _clamp_safe_seed(n: Union[int, float]) -> int:
    """Clamps the input number to a safe integer range for seeding.

    Args:
        n (int | float): Input number.

    Returns:
        int: A safe integer in [0, MAX_SAFE_INT).
    """
    return abs(int(n)) % MAX_SAFE_INT

def get_time_seed() -> int:
    """Generates a random seed based on the current system time.

    Returns:
        int: A time-based random seed.
    """
    try:
        # Python 3.7+ supports nanoseconds for higher precision
        seed = time.time_ns()
    except AttributeError:
        # Fallback for older python versions
        seed = int(time.time() * 1_000_000)
    return _clamp_safe_seed(seed)

def get_smart_seed(seed_input: Optional[Union[int, float, str]] = None) -> int:
    """Intelligently converts various input types into a valid random seed.

    Rules:
    1. None -> Generates a time-based random seed.
    2. Number -> Clamps to safe range.
    3. Numeric String ("123") -> Converts to float then clamps.
    4. Text String ("experiment_1") -> Deterministic Hash conversion.

    Args:
        seed_input (int | float | str | None): The input to convert.

    Returns:
        int: A valid seed integer.

    Example:
        >>> get_smart_seed(42)
        42
        >>> get_smart_seed("123.45")
        123
        >>> get_smart_seed("my_experiment")
        294823... (Hash value)
    """
    # 1. Handle None
    if seed_input is None:
        return get_time_seed()

    try:
        # 2. Handle Numbers
        if isinstance(seed_input, numbers.Number):
            return _clamp_safe_seed(seed_input)

        # 3. Handle Strings
        if isinstance(seed_input, str):
            if "time" in seed_input:
                return get_time_seed()

            # 3.1 Check if it is a numeric string (e.g., "123", "-12.3")
            # Remove negative sign and one decimal point to check digits
            clean_str = seed_input.lstrip('-').replace('.', '', 1)
            if clean_str.isdigit():
                return _clamp_safe_seed(float(seed_input))

            # 3.2 Text string -> Deterministic Hash
            # hashlib is stable across runs (unlike python's hash())
            hash_object = hashlib.sha256(seed_input.encode('utf-8'))
            hex_dig = hash_object.hexdigest()
            # Convert hex to int and clamp
            return _clamp_safe_seed(int(hex_dig, 16))

        # 4. Unsupported types
        raise TypeError(f"Unsupported type: {type(seed_input)}")

    except Exception as e:
        fallback = get_time_seed()
        logger.warning(f"[get_smart_seed] Input '{seed_input}' is invalid ({e}). Fallback to time-seed: {fallback}")
        return fallback

def seed_base_everything(seed: Optional[Union[int, str]] = 42) -> int:
    """Sets the seed for all random number generators (Python, NumPy, PyTorch).

    Args:
        seed (int | str | None): The seed value. Defaults to 42.

    Returns:
        int: The actual integer seed used.
    """
    # 1. Resolve seed
    safe_seed = get_smart_seed(seed)

    # 2. Set Basic Libs
    random.seed(safe_seed)
    os.environ['PYTHONHASHSEED'] = str(safe_seed)
    np.random.seed(safe_seed)

    # 3. Set PyTorch
    torch.manual_seed(safe_seed)

    logger.info(f"[seed_base_everything] Global seed locked at {safe_seed}")
    return safe_seed


