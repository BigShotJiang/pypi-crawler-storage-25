# -*- coding: utf-8 -*-

import logging
import torch
from typing import Optional, Union, Dict, Any
from .torch_seeder import seed_base_everything

logger = logging.getLogger(__name__)


CUDNN_CONFIGS: Dict[str, Dict[str, bool]] = {
    "fastest_dynamic": {"benchmark": False, "deterministic": False},
    "fastest_fixed":   {"benchmark": True,  "deterministic": False},
    "reproducible":    {"benchmark": False, "deterministic": True},
    "debug":           {"benchmark": False, "deterministic": True},
    "default":         {"benchmark": False, "deterministic": False}
}


def apply_cudnn_config(reproducibility_mode: str = "default") -> str:
    """Applies CuDNN benchmark and deterministic flags.

    Args:
        reproducibility_mode (str): Configuration reproducibility_mode name.
            Options: 'fastest_dynamic', 'fastest_fixed', 'reproducible', 'debug', 'default'.

    Returns:
        str: Configuration reproducibility_mode name.

    """
    if reproducibility_mode not in CUDNN_CONFIGS:
        logger.warning(f"[apply_cudnn_config] Unknown CuDNN reproducibility_mode '{reproducibility_mode}', using 'default'.")
        reproducibility_mode = "default"

    config = CUDNN_CONFIGS[reproducibility_mode]

    if torch.cuda.is_available():
        torch.backends.cudnn.benchmark = config["benchmark"]
        torch.backends.cudnn.deterministic = config["deterministic"]
        logger.info(f"[CuDNN] reproducibility_mode: '{reproducibility_mode}' | Benchmark: {config['benchmark']} | Deterministic: {config['deterministic']}")
    else:
        logger.debug("[CuDNN] CUDA not available, skipping CuDNN config.")

    return reproducibility_mode


def seed_cuda_everything(seed: Optional[Union[int, str]] = 42) -> int:
    """Sets the seed for all random number generators (Python, NumPy, PyTorch).

    Args:
        seed (int | str | None): The seed value. Defaults to 42.

    Returns:
        int: The actual integer seed used.
    """

    safe_seed = seed_base_everything(seed)

    if torch.cuda.is_available():
        torch.cuda.manual_seed(safe_seed)
        torch.cuda.manual_seed_all(safe_seed)
    else:
        logger.warning(f"[seed_cuda_everything] CUDA not available, using default seed.")

    logger.info(f"[seed_cuda_everything] Global seed locked at {safe_seed}")
    return safe_seed



