# -*- coding: utf-8 -*-
import logging
import torch
from typing import Optional, Union, Dict, Any

logger = logging.getLogger(__name__)

try:
    from .....core.general.constant.numeric import MAX_SAFE_INT
except:
    MAX_SAFE_INT: int = 2**31 - 1
    r"""The maximum safe integer ensuring 32-bit compatibility.
    
    Value is :math:`2^{31} - 1` (2147483647).
    This constant is used for random seeds to ensure compatibility across both
    signed and unsigned 32-bit environments.
    """

from .torch_setup_cuda import apply_cudnn_config
from .torch_seeder import seed_base_everything, get_smart_seed
from .torch_setup_cuda import seed_cuda_everything
from .torch_setup_npu import seed_npu_everything, apply_npu_config



class ReproducibilityManager:
    """
    A manager class to handle random state initialization and management.

    Args:
        seed (int | str | None): Initial seed.
        mode (str): CuDNN or other optimization mode.
    """
    def __init__(
            self,
             seed: Optional[Union[int, str]] = 42,
             reproducibility_mode: str = "default"
        ):

        if torch.cuda.is_available():
            self.seed = seed_cuda_everything(seed=seed, )
            self.reproducibility_mode = apply_cudnn_config(reproducibility_mode=reproducibility_mode)
        elif hasattr(torch, 'npu') and torch.npu.is_available():
            self.seed = seed_npu_everything(seed=seed, )
            self.reproducibility_mode = apply_npu_config(reproducibility_mode)
        else:
            self.seed = seed_base_everything(seed=seed, )
            self.reproducibility_mode = reproducibility_mode

    def get_seed_with_safe_offset(self, offset: int = 1) -> int:
        """Returns a derived seed based on the base seed and an offset.

        Uses modulo arithmetic to ensure the result is always within safe bounds
        and deterministic.

        Args:
            offset (int): The offset to add to the base seed.

        Returns:
            int: A new valid seed.
        """
        # Logic: (Base + Offset) % Max -> Always safe, handles overflow automatically
        return (self.seed + offset) % MAX_SAFE_INT

    def get_seed(self) -> int:
        """Returns the current base seed."""
        return self.seed

    def get_reproducibility_mode(self) -> str:
        """Returns the current reproducibility mode."""
        return self.reproducibility_mode

    def get_generator(self, seed: Optional[Union[int, str]] = None) -> torch.Generator:
        """Creates a local PyTorch Generator (isolated from global state).

        Args:
            seed (int | str | None, optional): Specific seed for this generator.
                If None, uses the manager's base seed.

        Returns:
            torch.Generator: An initialized generator.
        """
        if seed is None:
            target_seed = self.seed
        else:
            target_seed = get_smart_seed(seed)

        g = torch.Generator()
        g.manual_seed(target_seed)
        return g





