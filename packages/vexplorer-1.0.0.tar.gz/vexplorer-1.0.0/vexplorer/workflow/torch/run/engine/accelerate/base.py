# -*- coding: utf-8 -*-
import os
import contextlib
import logging
from typing import Any, Dict, List, Optional, Union, Callable, ContextManager

import torch
import torch.distributed as dist
import torch.nn as nn
from accelerate import Accelerator, DistributedDataParallelKwargs
from accelerate import load_checkpoint_in_model
from accelerate.utils import DistributedType
from accelerate.utils.operations import gather_object
from safetensors.torch import load_file


logger = logging.getLogger(__name__)


class AccelerateEngine:
    r"""
    A unified wrapper for HuggingFace Accelerate to simplify distributed training workflows.

    This engine encapsulates device placement, gradient synchronization, mixed precision,
    and distributed gathering strategies. It aims to provide a PyTorch-like interface
    while leveraging Accelerate's backend handling.

    Supports three distributed strategies via Accelerate:

    - **DDP** (default): ``DistributedDataParallel`` — standard data parallelism.
    - **FSDP**: ``FullyShardedDataParallel`` — parameter sharding across ranks.
      Requires ``acc_fsdp_params`` or an Accelerate YAML with ``distributed_type: FSDP``.
    - **DeepSpeed**: ZeRO Stage 1/2/3 — gradient/optimizer/parameter partitioning.
      Requires ``acc_deepspeed_params`` or an Accelerate YAML with ``distributed_type: DEEPSPEED``.

    Both FSDP and DeepSpeed work on NVIDIA CUDA (NCCL) and Huawei Ascend NPU (HCCL)
    backends. The communication backend is auto-selected by ``torch.distributed``
    based on available hardware (``torch.cuda`` vs ``torch_npu``).

    Args:

        gather_in_train (str, optional): Strategy for gathering tensors during training loops.
            Options: ``"gather_for_metrics"``, ``"gather_for_metrics_use_object"``,
            ``"gather"``, ``"gather_object"``. Defaults to ``"gather_for_metrics"``.
        gather_in_eval (str, optional): Strategy for gathering tensors during evaluation loops.
            Defaults to ``"gather_for_metrics"``.
        acc_init_params (Dict[str, Any], optional): Parameters passed directly to
            :class:`~accelerate.Accelerator`. Defaults to None.
        acc_ddp_params (Dict[str, Any], optional): Parameters passed to
            :class:`~accelerate.DistributedDataParallelKwargs`.
            Common usage includes ``{"find_unused_parameters": True}``. Defaults to None.
        acc_fsdp_params (Dict[str, Any], optional): Parameters passed to
            :class:`~accelerate.FullyShardedDataParallelPlugin`. Key options:
            ``sharding_strategy`` (``"FULL_SHARD"``, ``"SHARD_GRAD_OP"``, ``"NO_SHARD"``),
            ``backward_prefetch`` (``"BACKWARD_PRE"``, ``"BACKWARD_POST"``),
            ``cpu_offload`` (bool), ``use_orig_params`` (bool, default True for torch.compile).
            Mutually exclusive with ``acc_deepspeed_params``. Defaults to None.
        acc_deepspeed_params (Dict[str, Any], optional): Parameters passed to
            :class:`~accelerate.DeepSpeedPlugin`. Typically includes
            ``deepspeed_config_file`` path and ``zero3_init_flag``.
            Mutually exclusive with ``acc_fsdp_params``. Defaults to None.

    Attributes:

        accelerator (Accelerator): The underlying Accelerator instance.

    Example:

        >>> # DDP (default)
        >>> engine = AccelerateEngine(acc_ddp_params={"find_unused_parameters": True})
        >>>
        >>> # FSDP
        >>> engine = AccelerateEngine(acc_fsdp_params={
        ...     "sharding_strategy": "FULL_SHARD",
        ...     "use_orig_params": True,
        ... })
        >>>
        >>> # DeepSpeed ZeRO-3
        >>> engine = AccelerateEngine(acc_deepspeed_params={
        ...     "deepspeed_config_file": "ds_z3_config.json",
        ...     "zero3_init_flag": True,
        ... })
    """

    def __init__(
            self,
            gather_in_train: str = "gather_for_metrics",
            gather_in_eval: str = "gather_for_metrics",
            acc_init_params: Optional[Dict[str, Any]] = None,
            acc_ddp_params: Optional[Dict[str, Any]] = None,
            acc_fsdp_params: Optional[Dict[str, Any]] = None,
            acc_deepspeed_params: Optional[Dict[str, Any]] = None,
    ) -> None:

        # 0. Mutual exclusion check
        active_strategies = []
        if acc_ddp_params:
            active_strategies.append("acc_ddp_params")
        if acc_fsdp_params:
            active_strategies.append("acc_fsdp_params")
        if acc_deepspeed_params:
            active_strategies.append("acc_deepspeed_params")
        if len(active_strategies) > 1:
            raise ValueError(
                f"Only one distributed strategy can be configured at a time, "
                f"but got: {active_strategies}. Use the Accelerate YAML config "
                f"(distributed_type) to select the strategy instead of passing "
                f"multiple kwargs."
            )

        # 1. Strategy Configuration
        self._gather_methods: Dict[str, Callable] = {
            "gather_for_metrics": self._gather_for_metrics,
            "gather_for_metrics_use_object": self._gather_for_metrics_use_object,
            "gather": self.gather,
            "gather_object": self.gather_object,
        }

        if gather_in_train not in self._gather_methods:
            raise ValueError(f"Invalid gather_in_train strategy: '{gather_in_train}'. "
                             f"Available: {list(self._gather_methods.keys())}")

        if gather_in_eval not in self._gather_methods:
            raise ValueError(f"Invalid gather_in_eval strategy: '{gather_in_eval}'. "
                             f"Available: {list(self._gather_methods.keys())}")

        self._gather_in_train_fn = self._gather_methods[gather_in_train]
        self._gather_in_eval_fn = self._gather_methods[gather_in_eval]

        # 2. Distributed Strategy & Accelerator Initialization
        kwargs_handlers = []
        fsdp_plugin = None
        deepspeed_plugin = None

        if acc_ddp_params:
            ddp_kwargs = DistributedDataParallelKwargs(**acc_ddp_params)
            kwargs_handlers.append(ddp_kwargs)

        if acc_fsdp_params:
            from accelerate import FullyShardedDataParallelPlugin
            from torch.distributed.fsdp.fully_sharded_data_parallel import (
                ShardingStrategy, BackwardPrefetch, CPUOffload,
            )
            fsdp_params = dict(acc_fsdp_params)  # shallow copy

            # Map string sharding_strategy to enum
            ss = fsdp_params.pop("sharding_strategy", "FULL_SHARD")
            if isinstance(ss, str):
                ss = ShardingStrategy[ss]

            # Map string backward_prefetch to enum
            bp = fsdp_params.pop("backward_prefetch", "BACKWARD_PRE")
            if isinstance(bp, str):
                bp = BackwardPrefetch[bp]

            # CPU offload
            cpu_offload_flag = fsdp_params.pop("cpu_offload", False)

            # use_orig_params defaults to True for torch.compile compatibility
            use_orig = fsdp_params.pop("use_orig_params", True)

            fsdp_plugin = FullyShardedDataParallelPlugin(
                sharding_strategy=ss,
                backward_prefetch=bp,
                cpu_offload=CPUOffload(offload_params=cpu_offload_flag),
                use_orig_params=use_orig,
                **fsdp_params,
            )

        if acc_deepspeed_params:
            from accelerate import DeepSpeedPlugin
            deepspeed_plugin = DeepSpeedPlugin(**acc_deepspeed_params)

        if acc_init_params is None:
            acc_init_params = {}

        self.accelerator = Accelerator(
            kwargs_handlers=kwargs_handlers,
            fsdp_plugin=fsdp_plugin,
            deepspeed_plugin=deepspeed_plugin,
            **acc_init_params
        )
        self.scaler = self.accelerator.scaler

        # 3. Logging
        if self.is_main:
            logger.info(
                f"[AccelerateEngine] Initialized on {self.device} "
                f"with {self.all_num_processes} processes, "
                f"strategy={self.distributed_strategy}."
            )


    # =========================================================================
    # Properties (PyTorch Style Accessors)
    # =========================================================================
    def reduce(self, tensor, reduction="sum", scale=1.0):
        return self.accelerator.reduce(tensor, reduction=reduction, scale=scale)

    @property
    def distributed_strategy(self) -> str:
        """Returns the active distributed strategy as a string.

        Returns one of: ``"ddp"``, ``"fsdp"``, ``"deepspeed"``, ``"no"``.
        """
        dt = self.accelerator.distributed_type
        _MAP = {
            DistributedType.MULTI_GPU: "ddp",
            DistributedType.MULTI_NPU: "ddp",
            DistributedType.MULTI_CPU: "ddp",
            DistributedType.FSDP: "fsdp",
            DistributedType.DEEPSPEED: "deepspeed",
            DistributedType.NO: "no",
        }
        return _MAP.get(dt, "no")

    @property
    def device(self) -> torch.device:
        """Returns the device associated with the current process."""
        return self.accelerator.device

    @property
    def is_main(self) -> bool:
        """Returns True if this is the global main process."""
        return self.accelerator.is_main_process

    @property
    def is_local_main(self) -> bool:
        """Returns True if this is the main process on the current node."""
        return self.accelerator.is_local_main_process

    @property
    def process_index(self) -> int:
        """Returns the index of the current process (rank)."""
        return self.accelerator.process_index

    @property
    def all_num_processes(self) -> int:
        """Returns the total number of processes across all nodes."""
        return self.accelerator.num_processes

    # =========================================================================
    # Core Training Utilities
    # =========================================================================

    def prepare(self, *args) -> Any:
        r"""
        Prepares models, optimizers, and dataloaders for distributed execution.

        Wraps the passed objects with DDP/FSDP/DeepSpeed wrappers depending on
        the active distributed strategy and moves them to the correct device.

        .. note::
            For FSDP: models should NOT be manually ``.to(device)`` before calling
            this method — FSDP handles device placement during wrapping.

            For DeepSpeed: same as FSDP — the engine handles device placement.

        Args:

            *args: Comma-separated list of objects (``torch.nn.Module``,
                ``torch.optim.Optimizer``, ``torch.utils.data.DataLoader``).

        Returns:

            Any: The prepared objects in the same order.
        """
        return self.accelerator.prepare(*args)

    def backward(self, loss: torch.Tensor, **kwargs) -> None:
        r"""
        Backward propagates the loss.

        Handles mixed precision scaling automatically if enabled.

        Args:

            loss (torch.Tensor): The computed loss tensor.
        """
        self.accelerator.backward(loss, **kwargs)

    def wait_for_everyone(self) -> None:
        r"""
        Blocks execution until all processes have reached this point (Barrier).
        """
        self.accelerator.wait_for_everyone()

    def get_null_context(self) -> ContextManager:
        r"""
        Returns a null context manager. Useful for conditional context application.
        """
        return contextlib.nullcontext()

    def get_nosync_context(self, network: nn.Module) -> ContextManager:
        r"""
        Returns a context manager that disables gradient synchronization.

        Useful for gradient accumulation to reduce communication overhead.

        Args:

            network (torch.nn.Module): The DDP-wrapped model.
        """
        return self.accelerator.no_sync(network)

    def print(self, msg: str) -> None:
        r"""
        Prints the message only on the main process.

        Args:

            msg (str): The message to print.
        """
        self.accelerator.print(msg)

    # =========================================================================
    # Model IO (Saving & Loading)
    # =========================================================================

    def save_model(
            self,
            model: nn.Module,
            save_directory: str,
            max_shard_size: str = "10GB",
            safe_serialization: bool = True
    ) -> None:
        r"""
        Saves the model weights to the specified directory.

        Automatically handles:
        1. Unwrapping DDP/FSDP models.
        2. Sharding large checkpoints (e.g., splitting into multiple files).
        3. Saving in ``safetensors`` format (default).

        Args:

            model (torch.nn.Module): The model to save.
            save_directory (str): Path to the output directory.
            max_shard_size (str, optional): Max size per checkpoint file. Defaults to "10GB".
            safe_serialization (bool, optional): Whether to use ``safetensors``. Defaults to True.
        """
        self.accelerator.wait_for_everyone()
        self.accelerator.save_model(
            model,
            save_directory=save_directory,
            max_shard_size=max_shard_size,
            safe_serialization=safe_serialization
        )

    def save_state(
            self,
            output_dir: str,
            safe_serialization: bool = True,
            **kwargs
    ) -> None:
        r"""
        Saves the complete training state (Model, Optimizer, LR Scheduler, RNG state).

        Args:

            output_dir (str): Path to the output directory.
            safe_serialization (bool, optional): Use safetensors for state. Defaults to True.
            **kwargs: Additional arguments passed to ``save_state``.
        """
        self.accelerator.wait_for_everyone()
        self.accelerator.save_state(
            output_dir=output_dir,
            safe_serialization=safe_serialization,
            **kwargs
        )

    def register_obj_for_save_state(self, obj: Any) -> None:
        r"""
        Registers a custom object to be saved/loaded via ``save_state`` and ``load_state``.
        """
        self.accelerator.register_for_checkpointing(obj)

    def load_state(self, save_directory: str) -> None:
        r"""
        Restores the full training state (Optimizer, LR Scheduler, RNG) from a directory.

        Args:

            save_directory (str): Directory containing the checkpoint.
        """
        self.accelerator.load_state(save_directory)

    def get_unwrap_model(self, model: nn.Module) -> nn.Module:
        r"""
        Unwraps the given model from DDP/FSDP/DeepSpeed wrappers.

        .. warning::
            Under DeepSpeed ZeRO-3, the returned model only contains **this rank's
            parameter shard**. Use :meth:`get_state_dict` to gather the full state
            dict across all ranks.

        Args:
            model (torch.nn.Module): The model instance to unwrap.

        Returns:
            torch.nn.Module: The unwrapped model (original pytorch module).
        """
        if self.distributed_strategy == "deepspeed":
            logger.warning(
                "[AccelerateEngine] get_unwrap_model under DeepSpeed ZeRO-3 returns "
                "only this rank's parameter shard. Use get_state_dict() for full weights."
            )
        return self.accelerator.unwrap_model(model)

    def get_state_dict(self, model: nn.Module) -> dict:
        r"""
        Unwraps the given model from DDP/FSDP wrappers.
        Pay attention, if DDP full model, if ZeRO-3  full model,
        but may out of gpu memory if marge to gpu, acc default cpu

        Args:
            model (torch.nn.Module): The model instance to unwrap.

        Returns:
            dict: The unwrapped model dict (original pytorch module dict).

        Example:
            >>> state_dict = engine.get_state_dict(ddp_model)
            >>> engine.save(state_dict, "model.pth")
            >>> # if torch need in main process
            >>> torch.save(state_dict, "model.pth")
        """
        return self.accelerator.get_state_dict(model)

    def load_model(self, model: nn.Module, save_path: str) -> None:
        r"""
        Loads model weights from a file or a sharded checkpoint directory.

        This method is robust to DDP wrappers and handles both legacy ``.bin``
        and new ``.safetensors`` formats.

        Args:

            model (torch.nn.Module): The model instance to load weights into.
            save_path (str): Path to a **file** (e.g. ``model.safetensors``) or
                a **directory** containing sharded weights.

        Raises:

            FileNotFoundError: If the provided path does not exist or contains no weights.
        """
        self.accelerator.wait_for_everyone()
        unwrapped_model = self.accelerator.unwrap_model(model)

        # Logic for loading from a directory (Sharded checkpoint)
        if os.path.isdir(save_path):
            try:
                # Try loading as a standard Accelerate/HuggingFace sharded checkpoint
                load_checkpoint_in_model(
                    unwrapped_model,
                    checkpoint=save_path,
                    device_map=None,
                    offload_folder=None
                )
                if self.is_main:
                    logger.info(f"[AccelerateEngine] Successfully loaded sharded checkpoint from: {save_path}")
            except Exception as e:
                # Fallback: Look for specific single files inside the directory
                if self.is_main:
                    logger.warning(
                        f"[AccelerateEngine] Standard folder load failed ({str(e)}). "
                        "Attempting to find single weight files..."
                    )

                single_safe = os.path.join(save_path, "model.safetensors")
                single_bin = os.path.join(save_path, "pytorch_model.bin")

                if os.path.exists(single_safe):
                    self._load_single_file(unwrapped_model, single_safe)
                elif os.path.exists(single_bin):
                    self._load_single_file(unwrapped_model, single_bin)
                else:
                    raise FileNotFoundError(f"No valid 'model.safetensors' or 'pytorch_model.bin' found in {save_path}")

        # Logic for loading from a single file
        elif os.path.isfile(save_path):
            self._load_single_file(unwrapped_model, save_path)
        else:
            raise FileNotFoundError(f"Checkpoint path not found: {save_path}")

    def _load_single_file(self, model: nn.Module, file_path: str) -> None:
        """Internal helper to load a single weight file (safetensors or torch pickle)."""
        if file_path.endswith(".safetensors"):
            state_dict = load_file(file_path)
        else:
            state_dict = torch.load(file_path, map_location="cpu")

        model.load_state_dict(state_dict, strict=True)
        if self.is_main:
            logger.info(f"[AccelerateEngine] Loaded weights from file: {file_path}")

    def save(self, obj: Any, path: str, safe_serialization: bool = False) -> None:
        """Wrapper for saving arbitrary objects via Accelerator.
        if main_process[or all_proces]: torch.save  is equal to acc.save
        and acc.save can set only rank 0 save or all rank save in project_config
        """
        self.accelerator.save(obj, path, safe_serialization=safe_serialization)

    # =========================================================================
    # Distributed Gathering
    # =========================================================================

    def gather_for_metrics(self, input_data: Any, use_gather_object: bool = False) -> Any:
        r"""
        Gathers data across processes specifically for metric evaluation.

        Note:

            This method automatically discards duplicate samples introduced by
            DistributedSampler padding.

        Args:

            input_data (Union[torch.Tensor, Any]): The local data to gather.
            use_gather_object (bool): If True, uses pickling (slower, supports any object).
                If False, expects Tensors (faster).
        """
        return self.accelerator.gather_for_metrics(input_data, use_gather_object=use_gather_object)

    def _gather_for_metrics(self, input_data: torch.Tensor) -> torch.Tensor:
        """Internal: Gather tensors for metrics."""
        return self.accelerator.gather_for_metrics(input_data, use_gather_object=False)

    def _gather_for_metrics_use_object(self, input_data: Any) -> List[Any]:
        """Internal: Gather objects for metrics."""
        return self.accelerator.gather_for_metrics(input_data, use_gather_object=True)

    def gather(self, input_data: torch.Tensor) -> torch.Tensor:
        r"""
        Gathers tensors from all processes into a single tensor.

        Note:

            Does NOT remove duplicates from padding. Dimensions are concatenated.

        Args:

            input_data (torch.Tensor): Local tensor.

        Returns:

            torch.Tensor: Concatenated tensor from all processes.
        """
        return self.accelerator.gather(input_data)

    def gather_object(self, input_data: Any) -> List[Any]:
        r"""
        Gathers any picklable object from all processes.

        Args:

            input_data (Any): Local object.

        Returns:

            List[List[Any]]: List containing objects from all processes. Outside len is rank num.
        """
        output = gather_object(input_data)
        if self.accelerator.num_processes == 1:
            return [output]

        return output


    def gather_in_eval(self, input_data: Any) -> Any:
        r"""
        Executes the strategy defined by ``gather_in_eval`` during initialization.
        """
        return self._gather_in_eval_fn(input_data)

    def gather_in_train(self, input_data: Any) -> Any:
        r"""
        Executes the strategy defined by ``gather_in_train`` during initialization.
        """
        return self._gather_in_train_fn(input_data)

    def close(self) -> None:
        r"""
        Finalizes the distributed process group and cleans up resources.
        """
        self.accelerator.end_training()
        if dist.is_initialized():
            dist.destroy_process_group()




