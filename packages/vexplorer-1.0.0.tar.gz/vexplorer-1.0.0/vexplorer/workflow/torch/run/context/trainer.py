# -*- coding: utf-8 -*-
import torch
import torch.nn as nn
from typing import Dict, Any, Optional, List, Union
from dataclasses import dataclass, field, asdict
import torch.distributed as dist
import logging


logger = logging.getLogger(__name__)

from ....general.run.context.base import BaseRunArgs, BaseRunContext

@dataclass
class TrainerRunArgs(BaseRunArgs):
    """
    Container for training/evaluation state and hyperparameters.
    
    This class acts as a central registry for all variables accessible within 
    Callbacks. It separates static configuration from dynamic runtime state.

    """

    config: Dict[str, Any] = field(default_factory=dict)
    """Detail config dict of job"""

    # ==========================================
    # 1. Static Configuration
    # ==========================================
    network: Optional[nn.Module] = None
    """The base neural network model."""

    engine: Any = None
    """The engine to use for training or evaluation."""

    train_network: Optional[nn.Module] = None
    """Network wrapped with Loss/Optimizer (if applicable)."""

    eval_network: Optional[nn.Module] = None
    """Network used for evaluation."""

    optimizer: Optional[torch.optim.Optimizer] = None
    """The optimizer instance."""

    loss_fn: Optional[nn.Module] = None
    """The loss function."""

    train_dataset: Any = None
    """The training dataloader or iterator."""

    eval_dataset: Any = None
    """The evalation dataloader or iterator."""

    list_callback: List[Any] = field(default_factory=list)
    """List of active callbacks."""

    # ==========================================
    # 2. Hyperparameters & Environment
    # ==========================================
    mode: str = "train"
    """Current running mode ("train" or "eval")."""

    epoch_num: int = 0
    """Total number of epochs to run."""

    batch_num: int = 0
    """Total batches per training epoch."""

    batch_num_of_eval: int = 0
    """Total batches per evaluation epoch."""

    parallel_mode: str = "stand_alone"
    """Parallel mode configuration (e.g., 'stand_alone', 'data_parallel')."""

    device_number: int = 1
    """Number of devices (GPUs) used."""

    device_index: int = 0
    """This device process_index (GPU id in global)"""

    dataset_sink_mode: bool = False
    """Whether to use dataset sink mode (if supported by backend)."""

    # ==========================================
    # 3. Dynamic Runtime Status
    # ==========================================
    cur_epoch_num: int = 0
    """Current epoch index (1-based usually)."""

    cur_epoch_num_of_eval: int = 0
    """Current evaluation epoch index."""

    cur_step_num: int = 0
    """Current global step index."""

    cur_step_num_of_eval: int = 0
    """Current global evaluation step index."""

    # Current Data/Outputs
    train_dataset_element: Any = None
    """Input data of the current step (e.g., (x, y))."""

    eval_dataset_element: Any = None
    """Input data of the current evaluation step."""

    net_outputs: Any = None
    """Raw output from the network for the current step."""

    # Loss & Metrics
    train_loss: Any = None
    """Loss value of the current step."""

    train_raw_losses: Dict[str, Any] = field(default_factory=dict)
    """Detail losses dict of train"""

    eval_loss: Any = None
    """Loss value of the current evaluation step."""

    eval_raw_losses: Dict[str, Any] = field(default_factory=dict)
    """Detail losses dict of eval"""

    train_metrics: Dict[str, Any] = field(default_factory=dict)
    """Accumulated training metrics."""

    eval_metrics: Dict[str, Any] = field(default_factory=dict)
    """Accumulated evaluation metrics."""

    # ==========================================
    # 4. Checkpoint Management
    # ==========================================
    last_save_ckpt_step: int = 0
    """The step number when the last checkpoint was saved."""

    latest_ckpt_file: str = ""
    """The file path of the latest saved checkpoint."""

    # ==========================================
    # 5. Dynamic Extensions
    # ==========================================
    extras: Dict[str, Any] = field(default_factory=dict)
    """A reserved dictionary for user-defined dynamic variables."""

    def to_dict(self, safe: bool = True) -> Dict[str, Any]:
        """Converts the state to a dictionary.

        Args:
            safe (bool): If True, removes non-serializable or heavy objects
                (like nn.Module, Optimizer, Datasets) to allow for safe logging
                or printing. Defaults to True.

        Returns:
            Dict[str, Any]: A dictionary representation of the state.
        """
        data = asdict(self)
        if safe:
            # Filter out heavy objects that pollute logs
            # TODO
            keys_to_exclude = {
                'network', 'train_network', 'eval_network',
                'optimizer', 'loss_fn', 'train_dataset', 'eval_dataset',
                'list_callback', 'train_dataset_element', 'eval_dataset_element',
                'net_outputs'
            }
            return {k: v for k, v in data.items() if k not in keys_to_exclude}
        return data


class TrainerRunContext(BaseRunContext):
    """
    Context manager that wraps `RunArgs` and provides flow control interfaces.

    It serves as the bridge between the training loop and callbacks. Callbacks
    receive this context to read state (`original_args`) or modify flow (`request_stop`).

    Args:
        original_args (RunArgs): The underlying state container.

    Example:
        >>> args = TrainerRunArgs(epoch_num=10)
        >>> ctx = TrainerRunContext(args)
        >>> ctx.request_stop()
        >>> print(ctx.get_stop_requested())
        True
    """
    def __init__(self, original_args: TrainerRunArgs):
        super().__init__(original_args)
        self._original_args = original_args
        self._stop_requested = False
        self.device = self._get_current_device()
        logging.info(f"Initialized TrainerRunContext on device: {self.device}")

    def original_args(self) -> TrainerRunArgs:
        """Returns the underlying state container.

        Returns:
            RunArgs: The mutable arguments object.
        """
        return self._original_args

    def request_stop(self) -> None:
        """Signals the training loop to stop execution at the next safe point."""
        self._stop_requested = True

    def get_stop_requested(self) -> bool:
        """Checks if a stop signal has been issued.

        Returns:
            bool: True if stop requested, False otherwise.
        """
        # # return self._stop_requested
        # # """
        # # 检查是否停止。在分布式环境下，会自动同步所有卡的状态。
        # # 只要有一张卡请求停止，所有卡都会同步停止状态。
        # # """
        # # 如果没有初始化分布式环境，直接返回本地状态
        # if not dist.is_initialized():
        #     return self._stop_requested

        # # 将本地布尔状态转换为 Tensor 用于通信
        # # 使用当前进程的设备，避免跨设备通信错误
        # stop_tensor = torch.tensor(
        #     [1.0 if self._stop_requested else 0.0],
        #     device=torch.cuda.current_device()
        # )

        # # 使用 MAX 操作进行全员同步：只要有一个进程是 1，所有进程都会变成 1
        # dist.all_reduce(stop_tensor, op=dist.ReduceOp.MAX)

        # # 更新本地状态并返回
        # self._stop_requested = stop_tensor.item() > 0.5
        # return self._stop_requested
    

    # def check_stop(self):
        if not dist.is_initialized():
            return self._stop_requested

        device = self._get_current_device()
        stop_tensor = torch.tensor(
            [1.0 if self._stop_requested else 0.0],
            device=device
        )

        dist.all_reduce(stop_tensor, op=dist.ReduceOp.MAX)

        self._stop_requested = stop_tensor.item() > 0.5
        return self._stop_requested


    def _get_current_device(self):
        """获取当前加速设备，兼容 CUDA 和华为 NPU。"""
        try:
            import torch_npu  # noqa: F401
            if torch.npu.is_available():
                return torch.device(f"npu:{torch.npu.current_device()}")
        except ImportError:
            pass

        if torch.cuda.is_available():
            return torch.device(f"cuda:{torch.cuda.current_device()}")

        return torch.device("cpu")

