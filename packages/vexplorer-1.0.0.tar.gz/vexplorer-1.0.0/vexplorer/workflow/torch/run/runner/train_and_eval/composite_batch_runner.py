# -*- coding: utf-8 -*-
import logging
import time
from pathlib import Path
from typing import Dict, Any, Optional, List, Union, Tuple

import torch

from ......core.general.builder.config_builder import build_from_cfg
from ......data.torch.transform.data_prefetcher import DataPrefetcher


logger = logging.getLogger(__name__)


class CompositeBatchRunner:
    """
    Core execution engine for Super-Batch training strategies.

    This runner handles:
    1.  **Gradient Accumulation**: Splits a "Super Batch" into "Micro Batches" to save memory.
    2.  **Dynamic Batching**: Works with `DistributedCompositeBatchSampler` to handle grouped data.
    3.  **Distributed Training**: Manages DDP synchronization contexts automatically.
    4.  **Lifecycle Management**: Orchestrates Callbacks, Metrics, and Engines.

    Args:
        raw_cfg (Dict): The complete configuration dictionary.
        **kwargs: Runtime overrides for runner parameters.
    """

    def __init__(self, raw_cfg: Dict[str, Any], **kwargs):
        self.raw_cfg = raw_cfg
        self.raw_cfg["running"]=dict()

        # ── 1. Runner Parameters ──────────────────────────────────────────────
        workflow_cfg = self.raw_cfg.get('workflow', {})
        run_cfg = workflow_cfg.get("run", {})

        runner_params = run_cfg.get("runner_cfg", {}).get("params", {})
        runner_params.update(kwargs)  # kwargs take precedence

        self.epoch_num = int(runner_params.get('epoch_num', 1))
        self.work_dir = Path(runner_params.get('work_dir', './workspace/output'))
        # debug_sync_device: 控制 DEBUG 模式下是否执行 torch.npu.synchronize()
        # false(默认): DEBUG 仍输出 timing 日志，但不阻塞 NPU 异步流水线（timing 不精确）
        # true: 执行同步，timing 精确但会严重拖慢训练
        self.debug_sync_device = runner_params.get('debug_sync_device', False)
        self.work_dir.mkdir(parents=True, exist_ok=True)

        # ── 1.2 Environment ───────────────────────────────────────────────────
        log_cfg = run_cfg.get("environment", {}).get("log_manager_cfg", None)
        self.log_manager = build_from_cfg(log_cfg) if log_cfg else None
        self.log_level = self.log_manager.get_current_log_level() if self.log_manager else logging.DEBUG
        logger.info(f"[Runner] Logger Initialized: {self.log_level}")

        # Seed / Reproducibility
        reproducibility_manager_cfg = run_cfg.get("environment", {}).get("reproducibility_manager_cfg", None)
        self.reproducibility_manager = build_from_cfg(reproducibility_manager_cfg) if reproducibility_manager_cfg else None
        self.seed = self.reproducibility_manager.get_seed() if self.reproducibility_manager else 42
        logger.info(f"[Runner] Seed Initialized: {self.seed}")
        self.raw_cfg["running"]["seed"] = self.seed

        # ── 1.3 Engine ────────────────────────────────────────────────────────
        self.engine = build_from_cfg(run_cfg.get('engine_cfg'))
        self.is_main = self.engine.is_main

        # ── 1.4 Run Args & Context ────────────────────────────────────────────
        self.run_args = build_from_cfg(run_cfg.get('context', {}).get('run_args_cfg'))
        self.run_args.epoch_num = self.epoch_num

        # Initialise step counters explicitly to avoid AttributeError on += .
        if not hasattr(self.run_args, 'cur_step_num'):
            self.run_args.cur_step_num = 0
        if not hasattr(self.run_args, 'cur_step_num_of_eval'):
            self.run_args.cur_step_num_of_eval = 0
        if not hasattr(self.run_args, 'cur_epoch_num'):
            self.run_args.cur_epoch_num = 0

        self.run_context = build_from_cfg(
            run_cfg.get('context', {}).get('run_context_cfg'),
            params_override={"original_args": self.run_args},
        )

        # ── 2. Model ──────────────────────────────────────────────────────────
        self.network = build_from_cfg(self.raw_cfg.get('model', {}).get("model_cfg"))
        params_to_optimize = [{'params': self.network.parameters()}]

        # === 提取按需初始化的 Config 节点 ===
        train_cfg = workflow_cfg.get('train', {})
        eval_cfg = workflow_cfg.get('eval', {})
        data_cfg = self.raw_cfg.get('data', {})

        # ── 3. Loss Functions ─────────────────────────────────────────────────
        self.train_loss, self.train_loss_weight_optimizer = None, None
        if train_cfg and train_cfg.get('loss'):
            (self.train_loss, train_loss_params, _train_loss_w_params,
             self.train_loss_weight_optimizer) = self._build_loss_pipe(train_cfg['loss'])
            if len(train_loss_params) > 0:
                params_to_optimize.append({'params': train_loss_params})

        # ── 3.1 Light Loss (可选) ────────────────────────────────────────────
        # 轻量 loss：在 SuperBatch 级别与 full loss 交替使用
        # 配置路径: workflow.train.loss_light
        # 配合 runner_params.light_loss_interval 控制频率（默认 0 = 不启用）
        self.train_loss_light = None
        self._light_loss_interval = int(runner_params.get('light_loss_interval', 0))
        if train_cfg and train_cfg.get('loss_light') and self._light_loss_interval > 0:
            (self.train_loss_light, _light_params, _light_w_params,
             _) = self._build_loss_pipe(train_cfg['loss_light'])
            logger.info(
                "[Runner] Light loss enabled: interval=%d (every %d steps use full, others use light)",
                self._light_loss_interval, self._light_loss_interval,
            )

        self.eval_loss, self.eval_loss_weight_optimizer = None, None
        if eval_cfg and eval_cfg.get('loss'):
            (self.eval_loss, _eval_loss_params, _eval_loss_w_params,
             self.eval_loss_weight_optimizer) = self._build_loss_pipe(eval_cfg['loss'])

        # ── 4. Optimizer ──────────────────────────────────────────────────────
        self.optimizer = None
        if train_cfg and train_cfg.get('optimizer') and train_cfg['optimizer'].get('optimizer_cfg'):
            self.optimizer = build_from_cfg(
                train_cfg['optimizer']["optimizer_cfg"],
                params_override={'params': params_to_optimize},
            )

        # ── 5. Data Pipelines ─────────────────────────────────────────────────
        self.train_loader, self.train_batch_transform, self.train_batch_sampler = None, None, None
        train_pipeline_cfg = data_cfg.get('train_pipeline')
        if train_pipeline_cfg:
            self.train_loader, self.train_batch_transform, self.train_batch_sampler, self.train_group_name_key = self._build_data_pipe(
                train_pipeline_cfg
            )
            logger.info(f"[Runner] Length of self.train_loader: {len(self.train_loader)}")

        self.eval_loader, self.eval_batch_transform, self.eval_batch_sampler = None, None, None
        eval_pipeline_cfg = data_cfg.get('eval_pipeline')
        if eval_pipeline_cfg:
            self.eval_loader, self.eval_batch_transform, self.eval_batch_sampler, self.eval_group_name_key = self._build_data_pipe(
                eval_pipeline_cfg
            )
            logger.info(f"[Runner] Length of self.eval_loader: {len(self.eval_loader)}")

        # ── 6. LR Scheduler ───────────────────────────────────────────────────
        self.lr_scheduler = None
        if train_cfg and train_cfg.get('optimizer') and train_cfg['optimizer'].get('lr_scheduler_cfg'):
            steps_per_epoch = len(self.train_loader) if self.train_loader is not None else 1
            self.lr_scheduler = build_from_cfg(
                train_cfg['optimizer']['lr_scheduler_cfg'],
                params_override={
                    'optimizer': self.optimizer,
                    'epochs': self.epoch_num,
                    'steps_per_epoch': steps_per_epoch,
                },
            )

        # ── 7. Metrics & Callbacks ────────────────────────────────────────────
        self.metric_in_train = None
        if train_cfg and train_cfg.get('metric'):
            self.metric_in_train = self._build_metric_pipe(train_cfg['metric'])

        self.metric_in_eval = None
        if eval_cfg and eval_cfg.get('metric'):
            self.metric_in_eval = self._build_metric_pipe(eval_cfg['metric'])

        self.callback_manager = None
        callback_cfg = workflow_cfg.get("callback", {}).get("in_train_and_eval")
        if callback_cfg:
            self.callback_manager = self._build_callback_pipe(callback_cfg)

        # ── 8. Accelerator Preparation (Dynamic wrapping) ─────────────────────
        # The initialization order depends on the distributed strategy:
        #   DDP:       .to(device) → compile → prepare
        #   FSDP:      .to(device) for non-model only → prepare → compile
        #   DeepSpeed: .to(device) for non-model only → prepare (no compile)
        _device = self.engine.device
        _strategy = self.engine.distributed_strategy
        logger.debug(f"Running device: {_device}, strategy: {_strategy}")

        # For FSDP/DeepSpeed, the engine handles model device placement during
        # prepare(). Only move non-model modules (loss, transforms) manually.
        # For DDP/no-dist, move everything including the model (existing behavior).
        if _strategy in ("fsdp", "deepspeed"):
            _modules_to_move = [self.train_loss, self.train_loss_light, self.eval_loss,
                                self.train_batch_transform, self.eval_batch_transform]
        else:
            _modules_to_move = [self.network, self.train_loss, self.train_loss_light,
                                self.eval_loss,
                                self.train_batch_transform, self.eval_batch_transform]

        for _obj in _modules_to_move:
            if _obj is not None and isinstance(_obj, torch.nn.Module):
                _obj.to(_device)
                try:
                    curr_device = next(_obj.parameters()).device
                    logger.debug(f"Move {_obj.__class__.__name__} to {curr_device}")
                except Exception as e:
                    pass

        # ── 8.0 Training Optimization ─────────────────────────────────────────
        # Apply platform-specific optimizations (NPU env vars, CUDA TF32, etc.)
        # BEFORE any compilation to ensure environment is ready.
        model_cfg = self.raw_cfg.get('model', {})
        _opt_cfg = model_cfg.get('optimize_for_training')
        if _opt_cfg and _opt_cfg.get('enabled', False):
            _opt_params = _opt_cfg.get('params', {})
            if hasattr(self.network, 'optimize_for_training'):
                logger.info("[Runner] Applying optimize_for_training with params: %s", _opt_params)
                _opt_params_safe = dict(_opt_params)
                # For FSDP/DeepSpeed the strategy handles device placement.
                # We still want optimize_for_training to SET NPU/CUDA env vars
                # (which are gated on device type), but NOT move the model.
                # Solution: detect the actual target device, apply env vars,
                # then override device='cpu' so model.to() is a no-op.
                if _strategy in ("fsdp", "deepspeed"):
                    # Import here to set env vars for the actual target device
                    import os
                    _actual_device = _opt_params_safe.get('device', 'auto')
                    if _actual_device == 'auto':
                        try:
                            import torch_npu  # noqa: F401
                            _actual_device = 'npu'
                        except ImportError:
                            _actual_device = 'cuda' if torch.cuda.is_available() else 'cpu'
                    # Set NPU env vars BEFORE model creation if target is NPU
                    if _actual_device == 'npu':
                        _npu_envs = {
                            'TASK_QUEUE_ENABLE': '2',
                            'CPU_AFFINITY_CONF': '2',
                            'COMBINED_ENABLE': '1',
                            'MULTI_STREAM_MEMORY_REUSE': '3',
                            'ACL_OP_COMPILER_CACHE_MODE': 'enable',
                        }
                        for k, v in _npu_envs.items():
                            if k not in os.environ:
                                os.environ[k] = v
                                logger.debug("[Runner] Set env %s=%s (NPU default)", k, v)
                    # Keep model on CPU — FSDP will move it
                    _opt_params_safe['device'] = 'cpu'
                # Never let optimize_for_training trigger compile — we handle that below
                _opt_params_safe.pop('use_compile', None)
                _opt_params_safe.pop('compile_mode', None)
                self.network.optimize_for_training(**_opt_params_safe)
            else:
                logger.debug("[Runner] Model has no optimize_for_training(); skipping.")

        # ── 8.1 Model Compilation ─────────────────────────────────────────────
        # Two levels of compilation:
        #   compile_inner: block-level torch.compile on hot-path submodules
        #                  (encoder/decoder blocks).  Executes BEFORE prepare
        #                  for all strategies.
        #   compile:       whole-model torch.compile.  Timing depends on strategy:
        #                    DDP: before prepare | FSDP: after prepare | DS: skip.
        #
        # If both are enabled, a warning is emitted about potential redundant
        # tracing overhead.

        # --- Outer compile config ---
        compile_cfg = model_cfg.get('compile')
        _want_compile = compile_cfg and compile_cfg.get('compile_open', False)
        _compile_params = compile_cfg.get('params', {}) if compile_cfg else {}

        # --- Inner compile config ---
        compile_inner_cfg = model_cfg.get('compile_inner')
        _want_compile_inner = (compile_inner_cfg
                               and compile_inner_cfg.get('compile_open', False))
        _compile_inner_params = (compile_inner_cfg.get('params', {})
                                 if compile_inner_cfg else {})

        # Warn if both inner and outer are active
        if _want_compile_inner and _want_compile:
            logger.warning(
                "[Runner] Both compile_inner and compile are enabled. "
                "Inner compile targets individual blocks; outer compile wraps "
                "the entire model.  This causes double tracing and may "
                "significantly increase first-step compilation time. "
                "Consider using only one level of compilation."
            )

        if _want_compile and _strategy == "deepspeed":
            logger.warning(
                "[Runner] torch.compile (outer) is incompatible with DeepSpeed "
                "ZeRO-3. Skipping outer compilation. "
                "Set compile.compile_open=false to suppress."
            )
            _want_compile = False

        if _want_compile_inner and _strategy == "deepspeed":
            logger.warning(
                "[Runner] compile_inner with DeepSpeed is experimental; "
                "parameter proxies may cause graph breaks."
            )

        # Inner compile — BEFORE prepare for all strategies.
        # Compiled blocks become the units that FSDP wraps.
        if _want_compile_inner:
            if hasattr(self.network, 'compile_inner'):
                logger.info(
                    "[Runner] Applying inner compilation (block-level) "
                    "with config: %s", _compile_inner_params
                )
                self.network.compile_inner(**_compile_inner_params)
            else:
                logger.warning(
                    "[Runner] compile_inner requested but model has no "
                    "compile_inner() method. Falling back to whole-model "
                    "torch.compile with inner params."
                )
                self.network = torch.compile(self.network, **_compile_inner_params)

        # DDP: outer compile before prepare
        if _want_compile and _strategy not in ("fsdp",):
            # --- torchair backend: use GE graph engine for NPU ---
            if _compile_params.get('backend') == 'torchair':
                try:
                    import torchair
                    _tc_config = torchair.CompilerConfig()
                    _tc_config.mode = _compile_params.get('mode', 'max-autotune')
                    _tc_backend = torchair.get_npu_backend(compiler_config=_tc_config)
                    _tc_params = {k: v for k, v in _compile_params.items()
                                  if k not in ('backend', 'mode')}
                    logger.info("[Runner] Compiling model with torchair GE backend "
                                "(mode=%s): %s", _tc_config.mode, _tc_params)
                    self.network = torch.compile(
                        self.network, backend=_tc_backend, **_tc_params)
                except ImportError:
                    logger.error("[Runner] torchair not installed! "
                                 "Falling back to eager mode (no compile).")
            else:
                logger.info("[Runner] Compiling model (pre-prepare, outer) with config: %s", _compile_params)
                self.network = torch.compile(self.network, **_compile_params)

        prepare_dict: Dict[str, Any] = {'network': self.network}
        if self.optimizer is not None: prepare_dict['optimizer'] = self.optimizer

        if self.train_loader is not None and self.train_batch_sampler is not None:
            if getattr(self.train_batch_sampler, 'need_rank_select_outside', True):
                prepare_dict['train_loader'] = self.train_loader
        if self.eval_loader is not None and self.eval_batch_sampler is not None:
            if getattr(self.eval_batch_sampler, 'need_rank_select_outside', True):
                prepare_dict['eval_loader'] = self.eval_loader
        if self.lr_scheduler is not None: prepare_dict['lr_scheduler'] = self.lr_scheduler
        
        # Losses, transforms and loss-weight optimizers should NOT be prepared (wrapped) 
        # in FSDP/DeepSpeed to avoid sharding small parameters into 0-element tensors.
        # They are already moved to the correct device in the preceding block.
        if _strategy not in ("fsdp", "deepspeed"):
            if self.train_loss is not None: prepare_dict['train_loss'] = self.train_loss
            if self.eval_loss is not None: prepare_dict['eval_loss'] = self.eval_loss
            if self.train_loss_weight_optimizer is not None: prepare_dict['train_loss_weight_optimizer'] = self.train_loss_weight_optimizer
            if self.eval_loss_weight_optimizer is not None: prepare_dict['eval_loss_weight_optimizer'] = self.eval_loss_weight_optimizer
            if self.train_batch_transform is not None: prepare_dict['train_batch_transform'] = self.train_batch_transform
            if self.eval_batch_transform is not None: prepare_dict['eval_batch_transform'] = self.eval_batch_transform

        keys = list(prepare_dict.keys())
        prepared_values = self.engine.prepare(*prepare_dict.values())
        prepared = dict(zip(keys, prepared_values))

        # Re-assign prepared objects gracefully
        self.network = prepared.get('network', self.network)
        self.optimizer = prepared.get('optimizer', self.optimizer)
        self.train_loader = prepared.get('train_loader', self.train_loader)
        self.eval_loader = prepared.get('eval_loader', self.eval_loader)
        self.lr_scheduler = prepared.get('lr_scheduler', self.lr_scheduler)
        self.train_loss = prepared.get('train_loss', self.train_loss)
        self.eval_loss = prepared.get('eval_loss', self.eval_loss)
        self.train_loss_weight_optimizer = prepared.get('train_loss_weight_optimizer', self.train_loss_weight_optimizer)
        self.eval_loss_weight_optimizer = prepared.get('eval_loss_weight_optimizer', self.eval_loss_weight_optimizer)
        self.train_batch_transform = prepared.get('train_batch_transform', self.train_batch_transform)
        self.eval_batch_transform = prepared.get('eval_batch_transform', self.eval_batch_transform)

        # FSDP: outer compile AFTER prepare (FSDP wrapping must happen first)
        if _want_compile and _strategy == "fsdp":
            logger.info("[Runner] Compiling model (post-prepare/FSDP, outer) with config: %s", _compile_params)
            self.network = torch.compile(self.network, **_compile_params)

        # ── 8.2 Inject engine into weight strategies (for mixed-precision) ────
        if self.train_loss is not None:
            train_loss_impl = getattr(self.train_loss, 'module', self.train_loss)
            train_loss_impl.set_engine(self.engine, self.network)
            self._evalate_loss_mode(train_loss_impl, label="train_loss")
            self.train_loss = train_loss_impl

        if self.eval_loss is not None:
            eval_loss_impl = getattr(self.eval_loss, 'module', self.eval_loss)
            eval_loss_impl.set_engine(self.engine, self.network)
            self._evalate_loss_mode(eval_loss_impl, label="eval_loss")
            self.eval_loss = eval_loss_impl

        # ── 8.3 Inject engine into light loss (same pattern as train/eval) ────
        if self.train_loss_light is not None:
            light_loss_impl = getattr(self.train_loss_light, 'module', self.train_loss_light)
            light_loss_impl.set_engine(self.engine, self.network)
            self._evalate_loss_mode(light_loss_impl, label="train_loss_light")
            self.train_loss_light = light_loss_impl

        # ── 9. Inject into run_args AFTER prepare ─────────────────────────────
        self.run_args.network = self.network
        self.run_args.engine = self.engine
        self.run_args.train_network = None
        self.run_args.eval_network = None
        self.run_args.parallel_mode = _strategy
        self.run_args.device_number = self.engine.all_num_processes
        self.run_args.device_index = self.engine.process_index
        self.run_args.dataset_sink_mode = False

        self.run_args.optimizer = self.optimizer
        self.run_args.loss_fn = self.train_loss
        self.run_args.train_dataset = self.train_loader
        self.run_args.eval_dataset = self.eval_loader
        self.run_args.list_callback = self.callback_manager.callbacks if self.callback_manager else []
        self.run_args.config = self.raw_cfg

    # =========================================================================
    # Validation Helpers
    # =========================================================================
    def _synchronize(self) -> None:
        """Wait for kernels to finish for accurate timing, only in debug mode.

        When ``debug_sync_device`` is False (default), this is a no-op even in
        DEBUG mode — timing info is still logged but won't be GPU/NPU-precise.
        Set ``debug_sync_device=True`` in runner_params for precise profiling.
        """
        if self.log_level > logging.DEBUG:
            return
        if not self.debug_sync_device:
            return

        if torch.cuda.is_available():
            torch.cuda.synchronize()
        elif hasattr(torch, 'npu') and torch.npu.is_available():
            torch.npu.synchronize()
        elif hasattr(torch, 'cuda') and torch.cuda.is_available():
            # Some NPU environments alias or use torch.cuda for compatibility
            torch.cuda.synchronize()

    @staticmethod
    def _evalate_loss_mode(loss_manager: Any, label: str = "loss") -> None:
        """Ensure exactly one of the three optimisation mode flags is set."""
        flags = {
            'is_params_optimize_together': loss_manager.is_params_optimize_together,
            'is_grad_inner': loss_manager.is_grad_inner,
            'is_params_optimize_two_stage': loss_manager.is_params_optimize_two_stage,
        }
        active = [name for name, val in flags.items() if val]
        if len(active) != 1:
            raise RuntimeError(
                f"[Runner] {label} has {len(active)} active optimisation mode(s): "
                f"{active}. Exactly one must be True."
            )

    # =========================================================================
    # Builder Helpers
    # =========================================================================

    def _build_loss_pipe(self, cfg: Dict[str, Any]) -> Tuple[Any, list, list, Optional[Any]]:
        manager_cfg = cfg.get('manager_cfg')
        weight_strategy_cfg = cfg.get("weight", {}).get('strategy_cfg', None)
        weight_strategy_opt_cfg = cfg.get("weight", {}).get('strategy_optimizer_cfg', None)
        loss_set_cfg = cfg.get('loss_set', [])

        weight_strategy = build_from_cfg(weight_strategy_cfg)
        manager = build_from_cfg(manager_cfg, params_override={"weight_strategy": weight_strategy})

        for loss_cfg_i in loss_set_cfg:
            loss_i = build_from_cfg(loss_cfg_i["loss_cfg"])
            wrapper_i = build_from_cfg(loss_cfg_i.get("wrapper_cfg", None))
            manager.add_loss(name=loss_cfg_i["name"], loss_fn=loss_i, wrapper=wrapper_i)
        manager.build()

        loss_params, loss_w_params = manager.get_parameter_groups()

        weight_optimizer = None
        if manager.is_params_optimize_two_stage and len(loss_w_params) > 0:
            weight_optimizer = build_from_cfg(
                weight_strategy_opt_cfg,
                params_override={'params': loss_w_params},
            )
        return manager, loss_params, loss_w_params, weight_optimizer

    def _build_metric_pipe(self, cfg: Dict) -> Any:
        manager_cfg = cfg.get('manager_cfg')
        metric_set_cfg = cfg.get('metric_set', [])
        manager = build_from_cfg(manager_cfg)

        for m in metric_set_cfg:
            input_transform = {}
            input_transform_cfg = m["wrapper_cfg"].get("input_transform",{})
            for t_name in input_transform_cfg:
                input_transform[t_name] = build_from_cfg(input_transform_cfg[t_name])

            wrapper=build_from_cfg(m["wrapper_cfg"],
                                   params_override={"input_transform":input_transform})

            manager.add_metric(
                name=m["name"],
                metric=build_from_cfg(m["metric_cfg"]),
                wrapper=wrapper,
            )
        manager.build()
        manager.to(self.engine.device)
        return manager

    def _build_callback_pipe(self, cfg: Dict) -> Any:
        manager_cfg = cfg.get('manager_cfg')
        callback_set_cfg = cfg.get('callback_set', [])
        manager = build_from_cfg(manager_cfg)
        for c in callback_set_cfg:
            manager.add_callback(
                name=c.get("name"),
                callback=build_from_cfg(c["callback_cfg"]),
            )
        manager.build()
        return manager

    def _build_transform_pipe(self, cfg: Optional[Dict]) -> Optional[Any]:
        if not cfg:
            return None
        manager = build_from_cfg(cfg.get("manager_cfg"))
        if manager is None:
            return None
        for t in cfg.get("transform_set", []):
            name = t.get("name")
            wrapper = build_from_cfg(t.get("wrapper_cfg"))
            if t.get("transform_cfg") is not None:
                manager.add_transform(name=name, transform=build_from_cfg(t["transform_cfg"]),
                                      wrapper=wrapper)
            elif t.get("transform_set") is not None and t.get("manager_cfg") is not None:
                manager.add_transform(name=name, transform=self._build_transform_pipe(t),
                                      wrapper=wrapper)
            else:
                raise RuntimeError("Must set transform_cfg or (transform_set + manager_cfg)")
        manager.build()
        return manager

    def _build_collate_pipe(self, cfg: Dict) -> Any:
        manager = build_from_cfg(cfg.get("manager_cfg"))
        for c in cfg.get("collate_fn_set", []):
            name = c.get("name")
            if c.get("collate_fn_cfg") is not None:
                manager.add_processor(name=name, processor=build_from_cfg(c["collate_fn_cfg"]))
            elif c.get("collate_fn_set") is not None and c.get("manager_cfg") is not None:
                manager.add_processor(name=name, processor=self._build_collate_pipe(c))
            else:
                raise RuntimeError("Must set collate_fn_cfg or (collate_fn_set + manager_cfg)")
        manager.build()
        return manager

    def _build_data_pipe(self, cfg: Dict) -> Tuple[Any, Optional[Any], Optional[Any], Any]:
        """Build: Transform → Dataset → Sampler → DataLoader."""
        if not cfg:
            raise ValueError("_build_data_pipe received an empty config.")

        transform_cfg = cfg.get('transform', {})
        item_transform = self._build_transform_pipe(transform_cfg.get('item_transform'))
        batch_transform = self._build_transform_pipe(transform_cfg.get('batch_transform'))

        dataset = build_from_cfg(cfg['dataset_cfg'],
                                 params_override={'transform': item_transform, 'is_main': self.is_main})

        seed = self.seed
        if self.reproducibility_manager:
            seed = self.reproducibility_manager.get_seed_with_safe_offset(offset=self.epoch_num)

        batch_sampler = build_from_cfg(cfg['batch_sampler_cfg'],
                                       params_override={ "dataset": dataset, "seed": seed})
        collate_fn = self._build_collate_pipe(cfg['collate_fn'])
        worker_init_fn, _ = build_from_cfg(cfg=cfg.get('worker_init_fn_cfg'), return_instance=False)
        generator = self.reproducibility_manager.get_generator() if self.reproducibility_manager else None

        dataloader = build_from_cfg(
            cfg['dataloader_cfg'],
            params_override={
                'dataset': dataset,
                'batch_sampler': batch_sampler,
                'collate_fn': collate_fn,
                'worker_init_fn': worker_init_fn,
                'generator': generator,
            },
        )

        return dataloader, batch_transform, batch_sampler, dataset.group_name_key

    # =========================================================================
    # Public Entry Point
    # =========================================================================

    def run(self, mode: str = "train_eval") -> None:
        """Execute the workflow."""
        logger.info(f"[Runner] Starting workflow — mode: {mode}")
        strategies = {
            "train_eval": self._strategy_train_eval_every_epoch,
            "train_only": self._strategy_train_only,
            "eval_only": self._strategy_eval_only,
            "train_final_eval": self._strategy_train_final_eval,
        }
        if mode not in strategies:
            raise ValueError(f"Unknown run mode: '{mode}'. Supported: {list(strategies.keys())}")

        self._safe_callback('on_begin')
        strategies[mode]()
        self._safe_callback('on_end')

    # =========================================================================
    # Callback Safety Helper
    # =========================================================================

    def _safe_callback(self, hook_name: str) -> None:
        """Safely trigger callbacks only if they are properly configured."""
        if self.callback_manager and hasattr(self.callback_manager, hook_name):
            getattr(self.callback_manager, hook_name)(self.run_context)

    # =========================================================================
    # High-Level Strategies
    # =========================================================================

    def _strategy_train_eval_every_epoch(self) -> None:
        self._safe_callback('on_train_begin')
        self._safe_callback('on_eval_begin')
        for epoch in range(self.epoch_num):
            self.run_args.cur_epoch_num += 1
            self._train_one_epoch(epoch=epoch)
            self.run_args.cur_epoch_num_of_eval += 1
            self._eval_one_epoch(epoch=epoch)
            if self.run_context.get_stop_requested():
                break
        self._safe_callback('on_train_end')
        self._safe_callback('on_eval_end')

    def _strategy_train_final_eval(self) -> None:
        self._safe_callback('on_train_begin')
        for epoch in range(self.epoch_num):
            self.run_args.cur_epoch_num += 1
            self._train_one_epoch(epoch=epoch)
            if self.run_context.get_stop_requested():
                break
        self._safe_callback('on_train_end')
        self._safe_callback('on_eval_begin')
        self._eval_one_epoch(epoch=1)
        self._safe_callback('on_eval_end')

    def _strategy_train_only(self) -> None:
        self._safe_callback('on_train_begin')
        for epoch in range(self.epoch_num):
            self.run_args.cur_epoch_num += 1
            self._train_one_epoch(epoch=epoch)
            if self.run_context.get_stop_requested():
                break
        self._safe_callback('on_train_end')

    def _strategy_eval_only(self) -> None:
        self.run_args.cur_epoch_num_of_eval += 1
        self._safe_callback('on_eval_begin')
        self._eval_one_epoch(epoch=1)
        self._safe_callback('on_eval_end')

    # =========================================================================
    # Batch Normalisation Helper
    # =========================================================================

    @staticmethod
    def _normalize_batch(batch) -> list:
        if isinstance(batch, list):
            return batch
        return [batch]

    # =========================================================================
    # Core Training Loop
    # =========================================================================

    # ------------------------------------------------------------------
    # FakeTensor detection helpers (torchair / NPU workaround)
    # ------------------------------------------------------------------

    @staticmethod
    def _has_fake_tensors(outputs: dict) -> bool:
        """Return ``True`` if any tensor in *outputs* is a FakeTensor."""
        try:
            from torch._subclasses.fake_tensor import FakeTensor
        except ImportError:
            return False
        for v in outputs.values():
            if isinstance(v, torch.Tensor) and isinstance(v, FakeTensor):
                return True
        return False

    def _warmup_compile(self, micro_inputs: dict) -> None:
        """Trigger compilation by running a throwaway forward pass."""
        logger.info("[Runner] Warmup forward pass to trigger compilation …")

        # ======== NPU TorchAir Dynamic Gears Injection ========
        try:
            compile_cfg = self.raw_cfg.get('model', {}).get('compile_inner', {}).get('params', {})
            if not compile_cfg or not compile_cfg.get('dynamic', False):
                compile_cfg = self.raw_cfg.get('model', {}).get('compile', {}).get('params', {})

            if compile_cfg.get('dynamic', False):
                gears_cfg = compile_cfg.get('dynamic_gears', None)
                if gears_cfg:
                    import torchair
                    for tensor_name, gear_dict in gears_cfg.items():
                        if tensor_name in micro_inputs:
                            # Convert YAML dict keys (e.g., '2': [128, 256]) to integers
                            parsed_gears = {int(dim): list(gears) for dim, gears in gear_dict.items()}
                            torchair.inference.set_dim_gears(micro_inputs[tensor_name], parsed_gears)
                            logger.info(f"[Runner] [TorchAir Gears] Bound {tensor_name} gears -> {parsed_gears}")
        except ImportError:
            logger.debug("[Runner] torchair not found; skipping dynamic gears setup.")
        except Exception as e:
            logger.warning(f"[Runner] TorchAir Dim Gears binding failed/ignored: {e}")
        # ========================================================

        with torch.no_grad():
            _out = self.network(**micro_inputs)
            if self._has_fake_tensors(_out):
                logger.warning("[Runner] Warmup produced FakeTensors — re-running...")
                _out2 = self.network(**micro_inputs)
            del _out
        logger.info("[Runner] Warmup complete.")

    # ------------------------------------------------------------------
    # Multi-Shape Warmup: pre-compile TBE/ACLNN kernels for all shapes
    # ------------------------------------------------------------------

    def _warmup_all_shapes(self) -> None:
        """Pre-compile TBE/ACLNN kernels for ALL tensor shape variants.

        On Ascend NPU, every unique tensor shape triggers a TBE kernel
        recompilation (~255s per shape change).  This method warms up
        all shape variants *before* training starts so that every
        subsequent forward pass hits the kernel cache.

        Shape sources (in priority order):
          1. Sample from ``self.train_loader`` (covers real shapes)
          2. Fall back to ``warmup_shapes`` list in runner_cfg params
        """
        if not self.train_loader or not self.network:
            return

        _device = next(self.network.parameters()).device
        seen_shapes: dict = {}  # shape_key -> shape_desc
        train_batch_transform = self.train_batch_transform

        logger.info("[Runner] ═══ Multi-Shape Warmup Start ═══")

        # --- Strategy 1: Sample from DataLoader ---
        max_warmup_batches = 30  # enough to see all condition groups
        try:
            warmup_iter = iter(self.train_loader)
            for batch_idx in range(max_warmup_batches):
                try:
                    batch = next(warmup_iter)
                except StopIteration:
                    break

                micro_batches = self._normalize_batch(batch)
                for mb in micro_batches:
                    # Apply transform to get model-ready inputs
                    if train_batch_transform is not None:
                        inputs = train_batch_transform(mb)
                    else:
                        inputs = mb

                    # Build a shape signature from all tensor values
                    shape_key = tuple(
                        (k, tuple(v.shape), str(v.dtype))
                        for k, v in sorted(inputs.items())
                        if isinstance(v, torch.Tensor)
                    )

                    if shape_key not in seen_shapes:
                        # Describe the shape for logging
                        shape_desc = {k: list(v.shape) for k, v in inputs.items() if isinstance(v, torch.Tensor)}
                        seen_shapes[shape_key] = shape_desc

                        # Run forward to trigger TBE compilation
                        with torch.no_grad():
                            _out = self.network(**inputs)
                            if self._has_fake_tensors(_out):
                                _out = self.network(**inputs)
                            del _out

                        # Synchronize to ensure compilation completes
                        self._synchronize()

                        logger.info(
                            "[Runner] Warmed shape #%d: %s",
                            len(seen_shapes), shape_desc,
                        )

        except Exception as e:
            logger.warning("[Runner] DataLoader sampling warmup failed: %s", e)

        # --- Strategy 2: Fall back to warmup_shapes config ---
        if len(seen_shapes) == 0:
            runner_params = (
                self.raw_cfg.get('workflow', {})
                .get('run', {})
                .get('runner_cfg', {})
                .get('params', {})
            )
            warmup_shapes_cfg = runner_params.get('warmup_shapes', [])
            if warmup_shapes_cfg:
                logger.info("[Runner] Using config warmup_shapes list (%d entries)", len(warmup_shapes_cfg))
                # Each entry is [B, C, D, H, W] — create dummy tensors
                for idx, shape in enumerate(warmup_shapes_cfg):
                    try:
                        # Get a reference input dict structure from first batch
                        ref_keys = list(self.train_loader.dataset[0].keys()) if hasattr(self.train_loader.dataset, '__getitem__') else []
                        # Create dummy with the specified shape on the target device
                        dummy_tensor = torch.zeros(shape, dtype=torch.bfloat16, device=_device)
                        dummy_inputs = {'bout': dummy_tensor}
                        with torch.no_grad():
                            _out = self.network(**dummy_inputs)
                            del _out
                        self._synchronize()
                        logger.info("[Runner] Warmed config shape #%d: %s", idx + 1, shape)
                    except Exception as e:
                        logger.warning("[Runner] Config shape warmup failed for %s: %s", shape, e)

        logger.info(
            "[Runner] ═══ Multi-Shape Warmup Done: %d unique shapes compiled ═══",
            len(seen_shapes),
        )

    @torch._dynamo.disable(recursive=False)
    def _train_one_epoch(self, epoch) -> None:
        if not self.train_loader or not self.train_loss or not self.optimizer:
            logger.warning("[Runner] Training skipped: loader, loss or optimizer missing.")
            return

        self.network.train()
        self.run_args.mode = "train"
        if self.metric_in_train:
            self.metric_in_train.reset()

        self.optimizer.zero_grad()
        self._safe_callback('on_train_epoch_begin')

        if hasattr(self.train_batch_sampler, 'set_epoch'):
            self.train_batch_sampler.set_epoch(self.run_args.cur_epoch_num)

        loss_fn_full = self.train_loss
        loss_fn_light = self.train_loss_light      # None if not configured
        train_batch_transform = self.train_batch_transform

        self.run_args.batch_num = len(self.train_loader)
        is_debug = (self.log_level <= logging.DEBUG)

        last_step_end = time.perf_counter() if is_debug else 0.0
        for step, batch in enumerate(self.train_loader):
            self.run_args.cur_step_num += 1
            train_loss = 0.0

            # ── SuperBatch 级别 loss 切换 ─────────────────────────────────
            # light_loss_interval=N: 每 N 个 step 用一次 full loss，其余用 light
            # light_loss_interval=0 或未配置 light loss: 始终 full
            _interval = self._light_loss_interval
            if loss_fn_light is not None and _interval > 0:
                use_full = (step % _interval == 0)
                loss_fn = loss_fn_full if use_full else loss_fn_light
            else:
                use_full = True
                loss_fn = loss_fn_full

            self._safe_callback('on_train_step_begin')
            step_start = time.perf_counter() if is_debug else 0.0

            micro_batches = self._normalize_batch(batch)
            accum_steps = len(micro_batches)

            train_raw_losses = dict()
            timing_stats = {}
            fwd_time, bwd_time, trans_time = 0.0, 0.0, 0.0
            if is_debug:
                timing_stats = {"data": step_start - last_step_end, "loss_mode": "full" if use_full else "light"}

            # ── DataPrefetcher: overlap transform+H2D with fwd+bwd ──
            _device = next(self.network.parameters()).device
            prefetcher = DataPrefetcher(train_batch_transform, _device)

            # Pre-transform the first micro_batch (async on prefetch stream)
            if is_debug: ts_start = time.perf_counter()
            next_inputs = prefetcher.prefetch(micro_batches[0])

            for i, micro_batch in enumerate(micro_batches):
                micro_batch_group_name = micro_batch.get(self.train_group_name_key)
                is_last_micro = (i == accum_steps - 1)
                ctx = loss_fn.get_sync_context(is_last_micro)

                with ctx:
                    # Wait for the current prefetch to finish
                    prefetcher.wait()
                    micro_inputs = next_inputs

                    if is_debug:
                        self._synchronize()
                        trans_time += (time.perf_counter() - ts_start)

                    # Start prefetching next micro_batch (overlaps with fwd+bwd)
                    if i + 1 < accum_steps:
                        if is_debug: ts_start = time.perf_counter()
                        next_inputs = prefetcher.prefetch(micro_batches[i + 1])

                    if not getattr(self, '_compile_warmed_up', False):
                        self._compile_warmed_up = True
                        # Multi-shape warmup: pre-compile TBE for ALL shape variants
                        self._warmup_all_shapes()
                        # Also do single-shape warmup for torchair gears if configured
                        self._warmup_compile(micro_inputs)

                    if is_debug: f_start = time.perf_counter()
                    micro_outputs = self.network(**micro_inputs)
                    if self._has_fake_tensors(micro_outputs):
                        micro_outputs = self.network(**micro_inputs)
                    if is_debug:
                        self._synchronize()
                        fwd_time += (time.perf_counter() - f_start)

                    if is_debug: b_start = time.perf_counter()
                    loss_val, raw_losses = loss_fn.backward_step(
                        accum_steps=accum_steps,
                        is_last_micro=is_last_micro,
                        **micro_outputs,
                    )
                    if is_debug:
                        self._synchronize()
                        bwd_time += (time.perf_counter() - b_start)

                    if is_debug:
                        cur_bwd_end = time.perf_counter()
                        logger.debug(
                            "Step %d MicroBatch %d [%s] timing: trans=%.4f, fwd=%.4f, bwd=%.4f",
                            step, i, micro_batch_group_name,
                            trans_time,                               # cumulative transform time
                            cur_bwd_end - f_start,                    # cumulative from fwd start
                            cur_bwd_end - b_start                     # bwd only
                        )

                    train_loss += loss_val
                    raw_losses["train_running_loss"] = loss_val * accum_steps
                    train_raw_losses[micro_batch_group_name] = raw_losses

                    if self.metric_in_train:
                        self.metric_in_train.update(**micro_outputs)

            opt_start = 0.0
            if is_debug: opt_start = time.perf_counter()
            self.optimizer.step()
            if self.lr_scheduler:
                self.lr_scheduler.step()
            # set_to_none=True: 用 None 替代零张量，减少内存访问和 kernel launch
            # 在 CUDA 和 NPU 上均有收益（避免 memset 操作）
            self.optimizer.zero_grad(set_to_none=True)

            if self.train_loss_weight_optimizer is not None:
                self.train_loss_weight_optimizer.step()
                self.train_loss_weight_optimizer.zero_grad()
                loss_fn.weight_strategy.normalise_weights()
            
            if is_debug:
                opt_end = time.perf_counter()
                timing_stats.update({
                    "trans": trans_time,
                    "fwd": fwd_time,
                    "bwd": bwd_time,
                    "opt": opt_end - opt_start,
                    "total": time.perf_counter() - step_start
                })
                logger.info("Step %d timing: %s", step, timing_stats)
            elif step % 10 == 0:
                logger.info("Step %d finished", step)

            self.run_args.train_loss = train_loss
            self.run_args.train_raw_losses = train_raw_losses
            self._safe_callback('on_train_step_end')

            if self.run_context.get_stop_requested():
                break

            last_step_end = time.perf_counter()

        if self.metric_in_train:
            self.run_args.train_metrics = self.metric_in_train.compute()

        self._safe_callback('on_train_epoch_end')

    # =========================================================================
    # Core Evaluation Loop
    # =========================================================================

    @torch._dynamo.disable(recursive=False)
    def _eval_one_epoch(self, epoch) -> None:
        if not self.eval_loader or not self.eval_loss:
            logger.warning("[Runner] Evaluation skipped: eval loader or eval loss missing.")
            return

        self.network.eval()
        self.run_args.mode = "eval"
        if self.metric_in_eval:
            self.metric_in_eval.reset()

        self._safe_callback('on_eval_epoch_begin')

        if hasattr(self.eval_batch_sampler, 'set_epoch'):
            self.eval_batch_sampler.set_epoch(self.run_args.cur_epoch_num_of_eval)

        eval_loss_fn = self.eval_loss
        eval_batch_transform = self.eval_batch_transform

        is_debug = (self.log_level <= logging.DEBUG)
        
        last_step_end = time.perf_counter() if is_debug else 0.0
        with torch.no_grad():
            for step, batch in enumerate(self.eval_loader):
                self.run_args.cur_step_num_of_eval += 1
                eval_loss = 0.0

                self._safe_callback('on_eval_step_begin')
                step_start = time.perf_counter() if is_debug else 0.0

                micro_batches = self._normalize_batch(batch)
                accum_steps = len(micro_batches)

                eval_raw_losses = dict()
                timing_stats = {}
                fwd_time, trans_time = 0.0, 0.0
                if is_debug:
                    timing_stats = {"data": step_start - last_step_end}

                for i, micro_batch in enumerate(micro_batches):
                    micro_batch_group_name = micro_batch.get(self.eval_group_name_key)
                    
                    if is_debug: ts_start = time.perf_counter()
                    micro_inputs = (eval_batch_transform(micro_batch)
                                    if eval_batch_transform is not None
                                    else micro_batch)
                    if is_debug:
                        self._synchronize()
                        trans_time += (time.perf_counter() - ts_start)

                    if not getattr(self, '_compile_warmed_up', False):
                        self._compile_warmed_up = True
                        self._warmup_compile(micro_inputs)

                    if is_debug: f_start = time.perf_counter()
                    micro_outputs = self.network(**micro_inputs)
                    if self._has_fake_tensors(micro_outputs):
                        micro_outputs = self.network(**micro_inputs)
                    if is_debug:
                        self._synchronize()
                        fwd_time += (time.perf_counter() - f_start)

                    if is_debug:
                        cur_trans = time.perf_counter() - ts_start
                        cur_fwd = time.perf_counter() - f_start
                        logger.debug(
                            "Eval Step %d MicroBatch %d [%s] timing: trans=%.4f, fwd=%.4f",
                            step, i, micro_batch_group_name,
                            cur_trans, cur_fwd
                        )

                    loss_val, raw_losses = eval_loss_fn.eval_step(
                        accum_steps=accum_steps,
                        **micro_outputs,
                    )

                   