import torch
from tqdm import tqdm
from ......core.general.builder.config_builder import build_from_cfg


def build_dataloader(cfg, dataset, sampler=None, collate_fn=None):
    args = {'dataset': dataset}
    if sampler: args['sampler'] = sampler
    if collate_fn: args['collate_fn'] = collate_fn
    return build_from_cfg(cfg, params_override=args)


class StandardRunner:
    def __init__(self, raw_cfg, **kwargs):
        self.raw_cfg = raw_cfg

        self.max_epochs = kwargs.get('max_epochs', 1)
        self.work_dir = kwargs.get('work_dir', './workspace/output')

        # 1. Engine & Model
        self.engine = build_from_cfg(self.raw_cfg['workflow']['run']['engine'])
        self.model = build_from_cfg(self.raw_cfg['model'])

        # 2. Data
        self.train_loader = self._build_pipe(self.raw_cfg['data']['train_pipeline'])
        self.val_loader = self._build_pipe(self.raw_cfg['data']['val_pipeline'])

        # 3. Optim & Loss
        train_cfg = self.raw_cfg['workflow']['train']
        self.optimizer = build_from_cfg(train_cfg['optimizer'], params_override={'params': self.model.parameters()})
        self.criterion = build_from_cfg(train_cfg['loss'])

        # 4. Metric & Callbacks
        self.metric = build_from_cfg(self.raw_cfg['workflow'].get('eval', {}).get('metric'))

        self.callbacks = []
        if 'callback' in self.raw_cfg['workflow']:
            for cb in self.raw_cfg['workflow']['callback']:
                if 'params' not in cb: cb['params'] = {}
                cb['params']['save_dir'] = self.work_dir
                self.callbacks.append(build_from_cfg(cb))

        # 5. Prepare
        self.model, self.optimizer, self.train_loader, self.val_loader = \
            self.engine.prepare(self.model, self.optimizer, self.train_loader, self.val_loader)

    def _build_pipe(self, cfg):
        tf = build_from_cfg(cfg.get('transform'))
        ds = build_from_cfg(cfg['dataset'], params_override={'transform': tf})
        return build_dataloader(cfg['dataloader'], dataset=ds)

    def _call_hook(self, event, **kwargs):
        for cb in self.callbacks:
            if hasattr(cb, event): getattr(cb, event)(self, **kwargs)

    def run(self):
        self._call_hook('on_train_begin')
        self.engine.print(f"Start Training: {self.max_epochs} Epochs")

        for epoch in range(self.max_epochs):
            self.model.train()
            pbar = tqdm(self.train_loader, desc=f"Epoch {epoch+1}", disable=not self.engine.is_main)

            for imgs, labels in pbar:
                outputs = self.model(imgs)
                loss = self.criterion(outputs, labels)
                self.engine.backward(loss)
                self.optimizer.step()
                self.optimizer.zero_grad()
                pbar.set_postfix(loss=loss.item())

            metrics = self._evaluate()
            self._call_hook('on_eval_end', metrics=metrics)
        if hasattr(self.engine, 'close'):
            self.engine.close()


    def _evaluate(self):
        if not self.val_loader or not self.metric: return {}
        self.model.eval()
        self.metric.reset()
        with torch.no_grad():
            for imgs, labels in self.val_loader:
                outputs = self.model(imgs)
                self.metric.update(outputs, labels)
        acc = self.metric.compute()
        self.engine.print(f"  Eval Acc: {acc:.4%}")
        return {'accuracy': acc}