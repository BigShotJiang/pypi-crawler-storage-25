# -*- coding: utf-8 -*-
"""
Masked regression losses.

Provides MSE and MAE losses that support masking for ignoring certain positions
during loss computation. Useful for handling missing data, padding, or region-specific
training.
"""

from typing import Optional

import torch
import torch.nn as nn
from torch import Tensor


__all__ = ['MaskedMSE', 'MaskedMAE']


class MaskedMSE(nn.Module):
    """
    Masked Mean Squared Error Loss.

    Computes MSE only on positions where mask is True/1. Useful for:
    - Ignoring padding in sequences
    - Handling missing data
    - Region-specific loss computation
    - Multi-task learning with variable outputs

    Parameters
    ----------
    reduction : str
        Specifies the reduction to apply to the output:
        - 'mean' (default): Returns the mean of masked losses
        - 'sum': Returns the sum of masked losses
        - 'none': No reduction, returns per-element losses

    Examples
    --------
    >>> # Basic usage with mask
    >>> criterion = MaskedMSE()
    >>> pred = torch.randn(10, 5)
    >>> target = torch.randn(10, 5)
    >>> mask = torch.randint(0, 2, (10, 5)).bool()  # Random binary mask
    >>> loss = criterion(pred, target, mask)
    >>>
    >>> # Without mask (equivalent to nn.MSELoss)
    >>> loss = criterion(pred, target)
    >>>
    >>> # Sum reduction
    >>> criterion_sum = MaskedMSE(reduction='sum')
    >>> loss_sum = criterion_sum(pred, target, mask)
    >>>
    >>> # No reduction (per-element losses)
    >>> criterion_none = MaskedMSE(reduction='none')
    >>> losses = criterion_none(pred, target, mask)  # Shape: (10, 5)

    Notes
    -----
    - When mask is None, behaves like standard nn.MSELoss
    - For reduction='mean', divides by number of valid (masked) elements
    - Mask can be boolean (True/False) or binary (1/0)
    - Broadcast rules apply: mask can have fewer dimensions than input/target
    """

    def __init__(self, reduction: str = 'mean'):
        """
        Initialize MaskedMSE.

        Parameters
        ----------
        reduction : str
            Reduction method: 'mean', 'sum', or 'none'

        Raises
        ------
        ValueError
            If reduction is not one of 'mean', 'sum', 'none'
        """
        super().__init__()
        if reduction not in ['mean', 'sum', 'none']:
            raise ValueError(
                f"Invalid reduction '{reduction}'. Must be 'mean', 'sum', or 'none'."
            )
        self.reduction = reduction

    def forward(
        self,
        input: Tensor,
        target: Tensor,
        mask: Optional[Tensor] = None
    ) -> Tensor:
        """
        Compute masked MSE loss.

        Parameters
        ----------
        input : Tensor
            Predicted values, shape (*)
        target : Tensor
            Ground truth values, shape (*)
        mask : Optional[Tensor]
            Boolean or binary mask, shape (*) or broadcastable
            - True/1: Include in loss computation
            - False/0: Exclude from loss computation
            If None, all elements are included (standard MSE)

        Returns
        -------
        Tensor
            Scalar loss (if reduction='mean' or 'sum')
            or per-element losses (if reduction='none')

        Examples
        --------
        >>> criterion = MaskedMSE()
        >>>
        >>> # 1D example
        >>> pred = torch.tensor([1.0, 2.0, 3.0, 4.0])
        >>> target = torch.tensor([1.5, 2.5, 3.5, 4.5])
        >>> mask = torch.tensor([1, 1, 0, 1])  # Ignore 3rd element
        >>> loss = criterion(pred, target, mask)
        >>> # Computes: mean([(1-1.5)^2, (2-2.5)^2, (4-4.5)^2]) = 0.25
        >>>
        >>> # 2D example (batch of sequences)
        >>> pred = torch.randn(32, 100, 512)  # (batch, seq_len, features)
        >>> target = torch.randn(32, 100, 512)
        >>> mask = torch.ones(32, 100, 1).bool()  # Mask by sequence position
        >>> mask[:, 80:, :] = 0  # Ignore last 20 positions (padding)
        >>> loss = criterion(pred, target, mask)
        """
        # Compute squared error
        squared_error = (input - target) ** 2

        if mask is not None:
            # Convert mask to same dtype as loss for multiplication
            if mask.dtype == torch.bool:
                mask = mask.float()

            # Apply mask
            masked_loss = squared_error * mask

            if self.reduction == 'mean':
                # Mean over valid (masked) elements
                num_valid = mask.sum().clamp(min=1)  # Avoid division by zero
                return masked_loss.sum() / num_valid
            elif self.reduction == 'sum':
                return masked_loss.sum()
            else:  # 'none'
                return masked_loss
        else:
            # No mask: standard MSE behavior
            if self.reduction == 'mean':
                return squared_error.mean()
            elif self.reduction == 'sum':
                return squared_error.sum()
            else:  # 'none'
                return squared_error

    def extra_repr(self) -> str:
        """Return extra representation string."""
        return f'reduction={self.reduction}'


class MaskedMAE(nn.Module):
    """
    Masked Mean Absolute Error Loss.

    Computes MAE (L1 loss) only on positions where mask is True/1. Useful for:
    - Ignoring padding in sequences
    - Handling missing data
    - Region-specific loss computation
    - Multi-task learning with variable outputs

    Parameters
    ----------
    reduction : str
        Specifies the reduction to apply to the output:
        - 'mean' (default): Returns the mean of masked losses
        - 'sum': Returns the sum of masked losses
        - 'none': No reduction, returns per-element losses

    Examples
    --------
    >>> # Basic usage with mask
    >>> criterion = MaskedMAE()
    >>> pred = torch.randn(10, 5)
    >>> target = torch.randn(10, 5)
    >>> mask = torch.randint(0, 2, (10, 5)).bool()  # Random binary mask
    >>> loss = criterion(pred, target, mask)
    >>>
    >>> # Without mask (equivalent to nn.L1Loss)
    >>> loss = criterion(pred, target)
    >>>
    >>> # Sum reduction
    >>> criterion_sum = MaskedMAE(reduction='sum')
    >>> loss_sum = criterion_sum(pred, target, mask)
    >>>
    >>> # No reduction (per-element losses)
    >>> criterion_none = MaskedMAE(reduction='none')
    >>> losses = criterion_none(pred, target, mask)  # Shape: (10, 5)

    Notes
    -----
    - When mask is None, behaves like standard nn.L1Loss
    - For reduction='mean', divides by number of valid (masked) elements
    - Mask can be boolean (True/False) or binary (1/0)
    - Broadcast rules apply: mask can have fewer dimensions than input/target
    """

    def __init__(self, reduction: str = 'mean'):
        """
        Initialize MaskedMAE.

        Parameters
        ----------
        reduction : str
            Reduction method: 'mean', 'sum', or 'none'

        Raises
        ------
        ValueError
            If reduction is not one of 'mean', 'sum', 'none'
        """
        super().__init__()
        if reduction not in ['mean', 'sum', 'none']:
            raise ValueError(
                f"Invalid reduction '{reduction}'. Must be 'mean', 'sum', or 'none'."
            )
        self.reduction = reduction

    def forward(
        self,
        input: Tensor,
        target: Tensor,
        mask: Optional[Tensor] = None
    ) -> Tensor:
        """
        Compute masked MAE loss.

        Parameters
        ----------
        input : Tensor
            Predicted values, shape (*)
        target : Tensor
            Ground truth values, shape (*)
        mask : Optional[Tensor]
            Boolean or binary mask, shape (*) or broadcastable
            - True/1: Include in loss computation
            - False/0: Exclude from loss computation
            If None, all elements are included (standard MAE)

        Returns
        -------
        Tensor
            Scalar loss (if reduction='mean' or 'sum')
            or per-element losses (if reduction='none')

        Examples
        --------
        >>> criterion = MaskedMAE()
        >>>
        >>> # 1D example
        >>> pred = torch.tensor([1.0, 2.0, 3.0, 4.0])
        >>> target = torch.tensor([1.5, 2.5, 3.5, 4.5])
        >>> mask = torch.tensor([1, 1, 0, 1])  # Ignore 3rd element
        >>> loss = criterion(pred, target, mask)
        >>> # Computes: mean([|1-1.5|, |2-2.5|, |4-4.5|]) = 0.5
        >>>
        >>> # 2D example (batch of images with valid regions)
        >>> pred = torch.randn(8, 3, 256, 256)  # (batch, channels, H, W)
        >>> target = torch.randn(8, 3, 256, 256)
        >>> mask = torch.ones(8, 1, 256, 256).bool()  # Mask by spatial location
        >>> mask[:, :, :50, :] = 0  # Ignore top 50 rows
        >>> loss = criterion(pred, target, mask)
        """
        # Compute absolute error
        absolute_error = torch.abs(input - target)

        if mask is not None:
            # Convert mask to same dtype as loss for multiplication
            if mask.dtype == torch.bool:
                mask = mask.float()

            # Apply mask
            masked_loss = absolute_error * mask

            if self.reduction == 'mean':
                # Mean over valid (masked) elements
                num_valid = mask.sum().clamp(min=1)  # Avoid division by zero
                return masked_loss.sum() / num_valid
            elif self.reduction == 'sum':
                return masked_loss.sum()
            else:  # 'none'
                return masked_loss
        else:
            # No mask: standard MAE behavior
            if self.reduction == 'mean':
                return absolute_error.mean()
            elif self.reduction == 'sum':
                return absolute_error.sum()
            else:  # 'none'
                return absolute_error

    def extra_repr(self) -> str:
        """Return extra representation string."""
        return f'reduction={self.reduction}'
