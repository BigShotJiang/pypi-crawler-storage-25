# -*- coding: utf-8 -*-
"""
Loss managers for managing and combining multiple loss functions.

This package provides managers for combining multiple loss functions with
configurable weights, priorities, and input transformations, as well as a
suite of dynamic weighting strategies.

Managers
--------
DirectLossManager   All losses receive the same args/kwargs (broadcast).
ListLossManager     Losses select args by positional index.
DictLossManager     Losses remap kwargs by key.

All managers accept an optional ``weight_strategy`` parameter.  When set,
the strategy replaces static per-loss weights for the weighting step.

Weight strategies
-----------------
Static
    StaticWeightStrategy        Fixed scalar weights (default behaviour).

Loss-value (transparent to training loop)
    UncertaintyWeightStrategy   Learnable uncertainty (UW). Kendall 2018.
    DWAStrategy                 Dynamic Weight Averaging. Liu 2019.
    RLWStrategy                 Random (Dirichlet) weighting. Lin 2022.

Gradient-level (require custom training loop)
    GradNormStrategy            Gradient normalisation. Chen 2018.
    PCGradStrategy              Project Conflicting Gradients. Yu 2020.
    CAGradStrategy              Conflict-Averse Gradient Descent. Liu 2021.
"""

from .weight_strategy import (
    BaseWeightStrategy,
    StaticWeightStrategy,
    UncertaintyWeightStrategy,
    DWAStrategy,
    RLWStrategy,
    GradNormStrategy,
    PCGradStrategy,
    CAGradStrategy,
)
from ..base import BaseLossManager
from .direct_manager import DirectLossManager, DirectLossWrapper
from .list_manager import ListLossManager, ListLossWrapper
from .dict_manager import DictLossManager, DictLossWrapper

__all__ = [
    # Weight strategies
    'BaseWeightStrategy',
    'StaticWeightStrategy',
    'UncertaintyWeightStrategy',
    'DWAStrategy',
    'RLWStrategy',
    'GradNormStrategy',
    'PCGradStrategy',
    'CAGradStrategy',
    # Base manager
    'BaseLossManager',
    # Direct manager
    'DirectLossManager',
    'DirectLossWrapper',
    # List manager
    'ListLossManager',
    'ListLossWrapper',
    # Dict manager
    'DictLossManager',
    'DictLossWrapper',
]
