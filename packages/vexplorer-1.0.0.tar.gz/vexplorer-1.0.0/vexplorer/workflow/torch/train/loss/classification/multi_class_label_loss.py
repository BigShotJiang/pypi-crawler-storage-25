import torch
import torch.nn as nn
import torch.nn.functional as F
from typing import Optional, List


class MultiClassWindowLoss(nn.Module):
    """
    Multi-Class Cross Entropy Loss across multiple temporal prediction windows.

    This loss is designed for mutually exclusive classification tasks where a sample
    can only belong to exactly ONE class within a specific time window.

    Internally, it safely reshapes multi-window predictions to bypass PyTorch's
    strict `[Batch, Classes, ...]` dimensional requirements. It leverages PyTorch's
    highly optimized `F.cross_entropy`, which natively combines `LogSoftmax` and
    `NLLLoss` for maximum numerical stability.

    Parameters
    ----------
    num_windows : int
        The number of temporal prediction windows (e.g., 3 for predicting 12h, 24h, 48h).
    num_classes : int
        The number of mutually exclusive classes (e.g., 4 for [Quiet, C, M, X]).
    class_weights : List[float], optional
        A list of static weights for each class, useful for mitigating severe class
        imbalance. Length must exactly match `num_classes`. Default: None.
    reduction : str, optional
        Specifies the reduction to apply to the output:
        ``'none'`` | ``'mean'`` | ``'sum'``. Default: ``'mean'``.

    Shape
    -----
    - pred_logits: ``(N, num_windows, num_classes)`` or flattened ``(N, num_windows * num_classes)``.
      These must be raw, unnormalized scores (no Softmax applied).
    - target: ``(N, num_windows, num_classes)`` or flattened ``(N, num_windows * num_classes)``.
      Modern PyTorch (>=1.10) supports targets as either one-hot encoded floats
      (e.g., [0., 1., 0., 0.]) or class indices (LongTensors).
    - Output: Scalar if ``reduction`` is 'mean' or 'sum'. If 'none', returns a tensor
      of shape ``(N * num_windows,)``.

    Examples
    --------
    >>> criterion = MultiClassWindowLoss(num_windows=3, num_classes=4, class_weights=[0.1, 1.0, 5.0, 20.0])
    >>> # Batch Size = 2. Raw logits without Softmax.
    >>> logits = torch.randn(2, 3 * 4, requires_grad=True)
    >>> # Targets in one-hot format
    >>> target_indices = torch.tensor([[0, 1, 2], [1, 2, 3]]) # B=2, W=3
    >>> target_onehot = F.one_hot(target_indices, num_classes=4).float().view(2, -1)
    >>>
    >>> loss = criterion(logits, target_onehot)
    >>> loss.backward()
    >>> print(loss.item())
    """
    def __init__(
            self,
            num_windows: int,
            num_classes: int,
            class_weights: Optional[List[float]] = None,
            reduction: str = 'mean'
    ):
        super().__init__()
        self.num_windows = num_windows
        self.num_classes = num_classes
        self.reduction = reduction

        if class_weights is not None:
            if len(class_weights) != num_classes:
                raise ValueError(f"Length of class_weights ({len(class_weights)}) must match num_classes ({num_classes}).")
            # Register as buffer so it moves to GPU/CPU automatically with the model
            self.register_buffer('weight', torch.tensor(class_weights, dtype=torch.float32))
        else:
            self.weight = None

    def forward(self, pred_logits: torch.Tensor, target: torch.Tensor) -> torch.Tensor:
        # 1. Flatten into 2D shape: (Batch * Windows, Classes)
        # This prevents the dimension mismatch trap in F.cross_entropy
        pred = pred_logits.view(-1, self.num_classes)
        target = target.view(-1, self.num_classes)

        # 2. Ensure target is float for cross_entropy with one-hot labels
        if target.dtype != torch.long and target.dtype != torch.float32:
            target = target.float()

        # 3. Compute stable Cross Entropy Loss
        loss = F.cross_entropy(
            pred,
            target,
            weight=self.weight,
            reduction=self.reduction
        )

        return loss


class MultiLabelWindowLoss(nn.Module):
    """
    Multi-Label Binary Cross Entropy Loss across multiple temporal prediction windows.

    This loss is designed for non-exclusive, multi-label classification tasks where
    a sample can simultaneously trigger multiple classes within a single time window.
    (e.g., Cumulative Solar Flare Evaluation: simultaneously satisfying >=C and >=M thresholds).

    Internally, it utilizes `F.binary_cross_entropy_with_logits`. This treats the
    prediction for every single class as an independent binary classification task,
    applying a Sigmoid activation internally for optimal numerical stability.

    Parameters
    ----------
    num_windows : int
        The number of temporal prediction windows.
    num_classes : int
        The number of independent, non-exclusive classes.
    pos_weights : List[float], optional
        A list of weights applied to the positive examples of each class.
        Crucial for highly imbalanced datasets where certain labels (e.g., X-class)
        are extremely rare. Length must exactly match `num_classes`. Default: None.
    reduction : str, optional
        Specifies the reduction to apply to the output:
        ``'none'`` | ``'mean'`` | ``'sum'``. Default: ``'mean'``.

    Shape
    -----
    - pred_logits: ``(N, num_windows, num_classes)`` or flattened ``(N, num_windows * num_classes)``.
      These must be raw, unnormalized scores (no Sigmoid applied).
    - target_multilabel: ``(N, num_windows, num_classes)`` or flattened ``(N, num_windows * num_classes)``.
      Values must be floats, typically 0.0 or 1.0. A single row can contain multiple 1.0s.
    - Output: Scalar if ``reduction`` is 'mean' or 'sum'. If 'none', returns a tensor
      of shape ``(N * num_windows, num_classes)``.

    Examples
    --------
    >>> criterion = MultiLabelWindowLoss(num_windows=3, num_classes=3, pos_weights=[1.0, 5.0, 20.0])
    >>> # Batch Size = 2. Raw logits without Sigmoid.
    >>> logits = torch.randn(2, 3 * 3, requires_grad=True)
    >>> # Targets in multi-hot format (cumulative logic)
    >>> # e.g., an M-class flare satisfies >=C (index 0) and >=M (index 1)
    >>> target_multilabel = torch.tensor([
    ...     [1., 1., 0.,   1., 0., 0.,   0., 0., 0.], # Batch 1: M-class, C-class, Quiet
    ...     [1., 1., 1.,   1., 1., 0.,   1., 0., 0.]  # Batch 2: X-class, M-class, C-class
    ... ])
    >>>
    >>> loss = criterion(logits, target_multilabel)
    >>> loss.backward()
    >>> print(loss.item())
    """
    def __init__(
            self,
            num_windows: int,
            num_classes: int,
            pos_weights: Optional[List[float]] = None,
            reduction: str = 'mean'
    ):
        super().__init__()
        self.num_windows = num_windows
        self.num_classes = num_classes
        self.reduction = reduction

        if pos_weights is not None:
            if len(pos_weights) != num_classes:
                raise ValueError(f"Length of pos_weights ({len(pos_weights)}) must match num_classes ({num_classes}).")
            # Register as buffer so it moves to GPU/CPU automatically with the model
            self.register_buffer('pos_weight', torch.tensor(pos_weights, dtype=torch.float32))
        else:
            self.pos_weight = None

    def forward(self, pred_logits: torch.Tensor, target_multilabel: torch.Tensor) -> torch.Tensor:
        # 1. Flatten into 2D shape: (Batch * Windows, Classes)
        pred = pred_logits.view(-1, self.num_classes)
        target = target_multilabel.view(-1, self.num_classes)

        # 2. BCE requires float targets
        if target.dtype != torch.float32:
            target = target.float()

        # 3. Compute independent Binary Cross Entropy for each class
        loss = F.binary_cross_entropy_with_logits(
            pred,
            target,
            pos_weight=self.pos_weight,
            reduction=self.reduction
        )

        return loss



class MultiClassWindowMap(nn.Module):
    """
    Applies Softmax activation over multiple temporal windows for mutually exclusive classes.

    This module converts raw model logits into normalized probability distributions
    where the probabilities for all classes within a single time window sum to 1.0.
    It safely reshapes the input to isolate the class dimension before applying Softmax.

    Parameters
    ----------
    num_windows : int
        The number of temporal prediction windows (e.g., 3 for 12h, 24h, 48h).
    num_classes : int
        The number of mutually exclusive classes (e.g., 4 for [Quiet, C, M, X]).

    Shape
    -----
    - Input: ``(N, num_windows, num_classes)`` or flattened ``(N, num_windows * num_classes)``,
      where N is the batch size. Contains raw, unnormalized logits.
    - Output: ``(N, num_windows, num_classes)``. The output is always forced into this
      clean 3D structure for easier downstream metric calculation. Values are in the range [0, 1].

    Examples
    --------
    >>> mapper = MultiClassWindowMap(num_windows=2, num_classes=3)
    >>> # Batch Size = 1. Raw logits flattened (e.g., output from a Linear layer)
    >>> logits = torch.tensor([[10.0, 1.0, 0.1,   # Window 1: High confidence in Class 0
    ...                         1.0, 2.0, 5.0]])  # Window 2: High confidence in Class 2
    >>>
    >>> probabilities = mapper(logits)
    >>> print(probabilities.shape)
    torch.Size([1, 2, 3])
    >>> print(torch.round(probabilities * 1000) / 1000) # Rounded for readability
    tensor([[[1.0000, 0.0001, 0.0000],
             [0.0179, 0.0486, 0.9335]]])
    """
    def __init__(self, num_windows: int, num_classes: int):
        super().__init__()
        self.num_windows = num_windows
        self.num_classes = num_classes

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        # 1. Force the shape to (Batch, Windows, Classes)
        # -1 automatically infers the batch size from the total elements
        x = x.view(-1, self.num_windows, self.num_classes)

        # 2. Apply Softmax strictly across the last dimension (the Classes)
        probabilities = F.softmax(x, dim=-1)

        return probabilities


class MultiLabelWindowMap(nn.Module):
    """
    Applies Sigmoid activation over multiple temporal windows for non-exclusive multi-labels.

    This module converts raw model logits into independent probabilities for each class.
    Unlike Softmax, the probabilities within a single time window do NOT sum to 1.0.
    This is designed for cumulative/multi-label tasks where a sample can trigger
    multiple thresholds simultaneously (e.g., a flux that is both >=C and >=M).

    Parameters
    ----------
    num_windows : int
        The number of temporal prediction windows.
    num_classes : int
        The number of independent, non-exclusive classes.

    Shape
    -----
    - Input: ``(N, num_windows, num_classes)`` or flattened ``(N, num_windows * num_classes)``,
      where N is the batch size. Contains raw, unnormalized logits.
    - Output: ``(N, num_windows, num_classes)``. The output is always structured into this
      3D shape. Values are in the range [0, 1].

    Examples
    --------
    >>> mapper = MultiLabelWindowMap(num_windows=2, num_classes=2)
    >>> # Batch Size = 1. Raw logits flattened.
    >>> # A logit of 0.0 equals exactly 50% probability after Sigmoid.
    >>> logits = torch.tensor([[0.0, 5.0,    # Window 1: 50% for class 0, ~99% for class 1
    ...                         -5.0, 0.0]]) # Window 2: ~1% for class 0, 50% for class 1
    >>>
    >>> probabilities = mapper(logits)
    >>> print(probabilities.shape)
    torch.Size([1, 2, 2])
    >>> print(torch.round(probabilities * 1000) / 1000) # Rounded for readability
    tensor([[[0.5000, 0.9933],
             [0.0067, 0.5000]]])
    """
    def __init__(self, num_windows: int, num_classes: int):
        super().__init__()
        self.num_windows = num_windows
        self.num_classes = num_classes

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        # 1. Force the shape to (Batch, Windows, Classes)
        # This provides a consistent 3D tensor format for easier evaluation and thresholding
        x = x.view(-1, self.num_windows, self.num_classes)

        # 2. Apply Sigmoid element-wise
        # Each logit is independently mapped to a [0, 1] probability
        probabilities = torch.sigmoid(x)

        return probabilities



