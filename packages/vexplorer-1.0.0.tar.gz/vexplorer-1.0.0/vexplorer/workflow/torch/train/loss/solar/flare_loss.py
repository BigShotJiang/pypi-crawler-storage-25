import torch
import torch.nn as nn
import torch.nn.functional as F
from typing import List, Optional, Union, Dict

import  logging
logger = logging.getLogger(__name__)

class FluxAndLevelLoss(nn.Module):
    """
    Combined Regression and Cumulative Multi-Label Focal Loss.

    This loss function is designed for spatio-temporal ordinal regression tasks
    with extreme class imbalance, such as solar flare forecasting. It evaluates
    predictions across multiple time windows simultaneously.

    It consists of two dynamically weighted components:
    1. **Regression Loss**: Mean Squared Error (MSE) computed in the log10 space
       to ensure accurate continuous flux predictions across orders of magnitude.
    2. **Classification Loss**: A cumulative Multi-Label classification loss.
       A prediction is evaluated against multiple thresholds simultaneously
       (e.g., an X-class flare satisfies >=C, >=M, and >=X thresholds).
       It supports both standard Binary Cross Entropy (BCE) and a mathematically
       stable implementation of **Focal Loss** to mine hard examples and suppress
       overwhelming numbers of easy negative samples (e.g., background noise).

    Parameters
    ----------
    num_windows : int
        The number of temporal prediction windows (e.g., 3 for 12h, 24h, 48h).
    thresholds : List[float]
        A list of physical thresholds defining the class boundaries
        (e.g., [1e-6, 1e-5, 1e-4] for C, M, X class flares).
    w_reg : float, optional
        Weight for the regression (MSE) component. Set to 0.0 to disable. Default: 1.0.
    w_cls : float, optional
        Weight for the classification (BCE/Focal) component. Set to 0.0 to disable. Default: 1.0.
    logit_scale : float, optional
        Inverse temperature scaler controlling the steepness of the probability
        mapping from flux differences. Default: 3.0.
    pos_weights : List[float], optional
        Weights for positive examples in standard BCE mode. Ignored if `use_focal_loss`
        is True. Length must match `thresholds`. Default: None.
    use_focal_loss : bool, optional
        If True, applies Focal Loss instead of standard BCE to dynamically scale
        gradients based on prediction confidence. Highly recommended for extreme
        imbalance. Default: False.
    focal_gamma : float, optional
        Focusing parameter for Focal Loss. Higher values rapidly reduce the weight
        of easy-to-classify examples. Standard value is 2.0. Default: 2.0.
    focal_alpha : List[float], optional
        Balancing parameter for Focal Loss to handle class imbalance. Values should
        be in the range [0, 1], representing the weight given to positive samples.
        Length must match `thresholds`. Default: None.
    return_mode : str, optional
        Controls the return format:
        - ``'weighted_sum'``: Returns a scalar tensor (w_reg * L_reg + w_cls * L_cls).
        - ``'weighted_dict'``: Returns a dict of already weighted components.
        - ``'raw_dict'``: Returns a dict of unweighted raw loss components.
        Default: 'weighted_sum'.

    Shape
    -----
    - pred_flux: ``(N, num_windows)`` or flattened ``(N * num_windows,)`` where N is batch size.
      Represents raw continuous predictions.
    - target_flux: ``(N, num_windows)`` or flattened ``(N * num_windows,)``.
      Represents raw continuous ground truth targets.
    - Output: Scalar if ``return_mode='weighted_sum'``, else a Dict[str, Tensor].

    Examples
    --------
    >>> # Initialize loss for 3 time windows with Focal Loss enabled
    >>> criterion = FluxAndLevelLoss(
    ...     num_windows=3,
    ...     thresholds=[1e-6, 1e-5, 1e-4],  # C, M, X classes
    ...     w_reg=1.0,
    ...     w_cls=5.0,                      # Often increased when using Focal Loss
    ...     use_focal_loss=True,
    ...     focal_gamma=2.0,
    ...     focal_alpha=[0.5, 0.75, 0.95],  # Higher alpha for rarer X-class flares
    ...     return_mode='weighted_dict'
    ... )
    >>>
    >>> # Dummy inputs (Batch size 2, flattened)
    >>> preds = torch.tensor([1.2e-4, 9e-6, 1.1e-6, 1.8e-5, 1.0e-5, 5.5e-6], requires_grad=True)
    >>> targets = torch.tensor([1.5e-4, 8e-6, 1e-6, 2e-5, 1.2e-5, 6e-6])
    >>>
    >>> loss_dict = criterion(preds, targets)
    >>> print(f"Regression Loss: {loss_dict['reg'].item():.4f}")
    >>> print(f"Focal Classification Loss: {loss_dict['cls'].item():.4f}")
    >>>
    >>> total_loss = sum(loss_dict.values())
    >>> total_loss.backward()
    """

    _VALID_MODES = ('weighted_sum', 'weighted_dict', 'raw_dict')

    def __init__(
            self,
            num_windows: int,
            thresholds: List[float],
            w_reg: float = 1.0,
            w_cls: float = 1.0,
            logit_scale: float = 3.0,
            pos_weights: Optional[List[float]] = None,
            use_focal_loss: bool = False,
            focal_gamma: float = 2.0,
            focal_alpha: Optional[List[float]] = None,
            return_mode: str = 'weighted_sum',
            debug_mode: str = 'debug_less'
    ):
        super().__init__()
        self.num_windows = num_windows
        self.w_reg = w_reg
        self.w_cls = w_cls
        self.logit_scale = logit_scale
        self.return_mode = return_mode
        self.use_focal_loss = use_focal_loss
        self.focal_gamma = focal_gamma

        if self.return_mode not in self._VALID_MODES:
            raise ValueError(f"Invalid return_mode '{self.return_mode}'. Expected one of {self._VALID_MODES}.")

        # debug_mode: 控制 DEBUG 级别下的日志输出
        #   'debug_less'  (默认): 仅打印 shape 信息，不触发 NPU→CPU 数据传输
        #   'debug_detail': 打印 shape + min/max 统计（触发 NPU→CPU 同步）
        #   'off': 完全关闭 DEBUG 打印
        self.debug_mode = debug_mode

        # Register thresholds as a buffer for automatic device placement
        self.register_buffer('thresholds', torch.tensor(thresholds, dtype=torch.float32))

        # Setup static positive weights for standard BCE
        if pos_weights is not None:
            if len(pos_weights) != len(thresholds):
                raise ValueError("Length of pos_weights must match the length of thresholds.")
            self.register_buffer('pos_weights', torch.tensor(pos_weights, dtype=torch.float32))
        else:
            self.pos_weights = None

        # Setup Alpha balancing parameter for Focal Loss
        if focal_alpha is not None:
            if len(focal_alpha) != len(thresholds):
                raise ValueError("Length of focal_alpha must match the length of thresholds.")
            # Reshape to (1, 1, Levels) to allow automatic broadcasting across Batch and Window dimensions
            self.register_buffer('focal_alpha', torch.tensor(focal_alpha, dtype=torch.float32).view(1, 1, -1))
        else:
            self.focal_alpha = None

    def forward(self, pred_flux: torch.Tensor, target_flux: torch.Tensor) -> Union[torch.Tensor, Dict[str, torch.Tensor]]:
        """Computes the combined loss."""
        # 确保计算在 float32 下进行，避免 NPU 不支持 double 的警告
        pred_flux = pred_flux.float()
        target_flux = target_flux.float()

        # Force the shape to (Batch, num_windows) to handle both 1D flattened and 2D inputs
        pred = pred_flux.view(-1, self.num_windows)
        target = target_flux.view(-1, self.num_windows)

        if logger.isEnabledFor(logging.DEBUG) and self.debug_mode != 'off':
            if self.debug_mode == 'debug_detail':
                # 详细模式：打印 shape + min/max（触发 NPU→CPU 同步）
                logger.debug(
                    "pred shape=%s min=%.6f max=%.6f, target shape=%s min=%.6f max=%.6f",
                    pred.shape, pred.min().item(), pred.max().item(),
                    target.shape, target.min().item(), target.max().item()
                )
            else:
                # debug_less 模式（默认）：仅打印 shape，不触发数据传输
                logger.debug("pred shape=%s, target shape=%s", pred.shape, target.shape)

        raw: Dict[str, torch.Tensor] = {}

        # ---------------------------------------------------------------------
        # 1. Regression Loss (MSE in Log10 Space)
        # ---------------------------------------------------------------------
        if self.w_reg > 0.0:
            # Apply ReLU to prevent negative flux predictions and add epsilon for numerical stability
            # log_pred = torch.log10(F.relu(pred) + 1e-10)
            # log_target = torch.log10(F.relu(target) + 1e-10)
            # raw['reg'] = F.mse_loss(log_pred, log_target)

            # log_pred = torch.log10(F.relu(pred) + 1e-10)
            # log_target = torch.log10(F.relu(target) + 1e-10)
            # raw['reg'] = F.mse_loss(pred, target)
            # 2. 数值安全处理
            # 既然最小值是 0.0005，建议将 epsilon 设为 1e-5 左右
            # 这样 log10(eps) 约为 -5，避免了 -10 带来的巨大 Loss
            eps = 1e-5
            # TODO
            # 使用 clamp 保证 pred 不会过小或过大（99以上给一点余量到 200）
            pred_safe = torch.clamp(pred, min=eps, max=100.0)
            target_safe = torch.clamp(target, min=eps, max=100.0)

            log_pred = torch.log10(pred_safe)
            log_target = torch.log10(target_safe)

            # 3. 使用 SmoothL1 代替 MSE 增加稳定性
            raw['reg'] = F.smooth_l1_loss(log_pred, log_target, beta=0.5)

        # ---------------------------------------------------------------------
        # 2. Classification Loss (Standard BCE or Focal Loss)
        # ---------------------------------------------------------------------
        if self.w_cls > 0.0:
            # Expand dimensions to broadcast against the thresholds
            # target_expand: (Batch, Windows, 1) | thresh_expand: (1, 1, Levels)
            target_expand = target.unsqueeze(-1)
            pred_expand = pred.unsqueeze(-1)
            thresh_expand = self.thresholds.view(1, 1, -1)

            # Generate hard cumulative labels -> (Batch, Windows, Levels)
            target_labels = (target_expand >= thresh_expand).float()

            # Calculate raw logits strictly based on the log10 magnitude difference
            log_thresh_expand = torch.log10(thresh_expand)
            log_pred_expand = torch.log10(F.relu(pred_expand) + 1e-10)
            logits = (log_pred_expand - log_thresh_expand) * self.logit_scale

            if self.use_focal_loss:
                # --- Mathematically Stable Focal Loss Implementation ---

                # Compute base BCE loss without reduction
                bce_loss = F.binary_cross_entropy_with_logits(logits, target_labels, reduction='none')

                # Derive pt (probability of the correct class) from BCE
                # Since BCE = -log(pt), we can perfectly reconstruct pt using exp(-BCE)
                pt = torch.exp(-bce_loss)

                # Calculate the modulating Focal factor: (1 - pt)^gamma
                focal_weight = (1 - pt) ** self.focal_gamma

                # Apply Alpha balancing if provided
                if self.focal_alpha is not None:
                    # If target is 1, use alpha. If target is 0, use (1 - alpha).
                    alpha_t = target_labels * self.focal_alpha + (1 - target_labels) * (1 - self.focal_alpha)
                    focal_weight = focal_weight * alpha_t

                # Combine weights with the base BCE and apply the mean reduction
                raw['cls'] = (focal_weight * bce_loss).mean()

            else:
                # --- Standard BCE Loss ---
                raw['cls'] = F.binary_cross_entropy_with_logits(
                    logits,
                    target_labels,
                    pos_weight=self.pos_weights
                )

        # ---------------------------------------------------------------------
        # 3. Output Assembly
        # ---------------------------------------------------------------------
        weights: Dict[str, float] = {'reg': self.w_reg, 'cls': self.w_cls}

        if self.return_mode == 'weighted_sum':
            total = pred.new_zeros(())
            for k, v in raw.items():
                total = total + weights[k] * v
            return total

        elif self.return_mode == 'weighted_dict':
            return {k: weights[k] * v for k, v in raw.items()}

        elif self.return_mode == 'raw_dict':
            return raw




