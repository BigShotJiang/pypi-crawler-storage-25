# -*- coding: utf-8 -*-
"""
Classification loss functions.

This package provides specialized loss functions for various classification tasks,
including focal loss for handling class imbalance and value-class losses for
structured spatial classification.
"""

from .focal_loss import FocalLoss
from .value_class_loss import (
    ValueClassSoftmaxMap,
    ValueClassLoss,
    ValueClassLossWithSoftmaxMap,
    ValueClassLossWithoutSoftmaxMapNoWeight,
    ValueClassLossWithoutSoftmaxMap,
)

__all__ = [
    # Focal loss
    'FocalLoss',
    # Value-class losses
    'ValueClassSoftmaxMap',
    'ValueClassLoss',
    'ValueClassLossWithSoftmaxMap',
    'ValueClassLossWithoutSoftmaxMapNoWeight',
    'ValueClassLossWithoutSoftmaxMap',
]
