# -*- coding: utf-8 -*-
"""
Masked vector field losses for 4D spatio-temporal magnetic fields.

Provides component-wise reconstruction losses (MSE / MAE) and physics-based
regularisation losses (divergence-free, force-free) with optional spatial-
temporal masking.  Designed for solar magnetic field reconstruction tasks.

Loss taxonomy
-------------
Reconstruction (compare pred ↔ target)
    MaskedVectorMSE  – masked mean-squared error over (batch, 3, D, H, W, T)
    MaskedVectorMAE  – masked mean-absolute error over (batch, 3, D, H, W, T)

Physics (pred only, no target required)
    DivergenceLoss   – penalise ∇·B ≠ 0 (solenoidal constraint)
    CurrentWeightedSineLoss        – penalise J ∦ B via CWsin (force-free condition)

Combined
    VectorFieldPhysicsLoss – weighted sum of any subset of the above four

Mask convention (consistent with masked_losses.py)
---------------------------------------------------
mask : Tensor or None, shape (batch, D, H, W, T), dtype bool or float
    True / 1  → valid voxel, include in loss
    False / 0 → padding / invalid, exclude from loss
    None      → all voxels are valid
"""

from typing import Dict, Optional, Sequence, Union

import torch
import torch.nn as nn
import torch.nn.functional as F
from torch import Tensor

from .vector_field_ops import vector_field_ops_4D, validate_mask


__all__ = [
    'MaskedVectorMSE',
    'MaskedVectorMAE',
    'DivergenceLoss',
    'CurrentWeightedSineLoss',
    'VectorFieldPhysicsLoss',
]


# ---------------------------------------------------------------------------
# Internal helpers
# ---------------------------------------------------------------------------

def _to_float_mask(mask: Tensor) -> Tensor:
    """Cast bool mask to float32 in-place-safe manner."""
    return mask.float() if mask.dtype == torch.bool else mask


def _expand_mask_to_field(mask: Tensor) -> Tensor:
    """Expand spatial-temporal mask (B, D, H, W, T) → (B, 1, D, H, W, T).

    The extra channel dimension lets the mask broadcast against a 3-component
    vector field of shape (B, 3, D, H, W, T).
    """
    return mask.unsqueeze(1)  # (B, 1, D, H, W, T)


def _apply_reduction(
    loss_map: Tensor,
    reduction: str,
    mask: Optional[Tensor],
) -> Tensor:
    """Apply reduction to a per-element loss map with optional mask.

    Parameters
    ----------
    loss_map : Tensor
        Per-element losses with shape (*).
    reduction : str
        'mean', 'sum', or 'none'.
    mask : Tensor or None
        Float mask broadcastable to ``loss_map``.

    Returns
    -------
    Tensor
        Scalar (reduction != 'none') or masked loss map.
    """
    if mask is not None:
        masked = loss_map * mask
        if reduction == 'mean':
            num_valid = mask.sum().clamp(min=1)
            return masked.sum() / num_valid
        elif reduction == 'sum':
            return masked.sum()
        else:  # 'none'
            return masked
    else:
        if reduction == 'mean':
            return loss_map.mean()
        elif reduction == 'sum':
            return loss_map.sum()
        else:  # 'none'
            return loss_map


# ---------------------------------------------------------------------------
# Reconstruction losses
# ---------------------------------------------------------------------------

class MaskedVectorMSE(nn.Module):
    """
    Masked Mean Squared Error for 4D vector fields.

    Computes element-wise squared error between predicted and target magnetic
    field tensors, then reduces only over valid (masked) voxels and channels.

    The mask operates on the spatial-temporal volume and is broadcast across
    the three field components automatically.

    Parameters
    ----------
    reduction : str
        'mean' (default), 'sum', or 'none'.

    Examples
    --------
    >>> criterion = MaskedVectorMSE()
    >>> pred   = torch.randn(2, 3, 16, 16, 16, 4)   # (B, 3, D, H, W, T)
    >>> target = torch.randn(2, 3, 16, 16, 16, 4)
    >>> mask   = torch.ones(2, 16, 16, 16, 4, dtype=torch.bool)
    >>> mask[:, :, :, :, 2:] = False                 # mask last 2 time-steps
    >>> loss = criterion(pred, target, mask)          # scalar

    Notes
    -----
    - When ``mask`` is None, behaves like ``nn.MSELoss(reduction=...)``
      applied to the full 6-D tensor.
    - For reduction='mean', the denominator is the *total number of valid
      scalars*, i.e. ``mask.sum() * 3`` (three components).
    - Mask dtype may be bool (True/False) or float (1.0/0.0).
    """

    def __init__(self, reduction: str = 'mean'):
        super().__init__()
        if reduction not in ('mean', 'sum', 'none'):
            raise ValueError(
                f"Invalid reduction '{reduction}'. "
                "Must be 'mean', 'sum', or 'none'."
            )
        self.reduction = reduction

    def forward(
        self,
        input: Tensor,
        target: Tensor,
        mask: Optional[Tensor] = None,
    ) -> Tensor:
        """
        Compute masked MSE.

        Parameters
        ----------
        input : Tensor
            Predicted field, shape (batch, 3, D, H, W, T).
        target : Tensor
            Ground-truth field, shape (batch, 3, D, H, W, T).
        mask : Tensor or None
            Boolean or float mask, shape (batch, D, H, W, T).
            Broadcast across the 3 channels automatically.

        Returns
        -------
        Tensor
            Scalar loss or per-element loss map (reduction='none').
        """
        sq_err = (input - target) ** 2  # (B, 3, D, H, W, T)

        if mask is not None:
            mask_f = _to_float_mask(mask)               # (B, D, H, W, T)
            if mask_f.dim() == 5:
                mask_f = _expand_mask_to_field(mask_f)      # (B, 1, D, H, W, T)
            # For 'mean', denominator = valid voxels × 3 channels
            if self.reduction == 'mean':
                num_valid = (mask_f * 3).sum().clamp(min=1)
                return (sq_err * mask_f).sum() / num_valid
            elif self.reduction == 'sum':
                return (sq_err * mask_f).sum()
            else:  # 'none'
                return sq_err * mask_f
        else:
            if self.reduction == 'mean':
                return sq_err.mean()
            elif self.reduction == 'sum':
                return sq_err.sum()
            else:
                return sq_err

    def extra_repr(self) -> str:
        return f'reduction={self.reduction}'


class MaskedVectorMAE(nn.Module):
    """
    Masked Mean Absolute Error for 4D vector fields.

    Computes element-wise absolute error between predicted and target magnetic
    field tensors, reducing only over valid (masked) voxels and channels.

    Parameters
    ----------
    reduction : str
        'mean' (default), 'sum', or 'none'.

    Examples
    --------
    >>> criterion = MaskedVectorMAE()
    >>> pred   = torch.randn(2, 3, 16, 16, 16, 4)
    >>> target = torch.randn(2, 3, 16, 16, 16, 4)
    >>> mask   = torch.ones(2, 16, 16, 16, 4, dtype=torch.bool)
    >>> loss = criterion(pred, target, mask)

    Notes
    -----
    - When ``mask`` is None, behaves like ``nn.L1Loss(reduction=...)``
      applied to the full 6-D tensor.
    - Denominator for reduction='mean' is ``mask.sum() * 3``.
    """

    def __init__(self, reduction: str = 'mean'):
        super().__init__()
        if reduction not in ('mean', 'sum', 'none'):
            raise ValueError(
                f"Invalid reduction '{reduction}'. "
                "Must be 'mean', 'sum', or 'none'."
            )
        self.reduction = reduction

    def forward(
        self,
        input: Tensor,
        target: Tensor,
        mask: Optional[Tensor] = None,
    ) -> Tensor:
        """
        Compute masked MAE.

        Parameters
        ----------
        input : Tensor
            Predicted field, shape (batch, 3, D, H, W, T).
        target : Tensor
            Ground-truth field, shape (batch, 3, D, H, W, T).
        mask : Tensor or None
            Boolean or float mask, shape (batch, D, H, W, T).

        Returns
        -------
        Tensor
            Scalar loss or per-element loss map (reduction='none').
        """
        abs_err = torch.abs(input - target)  # (B, 3, D, H, W, T)

        if mask is not None:
            mask_f = _to_float_mask(mask)
            mask_f = _expand_mask_to_field(mask_f)      # (B, 1, D, H, W, T)
            if self.reduction == 'mean':
                num_valid = (mask_f * 3).sum().clamp(min=1)
                return (abs_err * mask_f).sum() / num_valid
            elif self.reduction == 'sum':
                return (abs_err * mask_f).sum()
            else:  # 'none'
                return abs_err * mask_f
        else:
            if self.reduction == 'mean':
                return abs_err.mean()
            elif self.reduction == 'sum':
                return abs_err.sum()
            else:
                return abs_err

    def extra_repr(self) -> str:
        return f'reduction={self.reduction}'


# ---------------------------------------------------------------------------
# Physics-based losses (pred only)
# ---------------------------------------------------------------------------

class DivergenceLoss(nn.Module):
    """
    Solenoidal constraint loss: penalise ∇·B ≠ 0.

    Minimising this loss encourages the predicted magnetic field to satisfy
    the divergence-free condition (Maxwell's equation ∇·B = 0).

    Two modes are available via ``normalise``:

    ``normalise=False`` (absolute divergence loss)::

        L = mean( |∇·B| )         over valid voxels

    ``normalise=True`` (Metcalf et al. 2008 normalised divergence)::

        L = mean( |∇·B| / (6|B|/dx + ε) )   over valid voxels

    Parameters
    ----------
    dx : float
        Isotropic grid spacing in physical units (default 0.36).
    eps : float
        Numerical stability constant (default 1e-8).
    normalise : bool
        If True, normalise divergence by 6|B|/dx (default False).
    reduction : str
        'mean' (default), 'sum', or 'none'.

    Examples
    --------
    >>> criterion = DivergenceLoss(dx=0.36, normalise=True)
    >>> pred = torch.randn(2, 3, 16, 16, 16, 4)
    >>> mask = torch.ones(2, 16, 16, 16, 4, dtype=torch.bool)
    >>> loss = criterion(pred, mask=mask)

    Notes
    -----
    - ``target`` is accepted in ``forward`` for API consistency but is not
      used; the loss is purely a function of ``input``.
    - Spatial dims D, H, W must each be >= 3 (required by torch.gradient).
    - Mask dtype may be bool or float; shape must be (batch, D, H, W, T).
    """

    def __init__(
        self,
        dx: float = 0.36,
        eps: float = 1e-8,
        normalise: bool = False,
        reduction: str = 'mean',
        gradient_backend: Optional[str] = None,
    ):
        super().__init__()
        if reduction not in ('mean', 'sum', 'none'):
            raise ValueError(
                f"Invalid reduction '{reduction}'. "
                "Must be 'mean', 'sum', or 'none'."
            )
        self.dx = dx
        self.eps = eps
        self.normalise = normalise
        self.reduction = reduction
        self.gradient_backend = gradient_backend

    def forward(
        self,
        input: Tensor,
        target: Optional[Tensor] = None,
        mask: Optional[Tensor] = None,
    ) -> Tensor:
        """
        Compute divergence loss.

        Parameters
        ----------
        input : Tensor
            Predicted field, shape (batch, 3, D, H, W, T).
        target : Tensor or None
            Ignored (accepted for API compatibility).
        mask : Tensor or None
            Boolean or float mask, shape (batch, D, H, W, T).

        Returns
        -------
        Tensor
            Scalar loss (reduction='mean'/'sum') or per-voxel map ('none').
        """
        if input.shape[1] != 3:
            raise ValueError(
                f"Channel dim must be 3 (Bx, By, Bz), got {input.shape[1]}"
            )

        compute_norm = self.normalise
        div_B, _, B_norm = vector_field_ops_4D(
            input,
            dx=self.dx,
            compute_div=True,
            compute_curl=False,
            compute_norm=compute_norm,
            backend=self.gradient_backend,
        )

        if self.normalise:
            # Metcalf normalised divergence: |∇·B| / (6|B|/dx + ε)
            loss_map = torch.abs(div_B) / (6.0 * B_norm / self.dx + self.eps)
        else:
            # Absolute divergence
            loss_map = torch.abs(div_B)  # (B, D, H, W, T)

        if mask is not None:
            mask_f = _to_float_mask(mask)
            validate_mask(mask.bool() if mask.dtype != torch.bool else mask,
                          tuple(loss_map.shape))
        else:
            mask_f = None

        return _apply_reduction(loss_map, self.reduction, mask_f)

    def extra_repr(self) -> str:
        return (
            f'dx={self.dx}, eps={self.eps}, '
            f'normalise={self.normalise}, reduction={self.reduction}'
        )


class CurrentWeightedSineLoss(nn.Module):
    """
    Current-Weighted Sine (CWsin) loss: force-free constraint penalising J ∦ B.

    A magnetic field is force-free when J = ∇×B is parallel to B everywhere.
    This loss quantifies the mean misalignment (via its sine) weighted by
    current density magnitude — the same quantity evaluated by the `CurrentWeightedSine`
    metric:

    .. math::

        \\text{CWsin} =
        \\frac{\\sum_i |\\mathbf{J}_i|\\,\\sin\\theta_i}
              {\\sum_i |\\mathbf{J}_i|}

    where :math:`\\sin\\theta_i = |\\mathbf{J}_i \\times \\mathbf{B}_i| /
    (|\\mathbf{J}_i||\\mathbf{B}_i| + \\varepsilon)`.
    Minimising CWsin → 0 yields a perfectly force-free field.

    Parameters
    ----------
    dx : float
        Isotropic grid spacing (default 0.36).
    eps : float
        Numerical stability constant (default 1e-8).

    Examples
    --------
    >>> criterion = CurrentWeightedSineLoss(dx=0.36)
    >>> pred = torch.randn(2, 3, 16, 16, 16, 4)
    >>> mask = torch.ones(2, 16, 16, 16, 4, dtype=torch.bool)
    >>> loss = criterion(pred, mask=mask)

    Notes
    -----
    - ``target`` is accepted in ``forward`` for API consistency but is not
      used.
    - Spatial dims D, H, W must each be >= 3.
    - The loss is always a scalar (CWsin is an intrinsically weighted mean).
    - Returns NaN if all mask weights are zero.
    """

    def __init__(self, dx: float = 0.36, eps: float = 1e-8, gradient_backend: Optional[str] = None):
        super().__init__()
        self.dx = dx
        self.eps = eps
        self.gradient_backend = gradient_backend

    def forward(
        self,
        input: Tensor,
        target: Optional[Tensor] = None,
        mask: Optional[Tensor] = None,
    ) -> Tensor:
        """
        Compute CWsin (force-free) loss.

        Parameters
        ----------
        input : Tensor
            Predicted field, shape (batch, 3, D, H, W, T).
        target : Tensor or None
            Ignored (accepted for API compatibility).
        mask : Tensor or None
            Boolean or float mask, shape (batch, D, H, W, T).

        Returns
        -------
        Tensor
            Scalar CWsin loss (current-weighted mean sine of misalignment).
        """
        if input.shape[1] != 3:
            raise ValueError(
                f"Channel dim must be 3 (Bx, By, Bz), got {input.shape[1]}"
            )

        _, J, B_norm = vector_field_ops_4D(
            input,
            dx=self.dx,
            compute_div=False,
            compute_curl=True,
            compute_norm=True,
            backend=self.gradient_backend,
        )

        # |J| with eps for numerical stability            (B, D, H, W, T)
        J_norm = torch.linalg.norm(J, ord=2, dim=1) + self.eps

        # |J × B| – cross product in channel dim          (B, 3, D, H, W, T)
        J_cross_B = torch.cross(J, input, dim=1)
        J_cross_B_norm = torch.linalg.norm(J_cross_B, ord=2, dim=1)

        # sin θ = |J × B| / (|J| |B|)                   (B, D, H, W, T)
        sigma = J_cross_B_norm / (J_norm * B_norm + self.eps)

        if mask is not None:
            mask_f = _to_float_mask(mask)
            validate_mask(mask.bool() if mask.dtype != torch.bool else mask,
                          tuple(J_norm.shape))
            numerator   = (J_norm * sigma * mask_f).sum()
            denominator = (J_norm * mask_f).sum().clamp(min=self.eps)
        else:
            numerator   = (J_norm * sigma).sum()
            denominator = J_norm.sum().clamp(min=self.eps)

        return numerator / denominator

    def extra_repr(self) -> str:
        return f'dx={self.dx}, eps={self.eps}'


# ---------------------------------------------------------------------------
# Combined loss
# ---------------------------------------------------------------------------

class VectorFieldPhysicsLoss(nn.Module):
    """
    Weighted combination of reconstruction and physics-based losses.

    Allows any subset of the four loss components to be enabled and weighted
    independently:

    .. code-block:: text

        L = w_mse  · MaskedVectorMSE(pred, target, mask)
          + w_mae  · MaskedVectorMAE(pred, target, mask)
          + w_div  · DivergenceLoss(pred, mask)
          + w_cwsin · CurrentWeightedSineLoss(pred, mask)

    Setting a weight to 0.0 skips that computation entirely.

    **Shared gradient computation**

    When both ``w_div`` and ``w_ff`` are non-zero, ``torch.gradient`` is
    called **once** over all three field components (9 partial derivatives
    total). Both losses are derived from that single computation, halving
    the cost compared to calling ``DivergenceLoss`` and ``ForceFreeLoss``
    as independent modules.

    Parameters
    ----------
    w_mse : float
        Weight for MSE reconstruction loss (default 1.0).
    w_mae : float
        Weight for MAE reconstruction loss (default 1.0).
    w_div : float
        Weight for divergence constraint loss (default 1.0).
    w_cwsin : float
        Weight for CWsin (force-free) constraint loss (default 1.0).
    dx : float
        Grid spacing for physics losses (default 0.36).
    eps : float
        Numerical stability constant (default 1e-8).
    normalise_div : bool
        Normalise divergence loss by 6|B|/dx, Metcalf style (default False).
    reduction : str
        Reduction for reconstruction losses: 'mean' (default) or 'sum'.
    return_mode : str
        Controls the return value:

        ``'weighted_sum'`` *(default)*
            Scalar weighted total loss: ``Σ w_i · L_i``.
        ``'weighted_dict'``
            Dict ``{name: w_i · L_i}`` — components already scaled by
            their weights; caller can sum freely or log individually.
        ``'raw_dict'``
            Dict ``{name: L_i}`` — unweighted component losses;
            caller applies weights and summation externally.

    Examples
    --------
    >>> # Pure reconstruction (scalar output)
    >>> criterion = VectorFieldPhysicsLoss(w_mse=1.0)
    >>> pred   = torch.randn(2, 3, 16, 16, 16, 4)
    >>> target = torch.randn(2, 3, 16, 16, 16, 4)
    >>> mask   = torch.ones(2, 16, 16, 16, 4, dtype=torch.bool)
    >>> loss = criterion(pred, target, mask)                # Tensor scalar
    >>>
    >>> # Reconstruction + physics, inspect weighted components
    >>> criterion = VectorFieldPhysicsLoss(w_mse=1.0, w_div=0.1, w_cwsin=0.05)
    >>> loss = criterion(pred, target, mask)                # scalar
    >>>
    >>> # Get weighted dict for external summation (e.g. custom scheduler)
    >>> d = criterion(pred, target, mask)
    >>> # d == {'mse': 1.0*L_mse, 'divergence': 0.1*L_div, 'cwsin': 0.05*L_cwsin}
    >>> total = sum(d.values())                             # equivalent scalar
    >>>
    >>> # Get raw (unweighted) dict to apply your own weights downstream
    >>> d = criterion(pred, target, mask)
    >>> # d == {'mse': L_mse, 'divergence': L_div, 'cwsin': L_cwsin}
    >>> total = d['mse'] + 0.1 * d['divergence'] + 0.05 * d['cwsin']

    Notes
    -----
    - Target is required when ``w_mse > 0`` or ``w_mae > 0``.
    - Physics losses require spatial dims D, H, W >= 3.
    - With both ``w_div`` and ``w_ff`` active, spatial gradients are computed
      **once** and shared — there is no redundant ``torch.gradient`` call.
    """

    _VALID_MODES = ('weighted_sum', 'weighted_dict', 'raw_dict')

    def __init__(
        self,
        w_mse: float = 1.0,
        w_mae: float = 1.0,
        w_div: float = 1.0,
        w_cwsin: float = 1.0,
        dx: float = 0.36,
        eps: float = 1e-8,
        normalise_div: bool = False,
        reduction: str = 'mean',
        return_mode: str = 'weighted_sum',
        gradient_backend: Optional[str] = None,
        physics_downsample: int = 1,
    ):
        super().__init__()
        self.w_mse   = w_mse
        self.w_mae   = w_mae
        self.w_div   = w_div
        self.w_cwsin = w_cwsin
        self.dx      = dx
        self.eps     = eps
        self.normalise_div = normalise_div
        self.return_mode = return_mode
        # gradient_backend: None=auto (CUDA→gradient, NPU→conv3d), "gradient", "conv3d"
        self.gradient_backend = gradient_backend
        # physics_downsample: >1 则先将预测场降采样再计算物理损失，降低计算量
        # 例如 physics_downsample=2 → 每个空间维度缩小一半，计算量降为 1/8
        self.physics_downsample = physics_downsample

        # Reconstruction sub-losses (no gradient ops, cheap to keep separate)
        self._mse_loss = MaskedVectorMSE(reduction=reduction) if w_mse > 0.0 else None
        self._mae_loss = MaskedVectorMAE(reduction=reduction) if w_mae > 0.0 else None

        # Physics flags — used at forward time for one shared ops call
        self._need_div   = w_div   > 0.0
        self._need_cwsin = w_cwsin > 0.0
        # |B| is required for: normalised divergence OR CWsin loss
        self._need_norm = (w_div > 0.0 and normalise_div) or (w_cwsin > 0.0)

        if self.return_mode not in self._VALID_MODES:
            raise ValueError(
                f"Invalid self.return_mode '{self.return_mode}'. "
                f"Must be one of {self._VALID_MODES}."
            )

    # ------------------------------------------------------------------
    # Internal: physics losses from pre-computed field quantities
    # ------------------------------------------------------------------

    def _div_loss_from(
        self,
        div_B: Tensor,
        B_norm: Optional[Tensor],
        mask_f: Optional[Tensor],
    ) -> Tensor:
        """Compute divergence loss from precomputed div_B (and B_norm)."""
        if self.normalise_div:
            loss_map = torch.abs(div_B) / (6.0 * B_norm / self.dx + self.eps)
        else:
            loss_map = torch.abs(div_B)
        return _apply_reduction(loss_map, 'mean', mask_f)

    def _cwsin_loss_from(
        self,
        J: Tensor,
        B_field: Tensor,
        B_norm: Tensor,
        mask_f: Optional[Tensor],
    ) -> Tensor:
        """Compute CWsin (force-free) loss from precomputed J and B_norm."""
        J_norm       = torch.linalg.norm(J, ord=2, dim=1) + self.eps
        J_cross_B    = torch.cross(J, B_field, dim=1)
        J_cross_B_norm = torch.linalg.norm(J_cross_B, ord=2, dim=1)
        sigma        = J_cross_B_norm / (J_norm * B_norm + self.eps)

        if mask_f is not None:
            num   = (J_norm * sigma * mask_f).sum()
            denom = (J_norm * mask_f).sum().clamp(min=self.eps)
        else:
            num   = (J_norm * sigma).sum()
            denom = J_norm.sum().clamp(min=self.eps)
        return num / denom

    # ------------------------------------------------------------------
    # forward
    # ------------------------------------------------------------------

    def forward(
        self,
        input: Tensor,
        target: Optional[Tensor] = None,
        mask: Optional[Tensor] = None,

    ) -> Union[Tensor, Dict[str, Tensor]]:
        """
        Compute the combined weighted loss.

        Parameters
        ----------
        input : Tensor
            Predicted field, shape (batch, 3, D, H, W, T).
        target : Tensor or None
            Ground-truth field, required when w_mse or w_mae > 0.
        mask : Tensor or None
            Boolean or float mask, shape (batch, D, H, W, T).


        Returns
        -------
        Tensor
            Scalar total loss when ``return_mode='weighted_sum'``.
        Dict[str, Tensor]
            Component dict when ``return_mode`` is ``'weighted_dict'`` or
            ``'raw_dict'``.

        Raises
        ------
        ValueError
            If target is None but reconstruction losses are requested,
            or if ``self.return_mode`` is not a recognised value.
        """

        if (self.w_mse != 0.0 or self.w_mae != 0.0) and target is None:
            raise ValueError(
                "target must be provided when w_mse or w_mae is non-zero."
            )

        # Float mask for physics ops (spatial-temporal, no channel dim)
        mask_f: Optional[Tensor] = None
        if mask is not None:
            mask_f = _to_float_mask(mask)
            # Validate shape once here for the physics branch
            if self._need_div or self._need_cwsin:
                expected = (input.shape[0],) + tuple(input.shape[2:])
                validate_mask(
                    mask.bool() if mask.dtype != torch.bool else mask,
                    expected,
                )

        # Accumulate raw (unweighted) per-component losses
        raw: Dict[str, Tensor] = {}

        # ── Reconstruction (cheap, no gradient ops) ──────────────────────
        if self._mse_loss is not None:
            raw['mse'] = self._mse_loss(input, target, mask)
        if self._mae_loss is not None:
            raw['mae'] = self._mae_loss(input, target, mask)

        # ── Physics: one shared vector_field_ops_4D call ──────────────────
        # When both w_div and w_cwsin are active, the 9 spatial partial
        # derivatives (∂Bx/∂x … ∂Bz/∂z) are computed only once.
        if self._need_div or self._need_cwsin:
            phys_input = input
            phys_mask_f = mask_f
            phys_dx = self.dx

            # ── 可选：降采样后计算物理损失，降低计算量 ──
            if self.physics_downsample > 1:
                s = self.physics_downsample
                # input: (B, 3, D, H, W, T) → pool over spatial dims
                b, c, d, h, w, t = input.shape
                # 将 T 合并到 batch → (B*T, 3, D, H, W) → avg_pool3d → 还原
                inp_flat = input.permute(0, 5, 1, 2, 3, 4).reshape(b * t, c, d, h, w)
                inp_ds = F.avg_pool3d(inp_flat.float(), kernel_size=s, stride=s)
                _, _, d2, h2, w2 = inp_ds.shape
                phys_input = inp_ds.to(input.dtype).reshape(b, t, c, d2, h2, w2).permute(0, 2, 3, 4, 5, 1)
                phys_dx = self.dx * s
                # 降采样 mask
                if phys_mask_f is not None:
                    m_flat = mask_f.permute(0, 4, 1, 2, 3).reshape(b * t, 1, d, h, w)
                    m_ds = F.avg_pool3d(m_flat.float(), kernel_size=s, stride=s)
                    phys_mask_f = (m_ds > 0.5).float().reshape(b, t, 1, d2, h2, w2).permute(0, 3, 4, 5, 1, 2).squeeze(-1)

            div_B, J, B_norm = vector_field_ops_4D(
                phys_input,
                dx=phys_dx,
                compute_div=self._need_div,
                compute_curl=self._need_cwsin,
                compute_norm=self._need_norm,
                backend=self.gradient_backend,
            )
            if self._need_div:
                raw['divergence'] = self._div_loss_from(div_B, B_norm, phys_mask_f)
            if self._need_cwsin:
                raw['cwsin'] = self._cwsin_loss_from(J, phys_input, B_norm, phys_mask_f)

        # ── Assemble output ───────────────────────────────────────────────
        weights: Dict[str, float] = {
            'mse': self.w_mse, 'mae': self.w_mae,
            'divergence': self.w_div, 'cwsin': self.w_cwsin,
        }

        if self.return_mode == 'weighted_sum':
            total = input.new_zeros(())
            for k, v in raw.items():
                total = total + weights[k] * v
            return total

        elif self.return_mode == 'weighted_dict':
            return {k: weights[k] * v for k, v in raw.items()}

        elif self.return_mode == 'raw_dict':
            return raw
        
        else:
            raise ValueError(f"Invalid return_mode '{self.return_mode}'. "
                             f"Expected one of {self._VALID_MODES}.")

    def extra_repr(self) -> str:
        return (
            f'w_mse={self.w_mse}, w_mae={self.w_mae}, '
            f'w_div={self.w_div}, w_cwsin={self.w_cwsin}'
        )
