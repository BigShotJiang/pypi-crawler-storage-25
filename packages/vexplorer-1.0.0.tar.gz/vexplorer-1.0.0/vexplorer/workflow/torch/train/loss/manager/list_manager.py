# -*- coding: utf-8 -*-
"""
List-based loss manager with positional-argument index routing.

Each loss can select a subset of the positional args by index.  Weights
are configured through the manager's ``weight_strategy``, not in
:meth:`~ListLossManager.add_loss`.
"""

from dataclasses import dataclass, field
from typing import Any, Callable, Dict, List, Optional, Tuple, Union

import torch
import torch.nn as nn
from torch import Tensor

from ..base import BaseLossManager
from .weight_strategy import BaseWeightStrategy


__all__ = ['ListLossWrapper', 'ListLossManager']


@dataclass
class ListLossWrapper:
    """
    Configuration wrapper for losses managed by ListLossManager.

    Parameters
    ----------
    priority : int
        Computation priority.  Lower values are computed first.
        Default: 0.
    arg_indices : Tuple[int, ...]
        Positional argument indices to forward to this loss.
        ``()`` (default) means forward all positional args.
    kwarg_keys : Tuple[str, ...]
        Keyword argument keys to forward to this loss.
        ``()`` (default) means forward no kwargs.
    arg_transform : Dict[int, Callable]
        Transforms applied after argument selection.
        Keys are positions *within the selected args*.
        Default: empty (no transform).
    kwarg_transform : Dict[str, Callable]
        Transforms applied to selected kwargs.
        Default: empty (no transform).

    Examples
    --------
    >>> wrapper = ListLossWrapper(arg_indices=(0, 1))

    >>> wrapper = ListLossWrapper(
    ...     arg_indices=(0, 1),
    ...     arg_transform={0: lambda x: x.sigmoid()},
    ... )
    """
    priority: int = 0
    arg_indices: Tuple[int, ...] = field(default_factory=tuple)
    kwarg_keys: Tuple[str, ...] = field(default_factory=tuple)
    arg_transform: Dict[int, Callable] = field(default_factory=dict)
    kwarg_transform: Dict[str, Callable] = field(default_factory=dict)



class ListLossManager(BaseLossManager):
    """
    List-based loss manager with indexed argument routing.

    Organises losses in insertion order and routes positional arguments
    by index.  Useful when different losses need different input subsets.
    Weighting is configured through :attr:`weight_strategy`, not in
    :meth:`add_loss`.

    Parameters
    ----------
    detach : bool
        Whether to detach tensors. Default: False.
    clone : bool
        Whether to clone tensors. Default: False.
    weight_strategy : BaseWeightStrategy or None
        Weighting strategy.  ``None`` creates a
        :class:`~.weight_strategy.StaticWeightStrategy` with unit weights.

    Examples
    --------
    >>> manager = ListLossManager()
    >>> manager.add_loss('mse', nn.MSELoss())
    >>> manager.add_loss('mae', nn.L1Loss())
    >>> loss = manager(predictions, targets)   # 1.0 * MSE + 1.0 * MAE

    >>> # index routing
    >>> wrapper1 = ListLossWrapper(arg_indices=(0, 1))
    >>> wrapper2 = ListLossWrapper(arg_indices=(0, 2))
    >>> manager = ListLossManager(
    ...     weight_strategy=StaticWeightStrategy({'loss1': 1.0, 'loss2': 0.5})
    ... )
    >>> manager.add_loss('loss1', loss_fn1, wrapper=wrapper1)
    >>> manager.add_loss('loss2', loss_fn2, wrapper=wrapper2)
    >>> loss = manager(pred, target1, target2)
    """

    def __init__(
        self,
        detach: bool = False,
        clone: bool = False,
        weight_strategy: Optional[BaseWeightStrategy] = None,
    ):
        super().__init__(detach=detach, clone=clone, weight_strategy=weight_strategy)
        self._losses: List[nn.Module] = []
        self._loss_names: List[str] = []
        self._wrappers: List[Optional[ListLossWrapper]] = []

    def add_loss(
        self,
        name: str,
        loss_fn: nn.Module,
        wrapper: Optional[ListLossWrapper] = None,
    ) -> None:
        """
        Register a loss function.

        Weights are configured through ``manager.weight_strategy``.

        Parameters
        ----------
        name : str
            Unique name identifier for the loss.
        loss_fn : nn.Module
            The loss function to register.
        wrapper : ListLossWrapper or None
            Optional index-routing wrapper.

        Raises
        ------
        ValueError
            If *name* is already registered.
        """
        if name in self._loss_names:
            raise ValueError(f"Loss '{name}' already exists in ListLossManager")
        self._losses.append(loss_fn)
        self._loss_names.append(name)
        self._wrappers.append(wrapper)

    def _compute_raw_losses(self, *args, **kwargs) -> Dict[str, Tensor]:
        """
        Compute all losses with per-loss index routing.

        Returns
        -------
        Dict[str, Tensor]
            Mapping of loss name → scalar loss tensor (priority order),
            with dict-returning losses expanded to ``name/key`` entries.

        Raises
        ------
        ValueError
            If no losses have been added.
        """
        if not self._losses:
            raise ValueError("No losses have been added to ListLossManager")

        args = self._prepare_args(args)
        kwargs = self._prepare_kwargs(kwargs)

        sorted_indices = sorted(
            range(len(self._losses)),
            key=lambda i: (
                self._wrappers[i].priority if self._wrappers[i] is not None else 0
            ),
        )

        raw: Dict[str, Tensor] = {}
        for idx in sorted_indices:
            loss_fn = self._losses[idx]
            wrapper = self._wrappers[idx]
            name = self._loss_names[idx]

            loss_args = args
            loss_kwargs = kwargs.copy()

            if wrapper is not None:
                if wrapper.arg_indices:
                    loss_args = tuple(args[i] for i in wrapper.arg_indices)
                if wrapper.arg_transform:
                    loss_args = tuple(
                        wrapper.arg_transform.get(i, lambda x: x)(arg)
                        for i, arg in enumerate(loss_args)
                    )
                if wrapper.kwarg_keys:
                    loss_kwargs = {
                        k: v for k, v in kwargs.items() if k in wrapper.kwarg_keys
                    }
                if wrapper.kwarg_transform:
                    loss_kwargs = {
                        k: wrapper.kwarg_transform.get(k, lambda x: x)(v)
                        for k, v in loss_kwargs.items()
                    }

            self._collect_loss(raw, name, loss_fn(*loss_args, **loss_kwargs))

        return raw

    def to(self, device: Union[str, torch.device]) -> 'ListLossManager':
        """Move all loss functions to *device*."""
        super().to(device)
        for i, loss_fn in enumerate(self._losses):
            self._losses[i] = loss_fn.to(device)
        return self

    def del_loss(self, name: str) -> None:
        """
        Remove a loss function by *name*.

        Raises
        ------
        KeyError
            If *name* is not registered.
        """
        if name not in self._loss_names:
            raise KeyError(f"Loss '{name}' not found in ListLossManager")
        idx = self._loss_names.index(name)
        del self._losses[idx]
        del self._loss_names[idx]
        del self._wrappers[idx]

    def get_loss_names(self) -> list:
        """Return registered loss names in insertion order."""
        return self._loss_names.copy()

    def get_loss_details(self) -> Dict[str, Dict[str, Any]]:
        """
        Return detailed information about each registered loss.

        Returns
        -------
        Dict[str, Dict[str, Any]]
            Keys: ``'loss_fn'``, ``'wrapper'``.
        """
        return {
            name: {
                'loss_fn': self._losses[i],
                'wrapper': self._wrappers[i],
            }
            for i, name in enumerate(self._loss_names)
        }
