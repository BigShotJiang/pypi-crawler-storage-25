# -*- coding: utf-8 -*-
"""
Solar magnetic field losses, metrics, and utilities.

This package provides:

Losses (for training)
    MaskedVectorMSE       – masked MSE over (batch, 3, D, H, W, T)
    MaskedVectorMAE       – masked MAE over (batch, 3, D, H, W, T)
    DivergenceLoss        – solenoidal constraint: penalise ∇·B ≠ 0
    CurrentWeightedSineLoss             – force-free constraint: penalise J ∦ B via CWsin
    VectorFieldPhysicsLoss – weighted combination of the above

Low-level ops
    vector_field_ops_4D   – divergence, curl, norm for 6-D tensors
    validate_mask         – mask shape/dtype checker
"""

from .vector_field_ops import vector_field_ops_4D, validate_mask

from .vector_field_loss import (
    MaskedVectorMSE,
    MaskedVectorMAE,
    DivergenceLoss,
    CurrentWeightedSineLoss,
    VectorFieldPhysicsLoss,
)

__all__ = [
    # Low-level ops
    'vector_field_ops_4D',
    'validate_mask',
    # Training losses
    'MaskedVectorMSE',
    'MaskedVectorMAE',
    'DivergenceLoss',
    'CurrentWeightedSineLoss',
    'VectorFieldPhysicsLoss',
]
