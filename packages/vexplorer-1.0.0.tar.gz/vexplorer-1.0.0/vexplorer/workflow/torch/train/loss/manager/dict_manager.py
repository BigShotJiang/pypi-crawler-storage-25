# -*- coding: utf-8 -*-
"""
Dict-based loss manager with keyword-argument routing and per-key transform.

Each loss declares an ``input_map`` to remap manager kwargs to its own
kwarg names.  Weights are configured through the manager's
``weight_strategy``, not in :meth:`~DictLossManager.add_loss`.
"""

from collections import OrderedDict
from dataclasses import dataclass, field
from typing import Any, Callable, Dict, Optional, Union

import torch
import torch.nn as nn
from torch import Tensor

from ..base import BaseLossManager
from .weight_strategy import BaseWeightStrategy


__all__ = ['DictLossWrapper', 'DictLossManager']


@dataclass
class DictLossWrapper:
    """
    Configuration wrapper for losses managed by DictLossManager.

    Parameters
    ----------
    priority : int
        Computation priority.  Lower values are computed first.
        Default: 0.
    input_map : Dict[str, str]
        Maps manager-side kwarg names to loss-side kwarg names.
        Example: ``{'predictions': 'input', 'labels': 'target'}`` means
        ``manager(predictions=…, labels=…)`` calls
        ``loss_fn(input=…, target=…)``.
        Default: empty (pass all kwargs through as-is).
    input_transform : Dict[str, Callable]
        Transforms applied after key remapping.  Keys are the loss-side
        names (values of *input_map*).
        Default: empty (no transform).

    Examples
    --------
    >>> wrapper = DictLossWrapper(
    ...     input_map={'predictions': 'input', 'labels': 'target'},
    ... )

    >>> wrapper = DictLossWrapper(
    ...     input_map={'raw_logits': 'input', 'labels': 'target'},
    ...     input_transform={'input': lambda x: x.sigmoid()},
    ... )
    """
    priority: int = 0
    input_map: Dict[str, str] = field(default_factory=dict)
    input_transform: Dict[str, Callable] = field(default_factory=dict)

    def __post_init__(self):
        if self.input_map is None:
            self.input_map = {}
        if self.input_transform is None:
            self.input_transform = {}


class DictLossManager(BaseLossManager):
    """
    Dict-based loss manager with kwarg routing, transform, and strategy weighting.

    The most flexible manager: each loss declares its own kwarg mapping and
    optional transform.  Weighting is configured through
    :attr:`weight_strategy`, not in :meth:`add_loss`.

    Parameters
    ----------
    detach : bool
        Whether to detach tensors. Default: False.
    clone : bool
        Whether to clone tensors. Default: False.
    weight_strategy : BaseWeightStrategy or None
        Weighting strategy.  ``None`` creates a
        :class:`~.weight_strategy.StaticWeightStrategy` with unit weights.

    Examples
    --------
    >>> manager = DictLossManager()
    >>> manager.add_loss('mse', nn.MSELoss())
    >>> manager.add_loss('mae', nn.L1Loss())
    >>> loss = manager(predictions=preds, targets=targets)

    >>> # with key remapping
    >>> wrapper = DictLossWrapper(
    ...     input_map={'predictions': 'input', 'labels': 'target'}
    ... )
    >>> manager = DictLossManager(
    ...     weight_strategy=StaticWeightStrategy({'mse': 1.0, 'mae': 0.5})
    ... )
    >>> manager.add_loss('mse', nn.MSELoss(), wrapper=wrapper)

    Notes
    -----
    - ``manager.forward()`` only accepts keyword arguments.
    - Losses are computed in priority order (lowest first).
    """

    def __init__(
        self,
        detach: bool = False,
        clone: bool = False,
        weight_strategy: Optional[BaseWeightStrategy] = None,
    ):
        super().__init__(detach=detach, clone=clone, weight_strategy=weight_strategy)
        self._losses: OrderedDict[str, nn.Module] = OrderedDict()
        self._wrappers: Dict[str, Optional[DictLossWrapper]] = {}

    def add_loss(
        self,
        name: str,
        loss_fn: nn.Module,
        wrapper: Optional[DictLossWrapper] = None,
    ) -> None:
        """
        Register a loss function.

        Weights are configured through ``manager.weight_strategy``.

        Parameters
        ----------
        name : str
            Unique name identifier for the loss.
        loss_fn : nn.Module
            The loss function to register.
        wrapper : DictLossWrapper or None
            Optional kwarg-routing wrapper.

        Raises
        ------
        ValueError
            If *name* is already registered.
        """
        if name in self._losses:
            raise ValueError(f"Loss '{name}' already exists in DictLossManager")
        self._losses[name] = loss_fn
        self._wrappers[name] = wrapper

    def _compute_raw_losses(self, *args, **kwargs) -> Dict[str, Tensor]:
        """
        Compute all losses with per-loss kwarg remapping.

        Only keyword arguments are forwarded; positional args are rejected.

        Returns
        -------
        Dict[str, Tensor]
            Mapping of loss name → scalar loss tensor (priority order),
            with dict-returning losses expanded to ``name/key`` entries.

        Raises
        ------
        ValueError
            If no losses have been added or positional args are supplied.
        """
        if not self._losses:
            raise ValueError("No losses have been added to DictLossManager")

        if args:
            raise ValueError(
                "DictLossManager does not accept positional arguments. "
                "Use keyword arguments only."
            )

        kwargs = self._prepare_kwargs(kwargs)

        sorted_names = sorted(
            self._losses.keys(),
            key=lambda n: (
                self._wrappers[n].priority if self._wrappers[n] is not None else 0,
                n,
            ),
        )

        raw: Dict[str, Tensor] = {}
        for name in sorted_names:
            loss_fn = self._losses[name]
            wrapper = self._wrappers[name]

            loss_kwargs = kwargs.copy()

            if wrapper is not None:
                if wrapper.input_map:
                    loss_kwargs = {
                        loss_key: kwargs[mgr_key]
                        for mgr_key, loss_key in wrapper.input_map.items()
                        if mgr_key in kwargs
                    }
                if wrapper.input_transform:
                    for loss_key, transform_fn in wrapper.input_transform.items():
                        if loss_key in loss_kwargs:
                            loss_kwargs[loss_key] = transform_fn(loss_kwargs[loss_key])

            self._collect_loss(raw, name, loss_fn(**loss_kwargs))

        return raw

    def to(self, device: Union[str, torch.device]) -> 'DictLossManager':
        """Move all loss functions to *device*."""
        super().to(device)
        for name, loss_fn in self._losses.items():
            self._losses[name] = loss_fn.to(device)
        return self

    def del_loss(self, name: str) -> None:
        """
        Remove a loss function by *name*.

        Raises
        ------
        KeyError
            If *name* is not registered.
        """
        if name not in self._losses:
            raise KeyError(f"Loss '{name}' not found in DictLossManager")
        del self._losses[name]
        del self._wrappers[name]

    def get_loss_names(self) -> list:
        """Return registered loss names in insertion order."""
        return list(self._losses.keys())

    def get_loss_details(self) -> Dict[str, Dict[str, Any]]:
        """
        Return detailed information about each registered loss.

        Returns
        -------
        Dict[str, Dict[str, Any]]
            Keys: ``'loss_fn'``, ``'wrapper'``.
        """
        return {
            name: {
                'loss_fn': self._losses[name],
                'wrapper': self._wrappers[name],
            }
            for name in self._losses
        }
