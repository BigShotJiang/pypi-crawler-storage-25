# -*- coding: utf-8 -*-
"""
Base loss manager for managing and combining multiple loss functions.

All weighting is handled through a :class:`~.weight_strategy.BaseWeightStrategy`.
When no strategy is supplied a :class:`~.weight_strategy.StaticWeightStrategy`
with ``default_weight=1.0`` is created automatically, giving every registered
task equal unit weight.
"""

from abc import ABC, abstractmethod
from typing import Any, Dict, List, Optional, Tuple, Union

import logging
import torch
import torch.nn as nn
from torch import Tensor

from ..manager.weight_strategy import BaseWeightStrategy, StaticWeightStrategy, LossWeightStrategyOptimizeMode

logger = logging.getLogger(__name__)

__all__ = ['BaseLossManager']


class BaseLossManager(nn.Module, ABC):
    """Abstract base class for managing multiple loss functions.

    All weighting — including the default equal-weight case — is handled
    through a :class:`~.weight_strategy.BaseWeightStrategy`.  Passing
    ``weight_strategy=None`` (the default) automatically creates a
    :class:`~.weight_strategy.StaticWeightStrategy` with unit weights, so
    simple usage requires no explicit strategy at all.

    Weights are no longer specified in :meth:`add_loss`.  To change static
    weights at any time use the :attr:`weight_strategy` property::

        manager.weight_strategy.update_weight('mse', 2.0)

    or supply a fully configured strategy up front::

        manager = DirectLossManager(
            weight_strategy=StaticWeightStrategy({'mse': 2.0, 'div': 0.1})
        )

    Parameters
    ----------
    detach : bool
        Whether to detach tensors before passing to loss functions.
        Must be ``False`` when using gradient-based strategies (PCGrad,
        CAGrad, GradNorm), otherwise gradients are severed.
        Default: ``False``.
    clone : bool
        Whether to clone tensors before passing to loss functions.
        Default: ``False``.
    weight_strategy : BaseWeightStrategy or None
        Weighting strategy.  ``None`` creates a default
        :class:`~.weight_strategy.StaticWeightStrategy` with
        ``default_weight=1.0``.

    Properties
    ----------
    weight_strategy : BaseWeightStrategy
        The active strategy instance.
    last_raw_losses : Dict[str, float]
        The most recently computed raw (unweighted) per-task losses.
    """

    def __init__(
        self,
        detach: bool = False,
        clone: bool = False,
        weight_strategy: Optional[BaseWeightStrategy] = None,
    ):
        super().__init__()
        self._detach = detach
        self._clone = clone
        self._weight_strategy: BaseWeightStrategy = (
            weight_strategy if weight_strategy is not None
            else StaticWeightStrategy()
        )
        self._step: int = 0

        # Backward context — populated by setup_backward_context().
        self._bwd_network: Optional[nn.Module] = None
        self._bwd_engine: Any = None

        # Cache of raw (unweighted) per-task losses from the most recent
        # backward_step / eval_step call, exposed via :attr:`last_raw_losses`.
        self._last_raw_losses: Dict[str, float] = {}

    # ------------------------------------------------------------------
    # Parameter grouping
    # ------------------------------------------------------------------

    def get_parameter_groups(self) -> Tuple[List[nn.Parameter], List[nn.Parameter]]:
        """Split parameters into two disjoint groups.

        Returns
        -------
        main_params : List[nn.Parameter]
            Parameters optimised by the main optimiser, including any
            learnable parameters inside registered loss functions
            (e.g. ``UncertaintyWeightStrategy`` log-variances).
        strategy_params : List[nn.Parameter]
            Parameters that require a **separate** optimiser.  Non-empty
            only for two-stage strategies such as ``GradNormStrategy``.
        """
        all_params = list(self.parameters())

        if self.is_params_optimize_two_stage:
            strategy_ids = {id(p) for p in self._weight_strategy.parameters()}
            main_params = [p for p in all_params if id(p) not in strategy_ids]
            strategy_params = [p for p in all_params if id(p) in strategy_ids]
            return main_params, strategy_params

        # For all other modes (Static, UW, DWA, RLW, PCGrad, CAGrad),
        # every parameter — including those inside loss modules — is
        # optimised jointly.
        return all_params, []

    # ------------------------------------------------------------------
    # Strategy access helpers
    # ------------------------------------------------------------------

    @property
    def is_params_optimize_together(self) -> bool:
        """``True`` for scalar-weight strategies (Static / UW / DWA / RLW)."""
        return self._weight_strategy.optimize_mode == LossWeightStrategyOptimizeMode.params_optimize_together

    @property
    def is_params_optimize_two_stage(self) -> bool:
        """``True`` for two-stage strategies (GradNorm)."""
        return self._weight_strategy.optimize_mode == LossWeightStrategyOptimizeMode.params_optimize_two_stage

    @property
    def is_grad_inner(self) -> bool:
        """``True`` for gradient-surgery strategies (PCGrad / CAGrad)."""
        return self._weight_strategy.optimize_mode == LossWeightStrategyOptimizeMode.grad_inner

    @property
    def weight_strategy(self) -> BaseWeightStrategy:
        """The active weighting strategy."""
        return self._weight_strategy

    # ------------------------------------------------------------------
    # Tensor preparation helpers
    # ------------------------------------------------------------------

    def _prepare_tensor(self, value: Any) -> Any:
        """Apply detach/clone to *value* if it is a Tensor."""
        if isinstance(value, Tensor):
            if self._detach:
                value = value.detach()
            if self._clone:
                value = value.clone()
        return value

    def _prepare_args(self, args: tuple) -> tuple:
        """Apply detach/clone to all positional arguments."""
        return tuple(self._prepare_tensor(a) for a in args)

    def _prepare_kwargs(self, kwargs: dict) -> dict:
        """Apply detach/clone to all keyword arguments."""
        return {k: self._prepare_tensor(v) for k, v in kwargs.items()}

    # ------------------------------------------------------------------
    # Dict-output helper
    # ------------------------------------------------------------------

    @staticmethod
    def _collect_loss(
        raw: Dict[str, Tensor],
        name: str,
        output: Union[Tensor, Dict[str, Tensor]],
    ) -> None:
        """Insert one loss function's output into the accumulation dict *raw*.

        Handles two cases transparently:

        * **Tensor** – stored as ``raw[name]``.
        * **Dict[str, Tensor]** – each entry stored as
          ``raw[f"{name}/{k}"]``, making sub-components individually
          visible to the weighting strategy.

        This allows dict-returning losses (e.g. ``VectorFieldPhysicsLoss``
        with ``return_mode='raw_dict'``) to be mixed with plain scalar
        losses in the same manager, with every component weighted
        independently.

        Parameters
        ----------
        raw : Dict[str, Tensor]
            Accumulation dict modified **in-place**.
        name : str
            Registered name of the loss function.
        output : Tensor or Dict[str, Tensor]
            Return value of ``loss_fn(...)``.

        Examples
        --------
        >>> BaseLossManager._collect_loss(raw, 'mse', scalar_tensor)
        >>> # raw == {'mse': scalar_tensor}

        >>> BaseLossManager._collect_loss(raw, 'physics', {'mse': t1, 'div': t2})
        >>> # raw == {'physics/mse': t1, 'physics/div': t2}
        """
        if isinstance(output, dict):
            for k, v in output.items():
                raw[f"{name}/{k}"] = v
        else:
            raw[name] = output

    # ------------------------------------------------------------------
    # Abstract: raw loss computation (subclasses implement routing logic)
    # ------------------------------------------------------------------

    @abstractmethod
    def _compute_raw_losses(self, *args, **kwargs) -> Dict[str, Tensor]:
        """Compute all individual losses and return an unweighted dict.

        Subclasses implement their routing / wrapper / priority logic here.
        The result is consumed by :meth:`_apply_weights` or returned
        directly via :meth:`compute_raw_losses`.

        Returns
        -------
        Dict[str, Tensor]
            Mapping of loss name to scalar loss tensor.
        """

    # ------------------------------------------------------------------
    # Concrete helpers
    # ------------------------------------------------------------------

    def compute_raw_losses(self, *args, **kwargs) -> Dict[str, Tensor]:
        """Public entry-point: compute and return unweighted per-task losses.

        Use this when running gradient-based strategies (PCGrad, CAGrad,
        GradNorm) where the caller needs individual loss tensors before
        calling backward::

            raw = manager.compute_raw_losses(pred, target)
            manager.weight_strategy.backward(raw, model.parameters())
            optimizer.step()

        Returns
        -------
        Dict[str, Tensor]
            Unweighted per-task scalar losses.
        """
        return self._compute_raw_losses(*args, **kwargs)

    def _apply_weights(self, raw: Dict[str, Tensor]) -> Tensor:
        """Combine raw losses through the active strategy.

        Parameters
        ----------
        raw : Dict[str, Tensor]
            Unweighted per-task scalar losses.

        Returns
        -------
        Tensor
            Weighted scalar total loss.
        """
        if not raw:
            raise ValueError(
                "No losses were computed. "
                "Make sure losses are added before calling forward()."
            )
        weights = self._weight_strategy.compute_weights(raw, step=self._step)
        total: Optional[Tensor] = None
        for k in raw:
            term = weights[k] * raw[k]
            total = term if total is None else total + term
        extra = self._weight_strategy.extra_loss()
        if extra is not None:
            total = total + extra  # type: ignore[operator]
        self._step += 1
        return total  # type: ignore[return-value]

    # ==================================================================
    # Backward context injection & unified backward / eval step
    # ==================================================================

    def set_engine(self, engine: Any, network: nn.Module) -> None:
        """Consolidated post-prepare setup: inject engine into weight strategy and
        cache the backward context. Call this once after ``engine.prepare()``,
        passing the prepared (DDP-wrapped) network.

        Parameters
        ----------
        engine : AccelerateEngine (or compatible)
        network : nn.Module
            The prepared network (already passed through ``engine.prepare``).
        """
        self._weight_strategy.set_engine(engine)
        self.setup_backward_context(network, engine)

    def setup_backward_context(
        self,
        network: nn.Module,
        engine: Any,
    ) -> None:
        """Inject *network* and *engine* references for :meth:`backward_step`
        and :meth:`eval_step`.

        Must be called **after** ``engine.prepare(...)`` so that *network*
        is the DDP-wrapped module.

        Parameters
        ----------
        network : nn.Module
            The training network (already passed through ``engine.prepare``).
        engine : AccelerateEngine (or compatible)
            Training engine providing ``backward``, ``reduce``, and
            ``get_nosync_context`` / ``get_null_context`` methods.
        """
        self._bwd_network = network
        self._bwd_engine = engine

        # Pre-cache the trainable parameter list so that we avoid
        # rebuilding it on every micro-batch (measurable overhead for
        # large models).
        self._bwd_params: List[nn.Parameter] = [
            p for p in network.parameters() if p.requires_grad
        ]

        # Cache the optimisation-mode enum value to avoid repeated
        # property lookups in the hot path.
        self._cached_opt_mode: LossWeightStrategyOptimizeMode = (
            self._weight_strategy.optimize_mode
        )

    # ── sync context helper ──────────────────────────────────────────

    def get_sync_context(self, is_last_micro: bool = True):
        """Return the appropriate DDP synchronisation context manager.

        Selection rules:

        * Non-final micro-batch → ``nosync`` (defer all-reduce).
        * Final micro-batch **and** not ``grad_inner`` → ``null``
          (DDP fires the all-reduce automatically).
        * Final micro-batch **and** ``grad_inner`` → ``nosync``
          (:meth:`backward_step` performs a manual all-reduce instead).
        * For plain (non-superbatch) usage the default
          ``is_last_micro=True`` produces the correct behaviour.

        Parameters
        ----------
        is_last_micro : bool
            Whether the current micro-batch is the last one in a
            super-batch.  For plain batches leave as ``True`` (default).

        Returns
        -------
        contextmanager
            Either a null context or a DDP no-sync context.
        """
        engine = self._bwd_engine
        if is_last_micro and self._cached_opt_mode is not LossWeightStrategyOptimizeMode.grad_inner:
            return engine.get_null_context()
        return engine.get_nosync_context(self._bwd_network)

    # ── internal helper ──────────────────────────────────────────────

    @staticmethod
    def _detach_raw(raw: Dict[str, Tensor]) -> Dict[str, float]:
        """Convert raw loss tensors to a plain ``{name: float}`` dict."""
        return {k: v.item() for k, v in raw.items()}

    # ── unified backward step ────────────────────────────────────────

    def backward_step(
        self,
        accum_steps: int = 1,
        is_last_micro: bool = True,
        **micro_outputs,
    ) -> Tuple[float, Dict[str, float]]:
        """Compute losses and execute the backward pass.

        Internally dispatches to the correct logic based on the active
        :class:`LossWeightStrategyOptimizeMode`:

        * **params_optimize_together** – scalar-weight strategies
          (Static / Uncertainty / DWA / RLW).  Weighted total is scaled
          by ``1 / accum_steps`` and passed to ``engine.backward``.
        * **grad_inner** – gradient-surgery strategies (PCGrad / CAGrad).
          Per-task losses are scaled by ``1 / accum_steps``; the
          strategy writes gradients directly into ``param.grad``.  On
          the final micro-batch a manual all-reduce is issued (all
          micro-batches run under ``nosync``).
        * **params_optimize_two_stage** – two-stage strategies
          (GradNorm).  Stage 1 back-propagates the weighted task loss
          with ``retain_graph=True``; Stage 2 back-propagates the
          GradNorm auxiliary loss.

        Compatible with both **super-batch** (gradient-accumulation,
        ``accum_steps > 1``) and **plain batch** (``accum_steps = 1``,
        the default) workflows.

        Parameters
        ----------
        accum_steps : int
            Number of gradient-accumulation steps (i.e. micro-batches in
            one super-batch).  Set to ``1`` (default) for plain batches
            — no additional scaling is applied.
        is_last_micro : bool
            Whether this is the last micro-batch of the super-batch.
            Set to ``True`` (default) for plain batches.  Only affects
            behaviour under the ``grad_inner`` mode (triggers the manual
            DDP all-reduce).
        **micro_outputs
            Network outputs forwarded directly to the loss computation.

        Returns
        -------
        loss_val : float
            Scalar loss for this micro-batch (already divided by
            *accum_steps*).
        raw_losses : Dict[str, float]
            Unweighted per-task losses (**not** divided by
            *accum_steps*), suitable for logging / debugging.
        """
        engine = self._bwd_engine
        mode = self._cached_opt_mode

        # Pre-compute reciprocal; when accum_steps == 1 the branches
        # are skipped entirely so no floating-point cost is incurred.
        inv_accum = 1.0 / accum_steps if accum_steps > 1 else 1.0

        if mode is LossWeightStrategyOptimizeMode.params_optimize_together:
            # ── Case A: Scalar-weight strategies ────────────────────
            raw = self._compute_raw_losses(**micro_outputs)
            total_loss = self._apply_weights(raw)
            if accum_steps > 1:
                total_loss = total_loss * inv_accum
            engine.backward(total_loss)
            loss_val = total_loss.item()

        elif mode is LossWeightStrategyOptimizeMode.grad_inner:
            # ── Case B: Gradient-surgery strategies ─────────────────
            raw = self._compute_raw_losses(**micro_outputs)
            if accum_steps > 1:
                scaled_raw = {k: v * inv_accum for k, v in raw.items()}
            else:
                scaled_raw = raw

            self._weight_strategy.backward(scaled_raw, self._bwd_params)

            # All micro-batches run under nosync; on the final one we
            # manually all-reduce gradients across DDP ranks.
            if is_last_micro:
                for param in self._bwd_params:
                    if param.grad is not None:
                        param.grad = engine.reduce(param.grad, reduction="mean")

            n = len(raw)
            loss_val = sum(v.item() for v in raw.values()) / n * inv_accum

        elif mode is LossWeightStrategyOptimizeMode.params_optimize_two_stage:
            # ── Case C: Two-stage strategies (GradNorm) ─────────────
            raw = self._compute_raw_losses(**micro_outputs)
            total_loss = self._weight_strategy.weighted_loss(raw)
            if accum_steps > 1:
                total_loss = total_loss * inv_accum

            # Stage 1: retain the graph so Stage 2 can still compute
            # torch.autograd.grad through it.
            engine.backward(total_loss, retain_graph=True)

            # Stage 2: GradNorm auxiliary loss → weight gradients.
            gn_loss = self._weight_strategy.gradnorm_loss(
                raw, self._bwd_params,
            )
            if accum_steps > 1:
                gn_loss = gn_loss * inv_accum
            engine.backward(gn_loss)

            loss_val = total_loss.item()

        else:
            raise RuntimeError(
                f"Unrecognised optimisation mode: {mode}. "
                "Expected params_optimize_together / grad_inner / "
                "params_optimize_two_stage."
            )

        # Cache the unweighted raw losses (not divided by accum_steps)
        # for external inspection via :attr:`last_raw_losses`.
        self._last_raw_losses = self._detach_raw(raw)
        return loss_val, self._last_raw_losses

    # ── unified eval step (no backward, consistent interface) ────────

    def eval_step(
        self,
        accum_steps: int = 1,
        **micro_outputs,
    ) -> Tuple[float, Dict[str, float]]:
        """Compute losses without executing a backward pass.

        The return signature is identical to :meth:`backward_step`,
        making it straightforward to share logging / metric-collection
        code between training and evaluation.

        Compatible with both **super-batch** (``accum_steps > 1``) and
        **plain batch** (``accum_steps = 1``, the default) workflows.

        Parameters
        ----------
        accum_steps : int
            Accumulation-step count used for loss scaling, mirroring the
            training side.  Defaults to ``1`` (no scaling).
        **micro_outputs
            Network outputs forwarded directly to the loss computation.

        Returns
        -------
        loss_val : float
            Scalar loss (already divided by *accum_steps*).
        raw_losses : Dict[str, float]
            Unweighted per-task losses (**not** divided by
            *accum_steps*), suitable for logging / debugging.
        """
        raw = self._compute_raw_losses(**micro_outputs)
        total_loss = self._apply_weights(raw)
        inv_accum = 1.0 / accum_steps if accum_steps > 1 else 1.0
        loss_val = total_loss.item() * inv_accum

        self._last_raw_losses = self._detach_raw(raw)
        return loss_val, self._last_raw_losses

    # ── property: last raw losses ────────────────────────────────────

    @property
    def last_raw_losses(self) -> Dict[str, float]:
        """Unweighted per-task losses from the most recent step.

        Returns a ``{task_name: float}`` dict that can be fed directly
        to TensorBoard / WandB / CSV loggers.  Returns an empty dict
        before the first :meth:`backward_step` or :meth:`eval_step`
        call.
        """
        return self._last_raw_losses

    # ==================================================================
    # Original forward (unchanged — still usable for simple paths)
    # ==================================================================

    def forward(self, *args, **kwargs) -> Tensor:
        """Compute the total combined loss.

        Calls :meth:`_compute_raw_losses` then :meth:`_apply_weights`.

        Returns
        -------
        Tensor
            Scalar total loss.
        """
        raw = self._compute_raw_losses(*args, **kwargs)
        return self._apply_weights(raw)

    # ------------------------------------------------------------------
    # Abstract interface for subclasses
    # ------------------------------------------------------------------

    @abstractmethod
    def add_loss(
        self,
        name: str,
        loss_fn: nn.Module,
        wrapper: Optional[Any] = None,
    ) -> None:
        """Register a loss function with the manager.

        Weights are **not** specified here.  Configure them through
        ``manager.weight_strategy`` after construction, e.g.::

            manager.weight_strategy.update_weight('mse', 2.0)

        or by passing a pre-configured strategy to the manager constructor::

            manager = DirectLossManager(
                weight_strategy=StaticWeightStrategy({'mse': 2.0})
            )

        Parameters
        ----------
        name : str
            Unique name for the loss.
        loss_fn : nn.Module
            Loss function module.
        wrapper : optional
            Per-manager routing / transform wrapper (type depends on
            the concrete manager subclass).

        Raises
        ------
        ValueError
            If *name* is already registered.
        """

    def build(self):
        pass

    @abstractmethod
    def to(self, device: Union[str, torch.device]) -> 'BaseLossManager':
        """Move all managed loss functions to *device*."""
        super().to(device)  # delegate to nn.Module.to() to move registered params/submodules
        return self

    @abstractmethod
    def del_loss(self, name: str) -> None:
        """Remove a loss function by *name*.

        Raises
        ------
        KeyError
            If *name* is not registered.
        """

    def get_loss_names(self) -> list:
        """Return a list of all registered loss names."""
        return []

    def get_loss_weights(self) -> Dict[str, float]:
        """Return the most recently computed effective weights.

        Delegates to
        :meth:`~.weight_strategy.BaseWeightStrategy.get_current_weights`.
        Returns an empty dict before the first forward pass.
        """
        return self._weight_strategy.get_current_weights()
