# -*- coding: utf-8 -*-
"""
Vector field operations for 4D spatio-temporal magnetic fields.

Provides efficient computation of divergence, curl, and norm for
magnetic field tensors used in solar physics applications.

Two backends:
  - ``"gradient"`` (default on CUDA): uses ``torch.gradient`` — accurate,
    well-optimised on GPU.
  - ``"conv3d"`` (default on NPU): uses 3D depthwise convolution for spatial
    gradients — single kernel launch per component, much faster on Ascend
    NPU where ``torch.gradient`` degrades to multiple slice+subtract ops.

The default backend is selected automatically based on device type:
  CUDA → ``"gradient"``
  NPU  → ``"conv3d"``
Override via the ``backend`` parameter.
"""

from typing import Optional, Tuple

import torch
import torch.nn.functional as F
from torch import Tensor


__all__ = [
    "vector_field_ops_4D",
    "validate_mask",
]


# ─────────────────────────────────────────────────────────────────────────────
# Conv3d gradient backend — cached kernels
# ─────────────────────────────────────────────────────────────────────────────

# Module-level cache: (device, dtype) → (kx, ky, kz)
_CONV_KERNEL_CACHE: dict = {}


def _get_gradient_kernels(
    dx: float,
    device: torch.device,
    dtype: torch.dtype,
) -> Tuple[Tensor, Tensor, Tensor]:
    """Return cached 3×1×1 / 1×3×1 / 1×1×3 central-difference kernels.

    Central difference: [-1, 0, 1] / (2 * dx)
    Kernels are created once per (device, dtype) pair and reused.
    """
    key = (str(device), dtype, dx)
    if key not in _CONV_KERNEL_CACHE:
        coeff = 1.0 / (2.0 * dx)
        kx = torch.zeros(1, 1, 3, 1, 1, device=device, dtype=dtype)
        kx[0, 0, 0, 0, 0] = -coeff
        kx[0, 0, 2, 0, 0] = coeff

        ky = torch.zeros(1, 1, 1, 3, 1, device=device, dtype=dtype)
        ky[0, 0, 0, 0, 0] = -coeff
        ky[0, 0, 0, 2, 0] = coeff

        kz = torch.zeros(1, 1, 1, 1, 3, device=device, dtype=dtype)
        kz[0, 0, 0, 0, 0] = -coeff
        kz[0, 0, 0, 0, 2] = coeff

        _CONV_KERNEL_CACHE[key] = (kx, ky, kz)
    return _CONV_KERNEL_CACHE[key]


def _gradient_conv3d(
    component: Tensor,
    dx: float,
) -> Tuple[Tensor, Tensor, Tensor]:
    """Compute spatial gradients of a single field component via Conv3d.

    Parameters
    ----------
    component : Tensor
        Shape ``(N, D, H, W)`` where N = batch * T.
    dx : float
        Isotropic grid spacing.

    Returns
    -------
    (grad_d, grad_h, grad_w) : tuple of Tensor
        Each has the same shape as *component*.
    """
    device, dtype = component.device, component.dtype
    # conv3d needs float32 for kernel precision
    comp = component.unsqueeze(1).float()        # (N, 1, D, H, W)
    kx, ky, kz = _get_gradient_kernels(dx, device, torch.float32)

    grad_d = F.conv3d(F.pad(comp, (0, 0, 0, 0, 1, 1), mode='replicate'), kx)
    grad_h = F.conv3d(F.pad(comp, (0, 0, 1, 1, 0, 0), mode='replicate'), ky)
    grad_w = F.conv3d(F.pad(comp, (1, 1, 0, 0, 0, 0), mode='replicate'), kz)

    return (
        grad_d.squeeze(1).to(dtype),
        grad_h.squeeze(1).to(dtype),
        grad_w.squeeze(1).to(dtype),
    )


# ─────────────────────────────────────────────────────────────────────────────
# torch.gradient backend (original)
# ─────────────────────────────────────────────────────────────────────────────

def _gradient_torch(
    component: Tensor,
    dx: float,
    dims: Tuple[int, ...] = (1, 2, 3),
) -> Tuple[Tensor, Tensor, Tensor]:
    """Compute spatial gradients via ``torch.gradient`` (edge_order=2).

    Parameters
    ----------
    component : Tensor
        Shape ``(batch, D, H, W, T)``.
    dx : float
        Isotropic grid spacing.
    dims : tuple of int
        Spatial dimensions to differentiate over.

    Returns
    -------
    (grad_d, grad_h, grad_w) : tuple of Tensor
    """
    spacing = (dx, dx, dx)
    grads = torch.gradient(component, spacing=spacing, dim=dims, edge_order=2)
    return grads[0], grads[1], grads[2]


# ─────────────────────────────────────────────────────────────────────────────
# Unified entry point
# ─────────────────────────────────────────────────────────────────────────────

def _auto_backend(device: torch.device) -> str:
    """Select default backend: CUDA → gradient, NPU → conv3d."""
    dev_type = str(device).split(':')[0]
    if dev_type == 'npu':
        return 'conv3d'
    return 'gradient'


def vector_field_ops_4D(
    B: Tensor,
    dx: float = 0.36,
    compute_div: bool = True,
    compute_curl: bool = True,
    compute_norm: bool = True,
    backend: Optional[str] = None,
) -> Tuple[Optional[Tensor], Optional[Tensor], Optional[Tensor]]:
    """
    Compute divergence, curl, and norm of a 4-D spatio-temporal vector field.

    Parameters
    ----------
    B : Tensor
        Magnetic field, shape ``(batch, 3, D, H, W, T)``.
        Channels correspond to [Bx, By, Bz].
    dx : float
        Isotropic grid spacing in physical units (default 0.36).
        HMI CEA raw set 0.3645, if down 1 set 0.729, if down 2 set 1.458
    compute_div : bool
        Whether to compute ∇·B (divergence).
    compute_curl : bool
        Whether to compute ∇×B (curl / current density J).
    compute_norm : bool
        Whether to compute |B| (field magnitude).
    backend : str or None
        ``"gradient"`` — use ``torch.gradient`` (default on CUDA).
        ``"conv3d"``   — use 3D convolution (default on NPU / Ascend).
        ``None``       — auto-select based on device type.

    Returns
    -------
    div_B : Tensor or None
        Divergence ∇·B with shape ``(batch, D, H, W, T)``.
    curl_B : Tensor or None
        Curl ∇×B (current density J) with shape ``(batch, 3, D, H, W, T)``.
    B_norm : Tensor or None
        Field magnitude |B| with shape ``(batch, D, H, W, T)``.
    """
    if B.shape[1] != 3:
        raise ValueError(
            f"Channel dim must be 3 (Bx, By, Bz), got {B.shape[1]}"
        )

    batch, _, D, H, W, T = B.shape
    if min(D, H, W) < 3:
        raise ValueError(
            f"torch.gradient(edge_order=2) requires spatial dims >= 3, "
            f"got D={D}, H={H}, W={W}."
        )

    if backend is None:
        backend = _auto_backend(B.device)

    # Split components: each is (batch, D, H, W, T)
    Bx, By, Bz = B[:, 0], B[:, 1], B[:, 2]

    div_B: Optional[Tensor] = None
    curl_B: Optional[Tensor] = None
    B_norm: Optional[Tensor] = None

    if compute_div or compute_curl:

        if backend == 'conv3d':
            # ── Conv3d path: merge T into batch, compute 3D gradients ────
            # Reshape: (batch, D, H, W, T) → (batch*T, D, H, W)
            Bx_flat = Bx.permute(0, 4, 1, 2, 3).reshape(batch * T, D, H, W)
            By_flat = By.permute(0, 4, 1, 2, 3).reshape(batch * T, D, H, W)
            Bz_flat = Bz.permute(0, 4, 1, 2, 3).reshape(batch * T, D, H, W)

            dBx_dx, dBx_dy, dBx_dz = _gradient_conv3d(Bx_flat, dx)
            dBy_dx, dBy_dy, dBy_dz = _gradient_conv3d(By_flat, dx)
            dBz_dx, dBz_dy, dBz_dz = _gradient_conv3d(Bz_flat, dx)

            # Reshape back: (batch*T, D, H, W) → (batch, D, H, W, T)
            def _unflatten(t: Tensor) -> Tensor:
                return t.reshape(batch, T, D, H, W).permute(0, 2, 3, 4, 1)

            if compute_div:
                div_B = _unflatten(dBx_dx + dBy_dy + dBz_dz)

            if compute_curl:
                curl_B = torch.empty_like(B)
                curl_B[:, 0] = _unflatten(dBz_dy - dBy_dz)  # Jx
                curl_B[:, 1] = _unflatten(dBx_dz - dBz_dx)  # Jy
                curl_B[:, 2] = _unflatten(dBy_dx - dBx_dy)  # Jz

            del dBx_dx, dBx_dy, dBx_dz
            del dBy_dx, dBy_dy, dBy_dz
            del dBz_dx, dBz_dy, dBz_dz

        else:
            # ── torch.gradient path (original) ───────────────────────────
            dims = (1, 2, 3)

            if compute_div:
                div_B = torch.zeros_like(Bx)
            if compute_curl:
                curl_B = torch.empty_like(B)

            grads_Bx = _gradient_torch(Bx, dx, dims)
            if compute_div:
                div_B.add_(grads_Bx[0])
            if compute_curl:
                curl_B[:, 1].copy_(grads_Bx[2])         # Jy =  ∂Bx/∂z − ...
                curl_B[:, 2].copy_(grads_Bx[1]).neg_()   # Jz = −∂Bx/∂y + ...
            del grads_Bx

            grads_By = _gradient_torch(By, dx, dims)
            if compute_div:
                div_B.add_(grads_By[1])
            if compute_curl:
                curl_B[:, 0].copy_(grads_By[2]).neg_()   # Jx = −∂By/∂z + ...
                curl_B[:, 2].add_(grads_By[0])            # Jz += ∂By/∂x
            del grads_By

            grads_Bz = _gradient_torch(Bz, dx, dims)
            if compute_div:
                div_B.add_(grads_Bz[2])
            if compute_curl:
                curl_B[:, 0].add_(grads_Bz[1])            # Jx += ∂Bz/∂y
                curl_B[:, 1].sub_(grads_Bz[0])             # Jy −= ∂Bz/∂x
            del grads_Bz

    if compute_norm:
        B_norm = torch.linalg.norm(B, ord=2, dim=1)  # (batch, D, H, W, T)

    return div_B, curl_B, B_norm


def validate_mask(mask: Tensor, expected_shape: Tuple[int, ...]) -> None:
    """Validate mask dtype and shape for physics metrics."""
    if mask.dtype != torch.bool:
        raise ValueError(f"mask dtype must be torch.bool, got {mask.dtype}")
    if mask.shape != expected_shape:
        raise ValueError(
            f"mask shape {list(mask.shape)} does not match "
            f"field shape {list(expected_shape)}"
        )
