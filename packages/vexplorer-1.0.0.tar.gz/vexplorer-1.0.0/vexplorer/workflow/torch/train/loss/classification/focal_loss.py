# -*- coding: utf-8 -*-
"""
Focal Loss for addressing class imbalance in classification tasks.

Focal Loss is designed to address class imbalance by down-weighting the loss
assigned to well-classified examples. This allows the model to focus more on
hard, misclassified examples.

Reference:
    Lin et al. (2017), "Focal Loss for Dense Object Detection"
    https://arxiv.org/abs/1708.02002
"""

import torch
import torch.nn as nn
import torchvision.ops


__all__ = ['FocalLoss']


class FocalLoss(nn.Module):
    """
    Focal Loss for binary or multi-class classification.

    The focal loss applies a modulating term to the cross entropy loss to focus
    training on hard negative examples. It is particularly useful for addressing
    class imbalance during training.

    The focal loss is defined as:
        FL(p_t) = -α_t * (1 - p_t)^γ * log(p_t)

    where:
        - p_t is the model's estimated probability for the class with label y
        - α_t is the weighting factor in [0, 1] to balance positive/negative examples
        - γ is the focusing parameter (γ ≥ 0) to adjust the rate at which easy
          examples are down-weighted

    Parameters
    ----------
    alpha : float
        Weighting factor in range [0, 1] to balance positive vs negative examples.
        Default: 0.25 (slight emphasis on positive examples).
    gamma : float
        Exponent of the modulating factor (1 - p_t).
        Higher gamma increases the focus on hard examples.
        Default: 2.0.
    reduction : str
        Specifies the reduction to apply to the output:
        - 'none': no reduction, return per-sample losses
        - 'mean': return the mean of losses
        - 'sum': return the sum of losses
        Default: 'mean'.

    Input
    -----
    inputs : Tensor
        Predicted logits with shape ``(N, C)`` for multi-class or ``(N,)`` for binary.
        For binary classification, logits should be raw (not passed through sigmoid).
    targets : Tensor
        Ground truth labels with the same shape as inputs.
        For multi-class: integer class indices with shape ``(N,)``.
        For binary: float labels in [0, 1] with shape matching inputs.

    Returns
    -------
    loss : Tensor
        Computed focal loss. Scalar if reduction='mean' or 'sum',
        otherwise has the same shape as inputs.

    Examples
    --------
    >>> # Binary classification example
    >>> criterion = FocalLoss(alpha=0.25, gamma=2.0, reduction='mean')
    >>> inputs = torch.randn(10, 1, requires_grad=True)  # Logits
    >>> targets = torch.randint(0, 2, (10, 1)).float()   # Binary labels
    >>> loss = criterion(inputs, targets)
    >>> loss.backward()

    >>> # Multi-class classification example
    >>> criterion = FocalLoss(alpha=0.25, gamma=2.0, reduction='mean')
    >>> inputs = torch.randn(8, 5, requires_grad=True)   # 5 classes
    >>> targets = torch.randint(0, 5, (8,))              # Class indices
    >>> # Convert to one-hot encoding
    >>> targets_one_hot = torch.nn.functional.one_hot(targets, num_classes=5).float()
    >>> loss = criterion(inputs, targets_one_hot)
    >>> loss.backward()

    Notes
    -----
    - This implementation uses torchvision.ops.sigmoid_focal_loss internally,
      which expects inputs to be logits (not probabilities).
    - The loss automatically applies sigmoid activation to inputs.
    - For multi-class problems, consider using standard cross-entropy with
      class weights as an alternative.
    """

    def __init__(self, alpha: float = 0.25, gamma: float = 2.0, reduction: str = 'mean'):
        super(FocalLoss, self).__init__()
        self.alpha = alpha
        self.gamma = gamma
        self.reduction = reduction
        self.loss = torchvision.ops.sigmoid_focal_loss

    def forward(self, inputs: torch.Tensor, targets: torch.Tensor) -> torch.Tensor:
        """
        Compute the focal loss.

        Parameters
        ----------
        inputs : Tensor
            Predicted logits (before sigmoid).
        targets : Tensor
            Ground truth labels.

        Returns
        -------
        loss : Tensor
            Computed focal loss.
        """
        loss = self.loss(
            inputs=inputs,
            targets=targets,
            alpha=self.alpha,
            gamma=self.gamma,
            reduction=self.reduction
        )
        return loss


# Alternative manual implementation (commented out):
# This is the original manual implementation before using torchvision.ops
# Kept for reference and understanding of the focal loss computation
#
# def forward(self, inputs, targets):
#     """
#     Manual focal loss computation.
#
#     Steps:
#     1. Compute standard cross-entropy loss (without reduction)
#     2. Calculate p_t = exp(-ce_loss) (probability of correct class)
#     3. Apply focal loss formula: α * (1 - p_t)^γ * ce_loss
#     4. Apply reduction (mean or sum)
#     """
#     ce_loss = F.cross_entropy(inputs, targets, reduction='none')
#     pt = torch.exp(-ce_loss)
#     focal_loss = (self.alpha * (1 - pt) ** self.gamma * ce_loss)
#
#     if self.reduction == 'mean':
#         return torch.mean(focal_loss)
#     elif self.reduction == 'sum':
#         return torch.sum(focal_loss)
#     else:
#         return focal_loss
