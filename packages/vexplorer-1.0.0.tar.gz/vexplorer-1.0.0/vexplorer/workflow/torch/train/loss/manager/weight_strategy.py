# -*- coding: utf-8 -*-
"""
Multi-task loss weighting strategies.

Strategies are split into two broad families:

Loss-value strategies (plug transparently into manager.forward)
---------------------------------------------------------------
  StaticWeightStrategy       Fixed scalar weights — default behaviour.
  UncertaintyWeightStrategy  Learnable per-task uncertainty (UW).
                             Kendall et al., CVPR 2018.
  DWAStrategy                Dynamic Weight Averaging.
                             Liu et al., CVPR 2019.
  RLWStrategy                Random Loss Weighting (Dirichlet sampling).
                             Lin et al., TMLR 2022.

Gradient strategies (require a custom training loop)
-----------------------------------------------------
  GradNormStrategy           Gradient normalisation with learnable task
                             weights.  Chen et al., ICML 2018.
  PCGradStrategy             Project Conflicting Gradients.
                             Yu et al., NeurIPS 2020.
  CAGradStrategy             Conflict-Averse Gradient Descent.
                             Liu et al., NeurIPS 2021.

Usage summary
-------------
Loss-value strategies plug into any manager via::

    manager = DirectLossManager(weight_strategy=UncertaintyWeightStrategy(...))
    loss = manager(pred, target)          # weights adjusted automatically
    loss.backward()

Gradient strategies are invoked explicitly after computing raw losses::

    raw = manager.compute_raw_losses(pred, target)
    strategy.backward(raw, model.parameters())   # custom backward

For mixed-precision support, inject the engine once after construction::

    strategy.set_engine(engine)                   # caches scaler reference
    # ... later in the training loop ...
    strategy.backward(raw, model.parameters())    # scaler applied automatically

References
----------
Kendall et al. (2018) "Multi-Task Learning Using Uncertainty to Weigh Losses
    for Scene Geometry and Semantics." CVPR.
Liu et al. (2019) "End-to-End Multi-Task Learning with Attention." CVPR.
Lin et al. (2022) "Reasonable Effectiveness of Random Weighting: A Litmus Test
    for Multi-Task Learning." TMLR.
Chen et al. (2018) "GradNorm: Gradient Normalization for Adaptive Loss
    Balancing in Deep Multitask Networks." ICML.
Yu et al. (2020) "Gradient Surgery for Multi-Task Learning." NeurIPS.
Liu et al. (2021) "Conflict-Averse Gradient Descent for Multi-task
    Learning." NeurIPS.
"""

from abc import ABC, abstractmethod
from enum import Enum
from typing import Any, Dict, Iterator, List, Optional, Sequence, Tuple

import torch
import torch.nn as nn
import torch.nn.functional as F
from torch import Tensor


__all__ = [
    "BaseWeightStrategy",
    "StaticWeightStrategy",
    "UncertaintyWeightStrategy",
    "DWAStrategy",
    "RLWStrategy",
    "GradNormStrategy",
    "PCGradStrategy",
    "CAGradStrategy",
]


class LossWeightStrategyOptimizeMode(str, Enum):
    """Optimisation mode communicated to the runner / loss manager."""

    params_optimize_together = "params_optimize_together"
    params_optimize_two_stage = "params_optimize_two_stage"
    grad_inner = "grad_inner"


# =========================================================================
# Helper utilities
# =========================================================================

def _safe_item(v: torch.Tensor, default: float = 0.0) -> float:
    """Safely convert a 1-element tensor to a scalar, returning default if empty."""
    return v.item() if v.numel() > 0 else default


def _flat_grad(
        loss: Tensor,
        params: List[nn.Parameter],
        *,
        retain_graph: bool = True,
        create_graph: bool = False,
        allow_unused: bool = True,
) -> Tensor:
    """Compute the flat gradient of *loss* w.r.t. *params*.

    Returns a single 1-D tensor that is the concatenation of all
    per-parameter gradients.  ``None`` entries (from ``allow_unused``)
    are replaced with zeros.
    """
    grads = torch.autograd.grad(
        loss, params,
        retain_graph=retain_graph,
        create_graph=create_graph,
        allow_unused=allow_unused,
    )
    segments = [
        g.reshape(-1) if g is not None else torch.zeros(p.numel(), device=p.device)
        for g, p in zip(grads, params)
    ]
    return torch.cat(segments)


def _write_grad(g_flat: Tensor, params: List[nn.Parameter]) -> None:
    """Scatter a flat gradient vector back into ``param.grad`` attributes."""
    offset = 0
    for param in params:
        numel = param.numel()
        chunk = g_flat[offset: offset + numel].reshape(param.shape)
        if param.grad is None:
            param.grad = chunk.clone()
        else:
            param.grad.copy_(chunk)
        offset += numel


# ---------------------------------------------------------------------------
# Abstract base
# ---------------------------------------------------------------------------

class BaseWeightStrategy(nn.Module, ABC):
    """
    Abstract base class for multi-task loss weighting strategies.

    Subclasses must implement :meth:`compute_weights`.  Gradient-level
    strategies additionally override :meth:`backward`.

    The contract with managers
    --------------------------
    1. The manager collects raw (unweighted) per-task losses into a dict.
    2. It calls ``strategy.compute_weights(raw_losses, step)`` to obtain
       per-task weight tensors.
    3. It forms ``total = Σ weights[i] * raw[i] + strategy.extra_loss()``.
    4. For gradient strategies (``is_gradient_strategy() → True``), the
       training loop calls ``strategy.backward(raw, params)`` instead of
       ``total.backward()``.

    Engine injection
    ----------------
    Call :meth:`set_engine` once after the engine and strategy are both
    constructed.  This caches a reference to the ``GradScaler`` (if any)
    so that gradient-level strategies can produce correctly-scaled
    gradients under mixed precision.
    """

    def __init__(self) -> None:
        super().__init__()
        self._engine: Any = None
        self._scaler: Any = None          # cached GradScaler or None
        self._last_weights: Dict[str, float] = {}

    # ── engine / scaler management ────────────────────────────────────────

    def set_engine(self, engine: Any) -> None:
        """Inject the training engine and cache its ``GradScaler``.

        Call this once after both the engine and strategy are constructed
        (typically right after ``engine.prepare(...)``).

        Parameters
        ----------
        engine : AccelerateEngine (or compatible)
            The training engine.  ``engine.scaler`` is read once and cached.
        """
        self._engine = engine
        scaler = getattr(engine, "scaler", None)
        if scaler is not None and hasattr(scaler, "is_enabled") and not scaler.is_enabled():
            scaler = None
        self._scaler = scaler

    @property
    def engine(self) -> Any:
        """Return the injected engine, or ``None``."""
        return self._engine

    @property
    def scaler(self) -> Any:
        """Return the cached ``GradScaler``, or ``None``."""
        return self._scaler

    # ── interface ─────────────────────────────────────────────────────────

    @abstractmethod
    def compute_weights(
            self,
            raw_losses: Dict[str, Tensor],
            step: int = 0,
    ) -> Dict[str, Tensor]:
        """Return a per-task weight tensor for the current step.

        Parameters
        ----------
        raw_losses : Dict[str, Tensor]
            Mapping of task name → scalar loss tensor.
        step : int
            Current training step (0-indexed).

        Returns
        -------
        Dict[str, Tensor]
            Mapping of task name → scalar float weight tensor.
        """
        ...

    def get_optimize_mode(self) -> LossWeightStrategyOptimizeMode:
        return self.optimize_mode

    def extra_loss(self) -> Optional[Tensor]:
        """Optional extra scalar added to the weighted total (e.g. UW regularisation).

        Default: ``None`` (no extra term).
        """
        return None

    def is_gradient_strategy(self) -> bool:
        """Return ``True`` if this strategy requires a custom backward pass."""
        return False

    def backward(
            self,
            raw_losses: Dict[str, Tensor],
            shared_params: Iterator[nn.Parameter],
    ) -> None:
        """Perform the backward pass.

        Default: weighted sum → ``engine.backward()`` (or plain ``.backward()``).
        Gradient strategies override this.

        Parameters
        ----------
        raw_losses : Dict[str, Tensor]
            Raw per-task losses (computation graphs must be intact).
        shared_params : Iterator[nn.Parameter]
            Model parameters.
        """
        weights = self.compute_weights(raw_losses)
        total: Tensor = sum(weights[k] * v for k, v in raw_losses.items())  # type: ignore[assignment]
        extra = self.extra_loss()
        if extra is not None:
            total = total + extra
        if self._engine is not None:
            self._engine.backward(total)
        else:
            total.backward()

    def get_current_weights(self) -> Dict[str, float]:
        """Return the most recently computed weights as Python floats."""
        return self._last_weights


# ---------------------------------------------------------------------------
# 1. StaticWeightStrategy
# ---------------------------------------------------------------------------

class StaticWeightStrategy(BaseWeightStrategy):
    """
    Fixed scalar weights — default weighting behaviour.

    Any task not found in *weights* receives *default_weight*, so the
    strategy works out-of-the-box without pre-declaring task names.

    Parameters
    ----------
    weights : Dict[str, float] or None
        Mapping of task name → static weight.  ``None`` ≡ ``{}``.
    default_weight : float
        Weight for unspecified tasks.  Default: 1.0.

    Examples
    --------
    >>> StaticWeightStrategy({'mse': 1.0, 'div': 0.1, 'ff': 0.05})
    >>> StaticWeightStrategy()                          # all tasks = 1.0
    >>> StaticWeightStrategy({'div': 0.1}, default_weight=1.0)
    """

    def __init__(
            self,
            weights: Optional[Dict[str, float]] = None,
            default_weight: float = 1.0,
    ) -> None:
        super().__init__()
        self._weights: Dict[str, float] = dict(weights) if weights else {}
        self._default_weight = default_weight
        self.optimize_mode = LossWeightStrategyOptimizeMode.params_optimize_together

        # Tensor cache: avoids re-creating identical tensors every step.
        # Invalidated when task set or device changes.
        self._cached_tensors: Dict[str, Tensor] = {}
        self._cached_device: Optional[torch.device] = None

    def compute_weights(
            self, raw_losses: Dict[str, Tensor], step: int = 0,
    ) -> Dict[str, Tensor]:
        device = next(iter(raw_losses.values())).device
        keys = set(raw_losses.keys())

        # Rebuild cache only when task set or device changes.
        if device != self._cached_device or keys != set(self._cached_tensors.keys()):
            self._cached_tensors = {
                k: torch.tensor(
                    self._weights.get(k, self._default_weight),
                    device=device, dtype=torch.float,
                )
                for k in keys
            }
            self._cached_device = device

        self._last_weights = {k: _safe_item(self._cached_tensors[k]) for k in keys}
        return dict(self._cached_tensors)  # shallow copy — tensors are not mutated

    def update_weight(self, name: str, value: float) -> None:
        """Set the weight for a single task (invalidates tensor cache)."""
        self._weights[name] = value
        self._cached_tensors.clear()

    def set_weights(self, weights: Dict[str, float]) -> None:
        """Bulk-update weights (invalidates tensor cache)."""
        self._weights.update(weights)
        self._cached_tensors.clear()

    def extra_repr(self) -> str:
        parts = ", ".join(f"{k}={v}" for k, v in self._weights.items())
        return f"{parts}, default={self._default_weight}" if parts else f"default={self._default_weight}"


# ---------------------------------------------------------------------------
# 2. UncertaintyWeightStrategy  (UW — Kendall et al. 2018)
# ---------------------------------------------------------------------------

class UncertaintyWeightStrategy(BaseWeightStrategy):
    """
    Learnable uncertainty-based loss weighting (Kendall et al., CVPR 2018).

    Each task has a learnable log-variance ``s_i = log(σ²_i)``::

        L_i_eff = L_i · exp(−s_i) + s_i

    :meth:`compute_weights` returns ``exp(−s_i)`` (precision weights).
    :meth:`extra_loss` returns ``Σ s_i`` (log-variance regularisation).

    Parameters
    ----------
    task_names : sequence of str
        Names of tasks to assign learnable log-variances.

    Notes
    -----
    - ``strategy.parameters()`` must be passed to the optimizer.
    - Log-variances are initialised to 0 (σ² = 1 → equal initial weights).
    """

    def __init__(self, task_names: Sequence[str]) -> None:
        super().__init__()
        if not task_names:
            raise ValueError("task_names must be non-empty")
        # nn.ParameterDict forbids "." in keys; replace with "__"
        self._name_to_key = {name: name.replace(".", "__") for name in task_names}
        self._key_to_name = {v: k for k, v in self._name_to_key.items()}
        self.log_vars = nn.ParameterDict({
            self._name_to_key[name]: nn.Parameter(torch.zeros(1)) for name in task_names
        })
        self.optimize_mode = LossWeightStrategyOptimizeMode.params_optimize_together

    def compute_weights(
            self, raw_losses: Dict[str, Tensor], step: int = 0,
    ) -> Dict[str, Tensor]:
        result: Dict[str, Tensor] = {}
        for name in raw_losses:
            key = self._name_to_key.get(name)
            if key is None or key not in self.log_vars:
                raise KeyError(
                    f"Task '{name}' not registered in UncertaintyWeightStrategy. "
                    f"Known tasks: {list(self._name_to_key.keys())}"
                )
            s = self.log_vars[key]
            result[name] = torch.exp(-s).squeeze()  # 1/σ²
        self._last_weights = {k: _safe_item(v) for k, v in result.items()}
        return result

    def extra_loss(self) -> Tensor:
        """Return ``Σ log(σ²_i)`` — penalises infinite uncertainty."""
        # torch.stack → sum avoids int + Tensor from builtin sum().
        return torch.stack([s.squeeze() for s in self.log_vars.values()]).sum()

    def get_log_vars(self) -> Dict[str, float]:
        """Return current log-variance values per task."""
        return {self._key_to_name.get(k, k): _safe_item(v) for k, v in self.log_vars.items()}

    def extra_repr(self) -> str:
        return f"tasks=[{', '.join(self._name_to_key.keys())}]"


# ---------------------------------------------------------------------------
# 3. DWAStrategy  (Dynamic Weight Averaging — Liu et al. 2019)
# ---------------------------------------------------------------------------

class DWAStrategy(BaseWeightStrategy):
    """
    Dynamic Weight Averaging (Liu et al., CVPR 2019).

    Weights are proportional to the relative rate of loss change::

        r_i(t) = L_i(t−1) / L_i(t−2)
        w_i(t) = K · softmax(r(t) / T)_i

    Equal weights for the first two steps (insufficient history).

    Parameters
    ----------
    task_names : sequence of str
        Task names in a fixed order.
    temperature : float
        Softmax temperature T.  Higher → more uniform.  Default 2.0.

    Notes
    -----
    History tensors are registered as buffers so they survive
    ``model.to(device)`` / ``state_dict`` round-trips.
    """

    def __init__(
            self,
            task_names: Sequence[str],
            temperature: float = 2.0,
    ) -> None:
        super().__init__()
        if not task_names:
            raise ValueError("task_names must be non-empty")
        self.task_names: List[str] = list(task_names)
        self.T = temperature
        n = len(task_names)
        self.register_buffer("_loss_t1", torch.ones(n))  # L(t-1)
        self.register_buffer("_loss_t2", torch.ones(n))  # L(t-2)
        self.optimize_mode = LossWeightStrategyOptimizeMode.params_optimize_together

    def compute_weights(
            self, raw_losses: Dict[str, Tensor], step: int = 0,
    ) -> Dict[str, Tensor]:
        n = len(self.task_names)
        device = next(iter(raw_losses.values())).device

        if step < 2:
            w = torch.ones(n, device=device)
        else:
            rates = self._loss_t1.to(device) / (self._loss_t2.to(device) + 1e-8)
            w = n * torch.softmax(rates / self.T, dim=0)

        # Update history using in-place ops to preserve buffer registration.
        current = torch.stack([
            raw_losses[k].detach().float() for k in self.task_names
        ]).cpu()
        self._loss_t2.copy_(self._loss_t1)
        self._loss_t1.copy_(current)

        result = {k: w[i] for i, k in enumerate(self.task_names)}
        self._last_weights = {k: _safe_item(v) for k, v in result.items()}
        return result

    def extra_repr(self) -> str:
        return f"tasks={self.task_names}, temperature={self.T}"


# ---------------------------------------------------------------------------
# 4. RLWStrategy  (Random Loss Weighting — Lin et al. 2022)
# ---------------------------------------------------------------------------

class RLWStrategy(BaseWeightStrategy):
    """
    Random Loss Weighting (Lin et al., TMLR 2022).

    Samples from Dirichlet(α, …, α) scaled so ``Σ w_i = num_tasks``.

    Parameters
    ----------
    task_names : sequence of str
    distribution : {'dirichlet', 'normal'}
    alpha : float
        Concentration (default 1.0 = flat prior).

    Notes
    -----
    ``alpha → ∞`` → equal weighting; ``alpha → 0`` → winner-take-all.
    """

    def __init__(
            self,
            task_names: Sequence[str],
            distribution: str = "dirichlet",
            alpha: float = 1.0,
    ) -> None:
        super().__init__()
        if distribution not in ("dirichlet", "normal"):
            raise ValueError(f"distribution must be 'dirichlet' or 'normal', got {distribution!r}")
        if not task_names:
            raise ValueError("task_names must be non-empty")
        self.task_names: List[str] = list(task_names)
        self.distribution = distribution
        self.alpha = alpha
        self.optimize_mode = LossWeightStrategyOptimizeMode.params_optimize_together

    def compute_weights(
            self, raw_losses: Dict[str, Tensor], step: int = 0,
    ) -> Dict[str, Tensor]:
        n = len(self.task_names)
        device = next(iter(raw_losses.values())).device

        if self.distribution == "dirichlet":
            concentration = torch.full((n,), self.alpha, device=device)
            w = torch.distributions.Dirichlet(concentration).sample() * n
        else:
            w = torch.abs(torch.randn(n, device=device))
            w = w / (w.sum() + 1e-8) * n

        result = {k: w[i] for i, k in enumerate(self.task_names)}
        self._last_weights = {k: _safe_item(v) for k, v in result.items()}
        return result

    def extra_repr(self) -> str:
        return f"tasks={self.task_names}, distribution={self.distribution!r}, alpha={self.alpha}"


# ---------------------------------------------------------------------------
# 5. GradNormStrategy  (Chen et al. 2018)
# ---------------------------------------------------------------------------

class GradNormStrategy(BaseWeightStrategy):
    """
    GradNorm: Gradient Normalization (Chen et al., ICML 2018).

    Learnable task weights ``w_i`` are adjusted so that per-task gradient
    norms track a difficulty-relative target::

        G_W_i(t) = ‖∇_{W_shared}(w_i · L_i)‖
        target_i = Ḡ_W(t) · r̃_i(t)
        L_GN     = Σ_i |G_W_i − target_i|

    Parameters
    ----------
    task_names : sequence of str
    alpha : float
        Asymmetry hyperparameter.  ``0`` → equal norms; larger → emphasise
        harder / faster tasks.  Recommended: 1.5.

    Training loop
    -------------
    GradNorm uses **two optimizers** (model params + task weights)::

        raw = manager.compute_raw_losses(pred, target)
        # model update (weights detached)
        total = strategy.weighted_loss(raw)
        engine.backward(total); model_opt.step(); model_opt.zero_grad()
        # weight update
        gn_loss = strategy.gradnorm_loss(raw, list(backbone.parameters()))
        engine.backward(gn_loss); w_opt.step(); w_opt.zero_grad()
        strategy.normalise_weights()

    Notes
    -----
    - Weights are stored in log-space to enforce positivity.
    - ``strategy.parameters()`` → one ``log_weight`` per task; pass to a
      separate optimizer.
    """

    def __init__(
            self,
            task_names: Sequence[str],
            alpha: float = 1.5,
    ) -> None:
        super().__init__()
        if not task_names:
            raise ValueError("task_names must be non-empty")
        self.task_names: List[str] = list(task_names)
        self.alpha = alpha
        n = len(task_names)
        self.log_weights = nn.ParameterDict({
            name: nn.Parameter(torch.zeros(1)) for name in task_names
        })
        self.register_buffer("_initial_losses", torch.zeros(n))
        self.register_buffer("_initialized", torch.tensor(False))
        self.optimize_mode = LossWeightStrategyOptimizeMode.params_optimize_two_stage

    def is_gradient_strategy(self) -> bool:
        return True

    @property
    def task_weights(self) -> Dict[str, Tensor]:
        """Current task weights (differentiable, linear scale)."""
        return {k: torch.exp(self.log_weights[k]).squeeze() for k in self.task_names}

    def compute_weights(
            self, raw_losses: Dict[str, Tensor], step: int = 0,
    ) -> Dict[str, Tensor]:
        """Return **detached** task weights for the model-parameter update."""
        tw = self.task_weights
        result = {k: tw[k].detach() for k in raw_losses}
        self._last_weights = {k: _safe_item(v) for k, v in result.items()}
        return result

    def weighted_loss(self, raw_losses: Dict[str, Tensor]) -> Tensor:
        """Weighted sum for the model update (weights detached)."""
        tw = self.compute_weights(raw_losses)
        return sum(tw[k] * raw_losses[k] for k in raw_losses)  # type: ignore[return-value]

    def gradnorm_loss(
            self,
            raw_losses: Dict[str, Tensor],
            shared_params: List[Tensor],
    ) -> Tensor:
        """Compute the GradNorm auxiliary loss for ``log_weights``.

        Parameters
        ----------
        raw_losses : Dict[str, Tensor]
            Current raw losses (graphs must be intact).
        shared_params : List[Tensor]
            Shared backbone parameters.

        Returns
        -------
        Tensor
            Scalar GradNorm loss.
        """
        tw = self.task_weights  # differentiable w.r.t. log_weights
        device = next(iter(raw_losses.values())).device

        # Store initial losses on first call (in-place to keep buffer).
        if not self._initialized.item():
            init = torch.stack([raw_losses[k].detach() for k in self.task_names])
            self._initial_losses.copy_(init.to(self._initial_losses.device))
            self._initialized.fill_(True)

        # Per-task gradient norms ‖∇_{W_shared}(w_i · L_i)‖
        task_grad_norms: List[Tensor] = []
        for k in self.task_names:
            flat = _flat_grad(
                tw[k] * raw_losses[k], shared_params,
                retain_graph=True, create_graph=True,
                )
            task_grad_norms.append(flat.norm(2))

        task_grad_norms_t = torch.stack(task_grad_norms)
        mean_norm = task_grad_norms_t.detach().mean()

        # Relative inverse training rates r̃_i
        current = torch.stack([raw_losses[k].detach() for k in self.task_names])
        r_i = (current / (self._initial_losses.to(device) + 1e-8)) ** self.alpha
        mean_r = r_i.mean()

        targets = (mean_norm * r_i / (mean_r + 1e-8)).detach()
        return F.l1_loss(task_grad_norms_t, targets)

    def normalise_weights(self) -> None:
        """Re-scale task weights so they sum to ``num_tasks``."""
        n = len(self.task_names)
        with torch.no_grad():
            log_w = torch.stack([
                self.log_weights[k] for k in self.task_names
            ]).squeeze(-1)
            # log-space normalisation avoids repeated exp/log:
            #   log(w_i / Σw · n) = log_w_i − logsumexp(log_w) + log(n)
            log_sum = torch.logsumexp(log_w, dim=0)
            log_n = torch.tensor(n, dtype=log_w.dtype, device=log_w.device).log()
            for i, k in enumerate(self.task_names):
                self.log_weights[k].data.fill_(log_w[i] - log_sum + log_n)

    def backward(
            self,
            raw_losses: Dict[str, Tensor],
            shared_params: Iterator[nn.Parameter],
    ) -> None:
        """Model-parameter backward (weights detached)."""
        total = self.weighted_loss(raw_losses)
        if self._engine is not None:
            self._engine.backward(total)
        else:
            total.backward()

    def extra_repr(self) -> str:
        return f"tasks={self.task_names}, alpha={self.alpha}"


# ---------------------------------------------------------------------------
# 6. PCGradStrategy  (Yu et al. 2020)
# ---------------------------------------------------------------------------

class PCGradStrategy(BaseWeightStrategy):
    """
    PCGrad: Projecting Conflicting Gradients (Yu et al., NeurIPS 2020).

    For conflicting task-gradient pairs, the conflicting component is
    projected out::

        if g_i · g_j < 0:
            g_i ← g_i − (g_i · g_j / ‖g_j‖²) g_j

    The final gradient is the mean of projected per-task gradients.

    Parameters
    ----------
    task_names : sequence of str

    Notes
    -----
    - O(n) backward passes, O(n² · d) projection cost.
    - Memory: n × total_param_count × 4 bytes (float32).
    - Projection uses the *original* (un-projected) ``g_j`` as per the
      paper.  Using the already-projected ``projected[j]`` is also valid
      but gives different theoretical properties.
    - When mixed-precision is active (``set_engine`` called with a scaler-
      enabled engine), each per-task loss is scaled before
      ``torch.autograd.grad`` so that the resulting ``param.grad`` values
      are in the scaled space expected by ``scaler.unscale_()`` /
      ``scaler.step()``.
    """

    def __init__(self, task_names: Sequence[str]) -> None:
        super().__init__()
        if not task_names:
            raise ValueError("task_names must be non-empty")
        self.task_names: List[str] = list(task_names)
        self.optimize_mode = LossWeightStrategyOptimizeMode.grad_inner

    def is_gradient_strategy(self) -> bool:
        return True

    def compute_weights(
            self, raw_losses: Dict[str, Tensor], step: int = 0,
    ) -> Dict[str, Tensor]:
        """PCGrad uses equal nominal weights; real adjustment is in backward."""
        device = next(iter(raw_losses.values())).device
        return {k: torch.ones(1, device=device) for k in raw_losses}

    def backward(
            self,
            raw_losses: Dict[str, Tensor],
            shared_params: Iterator[nn.Parameter],
    ) -> None:
        """Compute PCGrad-adjusted gradients and write to ``param.grad``.

        Parameters
        ----------
        raw_losses : Dict[str, Tensor]
            Raw per-task losses with live computation graphs.
        shared_params : Iterator[nn.Parameter]
            Model parameters.
        """
        params = [p for p in shared_params if p.requires_grad]
        names = list(raw_losses.keys())
        n = len(names)
        scaler = self._scaler

        # Step 1: flat gradient per task
        flat_grads: List[Tensor] = []
        for name in names:
            loss_i = raw_losses[name]
            if scaler is not None:
                loss_i = scaler.scale(loss_i)
            flat_grads.append(_flat_grad(loss_i, params))

        # Step 2: project conflicting components (using original g_j per paper)
        projected = [g.clone() for g in flat_grads]
        for i in range(n):
            for j in range(n):
                if i == j:
                    continue
                g_j = flat_grads[j]
                dot = torch.dot(projected[i], g_j)
                if dot < 0:
                    projected[i] = projected[i] - (dot / (g_j.norm().pow(2) + 1e-12)) * g_j

        # Step 3: mean → param.grad
        g_final = torch.stack(projected).mean(dim=0)
        _write_grad(g_final, params)

    def extra_repr(self) -> str:
        return f"tasks={self.task_names}"


# ---------------------------------------------------------------------------
# 7. CAGradStrategy  (Liu et al. 2021)
# ---------------------------------------------------------------------------

class CAGradStrategy(BaseWeightStrategy):
    """
    CAGrad: Conflict-Averse Gradient Descent (Liu et al., NeurIPS 2021).

    Finds ``g*`` close to ``g_avg`` that minimises worst-case conflict
    with individual task gradients, using a Frank-Wolfe approximation::

        φ_i = g_i · g_avg / ‖g_avg‖
        w   = softmax(−φ / ‖φ‖ · c · n)
        g*  = g_avg + c · Gᵀ w

    Parameters
    ----------
    task_names : sequence of str
    c : float
        Conservativeness in [0, 1].  0 → mean gradient; 1 → most averse.
    rescale : {0, 1, 2}
        0 = none, 1 = rescale to ‖g_avg‖, 2 = rescale to ‖g_avg‖².

    Notes
    -----
    - O(n) backward passes.
    - ``c = 0`` degenerates to vanilla mean gradient.
    - When mixed-precision is active, losses are scaled before grad
      computation (same mechanism as PCGrad).
    """

    def __init__(
            self,
            task_names: Sequence[str],
            c: float = 0.5,
            rescale: int = 1,
    ) -> None:
        super().__init__()
        if not (0.0 <= c <= 1.0):
            raise ValueError(f"c must be in [0, 1], got {c}")
        if rescale not in (0, 1, 2):
            raise ValueError(f"rescale must be 0, 1, or 2, got {rescale}")
        if not task_names:
            raise ValueError("task_names must be non-empty")
        self.task_names: List[str] = list(task_names)
        self.c = c
        self.rescale = rescale
        self.optimize_mode = LossWeightStrategyOptimizeMode.grad_inner

    def is_gradient_strategy(self) -> bool:
        return True

    def compute_weights(
            self, raw_losses: Dict[str, Tensor], step: int = 0,
    ) -> Dict[str, Tensor]:
        device = next(iter(raw_losses.values())).device
        return {k: torch.ones(1, device=device) for k in raw_losses}

    def backward(
            self,
            raw_losses: Dict[str, Tensor],
            shared_params: Iterator[nn.Parameter],
    ) -> None:
        """Compute CAGrad-adjusted gradients and write to ``param.grad``."""
        params = [p for p in shared_params if p.requires_grad]
        names = list(raw_losses.keys())
        n = len(names)
        scaler = self._scaler

        # Step 1: flat gradients
        flat_grads: List[Tensor] = []
        for name in names:
            loss_i = raw_losses[name]
            if scaler is not None:
                loss_i = scaler.scale(loss_i)
            flat_grads.append(_flat_grad(loss_i, params))

        # Step 2: CAGrad solve
        G = torch.stack(flat_grads)       # (n, d)
        g_avg = G.mean(dim=0)             # (d,)
        g_star = self._cagrad_solve(G, g_avg, n)

        # Step 3: write back
        _write_grad(g_star, params)

    def _cagrad_solve(self, G: Tensor, g_avg: Tensor, n: int) -> Tensor:
        """Frank-Wolfe closed-form approximation."""
        eps = 1e-8
        g_avg_norm = g_avg.norm() + eps

        phi = torch.mv(G, g_avg) / g_avg_norm  # (n,)

        if self.c == 0.0 or phi.min() >= 0:
            g_star = g_avg
        else:
            phi_norm = phi.norm() + eps
            w = F.softmax(-phi / phi_norm * self.c * n, dim=0)
            g_star = g_avg + self.c * torch.mv(G.t(), w)

        if self.rescale == 1:
            g_star = g_star / (g_star.norm() + eps) * g_avg_norm
        elif self.rescale == 2:
            g_star = g_star / (g_star.norm() + eps) ** 2 * g_avg_norm ** 2

        return g_star

    def extra_repr(self) -> str:
        return f"tasks={self.task_names}, c={self.c}, rescale={self.rescale}"