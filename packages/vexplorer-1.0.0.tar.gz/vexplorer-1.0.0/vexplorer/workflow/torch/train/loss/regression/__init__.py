"""Regression losses with mask support."""

from .masked_loss import MaskedMSE, MaskedMAE

__all__ = [
    'MaskedMSE',
    'MaskedMAE',
]
