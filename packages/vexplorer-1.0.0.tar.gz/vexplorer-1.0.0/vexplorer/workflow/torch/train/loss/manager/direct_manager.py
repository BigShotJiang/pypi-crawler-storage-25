# -*- coding: utf-8 -*-
"""
Direct loss manager for managing multiple loss functions with direct argument passing.

All losses receive the same arguments directly without routing or remapping.
Weights are configured through the manager's ``weight_strategy``, not in
:meth:`~DirectLossManager.add_loss`.
"""

from collections import OrderedDict
from dataclasses import dataclass, field
from typing import Any, Callable, Dict, Optional, Union

import torch
import torch.nn as nn
from torch import Tensor

from ..base import BaseLossManager
from .weight_strategy import BaseWeightStrategy


__all__ = ['DirectLossWrapper', 'DirectLossManager']


@dataclass
class DirectLossWrapper:
    """
    Configuration wrapper for losses managed by DirectLossManager.

    Controls priority ordering and optional input transformations for each
    loss.  All losses receive the same args and kwargs directly.

    Parameters
    ----------
    priority : int
        Computation priority.  Lower values are computed first.
        Losses with the same priority are ordered alphabetically by name.
        Default: 0.
    input_transform : Dict[str, Callable]
        Transforms applied to kwargs before passing to the loss.
        Keys are the kwarg names in ``manager.forward()``.
        Default: empty dict (no transform).
    arg_transform : Dict[int, Callable]
        Transforms applied to positional arguments.
        Keys are argument indices.
        Default: empty dict (no transform).

    Examples
    --------
    >>> wrapper = DirectLossWrapper(priority=1)

    >>> wrapper = DirectLossWrapper(
    ...     priority=0,
    ...     input_transform={'input': lambda x: torch.sigmoid(x)},
    ... )
    """
    priority: int = 0
    input_transform: Dict[str, Callable] = field(default_factory=dict)
    arg_transform: Dict[int, Callable] = field(default_factory=dict)

    def __post_init__(self):
        if self.input_transform is None:
            self.input_transform = {}
        if self.arg_transform is None:
            self.arg_transform = {}


class DirectLossManager(BaseLossManager):
    """
    Direct loss manager — all losses receive the same args/kwargs.

    This is the simplest multi-loss manager.  Every registered loss sees
    the full input (optionally with per-loss transform).  Weighting is
    configured through :attr:`weight_strategy`, not in :meth:`add_loss`.

    Parameters
    ----------
    detach : bool
        Whether to detach tensors before passing to losses. Default: False.
    clone : bool
        Whether to clone tensors before passing to losses. Default: False.
    weight_strategy : BaseWeightStrategy or None
        Weighting strategy.  ``None`` (default) creates a
        :class:`~.weight_strategy.StaticWeightStrategy` with unit weights.

    Examples
    --------
    >>> manager = DirectLossManager()
    >>> manager.add_loss('mse', nn.MSELoss())
    >>> manager.add_loss('mae', nn.L1Loss())
    >>> # equal unit weights by default
    >>> loss = manager(predictions, targets)

    >>> # static weights via strategy
    >>> from losses.managers import StaticWeightStrategy
    >>> manager = DirectLossManager(
    ...     weight_strategy=StaticWeightStrategy({'mse': 2.0, 'mae': 0.5})
    ... )
    >>> manager.add_loss('mse', nn.MSELoss())
    >>> manager.add_loss('mae', nn.L1Loss())

    >>> # dynamic weights
    >>> manager = DirectLossManager(
    ...     weight_strategy=DWAStrategy(['mse', 'mae'])
    ... )
    >>> manager.add_loss('mse', nn.MSELoss())
    >>> manager.add_loss('mae', nn.L1Loss())
    >>> loss = manager(predictions, targets)

    Notes
    -----
    - All losses receive the same arguments (broadcast).
    - Losses are computed in priority order (lowest first).
    - For per-task transform use :class:`DirectLossWrapper`.
    """

    def __init__(
        self,
        detach: bool = False,
        clone: bool = False,
        weight_strategy: Optional[BaseWeightStrategy] = None,
    ):
        super().__init__(detach=detach, clone=clone, weight_strategy=weight_strategy)
        self._losses: OrderedDict[str, nn.Module] = OrderedDict()
        self._wrappers: Dict[str, Optional[DirectLossWrapper]] = {}

    def add_loss(
        self,
        name: str,
        loss_fn: nn.Module,
        wrapper: Optional[DirectLossWrapper] = None,
    ) -> None:
        """
        Register a loss function.

        Weights are configured through ``manager.weight_strategy``.  For
        a :class:`~.weight_strategy.StaticWeightStrategy` (the default)::

            manager.weight_strategy.update_weight('mse', 2.0)

        Parameters
        ----------
        name : str
            Unique name identifier for the loss.
        loss_fn : nn.Module
            The loss function to register.
        wrapper : DirectLossWrapper or None
            Optional configuration wrapper for priority and per-loss
            transform.

        Raises
        ------
        ValueError
            If *name* is already registered.
        """
        if name in self._losses:
            raise ValueError(f"Loss '{name}' already exists in DirectLossManager")

        self._losses[name] = loss_fn
        self._wrappers[name] = wrapper

    def _compute_raw_losses(self, *args, **kwargs) -> Dict[str, Tensor]:
        """
        Compute all losses with per-loss transform, returning an unweighted dict.

        Returns
        -------
        Dict[str, Tensor]
            Mapping of loss name → scalar loss tensor (or flattened
            sub-keys for dict-returning losses).

        Raises
        ------
        ValueError
            If no losses have been added.
        """
        if not self._losses:
            raise ValueError("No losses have been added to DirectLossManager")

        args = self._prepare_args(args)
        kwargs = self._prepare_kwargs(kwargs)

        sorted_names = sorted(
            self._losses.keys(),
            key=lambda n: (
                self._wrappers[n].priority if self._wrappers[n] is not None else 0,
                n,
            ),
        )

        raw: Dict[str, Tensor] = {}
        for name in sorted_names:
            loss_fn = self._losses[name]
            wrapper = self._wrappers[name]

            loss_args = args
            loss_kwargs = kwargs.copy()

            if wrapper is not None:
                if wrapper.arg_transform:
                    loss_args = tuple(
                        wrapper.arg_transform.get(i, lambda x: x)(arg)
                        for i, arg in enumerate(loss_args)
                    )
                if wrapper.input_transform:
                    loss_kwargs = {
                        k: wrapper.input_transform.get(k, lambda x: x)(v)
                        for k, v in loss_kwargs.items()
                    }

            self._collect_loss(raw, name, loss_fn(*loss_args, **loss_kwargs))

        return raw

    def to(self, device: Union[str, torch.device]) -> 'DirectLossManager':
        """Move all loss functions to *device*."""
        super().to(device)
        for name, loss_fn in self._losses.items():
            self._losses[name] = loss_fn.to(device)
        return self

    def del_loss(self, name: str) -> None:
        """
        Remove a loss function by *name*.

        Raises
        ------
        KeyError
            If *name* is not registered.
        """
        if name not in self._losses:
            raise KeyError(f"Loss '{name}' not found in DirectLossManager")
        del self._losses[name]
        del self._wrappers[name]

    def get_loss_names(self) -> list:
        """Return registered loss names in insertion order."""
        return list(self._losses.keys())

    def get_loss_details(self) -> Dict[str, Dict[str, Any]]:
        """
        Return detailed information about each registered loss.

        Returns
        -------
        Dict[str, Dict[str, Any]]
            Keys: ``'loss_fn'``, ``'wrapper'``.
        """
        return {
            name: {
                'loss_fn': self._losses[name],
                'wrapper': self._wrappers[name],
            }
            for name in self._losses
        }
