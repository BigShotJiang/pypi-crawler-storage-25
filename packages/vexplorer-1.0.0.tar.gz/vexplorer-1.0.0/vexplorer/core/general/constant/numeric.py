

MAX_SAFE_INT: int = 2**31 - 1
r"""The maximum safe integer ensuring 32-bit compatibility.

Value is :math:`2^{31} - 1` (2147483647).
This constant is used for random seeds to ensure compatibility across both
signed and unsigned 32-bit environments.
"""





