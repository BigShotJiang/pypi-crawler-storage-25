# -*- coding: utf-8 -*-
"""
YAML Configuration Management Module.

This module provides a robust, production-ready YAML configuration loader
designed for complex deep learning pipelines and large-scale experiments.
It heavily embraces the "Composition over Inheritance" design pattern.
"""

import os
import re
import json
import logging
import importlib.util
from copy import deepcopy
from typing import Any, Dict, List, Optional, Tuple, Union

import yaml

# Initialize module-level logger. 
# In a library, we attach a NullHandler to avoid "No handler found" warnings
# if the user hasn't configured logging in their main application.
logger = logging.getLogger(__name__)
logger.addHandler(logging.NullHandler())


class YamlConfigLoader:
    """A comprehensive configuration parser for deep learning experiments.

    This parser supports variable interpolation, modular composition via templates,
    and recursive inheritance. It allows configurations to be built dynamically,
    significantly reducing redundancy across experiment runs.

    Key Features:
        * **Variable Interpolation**: ``${var}`` syntax, supported globally.
        * **Universal List Access**: Automatically converts lists to dicts for dot-notation 
          indexing (e.g., ``${data.0.path}``).
        * **Template Inheritance**: Inherit from external files or the same file.
        * **Self-Reference**: Use ``template_path: "."`` to refer to the current file.
        * **Deep Indexing**: Use ``template_name: "group.sub.item"`` to cherry-pick sections.
        * **Path Resolution**: Supports absolute, relative, and package paths (e.g., ``vexplorer/``).
        * **Circular Dependency Detection**: Safely catches and traces infinite inheritance loops.

    .. note::
        All loaded YAML files are cached during a single ``load_config`` call to 
        minimize disk I/O when multiple templates inherit from the same base file.

    Example:
        >>> # Assume exp.yaml contains:
        >>> # dataset:
        >>> #   path: "${base_dir}/${modes.0}"
        >>> build_vars = {"base_dir": "/data", "modes": ["train", "val"]}
        >>> cfg = YamlConfigLoader.load_config_with_variables('exp.yaml', variables=build_vars)
        >>> print(cfg['dataset']['path'])
        '/data/train'
    """

    # Pre-compiled regex for variable interpolation to optimize performance.
    _VAR_PATTERN = re.compile(r'\$\{(\s*[\w\.]+\s*)\}')

    # ------------------------------------------------------------------
    # Public API
    # ------------------------------------------------------------------

    @classmethod
    def load_config(cls, path: str) -> Dict[str, Any]:
        """Loads and resolves a YAML configuration file.

        Args:
            path (str): The file path to the root configuration file.

        Returns:
            Dict[str, Any]: The fully resolved configuration dictionary.

        Raises:
            FileNotFoundError: If the specified file path does not exist.
            ValueError: If the YAML file contains invalid syntax.
        """
        return cls.load_config_with_variables(path)

    @classmethod
    def load_config_with_variables(
            cls,
            path: str,
            variables: Optional[Dict[str, Any]] = None,
    ) -> Dict[str, Any]:
        """Loads a YAML configuration file and resolves all dynamic structures.

        Args:
            path (str): The file path to the root configuration file.
            variables (Optional[Dict[str, Any]], optional): A dictionary of variables 
                to inject into the config for ``${var}`` interpolation. Defaults to None.

        Returns:
            Dict[str, Any]: The fully resolved configuration dictionary.

        Raises:
            FileNotFoundError: If the config file cannot be found.
            ValueError: If circular template dependencies are detected.
        """
        real_path = cls._resolve_path(path)
        if not os.path.exists(real_path):
            raise FileNotFoundError(f"Root config file not found: {real_path}")

        logger.info(f"Initializing config load from: {real_path}")

        # 1. Pre-process variables: Convert lists to index-keyed dicts
        processed_vars = cls._convert_lists_to_dicts(variables) if variables else {}

        # 2. Context Initialization: file caching & safe tuple for circular dependency tracking
        file_cache: Dict[str, Dict[str, Any]] = {}
        seen_nodes: Tuple[Tuple[str, str], ...] = ()

        # 3. Load the root file with text-level variable interpolation
        cfg = cls._load_yaml_with_interpolation(real_path, processed_vars, file_cache)

        # 4. Recursively resolve all template inheritances
        resolved_cfg = cls._recursive_resolve(
            cfg, real_path, file_cache, seen_nodes, processed_vars
        )
        
        return resolved_cfg

    @staticmethod
    def update_config_from_list(cfg: Dict[str, Any], overrides: List[str]) -> Dict[str, Any]:
        """Updates a configuration dictionary with CLI overrides.

        Supports dot-separated key paths and safely parses JSON values. If an intermediate 
        key exists but is not a dictionary, it will be forcefully overwritten into a dictionary
        to prevent TypeError crashes.

        Args:
            cfg (Dict[str, Any]): The base configuration dictionary.
            overrides (List[str]): A list of string overrides in the format ``key.sub_key=value``.

        Returns:
            Dict[str, Any]: The updated configuration dictionary (updated in-place).

        Example:
            >>> cfg = {'model': {'layers': 3}}
            >>> YamlConfigLoader.update_config_from_list(cfg, ['model.layers=5', 'model.dropout=0.1'])
            {'model': {'layers': 5, 'dropout': 0.1}}
        """
        if not overrides:
            return cfg

        for override in overrides:
            if '=' not in override:
                logger.warning(f"Ignoring invalid CLI override (missing '='): {override}")
                continue
            
            key_str, value_str = override.split('=', 1)
            
            # Attempt to parse the value as JSON (e.g., lists, dicts, ints, floats, booleans)
            try:
                value = json.loads(value_str)
            except json.JSONDecodeError:
                value = value_str  # Fallback to pure string

            keys = key_str.split('.')
            current = cfg
            
            # Traverse and construct missing intermediate dictionaries
            for k in keys[:-1]:
                if k not in current or not isinstance(current[k], dict):
                    current[k] = {}
                current = current[k]
                
            # Assign the final leaf value
            current[keys[-1]] = value
            logger.debug(f"Applied CLI override: '{key_str}' -> {value}")

        return cfg

    @staticmethod
    def read_yaml(path: str) -> Any:
        """Utility function to perform a raw load of a YAML file.

        Args:
            path (str): Path to the YAML file.

        Returns:
            Any: The parsed YAML content (usually a Dict or List).
        """
        with open(path, 'r', encoding='utf-8') as f:
            return yaml.safe_load(f)

    # ------------------------------------------------------------------
    # Internal Helpers: Variables & Loading
    # ------------------------------------------------------------------

    @classmethod
    def _convert_lists_to_dicts(cls, data: Any) -> Any:
        """Recursively converts lists into dictionaries with string-index keys.
        
        This enables the interpolation engine to treat `${my_list.0}` identically
        to a standard dictionary lookup `data['my_list']['0']`.
        """
        if isinstance(data, list):
            return {str(i): cls._convert_lists_to_dicts(v) for i, v in enumerate(data)}
        elif isinstance(data, dict):
            return {k: cls._convert_lists_to_dicts(v) for k, v in data.items()}
        return data

    @classmethod
    def _interpolate_variables(cls, content: str, variables: Dict[str, Any]) -> str:
        """Replaces ``${var}`` placeholders in a string with values from the context."""
        def lookup(key_path: str, ctx: Dict[str, Any]) -> Optional[str]:
            try:
                val: Any = ctx
                for k in key_path.strip().split('.'):
                    val = val[k]
                return str(val)
            except (KeyError, TypeError, IndexError):
                return None

        def replace_func(match: re.Match) -> str:
            val = lookup(match.group(1), variables)
            # If variable is not found in context, leave it intact for potential later resolution
            return match.group(0) if val is None else val

        return cls._VAR_PATTERN.sub(replace_func, content)

    @classmethod
    def _load_yaml_with_interpolation(
            cls,
            abs_path: str,
            variables: Dict[str, Any],
            file_cache: Dict[str, Dict[str, Any]],
    ) -> Dict[str, Any]:
        """Reads a file, applies text-level interpolation, parses YAML, and caches it."""
        if abs_path in file_cache:
            return file_cache[abs_path]

        try:
            with open(abs_path, 'r', encoding='utf-8') as f:
                content = f.read()
        except OSError as e:
            raise OSError(f"Failed to read config file at {abs_path}: {e}")

        if variables:
            content = cls._interpolate_variables(content, variables)

        try:
            data = yaml.safe_load(content) or {}
            file_cache[abs_path] = data
            return data
        except yaml.YAMLError as e:
            raise ValueError(f"Syntax error while parsing YAML file '{abs_path}':\n{e}")

    # ------------------------------------------------------------------
    # Internal Helpers: Recursive Resolution Logic
    # ------------------------------------------------------------------

    @classmethod
    def _recursive_resolve(
            cls,
            node: Any,
            current_file_path: str,
            file_cache: Dict[str, Dict[str, Any]],
            seen_nodes: Tuple[Tuple[str, str], ...],
            variables: Dict[str, Any],
    ) -> Any:
        """Traverses the config AST and resolves nodes designated as 'templates'."""
        if isinstance(node, dict):
            # Check for the Template Hook definition
            if node.get('type') == 'template':
                return cls._handle_template_node(
                    node, current_file_path, file_cache, seen_nodes, variables
                )

            # Standard dictionary traversal
            for k, v in node.items():
                node[k] = cls._recursive_resolve(
                    v, current_file_path, file_cache, seen_nodes, variables
                )
            return node

        elif isinstance(node, list):
            # Standard list traversal
            return [
                cls._recursive_resolve(x, current_file_path, file_cache, seen_nodes, variables)
                for x in node
            ]

        # Primitive types (int, str, float, etc.) return as-is
        return node

    @classmethod
    def _handle_template_node(
            cls,
            node: Dict[str, Any],
            current_file_path: str,
            file_cache: Dict[str, Dict[str, Any]],
            seen_nodes: Tuple[Tuple[str, str], ...],
            variables: Dict[str, Any],
    ) -> Dict[str, Any]:
        """Resolves a specific template node, fetching its base and applying overrides."""
        tpl_path = node.get('template_path')
        tpl_name = node.get('template_name')

        if not tpl_path or not tpl_name:
            raise ValueError(
                "A template node must explicitly define both 'template_path' and 'template_name'."
            )

        # 1. Resolve Absolute Path
        current_dir = os.path.dirname(current_file_path)
        abs_tpl_path = current_file_path if tpl_path == "." else cls._resolve_path(tpl_path, current_dir)

        if not os.path.exists(abs_tpl_path):
            raise FileNotFoundError(f"Referenced template file not found: {abs_tpl_path}")

        # 2. Circular Dependency Safeguard
        node_id = (abs_tpl_path, tpl_name)
        if node_id in seen_nodes:
            chain = " ->\n  ".join(f"{os.path.basename(p)} [section: {n}]" for p, n in seen_nodes)
            raise ValueError(
                f"Circular template dependency detected! Resolution chain:\n  {chain} ->\n  "
                f"{os.path.basename(abs_tpl_path)} [section: {tpl_name}] (LOOP)"
            )

        # 3. Load Base Template File
        full_tpl_data = cls._load_yaml_with_interpolation(abs_tpl_path, variables, file_cache)

        # 4. Extract Target Section (Support deep indexing and root indexing ".")
        try:
            base_node_raw = cls._get_nested_value(full_tpl_data, tpl_name)
        except KeyError as e:
            raise KeyError(
                f"Section '{tpl_name}' could not be located in template file '{abs_tpl_path}'.\nDetails: {e}"
            )

        # 5. Recursive Resolution of the Inherited Content
        # We pass a new Tuple to `seen_nodes` to maintain immutable state tracking for this branch
        resolved_base = cls._recursive_resolve(
            deepcopy(base_node_raw),
            abs_tpl_path,
            file_cache,
            seen_nodes + (node_id,),
            variables
        )

        # 6. Apply Local Overrides (Params merging)
        final_node = deepcopy(resolved_base)
        if isinstance(final_node, dict):
            override_params = node.get('params', {})
            base_params = final_node.get('params', {})
            if override_params or base_params:
                final_node['params'] = cls._merge(base_params, override_params)

        return final_node

    # ------------------------------------------------------------------
    # Utilities: Path Math, Merging, and Lookups
    # ------------------------------------------------------------------

    @staticmethod
    def _resolve_path(path: str, root_dir: Optional[str] = None) -> str:
        """Resolves file paths considering system paths, relative paths, and package roots."""
        # Handle package-specific protocol paths (e.g., 'vexplorer/configs/base.yaml')
        if path.startswith("vexplorer/"):
            spec = importlib.util.find_spec("vexplorer")
            if spec and spec.origin:
                pkg_root = os.path.dirname(os.path.dirname(spec.origin))
                rel_path = path[len("vexplorer/"):]
                return os.path.abspath(os.path.join(pkg_root, "vexplorer", rel_path))
            else:
                logger.warning("Module 'vexplorer' not found, treating as a standard relative path.")

        if os.path.isabs(path):
            return path

        if root_dir:
            return os.path.abspath(os.path.join(root_dir, path))

        return os.path.abspath(path)

    @staticmethod
    def _merge(base: Dict[str, Any], override: Dict[str, Any]) -> Dict[str, Any]:
        """Performs a deep merge of ``override`` into ``base``.

        Args:
            base (Dict[str, Any]): The foundational dictionary.
            override (Dict[str, Any]): The dictionary containing values to overwrite.

        Returns:
            Dict[str, Any]: A new merged dictionary.
        """
        # Copy base once at the root level to prevent mutating the original templates
        merged = deepcopy(base or {})

        def _recursive_update(b: Dict[str, Any], o: Dict[str, Any]) -> None:
            for k, v in o.items():
                if isinstance(v, dict) and k in b and isinstance(b[k], dict):
                    _recursive_update(b[k], v)
                else:
                    # Deepcopy the incoming value to prevent unintended reference sharing
                    b[k] = deepcopy(v)

        _recursive_update(merged, override or {})
        return merged

    @staticmethod
    def _get_nested_value(data: Dict[str, Any], key_path: str) -> Any:
        """Retrieves a value from a nested dict using dot notation.

        Args:
            data (Dict[str, Any]): The dictionary to search.
            key_path (str): The dot-separated path (e.g., ``model.backbone.channels``).
                Use ``"."`` or an empty string to return the root data itself.

        Raises:
            KeyError: If the path traverses a non-dict type or the key is not found.
            
        Returns:
            Any: The extracted value.
        """
        if not key_path or key_path == ".":
            return data

        current = data
        for k in key_path.split('.'):
            if not isinstance(current, dict):
                raise KeyError(
                    f"Expected a dictionary while traversing '{k}', but encountered type '{type(current).__name__}'."
                )
            if k not in current:
                raise KeyError(f"Key '{k}' is missing.")
            current = current[k]
            
        return current

