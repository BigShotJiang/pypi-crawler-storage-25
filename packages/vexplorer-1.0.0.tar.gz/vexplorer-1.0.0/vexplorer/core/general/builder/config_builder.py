import logging
import importlib
from typing import Any, Dict, List, Optional, Union, Tuple

logger = logging.getLogger(__name__)

def _get_obj_from_path(path: str) -> Any:
    """Helper function to dynamically import an object from a string path.

    Args:
        path (str): The dot-separated path to the object (e.g., 'os.path.join').

    Returns:
        Any: The imported object (class, function, or instance).

    Raises:
        ImportError: If the module cannot be imported.
        AttributeError: If the object is not found in the module.
    """
    if '.' not in path:
        return importlib.import_module(path)

    module_path, obj_name = path.rsplit('.', 1)
    try:
        module = importlib.import_module(module_path)
    except ImportError as e:
        raise ImportError(f"Failed to import module '{module_path}' from path '{path}'. Error: {e}")

    try:
        return getattr(module, obj_name)
    except AttributeError:
        raise AttributeError(f"Module '{module_path}' has no attribute '{obj_name}'.")


def build_from_cfg(
        cfg: Union[Dict, List, None],
        params_override: Optional[Dict[str, Any]] = None,
        return_instance: bool = True,
        callable_test: bool = True,
) -> Union[Any,Tuple[Any,Any]]:
    """Builds an object from a configuration dictionary or list.

    This function supports two modes: 'import' and 'registry'. It dynamically
    resolves classes or functions and instantiates them with provided parameters.

    Args:
        cfg (Dict | List | None): The configuration object.

            * If ``None``: Returns None.
            * If ``List``: Recursively calls ``build_from_cfg`` for each item.
            * If ``Dict`` (standard config):
                * ``type`` (str): Required. Either ``'import'`` or ``'registry'``.
                * ``name`` (str | List[str]): The target name.
                  If a list is provided, the first N-1 items are imported for side effects
                  (e.g., triggering decorators), and the last item is the target.
                * ``registry`` (str): Required if ``type='registry'``. The python path
                  to the registry object (e.g., ``'my_project.registry.MODELS'``).
                * ``params`` (Dict, optional): Initialization arguments.
            * If ``Dict`` (raw): If ``type`` is missing, returns ``cfg`` as is.

        params_override (Dict, optional): A dictionary of parameters to
            override the default values in ``cfg['params']``. Defaults to None.

        return_instance (bool): If True, returns the instantiated object.
            If False, returns a tuple of (Callable, Dict). Defaults to True.

        callable_test (bool): If True, test callable for each item.

    Returns:
        Any: The instantiated object, a list of objects, or the raw config data.
        Tuple[Any,Any]: if not return_instance return cls, params

    Raises:
        ValueError: If ``type`` is invalid, or required fields (like ``name`` or ``registry``) are missing.
        ImportError: If modules specified in ``name`` or ``registry`` cannot be imported.
        TypeError: If the resolved object is not callable or instantiation fails.
        AttributeError: If the class definition is not found.

    Example:
        >>> # Case 1: Import Mode (Directly import class)
        >>> cfg = {
        ...     'type': 'import',
        ...     'name': 'collections.Counter',
        ...     'params': {'iterable': [1, 1, 2]}
        ... }
        >>> obj = build_from_cfg(cfg)
        >>> print(obj)
        Counter({1: 2, 2: 1})

        >>> # Case 2: Registry Mode (Import registry object -> get class -> instantiate)
        >>> # Assuming 'my_lib.registries.MODELS' is a registry object
        >>> # and 'ResNet' is registered inside it.
        >>> cfg = {
        ...     'type': 'registry',
        ...     'registry': 'my_lib.registries.MODELS',
        ...     'name': ['my_lib.backbones', 'ResNet'], # First item is side-effect import
        ...     'params': {'depth': 50}
        ... }
        >>> model = build_from_cfg(cfg)
    """
    # 1. Handle None
    if cfg is None:
        return None

    # 2. Handle List (Recursion)
    if isinstance(cfg, list):
        return [build_from_cfg(x, params_override) for x in cfg]

    # 3. Handle Raw Parameters (Return as is if not a build config)
    if not isinstance(cfg, dict) or 'type' not in cfg:
        return cfg

    # 4. Validation
    build_type = cfg.get('type')
    valid_types = {'import', 'registry'}
    if build_type not in valid_types:
        raise ValueError(f"Expected cfg['type'] in {valid_types}, but got: '{build_type}'")

    raw_names = cfg.get('name')
    if not raw_names:
        raise ValueError(f"Field 'name' is mandatory in config: {cfg}")

    # Normalize 'name' to list to support side-effect imports
    names_list = raw_names if isinstance(raw_names, list) else [raw_names]

    # 5. Prepare Parameters
    # params = cfg.get('params', {}).copy()
    params = (cfg.get('params') or {}).copy()
    if params_override:
        params.update(params_override)

    # 6. Resolution Loop
    cls = None

    for i, full_path in enumerate(names_list):
        is_last_item = (i == len(names_list) - 1)

        # Step 6a: Side-effect Imports (Pre-load modules)
        if not is_last_item:
            try:
                importlib.import_module(full_path)
                logger.debug(f"Side-effect module imported: {full_path}")
            except ImportError as e:
                raise ImportError(f"Failed to import side-effect module '{full_path}'. Detail: {e}")
            continue

        # Step 6b: Resolve Target (Last Item)
        if build_type == 'registry':
            registry_path = cfg.get('registry')
            if not registry_path:
                raise ValueError(f"Field 'registry' (path string) is required when type='registry'. Config: {cfg}")

            # Dynamically import the registry object itself
            try:
                registry_obj = _get_obj_from_path(registry_path)
            except (ImportError, AttributeError) as e:
                raise ImportError(f"Failed to load registry object from '{registry_path}'. Detail: {e}")

            # Retrieve class from registry
            # Note: registry object must implement .get(key)
            if not hasattr(registry_obj, 'get'):
                raise AttributeError(f"Registry object at '{registry_path}' has no method 'get'.")

            cls = registry_obj.get(full_path)
            if cls is None:
                raise ValueError(f"Key '{full_path}' not found in registry '{registry_path}'.")

            logger.debug(f"Resolved '{full_path}' via registry '{registry_path}'")

        elif build_type == 'import':
            # Direct import
            cls = _get_obj_from_path(full_path)
            logger.debug(f"Resolved '{full_path}' via direct import.")

    # 7. Instantiation
    try:
        if callable_test:
            if not callable(cls):
                raise TypeError(f"Resolved object {cls} (from '{names_list[-1]}') is not callable.")

        if not return_instance:
            return cls, params

        return cls(**params)
    except TypeError as e:
        cls_name = getattr(cls, '__name__', str(cls))
        raise TypeError(f"Failed to instantiate '{cls_name}' with params {params}. Detail: {e}")


