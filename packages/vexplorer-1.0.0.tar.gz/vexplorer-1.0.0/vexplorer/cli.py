# -*- coding: utf-8 -*-
"""
VExplorer CLI Entrypoint
========================

Main execution interface for the VExplorer framework. This script serves as the unified entry point
for training, testing, and inference pipelines. It is designed to be agnostic to the launcher
(python, torchrun, or accelerate), focusing solely on configuration parsing and runner dispatching.

Supported Launch Modes:
-----------------------
1. **Standard Python**: For single-gpu debugging or cpu-only runs.
2. **Torchrun**: For native PyTorch Distributed Data Parallel (DDP).
3. **Accelerate**: For HuggingFace Accelerate (Mixed Precision, DeepSpeed, Multi-node).

.. _cli-examples:

Examples:
----------

    **1. Standard Python Execution (Single Device / Debug)**

    .. code-block:: bash

        # 1.1 Run as a module (Recommended)

        # Assuming vexplorer is in PYTHONPATH
        python -m vexplorer.cli \\
            -c configs/experiments/lenet/lenet_base.yaml \\
            -o "workflow.run.runner.params.max_epochs=1"

        # 1.2 Run directly from file
        python cli.py \\
            -c configs/experiments/lenet/lenet_base.yaml \\
            -v configs/vars/env_local.yaml

    **2. Torchrun Execution (Native Distributed)**

    .. code-block:: bash

        # 2.1 Launch on 2 GPUs on a single node

        torchrun --nproc_per_node=2 \\
            -m vexplorer.cli \\
            -c configs/experiments/lenet/lenet_ddp.yaml \\
            -o "workflow.run.runner.params.sync_bn=True"

    **3. Accelerate Execution (Advanced Distributed / FP16 / BF16)**

    .. code-block:: bash

        # 3.1 Launch with accelerate

        accelerate launch \\
            -m vexplorer.cli \\
            -c configs/experiments/lenet/lenet_base.yaml \\
            -v configs/vars/static_vars.yaml \\
            -o "workflow.run.runner.params.max_epochs=10" \\
            -o "workflow.train.optimizer.lr=0.0005"


        # 3.2 Launch with specific accelerate config

        # First, generate or specify an accelerate config:
        accelerate config --config_file configs/accelerate/default_bf16.yaml
        # Then specify an accelerate config:
        accelerate launch \\
            --config_file configs/accelerate/default_bf16.yaml \\
            -m vexplorer.cli \\
            -c configs/experiments/lenet/lenet_base.yaml \\
            -v configs/vars/static_vars.yaml \\
            -o "workflow.run.runner.params.max_epochs=10" \\
            -o "workflow.train.optimizer.lr=0.0005"


CLI Arguments
-------------

    -c, --config (str)
        Path to the main workflow configuration file (YAML).
        *Required.*

    -v, --config_var (str, optional)
        Path to a YAML file containing variables for interpolation (e.g., system paths).
        *Default: None*

    -o, --override (list, optional)
        Override config params using dot notation. Can be used multiple times.
        Example: ``-o 'optimizer.lr=0.001'``

"""

import argparse
import logging
import os
import sys
import traceback
from typing import Optional, Dict, Any

# ----------------------------------------------------------------------
# Core Imports
# ----------------------------------------------------------------------
try:
    from vexplorer.core.general.configurator.yaml_manager import YamlConfigLoader
    from vexplorer.core.general.builder.config_builder import build_from_cfg

except ImportError as e:
    # Fallback specifically for local directory running without install
    sys.path.append(os.path.join(os.path.dirname(__file__), '..', '..'))
    try:
        from vexplorer.core.configurators.yaml_manager import YamlConfigLoader
        from vexplorer.core.builders.config_builder import build_from_cfg
    except ImportError:
        raise ImportError(f"Could not import vexplorer core modules. Error: {e}")


def parse_args() -> argparse.Namespace:
    """
    Parses command line arguments.

    Returns:
        argparse.Namespace: The parsed arguments object.
    """
    parser = argparse.ArgumentParser(
        description="VExplorer Unified Entrypoint",
        formatter_class=argparse.RawTextHelpFormatter
    )

    parser.add_argument(
        '-c', '--config',
        required=True,
        type=str,
        help="Path to the main config file (YAML)."
    )

    parser.add_argument(
        '-v', '--config_var',
        type=str,
        default=None,
        help="Path to a YAML file containing variables for interpolation (e.g., system paths)."
    )

    parser.add_argument(
        '-o', '--override',
        action='append',
        default=[],
        help=(
            "Override config params using dot notation.\n"
            "Example: -o 'optimizer.lr=0.001' -o 'model.backbone.depth=50'"
        )
    )

    parser.add_argument(
        '-ov', '--override_config_var',
        action='append',
        default=[],
        help=(
            "Override config_var using dot notation.\n"
            "Example: -ov 'optimizer.lr=0.001' -ov 'log.log_root=./log_root'"
        )
    )

    return parser.parse_args()


def main(args: Optional[argparse.Namespace] = None) -> None:
    """
    Main execution pipeline.

    Args:
        args (Optional[argparse.Namespace]): Pre-parsed arguments. If None, parses from sys.argv.
    """
    if args is None:
        args = parse_args()

    logger = logging.getLogger(__name__)

    # 1. Load Variable Context
    # This is typically used for static paths or environment-specific variables
    var_ctx: Dict[str, Any] = {}
    if args.config_var:
        logger.info(f"Loading variable context: {args.config_var}")
        try:
            var_ctx = YamlConfigLoader.read_yaml(args.config_var)
        except Exception as e:
            logger.error(f"Failed to load variable context: {e}")
            traceback.print_exc()
            sys.exit(1)

    # 1.2 Apply CLI Overrides for config_var
    if args.override_config_var:
        logger.info(f"Applying {len(args.override_config_var)} CLI overrides for config_var")
        try:
            var_ctx = YamlConfigLoader.update_config_from_list(var_ctx, args.override_config_var)
        except Exception as e:
            logger.error(f"Failed to apply overrides: {e}")
            traceback.print_exc()
            sys.exit(1)

    # 2. Load Main Config (with Template Resolution)

    try:
        logger.info(f"Loading main configuration.")
        cfg = YamlConfigLoader.load_config_with_variables(args.config, variables=var_ctx)
    except Exception as e:
        logger.error(f"Failed to load config file: {e} {args.config}")
        traceback.print_exc()
        sys.exit(1)

    # 3. Apply CLI Overrides
    if args.override:
        logger.info(f"Applying {len(args.override)} CLI overrides")
        try:
            cfg = YamlConfigLoader.update_config_from_list(cfg, args.override)
        except Exception as e:
            logger.error(f"Failed to apply overrides: {e}")
            traceback.print_exc()
            sys.exit(1)

    # 4. Build Runner
    # The runner encapsulates the training/validation loop and device management.
    try:
        def get_by_path(data, path):
            keys = path.split('.')
            for key in keys:
                if isinstance(data, dict) and key in data:
                    data = data[key]
                else:
                    raise Exception(f"Could not find key {key} in {path}")
            return data

        cli_cfg = cfg.get('cli', {})
        logger.info(f"Using cli config: {cli_cfg}")

        run_class_cfg_path = cli_cfg.get('run_class_cfg_path',"workflow.run.runner_cfg")
        run_class_init_accept_full_cfg = cli_cfg.get('run_class_init_accept_full_cfg',"raw_cfg")
        run_interface_name = cli_cfg.get('run_interface',"run")
        run_interface_params = cli_cfg.get('run_interface_params',{})
        if run_interface_params is None: run_interface_params = {}

        run_class_cfg = get_by_path(data=cfg, path=run_class_cfg_path)

        running_ctx = {run_class_init_accept_full_cfg: cfg}

        runner = build_from_cfg(
            run_class_cfg,
            params_override=running_ctx
        )
    except Exception as e:
        logger.error(f"Runner Initialization Failed: {e}")
        traceback.print_exc()
        sys.exit(1)

    # 5. Execute Entry Method
    if not hasattr(runner, run_interface_name):
        logger.error(f"Runner '{type(runner).__name__}' has no method '{run_interface_name}'")
        sys.exit(1)

    entry_method = getattr(runner, run_interface_name)

    logger.info(f"Starting Workflow -> {type(runner).__name__}.{run_interface_name}()")
    try:
        entry_method(**run_interface_params)
    except Exception as e:
        logger.error(f"Runtime Error during {run_interface_name}(): {e}")
        traceback.print_exc()
        sys.exit(1)
    else:
        logger.info("Workflow finished successfully.")

if __name__ == "__main__":
    main()




